# A certified operational reset without resetting the true environment

28 October 2026. New construction candidate; independent review pending. This imports the received trace-class complete-quotient primitive, not an unproved physical realization or reset oracle. It removes ongoing environment-reset demands CONDITIONAL on an already valid acquired core. Cold-start acquisition without reset remains a separate obligation.

## 1. Actual operation and certificate inputs

Use the stationary finite accessible quantum-port and honest finite observable-rank-r contract of TRACE_CLASS_COMPLETE_QUOTIENT_EXTENSION.md. The true hidden memory may be infinite-dimensional. A valid r-core supplies raw physical prefixes tau_j, empty prefix first, trace row m_j=Tr(tau_j), m_1=1, 0<=m_j<=1, and predictive coordinates Pi with complete positive-state bound ||Pi(Omega)||_Sigma<=K Tr(Omega). Unknown core values need not be supplied exactly: simultaneous valid intervals from a prior paid acquisition suffice.

Fix a finite physically executed memory-only word R. The word and its control configuration are fixed independently of the record whose dependence is to be erased. If a prior pilot selects the word/configuration, all following decoupling claims are CONDITIONAL on that frozen pilot configuration; the operational limit may depend on it. A common limit across configurations or an independent fixed choice is necessary for unconditional erasure of configuration information. Simultaneous confidence for word selection does not supply such a common limit. It prepares declared accessible inputs, runs native operations and discards all accessible outputs/outcomes at its end; any local ancillas are freshly initialized each repetition. Thus its ACTUAL memory map Psi is CPTP and preserves the reachable algebraic span and its invisible subspace. No outcome postselection or retained reset-record controller is silently inserted. Let C be its true r-by-r coordinate matrix, so Pi Psi=C Pi and mC=m. The word's full call, preparation, discarded-readout, duration and control costs are charged every repetition.

Acquire C from the shifted raw table H_R,ij=Tr[F_i Psi(tau_j)] using the same valid core interval inversion as the signed predictor. These are actual joint prefix/reset-word/future probabilities. They include all failed prefix trials and marginalize reset outputs. Acquisition of these tables is NOT free from an arbitrary current hidden state; see Section6.

## 2. Eliminate the unknown trace coordinate stably

Let E select coordinates2,...,r and define

    W_m y = (-sum_(j=2)^r m_j y_j, y_2,...,y_r).

Then m W_m=0, E W_m=I, and every tuple x with m x=0 equals W_m E x. On the amplified block trace norm, ||E||<=1 and ||W_m||<=2 because 0<=m_j<=1. This holds with operator-valued Hermitian coordinates and arbitrary finite reference dimensions, not only scalar probability vectors.

Define

    a=E C e_1, D=E C W_m.

On the trace-one affine hyperplane y=E x evolves as y'=a+D y. On trace-zero tuples, C W_m=W_m D because mC=m. If the computable certificate below gives

    ||D||_(1->1) <= c <1,                                  (1)

then every amplified trace-zero block contracts: ||D^t y||_Sigma<=c^t||y||_Sigma. This uses only the sum of absolute matrix coefficients, so no unspecified completely bounded norm optimization is hidden.

The affine fixed point is y_*=(I-D)^(-1)a and v=e_1+W_m y_*. Starting from physical rho_0, C^t e_1 converges to v. Since every such physical state has coordinate norm<=K, ||v||_1<=K and ||y_*||_1<=K. This does NOT assert convergence of the actual memory state in trace norm or existence of a physical stationary trace-class memory state.

For r=1, the quotient is already operationally independent of memory: take v=1 and zero reset cost. No empty-matrix norm ambiguity is required.

## 3. Decoupling an actual record or reference

Let Omega_MR be any positive normalized finite-history joint state whose memory blocks belong to the reachable algebraic span; R can contain retained classical calibration records and finite quantum registers. Put x=Pi(Omega), so ||x||_Sigma<=K and m x=Omega_R. Since E(x-v tensor Omega_R) has norm<=2K,

    ||C^t x - v tensor Omega_R||_Sigma
      <= ||W_m|| c^t ||E x-y_* tensor Omega_R||_Sigma
      <=4K c^t.                                           (2)

The actual operation Psi acts only on memory through its accessible word; it does not inspect R. Thus (2) is an operational forgetting certificate for initially correlated records, not merely a convergence statement from one fixed state.

For any subsequent finite allowed coherent/adaptive controller retaining R, the final accessible-output map on predictive tuples has norm at most one: realize a signed tuple by Lambda(x)=sum_j tau_j tensor x_j, execute the ACTUAL complete CPTP future controller, then trace hidden memory. Lambda has norm<=1; complete CPTP processing and partial trace contract Hermitian trace norm. Invisible-kernel invariance makes this representation exact on reached states. Consequently the half trace distance between the actual post-reset future output and its operational-limit reference is at most

    epsilon_reset(t)=min(1,2K c^t).                         (3)

The reference defined by v (or v_config conditional on a frozen selected configuration) is a physical accessible process at every finite horizon: it is the limit of the processes obtained by actual reset repetitions from rho_0. Each finite Choi channel is CPTP and that cone is closed. Consistent limits give a compatible finite-horizon family. We do not construct a finite hidden CP realization or assume that v has a positive Lambda representative.

The comparison is uniform over finite future controllers and finite reference dimensions at the actual ports. It is not a full hidden-memory diamond-norm reset. Hidden counters or inaccessible degrees of freedom can continue recording the entire past.

## 4. A finite interval test, including the trace row

Let valid simultaneous bounds give |C-Chat|<=F and |m-mhat|<=d, with m_1=mhat_1=1. All matrices/bounds can be rational. For row l>=2 and column j>=2 define

    Dhat_lj=Chat_lj-Chat_l1 mhat_j,
    B_lj=F_lj+F_l1+|Chat_l1| d_j.

Indeed D_lj=C_lj-C_l1 m_j, and |m_j|<=1 yields |D-Dhat|<=B. Therefore

    c_cert=max_(j>=2) sum_(l>=2) (|Dhat_lj|+B_lj)             (4)

is a certified amplified contraction constant. Accept ONLY if c_cert<1. This is a sufficient certificate, not a test characterizing all mixing sources; a poorly chosen core/norm can fail despite true mixing. Invalid or uninformative intervals cause ABSTAIN. Data-dependent word selection is permitted only under a simultaneous confidence event covering the declared finite word pool; arbitrary post-selection of unbudgeted words is not included. This certifies contraction separately for the selected configuration. It does NOT make its limiting process independent of the pilot selection record. Apply Sections2–3 conditional on that configuration, or separately prove every selectable word has the same operational limit. Distinct c=0 replacers already show why this qualification is essential.

Choose the smallest integer t such that 2K c_cert^t<=epsilon. Rational repeated powering suffices, with actual word length L_R giving t L_R native calls. For c_cert=0 one repetition suffices; for c_cert in(0,1) this is logarithmic in1/epsilon with the explicitly acquired conditioning/mixing constants. Confidence failure beta and physical WHOLE reset-word implementation distance nu_t are added once. Repetition of inaccurate controls needs an actual complete process bound, e.g. t times a certified per-word norm error; ideal contraction alone does not certify the hardware.

No empirical trace row is set to all ones. Trace-row uncertainty enters (4) and is essential: the stable trace-zero hyperplane depends on the actual raw prefix masses.

## 5. What it enables, and what it does not

After a valid core and reset certificate have been acquired, later calibration/service episodes can begin with this paid operational burn-in rather than a full environmental reset. Approximate starting-law errors must enter probability intervals and whole-process performance budgets; repeated episodes are not thereby literally independent.

For N reset-separated experiments whose conditional starting operational law is within epsilon_reset of the same limit, conditional event means differ from the corresponding limit-law probabilities by at most epsilon_reset. Classical martingale concentration can therefore use radius epsilon_reset plus its stochastic deviation, rather than falsely applying an exact iid model. A joint whole-record comparison can alternatively pay at most N epsilon_reset by a hybrid. Which accounting is appropriate depends on the downstream theorem; it must be stated.

This also supplies a potential interface for retiring calibration records before a record-averaged recovery protocol: the memory is operationally decorrelated from those records to (3). It does NOT itself prove cancellation of decoder estimation errors, a fast1/N learning rate, or a guarantee after records remain accessible to the final evaluator. Those are separate constructions.

The strongest conventional baseline is a known mixing/burn-in or Doeblin-style condition followed by ordinary identification. The addition here is an acquired sufficient contraction witness on the complete observable quotient, with trace-row uncertainty and a possibly infinite nonmixing actual environment. No historical novelty or practical speed advantage is claimed.

## 6. Bootstrap boundary
