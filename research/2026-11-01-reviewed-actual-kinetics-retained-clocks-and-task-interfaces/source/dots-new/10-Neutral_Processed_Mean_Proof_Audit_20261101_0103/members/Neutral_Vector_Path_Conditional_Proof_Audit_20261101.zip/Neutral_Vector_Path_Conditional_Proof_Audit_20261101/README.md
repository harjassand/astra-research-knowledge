# Neutral vector to finite sampled paths: conditional proof package

**Current sharper proof plus independent audit. No upload. The previous proof
ZIP is unchanged. Generic conditional theory only: the actual global odd
trial/current and numerical sampled-path certificate remain pending.**

## Current accepted statement

Read `proof/NEUTRAL_VECTOR_AND_PATH_SHARP_V2.md`, then
`audits/NEUTRAL_VECTOR_INDEPENDENT_ACCEPTANCE.md`.

Under the base theorem's actual common-domain weak energy receiving, a unit
trial e with a=E(e,e), q=||A^(-1/2)e||^2, and d=aq-1 obeys

    ||x(t)||^2<=d/4,
    ||u(t)-exp(-at)e||^2<=d(1+d)/4.

If a<=k and kq<=1+epsilon, the rate-k vector error is at most

    G(epsilon)=0.5sqrt(epsilon(1+epsilon))+epsilon/exp(1).

This is a separately hashed root-author refinement independently checked by
the reviewer. The original weaker candidate remains unchanged and valid.
The preserved root message records its mathematical authorship; the reviewer
transcribed the current source rather than claiming a second reviewer audited
that transcription.

## Chronology and path join

The proof distinguishes chronological forward density P* from backward
observable evolution P_{t-r,t}. Both orientations are earned for the base's
actual compact transverse drift when the received trial depends only on y.
Neutrality of arbitrary phase-space trials is not automatic.

For a conservative full process, a mean-zero global trial psi still must earn
its finite inverse form and actual certificate. With N=||psi||^2, actual binary
label error eta, deterministic sampling intervals Delta_i, and r_i=exp(-kDelta_i),
the conditional vector receipt is

    delta_i=sqrt(N)G(epsilon)+(1+r_i)eta.

Initial density f0<=R relative to common invariant pi gives

    KL(actual finite label record || comparison record)
      <=R sum_i delta_i^2/(1-r_i^2).

The comparison has the SAME initial label law and transitions
Q_i(z,z')=(1+r_i zz')/2. Here k is a correlation-decay rate; a continuous-time
symmetric two-state representation would have flip rate k/2.

## Controlling qualifications and counterexamples

`audits/PATH_INDEPENDENT_AUDIT.md` is the independently accepted, unchanged
controlling path audit (SHA 592b28cb...73bfe). Its cost correction controls the
older path source: J FINITE accumulator states yield O(nJ) arithmetic
operations and O(J) space for fixed-cost updates. O(n) requires J fixed. Bit
complexity, numerical enclosures and certificate acquisition are separate.
Bounded real-valued range is not a fixed finite-state guarantee.

That audit includes counterexamples to replacing the density bound R by fixed
L2 concentration in the quadratic KL bound, to adaptive first-jump sampling,
and to the bounded-range cheap-computation inference. They remain active here.

No physical control/preparation, arbitrary record-feedback theorem, iid restart,
continuous renewal, processed MFPT, relative rare-event accuracy, infinite-record
uniform guarantee, universal cheap event oracle, historical novelty, quantum-
fault claim, or executable/numerical model acquisition is supplied. Ordinary
Schur/passivity/storage and entropy-chain explanations receive full credit.

## Files and checks

- `proof/`: current sharp source and immutable weaker source.
- `dependencies/`: complete base port proof/process receipt and source path theorem.
- `audits/`: independent vector/refinement acceptance and controlling path audit.
- `provenance/ROOT_REFINEMENT_MESSAGE.txt`: unchanged mathematical source message.
- `PROVENANCE.json`: exact source bindings.
- `check_integrity_and_algebra.py`: stdlib-only integrity and exact algebra checks.
- `SHA256SUMS`: every package file except itself.

Run:

    python check_integrity_and_algebra.py
    sha256sum -c SHA256SUMS

These are regression/integrity checks, not finite tests offered instead of the
analytical infinite-dimensional and actual-process proofs. The external ZIP
receipt records CRC, extraction and replay. No nested archive is included.
