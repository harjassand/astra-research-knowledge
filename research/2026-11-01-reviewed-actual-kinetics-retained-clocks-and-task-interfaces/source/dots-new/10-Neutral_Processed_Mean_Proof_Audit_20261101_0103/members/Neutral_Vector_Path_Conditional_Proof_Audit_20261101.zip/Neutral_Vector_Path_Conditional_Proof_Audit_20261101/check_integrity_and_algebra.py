#!/usr/bin/env python3
"""Exact algebra/integrity regression only; not an executable path receiver."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parent
p=json.loads((ROOT/'PROVENANCE.json').read_text())
for item in p['bound_sources']:
    assert sha256((ROOT/item['package_path']).read_bytes()).hexdigest()==item['sha256'],item
checks=0

def check(x):
    global checks
    assert x
    checks+=1

for ia in range(1,7):
    a=F(ia,11)
    for d in [F(j,7) for j in range(1,13)]+[F(1,10000),F(10),F(100)]:
        sigma=a*d/(1+d)
        q=(1+d)/a
        gamma=(a-sigma)/(a*sigma)
        b2=1/(2*a)
        check(0<sigma<a)
        check(sigma==a-1/q)
        check(d==sigma/(a-sigma))
        check(b2/(2*gamma)==d/4)
        check(d/4+d*d/4==d*(1+d)/4)
        check(d*(1+d)/4 <= d+F(5,4)*d*d)
        for j in range(11):
            t=F(j,5) # t=Y/b, eliminating square roots from the square identity.
            polynomial=2*t-2*gamma*t*t
            completed=1/(2*gamma)-2*gamma*(t-1/(2*gamma))**2
            check(polynomial==completed)
            check(b2*polynomial<=d/4)
# Sigma=0 endpoint has d=0, scalar and hidden bounds zero.
check(F(0)*(1+F(0))/4==0)
# Bernoulli denominator and exact density-counterexample identities.
for ir in range(10):
    r=F(ir,10)
    for z in [-1,1]:
        prob=(1+r*z)/2
        check(prob*(1-prob)==(1-r*r)/4)
        check(0<prob<1)
for n in range(2,51):
    delta=F(1,n*n)
    mass=F(1,n)
    D=mass*mass/delta + (1-mass)**2/((1-delta)/2)
    check(D==1+2*F(n-1,n+1))
    check(D<=3)
    check(mass/delta==n)
    check((1-mass)/((1-delta)/2)<=n)
check(F(1)+F(1)+F(1,2)+F(1,6)==F(8,3))
print(json.dumps({
 'status':'PASS',
 'bound_source_files':len(p['bound_sources']),
 'exact_rational_algebra_checks':checks,
 'scope':'integrity and finite algebra regression; analytical and actual-process proofs are in the bound documents',
 'concrete_global_odd_trial_or_numeric_path_accepted':False,
 'physical_control_or_preparation_accepted':False,
 'upload_performed':False
},indent=2,sort_keys=True))
