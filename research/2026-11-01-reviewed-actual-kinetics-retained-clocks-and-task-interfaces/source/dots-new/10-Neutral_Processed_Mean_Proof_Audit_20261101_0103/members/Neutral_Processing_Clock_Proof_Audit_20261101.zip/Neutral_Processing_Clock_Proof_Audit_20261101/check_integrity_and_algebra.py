#!/usr/bin/env python3
"""Integrity/exact-algebra regression checks, NOT a theorem or process receiver."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
if (ROOT / 'PROVENANCE.json').exists():
    package_root = ROOT
else:
    package_root = ROOT.parent.parent / 'Neutral_Processing_Clock_Proof_Audit_20261101'
manifest = json.loads((package_root / 'PROVENANCE.json').read_text())
file_checks = 0
for entry in manifest['bound_sources']:
    actual = sha256((package_root / entry['package_path']).read_bytes()).hexdigest()
    assert actual == entry['sha256'], (entry['package_path'], actual, entry['sha256'])
    file_checks += 1
checks = 0

def check(test):
    global checks
    assert test
    checks += 1

# Exact 2-by-2 Schur checks including sigma=0, spanning several scales.
# These are finite-dimensional algebra regressions, NOT proof of the
# infinite-dimensional completion or weak-domain theorem.
for ia in range(1, 6):
    for id_ in range(1, 6):
        for ib in range(8):
            a, d, b = F(ia+3, 3), F(id_+5, 5), F(ib, 16)
            det = a*d-b*b
            check(det > 0)
            q = d/det
            sigma = b*b/d
            check(sigma == a-1/q)
            check(0 <= sigma < a)
            check(sigma/(2*(a-sigma)) == (a*q-1)/2)
            # Squared coefficient of arbitrary hidden initial storage.
            check(a*sigma/(4*(a-sigma)**2) == (a*q-1)*a*q/4)

# Exact certificate normalization inequalities, without assuming N=M.
for im in range(1, 4):
    for excess in range(4):
        for extra_mass in range(3):
            for rnum in range(1, 5):
                for slack in range(3):
                    M = F(im, 3)
                    N = M*(1+F(excess, 10))
                    rho = F(excess+extra_mass, 10)
                    a = F(7, 11)
                    q = (1+F(rnum, 20))/a
                    C0 = a*N*(1+F(slack, 10))
                    B = q*N*(1+F(2-slack, 10))
                    k0 = C0/M
                    eps = C0*B/(M*M)-1
                    check(M <= N <= M*(1+rho))
                    check(eps >= 0)
                    check(a <= k0)
                    check(k0*q <= 1+eps)
                    check(a*q-1 <= eps)
                    check(k0/a-1 <= eps)
                    for D in [F(1), F(5,4), F(3)]:
                        X2 = D/M-1/N
                        check(X2 >= 0)
                        check(N*X2 == N*D/M-1)
                        check(N*X2 <= (1+rho)*D-1)

# Elementary rigorous constants: exp(1)>sum_{j=0}^3 1/j! = 8/3.
check(F(1)+F(1)+F(1,2)+F(1,6) == F(8,3))
check(F(1,2)+F(3,8) == F(7,8))
check(F(1,2)*F(3,8) == F(3,16))
# Conditioning Gibbs|A on an event of probability p gives D_init=1/p.
for numerator in range(1, 10):
    p = F(numerator,10)
    M = F(13,7)
    density = 1/(M*p)
    check(M*(M*p)*density*density == 1/p)

print(json.dumps({
    'status': 'PASS',
    'bound_source_files': file_checks,
    'exact_rational_algebra_checks': checks,
    'scope': 'source integrity and finite algebra regression only; analytical proof and actual-process receiving are in the theorem/audit documents',
    'not_claimed': ['executable clock receiver', 'physical preparation or control', 'arbitrary feedback', 'processed MFPT or iid restart', 'a second independent reviewer of V2']
}, indent=2, sort_keys=True))
