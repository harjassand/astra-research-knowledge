# Root extension: a paid nonequilibrium initial-law clock

Status: NEW, not independently reviewed. It extends the received energy equations, not arbitrary formal generators or a physical preparation claim.

Use the neutral-processing theorem's actual adjoint propagator and reference form. For a general initial vector u0=c0 e+x0 with x0 perpendicular to e, the hidden storage inequality now has right side ||x0||^2/2 + Re integral conjugate(c)y. Put C=||c||L2 and Y=||y||L2 on any finite horizon. Then

Y^2 <= sigma ||x0||^2/2 + sigma C Y,
Y <= sigma C + sqrt(sigma/2)||x0||,
C <= |c0|/sqrt(2a)+Y/a.

Consequently, using sigma=a-1/q,

sup_t |c(t)-c0 exp(-at)|
 <= (aq-1)|c0|/2 + sqrt((aq-1)aq)||x0||/2.

This is an ordinary storage/input estimate, with no global spectral gap. Actual evolution must receive the energy inequality for this initial vector too. Approximation from the form domain is allowed only when the received propagator's continuity supplies it.

For the same killed Markov model, let initial probability have density f relative to m, supported in A_set, and finite D=M||f||^2 >=1. Here D=1+chi-square(initial law || m(.|A_set)). Since h=1 on A_set, c0=1/sqrt(N) and N||x0||^2=N||f||^2-1 <=(1+rho)D-1.

Survival is <f,P(1_D)> = sqrt(N)c(t)+<f,P(1_D-h)>.
The latter nonnegative term is at most ||f|| sqrt(m(S))=sqrt(D rho), by common-measure contraction. Thus with epsilon,k0 from the current/trial certificate,

sup_t |Pr_f(tau_B>t)-exp(-k0 t)|
 <= (1/2+1/EulerNumber)epsilon
    + (1/2)sqrt(epsilon(1+epsilon)((1+rho)D-1))
    + sqrt(D rho).

No normalization replacement rho term is needed here because sqrt(N)c0=1 exactly. This is a sufficient absolute CDF bound. It is not a necessary mixing criterion or an unbounded mean estimate.

If the actual prepared distribution is within total variation delta of this reference initial distribution, every fixed deadline probability changes by at most delta. This step also accommodates singular finite-bit approximations when a genuine total-variation coupling exists; do NOT claim a discrete law is TV-close to a continuous density merely because coordinates are close. Finite-resolution observation equivalence needs a separate process/observable coupling.

Practical consequence to assess: exact equilibrium initialization is replaceable by an acquired finite D and optional paid TV approximation for bounded deadline observables. D must itself be justified; a fast equilibrium sampler, arbitrary retained exit state, angular mixing or an iid restart is NOT supplied. In particular a boundary-supported exit law usually has infinite D, so repeated-clock use still needs actual return/settling or another representation. An initial law restricted from Gibbs|A to an event of probability p has D=1/p; acquiring/producing that law and p remains charged.
