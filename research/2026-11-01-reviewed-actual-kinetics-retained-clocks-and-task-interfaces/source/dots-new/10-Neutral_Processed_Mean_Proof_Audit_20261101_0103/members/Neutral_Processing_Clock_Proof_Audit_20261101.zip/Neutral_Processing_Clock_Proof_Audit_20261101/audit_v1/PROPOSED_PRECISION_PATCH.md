# Suggested precision patch (source not modified)

These are defensive domain/chronology clarifications, not fixes to a false numerical inequality.

1. After introducing the weak equations, add:

   "On every finite horizon, require x in L2(0,T;D(E)), c locally absolutely continuous, y=-E(e,x), and the integrated hidden-storage inequality with x(0)=0. Interpret any neutral contractive jumps as nonpositive jumps of hidden storage, with c unchanged. The displayed differential inequality is shorthand for this received energy-solution statement."

2. Replace the broad standalone skew-generator sentence by:

   "For example, a common-domain form sum with a neutral skew term has (1) once its nonautonomous energy solution is received. Mere formal skewness or B_t e=0 does not itself establish a valid sum, a common weak domain, or global wellposedness. A genuinely dissipative additional term annihilating e and its dual is treated in the same received-energy sense."

3. At the start of the actual-process transfer, add:

   "Write P_{s,t} for the actual killed transition propagator on observables, and take u(t)=P_{0,t}^*e. Thus u'=L_t^*u; no time-order reversal or equation u'=L_tu for P_{0,t}e is being assumed."

4. Use "Euler's number" rather than "Euler's constant" in section 3, to avoid confusion with the Euler-Mascheroni constant. The numerical inequality already uses the correct number.

5. In the example paragraph, an actually received sufficient class can be named:

   "For the original whole-space model, c=(0,phi(y)psi(U(z))J grad U(z)) with smooth compact cutoffs is a bounded smooth weighted-divergence-free transverse drift. For measurable locally bounded predetermined amplitudes, the inherited proper Lyapunov function, common-domain antisymmetric form and invariant measure give a global positive L2-contracting process. No common strength or bandwidth cap enters the clock-error constant."

No blanket expansion to arbitrary unbounded mobility, arbitrary record feedback, or physical controls is proposed.
