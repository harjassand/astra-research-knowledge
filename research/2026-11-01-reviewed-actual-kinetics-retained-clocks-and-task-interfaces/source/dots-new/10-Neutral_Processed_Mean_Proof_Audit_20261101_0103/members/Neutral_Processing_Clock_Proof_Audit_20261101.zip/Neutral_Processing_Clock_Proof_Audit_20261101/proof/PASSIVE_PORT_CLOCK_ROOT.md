# A received clock survives neutral internal processing

Status: new root construction, independent review pending. Ordinary quadratic
forms, Schur complements and passive small-gain estimates are components; no
historical novelty or physical implementation claim is made. This is NOT an
extension of any already accepted executable interface.

## 1. Abstract reference and actual evolution

Let A be a positive injective self-adjoint killed generator on a Hilbert space,
with closed form E. Choose a real unit vector e in its form domain with

  a=E(e,e)>0,  q=||A^(-1/2)e||^2<infinity.

The spectrum may accumulate at zero. Let the ACTUAL adjoint evolution u(t),
initially e, have the same reference dissipative form plus internal processing.
Assume that processing fixes e on BOTH sides and is dissipative on Q=e^perp.
More explicitly, after u=c e+x, x perpendicular to e, the weak equations must
give

  c'=-a c+y,                 y=-E(e,x),
  (1/2)d||x||^2/dt <=-E(x,x)+Re(conj(c)y).             (1)

These identities are received assumptions about the full actual evolution,
not consequences of an arbitrary 'control' label. They hold for additional
skew-adjoint B_t with B_t e=0, and for additional dissipative generators which
annihilate e and whose adjoints also annihilate e. Time dependence may be
arbitrary provided the weak evolution and energy inequality actually exist.
No bound on the strength or time derivative of those neutral terms enters the
estimate. Contractive intervention maps preserving e and its dual leave c
unchanged and can only decrease ||x||; their execution/exposure still needs its
own actual model. Causal well-defined, non-Zeno propagation is required.

Define sigma as the squared dual-energy norm of x -> E(e,x) on Q. Then

  sigma = a-1/q,                 0<=sigma<a.            (2)

Indeed q^(-1)=inf_{<e,z>=1} E(z,z), by the energy Cauchy--Schwarz inequality and
resolvent approximation. Writing z=e+x gives the infimum a-sigma. This argument
uses the closed form/energy completion; it does not assume Ae or A^(-1)e are
ordinary Hilbert-space vectors. The finite inverse FORM q is enough.

## 2. Exact small-gain estimate

By definition |y|^2<=sigma E(x,x). Integrating (1), using x(0)=0 and nonnegative
terminal storage, gives on every finite time interval

  ||y||_(L2 time) <=sigma ||c||_(L2 time).

The scalar equation yields c(t)=exp(-at)+int_0^t exp[-a(t-s)]y(s)ds. Its
convolution has L2 gain1/a, and ||exp(-at)||_L2<=1/sqrt(2a). Since sigma<a,

  ||c||_L2 <=sqrt(a/2)/(a-sigma),
  sup_t |c(t)-exp(-at)| <=sigma/[2(a-sigma)]
                           =(a q-1)/2.                (3)

For sigma=0 the conclusion is exact and follows by continuity/directly. No
spectral mixture representation, stationary processing, global gap or
computable hidden-mode basis is used. The hidden-subspace decomposition is a
proof device, not an input oracle or a simulated trajectory.

## 3. Interface to the explicit trial/current clock certificate

Now use the finite reference measure m, killed domain D=A_set union S, and
explicit trial h from the separately reviewed trial/current construction.
Put M=m(A_set)>0, rho=m(S)/M, N=||h||^2 in[M,M(1+rho)], and e=h/sqrt(N).
Suppose the SYMMETRIC reference form receives

  E(h,h)<=C0,
  <h,A^(-1)h><=B_total,
  k0=C0/M,  epsilon=C0 B_total/M^2-1>=0.               (4)

B_total may be (sqrt(B_A)+sqrt(B_S))^2 from independently constructed source
currents. Then a<=k0, k0 q<=1+epsilon, a q-1<=epsilon, and
k0/a-1<=epsilon. The mean-value exponential bound and (3) give

  sup_t |<e,u(t)>-exp(-k0 t)|
       <=(1/2+1/euler_number)epsilon <(7/8)epsilon.     (5)

Here the e in 'euler_number' is Euler's constant, not the unit trial vector.
The looser epsilon bound is therefore also valid. Using a numerical interval
for k0 requires the separately paid midpoint/envelope correction as before.

Suppose additionally the actual killed evolution is positive and L2-contracting
with respect to this SAME measure m. For exact initial law m(.|A_set), the
positive-semigroup initial-law argument is unchanged even with time dependence:
h-1_A and1_D-h are nonnegative and supported in S. It gives

  sup_t |P_actual(tau_B>t)-exp(-k0 t)|
     <=(7/8)epsilon +rho+sqrt(rho(1+rho)).              (6)

This is uniform ABSOLUTE CDF/survival accuracy. It supplies neither relative
extreme-tail accuracy, an exponential moment, nor an unbounded mean-time bound
for an arbitrary time-dependent controlled process. The existing reversible
MFPT theorem must not be silently transferred merely from (6).

## 4. Concrete neutral operations to receive, not assume

For the present Langevin models h depends only on y. A smooth transverse
circulation c_t with c_y=0 and div(m c_t)=0 annihilates h and its adjoint and
is skew in L2(m). In particular a transverse Hamiltonian field
c_t(y,z)=s(t) J grad_z F(y,z), J constant skew, preserves F and volume.
Its strength may vary in time. Actual global SDE existence/conservativity and
the common-measure energy inequality still need a proof; they are not inferred
from formal skewness alone. A simple finite-dimensional bounded-domain or
compactly supported smooth version supplies a conventional concrete test class.

Additional reversible transverse diffusion or jump updates can also fit if
they preserve the same m, fix h on both sides, are dissipative, and have an
actually received global process. State-dependent reversible diffusion needs
its divergence drift; arbitrary unbounded mobility is NOT admitted by finite
Gibbs mass alone. The known exploding atan-coordinate counterexample remains.

This does NOT automatically admit measurement-conditioned feedback. Each
branch preserving m separately is not enough after a source-dependent record
selects that branch. A joint source/controller model must earn (1), positivity
and the common-measure contraction, or the theorem does not apply. Predetermined
time-dependent protocols and independent external random mixtures can be
received without that extra feedback claim.

Neutrality is a mathematical, task-specific condition, not zero thermodynamic
work or free hardware. Port acquisition, calibration, actual controls, all
waiting/switching/readout exposure and release remain physical obligations.
No automatic quantum all-selected fault theorem follows from this classical
clock correlation/survival result.
