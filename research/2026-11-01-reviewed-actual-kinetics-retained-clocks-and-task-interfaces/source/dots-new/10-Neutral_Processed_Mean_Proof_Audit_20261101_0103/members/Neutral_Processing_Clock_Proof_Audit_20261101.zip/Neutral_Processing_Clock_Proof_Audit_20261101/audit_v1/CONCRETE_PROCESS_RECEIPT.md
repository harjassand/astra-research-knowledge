# A genuine whole-space neutral-stirring test class

This construction applies to the already received constant-SPD reference process, not a newly engineered mobility. It is a mathematical receiving example, not physical actuation.

## Data and explicit drift

Use the reference F(y,z)=v(y)U(z), v(y)=1+kappa(1-y^2)^2, positive coercive smooth homogeneous U of degree p, fixed SPD M_z>=mu I, beta>0. In the admitted quartic interface p=4 and dimension m>=16. Let J be any constant real skew m-by-m matrix. Choose phi in C_c^infinity(R) and psi in C_c^infinity(R), and put

  chi(y,z)=phi(y)psi(U(z)),
  c(y,z)=(0,chi(y,z) J grad U(z)).

Coercivity of U implies c has compact support in (y,z). It is smooth, bounded and globally Lipschitz. Taking phi, psi nonzero on an open region and a nonzero J gives nontrivial stirring.

Let s:[0,infinity)->R be predetermined, measurable and in L_infinity on each finite interval. There is no fixed numerical cap on its magnitude or oscillation rate and no derivative hypothesis. Consider the ACTUAL SDE

  dY=-v'(Y)U(Z)dt + sqrt(2/beta)dW,
  dZ=[-v(Y)M_z grad U(Z)+s(t)chi(Y,Z)J grad U(Z)]dt
                                        +sqrt(2M_z/beta)dB.

Kill at Y=b and use the same finite Gibbs measure m proportional to exp(-beta F) as reference. The unnormalized version is equally valid.

## Neutrality and boundary compatibility

Since J is skew,

  grad U dot J grad U=0,
  div_z(J grad U)=trace(J Hess U)=0,
  grad_z chi dot J grad U=0.

Therefore div_z c_z=0 and c dot grad F=0, so div(m c)=0. Also c_y=0, so c is tangent to every level set of y and in particular to the killing boundary. For every scalar trial h(y), C h=0, where C=c dot grad. Integration by parts, with no boundary flux and no infinity boundary term because c is compactly supported, gives C^*=-C in L2(m) at the form level. Hence C h=C^*h=0. The same statement applies to the piecewise-smooth killed-form trial h used by the source certificate: it has no transverse weak derivative.

## Global pathwise process

The original smooth drift is locally Lipschitz. Adding s(t)c preserves local existence and pathwise uniqueness on finite intervals, using time-measurable locally bounded coefficients and the usual local spatial Lipschitz estimates. The inherited proper function

  V(y,z)=1+y^2+K z^T M_z^(-1)z,  K=1+kappa/p,

obeys L0 V<=C0:=2(1+Km)/beta in the reference proof. As c is compactly supported,

  D:=sup |c dot grad V|<infinity,
  L_t V<=C0+D|s(t)|.

Apply Ito's formula stopped on {V<R}. For every finite T,

  E V(X_{T wedge tau_R}) <= V(X_0)+C0 T+D int_0^T|s(t)|dt.

Thus P(tau_R<=T)<=the displayed finite numerator/R. Letting R->infinity proves nonexplosion on every finite horizon. The received exact Gibbs basin law has finite V moment in the admitted alpha>=4 quartic regime; alternatively the point-start nonexplosion result extends to any probability mixture of finite points without needing that moment. Killing cannot create explosion.

## Common-measure and weak-energy receiving

For the full process, each frozen-amplitude generator L0+sC has invariant m: integration by parts gives integral L0 f dm=integral C f dm=0, and the conservative smooth diffusion is the unique martingale/Fokker-Planck evolution. For time-dependent s, the same m is a stationary weak Fokker-Planck solution; uniqueness yields preservation. Equivalently one can approximate s in L1 on finite intervals by bounded step protocols, each preserving m, and use stopped SDE stability plus the uniform Lyapunov bound to pass to the limit. The stopping/localization estimates here are uniform under an L1 bound on the approximating amplitudes.

The killed transition operator P_{r,t} is positive and sub-Markov. Jensen, domination by the full process and common m preservation give

  int |P_{r,t}f|^2 dm <= int P_full_{r,t}(|f|^2) dm = int |f|^2 dm.

This is actual L2 contraction, not an assertion inferred from a formal label.

Let V_form be the reference killed form domain with norm (||f||_2^2+E(f,f))^(1/2). The transverse form satisfies

  |<f,Cg>| <= ||c||_infinity sqrt(beta/mu) ||f||_2 sqrt(E(g,g)).

It is therefore bounded on the SAME form domain, locally uniformly in time after multiplication by s(t), and is antisymmetric. The nonautonomous form for the adjoint equation has real part exactly E. Standard variational construction (or bounded step-form approximation with its uniform energy estimates) gives the weak forward-density solution u=P_{0,t}^*e with u in L2(0,T;V_form) and

  (1/2)d||u||_2^2/dt <= -E(u,u).

Testing against e is valid because e lies in V_form and C e=0. Consequently c0(t)=<e,u(t)> obeys c0'=-a c0-E(e,x), x=u-c0 e. Subtracting the exact scalar energy identity from the full energy inequality gives

  (1/2)d||x||_2^2/dt <=-E(x,x)+Re(conjugate(c0)y),
  y=-E(e,x).

These are precisely the root's received port assumptions. All constants in this process-existence argument may depend on the finite-horizon amplitude norm; the clock-error estimate does not.

## Nontriviality and limitations

This need not be a symmetry that leaves every reduced dynamic unchanged. For U=z1^4+2z2^4+sum_{i>=3}zi^4 and J acting in the first two coordinates as J(a,b)=(-b,a),

  (J grad U) dot grad |grad U|^2
    =768 z1^3 z2^3(-z1^2+2z2^2),

which is generally nonzero. Thus the circulation moves along U-level sets while changing coefficients that govern the subsequent U dynamics. It does not automatically reduce to an irrelevant rigid rotation, although no claim about the sign or size of the actual survival change is needed.

The reference source-current certificates, trial h and inverse form q remain those of A, not certificates for a new symmetric generator. The actual process is now nonreversible/time-inhomogeneous. Only the clock result transfers by the port theorem; the old reversible MFPT theorem is not asserted for this new process.

Predetermined measurable schedules are included. An independent random schedule can be conditioned on and then averaged, provided its paths meet the receiving conditions. Source-dependent selection is not included by that conditioning argument. Hardware execution and any finite exposure obligations remain outside this mathematical example.
