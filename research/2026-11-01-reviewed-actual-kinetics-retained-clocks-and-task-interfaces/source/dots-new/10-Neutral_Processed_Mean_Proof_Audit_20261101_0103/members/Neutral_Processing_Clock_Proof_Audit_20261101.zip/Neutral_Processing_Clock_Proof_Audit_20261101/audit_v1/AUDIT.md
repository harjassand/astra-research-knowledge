# Independent audit: neutral processing and the actual exit-time clock

Date: 2026-11-01 UTC. Reviewer: independent process/domain audit agent.

## Verdict and exact scope

**PASS as a conditional mathematical theorem, with a requested precision patch, not a new executable or physical receiving.** I found no counterexample to the Schur identity, small-gain estimate, normalization, or positive-propagator initial-law transfer under the displayed received assumptions. In particular, absence of a global spectral gap is not a defect. The common weak domain and chronological adjoint evolution should be stated explicitly to prevent incorrect downstream use.

Reviewed immutable source:
`neutral_processing_clock_pending_20261101/PASSIVE_PORT_CLOCK_ROOT.md`
SHA-256 `487a37d2d7d0c15ee756ccda3717bb47c5bd9aa4b1e0bec5ea7201c435950a6d`.

The conclusion is uniform **absolute** survival/CDF accuracy for the exact common-measure basin law, provided an actual positive L2-contracting killed propagator earns the weak identities. It is not arbitrary feedback robustness, a mean-time theorem for the processed process, a relative-tail theorem, a physical preparation/control guarantee, or a quantum-fault claim. Historical novelty remains unresolved. Ordinary Schur complements, energy-space projections, neutral dissipative control, and passive small-gain arguments deserve full prior credit.

## 1. Infinite-dimensional Schur identity

Let V=D(A^(1/2)) and equip V with the energy inner product. Since A is injective this is a norm, although V need not be complete in that norm. Write H_E for its completion. Finite q=||A^(-1/2)e||^2 makes ell(z)=<e,z> a bounded functional on H_E, with norm sqrt(q). The equality of the norm follows either from the spectral theorem or the resolvent approximants z_delta=(A+delta)^(-1)e. They satisfy

- <e,z_delta> -> q;
- E(z_delta,z_delta)=int lambda/(lambda+delta)^2 dmu_e(lambda) -> q;

by monotone/dominated convergence using int lambda^(-1) dmu_e=q<infinity. Thus inf_{ell(z)=1} E(z,z)=1/q. Approximants can be normalized to satisfy the constraint exactly.

The closure in H_E of Q intersect V equals ker ell: if z_n -> z in energy and ell(z)=0, then x_n=z_n-ell(z_n)e lies in Q intersect V and converges to z in energy. Therefore the functional x -> E(e,x), restricted to Q intersect V, has squared dual norm equal to the energy norm squared of the energy-orthogonal projection of e onto ker ell. The complementary squared norm is 1/q because ell(e)=1. Hence sigma=a-1/q. No use of Ae in H or A^(-1)e in H occurs.

This also proves aq>=1 and 0<=sigma<a. A zero spectral gap is harmless here; the finite inverse FORM is precisely the continuity assumption the constraint needs.

## 2. Weak evolution and time ordering

A safe explicit solution class is x in L2(0,T;V), c locally absolutely continuous, x(0)=0, c(0)=1, with y=-E(e,x), scalar equation c'=-ac+y a.e., and the integrated hidden-storage inequality

  (1/2)||x(T)||^2 + int_0^T E(x,x) <= Re int_0^T conjugate(c)y

for all admissible terminal times (then by the solution's trace/continuity convention for all times). These requirements eliminate purely formal applications with incompatible operator domains. Neutral contractive jumps may be included by retaining their downward storage jumps; c does not jump.

For a nonautonomous Markov process, define P_{s,t}f(x)=E[f(X_t)1_{tau>t} | X_s=x]. Then P_{0,t} differentiates on its RIGHT: partial_t P_{0,t}=P_{0,t}L_t on its natural test class. Consequently u(t)=P_{0,t}^*e satisfies u'=L_t^*u, with u(0)=e. The scalar correlation is <e,P_{0,t}^*e>=<e,P_{0,t}e> in the real setting. Evolving an observable by u'=L_tu would generally put time-dependent generators in the wrong order. The root's word 'adjoint' is correct, but this explicit definition should be retained in any consumer.

The blanket sentence about skew-adjoint B_t is sound only inside the root's explicitly received common weak evolution/energy premise. B_t e=0 plus formal skewness is not itself an existence theorem, nor does it automatically justify the form sum for unbounded B_t.

## 3. Small-gain calculation, independently checked

For sigma>0, |y|^2<=sigma E(x,x). On [0,T] the integrated storage inequality gives

  Y_T^2/sigma <= int E(x,x) <= C_T Y_T,

where C_T=||c||_2 and Y_T=||y||_2. Hence Y_T<=sigma C_T, including the Y_T=0 case. The scalar variation-of-constants formula and the causal kernel exp(-at) give

  C_T <= 1/sqrt(2a) + Y_T/a,
  C_T <= sqrt(a/2)/(a-sigma),
  sup_{0<=t<=T}|c(t)-exp(-at)| <= Y_T/sqrt(2a)
                                      <=sigma/[2(a-sigma)].

No infinite-time integrability was assumed to prove these bounds; every estimate is first finite-horizon. Letting T increase proves the advertised uniform result and the L2 bound. Sigma=0 forces y=0 a.e. and exact c=exp(-at). The feedback port constants and the factor 1/2 are correct.

## 4. Certificate normalization and survival transfer

With N in [M,M(1+rho)], a=E(h,h)/N and q=<h,A^-1h>/N,

  a<=C0/N<=k0,
  k0 q<=C0 B_total/(MN)<=(1+epsilon),
  aq-1<=epsilon,
  k0/a<=k0q<=1+epsilon,

where aq>=1 is used in the last line. Thus epsilon>=0 is earned, and
sup_t|exp(-at)-exp(-k0t)| <= (k0/a-1)/e <=epsilon/e.
Together with the small-gain bound this gives (1/2+1/e)epsilon<7epsilon/8. Euler's number, rather than the Euler-Mascheroni constant, is intended.

For any positive L2(m)-contracting P=P_{0,t}, put r=h-1_A and d=1_D-h. The exact identity is

  <1_A,P1_D>-<h,Ph> = <1_A,Pd>-<r,Ph>.

Both terms on the right are nonnegative. Their respective upper bounds are sqrt(M m(S)) and sqrt(N m(S)), so the absolute difference is at most sqrt(N m(S)), NOT their sum. Since 0<=<h,Ph>/N<=1, replacing the N normalization by M contributes at most rho. This reproduces rho+sqrt(rho(1+rho)) without self-adjointness or stationarity. The finite measure must be the SAME m as in the reference certificate and the actual contraction.

## 5. Actually received transverse processing

The accompanying `CONCRETE_PROCESS_RECEIPT.md` gives smooth compactly supported transverse stirring on the original whole-space constant-SPD model, not merely a bounded-domain replacement. For any locally essentially bounded measurable predetermined amplitude s(t), it supplies:

- explicit smooth bounded spatial drift and tangency to the killing boundary;
- exact weighted-divergence neutrality and annihilation of h on both sides;
- a proper inherited Lyapunov function proving global nonexplosion;
- common-domain variational energy receiving and positivity;
- common-measure contraction and the correctly ordered adjoint equation.

There is no common numerical bound on amplitude, frequency, or derivative in the clock error. Local boundedness is a sufficient actual-process receiving assumption for this example, not a necessary extra hypothesis of the abstract theorem. Unbounded globally growing amplitudes are allowed if bounded on each finite interval. Extension to amplitudes merely in L1_loc is plausible by approximation and Lyapunov estimates, but not claimed here without spelling out that extra convergence proof.

## 6. Remaining gaps and exclusions

1. The frozen root is not an executable receiver for arbitrary descriptions of B_t; it conditions on equations (1), positivity, contraction and actual global process validity.
2. Formal skewness, finite Gibbs mass, or pointwise annihilation of h do not on their own supply those premises for arbitrary unbounded operators/mobilities.
3. State-dependent record selection can destroy weighted divergence or common-measure preservation. Branchwise invariance is not a feedback theorem. Any controller must earn a joint-state receiving.
4. Uniform absolute survival control does not bound the processed mean; no MFPT transfer should be made.
5. No physical implementation, exposure budget, preparation accuracy, apparatus or calibration was received by this audit.
6. No empirical simulation is needed for the analytical bounds, and no finite-dimensional numerical stress test would establish the infinite-dimensional domain claims.

No frozen source was modified. Separate suggested wording is in `PROPOSED_PRECISION_PATCH.md`.
