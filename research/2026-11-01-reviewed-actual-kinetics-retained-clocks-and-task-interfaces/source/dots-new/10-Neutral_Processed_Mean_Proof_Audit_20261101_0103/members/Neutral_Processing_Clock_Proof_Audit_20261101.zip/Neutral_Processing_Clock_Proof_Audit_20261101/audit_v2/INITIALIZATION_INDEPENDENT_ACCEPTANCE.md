# Independent acceptance: paid nonequilibrium initialization

Date: 2026-11-01 UTC. Verdict: **PASS, conditional theorem only.**

This is an independent review of the parent's NEW derivation, not a claim that
the reviewer independently authored it. Reviewed source:
`NON_EQUILIBRIUM_INITIALIZATION_ROOT.md`, SHA-256
`2accda82d25a2a14f357f2cd8ef28eda0be91a9fb457f31cdb9115e90aa627ff`.
The source remains unchanged. It is accepted as a separate extension, not as
retroactive physical preparation or executable receiving.

## Full assumptions required by the accepted extension

Use the positive injective self-adjoint reference form A, unit trial e in its
form domain, a=E(e,e)>0, q=||A^(-1/2)e||^2<infinity, and
sigma=a-1/q from the neutral-processing theorem. For a general H initial vector
u0=c0 e+x0, x0 perpendicular to e, the ACTUAL evolution must additionally earn,
on every finite horizon, x in L2(0,T;D(E)), c absolutely continuous,
y=-E(e,x), c'=-ac+y, and

  (1/2)||x(T)||^2 + int_0^T E(x,x)
    <= (1/2)||x0||^2 + Re int_0^T conjugate(c)y.

This receiving is not inferred just because the evolution was received for the
single initial vector e. Initial x0 need only lie in H, not D(E). In the
concrete common-domain variational process of the consolidated V2, the energy
solution exists for every H initial vector and supplies the required trace.
If one uses form-domain approximation, H continuity identifies the initial
trace/propagator limit; uniform energy estimates and lower semicontinuity are
also what pass the energy inequality. Continuity alone is not a new general
form-domain theorem.

## Independent port calculation

Write X=||x0||, C=||c||_{L2(0,T)}, Y=||y||_{L2(0,T)}. For sigma>0,

  Y^2 <= sigma X^2/2 + sigma C Y.

The positive-root formula or sqrt(v^2+w^2)<=v+w gives

  Y <= sigma C + sqrt(sigma/2) X.

Variation of constants gives C<=|c0|/sqrt(2a)+Y/a. Hence

  Y <= [sigma |c0|/sqrt(2a)+sqrt(sigma/2)X]/(1-sigma/a).

The output convolution has pointwise norm at most Y/sqrt(2a), proving

  sup_t |c(t)-c0 exp(-at)|
    <= sigma|c0|/[2(a-sigma)] + sqrt(a sigma)X/[2(a-sigma)]
     = (aq-1)|c0|/2 + sqrt((aq-1)aq)X/2.

Sigma=0 yields y=0 and the exact scalar law, regardless of hidden initial
storage. The result is finite-horizon first and then uniform in T; it does not
assume a gap or infinite-time integrability.

## Independent probability and normalization calculation

Let the ACTUAL killed transition propagator P=P_{0,t} be positive and
L2(m)-contracting for the same m as the reference certificate. The correct
initial evolution is now u(t)=P_{0,t}^*f, NOT P_{0,t}^*e. Here f>=0,
int f dm=1, f vanishes outside A_set, and f belongs to L2(m). Write

  D_init=M||f||^2 >=1,
  D_init=1+chi_square(initial law || m(.|A_set)).

This scalar is the source's D; it should not be confused with the killed domain
also often denoted D. Since h=1 on A_set, c0=<e,f>=1/sqrt(N), and

  N||x0||^2 = N||f||^2-1 <= (1+rho)D_init-1.

For d=1_D-h>=0 supported in S,

  Pr_f(tau_B>t) = sqrt(N)c(t)+<f,Pd>,
  0<=<f,Pd><=||f||sqrt(m(S))=sqrt(D_init rho).

The exact identity sqrt(N)c0=1 eliminates the previous rho normalization
replacement term. From aq-1<=epsilon, aq<=1+epsilon, and the separately proved
rate mismatch at most epsilon/exp(1), one obtains precisely

  sup_t |Pr_f(tau_B>t)-exp(-k0t)|
    <= (1/2+1/exp(1))epsilon
       +(1/2)sqrt(epsilon(1+epsilon)((1+rho)D_init-1))
       +sqrt(D_init rho).

All square-root arguments are nonnegative. This is a sufficient uniform
ABSOLUTE CDF/survival bound, not a necessary equilibrium/mixing criterion.
There is no hidden self-adjointness assumption on P and no reversal of the
nonautonomous chronology.

## TV, preparation and repeated-use scope

Using total variation as sup_E|mu(E)-nu(E)|, any fixed [0,1]-valued deadline
kernel differs by at most TV(mu,nu). Thus a separately earned TV error delta
adds delta, uniformly over deadlines for the SAME actual process. A purely
atomic finite-bit distribution and an absolutely continuous Gibbs density are
mutually singular and have TV=1: mere coordinate proximity cannot buy a small
TV correction. The source explicitly warns against that invalid step.

The example conditioned from Gibbs|A onto an event of positive probability p
has density 1_E/(Mp), and therefore D_init=1/p exactly. Producing the law and
acquiring p are separate tasks. Singular boundary exit laws generally do not
have finite D_init. No iid restart, arbitrary retained exit state, angular
sampler, physical preparation, mean-time transfer or exponential-moment claim
is accepted. As in the base theorem, arbitrary measurement-conditioned feedback
must separately earn a joint actual-process receiving.

The new theorem is ordinary storage/input-output mathematics. It can replace
exact Gibbs initialization for bounded deadline observables when a finite,
useful D_init is genuinely acquired; it does not make that acquisition free.
