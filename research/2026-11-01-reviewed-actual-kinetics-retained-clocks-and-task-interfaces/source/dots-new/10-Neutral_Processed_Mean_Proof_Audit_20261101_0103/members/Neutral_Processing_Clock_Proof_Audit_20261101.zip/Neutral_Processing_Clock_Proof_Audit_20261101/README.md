# Neutral-processing clock: current proof and audit

**Local proof/audit package — no upload, executable receiver, or physical
control/preparation claim.**

## Read these current documents

1. `proof/PASSIVE_PORT_CLOCK_ROOT_V2.md`: the complete current theorem/proof,
   including explicit weak domains, chronological adjoint evolution and a
   genuinely received compact transverse-stirring class on the original
   whole-space constant-SPD model. No patch reconstruction is necessary.
2. `audit_v2/V2_EXACT_SOURCE_RECHECK.md`: precise source binding and recheck.
3. `proof/NON_EQUILIBRIUM_INITIALIZATION_ROOT.md` and
   `audit_v2/INITIALIZATION_INDEPENDENT_ACCEPTANCE.md`: separately accepted
   extension for an acquired L2 initial density with finite concentration cost.

For the base theorem, a positive self-adjoint reference killed form A and unit
trial e give a=E(e,e), q=||A^(-1/2)e||^2. Neutral actual processing is allowed
only after it earns the stated weak scalar/storage equations. The energy-space
Schur identity sigma=a-1/q and passive small gain yield

    sup_t |<e,P_{0,t}^*e>-exp(-at)| <= (aq-1)/2.

The reference trial/current certificate then gives, for the exact common-measure
basin law, an absolute survival error at most

    (7/8)epsilon +rho+sqrt(rho(1+rho)).

No global spectral gap or numerical processing-bandwidth bound enters that
error. Actual process existence, positivity and same-measure contraction are
separate earned premises, not consequences of a neutral-control label.

The independently accepted initialization extension instead uses f supported
in the basin and D_init=M||f||^2=1+chi_square(f || Gibbs|A). Its bound is

    (1/2+1/exp(1))epsilon
      +(1/2)sqrt(epsilon(1+epsilon)((1+rho)D_init-1))
      +sqrt(D_init rho).

It requires energy receiving for that initial f. Acquiring/preparing f or its
D_init is not supplied. Paid TV error can be added for bounded deadlines, but
coordinate closeness does not make a discrete preparation TV-close to a
continuous density.

## Explicit limits

These are conditional mathematical absolute-CDF theorems, **not** processed
MFPT or relative-extreme-tail bounds, an equilibrium sampler, physical
controls/calibration, arbitrary record-feedback robustness, iid restarts,
quantum-fault claims, historical novelty claims, or a newly accepted
executable interface. Ordinary Schur, energy-projection, neutral-control and
passivity explanations receive full credit.

## Provenance and reviewer roles

- `proof/PASSIVE_PORT_CLOCK_ROOT.md` is the unchanged original root.
- `audit_v1/` contains its independent audit, process receipt and proposed
  clarifications.
- V2 was consolidated by that independent reviewer. Its V2 exact-source
  recheck is explicitly NOT mislabeled as a new second-author review.
- The parent's newly authored initialization extension received a separate
  independent source-bound review.
- `background/` preserves the three reference documents used for model/current
  provenance. They are not changes to the actual process or executable scope.
- `PROVENANCE.json` binds originals and package copies; `SHA256SUMS` covers all
  package files except itself.

## Reproduce the non-executable checks

From this directory:

    python check_integrity_and_algebra.py
    sha256sum -c SHA256SUMS

The Python script uses only the standard library. It verifies bound source
bytes and performs 7,492 exact rational algebra regressions. These tests do not
replace the analytical infinite-dimensional/process proofs. The package has no
nested archives. The external ZIP verification receipt records CRC, complete
extraction, manifest replay and the unchanged results from the extracted copy.
