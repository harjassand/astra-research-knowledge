# Reviewed autonomous radial-gain mean hitting-time receiver

This local package contains the newly received autonomous Gibbs|A mean first-passage proof/receiver, and unchanged accepted kinetic-lift dependency with its correction/prior-overlap history. Read the source-bound whole-review receipt before historic candidate status strings.

The actual model has a declared engineered radial mobility gain and tangent diffusion. The observable is an autonomous mean, not capacity inversion or clamped terminal CDF. Exact initialization is required. Approximate finite-bit sampling, physical parameters/actuation, and the original constant-mobility model are NOT authenticated. The separate later constant-SPD extension is deliberately excluded.

Run python -B PACKAGE_REPLAY.py from this extracted root for one small receiving replay with the original external task reconstructed literally. Full tests are in autonomous_radial_mfpt_20261031; SymPy and mpmath diagnostics are separate from the standard-library producer. No upload was performed.
