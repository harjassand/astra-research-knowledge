# Independent audit: mixed U/identity-slot all-resource strong upper

23 October 2026, w36. ENTIRE source read:
`work/root/ALL_RESOURCE_SOFT_BETA_STRONG_CONVERSE_CANDIDATE.md`, SHA256 **768852a9283399e92ed0d41f858646d1749128e9ba03d8a82c891dfd33db9d0e**.

**No blocking defect found conditional on the separately independently reconstructed beta-zero sector theorem.** The same mixed-slot formula was reconstructed through own weighted teleportation BEFORE reading this source. This is an internal proof audit, not priority, achievability, external certification or a physical result. No new numerical tests are claimed here.

Fix a designated pattern of n U-slots and s direct identity qutrit slots, n+s=N. Count incoming/outgoing colored charges only on U-slots. The per-U zero colored/colored block gives q+o<=n, including its physical root00 action. There is no such support restriction on the designated identity slots. At either communication cut those unrestricted slots contribute a dimension factor3^s to the charge-sector vector, hence9^s in CP order. The fixed correlated replacer can be prepared independently and delivered in the designated chronological order; no physical pattern flag or bath intervention is added.

An independent literal weighted-teleport check gives the same cost. Use p0=pc=1/3 at every direct slot, so each success operator is I/3. Use the optimized constant p on only the U-slots and select their aggregate input/output charges. The all-success branch is multiplied by3^-s times the fixed-sector filter factor. The completed comparison still has NO forward wire, so its unnormalized Bell branch is<=K^-2. Both cuts therefore yield

    F_pattern<=M_n^2 9^s 8^n/K^2.

The same original local maps, memory, initial entanglement, quantum feedback and decoder occur in EVERY designated pattern. Purify that fixed strategy. Each chronological V=alpha U+i beta I insertion is linear, so the actual final vector is exactly the coherent sum over masks with coefficient alpha^n(i beta)^s. Apply the Bell projector first and then the Hilbert norm triangle inequality. Since M_n<=M_N,

    sqrt(F_beta)
      <=(M_N/K) sum_s binom(N,s)(sqrt8 alpha)^(N-s)(3beta)^s
      =(M_N/K)(sqrt8 sqrt(1-beta^2)+3beta)^N.

Thus the source's finite-N inequality is correct. Absolute values make beta>=0 explicit; the alternating i phases are discarded only in a safe upper. There is no stochastic-mixture or orthogonality assumption. Every pattern is itself a legitimate fixed-interface circuit used for an upper-bound comparison; no party observes it in the physical protocol.

The resulting all-resource strong threshold is

    R_soft(beta)=log2[sqrt8 sqrt(1-beta^2)+3beta].

It recovers3/2 at beta0 and is only linear near zero. It improves the qutrit dimension ceiling EXACTLY for0<=beta<1/17: for beta<1, squaring the equivalent positive inequality sqrt8 sqrt(1-beta^2)<3(1-beta) reduces to(1-beta)(1-17beta)>0. In particular the pinned small-beta interval beta<=1/32 lies inside this range. At beta1 the gate is the identity and the dimension ceiling is recovered; no strict deficit there is claimed.

The quadratic weak converse from the correlation-loss theorem remains a distinct, smaller reliable-rate bound. It does not imply fidelity tends to zero at that smaller threshold. Retaining the coherent physical phase or another causal moment structure to obtain a quadratic all-resource strong threshold remains OPEN. This audit does not assert it.

Initial resources may be arbitrary normal N-dependent E:whole-lab entangled states, but the fresh Bell source must be product with the ENTIRE resource. Only N prescribed forward qutrit calls, backward assistance and unconditional TP decoding are allowed. Normal strategy limits are inherited from the beta0 theorem and bounded finite mask sum for each fixed N. Variable stopping, extra forward classical/timing carriers and postselected normalization would change the model. All hardware, state acquisition, precision, reset, bandwidth, energy and useful-code questions remain unacquired. Generic tools established; narrow priority UNKNOWN; mission NOT_ACHIEVED.
