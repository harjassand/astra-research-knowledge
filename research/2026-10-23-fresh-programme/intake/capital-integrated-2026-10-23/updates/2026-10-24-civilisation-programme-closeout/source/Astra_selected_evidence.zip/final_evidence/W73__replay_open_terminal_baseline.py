"""No-import finite exact controls and causal synthetic open-port baseline.

The floating circuit, iid sensor law and settled actions are stipulated.
No measurement, leakage, capacitance or hardware validation is performed.
"""

from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import json
import math
import numpy as np

ROOT = Path(__file__).resolve().parent
assertions = 0


def check(condition):
    global assertions
    assertions += 1
    assert condition


def inverse(A):
    n = len(A)
    B = [row[:] + [F(i == j) for j in range(n)] for i, row in enumerate(A)]
    for j in range(n):
        k = next(i for i in range(j, n) if B[i][j])
        B[j], B[k] = B[k], B[j]
        z = B[j][j]
        B[j] = [x / z for x in B[j]]
        for i in range(n):
            if i != j:
                z = B[i][j]
                B[i] = [x - z * y for x, y in zip(B[i], B[j])]
    return [row[n:] for row in B]


def graph(d, theta, profile):
    n = 2 * d + 2
    adj = [[] for _ in range(n)]
    for h, leaves in ((0, range(2, d + 2)), (1, range(d + 2, n))):
        for j, l in enumerate(leaves):
            w = F(1 if profile == 0 else 1 + (j + h) % 3)
            adj[h].append((l, w))
            adj[l].append((h, w))
    if theta:
        adj[0].append((1, F(1)))
        adj[1].append((0, F(1)))
    return adj


def reachable(adj, p):
    seen, stack = {p}, [p]
    while stack:
        for j, _ in adj[stack.pop()]:
            if j not in seen:
                seen.add(j)
                stack.append(j)
    return sorted(seen)


def path_resistance(adj, p, q):
    stack = [(p, -1, F(0))]
    while stack:
        i, parent, resistance = stack.pop()
        if i == q:
            return resistance
        for j, w in adj[i]:
            if j != parent:
                stack.append((j, i, resistance + 1 / w))
    return None


def full_nodal_port_means(adj, p, q, r, amplitude):
    """Direct full circuit inversions, without the series-path formula."""
    means = [F(0)] * len(adj)
    completed = set()
    for terminal in (p, q):
        if terminal in completed:
            continue
        nodes = reachable(adj, terminal)
        completed.update(nodes)
        index = {v: i for i, v in enumerate(nodes)}
        K = [[F(0)] * len(nodes) for _ in nodes]
        rhs = [F(0)] * len(nodes)
        for v in nodes:
            i = index[v]
            K[i][i] = sum(w for _, w in adj[v])
            for z, w in adj[v]:
                K[i][index[z]] -= w
            if v in (p, q):
                K[i][i] += 1 / r
                rhs[i] = (amplitude if v == p else F(0)) / r
        Ki = inverse(K)
        potentials = [sum(x * y for x, y in zip(row, rhs)) for row in Ki]
        for v in nodes:
            if v in (p, q):
                means[v] = ((amplitude if v == p else F(0)) - potentials[index[v]]) / r
    return means


exact_circuit_cases = 0
for d in (1, 2, 3):
    n, a, amplitude, r = 2 * d + 2, F(1), F(1, 2), F(1, 128)
    lower = amplitude * a / (3 + 2 * a * r)
    for theta in (0, 1):
        for profile in (0, 1):
            adj = graph(d, theta, profile)
            for p in range(n):
                for q in range(n):
                    if p == q:
                        continue
                    resistance = path_resistance(adj, p, q)
                    predicted = F(0) if resistance is None else amplitude / (2 * r + resistance)
                    actual = full_nodal_port_means(adj, p, q, r, amplitude)
                    check(actual[p] == predicted and actual[q] == -predicted)
                    check(all(z == 0 for j, z in enumerate(actual) if j not in (p, q)))
                    check(sum(actual) == 0)
                    check(predicted == 0 or predicted >= lower)
                    check(0 <= predicted <= 3 * a * amplitude)
                    check(amplitude * predicted <= 3 * a * amplitude * amplitude)
                    exact_circuit_cases += 1

# Exact finite-bit pair-law lower, over every balanced partition up to n=10.
exact_sampler_partitions = 0
for n in (4, 6, 8, 10):
    N = n * (n - 1)
    b = (N - 1).bit_length()
    M = 1 << b
    counts = [M // N + int(j < M % N) for j in range(N)]
    check(sum(counts) == M)
    for U in combinations(range(n), n // 2):
        U = set(U)
        cross = 0
        for j, c in enumerate(counts):
            p, h = divmod(j, n - 1)
            q = h + int(h >= p)
            if (p in U) != (q in U):
                cross += c
        check(F(cross, M) >= F(1, 4))
        exact_sampler_partitions += 1


class SyntheticOpenPlant:
    def __init__(self, n, a, r0, A, sigma, delta, theta, seed):
        self.n, self.a, self.r0, self.A = n, a, r0, A
        self.sigma, self.theta = sigma, theta
        rng = np.random.default_rng(seed)
        labels = rng.permutation(n)
        self.hubs = labels[:2]
        self.groups = (labels[2:2 + (n - 2) // 2], labels[2 + (n - 2) // 2:])
        self.membership = np.empty(n, dtype=int)
        self.resistance_to_hub = np.zeros(n)
        for j, (h, leaves) in enumerate(zip(self.hubs, self.groups)):
            self.membership[h] = j
            self.membership[leaves] = j
            self.resistance_to_hub[leaves] = 1 / rng.uniform(a, 3 * a, len(leaves))
        self.noise = np.random.default_rng(seed + 1249843)
        self.lower = A * a / (3 + 2 * a * r0)
        self.m = math.ceil(math.log(2 / delta) / math.log(4 / 3))
        self.T = max(1, math.ceil(32 * sigma ** 2 / self.lower ** 2 * math.log(4 * self.m / delta)))
        self.q = self.m * self.T
        H = 3 * a * A + sigma * math.sqrt(2 * math.log(8 * n * self.q / delta))
        self.step = self.lower / 4
        self.max_index = math.ceil(H / self.step)
        self.bits = math.ceil(math.log2(2 * self.max_index + 1))
        self.row_energy = np.zeros(n)
        self.actions = self.scalars = self.clipped = self.cross_pairs_seen = 0
        self.max_mean_current = self.max_source_power = 0.0
        self.seen_pairs = set()

    def acquire(self, pair):
        p, q = pair
        assert p != q
        if self.membership[p] == self.membership[q]:
            resistance = self.resistance_to_hub[p] + self.resistance_to_hub[q]
        elif self.theta:
            resistance = self.resistance_to_hub[p] + self.resistance_to_hub[q] + 1 / self.a
        else:
            resistance = None
        current = 0.0 if resistance is None else self.A / (2 * self.r0 + resistance)
        y = self.noise.normal(0, self.sigma, self.n)
        y[p] += current
        y[q] -= current
        indices = np.rint(y / self.step)
        self.clipped += int(np.count_nonzero(abs(indices) > self.max_index))
        indices = np.clip(indices, -self.max_index, self.max_index)
        self.row_energy[p] += self.A ** 2
        self.actions += 1
        self.scalars += self.n
        self.max_mean_current = max(self.max_mean_current, current)
        self.max_source_power = max(self.max_source_power, self.A * current)
        if pair not in self.seen_pairs:
            self.seen_pairs.add(pair)
            self.cross_pairs_seen += int(self.membership[p] != self.membership[q])
        return indices * self.step


def learner(acquire, n, a, r0, A, sigma, delta, seed):
    """All pairs fixed before any returned data; no access to graph truth."""
    lower = A * a / (3 + 2 * a * r0)
    m = math.ceil(math.log(2 / delta) / math.log(4 / 3))
    T = max(1, math.ceil(32 * sigma ** 2 / lower ** 2 * math.log(4 * m / delta)))
    N = n * (n - 1)
    b = (N - 1).bit_length()
    rng = np.random.default_rng(seed)
    pairs = []
    for _ in range(m):
        j = int(rng.integers(0, 1 << b)) % N
        p, h = divmod(j, n - 1)
        pairs.append((p, h + int(h >= p)))
    connected = True
    for pair in pairs:
        average = sum(acquire(pair)[pair[0]] for _ in range(T)) / T
        connected = connected and bool(average >= lower / 2)
    return connected, m, T, m * b


cases = []
for n in (32, 264, 1024):
    for sigma in (0.05, 0.25):
        for theta in (0, 1):
            a, r0, A, delta = 1.0, 1 / 128, 0.5, 0.1
            plant = SyntheticOpenPlant(n, a, r0, A, sigma, delta, theta,
                                       1741 * n + 17 * theta + int(100 * sigma))
            result, m, T, bits = learner(plant.acquire, n, a, r0, A, sigma, delta,
                                         7249 + 101 * n + theta)
            check(result == bool(theta))
            check(plant.actions == m * T and plant.scalars == n * m * T)
            check(np.max(plant.row_energy) <= plant.q * A * A)
            check(plant.max_mean_current <= 3 * a * A)
            check(plant.clipped == 0)
            check(theta or plant.cross_pairs_seen > 0)
            cases.append({"n": n, "sigma_over_a": sigma, "theta": theta,
                          "precommitted_pairs": m, "readings_per_pair": T,
                          "bounded_design_random_bits": bits,
                          "actual_synthetic_actions": plant.actions,
                          "actual_synthetic_scalar_readouts": plant.scalars,
                          "max_command_row_energy": float(np.max(plant.row_energy)),
                          "peak_mean_current": plant.max_mean_current,
                          "peak_nominal_settled_source_power": plant.max_source_power,
                          "bits_per_scalar": plant.bits, "clipped_scalars": plant.clipped,
                          "correct_decision": result == bool(theta)})

result = {"status": "PASS", "scope": "exact finite algebra plus synthetic settled ideal-open acquisition",
          "assertions": assertions, "exact_full_nodal_circuit_cases": exact_circuit_cases,
          "exact_balanced_sampler_partitions": exact_sampler_partitions,
          "synthetic_cases": cases,
          "total_synthetic_actions": sum(c["actual_synthetic_actions"] for c in cases),
          "total_synthetic_scalar_readouts": sum(c["actual_synthetic_scalar_readouts"] for c in cases),
          "physical_trials": 0, "real_unknown_experiment_acquisitions": 0,
          "settling_time_measured": False, "leakage_measured": False}
(ROOT / "OPEN_TERMINAL_REPLAY_RESULTS.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if not isinstance(v, list)}, indent=2))
