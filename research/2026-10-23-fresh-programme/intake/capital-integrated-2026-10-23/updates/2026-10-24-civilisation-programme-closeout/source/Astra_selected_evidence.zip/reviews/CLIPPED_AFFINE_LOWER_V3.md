# Independent audit of the enlarged-block lower, V3

Verdict: **ACCEPTED_INTERNAL_AUDIT_OF_V3_DELTA**. No blocking defect found.
This is an internal mathematical audit conditional on the unchanged original
H, all-coherence response and fixed-normal coding interfaces already audited
in V1/V2. It is not external certification, an optimal coefficient, a compiled
code or evidence of physical/practical advantage.

Reviewed exact source:
`work/workers/w56_fresh_quadratic_capacity_critic/lower_construction/TRACE_BUDGET_LOWER_V3.txt`,
SHA256 `a209cb166e057caff5222c3a146a4e8e8a7567466e9134c3b02f81fcba83332b`.
Its response lemma is `EXACT_SUMMED_TRACE_BUDGET_V3.txt`, SHA256
`7ee498ce8faa67b7f502e54dae9f668621155f79d733e6916e4157a7fe449649`.
V1 and V2 retained bytes were not modified.

## 1. Exact response and parameter window

Let `N=binom(k,2)`, `v=Tr sigma H^2` and `Tsum=sum||sigma H_ij||_1`.
For each pair, nonzero oriented color blocks both have normalized absolute
trace 1/2, and endpoint orientations have total mass 1/2. Writing
`A=sum Pr(h>d)`, `B=sum Pr(h=d)`, the symmetric triangular prefix/middle
walk-length sum gives `A=(N-B)/2`. Therefore

`Tsum=(A+B)/4=3N/8-v`.

Retaining the scalar empty-mask sum and applying the trace bound only to the
nonempty terms proves the complete bath-operator inequality

`F_k(b)>=[v-(3N/4-v)(1-a^(k-2))]I`.

This permits negative individual coefficients, including the exact k7
counterexample found during this audit campaign. No coefficientwise PSD
assumption enters V3.

For `0<b<=1/16384`, `k=floor1/(6b)>=2730` and `1/7<=r=bk<=1/6`.
The inherited collision estimate gives `nu=v/k^2>=3/25`, since its required
`k>=1365` is satisfied. Thus `N/v<=25/6` and the response ratio is at least
`1-(17/8)r>=31/48`. These floor and inequality directions were reconstructed
directly; no small-b asymptotic is substituted for a finite bound.

## 2. Positive input and clipping errors

The architecture is unchanged:

`X=-bH/5`, `B=(I+X)_+`, `Ntail=(-I-X)_+`,
`D=pin B=I+pin Ntail`, `J=D^-1/2`, `F=JBJ`,
`T=I+[t0/(4k)](Q-k/2)`, `rho=sigma T F`, `t0=v b^2`.

All these operators preserve total charge; sigma and T are functions of
charge and commute with F, although J need not commute with H. Consequently
rho is positive, `pin F=I`, `Tr rho=1`, and the exact charge excess is
`delta=t0/16`. This is the existing positive congruence, not a probabilistic
filter or a bath reset.

At even moment 20, the inherited endpoint count gives conditional moment
`39!! k^20`; the quarter-trace budget improves its sigma-weighted version
by 1/8. With `r/5<=1/30`, maximizing `(y-1)_+^j/y^20` gives
`c_j=j^j(20-j)^(20-j)/20^20`. Exact rational recomputation gives

- `||pin Ntail|| < 2e-8`;
- `||Ntail||_2 < 14e-6`;
- `||Ntail||_4 < 16e-4`.

No small operator norm of X or Ntail is inferred. The weighted error obeys
`e=||F-I-X||_2 <=d0||X||_2+||Ntail||_2 <15e-6`.
Since `t0>=3/1225`, `u=||X||_2=sqrt(t0)/5>1/102` and `u<.012`,
`e/u<1/600`. Also `eta=||T-I||=t0/8<=1/2304`.

Complete-pattern orthogonality isolates the diagonal T-I from T(F-I).
The reconstructed bounds are

`||TF-I||_2^2/t0 <=6985418048611/173903708160000 <201/5000`,

`||TF-I||_4/r <=6179783/14976000 <413/1000`.

For the latter, the noncommuting normalization is still controlled by
Schatten multiplication with contraction J and the pinching contraction;
it is not replaced by a scalar normalizer. The diagonal fourth moment
uses `Tr sigma(Q-k/2)^4=(3k^2-2k)/16` and `sqrt(k)>52`.

## 3. New global entropy estimate

For `y>=-1`, put `h(y)=(1+y)ln(1+y)-y`. Independently reconstruct:

`h(y)<=y^2/2-y^3/6+y^4/3`.

If `y=-x`, `0<=x<=1`, its exact series is
`sum_{n>=2}x^n/[n(n-1)]`. The n>=4 tail is at most
`x^4 sum_{n>=4}1/[n(n-1)]=x^4/3`. If y>=0, `h''''(y)=2/(1+y)^3<=2`,
so the cubic Taylor remainder is at most `y^4/12`, which is even smaller.
The y=-1 endpoint follows by continuity. The estimate is therefore global,
including clipping zeros and arbitrarily large positive relative eigenvalues.

For the Hermitian `Y=TF-I`, `[sigma,Y]=0` and `Tr sigma Y=0`.
Weighted Cauchy-Schwarz gives
`|Tr sigma Y^3|<=||Y||_2 ||Y||_4^2`. Applying the scalar majorant in the
common eigenbasis proves the stated relative-entropy estimate, with no
spectral Taylor truncation assumption:

`D_2(rho||sigma)/t0 <325382664997/8942400000000`.

This is about .0363865. The exact identity
`S_2(rho)-3k/2=t0/16-D_2(rho||sigma)` has gain coefficient
`233517335003/8942400000000 >1/39`. Every rational margin matches an
independent Fraction calculation, not merely the supplied JSON receipt.

## 4. Entire operator drift and coding transfer

The comparison state sigma(T+X) has drift at most
`a t0[1/8-(31/48)/5]I=-a t0/240 I`.
The remaining correction `Yoff=T(F-I)-X` is exactly off-pattern, so its
full prefix-operator response is bounded by the original H4 interface.
Its norm is at most `(1+eta)e+eta u`. With
`r exp(2r^2)<=r/(1-2r^2)<=3/17`, the resulting certified negative margin is

`4713287/1671168000 >1/360`.

This is an operator bound for every coherent or entangled bulk prefix,
not a selected-prefix expectation. The unchanged actual-root Lyapunov and
full-reference code theorem can therefore be invoked with fixed
`kappa=t0/360`. Beta, k and rho are fixed before the outer number of blocks
grows. The same code sequence works pointwise for each fixed normal bath
initializer, without free resets or a uniform all-normal horizon.

It follows that

`Q>=3/2+v beta^4/(39k)>=3/2+beta^2/2275`.

The simple bound uses `nu>=3/25` and `r>=1/7`. The unsimplified asymptotic
coefficient is `1/(8*6*39)=1/1872`; neither is the sharp capacity coefficient.

## 5. Independent scalar/baseline receipt and costs

Own script: `check_independent_v3.py`.
Own exact rational and 90-digit receipt:
`INDEPENDENT_V3_SCALAR_AND_BASELINE.json`.
At beta=1/512 it gives

- k=43690;
- new gain `2.032502311677681271918532899726...e-9`;
- ratio to frozen V2 `1.84814925890884...`;
- ratio to the previously independently evaluated best retained Cycle9
  certificate `86.3011545847415...`;
- `log10(3^k)=20845.427618702...`.

The larger constant requires an even larger exponential input space. No
large rho was synthesized, no spectral code/type or decoder was compiled,
and preparation, precision, error, finite-horizon and physical costs remain
unestablished. This audit supplies an analytic delta check and small exact
scalar calculations, not a practical communications improvement. Peak memory
and total inference/review costs were not measured.
