# Capped-probe coupling and optional diamond-error extension

23 October2026, w64. This supplements frozen V1 SHA28008c7e... and its mandatory probe sign correction38995aa2.... Historical bytes are preserved.

The iid claim in section5 is to be read for the IDEAL experiment with unlimited heralded depth1 recoveries, each of which terminates almost surely. It is in that ideal experiment that the corrected probe samples have mean x m_beta. Conditioning the CAPPED experiment on no abort can bias the zero-outcome frequency; an exact unchanged conditional mean is not needed or asserted here. Couple it sample by sample to the ideal experiment. They agree until the first depth1 recovery exceeds r. The probability of that disagreement is at most k b^r, without conditioning. Hoeffding applies to the ideal k-sample sequence, and adding the disagreement probability proves the same error/abort bound(L5). This clarifies the justification; it changes neither the bound nor any cost.

The main proof states reliable Bell-fidelity reduction. It also extends to reliable decoded DIAMOND error under the same final-discard objective. Here are the extra steps rather than treating Bell fidelity as diamond error.

Let the original decoded channel be N=sum_x p_x N_x, with fixed p_x>0, and suppose ||N-id||_diamond<=epsilon. For any pure input on the logical register and an arbitrary reference, its ideal output |psi> is pure. The trace bound implies <psi|N(psi)|psi>>=1-epsilon/2. Positivity of each weighted infidelity gives

    1-<psi|N_x(psi)|psi> <= epsilon/(2p_x).

Fuchs--van de Graaf against a pure state therefore gives, uniformly over that input/reference,

    ||N_x(psi)-psi||_1 <= 2sqrt(epsilon/(2p_x)).

Convexity reduces mixed inputs to purifications, and the standard channel-difference diamond variational formula gives the same bound on ||N_x-id||_diamond (clipped at2). Thus reliable mixture decoding forces reliability in each occupied fixed sector in dimension-independent diamond error; no dimension-dependent Choi-to-diamond estimate is used.

The conjugated local protocol has the conjugated decoded channel. The diamond distance to identity is invariant under simultaneous matrix conjugation of every input/reference and output: the global trace norm is conjugation invariant. This requires no physical antiunitary.

Finally a trace-norm error delta in an INITIAL resource independent of the unknown input causes at most delta decoded diamond error under an arbitrary fixed adaptive body protocol: tensoring it with any input/reference preserves the trace norm, then trace-preserving physical/local evolution is contractive. A preprocessing abort branch has diamond cost at most twice its probability, and its probability is independent of the untouched logical input. Hence the same o(N) preprocessing establishes the capacity reduction for body code sequences with vanishing decoded full diamond error too. It still does not establish return of the original bath/purifier or full process equivalence before tracing them out.
