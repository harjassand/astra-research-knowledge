# Independent local amplifier EPnI from thermal count kernels

23 October 2026, W38. NEW DERIVATION, NOT YET INDEPENDENTLY AUDITED.
No general amplifier EPnI theorem, N557 closure, historical novelty or
physical implementation is assumed. Natural logarithms throughout.

## 1. A substantive independent-input class

Fix G>1 and a,b>0. Write

    g(x)=(x+1)ln(x+1)-xlnx, h(x)=ln(1+1/x),
    c=Ga+(G-1)(b+1), eta_A=G h(c)/h(a),
    eta_B=(G-1)h(c)/h(b), eta_*=min(eta_A,eta_B).

For ANY finite n, let P_a,P_b be the product geometric photon-count laws
of tau_a^tensor n and tau_b^tensor n. Choose arbitrary REAL bounded
functions f_A,f_B of all n native photon counts satisfying

    |f_A|,|f_B|<=1,
    E_(P_a)f_A=E_(P_b)f_B=0,
    E_(P_a)[N_total f_A]=E_(P_b)[N_total f_B]=0.           (L1)

Define actual independent quantum input groups, diagonal in the joint Fock
basis, by

    rho_A=tau_a^tensor n [1+epsilon f_A(N_1,...,N_n)],
    rho_B=tau_b^tensor n [1+epsilon f_B(N_1,...,N_n)].    (L2)

Their within-group counts can be arbitrarily correlated and non-Gaussian;
there is no product assumption within either group. They have exact finite
mean total occupations na,nb. A concrete epsilon_0(G,a,b)>0 below is
INDEPENDENT OF n and of f_A,f_B. For |epsilon|<=epsilon_0,

    S(C) >= n g(G g^-1(S(A)/n)
                    +(G-1)[g^-1(S(B)/n)+1]),          (L3)

where c_j=sqrt(G)a_j+sqrt(G-1)b_j^dagger and A,B are INDEPENDENT.
In fact the entropy gap in (L3) is at least

    (delta/8)epsilon^2[eta_A E f_A^2+eta_B E f_B^2].       (L4)

Thus the inequality is strict unless both perturbations vanish. The
result is local, energy-matched and joint-Fock-diagonal, not a global
proof or a general quantum trace-distance neighborhood.

## 2. Exact physical photon-count representation

For diagonal inputs, two-mode squeezing preserves each number difference.
Tracing the discarded mode leaves the retained output Fock diagonal. Hence
the physical output is an ordinary stochastic photon-count kernel
Q(k_out|k_A,k_B), tensoring across native mode pairs. No measurement,
Gaussian replacement or acquired record is inserted into the physical map.

At the product thermal references the retained counts are geometric of mean
c. Let X be an initial A count and Y a retained C count. Thermal tilting
gives their exact joint probability generating function

    E[u^X v^Y]
      =1/{[1+a(1-u)][1+c(1-v)]
                            -G a(a+1)(1-u)(1-v)}.     (L5)

Indeed, multiplying tau_a by u^N has trace 1/[1+a(1-u)] and normalized
thermal mean a_u=au/[1+a(1-u)]. Mixing it with tau_b gives thermal mean
Ga_u+(G-1)(b+1); its geometric generating function proves (L5). Tilting
the B count instead gives the SAME formula with a replaced by b and the
cross coefficient by (G-1)b(b+1). This uses only the elementary physical
thermal-output formula, verifiable directly by Gaussian characteristic
functions. It does not assume an entropy-minimum principle.

For a geometric variable of mean x>0, set q_x=x/(x+1). Define the normalized
Meixner polynomials M_k^(x) through the generating function

    sum_(k>=0) M_k^(x)(m) z^k
       =(1-z/sqrt(q_x))^m/(1-z sqrt(q_x))^(m+1).       (L6)

Directly summing the geometric law shows E[M_j M_k]=1{j=k}. Polynomials
are complete in L2 of a geometric law: orthogonality to all powers would
make the analytic geometric-weighted generating function have all
derivatives zero at one, hence vanish identically. Substitution of (L6)
into (L5) gives EXACTLY

    E[M_j^(a)(X) M_k^(c)(Y)] = 1{j=k} r_A^k,
    r_A=G sqrt[a(a+1)/(c(c+1))],
    r_B=(G-1)sqrt[b(b+1)/(c(c+1))].                    (L7)

The substitution reduces the generating function to 1/(1-r_A z w).
Both 0<r_A,r_B<1; for example c>=Ga+G-1 and c+1>=G(a+1) prove the first
strict inequality, and the analogous B estimate proves the second.

For n modes use product Meixner polynomials indexed by multi-indices alpha.
The conditional-expectation operators

    T_A f_A=E_ref[f_A(A)|C], T_B f_B=E_ref[f_B(B)|C]

therefore have common output orthonormal basis and singular coefficients
r_A^|alpha| and r_B^|alpha|. No number-of-modes limit or tensorization
assumption about the PERTURBED inputs occurs.

## 3. A strict thermal scalar inequality

Define kappa(x)=x(x+1)h(x). Then

    delta=1-[G kappa(a)+(G-1)kappa(b)]/kappa(c)>0.      (L8)

Here is a direct positive-series proof. With v=x+1/2>1/2,

    kappa(x)=v-sum_(j>=1) d_j v^(-(2j-1)),
    d_j=2/[(4j^2-1)4^j]>0.

This follows by multiplying the absolutely convergent atanh series for
h(x) by v^2-1/4. Put v_c=Gv_a+(G-1)v_b. Linear terms cancel in the
difference kappa(c)-Gkappa(a)-(G-1)kappa(b). Every remaining term is

    d_j[G v_a^-p+(G-1)v_b^-p-v_c^-p]>0, p=2j-1,

since v_c>v_a and G>1. Absolute convergence justifies subtraction. Thus
(L8) is strict. It is finite for every fixed positive a,b and finite G>1.

Expand f_A,f_B in (L7)'s complete product basis. Their mean-zero condition
removes alpha=0. Weighted Cauchy-Schwarz at every remaining coefficient,
r_A,r_B<1, and (L8) yield the SIMULTANEOUS count contraction

    ||T_A f_A+T_B f_B||_2^2
       <=(r_A^2/eta_A+r_B^2/eta_B)
                         [eta_A||f_A||_2^2+eta_B||f_B||_2^2]
       =(1-delta) W, W=eta_A E f_A^2+eta_B E f_B^2.        (L9)

All norms on the left use the exact product thermal C reference. The
strict constant is dimension free. It is not a displacement-Fisher Stam
claim and is not applied at arbitrary nonthermal reference states.

## 4. Finite perturbations and rigorous entropy remainders

Put t=|epsilon|<=1/8. Under the exact reference count joint law, independence
of the A and B references gives the output density ratio

    p_C/P_c=1+epsilon u+epsilon^2 v,
    u=T_A f_A+T_B f_B, v=E_ref[f_A(A)f_B(B)|C].                 (L10)

Jensen gives ||v||_2^2<=E f_A^2 E f_B^2<=W/(2eta_*), because E f_A^2,E f_B^2<=1.
Also |epsilon u+epsilon^2 v|<=H_t=2t+t^2<1. For phi(z)=(1+z)ln(1+z)-z,
Taylor's integral formula gives, for |z|<=h<1,

    z^2/[2(1+h)]<=phi(z)<=z^2/[2(1-h)].               (L11)

Denote the input/output relative entropies to their respective thermal
references by D_A,D_B,D_C. Equations (L9)-(L11) imply

    eta_A D_A+eta_B D_B >= t^2 W/[2(1+t)],
    D_C <= t^2 W [sqrt(1-delta)+t/sqrt(2eta_*)]^2
                                              /[2(1-2t-t^2)].

For A_*=(2eta_*)^(-1/2), put

    C_*=4+(11/4)A_*+(11/64)A_*^2.

The elementary inequalities 1/(1+t)>=1-t and
1/(1-2t-t^2)<=1+3t for 0<=t<=1/8 show that the difference between the
two brackets is at least delta-C_*t. Hence if t<=delta/(2C_*),

    eta_A D_A+eta_B D_B-D_C >= (delta/4)t^2 W.         (L12)

The energy orthogonality in (L1) and zero first moments of diagonal states
give EXACTLY

    S(A)=ng(a)-D_A, S(B)=ng(b)-D_B, S(C)=ng(c)-D_C.    (L13)

The bilinear cross term changes neither output trace nor energy. These
identities are where fixed input energies, not just trace normalization,
are essential.

## 5. The nonlinear entropy-photon conversion is paid explicitly

Define F(s,t)=g(Gg^-1(s)+(G-1)[g^-1(t)+1]). On the compact rectangle
R=[g(a)/2,g(a)] times [g(b)/2,g(b)] its Hessian entries have a finite
absolute upper bound L. No convexity conjecture is needed. An explicit
choice is the maximum of the following three positive quantities:

    a_-=g^-1(g(a)/2), b_-=g^-1(g(b)/2),
    c_-=Ga_-+(G-1)(b_-+1),

    L_AA=G^2/[c_-(c_-+1)h(a)^2]
                  +G h(c_-)/[a_-(a_-+1)h(a)^3],
    L_BB=(G-1)^2/[c_-(c_-+1)h(b)^2]
                  +(G-1)h(c_-)/[b_-(b_-+1)h(b)^3],
    L_AB=G(G-1)/[c_-(c_-+1)h(a)h(b)],
    L=max(L_AA,L_BB,L_AB)>0.

These bounds follow by differentiating F and using h'(x)=-1/[x(x+1)].
Its first derivatives at (g(a),g(b)) are eta_A,eta_B. Therefore

    nF(g(a)-D_A/n,g(b)-D_B/n)
       <=ng(c)-eta_A D_A-eta_B D_B
                                      +L(D_A+D_B)^2/(2n). (L14)

Input entropy reductions are <=t^2/[2(1-t)] individually. Thus the
arguments stay in R if t^2<=7min(g(a),g(b))/8. Moreover

    L(D_A+D_B)^2/(2n)
      <=[16L/(49eta_*)]t^4 W                         (L15)

for t<=1/8, using n>=1 and (E f_A^2+E f_B^2)^2<=2(E f_A^2+E f_B^2).

A fully specified sufficient common radius is consequently

    epsilon_0=min{1/8, delta/(2C_*),
                 sqrt[7min(g(a),g(b))/8],
                 sqrt[49delta eta_* /(128L)]}.        (L16)

Combining (L12)-(L16) proves the strict gap (L4), hence (L3), for every
finite n and every f_A,f_B obeying (L1). All constants depend only on the
fixed G,a,b. Infinite count sums are legitimate because bounded density
ratios dominate product thermal laws and have finite energy. No finite
Fock cutoff, numerical optimizer or historical proof candidate is a premise.

## 6. Non-Gaussian examples and internal entanglement

For one mode of mean x, let q=x/(x+1), and set a finite perturbation
f_x(0)=q^2/M, f_x(1)=-2q/M, f_x(2)=1/M, f_x(k)=0 for k>=3, with
M=max(1,2q). Its geometric mean and first occupation moment vanish exactly.
Thus both ports can be nonthermal and non-Gaussian. For any n, arbitrary
bounded linear combinations of finite product perturbations with the
required mean/energy orthogonality are admitted. In particular at n=2,
f_x(N_1)f_x(N_2) gives actual within-input classical correlations while
leaving both one-mode marginals thermal. The physical groups remain product.

There is also an exact matched Gaussian-frame extension. For any finite
symplectic transformation S on n modes, let Z reverse every momentum.
Apply its Gaussian unitary U_S to A and U_(ZSZ) to B, with arbitrary local
displacements. The retained quadratures transform as S times their original
amplifier quadratures, plus a displacement. Thus the retained state is
U_S rho_C U_S^*, up to displacement, and all three entropies are unchanged.
Finite symplectic coefficients preserve finite energy. Equation (L3) holds
for these transformed inputs too. Such local transformations can generate
internal entanglement and coherences from the non-Gaussian correlated
diagonal class. This is a covariance corollary, not a general arbitrary-
quantum perturbation theorem or a correlated-A/B extension.

Internal entanglement is not merely a hypothetical possibility. For the
n=2 product perturbation just described, both native one-mode marginals
remain exactly thermal, and all cross quadrature covariances vanish.
Its covariance is therefore (a+1/2)I_4 at A and (b+1/2)I_4 at B, despite
the non-Gaussian count correlations. Apply a common within-party two-mode
squeezer of parameter R large enough that

    exp(2R)>max(2a+1,2b+1).

Each party's partially transposed covariance then has minimum symplectic
eigenvalue (a+1/2)exp(-2R) or (b+1/2)exp(-2R), below 1/2. A positive
partial-transposed state must satisfy the ordinary covariance uncertainty
inequality, so both inputs are internally NPT entangled, including for the
non-Gaussian perturbations. The A and B GROUPS are still independent.

## 7. Exact surviving open step

The proof controls the nonlinear count kernel only in a bounded likelihood
neighborhood of thermal references, and uses exact energy matching. Extending
its simultaneous relative-entropy estimate to large nonthermal deviations,
or replacing the classical count conditional expectation by a full quantum
noncommuting representation with controlled remainders, is NOT established.
The all-input amplifier EPnI remains UNKNOWN. Known scalar displacement-
Fisher, universal majorization and determinant-order shortcuts fail in the
pinned corpus; none is invoked. Local Meixner diagonalization, bounded-
likelihood Taylor bounds and the explicit nonlinear correction above are
the independent construction to be freshly criticized.

Historical priority, independent correctness, efficiency, finite physical
entropy acquisition and practical advantage remain UNKNOWN/NOT_ESTABLISHED.
