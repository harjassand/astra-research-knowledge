# Independent pair Gibbs reconstruction, variational optimum and finite guard

W66,23 October2026. This independently reconstructs formulas communicated
by root; it is not a hash-bound review of an unseen root manuscript. The
entropy optimum is scoped to two-port INPUT STATES with complete nonpositive
bulk drift. It is not a converse for all channel codes or the unrestricted
capacity. Gibbs/relative-entropy optimization is established machinery;
no historical novelty claim is made.

## 1. Exact whole-input scalar witness

Use A=Q-1,H=.5sum_c(|0c><c0|+h.c.), and L=2A+bH. The closed actual-word
calculation in PAIR_RESPONSE_WORD_PROOF.md generalizes to different colors:

    <0c|G_beta|c'0>
       =ab[delta_cc' I-|c'><c|_top].                (G1)

This follows from the same three Q_out-weighted terms: rowII/columnUU is
-ab delta_cc'I in W*QW; rowUU/columnII is-ab|c'><c|; rowUI/columnIU
is+2ab|c'><c|. Negating gives(G1). Within a complete binary charge pattern
the input effect is the scalar a(2Q-2)I and has no color offdiagonals.

Choose the legitimate initial bath state at depth exactly2 with maximally
mixed colors I_4/4. Its top marginal is I_2/2. Taking this bath expectation
in the COMPLETE input displacement operator gives

    E_bath G_beta =a[2(Q-1)+bH]=aL.                (G2)

Total-charge conservation makes input charge-offdiagonal blocks vanish
under this fixed-depth bath expectation. Thus(G2) is the full9-by-9
input operator, not only its sigmaA and sigmaH contractions. I independently
checked all its formal b-polynomial coefficients from the full36-by-36
physical matrix in check_rational_pair_source.py. The previous raw bytes
are preserved in RATIONAL_PAIR_SOURCE_IDENTITY_V1.json; the new raw includes
the additional full-input check.

If the complete bulk operator D_b(rho)<=0, its expectation in this particular
legitimate bulk state is nonpositive, soTr(rho L)<=0. This is necessary
for every source, including one with other color or charge coherences.

## 2. Root's Gibbs state and exact optimum

Since A and H commute, the partition function for rho_t=exp(-tL)/Z is

    Z(t)=e^(2t)+4e^(-2t)+4cosh(tb/2).

Its known eigenbasis is the same two-port basis as the rational source.
Using the direct full operator responses, not only(G2), gives

    D_b(rho_t)=-a Z'(t)/Z(t) I,
    Z'=2e^(2t)-8e^(-2t)+2b sinh(tb/2),
    Z''=4e^(2t)+16e^(-2t)+b^2cosh(tb/2)>0.          (G3)

At0, Z'=-6. At t0=ln2/2, Z'=2b sinh(t0b/2)>0 for b>0. There is a UNIQUE
t_b in(0,t0) with Z'=0. It is a MINIMUM of Z, a fact that must not be
confused with maximizing Z. Its role in entropy is constrained duality.

For every admissible source, the relative entropy identity is

    S_2(rho)=log_2 Z(t_b)+(t_b/ln2)Tr(rho L)
                         -D_2(rho||rho_tb)
             <=log_2 Z(t_b).                        (G4)

The Gibbs source attains the full operator constraint D=0 and equality.
Hence it is the UNIQUE max-entropy two-port source under the full operator
nonpositive-bulk-drift condition. No symmetry reduction of an arbitrary
source is needed for this upper bound: the scalar witness(G2) already
holds for every source. The maximum is attainable by a charge-preserving
source with the fixed known eigenbasis.

The elementary inequality e^(2t)+4e^(-2t)>=4 and strictcosh(tb/2)>1 for
t>0 prove Z(t_b)>8. Therefore its source entropy is strictly greater than3
for every0<b<1. This is an exact statement in the model, not a physical
thermodynamic validation.

Taylor expansion aboutb0,t0 gives

    t_b=t0-(t0/16)b^2+O(b^4),
    S_2(rho_tb)-3=(ln2/64)b^2+O(b^4).              (G5)

The corresponding source rate excess per physical call is
(ln2/128)beta^4+O(beta^8). This is the optimal leading entropy coefficient
within this fixed two-port inward/critical-source interface, not the
leading unrestricted channel capacity coefficient.

## 3. An explicit all-b critical entropy floor

For0<b<=1, t_b>1/4. Indeed e^(1/2)<5/3, e^(-1/2)>3/5 and
sinh(1/8)<1/7 give

    Z'(1/4)<10/3-24/5+2/7=-124/105<0.

The exponential bounds have elementary positive-series certificates;
e^(1/2)<=1+.5+(.5^2/2)/(1-.5/3)=33/20<5/3, and
sinh(1/8)<(1/8)/(1-1/384)=48/383<1/7.

Using cosh x>=1+x^2/2,

    Z(t_b)>=8+b^2/32,
    S_2(rho_tb)-3>=ln(1+b^2/256)/ln2
       >=b^2/(257ln2)>b^2/180.                      (G6)

The last step uses ln2<7/10; exp(7/10)>2 already follows by its first
four positive Taylor terms. This provides a nonasymptotic rational lower
certificate for the critical source. The previously proved critical
resource theorem applies without a kappa denominator. A constant9D
factory can approximate t_b and the known eigenvalue weights; there is
no Gibbs-state quantum oracle or unknown eigenvector.

## 4. Finite inward guard with paid root approximation

One may prefer strictly negative drift with a finite root enclosure.
On[1/4,t0], elementary bounds give

    16<=Z''<=26, 8<=Z<=9,
    |d S_2(rho_t)/dt|=t Var_t(L)/ln2<2.             (G7)

The lower16 is AMGM on the first two Z'' terms. For the upper26 use
t<=t0<.35 andcosh(tb/2)<2. Convexity andZ(t0)<9 boundZ<=9; the
entropy derivative uses t<.35, Z>=8 and ln2>2/3, giving at most273/160<2.

Set w=b^2/2880. Obtain a certified root bracket[l,r] of width<=w, with
l<=t_b<=r, and choose

    t=r+w.

Then w<=t-t_b<=2w. This stays belowt0: sinceZ'(t0)>=t0 b^2 andZ''<=26,
t0-t_b>=t0 b^2/26>b^2/104>2w. Equations(G3),(G6),(G7) imply

    D_b(rho_t)<=-[a b^2/1620]I,
    S_2(rho_t)>=3+b^2/240.                          (G8)

IndeedZ'>=16w=b^2/180 andZ<=9; entropy decreases by at most4w=b^2/720.
These are conservative bounds, not optimized finite resources.

The bracket can be computed with polynomial bit work in L_b+log(1/b).
Use the rational starting interval[1/4,7/20]. Z' is increasing with slope
at least16. Evaluate exponentials to O(w) certified absolute precision.
If a midpoint sign is ambiguous within that tolerance, the same slope
bound already gives a root enclosure of widthO(w); refine a constant factor
if needed. Otherwise bisect. Thus no exact comparison with a potentially
zero transcendental expression or unbounded precision escalation is needed.
Rational arithmetic, positive exponential series with a remainder bound,
and O(log1/w) iterations give the paid finite algorithm.

Choosing t=t0 instead is NOT a safe shortcut: its entropy gain has leading
coefficient negative-ln2/64 even though its drift is inward. Positivity,
inward drift and positive entropy are separate guards.

This reconstructs a concrete inward-source alternative to the exact
critical optimum. Its larger entropy certificate has weaker drift than
the simple rational pair; full call/gate costs must be compared before
claiming a finite advantage. The rational source remains the simpler
fully reviewed route. No novelty, physical or practical claim follows.
