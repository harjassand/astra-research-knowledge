# Critical and mixed power tails in the thermal-mixture entropy bridge

23 October 2026. W38. NEW separate candidate, full fresh criticism pending.
It does not alter frozen15bd31ec..., which deliberately left alpha=4 open.
The nonanalytic alpha<4 dependency remains pending fresh criticism too.
General UNHEATED finite-energy independent-input EPnI is NOT_ACHIEVED.

## 1. Exact proposed critical/analytic-tail theorem

Let R>=0 have a probability density satisfying

    f_R(v) ~ C v^(-alpha-1), C>0, alpha>=4,

with arbitrary behavior on bounded v. Put a=ER, v=Var(R)>0 and
rho_R=E tau_R, where tau_R is the one-mode thermal state of mean R.
Then the proposed ACTUAL quantum entropy asymptotic is

    D(H_T rho_R||tau_(T+a)) =v^2/(2T^4)+o(T^-4).        C1

At alpha=4 no finite fourth temperature moment, no exponential photon
moment and no finite thermal chi-squared are implied or used. The finite
third TEMPERATURE moment is automatic because alpha>=4. The proof below
uses an auxiliary L4-bounded core but compares its entropy with the actual
source directly on radial regions. It does NOT pay a binary-flag entropy
O(T^-4 ln T), which would be too large.

Together with the separate frozen
`REGULAR_VARIATION_THERMAL_MIXTURE_ENTROPY_BRIDGE.md`, SHA256
`15bd31ec239992165442f2fbbde3a92b290a6298ba160770a6881c47b65d7a27`,
this supplies a candidate eventual EPnI for ANY two independent one-mode
thermal-mixture sources with possibly different power exponents
alpha_A,alpha_B>1. It includes the original Pareto coherent mixtures at
EVERY p>2, with p=5 belonging to the critical case proved here. These are
fixed-source changed-input high-heat conclusions, not the original general
unheated target or arbitrary finite-energy thermal-mixture laws.

## 2. Auxiliary core and its global L4 Taylor expansion

Use the radial notation k_x(y)=(1+x)^(-1)e^(-y/(1+x)),
H_t(y)=E k_(R/t)(y), Q_t(y)=k_(a/t)(y), as in frozen15bd. Choose once
and for all delta=1/8 and let epsilon_t=P(R>delta t)=O(t^-alpha).
Let H_0,t be the NORMALIZED conditional mixture given R<=delta t, and
F_0,t=(H_0,t-Q_t)/Q_t. This conditional core is only an analytic object.

For 0<=x<=delta, the third x-derivative of k_x divided by Q_t has uniformly
bounded L4(Q_t) norm for large t. Indeed its fourth-power exponential
decay rate is at least

    4/(1+delta)-3/(1+a/t)>=32/9-3=5/9>0,

and the remaining factors are bounded rational functions of x times a
fixed polynomial in y. The same holds at the reference x=a/t, which is
eventually <=delta. Taylor's integral remainder through order2, Minkowski
and the bounded conditional ER^3 therefore give

    F_0,t = [Var(R)/(2t^2)] k''_0/Q_t +O_(L4(Q_t))(t^-3), C2

up to additional smaller low-moment clipping errors. Explicitly,

    E[R|core]-a=O(t^(1-alpha)),
    E[R^2|core]-ER^2=O(t^(2-alpha)).

After their factors t^-1 and t^-2 these are O(t^-alpha), and hence are
absorbed in C2 for alpha>=4. The reference expansion contributes a^2 at
second order, leaving the variance. Since

    k''_0(y)=(y^2-4y+2)e^-y,
    integral_0^infinity (y^2-4y+2)^2 e^-y dy=4,

C2 yields

    ||F_0,t||_4=O(t^-2),
    ||F_0,t||_2^2=v^2/t^4+o(t^-4).                    C3

The coefficient norm converges by polynomial exponential domination as
Q_t->e^-y. All Lp norms in this section concern only the bounded-temperature
core, NOT the actual heavy-tailed source.

## 3. Actual and auxiliary densities agree to the needed order before 3 ln t

Let H_tail,t=E[k_(R/t)1_(R>delta t)] be the subnormalized actual tail.
The exact mixture identity is

    H_t-H_0,t=H_tail,t-epsilon_t H_0,t.

The tail-density estimate used in frozen15bd Section3 gives

    H_tail,t(y)<=C t^-alpha(1+y)^(-alpha-1).            C4

Set Y_t=3 ln t. On 0<=y<=Y_t, Q_t>=c0e^-y, so

    integral_0^Y (H_t-H_0,t)^2/Q_t dy
       <=C t^(-2alpha) e^Y
          +C epsilon_t^2 integral H_0,t^2/Q_t
       =O(t^(-2alpha+3))+O(t^(-2alpha))=o(t^-4).        C5

The final full auxiliary integral is bounded because it equals
1+||F_0,t||_2^2. For alpha=4 the first exponent is -5, still strictly
smaller than -4.

The relative density errors are uniformly small on this region. The
pointwise first-order variance Taylor bound for the auxiliary mixture is

    |F_0,t(y)|<=C t^-2(1+y)^2 exp[(1-c)y]
                       +C t^-alpha(1+y), c=8/9.

At y<=3 ln t its first exponent is -2+3/9=-5/3, so this tends uniformly
to zero. For the actual added tail C4/Q_t is at most C t^(-alpha+3), which
also tends to zero. The epsilon_t H_0,t term is uniformly negligible.
Thus F_t=(H_t-Q_t)/Q_t tends uniformly to zero on [0,Y_t].

The scalar entropy integrand is consequently F_t^2/2 times 1+o(1)
UNIFORMLY on this region. C5 identifies its L2 leading norm with that of
F_0,t. The auxiliary norm outside [0,Y_t] is negligible by Holder:

    integral_Y^infinity F_0,t^2 Q_t
       <=||F_0,t||_4^2 [P_(Q_t)(y>Y)]^(1/2)=o(t^-4).

It follows from C3 that the ACTUAL pre-tail entropy is

    integral_0^Y Phi(H_t,Q_t)dy=v^2/(2t^4)+o(t^-4).     C6

No global actual relative-moment norm was inferred from C5.

## 4. Actual entropy beyond 3 ln t is smaller than t^-4

The global density error from the same first-order variance Taylor
argument is

    |H_t-Q_t|<=A_t+B_t,
    A_t=C t^-2(1+y)^2 e^(-8y/9),
    B_t=C t^-alpha(1+y)^(-alpha-1).                    C7

This is H5 of frozen15bd with beta=2; the required finite second
temperature moment holds. For r>=|h-q| one has
Phi(h,q)<=r[1+ln(1+r/q)]. Convexity bounds its value at A+B by the sum of
the corresponding A[1+ln(1+2A/q)] and B[1+ln(1+2B/q)] terms.

For A the logarithm is bounded by C(1+y), using Q_t>=c0e^-y and dropping
the favorable factor t^-2. Therefore its integral beyond Y is at most

    C t^-2(1+Y)^3 exp(-8Y/9)
       =O(t^(-14/3)(ln t)^3)=o(t^-4).                 C8

For B, once Y grows, the logarithm is at most

    C+(y-alpha ln t)_+.

As alpha>=4, Y=3 ln t<alpha ln t. Its full remaining integral is

    O(t^-alpha (ln t)^-alpha)
       +O(t^-alpha (ln t)^(1-alpha))=o(t^-4).          C9

At the critical alpha=4 the latter is t^-4/(ln t)^3, which is genuinely
smaller than the bulk term. This is a direct bound on the ACTUAL tail
entropy; it does not charge the larger entropy of an auxiliary tail flag.
Combining C6-C9 proves the classical variance coefficient C1. Normal
coherent-preparation/heterodyne DPI at noise times T and T+1 then proves
C1 for the actual quantum state, exactly as in frozen15bd Section7.

## 5. Two-port closure when both power exponents are at least4

Take arbitrary independent sources in this class with alpha_A,alpha_B>=4,
not necessarily equal. Their temperature variances v_A,v_B are finite and
strictly positive. The actual retained state is the thermal mixture at
mean sT+W, W=lambda+G R_A+lambda R_B. Its variance is

    Var(W)=G^2 v_A+lambda^2 v_B.

Its density has exponent min(alpha_A,alpha_B)>=4; the elementary tail
addition proof is given below. Thus C1 applies to it at heat sT. The
three relative-entropy defects are

    d_A=v_A^2/(2T^4)+o(T^-4),
    d_B=v_B^2/(2T^4)+o(T^-4),
    d_C=(theta^2 v_A+phi^2 v_B)^2/(2T^4)+o(T^-4).

The matched Gaussian baseline is zero because all references are thermal.
The actual EPnI gap therefore equals

    [theta v_A^2+phi v_B^2
                 -(theta^2 v_A+phi^2 v_B)^2]/(2T^4)
                     +o(T^-4).                        C10

Weighted Cauchy gives a lower coefficient

    [1-theta^3-phi^3][theta v_A^2+phi v_B^2]/2>0.

The target derivative/Hessian limits are the same established scalar
facts in frozen d0e95b06... Sections3,5, reconstructed by W17 in52e1a998...
and used in the separately reviewed finite-moment bridge. This is not an
import of a general unproved amplifier optimizer.

For the critical original Pareto p=5,b>0, R=b/U, U~Gamma(4,1), so
Var(R)=b^2/18. In particular the actual quantum defect is

    D(H_T rho_(5,b)||tau_(T+b/3))=b^4/(648 T^4)+o(T^-4).

## 6. Different exponents with the heavier port below4

The sum-density tail of two independent positive variables has the smaller
exponent. If alpha_X<alpha_Y, split its convolution at x=r/2. On the
first half, r^(alpha_X+1)f_Y(r-x) is bounded by C r^(alpha_X-alpha_Y)
and tends to zero. On the second half, change variables and apply dominated
convergence against f_Y; its limit is C_X. The same split gives a global
power upper bound. For equal exponents the two coefficients add. Fixed
shifts preserve the coefficient and scaling by c multiplies it by c^alpha.

Suppose alpha_A<min(alpha_B,4), and write alpha=alpha_A, K=Gamma(alpha)/
(alpha-1), b_T=T^-alpha(alpha ln T)^(1-alpha). The pending nonanalytic
theorem frozen15bd then gives

    d_A~K C_A b_T, d_B=o(b_T), d_C~K theta^alpha C_A b_T.

For d_B, if alpha_B<4 use that theorem's faster power. If alpha_B>=4 use
C1's O(T^-4), which is smaller than b_T. Thus the actual EPnI gap is

    K(theta-theta^alpha)C_A b_T+o(b_T)>0 eventually.     C11

If B is the heavier port, replace theta,C_A by phi,C_B. If both exponents
equal alpha<4, the two positive contributions in frozen15bd H3 add. If
both are at least4, C10 applies. These cases exhaust all power exponents
alpha_A,alpha_B>1 and prove the stated complete thermal-power class,
conditional on fresh criticism of BOTH this note and frozen15bd.

## 7. Boundaries and falsification targets

The exact tail-density condition is stronger than finite mean energy.
Slowly varying/oscillatory tails and general nonthermal states are not
included by approximation. Sources and G are fixed before T grows; no
uniform or acquired useful heat threshold is inferred. The asymptotic
orders change at alpha=4, so neither formula is silently continued across
that point. Finite computation cannot certify this transition universally.

The actual heat changes inputs and adds T photons per input mode. These
sources are already unflagged classical thermal/coherent mixtures; no
temperature record, native entanglement, source factory, pump, calibration,
precision, entropy acquisition, disposal or reset has been acquired or
implemented. Generic variance Taylor, regular-variation and normal-DPI
tools are prior. Exact historical priority and external acceptance remain
UNKNOWN; physical/practical advantage is NOT_ESTABLISHED.

Fresh attacks should focus on uniform L4 covariance derivatives, actual
versus auxiliary pre-tail density comparison, the uniform entropy Taylor,
the remaining B-tail logarithm, and unequal-exponent convolution domination.
No new peer task, descendant, external message or public action is made.
The general UNHEATED finite-energy EPnI remains NOT_ACHIEVED.
