# Same-author replay receipt: paid-program candidate

24 October 2026. This receipt binds the saved candidate and calculations;
it is not an independent proof review or an extension of W49's verdict.

* Candidate: `PAID_COMPACT_PROGRAM_REUSE_CANDIDATE.md`, SHA256
  e8889995c6f60d24ba94879ac17da718d32171b0e2786780e69c22a18d180c58.
* Copied block policy: `reuse_block_policy.py`, SHA256
  0a720823c4127236f8beec4611fd2eea42c1e68a2f9af29a7739b054617e1d69.
* Guard producer: `certify_paid_program_reuse.py`, SHA256
  f9bd0056dd2d82ac88beee8289ee140822ddec1f1353ef825c812032589bb4d5.
* Selected raw guards: `PAID_PROGRAM_REUSE_GUARDS.json`, SHA256
  c9bb72986bc497631b385684f3c6f4c77b0e0c81084409461ddb49e4537c23b6.
* Actual-word/completion checker: `check_paid_bootstrap.py`, SHA256
  ca5525b3452a8f975018928e305b30c41b9f7efc7486e1e50aee62dbcc216b16.
* Raw exact bootstrap: `PAID_BOOTSTRAP_EXACT.json`, SHA256
  fdd30c07bd0e457df90819b94ff779537833de92b3bbdb54ff5ca025093562fd.
* No-producer-import replay: `check_paid_reuse_record.py`, SHA256
  ece672277dd9ddc245219c19d17afeebf3e2eb4e5bbc394d5b0d0f7a943082f5.
* Raw replay: `PAID_REUSE_RECORD_REPLAY.json`, SHA256
  2a9322a9b36acd22889142b24eceace79d77f11e5b9e964bff1656ebe7782595.

The saved producer and both checkers ran successfully on24 October.
Their frozen outputs refuse a different overwrite. The producer imports
only the explicitly pinned OWN block policy. The second scalar checker
imports no producer/peer implementation, reconstructing114 declared
scalar groups across3 rows and5 generic absorbing-memory controls.
It is still the same author's check, not scientific independence.

The bootstrap checker performs exact rational matrix algebra on8 actual
colour/zero-length cases, with46 instrument branches. It combines root
amplitudes coherently, checks every record Gram is scalar on the seed,
and checks the same-column/different-completion identity and initial
native subbudget. It does not execute the actual physical device. The
generic absorbing-memory controls reject an iid/local-stochastic
inference while satisfying the complete B-times-error hybrid bound.

All 3 selected candidate rate/error/count guards pass. The code width,
table, seed, initial/terminal calls, new block error, bootstrap length,
repetition number and previous failed guard are visible in the raw data.
No giant table sampling, random frame, native coefficient/phase array,
gate list, actual prefix or quantum message was constructed or sent.
The finite arithmetic does not prove compact-recipe sufficiency, the
full dual-completion interface or the all-parameter asymptotic resource
claim. Those remain the exact next independent criticism gates.

Priority UNKNOWN; practical advantage NOT_ESTABLISHED;
physical NOT_PERFORMED; mission NOT_ACHIEVED.
