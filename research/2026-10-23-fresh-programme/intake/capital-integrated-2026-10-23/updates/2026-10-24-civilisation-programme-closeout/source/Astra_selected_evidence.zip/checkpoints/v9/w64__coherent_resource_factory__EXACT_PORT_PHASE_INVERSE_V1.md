# Exact physical inverse from port phases and finitely many forward native calls

23 October 2026, w64. Independent derivation after the polynomial recurrence factory packet was frozen. This is a NEW proof, not covered by its manifest or any older audit. Ideal-algebra proof candidate; new complete native diagnostics and fresh criticism PENDING at this freeze. No claim of generic composite-pulse novelty, scientific priority, physical apparatus, capacity advantage or mission completion.

## I. Native decomposition and legal controls

Use the unchanged full infinite native U and V=alpha U+i beta I of c544c1a9... . First assume known fixed 0<=beta<1, alpha=sqrt(1-beta^2)>0, and a KNOWN conserved seed-X sector x in {+1,-1}. The port is coherently returned from Bob to Alice after every forward call. Alice may apply the explicitly local phase

    D(z)=diag(z,1,1),  |z|=1,

to that returned qutrit, phasing ONLY its vacuum basis vector. No physical controlled V, negative-time operation, bath measurement or direct bath control is supplied.

The complete port/bath Hilbert space in this sector is the orthogonal direct sum of the root singleton |0,r_x> and matched two-dimensional spaces

    span{|0,jw>, |j,w>},  j=1,2, every finite w.

On every matched pair,

    V2 = [[i beta,alpha],[alpha,i beta]],
    D2(z)=diag(z,1).

On the root singleton, V is the scalar lambda_x=alpha x+i beta and D(z) is z. This decomposition exhausts the native space. A pulse identity verified on every matched pair AND the root singleton is therefore an operator identity on the full infinite sector, including arbitrary bath/reference entanglement.

The elementary echo D(i) in matched-pair notation is not by itself a valid inverse: a port phase diag(i,-i,-i) flips the matched off-diagonal part but has an unmatched root phase. The following construction explicitly matches that root phase.

## II. Three-call inverse when beta^2<=1/2

This lemma permits REAL alpha,beta of either sign, alpha^2+beta^2=1, alpha!=0, beta^2<=1/2. It will later be applied to an odd native power. For beta=0, V=alpha U is already its own inverse; one call suffices. Suppose beta!=0. Define

    lambda = alpha x+i beta,
    g = lambda^(-4),
    w = (1-g)/alpha^2,
    e = w/|w|,
    c = 2|beta|^3/|alpha|,
    z1=e(c+i sqrt(1-c^2)),
    z2=e(c-i sqrt(1-c^2)).                          (P1)

All z's are unit phases. The radicand is nonnegative because c<=1 is equivalent to 4(beta^2)^3<=1-beta^2, which holds exactly for beta^2<=1/2. The useful identities are

    |w|=4|beta|/|alpha|,
    Re(w)/|w|=2|alpha beta|,
    (1+z1)(1+z2)=w.                                (P2)

For the last identity, z1+z2=2ec and z1z2=e^2, so their product plus singles is 1+2ec+e^2=2e(c+Re(e))=e|w|. The expressions are valid for either sign of alpha,beta and either x.

Form the three-call CORE matrix

    C = V2 D2(z2) V2 D2(z1) V2.                    (P3)

Its lower-right entry is obtained by the four intermediate vacuum/colored paths:

    C11=(i beta)^3+alpha^2 i beta(z1+z2+z1z2)
       =i beta[alpha^2(1+z1)(1+z2)-1]
       =-i beta g.                                (P4)

Here the subscripts 0,1 denote vacuum-child and colored-parent in a matched pair. C is unitary. Hence |C01|=|C10|=|alpha|>0. Define legal endpoint phases

    zL = g alpha/C01,
    zR = g alpha/C10.                              (P5)

Then

    D2(zL) C D2(zR)=g V2*.                         (P6)

The two off-diagonal entries match by construction, the lower-right matches by (P4), and row orthogonality fixes the upper-left to -i beta g. No numerical search or approximation enters this ideal identity.

The physical-root check is essential. Since det V2=-1 and det(gV2*)=-g^2, taking determinants in (P6) gives

    zL z2 z1 zR = g^2.

The same pulse sequence on the ROOT singleton is therefore

    lambda^3 zL z2 z1 zR
      =lambda^3 g^2=g lambda*,                     (P7)

because g=lambda^-4 and |lambda|=1. Equations (P6) and (P7) prove the FULL native-sector operator identity

    D(zL) V D(z2) V D(z1) V D(zR)=g V*.            (P8)

Execute from right to left. This needs exactly three FORWARD calls and three coherent qutrit backward returns; all four port phases are local. The final scalar g is a global phase on the entire known sector, so its channel is EXACTLY V*. It is not just a relative phase chosen separately on each pair. Its root dependence has been explicitly reconciled.

## III. Every fixed beta<1 reduces to the three-call regime

For the original alpha>0,beta>=0, let theta=arcsin(beta), gamma=arccos(beta). If beta^2<=1/2 use m=1. Otherwise 0<gamma<pi/4. Choose the least positive ODD integer m with

    m gamma >= pi/4.

Its minimality gives m gamma<pi/4+2gamma<3pi/4. Thus

    |cos(m gamma)|<=1/sqrt(2),
    m<=pi/(4gamma)+2.                              (P9)

For odd m, exact spectral calculus gives

    W=V^m=alpha_m U+i beta_m I,
    alpha_m=cos(m theta), beta_m=sin(m theta),
    beta_m^2=cos^2(m gamma)<=1/2.                   (P10)

The effective alpha_m can be negative and beta_m can have either sign, which is why the lemma covered those cases. In particular |alpha_m|>=1/sqrt(2). Apply (P8) to W, implementing each W by m actual forward native V calls on the same returned qutrit. This realizes g_m W*. Append m-1 additional forward native calls:

    (g_m W*) V^(m-1)=g_m V*.                       (P11)

The number of actual forward calls and backward returns is at most

    n_inv=4m-1=O(1/gamma+1)=O(1/alpha+1).           (P12)

If beta_m=0 exactly, W=W* and the shortcut W V^(m-1)=V* uses only 2m-1 calls. At beta=0, a single V=U call is exact. At beta=1 the inverse is the known global scalar -iI and no interaction is needed, but the coherent bath FACTORY still fails because the bath cannot be written. Near beta=1 the inverse synthesis here is pointwise and its bound diverges; no uniform endpoint cost is claimed.

All words, root visits, arbitrary bath coherences, and external references are already included in the full sector operator identity. The construction does not invoke a finite physical cutoff. If the initial seed has an unresolved superposition of x=+1 and x=-1, the same chosen pulse generally does not implement V* on BOTH sectors with a common phase. Known x remains a premise; the corrected finite probe/operational sector reduction is a separate acquisition step, not arbitrary whole-seed/purifier return.

## IV. Finite precision is charged and implementable

Four exact local phase gates are an ideal-control statement. If their implemented operator errors sum to eta, telescoping gives at most eta error in the synthesized inverse. Native-query count remains n_inv; no 1/eta recurrence count is hidden. Each forward/return hardware error is separately multiplied by n_inv, as usual.

One need not decide equality of arbitrary computable real coefficients or assume an exact-angle oracle. Choose a certified RATIONAL beta_tilde in [0,1) with ||V(beta)-V(beta_tilde)||<=kappa. For fixed beta<1, alpha's conditioning is finite. Run the algebraic construction for beta_tilde. Its odd-power coefficients can be evaluated by polynomial/complex-power recurrence, and a suitable odd m can be found by testing beta_m^2<=1/2. With rational beta_tilde these tests, any beta_m=0 branch, square roots and unit complex phases are algebraic and can be evaluated with certified finite precision. No physical queries occur in this classical compilation.

If the resulting sequence has n_inv queries, compare its use of actual V(beta) to ideal V(beta_tilde), and also compare their target inverses. The full operator error is at most

    (n_inv+1) kappa + eta.                         (P13)

All quantities can be chosen before the unknown quantum input arrives. For every fixed beta<1, n_inv is bounded independently of accuracy, and beta/phase precision need only increase logarithmically with the requested error, with additional finite endpoint conditioning. Bit arithmetic, exact-algebraic sign tests, phase synthesis and gate storage remain counted local computation. This is a physical-query improvement, not a free classical compiler.

## V. Consequence for the coherent resource factory

Keep the full deterministic circuit and overlap identity of COHERENT_VARIABLE_DEPTH_FACTORY_V1.md with its mandatory NORM_AND_PHASE_CLARIFICATIONS.md. Replace ONLY the long positive-power approximation to each V* by the native sequence just proved. If each synthesized inverse has operator error at most delta, the same product telescoping gives Tdelta. The full output-channel bound remains

    2sqrt(2tau)+2Tdelta+2e_loc+epsilon_root,
    tau=Pr[Bin(T,1-beta^2)<H].                      (P14)

Use the same T=O_beta(H+ln(1/epsilon)+1), delta=epsilon/(8T), local error allocation and UNHALVED JOINT root promise. The actual physical forward calls and coherent backward qutrit returns are now bounded by

    n_inv T = O_beta[H+ln(1/epsilon)+1],            (P15)

with four local port phase gates per inverse block, plus the already explicit T-step local stack simulator. The state being transferred can be UNKNOWN, entangled with an arbitrary reference and coherent across word lengths. Root initialization, Bob-resource distribution, target local preparation, hardware noise, quantum returns and storage are still separate and charged.

This removes the inverse-recurrence 1/epsilon and extra T factors from the physical query bound. It does not remove the exponential local circuit complexity of arbitrary unstructured target preparation, confer a message capacity above the existing bounds, or restore a replaced old bath/purifier. No such corollary is asserted.

## VI. Proof and novelty obligations

New diagnostics must check the exact three-call pair/root identity for signs, both sectors and threshold; the odd-power reduction; the literal native full factory; sensitivity to wrong x; and finite phase errors. Until those run, this is an analytic candidate only. A separate fresh audit of the FULL frozen source is required; earlier factory and upload audits do not cover it.

Generic composite-pulse and local-control strategies are established literature. Burgarth/Giovannetti (2007) already gives the general reverse-download idea. A primary-source special-case priority search for this exact root-compatible finite-port synthesis remains PENDING. The intended evidence is a concrete legal interface and fully counted query bound, not a claim to have invented composite pulses or solved the broader scientific-learning mission.
