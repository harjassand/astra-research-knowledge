# Independent audit: one efficient receiver for an unknown fixed gain

23 October 2026, w20. **No blocking defect found in the scoped ideal-model
construction.** The Fourier/common-code/polar route supplies a concrete local
receiver without acquiring the actual fine gain or seed sector. It has a
polynomial mathematical gate bound, logarithmic rate loss, and pointwise
vanishing full logical error for every fixed normal initializer. The known
interaction family, public coarse interval and ordinary coherent local gates
remain supplied premises. Physical realization, practical advantage,
historical priority and external validation are not established.

This is a fresh internal reconstruction, not an external endorsement. It
does not extend earlier known-parameter review receipts automatically. It
preserves all earlier w20 packets and the actual source corpus.

## 1. Exact sources and independent development

The old sender-only band extension has SHA256
`b22ae44b50ec62acfeadda46feb6ce3b90b945ba82709bbfbdfb175a9ed96600`.
It explicitly leaves its digital inverse dependent on the actual parameter.
The reviewed new w67 Fourier draft is
`f6c696a1a8c3d56524ffb53d7551a1ff9be588dc900b9e9a36b3df61b3336d49`.
Its separately retained cross-Gram overflow addendum is
`12d08bb9afc409ae0a911795e8bbe796a5ade4258a3d459a0b603d56674e97e5`.
All were copied byte-for-byte into `sources/`. Source paths, sizes and hashes
are in `sources/INTERNAL_SOURCE_MANIFEST.json`. The actual local Astra HEAD
was checked as `e606bfc587c76bdcae8b8fa3ec33e721efa2fbac`.

Before reading the new peer proof, w20 saved a joint grid/initializer
error-span compiler, accessible row-adjoint block encoding, spectral cutoff
and explicit cross-parameter caveat in `INDEPENDENT_CONSTRUCTION.md`,
SHA `810e43b903d854af42aa49b5767f03b604e17203729fb462356774b8184d5dbe`.
The dimension-free square-root/cutoff/full-channel derivation was also saved
independently in `ROBUST_POLAR_DERIVATION.md`, SHA
`b3bb7935b0160fa52a5eeac3b2cf473cc0f9593af41502da274d4d4744c1f649`.
Root independently reconstructed the same square-root argument. W67
independently developed the exact Fourier span and centered-design proof.
W20 subsequently derived that the common Gram event also controls physical
overflow; w67 checked it and retained the credited addendum. Root then found
that the ENTIRE generic dimension-free Gram/square-root/polar bridge is
already explicit in Elimelech--Albert--Barg2608.28962v1, Theorem11 and
Proposition12. I reopened those proofs and confirmed it. Our independent
generic derivation is a rediscovery, with no novelty claim. The potential
contribution is the device-specific paid composition and finite ledger.

## 2. Causal physical and local-computational protocol

Supply rational `0<b0<=b<=b1<=1/1024`, with fixed unknown b=beta^2 for
the WHOLE transmission. The source/encoder depends only on b0 and the
public offline random seed. No online parameter message is used.

1. Send a deterministic counted zero prefix. Its length uses the lower
   pop probability `a1=1-b1` and an increasing incoming depth cutoff A.
   The complete reset bound is `4sqrt(q_A+nu_prefix)` in full trace norm.
   This converges for each fixed normal initializer; no finite uniform tail
   over all normal states is acquired or claimed. Bath/input independence
   is essential.
2. Send the pure type/common high-design encoder body of 2m ports. Its
   analytic pair source has surplus `g0=b0^2/384` and uniform actual drift
   at most `-(1-b1)b0^2/240`. The analytic source is not prepared as free
   physical copies. The parent type is acquired by exact ranking/counting.
3. Append counted zero ports and retain EVERY body/terminal output. The
   physical final word is approximately the pure vacuum. The unchanged
   root, arbitrary word coherences and both conserved seed sectors are
   included. This is forward physical evolution, not an inverse query.
4. On the received ports execute ONE locally compiled Fourier-row polar
   recovery circuit. Its known local simulations use all parameter/sector
   labels. They never read the actual beta, seed, bath, or a physical
   coherent parameter tag. Every helper branch is part of a TP map.
5. Discard local flags/syndrome/work registers and output the fixed logical
   register. No successful postselection occurs. No physical seed probe or
   fine-gain calibration is required by this protocol.

The seed may be mathematically dephased when assessing accessible outputs,
because physical interactions conserve X_seed and the actual seed is
traced. This reduction does not claim physical erasure of seed coherence
or return/decoupling of its original purifier. The reset theorem retains
the classical sector/reference correlations; a common receiver handles both
sectors. Initial-prefix outputs may be discarded as in the stated interface.

## 3. Full Fourier span and normalization

For a T-call body/flush circuit, each
`V_theta=U exp(i theta U)` contributes frequencies +/-1. Interleaved
theta-independent gates and the type encoder do not change the degree.
The vacuum component K_s(theta) is a Laurent polynomial supported on
`[-T,T]`. With J=2T+1 full-circle digital angles,

    E_(s,a)=(1/J) sum_j exp(-ia theta_j) K_s(theta_j),
    K_s(theta)=sum_a exp(ia theta) E_(s,a),
    sum_a E_(s,a)^*E_(s,a)<=I.

J prevents aliasing of every difference of two supported frequencies.
Parseval gives the last inequality. Angles outside the actual band are
legitimate KNOWN digital circuit targets; no physical experiment at those
angles is used. All E_i are contractions.

Include both sectors, giving r=2J error labels. An actual coefficient
vector has J unit-modulus entries in one sector, hence squared norm J,
bounded by r. There is no free unit-norm coefficient promise. The Gram
G has trace at most TWO, not one; the recovery argument never requires a
unit trace. The good final physical word has dimension one. Keeping the
whole depth<=H environment instead would introduce a beta-dependent power
of m and fail the claimed joint polynomial accounting.

## 4. Cross-model common code, rather than per-model recovery

For every Hermitian real/imaginary part of E_i^*E_j, center its parent
trace mean and apply the Gaussian/net/integrated even-moment lemma. I
reconstructed its constants directly. The centered operator has norm<=2.
The Gaussian denominator exceptional probability is exp[-(ln2-1/2)D].
A quarter-net has cardinality at most 9^(2K), used ONLY to derive a Haar
tail. Integrating before design replacement gives the F4 moment bound with
256 and 4^h terms. The diamond 2h moment transfer costs exactly
`4^h delta K^(2h)`; that large dimension factor is paid in the precision
length, not suppressed. Lower-order moments follow by appending/tracing
maximally mixed registers, so one sufficiently accurate 2h design is enough.

A union over at most 2r^2 centered cross products gives on ONE seed event

    F=[E_i V], ||F^*F-G tensor I||<=omega=128r sqrt(q).

This is the required operator norm on the entire label/logical space and
is complete with respect to logical references. It includes off-diagonal
sector and parameter pairs. The encoder constructor uses only the scalar
guards and known random circuit, never evaluates these operators or G.

A decisive falsifier for the weaker argument is `{I_2,Z_2}` on the full
qubit code: each channel separately has a perfect inverse, but their
equal unknown mixture is complete dephasing. Its Bell fidelity after any
common local recovery is at most one-half. Thus separate per-beta
decoupling cannot replace the cross-product event. The new proof does
not make that substitution.

## 5. Recovery, all helper branches and the physical residual

Let F=R sqrt(A), A=F^*F. The exact polar inverse gives R^*F=sqrt(A).
Operator monotonicity proves
`||sqrt(A)-sqrt(G tensor I)||<=sqrt(omega)` even when G is singular.
Actual coefficient norm then gives logical/syndrome factorization error
at most sqrt(r omega), with no exponential logical-dimension factor.

Discard singular values of F below sqrt(nu). Both their actual amplitude
and their exact polar target have norm at most sqrt(r nu), so replacing
that subspace by ANY unitary/TP helper completion costs at most twice
that norm. The high left-singular projection of the actual good amplitude
is a contraction, so uniform FULL high-subspace error xi contributes xi.
Thus

    e_good<=sqrt(r omega)+2sqrt(r nu)+xi.

A signal success probability is not enough: a successful transformation
with opposite phases on two logical singular vectors can be a logical Z,
having Bell full trace error two. The phase-aligned QSVT theorem addresses
this. A projected polynomial error of order xi^2 is required to control
unitary leakage in full isometry norm.

Restoring the actual nonvacuum physical word costs sqrt(u). The target
syndrome vector is common to all messages but may be unnormalized; its
normalization adds at most the same norm discrepancy. This yields the
full diamond bound `4(e_good+sqrt(u))`, preserving arbitrary logical
references. `ROBUST_POLAR_DERIVATION.md` also supplies an independent
channel-level bound `2u+4d+2d^2`, d=sqrt(r omega)+xi, with its separately
specified cutoff convention. No claim here retains only a favorable branch.

The new simplification is

    u<=2q+r omega.

The parent average final bad probability is <=2q by source tail plus
terminal descent. Compressing the COMMON Gram event with the actual
coefficient vector promotes that same average to a uniform code effect.
No separate continuity grid or positive-overflow seed event is needed.
Under `q<=2^-48 z^4/r^4`, `nu=z^2/(2^16 r)`, `xi<=z/128`, the ideal
vacuum-start full error is <=3z/32. The owner addendum correctly assigns
xi to include the ideal QSVT and native helper telescope. Prefix and
transmission-encoder errors are still separately counted.

## 6. Actual helper access and complete costs

The row has a direct block F/sqrt(r). Coherently select the known error
implementations, Fourier-LCU over the J known angles, project the LOCAL
word to vacuum, and unprepare the label against its known uniform state.
All projections are known fixed ancilla/valid-index subspaces in a unitary
block encoding. Its adjoint is obtained by reversing finite local gates.
The dual construction in w20's independent seed uses a local environment
Bell pair, known inverse and input-zero projection. Both have the required
sqrt(r) normalization. Neither reflects about an unknown received state.

Starting the simulation at vacuum, a T-cell word stack and depth pointer
give the exact relevant infinite-tree matrix elements. Pair each push with
its inverse pop; fix unmatched top charged/invalid patterns and retain the
actual signed root. This is a total unitary involutive completion. No
reachable input-vacuum forward path encounters the artificial top boundary
before its last permitted call. QSVT may visit arbitrary digital states,
where the stated total extension, not a partial inverse, applies.

Known full-circle angle and Fourier phases, non-power-of-two uniform
registers, controlled circuits, all invalid basis patterns, encoder inverse,
label preparation and reflection are ordinary paid finite computation.
Controlled simulations must preserve their known relative/global phases;
an untracked branch-dependent phase changes the row and is not permitted.
The normalized retained gap is sqrt(nu/r). Query cost is
`O(sqrt(r/nu) log(1/xi))` times the ENTIRE block circuit, including the huge
high-design encoder and exact reversible type arithmetic. No Gram
tomography, physical inverse or fine-parameter oracle is supplied.

`FINITE_GUARD_PROOF.md` and the no-import script provide three NEW exact
integer/rational finite packages for b in [b0,2b0]:

| beta0 | sufficient m | lost qubits | ideal local design-gate interval |
|---|---:|---:|---:|
| 1/64 | 2^81 | 432 | [2^1121,2^1122) |
| 1/128 | 2^90 | 468 | [2^1239,2^1240) |
| 1/512 | 2^106 | 532 | [2^1447,2^1448) |

They check actual-rank envelopes, order 2h and width, all centered Gaussian/
diamond guards, label/terminal self-consistency, bounded random-bit compiler,
complete forward rate >=3/2+b0^2/1536 and tau_pi full error below .001,
including a finite-native allowance and the randomized seed-failure event.
Only the integer resource bounds are evaluated. The constructor must still
acquire the actual enormous type size and emit its full circuit/seed at
the counted polynomial cost. Its good seed is not efficiently recognized.

The full worst-case local gate bound is polynomial in horizon, inverse
band endpoint, inverse requested error and description lengths, with huge
degree/constants. It is not the displayed ideal-design length alone.
Pure port preparation, coherent local operations, record disposal and
precise native control remain mathematical resources; their laboratory
energy, elapsed time, noise, fault tolerance and cost are unknown. No
physical acquisition, equipment operation or large circuit execution occurred.

## 7. Evidence and strongest incumbent

`FINITE_CHECKS.json` contains eight tiny actual-word Laurent fixtures with
Fraction path coefficients and floating DFT/Parseval/continuum checks,
27 generic polar/square-root/coherent-cutoff TP fixtures and three exact
scalar packages. Largest Fourier discrepancy was 1.23e-15; largest TP
isometry discrepancy was 3.05e-15. These numerical checks are finite
diagnostics, not proofs or experiments. The proof reconstruction above is
the mathematical evidence. First and second run outputs are both retained;
`FIRST_RUN_RECEIPT.txt` explains exact hash recovery of the first runtime
record after a replay initially overwrote it.

Strong primary incumbents were actually reopened: compound quantum coding
already treats a common unknown-channel decoder; error-set recovery already
contains the full dimension-free operator-Gram square-root/polar proof,
and Petz/QSVT supplies the algorithmic tools. The 2009 compound
coding theorem concerns memoryless constituents; it does not by itself
compile this recurrent device. The 2026 error-set results explicitly charge
coefficient constraints; our Fourier coefficient norm is retained. The
2026 single-polar Petz paper has generic spectrum/reference factors; the
independently reconstructed dimension-free proof here is also prior in the
separate error-set paper, rather than a newly supplied generic bridge.
See `PRIMARY_RECEIPTS.md` for exact primary versions and read scope.

The proper baseline is a common error-set/Petz decoder with the SAME known
family and encoder access, not a receiver forbidden to use that information.
This work does not establish an algorithmic speedup over that incumbent.
It does resolve a concrete missing compiler interface inside this ideal
device proof. Comparing only to naive iid fine calibration would overstate
the scientific novelty and practical benefit.

## 8. Scope of the conclusion and next falsifiers

The reconstructed claim is conditional on the exact physical involution
family, fixed parameter throughout each codeword, public coarse band,
parent source/type theorem, coherent local gate access and bath/input
independence. That is a complete mathematical model, not an experimentally
identified apparatus. A time-varying unknown interaction, absent band, or
an unmodelled native gate/control error need not satisfy the Fourier span.
Finite calibration cannot certify the entire infinite physical tree.

Concrete mathematical falsifiers would be a reachable finite-word path
outside the retained Fourier span, a missed sqrt(r) coefficient factor,
non-TP helper completion, source average failing the actual coarse-band
operator drift, or a finite guard violating the full rate/error ledger.
No such blocker was found. Physical/practical falsification requires an
actual apparatus and a fully matched resource/noise experiment, absent here.

Proof status: INTERNAL_FRESH_RECONSTRUCTION_NO_BLOCKER_FOUND.
Randomized known-family universal receiver: CONDITIONAL_MATHEMATICAL_RESULT.
Deterministic good-seed recognition: NOT_ESTABLISHED.
External validation/priority/practical advantage: UNKNOWN/NOT_ESTABLISHED.
Physical validation: NOT_PERFORMED. Mission: NOT_ACHIEVED.
