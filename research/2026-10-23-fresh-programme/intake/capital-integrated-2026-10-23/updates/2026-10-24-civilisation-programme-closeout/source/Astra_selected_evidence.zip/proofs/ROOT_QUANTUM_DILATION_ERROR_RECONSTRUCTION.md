# Arbitrary quantum dilation error — root reconstruction

23 October2026. Reconstruction of W68's frozen QUANTUM_ERROR_CONSTANT.md, after receiving its outline. W40 separately converged on a variance/rounding proof before seeing W68's argument; that is independent convergence, not a blind fresh review. This file is root's direct check of the load-bearing arbitrary-algebra trace argument.

Let N=r^3,r>=2. Let P,Q be the commuting physical coordinate projections in the retained example: each has rank r, PQ rank1. Let E_P,E_Q be the binary normalized-trace conditional expectations. On S tensor A with ancilla dimension K, use the same letters P,Q for their tensor-identity lifts; ranks rK and overlap K. D=Tr_A. F,G are ANY commuting normalized-trace conditional expectations on the enlarged full matrix algebra, with arbitrary unital range algebras. Assume full-domain channels satisfy

max(||DF-E_PD||diamond,||DG-E_QD||diamond)<=epsilon.

All unnormalized matrix traces below are on enlarged space. This is the full-domain arbitrary-correlated-input contract, not just hot-product initialization. Put c=1/(r+1), delta=epsilon/2. Ifepsilon>=1 the desired weak bound below is automatic, so suppose0<=delta<1/2.

Adjoint duality and trace preservation give, for every physical projection R,

||F(R)-E_P(R)||infinity<=delta,
||G(R)-E_Q(R)||infinity<=delta.                        (1)

The factor1/2 is justified: the adjoint difference annihilates identity, so evaluate it on R=(I+(2R-I))/2, with||2R-I||=1. Do not replace a projection test by a state test or forget this normalization.

In particular, ||F(P)-P||<=delta and||G(Q)-Q||<=delta. Let X=F(P). Bimodularity yields

F((P-X)^2)=X-X^2<=delta^2 I.

Thus every eigenvalue of X lies in[0,alpha] union[1-alpha,1], alpha=(1-sqrt(1-4delta²))/2. Since||X-P||<1/2, exactlyrK eigenvalues occupy the high interval. TrX=TrP=rK; hence the total low-eigenvalue mass equals the total deficit of the high eigenvalues and is<=alpha rK. Orthogonality of trace expectations gives

v_F=||F(P)-P||_2²=Tr[X-X²]<=2alpha rK.                (2)

Similarly v_G<=2alpha rK for Y=G(Q).

Write A=X-P,B=Y-Q. SinceP,Q commute and0<=X,Y<=I, the negative part of the diagonal traceTr(AQ) is bounded by all ofP's deficit: Tr(AQ)>=Tr(AP)=-v_F. LikewiseTr(PB)>=-v_G. Cauchy–Schwarz givesTr(AB)>=-sqrt(v_F v_G). Therefore

Tr[ F(P)G(Q)] >=K-v_F-v_G-sqrt(v_Fv_G)
               >=K-6alpha rK.                       (3)

This step requiresP,Q commute; it does not assumeF(P),G(Q) commute with them individually.

Commutation and trace self-adjointness of F,G imply

Tr[F(P)G(Q)]=Tr[F(Q)G(P)].                            (4)

Now E_P(Q)=cP+(c/r)I and E_Q(P)=cQ+(c/r)I. Equations(1), positivity and trace preservation give

F(Q)<=cP+(c/r+delta)I,
||G(P)||infinity<=1/r+delta, TrG(P)=rK.

So

Tr[F(Q)G(P)]
 <=c Tr[P G(P)]+(c/r+delta)rK
 <=[2c+r(1+c)delta]K.                                (5)

Combine(3)-(5), cancelK:

1<=2c+r(1+c)delta+6r alpha(delta).                    (6)

This is uniform over ancilla dimension and EVERY enlarged range algebra. No block architecture, separability, outcome count or physical gate implementation is assumed.

Sincealpha<=2delta² fordelta<=1/2, ifdelta<1/(r+16), the right side is strictly less than1: the positive difference from1 after substitution has numerator r²+180r-256 over(r+1)(r+16)². Thus

epsilon>=2/(r+16).                                  (7)

More sharply, ifr epsilon stays bounded, alpha=delta²+O(delta^4), so(6) forces liminf r epsilon>=2. The retained hot quantum and classical constructions have error2/(r+1), so the unrestricted optimum has sharp leading constant

epsilon_opt=(2+o(1))/r.

The exact finite-r quantum optimum remains open. This is compatible with quantum ancillary dimensionTheta(sqrt r) versus physical-product-diagonal classicalTheta(r) at the relevant error. It gives no gate/runtime, actual hardware or practical advantage. Generic conditional-expectation variance, spectral perturbation and trace inequalities are established; exact device-specific priority remains UNKNOWN.
