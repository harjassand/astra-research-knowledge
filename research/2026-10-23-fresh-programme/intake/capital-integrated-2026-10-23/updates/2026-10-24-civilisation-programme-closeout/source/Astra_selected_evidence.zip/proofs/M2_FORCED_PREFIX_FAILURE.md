# An open hole in the forced-prefix maximal-pair cover

The two universal initial packets are legal for every actual N9 law, but
requiring both of them can prevent every subsequent maximal singleton or
rank-one-pair root-peeling continuation. This is a failure of that sufficient
representation class. It is not a nonlamination result, and does not refute
the audited nineteen-leaf box construction or the conditional compactness
argument.

Here is an explicit twelve-coordinate rational nodal assignment, with outer
values zero and the same physical mesh and area masses as the frozen proof:

```
u3=(27/14, 3/14),  u4=(24/7,-11),
u5=(-9/10,-18/7),  u6=(-3/7,7/15),
u7=(-16/31,-13/29),u8=(-4/27,-9/31).
```

Every coordinate may vary independently by `2^-32`. On this entire closed
twelve-dimensional box, the following restricted procedure has no successful
history:

1. Peel the full physical face zero.
2. Peel the full physical pair `(1,2)`.
3. Repeatedly peel a whole atom whose determinant displacement from the
   current mean is zero, or a maximal two-atom packet whose original atom
   gradients are rank-one connected and whose determinant displacements have
   opposite signs.

The box has nonempty interior. Hence the union of successful strict chambers
of precisely this forced-prefix strategy is not dense in actual N9 nodal
space. A dense-cover strategy must permit another prefix, a broader packet
grammar, nonmaximal peeling, another splitting shape, or a different argument.
None of those broader possibilities is excluded.

## Exhaustive finite certificate at the rational center

After the two forced packets, the remaining ten actual atoms have their
unchanged physical weights and total mass `12/25`. For a weight vector `w`
write `D_ij=det(A_i-A_j)` and `W=sum w_i`. Determinant balance gives

```
f_i=det(A_i-M)=(D w)_i/W.
```

This identity follows by expanding `det(A_i-A_j)` and using both the weighted
mean and determinant balance. Set `g_i=(D w)_i`. The only rank-one connected
distinct pairs among the ten atoms at this center are the thirteen universal
physical pairs

```
(3,5),(3,7),(4,5),(4,10),(5,11),(6,7),(6,9),
(7,12),(8,9),(8,10),(9,12),(10,11),(11,12).
```

All thirty-two other pair determinants are nonzero. For any current state,
a strict pair is available exactly when its two `g` values have opposite
signs. Define `r=w_j+w_i g_i/g_j`. If `r>0`, exhaust `i` and replace `w_j`
by `r`. If `r<0`, exhaust `j` and replace `w_i` by
`w_i+w_j g_j/g_i`. Equality would exhaust both. A zero `g_i` would allow
a whole atom peel.

`forced_prefix_obstruction.py` generates every such choice recursively,
merging states only when their complete exact Fraction weight vectors agree.
There is no search budget. Every transition strictly reduces support, so the
finite directed graph is acyclic and the enumeration must terminate. The
complete certificate has

```
1578 exact states,
1599 transitions,
617 stuck states,
support sizes 10:1, 9:7, 8:39, 7:157, 6:418, 5:599, 4:357.
```

At every reachable state all active `g_i` are nonzero. Every capacity
comparison `r` for a legal pair is also nonzero. Thus neither a missing whole
atom transition nor a simultaneous-exhaustion boundary is hidden in this
enumeration. Each terminal graph state has at least four atoms, no zero
displacement, and no rank-one edge with opposite endpoint displacement
signs. It admits no allowed move. Every possible history ends in one of
these stuck states. Terminal splitting into two singleton/rank-one-pair
groups cannot have been overlooked: such a split would force either a zero
singleton displacement or an equal-capacity opposite-sign pair, neither of
which occurs at any state.

The certificate is `FORCED_PREFIX_OBSTRUCTION.json`. It records every state
and every outgoing pair/exhaustion/child transition. A separate verifier
within the script reconstructs all gradients from physical nodal data,
reconstructs all states from incoming transitions, computes actual physical
means, evaluates `det(A_i-M)` directly, and recomputes maximal capacities
from `q_i=-f_j/(f_i-f_j)`. It checks all legal moves, all incoming equality
conditions, every balance identity and every stated stuck condition. Thus
the verifier does not merely repeat the constructor's `D w` update formula.
Cryptographic weight hashes are additional transport checks; every merged
weight vector is compared exactly, so hash collision resistance is not a
mathematical premise.

## The all-values open box, rather than a finite-sample extrapolation

There is already a qualitative openness argument: finitely many strict
nonzero rational expressions are evaluated along all histories, so all
signs persist in some neighborhood of the center. The additional script
`open_failure_box.py` supplies an explicit full-dimensional neighborhood.

It independently reconstructs interval atom matrices from the twelve input
intervals of radius `2^-32`, using the same outward integer-grid arithmetic
described in `REVIEW.md`. For every one of the thirteen zero pairs, all
scalar-hat gradient differences are checked mutually parallel, so these
zero determinants are universal polynomial identities. The intervals for
all thirty-two remaining pair determinants strictly exclude zero throughout
the box. The available rank-one graph is consequently exactly the same
thirteen-edge graph for every datum in the box.

The verifier then propagates interval weights through the complete finite
certificate. Every active mass stays strictly positive, every load keeps
its displayed strict sign, and every maximal-capacity comparison retains
its displayed strict direction. An important dependency issue is handled
explicitly: when several incoming histories reach the same state at the
center, their rational weight functions need not agree away from the
center. The interval state takes the componentwise hull of every incoming
weight enclosure before processing outgoing transitions. It therefore
covers all histories at every datum, without identifying those functions
or assuming independent intermediate weights.

The recorded topological order puts all parents before every child. At each
state the strict load signs certify the complete list of eligible pairs;
same-sign edges stay ineligible and no zero displacement appears. The
strict capacity signs certify the same exhausted endpoint and the same
next support on every allowed edge. Induction over this graph proves that
every permitted history at every datum in the box follows the certificate
and eventually gets stuck. `OPEN_FAILURE_BOX.json` retains all nonedge,
state-load and positive-mass interval enclosures. This is a simultaneous
all-values exclusion proof, not a perturbation sample.

## Positive original-law control and exact limitations

The original thirteen-atom physical law at this center does have a
twenty-two-leaf positive laminate. A fresh independent full-law search and
physical replay are retained in `UNRESTRICTED_POSITIVE_CONTROL.json`.
It first peels the full face zero, but then peels the whole face six
together with only part of face one:

```
face1 mass 1836202/16114575,
face6 mass 1/25.
```

The next packet uses the remaining face-one mass with part of face two.
All twenty-one binary jump determinants are exactly zero, the root is
zero, all terminal masses are positive, and all physical face totals are
exactly preserved. This control directly prevents interpreting the
restricted failure as a counterexample to lamination of the original law.

The ten-atom residual after the forced prefix may have another finite or
limiting laminate representation. This certificate does not decide that.
Likewise it does not exclude a dense cover using other original-law
prefixes, more complex packets, or another uniform twenty-two-leaf tree
grammar. The only density claim refuted here is density of the stated
forced-prefix maximal singleton/pair construction.

As an additional finite diagnostic, the independent search tested 120
constructed actual rational fields from six varied families. Four exhausted
the forced-prefix restricted search, and all 116 successes had exact physical
replays. The producer's independent direct-mean solver confirmed those four
residual failures without budget exhaustion, while its full thirteen-atom
solver succeeded. These finite results motivated the certificate; they are
not the reason the explicit open-hole theorem holds.

This is an internally derived mathematical obstruction to one proposed
construction. Historical novelty and independent external acceptance are
unknown. No physical acquisition or experiment occurred. The complete
center construction/direct verifier ran in under one second; the all-DAG
interval replay also ran in under one second on this host. Those body
timings exclude discovery, review and source-reading costs.
