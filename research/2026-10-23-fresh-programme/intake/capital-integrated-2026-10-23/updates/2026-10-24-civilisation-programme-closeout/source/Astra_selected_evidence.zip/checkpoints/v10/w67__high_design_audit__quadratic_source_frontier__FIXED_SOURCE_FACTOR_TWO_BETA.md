# Fixed-source extension to a factor-two interval in beta

W67, 24 October 2026. NEW component candidate; fresh review pending.
The root agent proposed the k=1/(10b0) parameter change and signed
response below. W67 independently reconstructed the inherited moment,
normalization, entropy and full-operator correction transfers before
freezing this file. The source family and operator theorems remain the
earlier W56/pinned-source work. No source authorship or novelty is inferred.
The frozen factor-two-b theorem90f0882f and all older rows are unchanged.

Public input: rational 0<b0<=1/65536. Define

    k=floor(1/(10b0)), r0=b0 k, t0=v_k b0^2,
    gamma=4/25, delta=t0/18,
    X=-gamma b0 H_k, B=(I+X)_+, N=(-I-X)_+,
    D=pin_COMPLETE_PATTERN(B), J=D^(-1/2), F=JBJ,
    T=I+(4delta/k)(Q-k/2), rho0=sigma T F.             (V1)

The ACTUAL fixed unknown parameter can lie anywhere in

    b in[b0,4b0], equivalently beta in[beta0,2beta0]. (V2)

All source, table and encoder operations depend only on b0. There is
no calibrated actual label, backward message or duplication of an
unknown logical state. Uniform compound-code events and native totals
are separate obligations, rather than implicit in this source lemma.

## 1. Parameter, positivity and normalization checks

For the actual historical H_k, use the explicit inherited premises in
the fixed-b theorem90f0882f: the causal full-operator F_k response,
all-coherence norm bound, complete-pattern pinching and even endpoint
moments. The precise sources are W56 CLIPPED_AFFINE_PROOF_V1.txt
(d5e0c944), CAUSAL_CLIPPED_LOWER_V4.txt (b37eccac),
CAUSAL_PREFIX_RESPONSE_V4.txt (f1b3dadb), and pinned Cycle10
COMPLETE_PROOF.tex.txt (1759b20d). A new parameter choice is proved
below; the old V4 theorem is not invoked outside its stated k choice.

Here k>=6553 and 1/12<=r0<=1/10. The inherited collision expression
for v_k gives nu=v_k/k^2>=3/25. For example its elementary lower bound
[1-1/k-sqrt(2/k)]/8 suffices: k>=6553>5000 gives sqrt(2/k)<1/50 and
1/k<1/5000, and (1-1/50-1/5000)/8>3/25. Also nu<=1/8. Thus

    1/1200<=t0<=1/800,
    1/250<u=||X||_(2,sigma)<6/1000,
    eta=||T-I||=t0/9<=1/7200.                       (V3)

Exactly as for the original normalized positive-part construction,
D=I+pin(N)>=I, F>=0, pin(F)=I. Every factor commutes with Q and sigma;
T is a positive function of Q. Consequently rho0 is a normalized PSD
density, pin(rho0)=sigma T and Tr[(Q-k/2)rho0]=delta. No condition on
the spectral norm of X is asserted. The source uses the actual nonlocal
H, including spectator colour permutations.

## 2. Clipping tails at the changed temporal scale

For every even m, the inherited conditional and weighted moments are

    0<=pin(H^m)<=(2m-1)!! k^m I,
    Tr sigma H^m <=(2m-1)!! k^m/8.

Let c_j=j^j(20-j)^(20-j)/20^20. Spectral calculus gives

    d0=||pin(N)|| <=c_1 A20,
    ||N||_2^2 <=c_2 A20/8,
    ||N||_4^4 <=c_4 A20/8,
    A20=39!!(gamma*r0)^20.

Now gamma*r0<=2/125, half the old V4 upper4/125. Hence A20 is at most
the old bound divided by2^20. The old exact scalar comparisons yield

    d0 <10^-8/2^20,
    ||N||_2 <9*10^-6/2^10,
    ||N||_4 <13*10^-4/2^5.                          (V4)

With u as in(V3), the exact congruence/pinching estimate gives

    e=||F-I-X||_2 <=d0*u+||N||_2
      <460800003/52428800000000000 <10^-8,
    e/u<1/800.                                     (V5)

This is a direct proof for the new r0 range, not reuse of V4's former
lower bound u>9/1000.

## 3. Weighted variance and global entropy

For Y=TF-I, weighted diagonal/offdiagonal orthogonality gives

    ||Y||_2^2/t0
      <=(1+eta)^2 gamma^2(1+e/u)^2+t0/(81k)
      <(1+1/7200)^2(4/25)^2(1+1/800)^2
                                       +1/(800*81*6553)
      <257/10000.                                   (V6)

The fourth-moment triangle bound is
||F-I||_4<=(105/8)^(1/4)*gamma*r0+2||N||_4.
The factor1/r0 in this estimate is now at most12, rather than6, but
the N fourth norm improved by32. Thus that tail term improves by16.
Using (105/8)^(1/4)<39/20, sqrt(k)>80 and the conservative old diagonal
tilt bound gives explicitly

    ||Y||_4/r0
      <(1+1/7200)[(39/20)(4/25)
                        +2*(13/10000)*12/32]+1/(270*80)
      =270487957/864000000 <328/1000.                (V7)

This checks the nontrivial entropy interface affected by the changed
block length. All eigenvalues remain covered by the original global
inequality

    (1+y)ln(1+y)-y <= y^2/2-y^3/6+y^4/3, y>=-1.

The same Holder argument therefore gives the conservative old bound

    D_2(rho0||sigma)/t0
      <[(257/10000)/2
           +(161/1000)(328/1000)^2(29/10)/30
           +(328/1000)^4(25/3)/75]/(69/100)
      =277917203/12128906250.                       (V8)

It is safe to use the old r<=1/5 in this displayed relaxation, since
r0<=1/10 only reduces the cubic and quartic terms. The constants
sqrt(257/10000)<161/1000, 1/sqrt(nu)<29/10 and1/nu<=25/3 are unchanged.
The exact charge identity S_2(rho0)-3k/2=t0/18-D_2(rho0||sigma) and

    1/18-277917203/12128906250-1/31
        =72166166/187998046875 >0

prove S_2(rho0)>=3k/2+t0/31. Rare large or zero relative eigenvalues
are not excluded by this argument.

## 4. Full operator drift at the ACTUAL parameter

Write x=b/b0 in[1,4]. The inherited causal response is

    D_b(sigma H)=ab F_k(b),
    F_k(b)>=v_k[1-(103/72)bk] I.

Since bk<=x/10, the concave quadratic
h(x)=x-103x^2/720 has endpoint values

    h(1)=617/720, h(4)=77/45>617/720.

Hence for every actual parameter in(V2),

    D_b[sigma(T+X)]
      <=a*t0[1/9-(4/25)*(617/720)] I
      =-a*t0*(13/500) I.                            (V9)

The actual offdiagonal correction Yoff=T(F-I)-X has zero COMPLETE
pattern pinching. Its weighted norm satisfies

    ||Yoff||_2/t0 <=(1+1/7200)*1200*10^-8+(6/1000)/9
                       =407201/600000000.           (V10)

The all-coherence response applies at the actual r=bk<=2/5 and gives
L(r)=r exp(2r^2)<=10/17. Also a>=1-4/65536=16383/16384. Thus

    D_b(rho0)<=-t0*C I,
    C=(16383/16384)*(13/500)
                      -(10/17)*(407201/600000000)
      =393203657/15360000000 >1/40.                 (V11)

The inequality holds on every coherent or entangled bulk bath prefix,
tensor identity on seed and untouched tail. Actual calls are neither
skipped nor classicalized. The root is separately retained in the
unchanged cutoff/Lyapunov theorem.

## 5. One fixed regularized source over the full beta interval

Define rho_*=(rho0+sigma)/2 and its analytic M_*=sigma^(-1)rho_*.
Entropy concavity, exact D_b(sigma)=0 and(V3),(V6),(V8),(V11) imply

    S_2(rho_*)>=3k/2+G_beta, G_beta=1/74400,
    D_b(rho_*)<=-Kappa_beta I, Kappa_beta=1/96000,
    Tr sigma(M_*-I)^2<=257/32000000<1/100000,
    M_*>=I/2, [rho_*,Q]=0.                          (V12)

These hold SIMULTANEOUSLY for beta in[beta0,2beta0]. There is only
one reference source and table. The explicit acquired positive-part,
input-pattern normalizer, regularization/log and filter circuits still
have the same algebraic form; they use b0 and the new finite k. An
inverse sigma or spectral basis is not provided as an oracle.

The mesoblock/high-design/public-prefix encoder and common Fourier
receiver can use these new constants after regenerating all finite
guards, including the continuum grid Markov event. The band length in
theta is<1, so the old analysis grid cardinality bound remains safe.
The native/source/receiver precision and shared-program costs must all
be recomputed; old rows are not reused.

If the new rate guard preserves excess G_beta/(16k), then

    G_beta/(16k)>=b0/119040>=b_actual/476160.        (V13)

Thus this source lemma addresses a full factor-two-beta supplied public
uncertainty without sender calibration.
It is not yet an independently reviewed complete code theorem. The
public lower endpoint is supplied information; its discovery, time-varying
gain, unsupported physical native-error floors and absent public-program
transport are not silently resolved. No physical operation was performed.
Priority UNKNOWN; practical advantage NOT_ESTABLISHED; mission
NOT_ACHIEVED.
