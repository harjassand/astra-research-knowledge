# A direct rational9D source for quartic positive excess

23 October2026. Internal exact finite-source construction for the unchanged
device. This avoids the general H_k endpoint-access and pinch-normalization
factory premises. It is not claimed a new capacity source: two-port coherent
pair mechanisms and the quartic lower-gain baseline already occur in the
inherited programme. Its use here is an explicitly costed simple source for
a complete polynomial-onset randomized code.

## 1. Explicit density and spectrum

For0<=b=beta^2<=1, a=1-b, use two qutrits, q=diag(0,1,1),

    sigma=diag(1/2,1/4,1/4)^tensor2,
    Q=q_1+q_2, A=Q-I,
    H=(1/2)sum_{c=1,2}(|0c><c0|+|c0><0c|),
    x=b/12, u=b^2/60,
    rho=sigma M, M=I+uA-2xH.                         (P1)

Every matrix is9-by-9. Sigma,M commute with Q and with each other. On
span{|0c>,|c0>} the M block is[[1,-x],[-x,1]]. Its remaining blocks are
1-u on|00> and1+u on the four doubly excited states. Therefore the exact
rho eigenvalues, in a KNOWN b-independent eigenbasis, are

    (1-u)/4                       multiplicity1,
    (1+x)/8 and(1-x)/8             multiplicity2 each,
    (1+u)/16                      multiplicity4.      (P2)

The basis consists of|00>, the four|cd> withc,d nonzero, and
(|0c>+/-|c0>)/sqrt2. All eigenvalues are at least1/16 for b in[0,1].
They sum to1. Thus rho is an actual full-rank positive, normalized,
charge-preserving density. No formal signed affine input is substituted.

## 2. Exact bulk response on the full bath prefix

For the actual two-call ordered physical unitary W_2, let

    G_beta=Q-W_2*QW_2,
    D_b(Z)=Tr_input[(Z tensor I)G_beta].

At initial depth>=2, both pre-call depths are nonroot, and only the first
two initial bath colors can participate. The seed and all later word
colors are untouched identities in the charge-pinched bounded response.
The following are full4-by-4 OPERATOR identities on that prefix, including
all color coherences:

    D_b(sigma)=0,
    D_b(sigma A)=a I,
    D_b(sigma H)=ab I/8.                            (P3)

Here is an exact finite algebra procedure specifying and certifying(P3),
independent of a scalar bath or iid approximation. Enumerate all9 input
words, all4 prefix color words, and all4 U/I masks. Apply the actual ordered
push/pop word, combining amplitudes before taking matrix elements. For
row/column histories with s,t stays, total-input-charge pinching enforces
s+t even. Their real amplitude product is

    sign * a^(2-r) b^r, r=(s+t)/2,
    sign=+1 ift-s is0mod4, else-1.

For every matched complete output/final-word pair, multiply by its output
charge, negate, and add the diagonal input Q. The three polynomial
coefficient vectors are(1,-2,1),(0,1,-1),(0,0,1) forr0,1,2 respectively.
Contract the resulting COMPLETE36-by-36 matrices against sigma,sigma A,
sigma H. Exact coefficient matrices are respectively

    (0,0,0), (1,-1,0)I_4, (0,1/8,-1/8)I_4.

`check_rational_pair_source.py` implements this144-history enumeration
using only integer/Fraction algebra and records every contracted coefficient
in `RATIONAL_PAIR_SOURCE_IDENTITY.json`. This certifies the identity for
ALL b, rather than fitting finitely many b values. Finite propagation and
charge conservation identify this complete prefix representation with the
whole bulk operator at every initial depth>=2. The actual root is retained
outside this bulk premise by the separate Lyapunov/reset/decoder proofs.

Linearity of(P3) now gives the exact complete drift

    D_b(rho)=a(u-xb/4)I= -ab^2 I/240.                (P4)

It is strictly inward for0<b<1. No bath expectation or favorable initial
color state is selected. Atb1 the physical channel is identity and is
handled directly; atb0 the colored-Dyck baseline remains separate.

## 3. Rigorous entropy and variance with rational margins

Direct traces in the known basis give

    Tr(rho A)=u/2=b^2/120,
    Tr(rho A^2)=1/2,
    chi^2=Tr[sigma(M-I)^2]=(u^2+x^2)/2
          =b^2/288+b^4/7200,
    Var_rho Q=1/2-(u/2)^2.                          (P5)

The exact relative-entropy identity is
S_2(rho)-3=Tr(rho A)-D_2(rho||sigma). The scalar inequality
z lnz-z+1<=(z-1)^2 yields D_2<=chi^2/ln2. Since ln2>2/3,

    S_2(rho)-3
       >=u/2-(3/4)(u^2+x^2)
        =b^2/320-b^4/4800
       >=7b^2/2400 >=b^2/384, 0<=b<=1.             (P6)

Consequently a completely rational modular interface is

    k=2, g0=b^2/384, kappa=ab^2/240,
    Xi=b^2/288+b^4/7200,
    Upsilon=1/2-b^4/14400.                          (P7)

The exact spectrum, not a continuity extrapolation, proves positivity.
The chi-square bound is a separately computed weighted L2 square, not
deduced from entropy. The explicit finite polynomial source checks agree
with all the displayed moments and full drift coefficients.

## 4. Direct source circuit

Prepare a known9-term probability distribution(P2), coherently copying
its label to a local purification register, then apply the fixed basis
change for the four plus/minus vectors. Binary interval rotations require
only a constant number of rotations, with rational probabilities computed
from b. Square roots and angle synthesis to eta cost polynomial work and
gates in L_b+log(1/eta), using a fixed inverse-closed universal gate basis.
There is no H oracle, rectangular access, QSVT, source eigenbasis acquisition,
exponentially small success branch, or bath operation in this source factory.
Its inverse preparation is the reverse of its known local circuit.

All helpers are locally prepared encoder systems. The complete code must
still preserve arbitrary unknown logical inputs. It therefore uses the
subsystem/high-design encoder and retained-output digital decoder, not
the source preparation alone. Physical calibration, noise, hardware,
energy and wall time are unacquired. Novelty and practical advantage
remain UNKNOWN; mission NOT_ACHIEVED.
