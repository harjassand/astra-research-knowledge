# Two communication cuts with arbitrary initial memory entanglement

23 October 2026. W19 invented the zero-perturbation argument. Root independently reconstructed it and derived the all-beta spectral extension below. W64 has been assigned a fresh critical review. This is a candidate mathematical weak converse until that review is reconciled. It is not a CP domination or strong-fidelity theorem.

The device, units and port basis are the unchanged pinned recurrent-tree model. The initial logical reference (R) and logical input are independent of the entire preexisting resource. That resource may contain arbitrary normal entanglement among memory (E), Alice and Bob, and arbitrary preshared entanglement between the laboratories. Alice may perform arbitrary causal encoding and receive free backward quantum communication. Exactly (N) forward device uses are counted; no external forward carrier is allowed. All failure branches remain. Classical strategy randomness is included in laboratory registers.

Let (A_t) denote the qutrit just before it enters the device and (B_t) the qutrit just after it exits. Assign the memory first to Bob's side of a communication cut. Alice's transmission of (A_t) across this cut increases mutual information with (R) by at most (2S(A_t)): for any receiver register (C), (I(R:A_t\mid C)\le2S(A_t)). Operations on the receiver's side and backward transmissions to Alice cannot increase the receiver's mutual information with (R). Initial receiver resource is independent of (R). Therefore

\[
I(R:B_{\rm final})\le2\sum_t S(A_t).
\]

For the second cut assign the memory to Alice's side. The only forward transmissions are now (B_t). By the same chain-rule argument,

\[
I(R:B_{\rm final})\le2\sum_t S(B_t).
\]

These arguments do not assume that the bath or laboratories are mutually independent. They do require that the fresh logical reference has no initial information in the preexisting resource. Infinite-dimensional memories may be treated by normal finite-rank approximations and lower semicontinuity; each transmitted system is finite-dimensional and has entropy at most (\log_2 3). A final formal audit should state the corresponding normal-strategy limiting argument explicitly.

Put (q=\mathrm{diag}(0,1,1)), (u_t=\operatorname{Tr}q\rho_{A_t}) and (v_t=\operatorname{Tr}q\rho_{B_t}). The maximum qutrit entropy with colored probability (u) is

\[
f(u)=h_2(u)+u.
\]

This follows by binary-sector pinching and uniformity within the two-dimensional colored sector. No such pinching is performed by the code; it is just an entropy upper bound on its actual marginal.

At beta zero, direct multiplication of the original (U\) gives

\[
U^*(q\otimes I)U=|0\rangle\langle0|\otimes(I-P_0).
\]

Thus (u_t+v_t\le1) for **every joint port/memory/laboratory state**, including initial bath entanglement and adaptively prepared correlations. Concavity, symmetry, and monotonicity of (f(s)) on (s\le1/2) give

\[
S(A_t)+S(B_t)\le f(u_t)+f(v_t)\le2f(1/2)=3.
\]

Combining the cuts,

\[
I(R:B_{\rm final})\le2\min\{\sum_tS(A_t),\sum_tS(B_t)\}
 \le\sum_t[S(A_t)+S(B_t)]\le3N. \tag{1}
\]

Reliable rank-(K_N) quantum transmission has (I(R:B_{\rm final})\ge 2\log_2K_N-o(\log K_N)-o(1)), by continuity around its target Bell state. Since the finite-port cut already gives (\log K_N=O(N)) along reliable codes, (1) implies the weak rate ceiling (\limsup N^{-1}\log_2K_N\le3/2). The familiar fixed-normal product-resource lower attains (3/2), so the *supremum* over allowed initial resources cannot exceed or improve that value at beta zero. This does not assert a uniform lower for every adversarial initializer family.

## Root's all-beta extension

Let (V=\sqrt a\,U+i\sqrt b\,I), (b=\beta^2\), (a=1-b\), (0\le\beta\le1\). Define

\[
M=q\otimes I+V^*(q\otimes I)V.
\]

The original (U\) matches every colored-port/bath state to a vacuum-port/nonroot-bath state. On each matched two-dimensional subspace choose Pauli coordinates with (q=(I+Z)/2\) and (U=X\). Then, up to the immaterial sign of (Y\),

\[
M=I+bZ+\sqrt{ab}\,Y,
\]

whose eigenvalues are (1\pm\sqrt{b^2+ab}=1\pm\beta\). The unmatched vacuum-port/root-bath subspace has (q=V^*qV=0\), even though (U\) flips its seed. Hence globally (M\le(1+\beta)I\). The decomposition includes all seeds and depths and uses no root approximation.

For (0\le\beta\le1/3\), (u_t+v_t\le1+\beta\), concavity and monotonicity up to (2/3\) yield

\[
S(A_t)+S(B_t)\le2f((1+\beta)/2).
\]

The arbitrary-resource weak capacity ceiling is therefore

\[
Q\le f((1+\beta)/2)
=h_2((1+\beta)/2)+(1+\beta)/2,\quad0\le\beta\le1/3,
\]

and the generic qutrit ceiling (\log_2 3\) applies thereafter. Near zero this upper is (3/2+\beta/2-\beta^2/(2\ln2)+O(\beta^4)\). The stronger quadratic product/separable-initial-resource ceiling remains preferable under its own hypotheses. This extension only delimits a possible correlation-assisted gap; it supplies neither an attaining code nor an entanglement preparation mechanism, advantage, or physical validation.
