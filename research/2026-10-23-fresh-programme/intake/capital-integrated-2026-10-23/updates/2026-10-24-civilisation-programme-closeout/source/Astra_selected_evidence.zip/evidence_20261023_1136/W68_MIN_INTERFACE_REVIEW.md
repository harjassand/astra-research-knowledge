# Fresh reconstruction of the minimal-interface joint-return frontier

23 October 2026. Reviewer: W68. Internal mathematical review, not external
validation. Source bytes were read afresh after the earlier bath and entropy
audits; none of those earlier verdicts was transferred to this result.

Frozen source: W40 `MINIMAL_INTERFACE_JOINT_RETURN.md`, SHA256
`c9b03de5cc0fe062fc15bc272376f23d30cad20bb3a92add79d982db95d2b2df`.

Verdict: **PASS at the stated asymptotic scope; no mathematical gap found.**
The finite diagnostic bounds in section 7 below are a reviewer reconstruction,
not a change to the frozen source or a claim of finite-r optimality.

## 1. Reconstructed contract

For a sequence of integers r tending to infinity, N=r^3. Physical diagonal
rank-r system projections P,Q overlap in the rank-one projection u; their
binary trace-preserving scalar-block expectations are E_P,E_Q. The projections
P,Q commute, while the two expectations do not. Let K be any positive integer,
and let F,G be trace-preserving conditional expectations onto arbitrary unital
star subalgebras of M_(NK), with FG=GF exactly. All Hilbert-space traces are
ordinary traces. D=Tr_A is the ordinary ancilla trace, and J(X)=X tensor I_K/K.

The two channel errors are UNHALVED diamond norms, including arbitrary external
references:

    epsilon=max(||DF-E_P D||_diamond, ||DG-E_Q D||_diamond),
    delta=max(||FJ-JE_P||_diamond, ||GJ-JE_Q||_diamond).

The assumptions are epsilon=O(1/r) and lambda=K^2/r<=Lambda for a fixed finite
constant Lambda. The conclusion is lambda>=1-o(1) and

    delta >= 2/lambda-o(1).

All little-o terms are along such a sequence; they may depend on the fixed
epsilon and lambda upper-bound constants. At K=(1+o(1))sqrt(r), the conclusion
and the universal upper bound delta<=2 imply delta tends to TWO. This does not
determine an attained tradeoff for other fixed lambda, or a finite-r optimum.
No exact event membership, abelian range, internal separability, or selector
form of F,G is assumed. The final witness input requires no external reference.

## 2. First and common output entropy budgets

Set rho=u tensor I_K/K, A=F(rho), B=G(rho), omega=FG(rho), sigma=D(omega),
m=rK and m0=N/K. Recovered trace distance epsilon puts mass at least
1-epsilon/2 of A in P_L=P tensor I_K, and similarly B in Q_L. Pinching and
maximizing entropy inside each of those two blocks gives

    S(A),S(B)<=log m+h(epsilon/2)
                  +(epsilon/2)log(r^2-1)=log m+o(1).

The binary entropy expression is monotone in the relevant leakage interval
for all sufficiently large r. The block dimension ratio is r^2-1, so the
ancilla dimension cancels; no product form for A or B was presumed.

The common state is fixed by F and G. Applying the FULL enlarged-domain
marginal bound to that possibly correlated state gives residuals at most
epsilon for both E_P and E_Q on sigma. For traceless Hermitian X,

    E_P E_Q X = c Tr(QX) [P/r-P_perp/(N-r)], c=1/(r+1),
    ||E_P E_Q X||_1 <= c||X||_1.

Here ||P/r-P_perp/(N-r)||_1=2 and |Tr(QX)|<=||X||_1/2. The residual for
sigma-E_P E_Q sigma is at most 2epsilon. Thus
TV(sigma,I/N)<=epsilon/(1-c), and entropy continuity gives
S(sigma)>=log N-o(1). This is the step not licensed by a guarantee only on
prepared hot product inputs.

Araki--Lieb gives S(omega)>=log m0-o(1). Conditional-expectation data
processing gives the commuting-square inequality

    S(A)+S(B)>=S(rho)+S(omega)=log K+S(omega).

Consequently lambda>=1-o(1),
S(A),S(B)>=log m-log lambda-o(1), and
S(omega)<=log m0+log lambda+o(1). The bound K^2<=Lambda r ensures all
ambient entropy continuity factors are O(log r), and also bounds log lambda
above and asymptotically below.

## 3. The order bound and noncommuting smoothing

The universal order bound omega<=K(sigma tensor I_K) is valid. A direct
mixed-state proof first uses positivity and block Cauchy--Schwarz to show
omega<=K sum_a |a><a| tensor omega_aa. Each diagonal block obeys
omega_aa<=sum_b omega_bb=sigma. Equivalently the pure-state inequality
follows from the at-most-K Schmidt terms and extends by linearity. There is
no missing reference dimension in this inequality: the bipartition is S:A.

Put beta=r^(-1/4) and retain the sigma eigenvalues at most (1+beta)/N. If b
is discarded mass, each discarded eigenvalue l has
l-1/N >= beta l/(1+beta), hence b<=((1+beta)/beta)TV=O(r^(-3/4)). The
normalized compression chi of omega has trace distance at most
2sqrt(b)+b, whose product with log(NK) vanishes. It obeys

    chi <= b_r I/m0, b_r=(1+beta)/(1-b)=1+o(1),
    S(chi)<=log m0+log lambda+o(1).

Neither a common eigenbasis nor a noncommuting common positive part is used.
Both statements follow from compression, the preceding order bound, and
entropy continuity.

## 4. Spectral support belongs to the common algebra

If mu_i are chi's eigenvalues, every term in

    sum_i mu_i log[(b_r/m0)/mu_i]
       =S(chi)-log(m0/b_r)<=log Lambda+o(1)

is nonnegative. Eigenvalues below x=1/(m0 r^(1/3)) therefore carry o(1)
total mass. They can be removed with a subspace of rank at most 1/x.
Ky Fan plus trace distance transfers the top-M mass to omega, where
M=ceil(1/x); it does not transfer individual eigenvectors.

For y=1/(m0 r^(2/3)), set W=1_[y,infinity)(omega). The top M eigenvalues
below y have mass at most My<=r^(-1/3)+1/(m0 r^(2/3))=o(1). Thus

    Tr(W omega)=1-o(1), rank W<=m0 r^(2/3).

Since omega lies in the common unital star algebra, its whole spectral
projection W lies there as well, including at eigenvalue degeneracies.
Therefore F(W)=G(W)=W. Self-adjointness of tracial expectations now gives
Tr(WA)=Tr(WB)=Tr(Wrho)=Tr(Womega). No chosen partial eigenspace or
commutation with physical P_L,Q_L enters.

## 5. Entropy forces a large physical rare-event fraction

Normalize the P_L compression A_P. Its trace distance from A is O(sqrt(epsilon)),
so its entropy differs by o(1), again because log(NK)=O(log r). The earlier
lower entropy bound gives

    D(A_P || P_L/m)=log m-S(A_P)<=log lambda+o(1).

Measuring W on these two states is a legitimate binary measurement although
W need not commute with P_L. For a=Tr(W A_P)=1-o(1) and
w=Tr(W P_L)/m, binary relative entropy is at least
a log(1/w)-h(a). Hence w>=1/lambda-o(1); bounded lambda makes the
exponentiation uniform. The identical reasoning for B gives
Tr(W Q_L)/(rK)>=1/lambda-o(1). Relative entropy has been taken on P_L's
support, so the zero eigenvalues of the reference outside P_L pose no issue.

## 6. A legal prepared hot input gives the unhalved error

T=P_L Q_L has rank K. For the hot input
rho_B=(Q_L-T)/((r-1)K), the preceding Q fraction yields

    Tr(W rho_B)>=(r/lambda-1)/(r-1)-o(1)=1/lambda-o(1).

F fixes W, so its output has the same W probability. The ideal target is
(I-P_L)/((N-r)K). Its W probability is at most

    rank W/((N-r)K)
       <= [N/(N-r)]r^(2/3)/K^2=o(1).

The last use of lambda>=1-o(1) is valid. Trace distance between normalized
outputs is at least TWICE the difference of these effect probabilities,
giving delta>=2/lambda-o(1). The input is a system density tensor the hot
ancilla. This proves the asserted full joint-return consequence with no
inaccessible input or additional decoder.

## 7. Optional explicit finite residual bound for diagnostics

All quantities below use base-two logarithms. Define the entropy-continuity
function f_d(t)=h(min(t,1-1/d))+min(t,1-1/d)log(d-1). Let

    p=epsilon/2, t=min(1,epsilon/(1-c)), d=NK,
    e=h(p)+p log(r^2-1), u=f_N(t),
    b0=((1+beta)/beta)t, nu=2sqrt(b0)+b0,
    bbar=(1+beta)/(1-b0),
    R=log lambda+2e+f_d(nu/2)+log bbar,
    ell=R/log(bbar r^(1/3))+nu/2+r^(-1/3)
                                          +1/(m0 r^(2/3)),
    g=2sqrt(p)+p, a0=max(0,1-ell-g/2),
    D0=log lambda+u+e+f_d(g/2).

These formulas apply when p<=1-1/r^2, b0<1, nu<=2, and the displayed
entropy bounds are evaluated in their valid intervals. R,D0 are nonnegative
for any actual admissible fixture; rounding-safe upper bounds can replace
them. If a0>0, let hmax=h(a0) for a0>=1/2 and hmax=1 otherwise, and put
w0=2^(-(D0+hmax)/a0). Then an explicit valid consequence is

    delta >= 2 max(0, (r w0-1)/(r-1)
                           - [N/(N-r)]r^(2/3)/K^2).

For a0=0 this reconstruction yields only delta>=0. The common lambda bound
is also explicit: log lambda>=-u-2e. Along the source's sequences every
residual vanishes and w0=1/lambda-o(1). This bound is deliberately loose at
small r; it is not a claim about affordable scales or exact finite optima.

## 8. Falsifiers and remaining scope

A sequence satisfying the exact hypotheses with liminf(lambda delta)<2
would falsify the source. Replacing full-domain marginal control by a
prepared-input condition, letting lambda grow without bound, or allowing a
nonzero commutator does not test this theorem. The existing Fourier-flat
construction supplies the leading lambda=1 endpoint but not an attained
curve at lambda>1. Standard entropy, spectral and data-processing ingredients
are prior mathematics; the parameter-specific consequence has UNKNOWN
historical priority. No physical usefulness, external acceptance, efficient
implementation or mission completion follows from this internal PASS.

## 9. Independent finite challenges retained

`check_minimal_interface_return.py` passed 1,523 assertions. It independently
tested 144 random mixed/pure cases of the universal order bound and actual
noncommuting compressions; 160 noncommuting physical-support/witness pairs for
relative-entropy data processing; the full commuting Fourier-flat fixtures at
r=2,3,4; and 100-digit evaluations of the explicit residual formulas through
r=10^96. The largest positive numerical violation was 8.13e-16, within the
declared floating tolerance. The actual hot-B trace distances were 4/3, 3/2
and 8/5, as independently computed from the declared channels.

These are diagnostic challenges, not substitutes for the proof above. For
fixed lambda>1 the support extraction used here loses O(1/log r) mass, so
the residual bound approaches 2/lambda slowly. An initial diagnostic demand
for 1e-15 agreement at r=10^96 was unsupported and was removed; the corrected
check tests convergence without imposing that false rate. The theorem and
the finite inequality were unchanged. No practical convergence scale is
inferred from these evaluations.
