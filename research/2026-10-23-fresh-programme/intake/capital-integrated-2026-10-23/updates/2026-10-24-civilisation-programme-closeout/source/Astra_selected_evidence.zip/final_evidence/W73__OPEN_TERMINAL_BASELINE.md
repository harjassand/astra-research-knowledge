# Opening unused terminals erases the hidden-star action separation

24 October 2026. A proved ordinary comparator on an explicitly changed
interface. This is not a contradiction of frozen455c, whose unselected
terminals retain r0, nor an acquired instrument or a novelty claim.

## Interface and statement

The unknown labelled positive forest is the same hidden-two-star family:
n=2d+2, d>=1, two unknown equal hub/leaf components, every leaf weight in
[a,3a], and an optional hub edge of known weight a. The task is connectivity.
Hubs, component labels and weights are unknown to the learner. A graph is
fixed before the learner's randomness.

Grant one new capability: every unselected terminal can be perfectly
open-circuited, with zero DC leakage; wait until the actual circuit has
settled. Two selected terminals p,q connect through ordinary, fixed series
resistance r0>0 to external rails A>0 and0. All other external port currents
are zero. Read both selected currents with independent N(0,sigma^2) noise
per actual action, independent across actions. To compare conservatively
with full-output acquisition, count n scalar readouts for every action even
though only the selected current is used. Fixed noise, perfect opening,
rail contrast and settling are instrument premises, not device results.

Define

    I_* = Aa/(3+2ar0),
    m = ceil[ln(2/delta)/ln(4/3)],
    T = max{1,ceil[(32sigma^2/I_*^2)ln(4m/delta)]},
    q = mT.                                                   (1)

For every fixed input, the following fully nonadaptive protocol has error
at most delta in(0,1/2). Its number of actual actions is independent of n
at fixed a,A,r0,sigma,delta; its scalar acquisition count is nq; selected
peak mean current is at most3aA. The per-terminal nominal command budget
is pathwise B<=qA^2. There is no high-current hub amplifier.

## Protocol and proof, including finite randomness/ADC

Before any data, choose m independent ordered terminal pairs. A bounded
fair-bit implementation is explicit. Let N=n(n-1), b=ceil(log2 N), draw
J uniformly from{0,...,2^b-1}, and use pair-index J mod N in any fixed
enumeration of all ordered distinct pairs. Every pair has probability
at least1/(2N). This takes exactly mb fair bits; no rejection loop or
exact uniform-pair random oracle is needed.

For each precommitted pair, open every other terminal, apply the two rails
for T actual independent readings, and average the selected p-current.
Declare disconnected if at least one pair average is below I_*/2;
otherwise declare connected.

For a connected tree, the unique path between p and q has at most three
edges, each of resistance at most1/a. Every branch off this path carries
zero settled current because its terminals float. Kirchhoff's laws give

    mean i_p = A/[2r0+sum_{e on path}1/w_e] >= I_*.             (2)

If the core is absent and the pair crosses the two components, each
contacted component has just one external terminal. Its settled current
is exactly zero. The two components each contain n/2 vertices, so there
are n^2/2 ordered cross pairs. Under the finite-bit sampler above,

    P(pair crosses) >= (n^2/2)/(2n(n-1)) >=1/4.

Thus, for every fixed disconnected graph, the chance all m chosen pairs
miss this decisive event is at most(3/4)^m<=delta/2. No hidden metadata
is supplied. Under a connected graph every pair satisfies(2).

For finite response encoding, round currents to grid step I_*/4, error
at most I_*/8 absent clipping. Set an outward-rounded range at least

    H=3aA+sigma sqrt[2ln(8nq/delta)].                         (3)

Every selected mean has magnitude at most3aA: any nonempty path includes
an edge of resistance at least1/(3a). Every open port has zero mean.
The union probability of clipping among nq charged readouts is therefore
at most delta/4. The signed grid index uses

    ceil log2[2ceil(4H/I_*)+1]

bits per scalar. On the no-clipping event a threshold error for a zero
or >=I_* mean requires an averaged Gaussian error of magnitude at least
I_*/4 in the adverse direction. The one-sided tail bound and(1) give

    P(pair threshold error) <=exp[-TI_*^2/(32sigma^2)]
                           <=delta/(4m).

The union over m pair decisions costs delta/4. For a disconnected graph,
missing all cross pairs costs delta/2; a connected graph has no such
failure. Adding clipping proves the uniform error<=delta statement.
At sigma=0 take T=1 and the Gaussian error term vanishes.

All selections, commands and repetitions were committed before any data.
Processing costs O(nq) if all n returned scalars are read/validated and
O(m) besides that; keeping only the relevant running averages uses O(n)
or less working memory. A list of pairs requires O(m log n) bits. With
fixed delta, all q and peak-current bounds above are independent of n;
ADC range grows only through the charged full-readout clipping event.

## Consequence and complete-process limitations

This ordinary continuity comparator has the same O(n) full-scalar order
as the ideal adaptive two-action result. Therefore a practical claim
cannot remove the O(n) gain/current burden of455c by silently granting
perfect opening only to its adaptive protocol. With that grant made to
both algorithms, the hidden-star asymptotic action gap disappears.
This is the familiar series-path/continuity mechanism, not a claimed
new algorithm or a source-priority result.

The settled source power is A*i_p<=3aA^2 per action. This does not give
constant physical energy or wall-clock time: duration, switching,
reset/discharge, sensor averaging and calibration are unpriced here.
In particular, off-state leakage from n nominally floating terminals can
accumulate, and their capacitance can require a growing charging time
when a selected leaf drives the bulk through one conductance-a edge.
Those effects require their own actual circuit/noise/time law. Neither
zero leakage nor a constant settling time is inferred from(2).

The frozen finite-r0 obstruction2e8 and routed-driver candidate455c retain
their original, different contracts. Mathematical comparator: PROVED
conditionally in the interface above. Priority: ordinary baseline/PRIOR.
Physical capability: NOT_ACQUIRED. Practical advantage: UNKNOWN. Broad
mission: NOT_ACHIEVED.
