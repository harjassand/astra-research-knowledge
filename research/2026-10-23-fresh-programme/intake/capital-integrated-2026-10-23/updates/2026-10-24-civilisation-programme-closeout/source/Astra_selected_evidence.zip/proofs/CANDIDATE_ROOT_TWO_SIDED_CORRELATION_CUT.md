# Two-sided correlation penalties and the exact matched-pair rotation

23 October 2026. W19 independently invented the two-sided argument; W64 independently invented the earlier one-sided quadratic bound. Root reconstructed both before receiving their complete proofs. W36 and W64 are freshly attacking the stronger source. This is a candidate mathematical weak converse until those audits are reconciled. Generic conditional entropy, pinching, DPI and scalar Legendre tools are prior.

Use the same fresh-logical, arbitrary-normal-initial-resource, fixed-\(N\), no-extra-forward-carrier contract as the previous cut notes. All entropies are bits.

At the cut placing memory with Bob, a forward input \(A\) increases the receiving side's information by
\[
I(R:A\mid C)\le2S(A)-I(A:E_{\rm pre}),
\]
because \(S(A\mid RC)\ge-S(A)\) and \(C\) contains the actual memory. At the cut placing memory with Alice, the arriving output \(B\) increases Bob's information by
\[
I(R:B\mid C_B)=S(B\mid C_B)-S(B\mid RC_B)
\le S(B)+S(B\mid E_{\rm post})
=2S(B)-I(B:E_{\rm post}).
\]
The nontrivial second inequality is weak monotonicity
\(S(B\mid RC_B)+S(B\mid E_{\rm post})\ge0\): \(RC_B\) and \(E_{\rm post}\) are disjoint systems. It does not assume they purify \(B\), nor that the initial resource is product. Finite transmitted systems make the conditional quantities well defined for normal infinite ancillary systems. Local TP actions and backward messages do not increase either receiver's information. Averaging the two accumulated bounds,
\[
I(R:B_{\rm final})\le\sum_t G_t,\qquad
G=S(A)+S(B)-[I(A:E_{\rm pre})+I(B:E_{\rm post})]/2. \tag{1}
\]

Put \(u=\langle q_A\rangle\), \(v=\langle q_B\rangle\), \(f(x)=h_2(x)+x\), \(d_A=f(u)-S(A)\ge0\), and \(d_B=f(v)-S(B)\ge0\). Let \(\Delta\) pinch only the port's vacuum/colored charge, and define its joint relative entropy of coherence
\[
C_{\rm pre}=D_2(\rho_{AE}\Vert\Delta_A\rho_{AE}),
\quad C_{\rm post}=D_2(\rho'_{BE}\Vert\Delta_B\rho'_{BE}).
\]
The pinching Pythagorean identity against
\(\rho_u\otimes\rho_E\), \(\rho_u=\mathrm{diag}(1-u,u/2,u/2)\), proves
\(C_{\rm pre}\le I(A:E)+d_A\); likewise post-call. These are relative-entropy statements, so no subtraction of infinite entropies is needed. Therefore
\[
G\le f(u)+f(v)-(C_{\rm pre}+C_{\rm post})/2
\le3+d-(C_{\rm pre}+C_{\rm post})/2,\quad d=u+v-1. \tag{2}
\]

Let \(Y=i(Uq-qU)\). On every matched vacuum/nonroot–colored pair choose \(U=X\), \(q=(I+Z)/2\); then \(Y\) is the Pauli \(Y\). It is zero on the unmatched vacuum/root subspace. Write \(y=\operatorname{Tr}Y\rho\) and \(y'=\operatorname{Tr}Y\rho'\). The binary POVM \((I\pm Y)/2\) has a fair outcome law on the port-charge-pinched state. DPI consequently gives
\[
C_{\rm pre}\ge j(y),\quad C_{\rm post}\ge j(y'),
\qquad j(s)=1-h_2((1+s)/2).
\tag{3}
\]
These bounds remain valid at the root and with arbitrary memory entanglement.

For \(V=\alpha U+i\beta I\), \(\alpha^2=a=1-\beta^2\), \(0<\beta<1\), the exact pair rotation is
\[
V^*YV=(2\beta^2-1)Y-2\alpha\beta Z.
\]
Also \(q+V^*qV-I=\beta^2 Z+\alpha\beta Y\) on the matched subspace, and equals \(-I\) on vacuum/root. That root subspace is invariant under \(V\), including its seed flip. With \(r=\operatorname{Tr}[(|0\rangle\langle0|\otimes P_0)\rho]\ge0\),
\[
d+r=\frac{\beta}{2\alpha}(y-y'). \tag{4}
\]
Thus (2)–(4) give, writing \(z=\beta/(2\alpha)\),
\[
G\le3+z(y-y')-\tfrac12[j(y)+j(y')]
\le3+\log_2\cosh[(\beta/\alpha)\ln2]. \tag{5}
\]
The last inequality is the exact binary Legendre transform
\(\sup_{s\in[-1,1]}\{cs-j(s)\}=\log_2\cosh(c\ln2)\), applied separately to \(y\) and \(-y'\). No scalar Pinsker relaxation or port-entropy curvature is needed.

The binary Bell test, with \(\rho_R=I/K\), then yields the candidate finite bound
\[
\boxed{2F_e\log_2K-h_2(F_e)
\le N\{3+\log_2\cosh[(\beta/\sqrt{1-\beta^2})\ln2]\}.}
\]
Reliable rate is at most
\[
Q\le\min\{\log_2 3,\;
3/2+\tfrac12\log_2\cosh[(\beta/\sqrt{1-\beta^2})\ln2]\}.
\]
The excess has expansion \((\ln2)/4\,\beta^2+O(\beta^4)\). At beta zero the earlier exact \(3/2\) cut applies; beta one is the identity endpoint. Unlike the previous product/SEP CP order, this bound allows arbitrary horizon-dependent initial bath–laboratory entanglement. It is a weak converse, with no exponential fidelity conclusion. It removes the possible linear-beta rate escape but neither determines the exact quadratic coefficient nor constructs a resource-assisted code. Physical interaction/acquisition, novelty and mission achievement remain unestablished.
