# An explicit quadratic collision annihilator for every deficit below L

Version1, 23 October 2026. New composition; fresh review PENDING.
This proof uses classical Kasami--Tokura forms, W59's new odd-hull quotient
coupling, and the actual degree-feature acquisition proved in frozen
COHEN_COLLISION_ANNIHILATOR_PROOF.md (36157bb2...953a4). It does NOT use
an unextracted Cohen constant. The append/flip reduction is classical.
Historical priority and external validation remain UNKNOWN.

The announced shortcut C subset U was false. W59 caught the gap and supplied
the essential at-most-one-extra-positive-point repair used in Section4.
That adversarial contribution is explicitly retained; no false shortcut is
part of the theorem below.

## 1. Exact structural and algorithmic statements

Let P:F2^n->F2^n be any explicit quadratic Boolean map, with arbitrary dense
coordinate ranks and arbitrary fibers. Set

    w(y)=|P^-1(y)|-1, H=#{y:w(y)=-1},
    K=ceil(n/2), L=2^K, C={y:w(y)>0}.

If n>=6 and 0<H<L, there is a NONZERO Boolean polynomial R of degree at most
TWO which vanishes on ALL of C. The polynomial need not be given as an
affine-flat indicator, nor is its proper structural decomposition supplied.

Consequently there is a completely numerically specified deterministic
uniform FP^NP algorithm for the following rectangular promise: an explicit
F=(P,g):F2^n->F2^(n+1) has SOME actually enumerated square coordinate projection
P which is quadratic and has H(P)<2^ceil(n/2). The removed output g may be any
explicit polynomial-size Boolean circuit. The algorithm returns a missing
(n+1)-bit output. It does not compute H, decide that numerical promise, or
necessarily return a square hole. Every returned word is sound on EVERY
input, even off promise.

For n<=5 enumerate the at-most32 inputs and choose an omitted output of F.
For n>=6 run the explicit acquired algorithm A_2 on all n+1 coordinate
projections, stopping at the first success. It actually acquires the complete
degree<=2 collision evaluation span by ordinary NP INPUT-pair queries, finds
a nonzero kernel polynomial, and constructs y with R(y)=1. Its P-fiber has
at most one point. NP inversion returns either an empty fiber or its unique
preimage; the classical CollisionAvoid append/flip operation then yields a
rectangular hole. No classifier, hull, H, decomposition, advice or count is
an input. Failure of every projection certifies only the degree-two closure
class failure, not a numerical deficit value.

With M_2=1+n+binom(n,2), the exact safe ordinary NP decision bound is

    (n+1)*((2n+1)*M_2+n+2).                    (1)

Maximum query bits are O(S_F+n^4). A safe total outside bit bound is
O((n+1)*(S_F+n+1)^4*(M_2+1)^4), charging all projections, witness prefix
extraction, monomial/row acquisition and serialization. All n^2-feature and
M_2-by-M_2 fields are PHYSICALLY padded from the first query, so one fixed
ordinary NP language suffices; witnesses have2n or n bits. These caps hold
off promise. For dense quadratic F, S_F=O(n^3), this conservative outside
bound is O((n+1)^21), while the decision count is O(n^4). No unknown constant
is hidden in the algorithm's feature degree or stopping rule.

## 2. Exact dyadic and low-weight facts

Write W(a)=sum_y w(y)(-1)^(a.y). At a=0 it equals0, not the ordinary Gauss
sum2^n. For a!=0 it is the quadratic Gauss sum of a.P, hence is0 or a signed
power2^(n-rank/2), with even rank<=2floor(n/2). Every W(a) is divisible by L.
Because |W(a)|<=sum|w|=2H<2L, in the present regime

    W(a) in {0,+L,-L}.                         (2)

Let U={y:w(y) is odd}. All negative values of w are exactly -1, so all holes
lie in U. Positive defect has total mass H, hence

    0<|U|=H+#{positive odd points}<=2H<2L.     (3)

The indicator of U has Boolean degree<=m=n-K. To verify this directly, expand
w in the integer squarefree monomial basis. Fourier inversion gives its
coefficient on T as

    c_T=(-2)^|T| * 2^-n * sum_(a contains T) W(a).

For |T|>n-K, divisibility by L makes c_T even. Reducing the integer ANF mod2
therefore proves the degree claim. Equivalently U is a [K-1] UNITRADE. This
binary set is simple even when w has repeated positive fibers; no repeated
signed-trade classification is invoked.

Classical Kasami--Tokura low-weight Reed--Muller classification now gives:

* Minimum: |U|=L and U is an affine K-flat.
* Type A: U is the symmetric difference of TWO affine K-flats; its weight is
  2L-2^(K+1-mu), and its affine hull has dimension<=K+mu, with2<=mu<=m.
* Type B: U is contained in an affine flat of dimension<=K+2.

The needed primary form is Lemma11 of Ghorbani--Kamali--Khosrovshahi--Krotov,
*On the volumes and affine types of trades*, arXiv1810.02296v2 (11January2020),
https://arxiv.org/html/1810.02296v2 . Directly rechecked23October2026. In
RM(m,n), Type A is a common product of m-mu coordinates times the XOR of two
disjoint mu-fold products; each summand has support a K-flat. Type B has a
common product of m-2 coordinates, so support dimension at most K+2.
Minimum words are K-flat indicators. The unitrade correspondence is Lemma2.
We use these literal forms, not the later simple signed-trade exclusions.

## 3. W59's quotient coupling and the minimum odd-support case

Let O=b+V=aff U. Aggregate w over the quotient by V, with O its base cell.
All negative values lie in O, so every nonbase quotient sum p(t) is
nonnegative. Let Pout=sum_(t!=0)p(t); total mass zero gives p(0)=-Pout, with
Pout<=H<L. Quotient Walsh coefficients are restrictions of W and also equal

    -sum_(t!=0)p(t)*(1-chi_a(t))<=0.

By(2) they are0 or-L. Hence nu=delta_0+p/L is a nonnegative probability
whose Fourier values are0 or1. Such a probability is uniform on a subgroup:
modulus-one characters are constant on its support and form a subgroup,
and Fourier inversion gives the uniform measure on their annihilator.
If the subgroup has dimension h, then

    Pout=L*(1-2^-h).                          (4)

All odd positive points lie in O and consume at least one unit of the
positive mass H-Pout there. Therefore W59's sharpened coupling is

    |U|<=2H-Pout.                             (5)

If h>=1 and U is nonminimum, the classical first weight gap |U|>=3L/2 and
(4),(5) give 3L/2<=2H-L/2<3L/2, a contradiction. Thus a nontrivial quotient
forces MINIMUM odd support. If h=0, Pout=0; all entries outside O are
nonnegative with zero total in their cell, so ALL defect is contained in O.

Whenever U=B is a minimum affine K-flat, define phi=w+1_B. It is nonnegative,
has total mass L, and is EVEN everywhere: w is odd exactly on B. Its Walsh
coefficients are all divisible by L, and positivity bounds their magnitudes
by L. Thus phi/L is a probability with every Fourier coefficient0,+1,-1.
The same positive-idempotent argument, with character signs retaining a
possible affine offset, makes it uniform on an affine flat A. Therefore

    w=q*1_A-1_B, q=L/|A| a positive even integer.

The evenness forces q>=2. The positive set is EXACTLY A, and dim A<=K-1<n.
Thus a NONZERO AFFINE LINEAR polynomial annihilates C. This covers every
minimum-U case, whether or not the whole defect hull is proper.

## 4. Full odd hull: the essential extra-point repair

It remains that U is nonminimum. Section3 gives h=0 and the entire defect
support contained in O. If O is proper, one affine separator already
annihilates C. Suppose instead O is FULL dimensional.

For n>=6, K+2<n, so Type B is impossible in this case. U has Type A and
n=dim O<=K+mu with mu<=m=n-K; consequently mu=m. In particular

    |U|=2L-2      if n=2K,
    |U|=2L-4      if n=2K-1.                  (6)

One cannot conclude C subset U: positive EVEN defects need not lie in U.
The exact excess identity is instead

    2H-|U|=2*sum_(y:w(y)>0) floor(w(y)/2).     (7)

Since H<=L-1, equations(6),(7) give excess0 in even dimensions and excess
at most2 in odd dimensions. Thus at most ONE positive-even point p can lie
outside U. A possible w=3 point consumes the same budget but is already in
U; it causes no further support enlargement. This is W59's necessary repair
of the invalid C subset U shortcut in the preliminary announcement.

Write U=F1 triangle F2 for the two affine K-flats given by Type A. If the
extra point p exists, replace F1 by F1'=aff(F1 union{p}); otherwise let
F1'=F1. Then

    C subset F1' union F2,
    dim F1'<=K+1, dim F2=K,
    |F1' union F2|<=3L<2^n                    (8)

for every n>=6. Both flats are proper. Choose z outside their union. For
each flat choose one affine linear polynomial vanishing on it and equal to1
at z. Their product is a NONZERO polynomial of degree<=2, since it equals1
at z. It vanishes on C by(8). This proves the structural theorem.

No flat, exceptional point, quotient subgroup, KT type or Cohen decomposition
is acquired for free in the algorithm. They prove ONLY the degree cap.
The complete NP feature-span acquisition acquires a possibly different
nonzero quadratic annihilator directly from actual collision input pairs.

## 5. Scope, credits and remaining boundary

This completes the ENTIRE strict interval H<L for the rectangular missing-
word task, including every integer endpoint left by a proper-whole-hull
argument. It does not extend the old square-hole/full-profile guarantees
without margin. At H=L the Fourier values may include +/-2L and |U| may
reach2L, so the ternary and strict low-weight steps above cease to apply.
No statement for all bounded-factor H>L follows from this explicit proof.

For fixed H<=cL, the separate Cohen-annihilator composition gives existence
of a uniform FP^NP machine with numerical universal degree NOT_EXTRACTED.
The present H<L theorem has fully specified degree2 and all-input clocks.
The gap between these numerical and existential claims remains explicit.

Credit: W59 derived the quotient-coupling inequality(5), the sharp support-
rank bound that motivated this endpoint attack, the minimum-odd two-flat
extension, and the essential extra-point correction in Section4. Classical
Kasami--Tokura supplies the low-weight forms. Chung et al., ECCC TR23-193
revision1, Definition2.4/Theorem3.1 supplies the append/flip CollisionAvoid
reduction. The standard monomial interpolation is turned into actual
complete acquisition by ordinary NP witness searches, all charged here.

No historical priority verdict, external proof validation, ordinary-time
algorithm, generic near-square3local Avoid, P-versus-NP or mission success
is claimed. Fresh criticism, finite acquisition checks and novelty review
remain separate obligations.
