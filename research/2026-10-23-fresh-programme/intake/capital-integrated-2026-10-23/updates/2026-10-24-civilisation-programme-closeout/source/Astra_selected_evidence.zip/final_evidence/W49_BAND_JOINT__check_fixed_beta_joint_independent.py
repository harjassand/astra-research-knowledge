"""Fresh independent scalar reconstruction and small joint-channel controls.

No producer/peer module is imported or executed. The frozen rows are INPUT
data, checked against independently derived inequalities and precision
formulas. No giant circuit, source, good program or physical run is made.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import math
import resource
import time
import numpy as np

HERE = Path(__file__).resolve().parent
SRC = HERE.parents[1]/'w67_fresh_foundational_mechanism/high_design_audit/quadratic_source_frontier'
Z, ETA = F(1,1000), F(1,100)
G, KAP, CHI = F(1,74400), F(1,96000), F(1,100000)


def ceil(x):
    x = F(x)
    return -(-x.numerator//x.denominator)


def bits(x):
    x = F(x)
    if x <= 1:
        return 0
    b = x.numerator.bit_length()-x.denominator.bit_length()
    return b if F(2)**b >= x else b+1


def source_scalars():
    gamma, rmax, tmin, tmax = F(4,25), F(1,10), F(1,1200), F(1,800)
    assert F(1,8)*(1-F(1,5000)-F(1,50)) > F(3,25)
    assert F(3,25)*F(1,12)**2 == tmin and F(1,8)*rmax**2 == tmax
    assert gamma**2*tmin > F(1,250)**2 and gamma**2*tmax < F(6,1000)**2
    A = math.prod(range(1,40,2))*(gamma*rmax)**20
    cj = lambda j: F(j**j*(20-j)**(20-j),20**20)
    d0, N2, N4 = F(1,10**8*2**20), F(9,10**6*2**10), F(13,10**4*2**5)
    assert cj(1)*A < d0 and cj(2)*A/8 < N2**2 and cj(4)*A/8 < N4**4
    e = d0*F(6,1000)+N2
    assert e == F(460800003,52428800000000000) and e < F(1,10**8)
    assert e/F(1,250) < F(1,800)
    variance = (1+F(1,7200))**2*gamma**2*(1+F(1,800))**2+F(1,800*81*6553)
    fourth = (1+F(1,7200))*(F(39,20)*gamma+2*N4*12)+F(1,270*80)
    assert variance < F(257,10000) and fourth == F(270487957,864000000) < F(328,1000)
    loss = (F(257,20000)+F(161,1000)*F(328,1000)**2*F(29,10)/30
            +F(328,1000)**4*F(25,3)/75)/F(69,100)
    assert loss == F(277917203,12128906250) and F(1,18)-loss > F(1,31)
    h = lambda x: x-F(103,720)*x*x
    assert h(F(1)) == F(617,720) < h(F(4)) == F(77,45)
    main = gamma*h(F(1))-F(1,9)
    assert main == F(13,500)
    corr = (1+F(1,7200))*1200*F(1,10**8)+F(6,1000)/9
    drift = F(16383,16384)*main-F(10,17)*corr
    assert corr == F(407201,600000000) and drift == F(393203657,15360000000) > F(1,40)
    assert tmin/62 == G and tmin/80 == KAP
    assert F(257,10000)*tmax/4 == F(257,32000000) < CHI
    return {'A20':str(A),'congruence_error_bound':str(e),'entropy_loss_coefficient':str(loss),
            'uniform_drift_coefficient':str(drift),'G':str(G),'Kappa':str(KAP),'chi':str(CHI)}


def scalar_row(a, expected):
    k,t,s = a['k'],a['t_mesoblock'],a['s_mesoblocks']
    b0=F(a['b_reference'])
    assert k == (1/(10*b0)).numerator//(1/(10*b0)).denominator
    assert k>=6553 and 0<b0<=F(1,65536) and F(1,12)<=b0*k<=F(1,10)
    assert F(a['actual_b_lower'])==b0 and F(a['actual_b_upper'])==4*b0
    B0=bits(2**30*k**6/(G*KAP)); eps=F(1,2**B0)
    assert a['B0']==B0 and F(a['eps'])==eps
    w=ceil(2*CHI*t)+1; B=(k*t+1)*(2*w+1)
    assert t&(t-1)==0 and w==a['w_bin'] and B==a['table_cells_upper']
    assert CHI*t>=B0+4 and bits(B)+2*B0+32<=t*G/8 and eps*(4*k+1)<=G/16
    if t>1:
        th=t//2; Bh=(k*th+1)*(2*(ceil(2*CHI*th)+1)+1)
        assert not (CHI*th>=B0+4 and bits(Bh)+2*B0+32<=th*G/8)
    Bp=bits(128*B/eps); pmin=F(1,2**Bp); Bmu=Bp+2*w+3
    assert a['Bp']==Bp and a['Bmu']==Bmu and B*pmin<=eps/128
    ellmin=k*t-Bp-2*(w+1)-2*B0-24; Dlo=k*t-Bp-2*(w+1); E=2*k*t
    assert a['ell_min']==ellmin and a['D_log_lower']==Dlo and a['E_inner']==E
    etap=F(1,2**bits(32/ETA)); etaw=ETA/32; Bf=bits(32*s/ETA)
    assert s*G*G>=128*k*k*bits(1/etaw)
    h=E+Bf+3; Bd=Bf+2+2*h*(E+B0+Bmu+1); p=2*h
    assert a['h_inner']==h and a['Bdes_inner']==Bd and ellmin>=bits(h)
    rhs=E+Bf+2+2*h*(B0+Bmu)
    assert Dlo>=bits(16*rhs) and eps**2/2**20<=F(1,128)
    Mp=8*p*(E*p+Bd+3); seed=Mp*(2*E+bits(2*p))+2*E
    assert a['pauli_inner_steps']==Mp and a['seed_one_inner_upper']==seed
    assert 3*Mp>=16*p*(E*p+Bd+2)
    body=k*s*t; R=1<<bits(16*body); BR=bits(R); Bq=48+4*BR+4*bits(1/Z)
    q=F(1,2**Bq); Bgrid=Bq+BR+5
    tL=KAP/(8*k*k); Ct=6/(KAP*tL)
    numer=5*eps*s+2*etaw+bits(1+Ct)+Bq+bits(32/ETA)+Bgrid+12
    H=ceil(numer/tL); flush=16*(H+Bq+6); A=Bq+8; initial=16*(A+Bq+4)
    total=initial+body+flush; width=(s*t*(F(3*k,2)+G/2)).numerator//(s*t*(F(3*k,2)+G/2)).denominator
    logical=width-Bq; rate=F(3,2)+G/(16*k)
    assert body==a['forward_body'] and R==a['R_outer'] and BR==a['B_R'] and Bq==a['Bq']
    assert H==a['body_depth_cutoff'] and flush==a['forward_terminal'] and initial==a['forward_initial']
    assert total==a['forward_total'] and width==a['parent_width'] and logical==a['logical_width']
    assert logical>=rate*total and rate-F(3,2)>=4*b0/476160
    assert flush<=body and 2*(2*(body+flush)+1)<=R and 2*(body+flush)<=R/4
    assert 2**Bgrid>=16*R/q+2 and a['B_grid_cardinality']==Bgrid
    # Exact positive diagonal zero-port effect allows addition, not a sqrt cross term.
    assert F(3,4)**3 < F(1,2)
    assert 2*(body+flush)*q/(16*R)<=q/64
    grid_union=etap/512
    assert grid_union<ETA/32
    assert 16*(q+F(1,2**A))<=(Z/32)**2
    ho=width+2*BR+bits(32/ETA)+8
    Bdo=bits(32/ETA)+2*BR+3+2*ho*(width+Bq+2)
    assert a['h_outer']==ho and a['Bdes_outer']==Bdo
    assert logical>=bits(ho) and width>=bits(16*(width+2*BR+bits(32/ETA)+10+ho*(Bq+4)))
    po=2*ho; Mo=8*po*(width*po+Bdo+3)
    assert Mo==a['pauli_outer_steps']
    omega=128*R*F(1,2**(Bq//2)); u=2*q+R*omega
    assert R*omega<=Z*Z/256**2 and u<=Z*Z/256**2
    Ienc=a['row_queries_outer']+1
    assert Ienc==a['whole_encoder_invocations'] and a['row_queries_outer']==4*a['sign_degree_outer']+4
    # Reconstruct the explicit tanh/Chebyshev degree, rather than use an O(.) query bound.
    gapo=Z/(256*R); xio=Z/128; ds=xio*xio/32; es=ds/8
    ac=bits(4/es); kc=ceil(F(ac)/(2*gapo)); bc=bits(16*kc/es)
    deg=5*kc*bc; deg+=int(deg%2==0)
    assert deg==a['sign_degree_outer']
    Dp=Z/(4096*Ienc); Di=Dp/(8*s); Bsig=2*bits(1/Di)+32
    sig=F(1,2**Bsig); Bg=(Bmu+3)//2; gap=F(1,2**Bg)
    degi=ceil(8*(Bsig+2)/(gap*gap)); degi+=int(degi%2==0)
    Qi=2**(2*Bg)*64*(Bsig+1)
    assert 4*degi+4<=Qi and 648*sig<Di*Di
    xi=sig/(4096*Qi); MB=1+F(4,25)*b0*k*(k-1); alpha=(1+16*MB)/2
    domain=max(t*bits(1+2*MB),w)+max(t,w)+4
    Tpe=1<<bits((40*domain/xi)**2); dL=xi*domain/(1024*Tpe)
    dB=dL/(16*t*MB); dlog=dL/(2*t)
    assert 8*t*MB*dB+t*dlog==dL
    assert F(25*domain*domain,4*Tpe)<=xi*xi/256
    assert 16*Tpe*dL/domain==xi/64
    ntable=8*(128*2**(B0+Bp))**2*(bits(64*B/ETA)+1)
    assert ntable==a['table_sampling_source_experiments_upper']
    assert t*ntable==a['source_blocks_used_by_table_upper']
    Bcdf=bits(128*B/(eps*pmin)); assert Bcdf==a['cdf_sampler_bits_per_cell']
    assert 2*s*Bcdf==a['cell_sequence_seed_upper_two_attempts']
    assert s*seed+a['outer_seed_upper']+2*s*Bcdf+2*k*s*t==a['all_random_seed_bits_upper']
    err=3*Z/32+Z/32+Z/4+2*Ienc*Dp
    fail=ETA/32+etaw**2+s*F(1,2**Bf)+2*etap
    assert err==F(769,2048000)<Z and fail==F(10701,10240000)<ETA
    got={'reference_beta_denominator':a['reference_beta_denominator'],'k':k,'forward_total':total,
         'M_B':str(MB),'acquired_alpha_star':str(alpha),'function_domain':domain,
         'signal_tolerance_bits':Bsig,'inner_gap_bits':Bg,'function_isometry_accuracy_bits':bits(1/xi),
         'T_PE_power_two_exponent':bits(Tpe),'L_operator_accuracy_bits':bits(1/dL),
         'B_operator_accuracy_bits':bits(1/dB),'per_source_log_accuracy_bits':bits(1/dlog),
         'grid_union_budget':str(grid_union),'native_encoder_channel_error_bound':str(2*Ienc*Dp),
         'full_error_bound':str(err),'program_failure_union_bound':str(fail)}
    for key,val in got.items():
        assert val==expected[key],(key,val,expected[key])
    return got


def sqrt_psd(A):
    v,U=np.linalg.eigh(A)
    assert min(v)>-1e-12
    return (U*np.sqrt(np.maximum(v,0)))@U.conj().T


def joint_controls():
    rng=np.random.default_rng(49067002)
    I=np.eye(2); X=np.array([[0,1],[1,0]])
    cases=0; mxiso=mxformula=mxjoint=0.
    for m in (0.,1e-5,.001,.02):
      for perturb in (0.,1e-5):
       if m==0 and perturb:
        continue
       for phase in (0.,.39,1.17):
        v=[np.array([1.,0.],complex),np.exp(1j*phase)*np.array([.6,.8],complex)]
        mus=[1-m,1-m/2]
        delta=min(perturb,m/8)
        Ks=[np.kron(v[s][:,None],I)@np.diag(np.sqrt(mus[s])*np.array([1+delta,1-delta])) for s in range(2)]
        row=np.concatenate(Ks,axis=1)
        U,sv,Vh=np.linalg.svd(row)
        dec=Vh.conj().T@U.conj().T
        Gram=np.array([[np.trace(Ks[i].conj().T@Ks[j])/2 for j in range(2)] for i in range(2)])
        root=sqrt_psd(Gram)
        es=[root[:,s] for s in range(2)]
        fs=[es[s]/np.sqrt(Gram[s,s].real) for s in range(2)]
        omega=np.linalg.norm(row.conj().T@row-np.kron(Gram,I),2)
        mean=1-min(Gram.diagonal().real); u=mean+2*omega
        Va=np.zeros((16,4),complex); target=np.zeros_like(Va)
        for s in range(2):
            bad=sqrt_psd(I-Ks[s].conj().T@Ks[s])
            bad=np.kron(np.array([0.,1.])[:,None],X)@bad
            aa=[dec@Ks[s],dec@bad]
            for l in range(2):
                for lo in range(2):
                    for co in range(2):
                        target[((lo*2+s)*2)*2+co,l*2+s]=int(lo==l)*fs[s][co]
                        for word in range(2):
                            Va[((lo*2+s)*2+word)*2+co,l*2+s]=aa[word][co*2+lo,l]
        iso=max(np.linalg.norm(Va.conj().T@Va-np.eye(4),2),np.linalg.norm(target.conj().T@target-np.eye(4),2))
        actual=np.linalg.norm(Va-target,2)
        bound=np.sqrt(2*omega)+2*np.sqrt(2e-10)+np.sqrt(max(u,0))+mean
        assert iso<1e-12 and actual<=bound+1e-12
        phi=np.array([[np.vdot(fs[t],fs[s]) for t in range(2)] for s in range(2)])
        assert min(np.linalg.eigvalsh(phi))>-1e-12 and np.max(abs(phi.diagonal()-1))<1e-12
        # Compare ALL joint logical-seed matrix units, tracing only decoder work.
        ts=target.reshape(8,2,4)
        for a in range(4):
            for b in range(4):
                out=sum(np.outer(ts[:,c,a],ts[:,c,b].conj()) for c in range(2))
                want=np.zeros((8,8),complex)
                want[a*2,b*2]=phi[a%2,b%2]
                mxformula=max(mxformula,float(np.max(abs(out-want))))
        mxiso=max(mxiso,float(iso)); mxjoint=max(mxjoint,float(actual)); cases+=1
    # Actual root-only zero-port phases, with no claimed logical transmission.
    root_cases=0; root_residual=0.; wrong_seed_identity=0.
    for T in range(1,9):
      for theta in (0.,.01,.27,.71):
        lam=np.array([np.exp(1j*theta),-np.exp(-1j*theta)])**T
        # Fourier row includes both sector signs and all 2T+1 frequencies.
        J=2*T+1; th=2*np.pi*np.arange(J)/J; aa=np.arange(-T,T+1)
        samples=np.vstack((np.exp(1j*T*th),(-1)**T*np.exp(-1j*T*th)))
        E=(samples@np.exp(-1j*np.outer(th,aa)))/J
        ev=E.reshape(2*J); c=[]
        for s in range(2):
            cc=np.zeros(2*J,complex);cc[s*J:(s+1)*J]=np.exp(1j*aa*theta);c.append(cc)
        Gram=np.outer(ev.conj(),ev)
        root=Gram/np.linalg.norm(ev)
        es=[root@cc for cc in c]
        fs=[e/np.linalg.norm(e) for e in es]
        kernel=np.array([[np.vdot(fs[t],fs[s]) for t in range(2)] for s in range(2)])
        exact=np.outer(lam,lam.conj())
        residual=np.max(abs(kernel-exact));assert residual<1e-12
        root_residual=max(root_residual,float(residual));root_cases+=1
        if T==1 and theta==0:
            wrong_seed_identity=2*abs(math.cos(theta))
    assert wrong_seed_identity==2 and mxformula<1e-12
    return {'controlled_joint_fixtures':cases,'joint_matrix_unit_entries_checked':cases*16*64,
            'max_isometry_residual':mxiso,'max_explicit_Schur_formula_residual':mxformula,
            'max_actual_target_isometry_distance':mxjoint,'actual_root_phase_fixtures':root_cases,
            'max_root_Schur_phase_residual':root_residual,'wrong_seed_identity_diamond_witness':wrong_seed_identity,
            'toy_joint_fixtures_are_not_actual_H_codes':True}


def main():
    start=time.time()
    rowfile=SRC/'FIXED_BETA_FORWARD_GUARDS.json'; nativefile=SRC/'FIXED_BETA_NATIVE_INPUTS.json'
    rows=json.loads(rowfile.read_text())['rows']; natives=json.loads(nativefile.read_text())['rows']
    out={'status':'PASS_INDEPENDENT_EXACT_SCALARS_AND_FINITE_JOINT_CONTROLS',
         'source_scalars':source_scalars(),'row_reconstructions':[scalar_row(a,b) for a,b in zip(rows,natives)],
         'joint_controls':joint_controls(),'implementation':'No producer or peer code imports/execution; frozen JSON only as supplied comparison data',
         'arithmetic':'Integers/Fractions for all scalar guards; NumPy floating point for small joint matrices',
         'not_executed':['Actual giant H/source','Quantum table acquisition','Good code program','Native circuit/phase array','Hardware','Public program transport','Outer/reuse code'],
         'input_rows_sha256':hashlib.sha256(rowfile.read_bytes()).hexdigest(),
         'input_native_sha256':hashlib.sha256(nativefile.read_bytes()).hexdigest(),
         'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'numpy_version':np.__version__}
    out['wall_seconds']=time.time()-start
    out['peak_rss_host_units']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    (HERE/'INDEPENDENT_FIXED_BETA_JOINT_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))


if __name__=='__main__':
    main()
