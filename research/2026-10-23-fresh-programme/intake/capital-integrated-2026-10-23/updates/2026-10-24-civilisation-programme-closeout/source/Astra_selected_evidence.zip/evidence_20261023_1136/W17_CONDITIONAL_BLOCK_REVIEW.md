# Fresh conditional-block amplifier EPnI review

23 October 2026, w17. Exact reviewed files:

- `w69_fresh_amplifier_resource_critic/local_epni_audit/sequential_composition/CONDITIONAL_BLOCK_UNIFICATION.md`,
  SHA256 `165b92d13c50eeb4b052f09df94c27543741ea29bbd7afed6534b3ff45e12b25`;
- the same directory's `SEQUENTIAL_LOCAL_THEOREM.md`,
  SHA256 `db47dce2c56061c9bbab89336fa435fb9243ccdea8cd29697500c52f0c7e3b80`;
- its RESULT manifest SHA256
  `f04a5554805092da62eca87dad7917c75aea0b8fff1fb1d390b6f7bb80329d65`.

The local source is w38's diagonal proof SHA256
`021e74d98b9375c82abdcb5a0ae2f40ab665ec38793103c0ad9039aa4579a3c5`.
The convexity dependency is w69 `BLOCK_PRODUCT_EXTENSION.md`, SHA256
`e42e7ca704ec3256403c1acd71de8c3a8b10d13cd69752ef48f0a00740d67bd5`,
Sections 1-2. W17 had also independently derived the same scalar Hessian
and product closure, recorded in its separate `BLOCK_PRODUCT_CLOSURE.md`.
Exact primary and witness snapshots are retained beside this review;
originals were not edited. No producer script was imported or replayed.

**Verdict: no blocking defect found at the exact finite conditional-block
contract.** The native-past Markov relation and inequality direction are
correct, both Jensen steps are justified, and the supplied latent-bit
witness has an extensive strict-gap lower bound and entropy deficit with
no nontrivial native block factorization. This unifies the DIAGONAL local,
diagonal product-block and diagonal sequential classes. It does not
subsume w38's arbitrary noncommuting quantum local bridge or establish a
general quantum-correlated closure. The matched Gaussian orbit is a
separate exact covariance corollary.

## 1. All hypotheses of the pointwise local bound are present

Fix the common G>1, H=G-1, a finite ordered partition into positive block
sizes n_i and total N. The whole A and B groups are independent and
diagonal in the native joint Fock basis. For every positive-probability
native A past x, block i has conditional law

```
P_A(A_i=k|A_<i=x)=P_(a_i)^n_i(k)[1+epsilon_i f_Ai(x,k)].
```

The reference a_i>0 and epsilon_i are fixed for that block, independent of
history. Every row has |f|<=1, reference mean zero and reference TOTAL
number moment zero, and |epsilon_i| is at most the exact local radius.
B has the corresponding statement with b_i and its own past. Null pasts
need no supplied row. Histories at each finite index are countable.

These hypotheses ensure normalized positive rows, conditional block
energy n_i a_i, and the exact energy-matched diagonal local theorem for
every x,y. They do not require each native mode in a nonsingleton block
to have the same conditional mean. There is no replacement of merely
total-energy orthogonality by per-mode or full covariance orthogonality.

I separately checked the diagonal local dependency at this exact scope.
Its one-port thermal count PGF is

```
E[u^A v^C]=1/{[1+a(1-u)][1+c(1-v)]
                      -G a(a+1)(1-u)(1-v)},
```

with the B-port coefficient H b(b+1). Thermal tilting proves this directly.
The Meixner generating functions diagonalize the count conditional
expectations with coefficients r_A^k and r_B^k. Equivalently these are
the diagonal p=q Wick sectors independently reconstructed in the quantum
audit. On every nonconstant count degree, their simultaneous squared
coefficient ratio is at most

```
r_A^2/eta_A+r_B^2/eta_B
 =[G kappa(a)+H kappa(b)]/kappa(c)=1-delta_D<1.
```

Only the constant count component must be removed for this strict
spectral bound. The first/second noncommuting quantum moment exclusions
are not imported into this diagonal argument. Total-energy matching is
then sufficient for the exact entropy identities. The bounded-ratio
quadratic entropy bounds, binary cross-term comparison and scalar
nonlinear curvature calculation give the stated diagonal local radius
with delta_D, not the possibly smaller quantum delta_Q. Thus applying the
source local theorem to a whole conditional block is legitimate.

## 2. The unmeasured physical output is the count kernel

For each fixed input Fock pair, two-mode squeezing preserves its number
difference. Tracing the discarded output leaves the retained number
diagonal. The N-pair unitary acts independently on native pairs. A mixture
of input number vectors therefore produces precisely the classical
memoryless conditional kernel, product over native pairs. Within a block
the input counts can remain correlated; its kernel Q_i is the product
kernel acting on the whole vector.

This is a representation of the actual unmeasured quantum output, not a
measurement whose entropy increase is used as an output lower bound.
All three relevant quantum marginal entropies equal their count Shannon
entropies in this native representation.

## 3. Native histories preserve independence; output histories do not

Put W_i=(A_<i,B_<i). Full-group independence gives, at every admitted past,

```
P(A_i,B_i|W_i=(x,y))=P_A(A_i|x)P_B(B_i|y).
```

The local pointwise inequality consequently has two genuinely independent
conditional inputs. No independence is asserted after conditioning only
on the output past, which would generally be false.

The exact joint distribution factors, after summing all later counts, as

```
P(c_<i,c_i,x,y)
 =P_A(x)P_B(y) Q_<i(c_<i|x,y)
      *sum_(k,l) P_A(k|x)P_B(l|y)Q_i(c_i|k,l).
```

Thus C_i is conditionally independent of C_<i given W_i. Future/present
count correlations with the native past do not change that factorization:
the fresh local output randomness is independent across pairs. It follows
that

```
H(C_i|C_<i)-H(C_i|W_i)
 =I(C_i:W_i|C_<i)>=0.
```

This is exactly the lower-bound direction needed in U1. It is not an
assumption that the native count source itself is Markov of finite order.
Its conditional laws can depend on the entire native past.

## 4. Pointwise application, actual history weights and both Jensen steps

At each x,y, define s_i(x)=H(A_i|x)/n_i and t_i(y)=H(B_i|y)/n_i.
The local theorem yields conditional output entropy at least
n_i F_G(s_i(x),t_i(y)) plus its local strict gap. Averaging uses the
ACTUAL past weights P_A(x)P_B(y); the norm inside the gap still uses the
specified local THERMAL reference. These two measures are not confused.

The local gap is a sum of an A-row norm and a B-row norm with fixed
block constants. Its averaged value is exactly Gamma_i in the source.
There is no extra weight from the other party or an unobserved shared
latent variable.

The scalar target F_G(s,t)=g(Gg^(-1)(s)+H[g^(-1)(t)+1]) is jointly strictly
convex on s,t>0. This follows either from the independently recomputed
positive Hessian determinant or from the dependency's exact factorization
Hess F=D-uu^T with u^T D^(-1)u=1-delta_D<1. The first Jensen step gives

```
H(C_i|W_i)>=n_i F_G(H(A_i|A_<i)/n_i,
                    H(B_i|B_<i)/n_i)+Gamma_i.
```

Each row's entropy coordinates lie in the fixed compact rectangle
[g(a_i)/2,g(a_i)] times [g(b_i)/2,g(b_i)], because the source radius bounds
its entropy deficit. Consequently Jensen over countably many histories
has no integrability or boundary problem.

Sum the OUTPUT entropy chain rule, use the native-history lower bound,
and apply weighted Jensen with n_i/N. The INPUT chain rules then give

```
H(C^N)>=N F_G(H(A^N)/N,H(B^N)/N)+sum_i Gamma_i.
```

All inequalities have the correct sign. The omitted terms are a sum of
nonnegative conditional mutual informations and two nonnegative convexity
gaps. The second Jensen step needs a COMMON gain G but not common block
temperatures, sizes or amplitudes.

For each finite instance the conditional means give total input energies
sum_i n_i a_i and sum_i n_i b_i and output energy sum_i n_i c_i. Finite
total number bounds entropy by a finite thermal entropy. Hence all
unconditional and conditional entropies and chain-rule differences above
are finite; no infinity-minus-infinity or asymptotic continuity argument
has been used. This review does not extend the theorem to a countable
partition with possibly infinite entropy.

## 5. Exact long-range witness and radius admission

At G=2,a=b=1, take P(k)=2^(-k-1), epsilon=3/1000 and
f=(1/4,-1,1,0,...) on k=0,1,2,3,... . Direct sums give

```
E_P f=E_P Nf=0, alpha=E_P f^2=13/32.
```

Let sigma(A_1)=+1 on zero and -1 otherwise. The first count is thermal,
so this is a fair sign. Every later conditional row is
P(k)[1+epsilon sigma(A_1)f(k)]. The B construction is INDEPENDENT and
has its own first count/sign; sharing the sign across A and B would
violate the theorem. Conditional sampling given the first count defines
consistent laws for every finite horizon.

Each later marginal is exactly P, every conditional mean is one, and
the state is non-Gaussian and nonproduct. Native Fock diagonality and
unit mean marginals give covariance (3/2)I despite higher count
correlations. This is not a covariance-only admission criterion.

The stated rational epsilon is genuinely inside the source radius. Using
positive atanh-series log bounds gives
0.693<ln2<0.694, 0.223<ln(5/4)<0.224, hence
delta>3/50, eta_*>11/35, C_*<8. The lower endpoint a_->1/4 follows from
g(1/4)=(ln2)/2+5ln(5/4)/4<ln2, and c_->7/4. Since h(7/4)<1/2,
substitution in the explicit curvature formula gives L<16. The four
sufficient radius conditions are then all strictly greater than .003.
Conversely delta<.08 and C_*>4 give epsilon_0<.01.

Write d_+=D(P(1+epsilon f)||P), d_- analogously, and dbar=(d_++d_-)/2.
Only three terms are nonzero. Entropy chain rule gives exactly

```
S(A^n)=S(B^n)=n g(1)-(n-1)dbar,
D(rho_A||tau_1^n)=D(rho_B||tau_1^n)=(n-1)dbar.
```

Dbar is positive; the independent 75-digit diagnostic gives
0.0000018281275444427092602450015117783443179294957150947913230677...
nats. Since every marginal is thermal, each group's multi-information
is the same extensive quantity. The summed guaranteed ENTROPY gap is
(n-1)(delta/8)epsilon^2(eta_A+eta_B)13/32, in nats. No photon-number or
distillable-entanglement rate is silently substituted for this entropy
gap.

For each j>=2, Cov(sigma(A_1),f(A_j))=epsilon alpha>0. Every nontrivial
partition of the native sites separates site 1 from some later site;
those bounded functions then disprove independence of its two parts.
Thus no nontrivial native independent-block factorization exists. For
j!=k>=2, covariance of f(A_j),f(A_k) is epsilon^2 alpha^2>0, so the
dependence persists at arbitrary separation. The same statements hold
in B. Bounded-function dependence is compatible with zero quadrature
cross covariances and zero conditional number-mean changes.

The full likelihood has positive-probability extreme values
(1+epsilon)^(n-1) and (1-epsilon)^(n-1). At n=5 these are already above
1.01 and below .99, outside the original global local window. Thus this
witness genuinely separates the conditional theorem from both the
global order ball and native independent-block classes.

## 6. Independent diagnostic and a conditioning negative control

Own `check_conditional_blocks.py` imports no producer script. It passes
54 exact-fraction assertions, including rational log-tail radius bounds,
normalization/energy/covariance identities, likelihood separation and a
finite Markov factorization. Fifteen further assertions use 75-digit
Decimal arithmetic for entropy identities and diagnostic signs; they
are not labelled interval certificates. Raw data are retained in
`conditional_block_checks.json`.

For the native witness, the symbol T groups ALL counts k>=3. Its exact
conditional mean is four, its hidden geometric residual has entropy
g(1), and f(T)=0. That preserves the true infinite law; no truncated
input is declared. Enumerating four-symbol distributions for n=1,...,6
and adding the exact residual entropy verifies the full entropy and
relative-entropy identities. This is not a numerical simulation of the
amplifier output or an all-n proof.

An independent finite noisy-parity fixture demonstrates why output-past
conditioning is unsafe. Let A_2=A_1 and B_2=B_1, with independent fair
A_1,B_1, and C_j=A_j xor B_j xor E_j for fresh noise probability 1/5.
The correct native-past Markov relation is exact. It gives
H(C_2|C_1)=0.6268694575... >= H(C_2|A_1,B_1)=0.5004024235... nats.
But I(A_2:B_2|C_1)=0.1927447570...>0: output conditioning correlates
the initially independent groups. This is only a structural
negative-control kernel, not an admitted thermal/amplifier source.

The final run took 0.3788357919547707 seconds, macOS peak RSS 20,152,320
bytes. Exact rational sign decisions and finite high-precision diagnostics
support their stated components; the physical kernel/entropy proof above
remains load-bearing. No physical data or experimental source certificate
was acquired.

## 7. Prior art, quantum boundary and costs

I independently opened the primary
[De Palma-Trevisan-Giovannetti 1705.00499v1, Section II](https://arxiv.org/html/1705.00499v1).
Its Theorem 2, Eq12, and classical Corollary 5 already use native
conditioning, conditional-entropy data processing, convexity and chain
rules to transfer single-copy output entropy bounds to correlated
classical sources. This is direct generic-method prior art. The current
two-input transfer still needs full A/B independence and admission of
EVERY conditional pair; the prior single-channel theorem is not imported
as an arbitrary two-nonthermal-input amplifier result. Exact interface
priority remains UNKNOWN.

A full matched Gaussian frame S on A and ZSZ on B intertwines the common-
gain amplifier with S on C, preserving all three entropies and A/B group
independence. The native conditional proof is applied BEFORE that frame.
Its noncommuting orbit can have internal entanglement, but no arbitrary
quantum-history Markov property is asserted afterward. Noncommuting
conditional entropies can be negative and conditioning on past outputs
can entangle the groups; that extension requires a different theorem.

The crucial supplied promise is conditional local energy matching and a
uniform row likelihood certificate at EVERY positive-probability native
history. Thermal marginals, small average relative entropy, small
pairwise correlations or a finite sample do not acquire this promise.
Analytic conditioning adds no physical measurement/record to the actual
map. Preparing a long-range latent bit, maintaining source memory,
enforcing A/B independence, output/control precision and any matched
squeezing all remain physical costs. Ideal mean pump-to-active energy
increment is 2 hbar omega H times the sum of input photon means plus N;
deterministic work, phase reference and disposal/reset are unacquired.

This is an entropy inequality with an explicit correlated mathematical
source. It does not construct a universal non-iid distillation receiver,
provide source tomography, or establish practical advantage, global
amplifier EPnI or external specialist acceptance.
