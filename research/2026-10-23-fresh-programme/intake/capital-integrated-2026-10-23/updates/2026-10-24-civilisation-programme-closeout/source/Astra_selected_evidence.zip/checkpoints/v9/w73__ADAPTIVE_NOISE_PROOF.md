# Adaptive acquisition of a positive forest with bounded action noise

Checkpoint 2, internal proof candidate, 2026-10-23. This is a new construction; the frozen first-checkpoint files have not been edited. Correctness, priority, experimental availability, practical advantage, and mission achievement remain separate statuses. The claimed theorem is mathematical acquisition under the explicitly supplied interface below. It is not evidence that this interface is available in a physical system.

## 1. Interface and exact quantifiers

Fix a labelled set V={0,...,n-1}, n>=2, and a finite, undirected, simple forest F=(V,E). Every edge has an unknown positive real weight w_e>=a, where the lower floor a>0 is supplied to the learner. The topology, weights, connected-component count, rooting, elimination order, and maximum degree are not supplied. Let L be its weighted graph Laplacian:

    (Lx)_i = sum_{j:ij in E} w_ij (x_i-x_j).

An action consists of preparing a specified full real input vector x in R^n and acquiring the full vector Lx+e. Each of the n output coordinates is an acquired scalar. A complete action is not one scalar query. Controls can be changed between actions, and later controls may depend on earlier acquired data. No graph-neighbourhood oracle is supplied. The operator must remain the same through all actions. Initially take x in {0,1}^n and assume every acquired scalar has absolute error at most eta, including deterministic bias, quantization, and stochastic error on a bounded-error event.

Theorem (candidate, proved below). For every such fixed L, every confidence 0<delta<1, and every eta<=a/64, an adaptive randomized learner uses at most

    ell = ceil(8 ln(4 n^2/delta)),
    T   = ceil(8 ln(2 n/delta)),
    Q   = (ell+1) T

complete binary actions and nQ acquired scalars. With probability at least 1-delta over its control randomization, it recovers the entire labelled support exactly. Every recovered edge also has an estimate with absolute error at most eta. The successful randomization event works simultaneously for all errors bounded by eta, even correlated or noncausal errors. No assertion is made for arbitrary real signed weights, directed edges, graphs with cycles, or missing readout coordinates.

The quantifier is

    for every fixed L, P_design[ for every bounded error transcript,
                                 support recovery is exact ] >= 1-delta.

It is not a statement that one random design succeeds simultaneously for every unknown L. The forest and positive-weight promises and the supplied nonzero lower floor a are premises. Finite observations do not certify those premises against unrestricted operators.

The case n=1 needs zero actions. All logarithms are natural. Some constants below are deliberately loose and may be reduced.

## 2. Label codes and a positive singleton certificate

Independently draw ell fair bits b_i in {0,1}^ell for each original vertex i. Define the code event G by

    d_H(b_i,b_j) >= ell/4 for all distinct i,j.

For a fixed pair, their Hamming distance is Binomial(ell,1/2). Hoeffding's inequality gives

    P[d_H(b_i,b_j)<ell/4] <= exp(-ell/8).

The union bound yields P[G^c]<=n(n-1) exp(-ell/8)/2 <=delta/8. In particular all codes are distinct on G. The learner may use a binary trie for exact code-to-label lookup. Drawing the code costs n ell independent random bits and O(n ell) storage/bit operations. The learner need not test all pairwise distances. If it does test or resample codes, the additional computation must be charged; the theorem here does not rely on resampling.

Suppose a row is known to have acquired a positive mixture of labels:

    m_0 = sum_{k in A} w_k,
    m_r = sum_{k in A} w_k b_{k,r},  1<=r<=ell,
    w_k>=a,

with distinct k, and each m coordinate is measured with error at most eta. Empty A is allowed. On G, the following procedure distinguishes empty, singleton, and nonsingleton mixtures exactly:

1. If mhat_0<=a/2, declare empty.
2. Otherwise form bit r as 1 precisely when mhat_r>=mhat_0/2. If this bit string is not a label code, reject it as nonsingleton.
3. For its candidate label j, calculate

       Chat(j) = sum_{r:b_jr=0} mhat_r
               + sum_{r:b_jr=1} (mhat_0-mhat_r).

   Accept singleton j only when Chat(j)<=a ell/8.

Proof. Empty mixtures have mhat_0<=eta<a/2, and nonempty mixtures have mhat_0>=a-eta>a/2. If A={j}, each threshold bit is correct: in a zero bit mhat_r<=eta<(a-eta)/2<=mhat_0/2; in a one bit mhat_r>=w_j-eta>(w_j+eta)/2>=mhat_0/2. For any candidate j, positivity gives the exact certificate

    C(j) = sum_{k in A} w_k d_H(b_k,b_j) >=0.

If A={j}, this is zero. Otherwise A contains k!=j and G gives C(j)>=a ell/4. The error in Chat is at most 2 ell eta<=a ell/32. Hence a true singleton has Chat<=a ell/32<a ell/8, and every other nonempty mixture has Chat>=7a ell/32>a ell/8. The procedure therefore returns every singleton and no false singleton, simultaneously for all bounded errors. The mass estimate mhat_0 then estimates its unique weight to error at most eta. No upper weight bound or maximum-degree bound enters the separation. Large masses still require sufficient readout dynamic range.

## 3. Null known components in the physical query

Maintain a set K of acquired true edges and the connected-component partition P of (V,K). Initially K is empty, so P consists of singletons. Within a batch, this partition remains frozen until all batch actions have been acquired.

For each current component C independently draw a fair bit g_C. Set h_i=g_C when i belongs to C. Query the ell+1 vectors

    x^0_i = h_i,
    x^r_i = h_i b_{i,r},  1<=r<=ell.

For each original vertex i in an inactive component C (g_C=0), all vertices in C have zero input in all these actions. Define mhat_r=-y^r_i from the acquired row. Then the noiseless part is exactly

    m_0 = sum_{j outside C, g_{C(j)}=1, ij in E} w_ij,
    m_r = sum_{j outside C, g_{C(j)}=1, ij in E} w_ij b_{j,r}.

This identity uses x_i=0 and actual zero input throughout C. Internal interaction terms vanish before the measurement is made. It does not subtract estimated weights or numerical residuals. Inputs in active components need not be constant there for r>=1; only rows in inactive components are decoded.

Apply the singleton procedure to every inactive row. If it returns label j, insert the edge ij and estimate w_ij by mhat_0. One can additionally require that j is outside C and active; correct returned singletons always satisfy these checks. De-duplicate discovered edges and merge their components only after the batch finishes.

Induction. On G every inserted edge is a true edge. Hence K is always a subforest of F, and its components are connected subtrees of F. An unacquired true edge cannot have both endpoints in one current component, since the known path plus that edge would be a cycle. Contracting current components in each original true tree therefore produces a simple tree, with one crossing edge per quotient adjacency. All inserted crossing edges are distinct true edges; adding any set of them reduces the component count by exactly its cardinality. Weight-estimate errors do not enter any later control.

This proves the classification of every row and the resulting partition evolution are independent of the error values, as long as all errors obey the bound. They may affect only the reported edge weights. This fact makes the probability argument valid even against bounded errors that see future random bits.

## 4. The quotient forest contracts in expectation

Let c_F be the unknown number of true connected components and let c_t be the current number of known components after t batches. Define the nonnegative integer potential

    P_t = c_t-c_F.

It is the number of still-unacquired true edges. Consider a nontrivial quotient tree with r>=2 vertices. At least r/2 of its vertices have degree 1 or 2. Indeed, writing l for that count, all other degrees are at least 3, whereas sum degrees=2r-2, so 2r-2>=l+3(r-l), giving l>r/2. This loose inequality is sufficient; stronger degree counting is unnecessary.

For a quotient component C of degree 1 or 2, the event

    g_C=0 and exactly one of its adjacent components is active

has probability 1/4. On that event precisely one true edge in the entire cut of C reaches an active component. Its original endpoint i in C consequently sees a singleton positive mixture and discovers this edge. Different successful components yield distinct such edges: an edge discovered in this way has its discovering endpoint component inactive and its other endpoint component active, so both endpoints cannot discover the same edge through these events. Additional discoveries can only improve the count.

For disjoint nontrivial quotient trees with sizes r_1,...,r_s, the number of degree-1-or-2 quotient vertices is at least sum r_j/2 >= sum(r_j-1)/2=P_t/2. Conditional on all past masks and on a fixed good label code, fresh independent masks therefore give

    E[number of newly acquired edges | past] >= P_t/8,
    E[P_{t+1} | past] <= (7/8) P_t.

No independence between success events at adjacent components is required; only linearity of expectation is used. By induction,

    E[P_T | G] <= (7/8)^T (n-c_F) <= n exp(-T/8) <=delta/2.

Since P_T is an integer, Markov's inequality gives P[P_T>=1 | G]<=delta/2. Combining with P[G^c]<=delta/8 proves success at least 1-5delta/8, which is stronger than the advertised 1-delta. Running the prescribed T batches does not require knowing c_F. For a connected input, reaching a single acquired component certifies completion within the forest promise and permits early stopping. The theorem's budget remains the worst-case fixed Q.

## 5. Costs, normalization, and noisy repetitions

The learner prepares n coordinates and acquires n coordinates per action. It uses Q=O(log^2(n/delta)) full actions, nQ scalar observations, n ell code bits, and O(nQ) code/moment operations plus union-find operations. A binary trie gives deterministic O(ell)-time label lookup without a scan over all n labels. Memory can be O(n ell+n). Each edge is output once; duplicate discoveries can be handled by endpoint-pair keys. In the forest there are at most n-1 edges total. Writing a dense n by n matrix would cost n^2 and is not needed for support output.

Binary raw inputs have full-row energy at most Q, not 1. To impose the complete-action row budget

    for every i, sum_{q=1}^Q |x^q_i|^2 <=1,

set the known integer c=ceil(sqrt(Q)) and actually prepare every specified raw input divided by c. Multiply each acquired output by c before decoding. Actual per-coordinate error must then obey

    epsilon <= a/(64c).

Thus the row normalization costs sqrt(Q), a factor polynomial in log n, in absolute precision. Every normalized control coordinate is exactly the rational 0 or 1/c. A global per-action Euclidean norm bound of 1 is a different resource constraint; the raw controls can have norm sqrt(n). Meeting that bound requires another factor up to sqrt(n), and would change the repetition costs. The theorem does not silently assume a global energy bound that it does not meet.

If normalized scalar readout errors in independent repetitions have conditional mean zero and sub-Gaussian variance proxy sigma^2, unchanged L and reproducible preparations are required. For an overall failure budget delta, run the design above with delta/2. Let its action bound be Q and c=ceil(sqrt(Q)). Averaging

    R >= max(1, ceil[(2 sigma^2/epsilon^2) ln(4 n Q/delta)]),
    epsilon=a/(64c),

repetitions of each action makes all nQ averaged errors at most epsilon except with probability delta/2, by a conditional tail bound and a union bound. This yields total QR=O(sigma^2 a^-2 Q^2 log(nQ/delta)+Q) complete preparations/actions/readouts and nQR scalar readouts. Repetition energy, resets, time, precision, and operator stability are charged separately; they are not cancelled by the unique-action row normalization. Deterministic bias is not averaged away. Quantization must fit inside the bounded-error budget, for example by reserving half the epsilon margin and changing the corresponding constant in R.

If a supplied upper weight bound is W and the maximum degree is D<=n-1, binary raw responses have magnitude at most DW. Readout precision eta costs O(log(1+DW/eta)) bits per scalar, with an analogous normalization scaling. Without an upper bound, adequate dynamic range is an unpriced interface premise and practical acquisition is UNKNOWN. No infinite-precision claim is used to cross the support margin, but the finite dynamic-range cost cannot be inferred from n and a alone.

Control accuracy also matters. If a normalized prepared coordinate differs from its prescribed 0 or 1/c by at most kappa, then ||L||_infinity<=2DW makes the extra response error at most 2DW kappa in each coordinate. Sufficient charged conditions for an imperfect instrument are therefore

    c (eta_sensor + 2DW kappa) <= a/64.

Thus a worst-case hub can require control accuracy of order a/(nWc), even though the sensor noise margin only costs a/c. This is a logarithmic number of accuracy bits, but a physical instrument's preparation cost need not be logarithmic. It has not been measured here. To retain actual whole-row energy <=1 as well as nominal energy, one may reserve a factor-two headroom by taking c=ceil(2 sqrt(Q)) and kappa<=1/(2 sqrt(Q)); the triangle inequality on each full control row gives the budget. The theorem with exact binary/rational controls does not itself establish affordable control accuracy, and preparation error is not a free oracle.

The asymptotic Q bound can have large constants. At moderate n its explicit Q may exceed the n standard-basis actions which reconstruct every matrix. Practical superiority is therefore UNKNOWN. Neither a polylogarithmic action count nor synthetic replay proves an improvement over the best equally informed graph sketches, group-testing protocols, or physical instrument.

## 6. Optional full-matrix estimation after acquiring support

The preceding output weights each have coordinate error <=eta. Rebuilding the Laplacian diagonal by summing edge estimates can amplify degree, so that step does not by itself give a constant Frobenius stability factor.

A simple ordinary known-support control handles full-matrix estimation with three new actions. Root each acquired tree, color each vertex by depth mod 3, and let its three-coordinate row code be the corresponding standard unit vector. Query the three code columns. For any symmetric matrix A supported on the known forest with arbitrary free diagonal, at row i the own-color output isolates A_ii; the parent-color output isolates the unique edge A_i,parent(i), since all children have the third color. Read each edge from its child row and copy it symmetrically. For any full output error matrix E, the constructed estimate satisfies

    ||Ahat-A||_F^2 <= 2 ||E||_F^2.

The read diagonal errors and child-parent errors occupy distinct readout coordinates, and each edge error is copied twice. This proves the bound directly. For Laplacians, orthogonally projecting Ahat onto the linear space of matrices with the acquired Laplacian support can only decrease distance to the true L. This projection and its computation must be charged if required. Positivity can likewise be enforced by projection onto the closed cone on that support.

These three actions require the support already to be correct and are an ordinary matched baseline, not claimed as a novel contribution. For a single global row-energy budget over acquisition and finishing, use c=ceil(sqrt(Q+3)) on all columns and undo the common factor. The acquisition precision threshold changes accordingly. The full-matrix Frobenius conclusion is conditional on the support-success event and the actual acquired finishing errors, not an assertion that the earlier support theorem estimated the entire matrix stably.

## 7. Evidential and priority status

The load-bearing bridge is the use of actual controls to null every already acquired internal interaction, followed by a positive code-distance certificate and a contracting quotient forest. It removes fitted-weight error propagation and the earlier n^-5 support precision threshold. The theorem supplies a conditional mathematical acquisition capability; it does not establish a practical scientific discovery.

Degeneracy peeling, local linear sketches, singleton decoding, and error-detecting codes are well-established mechanisms. Becker et al. (2011), Guha--McGregor--Tench (2015), and Becker--Montealegre--Rapaport--Todinca (2020) already provide consequential related graph-reconstruction baselines. A source audit must determine whether the exact unknown weighted Laplacian / adaptive controls / bounded adversarial action-noise combination is new or a routine consequence of stronger incumbents. Novelty: UNKNOWN. Physical interface validation: NOT_ACQUIRED. Practical advantage: UNKNOWN. Mission achievement: NOT_ACHIEVED.
