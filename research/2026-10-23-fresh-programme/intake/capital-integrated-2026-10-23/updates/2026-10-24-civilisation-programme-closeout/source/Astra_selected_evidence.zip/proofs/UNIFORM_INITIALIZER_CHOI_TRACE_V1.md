# Uniform product-initializer converse for the recurrent tree device

23 October 2026. Independent construction by w19, followed by fresh internal
reconstruction from root and w36; w49's hash-specific criticism is pending.
The initial route was frozen before peer operator-route exchange as
`CONSTRUCTION_BEFORE_PEERS.md`, SHA256
`38951ca5e5ff13929abeaa15f8675bc46d5f6f0ff85a3b3c07d289060d1d2d47`.
This complete version makes the chronological and whole-resource scope explicit.
Generic Choi positivity and deterministic-comb tools are established. Historical
priority and external proof certification remain UNKNOWN.

## 1. Exact device and quantifiers

The unchanged bath is E=C^2_seed tensor F(C^2), with word basis(s,w).
S_j prepends color j; R exchanges the two vacuum seeds and is zero off vacuum.
They obey

    S_i^*S_j=delta_ij I, sum_j S_jS_j^*=I-P0,
    R=R^*, R^2=P0.

The qutrit input/output interaction is

    U=[[R,S1,S2],[S1^*,0,0],[S2^*,0,0]],
    V_beta=alpha U+i beta I, alpha=sqrt(1-beta^2),
    b=beta^2 in[0,1], a=1-b.

Every positive integer N may use a different arbitrary normal bath density
tau_N, without support, entropy, depth, tail or coherence bounds. The device
always uses the same evolving bath for its N calls, in chronological order.
There is no bath reset, bath access or changed interaction.

The bath is initially independent of the ENTIRE laboratory resource. The
laboratories may have arbitrary normal local memories and preshared resources
among themselves. A fresh logical input/reference is independent of the whole
initial resource. No initial bath--laboratory entanglement or correlation is
assumed free. The initializer's inaccessible purifier is part of the environment.
For fixed-call block coding the whole encoded physical input is independent
of the bath. The chronological extension below allows adaptive local actions,
all laboratory preshares and backward messages, while retaining this initial
bath/laboratory product condition and no extra forward Alice-to-Bob wire.

The output is an unconditional fixed K-dimensional logical register, with
all failures counted and a trace-preserving decoder. F_N means overlap with
the normalized maximally entangled state Phi_K on fresh reference and receiver.
There is no postselected success normalization.

## 2. General finite-port weighted Choi-trace lemma

Let a finite-dimensional port interact with arbitrary memory by bounded
unitary V. Write K_oi=<o|V|i>. Fix a faithful diagonal one-port output
density sigma=diag(s_o), and define the normal completely positive memory map

    Theta_sigma(X)=sum_(i,o) s_o^-1 K_oi^* X K_oi.

Suppose Theta_sigma(I)<=h I. For every N and every independent normal tau_N,
the N-call chronological Choi operator satisfies

    J_N(tau_N)<=h^N I_(A^N) tensor sigma^(tensor N).           (1)

Here J_N uses the UNNORMALIZED maximally entangled vector
sum_i |i>_reference |i>_input on each physical input port. Thus the right
side is h^N times the Choi operator of the normalized product-replacer process.

Proof. Define the positive finite-dimensional matrix

    Z_N=(I tensor sigma^(-tensor N/2)) J_N
                     (I tensor sigma^(-tensor N/2)).

Its largest eigenvalue is at most its trace. The exact trace identity is

    Tr Z_N=Tr[sigma^(-tensor N) N_N^(tau_N)(I_input)]
          =Tr[tau_N Theta_sigma^N(I)].                       (2)

To verify chronology directly, the memory block of history(i_1,...,i_N;
o_1,...,o_N) is P=K_(o_N i_N)...K_(o_1 i_1). The trace sums

    sum_(i,o) (product_t s_(o_t)^-1) Tr(tau_N P^*P).

Summing the final call first replaces its squared block by Theta_sigma(I);
then the next earlier call inserts that operator between its block and
adjoint. The result is exactly Theta_sigma^N(I), with chronological order
preserved. Intermediate interference is retained inside the products. No
classical history approximation, fresh-memory factorization or normalized
maximally-mixed input is used.

Since Theta_sigma is positive, induction gives
Theta_sigma^N(I)<=h^N I. Normality and Tr tau_N=1 bound(2) by h^N.
Then Z_N<=h^N I, and conjugation proves(1). All port matrices are finite.
Memory identity is never traced: only a bounded memory operator against a
normal density occurs. The proof therefore covers arbitrary infinite normal
initializers without a truncation or interchange of divergent sums.

The Choi criterion gives the block-channel form

    N_N^(tau_N)<=_CP h^N R_(sigma^N),
    R_(sigma^N)(X)=Tr(X) sigma^(tensor N).                    (3)

No claim of optimality is made for replacing lambda_max(Z_N) by Tr Z_N.
The usefulness here comes from the exactly evaluable whole-memory envelope.

## 3. Whole-memory evaluation including the physical root

The only nonzero blocks are

    K_00=alpha R+i beta I,
    K_(j0)=alpha S_j^*, K_(0j)=alpha S_j,
    K_(jj)=i beta I, j=1,2.

Self-adjointness of R cancels the cross terms:
K_00^*K_00=aP0+bI. Take

    sigma_p=diag(p,(1-p)/2,(1-p)/2), 0<p<1.

Summing separately by output label gives

    Theta_p(I)=[(2-b)/p+(2+2b)/(1-p)]I
                     +a[1/p-2/(1-p)]P0.                    (4)

For example, the zero output contributes
[aP0+(b+2a)I]/p, and the two colored outputs contribute
2[a(I-P0)+2bI]/(1-p). Their sum is(4). No off-root-only surrogate or
root removal is made.

For p>=1/3 the root correction is nonpositive. Thus the lemma applies with

    H_b(p)=(2-b)/p+(2+2b)/(1-p).

At p=1/2,

    Theta_(1/2)(I)=(8+2b)I-2aP0,
    J_N(tau_N)<=(8+2b)^N I_A tensor sigma_*^(tensor N),
    sigma_*=diag(1/2,1/4,1/4).                              (5)

This is uniform in every normal horizon-dependent coherent tau_N. In
particular no initial-coherence price is needed for a product bath resource.
Theta_p(P0) need not be diagonal or a scalar kernel: positivity alone
iterates the inequality Theta_p(I)<=H_b(p)I.

Minimizing this scalar envelope gives

    p_b=sqrt(2-b)/[sqrt(2-b)+sqrt(2+2b)] in[1/3,1/2],
    H_b=[sqrt(2-b)+sqrt(2+2b)]^2
       =4+b+2sqrt(4+2b-2b^2).                              (6)

The constraint p>=1/3 is satisfied for all b in[0,1]. Therefore

    J_N(tau_N)<=H_b^N I_A tensor sigma_(p_b)^(tensor N).      (7)

This is never worse than the explicit(8+2b)^N choice. H_0=8 and H_1=9;
the beta=1 identity qutrit has its correct trivial dimension ceiling.

This optimization is NOT asserted better than the source's separate
fixed-normal-initializer t-optimized bound. The latter can have a smaller
order-b^2 correction under its narrower initializer promises. Preserve the
best applicable bound by resource regime. Here the new point is uniformity
over arbitrary varying product coherent initializers and removal of the
polynomial prefactor, not an optimal finite-beta coefficient.

## 4. Arbitrary block encoders and the Bell K^-2 factor

For any CPTP encoder into all N input ports, the encoded state omega_RA
satisfies omega_R=I_R/K, whether its physical input is mixed or the encoder
keeps/discards local ancillas. Under initial bath independence, complete
positivity of(3) and any CPTP decoder D give

    (id_R tensor D N_N)(omega_RA)
        <= H_b^N (I_R/K) tensor D(sigma_(p_b)^N).

The normalized product on the right has Bell overlap

    Tr[Phi_K ((I_R/K) tensor D(sigma^N))]=1/K^2.

Thus

    F_N<=min{1,H_b^N/K^2}.                                  (8)

There is no isometric-encoder restriction or substitution of physical-input
entropy for fresh logical dimension. Bath purifier size never enters.

## 5. Chronological extension, preshares and backward messages

The same J_N is the deterministic N-slot process Choi operator of the actual
recurrent device. It obeys the prefix causal constraints

    Tr_(B_n) J_n=I_(A_n) tensor J_(n-1), J_0=1.

The normalized product-replacer process J_R,n obeys the same constraints.
Set the SINGLE global constant C_N=H_b^N for all prefixes in this argument,
and define

    D_n=[C_N J_R,n-J_n]/(C_N-1), n=0,...,N.

By(7), D_N is positive. Taking successive causal partial traces shows that
every D_n is positive. Their trace constraints are the same deterministic
constraints, with D_0=1. Therefore D_N is a normalized deterministic process.
Equivalently,

    J_R,N=(1/C_N)J_N+(1-1/C_N)D_N.                          (9)

The characterization of positive causally normalized Choi operators as
deterministic quantum networks is established comb theory. Inserting any
legal adaptive laboratory strategy into(9) preserves the convex combination
and produces normalized positive outputs. Consequently its final actual
state is bounded by C_N times its final replacer state. It would be invalid
to use independently normalized difference constants at each prefix; the
same global C_N is essential here.

The strategy may use arbitrary initial laboratory preshares, local memories,
measurements with all branches retained, and Bob-to-Alice quantum/classical
messages. Its initial resource is independent of both the bath and the fresh
logical input. Under the replacer process there is no Alice-to-Bob signalling
path: all forward outputs are fixed and independent, and backward messages
cannot convey Alice's fresh input to Bob. Trace-preserving local actions and
no-signalling therefore give a final reference/receiver product with the
same fresh reference I_R/K. Its Bell overlap is again1/K^2, so(8) holds for
the full same-interface chronological strategy.

Finite port combs suffice even when local memories are normal infinite
systems; finite-subspace approximations of their states/operations and trace
continuity give the same inequality, or one may use the normal CPTP strategy
contraction directly. No extra forward wire, bath access or postselected
normalization is inserted. Initial bath--laboratory correlations are not
covered by simply regarding a fresh logical input as independent: that
weaker condition would not justify the product-initialized process model.

## 6. Answer at beta=0 and complete resource boundary

At beta=0, H_0=8. For every N, every normal product bath initializer tau_N,
every allowed initial laboratory resource, and every legal N-call strategy,

    F_N<=min{1,8^N/K_N^2}.                                  (10)

Hence log2(K_N)/N>=3/2+delta with fixed delta>0 implies
F_N<=2^(-2delta N). Full qutrit transmission K_N=3^N obeys
F_N<=(8/9)^N. The conclusion is uniform, so there is no family-dependent
tail modulus, no fixed-initializer order-of-limits caveat, and no coherence,
depth, entropy or coordinate-rank penalty for a product bath state.

For general beta, the same uniform strong-converse ceiling is

    Q<= (1/2)log2 H_b.

Matching the beta=0 ceiling to a lower construction still uses the inherited
coding theorem at its exact scope; no achievability is inferred from this
upper bound. The construction question posed here has a negative answer for
independent coherent bath families: spending arbitrary preparation resources
on local bath coherence cannot increase the rate above3/2.

The proof is deliberately stronger than any finite preparation budget: it
grants arbitrary normal tau_N for free and still gives the same obstruction.
Thus no physical preparation, gate/depth compiler, clock, bath tomography,
energy, control accuracy or reset cost is acquired or claimed. All N forward
calls count. Backward bandwidth and local preshares are allowed only to
strengthen this upper bound; their physical costs are not claimed negligible.

An initial bath--laboratory entangled resource is a separate remaining
possibility, not supplied by a coherent density of the bath alone. Fresh
logical independence from that whole resource must be maintained. This
proof does not claim a high-rate construction from a correlation lower
bound, nor collapse that resource into a free initializer.

## 7. Sources and status

The exact source snapshots/hashes are in `PINNED_SOURCES.json`; the device
and inherited baseline come from Cycle11 and w49V4. w36's corrected vertex
proof was read only AFTER the independent trace route was frozen. Root and
w36 independently reconstructed the new whole-memory envelope and trace
identity. Those are internal reviews, not external certification.

Choi positivity, trace bounds, completely positive order, no-signalling and
normalized comb causality are established tools. The network characterization
used in Section5 is given in Chiribella--D'Ariano--Perinotti,
*A theoretical framework for quantum networks*, arXiv0904.4483. Anshu,
*An upper bound on quantum capacity of unital channels*, arXiv1611.09248,
provides a primary norm-to-code-converse comparator; no unital hypothesis or
its specific formula is imported here. Historical priority of this evaluated
device-specific route remains UNKNOWN. No physical capability or practical
advantage is established by the ideal converse.
