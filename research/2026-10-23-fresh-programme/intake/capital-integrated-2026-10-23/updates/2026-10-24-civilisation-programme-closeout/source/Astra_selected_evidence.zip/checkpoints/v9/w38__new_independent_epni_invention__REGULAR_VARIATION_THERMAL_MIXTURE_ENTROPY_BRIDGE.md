# A nonanalytic entropy bridge for finite-energy thermal mixtures

23 October 2026. W38. NEW independent candidate. Full fresh criticism is
pending. Earlier finite-moment and exponential-tail proofs are unchanged.
The general UNHEATED independent-input finite-energy EPnI is NOT_ACHIEVED.

## 1. Exact proposed class and coefficient

Let R>=0 have a probability density f_R with

    f_R(v) ~ C v^(-alpha-1), v->infinity,
    C>0, 1<alpha<4.                                    H1

Its behavior on bounded v may be arbitrary. It has finite mean a=ER and
finite beta-th moment whenever beta<alpha. Let tau_v denote the one-mode
thermal state of mean v and define the ACTUAL unflagged source

    rho_R=E tau_R.

At every finite heat T, same-energy thermal chi-squared may be infinite.
The proposed relative-entropy asymptotic is instead

    D(H_T rho_R || tau_(T+a))
      ~ [C Gamma(alpha)/(alpha-1)]
                     T^(-alpha)(alpha ln T)^(1-alpha). H2

Thus the leading rate is not an integer moment expansion. The proof
below locates its positive entropy mass near photon/classical radial
scale T ln T, with neither global L2 nor a high photon moment premise.

For two independent sources of this class with the SAME alpha in(1,4),
arbitrary C_A,C_B>0, apply ACTUAL equal input heat T and a fixed G>1
amplifier. Write lambda=G-1, s=2G-1, theta=G/s, phi=lambda/s. The proposed
ACTUAL entropy-form EPnI gap is asymptotic to

    Gamma(alpha)/(alpha-1)
       *[(theta-theta^alpha)C_A+(phi-phi^alpha)C_B]
       *T^(-alpha)(alpha ln T)^(1-alpha).               H3

Its coefficient is strictly positive because alpha>1 and theta,phi in(0,1).
This gives eventual exact EPnI for this finite-energy heavy-tail class.
It asserts neither zero-heat EPnI nor a general finite-energy completion.

## 2. Exact classical radial comparison

The positive-P amplitude of tau_v is a centered complex Gaussian with
variance v. After heat t, its squared radius r has density

    h_t(r)=E [(t+R)^(-1) exp(-r/(t+R))], r>=0.

The matching Gaussian radial density is

    q_t(r)=(t+a)^(-1) exp(-r/(t+a)).

The full two-real-dimensional classical relative entropy is exactly the
radial one; their common uniform angle and its pi factor cancel. Put

    k_x(y)=(1+x)^(-1) exp[-y/(1+x)],
    H_t(y)=t h_t(ty)=E k_(R/t)(y), Q_t(y)=k_(a/t)(y),
    Phi(h,q)=h ln(h/q)-h+q >=0.

Normalization gives D(h_t||q_t)=integral_0^infinity Phi(H_t,Q_t)dy. This
entropy is finite: convexity bounds it by the expectation of the finite
Gaussian variance comparison, and ER is finite. No subtraction of infinite
entropies and no global chi-squared is used.

## 3. A uniform bulk-plus-tail density error

Choose beta with

    max(1,alpha/2)<beta<=2, beta<alpha.                 H4

Such a beta exists precisely throughout the interval 1<alpha<4 used here.
Fix delta in(0,1), independent of t. On 0<=x<=delta,

    |k_x-k_0-x k'_0|
      <=C_delta x^beta(1+y)^2 exp[-y/(1+delta)].

Indeed the second x derivative is a polynomial of degree at most2 in y,
times the same exponential with bounded rational prefactors. Taylor's
integral remainder is O(x^2), and x^2<=delta^(2-beta)x^beta. Therefore
integrating R<=delta t gives an O(t^-beta) remainder. Omitting the mass
and first moment on R>delta t changes the two lower terms by
O(t^-alpha)(1+y)e^-y, since H1 implies

    P(R>delta t)=O(t^-alpha),
    E[R 1_(R>delta t)]=O(t^(1-alpha)).

The reference k_(a/t) has its own O(t^-2) second-order remainder. For the
remaining tail contribution, H1 gives f_R(v)<=C0 v^-alpha-1 for large v.
Rescale v=tx in its integral. For all y>=0,

    E[k_(R/t)(y)1_(R>delta t)]
      <=C_delta t^-alpha (1+y)^(-alpha-1).

For y>=1 this follows from 1+x<=(1+1/delta)x and the convergent integral
of x^(-alpha-2)exp[-delta y/((1+delta)x)] over x>0. For y<=1 use its finite
total integral. Consequently, for all sufficiently large t and all y>=0,

    |H_t(y)-Q_t(y)| <=A_t(y)+B_t(y),
    A_t=C_delta t^-beta(1+y)^2 e^(-c y),
    B_t=C_delta t^-alpha(1+y)^(-alpha-1),
    c=1/(1+delta)>1/2.                                H5

This estimate is allowed even though its square divided by Q_t is NOT
globally integrable. It will be used quadratically only before crossover.

## 4. The pre-crossover region contributes negligibly

Set L=alpha ln t and b_t=t^-alpha L^(1-alpha). Fix eta in(0,1). Because
Q_t(y)>=c0 e^-y for large t and Phi(h,q)<=(h-q)^2/q pointwise, H5 gives

    integral_0^((1-eta)L) Phi(H_t,Q_t)dy
      <=C t^(-2beta)
          +C t^(-2alpha) exp[(1-eta)L]
      =O(t^(-2beta))+O(t^(-alpha(1+eta)))=o(b_t).       H6

The first integral is finite because 2c-1>0; the second uses
integral_0^Y e^y(1+y)^(-2alpha-2)dy<=e^Y. Its exact polynomial factor is
unnecessary. The key strict relation is 2beta>alpha. This is the step that
would fail in this form at alpha=4.

## 5. The transition band has vanishing scaled entropy as its width shrinks

For r>=|h-q|, a useful scalar estimate is

    Phi(h,q)<=r[1+ln(1+r/q)].

For h>=q it follows from Phi(q+r,q)<=r ln(1+r/q); for h<=q, Phi(h,q)<=r.
The right side increases with r. Its convexity also bounds the value at
A+B by

    A[1+ln(1+2A/q)]+B[1+ln(1+2B/q)].

Fix delta0>0 sufficiently small that, for all sufficiently small eta>0,

    beta+alpha(1-eta)/(1+delta0)>alpha.

Use H5 with this FIXED delta0 throughout the band
(1-eta)L<=y<=(1+eta)L. The A term has an exponentially decaying y factor;
even multiplying it by O(L), its integral is o(b_t) by the displayed
strict exponent. For B use Q_t>=c0e^-y and t^-alpha=e^-L. On the band,
for large t,

    ln(1+2B_t/Q_t)<=C+(y-L)_+.

The negative -(alpha+1)ln(1+y) only helps. Hence its integral is bounded by

    C_delta0 t^-alpha L^-alpha O(eta)
       +C_delta0 b_t integral_1^(1+eta)
                          u^(-alpha-1)(u-1)du.

It follows that

    limsup_(t->infinity) band_entropy/b_t
         <=C_delta0 O(eta^2), eta->0.                 H7

The constant delta0 is held FIXED as eta shrinks. No divergent
delta=eta constant is used to conclude a vanishing transition-band cost.

## 6. The far tail gives the exact leading constant

Fix eta>0 and u>=1+eta. Put r=t L u. Split the defining density integral
at R=delta t, choosing here delta<eta. The R<=delta t contribution is at
most t^-1exp[-Lu/(1+delta)]. After multiplying by r^(alpha+1), it tends
to zero since u>1+delta. For the remainder put R=rw. H1 gives pointwise

    r^(alpha+1) h_t(r) -> C Gamma(alpha+1)=:A.

The domination is explicit: w>=delta t/r implies t/r<=w/delta, so the
rescaled integrand is bounded by a constant times
w^(-alpha-2)exp[-delta/((1+delta)w)], which is integrable on(0,infinity).
Its limit is C w^(-alpha-2)e^(-1/w), with integral C Gamma(alpha+1).

Thus at fixed u>1,

    h_t(tLu) ~ A(tLu)^(-alpha-1),
    ln[h_t(tLu)/q_t(tLu)]/L ->u-1.

For integration over the full half-line u>=1+eta, the upper bound

    h_t(tLu)<=t^-1e^[-Lu/(1+delta)]
                  +C(tLu)^(-alpha-1)

and h_t<=1/t give an integrable scaled entropy dominator. In detail,

    Phi(h_t,q_t)
       <=h_t[r/(t+a)+ln((t+a)/t)]+q_t.

After the Jacobian tL and division by b_t, the polynomial part is bounded
by C u^-alpha, integrable since alpha>1. The Gaussian part is bounded by
an integrable exponential in u: its prefactor has form
L^(alpha+1)exp[L-Lu/(1+delta)], and u>=1+eta>1+delta leaves a strict
positive decay margin. The q_t part is handled identically, with
t/(t+a)->1. Thus dominated convergence, with no ignored remote tail,
proves

    lim tail_entropy/b_t
       =A integral_(1+eta)^infinity u^(-alpha-1)(u-1)du. H8

The pointwise limit uses Phi/h=ln(h/q)-1+q/h and q/h->0. Combining H6-H8
and letting eta down to zero gives

    D(h_t||q_t)/b_t ->A/[alpha(alpha-1)]
                         =C Gamma(alpha)/(alpha-1).   H9

All integrands are nonnegative. The lower bound follows from H8 alone;
the upper bound adds the o(b_t) core and H7's vanishing-width band.

## 7. Exact normal quantum transfer

The actual state H_T rho_R=E tau_(T+R) has coherent preparation law with
radial density h_T. Its heterodyne law has h_(T+1). The same two laws for
its matched thermal tau_(T+a) are q_T and q_(T+1). Normal preparation and
measurement DPI give

    D(h_(T+1)||q_(T+1))
      <=D(H_T rho_R||tau_(T+a))<=D(h_T||q_T).

Since b_(T+1)/b_T->1, H9 proves H2. Every state has finite energy and
entropy; matching against the thermal logarithm therefore also gives the
exact identity D=g(T+a)-S(H_T rho_R). This is the ACTUAL normal quantum
entropy, not its classical replacement. The classical mixture variables
R and amplitude are analytic representations, with no acquired flags.

## 8. Tail addition through the actual amplifier

For independent sources rho_RA,rho_RB, condition only mathematically on
the two temperatures. Exact thermal Gaussian channel algebra makes the
retained state

    rho_C(T)=E tau_(sT+W),
    W=lambda+G R_A+lambda R_B.

Its finite mean is lambda+G a_A+lambda a_B. Scaling a density in H1 by
a positive c multiplies its power-tail coefficient by c^alpha. Moreover,
for two independent positive densities with the same exponent alpha,

    f_(X+Y)(v) ~ (C_X+C_Y)v^(-alpha-1).

An elementary proof splits its convolution at x=v/2. On the first half,
v^(alpha+1)f_Y(v-x) is uniformly bounded and tends to C_Y for fixed x;
dominated convergence against the probability density f_X gives C_Y.
Changing variables on the second half gives C_X. The same split supplies
a uniform O(v^-alpha-1) upper bound. A fixed shift does not change the
coefficient. Therefore W has tail coefficient

    C_W=G^alpha C_A+lambda^alpha C_B.

Apply H2 at heat sT for this output law. Since ln(sT)/lnT->1,

    d_A ~ K C_A b_T, d_B ~K C_B b_T,
    d_C ~K(theta^alpha C_A+phi^alpha C_B)b_T,
    K=Gamma(alpha)/(alpha-1).

The matching Gaussian inputs and output are thermal, so their EPnI
baseline is EXACTLY zero. The entropy-target derivatives tend to theta,
phi, with O(1/T) error; its Hessian stays bounded. These elementary
scalar facts are independently reconstructed in frozen d0e95b06...
Sections3,5 and its W17 receipt52e1a998.... Taylor's finite remainder is
O((d_A+d_B)^2)=o(b_T), proving H3. The strict positive coefficient gives
the inequality for every sufficiently large finite T, not merely a
selected subsequence. Source pair and G are fixed before T grows.

Actual products of finitely many separately certified one-mode pairs
also satisfy multimode EPnI by additivity and the established convexity
of the same scalar entropy target. This is an ACTUAL product closure;
no intermode-correlated-source theorem is inferred.

## 9. Explicit original Pareto family and boundaries

For the original coherent mixture

    (p-1)/[pi b(1+|alpha|^2/b)^p], b>0, p>2,

one has exactly R=b/U with U~Gamma(p-1,1). Put alpha=p-1. Its density
coefficient is C=b^alpha/Gamma(alpha), and mean a=b/(alpha-1). Thus for
2<p<5 the proposed exact quantum asymptotic is

    D(H_T rho_(p,b)||tau_(T+a))
        ~ b^alpha/(alpha-1)
                 T^-alpha(alpha ln T)^(1-alpha).       H10

For two same-p sources with arbitrary b_A,b_B>0, H3's coefficient becomes

    [(theta-theta^alpha)b_A^alpha
        +(phi-phi^alpha)b_B^alpha]/(alpha-1)>0.

This covers finite-energy states lacking the high moments used in the
earlier bridge, including p arbitrarily close to2. All finite post-heat
thermal chi-squared defects remain infinite. For p>5 the separate frozen
finite-moment proof a3b10a02... already has a different order-T^-4 leading
term; H10 is NOT asserted there. The critical p=5 (alpha=4) is not proved
by this note: H4 then cannot have 2beta>alpha, and the Gaussian bulk may
contribute at order T^-4. The assumption gap is stated, not passed over.

For a general finite-energy state or even a general thermal-mixture law,
H1's exact power density need not hold. No approximation/density argument
or source-uniform threshold is supplied. Different tail exponents between
the two ports and slowly varying factors require separate control; this
note does not infer them merely from the same-exponent computation.

The added heat changes actual inputs and supplies T photons to each mode.
At T>=1 it is entanglement breaking. The present sources are already
positive mixtures of thermal/coherent states; no surviving entanglement
resource or free R record is supplied. Source/tail-law certification, pump,
preparation, calibration, precision, entropy acquisition, disposal and
reset remain unimplemented. No device, publication or public action was
taken. Generic regular-variation/scale-mixture tools have prior literature;
exact historical priority of H9/H2/H3 remains UNKNOWN. Primary comparison
is distinct from the pending fresh proof criticism.

Main fresh falsification targets: the global error H5, transition-band
constant order in eta, the far-tail integrable dominator, coefficient
Gamma(alpha+1), output density-tail addition, and quantum one-unit times.
The original general UNHEATED finite-energy EPnI remains NOT_ACHIEVED.
