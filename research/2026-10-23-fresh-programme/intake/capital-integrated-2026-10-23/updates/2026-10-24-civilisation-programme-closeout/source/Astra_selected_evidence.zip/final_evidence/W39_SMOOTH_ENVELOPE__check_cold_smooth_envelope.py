"""New W39 smooth-envelope controls, with no producer/peer imports.

Exact photon-kernel/thermal-amplifier identities are distinguished from
arbitrary-precision asymptotic controls and floating actual-quantum entropy
truncations. Numerical quadrature is NOT interval certification. No source
data or device has been acquired. All temperature labels are analytic.
"""
from pathlib import Path
from fractions import Fraction as F
import hashlib
import json
import math
import time
import mpmath as mp
import numpy as np

HERE=Path(__file__).resolve().parent
SPACE=HERE.parents[3]
TARGET=SPACE/'work/workers/w38_fresh_inventory_critic/new_independent_epni_invention'
mp.mp.dps=60

ENVS=[('critical1.05','critical',mp.mpf('1.05')),
      ('critical1.5','critical',mp.mpf('1.5')),
      ('critical2','critical',mp.mpf(2)),
      ('critical4','critical',mp.mpf(4)),
      ('power1.2','power',mp.mpf('1.2')),
      ('power2','power',mp.mpf(2)),
      ('power4','power',mp.mpf(4)),
      ('oscillating_plus','osc',mp.mpf('.25')),
      ('oscillating_minus','osc',mp.mpf('-.25'))]


def logell(env,x):
    _,kind,p=env
    if kind=='critical':return -mp.log(x)-p*mp.log(mp.log(x))
    if kind=='power':return -p*mp.log(x)
    return -2*mp.log(x)+p*mp.log(x)*mp.sin(mp.log(mp.log(x)))


def ell(env,x):return mp.exp(logell(env,x))


def dlogell(env,x):
    _,kind,p=env
    if kind=='critical':return -(1+p/mp.log(x))/x
    if kind=='power':return -p/x
    h=mp.log(mp.log(x))
    return (-2+p*(mp.sin(h)+mp.cos(h)))/x


def exact_quantum_kernel_controls():
    poisson=gamma=amp=0
    for m in (F(1,4),F(1),F(3,2),F(4),F(16),F(65)):
        q=m/(m+1)
        for k in range(25):
            # Integral e^(-r/m)/m times the Poisson kernel, using Gamma.
            got=F(1,m)*(1+1/m)**(-k-1)
            assert got==(1-q)*q**k;poisson+=1
            coeff=sum((F(q**n*(-1)**(k-n),math.factorial(n)*math.factorial(k-n)) for n in range(k+1)),F(0))*(1-q)
            assert coeff==(1-q)*(q-1)**k/math.factorial(k);gamma+=1
    for G in (F(11,10),F(2),F(7)):
        la=G-1;s=2*G-1
        for T in (F(1),F(4),F(16),F(64)):
            for rA in (F(0),F(1),F(13,3)):
                for rB in (F(0),F(2),F(7,2)):
                    assert G*(T+rA)+la*(T+rB+1)==s*T+la+G*rA+la*rB;amp+=1
    return {'exact_Poisson_preparation_coefficients':poisson,
            'exact_Gamma_heterodyne_series_coefficients':gamma,
            'exact_actual_amplifier_temperature_identities':amp}


def mellin_and_shifts():
    rows=[];shifts=[];wrong=[]
    wlo=mp.mpf(-36);whi=mp.log(64)
    for env in ENVS:
        for v0 in (16,64,256,1024):
            v=mp.mpf(v0)
            fn=lambda w:mp.exp(2*w-mp.exp(w)+logell(env,v-w)-logell(env,v))
            value=mp.quad(fn,[wlo,-8,0,whi])
            residual=(value-1+(1-mp.euler)*dlogell(env,v))*v*v
            assert abs(residual)<1000
            rows.append({'envelope':env[0],'v':v0,'normalized_mellin_value':mp.nstr(value,30),
                         'v_squared_relative_second_order_remainder':mp.nstr(residual,25)})
            if v0==1024:
                bad=(value-1-(1-mp.euler)*dlogell(env,v))*v*v
                assert abs(bad)>10
                wrong.append({'envelope':env[0],'wrong_sign_scaled_residual':mp.nstr(bad,20)})
        for x0 in (16,64,256,1024,1000000):
            x=mp.mpf(x0);Y=x-logell(env,x)+2*mp.log(x);b=mp.log(Y)
            ratio=lambda u:mp.exp(logell(env,x+u)-logell(env,x))
            M_error=b-mp.quad(ratio,[0,b])
            rel=ratio(b)-1
            negative=-2*mp.log(x)
            shifts.append({'envelope':env[0],'l':x0,'growing_b':mp.nstr(b,20),
                           'b_minus_log_l':mp.nstr(b-mp.log(x),20),
                           'M_shift_error_divided_by_ell':mp.nstr(M_error,20),
                           'ell_shift_relative_error':mp.nstr(rel,20),
                           'negative_cutoff_ell_ratio':mp.nstr(ratio(negative),20)})
        assert abs(mp.mpf(shifts[-1]['M_shift_error_divided_by_ell']))<mp.mpf('.002')
    # A genuinely measurable discontinuous error, no derivative assumed.
    jumps=[]
    for v0 in (16,64,256):
        env=ENVS[2];v=mp.mpf(v0)
        points=[wlo,whi]
        kmin=int(mp.floor((v-whi)/mp.pi));kmax=int(mp.ceil((v-wlo)/mp.pi))
        for k in range(kmin,kmax+1):
            w=v-k*mp.pi
            if wlo<w<whi:points.append(w)
        points=sorted(points)
        def fn(w):
            u=v-w;e=mp.mpf('.2')*mp.sign(mp.sin(u))/(u*u)
            return mp.exp(2*w-mp.exp(w)+logell(env,u)-logell(env,v))*(1+e)
        value=mp.quad(fn,points)
        residual=(value-1+(1-mp.euler)*dlogell(env,v))*v*v
        assert abs(residual)<1000
        jumps.append({'v':v0,'discontinuous_E_scaled_remainder':mp.nstr(residual,25)})
    return {'mellin_cases':rows,'growing_and_negative_shift_cases':shifts,
            'wrong_Mellin_sign_controls':wrong,'measurable_error_cases':jumps,
            'scope':'60-digit analytic quadrature controls; not interval-certified universal bounds.'}


def cancellation_controls():
    pairs=[(ENVS[0],ENVS[3]),(ENVS[2],ENVS[5]),(ENVS[4],ENVS[6]),(ENVS[7],ENVS[8])]
    rows=[]
    for A,B in pairs:
        for G in (mp.mpf('1.1'),mp.mpf(2),mp.mpf(7)):
            la=G-1;s=2*G-1;theta=G/s;phi=la/s
            for l0 in (16,64,256,1024,1000000):
                l=mp.mpf(l0);eA=ell(A,l);eB=ell(B,l)
                bA=-mp.log(theta);bB=-mp.log(phi)
                mdA=mp.quad(lambda z:ell(A,l+z),[0,bA])
                mdB=mp.quad(lambda z:ell(B,l+z),[0,bB])
                shifted=theta*ell(A,l+bA)+phi*ell(B,l+bB)
                current=theta*eA+phi*eB
                exact=theta*mdA+phi*mdB+shifted*(mp.log(l+mp.log(s))+mp.euler)-current*(mp.log(l)+mp.euler)
                prediction=-theta*eA*mp.log(theta)-phi*eB*mp.log(phi)
                residual=(exact-prediction)/(eA+eB)
                if l0==1000000:
                    assert abs(residual)<mp.mpf('.001') and exact>0
                rows.append({'source_A':A[0],'source_B':B[0],'G':str(G),'l':l0,
                             'principal_entropy_gap_divided_by_envelope_sum':mp.nstr(exact/(eA+eB),25),
                             'positive_limit_coefficient':mp.nstr(prediction/(eA+eB),25),
                             'normalized_error':mp.nstr(residual,25)})
    # A half-unit physical shift can change the allowed O(log^-2) E
    # much more than O(1/r). Evaluate phases exactly along m+1/4.
    fixed=[];env=ENVS[2];amplitude=mp.mpf('.2')
    for m in (1000,1000000,1000000000000):
        r=mp.mpf(m)+mp.mpf('.25');rp=r-mp.mpf('.5')
        f=lambda z,sign:ell(env,mp.log(z))/(z*z)*(1+sign*amplitude/mp.log(z)**2)
        change=f(rp,-1)/f(r,1)-1
        fixed.append({'r':str(r),'relative_shift_times_log_squared':mp.nstr(change*mp.log(r)**2,25),
                      'relative_shift_times_r':mp.nstr(change*r,25)})
    assert abs(mp.mpf(fixed[-1]['relative_shift_times_log_squared'])+2*amplitude)<mp.mpf('.001')
    return {'unequal_and_nonconvergent_ratio_pair_cases':rows,
            'fixed_shift_rough_error_negative_controls':fixed,
            'oscillating_ratio_analytic_contract':'ell±=x^-2 exp(±(1/4)ln(x)sin(lnln(x))); derivative bound ensures admissibility; their ratio tends to0/infinity along alternating subsequences.'}


def probability_mass(env):
    return mp.quad(lambda x:mp.exp(-x+logell(env,x)),[mp.e,8,24,mp.inf])


def convolution_controls():
    A=ENVS[0];B=ENVS[3];pA=1-probability_mass(A);pB=1-probability_mass(B)
    rows=[]
    for G in (mp.mpf('1.1'),mp.mpf(2),mp.mpf(7)):
        la=G-1
        def f(x,c,env):return c*ell(env,mp.log(x)-mp.log(c))/(x*x)
        for v0 in (8,12,16,24):
            r=mp.exp(v0);z=r-la;middle=mp.log(z/2)
            def left(c,env,other,otherenv):
                low=mp.e+mp.log(c)
                return mp.quad(lambda x:mp.exp(x)*f(mp.exp(x),c,env)*f(z-mp.exp(x),other,otherenv),[low,middle])
            full=pA*f(z,la,B)+pB*f(z,G,A)+left(G,A,la,B)+left(la,B,G,A)
            principal=(G*ell(A,v0-mp.log(G))+la*ell(B,v0-mp.log(la)))/(r*r)
            error=(full/principal-1)*v0*v0
            assert abs(error)<1000
            rows.append({'G':str(G),'ln_r':v0,'log_squared_relative_convolution_error':mp.nstr(error,25),
                         'fixed_added_temperature':str(la)})
    return rows


def g(x):
    x=np.asarray(x)
    return np.log1p(x)+x*np.log1p(1/x)


def panels(lo,hi,order):
    z,w=np.polynomial.legendre.leggauss(order)
    cuts=np.linspace(lo,hi,max(1,math.ceil((hi-lo)/.5))+1)
    x=np.concatenate([(a+b)/2+(b-a)/2*z for a,b in zip(cuts[:-1],cuts[1:])])
    weights=np.concatenate([(b-a)/2*w for a,b in zip(cuts[:-1],cuts[1:])])
    return x,weights


def entropy_function(p):
    ans=np.zeros_like(p);mask=p>0
    ans[mask]=-p[mask]*np.log(p[mask])
    return ans


def actual_quantum_controls():
    qs=np.array([1.05,1.5,2.,4.]);means=1/(qs-1)
    order_rows=[];N=8192;cut=40.;C=math.exp(cut)
    for order in (8,16):
        x,wx=panels(math.e,cut,order);Rtemp=np.exp(x)
        W=wx[:,None]*np.exp(-x[:,None])/(x[:,None]*np.log(x[:,None])**qs[None,:])
        atom=1-W.sum(axis=0)
        assert np.all(atom>0)
        def classical(t):
            yy1,ww1=panels(0.,1.,order*2)
            z,wz=panels(0.,cut,order);yy=np.concatenate([yy1,np.exp(z)]);ww=np.concatenate([ww1,wz*np.exp(z)])
            alpha=t/(t+Rtemp)
            H=np.exp(-yy[:,None]*alpha[None,:])@(alpha[:,None]*W)+np.exp(-yy[:,None])*atom[None,:]
            entropy=np.sum(ww[:,None]*entropy_function(H),axis=0)
            return np.log1p(means/t)+1-entropy
        for T in (4.,16.,64.):
            m=T+Rtemp;logq=-np.log1p(1/m)
            def pn(n):
                n=np.asarray(n)
                return np.exp(n[:,None]*logq[None,:])@(W/(m[:,None]+1))+np.exp(n[:,None]*(-math.log1p(1/T)))/(T+1)*atom[None,:]
            total=np.zeros(len(qs))
            for start in range(0,N+1,1024):
                total+=entropy_function(pn(np.arange(start,min(N+1,start+1024),dtype=float))).sum(axis=0)
            tails=[]
            for threshold in (N,N+1):
                zz,ww=panels(math.log(threshold),cut,order)
                nn=np.exp(zz)
                tails.append(np.sum((ww*nn)[:,None]*entropy_function(pn(nn)),axis=0))
            mfull=T+means;Pmax=(mfull+1)/(C-1)
            analytic_tail=Pmax*(1+np.log((mfull+1)/(Pmax*Pmax)))
            p_temperature=np.exp(-cut)/(cut*np.log(cut)**qs)
            M_temperature=np.log(cut)**(1-qs)/(qs-1)
            h2=-p_temperature*np.log(p_temperature)-(1-p_temperature)*np.log1p(-p_temperature)
            source_entropy_error=p_temperature*(g(T+M_temperature/p_temperature)+g(T))+h2
            Slo=total+tails[1]-source_entropy_error
            Shi=total+tails[0]+analytic_tail+source_entropy_error
            Dlo=g(T+means)-Shi;Dhi=g(T+means)-Slo
            Cnow=classical(T);Cnext=classical(T+1)
            for j,q in enumerate(qs):
                # Floating quadrature, with analytic truncation envelopes;
                # no interval claim about quadrature bias is made.
                assert Dlo[j]<=Dhi[j] and Dlo[j]>=Cnext[j]-1e-9 and Dhi[j]<=Cnow[j]+1e-9
                order_rows.append({'order':order,'T':T,'q':q,'mean_R':means[j],
                    'quantum_D_lower_from_entropy_cutoff':Dlo[j],
                    'quantum_D_upper_from_entropy_cutoff':Dhi[j],
                    'classical_D_t':Cnow[j],'classical_D_t_plus_one':Cnext[j],
                    'analytic_photon_continuous_tail_entropy_upper':analytic_tail[j],
                    'analytic_omitted_temperature_entropy_error':source_entropy_error[j],
                    'photon_cutoff':N,'temperature_log_cutoff':cut})
    refinements=[]
    half=len(order_rows)//2
    for a,b in zip(order_rows[:half],order_rows[half:]):
        refinements.append(max(abs(a[k]-b[k]) for k in ['quantum_D_lower_from_entropy_cutoff','quantum_D_upper_from_entropy_cutoff','classical_D_t','classical_D_t_plus_one']))
    return {'status':'ACTUAL_DIAGONAL_QUANTUM_ENTROPY_WITH_ANALYTIC_CUTOFF_FORMULAS_BUT_FLOAT_QUADRATURE_NOT_INTERVAL_CERTIFIED',
            'rows':order_rows[half:],'max_order_refinement':max(refinements),
            'method':'Actual p_n geometric thermal mixture, finite sum and monotone continuous-n entropy tail; no classical entropy substituted for quantum entropy. Classical quantities separately evaluated for both DPI ends.'}


def main():
    begin=time.time()
    out={'status':'PASS_NEW_COLD_EXACT_IDENTITIES_AND_SEPARATE_NUMERICAL_CONTROLS',
         'provenance':'No producer diagnostic/code/output or W49 narrower review read/imported.',
         'exact':exact_quantum_kernel_controls(),
         'mellin_growing_shift':mellin_and_shifts(),
         'two_source_cancellation':cancellation_controls(),
         'actual_output_convolution':convolution_controls(),
         'actual_quantum_squeeze':actual_quantum_controls(),
         'runtime_seconds':time.time()-begin,
         'source_hashes':{n:hashlib.sha256((TARGET/n).read_bytes()).hexdigest() for n in ['SMOOTH_INTEGRABLE_LOG_ENVELOPE_HEAT_BRIDGE.md','SMOOTH_LOG_ENVELOPE_GROWING_SHIFT_DETAIL.md']},
         'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'scope':'New finite exact/analytic/numerical controls supplement the all-size proof. Numerical integrations are not interval-certified. No physical/unknown-data acquisition, finite useful threshold or general unheated EPnI.'}
    (HERE/'COLD_SMOOTH_ENVELOPE_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'status':out['status'],'exact':out['exact'],
        'mellin_cases':len(out['mellin_growing_shift']['mellin_cases']),
        'shift_cases':len(out['mellin_growing_shift']['growing_and_negative_shift_cases']),
        'cancellation_cases':len(out['two_source_cancellation']['unequal_and_nonconvergent_ratio_pair_cases']),
        'convolution_cases':len(out['actual_output_convolution']),
        'quantum_cases':len(out['actual_quantum_squeeze']['rows']),
        'quantum_refinement':out['actual_quantum_squeeze']['max_order_refinement'],
        'runtime_seconds':out['runtime_seconds']},indent=2))


if __name__=='__main__':main()

