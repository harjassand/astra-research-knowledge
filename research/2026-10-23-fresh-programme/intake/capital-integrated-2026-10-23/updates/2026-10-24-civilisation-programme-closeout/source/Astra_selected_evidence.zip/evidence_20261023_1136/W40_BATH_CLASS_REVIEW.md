# Fresh review of the physical and separable-scalar bath separations

23 October 2026. W40 bounded independent reconstruction, requested by the
root. **PASS for both frozen packets under their respective whole-map
resource classes.** No mathematical gap identified. Internal criticism and
finite diagnostics are not formal/external certification or priority
clearance. Generic support, rank, coloring, Choi, dephasing and swap
mechanisms are prior. Physical validation NONE, mission NOT_ACHIEVED.

Exact sources actually hash-verified and read:

* W68 `PHYSICAL_CLASSICAL_BATH_FRONTIER.md`, SHA256
  `1fe06a3dee5cc0f5096eb0af17594dafc7783cb8bf05efd6681e718810352d1a`.
* W68 `SEPARABLE_SCALAR_BLOCK_BATH_FRONTIER.md`, SHA256
  `7e2bc7b9d4ba15742dcbada53950be9042481e5181172396157682fb6031e385`.

Before opening either text I formed the physical support-count lower and
a weighted rank/support argument for the separable class. W68 then supplied
its checkpoint, after which I read the full proofs. No producer check code
was imported. This is genuinely fresh reconstruction, not an independent
claim of inventing the source results or their generic mechanisms.

## 1. Whole-map resource model

The implemented channels are the declared enlarged F,G: SA->SA, not merely
some different channels with the same recovered system marginal. A single
independent initial bath has dimension e and rank s, undergoes a joint
unitary, and is completely discarded after the call. All measurements,
randomness and reset histories are charged there. Thus Kraus/Choi rank
C_F<=es, mixed e>=sqrt C_F, pure e>=C_F.

There is NO extra K factor in this whole-map rank lower. That factor appears
in the different SA->S marginal-channel lower when the retained A itself
is discarded. Nor is the present bound a limit on one processor register
while arbitrary external entropy streams are omitted. The comparator
implementation may use a quantum bath and coherent control; the word
physical-classical restricts its output algebra, not its engineering toolbox.
This is a strong and fairly matched implementation comparator.

## 2. Physical-product-diagonal lower

At epsilon_star=2/(r+1)<1, any F cell mixing physical P and P-complement
points would give the SAME actual output for two orthogonal ideal target
states. Their triangle inequality would force epsilon>=1. Hence P_L is
exactly F-measurable; the symmetric statement holds for G,Q_L. The earlier
global classical optimum proof gives K>=r+1, without assuming three cells
or one active common component.

An outside-P uniform physical cell T of size t has at most t distinct
system labels in its marginal support. Its distance2/(r+1) from the
uniform L=N-r outside state forces at least L(1-1/(r+1))=r^2(r-1)
support labels. Thus every such t is at least n3=r^2(r-1). Summing t^2
over their total size LK gives n3 LK. Inside P, the analogous support
requirement is ceil(r-r/(r+1))=r, yielding the additional r^2 K.

This reconstructs the exact C3 lower. At any feasible K>=r+1 it gives
liminf C_F/(N^2 r)>=1, and the bath inequalities follow as stated. Both
the event membership and support argument here use the FIXED physical
basis. They have not been transferred to an arbitrary entangled basis.

## 3. Coloring and matching upper

I independently reconstructed the extra-point bijection. For
v=r(r-1)=(r-2)(r+1)+2, the V-residue counts are r-1 on residues0,1
and r-2 elsewhere. At a fixed ancillary residue a, the number of nonzero
colors c with q_(a-c)=r-2 is exactly q_a, so its extra V points can be
assigned bijectively to those colors. No probabilistic selection or
noninteger cell is hidden.

Each color has one base point in every C row and r-1 extra V points,
hence rank L. At ancillary label a, the U, base-V and extra-V counts
are D0, q_(a-c), and r-1-q_(a-c), summing to L/(r+1). Thus every output
cell has exact hot local ancillary marginal. Its system state has error
2(r-1)/L=2/[r(r+1)] to the outside uniform target; the active S cell
has error2/(r+1). The common-projective-measurement diamond argument is
valid with references, and a B input attains the latter error. All cross
effect traces vanish, although Tr_A of a cross operator alone need not.

The active table inside W1 remains independent; all new color cells are
common. Exact global F/G commutation follows. On hot U rows the outside
blocks have equal probability, on V rows one color has the extra point,
and on B the S output remains unchanged. The joint error is still2r/(r+1).

The scalar block ranks are rp once and L on r+1 other blocks. Thus
C_class=(rp)^2+(r+1)L^2. Every rank divides L. The paid hot Weyl flag
h=ceil sqrt(r+2) and controlled L-swap bath realize the WHOLE map with
e=hL, one final trace and no interim reset. Pure minimum is exactly
C_class. C_class/(N^2 r) and e/(N sqrt r) tend to one. No exact finite
bath minimum or inexpensive basis compiler follows.

## 4. The separable scalar-block lower does not use membership

For separable sigma_j=Pi_j/t_j, a finite positive pure-product
decomposition spans its range. Pick product terms with linearly independent
system factors spanning the system marginal support. Applying dual system
functionals proves those product vectors independent, so
rank(sigma_j,S)<=rank(sigma_j)=t_j. This rank property concerns the
PHYSICAL S:A cut, not entanglement breaking against an outside reference.

Since F fixes sigma_j, the full-domain contract gives
||rho_j-E_P rho_j||_1<=epsilon_star. Test the ideal state's probability
outside the support of rho_j. With a_j=Tr(P rho_j), delta=epsilon/2,

    delta >=(1-a_j)-t_j/L,
    t_j>=L(1-a_j-delta).

The dropped rare contribution is nonnegative, and replacing the factor
1-a_j by at most one in the subtracted support term has the correct
direction. Negative right sides cause no problem. Completeness gives
sum t_j=NK and sum t_j a_j=rK. Multiplication by t_j and summation yields
exactly C_F=sum t_j^2>=LK(L-delta N), as in S3. No P_L membership,
physical diagonalization or commutation premise enters this single-map
step.

Every output of such an F is internally separable, and the common output
H(rho) is one such output. The previously independently audited
separable-common-state entropy lower supplies K/r liminf>=1. This is
what supplies the retained-dimension factor; it is not derived from an
inapplicable classical integer-cell theorem. The common physical coloring
upper belongs to this broader class and matches both leading bath ratios.

## 5. Boundary countermodels

The abelian/scalar assumption is essential, even if one strengthens
separability from one common output to EVERY output. W61's independently
frozen common-M_r construction, source e0a0c448..., has on W0

    E0(X)=V0[(I_L/L) tensor rho]V0*.

For positive logical rho this is the sum of product positive terms
|y><y| tensor rho over core C labels and V_k rho V_k* tensor |0><0|
over the extra labels, divided by L. Thus EVERY internal S:A output
on W0 is separable. The active blocks are separable too, so all F/G
outputs are separable. Nevertheless its whole bath is3L=Theta(N),
because the W0 Choi rank is L^2, rather than (rL)^2. It lies outside
the scalar class, and invalidates extending the new N sqrt r lower
to arbitrary separable-output or separable-common-output expectations.

Conversely, the Fourier-flat quantum pair has abelian ranges and is
entanglement breaking against external references, but prepares internally
entangled blocks. It escapes the new separability premise and achieves
whole bath(1+o(1))N. External-reference entanglement breaking therefore
cannot replace internal S:A separability in the resource statement.

There is also an exact-optimum example INSIDE the broader scalar/separable
class with P_L NOT F-measurable. The separate W40
`EXACT_SEPARABLE_NONMEMBERSHIP_EXAMPLE.md` rotates one A label into one V
label by a small product rational system rotation. It fixes the saturated
F active block S, while the other branch has strict error slack, and it
commutes with Q. Both full-domain errors therefore remain EXACTLY
epsilon_star, exact local hot return and all bath dimensions persist,
but P_L fails to commute with a minimal F projection. This validates
the need for the basis-independent rank/support proof.

For clarity on that example's optional joint-error paragraph: use the
PHYSICAL system B versus B-complement decomposition after hot preparation,
not the enlarged S versus S-complement input decomposition. B rows retain
the unchanged S output. On B-complement, the original hot joint channel
has error at most2/(r+1), and conjugation increases this by at most8z,
strictly less than2r/(r+1). Thus its exact hot joint error is also retained.
This distinction avoids incorrectly using a hot-input estimate on arbitrary
conditional SA states after an enlarged measurement.

## 6. Independent diagnostics and remaining gates

`check_bath_separation_review.py` imports no producer code. Its retained
results report33,767 exact integer/rational assertions and20 separate
floating assertions. The actual coloring is constructed through r=25,
including every physical point and extra assignment. It checks ranks,
both cell marginals, the two squared-rank lower formulas, whole bath
divisibility, rationally rotated fixed-state probabilities, and actual
nonmembership/local-return projectors for r=2,3. Recorded replay is
about7.11 seconds. These finite checks do not establish the universal
lower, exact diamond norm, or external validity; the written arguments do.

The source claims are supported within their exact classes. Unrestricted
nonabelian comparators, marginal-only implementations, state acquisition,
finite-bit gate costs, hardware, energy/reset costs, historical priority
and practical usefulness remain distinct gates. No peer source was edited.
