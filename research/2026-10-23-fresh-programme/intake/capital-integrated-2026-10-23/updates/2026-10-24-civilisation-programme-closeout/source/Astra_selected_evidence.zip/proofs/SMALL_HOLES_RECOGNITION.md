# Exact recognition of the fixed-factor small-hole class

23 October 2026. W59 composition, with W14 algebraic criticism. Internal proof
candidate; historical priority, external validation and practical advantage
UNKNOWN. This file records the separate numerical-promise-removal bridge.

## Statement

Fix integer r>=1. For every explicit square Boolean map P on even N=2l>=6
with output locality at most three, a uniform deterministic FP^NP algorithm
returns exactly one of:

* BIJECTIVE, iff H=0;
* SMALL_HOLES, iff 0<H<=(2-2^(-r))*2^(l-1), together with exact H, an explicit
  missing output and an exact finite affine-coset cover of the whole hole set;
* OUTSIDE_CLASS, otherwise.

No numerical deficit or fiber-multiplicity promise is supplied. r remains a
fixed constant of the algorithm. This recognizes one narrow numerical class;
it does not locate holes on general OUTSIDE_CLASS inputs.

## Dependencies and provenance

The large-dimension candidate reconstruction is the fully acquired procedure
in W14's near-minimum proof, frozen mathematical version 2 SHA256
`087fb62f7a0042787f6b93768870045bf6967676d6ca9b91a3d2c6c5fa9bf431`.
Its structural promise-case correctness was independently checked in `REPORT.md`.
Subsequent attribution-only additions do not change that derivation.

W14's odd-support simplicity theorem, frozen SHA256
`87c04219b46e428070ed2ca647f33014516ef01894622d2cb4e434f088a3a1db`, removes
the max-fiber condition when N>4r+8. `ODD_SUPPORT_AUDIT.md` records the fresh
independent audit. The sharper threshold N>4r+4 can be substituted after its
separate addendum; this proof uses the frozen coarser threshold.

The original bounded-factor low-degree/period reconstruction belongs to W14.
The proposed exact cover/Fourier certification and its recognition composition
are recorded here. W51's separately audited dense exact-extremal recognizer
supplies a related exact-recognition mechanism, not the bounded-factor
structural theorem. Classical Fourier uniqueness, affine solving, Gauss sums,
and NP self-reduction receive no novelty claim.

## A general exact cover-verification lemma

Let Q be any explicitly given square quadratic Boolean map on N bits. Define
w(y)=|Q^-1(y)|-1 and suppose candidate sets A_c,B_c are supplied as at most k
internally disjoint parallel affine cosets each. Their directions may differ
between the two sets. Assume k is polynomially bounded and all affine data
are explicit.

For an affine coset b+V, its unnormalized Fourier sum at a is zero unless a
annihilates V; otherwise it equals (-1)^(a.b)*2^dim(V). Thus both candidate
Fourier sums are P-computable exactly. The true defect Fourier sum is also P:

    W(a)=sum_x (-1)^(a.Q(x)) - (2^N if a=0 else 0),

by exact quadratic Gauss elimination. All integers have O(N+log k) bits.

First check A_c and B_c internally and mutually disjoint in P. Two affine
cosets a+V and b+Z intersect iff a+b belongs to V+Z, a GF2 span test. At most
O(k^2) such tests suffice.

Then ask the single NP decision query

    EXISTS a in F2^N:
       Ahat_c(a)-Bhat_c(a) != W(a).                     (C1)

The witness is N bits and its verifier uses only exact P computations on
explicit data. A NO answer establishes equality of every Fourier coefficient;
Fourier invertibility gives w=1_Ac-1_Bc at every output. Disjointness then
implies:

* c(y)=2 on A_c;
* c(y)=0 on B_c;
* c(y)=1 elsewhere.

Therefore the two candidate sets are exactly the double-image and hole sets,
and H=|B_c| is acquired by the explicit coset count. This soundness proof does
not assume any fiber bound or deficit. It actually certifies maxfiber<=2.

The disjointness check is necessary. Adding the same spurious singleton to
both true sets preserves all Fourier differences but changes each indicator
separately. The executable controls retain this falsifier. A separate NP query
for an image in B_c would also eliminate that ambiguity, but explicit coset
intersection tests make that second query unnecessary.

## Producing candidates without assuming their correctness

For the large branch, run W14's acquired-state construction with its fixed-r
degree and rank caps. On arbitrary inputs the reconstructed sets are only
candidates. In particular, interpolating a degree-D collision polynomial is
not itself asserted to recover the true collision set off-promise.

The construction remains uniformly bounded:

1. The exact collision hull is acquired by NP collision witnesses. An empty
   relation proves BIJECTIVE because domain and codomain have equal size.
2. Degree-D feature-span acquisition and interpolation produce an explicit
   Boolean F2 polynomial f_A on that hull. Its actual period space is acquired
   by P coefficient-identity tests inside NP span searches. Reject if period
   codimension exceeds R; otherwise enumerate its <=2^R cosets to define A_c.
3. Compute the auxiliary exact function Btrialhat=Ahat_c-W. Using it, follow
   the bounded candidate hole-hull and spectral-span construction. Off-promise,
   recheck basis amplitudes and phase-equation consistency; abort on failure.
   Use a fixed linear lift from intrinsic to global frequencies, so this
   auxiliary function is completely specified even if it is not a true hole
   transform.
4. Reject if intrinsic spectral rank would exceed R. At the cap, ask only the
   next existence decision; a YES aborts without extracting another witness.
   This keeps the stated query bound valid even off-promise.
5. Invert all <=2^R intrinsic spectral patterns. Every inversion value must
   be exactly 0 or 2^b, with b the candidate hull dimension. Reject otherwise.
   Materialize EVERY positive pattern as an affine coset. Its common
   direction is the kernel of the acquired spectral forms, mapped into the
   ambient coordinates. This defines an actual Boolean candidate B_c,
   rather than merely selecting one proposed hole.

All candidate covers are explicitly internally disjoint by construction and
can be checked again in P. Apply the mutual-disjointness test and (C1). On
success compute H from B_c and accept SMALL_HOLES exactly when the numerical
integer inequality holds. Output any representative of a nonempty B_c coset.
The whole proposed hole set is certified, so a final point preimage query is
not needed.

The original final one-word preimage query is replaced by (C1), which is one
NP decision as well. No extra NP calls are required for this strengthening.

## Full wrapper and completeness

If N<=4r+8, enumerate P on every input, mark images and count unmarked outputs
exactly. Return the appropriate class and a hole if in the specified interval.
This branch does not apply a max-fiber filter. Its size depends only on fixed r.

If N>4r+8, first an NP query may reject any triple equal-image fiber. Every
valid SMALL_HOLES map has maxfiber<=2 by W14's odd-support theorem, so that
rejection is safe. Reject locally unbalanced coordinates: they force
H>=2^(N-3)>=2^l, above this interval. All remaining coordinates are quadratic.

Now run the capped candidate construction. For every map in the stated
interval, the previously audited promise-case theorem guarantees that the
construction obtains the exact A,B, all rank/degree guards pass, all inversion
values are Boolean, the covers are disjoint and (C1) answers NO. Hence every
SMALL_HOLES map is accepted. Every bijection is balanced with no collision and
is returned as BIJECTIVE. All earlier rejections are therefore safe.

Conversely, any accepted large-branch map has its full defect certified by the
cover-verification lemma, and its exact H passes the interval comparison. There
is no false acceptance. These two directions prove exact three-way recognition
on all input maps in the format, without assuming either numerical condition.

## Explicit costs

Use s=r+1, D=2s+1, q=s*2^(s+1), R=q+1, and
M=sum_(j<=min(D,N)) binom(N,j). The full algorithm uses at most

    (2N+1)(M+N+1)+2N(N+1)+(N+1)min(R,N)+7

NP decisions on every large-branch input, including witness bit fixing,
terminal/guard decisions, the max-fiber check and the final global identity
query. At a spectral-rank cap a YES is an immediate rejection, not another
extracted witness. The small branch uses zero NP calls.

Queries have O_r(M^2+2^R*N^2+N log N) bits. The extra cover materialization and
disjointness costs O_r(2^(2R)*poly(N)) outside the oracle and fit inside the
existing conservative bound

    O_r(2^(3R)*(N+1)^6*(M+1)^4).

Add the finite-branch O(2^(4r+8)*(r+1)^2) bit-array work and
O(2^(4r+8)) flag bits. Counts and inversion intermediates require O(N+R) bits.
The fixed-r constants are charged. Implementing the NP decisions by an actual
SAT solver is not claimed polynomial. Growing r is outside this FP^NP result.

## Evidence and remaining status

`check_bounded_recognizer.py` implements the capped candidate reconstruction
and global certificate with an explicitly exponential finite NP backend.
`BOUNDED_RECOGNIZER_RAW_CHECKS.json` checks 148 original two-fiber-class inputs,
including both valid thresholds and off-promise systems. Two direct verifier
controls show that shared overlap can fool the Fourier difference, and that
equal-size disjoint wrong-hole covers are rejected by a global parity witness.
The separate full wrapper diagnostic covers arbitrary fibers on the bounded
finite branch and acquired large-branch examples.

These checks test code and falsifiers. The complete theorem rests on the
audited structural dependencies and the exact verification proof above.
Historical priority, external validation, actual solver speed, generic
near-square range avoidance, P versus NP and mission completion remain UNKNOWN
or unestablished by this scoped result.
