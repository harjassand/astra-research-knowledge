"""Exact charge-parent coordinates and total XOR extensions.

This representation does not factor the actual H into colour/gauge parts.
The acquired filter retains every nonlocal colour permutation in H.
"""
from itertools import product
from math import comb
from pathlib import Path
import json

OUT = Path(__file__).with_name("CHARGE_COORDINATES_EXACT.json")


def unrank_subset(n, q, r):
    assert 0 <= r < comb(n, q)
    selected = []
    for i in range(n):
        if not q:
            break
        zero = comb(n - i - 1, q) if q <= n - i - 1 else 0
        if r < zero:
            continue
        r -= zero
        selected.append(i)
        q -= 1
    assert not q and r == 0
    return selected


def rank_subset(n, selected):
    selected = set(selected)
    q = len(selected)
    r = 0
    for i in range(n):
        if i in selected:
            r += comb(n - i - 1, q) if q <= n - i - 1 else 0
            q -= 1
    assert not q
    return r


def unrank(n, q, r):
    N = comb(n, q) * 2**q
    assert 0 <= r < N
    positions = unrank_subset(n, q, r >> q)
    w = [0] * n
    for c, i in enumerate(positions):
        w[i] = 1 + ((r >> c) & 1)
    return tuple(w)


def rank(n, q, w):
    if len(w) != n or any(x not in [0, 1, 2] for x in w) or sum(x != 0 for x in w) != q:
        return None
    positions = [i for i, x in enumerate(w) if x]
    colours = sum((w[i] - 1) << c for c, i in enumerate(positions))
    return (rank_subset(n, positions) << q) + colours


def pack(w):
    return sum(x << (2 * j) for j, x in enumerate(w))


def unpack(n, w):
    return tuple((w >> (2 * j)) & 3 for j in range(n))


def total_xor(n, q, r, w, reverse=False):
    N = comb(n, q) * 2**q
    def gx(r):
        return pack(unrank(n, q, r)) if r < N else 0
    def rx(w):
        ans = rank(n, q, unpack(n, w))
        return ans if ans is not None else 0
    if reverse:
        r ^= rx(w)
        w ^= gx(r)
    else:
        w ^= gx(r)
        r ^= rx(w)
    return r, w


def main():
    tests = []
    roundtrips = 0
    for n in range(1, 8):
        for q in range(n + 1):
            N = comb(n, q) * 2**q
            seen = set()
            for r in range(N):
                w = unrank(n, q, r)
                assert rank(n, q, w) == r
                assert sum(x != 0 for x in w) == q
                seen.add(w)
                roundtrips += 1
            assert len(seen) == N
            tests.append({"ports": n, "charge": q, "N": N,
                          "pad_dimension": 1 << (N - 1).bit_length(), "rank_roundtrips": N})
    total_cases = []
    total_inputs = 0
    for n, q in [(3, 1), (4, 2)]:
        N = comb(n, q) * 2**q
        D = 1 << (N - 1).bit_length()
        seen = set()
        for r, w in product(range(D), range(4**n)):
            out = total_xor(n, q, r, w)
            assert total_xor(n, q, *out, reverse=True) == (r, w)
            seen.add(out)
            total_inputs += 1
        assert len(seen) == D * 4**n
        for r in range(N):
            assert total_xor(n, q, r, 0) == (0, pack(unrank(n, q, r)))
        for r in range(N, D):
            # Invalid ranks are explicitly outside the partial isometry.
            assert total_xor(n, q, r, 0) == (r, 0)
        total_cases.append({"n": n, "q": q, "all_inputs": D * 4**n,
                            "all_input_permutation_and_inverse": True,
                            "invalid_rank_and_qutrit_patterns_included": True})
    result = {"status": "PASS", "scope": __doc__, "roundtrips": roundtrips,
              "charge_cases": tests, "total_input_cases": total_inputs,
              "total_extensions": total_cases}
    payload = json.dumps(result, indent=2) + "\n"
    if OUT.exists():
        if OUT.read_text() != payload:
            raise RuntimeError("refuse changed frozen output")
    else:
        OUT.write_text(payload)
    print(json.dumps({"status": "PASS", "roundtrips": roundtrips, "total_input_cases": total_inputs}))


if __name__ == "__main__":
    main()
