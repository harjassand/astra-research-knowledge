# Global balanced-beam correlation law

Root original derivation, 23 October 2026, prompted by reconstructing w42's
amplifier correlation law. Internal proof pending fresh review; priority UNKNOWN.
Natural logarithms. This is a mathematical entropy tradeoff, not a new cooling
device or a way to acquire correlations for free.

Let g(x)=(x+1)ln(x+1)-x ln x, g(0)=0. Fix n>=1, v>0. Each of A,B has
n bosonic modes and its marginal is exactly the product thermal state tau_v.
Allow any joint state, including non-Gaussian/intermode entanglement, subject to
I(A:B)<=kappa. Apply the balanced pairwise beam splitter
C=(A+B)/sqrt(2), D=(A-B)/sqrt(2), and retain C.

Put kappa_0=n[2g(v)-g(2v)]. For 0<=kappa<=kappa_0 let q_kappa be the
unique q in [0,v] satisfying

 n[g(q)+g(2v-q)]=2n g(v)-kappa.                         (1)

Then the EXACT minimum over the stated input class is

 inf S(C)=n g(q_kappa) for 0<=kappa<=kappa_0,
 inf S(C)=0 for kappa>=kappa_0.                        (2)

The minimum is attained by separable Gaussian inputs at every budget.

## Proof without a covariance or Gaussian optimizer premise

Total mean photon number is 2nv and is preserved by this beam splitter.
Let x=Tr N_C rho_C/n. Then 0<=x<=2v and E_D/n=2v-x. All entropies
below are finite by the finite-energy bosonic entropy bound. Unitary invariance,
the prescribed marginals and the MI budget give

 S(CD)=S(AB)=2n g(v)-I(A:B)>=2n g(v)-kappa.              (3)

Subadditivity and the maximum entropy at a supplied mean number imply

 S(CD)<=S(C)+S(D)<=n[g(x)+g(2v-x)].                    (4)

The function f(x)=g(x)+g(2v-x) is continuous and strictly increasing on
[0,v], strictly decreasing on [v,2v], with f(0)=g(2v), f(v)=2g(v).
For kappa<=kappa_0, (3)-(4) force q_kappa<=x<=2v-q_kappa.
Again by subadditivity and the maximum-entropy bound,

 S(C)>=S(CD)-S(D)
     >=2n g(v)-kappa-n g(2v-x)
     >=2n g(v)-kappa-n g(2v-q_kappa)
      =n g(q_kappa).                                  (5)

No correlation moment, input Gaussianity, EPnI or channel optimizer theorem
has been assumed. The usual thermal entropy bound follows directly from
D(rho||tau_x)>=0 and its number-affine logarithm, so it applies to an
arbitrary n-mode state at the stated total mean.

For attainment choose the OUTPUT product tau_q^C tensor tau_(2v-q)^D
and apply the inverse balanced beam splitter. The resulting Gaussian input
has both marginals tau_v (the number covariance of each is vI and there
are no anomalous moments), joint entropy n[g(q)+g(2v-q)], hence MI equal
to kappa. Its output C is exactly tau_q. It is separable: product thermal
states have a positive coherent-state Gaussian mixture, and passive linear
optics sends each coherent product to another coherent product. This also
works at q=0. For every larger budget, the q=0 state remains admissible
and gives the entropy-zero lower limit, proving (2).

## A broader exact energy/entropy statement

The lower proof only needs total input mean 2nv and
S(AB)>=2n g(v)-kappa. Equivalently, at that fixed total mean it needs
D(rho_AB||tau_v tensor tau_v)<=kappa. It therefore holds for that larger
reference-budget class as well. Attainment is already in the smaller exact
thermal-marginal class. Arbitrary energy-preserving unitaries have the same
lower bound for an n+n output partition; balanced mixing supplies an
attainer with the desired thermal input marginals. Do not replace this
reference-relative-entropy budget by MI alone for arbitrary nonthermal
marginals.

## Small-budget sensitivity and resource boundary

Write c=v-q. The budget of the attaining family is

 K(c)=n[2g(v)-g(v-c)-g(v+c)]
     =n c^2/[v(v+1)]+O(c^4).

Consequently c=sqrt[v(v+1)kappa/n]+O(kappa^(3/2)), and

 inf S(C)=n g(v)-sqrt[n v(v+1)] ln(1+1/v) sqrt(kappa)+O(kappa).

Thus a linear-in-I correction cannot be uniformly valid near independent
thermal inputs. This phenomenon is consistent with w42's independently
derived local amplifier law; here total-energy conservation gives a global
all-budget formula through elementary entropy allocation.

Correlations are a supplied resource. Their preparation, MI certification,
mode/phase matching, thermal-marginal calibration, loss and discarded-output
cost have not been acquired. Retained entropy is not automatically useful
entanglement or net work. At q=0, one output is vacuum and the other carries
the entire supplied entropy and energy; there is no free cyclic reset.

## Primary context and priority status

The conditional bosonic EPI of De Palma and Trevisan (2017),
https://arxiv.org/abs/1706.00440, concerns conditionally independent inputs,
and is an established entropy-inequality comparator. The present class allows
correlations and uses a different explicitly supplied budget.

Bruschi et al., Thermodynamics of creating correlations: Limitations and
optimal protocols, Phys. Rev. E 91,032118 (2015),
https://doi.org/10.1103/PhysRevE.91.032118, already studies thermodynamic
correlation costs and bosonic modes. A focused search does not establish
priority for this exact formula. The Gaussian realization and maximum-entropy
principle are established tools. Historical novelty stays UNKNOWN.
