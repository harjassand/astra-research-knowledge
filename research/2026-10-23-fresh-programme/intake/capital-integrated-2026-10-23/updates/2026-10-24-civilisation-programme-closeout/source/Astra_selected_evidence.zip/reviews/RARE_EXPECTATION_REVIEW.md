# Independent audit of the rare-outcome obstruction

Worker w61. No peer criticism or verdict was read before the conclusions below
were formed. The supplied target is the frozen `SUPPLIED_PROOF_SNAPSHOT.md`,
Section E, SHA256
`ebb4c2854dc3dff37b5ee72b9a990a61eadacdcc46098e00970714ef30b4d1e2`.

## 1. Exact contract

For every integer r >= 2, put N = r^3 and tau = Tr/N on M_N(C). Let P,Q be
diagonal rank-r projections whose supports intersect in one coordinate.
The input algebras are A = span_C{I,P} and B = span_C{I,Q}. The maps are the
unique tau-preserving conditional expectations onto these algebras:

    E_P(X) = Tr(PX)/r * P + Tr((I-P)X)/(N-r) * (I-P).

These maps kill off-diagonal matrix entries and average the two diagonal
blocks. They are not the pinching maps X -> PXP+(I-P)X(I-P).

All repair maps act on the same M_N. Each is required to be the tracial
conditional expectation onto an arbitrary unital C*-subalgebra. The repair
distance is the induced operator norm on maps M_N -> M_N; the cb norm is
its matrix amplification. Algebra distance below means the maximum of the
two relative, one-sided near-inclusion gaps. No promise of factor input
algebras, bounded index, balanced weights, or a new ambient space is made.

## 2. Reconstructed commutator, with an exact cb norm

Write

    p = r/N = 1/r^2,
    D_P = P-pI, D_Q = Q-pI,
    s = p(1-p), q = 1/N,
    c = tau(D_P D_Q)/s = (q-p^2)/s = 1/(r+1).

Direct expansion gives

    E_P(X) = tau(X)I + tau(D_P X)D_P/s,
    [E_P,E_Q](X) = c/s * [tau(D_Q X)D_P - tau(D_P X)D_Q].

The scalar functional tau(D_P ·) has cb norm tau|D_P| = 2s, and similarly
for Q. Therefore the supplied upper bound 4c(1-p) < 4/(r+1) is valid.
No conversion from Hilbert-Schmidt norm to operator norm is used here.

There is a modest sharpening: the stated exact ordinary norm is also the
exact cb norm. The output is diagonal, so write the map as

    K(X) = diag_j phi_j(X),
    phi_j(X) = c/s * tau(H_j X),
    H_j = (P_j-p)D_Q - (Q_j-p)D_P.

At every amplification the output is block diagonal. Each block has norm
at most ||phi_j||_cb ||X||, and scalar functionals satisfy
||phi_j||_cb = ||phi_j|| = c/s * tau|H_j|. The scalar diagonal sign matrix
sign(H_j) attains this bound at level one. Thus

    ||K||_cb = ||K|| = max_j c/s * tau|H_j|.

For joint-coordinate types ++,+-,-+,--, with respective multiplicities
1,r-1,r-1,N-2r+1, the row norms are

    ++: 2c(r-1)/r,
    +- and -+: 2c(1-2p+q)/(1-p),
    --: 2cp(r-1)/(r(1-p)).

The exclusive-coordinate rows maximize the norm. Hence, exactly,

    eta_r := ||[E_P,E_Q]||_cb = ||[E_P,E_Q]||
           = 2c(1-2p+q)/(1-p)
           = 2(r^2+r-1)/(r(r+1)^2) -> 0.

## 3. Audit of arbitrary repaired expectations

Let F,G be eligible repair maps with FG=GF, and define

    epsilon = max(||F-E_P||, ||G-E_Q||).

If epsilon >= 1/4, the desired lower bound is immediate. Assume epsilon<1/4.

**Range dimension.** If idempotents T,U on any finite-dimensional normed
space obey ||T-U||<1, then U|range(T) is injective: Ux=0 and Tx=x would imply
||x|| <= ||T-U|| ||x||. Interchanging T,U gives equality of ranks. Applying
this on the normed vector space M_N gives dim range(F)=dim range(G)=2.
This excludes every possible larger nonabelian repaired range at the relevant
small distance. It does not assume the repairs are diagonal.

**Binary form.** A two-dimensional unital complex C*-algebra is C direct-sum C.
Consequently range(F)=span{I,R}, range(G)=span{I,S} for nontrivial orthogonal
projections R,S. Traciality makes F,G the Hilbert-Schmidt orthogonal
projections onto these ranges.

**Spectral orientation and physical ranks.** The self-adjoint matrix
H=F(P)=aR+b(I-R) satisfies ||H-P||<=epsilon, with a,b in [0,1].
Its spectrum is within epsilon of {0,1}, and each eigenvalue 0,1 of P is
within epsilon of its spectrum. Because epsilon<1/2, the two values a,b
occupy different spectral clusters. Orient R so a is near 1 and b is near 0.
Then ||H-R||<=epsilon, and

    ||R-P||<=2epsilon<1/2.

The same argument gives ||S-Q||<=2epsilon. Two orthogonal projections at
operator-norm distance <1 have the same rank, so rank(R)=rank(S)=r.
The use of spectral perturbation is valid for these self-adjoint matrices;
it does not make a claim about nonnormal spectral stability.

**Dichotomy under exact commutation.** Subtract the common scalar projection
E_0(X)=tau(X)I. The maps F-E_0 and G-E_0 are rank-one orthogonal projections
on the Hilbert space of traceless matrices. Commuting rank-one orthogonal
projections have equal or orthogonal ranges. In the equal case the two
algebras coincide. A binary algebra has only two nontrivial projections,
R and I-R. Since r<N/2 and rank(S)=r, equality of the algebras forces S=R.
This contradicts

    1=||P-Q|| <= ||P-R||+||S-Q|| <= 4epsilon<1.

The centered lines are therefore orthogonal. This is exactly

    Tr(RS) = Tr(R)Tr(S)/N = r^2/N = 1/r.

**Retained common vector.** Let u be the original common basis vector.
Because Pu=Qu=u,

    ||RSu-u|| <= ||R(Su-u)||+||Ru-u|| <=4epsilon.

No commutation of R and S is needed. Cyclicity of trace gives

    Tr(RS) = Tr((RS)^*RS) = ||RS||_F^2
           >= ||RSu||^2 >= (1-4epsilon)^2.

Here ||·||_F is the unnormalized Frobenius norm. Combining the last two
identities and using 1-4epsilon>0 proves

    max(||F-E_P||,||G-E_Q||) >= (1-1/sqrt(r))/4.

Every step is valid for arbitrary eligible repaired algebras. The bound is
a valid lower bound, not an asserted sharp minimax value. Since ordinary
map norm is at most cb norm, the same lower bound holds for cb repair distance.

## 4. Direct extension to nearby algebras

This independent extension removes reliance on a map-distance interpretation
of the word "nearby". Suppose A' is two-sided delta-near A and B' is
two-sided delta-near B, and their tracial expectations commute exactly.
If delta>=1/4 the desired lower bound is immediate, so assume delta<1/4.

For x in A', choose a in A with ||x-a||<=delta||x||. Contractivity of E_P gives

    ||x-E_P x|| <= ||x-a||+||E_P(a-x)|| <=2delta||x||.

Hence E_P restricted to A' is injective, proving dim(A')<=2. Dimension one
would mean A'=CI. The reverse near-inclusion would require
dist(P,CI)<=delta, whereas dist(P,CI)=1/2. Thus dim(A')=2.
Write A'=span{I,R}. The inclusion A near A' supplies H in A' satisfying
||P-H||<=delta. Replace H by its self-adjoint part without increasing the
error. Its two scalar spectral values cluster within delta of 0 and 1,
so an orientation of R satisfies ||R-P||<=2delta. Repeat for S and B'.

Now the rank, centered-line dichotomy, and common-vector arguments in Section 3
apply unchanged, with delta in place of epsilon. Therefore

    max(gap(A,A'),gap(B,B')) >= (1-1/sqrt(r))/4,

where gap is the maximum of the two relative near-inclusion gaps.
The proof uses only elementary contraction and spectral arguments. It does
not depend on a dimension-dependent conversion between algebra and map norms.

## 5. Surviving intersection and failed attempted repairs

The robust-intersection conclusion is consistent with this family. Directly,

    ||E_P E_Q-E_0||_cb = 2c(1-p) < eta_r.

Thus the scalar algebra is already an exact, stable intersection proxy even
while a simultaneous repair of the two whole algebras is bounded away from zero.

Attempts to evade the obstruction fail for the following exact reasons:

- Choosing a larger repaired algebra fails the idempotent rank test at distance <1.
- Replacing one rank-r generator by a different-rank projection fails the
  spectral orientation and rank-stability test at distance <1/4.
- Making the repaired algebras identical forces a projection displacement whose
  two-sided triangle bound is at least 1.
- Merely observing that P,Q commute does not make their block-averaging
  expectations commute; the expectations encode dependence of the two events.
- Rotating to noncommuting R,S is allowed throughout the lower-bound proof.

Changing the input class to factors, imposing a nonvanishing trace-weight
promise, requiring bounded index, changing the norm to a weaker averaged
metric, or enlarging the ambient algebra changes this contract. Those cases
are not refuted here. In particular, the ambient M_N being a factor does
not make the two binary input subalgebras factors.

## 6. Audit status and decisive falsifiers

The supplied theorem passes this independent internal proof audit. No correction
is necessary for its stated scope. The exact cb norm and algebra-gap extension
above are additional proved deductions. Historical priority and external
validation remain UNKNOWN. A statement that every unrestricted dimension-uniform
repair modulus tends to zero is refuted. A fixed-N compactness statement is
not refuted.

An eligible exactly commuting pair at distance below the displayed bound would
be decisive contrary evidence. To localize any such contradiction, check:
range dimension; spectral orientation and physical ranks; exact centered-line
commutation; and the unnormalized overlap identity. Finite diagnostics do not
quantify over repaired algebras. The proof above supplies that quantifier.
