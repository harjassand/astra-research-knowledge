# Joint polynomial code construction with quartic positive excess

23 October2026. Internal theorem and resource composition. This is a
randomized code-construction algorithm in the known mathematical device
model. No useful numerical performance, deterministic good-seed test,
physical implementation, historical novelty or mission completion follows.

## 1. The change in parameter regime

The earlier full circuit composition uses k=Theta(beta^-2) to retain a
Theta(beta^2) source gain. Its particular multiplicity encoder then has
exponential onset in1/beta^2. This does NOT rule out joint polynomial
onset for a smaller positive excess. Fixing k=2 makes the source dimension9
independent of beta. The following gives an explicit positive quartic gain.

For every0<beta<=1/32, b=beta^2, a=1-b, use the direct rational pair source
in `RATIONAL_PAIR_SOURCE.md`, SHA256
0f84dc0c5400fef0c80d25a563eb6ce42bd48da2ccf06ae0d3f54de92a4de324.
It has a direct known9D eigenbasis factory and the complete interface

    k=2, S_2(rho)>=3+g0, g0=b^2/384,
    bulk D_b(rho)=-kappa I, kappa=ab^2/240>0,
    Xi=b^2/288+b^4/7200,
    VarQ=1/2-b^4/14400.                             (F1)

These follow from an explicit positive density, scalar entropy inequalities
and a complete36-by-36 all-b polynomial response identity. No general-H
short-access, rectangular block-encoding or normalized-square factory is
needed. W67 independently reconstructed the exact physical path expansion
and scalar source algebra without importing this worker's code.

The original Cycle10 proof also permits every k>=2 in its window
k>=2,b<=1/1024,bk<=1/256 (lines473--600); its floor appears only later
to extract quadratic gain. Thus even the unchanged original k=2 source
would suffice with a smaller quartic coefficient. The rational source(F1)
removes that inner proof/factory dependence for the present construction.

## 2. Actual encoder and decoder, not source preparation alone

Use the generic Schur/subsystem and high-design proofs as independently
reconstructed in `REVIEW_W39_HIGH_DESIGN.md`. Those proofs use only a
positive source, a paid factory, entropy certificate, charge commutation
and the full recurrent source tail. None uses the original square-source
formula after those hypotheses are supplied. They therefore apply to(F1).

Explicitly, for m outer source copies set

    R=3+g0/2, Delta=g0/4, ell=floor(mR), D=2^ell.

For partitions lambda of m with at most9 rows, the Schur decomposition of
rho^m is p_lambda rho_lambda^Q tensor I_M/f_lambda. Keep all lambda with
f_lambda>=D, then split a tableau rank asz+D u. A paid preparation of the
resulting mixed gauge, followed by this known full-domain subsystem isometry
V, is a CPTP arbitrary-message encoder E with

    E(I_D/D)<=4rho^m,                                (F2)

once the explicit source-acceptance conditions hold. Both V and its inverse
are efficient circuits; no unknown eigenbasis or good-vector search is
inserted. The known9D source factory makes every required local copy.

On ell logical qubits choose the finite high-design subcode T of
`HIGH_DESIGN_OVERFLOW.md`, SHA256
91b8bb963c3880b7b5adc4feb7c1fd26fb15d020b0d10296c28d98b7574a3fe1,
with the explicit bounded-bit compiler in `FINITE_HAAR_COMPILER.md`, SHA256
5d66273de64ce44b28aec08675a4320e39872705bb5d599c56d68ee64fb9c8c0.
Choose eta=(m+1)^(-2), s=12+ceil[2log_2(m+1)], q=2^-s and h=ell+
ceil(log_2(1/eta))+4. Check every finite guard. The circuit loses s logical
qubits, and with construction probability>=1-eta gives COMPLETE logical
overflow<=512q in EACH conserved seed sector. It averages only the FIXED
paid mixed gauge; it need not hold for every arbitrary gauge vector.

Perform exactly the prefix/probe/body/retained-zero-flush protocol in
`RANDOMIZED_CODE_COMPOSITION.md`, SHA256
3816a9a27f990f9e7d19c22418699c60a46b3cd97b6e17b9e11f76e1f178d4d5,
substituting(F1). Every forward call and emitted port counts. The receiver
learns the conserved sector, locally digitally inverts the known body+flush
unitary on received ports and a locally prepared word vacuum, then applies
V* and T*. The actual physical bath is never accessed, reset or reversed.
The source-gauge purifier remains at the sender. Its known full-domain
inverse returns logicaldata tensor the original gauge purification.

The decoder and the mixed-gauge extension have separate positive w17
reconstructions. Its frozen integration receipt for the generic composition
is `RANDOMIZED_CODE_INTEGRATION_AUDIT.md`, SHA256
a2fd6742b756398b63d22c8d983ef961c40e08ba63fbc6b3938488458b21e475.
This does not imply that w17 audited the new rational source in this pass.

## 3. Explicit finite guarantee

Let S be ALL initial-zero, probe/interprobe-zero and terminal-zero calls,
and N_total=2m+S. Set A=floor log_2(m+1), delta=(m+1)^(-1), nu=(m+1)^(-2).
Prepare/compile each of the aggregate encoder and decoder channels within
full diamond error delta. For a successful compiled seed, the resulting
logical channel has full diamond error at most

    min{2,4sqrt(513q)+4delta+4sqrt(q_A+nu)},          (F3)

where q_A is the actual fixed normal initializer's depth tail. The code
is independent of that initializer. At tau_pi, q_A=3^(-(A+1)); for every
fixed normal tau the error vanishes pointwise. All arbitrary logical
references are retained. No uniform finite tail modulus for all normal
baths or return of their original purifiers is asserted.

The finite rate is at least

    3/2+g0/8 =3/2+beta^4/3072                       (F4)

whenever

    mg0/4 >=1+s+(3/2+g0/8)S.                       (F5)

This is exactly the logical floor/sublabel loss and paid-port rate inequality;
state preparation alone does not prove it. Source acceptance, high-design
finite guards, word cutoff, prefix/probe/flush and(F5) are all checked at
the chosen finite m in the accompanying scalar contracts.

## 4. Joint polynomial onset: proof of the scaling

All constants below are uniform for0<b<=1/1024. The source dimension d=9
is FIXED and g0=Theta(b^2), kappa=Theta(b^2). The source acceptance bound is

    m>=4B_9/(g0/4)^2 =O(b^-4),
    m(g0/4)-45log_2(m+1)>=2,

with constant B_9. The first requirement dominates the second eventually.

The actual second-moment bound V isO(1); alternatively use the elementary
bound V<=k^2=4 for a purely rational certificate. Choose
t=kappa/(3k^2)=Theta(b^2), valid since e<3. The retained root coefficient
satisfies C_tail<=18/(kappa t)=O(b^-4). Hence the required source-mean
overflow cutoff obeys

    H=O(b^-2[log(m+1)+log(1/b)]).

The terminal flush costsO(H+log m); the initial normal-word prefix costs
O(log m). Seed probes cost n=O(b^-1 log m) calls, with
j=O[(log m+log(1/b))/log(1/b)] zeros after each. At

    m=C b^-4 log(2/b)                               (F6)

and fixed large enough absolute C, log m=O(log1/b) and j=O(1). Thus

    S=O(b^-2 log(2/b)),
    mg0=Theta(C b^-2 log(2/b)),

so(F5) holds once C is sufficiently large. All source/design finite guards
also hold. Therefore, for any fixed target error at tau_pi, sufficiently
large C gives a fully counted horizon

    N_total=O(b^-4 log(2/b))
           =O(beta^-8 log(2/beta)).                  (F7)

The q_A contribution in(F3) isO(m^(-log_2(3)/2)); the other terms areO(m^-1).
In particular the loose bound16/sqrt(m) suffices for m>=2. Arbitrary finite
error epsilon may be obtained, for example, with a conservative polynomial
choice m=O[b^-4 log^2(2/(b epsilon))+epsilon^-2], enlarging the absolute
constant. This deliberately loose bound absorbs the probe logarithms too.
For an arbitrary fixed normal initializer only its pointwise tail statement
is available; a polynomial finite-error modulus cannot be inferred without
a supplied tail bound.

## 5. Gates, random bits and accuracy are charged

Here ell,h=Theta(m), log2(1/delta_des)=O(m^2). The explicit ideal BHH
Haar-local length isO(m^13 polylog m); bounded-bit local sampling needs
O(m^2) bits per scalar to attain that moment accuracy. Its total offline
seed length is polynomial, conservativelyO(m^15 polylog m), and belongs
to the preprogrammed encoder/decoder description. It is not sent through
an uncounted runtime wire.

Fixed-dimensional Solovay--Kitaev synthesis adds a polynomial factor in
those O(m^2) accuracy bits. The design component can conservatively be
bounded byO(m^21 polylog m) elementary gates with the standard logarithmic
synthesis exponent rounded up to4; exact constants are not instantiated.
The source copies, Schur/rank arithmetic, interval preparation, inverses
and local digital word-stack circuit are also polynomial. Thus the WHOLE
randomized compiler and code have cost polynomial in1/beta, the eventual
block length, L_b and the charged precision bits in this fixed-k regime.
The exponent and constants make this a complexity result, not a useful
runtime estimate. No actual circuit of those sizes has been generated.

An actual physical model-angle error nu_angle adds at most2N_total nu_angle.
For a mathematical error allocation epsilon, request
nu_angle<=epsilon/(2N_total). Control noise, calibration, fault tolerance,
equipment, energy, disposal and time have not been acquired or validated.

## 6. Matched finite arithmetic and honest remaining limits

`fixed_pair_pipeline_costs.py`/`FIXED_PAIR_PIPELINE_COSTS.json` evaluate18
full contracts at beta1/32,1/64,1/128,1/256,1/512,1/2048 for original
fixed k2,k4 and the rational pair. Integer m,A,H and all padding decisions
are stable at80 versus110digits; this is NOT interval certification.

For the rational pair at beta1/512, the sufficient chosen m is2^103,
body2^104=20282409603651670423947251286016 forward calls, with an EXTRA
38813632023018840 charged padding calls. The finite rate excess is
4.736951571734e-15 per call, the tau_pi full-diamond bound about6.19e-25,
and the conservative ideal BHH local-gate bound about10^418.889 BEFORE
finite-basis synthesis. Required design-accuracy length is about10^62.966
bits. These are symbolic/large-number arithmetic calculations, not executed
circuits, measurements, optimized resources or practical performance.

This closes an internal mathematical RANDOMIZED joint-polynomial route
for strict positive QUARTIC excess, on the reviewed generic Schur/design
and local decoder circuit premises. It does not attain the separately
proved Theta(beta^2) unrestricted gain with joint polynomial cost. There
is no efficient deterministic good-seed certification, no external proof
review, no practical advantage and no physical validation. Historical
novelty remains UNKNOWN; the overall discovery mission NOT_ACHIEVED.
