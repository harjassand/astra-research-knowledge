# Rational V2 source in the fixed-gain universal code

23 October 2026. Separate post-freeze integration candidate. OLD-source
physical/count comparisons and all reviews remain unchanged. This is not a
new generic source, coding, design or recovery theorem. It composes the
already separately source-audited V2 pair with the reviewed universal
type/Fourier/polar and bounded-sign compiler interfaces, with fresh guards.

## 1. Inputs and exact source substitution

The V2 source premise is W66's RATIONAL_PAIR_TRADEOFF_V2.md, SHA256
eeb8a255afc35ba8261cbfcf59efbe1d0245499abe36340cde517140a217f85e.
Our source-only review d059f1463ce020376a4cef9fc561cfdc5af924f29fe795818b1c325d1412d383
checks positivity, entropy and the scalar bulk drift; it does not itself
review a complete code or native cost integration.

Let one fixed unknown b lie in the supplied public band
0<b0<=b<=b1<=1/1024, and a1=1-b1. On the same nine-dimensional pair basis,
take x=b0/6 and u=b0^2/32. With sigma=diag(1/2,1/4,1/4)^(tensor2),
A=Q-I and the same pair hopping H, set

    rho0=sigma(I+uA-2xH).

Its known spectrum is (1-u)/4 once, (1+u)/16 four times,
(1-x)/8 twice and (1+x)/8 twice. These nine rational probabilities
sum to one and belong to[1/16,1/4] throughout the present source range.
The fixed eigenvectors and exact physical port basis are unchanged.
The actual source charge is E_rho0 Q=1+u/2, not the old diagonal reference
mean1. Its variance is1/2-u^2/4. The selected type has the exactly known
integer total charge2 sum_(i=1..4)n_i+sum_(i=5..8)n_i; no fixed-charge
or gauge assumption is inferred from the reference alone.
The separately proved entropy floor is

    S(rho0)>=3+g0,  g0=b0^2/179.                  (V1)

The exact old pair-response algebra is affine in x,u for ANY actual b:

    D_b rho0=(1-b)(u-xb/4)I.

For b>=b0,

    u-xb/4<=b0^2/32-b0^2/24=-b0^2/96.

Hence the uniform drift premise is

    D_b rho0<=-kappa I,
    kappa=a1*b0^2/96.                            (V2)

This is a fixed source chosen at b0, not reoptimized at unknown b.
It needs no actual-gain or static-sector query. The source still
commutes with total pair charge, so the earlier generic bounded-charge
Lyapunov proof applies with the same conservative constants
t=kappa/12 and C=18/(kappa*t).

In detail, every two-call displacement lies in[-2,2], so its positive
second-moment effect is at most4I. For2t<=1, Taylor with e<3 bounds the
bulk exponential effect by1-kappa*t+6t^2=1-kappa*t/2=:lambda. Initial
depth below2 reaches at most3 in the block, and charge commutation
eliminates cross-depth blocks. Thus the ACTUAL root-retaining dual
channel obeys

    Phi* exp(tL)<=lambda exp(tL)+exp(4t)P_(L<2).

The low-depth term is retained. Since exp(4t)<9 under these guards,
its iterated constant is2exp(4t)/(kappa*t)<18/(kappa*t). Starting at
vacuum gives(1+C)exp(-tH) for the body-tail comparison. No iid bath
or diagonal radial closure is used. The guards2t<=1 and0<lambda<1
hold directly at every stated V2 source parameter.

## 2. Pure type and universal receiver interfaces

Round the first eight m*probability counts down and use the last remainder.
The same nine-label type proof applies because its only spectral bounds
were[1/16,1/4]. The actual type rank f must be computed by a real
constructor; choose D as its largest dyadic dimension. The same total
rank/unrank circuit and fixed exact basis give

    ell>=m(3+g0)-9log2(m+1)-18,
    C(I_D/D)C*<=4(m+1)^9 rho0^(tensor m).          (V3)

The constants and circuit size bounds do not depend on the replaced
rational x,u values. Every image still has a definite total charge.
There is no source-copy preparation, mixed gauge or eigenbasis oracle.

Use the actual physical initial prefix,2m body calls and terminal zero
flush. Replace only kappa/g0 in the Lyapunov, depth and finite rate guards.
The full vacuum-word Laurent degree remains T=2m+l, and the same2(2T+1)
Fourier errors, coefficient norm, common centered-KL event, bad-word
bound u_bad<=2q+R omega, full-TP cutoff and digital row access apply.
Those arguments require the parent average drift/tail and dimension,
not the old numerical source coefficients. The normal-initializer
requirement remains pointwise, and all output ports are retained.

## 3. New finite/native budget, requiring separate review

The companion independent integer/Fraction script instantiates public
bands[b0,2b0], b0=beta0^2, and target z=1/1000. It reacquires m=2^J
from the complete source/design/initial/body/flush/rate/error guards.
It does not import producer code or inherit a source-changed count row.
Target full rate is

    3/2+g0/4=3/2+beta0^4/716.                     (V4)

Every retained finite dimension/moment guard is checked using lower and
upper parent width bounds; no huge full type rank is claimed acquired.
The actual constructor uses its true largest dyadic type slice as before.
Moment order is2h, the finite Pauli ideal seed and its operational
precision separation are paid, the common encoder is used Q+1 times,
and Q is the explicit bounded-sign/Haah query envelope. All native
controlled phases, exact type, digital helpers, phase preprocessing and
output-emission costs retain their reviewed interfaces and symbolic
compiler constants. These are not free source-specific oracle calls.

The joint-polynomial onset O(beta0^-8 log(2/beta0)) is unchanged; only
its sufficient constants and quartic rate floor improve. All generic
ingredients are prior and an equally informed ordinary comparator may
use them. The OLD-source table remains the appropriate matched table
when measuring only a compiler change. This candidate is instead a
separate source-plus-code substitution and must be reviewed as such.

No huge type rank, successful seed, coefficient/phase array, native full
code or apparatus run is generated. Exact known coherent interaction
family, supplied band, static sectors and input/bath independence remain
assumptions. Physical calibration, noisy architecture, energy, practical
usefulness and composition priority are unestablished.

Status: CONDITIONAL_INTEGRATION_AWAITING_FRESH_REVIEW. Priority UNKNOWN;
practical advantage NOT_ESTABLISHED; physical validation NOT_PERFORMED;
mission NOT_ACHIEVED.
