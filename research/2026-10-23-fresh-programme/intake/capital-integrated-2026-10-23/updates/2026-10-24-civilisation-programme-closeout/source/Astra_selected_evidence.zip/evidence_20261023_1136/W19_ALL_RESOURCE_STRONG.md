# Beta0 strong converse for arbitrary normal initial bath/laboratory resources

23 October 2026, w19. Complete development of the independently frozen seed
SECTOR_COUNTER_SEED.md SHA256
d29859360d62c5c72e78563076a1b964334e939a83e3b7e0b3ffc624d555d683.
This extension POSTDATES the prior FROZEN_PACKET_V1, whose weak-converse
status is historical and has not been silently edited. The seed was sent to
root and w49 before their reconstruction. Root reported parallel convergence
by w36 through a distinct weighted-teleportation route; that source has not
been read before this full proof was frozen. Historical priority is UNKNOWN.
This is an internal mathematical proof requiring full-source fresh criticism,
not formal/external validation, physical acquisition or a code.

## 1. Exact quantifiers and theorem

Use the unchanged physical-root-corrected recurrent tree device at beta0:

    U=[[R,S1,S2],[S1*,0,0],[S2*,0,0]].

S_j prepends one color to a word; R flips the two root seeds and vanishes
elsewhere. The same bath E evolves through all N calls, without reset or
direct bath operation. The qutrit charge is q=diag(0,1,1).

For EVERY positive integer N allow ANY normal initial resource eta_N on E,
all Alice/Bob laboratories and inaccessible systems. Its coherence, word
support, depth, entropy, initial E:labs entanglement and Alice:Bob preshares
are unrestricted; the resource may depend on N. The fresh K-dimensional
logical Bell pair begins independently of the ENTIRE resource:

    Phi_(R_log M) tensor eta_N.

There are exactly N prescribed chronological qutrit calls. Arbitrary local
normal TP operations and Bob-to-Alice quantum/classical communication are
allowed. The prescribed calls are the only forward path. There is no
additional forward wire or timing/selection carrier, direct bath access,
source/logical correlation, or postselected normalization. The decoder is
TP into a fixed-K logical output and counts all failure branches. F denotes
its unconditional Bell overlap.

Define

    D_q(N)=binom(N,q)2^q, 0<=q<=N,
    M_N=(N+1)(N+2)/2.

The result proved below is

    F<=min{1, [M_N/K^2] sum_(q+o<=N)min{D_q(N)^2,D_o(N)^2}}
      <=min{1,M_N^2 8^N/K^2}.                         (T1)

This is uniform over every normal N-dependent initial resource described
above, including arbitrary initial bath:whole-laboratory ENTANGLEMENT.
Therefore log2K_N/N>=3/2+delta implies

    F_N<=M_N^2 2^(-2delta N)->0.

For K_N=3^N, F_N<=min{1,M_N^2(8/9)^N}->0. Thus the beta0 reliable-rate
ceiling3/2 is an exponential strong converse up to a polynomial prefactor
for the full initial-resource class. No achievability is asserted here.

## 2. Positive finite-port linking does not require a normalized difference

Fix a complete legal chronological strategy, initial resource and fresh
Bell input. Purify the normal resource and all local TP channels, keeping
their environments. The forward wire ports across one fixed communication
cut are finite-dimensional. All other systems may be normal infinite systems.

Let |A>> be the finite-port vectorization of a rank-one Choi amplitude
inserted at these N wire slots. Its final purified network amplitude is a
LINEAR function L|A>>: expand in the fixed input/output port basis and
contract the remaining bounded strategy operators and initial vector.
The domain of L is finite-dimensional, and each basis coefficient has a
finite Hilbert norm, so L is bounded even when its output Hilbert space is
infinite-dimensional. For J=sum_j|A_j>><<A_j|, the linked purified output
is L J L*. Partial trace of retained environments is positive and normal.
An additional local instrument selection can be included in the same fixed
linear strategy map. Hence

    J1<=c J2  ==> linked_output(J1)<=c linked_output(J2). (T2)

Equivalently, the fixed final Bell test defines a positive finite-port
tester, so its probability is monotone under Choi positive order. Neither
J1 nor cJ2-J1 must be a normalized deterministic comb for(T2). This does
NOT claim that every positive difference is a physically normalized process.
It only uses positivity of the finite-port network contraction. Normalized
causal processes will still be required for the no-signalling comparators.

The free backward channels, arbitrary initial cross-cut entanglement,
local memories and retained measurement environments are parts of this fixed
strategy. They are not part of the independent identity-wire process being
compared. Thus initial bath/laboratory correlations do not invalidate(T2).

## 3. The aggregate-charge identity-wire instrument

Consider N chronological identity qutrit wires, temporarily replacing the
forward interfaces across a fixed cut. Add a finite counter initially0.
On passage of each port basis state i, coherently add0 for i0 and1 for
i1,2 to the counter; dimension N+1 suffices (one may implement modular
addition since no physical path overflows). Do not read or feed this counter
into any control. At the END select its value q.

This is a physical CP process-instrument element with memory. Testing each
wire input with an unnormalized Bell vector gives its Choi amplitude

    |Omega_q>=sum_(i_1,...,i_N:total colored=q)|i>_in|i>_out,
    J_q=|Omega_q><Omega_q|.                            (T3)

It preserves ALL coherence between different temporal/color histories with
the same aggregate q. It is not a classical path approximation. The Choi
operator and its use in an adaptive strategy are independent: insertion
into the strategy is exactly the positive linking described in(T2).
Summing q gives a TP causal wire process with its unobserved counter; it
dephases only different aggregate sectors. Individual J_q need not be TP.

Let P_q project onto the total-charge-q sector of the N output ports. Its
rank and the squared norm of |Omega_q> are D_q=binom(N,q)2^q. The vector is
supported on I_in tensor P_q, so elementary rank-one positivity gives

    J_q<=D_q I_in tensor P_q
       =D_q^2 [I_in tensor sigma_q], sigma_q=P_q/D_q.  (T4)

The normalized comparator J_Rq=I_in tensor sigma_q discards every input
and emits one fixed correlated N-port state, prepared independently of the
initial resource. Its outputs can be prepared in advance and delivered in
chronological order. Its prefixes are the successive marginals of the SAME
sigma_q. Thus it is a normalized causal process with NO forward signal;
independence of its different outputs is unnecessary. The quantity D_q^2
is a mathematical dimension factor, not an entanglement-preparation bill.

## 4. Two counters in the actual recurrent-device network

Purify the complete actual protocol as in Section2. Add one coherent
aggregate counter to the incoming A wires, immediately before each device
interaction, and a second to the outgoing B wires immediately after it.
Neither counter is read or used for adaptive control. They are proof
registers, not extra signals supplied to the parties.

At beta0 the actual block K_oi=<o|U|i> vanishes whenever BOTH i and o are
colored. Consequently every nonzero port-basis history has at most one
colored passage per physical call and obeys

    q_in+q_out<=N.                                    (T5)

The root block R has i=o0 and is explicitly included. No bath diagonalization
or finite-depth assumption is used. Counters are inserted in the actual
chronological order; different times' physical charges need not commute.
Within each aggregate sector the ORIGINAL coherent history amplitudes are
retained, including all bath/laboratory interference and feedback histories.

Write the augmented final vector

    |Psi_tilde>=sum_(q+o<=N)|q,o> |Psi_qo>.

Expanding the same original network in its physical port basis shows

    |Psi_original>=sum_(q+o<=N)|Psi_qo>.                (T6)

The counters only tag the aggregate histories; their values are not fed
back into the underlying operations. This establishes(T6) directly by
amplitudes, not by claiming that discarding a counter preserves the original
state. In fact discarding the counters can dephase original interference.

There are M_N=(N+1)(N+2)/2 allowed pairs. For every vector v,
|sum_s <v|Psi_s>|^2<=M_N sum_s|<v|Psi_s>|^2. Therefore

    |Psi_original><Psi_original|
       <=M_N sum_(q+o<=N)|Psi_qo><Psi_qo|.

Partial trace and the final positive Bell test give

    F<=M_N sum_(q+o<=N)F_qo,                          (T7)

where F_qo is the UNNORMALIZED Bell overlap in the branch of the physical
two-counter instrument with final values q,o. No success branch has been
renormalized. This finite-sector inequality holds also for any normal mixed
initial state by purification or linearity.

## 5. Incoming-cut bound for a fixed sector

Fix q,o. In the cut Alice | (device bath plus Bob plus inaccessible systems),
the q-counting input wire instrument is the process J_q of(T3). All other
operations, including the o-counter on B, lie in a fixed valid cut strategy.
The o-counter is entirely local to the receiving side of this partition.
Initial cross-cut entanglement is allowed, but the fresh Bell pair remains
independent of the entire initial resource.

Replace J_q by J_Rq from(T4), keeping the same strategy and selected o.
By(T2),(T4), the actual positive sector output is at most D_q^2 times this
comparison output. Let it be tilde_rho^(q)_o. The SAME sigma_q is kept fixed
when summing over ALL o0,...,N. Those o branches form the complete local
counter instrument in one normalized comparison protocol. (One must not
choose a different comparator as o changes.)

The full comparison has no Alice-to-receiver forward signal. Its fixed
outputs, initial arbitrary preshares and Bob-to-Alice messages cannot carry
the fresh input. Thus its unconditional reference/receiver state, after TP
decoding, is (I_R/K) tensor omega_L^(q). Positivity of every instrument
branch gives

    tilde_rho^(q)_o <= sum_o' tilde_rho^(q)_o'
                    =(I_R/K) tensor omega_L^(q).

The normalized product has Bell overlap1/K^2. Hence

    F_qo<=D_q^2/K^2.                                  (T8)

One could additionally use receiving-side locality of the selection, but
the positive branch<=unconditional output argument already suffices.

## 6. Outgoing-cut bound and sender-side postselection

Now fix the same q,o and use the cut Bob | (Alice plus device bath plus
inaccessible systems). The o-counting output wire instrument is J_o.
The incoming q-counter is entirely local to the SENDING side of this cut.
Replace J_o by the normalized fixed correlated replacer J_Ro, with SAME
sigma_o as q varies. Positive linking gives sector output at most D_o^2
times a comparison branch tilde_rho^(o)_q.

Sender postselection CAN steer the reference and Bob. It would be incorrect
to call a normalized q-selected branch a product. Instead sum the complete
q instrument in this one fixed comparison protocol. All q0,...,N are summed,
including q with q+o>N: such branches may exist in the COMPARISON after
replacement, even though the original device forbids them. The sum is TP.

Since all outgoing wires are replaced, there is no sender-to-Bob forward
signal. All device interactions and q-counter operations are sender local;
backward messages go from Bob to sender. The initial fresh reference is
independent of Bob's whole initial resource. Therefore the unconditional
comparison output is (I_R/K) tensor omega_L^(o). Each positive selected
branch is bounded by that product output, so

    F_qo<=D_o^2/K^2.                                  (T9)

This explicitly uses UNNORMALIZED branch positivity, the completeness of
the sender instrument, and a comparator independent of the summed q. It
does not assume a flag known by Bob, extra forward selection communication,
initial bath/laboratory product, or accessible bath operations.

## 7. Combine dimensions and obtain the uniform strong converse

Equations(T7)--(T9) yield the first bound(T1). For each allowed pair q+o<=N,
one of q,o, say k, is at most N/2. Independently of which sector has smaller
dimension,

    min{D_q^2,D_o^2}<=D_k^2
       =[binom(N,k)2^k]^2 <=[2^N 2^(N/2)]^2=8^N.

There are M_N sectors in(T7), proving the second bound(T1). The polynomial
M_N^2=O(N^4) is proof slack, not an extra physical resource, preparation
depth, bath coherence or entanglement-cost factor. It is uniform in eta_N.

For reliable rate above3/2 the factor2^(-2delta N) dominates this polynomial.
The conclusion holds separately at each horizon with its own arbitrary
normal resource. No fixed-initializer limit, tail modulus, finite entropy,
finite support, bath identity trace, or unproved initialization oracle is
used. Product/SEP resources retain the separate stronger finite-N bound
8^N/K^2 without this polynomial from FULL_PROOF_V1.md.

For normal infinite laboratory systems, the purified initial vector and
normal local Stinespring maps used above are legitimate. The finite-port
link map L is bounded by finite dimensionality of its domain. All other
operations in the proof are finite-counter projections, bounded basis blocks,
normal partial traces and positive finite Bell tests. Thus no finite bath
cutoff is introduced in this extension. Any well-defined normal strategy
given as a trace-norm limit of finite internal communication networks
inherits(T1) by continuity of its Bell probability and the uniform constants.

At beta>0 the hard support(T5) fails; this proof does not assert a positive-
beta strong-converse threshold or import the earlier quadratic weak ceiling
as a strong converse. The separate weak-converse theorem remains valid.

## 8. Evidence, costs and remaining critical checks

The independent finite diagnostic check_sector_counters.py reuses only
w19's own tensor helper, with no peer imports. It constructs6 supplied
three-call beta0 protocols with fresh K27 Bell input, product/coherent,
generic E:LA:LB entangled or maximally E:labs entangled initial states,
random supplied local controls, and optional actual backward LB-qubit
transfer. The physical tree support grows from depth1 to4, without outer
reflection. It runs each protocol both with and without the two counters.

All forbidden q+o>N sector amplitudes vanish. Summing coherent counter
sector amplitudes recovers the original global state to max1.44e-17. Every
unnormalized sector Bell value obeys both dimension bounds and the full
vector-Cauchy inequality. Direct finite-port wire rank/whitening constants
are also recorded for N1,...,6. These are selected diagnostics, not proof
for all protocols or experimental communication results.

Recorded computation:1.06s wall,.87s user,.07s system, maximum RSS355,139,584
bytes; raw supplied local controls259,576 compressed bytes, hash in
SECTOR_COUNTER_CHECKS.json. Full reasoning/review cost and physical energy
are UNKNOWN. No state preparation, equipment operation, purchases or
external messages were performed. Generic communication dimension and
positive-link tools are established; the exact-device extension's priority
is UNKNOWN. The proof's source model is the same pinned corpus, not acquired
apparatus.

Fresh criticism should specifically reconstruct(T2), the adaptive wire-
instrument Choi(T3), the amplitude identity(T6), local counter placement
under both FIXED cuts, complete-instrument sums with the SAME replacer,
and the normal infinite-resource extension. A different source correlated
with the fresh input, an extra forward carrier or renormalized success
would change the contract and cannot serve as a counterprotocol here.
