"""Exact Q(sqrt3) depth/counter DP for beta=1/2 three-call classifiers.

Each block is native input10, measure Y HYPOTHETICALLY, one vacuum reset.
Exact denominator128 per block. No physical measurement is performed by the
coherent protocol; these statistics certify the coherent wrong-label effect.
"""
from pathlib import Path
import math,json,time,datetime,hashlib
ROOT=Path(__file__).parent

def add(out,key,A,B):
    if key in out:
        a,b=out[key];out[key]=(a+A,b+B)
    else:out[key]=(A,B)

def step(state):
    out={}
    for (score,h),(A,B) in state.items():
        if h==0:
            # Y+/- root probabilities(13 +/-6sqrt3)/32, reset staysroot.
            add(out,(score+1,0),52*A+72*B,24*A+52*B)
            add(out,(score-1,0),52*A-72*B,-24*A+52*B)
            # Y0 pushes1, then vacuum reset pops with3/4 or stays with1/4.
            add(out,(score,0),18*A,18*B)
            add(out,(score,1),6*A,6*B)
        else:
            for dy in [-1,1]:
                add(out,(score+dy,h-1),30*A,30*B)
                add(out,(score+dy,h),10*A,10*B)
            # Y0 push then reset.
            add(out,(score,h),18*A,18*B)
            add(out,(score,h+1),6*A,6*B)
            # Y0 pop then reset; root is absorbing under vacuum.
            if h==1:add(out,(score,0),24*A,24*B)
            else:
                add(out,(score,h-2),18*A,18*B)
                add(out,(score,h-1),6*A,6*B)
    return out

def probability(state,condition,r):
    A=sum(v[0] for k,v in state.items() if condition(k))
    B=sum(v[1] for k,v in state.items() if condition(k))
    scale=10**120;lower=math.isqrt(3*scale*scale);upper=lower+1
    assert lower*lower<=3*scale*scale<upper*upper
    U=A*scale+B*(upper if B>=0 else lower)
    D=scale*(1<<(7*r))
    assert U>=0
    return dict(A=str(A),B=str(B),denominator_power_of_2=7*r,
                sqrt3_bracket_scale=str(scale),sqrt3_lower_numerator=str(lower),
                sqrt3_upper_numerator=str(upper),upper_numerator=str(U),upper_denominator=str(D),
                upper_float=U/D)

def exact_run(h0,maxr,checkpoints):
    state={(0,h0):(1,0)};rows=[]
    for r in range(1,maxr+1):
        state=step(state)
        # Exact normalization in the quadratic field after every block.
        assert sum(v[0] for v in state.values())==1<<(7*r)
        assert sum(v[1] for v in state.values())==0
        if r in checkpoints:
            strict=probability(state,lambda k:k[0]<0,r)
            weak=probability(state,lambda k:k[0]<=0,r)
            rows.append(dict(initial_depth=h0,r=r,eta_plus=strict,eta_minus_by_sign_mirror=weak,
                             retained_depth_counter_states=len(state)))
    return rows

def main():
    start=time.perf_counter();checkpoints=[1,2,3,8,16,32,48,64,80,96];rows=[]
    for h0 in [0,1]:rows.extend(exact_run(h0,max(checkpoints),checkpoints))
    candidates=[]
    # Exact chosen target eta<=1e-8. All comparisons are integer inequalities.
    for r in checkpoints:
        subset=[row for row in rows if row['r']==r]
        certified=all(int(row['eta_minus_by_sign_mirror']['upper_numerator'])*10**8
                      <=int(row['eta_minus_by_sign_mirror']['upper_denominator']) for row in subset)
        if certified:
            upper=max(row['eta_minus_by_sign_mirror']['upper_float'] for row in subset)
            # V^3=iI at beta=.5, hence TWO forward V implement i V* on
            # both seed sectors; common global phase is irrelevant.
            T=12;oracle_operator=2*math.sqrt(upper)
            diamond=4*oracle_operator+2*math.sqrt(2*(.25**T))
            candidates.append(dict(r=r,H=1,certified_eta_upper=upper,eta_target='1/100000000',
                per_oracle_physical_calls=9*r,per_oracle_quantum_returns=9*r,
                two_oracle_plus_upload_forward_calls=18*r+T,
                quantum_backward_qutrit_returns=18*r,upload_ports=T,
                conservative_complete_channel_diamond_upper=diamond,
                status='Exact classifier certificate plus analytic coherent oracle/composition theorem; no apparatus run'))
    result=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        status='EXACT_QUADRATIC_FIELD_CLASSIFIER_CERTIFICATE_NOT_HARDWARE',
        beta='1/2',a='3/4',b='1/4',block_native_calls=3,
        tested_initial_depths=[0,1],checkpoint_r=checkpoints,
        arithmetic='Integer pairs A+B sqrt3 over2^(7r); integer-isqrt120-digit outward bracket',
        normalization='Exact after EVERY block for both initial depths',
        physical_or_source_calls=0,peer_imports=0,packages_installed=0,
        rows=rows,certified_factory_candidates=candidates,wall_seconds=time.perf_counter()-start)
    path=ROOT/'EXACT_THREE_CALL_CLASSIFIER_CERTIFICATE.json'
    path.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))

if __name__=='__main__':main()
