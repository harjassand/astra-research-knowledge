# A dimension-independent obstruction to hot decoupled catalytic return

23 October 2026. Self-contained internal proof candidate, no architecture
restriction on the commuting enlarged range algebras. This uses the standard
commuting-square entropy inequality, not a newly claimed uncertainty law.
W61 independently derived a hot 1/5 asymptotic bound and a general nonhot
continuity bound. The two-threshold refinement below improves the hot
asymptotic constant to 2/9. Priority and independent review remain UNKNOWN.

## 1. The stronger return contract

Let F,G be any commuting trace-preserving conditional expectations on M_(NK),
with arbitrary range algebras and H=FG. N=r^3 and E_P,E_Q are the original
rare binary targets. Prepare J_hot(rho)=rho tensor I_K/K. Require approximate
joint return, including arbitrary references:

    delta=max(||F J_hot-J_hot E_P||_diamond,
              ||G J_hot-J_hot E_Q||_diamond).             (1)

This returns the ancilla decoupled as its initial state, rather than merely
reproducing the system marginal. Let u be the common original basis vector,

    rho=|u><u| tensor I_K/K,
    omega=H(rho), tau=I_(NK)/(NK),
    q_r=(r-1)/r^2.

All norms are unhalved. For any ancilla dimensions K=K_r and arbitrary such
F_r,G_r, the following theorem holds:

    liminf_(r->infinity) delta_r >=2/9.                  (2)

No scalar-intersection, diagonal, rank, or hot-ancilla-size restriction is
used. This rules out vanishing joint catalytic error even though the marginal
simulation in HOT_QUANTUM_INTERVENTIONS.md has vanishing error with K~sqrt(r).
It does not apply to a nontracial initial ancilla without further hypotheses.

## 2. Entropy lower bound from the two rare output supports

Write all entropies and logarithms in bits, and h2 for binary entropy.
For 0<=delta<=1, the two marginal support bounds and commuting-square SSA give

    L_H:=D_bits(omega||tau)
       >=log2(r)-2h2(delta/2)-delta log2(r^2-1).           (3)

For completeness, the marginal F output has leakage at most delta/2 outside
the rank-r P subspace, so its entropy is at most
log2(r)+h2(delta/2)+(delta/2)log2(r^2-1). Add log2(K) for its ancilla.
Apply the symmetric bound to G and use the established inequality

    S(F rho)+S(G rho)>=S(rho)+S(H rho),

where S(rho)=log2(K), and N=r^3. This proves (3). The entropy inequality
itself follows from relative-entropy data processing through F applied to
D(rho||G rho), using FG=GF. It is the Petz commuting-square inequality,
also stated after Theorem B of Gao--Junge--LaRacuente arXiv:2301.08402v1.

## 3. Bounds on total variation and the high-density tail

The catalytic contract and channel contractivity imply

    ||H J_hot-J_hot E_P E_Q||_diamond<=2delta.

The exact target product distance to scalar depolarization is 2q_r. Hence

    T:=||omega-tau||_1/2<=delta+q_r.                    (4)

Unitality also gives rho<=I/K and therefore

    omega<=I/K=N tau.                                   (5)

There is a stronger high-density-tail bound. Put a=N/r=r^2. The F output
is within trace norm delta of P tensor I_K/(rK), a state bounded above by
I/(rK)=a tau. For two equal-trace Hermitian matrices, the positive part of
their difference has trace at most half their trace-norm distance. The
variational formula for the trace of a positive part is monotone in its
Hermitian argument; comparison with that target state therefore gives

    Tr(F rho-a tau)_+<=delta/2.

For a trace-preserving positive map G, Tr(G(Y))_+<=Tr(Y)_+ for self-adjoint Y;
this follows from the variational formula Tr(Y)_+=sup_(0<=E<=I)Tr(EY).
Since G is unital, G(a tau)=a tau. Consequently

    V:=Tr(omega-a tau)_+<=delta/2.                       (6)

No false Loewner claim (X-Y)_+<=X is used here.

## 4. A two-threshold elementary entropy upper bound

For numbers 1<a<N put

    c_a=a log2(a)/(a-1),
    d_(N,a)=[N log2(N)-c_a(N-1)]/(N-a).

Convexity of f(x)=x log2(x), with f(0)=0, gives on 0<=x<=N

    f(x)<=c_a(x-1)_+ + d_(N,a)(x-a)_+.                  (7)

Indeed f<=0 on [0,1]. On [1,a] its chord is c_a(x-1).
On [a,N] the right side is exactly the chord joining (a,f(a)) and (N,f(N)).
This is only a scalar inequality. Since tau is scalar, apply it to the
eigenvalue likelihood ratios x_i=NK lambda_i(omega), weighted by 1/(NK).
Equations (5)--(6) and the trace-zero difference from tau give

    L_H<=c_a T+d_(N,a)V
        <=c_a(delta+q_r)+(d_(N,a)/2)delta.              (8)

Combining (3) and (8), every legal hot catalytic return satisfies the explicit
finite-r necessary inequality

    log2(r)-2h2(delta/2)-delta log2(r^2-1)
       <=c_(r^2)(delta+q_r)
                    +(d_(r^3,r^2)/2)delta.             (9)

At delta>1 the lower bound (2) is automatic. For 0<=delta<=1,

    c_(r^2)/log2(r)->2,
    d_(r^3,r^2)/log2(r)->1,
    q_r->0, h2(delta/2)/log2(r)->0 uniformly.

Along any subsequence approaching liminf delta, divide (9) by log2(r) to get
1-2delta<=2delta+delta/2. Thus delta>=2/9, proving (2). QED.

The earlier one-threshold bound uses only (5), gives L_H<=c_N T, and yields
1/5. The extra high-density-tail control (6), which specifically uses strong
joint return, is what improves that constant. Neither constant is asserted
optimal.

## 5. General-state concentration tradeoff, separately scoped

For an arbitrary initial ancilla state sigma, put

    m=K||sigma||_infinity, C_sigma=log2(K)-S(sigma),
    J_sigma(rho)=rho tensor sigma,
    delta=max(||F J_sigma-J_sigma E_P||_diamond,
              ||G J_sigma-J_sigma E_Q||_diamond).

Let omega=H(|u><u| tensor sigma), beta=I_N/N tensor sigma and
T=||omega-beta||_1/2<=delta+q_r. Both omega and beta are bounded by
||sigma||_infinity I. A valid quantum mixing argument gives

    |S(omega)-S(beta)|
       <=T log2(Nm/T)+(1+T)h2(T/(1+T))=:g_(Nm)(T).       (10)

At T=0 the right side is zero. To prove it, write the Jordan decomposition
omega-beta=T(rho_plus-rho_minus) and the common mixture
(omega+T rho_minus)/(1+T)=(beta+T rho_plus)/(1+T).
Entropy concavity and the mixture upper bound give an absolute entropy
difference at most T|S(rho_plus)-S(rho_minus)|+(1+T)h2(T/(1+T)).
The positive and negative Jordan parts have operator norm at most
||sigma||_infinity; their normalized states have entropy at least
log2(T/||sigma||_infinity). Comparing with entropy <=log2(NK) proves (10).
This uses the norm of a positive part, not an invalid operator common part.

Thus L_H<=C_sigma+g_(Nm)(T). The support/SSA lower bound now reads
C_sigma+L_H>=log2(r)-2h2(delta/2)-delta log2(r^2-1), yielding

    2C_sigma+g_(Nm)(T)+2h2(delta/2)
                       +delta log2(r^2-1)>=log2(r).     (11)

For example, if C_sigma=o(log r) and log m=O(log r), vanishing delta is
impossible, regardless of K. If m<=r^b and C_sigma/log2(r)<=c+o(1), the
liminf necessary bound is delta>=max(0,(1-2c)/(b+5)). The hot state has
C_sigma=0,m=1; section 4 gives the stronger 2/9 constant there.

This general-state tradeoff was independently derived in parallel by W61
and W40. Its entropy/mixing ingredients are established. It is not a
construction attaining the bound or an unrestricted no-go for highly
concentrated nontracial catalysts. Approximate nonhot catalytic constructions,
sharp constants, arbitrary-intervention global return and physical utility
remain UNKNOWN. Mission NOT_ACHIEVED.

## 6. A return-concentration bound for every initial ancilla state

There is a stronger consequence when the full catalytic contract, rather
than only its reduced support constraints, is used on both first actions.
Put L=Nm, u=delta+q_r, and assume u<=1. The same mixing proof (10) applies
to each pair

    F rho versus (P/r) tensor sigma,
    G rho versus (Q/r) tensor sigma,
    H rho versus (I_N/N) tensor sigma.

All six states are bounded by ||sigma||_infinity I, by unitality for the
actual outputs. The first two half trace distances are <=delta/2; the third
is <=u. The function g_L from (10) is increasing on [0,1] for L>=N>=8.
Thus their entropy differences are at most g_L(delta/2), g_L(delta/2),
and g_L(u), respectively. Commuting-square SSA now yields

    log2(r)<=2g_(Nm)(delta/2)+g_(Nm)(delta+q_r).           (12)

Indeed the target first-action entropies equal log2(r)+S(sigma), while the
target mixed-action entropy equals 3log2(r)+S(sigma), and S(rho)=S(sigma).
The S(sigma) terms cancel. This applies to arbitrary nontracial sigma and
arbitrary commuting range algebras; it is not a three-block rank argument.

If log2(m)<=b log2(r)+o(log r), dividing (12) by log2(r) gives

    liminf delta>=1/[2(b+3)].                            (13)

For pure sigma, m=K. Consequently polynomial ancillary dimension K<=r^b
cannot support vanishing decoupled catalytic error even with a pure initial
state. More generally this holds whenever peak concentration m grows only
polynomially, regardless of the total K or entropy deficit. It strengthens
the regime of the two-parameter tradeoff (11); their quantitative lower
bounds can be combined by taking the larger one. The hot bound 2/9 remains
stronger than (13) at m=1.

If delta<=c/r for a fixed c>0, (12) instead requires

    log2(m)>= [r/(2c+1)-O(1)] log2(r).                   (14)

To see this, the coefficients of log2(Nm) in (12) sum to
2(delta/2)+(delta+q_r)<= (2c+1)/r. The remaining terms are
O((log r)/r), since T log(1/T) and the mixing entropy terms have that order
for these distances. Solve for log2(Nm) and subtract 3log2(r).
Because m<=K, the same dimension lower bound applies to K. It is a
necessary resource bound, not a catalyst construction or a sharp asymptotic
constant. Large highly concentrated embezzling-type catalysts are not
excluded by it and would require a separate realization by commuting trace
expectations.
