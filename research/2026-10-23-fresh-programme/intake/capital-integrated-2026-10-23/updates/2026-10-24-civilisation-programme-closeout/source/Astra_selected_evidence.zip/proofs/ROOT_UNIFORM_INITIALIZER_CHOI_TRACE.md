# Uniform initializer upper bound from weighted Choi trace

23 October2026. W19 independently invented this route in CONSTRUCTION_BEFORE_PEERS.md before reading W36's proposed free-tree polynomial approach. Root, W36 and W49 then reconstructed it. This file is root's direct mathematical verification, not an independent priority claim. Generic CP-order/max-information/comb tools are established. Device-specific historical priority UNKNOWN; no hardware result.

## Generic finite-port criterion

A finite d-dimensional port interacts sequentially with any separable memory Hilbert space E via a fixed unitary V. In port bases put V_oi=<o|V|i>, bounded operators on E. Fix a faithful output state sigma diagonal with probabilities s_o>0. Define the positive Heisenberg map on bounded memory operators

Theta_sigma(X)=sum_(i,o) s_o^-1 V_oi^* X V_oi.

If Theta_sigma(I)<=hI, then for EVERY call countN and EVERY normal initial memory state tau_N, including arbitrary N-dependent coherent states with no depth/entropy bound, the complete N-port channel obeys

N_N^(tau_N) <=CP h^N R_(sigma^tensorN).                (1)

The memory must start PRODUCT with the entire encoded input and all laboratory resources. This is not an arbitrary correlated-initial-assignment claim.

Proof: use the UNNORMALIZED port Choi matrix J_N, whose input reference is sum_i |i,i>. Whiten only its output:

Z_N=(I_R tensor sigma^(-tensorN/2))J_N
                       (I_R tensor sigma^(-tensorN/2)).

It is a positive matrix on finite port reference/output spaces, so Z_N<=Tr(Z_N)I. Let K_(o,i)=V_(oN,iN)...V_(o1,i1) denote a history operator. Directly tracing the Choi matrix gives

Tr Z_N=sum_(i,o)[product_t s_(ot)^-1]
                       Tr[tau_N K_(o,i)^*K_(o,i)]
       =Tr[tau_N Theta_sigma^N(I)] <=h^N.             (2)

The chronological Heisenberg order follows by summing the final call first. Positivity of Theta and Theta(I)<=hI imply Theta^N(I)<=h^NI inductively. All terms are finite sums of bounded operators at each N, so no infinite-dimensional trace interchange or bath cutoff is needed. Conjugating Z_N<=h^NI back proves(1). The replacer's UNNORMALIZED Choi matrix is I_R tensor sigma^tensorN; there is no missing d^-N factor.

## Evaluation for the ORIGINAL device

Use two Cuntz-Toeplitz prefix isometries S1,S2, root projection P0 and root seed flip R:

S_i^*S_j=delta_ij I, S1S1^*+S2S2^*=I-P0,
R^*=R, R²=P0.

The original involution and device are

U=[[R,S1,S2],[S1^*,0,0],[S2^*,0,0]],
V=sqrt(a)U+i sqrt(b)I, a=1-b, b=beta².

For sigma_p=diag(p,q,q), q=(1-p)/2, summing the nine terms gives EXACTLY

Theta_p(I)=H_b(p)I+a(1/p-1/q)P0,
H_b(p)=(2-b)/p+(1+b)/q
      =(2-b)/p+2(1+b)/(1-p).                          (3)

The R/I cross terms cancel in V_00^*V_00 before using any bath symmetry. The root term is nonpositive whenever p>=1/3. In particular p=1/2 gives

Theta_(1/2)(I)=(8+2b)I-2aP0.

For0<=b<=1, the minimizing p is

p_* =sqrt(2-b)/(sqrt(2-b)+sqrt(2+2b)) in[1/3,1/2],
h_*(b)=[sqrt(2-b)+sqrt(2+2b)]² <=8+2b.                (4)

Thus(1) holds with h_*(b), uniformly over ALL normal tau_N in the product-initial-resource model. Atb0 h8; atb1 h9. This supersedes polynomial/cutoff prefactors for this model. The older fixed-normal optimized-kernel upper may remain sharper at some interior b; preserve the best applicable bound rather than asserting every new formula dominates all earlier refinements.

## Complete finite-error and feedback consequences

For any fixed-N quantum code of rankK, preserving all failure branches,

F_ent <=min(1,h_*^N/K²).                              (5)

CP order passes through CPTP encoders/decoders; the replacer carries no logical information, so its Bell overlap is1/K². The same holds with initial shared entanglement INDEPENDENT of the bath and arbitrary backward quantum feedback, fixed call count and no external forward carrier. To see the sequential extension, the N-turn Choi inequality is a domination of causal combs. The positive difference

[h_*^N J_replacer-J_device]/(h_*^N-1)

satisfies the affine prefix trace constraints with the SAME global coefficient. Hence it is a normalized physical comb, and every causal tester preserves the convex-mixture decomposition. The replacer plus backward communication/preshares still cannot signal logical data forward. This is the established comb method, not a new causal-order theorem.

Consequently the uniform quantum rate upper is

Q <= C_*(b)=(1/2)log2 h_*(b).

Above C_* by delta>0, Bell fidelity is at most2^(-2delta N) uniformly over any horizon-dependent normal product initializer family. In particular atbeta0, Q<=1.5 and full-qutrit-rate Bell fidelity<= (8/9)^N, regardless of supplied coherent depth. The inherited fixed-normal lower attains1.5 atbeta0. This does not assert that the same lower is uniform over arbitrary adversarial varying initializer families.

Static entanglement-assisted classical success similarly obeys p_succ<=h_*^N/M forM equiprobable messages, hence classical rate<=log2h_*. For a direct unassisted block channel, CP order gives I(R:B)<=Nlog2h_* and coherent information<=min{S(R),Nlog2h_*-S(R)}; its purified complete complement contains at least[2S(R)-Nlog2h_*]_+ mutual-information bits.

Initial bath–laboratory correlations remain DIFFERENT. A receiver-held purifier or encoder-owned system correlated with the bath is outside the factorization used to define this channel/comb. The earlier fixed-normal correlated-resource cutoff and quantum-incoherent resource bounds remain useful in that larger model. A one-call coherent reference can have finite behavior better than a classical initializer while still satisfying this asymptotic ceiling.

No physical bath preparation, efficient useful code, exact beta>0 coefficient, general correlated-initializer theorem or mission accomplishment follows. Mission NOT_ACHIEVED.
