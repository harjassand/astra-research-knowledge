# Two acquired actions versus a nonadaptive lower: connectivity of hidden stars

2026-10-23. A simpler analytic consequence of checkpoint 4, not a full-support two-action claim. All previous frozen bytes are unchanged. Correctness/priority/practical review is pending.

Consider exactly checkpoint 4's family: n=2d+2 labelled vertices, two unknown hubs U,V, d unknown leaves attached to each hub, leaf-edge weights anywhere in [a,3a], and an optional U--V edge of known weight a. The task is only to decide whether that edge is present, equivalently whether this promised forest is connected. Hubs and leaf memberships are not supplied. Every full acquired scalar has independent N(0,sigma^2) sensor noise; exact rational controls are available. Use delta in (0,1/2).

Suppose

    sigma <= a/sqrt(32 ln(2/delta)),
    d >= 8 ln(8/delta),
    d > 12 + 16 sigma sqrt(2 ln(8n/delta))/a.               (A)

Then TWO adaptive complete n-output actions suffice with worst-case error <=delta for every fixed promised weighted forest, using total row energy <=1/2. No metadata or extra measurements are used. The only randomness besides sensor noise is n fresh fair bits in the first prepared input.

Action 1. Draw independent fair bits b_i and prepare x_i=b_i/2. Acquire all n outputs. Choose the two vertices with greatest absolute acquired output as the hubs. Select their order deterministically by label.

Proof of hub acquisition. Conditional on a hub's own bit, the number of its d leaves with the opposite bit is Binomial(d,1/2), irrespective of edge weights. Every term w_ij(x_i-x_j) at a binary-controlled positive Laplacian row has the same sign, so the optional hub edge cannot cancel the leaf currents. If at least d/4 leaves have opposite bit, that hub's noiseless absolute response is at least ad/8. A leaf's noiseless absolute response is at most 3a/2. Hoeffding gives failure probability at most exp(-d/8) per hub.

Let t=sigma sqrt(2 ln(8n/delta)). The event that all n first-action sensor errors have magnitude <=t fails with probability <=delta/4. On this event and both binomial events, hub outputs have magnitude >=ad/8-t and all leaf outputs have magnitude <=3a/2+t. The last condition in (A) makes the two hubs strictly the largest. The first-binomial failure is <=2 exp(-d/8)<=delta/4 by (A). Thus this ACTUAL acquired hub set is correct with probability at least 1-delta/2. It is not supplied by a hidden degree or topology oracle.

Action 2. Prepare x_U=1/2 and every other coordinate zero, using one of the acquired hubs U. At the other hub V all its leaf neighbours have exactly the same zero input as V. Its noiseless acquired output is therefore 0 if disconnected and -a/2 if connected. Declare connected precisely when the acquired V output is below -a/4.

The second action's fresh sensor noise is independent of the first action and of its selected hubs. On the correct hub event the error probability is at most exp(-a^2/(32sigma^2))<=delta/2. The union bound proves total error <=delta. Each vertex receives squared control at most 1/4 in action 1 and at most 1/4 in action 2, so total row energy is <=1/2. Controls are exactly 0 or 1/2, requiring no growing probe-coordinate precision in the ideal mathematical interface. There are exactly two preparations and 2n acquired scalar readouts. Straight-line processing and selecting the two largest outputs cost O(n).

For comparison, NONADAPTIVE_NOISE_LOWER_BOUND.md applies even if a decoder is granted the hub/leaf partition AFTER all nonadaptive controls are committed. For any fixed ratio sigma/a obeying (A), fixed delta, fixed epsilon with delta+epsilon<1/2, and total row energy B<=1,

    q_nonadaptive >= n(1-2delta-2epsilon)^2
                      /[2 ln(2(n-2)/epsilon)+8a^2/sigma^2]
                   = Omega(n/log n).

The two-action adaptive learner uses LESS total row budget, the same fixed sensor noise, the same bounded continuous weights, and no post-design metadata. Conditions (A) hold for all sufficiently large n. Thus this specialized promised connectivity problem gives a two-round versus nonadaptive acquisition separation at fixed noise and fixed total row-energy order. It does not reconstruct every star-leaf membership or every weight with two noisy actions; all-size full support at fixed row energy and fixed sensor noise has additional information requirements.

Actual control errors remain a charged interface condition. At a hub, degree is d or d+1 and ||L||_infinity<=6a(d+1), so bounded coordinate preparation error kappa can create response bias up to 6a(d+1)kappa. To keep the second-action bias below, for example, a/16, one must supply kappa<=1/[96(d+1)], as well as sensor/quantization margins (changing constants if they share the error budget). The first action can produce order an current and needs that dynamic range. A mathematical unit row-norm budget is not an energy-in-joules or measurement-time guarantee. Reset time, readout duration, and instrument cost have not been measured.

Mathematical status: INTERNAL_COROLLARY_CANDIDATE. Priority: UNKNOWN. Physical acquisition: NOT_ACQUIRED. Practical advantage: UNKNOWN. Mission: NOT_ACHIEVED.
