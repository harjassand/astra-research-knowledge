# A charge-resolved mesoblock encoder from bounded relative-density access

W67, 23 October 2026. **New proof candidate; fresh criticism pending.**
This is separate from every frozen, reviewed quartic-rate row. It proposes
an actual randomized encoder operation, rather than an eigenbasis oracle.
No enormous program, source circuit, physical experiment or successful
code seed has been generated. Standard filters, designs, polar transforms,
concentration and recovery are prior. Composition priority is UNKNOWN.

The useful interface may be weaker than a classical circuit constructor:
this version permits polynomial **quantum offline preprocessing** of the
known source circuit to estimate a polynomial-size classical table. The
resulting table, all random seeds and the complete circuit descriptions
are public preprogramming with counted bits. They are not acquired from
the unknown physical bath. Removing that quantum preprocessing, or
charging distribution through the forward device, is a separate interface
obligation, not a free wire.

## 1. Source premises and regularization

Let one source block have k qutrit ports,

    sigma=diag(1/2,1/4,1/4)^tensor k,
    Q=sum diag(0,1,1),    -log2 sigma=k+Q.

Supply an analytic state rho=sigma M, with [M,Q]=0, M>=0,
Tr sigma M=1. Supply polynomial local block access to M, not its spectral
basis, and a local preparation circuit for rho. Assume

    S(rho)>=3k/2+g,    D_b(rho)<=-kappa I in the actual bulk,
    Tr sigma(M-I)^2<=c_chi,    ||M||<=poly(k).

The actual root remains. Take rho_*=(rho+sigma)/2=sigma M_*,
M_*=(M+I)/2. Then

    M_*>=I/2,  ||M_*||<=poly(k),
    S(rho_*)>=3k/2+g_*, g_*=g/2,
    D_b(rho_*)<=-kappa_* I, kappa_*=kappa/2,
    Tr sigma(M_*-I)^2<=c_chi/4.                     (M1)

The drift identity uses D_b(sigma)=0; entropy uses concavity, so no
dimension-dependent trace-continuity estimate is substituted.

For the source-specific V4 premise, W56
CAUSAL_CLIPPED_LOWER_V4.txt has SHA256
b37eccacafa054db80a9f28f6903af0015b78f00a83c303048b8586994b6a0a6.
Its conditions are beta<=1/128, b=beta^2, k=floor[1/(5b)], k>=3276,
t0=v_k b^2 in[1/300,1/200]. It gives

    g=t0/31, kappa=t0/480,
    c_chi<1/6400, so g_*>=1/18600, kappa_*>=1/288000.

These are imported source theorems, not re-proved here. The acquired
access interface is W39's H/source factory plus its qualified functional
calculus; W39's new router SHA256 is
a9d8650d81802348413971888f84ba76c5b2fcfa564333a0995460c42dcb2952.
It preserves the actual H; it does not turn it into collective hopping.
W66's regularization/log component has SHA256
68d9886739c11239b81b8d4fc1daeef00b5305047237d7a2ad184654c847f37f.
For clipped V4, use the explicit analytic relative operator and its
operator-norm approximation. Trace closeness of an arbitrary prepared
native state does NOT imply relative-density access.

## 2. Mesoblocks, a smooth partition, and accessible fractions

Group t source blocks, with t an integer selected below. On these kt
ports put

    L=sum_(a=1)^t ln M_*^(a),
    rho_*^t=sigma^t exp(L),    [L,Q_total]=0.

The scalar lower bound gives L>=-t ln2. Also

    E_(rho_*^t) exp(L)=(Tr sigma M_*^2)^t
                     <=exp[(c_chi/4)t].

Consequently Pr_(rho_*^t)(L>t-1)<=exp[1-(1-c_chi/4)t].
For c_chi/4<=1/2 this is at most e*exp(-t/2). This is a genuine
source-probability estimate, not a claim that ||L||=O(t).
The full operator norm is only O(t log k), still polynomially accessible.

For integer j define the continuous, globally Lipschitz function

    f_j(x)=cos(pi(x-j)/2) if |x-j|<=1, and 0 otherwise.

For every real x, sum_(j in Z) f_j(x)^2=1. At most two terms are nonzero.
Use bins j=-t,...,t. The omitted total mass is at most e*exp(-t/2).
Let P_q be exact total-charge projection. Define

    p_(q,j)=Tr[rho_*^t P_q f_j(L)^2].                (M2)

There are B=(kt+1)(2t+1) possible retained table cells. Discard cells
whose source probability is below a polynomially small threshold p_min;
with suitable conservative estimated thresholds their additional mass
is at most 4B p_min. Let P be the total retained mass and require

    1-P<=d, d<=1/4.                                (M3)

This is achieved with t=O(log k+log(1/d)) and p_min=Theta(d/B), with
constants specified by the final finite guards. Probability-table errors
and ambiguous cells are included in d or in a separate relative factor.

On a selected charge q, the known parent dimension is

    N_q=binom(kt,q) 2^q,
    D_q=2^ceil(log2 N_q), sigma_q=2^(-kt-q).

Pad this known enumerative space by zeros to D_q. No unknown spectral
coordinates are used. Let E_q be the ordinary charge-rank/unrank map on
the valid N_q labels. On that space define the bounded positive filter

    A_(q,j)=E_q^* exp[(L-j-1)/2] f_j(L) P_q E_q,
    A=0 on invalid padded labels.

The displayed exponential is evaluated only where f_j is nonzero;
the scalar function is defined as ZERO outside [j-1,j+1]. Thus 0<=A<=I.
Its scalar Lipschitz constant is less than3. There is no implementation
of exp(L/2) with an exponentially large normalization followed by an
informal cancellation.

Write mu=Tr(A^2)/D_q. Exactly,

    p_(q,j)=sigma_q exp(j+1) D_q mu.                 (M4)

Since sigma_q D_q<=2 and j<=t, every retained cell has

    mu>=p_min exp[-(t+1)]/2=:mu_min.                 (M5)

For t=C log k and inverse-polynomial d, mu_min is inverse polynomial in
k. C may be enormous and depends on the fixed source margins; no small
exponent or practical implementation follows. The global t-source
spectral window is made accessible only INSIDE a charge parent. Taking
one global window for m>>log k would reintroduce exp(-Theta(m)) fractions.

## 3. Relative PSD compression, with a variance factor

This factor is load bearing. A generic bound sqrt(K/D) would require
K<=tau^2 mu^2 D and lose an extra -log mu in the width. We instead use
the variance of a positive contraction.

Let 0<=B0<=I on D dimensions, mu=Tr B0/D>0, C0=B0-mu I.
Then Tr C0=0, ||C0||<=1 and Tr C0^2<=mu D. For a standard complex
Gaussian g and |z|<=1/2,

    log E exp(z g^* C0 g)
       =sum_(a>=2) z^a Tr(C0^a)/a <=z^2 mu D.

Chernoff with z=min(x/(2mu D),1/2), and the negative analogue, yields

    Pr(|g^* C0 g|>x)
        <=2exp[-min(x^2/(4mu D),x/4)].

The denominator event ||g||^2<D/2 has probability at most exp(-c0 D),
c0=ln2-1/2. A quarter-net of the complex K sphere has at most9^(2K)
points. With Z=||V^* C0 V|| for a Haar D-by-K frame V, put

    v0=2K ln9+ln2, zeta=exp(2K ln9-c0D).

For u>=0 the preceding bounds imply

    Pr{Z>16[sqrt(mu(v0+u)/D)+(v0+u)/D]}<=exp(-u)+zeta.

Integrate before changing the distribution. Minkowski at moment2h and
the exponential moment bounds ||X||_h<=h, ||X||_(2h)<=2h give

    E_Haar Tr[(V^*C0V)^(2h)]
    <=K{[16sqrt(mu(v0+h)/D)+16(v0+2h)/D]^(2h)+zeta}. (M6)

For h<=K, v0+2h<=8K. If

    K/D<=2^-20 tau^2 mu, 0<tau<=1/2,                (M7)

the bracket in(M6) is less than tau mu/16. A diamond-accurate2h-moment
design transfers the trace moment with additive delta_des K^(2h),
because ||C0^(tensor2h)||<=1. Sufficient finite guards for relative
Gram failure probability eta_f are

    h<=K, h>=ceil log2(4K/eta_f),
    2K ln9<=c0D/2,
    c0D/2>=ln(4K/eta_f)+2h ln[1/(tau mu)],
    delta_des<=eta_f/4 * (tau mu/K)^(2h).             (M8)

Then

    ||V^* A^2 V-mu I_K||<=tau mu                   (M9)

except with probability eta_f. Use a finite Pauli design at order2h,
with all seed and synthesis costs paid, as in frozen compiler622187d1.
An extra independent uniform Pauli on the LEFT of the sampled unitary
ensures the first frame moment is EXACTLY K I_D/D. This preserves the
diamond design accuracy and costs2log2D fair bits and O(log D) gates.

This proof does not transfer a net to a small design. It first integrates
the Haar tail, transfers the polynomial trace moment, and then uses Markov.
Finite guards concerning D, K and h are required, even though all become
easy at the large mesoblock dimensions used below.

## 4. A compiled pure isometry and its averaged operator bound

For each table cell choose a dyadic K satisfying(M7), within a fixed
factor of its right-hand side, by a conservative relative estimate of p
and hence of mu through(M4). Let G=V^*A^2V. On the event(M9), define

    C_(q,j,V)=E_q A V G^(-1/2).                     (M10)

This is a physical pure isometry from K dimensions into exactly charge-q
ports. Its smallest pre-polar singular value is at least
sqrt[(1-tau)mu], an inverse polynomial. A bounded sign/polar transform
of the acquired block A V supplies the encoder and reverse circuit to
any prescribed operator accuracy in polynomial cost. It does not acquire
G entries or a Gram eigenbasis. Inverses are reversals of the same full
native circuit; all signal projectors and helper completions are retained.

Let Good denote(M9). Since G>=(1-tau)mu I,

    1_Good C C^*/K
       <=1_Good E_q A V V^* A E_q^*/[K(1-tau)mu].

Drop the indicator only on this positive right side. Exact first moment
then gives

    E_V[1_Good C C^*/K]
       <= E_q A^2 E_q^*/[(1-tau)D_q mu]
        =rho_*^t P_q f_j(L)^2/[(1-tau)p_(q,j)].      (M11)

Sample retained(q,j) with probability p_(q,j)/P. Summing(M11) yields

    E_[q,j,V][1_Good C(I_K/K)C^*]
       <=rho_*^t/[(1-tau)P].                       (M12)

An estimated public table with normalized probabilities bounded by
(1+zeta_p)p_(q,j)/P multiplies this by1+zeta_p. The selected encoder is
NOT certified good. It is a randomized program with an explicit failure
probability. Bad programs are not silently treated as isometries(M10).
The actual finite circuit is always a total CPTP operation; comparison
with the ideal pure target is asserted only on good seeds.

## 5. Width: O(log k) loss, with variable offline cells

The relative table estimate can make the dyadic width ell=log2K satisfy

    ell>=log2D_q+log2mu-2log2(1/tau)-24.

The constant24 allows dyadic rounding and a conservative factor in(M7).
For a state in the support of f_j, its information
I=-log2(rho_*^t) is -log2sigma_q-L log2e, and

    -log2sigma_q-(j+1)log2e >=I-2log2e.

Using(M4), and averaging the retained table, therefore gives

    E ell >=t S(rho_*)
       -d(2k+1)t-log2 B-2log2(1/tau)-24
       -2log2e+log2P.                              (M13)

The information is bounded by(2k+1)t because rho_*>=sigma/2 at each
source block. No claim that charge fluctuations have only constant
variance is used. Pick t so the entire displayed overhead is at most
t g_*/4. With d,tau inverse polynomial in k this has a solution
t=O(log k) for fixed positive source margins. Constants depend on those
margins, and the literal finite inequality is part of the constructor.
For the estimated normalized table, the one-sided relative bound used
in(M12) implies total variation at most zeta_p. Since ell<=2kt, subtract
an additional2 zeta_p kt from(M13). This term is also included in the
finite overhead inequality before using(M14)--(M15).

This is why one must allow the offline cell(q,j) to choose a VARIABLE
width. Requiring the same width in every typical q loses sqrt(kt) charge
fluctuations, which would force much larger mesoblocks and destroy(M5).

Take s independently sampled cells and frames. Their widths are known
classical program data and satisfy0<=ell<2kt+1. Hoeffding bounds the
probability that sum ell is below its mean by s t g_*/8 by

    exp[-s g_*^2/(128 k^2)]                         (M14)

using k>=2 and deliberately loose constants. Thus polynomial s suffices
for a predetermined parent width

    ell_parent=floor[s t(3k/2+g_*/2)].              (M15)

Reject and resample a cell sequence whose total width is smaller than
ell_parent. This is a CLASSICALLY decidable width test, unlike good-frame
certification. If the rejection probability is at most eta_w, the final
conditioning contributes at most1/(1-eta_w) to averaged bounds.

For a successful width sequence, let W=sum ell-ell_parent. Choose W
fair PUBLIC program bits z, and embed an arbitrary logical/reference
state as |z> tensor |psi> before the product of the isometries(M10).
These bits are fixed in the program for the entire code. They are not a
mixed gauge secretly traced at the sender, a runtime forward message or
preserved entanglement. Averaging z gives the maximally mixed state on
the full product code when the logical input is maximally mixed.
The result for every fixed program is a PURE isometry of the COMMON
width(M15), with definite total physical charge sum q.

The word PUBLIC is substantive: no message-dependent gauge is selected.
Both parties receive the same finite program before transmission. The
probability table may be learned once by the known local quantum circuit;
thereafter bounded fair bits and a finite dyadic cumulative table sample
all cells classically. Rounding probability weights down and assigning the
small remaining grid mass to a retained cell gives an exact finite fair-bit
sampler with a charged one-sided relative error, if its grid is finer than
zeta_p p_min/B. There is no infinite rejection sampler in the seed bound.

Combining(M12) across independent mesoblocks, then averaging z and
conditioning only the decidable width test, gives

    E_program[1_allframesGood C_parent(I/D)C_parent^*]
      <= F rho_*^(st),
    F=[(1+zeta_p)/((1-tau)P)]^s/(1-eta_w).           (M16)

The product indicator is necessary; the probability that it fails is at
most s eta_f. The invariant dimension D=2^ell_parent is fixed before
message transmission. Each fixed program has an explicit unitary
extension, inverse and range test. Random bits z are included in the
bounded program seed. They are not freshly sampled by the encoder on
each message.

## 6. Acquisition and finite implementation, with no spectral coordinates

The classical table cells are obtained by quantum offline experiments on
the known LOCAL preparation circuit for rho_*^t. Measure exact Q_total
and the commuting smooth-bin instrument with Kraus f_j(L). Ordinary
bounded sampling estimates all polynomially many probabilities to a
specified inverse-polynomial additive error, with an explicit confidence
failure budget. At retained p>=p_min, a sufficiently finer error yields
relative factor zeta_p and the conservative mu estimate used in(M7).
All copies, state preparations, helper resets and measurements are paid.
These are algorithms, not experiments actually performed in this work.

An eigenbasis is unnecessary for this instrument. A finite phase-estimator
for the acquired Hermitian L first estimates its eigenvalue coherently;
reversible finite scalar arithmetic prepares the two nonzero bin
amplitudes; uncompute the phase estimator. Its ideal amplitude vector
(f_j(x))_j is globally Lipschitz. Uniform functional error can therefore
be made inverse polynomial by polynomial phase-estimation precision.
Keep a phase interval away from wraparound. The same device implements
the bounded scalar filter A_j(x), with its known compact support and
Lipschitz constant. Square-root rotation accuracy is charged at the full
Stinespring level, not inferred from a signal-block error alone.

All scalar functions are computable, finite-bit functions; no exact real
oracle is a program input. Uniform polynomial approximation / established
QSVT or finite phase estimation plus local arithmetic suffice. Their
classical coefficients/phases, intermediate precision, output emission,
controlled operations and full-unitary adjoints remain charged. We seek
a conservative polynomial constructor, not optimal approximation degree.

Source log access is to M_* whose lower bound is1/2. It is NOT log access
to the exponentially small density rho_* itself, nor a promise that an
arbitrary trace-close native source has a well-conditioned relative
operator. The individual source operator is approximated uniformly, and
the analytic functions above are approximated uniformly to their own
budgets. Total physical encoding is compared against(M10) on good seeds.

Charge ranking is elementary. Choose the q occupied positions by
binomial rank/unrank, then q binary colours; all integers have O(kt)
bits. Reversible compute/XOR/uncompute gives a total permutation on all
bitstrings, with invalid labels marked. The filter is ZERO on invalid
labels. After the polar step its target output lies in the valid parent
space. A finite approximation can use a CPTP validity conversion with a
retained reject flag; contraction preserves the charged small encoder
error. No illegal four-bit pattern is handed to a physical qutrit port.

## 7. End-to-end interface and costs still to instantiate

Equation(M16), an efficient pure full-domain C_parent, known dimension,
and definite total charge are the interfaces required by the already
compiled body/flush/common-Fourier/full-TP polar construction. They do
not by themselves provide numerical forward horizons. For known b, the
source/drift premises are as above. A common source over a nontrivial
unknown-b band requires a separate uniform full-drift proof; that is NOT
inherited from the quartic pair source.

A deliberately conservative generic Lyapunov choice is

    t_L=kappa_*/(8k^2), lambda=1-kappa_* t_L/2.

The bounded k-call displacement and negative bulk drift give
Phi^*e^(t_L Ldepth)<=lambda e^(t_L Ldepth)+e^(2k t_L)P_(depth<k).
All cross-depth terms vanish by exact total-charge commutation. This
retains the actual low-depth/root term, and yields a polynomial C_tail.
With(M16), choose body cutoff from log F+log[(1+C_tail)/q_code] and all
code-selection/Markov failure budgets. Add the actual terminal zero
flush, its binomial tail, initial prefix and the pointwise normal-state
tail. No iid bath, known radial state or free reset is used.

Because log F=O[s(tau+d+zeta_p)]+O(eta_w), inverse-polynomial choices
tau,d,zeta_p small enough make the resulting linear part of terminal
padding much less than the positive s t g_* width. The remaining log
horizon terms are dominated by polynomially increasing s. The extra
outer high-design width sacrifice is logarithmic in the total physical
horizon. Explicit finite inequalities and sample scalar rows are a NEXT
OBLIGATION; they are not asserted checked in this draft.

For fixed source margins, t=O(log k); every retained mu_min^-1 is a
fixed polynomial in k (with a potentially vast exponent). Register
widths, 2h-design orders, moment accuracy bits, seed counts, table counts,
sampling repetitions, filter degrees and polar query counts are
polynomial in k, s, inverse target accuracy and inverse confidence.
Native repeated encoder calls inside the universal row decoder multiply
these costs; the previous quartic m5 whole-code exponent is NOT retained.
Classical scalar tables, all random seeds, stable phase generation and
full circuit descriptions are separate counted costs. There is no
claim that a polynomial with a huge source-margin exponent is useful.

If public preinstallation of the quantum-generated table is disallowed,
one must either derive a classical constructor or send that finite
message-independent table using an explicitly paid bootstrap code and
then amortize its size. The random seed can be common preprogramming as
in the earlier code contract, but its bits are never omitted from cost.
This boundary must be resolved in any stronger operational theorem.

## 8. Falsifiers and precise unresolved status

1. Any missing factor mu in(M6)--(M8) would erase the main rate estimate.
2. M11 is an UNCONDITIONED good-event bound. Dividing by a good-frame
   probability separately per mesoblock would change F and must be paid.
3. A variable-width construction that discards a correlated sender gauge
   is invalid. The fixed public prefix in Section5 is essential.
4. Applying the positive filter and its polar to a FULL fixed-charge
   parent gives the identity for a full-support source; it gives no gain.
   Random subframes and the averaged cell distribution are essential here.
5. A global spectral filter on m source blocks generally has exp(-mD)
   rank fraction. This proposal only promises polynomial access for
   t=O(log k) mesoblocks and must preserve the averaging identity across
   many such mesoblocks.
6. The fixed-shared-program and table-acquisition model must be explicit.
   Quantum offline estimation is not polynomial classical simulation.
7. No spectral-gap promise is supplied at bin boundaries. The smooth
   functions must be approximated uniformly; hard exact reflections
   cannot replace them silently.

Analytic status: NEW CANDIDATE, NOT INDEPENDENTLY REVIEWED. Finite scalar
end-to-end guards and total code-constructor cost ledger are unfinished.
Actual-H hardness is NOT proved. Physical validation NOT_PERFORMED;
practical advantage NOT_ESTABLISHED; priority UNKNOWN; mission
NOT_ACHIEVED. Frozen quartic results remain unchanged.
