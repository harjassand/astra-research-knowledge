# A native finite-word resource loader and a fixed-resource capacity reduction

23 October 2026, w64. Independent construction after root identified the missing legal bath-preparation interface. This packet does NOT assume direct bath control, a freely implemented inverse gate, a fresh bath, an external forward classical wire, a source-correlated initializer, or successful-branch-only accounting. It concerns ordinary decoded-message fidelity with the final bath and discarded resource traced. Whole-resource return, a sharp capacity value, efficient compilation, physical affordability and mathematical priority are NOT claimed. Fresh criticism and finite native checks are PENDING at this proof freeze.

## 1. Device, permissions and precise claim

The unchanged device is

    E=C^2_seed tensor F(C^2),
    U=[[J,S1,S2],[S1*,0,0],[S2*,0,0]],
    V_beta=alpha U+i beta I, alpha=sqrt(1-beta^2).

J flips the two seeds at the empty word and vanishes elsewhere; S_j prepends color j. All forward transmissions are actual qutrit calls A->device->B. Alice and Bob have arbitrary local trace-preserving operations, local ancillas, initial A:B preshares independent of the bath, and Bob->Alice classical/quantum communication. The fresh logical Phi_RM is independent of the WHOLE initial resource and remains untouched throughout preprocessing. All branches, calls and outcomes are charged. No terminal bath/resource-return condition is imposed.

Fix 0<beta<1. A fixed normal state eta_(E L_A L_B), independent of the communication horizon, may contain arbitrary bath/laboratory entanglement and may be a marginal of an inaccessible G. For every fixed target approximation tolerance, the construction below prepares a finite approximation to the operationally relevant sector of eta, up to an explicit sector equivalence, starting with ANY fixed normal independent bath initializer tau_E. The finite preparation cost can depend arbitrarily badly on eta,beta,tolerance. Its unknown-tail reset error vanishes pointwise as its initial reset length tends to infinity. It is NOT uniform over arbitrary normal tau, nor over horizon-dependent target eta_N.

Consequently, in the SAME preshare/backward-communication model, every rate achievable with any FIXED normal eta is achievable from any FIXED normal independent bath tau_E, with o(N) additional forward calls. The comparison is about existence of reliable code sequences and decoded fidelity; it is not exact simulation with the original external purifier returned. The reverse capacity inequality holds because an independent initializer is itself an allowed fixed bath/labs resource. Thus taking a supremum over fixed normal bath/lab resources does not enlarge that independent-initializer capacity. N-dependent bath correlations remain outside this conclusion.

The statement assumes the same abstract ability to specify known finite local resource states and operations as the original capacity model. It does not acquire a finite classical description of an arbitrary unknown normal eta, an efficient source compiler, or laboratory bath controls.

## 2. Conserved seed sector and why coherence is operationally irrelevant

Let X be seed flip on the entire bath, not merely at the root. Then [U,I_A tensor X]=[V_beta,I_A tensor X]=0. Every laboratory operation and every communication wire acts trivially on this bath X. Hence every complete adaptive-protocol Kraus operator is block diagonal in its two spectral sectors x=+1,-1.

For an arbitrary initial eta, the final R:Bob state, including all recorded outcomes, is the sum of the two diagonal-sector contributions. The offdiagonal |+><-| bath blocks have zero partial trace over the final seed, regardless of laboratory registers, feedback or sector-dependent output records. Thus initial seed coherence can be dephased without changing this operational final state. This is NOT a claim of whole-resource return or trace-norm equivalence before discarding the bath.

Write p_x eta_x=P_x eta P_x, normalized when p_x>0. For a fixed eta and a reliable code sequence, decoded Bell fidelity is sum_x p_x F_(N,x). Fixed positive p_x and F_N->1 imply F_(N,x)->1 in each occupied sector. It therefore suffices to simulate one chosen occupied eta_x0. The weights must be fixed with N for this implication.

## 3. Exact sector equivalence without implementing an inverse physical gate

Within sector x, identify E with binary Fock space and let P=(-1)^length. The interactions satisfy

    U_-=-P U_+ P,
    V_(beta,-)=-P overline(V_(beta,+)) P.            (L1)

Here the bar is matrix conjugation in the fixed word/port basis; U_+ is real. Equation (L1) is an identity of the TWO EXISTING physical sectors, not an instruction to implement conjugation or inversion of an unknown gate.

Given a known protocol in sector+, construct a sector- protocol by conjugating every LOCAL Kraus matrix and its known initial resource, and putting the real bath parity P on the initial bath state. No antiunitary is applied to the unknown message. Conjugating a known Kraus family produces another legal CPTP family: K becomes overline(K). Identity quantum wires and classical control are real. In the circuit expansion, the neighboring bath P factors in (L1) cancel through every local operation; the remaining final P disappears on tracing the bath. The resulting decoded channel is the complex-conjugate channel, whose Bell fidelity against the real Phi_RM is the same. The same argument works in the other direction.

In particular, a prepared sector- resource P overline(eta_+) P with conjugated local operations has the same communication performance as eta_+ in sector+. This does not use a physical inverse per body call, add per-call overhead, or conjugate an unknown input state. It is a known-program transformation of a CPTP protocol. It covers arbitrary adaptive classical/quantum Bob->Alice wires by the same Kraus expansion.

## 4. Pointwise native root reset

Send vacuum |0> at every reset call and discard its output. The bath Kraus operators are

    K0=alpha J+i beta I,
    Kj=alpha S_j*, j=1,2.

With a=alpha^2 and b=beta^2, the depth probabilities obey

    p'_0=p_0+a p_1,
    p'_h=b p_h+a p_(h+1), h>=1.

This holds for coherent initial bath states too: shell traces remove cross-depth terms. After T calls, the nonroot probability is exactly

    epsilon_T(tau)=sum_(h>=1) p_h(tau)
                       Pr[Binomial(T,a)<h].         (L2)

For EVERY fixed normal tau this tends to zero by dominated convergence, without assuming finite mean depth or entropy. The bath state is within unhalved trace distance 2sqrt(epsilon_T) of its normalized root compression. This first reset is pointwise, never uniform over all normal states: a bath initially deeper than T defeats any such bound.

Within a known fixed sector x the root is one-dimensional. For an input supported at depths<=H the reset tail is at most Pr[Binomial(T,a)<H]. A fresh unused preparation program is independent of all previous failed programs/bath records, so only the reset bath marginal is needed between retries. Prior used programs and outputs are discarded. Its distance to root x is at most 2sqrt(this tail). All resets are actual forward calls on the same bath.

## 5. A finite-cost QND sector probe for 0<beta<1

From root sector x, send the KNOWN input |1,0> in two calls. The exact joint port/bath state is

    [a|01>+(-b+i alpha beta x)|10>] tensor |root,x>
       +i alpha beta |00> tensor |1,x>.             (L3)

Bob measures the Hermitian observable

    Y=i(|01><10|-|10><01|),

with outcomes+1,-1,0. Its expectation is

    E_x Y=x m_beta, m_beta=2 a^(3/2) beta>0.         (L4)

A +/- outcome leaves the bath EXACTLY at root. The zero outcome leaves it EXACTLY at depth1, known color1. In that case vacuum calls, with measured outputs, return it to root at the first colored output. Each attempt succeeds with probability a; a zero output leaves depth1. Capping this recovery at r calls has failure probability b^r. Bob sends the measured outcomes backward to Alice, using the allowed wire.

Conditioned on sector x and successful recoveries, k probes give independent bounded samples with mean x m_beta, because each probe starts at root. Hoeffding gives a wrong-sign probability at most exp(-k m_beta^2/2). Equivalently couple the capped experiment to its unlimited-reset ideal; the total wrong/abort probability is at most

    exp(-k m_beta^2/2)+k b^r.                        (L5)

This remains valid for a mixed/coherent seed because output statistics depend only on its diagonal sector mixture (section2). The maximum additional forward cost is k(2+r). Taking k=O(a^-3 beta^-2 log(1/epsilon)) and r=O(log(k/epsilon)/|log b|) makes (L5) small for every fixed0<beta<1. It is not a cost uniform at beta0 or beta1.

## 6. Exact finite-word loading in a known sector

Let a normalized pure target |chi>_(E L_A L_B F) have bath support on word lengths<=H in sector x. F may purify a mixed desired resource and stays in Alice's lab. Expand

    |chi>=sum_(|w|<=H)|w,x> tensor |chi_w>.

For w=(w1,...,wk), define the orthogonal H-port program word

    pad_H(w)=0^(H-k) wk ... w1.

Conditioning on output0 on EVERY port, the unchanged physical device acts exactly as

    <0^H|W_beta|pad_H(w),root,x>
       =gamma_w |w,x>,
    gamma_w=alpha^k (alpha x+i beta)^(H-k).          (L6)

All zero inputs occur before pushes in each program basis word. At root their vacuum-output coefficient is alpha x+i beta, of modulus1. A colored input with vacuum output applies alpha S_j, and the reversed input order produces the requested top-first word. Every gamma_w is nonzero for beta<1.

Prepare the known normalized laboratory program

    |prog>=(1/sqrt Z)sum_w gamma_w^-1
                     |pad_H(w)> tensor |chi_w>,
    Z=sum_w a^(-|w|)||chi_w||^2.                    (L7)

Its all-vacuum output event has probability exactly1/Z>=a^H and prepares chi EXACTLY, including all desired bath/lab coherence and entanglement. Finite A:B preshares may supply the Bob part of this known program; their dimension and number are charged. Their marginal need not already equal the final Bob marginal: the heralding event is a forward device event. The fresh logical M is untouched and independent of every program, event and target state.

This event alone is NOT a legal successful-branch-only protocol. Use at most R independent supplied program copies. On failure, discard the used program registers and outputs, reset the same bath with T_H vacuum calls, then try the next copy. With ideal root resets the probability all R copies fail is at most (1-a^H)^R. Real finite resets add at most

    2 R sqrt(Pr[Binomial(T_H,a)<H])                 (L8)

to unhalved trace error by a hybrid comparison. Every failed attempt has bath support<=H when starting at root, since each of its H calls changes depth by at most1. The successful bath is left alone while the body protocol begins. The maximum loader cost is R(H+T_H) forward calls, plus the finite supplied programs. A cap failure is retained and leads to a default decoded output; it is never dropped from the fidelity.

The original normal target eta_x is approximated in trace norm by finite bath-word AND finite local-register support. Normal states on separable tensor Hilbert spaces admit such normalized finite compressions. Purifying that finite state in F gives the preceding chi. No inaccessible external G needs to be reproduced for an objective that traces G. A requirement to restore the original G correlations would invalidate this reduction.

## 7. Fixed total call count and the asymptotic reduction

For any target tolerance epsilon>0 choose a finite approximation, k,r,R,T_H so their errors in sections5--6 and target approximation sum to at most epsilon (constants can be made conservatively smaller). Let C_epsilon be the resulting FINITE worst-case calls, not including the first unknown-tail reset. Include in a finite cost ledger all supplied program copies, local dimensions/descriptions and requested precision; no polynomial or physical bound is asserted.

For a body code of N calls, choose a slowly increasing approximation index m(N) with epsilon_m->0 and C_(epsilon_m)=o(N). This is an ordinary diagonal choice because every fixed m has finite cost. For example require all known finite per-m call/resource description costs to be <=sqrt(N), and increase m only when that condition holds. Use T0(N)=floor(sqrt(N)) initial vacuum reset calls. Equation(L2) makes its error vanish for every fixed independent normal tau, even if tau has infinite mean depth. The same reset schedule is independent of tau.

Keep the fresh logical Bell pair untouched during ALL preprocessing. After prep success, run the selected sector-transformed body code. Trace-norm contractivity bounds its output error by the preparation error independently of N and every adaptive operation. On prep failure output a default state. The resulting Bell fidelity tends to1 whenever the original body fidelity does.

Random early success does not provide a timing carrier. Its call index is determined before touching the fresh M. To enforce EXACTLY N+T0+C_epsilon forward calls on every branch, run the body immediately after success, then send a fixed dummy input for all unused budget calls AFTER Bob has decoded and retained the message. These final calls act only on unused ports and the bath and cannot change the retained R:Bob marginal. Failure branches also fill the complete budget. There is no external forward announcement; Bob directly observes all heralding flags, and the classical coordination travels backward.

The total call count is N+o(N), so the rate is unchanged. The construction therefore establishes the fixed-normal-resource capacity reduction in section1, subject to the explicit permissions and final-discard objective. It does not identify that capacity, show a positive-beta rate beyond inherited codes, prove a strong converse, or treat arbitrary N-dependent eta_N. If eta_N has an explicitly supplied finite approximation with preparation cost o(N), the same conditional reduction applies; otherwise no conclusion follows.

## 8. Endpoints and costs/boundaries

At beta0 the sector probe is unnecessary. In(L6), gamma_w=x^(H-|w|), so using a single fixed program prepared for x=+ loads, in unknown sector-, the parity-transformed target P chi, up to global phase. Equation(L1) at beta0 has no complex conjugation requirement for the real device, and the SAME local body operations give the identical output after bath trace. A fixed-resource reduction follows similarly; separately the already audited all-resource upper and inherited Dyck lower give beta0 value3/2. No new beta0 capacity theorem is claimed. At beta1 V=iI and forward communication is directly the identity qutrit, so the endpoint capacity is log2(3) in the present model; the loader itself is not used.

For0<beta<1, costs may be exponential in word cutoff H and arbitrarily worse in target approximation. The boundR>=a^-H log(1/epsilon) is a worst-case scaling, seed discrimination cost diverges as beta->0 or1, and vacuum reset has no uniform unknown-normal-tail rate. Finite program precision, preparation energy, spatial bath implementation, reset heat and efficient local compilation remain UNACQUIRED/UNKNOWN. Supplied preshares/programs must be recorded rather than called free. If the comparison class forbids initial A:B preshares or backward communication, this theorem as stated does NOT establish equivalence to that class.

Primary literature and relevant corpus priority checks, actual native finite tests and independent fresh criticism remain to be added in separate files without changing this frozen proof. Generic normal compression, CP conjugation, Hoeffding and asymptotic diagonalization are established tools. Proposed device-specific initialization interface novelty UNKNOWN. Physical validation NOT_PERFORMED; operational efficiency/advantage NOT_ESTABLISHED; mission NOT_ACHIEVED.
