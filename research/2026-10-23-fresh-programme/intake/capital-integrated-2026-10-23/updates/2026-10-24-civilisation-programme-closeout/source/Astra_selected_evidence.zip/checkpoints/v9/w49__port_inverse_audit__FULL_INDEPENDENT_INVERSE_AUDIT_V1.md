# Full fresh audit of the root-compatible port-phase inverse

23 October 2026, W49. Read the complete sources before issuing a verdict:

- W64 `EXACT_PORT_PHASE_INVERSE_V1.md`, SHA256
  `06cf56a3a937181822c8d4d04c36f832f2d3d11a452ae0ad0bb652848fbe5eec`.
- `COMPOSITE_CONTROL_CONVENTIONS.md`, SHA256
  `d19b7491bf5b00aa1c807b1e8c67db4ce7c270069d73d6d31afe9732d2f452e8`.
- All entries of `FROZEN_COMPOSITE_PACKET.json` were read or inspected,
  and their byte counts and hashes verified. The producer and its finite
  data are evidence only for their finite simulated scope.
- The separate restricted-minimality source, read after W64 froze it:
  `RESTRICTED_PHASE_QUERY_MINIMALITY_V1.md`, SHA256
  `bfbdd68e2a17c2d9ad9305dba8f707ed9709514920e70f9e3e8aae1c6de7a5a8`.

These are in W64's `coherent_resource_factory/` directory. I also reopened
the original full device definition, the complete relevant factory proof
`c544c1a9...` with mandatory norm/phase clarification `75c36c3a...`, and
the stronger controlling opposite-download source `f64ed77a...`. The
source corpus HEAD is still `e606bfc587c76bdcae8b8fa3ec33e721efa2fbac`.

**Verdict:** no blocking defect found in the full exact inverse, its
known-sector infinite-bath/reference scope, odd-power extension, counted
physical returns, or rational-parameter error bound. The elementary echo
notation correction in the conventions is necessary and sufficient;
P1--P15 already use the correct D gates. The restricted query-minimality
claim also reconstructs, including the essential two-call exception at
beta=1/2. This is an inverse CONTROL capability. It is not the strongest
uploader: the opposite-download construction uses only T forward native
calls and zero backward returns for that task. No broader optimality,
novelty, calibrated apparatus or physical advantage is inferred.

## 1. The actual full Hilbert-space decomposition

The pinned U prepends/pops colors and flips the seed only on vacuum.
Let F exchange the two entire seed trees. Both U and every local port
phase commute with F. In a fixed KNOWN eigenvalue x of F, the port/bath
space has the orthogonal decomposition

    H_x = span{|0,empty;x>}
          direct_sum_(j=1,2; finite w)
             span{|0,jw;x>, |j,w;x>}.

Every colored-port vector occurs once as the second vector of a pair;
every nonempty vacuum-port vector occurs once as the first vector of a
pair; only the vacuum root is unmatched. Thus the decomposition is
complete, not a selected invariant orbit. In this basis

    U_pair = [[0,1],[1,0]],
    V_pair = [[i beta,alpha],[alpha,i beta]],
    D_pair(z)=diag(z,1),
    V_root=lambda=alpha x+i beta, D_root(z)=z.

The same pair matrix works for BOTH colors j and every word. A common
pair/root identity therefore extends by orthogonal direct sum to the
entire infinite known sector. All operators have norm one, so equality
on the algebraic basis core extends to its Hilbert completion. Tensoring
an arbitrary reference preserves this identity and its operator norm.
There is no cutoff, depth moment, finite entropy or product-state premise
for the inverse itself. Its input can have arbitrary port/bath/reference
entanglement supported in this sector.

The KNOWN sector is essential. It is not equivalent to a known bath
word or a known pure bath; conversely an unresolved superposition or
unmeasured mixture of sectors is not silently covered by one compiled
pulse. The factory's stronger known-root promise is a separate premise.

## 2. Independent signed-parameter construction

Allow real alpha,beta with `alpha^2+beta^2=1`, alpha nonzero,
`0<beta^2<=1/2`. Write `a=alpha^2`, `b=beta^2`,
`lambda=alpha x+i beta`, `g=lambda^-4`, and `w=(1-g)/a`.
Direct expansion, including all signs, gives

    w=8b+4i x beta(a-b)/alpha,
    |w|=4|beta|/|alpha|,
    Re(w)/|w|=2|alpha beta|.

An equivalent stable phase normal form is

    e=w/|w|=2|alpha beta|+i x sign(alpha beta)(a-b).

It has modulus one because `4ab+(a-b)^2=1`. This normal form is useful
for finite diagnostics near beta zero; it does not change the theorem.

Put `c=2|beta|^3/|alpha|`. The radicand in P1 is nonnegative exactly
when `4b^3<=1-b`. Its difference factors as

    4b^3+b-1=(2b-1)(2b^2+b+1),

so the exact positive-b threshold is b=1/2. With

    z1=e(c+i sqrt(1-c^2)), z2=e(c-i sqrt(1-c^2)),

both gates are unit phases, and

    (1+z1)(1+z2)=2e[c+Re(e)]=e|w|=w.

Here `c+Re(e)=2|beta|/|alpha|`; no positivity of alpha or beta was
used. At beta zero the separate one-call involution branch is correct.

## 3. Pair identity, common phase, and the ROOT check

For `C=V D(z2) V D(z1) V` on a pair, enumerate the four paths from
colored input to colored output. Their sum is

    C11=(i beta)^3+i beta a(z1+z2+z1z2)
       =i beta[a(1+z1)(1+z2)-1]
       =-i beta g.

Because C is unitary, its off-diagonal entries both have modulus
`|alpha|`. Thus `zL=g alpha/C01` and `zR=g alpha/C10` are legal unit
phases. The endpoint gates fix both off-diagonal entries to g alpha,
leave the lower-right entry at `-i beta g`, and row orthogonality fixes
the upper-left entry to `-i beta g`. Hence the pair word is `g V*`.
This also proves that no division by a vanishing off-diagonal amplitude
was hidden in P5.

Now retain the root instead of fitting it separately. Each pair V has
determinant -1. Therefore

    det[D(zL) C D(zR)] = -zL z2 z1 zR = -g^2,
    product of ALL four vacuum phases = g^2.

The ACTUAL root output of the SAME sequence is consequently

    lambda^3 product(z's)=lambda^3 g^2
                        =lambda^-5=g lambda*.

This is exactly the pair's g, not a separately selected root phase.
It is the load-bearing identity. The chronological physical order is

    D(zR), V, D(z1), V, D(z2), V, D(zL).

Every D is precisely `diag(z,1,1)` on the local qutrit. The informal
echo symbol in the first source is corrected by the mandatory conventions:
`E_pi=diag(i,-i,-i)=-i D(-1)`, whereas defined `D(i)=diag(i,1,1)`.
Neither that informal echo nor an uncharged bath phase is used in P1--P15.

A useful deliberately invalid control confirms the issue. On every
matched pair,

    D(-1) V D(-1) = -V*.

On the root, however, the left side is lambda while the proposed right
side is `-lambda*`. Their difference has magnitude `2|alpha|`. Pair-only
verification would therefore give a false full-space inverse. The actual
construction avoids exactly this defect.

## 4. Odd powers cover every fixed beta below one

For the original alpha positive and beta nonnegative, let
`theta=arcsin beta`, `gamma=arccos beta`. The two U eigenvalues of V
are `exp(i theta)` and `-exp(-i theta)`. For ODD m this gives exactly

    V^m=cos(m theta) U+i sin(m theta) I.

For beta squared greater than one half, choose the first positive odd
m with `m gamma>=pi/4`. Its predecessor differs by two, so

    pi/4 <= m gamma < pi/4+2gamma < 3pi/4,
    m <= pi/(4gamma)+2.

Consequently `beta_m^2=cos^2(m gamma)<=1/2` and
`|alpha_m|>=1/sqrt(2)`. The signed lemma applies without another root
assumption, since its root eigenvalue is precisely `lambda^m`.
Replacing each of the lemma's three W calls by m native V calls, then
executing m-1 further V calls, gives

    g_m (V^m)* V^(m-1) = g_m V*,
    n_inv=3m+(m-1)=4m-1.

Whether the extra V powers are written on the left or right is harmless
for the ideal equality because they commute with `(V^m)*`. The literal
chronological implementation and the telescoping error count still have
to use one consistent word; the conventions/producer do so.

If beta_m is EXACTLY zero, `V^m` is an involution and `V^(2m-1)=V*`
needs only `2m-1` calls. The numerical producer uses an explicitly
qualified near-zero shortcut and retains its coefficient error; this
is not an exact-zero algebraic proof. At beta zero, one call is exact.
At beta one, V is `iI` and its inverse is a known global scalar with
zero interactions, while bath writing is impossible.

For each FIXED beta below one the count is finite and independent of
requested accuracy. Its sufficient upper bound grows as `O(1/alpha)`
near beta one; no uniform endpoint bound is established. No query-minimum
claim for this high-beta construction follows from its sufficient count.

## 5. Returns, reference scope and precision costs

Alice must get the SAME unknown qutrit back after every forward use,
including the final use if the output port is to be back at Alice for
the terminal phase/control composition. The sufficient counts are
exactly `n_inv` forward native calls and `n_inv` coherent quantum qutrit
returns. There are four local vacuum phases per non-shortcut block,
plus classical compilation, storage and local gates. These returns can
carry arbitrary bath/reference entanglement. Classical flag feedback
cannot substitute for them in this implementation.

Time homogeneity of the specified native V and no extra uncontrolled
bath dynamics between the prescribed calls are part of the mathematical
device/control interface. Direct bath control, physical controlled V,
postselection, negative-time evolution and resetting the bath are absent.

If the four phase gate errors sum to eta in operator norm, product
telescoping adds at most eta, uniformly in the full bath/reference.
For a chosen rational beta_tilde, let
`kappa=||V(beta)-V(beta_tilde)||`. Evaluate the SAME compiled word with
actual and design gates: its n_inv query changes cost at most
`n_inv kappa`. The target adjoints differ by at most kappa. Therefore

    ||M_actual-g_tilde V(beta)*|| <= (n_inv+1)kappa+eta.

The phase in this comparison is the single DESIGNED global phase;
it is not fitted to each input, bath depth or reference branch. The
unhalved diamond error for the induced unitary channels is at most twice
this operator bound. Additional imperfect physical gates and backward
returns are separately telescoped by their actual invocation counts.

Known beta means certified finite numerical access, not uncharged unknown
parameter acquisition. For rational beta_tilde, odd `sin(m arcsin beta_tilde)`
is a rational polynomial in beta_tilde; the corresponding cosine is a
rational polynomial times `sqrt(1-beta_tilde^2)`. Exact tests and algebraic
square-root/phase evaluation are therefore available with counted finite
arithmetic. In particular an arbitrary computable-real equality oracle
is unnecessary. On any fixed compact interval below one, the required
query count is bounded uniformly as precision improves; parameter and
phase bit counts grow logarithmically in inverse target accuracy with
additional endpoint conditioning. Unknown-beta acquisition is a separate
packet and is NOT certified by this audit.

## 6. Factory substitution, and the stronger uploader comparator

The complete factory proof with its mandatory norm/phase conventions
uses the same T at every input depth. Its key identity is
`S*J=A*A`, where `A` is the unnormalized root component of coherent
vacuum download and `A*A>=(1-tau)I`. Thus its uniform channel estimate
is based on an operator inequality, not normalization of a successful
branch or a basis-average observation. The source's
`tau=Pr[Bin(T,1-beta^2)<H]` includes every root-arrival failure.

Replacing each of the T inverse gates by the exact pulse multiplies the
ENTIRE ideal isometry by the same `g_m^T`. There is no length-dependent
phase, since T is fixed, no word length is measured and the conserved
sector never changes. Approximate inverses at error delta add `T delta`
in operator norm. Together with local-circuit error and the UNHALVED
JOINT product-root promise, this reconstructs P14 and P15:

    diamond error <=2sqrt(2tau)+2T delta+2e_loc+epsilon_root,
    forward calls = quantum returns = T n_inv.

The factory does not restore a replaced old bath/purifier or arbitrary
seed coherence. Target state preparation and Bob's local resource
distribution remain separate costs, possibly exponential for an
unstructured target. This audit does not turn a supplied circuit into
acquired experimental information.

The separate controlling opposite-download construction is stronger for
UPLOAD. Simulate `V_H*` only in the LOCAL download. The mathematical
reverse of its physical counterpart is then a reverse-order product of
actual FORWARD V gates, each port used once. The same root-effect and
overlap identity apply, with conjugated local root phase consistently
on both bra and ket sides. Hence only T forward physical calls are
needed, with zero quantum returns. The inverse capability remains valid,
but neither it nor the recurrence construction is a best-uploader result.
The generic control/upload priority claims are outside this algebra audit;
special-case historical priority remains UNKNOWN.

## 7. Separate restricted query minimality

The newly frozen `bfbdd68e...` source permits ONLY deterministic words
`D(z_n)V...VD(z_0)`, with no ancillas, port mixing, measurements,
adaptive strategies or supplied special bath resources. Let
`Z=product z_j`. Pair determinants and the actual root force

    (-1)^n Z=-g^2, lambda^n Z=g lambda*,
    g=(-1)^(n+1)lambda^[-(n+1)].

Zero queries cannot supply the nonzero alpha off-diagonal pair entry.
With one query, endpoint phases leave the colored diagonal at i beta,
so matching forces g=-1. The root/determinant relation then requires
`lambda^2=-1`, impossible for `0<beta<1` because
`Im(lambda^2)=2alpha x beta` is nonzero.

For two queries the one internal phase z must satisfy

    a z-b=i beta lambda^-3,
    z=4b+i x(beta/alpha)(1-4b),
    |z|^2-1=(8b^2+2b-1)/(1-b)
            =(4b-1)(2b+1)/(1-b).

Only b=1/4 is possible. It is sufficient: `V^3=iI` then gives
`V^2=iV*` on the ENTIRE native space, even without knowing the sector.
Thus in this restricted class the minimum is two calls at beta=1/2,
and three for every other `0<beta^2<=1/2`. The high-beta result is only
a lower bound of three together with the sufficient odd-power upper
bound. No optimality against larger local-control/resource classes or
against upload protocols is implied. No blocking defect was found in
this separate exact restricted statement.

## 8. Own independent diagnostics and limits

Own `check_global_port_inverse.py` imports no peer code or data. It builds
the literal TWO-SEED U with its actual root seed flip, both colors and
all input columns in the selected seed sector at depths up to B. The
finite completion sits one level beyond the complete input support;
total port charge plus depth makes its colored-boundary rows unreachable.
Every call explicitly checks zero boundary occupation. The operator
residual is computed against the prescribed common g, never by fitting
independent root, word, sector or reference phases.

Passed: 100 signed lemma cases and 80 complete-column native cases with
B=0,1,2,3, both known sectors, beta from zero through .9999, threshold
and near-involution cases. Maximum operator residual was `4.124e-13`;
boundary mass was exactly zero. Six parameter and six local-phase tests
obeyed the respective telescoping bounds. The pair-only echo and wrong
sector controls fail by large retained root residuals. Exact Fraction
checks retain the two-query modulus factorization and exceptional b=1/4.
Python runtime was about 0.043 seconds using preinstalled NumPy2.5.3;
peak memory and total inference/review cost were not measured.

These are finite mathematical checks, not all-depth inference. The
infinite-bath and arbitrary-reference result rests on the analytic
complete direct-sum identity above. No physical calls, backward quantum
transmissions, local phase hardware, calibration or state preparation
were acquired/executed. Internal proof reconstruction passed; external
acceptance UNKNOWN; special-case novelty UNKNOWN; physical validation
NOT_PERFORMED; practical advantage NOT_ESTABLISHED; mission NOT_ACHIEVED.
