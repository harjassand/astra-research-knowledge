# Independent audit of the collective trilinear number-pump receiver

Worker w50; 23 October 2026. No descendants. This receipt forms its view
from the frozen mathematical targets, direct reconstruction, primary
sources and its own controls. No producer checker is imported.

The principal target is `OWNER_TRILINEAR_NUMBER_PUMP_RECEIVER.md`,
SHA256 `43e2453209beb44da6df8ad668b971c77589b296b4f295d8adf0cde95bdd4649`.
The separate engineered-unitary target is
`OWNER_FINITE_NUMBER_PUMP_DILATION.md`, SHA256
`97804cb35b853318f470bb67b8f34b2f973ff401a5cce626a95b1882e08286df`.
Those bytes are snapshots, not revised owner proofs. The inherited GE
sector receiver and finite readout are covered by my earlier immutable
`global_energy_audit/AUDIT.md`, SHA256
`a87669a2fa366ba45273fe218f85bd03d9f7f815915c6c6733e9071b61cd237e`,
and its pinned source hashes. The changed pump interaction requires this
new audit; the earlier receipt did not certify it.

## Verdict and exact statement

PASS for both stated ideal mathematical models. I find no load-bearing
gap in the finite-chain construction, original explicit error constant,
unconditional receiver composition, actual-residual quantifier, mean
depletion, or pump non-return. The minor literature qualification below
does not enter the proof. This is not a claim of priority, an acquired
Fock-pump device, affordable decoder, full optical-channel approximation,
cyclic work extraction, or advantage over the stronger both-vacuum
baseline.

Let N>=1, M=floor(EN), G=cosh(tau)^2>1, H=sinh(tau)^2, and let A be
arbitrary within its total-number cap, with independent B vacuum and an
independent SHARED pump in |L>. The actual source extension is arbitrary.
With the supplied equal-coupling, common-phase, lossless trilinear
Hamiltonian and time tau/(chi sqrt L), the old GE receiver satisfies

    q_N <= min(1,Q_N+epsilon_N),
    epsilon_N = 2tau (N+M)^2 sqrt[C(H)]/L,
    C(H) = 24H^4+48H^3+28H^2+4H.

Here Q_N is exactly the inherited three-term GE bound, not a new bound
on an unmeasured optical channel. Every receiver branch has logical
rank J_N=2^floor(Nr/ln2), for any fixed 0<r<lnG and sufficiently large N.
The unconditional actual whole output obeys half trace distance

    d(Omega,Phi_(J_N) tensor Omega_actual_residual) <= min(1,2sqrt(q_N)).

The residual includes the pump, old source, seed/readout purifiers,
instrument remnants and all untouched references. The earlier separate
rank-one projection improvement also gives min(1,sqrt(q_N)+q_N), but
that improvement is not needed for the target's stated inequality.
L=ceil(N^(2+delta)), delta>0, is sufficient for epsilon_N=O(N^-delta).
No necessary scaling is claimed by the owner theorem.

The engineered unitary instead has L=O(N), a pure degenerate flag, and
the same GE bound with no chain approximation error. It is a different
supplied interaction, obtained by energy-sector unitary completion.

## 1. Self-adjoint dynamics and exact collective chains

With finitely many optical modes and one pump oscillator, each eigenspace
of N_C+N_D+2N_P is finite dimensional. The interaction
i hbar chi(P K_+ - P^* K_-) is Hermitian on each eigenspace and preserves
it. Its finite-matrix direct sum is self-adjoint on its natural square-
summability domain, and the finite-energy algebraic span is a core.
Consequently the claimed unitary and its exact energy preservation are
well defined. This is not an approximation by a truncated unstable
infinite Hamiltonian.

For input occupation j of total m, put s=N+m. Direct expansion of
(sum_i c_i^*d_i^*)^l yields

    K_+^l |j,0> / sqrt[l!(s)_l]
      = sum_(|a|=l) sqrt[ prod_i binom(j_i+a_i,a_i)
                              / binom(s+l-1,l) ] |j+a,a>.

The generating-function identity
prod_i (1-t)^(-j_i-1)=(1-t)^(-s) proves normalization.
For different j the coordinate difference C-D=j proves orthogonality,
even before imposing the same m. Thus this is the same GE sector
isometry V_(m,l), not merely the same output number law.

The canonical commutators give [K_-,K_+]=N+N_C+N_D. Since K_-|j,0>=0,
induction gives

    K_- K_+^l |j,0> = l(s+l-1) K_+^(l-1)|j,0>.

Together with normalization this proves both ladder coefficients
sqrt[(l+1)(s+l)] and sqrt[l(s+l-1)]. Combining them with
P|L-l>=sqrt(L-l)|L-l-1> gives the exact finite chain on
|l;j>|L-l>, 0<=l<=L. Its rescaled real antisymmetric generator B has
positive subdiagonal links

    b_l = sqrt[(l+1)(s+l)] sqrt(1-l/L), 0<=l<L.

In particular b_0=sqrt(s), and the missing boundary at l=L has the
correct zero coupling. The amplitude vector z_(s,L) is identical for
every j of the same m. The pump conditional on l is |L-l>, independent
of j. Linearity therefore proves the conditional optical map on
arbitrary within-sector source extensions, not just on diagonal inputs.
The receiver reads both total counts, so it also distinguishes m from
m+l and l when an input has cross-m coherences.

Matched passives preserve K_+ because sum_i U_ij conjugate(U_ik)=delta_jk.
They preserve K_- as well and leave P untouched. The whole trilinear
unitary therefore has exactly the inherited matched covariance on its
full declared input. A fresh independent output passive seed induces
the same block-scalar input Bell effect. One only averages the receiver
marginal to compute this effect; the seed purifier remains in the actual
residual and is not replaced by a fictitious twirled full source.

Separate Fock pumps are a decisive counterexample to removing the word
SHARED. For optical vacuum, their orthogonal pump states record every
individual added occupation. The available C:D state is a convex sum of
|a><a|_C tensor |a><a|_D and is separable. A common pump records only
total l, preserving the within-l superposition used by the receiver.

## 2. Duhamel comparison without an unbounded-domain shortcut

On the mathematical sequence space define

    x_l(u)=sqrt[binom(s+l-1,l)] tanh(u)^l sech(u)^s,
    a_l=sqrt[(l+1)(s+l)].

Its squared amplitudes sum to one, with the NB probability generating
function (1+H_u-H_u t)^(-s), H_u=sinh(u)^2. For 0<u<=tau,

    x_l'=[l/tanh(u) - (s+l)tanh(u)] x_l
         =a_(l-1)x_(l-1)-a_l x_(l+1).

The derivative at u=0 is obtained continuously (only the l=1 derivative
is nonzero). For any bounded u interval, polynomially weighted sequence
tails are dominated by an exponential tail with ratio strictly below
one; the finitely many terms near zero are continuous directly.
This proves strong l2 differentiability and a well-defined A x(u) in l2.
It is unnecessary to assume an unspecified unbounded-generator theorem.

Extend finite B by zero outside coordinates 0..L. It is bounded for each
fixed s,L. Differentiating e^((tau-u)B)x(u) in the Hilbert space and
integrating gives

    ||e^(tau B)e_0-x(tau)||_2
          <= integral_0^tau ||(B-A)x(u)||_2 du.

The labels past L belong only to this comparison space. They are not
unphysical negative pump-energy states asserted in the true dilation.

Write d_l=a_l-b_l, with b_l=0 for l>=L. For every l>=0,
0<=d_l<=(l/L)a_l. For l<L use 1-sqrt(1-t)<=t; for l>=L use l/L>=1.
Separating the two shifts and changing the index in the downward shift,

    ||(A-B)x||_2 <= (1/L) sqrt E[X^2(X+1)(s+X)]
             +(1/L) sqrt E[(X-1)^2 X(s+X-1) 1_(X>=1)]
          <= (2/L) sqrt E[X^2(X+1)(s+X)].

The index X-1 in the second term is essential; it is correct in TP11.
There is no operator norm bound on A in this argument.

## 3. Exact moment arithmetic and original constant

The generating function gives E(X falling k)=(s)_k H_u^k. For integer
s>=1, each s+j<=s(j+1), so (s)_k<=k!s^k. The Stirling coefficients for
powers 2,3,4 are respectively (1,1), (1,3,1), (1,7,6,1) in increasing
falling degree. It follows that

    EX^2 <= s^2(2H^2+H),
    EX^3 <= s^3(6H^3+6H^2+H),
    EX^4 <= s^4(24H^4+36H^3+14H^2+H).

Now X^2(X+1)(s+X)=sX^3+sX^2+X^4+X^3. Applying s>=1 gives
the coefficient vector (24,48,28,4) for H^4,H^3,H^2,H. Direct expansion
also gives C(H)=4H(H+1)(6H^2+6H+1). Integrate the constant bound over
0..tau and use s<=N+M to obtain the stated epsilon_N. All inequalities
are uniform in the unknown source, not inferred by extrapolating a
finite test. A bound above one is harmless but uninformative.

## 4. Why one complete bounded Bell effect suffices

For the canonical known reference mu_m, condition on both number counts.
The normalized state in every l is exactly the old GE state, with the
same fixed local code and Uhlmann decoder. Let f_(m,l) be the complete
receiver's Bell-failure coefficient in [0,1]. This includes the low-l,
overflow, invalid-relation and small-N defaults. It is not conditional
on eventual success.

For p_l=|z_l|^2, p_l^0=|x_l|^2, where z_l=0 past L,

    |sum_l (p_l-p_l^0) f_(m,l)|
       <= TV(p,p^0)
       <= sqrt(1-|<z,x>|^2)
       <= ||z-x||_2.

The last inequality holds for any two normalized vectors by
1-|a|^2 <= 2-2 Re a. It does not require choosing the ideal pump as the
actual purifier. This bound is charged once to the whole failure table;
adding it separately per l, per input mode, or again per GE tail would
be unnecessary.

The passive averaged input effect is F=sum_m f_m Pi_m by Schur's lemma,
with f_m computed from mu_m. The preceding comparison proves
0<=F<=(Q_N+epsilon_N)I_cap. Tensoring the identity on any actual source
extension proves the same Bell-failure bound there. Finally project the
ACTUAL full output with Phi_(J_N) tensor I: the good block is a Bell
factor times an actual residual state. Standard projection contraction
and residual contraction give 2sqrt(q); tracing the good/bad Bell blocks
more carefully gives the already separately proved sqrt(q)+q.
Neither argument replaces the actual source/pump/seed residual by the
canonical reference.

For a fixed common unknown tau in [tau_-,tau_+], use the same sector
receiver with lower/upper gain tails at the old endpoints and this
epsilon at tau_+. A common phase multiplies a fixed-l amplitude by a
scalar phase and does not change its normalized sector map. These
statements require a single common gain/phase and a seed independent
of the entire initial input/apparatus. Arbitrary per-mode errors, loss,
or unmodeled source-correlated controllers do not follow from them.

## 5. Exact depletion, entropy, and the returned-pump obstruction

For a finite chain y=sum_l l|z_l|^2 is differentiable and bounded. Its
derivative is at most 2sum_l b_l|z_l z_(l+1)|. Since
b_l<=sqrt[(s+l)(l+1)], Cauchy--Schwarz bounds this by

    2sqrt[(sum_(l=0)^(L-1)(s+l)|z_l|^2)
           (sum_(l=0)^(L-1)(l+1)|z_(l+1)|^2)]
        <=2sqrt[(s+y)y].

The initial zero causes no gap: replace y by y+e, e>0, to obtain
(asinh sqrt[(y+e)/s])'<=1, integrate, and let e decrease to zero.
Thus y(u)<=s sinh(u)^2. Averaging m proves E loss<=H(N+M), mean optical
photons<=M+2H(N+M), with hard optical cap M+2L. The mean bound is proved
directly; no continuity argument for an unbounded energy observable is
used. The owner's refusal to import the ideal exponential moment is
appropriate.

After tracing optics, D total number separates every l, so the pump is
diagonal in |L-l>, also for cross-m inputs and arbitrary purifiers.
The maximum entropy of a nonnegative-integer distribution of mean y is
g(y)=(y+1)ln(y+1)-yln y; this follows by nonnegative relative entropy
against the geometric law of mean y (the case y=0 is immediate).
Consequently S(P)<=g(H(N+M))=O(ln N).

For gamma_P proportional to exp(-2 beta hbar omega N_P), initial Fock
ordinary and max relative entropy are both
2 beta hbar omega L+ln Z_P. The exact ordinary marginal resource decrease
is 2 beta hbar omega E loss+S(P_final). Mutual information with the rest
is <=2S(P_final). These are entropy/mean identities, not a max-relative-
entropy subtraction or cyclic-work theorem. The full initial inventory
is O(N^(2+delta)) for the target choice, although mean depletion is O(N).

The l=0 indicator is a bounded event, so
p_zero<=G^-N+epsilon_N. Diagonality makes
d(P_final,|L><L|)=1-p_zero>=1-G^-N-epsilon_N. It tends to one when the
proved error vanishes, despite E loss/L tending to zero. This explicitly
rules out calling this pump an approximately returned free catalyst.

## 6. Independent audit of the engineered O(N)-inventory dilation

FP3 supplies only finitely many columns, one for each capped input j,
within the fixed finite-dimensional energy sector m+2L. Columns are
orthonormal: V_(m,l) preserves j, pump labels distinguish l, and the
orthogonal flag separates failure from l=0 success. All column energies
are exactly m+2L. Complete each finite energy-sector orthonormal family
to a basis; arbitrary remaining columns give a unitary on that sector.
Identity on all unassigned sectors produces an actual commuting-energy
unitary. This is valid, but grants arbitrary many-body control rather
than deriving it from the trilinear Hamiltonian.

On all 1<=l<=L the old sector maps and probabilities are exact. The
omitted ideal tail r_m is routed to the existing low-l product default,
with no renormalization or discarded probability. Its flag/pump are
retained. The source/pump extension quantifier follows from the same
positive-effect argument as above, not from a chosen purification.

A useful stronger observation, independently obtained in this audit:
when the SAME fixed logical product default is used on low-l and
overflow, the complete defaulted receiver has EXACTLY THE SAME Bell-
failure input effect under FP and under the ideal amplifier. Indeed
f_(m,0)=f_(m,l>L)=f_default, so

    sum_(l<=L) p_l f_(m,l) + r_m f_default

is the failure coefficient for both. The low-l coefficient in FP is
(p_0+r_m)f_default, and all other retained coefficients are unchanged.
The statement is equality of that receiver effect, not equality of
whole optical channels or their dilations. The stated GE bound follows
even if one uses only the owner's looser union bound.

Initial pump resource is O(N) for L=floor(lambda N), plus ln2 for the
initial pure degenerate flag. Mean depletion is <=H(N+M). No final
D_max subtraction follows. Input-cap routing can move an accepted
unknown occupation to fresh active vacuum registers while leaving old
registers vacuum; rejected occupations stay in old registers with active
vacuum and an orthogonal flag. This transfers rather than copies the
unknown state. It requires trusted pure resources and exact conditional
routing, and does not bound rejected old-source energy or reset cost.

## 7. Strong baseline and missing acquisition interfaces

With both optical inputs vacuum, the conditional common-pump optical
state is exactly Phi_(d_l), d_l=binom(N+l-1,l). For the trilinear model
its number law is TV-close to NB(N,1/G) when L/N^2 tends to infinity;
for FP it is the same law with its small tail routed to default.
The ideal law has l/N tending to H by its explicit mean and variance.
TV transfer preserves this convergence. Stirling then gives
ln d_l/N tending to g(H). For any rate below g(H), sectors with enough
rank can convert exactly to the fixed target; all other sectors retain
a product default. Cyclic-window instruments give the exact conversion
without an uncounted divisibility remainder. Thus both-vacuum gives a
strictly stronger rate g(H)>lnG under the same supplied pump model.
The excess is H ln[(1+H)/H]>0. No net gain is certified by the unknown-
input guarantee, and no useful recovered A-information task has yet
been proved.

The required independent Fock state, collective equal coupling, lossless
time control, global cap/fresh vacuum, complete optical storage, seed,
QND total-number readout, exponentially large number-sector instruments,
pure local degenerate ancillas, decoder/program precision and reset are
supplied or charged tasks. Energy conservation alone does not acquire
them. Local fixed-number instruments can preserve optical energy in
old carriers while writing degenerate Bell registers, but their purity
and relative-mode phase controls still cost resources. No hardware
operation was performed. No practical or mission advantage is inferred.

## 8. Primary comparison, exact priority remaining unknown

Full raw HTML and parsed text, acquisition URLs, byte counts and SHA256s
are retained in `primary/` and `PRIMARY_RECEIPTS.json`.

* Florez et al., [arXiv:1808.06136v1](https://arxiv.org/html/1808.06136v1),
  Section II Eqs(2)-(6), explicitly use the quantized trilinear
  Hamiltonian, terminating |L-l,l,l> basis and coupling
  (l+1)sqrt(L-l). Setting N=1,m=0 in the target gives exactly this
  familiar chain, up to a common phase and time normalization. Fock
  pumping and the finite chain are established prior mechanisms.
* Chinni--Quesada,
  [arXiv:2312.09239v2](https://arxiv.org/html/2312.09239v2), Sections I-II,
  study pump depletion and pump/system entanglement beyond parametric
  approximation; their emphasized initial pump is coherent, not this
  uniformly capped unknown-input Fock-chain theorem. Small fractional
  depletion alone does not imply the target approximation; the explicit
  comparison vector supplies it.
* [Niu et al.1603.06857v3](https://arxiv.org/html/1603.06857v3) propose
  interlaced nonlinear sign gates and varying crystal lengths; their
  ideal complete-conversion assertion permits those extra controls,
  while fixed-precision/same-crystal numerics have separate limits.
  [Olsen1707.09139v2](https://arxiv.org/html/1707.09139v2) distinguishes
  mean converted fraction from probability of complete conversion and
  tabulates the latter for uncontrolled SPDC. This is narrower than a
  direct refutation of the controlled Grover theorem. The owner's phrase
  that Olsen disputes the complete-conversion result should retain this
  qualification. Neither result is a premise of TP or FP.
* [Horodecki--Oppenheim1111.3834v2](https://arxiv.org/html/1111.3834v2)
  supplies established energy-preserving thermal-operation/athermal-store
  context. It does not make arbitrary energy-sector control free.
  The earlier GE receipt separately retains the full passive-symmetry,
  one-shot decoupling, amplifier entropy and channel-merging primaries.

This focused comparison establishes important existing ingredients,
not exact novelty of the evaluated composite bound. Exact priority,
external validation, physical availability, efficient implementation
and practical value remain UNKNOWN or NOT ACQUIRED as appropriate.

## 9. Independent finite controls and limits

`check_independent.py` imports only standard Python and NumPy. It reports
12,652 controls: 5,695 raised and 1,741 lowered bosonic coefficients;
345 exact rational sector normalizations; 696 exact factorial/ordinary
moment cases; 174 exact C(H) bounds; 225 diagonalized finite chains;
900 complete-effect TV transfers; 1,776 exact engineered energy
components; 136 exact defaulted-effect equalities; and 964 orthogonal
engineered column pairs. All PASS. Eighty-eight chain fixtures have
the displayed original norm bound below one.

Physical chains cover s=1,2,4,8,16, L=1,2,4,8,16,32,64,128,256 and five
positive times through 1.2. Their infinite ideal norm is handled using
normalization and exact finite overlap, not by silently discarding the
ideal tail. TV includes the whole ideal tail. Direct dense real-symmetric
Jacobi diagonalization, related by i^l phases to B, independently checks
normalization, the original error, mean, entropy, p_zero and bounded
effect transfer. The worst bosonic coefficient residual is below 9e-16;
engineered cross-column overlaps are exactly zero by sparse support.
Fractions supply exact combinatorial/moment/energy/effect arithmetic;
matrix and logarithmic comparisons are ordinary-double diagnostics,
not formal floating-point interval certificates. Universal conclusions
come from Sections 1-6, not the finite count.

Falsifiers include unequal uncharged mode couplings, a source-dependent
seed, omitted default mass, loss not covered by a declared bounded-effect
certificate, a purifier substitution, or claiming a full optical-channel
approximation from TP14. A net-gain claim must beat the stronger charged
both-vacuum baseline. The next useful steps are tighter mathematically
proved pump scaling and a finite-N acquired/certified control/decoder
interface, not a broadened success label.
