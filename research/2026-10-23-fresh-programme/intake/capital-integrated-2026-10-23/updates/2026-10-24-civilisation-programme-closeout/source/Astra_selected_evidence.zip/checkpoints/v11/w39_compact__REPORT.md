# Cold review: compact-prior forest lower and two-round star consequence

W39, 24 October 2026. Exact targets:

- `COMPACT_PRIOR_FOREST_LOWER.md`, SHA256
  `45421a5832a0453574a2251c9bb9c3c6c5ef6c7e7ae7e493236d69343aeaab2c`.
- `TWO_ROUND_STAR_COROLLARY.md`, SHA256
  `2220c100071a2f0009d9b671564dffd0a1d13b11a48ff9642014a9bb8f51e17e`.

**Verdict: no blocking defect found; independent full proof reconstruction
is positive in the exact stipulated sensing model.** This is a cold audit
relative to root/peer development and verdicts. I read those two sources
and the named primary Fisher-method paper before developing my proof and
new controls. I did not read/import/run the producer's replay, outputs,
report/result, earlier Gaussian lower proof or another review. The
pre-diagnostic derivation is frozen separately; the detailed all-size
reconstruction is `INDEPENDENT_RECONSTRUCTION.md`.

The lower proves, for even n>=4, independent Gaussian scalar noise,
nonadaptive complete nq-data acquisition, and a PATHWISE nominal row
budget sum_t x_ti^2<=B,

    q[pi^2+8a^2B/sigma^2]>=n(1-2delta)^2

whenever worst-case connectivity error on every fixed positive promised
forest is <=delta<1/2. The design can be randomized independently of the
unknown graph, controls/readout can have arbitrary precision, and the
decoder can have unlimited computation. The hidden-label prior precedes
design randomness. Giving its common hub/partition metadata AFTER design
commitment preserves the argument. The lower does not permit labels
chosen after seeing the design or metadata leaking the answer.

The critical proof steps reconstruct as follows:

- The compact cos-squared prior has endpoint density and first derivative
  zero, mean-zero a.e. score, and finite exact J=pi^2/a^2. Its unbounded
  endpoint score is square integrable. No positivity truncation or
  simultaneous n-weight event is required.
- Full-data IBP projects independent latent scores onto the score of
  Y=HW+Z. Minimizing their quadratic variance gives
  I_Y(v)<=v^T[sigma^2I+J^-1HH^T]^-1v for arbitrary rectangular or
  rank-deficient H. This comparison matrix is NOT identified with the
  actual non-Gaussian covariance/posterior.
- Eliminating every observed leaf in that comparison matrix gives the
  exact two-hub Schur blocks. The hidden-label ridge average uses the
  actual uniform(V,A) sampling law, pathwise ||s_i-s_h||^2<=4B, and
  d+1=n/2, producing (4q/n)(J+8B/sigma^2) with the stated constants.
- FTC, Tonelli and Cauchy--Schwarz along the location path give TV directly.
  No finite-shift KL bound is asserted. Algorithm risk is used only at
  absent edge0 and present edgea; intermediate t in(0,a) need not satisfy
  the edge-weight promise. Averaging common design/metadata and testing
  then prove the exact necessary inequality and fixed-input quantifier.

The separately frozen two-action source also reconstructs in its
specialized hidden-two-star promise. Positivity aligns first-action
currents, so acquired noisy hub ranking is correct with probability
>=1-delta/2 under its finite conditions. The second fresh reading at
the other acquired hub distinguishes0 from-a/2 with error<=delta/2.
Every possible outcome path uses row budget<=1/2, exactly2 complete
actions,2n scalar acquisitions and O(n) ideal arithmetic. It uses no
supplied hub/leaf labels. This is connectivity only.

Combining at the SAME allowed B=1/2, for fixed delta and fixed sufficiently
small r=sigma/a, gives for all sufficiently large even n

    q_nonadaptive>=n(1-2delta)^2/(pi^2+4/r^2),
    q_adaptive=2.

Thus the claimed linear full-action adaptivity separation survives this
stronger lower bound in the ideal model. It does not establish two-action
full support, general forest recovery, a vanishing-error fixed-noise
result, or a measured physical advantage.

My new no-import controls pass210 exact rectangular minima,735 full-data
Schur equalities,11916 hidden-metadata forms/27 exhaustive averages,
2262 ridge identities/84 averages,10656 first-action star cases,
63360 pathwise control-budget cases and360 second-action signals.
Separate floating quadrature checks36 actual full non-Gaussian
conditional-score points and12 Fisher/TV pairs; score residual<=1.74e-13
and scalar refinement<=1.99e-13. They are not interval-certified proofs
or measured data. Negative controls reject a missing ridge factor,
false non-Gaussian posterior substitution and ignored prior boundary terms.

The method is established Fisher-convolution/score-projection mathematics;
I reopened [Dembo--Cover--Thomas, Theorem13 and its matrix-version pointer](https://isl.stanford.edu/~cover/papers/transIT/1501demb.pdf).
That citation does not establish priority for this exact graph theorem.
No exhaustive source-method priority search or hardware acquisition was
performed. The upper grants global exact preparations and fixed-noise
full readout. It may need O(an) dynamic range and O(1/n) actual control
accuracy to retain its second-action signal under loading. Nominal B
does not price energy, time, impedance, sensor laws or resets.

All target and earlier worker/code verdict bytes remain unchanged.
Source/priority UNKNOWN; physical validation NOT_PERFORMED; practical
advantage UNKNOWN; mission NOT_ACHIEVED. A finite-port circuit-law audit
is the next separately assigned obligation, not covered by this verdict.

