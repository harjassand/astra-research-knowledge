# Expanded growing-shift and scalar-Hessian details for cbd968c5

24 October 2026. This supplies two explicit proof substeps for the frozen
SMOOTH_INTEGRABLE_LOG_ENVELOPE_HEAT_BRIDGE.md, SHAcbd968c585a332e49547f9a74b3b1e014ce2b3d36f695dfb7c46c8b327646399.
It changes neither its premises nor coefficients, and does not supply a
fresh independent audit. The frozen file is unchanged.

## 1. The growing shift in Section5

Equation(S7) is stated for FIXED shifts. At the application x=ln(tY) the
shift b_l=x-l=ln l+o(1) instead grows. The required estimate follows
directly from(S2), with constants uniform on that interval:

    sup_(u between l and l+b_l)|ell'(u)|
       <=C ell(l)/l,

because b_l=O(ln l) and ell is nonincreasing. Therefore

    ell(l+b_l)=ell(l)+O(ell(l)|b_l|/l),
    M(l+b_l)=M(l)-b_l ell(l)+O(ell(l)b_l^2/l).

The error terms are respectively o(ell(l)) and o(ell(l)), and
b_l=ln l+o(1). This is the exact growing-shift justification for the two
displayed replacements before(S19); it does not apply the fixed-b error
constant in(S7) outside its stated regime.

## 2. Bounded scalar Hessian in Section8

For F(u,v)=g(G a+lambda(b+1)), a=g^-1(u), b=g^-1(v), c=G a+lambda(b+1),

    F_uu=G^2 g''(c)/g'(a)^2
              -G g'(c)g''(a)/g'(a)^3,
    F_uv=G lambda g''(c)/[g'(a)g'(b)],
    F_vv=lambda^2 g''(c)/g'(b)^2
              -lambda g'(c)g''(b)/g'(b)^3.

For the entropy segment in(S22), a belongs to[T,T+a_A] and b to[T,T+a_B].
Every c is of order T, with fixed G and finite a_A,a_B. Since
g'(z)=z^-1+O(z^-2) and g''(z)=-z^-2+O(z^-3), every displayed Hessian
entry is bounded uniformly for all sufficiently large T. The endpoint
derivatives are theta+O(T^-1),phi+O(T^-1) by the same formulas. These
are scalar calculus facts; no exponential source moment, Gaussian input
theorem, global metric inequality or historical N557 argument is imported.

## 3. Infinite actual thermal chi-squared at every finite heat

The polynomial lower bound ell(x)>=c x^-K in(S6) implies that EVERY
source in this envelope class has ER^(1+eta)=infinity for all eta>0.
Conditional Jensen for a thermal photon law gives the same divergence
for every photon-number moment of order>1, even after replacing R by T+R
for an arbitrary finite heat T. This cannot be cured by that finite heat.

If the commuting actual state p_n had finite thermal chi-squared relative
to any finite-mean thermal law q_n, Cauchy--Schwarz would give, for every
fixed k>0,

    sum_n n^k p_n
       <=[sum_n p_n^2/q_n]^(1/2)
          [sum_n n^(2k)q_n]^(1/2)<infinity.

The thermal weighted moment is finite, contradicting the preceding
divergence for k>1. Hence actual thermal chi-squared is infinite at EVERY
finite heat, for every finite thermal reference. This is fully compatible
with the finite relative entropy and its small eventual value in(S4).
Only the local pre-crossover density in(S13) uses a quadratic estimate;
the global normal quantum transfer uses relative-entropy DPI.
