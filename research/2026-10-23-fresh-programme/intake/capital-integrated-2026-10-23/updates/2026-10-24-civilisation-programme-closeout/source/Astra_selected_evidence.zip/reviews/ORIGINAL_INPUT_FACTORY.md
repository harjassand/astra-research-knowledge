# Independent review: recurrent input preparation

23 October 2026. Reviewer w01; owner w39; root requested an independent reconstruction, with no preferred verdict. No physical operations or descendants. All previous w01 packets are preserved separately.

The final original-input factory survives this review as a **conditional mathematical circuit construction**. I found no blocking algebraic or access-model defect in the frozen final proof. Its strongest scope is a polynomial local quantum circuit preparing the original inherited rho to prescribed trace accuracy, with explicit model and parameter inputs. It does not establish an efficient outer encoder or decoder, a capacity improvement, a physical calibration procedure, or practical advantage.

This closes a specific source-recorded mathematical bottleneck: pinned Cycle11 `pro1/CONTINUATION.md:90` says no efficient preparation, spectral computation or precision bound was known. The present preparation result does not close the neighboring spectral/coding bottlenecks. External correctness and historical novelty review remain open.

## What was independently reconstructed

`RECONSTRUCTION.md` gives the complete derivation. The decisive steps are:

1. Coherent differentiation of the actual sqrt(a)U+i sqrt(b)I histories yields the short exact H representation `sum_(i<j) E_zeta[(q_i-q_j)(W_j*W_i-W_i*W_j)]`. Endpoint history cancellation removes the spectator charge and the otherwise extra k normalization. No stochastic replacement is used.
2. A locally simulated finite stack, including the actual root swap and identity only on the unpaired artificial top boundary, suffices. Relevant words start at depth k and use at most 2k U calls, so capacity 4k is safe. Known local circuits and their inverses suffice. No actual bath or inverse-device oracle is supplied.
3. A pair changes precisely its two named charge bits. Reversibly erasing its index from the output charge syndrome gives the rectangular `B_H=sum_x |x>H P_x` at normalization `2sqrt(N)`, N=binom(k,2). Its Gram is `P(H^2)`. The retained original pattern is essential.
4. The known local canonical source purifier stores the original charge pattern in its helper. An initial matching-pattern predicate E makes the assisted action exactly `(H tensor I)E/(2sqrt(N))`. On that known source, an LCU prepares C at constant normalization. This is a known-state factory; it is not access to an arbitrary logical or remote reference.
5. The **explicit middle signal projector** in `U* Pi_L U` gives `P(H^2)/(4N)`. Consequently D has constant normalization `1+theta^2 N` and D>=I gives a constant inverse-square-root gap. Applying J/2 after the assisted C gives the original JC purification, with known constant success `1/(4 alpha_src^2)` before its source flag. Amplification uses only the local preparation circuit and its inverse.
6. The reversed-congruence alternative is separately sound under the inherited all-coherence theorem: it has equal charge-sector spectra/entropy and full entire-prefix drift difference at most r^5/4, smaller than kappa/4096 in the prescribed window. It is unnecessary for the final original-input factory.

## Precision and full costs

The constructive logical cost is soft-O(k^2)*polylog(1/epsilon) gates, with a conservative O(log^2(1/epsilon)) pair-query composition, O(k) local workspace plus arithmetic precision, and classical compilation polynomial in k, input representation length L_b, and log(1/epsilon). All pair selection, prefix purification, projected signal tests, source preparation, amplification and inverses are included at this asymptotic level. A gate-level compiler and measured constants have not been implemented.

I independently obtained `||partial_b rho'||_1<=4k^3`; the owner then extended it to the original rho, and I independently confirmed that extension: `J'=-D^(-3/2)D'/2`, so the T', J', C' terms total less than 4k^3. Thus both inputs have trace-distance perturbation at most `2k^3 |Delta b|` at fixed safe k. The required accurate scalar bits are logarithmic in k and 1/delta. Input length, physical parameter acquisition and device-model mismatch must remain separate costs. The compiler does not learn b, perform an exact floor of an uncertain real, or validate the physical model.

Only final **total-Q** pinching is permitted for exact charge preservation. Complete-pattern dephasing destroys the useful coherences and yields outward bulk drift `2(1-b)m b^2 I`. Trace distance delta changes full drift by at most 2k delta and entropy by at most `delta k log2(3)+h2(delta)`. Inverse-polynomial state accuracy therefore preserves the inherited strict margins at its selected scaling. Fix that finite prepared density before the outer coding horizon, then invoke the conditional coding theorem for that density.

No actual bath reset, preparation, or feedback is introduced. Local ancilla initialization/disposal belongs to the logical factory, but its thermodynamic energy, fault tolerance, wall time and hardware costs are unacquired. There is no end-to-end communication resource estimate. The inherited exact spectral-type code may still require exponential dimension; state preparation does not compile it.

## Fresh tests and retained failure cases

`independent_checks.py` imports no owner code and derives the coherent response and simulated inverse-word contraction by different routes. `INDEPENDENT_RESULTS.json` records:

| Test | Fresh result |
| --- | --- |
| Legal finite-U basis states, including root and artificial boundary | 3,318 involution/charge checks passed |
| Exact coherent G1 versus forward/inverse skipped-pair H | k=2,3,4; rational residual zero |
| Forward/inverse basis paths | 72, 1,296, 15,552; no artificial-boundary touches |
| Exact nonzero pair entries | 4, 32, 188; zero wrong charge syndromes |
| Full assisted AR-domain contribution checks | 16,128 passed with E guard |
| Omitting E | False good contributions at every checked k; explicit k=2 counterexample retained |
| Original factory, rectangular polar/Gram, sector spectra, full-prefix drift | Nine floating parameter fixtures passed |
| Maximum entry error, final original-state reduction | <4.2e-17 |
| Complete-pattern dephasing | Adverse outward sign independently reproduced |

The invalid-syndrome counterexample is an active implementation discriminator: A_input=01, A_output=10, helper R=00 at k=2 is accepted without the E predicate when an invalid syndrome is totalized to pair index zero. The frozen final proof already includes the predicate, so this is a tested necessary condition, not an unresolved defect.

The r=1/4,1/2 fixtures are deliberately outside the inherited capacity window and test visible algebra. At r=1/256, k=2,3 still fail the separately stated b<=1/1024 premise of that particular capacity theorem. Only k=4 at that r meets the inherited selected-k example. None of these finite tests replaces the all-length proof or experimentally validates the device.

## Equally informed prior and remaining uncertainties

LCU, QSVT inverse powers, projected polar transformations, amplification and Dicke preparation are established. The primary QSVT paper directly supplies the required transformation, gap dependence, and polynomial classical phase construction; Petz normalization methods also predate this work. Current polar-Petz work likewise does not make access and singular-value costs free. The candidate contribution is acquiring those access hypotheses from this recurrent model. Section 8 of `RECONSTRUCTION.md` links the primary sources. Generic standard primitives are not novel here, and no best-algorithm separation is proved.

The decisive next computational discriminator is a gate-level implementation of SELECT, the symmetric-prefix purifier, E, the middle Pi_L, and rectangular right/left signal projectors. Its full projected block must be checked on small-k arbitrary inputs, E-perp, and bad signal states at fixed synthesized precision, with all gates and failed amplitudes charged. The consequential next scientific task is a costed outer code/decoder or a distinct rate theorem. Neither follows from this factory.

The original four theorem files are frozen by hash; their snapshots and exact owner receipts are recorded separately from this review. Prior review packets remain byte-identical. Status: preparation construction CONDITIONAL_INTERNAL_PASS; external validation UNKNOWN; novelty UNKNOWN; efficient code UNKNOWN; physical validation NOT_TESTED; practical advantage UNKNOWN; mission NOT_ACHIEVED.
