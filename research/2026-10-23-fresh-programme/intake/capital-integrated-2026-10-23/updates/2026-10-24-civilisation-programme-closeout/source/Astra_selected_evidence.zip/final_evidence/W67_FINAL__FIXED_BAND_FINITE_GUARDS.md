# Finite fixed-program rows over the supplied factor-two-b interval

W67, 24 October 2026. New unreviewed integration delta. It binds the
fixed-source transfer 90f0882f to a separate exact integer/Fraction
producer. All older known-parameter and narrow-band rows remain frozen.
The native/receiver interface is inherited from d8142311 with the
initializer qualification 736cebd6, at the recomputed dimensions and
accuracies. Its existing reviews do not automatically review this delta.

The public input is a rational b0 in(0,1/16384], not the actual gain.
One source, probability table, encoder and receiver are constructed from
b0. The actual fixed unknown parameter obeys b in[b0,2b0]. This is a
sqrt(2) interval in beta=sqrt(b), not a factor-two beta theorem.
Calibration is unnecessary within this supplied location. No receiver
estimate, shared actual label, unknown-message copy or backward message
appears in the construction.

The new source transfer gives, uniformly over that entire interval,

    k=floor(1/(5b0)),
    G=1/18600, Kappa_band=1/1080000, c=1/25600.

Entropy, relative operator, charge commutation, regularization gap,
table probabilities and acquired functions all concern the REFERENCE
source. The full negative drift is evaluated at the ACTUAL device and
acts on every coherent/entangled bulk prefix. At low depth the actual
root is retained in the Lyapunov remainder.

Recompute G1--G10 using Kappa_band throughout. The continuum analysis
grid has at most2^Bgrid points, where

    Bq=48+4B_R+4 ceil(log2(1/z)),
    Bgrid=Bq+B_R+5, spacing=q/(16R), q=2^-Bq,
    t_L=Kappa_band/(8k^2), C_tail=6/(Kappa_band*t_L),
    H=ceil{[5eps*s+2eta_w+ceil(log2(1+C_tail))+Bq
                +ceil(log2(1/eta_parent))+Bgrid+12]/t_L},
    n_flush=16(H+Bq+6).

The angular interval has length<1. Therefore the grid count covers
both endpoints and the whole interval, regardless of its detailed
arcsine endpoints. R is a power of two at least16 n_body. On a passed
row flush<=body, so the final bad-effect Lipschitz constant is2T<=R/4;
grid interpolation loses at mostq/64. The full grid is an analysis
device, never an experimentally evaluated or emitted object.

For clarity the conservative arithmetic has additional probability
slack. Writing eta_p=2^-ceil(log2(1/eta_parent)), the cutoff implies
the GOOD-program source-averaged tail at each point and sector is at
most eta_p*q/(4096*2^Bgrid), using e>2 after cancelling ln F. Two-sector
Markov at q/4 and the grid union then cost at most eta_p/512. Conditional
frame/table/width failures retain their separate allocated budgets.
The terminal descent error is at mostq/4, and interpolation leaves the
parent mean final bad word belowq. The common Fourier centered-Gram
event handles the whole finite error span, so no second physical gain
grid enters the outer design or decoder.

All initial, body and terminal forward calls are priced. The illustrative
initializers have supplied tail Tr(P_(depth>A)tau)<=2^-A, A=Bq+8. General
normal initializers require an explicit tail input, charged separately;
only pointwise asymptotics are available without that input.

| Public reference beta0 | k | H | Terminal calls | Total calls |
|---|---:|---:|---:|---:|
| 1/128 | 3276 | 113125778734550401 | 1810012459752814640 | 2027745784351262902744518310000 |
| 1/512 | 52428 | 31728313299673353601 | 507653012794773666608 | 8307548208596209035721439230116208 |
| 1/2048 | 838860 | 8882661582599721840001 | 142122585321595549449840 | 68056408480477103129914886450698996528 |

Each new row checks all sufficient G/M8/F6 scalar guards and

    ell_code >= [3/2+G/(16k)]*(n_initial+n_body+n_flush).

Consequently this conditional rate target has excess at least
b_actual/119040. The mesoblock count s and t happen to agree with the
selected earlier rows; their source margins, B0, bins' mu lower bounds,
inner designs/queries, H, flush and final totals are newly computed.
They must not be represented as unchanged known-parameter runs.

All seed sizes, quantum probability-table experiments, table output,
inner polar queries/phase work and outer repeated-encoder accuracies
are in FIXED_BAND_FORWARD_GUARDS.json. For beta0=1/128, the conservative
inner polar query ceiling is2^10688*31296, before functional access and
the whole-code repetition cost. Every such query carries the explicit
source/log/QPE/native construction and both global completion budgets
of d8142311. No earlier quartic gate exponent is inherited. These
selected sufficient costs are enormous; they establish no practical
benefit over an equally informed ordinary compiler.

The generator remains randomized QUANTUM preprocessing with classical
public output. Its known-model table is counted; deterministic classical
generation, certified seeds, or free distribution through the unknown
device are not supplied. Actual hardware instrument accuracy and
parameter stationarity remain model promises, not measured facts.

The new source-band theorem and changed finite/native integration still
need fresh review. The exact scalar producer is a replayable calculation,
not an execution of the giant source, table, design, polar phases or
communication experiment. Physical NOT_PERFORMED; priority UNKNOWN;
practical advantage NOT_ESTABLISHED; mission NOT_ACHIEVED.
