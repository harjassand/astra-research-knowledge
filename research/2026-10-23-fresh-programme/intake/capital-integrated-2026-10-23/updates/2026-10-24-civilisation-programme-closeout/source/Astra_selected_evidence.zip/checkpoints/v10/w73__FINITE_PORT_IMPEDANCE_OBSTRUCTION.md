# Finite port impedance: a complete-process obstruction and feedback target

2026-10-24. Separate internal analytic model. This is not an acquired physical
instrument, a hardware impossibility theorem, or a change to the reviewed
ideal-action results. It identifies a concrete resource needed by one natural
realization of that interface. All older proof bytes remain frozen.

## 1. Actual observation and cost law

Let L_theta be the Laplacian of two balanced stars of d leaves each, n=2d+2.
Every leaf-edge weight is a>0, and an unknown bit theta optionally adds a
weight-a hub edge. Give the learner the hub labels, all leaf memberships,
every leaf weight, the two possible networks, and all device constants before
its first action. Only theta is unknown. This is a strengthening for the
lower bound, not an uncharged acquisition in a positive protocol.

At each action a controller commands the external terminal voltages x. Each
terminal is connected to its actual graph node by a **known series resistance
r>0**. Let v be the actual internal node potentials and i the port currents.
Grant instantaneous exact stable settling and exact external commands. The
device's defining equations are

    i=(x-v)/r=L_theta v,
    v=(I+r L_theta)^-1 x,
    i=M_theta x,   M_theta=L_theta(I+rL_theta)^-1.       (1)

Acquire all n port currents with independent additive N(0,sigma^2) readout
errors at every action. The scalar sensor noise sigma>0 is stipulated by
this model; no thermal-noise or actual electronics law is inferred. The
controller may choose each future command using every past observation and
its independent random seed. It may repeat actions, use any finite number
q, and perform unlimited computation. Impose the **external-command** budget

    sum_t x_ti^2 <= B,   every terminal i,             (2)

pathwise under either hypothesis. The budget concerns x, not the internal v
of the ideal Laplacian-action theorem. Their difference is the preparation
cost under examination. All nq scalar readouts are allowed. No adaptive
restriction is imposed on this lower bound.

## 2. Exact rank-one response difference

Write L_0 for the disconnected known stars, b=e_U-e_V,
A_0=(I+r L_0)^-1, and u=A_0 b. Then L_1=L_0+a b b^T.
Sherman--Morrison and M_theta=r^-1[I-(I+rL_theta)^-1] give

    M_1-M_0 = c u u^T,
    c=a/[1+r a b^T u] <=a.                            (3)

Set beta=r a and D=1+beta(d+1). In the U-star the column A_0 e_U has

    hub entry (1+beta)/D,
    each of its d leaf entries beta/D.

The V-star column is identical on its disjoint support. Thus u has that
positive column on the U-star and its negative counterpart on the V-star,
so exactly

    ||u||_1=2,
    ||u||_2^2=2[(1+beta)^2+d beta^2]/D^2,
    b^T u=2(1+beta)/D.                                (4)

The positive column sums to one; no unknown edge weights enter (4). For
fixed a,r>0 and d growing, ||u||_2^2~2/d and c tends to a.

## 3. Full adaptive transcript bound, including repetitions

Let P_1,P_0 denote the complete adaptive transcript laws, including its random
seed. Conditional on any history, the next control x_t is the same function
of that history under either hypothesis. The two conditional acquired means
differ by c u(u^T x_t), with common covariance sigma^2 I_n. The ordinary
Gaussian relative-entropy chain rule therefore gives exactly

    D(P_1||P_0)
      = [c^2||u||_2^2/(2sigma^2)]
          E_1 sum_t (u^T x_t)^2.                      (5)

Define s_i=(x_1i,...,x_qi) for a realized path of controls. The triangle
inequality and (2), **on that realized adaptive path**, imply

    sum_t (u^T x_t)^2
       = ||sum_i u_i s_i||_2^2
       <= (sum_i |u_i| ||s_i||_2)^2
       <= B||u||_1^2=4B.

Consequently, for every adaptive/repeated design,

    D(P_1||P_0) <= 2c^2 B||u||_2^2/sigma^2,
    TV(P_1,P_0) <= (c/sigma) sqrt[B||u||_2^2].          (6)

A test with error <=delta<1/2 on both possible inputs requires

    B >= sigma^2(1-2delta)^2/[c^2||u||_2^2].           (7)

At fixed a,r,sigma,delta this is B=Omega(d), even though the whole background
network is supplied. Additional actions or repeated readings cannot remove
this requirement while keeping the same total budget (2). This is a
full-data bound: it does not retain only one weak hub current and ignore
the other n-1 acquired outputs.

For comparison, one nonadaptive command x_i=sqrt(B) sign(u_i) attains equality
in the control inequality. Its Gaussian mean separation is
2c sqrt(B)||u||_2 and threshold testing errs with probability
Phi[-c sqrt(B)||u||_2/sigma]. Thus B=Theta(d) is also sufficient at fixed
target error in this strengthened known-background problem. This observation
does not assert an exact adaptive minimax error formula.

## 4. Impedance scaling required by unit-command-budget acquisition

The ideal hidden-star protocol uses constant nominal node-voltage budget and
fixed noise. The passive finite-port realization above instead requires
growing B when r is fixed. If a r_d d tends to infinity, (4) implies
||u||_2^2 tends to zero, hence fixed B and fixed sigma/a cannot achieve a
fixed error <1/2 for any number of adaptive actions.

To keep that information bound nonvanishing at fixed B,sigma/a, it is
necessary to keep a r_d d bounded. A resistance r_d=O(1/(a d)) does so in
this model. This is a concrete preparation/interface resource target, not
evidence that such an instrument is unavailable or unaffordable. Active
feedback, direct aggregation, different sensors or a larger command budget
could change the model, and each needs its own complete observation/cost law.

## 5. Duration and averaging cannot be credited for free

An alternative explicitly charged law is independent current readout variance
sigma_0^2/tau_t after a duration tau_t>0. If a physical nominal cost is defined
as the time-weighted command budget

    sum_t tau_t x_ti^2 <= E,   every i,

then the same proof uses temporal vectors sqrt(tau_t)x_ti and gives

    D(P_1||P_0) <=2c^2 E||u||_2^2/sigma_0^2,
    E >= sigma_0^2(1-2delta)^2/[c^2||u||_2^2].

This is a stipulated white-noise averaging model, not a measured sensor law.
It explicitly charges long integration or repeated actions together with
their prepared amplitudes. If duration can reduce sigma while its cost is
omitted, it is a different resource model.

## 6. Two ideal feedback laws and their paid noise

These calculations are stress controls, not stable circuits that have been
built. Suppose an ideal instantaneous current-feedback controller uses the
noisy current j=i+eta to command x=z+r j, intending internal target z.
Equation (1) then gives

    v=z+r eta,
    j=L_theta z+(I+rL_theta) eta.                      (8)

Restoring the ideal mean action by this exact algebra changes independent
readout noise eta~N(0,sigma_i^2 I) into covariance
sigma_i^2(I+rL_theta)^2. It does not restore the ideal fixed independent
current-noise oracle. It also requires commands that can grow with degree.
For equal stars a hub row has ||row_i(L_theta)||_2^2 at least a^2(d^2+d).
Its raw feedback-noise variance is therefore at least
sigma_i^2[1+2r ad+r^2 a^2(d^2+d)]. Keeping it constant at fixed r can require
sigma_i=O(1/d), or another differently charged controller.

Alternatively, grant a perfect high-gain voltage loop whose residual internal
potentials are v=z-xi, with independent voltage-sense errors
xi~N(0,sigma_v^2 I), and a separate current readout eta of variance sigma_i^2.
The acquired current is

    j=L_theta z-L_theta xi+eta,
    Cov(j)=sigma_v^2 L_theta^2+sigma_i^2 I.             (9)

At a degree-d equal-star hub its extra variance is at least
sigma_v^2 a^2(d^2+d). Thus fixed scalar output noise requires voltage-sense
precision of order 1/d in this independent-offset feedback model. Exactly
common-mode voltage errors would cancel through L1=0; that is a different
correlation/control capability, not something excluded by (9).

No feedback stability, bandwidth, power-source capacity, aggregate-sensor
noise law or manufacturing cost has been established. Equations (8)--(9)
show which noise/control terms must be supplied before feedback may be
credited with implementing the ideal mathematical interface.

Analytic status: producer candidate awaiting independent reconstruction.
Physical: MODEL_ONLY, zero trials. Priority: UNKNOWN; elementary circuit,
rank-one and Gaussian-testing ingredients are prior. Practical: UNKNOWN.
Mission: NOT_ACHIEVED.

## 7. Diagnostics and a primary instrument control

`replay_finite_ports.py` checks 972 exact rational assertions: 36 full circuit
cases with directly inverted terminal operators, 144 whole temporal-control
energy cases, the rank-one difference, exact column norms, saturation by one
known-background command, and feedback covariance identities. Its larger-d
table evaluates the closed forms only. These are finite synthetic algebraic
checks, not acquired unknown-network data or physical tests.

As primary context, the Keysight N2820/1A current-probe manual (May 2025),
pages 47--48, explicitly describes series lead/shunt resistance and its burden
voltage. It also identifies a different head architecture without that added
burden contribution. Thus the fixed-r law is relevant but not universal across
current sensors. No product is claimed to satisfy our simultaneous n-port,
noise, settling or affordability requirements. [Primary manufacturer manual](https://prc.keysight.com/Content/PDF_Files/N2820-97007.pdf).
Retained full PDF SHA256
`0697359aae9412045163401860a1a36c464dc57e3a14a3f3a6131865a1800a30`;
only its relevant burden-voltage pages were read for this comparison.
