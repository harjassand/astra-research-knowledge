# Fresh audit of the Cohen collision-annihilator bridge

23 October 2026. Reviewer W61. Scoped result: **PASS, with the fixed-constant
and numerical-instantiation distinctions stated below.** This is an independent
mathematical reconstruction and finite diagnostic, not external proof certification.
Priority, ordinary-time advantage, practical usefulness and the programme mission
remain UNKNOWN / NOT_ACHIEVED.

The exact reviewed main source is W14's
`dense_repeated/COHEN_COLLISION_ANNIHILATOR_PROOF.md`, SHA256
`36157bb2129d435b30a3cc17e231a46e5c609cf068231f5bc643f15dd2a953a4`.
The separately frozen encoding clarification has SHA256
`d164cde559c3d8ec10507a447ac13338fa747ce21dd2ca3e419c79acca707884`.
Both exact sources are copied into this directory. All predecessor Dyck and
operator-algebra packets are preserved.

I reconstructed the arrangement and actual NP acquisition from the task's
definitions before reading the complete frozen proof. I then read every section
of those exact main bytes and checked its cited primary statements directly.
No W14 verification code or fixture was read or imported into this diagnostic.

## 1. Exact strongest scoped claim

Write an explicitly evaluable expanding circuit as

    F=(P,g): F2^n -> F2^n x F2.

For any chosen fixed degree D, let M_D be the number of squarefree monomials of
degree at most min(D,n). There is a deterministic ordinary-NP-oracle procedure
that either returns a correct missing output of F, or certifies that the collision
outputs of P have no nonzero degree-at-most-D Boolean annihilator. It is uniformly
clocked even off the structural promise.

If P is quadratic and has H holes, put L=2^ceil(n/2). For every fixed integer c>=1,
the promise H<=cL implies the existence of an annihilator whose degree is bounded
by a constant depending only on c. Consequently some deterministic uniform
FP^NP machine solves Avoid on this promised family. Trying the n+1 actual
coordinate projections extends this to F having at least one such projection.

The numerical universal Cohen constant, a guaranteed numerical degree for a
given c, and the resulting numerical polynomial exponent have **not** been
extracted. This qualification is already explicit in the reviewed proof. The
chosen-degree procedure is concrete; its guaranteed completeness for the entire
fixed-c family is an existential machine statement until a valid bound is fixed.

Only P needs to be quadratic for the structural implication. The appended bit g
can be any explicitly evaluable Boolean circuit: its only uses are evaluations
after a known input has been obtained. This mild scope extension follows directly
from the proof and does not give unrestricted Avoid.

## 2. Integer Gauss normalization, reconstructed

Set nu(y)=|P^{-1}(y)| and w(y)=nu(y)-1. Since the domain and codomain have the
same size,

    sum_y w(y)=0,  sum_y |w(y)|=2H.

Every negative w value is exactly -1. Define the unnormalized Walsh transform

    W(a)=sum_y w(y)(-1)^(a.y).

At a=0 this is zero. At a!=0 the subtracted constant has zero Walsh transform,
so W(a)=sum_x(-1)^(a.P(x)).

For completeness, if q is a scalar quadratic on F2^n and B its alternating polar
form of rank r, write q0=q+q(0). Directly expanding the square of its Gauss sum
gives

    (sum_x (-1)^q(x))^2
      = 2^n sum_(h in rad B) (-1)^q0(h).

On rad B the map q0 is linear. The last sum is either zero or 2^(n-r), and r is
even. Thus the Gauss sum is zero or +/-2^(n-r/2). Since
r<=2 floor(n/2), it is divisible by L=2^ceil(n/2), with no assumption about H,
fiber multiplicities, or a one-band spectrum.

Accordingly f(a)=W(a)/L is integer valued, including at the origin. With normalized
Fourier transform on f,

    fhat(y)=2^-n sum_a f(a)(-1)^(a.y)=w(y)/L,
    ||f||_A=sum_y |fhat(y)|=2H/L.

This is the correct normalization for the imported integer theorem. There is no
extra factor 2^n, no origin correction and no zero-one-valued hypothesis on f.

## 3. Primary Cohen theorem and inversion

I checked the actual v2 HTML and PDF of Green--Sanders, Theorem 1.3 and the
measure/Fourier conventions immediately following it. Its input is an integer
function on a finite abelian group with bounded algebra norm; its output is a
signed sum of coset indicators. Its count is at most
exp(exp(C_absolute M^4)), independent of group size. The paper does not print
a numerical absolute constant in this statement. [Primary source]
(https://arxiv.org/html/math/0611286v2).

For norm<=2c fix one valid integer count bound C_c>=1. It is a universal bound
for the fixed c, independent of the particular circuit or n. If

    f(a)=sum_(i=1)^t eps_i 1_(b_i+V_i)(a), t<=C_c,

then exact Fourier inversion yields

    w(y)=sum_i eps_i L 2^(dim V_i-n)
                    (-1)^(b_i.y) 1_(V_i^perp)(y).

This follows by summing a character over b_i+V_i. The term weight is dyadic and
need not be an integer. Physical support flats are linear here; allowing affine
flats in the next lemma only strengthens that lemma. The source applies to all
integer f, so it is not necessary to prove f takes only 0,+1,-1.

The retained correct primary PDF has SHA256
`4c1e5ae4d3f92eebc0f917f3122643d4019e778c1630bdf85c0e18385cebe849`.
Its first page and Theorem 1.3 agree with the cited work. I did not use the owner's
earlier mislabeled PDF, which is invalid evidence for this theorem. Sanders's
later finite-vector-space integer theorem was also read as corroborating primary
background; it is not needed for the present bound. Its sharper bound does not
resolve the missing numerical instantiation by itself.

## 4. Arrangement-to-annihilator lemma

Suppose, independently of the previous section, that

    w(y)=sum_(i=1)^t alpha_i (-1)^(a_i.y+b_i) 1_(A_i)(y), t<=C,

where A_i are arbitrary affine flats. Assume the positive set S={w>0} has density
at most 1/2. For square P this is automatic: every collision output uses at least
two distinct inputs, so there are at most 2^(n-1) collision outputs.

Put s=ceil(log2(4C)). Flats of codimension at least s have union density at most
C 2^-s<=1/4. Their union together with S therefore leaves at least a quarter of
the cube. Choose y0 outside both sets. The following conditions are consistent
because y0 satisfies them:

* For each support flat containing y0, impose all its defining affine equations.
  It has codimension less than s.
* For each support flat excluding y0, select one violated defining equation and
  fix that equation's value at y0. This one condition excludes the entire flat,
  even if its codimension is large.
* For every character, impose a_i.y=a_i.y0.

The resulting nonempty affine cell T contains y0 and fixes every summand, so
w=w(y0)<=0 on T. Its Boolean indicator is a product R of affine linear factors.
It satisfies R(y0)=1, hence is a nonzero Boolean function after squarefree
reduction. For a containing flat there are at most s-1 support factors; for an
excluding flat there is only one, and s>=2. The character costs at most one more.
Thus degree R<=t s<=C(s+1), as claimed. On S the indicator is zero.

No step assumes disjoint flats, generic position, a supplied decomposition,
bounded weights, independent character phases, or a proper affine hull. Importantly
the algorithm below never needs to locate y0 or recover this representation.

## 5. Actual acquisition through ordinary NP decisions

Let v_D(y) be the full vector of the M_D squarefree monomials, including 1. The
desired linear subspace is

    E=span_F2 {v_D(y): y is a collision output of P}.

Starting with an explicit zero row space, ask for distinct inputs x,x' with
P(x)=P(x') and v_D(P(x)) outside the current row space. This is an NP predicate:
the witness is the pair of n-bit INPUTS, and the verifier evaluates the circuit,
the listed monomials and an explicit GF2 row-space calculation. Nonmembership
in a given linear span is deterministically decidable; it does not insert a
coNP predicate into the verifier.

Each YES can be converted to an actual pair by at most 2n ordinary decision
queries fixing one successive witness bit. The resulting independent row raises
the dimension. There are at most M_D such increases. A terminal NO certifies
the COMPLETE span, not a statistically representative sample. If the row space
becomes the entire feature space, acquired rows already rule out an annihilator
and justify OUTSIDE immediately.

If the complete span is proper, a nonzero vector in its orthogonal kernel gives
a polynomial R vanishing on all collision outputs. Distinct squarefree monomials
are independent as functions on F2^n, so R is not the zero function. To find an
explicit y with R(y)=1, choose an inclusion-minimal monomial in its support and
set exactly those variables to 1. The only surviving supported monomial contained
in that support is the chosen one. This also covers the constant-term case.

The algorithm now has an output y with at most one P-preimage. A preimage
existence query is ordinary NP. NO gives the missing rectangular word (y,0).
YES permits n more input-prefix queries, obtains the unique x, and gives
(y,1+g(x)). If there were no collisions at the first query, square P is a
permutation and the fixed input x=0 already gives the flipped missing word.
The n=0 case is handled by flipping the only produced bit.

This last projection/flip step is the classical CollisionAvoid-to-Avoid interface,
not a new reduction. I independently read Definition 2.4 and Theorem 3.1, printed
pages 7 and 13 of the exact ECCC revision. [Primary source]
(https://eccc.weizmann.ac.il/report/2023/193/revision/1/download/).

## 6. Complete costs and uniformity

The displayed safe decision cap is

    (2n+1) M_D+n+2.

Every pair success costs one existence query plus at most 2n prefix queries;
there can be at most M_D successes. A terminal NO and the preimage branch fit
within the additional terms. Full-span abort only reduces this count.

For a fixed degree D, M_D=O(n^D). A full monomial description needs O(n M_D)
bits and a dense padded row-space field O(M_D^2) bits. Since
n M_D<=n^2+M_D^2, the claimed query length O(S_F+M_D^2+n^2) is valid under
the stated circuit-description-size convention. Padding is present FROM THE
FIRST QUERY. A single tagged NP language can verify the pair and preimage
questions in time polynomial in their actual serialized length. There is no
arbitrary exponential monomial calculation hidden behind a short query.

Repeated serialization, elimination and evaluations fit the generous outside
work bound O((S_F+n+1)^4(M_D+1)^4). For a variable binary D, reading its
description also costs its bit length; clip D to min(D,n) BEFORE serialization.
I raised this minor bookkeeping point, and the separately frozen owner addendum
states exactly this charge. It does not affect any fixed-D consequence.

For every fixed c one valid integer C_c exists by the imported theorem. A
deterministic Turing machine can contain this SAME finite constant for every
input in that class. This is an existential uniform machine, not input-dependent
advice. However the proof has not numerically selected its value. Therefore it
does not provide a numerically instantiated universally complete executable for
a named c. Chosen-degree A_D is executable and exactly recognizes its own
annihilator class. It is not a recognizer of the numerical H<=cL promise.
There is no justified unbounded adaptive-degree search called polynomial.
If c or D grows with n, the M_D dependence must be paid.

Trying all n+1 coordinate projections is an explicit additional factor. It does
not discover an arbitrary favorable affine projection without cost. A failure on
all chosen projections does not rule out every possible representation.

## 7. Collision-hull baseline and negative scope controls

For an arbitrary square circuit, a proper affine hull of collision outputs gives
a degree-one annihilator, without Gauss sums, H, or Cohen. Degree-one acquisition
is exactly the same complete-span procedure. A proper WHOLE-defect hull is a
stronger assumption and cannot be credited as an advantage over this baseline.
The present structural theorem does not assume either hull is proper.

The finite replay found a three-bit quadratic example whose four collision
outputs are 2,3,5,6 and span the whole affine cube. Its monomial-mask coordinate
lists are

    [[1,2,3,5], [0,1,5], [0,2,3,5]],

where mask 0 denotes the constant monomial. It has H=L=4. A degree-two acquired
annihilator is 1+x1+x0*x2 using zero-based variables. Degree one rejects it.
This is a concrete finite distinction from the proper-collision-hull baseline;
it is not an asserted asymptotic strict-family separation.

No claim follows for arbitrary rectangular quadratic circuits with H/L unbounded,
arbitrary literal three-local circuits that may contain cubic terms, general
Avoid, P versus NP, or an ordinary-polynomial-time implementation without the
NP oracle. The finite simulator uses exhaustive witnesses and is itself
exponential, as explicitly recorded. No quantum or physical advantage is involved.

## 8. Independent finite diagnostics

`check_independent.py` uses exact integers/Fractions and imports no producer
code. Its seed is 610140059. `CHECK_RESULTS.json` and `CHECK_RAW.txt` retain the
raw result and example fixtures. It passed 1,022,846 assertions:

* 9,596 complete acquisition runs and 153,109 serialized simulated NP decisions;
* 8,591 successful annihilator branches, including 4,452 square-hole outputs
  and 4,139 singleton outputs; 782 permutation branches; 223 exact OUTSIDE cases;
* all 4 one-bit and 256 two-bit quadratic square maps, with all appended-bit
  truth tables and all degrees from 1 through n in these exhaustive cases;
* 664 total quadratic Gauss/Fourier fixtures through n=8, including exact polar
  ranks, all nonzero Walsh amplitudes, integrality and normalized algebra norms;
* arbitrary nonquadratic maps and dense generic two-to-one maps as off-promise
  controls, plus a 5,001-bit degree input clipped before query serialization;
* 700 arbitrary weighted affine-support/character arrangements, including 816
  high-codimension supports, with the entire cube checked for every fixture;
* 200 exact signed frequency-coset inversions with rational term weights.

Ground-truth fibers are computed only after each client run. The simulated NP
oracle internally exhausts actual input witnesses, while the client uses only
decision answers and bit-prefix extraction. Every query parses the complete
M_D-by-M_D bit field, including the initial all-zero field. Truth-table circuits
are used as finite controls and are charged at their actual description size.

These diagnostics support the stated finite implementation behavior. The
analytic arguments, plus the imported exact Cohen theorem, carry the universal
mathematical consequence; the assertion count does not certify it.

## 9. Remaining gates

No blocking mathematical gap was found in the frozen proof with its explicit
scope and the encoding clarification. A focused search did not establish the
historical priority of the arrangement/acquisition composition. Ordinary parity
learning and integer spectral-norm structure have extensive prior literature;
the present record must not describe the constituent mechanisms as wholly new.
Needed before stronger claims are a broader specialist priority check, extraction
of a usable numerical universal bound if an instantiated guaranteed algorithm is
desired, and a genuinely matched benefit beyond the proper-collision-hull and
other equally informed NP baselines. General Avoid and the mission remain open.
