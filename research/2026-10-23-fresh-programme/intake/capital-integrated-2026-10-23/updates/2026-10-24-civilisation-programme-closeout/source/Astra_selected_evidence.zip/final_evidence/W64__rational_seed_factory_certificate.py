"""Bind exact classifier outputs to an outward rational full-factory error.

Does NOT perform high-r giant-statevector evolution, apparatus operation or
independent full proof review. Checks exact integer inequalities only.
"""
from pathlib import Path
from fractions import Fraction
import json,hashlib,datetime
ROOT=Path(__file__).parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    source=ROOT/'EXACT_THREE_CALL_CLASSIFIER_CERTIFICATE.json'
    data=json.loads(source.read_text());assert data['beta']=='1/2'
    selected=[r for r in data['rows'] if r['r']==80 and r['initial_depth'] in [0,1]]
    assert {r['initial_depth'] for r in selected}=={0,1}
    rows=[];eta=[]
    for row in selected:
        for key in ['eta_plus','eta_minus_by_sign_mirror']:
            val=row[key];A=int(val['A']);B=int(val['B']);scale=int(val['sqrt3_bracket_scale'])
            lower=int(val['sqrt3_lower_numerator']);upper=int(val['sqrt3_upper_numerator'])
            assert upper==lower+1 and lower*lower<=3*scale*scale<upper*upper
            U=A*scale+B*(upper if B>=0 else lower);D=scale*(1<<val['denominator_power_of_2'])
            assert U==int(val['upper_numerator']) and D==int(val['upper_denominator'])
            assert 0<=U<=D
            eta.append(Fraction(U,D))
            # zeta=257/10^7 upper-bounds2sqrt(eta) iff4eta<=zeta^2.
            left=4*U*10**14;right=257**2*D
            assert left<=right
            rows.append(dict(initial_depth=row['initial_depth'],sector_error=key,
                inequality='4*U*10^14 <=257^2*D',left=str(left),right=str(right),passed=True))
    r=80;L=3*r;T=12;zeta=Fraction(257,10**7);upload=Fraction(6906,10**7)
    tau=Fraction(1,4**T)
    assert 8*tau<=upload*upload
    ideal=4*zeta+upload
    assert ideal==Fraction(7934,10**7) and ideal<Fraction(1,1250)
    n_forward=2*(L+2*L)+T;n_return=2*(L+2*L)
    assert n_forward==1452 and n_return==1440
    # Separate OPTIONAL perturbation budget; does not assert such hardware exists.
    per_channel=Fraction(1,10**9);local_total=Fraction(1,10**6)
    noisy=ideal+(n_forward+n_return)*per_channel+local_total
    assert noisy<Fraction(1,1250)
    payloads=['COHERENT_SECTOR_ORACLE_AND_SEED_PRESERVING_UPLOAD_V1.md','THREE_CALL_CLASSIFIER_REFINEMENT_V1.md',
        'EXACT_THREE_CALL_CLASSIFIER_CERTIFICATE.json','three_call_classifier_exact.py','NATIVE_DEPTH_KERNEL_CHECKS.json','native_depth_kernel_checks.py']
    result=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        status='EXACT_RATIONAL_IDEAL_NATIVE_CERTIFICATE_FULL_FRESH_REVIEW_PENDING',
        beta='1/2 supplied exact native angle',word_depth_H=1,unknown_seed='Arbitrary; may be jointly entangled with source and inaccessible reference',
        initial_word='EXACT joint physical word root; old seed/source/reference unrestricted',
        target='Transfer arbitrary F in span(empty,1,2) to native word, reset F/label/all coherent ancillas, preserve entire original seed/reference',
        classifier_blocks_per_oracle=r,coherent_classifier_native_calls=L,exact_integer_checks=rows,
        uniform_wrong_label_upper_fraction=str(max(eta)),uniform_wrong_label_upper_display=float(max(eta)),
        per_oracle_operator_upper=str(zeta),upload_tail_tau=str(tau),upload_unhalved_diamond_upper=str(upload),
        upload_squared_integer_inequality=dict(left=str(8*10**14),right=str(6906**2*4**T),passed=True),
        complete_ideal_unhalved_diamond_upper=str(ideal),complete_ideal_upper_decimal='0.0007934',
        forward_calls=n_forward,quantum_backward_qutrit_returns=n_return,quantum_port_memory_qutrits=2*L+T,
        quantum_port_memory_scope='Fresh240-port ancillas per oracle plus12upload ports; source/label/arithmetic storage additional',
        optional_perturbation_promise=dict(each_native_call_unhalved_diamond=str(per_channel),each_quantum_return_unhalved_diamond=str(per_channel),
            sum_all_local_circuit_unhalved_diamond=str(local_total),complete_upper=str(noisy),complete_upper_decimal=float(noisy),
            status='CONDITIONAL precision specification, no calibration or noise demonstration'),
        source_hashes={p:sha(ROOT/p) for p in payloads},
        limitations=['Exact finite classifier DP plus analytic operator/composition proof, not a full high-r statevector or hardware execution',
            'Native beta/root/precision promises are supplied in this certificate; no unknown-beta acquisition credit',
            'Complete proof fresh independent review pending',
            'Generic coherent control, uncomputation and opposite-download upload are prior; special native priority unknown',
            'No capacity improvement, practical advantage or scientific-learning mission achievement'],
        physical_calls=0,peer_imports=0)
    target=ROOT/'RATIONAL_SEED_FACTORY_CERTIFICATE.json';target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['exact_integer_checks','source_hashes']},indent=2))

if __name__=='__main__':main()
