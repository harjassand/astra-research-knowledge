# Preserve the original body's backward-wire permission

23 October2026. Fresh critic w36 identified ambiguous scope wording in section4 of frozen acquisition addendumad82ba2a51926da78c50f0f3d2c141ba31d2ea0f5eefe7672df04e49a0bf536e. Its historical bytes are unchanged.

The ACQUISITION PHASE needs only backward CLASSICAL flags. It does not replace or simulate any backward quantum wires used by the ORIGINAL BODY protocol. The simulation retains exactly that body's backward communication permission. In particular:

- A body with arbitrary backward quantum/classical communication is simulated with the SAME arbitrary backward quantum/classical permission, and zero newly supplied loader-program preshares.
- A body that uses only backward classical feedback is simulated with only backward classical feedback, and zero initial A:B preshares if its entire original nonlocal initial resource is the fixed eta being synthesized.
- No o(N)-cost conversion of an arbitrary quantum-back body into a classical-back body is asserted.

Read the section4 phrase 'retaining backward classical feedback' subject to this explicit distinction. It describes the classical-feedback subclass, not a downgrade of the body's wire permission. The all-bath carrier identity, whole-known-program retries, error bounds and preparation costs are unchanged. Original N-dependent common preshares remain common permission as already stated.
