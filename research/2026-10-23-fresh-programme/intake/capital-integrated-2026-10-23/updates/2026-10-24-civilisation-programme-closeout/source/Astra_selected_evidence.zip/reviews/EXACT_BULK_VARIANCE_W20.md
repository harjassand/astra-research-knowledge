# Exact coherent bulk variance: independent audit

**The all-k response theorem passes this scoped internal audit. Its positive
source application needs gamma>=0 explicitly. It also proves an exact score
ceiling that defeats the proposed quadratic large-r variance route.**
No new capacity rate, efficient source/code construction or physical
capability follows from this operator improvement alone.

The frozen original source has SHA256
`5fc82bbc4bf0f76d7e8133d9c2d3eb5e2d937da3bc534ac711fdb99e44bbdfd3`.
The root reconstruction and exact-score/gamma qualification are separately
frozen. `INDEPENDENT_AUDIT.md` derives all principal steps and states the
remaining source premises; `FIRST_PASS.md` preceded reading root's proof.

## What checks

For initial bath depth>=k, every move/stay mask produces its own orthogonal
output binary input-charge pattern. Each raw move word is an isometry of
the ACTUAL root-completed unitary. Full W unitarity consequently gives exact
mean displacement a(2q-k) and centered complete-pattern variance kab.
Squaring after a bulk cutoff would lose positive rows and is not the proof.

Total-charge pinching selects a subset of positive row squares. The centered
charge-preserving operator preserves bath depth, making the bulk reducing.
Weighted UCP Gram positivity then gives

    ||D_b(sigma Yoff)||<=sqrt(kab)||Yoff||_(2,sigma),

for Hermitian total-charge-preserving Y and zero COMPLETE-pattern Yoff.
This bounds the full coherent bulk response, not one selected bath
expectation. The clipped-pattern positive source and exponential charge
tilt retain positivity, exact normalization/charge, both offdiagonal
remainders and the full bath operator bound. The entropy split and vanishing
fixed-r tilt correction also check under their separately supplied moments.

## Concrete corrections and falsifiers

The displayed signed-score error must be +gamma epsilon_k for gamma>=0,
or +|gamma|epsilon_k for either sign. A tiny negative gamma with no clipping
and zero tilt gives a direct counterexample to the unqualified form. The
producer's separate frozen addendum now states this hypothesis; the core
variance theorem is unaffected.

Applying the response theorem to the score first gives w<=kab+2epsilon_k.
W20 identified that this already excludes uniform c r^2 large-r growth.
W56 then supplied the stronger exact dual-score expectation, independently
checked by root/w49 and here:

    w=Tr zeta D_b(sigma K)<=sqrt(kab*w), hence w<=kab.

It holds for every analytic bulk prefix state and both the pair score and
the complete centered score. No KKT sign or approximate-scalar lemma is
needed. The uniform quadratic-growth hypothesis is REFUTED, while linear
growth, fixed-r improvements and reviewed rate floors remain alive.

Exact actual-coordinate checks cover12 parameter cases and134,720 Gaussian-
integer Gram entries for k<=3, including the actual root/seed rule. Ten
labelled floating operator-norm pilots pass, including charge-changing
symmetric density sandwiches. These finite checks support the implementation
and scope, not the all-k theorem. They explicitly show that inserting a
bulk cutoff changes full variance144/625 to0 in a one-call example.
At the root itself input sigma instead gives drift9/50 where the bulk
formula gives0. The source correctly excludes these invalid extensions.

## Constructive extension and its limit

A separate proof gives, for ANY Hermitian Y,

    ||D_b(sigma^(1/2)Yoff sigma^(1/2)) P_bulk||
                  <=sqrt(kab)||Yoff||_(2,sigma).

This is a full-output rectangular response bound, with a physical symmetric
density convention. It does not need total-charge preservation or a fake
commuting sigma Y. It also does not supply a new source optimum: phase
covariance shows that total-charge pinching of any positive source preserves
uniform bulk inward drift and increases entropy. New entropy/tilt identities
cannot be borrowed across that noncommuting extension without proof.

## Costs and remaining gates

The improvement replaces an analytic exponential amplification by sqrt(kab).
It does not implement clipping, pattern inverse square roots, a3^k source,
the infinite tree, quantum memory, physical gates or decoding. Existing
fixed-normal/full-reference coding, all forward calls, initializer tails,
root handling, encoding ranks and finite-error losses remain separately
required. Primary UCP/Schwarz and perfect-memory coding precedence, together
with actual retrieval failures, are recorded in `LITERATURE.md`.

No efficient complete source/receiver, calibrated physical implementation,
total energy/time/money advantage, external proof acceptance or novelty
clearance is established. The next mathematical gate is a complete positive
source with a genuinely attainable linear-scale score/drift/entropy margin
and the full original coding transfer. The refuted quadratic-variance
hypothesis must not be reinstated as a missing-but-plausible premise.
