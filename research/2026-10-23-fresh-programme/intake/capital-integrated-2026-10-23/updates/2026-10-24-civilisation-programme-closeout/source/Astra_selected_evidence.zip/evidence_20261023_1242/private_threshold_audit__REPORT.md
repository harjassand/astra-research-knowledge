# Fresh review: private Frobenius query threshold

23 October 2026. W15 independent analytic/source/native review.

**PASS: no mathematical correction requested.** This verdict binds the
exact frozen source `PRIVATE_FROBENIUS_QUERY_THRESHOLD.md`, SHA256
`fce18b8bf735210585304faef9a310a355bed4875e0125fbe808a9498d6aec34`.
It also binds the imported q4 source673e89 and its mandatory zero-noise
qualificatione44f36, already reviewed in the separate preserved packet.
No original proof or prior review bytes were edited. The original source's
historical candidate/unreviewed label remains in its frozen snapshot.

## Claim and exact measurement contract

The supplied actual support is S(K_k), k>=4, with T=k(k-1)/2 actual
degree-two mediators and N=k+T total sites. The independent unknowns are
N free diagonals and2T real symmetric couplings, p=k+3T. The matrix class
is unbounded and allows arbitrary signs. This is a different support
family from bounded-degree partial two-trees.

For each fixed unknown D and each fixed complete physical N-by-q noise
matrix E, a legal private algorithm must satisfy

    E_private ||Dhat-D||_F^2 <= C_q(k)^2 ||E||_F^2.

E is independent of the private seed, but may depend on the fixed D and
have arbitrary correlations across cells. The action at stage j can be
any measurable function of all earlier noisy observations and private
randomness. Each complete site input row across the q stages has norm
at most one, for every realized history. All Nq original cells are paid.
No hidden entry oracle, diagonal values or extra support information is
supplied. The loss is the full symmetric Frobenius loss, counting both
copies of each off-diagonal coefficient.

The source proves, with all real adaptive/global decoders in the lower:

* q<=2: no finite uniform C_q(k), for k>=4.
* q3, k>896: C_3(k)^2 >= k^2 ln(k/896)/(768N).
  Its nonadaptive rational upper is C_3(k)^2 <=1+72H_(L-1),
  L=max(2,ceil(sqrt(k))). Thus C_3(k)=Theta(sqrt(log k)).
* q4: 1/2<=C_4(k)<=14. Four is the least fixed action count with
  bounded uniform private Frobenius RMS risk as k grows.

The q3 lower is not an operator-norm lower. Norm domination transfers
an F upper to an OP upper, but cannot transfer this F lower in that
direction. No Frobenius-to-operator conversion is used in this review.

## Actual supported signal subspace and all hub observations

Fix any legal realized q3 matrix X. If any site row is zero, its free
diagonal gives an exactly unobserved unit parameter. Otherwise let v_i
be a nonzero hub row, r_i=||v_i||<=1, u_i=v_i/r_i. For each original
mediator e=ij define F_e with two actual symmetric half-edge weights
1/r_i and -1/r_j, no diagonal, and

    n_e^2=||F_e||_F^2=2(r_i^-2+r_j^-2)>=4,
    Q_e=F_e/n_e.

Different e have disjoint matrix coefficient positions, even when they
share a hub, so the Q_e form a Frobenius-orthonormal T-frame in the
actual p-dimensional signal space. They are test directions in the
unknown matrix space, not physical actuators or extra observations.

The full original action of Q_e is (u_i-u_j)/n_e at mediator e,
w_e/(r_i n_e) at hub i, and -w_e/(r_j n_e) at hub j. There are no
other nonzero output rows. Thus, with A_X the action map in an F
orthonormal basis and H_X=A_X^T A_X,

    Q^T H_X Q = diag(c_e)+B^T B,
    c_e=||u_i-u_j||^2/n_e^2 <= ||u_i-u_j||^2/4,
    B has3k rows, hence rank(B)<=3k.

Every actual mediator input w_e is arbitrary within the legal cap.
Every hub reading is included in B. Their information is paid by the
rank term, rather than discarded or presumed zero. This is the crucial
step making the lower cover unrestricted global receivers and designs.

## Inverse compression, eigenvalue ordering and the trimmed geometry

For lambda>0 the inverse-compression inequality follows from the Schur
complement of H_X+lambda I in a basis extending Q:

    tr(H_X+lambda I)^-1
      >=tr(diag(c_e)+B^T B+lambda I)^-1.

For increasing eigenvalues, a positive rank-r update obeys
lambda_j(D+B^T B)<=lambda_(j+r)(D) for j<=T-r. Reciprocation reverses
the inequality and gives the inverse-trace lower after deleting the r
smallest diagonal entries. Coordinatewise c_e<=delta_e^2/4 also holds
after increasing sorting. Consequently, using r=3k and the increasingly
sorted chord distances delta_(j),

    tr(H_X+lambda I)^-1
      >=4 sum_(j=3k+1)^T (4lambda+delta_(j)^2)^-1.

The deleted pairs really are the closest3k in this lower bound. Replacing
this with an ordinary untrimmed Riesz sum would not be valid.

For 0<a<=1, choose a maximal sqrt(a)/2-separated set on S^2. The chord
caps of radius sqrt(a)/4 have disjoint interiors and exact area pi*a/16.
There are at most64/a centers. Maximality covers S^2 by chord caps of
radius sqrt(a)/2. Assigning points to covering caps yields a partition
into at most64/a cells of chord diameter at most sqrt(a). Cauchy on
the cell occupancies therefore supplies at least

    k^2 a/128-k/2

unordered pairs with squared distance at most a. Removing any3k pairs
leaves R(a)>=k^2 a/128-7k/2. For a>=a0=896/k this is at least k^2 a/256.
The conclusion covers collisions, repeated directions and clustering.
Boundary intersections of closed caps have zero area and do not affect
the packing count.

With lambda=k^-3 and k>896, 4lambda<=a0<1. Each remaining pair's positive
reciprocal dominates its contribution to the layer integral on[a0,1].
Hence

    sum_trim (4lambda+delta^2)^-1
      >= integral_(a0)^1 R(a)/(4lambda+a)^2 da
      >= (k^2/1024) ln(k/896),

because (4lambda+a)^2<=4a^2 there. Combining with the previous factor4
gives tr(H_X+k^-3 I)^-1 >= k^2 ln(k/896)/256.
If any row of X is zero, the one unobserved free diagonal already gives
inverse trace at leastk^3, larger than this bound. This establishes the
resolvent inequality pointwise for every legal X, without an amplitude
lower bound or a compactness/genericity assumption on the design.

## Adaptive private Bayes step and noise timing

The finite test prior is theta~N(0,sigma^2 k^3 I_p), in the F
orthonormal basis. The complete test E has iidN(0,sigma^2) original
cells, drawn independently of theta and all private randomness. This
is a permitted mathematical distribution over fixed D,E for the uniform
claim; it is not an assumed or acquired physical noise law for the upper.

Conditioning on a private seed and a complete observed y fixes each
x_j(y_<j). The joint conditional observation density is a product of
the sequential Gaussian kernels. As a function of theta its exponent is
exactly sum_j ||y_j-D(theta)x_j(y_<j)||^2/(2sigma^2). There is no
theta-dependent policy-choice density or change-of-variables Jacobian:
queries are deterministic functions of the already conditioned past.
The usual conditional-density assertions need only hold almost everywhere;
the pointwise legal-X bound covers every such realized query matrix.

Completing the square gives posterior covariance

    Sigma_y=sigma^2(H_(X(y))+k^-3 I)^-1.

The posterior mean is the optimal conditional F squared-loss decoder.
Any decoder has conditional risk at least tr(Sigma_y), at least
sigma^2 k^2 ln(k/896)/256 by the uniform geometric bound. Tonelli can
integrate the hypothesized per-fixed-D,E risk inequality, giving the
opposing upper3N C^2 sigma^2. Their comparison proves the displayed
q3 lower with denominator768N.

This argument permits exact-real, discontinuous measurable adaptive
policies. It does not condition on a fixed design while forgetting that
the design depended on data: that dependence is retained in X(y).
There is no diffuse-prior/adaptive-design limit exchange. A policy's
entire future random choices may be included in its initially conditioned
private seed, independent of D,E.

For q<=2, rank(H_X)<=qN and p-qN>=T-k>0 for k>=4. At any finite prior
variance tau^2, posterior covariance has at leastp-qN eigenvalues tau^2,
even though the nullspace may vary with y. Its trace lower can be made
arbitrarily large by choosing a larger permitted finite prior. The
assumed risk upper remainsqN C^2 sigma^2. No finite C can satisfy both.
This is a Bayes dimension obstruction for adaptive/private acquisition,
not an invalid extension of a fixed zero-transcript argument.

For any fixed q, a free diagonal's information entry is the corresponding
complete input-row norm squared<=1. The positive inverse diagonal is at
least1/(1+lambda). Summing only those N coordinates and repeating the
finite-prior calculation gives C^2>=1/[q(1+lambda)] for every lambda>0.
The scalar limit implies C^2>=1/q, supplying the q4 lower1/2. This
last limit does not interchange a policy-dependent expectation and a
diffuse prior.

## Matching q3 upper, precision and free diagonals

The positive rational stereographic code uses the two-dimensional grid
z in{1,...,L}^2 and u=(4Lz1,4Lz2,4L^2-||z||^2)/(4L^2+||z||^2).
It has unit rows, distinct non-antipodal points, O(k) candidates and
O(log k)-bit coordinates. Assigning k distinct labels without replacement
makes each endpoint pair uniform among distinct labels.

For each actual mediator the orthogonal complement of its two hub codes
is one-dimensional. Its rational rank-one projector has maximum diagonal
p>=1/3. The actual row w=P e_max satisfies ||w||^2=p, with both endpoint
inner products zero. The q4 receiver's hub and mediator diagonal formulas
therefore remain exact, while ordinary two-column LS recovers the two
couplings. No free diagonal information is given. A rational unit normal
is neither required nor silently implemented.

The sphere identity now has J<=9/4, yielding
1-rho^2>=16||z-z'||^2/(81L^2). Integer infinity shells have8r points,
so the distinct-pair inverse moment satisfies

    A_L <=(81/2) L^2 H_(L-1)/(L^2-1) <=54 H_(L-1).

The mediator's full symmetric-loss trace is1/p+4/(1-rho^2), at most
3+4/(1-rho^2). The complete48-element signed-permutation average divides
that trace by3, while a hub's contribution is1/3. The physical E remains
fixed while the seed varies. Summing gives C_3(k)^2<=1+72H_(L-1).
All comparisons are correctly non-strict at zero noise, where recovery
is exact for every encoded outcome.

The q4 constant upper uses the separately source-bound reviewed theorem
and mandatory zero-noise qualifier. Its three-dimensional code chart has
a bounded inverse-square moment, in contrast to the critical harmonic
sum on the q3 two-dimensional chart. The lower establishes that no real
adaptive policy can eliminate the q3 logarithm in this specific F-risk
model; it is not merely a deficiency of the local upper decoder.

## Independent exact native audit

`audit.py` is a new standalone Fraction implementation. It does not
import or run any producer or earlier peer checker. In q3 it reconstructs
the actual projector from a cross product, independently of the producer's
I-U(U^TU)^-1U^T implementation. It binds all source/raw/receipt bytes in
`SOURCE_BINDING.json`. `AUDIT_RESULTS.json` records:

* All543 original cells of the k9/N45 and k16/N136 free-diagonal native
  cases: exact input, DX, fixed physical E, observed data, full decoded
  matrix, symmetric F error, energy, peak and individual input-bit counts.
* All156 pair/projector records and the complete48 signed column group.
* All1,152 outcomes of the complete fixed-E k3 experiment,20,736 actual
  seed/action cells. The exact mean full-matrix loss equals the trace
  formula and the exact matrix bias is zero. E is held fixed throughout.
* The full3,024 original restricted-basis action cells for arbitrary
  nonorthogonal mediator inputs at k8. Their exact Gram is diag(c)+B^TB,
  rank(B)=21; both the actual-rank and3k deletion bounds, sorted geometric
  comparison and complete restricted inverse trace agree.
* The full22-parameter q2/q3 information cases. q2 actual nullity is3,
  stronger than the necessary dimension lower2. Besides the recorded
  inverse traces, an independent exact PSD Schur calculation verifies
  the Loewner inverse-compression inequality, with the raw coefficient
  Frobenius metric diag(1 on diagonals,2 on edges) explicitly retained.
* All20 recorded likelihood square completions at four causal histories.
  A further independent policy on actual S(K4),22 parameters, uses
  nonlinear bounded feedback from earlier outputs. Four new complete
  histories and20 new parameter tests verify its exact Gaussian precision
  and square completion. Its whole-row energy is<=3/16 for every history.
* The retained large-k cap/trim checks were verified as scalar coefficient
  identities, not mislabeled large-graph action data.

The body ran in1.491150167 wall seconds,1.419371 CPU seconds and
49,119,232 bytes peak macOS RSS, excluding analysis, literature and
reporting. No physical samples, private entropy or large asymptotic
operator actions were acquired. These finite cross-checks support the
implementation and bookkeeping; the preceding analytic reconstruction
is what audits the universal/all-policy assertions.

## Primary prior and equally informed ordinary methods

The primary [Hardin--Saff source](https://arxiv.org/pdf/math-ph/0311024)
was freshly read, including Theorem1.2 at printed page4 and Lemma3.1.
It records the ordinary critical sphere energy of orderN^2 log N,
credits earlier sphere results, and notes its ordered-pair normalization.
The retrieved PDF also contains an addendum. This context does not
prove a lower after removing3k pairs; the reviewed cap/count/integral
argument supplies that missing step directly. No new general Riesz
energy theorem is inferred.

The primary [Amsel et al. paper](https://arxiv.org/pdf/2402.09379) and
[Musco--Ramesh paper](https://arxiv.org/html/2606.12179v1), already read
in the immediately preceding frozen review, retain randomized local LS,
inverse-Gram means and degeneracy-based matrix querying as strong ordinary
incumbents. They have their own Gaussian query/off-pattern error models;
neither was presented as literally establishing this finite rational
bounded-row absolute-noise threshold. An additional adaptive-Gaussian
literature query returned a PMC anti-bot page; that page was not used as
proof or bypassed. The posterior calculation here is self-contained.

The q3 rational upper and all its measurements are available to an equally
informed ordinary method. The q4 continuous-real unit-sphere/unit-projector
comparator has better squared constant9/4, RMS3/2, within its ideal exact
continuous-randomness/irrational-control contract. Thus the threshold
does not establish superiority over general conventional probing. The
specific theorem's historical priority remains UNKNOWN; the Gaussian,
rank-interlacing and potential-theory ingredients are established.

## Acquisition and complete-cost limits

The upper's grid has O(k) candidates. Preparing and sampling labels uses
O(k) word operations/storage and O(k log k) expected unbiased random bits;
exact rejection sampling has no fixed worst-case draw length. The column
group uses constant expected entropy. Every actual mediator projector and
receiver is prepared: O(T)=O(N) fixed-dimensional rational arithmetic and
storage. Individual coefficients have O(log k) additional bits; sums,
signal/noise magnitudes and exact output encodings can cost more. This
is not a unit-cost finite bit-time or physical calibration assertion.

Acquisition costs3N or4N full original readout cells, with all mediator
inputs real actuators. Supported output hasp=N+2T independent scalars;
dense output hasN^2 positions. Each upper has S>=k+T/q, so its global
per-action peak is at leastS/q=Omega(k^2). A private column permutation
reorders rather than balances it. A fixed peak cap requires extra
actions/readouts; constantq is not constant power, energy or bandwidth.

The full absolute F noise budget differs from a fixed per-cell noise
law. Input calibration leakage D DeltaX can depend on the private seed
and be arbitrarily large over this unbounded D class. Such leakage is
outside the upper's fixed-seed-independent-noise promise. Support, exact
signed/rational site controls and zeros, stationary D, full access,
reset/readout, private entropy and justified noise independence are
supplied or unacquired resources, not consequences of the proof.

The lower requires the unbounded real signal class to choose arbitrarily
large finite Gaussian priors. A bounded-height, bounded-magnitude,
positive-only or row-sum-constrained signal class requires a new lower
argument. It is not licensed by this theorem automatically.

## Verdict, corrections and open obligations

No correction to the frozen threshold proof is requested. Its imported
q4 zero-noise qualification remains mandatory and is explicitly bound.
No formal proof certificate or external correctness verdict was acquired.
Historical priority: UNKNOWN. Physical validation: UNACQUIRED. Practical
advantage: NOT_ESTABLISHED. Mission: NOT_ACHIEVED.

Decisive mathematical falsifiers would be an omitted hub output, wrong
F norm normalization, reversed rank interlacing, an invalid trimmed count,
an extra theta-dependent adaptive likelihood factor, or an actual q3
projector/diagonal cancellation failure. The exact checks and reconstruction
found none. Relabeling the q3 F lower as an OP lower is an immediate scope
failure even with correct algebra.

The next steps should acquire a useful actual interface with paid
peak/calibration/noise privacy, search precise historical priority, or
change a load-bearing premise and derive the new theorem. A separate
W15 continuation investigates whether a supplied row-sum conservation
law allows volume-distributed hub codes to escape the normalized-sphere
obstruction. It is not part of this completed review verdict.
