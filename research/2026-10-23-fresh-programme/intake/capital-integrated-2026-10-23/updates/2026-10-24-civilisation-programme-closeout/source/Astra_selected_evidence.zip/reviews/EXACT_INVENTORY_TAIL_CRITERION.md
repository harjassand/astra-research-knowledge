# Independent exact-tail criterion and operational audit

**Frozen proof audit: PASS. The separable/PPT threshold is exact for the
stated nested Bell-prefix/independent-white-tail family. Every violation is
one-copy distillable and gives a strictly positive unassisted rate beyond
the exact mandatory prefix under the original fixed-source-first contract.**

Reviewer w44, 23 October 2026. This fresh derivation preceded reading the
peer's preferred verdict. Audited file:
`work/workers/w38_fresh_inventory_critic/EXACT_TAIL_CRITERION.md`, SHA256
`b00975d09fda2da275e40c33a1f24e487cbdf90ff340f97f3e6f20287aea7b6a`,
retained verbatim as `w38_exact_tail_snapshot.md`. Source HEAD was rechecked:
`e606bfc587c76bdcae8b8fa3ec33e721efa2fbac`. Previous w44 general-prior,
dimension-free and collective frozen audit files remain unchanged.

## 1. Exact state and independent eigenvalue derivation

Fix finite D>=2, n>=1, p_j>=0 and sum_(j=0)^n p_j=1. Define

    sigma_j=Phi_D^tensor j tensor nu_D^tensor(n-j),
    eta=sum_j p_j sigma_j,
    S=sum_(j>=1) p_j D^j.

The bipartition is ALL of Alice's sites versus ALL of Bob's sites. Local
operations may couple sites within one party. The theorem is not about
separability across 2n individually separated observers.

At site i, Phi_D^Gamma=F_i/D and nu_D^Gamma=I/D^2, where F_i is swap.
Consequently

    eta^Gamma=D^(-2n)[p_0 I+sum_(j>=1)p_j D^j F_1...F_j].   (T1)

The swap operators commute. Each has both signs with nonzero eigenspaces
because D>=2. If f_i is its sign, the cumulative signs t_j=product_(i<=j)f_i
range independently over {-1,+1}: f_1=t_1 and f_j=t_(j-1)t_j. Since all
coefficients p_j D^j are nonnegative, the exact least eigenvalue is

    lambda_min=D^(-2n)(p_0-S).                             (T2)

One explicit minimizing vector is

    (|01>-|10>)/sqrt(2) on site 1,
    |00> on every later site.

Its first swap sign is -1 and all later swap signs are +1, so every prefix
product is -1. As a vector across the full Alice:Bob partition it has
Schmidt rank 2. This directly supplies a one-copy distillability witness
whenever (T2) is negative; the filter below also gives an explicit protocol.
Zeros in p do not affect the argument. There is no unproved assumption that
the different prefix signs can be minimized simultaneously: the displayed
vector does so.

## 2. PPT sufficiency by a nonnegative separable mixture

For d=D^j, the isotropic boundary state

    zeta_d=(I+d Phi_d)/[d(d+1)]
          =[d nu_d+Phi_d]/(d+1)

is separable. Grouping the first j digits locally identifies their Bell
tensor product with Phi_(D^j). Let

    tau_j=zeta_(D^j) tensor nu_D^tensor(n-j)
         =[sigma_j+D^j sigma_0]/(D^j+1).

If p_0>=S, define w_0=p_0-S and w_j=p_j(D^j+1). Then all w are
nonnegative, w_0+sum_j w_j=1, and

    eta=w_0 sigma_0+sum_(j>=1)w_j tau_j.                  (T3)

Every term is separable across the original A:B cut. This proves PPT
sufficiency by an exact normalized decomposition. Necessity follows from
(T2) and the ordinary partial-transpose necessary condition. Thus

    eta is PPT iff eta is separable iff p_0>=S.            (T4)

The isotropic comparison need not be physically prepared; it is a
mathematical separability witness. Finite-dimensional Caratheodory also
replaces its Haar-product representation by a finite product mixture if
needed. No efficient mixture compilation follows.

## 3. Literal local filter and all success costs

Alice and Bob separately project every site after the first onto their
native |0> basis vector. Each projects its first site onto the two-level
span of |0>,|1>. The joint success event is determined by communicating
their LOCAL measurement outcomes. It does not measure K or any inaccessible
clock.

For j=0 the unnormalized four-dimensional output is p_0 D^(-2n)I_4.
For j>=1, projection of its first Phi_D is (2/D)Phi_2; each of its other
j-1 Bell sites contributes probability 1/D, and each white site contributes
probability 1/D^2. Summing gives exactly

    eta_success=D^(-2n)[p_0 I_4+2S Phi_2].                 (T5)

Therefore

    q=D^(-2n)(4p_0+2S),
    f=<Phi_2|eta_success/q|Phi_2>
      =(p_0+2S)/(4p_0+2S).                               (T6)

For every normalized law and n>=1, 0<q<=1. The filtered state is a qubit
isotropic state, and f>1/2 exactly when S>p_0. The omitted outcomes are
ordinary failures; none is conditioned away in the original copy count.
For p_0=0 the success state is pure Phi_2, which is consistent with a
mandatory first tail Bell pair. In the original k0=min supp K formulation,
p_0 is positive by definition.

For f>1/2, run finitely many BBPSSW recurrence rounds, each followed by a
finite bilateral qubit twirl preserving f. With e=1-f, the actual success
probability and next fidelity are

    P=f^2+(2/3)fe+(5/9)e^2,
    f_next=(f^2+e^2/9)/P.                                 (T7)

Each round uses two inputs per attempted output, so its retained fraction
is P/2. Directly f_next>f for 1/2<f<1, and the iteration tends to 1.
Choose any fixed finite number m sufficient for f_m>=0.9; ordinary
unassisted Bell-diagonal hashing then has positive rate

    h_m=ln2-h2(f_m)-(1-f_m)ln3>0.

The paid tail-rate certificate is

    R_tail >= q product_(i=0)^(m-1)(P_i/2) h_m >0,         (T8)

where the operational statement uses any strictly smaller rate. For f=1,
take zero recurrence rounds. Neither borrowed Bell stock nor a free seed
is required: the primary source explicitly distinguishes breeding from
unassisted hashing and states the same yield for the latter.

This checks both parts of the implication often hidden by the phrase
"NPT implies distillable": this family has an actual one-copy rank-2
projection, and its output lies in the explicit f>1/2 qubit regime with
a finite recurrence-to-positive-hashing protocol.

## 4. Reliable fixed rank, iid conditioning and complete residual

At fixed D,n,p with S>p_0, q and every P_i are strictly positive constants
BEFORE r grows. Apply the filter separately to r iid complete queues.
Their binary success flags have the binomial iid law. Conditional on any
flag pattern, all successful quantum marginals equal the same normalized
state in (T5), independently. Thus selecting the first deterministic
m_0=floor(r(q-delta)) successes yields the required iid qubit input on
every nonshortage branch. The flag pattern and original clock may remain
correlated with the complete residual; only the quantum marginal iid
statement is used by distillation.

At recurrence stage i, pair a predetermined input count and retain a
deterministic count strictly below its mean success count. With finitely
many stages and fixed positive probabilities, all shortage probabilities
vanish by elementary concentration. On every shortage branch output a
product filler at the same declared final rank. Apply a fixed-output
unassisted hashing code on the nonshortage branch. A strict rate slack in
(T8) accommodates all deterministic stage budgets and integer rounding.
Total Bell marginal infidelity tends to zero, with no favorable-branch or
expected-rank target.

For ANY actual output omega_QW and Bell marginal infidelity delta_out, the
pinned pure-output argument gives

    T(omega_QW,Phi_N tensor omega_W)
       <=sqrt(delta_out(1-delta_out))+delta_out
       <=2 sqrt(delta_out).                              (T9)

It uses the OWN actual residual omega_W. Include all original clocks and
old memory, filter successes and failures, bilateral twirl seeds,
recurrence outcomes, hashing transcripts, discarded inputs and shortage
flags there. This verifies the complete governing error contract without
assuming an independent or preferred residual state.

## 5. Exact common-prefix capacity classification

For the original prior let k0=min supp K and J=K-k0. Either use
n=L-k0 with zero probabilities allowed at its end, or n=max supp K-k0 and
keep the remaining independent white sites as a separate trailing factor.
The accessible source is exactly

    Phi_D^tensor k0 tensor eta_p tensor nu_trailing.

The pure prefix marginal factors from the COMPLETE preparation, including
its inaccessible clocks and old memory. It supplies exactly k0 ln D nats
per queue at zero error by direct retention.

If (T4) holds, compare the accessible source with the separable state

    chi_D^tensor k0 tensor eta_p tensor nu_trailing,
    chi_D=(1/D)sum_a |aa><aa|.

The relative entropy is exactly k0 ln D. For every finite admitted
receiver with complete half-trace error epsilon<1/2, the binary Bell test
therefore gives

    (1-epsilon)ln N <= r k0 ln D+h2(epsilon).              (T10)

Normal independent local apparatus is handled by the same preserved normal
finite-tree argument as in the governing converse. No inaccessible flag
was passed to the receiver or included as an available entanglement supply.
Taking r first proves R(p)<=k0 ln D. Together with retention this is equality.

If (T4) fails, retain that exact prefix untouched and apply (T8) to the
tail. The final target rank is the exact prefix rank times the fixed
qubit-code rank on ALL branches. Equations (T8)-(T9) prove

    R(p)>k0 ln D.

Thus the frozen iff criterion is valid. It does not require or prove the
general additivity identity R(Phi^k0 tensor eta)=k0 ln D+E_D(eta); the
separable upper bound and a positive tail lower bound suffice separately.
The n=0 case is simply the exact prefix plus independent white noise.

## 6. Entropy obstruction and practical scale

On the PPT side,

    E[D^J]=p_0+S<=2p_0<=2.

Jensen gives EJ<=ln2/ln D<=1. The geometric maximum-entropy bound for a
nonnegative integer of mean at most one yields

    H(K)=H(J)<=2 ln2.

Hence exact common-prefix-rate laws cannot form a growing-entropy family.
This excludes that particular strategy for a second-order counterexample.
It gives no uniform positive lower bound on the excess rate when the
criterion fails; the strict excess can be extraordinarily small.

The literal success q in (T6), every P_i/2, and the hashing loss are already
charged per ORIGINAL input queue. Preparation of r complete queues,
storage of their D-level systems, local projection precision and failures,
local two-pair gates, readout, finite twirl seeds, communication, retained
records, code descriptions and resets are actual costs. No physical method
of preparing this ideal source or implementing those instruments has been
acquired. There is no uniform blocklength/precision bound as n,D,p vary.

For scale only, the synthetic admissible qubit fidelity
f=1/2+10^(-30) took 376 recurrence rounds in a 120-digit Decimal calculation
before crossing 0.9. The resulting retained fraction was about
1.2409121661e-208 and the certified rate was about 4.0107195629e-209 nats
per FILTERED input, before multiplying by q. These are mathematical
calculations, not acquired data or a proposed practical distiller. The
source-first order of limits is essential to the strict positivity claim.

## 7. Independent finite evidence

`check_exact_tail.py` imports no peer code. It builds literal Phi_D and
white local matrices, tensors them, mixes with exact Fraction probabilities,
and performs the partial transpose by native index exchange. For all
swap-sign characters it checks the literal matrix action, exact eigenvalue,
multiplicity trace and trace-square, and the exact minimum. It filters the
native matrix directly to the retained four dimensions and checks all
matrix entries, success probability and fidelity. On the PPT side it
reconstructs the full matrix from (T3).

It also enumerates the 16 Bell-label input combinations of bilateral CNOT
and target equality measurement, independently obtaining (T7). Five rounds
per NPT test are checked with exact Fractions. Longer recurrence and
positive hashing certificates use 120-digit Decimal arithmetic.

PASS: 357 laws, including 54 literal tensor-matrix cases for D in {2,3,5},
n up to 4; 300 additional scalar/swap-sector cases with D up to 71 and n
up to 8; 3 n=0 cases; exact below/equal/above threshold, zeros, pure tail,
and near-threshold tests. There were 177 PPT and 180 NPT cases. No physical
experiment or actual quantum coding implementation was run.

Checker SHA256:
`7531e9ab77697fa15168053e0bf0bf847fb3ed54db2648e1aa9ab498698e8f7b`.
Summary `exact_tail_checks.json` SHA256:
`32de1207293e1779edd575a2c0c4d5637a2832c714434353dd35514073643dd7`.
Raw `exact_tail_cases.json` SHA256:
`438ffdabc58af1badb19f43dee86e63da160794d0c522bec96c5fda51fc7d982`.
The analytic proof supplies universality; finite checks only challenge it.

## 8. Primary prior-art boundary and status

Bennett et al., *Purification of Noisy Entanglement and Faithful
Teleportation via Noisy Channels*, quant-ph/9511027v2, equation (7), gives
the recurrence, and the later unassisted-hashing paragraph states its
positive entropy yield without breeding stock. This is credited old
machinery. [Primary text](https://arxiv.org/html/quant-ph/9511027v2).

Horodecki, Horodecki and Horodecki, *Distillability of Inseparable Quantum
Systems*, quant-ph/9607009v2, proves the general two-qubit filtering and
positive-yield principle. Its efficiency calculation likewise multiplies
filter and later distillation yields. [Primary text](https://arxiv.org/html/quant-ph/9607009v2).

Chruscinski and Kossakowski, *On multipartite invariant states I. Unitary
symmetry*, quant-ph/0601027v2, Sections III-IV, already studies independent
pairwise isotropic invariance, swap/projector coordinates, generalized
partial-transpose transforms and separability. Our eta lies in that broad
invariant family. A narrow search did not identify the exact nested
p_0-versus-sum p_j D^j formula or this specific common-prefix operational
classification there; that is not a priority clearance. Its broader
multi-PPT assertions are not used as premises of this proof, and different
multipartite cuts must not be conflated. [Primary text](https://arxiv.org/html/quant-ph/0601027v2).

Exact HTML bytes, parsed text, URLs, byte counts and hashes are preserved
in `tail_primary_manifest.json` (three successful primary retrievals).
The governing source already treats the two-point isotropic special case;
this result extends the exact structural criterion to the stated finite
nested family. It does not invent PPT, isotropic separability, local
filtering or recurrence/hash distillation.

Final status: frozen proof independently passes this internal audit.
Historical novelty and external correctness remain UNKNOWN; computational
advantage, physical validation and practical value are NOT_ESTABLISHED.
Mission: NOT_ACHIEVED.
