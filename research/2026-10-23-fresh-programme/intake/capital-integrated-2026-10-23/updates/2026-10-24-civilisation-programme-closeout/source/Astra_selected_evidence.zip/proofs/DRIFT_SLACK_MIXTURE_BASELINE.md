# Exact convex-mixture baseline for spending a strict drift margin

This is an equally informed elementary baseline for any claimed Gibbs or
pressure-inheritance gain. It changes the chosen input density, not the
physical recurrent device. All quantities below concern its exact bulk drift.

Let a=1-beta^2>0, and suppose an existing Q-preserving input rho0 has

`D(rho0)<=-kappa I`, `S_2(rho0)>=3k/2+g`.

For any0<delta<k/2 take the original DIAGONAL exponential charge tilt

```
tau_delta=sigma T_delta,
T_delta=exp(lambda(Q-k/2))/cosh(lambda/2)^k,
lambda=2 artanh(2delta/k).
```

It is a legitimate product qutrit density. The exact complete-pattern
diagonal displacement gives

`D(tau_delta)=2a delta I`,
`S_2(tau_delta)=3k/2+delta-D_tilt(delta)`.

Choose0<eta<kappa and the scalar weight

`eps=(kappa-eta)/(kappa+2a delta) in(0,1)`.

The UNFLAGGED physical input density
`rho_mix=(1-eps)rho0+eps tau_delta`
is normalized, positive, full rank and Q-preserving. Drift linearity gives

`D(rho_mix)<=-eta I`.

Entropy concavity, without any retained private coin supplied to Bob, gives

`S_2(rho_mix)-3k/2 >= g+eps[delta-D_tilt(delta)-g]`.       (M1)

No spectral optimization or Gibbs factory is needed to establish this lower
bound. Preparing rho0 itself remains the same enormous unresolved source
cost; this does not claim a practical preparation operation.

For fixed g,kappa,a and k->infinity, choose delta->infinity with delta=o(k).
The elementary binary tilt estimate D_tilt/delta->0 then yields an additional
block entropy tending to

`(kappa-eta)/(2a)`.

For example delta=k^(1/3) satisfies the conditions. A vanishing target eta
may approach the full kappa/(2a) slack but remains POSITIVE and fixed for
each chosen beta,k before the outer coding horizon. The inherited Lyapunov
and decoder costs depend on this smaller margin and must be retained.

For the reviewed V4 CERTIFICATES g=t0/31 and kappa=t0/480, the small-beta
relative asymptotic increase certified by (M1) approaches the baseline factor

`1+31/960 =1.032291666...`

as eta/kappa->0 and a->1. This is a lower-certificate improvement obtained
by spending old strict drift, not evidence of an improved mechanism. In
particular, an inherited-pressure Gibbs gain of about3.2% should not be
credited as an advantage over this simpler equally informed construction.
The general PSD entropy optimizer may improve further, but must prove it.

Every call still counts. Source full rank implies the3^k type-code cost;
smaller eta worsens root-return and finite-horizon costs. No physical input,
coin source, reset, source factory or logical code was acquired. External
acceptance, originality and practical usefulness remain UNKNOWN.
