# Bounded spectral norm supplies an acquired collision annihilator

Version1,23October2026. Complete proposed proof; fresh independent review
PENDING. The integer quantitative Cohen theorem and the reduction from a
uniquely covered input to rectangular Avoid are CLASSICAL. The possible new
bridge is the low-degree collision annihilator and its actual NP acquisition.
Historical priority/external validation/ordinary-time advantage are UNKNOWN.

## 1. The degree-parametric algorithm, with no structural promise

Let F=(P,g):F2^n->F2^(n+1) be explicitly evaluable by polynomial-size Boolean
circuits, and let integer D>=1 be a parameter. No quadraticity is required in
this section. Set

    C={y in F2^n:|P^-1(y)|>=2},
    M=M_D=sum_(j=0)^min(D,n) binom(n,j).

Use the FULL squarefree degree<=D Boolean monomial vector v_D(y), including
the constant monomial1. There is a deterministic uniform ordinary-NP-oracle
algorithm which returns a missing word of F if C has a nonzero degree<=D
Boolean annihilator, and returns OUTSIDE_DEGREE_D_CLASS exactly otherwise.
All successes are sound on every input. No count, classifier, affine frame,
spectral table, proper representation, low-deficit promise or advice is supplied.

Maintain E, initially the zero span in F2^M. Ask NP for distinct x,x' such
that P(x)=P(x') and v_D(P(x)) lies outside E. Each YES is actually extracted
by at most2n input-prefix queries. Add the resulting independent evaluation
row to E. At most M rows can be added. If E reaches dimension M, stop and
return OUTSIDE_DEGREE_D_CLASS; already acquired rows rule out any annihilator.
Otherwise a terminal NO certifies

    E=span{v_D(y):y in C}.                        (1)

This is an acquired COMPLETE span, not a finite sample assumed representative.
If the very first query is NO, C is empty and the square map P is a
permutation. Return (P(0),1+g(0)), a missing word of F.

Otherwise, since E is proper, compute any nonzero coefficient vector in
E^perp and let R be its Boolean ANF. Distinct squarefree monomials are
linearly independent as Boolean functions, so R is genuinely nonzero, and
(1) means R vanishes on ALL collision outputs. Find an explicit y with R(y)=1
in P: choose an inclusion-minimal monomial with nonzero coefficient and set
exactly its variables to1. No proper submonomial contributes and no other
monomial is contained in that support, so this evaluation is1. A nonzero
constant term gives y=0 directly. Equivalently, successive nonzero ANF
restrictions yield such a y in polynomial bit time.

Because y is not in C, its P-fiber has size at most1. Ask NP whether it has
a preimage. If NO, return(y,0), a rectangular hole. If YES, extract the
preimage x with at most n prefix queries; it is UNIQUE. Return(y,1+g(x)).
Every potential preimage would have to be x but has the opposite last bit.

The last case distinction is essential: y outside a proper COLLISION hull
or polynomial closure need not be a singleton output; it could itself be a
square hole. Both alternatives solve rectangular Avoid with this NP branch.
Thus no proper WHOLE-DEFECT hull or Gauss-zero condition is needed here.

A safe total number of ordinary NP decision calls is

    Q_D(n)=(2n+1)*M_D+n+2.                       (2)

The at-most-M self-reduced pair witnesses and one terminal NO account for
the first term plus1; preimage existence/extraction account for n+1 more.
An early full-span abort needs no terminal NO. The exact all-input rank cap
keeps the same clock off promise. For n=0 directly flip the unique output bit.

Queries physically contain the input circuit, ALL M monomial slots and an
M-by-M dense row-space field FROM THE FIRST QUERY, plus public prefix data.
Let S_F be the circuit-description/evaluation-size bound. Maximum query
length is O(S_F+M_D^2+n^2). A safe total outside bit-work bound is

    O((S_F+n+1)^4*(M_D+1)^4).                    (3)

It includes monomial enumeration, linear algebra, query serialization and
the final evaluations. One fixed ordinary NP language verifies the tagged
pair/preimage predicates using only P evaluation and explicit GF2 algebra;
the witnesses have2n or n bits. There is no coNP predicate inside a verifier.
Physical padding makes verification polynomial in ACTUAL query length even
for binary variable D. For fixed D this is FP^NP; for growing D the displayed
M_D costs are paid and no polynomial-time claim is made.

For F with n+1 outputs and no preferred projection, actually try the n+1
coordinate projections P_j, with the removed bit as g. This uses at most
(n+1)*Q_D(n) decisions and the corresponding polynomial outside work. It
recognizes exactly whether some enumerated coordinate projection's collision
set has such an annihilator. No arbitrary good affine projection is guessed
and checked for free.

## 2. An affine-arrangement lemma with an explicit degree bound

Let w:F2^n->R be ANY function expressible as

    w(y)=sum_(i=1)^t alpha_i*(-1)^(a_i.y+b_i)*1_Di(y), t<=C,          (4)

where D_i are affine flats, C>=1 is an integer and the alpha_i are real.
Let Cplus={y:w(y)>0}. Assume |Cplus|<=2^(n-1). Set

    s=ceil(log2(4C)), D_C=C*(s+1).                (5)

Then Cplus has a NONZERO Boolean annihilator of degree at most D_C.
No assumption about the flats' codimensions, independence, overlap, proper
union learning or the numeric sizes of their coefficients is used.

Proof. Call a flat high-codimension if codim D_i>=s. The union of all such
flats has density at most C*2^(-s)<=1/4. Together with Cplus, of density at
most1/2, this covers at most3/4 of the cube. Choose a point y0 outside both.
In particular w(y0)<=0, and no high-codimension D_i contains y0.

For each D_i construct a Boolean factor r_i taking value1 at y0:

* If y0 lies in D_i, it is low-codimension. Take its actual affine indicator,
  a product of codim D_i<s independent affine linear equations, of degree<s.
  This fixes membership in D_i to1 on r_i=1.
* If y0 is outside D_i, choose ONE affine linear separator that vanishes on
  D_i and takes value1 at y0. This fixes membership in D_i to0 on r_i=1,
  regardless of how large that flat's codimension is.

For each character also multiply the affine factor

    h_i(y)=1+a_i.y+a_i.y0.

It is1 at y0 and fixes that character's value to its value at y0. Constants
a_i=0 give the harmless factor1; b_i is already constant. The product

    R(y)=product_i r_i(y)*h_i(y)                  (6)

takes value1 at y0, so is NONZERO even after Boolean squarefree reduction.
Each r_i has degree at most s-1 (because s>=2), and each h_i at most1.
Thus degree R<=t*s<=D_C; (5) is a safe deliberately loose upper bound.
On R=1 all support indicators and all character values in(4) equal their
values at y0, so w(y)=w(y0)<=0. Hence R vanishes on Cplus, as required.

This is an EXISTENCE proof of a low-degree annihilator. The actual algorithm
in Section1 acquires it by collision pairs and complete evaluation spans.
It does NOT receive the point y0, the flats, their codimensions, coefficients
or character phases. Those proof objects are not classifier or advice input.

For a square map P, Cplus={y:|P^-1(y)|>=2} always obeys |Cplus|<=2^(n-1),
since every such output consumes at least two of the2^n inputs. Thus the
density assumption in this lemma is automatic for the application, including
small n. No finite exceptional-size wrapper is needed.

## 3. Exact integer normalization for arbitrary square quadratics

Let P:F2^n->F2^n have explicit quadratic Boolean ANFs. Put

    K=ceil(n/2), L=2^K,
    w(y)=|P^-1(y)|-1, H=|{y:w(y)=-1}|,
    W(a)=sum_y w(y)*(-1)^(a.y), f(a)=W(a)/L.       (7)

At the origin W(0)=0. For a!=0, W(a) is the unnormalized Gauss sum of the
quadratic a.P. Such a sum is zero or +/-2^(n-rank/2), with an even polar
rank<=2*floor(n/2). It is therefore ALWAYS divisible by L. Consequently
f is INTEGER-VALUED for every square quadratic P, without any hole-count
or one-band/ternary assumption.

Use normalized Fourier transform on f, namely

    fhat(y)=2^(-n)*sum_a f(a)*(-1)^(a.y).

Exact Fourier inversion gives fhat(y)=w(y)/L. Square mass balance gives
sum_y |w(y)|=2H. Thus

    ||f||_A=sum_y |fhat(y)|=2H/L.                (8)

No factor2^n, origin correction or advice-dependent denominator is omitted.
In particular H<=c*L for a FIXED positive integer c implies ||f||_A<=2c.
This allows amplitudes beyond {0,+/-L} and arbitrary repeated fibers.

## 4. The exact classical theorem used, with its unresolved constant

Primary source: Green--Sanders, *A quantitative version of the idempotent
theorem in harmonic analysis*, arXiv:math/0611286v2,2February2007,
Theorem1.3, later Annals of Mathematics168(2008),1025--1054:
https://arxiv.org/html/math/0611286v2 . Directly read and independently
rechecked23October2026. It applies to INTEGER-valued functions on finite
abelian groups, not just0/1 functions. For norm<=M it gives a signed sum
of at most exp(exp(C_absolute*M^4)) affine-coset indicators, with a universal
finite absolute constant. A numerical valid constant is NOT_EXTRACTED here.

For fixed c choose any valid integer C_c>=1 bounding that signed-coset count
at M=2c, uniformly in n and in the input P. Then

    f(a)=sum_(i=1)^t eps_i*1_(b_i+H_i)(a), t<=C_c, eps_i=+1 or-1.

Inverting each frequency coset yields

    w(y)=sum_i eps_i*L*2^(dim H_i-n)*(-1)^(b_i.y)*1_(H_i^perp)(y).   (9)

This is precisely(4), with linear support flats (the affine lemma is stronger).
Weights are exact dyadic rationals; individual terms need not be integer.
No Cramer estimate, output-period acquisition, dyadic digit calculation,
max-fiber bound or proper Cohen-decomposition learner is needed.

The retained correct primary PDF is
primary/GreenSanders_General_math0611286v2.pdf,
SHA2564c1e5ae4d3f92eebc0f917f3122643d4019e778c1630bdf85c0e18385cebe849.
The old mislabeled GreenSanders_General_2008.pdf actually contains Talagrand;
it is explicitly marked INVALID retrieval and is not evidence for this theorem.

## 5. The scoped uniform complexity consequence

For any fixed integer c>=1 and ANY valid constant C_c from Section4, define

    D_c=C_c*(ceil(log2(4C_c))+1).                 (10)

The completely specified degree-D algorithm of Section1 then solves
rectangular Avoid for every quadratic F:F2^n->F2^(n+1) having SOME actually
enumerated square coordinate projection P with

    H(P)<=c*2^ceil(n/2).                         (11)

There is no relative margin from L, no maximum-fiber bound, no proper
collision/defect hull assumption, and no supplied H. Every input on which
the algorithm succeeds is sound even if(11) fails; OUTSIDE only certifies
the chosen polynomial-closure class, not a computed numerical hole count.
This is not an exact recognizer of the numerical promise(11).

Because C_c and D_c are fixed universal constants for a fixed c, this proves
EXISTENCE OF A DETERMINISTIC UNIFORM FP^NP MACHINE on that promised class,
with the explicit degree-parametric costs(2),(3). Hardcoding one universal
valid constant is not input-dependent advice. Conversely, numerical C_c,
numerically instantiated guaranteed-complete degree D_c, and the leading
polynomial exponent for the full promised class remain NOT_EXTRACTED.
Do not substitute the hidden absolute constant by1, run unbounded adaptive
degree search while calling it polynomial, or claim an executable numerical
guarantee beyond the chosen degree's actually recognized class.

The parametric algorithm A_D is fully explicit, uniformly clocked and
fail-closed for ANY supplied degree D. Thus concrete small-degree instances
can be run and validated without pretending the universal C_c was extracted.
If c grows with n, the theorem gives no FP^NP conclusion for free; dependence
of the structural constant and every M_D bit/query cost must be paid.

## 6. Classical reduction, exact contribution and remaining frontier

Chung--Golovnev--Li--Obremski--Saraogi--Stephens-Davidowitz,
*The hardness of range avoidance for randomized algorithms implies Minicrypt*,
ECCC TR23-193 revision1(18September2024), Definition2.4 and Theorem3.1,
already define CollisionAvoid and reduce Avoid to it by projection and
flipping the last bit at a NON-COLLISION input:
https://eccc.weizmann.ac.il/report/2023/193/revision/1/download .
That exact primary reduction was read directly, printed page13. It is
CLASSICAL, not an invention here. We use its easy two-case output interface.

The candidate new bridge is the explicit arrangement-to-annihilator lemma
plus actual complete NP acquisition of that annihilator from collision
inputs, composed with the precise integer Gauss normalization and classical
Cohen theorem. No decomposition is supplied or acquired, so the unresolved
general proper-Cohen-learning problem is bypassed for this more limited task.

The unrestricted square-projection deficit may be exponentially larger than
L, and arbitrary rectangular quadratic maps are not covered by(11). Literal
3local maps can also have cubic coordinates. Generic near-square3local
Avoid, P-vs-NP, practical usefulness and the programme mission remain
NOT_ACHIEVED/UNRESOLVED. This is a new structural algorithm proposal with
fresh internal review and a focused broader priority check still required.
