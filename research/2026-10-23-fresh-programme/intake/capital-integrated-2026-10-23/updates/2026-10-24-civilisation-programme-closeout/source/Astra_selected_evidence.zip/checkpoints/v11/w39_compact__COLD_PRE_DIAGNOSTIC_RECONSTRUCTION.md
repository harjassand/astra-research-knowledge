# Cold algebraic reconstruction before diagnostics

W39, 24 October 2026. Read only the exact W73 compact-prior source
45421a5832a0453574a2251c9bb9c3c6c5ef6c7e7ae7e493236d69343aeaab2c
and the separate two-round source, plus the named primary Fisher-method
paper. No W73 replay code, report/result, peer audit or root development
proof was read. This records the mathematical reconstruction before
writing/running my diagnostic code. It is not yet the final verdict.

1. On w=a(2+u), u in[-1,1], prior mass is cos^2(pi u/2)du. Its integral
is1. Extending by0 is C1: the density is quadratic and its first derivative
linear at each endpoint. Its a.e. score is -(pi/a)tan(pi u/2), mean0,
and score-squared mass is (pi^2/a^2)sin^2(pi u/2)du. Thus J=pi^2/a^2,
finite despite the unbounded endpoint score. Boundary p=0 suffices for
the distributional IBP; p rho=p' also vanishes at the endpoints.

2. For the ENTIRE Y=HW+Z, test-function IBP gives
E[rho_W|Y]=H^T grad log f_Y(Y) and E[rho_Z|Y]=grad log f_Y(Y).
The scores are centered independent coordinates, so for H alpha+beta=v,
I_Y(v)<=J||alpha||^2+sigma^-2||beta||^2. Set
C=sigma^2 I+J^-1HH^T,
alpha*=J^-1 H^T C^-1v and beta*=sigma^2 C^-1v. The constraint and
objective equality to v^T C^-1v hold by multiplication. This proves the
minimum for all rectangular/rank-deficient H; the objective is strictly
convex in alpha. There is no Gaussian posterior assertion.

3. For a leaf edge at h,l, column H_l has r_l=s_l-s_h at the leaf and
-r_l at its hub. The two-star H has no cross-star columns. With c=1/J,
each leaf's Schur contribution is
c-c^2||r||^2/(sigma^2+c||r||^2)=1/(J+||r||^2/sigma^2).
The two remaining hub blocks S_U,S_V are independent. Since v has only
hub entries +(s_U-s_V),-(s_U-s_V), its complete quadratic form is the
sum of the two inverse-hub quadratic forms. This uses the comparison
C only, not an identification with the actual posterior of W or Y.

4. Row budgets give ||s_i-s_h||^2<=4B. With b*=1/(J+4B/sigma^2),
lambda=sigma^2/b*, inverse order bounds each hub term by 1/b* times a
ridge quadratic form. For T a uniform(d+1)-set and j uniform in T,
h_j=r_j^T G^-1r_j and t_j=r_j^T(G-r_jr_j^T)^-1r_j satisfy
t_j=h_j(1+t_j), t_j<=4B/lambda and sum h_j<=q. Consequently the average
is <=(1+4B/lambda)q/(d+1). Conditional on U, this is EXACTLY the
sampling V uniform and A a uniform d-subset excluding V. Since
d+1=n/2, the sum of both hub terms is bounded by
(4q/n)(J+8B/sigma^2). Hubs/partition/weights are drawn before and
independently of design randomization. No per-design adversarial graph
is selected. Allowing the decoder metadata only after commitment does
not change that averaging law.

5. For each fixed design and metadata, f_t(y)=f_0(y-tv) is a location
family with the same directional Fisher at all t. Its derivative has
L1 norm E|v^T score(Y)|<=sqrt(I). FTC and Tonelli imply
TV(f_a,f_0)<=a sqrt(I)/2. The Gaussian convolution ensures positivity,
smoothness, finite directional Fisher and integrable derivatives. Mixing
over common metadata/design measures followed by Jensen gives the
claimed sqrt[(q/n)(pi^2+8a^2B/sigma^2)] bound. Algorithm accuracy is used
only at edge weight0 (absent) and a (present), both promised forests;
the intermediate analytic location path is not a promised instance.
No finite-shift KL/Fisher inequality is needed or inferred.

6. Uniform risk<=delta on every fixed input gives endpoint-prior Bayes
risk<=delta. Therefore TV>=1-2delta, giving the stated q lower bound.
The hard prior is independent of the random design, so the conclusion
is a fixed hard input in the usual minimax order. For a decoder allowed
metadata, its fixed hard input includes an admissible fixed metadata
description; for a decoder without metadata this convention is moot.

7. The separate two-round star source has a direct reconstruction:
binary x_i in{0,1/2} makes all incident positive edge currents at a
vertex have the same sign. Each hub has Binomial(d,1/2) opposite-bit
leaves, hence signal>=ad/8 when count>=d/4; a leaf signal<=3a/2.
The stated all-sensor and two-binomial budgets sum to<=delta/2, and its
strict d>12+16t/a ensures both hubs outrank every leaf. The second
action, at an acquired hub, isolates the other hub's optional-edge
response0 versus-a/2. Its fresh Gaussian threshold error is<=delta/2.
Each row's total squared control is<=1/2 on EVERY data path, including
incorrect hub selection. Total acquisitions are exactly2n, not2 scalar
reads. This is connectivity only, exact-control Gaussian sensing, not
full support or a physical-time/energy result.

No algebraic obstruction found at this pre-diagnostic point. Numerical
and exact finite checks will supplement, not replace, this all-size
argument. Source priority and hardware feasibility remain separate.

