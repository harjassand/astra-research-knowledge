# Probe-observable sign correction to frozen V1

23 October 2026. Fresh critic w36 independently found a sign error in section5 of frozen `FINITE_PREPARATION_AND_CAPACITY_V1.md` SHA28008c7e0568aeb083720ade53788ab5ddeea3275dc1db0a027bc7b2723eccd6. The V1 bytes are unchanged.

For the exact state(L3), the V1 observable has mean -x m_beta, whereas(L4) says +x m_beta. Replace ONLY the measured observable by

    Y_corrected=i(|10><01|-|01><10|).

Then E_x Y_corrected=+2 a^(3/2) beta x as used in(L4), and the sign classifier is as stated. Equivalently one could keep the old observable and reverse the classifier. The +/- eigenprojectors are interchanged, the zero projector is identical, root/depth1 recovery is identical, and every cost/error constant in(L5) is unchanged. All numerical diagnostics and subsequent implementation must use the corrected observable. This addendum controls the sign over the frozen V1 text. No other conclusion is changed by this repair; the remaining theorem is under fresh criticism.
