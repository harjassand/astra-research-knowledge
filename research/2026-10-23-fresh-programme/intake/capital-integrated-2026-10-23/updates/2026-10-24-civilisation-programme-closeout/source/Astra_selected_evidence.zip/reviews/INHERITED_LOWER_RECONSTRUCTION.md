# Independent recertification of the Pro1 quadratic lower bound

23 October 2026. Worker w10. An internal analytic reconstruction from the
actual original proofs, not a source-integrity or model-agreement certificate.
No source, earlier w10 packet or other worker's file was edited.

## 1. Exact question, sources and verdict

The inherited lower does establish an Omega(beta^2) excess over 3/2 for the
UNCHANGED UNRESTRICTED no-feedback capacity model, on 0<beta<=1/32. Its
particular code has inward drift and small effective bath support; those are
properties of a legal constructed code, not extra admissibility conditions
in the capacity being lower-bounded. No terminal return premise is imposed.

The code is one deterministic isometric encoder/decoder sequence chosen
independently of the initial bath density. Its full-diamond error tends to
zero pointwise for EVERY FIXED normal initializer, including coherent ones
and normal states with infinite mean depth. There is no fixed-horizon uniform
claim over all normal states. This is the same initializer and coding model
as the pointwise upper in w49 PROOF_V4.txt. The initial bath is independent
of logical inputs/references. Initial bath purifiers remain in the complement.

The exact lower is

    Q(beta,tau)>=3/2+(ln 2)/2^20 * beta^2,  0<beta<=1/32.       (1)

No blocking mathematical gap was found in the reconstruction below. The
finite-error-set code uses the established AFFINE Tverberg theorem and
Knill-Laflamme correction; it is an existence construction with enormous
dimension and no efficient synthesis guarantee. External/formal correctness,
historical priority and practical advantage remain separate open statuses.

Pinned corpus HEAD: e606bfc587c76bdcae8b8fa3ec33e721efa2fbac. The governing
merged proof is cycle-11/pro1/dependencies/cycle10/COMPLETE_PROOF.tex.txt,
SHA256 1759b20db049172f713feea66f0d2ff5a7f36af258e546220bbc02f6c30d80aa.
All cycle paths below are under work/astra/research/2026-10-23-scientific-cycles/.
The complete Cycle10 file was reopened, including its preserved endpoint,
operator-coding and joint-compression appendices. I also reopened Cycle7's
SHARP_TEMPORAL_GROWTH.tex to reconstruct its inherited H_k interface rather
than treating the Cycle10 assertion as a proof. The new all-distance response
is in cycle10's contributions/hamming_response/FULL_HAMMING_RESPONSE.tex.

## 2. Unchanged device and complete code interface

E has basis |s,w>, s in {0,1}, w a finite word over two colors. L=|w|.
S_j prepends color j. R exchanges the two vacuum seeds and is zero elsewhere.

    U=[[R,S1,S2],[S1*,0,0],[S2*,0,0]],
    V=sqrt(1-beta^2)U+i beta I, W_N=V_(N,E)...V_(1,E).

The identities S_i*S_j=delta_ij I, sum S_j S_j*=I-P_vac, R^2=P_vac,
R S_j=S_j* R=0 prove U=U*=U^-1. Each call conserves bath depth plus port
charge q=diag(0,1,1), including R at the actual root. All calls share one
evolving bath. There is no reset, direct bath access, postselection, entangled
seed, reverse quantum wire, extra timing alphabet or feedback. An N-call code
is a single encoder into all N qutrits and a decoder on all N emitted outputs.
The lower's isometric encoder is included among the upper's arbitrary CPTP
encoders. Arbitrary initially retained logical references are protected.

The actual initializer is

    tau_pi=(I_seed/2) tensor (2/3) sum_w 6^(-|w|)|w><w|,
    Pr_tau_pi[L=h]=(2/3)3^(-h),  E L=1/2.

It is used for the additional coherent-information limit, not to choose the
universal code. The density eta=diag(3/4,1/8,1/8) does not supply a reset in
this proof. The finite-prefix comparison state used below is never prepared.

## 3. Reconstructing the inherited H_k from actual bulk words

Set b=beta^2,a=1-b, Q=sum_i q_i, A=Q-k/2 and
sigma=diag(1/2,1/4,1/4)^tensor k. Then -log_2 sigma=k+Q.
Define the bounded observable G_b=Q-W_k* Q W_k, ||G_b||<=k. It represents
bath displacement without subtracting potentially infinite depth means.

Starting at depth at least k, no root exchange is encountered before the
last of k calls. After total input-charge pinching, G_b acts on the first k
bath colors and the input, tensor identity on the seed and untouched tail.
Equal input charges and a common output imply equal-length final tails.
Every surviving paired stay count is even, so this finite representation
Gcal_k(b) is polynomial in b. Its diagonal on each COMPLETE binary input
pattern x is exactly a(2|x|-k)I: move/stay choices produce distinct output
charge words, and each fixed word is an isometry on its color fiber.

Let G1 be the first b coefficient. For a sufficiently deep algebraic core,
the conjugated toggles C_i=U0...U_(i-1) U_i U_(i-1)...U0 flip input bit i.
Writing W(0)*W(s)=exp(is C_(k-1))...exp(is C0), charge pinching of its
second-order expansion gives G1=[C_-,C_+]. The ordered-product correction
is a commutator with Q and pinches to zero. Same-index terms are k-2Q.
An offdiagonal pair i<j has the oriented block C_j^- C_i^+-C_i^+ C_j^-.
These deep-core words identify the same finite prefix coefficient; they do
not extend a bulk identity through the physical root.

Here is the original token normal form reconstructed explicitly. For endpoint
charges 01, let h be unmatched pushes before i and d unmatched pops in (i,j).
Cancel matched Dyck factors, which only permute their own input color wires.
The remaining prefix stack is (a_h,...,a_1,B_m,B_(m+1),...). The conjugated
middle toggle inserts its color w at index d. The two endpoint orders are
pop-after-insertion and insertion-after-pop. Their differing stack entries
are adjacent w and P_d; for d=0 one order outputs w and the other outputs
P_0. Undoing the prefix consumes exactly its first h stack entries. Hence:

- h>d: the two changed wires are distinct input colors, giving
  K=P_input(I-SWAP_input,input) tensor I_bath.
- h=d: one changed wire is input and the other original bath coordinate m,
  giving K=(P_input tensor I)(I-SWAP_input,bath).
- h<d: both words export w and extract the same B_m. Their final baths
  differ only in the insertion position of w among original bath colors.

All affected original bath positions are within the first k colors. On a
repeated pure prefix |u>^tensor k, the h<d contractions cancel: both extract
|u> and contract the exported input against <u|, independently of insertion
position. No zero assertion for arbitrary prefixes is used.

For zeta_sym=P_sym,k/(k+1)=integral |u><u|^tensor k du, every one-color
marginal is I/2. Define H=Tr_F[(I tensor zeta_sym)G1]+2Q-k. Its oriented
blocks are respectively P(I-SWAP),P/2,0. Thus H is Hermitian, commutes with
Q and sigma, is completely pattern-offdiagonal, and H=sum_(i<j)H_ij with
||H_ij||<=2. The symmetric density is an analytic comparison only.

Normalized input-color square in the three cases is 1,1/4,0. Pairing H
against the full G1 and tracing input colors gives exactly these same
SCALAR values on every bath vector: the critical value is
(1/2)[I-(1/2)I]=I/4, using partial trace of a color swap. Therefore

    Tr_input[(sigma H tensor I)G1]=v_k I_F,
    v_k=Tr(sigma H^2).                                       (2)

This is full operator equality, not a chosen-prefix expectation or a scalar
depth-chain approximation. The two endpoint orientations have equal sigma
weight. Fair pattern bits imply

    v_k=(1/2) sum_(i+r<=k-2)[Pr(M_i>M_r)+(1/4)Pr(M_i=M_r)],

with independent symmetric-walk maxima. Swapping i,r in the triangular sum
gives v_k=k(k-1)/8-C_k/8. Reflection gives
Pr(M_j=m)=Pr(S_j=m)+Pr(S_j=m+1); its resolvent generating function yields
sum_(i=0)^t Pr(M_i=M_(t-i))=sum_(j=0)^t Pr(S_j=0). Consequently

    C_k=sum_(j=0)^(k-2)(k-1-j)Pr(S_j=0),
    k^2/32<=v_k<=k(k-1)/8,  v_k>=binom(k,2)/8.                (3)

Explicitly, with D_z=sqrt(1-z^2) and u_z=(1-D_z)/z, the maximum generating
function at height m is (1+u_z)u_z^m/D_z. Summing its squares over m gives
(1+u_z)/[(1-u_z)D_z^2]=1/[(1-z)D_z]. The coefficient at z^t is the
return-probability partial sum above; summing t<=k-2 gives C_k. The parity
of S_j is retained throughout.

The lower already follows from 0<=C_k<=binom(k,2), without an asymptotic
estimate. Distinct endpoint pairs occupy orthogonal complete-pattern matrix
blocks. A product of 2p endpoint terms can survive complete-pattern pinching
only if each named vertex occurs evenly. Orienting edges, matching 4p slots
in (4p-1)!! ways and assigning at most k^(2p) labels bounds the count. The
orientation factor cancels the product norm 2^(2p), giving

    0<=P(H^2)<=3k^2 I,  Tr(sigma H^4)<=105k^4.                (4)

## 4. All-order pair response, with its full bath norm

For each endpoint pair, equality of the output charge word forces identical
stay choices at spectators and complementary choices at the endpoints. The
endpoint scalar factor is ba. For a fixed spectator stay set S the weights
are b^|S| a^(k-2-|S|), summing to one. The four endpoint raw overlaps are
contractions. Unitarity of the auxiliary word with these fixed spectator
U/I calls gives -R00+R01+R10-R11=0. This cancels the whole spectator output
charge and the constant endpoint charge, leaving R10-R01 of norm at most2.

The original H_ij has weighted trace norm at most1/4. Indeed conditional
input colors are maximally mixed; |I-SWAP| has normalized trace1/2, as
does I/2, and the two 01/10 endpoint orientations together have charge
probability1/2. Thus every contracted pair coefficient A_(ij,S) has norm
at most1/2. Empty spectator-stay masks sum to the scalar certificate (2).
Only mass 1-a^(k-2) differs, so the exact response is

    D_b(sigma H)=ba F_k(b),
    ||F_k(b)-v_k I||<=binom(k,2)[1-a^(k-2)]
                    <=8b(k-2)v_k.                           (5)

Here D_b(Z)=Tr_input[(Z tensor I)G_b]. These are operator norm bounds on
the entire prefix. The positive weights occur AFTER coherent histories are
paired; they do not declare the actual device to be classical noise.

## 5. All-distance response needed by the nonlinear normalization

Two equal-weight patterns at Hamming distance2m need complementary endpoint
stay bits on those2m sites. The raw endpoint sum has (ab)^m factor. The same
auxiliary unitarity cancels spectator output charge. Subtract endpoint mean m;
the sum of absolute endpoint deviations is
c_m=sum_j binom(2m,j)|j-m|=m binom(2m,m). Thus each such pattern block of
Z=Gcal_k(b)-a(2Q-k)I has norm <=c_m(ab)^m.

For pattern x of weight q there are binom(q,m)binom(k-q,m) such columns.
Pinching Z^2 sums their positive squares without cross-column terms, giving

    P(Z^2)<=sum_(m>=1) [m^2 4^(m-1)(bk)^(2m)/(m!)^2] I
            <=r^2 exp(4r^2)I, r=bk.                          (6)

For any pattern-diagonal density omega, Phi_omega(X)=Tr_input[(omega tensor
I)X] is unital CP; cyclic input partial trace supplies its positive sandwich
form. Apply it to the positive block matrix [[Y_perp^2,Y_perp Z],
[Z Y_perp,Z^2]]. The scalar upper-left block and (6) imply

    ||D_b(sigma Y)-2a Tr(sigma AY)I||
       <=r exp(2r^2)||Y-P(Y)||_(2,sigma)
       <=2r ||Y-P(Y)||_(2,sigma), r<=1/2.                    (7)

No commutation between Y_perp and Z is assumed. For the actual sigma,
[Y,Q]=0 ensures [Y,sigma]=0 and the response is Hermitian. This is the
load-bearing improvement over an invalid generic k||sigma Y||_1 estimate.

## 6. Actual positive input and exact diagonal charge

Fix 0<b<=1/1024, k=floor[1/(256b)], r=bk<=1/256. Then k>=4 and
k>=1/(512b). Let ell=ln2, gamma=ell/4, m=3ell v_k/32 and

    X=-gamma b H, C=I+X/2, D=P(C^2)=I+P(X^2)/4,
    J=D^-1/2, F=J C^2 J, T=I+(4m/k)b^2 A, rho=sigma T F.      (8)

D>=I. Conditional-expectation bimodularity gives P(F)=I EXACTLY.
F is positive and commutes with Q; sigma,T are functions of Q and commute
with F. T>0 because eta=||T-I||=2m b^2<r^2/32. Hence rho is a density,
P(rho)=sigma T, Tr(A rho)=m b^2. This is the definition of a finite input
matrix, not a success-filtering operation or physical bath normalization.

Write ||Z||_2^2=Tr(sigma Z*Z), u=||X||_2=gamma b sqrt(v). Equations(3)-(4)
and scalar inverse-square-root calculus give

    ||J-I||<=3gamma^2 r^2/8, u<r/8,
    e=||F-I-X||_2<=3gamma^2 r^2, e/u<=5r,
    Y=T(F-I)-X, P(Y)=0, ||Y||_2<4gamma^2 r^2.                 (9)

For example F-I=JXJ+(1/4)J[X^2-P(X^2)]J; the fourth moment bounds the
second term in weighted Hilbert-Schmidt norm. No small operator norm of X
or hidden spectral-tail cutoff is used.

## 7. Global entropy bound and full inward drift, with constants

rho commutes with sigma and z ln z-z+1<=(z-1)^2 for z>=0. Thus, using
bits for entropy and Bcal=ell v b^2,

    D_2(rho||sigma)<=Tr sigma(TF-I)^2/ell
      <=[4m^2 b^4/k+(1+eta)^2(u+e)^2]/ell
      <=18 Bcal/256.

The last bound uses
(1+2^-21)^2(261/256)^2<17/16 and 9vb^2/k<1. Therefore

    S_2(rho)-3k/2=Tr(A rho)-D_2(rho||sigma)
       >=3 Bcal/128>=Bcal/64.                               (10)

The signed comparison sigma(T+X) has response
ab^2[2m I-gamma F_k(b)]<=-a Bcal(1/16-2r)I by(5).
The actual difference is sigma Y. Its charge is zero, so(7) and(9) give
||D_b(sigma Y)||<=8gamma^2 r^3<=16ell r Bcal. It follows that

    P_(L>=k) D_b(rho) P_(L>=k)<=-kappa P_(L>=k),
    kappa=a ell v b^2/128>0.                                (11)

The required scalar margin is a(7/128-2r)>=16ell r. At the worst endpoint,
substituting a>=1023/1024,r<=1/256,ell<7/10 leaves EXACT margin
1009/327680>0. All beta and k restrictions in the source are retained.

## 8. The actual root, homogeneous increments and exponential tightness

Because [rho,Q]=0, diagonalize rho in Q-eigenvectors. Each bath Kraus
operator has homogeneous degree Delta=input charge-output charge, |Delta|<=k.
This includes R, which has degree0. For its effects A_Delta=K* K,

    sum A_Delta=I, [A_Delta,L]=0,
    D_b(rho)=sum Delta A_Delta,
    Phi_rho* exp(tL)=(sum exp(t Delta)A_Delta)exp(tL).         (12)

All are positive-form identities obtained first on the coordinate core and
extended by monotone limits. Take t=kappa/(2k^2),lambda=1-kappa^2/(4k^2),
C_L=exp(2kt)/(1-lambda). Since |t Delta|<=1/2,
exp(t Delta)<=1+t Delta+k^2t^2. Equation(11) bounds the high-depth block
by lambda. At depth<k the actual evolution reaches at most2k-1. Commutation
in(12) excludes low/high cross terms. Thus the GLOBAL root-retaining bound is

    Phi_rho* exp(tL)<=lambda exp(tL)+exp(2kt)P_(L<k).          (13)

For every coherent initializer supported at depth<=A this yields

    Pr[L_after_m_blocks>H]<=(1+C_L)exp[-t(H-A)].              (14)

The finite root term is essential: no globally strict positive contraction
is asserted. No physical scalar bath-chain invariant family is needed.

## 9. Spectral types transfer overflow to the actual code subspace

Let d=rank rho and T_m a maximum-probability exact spectral type of rho^tensor m,
of mass w_m and dimension D_m. There are at most(m+1)^d types, so

    w_m>=(m+1)^-d, T_m/D_m<=rho^tensor m/w_m,
    log_2 D_m/m -> S_2(rho).                                (15)

The frequency convergence is direct: maximality under moving one count i to j
gives n_i/p_i<=(n_j+1)/p_j; summing against p_i gives n_j>=mp_j-1.
Only positive eigenvalues are counted. Eigenvectors may be temporally entangled.

Set A_m=floor log_2(m+1), epsilon_m=(m+1)^-16 and

    H_m=A_m+ceil[((d+16)ln(m+1)+ln(1+C_L))/t].               (16)

Apply(14) first with the uniform initializer on P_(L<=A_m), then apply(15).
The average final overflow for T_m/D_m and that finite bath input is <=epsilon_m.
The polynomial type factor is paid ONLY here; it is not applied to an
uncontrolled tail of an arbitrary initializer.

## 10. Joint compression, r^2 factor, actual isometric encoder

I reconstructed the source's coding bridge rather than using an iid channel
capacity theorem. Let W:A tensor E0 -> B tensor E be an isometry with input
dimension D, bath input dimension r and rank-h final bath projection P. For
overflow F=W*(I-P)W define L_A=Tr_E0 F/r. If Tr L_A/D<=epsilon, expurgate to
Q=1_[0,2epsilon](L_A), of dimension at least floor(D/2). Positivity gives

    F_Q<=r(Tr_E0 F_Q) tensor I<=2r^2 epsilon I.              (17)

The factor r^2 is retained. The projected Kraus operators
B_(w,v)=<w|P W|v>/sqrt(r) obey sum B*B=I-Q L_A Q. Therefore
J_aux=(I-Q L_A Q)^-1/2 normalizes them into a CPTP map with at most r*h
Kraus operators and ||J_aux-I||<=(1-2epsilon)^-1/2-1.

A CPTP map with q Kraus operators on an s-dimensional input has an exact
subspace code of size at least ceil(s/q^4). To see this, its error-product
operator system has a Hermitian basis I,H2,...,H_d, d<=q^2. Greedily choose
at least ceil(s/d) orthonormal vectors with all cross error expectations zero.
Their remaining diagonal expectation vectors lie in REAL dimension d-1
because I is constant. The AFFINE Tverberg theorem gives r0=ceil(N/d) disjoint
groups with a common convex-hull point: (r0-1)d+1<=N. Square-root convex
weights give quantum code vectors satisfying Knill-Laflamme. The exact
decoder is an isometry on the full error-image span and extends to a CPTP
decoder. It corrects every syndrome; no outcome is selected.

For the normalized auxiliary channel this gives encoder C and recovery Drec.
The projected recovered joint map using J_aux C is I_logical tensor Z. The
ACTUAL encoder is C, never J_aux C. Its recovered isometry differs from that
factor by at most

    e=r sqrt(2epsilon)+(1-2epsilon)^-1/2-1.

Since the actual map is isometric, singular values of Z lie in[1-e,1+e]. Its
polar isometry Z0 differs by at most e; hence the actual recovered isometry
is within2e of I_logical tensor Z0. This operator norm estimate tensors with
all references, including purifiers of coherent initial bath states. Its
logical marginal has FULL diamond error <=4e and code size

    K>=ceil[floor(D/2)/(r*h)^4].                             (18)

All initial and final bath indices are used. No bath measurement, physical
normalizer or probability-conditioned code has entered the proof. The affine
Tverberg and Knill-Laflamme ingredients are established finite mathematics;
the new model-specific obligations are the exact drift and compression input.

## 11. Horizon, initializer and rate limits

Apply(18) with r=r_(A_m)=2^(A_m+2)-2 and h=r_(H_m). Then
e_m<=4sqrt2(m+1)^-7+O((m+1)^-16)->0. Both log r and log h are O(log m)
for each FIXED beta,k,rho. Equations(15),(18) therefore give rate S_2(rho)/k.

For any fixed normal tau, compare it OUTSIDE the type domination to its
normalized coordinate truncation. Gentle truncation gives full-diamond error

    min{2,4e_m+2sqrt[1-Tr(P_(L<=A_m)tau)]}->0.               (19)

Normality suffices; no first moment or entropy bound is needed. The same C,Drec
were chosen using only the uniform finite bath input, independently of tau.
For incomplete horizons append fixed data-independent input calls and ignore
their later outputs; earlier decoded marginals are unchanged and every call
counts. This handles all integer horizons without a timing or stopping channel.

Finally(3),(10), k>=1/(512b) give

    [S_2(rho)-3k/2]/k>=ell v b^2/(64k)
      >=ell b^2 k/2048>=ell b/2^20.                          (20)

At tau_pi the exponential moment is finite because t<=1/2<ln3. Equation(13)
bounds final mean depth uniformly. The normalized bath Gibbs density
g=4^(-L)/4 has -log_2 g=2L+2, hence S(E_m)<=2E L_m+2=O_beta(1).
Initial bath entropy is finite. Unitary entropy conservation, subadditivity
and Araki-Lieb give m S(rho)-2S(E_m)<=Ic<=m S(rho). This proves the stated
coherent-information limit, without replacing repeated blocks by iid channels.

## 12. Exact combination with the independently audited upper

w49 Version4 SHA256 ccd777dd4daea424e19d6b8fd4e8c6842fb7f0614aa0fb325cc1744fe532da11
uses the same device, root, fixed-call/no-feedback interface and every fixed
normal initializer. Its upper covers all CPTP encoders, hence this lower's
isometric encoders. Conditional on that separately audited upper, the bounds
can therefore be combined without a change of model:

    (ln2)/2^20 beta^2 <= Q(beta,tau)-3/2
       <=(1/2)log_2(1+beta^2/4)
       <=beta^2/(8ln2), 0<beta<=1/32.                        (21)

This proves the two-sided Theta(beta^2) order for every fixed normal tau.
It does not identify the leading coefficient, feedback capacity, finite
horizon usefulness or physical realizability. Numerically the lower
coefficient is about6.61037e-7 and the upper tangent coefficient about0.180337.

The baseline itself can be reconstructed without any inherited H interface.
For k=1 choose rho_p=diag(1-p,p/2,p/2),0<p<1/2. At every nonroot depth its
actual drift is a(2p-1)<0 for every fixed beta<1; at the root it is ap.
The homogeneous-increment/Lyapunov/compression proof above applies unchanged,
including at beta=0 (its proof has no division by beta). It gives rates
h_2(p)+p approaching3/2 as p increases to1/2. Thus Q(0,tau)=3/2 by w49's
beta-zero upper, and Q(beta,tau)>=3/2 for every fixed beta<1. At beta=1,
V=iI and Q=log_2 3. This endpoint check is not needed to prove(21), but
confirms that the reference value3/2 is an actual same-model capacity at0.

## 13. Dependencies, diagnostics and costs

The only imported finite geometric theorem is affine Tverberg, applied to
real expectation points; no topological-Tverberg extension is used. The
finite error correction is the standard Knill-Laflamme Gram construction.
The primary KLV paper and GBM perfect-memory construction were read directly;
the original Tverberg DOI retrieval was unavailable. Their coding mechanisms
are prior art. No exact-source model-specific claim was inferred from them.

check_lower.py independently rebuilds physical ordered U/I histories at
k=2,3,4. It obtains exact integer first-b coefficients and rational charge
diagonals; contraction with the symmetric prefix gives v=1/8,1/2,17/16 and
the FULL scalar operator certificate exactly. At beta=1/32,k=4 it constructs
the actual positive matrix rho and checks entropy and full bath drift by
floating eigenvalues. The entropy excess is about1.09743e-8 per call versus
the proved2.74356e-9 bound; largest bulk drift eigenvalue about-4.37304e-8
versus required-5.48176e-9. These are finite diagnostics, not the all-length
proof or an actual code implementation. The exact worst-case drift margin
is separately checked as1009/327680.

The inner input dimension is3^k with k=Theta(beta^-2); at beta=1/512 it is
3^1024, about10^488.572. The type exponent d can be as large as3^k. The
cutoff H_m has coefficient(d+16)/t, t=kappa/(2k^2); the decoder and spectral
normalization are existential operations. The proof supplies no efficient
compiler, laboratory gate precision, energy/reset cost or useful finite time.
All fixed forward calls count. The infinite physical bath and arbitrary
global external encoder/decoder remain declared supplied model interfaces.

Remaining scientific gates are external/formal review and priority review;
there is no unresolved lower-bound dependency merely on a current claim
notice after the reconstruction above. A source-specific counterexample to
the token normal form, full scalar certificate, all-distance row bound or
joint compression would invalidate the result. The present review found none.
