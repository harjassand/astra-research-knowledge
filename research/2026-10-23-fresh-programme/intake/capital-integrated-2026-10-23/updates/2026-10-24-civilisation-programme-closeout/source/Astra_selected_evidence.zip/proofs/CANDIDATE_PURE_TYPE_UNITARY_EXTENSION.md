# Explicit total unitary extension and conservative encoder gate bound

W67, 23 October 2026. This is a post-freeze implementation strengthening of
`../PURE_TYPE_ENCODER.md`, SHA256
`e61ec757e15f008e283711c4f7ab7fe8aa8214801c5b1600f78ce0c26d74cd55`.
The frozen type/source/rate proofs and their numerical records are unchanged.
The point here is to make the phrase "fixed reversible reject extension"
literal and to charge a concrete, deliberately loose arithmetic circuit size.
No new generic reversible computation or enumerative coding claim is made.

## 1. Total Boolean maps and a literal unitary

Encode each of the nine type labels by a four-bit digit. A word therefore
occupies `4m` bits. Let the fixed type size be f, let `ell=floor(log2 f)`,
and let `D=2^ell`. The actual classical constructor computes f; a lower
bound on f is not a substitute for that computation.

Define two total Boolean functions:

* `G:{0,1}^ell -> {0,1}^{4m}` maps the integer r to the lexicographic
  type word of rank r. Every input r is legal, because `r<D<=f`.
* `R:{0,1}^{4m} -> {0,1}^ell` first verifies that every digit is below
  nine and that the complete digit counts equal the fixed counts. If so,
  compute its ordinary type rank z. Return z if `z<D`; return zero
  otherwise. All invalid digit strings and all remaining type words
  likewise return zero.

Thus `R(G(r))=r` for every ell-bit input. Invalid words need not have
distinct R values: R is used as an XOR function, not asserted to be a
permutation itself. Define the two standard XOR unitaries

    X_G |r,x> = |r,x XOR G(r)>,
    X_R |r,x> = |r XOR R(x),x>.

Each is its own inverse on EVERY computational basis state, including
invalid digit strings. Their composition is the required total extension:

    U_type = X_R X_G,
    U_type |r,0> = |0,G(r)>,
    U_type^* = X_G X_R.

Any classical work bits used to evaluate G or R are computed, copied into
the XOR target, and uncomputed before the next oracle. They finish in zero.
This removes any need to complete a partial isometry by an unspecified
spectral or exponentially described permutation. It also defines the
decoder on arbitrary noisy/out-of-code-space strings.

After the type word is written, a fixed permutation of the nine labels
identifies them with the computational two-qutrit pair basis. A fixed
unitary changes the pairs `|0c>,|c0>` to their symmetric/antisymmetric
combinations for `c=1,2`; the other five basis vectors are unchanged.
Extend this constant-dimensional unitary by identity on the seven unused
four-bit patterns. This is an ordinary known unitary on four qubits.
Its inverse is the reverse conjugate gate sequence. The encoded state
occupies the valid two-qutrit subspace; the extra bit patterns only specify
the local digital unitary extension.

## 2. Polynomial construction without enormous factorial intermediates

Let `L=ceil(log2(m+1))` and `W=8m+8L+32`. All type sizes are below
`9^m<2^(4m)`. Products of a type size by a remaining count or position are
below `2^(4m+L)`, well inside W bits. Counts/positions themselves have at
most L bits. The constructor can avoid an `m!` intermediate entirely:
multiply successive binomial coefficients

    f = product_(j=0)^8 binom(n_0+...+n_j,n_j).

Each binomial coefficient is built by the exact integer recurrence
`B_i=B_(i-1)*(s+i)/i`. Across all nine coefficients there are m steps.
The retained partial products are type sizes for shorter words, hence
bounded by `9^m`; multiplication before each exact division only adds L
bits. The type probabilities and rounded counts require only nine rational
calculations. If the supplied rational b has input bit length B, these
calculations cost polynomially in `B+log m` and return fixed classical
constants for the circuit.

## 3. A conservative explicit reversible gate count

Use ordinary fan-in-two Boolean circuits and exact schoolbook arithmetic,
then the standard fresh-wire reversible simulation. A W-bit add,
subtract, comparison or conditional selection takes at most `16W`
Boolean gates; schoolbook multiplication and restoring integer division
can each be unrolled using at most `64W^2` Boolean gates. These bounds
allow unused high bits and are deliberately larger than needed.

At an unranking stage, compute the nine integers `F*r_j/t`, compare rank
with their nine cumulative intervals, choose a symbol, and update F,
rank and counts. The ranking stage uses the same nine branch sizes and
adds preceding intervals. The loop count is exactly m; each stage has a
fixed nine-way branch implemented by comparisons and multiplexers, rather
than a data-dependent unbounded loop. Verifying all word digits and counts,
and checking whether the final rank is below D, also takes at most a
constant number of these operations per stage. A bound of

    S = 10,000 m W^2

Boolean gates suffices for EACH total function G and R, including total
invalid-input handling. All division denominators in the valid branch
are the known positive integers `m,m-1,...,1`. The invalid branch returns
zero before attempting the rank recurrence. No division by an unverified
input, small real number, or source spectral gap occurs.

In a fully unrolled circuit, realize that early rejection by selecting a
fixed known legal type word whenever verification fails, run the valid-word
rank recurrence on the selected word, then mask its output to zero using
the verification bit. Thus even unused arithmetic wires have the same
bounded valid-word operands; the circuit has no implicit partial operation.

An AND/XOR/NOT/OR gate can be computed into a fresh zero wire with at most
three NOT/CNOT/Toffoli gates. Compute-copy-uncompute therefore realizes an
XOR oracle for a function of S Boolean gates with at most `6S+output_bits`
reversible gates and O(S) clean work bits, all returned to zero. For the
composition of G and R above, a convenient safe bound is

    G_type <= 200,000 m W^2

NOT/CNOT/Toffoli gates, and at most `20,000 m W^2+8m` work bits. The inverse
has exactly the same gate count and workspace bound. This is a loose
`O(m^3)` arithmetic implementation. A more space-efficient reversible
implementation could improve it, but is unnecessary for polynomiality.
The classical constructor must output the constants and the unrolled
circuit and pay at least their description length; none is a free oracle.

The model can include these exact reversible gates in the same fixed
finite universal native alphabet used for the design compiler, or compile
them with the usual fixed-dimensional precision charge. The local pair
basis unitary contributes m constant-dimensional targets. To make its
whole encoder operator error at most xi, synthesize each target to at most
`xi/m` operator error. A fixed universal inverse-closed gate alphabet gives
the standard finite-dimensional synthesis cost

    m * poly(log(m/xi))

additional gates and classical work. If the arithmetic gates are also
approximated in another native alphabet, include their number in the
same telescope and use precision `xi/(G_type+m)` for each such target.
This keeps both gate count and arithmetic precision polynomial. The exact
XOR description is the ideal unitary, with its finite synthesis difference
charged to the already allocated encoder/decoder implementation errors.

## 4. Composition and finite evidence scope

This addendum changes none of the source probability, charge, domination,
high-design probability, padding, rate or diamond-error inequalities.
It supplies an explicit `G_C` for the PURE-ENCODER forward decoder's
`G_C+poly(T,log(1/precision))` interface. All work registers are local;
only the same two-qutrit pair ports enter the actual recurrent device.

The companion exact finite check exhausts every input of the XOR extension
for a three-symbol type with `f=6,D=4`. It includes all four-bit digit
patterns, invalid words, the two excluded legal type words, and every
rank-register pattern. It checks bijectivity, the displayed inverse, and
zero rank erasure on each of the four code inputs. This is a finite
classical permutation check; it is not execution of the enormous complete
quantum code or a native gate compilation.

The main internal theorem remains subject to independent integrated review.
Priority UNKNOWN; physical validation NOT_PERFORMED; practical advantage
NOT_ESTABLISHED; mission NOT_ACHIEVED.
