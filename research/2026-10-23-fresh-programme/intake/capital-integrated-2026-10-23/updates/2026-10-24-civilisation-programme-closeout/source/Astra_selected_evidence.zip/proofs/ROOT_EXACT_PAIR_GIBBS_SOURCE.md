# Exact two-port Gibbs source and its entropy/drift frontier

23 October 2026. Root's original derivation, supplied to W66/W67 for independent attack. It uses their independently proved original-device two-call response identities. General maximum-entropy/Gibbs optimization is established mathematics; device-specific priority and practical importance are UNKNOWN. This is a new internal candidate source optimization, not a finished integrated code.

Let \(a=1-b\), \(b=\beta^2\), \(0<b<1\), and use two qutrits with
\[
Q=q_1+q_2,\quad A=Q-I,\quad
H=\tfrac12\sum_{c=1,2}(|0c\rangle\langle c0|+|c0\rangle\langle0c|).
\]
On the charge-one sector \(H^2=I/4\). On charge zero and two it vanishes. The exact original bulk response, for initial depth at least two, is
\[
\mathcal D_b(\sigma)=0,\quad
\mathcal D_b(\sigma A)=aI,\quad
\mathcal D_b(\sigma H)=abI/8,
\quad \sigma=\operatorname{diag}(1/2,1/4,1/4)^{\otimes2}.
\]
For any diagonal input density the response is \(a(2\langle Q\rangle-2)I\), because every move/stay history has its actual Bernoulli displacement. Since \(\sigma=I/8\) on charge one, \(\mathcal D_b(H)=abI\).

Define the known nine-dimensional matrix and explicit density
\[
L=2A+bH,\quad \rho_t=e^{-tL}/Z(t),\qquad
Z(t)=e^{2t}+4e^{-2t}+4\cosh(tb/2).
\]
Its eigenbasis is fixed: \(|00\rangle\), the four \(|cd\rangle\), and the four pair \(\pm\) states. The eigenvalues of \(L\) are \(-2\) once, \(2\) four times, and \(b/2,-b/2\) twice each. Thus this is a literal constant-dimensional state factory with elementary probabilities, without a many-body Gibbs oracle.

Its charge-one block is
\[
[\cosh(tb/2)I-2\sinh(tb/2)H]/Z(t).
\]
Combining the actual diagonal and coherent responses gives the **full bath operator identity**
\[
\mathcal D_b(\rho_t)
=\frac{a[-2e^{2t}+8e^{-2t}-2b\sinh(tb/2)]}{Z(t)}I
=-a\,Z'(t)/Z(t)\,I.
\]
Its entropy is exactly
\[
S_2(\rho_t)=\big[\ln Z(t)-tZ'(t)/Z(t)\big]/\ln2.
\]

The strictly convex \(Z\) has \(Z'(0)=-6\) and \(Z'((\ln2)/2)>0\) for \(b>0\). Its unique minimizer \(t_b\) lies in \((0,(\ln2)/2)\), solves
\[
2e^{2t_b}-8e^{-2t_b}+2b\sinh(t_bb/2)=0,
\]
and has zero full bulk drift. For every real \(t\), \(e^{2t}+4e^{-2t}\ge4\) and \(4\cosh(tb/2)\ge4\). Equality in both requires simultaneously \(t=(\ln2)/2\) and \(tb=0\), impossible for \(b>0\). Therefore \(Z(t_b)>8\) and \(S_2(\rho_{t_b})>3\). Taking \(t>t_b\) sufficiently close retains entropy above three while making the full drift strictly negative. These are continuous finite positive densities; no bath expectation has replaced an operator condition.

This \(t_b\) is also the maximum-entropy state among densities whose expectation of \(L\) is nonpositive: Gibbs variational duality gives \(S(\rho)\le\ln Z(t_b)+t_b\operatorname{Tr}\rho L\le\ln Z(t_b)\). It is not asserted to optimize every possible two-call bulk-inward source, since scalar \(L\)-expectation describes the displayed invariant input class rather than all arbitrary input operators.

With \(t_0=(\ln2)/2\), the implicit-function expansion is
\[
t_b=t_0-\frac{t_0}{16}b^2+O(b^4),\qquad
S_2(\rho_{t_b})=3+\frac{\ln2}{64}b^2+O(b^4).
\]
Indeed \(Z''(t_0,0)=16\), \(Z'(t_0,b)=t_0b^2+O(b^4)\), and \(Z(t_0,b)=8+(t_0^2/2)b^2+O(b^4)\). The corresponding entropy per call has excess \((\ln2)/128\,\beta^4+O(\beta^8)\), with a strict inward source approaching that frontier from \(t>t_b\). The rate transfer still needs the complete code and all preparation/error costs; no direct source state is itself a message code.

The previously frozen rational affine source remains the simpler certified finite-code input. For this Gibbs candidate, independent exact reconstruction, a rational finite-precision inward margin, explicit entropy remainder, and a complete polynomial-onset code integration are pending. No physical preparation, useful cost, quadratic-gain code, or mission accomplishment is inferred.
