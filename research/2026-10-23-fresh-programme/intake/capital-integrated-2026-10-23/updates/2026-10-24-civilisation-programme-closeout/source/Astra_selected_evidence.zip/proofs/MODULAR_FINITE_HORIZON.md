# Modular resource bound and composition with the audited clipped V2 input

23 October 2026. This is an explicit interface composition of the moment,
spectral-slice and inherited joint-compression proofs. It does not assume
an efficient state factory, arbitrary-message encoder or decoder.

## 1. Modular hypotheses

Fix the unchanged root-retaining k-call device, b=beta^2, a=1-b,
sigma=diag(1/2,1/4,1/4)^tensor k, total input charge Q, and a finite
input density rho=sigma M with

    M>=0, [M,Q]=0, Tr(sigma M)=1,
    S_2(rho)>=3k/2+g, g>0,
    P_{>=k}D_b(rho)P_{>=k}<=-kappa P_{>=k}, 0<kappa<=k,
    Tr[sigma(M-I)^2]<=Xi,
    Var_rho Q<=Upsilon.

Xi is a supplied weighted chi-SQUARE bound, not inferred from entropy.
Upsilon is a separately supplied charge-variance bound. All constants
must hold for the actual positive rho; a signed affine comparison does
not supply this interface. Initial input and bath are independent.

The unchanged physical device, its exact sigma word calculation and
positive displacement effects in SECOND_MOMENT_LYAPUNOV.md prove

    V = ak+sqrt(Xi)*sqrt[ak+3a^2 k(k-1)],
    P_{>=k} Tr_input(rho R_2) P_{>=k}<=V P_{>=k}.

The source-information bound is

    B = sqrt(Upsilon)+(log_2 e)sqrt(Xi),
    Var_rho(-log_2 rho)<=B^2.

This uses the exact commuting identity -log_2 rho=k+Q-log_2 M on the
support of rho and scalar x(ln x)^2<=(x-1)^2. It remains valid with
zero M eigenvalues. Nothing requires exact knowledge of rho's eigenbasis.

## 2. Completely explicit resource formulas

Set

    t=min{1/k,kappa/(eV)},
    lambda=1-kappa t/2,
    C_L=exp(2kt)/(1-lambda).

For outer block count m>=2 and the original convenient asymptotic choices,

    A_m=floor(log_2(m+1)), epsilon_m=(m+1)^(-16),
    J_m=ceil(4B sqrt(m))+2,
    F_m=8J_m/3,
    H_m=A_m+ceil{[16ln(m+1)+ln F_m+ln(1+C_L)]/t},
    E_m=2B sqrt(m)+log_2(4J_m/3)+4(A_m+H_m+4)+3.

Whenever E_m<=mg/2, the actual inherited joint-compression proof supplies
an isometric encoder and deterministic decoder of rate at least

    3/2+g/(2k)

using exactly N=mk forward calls. Its actual initial- and final-cutoff
ranks are r_A=2^(A_m+2)-2 and r_H=2^(H_m+2)-2. The full-diamond error
for every fixed normal initializer tau is bounded by

    min{2,4e_m+2sqrt[1-Tr(P_{<=A_m}tau)]},
    e_m=r_A sqrt(2epsilon_m)+(1-2epsilon_m)^(-1/2)-1.

This retains coherent initializers, their purifiers, arbitrary logical
references, the r_A^2 positive-block factor, auxiliary normalization J
and its polar repair. No success filter or bath reset is performed.
The same code is chosen independently of tau; finite convergence is
pointwise, not uniform over all normal tau. For tau_pi the tail is
exactly3^(-(A_m+1)).

A conservative parameter-order sufficient condition is

    m = O( B^2/g^2
          + [1/(tg)] log[2+B+1/g+1/t+1/(1-lambda)] ),

with an absolute sufficiently large constant and a further logarithm if
needed to absorb log m; the explicit E_m condition governs all reported
numbers. At fixed positive g,kappa,Xi and Upsilon=O(k), V=O(k), B=O(sqrt k),
the clean asymptotic conclusion is m=O(k log(k+1)), N=O(k^2 log(k+1)).

The exponent16 is not a necessary physical resource. More generally set
A_m=floor(c log_2(m+1)), epsilon_m=(m+1)^(-p), where c>0,p>2c, replace16
by p in H_m, and keep the same E_m/error formulas. Then r_A sqrt(epsilon_m)
vanishes, every fixed normal tail still vanishes, and the identical coding
proof applies. Concrete finite target-error optimizations must charge both
cutoff contributions and may use this optional parameterized family. All
reported default comparisons use the fixed original c=1,p=16.

Finite guard identified by w30's independent review: for the generalized
c,p family, impose `0<epsilon_m<1/2` and `e_m<1` before invoking the
nontrivial finite joint-compression guarantee. The inequalities p>2c
ensure these eventually, but do not ensure them at every small m. All
reported numerical contracts check both guards explicitly. The original
c=1,p=16 choices already satisfy the guards for m>=2. This correction
does not change an asymptotic claim or a recorded resource number.

## 3. Exact clipped V2 interface supplied and checked against source

The source is w56's frozen
`../w56_fresh_quadratic_capacity_critic/lower_construction/PAIR_RESPONSE_REFINEMENT_V2.txt`,
SHA256 f22a46f01fb9ea95fd9b528fb853e98f8379512bd2d5ce3f34698a06150672ce,
with full architecture in frozen CLIPPED_AFFINE_PROOF_V1.txt,
SHA256 d5e0c94470a8a080b4ea673196ddad0bf3f6d70804202ccb5014b1fff9a79ce2.
W49 independently accepted that source according to the owner's audit
record; this composition does not assert a fresh independent recertification
of every upstream clipping/moment/response lemma.

For every fixed 0<beta<=1/128, set

    k=floor[1/(12b)]>=1365, r=bk in [1/13,1/12], t0=v_k b^2,
    X=-(b/5)H,
    Bplus=(I+X)_+, Nminus=(-I-X)_+,
    D=pin(Bplus)=I+pin(Nminus), J=D^(-1/2),
    F=J Bplus J,
    T=I+[t0/(4k)](Q-k/2), rho=σTF.

The pin is the COMPLETE binary-pattern pin, not merely total charge.
The source proves rho is an actual positive normalized charge-preserving
density, pinrho=σT, and the full bulk drift/entropy bounds

    g=t0/36, kappa=t0/192,
    Xi=(4001/100000)t0.                              (V2.5)

The Xi line is exactly the weighted L2-SQUARED estimate for TF-I,
not the entropy bound or an unjustified conversion from relative entropy.
Because T is linear in A=Q-k/2 and sigma's charge is fair binomial,

    E_rho A=t0/16, E_rho A^2=k/4,
    Upsilon=k/4-(t0/16)^2 <=k/4.

Thus every modular hypothesis is supplied with the correct object,
normalization and cost interface. Apply Section2 with these values; no
additional proof about state preparation, spectral circuit access, logical
encoding, feedback, bath access or time reversal is inserted.

As r is bounded above and below and v_k/k^2 lies in [3/25,1/8], the
constants g,kappa,Xi have k-independent positive finite bounds in this
V2 scaling. The same existence horizon O(beta^-4 log(1/beta)) follows,
now with much better drift and entropy constants than Cycle10's square.
The concrete numbers remain the governing resource comparison.

## 4. Scalar acquisition and retained costs

The susceptibility v_k is explicitly computable without a 3^k density.
Let n=floor((k-2)/2) and c_n=binom(2n,n)/4^n. The elementary identities

    sum_{j=0}^n c_j=(2n+1)c_n,
    sum_{j=0}^n j c_j=n(2n+1)c_n/3

follow by induction from c_n/c_(n-1)=(2n-1)/(2n). The original collision
formula therefore simplifies exactly to

    C_k=(2n+1)c_n[(k-1)-2n/3],
    v_k=[k(k-1)-C_k]/8.

This scalar shortcut pays polynomial-size integer arithmetic, not a quantum
state or code compiler. `modular_resource_costs.py` checks it against the
original sum at small k and evaluates the modular formulas directly.

For upper-only cost guarantees one may instead use separately
`g_lower=(3/25)r^2/36`, `kappa_lower=(3/25)r^2/192`,
`Xi_upper=(4001/100000)r^2/8`, `Upsilon_upper=k/4`.
These must not be combined as if the actual t0 simultaneously equaled
both extreme susceptibility values. The conservative mixed bounds are
valid because they are used in their monotone directions.

The full source dimension3^k, spectral clipping, exact bin selection,
overflow expurgation, Tverberg/KL encoder and decoder remain existence
operations. W39's original square-state factory is not silently transferred
to clipped V2. No positive-excess circuit advantage, physical validation,
energy/reset budget or practical performance follows. Mission NOT_ACHIEVED;
novelty and external correctness remain separate UNKNOWN gates.
