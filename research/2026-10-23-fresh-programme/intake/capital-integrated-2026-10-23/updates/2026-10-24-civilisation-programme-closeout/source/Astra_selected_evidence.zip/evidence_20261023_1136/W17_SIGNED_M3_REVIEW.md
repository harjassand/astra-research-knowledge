# Independent review of the signed quantum cubic remainder

23 October 2026. Reviewer W17. No producer code or numerical data imported.

Reviewed immutable source: W38 `new_independent_epni_invention/GLOBAL_QUANTUM_THIRD_MOMENT.md`, SHA256 `c0d55deb9106545533aca7acb2c82125402bdbf41cfb130a4f1e389066687cc3`. A byte-identical copy is retained alongside this receipt. Corpus HEAD remains `e606bfc587c76bdcae8b8fa3ec33e721efa2fbac`.

Verdict: no blocking mathematical defect found at the stated bounded-relative scope. This is an internal independent reconstruction, not external validation or a priority determination. The exact resolvent identity and the ALT tool have prior formulations. Priority of the particular signed cubic inequality remains UNKNOWN.

## Exact contract

Use natural logarithms. Let \(\tau\) be any faithful normal density operator, \(F=F^*\) bounded, \(F\ge-I\), and \(\operatorname{Tr}\tau F=0\). Set \(X=\tau^{1/2}F\tau^{1/2}\) and \(\rho=\tau+X\). No smallness bound on the positive spectral peak is imposed. Then

\[
-\frac16\operatorname{Tr}\tau F_+^3
\le D(\rho\Vert\tau)-\frac12Q_\tau(X)
\le\frac12\operatorname{Tr}\tau F_-^3.
\]

All quantities are finite. Neither finite \(S(\tau)\) nor finite \(S(\rho)\) is required; relative entropy is its normal lower-semicontinuous definition, not an unsupported subtraction of two infinite entropies. This result by itself supplies no channel contraction of a quantum cubic moment, no amplifier EPnI, and no extension to an unbounded positive relative density.

## 1. Finite identity and the kernel endpoint

Put \(R_{t,s}=(\tau+tX+sI)^{-1}\). The entropy Hessian gives

\[
D(\rho\Vert\tau)
=\int_0^1(1-t)\int_0^\infty\operatorname{Tr}X R_{t,s}X R_{t,s}\,ds\,dt.
\]

For \(K_s=(\tau+sI)^{-1/2}X(\tau+sI)^{-1/2}\), cyclicity changes the inner trace to \(\operatorname{Tr}K_s^2(I+tK_s)^{-2}\). Integrating each eigenvalue in \(t\) yields

\[
\int_0^1\frac{(1-t)k^2}{(1+tk)^2}\,dt=k-\log(1+k)=:h(k).
\]

Thus \(D=\int\operatorname{Tr}h(K_s)ds\), and \(Q=\int\operatorname{Tr}K_s^2ds\). This argument does not replace noncommuting logarithms by the logarithm of their quotient.

The endpoint \(F\ge-I\) is safe even when \(\rho\) has a kernel. Writing \(A_s=[\tau/(\tau+sI)]^{1/2}\),

\[
K_s=A_sFA_s\ge-A_s^2,
\qquad \|A_s^2\|=\frac{\|\tau\|}{\|\tau\|+s}<1\quad(s>0).
\]

Every fixed positive \(s\) therefore has spectrum strictly above \(-1\). The logarithm and its negative-spectrum series are defined there. A finite-dimensional \(t\uparrow1\) limit also permits \(0\log0=0\).

## 2. Signed moments: the noncommutative step

The bounds \(-A_sF_-A_s\le K_s\le A_sF_+A_s\) imply domination of the ordered positive eigenvalues separately by min-max. They do not assert a generally false operator inequality between positive parts. Consequently,

\[
\operatorname{Tr}(K_s)_\pm^m
\le\operatorname{Tr}(A_sF_\pm A_s)^m
\le\operatorname{Tr}F_\pm^m A_s^{2m},\qquad m\ge2.
\]

The last step is positive ALT. Its direction is exactly the \(r\ge1\) direction of [Audenaert, Theorem 1](https://arxiv.org/pdf/math/0701129); Proposition 3 also supplies an absolute Hermitian version, but that weaker absolute version alone would lose the signed constants. Cyclicity and scalar functional calculus of \(\tau\) give

\[
\int_0^\infty\operatorname{Tr}(K_s)_\pm^m\,ds
\le\sum_j\langle j|F_\pm^m|j\rangle
\int_0^\infty\left(\frac{p_j}{p_j+s}\right)^m ds
=\frac{\operatorname{Tr}\tau F_\pm^m}{m-1}.
\]

For \(k\ge0\), \(-k^3/3\le h(k)-k^2/2\le0\). For \(-1<k\le0\), \(h(k)-k^2/2=\sum_{m\ge3}|k|^m/m\). Tonelli applies to each nonnegative signed contribution. The positive contribution is bounded using \(m=3\); the negative contribution uses \(F_-\le I\) and \(\sum_{m\ge3}1/[m(m-1)]=1/2\). This proves the claimed constants and finiteness of the integrated absolute remainder.

## 3. Normal-state completion

Choose finite spectral-coordinate projections \(P_M\uparrow I\) commuting with \(\tau\). The trace-preserving compression with a tail symbol sends the pair to

\[
\tau_M=P_M\tau P_M\oplus q_M,
\qquad \rho_M=P_M\rho P_M\oplus\operatorname{Tr}(I-P_M)\rho.
\]

The relative operator is \(P_MFP_M\oplus f_M\), where \(f_M=\operatorname{Tr}(I-P_M)\tau F/q_M\) if \(q_M>0\). It has the same lower bound \(-I\), uniformly bounded norm, and zero reference mean. A zero tail is omitted.

The embedded \(P_MFP_M\) converges bounded strongly to \(F\). Continuous functional calculus on a common compact spectral interval gives bounded-strong convergence of its positive and negative cubes. Testing against trace-class \(\tau\) gives convergence of the two weighted cubic moments. The tail contribution is at most \(q_M\|F\|^3\to0\).

In a \(\tau\)-eigenbasis,

\[
Q_\tau(X)=\sum_{ij}\frac{|X_{ij}|^2}{\ell(p_i,p_j)}
\le\sum_{ij}\frac{p_i+p_j}{2}|F_{ij}|^2
=\operatorname{Tr}\tau F^2<\infty,
\]

where the logarithmic mean dominates the harmonic mean. The nonnegative finite block sums increase to \(Q\); the scalar-tail term is at most \(q_M\|F\|^2\) and vanishes. Normal DPI gives \(D(\rho_M\Vert\tau_M)\le D(\rho\Vert\tau)\). Embed the tail in one coordinate outside \(P_M\): both embedded states converge in trace norm to the original pair, so joint lower semicontinuity gives the opposite limit inequality. Thus \(D_M\to D\), including an initially extended-valued \(D\). Passing the finite cubic bound also proves that this \(D\) is finite.

For completeness, the exact normal resolvent identity U2 can be closed without an interchange of infinite logarithms. Use principal compressions without a tail and generalized relative entropy

\[
D_+(A\Vert B)=\operatorname{Tr}A(\log A-\log B)-\operatorname{Tr}A+\operatorname{Tr}B.
\]

Normal DPI with a tail symbol and lower semicontinuity imply \(D_+(P_M\rho P_M\Vert P_M\tau P_M)\to D(\rho\Vert\tau)\). For fixed \(s\), the compressed relative resolvent is exactly \(P_MK_sP_M\). The function \(h(x)=x-\log(1+x)\) is operator convex on \((-1,\infty)\), nonnegative, with \(h(0)=0\). Compression Jensen implies that \(\operatorname{Tr}h(P_MK_sP_M)\) increases with \(M\) and is bounded above by \(\operatorname{Tr}h(K_s)\). Bounded-strong functional calculus plus trace Fatou gives the reverse limit inequality. Monotone convergence in \(M\), followed by the finite generalized identity, establishes U2. This adds detail to the source's brief normal-limit paragraph; it does not add a new hypothesis.

For ALT in normal dimension, first apply the finite theorem to the same commuting spectral projections. The positive sandwiched operators converge in trace norm; bounded-strong powers on the other side are tested against trace-class \(A_s^{2m}\). This yields the displayed signed moment bounds. Every fixed \(s>0\) has trace-class \(K_s\), since \(A_s\) is Hilbert-Schmidt.

## 4. Both constants are sharp

This is an additional reviewer derivation, not needed to validate U1. In a commuting binary reference let \(p=\epsilon\), and let \(F\) take values \(\epsilon\) and \(-\epsilon^2/(1-\epsilon)\). It is centered, and

\[
\frac{-[D-Q/2]}{\operatorname{Tr}\tau F_+^3}\longrightarrow\frac16.
\]

For the upper constant, let \(F=-1\) on a reference event of probability \(p\), and \(F=p/(1-p)\) on its complement. Then

\[
D=-\log(1-p),\quad Q=\frac{p}{1-p},\quad
\frac{D-Q/2}{\operatorname{Tr}\tau F_-^3}\longrightarrow\frac12.
\]

Thus neither universal one-sided coefficient can be decreased in this model class.

## 5. Independent diagnostics and their limits

`check_signed_remainder.py` uses only NumPy, Python Decimal, and standard libraries, with its own fixed RNG seed. It ran 160 noncommuting finite states: 80 kernel cases, 78 positive peaks above one, largest positive peak approximately 1,336,408. All signed bounds passed. Six separate composite Gauss quadratures check U2 and signed U3 for powers 2,3,4; the maximum U2 discrepancy was below \(5.1\times10^{-9}\), and refinement changed results by at most \(1.34\times10^{-15}\). The improper integral tails are not interval-certified; these are diagnostics, not the analytic proof.

An analytic infinite direct sum uses \(\tau=\bigoplus_n w_n\operatorname{diag}(.2,.8)\), \(\rho=\bigoplus_nw_n|\psi\rangle\langle\psi|\), \(\psi=(1,i)/\sqrt2\). Choosing \(w_n\propto1/[n\log(n+1)^2]\) permits infinite reference entropy. All four functionals are homogeneous blockwise and finite; five tail-symbol tests reproduce the exact retained-mass scaling. Three 90-digit binary limits check sharpness. These examples do not numerically verify all normal operators.

The first numerical run used a fixed absolute positivity tolerance for \(F\), which was too tight at million-scale positive eigenvalues. The analytically positive pure-state fixtures have floating eigenvalue error scaling with \(\|F\|\). The final script explicitly checks and records this scale-dependent error; no mathematical inequality failed and no state was projected into the admissible class. Runtime was 0.8845 seconds; peak macOS RSS was 37,601,280 bytes on the shared host. These costs exclude discovery and review.

## 6. Prior-art and resource boundary

The BKM Hessian, entropy Taylor expansions, min-max, scalar logarithmic bounds, ALT, normal DPI and lower semicontinuity are established tools. The exact finite U2 identity follows already by integrating [Frenkel 2208.12194v4, Lemmas 4–5](https://arxiv.org/pdf/2208.12194); its higher-derivative representations are in Theorem 7. [Grace–Guha 2106.05533v3, Theorem 3](https://arxiv.org/pdf/2106.05533) gives the established second-order relative-entropy expansion with an asymptotic cubic remainder.

An explicit exact finite shifted-LogDet statement is also [Gauvin, Preprints 202609.0123v1, Theorem 11, equations 311–312](https://www.preprints.org/manuscript/202609.0123). Congruence of that LogDet divergence is precisely \(\operatorname{Tr}[K_s-\log(I+K_s)]\). Its indexed primary theorem text was read for this statement comparison; the large full HTML fetch and two PDF routes failed. That unreviewed preprint is not a mathematical dependency of this audit. No priority is assigned to U2 here. No exact primary match to the particular signed, sharp, globally bounded-relative U1 was located in these focused searches; this does not establish novelty.

The lemma is analytic and performs no physical preparation, bath reset, measurement or control. Supplying a bounded relative-density description is a hypothesis, not an experimentally acquired certificate. No energy constraint, implementation, physical validation, useful finite regime or preparation cost is established by this receipt. The subsequent heated finite-Fock theorem requires its own moment, kernel, output and covariance proof; this receipt does not certify it.
