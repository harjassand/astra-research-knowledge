"""New sparse full-two-seed diagnostics of C* B C coherent-sector oracle.

No producer peer import or truncated physical bath. All reachable native words
are explicit dictionary keys, with complete input columns. Exact inverse is a
MATHEMATICAL reference; selected cases also run literal positive-power queries.
"""
from pathlib import Path
import itertools,math,time,json,datetime
import numpy as np
ROOT=Path(__file__).parent

def words(H):return [w for h in range(H+1) for w in itertools.product((1,2),repeat=h)]

def add(out,key,value):
    if key in out:out[key]+=value
    else:out[key]=value.copy()

def native_gate(state,t,beta,adjoint=False):
    out={};alpha=math.sqrt(1-beta*beta);ico=(-1j if adjoint else 1j)*beta
    for (seed,w,p,label),v in state.items():
        add(out,(seed,w,p,label),ico*v)
        port=p[t];po=list(p)
        if port:po[t]=0;wo=(port,)+w;so=seed
        elif w:po[t]=w[0];wo=w[1:];so=seed
        else:po[t]=0;wo=w;so=1-seed
        add(out,(so,wo,tuple(po),label),alpha*v)
    return out

def y_rotate(state,pairs,inverse=False):
    # Y=i(|10><01|-|01><10|). Columns are its +/- eigenvectors.
    E=np.array([[1,1],[1j,-1j]],complex)/math.sqrt(2)
    matrix=E if inverse else E.conj().T
    out=state
    for t in (reversed(pairs) if inverse else pairs):
        new={}
        for (seed,w,p,label),v in out.items():
            pair=p[t:t+2]
            if pair not in [(0,1),(1,0)]:add(new,(seed,w,p,label),v);continue
            col=0 if pair==(0,1) else 1
            for row,pattern in enumerate([(0,1),(1,0)]):
                po=list(p);po[t:t+2]=pattern
                add(new,(seed,w,tuple(po),label),matrix[row,col]*v)
        out=new
    return out

def classifier(p,pairs):
    score=sum(1 if p[t:t+2]==(0,1) else -1 if p[t:t+2]==(1,0) else 0 for t in pairs)
    return int(score<0) # tie -> sector+

def B_gate(state,pairs):
    out=y_rotate(state,pairs);new={}
    for (s,w,p,l),v in out.items():add(new,(s,w,p,l^classifier(p,pairs)),v)
    return y_rotate(new,pairs,True)

def make(H,s0,r,s):
    program=[0]*s0;pairs=[]
    for _ in range(r):pairs.append(len(program));program.extend([1,0]+[0]*s)
    program=tuple(program);ws=words(H);d=4*len(ws)
    init={};columns=[]
    for seed in [0,1]:
        for w in ws:
            for label in [0,1]:columns.append((seed,w,label))
    for k,(seed,w,label) in enumerate(columns):
        v=np.zeros(d,complex);v[k]=1;init[(seed,w,program,label)]=v
    return init,columns,program,pairs

def gram(state,d):
    out=np.zeros((d,d),complex)
    for v in state.values():out+=np.outer(v.conj(),v)
    return out

def target_Xor(columns,program):
    out={};d=len(columns)
    for k,(s,w,l) in enumerate(columns):
        for so,lo,co in [(s,l,.5),(1-s,l,.5),(s,l^1,.5),(1-s,l^1,-.5)]:
            v=np.zeros(d,complex);v[k]=co;add(out,(so,w,program,lo),v)
    return out

def diff_norm(A,B,d):
    G=np.zeros((d,d),complex)
    for key in A.keys()|B.keys():
        v=A.get(key,0)-B.get(key,0);G+=np.outer(np.conjugate(v),v)
    return math.sqrt(max(0,float(np.linalg.eigvalsh((G+G.conj().T)/2)[-1])))

def worst_classifier_error(rotated,columns,pairs,x):
    ws=sorted(set(w for s,w,l in columns),key=lambda w:(len(w),w));ix={v:k for k,v in enumerate(columns)}
    effect=np.zeros((len(ws),len(ws)),complex);correct=0 if x==1 else 1
    for (seed,w,p,l),v in rotated.items():
        if classifier(p,pairs)==correct:continue
        col=np.array([(v[ix[(0,u,0)]]+x*v[ix[(1,u,0)]])/math.sqrt(2) for u in ws])
        effect+=np.outer(col.conj(),col)
    return max(0,float(np.linalg.eigvalsh((effect+effect.conj().T)/2)[-1]))

def one(H,s0,r,s,beta,literal=False):
    initial,cols,program,pairs=make(H,s0,r,s);d=len(cols);L=len(program)
    C=initial
    for t in range(L):C=native_gate(C,t,beta)
    rotated=y_rotate(C,pairs)
    eta_plus=worst_classifier_error(rotated,cols,pairs,1)
    eta_minus=worst_classifier_error(rotated,cols,pairs,-1)
    Q=B_gate(C,pairs)
    if literal:
        # beta=.5 -> V^12=I on full U +/- eigenspaces. Use11 TRUE V
        # calls per inverse, with the same returned qutrit each time.
        assert abs(beta-.5)<1e-15;k=11
        for t in reversed(range(L)):
            for _ in range(k):Q=native_gate(Q,t,beta)
        actual_calls=L+k*L
    else:
        for t in reversed(range(L)):Q=native_gate(Q,t,beta,True)
        actual_calls=0 # mathematical diagnostic, NOT legal forward-call execution
    target=target_Xor(cols,program);err=diff_norm(Q,target,d)
    eta=max(eta_plus,eta_minus);exact_relation=abs(err-2*math.sqrt(eta))
    isometry=float(np.linalg.norm(gram(Q,d)-np.eye(d)))
    assert isometry<2e-10 and exact_relation<2e-10
    a=1-beta*beta;b=beta*beta;m=2*a**1.5*beta
    tau=sum(math.comb(s0,k)*a**k*b**(s0-k) for k in range(min(H,s0+1)))
    bound=math.exp(-r*m*m/2)+4*math.sqrt(tau)+4*r*b**(s/2)
    assert eta<=bound+2e-11
    return dict(H=H,s0=s0,r=r,s=s,beta=beta,L=L,input_columns=d,
        classifier_eta_plus=eta_plus,classifier_eta_minus=eta_minus,
        CS1_error_bound=bound,complete_oracle_operator_error=err,
        exact_2sqrt_eta_relation_defect=exact_relation,isometry_error=isometry,
        literal_positive_power_native=literal,actual_forward_query_diagnostic_count=actual_calls,
        returned_qutrit_count=actual_calls if literal else 0,
        reachable_basis_keys=len(Q)),Q,target

def beta0_no_go():
    # Same program in both root sectors: every final state differs by(-1)^N P_E.
    rows=[]
    for N in [1,2,3,4]:
        prog=tuple([1 if i%2==0 else 0 for i in range(N)])
        # Coherent probe program with different port patterns, same in both sectors.
        for x in [-1,1]:
            pass
        plus={};minus={}
        for seed in [0,1]:
            v=np.array([1/math.sqrt(2)],complex)
            plus[(seed,(),prog,0)]=v
            minus[(seed,(),prog,0)]=((-1)**seed)*v
        for t in range(N):
            plus=native_gate(plus,t,0.);minus=native_gate(minus,t,0.)
        corrected={}
        for (seed,w,p,l),v in plus.items():
            # Sector- embedding has extra(-1)^seed; seed parity operator does
            # not change words. Compare full Z-seed amplitudes explicitly.
            corrected[(seed,w,p,l)]=((-1)**(N+len(w)+seed))*v
        err=diff_norm(minus,corrected,1)
        assert err<2e-12
        rows.append(dict(N=N,full_two_seed_gauge_error=err))
    psi=np.array([1,1],complex)/math.sqrt(2);rho=np.outer(psi,psi.conj())
    parity=np.diag([1,-1]);other=parity@rho@parity
    sep=float(np.sum(np.abs(np.linalg.eigvalsh(rho-other))))
    assert abs(sep-2)<2e-12
    return dict(native_gauge=rows,even_odd_target_parity_distance=sep,
                unlabeled_equal_sector_factory_error_lower_bound=sep/2)

def main():
    start=time.perf_counter();rows=[];raw={}
    fixtures=[(0,0,1,0),(0,0,1,2),(0,0,2,1),(0,0,3,1),
              (1,1,1,1),(1,2,2,1),(1,2,3,1)]
    for f in fixtures:
        for beta in [.2,.5,.9]:
            row,Q,S=one(*f,beta);rows.append(row)
            if f==(1,1,1,1) and beta==.5:
                keys=sorted(Q.keys()|S.keys(),key=repr)
                raw['oracle_keys']=np.array([repr(k) for k in keys])
                raw['oracle_actual']=np.stack([Q.get(k,np.zeros(row['input_columns'])) for k in keys])
                raw['oracle_target']=np.stack([S.get(k,np.zeros(row['input_columns'])) for k in keys])
    literal=[]
    for f in fixtures[:3]+[fixtures[4]]:
        row,_,_=one(*f,.5,literal=True);literal.append(row)
    result=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        status='FINITE_FULL_TWO_SEED_COHERENT_ORACLE_DIAGNOSTICS_NOT_HIGH_ACCURACY_FACTORY',
        exact_inverse_reference_cases=len(rows),literal_forward_power_cases=len(literal),
        max_exact_relation_defect=max(r['exact_2sqrt_eta_relation_defect'] for r in rows+literal),
        max_isometry_error=max(r['isometry_error'] for r in rows+literal),
        peer_code_or_data_imports=0,source_or_physical_calls=0,packages_installed=0,
        scope='Reference cases use mathematical adjoints; literal cases count all repeated forward V. Small classifiers do not demonstrate asymptotically tiny error.',
        reference=rows,literal=literal,beta0_obstruction=beta0_no_go(),
        wall_seconds=time.perf_counter()-start)
    (ROOT/'COHERENT_SECTOR_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
    np.savez_compressed(ROOT/'coherent_sector_raw.npz',**raw)
    print(json.dumps({k:v for k,v in result.items() if k not in ['reference','literal']},indent=2))

if __name__=='__main__':main()
