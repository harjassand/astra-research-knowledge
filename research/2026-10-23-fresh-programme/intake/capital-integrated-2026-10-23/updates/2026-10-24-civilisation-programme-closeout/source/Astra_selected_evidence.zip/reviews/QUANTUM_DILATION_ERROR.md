# Independent audit of the unrestricted quantum leading error constant

Supplied W68 proof: QUANTUM_ERROR_CONSTANT.md, SHA256
72211f7622e3f6a79296257382f3fde723a9da84a83edbd8d0ae948664de7816.
The frozen hash was requested before reading. W61 reconstructed the effect,
variance, spectral-rank, and overlap mechanism from the checkpoint before
reading the entire proof, then audited every step. W40's review was not read
before forming and recording this independent verdict.

## Verdict and exact scope

PASS: no gap identified. For arbitrary ancillary dimension K and arbitrary
commuting normalized-trace-preserving conditional expectations F,G onto
unital C* subalgebras of M_(r^3 K), the FULL-DOMAIN unhalved marginal diamond
error epsilon obeys the displayed necessary inequality below. It implies
epsilon>=2/(r+16) and hence optimal leading constant two, matching the
explicit error 2/(r+1) upper construction.

No physical-diagonal, separable, commutative-range, three-block, or returned-
ancilla hypothesis enters the lower bound. Conversely the norm must hold
on ALL enlarged inputs; product-ancilla compression cannot replace it.
The original P,Q commute and have the specified one-label overlap. The proof
does not address general noncommuting input projections or exact finite-r
quantum optimality. Established operator-algebra mechanisms are not new laws;
historical priority and external validation remain UNKNOWN.

## 1. The factor one half is valid for this unhalved metric

Let A_ch=D F and B_ch=E_P D, with D ordinary partial trace. Both are channels,
and A_ch-B_ch is trace-annihilating. Every effect Z has adjoint difference
operator norm at most epsilon/2. This follows either from the trace-zero
output-state variational formula or by centering Z at I/2 and using
(A_ch-B_ch)^*(I)=0. No dimension or reference factor is hidden.

Writing P,Q for the lifted physical projections, delta=epsilon/2 and
c=1/(r+1), the exact target identities give

    ||F(P)-P||,||G(Q)-Q||<=delta,
    ||F(Q)-[cP+(c/r)I]||<=delta,
    ||G(P)-[cQ+(c/r)I]||<=delta.                         (A1)

The adjoint of ordinary partial trace is Y->Y tensor I, with no K factor.
Tracial expectations are trace self-adjoint. The coefficient check is
E_P(Q)=P/r+(I-P)/[r(r+1)]=cP+(c/r)I. This is block averaging, not pinching.

## 2. Dimension-free quadratic variance and the spectral-rank gate

Let E be any tracial conditional expectation, R a rank-m projection,
A=E(R), and ||A-R||<=delta<1/2. Bimodularity gives the exact identity

    E((R-A)^2)=A-A^2<=delta^2 I.                         (A2)

A is an effect. Put alpha=(1-sqrt(1-4delta^2))/2. Every eigenvalue of A
lies in [0,alpha] or [1-alpha,1]. Weyl perturbation relative to R places
the first m eigenvalues at least 1-delta and all remaining at most delta.
Since delta<1/2 and alpha<=delta, exactly m eigenvalues occupy the high
cluster. Equivalently its high spectral projection is within delta+alpha<1
of R and has the same rank. Either route is valid and ambient independent.

Trace preservation gives Tr(A)=m. Let s be the mass in the low cluster;
it equals the total deficit of the m high eigenvalues from one, so
0<=s<=alpha m. Consequently

    Tr(A-A^2)<=2s<=2alpha m.

Trace self-adjointness and idempotency imply Tr(RA)=Tr(A^2), so

    v=||A-R||_HS^2=m-Tr(A^2)=Tr(A-A^2)<=2alpha m.         (A3)

The HS norm and trace here are UNNORMALIZED. A naive bound delta^2 times
the full ambient dimension would not suffice. At delta=1/2 use v<=m,
which is exactly the displayed 2alpha m bound; no strict spectral-rank
inference is needed at that endpoint.

If B is an effect commuting with R, then

    |Tr((A-R)B)|<=v.                                   (A4)

The R diagonal block of A-R is negative, its complementary block positive,
and their absolute traces are both v. Commutation makes B block diagonal;
its two weighted traces lie in [-v,0] and [0,v]. This proves (A4), even if
A and R do not commute. Original lifted P,Q do commute, so the lemma applies
to the specific linear overlap terms.

## 3. A lower and an upper bound on the same overlap

Let m=rK, X=F(P)-P, Y=G(Q)-Q. Their squared HS norms v_F,v_G are at most
2alpha rK. Since Tr(PQ)=K and P,Q commute, (A4) and HS Cauchy--Schwarz give

    Tr(F(P)G(Q))
       >=K-v_F-v_G-sqrt(v_F v_G)
       >=K-6alpha rK.                                  (A5)

All trace products are real; the enlarged effects need not commute.

Commutation of the expectations, their self-adjointness and H=FG=GF give
the exact symmetry

    Tr(F(P)G(Q))=Tr(F(Q)G(P)).                           (A6)

By (A1), F(Q)<=cP+(c/r+delta)I, while G(P)>=0,
||G(P)||<=1/r+delta and Tr(G(P))=m. Also
Tr(P G(P))=Tr(G(P)^2). Positive-order comparison inside a trace therefore
yields, without assuming matrix products commute,

    Tr(F(Q)G(P))
       <=c Tr(G(P)^2)+(c/r+delta)m
       <=[2c+r(1+c)delta]K.                            (A7)

The factor c+c/r=1/r is correct. Combining (A5)--(A7), K>0 cancels:

    1<=2c+r(1+c)delta+6r alpha(delta).                   (A8)

These arguments use the original tracial trace at each stage, not a prepared
ancillary state or an output marginal rank promise.

## 4. Closed lower bound and the asymptotic statement

For 0<=delta<=1/2, alpha<=2delta^2. At delta=1/(r+16),

    2c+r(1+c)delta+12r delta^2<1,

because the numerator of the difference from one is
r^2+180r-256>0 for every r>=2. The right side is increasing in delta.
Thus epsilon>=2/(r+16). For epsilon>1 that bound is automatic. No endpoint
or infimum-attainment assumption is missing.

The unique positive root delta_r of equality in (A8) has expansion

    delta_r=1/r-9/r^2+120/r^3+O(r^-4).

The supplied first two terms are correct. A useful equivalent exact root
formula, derived during this audit, is

    u=1-(1-2c)/(3r), v=(1+c)/3,
    delta_r=(1-u^2)/[sqrt(v^2+4(1-u^2))+u v].            (A9)

The unsquared relation sqrt(1-4delta_r^2)=u+v delta_r is positive, so no
spurious root is introduced. The known finite upper construction has
epsilon=2/(r+1); squeezing gives r*epsilon_opt(r)->2 across ALL finite K
and arbitrary enlarged unital range algebras. The formula does not determine
the exact finite-r quantum optimum, and no such claim is adopted.

## 5. Adversarial tests and interpretation

The critical potential failures were the effect normalization, replacing
ambient dimension by rare projection rank, the high-cluster rank, use of
commuting ORIGINAL rather than enlarged projections, and multiplying an
operator order inequality inside a trace. Each is justified above. Dropping
trace preservation or bimodularity breaks (A2)/(A3), and a general idempotent
channel cannot silently replace a tracial conditional expectation.

The elementary ingredients are established mathematics. This audit supports
the parameter-specific leading error constant and its exact hypotheses,
not historical novelty, new entropy principles, hardware feasibility,
catalytic return, or practical speedup. All older packets stay frozen.
