# Root reconstruction of the compact-prior forest lower

24 October2026 local. Exact source fully read: W73 `COMPACT_PRIOR_FOREST_LOWER.md`, SHA256 45421a5832a0453574a2251c9bb9c3c6c5ef6c7e7ae7e493236d69343aeaab2c. **No blocking defect found in the complete analytic argument.** This reconstruction is explicitly CO-INFORMED: after the producer proposed a compact Fisher prior, root independently derived its full score/Schur chain and cautioned against a Fisher-to-KL shortcut during development. The source already used the correct TV path. W39 is now conducting the separate cold full review; do not call this a cold verdict.

The theorem's contract remains exact: positive labelled forests with weights[a,3a], unknown input fixed before design randomness, all n noisy outputs per common full-vector action, independent Gaussian sensor noise sigma, and a PATHWISE total per-vertex control budget B. The nonadaptive learner may use arbitrary real controls and unbounded computation, with hub/leaf metadata revealed only after commitment. For even n>=4, error<=delta<1/2 on every fixed promised input implies

    q[pi^2+8a^2B/sigma^2] >= n(1-2delta)^2.

The previous Gaussian-prior truncation proof remains valid but its log n overhead is unnecessary.

## Independent analytic derivation

Use independent positive leaf weights of density a^-1 cos^2[pi(w-2a)/(2a)] on[a,3a]. Its density and first derivative vanish at endpoints; the score has mean0 and squared expectation J=pi^2/a^2, since its tangent square cancels the cosine square. Its score is unbounded near the endpoints but square-integrable, sufficient for the following conditional Jensen argument. Gaussian convolution gives the observed density smooth full support.

For ANY rectangular full observation Y=HW+Z and any direction v, choose vectors alpha,beta with H alpha+beta=v. Integration by parts against a compact smooth test function gives

    E[alpha.score(W)+beta.score(Z)|Y]=v.grad log f_Y(Y).

The boundary term is zero, and Fubini is legitimate because the latent score is integrable and the Gaussian kernel is smooth. Independent mean-zero scores and conditional Jensen bound directional Fisher information by J||alpha||^2+sigma^-2||beta||^2. Minimizing alpha yields exactly

    I_Y(v)<=v^T[ sigma^2 I+J^-1 HH^T ]^-1v.

This matrix is an INFORMATION COMPARISON object. It is neither the actual observation covariance nor a non-Gaussian posterior covariance.

For the two-star prior, H's leaf column is r_l=s_l-s_h at the leaf and-r_l at its hub. The hypothesis changes only a times the full direction v=(e_U-e_V) tensor(s_U-s_V). Eliminating each leaf block from the comparison matrix gives the exact hub ridge coefficient (J+||r_l||^2/sigma^2)^-1. This is the same Schur algebra as the Gaussian calculation, but no Gaussian conjugacy for W is claimed. The two hub blocks are independent in that comparison matrix because their leaf columns are disjoint.

Since ||r_l||^2<=4B, comparison with the uniform coefficient (J+4B/sigma^2)^-1 and the previously proven leave-one-out ridge identity gives the averaged full directional Fisher bound

    E_metadata I_Y(v)<= (4q/n)(J+8B/sigma^2).

The fixed cloud/design lemma is deterministic. Uniform hidden labels/leaf partition are sampled independently of the design, and the exact uniform-(d+1)-set/held-out-index equivalence has d+1=n/2. Therefore the same bound holds after revealing metadata and after averaging arbitrary independent design randomization.

For the location family Y+t v, the fundamental theorem of calculus in L1 followed by Cauchy--Schwarz gives TV(P_a,P0)<=a sqrt(I_Y(v))/2. The Fisher bound is translation invariant, so averaging metadata/design and applying Jensen gives

    TV(P1,P0)<=sqrt{(q/n)[pi^2+8a^2B/sigma^2]}.

Both endpoint input priors are entirely positive promised forests. Intermediate hub-edge weights t in(0,a) are only an analytic translation path; the learner is never assumed to work on them. Equal-prior testing error at mostdelta requires TV>=1-2delta, proving the theorem. There is no KL claim from Fisher information and no prior-conditioning loss.

## Consequences and strong comparator

At fixed B and a/sigma, nonadaptive connectivity needs Omega(n) full actions. The separately reviewed two-action hidden-star corollary uses the same fixed sufficiently small sensor noise, B<=1/2, and actual acquired hubs. It therefore gives a linear separation at the stated sufficiently-large-n promises. This does not say two noisy actions acquire all forest edges.

An ordinary q=n standard-basis schedule supplies a matched nonadaptive upper, B=1. The n acquired diagonal entries identify the two order-n degree hubs at eventual large n despite Gaussian noise; the selected off-diagonal hub entry has mean0 or-a and noise independent of the diagonal data. Threshold-a/2 attains constant error under the same stricter two-action noise premise. Thus the connectivity-only nonadaptive order is Theta(n), not an unbounded/unknown comparator. This comparator is established ordinary column acquisition, not a new algorithm. Full-vector readout counts are n^2 versus2n; a selective or aggregate instrument is a changed contract.

The general-support adaptive upper still spends O(log^2 n) actions AND that order row energy at fixed sensor noise, and has separately charged decoder work. Its B=1 version requires a shrinking sensor-noise scale. No fixed-noise/B1 general-support theorem is inferred. Instrument dynamic range, coordinate preparation accuracy, impedance, duration and reset/calibration are unacquired physical premises. A row-norm budget is not Joules.

Root reopened the primary Dembo--Cover--Thomas1991 paper https://isl.stanford.edu/~cover/papers/transIT/1501demb.pdf . Fisher convolution/conditional-score methods are established; this application and exact forest separation still have priority UNKNOWN. Producer finite quadratures/rational checks remain diagnostics. This universal reconstruction is analytic. Cold review PENDING, physical validation NONE, mission NOT_ACHIEVED.
