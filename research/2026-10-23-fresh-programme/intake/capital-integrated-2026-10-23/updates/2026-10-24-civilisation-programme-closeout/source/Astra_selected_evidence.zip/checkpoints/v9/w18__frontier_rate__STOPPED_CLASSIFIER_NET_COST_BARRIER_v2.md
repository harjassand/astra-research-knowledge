# Net Bell cost of the same actual stopped classifier

23 October 2026, w18. Version2: wording correction after w44 fresh review;
the frozen v1 remains unchanged. Bell-verifier failure is bounded ABOVE by
the Bell infidelity, and monotonic replacement gives the same inequalities.
A new operational method barrier derived while testing
coherent and nonlinear implementations of the governing classifier. The
finite information-radius method is credited to w44's preceding
GENERAL_LOCC_TRANSCRIPT_INFORMATION_BILL.md, frozen SHA256
25add9d824b9dccd1f3363e686dccb8bfbd30ce4acbfcf163fc74fbbbc56645c.
I reconstructed and reviewed that finite bill independently. The stock-return
extension and this clock-joint instrument application are derived below.
Historical priority and external correctness remain UNKNOWN.

This does NOT bound the unrestricted original receiver by H-O(1). It proves
that a more coherent implementation of the SAME stopped classifier cannot
save a diverging number of Bell nats per queue while preserving the stated
source-clock/output law. It is independent of fixed-partition comparisons.

## 1. Source, stock and finite information bill

Fix the unchanged original finite D,L,p before taking r to infinity. Its
accessible conditional state is sigma_k=Phi_D^tensor k tensor nu_D^tensor(L-k),
nu_D=I/(D^2), with B=E K lnD and H=H(K). The actual COMPLETE input has the
inaccessible duplicated classical K clock and the independent product old
memory of pinned PROOF.txt equation(1), revision
e606bfc587c76bdcae8b8fa3ec33e721efa2fbac. Neither is supplied to the receiver.

For the purpose of CHARGING a classifier, allow an independent exact initial
Bell stock Phi_M, M a predetermined finite rank. Other apparatus is normal
local product and independent of the COMPLETE source and stock. The operation
is arbitrary finite TP LOCC, coherent across all r queues and using two-way
communication. All branches, flags and work are retained in the actual
residual. Suppose its predetermined target ports have ranks N and M', with
unconditional Bell infidelities respectively eps and gamma, both below1/2.
The rank M' is interpreted as stock returned, and N as gross useful output.
Either rank may equal1, in which case omit its test and set its infidelity
to zero. Let T be any finite actual classical transcript of this operation.

Then the following finite inequality holds:

    I(K^r:T)
      +(1-eps)ln[(N+1)/2] +(1-gamma)ln[(M'+1)/2]
      -h2(eps)-h2(gamma) <= rB+lnM.                    (1)

No independence of the two ACTUAL output ports is assumed in(1). Two nearly
pure Bell marginals imply a nearly pure joint Bell output by the union bound
on their commuting projectors. The usual pure-output lift then supplies
decoupling from the OWN actual COMPLETE residual, with dimension-free error.

To prove(1), use the same operation on the all-white native input AND the
all-white stock I/(M^2). This reference is separable. A terminal effect of
the receiver and appended local Bell-verification tests is separable across
the original Alice:Bob cut. Conditional on K^r=k, native pure Bell sites and
the supplied stock combine to a maximally entangled factor of rank

    d_k=M D^(sum_a k_a).

Tracing the other native white positions out of the effect preserves
separability. The product-vector Bell-overlap inequality gives, pointwise,

    P_k(y) <= d_k Q(y),
    D(P_k||Q) <= (sum_a k_a)lnD+lnM.                    (2)

The reference is full rank on all finite native and stock inputs, so there
is no support exception. Independent normal local apparatus is absorbed
into local effective maps on those finite inputs, as in w44's finite bill.

For every finite rank J, the finite random-basis LOCC verifier has pass
effect (I+J Phi_J)/(J+1). It accepts Phi_J with probability1 and accepts any
separable state with probability at most q_J=2/(J+1). Its exact finite
setting ensemble follows from compactness/finite-dimensional convexity;
no continuously indexed setting or supplied shared seed is needed.

Append separate such verifiers for the returned-stock and useful-output
ports, in that order, with classical bits S',S. On the reference's OWN
T=t, the stock pass probability is at most q_(M'). After either stock-test
outcome, every conditional reference branch is still separable, so the
main pass probability is at most q_N on its OWN (t,S') history. This is
conditioning the reference, not substituting an iid source after observing
an internal actual transcript.

The information-radius identity gives exactly

    sum_k p(k)D(P_k||Q)=I(K^r:T,S',S)+D(P_mix||Q).       (3)

For a binary actual pass probability u and reference pass probability at
most q, d(u||q_actual)>=u ln(1/q)-h2(u). Apply the divergence chain rule to
T,S',S, discard the nonnegative transcript radius, and use entropy
concavity. The actual stock-verifier failure is at most gamma and the actual
main-verifier failure is at most eps. For failure probabilities below1/2,
the stated binary lower bound decreases with the failure probability, so
these infidelity bounds may be substituted. A TP test on the separate stock
port leaves the main unconditional marginal unchanged. Thus

    D(P_mix||Q)>= (1-gamma)ln(1/q_(M'))-h2(gamma)
                   +(1-eps)ln(1/q_N)-h2(eps).           (4)

Drop I(K:S',S|T), average(2), and obtain(1).

The SEPARATE coefficients in(1) matter: only the stock-return infidelity
gamma multiplies lnM'. Using just a combined Bell verifier would multiply
lnM' by the main classifier/hash error too and would give a weaker limit.
For EXACT returned Bell stock gamma=0, its logarithm has coefficient1,
even if the returned rank is enormous. For approximate return, cancellation
of stock logarithms at the per-queue rate requires

    gamma_r lnM'_r=o(r).                               (5)

For example lnM'_r=O(r) and gamma_r->0 suffice. No arbitrary gigantic
approximate-catalyst cancellation is claimed. Without(5), the explicit
error-dimension term remains in the finite bound. No continuity of a
large catalyst's entropy is invoked.

## 2. Exact ideal stopped instrument on the actual clock

Use the governing classifier: measure the sitewise computational XOR
sectors nondestructively until the first nonzero sector, or the end. Let
V=(U,E_U), or *, and n(V)=U-1, or L on *. Conditional on ACTUAL K=k and
V=v, the retained quantum state is precisely

    theta_(k,v)=Phi_D^tensor k tensor chi_D^tensor(n(v)-k),
    chi_D=(1/D)sum_a |aa><aa|.                          (6)

Variable-size ports may be padded to a fixed finite D^L native output
with declared local product fillers; v specifies the occupied ports.
The ideal joint state eta_FVQ records the SAME actual inaccessible K,
duplicates v to the two parties, and has retained state(6). No fictitious
replacement clock is permitted. A mathematical phase label X of the
retained MC state is used only to calculate its entropy, never supplied
operationally.

Let theta_v be the actual normalized mixture in(6). Conditional hashing
of these finitely many maximally correlated states has gross Bell rate

    d=sum_v p(v) I_c(theta_v)
     =B-H(K|V)+H(K|X,V).                               (7)

It is nonnegative and attainable by the already credited one-way hashing
theorem. All typical-count failures get fixed fillers; the final gross
Bell rank is deterministic. This is the governing source-specific
calculation, not a new general hashing primitive.

Put G=n(V)-K. Given K, G is a capped geometric overshoot with zero-tail
probability r0=1/D; hence E G<=r0/(1-r0). Since K=n(V)-G and n is determined
by V, the elementary maximum-entropy bound on a nonnegative integer gives

    H(K|V)<=H(G)<=c(r0),
    c(u)=-ln(1-u)-u ln(u)/(1-u),
    c(1/D)<=2ln2.                                     (8)

This bound includes the overflow/all-zero branch *, zero prior atoms,
single-support priors and all finite original D, including nonpowers.

## 3. Arbitrary collective implementation and its net cost

Consider any sequence of finite TP LOCC implementations on r ACTUAL
COMPLETE iid queues, using exact independent input stock Phi_(M_r),
reporting an actual duplicated record V_r, and returning a predetermined
Bell port of rank M'_r. Require only

    T(omega_(F V_r Q), eta_FVQ^tensor r)<=beta_r->0,     (9)

where F is the original actual inaccessible clock, together with stock
Bell infidelity gamma_r->0 and(5). The parties cannot act on F. All work
and unused systems remain in the actual residual. The output record has
the ideal record alphabet^r, with a designated failure/overflow report
mapped into that alphabet if necessary; arbitrary extra internal records
can also be retained. An implementation with a separate extra failure
symbol may be covered by padding the ideal alphabet with its zero atom.

Clock-joint approximation is essential. Mere approximation of the
accessible V_r Q marginal does NOT imply the information term used below.
Nor does replacing the physical F by a newly generated iid clock satisfy(9).

At fixed finite support size m=|supp p|, tracing(9) gives classical total
variation at most beta_r for (K^r,V_r). Classical conditional entropy has
the elementary continuity bound

    |H_P(A|B)-H_Q(A|B)|<=beta ln|A|+h2(beta).            (10)

For completeness, split P,Q into their common part of weight1-beta and
two remainder laws. Conditional entropy of either mixture lies between
the mixture of conditional entropies and that mixture plus h2(beta).
Each remainder conditional entropy is in[0,ln|A|], proving(10).
The actual K^r marginal is unchanged, so

    I(K^r:V_r)>=r I(K:V)-beta_r rlnm-h2(beta_r).         (11)

When m=1 use ln m=0; no division by H or assumption H>0 occurs.

Append the governing gross hash code to Q,V_r without acting on the
returned stock. On the ideal iid classified block it produces deterministic
rank N_r with lnN_r/r->d and infidelity zeta_r->0, choosing slacks by a
standard diagonal sequence. Contractivity of the SAME actual block map
gives actual main infidelity eps_r<=beta_r+zeta_r. Extra transcript/work
correlations are handled by the pure-output lift; no one-copy error is
tensorized. The stock marginal and gamma_r are unchanged.

Apply(1) with T containing V_r, use(11), and subtract lnM'_r. With(5),
eps_r->0, bounded lnN_r/r, and fixed D,L,p, every admitted sequence obeys

    liminf_r [lnM_r-lnM'_r]/r
       >= d+I(K:V)-B
        = H(K)-2H(K|V)+H(K|X,V)
       >= H(K)-2c(1/D)
       >= H(K)-4ln2.                                  (12)

Thus the least net Bell cost of reproducing this clock-joint instrument
is H(K)+O_D(1) in every growing-entropy family, with the fixed-source r
limit taken first. The known compressed partial-breeding implementation
uses H(V)<=H(K)+kappa_D Bell nats per queue. Its excess over the explicit
lower bound in(12) is

    H(V|K)+H(K|V)-H(K|X,V)<=kappa_D+c(1/D).             (13)

The gross hashing theorem, compressed breeding and seed removal are
established preceding methods, credited in the pinned proof. They supply
the matching achievable cost upper bound in this architecture. Classifier
cost(12) may be vacuous or negative at low H; no near-H=0 proportional-loss
law is asserted. At H=0 the ideal instrument can be implemented with no
entangled stock by preserving the known pure prefix and preparing the
separable suffix/independent record locally, which is consistent with(12).

## 4. Scope and the next load-bearing obligation

This excludes logarithmic savings by quantum compression, different query
trees, coherent probes or Bell catalysts that implement the SAME actual
clock-joint stopped instrument with the stated return condition. It bills
net stock and all failure branches. It assumes neither destructive queries
nor a one-way implementation. It makes no fixed-partition assumption.

It does NOT show that every good Bell distiller produces a transcript with
small H(K^r|T), or that it passes through eta_FVQ. A genuinely different
receiver could preserve quantum inventory uncertainty, alter the retained
conditional state, or avoid this classifier. Proving such a receiver's
impossibility, or constructing it with a second-order gain, remains the
actual unrestricted frontier. The principal universal H-O_D(lnH) converse
and H+O_D(1) receiver are unchanged.

The finite stock bill itself uses known separable-overlap testing machinery
and established information/entanglement complementarity; it is not a new
universal primitive. All calculations are mathematical, with finite setting
existence rather than an efficient circuit/decoder claim. Source/record
preparation, stock, local control, classical messages, memory, precision,
reset and all residual correlations remain costs. No physical experiment,
practical advantage, historical novelty or mission completion is claimed.
