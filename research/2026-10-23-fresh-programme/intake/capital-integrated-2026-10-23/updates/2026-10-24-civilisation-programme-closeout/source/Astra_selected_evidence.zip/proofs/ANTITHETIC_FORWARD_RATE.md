# Original unflagged forward rate: posterior coupling and a matched leading term

23 October 2026, W38. Independent reconstruction, with the same arbitrary
self-coupling observation independently reported by W01/root. W44's
underlying all-input erasure proof is reviewed in `FORWARD_IFF_REVIEW.md`.
All rates are natural-log Bell rank per original queue. This note gives
upper/lower BOUNDS; exact finite-source forward capacity remains UNKNOWN.

## 1. Any valid posterior self-coupling gives a finite converse

At an actual record z, let pi_z(k,l) be ANY joint distribution with both
marginals p(k|z). Write S(k) for its prefix-survival sites. For arbitrary
correlated input rho the erasure entropy inequality gives

    f(S(k))+f(S(l)) <= 2 |S(k) intersect S(l)| lnD.

The proof uses no independence between k,l. Consequently the coherent
information of the actual unflagged channel obeys

    Ic(N_z,rho) <= lnD E_pi_z |S(K) intersect S(K')|.

Refine only Alice's maps, keep Bob CPTP, average and compose the output
forward Weyl twirl exactly as in W44's proof. Every finite zero-aid strict
forward receiver with complete error epsilon<1/2 satisfies

    (1-2epsilon)lnN-h2(epsilon)
      <= lnD E_z inf_pi_z E_pi_z sum_a min(K_a,K'_a).       (A1)

Each posterior has finite support, so this infimum is a finite transport
linear programme and is attained. No efficient compilation is asserted.
The independent self-coupling recovers W44's squared-survival bound.

Crucial scope: a different independently optimized antithetic coupling for
each QUEUE need not combine to a self-coupling of the whole CORRELATED
posterior. Thus one cannot replace (A1) by the sum of coordinate Frechet
bounds for arbitrary Z. For example, the posterior uniform on the four
binary words 000,011,101,110 has every tail-survival marginal 1/2, yet no
coupling can make their tail survival sets disjoint almost surely; the
minimum expected tail intersection is 1/2, rather than zero. The independent
source below permits a valid tensor product of coordinate couplings.

## 2. Original iid source and an antithetic upper

Now Z is constant and K_a are iid from the ORIGINAL finite prior p on
1,...,L. Let alpha_j=P(K>=j). For a single queue choose U uniform on (0,1),

    K=F^(-1)(U), K'=F^(-1)(1-U).

Both marginals are p. The event that both exceed j has length
max(0,2alpha_j-1). Hence

    C(p)=E min(K,K')=sum_(j=1)^L (2alpha_j-1)_+.          (A2)

The opposite inequality for every self-coupling follows from the Frechet
intersection bound for each nested tail, so (A2) is also the minimum single
queue overlap. Independently apply this coupling at all queues. Both WHOLE
marginals are then p^tensor r; it is a valid self-coupling of the actual
whole posterior, giving the fixed-source strict-forward upper

    R_forward <= C(p) lnD.                              (A3)

This is a bound on arbitrary correlated input codes and Alice preprocessing,
not a single-letter product-input supposition.

## 3. A zero-aid forward lower within H(K) of that upper

Let m be the last j with alpha_j>1/2. Since alpha_1=1, m>=1. Alice and Bob
locally discard all native positions after m. The remaining source has
inventory J=min(K,m), and is iid across the ORIGINAL queues. Its state theta
is diagonal in the product generalized-Bell basis, with Bob marginal I/D^m.
Entropy of a mixture gives

    S(theta) <= H(J)+2[m-EJ]lnD.

Also, by the chosen cutoff,

    2EJ-m = sum_(j<=m)(2alpha_j-1)=C(p).

Thus the coherent information of this accessible iid source is at least
C(p)lnD-H(J). Unassisted forward hashing gives

    max(0,C(p)lnD-H(min(K,m))) <= R_forward <= C(p)lnD,
    in particular R_forward >= C(p)lnD-H(K).             (A4)

For completeness, (A4) can use the SAME primary finite one-shot lemma as
our Bell-error-ball construction without importing an asymptotic output
claim. At fixed D,L,p, the Bell-label law q of theta has finite support.
With delta_r=r^(-1/4), its iid surprisal-typical set has mass >=1-beta_r,
where beta_r<=Var_q(-lnq)/sqrt(r), and cardinality at most
exp[r(S(theta)+delta_r)]. Every product Bell vector is maximally entangled
in local dimension D^(mr). Restrict theta^tensor r to that positive-support
typical set. Its squared fidelity is >=1-beta_r and support Pi obeys
Tr Pi(I tensor sigma)<=exp[r(S(theta)+delta_r)]/D^(mr).
Buscemi-Datta's UNASSISTED one-way one-shot lemma therefore gives a fixed
Bell rank with rate approaching m lnD-S(theta), with o(r) smoothing/floor
penalty. No supplied Bell stock, backward messages, physical Bell-label
measurement or iid residual approximation is used. All discarded native
tails and code records stay in the OWN actual residual, and the pure-output
lift supplies the original complete-output contract. The constant-state
or nonpositive-rate cases can use a rank-one filler; they do not affect (A4).

## 4. Uniform inventory: exact leading forward/ordinary ratio

For K uniform on 1,...,L the antithetic coupling is simply K'=L+1-K.
Direct summation gives

    C_L = L/4+1/2                    if L is even,
          L/4+1/2+1/(4L)             if L is odd.

For fixed D and fixed-source r FIRST, followed by L->infinity, (A4) yields

    R_forward = (L/4)lnD + O_D(lnL),
    R_forward / B -> 1/2,       B=((L+1)/2)lnD.

Our previously audited ordinary-LOCC receiver satisfies
R_two_way>=B-lnL-4ln2 while the supply cap gives R_two_way<=B.
Consequently R_two_way/B->1 in the SAME order of limits. The rate gap has
leading term (L/4)lnD. There is no added record, entangled stock or acquired
side-information premise in this uniform-source consequence. The finite-L
capacity, original ordinary-LOCC H+O(1) question, algorithmic efficiency,
physical validation and historical novelty are not resolved here.

The receiver remains fully paid: truncation loss, discarded tails, finite
forward twirl/hash communication, same-rank failures, local independent
normal apparatus and all actual residual systems are included. Variable D
is explicit in (A1)-(A4); no simultaneous growing-D,L,r operational limit
is asserted. Primary one-shot source:
https://arxiv.org/html/1006.1896v2 .
