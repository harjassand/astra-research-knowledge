"""Independent exact diagnostics for the root conditional covariance model."""
from pathlib import Path
import hashlib, json, math
import sympy as s
root=Path(__file__).resolve().parent
count=0; cases=0
def check(z):
    global count
    count+=1
    assert z
def equal(A,B):
    for z in A-B: check(z==0)
def lap(d,a,bit):
    n=2*d+2;L=s.zeros(n)
    edges=[(0,j) for j in range(2,d+2)]+[(1,j) for j in range(d+2,n)]
    if bit: edges.append((0,1))
    for i,j in edges:
        L[i,i]+=a;L[j,j]+=a;L[i,j]-=a;L[j,i]-=a
    return L
for d in (1,2,4):
  for a in (s.Rational(1,2),s.Integer(2)):
    r0=1/(128*a);alpha=a/(1+a*r0);n=2*d+2
    b=s.zeros(n,1);b[0]=1;b[1]=-1
    L0,L1=lap(d,a,0),lap(d,a,1)
    for ratio in (1,2,d+1):
      g=128*a*ratio
      G=s.diag(g,g,*([128*a]*(2*d)));I=s.eye(n)
      K=L0+G;KI=K.inv();M0=G-G*KI*G
      K1I=(L1+G).inv();M1=G-G*K1I*G
      u=G*KI*b;c=a/(1+a*(b.T*KI*b)[0])
      equal(M1-M0,c*u*u.T)
      equal((I-G*KI)*G*(I-KI*G)+G*KI*L0*KI*G,M0)
      check(sum(abs(v) for v in u)==2)
      for sig2,nu in ((s.Rational(1,3),s.Rational(2,5)),(s.Integer(2),s.Integer(3))):
        C0=sig2*I+nu*M0;C1=sig2*I+nu*M1
        A=(u.T*C0.inv()*u)[0];rho=nu*c*A
        h=g/(g+d*alpha);ell=alpha/(g+d*alpha);kap=h-ell;t=alpha*h
        formula=s.Rational(2,d+1)*(1/sig2+d*kap**2/(sig2+nu*(d+1)*t))
        check(s.simplify(A-formula)==0)
        bound=s.Rational(2,d+1)*(1/sig2+1/(nu*alpha))
        check(A<=bound)
        check((C0.inv()*C1).trace()-n==rho)
        check(s.cancel(C1.det()/C0.det())==1+rho)
        x=s.Matrix([s.Rational((i%3)-1,3) for i in range(n)])
        dm=(M1-M0)*x
        check((dm.T*C0.inv()*dm)[0]==c*c*A*(u.T*x)[0]**2)
        cases+=1
rows=[]
for d in (16,128,1024,8192):
    a=1.;nu=1.;sig2=.25;alpha=128./129.
    g=128.*(d+1);h=g/(g+d*alpha);ell=alpha/(g+d*alpha)
    kap=h-ell;t=alpha*h
    A=2./(d+1)*(1./sig2+d*kap*kap/(sig2+nu*(d+1)*t))
    c=1./(1.+2./(g+d*alpha));rho=nu*c*A
    covkl=.5*(rho-math.log1p(rho))
    rows.append(dict(d=d,A=A,rho=rho,zero_command_KL=covkl,
                     q_chebyshev_error_point1=math.ceil(80*(1+rho)**2/rho**2)))
proof=root/'THERMAL_COVARIANCE_GRAPH_TRADEOFF.md'
data=dict(status='PASS',exact_assertions=count,circuit_noise_cases=cases,
          scaling_diagnostics=rows,proof_sha256=hashlib.sha256(proof.read_bytes()).hexdigest(),
          evidence='Exact finite algebra plus ordinary floating scaling; not hardware or independent full proof review')
(root/'THERMAL_COVARIANCE_GRAPH_RESULTS.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data,indent=2))
