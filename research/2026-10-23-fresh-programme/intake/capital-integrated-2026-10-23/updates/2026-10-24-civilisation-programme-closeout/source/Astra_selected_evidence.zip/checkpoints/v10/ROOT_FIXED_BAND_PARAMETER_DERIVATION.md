# Removing actual-gain calibration from the source choice on a full beta band

24 October2026 local. Root's parameter/response derivation, independently reconstructed and expanded by W67 in frozen `FIXED_SOURCE_FACTOR_TWO_BETA.md` SHA256 0dcf43ab9d1d385dd8d05592986c4f605568bd46b3abd83afbab9dbb70968977. This is a source-component construction under explicit inherited operator/moment premises; full new finite-code integration is separate. Priority UNKNOWN; no physical gain calibration or apparatus validation is claimed.

The obstruction is informational: forward-only probing cannot change Alice's local marginal as a function of the remote unknown native parameter. A receiver estimate cannot silently become a sender label. A more useful response is to choose ONE source which works throughout the supplied coarse interval. The previous norm-telescope robustness interval was unnecessarily narrow.

Use the inherited actual optimizer H_k, sigma=diag(1/2,1/4,1/4)^tensor k, exact complete-pattern normalization and global all-coherence response. Root read the COMPLETE causal-prefix proof f1b3dadb and V4 source proof b37eccac before deriving this change. Their source family is not replaced by ordinary hopping and their physical bulk-root distinction is retained. The relevant identities are

    D_b(sigma)=0,
    D_b[sigma(Q-k/2)]=(1-b)k I/2,
    D_b(sigma H_k)=(1-b)b F_k(b),
    F_k(b)>=v_k[1-(103/72)bk]I,
    ||D_b(sigma Y_off)||<=L(bk)||Y_off||_(2,sigma),
    L(r)=r exp(2r^2), pin(Y_off)=0.

All are full coherent-prefix operator statements. They do not assert individual spectator positivity. The causal bound is valid beyond the earlier selected bk<=1/5; the norm bound is evaluated at the ACTUAL parameter.

Choose public rational b0<=1/65536, k=floor[1/(10b0)] and t0=v_k b0^2. Construct the normalized clipped source at reference b0 using gamma=4/25 and delta=t0/18, exactly in the historical algebraic form. Then k>=6553, r0=b0 k in[1/12,1/10], nu=v_k/k^2 in[3/25,1/8] and t0 in[1/1200,1/800]. These replace, rather than assume, the old source's lower scale bounds.

The m20 clipping-tail bound scales as39!!(gamma r0)^20, at most the old bound/2^20. Hence its diagonal tail, N weighted2norm and N weighted4norm improve by2^20,2^10,2^5 respectively. The inverse normalization error is therefore e<1e-8, u=||X||2<.006 and e/u<1/800, with tilt eta<=1/7200. The only potentially adverse fourth-moment factor is1/r0<=12 instead of6, overwhelmed by the32-fold N4 improvement. Thus the old conservative weighted Y2 and Y4 bounds continue to hold after direct rederivation, NOT by invoking the original k-choice theorem out of scope. Its global quartic all-eigenvalue entropy estimate gives S2(rho0)>=1.5k+t0/31. Positivity and pin(rho0)=sigma T remain exact.

For actual b in[b0,4b0], put x=b/b0. Since bk<=x/10, concavity gives

    x[1-103x/720]>=min(617/720,77/45)=617/720.

The diagonal tilt stays fixed while the useful response couples to actual b. Therefore

    D_b[sigma(T+X)]
      <=(1-b)t0[1/9-(4/25)(617/720)]I
      =-(1-b)t0(13/500)I.

For the ENTIRE clipped-source offdiagonal correction,

    ||Y_off||2/t0<=(1+1/7200)*1200*1e-8+.006/9
                 =407201/600000000.

Now bk<=2/5 gives L<=10/17, while1-b>=16383/16384. The full actual inward margin is

    (16383/16384)(13/500)-(10/17)(407201/600000000)
      =393203657/15360000000 >1/40.

Half-regularizing with sigma yields one fixed source rho_* for EVERY beta in[beta0,2beta0], with

    S2(rho_*)>=1.5k+1/74400,
    D_b(rho_*)<=-I/96000,
    Tr sigma(M_*-I)^2<=257/32000000<1/100000,
    M_*>=I/2, [rho_*,Q]=0.

All source/table/encoder choices depend on b0, not the actual gain. The reference lower endpoint is still supplied information; a varying unknown gain or unsupplied location is not solved. Physical root and initial normal-state tails remain explicitly counted in the separate code theorem. A common continuum good-program event and regenerated native/receiver/forward costs are necessary before this source lemma becomes an integrated band code. If its final guard retains G/(16k), the prospective excess is at least b_actual/476160; that conclusion remains conditional on the complete new integration.

W67 independently checked the nontrivial clipping/entropy transfer, all exact scalar constants and operator source dependencies, and froze the full proof/certificate. This corroboration is correlated internal research, not external novelty certification or hardware evidence. The previous known-b integration review and narrower-band rows do not automatically endorse these new rows. Mission NOT_ACHIEVED.
