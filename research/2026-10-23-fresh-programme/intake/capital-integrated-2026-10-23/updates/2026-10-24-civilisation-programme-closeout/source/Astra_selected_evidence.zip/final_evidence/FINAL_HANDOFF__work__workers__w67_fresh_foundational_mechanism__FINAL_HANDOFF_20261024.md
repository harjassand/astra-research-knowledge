# W67 final handoff

Current work stops here under the user's worker-drain instruction.
No new branch, worker or review assignment is being opened. Saved
artifacts are local research. Mission NOT_ACHIEVED.

The strongest independently reconstructed current result is a conditional
finite compiler for the exact recurrent quantum device, with one fixed
actual beta in a supplied public interval [beta0,2beta0], a supplied
initializer tail, coherent local finite-gate operations and an installed
quantum-generated classical public program. It has sufficient finite
rate 3/2+beta_actual^2/476160 per ALL initial/body/terminal forward calls,
with formal joint-polynomial onset/cost and enormous constants. The
program is Monte Carlo, not a deterministic certified good seed or an
ordinary classical table constructor. This closes the model-specific
encoder/source-coordinate interface conditionally; it does not establish
practical, hardware, acquisition or priority claims.

The construction combines the original noncommuting clipped source,
charge-resolved short mesoblocks, relative-variance filtered random
frames, source-weighted offline table sampling, fixed pure logical
slices, one common Fourier error-set receiver and paid native operator
access. It retains full actual word/root/colour coherence, both static
sectors and the source's low-depth term. Generic concentration, design,
functional, sign, phase and polar-recovery operations are established
prior. The old Schur multiplicity route's exponential onset is a narrow
route-specific failure, not an all-encoder obstruction. The new compiler
has no inherited small quartic native-gate exponent: full nested source,
functional precision and repeated encoder calls are paid.

The same fixed program has a reviewed complete WORD-vacuum-start
diamond comparison on logical and physical seed JOINTLY, allowing any
reference and seed/message entanglement. Its target is logical identity
times one fixed seed Schur channel with final WORD vacuum. That seed
map may change relative phases, so identity-seed replacement is false.
The native encoder is CPTP close to its all-Good pure ideal isometry.
The comparison does not assert exact reset, iid faults, memoryless
blocks, forgetfulness or an outer-code threshold.

The source/band/native/joint delta is frozen under
`high_design_audit/quadratic_source_frontier/`:

| artifact | SHA256 |
|---|---|
|FIXED_SOURCE_FACTOR_TWO_BETA.md|0dcf43ab9d1d385dd8d05592986c4f605568bd46b3abd83afbab9dbb70968977|
|FIXED_BETA_COMPOUND_INTEGRATION.md|acad93ee122e56ab33fb38f8edc6aaa9e36651eba136ca2479a4e537443f5c1e|
|FIXED_BETA_FORWARD_GUARDS.json|4aaa7c88955c48265e05faa58dafae242546b6dc3e5382ef443d92a18e70a898|
|FIXED_BETA_NATIVE_INPUTS.json|ad641f3df6a3777083e38fdb7758b58343338213d7107c61018f927f27cc7268|
|JOINT_SEED_VACUUM_PRIMITIVE.md|50adce5162f1d470fc625d16dd8e1ecb3e5f3965749d65e54a815ab5e371c941|

W49's fresh full review is
`work/workers/w49_fresh_recurrent_capacity/fixed_beta_joint_audit/FULL_FIXED_BETA_AND_JOINT_PRIMITIVE_AUDIT_V1.md`,
SHA256835ccc6ef4bbe5de5a554dbd16d7ee3d1b5ce0aa4ffa566647a5e0376fdd66a9.
Read in full and current bytes verified. No blocking defect was found at
its explicit contract. Own and critic scalar checks are exact; W49's
small joint/root matrices are floating diagnostics. No huge program,
table, signal phase list or physical code was executed. Source parameter
choice is credited to root; source/access and prior contributions retain
their original scopes. W39's earlier complete known-b reviewa447a4d5,
qualified by initializer736cebd6, remains a separate immutable verdict.

The final NEW paid-program route is only an UNREVIEWED candidate, not
covered by 835ccc6e. It sends a compact table and ideal recipe seeds with
a prefix derived from the exact interaction. One colour followed by r zeros has
seed-independent failure a b^r and success WORD vacuum. Both parties
locally construct all native phase/gate lists, with all work retained.
The same program acts on entangled chunks using a complete ideal-past/
actual-future hybrid, and block error z/(8B) is selected BEFORE computing
its table/seed/program size. No iid/local-stochastic or fresh-normal
assumption is used. Three noncircular selected scalar guards pass, with
candidate total rate 3/2+beta_actual^2/952320 and error<=13z/64.

Its proof is `PAID_COMPACT_PROGRAM_REUSE_CANDIDATE.md`, SHA256
e8889995c6f60d24ba94879ac17da718d32171b0e2786780e69c22a18d180c58.
Raw guards c9bb7298 use B=2^375,2^415,2^458 for beta0=1/256,1/1024,
1/4096. The NUMBER of program bits has 449/497/549 bits, and total
forward-call COUNT has 485/537/593 bits. These are prohibitive formal
counts. Actual-word rational checks cover 8 cases/46 branches; a separate
same-author no-import check covers 114 scalar groups and 5 absorbing-
memory controls. The exact next gate is fresh criticism of compact
description sufficiency, separate native completion binding, the
polylog(B) transmitted cap and complete paid native/storage precision.
There is no new review assignment under the drain instruction.

The sender-side unknown-band acquisition obstacle remains exact under
unassisted forward-only access: remote trace-preserving device maps
cannot change Alice's reduced data. Receiver-only calibrated statistics
do not send a gain label back to Alice. The robust source avoids such
calibration within the supplied interval, not acquisition of its location.
This is frozen in CALIBRATION_INFORMATION_FLOW.md, SHA prefix eb6d888c.

Earlier independently reviewed quartic source/type/receiver/compiler
rows and the CTMC acquisition packet remain immutable at their original
scopes. Basic CTMC acquisition and generic recovery/design operations
were retired as prior/rediscovery when primary sources established that;
none is relabelled an invention. Synthetic CTMC acquisition used actual
charged read/discard counts, not a physical sensor. Strongest unrestricted
source/device/capacity converse, historical novelty, ordinary performance
advantage, real calibrated local operations and physical validation remain
open or unestablished. The manifest is transport evidence only.

For continuation use CONTINUATION_20261024.json and the manifest;
resume only on a later explicit user request. No research work continues
automatically after this checkpoint.
