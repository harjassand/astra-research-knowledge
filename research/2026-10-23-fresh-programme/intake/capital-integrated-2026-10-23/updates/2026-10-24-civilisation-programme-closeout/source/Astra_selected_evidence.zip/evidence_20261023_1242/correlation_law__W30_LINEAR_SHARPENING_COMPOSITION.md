# Credited linear-pump sharpening and its optical/acquisition consequences

w42, 23 October 2026. W30's independently derived finite-chain audit is
retained at `reviews/W30_LINEAR_CONCENTRATION_PROOF_AS_RECEIVED.md`,
SHA06454d78c331f93831f573389ecd79ac6ea941e63e05a42abf38ed20f58b468f.
I read it AFTER freezing my source-bound root concentration and Poisson
audits5c5b3e07 andb68e8e69, then independently reconstructed the new
inequalities below. No blocker was found. This note credits the exact
new source, keeps all prior bytes unchanged, and derives its receiver
composition; it does not attribute that composition to W30's narrower
concentration-only receipt. No exact priority or physical claim follows.

## 1. Check of the sharpened finite-operator proof

Use S=N+m,s=S/N,lambda=L/N>=4s, Y=ell/N and root's X,p,y,x.
On0<=tau<=1, r'<=1 gives y<=s sinh^2 tau<2s<=lambda/2.
Here p(y)-2s=y[4-(4s+6y)/lambda]>=0, so y''>=2s and
y(1)>=s. This strengthens root's valid3s/4 bound.

With the INITIAL state fixed, put u=(Y-y)psi,v=(X-x)psi and

    B=4(1-s/lambda)I-6(Y+yI)/lambda,
    h=2Ypsi/(lambda N).

The exact equations are u'=v,v'=Bu+h, with ||h||<=2/N.
At a=s/lambda<=1/4, Y spectrum[0,lambda], y<=2s implies
spec(I+B) subset[-1-16a,5] subset[-5,5]. Thus combine BEFORE bounding:

    E'=2Re<v,(I+B)u+h>
        <=10||u||||v||+4||v||/N<=6E+4/N^2.

This uses no noncommuting-product factorization. E(0)=s/N as before,
so E(tau)<=e^(6tau)[s/N+4tau/N^2]. With any fixed0<eta<1,

    Pr[ell<(1-eta)S]
      <=e^6/eta^2[1/(sN)+4/(s^2N^2)]
      <=e^6/eta^2[1/N+4/N^2].                          (WS1)

Real thresholds mean exactly ell>=ceil((1-eta)S) on the good event.
The SAME Fock inventory L=4(N+M) and physical time1/(chi sqrt L)
meet this hypothesis for every m<=M, without knowing that m.

## 2. The exact fixed-rank source-uniform receiver

Put c=1-eta and choose any fixed0<r<ln(1+c). The V_(m,ell) sector
isometry remains exact. Its flat reference and cyclic/Uhlmann decoder
give q_code<=sqrt[J_N d_m/d_(m+ell)]. On ell>=c(N+m),

    d_(m+ell)/d_m>= (1+c)^(N-1),
    q_code<=sqrt(1+c)exp[-N(ln(1+c)-r)/2].

The passive averaged initial Bell-failure effect is block scalar in m.
Keeping ALL defaults and finite count readouts0<=D<=L,0<=C<=M+L
gives uniformly over arbitrary capped A states and actual purifiers

    q_N<=min{1,e^6/eta^2(1/N+4/N^2)
                 +sqrt(2-eta)exp[-N(ln(2-eta)-r)/2]},  (WS2)
    d(Omega,Phi_(J_N) tensor Omega_actual,residual)
                                             <=min{1,2sqrt(q_N)}.

Since eta can be any fixed positive number, this proves every fixed
Bell rate below ln2 nats per pair with a linear Fock-pump inventory.
The optical source need not be iid and the pump/source purifiers stay
in the actual residual. No undepleted amplifier is approximated.

An optional explicit endpoint sequence is also possible: take
eta_N=N^(-1/4) and r_N=ln(2-eta_N)-N^(-1/4) for large N, using defaults
on the finite initial segment where these parameters are inadmissible.
Then WS1 is O(N^(-1/2)), the code term is O(exp(-N^(3/4)/2)), and
ln J_N/N tends to ln2. This is an ACHIEVED LOWER RATE, not a proof of
an exact minimax or capacity optimum. Its finite-N constants remain
very conservative and large sector-code acquisition remains unproved.

## 3. Correct use on root's Poisson pump and correlated source family

For root's Poisson source70926421, a good initial L in[4J_0,8J_0],
J_0=N+M, has tau_L in[1,sqrt2]. W30's E6 bound was proved only while
sinh^2 tau<=2; it must NOT be silently extended through sqrt2.
However root's original E12 comparison is valid through sqrt2 by the
turning-time proof in the separate Poisson audit. Monotonicity gives
y(tau_L)>=y(1)>=s, so the NEW threshold c=1-eta is still justified:

    Pr[ell<cS | good L]
      <=e^(12sqrt2)/eta^2[1/N+4sqrt2/N^2].              (WS3)

Add the bad-initial-L probability2exp(-2J_0/7) and the same WS2 code
term. Thus every fixed r<ln2, and the explicit endpoint sequence above,
also follows with one Poisson pump of linear mean energy and linear
max-Gibbs price. The initial-number-diagonal Bell effect, pure-coherent
extension, arbitrary joint source-pump correlations at fixed Poisson
number diagonal, and active APB resource bound are as proved separately
in frozen `ROOT_POISSON_PUMP_INDEPENDENT_AUDIT.md`b68e8e69. No extra
independence, dephasing oracle or new postselection is inserted here.

## 4. Coarse thermal-band acquisition as a separate option

The generic lemma `THERMAL_BAND_PUMP_ACQUISITION.md` tests independent
thermal candidates of mean K for K<=N_P<=2K. Each succeeds with
probability at least1/6; T tests have all-failure at mostexp(-T/6).
It was originally instantiated with superquadratic K through my
Duhamel proof and did not assume a future direct concentration theorem.

Now take K=4(N+M), the SAME fixed t=1/(chi sqrt K), and use WS3 uniformly
for every selected number k in[K,2K]. Its complete unconditional Bell
error is bounded by WS3 plus the fixed code term plus exp(-T/6).
For T=ceil(6a ln N),a>0, it vanishes without exact Fock preparation,
exact pump-number readout or per-number time feedback.

The full supplied hot-pump inventory and ordinary Gibbs resource are
O(N ln N), and pure test-pointer resource is O(ln N). Expected constant
tests do not make that supplied worst-case inventory linear. Hot thermal
tails retain infinite exact max-Gibbs resource relative to a colder
reference; the active selected bounded-band state has finite O(N)
max-resource but failed raw pumps cannot be subtracted for free.
Independent candidate replenishment remains a supplied joint contract:
perfectly correlated equal thermal marginals give constant all-failure
probability. The single Poisson-pump option is a stronger supplied
initial-resource alternative and needs none of these candidate tests.

## 5. Stronger same-pump vacuum and status

Under each matched Fock, Poisson or thermal-band model, both-input
vacuum gives exactly Phi_(d_ell) conditional on ell. WS1/WS3 gives every
fixed rate below g(c),c<1, hence every rate below g(1)=2ln2 by choosing
c near one. The same explicit slowly varying c_N and Stirling bound
can approach2ln2; exact maximally-entangled rank conversion retains every
branch and has no divisibility remainder. This is stronger than the
universal unknown-input lower rate ln2, and supplies no yield advantage.

The source cap, fresh B vacuum, shared mode with coherent equal
couplings, trusted pump number law or band replenishment, lossless
common time control, retained old source, full output storage, non-Gaussian
number instruments, huge general sector codes, pure ancillas, precision,
program/reset costs and external priority remain explicit premises.
Root's core, W30's sharpening, my receiver composition and later
acquisition interfaces are kept separate in the evidence ledger. No
physical operation, efficient large decoder, source-information recovery,
net total-resource superiority or mission completion is established.
