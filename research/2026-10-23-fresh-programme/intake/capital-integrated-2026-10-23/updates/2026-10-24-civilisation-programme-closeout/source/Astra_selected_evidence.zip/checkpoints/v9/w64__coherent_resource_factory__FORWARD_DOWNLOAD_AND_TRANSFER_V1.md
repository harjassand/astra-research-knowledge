# Forward-only native download, decoded locally at Bob

23 October 2026. Candidate full proof, after the stronger Burgarth--Giovannetti opposite-download uploader was reconstructed. Generic local relaxation/upload/download control is PRIOR; this is an explicit native finite-depth complete-channel application. Fresh independent receipt and new diagnostics PENDING at this freeze. No capacity, apparatus, priority or mission overclaim.

## D1. Explicit source and register promises

Use the unchanged full infinite native V=alpha U+i beta I and a fixed known 0<=beta<1. The bath input is an ARBITRARY UNKNOWN state in a KNOWN conserved seed-X sector x, supported on words of length<=H. It can be entangled with arbitrary external reference/laboratory R. Unlike upload, download does not start the bath at root. The unknown information is already in E and is to be moved into a local register at Bob.

Alice supplies T fresh vacuum qutrits P_1,...,P_T. Bob has a locally controllable encoded word register F_B of dimension d_H=2^(H+1)-1, initialized in its known empty-word basis state r_x. This local register's root sign x is a circuit parameter, not a new physical bath. Bob can apply the same succinct local stack simulator U_H and V_H described in frozen c544c1a9... . All these local storage, circuits and precision are counted; no dense d_H oracle is assumed.

The target isometry is

    S_D: |psi>_E -> |r_x>_E |0^T>_P |psi>_(F_B).  (D1)

This transfers every cross-depth coherence and all reference entanglement, while resetting the old input bath to the known root. It does not leave that bath's original unknown state in place. It cannot transfer an unresolved coherent superposition of conserved seed-X sectors; known x is essential to this exact scope.

## D2. The complete legal circuit

Send P_1,...,P_T forward in ascending order, each initially vacuum, and use actual native V ONCE on each. Bob stores the output qutrits coherently. The physical operator is

    W_+E=V_(P_T E)...V_(P_1 E).

Append the initialized local F_B and apply, ONLY IN BOB'S LABORATORY,

    W_+F*=V_H*_(P_1 F)...V_H*_(P_T F).

This local decoding acts on port order T,T-1,...,1. Each V_H* is the explicitly compiled local signed-stack circuit with conjugated eigenphases. The physical device never implements an inverse. Each physical port is used once and never sent backward. No backward quantum communication, no backward classical feedback, and no bath measurement are needed in this download circuit.

Bob's local finite boundary completion does not change the forward-simulation identity on depth<=H. A concise basis implementation requires O(H) encoded word storage, O(T) stored qutrits and T local stack steps with the earlier explicit polynomial gate count. Parameter calibration, fault tolerance and phase synthesis are additional resources.

## D3. Uniform channel proof

Let D_+X=W_+X(|0^T>_P tensor ._X) be the coherent vacuum download, physical on E and locally simulated on F. These agree exactly on the depth promise. Define A_+=(<r_x| tensor I_P)D_+. The physical vacuum channel has root phase alpha x+i beta, pop probability a=1-beta^2 and positive-depth survival beta^2. Therefore

    A_+*A_+>= (1-tau)I,
    tau=Pr[Bin(T,a)<H].                            (D2)

Let J_D denote the complete physical-download/local-decoder isometry above. Move the local decoder across a target bra in (D1). Its local FORWARD simulated vacuum download and the actual physical download share precisely the same root components, including the root phase. Thus

    S_D* J_D=A_+*A_+,
    ||J_D-S_D||<=sqrt(2tau),
    ||channel(J_D)-channel(S_D)||_diamond
       <=2sqrt(2tau).                              (D3)

All bounds are on the entire finite-depth input operator space and so hold for arbitrary reference dimension. They do not rest on a basis-average fidelity, a chosen known state, postselection or a nonlinear successful normalization. Both isometries include the FINAL bath, all Bob ports and Bob's decoded word register; discarding ports can only reduce error.

An O_beta[H+ln(1/epsilon)+1] choice of T makes (D3) at most epsilon, before local/parameter/noise errors. Additional local decoder operator error e_B adds at most 2e_B in UNHALVED diamond norm. A rounded local parameter with native-operator error kappa adds at most 2T kappa. Hardware error per actual forward call accumulates T times. No finite-cost unknown normal tail bound is inferred from a depth promise; general normal inputs require a separately controlled depth-tail truncation.

## D4. Forward-only fresh-message transfer with a known-root return

Compose the controlling opposite-download UPLOAD in STRONG_INCUMBENT_OPPOSITE_DOWNLOAD.md with this DOWNLOAD. Initially Alice holds an arbitrary unknown F_A word-register state of depth<=H, possibly entangled with a fresh source R; physical E starts in r_x independently, and Bob holds empty F_B. Neither laboratory needs preshared entanglement.

First Alice locally simulates the OPPOSITE vacuum download using V_H*, then sends its prepared ports T down to1 through actual forward V. This approximately moves F_A into E and resets F_A/its ports. Next Alice sends T fresh vacuum ports in ascending order, and Bob locally decodes them with the PRESENT V_H* decoder. This moves E into F_B and resets E/these ports. Each of the 2T ports is sent exactly once. The desired full output is

    |r_x>_(F_A) |0^T>_(P_upload) |r_x>_E
       |0^T>_(P_download) |psi>_(F_B).              (D4)

No timing carrier, backward feedback, quantum return or physical inverse is used. The source is independent of the original bath/labs resource and all errors are retained. Isometric telescoping gives operator error at most 2sqrt(2tau), hence UNHALVED diamond error at most 4sqrt(2tau). Local upload/decoder compilation, learned-parameter error, native hardware error and a JOINT initial-root product error add by contractivity as already stated. The full final bath is approximately its ORIGINAL KNOWN PURE ROOT, including decoupling from the transferred fresh source. This is not an arbitrary old correlated-resource return theorem.

The count 2T is deterministic and needs no dummy padding. A sharper binomial tail allows T=H/a+o(H) at slowly vanishing error, so the elementary word-register communication rate approaches a/2 qubits per native call. It is an ordinary constructive baseline and is weaker than the inherited beta0 Dyck rate3/2. No new capacity advantage is claimed. Its useful scope is a fully explicit resource read/write/reset interface and complete cross-depth unknown-state transfer.

## D5. Provenance and remaining boundary

The generic upload/download relaxation principle and the opposite-evolution uploader are Burgarth/Giovannetti2007 PRIOR. This proof should not be presented as a new general quantum memory-control principle. The device-specific depth-binomial complete-channel estimate and succinct simulator are established here as a candidate application; special-case priority UNKNOWN. A strict corpus/primary comparison and fresh full critique still control any scientific promotion.

The known-sector/root/circuit promises must remain visible in every composition. Fixed normal initializer reset, seed acquisition, arbitrary N-dependent initial resources, external seed-purifier return and unknown-beta acquisition are distinct scopes. No earlier proof/audit of any of those interfaces is silently substituted for this theorem. Programme mission NOT_ACHIEVED.
