# Fresh reconstruction of the finite-Fock quantum heat extension

23 October 2026. W17. Sources and other workers' files left unchanged.

Exact reviewed targets:

- W38 `HEATED_FINITE_FOCK_QUANTUM_CUBIC_CANDIDATE.md`, SHA256 `c6ad8e31bb6c79743812b4052ac4dd2a595148af5fcec4defc0bd145fccfcdf0`.
- The distinct all-orders extension `HEATED_FINITE_FOCK_QUANTUM_GENERAL.md`, SHA256 `f17fbcf5953de8264c93b80e1311a9b1a802cb94e6c08da4fc0015891c35d7b9`.

Dependencies independently reconstructed here or in hash-bound earlier receipts: `QUANTUM_LOCAL_BRIDGE.md` `6cfc1f798de575f4ce794d47b00c2df2f14eee6941fb2d8586d17f9fc68acd3a`; `HEAT_BRIDGE_OBSTRUCTION.md` `e99fcbae45002ffe9d8afcaff7c2052c0b292ca1a5d86b6a76f123b47a664099`; and `GLOBAL_QUANTUM_THIRD_MOMENT.md` `c0d55deb9106545533aca7acb2c82125402bdbf41cfb130a4f1e389066687cc3`. Source snapshots are retained. The earlier local review is `quantum_local_epni_audit/RECONSTRUCTION.md` `057bc9fc646302c4e1d8feca035a036ebca37faa58bce050cb96758c74a49736`; the signed-M3 review is `quantum_third_moment_audit/REVIEW.md` `3fbb5c77634331b68ea2765ba1bf6d1ea39e067143d0f12d20a848aa31f0719c`.

Verdict: no blocking mathematical defect found in either exact target under its stated hypotheses. This is a fresh internal proof reconstruction, not external validation, novelty certification, a uniform-noise theorem, or an unheated amplifier EPnI. The all-orders review is separate from the cubic review; it is not inferred merely from cubic examples.

## 1. Exact theorem being reviewed

Fix finite positive integer \(n\), gain \(G>1\), \(H=G-1\), and two independent positive states \(\rho_{A0},\rho_{B0}\), each with finite joint support in the native Fock basis. Within each group arbitrary coherences and entanglement are admitted. The first and anomalous second moments vanish, and

\[
\operatorname{Tr}\rho_{A0}a_j^\dagger a_k=a\delta_{jk},\quad
\operatorname{Tr}\rho_{B0}b_j^\dagger b_k=b\delta_{jk},\qquad a,b>0.
\]

Let \(\mathcal H_T\) be independent isotropic additive Gaussian noise adding \(T\) photons per mode. The actual inputs are \(\rho_A(T)=\mathcal H_T^{\otimes n}(\rho_{A0})\) and \(\rho_B(T)\), and the retained amplifier modes are \(c_j=\sqrt G a_j+\sqrt H b_j^\dagger\). For all sufficiently large finite \(T\), depending on the fixed sources, \(n\) and gain,

\[
S(C_T)\ge n g\!\left(Gg^{-1}(S(A_T)/n)+H[g^{-1}(S(B_T)/n)+1]\right)+c_0T^{-m}
\]

for some fixed \(c_0>0\). Here \(m\ge3\) is the smaller first unmatched Gaussian moment degree of the two original sources. The cubic candidate assumes a nonzero cubic moment and gives \(m=3\). The separate general candidate removes that assumption by proving cancellation at every finite first unmatched degree. All entropies use nats.

Both source states, \(n\) and \(G\) are fixed before \(T\to\infty\). The conclusion changes both inputs. There is no inverse heat map, no passage to \(T=0\), no uniform threshold over all finite-energy sources, and no arbitrary unequal covariance theorem.

## 2. Exact heat matrix units

Write \(l=k+d\), \(d\ge0\), \(\eta=1/(1+t)\), and amplifier power gain \(g=1+t\). The loss map removing \(j\) photons has matrix-unit amplitude

\[
\sqrt{\binom kj\binom lj}(1-\eta)^j\eta^{(k+l)/2-j}.
\]

The subsequent amplifier adds \(m-k+j\ge0\) photons, with amplitude

\[
\sqrt{\binom m{k-j}\binom{m+d}{l-j}}
(g-1)^{m-k+j}g^{-m-d/2-1}.
\]

Their product is exactly the summand of V4, with power \(t^{m-k+2j}/(1+t)^{m+l+1}\). The characteristic action of this composition is unit signal gain and noise \(e^{-t|z|^2}\), so it is precisely the stipulated heat channel. These Kraus ingredients and the noisy-channel composition are established prior work, not a new dilation; see the separate primary note.

After \(v=k-j\), the four binomial square roots simplify to

\[
\frac{\sqrt{k!l!}\sqrt{(m+d)!/m!}(m)_v}
{(k-v)!v!(d+v)!}.
\]

Divide by \(\sqrt{\tau_{t+x}(m)\tau_{t+x}(m+d)}\), and set

\[
R=\frac{t(t+x+1)}{(t+1)(t+x)}\le1,\quad q=\frac{t+x}{t+x+1}.
\]

The remaining scalar factor is exactly V5. This derivation includes \(m<k\): the falling factorial removes the forbidden terms. No reflecting boundary or finite output space enters.

## 3. All-orders cancellation, including mixed vector charges

Put \(\epsilon=1/t\), \(u=m/t\). Pull out the common band factor

\[
R^m q^{-d/2}\epsilon^{d/2}\sqrt{\prod_{s=1}^d(u+s\epsilon)}.
\]

The remaining finite sum is \(\sum_k\sigma_{k,k+d}B_{k,d}(\epsilon,u)\), with \(B\) exactly as W3. The square root is never Taylor-expanded at \(u=0\).

For a coefficient of \(\epsilon^r\), only \(v\le r\) can contribute. The factor \(\binom kv\) has degree \(v\) in \(k\). If the falling product supplies a further power \(\epsilon^j\), the denominator expansion contributes degree at most \(r-v-j\). Thus the total \(k\)-degree is at most \(r-j\le r\); the extra linear numerator does not increase this bound. A truncated \(k\)-sum causes no exception: \(\binom kv=0\) for nonnegative integers \(k<v\).

Every degree-\(r\) polynomial in \(k\) is a linear combination of \((k)_s\), \(s\le r\), and the exact identity is

\[
\sum_k\sigma_{k,k+d}\frac{\sqrt{(k+d)!/k!}}{d!}(k)_s
=\frac1{d!}\operatorname{Tr}\sigma(a^\dagger)^{s+d}a^s.
\]

The orientation here was checked from the trace, not assumed from a Hermitian label. These observables have degree \(d+2s\). Hence matching every Gaussian moment below degree \(M\) removes every coefficient satisfying \(d+2r<M\) on a nonzero-charge band. The first remaining integer order, multiplied by the common \(\epsilon^{d/2}\), is at least \(\epsilon^{M/2}\). When \(d\ge M\), direct power counting suffices.

For finite \(n\), coefficients are products of the one-coordinate coefficients. A total order \(r\) has total lower-index polynomial degree at most \(r\), so its normal-ordered moments have degree at most \(|D|_1+2r\). In a negative coordinate, take the adjoint matrix unit and use its smaller native occupation as the base index. This exchanges creation and annihilation in precisely that coordinate. In mixed signs, it gives the corresponding mixed normal moment, including \(a_j^\dagger a_k\) at degree two. The fixed base-index shifts change only a polynomial majorant. Full matching of all low-degree moments is essential; scalar total-energy matching alone would not remove these bands.

## 4. The diagonal comparison and uniform far tails

For \(D=0\), zero-charge coefficients are not zero; they must match the thermal comparison. Independently summing W3 over the geometric law gives this exact identity. With

\[
z=\frac{x}{(x+1)(1+\epsilon)},\qquad
y=\frac{x\epsilon^2}{1+(x+1)\epsilon},
\]

the identity \(\sum_{k\ge v}z^k\binom kv=z^v/(1-z)^{v+1}\) leaves \(\sum_v\binom mv y^v=(1+y)^m\); its other prefactor is one. Since \(R=(1+y)^{-1}\), this is exactly W5. For every fixed coefficient only finitely many \(v\)'s enter, and its \(k\)-dependence is polynomial. Geometric thermal moments therefore justify coefficient extraction without a uniform power-series expansion in arbitrarily large occupation.

Multiplication by \(R^m\) cancels every diagonal coefficient below \(\lceil M/2\rceil\). For a uniform remainder at all physical \(m\), write \(m=u/\epsilon\) and

\[
R^m=\exp[u f(\epsilon)],\qquad f(\epsilon)=\frac{\log R(\epsilon)}\epsilon.
\]

The apparent singularity of \(f\) at zero is removable; \(f(0)=0\), and \(f\le0\) for positive \(\epsilon\). Every fixed derivative is bounded on a sufficiently short fixed positive interval. Derivatives of the exponential are the same nonincreasing exponential times a fixed polynomial in \(u\), so they are uniformly bounded by a polynomial for every \(u\ge0\). The finite source sum has the same property. Taylor's finite integral remainder now gives the claimed bound uniformly over *all* occupations, not merely \(m/t\) in a compact set.

Consequently, for finitely many bands and fixed source-dependent \(C,P\),

\[
|(F_t)_{\mathbf m,\mathbf m+D}|
\le Ct^{-M/2}(1+|\mathbf m|_1/t)^P.
\]

This polynomial majorant can be large in a remote tail. It does not assert operator-norm convergence of \(F_t\) to zero and is compatible with the exact heated-one-photon lower likelihood defect one.

## 5. Normal second, fourth and cubic moments

For a scaled geometric occupation of mean \(t+x\), choose \(\theta=1/[2(x+2)]\). For \(t\ge1\),

\[
\log(1+1/(t+x))\ge\frac1{t+x+1}\ge\frac{2\theta}{t}.
\]

Thus \(q\exp(\theta/t)\le\exp(-\theta/t)\), and the exponential moment of \(N/t\) is uniformly bounded. A fixed finite product gives a uniform exponential moment of \(|\mathbf m|_1/t\), so all needed polynomial moments are bounded.

For \(\operatorname{Tr}\tau F_t^2\), sum the squared finite-band entries. For \(F_t^4\), expand each diagonal entry over the finite set of four-step closed band paths. Intermediate indices differ by bounded fixed shifts, so each product is bounded absolutely by \(Ct^{-2M}\) times a polynomial in \(1+|\mathbf m|_1/t\). Invalid negative-number paths are omitted. Absolute convergence then permits the sums and yields

\[
P_2(t)=\operatorname{Tr}\tau F_t^2=O(t^{-M}),\quad
P_4(t)=\operatorname{Tr}\tau F_t^4=O(t^{-2M}).
\]

The state \(\tau\) need not commute with \(F_t\). Its scalar spectral measure \(\mu(E)=\operatorname{Tr}\tau E_{F_t}(E)\) is positive, and ordinary scalar Cauchy-Schwarz gives \(\operatorname{Tr}\tau|F_t|^3\le\sqrt{P_2P_4}=O(t^{-3M/2})\). No noncommutative \(L^3\) triangle, multiplicative BKM rule or cubic-moment DPI is used.

Finite support also supplies \(-M\tau_x\le\sigma\le M\tau_x\), even for the signed finite operator. CP heat propagates these bounds to \(\tau_{t+x}\), so all the relative operators used in these moment sums are bounded. Positivity is required later only for the actual states.

## 6. First moment order and the matching lower BKM scale

The relative characteristic \(e^{x|z|^2}P(z,\bar z)-1\) is analytic and cannot vanish identically for a finite polynomial \(P\) at \(x>0\). Its first nonzero Taylor degree \(M\) is finite, and covariance matching makes \(M\ge3\). Multiplication by a Gaussian with value one at zero preserves the first unmatched degree. Ordering corrections lower total degree, so Weyl and normal moment matching are equivalent at this first unmatched order.

Choose a Hermitian degree-\(M\) polynomial \(O\) with fixed nonzero discrepancy \(\mu=\operatorname{Tr}(\rho_0-\tau_x)O\). Heat adds only lower-degree terms in its adjoint action, and those discrepancies vanish. Therefore \(\operatorname{Tr}(\rho_t-\tau_{t+x})O=\mu\) for every \(t\). BKM dual Cauchy-Schwarz gives

\[
Q_t\ge\frac{|\mu|^2}{\operatorname{Tr}[O_0\Omega_{\tau_{t+x}}(O_0)]}
\ge\frac{|\mu|^2}{\operatorname{Tr}\tau_{t+x}O_0^2}
\ge c t^{-M},
\]

where \(O_0=O-\operatorname{Tr}\tau_{t+x}O\). The middle step is logarithmic mean at most arithmetic mean; thermal degree-\(2M\) moments are \(O(t^M)\).

Unbounded polynomial observables cause no missing domain assumption. Number-compressed \(O\)'s converge in thermal quadratic mean. Bounded relative densities and thermal Cauchy-Schwarz identify their pairings with the actual moments; the BKM dual bound is no larger than that quadratic mean. Passing the cutoffs proves the displayed inequality. The upper bound \(Q_t\le P_2(t)\) follows from logarithmic mean at least harmonic mean, already justified in the signed-M3 review. Hence \(Q_t=\Theta(t^{-M})\).

For the two groups, \(W=\eta_AQ_A+\eta_BQ_B=\Theta(T^{-m})\), because \(\eta_A\to G/(2G-1)\), \(\eta_B\to H/(2G-1)\) are positive. No finite lower bound uniform over all source discrepancies is asserted.

## 7. The signed output is analytic bookkeeping

Finite-support characteristic polynomials form a triangular basis: a matrix unit with charge \(d\) has a monomial of degree \(d\) times an associated Laguerre polynomial, whose nonzero leading term gives triangular invertibility. Products across modes give the full multivariate polynomial basis. Thus the amplifier polynomial \(P_C\) has a unique finite-support Hermitian trace-one representative \(\sigma_C\). Characteristic conjugation symmetry gives Hermiticity and value at zero gives trace one.

The physical output at zero added heat is exactly \(\mathcal H_H(\sigma_C)\). Its signed representative has occupation \(x_C=Ga+Hb>0\); heating both original groups gives actual output

\[
\rho_C(T)=\mathcal H_{(2G-1)T+H}^{\otimes n}(\sigma_C),\quad
c_T=G(a+T)+H(b+T+1).
\]

The relative characteristic of \(\sigma_C\) is the product of the two relative input characteristics after the amplifier's linear substitutions. Hence it matches the Gaussian through every degree below \(m\), even if its degree-\(m\) discrepancy cancels. The upper moment estimates apply with order \(m\), which is all the proof needs. Positivity of \(\rho_C(T)\) comes from the actual channel on independent positive input states; no signed state is prepared or postselected.

An explicit check makes the distinction concrete. At \(G=2\), \(A=(|0\rangle+|3\rangle)/\sqrt2\), \(B=|1\rangle\), one finds

\[
\operatorname{diag}\sigma_C=(3,-18,42,-42,16),\quad
(\sigma_C)_{03}=-3\sqrt2,\quad(\sigma_C)_{14}=2\sqrt2.
\]

Its trace is one, occupation four, and its characteristic polynomial is exactly that of the actual output with the one-photon noise factor removed. It is strongly nonpositive. This example checks the analytic use rather than pretending that \(\sigma_C\) is a physical input.

## 8. Quantum interaction and the nonvanishing high-temperature gap

The already reviewed complete Wick/BKM decomposition applies homogeneously to every moment-orthogonal deviation with finite BKM norm. A common rescaling, if needed, places bounded relative deviations inside the earlier tangent convention; the homogeneous inequality then rescales back.

All degrees zero, one and two have been removed. In the equal aggregate-degree sector \(p=q=k\), the first surviving \(k\) is two. Therefore the valid sharpened gap is

\[
\delta_{D2}=1-r_A^4/\eta_A-r_B^4/\eta_B>\delta_D>0.
\]

As \(T\to\infty\), independently of fixed unequal offsets \(a,b\),

\[
\delta_{D2}\to\frac{3GH}{(2G-1)^2},\quad
\delta_M,\delta_P\to\frac{2GH}{(2G-1)^2}.
\]

Thus one fixed positive \(\delta_0\) bounds the simultaneous linear contraction gap at every sufficiently large \(T\). This uses the exclusion of every quadratic direction, not just total number.

For the bilinear cross term \(Z=\Gamma_G(X_T,Y_T)\), metric DPI and the harmonic-mean bound give

\[
Q_C(Z)\le Q_{\tau_A\otimes\tau_B}(X_T\otimes Y_T)
\le\operatorname{Tr}X_T^2\tau_A^{-1}\,
\operatorname{Tr}Y_T^2\tau_B^{-1}
=P_A P_B=O(T^{-M_A-M_B}).
\]

The inverse-weight expressions here are defined by their finite weighted Hilbert-Schmidt forms and equal \(\operatorname{Tr}\tau F^2\). This is a product rule for the larger Petz form, not for BKM. The triangle inequality then yields

\[
Q_C(\text{actual deviation})\le(1-\delta_0)W+O(T^{-3m/2}).
\]

Independence of the full A/B groups is essential to this expansion. Internal entanglement within either finite group is harmless to the algebra.

## 9. Entropy, curvature, and eventual sign

Each finite positive source obeys \(\rho_{i0}\le M_i\tau_{x_i}\) with finite fixed \(M_i\). Heat and amplifier CP positivity yield uniform relative bounds for all three actual states, with output constant \(M_AM_B\). In particular \(F\ge-I\), so the independently reviewed signed-M3 bound applies. The normal moment estimates give

\[
D_i=Q_i/2+O(T^{-3M_i/2}),\quad
D_C=Q_C/2+O(T^{-3m/2}),
\]

and therefore

\[
\eta_AD_A+\eta_BD_B-D_C
\ge\tfrac12\delta_0W-O(T^{-3m/2}).
\]

All energies exactly match their thermal references and remain finite, so \(S_i=ng(x_i+T)-D_i\) and the output analogue are exact. There is no entropy continuity claim on an unbounded-energy ball.

For the scalar target \(F_G(s,t)\), the first derivatives are \(\eta_A,\eta_B\). Its Hessian is uniformly bounded on the needed high-temperature rectangle. One direct check is \(\eta_A,\eta_B\le1\), \(1/(x+1/2)\le h(x)\), and \((x+1/2)^2/[x(x+1)]\le9/8\) for \(x\ge1\). The two absolute terms in a pure second derivative are each at most \(9/8\), giving the stated \(9/4\); the mixed derivative is at most \(9/32\) by \(uv/(u+v)^2\le1/4\). At sufficiently large \(T\), the entire half-entropy rectangle has its corresponding means at least one. Also \(D_i=O(T^{-m})\ll ng(x_i+T)\), so the actual entropies lie in that rectangle.

Taylor's error is consequently \(O((D_A+D_B)^2/n)=O(T^{-2m})\). Since \(m\ge3\) and \(W\ge cT^{-m}\), both error orders are smaller than \(W\). Increasing a source-dependent threshold leaves a positive lower bound \(c_0T^{-m}\) for every subsequent finite \(T\). The same estimates give an \(O(T^{-m})\) upper bound on the gap, so “order” can be read as a source-dependent \(\Theta(T^{-m})\) statement.

## 10. Independent exact diagnostics

`check_heat_allorders.py` imports no producer code or data. It independently composes loss and amplifier amplitudes and compares the relative V5 form in 48 high-precision matrix-unit cases, including forbidden lower occupation terms. There are 35 exact symbolic coefficient-degree checks, seven exact diagonal thermal cancellation coefficients, and ten mixed-vector-charge cancellation checks. These finite checks supplement the all-orders proof; they do not replace it.

Six explicit positive finite sources have first unmatched degrees 4,6,8,10 and coherent degrees 5,7. The latter use \(\rho_{k,k+1}=\kappa(-1)^k\binom sk/\sqrt{k+1}\), whose first \(s\) weighted moments vanish. Exact strict diagonal dominance certifies positivity. Their cubic moments vanish, so they test genuinely beyond the cubic assumption.

For 36 cases through \(T=10^6\), the script sums the relative second and fourth moments over *every* number level by rational geometric-power identities. Closed paths pair their square-root edge factors to polynomials, and \(\sum_{m\ge0}m^jz^m\) is summed exactly using Stirling numbers. The final rational values are recorded to 55 decimal digits with fingerprints of the exact numerator/denominator. There is no photon cutoff or finite-state replacement in these normal-moment tests.

The finite examples pass. Small leading coherent discrepancies can leave the next diagonal degree dominant until very large noise; the finite values do not certify a source-uniform asymptotic regime. The script also checks the explicit signed output polynomial, trace and energy above. Final run: 1.0017 seconds, peak macOS RSS 61,652,992 bytes. Runtime excludes discovery, proof reconstruction and literature review. No actual amplifier entropy spectrum, all-mode numerical proof or physical experiment is claimed.

## 11. Costs and remaining boundaries

The source matrices, exact independence, finite Fock support, covariance certificates, gain and noise calibration are supplied mathematical data. Their physical acquisition is not demonstrated. The Gaussian references and signed finite output are analytic comparison objects. Real heat is applied to both inputs: the net mean input-mode energy rises by \(2nT\hbar\omega\) at a common mode frequency. The main amplifier raises the combined energy of its two outputs by \(2Hn(a+b+2T+1)\hbar\omega\). These are ideal mean-energy balances, not complete factory work budgets.

Noise generation, loss/amplifier auxiliary modes, full residuals, source preparation, pump/control, calibration, precision, randomness, storage, disposal and reset require explicit physical resources in any implementation. No catalyst return, free bath reset, efficient threshold acquisition, hardware experiment or practical advantage is obtained. Constants can depend badly on support, moment order, and the nonzero moment discrepancy; no useful uniform finite threshold has been acquired.

There is a further exact physical qualification. In these noise units,

\[
\mathcal H_1^{\otimes n}(\rho)=\int_{\mathbb C^n}\frac{d^{2n}\alpha}{\pi^n}
\langle\alpha|\rho|\alpha\rangle\,|\alpha\rangle\langle\alpha|.
\]

The Fourier transform of the Husimi weight supplies one factor \(e^{-|z|^2/2}\), and the coherent preparation supplies the other, proving the characteristic multiplier \(e^{-|z|^2}\). Thus every \(T\ge1\) heated input is a positive mixture of native product coherent states, even if the original finite source was internally entangled. Initial entanglement is admitted by the theorem, but none survives as native intermode entanglement in the eventual actual inputs. Noncommuting Fock coherences and classical correlations can survive. This does not itself turn the von Neumann photon-number inequality into a classical entropy inequality, and no such shortcut is used here.

Finite Fock support, positive isotropic native covariances, finite fixed mode number, and full A/B independence remain assumptions. Passing to arbitrary finite-energy quantum sources would need an additional uniform approximation argument; passing back through heat is not authorized by this result. Current unheated general amplifier EPnI status in this programme remains UNKNOWN. Primary comparisons and their own scope limits are recorded separately in `PRIMARY_BOUNDARY.md`.
