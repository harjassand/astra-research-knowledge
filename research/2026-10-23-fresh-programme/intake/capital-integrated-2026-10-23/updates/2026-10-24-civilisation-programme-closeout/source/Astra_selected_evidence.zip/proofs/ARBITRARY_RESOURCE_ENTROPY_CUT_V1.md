# Two-cut port-entropy obstruction with arbitrary initial bath entanglement

23 October 2026. Independent w19 continuation after the weighted-Choi proof
was frozen. Root independently reconstructed the same beta0 argument and
the matched-pair all-beta extension in parallel. Fresh hash-specific criticism
is requested. This is a capacity/weak-converse bound, not an exponential
strong converse or CP domination for entangled initial resources.

## 1. Resource model and normality

Use exactly the unchanged V_beta device, bath E, root R, colors S1,S2 and
charge q=diag(0,1,1) of `FULL_PROOF_V1.md`. Fix N, possibly with any
N-dependent initial normal resource

    eta_(E L_A L_B G).

The laboratories may have arbitrary preshared entanglement with each other
and with E. G is an inaccessible purifier/environment if desired. Alice owns
L_A and a fresh logical input M; Bob owns L_B. The fresh logical reference
R_log and M begin in Phi_K, independently of the ENTIRE initial resource:

    Phi_(R_log M) tensor eta_(E L_A L_B G).

Only the prescribed N chronological qutrit calls provide an Alice-to-device/
Bob path. Backward Bob-to-Alice quantum/classical communication, local normal
operations and ancillary registers are arbitrary. There is no extra forward
wire or forward signalling through a timing/selection side channel, no direct
bath access, no initial correlation with the fresh logical state, and no
postselected normalization. All branches count in a fixed K-dimensional
trace-preserving receiver output.

No initial entropy, bath depth, support, coherence, entanglement or preparation
budget is bounded. Giving all those resources for free strengthens the upper
bound; it does not acquire their physical preparation.

The fresh reference is finite-dimensional. All mutual informations involving
it are finite (at most2log2 K), even when other normal systems have infinite
entropy. Conditional mutual information with a finite qutrit message has the
usual well-defined finite-system chain rule. No subtraction of infinite
ancillary entropies is used below.

## 2. Two information-flow cuts

At call t, let A_t be the incoming physical qutrit immediately before its
device interaction and B_t the outgoing qutrit immediately after it. Their
entropies are those of the actual unconditional protocol marginals, including
all adaptive branches.

For the cut Alice | (device E,G plus Bob), initially the fresh reference has
zero mutual information with the receiving side. Moving A_t into that side
increases the mutual information by

    I(R_log:A_t | receiving_side_before)<=2 S(A_t).

The inequality follows from -S(A_t)<=S(A_t|Y)<=S(A_t), valid with finite A_t
and arbitrary normal Y. Device unitaries and receiver local operations do not
increase mutual information beyond data processing. Backward messages move
systems OUT of this receiving side and cannot increase it. Sender local
trace-preserving operations leave the receiving-side/reference marginal
unchanged. Therefore

    I(R_log:Bob_final)<=2 sum_t S(A_t).                     (E1)

For the second cut Bob | (Alice plus device E,G), the only systems entering
Bob from outside are B_t. Initially I(R_log:Bob)=0. The same chain-rule
argument, with backward messages leaving Bob, gives

    I(R_log:Bob_final)<=2 sum_t S(B_t).                     (E2)

These two bounds permit arbitrary initial E--laboratory entanglement. The
initial zero mutual informations follow from fresh-logical independence,
not from any product assumption among the initial resource registers.

Combining them gives

    I(R_log:Bob_final)
       <=2 min{sum S(A_t),sum S(B_t)}
       <=sum_t [S(A_t)+S(B_t)].                            (E3)

## 3. Exact beta0 charge obstruction

At beta=0, V=U. Directly from its actual Kraus blocks,

    U^*(q_B tensor I)U=|0><0|_A tensor(I-P0).

Thus for EVERY correlated pre-call state on A_t,E,laboratories,

    u_t=Pr(A_t colored), v_t=Pr(B_t colored),
    u_t+v_t<=1.                                            (E4)

This is a bounded operator inequality including the root. It requires no
input/bath product, no diagonal state and no finite depth.

For any qutrit state with colored probability x, pinching into the one-
dimensional vacuum and two-dimensional colored subspaces and then maximizing
the colored entropy gives

    S(qutrit)<=f(x):=h2(x)+x.

Hence each physical call satisfies

    S(A_t)+S(B_t)
       <=h2(u_t)+h2(v_t)+u_t+v_t<=3.                       (E5)

Equations(E3)--(E5) prove

    I(R_log:Bob_final)<=3N                                (E6)

uniformly over the entire arbitrary initial-resource class above.

## 4. Operational quantum-rate consequence

Let Bob's normalized fixed-dimensional decoded output be L, and F_N its
Bell overlap with Phi_K. Its reference marginal remains I/K. Data processing
of I(R_log:L) by the binary Bell test yields

    I(R_log:L)>=d_bin(F_N ||1/K^2)
                >=2F_N log2 K-h2(F_N).

The comparison state's Bell probability is1/K^2 because it is
(I_R/K) tensor omega_L. The last lower bound drops the nonnegative
term -(1-F_N)log2(1-1/K^2). Combining with(E6),

    2F_N log2 K_N-h2(F_N)<=3N.                             (E7)

Consequently F_N->1 implies limsup log2 K_N/N<=3/2. No independently
prepared normal coherent initializer family, even with arbitrarily extensive
initial bath--laboratory entanglement, can enable reliable rate above3/2
under this interface.

For full qutrit logical dimension K_N=3^N, (E7) implies

    limsup F_N<=3/[2log2 3]<1.

This is weaker in error exponent than the product/separable-initializer CP
bound: it does NOT prove F_N->0 for arbitrary entangled initial resources.
It suffices to exclude their proposed reliable capacity increase. Matching
the ceiling to3/2 achievability for the enlarged resource class relies on the
inherited known-initializer lower code, which is separate from this proof.

## 5. All-beta matched-pair extension

For completeness, the same method gives a weaker but resource-uniform
finite-angle bound. The joint port/bath space decomposes into matched pairs

    {|0,S_j x>, |j,x>}, j=1,2,

and the two-dimensional root block {|0,seed0>,|0,seed1>}.
On each matched pair U is sigma_x and q_A=diag(0,1). On the root block
both incoming and outgoing charges vanish. With a=1-b and b=beta^2,

    q_A+V_beta^* q_B V_beta
      =[[a, i sqrt(ab)],[-i sqrt(ab),1+b]]

on a matched pair. Its eigenvalues are1-beta and1+beta (for beta>=0).
The root block is zero. Therefore

    u_t+v_t<=1+beta                                       (E8)

for every state and resource. Concavity of f and monotonicity up to its
maximum at2/3 show that, for0<=beta<=1/3,

    S(A_t)+S(B_t)<=2 f((1+beta)/2).

For larger beta use2log2 3. The resulting all-resource reliable-rate ceiling is

    Q<=C_ent(beta):=f(min{(1+beta)/2,2/3}).                  (E9)

Near zero this is

    C_ent(beta)=3/2+beta/2-beta^2/(2ln2)+O(beta^4).

The product-initializer CP ceiling remains quadratic and stronger in that
regime. This entropy bound leaves a possible linear-vs-quadratic gap for
initial bath entanglement at beta>0; it proves no achievability there.

## 6. Costs and scope

Every forward call counts. Initial bath coherence, depth, entropy, support
and E--laboratory entanglement are unrestricted in this upper bound, so no
finite cost lower bound is being mistaken for a construction. Initial Alice--
Bob entanglement is not charged as bath entanglement or excluded. Backward
bandwidth may be unlimited only to strengthen the converse. Physical source
preparation, exact coherent control, depth access, timing, energy, resets,
memory and noise remain unacquired.

The proof uses only the fixed device's charge operator and generic quantum
information flow. It is an internal mathematical derivation requiring fresh
criticism, not an experimental quantum communication result or a priority
claim. A free extra forward message, fresh-logical/resource correlation,
changed interaction, accessible bath output or postselected task would
change the contract.
