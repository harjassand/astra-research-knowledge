# Fresh reconstruction of the exponential-tail coherent heat bridge

23 October 2026. Reviewer W17. This is an internal, source-bound mathematical
audit; external validation, priority and useful physical performance are separate.

## Exact frozen targets and verdict

I independently reconstructed both complete targets, without importing their
producer diagnostics, the finite-Fock proofs, the bounded/unbounded quantum-M3
notes, N557, or a claimed generic optimizer theorem:

* W38 `COHERENT_SANDWICH_HIGHER_MOMENT_BRIDGE.md`, SHA256
  `e51dd5d26d94d222032deab14232cc973e5825089b96e6dc8fcd7288378e4fff`.
* W38 `ARBITRARY_COVARIANCE_EXPONENTIAL_TAIL_HEAT_CLOSURE.md`, SHA256
  `d0e95b062c7b6c3c02ff512fc2e17f0c41866444ec58a8bda0eb079fa7ce0334`.

Exact snapshots are `SOURCE_*.md` in this folder. **No blocking mathematical
defect found at their stated scope.** All estimates below are for one fixed
finite mode count, fixed gain and fixed source pair before heat tends to infinity.
There is no acquired or uniform source-independent heat threshold.

The exact consequence is the following. Fix integer n>=1 and G>1; put
lambda=G-1, s=2G-1. Let rho_A and rho_B be independent n-mode normal states,
each with a supplied finite positive exponential photon moment. Their respective
covariances may be arbitrary physical finite matrices; within-party correlations,
coherences and entanglement are admitted initially. Apply the actual isotropic
additive-noise channel H_T separately to every input mode, with covariance
increment T I. The amplifier retained quadratures are sqrt(G) R_A+sqrt(lambda)J R_B,
where J is block diag(1,-1). For every sufficiently large finite T,

    S(C_T) >= n g(G g^{-1}(S(A_T)/n)
                         +lambda[g^{-1}(S(B_T)/n)+1]).

If at least one fixed input is non-Gaussian, its entropy-form gap is bounded
below by c T^{-m} eventually for some c>0 and a finite first unmatched Gaussian
moment order m>=3. In the isotropic case its whole gap equals
kappa T^{-m}+O(T^{-m-1}); for arbitrary covariance the whole gap includes a
nonnegative Gaussian baseline and can have a larger leading order. Gaussian
inputs satisfy the exact Gaussian inequality at every heat, including zero.

The one-state bridge itself proves

    D(H_T rho || H_T gamma)
        = ||Delta_M||_F^2/(2 M! T^M)+O(T^{-M-1}),

where gamma matches the centered first/second moments and Delta_M is the first
unmatched real Husimi moment tensor. This is normal quantum relative entropy,
not a replacement of von Neumann entropy by a classical phase-space entropy.

## 1. Independent reconstruction of the classical kernel

Let d be finite, X centered with covariance Sigma>=0 and an exponential
quadratic moment, Z Gaussian with that covariance, and mu=law(X)-law(Z).
For t>0 let p_t=law(X)*G_t, q_t=G_{tI+Sigma}, f_t=(p_t-q_t)/q_t and epsilon=1/t.
The Gaussian y precision in

    integral product_i G_t(y-x_i)/q_t(y)^{k-1} dy

is

    A = k/t I-(k-1)(tI+Sigma)^{-1}
      = epsilon (I+k epsilon Sigma)(I+epsilon Sigma)^{-1}.

It is positive even when Sigma has a kernel. The linear term is epsilon U,
U=sum_i x_i. Direct completion of the square gives the determinant

    det(I+epsilon Sigma)^{k/2}/sqrt(det(I+k epsilon Sigma))

and exponent

    epsilon sum_{i<j} x_i.x_j
       -(k-1)epsilon^2 U^T Sigma(I+k epsilon Sigma)^{-1}U/2.

This verifies S3, including the k=4 determinant and the sign/placement of the
matrix correction. Keeping the two unsimplified Gaussian determinants is a
useful independent normalization check.

This pointwise identity alone would not justify exchanging signed integrals.
Here |mu| is bounded as a measure by the sum of the two probability laws and
has an exponential quadratic moment at some beta>0. On 0<=epsilon<=epsilon_0,

    K <= C exp[(k-1)epsilon sum_i |x_i|^2/2].

Every derivative of log K of any fixed finite order is bounded by a constant
times 1+sum_i|x_i|^2: all matrix resolvent derivatives are bounded on this
compact positive interval. The derivatives of K are therefore bounded by
the same exponential times a fixed polynomial. Choose epsilon_0 strictly
smaller than the exponential-moment margin, leaving room for that polynomial.
Absolute Fubini and dominated differentiation then apply to the full product
|mu|^{tensor k}. They justify both the exact relative k-th moment identity and
the Taylor remainder. This is not an appeal to formal asymptotic symbols or to
a global classical Lp channel contraction.

Suppose each mu annihilates polynomials of degree <M separately. In the
epsilon^r coefficient, the total x degree is <=2r. A monomial that survives
product-mu integration must have degree >=M in *every* x_i. Thus all
coefficients with 2r<kM vanish. For k=2, r=M, only
(x_1.x_2)^M/M! attains total degree 2M: the covariance correction has degree
two at epsilon order >=2, and determinant terms have degree zero. Integrating
gives

    integral q_t f_t^2 = ||Delta_M||_F^2/(M! t^M)+O(t^{-M-1}).

For k=4, derivatives below 2M vanish and the bounded 2M-th derivative gives
integral q_t f_t^4=O(t^{-2M}). These remain true with a zero Delta_M if the
source matches further. The two Taylor steps require only finitely many
derivatives; there is no uniform-in-M, dimension or source assertion.

Since f_t>=-1, the scalar bound

    |(1+f)ln(1+f)-f-f^2/2| <= |f|^3/2

and Cauchy-Schwarz in q_t give an entropy remainder O(t^{-3M/2}). For M>=3
this is O(t^{-M-1}). This proves S6 with the exact coefficient. Frobenius
normalization is equivalent to

    ||Delta_M||_F^2/M! = sum_{|alpha|=M} |Delta_alpha|^2/alpha!.

This is exactly the usual multiplicity of the symmetric tensor's coordinates.

## 2. Husimi exponential moments and finite first unmatched degree

Use R=(q_1,p_1,...), vacuum covariance I/2 and coherent mean
x=sqrt(2)(Re alpha_1,Im alpha_1,...). The Husimi probability law has covariance
V+I/2. In the number basis, radial integration gives the positive form identity

    integral exp(beta |x|^2)|alpha><alpha| d^{2n}alpha/pi^n
       = (1-2beta)^{-n}(1-2beta)^{-N},  0<beta<1/2.

Angular integration kills number off-diagonals; each one-mode diagonal integral
is (1-2beta)^{-k-1}. Positivity and Tonelli extend the equality to every normal
rho, allowing infinity. Choose beta so -ln(1-2beta) is below the supplied
photon exponent. S7 is therefore valid without a finite-rank or bandwidth bound.

Translation of this classical law preserves an exponential quadratic moment at
a smaller parameter, by |x-m|^2<=2|x|^2+2|m|^2. Applying the same identity back
also verifies a positive exponential photon moment for the centered state.
Thus centering does not require a false operator monotonicity of exponentials
of noncommuting number operators.

The exponential quadratic moment gives an entire characteristic function in
the complex Fourier variables: on each compact complex set its integrand is
bounded by exp(beta |x|^2) times a constant. Differentiation under the integral
is valid. If every Gaussian moment matched, the analytic functions agree near
zero and hence everywhere; Fourier uniqueness then gives the same Husimi law.
Its Fourier transform is the quantum Weyl characteristic multiplied by a
nowhere-zero Gaussian factor, so Husimi measurement is injective on normal
states. Therefore a non-Gaussian source has a finite first mismatch M>=3.
All cumulants below M agree; its moment-difference tensor equals the M-th
non-Gaussian cumulant. The added Husimi vacuum covariance cannot change it.

## 3. Exact quantum sandwich and its normal-domain completion

In these units additive classical covariance t I multiplies the Weyl
characteristic by exp(-t|z|^2). Coherent preparation adds covariance I/2;
heterodyne measurement adds I/2 again. Consequently, for T>1,

    H_T rho = C(Q_rho * G_{T-1}),
    Q_{H_T rho} = Q_rho * G_T.

The same holds for the matching Gaussian. Characteristic functions establish
these equalities of actual normal states; no inverse heat map is invoked.
Applying quantum relative-entropy DPI first to coherent preparation and then
to heterodyne gives

    D(p_T||q_T) <= D(H_T rho||H_T gamma)
                       <= D(p_{T-1}||q_{T-1}).

Both sides have coefficient C_M=||Delta_M||^2/(2M!), and shifting T by one
changes C_M T^{-M} only by O(T^{-M-1}). This proves the normal quantum
asymptotic without a noncommuting entropy Taylor expansion.

The continuous-classical interface is legitimate, and can be reduced to
discrete ones if preferred. Heterodyne probabilities for any finite measurable
partition come from a finite-outcome POVM; the classical relative entropy is the
supremum of its finite-partition values. For preparation, fix its reference
probability q and a refining sequence of finite partitions generating the
Borel sigma algebra. Prepare, in cell E, the state averaged with q(.|E).
Writing l=p/q, the resulting states use l_j=E_q(l|partition_j); martingale L1
convergence gives trace-norm convergence because coherent projectors have trace
norm one. Their reference state is exactly C(q) at every stage. Discrete-channel
DPI, D(partition p||partition q)<=D(p||q), and lower semicontinuity prove the
upper bound. This construction does not grant a measured source record to a
physical participant. All reference densities here are strictly positive once
the displayed classical heat times are positive.

Finite second moments already bound the entropy of every actual heated state
by the thermal maximum at its finite energy. The heated matching Gaussian is
faithful. Its negative logarithm is a constant plus a positive quadratic form
after a finite-dimensional Williamson transformation. Matching first/second
moments therefore makes its cross-entropy exactly the Gaussian entropy, with
all quadratic expectations finite. Hence

    D(rho_T||gamma_T)=S(gamma_T)-S(rho_T)

is a genuine finite identity, not an infinity-minus-infinity subtraction.

## 4. Actual creation-port output and strict tensor coefficient

Independence between the groups is load-bearing. Draw their two Husimi vectors
independently and let Y=sqrt(G)X_A+sqrt(lambda)J X_B. It has an exponential
quadratic moment: |Y|^2<=2G|X_A|^2+2lambda|X_B|^2 and the laws factor. Its
covariance is G Sigma_A+lambda J Sigma_B J. For T>G/s the exact retained state is

    C(law(Y+Z_{sT-G})).

Indeed the two Husimi factors contribute a Weyl multiplier exp(-s|z|^2/2),
preparation contributes exp(-|z|^2/2), and the added noise contributes
exp[-(sT-G)|z|^2]. Since (s+1)/2=G, their product is exp(-sT|z|^2), precisely
the heat after the actual two-port amplifier. Its matching Gaussian covariance
is G V_A+lambda J V_B J+sT I. Heterodyne adds one noise unit, so the output D
lies between the classical quantities at sT-G+1 and sT-G, respectively.

Let m be the smaller first unmatched order, with infinity for a Gaussian input.
Set a missing degree-m tensor to zero. Expansion of Y^{tensor m} shows

    Delta_Y = G^{m/2} Delta_A +lambda^{m/2}J^{tensor m}Delta_B.

Every genuinely mixed term uses degree between 1 and m-1 from both groups,
so its expectation agrees with the independent Gaussian pair. Within-group
quantum correlations do not invalidate this argument; dropping independence
between the groups would invalidate it.

Put A=Delta_A, B=J^{tensor m}Delta_B, theta=G/s, phi=lambda/s. The bridge yields

    d_A=||A||^2/(2m!T^m)+O(T^{-m-1}),
    d_B=||B||^2/(2m!T^m)+O(T^{-m-1}),
    d_C=||theta^{m/2}A+phi^{m/2}B||^2/(2m!T^m)+O(T^{-m-1}).

The last formula remains valid when the displayed tensor cancels, without
needing to infer a new first unmatched output degree or a photon-exponential
bound on the unheated quantum output. Weighted vector Cauchy-Schwarz gives

    ||theta^{m/2}A+phi^{m/2}B||^2
      <=(theta^{m-1}+phi^{m-1})(theta||A||^2+phi||B||^2).

Since m>=3, both weights are positive and their sum is one, this coefficient
has a strict gap. In particular the stated kappa is positive whenever at least
one tensor is nonzero. J is orthogonal, so it preserves the tensor norm.

## 5. Independent active Gaussian prerequisite

The exact Gaussian inequality, rather than an error of order T^{-3}, is needed
when m is arbitrarily large. It follows from established symplectic variational
mathematics plus the active scalar convexity below.

For A>0, transform to Williamson covariance diag(D,D). A real 2k by 2n canonical
frame defines b=U a+V a^dagger with UU^dagger-VV^dagger=I. Its total variance is
2Tr(U D U^dagger+V D V^dagger). Write U=(UU^dagger)^{1/2}W, WW^dagger=I.
Positivity gives Tr(U D U^dagger)>=Tr(W D W^dagger), and ordinary Ky Fan bounds
the latter below by the k smallest entries of D. Taking V=0 and W selecting
those modes attains the bound. Thus

    min_{S Omega S^T=Omega_k} Tr(S A S^T)=2 sum_{j<=k}nu_j(A).

Minimizing the sum of two positive quadratic forms gives the ascending
partial-sum superadditivity. Scaling covariances scales their symplectic
eigenvalues; J is antisymplectic but preserves their positive spectrum (it
reverses the signed eigenvalues of i Omega V). The increasing-concave function
h(v)=g(v-1/2) therefore gives

    S(gamma_C)>=sum_j h(G a_j+lambda b_j).

This reconstruction agrees with Hiroshima's exact Lemma 1 and Theorem 1; the
majorization direction is not reversed. De Palma Appendix A.8 supplies the
known passive application, but its passive scalar coefficient was not silently
continued into the active domain.

For the active scalar map F(u,v)=h(G h^{-1}(u)+lambda h^{-1}(v)), write
ell(x)=ln[(x+1/2)/(x-1/2)], W_x=x^2-1/4, K(x)=W_x ell(x). Its absolutely
convergent series for x>1/2 is

    K(x)=x-sum_{r>=1} 2 x^{-(2r-1)}/[(4r^2-1)4^r].

For c=G a+lambda b and p>0, weighted convexity gives
G a^{-p}+lambda b^{-p}>=s^{p+1}c^{-p}>c^{-p}. Termwise subtraction therefore
gives K(c)>G K(a)+lambda K(b). Direct differentiation reproduces G7, with
positive pure Hessian entries and determinant

    G lambda K(c)[K(c)-G K(a)-lambda K(b)]
       /[W_c^2 ell(a)^2 ell(b)^2 K(a)K(b)] > 0.

Jensen over the n entropy pairs proves the exact Gaussian active EPnI. The
boundary at pure modes follows by adding epsilon I to the finite covariances
and continuity of g. Heat makes all modes strictly warm in the actual argument.

## 6. Arbitrary covariance closure and order of limits

Let s_i(T) be the matching Gaussian entropies and d_i the just-proved defects.
The exact Gaussian baseline B(T)=s_C-nF(s_A/n,s_B/n) is nonnegative. For each
fixed finite covariance V, all symplectic eigenvalues of TI+V lie between
T+lambda_min(V) and T+lambda_max(V): apply norm and inverse-norm bounds to
i(TI+V)^{1/2}Omega(TI+V)^{1/2}, a Hermitian matrix with paired signed eigenvalues.
Consequently h^{-1}(s_i(T)/n)=T+O(1), by monotonicity of h and the same bounds
on its average. At this pair, F_u=theta+O(T^{-1}), F_v=phi+O(T^{-1}).

The whole intervening entropy segment differs by d_i/n=O(T^{-m}), so its
effective variances remain of order T. The Hessian formulas above are uniformly
bounded there: W_c ell(a)^2 and W_c ell(a)ell(b) remain bounded away from zero,
and all K-ratios remain bounded for the fixed gain and sources. Taylor's finite
remainder then gives exactly

    Delta(T)=B(T)+kappa T^{-m}+O(T^{-m-1})+O(T^{-2m}/n).

The last term is absorbed. Keeping the exact nonnegative B(T) proves
Delta(T)>=kappa/(2T^m) for every sufficiently large finite T. No sign inference
from a merely asymptotic Gaussian prerequisite is used. For arbitrary covariance
the baseline may dominate at order T^{-2}, so the total gap is not asserted to
be Theta(T^{-m}). The narrower isotropic target has B(T)=0 exactly.

All sources, n, G, exponential-moment constants, the first mismatch and its
nonzero tensor are fixed before T grows. The source-dependent constants can be
arbitrarily poor. No assertion is made for n growing with T, for horizon-dependent
source sequences without uniform estimates, or for an acquired computable heat
threshold based only on finite observations.

## 7. Independent finite diagnostics and evidence limits

`check_bridge.py` imports no producer code. `bridge_checks.json` retains all raw
numbers. One run passed in 1.563758 seconds with macOS maximum RSS 202,735,616
bytes:

* 48 pointwise Gaussian-kernel comparisons against direct unsimplified Gaussian
  integration, k=2,4, dimensions 1,2,5, including singular Sigma. Maximum log
  discrepancy was 6.99e-15.
* Exact Gaussian integration of the full signed-mixture k=2,4 expressions, using
  95-digit arithmetic, for first unmatched degrees 3,4,6 at t=16,64,256. No spatial
  integration cutoff is used. The scaled second and fourth moments approach the
  independently computed Hermite coefficients. These finite checks do not prove
  the dominated Taylor or arbitrary-degree argument.
* 48 squeezed multimode Gaussian comparisons, n=1,2,4 and gain 1.00001,1.2,2,9,
  testing both ascending symplectic partial sums and the final entropy inequality.
  Minimum entropy gap in these fixtures was 4.01e-6. These are synthetic finite
  matrices, not a universal numerical proof or an experimental test.
* Four genuinely infinite-rank, infinite-Fock-bandwidth quantum sources at
  T=2,4,8,16. The initial state is
  (2/3)|-1><-1|+(1/3)|2><2|, with coherent amplitudes indicated by the kets.
  It is centered, has V=diag(4.5,.5), and its first unmatched tensor has only
  qqq entry 4sqrt(2), so C_3=8/3. Its actual heat is a mixture of displaced
  thermal states. Exact principal matrix entries are generated from the Bargmann
  recurrence, not from a truncated oscillator unitary. Separate analytic photon
  Chernoff bounds control the infinite tail, between 5.19e-26 and 2.72e-13 in
  these fixtures. Entropy is enclosed analytically by the principal entropy and
  h2(q)+q g(E/q); floating eigensolver errors are additional, not interval certified.
  The lower/upper quantum defects fit strictly inside the two classical sandwich
  bounds. The largest 80-vs-160 Hermite quadrature refinement is 8.15e-10 at the
  smallest time, much below the inequality slack. Its T^3-scaled defect progresses
  from .36165 to 1.76730 toward the asymptotic 2.66667; no finite time is presented
  as the exact asymptotic regime.

The last fixture deliberately tests the absence of a finite bandwidth assumption,
but it is one supplied positive-P family. It proves no new all-input statement.
No full-amplifier non-Gaussian entropy fixture, native entangled-input experiment,
or finite-precision physical implementation has been acquired by these tests.

## 8. Complete physical and priority boundaries

Each actual H_T adds nT photons per input group. For equal mode frequency omega,
this is 2nT hbar omega total added input energy. In the centered normalization,
the ideal two-output amplifier energy increase is

    2lambda [E_A(0)+E_B(0)+2nT+n] hbar omega.

For nonzero original means, a further mean-dependent cross term appears in that
ideal energy balance; the displacement equivalence used for entropy does not
acquire a free physical centering operation or its record. None of these ideal
balances is a complete factory-work certificate.

For T>=1, H_T is heterodyne measurement followed by coherent preparation with
extra classical Gaussian displacement. It is entanglement breaking and its output
is a positive mixture of native product coherent states. Thus initially allowed
within-party entanglement has not survived into the eventual heated inputs.
Classical correlations, non-Fock-diagonal coherence and correlations with actual
purification records can remain; neither a free accessible Husimi record nor a
joint reference reset has been supplied.

The mathematical hypotheses supply exact sources, independence, covariances and
positive exponential photon tails. No finite tomography, tail certification,
source factory, covariance/entropy acquisition, random-displacement calibration,
gain/phase control, pump model, precision synthesis, catalyst/battery return,
ancillary memory, disposal or reset has been implemented. The vanishing strict
gap would require a corresponding precision analysis before an approximate
device could certify its sign. There is no claimed practical or physical advantage.

Primary comparison is in `PRIMARY_BOUNDARY.md`. Chen--Niles-Weed already gives
the generic classical leading coefficient under the same exponential quadratic
tail premise. Hiroshima supplies the symplectic principle, and the Gaussian
comparison and generic coherent/DPI ingredients have established predecessors.
The exact scope of any new quantum coefficient/changed-input application remains
historical-priority UNKNOWN; this audit is not an external review or novelty
certificate. It does not establish the general unheated independent-input EPnI,
the finite-energy heavy-tail case, backward heat monotonicity, arbitrary A/B
correlation, or a source-uniform high-noise result. Earlier finite-Fock and M3
source packets and receipts remain unchanged.
