# Exact maximum-entropy Gibbs source from a positive bath multiplier

w49 independent continuation, 23 October2026. Generic finite convex-duality
mechanism applied to the unchanged recurrent device. This is not a field-wide
novelty claim or a newly improved numerical capacity coefficient. It supplies
a concrete optimizing source interface and an equally informed baseline.

## Finite bulk setup and theorem

Fix the physical block length k and 0<beta<1. Let A=(C^3)^tensor k and
F=(C^2)^tensor k be the analytical first-k-color prefix. The pinned original
Cycle10 all-distance source identifies

`Gbar=pin_Q(Q-W*QW)`

on A tensor F, tensor identity on seed and untouched tail, for initial depth
at least k. This is the actual unitary bulk displacement; no finite reflecting
boundary or reset is inserted. It is Hermitian, commutes with total input Q,
and has norm<=k. Define the actual operator drift on charge-preserving input
rho by

`D(rho)=Tr_A[(rho tensor I_F)Gbar]`.

Suppose an already supplied finite density rho0 is Q-preserving and satisfies

`D(rho0)<=-kappa I_F`, kappa>0.

Its entropy is S0 in NATURAL units. No full rank of rho0 is required. Choose
any target margin 0<eta<kappa. For a positive semidefinite, UNNORMALIZED bath
multiplier L>=0 define

```
H_L=Tr_F[(I_A tensor L)Gbar],
Z_L=Tr_A exp(-H_L),
f_eta(L)=ln Z_L-eta Tr_F L.
```

Then f_eta has a finite minimizer L*. Its Gibbs input

`rho*=exp(-H_L*)/Z_L*`

is strictly positive, Q-preserving, and obeys

`D(rho*)<=-eta I_F`, `S_nat(rho*)>=S0`.

In fact rho* is the UNIQUE maximum-entropy density among all Q-preserving
inputs with drift<=-eta I_F, and

`S_nat(rho*)=min_(L>=0) f_eta(L)`.

Every minimizing multiplier is contained in the EXPLICIT compact trace ball

`Tr L <= [k ln3-S0]/(kappa-eta)`.                       (D1)

The multiplier is purely analytical: it is not an initial bath density or a
physical resource the sender acquires, observes or prepares.

## Full proof without an unproved strong-duality invocation

H_L is Hermitian and Q-preserving because Gbar is. The Gibbs variational
inequality follows directly from nonnegativity of relative entropy:

`ln Z_L >= S_nat(rho)-Tr rho H_L`

for every density rho. Apply it to rho0 and use the adjoint pairing
Tr rho0 H_L=Tr L D(rho0)<=-kappa Tr L. It gives

`f_eta(L)>=S0+(kappa-eta)Tr L`.

Since f_eta(0)=ln dim A=k ln3, a minimizing sequence can be restricted to
(D1). Positivity and a trace bound form a compact finite-dimensional set.
Continuity yields a minimizer. No density-matrix boundary differentiability
of rho0 or unbounded multiplier limit is needed.

Differentiating the finite matrix trace exponential cyclically gives, for
any Hermitian variation P,

`d f_eta(L)[P]=-Tr_F P[D(rho_L)+eta I_F]`.

At a PSD-cone minimum, L*+tP is admissible for every P>=0,t>=0. Its right
first derivative is nonnegative. Testing all such P gives
`D(rho*)+eta I_F<=0`. Scaling L* by1+t is admissible for both signs of
sufficiently small t, so the derivative along L* vanishes:

`Tr L*[D(rho*)+eta I_F]=0`.

This remains true when L*=0. Now

```
S_nat(rho*)=ln Z_L*+Tr rho* H_L*
           =ln Z_L*+Tr L* D(rho*)
           =ln Z_L*-eta Tr L*=f_eta(L*).
```

For every feasible rho, the same Gibbs variational inequality gives

`S_nat(rho)<=ln Z_L+Tr L D(rho)<=ln Z_L-eta Tr L=f_eta(L)`

for all L>=0. Thus the constructed Gibbs state is feasible and achieves
the exact primal upper bound. This proves maximum entropy and the equality
without an assumed strong-duality theorem. Entropy is strictly concave on
the convex feasible density set, giving unique rho*, though L* need not
be unique. Since rho0 remains feasible at eta<kappa, S(rho*)>=S(rho0).

Writing gamma=TrL and zeta=L/gamma when gamma>0 yields

`H_L=gamma[D+K_full,zeta]`, D=a(2Q-k).

The optimization therefore chooses the score, inverse temperature AND its
endogenous charge distribution. It requires neither a prescribed binomial
charge law nor an optimizer-dependent scalar fixed point. This is the
relation to w56's separately reviewed normalized total-charge Gibbs source;
no partition-pressure improvement is inferred merely from this equivalence.

## Original device/code interface and resource costs

I reopened the pinned Cycle11 carried Cycle10 source. Its all-distance
section explicitly supplies the finite first-k-color representation of
pin_QG. Its 'Uniform operator drift gives actual reliable codes', equation
(C3), requires only fixed Q-preserving rho and a strict bulk drift margin.
It does not require complete-pattern scalar normalization. Thus rho* meets
that inherited interface at margin eta, with entropy no less than rho0.
The original actual-root Lyapunov, spectral-type code, joint full-reference
compression and pointwise fixed-normal initializer quantifiers are retained.

The parameter choice, state and margin are fixed before the OUTER code
horizon. This construction has input rank exactly3^k and a PSD optimization
variable of size2^k by2^k. Trace bound(D1) proves compact mathematical
existence, not affordable optimization. H_L can have norm as large as
k TrL; no modest condition number, preparation complexity or accuracy cost
is claimed. Decreasing eta may improve the feasible entropy but worsens
Lyapunov/return costs. Taking eta close to kappa enlarges the crude dual
trace budget through1/(kappa-eta).

Finite-precision existence can also be quantified: ||H_L-H_L*||<=
k||L-L*||_1; integrating the Gibbs Duhamel derivative gives
||rho_L-rho*||_1<=2k||L-L*||_1. Hence its actual drift changes by at most
2k^2||L-L*||_1. A sufficiently accurate finite PSD approximation therefore
retains a strict margin, e.g. trace-norm error<=eta/(4k^2) retains eta/2.
This is an approximation tolerance, not a certified optimizer or source
factory acquired here. Entropy continuity has its usual log(3^k) cost.

No better numerical rate is asserted without evaluating this optimum against
all simple feasible mixtures, including `DRIFT_SLACK_MIXTURE_BASELINE.md`.
No equipment, physical bath operation, public disclosure or outreach occurred.
External correctness, novelty, useful blocklength and practical advantage
remain UNKNOWN. This V1 is frozen for independent critical reconstruction.
