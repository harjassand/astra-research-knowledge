# Pulse aging — root reconstruction, scope counterexample and extra bound

23 October2026. Independent derivation after W63's construction; fresh W15 audit in progress. Basic and conditioned-path EP bounds agree with W63. The unconditioned-path alternative and explicit odd-parity countermodel below are root additions. The mathematical primitives are established Cauchy–Schwarz, path-relative entropy and Pinsker; priority UNKNOWN. No physical operation is acquired.

Let Q be a finite irreducible stationary CTMC on time-EVEN labels, stationary law pi. B is a visible off set. Start at a random stationary time CONDITIONAL on being in B, w=pi(.|B), not at a dwell entrance. Let T=exp(tau Q_B) be the killed baseline semigroup, censoring at first exit. An identical state-only finite pulse has survival probabilities g_i in[0,1]. These need not be known individually or selective. Measurable probabilities are b=pi(B), z=<1,T1>_w, z2=<1,T^2 1>_w, a=<1,g>_w, c=<1,Tg>_w. A delayed-pulse trial counts joint baseline-and-pulse survival, without conditioning away baseline failures.

Under ordinary detailed balance, T is self-adjoint. Put f=T1; then z2=||f||², c=<f,g>. Cauchy–Schwarz and Var(g)<=a(1-a) imply

(c-za)^2 <= (z2-z²) a(1-a).                           (1)

It excludes ALL finite hidden reversible CTMC completions satisfying this interface, not merely a fitted state model. It does not exclude all physical equilibrium processes.

For nonreversible ordinary time-even CTMC, write f*=T*1, where T* is the killed stationary reversed semigroup. Both f,f* are in[0,1] and have mean z. Put D=c-za, V=z2-z² and kappa=[D²/{a(1-a)}-V]_+ for0<a<1. Then D=<f*-z,g-a>, V=<f*-z,f-z>, so

When kappa>0, kappa <= Var(f*)-V=<f*,f*-f> <=.5||f*-f||_(1,w).
When kappa=0 the final nonnegative bound is automatic. Thus globally
kappa <= [Var(f*)-V]_+ <=.5||f*-f||_(1,w).             (2)

The last factor uses zero mean of f*-f and0<=f*<=1.

Let sigma=sum_(i<j)(pi_i qij-pi_j qji)ln[(pi_i qij)/(pi_j qji)] be stationary ordinary path-reversal entropy production in nats/time. For full stationary paths on[0,tau], D(P||P^R)=sigma tau. The reversal-invariant no-exit event has the SAME forward/reverse probability bz. Conditioning and endpoint data processing give

||f*-f||_(1,w) <= sqrt(2z sigma tau/b).

Together with(2),

sigma >= 2b kappa²/(z tau).                           (3)

The baseline dissipation is bounded; pulse work is not part of sigma. W63 independently derived exactly(3), including the crucial b conditioning cost.

An additional bound follows WITHOUT conditioning. Push full paths through the binary survival event and initial state. Forward/reverse initial marginals both equalpi. The surviving-coordinate differences are pi_i(f_i-f*_i), and the nonsurviving differences are their negatives. The resulting total variation is EXACTLY b||f*-f||_(1,w). Pinsker thus gives b||f*-f||_1<=sqrt(sigma tau/2). Hence

sigma >= 8b² kappa²/tau.                             (4)

Both(3),(4) hold; retain their maximum. (4) is stronger when4bz>1. There is no hidden state count or selectivity constant in these inequalities. A poor sensor or unknown initial sampling law still defeats the interface.

## An exact odd-parity zero-path-KL countermodel

Take four states0,1,2,3 in a directed cycle i->i+1 mod4 at rate1, uniform stationarypi. Reverse labels by theta(i)=1-i mod4. It is an involution preservingpi and B={0,1}. Every allowed transition i->i+1 maps under path reversal plus theta to another allowed clockwise transition with identical rate; holding rates are identical. Thus stationary path law is EXACTLY invariant under the CORRECT theta reversal and its relative entropy is0. This is a generalized-reversal null, not an ordinary detailed-balance chain. It is a mathematical parity countermodel, not a proposed physical apparatus.

From stationary conditional B, killed survival is

z(t)=exp(-t)(1+t/2), z(2t)=exp(-2t)(1+t).

Therefore V=z(2t)-z(t)^2= -exp(-2t)t²/4<0 for EVERYt>0. Choose a state-independent fair survival pulse g=.5; D=0 while the right side of(1) is V/4<0. The basic inequality fails although the theta-reversal path-KL is zero. Consequently(1)-(4) cannot be called universal thermal-equilibrium/dissipation witnesses without acquiring the time-even/ordinary-reversal specialization. Hidden inertial or odd-parity variables are a real exclusion. Stationary off preparation alone does not repair it.

This distinction is consistent with the primary odd-variable literature: Lee–Kwon–Park, PRL110(2013)050602, https://doi.org/10.1103/PhysRevLett.110.050602 and arXiv1209.0543. Existing hidden waiting-time inference precedents include Martinez etal, https://arxiv.org/html/1809.02084v2 and Skinner–Dunkel, https://arxiv.org/abs/2105.08681 . No broad new inference principle is claimed.

## Finite confidence and acquisition

A simultaneous valid confidence box for(b,z,z2,a,c) suffices. Bound d_min as the distance of interval(c-za) from0, V_up=z2_up-z_low², v_up=max_(a in interval)a(1-a), and kappa_low=[d_min²/v_up-V_up]_+. Then(3),(4) give conservative lower bounds using b_low,z_up and a valid upper elapsedtau. Return UNKNOWN if the denominators or confidence premises are missing. Confidence cannot be inferred from an apparent stationary fit: independent preparations, or valid dependence/mixing calibration, must be acquired. Unknown mixing/rare off-state coverage can make acquisition arbitrarily expensive. False missed exits and pulse history dependence also require calibration.

An equally informed conventional model-free calculator computes the same bound, or a stronger variational confidence region; no algorithmic advantage follows. Physical validation, useful sensitivity and comparative statistical efficiency remain UNKNOWN.

Correction provenance: W15 identified the positive-part qualification in(2); V1 preserved separately. This fixes a false intermediate inequality when Var(f*)-V<0; the final bounds are unchanged.
