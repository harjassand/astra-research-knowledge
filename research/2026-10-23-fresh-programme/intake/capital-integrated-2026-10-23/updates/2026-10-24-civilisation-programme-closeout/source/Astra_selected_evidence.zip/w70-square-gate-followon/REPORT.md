# Square-to-stiffness follow-on decision

**No new consequential physical operation or practical advantage is established.** This follow-on replaces an assumed square-sensitive coating with concrete electronic/work constructions, derives a useful bounded-error guarantee, and isolates a more demanding missing material response. It preserves every byte of the 25-file frozen first packet. Novelty, complete feasibility and advantage remain separate unknowns.

## What was constructed

1. **All fixed bounded load ensembles can tolerate a uniformly approximate square gate.** With complete observation error `delta`, a deadband applied *after averaging* prevents wrong-sign gradient updates and gives approximate KKT tolerance `2delta`, plus an explicit convex-objective gap. A finite clipped update is safe for `h<2 min(l S/M)/L_F`; continuous infinitesimal growth is not required. Minimum conservative dose enlarges the tolerance. Arbitrary time-varying bounded observation errors are allowed, but zero-command material drift is not an observation error.
2. **Symmetric signed threshold integration constructs the square physically.** `x²=R²+integral 2r 1{x>r}dr` allows a shared voltage ramp and one local comparator to gate signed charge. Four input-polarity/sweep-direction cycles plus matched zero cycles cancel stationary additive offset and directional hysteresis exactly in the ideal model. For `R=1.1, M=1024`, analytic finite integration error including zero subtraction is at most `0.00472887`. Real component residuals are additional, not canceled by assertion.
3. **Capacitor work constructs a second square without a powered bridge.** A reset linear piezo port stores `alpha² epsilon²/(2C)`, which synchronized energy extraction can feed to an energy bucket or dose controller. Existing primary SECE hardware supports this physical operation. Bonding, mechanical back-action, voltage compatibility, reset, efficiency versus amplitude and actual strain calibration remain load-bearing. A same-piezo ordinary controller is an incumbent.
4. **A ready-made RMS converter is a stronger simple replacement.** Existing AD8436/AD736 circuits square before averaging and output `r=sqrt(E[x²])`. Thresholding after this operation has the desired gradient sign because `r-r*=(E[x²]-theta)/(r+r*)`. The missing arithmetic is therefore attainable with existing electronics; it is not evidence for a new material effect.

Derivations and implementation details are in `ROBUSTNESS_PROOF.md`, `WEIGHTED_GATE.md`, `WORK_ENERGY_SQUARE.md` and `PRIOR_AND_BASELINES.md`.

## Quantified scope and costs

The final illustrative **unacquired** weighted-gate qualification budget is `delta=0.0193948704`, including threshold quantization, nonstationarity, weight current, timing, scale, reset, strain encoding, averaging and mechanical-state uncertainty. At `theta=.25`, this permits stationary RMS strain roughly `[.459576,.537392]` around `.5`. The earlier `.01563` subtotal is retained in its original calculation but is superseded as a complete budget.

An unknown iid ensemble needs 29,017,316 independent samples/update for the proposed `.0005` averaging allowance in the retained `N=100,K=100,alpha=.01` example—335.85 days at one independent sample per second. The concrete manufacturing proposal instead teaches known finite force states with controlled weights. Arbitrary service-load distributions have not been acquired, and temporal sweep aliasing is a proved obstruction without a hold/rate condition.

An ordinary 4-node MSP430 scenario gives about `1.1319 microW/node` for CPU/ADC/idle before reference, output, sensing, fixture and driver. One OPA333 native integrator plus its comparator alone gives about `56.35 microW/node` typical before additional circuit costs; its illustrative frame is 8.192 seconds before settling/reset. These are component-budget calculations, not whole-board measurements. The current native proposal loses the explicitly counted computation leg; whole-system advantage remains UNKNOWN.

Both share costly strain transfer and actuation: a continuously powered 3 V, 350-ohm bridge dissipates about 509 J in 5.5 hours; Cu nominally requires 27.2089 C/mm³ at unit Faradaic efficiency. Duty cycling, load teaching, references, driver headroom, stirring, chemistry, cleaning, deposition/etching, residual-stress rest and reset must be measured for both. No complete energy, money or production-time comparison has been acquired.

Analog command retention cannot be assumed across the chemical cycle: allowed OPA333 bias alone drifts the proposed 10-microfarad memory by 54 mV/hour, about 0.058 in its normalized scale. A short growth/reteach cycle or separately charged digital memory is required at the proposed margin. `COST_AND_SCALING.md` gives the full phase ledger, current-limited parallel time bound, reusable-fixture and O(N) scaling contracts.

In the work-square scenario, nominal 90 nF and an explicitly hypothetical 40 V at the taught strain yield 72 microjoule/extraction. Assuming 50% total conversion and one event/second gives about 63 hours/mm³ at nominal 0.3 V. The cited 10 V-device ASIC is not automatically compatible with 40 V. At an illustrative 8 V the same arithmetic becomes about 1575 hours/mm³. The manufacturer's listed 3.5 g patch is much heavier than the 8.96 mg of 1 mm³ Cu, favoring a removable manufacturing fixture. Neither scenario is a measured transfer curve.

## The central remaining physical interface

The earlier assumption `K=Kcore+sum E a/l bb^T` is not acquired by successfully plating Cu or welding a gap. Loaded deposition can give layers different natural lengths; intrinsic deposition stress, aging and adhesion can also change the derivative. The concrete sequence is now **teach → store → unload → bounded signed material update → zero/rest → reteach**. Common conductive steel with separate ionic compartments removes the earlier dielectric load-transfer shell, but its leakage/cross-talk must be measured.

Actual stiffness must grow/decline with the command, stop within its stated tolerance at zero command, and have bounded useful mobility. Broad positive Faradaic-efficiency variation changes speed; wrong-sign stiffness, open-circuit corrosion, spalling or residual-stress relaxation can invalidate descent. For a nonlinear acquired spring law `k(q)`, the correct local gradient includes `k'(q)`, and global convexity survives under a stated concavity condition—not under arbitrary weld/percolation curves. `MATERIAL_INTERFACE.md` gives the general derivative and exact failure point.

The newly acquired official 2025 lattice supplement confirms topology-switching/binary spring mechanics; it does not provide continuous charge-to-stiffness or complete strain-to-dose arrays. Published historical component measurements and specs were acquired. No new physical observations or raw response arrays for the proposed chain were acquired.

## Novelty boundary and immediate science

Early primary chopper, autozero, integrating multiplication, quarter-square and explicit reset sources were acquired, including Goldberg 1950, 1970/1973 patent records and Intersil AN017. Old primary structural optimality and strain-energy adaptive-remodeling work also precede the general feedback principle. Thus no broad converter, optimization or growth-under-stress novelty is claimed. Priority for the narrow assembly/cancellation sequence remains UNKNOWN, as does any useful hardware advantage.

`NEXT_SCIENCE.md` specifies a matched electronics assay, an unloaded continuous axial composite/dose assay with zero-current controls, and only then a two-load integrated test. The decisive new measurement is **signed incremental stiffness versus dose, strain and history**, with complete same-information controller costs. `qualification_analysis.py` is runnable now and returns `NOT_ACQUIRED` on the header-only input tables. It withholds a continuum certificate even after a finite grid is supplied. The calculation scripts execute without equipment, purchases or outreach.

The nearest useful result is an evidence-bounded manufacturable optimizer, conditional on those interfaces. A civilization-level discovery, complete attained material response and measured advantage remain **NOT_ACHIEVED / NOT_ESTABLISHED**.
