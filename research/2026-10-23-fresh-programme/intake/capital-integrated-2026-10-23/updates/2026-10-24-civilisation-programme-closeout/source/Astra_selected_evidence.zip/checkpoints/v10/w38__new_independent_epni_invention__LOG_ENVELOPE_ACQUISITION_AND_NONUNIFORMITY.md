# What a finite experiment and a uniform tail expansion cannot supply

24 October 2026, W38. Separate analytic scope obstruction, not an EPnI
counterexample or a statement that the actual inequality has no uniform
threshold. It applies to the new precise-tail asymptotic method. Generic
rare-contamination/testing arguments are prior; no novelty is claimed.

## 1. One fixed energy-bounded family

Let the finite-temperature core law P0 give probability1/2 to each of
R=0 and R=1, and let the unnormalized critical tail have exactly

    f_*(r)=1/[r^2 ln r (ln ln r)^2], r>=exp(e).

Its probability mass m is in(0,1), and its FIRST moment is exactly1:
put x=ln r to integrate integral_e^infinity dx/[x(ln x)^2]=1.
For 0<epsilon<=1 define a normalized temperature law

    P_epsilon=(1-epsilon*m)P0+epsilon f_*(r)dr,
    rho_epsilon=E_(P_epsilon) theta_R.               (N1)

Every mean is bounded by3/2, since

    E_epsilon R=(1-epsilon*m)/2+epsilon<=3/2.

Every member with epsilon>0 has all higher photon moments infinite.
The member epsilon=0 has all photon moments finite. All densities use
the SAME tail start exp(e), zero density error, and envelope

    ell_epsilon(x)=epsilon/[x(ln x)^2], x>=e.

The derivative bounds of SMOOTH_INTEGRABLE_LOG_ENVELOPE_HEAT_BRIDGE.md
hold with the SAME K=14 for all positive epsilon. Thus neither a bounded
energy, a common derivative constant nor a common tail starting point
removes the issue below.

## 2. No uniform relative small-remainder threshold for this asymptotic

Fix any finite T>0. The actual heated core state is

    omega0(T)=(theta_T+theta_(T+1))/2,

whose matching thermal mean is T+1/2. This state is not theta_(T+1/2):
the vacuum probability is strictly greater than the reference's because
x->1/(x+1) is strictly convex and the two means differ. Hence its finite
relative entropy

    D0(T)=D(omega0(T)||theta_(T+1/2))>0.              (N2)

The actual heated state for(N1) is the binary mixture

    (1-epsilon*m)omega0(T)+epsilon*m omega_*(T),

where omega_* is the normalized heated tail state and has a finite FIXED
mean and entropy at this fixed T. The binary entropy upper bound and
entropy concavity squeeze its entropy to S(omega0(T)) as epsilon->0.
Its matching mean also tends to T+1/2. Therefore, using the exact thermal
relative-entropy identity,

    D_epsilon(T)->D0(T)>0.                          (N3)

For T large enough to be in the envelope formula's domain, its explicit
tail main term is epsilon A(T), where

    A(T)=T^-1{1/ln l-(ln l+gamma_E)/[l(ln l)^2]},
    l=ln T.

At each such fixed finite T, (N3) implies

    [D_epsilon(T)-epsilon A(T)]
       /[epsilon/(T l(ln l)^2)] ->+infinity
       as epsilon->0.                              (N4)

Thus the o(ell_epsilon(l)/T) remainder of that tail asymptotic is NOT
uniform over this energy-bounded, common-K, common-tail-start family.
For every proposed uniform finite T0 and every fixed relative error
tolerance, choose some finite T>=T0 and then epsilon sufficiently small
to violate the claimed relative remainder bound. For EACH fixed positive
epsilon the candidate source-first eventual expansion may still hold.

This does not establish a negative actual EPnI gap at ANY T. In particular
it cannot be cited as a disproof of a source-uniform EPnI threshold: such
a threshold might follow from a different proof, or even be zero if the
general conjecture is true. It obstructs only a source-uniform inference
from this particular leading-tail expansion and its supplied constants.

## 3. Exact finite-copy acquisition boundary

Normalize the tail state sigma_*=m^-1 integral f_*(r)theta_R dr. Then

    rho_epsilon=(1-epsilon*m)rho0+epsilon*m sigma_*.

With trace distance defined as one half of the trace norm,

    d(rho_epsilon,rho0)<=epsilon*m,
    d(rho_epsilon^tensor r,rho0^tensor r)<=r epsilon*m (N5)

for every positive integer r, by a telescoping tensor expansion. Every
fixed physical preprocessing, heating, adaptive measurement or classical
readout is a channel and cannot increase(N5). Equal-prior discrimination
success is consequently at most(1+r epsilon*m)/2. Without a positive
supplied lower bound on epsilon, no fixed finite-copy procedure can
uniformly distinguish the finite-all-moments source from every source
with the prescribed critical infinite-moment tail. The same statement
holds if the finite experiment is granted the common energy bound3/2.

For any FIXED positive epsilon this bound can become uninformative at
large r; it does not prohibit eventual learning of a fixed identifiable
source. It forbids treating precise tail membership, coefficient, or a
uniform relative asymptotic regime as a freely acquired consequence of a
fixed finite data set. No experiment, detector, entropy estimate or tail
certificate was acquired in this programme. All such source conditions
remain explicit mathematical premises in the heat theorems.
