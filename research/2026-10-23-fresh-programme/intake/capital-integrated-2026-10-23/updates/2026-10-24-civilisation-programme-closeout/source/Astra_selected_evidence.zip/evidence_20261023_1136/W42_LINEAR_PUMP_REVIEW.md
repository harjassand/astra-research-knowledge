# Independent reconstruction of direct linear-pump concentration and composition

w42, 23 October 2026. The root source was read and retained at exact SHA
c7b73357575fc1ea48db93e38e613820d8a05ab892ca2de3a5ff9bbac04df1aa,
as `ROOT_LINEAR_INVENTORY_SOURCE_AS_AUDITED.md`. I reconstructed its
operator calculation and the full optical-sector composition directly;
no verdict or code from the separately assigned concentration critic was
used. This is a complete written internal mathematical audit under the
supplied exact model, not external review, formal verification, priority
adjudication or a physical experiment.

Verdict: no blocking defect found. The direct finite-ladder estimate
composes with the previously reviewed fixed-rank sector receiver. It
does not need optical closeness to an undepleted amplifier, a pump phase,
a coherent-state replacement, actual iid optical inputs, or quantum
moment factorization. All trusted preparation/control and cost limits
below remain material. A minor monotonicity wording distinction is in
Part7.

## 1. Exact finite chain, endpoints and source labels

Let S=N+m, N>=1,m>=0. For native occupation j with total m, set
|ell;j>=K_+^ell|j,0>/sqrt[ell!(S)_ell]. Coefficient extraction from
(1-z)^(-S) gives exactly the normalized GE isometry V_(m,ell).
Every occupation difference C_i-D_i remains j_i, so distinct native
source labels have orthogonal output images. The SU(1,1) ladder is

    K_+|ell;j>=sqrt[(ell+1)(S+ell)]|ell+1;j>.

A single initial pump Fock number L contributes sqrt(L-ell), hence

    A|ell>=a_ell|ell+1>,
    a_ell^2=(L-ell)(ell+1)(S+ell), 0<=ell<L.

All j of the same m have the SAME finite scalar amplitude chain. This
is an exact statement for arbitrary within-sector vectors and density
operators, not a mixture-of-Fock-input assumption. Put a_(-1)=a_L=0.
Direct expansion gives at every ell=0,...,L, including both endpoints,

    (A^*A-AA^*)|ell>
       =[LS+(2L-2S+1)ell-3ell^2]|ell>.

In dimensionless tau=chi sqrt L t, H=i(A-A^*)/sqrt L. With
Y=ell/N,X=(A+A^*)/(N sqrt L),lambda=L/N,s=S/N, the exact Heisenberg
commutators give

    Y'=X,
    X'=p(Y)+2Y/(lambda N),
    p(y)=2s+4(1-s/lambda)y-6y^2/lambda.

All operators act on a finite ladder. There is no unbounded-operator
domain gap in these differentiations or the later square identities.

## 2. Classical comparison until time one

The ODE y'=x,x'=p(y),y(0)=x(0)=0 has first integral

    x^2=4y(s+y)(1-y/lambda).

On its first increasing branch write y=s sinh^2 r. Then
r'=sqrt[1-(s/lambda)sinh^2 r],r(0)=0. If lambda>=4s,
the first upper turning point has r=asinh sqrt(lambda/s)>=asinh2>1.
Since r'<=1, its time is at least that r value. Thus on [0,1]
y is increasing, x>=0 and 0<=y<=lambda.

If y reaches s by time1, it stays at least s thereafter up to time1.
Otherwise y<=s on this interval, so r'>=sqrt3/2. Consequently
y(1)>=s r(1)^2>=3s/4. This proves the lower value without selecting a
spurious square-root solution at the initial y=x=0 point; the smooth
second-order ODE has initial acceleration p(0)=2s>0.

On the full spectral interval z in [0,lambda],
p'(z)=4(1-s/lambda)-12z/lambda has absolute value at most9 under
s/lambda<=1/4. This also bounds the divided difference between p(Y)
and the scalar p(y), by functional calculus of the single self-adjoint Y.

## 3. The state-L2 estimate, without factorization

In the INITIAL chain vector psi_0=|ell=0>, define

    DeltaY=Y(tau)-y(tau)I, DeltaX=X(tau)-x(tau)I,
    E=<DeltaY^2+DeltaX^2>_(psi_0).

Y(0)psi_0=0 and ||X(0)psi_0||^2=S/N^2, so E(0)=s/N exactly.
Differentiate both squares as ANTICOMMUTATORS. For the DeltaY square,
2|Re<DeltaY psi_0,DeltaX psi_0>|<=E. For the polynomial term,

    ||[p(Y)-p(y)]psi_0||<=9||DeltaY psi_0||,

so its anticommutator with DeltaX contributes at most9E. The remaining
finite-N term is at most

    (4/(lambda N))||DeltaX psi_0|| ||Y psi_0||
       <=4sqrt E/N<=E+4/N^2.

Together E'<=11E+4/N^2. Integrating and loosening constants gives

    E(tau)<=exp(12tau)[s/N+4tau/N^2], 0<=tau<=1.

No X,Y commutation, product-state propagation, closed first-moment
equation or unproved Gaussian approximation is used. Cauchy--Schwarz
bounds state vectors after the exact noncommuting derivative.

## 4. Actual number probability and integer thresholds

At time1, y>=3s/4. On the spectral event ell<S/2, Y<s/2, hence
|Y-y|>s/4. Spectral Chebyshev gives

    Pr(ell<S/2)<=16E(1)/s^2
       <=16exp12[1/(sN)+4/(s^2N^2)]
       <=B_N=16exp12[1/N+4/N^2].

The actual good event is ell>=ceil(S/2). This is exactly the complement
of ell<S/2 for integer ell, including odd S. No floor or half-integer
case is lost. For every source m<=M choose the SAME integer pump
L=4(N+M) and SAME physical time t=1/(chi sqrt L); then lambda>=4s.
This proves a uniform tail bound across every allowed total m.

The numerical prefactor is very conservative and the displayed bound
can exceed one. It is an asymptotic existence certificate, not a useful
moderate-size device-error estimate. Capping a probability upper bound
at one is always understood; one cannot infer a useful finite N from a
formal O(1/N) notation alone.

## 5. Compose the actual optical sector channel

The shared-pump unitary commutes with
Gamma_C(U) tensor Gamma_D(conjugate U), because K_+ is invariant. Its
isometry from A with B vacuum therefore intertwines Gamma_A(U), with
the pump factor untouched. This holds before tracing the pump and for
arbitrary source superpositions. The fresh matched passive twirl can be
performed after receipt of both complete optical output groups.

On the capped input, average the final bounded Bell-failure effect over
that independent passive ensemble. The commutant proof yields

    F=sum_(m=0)^M f_m Pi_m.

Evaluate f_m on mu_m=Pi_m/d_m. Conditional on observed added number ell,
the optical state is EXACTLY V_(m,ell)mu_m V_(m,ell)^*. The pump factor
is |L-ell>; the flat joint/marginal spectra used by GE4 are unchanged.
Thus the already fixed reference-sector decoder has a scalar
q_code(m,ell) in [0,1], including low-number/invalid defaults, and

    f_m=sum_(ell=0)^L |z_(m),ell|^2 q_code(m,ell).

For ell>=S/2 and N>=2,

    d_(m+ell)/d_m
      =product_(j=1)^(N-1)(1+ell/(m+j))>=(3/2)^(N-1).

For any fixed r<ln(3/2), eventually
J_N=2^floor(Nr/ln2)<=d_(m+ell)/d_m<=d_ell. The exact completed cyclic
instrument and fixed Uhlmann decoder apply on every such good sector,
giving

    q_code(m,ell)<=sqrt(3/2)
                            exp[-N(ln(3/2)-r)/2].

Every other sector outputs the same target-rank logical product default.
Therefore the whole receiver obeys the OPERATOR bound

    0<=F<=b_N I_cap,
    b_N=min{1,B_N+sqrt(3/2)exp[-N(ln(3/2)-r)/2]}.       (LA1)

No actual common optical gain is required for this step. The number-
conditioned maps and dimension ratio are exact properties of this
trilinear ladder, not an assumption that the full optical channel is a
quantum-limited amplifier. An m-dependent classical effective gain does
not enter the decoder or undermine LA1.

For arbitrary alpha and every source extension, the marginal Bell
probability is Tr(F alpha). Cross-m coherences and correlations with an
unknown actual purifier cannot change it. The canonical reference used
to design a decoder is not identified with that purifier. Apply a
rank-one Bell projection to the ACTUAL entire output to obtain

    d(Omega,Phi_(J_N) tensor Omega_actual,residual)
                                             <=min{1,2sqrt(b_N)}. (LA2)

This residual includes the pump, actual old source, all coherent
number/seed pointers and receiver environments. Its proof does not
require their closeness to an independently selected ideal dilation.
The separately credited w50 refinement sqrt(b_N)+b_N is available on
the identical state, but is not needed for the composition conclusion.

## 6. Finite readouts, full resources and a stronger same-pump baseline

Use the finite C total-number PVM for 0,...,M+L plus one overflow,
and D for 0,...,L plus one overflow. On the exact model no overflow
occurs, since the pump has at most L photons and number difference is
m in [0,M]. Any impossible record has the same fixed-rank default.
There are O(N^2) possible coded (m,ell) sectors at fixed E. Sector
dimensions, passive ensemble, POVM outcomes, fixed decoder search and
precision can still be exponential or worse. No efficient compiler is
being inferred from the explicit finite interaction Hamiltonian.

The initial pump inventory and its charged Gibbs D and D_max are

    L=4(N+M),
    kappa_P=2beta hbar omega L+ln Z_P=O(N).

It is a supplied pure Fock state with a shared equal mode coupling.
Independent Fock pumps per pair do not have this guarantee: for optical
vacuum their which-pair pump records make the available optical state
separable. Root's linear proof removes the superquadratic inventory
needed by my full number-chain Duhamel comparison; it does not remove
this shared-mode control premise, source cap/vacuum factory, decoder,
Fock-state acquisition or pump reset/correlation accounting.

Mean active energy is also finite and O(N), directly by hard cap
m+2ell<=M+2L, or by TP's exact differential mean bound
E ell<=S sinh^2(1). The final pump is mixed and correlated, not an
unaccounted returned battery. Full initial stores/program/apparatus and
any consumed purity are charged; no D_max marginal-return chain rule
is used. Original rejected source energy may remain unbounded and is
not supplied a finite disposal cost by these active bounds.

The SAME L, shared coupling, time, number controls and initial pump
provide a stronger vacuum benchmark. With m=0, conditional optics are
exactly Phi_(d_ell). The same tail guarantees ell>=N/2 with probability
at least1-B_N. For N large, Stirling gives

    ln d_(ceil(N/2))/N -> g(1/2),
    g(1/2)=ln(3/2)+(1/2)ln3>ln(3/2).

Every fixed rate below g(1/2) follows by exact fixed-rank maximally
entangled conversion on sufficiently large d_ell, with a product default
otherwise. All pump and actual residual records stay charged. Thus the
linear-pump composition proves no matched yield advantage. A tighter
analysis of the fluid trajectory could strengthen this baseline further;
g(1/2) already suffices to establish the comparison boundary.

## 7. Clarification and exact status

The source's phrase that the receiver error effect "decreases with ell"
needs the following reading: the proved UPPER bound
min(1,sqrt[J_N d_m/d_(m+ell)]) decreases with ell. Actual failures of
independently chosen fixed codes need not be monotone. LA1 uses only
the uniform upper bound on the good event, so this wording is not a
blocking mathematical defect.

Generic SU(1,1) ladders, trilinear quantized-pump modeling, mean-field/
semiclassical comparison, Gronwall and number-sector decoding precede
this work. The closed two-observable proof is a direct evaluated finite-
operator estimate. No exact historical priority determination for the
whole source-uniform optical composition has been made. A new peer
agreement is evidence of this internal reconstruction only, not a
mathematical consensus theorem or external certificate.

No blocker was found in the complete scoped proof and LA1-LA2 interface.
Efficient large-code acquisition, physically supplied equal couplings,
Fock-state preparation, reset, precision, implementation, net advantage,
external scrutiny and mission success remain UNKNOWN or NOT ESTABLISHED.
