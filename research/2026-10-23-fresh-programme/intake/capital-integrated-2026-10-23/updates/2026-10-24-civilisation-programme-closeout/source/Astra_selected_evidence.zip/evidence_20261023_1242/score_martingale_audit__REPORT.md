# Frozen independent physical-score review

W30, 23 October 2026. Subject: W56's
`FULL_SCORE_CAUSAL_MARTINGALE_GAUSSIAN_BOUND.txt`, SHA256
`646fce50b948aab2d76cb0ca6a60e5728a8b35e587cc4ceb1ef074b28c70ae3b`.

The guarded full-score martingale, its weighted Rademacher/Gaussian Laplace
bound and its separate all-even-moment argument reconstruct positively.
No blocking defect was found in the exact physical root/telescoping,
fresh-input support, norm contraction, conditional trace, weighted
Golden–Thompson, mixed-word Hölder or advertised source-class entropy steps.
This is an internal source-specific proof review, not an unrestricted
capacity converse, external/formal verification or physical experiment.

`INDEPENDENT_PROOF.md` derives the result from the actual original
push/pop/signed-root interaction. The global initial-depth guard `H>=k`
annihilates every incoming root correction. The same arbitrary normalized
analytical bath density is used for every prefix. Total-Q pinching preserves
the fresh charge-offdiagonal current while making the identical product
charge reference central in the relevant algebra. Its weighted trace is
therefore genuinely tracial. The fresh conditional expectation gives the
usual bounded-difference recursion without pretending that increments or
the evolving bath are independent.

The fourth moment has a separate valid proof; it is not obtained by comparing
Taylor coefficients in a loose Laplace bound. The general even-word proof
also checks: odd CURRENT/maximal-increment counts vanish, while all remaining
mixed words are bounded by weighted tracial Hölder. This proves
`Tr omega K^(2m) <= (2m-1)!! (kab)^m`, including the fourth bound
`(3k^2-2k)(ab)^2 <=3(kab)^2`. It does not assert operator fourth bounds,
vanishing global odd moments, arbitrary convex-order domination or the
same bound for every nonproduct/affine charge weight.

Independent original-interaction diagnostics were built without producer
code, history coefficients or result imports. At depth three, 54 settings
over two rational Pythagorean couplings, three coherent complex word states,
three prefixes and three product references pass exact Q(i) checks of all
coherent-history norms, fresh charge support, total-charge preservation,
entrywise conditional centering, norm PSD via Hermitian LDL and moments
2/4/6. Another 324 signed-t floating Laplace checks pass. These are finite
controls; the universal derivation is in the proof, not extrapolated from
the matrices or floating spectra.

Two exact physical witnesses make the scope falsifiable:

* Without the guard, one call from vacuum at `a=16/25,b=9/25` gives centered
  score `diag(16/25,0,0)` and weighted mean `8/25` at `p=1/2`. The positive
  root term is indispensable. The current sum alone remains centered, but
  it is not this uncorrected full score outside the guard.
* With `H=k=3`, the same coupling and initial color state
  `|+> tensor |-> tensor |+i>`, the exact third moment at `p=1/2` is
  `359997696/152587890625`, which is nonzero. Thus a shorthand claim that
  every odd mixed word/global odd moment vanishes would be false. The
  frozen proof correctly uses only maximal-increment parity and survives.

The advertised Gibbs entropy consequence M7/M8 is valid for the specified
full uniform inward-source class. A separate new corollary in
`CHARGE_TWIRL_EXTENSION.md` removes the charge-preserving source restriction:
exact conservation gives `D_b(pin_Q rho)=pin_L D_b(rho)`, which preserves
the full bulk order and raises source entropy. W56 independently reconstructed
that extension positively. Arbitrary good encoders are not thereby shown
to satisfy the full uniform inward order. There is still no unrestricted
capacity bridge.

The generic concentration step has an established strong baseline:
noncommutative bounded-difference Azuma uses the same secant/conditional/
Golden–Thompson iteration, as checked in the primary Sadeghi–Moslehian
paper, arXiv:1409.0342v1, Theorem 2.1 and proof. Tropp's matrix Laplace
framework is also established. The candidate mathematical contribution is
the physical causal-score identification and its source-class application,
not invention of a generic martingale inequality. Priority remains unknown.

No analytical bath contraction is granted as a physical gate or new bath
control. Source preparation, actual device calls, calibration, precision,
encoding/recovery and all earlier resource boundaries remain separate.
The new joint-critical-reference/capacity proposal, W56's subsequent
constant-gamma refinement, sharper factory proposals and every earlier
V4/pump/compiler/pure-type packet are excluded from this frozen verdict.

Next decisive criticism should target the actual new converse bridge on
its own frozen source, not infer one from this source-score pass. Historical
priority, external/formal validation, physical usefulness and practical
advantage remain unknown / not established. Mission remains not achieved.
