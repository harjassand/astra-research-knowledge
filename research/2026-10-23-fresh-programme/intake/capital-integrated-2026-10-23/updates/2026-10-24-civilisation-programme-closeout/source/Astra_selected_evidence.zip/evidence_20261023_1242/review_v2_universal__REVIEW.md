# Fresh review: rational-pair V2 source through the universal code

W66, 23 October 2026. Reviewed in full W67's separate integrated proof
`high_design_audit/v2_universal_integration/CONDITIONAL_INTEGRATION.md`,
SHA256 `1e404991b13024ab3f13f18f195107191e6c50f51ef747f075cc69961102a2d5`,
finite specification
`f45a455c981f1b87dc1f3550d1dcf74480f076d096953c1b6f70a3ee9294fd81`,
producer, charge/root guard sidecar, horizon table, and exact count data
`f4364af54634fdea6730ad53428551b795958308114f055467b367e3cee689aa`.
I verified the proof/data bindings. All OLD-source rows remain preserved.

**No blocking defect found in this complete source-substitution and
finite/native interface, under the explicitly inherited ideal-model
theorems and fixed coherent gate/compiler premises.** This is a fresh
review of W67's integration and counts, not a claim of independent
authorship or another independent creation of my own earlier source.
The rational-pair V2 source eeb8a255... was derived by W66 and already
separately audited by W67 at d059f146... . This is not W56's differently
named clipped V2 source. Generic coding/design/recovery operations remain
established prior and retain their own source-bound receipts.

## 1. Source, charge and exact physical response

At public b0, the spectrum is
`(1-u)/4`, four `(1+u)/16`, two `(1-x)/8`, two `(1+x)/8`, with
`u=b0^2/32,x=b0/6`. I freshly recomputed its normalization, positivity,
probability bounds[1/16,1/4], weighted chi-square
`(u^2+x^2)/2`, and the rational entropy bound. The two-sided scalar
Taylor remainder and `ln2>693/1000` give

    S>=3+u/2-chi2/[2(5999/6000)(693/1000)]
       >=3+b0^2/179.

No numerical spectral fit or Gibbs root is used. The exact fixed
physical eigenbasis and its invalid-port-safe native circuit are the
same as in the already reviewed pure type construction.

The earlier all-b coherent-word identities are linear in the input
source: `D_b(sigma)=0`, `D_b(sigma A)=(1-b)I`,
`D_b(sigma H)=(1-b)bI/8`. Thus for THIS fixed source and any actual
b in[b0,b1],

    D_b(rho0)=(1-b)(u-xb/4)I
       <=-(1-b1)b0^2 I/96.

Multiplying the negative coefficient by `1-b>=1-b1` has the correct
inequality direction. Neither source nor sender depends on unknown b.
The prior coherent-response proof includes bath color/word coherences
in both static seed sectors; it is not a radial or scalar bath model.

The actual source charge is not its diagonal reference mean. With
ordered charges `[0,2,2,2,2,1,1,1,1]`, I independently obtain

    E Q=1+u/2, Var Q=1/2-u^2/4.

The type's exact integer charge is the same charge-weighted sum of
its rounded counts. I checked it for every new record. This prevents
silently assigning the reference charge to the changed source/type.

## 2. Complete root-retaining tail, without an iid bath replacement

The source commutes with total pair charge. Homogeneous displacement
effects are positive, sum to I, and have displacements in[-2,2]. Hence
their second-moment effect is at most4I. At depth>=2 the exact uniform
drift is at most-kappa I, with `kappa=(1-b1)b0^2/96`. At
`t=kappa/12`, `2t<=1`, exponential Taylor with e<3 gives

    M_bulk(t)<=I-kappa t+6t^2
               =(1-kappa t/2)I=:lambda I.

Charge covariance makes the dual exponential effect block diagonal
in INITIAL bath depth, so this is a full operator bulk bound, not a
statement only for diagonal bath states. Initial depths0,1 reach at
most3 during the two-call block. Positivity/TP and the known finite
propagation therefore bound that low block by exp(3t)I; the looser
exp(4t) term in the owner proof is safe. Adding the positive
lambda exp(tL) there yields exactly its complete inequality

    Phi* exp(tL)<=lambda exp(tL)+exp(4t)P_(L<2).

Every source parameter satisfies0<lambda<1. Since4t<=2 and e^2<9,
iteration from word vacuum yields

    E exp(tL_m)<=1+2exp(4t)/(kappa t)
                 <=1+18/(kappa t)=1+C.

The low-depth/root term is retained, not omitted. This derivation does
not trace out a memory between blocks or assume iid bath increments.

The parent domination factor is still4(m+1)^9. Its product-source tail
is consequently at most
`4(m+1)^9(1+C)exp(-tH)`. With the chosen H, `m+1<=2^(J+1)`,
`1+C<=2^ceilLog2(1+C)` and e>2 make it at mostq=2^-s exactly.
The new larger drift changes the H numbers; it is not a reuse of an
old source's unverified cutoff.

Terminal zero counts have mean pop bound at least2H+8s under the
worst public endpoint, giving their at-mostq descent failure. Their
outputs are all retained. The initial prefix has its separately paid
normal-tail/Chernoff bound; it does not erase the seed or its arbitrary
reference correlations. The common receiver handles both sectors.
The finite tau_pi row is not a uniform tail promise for every normal
initializer.

## 3. Pure type, common code and full-TP/native composition

The pure type theorem used only nine eigenlabels with probabilities in
[1/16,1/4], a known charge eigenbasis and rational counts. All remain
true. I freshly round the first eight counts and the last remainder,
check positivity and their sum, and compute the exact type charge.
The same mode-probability/rank/18-bit entropy argument gives

    ell>=m(3+g0)-9log2(m+1)-18,
    C(I_D/D)C*<=4(m+1)^9 rho0^m.

D must still be the largest power of two in the ACTUALLY computed
type rank. The finite ledger obtains valid width bounds; it does not
claim to have constructed that enormous rank, seed or circuit. Full
domain rank/unrank, exact physical basis and all their gates are paid.
No source-copy factory, mixed gauge, unknown eigenbasis or backwards
physical access has been introduced.

The actual body/flush Fourier polynomial, row normalization, coefficient
norm, centered cross-products and common-KL/no-grid argument require
these source tail/width interfaces, not the previous numerical source
coefficients. Source substitution is therefore valid. Moment order2h
and its large diamond precision factor are retained. Pauli randomness
and finite dyadic angles are sampled offline with their exact paid seed;
the implemented native ensemble is NOT asserted to retain that design
moment accuracy. The uniform per-program full-circuit telescope covers
every one of Q+1 shared encoder uses and its inverse.

The finite bounded sign/DFT coefficient algorithm, scale-before-round
clarification and stable Haah walk still yield a full unitary polar
inverse on the high subspace, with every low/flag branch in its TP
completion. Its cutoff, gap, label preparations and relative phases
are recomputed at the new m. No Gram data, actual gain, physical bath
projection, inverse-device oracle or successful postselection is used.
The xi budget includes signal leakage, native design, digital row,
known controls and signal phases. All exact source/type charge facts
survive native implementation because the arbitrary parent native
design is followed by the exact physical type circuit.

## 4. Fresh complete exact finite reconstruction

Own `check_v2_independent.py` imports no peer/producer code. It starts
from the rational band/source and searches J from24 afresh, checks all
source, root/Taylor, actual parent width, Gaussian, moment/design,
tail/flush/prefix, rate/error, coefficient/alias, shared encoder/native
precision and helper guards, then compares EVERY named numerical/data
field with the supplied six cases. It excludes only the informational
`counts_scope` sentence, not a mathematical parameter.

All360 recorded values match. All60 horizon-table fields also match
the independent reconstruction and the preserved OLD-source ledger.
Additional exact source charge/variance/type-charge, positive rational
entropy margins and earlier failed dyadic-policy guards are retained
in the own raw output. No floating logarithm or peer function is used.

Own `V2_UNIVERSAL_RECONSTRUCTION.json`, SHA256
`068455c09bbe065c0b502aa0ed1ad97542c72f80fafc2c6784816f3adb7ff06d`.

| public beta0 | m | controlled Clifford count bits | OLD/new prescribed body calls |
|---|---:|---:|---:|
|1/64|2^79|454|4|
|1/128|2^87|494|8|
|1/256|2^95|534|8|
|1/512|2^103|574|8|
|1/1024|2^111|614|8|
|1/2048|2^120|659|4|

The stronger certified quartic excess is exactly384/179 times the old
floor, `rate>=3/2+beta0^4/716`, with all actual initial/body/terminal
ports counted. These are the first passing choices of the stated dyadic
policy, not optimal-resource or measured-performance comparisons.

At beta0=1/512, total forward calls are
20282409603651915997019378707783, including1872 initial and
245573072127419895 terminal zeros. The574-bit controlled Clifford
term is only one named primitive bound; native rotations, type,
digital helpers and phase work retain their additional explicit
compiler constants/log factors. Even this reduced sufficient resource
choice is vastly beyond execution.

## 5. Conclusion and limits

The complete ideal-model universal-code substitution has no blocking
defect found at this scope. It retains whole quantum
`O(m^5 z^-1 polylog(m/z))`, phase preprocessing
`O(m^3 z^-3 polylog(m/z))`, explicit seed storage/output and the actual
circuit emission cost. The cubic statement is PHASE work, not all
classical construction; proxies are not numerical native counts.
The old matched compiler-only table remains unchanged. The separately
reviewed short BHH comparator may also use all the same ordinary
factoring/sign ingredients; no algorithmic advantage or optimality
over an equally informed incumbent is established.

The exact known interaction family, one fixed unknown gain in a public
band, static sectors, input/bath independence and coherent native gate
model remain supplied. Actual coarse-band acquisition, fault-tolerant
layout, time-varying imperfections, energy, clocks, laboratory coherence,
useful performance and external proof/priority validation remain open.
No huge type rank, individual successful seed, coefficient/phase array,
complete native circuit or physical experiment was acquired.

Internal integration review: SCOPED_NO_BLOCKER_FOUND. Generic ingredients
PRIOR; device-composition priority UNKNOWN; practical advantage
NOT_ESTABLISHED; physical validation NOT_PERFORMED; mission NOT_ACHIEVED.
