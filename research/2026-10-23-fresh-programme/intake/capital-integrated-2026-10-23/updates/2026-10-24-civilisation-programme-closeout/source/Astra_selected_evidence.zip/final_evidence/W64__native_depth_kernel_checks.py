"""Separate native two-seed quantum implementation versus depth/score kernel.

No producer/peer code imports. Sparse physical words have no cutoff. All input
word columns and all final native output registers are kept for POVM checks.
"""
from pathlib import Path
import itertools, math, json, time, datetime, hashlib
import numpy as np
ROOT=Path(__file__).parent

def accumulate(out,key,vec):
    if key in out: out[key]+=vec
    else: out[key]=vec.copy()

def physical(state,t,beta):
    out={};al=math.sqrt(1-beta*beta)
    for (s,w,ports),v in state.items():
        accumulate(out,(s,w,ports),1j*beta*v)
        p=list(ports);j=p[t]
        if j: p[t]=0;ss=s;ww=(j,)+w
        elif w: p[t]=w[0];ss=s;ww=w[1:]
        else: ss=1-s;ww=w
        accumulate(out,(ss,ww,tuple(p)),al*v)
    return out

def rotate_one(state,t):
    # Coordinates ordered (01,10); columns are +/- eigenvectors of Pauli Y.
    rot=np.array([[1,-1j],[1,1j]],complex)/math.sqrt(2)
    out={}
    for (s,w,ports),v in state.items():
        pair=ports[t:t+2]
        if pair not in [(0,1),(1,0)]: accumulate(out,(s,w,ports),v);continue
        j=0 if pair==(0,1) else 1
        for k,pattern in enumerate([(0,1),(1,0)]):
            p=list(ports);p[t:t+2]=pattern
            accumulate(out,(s,w,tuple(p)),rot[k,j]*v)
    return out

def classical(h0,r,beta,x):
    a=1-beta*beta;b=beta*beta;m=2*a**1.5*beta
    state={(0,h0):1.}
    for _ in range(r):
        out={}
        def add(q,h,p):out[(q,h)]=out.get((q,h),0.)+p
        for (q,h),v in state.items():
            if not h:
                for y in [-1,1]:add(q+y,0,v*(1-a*b+y*x*m)/2)
                add(q,0,v*a*b*a);add(q,1,v*a*b*b)
            else:
                for y in [-1,1]:
                    p=v*(a*a+b*b)/2
                    add(q+y,h-1,p*a);add(q+y,h,p*b)
                add(q,h,v*a*b*a);add(q,h+1,v*a*b*b)
                if h==1:add(q,0,v*a*b)
                else:add(q,h-2,v*a*b*a);add(q,h-1,v*a*b*b)
        state=out
    return state

def one(H,r,beta):
    ws=[w for h in range(H+1) for w in itertools.product((1,2),repeat=h)]
    n=len(ws);ports=(1,0,0)*r;state={}
    for s in [0,1]:
        for k,w in enumerate(ws):
            v=np.zeros(2*n,complex);v[s*n+k]=1
            state[(s,w,ports)]=v
    for t in range(3*r):state=physical(state,t,beta)
    for t in range(0,3*r,3):state=rotate_one(state,t)
    cases=[];raw={}
    for x in [-1,1]:
        effects={}
        for (s,w,p),v in state.items():
            score=sum(1 if p[t:t+2]==(0,1) else -1 if p[t:t+2]==(1,0) else 0 for t in range(0,3*r,3))
            key=(score,len(w));col=(v[:n]+x*v[n:])/math.sqrt(2)
            if key not in effects:effects[key]=np.zeros((n,n),complex)
            effects[key]+=np.outer(col.conj(),col)
        expected=[classical(len(w),r,beta,x) for w in ws]
        allkeys=set(effects)
        for p in expected:allkeys.update(p)
        maxerr=0.;offdiag=0.;isom=np.zeros((n,n),complex)
        for key in allkeys:
            E=effects.get(key,np.zeros((n,n),complex));isom+=E
            diagonal=np.array([p.get(key,0.) for p in expected])
            maxerr=max(maxerr,float(np.max(np.abs(E-np.diag(diagonal)))))
            offdiag=max(offdiag,float(np.max(np.abs(E-np.diag(np.diag(E))))))
        wrong=sum((E for (score,h),E in effects.items() if (score>=0 if x==-1 else score<0)),np.zeros((n,n),complex))
        eta=float(np.linalg.eigvalsh((wrong+wrong.conj().T)/2)[-1])
        expectedeta=max(sum(p for (score,h),p in dist.items() if (score>=0 if x==-1 else score<0)) for dist in expected)
        iso=float(np.max(np.abs(isom-np.eye(n))))
        assert maxerr<3e-13 and offdiag<3e-13 and iso<3e-13 and abs(eta-expectedeta)<3e-13
        cases.append(dict(H=H,r=r,beta=beta,sector=x,input_word_columns=n,joint_score_finaldepth_effect_max_error=maxerr,
            effect_offdiagonal_max=offdiag,completeness_error=iso,wrong_effect_norm=eta,depth_kernel_worst_error=expectedeta))
        if H==2 and r==3 and beta==.5:
            raw['wrong_effect_sector_'+str(x)]=wrong
    return cases,raw

def main():
    start=time.perf_counter();rows=[];raw={}
    for H in [0,1,2]:
        for r in [1,2,3]:
            for beta in [.2,.5,.9]:
                rr,extra=one(H,r,beta);rows.extend(rr);raw.update(extra)
    exact=json.loads((ROOT/'EXACT_THREE_CALL_CLASSIFIER_CERTIFICATE.json').read_text())
    comparisons=[]
    for row in rows:
        if row['beta']!=.5 or row['H']>1:continue
        selected=[v for v in exact['rows'] if v['r']==row['r'] and v['initial_depth']<=row['H']]
        key='eta_plus' if row['sector']==1 else 'eta_minus_by_sign_mirror'
        probability=max((int(v[key]['A'])+int(v[key]['B'])*math.sqrt(3))/(2**v[key]['denominator_power_of_2']) for v in selected)
        defect=abs(row['wrong_effect_norm']-probability);assert defect<3e-13
        comparisons.append(dict(H=row['H'],r=row['r'],sector=row['sector'],native_eta=row['wrong_effect_norm'],exact_field_eta_float_for_diagnostic=probability,defect=defect))
    result=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='FINITE_NATIVE_QUANTUM_KERNEL_VALIDATION_NOT_INDEPENDENT_REVIEW',
        input_fixtures=27,sector_checks=len(rows),exact_field_crosschecks=len(comparisons),rows=rows,exact_field_comparisons=comparisons,
        max_joint_effect_error=max(r['joint_score_finaldepth_effect_max_error'] for r in rows),max_offdiagonal=max(r['effect_offdiagonal_max'] for r in rows),
        max_completeness_error=max(r['completeness_error'] for r in rows),max_exact_field_defect=max(r['defect'] for r in comparisons),
        native_calls_or_source_calls=0,peer_code_or_data_imports=0,own_producer_code_imports=0,physical_word_cutoff='NONE: sparse reachable native words',
        scope='Classical full joint score/depth law compared against every all-column quantum POVM effect; r<=3 only. High-r certificate uses the proved kernel, not a native giant-statevector run.',
        wall_seconds=time.perf_counter()-start)
    (ROOT/'NATIVE_DEPTH_KERNEL_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
    np.savez_compressed(ROOT/'native_depth_kernel_raw.npz',**raw)
    print(json.dumps({k:v for k,v in result.items() if k not in ['rows','exact_field_comparisons']},indent=2))

if __name__=='__main__':main()
