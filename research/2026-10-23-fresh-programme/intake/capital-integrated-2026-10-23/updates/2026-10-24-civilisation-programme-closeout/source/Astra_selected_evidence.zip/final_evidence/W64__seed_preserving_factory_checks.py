"""Full sparse seed-preserving uploader fixtures, all unknown source columns.

Acquired SMALL classifiers (not asymptotically accurate) are run literally in
selected beta=.5 cases using11 native forward calls per inverse. Ideal-oracle
cases are explicitly structural references and do not supply the claimed oracle.
"""
from pathlib import Path
import importlib.util,math,time,json,datetime
import numpy as np
ROOT=Path(__file__).parent
sp=importlib.util.spec_from_file_location('own_coherent_sector',ROOT/'coherent_sector_checks.py')
sec=importlib.util.module_from_spec(sp);sp.loader.exec_module(sec)

def local_opposite(state,t,beta,H):
    ws=sec.words(H);ix={w:i for i,w in enumerate(ws)};al=math.sqrt(1-beta*beta);out={}
    for (seed,ew,p,lab),v in state.items():
        label=lab&1;w=ws[lab>>1];port=p[t];po=list(p);co=1
        sec.add(out,(seed,ew,p,lab),-1j*beta*v)
        if port and len(w)<H:po[t]=0;wo=(port,)+w
        elif port:wo=w
        elif w:po[t]=w[0];wo=w[1:]
        else:wo=w;co=1 if label==0 else -1
        sec.add(out,(seed,ew,tuple(po),(ix[wo]<<1)|label),al*co*v)
    return out

def ideal_Xor(state):
    out={}
    for (s,w,p,lab),v in state.items():
        for so,lo,co in [(s,lab,.5),(1-s,lab,.5),(s,lab^1,.5),(1-s,lab^1,-.5)]:
            sec.add(out,(so,w,p,lo),co*v)
    return out

def subset_oracle(state,indices,pairs,beta,literal):
    out=state
    for t in indices:out=sec.native_gate(out,t,beta)
    out=sec.B_gate(out,pairs)
    for t in reversed(indices):
        if literal:
            assert beta==.5
            for _ in range(11):out=sec.native_gate(out,t,beta)
        else:out=sec.native_gate(out,t,beta,True)
    return out

def new_initial(H,program):
    ws=sec.words(H);columns=[(s,w) for s in [0,1] for w in ws];d=len(columns)
    state={};target={}
    for k,(s,w) in enumerate(columns):
        v=np.zeros(d,complex);v[k]=1
        state[(s,(),program,ws.index(w)<<1)]=v
        target[(s,w,program,0)]=v.copy()
    return state,target,columns

def actual_factory(H,T,r,s,beta,literal=False):
    _,_,prog0,pairs0=sec.make(0,0,r,s)
    _,_,progh,pairsh=sec.make(H,2,r,s)
    L0=len(prog0);LH=len(progh);offset=L0+T
    program=prog0+(0,)*T+progh
    state,target,cols=new_initial(H,program);d=len(cols)
    state=subset_oracle(state,list(range(L0)),pairs0,beta,literal)
    for t in range(L0,L0+T):state=local_opposite(state,t,beta,H)
    for t in reversed(range(L0,L0+T)):state=sec.native_gate(state,t,beta)
    state=subset_oracle(state,list(range(offset,offset+LH)),[offset+t for t in pairsh],beta,literal)
    error=sec.diff_norm(state,target,d)
    iso=float(np.linalg.norm(sec.gram(state,d)-np.eye(d)))
    # The two ACTUALLY ACQUIRED oracle errors, uniformly over all label/bath inputs.
    e0,_,_=sec.one(0,0,r,s,beta,literal=False)
    eh,_,_=sec.one(H,2,r,s,beta,literal=False)
    a=1-beta*beta;b=beta*beta
    tau=sum(math.comb(T,k)*a**k*b**(T-k) for k in range(min(H,T+1)))
    allowance=e0['complete_oracle_operator_error']+eh['complete_oracle_operator_error']+math.sqrt(2*tau)
    assert error<=allowance+3e-10 and iso<3e-10
    return dict(H=H,T=T,r=r,s=s,beta=beta,input_columns=d,
        complete_seed_source_reference_operator_error=error,
        independent_composition_operator_bound=allowance,isometry_error=iso,
        first_oracle_error=e0['complete_oracle_operator_error'],second_oracle_error=eh['complete_oracle_operator_error'],
        actual_literal_forward_queries=12*(L0+LH)+T if literal else 0,
        actual_literal_quantum_returns=12*(L0+LH) if literal else 0,
        mathematical_inverse_reference=not literal,reachable_keys=len(state)),state,target

def ideal_oracle_reference(H,T,beta,skip=False):
    # This reference tests controlled LOCAL simulator and seed phase exactly.
    # It is NOT claimed as the actual acquisition primitive.
    program=(0,)*T;state,target,cols=new_initial(H,program);d=len(cols)
    state=ideal_Xor(state)
    for t in range(T):state=local_opposite(state,t,beta,H)
    for t in reversed(range(T)):state=sec.native_gate(state,t,beta)
    if not skip:state=ideal_Xor(state)
    error=sec.diff_norm(state,target,d)
    a=1-beta*beta;b=beta*beta
    tau=sum(math.comb(T,k)*a**k*b**(T-k) for k in range(min(H,T+1)))
    if not skip:assert error<=math.sqrt(2*tau)+3e-12
    # Source seed Z=0, input word=(empty+1)/sqrt2.
    inputv=np.zeros(d,complex)
    inputv[cols.index((0,()))]=1/math.sqrt(2);inputv[cols.index((0,(1,)))]=1/math.sqrt(2)
    groups={}
    for (seed,w,p,lab),v in state.items():
        key=(w,p,lab)
        if key not in groups:groups[key]=np.zeros(2,complex)
        groups[key][seed]+=v@inputv
    rho=np.zeros((2,2),complex)
    for v in groups.values():rho+=np.outer(v,v.conj())
    targetseed=np.diag([1,0]);seederr=float(np.sum(np.abs(np.linalg.eigvalsh(rho-targetseed))))
    if skip:assert abs(seederr-1)<3e-12
    return dict(H=H,T=T,beta=beta,skipped_uncompute=skip,
                ideal_oracle_reference_only=True,full_operator_error=error,
                word_upload_operator_bound=math.sqrt(2*tau),seed_marginal_trace_error=seederr)

def main():
    start=time.perf_counter();rows=[];raw={}
    for beta in [.2,.5,.9]:
        for T,r,s in [(1,1,0),(2,1,1),(2,2,1)]:
            row,Q,S=actual_factory(1,T,r,s,beta);rows.append(row)
    literal=[]
    for T,r,s in [(1,1,0),(2,1,1),(2,2,1)]:
        row,Q,S=actual_factory(1,T,r,s,.5,True);literal.append(row)
        if (T,r,s)==(2,1,1):
            keys=sorted(Q.keys()|S.keys(),key=repr);d=row['input_columns']
            raw['factory_keys']=np.array([repr(k) for k in keys])
            raw['literal_factory']=np.stack([Q.get(k,np.zeros(d)) for k in keys])
            raw['whole_seed_target']=np.stack([S.get(k,np.zeros(d)) for k in keys])
    references=[]
    for beta in [.2,.5,.9]:
        references.append(ideal_oracle_reference(1,6,beta))
        references.append(ideal_oracle_reference(1,6,beta,True))
    result=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        status='FINITE_COMPLETE_SEED_PRESERVING_CIRCUIT_CHECKS_NOT_HIGH_ACCURACY_OR_ADVANTAGE',
        mathematical_inverse_reference_cases=len(rows),literal_native_factory_cases=len(literal),
        ideal_oracle_composition_references=len(references),
        max_literal_isometry_error=max(r['isometry_error'] for r in literal),
        source_or_physical_calls=0,peer_code_or_data_imports=0,packages_installed=0,
        scope='Small acquired classifiers have large error; proof supplies asymptotic amplification. Literal native cases retain every amplitude/ancilla/source column.',
        reference=rows,literal=literal,ideal_oracle_control_references=references,
        wall_seconds=time.perf_counter()-start)
    (ROOT/'SEED_FACTORY_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
    np.savez_compressed(ROOT/'seed_factory_raw.npz',**raw)
    print(json.dumps({k:v for k,v in result.items() if k not in ['reference','literal']},indent=2))

if __name__=='__main__':main()
