# A Plucker repair of a single-pair well barrier, and its exact limit

23 October2026. Internal proof; fresh criticism pending. No priority,
weak-closure, general finite-termination or Morrey claim is made.

This packet identifies an explicit quadratic barrier for a canonical
FIVE-output pair-mean quotient, proves why every TWO-output projection
escapes that particular barrier, and gives a positive two-output law
where the resulting compatible-pair contact still does not allow a
three-atom peel at the original root. Thus geometric projection repair
and universal laminate construction remain separate obligations.

## 1. Exact setting and a positive-coefficient identity

Use the N8 source, faces, physical masses and five-row hat matrices H_i
from NONLOCAL_PATCH_CYLINDER.md. Labels0,...,8 are the original first
nine physical gradients; label9 is the physical mean H_q of faces238,268,
with mass6/50. For ANY real two-output projection C:R^5->R^2, put

    G_i=C H_i,   Q=C H_q,   d_i=det(G_i-Q).

There is the universal identity

    (10d3+d8)(d6+2d7+d8)
       +2d5(d6+d8)+2d4*d8 = 0.                       (1)

All coefficients are positive. Hence d3,...,d8 cannot ALL have one
strict sign. In particular, no two-output projection makes Q a strictly
isolated determinant well with all other det(G_i-Q)>0 or all<0.
Zeros/degenerate projections are allowed by(1); finite lamination is
NOT concluded from this identity.

### Direct geometric proof, valid for all admitted source geometries

Subtract Qx from the actual P1 map and write its nodal images as v_i.
The common-edge trace gives v2=v8=:B. The opposite-apex physical-mean
secant identity gives v3=v6=:A. Let T=v1,C0=v4,D0=v5. Use the notation

    a=orient(A,C0,B), b=orient(C0,D0,B),
    c=orient(D0,A,B), x=orient(T,C0,D0),
    y=orient(T,D0,A), z=orient(T,B,A),
    Delta=orient(A,C0,D0)=a+b+c.

The elementary two-dimensional determinant identity is

    z*Delta = y*a - (Delta-x-y)*c.                   (2)

For Delta!=0 this is the barycentric formula for B and T relative to
the triangle(A,C0,D0); multiplying by Delta gives a polynomial identity,
so it remains true when Delta=0. It can equally be verified by expanding
the six2-by2 determinants, with no positivity assumption.

If s_i is twice the positive physical area of source face i, the source
face orientations give

    a=s6*d6, b=s7*d7, c=s8*d8,
    x=-s4*d4, y=-s5*d5, z=s3*d3.

Substituting in(2) and moving everything left gives

    (s3*d3+s8*d8)(s6*d6+s7*d7+s8*d8)
     +s5*d5(s6*d6+s8*d8)+s4*s8*d4*d8=0.            (3)

All s_i are positive. For the fixed source they are
s3=20,s4=s5=4,s6=s8=2,s7=4; dividing by4 gives(1).
Thus the sign exclusion holds on EVERY admitted straight embedding of
this same source, with its true physical pair mean. No affine outer
trace is needed for this local identity. Domain reflection changes all
oriented source signs simultaneously and leaves(3) unchanged.

### Exact Grassmannian coefficient proof

Let p_ab be the ten2-by2 minors of the2-by5 projection C, in row-pair
order01,02,03,04,12,13,14,23,24,34. Cauchy--Binet makes each d_i a
linear form in p. The left side P of(1) is the following EXACT linear
combination of the five Plucker quadrics

    R_abcd=p_ab*p_cd-p_ac*p_bd+p_ad*p_bc:

    P= -5/8 R0123 +5/12 R0124 -5/12 R0134
          +5/6 R0234 -5/6 R1234.                   (4)

Every R vanishes for every real2-by5 C. The stdlib verifier reconstructs
all canonical physical hats and checks EVERY quadratic monomial
coefficient of(4), rather than testing a finite set of projections.
Equations(2)--(4) give two independent elementary derivations of the
universal rank2-output restriction.

## 2. A higher-output strict well exists but cannot descend

On canonical A in R^(5 by2), define the globally rank-one-AFFINE quadratic

    F(A)=sum_(a<b) omega_ab det((A-H_q)_{rows a,b}),

with the integer coefficient vector, in the above row-pair order,

    omega=(-4,76,8,0,132,0,-66,0,-270,-132).

Every2-row minor is affine along every rank-one line, so this assertion
is global on ALL matrices. Exact values on the quotient support are

    F(H_q)=0;
    F(H_i)=10 for i=0,1,2,4,5,6,7,8;
    F(H_3)=21.

This quotient is NOT any finite exact-support binary laminate, with
any positive REAL split masses or repetitions. To prove this, take a
lowest mixed node in a hypothetical finite tree containing both H_q
and other terminal atoms. One child consists only of H_q; the other
contains only other atoms. Rank-one affinity implies F(othermean)>0.
But rank-one compatibility to H_q implies F(othermean)=0, because F is
a centered quadratic sum of minors at H_q. Contradiction. Repeated
H_q leaves or other terminal repetitions do not affect this argument.

This is a QUOTIENT barrier. The ORIGINAL eleven-face canonical hat law
is finite by the preserved<=5-interior theorem. Its two physical pair
gradients each have F=0 and are distinct; they cannot simply be forced
as siblings. No actual gradient-law Jensen violation has been obtained.
Indeed both the actual and quotient laws have exact F moment F(0)=11,
as required by the null-minor identities. F itself is not a separator.

The skew two-form omega has rank4, not2. Its five Plucker values are

    (1056,6096,1056,-7872,-17424),

and their combination in(4) is9400>0. The scalar values(10,...,21,...)
therefore cannot be minors of a two-output projection. Any global
factorization of this quadratic through a rank2 output C would require
omega to have radical containing ker C, hence rank at most2; the rank4
certificate rules it out. The same conclusion is visible directly from
(1): all nine strict positive values would violate it.

Thus this specific load-bearing higher-output scalarized-minor well
barrier cannot transfer to m2. This does not say that arbitrary nonlinear
rank-one convex witnesses descend, nor that every projected quotient
is finite. No weak-limit or off-support-auxiliary exclusion is inferred
from the exact finite-tree well argument.

## 3. A general geometric no-isolation lemma for physical pair means

The following extends the strict determinant conclusion beyond N8.
Let u be ANY continuous two-output P1 map on a finite admitted triangle
mesh of a polygonal disk, with full affine boundary u=Lx+b. Let two
adjacent faces form a four-vertex disk patch whose FOUR boundary edges
are internal mesh edges. Let Q be their true positive-area mean.
Then the outside values det(G_T-Q) cannot all have one strict sign.

Here is a finite piecewise-affine proof. The two pair gradients are
rank-one compatible, so det(G_T-Q)=0 on the pair. Affine boundary and
the physical null-minor identity give

    sum_T w_T det(G_T-Q) = det(L-Q).

If all outside values have one strict sign, Q-L is invertible and that
sign equals sign det(Q-L). Form

    v(x)=(Q-L)^(-1)(u(x)-Lx-b)-x.

Its boundary is -x. Its Jacobian is strictly POSITIVE on every outside
face and zero on both pair faces. Their shifted physical mean is0.
As in Section1, the four patch boundary images alternate A,B,A,B.
If A=B, every neighboring outside face on a patch boundary edge has
two equal image vertices, contradicting its positive Jacobian.

If A!=B, choose the two opposite patch boundary edges both traversed
from A to B in the oriented patch boundary. Each has a distinct outside
physical neighbor. Positive Jacobian makes both image triangles lie on
the SAME side of their common full base AB. Two nondegenerate triangles
with that full base on the same side overlap on an open region near an
interior point of AB.

For a target point outside the finitely many image edges, sum the signed
image-triangle indicators. Each oriented triangle contributes the
winding number of its image boundary. Internal source edges cancel
because v is continuous. Thus the sum is exactly the winding number
of the outer boundary -x: either0 or1. Degenerate pair triangles
contribute0, and all outside triangles have positive sign. The overlap
just found would give a sum at least2. Contradiction.

This proves the lemma with all embedding, mass and nodal quantifiers.
It is a finite oriented-triangle argument, not an assertion of a
general Sobolev global-injectivity theorem. The internal-boundary-edge
hypothesis is explicit; no absent outside neighbor is silently used.
It blocks only a STRICT single determinant-well obstruction at Q.
Zeros, nonlinear barriers, and finite/limiting construction remain
separate questions.

If additionally the outside physical face-adjacency graph is connected
and none of these d_T is zero, its mixed signs force a shared-edge pair
G_i,G_j with d_i*d_j<0. Their rank-one segment meets det(A-Q)=0.
Thus Q has a genuine rank-one contact with a positive mean of two
original compatible atoms. The N8 outside graph is connected and has
this property generically. The next section proves why this contact
alone does NOT finish the required root substitution.

## 4. Complete three-atom root-packet obstruction, with positive repair

At the FIXED N8 geometry use old values in order(3,4,5,6,8)

    (4,14), (7,-12), (-13,9), (6,14), (3,-6).

The pair mean is exactly Q=I. Its ten quotient atoms are distinct; Q
has NO original rank-one neighbor. The COMPLETE actual rank-one pair
list among the other nine atoms is

    (0,2),(0,4),(1,2),(2,6),(3,5),
    (4,5),(4,7),(5,8),(6,7),(7,8).

There is NO positive finite packet at the original root0 containing Q
and supported on at most THREE distinct quotient atoms, regardless of
real masses, scaling or internal repeated leaves. Q alone is rank2;
Q plus one other atom has no rank-one connection. A finite three-atom
law must contain an original compatible pair: reduce any pure-label
subtrees and take a lowest mixed node. Since Q is isolated, that pair
must be one of the ten displayed i,j.

Set f_i=det G_i (the current root is0), d_i=det(G_i-Q) and choose any
p_q>0. Self determinant balance and compatibility of the packet mean
with root0 force

    p_i d_i+p_j d_j=0,
    p_i f_i+p_j f_j=-p_q det Q.

For every listed pair the determinant z=d_i f_j-d_j f_i is NONZERO,
so the ONLY candidate ratio is

    p_i= p_q*d_j*det Q/z,
    p_j=-p_q*d_i*det Q/z.                            (5)

At least one candidate is strictly NEGATIVE in every case. The exact
receipt lists all ten rational pairs. This exhausts all positive real
scales because changing p_q only rescales(5) positively. It is a
complete exclusion of this narrow root-packet operation, not a finite
sampling claim or an exclusion of all binary trees.

The obstruction holds on an explicit FULL10D independent-real-coordinate
closed box of radius2^-32 around this field. Own exact outward-dyadic
interval replay verifies all35 nonedge determinants remain nonzero,
rank Q remains2, all ten denominators in(5) remain nonzero, and for
each pair at least one mass is strictly negative. There are46 nonzero
guards plus ten sign exclusions. The graph list is therefore complete
throughout that box; no accidental new compatible edge is omitted.

The CENTER nevertheless has an exact18-occurrence POSITIVE quotient
tree, found with the larger nonlocal packet operation and directly
replayed on all physical masses and jumps. Q occurs once, so replacing
it by the physical fourfan gives21 actual N9 leaves for ANY u7, or the
corresponding arbitrary-value doublefan extension. This positive center
does not certify every point of the surrounding obstruction box; no
universal positive claim for that box is made here.

The load-bearing missing condition is therefore not merely a compatible
pair contact with Q. That contact must also acquire root-compatible
positive mass and permit the remaining law to terminate. Larger packets
or an intermediate current mean are genuinely necessary for this
root-first three-atom strategy; the center's actual law is positive.

## Evidence, costs and remaining question

`pair_mean_projection_repair.py` is stdlib Fraction algebra, with no
solver, floating point or peer implementation imports. It reconstructs
the full Plucker coefficient identity, the rank4 omega control, every
actual compatible pair and the full real-box exclusions, then replays
the independently saved18-leaf positive tree. Runtime about0.02s.
All inputs are constructed mathematical fields, not experiments.

A separate QF_NRA query on the six-coordinate normalized Q=I chart
returns UNSAT for all nine strict positive d_i in about0.04s. It is a
finite solver control, not the governing proof: equations(2)--(4) and
the image-overlap lemma carry the universal claims. A broader finite
K(A R-lambda I) search tested150 one-hot diagonal-dominance cases and
961,535 random supplied fields/right matrices with no negative quotient
witness found; that nondiscovery gives NO universal inference.

The universal N8 two-output single-pair exposure and generic six-free-node
N9 finite-tree problem remain OPEN. No global continuous rank-one convex
negative functional or weak-closure exclusion has been obtained. The
proof/novelty/external-correctness statuses remain separate.
