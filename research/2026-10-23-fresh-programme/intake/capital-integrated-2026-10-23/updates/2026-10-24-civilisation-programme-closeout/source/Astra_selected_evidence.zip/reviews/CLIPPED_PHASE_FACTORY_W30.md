# Phase-instrument source and robustness audit

W30, 23 October 2026. Scoped internal conclusion: **the polynomial-in-inverse-error commuting-source factory and the stated exact-finite-source robustness transfer are reconstructed**, with the additive coherent-simulation precision qualification. This is a mathematical circuit/compiler claim, not an executed full source factory, integrated finite V4 code, physical validation or practical advantage.

The principal frozen phase proof has SHA256 `b05b38dcb8959e263d5fef99f88b2151680fba02949b2040eb7f2c06060995d9`; the robustness source has SHA256 `c9ccab4e7815df1e0a6ddb0ce1d7afce59ba1c9698a4b4c2789817b5dfab127c`. The owner-preserved additive simulator qualification, found during this audit, has SHA256 `944fcef4eb7c941607284deee8ba0cf68d849d3a6d77ed8e1ebcef0cc496e039`.

## Strongest conclusions and correction

Coherent phase estimation of the PHYSICAL H evolution, scalar coin rejection and a retained phase purifier prepare Gamma*Btilde/M because Gamma is a scalar function of Q and every Kraus operator is a normal function of H. The accepted-middle K*Pi_accept K block supplies Btilde/M as an operator. Complete-pattern COPY/XOR pinching supplies Dtilde/M without tracing colors. The uniform phase-wrap error is at most40M ln(2T)/T, even at a clipping eigenvalue. Applying the acquired inverse normalizer AFTER the instrument gives a normalized target with good probability1/(4Tmax M), and known-source amplification pays its square-root inverse.

The simulator precision needed an explicit distinction: top-left block error e from a unitary target guarantees only signal-isometry error at most sqrt(2e). Requesting e<=xi^2/2 supplies coherent error xi. A hybrid on ideal zero-simulation-helper prefixes controls QPE, Gram, inverse transformations and amplification, without falsely claiming global simulator norm accuracy on arbitrary helper inputs. The owner froze the qualification separately; only logarithmic precision lengths change. The inverse power's constant scaling is also made explicit in the independent review: Corollary67 gives sqrt(3/4)Jtilde/2, and either a fixed-slack constant amplification or a paid smaller scale yields the advertised interface. A prior independently written all-LCU inverse fallback removes the phase-compiler premise at much larger polynomial cost.

The exact mathematical output of the finite native CPTP circuit, after exact total-Q pinching, can itself be chosen as the outer coding source. Full trace-norm delta perturbs actual infinite-bath drift by at most k*delta. The entropy tolerance min{1/4,kappa/(4k),(eta*g)^2/(128k^2)} loses less than eta*g/4 while keeping a common strict bulk margin. Coding m copies of that actual source requires no comparison with an unused ideal rho^tensor m and hence no artificial m*delta charge.

For eta_m=1/ceil(log2(m+2)), source preparation needs only inverse-polylogarithmic accuracy in m, at fixed k,b,g,kappa. The moving-source argument is valid horizon by horizon: each code uses identical copies of its selected finite source; dimension-only Schur acceptance bounds vanish; conservative bounded-increment Lyapunov constants are common. The fixed-source black-box theorem is not invoked unchanged for a moving source. The limiting rate approaches the same CERTIFIED lower entropy floor, not an unknown optimal value.

## Independent evidence and limits

`INDEPENDENT_REVIEW.md` contains the complete fresh algebraic reconstruction, all scales and order, exact source-purifier reasoning, physical-simulation helper hybrid, infinite-bath drift perturbation, Audenaert half-distance convention, and moving-family argument.

The new `check_phase_scalars.py` imports no producer code. It checks195,072 exact rational pointwise filter inequalities, including21,608 wrapped pairs;1,344 phase/filter distributions at grid sizes8 through512 satisfy the derived tail/error bounds in double-precision diagnostics. Probability-sum residual is at most4.45e-16; these numerical comparisons are not interval certificates. Deliberately using circular distance as an unwrapped eigenvalue bound fails in seven exact controls, demonstrating the need for the bounded-filter wrap argument.

There are12 exact rational phase-grid stopping cases,90 exact robustness-budget cases,6 exact scalar moving-family acceptance fixtures and3 exact simulator-precision witnesses. The latter saturate coherent-error-squared=2*block-error and invalidate replacing coherent error by block error. The acceptance fixtures are scalar checks, not integrated codes or V4 horizon recommendations. Previous native-H and operator-pinch checks remain in the separately frozen Bernstein audit; they are not rerun or relabeled as phase-circuit executions.

## Full costs and information boundary

The supplied inputs are the exact recurrent model, acquired H block circuit with charged G_H, known scalar b with bit length L_b, efficiently prepared V4 Gamma, and certified g,kappa for robustness. Source preparation does not calibrate those physical parameters. Gamma is an acquired polynomial-size circuit here, not an arbitrary uncosted function oracle. Independent certificate bit lengths L_g,L_kappa are charged unless computed analytically.

M=1+gamma*b*k(k-1)=O(k). Choosing delta=epsilon/(16M) gives T_pe=O((M^2/epsilon)log(M/epsilon)); the phase register is logarithmic in this grid size. Scalar coin values are computed reversibly from y rather than stored in a T_pe-sized table. Physical controlled simulations have total normalized time O(T_pe) per instrument. The Gram uses two instruments, inverse QSVT has condition at mostM/(1-delta), and source amplification uses O(sqrt(Tmax M)log(1/epsilon)) complete preparation/inverse calls. The rough oracle scaling is G_H*M^(3/2)*T_pe times precision logarithms, with all inverse compiler/synthesis costs charged. No optimized leading exponent or practical gate count is claimed.

The robustness substitution makes the per-copy compiler polynomial in k,L_b,L_g,L_kappa,1/g,1/kappa,log m. Outer Schur, high-design, logical-map, seed-certification and decoder precision costs remain separate. This proof does not preserve sharper analytic-source variance or finite-horizon constants without a new stability bound; a common conservative bounded-increment tail suffices for its asymptotic assertion. The exponential-in-k mixed-Schur onset remains.

The equally informed ordinary baseline already has physical Hamiltonian simulation from acquired block access, coherent rejection sampling, inverse normalization and fixed-point amplification. Primary sources were reopened directly: Gilyen et al.1806.01838v1, Berry et al.1412.4687v1, Ozols et al.1103.2774v4, Yoder et al.1409.3305v2 and Audenaert quant-ph/0610146v1. Links and exact roles are in the review. A dimension-sized classical eigendecomposition is not the relevant strongest baseline.

## Remaining decisive work

The source and transfer are internally reconstructed. Integrated finite V4 contracts, an executable full factory, deterministic good-seed certification, useful finite onset, physical calibration/hardware errors, novelty and practical advantage are not established. The newly separate parameter-rounding lemma was not silently included in this verdict. Physical apparatus was not operated and no data were acquired from it.
