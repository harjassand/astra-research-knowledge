"""Cold W39 finite-port controls: new standalone exact and numeric code.

No producer or peer modules, replay scripts, raw outputs or reviews read.
Fraction controls test complete circuit matrices and every represented
adaptive history. Floating integration tests a complete two-step Gaussian
policy transcript, not a physical measurement or an interval certificate.
"""
from pathlib import Path
from fractions import Fraction as R
from itertools import product
import hashlib
import json
import math
import time
import numpy as np

HERE=Path(__file__).resolve().parent
SPACE=HERE.parents[3]
TARGET=SPACE/'work/workers/w73_fresh_foundational_inventor/FINITE_PORT_IMPEDANCE_OBSTRUCTION.md'


def I(n):return [[R(i==j) for j in range(n)] for i in range(n)]
def zeros(n):return [[R(0)]*n for _ in range(n)]
def add(A,B):return [[x+y for x,y in zip(a,b)] for a,b in zip(A,B)]
def scale(A,c):return [[c*x for x in row] for row in A]
def mat(A,B):return [[sum((x*y for x,y in zip(a,b)),R(0)) for b in zip(*B)] for a in A]
def mv(A,v):return [sum((x*y for x,y in zip(row,v)),R(0)) for row in A]
def dot(x,y):return sum((a*b for a,b in zip(x,y)),R(0))
def outer(x):return [[a*b for b in x] for a in x]


def inverse(A):
    n=len(A);W=[a+b for a,b in zip([row[:] for row in A],I(n))]
    for j in range(n):
        k=next(k for k in range(j,n) if W[k][j])
        W[j],W[k]=W[k],W[j]
        lead=W[j][j];W[j]=[v/lead for v in W[j]]
        for k in range(n):
            if k!=j:
                lead=W[k][j]
                W[k]=[v-lead*w for v,w in zip(W[k],W[j])]
    return [row[n:] for row in W]


def laplacian(d,a,theta):
    n=2*d+2;L=zeros(n)
    edges=[(0,l) for l in range(2,d+2)]+[(1,l) for l in range(d+2,n)]
    if theta:edges.append((0,1))
    for u,v in edges:
        L[u][u]+=a;L[v][v]+=a;L[u][v]-=a;L[v][u]-=a
    return L


def full_case(d,a,r):
    n=2*d+2;Ls=[laplacian(d,a,t) for t in (0,1)]
    As=[inverse(add(I(n),scale(L,r))) for L in Ls]
    Ms=[mat(L,A) for L,A in zip(Ls,As)]
    for M,A in zip(Ms,As):assert M==scale(add(I(n),scale(A,-1)),1/r)
    b=[R(0)]*n;b[0]=1;b[1]=-1
    u=mv(As[0],b);beta=r*a;D=1+beta*(d+1)
    h=(1+beta)/D;l=beta/D
    explicit=[h,-h]+[l]*d+[-l]*d
    assert u==explicit
    assert sum(abs(x) for x in u)==2
    assert dot(u,u)==2*((1+beta)**2+d*beta**2)/D**2
    assert dot(b,u)==2*h
    c=a/(1+r*a*dot(b,u))
    assert add(Ms[1],scale(Ms[0],-1))==scale(outer(u),c)
    assert 0<c<=a
    saturation=0
    for amplitude in (R(1,2),R(1),R(2)):
        x=[amplitude*(1 if ui>0 else -1) for ui in u]
        diff=[v-w for v,w in zip(mv(Ms[1],x),mv(Ms[0],x))]
        assert dot(u,x)**2==4*amplitude**2
        assert dot(diff,diff)==4*c*c*amplitude**2*dot(u,u)
        assert mv(Ms[0],x)==[R(0)]*n
        saturation+=1
    # Both current-feedback and voltage-sense covariance identities.
    feedback_basis=0;hub_variances=[]
    for theta,(L,A,M) in enumerate(zip(Ls,As,Ms)):
        F=add(I(n),scale(L,r))
        covariance=mat(F,F)
        assert covariance==add(add(I(n),scale(L,2*r)),scale(mat(L,L),r*r))
        assert covariance[0][0]>=1+2*r*a*d+r*r*a*a*(d*d+d)
        assert mat(L,L)[0][0]>=a*a*(d*d+d)
        assert mv(F,[R(1)]*n)==[R(1)]*n
        assert mat(mat(L,outer([R(1)]*n)),L)==zeros(n)
        for j in range(2*n):
            z=[R(0)]*n;eta=[R(0)]*n
            if j<n:z[j]=1
            else:eta[j-n]=1
            current=mv(L,z);noise=mv(F,eta)
            acquired=[x+y for x,y in zip(current,noise)]
            command=[x+r*y for x,y in zip(z,acquired)]
            v=mv(A,command);actual=mv(M,command)
            assert v==[x+r*y for x,y in zip(z,eta)]
            assert acquired==[x+y for x,y in zip(actual,eta)]
            feedback_basis+=1
        hub_variances.append(str(covariance[0][0]))
    assert mat(add(I(n),scale(Ls[0],r)),add(I(n),scale(Ls[0],r)))!=mat(add(I(n),scale(Ls[1],r)),add(I(n),scale(Ls[1],r)))
    # A concrete feedback-noise realization violates unit pathwise
    # command budget. Gaussian full support makes arbitrary clipping
    # avoidance incompatible with a finite deterministic B.
    eta=[R(0)]*n;eta[0]=10
    feedback_command=[r*x for x in mv(add(I(n),scale(Ls[0],r)),eta)]
    assert max(x*x for x in feedback_command)>1
    return {'d':d,'a':str(a),'r':str(r),'n':n,'u':u,'c':c,'Ms':Ms,
            'saturation':saturation,'feedback_basis':feedback_basis,
            'feedback_hub_variance_multipliers':hub_variances}


def command(seed,t,history,n,q):
    val=R(1,q+1);code=sum((j+1)*b for j,b in enumerate(history))
    return [val*((-1)**(i+t+seed+code)) if (i+2*t+code)%3 else R(0) for i in range(n)]


def temporal_controls(case):
    u=case['u'];c=case['c'];n=case['n'];M0,M1=case['Ms']
    path_count=0;conditional_checks=0;weighted=0
    sigma2=R(5,4)
    for q in (1,2,4,6):
        B=R(q,(q+1)**2);E=R(3*q,2*(q+1)**2)
        for seed in range(2):
            for past_bits in product((0,1),repeat=q-1):
                xs=[command(seed,t,past_bits[:t],n,q) for t in range(q)]
                taus=[R(1+(t+sum(past_bits[:t]))%3,2) for t in range(q)]
                assert all(sum((xs[t][i]**2 for t in range(q)),R(0))<=B for i in range(n))
                assert all(sum((taus[t]*xs[t][i]**2 for t in range(q)),R(0))<=E for i in range(n))
                energy=sum((dot(u,x)**2 for x in xs),R(0))
                tenergy=sum((tau*dot(u,x)**2 for tau,x in zip(taus,xs)),R(0))
                assert energy<=4*B and tenergy<=4*E
                kl=R(0);tkl=R(0)
                for tau,x in zip(taus,xs):
                    delta=[a-b for a,b in zip(mv(M1,x),mv(M0,x))]
                    conditional_kl=dot(delta,delta)/(2*sigma2)
                    assert conditional_kl==c*c*dot(u,u)*dot(u,x)**2/(2*sigma2)
                    kl+=conditional_kl;tkl+=tau*conditional_kl;conditional_checks+=1
                assert kl==c*c*dot(u,u)*energy/(2*sigma2)
                assert kl<=2*c*c*B*dot(u,u)/sigma2
                assert tkl<=2*c*c*E*dot(u,u)/sigma2
                path_count+=1;weighted+=1
    return path_count,conditional_checks,weighted


def adaptive_transcript_quadrature():
    out=[];max_error=0.;max_refine=0.
    # For x1=sign(u)/2, M0x1=0, M1x1=c*u. The direction u/||u||
    # is a sufficient statistic of ALL acquired outputs; orthogonal
    # Gaussian coordinates have exactly common law and factor out.
    # x2 repeats sign(u)/2 if first projection>=0, otherwise commands
    # the all-common vector1/2. Both hypotheses evaluate the same policy.
    for d in (1,4,16,64):
        for beta in (0.25,1.,4.):
            h=(1+beta)/(1+beta*(d+1));l=beta/(1+beta*(d+1))
            u2=2*(h*h+d*l*l);c=1/(1+2*beta*h);sigma=.75
            mu=c*math.sqrt(u2);k1=mu*mu/(2*sigma*sigma)
            p1=(1+math.erf(mu/(sigma*math.sqrt(2))))/2
            exact=k1*(1+p1);values=[]
            for N in (100,180):
                zz,ww=np.polynomial.legendre.leggauss(N)
                lo=-12*sigma;hi=mu+12*sigma
                y2=(lo+hi)/2+(hi-lo)/2*zz;w2=(hi-lo)/2*ww
                value=0.
                for aa,bb,active in ((lo,0.,False),(0.,hi,True)):
                    y1=(aa+bb)/2+(bb-aa)/2*zz;w1=(bb-aa)/2*ww
                    mean2=mu if active else 0.
                    p=np.exp(-((y1[:,None]-mu)**2+(y2[None,:]-mean2)**2)/(2*sigma*sigma))/(2*math.pi*sigma*sigma)
                    logratio=(mu*y1[:,None]-mu*mu/2)/(sigma*sigma)
                    if active:logratio=logratio+(mu*y2[None,:]-mu*mu/2)/(sigma*sigma)
                    value+=float(np.sum(w1[:,None]*w2[None,:]*p*logratio))
                values.append(value)
            max_error=max(max_error,abs(values[-1]-exact));max_refine=max(max_refine,abs(values[0]-values[1]))
            passive_upper=c*c*u2/(sigma*sigma)  # B=1/2
            assert exact<=passive_upper+1e-14
            assert abs(values[-1]-exact)<1e-10
            out.append({'d':d,'beta':beta,'true_full_adaptive_KL':exact,
                        'two_dimensional_integral':values[-1],
                        'passive_pathwise_bound':passive_upper})
    return {'status':'FLOATING_COMPLETE_POLICY_DIAGNOSTICS_NOT_INTERVAL_CERTIFIED',
            'cases':out,'max_integral_error':max_error,'max_refinement':max_refine}


def scaling_rows():
    rows=[]
    for k in (1,2,4,8,16):
        d=1<<(4*k)
        for name,beta in [('fixed_r',R(1)),('r_inverse_d',R(1,d)),
                          ('r_inverse_sqrt_d',R(1,1<<(2*k))),
                          ('r_inverse_d_three_quarters',R(1,1<<(3*k)))]:
            D=1+beta*(d+1);h=(1+beta)/D;l=beta/D
            u2=2*(h*h+d*l*l);c=1/(1+2*beta*h)
            gamma=beta*d
            assert u2<=4/(1+gamma)**2+R(4,d*d)+R(2,d)
            normalized_lower=1/(c*c*u2)
            rows.append({'d':d,'regime':name,'beta':str(beta),'u2_squared':str(u2),
                         'c_over_a':str(c),'B_lower_divided_by_sigma2_delta_factor':str(normalized_lower)})
    return rows


def main():
    begin=time.time();cases=[]
    for d in range(1,7):
        for a in (R(1,2),R(1),R(2)):
            for r in (R(1,4),R(1),R(3)):
                cases.append(full_case(d,a,r))
    paths=kernels=weighted=0
    for case in cases[::4]:
        p,k,w=temporal_controls(case);paths+=p;kernels+=k;weighted+=w
    numeric=adaptive_transcript_quadrature()
    out={'status':'PASS_COLD_FULL_CIRCUIT_AND_ADAPTIVE_TRANSCRIPT_CONTROLS',
         'provenance':'New standalone code after target and primary manual; no producer/peer code/output imports or reads.',
         'exact':{'full_n_port_circuit_cases':len(cases),
                  'rank_one_entry_equalities':sum(c['n']**2 for c in cases),
                  'single_command_saturation_cases':sum(c['saturation'] for c in cases),
                  'feedback_signal_noise_basis_cases':sum(c['feedback_basis'] for c in cases),
                  'adaptive_history_control_paths':paths,
                  'same_history_full_Gaussian_kernel_KL_equalities':kernels,
                  'time_weighted_history_paths':weighted,
                  'common_mode_voltage_covariance_and_current_identities':2*len(cases),
                  'feedback_covariance_changes_detected':len(cases),
                  'feedback_finite_pathwise_budget_counterexamples':len(cases)},
         'floating':numeric,'analytic_closed_form_scaling_only':scaling_rows(),
         'runtime_seconds':time.time()-begin,
         'target_sha256':hashlib.sha256(TARGET.read_bytes()).hexdigest(),
         'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'scope':'Finite exact algebra and synthetic Gaussian policy quadrature supplement universal derivation. No physical data, feedback circuit, calibration or instrument costs acquired.'}
    (HERE/'COLD_FINITE_PORT_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'status':out['status'],'exact':out['exact'],
                      'full_policy_KL_max_error':numeric['max_integral_error'],
                      'runtime':out['runtime_seconds']},indent=2))


if __name__=='__main__':main()

