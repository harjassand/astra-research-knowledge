# A correlation-penalized quadratic converse for the recurrent tree device

23 October 2026, w19. Full development of the independently frozen seed
CORRELATION_PENALIZED_CUT_SEED.md, SHA256
db3b05bb2c6677c4bc84bbe774a2ab07a2608ccc2a97e3115b0ccd9d2ce78f77.
The seed was sent to root and w36 before their reconstruction of this route.
This is a conditional mathematical weak converse for the specified device
and interface. Mathematical priority, physical preparation and a matching
achievable rate remain unestablished. Frozen predecessors are retained.

## 1. Device and full initial-resource contract

The bath is E=C^2_seed tensor F(C^2). S_j prepends color j=1,2 to a tree word;
P0 projects on the two physical roots; R flips the root seed and vanishes
elsewhere. The unchanged self-adjoint unitary and interaction are

    U=[[R,S1,S2],[S1*,0,0],[S2*,0,0]],
    V_beta=alpha U+i beta I, alpha=sqrt(1-beta^2), 0<=beta<=1.

The qutrit charge is q=diag(0,1,1). Each matched subspace
{|0,S_jx>,|j,x>} has U=sigma_x. The remaining physical-root subspace has
port0, U=R. There is no truncated-tree boundary or bath reset.

For EACH finite horizon N choose ANY normal initial resource
eta_N on E and the entirety of the laboratories. It may depend on N and may
have arbitrary bath/laboratory entanglement, bath coherence and support,
infinite mean depth or entropy, Alice--Bob preshares, and normal ancillary
memories. An inaccessible purifier is allowed. Let R_log be a finite fresh
reference and M the logical input of dimension K. Initially

    Phi_(R_log M) tensor eta_N.

Thus the fresh logical system is independent of the WHOLE initial resource.
There are exactly N chronological forward qutrit calls. Laboratories may
perform arbitrary local normal trace-preserving operations and send arbitrary
quantum/classical messages Bob-to-Alice. The prescribed calls are the only
forward path. There is no direct bath access, additional forward wire or
forward timing/selection signal. All branches count in one unconditional
fixed-K decoder output L. A successful branch is not renormalized.

No preparation budget is assumed. Granting these resources free strengthens
the converse; it does not acquire physical preparations or a code. The proof
below holds separately for every N and eta_N, without taking a fixed-state
limit or tracing an identity on the infinite bath.

## 2. Finite information quantities on normal infinite systems

All logarithms and entropies are in bits. For a finite system A and any normal
system Y define

    H(A|Y)=S(A)-I(A:Y),
    I(A:Y)=D_2(rho_AY || rho_A tensor rho_Y).

These obey -S(A)<=H(A|Y)<=S(A), so |H(A|Y)|<=log2 dim A. They are continuous
in trace norm uniformly in the dimension of Y when A is fixed finite.
Finite-system conditional mutual information is

    I(R:A|Y)=H(A|Y)-H(A|RY).

Its chain rule and data processing agree with the normal relative-entropy
extension. The finite reference makes I(R:anything)<=2log2 K. Infinite
ancillary entropies need never be subtracted.

Weak monotonicity in the form needed below follows directly from normal
conditional-entropy duality. Purify any state on B,X,E to B,X,E,F. Since B
is finite, H(B|X)=-H(B|EF) and conditioning gives H(B|EF)<=H(B|E). Hence

    H(B|X)+H(B|E)>=0.                                  (Q1)

Primary support: Kuznetsova, arXiv1004.4519v2, definition(2), bounds(5),
pure-state duality(6), monotonicity(7); Shirokov, arXiv1512.09047v7,
definition(6), finite-side continuity(7), chain rule(14), identities(15),(16)
and bound(17). The device-specific inequalities below are derived here.

## 3. Keep the correlation losses in both communication cuts

At call t write A_t for the incoming qutrit, B_t for its outgoing qutrit,
E_t for the bath just before and E'_t for it just after. Let rho_t be the
actual unconditional marginal on A_t E_t and rho'_t=V rho_t V* on B_t E'_t.
It may be correlated with every other register and with the fresh reference.

For the cut Alice | (E plus Bob plus inaccessible systems), put the latter
systems in Y. They initially have zero mutual information with R_log.
Moving A_t to that side changes the mutual information by

    I(R_log:A_t|Y)
      <=H(A_t|Y)+S(A_t)
      =2S(A_t)-I(A_t:Y)
      <=2S(A_t)-I(A_t:E_t).                            (Q2)

Device operations are local on the receiving side of this cut. Backward
messages move systems out of it; their loss cannot increase mutual
information. Local sender trace-preserving operations preserve the receiver
marginal. Therefore, after decoding,

    I(R_log:L)<=sum_t [2S(A_t)-I(A_t:E_t)].             (Q3)

For the cut Bob | (Alice plus E plus inaccessible systems), let C be Bob's
old memory just before B_t enters. Applying(Q1) with X=R_log C and the
DISJOINT actual bath E'_t gives

    I(R_log:B_t|C)
      =H(B_t|C)-H(B_t|R_log C)
      <=S(B_t)+H(B_t|E'_t)
      =2S(B_t)-I(B_t:E'_t).                            (Q4)

This step does not put the bath into Bob's laboratory and does not assume it
is independent of the reference. It merely uses a valid entropy inequality
on the actual joint state. For this cut the interaction is local on the
sender side. Backward messages leave Bob, so again data processing gives

    I(R_log:L)<=sum_t [2S(B_t)-I(B_t:E'_t)].            (Q5)

Taking the average of(Q3),(Q5), define

    G(rho)=S(A)+S(B)-[I(A:E)_rho+I(B:E')_rho']/2.

Then every legal protocol obeys

    I(R_log:L)<=sum_t G(rho_t).                        (Q6)

Each individual G is finite and nonnegative since I(A:E)<=2S(A) and
I(B:E')<=2S(B). No entropy of the initial entire resource occurs in(Q6).

## 4. Binary charge pinching controls useful rather than occupied entropy

Let Delta pinch the qutrit into the port-vacuum and colored sectors, acting
as the identity on E. Put

    c_A=S(Delta rho_A)-S(rho_A),
    c_pre=D_2(rho_AE || Delta rho_AE),

and define c_B,c_post analogously for rho'. All four are nonnegative and
at most1. The two-sector pinching gives rho<=2Delta rho, so the relative
entropies are finite. For finite E, direct entropy algebra proves

    c_pre=c_A+I(A:E)_rho-I(A:E)_(Delta rho).             (Q7)

This identity also holds for normal infinite E. To see this without using
S(E), take bath-only increasing finite-rank projections P_m and normalize
rho_m=(I tensor P_m)rho(I tensor P_m)/p_m, p_m->1. The pinching commutes
with these compressions. Finite-port conditional entropies and the mutual
informations in(Q7) converge by their fixed-finite-A continuity. The
relative entropies converge as well: joint lower semicontinuity gives
D(rho||Delta rho)<=liminf D(rho_m||Delta rho_m), while data processing
under the trace-preserving bath compression with a failure flag gives

    p_m D(rho_m||Delta rho_m)<=D(rho||Delta rho).

Its failure-block relative entropy lies between0 and1. These bounds imply
convergence and prove(Q7). The post-call identity uses the same argument.
In particular

    c_pre<=c_A+I(A:E),   c_post<=c_B+I(B:E').           (Q8)

For u=Tr rho_A q and v=Tr rho'_B q, maximum colored-block entropy is

    f(x)=h2(x)+x.

Thus S(A)<=f(u)-c_A, S(B)<=f(v)-c_B. Combining with(Q8),

    G<=f(u)+f(v)-(c_pre+c_post)/2
      <=3+d-(c_pre+c_post)/2, d=u+v-1.                (Q9)

The discarded losses c_A/2+c_B/2 are nonnegative. The last inequality uses
h2(u)+h2(v)<=2, valid on the whole interval, not an expansion near1/2.

## 5. The exact before/after interference identity, including the root

Suppose beta<1, write b=beta^2, a=1-b, alpha=sqrt(a). Define the invariant
physical-root projection P_r=|0><0| tensor P0. Define the bounded Hermitian
Y to be zero on this root block and to equal

    [[0,i],[-i,0]]

on every matched pair {|0,S_jx>,|j,x>}. It has norm1 and Delta(Y)=0.
Let r=Tr rho P_r, y=Tr rho Y, y'=Tr rho' Y. Since V preserves the root
block, the same r occurs before and after the call.

Multiplication of the actual two-by-two physical matrix gives the global
bounded-operator identity

    q+V* q V=I+b(2q-I)-a P_r+alpha beta Y.

Applying it to rho gives

    d=b(2u-1)-a r+alpha beta y.                        (Q10)

Apply the same identity to the inverse call: its interference sign changes,
while its b,a and root block do not. On rho' it gives

    d=b(2v-1)-a r-alpha beta y'.                       (Q11)

Adding and using (2u-1)+(2v-1)=2d proves EXACTLY

    d+r=[beta/(2alpha)](y-y').                        (Q12)

All operators in(Q10)--(Q12) are bounded. No word-depth moment, stationary
bath, product input, inaccessible control or fictitious boundary is used.

## 6. Binary data processing and a scalar Legendre maximum

The legitimate binary POVM {(I+Y)/2,(I-Y)/2} has outcome probabilities
(1+y)/2,(1-y)/2 on rho. Its probabilities on Delta rho are1/2,1/2 because
Delta(Y)=0. Relative-entropy data processing gives, with g even,

    c_pre>=g(y):=1-h2((1+y)/2),
    c_post>=g(y').                                    (Q13)

This POVM is a mathematical comparison in the proof. It is not an acquired
bath measurement or an operation supplied to the communication protocol.

Put kappa=beta/(2alpha). Equations(Q9),(Q12),(Q13) give

    G<=3-r+kappa(y-y')-[g(y)+g(y')]/2.

For any real s, elementary differentiation, or binary relative entropy to
the Gibbs weights, gives

    sup_(-1<=z<=1)[s z-g(z)]=log2 cosh(s ln2),
    z_max=tanh(s ln2).

Apply it with s=2kappa and s=-2kappa and discard -r<=0:

    G(rho)<=3+log2 cosh[(beta/alpha)ln2].               (Q14)

This holds for EVERY normal joint port/bath state rho, including states
correlated with all laboratories and with the reference.

## 7. Finite-error theorem and asymptotic consequence

Bob's normalized fixed-K output L has fresh reference marginal I_R/K.
Let F be its Bell overlap. Binary Bell-test data processing gives

    I(R_log:L)>=d_bin(F||1/K^2)
               >=2F log2 K-h2(F).

Together with(Q6),(Q14), for every finite N and arbitrary allowed eta_N,

    2F log2 K-h2(F)
      <=N[3+log2 cosh((beta/sqrt(1-beta^2))ln2)].       (Q15)

Therefore F_N->1 implies

    limsup_N log2 K_N/N
      <=C_quad(beta):=3/2+(1/2)log2 cosh[
                              (beta/sqrt(1-beta^2))ln2]. (Q16)

Take the minimum with log2(3) and the earlier valid charge-only bound
C_ent(beta)=f(min{(1+beta)/2,2/3}). At beta1 use the generic dimension bound
log2(3); the displayed C_quad has a divergent limit there and offers no
improvement. At beta0 equation(Q15) reduces to the earlier3N bound.

As beta->0,

    C_quad(beta)=3/2+(ln2/4)beta^2+O(beta^4).           (Q17)

Thus arbitrary initially entangled normal bath/whole-laboratory resources
cannot create a LINEAR reliable-rate gain at beta0 within this interface.
This resolves the apparent linear-vs-quadratic allowance left by the
charge-only bound. It does not determine the optimal quadratic coefficient
or construct an achievable code. In particular the converse is not an
entanglement-conversion or preparation sufficiency result.

This is a weak converse: it excludes F_N->1 above the ceiling. It does not
establish F_N->0 or an exponential strong converse for arbitrary entangled
resources. The independent product/SEP CP theorem retains its separate
strong-converse conclusion and may be combined by resource class/regime.

## 8. Checks, costs, provenance and remaining work

The independent script check_correlation_penalty.py imports no peer code.
It implements U as the actual sparse tree-basis permutation from input bath
depth<=2 into the larger exact output support depth<=3. There is no outer
reflection. Its63 selected states at seven beta values check both dephasing
identities, the root/interference balance, binary comparison and G bound.
Four arbitrary R,B,C,E states separately check(Q4). Five explicit matched-
pair fixtures show that saturated port entropy need not carry fresh logical
information and that a tempting joint encoder illegally changes the bath.
The maximum observed balance residual was3.61e-16 and dephasing identity
residual8.89e-16. These finite floating checks do not replace the proof.

Recorded diagnostic cost:.99s wall,.33s user,.06s system, maximum RSS
36,519,936 bytes. Full research time, model tokens/dollars and external
review costs are not measured. Initial state preparation, bath control,
physical apparatus, energy, timing, precision, error correction, reset and
output recovery have not been acquired. No equipment was operated and no
message was sent outside the authorized research team.

Generic conditional-entropy identities, pinching, data processing and scalar
Gibbs duality are established mathematics. Device-specific novelty is
UNKNOWN pending a proper priority audit. Independent criticism should focus
on(Q4), all-call cut bookkeeping, the normal extension of(Q7), invariant-root
term/signs in(Q12), and factors of2 in(Q14)--(Q17). No achievability or physical
advantage should be inferred from the conditional theorem or finite checks.

Primary links: https://arxiv.org/abs/1004.4519 and
https://arxiv.org/abs/1512.09047 . The underlying device source is pinned in
PINNED_SOURCES.json; its immutable corpus revision is
e606bfc587c76bdcae8b8fa3ec33e721efa2fbac.
