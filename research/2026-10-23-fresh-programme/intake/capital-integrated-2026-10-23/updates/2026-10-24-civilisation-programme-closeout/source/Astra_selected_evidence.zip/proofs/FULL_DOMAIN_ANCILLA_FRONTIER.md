# Optimal ancillary exponent under full-domain marginal intertwining

23 October 2026. New internal theorem candidate. No architecture restriction
on the enlarged range algebras in the lower bound. Its hypothesis is the
stronger FULL-DOMAIN marginal norm, not only compression of a prepared product
input. Standard entropy and commuting-square ingredients are prior mathematics.
Independent review and historical priority remain UNKNOWN.

## 1. Contract and finite-resource bound

Let N=r^3, r>=2, and let E_P,E_Q be the original rare binary trace expectations:
rank(P)=rank(Q)=r and their diagonal ranges share exactly one basis vector u.
Let F,G be arbitrary commuting trace expectations onto arbitrary unital
subalgebras of M_(NK), H=FG, and D=Tr_A. Suppose

    max(||D F-E_P D||_diamond,||D G-E_Q D||_diamond)
          <=epsilon<=1.                                (1)

This includes arbitrary correlated system/ancilla/reference inputs. It does
not require catalytic ancilla return. Define

    c=1/(r+1), c_N=N log2(N)/(N-1),
    B_r(epsilon)=[log2(r)-2h2(epsilon/2)
                  -epsilon log2(r^2-1)
                  -min(log2(N),c_N epsilon/(1-c))]_+.

Then every such dilation, with any K, satisfies

    2log2(K)>=B_r(epsilon).                             (2)

If its particular common output

    omega=H(|u><u| tensor I_K/K)

is separable across system and ancilla, the stronger bound holds:

    log2(K)>=B_r(epsilon).                              (3)

In particular, at epsilon=2/(r+1),

    K>=r^(1/2) 2^(-O((log r)/r))                       (all quantum),
    K>=r       2^(-O((log r)/r))                       (separable omega).

The first bound matches HOT_QUANTUM_COMPRESSION.md's K=sqrt(r)+O(1)
asymptotically, even across all enlarged quantum range algebras under (1).
The second matches W61's K=r+1 product-basis-diagonal refinement. It applies
in particular to classical product-basis-diagonal constructions, but does
not call every commutative quantum range algebra classical: our upper
construction has abelian ranges and an entangled common output.

## 2. Full-domain control forces a nearly uniform common marginal

Put rho_S=D(omega), x=rho_S-I_N/N. Since F(omega)=G(omega)=omega, hypothesis
(1) gives

    ||rho_S-E_P(rho_S)||_1<=epsilon,
    ||rho_S-E_Q(rho_S)||_1<=epsilon.

For every traceless self-adjoint x, the exact centered binary formulas give

    ||E_P E_Q(x)||_1<=c ||x||_1.                        (4)

To check constants, write p=1/r^2, s=p(1-p), D_P=P-pI and D_Q=Q-pI.
The centered normalized covariance is c. Then

    E_P E_Q(x)=c Tr(Qx) D_P/(Ns),
    ||D_P||_1=2Ns, |Tr(Qx)|<=||x||_1/2.

The last inequality uses x traceless and the fact that Q is an effect.
This proves (4), without a dimension factor.

Contractivity of E_P in trace norm on self-adjoint matrices gives

    ||x-E_P E_Q(x)||_1<=2epsilon.

Combining with (4),

    T_S:=||rho_S-I_N/N||_1/2<=epsilon/(1-c).             (5)

The system entropy deficit has the elementary upper bound

    D_S:=log2(N)-S(rho_S)
       <=min(log2(N),c_N T_S)
       <=min(log2(N),c_N epsilon/(1-c)).               (6)

Indeed its eigenvalue likelihood ratios relative to I_N/N lie in [0,N].
Convexity gives xlog2(x)<=c_N(x-1)_+ there; summing yields (6).
This reverse-Pinsker mechanism is established; it is written to fix the norm
normalization and the exact constant, not claimed as new.

## 3. The common state must retain log r distinguishability

Start from the hot product state rho=|u><u| tensor I_K/K. The reduced F output
is epsilon-close in trace norm to P/r. Its leakage outside P is <=epsilon/2.
Thus its system entropy is at most

    log2(r)+h2(epsilon/2)+(epsilon/2)log2(r^2-1).

Subadditivity adds at most log2(K) for its ancilla. The same holds for G.
The standard commuting-square entropy inequality gives

    S(F rho)+S(G rho)>=S(rho)+S(H rho),

with S(rho)=log2(K). Rearranging,

    L_H:=log2(NK)-S(omega)
       >=log2(r)-2h2(epsilon/2)-epsilon log2(r^2-1).      (7)

This is the same established entropy mechanism used in W61's resource audit.
The full-domain hypothesis now supplies the additional system-marginal bound
(6), which was unavailable under product compression alone.

## 4. Quantum correlations versus separable common outputs

Araki--Lieb gives S(omega)>=S(rho_S)-S(omega_A), and S(omega_A)<=log2(K).
Therefore

    L_H<=D_S+2log2(K).                                 (8)

Combining (6)--(8) proves (2). This is not a range-dimension or support-count
argument and uses no three-block hypothesis.

If omega is separable, its conditional entropy S(A|S)=S(omega)-S(rho_S)
is nonnegative. For completeness, conditional-entropy concavity applied to
a separable decomposition gives S(A|S)>=sum_i p_i S(omega_(A,i))>=0.
Hence the improved relation

    L_H<=D_S+log2(K)

proves (3). A physical product-basis-diagonal omega is a special case, also
following directly from nonnegative Shannon conditional entropy.

## 5. Sharp asymptotic comparison and entanglement requirement

At epsilon=2/(r+1), every term subtracted from log2(r) in B_r is
O((log r)/r). Thus the stated lower bounds follow. Our explicit quantum
construction has K=sqrt(r)+O(1), epsilon=2/(r+1), a shared two-dimensional
algebra of central weight1/r, and zero initial ancillary purity cost.
W61's refined diagonal construction has K=r+1 at the same error. Both match
their respective leading lower bounds under the identical full-domain norm.
This establishes an asymptotic ancillary Hilbert-dimension separation under
the explicit operational contract, not a gate-time or laboratory advantage.

The quantum construction's advantage necessarily uses entanglement in the
common output. More quantitatively, (7) and the identity

    L_H=D_S+log2(K)-S(A|S)_omega

give

    -S(A|S)_omega >= B_r(epsilon)-log2(K).

For K=sqrt(r)+O(1) and epsilon=2/(r+1), the common state has negative
conditional entropy of magnitude at least (1/2)log2(r)-o(log r). This is a
specified entanglement/correlation resource, not a binary-message capacity
claim. It also explains why ancilla marginal return alone misses the cost.

## 6. Boundaries and decisive falsifiers

A product-input compression bound alone cannot be inserted into (1): it does
not control F/G on their common output omega. Exact cold-ancilla one-use
recovery is not contradicted. No change to our same-ambient no-go is made.

A commuting pair satisfying full-domain (1) below (2), or below (3) with
separable omega, would decisively falsify this theorem. A smaller dilation
under a weaker domain would not. Initial state preparation, coherent block
control, precision, ancilla dimension, correlations, reuse error, hardware
cost and acquisition remain charged. Mission NOT_ACHIEVED; practical utility,
physical validation, historical novelty and external acceptance UNKNOWN.
