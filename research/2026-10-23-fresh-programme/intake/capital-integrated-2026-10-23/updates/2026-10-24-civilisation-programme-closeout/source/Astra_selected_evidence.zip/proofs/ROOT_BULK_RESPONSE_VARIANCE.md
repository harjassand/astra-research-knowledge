# Exact bulk variance controls the full coherent response

23 October 2026. W56 found the exact variance identity while root was independently seeking a replacement for the old exponential response estimate. Root reconstructed the argument below from the original unitary; W49 also independently reconstructed it. This is an internal mathematical result for the pinned recurrent-tree model. It does not establish a new capacity constant or a physical operation.

Write (N_E) for tree depth, (Q=\sum_i q_i) for input charge, (a=1-b), and (W=V_k\cdots V_1). The complete binary charge-pattern pinching is (\mathcal P_X); total-charge pinching is (\mathcal P_Q). All bath statements below are compressed to initial depth at least (k), so no history can encounter the root before its last call. The full depth increment is

\[
G=W^*(I\otimes N_E)W-I\otimes N_E,\qquad D=a(2Q-kI)\otimes I.
\]

The increment (G) is a bounded self-adjoint operator, with norm at most (k), even though depth itself is unbounded. Equivalently (G=W^*[N_E,W]). Compression to the bulk is made only after the full products are formed; one must not insert a bulk compression between two factors of (G).

For a fixed input charge pattern (x\in\{0,1\}^k), put (s_i=2x_i-1). Expand each actual call as a move (\sqrt a\,U) or a stay (i\sqrt b\,I). In the bulk, a move flips that call's binary charge. Thus two distinct move masks have orthogonal **output charge patterns**, including when input colors or the bath are coherent. For each mask, its color-and-bath history is isometric on this input-pattern/bulk subspace: the move is the original unitary, and no root (00) move is encountered. Its squared amplitude is precisely the product Bernoulli weight.

Consequently the first and second displacement moments on this entire color/bath block are the moments of (\sum_i s_i B_i), with independent (B_i\sim\mathrm{Bernoulli}(a)). This is an operator identity, not a sampled bath expectation:

\[
P_x G P_x=a(2|x|-k)P_x,
\quad
P_xG^2P_x=\{a^2(2|x|-k)^2+kab\}P_x.
\]

The second identity also follows directly from (G^2=[N_E,W]^*[N_E,W]), avoiding any mistaken insertion of a compression. Since (D) is scalar on each complete pattern,

\[
\mathcal P_X(G-D)=0,\qquad
\mathcal P_X[(G-D)^2]=kabI. \tag{1}
\]

Set (Z=\mathcal P_Q(G-D)). On a pattern (x), the diagonal block of (Z^2) is the sum of ((G-D)_{xy}(G-D)_{yx}) over patterns (y) having the same total charge. Each summand is positive. It is a subset of the summands defining the diagonal block of ((G-D)^2). Hence

\[
\mathcal P_X(Z^2)\le kabI. \tag{2}
\]

Let (\sigma=\mathrm{diag}(1/2,1/4,1/4)^{\otimes k}), and let (Y=Y^*) preserve total charge. Thus (Y) commutes with (\sigma), which is scalar in each total-charge sector. Write (Y_0=Y-\mathcal P_XY). With the UCP input expectation (\mathbb E_\sigma(A)=\operatorname{Tr}_{\rm in}[(\sigma\otimes I)A]), pattern and charge pinching give

\[
\mathbb E_\sigma(Y_0G)=\mathbb E_\sigma(Y_0Z),\qquad
\mathbb E_\sigma(Y_0^2)=\|Y_0\|_{2,\sigma}^2I,
\quad\mathbb E_\sigma(Z^2)\le kabI.
\]

UCP Cauchy--Schwarz therefore yields the **full bath operator-norm bound**

\[
\boxed{\|\mathcal D_b(\sigma Y_0)\|_\infty
 \le\sqrt{kab}\,\|Y_0\|_{2,\sigma}.} \tag{3}
\]

Here (\mathcal D_b) is the original depth-drift response, with the same sign convention as (G). This applies to arbitrary coherent initial bath vectors in the bulk, and hence to arbitrary states supported there. It is not a statement at the root, nor an acquired physical bath preparation.

At (r=bk), the new response constant is (\sqrt{ar}). It can be combined with the previous small-(r) bound by taking the smaller proved constant. In particular the previous (r\exp(2r^2)) amplification is unnecessary for clipping remainders and the exponential charge-tilt correction, provided their total-charge preservation and zero complete-pattern pinching are retained.

For the positive clipped source (F\), exponential tilt (T), and actual pair score (K), the earlier drift interface becomes

\[
\mathcal D_b(\sigma TF)\le
\{2a\delta-\gamma w+\gamma\epsilon_k
 +\sqrt{ar}[e+\|T-I\|_{4,\sigma}\|F-I\|_{4,\sigma}]\}I,
\]

where (w=\operatorname{Tr}\sigma K^2), (e=\|F-I+\gamma K\|_{2,\sigma}), and (\epsilon_k) is the independently proved scalar-response error. No new capacity gain is inferred from this interface. A sufficiently strong lower bound on actual-score variance at large (r), and a complete entropy/drift/coding transfer, remain load-bearing open obligations. Existing reviewed rate floors are unchanged.
