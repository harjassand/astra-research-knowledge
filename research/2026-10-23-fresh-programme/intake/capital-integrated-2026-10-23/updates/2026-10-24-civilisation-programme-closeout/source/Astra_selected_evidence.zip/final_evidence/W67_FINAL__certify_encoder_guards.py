"""Exact selected scalar guards for the UNREVIEWED mesoblock candidate.

Never constructs the exponentially large charge ranks, probability table,
random frame, signal phases or code. Polynomial-count outputs are symbolic
primitive envelopes; they are not executed native hardware counts.
"""
from fractions import Fraction as F
from pathlib import Path
import json

OUT = Path(__file__).with_name("ENCODER_FORWARD_GUARDS.json")
G = F(1, 18600)
KAPPA = F(1, 288000)
CCHI = F(1, 25600)
Z = F(1, 1000)
ETA = F(1, 100)
ETAW = ETA / 32


def ceilq(x):
    x = F(x)
    return -(-x.numerator // x.denominator)


def clog2(x):
    x = F(x)
    if x <= 1:
        return 0
    a = x.numerator.bit_length() - x.denominator.bit_length()
    return a if F(2) ** a >= x else a + 1


def dyad_upper_count(exponent, multiplier):
    """Keep very large query counts as exact, evaluable symbolic dyadics."""
    return {"upper_bound": f"2^{exponent} * {multiplier}",
            "log2_upper_integer": exponent + clog2(multiplier),
            "power_two_exponent": exponent, "integer_multiplier": multiplier}


def sign_policy(gap, xi):
    # Frozen explicit tanh/Chebyshev policy, with exact rational gap.
    delta = xi * xi / 32
    epsilon = delta / 8
    a = clog2(4 / epsilon)
    kval = ceilq(F(a) / (2 * gap))
    b = clog2(16 * kval / epsilon)
    n = 5 * kval * b
    n += (n + 1) % 2
    assert n % 2 == 1
    return {"delta": delta, "epsilon": epsilon, "a": a, "k": kval,
            "b": b, "n": n, "Q": 4 * n + 4}


def one(beta_den):
    bphys = F(1, beta_den * beta_den)
    k = beta_den * beta_den // 5
    assert k >= 3276 and bphys <= F(1, 16384)
    assert k == (1 / (5 * bphys)).numerator // (1 / (5 * bphys)).denominator
    B0 = clog2(F(2**30 * k**6) / (G * KAPPA))
    eps = F(1, 2**B0)
    t = 1
    while True:
        w = ceilq(2 * CCHI * t) + 1
        B = (k * t + 1) * (2 * w + 1)
        entropy_loss = clog2(B) + 2 * B0 + 32
        if CCHI * t >= B0 + 4 and entropy_loss <= t * G / 8 and eps * (4 * k + 1) <= G / 16:
            break
        t *= 2
    Bp = clog2(128 * B / eps)
    pmin = F(1, 2**Bp)
    Bmu = Bp + 2 * w + 3
    mu_min = F(1, 2**Bmu)
    ell_min = k * t - Bp - 2 * (w + 1) - 2 * B0 - 24
    D_log_lower = k * t - Bp - 2 * (w + 1)
    Einner = 2 * k * t
    assert ell_min > 1 and B * pmin <= eps / 128
    # Fixed number of attempts, each with a bounded fair-bit seed.
    s = 1 << clog2(128 * k * k / (G * G) * clog2(1 / ETAW))
    tL = KAPPA / (8 * k * k)
    Ctail = 6 / (KAPPA * tL)
    BCtail = clog2(1 + Ctail)
    Bz = clog2(1 / Z)
    Beta_parent = clog2(32 / ETA)
    B_eta_outer = clog2(32 / ETA)
    loop_rows = []
    while True:
        msource = s * t
        nbody = k * msource
        BR = clog2(16 * nbody)
        R = 2**BR
        Bq = 48 + 4 * BR + 4 * Bz
        q = F(1, 2**Bq)
        H = ceilq((5 * eps * s + 2 * ETAW + BCtail + Bq + Beta_parent + 4) / tL)
        flush = 16 * (H + Bq + 4)
        A = Bq + 8
        initial = 16 * (A + Bq + 4)
        total = nbody + flush + initial
        ellparent = (s * t * (F(3 * k, 2) + G / 2)).numerator // (s * t * (F(3 * k, 2) + G / 2)).denominator
        ellcode = ellparent - Bq
        target = F(3, 2) + G / (16 * k)
        rate_margin = ellcode - target * total
        passes = flush <= nbody and rate_margin >= 0
        loop_rows.append({"s": s, "nbody": nbody, "flush_le_body": flush <= nbody,
                          "rate_margin_nonnegative": rate_margin >= 0})
        if passes:
            break
        s *= 2
    assert s * G * G / (128 * k * k) >= clog2(1 / ETAW)
    B_eta_frame = clog2(32 * s / ETA)
    hinner = Einner + B_eta_frame + 3
    assert ell_min >= clog2(hinner)
    denom_rhs = Einner + B_eta_frame + 2 + 2 * hinner * (B0 + Bmu)
    assert D_log_lower >= clog2(16 * denom_rhs)
    # First denominator guard follows from q_inner<=2^-20 tau^2 mu.
    assert eps * eps / 2**20 <= F(1, 128)
    Bdes_inner = B_eta_frame + 2 + 2 * hinner * (Einner + B0 + Bmu + 1)
    pinner = 2 * hinner
    M_inner = 8 * pinner * (Einner * pinner + Bdes_inner + 3)
    seed_inner = M_inner * (2 * Einner + clog2(2 * pinner)) + 2 * Einner
    # Outer full Fourier/common-KL scalar guards, no physical gain grid.
    houter = ellparent + 2 * BR + B_eta_outer + 8
    assert ellcode >= clog2(houter)
    assert Bq >= 12
    outer_denom_rhs = ellparent + 2 * BR + B_eta_outer + 10 + houter * (Bq + 4)
    assert ellparent >= clog2(16 * outer_denom_rhs)
    B_eta_per_B = B_eta_outer + 2 * BR + 1
    Bdes_outer = B_eta_per_B + 2 + 2 * houter * (ellparent + Bq + 2)
    pouter = 2 * houter
    M_outer = 8 * pouter * (ellparent * pouter + Bdes_outer + 3)
    seed_outer = M_outer * (2 * ellparent + clog2(2 * pouter))
    sqrtq = F(1, 2 ** (Bq // 2))
    assert Bq % 2 == 0
    omega = 128 * R * sqrtq
    ubad = 2 * q + R * omega
    assert R * omega <= Z * Z / 256**2
    assert ubad <= Z * Z / 256**2
    qA = F(1, 2**A)
    assert 16 * (q + qA) <= (Z / 32) ** 2
    sig = sign_policy(Z / (256 * R), Z / 128)
    assert sig["Q"] == 4 * sig["n"] + 4
    # Full source encoder accuracy is reduced for every row invocation.
    Ienc = sig["Q"] + 1
    xi_parent = Z / (2**12 * Ienc)
    xi_inner = xi_parent / (8 * s)
    B_xi_inner = clog2(1 / xi_inner)
    # Conservative majority/polar bound: gap>=2^(-ceil((Bmu+2)/2)).
    # Its query degree is <=2^(2*Bgap) times a polynomial in signal bits.
    Bgap = (Bmu + 3) // 2
    Bsig = 2 * B_xi_inner + 32
    # For majority degree, a safe upper is 2^(2Bgap)*8(Bsig+1),
    # with four row queries per signal step and an extra four calls.
    Q_inner_bound = dyad_upper_count(2 * Bgap, 64 * (Bsig + 1))
    phase_inner_log2 = 3 * Q_inner_bound["log2_upper_integer"] + 16 * clog2(Bsig + Bgap + 2)
    # Each table cell has bounded additive error; counts use exact powers.
    Bstat = clog2(64 * B / ETA) + 1
    ntable = 8 * (128 * 2 ** (B0 + Bp)) ** 2 * Bstat
    Bcdf = clog2(128 * B / (eps * pmin))
    table_bits = B * (Bcdf + Bstat + 2)
    cell_seed_bits = 2 * s * Bcdf
    prefix_seed_bits = 2 * k * s * t
    all_seed_bits = s * seed_inner + seed_outer + cell_seed_bits + prefix_seed_bits
    assert ellcode >= target * total
    assert target - F(3, 2) >= bphys / 59520
    return {
        "beta_denominator": beta_den, "b": bphys, "k": k,
        "source_gain_lower": G, "source_drift_lower": KAPPA,
        "chi_squared_upper": CCHI,
        "B0": B0, "eps": eps, "t_mesoblock": t, "w_bin": w,
        "table_cells_upper": B, "entropy_loss_bits_upper": entropy_loss,
        "Bp": Bp, "Bmu": Bmu, "ell_min": ell_min,
        "D_log_lower": D_log_lower, "E_inner": Einner,
        "s_mesoblocks": s, "m_source_blocks": msource,
        "h_inner": hinner, "Bdes_inner": Bdes_inner,
        "pauli_inner_steps": M_inner, "seed_one_inner_upper": seed_inner,
        "t_L": tL, "C_tail": Ctail, "log_F_upper": 5 * eps * s + 2 * ETAW,
        "B_R": BR, "R_outer": R, "Bq": Bq,
        "body_depth_cutoff": H, "initial_cutoff": A,
        "forward_initial": initial, "forward_body": nbody,
        "forward_terminal": flush, "forward_total": total,
        "parent_width": ellparent, "outer_width_loss": Bq,
        "logical_width": ellcode, "target_rate": target,
        "exact_rate_margin_bits": rate_margin,
        "h_outer": houter, "Bdes_outer": Bdes_outer,
        "pauli_outer_steps": M_outer, "outer_seed_upper": seed_outer,
        "sign_degree_outer": sig["n"], "row_queries_outer": sig["Q"],
        "whole_encoder_invocations": Ienc,
        "parent_encoder_accuracy": xi_parent,
        "one_inner_accuracy": xi_inner,
        "inner_polar_query_upper": Q_inner_bound,
        "inner_phase_classical_log2_envelope": phase_inner_log2,
        "table_sampling_source_experiments_upper": ntable,
        "source_blocks_used_by_table_upper": t * ntable,
        "probability_table_output_bits_upper": table_bits,
        "cdf_sampler_bits_per_cell": Bcdf,
        "cell_sequence_seed_upper_two_attempts": cell_seed_bits,
        "fixed_public_prefix_seed_upper": prefix_seed_bits,
        "all_random_seed_bits_upper": all_seed_bits,
        "earlier_s_policy_trials": loop_rows,
        "guards_passed": True,
    }


def serial(x):
    if isinstance(x, F):
        return str(x)
    raise TypeError(type(x))


def main():
    rows = [one(d) for d in [128, 512, 2048]]
    result = {"status": "PASS", "scope": __doc__,
              "not_executed": ["giant ranks", "probability tables", "quantum table sampling", "random frame circuits", "polar phases", "physical communication"],
              "source_and_native_assumptions": "Analytic V4 plus acquired relative-operator/log/filter access; exact source/encoder random-ensemble proof and stable full-unitary compilation require fresh review.",
              "rows": rows}
    payload = json.dumps(result, default=serial, indent=2) + "\n"
    if OUT.exists():
        if OUT.read_text() != payload:
            raise RuntimeError("refuse overwrite of different frozen result")
    else:
        OUT.write_text(payload)
    print(json.dumps({"status": "PASS", "rows": [{"d": r["beta_denominator"], "k": r["k"],
          "t": r["t_mesoblock"], "w": r["w_bin"], "Bmu": r["Bmu"],
          "forward_total": r["forward_total"], "s": r["s_mesoblocks"]} for r in rows]}))


if __name__ == "__main__":
    main()
