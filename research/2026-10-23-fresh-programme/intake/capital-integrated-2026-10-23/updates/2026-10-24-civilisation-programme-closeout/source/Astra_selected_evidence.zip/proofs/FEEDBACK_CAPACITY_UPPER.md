# Fixed-horizon backward quantum feedback: an exact comb extension

Worker w36, 23 October 2026. Version 3 (adds the classical-data corollary to the reviewed quantum theorem). Status: **internal derivation; fresh w17 reconstruction found no blocker in frozen V1/V2**. This is not external validation. Version 1 is preserved verbatim as `FEEDBACK_EXTENSION_V1.md`, SHA256 `6207ab3c900911bf4d4196097f97f0f9982e23e57dd7a86c8d6d61e2375b2601`; Version 2 as `FEEDBACK_EXTENSION_V2.md`, SHA256 `f532d88b454f974c4ea4e6333a7357c2d1d9b176f09cfceb23c53f11dc04112b`. The generic comb/replacer argument is established methodology; historical priority of its application to this exact recurrent device is UNKNOWN. No physical implementation or useful code follows.

## 1. Claim and precise interface

Let the actual seeded-tree device, initialized independently in tau_pi, have its chronological N-port channel N_N. The independently audited input is w49's frozen `PROOF_V4.txt`, SHA256 `ccd777dd4daea424e19d6b8fd4e8c6842fb7f0614aa0fb325cc1744fe532da11`, copied locally as `W49_PROOF_V4.txt`. Its global theorem is unchanged from V3. V4 repairs V3's overly broad invariant-class wording: radial diagonal operators are an invariant class for the positive bath transfer. This worker's original independent reconstruction already used the sufficient narrower cone of diagonals invariant under the global seed flip, which also contains all shell inputs and remains invariant; mere equality at the two roots is insufficient on its own. The V3 audit and exact bytes are retained. With b=beta^2 and

    sigma_* = diag(1/2,1/4,1/4),
    C_N(b) = 2(N+1)(8+2b)^N,

that proof gives the GLOBAL Choi/CP inequality

    N_N <=_CP C_N R_N,
    R_N(X) = Tr(X) sigma_*^{tensor N}.                         (1)

The present extension uses all of (1), rather than only an ordinary-code fidelity inequality. Both sides are chronological deterministic N-combs. The actual bath is reused without observation, intervention, reset, or replacement between calls.

Consider quantum DATA TRANSMISSION from an Alice input M of dimension K to Bob's final output Mhat of dimension K. Initially

    Phi_RM tensor omega_A0B0 tensor tau_pi,E,                  (2)

where Phi is a normalized maximally entangled state, R is untouched, and omega is any Alice/Bob shared resource state. Thus the unknown logical input and its external reference are independent of all supplied shared resources and the bath. A purifier of tau_pi is inaccessible to both laboratories. A purifier of omega may be retained locally or externally; this does not affect the proof.

Between the N prescribed chronological calls, Alice and Bob may perform arbitrary local CPTP maps, keep quantum memories, measure, condition on outcomes, and send arbitrary noiseless QUANTUM messages from Bob to Alice. Classical feedback is included. Bob may send messages before the first call as well. There is no Alice-to-Bob wire except the N qutrit inputs/outputs of the device, including no free forward classical message, timing signal, delivered branch flag, or uncounted carrier. The protocol and final decoder are deterministic CPTP after summing outcomes. A reported accepted branch cannot be divided by its success probability.

The core theorem permits arbitrary finite ancillary dimensions, with no bound uniform in N or K. Its finite-horizon normal-state extension is stated separately in Section 8. All N forward calls count, even dummy calls after a local stop. The prescribed schedule is fixed. A random expected-use budget is a different model and is not asserted here.

**Theorem.** Every strategy with this interface has entanglement fidelity

    F_e <= min{1, C_N(b)/K^2}.                                (3)

Therefore the same threshold

    C_up(beta) = (1/2) log2(8+2 beta^2)
               = 1.5 + (1/2) log2(1+beta^2/4)                 (4)

bounds fixed-horizon forward quantum data transmission even with arbitrary backward quantum feedback and arbitrary initial shared entanglement. Equation (3) is an exponential strong converse for the actual tau_pi above this threshold. It does not assert equality with the unassisted capacity or that feedback cannot improve the exact coefficient.

## 2. Choi convention and causality

Use unnormalized input maximally entangled vectors. The prefix channel Choi operator J_m is positive on A_1 B_1 ... A_m B_m, with J_0=1, and satisfies

    Tr_{B_m} J_m = I_{A_m} tensor J_{m-1}.                    (5)

Tensor orders in (5) may be related by a fixed permutation. Future inputs do not influence past outputs because the physical process consists of sequential interactions with a fixed initial bath. This remains true for an infinite-dimensional bath: the input/output Choi spaces are finite-dimensional and the bath has been traced out. The product-replacer comb has

    J^R_m = I_{A_1...A_m} tensor sigma_*^{tensor m},

and obeys the same recursion and J^R_0=1. In particular Tr J_m=3^m, not 1.

The finite-dimensional deterministic-comb characterization says positivity plus (5) is necessary and sufficient for a sequential memory-channel realization. This is the standard comb theorem, not a new realization principle. See Chiribella, D'Ariano and Perinotti, [A theoretical framework for quantum networks](https://arxiv.org/pdf/0904.4483), Theorem 5, equation (40).

## 3. The normalized difference really is a deterministic comb

Fix ONE full horizon N and put C=C_N. Do not replace C by a different C_m at a shorter prefix. By (1),

    J^D_N = (C J^R_N - J_N)/(C-1) >= 0.                      (6)

Define algebraically at every prefix

    J^D_m = (C J^R_m - J_m)/(C-1),   0<=m<=N.               (7)

Applying (5) to (6) and (7) gives

    Tr_{B_m} J^D_m = I_{A_m} tensor J^D_{m-1},
    J^D_0 = (C-1)/(C-1) = 1.                                (8)

Positivity of each prefix follows downward from positivity of the full operator: partial trace is positive, so I_{A_m} tensor J^D_{m-1} >=0, hence J^D_{m-1}>=0. Thus every requirement of the deterministic-comb characterization is satisfied. A negative or horizon-dependent prefix normalization has not been hidden.

There exists a deterministic memory process D with these Choi operators, and as full combs

    R_N = (1/C) N_N + (1-1/C) D_N.                           (9)

D is a mathematical comparison process; no ability to implement or control it is supplied to the actual parties. Its existence is used only to preserve order under a legal strategy. C>1 here; the trivial C=1 case would give equality of the two normalized combs.

## 4. Legal strategies preserve this order without a dubious transpose claim

Fix the entire physical strategy S, including its initially shared state, local maps, memory dimensions, quantum feedback wires, and final TP decoder. Closing any deterministic N-comb into this chronological strategy produces a CPTP channel M->Mhat. Let these channels be Lambda_N, Lambda_R and Lambda_D for the three combs in (9).

Physical circuit contraction is linear in the inserted comb. Therefore

    Lambda_R = (1/C) Lambda_N + (1-1/C) Lambda_D,

and since Lambda_D is CPTP,

    Lambda_N <=_CP C Lambda_R.                              (10)

This proof does not assume that a partially transposed link-product formula is an arbitrary positive map on arbitrary matrices. It uses a convex decomposition into TWO NORMALIZED PHYSICAL COMBS and linearity of the fixed physical circuit. The strategy may adapt quantum coherently; it need not admit a frozen classical transcript. Initial shared entanglement is simply a fixed part of S, independent of R M as in (2).

## 5. The inserted forward replacer yields a normalized logical replacer

It remains to prove the logically essential directionality statement; normalization alone is insufficient.

Run the same strategy with the product-replacer comb. We show inductively that R is product with ALL quantum systems currently held by Bob. This holds initially by (2). An arbitrary Alice-local TP map, including discarding the next device input, cannot alter the reduced state on R and Bob. A replacer call obeys

    (id_X tensor R_sigma)(eta_XA) = (Tr_A eta_XA) tensor sigma_B.

Consequently the newly delivered B is independent of R and all previously held Bob systems. Bob-local operations preserve product form with R. If Bob splits off and sends a quantum system back to Alice, tracing that sent system out of his laboratory preserves the product form on R and his retained systems. This establishes the induction after every operation and every call. Deferred measurement registers and classical feedback are covered by the same CPTP reasoning.

For every initial state eta_RM, the final reduced state consequently has the form

    eta_R tensor zeta_Mhat,

where zeta depends on the fixed strategy and its resources but not on the logical input. Thus

    Lambda_R(X) = Tr(X) zeta,   Tr zeta=1.                    (11)

The conclusion also follows directly from the absence of an Alice-to-Bob causal path in this comparison network. Shared entanglement and backward quantum messages do not create such a path. The induction explicitly retains Bob's measurement records, so no missing transcript factor or normalization appears.

The initial independence in (2) is essential. If Bob initially held part of the unknown logical reference resource, this would be a different transmission task. The argument does not count generating already supplied entanglement as transmitting fresh unknown quantum data.

## 6. The two factors of K and the strong converse

Apply (10) to Phi_RM and use (11):

    (id_R tensor Lambda_N)(Phi_RM)
        <= C (I_R/K) tensor zeta_Mhat.                       (12)

For any density operator zeta on K dimensions,

    <Phi_K| (I/K tensor zeta) |Phi_K> = Tr(zeta)/K^2 = 1/K^2.

Taking Bell overlap proves (3), with no assumption that an encoder is isometric. If log2 K >= N(C_up+delta), then

    F_e <= 2(N+1) 2^{-2 delta N}.                            (13)

All backward-message dimensions, transcript alphabets, private outcomes and shared-entanglement ranks disappear because the comparison channel is normalized. Replacing this by a sum of individually normalized accepted branches would be invalid.

The same lemma applies separately to EVERY normalized product-replacer inequality in V4, Section 5. For 1<=t<3/sqrt2 it gives

    F_e <= A_N(t)/K^2,
    A_N(t) = [2(N+1)/(3-t sqrt2)] h_b(t)^N,
    h_b(t) = 2sqrt2(1-b)(t+2/t) + b(5+2t^2+2/t^2).           (16)

The comparison one-port density operator is diag(1,t^-2,t^-2)/(1+2/t^2), so its product is normalized; Sections 3-5 apply without change. Consequently the strongest evaluated feedback-assisted threshold in this family is

    Q_assisted <= (1/2) log2 min_{1<=t<=sqrt2} h_b(t).         (17)

For 0<b<1 the minimizer is unique in (1,sqrt2). Indeed

    h_b'(t)=2sqrt2(1-b)(1-2/t^2)+4b(t-t^-3),
    h_b''(t)=8sqrt2(1-b)/t^3+4b(1+3/t^4)>0,

and the derivative has opposite signs at the interval endpoints. At b=0 use t=sqrt2, and at b=1 use t=1. In particular choosing t=1 alone gives

    Q_assisted <= (1/2)log2[6sqrt2(1-b)+9b] < log2 3

for EVERY b<1. Thus no amount of the allowed backward quantum communication or initially shared entanglement restores the full ideal-qutrit forward transmission rate unless beta=1. At beta=1 the device is exactly iI and log2 3 is achievable. This is a strict upper deficit, not an exact-capacity formula at intermediate beta. The more accurate small-beta statement (4) remains the simple quadratic upper gap. The same fixed-normal-initializer limit applies to each t.

The same assistance model also gives a classical-data corollary. For M equiprobable classical messages and any final measurement decoding the message,

    P_correct <= min{1,A_N(t)/M}.                             (18)

Indeed (10) applies to the message-to-Bob channel, while (11) makes the comparison output independent of the uniform message. Its average correct-decoding probability is exactly (1/M) sum_x Tr(D_x zeta)=1/M for a normalized POVM {D_x}. Thus the assisted classical-data strong-converse ceiling is log2 min_t h_b(t), with an exponential error-to-one above it at tau_pi and the same fixed-normal initializer limit. In particular its deficit from the ideal entanglement-assisted qutrit classical rate 2log2(3) is strict for every beta<1. This uses the same ports and backward assistance; it supplies no free forward classical wire. The classical corollary is the standard replacer-test counterpart of the Bell-test proof, not a new coding theorem or a claim of optimality.

For arbitrary finite logical-input reference eta_RM the same argument gives

    omega_R Mhat <= C eta_R tensor zeta_Mhat.

When the relevant entropies are finite, operator-log monotonicity and the relative-entropy decomposition yield I(R:Mhat)<=log2 C. This is a statement about the final logical channel. No formula identifying an adaptive physical-input entropy or the original bath's leakage follows; initial entanglement and Alice's retained systems change that bookkeeping.

## 7. Each fixed normal bath initializer inherits the threshold

This section extends the INITIALIZER, rather than permitting initial correlations between bath and laboratories. Let tau be any fixed normal bath state, possibly coherent, still independent of (2)'s laboratory/reference state. Take an increasing finite-coordinate projector P_M of maximal depth A_M, tau_M=P_M tau P_M, WITHOUT renormalization. Faithfulness gives

    0 <= tau_M <= P_M <= 3*6^{A_M} tau_pi.                   (14)

For the fixed code and feedback strategy, its unconditional fidelity is a bounded positive linear effect of the initializer:

    F_e(tau)=Tr(E_N tau),    0<=E_N<=I.

This holds for adaptive strategies as well: the complete initial state is product with tau and every physical circuit step is CPTP; Bell measurement is a bounded effect. Thus

    F_e(tau) <= 3*6^{A_M} F_e(tau_pi) + ||tau-tau_M||_1
             <= 3*6^{A_M} C_N/K^2 + ||tau-tau_M||_1.         (15)

At a rate above (4), first take N to infinity at a FIXED M, then M to infinity. Normality gives ||tau-P_M tau P_M||_1 -> 0, proving the same strong-converse limit and capacity ceiling for every fixed normal independent initializer. Codes and auxiliary resources may vary with N because (15) is uniform over their bounded fidelity effects. No tail exponent uniform over all normal tau is claimed. A horizon-dependent newly supplied initializer is not a fixed-initializer capacity and is not covered by this limit.

## 8. Ancillary dimensions and normal strategies

The core theorem already permits every finite-dimensional feedback register and resource, however large and however dependent on N. This is the standard capacity-code class and does not impose any fixed feedback bandwidth or entanglement budget.

For completeness, a prescribed fixed finite-horizon strategy on separable infinite-dimensional laboratory registers with normal states and normal CPTP maps is approximable IN ITS ACTUAL FINITE-HORIZON OUTPUT STATE by finite-dimensional strategies. One can insert finite-rank compression channels with a fixed erasure output on the laboratory registers and feedback messages. Their disturbance on the finitely many encountered normal states tends to zero; an ordered telescoping/contractivity argument bounds the final trace-distance error by the sum of finitely many such disturbances. Finite-dimensional input/output code spaces make the entanglement-fidelity effect continuous. Approximate an initially normal shared resource by finite-rank states as well. Each approximant is a legal deterministic strategy and obeys (3); taking the limit preserves (3).

This approximation is for a fixed prescribed finite-horizon normal process, not a uniform finite-energy or computational-cost bound. To avoid unmodeled accumulation, a strategy is required to have finitely many physical communication stages between successive device calls, or to be a well-defined trace-norm limit of such stages. Non-normal states and an unspecified infinite sequence of operations in finite time are not supplied.

## 9. Classical transcript cross-check and direct diagnostics

The pinned original `cycle-01/pro1/FEEDBACK_AND_STOPPING.tex`, lines 144-187, already freezes a complete classical Bob transcript. In that narrower model, with no initial Alice/Bob shared entanglement, the strategy has

    Lambda = integral D_t o N_N o E_t dmu(t),

with E_t CPTP, D_t CP and integral D_t CPTP, WITHOUT conditioning branch outputs to trace one. Inserting (1) removes E_t because it is TP, and integral D_t(sigma_*^N) is a density operator. This independently reproduces (10)-(11) for classical feedback. The comb proof above is needed for the stronger coherent backward-message interface.

`feedback_extension_check.py` independently simulates direct two-call classical-adaptive circuits from this worker's exact seeded-tree simulator. It does not use a peer's implementation. It retains a mixed first encoder's two private Kraus outcomes, a genuine two-outcome weak measurement on Bob's first qutrit, outcome-dependent two-Kraus second encoders, and a multi-Kraus final decoder. Initial bath states are exact full shells H=0,1. Sixteen cases cover beta=0,.02,.4,1 and logical dimensions K=2,3; there is no reflecting bath cutoff. Actual transcript probabilities depend on the logical input in several cases.

All assertions passed. Direct chronological and frozen-transcript Kraus operators agree within 1.02e-16. Whole-protocol TP error is at most 3.21e-15; the comparison Choi equals I_K tensor zeta within 2.34e-15; comparison Bell overlap is 1/K^2. Each actual adaptive logical Choi obeys CP domination using the DIRECT physical channel's exact finite-shell coefficient relative to sigma_*^2, rather than relying on the loose analytic large-N prefactor. Raw evidence is `FEEDBACK_DIAGNOSTIC.json`. These are finite synthetic numerical diagnostics; all-horizon validity rests on Sections 2-7, not on the tests.

An additional independent coherent-circuit diagnostic is `quantum_feedback_check.py`, raw `QUANTUM_FEEDBACK_DIAGNOSTIC.json`. It uses an initially shared EPR pair, a Haar-random Bob unitary that splits the first output and Bob's resource half into a two-dimensional QUANTUM backward message and retained memory, and Alice's coherent response before the second call. All first encoder, response and final decoder operations are isometries with explicit discarded environments. It compares direct chronological exact-bath amplitudes against full comb contraction for every bath endpoint and all discarded registers. It constructs the normalized difference comb using the exact full-shell coefficient and explicitly verifies its affine prefix normalization, its TP channel after coherent feedback, and the convex-mixture equality.

All sixteen cases (the same H,beta,K grid) passed: maximum direct-vs-link operator residual 1.91e-16, difference-prefix residual 2.70e-16, difference-strategy TP error 2.33e-15, comparison product-Choi residual 1.74e-15, and linked convex-mixture residual 1.71e-13. Dephasing the backward message changes the resulting logical Choi by at least 0.0363, so the test does exercise coherent return information. Finite diagnostic scope is unchanged.

## 10. Primary-literature challenge and exact claim boundary

The generic mechanism is not claimed as new. Chiribella, D'Ariano and Perinotti's [comb framework](https://arxiv.org/pdf/0904.4483) supplies the normalization/realization theorem. Cooney, Mosonyi and Wilde's [strong-converse paper](https://arxiv.org/pdf/1408.3373) develops quantum-feedback-assisted communication converses through comparison with replacer channels for repeated memoryless channels. It is a close primary-method predecessor. The present inference uses an already bounded SINGLE recurrent N-comb; it does not replace its reused bath by independent channel copies or import a single-letter memoryless capacity theorem.

Bowen's [Quantum Feedback Channels](https://arxiv.org/pdf/quant-ph/0209076) defines unrestricted noiseless backward quantum feedback and discusses capacity increases in unassisted examples. Therefore there is no general feedback-useless claim here. Only the evaluated upper threshold survives feedback. The exact assisted capacity and any advantage below this threshold remain unresolved.

The supplied upper theorem is conditional on the exact device algebra and actual tau_pi shell law audited in `QUADRATIC_AUDIT.md`. If the separately inherited unassisted lower theorem is correct, allowing feedback cannot remove that lower bound, so the assisted gap also has order Theta(beta^2) for the same small-beta interval. This statement is conditional on that separate lower proof; this worker has not independently audited it.

Resources: all N qutrit calls are charged. Classical or quantum backward communication and initial entanglement are ideal free assistances in this UPPER-BOUND model; their finite-precision realization, energy, bandwidth, memory, synchronization and laboratory preparation cost are not supplied as a practical construction. No bath reset or return is assumed or acquired. No physical experiment, purchase, equipment action, external communication or disclosure occurred. This theorem does not supply an efficient encoder, exact coefficient, measured experimental advantage, computational acceleration, physical bath, or mission completion.

The crucial falsifiers are failure of the underlying global CP inequality or chronological causality, a free Alice-to-Bob side channel, initial logical-resource/bath correlations violating (2), postselection renormalization, or changing fixed-N accounting to an expected-use rule. Fresh critic w17 independently read the frozen V1 proof and reported no blocker in the normalized-comb argument, the R/Bob product induction, or the finite-horizon normal-auxiliary compression; he requested the V4 provenance correction incorporated above. This internal cross-review does not establish external correctness or historical priority, which remain UNKNOWN.
