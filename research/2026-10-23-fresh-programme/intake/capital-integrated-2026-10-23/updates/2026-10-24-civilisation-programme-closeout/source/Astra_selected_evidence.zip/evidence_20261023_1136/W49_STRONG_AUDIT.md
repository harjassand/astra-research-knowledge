# Full hash-specific beta0 all-resource strong-converse audit

Verdict: **ACCEPTED_INTERNAL_FULL_HASH_SPECIFIC_ANALYTIC_AUDIT** of w19
`coherent_initializer_invention/strong_converse_extension/FULL_STRONG_CONVERSE_V1.md`,
SHA256 `1f5997c7ba33c13e6f1a1a9f1cff183d68bad1a876b63f1c7a6ef3989bed16c7`.
The entire frozen full source was read after the earlier independent seed
reconstruction. No blocking defect was found in Sections1--8 or T1--T9.
This is internal scientific criticism, not external or formal validation.

The complete independent reconstruction, including additional aggregation,
is frozen at own `SECTOR_COUNTER_SEED_FRESH_AUDIT_AND_AGGREGATION.md`,
SHA256 `d68af2c1f6535e5ca9a9fe0883490ac32b7e088d8aaa05a31c7316915da48d25`.
That file identifies w19's independently frozen seed
`d29859360d62c5c72e78563076a1b964334e939a83e3b7e0b3ffc624d555d683`
as the source of the construction. The later full source adds the same
necessary linear-link, normalization and normal-resource arguments explicitly.

## Decisive checks of the full source

T2 is a positive CP map on the finite port Choi operator: after purification,
network contraction is linear in a port amplitude, so J maps to LJL*, with
environments retained or traced afterward. The finite-dimensional domain
makes L bounded for normal infinite resource Hilbert spaces. No positivity
of a partial transpose and no deterministic-comb normalization of the
sector/difference is assumed. Only the replacer comparison must be a causal
TP process. This is independently proved in the own frozen reconstruction.

The coherent wire counter's final amplitude is the total-type projector
P_q, hence its finite-port Choi is exactly |Omega_q><Omega_q|, including
adaptive use. The counter is part of the wire process; feedback remains in
the fixed linking strategy. The rank-one order uses norm squared D_q,
giving the necessary D_q^2 factor relative to P_q/D_q. Summing sectors is
a physical counter instrument, but is not equated with the original identity
wire. The original amplitude is recovered by coherent summation, as T6
states; this is the correct role of the finite-sector Cauchy bound.

The hard support q+o<=N follows from the ACTUAL beta0 block zero whenever
both physical port symbols are colored. This includes the original root
block and is independent of the bath state, depth, coherences or initial
laboratory entanglement. The counter charges at different calls need not
commute as operators on the underlying adaptive state; the proof uses
chronological port tensors and their coherent histories instead.

T8 and T9 keep one fixed comparator as the OTHER counter varies. Its N
outputs may be correlated; they are preprepared independently of the fresh
source and delivered causally. There is no forward signal after replacement,
so the COMPLETE TP comparison gives I_R/K tensor omega_Bob. Selected
counter branches are positive and bounded by this product. This handles
sender-side postselection and arbitrary initial resource entanglement.
The other counter is not fed into any original control, so the comparison
retains one common strategy/decoder for the complete sum.

The full source correctly stresses that the sender sum is over EVERY
q=0,...,N, INCLUDING q+o>N branches that were forbidden in the original
physical U process but can arise after replacement. Summing only the
originally allowed triangular subset would not justify TP normalization.
Both fresh-source independence from the ENTIRE initial resource and the
sole-forward-port condition are indispensable. Normalizing a selected
success branch, supplying its flag for free, or allowing an initial
source-correlated resource changes the theorem's contract.

Every original F_qo is unnormalized. Both cut bounds are therefore
F_qo<=D_q^2/K^2 and <=D_o^2/K^2. The final Bell test has product probability
exactly1/K^2, with no missing factor K. The Cauchy aggregation proves T1
and yields an exponential strong converse at rates above3/2 uniformly
over arbitrary normal horizon-dependent bath/laboratory resources. Its
full-qutrit conclusion and its exclusion of beta>0 are stated correctly.

The infinite-resource argument uses only finite port and counter spaces,
a normal purified initial vector, bounded normal Stinespring maps and a
finite Bell test. Any well-defined strategy supplied as a trace-norm limit
of finite internal networks inherits the bound by continuity and uniform
constants. No bath rank, entropy, mean-depth or cutoff modulus is needed.

## Sharper aggregation cleared against the full source

The additional own triangle aggregation uses the SAME sector vectors and
cut bounds, so every full-source obligation above applies without change:

`F<=K^(-2)[sum_(q+o<=N)min(D_q,D_o)]^2`.

The own frozen proof bounded the inner sum by grouping r=min(q,o).
Root subsequently observed the grouped formula is actually EXACT:

`S_N=sum_(r=0)^floor(N/2)[2(N-2r)+1]D_r`.

Indeed if r<=s<=N-r, binom(N,s)>=binom(N,r) and2^s>=2^r,
so D_s>=D_r and min(D_q,D_o)=D_min(q,o). This exactness improves no
assumption and is not needed for the prior upper estimate.

With m=floor(N/2), e=N mod2, the ratio D_(r-1)/D_r<=1/2 gives
S_N<=(10+4e)D_m. The central-binomial-square induction in the frozen
own proof gives D_m^2<=8^N 2^(-e)/(N+1). Thus even/odd constants100/98
give

`F<=min{1,100*8^N/[(N+1)K^2]}`.

Root independently reconstructed this arithmetic before adoption.
The exact S_N^2/K^2 form is sharper than the uniform100 expression.
At dimension K=2^(3N/2) the bound tends to0 as O(1/N); this is consistent
with a capacity ceiling and does not assert achievability at the exact
boundary dimension or determine any positive-beta coefficient.

## Evidence and boundaries

Owner's six supplied finite original-device protocols are diagnostics;
this worker did not acquire or rerun them. The audit's decisive evidence
is the complete analytic network/order/normalization reconstruction.
Own `check_sector_aggregation.py` and `SECTOR_AGGREGATION_EXACT_CHECKS.json`
are finite exact arithmetic diagnostics of the additional dimension sum,
not universal network or physical validation.

No code, bath state, experimental apparatus, resource factory, finite-N
advantage, historical priority or external acceptance is established.
The previous packet's weak-converse-only status is retained as historical
evidence; this is a separately frozen later theorem and criticism.
