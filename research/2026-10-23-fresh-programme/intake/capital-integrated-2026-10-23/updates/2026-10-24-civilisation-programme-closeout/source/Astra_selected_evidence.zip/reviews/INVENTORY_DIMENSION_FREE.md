# Independent audit of the dimension-free stopped receiver

**Verdict: no fatal gap found. The shortened stopped record admits the claimed H+4 ln 2 upper deficit under the unchanged finite-source sequential coding contract. Combined with the preserved general-prior converse, it gives leading coefficient one even when D varies arbitrarily along a family with H->infinity.**

This is an additional w44 audit, 23 October 2026. The earlier `REPORT.md`, `RESULT.json`, general-prior snapshots and checks are preserved. This document does not certify external correctness or historical novelty, and no equipment, quantum circuit compilation or distillation experiment was run.

The exact w38 proof reviewed is `work/workers/w38_fresh_inventory_critic/ADDITIONAL_CONSEQUENCES.md`, Section 2, with Section 3's joint-dimension consequence. It is retained as `w38_dimension_free_snapshot.md`, SHA256 `95693b0bec3b72aed9bca5b84c5c748272a7e6121680495882e099eaf247793b`. Source HEAD remains `e606bfc587c76bdcae8b8fa3ec33e721efa2fbac`.

I reconstructed the finite-GL, geometric-record and physical-query argument before receiving w38's exact file. I did not import its code or numeric results. During the audit I found a source-specific explicit bit order that removes the existential matrix search; that lemma is proved independently below.

## 1. Exact finite-GL statement

Let h=ceil(log_2 D)>=1 and M=2^h. Embed the original labels a,b in {0,...,D-1} in h binary digits. On an actual noisy site a and b are independent uniform native D-level labels. The XOR E=a XOR b has P(E=0)=1/D, and its conditional nonzero law is denoted mu.

For invertible binary A and nonzero e, let J_A(e) in {1,...,h} be the first nonzero coordinate of Ae. The action of GL(h,2) on nonzero h-bit vectors is transitive. All fibers have equal cardinality, so for each fixed e!=0 a uniformly chosen A makes Ae uniform over the M-1 nonzero vectors. Thus

    E_A P_mu(J_A=j)=q_j=2^(h-j)/(M-1).

This applies even if mu has zeros or is highly nonuniform. There are two valid selection arguments:

1. The averaged mean is sum_j j q_j=2-h/(M-1)<2, so some fixed A has E_mu J_A<2. For this A, maximum entropy of the nonnegative integer J_A-1 gives H(J_A)<=h_geom(1)=2 ln 2.
2. Entropy concavity gives E_A H_mu(J_A)<=H(q)=eta_h<=2 ln 2, so some fixed A has H_mu(J_A)<=eta_h.

W38 correctly uses the second argument. The two existential selections need not pick the same A; the proof requires only one entropy bound, so there is no need to assert simultaneous optimality. A is chosen once using the known source law and then fixed for all queues. Random A is a proof device, not a per-queue supplied record or free initial seed. Exhaustive finite search would be admissible as an existence construction, without any efficiency claim.

The exact entropy formula is

    eta_h=[2-h/(2^h-1)]ln 2+ln(1-2^-h).

It is nonnegative and <=2 ln 2. For D=2^h, mu is uniform over nonzero vectors, so every A gives q and

    h_geom(1/(D-1))+eta_h=2 ln 2.

That exact power-of-two refinement in the candidate is valid, including D=2, where J is deterministic.

## 2. An explicit bit order for this exact white-noise source

The search over GL is unnecessary on the declared native-label white tail. Query the original digits from least significant to most significant. In a conventional most-significant-first array this is just a bit-reversal permutation matrix, so it is an admitted fixed invertible A.

Conditional on E!=0, the pair (a,b) is uniform over the D(D-1) ordered distinct pairs from {0,...,D-1}. Let J be its first differing binary digit in this least-significant-first order. For j=0,...,h,

    J>j  iff  a=b mod 2^j.

For each a, the number of distinct partners b in its residue class is at most

    ceil(D/2^j)-1 = floor((D-1)/2^j) <= (D-1)/2^j.

Therefore

    P(J>j | E!=0)<=2^-j,
    E[J]=sum_(j=0)^(h-1) P(J>j | E!=0)
        <=2-2^(1-h)<2.

Since J-1 is a nonnegative integer of mean <1, H(J)<=2 ln 2. This supplies the claimed dimension-free entropy bound with an explicit coordinate order. It makes no assertion for arbitrary nonuniform noise or an arbitrary conditional XOR law; those are the cases where the general GL selection is useful.

For independent finite verification, the exact number of ordered distinct pairs agreeing on the lowest j bits is

    N_j = r q(q+1)+(2^j-r)q(q-1),
    D=q 2^j+r, 0<=r<2^j.

Thus P(J=i)=(N_(i-1)-N_i)/[D(D-1)]. No enumeration of D^2 pairs is needed to specify this witness law. This is a classical description simplification; it does not provide an efficient quantum distillation code or useful blocklength.

## 3. The stopped flag and the actual retained state

Use either the fixed GL-selected A or the explicit least-significant-first order. At each site i, ask row bits in order and proceed only while all earlier sites and all earlier rows at that site gave zero. Stop the whole queue at the first one. Define

    V'=(U,J) if a mismatch is found at site U, row J;
    V'=* if every site passed.

A being invertible is essential: all h rows are zero iff E=0. Pure Phi_D sites have E=0, so every stopped site U is strictly beyond the realized K. The number of retained sites is n=U-1, or n=L on the * branch.

Conditioned on the mathematical K=k, each retained noisy site was projected onto E=0. Its normalized state is exactly

    chi_D=(1/D)sum_a |aa><aa|,

with probability 1/D. A true Bell site is unchanged. All relevant projectors are diagonal in the joint computational digits, and Phi_D lies entirely in their common zero sector. On the stopped noisy site, the row event has probability (1-1/D)P(J=j|E!=0). That site and the entire suffix are discarded. Independence of the noisy sites given K yields the exact retained state

    Phi_D^tensor k tensor chi_D^tensor(n-k).

The stopped row never has to be refined to the full XOR value. For q0=1/D and mu_j=P(J=j|E!=0), its finite conditional law is

    P(V'=*|K=k)=q0^(L-k),
    P(V'=(u,j)|K=k)=q0^(u-k-1)(1-q0)mu_j, k<u<=L.

The j factor cancels in the K posterior at fixed u. Hence K and J are conditionally independent given U on the stopped branch. This property is exact for nonpowers of two as well. The no-stop branch is handled separately and needs no fictitious row value.

Let G count zero-XOR sites in an unlimited mathematical noisy tail. It has P(G=g)=(1-q0)q0^g, mean 1/(D-1), and is independent of the subsequent J. The actual finite V' is a deterministic truncation of (G,J) given K. Therefore

    H(V'|K)<=H(G)+H(J)
       <=h_geom(1/(D-1))+2 ln 2
       <=4 ln 2.

The unlimited tail is an entropy proof device; the receiver never prepares, sees or uses sites beyond its actual finite queue. No realized K, U or J is initially supplied.

At fixed v, mixing the exact retained states in the actual posterior gives a maximally correlated theta_v with local marginals uniform on D^n. Entropy of a mixture gives

    I_c(theta_v)>=E[K|v]ln D-H(K|v).

Its coherent information is nonnegative because dephasing a maximally correlated state increases entropy. Averaging yields d'>=B-H(K|V').

## 4. Physical parity queries and intermediate flags

The argument must pay for the coarse nonlocal measurements; treating them as free would invalidate it. The candidate instead retains the original paid gadget. For binary local functions f(a),g(b), append one Phi_2, apply X^f(a) and X^g(b) coherently on the two ancilla halves, and measure them in the computational basis. Outcomes u,v induce the source Kraus operator

    K_uv=2^(-1/2) P_(f(a) XOR g(b)=u XOR v).

For a transformed row a_j of A, take f(a)=a_j dot a and g(b)=a_j dot b. Their XOR is a_j dot E. The same gadget implements a binary linear hash parity across any selected source queues by using the XOR of their local functions as each party's control. Every parity consumes exactly one Bell qubit. The redundant output bit is uniform and reveals no Schmidt digit; the conditional operator is a scalar times the desired sector projector.

Nonpower D creates no obstruction. These are binary functions on the original finite computational labels. They can be implemented directly as diagonal controlled gates, or after a local padding isometry with unused levels. The argument never replaces Phi_D by Phi_(2^h) or assumes a uniform distribution on padded labels.

At each of the finite Lh stages, select only copies whose prior ideal queried bits were all zero. Conditional on their individual prior zero histories, their next binary labels are iid with the known conditional law. The random active count concentrates. Binary typical-set hashing on an active string of length s costs s(H_binary+slack)/ln 2 qubit pairs. If this exceeds literal s-bit revelation, reveal the current row bits directly. Active strings shorter than sqrt(m) can also be revealed literally at total o(m) cost because Lh is fixed. All hash descriptions and matrices are generated locally and communicated; there is no free shared randomness.

For one queue the queried binary path is zeros until a final one, or all zeros, and its leaf is exactly V'. The stopped-tree chain rule consequently gives

    sum_stage P(active_stage) H(next_bit|active_stage)=H(V').

Thus the physical classification cost is H(V') Bell nats per main queue, up to an arbitrarily small rate slack, rather than the entropy of the full nonzero XOR at the stop site.

One subtlety is that decoding success can correlate the copies. The proof does not assume that an actual failed/conditioned block is iid. Generate the mathematical iid site sectors and random matrices for the ideal decision process, and bound the probability of the first decoding/count/overflow error at any of the finitely many stages. Couple physical and ideal processes until this first error. This gives one global classification bad-event probability beta_m->0.

The actual source marginal is already block diagonal in site XOR sectors (and the declared clock extension is too). Therefore the parity measurements do not dephase a missing coherence between those sectors. On the good event they produce precisely the required coarse sector flags and retained quantum states. Each queried input bit is determined by the leaf V': zero before its stopping row and one there. The extra hash values are functions of those bits, while the ancillary masks and hash seeds do not carry an additional Schmidt record. There is no hidden revelation of the full nonzero XOR. The block marginal differs from the ideal iid flagged MC block by at most its one global beta_m error; no fixed one-copy error is incorrectly tensorized.

Provide a deterministic reserve of ceil[m(H(V')+delta)/ln 2] qubit pairs. Abort with retained flags on budget overflow, atypical counts or absent/ambiguous decoding. An undetected wrong decoding is part of beta_m. Abort and failure branches output product fillers in the same fixed Bell port dimension; none is dropped or postselected.

## 5. Actual-state hashing and removal of initial aid

There are finitely many flags at each fixed D,L. On the ideal block, group equal flags and hash their actual theta_v states below their coherent information. Typical count shortfalls use the fixed product filler. The established hashing theorem for finite-dimensional iid states supplies gross yield d' and a joint Bell marginal error tending to zero; no efficient encoding or error exponent is assumed. Contractivity adds the one global classification error.

For any fixed slack delta>0, obtain a finite TP assisted block on m main queues consuming a deterministic b_m qubit pairs and producing a deterministic a_m qubit pairs on every branch, with

    b_m ln 2<=m(c'+delta)+O(1), c'=H(V'),
    a_m ln 2>=m(d'-delta)-O(1),
    e_m->0.

Here e_m is the error of the entire gross Bell output, including the pairs later retained as reserve. It is not a per-pair fidelity statement. Thus

    d'-c'>=B-H(K|V')-H(V')
           =B-H(K)-H(V'|K)
           >=B-H-4 ln 2.

If d'<=c', the desired lower rate is nonpositive and the original guaranteed-prefix receiver suffices. If d'>c', pick slack so that a_m>b_m for all large m.

The first k0>=1 source pairs factor as pure Phi_D from the complete source, including its inaccessible clock and old memory. One such pair supplies one exact Phi_2 on every measurement outcome: Alice uses P_S/sqrt(D-1) for each two-element native-label subset S, announces S, and both relabel it. The instrument is TP because sum_S P_S=(D-1)I. This is a charged use of an actual source queue, not an initially supplied ebit.

Sacrifice b_m additional queues for the first reserve, run t batches of m untouched iid queues, retain b_m gross pairs after each batch, and deliver a_m-b_m. The same finite circuit acts on approximate or failed reserves too; all branches remain. A hybrid comparison of the joint past-delivery/current-reserve Bell marginal with the ideal pure one gives error at most t e_m. Future queues are untouched and independent, and prior transcripts can be ignored by the next fixed batch. Contractivity controls propagation from an approximate reserve; there is no claim that it becomes exact after a successful-looking batch.

The total source count is t m+b_m (plus charged rounding/unused queues) and the final reserve is excluded from delivered yield. Choosing t->infinity slowly enough that t e_m->0 makes the initial reserve fraction vanish. At a fixed source b_m/m is finite, even when D or L is large. The original all-r diagonal construction supplies codes for all sufficiently large r, not just a convenient subsequence. No dimension-uniform blocklength follows.

Finally, for every output extension omega_QW with Bell marginal error e, the pure-output lift bounds

    T(omega_QW,Phi_N tensor omega_W)<=2 sqrt(e).

Applying it after the entire recycled sequence supplies the complete actual residual, including masks, hashes, clocks, old memory, decoder errors, aborted branches and the final reserve. The proof uses the actual omega_W, not a chosen reference residual. The output port rank N is deterministic on every branch throughout.

This establishes R>=B-H-4 ln 2, or Delta<=H+4 ln 2, for every finite original D,L,p under the source contract.

## 6. Joint-dimension consequence and scope

The preserved general-prior audit gives

    Delta>=max{0,H-ln(H+1)-C_D},
    C_D=c(D^-2)+ln(1+2/ln D)+2+1/D+ln(3/2).

All variable terms decrease with D>=2. In particular

    C_D<=C_*=c(1/4)+ln(1+2/ln 2)+5/2+ln(3/2)
              =5.012468686862438... nats.

Combining the two sides gives the dimension-free sandwich

    max{0,H-ln(H+1)-C_*}<=Delta<=H+4 ln 2.

Hence Delta/H->1 for every family of finite original sources with H->infinity, without a restriction on how D or the support diameter grows. Both constants are numerical and independent of D,L,p.

The rate R is still the coding limit at each fixed finite source before taking that family. The finite-error converse carries an epsilon B correction in a deficit formulation, and the receiver proof supplies no error exponent or uniform useful blocklength. A simultaneous finite-r family interpretation needs those terms and the source-dependent code/seed costs controlled separately. This audit does not silently upgrade the quantifiers.

## 7. Independent finite evidence

`check_dimension_free_receiver.py` was written independently and imports no peer code or peer numeric values. All finite probabilities, matrix averages, record normalizations and posterior identities use exact Fractions; only entropy and coherent-information logarithms use floating point.

Run:

    python3 work/workers/w44_fresh_general_prior_critic/check_dimension_free_receiver.py

Results are saved in `dimension_free_checks.json`, `dimension_free_checks.log` and `dimension_free_lsb_cases.json`:

- PASS: exhaustive GL(h,2) for h=1,2,3,4: 20,335 matrices and 303,595 nonzero-input/matrix checks. For every nonzero input, the first-nonzero-coordinate averaged law equals q exactly. Mean and entropy averaging were also checked for each D=2,...,16.
- PASS: explicit least-significant-first laws for 4,151 dimensions, including every D=2,...,4096, dimensions around higher powers of two, and large exact integers with up to 1,001 bits. The tail bound, mean bound and normalized flag law were checked exactly. For D<=129, direct enumeration of all ordered native-label pairs independently matched the residue-count formula.
- PASS: six finite truncated-record fixtures at D=2,3,5,7. They include uniform, sparse, zero-weight, deterministic and rare-heavy priors. Exact normalization, K/J conditional independence given U, binary-tree entropy cost and actual retained MC phase spectra were checked. The net d'-H(V') inequality held; fixtures with a negative net lower bound correctly require the guaranteed-prefix baseline rather than a negative-output protocol.
- PASS: 5,084 exact truth-table checks of the scaled appended-Phi2 Kraus amplitudes, for nonpower dimensions as well, including parity over two source copies. The amplitude is constant over a parity sector and zero outside it, which is the load-bearing coherence property.
- The largest observed least-significant-first stopping constant among these finite dimensions was 1.591285420737032 nats. This is a diagnostic maximum over tested dimensions, not a proved optimal universal constant. The established bound here remains 4 ln 2.

Checker SHA256 `e0ecddf12e6dad442178ba421ab8eb113a3ee1b4acd479d09cdcdb72fbb7897f`. Summary SHA256 `7d765eb92dd6064042a5ab624fa89f6469bdca2462e60728f4d636e630e91063`. The principal run took approximately 2.0 seconds on this host. These are finite synthetic mathematical checks, not verification of an asymptotic coding theorem or a quantum experiment.

## 8. Primary attribution, costs and remaining gates

The exact Eriksson v1 PDF was fetched live and its SHA256 matched `6636559ebb4d478ebc7af7aff29c72e54b98cd56093b5a0ed1b1dcaf03692994`. Its Theorem 2, pp.3–4, already gives the finite-GL first-nonzero-coordinate averaging, entropy-concavity selection of fixed A, paid parity gadget, stopped binary compression and slow reserve recycling. These are prior receiving methods and must be credited. W38 explicitly attributes them correctly. The new scope here is their application within elementary sites while retaining a variable nested Bell/MC prefix. The preprint is not peer reviewed and is not an external correctness certificate. [Exact primary version](https://airr.science/papers/ARR-2026-58XZ9SCZA39DSRF0/versions/v1/), [PDF](https://airr.science/papers/ARR-2026-58XZ9SCZA39DSRF0/versions/v1/ARR-2026-58XZ9SCZA39DSRF0-v1.pdf).

Vollbrecht and Verstraete's Section V gives an established route to removing initial entanglement assistance by source-funded pools and block reuse. The pinned proof's slow number of batches avoids needing an imported quantitative error exponent. [Primary text](https://arxiv.org/html/quant-ph/0404111v2). Devetak and Winter's Theorem 10 supplies coherent-information achievability for actual finite-dimensional iid states; it is a named external theorem, not a newly derived code in this audit. [Primary text](https://arxiv.org/html/quant-ph/0306078v1).

The downloaded PDF and the two primary HTML sources are retained with hashes in `dimension_primary_manifest.json`; a retrieval script and the load-bearing web PDF text are retained. A GitHub source-link click failed as a restricted fetch; direct primary PDF retrieval succeeded. No Firecrawl-credit retries, purchase, account change, disclosure or outreach occurred.

Supplied: the exact original source, known finite prior, known paired basis and named coding dependencies. Acquired: independent derivation, the explicit bit-order lemma, finite synthetic checks and primary reading. No experimental source/record acquisition is supplied.

At fixed source there are Lh binary stages, finite block reserves O(m) with a source-dependent coefficient, full random hash descriptions and classical communication, and source padding O(mLh). The inherited loose O(Lh^2 m^2) controlled-bit and hash-description bound remains safe. Decoding can enumerate exponentially many typical strings; gross MC code selection and finite useful blocklength are uncompiled. The explicit bit order removes the GL search and avoids D^2 pair enumeration for its witness law, but it does not remove hash coding, precision, initial-source formation or quantum implementation costs. Computing stage probabilities and rates from arbitrary-real priors still has precision/computability obligations. Dimension-free loss is not dimension-free hardware or runtime.

Critical falsifiers checked: noninvertible or wrongly chosen row map; nonzero e passing all rows; disclosure of a Schmidt digit by the parity gadget; a stop-row flag changing the retained posterior/state; charging the full-XOR entropy after coarsening or omitting row entropy; pretending failed decoded states are iid; per-copy rather than global block error; exact-reserve assumptions after recycling; missing source queues or failure branches; and replacing the complete actual residual by a convenient one. No such defect was found.

External specialist review, source-specific historical priority and any practical or physical value remain unestablished. The additive converse remainder remains O(ln H), and neither audit proves Delta>=H-O(1), exact finite-prior capacities, efficient recovery or mission achievement. Mission: NOT_ACHIEVED.
