# Independent clipped-source factory audit

W30, 23 October 2026. Scoped internal result: **the gap-free polynomial-in-inverse-error local state-preparation conclusion survives this reconstruction**, with the owner-accepted scaled inverse-block error qualification. A completely phase-table-free LCU fallback supplies the same asymptotic conclusion with much worse costs. Neither a practical factory nor physical validation is established.

The frozen W39 source is `recurrent/CLIPPED_SOURCE_POLYNOMIAL_FACTORY.md`, SHA256 `c667df6c73a6a3589055f8f23661fd3887e333f7d8094a0bfc9ff9915adf3b98`. Its additive scaling correction has SHA256 `143d8c43850233459ccebc408778d87bfe4d81e3f466971cd5150edba4a4704b`. The separately frozen phase-instrument source is outside this packet and is the next audit task.

## Strongest reconstructed claim

Given the supplied exact recurrent model, known rational b of charged bit length L_b, and the inherited H/source identities, a local quantum compiler prepares a CPTP output within full trace-norm epsilon of the V4 state Gamma J(I-gamma bH)_+J using polynomial(k,L_b,1/epsilon) gates, workspace and classical compilation. The proof is independent of a gap at the clipping kink, including exact equality at the kink. It does not require an eigenvalue table, unknown state reflection, physical inverse-bath operation, a constant-normalization H improvement, or a dimension-sized source matrix.

The normalizer gap D>=I is derived by complete-pattern pinching, and its approximating version remains at least3/4. Correctly ordered root and inverse operations are required. Operator pinching retains color fibers and needs O(k) pattern operations. Multiplying a block unitary by its adjoint without a middle signal projection would be invalid.

## Found correction and its exact scope

The source defined chi as the block error of Jtilde/2. The full output density error is bounded by8chi sqrt(M), rather than the displayed4chi sqrt(M). With the original chi<=epsilon/(64sqrt(M)), the term costs epsilon/8; the final epsilon target still holds, with total allocated error at most epsilon/2. The owner preserved the frozen source bytes and recorded the correction separately. Halving chi restores the initially allocated epsilon/16 fraction.

## Fresh derivations and evidence

`INDEPENDENT_RECONSTRUCTION.md` gives the all-k coherent-history proof of H's pair-word LCU, a finite local root-retaining simulator, complete coefficient/tilt arithmetic, operator pinching, and ordered density errors. It explicitly separates the old bk source drift window from the b-independent H access.

`ALL_LCU_FALLBACK.md` replaces inverse-QSVT phase synthesis with a bounded Lipschitz inverse-root extension, a second dyadic Bernstein approximation, Chebyshev walk LCU and paid extra normalization. With Z=Dtilde/alpha_D, f(x)=1/(2sqrt(max(3/4,alpha_D x))) is alpha_D-Lipschitz and bounded by1/sqrt3. Degree N>=(2alpha_D/nu)^2 plus dyadic samples yields block h(Z)/A_J, where A_J=2N+1. This factor appears in both the success probability and amplification cost; it is not hidden. The companion proof supplies the complete state-error budget.

All three checkers are independently written and import no producer code:

- `check_native_h.py`: exact rational original-device histories at k=2,3,4,5; full dimensions9,27,81,243. Every H entry agrees with the separately assembled pair LCU. Hermiticity, total-charge commutation, complete-pattern pinching zero, original all-U displacement, and central-binomial variances1/8,1/2,17/16,15/8 pass exactly. This finite enumeration is not the universal proof.
- `check_operator_interfaces.py`: 52 exact compressed walk powers, including endpoints and zero; middle-signal product identities; operator COPY/apply/XOR and phase-mask pinching on a two-pattern/two-color fixture. Removing the middle projection fails on the intended nontrivial fixtures, and full color dephasing differs from the correct conditional expectation.
- `check_clipping_scalars.py`: eight exact rational toy spectra, 24 Bernstein cases at degrees8,32,128, including an exact kink and distances2^-40 from it. Exact PSD/normalizer/trace identities pass. Six fixtures have noncommuting B,D. Scalar error comparisons use100-digit Decimal diagnostics, not interval certification. These fixtures are not the actual Astra H or physical experiments.

Raw matrices, source hashes and receipts are retained. The prescribed enormous factory degrees were not executed as quantum circuits; no compilation timing or measured physical cost is inferred from the small diagnostic runtimes.

## Supplied versus acquired information and full costs

Supplied: exact recurrent model U, known b and k, V4 H identities and entropy/drift theorem, and its scalar variance formula. Acquired here: primary quantum-algorithm sources, the independent algebraic reconstruction/fallback, and source-bound native/generic finite diagnostics. No laboratory observations were acquired.

M=1+gamma b k(k-1)=O(k), n=O(M^8 epsilon^-4), alpha_P=sqrt(M)(2n+1), alpha_D=alpha_P^2. The all-LCU inverse fallback uses N=O(alpha_D^2 M epsilon^-2), A_J=2N+1. Each inverse LCU costs O(N) D-block calls; each D block costs two O(n)-query root LCUs. Success is bounded below by1/(16Tmax alpha_P^2 A_J^2), and amplification costs O(alpha_P A_J sqrt(Tmax)log(1/epsilon)) full source uses. Finite coefficient tables and reversible arithmetic have polynomial bit length; their polynomial preparation cost is paid rather than replaced by free logarithmic table access. The final primitive synthesis precision is epsilon divided by the paid circuit length.

These polynomial factors are extremely large. Ordinary inverse-QSVT provides a much better inverse step, and the owner's newly separate phase-instrument factory may improve the root stage; neither improvement is silently imported into this audit's finite or all-LCU costs. Accuracy polynomial in1/epsilon is weaker than polynomial inlog(1/epsilon).

The source Γ is obtained by a charge filter with Tmax<=1801/1800. Its v_k recurrence has polynomial bit complexity. Physical beta calibration, arbitrary-real exact-floor acquisition, hardware errors/energy and useful wall time remain unresolved. The separately established mixed-Schur onset exponential in k is unchanged.

## Strong ordinary baseline and remaining boundaries

The relevant equally informed baseline already has Chebyshev-walk LCU, inverse-power matrix functions and known-source fixed-point amplification. The primary literature reopened is Childs--Kothari--Somma1511.02306v2 Section4.1, Gilyen et al.1806.01838v1 Theorem56/Corollary67, and Yoder--Low--Chuang1409.3305v2 equations1--3. Full links and scopes appear in the reconstruction. A classical3^k eigendecomposition is not the strongest incumbent.

This audit supports an internal mathematical compiler theorem, not novelty, efficient deterministic good-seed certification, an executable full encoder/decoder, a practical rate advantage, a new physical mechanism, external certification or the overall mission. No end-to-end composition is promoted by this packet alone. The next decisive task is independent review of the separately frozen phase-instrument source and its proposed source-robustness lemma.
