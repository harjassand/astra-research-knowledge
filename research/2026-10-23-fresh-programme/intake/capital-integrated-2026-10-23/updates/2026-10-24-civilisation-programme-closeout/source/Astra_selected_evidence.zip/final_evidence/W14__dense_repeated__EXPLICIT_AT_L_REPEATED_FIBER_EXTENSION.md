# Explicit degree-two acquisition at H=L when fibers repeat

Version1, 23 October 2026. New mathematical continuation; independent fresh
review PENDING. No peer was assigned another task after the team drain
instruction. Earlier strict-interval proof1272c471...9dde remains unchanged.
Classical low-weight forms and the earlier W59 contributions are credited.
Historical novelty, external review and actual large-instance realizability
of this exact repeated endpoint are UNKNOWN.

## Statement and numerical algorithm

Let P:F2^n->F2^n be explicit quadratic, K=ceil(n/2), L=2^K, w=fiber-1, and
C={w>0}. If H=L and SOME fiber has size>=3, then for n>=8 there is a NONZERO
Boolean collision annihilator of degree<=2. Together with frozen1272's H<L
result, this gives an explicit rectangular locator whenever an enumerated
square quadratic projection satisfies

    H<L, OR [H=L and maxfiber>=3].             (1)

Use direct image enumeration for n<=7 (at most128 inputs), and the ACTUALLY
ACQUIRED A_2 degree-feature algorithm on all n+1 coordinate projections for
n>=8. Every success is sound on all inputs. No H, maxfiber, KT form, proper
cover or advice is supplied; (1) is a semantic completeness promise and is
not claimed numerically recognized. All oracle/padding/query bounds remain
those of the strict theorem, with only the fixed finite cutoff changed from
5 to7. In particular decisions are bounded by

    (n+1)*((2n+1)*(1+n+binom(n,2))+n+2),

query bits by O(S_F+n^4), and total outside work by
O(128*S_F+(n+1)*(S_F+n+1)^4*(1+n+binom(n,2)+1)^4).
There is no square-hole/count/full-profile guarantee or general Avoid claim.

## 1. Saturation handles any doubled Gauss amplitude

W(0)=0 and every W(a) is divisible by L. Here ||w||_1=2H=2L, so W has
values among0,+/-L,+/-2L. If some |W(a)|=2L, a!=0 and triangle equality gives

    sign(w(y))=sigma*(-1)^(a.y)

at every nonzero defect. Hence all positive defects lie in ONE proper affine
hyperplane. A nonzero affine annihilator exists, regardless of repeated or
simple fibers. No algorithm needs the saturating a for free; A_2 acquires an
annihilator directly. It remains to consider W in{0,+/-L}.

## 2. Odd support is strictly below2L in the repeated case

Let U={w odd}. Dyadic coefficient divisibility gives deg1_U<=n-K, exactly
as in frozen1272. All negative defects are-1 and mass balances, so

    2H-|U|=2*sum_(w(y)>0) floor(w(y)/2).        (2)

A fiber of size>=3 means a positive w>=2. Thus (2) is positive and
0<|U|<2L, so the same classical Kasami--Tokura minimum/TypeA/TypeB forms apply
to the SIMPLE BINARY unitrade U. No repeated signed-trade classification is
used. The primary source remains Ghorbani et al., arXiv1810.02296v2,
Lemmas2/11: https://arxiv.org/html/1810.02296v2 .

Write O=aff U=b+V. On the quotient by V, nonbase cell sums p(t)>=0 and
p(0)=-Pout, where now Pout<=H=L. The quotient Walsh coefficients are still
0 or-L because they are nonpositive restrictions of ternary W. Consequently
nu=delta_0+p/L is NONNEGATIVE even if its initial lower bound at0 is zero;
it is a probability with Fourier values0/1. The positive-idempotent lemma
therefore makes nu uniform on a subgroup T. In particular its value at0 is
actually POSITIVE, and

    Pout=L*(1-2^-h), h=dim T.                 (3)

All defect lies in the cells indexed by T, since outside-base entries are
nonnegative and a zero marginal forces every such entry zero. The whole
defect hull therefore has dimension at most dim O+h. The sharper coupling
from W59 continues to hold at H=L:

    |U|<=2L-Pout=L+L*2^-h.                   (4)

## 3. Nontrivial quotient or minimum odd support

If U is minimum, it is an affine K-flat B. Then phi=w+1_B is nonnegative
and EVEN, has mass L and all Walsh coefficients divisible by L. Positivity
makes its normalized coefficients0,+/-1, so phi is uniform on an affine
flat A up to a positive even factor q. Thus w=q1_A-1_B and C=A, with
dim A<=K-1<n. This holds even if A and B are disjoint, which can occur only
at H=L. A nonzero linear annihilator exists.

Suppose U is nonminimum and h>=1. The classical first weight gap gives
|U|>=3L/2. Equation(4) forces h=1 and |U|=3L/2 exactly. The literal KT forms
make this TypeA with mu=2; TypeB has weight at least7L/4. Hence

    dim O<=K+2, dim whole support<=K+3<n

for all n>=8. So C again lies in a proper affine flat and has a linear
annihilator. This argument uses no unproved uniformity of individual fibers
inside the nonbase quotient cell.

## 4. Trivial quotient and full odd hull

It remains that h=0 and U is nonminimum. Every defect is then inside O.
If O is proper, one linear annihilator suffices. Otherwise O is full.
For n>=8, TypeB's support bound K+2<n excludes it. TypeA has two K-flats
F1,F2 and dim O<=K+mu with mu<=n-K, so mu=n-K. Therefore

    |U|=2L-2 if n is even; |U|=2L-4 if n is odd.

By(2), the positive-even points outside U number at most ONE in even
dimensions and at most TWO in odd dimensions. Positive w3 or larger odd
weights may consume the same excess budget but are already inside U.
Enlarge F1 by all outside-U positive points, obtaining a flat F1' of
dimension<=K+2. Then

    C subset F1' union F2,
    |F1' union F2|<=5L<2^n

for n>=8, and both flats are proper. A point outside both exists. One affine
separator per flat, each equal to1 at that point, gives a NONZERO degree<=2
polynomial annihilating C. No cover or exceptional points need to be
acquired: only this proven degree cap is fed to the complete A_2 algorithm.

## 5. The sharply isolated unresolved endpoint

This proof leaves a possible exact-boundary class:

    H=L, maxfiber=2, W in{0,+/-L},
    U=entire defect support has |U|=2L and full affine hull.

Such U is AT the twice-minimum Reed--Muller weight boundary, where the strict
KT form used here does not apply. The theorem does not declare this class
empty, hard, or outside A_2 in every actual case. It records exactly the
remaining structural obligation. Actual all-coordinate A_2 counterexamples
known here have MUCH larger H and do not resolve this endpoint.

The exact repeated endpoint need not have an exhibited infinite actual
family for this conditional theorem to be valid; no such realizability is
inferred. Finite actual small-map controls, abstract profiles and the
all-size derivation remain distinct. This is a rectangle missing-word
continuation only, not generic P-versus-NP progress by assertion.
