"""Create one new frozen manifest; refuse to overwrite any manifest.

This is a packaging/hash check, not scientific validation. Historical packets
are verified before writing the new packet and are never modified.
"""
from pathlib import Path
import json,hashlib,datetime
ROOT=Path(__file__).parent
FILES=[
'COHERENT_SECTOR_ORACLE_AND_SEED_PRESERVING_UPLOAD_V1.md','THREE_CALL_CLASSIFIER_REFINEMENT_V1.md',
'coherent_sector_checks.py','COHERENT_SECTOR_CHECKS.json','coherent_sector_raw.npz',
'seed_preserving_factory_checks.py','SEED_FACTORY_CHECKS.json','seed_factory_raw.npz']
FILES+=['three_call_classifier_exact.py','EXACT_THREE_CALL_CLASSIFIER_CERTIFICATE.json',
'native_depth_kernel_checks.py','NATIVE_DEPTH_KERNEL_CHECKS.json','native_depth_kernel_raw.npz',
'rational_seed_factory_certificate.py','RATIONAL_SEED_FACTORY_CERTIFICATE.json',
'SEED_FACTORY_PRIMARY_COMPARISON.md','SEED_FACTORY_EVIDENCE_AND_SCOPE.md','SEED_FACTORY_SOURCE_BINDINGS.json',
'SEED_FACTORY_REPORT.md','SEED_FACTORY_RESULT.json','SEED_FACTORY_REPRODUCTION.md','SEED_FACTORY_CONTINUATION.md','freeze_seed_packet.py']

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    target=ROOT/'FROZEN_SEED_FACTORY_PACKET.json'
    assert not target.exists(),'Refusing to overwrite a frozen packet'
    historical=[]
    for p in sorted(ROOT.glob('FROZEN_*_PACKET.json')):
        data=json.loads(p.read_text())
        for row in data['files']:
            f=ROOT/row['file'];assert f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],str(f)
        historical.append(dict(file=p.name,sha256=sha(p),payloads_verified=len(data['files'])))
    rows=[dict(file=f,bytes=(ROOT/f).stat().st_size,sha256=sha(ROOT/f)) for f in FILES]
    result=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='NEW_UNKNOWN_SEED_COHERENT_ORACLE_AND_WORD_UPLOAD_CANDIDATE_WITH_EXACT_FINITE_CERTIFICATE',
        proof_status='FULL_FRESH_REVIEW_PENDING; earlier known-sector upload/inverse reviews remain separate',
        finite_evidence='PASS_IN_SCOPE; no physical execution or practical/capacity advantage claim',
        worker='IDLE_AFTER_CURRENT_OBLIGATION_PER_DIRECT_USER_STEERING',mission='NOT_ACHIEVED',
        files=rows,total_payload_bytes=sum(r['bytes'] for r in rows),historical_manifests_verified_unchanged=historical)
    target.write_text(json.dumps(result,indent=2)+'\n')
    # Read back every byte-size/hash; transport only.
    for r in json.loads(target.read_text())['files']:
        f=ROOT/r['file'];assert f.stat().st_size==r['bytes'] and sha(f)==r['sha256']
    print(json.dumps(dict(manifest=str(target),sha256=sha(target),payloads=len(rows),bytes=result['total_payload_bytes'],
        historical_manifests_verified=len(historical)),indent=2))

if __name__=='__main__':main()
