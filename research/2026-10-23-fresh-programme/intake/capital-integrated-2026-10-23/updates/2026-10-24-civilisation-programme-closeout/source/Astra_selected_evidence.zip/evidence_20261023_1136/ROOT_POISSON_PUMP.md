# Replacing Fock preparation by one ordinary bright pump

Root continuation after the direct concentration proof; new candidate requiring fresh review. Uses the SAME shared trilinear Hamiltonian and sector receiver. It does not propose a new generic pump state or claim an experimental device.

Let J=N+M, prepare ONE phase-randomized coherent pump with mean photon number mu=6J, and set the fixed interaction time t=1/(chi sqrt(4J)). Its initial pump-number distribution is Poisson(mu). No pump number measurement, Fock factory, repeated band selection or supplied number result is required.

Poisson Chernoff gives

    Pr[L outside [4J,8J]] <=2 exp(-2J/7).              (C1)

For each good number L, lambda=L/N>=4s for EVERY source sector S=N+m<=J, while the dimensionless time is tau_L=sqrt[L/(4J)] in[1,sqrt2]. Root's concentration argument remains valid throughout that interval: the first upper classical turning time is at least asinh2>sqrt2, so y(tau_L)>=y(1)>=3s/4. The exact state-error estimate yields

    Pr[ell<S/2 | L]
       <=16 exp(12sqrt2)[1/N+4sqrt2/N^2].             (C2)

Therefore the unconditioned pair-output tail is at most the sum of (C1) and (C2), uniformly over the capped source sectors. The precise sector-receiver composition still needs the same fresh check as the Fock version; conditional code errors are then added without dividing by a success probability.

## Why this is a physical state rather than a number oracle

The phase-randomized coherent state is a normal Poisson-diagonal density. Its mean initial pump energy is hbar*omega_P*6(N+M), fully charged. A trusted ordinary coherent pump source would supply this distribution after phase randomization; the source, shared coupling, time calibration and complete preparation/reset cost remain explicit apparatus premises. No physical operation is performed here.

Coherent pump off-diagonal terms are not needed. If one also claims a single pure coherent pump works, it is necessary to prove that the ENTIRE Bell-failure effect is diagonal in the INITIAL pump number. A sufficient device-specific reason is that the actual protocol first records the D-side total added photon number ell: in a fixed ell branch the unobserved final pump numbers L-ell are orthogonal for distinct initial L. This observation must be checked against the actual receiver chronology before such a stronger statement is adopted. The Poisson-diagonal candidate above already avoids that issue.

## Full resource price and finite readouts

Relative to any fixed faithful one-mode thermal Gibbs reference gamma_l=(1-q)q^l,0<q<1, its max-order resource is finite and satisfies

    D_max(Poisson(mu)||gamma)
       <=mu*(q^-1-1)-ln(1-q)=O(N+M).                 (C3)

Indeed each pointwise ratio is bounded by their positive exponential-series sum exp[mu(q^-1-1)]/(1-q). This is an UPPER resource price, not a proof of an optimal work cost or an acquired pump factory. The state has unbounded support, so its maximum photon number is UNKNOWN/unbounded even though its mean energy and max-Gibbs resource are linear. Do not mislabel it as a hard energy cap.

For the optical receiver, keep finite D-side readouts only through8J and C-side total only throughM+8J, with the exact common product default on overflow. On good-L branches those readouts are exhaustive; on bad-L branches their error is already paid by(C1). No infinite-outcome decoder or actual pump measurement is needed. The pump is retained in the complete complement; its exact return is not claimed.

The result, IF the proof and composition pass, would replace a supplied exact Fock pump or an O(N log N) worst-case thermal band-selection inventory by one ordinary Poisson pump with linear mean energy and linear max-Gibbs price, supporting the SAME robust non-iid source-sector receiver. A same-pump vacuum source can yield more Bell entanglement, so this is not a matched yield advantage over ordinary entanglement generation. Historical priority, physical validation, practical usefulness and mission achievement remain separate and unestablished.
