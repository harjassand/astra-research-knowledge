# The attainable material operation must preserve the mechanical variable

The proposed manufacturing process is now **teach under held forces → store the load-ensemble square → unload → electrodeposit/etch a bounded increment → zero/settle → reteach**. This is a substantive change from an assumed instantaneous strain-sensitive coating. It permits conventional existing square electronics, charges the fixture and memory phases, and makes stress-history effects experimentally separable.

## Why a weld is not the required continuously variable strut

The demonstrated Cu/steel actuator in [Kim et al., DOI 10.1002/smll.202510823](https://doi.org/10.1002/smll.202510823) changes topology by joining/disjoining cut struts. Its intermediate states, contact, percolation and junction mechanics do not establish the affine law `K(a)=Kcore+sum E a/l bb^T` used by the first packet. Its official supporting PDF was newly acquired through the [Europe PMC supplementary-files API](https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12658919/supplementaryFiles). It adds geometry, electrochemical setup and spring-model details, but not the needed continuous dose-to-axial-stiffness or full strain-to-dose response arrays. The supplement explicitly has bending/contact and binary spring states. Its bath method includes 350 rpm stirring, an additional process cost.

The prototype geometry should therefore be an uninterrupted steel axial core, with a continuous Cu layer grown along the full active length and anchored at both ends. The steel supplies the positive-definite core. Symmetric coating on opposite faces suppresses first-order bending. Two separated electrolyte compartments around two otherwise electrically continuous core members test ionic addressing and common-metal cross-talk before a network is attempted. This remains a proposed geometry: adhesion, uniformity, electrochemical access to both faces, reference drops and sealing have not been measured.

In an ideal perfectly bonded, zero-prestrain linear axial composite,

`k(q)=E_steel A_core/l+E_Cu A_Cu(q)/l`.

Faraday's law converts total *Faradaic* charge to deposited mass, not automatically to uniform load-bearing cross-section or a constant modulus. The mechanical acquisition must measure incremental axial stiffness and zero-force length, not just mass or an optical thickness.

## Loaded deposition changes the reference state

A new layer joining a member while it is strained can have a different stress-free length from the old core and earlier layers. The resulting energy has the form

`U(u,q)=(1/2)sum_layers k_i(q) [b^T u - z_i(q)]^2`,

where the natural-length shifts `z_i` depend on growth history. The external-force equilibrium then contains an internal-force term. Its derivative with respect to deposited material is not generally just the negative squared current strain. Perfect square electronics do not repair this mismatch.

Unloading during each growth step removes the deliberate external teaching strain from the layer's reference-state choice. It does not eliminate intrinsic electrodeposition stress, thermal mismatch, aging or chemical strain. [Kongstein, Bertocci and Stafford's original Cu stress study](https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=853333) shows potential- and growth-stage-dependent intrinsic stress and relaxation. The different thin-film/substrate regime is evidence that a zero-stress assumption needs testing, not a numerical bound for this proposed coupon. [McAndrews et al.'s reversible electrodeposition study](https://doi.org/10.1002/aenm.202202843) also shows that mechanically stable deposition and stable resting films are distinct properties in its Cu/Bi window chemistry. Its electrolyte and thickness regime must not be transferred as this steel/Cu coupon's failure rate.

The acquisition sequence records zero-force length before growth, immediately after growth, after rest and after etch, and performs small elastic loading/unloading cycles. [Trost et al.](https://arxiv.org/abs/2009.13850) provide a primary measured reason to prefer repeated elastic cycles to a single crosshead-slope modulus estimate for electrodeposited Cu foils. Their modulus values are not substituted for this composite's actual stiffness.

## A nonlinear response can sometimes be accommodated; it cannot be assumed away

For a measured mechanical variable `q_e`, let

`K(q)=Kcore+sum k_e(q_e) b_e b_e^T`,

`F(q)=E_P[f^T K(q)^-1 f]/2 + lambda sum c_e(q_e)`.

Then

`partial_e F = lambda c'_e(q_e) - k'_e(q_e) E_P[(b_e^T u)^2]/2`.

If `k'_e>0`, a local square gate still gives the correct gradient direction only with the corresponding acquired threshold `2lambda c'_e/k'_e`. A constant threshold therefore requires a constant known ratio, or a locally acquired state-dependent correction. Integrating current does not acquire `k'_e`.

If each `k_e(q_e)` is concave and nondecreasing and each cost `c_e` is convex, the objective remains convex: compliance is convex and nonincreasing in the spring constants, so the standard composition inequality applies. With convex or sigmoid junction stiffening, global convexity is not obtained from this argument. A topology switch/percolation curve can create distinct local stationary states. The original global-optimum theorem then does not apply, although a correctly measured local gradient may still decrease the chosen objective.

There are two honest continuation routes after the assay: retain a verified affine/concave composite response, or redesign the plant/control around its acquired nonlinear stiffness law and accept the changed optimization claim. Fitting a coefficient while retaining the original theorem is not a third route.

## Actual actuator contract

Deposition/etching commands must produce the intended signed change in the *mechanical* variable, with bounded positive rate and a realizable minimum dose. Potential limits must protect the steel and prevent unmodeled reactions. At zero command, disconnected or potentiostatically held material must not drift enough to violate the chosen tolerance over a complete observation/update frame. Zero-current corrosion, spalling, creep or residual-stress relaxation is a post-controller disturbance; it cannot be hidden in a square-estimation error.

The convergence proof permits broad positive mobility variation, including different deposition and etch rates. It does not require material dose to track an analog command to arbitrary precision. Maximum dose per update must obey the finite-step bound; minimum dose enlarges the approximate KKT tolerance. Failure to acquire useful lower mobility gives no useful completion-time claim.

For manufacturing, wet cells, sensing patches and controllers are reusable fixtures that can be removed after the geometry is made. Their fabrication, installation, cleaning, carryover, removal, chemical replacement and reuse life must be included in cost per part. For persistent in-service adaptation all those masses remain carried; the present volume objective does not optimize their total mass.
