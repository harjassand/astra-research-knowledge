# Asymptotically optimal full-domain error constant for arbitrary algebras

23 October 2026. New W68 internal mathematical candidate, independently
derived while auditing the ancilla-dimension frontier. No descendants used.
This file requires fresh independent criticism before promotion.

## Statement

Use the same N=r^3, rank-r physical diagonal projections P,Q with
rank(PQ)=1, arbitrary ancillary dimension K, and arbitrary commuting
tracial conditional expectations F,G onto arbitrary unital *-subalgebras
of M_(NK). Let D=Tr_A and let the unhalved full-domain diamond error be

    epsilon=max(||DF-E_P D||_diamond,||DG-E_Q D||_diamond).

If epsilon<=1, put

    delta=epsilon/2,
    c=1/(r+1),
    alpha(delta)=(1-sqrt(1-4delta^2))/2.

Then necessarily

    1 <= 2c+r(1+c)delta+6r alpha(delta).                    (Q1)

In particular, for every K and every such enlarged algebra pair,

    epsilon >= 2/(r+16).                                  (Q2)

Consequently the infimum full-domain error over arbitrary finite K and
arbitrary enlarged range algebras is

    epsilon_opt(r)=(2+o(1))/r,                             (Q3)

because the explicit flat-marginal construction has epsilon=2/(r+1).
No exact finite-r quantum optimum is claimed. The implicit necessary
bound (Q1) is stronger than the deliberately simple closed bound (Q2).
It gives epsilon>=2/r-18/r^2+O(r^(-3)).

The full-domain qualifier is essential: the proof uses dual observables on
the entire enlarged algebra, rather than only a prepared product input.
No separability, commutative range, specified block architecture or
ancilla-return condition appears in (Q1).

## Effect bounds supplied by the full-domain norm

Below P,Q denote their lifted projections P tensor I_K,Q tensor I_K on
the enlarged algebra. Ordinary trace satisfies

    Tr(P)=Tr(Q)=m=rK,       Tr(PQ)=K,       PQ=QP.

For two channels within unhalved diamond distance epsilon, every effect
has adjoint difference at most delta=epsilon/2 in operator norm. Indeed
their output difference on any input state is Hermitian and trace zero,
so every effect probability differs by at most half its trace norm.
The operator-norm bound follows by maximizing over input states.

The adjoint of ordinary partial trace is physical inclusion Y->Y tensor I.
The tracial expectations are trace self-adjoint. Since

    E_P(P)=P,
    E_P(Q)=cP+(c/r)I,

and symmetrically for E_Q, the norm hypothesis implies

    ||F(P)-P||_infinity <= delta,
    ||G(Q)-Q||_infinity <= delta,
    ||F(Q)-[cP+(c/r)I]||_infinity <= delta,
    ||G(P)-[cQ+(c/r)I]||_infinity <= delta.                (Q4)

The two-event formula follows directly from
E_P(Q)=P/r+(r-1)(I-P)/(N-r), with
(r-1)/(N-r)=1/[r(r+1)]=c/r and 1/r-c/r=c.

## Quadratic variance lemma for a nearly fixed projection

Let E be any tracial conditional expectation and let R be a projection of
rank m. Suppose ||E(R)-R||_infinity<=delta<=1/2. Put A=E(R). Then

    v:=||A-R||_2^2=Tr(R)-Tr(A^2) <=2 alpha(delta) m.       (Q5)

Here ||.||_2 is the unnormalized Hilbert--Schmidt norm. To prove this,
conditional-expectation bimodularity gives

    E((R-A)^2)=A-A^2.

Since (R-A)^2<=delta^2 I and E is positive and unital,

    0<=A-A^2<=delta^2 I.

Therefore every eigenvalue of A is in [0,alpha] or [1-alpha,1]. Weyl's
eigenvalue bound applied to ||A-R||<=delta shows that its first m
eigenvalues are at least 1-delta, and all others are at most delta.
For delta<1/2 this identifies exactly m eigenvalues in the high interval.
At delta=1/2 one may simply designate the first m as high; the same
inequalities below still hold, or use the trivial bound v<=m.

Trace preservation gives Tr(A)=m. Hence the deficit of the m high
eigenvalues from one equals the total mass of the low eigenvalues, and
both are at most alpha m. It follows that

    Tr(A-A^2)<=2 alpha m.

Trace self-adjointness and idempotency give
Tr(RA)=Tr(A^2), so

    ||A-R||_2^2=m-Tr(A^2)=Tr(A-A^2),

proving (Q5). This argument is independent of ambient dimension: using
only A-A^2<=delta^2 I and summing over NK would lose the necessary bound.

There is an additional useful estimate. If B is an effect commuting with
R, then

    |Tr((A-R)B)|<=v.                                     (Q6)

Indeed the R-diagonal block R(A-R)R is negative, the complementary
diagonal block is positive, and their absolute traces are each v. Since
B is block diagonal with respect to R, its weighted trace lies between
-v and v. Off-diagonal blocks contribute no trace to this expression.

## Lower bound on a trace overlap

Write X=F(P)-P and Y=G(Q)-Q, and let v_F=||X||_2^2,
v_G=||Y||_2^2. Equations (Q4)--(Q6) and PQ=QP give

    v_F,v_G<=2 alpha m,
    Tr(F(P)G(Q))
       =Tr(PQ)+Tr(XQ)+Tr(PY)+Tr(XY)
       >=K-v_F-v_G-sqrt(v_F v_G)
       >=K-6 alpha rK.                                  (Q7)

The cross term uses Hilbert--Schmidt Cauchy--Schwarz. The traces are real;
no commutation of F(P) with G(Q) is assumed.

## The same trace overlap has an upper bound

Commutation FG=GF and trace self-adjointness give the exact identity

    Tr(F(P)G(Q))=Tr(P H(Q))
                  =Tr(Q H(P))=Tr(F(Q)G(P)),              (Q8)

where H=FG. This identity is the only step needing commutation of the two
enlarged expectations; the variance lemma is an individual-map statement.

From (Q4),

    F(Q)<=cP+(c/r+delta)I,
    0<=G(P),       ||G(P)||_infinity<=1/r+delta,
    Tr(G(P))=m.

The maximum eigenvalue of cQ+(c/r)I is c+c/r=1/r, fixing the coefficient.
Moreover, expectation self-adjointness gives
Tr(P G(P))=Tr(G(P)^2). Multiplying the operator inequality by the positive
G(P) and taking trace therefore yields

    Tr(F(Q)G(P))
       <=c Tr(G(P)^2)+(c/r+delta)m
       <=[c(1/r+delta)+c/r+delta]m
       =[2c+r(1+c)delta]K.                              (Q9)

Combining (Q7)--(Q9) and dividing by K>0 proves (Q1).

## Explicit closed bound and leading constant

On 0<=delta<=1/2,

    alpha(delta)=2delta^2/(1+sqrt(1-4delta^2))<=2delta^2.

Thus (Q1) implies

    1 <= 2c+r(1+c)delta+12r delta^2.                     (Q10)

The right-hand side is increasing in delta>=0. At delta=1/(r+16), it is
at most one. After putting over positive denominators, this assertion is
equivalent to

    12r(r+1) <= (13r-16)(r+16),

whose right-hand side minus left-hand side is
r^2+180r-256>0 for every r>=2. Therefore delta>=1/(r+16), proving (Q2).
If epsilon>1, (Q2) is automatic, so the closed bound is unconditional.

The positive root delta_r of

    2c+r(1+c)delta_r+6r alpha(delta_r)=1

has expansion delta_r=1/r-9/r^2+O(r^(-3)), by elementary Taylor expansion.
Hence (Q1) provides the sharper asymptotic statement in the theorem.
The construction's upper error 2/(r+1) and (Q2) squeeze r epsilon_opt to
two. No limit in K or existence of a minimizing finite K is required:
the lower bound holds uniformly over every finite K, and a finite
construction supplies the upper bound.

## Falsifiers, literature role, and status

A commuting quantum pair at epsilon below the root of (Q1) would falsify
the candidate, regardless of K. The load-bearing audit targets are the
half-trace effect bound in (Q4), dimension-free quadratic variance (Q5),
commuting-projection trace estimate (Q6), overlap identity (Q8), and order
upper bound (Q9). A product-input-only construction would not refute it.

Conditional-expectation bimodularity, spectral perturbation, trace
self-adjointness and Hilbert--Schmidt Cauchy--Schwarz are standard prior
mathematics. This file asserts a parameter-specific consequence rather
than priority for those ingredients. Historical priority of the exact
rare-family asymptotic error optimum is UNKNOWN. No hardware, gate-count,
catalytic-return or practical computational advantage is implied.
Mission NOT_ACHIEVED; independent external validity and physical usefulness
remain UNKNOWN.
