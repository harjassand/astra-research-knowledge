# Static correlation cost transfers the product-resource strong converse

Root, 23 October 2026. A new device-specific application of standard finite
dimension domination and gentle truncation, not a claim of generic novelty.
W49 independently checked the exact product-process prerequisite and froze
STATIC_INITIAL_CORRELATION_TRANSFER_V1.md, SHA
a42ba0286d54e1f0871d7d9fa3fac67239d520c51fd19411d74efeed93b0d1cd,
after receiving root's direct comparison construction. Further fresh review
of this root statement is requested. Mathematical, priority, physical and
practical statuses remain separate.

## General comparison theorem

Consider any fixed N-call physical process with initial memory E and all
laboratory systems L. The logical input/reference is freshly prepared and
independent of the WHOLE initial resource eta_EL. Arbitrary laboratory
preshares and backward quantum/classical messages are allowed, but the
physical process is the only forward signalling route. All final branches
are retained, the target is a fixed K-dimensional Bell state, and N is fixed.

Assume the following independently proved product-resource bound: for every
normal product initial resource omega_E tensor xi_L and every allowed
strategy, its unconditional Bell fidelity is at most C_N/K^2. The bound
must cover the SAME strategy, preshares, feedback, call count and output
conventions, uniformly in omega and xi. Without that exact prerequisite,
the transfer below is conditional and cannot be applied.

Let P be ANY finite-rank projection on the INITIAL E, rank d>=1, and put
p=Tr[(P tensor I)eta]. If p>0, let eta_P=P eta P/p and
xi_P=Tr_E eta_P. On P E tensor L,

    eta_P <= d I_P tensor xi_P
          = d^2 (I_P/d) tensor xi_P.                    (S1)

Proof: write eta_P in d-by-d operator blocks eta_ij. For a test vector
sum_i |i> tensor v_i, positivity implies
|<v_i,eta_ij v_j>| <= sqrt(<v_i,eta_ii v_i><v_j,eta_jj v_j>).
Cauchy-Schwarz bounds the total quadratic form by
d sum_i <v_i,eta_ii v_i>, which is at most
d sum_i <v_i,xi_P v_i>, since eta_ii<=xi_P. This proves (S1), also for
normal infinite-dimensional L by testing finite sums. The d^2 factor
is tight uniformly: a maximally entangled rank-d pure resource compared
with I_P/d tensor its L marginal needs exactly that factor.

For a fixed legal strategy and fresh Bell input, the final unconditional
state is a NORMAL CP LINEAR function of its initial resource. Adaptive
measurements and classical control do not break linearity when ALL branches
are included. Apply this positive map to (S1), then the product bound:

    F_N(eta_P) <= min(1,d^2 C_N/K^2).                   (S2)

The product comparator uses xi_P, which may depend on P and the initial
resource, but never on the fresh logical input. No preparation, bath
measurement, physical filter or alternate protocol is being performed.

A purification of eta, followed by normalized P projection, has overlap
sqrt(p) with the original purification. Therefore trace-distance contraction
gives (half-trace convention)

    T(eta,eta_P) <= sqrt(1-p),

and every Bell test changes probability by at most that amount. Consequently

    F_N(eta) <= min(1, sqrt(1-p)+d^2 C_N/K^2).          (S3)

The slightly looser 2 sqrt(1-p) version in W49's corroborating note is also
valid. No commutation of P with the interaction, bath charge or resource
is required. P is a static comparison on the initializer; evolving dynamics
are never projected or modified.

## Recurrent-device application and exact prerequisite

W19 FULL_PROOF_V1.md SHA
1556727069358baa8838813d3364eb2e33869dd32cc6d04df682a4dc868328cc
Sections 1--5 establish the required SAME-interface product-process bound

    C_N=H_b^N,
    H_b=(sqrt(2-b)+sqrt(2+2b))^2,  b=beta^2 in [0,1].

Its whole-memory weighted Choi trace bound is uniform in ALL normal product
initializers. Its Section 5 uses ONE global C_N at every prefix to obtain
deterministic-process domination, hence permits arbitrary lab preshares and
backward quantum/classical communication, with no extra forward sidewire.
Root reread those exact sections; W49 separately checked their applicability.
This proof is newer private capital based on corpus pin
e606bfc587c76bdcae8b8fa3ec33e721efa2fbac, not a theorem inferred from
the latest repository's navigation. Its independent review history remains
separately bound in the central ledger.

Thus, for correlated initializers admitting projections P_N with

    Tr(P_N eta_N)->1,       log2(rank P_N)=o(N),

every fixed positive rate margin above c_b=(1/2)log2 H_b gives F_N->0.
More generally, if log2(rank P_N)<=sN+o(N), then S3 gives a strong ceiling
c_b+s whenever the tail vanishes. Clip by the ordinary qutrit ceiling.
The tails and ranks in a uniform family theorem are PREMISES, not acquired
physical preparation or inferred energy bounds.

For EVERY FIXED normal eta_EL, finite-rank projections P_M on E increase
strongly to I, so p_M->1. Fix M first. At any rate>c_b the d_M^2 term in
S3 tends to zero as N->infinity. Then let M->infinity. This proves a
pointwise strong converse for arbitrary fixed initial bath--laboratory
entanglement/correlation, not just product initializers. The marginal may
have infinite mean depth, entropy or thermal max-relative entropy. Extra
independent horizon-dependent laboratory preshares may be appended without
changing the argument. No common tail modulus is claimed for all normal
resources, and arbitrary horizon-dependent extensively correlated eta_N
remain outside this transfer.

At beta=0, c_b=1.5; the separately reviewed all-resource zero-beta theorem
already covers much more and is not superseded. For beta>0 this transfers
the EXISTING product-resource quadratic STRONG threshold; it does not reach
the smaller all-resource quadratic WEAK threshold and does not prove its
strong counterpart. It supplies no lower code or practical/physical device.

## Immediate research consequence

To exceed this threshold at nonvanishing Bell fidelity while maintaining
fresh logical independence, a horizon-dependent correlated resource cannot
have vanishing tails on all subexponential-rank bath supports. This is a
necessary smooth correlation/dimension cost, not sufficient evidence that
such a resource helps. The bound may also be stated with any smooth
product-domination factor c_N satisfying log2 c_N=o(N), in place of d_N^2.

This direct comparison is a stronger and simpler comparator to a converse
transfer through a costly loader. Constructive upload/acquisition theorems
remain useful separate achievements; they are unnecessary for this upper
bound. Standard max-information/conditional-min-entropy literature is the
generic prior, and complete device-specific priority is UNKNOWN.
