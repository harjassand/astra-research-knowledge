# Independent causal-response and positive-input V4 delta audit

Verdict: **ACCEPTED_INTERNAL_AUDIT_OF_CAUSAL_V4_DELTA**. No blocking defect
found in the exact source SHA256
`b37eccacafa054db80a9f28f6903af0015b78f00a83c303048b8586994b6a0a6`
(`w56/lower_construction/CAUSAL_CLIPPED_LOWER_V4.txt`). The causal lemma is
separately frozen at SHA256
`f1b3dadbc126b6996d3e86bdbc854c9bd40f143f00efaa905a1e9de6d56348a9`.
The unchanged H structure, all-coherence response and original code theorem
remain the explicit V1/V2 dependencies. External correctness, optimal
coefficient, priority and practical usefulness remain unknown.

## Causal response, independently reconstructed

Both the original H endpoint component and the spectator-fixed endpoint
component depend only on calls through their last endpoint. A later fixed U
call has bulk depth increment `2q_l-I`, which is independent of the bath,
diagonal in its own input and commutes with earlier calls; a fixed I call
has zero increment. No through-root identity is asserted.

The consistent integral representation of `zeta_sym,m` ensures the original
H family is prefix-compatible. Equivalently, the last-endpoint component
`J_m=H_m-H_(m-1) tensor I` contains exactly those pairs ending at m. Later
independent reference-sigma inputs have zero expected bulk depth increment,
so their exact signed-input response vanishes, even on a coherently
correlated prior bath. This gives the m-prefix grouping used in the source.
Its empty-mask group sum is `(v_m-v_(m-1))I` and its summed trace budget is
`T_m-T_(m-1)`. Thus

`F_k(b)>=[v_k-sum_(m=2)^k Delta(3N_m/4-v_m)(1-a^(m-2))]I`.

An independent per-pair derivation yields the same expression. For a
zero-based last endpoint j, put `R_(j-1)=sum_(ell=0)^(j-1)Pr(S_ell=0)`.
The triangular walk symmetry gives
`V_j=j/4-R_(j-1)/8`, `T_j=j/8+R_(j-1)/8`, so the loss weight is
`V_j+2T_j=j/2+R_(j-1)/8`. The individual empty pair is scalar by the
original three-case trace normal form. The source's group proof does not
need that additional individual statement.

Bernoulli's inequality and nonnegative collision increments give

`sum_(m=2)^k (m-2)Delta(3N_m/4-v_m)`
` <=binom(k,3)+(k-2)C_k/8=(k-2)(7N_k/12-v_k)`.

For `v_k/k^2>=3/25`, `N_k/v_k<=25/6`, which proves the exact source's
simple response `F_k/v_k>=1-(103/72)r`. The fixed-r limiting certificate
is `-1+4[1-(1+r)e^(-r)]/r^2`. It is correctly described as a limit of a
lower certificate, not an exact response/capacity formula.

## Changed gamma, charge tilt, and clipping

V4 chooses `k=floor1/(5b)`, `gamma=4/25`, `delta=t0/18`, `t0=v_k b^2`.
Thus `k>=3276`, `1/6<=r<=1/5`, `nu>=3/25`,
`eta=2delta=t0/9<=1/1800`, and the response is at least `257v/360`.
The complete-pattern positive congruence is unchanged; sigma and T commute
with its factors through total charge. Positivity, `pin F=I`, normalization
and the prescribed charge excess therefore persist with the changed tilt.

The actual affine moment parameter is `gamma*r<=4/125`. At moment 20,
independent exact arithmetic confirms the bounds
`d0<1e-8`, `||Ntail||_2<9e-6`, `||Ntail||_4<13e-4`.
Also `1/300<=t0<=1/200`, `.009<u=gamma sqrt(t0)<.012`,
`e<1e-5` and `e/u<1/800`. These are weighted/pinched estimates; no small
spectral norm of the affine perturbation is substituted.

The changed diagonal variance is exactly `4delta^2/k=t0^2/(81k)`,
and its fourth-norm ratio is at most `r/(54sqrt(k))`. Combining with the
offdiagonal normalizer estimates gives, independently,

`||TF-I||_2^2/t0 <=1704420221419619/66339000000000000 <257/10000`,

`||TF-I||_4/r <=252278249/769500000 <328/1000`.

## Entropy, entire drift, and rate

The already audited global quartic majorant remains valid at clipping
zeros and large relative eigenvalues. Weighted Cauchy-Schwarz controls the
cubic term. Substituting the new variance and fourth norm yields exactly

`D_2(rho||sigma)/t0 <277917203/12128906250`.

The changed entropy identity has charge term `t0/18`, so its gain coefficient
is `197955461/6064453125 >1/31`.

The signed comparison drift coefficient is
`gamma*(257/360)-2/18=7/2250`. The full offdiagonal correction is still
`Yoff=T(F-I)-X`, with weighted norm at most `(1+eta)e+eta u`.
At `r<=1/5`, the all-coherence response is at most `5/23`. Independent
rational subtraction gives negative drift margin

`3064393/1413120000 >1/480`.

It is a bound on the full bath operator for every bulk prefix, so the
unchanged actual-root and full-reference code bridge applies with fixed
`kappa=t0/480`. Beta, k and rho are fixed before the outer block horizon.
The resulting certificate is

`Q>=3/2+v_k beta^4/(31k)>=3/2+beta^2/1550`.

Its unsimplified small-beta coefficient is `1/1240`. The exact charge
variance claim also checks: `pin rho=sigma T` implies second centered
moment `k/4` because sigma's third centered moment is zero; subtracting
the squared charge mean gives variance `k/4-delta^2`.

## Receipt and resource scale

Own replay: `check_independent_v4.py`; own raw exact rational/90-digit data:
`INDEPENDENT_V4_SCALAR_AND_BASELINE.json`.
At beta=1/512, independently:

- k=52428;
- certified excess `3.069116655177885141293145...e-9`;
- ratio to accepted V3 `1.51001877712...`;
- ratio to the best previously retained original Cycle9 certificate
  `130.3163639103...`;
- `log10` input-space dimension `25014.513142442...`.

These are comparisons of derived lower certificates, not measured capacities
or finite-horizon code performance. No large input was synthesized; input
rank, spectral encoding, decoder compilation, precision and useful error
budgets remain unestablished. The larger exponential input burden and all
original cutoff/type/Lyapunov costs remain. No physical operation, reset,
experimental validation or practical advantage follows from this audit.
