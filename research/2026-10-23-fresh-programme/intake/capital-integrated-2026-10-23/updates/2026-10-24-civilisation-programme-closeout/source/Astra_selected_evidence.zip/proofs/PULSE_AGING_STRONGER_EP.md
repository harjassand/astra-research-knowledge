# Stronger baseline entropy bound from conditional Bernoulli information

23 October 2026. This separate supplement leaves all frozen first-exit
packet bytes unchanged. W63 derived the pointwise Bernoulli-KL/L2 step and
the positive-V branch; root independently reconstructed them and derived
the complete piecewise geometry. W15 independently checked the L2 factor,
positive-V confidence branch and passive negative-V branch before this
freeze. Specific priority UNKNOWN; no physical acquisition is asserted.

## First-exit contract and stronger information inequality

Use the finite ordinary time-even CTMC, stationary-off start, identical
pulse and first-exit probabilities from aging_witness/PROOF.md (SHA256
8b3a4ceeb8e9b99e93cb6f22c2f5958f2ee1af5c1eb76f8dcc77a843e8687a80).
Retain b=pi(B), T=exp(tau K_BB), f=T1, f*=T*1 and their common w-mean z.
Let sigma be stationary ordinary path-reversal entropy production, with
positive reverse rates when a finite KL value is claimed.

Map full stationary baseline paths on [0,tau] to their initial hidden state
i and the bit C that the whole interval remains in B. The two initial
marginals are both pi. Conditional on i in B, the bit has Bernoulli
parameters f_i and f*_i under the forward and reversed laws; outside B it
is identically zero. Relative-entropy data processing and its chain rule
therefore give

`sigma tau >= sum_{i in B} pi_i BernKL(f_i || f*_i)`
`          >= 2 b ||f-f*||_w^2`.                         (1)

The last step is Pinsker applied separately to each Bernoulli pair, whose
total variation is |f_i-f*_i|. This retains the initial-state conditioning
before averaging. Those hidden labels are used in the proof only; the
empirical estimator neither observes nor reconstructs them. Applying
Pinsker only after averaging loses information and gives the earlier weak
L1 bound. No extra measurement or microscopic input is required for (1).

## Geometry lemma, including the negative-V branch

Let u=f*-z1, v=f-z1, a=E_w g in (0,1), D=c-za and V=z2-z^2. In the
first-exit contract, V=<u,v>_w; more generally it is enough that
`<u,v>_w <= V`. Cauchy-Schwarz and 0<=g<=1 imply

`A=||u||_w^2 >= q=D^2/[a(1-a)]`.

For a fixed mixed inner product C=<u,v>_w and A>0,

`||u-v||_w^2 >= A+C^2/A-2C`.

Minimizing the right side over A>=q yields the continuous function

`L(q,V) = 0`                         if `V>=q`;
`L(q,V) = (q-V)^2/q`                 if `q>0 and -q<=V<=q`;
`L(q,V) = -4V`                       if `V<=-q`.

At q=0 define L(0,V)=max(0,-4V). Boundary formulas agree. The minimum is
at A=|V| when |V|>=q and otherwise at A=q. L is nondecreasing in q and
nonincreasing in V. Consequently C<=V also implies

`||u-v||_w^2 >= L(q,C) >= L(q,V)`.

For completeness, in the middle branch the q derivative is
`1-V^2/q^2>=0` and the V derivative is `2(V-q)/q<=0`; the other branches
are constant in q and either constant or decreasing in V. This verifies the
monotonicity needed for confidence intervals, not just at the true means.

Combining with (1) proves

`sigma >= 2 b L(q,V)/tau`.                              (2)

If V=0, it reduces to `2b D^2/[a(1-a)tau]`, quadratic in a small aging
signal rather than quartic. If V<0 and q<=-V, it is
`sigma >= 8b(-V)/tau`; the passive survival-variance defect already gives
information without a pulse covariance. The q=0 case is therefore defined
without dividing by a vanishing signal. A pulse with a=0 or1 has D=0 and
may be ignored, retaining the passive branch only.

## Finite confidence evaluation

Use the same simultaneous feature box as the frozen packet. Let d_min be a
lower bound on |c-za|, let v_g_up bound a(1-a) from above, let V_up bound
z2-z^2 from above, and let b_lo bound the stationary off probability from
below. Set q_lo=d_min^2/v_g_up when that denominator is positive. Then

`sigma_lo = 2 b_lo L(q_lo,V_up)/tau`

is conservative under the same coverage event. If v_g_up is zero, set
q_lo=0 and retain only the passive branch. Return UNKNOWN if no positive
lower bound survives or if the preparation/observation/confidence premises
are absent. No stronger statistical guarantee is inferred from the bound's
algebraic improvement.

## Scope and established methods

Bernoulli Pinsker, relative-entropy data processing and constrained quadratic
geometry are established tools. This is a tighter evaluation of the same
observable contract, not a claim to a new general information inequality.
The ordinary equally informed incumbent obtains exactly (2) as well.

Odd time-reversal labels, nonstationary samples, detector memory or changes
in the actual pulse operator remain exclusions. Endpoint or memoryless
emission variants require their own exact probability definitions and are
proved separately. This result is not a universal calorimetric inequality.
Internal proof supplied and independently reconstructed; novelty UNKNOWN,
physical validation NOT_ACQUIRED, all-resource advantage NOT_ESTABLISHED,
mission NOT_ACHIEVED.
