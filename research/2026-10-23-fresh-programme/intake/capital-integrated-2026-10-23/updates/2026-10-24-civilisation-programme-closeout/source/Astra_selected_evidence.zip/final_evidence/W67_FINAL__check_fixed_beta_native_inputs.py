"""Exact finite precision/continuum delta for the factor-two-beta rows.

Own arithmetic replay from frozen row data, not an independent audit.
No source/filter/table/native encoder or actual physical device is run.
Partial query counts and access-precision bits are not whole gate counts.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
Z, ETA = F(1, 1000), F(1, 100)


def ceiling(x):
    x = F(x)
    return -(-x.numerator // x.denominator)


def bits(x):
    x = F(x)
    if x <= 1:
        return 0
    b = x.numerator.bit_length()-x.denominator.bit_length()
    return b if F(2)**b >= x else b+1


def run(row):
    k, t, w = row['k'], row['t_mesoblock'], row['w_bin']
    b0 = F(row['b_reference'])
    G, kap, chi = F(1, 74400), F(1, 96000), F(1, 100000)
    assert F(row['source_gain_lower']) == G
    assert F(row['source_drift_lower']) == kap
    assert F(row['chi_squared_upper']) == chi
    assert k == (1/(10*b0)).numerator//(1/(10*b0)).denominator
    assert F(row['actual_b_upper']) == 4*b0
    eps = F(row['eps'])
    assert row['B0'] == bits(F(2**30*k**6)/(G*kap))
    assert chi*t >= row['B0']+4
    assert w == ceiling(2*chi*t)+1
    cells = (k*t+1)*(2*w+1)
    assert cells == row['table_cells_upper']
    assert bits(cells)+2*row['B0']+32 <= t*G/8
    assert eps*(4*k+1) <= G/16
    s = row['s_mesoblocks']
    body, flush, initial = row['forward_body'], row['forward_terminal'], row['forward_initial']
    R, BR, Bq = row['R_outer'], row['B_R'], row['Bq']
    q = F(1, 2**Bq)
    assert body == k*s*t and R == 2**BR and R >= 16*body
    assert flush <= body and 2*(2*(body+flush)+1) <= R
    Bgrid = Bq+BR+5
    assert row['B_grid_cardinality'] == Bgrid
    assert 2**Bgrid >= 16*R/q+2
    assert 2*(body+flush)*q/(16*R) <= q/64
    tL, Ct = kap/(8*k*k), 6/(kap*(kap/(8*k*k)))
    eta_w = ETA/32
    eta_p_bits = bits(32/ETA)
    eta_p = F(1, 2**eta_p_bits)
    cutnum = 5*eps*s+2*eta_w+bits(1+Ct)+Bq+eta_p_bits+Bgrid+12
    H = ceiling(cutnum/tL)
    assert H == row['body_depth_cutoff']
    assert flush == 16*(H+Bq+6)
    assert H*tL >= cutnum
    # After cancelling F and Ctail, e>2 makes this a rational upper.
    per_grid_mean = eta_p*q/(4096*2**Bgrid)
    union_bound = 2*2**Bgrid*per_grid_mean/(q/4)
    assert union_bound == eta_p/512
    assert initial == 16*(2*Bq+12)
    total = initial+body+flush
    assert total == row['forward_total']
    assert row['logical_width'] >= F(row['target_rate'])*total
    assert F(row['target_rate'])-F(3, 2) >= 4*b0/476160
    Qouter = row['row_queries_outer']
    Ienc = Qouter+1
    assert Ienc == row['whole_encoder_invocations']
    Delta_parent = Z/(4096*Ienc)
    Delta = Delta_parent/(8*s)
    assert F(row['parent_encoder_accuracy']) == Delta_parent
    assert F(row['one_inner_accuracy']) == Delta
    BDelta = bits(1/Delta)
    Bsig = 2*BDelta+32
    signal = F(1, 2**Bsig)
    Bgap = (row['Bmu']+3)//2
    gap = F(1, 2**Bgap)
    d = ceiling(8*(Bsig+2)/(gap*gap))
    d += int(d%2 == 0)
    Qupper = (1<<(2*Bgap))*64*(Bsig+1)
    assert 4*d+4 <= Qupper
    qb = row['inner_polar_query_upper']
    assert qb['power_two_exponent'] == 2*Bgap
    assert qb['integer_multiplier'] == 64*(Bsig+1)
    assert qb['log2_upper_integer'] == bits(Qupper)
    assert 648*signal < Delta*Delta
    xi = signal/(4096*Qupper)
    assert 9*Qupper*xi == 9*signal/4096
    MB = 1+F(4, 25)*b0*k*(k-1)
    alpha_star = (1+16*MB)/2
    a0 = bits(1+2*MB)
    domain = max(t*a0, w)+max(t, w)+4
    Bpe = bits((40*domain/xi)**2)
    Tpe = 1<<Bpe
    dL = xi*domain/(1024*Tpe)
    dB = dL/(16*t*MB)
    dlog = dL/(2*t)
    assert 8*t*MB*dB+t*dlog == dL
    assert F(25*domain*domain, 4*Tpe) <= xi*xi/256
    assert 16*Tpe*dL/domain == xi/64
    assert 16*(q+F(1, 2**row['initial_cutoff'])) <= (Z/32)**2
    encoder_error = 2*Ienc*Delta_parent
    full_error = 3*Z/32+Z/32+Z/4+encoder_error
    assert full_error == F(769, 2048000) and full_error < Z
    fbits = bits(32*s/ETA)
    failure_union = ETA/32+eta_w**2+s*F(1, 2**fbits)+eta_p+eta_p
    assert failure_union < ETA
    return {'reference_beta_denominator': row['reference_beta_denominator'],
            'k': k, 'forward_total': total, 'M_B': str(MB),
            'acquired_alpha_star': str(alpha_star), 'function_domain': domain,
            'signal_tolerance_bits': Bsig, 'inner_gap_bits': Bgap,
            'function_isometry_accuracy_bits': bits(1/xi),
            'T_PE_power_two_exponent': Bpe,
            'L_operator_accuracy_bits': bits(1/dL),
            'B_operator_accuracy_bits': bits(1/dB),
            'per_source_log_accuracy_bits': bits(1/dlog),
            'grid_union_budget': str(union_bound),
            'native_encoder_channel_error_bound': str(encoder_error),
            'full_error_bound': str(full_error),
            'program_failure_union_bound': str(failure_union),
            'not_a_full_native_gate_or_wall_clock_count': True}


def main():
    source = HERE/'FIXED_BETA_FORWARD_GUARDS.json'
    target = json.loads(source.read_text())
    rows = [run(row) for row in target['rows']]
    result = {'status': 'PASS_EXACT_FINITE_NATIVE_INPUTS',
              'scope': __doc__,
              'rows_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
              'rows': rows, 'physical_status': 'NOT_PERFORMED',
              'mission': 'NOT_ACHIEVED'}
    payload = json.dumps(result, indent=2)+'\n'
    out = HERE/'FIXED_BETA_NATIVE_INPUTS.json'
    if out.exists():
        assert out.read_text() == payload, 'refuse changed frozen output'
    else:
        out.write_text(payload)
    print(json.dumps({'status': result['status'], 'rows': rows}, indent=2))


if __name__ == '__main__':
    main()
