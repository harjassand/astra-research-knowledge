# Finite initializer promises and pointwise normal-state scope

23 October2026. Separate clarification accepted during W39's fresh audit
of bindingd8142311. All frozen candidate/guard/count/review bytes remain
unchanged. This qualification NARROWS the general finite-horizon wording;
it adds no physical acquisition of an initial bath tail.

The selected three scalar rows have the SUPPLIED geometric bound

    Tr P_(L>A)tau <= 2^-A.

Their A=Bq+8, initial prefix, exact all-forward rate and error arithmetic
remain valid. The joint-polynomial finite onset in k,z^-1,eta^-1,L_b
applies at this stated initializer class (or another class with a known
polynomial finite tail modulus). It is not uniform over all normal tau.

For a general supplied tail modulus, the appropriate explicit input is
an integer A with

    Tr P_(L>A)tau <= epsilon_init, epsilon_init=z²/2^16. (I1)

This tolerance depends on the target error, not on the much smaller body
q=2^-Bq. Count

    n_initial=16[A+ceil log2(1/epsilon_init)+4].          (I2)

The unchanged actual zero-input/root argument gives descent failure
nu_prefix<=epsilon_init from depth at most A. The original full-channel
prefix error is therefore

    4sqrt(q_A+nu_prefix)
       <=4sqrt(2epsilon_init)<z/32.                   (I3)

This retains the initializer/bath/reference independence and static-
sector coherence contract. The prefix is not a measured bath reset.
All I2 device calls belong in the rate. Increase the source mesoblock
count s by the same finite rate doubling until this extra initial cost
is amortized. It is a linear input cost in A; the resulting family has
polynomial cost in the EXPLICIT tuple(k,z^-1,eta^-1,L_b,A), given the
tail promise. No claim that A itself is polynomial in z^-1 is made.
The digital Fourier degree and row count still use only body plus
terminal flush; the physical rate counts all three portions.

For arbitrary normal tau without a supplied computable modulus, there
is no claimed finite-horizon algorithm that certifies I1, nor a uniform
polynomial finite-error onset. Retain the pointwise tail term
4sqrt[Tr P_(L>A_N)tau+nu_prefix,N] with A_N increasing to infinity.
For each fixed normal tau its first summand tends to zero. This supports
the corresponding pointwise asymptotic coding statement when all other
budgets also tend to zero; it does not supply an effective common tail
modulus or a uniform rate of that convergence.

Slow or uncomputable normal-state tails are not ruled out. The known
source parameter and quantum-generated public probability table also
retain their separate information/preprogramming qualifications. Physical
validation NOT_PERFORMED; practical advantage NOT_ESTABLISHED; mission
NOT_ACHIEVED.
