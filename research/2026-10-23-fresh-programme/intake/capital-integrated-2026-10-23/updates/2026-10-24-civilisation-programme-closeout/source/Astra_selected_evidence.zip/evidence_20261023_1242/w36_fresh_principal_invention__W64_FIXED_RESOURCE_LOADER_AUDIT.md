# Fresh audit of fixed-resource loading and capacity reduction

23 October 2026, w36. Entire exact source independently reconstructed:

* w64/fixed_resource_loader/FINITE_PREPARATION_AND_CAPACITY_V1.md,
  SHA25628008c7e0568aeb083720ade53788ab5ddeea3275dc1db0a027bc7b2723eccd6.
* Mandatory PROBE_SIGN_CORRECTION.md,
  SHA25638995aa235770beb5dc3c0384542af03ec4bd37ef3c0df9b4f82650ee8e9f7b6.
* RECOVERY_AND_DIAMOND_CLARIFICATION.md,
  SHA256021461ee2ead7bcd0dbbca603b2f98dbad64a5ea37a3a8ea7dbfab2519ae7028.

Verdict: **NO BLOCKING DEFECT FOUND FOR THE CORRECTED PACKET AT ITS STATED
FIXED-RESOURCE, FINAL-DISCARD, PRESHARE/BACKWARD-WIRE SCOPE**. The literal
V1 probe mean is false; its sign was independently caught in this audit
and must NOT be silently read as correct. The mandatory correction repairs
that local failure without changing the loader theorem's constants.
This is internal analytic criticism, not external/formal validation or
historical priority. Original frozen bytes are preserved.

## 1. Independent probe sign finding and repaired inference

For root sector x, direct native two-call expansion gives A=a on|01>,
B=-b+i alpha beta x on|10>, and i alpha beta on|00> with bathword1.
For the literal V1 Y=i(|01><10|-|10><01|),

    <Y>=i(A*B-B*A)=-2a alpha beta x.

This is the OPPOSITE of V1 L4. Keeping the original classifier would
misidentify the physical sector and invalidate the later preparation
choice. Replacing Y by its negative, as the separately frozen correction
does, gives +x m_beta. The zero projector and recovery are unchanged.

The corrected plus/minus outcomes have a one-dimensional sector-root bath
state. The zero outcome has known depth1/color1. Vacuum recovery has
success probability a and failure b at each measured attempt. Unlimited
recovery therefore terminates almost surely for beta<1, returning the
same root state. The IDEAL k probe samples are iid with mean x m_beta.
Conditioning finite capped recoveries on no abort biases their zero
frequency, so the literal conditional-iid wording in V1 should not be
used. The clarification correctly couples the capped run to the ideal,
then adds at most k b^r to Hoeffding's ideal wrong-sign bound. Its L5 is
valid without an unchanged conditional mean.

## 2. Sector coherence and the legal known-program transformation

The global seed flip X commutes with every V and with all local maps and
communication wires. Thus each recorded Kraus branch remains block
diagonal in its eigenvalue. Every offdiagonal sector block has zero final
bath trace, even with arbitrary initial bath/lab correlations. This is
an operational final-discard equivalence, not a whole-resource state
equivalence or permission to dephase an externally returned purifier.

For a FIXED target eta, the occupied-sector weights p_x are fixed. If
sum p_x F_N,x tends to1, positivity of each infidelity implies F_N,x tends
to1 in each occupied sector. One fixed occupied sector can therefore be
chosen. This inference would fail for arbitrary N-dependent vanishing
sector weights and is not extended to them.

I checked U_-=-P U_+ P: parity changes the sign of both creation blocks
while leaving the root projector, and the outer minus gives the correct
negative root eigenvalue. Consequently
V_-= -P overline(V_+) P. This is an identity between EXISTING sectors.
Replacing every KNOWN local Kraus family by its matrix-conjugated family
is CPTP; it specifies a new local program. No antiunitary is applied to
an unknown logical state, and no inverse physical V gate is assumed.
Quantum wires are real identities. Neighboring bath parity factors cancel
through local maps; the final parity is traced and the fixed number of
minus phases is irrelevant. Transforming the supplied resource to
P overline(eta_+)P and conjugating ALL local controls yields the conjugate
decoded channel, whose Bell fidelity is identical against real Phi.

This is performance equivalence for identity transmission. It is not a
physical exact implementation of matrix conjugation on an arbitrary
unknown input, nor arbitrary-channel simulation. A finite approximation
to the transformed bath resource is loaded through its known word program;
P is not supplied as an extra bath operation. Adaptive classical branches
and quantum backward messages obey the same expansion.

## 3. Reset, finite support and exact coherent loading

Vacuum reset has the native Kraus operators alpha J+i beta I and alpha S_j*.
Shell traces remove all commutator/cross-depth terms, giving the stated
absorbing depth recurrence and exact binomial tail L2. For every FIXED
normal initializer, dominated convergence makes this tail vanish, even
without finite mean depth. The root compression is close in ordinary
unhalved trace norm by at most2sqrt(tail). There is no uniform finite-time
guarantee over all normal bath states.

Within a known sector the root is one dimensional. A failure of one
H-port attempt started at root has bath support<=H. The proof explicitly
DISCARDS every used quantum program, lab purification and output on a
failure. Only classical control records and fresh unused independent
program copies remain. Conditional on those classical records, the reset
bath marginal is close to the same pure sector root; this is why the
ordinary2sqrt(tail) bound is sufficient for the retry hybrid. One must not
silently preserve a quantum reference to a failed program and use the
same marginal bound as a reference-preserving diamond bound. The stated
construction does not do so. First-j-resets-ideal hybrids ensure each
reset being replaced has a support<=H input; real residual tails need
not independently obey that support cutoff at every stage.

The padded words0^(H-|w|)reverse(w) are orthogonal. On the all-vacuum
herald branch their leading vacuum calls occur only at root, with phase
alpha x+i beta of modulus1; each following color is a native push with
amplitude alpha. This proves gamma_w and the normalization
Z=sum a^(-|w|)||chi_w||^2. Program coefficients gamma_w^-1/sqrtZ therefore
give EXACT chi with probability1/Z>=a^H. They preserve all finite desired
bath/lab coherence and entanglement; a Bob share of the known program is
an allowed initial A:B preshare independent of the bath and fresh source.
Heralding is observed from actual forward outputs and coordinated backward.

Retries count all H-port attempts, reset calls and failures. With fresh
tensor-product program copies the ideal failure probability is bounded
by(1-a^H)^R; the reset hybrid contributes at most2R sqrt(binomialtail).
Unsuccessful caps yield an unconditional default output, not a normalized
accepted branch. Finite bath AND finite local-register compressions
approximate a fixed normal eta in trace norm. A finite purification may
be put at Alice and ignored by the body; no original inaccessible G is
required for an objective that traces G. Requiring G/bath return would
invalidate this reduction.

## 4. Counted asymptotic limit and retained-output padding

For each fixed approximation index m all required word cutoffs, program
copies, discrimination caps, reset lengths and finite precision requests
have finite cost, however large. Taking a cumulative cost maximum permits
a slowly increasing m(N) with cost o(N). This is an existence diagonal,
not an efficient compiler, a uniform state-preparation rate or a procedure
for unknown noncomputable resource descriptions. T0(N)=floor(sqrtN)
handles the unknown independent FIXED bath tail pointwise with the same
schedule for every fixed normal tau. Convergence is not uniform in tau.

The fresh source is untouched during all preprocessing, so every branch
probability and variable preparation duration is source independent. Bob
observes the heralds, and all coordination is on the allowed backward
wire. Starting the body at random successful prep time supplies no logical
carrier. Unused budget calls placed AFTER Bob has decoded act only on the
complement of the isolated retained output. A TP map on that complement
cannot change its R:Bob marginal, even if the bath is still entangled with
it. Filling failure branches too enforces the same total prescribed calls.

The resulting rate comparison holds in the SAME model granting initial
A:B preshares and backward communication, with no terminal return. It
does not imply equivalence to an unassisted model. The supplied program
resources can vary with the approximation index and are allowed in that
preshare model; their potentially enormous preparation/precision/energy
costs are recorded rather than inferred negligible from o(N) forward calls.
Arbitrary horizon-dependent eta_N is outside the theorem unless it comes
with its own o(N) preparation bound.

## 5. Optional diamond-error clarification

If a mixture channel is diamond-close to identity, every pure input with
an arbitrary reference has a pure ideal target. Its infidelity is at most
epsilon/2. Positive weighted sector infidelities then give an individual
sector bound epsilon/(2p_x), uniformly in the input/reference. Fuchs--van
de Graaf gives the stated2sqrt(epsilon/(2p_x)) sector trace distance and
hence diamond bound; no dimension-dependent Choi estimate occurs.
Conjugation preserves the diamond distance to identity. An initial
resource trace error independent of the unknown input remains at most
that error under every fixed adaptive TP body, even with a reference;
an abort branch costs at most twice its probability. These steps justify
the optional reliable-diamond capacity reduction at exactly the same
final-discard interface. No whole-device process norm or original purifier
return follows.

## 6. New independent finite evidence and limits

Own implementation `fixed_resource_loader_audit_check.py` uses only my
earlier native seeded-tree tensor engine; no peer code was imported.
Raw `FIXED_RESOURCE_LOADER_AUDIT_DIAGNOSTIC.json` SHA256
449e182b4dc2d4e579f7f24644d189ba236548c6d4dcec7cbcaa7876355f1664.

Ten native probes retain both literal and corrected means. Twenty-four
complex coherent loaders at H1--3, both sectors and beta0/.1/.4/.9 verify
the complete success vector,1/Z probability and failure support. Their
nontrivial failures are reset and checked against the EXACT shell-weighted
binomial tail and the support-H bound. Twenty-four two-call Haar-complex
local protocols use genuinely bath/lab entangled states and a quantum
return wire; the transformed opposite-sector decoded states equal the
complex conjugates, including K2/K3 and initial depths0--2. Maximum loader
state residual1.89e-16; conjugation residual0; shell-tail residual1.07e-14.
Missing native edges are asserted unpopulated and never reflected.

These test local finite identities and the sign repair. They do NOT
establish an infinite-tail uniform rate, allN diagonalization, efficiency,
physical preparation, historical novelty or a matching capacity value.
The analytic scope and all paid-versus-supplied resources remain essential.
