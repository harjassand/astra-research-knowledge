# Actual-record full-supply converse — independent root reconstruction

23 October2026. Root independently reconstructed this converse after W38's operational sufficiency theorem and parallel W44 necessity investigation. It uses established squashed-entanglement monotonicity and elementary entropy inequalities. This is an internal source-specific theorem, not novelty certification or a physical record-acquisition result.

Fix finite D>=2,L>=2 and a finite prior p, iid original inventories K^r. Each queue is Phi_D^k tensor nu_D^(L-k). An ACTUAL finite duplicated record Z is formed by a known stochastic channel from K^r, with the accessible quantum state conditional on K^r,Z remaining the exact original product. Put B=E[K] lnD, H_r=H(K^r|Z). Any local apparatus is initially independent and product across receivers; no entangled stock is supplied. All logarithms are natural.

## Exact information expression

Let Y_i be the full generalized-Bell label of queue i in a mathematical diagonalization; it is NOT an acquired physical measurement. The conditional channel W_k to Y_i has its first k labels zero and the other L-k labels uniform on D^2 symbols. For k<l, the support of W_l is nested in that of W_k and

TV(W_k,W_l)=1-D^(-2(l-k)) >= delta_D=1-D^-2.

Every local A or B marginal is uniform. Consequently for the actual conditional mixture given Z,

I(A:B|Z)=2rL lnD-H(Y^r|Z)=2rB-I_r,
I_r=I(K^r:Y^r|Z).

The second identity uses the EXACT conditional source-preserving product interface: H(Y^r|K^r,Z)=2(rL-sum_i K_i)lnD on average. Correlations in the posterior K^r|Z are fully allowed.

Supply another mathematical copy of Z to the squashing system. For the real source with Z duplicated at the receivers,

E_sq(source) <= (1/2)I(A:B|Z)=rB-I_r/2.                 (1)

The record's large classical mutual information is removed by this squashing extension, so it is not accidentally counted as entanglement. Classical alphabet size is finite at each r but need not be subexponential.

## Finite Bell-error inequality without a continuity theorem

For ANY finite bipartite state omega_AB,

E_sq(omega_AB) >= I_c(A>B)_omega = -S(A|B)_omega.      (2)

Indeed, for every extension ABE, weak monotonicity gives S(A|E)>=-S(A|B), while strong subadditivity gives -S(A|BE)>=-S(A|B). Adding gives I(A:B|E)>=2I_c(A>B); take half the infimum. Thus no iid-hashing or asymptotic continuity assumption is needed for this step.

Compose any finite TP LOCC protocol with bilateral finite Weyl twirling on its output of deterministic local rank N. This remains LOCC, preserves its Bell fidelity, and makes both output marginals uniform. If the Bell infidelity is e<=epsilon<=1/2, its Bell-diagonal entropy is at most h2(e)+e ln(N^2-1). Therefore

E_sq(output)>=I_c(output)>= (1-2epsilon)lnN-h2(epsilon).

LOCC monotonicity, tracing all actual residuals, and (1) imply the EXACT finite inequality

(1-2epsilon)lnN-h2(epsilon) <= rB-I_r/2.              (3)

A complete-output half-trace error epsilon to Phi_N tensor the OWN actual residual implies Bell infidelity<=epsilon, so (3) holds for the user's stronger residual contract. There is no postselected branch normalization and no supplied Bell stock. Rank-one output is harmless. Independent normal product apparatus reduces to finite effective source/output channels; its local preparation is free LOCC in this resource statement, not an asserted physical zero cost.

## Lower bound for the information leak

For any prior u on K, put Wbar=sum u_k W_k and t_k=TV(W_k,Wbar). Pinsker in nats gives

I_u(K:Y)=sum_k u_k D(W_k||Wbar)>=2 sum_k u_k t_k^2.

Triangle and (a+b)^2<=2(a^2+b^2) give

delta_D^2(1-sum_k u_k^2)
 <= sum_(k,l)u_k u_l(t_k+t_l)^2
 <=4 sum_k u_k t_k^2.

Since sum u_k^2<=max u_k, with c_D=delta_D^2/2,

I_u(K:Y)>=c_D(1-max u).                              (4)

Let u_i=P(K_i | Y_<i,Z). Memoryless source diagonalization gives the exact chain identity

I_r=sum_i E I_(u_i)(K_i:Y_i).

Meanwhile data processing of the earlier inventories into Y_<i gives

H_r=sum_i H(K_i|K_<i,Z)<=sum_i E H(u_i).

For e(u)=1-maxu, Fano gives H(u)<=g_L(e)=h2(e)+e ln(L-1). This function is concave and increasing on [0,1-1/L]. Jensen and (4) imply

H_r/r <= g_L(min{I_r/(c_D r),1-1/L}).                (5)

In particular, I_r=o(r) iff H_r=o(r), since I_r<=H_r always. Equivalently, writing g_L^-1 for the increasing inverse on [0,lnL],

I_r/r >= c_D g_L^-1(H_r/r).                          (6)

Equations(3),(6) give a quantitative finite-rate deficit when the actual residual inventory entropy has positive density. All constants depend only on the FIXED source D,L, not the record channel, alphabet, posterior correlations or queue count.

## Operational conclusion and limits

A reliable rate approaching the ideal B forces I_r/r->0 by (3), and then H_r/r->0 by (5). W38's separate constructive sampling/sparse-error theorem proves the converse implication with zero entangled aid and deterministic rank. Thus, after independent audit of that construction, full supply B is achievable iff H(K^r|Z)=o(r), under the stated source-preserving record contract and two-way LOCC.

This says nothing about how to acquire Z cheaply. The original unflagged nontrivial source has H_r=rH(K), so it is excluded; its precise second-order deficit remains open. Strict one-way receiving has a separate complement-record obstruction, even when H_r=ln2. No simultaneous growing D,L assertion is included. Quantum correctness, exact field priority, physical interface and practical usefulness are separate statuses.

The established definition and LOCC monotonicity used here originate in Christandl–Winter, quant-ph/0308088v3, J.Math.Phys45(2004)829–840: https://arxiv.org/abs/quant-ph/0308088 . Their original abstract explicitly leaves general continuity open; our proof deliberately supplies the finite inequality(2)-(3) directly and does not attribute a later continuity theorem to that paper.
