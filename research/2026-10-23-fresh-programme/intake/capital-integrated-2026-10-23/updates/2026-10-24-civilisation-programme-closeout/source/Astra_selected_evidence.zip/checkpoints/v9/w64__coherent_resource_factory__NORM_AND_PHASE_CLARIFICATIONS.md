# Mandatory conventions for the frozen coherent factory V1

23 October 2026. Root's independent full-proof inspection identified two finite-interface ambiguities. This addendum controls those conventions; c544c1a94006cf8619947b852a472da57d04a703a59be3effc74e67580d63c34 remains byte-for-byte unchanged.

1. Every trace and diamond error used in the epsilon budget is UNHALVED. The approximate-root allowance in sections 1 and 6 means the trace NORM is at most epsilon/4; if the phrase trace distance is reserved for half the norm, the required trace distance is at most epsilon/8. With an old purifier/reference G present, a sufficient initialization promise is explicitly JOINT:

       ||Omega_EG - |r_x><r_x|_E tensor Omega_G||_1 <= epsilon/4.

   The local input F and its fresh reference can then be adjoined, or a uniform joint promise can be used for an already entangled input. Contractivity adds at most epsilon/4 to the unhalved output error. A marginal bath estimate of epsilon/4 is NOT substituted for this joint promise. If only a root-projector failure probability p is known, purification/gentleness first gives a product with a suitable conditioned G state within unhalved norm 2sqrt(p); comparing instead to the actual old marginal Omega_G costs at most an additional 2sqrt(p). Thus the conservative sufficient bound 4sqrt(p)<=epsilon/4 may be used. Such conditioning does not assert that the original G state or its seed-sector coherences are restored. The exact-root theorem and its uniform channel bound need no correction.

2. The inverse-search residual is the FULL eigenphase

       r_q = min_(m integer) |2q theta - 2pi m| in [0,pi].

   It is not the half-angle distance min_m|q theta-pi m|. With L=ceil(8pi/delta), Dirichlet gives some q<=L with r_q<=2pi/(L+1)<=delta/4. If theta is supplied in an interval of radius delta/(16L), its full-phase uncertainty is at most delta/8 for q<=L. Accept a computed FULL residual at most delta/2; existence follows and the true r_q is at most 5delta/8<delta. The exact inverse norm is

       ||V^(2q-1)-V*|| = 2|sin(r_q/2)| <= r_q < delta.

   Therefore all constants and the O(T^2/epsilon) call bound in V1 remain valid with this explicit residual definition. A circular pigeonhole proof using the L+1 points 0,theta,...,Ltheta modulo pi yields the stated pi/(L+1) half-angle bound, including the wraparound gap.

No additional physical preparation, return, novelty or capacity claim follows from this clarification. Fresh independent verdict on V1 plus this addendum remains separate from finite diagnostics.
