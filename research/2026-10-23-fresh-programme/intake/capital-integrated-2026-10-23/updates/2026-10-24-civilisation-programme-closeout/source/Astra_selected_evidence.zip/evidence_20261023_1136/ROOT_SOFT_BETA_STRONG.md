# A soft-beta all-resource strong-converse extension

23 October 2026. Root derivation; candidate until the beta-zero sector lemma and this extension receive fresh criticism. This is a mathematical bound on the supplied tree interaction, not a physical acquisition result.

Assume the exact fixed-N, sole-forward-port, fresh-message contract of W19/W36's independently constructed beta-zero all-resource sector bounds. The initial bath and all laboratories may share any normal entangled resource independent of the fresh logical Bell input. Backward quantum communication and independent A--B preshares are allowed. The candidate beta-zero lemma is:

For n U-slots and s designated direct identity-qutrit slots, n+s=N, each aggregate colored input/output sector (q,o) on the U-slots has q+o<=n and unnormalized Bell expectation at most

    9^s min(D_q(n)^2,D_o(n)^2)/K^2,
    D_j(n)=binom(n,j)2^j.

Proof interface: at either communication cut the fixed sector's forward identity-wire Choi vector has dimension 3^s D_j(n), hence is CP-dominated by the fixed correlated replacer with factor [3^s D_j(n)]^2. The comparison includes all s unrestricted wires as well as the charge-restricted n wires. The other counter is local at this cut. A selected sender-side branch is bounded by the complete no-forward TP comparator output; it is not asserted to be a normalized product. The positive linking argument does not require that the CP difference be a normalized comb. Arbitrary ordering of designated slots is immaterial to the finite-port inequality and causality of the fixed-output comparator.

Let M_n=(n+1)(n+2)/2. Coherent summation over the allowed sectors and min(D_q^2,D_o^2)<=8^n give, for the fixed designated-slot pattern S,

    sqrt(F_S) <= M_n 3^s (sqrt(8))^n/K.

The physical gate V=alpha U+i beta I has alpha=sqrt(1-beta^2), beta>=0. Purify the fixed strategy and initial resource. Multilinearity of the N chronological gate insertions gives its final amplitude exactly as a sum over all identity-slot subsets S,

    |Psi_beta> = sum_S alpha^(N-|S|)(i beta)^|S| |Psi_S>.

The same local strategy is used in each term, including its coherent records and all adaptive backward operations. No agent knows or observes S. Applying the Bell projector to this amplitude and taking its Hilbert norm, triangle inequality yields

    sqrt(F_beta)
      <= K^-1 sum_(s=0)^N binom(N,s) alpha^(N-s) beta^s
                       M_(N-s) (sqrt(8))^(N-s) 3^s
      <= M_N [sqrt(8) alpha+3 beta]^N/K.

Thus the candidate full bound is

    F_beta <= min(1, M_N^2 [sqrt(8) sqrt(1-beta^2)+3 beta]^(2N)/K^2).

It is an exponential strong converse for rates above

    log2[sqrt(8) sqrt(1-beta^2)+3 beta],

whenever this improves the ordinary log2(3) ceiling. It recovers 1.5 at beta=0 and has only a linear small-beta correction. It does not establish the quadratic strong-converse threshold that the independently reviewed weak converse suggests investigating. No entanglement/coherence resource price is introduced here.

The linear loss is exactly where triangle inequality discards the alternating physical phase i^|S|. A naive fugacity-weighted single-gate singular norm also has a linear |beta| term, so replacing triangle by a simple local operator norm does not immediately solve that sharper problem. The important remaining question is whether a phase-sensitive causal/moment bound retains the entropy-based quadratic penalty for arbitrary entangled initial resources.

Critical obligations: the beta-zero counter/network lemma under arbitrary feedback; the mixed restricted/unrestricted wire CP comparison and its causal fixed-output comparator; coherent expansion for adaptive purified protocols; and normal infinite-resource limits. No independent claim is made about continuous-time feedback, variable stopping, correlated fresh messages or extra forward carriers.
