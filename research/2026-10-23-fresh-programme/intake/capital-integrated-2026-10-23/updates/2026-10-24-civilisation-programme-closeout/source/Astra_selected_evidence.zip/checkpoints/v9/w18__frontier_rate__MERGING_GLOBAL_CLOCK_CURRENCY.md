# Finite coherent-information and global-clock currency

23 October 2026, w18. Independently generated after the unrecorded-data
coarse-read argument. This applies credited state merging to the actual
source-weighted information bill. Internal proof candidate; historical
novelty and external correctness UNKNOWN. The ordinary unrestricted
second-order LOCC deficit is not claimed solved.

The source is exactly pinned PROOF(1), revision
e606bfc587c76bdcae8b8fa3ec33e721efa2fbac. Actual inaccessible clocks,
independent product old memory and normal local-product apparatus remain
unchanged. D,L,p are fixed before reliable repetition limits. All stocks
are exact independent Bell inputs, all instruments finite TP LOCC, all
branches retained, and Bell purity is lifted to the OWN complete residual.

## 1. A finite-device inequality with a global output measurement

Consider ONE arbitrary finite LOCC device on r original source queues,
with exact independent input Bell stock Phi_S. Let its actual retained
data ports be Q=A B, and let its actual clock/data marginal be rho_(K^r Q).
It may have arbitrary other residual, and Q need not be iid, MC, pure,
or a successful distillation output. All dimensions are finite. Optionally
retain a separate Bell-return port of rank P, with unconditional Bell
infidelity gamma<1/2. It may initially be correlated with Q. A missing
return port means P=1, gamma=0.

For ANY finite GLOBAL POVM Y on Q, define its mathematical joint law with
the actual K^r by applying that POVM to rho_(K^r Q). No ability to apply
this global measurement by free LOCC is granted. Let

    I_c(Q)=S(B)-S(A B),
    v_P(gamma)=(1-gamma)log[(P+1)/2]-h2(gamma),
    B_supply=E K log D.

Then the following is an exact inequality about that one finite device:

    I_c(Q)+I(K^r:Y)+v_P(gamma) <= r B_supply+log S.         (1)

The coherent information may be negative. The global POVM is paid by
reference-preserving merging; it is not silently treated as a local test.

### Proof by independent repetition of this finite device

Hold r and this entire finite device fixed. Repeat it independently m
times on mr actual original source queues, with input stock Phi_(S^m).
The resulting actual Q states are iid repetitions of this ONE block
density rho_Q. This does not assert that the original r-wide output
factors over its r source queues.

Choose a fixed integer C with log C>-I_c(Q). Supply and charge an
independent Phi_(C^m), equivalently one Phi_C per device block. Apply
the established state-merging theorem to Alice's Q_A AND her Phi_C
half, with Bob's Q_B and Phi_C half as side information. Its negative
conditional entropy is

    S(A C_A|B C_B)=-I_c(Q)-log C<0.

For every fixed delta>0 below I_c(Q)+log C, finite TP one-way LOCC
mergers exist, for all sufficiently large m, with deterministic Bell
rank N_m satisfying

    log N_m/m -> I_c(Q)+log C-delta,

one global error tending to zero, and the ORIGINAL state rho_Q^tensor m
transferred to Bob's lab. They preserve a purification. The reference
may include all actual K clocks, both parties' unused return ports and
all other residual. The reserve is fully paid; no catalytic or recycled
seed is being assumed. The original Phi_C is also transferred locally
to Bob; only the newly returned Bell rank N_m is credited.

Bob now implements the formerly global POVM Y separately on each
reconstructed Q block. This is a local operation in his laboratory.
On the ideal merged state its classical law with K is the m-fold law
used in (1). Merging error and classical conditional-entropy continuity
on the fixed K^r alphabet therefore imply

    I(K^(rm):actual Y^m)/m -> I(K^r:Y).                    (2)

The actual transcript includes these Y outcomes. Other merger messages
can only increase the clock information entering the radius bill.
The merger and Y measurement do not act on any original rank-P return
port. A TP map on all other ports preserves EACH unconditional return
marginal exactly, even when the old ports were correlated with Q.
Consequently every one of the m returned ports has infidelity gamma.

Apply the source-weighted finite information bill to this whole actual
LOCC device, now with input stock S^m C^m. Test the m rank-P returns
sequentially and the new rank-N_m Bell port last. Each is the established
finite random-basis LOCC Bell test. On the ALL-WHITE comparison input,
every conditional history leaves every remaining target separable.
The pass probability on any such history is at most2/(rank+1).

The divergence chain rule and entropy concavity give one term
v_P(gamma) per old return, plus

    (1-eps_m)log[(N_m+1)/2]-h2(eps_m)

for the newly distilled Bell port. Individual failures are bounded by
their Bell infidelities; monotonic replacement on [0,1/2) is valid.
No actual independence of the tested ports is required. Nonselective
tests on other ports leave each unconditional tested marginal unchanged.
The radius identity then yields

    I(K^(rm):T_m)+m v_P(gamma)
      +(1-eps_m)log[(N_m+1)/2]-h2(eps_m)
        <= mr B_supply+m log S+m log C.                  (3)

Divide by m and take the credited merger's reliable limit. Its error
times log N_m is o(m); (2) applies. Subtract the paid log C and take
delta down to zero. This proves (1).

This auxiliary m limit is used only to prove an inequality about EACH
fixed finite r-device. It does not exchange a growing source family with
the reliable original-source limit. There is no unknown source-capacity
assumption and no need to generate the reserve from the output itself.

## 2. Paired MC data with arbitrary work held by Bob

Let A and B_0 have the same fixed basis {|a>} and let W_B be an arbitrary
finite quantum work register held ONLY by Bob. Any density Gamma on
A:B_0 W_B supported on the paired subspace has the form

    Gamma=sum_(a,b) |aa><bb|_(A B_0) tensor R_(a,b),        (4)

with the block operator positive. Dephase only Alice's paired index:

    tau=sum_a |aa><aa| tensor R_(a,a).

It is separable across A:(B_0 W_B), since each R_(a,a) is positive.
Its nonzero spectrum is exactly the spectrum of Gamma_(B_0 W_B).
The projective pinching identity therefore gives

    D(Gamma||tau)=S(tau)-S(Gamma)
                =S(B_0 W_B)-S(Gamma)=I_c(Gamma).

Credited unassisted one-way hashing and the separable relative-entropy
upper bound squeeze this to the EXACT resource identity

    E_D(Gamma)=E_R,SEP(Gamma)=I_c(Gamma)>=0.               (5)

The same algebra holds for every tensor power. Thus the relative-entropy
value is additive. Bob's work may be noncommuting, label dependent,
mixed, nonorthogonal, collectively encoded or very large. It need not
be a readable record or an orthogonal entangled flag. Positivity itself
implies (4) whenever the A B_0 marginal is MC in that fixed paired basis.

An extra quantum shield held by Alice is NOT part of (4). Leaving usable
Alice work outside Q does not allow its potential to be credited under
this theorem. A declared return Bell port is instead billed explicitly
in (1). These distinctions preserve the complete resource accounting.

## 3. An original-clock measurement independent of local padding

Now let Gamma_r be ANY target on the original r-queue native data
A=B_0=(C^D)^tensor(Lr) and arbitrary Bob work W_B. It may have arbitrary
correlations across its r queues. The actual clock law is still p^tensor r.
For each k^r assume its DATA marginal is

    Phi_D on all original live prefix positions
       tensor delta_(k^r) on the other native positions,                (6)

where delta_(k^r) is ANY computationally diagonal MC density, with
arbitrary classical correlations across suffix sites/queues. This includes
zero padding, uniform shared padding, soft or biased shared padding,
and data with an attached arbitrary Bob-local quantum clock encoding.
It does not assume the governing stopped record survives.

Measure the data globally in the D-ary MC phase bases

    |Phi_z>=(1/sqrt D)sum_a exp(2pi i az/D)|aa>, z=0,...,D-1.

Each actual live prefix yields phase0. On ANY diagonal MC suffix string,
every phase string has the same squared overlap D^(-number of suffix
sites). This remains true after an arbitrary diagonal mixture and across
arbitrarily correlated suffix probabilities. Consequently conditional on
k^r the observed phases are zero in the live prefixes and INDEPENDENT
uniform D-ary symbols on the rest. The phase outcomes can be replaced
by their first nonzero positions, including overflow.

The mathematical overshoot G_i between K_i and that first nonzero phase
is capped geometric with zero probability q=1/D. Its mean is at most
q/(1-q), and hence its entropy is at most

    c(q)=-log(1-q)-q log q/(1-q).

Thus this explicit finite global POVM Y obeys

    H(K^r|Y)<=r c(1/D),
    I(K^r:Y)>=r[H(K)-c(1/D)].                            (7)

No actual global clock measurement is supplied to the source protocol.
In the proof of (1), and only AFTER paid merging, this POVM becomes local
to Bob. D need not be a power of two. The Fourier phase basis here uses
the actual native D levels and no idealized XOR alphabet.

The target (6) is paired MC, and positivity forces every extension by
Bob's work to have (4). Therefore (5) applies to Gamma_r even when its
Bob work has arbitrary cross-queue quantum correlations.

## 4. Finite target-approximation bound, including huge Bob work

Suppose the actual r-device has clock/data/work marginal rho_r within
half-trace distance beta of a Gamma_r satisfying (4),(6), JOINTLY with
the actual clock. Alice's retained target dimension is

    d_A=D^(Lr).

Bob's work dimension can be any finite number, with no growth bound.
The conditional-entropy continuity bound depends ONLY on d_A:

    I_c(rho_r)>=I_c(Gamma_r)-2beta log d_A-g(beta),
    g(beta)=(1+beta)h2[beta/(1+beta)].                     (8)

This is Winter1507.07775v6, Lemma2, personally read for this application.
It avoids an invalid error times log(dim Bob work) estimate. The same
global phase POVM and the original clock's unchanged marginal give

    I_actual(K^r:Y)>=I_target(K^r:Y)
                        -beta r log|supp p|-h2(beta).     (9)

The latter is the elementary classical conditional-entropy continuity
bound already proved in the source-clock bill. Define

    F_r(beta)=2beta r L log D+beta r log|supp p|
                                      +g(beta)+h2(beta).

Substitute (5),(7)--(9) into the exact finite-device inequality (1):

    E_R,SEP(Gamma_r)+v_P(gamma)
        <= r[B_supply-H(K)+c(1/D)]+log S+F_r(beta).        (10)

Equivalently, in the usual net-currency form,

    E_R,SEP(Gamma_r)+log P-log S
       <=r[B_supply-H(K)+c(1/D)]+F_r(beta)
                                  +gamma log P+h2(gamma)+log2.       (11)

The log2 is only the finite Bell-verifier conversion
log P-log[(P+1)/2]<=log2. Formula (10) is a little sharper.

For every fixed source and beta_r->0, F_r(beta_r)=o(r), without ANY
assumption on Bob's work dimension. Exact return P has gamma=0 and
may be huge. Approximate return needs gamma_r log P_r=o(r), as before.
Every target in this class therefore has asymptotic net entanglement
potential at most

    B_supply-H(K)+c(1/D).                                 (12)

This closes a logarithmic saving from ANY target of the paired-MC/
diagonal-suffix/Bob-work architecture, including soft padding and
locally locked quantum clock records held by Bob. It is strictly broader
than preserving the old stopped-classifier data or a particular flag.
It is NOT an upper bound on a receiver that produces a different
non-MC state or retains a useful quantum shield on both sides.

## 5. Consequences, boundaries and provenance

For the unrecorded zero-padded data of the preceding note,
I_c>=B_supply-2c(1/D). Equation (10) consequently improves its sufficient
preparation-cost obstruction from H-5c to H-3c, while removing any need
to implement the local last-nonzero read. The older coarse-read theorem
is preserved: it is a direct finite-measurement proof with a different
scope and an independently inspected explicit local operation.

For uniform shared suffix padding, the local clock may be hidden
entirely, but (10) still applies. For arbitrary Bob-local nonorthogonal
clock encodings, local accessible information can be much smaller than
Holevo information; no equality between them is assumed here. Paid
merging makes the specified GLOBAL phase measurement operational.

An arbitrary successful original distiller need not keep any Q with
both high coherent information and a globally readable original clock.
Its unused Alice quantum work may carry large negative conditional
entropy or the clock may reside in a genuinely two-sided shield.
The supplied original source itself has low coherent information, so
(1) is not a direct H-O(1) converse by taking Q to be its unchanged input.
These are the load-bearing remaining obligations.

The state-merging, hashing, relative-entropy, entropy-continuity and
information-radius ingredients are established machinery, not new
physical primitives. I personally read HOW0512247v1 Definition1,
Theorem2 and its proof/Remark7; DW0306078v1 SectionIII/Theorems10,13;
and Winter1507.07775v6 Lemma2. Exact primary URLs:

https://arxiv.org/pdf/quant-ph/0512247v1
https://arxiv.org/html/quant-ph/0306078v1
https://arxiv.org/pdf/1507.07775v6

The new application was generated before requesting fresh criticism.
No efficient merger search, code compilation, physical experiment,
hardware cost or practical advantage is claimed. All local memory,
gate precision, messages, exact reserve formation, stock, discarded
outputs and reset are costs. Historical priority/external correctness
UNKNOWN; physical/practical/computational advantage NOT_ESTABLISHED;
mission NOT_ACHIEVED.
