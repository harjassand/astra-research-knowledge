# A finite local reader converges pointwise on every normal known-sector bath state

24 October2026(local),w64. Corollary candidate after forward-only source501ee943... . Generic relaxation/download control and strong-versus-uniform convergence distinctions are prior. This is an explicit native normal-state scope statement with counted finite decoders. No earlier upload/inverse review is inherited; fresh criticism PENDING.

## PNR1. One input-independent finite protocol at each horizon

Fix the unchanged native V=alpha U+i beta I, known0<=beta<1, a=1-beta^2>0, and a KNOWN conserved seed-X sector x. The input on the physical bath can be any UNKNOWN joint NORMAL state rho_ER supported in that sector, with arbitrary reference/laboratory R. No entropy, mean-depth, tail rate or classical state description is supplied. The bath need not initially be root.

For integer T>=1 choose

    H_T=floor(aT/2).

Run T physical forward native calls, each with a fresh VACUUM port from Alice. Bob retains all output ports and appends the locally encoded depth<=H_T word register F_T at its empty-word basis state. He applies the explicit finite LOCAL decoder W_+F* of source501ee943..., using the known x,beta and the signed-stack completion U_(H_T). This is a predetermined finite circuit depending only on T,x,beta; it does not inspect the unknown state or require a tail oracle. It needs exactly T forward calls, zero feedback and zero quantum returns.

For inputs deeper than H_T, the decoder's arbitrary LOCAL boundary completion can be occupied. It is a legitimate local unitary there; it is not required to simulate the infinite bath on that bad-depth part. The proof below controls that part by its input tail weight. The physical bath is never truncated.

## PNR2. Compare in a common output Hilbert space

Embed the finite F_T into a canonical infinite word register F_infty. Write J_T for the physical-read/local-decode isometry after that embedding. On the known sector define the ideal complete isometry

    S_T: |psi>_E -> |r_x>_E |0^T>_P |psi>_(F_infty). (PN1)

All Bob ports and the final physical bath are retained in this comparison. Let P_H project the INPUT bath onto words of length<=H and define

    p_T=Tr[(I-P_(H_T))rho_E],
    tau_T=Pr[Bin(T,a)<H_T].                         (PN2)

The finite-depth operator proof already establishes

    ||(J_T-S_T)P_(H_T)||<=sqrt(2tau_T).

Since both maps are isometries, ||J_T-S_T||<=2 on the remaining input space. Purify rho_ER, including any additional reference needed, and split its vector into P_H and I-P_H components. Their norms are sqrt(1-p_T) and sqrt(p_T). The triangle inequality therefore gives a purified output vector error at most sqrt(2tau_T)+2sqrt(p_T), and hence the UNHALVED JOINT trace-norm bound

    ||(J_T tensor I_R)rho(J_T* tensor I_R)
          -(S_T tensor I_R)rho(S_T* tensor I_R)||_1
       <= min(2, 2sqrt(2tau_T)+4sqrt(p_T)).         (PN3)

This is a complete reference-preserving statement for the WORD information: it moves that information and its correlations to F_infty while resetting E to root. It does not preserve the input unknown state in E as well, nor transfer unresolved quantum seed-sector coherence. No marginal-only root promise is substituted for this joint comparison.

For H_T>=1, aT>=2H_T and Chernoff gives tau_T<=exp(-aT/8). If H_T=0 then tau_T=0 directly. Since P_H increases strongly to the identity in this sector, normality gives p_T->0 for every FIXED rho_ER as T->infty. Thus the complete output in(PN3) converges to the ideal reader target, with no entropy/moment assumption and no supplied convergence rate. The SAME sequence of finite protocols works for all such fixed normal inputs.

The finite inequality also covers horizon-dependent rho_T with arbitrary N-dependent references whenever their actual tail p_T->0. Fixed normality is one sufficient tail condition, not a necessary one. Arbitrary normal horizon families without that condition are not covered.

## PNR3. Uniform unhalved diamond error is exactly two at every horizon

The pointwise statement must not be promoted to unrestricted uniform convergence. For each T choose the normal basis input word

    |1^(T+1)>_E.

T actual VACUUM calls can pop at most T letters, so the physical bath remains NONROOT with probability one. Bob's subsequent LOCAL decoder cannot change E. The ideal output(PN1) has E at root. Their final outputs have orthogonal bath supports, giving trace norm exactly2. Therefore the unrestricted unhalved diamond distance between the actual reader and ideal isometry is

    ||channel(J_T)-channel(S_T)||_diamond=2

for EVERY finite T. This does not contradict(PN3): the adversarial input itself depends on T and has p_T=1. It is a concrete same-device witness of the missing uniform quantifier, not a small simulated error.

## PNR4. Optional quantitative uniformity from a supplied depth constraint

If a class of arbitrary joint input states satisfies the supplied mean WORD-DEPTH constraint Tr[N_depth rho_E]<=M, Markov gives p_T<=M/(H_T+1). Consequently the complete reference-supremum error on this class is at most

    min(2,4sqrt(M/(H_T+1))+2sqrt(2exp(-aT/8)))       (PN4)

for H_T>=1. A sufficient forward count for error epsilon is O_beta[M/epsilon^2+ln(1/epsilon)+1]. This is a depth-constrained complete-channel bound; depth is not called physical energy without an additional physical Hamiltonian model. The bound/constraint is supplied prior information and is charged as such.

Without this constraint there is no quantitative tail rate. For example the normal diagonal law p_h=1/[(h+1)(h+2)], on one known unary word at each depth, has infinite mean depth and tail Pr[h>H]=1/(H+2). It is still covered pointwise by(PN3). Slower normal tails also prevent a universal normal-state convergence rate. No finite-time uniform efficiency or entropy transfer claim follows from normality alone.

## PNR5. Full costs, prior art and what is not learned

The protocol uses T actual forward calls, O(H_T+T) local qubits/qutrits up to encoding factors, and T explicit local signed-stack inverse steps. A straightforward compiled decoder costs O[T H_T polylog(H_T+1)] logical gates before phase-synthesis overhead. Operator error e_T in that whole local decoder adds at most2e_T to(PN3); a local rounded parameter with ||V(beta)-V(beta_tilde)||<=kappa_T adds at most2T kappa_T. Choose e_T->0 and T kappa_T->0 if finite numerical compilation is used. Actual physical-call error, coherence time, memory noise, local precision, energy and error correction must be counted separately.

The unknown beta acquisition packet can precede the read because its COMPLETED probes restore arbitrary old bath/reference states, but its cap/statistical errors and quantum-return permission must be added. The present theorem itself assumes known beta and does not inherit an acquisition review. Initial conserved-sector identification and arbitrary unknown seed-purifier return are not established here.

This is a read/reset interface for quantum information ALREADY IN the bath. It is not a free encoder putting a fresh logical source there, a new fresh-message capacity code, an algorithm discovering scientific features, or recovery of a classical description of an unknown state. Generic relaxation/download control is Burgarth--Giovannetti2007 PRIOR. Scope-specific mathematical priority UNKNOWN; physical validation NOT_PERFORMED; practical advantage NOT_ESTABLISHED; programme mission NOT_ACHIEVED.
