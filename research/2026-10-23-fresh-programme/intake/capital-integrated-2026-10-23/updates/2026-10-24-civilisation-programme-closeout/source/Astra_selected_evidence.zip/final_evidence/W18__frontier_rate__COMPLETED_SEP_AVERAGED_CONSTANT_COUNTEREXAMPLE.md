# Completed SEP measurements also falsify the proposed averaged constant

24 October 2026, W18. **INTERNAL EXACT FINITE COUNTEREXAMPLE.** This
closes the present exact POVM unit before the user-requested drain.
It is not a LOCC implementation, a Bell distillation receiver, a
failure of every D-dependent constant, or an additive-second-order
capacity theorem. Novelty and external correctness remain UNKNOWN.

## Four explicit separable effects

Fix D>=3. Initially use three binary core clocks j_i in {0,1}, uniform,
so the accessible state is omega_D^tensor3, omega_D=(Phi_D+I/D^2)/2.
This core is lifted to the unchanged original K in {1,2} source below.
Put

    P0=Phi_D, P1=(I-Phi_D)/(D^2-1),
    zeta=(1/D)P0+[(D-1)/D]P1.

Both P1 and zeta are separable: independent isotropic twirling of
|0><0| tensor |1><1| and of |0><0| tensor |0><0| produces them.
Define normalized separable states

    tau0=P1^tensor3,
    tau1=(1/3)sum_i zeta_i tensor P1_on_the_other_two,
    tau7=zeta^tensor3.

Let tauG be the independent three-site isotropic twirl of the rank-one
product |GHZ+><GHZ+|_A tensor |conjugate(GHZ-)><conjugate(GHZ-)|_B,
with GHZ+/-=(|000>+/-|111>)/sqrt2 in the native D-level systems.
Every unitary in this twirl is local across A:B, so tauG is separable.
Compactness and finite-dimensional convexity allow an exact finite
product-state decomposition; no free continuous operation is assumed.

For a sector bit string b in {0,1}^3, let j=|b| count complement
sectors. The coefficient below is its probability on EACH bit string,
not the sum over its binomial multiplicity:

    tau0: (0,0,0,1),
    tau1: (0,0,1/(3D),(D-1)/D),
    tauG: (0,1/(2D^2),(D-2)/(2D^2),
                     1-3/(2D)+3/(2D^2)),
    tau7: ((D-1)^j/D^3)_(j=0..3).                     (1)

For tauG, the direct GHZ reduced overlaps are f_i=f_ij=1/2 and
f_123=0. Inclusion-exclusion of the Phi projectors gives exactly (1).
All states in (1) are normalized after multiplying each entry by
binom(3,j).

Set

    q0=(D^3-3D^2+D+1)/D^3,
    q1=3(D-1)/D^2,
    qG=2(D-1)/D^3,
    q7=1/D^3.                                        (2)

All four numbers are positive for D>=3 and sum to1. Direct comparison
on each of the eight orthogonal sectors proves the OPERATOR identity

    q0 tau0+q1 tau1+qG tauG+q7 tau7=I/D^6.            (3)

Consequently E_y=D^6 q_y tau_y, y=0,1,G,7, form a finite four-outcome
SEP POVM. The effects are positive, separable, and sum to I. No
numerical LP feasibility premise is used.

## Exact outcome laws and strict inequality

Against the core all-white state the outcome law is q_y. On
omega_D^tensor3 the likelihood ratios ell_y=p_y/q_y are

    ell0=1/8,
    ell1=(D+1)/8,
    ellG=(2+3D+3D^2)/16,
    ell7=(D+1)^3/8.                                  (4)

These follow either from the sector eigenvalues of omega_D^tensor3 or
from the eight original clock likelihoods. Both sum q_y=1 and
sum q_y ell_y=1 hold exactly. Thus the completed measurement has

    D_meas=sum_y q_y ell_y log ell_y,
    average F=D_meas-(3/2)logD+3log2.                 (5)

At D=128 this gives

    average F=0.2036775969330486...,
    3c(1/D)=0.1381444205071631...,
    average F-3c(1/D)=0.0655331764258855...>3/50.      (6)

The strict comparison is certified by directed RATIONAL logarithm
intervals, not floating signs. Each log is reduced to [1,2], expanded
as 2 sum_(j>=0) t^(2j+1)/(2j+1), t=(x-1)/(x+1), with64 terms and
the exact geometric upper remainder. Terms are rounded outward on a
2^-192 grid. The standalone standard-library checker records the full
rational interval and proves its lower endpoint exceeds3/50.

For fixed three copies and D tending to infinity, the remainder in
(5) tends to (3/8)log(3/2)>0 while 3c(1/D) tends to0. This limit is
only an additional diagnostic of this PARTICULAR constant. It does
not exchange the fixed-source r-first capacity limit.

## Exact lift to the original native source

Take native L=2, uniform original K_i in {1,2}, r=3. Each original
first site is exactly Phi_D independently of the uncertain second
sites, so the full accessible state factors as Phi_D^tensor3 on the
known sites times omega_D^tensor3 on the uncertain sites. The actual
inaccessible clocks and independent old memory remain the original
ones. No entangled stock is added.

On the known sites perform the local computational basis comparison
and let Pi_eq be the projector onto agreement at all three known
pairs. The five native effects are Pi_eq tensor E_y for the four
core outcomes, together with (I-Pi_eq) tensor I. They form a finite
SEP POVM: Pi_eq and its complement are sums of computational product
projectors. The source fails this known-site test with probability0;
the all-white reference passes with probability D^-3. Therefore

    D_native=D_meas+3logD,
    3B_native= (9/2)logD,
    3H_native=3log2.

Subtracting 3(B_native-H_native) leaves exactly the averaged F in
(5). Thus (6) is a counterexample under the unchanged native-source
clock convention, with known prefixes explicitly INCLUDED. This
mathematical SEP POVM has no established finite LOCC implementation.
The native comparison does not teleport using or erase the known
prefix as an uncharged aid.

## Separate completed PPT-only control

For comparison, replace tauG by a normalized invariant PPT state tauP
with sector probabilities (0,1/[D(D+2)],0,1-3/[D(D+2)]). Its positive
partial transpose has, up to positive row factors, the four eigenvalues
4,4/(D+2),0,4(D-1)/(D+2). It is positive/PPT for every D>=2; no SEP
decomposition of this particular state is asserted. The exact weights

    qP0=(D-1)^2(D^2-D-4)/D^4,
    qP1=3(D-1)^2(D+2)/D^4,
    qPP=(D-1)(D+2)/D^4,
    qP7=1/D^3

again average tau0,tau1,tauP,tau7 to white for D>=3. Its special
likelihood is ellP=(3D^3+7D+2)/[8(D+2)], with the other three ratios
as in (4). At D=32, the completed PPT remainder exceeds3c(1/D) by
0.0596854917265908...>1/20, independently certified by the same rational
log method. The SEP construction (1)--(6) is the stronger operational
restriction and does not rely on promoting this PPT state to SEP.

## Prior art and final scope

Rippchen--Sreekumar--Berta, arXiv:2405.05037v1, Proposition23 and
AppendixB, give the single-isotropic-state-pair locally-measured
divergence for all LO/one-way/LOCC/SEP/PPT classes; that single-copy
baseline is established PRIOR. I personally read their exact statement
and proof, and the additivity discussion in Section5.2.2. Its pure-Phi
additivity and max-divergence conditions do not establish relative-
entropy additivity for our mixed omega_D pair. Their general
variational bounds explicitly need not be tight. Primary:
https://arxiv.org/pdf/2405.05037v1 .

This proof exhibits completed finite SEP/PPT POVMs and falsifies only
the proposed averaged r c(1/D) constant. It does not establish their
optimum, a LOCC tree, a native Bell receiver, a logarithmic-in-H saving,
or a failure of a more permissive O_D(1) remainder. The universal
coefficient-one theorem and reviewed merging/global-clock currency
remain unchanged. Actual additive second order is OPEN. Mission
NOT_ACHIEVED. No further investigation is initiated during the drain.
