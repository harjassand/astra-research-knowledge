"""Independent exact actual-gradient fixture for the original-face-once lemma."""
from fractions import Fraction as Q
from collections import defaultdict
import json
from pathlib import Path

def nodal(i,j):
    x=Q(i,4)
    bump=([Q(0),Q(1,8),Q(0),Q(-1,8),Q(0)][j]
          if i in (1,3) else Q(0))
    return ((2*x+bump,Q(0)) if i<=2
            else (Q(1),2*x-1+bump))

def point(v): return (Q(v[0],4),Q(v[1],4))
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def det(a,b): return a[0]*b[1]-a[1]*b[0]
def gradient(tri):
    p,p1,p2=map(point,tri)
    a,b=sub(p1,p),sub(p2,p)
    du1,du2=sub(nodal(*tri[1]),nodal(*tri[0])),sub(nodal(*tri[2]),nodal(*tri[0]))
    d=det(a,b)
    return tuple(((du1[k]*b[1]-du2[k]*a[1])/d,
                  (a[0]*du2[k]-b[0]*du1[k])/d) for k in range(2))
def rank_at_most_one(A): return det(A[0],A[1])==0
def matrix_sub(A,B): return tuple(sub(a,b) for a,b in zip(A,B))
def apply(A,v): return tuple(sum(x*y for x,y in zip(a,v)) for a in A)

faces=[]
for i in range(4):
    for j in range(4):
        for tri in [((i,j),(i+1,j),(i+1,j+1)),((i,j),(i+1,j+1),(i,j+1))]:
            A=gradient(tri)
            assert rank_at_most_one(A)
            group=0 if any(A[0]) else 1
            assert all(x==0 for x in A[1-group])
            faces.append(dict(tri=tri,A=A,group=group,weight=Q(1,32),id=len(faces)))

# All physical shared edges, including periodic identifications. Tangential
# derivatives are independent of the affine value shift at a period boundary.
edges=defaultdict(list)
for f in faces:
    for a,b in zip(f['tri'],f['tri'][1:]+f['tri'][:1]):
        key=tuple(sorted(((a[0]%4,a[1]%4),(b[0]%4,b[1]%4))))
        edges[key].append((f,sub(point(b),point(a))))
facet_checks=0
for ee in edges.values():
    assert len(ee)==2
    f,t=ee[0]; g,_=ee[1]
    assert apply(matrix_sub(f['A'],g['A']),t)==(0,0)
    for group in (0,1):
        rf=f['A'][group] if f['group']==group else (Q(0),Q(0))
        rg=g['A'][group] if g['group']==group else (Q(0),Q(0))
        assert sum(x*y for x,y in zip(sub(rf,rg),t))==0
    facet_checks+=1

groups=defaultdict(list)
for f in faces: groups[f['group']].append(f)
nodes=[]
def leaf(f):
    node=dict(id=len(nodes),weight=f['weight'],A=f['A'],leaves=[f['id']])
    nodes.append(node); return node
def merge(a,b):
    assert set(a['leaves']).isdisjoint(b['leaves'])
    assert rank_at_most_one(matrix_sub(a['A'],b['A']))
    w=a['weight']+b['weight']
    A=tuple(tuple((a['weight']*a['A'][i][j]+b['weight']*b['A'][i][j])/w
                  for j in range(2)) for i in range(2))
    node=dict(id=len(nodes),weight=w,A=A,leaves=a['leaves']+b['leaves'],
              children=[a['id'],b['id']])
    nodes.append(node); return node
packets=[]
for group,fs in sorted(groups.items()):
    packet=leaf(fs[0])
    for f in fs[1:]: packet=merge(packet,leaf(f))
    packets.append(packet)
root=packets[0]
for packet in packets[1:]: root=merge(root,packet)
assert root['A']==((Q(1),Q(0)),(Q(1),Q(0)))
assert root['weight']==1
assert sorted(root['leaves'])==list(range(32))
assert len(nodes)==63
assert all(len({f['A'][group] for f in fs})>1 for group,fs in groups.items())
for i in range(5): assert sub(nodal(i,4),nodal(i,0))==(0,0)
for j in range(5): assert sub(nodal(4,j),nodal(0,j))==(1,1)

result=dict(status='PASS_FINITE_EXACT_FIXTURE',source='actual rational nodal map',
    faces=len(faces),periodic_facets=facet_checks,output_line_groups=len(groups),
    group_weights=[p['weight'] for p in packets],group_means=[p['A'] for p in packets],
    root_gradient=root['A'],tree_nodes=len(nodes),tree_merges=len(nodes)-len(faces),
    each_original_face_once=True,groups_have_varying_input_covectors=True,
    faces_and_tree=dict(faces=faces,nodes=nodes),
    limits='Finite exact diagnostic; theorem is the written distributional/null-minor argument. Priority UNKNOWN.')
out=Path(__file__).with_name('RANK_ONE_OUTPUT_GROUP_EXACT_FIXTURE.json')
out.write_text(json.dumps(result,default=str,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='faces_and_tree'},default=str,indent=2))
