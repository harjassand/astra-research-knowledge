# Post-checkpoint: coupled-time concentration and pump non-return

w50, 23 October 2026. This is separate from frozen `AUDIT.md` SHA256
`96d22d7436271d5bd07c52907cfa672a6f305f4a07ea06ee63a77243998232fd`.
The original root c7b733/709264 source bytes and every earlier receipt
remain unchanged. The original Poisson theorem already passes without
anything below.

After freezing my source-bound audit, I read W30's independent sharpening
`INDEPENDENT_PROOF.md`, SHA256
`06454d78c331f93831f573389ecd79ac6ea941e63e05a42abf38ed20f58b468f`,
and W42's `W30_LINEAR_SHARPENING_COMPOSITION.md` and
`ROOT_POISSON_PUMP_INDEPENDENT_AUDIT.md`. Their E6 cancellation, y(1)>=s,
receiver composition and Poisson/resource extensions reconstruct. The
coupled-time extension below was then derived by me, explicitly using
W30's combined-antocommutator mechanism. W42's cautious original E12 use
through sqrt2 is valid and stays frozen. No exclusive priority is claimed
for the evaluated extension or any generic semiclassical method.

## 1. W30 mechanism and its exact hypothesis

Use the root finite observables with S=N+m, s=S/N, lambda=L/N and
a=S/L. In a fixed initial ladder vector, let

    u=(Y-y)psi, v=(X-x)psi,
    B=4(1-a)I-6(Y+yI)/lambda,
    h=2Ypsi/(lambda N), ||h||<=2/N.

The exact equations give

    E'=2 Re<v,(I+B)u+h>, E=||u||^2+||v||^2.

If ||I+B||<=5, this is at most
10||u||||v||+4||v||/N<=6E+4/N^2. Starting E(0)=s/N,

    E(tau)<=e^(6tau)s/N+(2/(3N^2))(e^(6tau)-1)
           <=e^(6tau)[s/N+4tau/N^2].                 (F1)

W30 established the sufficient condition y<=2s and a<=1/4 through
tau<=1 (and certain constant bands). Its condition sinh^2(tau)<=2 is
not automatically valid all the way to sqrt2. A further parameter
argument is required; that is the purpose of the next section.

## 2. Improved constant for the EXACT original mean6J source

For root709264, J=N+M, L in [4J,8J] and the fixed physical time give

    tau_L^2=L/(4J), 1<=tau_L<=sqrt2, a=S/L<=1/4.

Before its first classical turn, r'<=1 implies y(u)<=s sinh^2 u.
For all 0<=u<=tau_L,

    y(u)/lambda <=(S/L)sinh^2 u
       <=sinh^2(tau_L)/(4tau_L^2)
       <=sinh^2(sqrt2)/8 <1/2.                       (F2)

Here sinh(t)/t is increasing: the derivative numerator
t cosh(t)-sinh(t) starts at zero and has positive derivative t sinh(t).
The elementary inequality sinh(sqrt2)<2 can be proved without rounded
constants: its series divided by sqrt2 is at most
1+1/3+(1/30)/(1-1/21)=821/600<7/5<sqrt2.
The original turning-time proof ensures the trajectory exists on this
whole interval; alternatively F2 prevents reaching y=lambda there.

For spectral z in [0,lambda],

    I+B =5-4a-6z/lambda-6y/lambda
          in [-4-4a,5] subset [-5,5].

Thus W30's E6 inequality F1 is valid through each actual tau_L, even
though y need not remain below 2s. Its lower trajectory bound at time1
and monotonicity give y(tau_L)>=s. For any fixed 0<eta<1,

    Pr[ell<(1-eta)S | good L]
       <=min(1, e^(6sqrt2)/eta^2
                         [1/N+4sqrt2/N^2]).          (F3)

Add the SAME Poisson tail 2exp(-2J/7) and the SAME code bound
sqrt(2-eta) exp[-N(ln(2-eta)-r)/2], for r<ln(2-eta). The finite-readout,
pure-coherent, correlated-source and actual-residual proofs in AUDIT
are unchanged. This improves W42's valid WS3 exponential factor
e^(12sqrt2) to e^(6sqrt2), with its full parameter scope stated.

W30 and W42 both subsequently reconstructed this original-band argument
in messages. These are limited analytic peer comments, not new reruns of
my diagnostics or a blanket physical certificate.

## 3. A coupled scalar lemma covering a wider pump band

This section is a NEW parameter lemma, not an assertion that the frozen
root709264 source had different mean or endpoints. Fix the same time
t=1/[chi sqrt(4J)], but allow L in [2J,8J]. Put z=tau_L^2=L/(4J), so
z in [1/2,2] and a=S/L<=1/(4z). Define

    H(z)=[1+(3/2)sinh^2(sqrt z)]/z.

H is strictly convex for positive z. Indeed

    H(z)=1/z+(3/2)sum_(k>=1) 2^(2k-1) z^(k-1)/(2k)!,

whose second derivative is a convergent sum of nonnegative terms plus
2/z^3. Hence its maximum on [1/2,2] is at an endpoint. The bounds are
fully explicit:

    cosh(sqrt2) <=2+(1/6)/(1-1/15)=61/28,
    H(1/2)=2+3sinh^2(1/sqrt2)<=211/56<4,
    H(2)<[1+(3/2)*4]/2=7/2<4.

The cosh bound follows by starting its tail at 2^2/4!=1/6 and bounding
each successive term ratio by 1/15. Thus H(z)<=211/56<4 throughout.

The scalar trajectory exists increasingly through tau_L: before a putative
turn, y/s<=sinh^2 u<=sinh^2 tau_L<2tau_L^2, whereas a turn would require
y/s=1/a>=4tau_L^2. This is impossible. On the whole interval,

    a[4+6y(u)/s] <=[1+(3/2)sinh^2(tau_L)]/tau_L^2
                  =H(z)<4.                         (F4)

Two useful consequences follow at once:

    p(y)-2s=y[4-a(4+6y/s)]>=0,
    y(u)>=s u^2,
    min spec(I+B)>=-1-H(z)>-5, max spec(I+B)<=5.

Therefore F1 holds through tau_L for every L in [2J,8J], every S<=J,
without incorrectly asserting a<=1/4 at the lower endpoint. More
generally a chosen subband with tau_L^2>=z_- supports thresholds c<z_-
and gap z_--c in the Chebyshev denominator.

A broad [2J,8J] band has z_-=1/2, so by itself it only supplies
c<1/2. It must not be used to claim a near-S threshold. Narrowing the
ANALYTIC band around 4J, without measuring or selecting the pump, solves
that different issue as in the next section.

## 4. A distinct mean4J coherent/Poisson endpoint candidate

This explicit corollary is post-target, not a silent update to root709264.
For N>=256, put

    xi=N^(-1/4), mu=4J,
    t=1/[chi sqrt(4J)], K=8J,
    c_N=1-2xi,
    r_N=ln(2-2xi)-xi,
    D_N=2^floor(Nr_N/ln2).

For the finite startup N<256 take D_N=1 and the corresponding fixed
product default. Prepare either the Poisson-diagonal shared pump of
mean4J or a pure coherent pump of that mean; no pump measurement or
postselection is used. Analyze its integer good band

    ceil[4J(1-xi)] <=L<=floor[4J(1+xi)].

Multiplicative Chernoff gives

    p_bad <=2 exp[-4J xi^2/(2+xi)].                  (F5)

The band has tau_L^2 in [1-xi,1+xi] subset [1/2,2]. By the coupled
lemma, y(tau_L)>=s(1-xi), while the bad receiver event ell<c_N S has
distance at least xi s. Thus

    p_low <=min(1, e^(6sqrt2)/xi^2
                                  [1/N+4sqrt2/N^2]). (F6)

The exact old sector ratio is >=(1+c_N)^(N-1). For N>=256, r_N>0 and
Nxi>=ln(1+c_N), so D_N<=C/R and the cyclic code is valid. It gives

    q_code <=sqrt(1+c_N) exp(-Nxi/2)
            <=sqrt2 exp(-N^(3/4)/2).                (F7)

The complete finite receiver therefore has

    q_N<=min(1,p_bad+p_low+q_code),
    d_actual<=min(1,sqrt(q_N)+q_N),
    ln D_N/N ->ln2,
    q_N=O(N^-1/2), d_actual=O(N^-1/4).              (F8)

The same fixed8J count cutoff works; only the proof band narrows. Every
actual source/pump/reference extension and default remains retained.
The joint initial-number effect from AUDIT applies also to arbitrary
source-pump correlations at fixed Poisson number law, although their
preparation resource is not thereby free.

Initial pump mean energy and max-Gibbs upper price are now those for
mu=4J rather than6J, both O(J). For a pure coherent pump the max-order
price is exactly mu(q^-1-1)-ln(1-q); all coherence is included. This
reduces a model constant and removes neither the active pump resource
nor the supplied equal-mode control, input cap, vacuum, seed, storage,
huge code/decoder, purity, precision and reset interfaces. There is no
practical or yield advantage claim. Constants in F6 remain conservative,
and an endpoint-rate sequence need not have favorable finite-block error
compared with a fixed smaller rate.

The SAME pump with optical vacuum has ell>=c_N N with the same error.
Stirling uniformly at this threshold gives rates approaching
g(1)=2ln2, for example take g(c_N)-xi with a sufficiently large startup.
Exact rank conversion retains every branch. This stronger baseline
prevents interpreting the unknown-input lower rate ln2 as a capacity or
a net generation advantage.

## 5. Explicit pump non-return in the linear-inventory regime

This is a separate cost witness; it does not reuse the old Fock-pump
non-return estimate. Let initial pump number law be Poisson(mu) with
mu=bJ, b=6 for root709264 or b=4 for the new corollary. Let
delta_N bound Pr[ell<N/2] after the supplied amplification, without any
logical code error being charged. The original concentration gives
delta_N->0; the sharpened versions do as well. The receiver leaves the
pump untouched, so its final marginal is already determined here.

Initial P+D total is conserved and D starts vacuum. The commuting final
pump and D number measurement has classical labels k,ell with initial
total L=k+ell. Initial number coherences cannot change their joint
probabilities, because different total-number eigenspaces are orthogonal.
This is a mathematical witness measurement on the pump marginal; it
does not insert a pump-number readout into the receiver.

Set a=N/4 and choose the bounded pump-number event

    A={k>mu-a}.

If ell>=N/2=2a and L<=mu+a, then k=L-ell<=mu-a, so

    P_final(A)<=Pr[L>mu+a]+delta_N,
    P_initial(A)>=1-Pr[L<=mu-a].

Poisson Chernoff bounds give

    d(P_initial,P_final)
      >=1-delta_N
          -exp[-N^2/(32bJ)]
          -exp[-N^2/(32bJ+4N)].                     (F9)

For fixed E, J<= (1+E)N, hence the exponential terms vanish and the
return distance tends to ONE. The number measurement only contracts
trace distance, so F9 applies also to a PURE COHERENT initial pump and
a coherent final pump, not just to diagonal marginals. It also applies
to source-correlated states with the same number profile under the exact
fixed interaction. This rules out approximate catalyst return even if
one were tempted to charge only a small fraction of apparatus entropy.

Mean loss obeys

    E ell >=(N/2)(1-delta_N), E ell<=mu,
    E ell/mu >=(1-delta_N)/[2b(1+E)].                (F10)

Thus depletion is Theta(N) and its fraction of the linear inventory is
bounded away from zero. At a physical bath inverse temperature beta,
omega_P=2omega, the exact ordinary marginal resource drop is

    D(P_initial||gamma)-D(P_final||gamma)
       =beta hbar omega_P E ell
                        +S(P_final)-S(P_initial).

Both entropies are <=g(mu)=O(ln N). Therefore this marginal drop is
Theta(N), and in particular at least
beta hbar omega_P (N/2)(1-delta_N)-g(mu). This is an entropy/energy
identity and cost obstruction, not a deterministic work yield or a
max-relative-entropy subtraction in the presence of correlations.

## 6. Resource and proof comparison after the original audit

W42's b68 resource proof checks: for any pump density with Poisson
number diagonal, gamma_P^-1/2 rho_P gamma_P^-1/2 has finite trace
exp[mu(q^-1-1)]/(1-q), so its norm is bounded by that trace. Its full
active APB weighted-trace bound also correctly includes arbitrary
source-pump correlations, cap m<=M and pure vacuum B, giving

    D_max(active APB ||theta_AB tensor gamma_P)
      <=2Nln(v+1)+Mln(1+1/v)
                           +mu(q^-1-1)-ln(1-q).

This finite positive form is justified by weighted trace-class
convergence, not an unspecified inverse-Gibbs domain. It bounds active
state resource, not old rejected sources, controller/program resource,
physical state formation or an environment purifier's resource.
W42's moment-only heavy-tail counterexample also correctly separates a
Bell-error conclusion from an exact finite D_max certificate. Approximate
number-law or variance data alone must not be used to infer the latter.

W42's post-W30 r_N->ln2 receiver sequence is valid; it keeps E12 in its
original Poisson WS3. F2-F3 above are an additional credited parameter
improvement. This comparison does not audit W42's separate thermal-band
factory in full or any subsequent mean-only backconversion obstruction.

## 7. Independent finite checks and evidence limits

`check_followup.py` imports only my own pre-existing numerical helpers,
not root/W30/W42 code. It checks coupled state-error derivatives on the
actual finite chain for L/J=2,3,4,5,6,8, varying N, cap and source sector,
with the fixed-time relation preserved. It independently computes
||I+B||, y>=s tau^2 and E6 derivative slack, and samples the scalar H
for a diagnostic against the analytic convexity bound. Universal truth
is proved in Sections2-4, not inferred from this grid.

Separate exact finite-amplitude controls use known optical vacuum,
Poisson(6N) populations with explicitly stated finite fixture truncations,
and the same physical time. The actual coherent final pump density is
sum_ell |v_ell><v_ell|, with (v_ell)_k=alpha_(k+ell)z_(N,k+ell),ell.
The diagonal input gives the corresponding number-diagonal output.
The retained data checks both actual return distances, the bounded
number-event witness and the mean-loss lower bound. These are small
mathematical mechanism controls, not an experimental source or formal
floating-point certificate. Exact source tails are bounded separately
by the displayed Poisson Chernoff expressions; no physical truncation is
silently inserted in the new theorem.

Full results and numerical density/amplitude arrays are retained in
`FOLLOWUP_CHECKS.json` and `PUMP_RETURN_FIXTURES.npz`. The main audit's
5,721 controls stay separate from these new diagnostics. Generic
trilinear/SU(1,1), semiclassical error methods and coherent pumps have
established prior; exact priority of these particular evaluated
consequences remains UNKNOWN. No physical, practical, publication or
mission success is inferred.
