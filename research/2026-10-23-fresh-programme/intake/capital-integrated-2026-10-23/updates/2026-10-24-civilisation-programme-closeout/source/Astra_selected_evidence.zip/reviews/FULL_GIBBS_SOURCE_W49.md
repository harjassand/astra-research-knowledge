# Fresh audit of full-score Laplace bounds and Gibbs minimax source

Reviewed exact frozen w56 sources:

- `FULL_SCORE_TRACE_LAPLACE_BOUND.txt`, SHA256
  `5d480844785b96fb3e04c412a99cc36ea169dafdc1bbc65bccdebf28693a2859`;
- `TOTAL_CHARGE_GIBBS_MINIMAX_SOURCE.txt`, SHA256
  `50ce0f24c73ea2eebaa1e7c91245cd5fc5a60dd9f16acc1c12f997734c9dde96`.

Verdict: **NO BLOCKING DEFECT FOUND IN THE FULL FINITE ANALYTIC CRITERIA**.
This audits a new mathematical positive-source mechanism conditional on an
explicit old-H variance witness. It does not claim a stronger numerical rate,
a solved partition minimization, a source compiler, or external acceptance.

## 1. Full-score and exact trace Jensen

Let G=Q-W*QW for the ACTUAL full unitary and bulk depth>=k, D=a(2Q-k),
Z=pin_QG-D. For any analytical bath-color-prefix density zeta, define
`K_zeta=E_zeta Z`. This score retains all even Hamming distances, not just
named pairs. It is Hermitian, Q-preserving and has complete-pattern diagonal0,
so its normalized trace in every total-charge sector is0.

On total charge q, K_q=Phi_q((q-d)I-Q), d=a(2q-k), where Phi_q is the
normal UCP map compressing W* X W to that charge sector and taking the
bath state zeta. Diagonalize K_q. On EACH eigenvector, the composition with
Phi_q is a positive normalized scalar functional. Ordinary scalar spectral
Jensen for any real convex f therefore gives

`tr_q f(K_q)<=tr_q Phi_q[f((q-d)I-Q)]`.

This is a TRACE inequality; operator-exponential Jensen is neither required
nor asserted. The original exact distinct-move-mask diagonal identity applies
to EVERY scalar f(Q), not only first and second moments. Its scalar variable
is X=sum_i s_i(M_i-a), s_i=2x_i-1, with independent Bernoulli(a) M_i.
Hence the exact sectorwise Laplace envelope is

`tr_q exp(tK_q)<=[a exp(tb)+b exp(-ta)]^q [a exp(-tb)+b exp(ta)]^(k-q)`.

This independently matches the equivalent output-charge form
`tr_q exp(-tK_q)<=exp(-t mu_q)(a+b exp(t))^q(b+a exp(t))^(k-q)`,
mu_q=a(k-q)+bq. The signs differ only because one expression uses tK,
the other -tK. Intermediate coherent matrix blocks have not been replaced
by a stochastic channel.

Each centered summand has mean0, magnitude<=1 and variance ab, so
`1<=tr_q exp(tK_q)<=exp[mu B(|t|)]`, mu=kab, B(t)=exp(t)-1-t.
The lower bound follows from trace K_q=0. Averaging fair binary charges
produces `[a cosh(tb)+b cosh(ta)]^k`, at most exp[mu(cosh t-1)]. The exact
charge tilt multiplies each sign probability by1+u s; its extra sinh term
has vanishing linear coefficient and is bounded by
`exp{mu[cosh t-1+|u|(sinh|t|-|t|)]}`. I checked all coefficients and signs.

For convex x^2 and x^4, the same trace Jensen gives uniformly in q,zeta

`tr_q K_q^2<=mu`, `tr_q K_q^4<=mu+3k(k-2)(ab)^2<=mu+3mu^2`.

The centered independent-sum fourth moment is
k ab(1-3ab)+3k(k-1)(ab)^2, independent of the signs. Thus ANY total-charge
reweighting retains the fourth bound. No operator fourth-moment or
pair-Schur-projection contraction is silently inferred.

## 2. Convex variational drift

Prescribe the tilted binomial charge distribution p_q(delta), mean k/2+delta.
For gamma>0 set z_q=tr_q exp(-gamma K_q) and
`Phi_delta(zeta)=sum_q p_q(delta) ln z_q`.
The density with sector blocks
`rho_q=p_q exp(-gamma K_q)/(d_q z_q)` is strictly positive and normalized,
with exact charge shift delta. Scalar TOTAL-charge normalization suffices;
there is no claim that its complete-pattern blocks equal sigma T.

Log trace exponential is convex in the linear Hermitian score K_zeta. Its
Kubo-Mori Hessian is nonnegative termwise in the spectral basis of rho_q.
Thus minimizing Phi over the compact convex finite density set gives a
nonempty compact convex set of minimizers. Differentiation under the trace
is justified in finite dimensions and uses cyclicity, not commutation of a
perturbation with K. At a minimizer zeta*, set R=-Tr rho K_zeta*. Then

`dPhi(eta-zeta*)=-gamma Tr[(eta-zeta*)D_b(rho)]>=0`.

The scalar diagonal term2a delta cancels in the trace-zero direction.
Testing every eta yields the FULL bulk operator drift
`D_b(rho)<=(2a delta-R)I`. Also R=partial_gamma Phi>=Phi/gamma>=0.
No pair-score minimizer/KKT conjecture or bath preparation in zeta* is used.

## 3. Entropy, uniform floor and balance

Within charge q, the Gibbs relative entropy to I/d_q is gamma R_q-ln z_q.
The reference sigma has sector weight binom(k,q)/2^k and scalar density
2^(-k-q). Therefore the exact BIT entropy excess is

`S(rho)-3k/2=delta-D_tilt(delta)-(gamma R-Phi)/ln2`.

Choosing gamma=ln2/(2a), delta=(R-eta)/(2a), gives strict drift -eta and
entropy excess Phi/ln2-eta/(2a)-D_tilt. All factors of ln2 are consistent.

The supplied variance premise is w_zeta=Tr sigma K_zeta^2>=v0>0 for ALL
zeta. The old-H witness implies it by weighted Cauchy-Schwarz; this remains
a separately supplied interface with its actual constants. It requires no
positive arbitrary-mask Gram overlaps. A causal shorter prefix can provide
a positive limiting floor at any fixed r, without claiming growth like r^2.

Put mu=kab, M4=mu+3mu^2, M=rB(2gamma)/(2gamma). The conditions M<k/2 and

`vtilde=v0-sqrt(M4)sqrt(exp(4M^2/k)-1)>0`

correctly lower bound every tilted variance at delta in[0,M]. Indeed
||T_delta-I||2^2=(1+4delta^2/k^2)^k-1<=exp(4M^2/k)-1,
and weighted Cauchy-Schwarz uses the uniform fourth moment. The tilted
fourth remains<=M4 by sectorwise uniformity.

Choose s=min(gamma,(3/2)sqrt(vtilde/M4)). The global scalar cubic Taylor
minorant for exp(-sx) has nonnegative fourth remainder for ALL real x.
Cauchy-Schwarz bounds the cubic trace by sqrt(v_delta M4), so
E_tilt[z_q(s)-1]>=s^2 vtilde/4. Because1<=z_q<=exp[mu B(s)],
log z_q>=(z_q-1)exp[-mu B(s)]. Monotonicity in positive gamma then gives

`Phi_delta(zeta,gamma)>=h=exp[-mu B(s)]s^2 vtilde/4>0`.

The derivative bound R<=(Phi(2gamma)-Phi(gamma))/gamma<=mu B(2gamma)/gamma
is at most2aM. All these inequalities hold before choosing a minimizer.

At delta each minimizer set is compact convex, hence connected. The
continuous R-image is a compact interval; compactness and the minimizing
subsequence argument give upper hemicontinuity in delta. For
eta=h/(2gamma), the image F(delta)={(R-eta)/(2a)} lies in[0,M]. The source's
one-dimensional interval fixed-point argument is valid: absent a fixed
point, upper hemicontinuity would partition[0,M] into disjoint relatively
open above/below sets, each nonempty at an endpoint. No continuous optimizer
branch or unjustified derivative of the minimized value is used.

At that balance, entropy excess is at least h/(2ln2)-D_tilt. The exact tilt
bound is at most2M^2/[k ln2(1-4M^2/k^2)]. The condition
8M^2/[k(1-4M^2/k^2)]<=h then gives entropy excess>=h/(4ln2) and strict
drift margin h/(2gamma). Constants and directions are consistent.

## 4. Check of the inherited coding interface

I reopened the pinned Cycle11 carried `dependencies/cycle10/COMPLETE_PROOF.tex.txt`,
Theorem 'Uniform operator drift gives actual reliable codes', equation(C3).
It requires only a fixed charge-preserving density and uniform strict inward
bulk drift. It DOES NOT require complete-pattern scalar blocks or the old
sigma T F representation. The Gibbs source meets these hypotheses whenever
the explicit finite criteria and old-H variance premise hold. The resulting
rank is exactly3^k; k,b,rho and its margin are fixed BEFORE the outer code
horizon. The original pointwise fixed-normal initializer order and its
full-reference/joint-compression costs remain. They are not upgraded to a
free horizon-dependent initializer by this construction.

The supplied h is crude and is not compared favorably to the reviewed V4
rate without a complete scalar comparison. No certified optimizer, finite
precision source, efficient Gibbs factory or finite-horizon logical code was
acquired. Analytic matrix dimensions include3^k input and2^k prefix density.
This audit establishes internal reconstruction of the finite sufficient
criteria, not field-wide novelty, external correctness or physical advantage.
