# The next experiment resolves two central interfaces, before a network

No physical operation, purchases, equipment access or outreach has been performed or authorized. This is an assay proposal with immediately runnable offline analysis. Header-only input files deliberately contain no observations. The next science is targeted at the missing response, rather than another synthetic optimization demonstration.

## A. Electrical square qualification with a matched ordinary controller

Build no lattice initially. On one qualified strain-voltage source or already calibrated coupon, compare: (1) the weighted symmetric gate; (2) ordinary ADC + integer square + the same post-average deadband; (3) an AD633 square only if its full-scale/rail cost is being evaluated. Give both controllers identical source samples, force holds, zero taring, references, timing and eventual output driver. Include ordinary power gating and harvester-triggered wake when applicable.

The proposed bounded domain is normalized `x∈[-1,1]`, `R=1.1`; the first finite grid has both signs, zero, intermediate points and points on both sides of the robust threshold. Deliberately vary static offsets, initial comparator state, ascending/descending order, common mode, polarity ordering, zero-cycle age, temperature and slow drift. The useful hard test is that static-offset/hysteresis cancellation survives while deliberately nonstationary offsets fail according to the derived residual bound. A high R² on one positive-strain ramp is irrelevant.

For every trial retain reference voltage/strain intervals, native and digital outputs, raw source-file provenance, all phase timestamps, capacitor start/end voltages, reset/zero durations, source/ramp current, wall energy and temperature. Verify that no intermediate integrator state saturates. Measure threshold/weight/dwell nonlinearity separately; a shared DAC does not make them exact. Qualification also includes source motion during the complete eight-sweep frame. The `1 ms` dwell and `8.192 s` frame are starting hypotheses only.

For a uniform certificate, finite grid success alone is insufficient. Combine the grid's interval errors with independently justified derivative/range bounds between points and the acquired context ranges, or use the analytic component-wise bounds of `WEIGHTED_GATE.md`. Never infer a worst-case dynamic error merely from the largest sampled residual. The offline analyzer reports a finite observed envelope and explicitly withholds a continuum certificate.

**Electrical falsifier:** within the declared domain, any reference-enclosed error above the selected budget, unsaturated-start dependency, residual common-mode/polarity offset exceeding the assigned allowance, or unbounded frame drift rejects the proposed gate at that rate. A successful slower setting is a different charged design. **Advantage falsifier:** the same-information ADC design meets the same output/error requirement with no larger complete energy/time/preparation/reset cost. This does not erase feasibility; it rejects an exclusive performance claim.

## B. Continuous axial Cu/steel coupon with two isolated fluid cells

Use an uninterrupted steel core with symmetric continuous plating over a known active length and anchored ends. Start with two members sharing a metallic return and separately sealed ionic compartments. Use the source-backed Cu/steel chemistry as a starting recipe, not a certified transferable setting. References, stirring, insulation, electrode prep, cleaning and potential limits are recorded. No topology-gap closing/welding is used as a substitute for continuous cross-section control.

At each state: (i) rest and independently measure zero-force length; (ii) measure small reversible tension/compression stiffness through repeated loading/unloading; (iii) teach the selected force ensemble and store its square; (iv) fully unload; (v) apply a conservative signed dose; (vi) zero/rest and repeat. Include matched blank/zero-current periods and reverse-dose cycles. Observe local strain independently, actual current/potential, deposited mass/thickness distribution and stiffness. Record adjacent compartment current and mass to test ionic leakage/common-metal cross-talk.

The critical output is `k(q)`, its incremental slope, hysteresis, residual strain and relaxation, and the signed change at zero/deposit/etch commands. Faraday mass alone does not establish it. Fit candidate affine/concave response on one preparation, then test a separate preparation/etch return; retain deviations as physical observations. A model fit is not a universal calibration. At 50 mm gauge length and 1000 microstrain full scale, the illustrative 0.2% strain-encoding target means a 0.1-micrometre full uncertainty in extension; at 10 mm it means 20 nm. This is a real reference and fixture precision requirement. The admissible strain range must be shown elastic after each material update.

**Material falsifiers:** wrong-sign stiffness changes; substantial zero-command corrosion, creep, spalling or stress relaxation; a nonreproducible/hysteretic `k(q)`; an incremental slope varying beyond the mechanical-model allowance; reference-state shifts invalidating the squared-strain derivative; finite steps exceeding their safe bound; or ionic cross-talk above its assigned budget. A nonaffine response may prompt the explicit state-dependent derivative in `MATERIAL_INTERFACE.md`; it cannot retain the original constant-threshold global-optimum claim.

## C. Energy-square alternative only if it removes a measured burden

If bridge power/preparation dominates, test a bonded piezo with a zero-reset/known-strain extraction cycle. Measure extracted energy at both signs, zero, rates and buffer states, as well as extraction-induced strain motion. Include cold start, discharge, force reversal and capacitor leakage. A 40 V piezo scenario requires a separately qualified high-voltage interface; the cited 10 V-device ASIC is not automatically compatible. The ordinary controller gets the identical piezo and harvester, may wake only when its energy-ready output asserts, and may use the same energy bucket. Testing against an always-powered bridge alone would not decide advantage.

**Work-coupler falsifier:** no useful uniform affine-in-mean-square energy response after reset/efficiency errors and mechanical back-action are included; or insufficient extracted energy/rate after control and chemical losses. A useful harvester with an ordinary controller still counts as an attainable engineering result, without a native-computation advantage.

## D. Integrated two-load test only after A and B pass

Teach at least two distinct known force states with known weights, explicitly including an intermittent large-strain mixture that differentiates `E epsilon²` from an exponential or RMS-before-square surrogate. The current geometry is held fixed during observation and updated by the finite-step rule. The ordinary controller receives identical observations. Compare final compliance/volume, full wall energy, total teaching/update time, preparation labor, reset losses, repeatability and reusable-fixture life. Both must achieve the same functional output and scope.

The theorem applies to any fixed acquired bounded distribution; it does not infer an unknown service distribution from a short controlled teaching set. The 0.0005 averaging target would require about 29 million independent samples/update in the retained unknown-iid concentration example. Use known controlled weights for this manufacturing assay and state that restricted objective.

## Offline command and honest output

Run from this directory:

```sh
/opt/homebrew/bin/python3 qualification_analysis.py
/opt/homebrew/bin/python3 additional_calculations.py
/opt/homebrew/bin/python3 weighted_gate.py
```

`qualification_analysis.py` consumes `gate_observations.csv` and `whole_cost_observations.csv`. With the retained header-only files it returns `NOT_ACQUIRED`; it does not create observations. For real future data it calculates a finite interval error envelope and matched complete-row cost arithmetic. It never promotes a finite grid to a uniform physical certificate or a declared provenance string to verified experiment status.
