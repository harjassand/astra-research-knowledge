"""Freeze W39's final cold smooth-envelope review without source edits."""
from pathlib import Path
import hashlib
import json

HERE=Path(__file__).resolve().parent
SPACE=HERE.parents[3]
TARGET=SPACE/'work/workers/w38_fresh_inventory_critic/new_independent_epni_invention'


def bind(p):
    b=p.read_bytes()
    return {'path':str(p.relative_to(SPACE)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}


expected={
    'SMOOTH_INTEGRABLE_LOG_ENVELOPE_HEAT_BRIDGE.md':'cbd968c585a332e49547f9a74b3b1e014ce2b3d36f695dfb7c46c8b327646399',
    'SMOOTH_LOG_ENVELOPE_GROWING_SHIFT_DETAIL.md':'2c08cb95c0655d623563bf7c21c32fd50897fb3f2130e9ba4ee1c7454e1c4870',
    'LOG_TAIL_FIXED_SHIFT_CLARIFICATION.md':'a4bf33438a397e21d7858e24a120488cd0bd5fa31a4acb84b4f45543c5a8af5a',
    'FINITE_ENERGY_LOG_TAIL_ENTROPY_BRIDGE.md':'2167da8029a740a937b5ae477a1bf984fd34d4f9b6c02ce001ee02c8bc191e6e'}
dep_names=list(expected)+[
    'REGULAR_VARIATION_THERMAL_MIXTURE_ENTROPY_BRIDGE.md',
    'HEAT_RESOURCE_SCOPE_ADDENDUM.md',
    'LOG_ENVELOPE_ACQUISITION_AND_NONUNIFORMITY.md',
    'COHERENT_BRIDGE_PRIMARY_AND_QEPI_BOUNDARY.md']
deps=[]
for name in dep_names:
    row=bind(TARGET/name)
    if name in expected:assert row['sha256']==expected[name],name
    deps.append(row)
raw=json.loads((HERE/'COLD_SMOOTH_ENVELOPE_RESULTS.json').read_text())
for n,h in raw['source_hashes'].items():assert h==expected[n]
assert raw['checker_sha256']==bind(HERE/'check_cold_smooth_envelope.py')['sha256']
dependencies={'scope':'Exact targets, mandatory corrections and producer mathematical prerequisites read, not inherited review verdicts. No producer diagnostics or W49 narrower review imported.',
    'files':deps,'primary_sources_reopened':[
        {'url':'https://arxiv.org/pdf/1402.0404','version_read':'v2',
         'role':'Amplifier Bogoliubov relation Eq6 and distinct established qEPI; not proof of the exact entropy-photon target.'},
        {'url':'https://arxiv.org/pdf/1408.6410','version_read':'v2',
         'role':'Established multimode qEPI context; no general EPnI conclusion inherited.'}]}
(HERE/'DEPENDENCIES.json').write_text(json.dumps(dependencies,indent=2)+'\n')

result={
    'worker':'w39_fresh_computation_invention','date':'2026-10-24',
    'status':'POSITIVE_COLD_INTERNAL_FULL_PROOF_RECONSTRUCTION_FOR_ACTUAL_HEATED_SMOOTH_ENVELOPE_CLASS',
    'target_sha256':expected['SMOOTH_INTEGRABLE_LOG_ENVELOPE_HEAT_BRIDGE.md'],
    'mandatory_growing_shift_detail_sha256':expected['SMOOTH_LOG_ENVELOPE_GROWING_SHIFT_DETAIL.md'],
    'fixed_shift_clarification_sha256':expected['LOG_TAIL_FIXED_SHIFT_CLARIFICATION.md'],
    'cold_provenance':'Exact candidate, mandatory/fixed-shift details, underlying producer proofs/resource premises and primary method context read before own derivation/controls. No producer diagnostics/code/output, W49 narrower review, peer verdict or root preferred derivation read/imported/run.',
    'source_premises':'One-mode unflagged rho_R=E theta_R; bounded arbitrary body and eventual density r^-2[ell(ln r)+E(ln r)]. Positive C2 integrable nonincreasing ell with explicit first/second derivative bounds and |E(x)|<=K ell(x)/x^2; E only measurable. Independent source laws fixed before heat and fixed G>1.',
    'actual_quantum_defect':'D(H_T rho_R||theta_(T+ER))=[M(ln T)-ell(ln T)(lnln T+gamma_E)]/T+o(ell(ln T)/T), M(x)=integral_x^infinity ell.',
    'actual_independent_two_port_gap':'[-theta ell_A(ln T)ln theta-phi ell_B(ln T)ln phi]/T+o((ell_A(ln T)+ell_B(ln T))/T)>0 eventually at each fixed pair/G, theta=G/(2G-1),phi=(G-1)/(2G-1).',
    'critical_chain_reconstructed':['Uniform derivative-based positive/negative O(log l) shifts, including medium cutoff T/l^2.',
        'Finite global classical KL and local-only quadratic estimate retaining full mean tail/polynomial denominator.',
        'Three-range direct remote heat removal without inverse heat or high moments.',
        'Mellin derivative sign and uniform merely measurable error; all remote mass/first-moment/log contributions.',
        'Actual photon geometric mixture and explicit radial Poisson/Gamma preparation/heterodyne squeeze.',
        'One-unit heat difference o(ell/T), finite actual entropy and matching thermal identity.',
        'Independent convolution/scaling/fixed-added-temperature closure at O(ell/x^2), no false rough-error O(1/r) modulus.',
        'Actual amplifier creation-port constant and unflagged output mixture.',
        'Bounded entropy-target Hessian and componentwise M/log/Euler cancellations with no envelope-ratio limit.',
        'Nearcritical examples, all finite-heat thermal chi2 divergence, source-first/nonuniform acquisition boundaries.'],
    'nearcritical_scope':'ell_q(x)=1/[x(ln x)^q],q>1; exact mean1/(q-1), no photon moment above1, beyond every common power p>1. No arbitrary irregular finite-energy or unbounded-atomic tail extension.',
    'uniformity':'Eventual source-first theorem, not source/G-uniform threshold. Epsilon-tail contamination gives no uniform relative-asymptotic threshold even under common energy,K,r0; finite-copy trace-distance bound prevents uniform tail certification without coefficient lower bound. This is not a negative EPnI gap or proof that another uniform EPnI theorem is impossible.',
    'exact_controls':raw['exact'],
    'numerical_controls':{'status':'NUMERICAL_NOT_INTERVAL_CERTIFIED_NOT_PHYSICAL_DATA',
        'mellin_cases':len(raw['mellin_growing_shift']['mellin_cases']),
        'growing_and_negative_shifts':len(raw['mellin_growing_shift']['growing_and_negative_shift_cases']),
        'discontinuous_density_error_cases':len(raw['mellin_growing_shift']['measurable_error_cases']),
        'two_source_cancellation_cases':len(raw['two_source_cancellation']['unequal_and_nonconvergent_ratio_pair_cases']),
        'actual_independent_sum_fixed_shift_density_cases':len(raw['actual_output_convolution']),
        'actual_quantum_photon_entropy_cases':len(raw['actual_quantum_squeeze']['rows']),
        'actual_quantum_quadrature_refinement':raw['actual_quantum_squeeze']['max_order_refinement'],
        'method':'Actual geometric-mixture photon entropy through8192 plus analytic monotone-tail formulas; separately calculated classical t/t+1 squeeze. Quadrature bias not interval certified. Asymptotic cancellation controls are not finite actual two-port gap certificates.'},
    'negative_controls':['Wrong Mellin derivative sign detected at second-order scale.',
        'Allowed oscillating log-squared density error violates a claimed O(1/r) shift modulus.'],
    'cost_and_acquisition':'Actual heat adds T photons to each input; amplifier/pump/source/tail/mean/independence/precision/entropy/reset costs unacquired. Analytic temperatures/coherent labels are not free records. No useful finite T or measured source certificate.',
    'entanglement_scope':'H1 is heterodyne/prepare, so H_T is entanglement breaking for T>=1. These one-mode sources are already classical thermal mixtures; no surviving native entanglement advantage established.',
    'not_established':['General independent-input unheated finite-energy amplifier EPnI.',
        'Arbitrary irregular finite-energy states or atomic unbounded tails.',
        'Source-uniform relative expansion or useful heat threshold.',
        'Acquired apparatus/source data, quantum entropy measurement or practical advantage.',
        'Generic method novelty, exact class-specific priority or best matched prior.'],
    'evidence':{'report':bind(HERE/'REPORT.md'),'reconstruction':bind(HERE/'INDEPENDENT_RECONSTRUCTION.md'),
        'pre_diagnostic_proof':bind(HERE/'COLD_PRE_DIAGNOSTIC_RECONSTRUCTION.md'),
        'checker':bind(HERE/'check_cold_smooth_envelope.py'),'raw':bind(HERE/'COLD_SMOOTH_ENVELOPE_RESULTS.json'),
        'dependencies':bind(HERE/'DEPENDENCIES.json')},
    'blocking_mathematical_issue_found':False,
    'proof_validity_scope':'Internal independent full reconstruction; not formal verification, external acceptance or priority adjudication.',
    'source_method_priority':'UNKNOWN','physical_validation':'NOT_PERFORMED','practical_advantage':'UNKNOWN',
    'general_unheated_EPnI':'NOT_ACHIEVED','mission':'NOT_ACHIEVED',
    'critical_open_boundary':'Supplied structural/tail/independence premises and changed-input high-heat scope; external proof/priority and physical acquisition/useful resources remain open.',
    'continuation':'Final drain: freeze packet and worker continuation; return idle. No new branch, reactivation or assignment.',
    'previous_compact_finite_port_quantum_packet_bytes_preserved':True,'manifest':'MANIFEST.json'}
(HERE/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
names=['REPORT.md','INDEPENDENT_RECONSTRUCTION.md','COLD_PRE_DIAGNOSTIC_RECONSTRUCTION.md',
       'RESULT.json','DEPENDENCIES.json','check_cold_smooth_envelope.py','COLD_SMOOTH_ENVELOPE_RESULTS.json',Path(__file__).name]
manifest={'scope':'Frozen W39 final cold smooth-envelope review. Excludes itself. Producer targets/prerequisites were read and bound, never edited.',
          'files':[bind(HERE/n) for n in names],'source_files':deps}
(HERE/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
for n in names+['MANIFEST.json']:
    row=bind(HERE/n);print(row['sha256'],row['bytes'],n)

