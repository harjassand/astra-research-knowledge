# A physical rank-one counterexample to the proposed pointwise constant

24 October 2026, W18 independent construction. **INTERNAL EXACT
COUNTEREXAMPLE to the particular pointwise constants r h_L and
r c(1/D).** It is not a counterexample to an outcome-averaged bound,
an unrestricted capacity converse, the reviewed global-clock currency,
or the possibility Delta=H+O_D(1). Historical priority UNKNOWN; no
physical implementation or efficiency has been acquired.

## Actual source and admissible effect

Use the pinned original source, no extra clock or aid: D=32, L=2,
uniform K in {1,2}, three iid COMPLETE queues. The always-live first
site of each queue is retained, including its inaccessible original
clock and the independent old memory. At each laboratory define
normalized vectors that factor as |000> on those three known sites
times, on the three uncertain sites,

    u=(|000>+|111>)/sqrt2,
    v=(|000>-|111>)/sqrt2.

The vectors |0>,|1> are ordinary native levels in C^D. The terminal
effect E=|u_total><u_total|_A tensor
|conjugate(v_total)><conjugate(v_total)|_B is rank-one SEP and occurs
in an elementary zero-aid LOCC measurement: both laboratories measure
their corresponding rank-one projector and its complement, retaining
all four joint outcomes. The known-site factors are part of the local
vectors; they are not removed from arbitrary terminal vectors.

For core choices j_i=K_i-1 in {0,1}, let s=sum j_i. Direct partial
trace of these two GHZ vectors gives

    f_empty=1,
    f_I=1/2 for every nonempty proper subset I,
    f_all=|<u|v>|^2=0.

Thus, after factoring the actual common likelihood D^3, the eight
core likelihoods are 1 at s=0, D/2 at each of three s=1 entries,
D^2/2 at each of three s=2 entries, and 0 at s=3. Put

    Z=1+3D/2+3D^2/2,
    M=3D/2+3D^2,
    F=log Z-(M/Z)log D.                              (1)

In the ACTUAL native source the likelihoods are D^3 times these
entries, the actual energy is (3+s)logD, and the two common terms
cancel from F. Consequently (1) is exactly the original-source
pointwise remainder, with all known prefixes included.

## Exact strict comparison, without floating logarithms

For D=32, Z=1585 and M=3120, so

    F=log(1585/1024)+(50/1585)log32.

For x>=1, log x>=2(x-1)/(x+1). Also log32>3, since e<3 and
e^3<27<32. Consequently

    F > 1122/2609+150/1585 >9/20.                    (2)

The last strict rational comparison is exact. On the other side,
log2<7/10: the first five positive terms of exp(7/10) already sum
to more than2. Therefore log32<7/2, and using log(1+x)<x,

    3c(1/32)=3log(32/31)+(3/31)log32
             <3(1+7/2)/31=27/62<9/20.              (3)

Equations (2)--(3) prove F>3c(1/32). Since h_2(D), the entropy of
weights (1,D), is less than c(1/D), the stronger r h_L proposal also
fails. The numerical values retained by the checker are illustrative;
the rational inequalities above certify the sign. The positive
second term in (2) is essential to this short certificate.

## PPT relaxation and a weaker abstract shadow control

A different exact PPT state already violates the same constant at
D=16. On each native pair put P0=Phi_D and P1=(I-Phi_D)/(D^2-1).
Let tau have isotropic-sector probabilities

    z000=0,
    z001=z010=z100=1/[D(D+2)],
    z011=z101=z110=0,
    z111=1-3/[D(D+2)].

These are normalized and nonnegative. Partial transpose has integer
one-site kernel [[D+1,1],[-(D-1),1]], up to positive row factors.
Its tensor cube times z has values 4,4/(D+2),0,4(D-1)/(D+2)
on rows with zero,one,two,three minus labels, respectively, so it
is entrywise nonnegative for every D>=2. The
resulting overlaps are f_i=2/(D+2), f_ij=D/(D+2), f_123=0. At D=16
this gives Z=689,M=4112/3 and

    F=log(689/256)+(22/2067)log16
      >866/945>4/5>3c(1/16).

The last comparison follows log2<3/4, log16<3, and
c(1/16)<(1+log16)/15. This is a genuine positive/PPT effect control;
no claim that this particular state is SEP is needed because the
separate GHZ effect above IS SEP. The bare positive-shadow model
f_even=1,f_odd=0 is an even looser countermodel and violates physical
sector inclusion. None supplies a capacity receiver.

## Completeness and the remaining frontier

An unusually large remainder of one outcome does not lower-bound
the outcome average. For the four-outcome local completion above,
write d=D^6 for the actual local data dimension. Its all-white law
is q11=1/d^2, q10=q01=(d-1)/d^2, q00=(d-1)^2/d^2. The actual mixture
has p11=D^3 Z/(8d^2), p10=p01=1/d-p11 and
p00=1-2/d+p11, since both local marginals are maximally mixed.
The effect is rare: q11=D^-12 and p11 is of order D^-7. The other
outcomes must be charged. The completed measurement does not violate
the proposed averaged bound in the retained controls. It is terminal
and destructive, with no Bell-rate or residual-output conclusion.

For fixed three queues and D growing, (1) tends to log(3/2)>0
whereas 3c(1/D) tends to0. Independent tensor groups propagate the
pointwise obstruction linearly in the number of groups. This only
forces a larger D-dependent per-queue pointwise constant. In
particular it gives no unbounded-in-L remainder at fixed D and no
obstruction to Delta=H+O_D(1). A proof using POVM completeness or a
more permissive constant remains possible. The reviewed 79062b...
global-clock/merging target theorem concerns a different retained
output architecture and remains unchanged.
