# A value-dependent nineteen-leaf construction on an open two-output chamber

23 October2026. This is a conditional all-values mathematical construction,
plus a rigorous nonempty twelve-dimensional box. It does not establish a
chamber cover of all nodal space. The earlier six-output finite-order
obstruction does not transfer to two outputs.

## Actual physical law

Use the fixed N9 geometry and thirteen numbered physical faces in
`../allsize/escape/certificate.json`. The outer vertices are0,1,2 and the
interior vertices are3,...,8. For arbitrary residual values u_i in R^2 at
the six interior vertices, set the outer residual values to zero and
interpolate continuously and affinely. Write A_i for the two-by-two
gradient on physical face i. Physical normalized masses are

```
w=(1/5,1/5,3/25,1/5,1/25,1/25,1/25,1/25,
   1/50,1/50,1/25,1/50,1/50).
```

Every adjacent physical face pair is rank-one connected, independently of
nodal values. Boundary integration gives mean zero and
sum_i w_i det(A_i)=0. These identities hold for all twelve interior nodal
scalars. The claim below concerns this full actual physical law, with all
thirteen masses recovered, not a quotient at the same mean.

## The exact root-peeling step

Consider any current positive atomic measure with total mass W, mean M,
and determinant balance

```
sum_i w_i det(A_i)=W det(M).
```

Let f_i=det(A_i-M). Suppose A_i-A_j has rank at most one and f_i*f_j<0.
Along a rank-one segment determinant is affine, so the probability weights

```
q_i=-f_j/(f_i-f_j),   q_j=f_i/(f_i-f_j)
```

are positive, sum to one, and give a packet mean Q=q_i*A_i+q_j*A_j
with det(Q-M)=0. Choose any packet mass t>0 not exceeding either available
capacity w_i/q_i,w_j/q_j, with t<W. Remove those packet masses and call
the residual mean R. Then

```
Q-R = W/(W-t) * (Q-M).
```

Thus Q and R are rank-one connected. The packet's two atoms are also
rank-one connected. Their inner and outer binary splits are legal with
positive actual masses. Determinant affinity on those two splits implies
that the residual law still has determinant balance at R.

For a maximal peel exhausting i first, the condition and update simplify:

```
f_i*f_j<0,
w_j + w_i*f_i/f_j > 0,
removed masses:  w_i at i,  -w_i*f_i/f_j at j,
new weights:    w_i'=0,    w_j'=w_j+w_i*f_i/f_j.
```

All other weights stay fixed. This is a rational operation on the nodal
data wherever its displayed strict conditions hold. A whole atom may also
be peeled whenever det(A_i-M)=0. A failed choice or failed finite search
does not establish nonlamination.

For intuition, if D_ij=det(A_i-A_j), determinant balance also gives
f_i=(D w)_i/W. Maximal peeling stays on the quadratic cone w^T D w=0.
The graph of zero D_ij records potential pair packets; graph connectivity
alone does not guarantee successful termination.

## Two universal initial packets

First peel the whole physical atom0, of mass1/5. It has rank at most one
because its face014 has zero values at both outer vertices0,1. The
remaining mass is4/5 and its mean is M=-A_0/4.

Next peel the full physical two-face packet(1,2), of mass8/25, with its
actual masses1/5 and3/25. Let Q12 be its mean. Direct boundary/gradient
algebra gives

```
Q12-M=(2u3+u4) outer (1/8,1/16).
```

The two packet gradients are rank-one connected on their physical common
edge0-3. The displayed identity is universal, even for arbitrary finite
output dimension, and independently checked using all six scalar hats.
The residual now has support3,...,12, mass12/25, and mean

```
M2= -u3 outer (1/6,1/12) -u4 outer (1/12,1/6).
```

All ten residual weights still equal their original physical weights.
Determinant balance is preserved. No condition has yet been imposed on
any of the six interior two-output values.

## A fixed strict chamber

From that residual, perform six maximal pair peels in order, exhausting
the first listed endpoint each time:

```
(3,7),(4,10),(8,10),(5,11),(6,9),(7,12).
```

Each pair is physically adjacent, so its atoms are universally rank-one
connected. At each stage require the two strict conditions in the preceding
root-peeling lemma, evaluated on the current rational weights and mean.
These finitely many conditions define an open semialgebraic subset of
the twelve-dimensional nodal space; denominators are nonzero there.

At the seed

```
u3=(2,-1),u4=(-1,-2),u5=(2,-2),
u6=(5,-2),u7=(2,0),u8=(4,0),
```

all six conditions are strict. Exact values include:

|Exhaust i,partner j|f_i|f_j|New partner mass|
|---|---|---|---|
|3,7|17/48|-97/48|12/2425|
|4,10|-5/264|71/198|269/7100|
|8,10|-106429/139693|60492/139693|23/8520|
|5,11|-3780781/2440444|67308/19681|78463/41730960|
|6,9|-261092281/3624014594|694688576/1812007297|86719259/6946885760|
|7,12|10749131940146345/147671683031001494|-30839113270664920/73835841515500747|3042198324979/158964501395180|

No equalities between independent nodal vectors are imposed. For an explicit
subset of this chamber, allow every one of the twelve seed coordinates to
vary independently in the closed interval of radius2^-20. The exact outward
interval replay proves all six opposite-sign conditions and positive
remaining masses throughout this entire box. It uses Fraction operations
and outward rounding to dyadic120-bit endpoints; every rounding encloses
the exact real operation. Thus this is an all-values box proof, not a
finite sample of perturbations. The box has nonempty interior in R^12.

## Terminal construction and the leaf count

Only physical atoms9,10,11,12 remain. Split them into complete pairs(9,12)
and(10,11), each of which is physically rank-one connected. Let their
means be B,C and their positive relative masses be s,1-s. Their internal
pair laws preserve determinant. The residual determinant balance then gives

```
s det(B)+(1-s)det(C)-det(sB+(1-s)C)
                 =s(1-s)det(B-C)=0.
```

Because s is strictly between zero and one, det(B-C)=0. Therefore the
last split is rank-one, with no accidental nodal equality needed.

Read all previous peels as root splits whose right child is the remaining
law, and graft this terminal two-pair tree at the end. There are one leaf
from face0, two from packet(1,2), twelve from the six middle packets and
four terminal leaves: nineteen leaves and eighteen binary splits. Every
physical atom's masses add exactly to its original area mass. Only original
physical gradients appear as terminal atoms; there are no auxiliary terminal
atoms and no limiting passage in this construction.

The formula applies to every nodal assignment satisfying the strict chamber
conditions, including the entire explicit box. It allows arbitrary affine
outer trace by translating all gradients. Common invertible affine domain
images and common invertible output transformations preserve the certificate
(the determinant values acquire only a common nonzero factor and all ratios
are unchanged). Arbitrary new physical geometries are not asserted.

## Toward a finite cover, without claiming one

The two universal packets leave ten atoms and thirteen physical rank-one
edges. Any subsequent maximal one/two-atom peel reduces support by at least
one. If all choices eventually succeed, the resulting tree has at most
twenty-two leaves: three initial leaves plus at most nineteen residual
leaves. A sufficient terminal condition is a support of at most four atoms
partitioned into two singleton/rank-one-pair groups; the same determinant
balance argument supplies the last merge.

For generic det(u3,u4) nonzero, an invertible common output transformation
normalizes u3,u4 to a fixed basis, reducing a chamber-cover problem to eight
real variables. A finite uniform-leaf-bound cover of a dense open subset
would extend to all boundary data by compactness: pass to a common tree
shape with at most22leaves, take convergent nonnegative physical atom weights,
and prune zero-mass subtrees. Internal means with surviving positive mass
converge, and rank at most one is closed. This is a valid conditional way
to handle denominators and equality boundaries; no dense-open cover has
been proved.

The500unrestricted exact stress cases all succeeded, with17--22leaves and
no budget exhaustion; they are finite diagnostics only. They do not prove
that either the restricted method or any finite/limiting construction works
for every nodal assignment. Many successful residual paths disconnect their
rank-one graph, so connectivity preservation is not a necessary invariant.
Even high graph connectivity with determinant balance is insufficient in
general, as the retained strict quotient/row-product countermodel shows.
The actual-gradient and trace relations are load-bearing.

This packet proves an open full-dimensional family, not all N9 data, all
width-five meshes, or Morrey. Historical novelty and external acceptance
remain UNKNOWN. All inputs are constructed exact mathematical fields.
