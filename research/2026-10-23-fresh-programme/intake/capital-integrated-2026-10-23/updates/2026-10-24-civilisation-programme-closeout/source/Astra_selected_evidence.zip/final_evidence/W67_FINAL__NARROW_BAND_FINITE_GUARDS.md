# Selected finite guards for a supplied narrow interval

W67, 24 October 2026. New unreviewed delta to the frozen known-parameter
rows. No earlier proof, producer, data or review is changed. The interval
is a supplied public promise, not a result of parameter acquisition.

This binds NARROW_BAND_SOURCE_ROBUSTNESS.md (d5e04956) to a separate exact
integer/Fraction producer. The source and its table are functions only
of the rational reference b0. At k=floor(1/(5b0)), the actual unknown
angle obeys

    |theta-arcsin(sqrt(b0))| <= 1/(2304000 k^2).

The reference half-regularized V4 source has drift margin 1/288000.
The full k-call displacement telescope loses at most one quarter of
that value; the NEW finite policy uses the weaker uniform margin

    Kappa_u=1/576000.

All references to Kappa in G1--G10 and the derived moment/precision
policy use Kappa_u, while source entropy G=1/18600 and weighted chi-square
c=1/25600 remain unchanged. Source/operator/log access still targets the
reference model. It does not query the actual device at chosen angles.

For n_body=kst let R=2^B_R >=16 n_body, and keep the old policy

    Bq=48+4B_R+4 ceil(log2(1/z)), q=2^-Bq.

The analysis-only continuum grid has mesh q/(16R) and cardinality at most

    2^B_grid, B_grid=Bq+B_R+5.

With t_L=Kappa_u/(8k^2), C_tail=6/(Kappa_u*t_L), replace G8--G9 by

    H=ceil{[5 eps s+2 eta_w+ceil(log2(1+C_tail))+Bq
                   +ceil(log2(1/eta_parent))+B_grid+12]/t_L},
    n_flush=16(H+Bq+6).

The added B_grid+8 relative to G8 pays the two-sector grid union and
the q/4 Markov thresholds. The stronger terminal flush gives failure
at most q/4. On a passed row, n_flush<=n_body implies T<=2 n_body and
the final-word bad-effect Lipschitz constant 2T<=R/4. Interpolation
therefore costs at most q/64. No grid is experimentally sampled or
emitted in the program. The same parent and Fourier receiver cover the
entire supplied interval; the physical coefficient norm remains paid.

The initial-state examples retain the supplied geometric tail
Tr(P_(depth>A) tau)<=2^-A with A=Bq+8. All initial, body and terminal
forward calls enter the displayed rate. General initializers require
the separately frozen explicit-tail qualification 736cebd6; there is
no uniform finite bound for every normal state.

The new producer also repeats every inner/outer finite denominator,
moment, rank-width, sign-degree and repeated-encoder precision guard
from the earlier policy, after recomputing the new values. It is not a
new implementation of the quantum code or a full hardware gate count.

| Reference beta | k | Mesoblocks s | All forward calls |
|---|---:|---:|---:|
| 1/128 | 3276 | 9223372036854775808 | 2027745784350416647739556077680 |
| 1/512 | 52428 | 2361183241434822606848 | 8307548208595971725670537950505328 |
| 1/2048 | 838860 | 604462909807314587353088 | 68056408480477036702278998870158324528 |

Each selected row passes

    ell_code >= [3/2+G/(16k)]*(n_initial+n_body+n_flush).

Since actual b<2b0, the excess is at least actual b/119040. This is a
conditional finite scalar implication. It does not reuse the old rows
as if their source margin or continuum event were unchanged. The old
known-parameter producer/data hashes remain 68b03eac and 0ec806a0.

The probability table, source-circuit experiments, fair-bit seeds,
inner polar queries, stable phase generation, whole-encoder repetitions
and operational accuracy are all separately recorded. For reference
beta=1/128, the conservative inner-query bound is still about 2^10701;
this is a primitive count before the paid functional access/native cost.
These enormous sufficient counts establish no practicality or advantage.

The interval cannot be installed at Alice by receiver observations
over a forward-only wire: the separate CALIBRATION_INFORMATION_FLOW.md
proves the precise no-signalling obstruction and prices a conditional
receiver-only experiment. No calibration calls are hidden in these rows.
An encoder independent of the interval location would be a different
possible way around that information-flow limitation.

The full native integration d8142311 is being reviewed separately.
These new scalar rows have no independent review yet; their original
source, random-program, initial-state and public quantum-preprocessing
qualifications remain. Physical NOT_PERFORMED, practical advantage
NOT_ESTABLISHED, priority UNKNOWN, mission NOT_ACHIEVED.
