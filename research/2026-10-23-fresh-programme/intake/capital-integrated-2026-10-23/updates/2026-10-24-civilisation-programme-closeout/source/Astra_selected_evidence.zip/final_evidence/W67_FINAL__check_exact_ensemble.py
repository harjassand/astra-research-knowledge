"""Exact small algebra tests for the mesoblock filtered-frame candidate.

No giant code or random-design concentration is executed. Fractions test
the event-conditioned mean inequality, a non-diagonal positive filter,
zero padded labels, isometric ranges and a fixed public-prefix average.
The low-dimensional fixtures do NOT satisfy the asymptotic frame ratio
guard, and do not validate that concentration theorem by themselves.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json

OUT = Path(__file__).with_name("EXACT_ENSEMBLE_CHECKS.json")


def ident(n):
    return [[F(i == j) for j in range(n)] for i in range(n)]


def trans(a):
    return [list(x) for x in zip(*a)]


def mul(a, b):
    bt = trans(b)
    return [[sum(x * y for x, y in zip(r, c)) for c in bt] for r in a]


def scale(a, c):
    return [[c * x for x in row] for row in a]


def add(a, b, c=F(1)):
    return [[x + c * y for x, y in zip(ar, br)] for ar, br in zip(a, b)]


def inv(a):
    n = len(a)
    z = [a[i][:] + ident(n)[i] for i in range(n)]
    for j in range(n):
        p = next((i for i in range(j, n) if z[i][j]), None)
        if p is None:
            raise ValueError("singular")
        z[j], z[p] = z[p], z[j]
        v = z[j][j]
        z[j] = [x / v for x in z[j]]
        for i in range(n):
            if i != j and z[i][j]:
                v = z[i][j]
                z[i] = [x - v * y for x, y in zip(z[i], z[j])]
    return [row[n:] for row in z]


def psd(a):
    """Exact symmetric elimination, including zero-pivot qualification."""
    a = [r[:] for r in a]
    assert a == trans(a)
    n = len(a)
    for j in range(n):
        if a[j][j] < 0:
            return False
        if not a[j][j]:
            if any(a[i][j] for i in range(j + 1, n)):
                return False
            continue
        p = a[j][j]
        for i in range(j + 1, n):
            for q in range(i, n):
                a[q][i] -= a[q][j] * a[i][j] / p
                a[i][q] = a[q][i]
    return True


def trace(a):
    return sum(a[i][i] for i in range(len(a)))


def zero(a):
    return all(not x for row in a for x in row)


def parity(x):
    return x.bit_count() % 2


def fixture(D=16, K=2, tau=F(4, 5)):
    # A rational orthogonal Householder, acting only on valid labels0..11.
    nvalid = 12
    w = [F(i + 1) if i < nvalid else F(0) for i in range(D)]
    ww = sum(x * x for x in w)
    Q = [[F(i == j) - 2 * w[i] * w[j] / ww for j in range(D)] for i in range(D)]
    assert mul(Q, trans(Q)) == ident(D)
    diagonal = [F(1), F(3, 4), F(1, 2), F(1, 4)] * 3 + [F(0)] * 4
    A = mul(mul(Q, [[diagonal[i] * F(i == j) for j in range(D)] for i in range(D)]), trans(Q))
    A2 = mul(A, A)
    mu = trace(A2) / D
    assert psd(A) and psd(add(ident(D), A, -F(1)))
    assert any(A[i][j] for i in range(D) for j in range(D) if i != j)
    assert all(not A[i][j] for i in range(nvalid, D) for j in range(D))
    # Normalized Walsh frame: sqrt(D)=4 is rational in this fixture.
    base = [[F((-1) ** parity(i & j), 4) for j in range(K)] for i in range(D)]
    assert mul(trans(base), base) == ident(K)
    first = [[F(0) for _ in range(D)] for _ in range(D)]
    mean_good = [[F(0) for _ in range(D)] for _ in range(D)]
    good = singular = 0
    for xp, zp in product(range(D), repeat=2):
        V = [[((-1) ** parity(zp & i)) * base[i ^ xp][j] for j in range(K)] for i in range(D)]
        VV = mul(V, trans(V))
        first = add(first, VV)
        Y = mul(A, V)
        G = mul(trans(Y), Y)
        centered = add(G, scale(ident(K), mu), -F(1))
        good_here = psd(add(scale(ident(K), tau * mu), centered)) and psd(add(scale(ident(K), tau * mu), centered, -F(1)))
        if not good_here:
            continue
        try:
            Ginv = inv(G)
        except ValueError:
            singular += 1
            continue
        P = mul(mul(Y, Ginv), trans(Y))
        assert mul(P, P) == P and trace(P) == K
        assert all(not P[i][j] for i in range(nvalid, D) for j in range(D))
        point_bound = scale(mul(mul(A, VV), A), 1 / ((1 - tau) * mu))
        assert psd(add(point_bound, P, -F(1)))
        mean_good = add(mean_good, scale(P, F(1, K)))
        good += 1
    count = D * D
    assert scale(first, F(1, count)) == scale(ident(D), F(K, D))
    mean_good = scale(mean_good, F(1, count))
    rhs = scale(A2, 1 / (D * mu * (1 - tau)))
    assert psd(add(rhs, mean_good, -F(1)))
    return {
        "D": D, "K": K, "valid_labels": nvalid, "tau": str(tau),
        "mu": str(mu), "finite_pauli_frames": count,
        "good_frames": good, "singular_good_frames": singular,
        "first_moment_exact": True, "all_pointwise_bounds_exact": True,
        "mean_good_bound_exact": True, "range_projectors_exact": True,
        "padding_output_zero_exact": True,
        "asymptotic_ratio_guard_satisfied": F(K, D) <= F(1, 2**20) * tau * tau * mu,
    }


def prefix_fixture(widths, logical):
    total = sum(widths)
    assert logical <= total
    dim, K = 2**total, 2**logical
    gauge = 2**(total - logical)
    diagonal = [F(0) for _ in range(dim)]
    for z in range(gauge):
        # Each fixed z is a PURE injection, with exact reverse permutation.
        cols = [z * K + x for x in range(K)]
        assert len(set(cols)) == K
        for c in cols:
            diagonal[c] += F(1, gauge * K)
    assert diagonal == [F(1, dim)] * dim
    return {"widths": widths, "logical_width": logical, "public_prefix_bits": total - logical,
            "prefixes": gauge, "exact_common_width_isometries": True,
            "mixed_logical_and_public_prefix_average_uniform": True}


def main():
    rows = [fixture(K=k) for k in (1, 2, 4)]
    prefixes = [prefix_fixture(w, L) for w, L in [([1, 2], 2), ([2, 2], 2), ([1, 3, 2], 3), ([3, 1], 1)]]
    result = {"status": "PASS", "scope": __doc__, "filtered_frames": rows, "fixed_public_prefixes": prefixes}
    payload = json.dumps(result, indent=2) + "\n"
    if OUT.exists():
        if OUT.read_text() != payload:
            raise RuntimeError("refuse to overwrite a different frozen result")
    else:
        OUT.write_text(payload)
    print(json.dumps({"status": "PASS", "frames": sum(r["finite_pauli_frames"] for r in rows),
                      "good": [r["good_frames"] for r in rows], "prefix_cases": len(prefixes)}))


if __name__ == "__main__":
    main()
