# The Gibbs source is the exact two-port bulk-entropy optimum

23 October 2026. This adds a stronger conclusion to root's EXACT_PAIR_GIBBS_SOURCE.md. W66 found the load-bearing complete averaged-response identity after reading the candidate. Root independently replayed all coefficients of the original two-call word unitary, without importing producer code, and independently reconstructs the upper argument below. W66/W67 written reviews and a fresh integrated code review remain separate.

Let \(\zeta_2\) be the legitimate normal bath state uniform on its four depth-two binary words, with any fixed seed. Every required two-call history remains nonroot before its last call. Its complete input-operator contraction is
\[
\operatorname{Tr}_E[(I\otimes\zeta_2)
 (Q-W_2^*(Q\otimes I)W_2)]
=a[2(Q-I)+bH]=aL. \tag{1}
\]
This is a full nine-by-nine operator equality, not only its three contractions with \(\sigma,\sigma A,\sigma H\). Root's independent Fraction-arithmetic original-word expansion in check_pair_average.py checks all 243 polynomial coefficients exactly; PAIR_AVERAGE_EXACT_CHECK.json retains every coefficient. Charge-offdiagonal entries vanish by total charge/depth conservation and the fixed depth of \(\zeta_2\). The offdiagonal charge-one entries are \(ab/2\) on \(|0c\rangle\langle c0|\) and its adjoint, with zero color-offdiagonal entries. The seed is not reached during these calls.

For ANY two-port density \(\rho\) whose original full bulk response is nonpositive as a bath operator, its expectation in \(\zeta_2\) is nonpositive. Thus for \(0<b<1\),
\[
\operatorname{Tr}\rho L\le0.
\]
At the unique \(t_b>0\) minimizing \(Z(t)\), the Gibbs variational identity therefore gives, for every such density including arbitrary input charge coherences,
\[
S_2(\rho)
\le \log_2 Z(t_b)
 +\frac{t_b}{\ln2}\operatorname{Tr}\rho L
\le\log_2 Z(t_b). \tag{2}
\]
No phase-pinning assumption is needed for this upper: (1) tests the full input operator, and relative entropy to the full-rank Gibbs density establishes (2) directly.

Root's explicit \(\rho_{t_b}\) has **zero full bath-operator drift**, not just zero drift in \(\zeta_2\), and attains this entropy. Sources with strictly negative full drift approach it as \(t\downarrow t_b\) from above. Hence the exact entropy optimum over **all two-port nonpositive-bulk-drift densities** is
\[
\boxed{\sup_{\rho:\mathcal D_b(\rho)\le0} S_2(\rho)
=\log_2[e^{2t_b}+4e^{-2t_b}+4\cosh(t_bb/2)] .}
\]
The strict-inward class has the same supremum by continuity. The weak-inequality optimum exists and is unique by strict entropy concavity; the displayed Gibbs density is its optimizer.

Its leading excess over three bits is \((\ln2)b^2/64+O(b^4)\). Thus the best entropy-rate excess in this specific two-call inward-source interface is **quartic in beta**, even though the full unrestricted recurrent model has a separately proved quadratic-in-beta capacity excess using growing blocks. This is an interface limitation, not an upper bound on arbitrary two-call codes, all block sources, feedback, or the channel capacity.

The exact finite-dimensional algebra establishes this mathematical optimum. It does not establish novelty, a physically acquired memory interaction, practical gate costs, a complete source-to-message encoder, or mission accomplishment. The earlier rational source and its simpler fully charged construction remain independently useful.
