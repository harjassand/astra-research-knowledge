# W18 conclusion and exact continuation boundary

24 October 2026, user-directed drain conveyed by root. The current exact
POVM unit is finished. W18 becomes IDLE after the parent handoff. No new
investigation, reactivation, descendants, outreach or public disclosure
is authorized by this checkpoint. It is a continuity record, not a
claim that the research mission or unrestricted second order is solved.

## Governing source and strongest completed result

Pinned corpus e606bfc587c76bdcae8b8fa3ec33e721efa2fbac was rechecked clean.
The original source is sigma_k=Phi_D^tensor k tensor
nu_D^tensor(L-k), K in{1,...,L}, with actual inaccessible duplicated
classical clock and independent PRODUCT old memory. The known finite
prior is supplied; no actual clock or entangled aid is supplied. The
receiver contract is finite TP LOCC, deterministic Bell rank on every
branch and vanishing error to Bell tensor its OWN complete residual.
Take r to infinity at EACH fixed source before any source family.

The strongest universal theorem remains

    max(0,H-log(H+1)-C_D) <= Delta=B-R(p) <= H+kappa_D,
    Delta/H ->1 for EVERY H->infinity family.

`GENERAL_PRIOR_ENTROPY.md`, SHA256
f60f03d916e3d7f8ca9afb13068b319f0a5607212e664c8990b1e2ed11aff366,
has W38/W44 fresh scoped internal audits. It covers arbitrary finite
priors independently of support diameter. The inherited lower receiver,
complete-source constraints, sparse/grid corollaries and all exact
finite comparisons are preserved. External correctness and historical
novelty remain UNKNOWN; no practical/physical advantage is established.

## Reviewed operational frontier

`frontier_rate/MERGING_GLOBAL_CLOCK_CURRENCY.md`, SHA256
79062b0921296d6b8a62709e99edee060985b64e86de1cad5a1995be9d79ce87,
has root's full analytic CONDITIONAL INTERNAL PASS
`work/root/W18_GLOBAL_CLOCK_CURRENCY_REVIEW.md`, SHA256
ae595c4a2edc4c13cd402372d3d9af27032d69e65e7d666a19317e8769e7f1db.
I personally read the full receipt and verified the frozen prerequisite.
It proves for each fixed finite actual r-device and any GLOBAL POVM Y
on retained Q=A:B,

    Ic(Q)+I(actual K^r:Y)+v_P(gamma) <=rB+log S,
    v_P=(1-gamma)log[(P+1)/2]-h2(gamma).

Independent fixed-device repetition, paid reference-preserving merging
and separate return-port tests justify that finite inequality. On the
paired-MC native target with pure actual prefixes, arbitrary diagonal
MC suffix and Bob-only work it gives net ER potential <=B-H+c(1/D),
with no Bob-work dimension bound. This is an architecture theorem,
not an unrestricted capacity converse. Useful two-sided quantum work,
non-MC outputs and accessible-clock erasure remain outside its scope.

Earlier stopped/readable/phase-flag/orthogonal-ME/unrecorded-data
barriers and their W44/W01 receipts are preserved. W01's fresh third
unrecorded-data audit 95e57aba... passes cd4d0c63.... Root's 79062b
review does not certify later two-sided-shield or dense-flag extensions.
The generic merging-then-global-read/net-charge strategy is PRIOR
Ye et al. PRA81,014303(2010); the MQ resource identity is PRIOR Coles.
No generic priority is claimed for these ingredients.

## Final exact unit: constants falsified, capacity still open

1. `frontier_rate/GHZ_POINTWISE_PREFIX_COUNTEREXAMPLE.md`, SHA256
816647966d41e3b8ee0ae585cf48a0edd7b480a4f268434cf094154dffb7c13d,
is an exact physical rank-one SEP-effect counterexample to the proposed
pointwise constants r h_L and r c(1/D). Original native D32,L2,r3,
known first sites explicitly factored, no added aid: GHZ+ on Alice's
three uncertain sites and GHZ- on Bob's give F=.546197089002... versus
3c=.430639891989.... Its simple four-outcome local completion has
NEGATIVE averaged F and is not an averaged counterexample. Checker
61eb11... and raw dd73bef... retain exact source/overlap/completion laws.

2. `frontier_rate/COMPLETED_SEP_AVERAGED_CONSTANT_COUNTEREXAMPLE.md`,
SHA2567c39f9d86c70c346328b08415b3306f0f4fdf704f17b2c478ff6c56384273459,
then constructs four complete SEP core effects from three product-
isotropic states and the local-isotropic GHZ+/- twirl. Their exact
white weights and eight-sector operator identity prove completeness.
The actual native D128,L2,r3 lift has FIVE outcomes, retains known
prefixes and requires no added stock. The averaged F exceeds3c by
.06553317642588519...>3/50, certified by64-term rational log intervals
on a2^-192 grid. LOCC implementation is UNKNOWN. No Bell receiver,
optimum, capacity gain or logarithmic-in-H saving follows.

Exact standalone checker:
`frontier_rate/check_completed_sep_constant_counterexample.py`, SHA256
8680d2d8e2c3592f7ebdea214ea856e53100090567a99a72c2971c097a94c9a4.
Raw SHA25697664386b2c25c42d96cda186408cfbd1a15cdf45a739e5975ecd74d0bd14cf2.
Passes32SEP-state normalizations,32SEP sector completions,64PPT
positivity controls,64Born likelihoods,16actual native lifts and2
exact logarithmic gap certificates. These are internally derived,
not freshly independently reviewed or externally certified.

3. A separate four-outcome PPT-only counterpart violates the averaged
c constant already atD32 by an exact gap>.05. This weaker operational
restriction is not promoted to SEP; the independent GHZ-twirl family
above establishes SEP directly. The exploratory symmetric-PPT LPs
are floating diagnostics and are NOT proof premises for either family.

Root's mathematical two-one-site-queue swap lemma d9570730... passes
in `frontier_rate/TWO_QUEUE_ROOT_SWAP_REVIEW.md`, SHA256
9a79222238ebcf9fba8b72f71ad549970fefeefb5e9bc25264902c0f57744041.
The mandatory original-source label correction is root's
`TWO_QUEUE_SWAP_SOURCE_QUALIFICATION.md`, SHA256
bccf3cb5508ab3a51b22cb59b6a54c8b1dbb9cb763087a7840288654c468c6ea.
Its four entries describe stripped choices{0,1}, not nativeL1. Arbitrary
actual known prefixes cannot simply be removed. Its all-r extension is
not asserted and does not survive the GHZ constant counterexample.

`POINTWISE_ROUTE_STATUS_ADDENDUM.md` supersedes the historical
`PHYSICAL_PREFIX_OVERLAP_CONJECTURE.md` status without rewriting it.
Earlier D2 graph/complex/PPT diagnostics retain their finite scopes;
they never proved an all-D statement. Positive Fourier shadow alone
also fails, and three-queue PPT projection hulls have nonrectangular
vertices. No universal geometry is inferred from finite LP hulls.

## Unresolved resume obligations, only if explicitly reactivated

The actual fixed-D contiguous-uniform second order remains OPEN:
Delta=H+O_D(1), H-Theta(logH), or another behavior is unproved. The new
counterexamples only reject a PARTICULAR pointwise/averaged constant.
They do not reject a more permissive D-dependent constant and do not
establish a LOCC violation of the averaged bound. If explicitly resumed,
fresh criticism of the completed SEP operator identity and source lift
must precede any promotion. Larger constants, LOCC-specific completeness
constraints and true receivers would be separate investigations.

W01 and W44 are drained/idle and must not receive new assignments from
this checkpoint. No background calculation is intentionally left running.
`CONCLUSION_MANIFEST.json` binds all retained worker scientific files,
excluding the Python environment and caches, plus the pivotal external
source/review files. Final statuses: novelty UNKNOWN, external validity
UNKNOWN, physical/computational/practical advantage NOT_ESTABLISHED,
unrestricted second order OPEN, mission NOT_ACHIEVED.
