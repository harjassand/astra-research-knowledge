# Candidate uniform three-pattern Laplacian construction

23 October2026. Fresh mechanism derived by W15 after auditing the full-family
q2 obstruction. Pending independent review. No practical or priority claim.
Known support remains supplied; unknown-support acquisition is separate.

## Claim and inherited capital

Every finite known simple G with treewidth<=2 and maximum degree<=4 admits
rational n-by3 probes P with every whole row norm<=1, and a size-independent
constant C such that every signed conservative supported Laplacian satisfies

    ||L||F <= C ||L P||F.

Canonical LS over the original Laplacian coefficient space then gives
Frobenius and operator error<=C||E||F for arbitrary full original three-action
noise. No physical restriction on signed DIFFERENCES is needed; positive
baseline weights are included. Coupled with the audited P_n^2 q2 obstruction,
this would make three the minimum uniform count on the full known-support
class. It would not replace the chordless q2 positive theorem.

We reuse the already independently audited four-pattern theorem
../PROOF_UNIVERSAL_Q4.md, SHA256
862560084687db0b43c20fec0c862bb42fc50d52c776c2c49dc095afab2ddbad,
and its local polynomial/LLL construction, ../LLL_45BIT_SUPPLEMENT.md,
SHA2565d833867f69a1509f9558c5f60015697854982795b9533e504f42ca806dfb6c7.
The new issue is NOT automatic generic restriction: all rows are now confined
to a fixed affine hyperplane. We prove the needed rank and cycle polynomials
remain nonidentically zero there, then restate the normalization/noise bridge.

## Affine grid, actual row norms, rational three-channel projection

Use exactly the short-cycle sets S,B and star4 base coloring c in the audited
proof. Let Lgrid=2^36, Q=400 Lgrid. For each original vertex choose three
independent integers m1,m2,m3 in{1,...,Lgrid}. Put

    Xi_v=(398 Lgrid e_c+(m1,m2,m3,-m1-m2-m3))/Q.             (A)

Each row has sum s=398/400=199/200, the SAME s for every vertex. For c<=3,
its squared norm is at most(399^2+1+1+9)/400^2<1. For c=4, the fourth
numerator stays positive and at most398 Lgrid, giving squared norm at most
(398^2+3)/400^2<1. Distance from e_c is at most sqrt28/400<1/50. Therefore
the high-girth complement coercivity holds with

    beta=1/sqrt2-sqrt5/50>0,  beta^-1<2sqrt2.                (B)

Let the rational4-by3 matrix T have rows

    (1,1,1)/2, (1,-1,-1)/2, (-1,1,-1)/2, (-1,-1,1)/2.

Then T^T T=I3 and TT^T=I4-11^T/4. Set the ACTUAL acquired probe rows
P_v=Xi_v T. Every row norm<=||Xi_v||<1. These are THREE probes; Xi's fourth
coordinate is only a mathematical lift. Their coordinates still have common
denominator Q: after the1/2 in T, the398 Lgrid base becomes199 Lgrid and
the sum-zero perturbation produces even sums. Thus the actual probe
denominator remains45 bits, independent of graph size.

For every conservative L, L1=0 and Xi1=s1, so LXi1=0 and

    LXi = (LP)T^T,  ||LXi||F=||LP||F.                       (C)

Given noisy actual three-channel data LP+E, the computed lift (LP+E)T^T has
noise ET^T with EXACTLY the same Frobenius norm. No extra action or extra
independent noise observation is supplied by this identity.

## Restricted rank polynomials are nonzero

The row variables in(A) range over a three-dimensional open subset of the
affine hyperplane H={x in R4:sum x=s}, with s!=0. Four such rows can be
linearly independent: equivalently their three-dimensional affine coordinates
form a tetrahedron. Thus every4-by4 cofactor determinant on four distinct
rows is a nonzero polynomial in the independent three-coordinate variables.
For a lower-degree row with r=degree+1<=3, the first r columns also form a
nonzero minor polynomial: the projection H to the first three coordinates is
a bijective affine map onto R3, so r freely chosen rows have a nonzero such
minor generically. The rank events are exactly those of the audited LLL.

## Restricted induced-cycle holonomy is nonzero

For an induced all-degree4 cycle C of length3..13, define the same raw
cofactors k_i and P_C=prod k_i(next)-prod k_i(prev) as in the audited proof.
Its combinatorial unmatched-rowset argument is unchanged: some numerator
four-set M is absent from every denominator four-set. Otherwise all external
pairs coincide and a common apex over C yields a forbidden K4 minor.

To prove nonidentity WITHIN H, identify H affinely with R3. Place the four
points indexed by M in a common affine plane, with every three affinely
independent. They have linearly dependent lifted4D rows and every three
lifted rows independent because s!=0. Every denominator four-set differs
from M, so contains at most three constrained points; these are affinely
independent. All remaining points can be chosen generically in R3 so each
denominator four-set is affinely independent. Each individual condition is
a nonzero polynomial and finitely many can be avoided simultaneously.
The numerator product vanishes and the denominator product does not.
Therefore P_C is a NONZERO polynomial on the affine row variables.

Shared outside neighbors are already accounted for as the SAME point variable.
Distinct vertices in this argument have independent row variables; no palette
label identification is introduced. This proof is a geometric specialization,
not an unsupported assertion that a nonzero4D polynomial stays nonzero on H.

## Same bounded-grid Local Lemma and quantitative inverse

Every row entry is affine in its three independent integer variables.
All rank polynomials have degree<=4, and all P_C have degree<=52 (one may
improve this using the affine volume degree, but no improvement is needed).
Schwartz-Zippel on the Lgrid-valued product grid gives each bad event
probability p<=52/Lgrid. Events use at most39 rows. The unchanged bounded-
degree overlap count from the audited supplement gives

    U=5,314,405 events/row, D+1<=39U=207,261,795,
    4p(D+1)<=43,110,453,360/68,719,476,736<1.

The standard variable-model Local Lemma therefore supplies an assignment
where all rank and cycle constraints are nonzero. Moser-Tardos resampling
uses the three coordinates of each involved row and has expected O(n) local
resamplings with the same very large degree-dependent constants. This is not
a deterministic runtime cap or free base-color preparation.

The common denominator Q, row norms<=1, and exact nonzero events give the
same raw determinant bounds Q^-4 and cycle-product bounds Q^-52. Hence
eta=1/(27Q^4), A=2^15 eta^-1 Q^52 and C_S=A sqrt1457 from the original
raw-cycle/witness-overlap proof. None of that argument requires four free
coordinates after these conditions are established. The complement uses
the slightly weaker beta in(B); all other local and cross-block inequalities
are unchanged. Consequently for EVERY supported symmetric D,

    ||D||F <= sqrt[2 C_S^2+beta^-2(1+2C_S)^2] ||D Xi||F.     (D)

In particular(C) yields the claimed three-channel inequality for L. Since
beta^-1<2sqrt2 and C_S>=2, a simple sufficient constant is

    C=283,115,520 Q^56.

This bound is astronomically large. A45-bit probe description does NOT make
measurement tolerance, coefficient precision, output error or calibration
useful. Finite well-conditioned designs would require separate evidence.

## Decoder and complete cost boundary

Use ordinary global LS on original edge coefficients, with actual incident-
sum diagonals, so its output is conservative. The injective image is a linear
subspace; orthogonal projection of arbitrary E onto it has norm<=||E||F.
Equation(D) and(C) then prove the original F/operator noise guarantee with C.
No transformed-coordinate noise budget is silently substituted.

All original3n action cells are acquired. Known G, short-cycle enumeration,
base star4 coloring, exact LLL event checks/resampling, rational probe output,
LS, matrix output, bit growth and any physical actions/reset/calibration are
paid. The existing constructive Timmons extraction can be used if audited;
otherwise explicit finite star-color search is an honest expensive fallback.
Dense LS is O(n^3) arithmetic/O(n^2) storage. An optional sparse decomposition
bound follows by expanding each width-two support bag into incident edge
variables: at most3*4=12 variables/bag, so the normal graph has width<=11
and given that decomposition ordinary sparse LS is O(n) arithmetic. That
does not bound rational bit growth or discovery/preparation time.

No source program, entry oracle or unknown graph acquisition is supplied by
this theorem. Equally informed sparse-Hessian/rigidity/ordinary LS comparators
receive the SAME G and all acquired measurements. Existing constant-channel
projection under conservation is a standard elementary operation, not a
priority claim. Novelty, practical advantage, physical usefulness and mission
attainment remain UNKNOWN or NOT_ESTABLISHED. Fresh review must focus on the
restricted holonomy polynomial, row norms and the exact three-channel metric.
