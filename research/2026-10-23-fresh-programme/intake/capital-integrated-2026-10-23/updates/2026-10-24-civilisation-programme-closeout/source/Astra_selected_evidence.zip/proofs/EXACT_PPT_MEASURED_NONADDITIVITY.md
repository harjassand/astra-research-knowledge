# Exact obstruction to a PPT measured-divergence shortcut

23 October 2026, independent w18 derivation. This is a finite, exact
counterexample to additivity of PPT measured relative entropy against the
white separable comparison state for a source core. It is not a collective
LOCC receiver, a minimum-output-entropy counterexample, or a rate theorem.
Historical novelty and external correctness remain UNKNOWN.

## State and exact single-copy optimum

Set D=3 and let the two-site core be

    omega = (pi_1 tensor pi_2 + Phi_3 tensor pi_2
             + Phi_3 tensor Phi_3)/3,
    pi_j = I_(A_j B_j)/9,
    pi = I_(A_1 A_2 B_1 B_2)/81.

This is the unchanged core obtained by stripping the known first Bell pair
from the original D=3 uniform K=1,2,3 source. For any state pair let D_PPT
be the supremum of classical relative entropy over finite PPT POVMs.
Partial transpose is across the complete Bob register.

Let P_0=Phi_3, P_1=I-Phi_3. An independently site-twirled effect has physical
eigenvalues e=(e_00,e_01,e_10,e_11) in these sectors. Its partial transpose
has eigenvalues T e, where

    T = S tensor S,       S = [[1,2],[-1,4]]/3.

Thus its invariant PPT cone is {e>=0,T e>=0}. The exact five extreme rays,
up to positive scale, are

    (0,0,0,1), (0,0,1,1/4), (0,1,0,1/4),
    (1,1/4,1/4,1/16), (1,0,0,1/8).

This list is independently checked by exact enumeration of all 56 triples
of active inequalities among the eight defining inequalities. Each
nonzero cofactor kernel is oriented and tested using rational arithmetic.
The cone is pointed and full dimensional, so an extreme ray has three
independent active constraints, making this enumeration exhaustive.

Define the single-site effects

    F_0 = Phi_3 + (I-Phi_3)/4,
    F_1 = 3(I-Phi_3)/4.

They arise from measuring both sites in the same computational basis,
recording equality versus inequality, and averaging over a common local
basis. Their tensor products give the first four rays above. Their white
and source outcome probabilities, in order 00,01,10,11, are

    Q = (1,2,2,4)/9,
    P = (13,8,2,4)/27,
    P/Q = (13/3,4/3,1/3,1/3).

They attain

    C = (13 ln13 + 8 ln4)/27 - ln3
      = 0.547117212663708... .

Here is an exact dual proof of optimality over every PPT POVM. For a
nonnegative effect e define its homogeneous contribution

    f(e) = (x.e) ln[(x.e)/(u.e)],

where x is the source sector-probability vector and u the white sector law.
The log-sum inequality makes f subadditive. Choose the unique linear
functional v agreeing with f on the four canonical effect vectors.
Its slack on the fifth ray is exactly

    v.(1,0,0,1/8) - f(1,0,0,1/8)
      = (39 ln13 - 33 ln11 - 8 ln4)/81 > 0,

because the integer inequality 13^39 > 11^33 4^8 holds. Consequently v.e
>=f(e) throughout the PPT cone. Every PPT POVM can be site-twirled without
changing either outcome law, and summing v.e over its effects gives C.
This proves

    D_PPT(omega||pi) = C.                              (1)

## A ten-outcome PPT POVM on two copies

Order the four sites by the two source copies. For every four-bit string
b define F_b as the tensor product of F_(b_j), and let |b| be its Hamming
weight. Write the physical sector eigenvalue of another effect E at a
sector s as

    E_s = 9/16       if |s|=2,
          27/256     if |s|=4,
          0          otherwise.

Its exact partial-transpose spectrum is

    (E^Gamma)_s = 3/16   if |s|=0,
                    1/8  if |s|=1,
                    1    if |s|=4,
                    0    otherwise.

In particular E and E^Gamma are positive. The following ten effects sum
exactly to the identity:

    F_b for |b|=0 or 1;     2 F_b for |b|=3;     E.

There are five effects of the first kind, four of the second, and one E.
The omitted canonical effects have weights two or four. Each retained
canonical effect is PPT; E's displayed spectrum proves the same for E.
No assertion of separability or an LOCC implementation is made for E.

On omega tensor omega and pi tensor pi, this measurement has divergence

    2 C + delta,
    delta = 0.001192224261476340031237218774764987903926119171998...
            > 1/1000.

The exact rational outcome laws are retained in
`exact_ppt_measurement_counterexample_checks.json`. Positivity of delta is
certified without trusting floating-point logarithms: for every rational
likelihood q, set y=(q-1)/(q+1) and bound ln q by 128 terms of
2 sum_(j>=0) y^(2j+1)/(2j+1), with exact rational remainder bound
2 |y|^257/[257(1-y^2)]. The resulting rational lower bound on delta exceeds
1/1000. Thus

    D_PPT(omega^tensor2||pi^tensor2)
       > 2 D_PPT(omega||pi).                           (2)

The same explicit POVM improves the product canonical measurement by
0.01053549868027867322655... for prior (1/6,1/3,1/2), though no separate
single-copy optimality claim is needed for that second admission.

## Consequence and boundary

The computational measurement remains exactly optimal for a single queue
in the one-round calculation. Equation (2) shows that replacing its
unproved collective extension by a PPT measurement relaxation does not
give an additive formula. It does not settle the compatible-marginal
minimum-output-entropy question, arbitrary LOCC measured divergence, or
the original contiguous-uniform second-order entanglement deficit.

Every object above is a mathematical comparison measurement. It supplies
no inaccessible clock, actual entangled stock or physically acquired data.
Any future operational application must retain the original complete
residual and fixed-source r-first limits. The theorem is finite; no
computational advantage or efficient higher-copy implementation follows.

The standalone checker
`check_exact_ppt_measurement_counterexample.py` uses only Python's standard
library. It verifies all rational spectra, active sets, POVM normalization,
outcome laws, the integer single-copy dual inequality, and exact rational
log-series lower bounds. The exploratory parametric LP was used only to
discover E; it is not a premise of this certificate.

Restricted measured divergences are standard machinery; relevant primary
background includes Piani, arXiv:0904.2705; Lami--Regula,
arXiv:2307.11008v2; and Rippchen--Sreekumar--Berta, ISIT 2024,
DOI10.1109/ISIT57864.2024.10619141. This explicit source-core nonadditivity
certificate was derived here; a historical priority search has not been
completed.
