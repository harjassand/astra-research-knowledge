# A charged harmonic catalyst permits vanishing full joint return error

Independent construction after the small hot-ancilla marginal result and
the catalytic resource lower bounds. The harmonic embezzling mechanism is
established prior; its use here as a simultaneous tracial conditional-
expectation bucket cover is the specific construction being recorded.
Historical priority remains UNKNOWN.

## 1. Precise result

For every integer r>=2, let N=r^3 and use the original diagonal rank-r P,Q
with one shared basis vector. Define

    K0=r^2+r-1,
    w=(2r-1)K0,
    K=w^(4r),
    H_K=sum_(a=1)^K 1/a,
    sigma=diag(1/(a H_K): a=1,...,K),
    J(rho)=rho tensor sigma.

There are explicit commuting normalized-trace-preserving conditional
expectations F,G on M_(NK), with physical-product-diagonal range algebras,
such that the UNHALVED full joint return error obeys

    max(||F J-J E_P||_diamond,||G J-J E_Q||_diamond)
       <=1/r+(3+2 ln w)/H_K <2/r.                       (E1)

The comparison returns the entire ancilla as sigma, decoupled from the
system and arbitrary retained references. This is stronger than marginal
recovery. Ordinary partial trace satisfies Tr_A J=id exactly. No decoder
or target-channel action is hidden in J. The ancilla is independent of the
input and reference. The inequality is approximate, not exact return.

The dimension is K=r^(12r+O(r/log r)), with log2 K=Theta(r log r) ancillary
storage bits. Prepared entropy deficit and concentration are correspondingly
large. This is a concrete, expensive escape permitted by the lower bounds;
it does not make approximate catalysis a free resource.

## 2. Commuting weighted targets close to the original pair

Write O=P intersection Q, A=P minus Q, B=Q minus P, C=(P union Q)^c,
with cardinalities 1,r-1,r-1,M, where M=(r-1)K0. Define positive integer
weights, constant on these four cells, by

    w_O=(r-1)K0,
    w_A=w_B=(2r-1)K0=w,
    w_C=(2r-1)^2.

Their sum over all N individual labels is

    W=4r^2 M,

and w is their maximum. The probability nu_x=w_x/W has independent binary
P,Q events, both of probability p=1/(2r). Indeed its four aggregate masses
are p^2,p(1-p),p(1-p),(1-p)^2.

Let T_P,T_Q be the stochastic projection channels that first measure the
original system basis and then output nu conditioned on the input's P or Q
side, respectively. They are CPTP idempotents and commute, with

    T_P T_Q=T_Q T_P=R_nu,
    R_nu(X)=Tr(X)diag(nu).

They are generally not unital and are NOT the tracial expectations E_P,E_Q.
Their exact unhalved diamond distances to those original expectations are

    ||T_P-E_P||_diamond=||T_Q-E_Q||_diamond=1/r.           (E2)

On a P input the conditional common-cell mass is p rather than 1/r, giving
distance 2(1/r-p)=1/r. Outside P, the B mass is p rather than
1/[r(r+1)], giving distance (r-1)/[r(r+1)]<1/r. Outputs are uniform within
the relevant original cells, so these are the entire column differences.
Classical measure-prepare diamond norm equals the largest column l1 norm.
For the sharper p=(r+2)/(2r(r+1)) the best weighted-pair distance in this
one-parameter family is 1/(r+1); the simpler weights above suffice for (E1).

The weighted trace-relaxation observation has also been independently noted
by W50 for another p. This construction does not relabel the nontracial
channels as tracial: the next step is an explicit trace-preserving cover.

## 3. A simultaneous tracial bucket cover

Write K=J0*w, so J0=w^(4r-1). For each integer j=1,...,J0-1, define a
physical bucket

    B_j={(x,a): j*w_x+1<=a<=(j+1)*w_x}.

Every bucket is complete because w_x<=w and (j+1)w_x<=J0*w=K. Its x label
occurs exactly w_x times, and its total size is W. For a fixed x these
buckets are disjoint. Let Lft be the remaining physical basis points,
namely a<=w_x or a>J0*w_x.

Let F be the tracial block-average expectation on the following partition
of the physical basis:

    B_j intersection (P times ancilla),
    B_j intersection (P^c times ancilla),
    each singleton point in Lft.

Let G replace P by Q and use the same buckets and singletons. Both kill all
physical off-diagonal matrix units. They are unital, completely positive,
idempotent, and normalized-trace-preserving on the ENTIRE M_(NK). Within
each B_j, the P,Q table has cell counts proportional to the independent
law nu, so these conditional averages commute and compose to the uniform
average over B_j. On every leftover singleton they agree. Thus

    F G=G F=H

exactly on all matrix units, with H averaging each whole bucket and keeping
the leftover diagonal singletons. Their range and intersection algebras
are large; no fixed-dimensional range claim is made.

## 4. Uniform joint return error to the weighted target

Fix a basis input x, and let S be its P side. The target T_P outputs
nu_y/nu(S)=w_y/W_S for y in S, where W_S=sum_(y in S)w_y. In bucket j,
the encoded input puts mass

    b_j(x)=sum_(a=j w_x+1)^((j+1)w_x) 1/(a H_K).

After F this mass is uniform over the W_S physical points in that side of
B_j. The target joint product T_P(|x><x|) tensor sigma instead assigns
(w_y/W_S)/(a H_K) to each physical point (y,a) in that bucket. Since j>=1,

    1/(j+1)<=H_K b_j(x)<=1/j,
    1/(j+1)<=w_y/a<=1/j.

Hence each point's absolute discrepancy is at most

    1/[W_S H_K j(j+1)].

There are W_S such points, so summing over all bulk buckets bounds their
total l1 discrepancy by

    (1/H_K)sum_(j=1)^(J0-1) 1/[j(j+1)] <=1/H_K.        (E3)

The encoded input's leftover mass is

    ell_x=[H_(w_x)+H_K-H_(J0 w_x)]/H_K
         <=(1+ln w)/H_K.                               (E4)

Indeed H_(w_x)<=1+ln w_x and the tail harmonic sum is at most
ln(K/(J0 w_x))=ln(w/w_x). F leaves each leftover point alone. The target
joint product's leftover mass is the weighted average of ell_y on S and
obeys the same bound. Regardless of their overlap, the leftover l1
discrepancy is therefore at most 2(1+ln w)/H_K. Combining with (E3),

    ||F J-J T_P||_diamond <=(3+2 ln w)/H_K.              (E5)

For the diamond statement both maps kill off-diagonal SYSTEM matrix units
after J, since sigma is diagonal and the enlarged expectations kill all
physical off-diagonals. Their output is diagonal in the full physical basis.
The maximum-column-l1 proof therefore includes arbitrary references. No
positivity-only norm assumption occurs. G has the same estimate with Q.

Triangle inequality with (E2) proves the first part of (E1). Since
H_K>=ln(K+1)>4r ln w and w>=15, ln w>3/2, and thus

    (3+2 ln w)/H_K <1/r.

This proves the strict final bound in (E1) for every r>=2.

## 5. Words, interventions, and approximate reuse

The same calculation works for H with S the whole system, giving

    ||H J-J R_nu||_diamond <=(3+2 ln w)/H_K.              (E6)

The original family satisfies
||E_P E_Q-E_0||_diamond=2(r-1)/r^2, and every longer mixed word has no larger
distance to E_0. Also ||diag(nu)-I_N/N||_1<=2/r, directly from its four
cell masses. Every nonempty word containing both F and G equals H, so

    sup_word ||word(F,G)J-J word(E_P,E_Q)||_diamond
       <=(3+2 ln w)/H_K +2/r+2(r-1)/r^2 <5/r.           (E7)

Single-letter-only words have (E1); the empty word is exact. This is a
length-uniform full JOINT comparison for words without intervening operations.
It is not an exact semigroup dilation.

For arbitrary system/reference interventions or adaptive classical outcome
strategies, a hybrid argument using (E1) gives final full joint error at
most min(2,2T/r) after T action uses, including approximate decoupled return
of sigma. The ideal intermediate states keep their exact product ancilla;
channel contractivity controls the discrepancy of actual correlated states.
The claim is for the joint unconditioned outcome register, not normalized
rare postselected branches. It grants no access to the ancillary register.
There is no all-time catalytic error guarantee under unlimited interventions.

## 6. Complete resource accounting

The prepared state is highly nontracial. Exactly,

    m_sigma=K||sigma||_infinity=K/H_K,
    S_nats(sigma)=ln H_K+(1/H_K)sum_(a=1)^K (ln a)/a,
    C_sigma=log2 K-S_bits(sigma).

As K grows, C_sigma=(1/2)log2 K-log2 ln K+O(1), hence C_sigma=Theta(r log r).
Both log2(m_sigma) and ancillary storage log2 K have order r log r. They
pay for the full-return entropy difference allowed by a vanishing trace
error. The norm error alone does not mean vanishing entropy/resource change.

There are J0-1 bulk buckets. Their covered physical points total (J0-1)W;
the other NK-(J0-1)W points are leftover singletons. Consequently the exact
range dimensions are

    dim(range F)=dim(range G)=2(J0-1)+NK-(J0-1)W,
    dim(range H)=(J0-1)+NK-(J0-1)W.

The total dimension NK, these algebra dimensions, a literal partition
table, and a dense channel representation all grow extremely rapidly.
The interval rule is succinct, using O(log K+log r)=O(r log r) bits, and
membership/sampling can be done without listing that table.

The harmonic state can be sampled exactly without explicitly computing the
huge rational denominator H_K. Choose uniformly a dyadic bin
[2^b,min(2^(b+1)-1,K)], then uniformly a within that bin of length ell_b,
then accept if a fresh uniform integer in {1,...,a} is <=ell_b. Each a has
unconditional acceptance mass proportional to 1/a. The total acceptance
probability is H_K/(floor(log2 K)+1), bounded below by a positive constant.
Thus expected randomness and integer arithmetic costs are polynomial in
log K, with O(log K) expected random bits per successful draw. Uniform
integer sampling itself uses rejection; all randomness is charged.

F/G can measure the physical basis, determine j=floor((a-1)/w_x), and either
return that point if it is leftover or sample a uniform point in its
bucket/side block. The original four cells have constant weights, so this
uses integer weighted cell selection, uniform labels, and interval sampling,
all on O(log K)-bit integers. This is a mathematical classical simulation
route, not a calibrated hardware gate/energy theorem. The original E_P/E_Q
already have simple block-sampling implementations. No computational speedup,
experimental validation, cheap physical preparation, or free exact restoration
of a changed catalyst is established.

## 7. Comparison with lower bounds and prior

W40's general full-joint-return concentration lower bound, strengthened by
the one-sided entropy estimate audited separately here, forbids vanishing
error whenever m_sigma is polynomial in r. At error <=c/r it requires

    m_sigma,K >=r^(r/(2c+1)-O(1)).

Our explicit K=w^(4r)=r^(12r+O(r/log r)) and error <2/r match the exponential
order log K=Theta(r log r), not its sharp constant. This comparison uses
the same unhalved full joint diamond contract. The hot state remains
impossible at vanishing error for ANY K. The original same-ambient no-go
and all frozen audits remain unchanged.

The harmonic spectrum is the familiar van Dam-Hayden embezzling mechanism
(exact quant-ph/0201041v1), not an invented resource law. Ng et al., exact
arXiv:1405.3039v1, analyze optimal thermal embezzling and restrictions from
catalyst dimension/energy; their physical operation class differs from this
simultaneously commuting pair of tracial conditional expectations. These
sources are acquired and compared in LITERATURE.md. This construction must
not be advertised as the first use of harmonic spectra, approximate catalysis,
or dimension-dependent return lower bounds. Specific historical priority,
sharp constants, and practical value remain UNKNOWN.

Decisive falsifiers are a non-independent complete-bucket table, a missing
physical point in the partition, an incorrect weighted-target column norm,
or a uniform input column whose joint return discrepancy exceeds (E5).
The universal proof is analytic; small exact tests check the concrete
partition and error calculation without instantiating astronomical K.
