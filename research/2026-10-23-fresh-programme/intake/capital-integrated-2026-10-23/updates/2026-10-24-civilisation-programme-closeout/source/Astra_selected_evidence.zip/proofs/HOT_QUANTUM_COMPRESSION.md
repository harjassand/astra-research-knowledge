# A square-root-size hot ancilla from an explicit flat-marginal projection

23 October 2026. New candidate construction derived after independently
reconstructing W61's frozen hot hidden-intersection construction. W61 owns
that operational architecture. The present contribution is the entangled
projection, its resulting ancilla compression, and bounded architecture-specific
resource lower bounds. Priority and independent validity review are UNKNOWN.
No physical implementation or overall computational advantage is claimed.

## 1. Operational contract and result

For r>=2, N=r^3, let the original diagonal rank-r projections P,Q have one
common system basis vector. Write O=P intersection Q, A=P minus Q,
B=Q minus P, C=I-(P union Q), with dimensions 1,r-1,r-1,M respectively, where

    K0=r^2+r-1, M=(r-1)K0,
    b=M/(r-1)^2=r+2+1/(r-1).

Choose the smallest integer K>=2 satisfying

    K(K-1)>=b,

and put t=(r-1)^2 K. In particular

    ceil(sqrt(b))<=K<=ceil(sqrt(b))+1,
    K=Theta(sqrt(r)), t<M.

There are explicit trace-preserving conditional expectations F,G on M_(NK),
each with a three-dimensional abelian range, such that

    FG=GF=H,
    ||Tr_A F(. tensor I_K/K)-E_P||_diamond
      =||Tr_A G(. tensor I_K/K)-E_Q||_diamond=2/(r+1).     (1)

The norm is unhalved and includes arbitrary retained references. The same
all-word compression bound as W61's frozen hot construction holds without
intermediate ancilla reset:

    sup_word ||Tr_A word(F,G) J_hot-word(E_P,E_Q)||_diamond
        <=2(r-1)(3r-1)/r^3 ->0.                          (2)

The empty word is exact. Arbitrary intermediate interventions are not covered.
H has two-dimensional range and central weight 1/r. On the original common
input, its retained relative entropy from the global tracial state is log2(r).
The initial ancilla entropy deficit is zero.

## 2. Flat-marginal projection lemma, with an explicit sparse construction

Lemma. Let integers M,t,K obey 1<=t<M and M/t<=K-1. There is an explicit
rank-t projection R on C^M tensor C^K such that

    Tr_A(R)=(t/M) I_M.                                  (3)

Partition [0,M) into t half-open intervals

    I_j=[j M/t,(j+1) M/t), 0<=j<t,
    s_j=floor(j M/t).

Since M/t>1, the integer starts s_j are distinct. For each integer system
label x=0,...,M-1 define the rational weights

    a_(j,x)=(t/M) length(I_j intersection [x,x+1)).

They obey sum_x a_(j,x)=1 and sum_j a_(j,x)=t/M. Each positive support has
at most ceil(M/t)+1<=K consecutive system labels, all with
0<=x-s_j<K. Put

    |psi_j>=sum_x sqrt(a_(j,x)) |x> tensor |x-s_j>,
    R=sum_j |psi_j><psi_j|.                              (4)

The vectors are normalized. Two different vectors have disjoint physical
basis support: equality of both system and ancilla labels would require
s_j=s_l. Thus they are orthonormal and R is a rank-t orthogonal projection.
Within each vector, distinct system labels have distinct ancilla labels;
partial trace removes their coherences. Therefore

    Tr_A R=sum_x (sum_j a_(j,x)) |x><x|=(t/M)I_M.

This proves (3). All lengths and starts are given by integer/rational
arithmetic; square-root amplitudes are exact algebraic data, not learned
probabilities or free finite-bit gates. QED.

The selected K satisfies M/t=b/K<=K-1. Also K<=ceil(sqrt(b))+1<b for
b>=5, so t<M. Hence the lemma applies to the parameters in section 1.

## 3. The enlarged expectations and why their compression is identical

Embed R from (4) into the C-system sector tensor ancilla. Put

    W1=(P union Q) tensor I_K + R,
    W0=C tensor I_K-R.

These are orthogonal projections. W1 has rank

    (2r-1)K+t=r^2 K,

and W0 has rank r^2(r-1)K. The table of P tensor I_K and Q tensor I_K inside
W1 has the exact joint ranks

    [[K,(r-1)K],[(r-1)K,(r-1)^2 K]].

Thus the events are trace-independent within W1. Let F be the trace
expectation onto the blocks P tensor I_K, W1-P tensor I_K, W0. Let G use Q
in place of P. They commute exactly and their product is

    H(X)=Tr(W1 X)/(r^2 K) W1
          +Tr(W0 X)/(r^2(r-1)K) W0.                    (5)

This follows by the same independent table calculation as in W61; it does
not require W1 to be diagonal in the physical product basis.

To calculate compression without assuming off-diagonal matrix units vanish,
put alpha=t/(MK)=(r-1)^2/M=(r-1)/K0 and use (3). For arbitrary X in M_N,

    Tr[(W1-P tensor I_K)(X tensor I_K/K)]
         =Tr(BX)+alpha Tr(CX),
    Tr[W0(X tensor I_K/K)]=(1-alpha)Tr(CX).

The normalized block output marginals are respectively

    U_P=P/r,
    beta=B/[r(r-1)]+C/(r K0),
    U_C=C/M.

Consequently the compressed F is exactly

    T_F(X)=Tr(PX) U_P
          +[Tr(BX)+alpha Tr(CX)] beta
          +(1-alpha)Tr(CX) U_C.                        (6)

The analogous formula exchanges A and B for G. These are identical to W61's
frozen recovered hot channels, despite the much smaller K. Equation (6)
kills all off-diagonal system matrix units and has diagonal output. Its
unhalved diamond distance is the maximum l1 column difference from the
target transition matrix. The maximum is attained on a B input and equals
2/(r+1); C inputs give 2/[(r+1)K0]. This proves (1), including references.

The compressed H likewise depends only on the flat partial trace and is
identical to W61's T_H. Its distance to scalar depolarization is
2(2r-1)(r-1)/r^3. Original alternating words of length>=2 are within
2(r-1)/r^2 of scalar depolarization. Idempotency and FG=GF=H then prove (2).

For the common original input u, H(|u><u| tensor I_K/K)=W1/(r^2 K).
Its entropy is log2(r^2 K), giving the stated retained relative entropy log2(r).

## 4. Lower bounds with exact architecture boundaries

Flat-marginal family. Any rank-t projection with (3) must satisfy

    M=rank(Tr_A R)<=K rank(R)=K t,

because partial trace of each rank-one term has rank at most K. With the
required t=(r-1)^2 K, this forces

    K>=ceil(sqrt(b)).                                    (7)

Our explicit choice is at most one larger. This is an essentially sharp
ancilla dimension within the flat-marginal projection construction. It is
not a lower bound for every possible hot dilation.

Broader same three-block architecture. Suppose W1 contains P tensor I and
Q tensor I, W0 is its complement, and F/G use exactly the three blocks above.
Exact conditional independence inside W1 forces the additional C-sector
projection rank to be t=(r-1)^2 K. On a B input, F outputs the normalized
rank-r(r-1)K projector S=W1-P tensor I, supported in P-perpendicular tensor A.
Its system marginal has rank at most

    (r-1)+K t=(r-1)+(r-1)^2 K^2.

The target is uniform on L=N-r=r(r^2-1) dimensions. A state of rank at most
z differs from I_L/L in unhalved trace norm by at least 2(1-z/L), by measuring
its support. Therefore diamond error <=epsilon in this architecture requires

    (r-1)+(r-1)^2 K^2 >=(1-epsilon/2)L.                 (8)

At epsilon=2/(r+1), (8) gives K^2>=r+1. Thus the square-root scale is necessary
even without assuming an exactly flat marginal, within these same block and
support hypotheses.

For the physical-product-diagonal version of this architecture, the system
support of the C-sector projection has size at most t, so replace Kt by t
in (8). At the same target error this forces K>=r+1. This is consistent with
W61's separately communicated K=r+1 classical refinement. The quantum
construction changes this architecture's ancilla exponent from 1 to 1/2.
It does not establish an unrestricted classical-versus-quantum separation.

## 5. Disturbance and full resource accounting

The smaller ancilla does not become catalytic. On a B basis input the full
enlarged F output is S/[r(r-1)K], whereas the target with a returned decoupled
hot ancilla is (I-P) tensor I_K/[LK]. Since S is a subprojection of the latter
support, their exact trace-norm distance is

    2(1-r(r-1)/L)=2r/(r+1) ->2.                         (9)

This is a lower bound on the complete catalytic error. Ancilla-marginal
disturbance alone can undercount the retained system-ancilla correlations.
No claim about catalytic return follows merely from (1).

K=Theta(sqrt(r)) gives total Hilbert dimension NK=Theta(r^(7/2)) and
log2(K)=(1/2)log2(r)+O(1) ancilla storage bits. Preparation is maximally mixed;
initial entropy deficit is zero. The hidden central weight still vanishes.
The t sparse orthogonal vectors have at most K nonzero amplitudes each.
An explicit list costs O(tK)=O(r^3) coefficients; explicitly writing their
rank-one block projectors costs O(tK^2)=O(r^(7/2)) coefficients. A succinct
integer/rational interval rule costs O(log r) parameter bits.

The projection can be diagonalized by a direct sum of known vector-preparation
unitaries, one for each disjoint physical support. This gives a finite
compilation route, not an acquired efficient circuit. Coherent vector
preparation, block measurement, output sampling, precision, gate synthesis,
correlation erasure, reset, noise, time and energy are all charged. A uniform
finite-bit gate-cost theorem has not been supplied. W61's K=r+1 classical
refinement has simpler computational-basis sampling, a strong same-information
incumbent; the Hilbert-dimension reduction alone does not prove a net practical
advantage.

## 6. Decisive falsifiers and status

A failure of the interval support/orthogonality/flat-marginal identity, of
the full X compression (6), or of the rank lower bounds would falsify this
construction or its resource claims. An unrestricted smaller hot dilation
would not refute (7)/(8), whose architectural hypotheses are explicit.

The construction is a self-contained internal candidate. Historical priority,
independent correctness, useful physical realization, finite-bit compiler,
unrestricted optimal ancilla size and arbitrary-intervention simulation remain
UNKNOWN. Mission NOT_ACHIEVED.
