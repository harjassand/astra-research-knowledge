"""Independent finite diagnostics for root's analytic candidate, not its proof."""
import json, math, time
from pathlib import Path
import numpy as np

start=time.monotonic()
exact=0
for N in range(1,13):
    for m in (0,N,2*N):
        S=N+m
        for L in (S,4*S,4*S+1):
            for ell in range(L+1):
                upper=(L-ell)*(ell+1)*(S+ell) if ell<L else 0
                lower=(L-ell+1)*ell*(S+ell-1) if ell else 0
                assert upper-lower==L*S+(2*L-2*S+1)*ell-3*ell*ell
                exact+=1

rows=[]
for N in (2,4,8,16,32):
    for cap in (0,1,3):
        M=cap*N
        for m in sorted(set((0,M//2,M))):
            L=4*(N+M); S=N+m; lam=L/N; s=S/N
            ell=np.arange(L+1,dtype=float)
            lower=np.sqrt((L-ell[:-1])*(ell[:-1]+1)*(S+ell[:-1]))
            A=np.diag(lower,-1)
            X=(A+A.T)/(N*math.sqrt(L))
            H=1j*(A-A.T)/math.sqrt(L)
            eigen,vectors=np.linalg.eigh(H)
            psi0=np.zeros(L+1);psi0[0]=1
            p=lambda y:2*s+4*(1-s/lam)*y-6*y*y/lam
            # Independent explicit classical RK4, used for diagnostics only.
            z=np.zeros(2); classical={}; dt=1/8192
            for step in range(1,8193):
                rhs=lambda w:np.array((w[1],p(w[0])))
                k1=rhs(z);k2=rhs(z+dt*k1/2);k3=rhs(z+dt*k2/2);k4=rhs(z+dt*k3)
                z+=dt*(k1+2*k2+2*k3+k4)/6
                if step in (2048,4096,8192):classical[step/8192]=z.copy()
            for tau in (0.25,0.5,1.0):
                psi=vectors@(np.exp(-1j*tau*eigen)*vectors[0,:].conj())
                y,x=classical[tau]
                yerr=(ell/N-y)*psi
                xerr=X@psi-x*psi
                error=float(np.vdot(yerr,yerr).real+np.vdot(xerr,xerr).real)
                bound=math.exp(12*tau)*(s/N+4*tau/N**2)
                norm=float(np.vdot(psi,psi).real)
                assert abs(norm-1)<1e-9,(N,m,tau,norm)
                assert error<=bound+1e-8,(N,m,tau,error,bound)
                prob=float(np.sum(np.abs(psi[2*np.arange(L+1)<S])**2))
                if tau==1:
                    assert y>=3*s/4-1e-10
                    assert prob<=16*math.exp(12)*(1/N+4/N**2)+1e-8
                rows.append(dict(N=N,m=m,M=M,L=L,tau=tau,mean_y=float(np.sum(ell/N*np.abs(psi)**2)),classical_y=float(y),state_l2_error=error,analytic_bound=bound,prob_below_half_S=prob))

out={'kind':'FINITE_DIAGNOSTICS_NOT_UNIVERSAL_PROOF','exact_integer_commutator_checks':exact,'quantum_ode_cases':len(rows),'seconds':time.monotonic()-start,'rows':rows}
Path('work/root/LINEAR_PUMP_DIAGNOSTICS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='rows'}))
print(json.dumps([r for r in rows if r['m']==0 and r['M']==0 and r['tau']==1]))
