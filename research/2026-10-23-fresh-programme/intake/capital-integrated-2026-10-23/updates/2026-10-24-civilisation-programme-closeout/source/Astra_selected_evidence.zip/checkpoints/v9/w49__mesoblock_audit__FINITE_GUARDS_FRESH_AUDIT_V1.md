# Fresh audit of the finite mesoblock guard sidecar

23 October 2026, W49. Exact reviewed files, read in full:

- W67 `FINITE_ENCODER_GUARDS.md`, SHA256
  `baea9fafb8a76d3cb6aba60712d67880f70276e11419001a179788a584750d23`.
- Its integer/Fraction producer `certify_encoder_guards.py`, SHA256
  `68b03eac28efe52742807ca3225efbcf40b2a64658523a811470d9ae963841bf`.
- Its frozen scalar receipt `ENCODER_FORWARD_GUARDS.json`, SHA256
  `0ec806a06b1a390aea4db247acbe9cedd1d964835ee5419b3c45b6a6fa27e5dc`.

All three are in W67's `high_design_audit/quadratic_source_frontier/`.
The preceding source `26c7092c...` and my ideal audit `df4eb8b0...`
remain immutable. This is a new, separate delta review.

**Verdict:** no blocking defect found in the sharper spectral window,
finite two-attempt sampler, selected scalar guards, actual-root source
tail bound, or forward padding/rate arithmetic. The sidecar repairs the
two finite-scope qualifications in my ideal audit. This remains a
CONDITIONAL finite mathematical interface, not an independently bound
native encoder/decoder compiler. In particular an ideal all-Good encoder
is an isometry; an approximate native circuit is a CPTP encoder close to
that isometry unless an additional exact clean-helper property is proved.
The source's separate final-native-binding qualification is essential.

## 1. Sharper window and a polynomial retained fraction

Let `rho_*=sigma M_*`, `[sigma,M_*]=0`, `M_*>=I/2`, and
`Tr sigma M_*=1`. Put `c=1/25600` and `L=sum ln M_*` on t supplied
independent source blocks. Direct trace identities give

    E_rho exp(L)=(Tr sigma M_*^2)^t <= (1+c)^t,
    E_rho exp(-L)=(Tr sigma I)^t=1.

Markov therefore gives the two claimed tails, without a Gaussian or an
unknown eigenbasis assumption. For `w=ceil(2ct)+1`, the omitted smooth-bin
mass is bounded by `Pr(|L|>w-1)` and hence by `2e exp(-ct)` as stated
(a smaller constant is available). If `ct>=B0+4`, use `e>2`, `e<4` to
obtain strictly less than `2^(-B0)/2`.

The exact identity from the ideal proof is

    p_(q,j)=sigma_q exp(j+1) D_q mu_(q,j).

Since `sigma_q D_q<=2` and `j<=w`, a retained cell with `p>=p_min`
has `mu>=p_min exp[-(w+1)]/2`. The dyadic bound G2 follows from `e<4`:

    mu >= 2^[-Bp-2w-3].

For fixed supplied source constants, `t=O(log k)`, `w=O(log k)` and
`Bmu=O(log k)`. Inverse mu is thus polynomial in k, with a potentially
very large fixed exponent. It is not logarithmic cost in inverse mu.

## 2. Table confidence, finite sampling and entropy loss

The retained-cell test at estimated probability `8p_min` is safe with
the stated much smaller additive error. Every retained ideal p is at
least `7p_min`, and every dropped ideal p is at most `9p_min`. Since
`B p_min<=eps/128`, the latter cells lose at most `9eps/128<eps/8`.
Together with the window and the allocated implementation confidence
budget this permits `P>=1-eps`.

A single batch of categorical `(q,j)` samples estimates ALL B cell
probabilities; it does not require B separate batches. Hoeffding and a
union bound yield the conservative G5 bound. The table confidence is
charged once. The algorithm may then reuse its classical table for all
mesoblocks. Its quantum samples come from supplied source-preparation
circuits independent of the logical message and the bath; no actual-bath
preparation or statistical acquisition was performed here.

The finite probability sampler can satisfy the required one-sided
normalization condition. Here is an explicit slack calculation. With
`a=eps p_min/128`, relative error in a retained p is at most `eps/896`.
Also `|P_est-P|/P <= eps^2/8192 <= eps/8192`, using `P>=1/2`.
Round the normalized estimates DOWN on a grid of step at most
`eps p_min/(128B)` and put the residual mass in one retained cell.
The extra relative weight is at most `eps/896`. Consequently

    w_i/(p_i/P)
      <= (1+eps/896)/(1-eps/8192)+eps/896 < 1+eps

for `0<eps<=1/4`. This leaves room for further finite-arithmetic
subbudgets. The source permits enlarging 128 if those subbudgets are
chosen differently. Exact rational normalization and finite dyadic CDF
sampling avoid an infinite source of classical random bits.

Choose the largest dyadic width below the lower interval endpoint at
22-bit safety. A log-mu interval of width at most one quarter bit gives
the displayed 24-bit width-loss allowance. The words 'at least 22 bits
below' should be implemented with this maximal dyadic choice, rather
than allowing an arbitrarily smaller K. The claimed G4 bounds then hold:

    K/D <= 2^-20 tau^2 mu,
    ell >= log2(D mu)-2B0-24,
    ell >= kt-Bp-2(w+1)-2B0-24.

The last inequality also follows directly from `q>=0`, the exact p
identity and `e<4`. It is uniform over retained cells, including cells
with small charge-parent ranks relative to the full ambient space.

The information lost through discarded mass and normalized-table
variation is at most `eps(4k+1)t<=tG/16`. The remaining information
overhead is bounded by

    ceil(log2 B)+2B0+32 <= tG/8.

The 32-bit allowance safely covers the 24-bit width loss, `2 log2 e`
and `-log2 P`. Thus the mean width under the ACTUAL finite estimated
cell law is at least `t(1.5k+13G/16)`, stronger than the needed
`t(1.5k+3G/4)`. Hoeffding is therefore applied to the correct law.

## 3. Uniform frame guards and bounded width selection

The moment proof reviewed in `df4eb8b0...` is not replaced by dimensional
plausibility. The producer checks a uniform minimum rank and moment h.
To verify its rational replacements, use the lower Riemann sum

    ln 2 > 1/5+1/6+1/7+1/8 = 533/840 > 5/8.

Hence `c0=ln2-1/2>1/8`. Also `ln9<3`, since the first four terms of
`exp(3)` already exceed 9. Therefore `K/D<=1/128` implies

    2K ln9 < 6K <= 6D/128 < D/16 < c0 D/2.

If the checked lower log-rank implies `D>=16 denominator_rhs`, then
the other M8 denominator inequality follows because the displayed
base-two log upper bounds are larger than the corresponding natural
logs. The chosen `Bdes_inner` has additional slack, and `ell_min`
certifies `h<=K`. These are legitimate sufficient exact guards.

Let each independent width attempt fail with probability r at most
eta_w. For every accepted sequence x, its two-attempt probability is
`p(x)(1+r)`. The overall success probability is `1-r^2`, so conditional
on success its law is exactly `p(x)/(1-r)`, the original width-conditioned
law. Failure is at most `eta_w^2`. The finite cap therefore preserves
the ideal ensemble identity and bounds the worst-case seed length.
Generate the independent frames only AFTER choosing the width sequence.

Uniform conditional per-cell frame failure remains bounded by
`s eta_f`, even after the width event. There is no extra width-acceptance
denominator in this probability. In the GOOD-EVENT PSD expectation,
however, conditioning on width still costs `1/(1-eta_w)`, exactly as in
M16. Since `tau=zeta_p=eps`, `P>=1-eps`,

    ln F <= s[ln(1+eps)-2ln(1-eps)]-ln(1-eta_w)
         <= 5eps s+2eta_w.

The capped procedure's unnormalized success-indicator average is no
larger than the same bound. No repeated division by Good probabilities
has entered the argument.

## 4. Actual-root Lyapunov and all forward calls

The source-body channel has independent port blocks in its comparison
state. Total-charge covariance makes `Phi^* exp(t_L Ldepth)` block
diagonal in depth. From a starting depth at least k, no exceptional
root-input call can occur in a k-call block (the bath may reach depth
zero just after its final call). There the depth increment is in `[-k,k]` and has mean
operator at most `-Kappa I`. The scalar spectral Taylor inequality gives

    exp(t_L Delta) <= 1+t_L Delta
                      +(t_L^2 k^2/2) exp(t_L k).

With `t_L=Kappa/(8k^2)`, the remainder is below `Kappa t_L/2`.
At depth below k the terminal depth is below 2k, giving the retained
inhomogeneous root term. Thus the source's full-root dual inequality
is valid; no free reset or iid-bath assumption was inserted.

Iteration from the vacuum gives

    E exp(t_L Ldepth) <= 1+2 exp(2kt_L)/(Kappa t_L)
                      <= 1+C_tail,
    C_tail=6/(Kappa t_L).

The GOOD-PROGRAM PSD domination, followed by the ordinary scalar
Markov bound, proves G8. Using base-two ceilings in its numerator is
conservative relative to the needed natural logarithms.

During zero-input flushes a non-root bath descends with probability
`a>=1/2` at each call. The U and I outputs have orthogonal port charge
until the root is reached; root-sector coherence stays at depth zero.
Hence the event that a depth at most H has not reached the root by n
calls is bounded by `Pr[Bin(n,a)<H]`. For
`n=16(H+Bq+4)`, its mean is at least `8(H+Bq+4)` and a Chernoff lower
tail is less than `2^-Bq`. The identical argument applies to the counted
initial zero prefix with depth promise A. Coherent initial tails and
root-sector/reference issues still use the explicitly retained receiver
contract; this audit does not silently replace that contract by a bath
reset. The selected rows assume the stated geometric initializer-tail
promise, not a uniform tail modulus for every normal state.

I independently recomputed `n_initial+n_body+n_flush`, the parent
floor, the Bq-bit outer sacrifice, and G10 in all three rows. All pass.
The Fourier row count uses the body plus terminal flush, after the
initialization prefix; its two-sector bound is below the chosen R.
The local encoder invocations inside the digital row are separately
counted and do not constitute hidden physical bath calls.

There is also a general termination proof, rather than only three
numerical examples. For fixed error/confidence, the positive s-linear
rate margin before padding is `7tG/16`. Since the target rate is less
than 2, the s-linear padding loss is at most

    1280 eps k^2/Kappa <= 1280 G/(2^30 k^4).

This is strictly smaller than `7tG/16`; all remaining costs grow only
as `O(log s)`. Doubling s therefore terminates. The roots of these
linear-versus-log inequalities admit polynomial upper bounds in k and
the displayed inverse errors/confidences. This establishes a conditional
polynomial family, although its constants and exponents are enormous.
Since `k<=1/(5b)`, G10's excess is at least `b/59520`. This is an
arithmetic consequence conditional on the complete compiler premises,
not a separately certified new achievable capacity coefficient.

## 5. Native limits of this review

The noncommuting functional-error qualification is correct. The
same-Hermitian-L phase-estimation estimate is a scalar spectral theorem
argument; it must not be used to infer operator Lipschitz regularity
of a merely Lipschitz filter. For a perturbed generator, Duhamel instead
gives the source's `|u| delta_L` simulation error. The positive-resolvent
formula proves `||log X-log Y||<=||X-Y||/m` when both are at least mI,
without a commutation assumption. These justify the stated precision
policy, conditional on the acquired operator-access primitives.

The filter coin has an absolute amplitude margin. With `u=x-j` in
`[-1,1]`, for `u<=1/2` its amplitude is at most `exp(-1/4)<4/5`;
for `u>=1/2` it is at most `cos(pi/4)<4/5`. Its complementary coin
therefore has a bounded derivative. This does not by itself implement
the complete controlled log/filter/polar unitary or clean its helpers.

I have not independently re-proved the imported native router, design
mixing step count, stable sign-phase construction, or universal decoder
implementation. Their displayed arithmetic counts were checked only
to the extent stated below. The outer row must repeat the ENTIRE actual
encoder, and full-unitary errors must telescope with those repetitions.
The sidecar correctly retains these as final binding obligations and
does not reuse the old quartic native envelope.

## 6. Independent receipt and scope

Own `check_finite_guards_independent.py` imports no peer code. It reads
the frozen scalar rows and independently recomputes the integer/Fraction
guards above, selected outer scalar budgets, table/grid counts, all
forward horizons and exact rate margins. It also checks elementary
constant certificates instead of relying on rounded transcendental
values. All three selected beta denominators 128, 512 and 2048 pass.
The Python runtime was about 0.0012 seconds; this is small arithmetic
verification, not generation of any huge code. Peak memory and total
inference cost were not measured. The raw receipt is
`FINITE_GUARDS_INDEPENDENT_CHECKS.json`.

Not acquired or executed: source tables, probability-sampling experiments,
giant charge ranks, good frame programs, encoder/decoder phases, native
circuits or physical communication. Novelty UNKNOWN; physical validation
NOT_PERFORMED; practical advantage NOT_ESTABLISHED; mission NOT_ACHIEVED.
The construction is still a candidate awaiting its final integrated
native/full-unitary/source-access binding.
