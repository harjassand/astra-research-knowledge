# One fixed quadratic-gain source across a factor-two interval in b

W67, 24 October 2026. NEW component theorem candidate, fresh review
pending. This is an actual mismatched-reference response calculation,
not the narrow-angle global-norm telescope. It leaves all earlier
source, encoder, finite-row and review bytes unchanged.

Let b0 be a known rational number with 0<b0<=1/16384, let

    k=floor(1/(5b0)), t0=v_k b0^2,

and build the unchanged V4 source at THIS reference b0. The actual
fixed unknown device parameter may be any

    b in [b0,2b0].                                      (U1)

Thus the band has factor two in b=beta^2, or sqrt(2) in beta. No actual
parameter label, receiver estimate or backward communication is used.
This theorem does not yet assert a factor-two band in beta.

The source can therefore be chosen at the public lower endpoint even
when Alice cannot acquire a narrow interval from forward-only probes.
The exact information-flow obstruction to THAT acquisition remains
valid; an estimate is unnecessary for this fixed-source construction.

## 1. Explicit inherited premises

These are the unchanged exact-source results, not assumed new lemmas.
The frozen V4 source proof is CAUSAL_CLIPPED_LOWER_V4.txt (b37eccac),
and its causal response proof is CAUSAL_PREFIX_RESPONSE_V4.txt (f1b3dadb),
both under W56's lower_construction directory. The original actual
all-coherence response is Cycle10 COMPLETE_PROOF.tex.txt (1759b20d),
Theorem 'Uniform all-coherence response', with its exact diagonal
identity and full root qualification. All concern the actual H_k with
its nonlocal spectator-colour action, not collective hopping.

For sigma=diag(1/2,1/4,1/4)^tensor k and A=Q-k/2, the source is

    X=-gamma b0 H, gamma=4/25,
    B=(I+X)_+, D=pin_COMPLETE_PATTERN(B)>=I,
    J=D^(-1/2), F=JBJ,
    delta=t0/18, T=I+(4delta/k)A,
    rho0=sigma T F.

V4 supplies k>=3276, 1/300<=t0<=1/200, nu=v_k/k^2>=3/25,
pin(F)=I, all factors commuting with Q and sigma, and

    u=||X||_(2,sigma)<12/1000,
    e=||F-I-X||_(2,sigma)<1/100000,
    eta=||T-I||=t0/9<=1/1800,
    S_2(rho0)>=3k/2+t0/31,
    Tr sigma(TF-I)^2 <=(257/10000)t0.                   (U2)

The source is normalized and positive at the REFERENCE. None of these
source estimates is applied with the unknown actual b substituted.

For every actual b in[0,1], on every bulk bath prefix of depth>=k,

    D_b(sigma)=0,
    D_b(sigma A)=a k I/2,
    D_b(sigma H)=ab F_k(b), a=1-b,
    F_k(b)>=v_k[1-(103/72)bk] I.                      (U3)

The last bound uses only nu>=3/25; its proof does not require bk<=1/5.
The exact all-coherence theorem, also at the ACTUAL b, gives

    ||D_b(sigma Y)-2a Tr(sigma A Y)I||
        <= L(bk)||Y-pin(Y)||_(2,sigma),
    L(r)=r exp(2r^2),                                 (U4)

for every Hermitian charge-preserving Y. It holds on the full bath
prefix operator space, including coherent/entangled colours. The root
is handled later by the unchanged Lyapunov argument, not deleted here.

## 2. Mismatched signed response remains inward

Write x=b/b0 in[1,2]. Since kb0<=1/5, (U3) gives

    b0*b*F_k(b) >= t0*x*(1-103x/360) I.

The concave quadratic h(x)=x-103x^2/360 has

    h(1)=257/360, h(2)=77/90>257/360.

It is therefore at least257/360 throughout[1,2]. The diagonal tilt
and offdiagonal H contribution in sigma(T+X) obey the exact bound

    D_b[sigma(T+X)]
      <=a t0[1/9-(4/25)*(257/360)] I
      =-(7a t0/2250) I.                              (U5)

This is why the source mismatch is much less costly than the global
2k^2|delta theta| telescope suggests: its useful perturbation couples
linearly to the ACTUAL b, while the positive diagonal tilt stays fixed.
The original coherent response, rather than a scalar selected-prefix
expectation, justifies the signed inequality.

## 3. The entire clipped-source correction is still paid

Let Yoff=T(F-I)-X. Complete-pattern pin(Yoff)=0, so its diagonal charge
term in (U4) vanishes exactly. The reference source estimates imply

    ||Yoff||_(2,sigma) <=(1+eta)e+eta*u,
    ||Yoff||_(2,sigma)/t0
        <(1+1/1800)*(1/100000)*300+(12/1000)/9
        =867/200000.                                (U6)

At every actual parameter in(U1), r=bk<=2/5. Since exp(y)<=1/(1-y)
for0<=y<1, the ACTUAL all-coherence constant obeys

    L(r)<= (2/5)/(1-8/25)=10/17.                     (U7)

Also a>=1-2/16384=8191/8192. Combining(U5)--(U7) yields the full
operator inequality

    D_b(rho0) <= -t0*C I,
    C=(8191/8192)*(7/2250)-(10/17)*(867/200000)
      =51677/92160000 > 1/1800.                     (U8)

No positivity of individual spectator coefficients is assumed. No
measurement/reset or iid replacement is introduced during a k-call
source block. The input is the same rho0 for every b in the band.

## 4. Fixed half-regularized source and coding interface

Set rho_*=(rho0+sigma)/2, exactly as in the mesoblock encoder. Entropy
concavity, the zero drift of sigma and(U2),(U8) give SIMULTANEOUSLY
for all actual b in(U1)

    S_2(rho_*)>=3k/2+G, G=1/18600,
    D_b(rho_*)<=-Kappa_band I,
          Kappa_band=1/1080000,
    Tr sigma(M_*-I)^2<=1/25600, M_*=sigma^(-1)rho_*>=I/2,
    [rho_*,Q]=0.                                    (U9)

The inverse sigma here is only a defining expression for the analytic
relative operator. Its explicit acquired source/log block construction
does not query that inverse or a full source eigenbasis. The entropy,
relative-density operator, table and all inner coordinates are those of
the known reference b0, exactly as before.

All code/source-average tail inequalities can therefore use
Kappa_band uniformly. A COMMON parent random program still needs a
continuum event: repeat the analysis grid/union policy of d5e04956 with
this larger interval and the weaker margin. The whole angular band has
length<1, so the SAME grid upper B_grid=Bq+B_R+5 is sufficient. No
parameter-grid evaluation or actual device query is part of construction.
The common Fourier error span then already covers every theta and both
static sectors. Full source-to-call, initializer and native/receiver
composition still require their separately specified guards/reviews.

If new rows retain the final target3/2+G/(16k), their excess is

    G/(16k)>=b0/59520>=b_actual/119040.               (U10)

This is a conditional quadratic excess with one fixed source/encoder
over a supplied broad location. The interval is not discovered from
the physical device. It differs fundamentally from selecting a source
after receiver-side calibration. Message duplication, time-sharing of
an unknown state, correlated calibration labels and feedback are absent.

## 5. Scope and falsifiers

The indispensable checks are the full-operator validity of(U3),(U4)
at mismatched b, the complete-pattern zero diagonal in(U6), and all
reference-only V4 constants. Substituting an ordinary hopping H,
discarding the root, or using a source-specific scalar expectation
would not establish this result. At x>2 this proof's present endpoint
and correction budgets need re-evaluation; it makes no broader claim.

This file is a new proof candidate. Rational arithmetic can certify its
displayed constants but does not independently certify its inherited
operator identities. Numerical code execution, new finite rows, native
compiler closure, physical validation and practical gain are not inferred.
Novelty UNKNOWN; physical NOT_PERFORMED; practical advantage
NOT_ESTABLISHED; mission NOT_ACHIEVED.
