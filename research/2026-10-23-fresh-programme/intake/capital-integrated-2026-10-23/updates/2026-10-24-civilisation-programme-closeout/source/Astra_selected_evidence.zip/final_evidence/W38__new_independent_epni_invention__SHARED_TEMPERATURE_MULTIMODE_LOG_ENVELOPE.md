# A shared hidden temperature across any fixed finite number of modes

24 October 2026, W38. NEW internal candidate; full fresh criticism PENDING.
This extends the pending smooth-envelope proof cbd968c5..., not its review
status. No result is imported from W69's explicitly undeveloped multimode
power-tail continuation. The kernels and all changed steps are derived
below. No general unheated or all-finite-energy EPnI claim is made.

## 1. Actual correlated sources and precise conclusion

Let a law R satisfy(S1)--(S2) of
SMOOTH_INTEGRABLE_LOG_ENVELOPE_HEAT_BRIDGE.md,
SHAcbd968c585a332e49547f9a74b3b1e014ce2b3d36f695dfb7c46c8b327646399,
with ell positive C2, eventually decreasing and integrable,

    f_R(r)=r^-2[ell(ln r)+O(ell(ln r)/(ln r)^2)],
    -ell'<=Kell/x, |ell''|<=Kell/x^2,
    M(x)=integral_x^infinity ell(u)du, a=ER<infinity.

Fix ANY finite positive integer n. The source is now

    rho_R^(n)=E[theta_R^tensor n].                    (M1)

It is generally NOT the tensor power of the averaged one-mode state.
All n modes share the same mathematical hidden R, so correlations within
each input group are allowed and retained. No R record is accessible.
Independent RA,RB at the two ports are still required. Apply ACTUAL
H_T^tensor n to each source group.

Let H_n=sum_(j=1)^n 1/j, psi_n=H_n-gamma_E. The candidate quantum defect is

    D(H_T^tensor n rho_R^(n)||theta_(T+a)^tensor n)
       =n/T{M(l)-ell(l)[ln l+1-psi_n]}+o(ell(l)/T),
    l=ln T.                                        (M2)

In particular the dimension-dependent constant is1-H_n+gamma_E, not
gamma_E for every n. For n1 it reduces exactly to cbd968c5....

For fixed G>1,lambda=G-1,s=2G-1,theta=G/s,phi=lambda/s, the exact output
on the independent correlated sources has entropy gap

    S_C-n g(G g^-1(S_A/n)+lambda[g^-1(S_B/n)+1])
      =n/T[-theta ell_A(l)ln theta-phi ell_B(l)ln phi]
                    +o((ell_A(l)+ell_B(l))/T)>0      (M3)

eventually for EACH fixed n,G and supplied source pair. The two envelopes
may differ or have nonconvergent ratio. No n->infinity or threshold
interchange is asserted. Correlations in(M1) are classical, not internal
quantum entanglement.

## 2. Native n-mode radial representation and normal channels

Write r=|alpha|^2 for the squared radius in C^n. Conditional on R, the
coherent amplitudes of theta_(t+R)^tensor n have independent complex
Gaussian coordinates, each variance t+R. The full radial density is

    h_t(r)=r^(n-1)/Gamma(n) E[(t+R)^(-n)exp(-r/(t+R))],
    q_t(r)=r^(n-1)/[Gamma(n)(t+a)^n]exp(-r/(t+a)).    (M4)

Both full phase-space distributions have the SAME uniform conditional
angular law. Consequently their full classical relative entropy equals
the radial relative entropy in(M4). Their conditional n-dimensional
Gaussian relative entropy, or equivalently gamma relative entropy, is
n[(t+R)/(t+a)-1-ln((t+R)/(t+a))]. Convexity therefore gives

    D_cl(h_t||q_t)<=n[ln(t+a)-E ln(t+R)]
                      <=n ln(1+a/t)<infinity.        (M5)

The normal coherent-state preparation channel maps these phase-space
distributions to the actual n-mode states. Heterodyne measurement adds
ONE noise unit to EVERY native mode, retaining their common temperature.
Thus the exact normal DPI sandwich is

    D_cl(h_(t+1)||q_(t+1))
       <=D(H_t^tensor n rho_R^(n)||theta_(t+a)^tensor n)
       <=D_cl(h_t||q_t).                             (M6)

No temperature flag, count observation or product-within-group hypothesis
is inserted. The exact quantum identity is
D=n g(t+a)-S(H_t^tensor n rho_R^(n)), since the reference logarithm is
affine in the TOTAL number operator and all means/entropies are finite.

## 3. The changed quadratic core and moving boundary

The one-mode tail consequences(S6)--(S9), including the full mean-tail
term and truncated second moment, concern R alone and are unchanged.
Rescaling r=ty gives the gamma kernel

    k_x(y)=y^(n-1)/[Gamma(n)(1+x)^n]exp[-y/(1+x)].

On 0<=x<=delta<1 its second derivative is bounded by
C_n y^(n-1)(1+y)^2exp(-cy),c=1/(1+delta)>1/2. The exact same centered
split at R=delta t therefore gives

    |H_t(y)-Q_t(y)|<=A_t(y)+B_t(y),
    A_t=C_n t^-1 M(l)y^(n-1)(1+y)^2exp(-cy),
    B_t=C_n t^-1 ell(l)y^(n-1)(1+y)^(-n-1).         (M7)

For B_t use ell(l+ln x)<=C_delta ell(l) for x>=delta. The remaining
positive integral is y^(n-1) integral_delta^infinity
x^(-n-2)exp(-c_delta y/x)dx. It is bounded by
C_n y^(n-1)(1+y)^(-n-1), using a direct bound at y<=1 and z=y/x at y>1.
Hence no near-zero singularity is introduced by dividing by the gamma
reference; all densities vanish like y^(n-1) there when n>1.

Choose, with n fixed,

    Y=l-ln ell(l)+(n+1)ln l, X=tY, x=ln X.         (M8)

Again Y=l+O_n(ln l), x=l+ln l+o(1), but the n+1 factor is essential.
Now exp(-Y)=t^-1 ell(l)l^(-n-1). Since
Q_t(y)>=c_n y^(n-1)exp(-y), the local Phi<=delta^2/q bound yields

    integral_0^Y Phi(H_t,Q_t)dy
       <=C_n t^-2 M(l)^2
         +C_n t^-2 ell(l)^2exp(Y)Y^(-n-3)
       =O_n(t^-2 M(l)^2)+O_n(ell(l)/(t l^2))
       =o(ell(l)/t).                               (M9)

The two reference-normalized integrands are respectively bounded by a
fixed polynomial times exp[-(2c-1)y], and by
C_n t^-2ell(l)^2 e^y y^(n-1)(1+y)^(-2n-2). Its large-y power is -n-3;
its near-zero power is n-1 and integrable. No global actual L2 norm is
asserted. The actual thermal chi-squared is infinite at every finite t,
since any native marginal has infinite every photon moment above one.

## 4. The entire remote heat-removal error remains smaller

Define h0 from(M4) using R in place of t+R and omitting a possible R0
point mass only for this far-density comparison. On r>=X, restriction
R in[r,2r] gives h_t,h0>=c_n r^-2ell(lnr). The gamma kernel is at most
C_n/t for t+R>=t and at most C_n/r when optimized over positive R.
The logarithm of the gamma reference adds only fixed multiples of
lnr,l to r/(t+a); because r/t>=lnr in this range, the Phi mean-value
argument is still bounded by

    C_n integral_X^infinity (r/t)|h_t-h0|dr.         (M10)

For R<=t/l^2, the heated gamma tail contributes
O_n(Y^n exp[-Y/(1+l^-2)])=O_n(ell(l)/(t l)). Its cold part is smaller by
exp(-Yl^2). The latter assertion also follows by optimizing its temperature
at t/l^2: for r>=X and fixed n, r exceeds n(t/l^2).

For t/l^2<R<=delta t, the probability remains O(t^-1l^2ell(l)); the
conditional weighted gamma tail is O_n(Y^nexp(-cY)). Their product is
o(ell(l)/t) for each fixed n.

For R>delta t, differentiate the gamma kernel in its temperature v:

    |partial_v[r^(n-1)v^-n exp(-r/v)/Gamma(n)]|
       <=C_n r^(n-1)v^(-n-1)(n+r/v)exp(-r/v).

Between R and R+t the temperatures are comparable. After multiplication
by f_R and integration, the substitution R=ru plus the physical-scale
comparison(S9) gives

    |h_t^large-h0^large|<=C_n t r^-3ell(lnr).

The u integral is u^(-n-3)(n+1/u)exp(-c/u) times an arbitrarily small
positive/negative power, and is integrable. Inserting this in(M10) gives
O_n(ell(l)/(t l)). Thus the complete remote replacement error is
o(ell(l)/t), just as in the one-mode argument.

## 5. Mellin constant and the full gamma-reference entropy

The positive substitution z=r/R now gives exactly

    h0(r)=1/[Gamma(n)r^2] integral_0^infinity
             z^n exp(-z)[ell(lnr-lnz)+E(lnr-lnz)]dz,

with the bounded-temperature contribution handled separately. As in the
one-mode proof, split z at r^-1/2 and r^1/2; use the C2 principal envelope
in the middle and positive kernel tails outside. The result is

    h0(r)=n r^-2[ell(v)-psi_n ell'(v)
                            +O_n(ell(v)/v^2)], v=lnr. (M11)

Indeed Gamma(n+1)/Gamma(n)=n and
Gamma'(n+1)/Gamma(n+1)=H_n-gamma_E=psi_n. Both follow from the ordinary
Gamma recurrence and its logarithmic derivative. Consequently

    I1=integral_X^infinity r h0(r)dr
       =n[M(x)+psi_n ell(x)]+O_n(ell(x)/x),
    I0=integral_X^infinity h0(r)dr ~n ell(x)/X,
    Ilog=integral_X^infinity h0(r)lnr dr ~n xell(x)/X. (M12)

The integrated error is bounded by nC integral_x^infinity ell(u)/u^2 du
<=nC ell(x)/x, and the growing shift x-l=lnl+o(1) obeys
M(x)=M(l)-ell(l)lnl+o(ell(l)). The uniform proof of that growing shift
is explicitly given in SMOOTH_LOG_ENVELOPE_GROWING_SHIFT_DETAIL.md.

The gamma reference logarithm is

    ln q_t=(n-1)lnr-n ln(t+a)-lnGamma(n)-r/(t+a).

Combining it with ln h0=-2lnr+lnell(lnr)+lnn+O_n(1/lnr), the exact far
Phi decomposition has the leading terms

    I1/(t+a)+n ln(t+a)I0-(n+1)Ilog.                 (M13)

The terms lnell, constants and -I0 are o(ell(l)/t) because I0 is of order
ell(l)/(t l) and |lnell(x)|=O(lnx). The integrated reference gamma tail
is O_n(Y^(n-1)e^-Y)=O_n(ell(l)/(t l^2)). From(M8),(M12),

    n l I0-(n+1)Ilog=-n ell(l)/t+o(ell(l)/t).

Replacing t+a by t has error O_n(M(l)/t^2)=o(ell(l)/t). Equations
(M9)--(M13) prove the FULL classical defect

    n/T{M(l)-ell(l)lnl+(psi_n-1)ell(l)}+o(ell(l)/T).

Its main term changes under T->T+1 by o(ell(l)/T) using the same bounded
M and polynomial lower bound for ell. The normal sandwich(M6) therefore
proves(M2) for the actual correlated n-mode quantum state.

## 6. Actual independent two-port output and cancellation

Conditional on RA,RB, each input is a product thermal n-mode state with
the SAME native temperatures in all coordinates. The amplifier acts on
corresponding coordinates; its conditional output is exactly

    theta_(sT+W)^tensor n,
    W=lambda+G RA+lambda RB.

Unconditioned averaging retains all native correlations. The convolution
and fixed-shift closure from cbd968c5... concerns only the temperature law
and is unchanged, giving ell_W(x)=Gell_A(x-lnG)+lambda ell_B(x-lnlambda)
and the corresponding exact principal tail integral M_W. Its full proof
and the permitted O(ell/x^2) density error are dependencies of this result;
no claim about a total O(1/r) fixed-shift error is introduced.

The entropy target n g(Gg^-1(S_A/n)+lambda[g^-1(S_B/n)+1]) has the SAME
two first entropy derivatives as the one-mode target, and a bounded
Hessian for each fixed n. The thermal reference gap is exactly zero.
All effective means lie between T and T+a_i; the total defects are
O_n(1/T) by(M5). Scalar Taylor errors are o((ell_A+ell_B)/T).

Apply(M2) to both inputs and W at sT. The M terms cancel as in Section8
of cbd968c5.... The constants1-psi_n are IDENTICAL for input and output
dimension n and also cancel. The finite envelope shifts leave precisely
the main coefficient in(M3). Its fixed positive coefficients bound it
below by a positive constant times n(ell_A+ell_B)/T, irrespective of the
ratio of the two envelopes. This proves the stated eventual positivity
within the new candidate's exact assumptions.

## 7. Source and resource boundary

The critical example ell_q(x)=1/[x(lnx)^q],q>1, remains valid and now has
TOTAL mean energy n/(q-1). It has a shared fluctuating temperature and
genuine intermode classical correlations, with no acquired common record.
It is not an iid tensor power of the one-mode averaged state. Its higher
photon moments and every finite-heat thermal chi-squared remain infinite.

The actual preprocessing adds nT photons to each group. Source covariance,
tail law, independence of the two groups, pump/control parameters and
exact heat are supplied. No entropy/tail acquisition, physical operation,
preparation precision, reset, affordable T or n-uniform control has been
demonstrated. These particular inputs have no internal entanglement; the
H_T channel at T>=1 is entanglement breaking. No entangled or arbitrary
finite-energy extension follows just by density or shared-temperature
notation. General unheated independent-input EPnI is NOT_ACHIEVED.

Full fresh review of BOTH the underlying envelope proof and the changed
gamma-kernel/constant steps is PENDING. Finite product closure, W69's
one-mode native receipt and existing numerical radial controls do not
independently validate this correlated multimode theorem. No new n-mode
quadrature is claimed. Classical Mellin/Gamma tools and normal channels
are established prior; exact historical priority remains UNKNOWN.
