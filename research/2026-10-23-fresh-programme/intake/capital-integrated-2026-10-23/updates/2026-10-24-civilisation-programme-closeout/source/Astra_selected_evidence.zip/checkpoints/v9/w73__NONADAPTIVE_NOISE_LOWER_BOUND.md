# Nonadaptive noisy forest acquisition: an action--energy obstruction

2026-10-23. Internal theorem candidate, not independently reviewed. It complements the adaptive upper bounds in checkpoints 2/3. No priority, experimental, or mission achievement claim is made.

## 1. Fixed contract and theorem

Let n>=4 be even, a>0, sigma>0. An unknown undirected positive weighted forest Laplacian L acts on the known labelled vertices {0,...,n-1}. Every nonzero edge weight lies in the fixed interval [a,3a]. An action chooses a full real input x_t and acquires all n coordinates of Lx_t+z_t. Every scalar z_ti is independent N(0,sigma^2). Preparations are exact for this lower bound; granting perfect preparations strengthens the learner.

A nonadaptive learner commits to all q input vectors before any response. It may randomize, use arbitrary real coordinates, acquire every output, and perform unbounded computation. Its design is independent of the unknown forest/weights. For every design in the support of its randomization impose the total per-vertex control-energy bound

    sum_{t=1}^q x_ti^2 <= B for each i.

The decoder is additionally told the two hub identities and the entire partition of leaves among those hubs AFTER all controls have been committed. It is not told any edge weight or whether the hubs are adjacent. This post-design information is free only as a strengthening in the lower bound; no such oracle is used by the upper-bound learner.

For 0<epsilon<1/2 set

    K = sqrt(2 ln(2(n-2)/epsilon)).

Theorem (candidate). If this learner decides whether the forest is connected with error at most delta on every promised input, where delta+epsilon<1/2, then necessarily

    q [K^2 + 8a^2 B/sigma^2] >= n (1-2delta-2epsilon)^2.       (1)

Consequently a nonadaptive support-acquisition learner must obey the same condition. With raw binary controls B<=q and fixed sigma/a, uniform constant-error acquisition needs q=Omega(sqrt(n)). With a matched total per-row budget B=O(log^2 n) and fixed sigma/a, it needs q=Omega(n/log^2 n). These are statements about complete actions, each returning n acquired scalars, not scalar-query counts.

The adaptive checkpoint-3 learner, under the same positive-forest/readout model, uses q=O((1+sigma^2/a^2)log^2(n/delta)) actual binary actions and B<=q, recovering full support with error <=delta for every fixed L. For constant sigma/a and delta, its polylogarithmic action/energy upper and (1) give an asymptotic separation from nonadaptive acquisition. Constants are unoptimized; no finite practical advantage follows automatically. A known topology supplied BEFORE controls would change this result and can remove the obstruction.

There is also a unit-total-row-energy separation with a specified inverse-logarithmic sensor noise, derived explicitly in Section 7. Both learners then have B=1, the same sensor sigma_n=Theta(a/log n), and the same weight interval [a,3a]. The adaptive learner uses O(log^2 n) complete actions; every nonadaptive learner requires Omega(n/log^2 n). This does not assert a fixed nonzero sensor noise result at B=1.

## 2. A two-star prior, initially allowing Gaussian leaf weights

First derive a more general unconditioned Gaussian experiment. Choose distinct ordered hub labels U,V uniformly. Partition the other n-2 vertices uniformly into A and C of equal size

    d=(n-2)/2.

Every leaf in A is attached only to U; every leaf in C only to V. The leaf weights are independent N(mu,tau^2), for a fixed mu and tau>0. These preliminary weights may be negative; they are an analytical auxiliary experiment, not a promised input. A binary parameter theta in {0,1} adds an edge U--V of weight a when theta=1. For theta=0 the graph has two components; for theta=1 it is a tree. Only this hub edge changes with theta. The hub/partition metadata M=(U,V,A,C) is given to the decoder after its nonadaptive controls are fixed, without revealing theta or the weights.

Fix a deterministic design and write the full temporal code of vertex i as

    s_i=(x_1i,...,x_qi) in R^q,  ||s_i||_2^2<=B.

For a leaf l in A put r_l=s_l-s_U. Its full acquired row is

    Y_l=w_l r_l+Z_l,  Z_l~N(0,sigma^2 I_q).

The distribution of every leaf response is identical under theta=0 and 1. Conditional on all leaf responses and M, standard completion of the square in this one-parameter Gaussian regression makes the weights independent Gaussian variables with posterior variances

    v_l=(tau^-2+||r_l||_2^2/sigma^2)^-1.

Posterior means depend on the leaf data, but are the same under both theta values. The hub-U row is

    Y_U=-sum_{l in A} w_l r_l + theta a(s_U-s_V)+Z_U.

Thus its conditional covariance and the difference of conditional means are

    Sigma_U=sigma^2 I_q+sum_{l in A} v_l r_l r_l^T,
    a(s_U-s_V).

The V-hub has the analogous covariance Sigma_V and opposite mean shift. Conditional hub rows are independent because they have disjoint leaf weights and independent hub noise. Leaf response distributions are common to the hypotheses, so the full-data relative entropy, conditional on M, is exactly

    D(P_1(.|M)||P_0(.|M))
       = (a^2/2) (s_U-s_V)^T
                       (Sigma_U^-1+Sigma_V^-1)(s_U-s_V).     (2)

The covariance depends on the design and M, but not the acquired leaf values. Equation (2) therefore already includes all information in the n q full scalar readouts. It has not discarded the leaves' acquired information before accounting for the nuisance.

## 3. The leave-one-out ridge leverage lemma

Lemma. Fix vectors r_1,...,r_N in R^q with ||r_i||^2<=R^2 and lambda>0. Pick an index j uniformly and a d-element subset A uniformly from the remaining N-1 indices. Then

    E[r_j^T(lambda I+sum_{l in A}r_l r_l^T)^-1 r_j]
       <= (1+R^2/lambda) q/(d+1).                           (3)

Proof. Equivalently choose a uniformly random (d+1)-element set T and then j uniformly from T, with A=T\{j}. For this fixed T let

    G=lambda I+sum_{l in T}r_l r_l^T,
    h_j=r_j^T G^-1 r_j,
    t_j=r_j^T(lambda I+sum_{l in T\{j}}r_l r_l^T)^-1 r_j.

Sherman--Morrison gives t_j=h_j/(1-h_j), with h_j<1. The positive ridge gives t_j<=R^2/lambda and therefore

    t_j=h_j(1+t_j)<=(1+R^2/lambda)h_j.

Also

    sum_{j in T}h_j
      =tr[G^-1 sum_{j in T}r_jr_j^T]
      =tr[I-lambda G^-1] <=q.

Averaging the preceding inequality over the uniform j in T, and then T, proves (3). This lemma uses no random distribution, generic position, or incoherence for the fixed vectors.

## 4. Average the nuisance-information bound over hidden labels

Since every ||s_i||^2<=B, ||s_l-s_U||^2<=4B. Consequently

    v_l >= v_*=(tau^-2+4B/sigma^2)^-1.

Write lambda=sigma^2/v_*. Positive semidefinite order and inversion give

    (s_V-s_U)^T Sigma_U^-1 (s_V-s_U)
       <= (1/v_*) (s_V-s_U)^T
             (lambda I+sum_{l in A}(s_l-s_U)(s_l-s_U)^T)^-1
             (s_V-s_U).

Conditional on U, V is uniform among n-1 remaining labels and A is a uniform d-subset excluding U,V. Apply (3) to the fixed cloud {s_i-s_U:i!=U}, with R^2=4B. Since d+1=n/2,

    E[(s_V-s_U)^T Sigma_U^-1(s_V-s_U)]
       <= (1/v_*+4B/sigma^2) q/(d+1)
       = (tau^-2+8B/sigma^2) (2q/n).                       (4)

The symmetric bound holds at V. Including the freely revealed metadata, whose distribution is identical under both theta values, the entropy chain rule and (2)--(4) give

    D(P_1||P_0) <= (2a^2 q/n)(tau^-2+8B/sigma^2).          (5)

This is uniform over every fixed nonadaptive design obeying the row budgets. For a randomized design, include the independent design seed/code in the transcript and average (5) conditional on that seed. The same bound holds. Designs with fewer than q committed actions can be padded with zero controls; padding adds only independent uninformative sensor noise.

The random hidden hub/partition prior is selected independently of the design. No adversary selects weights or topology after seeing the design. This independence is essential to the quantifier.

## 5. Restore positive weights in a constant interval

Now set

    mu=2a,  tau=a/K,
    K=sqrt(2 ln(2(n-2)/epsilon)).

Write each leaf weight w_l=2a+(a/K)G_l with G_l standard Gaussian. Let E be the event |G_l|<=K for all n-2 leaves. The elementary Gaussian tail bound and a union bound imply

    P[E^c] <=2(n-2) exp(-K^2/2)=epsilon.

Conditional on E all leaf weights lie in [a,3a]; the optional hub edge has weight a. Both hypotheses are therefore supported entirely on the promised positive weighted forests with fixed dynamic range 3a. The conditional prior is still drawn before and independently of design randomization.

For each theta, the total variation distance between the auxiliary Gaussian prior and its conditioning on E is P[E^c]<=epsilon. Applying any fixed acquisition policy and adding noise cannot increase total variation. Let P_theta^+ denote the promised conditional transcript law, including the post-design metadata. Then

    TV(P_theta^+,P_theta)<=epsilon.

Pinsker's inequality applied to (5) gives

    TV(P_1^+,P_0^+)
       <= sqrt(D(P_1||P_0)/2)+2epsilon
       <= sqrt[(q/n)(K^2+8a^2B/sigma^2)]+2epsilon.           (6)

A binary test with average error at most delta needs total variation at least 1-2delta, since its optimal equal-prior error is (1-TV)/2. A learner with error <=delta on every fixed positive forest in [a,3a] also has average error <=delta under this conditional prior. Combining this fact with (6) proves (1).

This transfer conditions the input prior, not the acquired Gaussian sensor errors. It does not turn the sensor model into an artificially bounded-noise model. It also does not use a differential-entropy formula for noiseless data. The auxiliary signed Gaussian-weight experiment is removed rigorously by a prior total-variation bound before the positive-forest lower is asserted.

## 6. Exact comparison and outstanding obligations

For fixed a/sigma, fixed delta, and fixed epsilon, K^2=Theta(log n). With raw binary inputs B<=q, (1) implies q(log n+cq)>=c' n, hence q=Omega(sqrt n). More generally, for B=O(log^2 n), it implies q=Omega(n/log^2 n). The adaptive direct-noise construction uses q,B=O(log^2 n), outputs all support rather than only connectivity, and charges n q readout scalars. Thus this comparison uses the same weight floor/range, same independent sensor noise, same full vertex controls/readouts, and matched allowed per-row energy order. It does not compare a scalar cross-query with a full n-output action.

Known hub/partition metadata BEFORE the controls would allow a one-action hub test: hold one star at zero and the other at one. The lower explicitly permits this information only after the controls are fixed. The adaptive upper earns its partition from acquired data before changing the controls. Exact/noiseless graph sketches and bounded-rational-height lifting are different contracts; (1) has no sigma=0 conclusion and uses continuous nuisance weights.

This proof candidate needs an independent reconstruction of: the conditional posterior experiment; the leave-one-out sampling equivalence; the factor in (5); input-prior conditioning independent of design; and the same-contract adaptive comparison. Numerical checks can diagnose implementation errors but do not prove the all-design lower. Priority against noisy matrix sensing, graph acquisition, and adaptive sensing literature is UNKNOWN. Physical validation: NOT_ACQUIRED. Practical advantage: UNKNOWN. Mission achievement: NOT_ACHIEVED.

## 7. Explicit matched unit-energy corollary

Fix delta in (0,1/2), with epsilon chosen so delta+epsilon<1/2. Use the upper theorem with

    T=ceil(8 ln(4n/delta)),
    ell=ceil(8 ln(8n^2/delta)),
    Lambda=ln(16 n T (n+1)/delta),
    Q=2ell T,  c=ceil(sqrt(Q)),
    sigma_n=a sqrt(ell)/(32c sqrt(Lambda)).

Actually prepare each of the Q mass/code controls divided by c, and let each acquired scalar have independent Gaussian standard deviation sigma_n. Undo the known factor c on the responses. The rescaled noise has variance proxy

    sigma_raw^2=c^2 sigma_n^2=a^2 ell/(1024 Lambda).

Consequently the noise condition in DIRECT_STOCHASTIC_NOISE_PROOF.md is satisfied with equality, while its code condition is met by construction. Every full control row has squared energy at most Q/c^2<=1. The Q=O(log^2(n/delta)) actual actions already include all mass repetitions; no additional measurements or energy are hidden in the normalization.

For fixed delta, sigma_n=Theta(a/log n). A nonadaptive learner with the same n,a,sigma_n, error tolerance delta, and budget B=1 must, by (1), use

    q_nonadaptive >= n(1-2delta-2epsilon)^2
                     / [K^2+8192 c^2 Lambda/ell]
                   = Omega(n/log^2 n).

Thus the comparison has the same full n-output interface, total row energy, physical scalar noise, and continuous edge-weight range. The improved ratio is a mathematical adaptivity separation in acquisition, not an uncharged precision comparison. It leaves finite input-control accuracy, dynamic range, reset/time cost, and practical constants as separate instrument requirements. The current direct upper decoder has O(n^2 ell T) naive arithmetic; reducing that computation by an ordinary coding construction is an additional, separately charged task.
