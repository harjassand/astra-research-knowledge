"""Freeze W39's cold finite-port review; never edit target/prior packets."""
from pathlib import Path
import hashlib
import json

HERE=Path(__file__).resolve().parent
SPACE=HERE.parents[3]
TARGET=SPACE/'work/workers/w73_fresh_foundational_inventor/FINITE_PORT_IMPEDANCE_OBSTRUCTION.md'
MANUAL=SPACE/'work/workers/w73_fresh_foundational_inventor/sources/Keysight_N2820_97007_2025.pdf'


def bind(p):
    b=p.read_bytes()
    return {'path':str(p.relative_to(SPACE)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}


target=bind(TARGET);manual=bind(MANUAL)
assert target['sha256']=='2e8fe1f52d9c6fb77f78578efc303b0089a73e0937fd56c5d86f765fb2c9706b'
assert manual['sha256']=='0697359aae9412045163401860a1a36c464dc57e3a14a3f3a6131865a1800a30'
raw=json.loads((HERE/'COLD_FINITE_PORT_RESULTS.json').read_text())
assert raw['target_sha256']==target['sha256']
assert raw['checker_sha256']==bind(HERE/'check_cold_finite_ports.py')['sha256']

result={
    'worker':'w39_fresh_computation_invention','date':'2026-10-24',
    'status':'POSITIVE_COLD_FULL_PROOF_RECONSTRUCTION_WITHIN_EXPLICIT_PASSIVE_INSTRUMENT_MODEL',
    'target':target,
    'cold_provenance':'For this assignment only exact target and primary manual read before new derivation/controls. No finite-port producer replay/output/report, root argument or peer verdict used. Earlier ideal-action context retained at its own scope.',
    'model':'Known-background equal positive stars plus optional hub edge; exact external commands through known uniform series r>0; i=L(I+rL)^-1x; all n currents with fresh independent theta-invariant Gaussian variance sigma^2.',
    'adaptive_contract':'Commands chosen from common independent seed and prior full observations. Per-terminal sum_t x_ti^2<=B pathwise under either input; all finite q and arbitrary repeated history-dependent choices allowed.',
    'proved_bound':'B>=sigma^2(1-2delta)^2/[c^2||u||_2^2], c=a/(1+ra b^Tu), u=(I+rL0)^-1b.',
    'exact_norm':'||u||_1=2, ||u||_2^2=2[(1+ra)^2+d(ra)^2]/[1+ra(d+1)]^2.',
    'complete_process_reconstruction':['Exact KCL and nonsingular I+rL circuit law.',
        'Full n-port rank-one difference, explicit star columns and finite constants.',
        'Same-history conditional Gaussian KL and complete adaptive chain rule.',
        'Pathwise temporal-vector budget controlling all repetitions.',
        'Pinsker plus endpoint testing, without omitting readouts or computation.',
        'Known-background saturating one-command Gaussian sufficiency.',
        'Fixed-r Theta(d) budget law and variable-r_d necessary scaling.',
        'Separately charged time-weighted variance/duration model.',
        'Both separately stipulated feedback means/covariances, command/noise costs and common-mode exception.'],
    'known_background_sufficiency':'One x_i=sqrt(B)sign(u_i) command has equal endpoint error Phi[-c sqrt(B)||u||_2/sigma]; B=Theta(d) sufficient at fixed parameters. Not exact adaptive minimax formula or hidden-topology upper.',
    'scaling':'At fixed a,r,sigma,delta need B=Omega(d). If ar_d d is unbounded, fixed B,sigma/a fails along a subsequence. r_d=O(1/(ad)) removes this particular information loss; fixed r and B instead require sigma/a=O(d^-1/2).',
    'feedback_qualification':'Current/voltage ideal loops are different observation/control models. Raw hub noise precision O(1/d) statements hold for their stipulated independent-offset noise. Covariance can depend on theta, common-mode errors can cancel, same-action Gaussian commands need not satisfy finite passive pathwise B, and raw variance growth is not a universal information/controller lower bound.',
    'duration_scope':'Variance sigma0^2/tau with explicit time-weighted per-row cost E has same lower replacing B,sigma by E,sigma0. Stipulated averaging model, not measured noise/energy law.',
    'exact_controls':raw['exact'],
    'floating_controls':{'status':'SYNTHETIC_QUADRATURE_NOT_INTERVAL_CERTIFICATES',
        'complete_two_step_adaptive_policy_cases':len(raw['floating']['cases']),
        'maximum_KL_integral_error':raw['floating']['max_integral_error'],
        'maximum_refinement':raw['floating']['max_refinement']},
    'physical_instrument_context':{'manual':manual,'edition':'May2025',
        'pages_read':[2,47,48],
        'primary_url':'https://prc.keysight.com/Content/PDF_Files/N2820-97007.pdf',
        'retrieval':'Direct web PDF open timed out; retained primary PDF independently hashed and actual pages extracted with pypdf; official search also showed series-burden and alternate-head context.',
        'scope':'Some heads add series burden; another architecture does not add that head burden. No actual simultaneous n-port, independent-noise, settling or cost premise verified.'},
    'evidence':{'pre_diagnostic_derivation':bind(HERE/'COLD_PRE_DIAGNOSTIC_RECONSTRUCTION.md'),
        'report':bind(HERE/'REPORT.md'),'reconstruction':bind(HERE/'INDEPENDENT_RECONSTRUCTION.md'),
        'checker':bind(HERE/'check_cold_finite_ports.py'),'raw':bind(HERE/'COLD_FINITE_PORT_RESULTS.json')},
    'not_claimed':['Universal electronics impossibility or feedback no-go.',
        'Fixed-independent-noise ideal oracle restored by mean compensation.',
        'Measured noise laws, stable controller, device calibration or affordable precision.',
        'Rejection of the earlier ideal node-voltage mathematical theorem.'],
    'source_method_priority':'UNKNOWN; elementary circuit/rank-one/Gaussian-testing prior.',
    'actual_physical_acquisitions':0,'physical_validation':'NOT_PERFORMED',
    'practical_feasibility_or_advantage':'UNKNOWN','mission':'NOT_ACHIEVED',
    'critical_uncertainty':'Acquired full instrument noise/control/settling/cost laws for any proposed actual realization or alternative controller.',
    'next_decisive_action':'Root reviews the exact-model scope. Any positive physical proposal requires an independently acquired complete interface law before inheriting the ideal adaptivity advantage.',
    'earlier_compact_and_quantum_packet_bytes_preserved':True,'manifest':'MANIFEST.json'}
(HERE/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
names=['REPORT.md','INDEPENDENT_RECONSTRUCTION.md','COLD_PRE_DIAGNOSTIC_RECONSTRUCTION.md',
       'RESULT.json','check_cold_finite_ports.py','COLD_FINITE_PORT_RESULTS.json',Path(__file__).name]
manifest={'scope':'Frozen cold W39 finite-port review. Excludes this manifest itself; target/manual bytes read and bound, not edited.',
          'files':[bind(HERE/n) for n in names],'dependencies':[target,manual]}
(HERE/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
for n in names+['MANIFEST.json']:
    row=bind(HERE/n);print(row['sha256'],row['bytes'],n)

