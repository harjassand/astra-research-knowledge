# Fresh audit: direct linear-inventory and Poisson shared-pump receiver

Independent worker w50, 23 October 2026; no descendants. This audit began
with the exact root source files, before reading any complementary proof
or code. It imports no root/producer checker. Earlier frozen audits are
preserved; the old Duhamel approximation theorem is not a premise of this
new direct-concentration proof.

Reviewed snapshots:

* `ROOT_LINEAR_INVENTORY_TRILINEAR_CONCENTRATION_CANDIDATE.md`, SHA256
  `c7b73357575fc1ea48db93e38e613820d8a05ab892ca2de3a5ff9bbac04df1aa`.
* `ROOT_POISSON_PUMP_LINEAR_RESOURCE_CANDIDATE.md`, SHA256
  `7092642128f86257babdc0074ec59787b7c2ac33961df57bbe3b643c166de478`.

The exact common-pump chain is independently audited in the preceding
`trilinear_pump_audit/AUDIT.md`, SHA256
`296dac3b2d0f8dd2e9d8b64e27a7f4b7a26227c48ae4b592ac29404d1f6c86ac`.
The sector code, passive-reference lift and finite readout are independently
audited in `global_energy_audit/AUDIT.md`, SHA256
`a87669a2fa366ba45273fe218f85bd03d9f7f815915c6c6733e9071b61cd237e`,
with its separate follow-up `72a05659271255ab4e6a19ed0a65ea607f46a28a32c494b4afa9532527bd2cc4`.

## Verdict, precise scope, and completed receiver statement

PASS in the supplied equal-coupling lossless shared trilinear model.
The original exact-observable concentration proof is sound, and the
proposed Poisson source and finite receiver compose without an iid
actual-source premise, acceptance conditioning, or pump-number oracle.
The initial full pump resource is linear, not merely its depletion.
The proof is a direct number-concentration argument; it does not establish
closeness of the whole optical channel to an undepleted amplifier.

Here is the completed original conservative theorem, with no later
sharpening imported. Fix E>=0 and 0<r<ln(3/2). Put

    M=floor(EN), J=N+M, mu=6J,
    t=1/[chi sqrt(4J)], K=8J,
    T_N=16 exp(12sqrt2) [1/N+4sqrt2/N^2],
    B_N=2exp(-2J/7)+min(1,T_N)
                   +sqrt(3/2) exp[-N(ln(3/2)-r)/2].

Prepare A on its total-number cap, fresh B vacuum, and an independent
shared phase-randomized coherent pump with Poisson(mu) populations. Use
the SAME sector code for all allowed m and retained pair totals ell,
fixed target rank D_N=2^floor(Nr/ln2), with a fixed logical product default
on all other outcomes. Read D total only through K plus one overflow,
and C total only through M+K plus one overflow. The code exists for

    N >= max(2,ceil[ln(3/2)/(ln(3/2)-r)]).

A larger conservative startup threshold or all-default small blocks are
also valid. Then unconditional Bell failure obeys q_N<=min(1,B_N),
uniformly over all capped inputs and all their actual source extensions.
The actual whole output, including pump, unread seed/count purifiers,
old source and instrument remnants, satisfies half trace distance

    d(Omega,Phi_(D_N) tensor Omega_actual_residual)
          <=min(1,2sqrt(q_N)),

and the earlier separate rank-one improvement also gives
min(1,sqrt(q_N)+q_N). Thus fixed positive rate r<ln(3/2) has vanishing
unconditional actual-residual error. No success probability is divided
out, and no positive actual-source entanglement budget is assumed.

The same Bell-effect conclusion also holds for a supplied pure coherent
pump of mean mu, with arbitrary common optical phase. Section 5 proves
the required effect diagonality for the actual FINITE readout, including
its aggregated overflow. This is a receiver-specific extension, not an
equivalence of the coherent and dephased whole optical output states.

## 1. Exact observable identities and endpoints

In a source total-number sector m, write S=N+m, s=S/N, lambda=L/N.
Let A raise ell with coefficient sqrt[(L-ell)(ell+1)(S+ell)]. In rescaled
time tau=chi sqrt(L)t, the Hamiltonian is i(A-A*)/sqrt(L). On the exact
finite ladder 0..L define Y=ell/N and X=(A+A*)/(N sqrt(L)).

Using the zero missing coefficient at each endpoint,

    A*A-AA*=LS+(2L-2S+1)ell-3ell^2.

For example at ell=0 the value is LS, and at ell=L it is
-L(S+L-1); both agree with the actual one-sided action. The Heisenberg
commutators give

    Y'=X,
    X'=p(Y)+2Y/(lambda N),
    p(y)=2s+4(1-s/lambda)y-6y^2/lambda.

There is no factorization of quantum expectations, missing endpoint or
sign change. This calculation takes place entirely in a finite matrix
space; it has no unbounded-operator differentiation issue.

## 2. State-vector error inequality rather than moment closure

Let y'=x, x'=p(y), y(0)=x(0)=0. Suppose lambda>=4s. Before the upper
turn, integration gives

    x^2=4y(s+y)(1-y/lambda),
    y=s sinh^2 a, a'=sqrt[1-s sinh^2(a)/lambda].

The first turn requires a=asinh sqrt(lambda/s)>=asinh2. Since a'<=1,
its physical rescaled time is at least asinh2=1.4436...>sqrt2. Thus
y increases and lies in [0,lambda] through every tau in [0,sqrt2].
On this interval |p'(z)|<=9 for z in [0,lambda]. In particular the
scalar Lipschitz bound applies to p(Y)-p(y), by Y's spectral theorem;
it is not an operator Lipschitz assertion for two noncommuting operators.

For the initial ladder vector |0>, let a=Y(tau)-y and b=X(tau)-x, and
let e=||a|0>||^2+||b|0>||^2. Differentiating both squares produces the
actual anticommutators. Their expectations are bounded as follows:

    |<ab+ba>| <= e,
    |<b[p(Y)-p(y)]+[p(Y)-p(y)]b>| <=9e,
    |<bR+Rb>| <=4sqrt(e)/N <= e+4/N^2,
    R=2Y/(lambda N), ||R||<=2/N.

No product is silently commuted. Hence e'<=11e+4/N^2. Initially
Y|0>=0, <X>=0 and ||X|0>||^2=S/N^2=s/N, so e(0)=s/N. Gronwall gives
the stronger immediate estimate e<=exp(11tau)[s/N+4tau/N^2]; the root's
displayed exp(12tau) version is valid and is the only one needed here.

At tau=1, either y has reached s, or y<=s up to that time. In the latter
case a'>=sqrt(3)/2, so y(1)=s sinh^2 a(1)>=3s/4. Monotonicity extends
this lower bound through sqrt2. If the measured ell<S/2, then
|ell/N-y|>=s/4, so spectral Chebyshev gives

    Pr[ell<S/2 | m,L]
       <=16 exp(12tau) [1/(sN)+4tau/(s^2 N^2)]
       <=T_N,  1<=tau<=sqrt2.

Strict failure ell<S/2 has integer complement ell>=ceil(S/2).
This exact rounding is compatible with the sector-code threshold.
The inequality can be clipped at one. The root proof is valid even
though its deliberately conservative constants are quantitatively large.

## 3. The Poisson mixture needs no physical band measurement

Let L have Poisson mean mu=6J. Standard exponential-Markov bounds give
lower failure exponent at least J/3 for L<4J, and upper exponent at
least 2J/7 for L>8J. For example the multiplicative tail parameters
are delta=1/3, with mu delta^2/2=J/3 and
mu delta^2/(2+delta)=2J/7. Thus the root's sum

    p_bad<=2exp(-2J/7)

is sound, including the integer endpoints. The theoretical decomposition
over L is a trace calculation on a normal diagonal pump state. It does
not measure the pump, select a favorable number or renormalize it.

For every good integer L in [4J,8J] and every source sector m<=M,
lambda>=4S/N and the SAME physical time gives
tau_L=sqrt[L/(4J)] in [1,sqrt2]. The preceding concentration estimate
therefore holds uniformly. A bad-L branch costs at most its whole
probability, once. The source basis j is absent from the exact scalar
chain amplitudes; the state need not be a number mixture in j or m.

For a pure coherent pump, one must first prove the effect-diagonal
statement in Section 5 rather than treating a superposition as a mixture.
That proof justifies precisely the same scalar Poisson decomposition
for Bell failure, with no sqrt(p_bad) charge at this bounded-effect step.
The final full-output trace error still follows from rank-one projection.

## 4. Finite receiver, reference design and actual-purifier lift

The conditional optical map at fixed (m,ell) is exactly V_(m,ell), for
every L that permits ell. Its amplitude z_(S,L),ell is a scalar on the
entire native source space. Conditional on both optical counts, the
canonical known reference therefore gives exactly the old flat-sector
state, and the fixed GE instrument/decoder remains available. No ideal
NB law or undepleted-amplifier approximation is used to establish this.

Let R_m=binom(N+m-1,m) and C_(m,ell)=binom(N+m+ell-1,m+ell). If
ell>=ceil(S/2),

    C_(m,ell)/R_m
      =prod_(k=1)^(N-1)[1+ell/(m+k)] >=(3/2)^(N-1).

For the stated startup N, D_N<=C/R_m. The inherited dimension inequality
C<=R_m d_ell gives D_N<=d_ell, so every cyclic window of width D_N is
well defined. The Haar/flat-sector calculation and its chosen fixed
decoder give conditional canonical Bell failure at most

    sqrt[D_N R_m/C] <=sqrt(3/2)exp[-N(ln(3/2)-r)/2].

This is a bound on each retained good (m,ell) code, independent of L.
For all other outcomes the logical default is the SAME fixed product
state. We may safely bound its failure by one. No acceptance conditioning
is hidden here.

Read D total 0..K and one overflow, C total 0..M+K and one overflow.
Every physical component obeys Ctotal-Dtotal=m in [0,M]. Thus a C overflow
implies a D overflow, and on good L, ell<=L<=K prevents either overflow.
There are finitely many labels and finitely many code sectors. On bad L,
overflow or any other behavior is already charged by p_bad; do not add
another p_bad per count or sector. Invalid-count combinations outside
the exact supplied support can also use the same default.

Fresh independent matched passives commute with the collective pair
operator and preserve these counts. Averaging the receiver marginal
makes the Bell-failure input effect scalar on each irreducible source
H_m. Canonical reference calculations determine those scalar coefficients,
so their upper bound applies as a positive-operator inequality to every
actual capped source, including m coherences and arbitrary purifiers.
The canonical R_m reference is never identified with an actual source
purifier, pump environment or controller. The fixed physical instrument
and independent fresh seed are essential premises.

After this bounded Bell-probability argument, apply Bell projection to
the ACTUAL whole output. The good block is a rank-one Bell factor times
an actual residual state, and tracing the cross blocks in the Bell
factor gives the earlier sqrt(q)+q bound (or the original 2sqrt(q)).
Unmeasured/coherent flags and the pump remain in that residual. This
step does not require the full output to be an incoherent mixture over L.

## 5. Coherent pump, finite overflow, and the joint input effect

Consider a cross input |psi_m,L><phi_m',L'|. The exact interaction maps
its ket into components

    z_(N+m,L),ell V_(m,ell)|psi_m> tensor |L-ell>_P.

For each KEPT optical count the two recorded totals enforce ell=ell'
and m=m' in a Bell-effect trace. Subsequent code operations do not touch
the pump. Tracing final pump enforces L-ell=L'-ell, hence L=L'. Fresh
passive averaging then makes the source effect within each m scalar.

There is a potentially important finite-readout subtlety: overflow does
NOT record each ell>K. It has only one label. This causes no gap because
the overflow branch prepares a fixed logical product state independent
of all input degrees of freedom. Its Bell-failure effect is
f_default times the identity on the entire overflow input subspace,
which is already diagonal in optical ell. Thus this branch also kills
ell!=ell' in the bounded effect, without an imaginary infinite pointer
register. The same holds for any combined default subspace. Kept and
overflow branches are orthogonally recorded.

Consequently the full joint input Bell-failure effect is exactly

    F_(A,P)=sum_(m=0)^M sum_(L>=0)
                   f_(m,L) Pi_m tensor |L><L|,
    0<=f_(m,L)<=1.

On good L it is at most min(1,T_N+code_N), uniformly in m; on bad L it
is at most one. Therefore a supplied |alpha> pump has the same failure
as its Poisson dephasing, with arbitrary common phase, even though their
complete optical/pump output states can differ. The actual-residual
argument in Section 4 then applies to the coherent pump's OWN output.
No phase-randomization oracle is needed for that version.

In fact this effect formula proves the Bell-failure bound for arbitrary
joint source-pump correlations having the same pump number probabilities
and source cap, since conditional source states at each L are arbitrary
and the good-L bound is uniform in m. This is a mathematical extension,
not an assertion that such correlations are freely prepared; their joint
resource accounting needs its own ledger. Its independent derivation here
was formed before W42's later message reporting a related extension.

A chronology falsifier is explicit. With N=1, optical vacuum, initial
pump subspace |0>,|1>, interaction time a, and a Bell test of
(|0,0>+|1,1>)/sqrt2 BEFORE recording D number, the pulled-back effect is

    (1/2) [[1,sin(a)],[sin(a),1]].

Pump coherence matters there. Recording D number first gives I/2 instead.
Thus neither generic coherent-pump irrelevance nor a full optical-channel
identity follows from this receiver-specific proof.

## 6. Initial price, unbounded support, consumption and missing controls

For gamma_P,L=(1-q)q^L and Poisson(mu) diagonal populations,

    p_L/gamma_L = exp(-mu)/(1-q) * (mu/q)^L/L!,
    D_max <=mu(q^-1-1)-ln(1-q).

The supremum is at a Poisson-series mode; bounding it by the sum of all
positive terms proves the root's upper price. It is O(J) for fixed q.
This is not an equality with optimal preparation work or an acquired
coherent source. Ordinary pump energy is exactly hbar omega_P mu.
For a PURE coherent state, the weighted-vector criterion for
|alpha><alpha|<=c gamma gives the exact value

    D_max(|alpha><alpha| ||gamma)
       =ln <alpha|gamma^-1|alpha>
       =mu(q^-1-1)-ln(1-q).

The form-domain expectation is finite by its exponential series, so this
use of the infinite-dimensional Gibbs inverse is justified. The coherent
state's energy coherence is included in this price; it is not a free
controller resource. Pure and dephased inputs have distinct states and
ordinary entropies even when their Bell effect agrees.

At fixed E the pump's mean initial energy and max-Gibbs upper price are
linear in N. Its SUPPORT IS UNBOUNDED. This is not a deterministic photon
cap or a worst-case finite battery. The oscillator unitary is still well
defined by the direct sum of finite total-energy sectors, and bounded
effects on the normal input state are handled by convergent trace sums.

Exact conservation and ell<=L imply mean depletion<=mu=6J and mean active
optical photons<=M+12J. There is no deterministic photon cap on all
branches. Finite COUNT readouts and a finite number of code sectors do
not make old overflow oscillators finite-dimensional quantum memories.
Those actual modes and the pump remain retained residual systems. Any
strict finite Fock-level storage approximation needs an additional
tail/error certificate rather than being inferred from finite labels.

Pump marginal entropy is <=g(mu)=O(ln N) by the general thermal maximum-
entropy principle at bounded mean; its mutual information with the rest
is <=2S(P). No exact return, free catalyst, max-relative subtraction or
cyclic-work implementation is claimed. A vanishing fractional-depletion
premise is neither used nor established in this linear-inventory route.

The root's conservative K=8J gives O(N^2) code sectors, count labels
using O(ln N) bits, and sector Hilbert dimensions exp(O(N)) at fixed E.
The passive finite ensemble can have exp(O(N)) settings, with O(N) label
bits, but its weights and all code/decoder precision are separately
supplied/acquired tasks. The QND count instruments, complete mode storage,
collective equal coupling, common mode phase, timing t=Theta(N^-1/2),
source cap/fresh vacuum, pure degenerate receiver ancillas, controller
calibration, enormous general decoder, seed independence, reset and old
source disposal remain charged interfaces. The arbitrary original source
may have unbounded mean energy outside the active cap. Pump resource alone
is not the complete apparatus price.

For a physical bounded-effect certificate, the declared input must
include any source-correlated controller or its independence must be
supplied. Reduced optical calibration with an unmodeled correlated
apparatus does not establish this uniform instrument premise.

The original explicit T_N has leading constant
16exp(12sqrt2)=375,268,178.39.... A sufficient N from the original
2sqrt(q) bound for output error .01 has leading scale about 1.50e13
even before allocating code/tail error. The improved sqrt(q)+q version
still has leading scale about 3.83e12. These are conservative sufficient
estimates, not lower bounds or practical predictions. Every small-N
P4 tail bound in my finite diagnostics is vacuous after clipping at one.
Do not relabel those tests as a useful finite-block guarantee. Later
constant/rate improvements require their own reviewed proof.

## 7. Strong same-pump vacuum baseline

Keep the SAME pump state, mean 6(N+M), physical interaction time, shared
coupling and readout budget, but take known vacuum on A as well as B.
Now every conditional optical sector is exactly Phi_(d_ell),
d_ell=binom(N+ell-1,ell), independent of L; for a coherent pump its
conditional pump vector factors from this pure optical state. The same
uniform bound gives ell>=N/2 with probability 1-O(1/N)-p_bad.

Stirling at ell=ceil(N/2), and monotonicity in ell, show that every fixed
rate below

    g(1/2)=(3/2)ln(3/2)-(1/2)ln(1/2)=0.95477125...

is available by exact fixed-rank conversion on the sufficient-rank
sectors, with the same product default on all failures. This exceeds
ln(3/2)=0.40546510.... The conversion is a cyclic local window plus
conditional local isometry and works without divisibility assumptions.
Bell failure is bounded by the unconditional insufficient-rank/tail
probability, then the actual-residual lift applies to all records.

This conservative baseline already defeats a yield-advantage inference
from the unknown-input theorem. No old ideal NB law or rate g(G-1) is
imported into the linear-pump proof. A useful preservation task for the
unknown A input has not been established, and an explicit coherent
pump is a supplied active resource.

## 8. Independent finite diagnostics and countercontrols

`check_independent.py` gives 5,721 controls: 3,393 exact endpoint/polynomial
identities; 180 exact finite-chain matrix evolutions with state-error
comparisons; 64 Poisson band tails; 192 D_max upper-price comparisons;
1,888 exact sector-ratio thresholds; two complete actual instrument
fixtures; one no-count interference negative control; and one nontrivial
same-pump vacuum residual control. All pass. Universal validity comes
from the analytic arguments above, not these counts.

The matrix cases use N=1,2,4,8,16, S/N=1,2,3, L/S=4,6,8 and four times
through sqrt2. The actual state-error derivative is computed from finite
matrix vectors and the noncommuting anticommutators, not from factorized
moments. Ordinary RK4 scalar trajectories are diagnostics only; the
turning-time proof is analytic. Fractions verify the displayed algebra
and rank ratios exactly. Float/log comparisons are not interval proofs.

The actual instrument fixtures reuse ONLY my previously frozen independently
compiled N=3,m=1,ell=3,J=2 GE matrices, SHA256
`c2541780ca308130cf7a5759654dc9d32501e53a43d817efcf3867af73cc5e19`.
All other ell use a fixed product default. A finite pump superposition
L=0..9 with normalized truncated Poisson(4) populations is evolved at
the supplied fixed physical time; this is a mechanism fixture, not the
root's asymptotic Poisson(6J) source. One input is a product source/pump;
one has genuinely varying conditional source purifications correlated
with pump number. Both retain all pump, count, seed, outcome, remnant and
source-reference labels in a 4 by 31,680 pure-amplitude matrix.
`ACTUAL_PUMP_FIXTURES.npz` retains those exact numerical arrays and inputs.
Bell failure is 0.471476117592975 in both, matching the diagonal-pump
prediction within 2e-15. Actual whole-residual distance is about
0.7008606818047. Their general sqrt(q)+q upper bound is above one, so
these are interface controls, not small-error performance claims.

For a separate known-vacuum N=3 baseline, a normalized coherent-number
fixture truncated at L=80 from mean18 has omitted Poisson tail at most
2.821e-26 by Chernoff. Exact conversion on every ell>=1 to Phi_2, with
product default at ell=0, gives numerical failure 0.01505596499055 and
actual-residual distance 0.1294391543594, below sqrt(q)+q=0.1377587155325.
Its actual residual support is compressed only by an isometry for the
numerical spectral calculation; no fictitious product residual replaces
it. This known-state finite mechanism control is not a physically
acquired receiver or an arbitrary-source small-N theorem.

The one-pair no-count negative control has off-diagonal pump Bell-effect
entry sin(.37)/2=0.18080771598; actual D recording makes it zero. This
demonstrates why the pure coherent extension must use the real receiver
chronology and its fixed overflow default.

## 9. Primary boundaries and statuses

Full primary raw HTML/text and retrieval receipts are retained locally.
Focused web search logs include irrelevant hits; only the primary
sources actually read support the comparisons below.

* Florez et al. [1808.06136v1](https://arxiv.org/html/1808.06136v1),
  Section II Eqs(2)-(6), already supplies the familiar exact terminating
  quantized-pump chain. Full source bytes are pinned in the preceding
  pump checkpoint. This is established dynamics, not a new generic pump.
* Brif [quant-ph/9608022v1](https://arxiv.org/html/quant-ph/9608022v1),
  Section II Eqs(3)-(16), treats Manley--Rowe invariants, trilinear
  energy conservation, SU(1,1) representations, reference states and
  finite dynamical subspaces. Section VI also studies energy transfer.
* Gambini [Phys.Rev.A15,1157](https://journals.aps.org/pra/abstract/10.1103/PhysRevA.15.1157)
  (1977), publisher ABSTRACT ONLY acquired/read, already reduces nonlinear
  Heisenberg dynamics to a number-operator equation and studies means,
  variance and classical limits. Full text requires authorization and
  was not acquired; no exact theorem from behind that gate is claimed.
* Fleischhauer--Veits
  [quant-ph/9809089v1](https://arxiv.org/html/quant-ph/9809089v1), Sections
  II-III, explicitly distinguishes classical linearization from mean-field
  pump backaction, includes conservation and pendulum dynamics, and
  warns about quantum corrections. Their model is a degenerate subharmonic
  mode; its approximate moment closure is not substituted for the exact
  state-vector inequality reviewed here.
* Chinni--Quesada [2312.09239v2](https://arxiv.org/html/2312.09239v2)
  emphasizes coherent-pump depletion/entanglement beyond the parametric
  approximation. Earlier GE receipts retain the established passive
  symmetry, decoupling and channel-merging sources. Energy-preserving
  operations and athermal-store accounting have established thermal
  operation prior; neither energy conservation nor finite D_max acquires
  a cheap controller or pump factory.

Exact priority of the uniform evaluated composite receiver, external
validation, efficient control, physical implementation and net practical
value remain UNKNOWN or NOT ACQUIRED. There is no publication/outreach,
hardware operation or mission achievement. This receipt validates a
mathematical input-output guarantee within its exact supplied model.

After the reconstruction above, W30 reported a separately frozen stronger
concentration proof (06454d78...) and W42 reported separate composition/
Poisson receipts. I have not read those proof bodies in forming this
hash-specific verdict; their sharpened constants/rates are not counted
as reviewed by this receipt. A later separate comparison may be retained.

Falsifiers include unequal unmodeled couplings, an initial state outside
the declared cap/pump number-law class, source-dependent seed, failure
to use a fixed overflow default, a substituted ideal purifier, a hidden
infinite count record, a full optical approximation inferred from bounded
effects, or a practical advantage that fails the stronger same-pump
vacuum benchmark. The next decisive interfaces are sharper reviewed
finite-block constants and acquired/certified all-sector control, not a
broader success label.
