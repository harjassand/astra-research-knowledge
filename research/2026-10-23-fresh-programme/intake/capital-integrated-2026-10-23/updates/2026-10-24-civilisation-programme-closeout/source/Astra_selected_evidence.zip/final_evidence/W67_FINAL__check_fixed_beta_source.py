"""Exact scalar reconstruction for the NEW k=1/(10b0) source extension.

The changed temporal scale, tails, entropy and actual-parameter correction
are checked separately. Inherited bath operator theorems are not executed.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
WORKERS = HERE.parents[2]
PINS = {
    'CLIPPED_AFFINE_PROOF_V1.txt': 'd5e0c94470a8a080b4ea673196ddad0bf3f6d70804202ccb5014b1fff9a79ce2',
    'CAUSAL_CLIPPED_LOWER_V4.txt': 'b37eccacafa054db80a9f28f6903af0015b78f00a83c303048b8586994b6a0a6',
    'CAUSAL_PREFIX_RESPONSE_V4.txt': 'f1b3dadbc126b6996d3e86bdbc854c9bd40f143f00efaa905a1e9de6d56348a9',
}


def double_factorial(n):
    v = 1
    for j in range(n, 0, -2):
        v *= j
    return v


def main():
    pins = []
    for name, digest in PINS.items():
        path = WORKERS/'w56_fresh_quadratic_capacity_critic/lower_construction'/name
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        assert actual == digest
        pins.append({'name': name, 'sha256': actual})
    assert F(1, 10)-F(1, 65536) >= F(1, 12)
    assert 2*F(1, 5000) <= F(1, 50)**2
    assert (1-F(1, 5000)-F(1, 50))/8 > F(3, 25)
    tlo = F(3, 25)*F(1, 12)**2
    thi = F(1, 8)*F(1, 10)**2
    assert (tlo, thi) == (F(1, 1200), F(1, 800))
    gamma = F(4, 25)
    assert gamma**2*tlo > F(1, 250)**2
    assert gamma**2*thi < F(6, 1000)**2
    eta = thi/9
    assert eta == F(1, 7200)
    old_a20 = double_factorial(39)*F(4, 125)**20
    new_a20 = double_factorial(39)*F(2, 125)**20
    assert new_a20*2**20 == old_a20
    c = {j: F(j**j*(20-j)**(20-j), 20**20) for j in [1, 2, 4]}
    old_d0, old_n2, old_n4 = F(1, 10**8), F(9, 10**6), F(13, 10**4)
    assert c[1]*old_a20 < old_d0
    assert c[2]*old_a20/8 < old_n2**2
    assert c[4]*old_a20/8 < old_n4**4
    d0, n2, n4 = old_d0/2**20, old_n2/2**10, old_n4/2**5
    assert c[1]*new_a20 < d0
    assert c[2]*new_a20/8 < n2**2
    assert c[4]*new_a20/8 < n4**4
    eu = d0*F(6, 1000)+n2
    assert eu == F(460800003, 52428800000000000)
    assert eu < F(1, 10**8) and eu*250 < F(1, 800)
    vbound = ((1+eta)**2*gamma**2*(1+F(1, 800))**2
              +F(1, 800*81*6553))
    assert vbound < F(257, 10000)
    fourth = (1+eta)*(F(39, 20)*gamma+2*n4*12)+F(1, 270*80)
    assert fourth == F(270487957, 864000000)
    assert fourth < F(328, 1000)
    assert F(105, 8) < F(39, 20)**4
    assert F(257, 10000) < F(161, 1000)**2
    assert F(25, 3) < F(29, 10)**2
    dentropy = (F(257, 10000)/2
                +F(161, 1000)*F(328, 1000)**2*F(29, 10)/30
                +F(328, 1000)**4*F(25, 3)/75)/F(69, 100)
    assert dentropy == F(277917203, 12128906250)
    entropy_margin = F(1, 18)-dentropy-F(1, 31)
    assert entropy_margin == F(72166166, 187998046875) and entropy_margin > 0
    # h(1+3t), in the degree-two Bernstein basis on [0,1].
    a = F(103, 720)
    hbern = [1-a, 1-a+3*(1-2*a)/2, 4-16*a]
    assert min(hbern) == F(617, 720)
    mainmargin = gamma*min(hbern)-F(1, 9)
    assert mainmargin == F(13, 500)
    correction = (1+eta)*1200*F(1, 10**8)+F(6, 1000)/9
    assert correction == F(407201, 600000000)
    lbound = F(2, 5)/(1-2*F(2, 5)**2)
    assert lbound == F(10, 17)
    finalmargin = F(16383, 16384)*mainmargin-lbound*correction
    assert finalmargin == F(393203657, 15360000000)
    assert finalmargin > F(1, 40)
    gain, kappa, chi = tlo/62, tlo/80, F(257, 10000)*thi/4
    assert gain == F(1, 74400) and kappa == F(1, 96000)
    assert chi == F(257, 32000000) and chi < F(1, 100000)
    rows = []
    for den in [256, 1024, 4096]:
        b0 = F(1, den**2)
        k = den**2//10
        assert k >= 6553 and F(1, 12) <= k*b0 <= F(1, 10)
        assert 4*b0 <= F(1, 16384)
        assert gain/(16*k) >= 4*b0/F(476160)
        rows.append({'reference_beta_denominator': den, 'k': k,
                     'b0': b0, 'actual_b_upper': 4*b0,
                     'r0': k*b0, 'rate_excess_target': gain/(16*k)})
    data = {'status': 'PASS_EXACT_SCALAR_ONLY', 'scope': __doc__,
            'source_pins': pins, 't0_lower': tlo, 't0_upper': thi,
            'new_A20': new_a20, 'd0_upper': d0, 'N2_upper': n2,
            'N4_upper': n4, 'congruence_error_upper': eu,
            'variance_coefficient_upper': vbound,
            'fourth_ratio_upper': fourth, 'entropy_loss_coefficient': dentropy,
            'entropy_margin_above_1_over_31': entropy_margin,
            'response_bernstein_coefficients': hbern,
            'main_inward_coefficient': mainmargin,
            'correction_relative_upper': correction,
            'full_drift_coefficient_margin': finalmargin,
            'full_drift_slack_above_1_over_40': finalmargin-F(1, 40),
            'half_source_entropy_gain': gain, 'half_source_drift': kappa,
            'half_source_chi_sharp_upper': chi, 'rows': rows,
            'operator_proof_scope': 'INHERITED_NOT_REEXECUTED',
            'physical_status': 'NOT_PERFORMED', 'mission': 'NOT_ACHIEVED'}
    payload = json.dumps(data, default=lambda x: str(x) if isinstance(x, F) else x,
                         indent=2)+'\n'
    out = HERE/'FIXED_BETA_SOURCE_EXACT.json'
    if out.exists():
        assert out.read_text() == payload, 'refuse changed frozen output'
    else:
        out.write_text(payload)
    print(json.dumps({'status': data['status'], 'G': str(gain),
                      'kappa': str(kappa), 'drift_margin': str(finalmargin)}))


if __name__ == '__main__':
    main()
