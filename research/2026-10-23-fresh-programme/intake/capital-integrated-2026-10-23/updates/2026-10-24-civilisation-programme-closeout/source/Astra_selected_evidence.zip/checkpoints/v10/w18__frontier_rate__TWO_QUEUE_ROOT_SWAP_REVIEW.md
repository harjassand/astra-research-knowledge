# Frozen-source review of the two-queue swap lemma

24 October 2026, W18. **CONDITIONAL INTERNAL PASS of the mathematical
lemma, with a mandatory source-label qualification.** No all-copy or
original-capacity verdict follows. Novelty remains UNKNOWN.

Exact bytes personally read:
`work/root/TWO_QUEUE_SWAP_ENTROPY_LEMMA.md`, SHA256
`d9570730d4afe00236c1c9253a7d6de5feab93265cf52af8b70014e341ff978c`.
Before that read I independently reconstructed the three swap inequalities,
the five nonnegative weights, their sum and coordinates, the size-biased
convexity identity and the derivative of h. Root originated the proof.

For normalized complex u,v in C^D1 tensor C^D2, the expectations of the
commuting swaps F1,F2,F1F2 are a,b,c. Positivity of each displayed product
of I plus/minus a swap gives the stated inequalities. Nonnegative reduced
overlaps are essential in addition to Fourier positivity. With
t=max(0,(a+b+c-1)/2), each of a-t,b-t,c-t,t and 1-a-b-c+2t is nonnegative,
and these weights reconstruct the exact overlap triple. The relaxation's
unphysical vertices cause no problem because all five vertex entropy
remainders satisfy the desired inequality. Convexity of Z log Z gives
exactly the displayed size-biased bound, with the energy term linear.
The derivative h'(z)=-log(z)/(1+z)^2 and h>=0 justify the unequal-dimension
comparison. Aligned product vectors attain equality. I found no
load-bearing mathematical gap in this scope.

The sentence calling this the unchanged equal-D native model with r=2,
L=1 needs an addendum: the four clock entries g00,g10,g01,g11 describe two
clock choices {0,1} per one-site queue. In our core notation that is L=2
clock values and one uncertain site; the pinned native source has K in
{1,...,L}, so native L=1 is deterministic. Actual native K in {1,2} also
has an always-live prefix, which arbitrary u,v can entangle with the
uncertain sites. Removing that prefix is not justified by this lemma.
The mathematical result is a stripped-core bridge; the general known-
prefix version is a separate obligation. Root has been notified.

Independent checker `check_two_queue_swap_shadow.py` passes 4185 exact
rational admissions, 16740 nonnegative replica-sector weights, 12555
exact convex coordinate identities, 16740 numerical size-biased vertex
controls, and 120 arbitrary complex native vector pairs with 240 direct
replica-swap identities. The numerical checks are controls of a complete
analytic proof, not its replacement. Its separate eight exact Fourier
controls also establish that an all-r shadow-only extrapolation fails;
that nonphysical countermodel is not a defect in this two-queue theorem.

The new three-queue GHZ rank-one counterexample is stronger and separate:
it falsifies the proposed all-r constants h_L and c(1/D) for sufficiently
large D, while leaving this exact r=2 theorem intact. It does not disprove
an outcome-averaged converse or Delta=H+O_D(1). Mission NOT_ACHIEVED.
