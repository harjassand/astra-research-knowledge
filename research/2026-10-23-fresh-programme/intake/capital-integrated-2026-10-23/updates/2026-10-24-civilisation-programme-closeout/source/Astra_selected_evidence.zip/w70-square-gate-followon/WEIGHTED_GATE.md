# Signed threshold charge with offset and hysteresis cancellation

Internal construction plus manufacturer component evidence. No new circuit was assembled or measured. The older unweighted square-root-threshold version in `HARDWARE_CONSTRUCTION.md` remains an alternative; the construction here is the selected follow-on because it replaces tight comparator offset requirements with symmetric cycles and a residual error qualification.

## Central physical operation

For a held normalized strain voltage `x` in `[-1,1]`, choose an overrange `R>1`. Then

`x^2 = R^2 + integral_{-R}^{R} 2r 1{x>r} dr`.

A shared linear voltage sweep represents `r`. One comparator per member gates a signed current proportional to `r` into an integrating capacitor. Negative threshold intervals therefore contribute negative charge; positive intervals contribute positive charge. This is a real switched-current integrator, not a claim that an exponential deposition response magically becomes quadratic. The cell sees only the later slow current command; comparator switching stays outside the wet cell.

Let `sigma=+1,-1` reverse the electrical input before the comparator and let `tau=+1,-1` represent ascending/descending sweeps. For a constant comparator/input-stage offset `b` and stable directional hysteresis half-width `h`, the effective argument is `sigma x+b+tau h`, provided every trip lies inside the sweep range. Averaging the four charge results gives

`(1/4) sum_{sigma,tau} (sigma x+b+tau h)^2 = x^2+b^2+h^2`.

Matched zero-input sweeps measure `b^2+h^2`. Subtraction therefore gives **exactly `x^2` in this stationary ideal model**, even for offsets and hysteresis too large for the earlier unweighted threshold scheme. The result does not depend on knowing `b` or `h` numerically. The sweep must begin with the comparator saturated in the known state; starting inside a hysteresis window without reset invalidates the model.

Suggested interleaving is `+active/up, zero/up, -active/up, zero/up, +active/down, zero/down, -active/down, zero/down`, with matched sign reversal of the integrator contribution for zero phases. Initial states, settling intervals, hold, and capacitor reset are explicit phases. Eight sweeps is the minimum proposed frame here, before extra settling/reset time.

This cancels stationary *additive* electronic offsets. It does not cancel unknown sensor gain, strain-transfer error, bridge imbalance carried with the reversed signal, offset depending on common-mode or input sign, temperature changes between sweeps, hysteresis changing with rate/history, or arbitrary switch charge injection. A mechanical zero tare remains necessary. A shunt calibration does not acquire adhesive strain transfer. Common-mode and signal-polarity dependencies must be deliberately stressed during qualification.

## Finite implementation and a conservative uniform bound

With `M` equally spaced midpoint thresholds, `Delta=2R/M` and `r_k=-R+(k+1/2)Delta`, define

`Q_M(x)=R^2+Delta sum_k 2r_k 1{x>r_k}`.

This is exactly `x_hat^2`, where `x_hat` is the nearest endpoint of the threshold bin, up to the irrelevant tie convention. Thus

`|Q_M(x)-x^2| <= R Delta+Delta^2/4`.

Zero subtraction doubles this worst-case bound. For `R=1.1`, `M=1024`, it is `0.004728870391845704`. `weighted_gate.py` independently checks the midpoint-sum identity and obtains a maximum static offset/hysteresis grid error of `0.00213670586` across its stated finite grid. That smaller empirical grid maximum is not substituted for the analytic uniform bound.

If nonstationarity changes each effective argument by at most `rho`, and all arguments stay in range, an active-minus-zero pair adds at most `4R rho+2rho^2`. If normalized signed-weight current differs from the required weight by at most `delta_w` over a sweep, active-minus-zero integration contributes at most `8R delta_w`. Global DAC nonlinearity does not disappear merely because threshold and weight share a source: a nonuniform threshold coordinate has the wrong integration measure unless its dwell/weight is corrected. Actual thresholds, weight current and dwell must be included in this composite error qualification.

The complete *proposed qualification budget*, updated in `additional_calculations.json`, is:

| Term | Bound in normalized squared-strain units |
|---|---:|
| Finite threshold integration, including zero subtraction | 0.0047288704 |
| Residual input/threshold nonstationarity, `rho=0.001` | 0.004402 |
| Signed-weight nonlinearity, `delta_w=0.0002` | 0.00176 |
| Dwell/timing error | 0.0003 |
| Integrator scale/gain | 0.0012 |
| Reset, injection, leakage and hold | 0.0005 |
| Strain encoding, full-scale error 0.002 | 0.004004 |
| Load-ensemble average | 0.0005 |
| Mechanical-state uncertainty / geometry aging, expressed in the gate statistic | 0.002 |
| **Total** | **0.0193948704** |

Every non-quantization entry is an unacquired qualification target. Material actuation additionally requires sign preservation, zero-command stopping, a positive mobility bound and finite-step control; an arbitrary post-deadband dose bias is not an estimate error and is not covered by this table. The earlier `weighted_gate_results.json` example total of about 0.01563 omitted explicit weight, dwell, gain and reset allowances; it is preserved as an earlier calculation, not the final complete budget. At threshold `theta=0.25`, the corrected theorem certifies only `sqrt(y)` in approximately `[0.459576,0.537392]` for unconstrained stationary members. Exact optimization is not established. The objective bound is in `ROBUSTNESS_PROOF.md`.

The `0.0005` ensemble-average entry is realistic as a *target* only for a known, controlled finite teaching schedule with qualified force/timing weights, or an expensive acquisition. Under the earlier Hoeffding example (`N=100`, `K=100`, failure probability 0.01), an unknown iid distribution requires **29,017,316 independent samples/update** for that entry. At one independent sample per second this is about 335.85 days per update. At `eta=0.02` it still requires 18,136 samples/update (about 5.04 hours). Correlated service loads have no such certificate without an acquired dependence model. The selected manufacturing proposal therefore teaches a finite set of known loads rather than silently equating a short sweep with an unknown environmental distribution. A finite set is an acquired design objective, not proof of performance for every unobserved service load.

## Parts and a plausible, costly timing range

The [TLV3691 manufacturer datasheet](https://www.ti.com/lit/ds/symlink/tlv3691.pdf) specifies 75 nA typical supply current, large offset limits and internal hysteresis. The symmetric construction makes its stationary offset/hysteresis tolerable algebraically; its changing offset and near-threshold settling remain experimental requirements. The [DAC60501](https://www.ti.com/lit/ds/symlink/dac60501.pdf) gives a real 12-bit shared source with finite INL, settling and supply power. A [OPA333](https://www.ti.com/lit/ds/symlink/opa333.pdf) integrator is an available low-drift part, with 17 microampere typical supply current; it is already much more power than the comparator.

An illustrative `1 ms` threshold dwell gives `T=1.024 s` per sweep and `8.192 s` per eight-sweep frame. This is a proposed qualification rate, not a manufacturer-guaranteed bound at vanishing overdrive. With signed weight scale `I_w=10 microampere` and `C=10 microfarad`, one normalized sweep's scale is `I_w T/(4R C)=0.232727 V`. Summing four active-minus-zero results gives about `0.9309 V` per full-scale square. Properly centered intermediate states and output headroom must be checked. A 10-microfarad capacitor has `5 microjoule` stored at 1 V; reset discards/replaces this energy, besides amplifier/switch/control dissipation. Reset time, dielectric absorption and humidity-dependent leakage are precision costs. A small leakage specification for one switch does not bound a populated wet-fixture PCB.

Eight seconds is harmless relative to hours of plating only if load teaching can remain held and if geometry changes little during acquisition. For arbitrary time-varying strains, the deterministic sweep has the aliasing counterexample already retained in `ROBUSTNESS_PROOF.md`. The same load/time information and hold opportunity are given to the ordinary ADC incumbent.

Holding the computed analog command through hours of unloaded growth is a separate problem. The OPA333 sheet allows input bias up to 150 pA over its stated extended temperature range. Even that contribution alone changes a 10-microfarad capacitor by `I T/C`: about 0.45 mV in 30 seconds, 54 mV in one hour and 162 mV in three hours. Against a 0.9309 V four-pair scale, the one-hour value is about 0.058 of the gate statistic—well above the entire proposed 0.0005 reset/hold allowance. Board/switch/capacitor leakage adds to it. The proposed thin-dose process therefore needs a qualified short growth/hold step followed by re-teaching, a much larger qualified memory element, or digital latching of the completed command. None is free. Digital memory can be used in a hybrid, but then it is also given to the incumbent. A promise to hold the native capacitor for the source paper's three-hour plating cycle would invalidate the current error budget.

## Priority boundary

Time-domain multiplication, charge integration, sign reversal, automatic zeroing and explicit capacitor reset all have old primary prior. Their use here is not a new general physical operation. `PRIOR_AND_BASELINES.md` records the acquired early primary sources. The narrower strain-to-dose assembly and exact symmetric cancellation arrangement have UNKNOWN priority; an unsearched combination is not evidence of novelty.
