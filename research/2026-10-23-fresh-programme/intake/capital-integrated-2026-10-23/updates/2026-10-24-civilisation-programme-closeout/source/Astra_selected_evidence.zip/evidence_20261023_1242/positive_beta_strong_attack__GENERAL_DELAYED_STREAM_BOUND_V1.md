# Strong converse for fresh streams with sublinear decoding delay

23 October 2026, w19. Independent continuation after the separately frozen
fresh-block8424e4cb... and bounded-payloadf3ce4f1f... proofs. Partial
boundary groups remove their payload-cap premise; the ordinary equally
informed qutrit-wire bound strengthens the resulting polynomial bound to
an exponential one. Earlier frozen files remain unchanged. This is NOT
the unrestricted whole-source/deferred-decoder strong converse.

## 1. Contract and theorem

At beta in[0,1), use the exact supplied recurrent tree device V_beta,
with its same evolving bath and N prescribed qutrit calls. Arbitrary
normal initial bath--whole-laboratory entanglement, Alice--Bob preshares,
local normal TP controls and quantum backward communication are allowed.
No bath access/reset/replenishment or extra forward/timing/success wire
is supplied; all branches are counted without renormalization.

Immediately before call s, for s=0,...,N-1, a source of fixed finite
dimension K_s>=1 can arrive in a fresh pair Phi_(R_s M_s), independent of
the ENTIRE current resource. There is no advance access to future source
registers. Equivalently all pairs can be independently prepared at time0
and left completely untouched until their declared arrival. Sources may
be encoded jointly after arrival and retain arbitrary overlaps/memories.
There is NO per-call payload bound: K_s may be huge and depend on N.

Each TP decoded output B_s is CLOSED no later than the end of call s+D,
where D>=0 is an integer maximum delay. It is never acted upon or reused
after closure. Bob may retain decoder environments/other memories and
use them later. All outputs must have closed by the charged horizon N;
any flushing calls are included in N. References are untouched. The
source schedule/dimensions/deadlines are prescribed, not additional
message-dependent timing carriers.

Set Q=sum_s log2K_s and

    F_all=Tr[rho_final product_s Phi_(R_s B_s)].

Suppose C>0 is ANY universal whole-resource weak coefficient satisfying
for every m-call fresh-source block and TP decoder

    2F log2K-h2(F)<=2mC.                              (G1)

For the supplied device one may choose the reviewed quadratic value

    C=min{log2(3),3/2+.5log2cosh[
        (beta/sqrt(1-beta^2))ln2]},

and also intersect with the earlier reviewed C_ent(beta). Its source is
`../ALL_RESOURCE_QUADRATIC_BOUND_V1.md`666db846... . At beta1 the port
ceiling applies. The proof below is generic once(G1) holds uniformly
over ALL normal conditional resources.

If Q/N>=C+delta for a fixed delta>0, put

    W=ceil[2(CD+1/2)/delta], m=W+D, L0=log2(3).

Then

    F_all<=min{1,exp[1/(2mL0)-delta W N/(4m^2 L0)]}.  (G2)

Thus fixed D gives an exponential strong converse in N. More generally
D_N=o(N) implies F_all tends to zero with exponent of orderN/(D_N+1).
No per-call arrival-payload cap or per-window uniform-rate hypothesis
is needed. A source available in full before its declared arrivals, or
a joint output deferred for a linear fraction of the whole horizon,
does not satisfy this contract.

## 2. The standard port baseline on every conditional group

In addition to(G1), ANY ell-call fresh-source protocol with qutrit
forward ports and arbitrary initial resources/backward messages obeys

    F<=min{1,3^(2ell)/K^2}.                           (G3)

For completeness use the fixed cut Alice | (E plus Bob). Inserting the
ell chronological identity qutrit wires has unnormalized Choi vector
Omega of norm squared3^ell. Therefore

    |Omega><Omega|<=3^ell I_in tensor I_out
                 =3^(2ell) J_replacer(I_out/3^ell).

The replacer discards all forward inputs and emits independent fixed
ports. Positive finite-port linking with the same purified strategy
preserves order even with initially entangled normal infinite labs.
The completed comparator has no forward path, so its fresh-reference/
Bob output is(I/K) tensor tau and has Bell overlapK^-2. This proves(G3).
No normalized CP difference, fresh physical bath, forward teleportation
flag or actual new apparatus is assumed. It is the standard finite-wire
dimension/teleportation bound, not a claimed new mechanism.

## 3. Partial groups and exact phase averaging

Fix a phase phi=0,...,m-1. Partition the integer call line into cells
[phi+km,phi+(k+1)m), k any integer. INTERSECT these cells with the actual
horizon[0,N). Keep the first/last partial cells. Their actual lengths
ell_j sum exactlyN, each ell_j<=m, and their numberJ<=N/m+2.

In each cell select source births lying in its FIRST W nominal positions;
the remaining D positions are a guard. A partial cell selects the actual
intersection with that nominal birth window. Every selected source is
closed by its cell's end, or by N in the final partial cell. It arrived
after the previous cell's selected outputs closed. Cells with no selected
source can still carry arbitrary other traffic; they have a vacuous test.
The guard is a charged part of N and does not reset or idle the bath.

Every actual source birth is selected for EXACTLY W of the m possible
phases, including sources at the horizon boundaries. Write A_j for the
sum of log2K_s in the selected part of cell j. Some phase consequently has

    sum_j A_j >= (W/m)Q.                             (G4)

Choosing that phase is an analysis operation on the fixed schedule; no
phase is fed to the parties. No boundary-payload upper bound is required.

## 4. Normal conditional resources and a fresh grouped source

For the chosen phase, consider testing the selected closed outputs of
each cell jointly against their product Bell projector. These virtual
tests commute with all later physical operations. Ignoring unselected
source tests only increases the all-pass probability, hence

    F_all<= product_j p_j,                            (G5)

where p_j is the next selected-cell pass probability conditional on all
earlier selected-cell tests passing. A zero-probability condition makes
the right hand side zero and needs no normalized conditional state.

Otherwise the conditional remaining resource is NORMAL: it is produced
by finite projections, normal partial traces and division by a positive
number. It can be steered and arbitrarily entangled across E and all labs.
The next selected sources are still untouched and independent of it.
Their preparations can be moved back to the cell's start because all
their earlier operations were identities. Together they are one fresh
product Bell source of dimension2^A_j. Other sources/traffic are independent
ancillary resources for this group's application of(G1) and(G3); the
theorems already permit arbitrary normal such resources. The group decoder
collects its closed outputs and traces everything else, a TP map.

Applying both bounds, and using h2<=1, gives with a_j=C*ell_j+1/2

    p_j<=min{1,a_j/A_j, exp[-2ln2(A_j-ell_j L0)]}.    (G6)

For A_j0 use p_j<=1. This conditional statement is not derived from a
source-independent reset assumption; it uses the universal resource scope
of(G1)/(G3) AFTER establishing freshness. Actual controls never receive
the virtual Bell-test results. Reusing closed outputs or advance access
to future inputs would invalidate this exact induction.

## 5. No arrival-payload cap is needed

Let b=2mL0. For A_j<=b and A_j>a_j, the weak part of(G6) gives

    -ln p_j>=ln(A_j/a_j)>=(A_j-a_j)/A_j
                                  >=(A_j-a_j)/b.

For A_j>b, one has A_j>2ell_j L0, so the port part gives

    -ln p_j>=2ln2(A_j-ell_j L0)>=ln2 A_j
                                      >=(A_j-a_j)_+/b,

because b ln2=2m ln3>1. Thus UNIFORMLY for all finite payload sizes,

    -ln p_j>=(A_j-a_j)_+/b.                          (G7)

Equations(G4),(G5),(G7), sumell_j=N andJ<=N/m+2 imply

    -ln F_all >= [sum_j A_j-sum_j a_j]/b
       >= [WQ/m-CN-N/(2m)-1]/b
       >= [{delta W-CD-1/2}N/m-1]/b.                 (G8)

The chosen W ensures delta W-CD-1/2>=delta W/2. Substituting b=2mL0
proves(G2). The conclusion is clipped at1 when the exponent is positive.
All partial boundary cells and all actual calls have remained in the
ledger. Correlated success events do not justify replacing p_j by an
unconditional probability; this proof bounds each CONDITIONAL p_j using
the allowed conditional resource class.

## 6. Asymptotic scope and costs

For fixed C,delta, m=O(D+1), and W/m>=1/[1+delta/(2C)]. Hence the
negative exponent in(G2) has orderN/(D+1). This proves strong decay for
sublinear maximum decoding delay, including irregular/bursty source
arrivals and joint overlapping encoders. It does not prove an unrestricted
whole-message strong converse with a decoder delayed by orderN calls.
The beta0 sector theorem is stronger and needs none of these restrictions.

If a shrinking excess delta_N is considered in the finite inequalities,
the displayed bound alone suffices when delta_N^2 N/(D_N+1) tends to
infinity (C in a fixed positive bounded interval, delta_N<=1). This is a
SUFFICIENT scaling from this proof, not an optimal precision law or a
physical sample complexity. The gate model and source/timing interface
must still be guaranteed independently; no finite calibration certifies
unrestricted infinite-bath structure by itself.

No code, factory, teleportation apparatus or Bell-test feedforward has
been physically performed. The source registers/arrival timing, decoder
closure/deadline, actual N device calls and all ordinary lab controls are
substantive resources/constraints. Virtual tests and comparisons are
analysis, not supplied operational success flags. Generic blocking,
no-signalling, Choi dimension and logarithm inequalities are known tools;
the exact corollary's historical novelty is UNKNOWN. Formal/external
validation, physical validation and practical advantage remain separate
and unestablished. Fresh full-source criticism is required before any
internal promotion beyond this explicitly conditional interface.
