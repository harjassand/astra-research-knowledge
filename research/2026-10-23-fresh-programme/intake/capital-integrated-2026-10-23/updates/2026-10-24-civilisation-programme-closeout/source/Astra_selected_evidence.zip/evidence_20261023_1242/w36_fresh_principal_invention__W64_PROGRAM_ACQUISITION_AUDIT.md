# Fresh audit of the counted program-distribution addendum

23 October 2026, w36. Entire exact target independently reconstructed:
`w64/fixed_resource_loader/ACQUIRED_PROGRAM_DISTRIBUTION_V1.md`,
SHA256ad82ba2a51926da78c50f0f3d2c141ba31d2ea0f5eefe7672df04e49a0bf536e,
together with mandatory `ACQUISITION_PERMISSION_CLARIFICATION.md`,
SHA256309092ac3ca710de096a82d275d29f4129af892412157b076d9a602969e08031.

Verdict: **NO BLOCKING DEFECT FOUND IN THIS CORRECTED ACQUISITION INTERFACE**.
This is separate from the already frozen main-loader receipt743f70e9...
and does not silently expand that receipt's scope. No peer numerical code
was imported or rerun. Historical priority and physical preparation remain
unestablished.

For input colored qubit j followed by vacuum, select first output0 and
second output in the two-dimensional colored subspace. The first-call
identity branch has nonzero first output j, so is rejected. The accepted
first-U branch pushes j; on its second call only U's pop contributes to a
colored output. S_k* S_j=delta_kj I gives EXACT success Kraus a I on the
qubit and the entire bath, including roots and arbitrary bath/reference
entanglement. The mixed U/identity branch with first U and second identity
has output00 and is rejected. Bob's projector does not resolve the color.
Thus success probability is a^2 independent of all input states, and the
whole bath/correlations are restored ON THAT BRANCH. This is not an
unconditional unknown-message identity channel.

For m intended Bob qubits of a known locally prepared program, the all-
success branch is a^m times the identity on those qubits and bath. The
success probability is a^(2m), even if these qubits are entangled with
Alice's remaining program. An unsuccessful attempt may destroy them;
discarding ALL registers of that entire known copy and preparing another
known copy is legal while the fresh logical input remains untouched.
It is not cloning or restarting an unknown logical source. Every complete
attempt has the same success probability for any changed bath, giving
the capped bound and the maximum2mJ forward calls.

Earlier acquired successful programs are tensor factors independent of
the bath and all failure records. Later acquisition operates only on the
bath and a fresh new program, so cannot disturb that factorization. This
proves the R-copy induction. Starting at root, depth grows by at most one
per actual call, hence the conservative support cutoff D=2mJR is valid.
The final vacuum reset has the claimed binomial tail and leaves the
acquired independent programs alone. All aborted acquisitions are kept
as unconditional default-output branches, and the initial unknown-tail
error is propagated by a TP hybrid rather than divided by success
probabilities. The finite per-tolerance cost remains finite, so the
original slow diagonal still gives o(N) additional forward calls for
each FIXED target resource. The costs can be enormous and are not
equated to a cheap laboratory preparation.

I flagged the original section4 phrase 'retaining backward classical
feedback' as ambiguous because the main body permits quantum backward
wires. The mandatory clarification now correctly retains the ORIGINAL
BODY'S backward-wire permission. Acquisition itself needs only classical
backward herald flags; this does not simulate arbitrary body quantum
feedback by classical feedback. Classical-only bodies remain classical-
only, and quantum-back bodies remain quantum-back. Arbitrary N-dependent
body preshares are not acquired in o(N) by this finite-program argument.

The strengthened scope is consequently sound: finite programs introduced
solely to approximate a fixed eta can be distributed through counted
device calls instead of being assumed as new initial A:B preshares. If
the fixed eta was the body's only initial nonlocal resource, no initial
A:B entanglement is needed for the comparison, with the body's original
feedback permission retained. Whole purifier return, no-feedback
capacity, unknown-message herald retries, arbitrary varying eta_N and
efficient physical compilation are still excluded.

Own native implementation `program_carrier_audit_check.py` passed15
all-bath operator-vector fixtures, beta0/.02/.4/.9/1 and initial depths0--2.
The inputs have joint complex qubit:E:G entanglement and coherent seeds.
The full success vector equals a|0> tensor the original qubit:E:G vector;
maximum residual8.59e-17. Both the scalar probability a^2 and endpoint
failure are retained. Raw `PROGRAM_CARRIER_AUDIT_DIAGNOSTIC.json` SHA256
9fe44ecb123d85255a5913865a9d10c3cc8eba9114b117465955be0452fe2f60.
The implementation uses only my earlier native tensor engine, asserts
missing edges unpopulated and never reflects them. These tests verify
the local carrier identity, not an asymptotic theorem or acquired apparatus.
