# Fresh reconstruction: conditional randomized source/design/flush code

23 October 2026, w17. Reviewed frozen integration source
`work/workers/w66_fresh_quantum_decoder/RANDOMIZED_CODE_COMPOSITION.md`,
SHA256 `3816a9a27f990f9e7d19c22418699c60a46b3cd97b6e17b9e11f76e1f178d4d5`.
Also read in full and independently reconstructed the outer algebra in

- w39 `recurrent/outer/SOURCE_ENCODER.md`,
  SHA256 `7876eedb964d5660f7c4df7eeaa26b3ff7af4e450e170eb7da18927405847c87`;
- w39 `recurrent/outer/HIGH_DESIGN_OVERFLOW.md`,
  SHA256 `91b8bb963c3880b7b5adc4feb7c1fd26fb15d020b0d10296c28d98b7574a3fe1`.

Verdict: no blocking defect found in the CONDITIONAL outer composition at
the stated circuit, factory and inherited entropy/drift premises. This is
a randomized polynomial-in-eventual-block-length construction, with a proved
probability of an unverified seed being good. It is not polynomial onset in
1/beta, deterministic efficient seed certification, a physical factory or a
practical communication advantage.

The new design/source reconstruction was completed before reading w66's
`REVIEW_W39_HIGH_DESIGN.md`; that later peer receipt was read to identify its
own upstream scope and evidence. I did not import its numerical outputs.

## 1. Explicit supplied boundaries

The physical channel is unchanged: one inaccessible actual seeded binary
word bath and V_beta, no physical inverse query or forward side wire. The
body's physical input is independent of the initial bath. Logical information
may be encoded by a local CPTP map with retained ancillas. The fixed gauge
is prepared locally before the message is inserted.

This receipt retains the inherited actual original square-source facts:
positive entropy and bulk-drift margins, charge conservation and the
previously reconstructed root-retaining product-source Lyapunov tail.
It does not freshly recertify the entire inherited lower proof. W39's
`DIRECT_ORIGINAL_INPUT_FACTORY.md` was read at SHA256
`d4398b9c0fbafc9632d4b0dbe619e1bee012e3d55d7f2fc1c2ca4bd39eccbe5b`.
Its short H_ij endpoint/block-encoding implementation and rectangular
access/erasure sublemmas remain SUPPLIED circuit premises in this pass;
they were not independently reconstructed here. Its known local helper is
not an arbitrary logical reference or a physical bath purifier. Thus this
receipt does not turn the conditional local factory into an independently
acquired implementation.

The stated rational b, admissible k and positive rational entropy certificate
g0 are supplied classical data. In particular, the rational g0 example uses
that rational model premise; calibration of an unknown physical angle is a
separate error/resource problem.

## 2. The Schur encoder has the correct full-domain gauge and domination

Set R=3k/2+g0/2, Delta=g0/4, ell=floor(mR), D=2^ell and d=3^k. The exact
Schur form of rho^(tensor m) is the direct sum of
p_lambda rho_Qlambda tensor I_Mlambda/f_lambda. On labels f_lambda>=D let
L_lambda=floor(f_lambda/D). The known isometry maps logical z and gauge
(lambda,q,u) to tableau rank z+D u, followed by inverse Schur. Different
triples have distinct coordinates. Its full logical-times-gauge domain
fits inside the physical space because D L_lambda<=f_lambda for every label.

The gauge is prepared with label weights p_lambda/P_G, unitary-register
state rho_Qlambda and a uniform u in its variable finite range. It needs
no source eigenbasis. It can be acquired by paid copies of the known local
source, Schur, a single global good-label test, bounded retries, discarding
the old multiplicity register and controlled uniform-range preparation.
The acceptance test is message independent; failure before insertion is
bounded and assigned a valid default branch. It is not accepted-branch
normalization of unknown transmitted quantum data.

For a maximally mixed logical input, comparison in each Schur block costs
f_lambda/(D floor(f_lambda/D))<2, so

```
E(I_D/D) <= (2/P_G) rho^(tensor m).
```

This is ONLY an average-source domination. No such bound is asserted for
all logical pure states before the design step. The mean actual body
overflow effect transfers by positivity without replacing the recurrent
channel by an iid channel. For every logical operator, physical total
charge acts on the unitary irrep rather than the multiplicity register;
the fixed gauge commutes with that charge. This proves the ideal encoded
density commutes with total charge and uses no full-pattern dephasing.

The no-smallest-eigenvalue acceptance proof is valid. For Z=-log2 p_J,
Pr[Z>log2 d+t]<=2^-t, giving

```
E Z^2 <= B_d=(log2 d)^2+2log2 d/ln2+2/(ln2)^2.
```

Chebyshev bounds the weight on eigenvalues above
2^[-m(S(rho)-Delta)] by B_d/(m Delta^2). The bad-label projector commutes
with rho^(tensor m) and has rank at most
D(m+1)^[d(d+1)/2]. Its remaining weight is at most
(m+1)^[d(d+1)/2] 2^(-m Delta), because S(rho)-R>=2Delta.
The two displayed finite acceptance tests each make one term at most1/4,
hence P_G>=1/2 and the domination constant is4. Computing those scalar
tests and tableau hook ranks does not enumerate a d-entry eigenbasis or
all f_lambda tableaux.

## 3. High moments supply the complete logical overflow bound

Let A be the positive logical mean-over-seed overflow effect, 0<=A<=I,
Tr A/D<=epsilon. For a first-K-column Haar isometry T, the fixed-vector
Gaussian estimates independently reconstruct as

```
E exp(g*Ag/2)<=exp(Tr A),
Pr[||g||^2<D/2]<=exp[-cD], c=ln2-1/2.
```

They are combined by a union bound, not by an unjustified independence
claim for numerator and denominator. A half-net of the complex K-sphere
has size at most5^(2K). Applying it to A^(1/2)T and squaring its norm
costs factor4. The resulting Haar tail for Z=||T*AT|| is

```
Pr[Z>16(Tr A+2K ln5+u)/D] <= exp(-u)+zeta,
zeta=exp(2K ln5-cD), u>=0.
```

The net is purely analytical. Integrating BEFORE replacing Haar is the
load-bearing step. Since Z<=1, the constant exception contributes only
zeta to its h-th moment. Minkowski and (h!)^(1/h)<=h then give

```
E_Haar Tr[(T*AT)^h]
 <=K[16(Tr A+2K ln5+h)/D]^h+K zeta.
```

For a diamond h-moment-channel design approximation delta_des, the cyclic
trace identity uses input P^(tensor h) C_h, whose trace norm is EXACTLY
K^h. The resulting moment error is at most delta_des K^h, including this
dimension factor. It applies to a nonpositive cyclic test because diamond
norm bounds the full induced trace norm, not just tests on product states.
Markov therefore gives the three terms in the source's equation6.

The finite conditions in equation7 suffice. With q=K/D, epsilon<=q,
h<=K and ln5<2, the first normalized ratio is at most96/256<1/2 at
Q=256q. The chosen h pays its K prefactor. The two exponential conditions
pay K zeta/Q^h, and delta_des<=(eta/4)(Q/K)^h pays the design transfer.
Each term is at most eta/4, giving success at least1-eta. The dyadic
parameters in the integration file meet its accuracy inequality exactly;
all remaining finite size tests are explicitly required before use.

For the fixed gauge purification the mean effect really acts on LOGICAL
space. The actual source domination and Lyapunov tail give
Tr A/D<=4(1+C_tail)exp(-tH)<=q at the specified H. Positivity gives
A_s<=2A. Consequently the SAME successful random logical subcode has
complete overflow at most512q in EACH conserved seed sector. Low-order
average-fidelity decoupling would not suffice, but no such substitution
is made here.

## 4. The cited compilers and finite randomness conventions match

I independently opened the primary
[BHH1208.0692v4](https://arxiv.org/pdf/1208.0692), Corollary6 and Lemma3.
Their relative design convention implies diamond error at most twice the
relative error. At two-qubit local dimension, the coefficient is170000;
the exponent5+3.1/ln2 is below10. The source's longer circuit and relative
target delta_des/8 therefore have the claimed slack. These generic design
results are established prior art.

I independently opened the corrected primary
[Burchardt et al.2509.22640v1](https://arxiv.org/pdf/2509.22640), Theorem1
and Table1. They give the stated corrected Schur circuit with the required
symmetric and unitary Gelfand-Tsetlin coordinates, soft-O(m^4) gates and
soft-O(m^2) space, hiding polynomial logarithms in d and accuracy. The
older erroneous Krovi final step is not an adequate replacement citation.

The finite-bit Haar-local replacement is also a valid asymptotic compiler
construction. In constant dimension, truncate Gaussian coordinates at a
bound polynomial in sqrt(log(1/z)), and couple finite-bit inverse-CDF
samples to the continuous coordinates. The inverse can be computed by
bounded binary search with sufficiently accurate elementary functions.
Four Gram-Schmidt residuals each have a conditional small-norm probability
at most tau^2. On their complement the fixed-step map has a polynomial
Lipschitz bound in1/tau and the coordinate bound. Taking tau and coordinate
error as suitable fixed powers of z uses only O(log(1/z)) precision bits
and makes both operator error and exceptional probability at most z.
Constant-dimensional reunitarization and universal-gate synthesis preserve
polynomial logarithmic accuracy cost.

One small implicit discrete cost can be supplied explicitly: selecting a
nearest-neighbor index uniformly from ell-1 positions can use bounded-bit
rounding with total-variation error at most z and
O(log ell+log(1/z)) bits, or capped rejection. Its coupling error is
absorbed by decreasing the per-gate z by a fixed constant. This requires
no unbounded random seed or circuit-size branch. A telescoping coupling of
M local gates costs at most2hMz+2Mz in the h-moment channel, as stated.
Thus log(1/delta_des)=O(ell^2+ell log m) and the extreme accuracy still
has polynomial description/compilation length. This is an existence and
asymptotic cost reconstruction, not an executed sampler, explicit elementary
gate constant or inspected compiled high-order circuit.

I also independently opened the prior
[Hayashi-Matsumoto0209030v1](https://arxiv.org/pdf/quant-ph/0209030) Schur
multiplicity construction and [Rizzo et al.2609.38038v1](https://arxiv.org/pdf/2609.38038),
equation31 and D27-D28. The latter explicitly gives the mixed-gauge Schur
encoder; its pure-state refinement diagonalizes the gauge. That refinement
is not used here, nor is its memoryless-channel recovery imported to this
recurrent device. Generic Schur encoding and pseudorandom design methods
are not candidate novelties of this construction.

## 5. Counted decoder, error, rate and initializer quantifiers

The independently reviewed mixed-gauge decoder applies the digital inverse
to retained body AND flush outputs and a LOCAL vacuum stack. It then
inverts the full-domain source isometry and logical random embedding.
It never accesses G or the actual bath. All implementation differences
can be added at the encoder/decoder channel level by diamond contraction;
the implemented gauge purification need not equal the mathematical one
on every branch. Exact total-charge pinching leaves the ideal encoder
channel unchanged, although it can change an implementation's discarded
gauge environment. No physical original-gauge-purifier return is required
for the logical-channel guarantee.

With A=floor(log2(m+1)), nu=(m+1)^(-2), delta=(m+1)^(-1), the stated initial
zero prefix, sector probes and intervening zeros have the previously audited
complete errors. The tail cutoff is analytical, not a physical bath
measurement. For a successful design seed the body overflow is512q; the
terminal zeros add binomial failure at most q. The resulting ideal error is

```
min(2,4sqrt(513q)+2delta+4sqrt(q_A+nu)),
q_A=1-Tr(P_<=A tau),
```

plus separately paid encoder and decoder channel errors. Initial bath
and logical/gauge independence are required. For EACH fixed normal tau,
q_A->0; at tau_pi its explicit value is3^[-(A+1)]. There is no uniform
finite normal-tail modulus. A good seed works in both sectors, so the
encoder is common and Bob alone uses his acquired sector estimate. The
seed selection guarantee itself does not depend on which fixed normal
tau is subsequently supplied.

Every initial descent, probe, intervening zero and final flush is counted
in S; all-body calls number mk and N_total=mk+S. The displayed rational
rate arithmetic is correct:

```
log2 K=ell-s>=m(3k/2+g0/2)-1-s,
mg0/4 >=1+s+(3/2+g0/(4k))S
```

certifies rate at least3/2+g0/(4k). At fixed admissible beta and k,
S=O_beta(log^2 m)=o(mk); the error vanishes pointwise in tau. If a definition
requires all integer horizons rather than this sequence, the prescribed
sizes have N_(m+1)/N_m->1. Append fixed extra inputs and ignore those
later outputs to fill a requested horizon; causality leaves the earlier
decoded marginal unchanged, and the rate loss is o(1). This is standard
counted padding, not a new operation or a free return claim.

## 6. Randomized success is distinct from a certified deterministic seed

For each m, the finite offline compiler samples a polynomial-bit circuit
description with failure at most eta=(m+1)^(-2). The same known description
and its inverse must be programmed into Alice's and Bob's code before the
message; a seed privately sampled by Alice at runtime would not supply
Bob's decoder without extra communication. Pre-agreeing a code description
is the stated interface, not runtime shared entanglement or a forward wire.

After any seed is fixed, the transmission is a definite CPTP protocol.
Summable eta gives almost-sure eventual success for an independently sampled
sequence (summability alone would already suffice for this implication),
and a deterministic successful sequence exists. No efficient procedure
identifies or certifies which particular seeds are good. As an offline
randomized compiler this is a legitimate Monte Carlo guarantee; it must
not be described as a deterministic certified construction. Averaging
the logical channel over a shared offline seed also gives error at most
the good-seed bound plus2eta, if that randomized convention is adopted.

## 7. Exponential onset and complete cost separation

The representation's necessary onset is real, not a proof artifact hidden
by the gate bound. From sum_lambda f_lambda^2=m!, nonempty storage needs
2^floor(mR)<=sqrt(m!). Using m!<=m^m gives

```
log2 m >=2R-2/m >=3k-1  (m>=2).
```

The sufficient scalar test also has a9^k-scale factor. With
k=Theta(beta^-2), this particular encoder therefore has exponential onset
in1/beta^2 and cannot realize the separate polynomial-horizon existence
bounds from spectral slices. At that enormous eventual N, its factory,
gauge preparation/retries, Schur and tableau arithmetic, high-design gates,
stored seed, inverse source/design circuits, local digital simulation and
precision lengths are polynomial. The high-design degree and gate exponent
are large. Neither small constants nor useful numerical resources follow.

All local source copies and preparation failures, discarded helpers,
measurement records, classical code compilation, entropy disposal and
parameter precision are paid mathematical resources. Thermodynamic energy,
fault tolerance, realistic noisy controls, calibration, wall time, finite
useful onset and superiority to equally informed incumbents remain
UNKNOWN. The actual physical angle is supplied; the stated2N_total times
angle-error hybrid bound is consistent for the angle parametrization.

No new numerical fixtures were run: the all-dimension algebra and cited
compiler contracts carry this conditional result. Existing peer diagnostics
were not rerun or counted as hardware evidence. Exact capacity/coefficient,
terminal return versus unrestricted tradeoff, historical priority, external
mathematical acceptance, physical validation and mission achievement remain
unresolved. The sharp next gate for an unconditional circuit theorem is
fresh reconstruction of the specific inner factory/access sublemmas left
supplied above, rather than silently importing this outer verdict to them.
