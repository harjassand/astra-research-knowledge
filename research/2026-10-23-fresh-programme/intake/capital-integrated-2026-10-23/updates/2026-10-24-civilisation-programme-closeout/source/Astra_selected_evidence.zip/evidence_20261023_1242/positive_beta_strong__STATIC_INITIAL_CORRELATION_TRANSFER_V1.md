# Static initial-correlation transfer of the product strong converse

23 October2026, w49. Root proposed the finite-dimensional initial-resource
comparison and requested exact feedback-scope verification. This note
independently proves that comparison and checks it against the stronger
already reviewed product-initializer trace theorem. The bridge is root's
proposal; no new device-specific exponent or global all-resource strong
converse is claimed. All older frozen files remain unchanged.

## 1. Exact reviewed source and strategy scope

w19 `coherent_initializer_invention/FULL_PROOF_V1.md`, SHA256
`1556727069358baa8838813d3364eb2e33869dd32cc6d04df682a4dc868328cc`,
was reread completely, especially Sections1 and5. Own prior full audit
`whole_initializer_audit/FULL_V1_HASH_AUDIT.md`, SHA
`fdde75a601f295283083d5a6ff5d4801c959c91844dfd196efefd39757948346`,
is retained; the hash of that prior audit is reverified by the manifest.

The exact source proves, for every horizon N and every normal product
initialization `tau_E tensor zeta_labs` independent of a fresh logical
source, the finite Bell bound

    F_N(tau tensor zeta) <= min{1,H_b^N/K^2},
    H_b=(sqrt(2-b)+sqrt(2+2b))^2, b=beta^2.          (S1)

Crucially (S1) includes arbitrary normal laboratory preshares and memories,
arbitrary local normal TP controls, and arbitrary backward quantum or
classical messages. There are fixed N chronological forward qutrit calls
and no other forward carrier. The source's SAME-global-constant positive
normalized difference comb transfers its product Choi certificate to
those adaptive strategies. This exact scope was already audited and is
explicit in the frozen full source, rather than inferred from a static
block-channel result.

The initializer tau in (S1) can depend arbitrarily on N and have arbitrary
coherence, support, depth or entropy. Thus any static finite-rank bath
projection below is allowed; it need not be a coordinate/depth projection
or commute with U,V,port charges or any subsequent dynamics. The actual
infinite bath and its physical root remain unchanged in all N calls.

## 2. Finite-rank positive comparison

Let eta be a normal density on `E tensor L`, where L is the entire initial
laboratory resource. The fresh source is `Phi_RM tensor eta`, independent
of eta. Let P be any finite-rank bath projection, rank d>=1, and define

    eta_P=(P tensor I) eta (P tensor I),
    p=Tr eta_P, omega_P=P/d, eta_L=Tr_E eta.

In an orthonormal basis of P, positivity and vector Cauchy--Schwarz give
the finite pinching inequality

    eta_P <= d sum_j |j><j| tensor (eta_P)_jj.

For each j, the positive operator `(eta_P)_jj` is bounded above by their
sum `Tr_E eta_P`. Consequently

    eta_P <= d I_P tensor Tr_E eta_P
           <= d I_P tensor eta_L
            = d^2 omega_P tensor eta_L.             (S2)

The second inequality uses
`eta_L-Tr_E eta_P=Tr_E[(I-P)eta(I-P)]>=0`; cross-block terms have zero
bath partial trace. This proves (S2) for arbitrary normal infinite L,
including arbitrary correlations and coherences in eta. The factor d^2
is optimal for this generic comparison: a normalized maximally entangled
state on d bath and d laboratory dimensions has marginal I/d, and the
smallest multiple of `(I/d) tensor (I/d)` dominating it is d^2.

If p>0 one may instead use the normalized laboratory marginal of eta_P
and retain an extra factor p, but (S2) is sufficient and avoids a new
conditional-resource definition.

## 3. Transfer through the complete fixed protocol

Fix one code, all its controls and its source dimension K. Its final
unconditional Bell fidelity is a positive linear functional of the
INITIAL resource:

    F_N(x)=Tr[T_N x], 0<=T_N<=I                    (S3)

on positive trace-class x. Normal TP strategy maps, the independent fixed
Bell source and a bounded final Bell effect establish (S3). No physical
preparation or access to P is needed to compare two initial states.
In particular a protocol that retains decoder environments, sends quantum
systems backward or generates new bath/lab correlations during its
operation is still covered: only its initial state is being compared.

Apply (S2), positivity, then the reviewed product-resource theorem (S1):

    F_N(eta_P) <= d^2 F_N(omega_P tensor eta_L)
                 <= d^2 H_b^N/K^2.                 (S4)

Gentle projection of a normal state gives
`||eta-eta_P||_1<=2 sqrt(1-p)`. Combining with (S3) yields

    F_N(eta) <= min{1,d^2 H_b^N/K^2+2sqrt(1-p)}.    (S5)

This is the promised resource bridge. It uses the whole-laboratory
product contract of (S1), not merely source/bath independence. Source
freshness is preserved by (S2), since it is a comparison on eta alone.
The generic comparison is not a bath reset, physical filter, supplied
measurement outcome or normalization of successful code branches.

## 4. Pointwise fixed-normal and uniform supplied-family consequences

Put `C_prod(beta)=.5log2 H_b`. For a code rate
`log2 K_N/N>=C_prod+delta`, with fixed delta>0,

    F_N(eta) <= d^2 2^(-2delta N)+2sqrt(1-p).       (S6)

If eta is ANY fixed normal bath/laboratory state, choose bath projections
P_M increasing strongly to I. Normality gives `p_M->1` with finite d_M
for each fixed M. First taking N->infinity in (S6) at fixed M and then
M->infinity proves `F_N(eta)->0`, uniformly over all strategies at that
horizon. There is no finite mean-depth or entropy requirement and no
uniform tail modulus over all normal eta. This is a POINTWISE strong
converse, not a uniform all-normal finite-N exponential error rate.

One may append arbitrary N-dependent normal laboratory ancillas or
preshares independent of the fixed bath/laboratory state. Tensoring and
local TP preprocessing preserve (S2); the cutoff probability is unchanged.
Thus the fixed-correlated-resource conclusion does not impose a fixed
dimension on additional bath-independent laboratory assistance.

More generally let eta_N vary. If supplied bath projections P_N have ranks
d_N with `log2 d_N=o(N)` and `q_N=1-Tr(P_N eta_N)->0`, then

    F_N(eta_N) <= d_N^2 2^(-2delta N)+2sqrt(q_N)->0. (S7)

These projections can be arbitrary coherent subspaces. A depth cutoff
P_{<=A} has `d=2^(A+2)-2`, so the usual `A_N=o(N)` tail condition is a
special case. The comparison does NOT require the bath state itself to
have low depth or rank: uncorrelated product tau_N of any support already
has cost one by (S1).

An even more general supplied resource promise is a positive comparison

    eta_N^good <= c_N tau_N tensor zeta_N,
    ||eta_N-eta_N^good||_1<=epsilon_N,
    log2 c_N=o(N), epsilon_N->0,                    (S8)

with normalized product states tau_N,zeta_N. It immediately gives
`F_N<=c_N 2^(-2delta N)+epsilon_N`. This makes the missing resource cost
explicit: subextensive smooth max-relative correlation suffices. No
efficient method to acquire, estimate or certify (S8) is supplied.

## 5. What remains open

The new conclusion is an initializer/resource-boundary extension of the
OLD product trace ceiling, whose leading excess coefficient is
`1/(8 ln2)` at beta0. It is not the sharper reviewed all-resource weak
coefficient `ln2/4`, and is not a new best weak bound. The earlier
fixed-normal optimized graph ceiling may be better at intermediate beta
when its exact feedback/resource scope is separately available; this
note uses only the explicitly reviewed full trace source.

An arbitrary horizon-dependent entangled eta_N may require d_N exponential
in N and have extensive comparison cost. Equations(S5)--(S8) do not give
the unrestricted all-resource quadratic strong converse in that regime.
The arbitrary-N resource contract in the weak theorem permits it. A
correlation preparation budget or normality alone, without a fixed-state
limit or supplied sublinear comparison promise, cannot be silently added.

All proofs here are internal analytic deductions. No finite physical
device data, bath operation, resource factory, reset, calibration, code
synthesis or practical advantage was acquired. Historical priority of
the generic finite-dimensional domination is not claimed; root supplied
the bridge and this worker checked the precise source/strategy interface.
