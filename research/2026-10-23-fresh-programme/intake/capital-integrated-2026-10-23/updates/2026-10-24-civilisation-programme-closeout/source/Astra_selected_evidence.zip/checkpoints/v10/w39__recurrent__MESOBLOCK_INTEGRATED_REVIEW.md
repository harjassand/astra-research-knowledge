# Hash-specific integrated review of W67's mesoblock construction

W39, 24 October 2026. Main target SHA256:
`d8142311944b94c8b5a6e0773a9201d05d704d38810fee95120e1040c318a871`.
Initializer qualification SHA256:
`736cebd649960d1d295a45a2352d1aed0c04af3105956502e05e8a3a23155605`.
The exact dependencies and byte bindings are in
`MESOBLOCK_INTEGRATED_DEPENDENCIES.json`; the detailed derivation is
`MESOBLOCK_INTEGRATED_RECONSTRUCTION.md`.

**Verdict: no blocking defect found in the conditional integrated
construction, with the initializer qualification and supplied model
below.** This is a co-informed audit after reading W67's proof/policy/
producer text and W49's ideal review. It is separate from my earlier
cf90 access-only review. My new checker imports/runs no producer or peer
module and independently reconstructs every one of the 180 raw row fields.
Neither a chain of component approvals nor the finite rows alone is the
basis of the integrated verdict.

The qualified implication is a randomized, quantum-generated classical
public-program constructor for the supplied exact known rational b,
actual recurrent family and local universal digital-gate model. Given
the bound V4 source theorems and the explicit paid local source/operator
algorithms, it has joint-polynomial onset and construction/operation
cost in the named numerical inputs, and sufficient forward rate at least
3/2+beta^2/59520 at logical diamond error <=z except with program failure
probability <=eta. The three finite examples use the supplied geometric
initializer bound. General supplied tail cutoff A must be included as a
numerical input; arbitrary normal initializers retain pointwise
asymptotic convergence, without a uniform finite polynomial tail modulus.

I reconstructed the following integration points:

- The conditional good-frame PSD expectation retains its indicator,
  uses the source-weighted estimated finite cell law, and pays bounded
  two-attempt width selection. The fixed public prefix produces a common
  pure logical domain. Bad programs remain total CPTP/explicit compiler
  failures before message insertion; the proof does not normalize each
  frame by its good probability.
- Relative source/log approximation is ordinary operator norm, derived
  from the analytic source. The acquired block normalization is used.
  Full QPE/coin/uncompute leakage, reject bins, invalid charge labels,
  noncommuting Duhamel error and finite arithmetic are charged. No density
  eigenbasis, Gram oracle, inverse sigma or trace-to-relative shortcut is
  supplied.
- The FIRST completion compares the full functional unitary and its
  adjoint/controls with one consistent exact completion. The SECOND
  converts the final polar block approximation to a complete encoder
  comparison. The signal tolerance is squared: with Bsig=2BDelta+32,
  648delta_sig<Delta^2. Consequently dirty-helper calls, inverses and
  range reflections are justified globally. No ideal-completion circuit
  or inverse of physical CPTP legalization is called.
- The actual root term, conservative k-bounded drift, both sectors,
  Markov program failure, all terminal emission outputs and physical
  zero-port costs remain in the proof. The digital stack is sized at the
  actual body-plus-flush horizon. Fourier coefficient norm squared is
  <=R, not 1. Common operator cross-KL and full CPTP polar cutoff give the
  arbitrary-reference diamond bound without a logical-dimension factor.
- Every outer row contains the ENTIRE parent encoder. The valid full-
  domain factoring gives I=Qouter+1 repeated encoders, each with s child
  circuits and Qinner nested filter/design/rank calls. Both classical
  phase constructors, source/function precision, table acquisition,
  resets, all public seeds and full output emission remain paid.

The new exact integer/Fraction receipt matches all three selected rows,
including every initial/body/terminal physical call and rate guard. It
also checks the literal majority degree-to-query ceiling, squared polar
accuracy, both source-error terms, actual Fourier row count, error and
confidence unions. At z=.001 and eta=.01 its conservative error sum is
769/2048000<z and program-failure union is 10701/10240000<eta.

| beta | total actual forward calls | function-isometry accuracy bits | T_PE power |
|---|---:|---:|---:|
|1/128|2027745784349686312784312598608|11201|22471|
|1/512|8307548208595766840594898275993936|11270|22609|
|1/2048|68056408480476979321468946994890740496|21828|43728|

The last two columns are further **requirements** reconstructed from
N1/N3, not measured gate accuracy or full native code counts. In
particular P_access depends on that inverse accuracy. Qinner and phase
logarithms in the producer's raw rows are partial primitive envelopes;
they cannot stand in for a complete numerical native gate budget.

The probability table is learned by counted local quantum experiments
on known source circuits. It has not actually been learned here. Public
preprogramming is a substantive allowed interface: this audit does not
close the variant requiring the table/program bits to be transmitted
through the same forward device, a purely classical constructor, a
certified deterministic good seed, unknown apparatus calibration or a
coarse-band source. The later factor-two-band note 90f088 and changed
rows are outside this verdict.

No enormous circuit, successful program seed, full table, phase sequence,
native source/code execution or physical device was produced. Earlier
small source/access controls retain their original scope. I imported,
rather than freshly proved, the frozen V4 entropy/drift/chi-squared
theorem and the primary design/singular-transformation results. The
integration derives how those exact premises are consumed, including
the full operator/precision/call costs.

The candidate replaces the Schur route's exponential-k multiplicity
onset under this special charge/relative-density/access contract. It
does not prove a generic compiler speedup, optimal capacity coefficient
or practical advantage. Equally informed baselines receive the same
designs, polar machinery and full-domain factoring. Generic methods are
established prior; composition priority and best matched prior total
cost are UNKNOWN. Physical validation NOT_PERFORMED; practical advantage
NOT_ESTABLISHED; mission NOT_ACHIEVED.

The decisive next review is root's separate inspection of this complete
qualified composition and its operational public-program convention.
If a literal acquired executable is desired, the next construction is a
small complete t-cell table/filter/frame/encoder/receiver instance with
full controlled native output and all branches retained. That experiment
would test an implementation, not certify the enormous asymptotic rows
or acquire a device calibration.

