# Independent audit: heralded sampling from an arbitrary correlated block

23 October 2026. Critic w50; no descendants. The frozen source is
`OWNER_PROOF_SNAPSHOT.md`, SHA-256
`3977208bd51821f828acd68b9e25197c5a6f222a753c422898992d6df6aaece1`.
The referenced filter/code argument is separately frozen in
`OWNER_MAX_BUDGET_SNAPSHOT.md`, SHA-256
`b72343dd220696faa021fa4fc0d1f2d6eefca5ca5d9b6f61b61d9142859d774c`.
The latter document's unrelated preparation-budget conclusions are not
adopted by this audit.

## Verdict

**PASS as a sufficiently-large-block, ideal-control heralded statement.**
No actual-source iid, Gaussianity, mutual-information bound or relative-
entropy budget is needed. The source must be committed before independent
fresh sampling randomness; the specified filters, qubit gates, storage and
classical coordination are trusted. The accepted Bell failure is a virtual
output projector probability, not an implemented global Bell measurement.

For a fixed m with the stated distance code, the proof gives

    q=Pr(accept AND Bell failure)<=2 exp(−m/73728).

It gives a weighted accepted-state guarantee, and a different coherent
heralded-subspace guarantee when the purification of flag readout is retained.
It does not give a source-uniform normalized accepted-state error or any
positive acceptance/yield bound for an arbitrary source.

The phrase “sufficiently large” matters. I give an explicit completion:
for m>=72, so L=2m>=144, the stated half-rate code exists; for smaller m
declare all-abort before any division by a sample size or use of the code.
Product logical zeros in the predeclared rank 2^m factors complete every
abort branch. For the warm sequence, assign all-abort to the finite initial
segment with m_N<72. These conventions leave every stated asymptotic
reference rate unchanged and make a TP finite-size receiver explicit.

The independent reconstruction precedes reading a producer verdict or
producer checker. The new checker uses no producer imports. Its 10,666
exact and diagnostic controls cover constants, integer code thresholds,
small symplectic spaces, a completed five-qubit decoding control, exact
hypergeometric laws and a guard against dephasing the retained seed for free.
Universal validity comes from the analytic steps below, not finite tests.

## 1. Bounded filters on the full normal input extension

For fixed finite G>1, t=sqrt((G−1)/G) lies strictly between zero and one.
Alice's success map is

    K_A=t|0_q><0_F|+|1_q><1_F|,

with `K_A^*K_A=t^2|0><0|+|1><1|<=I`. Bob's success map projects to Fock
0,1 and relabels that subspace. Each has a complementary bounded failure
map, for example sqrt(I−K^*K) into a retained failure space. A Stinespring
implementation therefore gives a TP local instrument on every normal
bosonic input, including arbitrary extensions. This needs no moment,
mean-energy or entropy bound.

The quantum success map must preserve coherence between Fock 0 and 1;
it is not a photon-number measurement recording which of these occurred.
All flags, rejected modes and unused systems remain in the residual. The
trusted physical implementation of this non-Gaussian filter is supplied,
not obtained from the abstract bounded-operator formula.

Conditional on any filter flags with at least 4m joint successes, taking
the first 4m is a fixed local selection. The selected qubit marginal can
be arbitrary and entangled with every unused mode and inaccessible source
reference. Because the subsequent fresh seeds are independent of this
whole conditional state, proving soundness for every such marginal proves
it conditional on each eligible flag history. On histories lacking enough
successes, accept probability is zero. Averaging those histories preserves
the unnormalized failure bound.

## 2. What Pauli twirling does and does not classicalize

Let l=(x,z) label a Bell state. The bilateral operation bar P⊗P fixes the
standard Bell state and multiplies Bell label l by a character of the
four-element Pauli group. Averaging independently at every selected site
annihilates every off-diagonal Bell-label matrix element of the receiver
marginal. The resulting marginal is exactly

    sum_l p_l |Bell_l><Bell_l|,

where l is a whole 4m-site string and p_l is unrestricted. It need not
factor by site, by source copy, or between bit and phase labels.

The full Bell-plus-reference-plus-seed state need not be diagonal. The
recorded seed can retain the phases of the original coherences, including
in an inaccessible purification. The finite check explicitly has zero
averaged marginal off-diagonal but retained-seed off-diagonal absolute
sum 1/2. The source proof correctly uses only a marginal dephasing claim.

Every subsequent operation determining accept and the final Bell-test
probability acts on the receiver block and later fresh randomness, without
using the twirl seed. Thus its output probability is determined by the
averaged receiver marginal. This justifies the fixed-string classical
analysis even though the full extension remains quantum. It would fail
if the protocol coherently untwirled using its retained seed, or selected
its partition as a function of that seed. The declared independent fresh
partition and “do not use the seed” condition exclude those changes.

For each Bell string, local Z comparisons report x, and local X comparisons
report z. Fine local outcomes may be random, but the parity-error counts
used by the decision rule are these deterministic labels. No Bell-label
measurement or inaccessible purifier information is acquired.

## 3. Sampling without replacement: universal fixed-string proof

Fix an arbitrary binary x string on 4m sites and a uniformly random
partition into T_Z,T_X,R of sizes m,m,2m. Conditional on
`S=T_Z union R`, S has size 3m and T_Z is a uniform m-subset of its fixed
population. If a is its sample mean, r its remaining mean and mu its
population mean, then `mu=(a+2r)/3`.

For a nonnegative population y_1,...,y_(3m), the expected product on a
uniform m-subset is its elementary symmetric mean, bounded by the mth
power of the arithmetic mean. This is Maclaurin's inequality; the
pair-averaging argument in the source also proves it, because with a
fixed sum the elementary symmetric polynomial's dependence on the two
chosen entries has a nonnegative coefficient multiplying their product.

Apply this to y_i=exp(−lambda x_i). The sample sum's lower-tail mgf is
bounded by that of m independent Bernoulli(mu) variables. The centered
one-variable log mgf has second derivative at most 1/4, zero value and
zero first derivative at zero. Consequently

    Pr(mu−a>=b)<=exp(−2m b^2).

This uses a with-replacement mgf upper bound, not an iid premise on the
actual sample or source. If a<=tau and r>tau+delta, then
`mu−a=2(r−a)/3>2delta/3`. Therefore the x bad event has probability at
most `exp(−8m delta^2/9)`, uniformly in every S and every full x string.
The same argument applies to z using T_X union R. Acceptance can only
reduce either event. A union bound requires no independence between x,z
or between the two samples. Substituting tau=delta=1/256 gives exactly

    Pr(accept AND [x_R>1/128 OR z_R>1/128])
       <=2exp(−m/73728).

Uniformity over strings permits every arbitrary correlated Bell-label
distribution. The bound is also uniform in preceding filter flags.

Commitment and seed independence are load-bearing. If the source knew
test positions beforehand, it could place perfect Bell pairs on every
tested site and a separable state on all untested sites. Every test would
pass, but LOCC purification of the remaining separable input could not
produce a high-rank Bell state. Selecting fresh positions after complete
receipt excludes precisely this counterexample. An adversary holding a
purifier can steer conditional descriptions later, but cannot change the
unconditioned committed receiver marginal by acting only on that purifier.

## 4. Distance-code existence and decoding on every branch

For L=2m let r=L/2 and k=L−r=m. Choose an r-dimensional isotropic
subspace T of the 2L-dimensional binary Pauli-label space. Symplectic
transitivity on nonzero labels and `dim T_perp=2L−r` give

    Pr(e in T_perp)=(2^(2L−r)−1)/(2^(2L)−1)<=2^(1−r).

Set u=floor(L/32). The expected number of nonzero Pauli labels of weight
at most 2u in T_perp is bounded by

    2(L+1)2^(−L zeta),
    zeta=1/2−h2(1/16)−log2(3)/16.

The quaternary type-entropy bound applies because 2u/L<=1/16<3/4,
where that type entropy is increasing. The exact integer inequality
`3·16^15<8·15^15` implies zeta>1/16. For all integer L>=144,
`2(L+1)<2^(L/16)`: check the sixteen base residues L=144,...,159,
then increasing L by 16 doubles the right side while increasing the
left side by only 32. Thus the expectation is strictly below one for
every even L>=144. At least one T has no such low-weight vector.

Fix the first qualifying T in a specified finite enumeration. Its
stabilizer code has k=m logical qubits and distance at least 2u+1.
For any two distinct errors of weight at most u, their difference has
weight at most 2u and cannot lie in T_perp, so their syndromes differ.
This deliberately chooses a nondegenerate code; degeneracy is not needed.

A complete decoder is finite and fixed. Construct a lookup table for
all Pauli errors of weight at most u. For an unlisted syndrome, choose
the first Pauli with that syndrome, which exists because independent
stabilizer generators give a surjective symplectic syndrome map. This
defines a correction on every outcome. Alternatively any fixed correction
and local per-syndrome decoding would suffice on uncorrectable cases.
Given T, finite symplectic elimination supplies a Clifford mapping its
generators to standard syndrome Z operators. Bob uses that Clifford and
Alice its complex conjugate; output syndrome qubits and records are kept,
and k logical qubits are always designated. This fixes basis alignment,
including generators containing Y, rather than assuming arbitrary local
code bases yield the same Bell vector.

Alice measures conjugate generators and Bob measures the generators.
Their outcome differences give the error syndrome. Correcting a
weight-at-most-u error restores matching code subspaces. A matching
rank-2^k projection of the maximally entangled input is itself maximally
entangled in matching conjugate bases, so decoding gives exactly Phi_(2^k).
The syndrome outcomes and all input purifiers stay in the residual.
Linearity handles superpositions; no classical-purifier assumption is used.

On the good sampling event, Pauli weight is at most the sum of bit and
phase counts, at most L/64. For L>=64, floor(L/32)>=L/64. Thus every
such Bell string is corrected exactly. All other strings still produce a
normalized fixed-rank output; no successful decoder branch is postselected.
The original accepted Bell-failure bound follows.

Code search can require 2^O(L^2) candidates, each with an exponential
distance test; the low-weight lookup table is exponential in L. A code
has not been acquired by an efficient factory, and no efficient decoding
claim follows. The five-qubit fixture in the independent checker tests
the decoding mechanism on all 1,024 Pauli inputs, including a completed
default-syndrome rule. It is not substituted for the analytic large-L code.

## 5. Full residual and flag conventions

On a READ classical accept outcome of probability p, let Omega be the
normalized conditional Bell-plus-residual state and e=q/p its Bell failure.
The residual includes the original inaccessible source reference, old
modes, unused outputs, apparatus records and twirl records conditional on
that read outcome. Projecting onto the rank-one Bell factor and purifying
proves closeness at most sqrt(e) to Phi tensor a projected residual.
Contracting and applying a triangle inequality gives the source's bound
to Phi tensor the actual conditional residual, at most 2sqrt(e).
Multiplying by p proves `p d<=2sqrt(pq)<=2sqrt(eta_m)`. If p=0, the
weighted expression is zero. The classical ideal leaves abort exactly
unchanged, so the same weighted expression is the full instrument distance.

This convention does not retain the purification of the readout dephasing
as part of that classical instrument state. If that purification is also
kept, the joint state can have acc/abort cross blocks. The source instead
uses the projector

    Pi=|acc><acc|⊗Phi_M⊗I_R + |abort><abort|⊗I_Bell⊗I_R.

It has failure probability q. For q<1, normalized projection of a
purification gives `Omega_tilde=Pi Omega Pi/(1−q)` and distance at most
sqrt(q). This is valid on an arbitrary normal extension and preserves
possible coherent flag cross blocks. Its accepted conditional block has
the Bell factor; its abort block is unrestricted and may change. No
replacement of the actual unconditional residual is asserted here.

The distinction cannot be dropped: the coherent superposition of a
perfect accepted branch and an abort branch, each of weight 1/2, has
q=0 and is already in Pi, but differs from its classical-flag dephasing
by half trace distance 1/2. Declaring that total state block diagonal
would invalidate a zero-error claim. The frozen proof avoids this error.

## 6. Warm-reference completeness and all-abort limitations

For the known iid product thermal reference, p0=(1+v)^−2 is the vacuum
input weight. The local filter on the squeezed vacuum succeeds as
sqrt(s0) Phi_2 with `s0=2(G−1)/G^2>0`. Positivity of the other thermal
component gives success probability at least p_min=p0 s0 and normalized
Bell infidelity at most `(2v+v^2)/s0`. Since s0<=1/2 and
`v<=s0/4096`, this is strictly below 1/1024.

Reference success indicators are iid because both the reference and the
pair instruments factor. Conditional on all flags, the successful qubit
marginals are iid copies of the same success state. Selecting the first
4m_N successes preserves that product marginal. This is a property of
the known reference, not certification of the actual correlated source.

For m_N=floor(p_min N/8), count shortage is at most
`exp(−p_min N/8)`. Each bit or phase comparison error probability is
at most the Bell infidelity, 1/1024. With test threshold 1/256, the gap
is 3/1024, and the union of the two sample failures is at most
`2exp(−9m_N/524288)`. The stated lower bound on reference acceptance is
therefore correct. For sufficiently large N the code exists, acceptance
tends to one, and accepted Bell bits per input pair tend to p_min/8.
No uniform actual-source yield bound is inferred. Small N can all-abort.

An arbitrary separable actual source can abort with probability one.
It can also false-accept with a small probability; the theorem controls
that weighted event, not normalized quality after an arbitrarily rare
pass. The receiver certifies entanglement in the total available output.
Since arbitrary actual inputs may already be entangled, it cannot by
itself certify net entanglement generated by an amplifier or pump.

## 7. Costs, primary comparison and status

The receiver requires holding the complete block before sampling, an
independent seed not leaked to the source before commitment, exact local
Fock-qubit filters, calibrated X/Z and collective stabilizer operations,
authenticated classical coordination, transcript and failure storage,
and a completed decoder. It consumes half of the selected successes in
tests and another half of the remaining pairs in the half-rate code.
Unused successful pairs and every failure remain counted residuals.
Source, pump, quantum memory, energy, nonthermal controls, disposal/reset,
randomness, messages, physical errors and code acquisition remain costs.
Bounded filters do not bound rejected-mode energy or pump expenditure.
No such implementation or experimental dataset was acquired here.

Primary [Shor–Preskill0003004v1](https://arxiv.org/html/quant-ph/0003004v1)
already analyzes complementary checks followed by entanglement purification
against general attacks, with test/code positions hidden until receipt,
and distinguishes joint acceptance-and-failure from conditional fidelity.
The generic sampling/purification mechanism is established prior art.

[Bouman–Fehr0907.4246v1](https://arxiv.org/html/0907.4246v1), Theorem 3,
proves a general square-root relation from worst-case classical sampling
error to quantum ideal-subspace distance with an external system. Its
framework precedes the generic quantum lift. The present proof uses a
receiver-marginal twirl and then a direct full-extension projection; its
arbitrary normal residual does not require importing a finite-dimensional
environment assumption from that paper.

[Bardenet–Maillard1309.4029v2](https://arxiv.org/html/1309.4029v2),
Lemma 1.1 and Proposition 1.2, explicitly state the convex reduction to
with-replacement sums and the without-replacement Hoeffding bound. Their
text credits the reduction to Hoeffding's Theorem 4 and notes that Chernoff
bounds transfer as well. Thus neither the original bound nor the retained
KL refinement in `FOLLOWUP.md` is a new general concentration principle.

Primary HTML bytes and hashes are retained. The Hoeffding publisher page
was accessible through web search but direct acquisition returned 403.
An attempted nonexistent v3 of Bardenet–Maillard returned 404; checking its
abstract resolved the correct latest v2, which was acquired and read.
Both failures are retained rather than silently replaced. Firecrawl was
reported exhausted by the parent and was not retried.

Historical priority of the exact conservative interface remains UNKNOWN;
the producer makes no generic priority claim. Internal analytic validity,
an executable finite mathematical check, practical code acquisition,
physical validation, net resource gain and mission success are separate.
Only the first two are supported by this checkpoint.

The load-bearing follow-up in `FOLLOWUP.md` strengthens the tail exponent,
improves the actual-residual constant, composes accepted factors across
correlated blocks, and derives an explicit separable-source false-accept
bound. No actual iid or relative-entropy premise is introduced.
