# Fixed-shift clarification for the frozen logarithmic-tail note

24 October 2026. This sidecar leaves FINITE_ENERGY_LOG_TAIL_ENTROPY_BRIDGE.md,
SHA2167da8029a740a937b5ae477a1bf984fd34d4f9b6c02ce001ee02c8bc191e6e,
unchanged. W49 identified the wording issue during fresh reconstruction.
It is not a completed receipt for the remaining proof.

For a density satisfying

    f(r)=C r^-2 (ln r)^-p [1+d/ln r+o(1/ln r)], p>1,

a fixed shift preserves this displayed two-term expansion, with the same
C,d,p. However, with an unrestricted continuous little-o remainder, the
relative change f(r-b)/f(r)-1 need NOT be O(1/r). Only o(1/ln r), together
with the explicit O(1/r) changes of the displayed smooth leading factors,
is needed for the second-order convolution argument in frozen Section6.

For example, at sufficiently large r the positive density factor

    1+sin(2*pi*r)/(ln r)^(3/2)

is allowed by the premise with d=0. A shift b=1/2 changes its relative
value by -2/(ln r)^(3/2)+o((ln r)^(-3/2)) along r=m+1/4. This is not
O(1/r), but it is o(1/ln r). A bounded body can normalize this tail.

The claimed two-term theorem is not strengthened or weakened by this
wording correction: its premise and its required expansion after shifting
are the same. The full actual-quantum/remote-heat/Mellin/convolution proof
remains pending W49's completed fresh receipt at the time of this sidecar.
