# Primary comparison addendum and independent-review binding

2026-10-24. Earlier files remain frozen. This addendum supersedes only their
explicit open retrieval obligations, not their proofs or status boundaries.

## Exact independent-review binding

Read in full and hash-verified:
`work/root/W73_NONADAPTIVE_FOREST_LOWER_REVIEW.md`, SHA256
`d64afa40bee1d27f665324d2b937f3a24c7d26445ed618ffcae7f977524e003e`.
Root's internal conditional PASS covers frozen lower
`92f10ca28af3b945c166bf20de3290b348f58f6f5b6ac8003ae41aae32d124bb`
and direct upper
`ee0680992c18fc63716c0860330848919cd2e8ee97326aa4181cf3350dc188be`,
including checkpoint-2 nulling/progress. It explicitly excludes the later
fast decoder, two-action star corollary and new quantized-baseline argument.
This is correlated model-internal mathematical review, not external review,
priority certification, a hardware trial, or an end-to-end practical gain.

## Previously open final tensor-sketch manuscript found

The author's publication page loads `pubs.json`; its 2015 article entry links
`files/dasarathyCovSketchPreprint.pdf`. That 16-page manuscript bears the final
article title and an acceptance date of 26 November 2014. It is an accepted
author manuscript, not a publisher-formatted final PDF. Directly read Theorem
1, Theorem 2, Corollary 1, the observed-data paragraph and conclusion:
distributed row/column sparsity is still required; additive observed-data
analysis remains future work; the proved robustness treats a perturbation to
the matrix before sketching. The first comparison's open final-manuscript
retrieval obligation is therefore substantially closed. The distinction
between matrix perturbation and sensor noise remains necessary.
[Primary author PDF](https://gautamdasarathy.com/files/dasarathyCovSketchPreprint.pdf).

PDF SHA256 `0c35c6536ea0f2c5d971da448ce1a57ed39701fa405384f06b38d64a2e5c6a91`;
retained author JSON SHA256
`690ca95f983e33ba7295c1da32d2093a80f2bcf79deb9ebba383f7faf8b032d7`.

## Additional closest primary models

**Rayas--Anguluri--Dasarathy, NeurIPS 2022.** The complete published main paper
and supplement were retained. Theorem 1 observes passive potentials
Y=(B*)^-1 X, where X is a latent injection with known covariance. Its support
guarantee uses maximum degree, mutual incoherence and Hessian regularity;
model-complexity constants also enter. This is a strong statistical network
baseline, but a different experiment from chosen common potentials with
independently noisy current outputs. No active forest nulling or all-design
separation was found in its complete main text. This is a bounded reading,
not a universal exclusion.
[Primary proceedings](https://papers.neurips.cc/paper_files/paper/2022/hash/5e0347e19c51cfd0f6fe52f371004dfc-Abstract-Conference.html).
Main PDF SHA256 `7dee5bb3c7dfa3a34df8726849d669ab379c773ccdbbaa102aac349a2ba94bb7`;
supplement SHA256 `152c4e81419370937eac09cc5d6cdc4c70da6380366ab6399e79bf002c326da2`.

**Du--Engelmann--Jiang--Faulwasser--Houska, IFAC 2020.** The complete six-page
author paper uses known grid topology, nonlinear AC power-flow constraints,
generator power excitations, line-power/state measurements and sequential
Fisher-information experiment design. It is additional direct prior art for
active parameter acquisition, with realistic constraints absent from our
abstract interface. Its supplied topology and measurement operator differ;
no claimed worst-case unknown-forest action separation was identified.
[Primary author PDF](https://faculty.sist.shanghaitech.edu.cn/faculty/boris/paper/IFAC2020B.pdf).
PDF SHA256 `6206395eea9cea6aef9f05058e5b60d228e2b5e97a5be290214b063b6b340d81`.

**Rin--Shames--Petersen--Ratnam, latest arXiv:2605.00404v2, September 2026.**
The complete 13-page latest version was read, superseding its May v1 for this
comparison. Theorem 1 requires n-1 full operating points to identify an
arbitrary unknown dense admittance matrix. Theorem 3's one-point tree result
constructs the coefficient matrix using the supplied labelled support, as
confirmed by its IEEE123 example removing non-existent edges beforehand.
Section 4 proposes structured total least squares for noisy voltages and
currents. These exact rank/known-support results do not by themselves acquire
an unknown forest or give a fixed-noise action separation. The rigidity-matrix
connection is explicitly prior art, including the ACC2025 precursor.
[Latest primary](https://arxiv.org/html/2605.00404v2),
[ACC precursor](https://arxiv.org/html/2410.17553v2).
Latest PDF SHA256 `d1c80b02cd0d69ddeaf6937bee97afff5475f28418a7450745838894d059d5e1`;
ACCv2 PDF SHA256 `33db4f11268c966f45dca664a4ebdba2a354cb14d8be371a3709e849c86a3f1f`.

**Talkington et al., final accepted 2026 quantized-network letter.** This is a
particularly close claimed logarithmic-sampling baseline. The separate
`QUANTIZED_BASELINE_TRANSFER_AUDIT.md` records its complete model, the cited
independent-row theorem, and a proved acquired-path parameter-error
obstruction. It must remain in the comparison. Quantization and Gaussian
sensor noise are distinct experiments; no Gaussian-to-quantizer lower-bound
transfer is assumed. The source-specific bridge audit is internal only.

## What remains scientifically open

The exact candidate whose priority remains at issue is the **joint theorem**:
positive bounded-weight unknown forests, fully paid noisy common actions,
topology acquired before component nulling, an all-design nonadaptive
obstruction, and a matched-interface adaptive separation. None of the direct
primary readings establishes that exact joint statement. Retrieval absence
does not establish novelty. General sparse recovery, graph sketches,
experimental design, coding and Gaussian nuisance/Assouad methods remain
established ingredients.

A specialist/external priority review and broader citation closure remain
unperformed. The general forest upper's naive computation is quadratic in n
per certificate pass; the proposed ordinary-code improvement is not part of
root's endorsement. The separate two-action connectivity corollary has linear
arithmetic but awaits a fresh full review and priority comparison. No stable
full-control/full-readout physical instrument was acquired. Duration, resets,
calibration and actual energy costs remain unmeasured. Mission NOT_ACHIEVED.
