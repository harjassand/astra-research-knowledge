# Priority correction: the generic dimension-free polar step is also prior

23 October 2026. Root located and fully read the relevant primary result;
W67 then directly read the official primary Section4.2. This addendum
qualifies the wording of frozen `UNIVERSAL_FOURIER_RECEIVER.md` without
altering its bytes or treating an independent derivation as a novelty claim.

[Elimelech--Albert--Barg, arXiv2608.28962v1](https://arxiv.org/html/2608.28962v1),
Section4.2, Theorem11, equations28 and31--33, already gives the generic
error-set polar/square-root comparison and explicitly retains the coefficient
Hilbert--Schmidt norm in its proof. Proposition12, equation36, also uses the
operator square-root continuity bound. Thus the GENERIC dimension-free
approximate-KL-to-polar-recovery bridge is prior, as are the row-polar
operation and universal error-set recovery. Our independently reconstructed
(F9)--(F10) must not be described as a new generic theorem.

Its coefficient condition is not silently assumed here: the Fourier vector
has norm squared J<=r, and the proof pays that factor throughout. The present
possible contribution is only the explicit finite Fourier span of THIS
physically flushed recurrent model, its centered high-design common-code
construction, valid local helpers and complete finite costs/controls.
Priority even for that composition remains UNKNOWN.

This source must be distinguished from
[Zhao--Xu, arXiv2610.20515v1](https://arxiv.org/html/2610.20515v1), whose
SectionIV row-polar/QSVT representation is also prior. Its particular
general state-weighted error bound contains a reference inverse norm;
that bound is not our proof of logical-dimension-free accuracy. The earlier
2608 paper DOES supply dimension-free generic recovery and must not be
mischaracterized as having only the latter state-weighted limitation.

The source-specific distinction changes priority credit, not the internal
inequalities, finite resource scope, or requirement for fresh independent
review. Physical validation NOT_PERFORMED; practical advantage
NOT_ESTABLISHED; mission NOT_ACHIEVED.
