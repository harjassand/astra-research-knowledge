# Root reconstruction: forward-only coherent variable-depth upload

23 October 2026. **INTERNAL CONDITIONAL PASS** of the native known-root upload theorem below. No load-bearing defect found. This review also records a stronger matched incumbent which supersedes the claimed necessity of physical inverse synthesis for upload. Generic opposite-time uploading is prior art, not an Astra invention. Device-specific priority remains UNKNOWN, apparatus validation NONE, practical advantage NOT_ESTABLISHED, mission NOT_ACHIEVED.

Sources read in full: W64 `COHERENT_VARIABLE_DEPTH_FACTORY_V1.md` SHA256 c544c1a94006cf8619947b852a472da57d04a703a59be3effc74e67580d63c34; its `NORM_AND_PHASE_CLARIFICATIONS.md` 75c36c3a4d49048b52bb4b2493ce7b9971c4381545f6abbc003520b071d00697; and controlling `STRONG_INCUMBENT_OPPOSITE_DOWNLOAD.md` f64ed77a6f427a17aa48da1f0c532d14a183880332af7180b7bb12f60d353249. Native device source remains the e606bfc587c76bdcae8b8fa3ec33e721efa2fbac corpus. Root directly reopened Burgarth--Giovannetti, Full control by locally induced relaxation (2007), https://arxiv.org/html/0704.3027, especially its final Uploading protocol section and Eq.12.

## Contract and construction

The physical infinite bath has native V=alpha U+i beta I, U=U*=U^-1, alpha=sqrt(1-beta^2), fixed 0<=beta<1. A KNOWN seed-X sector x and an independent known root r_x are supplied or separately acquired and charged. The unknown local input F is the entire depth<=H word subspace, may have coherence between distinct word lengths, and may be entangled with an arbitrary laboratory/reference. A known finite local stack permutation U_H and compiled local phases are supplied. This does not supply any physical bath inverse, controlled physical V, bath measurement or bath actuator.

The local finite involution pairs |j,w> with |0,jw> for |w|<=H-1, acts by x on |0,empty>, and completes the colored depth-H boundary arbitrarily. On fresh VACUUM ports every actual U or U* step preserves or decreases depth, so this local completion is never entered. Its coherent action therefore exactly matches the full infinite native vacuum action. A word array, length register, reversible tests/shifts and root sign give a circuit polynomial in H, rather than a free dense matrix on 2^(H+1)-1 amplitudes. Controlled LOCAL U_H is an explicitly controlled known permutation. It does not assume controlled physical V.

Use the adjoint only in that local simulator: L_H=V_H*=alpha U_H-i beta I. Apply it on T fresh vacuum ports in order1,...,T. Then send those prepared ports through the actual physical V in order T,...,1, once each. All later operations involve another port and the bath, so Bob can retain each past output without returning it. The uploader needs exactly T forward calls, zero quantum returns and zero feedback. Keeping every Bob output permits the stronger full-output statement; discarding outputs afterward cannot increase the reduced channel error.

## Uniform analytic proof

In the mathematical infinite-space opposite download let W_-X=L_(P_T X)...L_(P_1 X) and D_-X psi=W_-X(vac_P tensor psi_X). The root Kraus operator is alpha J-i beta I and the colored Kraus operators are alpha S_j*. Its root phase alpha x-i beta has modulus one. On every positive depth, a colored output pops one symbol with probability a=alpha^2; vacuum preserves depth with probability beta^2. The Heisenberg evolution of a depth-diagonal effect remains depth diagonal, so root-arrival is an OPERATOR statement, including all cross-depth input coherences:

    A_-*A_- = diag_w Pr[Bin(T,a)>=|w|] >=(1-tau) I,
    tau=Pr[Bin(T,a)<H], A_-=(<r_x| tensor I_P)D_-.

Let J_- denote the actual coherent uploader and let S map psi_F to root_F tensor vac_P tensor psi_E. The mathematical inverse of the opposite download is precisely the ACTUAL sequence of forward physical V calls described above. Moving it across the target bra yields

    <phi|S*J_-|psi> = <A_- phi|A_- psi>.

This includes the same root phases on both contractions. It does not factor a noisy download into an exact port encoding or normalize a state-dependent successful branch. Since J_- and S are isometries,

    ||J_--S||^2 = ||2I-2A_-*A_-|| <=2tau,
    ||channel(J_-)-channel(S)||_diamond <=2sqrt(2tau).

The operator norm bound is unchanged on tensoring any reference; the complete target includes the emptied F and every output port. For aT>=2H, Chernoff gives tau<=exp(-aT/8). Taking T=ceil max[2H/a,(8/a)ln(128/epsilon^2)] makes the ideal exact-root diamond error <=epsilon/4. Thus physical calls are O_beta(H+ln(1/epsilon)+1), independent of the exponential word-space dimension.

With local compilation operator error e_loc, a local parameter mismatch ||V(beta)-V(beta_tilde)||<=kappa, and an UNHALVED JOINT root-product trace-norm error epsilon_root, a valid additional budget is

    2e_loc + 2T kappa + epsilon_root.

The initialization promise must include its joint laboratory/reference state. A marginal root trace bound in a different half-trace convention cannot silently pay that same epsilon_root. If each actual physical forward call has diamond error eta, add T eta. Local storage, T stack simulations, phase bits/compilation, input-state preparation, root reset and sector identification remain explicitly paid. At beta=1 the bath is inert and the theorem does not apply. No uniform cost is claimed as beta approaches1; no arbitrary unknown seed-sector coherence or old-purifier restoration is obtained.

## Stronger-incumbent correction

The 2007 primary source explicitly constructs the uploader by downloading in a fictitious system with H'=-H and then reversing THAT fictitious protocol with forward actual physics. Root identified that final mechanism as the missing matched comparator, and W64 independently reconstructed it. Our native V* vacuum channel has the same cooling effect as V, so the comparator applies directly with the explicit local simulator above.

Consequently the old recurrence-inverse uploader and the later exact port-phase inverse may remain valid sufficient algorithms, but neither is needed for the best uploader. Its former quadratic-in-T/epsilon call count and backward quantum wire requirement are dominated. The exact inverse is a SEPARATE full-gate control claim whose independent audit is assigned to W49. This review does not endorse that inverse or its restricted query-minimality statement. The generic reverse/opposite-download mechanism is PRIOR; distinct priority of the native dimension-free/succinct implementation statement is UNKNOWN.

## Independent diagnostics and remaining work

Root's `check_opposite_download_factory.py` imports no producer code and directly implements actual native push/pop/root amplitudes. `OPPOSITE_DOWNLOAD_INDEPENDENT_CHECKS.json` records 90 interface cases at H1..3, T=H..H+2, beta0/.2/.6/.8/.99, and both sectors. Complete input-column overlaps equal A_-*A_- to2.29e-16; all-output isometry errors are <=1.12e-15; squared Stinespring errors match2tau. Wrong local adjoint, wrong physical port order and wrong sector are discriminating failed controls. No colored truncation boundary is entered. These finite floating checks support, rather than replace, the analytic proof.

W64 separately constructed a forward vacuum download with a local Bob decoder and a two-stage unknown-input transfer returning the root. Its new sources and diagnostics are not automatically covered by this upload review. Likewise the whole initializer/calibration/distribution process must still be composed under its actual communication permissions and charged costs. This upload alone establishes no fresh-message capacity improvement or hardware advantage. Same-model internal agreement remains correlated.
