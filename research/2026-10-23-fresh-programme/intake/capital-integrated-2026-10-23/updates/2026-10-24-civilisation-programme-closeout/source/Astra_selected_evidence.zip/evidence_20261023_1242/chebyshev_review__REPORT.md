# Independent full-source Chebyshev-normalizer review

23 October 2026, w36. Exact frozen target read in full:
`work/workers/w39_fresh_computation_invention/recurrent/CHEBYSHEV_ACCELERATED_NORMALIZER.md`,
SHA256 `ec82f0197ce7a0a2d598220c3857a7d6a15e6fb7112f5c7376292fae1c4bea68`.
This review was assigned by root. No preferred verdict or producer test
result was adopted. Producer code was not imported or run. Necessary
predecessor proofs were read separately; their earlier V4 rate/integration
rows are not changed or relabeled as newly reviewed here.

Verdict: **NO BLOCKING DEFECT FOUND IN THE FULL HASH-SPECIFIC NORMALIZER
ARGUMENT, CONDITIONAL ON ITS STATED ACQUIRED H/INSTRUMENT/GAMMA CONTRACT**.
This is internal analytic reconstruction with finite diagnostics. It is
not an external/formal correctness certificate, historical-priority result,
executed V4 factory, physical calibration or practical advantage claim.

## 1. Exact interface and full right domain

The inherited access is a known finite local unitary U_B, with its inverse
and fully specified controls, obtained by INPUT-pattern COPY followed by
the physical-H phase/coin instrument. All these circuits are local digital
operations, not actual device/bath queries. Its right input projector Pi_R
requires only the NEW instrument helpers zero. The physical input and
references are unrestricted. Pi_accept tests the NEW accepted coin while
retaining the copied pattern and phase. Thus

    Pi_R U_B* Pi_accept U_B Pi_R = D_tilde/M,
    (3/4)I<=D_tilde<=M I.

The copied pattern must not be uncomputed using the output pattern; that
would give a different instrument Gram. Likewise the previously retained
ORDINARY source phase/coin/purification registers are spectators and are
not part of this new right-space test. This distinction is essential for
applying the normalizer after the source instrument on entangled inputs.

I reconstructed the reflected walk, including its signs. In a principal-
angle plane for squared accepted singular amplitude lambda, R0 is
diag(1,-1) and Rrej=U_B*(I-2Pi_accept)U_B has upper block1-2lambda.
Their product W=Rrej R0 is a rotation with cosine Y=1-2lambda. Its
right compression is therefore T_j(Y), including lambda1 and both
endpoints of the resulting Hermitian contraction. No square root of W,
fractional power, unknown singular-vector basis, Markov-chain sampling
oracle or left-space operation is inserted. Each walk uses two paid
U_B/U_B* calls and explicit helper reflections.

This review assumes the already specified full physical H block and its
legal/illegal extension; it does not reconstruct V4's entropy/drift theorem
or prove a new physical H acquisition. I did check the needed Gamma
qualification: the actual operators preserve legality and commute with
embedded Gamma. Centrality in an arbitrary ambient pattern algebra is
neither true in general nor needed.

## 2. Positive polynomial compression and degree

Setting y=cos(theta) gives ((1+y)/2)^l=cos^(2l)(theta/2).
Expanding its2l exponentials and pairing opposite frequencies yields
exactly the target coefficients: the central binomial mass for j0 and
twice the off-center mass for j>=1. All are nonnegative and sum to1.
Equivalently j has the law|S_(2l)|/2 for a fair sign walk. This is a
classical coefficient law, not a stochastic model for the physical bath.

For j>n, Hoeffding gives the slightly stronger
2exp[-(n+1)^2/l], so the stated2exp[-n^2/l] is valid. The omitted tail
times ||T_j(Y)||<=1 bounds the operator error uniformly on the ENTIRE
right physical domain. The common cutoff n=ceil(sqrt(L h1)), capped atL,
therefore makes the weighted inverse-series error at most2r_L2^(-h1).
When n=L the approximation is exact; no problematic tail formula at l0
is used. h0,h1 and n are computable by integer/rational comparisons.

The inherited inverse binomial-series lower gap gives
(1-tau)I<=P_L D_tilde^(1/2)/sqrtM<=I. Summing positive coefficients
gives r_acc>=1 from the l0 term, and r_acc<=r_L<=2sqrt(L+1).
This is the PAID LCU coefficient sum, not the norm of the desired inverse.
The resulting n=O(sqrtM log(M/epsilon)) replaces
L=O(M log(M/epsilon)) for each normalizer call.

## 3. Literal finite LCU and precision

Prepare j with probabilities b_j/r_acc, SELECT W^j, then unprepare and
require the full right-space output helpers zero. The physical signal
block is exactly P_acc(Y)/r_acc. A threshold loop applying W at step i
iff j>=i uses n sequential controlled walks, with a reversible predicate
and stored reverse circuit. Extra unused index labels can be totalized
unitarily; no measurement or halted-block power is being reused here.
The block norm is at most1 by the positive normalized Chebyshev sum.

Every c_l a_lj has denominator dividing16^L. A direct coefficient table
therefore has O(L+log(L+1)) bits per entry and a polynomial O(Ln)
arithmetic construction. The actual bit-operation count includes the
length of those numbers; it is not simply O(Ln) unit-cost machine work.
Subtree probabilities can be exponentially small, but exact O(L)-bit
rational integers permit computing their normalized ratios and rotations
to absolute accuracy with polynomial working precision. Zero/one subtree
cases are explicit finite gates. O(n) fixed controlled rotations do not
supply free QRAM or a source-Hilbert-space table.

This avoids a normalizer QSP phase-factorization routine. It does not show
that the complete classical compiler is faster than the existing stable
QSVT compiler: the coefficient arithmetic and all angle synthesis remain
paid. Only a constructive alternative is established.

## 4. Source order, retained purification and probability

The ordinary accepted source instrument FIRST acts on Gamma and retains
its own phase. The new normalizer acts AFTER it on the physical half.
The complete good density is

    Gamma P_acc B_tilde P_acc/(M T_max r_acc^2).

B_tilde and D_tilde need not commute. Actual Gamma commutators and the
pinching trace identity, not B/D commutation, justify this expression and
its normalization. Comparing to P_L with the SAME denominator r_acc
gives squared norm N_L/(T_max r_acc^2), with
N_L in[(1-tau)^2,1]. The comparison vector need not itself be an available
block on arbitrary inputs; it is a mathematical norm reference only.

If E=||P_acc-P_L||, the ordinary accepted K vector has norm at most1/sqrt
T_max. Its perturbation is at most E/(r_acc sqrtT_max), while the P_L
comparison vector has norm at least(1-tau)/(r_acc sqrtT_max). Thus the
relative error is E/(1-tau), with no missing sqrtM or forgotten coefficient
normalization. h1 makes this at most epsilon/192. Normalizing vector
states costs at most four times this in full trace norm, so epsilon/48
is valid even for the FULL retained accepted purification. The inherited
P_L error4tau=epsilon/16 is separate.

The same reverse triangle inequality, r_acc^2<=4(L+1), and the conservative
constants imply p_good>=1/[16T_max(L+1)]. Using the weaker explicit
amplifier lower bound1/[32T_max(L+1)] is safe. The amplification is of a
KNOWN local source with explicit success tests and reversible preparation,
not an unknown logical message. Its failure is kept as a CPTP default
port state. Paying O(sqrt(T_max(L+1))log(1/epsilon)) preparation/inverse
uses includes its coefficient normalization and success cost.

## 5. Complete controlled-source approximation and M-free stability

I independently reconstructed W30's separately bound M-free stability
lemma. The ordered congruence R=D'^(-1/2)D^(1/2), Sylvester integral for
the noncommuting square roots, and trace-class perturbation bound give
2delta/(a-delta), without a factor||B|| or M. For a1 and
delta<=epsilon/16<=1/4 this contributes at most epsilon/6. No commutation
of D,D' or B,D is introduced. This justifies the improved IDEAL finite
phase-grid tolerance; native circuit error is accounted for afterward.

The Hamiltonian simulator guarantee is a zero-simulator-helper coherent
ISOMETRY guarantee, including adjoints and controls, not global operator
accuracy on dirty simulator helpers. Its block error must be squared to
obtain the requested coherent accuracy. The predecessor qualification and
the elementary Taylor/robust-amplification compiler explicitly pay this.
Ideal physical exponentials leave these dedicated simulator helpers zero
for arbitrary dirty phase/coin/pattern inputs. COPY, reflections, index
controls and source-amplification reflections preserve that zero subspace.
Thus EVERY ideal prefix of the new W-power/LCU/amplifier circuit has
zero simulator helpers. Ideal-prefix/actual-suffix telescoping is valid
for repeated calls and inverses; actual leakage in a suffix needs no new
off-signal assumption. Native gate synthesis has separately charged FULL
operator error. Exact enabling-control signs, including the Hamiltonian
compiler's robust-amplification minus and the intended QPE offset minus,
must both be retained. The supplied control qualification does so.

The polynomial, model, amplification and synthesis budgets sum strictly
below epsilon. Physical-port legalization followed by exact total-Q
pinching is CPTP and fixes the ideal target. No final complete-pattern
output dephasing, scalar calibration, stronger entropy tolerance or V4
variance guarantee is imported.

## 6. Charged sufficient cost and prior challenge

Per complete source preparation the normalizer uses O(n) instruments.
Amplification multiplies by O(sqrt(T_max L)log(1/epsilon)), giving
sqrt(T_max) M times logarithmic factors in K/K* queries. With M-free
stability, T_pe=O((M/epsilon)log(M/epsilon)). Every binary QPE evolution
time is included: the sum of normalized times is O(T_pe), not merely
the number of phase bits. The elementary Hamiltonian compiler then gives
the sufficient acquired-H query class

    sqrt(T_max) M^2/epsilon times logarithmic factors.

The local G_H cost, multi-controls, arithmetic, coefficient bit operations,
rotation synthesis and complete gate descriptions accompany or multiply
this query bound. For V4 M=O(k), they remain polynomial in represented
inputs and inverse error in the stated model. The bound is not a total
runtime optimum, wall-clock measurement, polylog-accuracy factory or
physical energy estimate. The old elementary Taylor route remains valid
with its worse M^(5/2)/epsilon class. The rectangular QSVT route already
has the same new sufficient query class; this note changes the compiler
alternative, not that incumbent class or the frozen V4 multiplicity onset.

I reopened the primary Apers--Sarlette QFF paper, arXiv1804.02321v2,
https://arxiv.org/pdf/1804.02321. Proposition1, equations5--7, Lemma3,
and Theorems2--3 already provide the projected Chebyshev walk, positive
random-walk coefficient expansion, tail cutoff, LCU and normalization-
dependent amplification mechanism. Those generic ingredients are prior.
The present evaluated use supplies a concrete rejected-instrument walk
and pays its source-specific coefficient sum, state order and precision.
No generic matrix-algorithm novelty follows. Historical priority of the
device-specific composition and matched practical value remain UNKNOWN.

## 7. Independent finite diagnostics and explicit limits

`check_chebyshev_independent.py` imports no producer code. It passed:

- 175 exact rational polynomial identities, including both spectral
endpoints;2080 high-precision coefficient-tail checks; three exact rational
coefficient tables and their common-denominator bit bounds.

- A literal128-dimensional complex projected-unitary LCU, checking the
whole right domain: walk residual4.29e-15, good block residual5.69e-16,
unitarity residual4.25e-14.

- Three actual finite physical-H phase instruments at M8/32/128, with
nonuniform Gamma, retained phase/reference purifications and NONCOMMUTING
B_tilde,D_tilde. They check copied-input Gram, relative source error,
pinching normalization, coefficient-normalized probability and M-free
model comparison. They do not merely test a scalar eigenvalue surrogate.

- Eighteen integer parameter/phase-grid cost fixtures.

Negative controls are discriminating: a reversed reflection sign changes
the walk block by1.38; forgetting r_acc changes it by1.51; output-pattern
uncopy gives Gram errors0.38--0.44; normalizing BEFORE rather than AFTER
K changes full retained sources by0.29--0.66 in trace norm. These rule out
the tested access/order mistakes. They do not certify every numerical
compiler or the asymptotic cost by finite computation.

Dense matrix eigensolvers are used only to evaluate small diagnostic
targets; they are NOT supplied to the proposed oracle algorithm. The
actual sufficient T_pe from the analytic error bound is separately
computed, not falsely labeled executed when a smaller diagnostic phase
grid is used. The first diagnostic invocation stopped on a checker-only
rational-string parse error before completing its source checks; this
was repaired by exact Fraction parsing. No scientific claim changed.
The final raw record and implementation hashes are frozen separately.

No huge source factory/code, hardware, calibration, efficient useful
encoder, external validation or end-to-end practical advantage was acquired.
Programme mission remains NOT_ACHIEVED.
