"""Bind the new cold compact-prior proof/review without editing targets."""
from pathlib import Path
import hashlib
import json

HERE=Path(__file__).resolve().parent
SPACE=HERE.parents[3]
TARGET=SPACE/'work/workers/w73_fresh_foundational_inventor'


def bind(path):
    b=path.read_bytes()
    return {'path':str(path.relative_to(SPACE)),'bytes':len(b),
            'sha256':hashlib.sha256(b).hexdigest()}


expected={
    'COMPACT_PRIOR_FOREST_LOWER.md':'45421a5832a0453574a2251c9bb9c3c6c5ef6c7e7ae7e493236d69343aeaab2c',
    'TWO_ROUND_STAR_COROLLARY.md':'2220c100071a2f0009d9b671564dffd0a1d13b11a48ff9642014a9bb8f51e17e'}
targets=[]
for name,sha in expected.items():
    b=bind(TARGET/name)
    assert b['sha256']==sha
    targets.append(b)
raw=json.loads((HERE/'COLD_COMPACT_PRIOR_RESULTS.json').read_text())
assert raw['source_hashes']==expected
assert raw['checker_sha256']==bind(HERE/'check_cold_compact_prior.py')['sha256']

result={
    'worker':'w39_fresh_computation_invention','date':'2026-10-24',
    'status':'POSITIVE_COLD_INTERNAL_FULL_PROOF_RECONSTRUCTION_IN_STIPULATED_SENSING_MODEL',
    'targets':targets,
    'cold_provenance':'Only the two exact sources and the named primary method paper read before own derivation/checker. No producer replay/output/report/result, old Gaussian lower proof, root derivation or peer verdict read/imported/run.',
    'main_theorem':{'condition':'Even n>=4, a,sigma>0, q>=1 nonadaptive full actions; every realized independent design has per-vertex sum_t x_ti^2<=B; worst-case promised-input connectivity risk<=delta<1/2.',
                    'necessary_bound':'q[pi^2+8a^2B/sigma^2]>=n(1-2delta)^2',
                    'scope':'Positive forest weights in[a,3a]; full nq observation, unlimited decoder computation/real precision; exact common hub/partition metadata may be granted after design commitment.',
                    'fixed_input_order':'Hard prior independent of design randomness, not graph selected after realized design.'},
    'critical_steps_reconstructed':['Endpoint regularity and finite exact scalar J=pi^2/a^2 despite unbounded score.',
        'Full-data test-function IBP and conditional-score projection.',
        'Arbitrary rectangular/rank-deficient quadratic minimization without posterior identification.',
        'Exact comparison-matrix leaf elimination/hub Schur complement.',
        'Uniform hidden-label ridge averaging with exact pathwise row-budget constants.',
        'Common design/metadata averaging and location Fisher-to-TV integral without finite-shift KL claim.',
        'Risk only at promised absent/present endpoints, then fixed-input testing conclusion.'],
    'separate_two_round_target':{'status':'POSITIVE_INDEPENDENT_RECONSTRUCTION_OF_EXACT_2220c_SCOPE',
        'promise':'Only two equal-size hidden stars plus optional known-weight a hub edge; arbitrary fixed leaf weights in[a,3a].',
        'guarantee':'Under exact finite conditions(A), 2 adaptive complete actions,2n scalar readings, pathwise B<=1/2,O(n) ideal arithmetic, worst-case connectivity risk<=delta.',
        'not_claimed':'No two-action full support or general-forest recovery.'},
    'matched_combination':{'parameters':'Fixed delta in(0,1/2), fixed positive r=sigma/a<=1/sqrt(32ln(2/delta)), sufficiently large even n, SAME B=1/2.',
        'nonadaptive_bound':'q>=n(1-2delta)^2/(pi^2+4/r^2)',
        'adaptive_actions':2,
        'conclusion':'Linear-in-n nonadaptive versus constant adaptive full-action counts on the specialized connectivity promise, equivalently Omega(n^2) versus2n scalar acquisitions.'},
    'exact_controls':{key:raw['exact'][key] for key in ['rectangular_quadratic_minimizations','full_nq_inverse_Schur_equalities','metadata_directional_forms_evaluated','ridge_Sherman_Morrison_identities','exhaustive_ridge_average_cases','two_round_star_controls']},
    'exhaustive_metadata_average_cases':len(raw['exact']['exhaustive_metadata_average_cases']),
    'floating_controls':{'status':'NOT_INTERVAL_CERTIFIED_DIAGNOSTICS',
        'full_data_conditional_score_points':raw['floating']['full_data_conditional_score_cases'],
        'max_score_residual':raw['floating']['max_score_identity_residual'],
        'scalar_actual_convolution_Fisher_TV_cases':len(raw['floating']['scalar_actual_convolution_fisher_TV_controls']),
        'max_scalar_refinement':max(x['refinement_difference'] for x in raw['floating']['scalar_actual_convolution_fisher_TV_controls'])},
    'negative_controls':['Omitting ridge factor violates exact scalar example.',
        'Actual non-Gaussian posterior variance depends on data and differs from comparison variance.',
        'Flat compact prior interior score0 fails IBP when nonzero boundary terms are ignored.'],
    'evidence':{'pre_diagnostic_proof':bind(HERE/'COLD_PRE_DIAGNOSTIC_RECONSTRUCTION.md'),
                'report':bind(HERE/'REPORT.md'),'reconstruction':bind(HERE/'INDEPENDENT_RECONSTRUCTION.md'),
                'checker':bind(HERE/'check_cold_compact_prior.py'),'raw':bind(HERE/'COLD_COMPACT_PRIOR_RESULTS.json')},
    'primary_method_reopened':{'url':'https://isl.stanford.edu/~cover/papers/transIT/1501demb.pdf',
        'role':'Dembo-Cover-Thomas SectionIII-C Theorem13 and matrix-version pointer; establishes classical method provenance, not exact graph result priority.'},
    'source_method_priority':'UNKNOWN; no exhaustive priority search or generic Fisher/score novelty claim.',
    'physical_boundary':'Exact global control and independent fixed Gaussian full readout are stipulated. O(an) dynamic range and O(1/n) actual preparation accuracy can be required; B is not energy/time. Impedance, sensor loading, reset/calibration unacquired.',
    'actual_unknown_data_or_physical_acquisitions':0,
    'physical_validation':'NOT_PERFORMED','practical_advantage':'UNKNOWN','mission':'NOT_ACHIEVED',
    'critical_uncertainty':'Whether a physically stipulated finite-port instrument retains the ideal full-action/noise/control laws; separately assigned next audit, outside this verdict.',
    'next_decisive_action':'Root inspects this cold proof and the next separately frozen finite-port impedance obstruction. Preserve graph/source-method/hardware scopes.',
    'previous_quantum_and_all_target_bytes_preserved':True,
    'manifest':'MANIFEST.json'}
(HERE/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
names=['REPORT.md','INDEPENDENT_RECONSTRUCTION.md','COLD_PRE_DIAGNOSTIC_RECONSTRUCTION.md',
       'RESULT.json','check_cold_compact_prior.py','COLD_COMPACT_PRIOR_RESULTS.json',Path(__file__).name]
manifest={'scope':'Frozen cold W39 review and newly acquired controls. Target hashes bound separately; excludes this manifest itself.',
          'files':[bind(HERE/n) for n in names],'targets':targets}
(HERE/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
for n in names+['MANIFEST.json']:
    b=bind(HERE/n);print(b['sha256'],b['bytes'],n)

