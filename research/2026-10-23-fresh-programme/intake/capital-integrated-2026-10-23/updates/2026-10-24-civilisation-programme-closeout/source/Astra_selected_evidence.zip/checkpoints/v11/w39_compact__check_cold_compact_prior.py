"""New cold W39 controls for compact-prior lower and two-round corollary.

No producer/peer imports, outputs or replay code are read. Exact matrix,
sampling, topology and budget controls use only Fraction/int. Floating
quadrature is separately labeled and is not interval-certified evidence.
"""
from fractions import Fraction as F
from itertools import combinations, product
from pathlib import Path
import hashlib
import json
import math
import time
import numpy as np

HERE=Path(__file__).resolve().parent
SPACE=HERE.parents[3]
SOURCE=SPACE/'work/workers/w73_fresh_foundational_inventor'


def zero(n,m): return [[F(0) for _ in range(m)] for _ in range(n)]
def eye(n): return [[F(i==j) for j in range(n)] for i in range(n)]
def trans(A): return list(map(list,zip(*A)))
def mul(A,B): return [[sum((a*b for a,b in zip(row,col)),F(0)) for col in zip(*B)] for row in A]
def mv(A,x): return [sum((a*b for a,b in zip(row,x)),F(0)) for row in A]
def dot(x,y): return sum((a*b for a,b in zip(x,y)),F(0))
def quad(A,x): return dot(x,mv(A,x))
def outer(x): return [[a*b for b in x] for a in x]
def plus(A,B): return [[a+b for a,b in zip(r,s)] for r,s in zip(A,B)]
def scale(A,c): return [[c*x for x in row] for row in A]


def inv(A):
    n=len(A);R=[list(row)+rowI for row,rowI in zip(A,eye(n))]
    for j in range(n):
        pivot=next(i for i in range(j,n) if R[i][j])
        R[j],R[pivot]=R[pivot],R[j]
        r=R[j][j];R[j]=[x/r for x in R[j]]
        for i in range(n):
            if i!=j:
                c=R[i][j]
                if c:R[i]=[x-c*y for x,y in zip(R[i],R[j])]
    return [row[n:] for row in R]


def rectangular_checks():
    count=0
    for D in range(1,8):
        for m in range(1,6):
            for kind in range(3):
                H=[[F(((2*i+3*j+kind)%5)-2,3) if kind else F(0)
                    for j in range(m)] for i in range(D)]
                if kind==2:
                    H=[[row[0]]*m for row in H]  # rank-one and dependent columns
                J=F(3+kind,2);ss=F(2+kind,3)
                HH=mul(H,trans(H));C=plus(scale(eye(D),ss),scale(HH,1/J))
                Ci=inv(C)
                Hess=plus(scale(eye(m),J),scale(mul(trans(H),H),1/ss))
                for variant in range(2):
                    v=[F(((i+variant)%4)-1,2) for i in range(D)]
                    # Solve the normal equation independently, then compare
                    # to the C-inverse closed form and its achieved objective.
                    alpha=mv(inv(Hess),[x/ss for x in mv(trans(H),v)])
                    beta=[a-b for a,b in zip(v,mv(H,alpha))]
                    ci_v=mv(Ci,v)
                    assert alpha==[x/J for x in mv(trans(H),ci_v)]
                    assert beta==[ss*x for x in ci_v]
                    assert J*dot(alpha,alpha)+dot(beta,beta)/ss==dot(v,ci_v)
                    assert mv(Hess,alpha)==[x/ss for x in mv(trans(H),v)]
                    count+=1
    return count


def design(n,q,kind):
    if kind==0:return [[F(1,3)]*q for i in range(n)]
    return [[F(((i+1)*(j+2)+kind)%7-3,4+j) for j in range(q)] for i in range(n)]


def metadata(n):
    d=(n-2)//2
    for u in range(n):
        for v in range(n):
            if v==u:continue
            rest=[i for i in range(n) if i not in (u,v)]
            for A in combinations(rest,d):
                C=tuple(i for i in rest if i not in A)
                yield u,v,A,C


def star_matrices(s,M,J,ss):
    n=len(s);q=len(s[0]);u,v,A,C=M
    H=zero(n*q,n-2);ell=0
    S={u:scale(eye(q),ss),v:scale(eye(q),ss)}
    for hub,leaves in ((u,A),(v,C)):
        for leaf in leaves:
            r=[a-b for a,b in zip(s[leaf],s[hub])]
            for j in range(q):H[leaf*q+j][ell]=r[j];H[hub*q+j][ell]=-r[j]
            b=1/(J+dot(r,r)/ss)
            S[hub]=plus(S[hub],scale(outer(r),b));ell+=1
    r_uv=[a-b for a,b in zip(s[u],s[v])]
    direction=[F(0)]*(n*q)
    for j in range(q):direction[u*q+j]=r_uv[j];direction[v*q+j]=-r_uv[j]
    value=quad(inv(S[u]),r_uv)+quad(inv(S[v]),r_uv)
    return H,direction,value


def full_observation_and_average_checks():
    full=0;averages=[];metadata_count=0
    for n in (4,6,8):
        for q in (1,2,3):
            for kind in range(3):
                s=design(n,q,kind);B=max(dot(row,row) for row in s)
                J=F(3+kind);ss=F(2,3+kind)
                values=[]
                for index,M in enumerate(metadata(n)):
                    H,v,val=star_matrices(s,M,J,ss)
                    metadata_count+=1
                    # Full nq-dimensional inverse, not a hub-only datum.
                    should_full=(n==4 and q<=2) or (n==6 and q==1) or (n==6 and q==2 and index%11==0)
                    if should_full:
                        whole=plus(scale(eye(n*q),ss),scale(mul(H,trans(H)),1/J))
                        assert quad(inv(whole),v)==val
                        full+=1
                    values.append(val)
                mean=sum(values,F(0))/len(values)
                bound=F(4*q,n)*(J+8*B/ss)
                assert mean<=bound
                averages.append({'n':n,'q':q,'kind':kind,'metadata':len(values),
                                 'actual_comparison_mean':str(mean),'upper_bound':str(bound)})
    return full,metadata_count,averages


def leverage_checks():
    identities=0;mean_cases=0
    for N in range(3,8):
        for q in (1,2,3):
            rows=design(N,q,2);R2=max(dot(r,r) for r in rows)
            for lam in (F(1,3),F(2)):
                for d in sorted({1,N//2,N-1}):
                    total=F(0);count=0
                    for T in combinations(range(N),d+1):
                        G=scale(eye(q),lam)
                        for j in T:G=plus(G,outer(rows[j]))
                        Gi=inv(G);hs=[]
                        for j in T:
                            h=quad(Gi,rows[j])
                            removed=plus(G,scale(outer(rows[j]),-1))
                            t=quad(inv(removed),rows[j])
                            assert 0<=h<1 and t==h/(1-h)
                            assert t<=R2/lam
                            hs.append(h);total+=t;count+=1;identities+=1
                        assert sum(hs,F(0))<=q
                    mean=total/count
                    assert mean<=(1+R2/lam)*F(q,d+1)
                    mean_cases+=1
    # This false shortcut would lose a load-bearing factor in the theorem.
    t=F(100,101)
    assert t>F(1,2)
    return identities,mean_cases,{'omit_ridge_factor_lhs':str(t),'invalid_rhs':'1/2','detected':True}


def exact_star_controls():
    cases=0;hub_guards=0;second=0;budget=0
    for d in (1,2):
        n=2*d+2;U=0;V=1;A=range(2,2+d);C=range(2+d,n)
        edges_base=[(U,l) for l in A]+[(V,l) for l in C]
        for weights in product((1,2,3),repeat=2*d):
            for theta in (0,1):
                edges=[(i,j,F(w)) for (i,j),w in zip(edges_base,weights)]
                if theta:edges.append((U,V,F(1)))
                for bits in product((0,1),repeat=n):
                    x=[F(b,2) for b in bits];y=[F(0)]*n
                    for i,j,w in edges:
                        value=w*(x[i]-x[j]);y[i]+=value;y[j]-=value
                    for hub,leaves in ((U,A),(V,C)):
                        k=sum(bits[l]!=bits[hub] for l in leaves)
                        assert abs(y[hub])>=F(k,2)
                        if 4*k>=d:
                            assert abs(y[hub])>=F(d,8);hub_guards+=1
                    assert all(abs(y[l])<=F(3,2) for l in range(2,n))
                    # Every possible selected index, even if wrong, obeys
                    # pathwise row energy <=1/2 after action2.
                    for selected in range(n):
                        assert all(x[i]**2+F(i==selected,4)<=F(1,2) for i in range(n));budget+=1
                    cases+=1
                for selected,other in ((U,V),(V,U)):
                    x=[F(0)]*n;x[selected]=F(1,2);y=[F(0)]*n
                    for i,j,w in edges:
                        value=w*(x[i]-x[j]);y[i]+=value;y[j]-=value
                    assert y[other]==-F(theta,2);second+=1
    return {'full_first_action_cases':cases,'conditional_hub_signal_checks':hub_guards,
            'pathwise_all_selected_vertex_budget_cases':budget,'second_action_signal_cases':second}


def ceil_log2_positive(x):
    x=F(x);j=0
    while (x.denominator<<j)<x.numerator:j+=1
    return j


def star_finite_guards():
    error=F(1,10);ratio=F(1,20);rows=[]
    # Integer log upper bounds make these deliberately sufficient, not
    # decimal evaluations of the transcendental guards.
    for k in (8,12,16,20):
        n=2**k+2;d=(n-2)//2
        log_noise=ceil_log2_positive(2/error)
        log_hubs=ceil_log2_positive(8/error)
        log_readout=ceil_log2_positive(8*n/error)
        assert ratio**2*32*log_noise<=1
        assert d>=8*log_hubs
        assert F(d-12)**2>16**2*ratio**2*2*log_readout
        # Matched B=1/2: pi²<10 only weakens the lower. This constant
        # can therefore be certified with rational arithmetic.
        necessary_q_lower=F(n)*(1-2*error)**2/(10+4/ratio**2)
        rows.append({'n':n,'d':d,'sigma_over_a':str(ratio),
                     'delta':str(error),'log2_upper_bounds':[log_noise,log_hubs,log_readout],
                     'matched_B':'1/2','conservative_q_nonadaptive_lower':str(necessary_q_lower),
                     'adaptive_actions':2,'adaptive_scalar_acquisitions':2*n})
    return rows


def prior_nodes(N,flat=False):
    u,w=np.polynomial.legendre.leggauss(N)
    mass=w*(np.ones_like(u)/2 if flat else np.cos(np.pi*u/2)**2)
    score=np.zeros_like(u) if flat else -np.pi*np.tan(np.pi*u/2)
    return 2+u,mass,score


def conditional(H,y,sigma,N=96,flat=False):
    # m=1 or2 actual non-Gaussian latent coordinates.
    m=H.shape[1];w,weights,scores=prior_nodes(N,flat)
    grids=np.meshgrid(*([np.arange(N)]*m),indexing='ij')
    indices=np.stack([x.ravel() for x in grids],axis=1)
    W=w[indices];pw=np.prod(weights[indices],axis=1)
    rho=scores[indices]
    residue=y[None,:]-W@H.T
    log_kernel=-np.sum(residue**2,axis=1)/(2*sigma**2)
    scaled=pw*np.exp(log_kernel-log_kernel.max());scaled/=scaled.sum()
    sY=np.sum(scaled[:,None]*(-residue/sigma**2),axis=0)
    sW=np.sum(scaled[:,None]*rho,axis=0)
    mean=np.sum(scaled[:,None]*W,axis=0)
    covariance=(W-mean).T@(scaled[:,None]*(W-mean))
    return sY,sW,covariance


def quadrature_controls():
    score_cases=0;max_error=0.0;max_refinement=0.0
    # Full n=4 data, with all4 vertices observed. Two independent leaf
    # weights have actual cos² density, not a Gaussian substitute.
    s=design(4,1,1)
    H,_,_=star_matrices(s,(0,1,(2,),(3,)),F(3),F(1))
    H=np.array(H,dtype=float)
    for sigma in (0.5,1.,2.):
        for j in range(12):
            y=np.array([math.sin((i+1)*(j+2))*2.3 for i in range(4)])
            sy,sw,_=conditional(H,y,sigma,96)
            sy2,sw2,_=conditional(H,y,sigma,128)
            e=float(np.max(np.abs(sw-H.T@sy)))
            ref=max(float(np.max(np.abs(sy-sy2))),float(np.max(np.abs(sw-sw2))))
            max_error=max(max_error,e);max_refinement=max(max_refinement,ref);score_cases+=1
    assert max_error<1e-9 and max_refinement<1e-9
    # Actual posterior variance is not the fixed Schur/comparison matrix.
    post=[];target=1/(math.pi**2+1)
    for y in (2.,4.):
        sy,sw,cov=conditional(np.ones((1,1)),np.array([y]),1.,128)
        post.append(float(cov[0,0]))
    assert abs(post[0]-post[1])>1e-4
    assert min(abs(x-target) for x in post)>1e-3
    # Uniform compact density has nonzero boundary terms. Treating its
    # interior score as0 makes the purported identity fail away from center.
    sy,sw,_=conditional(np.ones((1,1)),np.array([3.]),0.5,128,True)
    boundary_counter=float(abs(sw[0]-sy[0]));assert boundary_counter>0.1
    scalar=[]
    for h in (0.,0.5,1.,2.):
        for sigma in (0.5,1.,2.):
            pairs=[]
            for Nw,Ny in ((80,320),(160,640)):
                W,mass,_=prior_nodes(Nw)
                lo=h-12*sigma;hi=3*h+1+12*sigma
                z,ww=np.polynomial.legendre.leggauss(Ny)
                yy=(hi+lo)/2+(hi-lo)/2*z;ww=ww*(hi-lo)/2
                residual=yy[:,None]-h*W[None,:]
                kernel=np.exp(-residual**2/(2*sigma**2))/(math.sqrt(2*math.pi)*sigma)
                dens=kernel@mass;deriv=((-residual/sigma**2)*kernel)@mass
                fisher=float(np.sum(ww*deriv**2/dens))
                # Split the L1 integral at the exact symmetry crossing,
                # avoiding an absolute-value cusp in one Gauss panel.
                crossing=2*h+0.5;tv=0.0
                for aa,bb in ((lo,crossing),(crossing,hi)):
                    yp=(aa+bb)/2+(bb-aa)/2*z;wp=ww*(bb-aa)/(hi-lo)
                    rr=yp[:,None]-h*W[None,:]
                    f=np.exp(-rr**2/(2*sigma**2))@mass/(math.sqrt(2*math.pi)*sigma)
                    g=np.exp(-(rr-1)**2/(2*sigma**2))@mass/(math.sqrt(2*math.pi)*sigma)
                    tv+=float(np.sum(wp*np.abs(f-g)))/2
                comparison=1/(sigma**2+h*h/math.pi**2)
                assert fisher<=comparison+1e-9
                assert tv<=0.5*math.sqrt(fisher)+1e-9
                pairs.append((fisher,tv,comparison))
            scalar.append({'h':h,'sigma':sigma,'fisher':pairs[-1][0],
                           'comparison_upper':pairs[-1][2],'TV_shift_one':pairs[-1][1],
                           'refinement_difference':max(abs(x-y) for x,y in zip(*pairs))})
    return {'status':'FLOATING_DIAGNOSTICS_NOT_INTERVAL_CERTIFICATES',
            'full_data_conditional_score_cases':score_cases,
            'max_score_identity_residual':max_error,'max_score_refinement_difference':max_refinement,
            'posterior_substitution_negative_control':{'actual_variances_at_y2_y4':post,'fixed_comparison_variance':target,'detected':True},
            'nonvanishing_boundary_negative_control':{'uniform_prior_score_identity_failure':boundary_counter,'detected':True},
            'scalar_actual_convolution_fisher_TV_controls':scalar}


def main():
    start=time.time()
    rectangular=rectangular_checks()
    full,metacount,averages=full_observation_and_average_checks()
    ridge,ridgemeans,negative=leverage_checks()
    exact={'rectangular_quadratic_minimizations':rectangular,
           'full_nq_inverse_Schur_equalities':full,'metadata_directional_forms_evaluated':metacount,
           'exhaustive_metadata_average_cases':averages,'ridge_Sherman_Morrison_identities':ridge,
           'exhaustive_ridge_average_cases':ridgemeans,'ridge_factor_negative_control':negative,
           'two_round_star_controls':exact_star_controls(),'two_round_finite_guards':star_finite_guards()}
    floating=quadrature_controls()
    result={'status':'PASS_COLD_EXACT_CONTROLS_AND_SEPARATE_FLOATING_DIAGNOSTICS',
            'provenance':'Target sources and primary method paper only before code. No producer or peer code/output imports or reads.',
            'exact':exact,'floating':floating,'runtime_seconds':time.time()-start,
            'source_hashes':{n:hashlib.sha256((SOURCE/n).read_bytes()).hexdigest() for n in ['COMPACT_PRIOR_FOREST_LOWER.md','TWO_ROUND_STAR_COROLLARY.md']},
            'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'scope':'Finite controls supplement the universal independent proof. No unknown-data acquisition, device experiment or full-support adaptive proof.'}
    (HERE/'COLD_COMPACT_PRIOR_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'rectangular':rectangular,'full_inverse':full,
                      'metadata_forms':metacount,'ridge_identities':ridge,'ridge_means':ridgemeans,
                      'star_cases':exact['two_round_star_controls'],
                      'score_residual':floating['max_score_identity_residual'],
                      'seconds':result['runtime_seconds']},indent=2))


if __name__=='__main__':main()

