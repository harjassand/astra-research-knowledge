# The finite loader programs can be acquired through the same device

23 October2026, w64. Addendum to frozen initialization proof28008c7e..., its mandatory sign correction38995aa2..., and clarification021461ee.... The colored two-call carrier is the inherited Dyck excursion used in the reverse-encoder baseline; the present lemma charges its positive-beta HERALDED use to prepare a KNOWN resource, rather than assuming new A:B program preshares. Generic heralded communication/retry is established. Device-specific application/priority UNKNOWN. Independent criticism PENDING.

## 1. Exact all-bath two-call success operator

Embed a qubit in colored input states |j>, j=1,2, followed by a vacuum input |0>. Let the native two-call interaction be W=V_(2,E)V_(1,E), with a=1-beta^2. Bob measures the single success projector

    P_success=|0><0|_(B1) tensor q_(B2).

The exact operator identity is

    (P_success tensor I_E) W (|j,0> tensor |psi>_E)
         =a |0,j> tensor |psi>_E.                   (A1)

The double-U term pushes j then pops the same j using S_k* S_j=delta_kj I. Its first output is0 and its second is j. The term with only the first U has output00. Terms with identity in the first call have first output j!=0. Thus no other amplitude enters the success subspace, even at the physical root or with coherent bath/external entanglement. This proves(A1) for every normal joint bath/purifier state and arbitrary qubit entanglement, by linearity and continuity.

Success has probability a^2, independent of the unknown qubit AND the entire bath resource. On that branch the qubit is transferred coherently, with the whole bath and all its previous correlations unchanged. Bob does NOT measure the color. He sends the success/failure bit through the permitted backward classical wire. The two actual forward calls and both outcomes are charged.

A failure may destroy an UNKNOWN qubit. Therefore(A1) alone is NOT a repeatable zero-error unknown-message channel, and failure outcomes may not be discarded when reporting a message fidelity. The following use is legal because the complete resource state being distributed is KNOWN and the fresh logical M is untouched.

## 2. Acquiring one known bipartite program

For a finite loader program |prog>_(Alice,Bob) in(L7), let m=ceil(log2 dim Bob), using a fixed qubit padding of Bob's finite register. Alice prepares the ENTIRE KNOWN program in her own laboratory, with the intended Bob register initially local. She sends these m qubits one after another through(A1). If any success flag fails, Alice and Bob discard the entire current program and all already transferred portions, then Alice prepares a new known copy. No cloning or reconstruction of an unknown source is assumed.

One complete distribution attempt succeeds with probability exactly a^(2m), for ANY starting bath state. Conditional on all m successes, it produces the prescribed bipartite program EXACTLY and the bath action is scalar identity. Consequently the successful program factorizes from the bath, provided its freshly prepared local state did so initially. Prior failed programs may have changed the bath arbitrarily, but are discarded; they do not change the next complete-attempt success probability.

Cap the number of complete attempts at J. The cap-failure probability is at most

    (1-a^(2m))^J <= exp[-J a^(2m)],                 (A2)

and all its probability remains in the abort/default output branch. The maximum forward call cost is2mJ, with early failure possibly using fewer calls. Choosing J>=a^(-2m)ln(1/epsilon) makes the program-distribution error probability at most epsilon. The case m=0 needs no distribution or retries.

## 3. Acquiring every loader program and preserving the reset bound

After the initial unknown-tail root reset and the sector probe of the main proof, acquire the R finite independent programs needed by the loader. Fresh complete programs are always prepared locally and independently of all previous bath/failed registers. By induction, every successfully distributed program is factorized from the bath; later distribution steps act only on the bath and the new program, leaving earlier programs unchanged. Distinct successful programs are the prescribed independent copies.

With J complete attempts per program, the failure probability over all R distributions is at most R exp[-J a^(2m)]. Their total forward call count is at most

    D=2mJR.                                        (A3)

Starting at root in the ideal comparison, bath depth after these calls is at most D, even on failed intermediate attempts. The actual native interaction changes length by at most1 per call; its identity term does not increase that bound. A vacuum reset of T_D calls then returns the bath within unhalved trace distance

    2sqrt(Pr[Binomial(T_D,a)<D])                    (A4)

of its known-sector root. The acquired programs remain independent of that bath and are untouched by this reset. Include the original first unknown-tail reset error by contractivity/hybrid comparison as in the main proof; no new uniform unknown-normal-tail claim is needed.

Now run the finite loader exactly as before. The whole acquisition uses only local known-state preparations, actual forward device calls, Bob's local flag measurements and backward CLASSICAL bits. It requires neither newly supplied A:B entanglement, direct bath control, unknown-state postselection credit nor quantum backward transmission. All capped failures, resource copies, calls and resets count. The flags and their timings precede action on the fresh M.

The enlarged per-tolerance cost

    C_epsilon <= seed_probe_calls + D + T_D
                     +R(H+T_H)                     (A5)

is finite, with typically very poor dependence on H,dim Bob,beta,epsilon. In particular program acquisition scales exponentially with m through a^(-2m), in addition to the loader's a^-H behavior. The diagonal o(N) choice in the main theorem remains possible for every FIXED normal target, because each fixed approximation still has finite cost. Exact total call count is obtained by the same post-decoding dummy-call padding; aborts remain in the output.

## 4. Exact scope of the strengthened comparison

The main loader reduction no longer needs newly supplied bipartite program copies: they can be acquired by(A1)--(A5). If an ORIGINAL body protocol uses only a FIXED normal eta_(E L_A L_B) and otherwise local ancillas, then its reliable rate can therefore be matched from an independent normal bath with NO initial A:B entanglement, retaining backward classical feedback. Fixed normal eta may itself have infinite initial entanglement; finite normal approximations plus a sufficiently slow diagonal schedule cover it without claiming an effective convergence rate.

If the original body additionally assumes arbitrary N-dependent independent A:B preshares as a free common resource, those remain a common permission. This addendum does not synthesize an arbitrary linear or superlinear amount of such body presharing in o(N) calls. It removes only the finite per-approximation programs introduced by the loader. Nor does it remove the backward classical wire, simulate no-feedback capacity, restore the original inaccessible purifier G, or cover unrestricted eta_N.

Known finite local program compilation, the target resource description and control precision remain supplied abstract capabilities. Hardware/energy/reset heat and computational efficiency are UNACQUIRED. No positive-beta capacity coefficient, useful physical advantage or general acquisition/intelligence result follows. Mission NOT_ACHIEVED.
