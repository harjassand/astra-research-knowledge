# Root analytic review of the finite global-clock currency inequality

23 October 2026. **INTERNAL CONDITIONAL PASS; no load-bearing defect found** at the stated finite-device and paired-MC/Bob-work scope. This is an analytic reconstruction, not external or formal certification. Same-model review remains correlated. No unrestricted second-order LOCC converse, efficient implementation, physical validation, priority or broad mission completion is inferred.

Exact reviewed proof: `work/workers/w18_entropy_coefficient/frontier_rate/MERGING_GLOBAL_CLOCK_CURRENCY.md`, SHA256 `79062b0921296d6b8a62709e99edee060985b64e86de1cad5a1995be9d79ce87`. Exact source-weighted stock-bill prerequisite read and reconstructed: `STOPPED_CLASSIFIER_NET_COST_BARRIER_v2.md`, SHA256 `454824a0ec2ce7912bcbd47c52b612e5b186c26d6a4f388a7cfea43ad2566df9`. These use the original finite source at corpus e606bfc587c76bdcae8b8fa3ec33e721efa2fbac, not a substituted clock or a different MC input.

## Finite-device proof

Fix the entire r-wide finite TP LOCC device and finite source D,L,p before any limit. Its retained Q=A:B is arbitrary. The exact input Bell stock has rank S and is independent of the complete source; a separate returned Bell port has rank P and unconditional infidelity gamma<1/2. Write I_c=S(B)-S(AB), B_supply=E K ln D and v_P(gamma)=(1-gamma)ln[(P+1)/2]-h2(gamma). The proposed inequality, for every finite mathematical global POVM Y on Q, is

    I_c(Q)+I(K^r:Y)+v_P(gamma) <= r B_supply+ln S.

The stock-bill prerequisite is valid on the actual original source. Conditional on the unchanged source clocks, a separable effective terminal effect has its actual-input probability at most S D^(sum k) times its all-white-input probability. This is the maximally-entangled overlap bound after tracing white native positions. Averaging its logarithm gives the source-weighted information radius r B_supply+ln S, rather than a dimension-only r L ln D allowance. The all-white comparison includes the input Bell stock and remains separable. Finite LOCC Bell verifiers on separate returned ports have separable pass probability <=2/(rank+1) on the comparison's OWN conditional history. Divergence chain rule, entropy concavity and their actual unconditional Bell infidelities give the sum of the separate v terms. Nonselective tests on other ports preserve each tested actual marginal. No independence of actual output ports is required. Keeping the separate gamma ln P term is essential.

Repeat this ONE finite device independently m times. Its Q-block states are iid across m, while no iid structure within the original r-wide output is asserted. Add and charge an exact independent Phi_C per block, with ln C>-I_c. The conditional entropy of Alice's Q_A C_A given Bob's Q_B C_B is -I_c-ln C<0. Reference-preserving state merging of these fixed finite block states transfers Q to Bob and generates a deterministic Bell rank N_m with ln N_m/m approaching I_c+ln C-delta, for arbitrary fixed positive slack delta. Its error tends to zero. All actual clocks, original return ports and residual systems can be included in the reference; transferring the original auxiliary C halves to Bob supplies no second entanglement credit.

Bob may now apply Y locally. Complete-reference merging error bounds the actual clock/outcome law, and conditional-entropy continuity on the fixed per-block K alphabet gives I(K^(rm):Y^m)/m -> I(K^r:Y). This uses the growing clock dimension correctly: its error contribution divided by m is a constant times the merging error, which tends to zero. Other merger messages only increase transcript clock information.

Merging and Y do not act on the old return ports, so every old return marginal retains infidelity gamma. Apply the source-weighted bill to the whole finite experiment, charging S^m C^m and verifying each old P port separately plus the new N_m port. The new verifier's loss is o(m) because its error tends to zero and ln N_m=O(m). Divide by m, cancel the charged ln C, and then let delta decrease to zero. This proves the exact inequality for the originally fixed finite device, including negative I_c. There is no original-source asymptotic-capacity premise, no recycled reserve and no exchange of a growing source-family limit.

## Paired-MC identity and actual-clock measurement

For Gamma=sum_ab |aa><bb| tensor R_ab on A:B_0 W_B, Alice pinching gives the separable density tau=sum_a |aa><aa| tensor R_aa. Its nonzero spectrum equals Gamma_(B_0 W_B). The pinching relative-entropy identity gives D(Gamma||tau)=I_c(Gamma). One-way hashing lower-bounds distillable entanglement by I_c, while separable relative entropy upper-bounds it. Thus E_D=E_R=I_c>=0, including tensor-power additivity. This is an established premeasurement/maximally-correlated class, not a new general resource identity. No extra Alice shield is included.

Conditional on each actual clock vector, the stated target has pure original Bell prefixes and an arbitrary computationally diagonal MC suffix; the latter may have cross-site/cross-queue correlations. A global MC Fourier-phase measurement produces deterministic phase zero at live sites and a uniform independent phase string on the suffix, because every diagonal paired string has the same squared Fourier overlaps. A complete POVM can include the orthogonal-complement outcome on the full data space; that extra outcome has zero probability on the target but permits applying the same channel to a nearby non-MC actual state.

Let F_i be the first nonzero phase position minus one, or L on overflow, and G_i=F_i-K_i. Then G_i is a capped geometric count of zeros, E G_i<=q/(1-q), q=1/D. Since K is determined by F and G, conditional entropy and subadditivity give H(K^r|Y)<=sum_i H(G_i)<=r c(q). The proof never presumes that this global measurement is free LOCC: it becomes local only after the paid merger. The actual K marginal remains p^tensor r.

## Approximation and net stock

For joint half-trace error beta to such a target, Winter's conditional-entropy bound uses only d_A=D^(Lr): I_c(actual)>=I_c(target)-2 beta r L ln D-g(beta). It need not pay the finite but arbitrarily large dimension of Bob's work. Classical conditional-entropy continuity after the same phase POVM loses at most beta r ln|supp p|+h2(beta), because the actual clock marginal is unchanged. Combining these bounds with the exact finite-device inequality proves source Eq.(10), including its finite F_r(beta). Algebraically replacing the verifier value by ln P costs at most gamma ln P+h2(gamma)+ln2, proving Eq.(11). For fixed source, beta_r->0 gives F_r=o(r); approximate huge stock still needs gamma_r ln P_r=o(r). Exact stock has gamma=0 without an uncharged dimension-continuity assumption.

The target restriction is load-bearing: arbitrary receivers may erase the original clock/data form, create non-MC states, or keep useful quantum shields on both sides. None is excluded by this proof. The original input itself does not supply high I_c and readable clock simultaneously. The unrestricted H-O(1) second-order problem remains open.

## Primary literature and claim boundary

Root directly reopened the following primary sources for this reconstruction:

- Horodecki--Oppenheim--Winter, Quantum state merging and negative information, https://arxiv.org/pdf/quant-ph/0512247v1 . Reference-preserving merging and the conditional-entropy entanglement rate are established prerequisites.
- Ye--Bai--Lin--Wang, Exploration of nonlocalities in ensembles consisting of bipartite quantum states, Phys.Rev.A81,014303(2010), https://hub.hku.hk/bitstream/10722/80563/1/Content.pdf . Theorem1 explicitly uses merging followed by global distinguishability and an entanglement charge. That generic strategy and the net-entanglement interpretation are PRIOR.
- Winter, Tight uniform continuity bounds for quantum entropies, https://arxiv.org/pdf/1507.07775v6 , Lemma2. The conditional-entropy continuity constant depends on Alice's dimension, not Bob's work dimension.
- Coles, Collapse of the quantum correlation hierarchy links entropic uncertainty to entanglement creation, https://arxiv.org/abs/1203.3153 . The paired/premeasurement resource-identity class is established prior work; this review independently derives the needed block-pinch algebra.

The reviewed Astra application combines the particular source-weighted radius, separate deterministic-return verifier accounting and actual-clock paired-target condition. Its mathematical reconstruction is positive, but distinct historical priority remains UNKNOWN. This audit uses complete analytic arguments; no finite simulation could substitute for its merging limit. Efficient code construction and measured physical operating costs are unacquired. Mission NOT_ACHIEVED.
