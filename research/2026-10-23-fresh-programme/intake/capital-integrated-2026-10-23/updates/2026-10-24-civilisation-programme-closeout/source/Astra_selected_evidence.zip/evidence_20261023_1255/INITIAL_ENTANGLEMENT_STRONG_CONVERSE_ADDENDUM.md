# Initial entanglement cost, rather than product-reference dimension

Root, 23 October 2026. Distinct extension of frozen root72256264 and
W49a42ba028. Root proposed the relative-entropy-of-entanglement refinement;
W49 independently converged and checked the normal-SEP closure, then froze
INITIAL_ENTANGLEMENT_CHANGE_OF_MEASURE_V1.md SHA
c18543277a00edc92508c37854dec7451db70a48867ac0c3cd9bea7898bcfe6a.
W49 separately supplied the mutual-information corollary and the stronger
d-versus-SEP cutoff comparison below. W36's fresh full review is pending.
Generic resource comparison, pinching and binary data processing are prior.

Use the exact model and SAME-interface W19 product-process prerequisite
1556727069358baa8838813d3364eb2e33869dd32cc6d04df682a4dc868328cc
specified in root STATIC_CORRELATION_STRONG_CONVERSE_TRANSFER.md. Put
C_N=H_b^N and c_b=log2(H_b)/2. All relative entropies here use bits.

For any FIXED N-call legal strategy and fresh independent Bell input, the
final Bell probability is a bounded normal linear effect on its initial
resource: F(eta)=Tr(T eta), 0<=T<=I. Thus the uniform product bound
F(omega_E tensor xi_labs)<=C_N/K^2 extends first to every finite convex
mixture of products and then by trace-norm continuity to every normal
state in their trace-norm closure SEP(E:wholelabs).

Write Delta_N=2log2 K-log2 C_N>0. For ANY sigma in this SEP set, let
f0=F(sigma)<=2^(-Delta_N). Full-protocol data processing and the binary
Bell test give

    D(eta||sigma) >= d_bin(F(eta)||f0)
                 >= F(eta) Delta_N-h2(F(eta)).          (E1)

The latter follows from the cross entropy expression: its second positive
term -(1-F)log2(1-f0) may be dropped. Cases f0=0 follow by extended-value
relative entropy; no assumed finite marginal entropy is needed. The same
right side is independent of sigma. Taking the infimum is therefore valid
without an attained optimum and proves

    E_R(E:wholelabs)_eta >= F(eta) Delta_N-h2(F(eta)).    (E2)

In particular if log2 K>=N(c_b+delta), delta>0, then

    F(eta_N) <= [E_R(eta_N)+1]/(2 delta N).             (E3)

Every family with INITIAL E_R=o(N) obeys the same strong threshold. Initial
classical correlation, even extensive, has no E_R cost and is already
covered. Fresh logical independence of the WHOLE resource is mandatory.
This theorem does not make a claim about a postselected resource or the
entanglement generated later by the physical forward device.

Two exact corollaries clarify the resource frontier:

* Since the product of its marginals is an allowed separable reference,
  E_R(eta)<=I(E:labs)_eta whenever that mutual information is finite. Thus
  sublinear INITIAL mutual information suffices as W49 independently
  derived; finite marginal entropies are not individually required.
* If S(eta_E)<infinity, purification across E:(labs+F), Schmidt dephasing
  and partial trace give E_R(eta)<=S(eta_E). Thus sublinear initial bath
  entropy also suffices. Fixed normal resources of infinite entropy or
  infinite E_R are handled by the pointwise cutoff argument, not this
  finite-information estimate.

The initial finite-rank comparison can also be strengthened. For normalized
eta_P supported on bath rank d, dephase E in ANY basis of that support:

    eta_P <= d chi,    chi=Delta_basis(E)(eta_P) in SEP.

Pinching proves the order. Therefore the original root product-reference
d^2 factor improves to d for the SCALAR Bell bound:

    F(eta)<=sqrt(1-Tr(P eta))+d H_b^N/K^2.              (E4)

No common replacer channel for all terms of chi is needed; the uniform
scalar SEP test suffices. A maximally entangled rank-d resource requires
factor d for generic domination by SEP, so this dimension-only comparison
cannot be uniformly improved. With a vanishing-tail rank bound
log2 d_N<=sN+o(N), E4 gives strong ceiling c_b+s/2. With log2d_N=o(N)
it retains c_b. No commutation with bath charge/dynamics or physical initial
measurement is required.

There is a useful pointwise/uniform distinction. If eta_N is allowed to
vary but its bath marginal is ONE FIXED normal tau_E, then every static
P_M has the SAME p_M=Tr(P_M tau_E) uniformly in all extensions/lab sizes.
Fix M, let N grow, then M grow: the strong threshold holds uniformly over
all such extensions. This is W36's independent quantifier strengthening.
It does not cover arbitrary varying normal marginals without a common
tail/information promise.

For arbitrary extensive entanglement/correlation resources no quadratic
strong theorem follows here. E2 states a necessary entanglement budget to
sustain above-threshold fidelity, not a useful construction or achievable
tradeoff. At beta=0 the stronger all-resource theorem already applies.
There is no physical resource preparation, practical advantage, or new
generic entropy inequality claimed. Device-specific priority remains
UNKNOWN; the scientific mission remains NOT_ACHIEVED.
