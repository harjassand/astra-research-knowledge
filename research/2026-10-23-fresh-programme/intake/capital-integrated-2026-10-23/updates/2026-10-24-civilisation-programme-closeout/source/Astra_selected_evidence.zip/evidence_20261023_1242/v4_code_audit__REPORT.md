# Frozen independent end-to-end V4 review

W30, 23 October 2026. Subject: W39's `recurrent/V4_FINITE_CODE_CONTRACT.md`,
SHA256 `fcf6cdd9f7090d4ab59ceeafe1a814f320c1190d6d6be5da90ff7ff58d31447b`.

No blocking defect was found in the conservative integration under its
stated exact recurrent-device, analytic V4 source and ideal finite native
circuit premises. The end-to-end mathematical claim survives independent
reconstruction: a randomized, paid polynomial-in-outer-length subsystem
encoder and output-only digital decoder attain the certified limiting
rate `3/2+g/k >= 3/2+beta^2/1550`, with pointwise vanishing full logical
diamond error for each fixed normal initializer. Its multiplicity onset
is exponential in `1/beta^2`. This is internal proof review, not external
or formal certification, an executed complete code, or practical advantage.

`INDEPENDENT_RECONSTRUCTION.md` proves the integration directly. It covers
the exact finite source family and common drift, legal-qutrit support,
entropy continuity in the half-distance convention, finite Schur acceptance
and all degenerate weights, full-domain subsystem inverse, Gaussian/Pauli
dimension factors, bounded acquisition/native errors, initial descent,
receiver-only sector probes, zeros after every probe, retained terminal
outputs, inaccessible gauge purifier, local digital inverse, and the complete
floor-aware call/rate/error sum. The physical device is the evolving original
channel throughout. No iid replacement or physical reverse query is used.

An explicit finite retry completion is included: `T_retry=J+10`, all-fail
default before logical insertion, and each acquisition channel compiled to
`delta_code/(256 T_retry)`. Failure and compilation together cost at most
`delta_code/128`. A fixed legal default suffices; no good-lambda search or
source-eigenbasis oracle is required. The other stages fit the stated
per-end diamond budgets. This makes the existing paid-retry claim concrete
without changing any displayed forward-call/design count.

The actual finite circuit output `rhohat_J` is used as the source at each
horizon, with `m` identical copies of that density. Its common operator
drift directly proves its product-source tail. There is no `m eps_src`
comparison to the unused analytic source. Only the universal `V=k^2`
bounded-displacement estimate is used. The sharper analytic source variance,
W30 tight OAA, W30 M-free source stability, newer rectangular-QSVT proposals
and separate fixed-pair quartic-gain code are excluded from this verdict.

The independent checker reads the frozen result JSON as fixtures and
imports no producer module or Python implementation. It reconstructed all
36 compared top-level fields per setting, including ten exact guards, for
all three requested `(beta,J)` settings. It additionally checked six finite
inequalities in each setting and 98 direct collision sums. All pass.
The logical dimension `2^ell` and code dimension `2^(ell-s)` are never
constructed. The elapsed scalar check measures only this modest integer
calculation, not a large program's construction or execution.

At `beta=1/512`, `k=52428`, `J=166380`, the chosen sufficient total forward
calls remain in `[2^166395,2^166396)`. The exact-Clifford bound is in
`[2^665594,2^665595)`, offline fair seed bits in `[2^665591,2^665592)`, and
each Rz target is requested at 665581-bit operator accuracy. These are
counted sufficient choices, not optimized lower bounds or useful resources.
No whole-code elementary-gate constant is instantiated.

All 32 frozen dependency paths, sizes and hashes, together with corpus
HEAD `e606bfc587c76bdcae8b8fa3ec33e721efa2fbac`, were rechecked. The binding
receipt is transport evidence only. The finite computations support their
declared cases and do not certify the universal proof.

Primary sources were challenged at the relevant interfaces. The established
HLT Pauli gap, lazy finite sampler and paid operational precision suffice.
The ordinary BCH transform already has polynomial cost here because finite
acceptance forces `d<=m`; the corrected high-dimensional Schur baseline is
retained and the old Krovi error is not ignored. Generic mixed-gauge Schur
encoding and the other standard ingredients are incumbent operations.
The possible contribution is their specific actual-source recurrent
composition, not generic Schur/design/synthesis invention.

Remaining obligations are independent verification of the supplied analytic
V4 source theorem beyond its bound review, an executable integrated program
and its nontrivial-size diagnostics, accurate physical parameter acquisition
and control, deterministic efficient seed certification, practical/error/
energy accounting, optimized onset or constants, priority review and
external/formal validation. None follows from these scalar passes. The
generic oracle seed-certification lower bound in W30's separate packet is
not a hardness result for this recurrent overflow effect.

Proof validity: internal positive under stated premises. Computational
construction: polynomial in numerical outer length; exponential onset in
inverse beta squared. Full large native program: not generated/executed.
Physical validation: not performed. Practical advantage: not established.
Priority: unknown. Mission: not achieved.
