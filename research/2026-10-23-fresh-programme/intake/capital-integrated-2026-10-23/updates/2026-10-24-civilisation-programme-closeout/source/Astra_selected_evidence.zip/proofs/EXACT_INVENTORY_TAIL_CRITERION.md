# Exact separable-tail and baseline-rate criterion

23 October 2026. W38 independent derivation while attacking the inventory
second-order question. Internal source-specific result; historical novelty and
external correctness UNKNOWN. The proof preserves the original fixed-source
limit and complete actual-residual target. No peer proof is used as a premise.

## Theorem

Fix finite D>=2, n>=1 and a probability vector p=(p_0,...,p_n), with zeros
permitted. Define

    eta_p=sum_(j=0)^n p_j Phi_D^tensor j tensor nu_D^tensor(n-j),
    S=sum_(j=1)^n p_j D^j.

Then the following are equivalent:

    eta_p is PPT,
    eta_p is separable,
    p_0 >= S.                                             (E1)

If p_0<S, an explicit local filter yields an entangled two-qubit isotropic
state. Therefore eta_p is one-copy distillable and has strictly positive
two-way asymptotic distillable entanglement. No statement about its exact
positive rate is implied.

Consequently, for the original queue prior with k0=min supp K and
p_j=P(K=k0+j), the original zero-aid pooled capacity satisfies

    R(p)=k0 ln D  iff  p_0>=sum_(j>=1)p_j D^j,
    R(p)>k0 ln D  otherwise.                              (E2)

Trailing noise and original inaccessible clocks/memory remain as supplied.
The degenerate n=0 case is purely the exact common prefix and satisfies the
same criterion with S=0.

## 1. Exact partial-transpose minimum

Let F_i be the swap between the two D-level parties at site i. Since
Phi_D^Gamma=F_i/D and nu_D^Gamma=nu_D,

    eta_p^Gamma
      =D^(-2n)[p_0 I+sum_(j>=1)p_j D^j F_1...F_j].          (E3)

The F_i commute and each has both signs as eigenvalues for D>=2. Let z_i
be their signs and Z_j=product_(i<=j)z_i. The prefix products Z_j can be
chosen independently: z_1=Z_1 and z_j=Z_(j-1)Z_j for j>1. Hence the minimum
eigenvalue of eta_p^Gamma is EXACTLY

    D^(-2n)(p_0-S).                                       (E4)

For example z_1=-1 and z_i=+1 for every later site attains all Z_j=-1.
Thus PPT is equivalent to the scalar inequality in (E1).

## 2. Finite explicit separable decomposition

For d>=2 use the established separable isotropic boundary state

    zeta_d=(I+d Phi_d)/(d(d+1))
          =d/(d+1) nu_d +1/(d+1) Phi_d.

Identify each first j-site block locally with dimension d_j=D^j. If p_0>=S,
put w_0=p_0-S and w_j=p_j(D^j+1). Then w_j>=0 and

    w_0+sum_(j>=1)w_j=1,
    eta_p = w_0 nu_D^tensor n
            +sum_(j>=1)w_j[zeta_(D^j) tensor nu_D^tensor(n-j)].  (E5)

The Phi-prefix coefficients are p_j and the total white-noise coefficient
is w_0+sum_j p_jD^j=p_0. Every term is separable on the original A:B
registers, proving sufficiency. Necessity follows from PPT. The boundary
state has a finite product decomposition as in the earlier inventory audit;
this is an exact witness, not an efficient preparation claim.

## 3. An explicit one-copy local filter for every violation

On sites 2,...,n, Alice and Bob locally project onto their basis vector |0>.
On site 1, each projects onto span{|0>,|1>}. Keep the joint success outcome
and locally identify the remaining two levels with qubits. All other
outcomes are retained as ordinary failure branches.

For the j=0 white component, the unnormalized output is D^(-2n) I_4.
For j>=1, the first Bell pair projects to (2/D)Phi_2; each of its j-1
remaining Bell sites contributes probability 1/D, and every later white
site contributes probability 1/D^2. Thus its unnormalized output is
2 D^(j-2n) Phi_2. The actual unnormalized success state is exactly

    D^(-2n)[p_0 I_4+2S Phi_2].                            (E6)

Its success probability and normalized Bell fidelity are

    q_filter=D^(-2n)(4p_0+2S)>0,
    f=(p_0+2S)/(4p_0+2S).                                (E7)

The denominator is nonzero for a normalized p. Directly,

    f>1/2 iff S>p_0.

It is a two-qubit isotropic state. A fixed finite number of ordinary
recurrence rounds raises any fixed f>1/2 above 0.9. If e=1-f, the known
recurrence is

    P_rec=f^2+(2/3)fe+(5/9)e^2,
    f_new=[f^2+e^2/9]/P_rec,

and each round consumes two input pairs per attempted output, with retained
fraction P_rec/2. After finitely many rounds the ordinary unassisted hashing
rate ln2-h_2(f_final)-(1-f_final)ln3 is positive. A concrete positive tail
rate lower certificate is

    q_filter product_rounds(P_rec/2)
          *[ln2-h_2(f_final)-(1-f_final)ln3] >0.             (E8)

One may take any strictly smaller rate to allow deterministic budgets and
typical fluctuations. All q_filter and recurrence failures are paid in
the original input-copy denominator. No entangled aid is supplied.

The established positive-yield recurrence/hash theorem was checked in the
primary source Bennett et al., *Purification of Noisy Entanglement and
Faithful Teleportation via Noisy Channels*, arXiv:quant-ph/9511027v2,
equation (7) and the following hashing discussion:
https://arxiv.org/html/quant-ph/9511027 . The finite filter and condition
(E1) above are derived here; the general qubit distillation primitive is
credited prior machinery.

## 4. Fixed output rank and complete actual residual

At fixed D,n,p with S>p_0, q_filter and the finitely many recurrence
success probabilities are positive constants before r grows. Apply each
finite LOCC stage to iid blocks with deterministic slack in retained counts;
unexpected shortages output product fillers at the same declared final rank.
Typical concentration makes those failure events vanish. Ordinary hashing
then gives Bell marginal error tending to zero at every strictly smaller
rate than (E8). There is no favorable-branch or expected-rank capacity claim.

For any output omega_QW whose Q marginal is close to a pure Bell state, the
pinned universal pure-output lift makes it close to Phi_Q tensor its OWN
actual omega_W. This includes the original K clocks, old memory, all filter
outcomes, recurrence records and discarded systems. Thus the construction
obeys the exact original complete-residual convention.

## 5. Exact common-prefix baseline

For the original law K=k0+J, the accessible state factors as

    Phi_D^tensor k0 tensor eta_p tensor nu_trailing.

The first factor is pure and factors from the COMPLETE preparation,
including its inaccessible clock. Keeping it gives rank D^(r k0) with zero
complete-residual error. If (E1) holds, the tail is separable by (E5).
The separable comparison chi_D^tensor k0 tensor eta_p tensor nu_trailing
has relative entropy k0 lnD from the actual accessible input. The binary
Bell test bounds every reliable rate by k0 lnD, proving equality in (E2).

If (E1) fails, set the pure prefix aside and apply the positive tail-rate
construction above. Tensoring its fixed Bell output with the exact prefix
gives rate strictly greater than k0 lnD with the same actual-residual lift.
This proves the strict alternative in (E2).

## 6. Why this route cannot settle the large-entropy second order

Whenever (E1) holds,

    E[D^J]=p_0+S<=2p_0<=2.

Jensen implies E J<=ln2/lnD<=1. Maximum entropy at mean at most one then
gives H(J)<=2ln2, uniformly in n,D. Thus the exactly baseline-rate priors
from (E2) cannot have H(K)->infinity. They supply no counterexample to a
constant or logarithmic second-order correction at growing entropy.

This is an exact finite-source operational classification, not a resolution
of whether the general capacity loss is H+O(1). Success probabilities and
required code lengths can be extremely poor. No physical implementation,
computational advantage or historical novelty is established.

## 7. Finite evidence

`check_exact_tail_boundary.py` checks 60 rational instances for D=2,3,5 and
n=1,...,5, below, at and above the threshold. PT minimum, separable mixture
weights, filtered matrix/probability/fidelity and all finite recurrence
updates are exact Fractions. Only the displayed positive hashing yield is
floating. Raw evidence is `exact_tail_boundary_checks.json`. The analytic
proof, rather than these finite admissions, supplies the universal claim.
