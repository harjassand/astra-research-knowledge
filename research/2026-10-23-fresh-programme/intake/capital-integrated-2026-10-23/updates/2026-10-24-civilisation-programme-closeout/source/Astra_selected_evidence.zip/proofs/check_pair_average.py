"""Independent full original two-call word replay; no producer imports."""
from fractions import Fraction as F
from itertools import product
from math import comb
from pathlib import Path
import json

words=list(product(range(3),repeat=2))
prefixes=list(product((1,2),repeat=2))
def branches(inp, bath):
    out=[]
    for mask in product((0,1),repeat=2): #1 is an actual move U
        row=list(inp); stack=bath; stays=0
        for i,move in enumerate(mask):
            if not move:
                stays+=1
            elif row[i]==0:
                assert stack,"root reached before call on required bulk guard"
                row[i]=stack[0]; stack=stack[1:]
            else:
                stack=(row[i],)+stack; row[i]=0
        out.append(((tuple(row),stack),stays))
    return out

# coefficient lists for degree at most2 in b, a=1-b
G=[[[F(0) for _ in range(3)] for j in words] for i in words]
for i,wi in enumerate(words):
    G[i][i][0]+=sum(c!=0 for c in wi)
    for j,wj in enumerate(words):
        for bath in prefixes:
            for (oi,si) in branches(wi,bath):
                for (oj,sj) in branches(wj,bath):
                    if oi!=oj: continue
                    assert (si+sj)%2==0 #fixed initial/final bath depth
                    r=(si+sj)//2
                    phase=1 if (sj-si)%4==0 else -1
                    qout=sum(c!=0 for c in oi[0])
                    for h in range(3-r):
                        G[i][j][r+h]-=F(qout*phase*((-1)**h)*comb(2-r,h),4)
checks=0
for i,wi in enumerate(words):
    for j,wj in enumerate(words):
        expect=[F(0)]*3
        if i==j:
            d=2*(sum(c!=0 for c in wi)-1)
            expect=[F(d),F(-d),F(0)]
        if (wi[0]==0 and wj==(wi[1],0) and wi[1]!=0) or (wi[1]==0 and wj==(0,wi[0]) and wi[0]!=0):
            expect=[F(0),F(1,2),F(-1,2)]
        assert G[i][j]==expect,(wi,wj,G[i][j],expect)
        checks+=3
result=dict(scope="Exact full input9x9 charge-averaged bulk depth response of original two-call word unitary",identity="Tr_bath[(I_depth2/4) G_beta]=a*[2(Q-I)+bH2]",coefficient_assertions=checks,initial_prefixes=4,input_basis=words,coefficients=[[[str(x) for x in row] for row in matrix] for matrix in G],producer_code_imports=False,physical_experiment=False)
out=Path(__file__).with_name("PAIR_AVERAGE_EXACT_CHECK.json")
out.write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(dict(assertions=checks,output=str(out),status="PASS")))
