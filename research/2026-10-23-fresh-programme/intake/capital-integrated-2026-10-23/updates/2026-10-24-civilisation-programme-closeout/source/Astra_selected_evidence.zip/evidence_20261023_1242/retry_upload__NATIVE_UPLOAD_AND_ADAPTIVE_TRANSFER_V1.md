# Native quantum upload and adaptive qubit transfer with all branches counted

23 October2026, w64. Independent derivation after the conservative fixed-resource acquisition packet was frozen and audited. This packet improves its costs using exact native instruments. It does not claim a new general repeat-until-success principle, sharp capacity, physical hardware, terminal fixed-horizon resource-return code, or mathematical priority. Fresh criticism is PENDING. The device is unchanged.

## 1. Exact native isometry on a colored input

Write a=1-beta^2, b=beta^2, alpha=sqrt(a),0<=beta<1, and let C:|j>->|j>_A, j=1,2 embed a qubit in the colored port states. Define the stack isometry

    T: C^2 tensor E -> E,
    T(|j> tensor |xi>)=S_j|xi>.

It is an isometry because S_j* S_k=delta_jk I. It may act on a qubit arbitrarily entangled with the bath or any external reference; no product-state assumption is needed for the following operator identities.

The exact native action is

    V(C tensor I_E)
      =alpha |0>_B tensor T
           +i beta (C_B tensor I_E).                (U1)

Bob measures ONLY the vacuum-versus-colored flag {|0><0|,q}. He does not measure the color. On the vacuum branch, probability a, the normalized action is exactly T and the port is fixed vacuum. On the colored branch, probability b, the normalized action is exactly identity from the input colored qubit to Bob, tensor identity on the ENTIRE bath. Both branch probabilities are independent of every input/bath/reference state. The phase i on a branch is scalar and irrelevant to its density operator.

## 2. Quantum-back upload with a cap

For the goal of UPLOADING the qubit into E, a colored output is a failed push: Bob sends that SAME colored port back to Alice through the permitted backward QUANTUM wire. The input qubit, its entanglement with every register and the entire old bath are unchanged on that branch. Alice retries that exact qubit, rather than reconstructing or postselecting an unknown state. A vacuum output is a successful push and the procedure stops for that qubit.

With at most r attempts, upload success probability is1-b^r and every successful branch implements exactly T. A cap failure leaves the original qubit still accessible in the returned port and the old bath unchanged, but the protocol retains this failure flag and may abort the later task. It is never removed from message/preparation error. All at most r forward calls and backward returns are counted. Unlimited repetition terminates almost surely for every fixed beta<1, with mean1/a forward calls, but the finite capped form is used for fixed horizons.

For a fixed-length H-word resource, Alice initially holds H qubits in the desired reversed stack order, possibly entangled with laboratories/Bob. Upload them sequentially. Already stored qubits are part of E and are unchanged by later failed pushes. When the next push succeeds it prepends that new qubit coherently, so all H successes implement the exact ordered isometry from the H-qubit register to bath words of length H above the old bath. Starting at root produces the requested H-word state. No seed identification is needed for THIS UPLOAD primitive: colored calls never invoke J, and the initial seed is preserved.

Capping each qubit at r gives failure probability at most H b^r, maximumHr forward calls, and at mostH(r-1) colored-port backward quantum returns. Thus r>=ln(H/epsilon)/|ln b| yields O_beta[H log(H/epsilon)] forward cost and total error probability<=epsilon. For H=0 no upload is needed. This can load an UNKNOWN entangled H-qubit state; it is an acquired native isometry, not a supplied bath oracle. It does not set the bath seed or prepare arbitrary superpositions of word LENGTH. Applying it to a general variable-length resource without a further coherent-length mechanism would be invalid.

## 3. Exact pop of an uploaded qubit

The range of T is the bath's NONROOT subspace. A vacuum input on that range has exact action

    V(|0>_A tensor T)
       =alpha (C_B tensor I_E)
              +i beta |0>_B tensor T.               (U2)

Here the E on the right is the OLD bath before the push; this is an operator from the qubit tensor old-E space. The root term vanishes on the shifted range, and S_k* S_j=delta_kj I proves the identity. A colored output coherently retrieves the stored qubit and restores the ENTIRE old bath, probability a. A vacuum output leaves the stored qubit and old bath unchanged, probability b. Bob again measures only the zero/nonzero flag, preserving all color coherence.

After a push has succeeded, Alice can send vacuum again until a colored output retrieves the qubit. A failed pop output is the fixed vacuum and needs no quantum backward return. With at most r pop attempts, retrieval cap failure has probability b^r. Every successful pop returns the old bath and all its prior external correlations EXACTLY, even when the qubit was initially entangled with that old bath. This is a branchwise operator identity, not an entropy or decoupling approximation.

## 4. Adaptive UNKNOWN-qubit communication needs only classical feedback

For the goal of TRANSMISSION to Bob, do NOT return a colored first output: it ALREADY IS the intact unknown qubit at Bob, by(U1). That branch succeeds immediately, probability b, and the old bath is unchanged.

If the first output is vacuum, probability a, the qubit is stored by T. Alice then sends vacuum, using(U2), for at most r pop attempts. At the first colored output Bob retains the retrieved qubit, signals success backward CLASSICALLY and stops. The successful branches of the WHOLE protocol all transfer the unknown qubit by identity and restore the entire initial bath/reference state. The normalized qubit/bath map is identical on every such branch; only a scalar record probability differs, so the flag record carries no information about the unknown qubit or old bath.

The cap failure probability and maximum forward cost are

    p_fail=a b^r,
    calls<=1+r.                                    (U3)

The first direct branch has probability b; retrieval at its tth attempt has probability a^2 b^(t-1), t=1,...,r. Their sum is1-a b^r. This identity counts every outcome, including the cap failure. Unlimited retrieval has mean1/a attempts after an upload. The unconditional expected total forward calls are1+a(1/a)=2 for fixed0<=beta<1. This is a variable-time primitive, not a deterministic two-call exact channel. Near beta1 rare uploaded branches take a long time; the expectation is nonuniform and does not contradict the identity-port endpoint beta1.

At beta0 it reduces to the inherited two-call colored Dyck excursion. At beta1 the actual device is iI and the first port transfers directly in one call; the upload/pop formulas have a=0 and are not used. No new beta0 capacity result is claimed.

For m unknown qubits, sequentially apply the capped primitive, possibly with joint entanglement across all input qubits and laboratories. On all successes the map is identity on those m qubits tensor identity on the ENTIRE original bath. Union bound gives failure probability<=m a b^r, and at mostm(1+r) calls. On any cap failure the task may abort, retaining the whole failure probability. No unknown state is reconstructed, cloned or retried after a destructive failure. Only backward classical flags are needed. Choosing r=O_beta(log(m/epsilon)) gives O_beta[m log(m/epsilon)] forward calls.

This provides a reliable finite resource-distribution interface, NOT a competitive asymptotic rate claim: its typical rate is around1/2 qubit per call before fixed-cap overhead, while the inherited beta0 Dyck code has rate3/2. All local control, flag precision, body resource and energy costs remain separate.

## 5. Improved known-program acquisition and fixed-length preparation

Alice can prepare the ENTIRE KNOWN finite program state locally and send its m-qubit intended Bob register using section4. The program may be entangled internally and with retained Alice registers. On all successes it is EXACTLY distributed and the bath unchanged; on cap failure abort the PREPARATION while the fresh logical M is still untouched. No whole-known-program geometric rebuild is necessary for successful unknown-qubit transfers; the cap error is simply retained.

For R independent finite loader programs, distribute all Rm qubits with a per-qubit pop cap r_D chosen so Rm a b^(r_D)<=epsilon. The maximum program-distribution cost is Rm(1+r_D); no a^(-2m) whole-program probability remains. On all successes every program is independent of the old bath whenever its original all-Alice preparation was, and the bath is still exactly its pre-distribution state. Thus no extra D-depth reset is needed after successful distribution. These facts replace only the COST of the older conservative acquisition addendum, whose identities and upper bounds remain valid.

Combining this improved distribution with the original variable-length all-vacuum loader leaves its R=O(a^-H log(1/epsilon)) attempts and depth-H resets. At fixed beta the forward count becomes

    O_beta[a^-H (m+1)(L+1)
                (H+ln(m+1)+L+1)+(L+1)^2],          (U4)
    L=ln(1/epsilon).

No fresh audit of this summarized growth consequence is inherited from the earlier packet; it follows by substituting the counted Rm cap above. Local program compilation still costs R copies of a known program and is not inferred efficient from(U4).

For a target resource with bath support at a SINGLE fixed word length H, and body permissions including quantum backward returns, the entire resource may instead be prepared locally in registers for its H bath qubits, its m Bob qubits and its retained Alice/purifying registers. Distribute the Bob part by section4, then upload the reversed H bath qubits by section2. Every success map is an isometry or identity on the full entangled state, so the target is loaded without nonlinear filtering or exponential a^-H retries. Choosing per-stage caps O_beta(log((H+m+1)/epsilon)) gives

    O_beta[(H+m+1)log((H+m+1)/epsilon)]              (U5)

forward calls, with all abort probability retained. The original independent bath must first be reset to root as in the corrected packet. If a body simulation needs a chosen seed sector, the existing finite QND probe and exact local-program sector equivalence are also needed; the bare upload itself does not choose the conserved sector. Starting with a fixed normal independent initializer still gives only pointwise tail reset, never uniform over arbitrary horizon-dependent deep initializers.

Consequently single-length known resource families with H_N+m_N=o(N/logN) have a sufficient o(N) FORWARD-CALL preparation window at fixed beta, under quantum-back permission and vanishing slow target tolerance. This is an initialization/capacity-comparison consequence, not a newly achieved message rate. No arbitrary variable-depth resource or width-dependent header theorem is claimed in this frozen source.

## 6. Cost and objective boundaries

Every forward attempt, returned quantum port, classical flag, stored qubit, failure and reset is counted. Quantum-back upload consumes backward quantum communication; it cannot silently replace a classical-only body's resource assumptions. The communication/program-distribution primitive itself needs only classical feedback. The original body retains its own quantum/classical backward-wire permission in a composed simulation.

A successful stopped primitive returns the old bath exactly in section4. To enforce a deterministic overall call count after early success, one may pad dummy calls AFTER Bob decodes if the final objective traces the bath. Such padding can disturb the bath. Therefore the composed fixed-horizon protocol is NOT asserted to satisfy whole-resource exact return. A separately stated variable-time stopped-success identity must not be promoted to a fixed-horizon return theorem.

The procedure assumes known native beta, exact flag projectors and arbitrary finite local register control, as permitted in the model. It acquires the bath interface and program distribution mathematically; it does not acquire a laboratory source, target-state classical description, low-cost local compiler, energy/heat budget or error-corrected hardware. Precision, storage and complete local computation must be charged separately. Practical advantage NOT_ESTABLISHED; physical validation NOT_PERFORMED; novelty UNKNOWN; programme mission NOT_ACHIEVED.
