# A positive-domain dilation entropy obstruction, with exact certificate

23 October 2026. W38. This is a scoped falsifier of a possible proof bridge,
NOT a counterexample to amplifier EPnI. General unheated amplifier EPnI
remains NOT_ACHIEVED. All preceding heated-input proofs are unchanged.

## 1. The tempting unary bridge and its exact failure

For s>1 let D_s denote phase-space scaling at the symmetric Weyl
characteristic level,

    chi_(D_s rho)(z)=chi_rho(sqrt(s)z).

This map is not a quantum channel and is not positive on all states.
Even restricting to states for which BOTH rho and D_s rho are normal
positive finite-energy states does not validate

    g^-1(S(D_s rho)) >=s g^-1(S(rho))+(s-1)/2.         WRONG

Take s=2 and

    rho=H_(1/4)(|1><1|),
    p_n=<n|rho|n>=4(16n+1)/5^(n+2), n>=0.

It has trace1 and mean photon number5/4. Its scaled operator is positive:

    q_n=<n|D_2 rho|n>=n/2^(n+1), n>=0.

This also has trace1, with mean3. Their entropies satisfy the rigorous
comparisons

    S(rho)>g(3/4)+0.0318066230884785080,
    S(D_2 rho)<g(2)-0.0300956035144497174.              D1

If WRONG held, the first inequality would force
g^-1(S(D_2 rho))>2*(3/4)+1/2=2, contradicting the second.
No numerical inversion of g is needed for this contradiction.

## 2. Exact characteristic-function verification

Write x=|z|^2, with vacuum characteristic e^-x/2 and heat H_T multiplying
by e^-Tx. Fock |1> has characteristic (1-x)e^-x/2, so

    chi_rho=(1-x)e^(-3x/4),
    chi_(D_2 rho)=(1-2x)e^(-3x/2).

For diagonal states use the Laguerre generating identity

    sum_(n>=0) r^n L_n(x)=(1-r)^(-1)exp[-r x/(1-r)].

Its r derivative gives the factor n. Substituting r=1/5 with coefficients
4(16n+1)/25 gives the first characteristic above. Substituting r=1/2
with coefficients n/2 gives the second. Thus the displayed p_n,q_n are
exact native states, not a finite photon truncation, inverse-heat positive
guess, or approximate oscillator simulation.

## 3. The counterexample is a reachable passive intermediate

The obstruction is not merely an arbitrary positive-domain scaling input.
Choose the actual original two-input device with

    G=3/2, lambda=1/2, s=2, theta=G/s=3/4.

Let B be vacuum and let A have probabilities

    a_n=9n/4^(n+1), n>=0.

A is a positive normalized photon-added thermal state of base mean1/3;
its mean is5/3 and its characteristic is

    chi_A=(1-4x/3)e^(-5x/6).

Passive BS_(3/4) mixing A and B has characteristic

    chi_A(sqrt(3/4)z) chi_B(sqrt(1/4)z)
       =(1-x)e^(-3x/4)=chi_rho.

The ACTUAL retained amplifier characteristic is

    chi_A(sqrt(3/2)z) chi_B(-sqrt(1/2)conjugate(z))
       =(1-2x)e^(-3x/2)=chi_(D_2 rho).

The native source and output energies5/3,0,3 agree with
G E_A+lambda(E_B+1)=3. Thus even a reachable intermediate can violate
the proposed UNARY scaling step. This does not refute the actual EPnI:
the passive intermediate can have extra entropy relative to the weighted
original input entropies, and that slack can compensate. Any successful
combined argument would have to retain this context.

For general G, the exact characteristic identity is

    amplifier(A,B)=D_(2G-1)[BS_(G/(2G-1))(A,B^T)],

where transposition is in the Fock basis. It preserves the individual
input entropy and energy, and the resulting dilation is positive because
the expression equals the original physical output. This is an analytic
identity, not a free physical implementation of transposition or scaling.
The falsifier blocks deducing amplifier EPnI by adding WRONG as a generic
one-state lemma to a passive theorem. It does not rule out a compensated
or more restricted joint comparison, which would need a new proof.

## 4. Exact rational/integer entropy certificate

`check_positive_dilation_counterexample.py` produces
`positive_dilation_counterexample_certificate.json`. It has no floating
logarithm, entropy cutoff assumption or inverse-entropy premise.

For each positive rational x, range reduction writes x=2^m y with
1<=y<=2. Set z=(y-1)/(y+1), so 0<=z<=1/3. The code bounds

    ln y=2sum_(j=0)^(N-1) z^(2j+1)/(2j+1)+remainder,
    0<=remainder<=2 z^(2N+1)/[(2N+1)(1-z^2)], N=80.

Each term and the remainder are enclosed by exact integer floors/ceilings
after scaling by10^50. The same series encloses ln2. Signed range reduction
then encloses every ln p_n, ln q_n and g at rational arguments. Multiplying
each logarithm interval by its exact rational probability preserves bounds.

For S(rho), the first32 entropy terms give a lower bound. For S(D_2 rho),
the first128 terms give a head interval. Since q_n=n/2^(n+1), for n>=M,

    -ln q_n<=(n+1)ln2,
    sum_(n>=M)(n+1)q_n=(M^2+3M+4)/2^M.

At M=128 this bounds the full omitted entropy by
3.416416964988514e-35. Adding this exact rational multiple of the ln2
upper enclosure gives D1. All reported margins remain positive by more
than0.03; the log enclosure widths are far smaller. This is a complete
infinite-dimensional certificate for the specific entropy comparisons.

## 5. Established primary boundary and costs

Generic nonpositivity of symmetric phase-space scaling is established
prior: [Ivan--Sabapathy--Simon1705.07044v2, Proposition2 and Theorem1]
(https://arxiv.org/html/1705.07044v2). I directly read its definitions,
characteristic formula and positivity classification. Its ordering
parameter s is different from this note's variance scale s: this note
uses their ordering0 and amplitude scale sqrt(s). No generic scaling-map
nonpositivity novelty is asserted. The exact positive-domain entropy
counterexample's historical priority remains UNKNOWN.

The states are supplied mathematical inputs. No source preparation,
heralded photon addition, nonpositive map, transposition record, pump,
factory, calibration, precision, entropy acquisition, disposal or reset
was implemented. The actual amplifier identity is exact but no physical
device experiment was done. External acceptance/practical advantage are
not established. This is a proof-route obstruction, not general EPnI
failure or a claim that all remaining unheated routes are impossible.
