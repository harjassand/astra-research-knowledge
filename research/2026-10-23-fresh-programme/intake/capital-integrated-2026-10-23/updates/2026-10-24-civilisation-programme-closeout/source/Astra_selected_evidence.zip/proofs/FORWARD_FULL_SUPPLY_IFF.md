# Exact strict-forward full-supply criterion for actual inventory records

23 October 2026, w44. Internal fixed-source theorem, frozen for independent
criticism. This is a further operational statement, not an assertion of
historical priority, external proof acceptance or physical acquisition.
The finite erasure-channel converse is derived here. The unassisted
Bell-error-ball correction step is established one-shot machinery and is
also used in the independently reconstructed w38 two-way sufficiency
proof, SHA256 393db7888adbe0cf666dfd87f19acbdb762168f3f1e0c7a02551769542c07d76.

## 1. Actual source, record and strict-forward receiver class

Fix finite D>=2, L>=1 and a known prior p on {1,...,L}, with zero masses
allowed. Original inventories K_a are iid with this prior. Their accessible
quantum states and ideal supply are

    sigma_k=Phi_D^tensor k tensor nu_D^tensor(L-k),
    nu_D=I_(D^2)/D^2, B=E K lnD.

The COMPLETE original queues retain exactly their original inaccessible
duplicated clocks and old memory. For each r, a KNOWN stochastic channel
from K^r prepares an ACTUAL finite duplicated classical record Z_r.
Conditional on K^r,Z_r, the accessible quantum preparation is STILL
tensor_a sigma_(K_a), with the original declared complete extension.
This source-preserving preparation interface is a premise. It is not
obtained by measuring the same source and pretending it was undisturbed.

The finite alphabet of Z_r may grow arbitrarily with r. Its acquisition,
duplication, delivery, description, storage and posterior compilation are
supplied premises, with no efficiency bound. The quantum states conditional
on Z_r can have arbitrarily correlated inventory posteriors.

There is NO supplied entangled stock. All other initial apparatus is normal
trace-class LOCAL PRODUCT and independent of the entire complete source
and record. Every receiver is finite-round finite-outcome TP LOCC at the
given r, with classical messages ONLY Alice->Bob. Bob's local outcomes may
control Bob's operations, but are not communicated to Alice or used to
control her operations. The initially duplicated Z_r is known to both.

At each r the final Bell rank N_r is one deterministic finite integer on
EVERY record, transcript, failure and abort branch. Reliability means

    T(omega_(QW),Phi_(N_r) tensor omega_W)<=epsilon_r->0,

where omega_W is the OWN full actual residual, including clocks, old memory,
records, messages, randomness, discarded inputs, work and failure flags.
No expected-rank or postselected target is allowed. Local gauges, arbitrary
Alice preprocessing and cross-queue processing are permitted. Fix D,L,p
FIRST and then let r grow.

Put

    A_r=sum_(a=1)^r H(K_a|Z_r).

Then the following are equivalent:

    (i) Such zero-aid strict-forward receivers achieve full supply B.
    (ii) A_r=o(r).
    (iii) There is a Z_r-alone estimator Khat(Z_r) with
          E d_H(Khat,K^r)=o(r).                         (G1)

Equivalently in (iii), there are h_r=o(r) and estimators with
P[d_H(Khat,K^r)>h_r]->0. Thus a joint posterior entropy o(r) is not the
whole strict-forward criterion; its marginal location uncertainty matters.
The finite bound below need not be the exact rate away from full supply.
Deterministic inventories are immediate; formulas using g_L assume L>=2.

## 2. Source as the Choi state of a random replacement channel

Index the rL physical D-level sites by (a,i), with 1<=i<=L. For an inventory
vector k, define its survival set

    S(k)={(a,i):i<=k_a}.

Let Dep replace a D-level input by I_D/D. At fixed actual z define

    N_z=sum_k p(k|z)[id_(S(k)) tensor Dep_(S(k)^c)].      (G2)

The conditional accessible source is precisely the normalized Choi state
of N_z. In particular Alice's marginal is maximally mixed, independent
of the hidden k even after conditioning on z.

For a converse, define a more informative flagged-erasure channel E_z.
Independently of its input, choose k with the actual posterior p(k|z).
Route the input sites S(k) to Bob, route the complement to the environment,
and give BOTH sides orthogonal classical k flags. Bob's erased positions
are represented by fixed pure erasure symbols. This is a finite channel;
its Stinespring realization coherently routes each posterior branch with
matching orthogonal flag copies. Bob's local postprocessing replaces each
erasure symbol by I_D/D and discards k. Therefore

    N_z=F_z composed with E_z

for a CPTP map F_z acting only on the flagged channel's BOB output. No
extra flag has been supplied to the actual receiver.

For EVERY possibly correlated input rho on all rL sites, the flag entropies
cancel between output and environment, giving

    I_c(E_z,rho)
       =sum_k p(k|z)[S(rho_(S(k)))-S(rho_(S(k)^c))].     (G3)

This formula permits arbitrary entanglement across physical sites and with
the reference. Coherent-information data processing gives
I_c(N_z,rho)<=I_c(E_z,rho).

## 3. An all-input erasure entropy bound

For a fixed input rho write f(S)=S(rho_S)-S(rho_(S^c)). For ANY two site
sets S,T, partition the sites as

    A=S intersection T, B=S\T, C=T\S, D=(S union T)^c.

Subadditivity and weak monotonicity give respectively

    S(AB)+S(AC)<=2S(A)+S(B)+S(C),
    S(BD)+S(CD)>=S(B)+S(C).

Subtracting shows

    f(S)+f(T)<=2S(rho_A)<=2|S intersection T| lnD.        (G4)

Empty registers have entropy zero, so endpoints are covered. No product
input or entropy additivity is used.

Draw S,T INDEPENDENTLY from the SAME posterior p(k|z). By (G3)-(G4),

    I_c(N_z,rho)<=I_c(E_z,rho)
       <=lnD sum_(a,i) alpha_(a,i)(z)^2,
    alpha_(a,i)(z)=P[K_a>=i|Z_r=z].                     (G5)

The survival events within a set can be arbitrarily correlated. Only the
two mathematical copies S,T used to average (G4) are independent.

## 4. Arbitrary Alice preprocessing and a finite Bell-error converse

Fix r,z and a strict-forward receiver. Since Bob sends nothing to Alice,
combine all Alice operations into one effective instrument {A_x} from
her finite source port to final Q_A. The label x is her full finite forward
transcript. Bob's operations compose to a conditional CPTP map B_x from
his source port to Q_B. ALL Bob outcomes are averaged in B_x; there is
no converse for an individually postselected favorable Bob branch.

Trace Alice's other final registers for this Bell-marginal analysis and
refine each finite-port A_x into finitely many single Kraus maps K_(x,j).
This is a mathematical refinement; Bob may continue to use coarse B_x.
The actual averaged output and its Bell overlap are unchanged. Independent
normal local apparatus is absorbed into these effective finite-port CP
maps, without any entropy assumption on the full residual.

Alice's refined map commutes with the conceptual channel N_z on the other
half of the Choi vector. Before that channel acts, every nonzero refined
branch is the normalized PURE reference-input vector

    (K_(x,j) tensor I)|Phi_(D^(rL))>.

The posterior p(k|z) is NOT reweighted by Alice's branch: all original
Alice marginals are the same maximally mixed state. Equivalently, the
commutation picture applies the unchanged channel N_z to this pure vector.
Thus (G5) bounds the branch coherent information for every input induced
by arbitrary Alice preprocessing. Bob's CPTP map cannot increase it.
Convexity of coherent information bounds the averaged final state by the
same quantity. Further mixing actual z and convexity give

    I(Q_A>Q_B)<=lnD E_z sum_(a,i) alpha_(a,i)(z)^2.       (G6)

Now COMPOSE the receiver with a finite bilateral Weyl twirl on its final
N-level target. Alice generates and forwards the twirl index, so the
whole composed code remains strict forward and (G6) applies to it. The
twirl preserves Bell overlap 1-d, gives uniform local marginals, and
produces a Bell-diagonal marginal theta with

    I(Q_A>Q_B)_theta
       >=lnN-h2(d)-d ln(N^2-1)
       >=(1-2d)lnN-h2(d).

One must apply the bound to the COMPOSED code; it is not necessary or
correct to assume arbitrary Alice twirling cannot raise coherent
information. The complete half-trace error epsilon controls d<=epsilon.
For epsilon<1/2, averaging and h2 monotonicity yield the EXACT finite bound

    (1-2epsilon)lnN-h2(epsilon)
      <=lnD E_z sum_(a,i) alpha_(a,i)(z)^2
       =rB-lnD Q_r,
    Q_r=E_z sum_(a,i) alpha_(a,i)(z)[1-alpha_(a,i)(z)].  (G7)

Here E_z sum alpha=r E K uses only the original unconditional iid prior.
Rank one is trivial. No residual entropy continuity, output iid limit,
entangled aid or assumption of a product conditional posterior is used.

## 5. Marginal posterior entropy forces a forward rate loss

For a queue posterior u=P(K_a|z), take independent K,K'~u. The survival
tails alpha_i satisfy the elementary identity

    sum_i alpha_i(1-alpha_i)=(1/2)E|K-K'|
       >=(1/2)(1-sum_k u_k^2)
       >=(1/2)(1-max_k u_k).                            (G8)

Let e(u)=1-max u. Put ebar_r=(1/r)sum_a E_z e(P(K_a|z)). For L>=2, define

    g_L(e)=h2(e)+e ln(L-1), 0<=e<=1-1/L.

This is continuous, concave and strictly increasing from 0 to lnL. Fano's
elementary most-likely-symbol bound and Jensen give

    A_r/r<=g_L(ebar_r), Q_r/r>=ebar_r/2
                          >=(1/2)g_L^(-1)(A_r/r).      (G9)

Combining with (G7), every admitted finite code satisfies

    (1-2epsilon)lnN-h2(epsilon)
       <=rB-(r lnD/2)g_L^(-1)(A_r/r).                  (G10)

Consequently, rate B and epsilon_r->0 force Q_r/r->0, ebar_r->0 and
A_r/r->0. This proves necessity in (G1). The ideal-supply cap follows
already from (G7), since Q_r>=0. Replacing L by the fixed nonzero support
size of p improves Fano but is unnecessary for the stated result.

Coordinate MAP minimizes expected Hamming error and attains r ebar_r.
Since H(u)>=-ln max u>=1-max u, A_r=o(r) implies this error is o(r).
Conversely any estimator's o(r) expected Hamming error bounds MAP's error;
Fano/Jensen then give A_r=o(r). An estimator with high-probability o(r)
Hamming error also has expectation o(r), because the total distance is
at most r. Conversely an o(r) expectation admits an o(r) high-probability
threshold by Markov. This establishes the equivalent formulations in (G1).

## 6. Full supply by wholly forward retention and one-shot correction

Assume A_r=o(r). Both parties use the same coordinate-MAP vector Khat(Z_r)
with a fixed tie rule. Put dbar_r=E d_H(Khat,K^r)=o(r) and choose

    h_r=ceil(sqrt[r(dbar_r+1)])=o(r),
    n_r=max{0,floor[r(EK-r^-1/4)-Lh_r]}, t_r=Lh_r.

Markov gives P[d_H>h_r]<=dbar_r/h_r->0. No physical samples or backward
messages are needed to form this common estimate. For nonconstant
inventories the original UNCONDITIONAL iid sum satisfies

    P[sum_a K_a<r(EK-r^-1/4)]
       <=exp[-2sqrt r/(L-1)^2].

This unconditional bound remains valid despite correlated posteriors
given Z_r. When the two good events hold, at least n_r purported-prefix
pairs exist: the prediction count differs from sum K by at most Lh_r.
Retain exactly n_r in a fixed common order. If the prediction count is
too small, use a product filler at the SAME intermediate rank. At most
t_r retained pairs on the good events are white rather than Bell.

Conditional on actual K^r,Z_r, unmeasured original sites remain products
of their declared Bell/white factors. Selection is coordinated from the
actual duplicated Z_r alone. Finite bilateral Weyl Bell dephasing, with
Alice's indices sent forward, makes the unconditional retained marginal
theta_r Bell diagonal on local dimension d_r=D^(n_r). This works for
every integer D, including composite D; no finite-field operation is used.
All filler and bad-estimation branches are INCLUDED. Its mass inside
the COMMON Bell-label ball of weight at most t_r is at least 1-beta_r,
where

    beta_r<=dbar_r/h_r+exp[-2sqrt r/(L-1)^2]->0.        (G11)

For constant inventory p, simply retain its exact prefix; the concentration
term is unnecessary. For large r in the nontrivial case, n_r/r->EK,
t_r=o(r), and the ball size obeys

    W_r=sum_(j<=min(t_r,n_r)) binomial(n_r,j)(D^2-1)^j,
    lnW_r<=n_r h2(t_r/n_r)+t_r ln(D^2-1)=o(r).          (G12)

This is not iid or phase-only noise. Normalize theta_r restricted to its
positive-probability Bell support inside the ball. The squared root
fidelity is at least 1-beta_r. Every global Bell vector is maximally
entangled, so its support projection Pi satisfies

    Tr[Pi(I_A tensor sigma_B)]<=W_r/d_r

for every normalized sigma_B. Hence smoothed zero-coherent information
is at least ln(d_r/W_r). The primary UNASSISTED one-shot one-way lemma
of Buscemi-Datta, arXiv1006.1896v2, Definitions (9),(11) and Lemma 2
equation (23), gives a sufficient deterministic target

    lnN_r<=ln d_r-lnW_r-2ln(1/eta_r)-3ln2,
    eta_r=max{8sqrt(beta_r),exp(-sqrt r)}.               (G13)

For all sufficiently large r, eta_r->0, beta_r<=eta_r^2/64, and the
penalty is at most 2sqrt r=o(r). Choose the largest positive integer
below the exponential right side, using rank one for early r if needed.
The resulting finite one-shot code is wholly Alice->Bob and has vanishing
Bell marginal error. It is applied ONCE to the unconditional theta_r;
no iid hashing of conditional states and no free entangled seed are used.

All selections and failures had fixed rank before the final code. The
universal pure-output lift gives complete half-trace error at most twice
the square root of its final marginal Bell infidelity, relative to its
OWN actual full residual. Thus lnN_r/r->EK lnD=B. This proves sufficiency
in (G1) for the exact governing operational target.

## 7. Relation to joint posterior entropy, costs and status

For ordinary two-way LOCC the separately frozen full-supply criterion is
H(K^r|Z_r)=o(r), with paid local acquisition and final forward correction.
The strict-forward condition here is stronger and has a direct geometric
meaning: the actual record alone must predict all but a vanishing fraction
of inventory locations. Exact block decoding is unnecessary.

For the complement record with iid uniform K in {1,2},
Z={K^r,3-K^r}, joint entropy is ln2 but A_r=r ln2. The new finite independent-
copy bound gives a strict rate loss, consistently with the separately
stronger exact forward capacity lnD. The latter used symmetric extension,
and is not replaced by an assertion of tightness of (G7).

For the Hamming-code record in the separately frozen w38 example, the
posterior vectors all lie within Hamming one of a known center. It has
vanishing expected Hamming fraction and A_r=o(r), although its optimal
Z-alone exact-vector error tends to one. It therefore attains full B
wholly forward, in agreement with this criterion.

The record is supplied. This theorem does not acquire its source-preserving
formation, posterior precision or classical compiler. The receiver spends
local selection, forward twirl communication, potentially enormous one-shot
code compilation, discarded pairs, same-rank fillers and all failure
records. Preparation, measurement, storage, timing, energy and reset remain
physical costs, without a hardware demonstration or practical comparison.
No simultaneous growing-D,L,r conclusion is claimed. The original unflagged
source has A_r=rH(K), so the original growing-entropy second-order question
is not resolved.

Primary one-shot dependency: https://arxiv.org/html/1006.1896v2 . Exact
retrieved bytes and parsed text are preserved in the collective primary
manifest. Choi channels, erasure channels, weak monotonicity, coherent
information, Fano and one-shot distillation are established machinery.
Generic one-way locking already appears in Horodecki et al., PRL94,200501
(2005), https://discovery.ucl.ac.uk/id/eprint/1362177/1/e200501.pdf . The
newly assembled source-specific equivalence is submitted to fresh internal
criticism. Historical priority and external correctness remain UNKNOWN;
physical validation, computational advantage and practical value remain
NOT_ESTABLISHED. Mission: NOT_ACHIEVED.
