# Independent Poisson-pump audit and the initial-number effect

w42, 23 October 2026. Source snapshot
`ROOT_POISSON_PUMP_SOURCE_AS_AUDITED.md` has exact SHA256
7092642128f86257babdc0074ec59787b7c2ac33961df57bbe3b643c166de478.
The direct concentration source is separately pinned c7b73357575fc1ea48db93e38e613820d8a05ab892ca2de3a5ff9bbac04df1aa
and my complete independent reconstruction of it is
`ROOT_LINEAR_INVENTORY_INDEPENDENT_AUDIT.md`, SHA
5c5b3e07cc2537de34f6fd8dbe15acdecab71b47bdd78bf662eb80df40af4394.
No other concentration critic's verdict or code is used here.

Verdict: no blocking defect found in the Poisson-diagonal candidate.
The exact receiver chronology also establishes its proposed pure-
coherent-pump extension, and in fact the broader initial-number claim
in Parts4-6. Those are independently derived post-source consequences,
not statements silently attributed to the frozen root candidate.
No external, formal, historical-priority, physical or affordability
certificate is inferred.

## 1. Poisson tails and the fixed physical interaction time

Write J_0=N+M>=1, mu=6J_0 and take the one shared pump with Poisson
number probabilities p_L=exp(-mu)mu^L/L!. Use the SAME physical time

    t=1/[chi sqrt(4J_0)]

on every branch, without observing its initial number. A number L in
[4J_0,8J_0] has lambda_L=L/N>=4s for every source S=N+m<=J_0, and
dimensionless tau_L=sqrt[L/(4J_0)] in [1,sqrt2].

For Poisson lower and upper relative deviations delta=1/3, the elementary
Chernoff bounds are respectively exp(-mu delta^2/2)=exp(-J_0/3) and
exp[-mu delta^2/(2+delta)]=exp(-2J_0/7). Their union gives

    Pr[L outside[4J_0,8J_0]]<=2exp(-2J_0/7).           (PA1)

Using a non-strict event in either Chernoff bound only enlarges the
estimate; all endpoints and integer roundings are covered because J_0
and both endpoints are integers.

## 2. Concentration through sqrt2 is justified

The finite-operator E' estimate from the root concentration proof remains
valid at every time before the first upper classical turning point:
0<=Y<=lambda and 0<=y<=lambda suffice for its Lipschitz and norm bounds.
The turning time is at least asinh sqrt(lambda/s)>=asinh2>sqrt2.
For an elementary exact last inequality, write

    sinh(sqrt2)/sqrt2=sum_(n>=0) 2^n/(2n+1)!.

After n=2 the term ratio is at most1/21, so the sum is at most
1+1/3+(1/30)/(1-1/21)=821/600<7/5<sqrt2. Thus sinh(sqrt2)<2.
There is no reliance on a rounded numerical turning time.

Every tau_L in [1,sqrt2] is on the increasing classical branch and has
y(tau_L)>=y(1)>=3s/4. Therefore

    Pr[ell<S/2 | m,L]
       <=B_N=16exp(12sqrt2)[1/N+4sqrt2/N^2].            (PA2)

This follows from the same state-L2 anticommutator proof; it does not
replace the number-state pump by a coherent classical amplitude. The
statement is uniform over all good L and all allowed m, with the single
fixed physical interaction time above.

## 3. Finite receiver, exact normalized maps, full actual residual

Retain only finite optical total-number readouts: D counts0,...,8J_0
plus overflow; C counts0,...,M+8J_0 plus overflow. On a good-L branch
the active output has ell<=L<=8J_0 and m+ell<=M+8J_0, so no overflow
exists. A bad-L branch may overflow; its ENTIRE probability is already
paid in PA1, regardless of what the receiver does there. All impossible,
low-added-number and overflow records use the same fixed logical product
default. The same target rank J_N appears on every branch.

For each observed valid (m,ell), the exact optical conditional map is
V_(m,ell); its normalized coefficients and reference state depend on
neither initial L nor its conditional distribution. The old GE code is
therefore fixed before the unknown source and pump are used. For any
fixed 0<r<ln(3/2), its good-sector Bell failure is at most

    C_N=sqrt(3/2)exp[-N(ln(3/2)-r)/2].

Parts1-2 and the Schur positive-effect argument give

    q_N<=b_N=min{1,2exp(-2J_0/7)+B_N+C_N},             (PA3)
    d(Omega,Phi_(J_N) tensor Omega_actual,residual)
                                              <=min{1,2sqrt(b_N)}. (PA4)

The final inequality is applied to the actual state after bounding its
Bell probability. It includes the entire real pump, every actual source
and apparatus purifier, and coherent retained seed/readout environments.
No ideal/reference purifier is identified with any of them. Only the
claimed large-N region admits the nontrivial code; smaller N may use the
fixed logical default. The prefactor in PA2 is deliberately very loose.

## 4. The entire effect is diagonal in INITIAL pump number

This checks the source's proposed coherent-pump extension, including
the finite aggregated overflow. Let F be the bounded final Bell-failure
effect pulled back to the initial capped A and pump, after averaging
the fresh passive ensemble. The shared-pump unitary is covariant, so
the capped-A commutant gives

    F=direct_sum_m I_(H_m) tensor B_m,

for bounded pump operators B_m. We now show B_m is number diagonal.

In a kept optical readout, the D total-number label ell is an exact
orthogonal pointer record. It is retained and not later erased or
coherently recombined with a different ell. Thus the Bell probability
has no cross terms between ell and ell'. A fixed ell term from initial
pump L ends with pump |L-ell>. The pump is untouched by the receiver
and is in its actual complement. Its orthogonality gives

    <L'-ell|L-ell>=delta_(L,L').

This proves number diagonality on every coded or exact low-number
branch, independently of any source-purifier choice.

The aggregated overflow is different and must not be treated as if an
infinite hidden count were read. Its logical output is the SAME fixed
product state, hence its Bell-failure coefficient is the scalar
1-1/J_N times the overflow probability; its old optical state is left
in the residual. Within this probability, the unprocessed optical D
sectors with different ell are already orthogonal, even though they
share one overflow pointer. Consequently only ell=ell' survives the
optical inner product, and the same final-pump orthogonality again
forces L=L'. C overflow is a subset of D overflow on every admitted
input, because m<=M. Invalid default branches cause no additional
cross term on the admitted exact support.

It follows on the entire declared input, including this finite overflow,
that

    F=sum_(m=0)^M sum_(L>=0)
             f_(m,L) Pi_m tensor |L><L|, 0<=f_(m,L)<=1. (PA5)

All sums define bounded effects. On good L, f_(m,L)<=B_N+C_N; elsewhere
it is at most one. This is a marginal EFFECT identity, not a claim that
the entire source/pump state or full readout purification becomes
number diagonal. Retaining old records coherently is compatible with
PA5 because the Bell test acts as identity on them.

## 5. Coherent pumps and arbitrary source-pump correlations

For a pure coherent pump |alpha>, |alpha|^2=mu, PA5 makes its Bell
failure identical to the Poisson-diagonal pump, at every source. No
energy dephasing apparatus or uniform continuous phase register is
needed to apply PA3-PA4 to this stronger preparation. The pump's energy
coherence is nevertheless an initial resource; it is not formed for
free from thermal states and an energy-diagonal work store.

More generally take ANY normal joint initial A:P state satisfying

    supp rho_A subset P_(N,M),
    <L|rho_P|L>=exp(-mu)mu^L/L!,

with B vacuum and the fresh passive seed independent of the whole
committed source/apparatus. A and pump may have arbitrary correlations,
including energy coherences. Every input/pump purifier is inaccessible
to the receiver and remains in the actual final residual. PA5 gives

    q_N=sum_m,L f_(m,L) Tr[(Pi_m tensor |L><L|)rho_AP]
        <=B_N+C_N+Pr_(rho_P)[L bad].

Thus the SAME PA3-PA4 holds without assuming source-pump independence.
This removes a possible free-independence inference; it does not provide
a physical pump-number-profile certificate. A seed correlated with the
source or a receiver that coherently erased/recombined the retained
number records would be a different protocol and is not justified by
this chronology argument.

## 6. Exact or upper linear resource prices, including correlations

For the pump Gibbs reference gamma_L=(1-q)q^L, 0<q<1,

    sum_L p_L/gamma_L
       =exp[mu(q^(-1)-1)]/(1-q).                       (PA6)

For the Poisson-diagonal state the maximum pointwise ratio is at most
this sum, proving root C3. For a pure coherent state the rank-one
formula gives the EXACT value

    D_max(|alpha><alpha| ||gamma)
       =ln<alpha|gamma^(-1)|alpha>
       =mu(q^(-1)-1)-ln(1-q).                          (PA7)

In fact every pump density operator with the stated Poisson diagonal
has the same finite UPPER bound: the positive operator
gamma^(-1/2)rho_P gamma^(-1/2) has trace PA6 and operator norm at most
that trace. Its off-diagonal terms cannot invalidate the bound.

There is also a finite bound on the entire ACTIVE prepared APB state,
even for the arbitrary source-pump correlations of Part5. Let the
optical Gibbs mean be v>0, h(v)=ln(1+1/v), and B be independent vacuum.
In the product reference theta_(A^N B^N) tensor gamma_P, the A cap and
the vacuum B factor give

    Tr[(theta tensor gamma)^(-1/2)rho_APB
                       (theta tensor gamma)^(-1/2)]
      <=exp[2N ln(v+1)+M h(v)] sum_L p_L/gamma_L.

The weighted trace is finite. Equivalently the corresponding weighted
square root of rho is Hilbert-Schmidt, so the positive weighted operator
exists as a trace-class operator, has norm at most its trace, and yields
the rigorous form/order certificate

    D_max(rho_APB ||theta tensor gamma)
       <=2N ln(v+1)+M h(v)
                    +mu(q^(-1)-1)-ln(1-q)=O(N).        (PA8)

Finite Fock truncations followed by the finite weighted-trace bound
justify the same conclusion without applying an inverse Gibbs operator
on an unspecified domain. If the references represent one physical bath,
take q=exp(-2beta hbar omega) and h(v)=beta hbar omega.

PA8 is an active STATE upper certificate. It neither bounds the old
rejected source, preparation/controller/program/purifier resource, nor
proves exact work-only formation of a coherent state or arbitrary joint
source-pump correlations. Initial energy coherence, resets, apparatus
purity and shared-coupling control remain separate supplied resources.
The initial pump has UNBOUNDED number support: linear mean energy and
linear Gibbs-order price must not be relabeled a hard photon cap.

## 7. A weaker moment-only extraction premise, and its resource limit

PA5 shows that exact Poisson statistics are not necessary for the
receiver error conclusion. Any pump number marginal of mean6J_0 and
variance V_N obeys

    Pr[L outside[4J_0,8J_0]]<=V_N/(4J_0^2)

by Chebyshev. If V_N=O(J_0), replace PA1 by this O(1/N) bound. Arbitrary
pump number coherences/source correlations remain allowed. No empirical
variance upper bound or future source model is acquired by this formula.
Finite first and second moments ALONE do not imply PA6-PA8 or finite
D_max; a small heavy number tail can have finite moments and unbounded
Gibbs likelihood ratio. The moment-only Bell conclusion and the Poisson
linear operator-resource certificate must remain distinct claims.

An explicit separation is useful. Let zeta_k=C/(k+1)^4 on k>=0, with
C the reciprocal normalizing sum, mean a and variance v_zeta. Elementary
integral bounds give 0<=a<=1/2 and v_zeta<=1. For J_0>=1 put
delta=1/(J_0+1) and mix zeta with a Poisson state of mean

    mu_b=[6J_0-delta a]/(1-delta)>0.

The resulting pump number law has mean EXACTLY6J_0 and variance

    (1-delta)mu_b+delta v_zeta
        +delta(6J_0-a)^2/(1-delta)
       <=6J_0+1+36J_0<=43J_0.

Nevertheless its tail is at least delta C/(k+1)^4, so its likelihood
ratio to every faithful one-mode thermal Gibbs state is unbounded and
D_max is infinite for every N. It therefore obeys the same moment-only
vanishing receiver error while violating every finite exact max-order
certificate. No preparation or affordability claim is attached to this
counterexample; it only prevents confusing the two mathematical premises.

## 8. Resources, baseline, primary and review boundaries

One Poisson pump eliminates a supplied exact Fock number, QND pump-band
tests and repeated thermal-candidate inventory from the MODEL. It still
needs a trusted source with the declared number law or paid errors, one
shared equally coupled mode, lossless calibrated interaction, original
cap/vacuum factory, both optical output blocks, passive seed, total-number
readout, large general sector codes and retained/reset apparatus. No
such full physical factory or scalable decoder has been acquired.

The SAME pump-number good event and conditional Phi_(d_ell) state for
both-input vacuum give every rate below g(1/2)>ln(3/2), with all bad
pump numbers/defaults and actual pump residual paid. Source-pump
correlations are initial resources rather than evidence of a net gain.
There is no matched yield or full-resource advantage established here.

Classical/coherent pumps, trilinear chains, incoherent-pump studies,
number-sector entanglement and Gaussian/thermal resource accounting are
established; `PUMP_PRIMARY_BOUNDARY.md` retains the exact predecessor
scope. PA5-PA8 are explicitly evaluated consequences for this supplied
receiver chronology, not a new generic quantum-pump principle. Exact
priority remains UNKNOWN. The result has a complete written independent
internal reconstruction, not external review or physical validation.
