"""Replay the separate exact partial-Good expectation fixture."""
from fractions import Fraction as F
from pathlib import Path
import json
from check_exact_ensemble import fixture


def main():
    row = fixture(K=2, tau=F(1, 2))
    result = {"status": "PASS", "scope": "Exact finite partial good-event test; no concentration or giant code execution.", "row": row}
    payload = json.dumps(result, indent=2) + "\n"
    out = Path(__file__).with_name("EXACT_PARTIAL_EVENT_CHECK.json")
    if out.exists():
        if out.read_text() != payload:
            raise RuntimeError("refuse changed frozen partial-event result")
    else:
        out.write_text(payload)
    print(json.dumps({"status": "PASS", "good": row["good_frames"], "frames": row["finite_pauli_frames"]}))


if __name__ == "__main__":
    main()
