# Fresh audit of the no-payload-cap delayed-stream theorem

23 October 2026, w49. **NO BLOCKING DEFECT FOUND**, for the exact source
`work/workers/w19_dose_matrix/coherent_initializer_invention/positive_beta_strong_attack/GENERAL_DELAYED_STREAM_BOUND_V1.md`,
SHA256 `a0b1d30f28ff50fa646d2d7561579bbf9344c768c2f11ece5c69114792d02f6b`.
This source was read completely after the separate bounded-payload audit
`BOUNDED_LATENCY_STREAM_FRESH_AUDIT_V1.md` had already been frozen.
No new peer verdict was used. The old proof and audit remain unchanged.

This is a converse for fresh sequential arrivals and permanently closed
outputs. It removes the arrival-payload cap from the earlier stream
argument, not the source/closure restriction. It still does not solve
the initially available whole-message / deferred-decoder strong problem.

## 1. Dependencies and exact strengthened interface

The only device-specific analytic premise is the same universal weak
finite-error statement from w19 source SHA
`666db8460f95b5d48376ce9d8c7375cca640e94705635da34c732a2a4be9d20d`:

    2F log2 K-h2(F) <= 2 ell C                      (B1)

for every finite fresh source independent of the whole arbitrary normal
resource. The explicit quadratic C is given in the earlier full audit.
The unchanged root-retaining device, arbitrary entangled bath/lab
initialization, arbitrary backward quantum messages, sole-forward-qutrit
ports and unconditional TP outputs are retained.

The source schedule and every finite K_s may depend on N. No uniform cap
on `log2 K_s` is assumed. Each source is exactly fresh at its declared
birth, with no earlier operations on its message half. Each output is
closed by the end of call `s+D` and forever untouched afterwards.
Crucially the new source also explicitly requires **all outputs closed
by the charged horizon N**, including any flushing calls in N. This
extra endpoint statement is used for the last partial cell. It should
remain explicit; a delay deadline extending beyond N alone would not
prove closure at that earlier truncated endpoint without an additional
argument about the absence of later forward calls.

Normality and exact conditional freshness are established in Sections3
of the earlier audit, and are reconstructed here again for the new cells
below. No selected branch is operationally renormalized or supplied as
a forward success flag.

## 2. Independent proof of the needed port strong bound

The source's ordinary qutrit-wire inequality is correct, including arbitrary
backward communication and initial normal entanglement:

    F <= min{1,3^(2 ell)/K^2}.                       (B2)

Here is an independent normalization reconstruction avoiding any assumption
that a global linked Choi matrix is a deterministic comb. Use the fixed
cut Alice | (bath and Bob). All actual device unitaries are on the receiving
side after the incoming qutrit crosses this cut. Replace each incoming
identity qutrit wire analytically by a shared normalized Bell pair and
the selected normalized Bell bra on the input and Alice's half. In the
same basis the resulting linear map is exactly

    (<Phi|_(A a) tensor I_b)(I_A tensor |Phi>_(a b))
       = I_(A->b)/3.                               (B3)

Selecting this branch at each of ell wires therefore reproduces the
ENTIRE original adaptive protocol's amplitude times `3^-ell`, and its
unnormalized output state times `3^(-2 ell)`. This identity is chronological;
it does not require that later inputs are independent of previous outputs
or backward messages.

Complete every selected Bell bra to a local TP instrument. Extend the
strategy on other outcomes arbitrarily, while retaining the original
operations on the selected branch. The completed comparison has shared
entanglement and backward messages but no forward path. The shared pairs
are independent of the fresh logical source. No-signalling makes Bob's
unconditional comparison output exactly `(I_R/K) tensor tau_B`, with
tau_B independent of the logical input. This remains true for bath/lab
entanglement: it is part of the initial source-independent receiver/sender
resource. A positive selected branch is bounded by the completed total
output; it need not itself be normalized or have a product R,B marginal.
Its Bell overlap is therefore at most `K^-2`. Multiplying by `3^(2 ell)`
proves (B2). Finite Bell projectors, normal controls and positive partial
traces make the argument valid with normal infinite laboratory memories.

This is only a dimension/no-signalling comparison. No Bell result is
delivered across the cut, no apparatus is acquired and no physical bath
is reset. It is the same finite-wire argument as the source's positive
Choi linking, with the factor and branch completion made explicit.

## 3. Partial cells repair boundary loss without a payload cap

For fixed integers W>=1,D>=0, put m=W+D. For each phase phi modulo m,
partition the entire integer call line into nominal cells
`[phi+k m,phi+(k+1)m)`. Intersect every nonempty cell with `[0,N)` and
keep those partial boundary cells as well as full cells.

The resulting actual lengths ell_j satisfy `1<=ell_j<=m`,
`sum ell_j=N` and `J<=N/m+2`. A birth is selected if its position within
its nominal cell is in `0,...,W-1`. For every actual birth t and every
residue r in that set there is exactly one phase with
`t-phi == r (mod m)`. Hence t is selected by exactly W phases, even at
the two ends. There is a phase for which

    sum_j A_j >= W Q/m, Q=sum_s log2 K_s.           (B4)

No payload size enters this average. The selected sources in a nonfinal
cell close before the next actual cell starts: their latest possible
birth plus D is the nominal cell end minus one. A first partial cell
merely omits negative-time births. In the final partial cell the explicit
all-closed-by-N contract supplies closure at its actual endpoint.

Condition on previous selected-cell Bell tests. Those systems are already
closed, so the tests commute with subsequent dynamics. Nonzero projection
followed by tracing produces an arbitrary normal conditional resource.
All selected source pairs in the next cell are still untouched and
factor as exact independent Bell pairs from that resource. Preparing this
group at the actual cell start, while leaving its physical input operations
delayed to their births, represents the same TP interval protocol. The
other source traffic is allowed ancillary resource. Applying (B1),(B2)
therefore gives for each conditional pass probability

    p_j <= min{1,a_j/A_j, exp[-2 ln2 (A_j-ell_j L0)]},
    a_j=C ell_j+1/2, L0=log2 3.                    (B5)

For A_j0 its vacuous test has bound one. Conditional resources are never
assumed equal to the unconditional ones. Ignoring the other source tests
increases the pass probability, so `F_all<=product_j p_j` follows from
the ordinary conditional chain rule for the selected closed tests.

## 4. Uniform excess-payload exponent, including huge K_s

Put b=2mL0. If `a_j<A_j<=b`, the weak factor in (B5) gives

    -ln p_j >= ln(A_j/a_j)
             >= (A_j-a_j)/A_j >= (A_j-a_j)/b.       (B6)

The middle inequality follows by integrating `1/x>=1/A_j` on
`[a_j,A_j]`. If A_j<=a_j the desired positive-part bound is zero.

If A_j>b, then `ell_j L0<=mL0<A_j/2`, and the port bound gives

    -ln p_j >= 2 ln2 (A_j-ell_j L0)
             >= ln2 A_j >= (A_j-a_j)_+/b.           (B7)

The last step uses `b ln2=2m ln3>1` and a_j>0. This numerical inequality
has ample elementary margin: `ln3=integral_1^3 dx/x>=2/3`, so
`2m ln3>=4m/3>1`. Thus for every finite payload, with no upper bound,

    -ln p_j >= (A_j-a_j)_+/b.                      (B8)

Sum and use (B4), `sum ell_j=N`, `J<=N/m+2`:

    -ln F_all >= [WQ/m-CN-N/(2m)-1]/b
       >= [({delta W-CD-1/2})N/m-1]/b.             (B9)

Choose `W=ceil[2(CD+1/2)/delta]`. Then
`delta W-CD-1/2>=delta W/2`, and substitution gives exactly

    F_all <= min{1,exp[1/(2mL0)-delta W N/(4m^2L0)]}.

The proof is valid when some A_j or K_s is arbitrarily large; the port
comparison handles that case rather than a boundary-payload bound.

For fixed C>0,delta>0, `m=O(D+1)` and `W/m>=1/[1+delta/(2C)]`.
Therefore `D_N=o(N)` forces F_all to zero, with exponent at least of
order `N/(D_N+1)`. For C in a fixed positive bounded interval and
`0<delta_N<=1`, the source's sufficient scaling
`delta_N^2 N/(D_N+1)->infinity` also follows: m is at most a constant
times `(D_N+1)/delta_N`, while W/m is uniformly bounded below. No
optimality of this sufficient law is claimed.

## 5. Own checks, scope and verdict

`check_general_stream_partial_cells.py` is an independently written
finite integer/log diagnostic; it imports no peer code or earlier script.
Its output `GENERAL_STREAM_INDEPENDENT_DIAGNOSTICS.json` records exact
W-fold coverage, actual-cell length sum, J bound and closure indexing for
58,800 configurations `N=1,...,140`, `W=1,...,20`, `D=0,...,20`,
enumerating5,292,000 partial/full cells, plus9,548 scalar weak/port-envelope
stress cases. All passed. Runtime inside Python was20.50093s; peak memory
and total inference/review cost were not measured.
The all-N proof is the residue and scalar analysis above, not extrapolation
from these cases. The earlier audit's entangled correlated-error fixture
and explicit future-use/output-reuse negative controls remain applicable.

No new mathematical blocker was found. No formula correction is needed.
The explicit all-outputs-closed-by-N clause is an important endpoint
premise, and future source independence plus permanent output closure
remain load-bearing. The partial-cell improvement removes the old fixed
arrival-payload cap and weakens no causal requirement. Every actual guard
or flush call stays in N; no bath reset, local depth truncation, source
factory, efficient encoder, calibration or practical advantage is supplied.

This theorem still cannot partition an initially available giant source
into fresh conditional arrivals: earlier selected tests can steer source
halves that were used by the earlier encoder. Nor can it insert an early
test on outputs reused by a later joint decoder. Those are the unrestricted
strong-converse obligations left open. Mathematical priority, external
verification, achievable rates and physical value remain unestablished.
