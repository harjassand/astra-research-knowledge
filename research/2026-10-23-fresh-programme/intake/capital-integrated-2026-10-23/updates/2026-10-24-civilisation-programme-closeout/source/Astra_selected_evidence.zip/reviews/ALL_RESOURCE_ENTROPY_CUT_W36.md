# Independent audit: arbitrary-resource two-cut entropy bound

23 October 2026, w36. Full exact source reviewed:
`work/workers/w19_dose_matrix/coherent_initializer_invention/ALL_RESOURCE_ENTROPY_BOUND_V1.md`,
SHA256 `50aa458a8d1c0736eb3c5ce44988ee66de8181373d430f9581b03587df89b38c`.
**No blocking defect found at the stated interface.** This is an internal analytic audit, not external certification, historical priority or a physical result. No new numerical channel tests were run for this generic entropy step.

The fresh finite-dimensional logical Bell source must be product with the ENTIRE initial normal bath/laboratory/purifier resource. That resource may otherwise have arbitrary horizon-dependent entanglement, entropy, support, depth and coherence. All N chronological forward qutrit calls count; backward quantum communication and local preshares are allowed, with no extra forward signal or direct bath access and no postselection. These premises are essential.

For the receiving cut(E plus Bob plus inert G), initial I(R:receiving)=0. Sending input port A_t into that side increases it by I(R:A_t|receiving)<=2S(A_t). V acts inside that side and cannot add another transfer increment. A Bob-to-Alice message removes systems from that side, so data processing decreases its mutual information. Local Alice TP actions leave its reference marginal unchanged. Thus final I(R:Bob)<=2sum S(A_t), even with initial bath/lab entanglement.

For the receiving cut Bob alone, the bath interaction acts outside Bob; moving output port B_t into Bob costs at most2S(B_t). Backward messages again remove from Bob and local operations obey data processing. Initial I(R:Bob)=0 by the same fresh-source premise. Thus I(R:Bob)<=2sum S(B_t). Both conceptual cuts use the SAME actual protocol marginals before and after each call. Their minimum is at most sum[S(A_t)+S(B_t)]. There is no assumption that Bob physically controls the bath.

Normal infinite ancillary systems are safe here. Mutual information is defined by relative entropy, and finite R gives I(R:Y)<=2log2 K for every receiving system. The increase from adjoining a finite port has the ordinary well-defined chain rule and is bounded by2S(port). The opened primary [Shirokov1506.06377v2](https://arxiv.org/pdf/1506.06377), Proposition3 and Theorem2/Remark6, establishes the extended conditional-entropy bounds, compatible CMI chain rule and finite-marginal upper bounds on normal separable Hilbert spaces. Converting natural logarithms to bits preserves the inequalities. No subtraction of infinite laboratory entropies is needed; infinite backward registers are removed by direct DPI, not assigned a finite entropy budget.

The device identity at beta0 reconstructs exactly:

    U^*q_B U=|0><0|_A tensor(I-P0),
    q_A+U^*q_B U=I-|0><0| tensor P0<=I.

It holds on arbitrary correlated A,E states. Let u,v be actual input/output colored probabilities. Then u+v<=1. The qutrit entropy envelope g(x)=h2(x)+x follows by charge pinching and maximizing the rank-two colored block. Concavity gives g(u)+g(v)<=2g((u+v)/2)<=2g(1/2)=3. The last monotonicity is used only below1/2, where it is valid. Thus I(R:Bob_final)<=3N without any initial-resource restriction beyond fresh-source independence and the interface.

For any normalized decoded K-dimensional output, the comparison state omega_R tensor omega_B has omega_R=I/K and Bell-test probability exactly1/K^2. Relative-entropy measurement monotonicity gives

    I(R:B)>=d_2(F_e||1/K^2)>=2F_e log2 K-h2(F_e).

Both K factors are accounted for. Combining yields the exact one-shot inequality2F_e log2 K-h2(F_e)<=3N. Reliability implies rate<=1.5. At K=3^N it gives limsup F_e<=3/(2log2 3), not F_e->0. This is a weak converse, not CP domination or a strong-converse exponent for arbitrary entangled initializers.

The matched-pair all-beta matrix also checks. Every nonroot pair {|0,S_j x>,|j,x>} has q_A+V^*q_B V eigenvalues1±beta; the two-root block is zero. Therefore u+v<=1+beta on every correlated input. Jensen and the entropy maximum at2/3 give

    Q<=g(min{(1+beta)/2,2/3}).

The small-beta expansion3/2+beta/2-beta^2/(2ln2)+O(beta^4) is correct. It is weaker than the product/separable quadratic bound, so it leaves an actual linear-versus-quadratic upper-bound gap for initially entangled resources at positive beta. No achieving code is inferred.

Generic information-flow cuts, entropy maximization, relative-entropy Bell tests and normal conditional information are established tools. The evaluated exact-device obstruction is the candidate contribution. The inherited lower code is still required for equality1.5; this audit does not establish its validity. External correctness, priority, useful efficient codes, physical preparation, precision, bandwidth, resets, energy and practical value remain UNKNOWN/UNACQUIRED. An initially correlated logical source, extra forward carrier, changed interaction or postselected task would invalidate the stated model.
