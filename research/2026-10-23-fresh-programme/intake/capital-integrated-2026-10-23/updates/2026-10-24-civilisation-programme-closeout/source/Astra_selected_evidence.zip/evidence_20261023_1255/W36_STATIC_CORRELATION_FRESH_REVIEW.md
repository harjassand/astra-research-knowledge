# Fresh full review: static initializer correlations and entanglement cost

**Verdict: no blocking mathematical defect found at the exact stated interface.**
This is an independent internal analytic reconstruction, with separate finite
normalization diagnostics. It is neither external proof certification nor
evidence of a useful physical apparatus, an achieving code, efficiency, or
historical priority. The scientific mission remains NOT_ACHIEVED.

## Frozen sources and independence

This review covers all of root's
`STATIC_CORRELATION_STRONG_CONVERSE_TRANSFER.md`, SHA256
`72256264840e9ec37943b9bb3a93d7864493316bd83caf97f6c5c35215c04d5f`,
and the same-interface
`INITIAL_ENTANGLEMENT_STRONG_CONVERSE_ADDENDUM.md`, SHA256
`ae8b0ae7d842f37cddccef920f4d1393163451f8313e3c9acce0d2ed9216a286`.
Their bytes are preserved in `sources/`. I reread and independently
reconstructed the exact W19 prerequisite `FULL_PROOF_V1.md`, SHA256
`1556727069358baa8838813d3364eb2e33869dd32cc6d04df682a4dc868328cc`,
especially Sections 1–5. My earlier W19 receipt was not used as a substitute
for that reread. W49's corroborating static/entanglement receipts were not
read or imported as evidence for this verdict.

Before receiving or opening the pending entanglement addendum, I preserved
`PRE_ADDENDUM_RECONSTRUCTION.md`, SHA256
`130b9c9e6f770c8c412cc38e503cf88d0df4e94fab39ea69a78185c18cb48595`.
It independently reconstructs normal-SEP closure, binary DPI followed by
infimum, rank-d separable pinching, and the fixed-bath-marginal uniformity.
The root addendum attributes the latter strengthening to this reviewer.
These are generic resource-comparison tools applied to the reviewed device
bound; exclusive priority is not claimed.

## Exact protocol contract

The fresh finite logical Bell source Phi_RM is initially product with the
ENTIRE normal initializer eta_EL. Here E is the actual inaccessible seeded
tree bath; L includes all Alice/Bob laboratory resources and preshares.
N is the prescribed number of forward qutrit device calls. No extra forward
classical, quantum, timing, acceptance, or transcript wire is supplied.
Arbitrary backward quantum/classical messages and arbitrary normal local
resources are granted within the original strategy model. Decoding is TP
with a fixed K-dimensional output, and all failure branches count in the
unconditional Bell fidelity F. The initial resource may be entangled across
E:L, as long as the source remains independent of all of it.

For a fixed allowed strategy, including every measurement branch and its
control, the map from the WHOLE initial density eta_EL to final R/receiver
density is normal CPTP. Its Bell probability is a bounded normal effect
F(eta)=Tr(T eta), 0<=T<=I. The strategy may have been designed using a full
description of eta; it must then be held fixed when a comparison state is
substituted. The substitutions below are mathematical comparisons, with no
physical bath filter, preparation, reset, charge measurement, or modification
of the strategy. Source independence is preserved by comparing resources
only, while tensoring the same fresh Phi_RM in every case.

## Fresh reconstruction of the exact product-process prerequisite

Write a=1-b, b=beta^2, alpha=sqrt(a). In the actual bath representation,

    K_00=alpha R+i beta I,
    K_0j=alpha S_j, K_j0=alpha S_j^*, K_jj=i beta I, j=1,2,
    S_i^* S_j=delta_ij I, sum_j S_j S_j^*=I-P0,
    R=R^*, R^2=P0.

For sigma_p=diag(p,(1-p)/2,(1-p)/2), the memory CP map
Theta_p(X)=sum_io sigma_o^-1 K_oi^* X K_oi obeys the WHOLE-memory identity

    Theta_p(I)=[(2-b)/p+(2+2b)/(1-p)]I
                   +a[1/p-2/(1-p)]P0.

The physical root is retained. In particular K_00^*K_00=aP0+bI: the root
cross term cancels because R is self-adjoint, not because it is discarded.
For p>=1/3 the root term is nonpositive. The minimizing
p=sqrt(2-b)/(sqrt(2-b)+sqrt(2+2b)) lies in [1/3,1/2], so

    Theta_p(I)<=H_b I,
    H_b=(sqrt(2-b)+sqrt(2+2b))^2.

For any independent normal bath density omega, the finite-port Choi matrix
J_N(omega) uses UNNORMALIZED input Bell vectors. Whiten its output by
sigma_p^(-N/2). Its trace is exactly

    Tr[(I tensor sigma_p^(-N/2)) J_N
                       (I tensor sigma_p^(-N/2))]
        =Tr[omega Theta_p^N(I)]<=H_b^N.

The order of multiplication is important. A history block is
K_(o_N i_N)...K_(o_1 i_1), and summing the final squared block first inserts
Theta_p(I); each earlier sum applies the same positive map again. No
memory-independence assumption is made between calls. There is no trace of
the infinite-dimensional memory identity: a bounded memory operator is
paired with the normal trace-one omega. Finite Choi positivity gives

    J_N(omega)<=H_b^N I_A^N tensor sigma_p^N.

This is uniform over all normal omega, including coherent and
horizon-dependent bath states. The right side is H_b^N times the Choi
operator of a NORMALIZED product-replacer process.

For the chronological assistance extension, fix this SAME omega throughout
the prefixes of the N-call process and use C_N=H_b^N at EVERY prefix. The
positive terminal difference

    D_N=(C_N J_replacer,N-J_actual,N)/(C_N-1)

has positive prefixes by successive causal partial traces and satisfies the
deterministic recursion Tr_Bn D_n=I_An tensor D_(n-1), D_0=1. Thus it is a
normalized deterministic comb. An admissible adaptive strategy maps its
convex decomposition into normalized outputs; the actual output is bounded
by C_N times the replacer output. This is why a block-channel CP bound can
be used with the same feedback strategy, rather than incorrectly treating
adaptive inputs as an independent static input block. Infinite normal
laboratory memories may be linked by the normal fixed strategy itself;
alternatively finite-horizon trace-norm approximations preserve the bound.

Under the replacer, the Bob side has no Alice-to-Bob path. Starting from a
fresh source independent of all preshares, induction over local TP actions,
backward messages, and fixed forward outputs leaves R product with all
Bob-held systems. Alice local actions cannot alter the reduced R/Bob
product; Bob operations and messages back to Alice do not create such a
correlation. The final state is (I_R/K) tensor zeta_B. Its normalized Bell
overlap is 1/K^2, not 1/K. Therefore the exact SAME-interface uniform bound
needed by root is

    F_N(omega_E tensor xi_L)<=min(1,H_b^N/K^2)

for all normal omega, xi, every allowed strategy and every prescribed N.
The arbitrary eta_EL used in the transfer is not silently claimed to be
product; only its comparison state is product.

## Static finite-rank comparison and half-trace cutoff

Let P have finite bath rank d>=1, p=Tr[(P tensor I)eta]>0, and let
eta_P=(P tensor I)eta(P tensor I)/p, xi_P=Tr_E eta_P. Positive d-by-d block
Cauchy gives eta_P<=d I_P tensor xi_P. Equivalently,

    eta_P<=d^2 (P/d) tensor xi_P.

This remains valid for arbitrary normal infinite-dimensional L: each test
vector has d components, each block quadratic form is bounded by its
positive diagonal block, and every diagonal block is at most xi_P. The
product comparator is a normalized normal state. A maximally entangled
rank-d resource has comparison density I_(d^2)/d^2 on its support and
requires the factor d^2. Replacing this product factor by d is false.

The same fixed normal physical map preserves the positive initializer
order, and its product comparator has the just-proved bound. Hence
F(eta_P)<=d^2 H_b^N/K^2. The normalized purification obtained by projecting
an initial purification has overlap sqrt(p). Its pure-state half-trace
distance is sqrt(1-p); partial trace and the physical map contract that
distance. Thus

    T(eta,eta_P)<=sqrt(1-p),
    F_N(eta)<=min(1,sqrt(1-p)+d^2 H_b^N/K^2).

There is no missing factor of two with T=||.||_1/2. The full trace norm would
indeed be twice this. Probability tail 1-p alone would be insufficient for
a coherent initializer: pure P/Q superpositions saturate sqrt(1-p). The
p=0 case is trivial and is not normalized. P need not commute with eta,
root charge, or the device; it is applied only to the INITIAL comparison.

## Normality, limits, and exact rank quantifiers

The seeded-tree E is separable. For any fixed normal bath marginal tau,
finite-rank P_M increasing strongly to I have p_M=Tr(P_M tau)->1, with no
finite depth, energy, entropy, or max-relative-entropy premise. At a fixed
rate margin log2 K_N>=N(c_b+delta), c_b=(1/2)log2 H_b, fixing M first gives
d_M^2 2^(-2delta N)->0. Taking N to infinity before M proves F_N->0.
It is invalid to replace this order by an assumed common tail modulus for
all normal states.

The stronger valid quantifier is uniformity over EVERY normal extension
eta_(E L_N),N with this ONE fixed bath marginal tau, all laboratory dimensions,
and all allowed strategies: p_M is then the same scalar Tr(P_M tau). The
whole eta need not be fixed. Independent horizon-dependent laboratory
preshares are included. Uniformity remains pointwise in tau.

For a varying marginal, the stated premises p_N->1 and log2 d_N=o(N) suffice.
For log2 d_N<=sN+o(N), the original product comparison gives ceiling c_b+s.
This rank condition concerns initial smooth bath support dimension; it is
neither a preparation cost nor a depth/energy law. An exponentially small
tail is needed to infer an exponential decay rate from this cutoff bound;
an unspecified vanishing tail gives only the strong-converse limit.

## Fresh reconstruction of the SEP/E_R addendum

For each fixed strategy the scalar uniform product bound passes to finite
convex mixtures by initializer linearity, then to their trace-norm normal
closure SEP(E:WHOLE-L) because 0<=T<=I. Individual product terms may use
different bath densities and different laboratory preshares; uniformity of
the product theorem permits this. No common replacer OUTPUT for all terms
is needed for this scalar step. Alice–Bob entanglement inside L is allowed,
and initial classical bath/laboratory correlation is included in SEP.

Put Delta_N=2log2 K-N log2 H_b>0. For any normal sigma in SEP, let
f=F(eta), q=F(sigma)<=2^(-Delta_N). Relative-entropy data processing through
the SAME full initializer-to-output map followed by the binary Bell test
gives, in bits,

    D(eta||sigma)>=d_binary(f||q)
      =-h2(f)-f log2 q-(1-f)log2(1-q)
      >=f Delta_N-h2(f).

The last dropped term is nonnegative. The argument does not assume q<=f,
finite marginal entropies, finite relative entropy, or a minimizing sigma.
For q=0 use the extended-value convention; if f>0 the divergence is infinite,
and if f=0 the desired statement is still valid. Establish the common lower
bound for EACH normal sigma, THEN take its infimum. Normal DPI is used
directly; no unsupported continuity limit of E_R is needed. Therefore

    E_R(E:L)_eta>=f Delta_N-h2(f),
    F_N(eta_N)<=[E_R(eta_N)+1]/(2delta N)

at rate margin delta. This establishes F_N->0 for INITIAL E_R=o(N), without
asserting exponential decay. Above-threshold nonzero limiting fidelity
would require a linear initial entanglement budget; this necessary cost
does not construct an encoder. Entanglement generated by subsequent calls
is not charged as initial resource entanglement.

The mutual-information corollary uses the normalized product of actual
marginals, an allowed separable comparison, so E_R<=I(E:L) defined by
relative entropy. It needs no separate finiteness of the marginal entropies.
The bath entropy corollary also holds: purify eta across E:(L+F), Schmidt
dephase that pure normal state, and trace out F. Its countable Schmidt
dephasing is a normal separable state in the trace-norm closure, its relative
entropy from the pure state is S(eta_E), and normal DPI gives
E_R(eta_EL)<=S(eta_E) when that entropy is finite. Fixed resources with
infinite E_R or infinite bath entropy are instead covered by the cutoff
argument. These sufficient criteria are not necessary conditions for the
strong-converse conclusion.

Finally, on a rank-d bath support the normalized bath pinching
chi=Delta_basis(E)(eta_P) is a finite mixture of normal bath/laboratory
products and eta_P<=d chi. Apply the scalar SEP bound to get the improved
addendum statement

    F_N(eta)<=sqrt(1-p)+d H_b^N/K^2.

It retains the SAME normalized half-trace tail. This is the addendum's E4,
and log2 d_N<=sN+o(N) now gives ceiling c_b+s/2. The generic factor d is
sharp: every separable chi has overlap <=1/d with Phi_d, so Phi_d<=c chi
forces c>=d, while its own Schmidt dephasing attains c=d. This does not
show that an actual device fidelity prefactor is tight.

## Independent diagnostic evidence and its limits

`check_static_order.py` imports no peer implementation. Its raw
`STATIC_ORDER_DIAGNOSTIC.json` records 18 complex pure/mixed initializer
cases with coherent, generally noncommuting cutoff projectors. Both the
product d^2 and pinched-SEP d orders pass, as do normalized cutoff tails and
random effect tests. Four maximally entangled fixtures show the two generic
constants are sharp and explicitly reject the wrong product factor d.
Five coherent P/Q fixtures saturate the half-trace sqrt-tail and reject a
tail-probability-only replacement. Twenty-four binary entropy fixtures
check the test algebra, including q>f and f endpoints. Fifteen exact analytic
geometric-Schmidt-family cutoff values illustrate a fixed normal marginal;
they are formula evaluations, not an infinite-dimensional simulation.

All assertions pass. Minimum product-order eigenvalue is
-3.84e-16 and maximum half-trace bound excess is 5.56e-16, consistent with
floating-point residuals. Runtime was about 0.012 seconds. There is no
reflection boundary, physical experiment, or peer code reuse. These finite
tests verify sensitive normalizations and comparisons; they do NOT
numerically distinguish H_b^N from a generic dimension bound, nor prove the
all-N asymptotic theorem. The analytic reconstruction above is load-bearing.

## Primary prior and remaining boundary

[Datta, arXiv:0803.2770v3](https://arxiv.org/pdf/0803.2770v3), Definition 1
and Section V, already treats order-based max-relative entropy and its
separable-reference entanglement version. Its stated setting is finite
dimensional, so it is a generic-method priority comparator, not the sole
justification of the present normal-state limit.

[Shirokov, arXiv:2302.04809v1](https://arxiv.org/pdf/2302.04809v1), Section 2
and Section 3.1 Eq. (22), states normal trace-class relative entropy and
data processing on separable Hilbert spaces, including extended values.
Its logarithms are natural; the review's bit convention divides by ln 2.
Exact retrieved primary PDFs are byte-bound in `sources/PRIMARY_RETRIEVAL.json`.
No new generic entropic measure, pinching inequality, or test method is
claimed. Complete device-specific priority remains UNKNOWN.

This transfer can rule out above-threshold performance from specified
correlation families; it does not prove the smaller all-resource quadratic
WEAK threshold is a strong threshold. Arbitrary varying resources with
extensive E_R and no smooth low-rank tail promise remain outside it. At
beta=0 the separately reviewed all-resource theorem is already stronger.
No apparatus calibration, resource acquisition, precision compiler, runtime,
reset, return, or energy budget is supplied or silently granted as a new
physical construction. The expensive loader is unnecessary for this upper
bound, while its separate constructive content remains intact.

The root-requested review is complete. Per the reduced-team drain instruction,
this worker will finish its checkpoint and idle rather than start another
research or peer-review round. This operational stop is not mission success.
