"""Exact scalar certificate for the fixed-reference factor-two-b source.

This checks rational transfers, not inherited physical operator identities.
It emits no quantum code, source preparation or parameter estimate.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PINS = {
    ROOT / 'w56_fresh_quadratic_capacity_critic/lower_construction/CAUSAL_CLIPPED_LOWER_V4.txt':
        'b37eccacafa054db80a9f28f6903af0015b78f00a83c303048b8586994b6a0a6',
    ROOT / 'w56_fresh_quadratic_capacity_critic/lower_construction/CAUSAL_PREFIX_RESPONSE_V4.txt':
        'f1b3dadbc126b6996d3e86bdbc854c9bd40f143f00efaa905a1e9de6d56348a9',
}


def main():
    verified = []
    for path, digest in PINS.items():
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        assert actual == digest
        verified.append({'path': str(path), 'sha256': actual})
    c = F(103, 360)
    # h(1+t) in the nonnegative degree-two Bernstein basis on [0,1].
    bernstein = [1-c, 1-c+(1-2*c)/2, 2-4*c]
    hmin = min(bernstein)
    assert hmin == F(257, 360)
    gamma = F(4, 25)
    main_inward = gamma*hmin-F(1, 9)
    assert main_inward == F(7, 2250)
    correction = (1+F(1, 1800))*F(1, 100000)*300 + F(12, 1000)/9
    assert correction == F(867, 200000)
    rmax = F(2, 5)
    lupper = rmax/(1-2*rmax*rmax)
    assert lupper == F(10, 17)
    amin = F(8191, 8192)
    margin = amin*main_inward-lupper*correction
    assert margin == F(51677, 92160000)
    assert margin > F(1, 1800)
    kappa = F(1, 300)*F(1, 1800)/2
    assert kappa == F(1, 1080000)
    gain = F(1, 300)/62
    assert gain == F(1, 18600)
    chi = F(257, 10000)*F(1, 200)/4
    assert chi < F(1, 25600)
    # Pointwise checks supplement, but do not replace, the Bernstein proof.
    for j in range(1001):
        x = 1+F(j, 1000)
        assert x-c*x*x >= hmin
    # A scope control: this SAME relaxed main bound is not inward at x=3.
    outside_main = gamma*(3-9*c)-F(1, 9)
    assert outside_main < 0
    rows = []
    for den in [128, 512, 2048]:
        b0 = F(1, den*den)
        k = (den*den)//5
        assert k >= 3276 and b0 <= F(1, 16384)
        assert k*b0 <= F(1, 5)
        assert 2*k*b0 <= rmax
        assert 1-2*b0 >= amin
        rate = gain/(16*k)
        assert rate >= 2*b0/F(119040)
        rows.append({'beta_reference_denominator': den, 'k': k,
                     'b_reference': b0, 'actual_b_upper': 2*b0,
                     'actual_r_upper': 2*k*b0, 'gain': gain,
                     'uniform_drift': kappa, 'chi_upper': F(1, 25600),
                     'final_rate_excess_target': rate,
                     'actual_b_rate_coefficient': F(1, 119040)})
    data = {'status': 'PASS', 'scope': __doc__, 'source_pins': verified,
            'h_bernstein_coefficients': bernstein,
            'h_lower': hmin, 'main_inward_coefficient': main_inward,
            'correction_relative_upper': correction, 'response_norm_upper': lupper,
            'full_drift_coefficient_margin': margin,
            'strict_margin_above_1_over_1800': margin-F(1, 1800),
            'half_source_drift': kappa, 'half_source_entropy_gain': gain,
            'half_source_chi_upper_sharp': chi,
            'outside_x3_main_certificate': outside_main,
            'rows': rows, 'operator_identity_validation': 'INHERITED_NOT_EXECUTED',
            'physical_status': 'NOT_PERFORMED', 'mission': 'NOT_ACHIEVED'}
    payload = json.dumps(data, default=lambda x: str(x) if isinstance(x, F) else x,
                         indent=2)+'\n'
    out = HERE/'FIXED_SOURCE_BAND_EXACT.json'
    if out.exists():
        assert out.read_text() == payload, 'refuse changed frozen output'
    else:
        out.write_text(payload)
    print(json.dumps({'status': data['status'], 'margin': str(margin),
                      'kappa': str(kappa), 'source_pins': len(verified)}))


if __name__ == '__main__':
    main()
