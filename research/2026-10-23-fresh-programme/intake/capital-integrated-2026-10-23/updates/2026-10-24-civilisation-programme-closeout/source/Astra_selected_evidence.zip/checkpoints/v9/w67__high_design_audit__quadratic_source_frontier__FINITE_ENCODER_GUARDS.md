# Finite guards and a sharper window for the mesoblock candidate

W67, 23 October2026. Post-freeze sidecar to candidate26c7092c. Neither
this sidecar nor its scalar producer is independently reviewed yet. It
keeps all old quartic rows and the first candidate bytes unchanged.

## 1. A less expensive window

Write c=1/25600 for the uniform upper bound on
Tr sigma(M_*-I)^2 after half regularization. The exact commuting identities

    E_rho_*^t exp(L)<=(1+c)^t<=exp(ct),
    E_rho_*^t exp(-L)=1

give Pr(L>x)<=exp(ct-x), Pr(L<-x)<=exp(-x). If

    w=ceil(2ct)+1,

retain only bins |j|<=w. Their omitted mass is at most2e exp(-ct): the
larger event |L|>w-1 is sufficient. It is enough to have

    ct>=B0+4                                             (G1)

when d=2^-B0, because e>2 and2e<8. In fact the omitted mass is then
less than d/2. This replaces the first draft's |j|<=t, without changing
any frame/entropy/averaging identity. The number of table cells is now

    B=(kt+1)(2w+1).

Every retained p>=p_min has

    mu>=p_min exp[-(w+1)]/2.

For dyadic p_min=2^-Bp, the exact integer bound

    mu>=2^-Bmu, Bmu=Bp+2w+3                           (G2)

uses only e<4. Query costs involving mu^-1 are charged, never treated as
logarithmic in inverse mu. The reduction of w matters enormously at the
literal constants in this construction; it does not establish usefulness.

## 2. One conservative rational policy

Use lower margins G=1/18600 and Kappa=1/288000. These are supplied by
the V4 source plus half regularization, not numerical observations.
For k>=3276 put

    B0=ceil log2[2^30 k^6/(G Kappa)],
    eps=2^-B0, d=tau=zeta_p=eps.

The constructor doubles t from1 until all of

    ct>=B0+4,
    ceil log2 B+2B0+32<=tG/8,
    eps(4k+1)<=G/16                                  (G3)

hold. This terminates with t=O(log k); the constants depend on G,Kappa,c.
The last guard covers both discarded-mass information loss and the
relative-table distribution change in M13. The entropy inequality gives
E ell>=t(3k/2+3G/4), with spare margin. It must use the ESTIMATED final
cell distribution when invoking Hoeffding.

Choose

    Bp=ceil log2(128B/eps), p_min=2^-Bp,
    Bmu=Bp+2w+3.

Estimate each ideal cell probability within eps p_min/128. Keep a cell
if its estimate is at least8p_min. On the good table event retained
probabilities are >=7p_min and dropped probabilities are <=9p_min.
The dropped cell mass is <=9B p_min<eps/8. Together with(G1), conservative
finite-instrument errors and slightly finer statistical accuracy, the
retained mass is P>=1-eps. All statistical confidence failures are paid
once for the table, not silently repeated per mesoblock.

For each retained cell compute an interval for log2 mu from M4, using
the estimated p and finite exp/log arithmetic. Its width is at most1/4.
Take a rational lower endpoint and select a power-of-two K at least
22 bits below the corresponding tau^2 mu D threshold. Interval rounding
never asks an oracle for the exact floor of a transcendental number.
The conservative bounds are

    K/D<=2^-20 tau^2 mu,
    ell>=log2(D mu)-2B0-24,
    ell>=ell_min=kt-Bp-2(w+1)-2B0-24.                 (G4)

The last bound uses sigma_q<=2^-kt and is uniform over retained cells.
The common frame h may be chosen from the upper width E=2kt and a
per-frame budget eta_f. Check h<=2^ell_min, along with the exact
finite denominator/moment/width guards M8. They are not replaced by a
claim that the source dimension is large.

Each cell table can be estimated by n independent offline source-circuit
experiments. A sufficient symbolic sample bound is

    n>=8*(128/(eps p_min))^2 * ln(2B/eta_table).       (G5)

Source-preparation and bin-instrument errors are reduced below one fourth
of the displayed additive target; constant factors in n can be enlarged
for the statistical split. This is a polynomial QUANTUM preprocessing
cost, not a classical density-matrix computation. The table has B entries
with O(B0+Bp+log B+log(1/eta_table)) output bits per entry. Internal scalar
precision, source copies, log/filter queries and measurement resets are
additional costs, all polynomial at the stated parameters.

Normalize the retained estimates and round on a common dyadic grid with
at least ceil log2[128B/(eps p_min)] fair bits. Allocate residual grid
mass to a retained cell. The resulting EXACT finite fair-bit sampler
can be made to obey the one-sided factor1+zeta_p used in M16. Estimates,
normalization and grid rounding each receive a fixed subbudget of eps;
the literal constant128 may be enlarged without changing G3 or scaling.

## 3. Bounded width selection and the parent ensemble

Take eta_w<=1/4. Require

    s>=128k^2/G^2 * ln(1/eta_w).                     (G6)

For every table satisfying its confidence contract, the width rejection
probability is <=eta_w. Draw at most TWO independent sequences of s cells
and choose the first whose total width permits

    ell_parent=floor[st(3k/2+G/2)].

If neither passes, output an explicit failed-program flag. Probability
of this failure is <=eta_w^2. Conditional on success, the first accepted
sequence has exactly the original cell-sequence law conditioned on the
width event. Therefore M16's factor1/(1-eta_w) applies. There is no
unbounded rejection loop or unbounded seed length. Generate frame seeds
only after width selection, independently of that selection. A safe seed
envelope reserves both attempts and all largest allowed cell widths.

Choose the fixed public prefix z of length sum ell-ell_parent, at most
2kst fair bits. It is a recorded, message-independent part of the code
program. On all good frame events, the parent encoder is a pure,
fixed-width, arbitrary-reference isometry. On bad frames the actual
finite circuit remains total CPTP; its success is not certified.

For eta_f per frame, the total bad-frame probability is at most s eta_f.
The log of the averaged domination constant is bounded by

    ln F<=5eps*s+2eta_w.                             (G7)

This follows from log(1+eps)<=eps and -log(1-eps)<=2eps.
It is a bound on the GOOD-EVENT ensemble, as M16 states. Dividing by a
separate good-frame probability at each mesoblock is unnecessary and
would require an additional term.

## 4. Forward horizon guards for a known parameter

This sidecar first instantiates a known rational b (or an explicitly
supplied sufficiently narrow model promise). It does not import the
quartic source's factor-two band response. The digital receiver may use
the full finite Fourier error span; its physical tail bound is asserted
at this actual b. Both static sectors and preserved sector/reference
coherences remain within the previously reviewed receiver contract.

Use conservative source constants

    t_L=Kappa/(8k^2), C_tail=6/(Kappa*t_L).

The bounded k-call step and full negative drift give the actual-root dual
inequality

    Phi^*e^(t_L Ldepth)
       <=(1-Kappa*t_L/2)e^(t_L Ldepth)
           +e^(2kt_L)P_(Ldepth<k).

The low-depth term is retained. The bulk Taylor remainder is at most
(e/2)t_L^2 k^2, less than Kappa*t_L/2. Total-charge commutation removes
cross-depth blocks. Starting at vacuum, the source body has tail
(1+C_tail)e^(-t_L H). The source is a tensor product of port blocks;
the evolving bath is not iid, measured or reset between them.

Let n_body=kst. Pick an integer R which is a power of two and
R>=16 n_body. Put B_R=log2R. For target error z in(0,1/100] use

    Bq=48+4B_R+4ceil log2(1/z), q=2^-Bq.

Pick a parent tail/Markov failure eta_parent. A sufficient cutoff is

    H=ceil{[5eps*s+2eta_w+ceil log2(1+C_tail)
                         +Bq+ceil log2(1/eta_parent)+4]/t_L}. (G8)

It gives the required GOOD-PROGRAM ensemble parent mean-tail budget.
Use the actual terminal zero flush

    n_flush=16(H+Bq+4).                             (G9)

Since a=1-b>=1/2, its descent failure from depth<=H is less than q by
the binomial lower tail. Check n_flush<=n_body, so T=n_body+n_flush<=
2n_body and the two-sector Fourier row count is below R. The universal
row's physical coefficient norm and cutoff costs are unchanged.

For a supplied initial normal-state tail bound, choose A so
Tr P_(L>A)tau<=q/256, and count an initial zero prefix

    n_initial=16(A+Bq+4).

The original prefix diamond term is charged separately. The illustrative
scalar rows use the supplied geometric bound Tr P_(L>A)tau<=2^-A and
A=Bq+8. This is a tail promise, not a uniform bound over normal states
or a physical acquisition of the initial bath.

The parent width is fixed. Sacrifice Bq logical bits for the outer common
centered-design code, so ell_code=ell_parent-Bq. Retain the exact outer
moment, denominator, row-polar, sign-compiler, native precision and
initializer guards of the reviewed interface. They have polynomial
parameters in the actual total horizon; previous quartic numerical
rows and gate exponents are not reused.

One explicit final RATE guard is

    ell_code >= [3/2+G/(16k)]
                       *(n_initial+n_body+n_flush).  (G10)

For fixed error/confidence, increasing s polynomially achieves G6,G8--G10.
Indeed ln F grows with slope at most5eps, and the slope of n_flush is at
most640eps*k^2/Kappa, whereas the parent has positive s-slope tG/2 beyond
3k/2. The eps choice makes the padding slope much smaller than that
margin. Remaining terms grow only logarithmically in s. Thus s can be
found by exact doubling and all source-to-call overheads are paid.

G10 gives a beta-SQUARED sufficient excess: k<=1/(5b) implies
G/(16k)>=5G b/16=b/59520. The coefficient is deliberately weakened.
This is a **conditional unreviewed implication**, not a reviewed capacity
coefficient, a practical speedup, or a claim that the source was invented
here.

## 5. Native and program resources

For the inner filtered frames the design width E=2kt, order2h,
h=O(kt+log(s/eta)) and diamond-accuracy bits
O[h(E+B0+Bmu)+log(s/eta)] are polynomial. An exact finite Pauli random
circuit of the reviewed step count, plus an exact left Pauli twirl, has
a bounded polynomial fair seed. The native design needs OPERATIONAL
precision after ideal seed selection; the tiny moment error is paid by
the design length, not a free native analog gate.

The bounded filter has a full phase-estimation/coin/uncompute construction.
Its physical scalar domain is O(t log k); its amplitude and instrument
vector are Lipschitz. A phase-estimation length polynomial in that
domain and inverse full-isometry error suffices, including wraparound
and scalar arithmetic. W39's independent interface derivation gives
the safe bound error<=C R_domain/(2sqrt(T_PE)). The A_j coin remains
away from a unit amplitude, so its complementary square root has a
bounded derivative; no new gap promise is needed.

Scalar Lipschitz regularity is used ONLY for the phase-estimation error
on the SAME exact Hermitian L. It is not an operator-Lipschitz theorem for
noncommuting approximations. For an acquired Hermitian Ltilde with
||Ltilde-L||<=delta_L, Duhamel gives
||exp(iu Ltilde)-exp(iuL)||<=|u|delta_L. Forward and inverse QPE simulation
times sum to O(T_PE/R_domain), so choose
delta_L<=xi R_domain/(C T_PE), with the explicit constant of the chosen
QPE circuit. This remains inverse polynomial. For Mtilde_*,M_*>=I/2,
the positive-resolvent logarithm bound is
||log Mtilde_*-log M_*||<=2||Mtilde_*-M_*||. A slightly perturbed floor
can use1/4 and constant4. All simulator/helper/native errors telescope
at the full unitary level. No scalar-to-operator smoothness shortcut is
assumed.

The pre-polar singular gap is >=sqrt[(1-tau)mu_min]. Both inverse-gap
queries and stable phase construction are charged. They are bounded by
a fixed polynomial in k because Bmu=O(log k). The exponent can be large.
All arithmetic, approximate-source operator access, helper controls,
adjoints, native synthesis and reset costs remain polynomial but are NOT
assigned an unrealistically small numeric constant.

For s mesoblocks, one parent encoder costs at most s times its largest
inner filter/design/polar/charge-rank cost plus program arithmetic.
The universal row contains this ENTIRE encoder. The factored row repeats
it Q_outer+1 times, with Q_outer polynomial in n_body,z^-1. Whole-encoder
accuracy is reduced accordingly. Stable signal-phase construction can
cost O(Q_outer^3 polylog) classically; this and the inner constructors,
table sampling, seed generation and actual circuit emission are all
counted separately. There is no inheritance of the old m5 whole-code
native envelope after changing the source encoder.

The code generator is quantum polynomial time with classical output.
If only deterministic classical generation or a self-contained forward
transport of the probability table is allowed, additional work is
required. Public installation here is the same message-independent code
program contract as earlier random codes, with the added quantum table
acquisition charged. It is not a free parameter-estimation channel.

## 6. Exact scope

The companion integer/Fraction producer checks selected sufficient
encoder, tail, physical-rate and outer scalar guards. It does not create
an enormous charge rank, table, design circuit, polar phases or good code
seed. Native costs are symbolic polynomial envelopes with primitive
counts, not a fully instantiated hardware count. The source H is the
actual nonlocal-colour operator. Standard operations are available to an
equally informed baseline. Comparison with exp(k) Schur onset is only a
mathematical representation comparison; crossover or practical advantage
does not follow from the word polynomial.

Fresh criticism and the final integrated full-unitary/native binding are
still required. Mathematical novelty UNKNOWN, physical NOT_PERFORMED,
practical advantage NOT_ESTABLISHED, mission NOT_ACHIEVED.
