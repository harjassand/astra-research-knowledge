# Final checkpoint: reviewed ideal acquisition theorem and instrument limits

24 October 2026. Work is finishing at the user's drain instruction. Every
earlier proof/checkpoint byte is preserved. No civilization-changing
breakthrough, physical acquisition or source-priority result is established.
This checkpoint supersedes status fields in older reports only through
separate review receipts; it does not rewrite those historical reports.

## Strongest reviewed mathematical result

For arbitrary nonadaptive common-node controls with total pathwise nominal
row budget B, full n-output acquisition with independent Gaussian scalar
noise sigma, unlimited computation and arbitrary real precision, worst-case
connectivity error<=delta on every fixed positive forest with weights in
[a,3a] requires, for even n>=4,

    q[pi^2+8a^2B/sigma^2] >= n(1-2delta)^2.             (1)

The unknown input precedes design randomness. Even the common hub/leaf
metadata may be revealed after commitment. The compact positive prior
stays inside the promise without a log n conditioning loss. A full-data
conditional-score bound, an exact comparison-matrix Schur elimination,
hidden-label ridge averaging and a direct Fisher-to-TV path establish(1).
It does not assume non-Gaussian posterior conjugacy or a finite-shift
Fisher-to-KL inequality. General Fisher-score methods are established
prior art; this exact forest theorem's priority remains UNKNOWN.

The matching specialized upper actually ACQUIRES the two unknown hubs
of the hidden-two-star family from one random binary noisy full action.
One fresh action then tests the optional hub edge. At fixed delta, fixed
sufficiently small sigma/a and all sufficiently large n, it uses exactly
q=2,2n acquired scalars,O(n) ideal work and B<=1/2. It decides connectivity,
not full support. Ordinary standard-basis acquisition gives a nonadaptive
O(n) upper at B=1 under the same eventual margins. Thus, allowing B=1
to both protocols, the nonadaptive order is Theta(n) versus adaptive2.

Exact frozen sources are compact lower45421a and two-action upper2220c.
W39's cold full reconstruction is positive; root's earlier compact
reconstruction is explicitly co-informed. `COMPACT_PRIOR_REVIEW_RECEIPT.md`
binds the reports and source hashes. These are internal conditional proof
reviews, not external validation. All scalar-readout and nominal-budget
claims are within the ideal interface; they are not Joules or latency.

The earlier general positive-forest component-nulling upper is broader
in target but spends q,B=O(log^2 n) at fixed sensor noise and has charged
naive arithmetic. Internal root review covers its direct stochastic
certificate proof and original Gaussian-prior lower. At the matched
B=O(log^2 n), the compact lower gives q_nonadaptive=Omega(n/log^2 n).
At B=1, the general-support upper requires sensor noise shrinking as
Theta(a/log n). A fixed-noise/B1 general-support theorem is NOT inferred.
The later expander-code fast-decoder reduction remains separately scoped
and unimplemented; its constants and preprocessing are not hidden.

## Complete finite-port obstruction, independently reviewed

The ideal interface omits finite source/sensor burden. Frozen2e8 instead
specifies actual settled external commands through fixed series resistance
r at every port, so actual currents are

    i=L(I+rL)^-1x,

plus independent graph-independent Gaussian current readout noise. Even
granting the full background, hub labels and weights BEFORE measurements,
all finite adaptive commands and repetitions obeying total row budget B
require B=Omega(n) to test the optional hub edge at fixed r,a,sigma.
The exact bound and known-background sufficiency are in the source and
`FINITE_PORT_REVIEW_RECEIPT.md`. W39's cold reconstruction found no blocker.

That is a conditional passive-model obstruction, not a universal
electronics no-go. Its separate current-/voltage-feedback stress identities
can have graph-dependent noise covariance, correlated measurements,
unbounded loop commands and additional control costs. Raw noise inflation
cannot be used as an information impossibility for all decoders. Thermal
covariance and alternative architectures need their own complete laws.

## Two routed precision channels: positive candidate, not reviewed hardware

Frozen455c changes the instrument explicitly. There are n ordinary ports
r0=1/(128a), at most two low-impedance channels routable to acquired labels,
and selected r1=1/[128a(d+1)]. With shared calibrated rails, fixed Gaussian
full-current readout unchanged by routing/gain, and settled actions, its
written protocol first acquires both hubs using ordinary ports, then
routes the two precision channels and tests the core. For the stated
finite d and error conditions, q=O((1+sigma^2/a^2)log(n/delta)), every
repetition is charged, and every current is encoded with finite ADC bits.

Its all-nonadaptive-routing lower grants arbitrary real commands, post-
commitment complete metadata and selected resistance even smaller than
the positive algorithm needs. For k channels and C=129 it requires

    2kq/n+(aC/sigma)sqrt(nB)/d >=1-2delta.              (2)

At fixed noise/error and allowed B=O(log n), this gives q=Omega(n/k),
compared with the candidate's adaptive O(log n) actions when k=2.
Full mathematical review of455c is PENDING at this checkpoint. Its
producer diagnostics passed 5,547 assertions and 18 causal synthetic
hidden-plant cases, counting4,258 actual synthetic actions and2,565,616
scalars. `TWO_PRECISION_CHANNEL_DIAGNOSTICS.md` gives code/raw hashes.

The two channel COUNT is not constant total hardware resource: selected
impedance scales1/n, driver capacity and peak current scale n, terminal
connections/sensors scale n, and switching, settling, source power,
rail errors and calibration are unresolved. In particular unchanged
independent noise across range/routing is not an acquired observation law.
Neither(2) nor synthetic circuit success demonstrates a useful apparatus.

## Stronger ordinary comparator if terminals may float

One must not remove455c's O(n) loading by granting perfect opening only
to the adaptive algorithm. Frozen `OPEN_TERMINAL_BASELINE.md` gives a
fully nonadaptive ordinary continuity comparator on that changed interface.
Float every unused terminal and connect one precommitted random pair
through fixed ordinary r0. In a connected promised tree the pair path has
at most3 edges, so current is at least Aa/(3+2ar0). In the disconnected
case a random pair crosses equal components with constant probability,
giving exactly zero current. A bounded fair-bit sampler, charged Gaussian
repetitions, finite ADC and clipping bounds give q independent of n at
fixed error/noise. Full scalar acquisition remains nq=O(n), and selected
peak mean current is at most3aA. This is an ordinary baseline, not new art.

Consequently the hidden-star asymptotic action separation disappears in
the ideal-open/free-settling interface. This neither contradicts455c nor
shows that perfect opening is physically affordable. Producer controls
passed2,776 assertions,392 full nodal inversions,348 exact balanced
partitions and12 causal synthetic cases. All30,426 synthetic actions and
13,387,440 scalar readouts were charged; physical acquisitions remain0.

Opening also needs an actual leakage/capacitance/settling law. Off leakage
can accumulate over n terminals; capacitance can create a bulk charging
time growing with n when a selected leaf drives the network through one
edge. The baseline proof explicitly grants zero leakage and full settling.
It establishes no constant physical duration, Joules or reset cost.
W75's separately frozen qualification149fb305 is bound in
`OPEN_TERMINAL_PHYSICAL_QUALIFICATION_RECEIPT.md`. Its exact received-current
leakage contrast decays as d^-2 at fixed per-terminal off-conductance;
constant contrast needs aggregate leakage O(a). Its particular capacitive
reset-zero model has Theta(d) settling, while a fixed-step receiver can
reach constant mean KL earlier at Theta(d^(4/5)) under stipulated white
noise. Neither is an all-schedule time lower. Those are unreviewed
conditional circuit qualifications, not imported physical measurements
or alterations to either frozen interface.

## Source comparison and final statuses

The retained primary comparison reads noisy graph/Laplacian reconstruction,
active distribution-network probing, sparse matrix sketches, query/sketch
connectivity, adaptive matrix sensing, passive grid inference, rigidity
and quantized-network claims. Different topology knowledge, support,
precision, sensing direction, noise, preparation and readout costs are
kept explicit. No exact matched earlier theorem was identified in the
read sources; that is NOT a novelty proof. `PRIMARY_PRIORITY_COMPARISON.md`
and its addendum preserve source versions/hashes and scoped distinctions.
The separate quantizer-transfer audit provides a self-contained global-
error lower in the actual common-voltage geometry; it does not refute the
cited iid sub-Gaussian quantization theorem. Literal source-specific
noiseless-converse diagnostics remain internal and independently scoped.

Mathematics: conditional internal PASS for454+2220 and2e8, with distinct
review provenance. New455c and open119806: producer proofs/diagnostics,
not inherited review. Source/novelty UNKNOWN. Physical validation NONE;
instrument NOT_ACQUIRED. Practical advantage UNKNOWN. Broad mission
NOT_ACHIEVED. No procurement, hardware operation, public disclosure or
third-party communication occurred. Continue only if the user later
authorizes further research; the present worker is draining to idle.
