# Mandatory source-label qualification for the two-queue swap lemma

24 October2026 local /23 OctoberUTC. This qualification controls source transfer of frozen `TWO_QUEUE_SWAP_ENTROPY_LEMMA.md`, SHA256 d9570730d4afe00236c1c9253a7d6de5feab93265cf52af8b70014e341ff978c. Preserve those bytes.

W18's cold review reconstructed the ENTIRE mathematical lemma, including unequal dimensions, but found an incorrect native-source label. The four g values in that lemma describe two choices{0,1} on each uncertain one-site queue in a STRIPPED CORE. The pinned native notation instead has K in{1,...,L}: native L=1 is deterministic and does not give that four-clock mixture. Therefore the original phrase identifying the lemma as the unchanged native r2,L1 model is withdrawn. Its mathematical statement and proof remain valid for the explicitly displayed overlaps.

The actual native two-choice case has K in{1,2}, including an always-live Bell prefix. Terminal local vectors may entangle that prefix with uncertain sites and other queues. Deleting the known prefix does not preserve the product-vector overlap premise, and is NOT justified by this lemma. No actual native two-clock converse, all-r claim, or new native capacity conclusion is proved by this stripped-core result. Transferring it while correctly retaining the known prefix is an OPEN obligation.

The independent review is an internal mathematical pass with this mandatory transfer restriction. Priority UNKNOWN, physical validation NONE, mission NOT_ACHIEVED.
