# Independent frozen-file audit of the uniform weighted Choi-trace converse

23 October 2026, w36. Reviewed w19 `coherent_initializer_invention/FULL_PROOF_V1.md`, SHA256 `1556727069358baa8838813d3364eb2e33869dd32cc6d04df682a4dc868328cc`, fully. W19 froze its independent invention before peer exchange as38951ca5e5ff13929abeaa15f8675bc46d5f6f0ff85a3b3c07d289060d1d2d47. **No blocking defect found at the stated product-bath/whole-laboratory interface.** This is a fresh internal analytic reconstruction, not formal verification, historical priority, external validation or a physical result.

## 1. Normalization and chronology reconstructed directly

Use the unnormalized physical Choi vector on all N input ports. Set sigma=diag(s_o)>0 and Z=(I tensor sigma^(-tensorN/2))J(I tensor sigma^(-tensorN/2)). Since Z is a positive FINITE external-port matrix, Z<=Tr(Z)I. Its trace is

    sum_(i^N,o^N) (product_t s_(o_t)^-1)
       Tr[tau K_(o1i1)^*...K_(oNiN)^*K_(oNiN)...K_(o1i1)]
       =Tr[tau Theta_sigma^N(I)],
    Theta_sigma(X)=sum_io s_o^-1 K_oi^* X K_oi.

The last-time sum is performed first and inserts Theta(I) inside the previous-time pair. This is a nested positive-map iteration, not a product of independently initialized channels. All interference inside each history operator is retained. No factor3^N has been divided out: J before whitening has trace3^N, and the input operator here is the identity, not I/3^N.

If Theta(I)<=hI, positivity proves Theta^N(I)<=h^N I. A normal tau has trace one; boundedness of the memory operator is sufficient. There is no trace of an infinite identity or divergent Kraus sum: each call has finitely many port blocks. Thus Z<=h^N I and J<=h^N I_A tensor sigma^tensorN, equivalently the complete-order channel bound. Coherent normal tau, even a different tau_N at each horizon, requires no special argument or truncation.

## 2. The whole-root identity and scalar optimization check

For a=1-b, b=beta^2, the actual K00=alpha R+i beta I has K00^*K00=aP0+bI because R is self-adjoint. For sigma_p=diag(p,(1-p)/2,(1-p)/2), direct independent summation gives

    Theta_p(I)=r_b(p)I+a[1/p-2/(1-p)]P0,
    r_b(p)=(2-b)/p+(2+2b)/(1-p).

In particular p=1/2 yields(8+2b)I-2aP0. The physical root has not been deleted. For p>=1/3 its correction is nonpositive, so the scalar envelope is r_b(p). Its derivative vanishes at

    p*=sqrt(2-b)/(sqrt(2-b)+sqrt(2+2b)) in[1/3,1/2],
    h_trace=[sqrt(2-b)+sqrt(2+2b)]^2.

This verifies the claimed family optimization. The beta1 identity channel gives sigma=I/3 and h_trace=9, so the logical qutrit dimension is normalized correctly. The beta0 value is8. It is unnecessary to assume that Theta(P0) remains diagonal or to replace coherent U/I interference by probabilities.

This trace profile can be weaker than the older graph profile at intermediate beta. If p=t^2/(t^2+2), x=t+2/t, then

    r_trace(t)-h_graph(t)=(1-b)x(x-2sqrt2)>=0.

The new theorem improves the initializer quantifiers and finite prefactor, not every optimized finite-beta coefficient. The older bound must be retained wherever its narrower contract applies.

## 3. Logical K squared and adaptive closure check

For a block encoder, complete order acts on an arbitrary correlated/mixed encoded physical input with fresh reference I_R/K. Any TP decoder then leaves a comparison state(I_R/K) tensor zeta_B. Its normalized Bell overlap is exactly1/K^2. Both factors of K are present; no isometric-encoder restriction is needed.

At a FIXED horizon N, all causal prefixes J_m must use the SAME chosen initial tau_N. They are not computed using the separately chosen tau_m from the family of different horizons. With this understood, C=h_trace^N is fixed at every prefix, and

    D_m=(C J_R,m-J_m)/(C-1)

is positive by descending causal partial traces and satisfies the deterministic trace recursion with D0=1. This is a normalized physical comb. Closing any fixed legal strategy preserves its convex mixture with the actual comb. The product forward replacer, arbitrary source-independent laboratory preshares and backward-only quantum messages leave R product with all Bob-held registers. Retained measurement outcomes are registers; no branch is normalized. Final Bell comparison is again1/K^2.

Normal finite-horizon infinite laboratory resources are allowed under the same well-defined strategy premise as the earlier comb proof. A finite-port deterministic comparison comb has a physical realization, and normal strategy contraction preserves CPTP normalization directly; finite compression is an alternative. Infinite feedback bandwidth does not create an Alice-to-Bob path. A free forward classical wire, direct bath access or logical data preembedded in resources would change the model.

## 4. Exact scope and additional consequences

The theorem as frozen assumes the bath initially PRODUCT with the ENTIRE laboratory resource and fresh logical source. This allows arbitrary bath coherence and arbitrary laboratory preshares, and then arbitrary correlations dynamically generated by the allowed calls. It does not allow an encoder to own a quantum purifier of the initial bath while pretending that its encoded physical input remains bath-independent.

An immediate further corollary, independently observed by w19 and w36 in parallel after the trace construction, is the same bound for every normal SEPARABLE initial state across E:(all laboratories). Finite product mixtures inherit by initializer linearity, then trace-norm closure handles all normal separable states. The bath marginal, coherence, initial depth and separable labels may vary with N without restriction. This is an explicit corollary, not silently attributed to the frozen product theorem.

Standard relative-entropy binary testing then prices initial bath/laboratory ENTANGLEMENT: E_R(eta)>=d_2(F_e||min(1,C/K^2)) when F_e exceeds the comparison probability, hence E_R>=F_e[2logK-logC]-h2(F_e). Any horizon-dependent resource with E_R=o(N) has F_e->0 above the trace ceiling. These generic entanglement-measure and test tools are established. Large entanglement is necessary, not a construction or proof of a capacity increase. Source independence, no extra forward wire and unconditional success remain essential.

## 5. Evidence and unresolved work

This audit ran NO new numerical channel fixture. The identities and normal-state/comb steps were reconstructed algebraically. Earlier small-horizon CP tests in this campaign were nondiscriminating against generic TP coefficients; they are not imported as evidence of this exponent. W19's own fixtures remain its separately attributed diagnostics, not this audit's implementation.

The inherited beta0 lower theorem is still needed for capacity equality. This upper alone proves the uniform strong converse Fe<=8^N/K^2 for arbitrary normal product initializers, including coherent horizon-dependent families; it does not supply a useful device, preparation, reset, finite-precision compiler or code. Historical priority and external correctness remain UNKNOWN. The full initially entangled bath/laboratory resource regime is not settled by the product-initialized comb theorem or its separable corollary.
