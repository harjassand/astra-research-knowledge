# Query minimality in the explicitly restricted vacuum-phase control class

23 October 2026. New analytic addendum to exact inverse06cf56a3... . This statement was independently derived after the three-call construction. It does NOT belong to the older frozen composite manifest and has no inherited review verdict.

Fix known 0<beta<1, alpha=sqrt(1-beta^2)>0 and a known seed-X sector x. Consider ONLY deterministic unitary sequences

    M_n=D(z_n)V D(z_(n-1))V ... V D(z_0),
    D(z)=diag(z,1,1), |z|=1,

with n forward queries, arbitrary chosen local phases and a common global phase ignored. There are no auxiliary registers, other port-mixing unitaries, postselection, adaptive measurements, resource-dependent encodings or other controls in this restricted comparator. The goal is the FULL sector operator identity M_n=gV*, |g|=1, including the root singleton and every matched pair.

Let lambda=alpha x+i beta and Z=product_(j=0)^n z_j. The pair determinant and root condition give

    (-1)^n Z=-g^2,
    lambda^n Z=g lambda*,
    hence g=(-1)^(n+1)lambda^(-(n+1)).              (M1)

This necessary common phase cannot be chosen independently for the root and pairs.

Zero queries cannot produce V* because the latter has nonzero matched-pair off-diagonal entry alpha. With one query, endpoint vacuum phases leave the pair's colored-to-colored entry equal to i beta. Matching -i beta g forces g=-1. Equation(M1) instead forces g=lambda^-2, so lambda^2=-1. Its imaginary part2alpha x beta is nonzero at every 0<beta<1, impossible. Thus n>=2.

With two queries, write the internal vacuum phase z=z_1. The pair's lower-right entry is a z-b, where a=alpha^2,b=beta^2; endpoints again do not alter it. Equation(M1) gives g=-lambda^-3, so

    az-b=i beta lambda^-3,
    z=4b+i x(beta/alpha)(1-4b).                    (M2)

Here lambda^-3=xalpha(a-3b)-i beta(3a-b). The unit-modulus condition is

    |z|^2=16b^2+(b/a)(1-4b)^2
          =(b+8b^2)/a=1,
    equivalently 8b^2+2b-1=0.                      (M3)

Its only solution in (0,1) is b=1/4. This necessary condition is sufficient: beta=1/2 gives V^3=iI on the ENTIRE native Hilbert space, hence V^2=iV*. No phase controls or known-sector discrimination are needed at that special point. It is a stronger short-query incumbent than the generic three-call construction there.

Consequently the exact restricted-class minimum is two queries at beta=1/2, and three queries for all other 0<beta^2<=1/2, using the existing three-call full-root construction. At beta=0 one native query V=U suffices. For beta^2>1/2, this addendum only proves the lower bound3 and does not determine the minimum; the odd-power upper bound remains sufficient.

This is NOT a minimum against arbitrary local port operations, auxiliary quantum memories, measurement/control strategies, arbitrary supplied bath resources or other equally informed full-model incumbents. It does not establish optimal uploading: the controlling Burgarth--Giovannetti opposite-download uploader does not need a physical inverse at all. Nor is mathematical priority for this restricted algebraic bound established. Fresh criticism remains PENDING; broad mission NOT_ACHIEVED.
