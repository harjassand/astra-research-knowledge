# Global bounded-relative quantum third-moment entropy remainder

23 October 2026, W38. Separate strengthening; earlier frozen proofs unchanged.
Fresh independent criticism required. This does not prove a quantum L3 DPI
or the general amplifier EPnI.

Let tau be faithful and F=F^dagger be any BOUNDED operator with F>=-I and
Tr tau F=0. There is NO requirement ||F||<=1 or small positive likelihood
peaks. Write X=tau^1/2 F tau^1/2, rho=tau+X, and F_+,F_- for the positive
and negative parts. The proposed exact inequalities are

    -Tr tau F_+^3/6 <=D(rho||tau)-Q_tau(X)/2
                                          <=Tr tau F_-^3/2.       (U1)

In particular |D-Q/2|<=Tr tau |F|^3/2. Only the physical positivity
condition limits F_-<=I; positive peaks can be arbitrarily large but finite.
This is an entropy Taylor lemma, not a Gaussian extremizer assertion.

Define K_s=(tau+sI)^-1/2 X(tau+sI)^-1/2 and A_s=[tau/(tau+sI)]^1/2.
The exact double-integrated Hessian identity is

    D(rho||tau)=int_0^infinity Tr[K_s-ln(I+K_s)]ds,
    Q_tau(X)=int_0^infinity Tr K_s^2 ds.                         (U2)

For a scalar k>=0,

    -k^3/3 <=k-ln(1+k)-k^2/2<=0.

For -1<k<=0 the remainder equals sum_(m>=3)|k|^m/m. The positive and
negative spectral parts of K_s can be controlled separately. Since

    -A_s F_- A_s <=K_s<=A_s F_+ A_s,

the min-max principle bounds every positive eigenvalue of (K_s)_+ by
the corresponding eigenvalue of A_s F_+ A_s, and similarly for (K_s)_-.
For every integer m>=2 the positive Araki-Lieb-Thirring inequality thus gives

    int Tr[(K_s)_+^m]ds <=Tr tau F_+^m/(m-1),
    int Tr[(K_s)_-^m]ds <=Tr tau F_-^m/(m-1).                   (U3)

The lower bound U1 follows by integrating the positive-spectrum cubic
remainder and using U3 at m=3. The upper bound follows by summing U3 over
m>=3, using 0<=F_-<=I and sum_(m>=3)1/[m(m-1)]=1/2. The integrated
absolute remainder is finite, so these interchanges are justified. Notice
the different constants 1/6 and 1/2: the negative relative tail can approach
the boundary rho=0, whereas the positive scalar logarithm has a bounded
third-order Taylor remainder on the entire positive half-line.

For infinite dimension, first use a number projection commuting with tau
and a tail symbol. Its relative operator is P_M F P_M plus a scalar tail
mean, bounded uniformly by ||F|| and bounded below by -I. The bounded
strong convergence of P_M F P_M, functional calculus of positive and
negative parts, and the trace-class reference give convergence of both
weighted third moments. The tail contribution vanishes. The BKM block sum
and tail mean converge as in the local quantum proof, and DPI plus joint
lower semicontinuity give the relative-entropy limit. Thus no arbitrary
unbounded logarithm or unsupported L3 contraction is needed.

The ALT step is established prior art; see [Audenaert 2007, Theorem 1 and
Proposition 3](https://arxiv.org/pdf/math/0701129). The retained construction
is its use in this signed resolvent remainder. Priority is UNKNOWN.

The assumption F bounded is explicit. Passing to unbounded positive
relative densities with only a weighted third moment needs an additional
domain approximation argument; no such extension is asserted here.
