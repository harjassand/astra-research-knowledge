# Cold smooth-envelope reconstruction before diagnostics

W39,24 October2026. Exact target cbd968c585a332e49547f9a74b3b1e014ce2b3d36f695dfb7c46c8b327646399,
mandatory detail2c08cb95c0655d623563bf7c21c32fd50897fb3f2130e9ba4ee1c7454e1c4870.
Read these and the producer's underlying radial/quantum proof, fixed-shift,
resource and acquisition-scope sources. No producer diagnostic code/output,
W49 narrower review or peer/root preferred verdict was read. This is a new
full-chain reconstruction, not inherited approval of a power-log subclass.

1. Source assumptions give ell(x)>=c x^-K, |ln ell|=O(ln x),
M(x)>=c x ell(x), and finite ER. They also give a derivative estimate
uniform over ANY shift b=O(ln x), positive or negative:
ell(x+b)=ell(x)+O(ell(x)|b|/x),
M(x+b)=M(x)-b ell(x)+O(ell(x)b^2/x).
For negative b take the interval above x/2 and integrate the log derivative;
its relative ell bound is uniform. This additionally justifies the
moving cutoff P(R>t/(ln t)^2), not only the positive growing shift.

2. The actual heated mixture has positive radial density h_t and its
matching thermal reference q_t. Convexity bounds their classical KL
by ln(t+a)-Eln(t+R)<=ln(1+a/t). Thus Phi=hln(h/q)-h+q is a legitimate
nonnegative global integrand; no infinite entropy subtraction is needed.

3. Taylor-expand k_(R/t) only below fixed delta t and retain the omitted
full mean tail. Truncated second moment is O(t ell(l)); omitted mean
is O(M(l)); large R has density upper bound C R^-2ell(l) after R=tx.
This proves S11 with A=O(M(l)/t)(1+y)^2e^-cy and
B=O(ell(l)/t)(1+y)^-2, c>1/2. Q>=const e^-y. At
Y=l-ln ell(l)+2ln l, local Phi bound integrates to
O(M(l)^2/t^2)+O(ell(l)/(t l^2))=o(ell(l)/t).
This is LOCAL quadratic control; global chi-squared is not invoked.

4. For r>=X=tY, r/t>=ln r uniformly (the difference is increasing there,
and is positive at X). Both h_t and h0 have positive lower bound
c r^-2ell(ln r), with upper bounds1/t and1/(er). Therefore mean-value
error in remote Phi is <=C integral_X^infinity(r/t)|h_t-h0|dr.
Small R<=t/l² costs O(ell(l)/(t l)); medium costs
O(t^-1 l²ell(l)Y e^-cY)=o(ell(l)/t), with its shifted probability
derived from item1. Large R kernel differentiation plus the physical
Potter-type bound S9 yields |h_t-h0|<=C t r^-3ell(ln r) and integrated
cost O(ell(l)/(t l)). This comparison is only remote; h0 can be a
subprobability if there is an atom at R=0.

5. In the unheated density set z=r/R. Its kernel is z e^-z and
argument ell(v-ln z), v=ln r. Taylor to first order and the S2 second
derivative bound give
h0=r^-2[ell(v)-(1-gamma_E)ell'(v)+O(ell(v)/v²)].
Small z<r^-1/2 costs O(ell(v)/r) inside the bracket; large z>sqrt r
is exponentially small, including any bounded source body. Measurable
E contributes only O(ell/v²), so no derivative of E is assumed.

6. Tail integrals are I1=M(x)+(1-gamma_E)ell(x)+O(ell(x)/x),
I0~ell(x)/X and Ilog~x ell(x)/X, x=lnX. Their exact remote entropy
decomposition retains I1/(t+a), ln(t+a)I0, h0lnh0, -I0 and qtail.
The term lI0-2Ilog=-ell(l)/t+o(ell(l)/t). All ln ell, constants,
qtail and denominator corrections are smaller. Since
x-l=lnY=ln l+O(ln l/l), item1 yields
M(x)=M(l)-ell(l)ln l+o(ell(l)), ell(x)=ell(l)+o(ell(l)).
The coefficient (1-gamma_E)-1=-gamma_E is therefore correct. This
proves the complete classical S4, not just its leading M(l)/t term.

7. Coherent preparation of the radial law gives the ACTUAL state
E theta_(t+R), and heterodyne measurement gives h_(t+1). Both reference
laws shift the same way. Normal relative-entropy DPI sandwiches actual
quantum D between classical values at t+1 and t. The displayed main
term changes by O(M(l)/t²), negligible relative to ell(l)/t; derivative
follows from M'=-ell and S2, with M>=c l ell. The little-o scales are
equivalent after that unit shift. Hence the ACTUAL quantum S4 follows.
Finite energy gives finite entropy and the exact identity D=g(t+a)-S.
There is no free temperature/amplitude flag in this argument.

8. Scaling a temperature by c gives principal envelope c ell(x-ln c).
Convolution endpoints at h=r/(ln r)^2 give the sum of the two envelopes
with relative O((ln r)^-2) error. E need only be bounded, not smooth:
bound it separately rather than claim its shift is O(1/r). Endpoint
missing masses and middle convolution are smaller at this required
scale; bounded atoms are included as probability measure contributions.
A fixed added temperature preserves only the total allowed log-squared
error, as the fixed-shift clarification requires.

9. The ACTUAL amplifier of independent thermal mixtures has output
E theta_(sT+W), W=lambda+G R_A+lambda R_B, s=2G-1. Its envelope is
G ell_A(x-lnG)+lambda ell_B(x-ln lambda). Apply S4 at sT. Set
theta=G/s,phi=lambda/s. Each output M term is M_i(l-ln theta_i),
so weighted input minus output has contribution
-theta_i ell_i(l)ln theta_i. The M_i(l), ln l and Euler terms cancel.
Fixed shifts change each envelope by O(ell_i/l), independently for each
source, giving an o((ell_A+ell_B)/T) remainder even if their ratio
oscillates or is unbounded along subsequences.

10. The entropy target F(u,v)=g(Gg^-1(u)+lambda[g^-1(v)+1]) matches
the output thermal baseline exactly. Concavity gives S(H_T rho_i)>=g(T),
so every inverse-entropy input on the Taylor segment lies in[T,T+a_i].
The mandatory Hessian formulas are bounded there; endpoint derivatives
are theta_i+O(T^-1). Defects d_i<=a_i/T make all scalar remainders
O(T^-2)=o((ell_A+ell_B)/T). The positive leading weighted log terms
therefore imply strict eventual S5 for each fixed pair and gain G>1.
No threshold uniform as G->1, over sources or over tail coefficients
has been acquired.

11. Critical ell_q=1/[x(lnx)^q],q>1, is admissible with exact mean
1/(q-1) and no higher moments. More generally the polynomial lower
bound and eventual f>=ell/(2r²) force every ER^(1+eta) to diverge;
conditional thermal Jensen gives the same for photon number after ANY
finite heat. If a finite-mean thermal chi-squared were finite, weighted
Cauchy--Schwarz would force all polynomial photon moments finite, a
contradiction. This reinforces why global quadratic control was not used.

12. Source-first quantifiers matter. An epsilon-scaled critical tail
added to the fixed two-temperature core remains bounded-energy with
common K,r0, but at any fixed finite T its entropy defect tends to the
positive core defect while its proposed tail main term is O(epsilon).
Thus no uniform relative asymptotic threshold follows even from those
common constants. r finite copies have trace distance<=r epsilon m,
so no fixed finite experiment uniformly certifies the positive tail.
This does not produce a negative EPnI gap or disprove a possible uniform
EPnI theorem by another method.

No load-bearing analytic blocker found before diagnostics. Heat genuinely
adds T photons at EACH input; H1 is heterodyne/prepare and H_T is
entanglement breaking for T>=1. Inputs here are already classical
unflagged thermal mixtures. Unheated/general finite-energy EPnI,
operational acquisition, practical threshold and priority remain open.

