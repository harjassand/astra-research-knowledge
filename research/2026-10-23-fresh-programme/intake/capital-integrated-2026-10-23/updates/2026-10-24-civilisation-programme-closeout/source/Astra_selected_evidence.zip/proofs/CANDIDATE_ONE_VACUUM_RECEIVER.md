# One vacuum port and an enforced finite input alphabet

Worker w42, 23 October 2026. Complete written derivation, pending fresh
criticism. This is a changed preparation contract. It uses the established
amplifier entropy-gain bound, compound-source hashing and quantum
postselection. None of those three general results is claimed as new.
No N557/EPnI conjecture, actual-source iid assumption, MI/D budget or
source tomography enters this result.

## OV1. Statement and quantifiers

Fix finite G>1, H=G-1, a fixed integer K>=0, and a rate

    0<r<ln G                                                   (OV1)

in nats per amplifier pair. Put d=K+1 and P_K=sum_(j=0)^K |j><j|.
There exists ONE sequence of receivers depending only on G,K,r, with a
fixed target Bell rank

    M_N=2^floor(Nr/ln2),

and constants c>0 and N_0, such that the following holds uniformly for
every N>=N_0 and EVERY normal initial source state on N A modes, N old B
modes, and an arbitrary inaccessible reference. No temporal consistency
between different N is required; a consistent source is included.

Preparation applies, separately at every site,

    Lambda_K(X)=P_K X P_K+Tr[(I-P_K)X]|0><0|                 (OV2)

to A, and replaces B by fresh vacuum. Both operations are trace preserving.
Their complete old modes, overflow records and environmental extensions
are retained in the residual, not postselected away. The resulting active
inputs have the form

    alpha_(A^N R') tensor |0><0|_(B^N),
    supp(alpha_(A^N)) subset (P_K H)^(tensor N).             (OV3)

Alpha may contain arbitrary coherence within the alphabet, temporal
entanglement and correlations with R'. In particular (OV2) is not a full
photon-number measurement, does not reveal the numbers j<=K, and does not
replace every A input by a known pure state.

Apply the ideal identical N-pair two-mode squeezer, retain both complete
output groups C,D, and use the receiver below. It consists of fixed local
output compression, a fresh random common permutation, and a one-way
LOCC compound hashing channel from D to C. If Omega_N is its COMPLETE
declared output including all original source references and every retained
apparatus/seed/record system, then

    q_N=1-Tr[(Phi_(M_N) tensor I_R)Omega_N]
        <=b_(N,d) exp(-cN),
    b_(N,d)=binom(N+d^2-1,N)<=(N+1)^(d^2-1).               (OV4)

Consequently the half trace distance to the Bell factor tensor the ACTUAL
full residual obeys

    (1/2)||Omega_N-Phi_(M_N) tensor Omega_(N,R)||_1
       <=min{1,2 sqrt[b_(N,d)exp(-cN)]} ->0.                (OV5)

Every branch has the same designated local target dimensions; there is no
acceptance conditioning or success-only rate. A finite initial segment can
output product logical zeros. The asymptotic guaranteed rate is at least r.
For fixed n pairs per use, apply the same per-pair alphabet and regard N
as the total number of pairs; the rate is n r per use.

These statements concern an ideal controlled preparation and receiver.
The full costs and baseline in OV8 remain part of the contract. In
particular K is fixed independently of N. No assertion below extends the
polynomial overhead to an uncontrolled growing alphabet K_N.

## OV2. A direct entropy-gain proof with finite quantities

Let V_G:|j>_A -> U_G|j,0>_(AB) be the quantum-limited amplifier isometry,
and Phi_G=Tr_D V_G(.)V_G^*. Up to phases irrelevant here,

    V_G|j>=sum_(l>=0) sqrt[binom(j+l,l)]
                  H^(l/2) G^(-(j+l+1)/2)|j+l>_C |l>_D.    (OV6)

The image of |j><j| under Phi_G is diagonal. Summing its coefficient at
output occupation m over all j=0,...,m gives

    sum_(j=0)^m binom(m,j) H^(m-j)/G^(m+1)=1/G.

Thus Phi_G(P_K)<=I/G; this bounded operator inequality is all we need.
For any density sigma supported on P_K, apply normal relative-entropy
DPI to the two NORMALIZED states sigma and P_K/d:

    ln d-S(sigma)
       >=D(Phi_G(sigma)||Phi_G(P_K)/d)
       =ln d-S(Phi_G(sigma))
                    -Tr[Phi_G(sigma) ln Phi_G(P_K)].       (OV7)

The last logarithmic expectation is finite: Phi_G(P_K) contains the
strictly positive thermal Phi_G(|0><0|), whose negative log grows only
linearly in number, and Phi_G(sigma) has bounded mean number. Operator
monotonicity of log and Phi_G(P_K)<=I/G therefore imply

    S(Phi_G(sigma))-S(sigma)>=ln G.                        (OV8)

No relative entropy to an unnormalizable identity state was used.
The isometry preserves entropy, so for omega=V_G sigma V_G^*,

    I_c(D>C)_omega:=S(C)_omega-S(CD)_omega>=ln G.            (OV9)

This is the familiar entropy-gain inequality. Holevo1003.5765v1,
Propositions1-2, already proves the general regular-channel bound and
evaluates the amplifier minimum entropy gain as ln G. The finite-P_K
argument above makes the present domain and normalization explicit; it
does not establish a new entropy-gain theorem.

## OV3. Uniform finite output compression with a strict rate margin

For every sigma supported on P_K, both local and total output means obey

    E_C<=G K+H, E_D<=H(K+1),
    E_C+E_D<=E:=(2G-1)K+2H.                               (OV10)

Let Q_L=sum_(j=0)^L |j><j| and use deterministic local vacuum compression
Lambda_L on both C,D, as in (OV2). Define the finite-output channel

    T_(K,L)(sigma)=(Lambda_L tensor Lambda_L)
                                      (V_G sigma V_G^*).

Both local outputs have dimension L+1. The mean energy of every compressed
state is no greater than before compression. For Q=Q_L tensor Q_L the
lost mass f<=E/(L+1), by the union bound for the commuting number cutoffs.
Normalized projection has half trace distance at most sqrt(f). Since the
compression fixes that normalized projected state, channel contraction and
the triangle inequality give the uniform estimate

    (1/2)||omega-T_(K,L)(sigma)||_1<=2sqrt[E/(L+1)].        (OV11)

For epsilon_L=2sqrt[E/(L+1)]<=1/2, the bosonic energy-entropy continuity
bound of Winter1507.07775v6 Lemma15 gives

    |I_c(D>C)_omega-I_c(D>C)_(T(sigma))|<=B_L,
    B_L=2 epsilon_L g(E/epsilon_L)
                +4 epsilon_L g(E/(2epsilon_L))+2 h_2(epsilon_L), (OV12)

where h_2 is the binary entropy in NATS. Using E instead of E_C for the
one-mode term only weakens the bound. Both states in each comparison have
the required respective one-/two-mode mean bounds. The right side tends
to zero as L->infinity at fixed G,K.

Choose a finite L, ONCE for the whole receiver sequence, with

    B_L<(ln G-r)/3.

Then the compact finite-dimensional image family

    X={T_(K,L)(sigma):sigma density on C^d}

has inf_X I_c(D>C)>ln G-(ln G-r)/3>r. The output compressions do not
postselect jointly successful cutoffs and require no backward flags.

## OV4. A single exponentially reliable compound hashing receiver

Use the established finite-dimensional compound-source hashing statement:
for a fixed finite-dimensional bipartite family X, every rate strictly
below inf_(omega in X) I_c(D>C)_omega is attained by a SINGLE D->C LOCC
sequence H_N, uniformly for omega^(tensor N), with Bell infidelity at most
exp(-cN) for some c>0 and sufficiently large N.

The needed exact primary is Boche-Janßen1401.6063v3, Proposition18 and its
proof Eqs(98)-(100), taking the identity instrument. Their fidelity is
squared Uhlmann fidelity, Eq(1), and for a pure Bell target is exactly its
overlap, Eq(2). Their logarithms are base2, so divide coherent-information
rates by ln2 and absorb ln2 into c. The proof explicitly covers arbitrary,
not necessarily finite or countable, generating sets; it uses Proposition10
to get exponential convergence. No unproved extension from a finite net
or merely pointwise state-dependent hashing is assumed here.

Take a strict intermediate rate between r and inf_X I_c. If the theorem's
fixed Bell rank is larger than M_N, deterministic exact maximally-entangled
rank conversion obtains Phi_(M_N) without an added failure. One explicit
conversion from Phi_M to Phi_J, J<=M, is the cyclic-window local POVM

    A_k=(1/sqrt J)sum_(j=0)^(J-1)|j><k+j mod M|, k=0,...,M-1.

Its effects sum to I, every branch probability is 1/M, and the receiver
relabels the corresponding correlated index window. Conditional on k it
gives exactly Phi_J. This is one-way in the same D->C direction. All
POVM outcomes and discarded/syndrome systems are retained as residual.

The resulting compound protocol is trace preserving, has fixed target
rank M_N on every branch, and satisfies

    sup_sigma Tr[(I-Phi_(M_N))H_N(T(sigma)^(tensor N))]
                    <=exp(-cN).                           (OV13)

Existence and a finite-dimensional mathematical construction are supplied
by that coding theorem. No efficient code search, efficient decoder or
realized apparatus is inferred. Only the receiver is fixed; actual inputs
will not be assumed iid in the next step.

## OV5. Why arbitrary temporal entanglement costs only a polynomial

Choose a uniform fresh permutation pi of the N paired outputs, apply it
locally on C and D, then H_N. It can be coordinated by a D->C message;
no reverse communication is needed. Record the seed, but do not use it
again to undo the receiver's symmetrization.

Let F_N be the positive Bell-failure effect pulled back through this
averaged receiver and T_(K,L)^(tensor N) onto the d-dimensional A inputs.
Then 0<=F_N<=I, F_N commutes with every input permutation, and by (OV13)

    Tr(F_N sigma^(tensor N))<=exp(-cN) for every sigma.     (OV14)

For an arbitrary density alpha on (C^d)^(tensor N), put

    alpha_bar=(1/N!)sum_pi U_pi alpha U_pi^*.

Invariance of F_N gives Tr(F_N alpha)=Tr(F_N alpha_bar).
There is a simple positive-operator version of quantum postselection:

    alpha_bar<=b_(N,d) tau_(d,N),
    tau_(d,N)=integral sigma^(tensor N) dmu(sigma),
    b_(N,d)=dim Sym^N(C^d tensor C^d).                     (OV15)

Here mu is induced by Haar-distributed pure states on C^d tensor C^d.
For completeness, take the canonical purification |sqrt(alpha_bar)>>
on A^N R^N, with each R=C^d. Since alpha_bar commutes with all REAL
permutation matrices, this vector is invariant under the simultaneous
paired permutations and lies in Sym^N(A R). Therefore

    |sqrt(alpha_bar)>><<sqrt(alpha_bar)|<=Pi_sym
        =b_(N,d) integral |psi><psi|_(AR)^(tensor N) dpsi.

Taking Tr_(R^N) proves (OV15). The symmetric subspace dimension is
binom(N+d^2-1,N), at most (N+1)^(d^2-1). This is the standard mechanism
of Christandl-Koenig-Renner0809.3019v1, Theorem1/Lemma2; the direct
positive-effect form avoids importing a stronger channel-distance claim.

Multiplying (OV15) by the positive F_N, integrating (OV14), proves

    Tr(F_N alpha)<=b_(N,d)exp(-cN).

This is (OV4) for every arbitrary input alpha, including temporally
entangled inputs. It is NOT an assertion that alpha is an iid mixture.
Only the symmetric positive-effect expectation is compared to the
mathematical de Finetti reference. The polynomial is harmless because
d=K+1 is fixed while the compound error is exponential.

## OV6. The complete quantum residual, normalization and controls

The Bell overlap is a marginal bounded output effect and has the same
value on any complete extension. It therefore applies to every old source
purifier, old B system, overflow environment, local compression residual,
message/seed record, code syndrome and the purification of any readout.
The full extension need not be classical on any of those records.

For P=Phi_M tensor I_R, q=Tr[(I-P)Omega], normalized projection is a
product Phi_M tensor eta_R and is within half trace distance sqrt(q)
of Omega. Contraction to R bounds d(eta_R,Omega_R)<=sqrt(q); a triangle
inequality proves (OV5). This gives the ACTUAL full residual rather than
only a favorable projected residual. No event was divided by a success
probability. It is valid for every dilation of the declared fixed channel.

The fresh permutation must be independent of the committed source and
the base code; its seed is not subsequently used to undo averaging.
All active output pairs are already received and held before it is
chosen. A retained seed or its purification does not damage the marginal
effect calculation, and is included in (OV5). A source allowed to choose
its input after learning the permutation would require a different proof.

The exact model is uniformly stable under a supplied whole declared-
channel diamond/normal cb-trace error xi_N->0, including preparation,
amplifier, compression and receiver, with ideal ancillas as specified.
For the same actual input extension, output half trace distance is at most
xi_N (using half-diamond convention). Comparing both actual residuals
adds at most 2xi_N to (OV5). A finite gatewise hybrid sum can be used
only when it is justified for the whole implemented channel; no uniform
infinite-dimensional amplifier calibration is acquired here.

## OV7. Active output energy and tail costs are bounded after the cap

For arbitrary correlated alpha supported on (P_K)^(tensor N), the active
amplifier outputs have total expected number at most NE, by (OV10).
At equal mode frequency, the expected pump-to-active-system energy change is

    Delta E_pump=2 hbar omega H sum_j(<N_Aj>+1)
                         <=2 hbar omega H N(K+1).          (OV16)

This is mean energy exchange for the ideal unitary, not deterministic
work, a pump implementation, an entropy-free battery or a free phase
reference. Reservoir, interaction/control energy and pump preparation
must still be accounted for under a physical implementation.

There is also a source-uniform exponential active OUTPUT-number tail.
For 0<z<(1/2)ln(G/H), (OV6) and the number-difference selection rule give

    <j|V_G^* exp[z(N_C+N_D)]V_G|j'>
       =delta_(j,j') exp(zj)/(G-H exp(2z))^(j+1).

The diagonal expression increases with j>=0, since the ratio is
exp(z)/(G-H exp(2z))>1. Hence, even with arbitrary input coherence and
temporal entanglement,

    Tr[omega exp(z(N_C,total+N_D,total))]<=B_K(z)^N,
    B_K(z)=exp(zK)/(G-H exp(2z))^(K+1).                    (OV17)

It follows that Pr(N_C,total+N_D,total>=L_tot)
<=exp[-z L_tot+N ln B_K(z)]. This controls active output tails supplied
by the changed cap. It does not bound the energy of discarded old source
modes or the cost of compressing/resetting an arbitrary original source.

## OV8. Acquisition, aid, rates and an equally informed baseline

The uniform theorem does not acquire exact purity or iid by testing. It
replaces those promises with trusted physical preparation: the finite
coherent low-number compression (OV2), a fresh independent vacuum B port,
and calibrated ideal amplifiers. K and G are supplied and enforced. A
source can be arbitrary at the logical level; a finite physical source-
disposal/implementation budget requires its own justified initial-energy
or tail premise. Rejected source energy cannot be erased from accounting
by calling the active alphabet finite.

Both complete active output groups, growing collective memory, local
output vacuum compression, fresh uniform permutation/recording, one-way
classical communication, local nonthermal ancillas, universal code
construction/decoding, gates and all disposal/reset remain resources.
No pre-shared entangled receiver aid is used. Source preparation records
and purifiers are not accessed by the receiver. Preserving them as the
actual residual is an error requirement, not an assumption that their
generation/storage costs vanish. The permutation can use O(N log N)
random and classical bits; the cited compound coding theorem supplies
finite classical rates, not an efficiency certificate for its code search.

Trusted BOTH-input vacuum reset gives the pure two-mode squeezed vacuum
with asymptotic entanglement g(H)>ln G per pair, since
g(H)-ln G=H ln(G/H)>0. It uses simpler known-state concentration. Thus
no yield advantage follows from (OV1). The present route can retain
unknown A coherence within a finite alphabet, but its supplied cap,
output compression and universal collective code may be expensive. No
net energy, apparatus, coherence, source-consumption, runtime or physical
advantage is established. Nor is a net entanglement increment after
subtracting all preexisting source/residual resources established merely
by the Bell target. The prepared ACTIVE A:B marginal is product with a
vacuum B; all old-source resources remain separately counted.

## OV9. Primary comparison and status

- Holevo, [1003.5765v1](https://arxiv.org/pdf/1003.5765v1),
  Propositions1-2: the general entropy-gain lower bound and amplifier
  evaluation are established. The attempted v2 URL returned404; the
  official abstract shows only v1, which is the retained primary.
- Boche-Janßen, [1401.6063v3](https://arxiv.org/pdf/1401.6063v3),
  Proposition18 proof Eqs(98)-(100): a single finite-dimensional compound
  hashing channel, uniform exponential fidelity and identity-instrument
  coherent-information lower rate. Their AVQS results address a related
  source model; arbitrary entangled alpha here is handled explicitly
  through (OV15), rather than inferred from an AVQS label.
- Christandl-Koenig-Renner,
  [0809.3019v1](https://arxiv.org/pdf/0809.3019v1), Theorem1/Lemma2:
  the polynomial finite-dimensional postselection mechanism is prior art.
- Winter, [1507.07775v6](https://arxiv.org/pdf/1507.07775v6), Lemma15:
  fixed-energy bosonic entropy continuity supplies (OV12).
- Gour-Wilde, [1808.06980v3](https://arxiv.org/pdf/1808.06980v3),
  channel merging is an additional close operational comparison under
  examination. No distinction or priority claim is made before its
  precise resource and input quantifiers are checked.

The theorem is an application/composition of established entropy gain,
universal hashing and postselection under an explicitly changed ideal
preparation. Exact historical priority of this particular cap/reset/
receiver interface is UNKNOWN. Fresh mathematical criticism is pending.
No physical device, empirical source certificate, code factory or
mission-level success was acquired.
