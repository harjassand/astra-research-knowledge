# Fresh W26 audit of complete fifteen-leaf exclusion

23 October2026. **PASS for the fixed generic actual law.** No gap was
found in the multiplicity recursion or the exact real two-mass primitive
operations needed by the retained negative certificate. The independent
replay excludes every tree with at most fifteen positive terminal
occurrences. Thus the generic center requires at least sixteen. This
does not exclude larger finite trees or establish nonlamination.

The frozen producer interface is `TWO_MASS_INTERFACE.md`, SHA256
`5d5c092df86e40169d3580a2b17084ebf9c700cebe1cc430046c9b3bd9af332e`.
The geometry source is `two_mass_geometry.py`, SHA256
`9683487f30095d4a15701c277092de99f539853556fb756b9f5f47ab4731acf5`.
The complete constructor, closure verifier and all supplied receipts
also matched W29's exact pinned hashes; all bindings are in our receipt.
Producer code was neither imported nor executed, and its bytes/receipts
were not modified.

## Independent arithmetic and physical input

`quadratic_geometry.py` is a new standard-library implementation, with no
SymPy, solver, producer geometry library or peer imports. It implements
bilinear factorization/intersection, rectangle clipping, reflection,
Cartesian products, projection, rational-interval unions and real
quadratic point operations. `independent.py` re-enumerates every closure
implication using these new primitives; it imports no DP constructor.
The only physical helper imported is our own previously independent
fourteen-leaf replay, whose fixed geometry and exact P1 calculation
have already been reviewed. Its actual gradients are independently
converted back to the integer determinant table and checked entrywise.

The source is the same fixed embedded N9 mesh, thirteen faces and area
units

```
m=(10,10,6,10,2,2,2,2,1,1,2,1,1), total50,
```

with zero boundary values and interior center values

```
(27/14,3/14),(24/7,-11),(-9/10,-18/7),
(-3/7,7/15),(-16/31,-13/29),(-4/27,-9/31).
```

These are thirteen distinct actual P1 gradients, not abstract atoms with
only selected moments. The source embedding, exact areas, mean0 and
all six-hat means/fifteen minor moments are checked. The common scale
of the actual determinant-difference table is88489648800.

The old independently verified complete fourteen-leaf closure remains a
separate dependency, freshly rechecked here. The new proof excludes the
only two multiplicity patterns with fifteen leaves.

## 1. Multiplicity and determinant balance cover arbitrary intermediate states

For an exact positive terminal law on thirteen distinct support matrices,
fifteen terminal occurrences have either one label used three times or
two different labels used twice. Every other label occurs exactly once
with its full original physical mass. Fewer occurrences are covered by
the old lower15 proof or by zero-copy enlargement. No auxiliary positive
terminal matrix is permitted because it would change the requested law.
Every internal matrix is the weighted mean of its descendant leaves,
so arbitrary intermediate matrices add no additional independent variable.

Write `D_il=det(A_i-A_l)` and, for a set S of once-only atoms,

```
a_S=sum_(i<l in S) m_i m_l D_il,
b_(j,S)=sum_(i in S) m_i D_ij.
```

For positive child masses, determinant balance of both children and their
parent is equivalent to a rank-at-most-one difference of the child means.
Every subtree of a legal tree is balanced. The audit uses necessity and
upper-family closure for exclusion; it does not infer a positive tree
from a zero-mass branch with an undefined mean.

## 2. One label used three times

Let H_r(S) be possible total mass tau on r copies of j, with all labels in
S appearing once at their full masses. Their balance is
`a_S+b_(j,S)*tau=0`, regardless of the division among the r copies.
The closed range is0<=tau<=m_j. At an internal node whose children contain
l and r distinguished copies, total masses add. The exact sum of two
closed intervals is their Minkowski sum; intersect with[0,m_j] and with
the parent's affine balance equation. All endpoints stay rational.

For a node with all distinguished copies on one side, the other side is
a once-only subtree from C. Such a step is precisely a once-only spine
transition. For a node with copies on both sides, the two smaller copy
counts are(1,1),(1,2) or(2,1). Therefore the H recurrence includes every
binary topology. H_1(empty)=[0,m_j] is the base; joins of empty masks
also force the conservative H_2/H_3 empty bases.

The fresh checker verifies38,657 spine transitions and55,485 smaller-copy
core joins, and all13 complete triplicate choices exclude total mass m_j
on all twelve other labels. All interval bounds and all real splits are
handled analytically; there is no rational-grid restriction.

## 3. Two distinct labels used twice: exhaustive multiplicity types

Fix j,k with capacities M=m_j,N=m_k. The free individual masses are
t,M-t and s,N-s in the closed rectangle[0,M]x[0,N]. A mixed subtree with
one occurrence of each type has balance

    p_S(t,s)=a_S+b_S*t+c_S*s+d*t*s=0,

where b_S=b_(j,S),c_S=b_(k,S),d=D_jk. The earlier one-copy families P_j/P_k
and full-two-copy families T_j/T_k are restricted to masks excluding both
labels; they retain exactly the required fixed capacities in T.

The two-copy recursion is complete by the following decomposition of an
arbitrary tree's first split that is not a once-only spine:

* Type(1,1) is(1,0)+(0,1). Its two real mass sets are a Cartesian product,
  followed by the bilinear parent balance. Above this first mixed node,
  only once-only side branches can occur until another copy is added.
* Type(2,1) is(2,0)+(0,1) or(1,1)+(1,0). In the latter case the two j
  masses are complementary. Filter the mixed child on that condition,
  project to the remaining k mass and impose the affine full-j parent
  balance. Type(1,2) is symmetric.
* Type(2,2) is(2,0)+(0,2),(2,1)+(0,1),(1,2)+(1,0), or(1,1)+(1,1).
  The last case intersects one mixed set with the reflection of the
  other under(t,s)->(M-t,N-s). Every full parent also needs its fixed
  full-capacity determinant balance.

All other root splits attach a once-only C branch and are explicitly
closed. Masks of unique labels are disjoint at every combination. The
recursion includes every branch order, not just maximal pair peeling.
Copy names may be interchanged, so unordered mixed/mixed child pairs
lose no case. The variable masses are arbitrary real numbers.

## 4. Exact bilinear geometry, including exceptional fibers

A nonconstant rational bilinear polynomial
`a+b*t+c*s+d*t*s` is a linear curve if d=0. If d!=0 and ad=bc, it factors
as `d*(t+c/d)*(s+b/d)` and both the vertical and horizontal lines must be
retained. Otherwise it is irreducible. A zero constant polynomial gives
the whole rectangle; a nonzero constant gives the empty set. Rational
scalar normalization clears denominators, divides the integer gcd and
fixes the sign, identifying equal curves exactly.

An affine-in-each-variable function has its minimum and maximum over
the rectangle at its corners. Since the rectangle is connected, its
zero set meets the rectangle exactly when the corner extrema straddle0.
This is the independent curve clipping test. Algebraic points are clipped
with exact real comparisons.

For two irreducible nonvertical curves, eliminating s gives

```
(a+b*t)*(C+D*t)-(A+B*t)*(c+d*t)=0,
```

a rational polynomial of degree at most two. Every genuine intersection
has a real root of this polynomial. Each root is evaluated exactly; a
nonzero s coefficient determines s and both original equations are
checked. If both s coefficients vanish, a nonzero constant rejects the
fiber. Both constants cannot also vanish for an irreducible nonvertical
curve, since that would supply a vertical factor. If the elimination
polynomial vanishes identically, irreducibility makes the two normalized
curves equal and the common curve is retained. Vertical curves are
handled first by exact substitution, including a shared vertical line.

Thus all isolated coordinates have algebraic degree at most two.
Subsequent intersections only retain a common curve or filter existing
points, so algebraic degree does not grow. Reflection and projection also
do not raise it.

The new quadratic arithmetic represents a real coordinate canonically as

    a+sign*sqrt(p),

where a,p are rational, p is positive and is not a rational square, and
sign is+1 or-1. Rational square factors multiplying a radical are absorbed
into p. A rational-square test uses integer square roots of the numerator
and denominator, without integer factorization. Two nonrational quadratic
values are equal exactly when their rational parts, signed squared
irrational magnitudes and signs agree. This follows from uniqueness of
the trace/rational part in a quadratic field. Products/division within
one quadratic field use exact rational coefficients; field compatibility
is checked by a rational-square ratio. Values in different fields are
compared for equality without subtracting them into a degree-four field.

Signs relative to a rational threshold are decided by the rational part
and one exact comparison of p with its square. There is no floating-point
tolerance, symbolic structural-equality assumption or number-field oracle.
All436 stored irrational mixed points pass this independent handling.
The remaining mixed components are rational points, rational curves or
planes;6,505 components are checked in total.

For projection of an entire curve to s, a root t in[0,M] exists exactly
when

    p_S(0,s)*p_S(M,s)<=0.

Both endpoint factors are affine in s. Their rational roots plus0,N split
the interval into finitely many sign-constant pieces. Exact midpoint and
endpoint tests give the complete closed projection, including an
identically zero endpoint factor, poles of a rational parametrization
and a whole vertical zero fiber. No division by a potentially vanishing
curve coefficient is used in this projection test.

A finite P_j root fixes t by a rational vertical line before projecting;
ALL permits the entire rectangle. Quadratic isolated points project to
their exact quadratic s coordinate. The independent checker deliberately
projects **before** imposing the full-parent affine balance. The producer
first filters the mixed set on that balance as an optimization. These
operations commute because the balance depends only on s; the successful
independent replay validates the optimization's result without sharing
its execution order.

## 5. Exhaustive independent receipt and positive control

The complete replay checks the following counts, matching the frozen
constructor-closure verifier while using a different arithmetic engine:

| Implication | Count |
|---|---:|
| Triplicate once-only spines |38,657|
| Triplicate smaller-copy joins |55,485|
| Mixed Cartesian-product seeds |76,237|
| Mixed once-only spines |91,455|
| Full/partial T+P seeds |20,139|
| Full/partial mixed+single seeds |252,787|
| Full/partial once-only spines |28,422|
| Full two-type core tests |230|
| Full two-type spine tests |8|

All13 triplicate full masks and all78 two-duplicate full masks are absent.
The fixed generic law therefore needs at least sixteen positive terminal
occurrences. Runtime is approximately26.30 seconds; parsing, exact
coefficient height, growing caches, construction and model reasoning are
separate costs. This is an exponential finite-support calculation, not
a scalable general laminate solver or a physical experiment.

`positive_control.py` reconstructs the DIFFERENT retained field with
nodal values

```
(0,-2),(3,0),(-1,2),(0,-1),(-2,3),(-1,1).
```

It replays our original15-occurrence tree, including all14 actual jumps,
root0 and every physical mass, then checks every tree node in its proper
parameter family using the new primitives. It also checks two actual
Cartesian-product/bilinear intersections and the nonempty complementary
mixed/reflected intersection that joins the two pairs. This is a positive
control of the load-bearing geometry, with no peer implementation
imports. It takes approximately0.022 seconds. This positive result does
not transfer to the generic center, and the generic negative result does
not contradict the retained field's sharp fifteen-leaf minimum.

## 6. Scope and qualitative robustness

The finite candidate is internally validated at the **fixed generic
point**. A separate earlier22-leaf tree supplies its actual positive
upper bound; our previous independent physical replay checked that tree
at this same generic center. Thus the point bounds are16<=minimum<=22.
No fifteen-leaf or sixteen-leaf upper is inferred. The existing
radius2^-32 box lower bound remains fifteen, not sixteen.

There is nevertheless some unspecified full12-dimensional neighborhood
with lower bound sixteen. For completeness: if a sequence of nearby
fields had exact trees with at most fifteen leaves, select one fixed
tree shape and fixed terminal labels from the finitely many choices.
Pass to convergent leaf masses in their compact simplex. All node means
are uniformly bounded by the nearby terminal convex hulls. Positive-mass
node means pass continuously to their forced weighted means. Prune every
zero-mass subtree and contract a parent with just one remaining child;
the parent and child limits agree. Every surviving binary jump retains
determinant0 by continuity. This yields a tree with at most fifteen
positive leaves for the center law, contradicting the exclusion.
Distinctness persists sufficiently near the center. This compactness
proof supplies existence of a neighborhood, not a numerical radius or
the whole previously certified box.

The result concerns exact finite physical terminal measures. It excludes
neither higher-order finite trees nor limiting laminates, T4/web repairs
or auxiliary positive terminal atoms in a changed law. It constructs no
global rank-one-convex separating function. Universal m2, Morrey,
historical novelty, external correctness and practical value remain
unestablished. All source and review bytes remain private worker files.
