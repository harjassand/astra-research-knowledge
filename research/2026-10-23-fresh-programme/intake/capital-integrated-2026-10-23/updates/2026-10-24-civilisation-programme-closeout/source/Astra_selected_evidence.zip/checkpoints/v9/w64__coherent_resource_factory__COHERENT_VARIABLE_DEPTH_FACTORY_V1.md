# A deterministic native channel for coherent variable-depth bath upload

23 October 2026, w64. Frozen V1 candidate proof, before fresh criticism and before its new diagnostics. This extends the fixed-length native upload packet; it does not inherit that packet's audit. Mathematical priority UNKNOWN; practical advantage NOT_ESTABLISHED; apparatus validation NOT_PERFORMED; programme mission NOT_ACHIEVED. Historical proofs remain unchanged.

## 1. Scope and exact statement

Use the unchanged pinned native device

    U = [[J,S1,S2],[S1*,0,0],[S2*,0,0]],
    V = alpha U + i beta I,
    alpha=sqrt(1-beta^2),  a=alpha^2,  0<=beta<1.

Here E is the seed qubit tensored with binary Fock space, S_j prepends color j and preserves the seed, and J flips the seed on the empty word and vanishes elsewhere. Thus U=U*=U^-1 on the FULL infinite space. Source: pinned work/astra HEAD e606bfc587c76bdcae8b8fa3ec33e721efa2fbac; Cycle11 COMPLETE_PROOF.txt SHA256 2efdaf74518a1c17aa323913162d25de7337441b6d154733d3fd1026d489fe83. No finite truncation is substituted for the physical device.

Fix a KNOWN seed-X sector x=+1 or -1. Write |r_x> for its empty-word vector. Let F be a locally controllable register encoding all binary words of length at most H, with the same fixed sector x; its dimension is d_H=2^(H+1)-1. The input on F is arbitrary and may be UNKNOWN and entangled with an arbitrary reference/laboratory R. The physical bath starts in |r_x>, independently of FR. A local circuit implementing the explicit stack permutation below and certified finite-precision access to the fixed parameter beta are supplied. A direct physical inverse, controlled physical V, physical bath measurement and direct bath control are NOT supplied.

The goal is the isometry

    S_H: |psi>_F -> |r_x>_F |0^T>_P |psi>_E.       (F1)

The intended input coefficients, INCLUDING COHERENCE BETWEEN DIFFERENT WORD LENGTHS, are transferred into E. For every 0<epsilon<1 there is a deterministic finite protocol with backward QUANTUM return of each physical port whose induced channel is within unhalved diamond norm epsilon of (F1), after allocating epsilon/4 to optional initial-root preparation error. From an exact known root the construction below has error at most 3epsilon/4. The forward count is

    O_beta[(H+ln(1/epsilon)+1)^2 / epsilon],          (F2)

and the same order of backward qutrit returns. This count includes the positive native powers used to synthesize every inverse. It does not include initial reset/sector probing or preparation of the input state on F. Those are separate charged costs in section 8. The protocol itself has no measurement, abort, omitted failure branch, or state-dependent stopping time.

At beta=0 the native inverse is exactly U itself, so only T forward calls and T backward qutrit returns are necessary. At beta=1 the physical device is iI, the bath cannot be changed at all, and this theorem does not apply. For H=0 the known-root state needs no calls. No guarantee uniform in a varying beta_N approaching 1 is claimed.

## 2. An explicit finite LOCAL simulator

In port tensor F, pair the basis states

    |j,w> <-> |0,jw>,   j in {1,2}, |w|<=H-1.

Give |0,empty> the eigenvalue x. Fix each remaining colored state |j,w> with |w|=H. These disjoint swaps, one signed fixed vector and remaining fixed vectors define a finite unitary involution U_H. Its last boundary rule is an arbitrary LOCAL completion; it is never installed on the physical bath.

Define V_H=alpha U_H+i beta I. A fresh VACUUM input port on a bath supported at depth<=H has exactly the same native action under V_H as under V. Its bath depth cannot increase. Therefore every step in a sequence of fresh vacuum ports agrees EXACTLY with the full physical V for all such inputs, including coherent/reference-entangled inputs. The colored boundary completion is never reached as the input of one of these local download steps.

U_H has a succinct reversible circuit. Encode a word by an H-bit array and an O(log(H+1))-bit length register. Reversible tests decide root, valid push/pop and colored boundary. Controlled reversible shifts, length arithmetic and color exchange realize the swaps; root x=-1 adds a conditional sign. Padding/invalid encodings receive a fixed reversible completion. This uses O(H) storage and a polynomial number of elementary reversible gates per U_H; a straightforward implementation uses O(H polylog(H+1)) gates. This claim is an explicit logical-circuit construction, not a compiled laboratory gate count.

V_H is also locally compilable, rather than an oracle for a dense d_H matrix. With theta=arcsin(beta), U_H's +/- eigenspaces have eigenphases exp(i theta) and exp(i(pi-theta)). A Hadamard, controlled-U_H, Hadamard extracts this eigenvalue coherently into one ancilla bit. Apply the corresponding known phases and uncompute the eigenvalue bit with a second controlled-U_H. Controlled LOCAL U_H is just control of a known compiled permutation. This does not require controlling the unknown physical operation. With local approximation error eta per V_H, T steps have operator error at most T eta.

## 3. Coherent vacuum download has a dimension-free root bound

Let P=P1...PT be T qutrit registers, initially all vacuum, and define

    W_X = V_(P_T X) ... V_(P_1 X),
    D_X |psi> = W_X(|0^T>_P |psi>_X),

for X=E, and the corresponding local W_F made of V_H. The local and physical D agree on depth<=H, by section 2. Do not measure or discard the download ports.

Tracing a fresh output port produces the vacuum bath channel with Kraus operators

    K0 = alpha J + i beta I,
    Kj = alpha S_j*,  j=1,2.

On a positive depth, a colored emission removes exactly one letter with total probability a; a vacuum output leaves that depth unchanged with probability b=beta^2. At root in sector x the output is vacuum and the bath remains root, with phase alpha x+i beta of modulus one. The Heisenberg image of every depth-diagonal effect is depth diagonal; in particular the root-arrival probability has no hidden dependence on input coherences. Hence, on a depth-h word,

    Pr(nonroot after T) = Pr[Bin(T,a)<h].            (F3)

The same formula weighted by the input depth probabilities holds for every mixed/coherent/reference-entangled input. Define

    tau = Pr[Bin(T,a)<H],
    A = (<r_x|_X tensor I_P) D_X.

Identifying F with the physical depth<=H word subspace,

    (1-tau) I_F <= A* A <= I_F.                     (F4)

In fact A*A is diagonal in the word basis with eigenvalue Pr[Bin(T,a)>=|w|]. Equation (F4), not merely a basis-average success bound, is what makes the eventual channel uniform over unknown entangled inputs. For aT>=2H, the elementary lower-tail Chernoff bound gives

    tau <= exp(-aT/8).                              (F5)

No Hilbert-space-dimension factor appears. The local state can have an exponentially large number of word amplitudes, while the promised depth bound is H.

## 4. The deterministic coherent transfer and its overlap identity

For the moment write W_E* as a mathematical inverse; section 5 physically acquires it. The circuit is:

1. Alice applies W_F to her unknown F input and the fresh vacuum P registers.
2. With the actual physical E at r_x, apply W_E* to the SAME P registers and E; F is retained coherently and is never projected onto root.

Call the resulting isometry from F to FPE, J_H. Its target is S_H in (F1). The exact identity is

    S_H* J_H = A* A.                                (F6)

To check factors and order, test arbitrary bra phi and ket psi on F. Move W_E across the bra. The overlap becomes that of D_E phi times the F root with D_F psi times the E root. Projecting E onto r_x in the first vector and F onto r_x in the second gives precisely <A phi|A psi>. This proves (F6) without assuming that a noisy download is exactly a factorized port encoding and without normalizing any state-dependent successful amplitude.

Both J_H and S_H are isometries. Therefore

    ||J_H-S_H||^2
      = ||2I-S_H*J_H-J_H*S_H||
      = 2||I-A*A|| <= 2tau.                         (F7)

Tensoring an arbitrary reference does not change this operator bound. The full output channels, INCLUDING F and P, obey

    ||channel(J_H)-channel(S_H)||_diamond
       <= 2sqrt(2tau).                              (F8)

Every branch is present because there is no measurement at all. In particular no nonlinear map psi -> A psi/||A psi|| is treated as a deterministic encoder. Tracing junk registers can only reduce the error. Formula (F8) is a complete-input channel claim, not just fidelity for a known target vector.

## 5. Acquire each physical inverse using ONLY forward native calls

The full physical U is an involution, so with spectral projectors P_+,P_-,

    V = exp(i theta)P_+ - exp(-i theta)P_-,
    V^(2q)=exp(2iq theta)P_+ + exp(-2iq theta)P_-.

For every delta>0, the pigeonhole/Dirichlet argument applied to theta/pi gives a positive integer q<=L with dist(q theta,pi Z)<=pi/(L+1). Thus

    ||V^(2q)-I|| <= 2pi/(L+1),
    ||V^(2q-1)-V*|| <= 2pi/(L+1).                  (F9)

Take an integer L>=2pi/delta, or use the slack construction below. Implement V^(2q-1) by sending the SAME current qutrit through the native device 2q-1 times and returning it coherently from Bob to Alice after EVERY call. E remains the same inaccessible physical bath throughout. No intermediate flag is measured. This acts on all port/bath/reference states and is not a projection onto a convenient finite orbit. Time homogeneity and access to quantum backward returns are essential supplied permissions.

W_E* equals V_(P_1 E)* ... V_(P_T E)*. Execute these factors in reverse chronological port order T,T-1,...,1; each approximate factor is the positive power above. Telescope products of unitaries:

    ||Wtilde_E*-W_E*|| <= T delta.                  (F10)

The physical forward and backward counts are both exactly T(2q-1). Retaining/returning every final qutrit is included in this bound. No earlier upload abort-return convention enters.

Finite-precision selection is charged rather than assuming an exact-real search. For example take L=ceil(8pi/delta). A suitable q exists with true phase residual at most delta/4. Supply a certified theta interval of radius delta/(16L), scan q=1,...,L and accept a computed residual at most delta/2. Interval error at q<=L is at most delta/8, so at least one q is found and every accepted q has residual <delta. This requires O(log(L/delta)) parameter bits, O(L) high-precision scalar search operations, and certified elementary-function evaluation. Near beta=1, converting beta precision to theta precision costs the additional 1/alpha conditioning. Unknown uncalibrated beta is outside the theorem. The integer repetition count is known before the quantum input arrives.

## 6. Explicit finite error/cost allocation

For H>=1 and 0<epsilon<1 choose

    T = ceil(max(2H/a, (8/a) ln(128/epsilon^2))),
    delta = epsilon/(8T),
    local total operator error e_loc <= epsilon/8.

Then tau<=epsilon^2/128, and the full unhalved diamond error from an EXACT root is bounded by

    2sqrt(2tau) + 2Tdelta + 2e_loc <= 3epsilon/4.   (F11)

Preparing the actual initial physical root within trace distance epsilon/4 adds at most epsilon/4, by contractivity, giving total epsilon. The local gate allocation can be eta<=epsilon/(8T) per V_H. In addition to the physical count (F2), there are T local stack-simulation steps, O(H+T) stored local qubits/qutrits up to logarithmic encoding factors, and O[T H polylog(H+1)] reversible logical gates before phase-synthesis overhead. A particular fault-tolerant gate set, phase-synthesis cost, memory noise, coherent return error, energy, speed and error-correction budget remain additional charged resources, not demonstrated affordable hardware.

An adversarial implementation-error bound can be stated explicitly: if each ACTUAL physical forward call is within diamond error kappa of ideal V and each backward return within error kappa_back, the added protocol error is at most T(2q-1)(kappa+kappa_back). Thus this polynomial construction does not get constant physical precision for free. Local phase compilation and parameter approximation enter separately as stated above.

This is a sufficient polynomial upper bound. Special rational angles may give an exact short inverse, and Diophantine search often does better. No worst-case improvement from those favorable angles is claimed.

## 7. Why variable length and unknown inputs are actually covered

There is no measured length register. The local download processes the entire superposition with vacuum carriers coherently. Equation (F6) holds as an OPERATOR on the whole d_H-dimensional input space. The physical inverse is approximated in operator norm on the FULL physical Hilbert space. Consequently the proof covers off-diagonal operators |w><v| with |w|!=|v| and unknown F entangled with Bob or an external reference.

This avoids the failure of a naive controlled fixed-length repeat-until-success loader: recording when a push succeeds, or conditionally stopping different length branches, can leak the length into classical records. It also avoids treating polar-decomposition matrix compilation as a free dense d_H-unitary. The local stack simulator is succinct and F remains coherent as temporary junk.

The factory does not restore a pre-existing unknown bath state; it starts from a known physical root and replaces it with the encoded input. It does not preserve the cross-sector coherence of an arbitrary unknown initial seed with an external purifier. Those objectives are distinct from producing the operational lab/bath resource in a known conserved sector.

## 8. Resource composition and initialization boundaries

A supplied known finite LOCAL preparation circuit can create an arbitrary target on F,L_A,L_B. The factory then transfers F into E and preserves its entanglement with both laboratory parts. If Bob's part initially sits at Alice, it must be distributed through the native forward device, not supplied for free. The separately frozen native adaptive transfer primitive in ../retry_upload/NATIVE_UPLOAD_AND_ADAPTIVE_TRANSFER_V1.md, with its mandatory QUANTUM_RETURN_COUNT_CORRECTION.md, provides such distribution with classical flag feedback; its stopped successful branches restore the WHOLE old bath exactly. Its conservative per-qubit capped cost is O_beta[m log((m+1)/epsilon)] forward calls. A separately provable shared pop budget improves this, but that refinement is not needed for (F2).

Acquiring a known physical root from an arbitrary fixed independent NORMAL initializer uses the corrected ../fixed_resource_loader/ packet. Vacuum reset is pointwise in that initializer: it has no uniform bound over arbitrarily deep horizon-dependent tails. Its seed-X probe is finite-cost only at a fixed 0<beta<1 and uses the corrected sign observable from PROBE_SIGN_CORRECTION.md (the actual correction is SHA256 38995aa235770beb5dc3c0384542af03ec4bd37ef3c0df9b4f82650ee8e9f7b6; see that packet's file manifest for the exact filename). Any reset/probe error and every probe/recovery call are added to (F11) and the total cost. If the desired sector differs, the already audited local-program conjugation/word-parity equivalence gives an operational body-channel comparison; it does not implement a physical antiunitary, choose the conserved sector, or restore a discarded purifier.

Even with a polynomial bath-interface factory, producing a completely arbitrary specified state on H word-qubits can require an exponentially long local preparation circuit. The present theorem transfers an ALREADY HELD unknown F state or a target prepared by an explicitly counted local circuit. It does not acquire a classical description of an opaque unknown target, efficient general state preparation, a quantum source, an error-corrected apparatus, or scientific representations from observations.

Preparation has a bounded number of calls; the deterministic factory itself has an exact fixed count. Earlier distribution/reset/probe stages can be capped and retain failures. Filling spare calls with dummy inputs can disturb the final bath, so no exact-N whole-resource-return corollary is asserted. The intended application is resource preparation followed by a body that finally traces E, with its original backward-wire permissions retained.

## 9. Incumbents, evidence and open obligations

The general reverse-download/upload-control idea is PRIOR: Burgarth and Giovannetti, Full control by locally induced relaxation, Phys. Rev. Lett. 99,100501 (2007), https://arxiv.org/html/0704.3027. Its Protocol and Uploading sections explicitly distinguish a mathematical W* using reverse evolution from a legal physical uploader. This candidate resolves that implementation obligation for THIS native involution device using counted positive powers, and replaces a dense recovered port-unitary by an explicit local simulated download. No priority claim for reverse relaxation or arbitrary unknown state upload is made.

Within our earlier exact native interfaces, the known-target all-vacuum variable-length loader had success lower bound a^H and exponential retry cost; fixed-length unknown-qubit upload already had polynomial cost. The relevant new scope to test here is arbitrary unknown VARIABLE-LENGTH coherence with a fully charged physical inverse, and a polynomial local simulator. This is an interface/cost improvement over that earlier loader construction, not an established advantage over all equally informed quantum-control incumbents. A strong matched control literature comparison, fresh independent proof audit, and new native finite diagnostics remain PENDING at freeze time.

Decisive falsifiers: a failure of (F6) on an input cross-depth coherence; any mismatch of the local and physical coherent VACUUM download; an uncharged physical inverse or controlled V; nonuniform operator error hidden as a basis-average bound; an erroneous Dirichlet/factor-order constant; or claiming unknown-root/external-purifier return without its separate proof. Positive-beta fresh-message capacity improvement, autonomous scientific learning, strong-converse novelty and the broad mission remain open.
