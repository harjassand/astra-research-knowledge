# Independent reconstruction of the two communication cuts

Audit target: the fixed root-retaining recurrent-tree device and the exact
resource contract in SOURCES.json. No preferred verdict is assumed. The root
draft was read for the model before this full reconstruction; this is an
independent mathematical audit, not a blinded test. The w19 proof was read only
after the core reconstruction below.

## 1. Exact source operator, including the root

Use E=C^2_seed tensor l2(binary words), with S_j prepending color j. Write
J for the root seed flip, to distinguish it from the fresh logical reference
R. The source relations are

    S_i^* S_j=delta_ij I,   S_1 S_1^*+S_2 S_2^*=I-P0,
    J=J^*, J^2=P0, J S_j=0, S_j^* J=0.

In incoming/output port order0,1,2,

    U = [[J,S1,S2],[S1*,0,0],[S2*,0,0]],
    q = diag(0,1,1).

These relations give U=U^* and U^2=I, without removing any root term. Direct
block multiplication gives

    U^*(q tensor I)U = diag(I-P0,0,0)
                    = |0><0| tensor(I-P0).

Consequently q+U^*qU=I-|0><0| tensor P0 <=I. For any joint normal state on
port, memory, laboratories and purifiers, its actual input/output colored
probabilities obey u+v<=1. Entanglement and coherent off-diagonal terms do not
alter this bounded-operator identity.

## 2. The two fixed partitions respect the same causal order

For each N, initialize Phi_(R M) tensor eta_(E L_A L_B G), with finite
dim(R)=dim(M)=K. Alice owns M,L_A; Bob owns L_B. Eta is any normal state,
possibly N-dependent, of unbounded depth/entropy and arbitrarily entangled
across E and both laboratories. G may be inaccessible. No part of eta has
initial information about the fresh R. All branches are retained.

Only N chronologically labeled qutrit calls carry information forward. Local
normal operations and Bob-to-Alice quantum/classical transmissions are free.
There is no other forward classical/quantum carrier, bath access, timing
signal, conditional acceptance channel or postselected normalization.

First assign E and G permanently to the Bob side of a mathematical cut. At
call t, transfer A_t from Alice into the receiver side C; the device unitary
then acts on A_t,E within C. The increase of reference mutual information is

    I(R:C A_t)-I(R:C)=I(R:A_t|C)<=2 S(A_t).

Receiver operations obey data processing. A backward message leaves C, hence
only traces a factor out of the receiver and cannot increase I(R:C). Sender
trace-preserving operations leave the R,C marginal unchanged, even when
sender and receiver initially share entanglement. Final actual Bob registers
are obtained by tracing out E,G from C, so

    I(R:Bob_final)<=2 sum_t S(A_t).                         (1)

For the second, separately fixed cut, assign E,G permanently to Alice's side.
The device acts on her side and then B_t crosses into Bob's side. Incoming
A_t does not cross this partition. The only forward transfers across this
cut are B_t. Backward messages again leave Bob, while Alice/device operations
are local to the other side. Initial I(R:Bob)=0, and therefore

    I(R:Bob_final)<=2 sum_t S(B_t).                         (2)

The two proofs do not move E between sides during one protocol. They analyze
the SAME physical protocol under two distinct, fixed mathematical partitions.
Giving the formal owner of E more local access than physically available is
a valid enlargement for an upper bound. Neither proof assumes initial E:labs
or Alice:Bob separability.

## 3. Infinite normal resources do not create entropy differences infinity-infinity

Define I(R:C) by relative entropy, not by S(R)+S(C)-S(RC). It is finite and
bounded by2 log K because R is finite. For a finite qutrit A, generalized
conditional entropy can be written S(A|C)=S(A)-I(A:C). It lies between
-S(A) and S(A), even for arbitrary normal C of infinite entropy. Thus

    I(R:A|C)=S(A|C)-S(A|RC)<=2 S(A).

The finite-system chain rule and bound apply directly; a physical finite-depth
or energy cutoff is not required. Primary support: Kuznetsova2010, definition
(2), bound(5), and Shirokov2017, section3, equations(12)-(17). These are
standard extended-information facts, not discoveries of this audit.

Any finite-block causal strategy consisting of normal maps is covered
directly. If the admitted strategy class includes limits of countably many
local/backward rounds between the N calls, require that those rounds define
a normal limiting operation/output. Finite-round approximants retain the
same cut inequalities. Trace-norm convergence, lower semicontinuity of MI and
continuity of finite-qutrit entropies transfer the inequalities to the limit.
An undefined nonconvergent process is not an operational code. The draft's
normal-strategy extension can be made explicit this way; no fatal gap occurs.

## 4. The port entropy sum

For a qutrit state with colored probability u, the maximal possible entropy is

    f(u)=h2(u)+u.

One proof is D(rho ||diag(1-u,u/2,u/2))>=0. It applies to the actual coherent
marginal; no physical pinching is supplied to the protocol. The function f is concave,
and f'(u)=log2(2(1-u)/u), so f increases up to u=2/3.

At beta0, u+v<=1 and hence

    S(A_t)+S(B_t)<=f(u)+f(v)<=2 f((u+v)/2)<=3.

Combining(1),(2),

    I(R:Bob_final)<=2 min(sum S(A_t),sum S(B_t))
                 <=sum_t[S(A_t)+S(B_t)]<=3N.              (3)

The entropy sum bound is locally sharp: take an input qutrit with marginal
diag(1/2,1/4,1/4) and a bath equally mixed over the two one-color words at
a fixed seed. Its output qutrit has the same marginal. This only witnesses
sharpness of the per-call entropy inequality, not a communication code.

## 5. Direct finite-error converse

Let a trace-preserving decoder output a fixed K-dimensional L and let
F=<Phi_K|omega_(R L)|Phi_K> be the unconditional Bell overlap. The reference
marginal remains I/K. Under the comparison state (I/K) tensor omega_L, the
Bell-test outcome probability is exactly1/K^2. Relative-entropy data processing
by that binary test gives

    I(R:L)>=d_bin(F||K^-2)
           =2F log2 K-h2(F)-(1-F)log2(1-K^-2)
           >=2F log2 K-h2(F).

Tracing/decoding Bob's full register cannot increase MI. Thus, for K>=2,

    2F log2 K-h2(F)<=3N.                                  (4)

K=1 is trivial. This avoids a continuity estimate that could depend on the
growing logical dimension. In particular,

    log2 K/N <= [3/2+h2(F)/(2N)]/F

when F>0. Reliable F_N->1 implies limsup(log2 K_N)/N<=3/2, uniformly over
the permitted N-dependent initial resources and causal strategies.
For a full-qutrit K_N=3^N code, only limsup F_N<=3/(2 log2 3)<1 follows.
The proof does NOT imply F_N->0, an exponential strong converse, CP domination,
or a bath-return requirement.

## 6. All-beta spectral calculation

Let b=beta^2, a=1-b and V=sqrt(a)U+i beta I,0<=beta<=1. The Hilbert space
decomposes exactly into paired subspaces {|0,S_j x>,|j,x>} plus the two root
seed states. With the pair ordered vacuum then colored,

    q+V^*qV = [[a, i sqrt(ab)],[-i sqrt(ab),1+b]].

Its trace is2 and determinant a, so its eigenvalues are1-beta and1+beta.
On the root seed block both q and V^*qV vanish, despite the seed flip.
Therefore u+v<=1+beta for every joint state. For0<=beta<=1/3,

    S(A_t)+S(B_t)<=2 f((1+beta)/2).

For larger beta, use2 log2 3. Define

    C(beta)=f(min((1+beta)/2,2/3)).

The same two cuts and Bell test give

    2F log2 K-h2(F)<=2N C(beta),
    Q_reliable<=C(beta).

Near zero, C(beta)=3/2+beta/2-beta^2/(2 ln2)+O(beta^4). This is weaker than
the separate quadratic small-beta bound under product/separable initializer
premises. It supplies no correlation-assisted code or physical preparation.

## 7. Essential boundary conditions and verdict

No fatal gap was found in the upper-bound argument under the explicit contract.
Fresh R independence is essential: a Bell pair already shared by R and Bob
would give F=1 with N=0, but violates the fresh-input premise. Free forward
classical communication plus preexisting laboratory Bell pairs would allow
teleportation with N=0, so that wire is also excluded. Unlimited initial
entanglement cannot be counted as newly generated entanglement; the audited
task is transmission of a fresh logical reference.

The upper bound is uniform over arbitrary normal initializer families. Equality
at3/2 for the supremum over resources needs an imported achievable product-
initializer code. That lower is outside this audit; a uniform lower for every
adversarial N-dependent initializer does not follow. Historical novelty,
external/formal proof validation, physical validation and practical value are
separate and remain UNKNOWN/NOT_PERFORMED.

Primary information-theory sources:

- https://arxiv.org/pdf/1004.4519
- https://arxiv.org/html/1512.09047v7

Finite checks are recorded separately and are not the proof of this universal
claim. The earlier scientific-learning packet remains frozen and unchanged.
