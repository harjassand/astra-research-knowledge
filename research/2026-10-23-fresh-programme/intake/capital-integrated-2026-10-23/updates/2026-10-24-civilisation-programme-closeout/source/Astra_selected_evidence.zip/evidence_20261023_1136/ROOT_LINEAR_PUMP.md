# Direct concentration with a linear shared-pump inventory

Root independent derivation, 23 October 2026. **Unreviewed mathematical candidate.** This follows W42's frozen shared collective trilinear chain, but does not compare its full optical state to the ideal undepleted amplifier. It proposes a direct bound on the pair number needed by the existing sector receiver. Generic SU(1,1) dynamics and mean-field ideas are prior; exact priority and the assembled receiver consequence remain UNKNOWN.

## Exact chain and closed observables

Fix N>=1 native mode pairs and a source total photon number m>=0. Put S=N+m, and prepare the ONE SHARED pump in the number state L. In each native source basis label j, the standard collective trilinear interaction stays in the exact ladder basis |ell;j>,0<=ell<=L, whose raising operator A has entries

    A|ell> = sqrt[(L-ell)(ell+1)(S+ell)] |ell+1>.

The label j is unaffected by the scalar ladder coefficients. In dimensionless time tau=chi sqrt(L) t, the self-adjoint Hamiltonian is

    H=i(A-A*)/sqrt(L).

Let lambda=L/N, s=S/N, and define two bounded self-adjoint observables on this finite ladder:

    Y=ell/N,    X=(A+A*)/(N sqrt(L)).

Their EXACT Heisenberg equations are

    Y'=X,
    X'=p(Y)+2Y/(lambda N),
    p(y)=2s+4(1-s/lambda)y-6y^2/lambda.                (P1)

Indeed A*A-AA* is diagonal and equals

    LS+(2L-2S+1)ell-3ell^2.

This identity holds at both endpoints as well, using the zero missing ladder coefficient. No pump phase, coherent-state replacement, number readout or factorization of quantum moments is used.

## A state-dependent error bound requiring no classical pump phase

Let y,x solve the scalar ODE

    y'=x, x'=p(y), y(0)=x(0)=0.                       (P2)

Assume lambda>=4s. Before the first upper turning point, the first integral is

    x^2=4y(s+y)(1-y/lambda).

Equivalently y=s sinh^2(r) and r'=sqrt[1-s sinh^2(r)/lambda]. The first upper turning time is at least asinh sqrt(lambda/s)>=asinh 2>1. Thus 0<=y(tau)<=lambda and x(tau)>=0 for 0<=tau<=1.

On this interval |p'(z)|<=9 for z in [0,lambda], because s/lambda<=1/4. In the INITIAL ladder state |ell=0>, define

    E(tau)=< (Y(tau)-y(tau)I)^2+(X(tau)-x(tau)I)^2 >.

The initial value is EXACTLY E(0)=s/N: Y|0>=0 and ||X|0>||^2=S/N^2. Differentiate the two squares using (P1). The first anticommutator contributes at most E. The polynomial difference contributes at most 9E by state Cauchy--Schwarz and

    ||[p(Y)-p(y)]psi||<=9 ||(Y-y)psi||.

The finite-N term contributes at most 4 sqrt(E)/N<=E+4/N^2, since 0<=Y<=lambda I. Noncommutativity of X and Y causes no omitted term: derivatives of squares are the anticommutators just bounded. Therefore

    E'<=11E+4/N^2,
    E(tau)<=exp(12tau)[s/N+4tau/N^2].                 (P3)

The deliberately looser final expression also covers tau=0. This is a norm/variance estimate on the exact finite quantum dynamics, not a closure assumption on first moments.

## Uniform finite-time output amount

At tau=1 the classical value satisfies y(1)>=3s/4. To see this, if y reaches s by time1, monotonicity gives the claim. Otherwise y<=s throughout, so r'>=sqrt(3)/2 and y(1)=s sinh^2 r(1)>=s r(1)^2>=3s/4.

Spectral Chebyshev and (P3) imply for the actual measured pair number ell

    Pr[ell<S/2]
       <=16 exp(12)[1/(sN)+4/(s^2 N^2)]
       <=16 exp(12)[1/N+4/N^2].                     (P4)

No measurement of ell is needed to establish this probability. If the supplied source cap is m<=M, choose the INTEGER inventory

    L=4(N+M),    actual time t=1/(chi sqrt(L)).

Then lambda>=4s holds simultaneously for every allowed m, with the SAME L and time. The bound is independent of the native source basis label j. All source coherences and purifiers must still be transported through the existing exact sector-receiver theorem; a scalar probability calculation alone does not prove that final code composition.

## Proposed receiver consequence and remaining obligations

The existing global-energy sector receiver uses the exact normalized SU(1,1) sector vectors V_(m,ell), which this Hamiltonian retains. Its error effect is scalar in each native source sector and decreases with ell through the ratio D_m/D_(m+ell). If its reviewed uniform threshold theorem applies whenever ell>=(G_min-1)(N+m), (P4) with G_min=3/2 gives a new unconditional error contribution only O(1/N), in addition to the same exponentially small code effect. This would support each fixed rate below ln(3/2) nats per mode while paying L=O(N+M) initial pump photons, rather than using an L/N^2->infinity approximation to a different full channel.

This last paragraph is a proposed composition, not an already audited claim. Fresh criticism must check: exact signs and endpoint ladder equations; the noncommuting state-error differential inequality; the scalar trajectory up to time1; all integer tail thresholds; uniformity over coherent m sectors; the actual scalar sector receiver effect with the pump retained in the complete complement; finite decoder/readout/resource requirements; and primary prior on this collective finite-pump limit. The normal input cap, shared equal coupling, number-state preparation, calibrated interaction time, amplifier/control realization, pump preparation/reset and stronger same-pump vacuum baseline remain supplied or charged premises. No physical operation, practical advantage or civilisation-level achievement is asserted.
