# A quantized-network baseline and its missing acquisition premise

2026-10-24. Internal analytic checkpoint. No external contact or disclosure.
This file preserves all earlier frozen bytes. It does **not** refute the
Gaussian-noise theorem of Li--Werner--Low, and it does not transfer that
Gaussian lower bound to quantization. The lower below is independently derived
for a specified quantizer experiment. Priority of the forest adaptivity result
remains UNKNOWN.

## Primary sources actually read

Talkington et al., *Error Bounds for Radial Network Topology Learning from
Quantized Measurements*, final accepted manuscript, 2026, DOI
10.1109/TPWRS.2026.3666699. Its Theorem 1 imports a generalized-Lasso bound for
iid sub-Gaussian sensing rows and advertises logarithmic samples per node.
The nodal sensing matrix in Section III-A is built from a common voltage
matrix and an incidence matrix. Equation (1) additionally assumes total scalar
measurements m >= d, where d is the complete-graph edge dimension. If retained,
that premise already requires at least (n+1)/2 full actions for n non-slack
nodes. The actual simulations use common Gaussian voltage vectors. The
readout model is dithered uniform quantization, not additive Gaussian noise.
[Primary author manuscript](https://samueltalkington.com/papers/2026/talkington_quantization_2026.pdf),
[author publication page](https://samueltalkington.com/papers/2025/talkington_quantization/).

Thrampoulidis--Rawat, arXiv:1807.06976v1, Assumption 1 and Theorem III.1:
independent copies of a symmetric L-sub-Gaussian vector a are required, with
E|a^T u| >= alpha > 0 for **every** ambient unit vector u. The sample constants
depend on L/alpha. This is nondegeneracy, not a requirement stated as isotropy.
This exact preprint, rather than a separately obtained publisher PDF, was read.
[Primary complete version](https://arxiv.org/html/1807.06976v1).

Retained PDFs under `sources/`:

* `Talkington_et_al_2026_quantized.pdf`: SHA256
  `c7414794f3598dccccbc06c1c72ab962225286173ab69d7f9bb9e04b5d1e063b`.
* `Thrampoulidis_Rawat_1807.06976v1.pdf`: SHA256
  `6a68380ef45005ddbadfba29cd8952e215ec053c4763cbebb4c2bd710331c2f3`.
* Corresponding HTML SHA256
  `37717eb272f1bed48572f9a6ab8dbcf4ce93fef7126221d7169e28b81e7a513e`.

## Exact transfer obstruction

Let N=n+1 nodes include a grounded slack node 0, and parameterize a Laplacian
by all d=binom(N,2) edge weights. A scalar row for non-slack vertex i under
one common voltage x has coefficient x_i-x_j for an edge {i,j}, and zero for
every nonincident edge. Therefore its support is confined to the n incident
edges. For n>=2 there is a nonincident edge e, and

    a_i^T e_e = 0 almost surely.

Thus alpha=0 for each fixed-node row in the cited ambient nondegeneracy
condition. Moreover, two endpoint rows share the same edge voltage with
opposite signs. Their edge-coordinate covariance is

    Cov(a_i[e], a_j[e]) = -Var(x_i-x_j),

which is nonzero for independent nonconstant Gaussian voltages. They are not
independent sensing rows. Different vertex rows also have different fixed
support. Independence of the voltage coordinates does not make these scalar
sensing rows independent. A theorem for independent full-dimensional rows is
therefore not a theorem for n outputs of a shared voltage action.

Randomly permuting/pooling vertices does not remove the within-action
dependence. It also requires tracking dimension-dependent small-ball constants.
A new structured or block-dependent recovery analysis could repair the bridge;
the existing independent-row theorem alone does not supply it. The next
calculation gives a concrete necessary error scaling in the acquired model,
without relying on the forest Gaussian lower.

## Scalar quantizer coupling lemma

For Delta>0 define

    Q_Delta(z+tau) = Delta [floor((z+tau)/Delta)+1/2],
    tau uniform in [-Delta/2,Delta/2].

For any two inputs z,z', using the same dither couples their outputs with

    P[Q_Delta(z+tau) != Q_Delta(z'+tau)]
       <= min{1, |z-z'|/Delta}.

For a displacement of at most one bin, exactly a |z-z'|/Delta fraction of the
uniform interval crosses a bin boundary. Larger displacements use the trivial
bound 1. Consequently the output-law total variation is bounded by that
quantity. Applying independent common dithers coordinate by coordinate gives

    TV(P_z, P_z') <= (1/Delta) sum_l |z_l-z_l'|.       (1)

The same coupling bound holds if the dithers are revealed after acquisition:
the coupling also makes their transcript values identical. It does not grant
control choices after the future dither is known.

## All-nonadaptive-design known-path error bound

Let n=2k>=2 be the number of non-slack vertices of the **known connected path**
0--1--...--2k. The unknown weights are positive. For j=0,...,k-1 define

    w_{2j,2j+1} = 2a + (h/2) theta_j,
    w_{2j+1,2j+2} = 2a - (h/2) theta_j,
    theta_j in {-1,+1},   0<h<=a.

Every input lies in [3a/2,5a/2] on the known support, and every input has the
same **known** total edge weight 4ak. Revealing the path and this exact l1
radius therefore does not reveal the bits.

The experiment takes q>=1 common voltage actions, x_t0=0, and returns all n
non-slack currents after the independent quantization above. Controls are
nonadaptive, may be randomized independently of the input, and every supported
design obeys

    sum_t x_ti^2 <= B,   every i,   B>0.

The complete controls and all outputs are supplied to an arbitrary estimator.
No computation restriction is imposed. Set

    h = min{a, Delta/(48 sqrt(q B))}.                   (2)

**Claim.** For every such design/estimator there is a fixed promised input,
independent of the design seed, for which

    P[||w_hat-w||_2 > h sqrt(k/8)] >= 1/4.             (3)

The estimator can output a complete-graph vector; extra off-path coordinates
cannot invalidate the inequality.

**Proof.** Compare two inputs differing only in theta_j. Write their three
successive vertices as u,v,z. Up to an irrelevant common sign, their current
differences at one action are

    h(x_u-x_v),   h(x_z-x_u),   h(x_v-x_z).

Omitting the slack current only decreases the l1 difference. For any two
vertices r,s, Cauchy--Schwarz and the row budgets give

    sum_t |x_tr-x_ts| <= sqrt(q) ||x_r-x_s||_2
                          <= 2 sqrt(q B).

Equation (1) now bounds the total variation of the two complete acquired
transcripts by

    6h sqrt(q B)/Delta <= 1/8.                         (4)

This holds for every supported fixed design. Including and averaging the
independent design seed preserves (4); the same input prior is used for all
design seeds.

Choose the k bits uniformly and independently. Even if all the other bits are
revealed, the equal-prior Bayes error for bit j is at least
(1-1/8)/2=7/16. An estimator with less information has no smaller average
error. Decode its j-th bit by the sign of the difference between its two
corresponding edge estimates (fix either tie convention). Thus, if H denotes
the number of wrong decoded bits,

    E H >= 7k/16.

Since 0<=H<=k,

    E H <= k/4 + (3k/4) P[H>k/4],

so P[H>k/4]>=1/4. A wrong bit places that pair of estimated weights on the
wrong side of the midpoint hyperplane. The squared Euclidean distance to the
true pair is then at least h^2/2. Disjoint pairs add their squared distances,
giving ||w_hat-w||_2^2 >= Hh^2/2. This proves (3) under the input prior.
Averaging over this finite prior yields a fixed theta with the same failure
probability. The topology and weights are not selected after seeing the
design seed. QED.

This is a standard two-point/Assouad argument applied to the acquired path
experiment; no novelty of that technique is claimed. In the small-h regime,
the necessary error radius is a constant times

    Delta sqrt(n/(q B)).                              (5)

For bounded unit-sized controls B<=q this becomes order Delta sqrt(n)/q.
This bound concerns total parameter l2 error, not support recovery: in this
construction all support is already supplied.

## The common Gaussian-voltage version used in the baseline simulations

If each non-slack voltage is an independent N(0,1) at each action (a common
mean can be added to every vertex, including the slack, without changing
differences), then no pathwise finite B
is assumed. Instead, E|x_r-x_s|<=2/sqrt(pi), including a fixed slack node.
Averaging the scalar coupling over this design gives TV <=6qh/(Delta sqrt(pi)).
Take

    h = min{a, Delta sqrt(pi)/(48q)}.

Exactly the same bit argument proves (3), hence an acquired-model radius
Omega(Delta sqrt(n)/q). For q=O(log n), this diverges with n at fixed Delta,
whereas a bound C Delta sqrt(log n/q) with dimension-independent C stays
bounded. The topology is a connected path, the exact support and total weight
are supplied, and the priors precede the random voltages.

Accordingly, a dimension-independent total-error theorem of that advertised
form cannot hold for the actual common Gaussian-voltage experiment at
logarithmic q. One must retain a stronger sampling premise such as m>=d,
pay dimension-dependent sensing constants, change the error normalization, or
prove and state a different result. This is an obstruction to the application
bridge; it is not an assertion that the separate iid-row theorem is false.

## Status and limits

The final accepted quantized-network manuscript is a strong and relevant
baseline that must be cited. Its controls/precision/statistical model cannot
be collapsed into an iid scalar sensing oracle. The result here diagnoses
that specific transfer and total-error normalization. It does not exclude a
different nonadaptive support decoder for quantized data, establish the exact
minimax rate, or settle priority of the Gaussian forest adaptivity separation.
No physical measurements have been acquired.

Analytic status: producer derivation, awaiting independent reconstruction.
Source status: direct primary read, versions/hashes retained. Priority:
UNKNOWN. Physical: NOT_ACQUIRED. Practical: UNKNOWN. Mission: NOT_ACHIEVED.

`replay_quantized_transfer.py` independently checks 3,185 rational scalar-TV
cases, 194 connected-path bit flips, 10 complete finite joint-output laws,
and endpoint covariance/geometry identities. Its 10,823 assertions pass.
These are exact finite diagnostics, not the quantified proof or acquisition
of unknown experimental data. Physical observations: zero.
