# Open-terminal baseline diagnostics

24 October 2026. Frozen mathematical source `OPEN_TERMINAL_BASELINE.md`,
SHA256 `11980610bf506e1d15d536dbd03cd05aa5f35d1e73ac62a91d03346d001f1533`.
The source gives the universal conditional proof. This is producer
verification, not independent review or physical acquisition.

New standalone no-import `replay_open_terminal_baseline.py`, SHA256
`00e1b0cc5aa68c4593c3aafe766d46b41074f26b6582d2b2f1e06aede474e5ae`,
generated `OPEN_TERMINAL_REPLAY_RESULTS.json`, SHA256
`faf47d31370826e1c8e326fb826109d4bd0dd2e1d8c4eda6c3b8e404e249472d`.

PASS: 2,776 assertions. The exact portion directly inverts 392 full nodal
circuits and checks all terminal currents against the separate series-path
calculation. It includes present/absent cores, two positive weight profiles,
d=1,2,3 and every ordered terminal pair. The finite fair-bit sampler is
checked against all 348 balanced partitions for n=4,6,8,10. No finite
test is used as a substitute for the written all-size argument.

All 12 synthetic hidden-plant cases passed: n=32,264,1024; sigma/a=.05,.25;
absent/present core; independently selected continuous weights in[a,3a].
The learner receives only the acquisition callable and public parameters.
All 11 terminal pairs in each case are committed before data. Every
fresh noise sample, rounded/clipped scalar and repetition is counted.
The runs used 30,426 synthetic actions and 13,387,440 scalar readouts.
At sigma/a=.05, q=198 for every n; at .25, q=4,873 for every n. Response
encodings used 7--8 bits per scalar; every decision was correct and no
scalar clipped. These conservative seeded successes do not estimate
worst-case risk or show a finite practical advantage over455c.

Physical trials: 0. Real unknown experimental acquisitions: 0. Neither
settling time nor leakage was measured. Every circuit was ideally open
and already settled before its counted reading. Independent sensor noise
under opening was stipulated. Power values are nominal settled circuit
values, not acquired Watts, durations, reset costs or Joules.

The result establishes a strong ordinary comparator that must be granted
any opening capability offered to an adaptive algorithm. Its constant
action count is a property of this hidden-star promise and ideal-open
interface, not a universal constant-time connectivity measurement result.
