# Complete accounting contract and scaling limits

No complete apparatus has been measured, so the full-system answer is a cost model with explicit unknowns, plus manufacturer-based sub-budgets. Unknown terms are not zero. This contract applies to the weighted gate, the RMS replacement, the work-square construction and the same-information ordinary controller.

For a manufactured part using a fixture for `R_use` successfully qualified parts, write

`E_part = E_fixture_fabrication/R_use + E_preparation + E_calibration + E_final_inspection + E_clean/remove + sum_updates(E_teach + E_sense + E_compute/memory + E_reset + E_driver + E_cell + E_mix + E_rest_aux)`.

The corresponding monetary/labor model uses the same phases, actual reusable life, chemical replacement and rejected parts. No prices, yield or reuse life were acquired; no credible monetary break-even number can be inferred from a chip's nominal current. To claim advantage, compare equal final compliance/volume/reliability and the complete same phases, not one candidate's chemical minimum against an incumbent's wall energy.

## Acquisition and preparation

The ground geometry, force weights/range, fixed supports, admissible small-strain elastic region and a positive lower stiffness bound must be acquired. Each member's gauge requires surface preparation, adhesive cure, thermal dummies/compensation and mechanical strain-transfer calibration. A current shunt calibrates electrical gain but does not check this transfer. The fixture requires force holds and independent displacement/strain metrology; the proposed 0.2%-of-full-scale strain encoding means 20 nm extension uncertainty on a 10 mm member at 1000 microstrain full scale. Growth/etching can alter that calibration and residual strain. The assembly needs electrode/reference calibration, insulation/seal testing, preparation of the active Cu/steel interface and separate dose/stiffness measurements.

A controlled `m`-load teaching schedule costs at least `sum_s(t_force_settle,s+t_observe,s+t_unload/reset,s)`. Unknown service distributions instead have a load-acquisition cost; the retained concentration examples are hours to hundreds of days per update, depending on error. Deterministic broadcast threshold sweeps do not avoid that cost.

## Material update and reset

For Faradaic Cu charge `Q_F`, `V_Cu=Q_F/27.208906` mm³. Actual electrical input includes all current, including double-layer charging and side reactions. Measure `E_cell=integral V_cell(t) I(t) dt` at the cell and `E_driver=E_supply−E_cell` at the driver; reference/amplifier currents need their own supplies included. A referenced working-electrode potential is not automatically the full cell terminal voltage. The 0.3 V charge products in the component arithmetic are nominal comparisons, not measured total work or a thermodynamic lower bound on reversible Cu transfer.

With bounded per-cell current `I_e,max` and a total shared source limit `I_total,max`, the update time obeys

`T_update >= max(max_e |Q_e|/I_e,max, sum_e |Q_e|/I_total,max)`

before mass-transport limits, potential clipping, relaxation and etch protection. Cells acting in parallel do not make current or ionic transport free. Reservoir replacement, mixing, reference maintenance, cleaning and waste/recovery handling remain process costs. When electrodeposited material is removed, the apparatus must verify that the steel/core and adhesion layer are preserved.

The proposed unload/grow/reteach cycle includes mechanical fixture work `integral f . du`, servo/hold dissipation, fluid movement, zero taring and waiting for residual-stress relaxation. Reset is thus both electrical and mechanical. The energy-square alternative explicitly harvests some of this mechanical work; it does not eliminate it.

## Electronic/memory cost

The native ramp/converter cost is

`E_native_obs = P_shared(N) T_frame + sum_e[P_amplifier,e T_on,e + P_integrator,e T_on,e + E_switch/reset,e + E_hold,e]`.

`P_shared(N)` grows with distributed wire/input capacitance and weighted-current delivery; it cannot be held constant as `N→infinity` by simply saying “one shared DAC.” Signal loading, ground/reference drops and settling must meet the same error allowance at the farthest member.

For a shared ADC, an ordinary lower-order time estimate is `T_ADC >= N t_channel` plus fixture/multiplex settling; distributed ADCs trade time for O(N) hardware. Their code/memory cost, references, wake/restore, timing and output drivers are charged. They may enter LPM4.5, wake from the same fixture/harvester event and retain a command digitally while chemistry operates. The native gate may also power gate, but its analog leakage and zero/restore cost are charged; the quantified 54 mV/hour OPA333 bias example already rejects the current 10-microfarad long-hold proposal at the stated margin. Both can use a digital latch/hybrid if it wins.

The earlier `1.1319 microW/node` ordinary scenario and `56.35 microW/node` native one-integrator subtotal are limited component comparisons, not complete machines. A completed comparison must measure the duty schedules needed to achieve the same frame, margin and material step. Long chemical update times may make either computation cost insignificant relative to common process energy.

## Scaling and carried mass

Both need O(N) local mechanical variables, wet cells or addressed ion paths, references, current capacity and sensing/actuation interfaces. A native broadcast architecture has O(1) logical shared waveforms plus O(N) loading/local integrators; a distributed ordinary controller can have O(N) local digitization and O(1) shared communication lines. No spatial or temporal asymptotic advantage has been proved. The chemical current bound and force-teaching schedule remain regardless of algorithm.

A removable manufacturing fixture amortizes reservoirs, sensors and electronics only through a measured reuse life and preparation/removal cost. For persistent adaptation these components are carried. One millilitre of aqueous electrolyte already has mass on the order of a gram, much more than the 8.96 mg in 1 mm³ Cu, before counterelectrode, pouch, sensor, wiring and electronics. A geometry optimizer penalizing only Cu volume therefore cannot claim whole-device mass savings in that regime.

All omitted numerical full-system terms remain UNKNOWN. The assay's complete-row ledger exists specifically to prevent those terms from disappearing in a later comparison.
