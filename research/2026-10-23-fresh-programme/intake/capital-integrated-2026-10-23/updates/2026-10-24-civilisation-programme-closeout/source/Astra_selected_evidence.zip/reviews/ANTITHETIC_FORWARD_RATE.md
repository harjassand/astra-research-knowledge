# Fresh audit: median truncation closes the forward leading term at fixed D

23 October 2026, w44. This preserves a separate improvement rather than
editing either frozen forward proof. The stronger whole-queue lower
protocol was proposed by w38 in ANTITHETIC_FORWARD_RATE.md and read in
full before this audit; root independently checked its algebra. Internal
correctness assessment: no load-bearing gap found under the fixed-source
contract. Historical priority and external acceptance remain UNKNOWN.

## 1. Source and exact claim

This corollary concerns the ORIGINAL unflagged iid source, with fixed finite
D>=2, L>=1 and prior p on K in {1,...,L}. There is no supplied collective
record and no entangled stock. Accessible queue state is
sum_k p_k Phi_D^tensor k tensor nu_D^tensor(L-k); original clocks and old
memory remain in the COMPLETE source. All local apparatus is initially
independent normal local product. Codes are finite-round finite-outcome TP
strict Alice->Bob, have fixed finite output rank on all branches, and must
approach Phi_N tensor their OWN actual full residual in half trace distance.
The reliability limit r->infinity is taken at each fixed D,L,p first.

Put

    alpha_j=P(K>=j),
    Omega_p=sum_j (2alpha_j-1)_+,
    m=max{j:alpha_j>1/2}, J=min(K,m).

The cutoff exists because alpha_1=1. Then

    max{min(supp p)lnD, Omega_p lnD-H(J)}
       <=R_forward(p,D)<=Omega_p lnD.                  (M1)

In particular the additive lower gap is at most H(J)<=H(K), rather than
the number-of-layers entropy loss of the earlier valid layerwise code.
No exact finite-source capacity equality is claimed in general.

## 2. Upper bound reconstructed independently

The normalized Choi channel replaces sites after K by maximally mixed
outputs. Its flagged-erasure upper channel routes kept inputs to Bob and
the rest to the environment, with the same hidden-set flag on each side.
For EVERY possibly correlated input, its coherent information is

    E[S(rho_(S(K)))-S(rho_(S(K)^c))].

For arbitrary two site sets S,T, subadditivity and weak monotonicity yield
f(S)+f(T)<=2|S intersection T|lnD. Average using ANY self-coupling of the
whole survival-set law. The antithetic pair
K=F_p^(-1)(U), K'=F_p^(-1)(1-U) attains

    E min(K,K')=sum_j (2alpha_j-1)_+=Omega_p.

Independent uniforms at the r iid queues give a valid coupling of both
WHOLE p^tensor r marginals. Therefore every conceptual channel input has
coherent information at most r Omega_p lnD. Collapse the forward code to
Alice's instrument, refine ONLY Alice to single Kraus, keep Bob CPTP with
all his outcomes averaged, and use the unchanged hidden posterior because
Alice's marginal is always maximally mixed. Convexity and the COMPOSED
forward output twirl give the finite bound

    (1-2epsilon)lnN-h2(epsilon)<=r Omega_p lnD.           (M2)

This is the already frozen self-coupling converse, not a product-input
capacity assumption. It proves the right side of (M1).

## 3. Whole-queue truncation and its entropy

Alice and Bob locally discard all native sites after the SAME known fixed
cutoff m. Each remaining queue has exactly the conditional state associated
with J=min(K,m), so its actual accessible marginal is

    theta_m=sum_j P(J=j) Phi_D^tensor j tensor nu_D^tensor(m-j).

There is no inventory measurement or postselection. The source is iid
across original queues before and after this deterministic truncation.
Within a queue its layer correlations are preserved.

Both local marginals of theta_m are I/(D^m). The entropy of its component
at J=j is 2(m-j)lnD. The entropy-of-mixture upper bound therefore gives

    S(theta_m)<=H(J)+2(m-EJ)lnD.

Because alpha_j>1/2 precisely at j<=m,

    2EJ-m=sum_(j<=m)(2alpha_j-1)=Omega_p.

Consequently

    I_c(theta_m)=m lnD-S(theta_m)
                >=Omega_p lnD-H(J).                   (M3)

H(J)<=H(K) follows from deterministic truncation. Equality of the bound
is not assumed: the conditional component supports overlap, which can
make S(theta_m) strictly smaller than its mixture bound.

## 4. Finite actual-output realization without aid

One may invoke the primary iid forward hashing inequality directly.
An explicit realization using the SAME previously checked Buscemi-Datta
one-shot lemma is also available, so no new iid-residual premise is needed.

Let q be the finite positive-probability generalized-Bell eigenlabel law
of theta_m. Every component eigenvector is maximally entangled in local
dimension D^m. The r-queue marginal has eigenlabel law q^tensor r. Define
delta_r=r^-1/4 and its surprisal-typical set

    T_r={y^r: |-(1/r)ln q^tensor r(y^r)-S(theta_m)|<=delta_r}.

Zero-probability labels are excluded. Its probability is at least
1-beta_r with beta_r<=Var_q(-lnq)/sqrt r by Chebyshev, and

    |T_r|<=exp[r(S(theta_m)+delta_r)].

The variance is a finite constant at every FIXED source. If it vanishes,
the restriction already has full mass and the variance bound is zero.
Restrict and normalize theta_m^tensor r to T_r. Squared root fidelity is
at least 1-beta_r. Its support projection Pi, a sum of maximally entangled
product Bell projections, obeys for every normalized sigma_B

    Tr[Pi(I tensor sigma_B)]
       <=exp[r(S(theta_m)+delta_r)]/D^(mr).

Thus smoothed zero-coherent information is at least
r[m lnD-S(theta_m)-delta_r]. Choose

    eta_r=max{8sqrt(beta_r),exp(-sqrt r)}.

For sufficiently large r, the primary unassisted one-shot one-way lemma
gives a finite TP Alice->Bob code at any deterministic rank satisfying

    lnN_r<=r[m lnD-S(theta_m)-delta_r]
                      -2ln(1/eta_r)-3ln2.              (M4)

Here beta_r<=eta_r^2/64 and 2ln(1/eta_r)<=2sqrt r=o(r).
If the rate is positive, floor the exponential right side; if not, use
a rank-one target for this lower construction. It achieves every rate
below [I_c(theta_m)]_+ and, by a slow diagonal choice or the displayed
penalties, the limiting coherent-information rate itself when positive.

All failure branches are in this TP code at the fixed rank. The Bell-label
typical set is used to prove and compile the code; it is not physically
measured or supplied to the receiver. No Bell reserve or backward message
is used. The original discarded native tails, clock, old memory, all code
transcripts and work remain in the actual residual. The pure-output lift
turns its vanishing Bell marginal error into half-trace convergence to
Phi_(N_r) tensor that OWN full residual. Keeping the exact mandatory prefix
is a separate admissible alternative. Equations (M2)-(M4) prove (M1).

## 5. Uniform inventories and two-point extremes

For uniform K in {1,...,L}, the exact antithetic overlap is

    Omega_p=L/4+1/2                         (L even),
             L/4+1/2+1/(4L)                (L odd).

Since H(J)<=lnL, (M1) shows at every fixed D>=2, after the fixed-source
r limit and then L->infinity,

    R_forward=(L/4)lnD+O_D(lnL),
    R_forward/B ->1/2, B=((L+1)/2)lnD.                 (M5)

The previously audited ordinary two-way receiver obeys
B-lnL-4ln2<=R_two_way<=B. Hence in the SAME order of limits

    R_two_way/B ->1,
    R_two_way/R_forward ->2.                            (M6)

The joint D,L->infinity consequence of the earlier layer code remains
valid, but a growing D is unnecessary for this stronger whole-queue proof.
There is no simultaneous growing-source/blocklength claim.

For a two-point prior K in {1,L} with P(K=L)=w<=1/2, alpha_1=1 and
alpha_j=w for j>=2. Thus Omega_p=1 and m=1, so H(J)=0. The bounds coincide:

    R_forward=lnD.

For fixed 0<w<=1/2 and L->infinity, ordinary two-way recovery has rate
B-O(1) with B=[1+w(L-1)]lnD, while the exact forward rate is constant.
This is the familiar antidegradability/no-cloning mechanism in this
particular source interface, not a newly discovered generic feedback
phenomenon. The w=0 endpoint is simply the deterministic pure prefix.

## 6. Essential scope caution for correlated actual posteriors

The antithetic coordinate optima in (M2) combine because the ORIGINAL
inventories are iid. For an arbitrary correlated posterior given Z_r,
one must instead minimize over self-couplings of the WHOLE posterior.
Its coordinate Fréchet lower bounds need not be jointly attainable.

A concrete counterexample is the posterior on tail-survival bits uniform
on 000,011,101,110. Every coordinate has marginal one-half, suggesting
zero if one incorrectly sums coordinate Fréchet optima. Yet every nonzero
word has a disjoint partner only at 000. At most one-quarter of row mass
can match to that column, so at least one-half of total mass matches two
nonzero words, whose intersection size is at least one. The minimum cost
is therefore at least one-half and is attained by pairing 000<->011 and
101<->110, each direction with mass one-quarter. Hence the minimum is
exactly one-half, not zero. Such a posterior can arise by conditioning
three iid binary inventories on their even-parity record. This is an
actual finite source/record counterexample to a tempting stronger upper,
not a contradiction of the valid whole-posterior transport converse.

Primary one-shot dependency: https://arxiv.org/html/1006.1896v2,
Definitions (9),(11), Lemma 2 (23). Primary iid hashing alternative:
https://arxiv.org/html/quant-ph/0306078v1, Theorem 10. Exact retrieved
primary bytes remain preserved. General erasure/feedback distinctions and
one-way locking are prior art. No efficient decoder, physical apparatus,
record-acquisition method or practical advantage is established.
Historical priority and external correctness remain UNKNOWN; physical
validation, computational advantage and practical value NOT_ESTABLISHED.
Mission: NOT_ACHIEVED.
