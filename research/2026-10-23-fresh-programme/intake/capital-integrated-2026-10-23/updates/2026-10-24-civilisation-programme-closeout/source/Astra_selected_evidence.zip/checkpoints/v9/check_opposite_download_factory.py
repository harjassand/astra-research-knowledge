"""Root's independent native opposite-download uploader; no worker imports."""
from collections import defaultdict
from itertools import product
from pathlib import Path
import math,json
import numpy as np

def words(H):return [w for h in range(H+1) for w in product((1,2),repeat=h)]
def act(state,port,which,alpha,beta,x,H,adjoint=False):
    out=defaultdict(complex)
    for (f,ps,e),z in state.items():
        word=f if which=='F' else e; colour=ps[port]
        if colour==0:
            if word:newcolour,newword,phase=word[0],word[1:],1
            else:newcolour,newword,phase=0,(),x
        else:
            assert len(word)<H,'Unreachable colored boundary reached'
            newcolour,newword,phase=0,(colour,)+word,1
        p=list(ps);p[port]=newcolour;p=tuple(p)
        key=(newword,p,e) if which=='F' else (f,p,newword)
        out[key]+=alpha*phase*z
        out[(f,ps,e)]+=(-1j if adjoint else 1j)*beta*z
    return {k:v for k,v in out.items() if abs(v)>1e-15}
def inner(a,b):return sum(z.conjugate()*b.get(k,0) for k,z in a.items())

def case(H,T,beta,x,wrong_local=False,wrong_order=False,physical_x=None):
    alpha=math.sqrt(1-beta*beta);a=alpha*alpha;basis=words(H)
    physical_x=x if physical_x is None else physical_x
    downloads=[];outputs=[]
    for word in basis:
        state={(word,(0,)*T,()):1+0j}
        for j in range(T):state=act(state,j,'F',alpha,beta,x,H,not wrong_local)
        downloads.append({p:z for (f,p,e),z in state.items() if not f})
        for j in (range(T) if wrong_order else reversed(range(T))):
            state=act(state,j,'E',alpha,beta,physical_x,H)
        outputs.append(state)
    gram=np.array([[inner(u,v) for v in downloads] for u in downloads])
    overlap=np.array([[outputs[j].get(((),(0,)*T,w),0) for j in range(len(basis))] for w in basis])
    iso=np.array([[inner(u,v) for v in outputs] for u in outputs])
    diag=np.array([sum(math.comb(T,k)*a**k*(1-a)**(T-k) for k in range(len(w),T+1)) for w in basis])
    tau=1-diag[-1]
    return dict(H=H,T=T,beta=beta,sector=x,physical_sector=physical_x,
        forward_calls=T,quantum_backward_returns=0,
        wrong_local=wrong_local,wrong_order=wrong_order,
        overlap_identity_error=float(np.max(np.abs(overlap-gram))),
        binomial_operator_effect_error=float(np.max(np.abs(gram-np.diag(diag)))),
        isometry_error=float(np.max(np.abs(iso-np.eye(len(basis))))),
        squared_stinespring_error=float(np.linalg.eigvalsh(2*np.eye(len(basis))-overlap-overlap.conj().T)[-1]),
        squared_analytic_bound=2*tau)

checks=[]
for H in (1,2,3):
    for T in (H,H+1,H+2):
        for beta in (0.,.2,.6,.8,.99):
            for x in (1,-1):
                c=case(H,T,beta,x)
                assert c['overlap_identity_error']<1e-11,c
                assert c['binomial_operator_effect_error']<1e-11,c
                assert c['isometry_error']<1e-11,c
                assert abs(c['squared_stinespring_error']-c['squared_analytic_bound'])<1e-10,c
                checks.append(c)
neg=[case(2,3,.6,1,wrong_local=True),case(2,3,.6,1,wrong_order=True),case(1,2,0.,1,physical_x=-1)]
for c in neg:assert c['overlap_identity_error']>.1,c
report=dict(status='PASS_INDEPENDENT_NATIVE_DIAGNOSTICS',native_interface_cases=len(checks),checks=checks,
    max_overlap_identity_error=max(c['overlap_identity_error'] for c in checks),
    max_isometry_error=max(c['isometry_error'] for c in checks),negative_controls=neg,
    evidence_limit='Floating finite original native-action checks; universal proof is the analytic operator overlap. No reflected physical bath boundary; no physical experiment. Generic opposite-time uploader is Burgarth-Giovannetti2007 prior art.')
Path(__file__).with_name('OPPOSITE_DOWNLOAD_INDEPENDENT_CHECKS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('checks','negative_controls')},indent=2))
