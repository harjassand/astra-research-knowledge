"""Exact actual-word bootstrap algebra and local-program completion checks.

Ports are measured in their computational basis only in this proposed
classical prefix. Root I/U amplitudes with the SAME record interfere
coherently. This is finite local algebra, not a physical operation.
"""
from fractions import Fraction as F
from pathlib import Path
import json

HERE=Path(__file__).resolve().parent


def eye(n):
    return [[F(i==j) for j in range(n)] for i in range(n)]


def zero(n):
    return [[F(0) for _ in range(n)] for _ in range(n)]


def mul(a,b):
    return [[sum(x*y for x,y in zip(r,c)) for c in zip(*b)] for r in a]


def trn(a):
    return list(map(list,zip(*a)))


def scale(a,x):
    return [[x*y for y in r] for r in a]


def plus(a,b):
    return [[x+y for x,y in zip(r,s)] for r,s in zip(a,b)]


def cycle(colour,r,alpha,beta):
    I=eye(4)
    # Realification of multiplication by i and of R_seed=X.
    Ji=[[F(0),F(0),-F(1),F(0)], [F(0),F(0),F(0),-F(1)],
        [F(1),F(0),F(0),F(0)], [F(0),F(1),F(0),F(0)]]
    R=[[F(0),F(1),F(0),F(0)], [F(1),F(0),F(0),F(0)],
       [F(0),F(0),F(0),F(1)], [F(0),F(0),F(1),F(0)]]
    root=plus(scale(R,alpha),scale(Ji,beta))
    assert mul(trn(root),root)==I
    branches={((),()):I}
    for inp in [colour]+[0]*r:
        nxt={}
        for (record,word),K in branches.items():
            # The identity and involution terms are added before any
            # measurement collapse when their output record/word agree.
            staykey=(record+(inp,),word)
            stay=scale(mul(Ji,K),beta)
            nxt[staykey]=plus(nxt.get(staykey,zero(4)),stay)
            if inp:
                out,newword,seed=0,(inp,)+word,I
            elif word:
                out,newword,seed=word[0],word[1:],I
            else:
                out,newword,seed=0,(),R
            key=(record+(out,),newword)
            move=scale(mul(seed,K),alpha)
            nxt[key]=plus(nxt.get(key,zero(4)),move)
        branches={k:v for k,v in nxt.items() if any(x for row in v for x in row)}
    a,b=alpha*alpha,beta*beta
    complete=zero(4)
    success=F(0)
    failures=0
    for (record,word),K in branches.items():
        gram=mul(trn(K),K)
        if not word:
            assert record.count(colour)==1 and all(x in[0,colour] for x in record)
            j=record.index(colour)
            prob=b if j==0 else a*a*b**(j-1)
            success+=prob
        else:
            assert word==(colour,) and not any(record)
            prob=a*b**r
            failures+=1
        assert gram==scale(I,prob)
        complete=plus(complete,gram)
    assert failures==1 and complete==I
    assert success==1-a*b**r
    return {'colour':colour,'zero_count':r,'instrument_branches':len(branches),
            'success_probability':str(success),'failure_probability':str(a*b**r),
            'all_record_probabilities_seed_independent':True,
            'coherent_root_terms_added_before_measurement':True}


def main():
    n=256
    alpha,beta=F(n*n-1,n*n+1),F(2*n,n*n+1)
    assert alpha*alpha+beta*beta==1 and beta*beta<F(1,16384)
    rows=[cycle(c,r,alpha,beta) for c in[1,2] for r in[1,2,4,8]]
    # Different finite native completions can share the SAME ideal
    # encoder input columns; Bob uses his own stored inverse throughout.
    UA,UB=zero(4),zero(4)
    for j,i in enumerate([0,2,1,3]):UA[i][j]=F(1)
    for j,i in enumerate([0,2,3,1]):UB[i][j]=F(1)
    assert mul(trn(UA),UA)==eye(4) and mul(trn(UB),UB)==eye(4)
    assert [r[:2] for r in UA]==[r[:2] for r in UB]
    product=mul(trn(UB),UA)
    assert [r[:2] for r in product]==[r[:2] for r in eye(4)]
    assert product!=eye(4)
    # Initial-prefix mathematical error has room for a separate native
    # subbudget; no uncharged initial preparation is required.
    z=F(1,1000)
    binit=44
    ainit=binit+8
    assert 16*(F(1,2**ainit)+F(1,2**binit))<=(z/64)**2
    ninit=16*(ainit+binit+4)
    init_instrument_steps=16*ninit
    init_instrument_error=z/(1024*ninit)
    assert init_instrument_steps*init_instrument_error==z/64
    data={'status':'PASS_EXACT_FINITE_BOOTSTRAP_AND_COMPLETION_FIXTURES',
          'scope':__doc__,'alpha':str(alpha),'beta':str(beta),'rows':rows,
          'actual_word_cases':len(rows),
          'instrument_branches_checked':sum(r['instrument_branches'] for r in rows),
          'different_global_completions_same_encoder_columns':True,
          'own_stored_receiver_inverse_correct_on_sender_embedding':True,
          'initial_prefix_native_subbudget':str(z/64),
          'initial_prefix_native_accuracy_bits_sufficient':38,
          'physical_status':'NOT_PERFORMED','mission':'NOT_ACHIEVED'}
    # The stated 38-bit accuracy is stronger than the exact required
    # z/(1024*ninit); verify rather than infer it from decimal rounding.
    assert F(1,2**38)<=init_instrument_error
    payload=json.dumps(data,indent=2)+'\n'
    out=HERE/'PAID_BOOTSTRAP_EXACT.json'
    if out.exists():assert out.read_text()==payload,'refuse changed frozen output'
    else:out.write_text(payload)
    print(json.dumps({'status':data['status'],'actual_word_cases':len(rows),
                      'branches':data['instrument_branches_checked']}))


if __name__=='__main__':main()
