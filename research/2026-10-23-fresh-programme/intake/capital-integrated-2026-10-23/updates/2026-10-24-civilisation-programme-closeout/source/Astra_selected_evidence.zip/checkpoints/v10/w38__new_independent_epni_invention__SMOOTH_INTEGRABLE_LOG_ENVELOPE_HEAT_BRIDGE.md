# Smooth integrable log envelopes at the finite-energy boundary

24 October 2026, W38. New internal candidate, full fresh criticism PENDING.
The frozen common-power note2167da80... and its W49 receipt6175a2a3... are
preserved separately. The present proof extends the tail representation;
it does not inherit a fresh verdict from that earlier review. It uses
actual Gaussian heat and one-mode unflagged thermal mixtures. It is not
the general finite-energy or original unheated amplifier EPnI. Historical
priority, a useful threshold, physical validity and advantage UNKNOWN.

All logarithms and entropies are natural. theta_a denotes a native thermal
state of mean photon number a>=0. H_T theta_a=theta_(T+a).

## 1. Source class and main claims

Let R>=0 have arbitrary probability law on a fixed bounded interval and,
past a fixed r0>1, a density

    f_R(r)=r^-2{ell(ln r)+E(ln r)},
    |E(x)|<=K ell(x)/x^2.                             (S1)

The positive function ell is C^2, integrable and nonincreasing on a
half-line, with fixed finite K satisfying there

    0<=-ell'(x)<=K ell(x)/x,
    |ell''(x)|<=K ell(x)/x^2.                         (S2)

The error E need only be measurable. The density is required nonnegative;
this follows eventually from(S1). Its bounded body includes any atoms,
including an atom at zero. Define

    M(x)=integral_x^infinity ell(u)du,
    a=ER<infinity, rho_R=E theta_R.                   (S3)

The first claim is the two-term ACTUAL quantum relative entropy

    D(H_T rho_R || theta_(T+a))
      =T^-1{M(l)-ell(l)[ln l+gamma_E]}+o(ell(l)/T),
    l=ln T, T->infinity.                             (S4)

No common power-law index, full second R moment, thermal chi-squared or
exponential source moment is assumed.

For two INDEPENDENT laws satisfying(S1)--(S2), ell_A and ell_B can differ,
and their ratio need not converge. Fix G>1, lambda=G-1, s=2G-1,
theta=G/s, phi=lambda/s. The original amplifier, applied to the actual
independent heated states H_T rho_A tensor H_T rho_B, has entropy gap

    S_C-g(G g^-1(S_A)+lambda[g^-1(S_B)+1])
      ={ -theta ell_A(l)ln theta-phi ell_B(l)ln phi }/T
            +o((ell_A(l)+ell_B(l))/T)>0              (S5)

for every sufficiently large finite T at each fixed source pair and G.
The inequality on the right is eventual, not an acquired finite threshold.

## 2. Uniform elementary consequences of the premises

Integrating the logarithmic derivative bound in(S2) gives constants c,C,
which can depend on the fixed source, such that

    ell(x)>=c x^-K,  |ln ell(x)|=O(ln x),
    c x ell(x)<=M(x)<=C.                            (S6)

For the lower M bound integrate over[x,2x] and use
ell(2x)>=2^-K ell(x). Since ell is integrable and nonincreasing, ell(x)
tends to zero and is bounded above; this proves the log bound as well.
For every fixed b,

    ell(x+b)=ell(x)[1+O(1/x)],
    M(x+b)=M(x)-b ell(x)+O(ell(x)/x).                (S7)

The omitted-tail moment and probability estimates, uniformly for fixed
delta in(0,1), are

    P(R>delta t)=O(t^-1 ell(l)),
    E[R;R>delta t]=O(M(l)),
    E[R^2;R<=delta t]=O(t ell(l)), l=ln t.          (S8)

For the probability substitute x=ln r; its tail has an e^-x factor and
ell is nonincreasing. The small fixed shift of l is controlled by(S7).
The mean-tail error due to E is at most
K integral_l^infinity ell(x)/x^2 dx<=K ell(l)/l, so the main term is M.
For the truncated second moment split at sqrt(t). Below it, the bound
sqrt(t) ER is o(t ell(l)) by(S6). From sqrt(t) to delta t,
ell(ln r)<=ell(l/2)<=2^K ell(l), and integrating the density after
multiplication by r^2 gives O(t ell(l)). The bounded body is harmless.

We will also use this physical-scale comparison: for any fixed epsilon>0,
large r,R in the continuous tail have

    ell(ln R)/ell(ln r)
      <=C_epsilon max((R/r)^epsilon,(R/r)^-epsilon). (S9)

For R>=r monotonicity suffices. For R<=r write z=ln(r/R)>=0;
(ln r/ln R)^K<=(1+z/x0)^K<=C_epsilon exp(epsilon z).
All the estimates in this section depend only on the fixed supplied law;
they are not inferred from a finite measured sample.

## 3. Complete classical entropy and a moving crossover

The positive P coherent-radius density of the actual heated mixture and
its matching thermal reference are respectively

    h_t(r)=E (t+R)^-1 exp[-r/(t+R)],
    q_t(r)=(t+a)^-1 exp[-r/(t+a)], r>=0.             (S10)

Both are normalized. Classical KL is finite by convexity and the matched
mean:

    D_cl(h_t||q_t)<=ln(t+a)-E ln(t+R)<=ln(1+a/t).

Thus the nonnegative integrand Phi(h,q)=h ln(h/q)-h+q may be used without
subtracting infinite entropy integrals. Rescale r=ty; let H_t(y)=t h_t(ty)
and Q_t(y)=t q_t(ty), with k_x(y)=(1+x)^-1 exp[-y/(1+x)].

Expand k_(R/t) to first order only on R<=delta t. By(S8), centering at the
FULL mean a, and bounding the remaining large-temperature integral, one
obtains uniformly in y>=0

    |H_t-Q_t|<=A_t(y)+B_t(y),
    A_t=C t^-1 M(l)(1+y)^2 exp(-cy),
    B_t=C t^-1 ell(l)(1+y)^-2,
    c=1/(1+delta)>1/2.                              (S11)

In detail, the first-order part retains
-E[R;R>delta t]k'_0/t as well as -P(R>delta t)k_0.
The second-order remainder is bounded by the truncated second moment in
(S8). The reference's O(t^-2) remainder is smaller than A_t by(S6).
For the large R integral, set R=tx>=delta t. Monotonicity and(S7) give
ell(l+ln x)<=C_delta ell(l) for ALL x>=delta, so it is bounded by

    C t^-1 ell(l) integral_delta^infinity
              x^-3 exp(-c_delta y/x)dx
      <=C t^-1 ell(l)(1+y)^-2.

Choose the moving boundary

    Y=l-ln ell(l)+2ln l, X=tY, x=ln X.             (S12)

Equation(S6) gives Y=l+O(ln l) and x=l+ln l+o(1); exactly
exp(-Y)=t^-1 ell(l)l^-2. Since Q_t>=c0 exp(-y), the local bound
Phi(H,Q)<=(H-Q)^2/Q and(S11) give

    integral_0^Y Phi(H_t,Q_t)dy
       <=C t^-2 M(l)^2
          +C t^-2 ell(l)^2 exp(Y)/(1+Y)^4
       =O(t^-2 M(l)^2)+O(t^-1 ell(l)l^-2)
       =o(ell(l)/t).                               (S13)

The A integral converges because 2c>1. The B integral is bounded by
C exp(Y)/(1+Y)^4, for example by splitting at Y/2. In the last limit,
M is bounded and ell(l)>=c l^-K, so M(l)^2/[t ell(l)] tends to zero.
This is a LOCAL quadratic argument; the actual global chi-squared can
be infinite and has not been used.

## 4. Remote removal of heat at the required smaller scale

Define h0(r)=E[R^-1 exp(-r/R);R>0] only on r>0. A zero-temperature atom is
not an ordinary density, and h0 need not have total mass one. We use it
only for r>=X. Restricting to R in[r,2r] gives common lower bounds

    h_t(r),h0(r)>=c r^-2 ell(ln r), r>=X.

Their upper bounds are h_t<=1/t and h0<=1/(er). On their positive segment
the absolute log ratio to q_t is O(r/t): from(S6), the lower logarithm
cost is O(ln r+ln ln r), while r/t>=ln r for r>=X and all large t.
Consequently the remote Phi replacement error is at most

    C integral_X^infinity (r/t)|h_t(r)-h0(r)|dr.     (S14)

Split into three ranges of the temperature R, with l=ln t.

SMALL R<=t/l^2: the heated kernel is bounded by
t^-1 exp[-r/(t(1+l^-2))]. Its contribution to(S14) is
O(Y exp[-Y/(1+l^-2)])=O(ell(l)/(t l)). The unheated kernel is bounded by
(l^2/t)exp(-r l^2/t) and is smaller. This uses all of the small-temperature
probability, including the bounded body; no atom is silently removed.

MEDIUM t/l^2<R<=delta t: by(S8) at the shifted cutoff its probability is
O(t^-1 l^2 ell(l)). The heated and unheated kernels have exponential
decay exp(-c r/t), so the contribution is bounded by
C t^-1 l^2 ell(l)Y exp(-cY)=o(ell(l)/t).

LARGE R>delta t: differentiation of the positive exponential kernel gives

    |K_(R+t)(r)-K_R(r)|
       <=C_delta t R^-2(1+r/R)exp(-c_delta r/R).

Multiply by(S1), use(S9), and put R=rv. Taking epsilon<1 leaves an
integrable v^-4(1+1/v)exp(-c_delta/v) times the two powers in(S9), so

    |h_t^large(r)-h0^large(r)|
       <=C t r^-3 ell(ln r).

Its contribution to(S14) is bounded by
C integral_X^infinity r^-2 ell(ln r)dr<=C ell(ln X)/X
=O(ell(l)/(t l)) by monotonicity and(S7). We have proved

    integral_X^infinity Phi(h_t,q_t)dr
       =integral_X^infinity Phi(h0,q_t)dr+o(ell(l)/t). (S15)

This is a direct estimate on the actual heated density. No inverse heat
channel, global strong norm or high source moment is invoked.

## 5. Mellin transform and the entire remote entropy

Writing z=r/R in the continuous tail of h0 gives the kernel z exp(-z).
The Taylor formula from(S2), with the density error(S1), proves

    h0(r)=r^-2{ell(v)-(1-gamma_E)ell'(v)
                         +O(ell(v)/v^2)}, v=ln r.  (S16)

Here integral z e^-z dz=1 and integral z e^-z ln z dz=1-gamma_E.
For a rigorous remainder, split z at r^-1/2 and r^1/2. In the middle,
v-ln z lies in[v/2,3v/2], where ell and its second derivative are uniformly
bounded relative to ell(v) and ell(v)/v^2 by(S2). The integrated remainder
is at most C ell(v)/v^2 times integral z e^-z(ln z)^2. The small-z part is
O(ell(v)/r) by monotonicity. The large-z part is exponentially small even
after the polynomial lower bound(S6). The bounded temperature body has an
exponentially decaying kernel and is separately smaller. This also shows
that the merely bounded error E contributes only the stated O term.

Let x=ln X as in(S12). Integrating the positive remote density yields

    I1:=integral_X^infinity r h0(r)dr
       =M(x)+(1-gamma_E)ell(x)+O(ell(x)/x),
    I0:=integral_X^infinity h0(r)dr ~ell(x)/X,
    Ilog:=integral_X^infinity h0(r)ln r dr ~x ell(x)/X. (S17)

For I1 the second term integrates ell' exactly, using ell(infinity)=0.
The remainder is bounded by integral_x^infinity ell(u)/u^2 du<=ell(x)/x.
The latter two asymptotics follow by r=Xu, dominated convergence with
u^-2 and u^-2(1+ln u), and monotonicity. In particular

    l I0-2Ilog=-ell(l)/t+o(ell(l)/t).                (S18)

By(S16), ln h0=-2ln r+ln ell(ln r)+O(1/ln r).
The term integral h0 ln ell(ln r) is O(ell(x)ln x/X), since(S6) bounds
its absolute logarithm by C(1+ln ln r). It is therefore o(ell(l)/t).
Constant multiples of I0 and the O(1/ln r) part are smaller still. Finally

    integral_X^infinity q_t(r)dr
       =O(exp(-Y))=O(ell(l)/(t l^2)).

The exact remote entropy decomposition is

    integral_X^infinity Phi(h0,q_t)dr
      =I1/(t+a)+ln(t+a)I0+integral h0 ln h0-I0
                                +integral q_t.     (S19)

Changing t+a to t in the leading first-moment denominator costs at most
C M(x)/t^2=o(ell(l)/t) by(S6); its logarithm costs even less. Equations
(S7),(S12) give

    M(x)=M(l)-ell(l)ln l+o(ell(l)),
    ell(x)=ell(l)+o(ell(l)).

Combining(S13),(S15),(S17)--(S19), with
(1-gamma_E)ell(l)/t-ell(l)/t=-gamma_E ell(l)/t, proves the full classical
version of(S4), with a little-o remainder at the claimed smaller scale.
No part of the remote radial first moment has been discarded.

## 6. Transfer to the actual normal quantum state

The positive coherent-state preparation channel maps h_t and q_t into
H_t rho_R and theta_(t+a); their heterodyne measurement gives h_(t+1) and
q_(t+1). Normal relative-entropy DPI gives the opposite sandwich

    D_cl(h_(t+1)||q_(t+1))
      <=D(H_t rho_R||theta_(t+a))<=D_cl(h_t||q_t).    (S20)

The main term proved in Section5 changes under t->t+1 by O(M(l)/t^2)
plus smaller terms, using M'=-ell and(S2). Equation(S6) makes this
o(ell(l)/t), while the two little-o scales at t and t+1 are equivalent.
Thus(S20) proves the ACTUAL quantum expansion(S4). All quantum states
have finite energy and finite entropy. Exactly

    D(H_t rho_R||theta_(t+a))=g(t+a)-S(H_t rho_R).

The temperatures and coherent variables are only analytic ensemble
coordinates. No record of either is supplied to a party for free.

## 7. Closure under the actual two-port temperature law

Scaling by c>0 replaces ell(x) by c ell(x-ln c), up to the allowed
O(ell(x)/x^2) remainder. Such a shifted envelope is eventually C^2,
nonincreasing, integrable and satisfies(S2) with adjusted constants.

For independent temperatures U,V in the class, their sum has envelope
ell_U+ell_V, at the same relative O(1/(ln r)^2) precision. To check this,
split the convolution at h=r/(ln r)^2 and r-h. At the first endpoint,
the principal density of V changes by O(h/r)=O((ln r)^-2) uniformly as
its argument ranges in[r-h,r]; the(S1) remainder remains uniformly of that
order without differentiating E. The other endpoint is symmetric. The
omitted endpoint probabilities are O(ell(ln h)/h), hence smaller than
(ln r)^-2. In the middle, one argument is at least r/2, so the integral
is at most

    C r^-2[ell_U(ln r)P(V>h)+ell_V(ln r)P(U>h)],

which is O(r^-2[ell_U+ell_V](ln r)^-2) by(S6)--(S8). Atoms in the bounded
body enter the endpoint integrals; there are no unaccounted large-r atoms.

A fixed added temperature also preserves the allowed envelope/error
class. The SMOOTH PRINCIPAL factor changes relatively by O(1/r); the
TOTAL error is only claimed O((ln r)^-2), not O(1/r), since E may
oscillate. This keeps the fixed-shift correction required by W49's
earlier2167 audit explicit.

Conditional on the original independent input temperatures, the ACTUAL
output is thermal with mean

    sT+W, W=lambda+G R_A+lambda R_B.

Consequently W has an envelope in the class,

    ell_W(x)=G ell_A(x-ln G)+lambda ell_B(x-ln lambda),
    M_W(x)=G M_A(x-ln G)+lambda M_B(x-ln lambda).    (S21)

Both equalities define the principal envelope and its tail integral;
the convolution and fixed shift contribute only the allowed density
remainder. Independent averaging gives the true unflagged quantum
output, so(S4) applies to it at the heat time sT.

## 8. Entropy-target cancellation without a common tail exponent

Let d_A,d_B,d_C be the ACTUAL thermal entropy defects of the two inputs
and output. At the matching thermal means T+a_A,T+a_B and
sT+G a_A+lambda(a_B+1), the entropy target is EXACTLY equal to the thermal
output entropy. Its two entropy derivatives are theta+O(1/T) and
phi+O(1/T), and its Hessian is bounded along the finite segment in question.
These facts also follow directly from g'(n)=ln(1+1/n) and
g''(n)=-1/[n(n+1)]. All effective input means on that segment lie in
[T,T+a_i], since concavity gives S(H_T rho_i)>=g(T).

Thus a finite scalar Taylor formula gives the actual entropy gap

    theta d_A+phi d_B-d_C
         +O((d_A+d_B)/T)+O((d_A+d_B)^2).            (S22)

The classical convexity bound in Section3 gives d_i<=a_i/T. By(S6), both
errors in(S22) are o((ell_A(l)+ell_B(l))/T). Applying(S4) and(S21) at sT,

    M_i(l-ln theta_i)=M_i(l)+ell_i(l)ln theta_i
                                +O(ell_i(l)/l),
    ell_i(l-ln theta_i)=ell_i(l)[1+O(1/l)],
    ln(l+ln s)=ln l+O(1/l),

where theta_A=theta,theta_B=phi. The M_i(l)/T, ln l and Euler terms all
cancel between the weighted input defects and output. This proves(S5).
Its remainder is controlled relative to ell_A+ell_B even if their ratio
has no limit. The fixed positive coefficients -theta ln theta and
-phi ln phi bound its main term below by a positive constant times
(ell_A+ell_B)/T, giving strict eventual positivity.

## 9. Explicit critical examples and costs

For ANY q>1 put, exactly on r>=exp(e),

    f_R(r)=1/[r^2 ln r (ln ln r)^q],                (S23)

and put the remaining probability at R=0. Its tail mass is less than
exp(-e)/e<1. The mean is exactly a=1/(q-1). Its envelope and integral are

    ell_q(x)=1/[x(ln x)^q],
    M_q(x)=(ln x)^(1-q)/(q-1), x>=e.              (S24)

Here -ell'/ell=(1+q/ln x)/x, and
ell''/ell=[2+3q/ln x+q(q+1)/(ln x)^2]/x^2, so all premises hold.
Every moment ER^(1+epsilon), epsilon>0, is infinite, by the polynomial
lower bound in(S6) after r=exp x. Jensen conditional on the thermal law
then gives an infinite photon-number moment of every order above one.
These sources lie beyond every common-power p>1 logarithmic class of2167:
their density is asymptotically heavier than r^-2(ln r)^-p for each p>1.
Different q values, powers and their smooth integrable combinations may
be used at the two independent ports. No higher-moment premise is hidden.

The theorem still inserts ACTUAL H_T, adding T photons to each input.
Fixed source, G and exact tail/envelope/independence premises come before
T->infinity. At T>=1 this heat is entanglement breaking, and these
particular source states were already classical thermal mixtures. The
proof does not acquire the tail from finite observations, supply a
useful T, remove preparation/pump/reset/precision costs, preserve arbitrary
native entanglement, or undo the heat on the original inputs.

No arbitrary finite-energy irregular or atomic unbounded tail is covered;
the supplied smooth principal-envelope and small error conditions matter.
General independent-input unheated EPnI remains NOT_ACHIEVED. Classical
Mellin/regular-variation methods, coherent-state DPI, Gaussian heat and
scalar entropy derivatives are prior tools; exact class-specific priority
is UNKNOWN. This new full chain requires fresh criticism, especially the
integrated O(ell/x^2) error, moving crossover, convolution remainder and
non-comparable two-port scales. Finite controls cannot replace that audit.
