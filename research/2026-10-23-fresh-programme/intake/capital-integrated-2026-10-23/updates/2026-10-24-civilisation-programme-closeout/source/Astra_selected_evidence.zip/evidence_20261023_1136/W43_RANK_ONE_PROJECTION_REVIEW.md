# Fresh audit: all descended projections and rank-one P1 physical laws

23 October 2026. Verdict: **PASS in the stated scope; no mathematical gap
found.** This is a same-team independent derivation and implementation
audit, not independent external expert acceptance. Novelty is unknown.

The frozen objects audited are:

* W26 `RANK_ONE_IMAGE_TREE_THEOREM.md`, SHA256
  `ee82fa392137293389acd6f96f6a1ceca6b0f55a652cfa4f0ee8e427a546eff2`.
* W26 `ALL_DESCENDED_PROJECTIONS_POSITIVE.md`, SHA256
  `0c129c571d6eb47f3d1fcc1201992fb4382ec2f94c1ee704356cfda7d4fc8fda`.

The singular theorem concerns EVERY admitted finite straight triangulation
of a polygonal disk, EVERY finite output dimension, actual positive
source areas, rank-at-most-one face gradients, and affine boundary trace
of rank at most one. Its exact physical law has a finite binary tree.

The full projection theorem concerns the FIXED N9 source geometry and its
affine equivalents: every two-output actual hat field admitting ONE fixed
matrix (D) with (det G_f=D:G_f) on every face is finite. The singular
case follows from the general rank-one theorem. In the nonsingular case,
at most twenty-two physical terminal occurrences suffice. Generic
two-output fields without that support identity remain outside the
theorem. This is not an all-N9 result or a Morrey resolution.

## 1. The target graph and lift withstand the topological objections

A rank-one affine triangle has a point or straight-segment image.
After subdividing all proper intersections and collinear overlaps, the
finite union is an embedded finite graph, in any finite output dimension.
Endpoints are nodal values; isolated constant images are also nodal
values and are inserted when they lie on an edge. Continuity of the map
on the connected source makes the image graph connected, unless it is
the single constant point. Coincident target pieces must be identified;
their multiple occurrences are subsequently distinguished by the lift.

A simply connected polygonal disk maps continuously into this finite
graph. The standard universal-cover lifting criterion therefore supplies
a continuous lift into its covering tree, once one basepoint is fixed.
This does NOT assert that the geometric image graph is itself a tree.
Cycles in that image are permitted. The reduced-edge-word construction
is valid: traversing a reversed last edge cancels it, and every other
traversal appends an edge. The tree records different turns around the
same geometric cycle as distinct lifted edges.

The lifted image is compact. The cover is locally finite, and every edge
length is one of finitely many positive lengths. Hence a compact lifted
image meets only finitely many edges and lies in a finite subtree. This
cannot conceal an infinite decreasing-edge-length path. A direct finite
cell bound below gives a second finiteness argument.

On an original nonconstant face, preimages of target vertices are parallel
affine level lines. They cut the face into finitely many convex polygonal
strips. Each strip's interior maps into a single open target edge, so its
connected lift maps into ONE open covering edge. No further cut is needed
merely because another strip maps to another lift of the same geometric
edge. On a strip, the inverse covering coordinate is affine, so the
lifted scalar edge coordinate is genuinely P1 there. Constant triangles
have zero gradient and are retained as actual constant cells.

These observations address proper crossings, collinear overlap,
nonplanar target graphs, repeated target edges, high-valence vertices,
and constant faces. They use simple connectivity of the SOURCE disk;
the proof does not automatically extend to a domain with holes.

## 2. The affine boundary supplies exactly one distinguished lifted path

If (A\ne0) has rank one, the affine image of the source closure is an
interval (K). Its scalar extrema occur on the polygonal boundary. The
boundary is connected and contains both extrema, so its affine image is
the WHOLE interval (K), even when the source disk is nonconvex.
Thus (K) is contained in the actual target graph.

The inverse image of an embedded interval under a graph covering consists
of disjoint interval copies. The connected lifted boundary lies in one
copy, and covers all of it. Call this lifted path (P). All its output
edge directions lie in the one line (operatorname{range}A).

If (A=0), the boundary image is one graph vertex and its continuous lift
is one vertex: the covering fiber is discrete and the boundary connected.
This supplies (P) in the zero-trace case. There is no hidden boundary
winding in either case. Other interior copies of the same geometric
interval can occur outside (P), and the proof correctly keeps them
separate.

## 3. The zero packets and substitution preserve the physical measure

For a lifted edge (e\notin P), its removal separates the tree into a
component containing (P) and an opposite component. The cut potential
(	heta_e) is zero on the former, one on the latter, and affine from
zero to one along the edge. Its pullback (phi_e) is continuous P1 on
the finite cell partition and vanishes on the entire outer boundary.

With the edge oriented from (a) near (P) toward (b) away from it,
on cells carried by that lifted edge one has

\[
 Dv=(q(b)-q(a))\otimes D\phi_e.
\]

On all other positive-area cells (D\phi_e=0). Interface contributions
cancel in the piecewise integration by parts, yielding

\[
 \sum_{C\text{ carried by }e}|C|Dv|_C
 =(q(b)-q(a))\otimes\int_\Omega D\phi_e=0.
\]

Every gradient in this packet has output range in the same edge line.
Consequently every difference of its weighted subtree means has rank at
most one. Arbitrary positive binary averaging compiles it at mean zero.
The actual weights are its physical CELL areas, not a fresh choice of
weights. Summing cell areas within a face exactly recovers the original
physical face area.

Every cell carried by (P) has output range in (operatorname{range}A).
After provisionally replacing off-(P) packets by their zero means, all
remaining matrices lie in that common output line. They therefore admit
a binary averaging tree rooted at the actual mean (A). Inserting each
off-(P) packet's tree at its matching zero terminal occurrence preserves
both its mass and its matrix. All ancestors retain their original means
and rank-one jumps. No unrelated mean quotient is being assumed positive:
the OUTER common-line tree is proved explicitly before substitution.
Thus the earlier matching/full-star quotient counterexamples do not
invalidate this operation.

This proves the exact finite physical-law theorem for all finite output
dimensions. Intermediate matrices are convex combinations of original
face gradients, hence inherit their maximum norm bound. Neither auxiliary
positive terminal atoms nor a limiting order is used.

## 4. Audit-derived uniform mesh-size bound

Let the source have (N) vertices and (F) triangles. All initial target
vertices are source nodal values, so there are at most (N). At most
(F) nonconstant triangle-image segments occur. A noncollinear pair adds
at most one proper intersection; a collinear overlap adds only original
endpoints. Hence

\[
 V(\Gamma)\le N+\binom F2.
\]

A nonconstant triangle is cut into at most (V-1) strips, and a constant
triangle contributes one cell. The preceding compiler therefore needs
at most

\[
 \boxed{F\max\{1,N+\binom F2-1\}}
\]

positive physical occurrences. The lift adds no cells, by connectedness
of each affine strip. For N9/F13 this gives the coarse UNIFORM bound
1118 in the singular descended case. This does not assert twenty-two
there or optimality. W26 separately checked this counting argument; it
is recorded here as an audit-derived corollary, leaving the frozen source
proof unchanged.

## 5. Singular descended defects reduce correctly

The cofactor is the Frobenius derivative of determinant:
(operatorname{cof}D=((D_{22},-D_{21}),(-D_{12},D_{11}))).
For singular (D), let (B=\operatorname{cof}D). Then
(operatorname{cof}B=D), (det B=0), and

\[
 \det(Du-B)=\det Du-D:Du+\det B=0.
\]

The actual map (v=u-Bx) has rank-one gradients and affine boundary
trace (-Bx), of rank at most one. Apply Sections 1--3 and translate its
entire matrix tree by (B). Every jump and physical leaf mass is
unchanged. This includes (D=0) and rank-deficient output maps.

## 6. The nonsingular classification is exhaustive

For invertible (B=\operatorname{cof}D), put (z=B^{-1}u) and
(Y(x)=x-z(x)). On every original face, (det DY=1), and (Y) fixes
the exterior vertices. Thus all thirteen SIGNED source face areas are
preserved. The algebra below does not need to assume global injectivity
of (Y); even if that ancillary re-embedding assertion were omitted,
the signed equations alone establish the classification.

Opposite equal areas around vertex 7 put (M=(Y_3+Y_6)/2) on both lines
(Y_2Y_7) and (Y_7Y_8). Both lines exist because the relevant areas
are nonzero. If they differ, (M=Y_7). Otherwise (Y_2,Y_7,Y_8) are
collinear. There is no third case.

In the collinear case, (Y_8\ne Y_2), since otherwise areas 378 and 237
would agree instead of being (-2) and (4). The area ratio forces
(Y_7=(Y_2+2Y_8)/3). The SOURCE coordinates have the same relation, so
(z_7=2z_8/3). Original face pairs 237/378 and 267/678 therefore have
identical gradients. They merge into admitted source triangles 238 and
268. Vertex 7 disappears, leaving five interior vertices and eleven
physical faces. The previously independently audited all-geometry,
all-output five-interior theorem applies. Two rank-zero identical-
gradient splits restore the original masses. This gives thirteen
occurrences without losing a source face.

In the midpoint case, the three exterior face equations give

\[
 Y_3=(2,a),\quad Y_4=(b,2),\quad Y_6=(4-t,4+t),\quad ab=16.
\]

Area 237 gives ((t-4)a=8t-20). The case (t=4) is impossible
((0=12)); (2t-5=0) would force (a=0), also impossible. The linear
system for (Y_5) has determinant (-4d/(2t-5)),
(d=3t^2+4t-19). Its DIVISION-FREE Cramer identity implies (t=-6)
if (d=0), but (d(-6)=65); thus that branch is impossible. The system
for (Y_8) has determinant (-6v/(2t-5)),
(v=(t-1)^2+1>0), so there is no further denominator exception.

The resulting rational formulas are therefore necessary for EVERY
midpoint solution. Eleven face equations hold formally; the two
remaining errors are (pm2f/((t-4)vd)), where

\[
 f=57t^5-102t^4-167t^3+324t^2+105t-262.
\]

Hence all midpoint solutions are roots of this one quintic. No algebraic
component or infinity parameter is discarded: finite (Y_6) defines the
finite real parameter (t) directly, and every possible zero denominator
has been excluded before division.

An independently implemented Sturm chain, with degrees 5,4,3,2,1,0,
proves exactly THREE real roots and exactly one in each supplied rational
isolation interval. This differs from the producer's Descartes/Bernstein
root-count route. The three actual trees have respectively 20,22,20
positive physical leaves, checked independently below. Left multiplication
by the original invertible (B) restores the requested field and
preserves all rank-one jumps and masses.

## 7. The 'every surviving projection' quantifier is justified

`support_span.py` independently reconstructs the thirteen canonical
six-output hat gradients. Their twelve affine differences have exact
rank twelve. All twelve mean entries and all fifteen minor moments
vanish with the actual physical weights. A rank-two (2\times6) matrix
(C) maps this affine hull surjectively onto all (2\times2) matrices,
so its projected atoms affinely span dimension four.

Every globally rank-one-affine function on (2\times2) matrices has form
(c+L:G+\alpha\det G). An elementary verification uses affinity in
each entry, then in each row and column, which leaves only the two
opposite-corner quadratic monomials; the all-ones rank-one direction
forces them to have opposite coefficients. Zero mean and zero determinant
moment force (c=0) for a function vanishing on the physical support.
If (alpha=0), affine spanning forces (L=0). Thus every NONZERO such
constraint normalizes to (det G=D:G), with a unique (D). Singular
and nonsingular (D) are both covered above. If (C) has rank below two,
its common output range supplies a direct tree. This proves the claimed
restricted-locus quantifier without projecting a higher-output separator.

## 8. Independent implementations and primary sources

Neither new main replay imports any producer numerical module.

`independent_graph_lift.py` constructs a fresh four-output physical disk
with NONZERO affine boundary trace. Its target has three independent
cycles, proper crossings, collinear overlaps, repeated paths and branches.
The code independently constructs all segment intersections and target
edges, propagates reduced edge-word lifts on the source mesh, and cuts
physical triangles by an exact scalar-triangle area CDF. N37/F69 yields
80 physical cell occurrences and 79 binary jumps, with nine source faces
split. Every off-boundary packet has exact zero mean. All six output-row
minor pairs at every jump and all original physical mass marginals pass.
These are adversarial bookkeeping checks; the universal proof is in
Sections 1--3, not an inference from this single fixture.

`independent_nonsingular.py` uses unreduced rational functions to verify
the area identities BEFORE quotient reduction. Its independent Sturm
count exhausts all real branches. It reconstructs actual gradients from
the coordinates (X-Y), rather than using the producer's projected hat
implementation. Every supplied tree is checked using polynomial MOMENT
matrices: the rank-one jump test is
(det(M_Lw_R-M_Rw_L)=0), avoiding division by node means. All leaf
masses are positive at the chosen isolated root; full marginals and
root zero are exact. All thirteen terminal gradients are distinct and
have norm below ten at each root. Convexity gives the same bound for
intermediate states. Replays took about 0.05 and 0.19 seconds on this
host; total discovery/review/retrieval costs are not those timings.

Classical covering facts were checked in the author's primary text,
[Hatcher, *Algebraic Topology*, Proposition 1.33, pp.61--62 and the
compact-graph argument pp.83--84](https://pi.math.cornell.edu/~hatcher/AT/AT..pdf).
The local raw PDF SHA256 is
`b920b664909a1b01565599cac086aa14d62aae99951994f7192eb7d5bad8f458`.
The broader metric-tree factorization context was checked directly in
[Esmayli--Hajlasz, arXiv:2106.15763v2, Theorems 1.1/1.9]
(https://arxiv.org/html/2106.15763v2). That source concerns a broader
Lipschitz setting; it is not substituted for the exact finite physical-
cell proof here. Its retained HTML SHA256 is
`22e054a1e195b3f908fa79b6bcbcde75e7978f9fc673b36271655849a059f658`.
The web PDF search endpoint failed to locate Hatcher's text; direct PDF
retrieval and local pypdf extraction succeeded. The source shows this
topological factorization context substantially predates the present
finite-law argument. No historical priority clearance is claimed.

## Limits and next target

The proof uses actual P1 realization and affine outer trace, not merely
an abstract determinant-balanced atomic law. Its singular all-geometry
conclusion and nonsingular fixed-N9 conclusion must remain distinct.
The exact minimum fifteen retained point, the different generic lower
fifteen box, and W29's still-provisional two-mass lower sixteen are
separate results. The present audit does not adopt that provisional
lower sixteen. Arbitrary six-free-vector N9 m2 lamination and general
Morrey remain open in this programme.
