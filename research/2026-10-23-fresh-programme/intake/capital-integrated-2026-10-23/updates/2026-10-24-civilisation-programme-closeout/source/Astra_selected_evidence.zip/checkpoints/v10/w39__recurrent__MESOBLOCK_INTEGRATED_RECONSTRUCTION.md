# Co-informed reconstruction of the finite mesoblock code binding

W39, 24 October 2026. Target: W67 `NATIVE_AND_RECEIVER_BINDING_CANDIDATE.md`,
SHA256 `d8142311944b94c8b5a6e0773a9201d05d704d38810fee95120e1040c318a871`,
together with the separate initializer qualification
`736cebd649960d1d295a45a2352d1aed0c04af3105956502e05e8a3a23155605`.
All source, old V4, router and earlier scoped-review bytes are preserved.

This is a new integrated reconstruction after reading the producer's
proofs, finite policy and code text. It is **co-informed**, not a cold
independent invention or a fresh proof of every inherited source lemma.
The new counter implementation imports/runs no producer or peer module.
The earlier W39 access review cf90 and W49 ideal review df4eb8 supply
identified premises; their positive verdicts alone are not the argument
for the integration below.

Verdict: **no load-bearing obstruction found in this conditional finite
construction, with the initializer qualification and public-program model
stated below**. This is a constructive polynomial existence/cost result
in the supplied local digital model. No giant encoder, probability table,
phase list, successful seed or physical apparatus has been acquired.

## A. Exact contract and imported source

The supplied known parameter is a rational b=beta^2, with beta<=1/128,
k=floor(1/(5b)) and its bit length L_b charged. The exact recurrent
interaction family, actual root and two static sectors are supplied;
there is no calibration experiment or reverse access to the real bath.
The local universal-gate model permits the explicit finite word simulator
and its controlled stored inverse. It does not grant an arbitrary
unknown unitary's control or inverse.

The inherited analytic V4 source is rho=sigma T J B J, where

    sigma=diag(1/2,1/4,1/4)^tensor k,
    B=(I-(4/25)bH)_+, D=P_complete-pattern(B)>=I,
    J=D^(-1/2), rho=sigma Mrel, Mrel=TJBJ.

All actual factors commute with total charge Q and with sigma,T.
B and D need not commute. The complete-pattern pinching retains color
fibers; it is not a color trace or just total-charge pinching. Import
the frozen V4 entropy, chi-squared and full bulk drift theorem b37eccac:

    S(rho)>=3k/2+t0/31,
    D_b(rho)<=-t0/480 I in the actual bulk,
    Tr sigma(Mrel-I)^2<1/6400, 1/300<=t0<=1/200.

The reference sigma has zero bulk drift. Therefore regularization

    rho_*=(rho+sigma)/2=sigma M_*, M_*=(I+Mrel)/2

has M_*>=I/2, entropy surplus G=1/18600, inward drift
Kappa=1/288000 and Tr sigma(M_*-I)^2<=c=1/25600. These are imported
operator theorems for the supplied interaction, not observations from
the three new rows. In particular they hold on arbitrary bulk word/color
coherences, rather than only a measured radial chain.

The compiler is allowed **quantum offline preprocessing with classical
output**: known local source circuits generate a source-probability table.
The table, random seeds, public prefix and circuit descriptions are fixed
and shared before an unknown message is encoded. Their generation,
storage and emission cost are charged. Distribution through the same
physical forward device is not proved in this packet. A purely classical
compiler, deterministic good-seed certification and unknown-b construction
are not consequences of this review.

For a numerical finite error guarantee, the initializer is independent
of the message as in the inherited model and has a supplied tail promise.
The three rows use Tr P_(L>A)tau<=2^-A. General supplied A is covered
only with polynomial dependence on A. Arbitrary normal initializers have
pointwise asymptotic scope, not a uniform finite tail modulus.

## B. The relative functional access used inside the encoder

Take M_B=1+(4/25)b k(k-1), T_max<=2. The source factory's positive
finite instrument acquires B_e with ||B_e-B||<=d<=1/4 and
D_e=P_complete-pattern(B_e)>=3I/4. Its fresh middle signal test is
essential to the Gram product. It gives a known acquired normalization,
including the inverse-root scale. W39 cf90 gives

    ||M_*,e-M_*||<=2 T_max M_B d,
    ||sum log M_*,e - sum log M_*||<=4t T_max M_B d.       (B1)

The logarithm inequality follows from its positive resolvent integral
on eigenvalues >=1/2. It makes no commutativity assumption between exact
and approximate operators. A generic trace-close density would not imply
B1 after division by the exponentially small sigma. That substitution
is not made.

The acquired block normalization is alpha_*=(1+8T_max M_B)/2. A bounded
log-polynomial uses alpha_*|x| in its scalar argument, not the smaller
operator norm bound. Illegal physical labels get the explicit extension
Mrel=0, M_*=I/2, so no log zero is introduced. Established polynomial
approximation/LCU/QSVT and stable phase generation give paid uniform
log access at inverse-polynomial accuracy. A coefficient-LCU alternative
must propagate its acquired coefficient sum. No source eigenbasis,
Gram entries, inverse sigma or free function query is assumed.

For L=sum log M_* and the retained bins |j|<=w, set

    a0=ceil log2(1+2M_B),
    xmin=-max(t,w)-2, xmax=max(t a0,w)+2,
    Rdom=xmax-xmin.

This contains the full spectrum, with spare room at both phase seams.
The smooth retained-bin vector includes a reject amplitude and is globally
periodic Lipschitz with constant <2. The bounded filter

    a_j(x)=exp((x-j-1)/2) cos(pi(x-j)/2), |x-j|<=1,
           0 otherwise

has amplitude <=4/5; its full success/reject coin vector is Lipschitz
with constant <=5. The exponential is evaluated only on this support,
not prepared with an enormous scale and cancelled informally.

For a T_PE-point phase estimator, circular distances d_y obey
sum p_y d_y^2<=1/(4T_PE). Prepare the coin/bin vector coherently and
uncompute the **whole** phase estimator. Its full isometry error is at
most 5Rdom/(2sqrt(T_PE)), including its nonzero phase-helper leakage.
This is stronger input than a signal-block approximation. For a perturbed
Hermitian L_e, Duhamel, not scalar operator-Lipschitz reasoning, gives
||exp(iuL_e)-exp(iuL)||<=|u| ||L_e-L||. The forward/inverse estimator's
total simulation time is <4pi T_PE/Rdom.

The target's rational policy

    T_PE=nextpow2 ceil[(40Rdom/xi_A)^2],
    delta_L=xi_A Rdom/(1024 T_PE),
    delta_B<=delta_L/(16t M_B),
    each log approximation <=delta_L/(2t)                (B2)

therefore pays the exact-source functional error. B1 contributes at
most delta_L/2, and the t log approximations contribute the other half.
The intrinsic estimator error is <=xi_A/16 and the Duhamel error is
<xi_A/64. Finite arithmetic, native gates and simulator helper errors
fit the remaining fixed subbudgets. Controlled simulations retain their
physical phase and stored inverses. In particular the controlled robust
OAA minus sign cannot be discarded.

This defines P_access as the sum of concrete constructors, including
source operator acquisition, functions, Hamiltonian simulation,
normalizations, bit arithmetic, native gate synthesis, descriptions and
resets at B2. Its precision dependence is paid. The old quadratic-scan
skipped-word access suffices for polynomiality. The newer oblivious
router, Chebyshev accelerator and sharper source-moment addendum are not
needed and receive no new verdict here.

## C. Exact bounded table and cell geometry

For a mesoblock of t source blocks, E_rho_*^t exp(L)<=(1+c)^t and
E_rho_*^t exp(-L)=1. With w=ceil(2ct)+1, omitting bins outside |j|<=w
costs at most 2e exp(-ct). The guard ct>=B0+4 makes this <eps/2 for
eps=2^-B0. It does not assert an O(t) operator norm for L.

There are Bcells=(kt+1)(2w+1) charge/bin cells. Set

    B0=ceil log2[2^30 k^6/(G Kappa)],
    Bp=ceil log2(128Bcells/eps), pmin=2^-Bp,
    Bmu=Bp+2w+3.

Acquire each ideal probability p_i to additive a=eps pmin/128.
Source-preparation and full-instrument bias can each receive a/8; the
remaining sampling error has ample slack at the stated
8 a^-2 ln(2Bcells/eta_table) trial envelope. A single multinomial run
estimates all cells; union-bound confidence is charged once for the
table. Every trial prepares t local source blocks and runs the full
charge/bin instrument. These are paid proposed quantum experiments,
not a classical density-matrix computation or an executed acquisition.

Keep hat p_i>=8pmin. On the confidence event, kept p_i>=7pmin and dropped
p_i<=9pmin, so dropped mass <=9Bcells pmin<=9eps/128. Combined with
bin omission this leaves retained mass P>=1-eps. For kept cells,
|hat p_i/p_i-1|<=eps/896. Normalizing the estimates introduces at most
the corresponding relative denominator error. Round this normalized
law down on a grid with step <=eps pmin/(128Bcells), and assign the
residual to a retained cell. Residual mass <=eps pmin/128 changes that
cell's normalized probability by relative at most eps/896. With the
displayed slack, the exact finite fair-bit law obeys

    w_i <= (1+eps) p_i/P.                                (C1)

For charge q, N_q=binom(kt,q)2^q, D_q=nextpow2 N_q and
sigma_q=2^(-kt-q). The padded map E_q is a partial isometry on valid
labels, zero on invalid labels. It is implemented by total reversible
rank/unrank with explicit validity flags, not treated as a full isometry
on too many labels. The physical positive filter A_i has

    mu_i=Tr A_i^2/D_q,
    p_i=sigma_q exp(j+1)D_q mu_i,
    mu_i>=2^-Bmu.                                        (C2)

C2 uses sigma_q D_q<=2, |j|<=w and e<4. Charge enumeration uses integers
of O(kt) bits. A finite interval of width <=1/4 for log2 mu_i suffices
to choose the dyadic K_i conservatively; no exact floor of an unknown
transcendental is called. Its bounds are

    K_i/D_q<=2^-20 eps^2 mu_i,
    ell_i=log2 K_i>=log2(D_q mu_i)-2B0-24,
    ell_i>=kt-Bp-2(w+1)-2B0-24.                           (C3)

The last two quantities are checked before any dimension feasibility is
inferred. The gap and inverse fraction mu_i^-1 are paid numerical costs,
not merely Bmu-bit precision costs.

## D. Relative frame concentration, width and the parent ensemble

I reconstructed the load-bearing identities of W49 df4eb8. For a positive
contraction A^2 with normalized trace mu, C0=A^2-mu I has
Tr C0^2<=mu D. Its Gaussian exponential moment is bounded by
exp(z^2 mu D) for |z|<=1/2. After the Gaussian norm denominator and a
quarter-net, integrate the Haar tail **before** changing to a design.
For h<=K the resulting 2h-th trace moment has principal term

    K[16sqrt(mu(v0+h)/D)+16(v0+2h)/D]^(2h),
    v0=2K ln9+ln2,

plus K exp(2K ln9-c0 D), c0=ln2-1/2. Under C3 the bracket is
<eps mu/16. The cyclic-trace input has trace norm K^(2h), so a diamond
moment error delta_des contributes delta_des K^(2h), with no extra
D^(2h) factor. Markov and the explicitly checked finite denominator,
h<=K and delta_des guards give relative Gram failure <=eta_f.
No exponential net is transferred to a low-order design.

The ideal finite Pauli design at order 2h uses exact dyadic-angle moment
sampling, and an independent left Pauli gives exact first frame moment
K I/D. Its design mixing/seed bounds are supplied by the primary
[Haah--Liu--Tan theorem and Appendix A](https://arxiv.org/html/2402.05239v1).
Their mixing theorem is an imported primary result, not independently
proved here. Native synthesis is an operational approximation to each
finite ideal seed after the good-event argument; it is not asserted to
preserve tiny moment error at native precision. The source/access and
outer telescopes explicitly price that operational error.

On Good, G_i=V_i^* A_i^2 V_i>=(1-eps)mu_i I, and

    C_i=E_q A_i V_i G_i^(-1/2)

is a pure charge-q isometry. In the PSD inequality for C_i C_i^*/K_i,
drop 1_Good only on the positive right-hand side and use the exact
first moment. The UNCONDITIONED expectation is

    E[1_Good C_i C_i^*/K_i]
       <=rho_*^t P_q f_j(L)^2/[(1-eps)p_i].               (D1)

Sampling with C1 cancels p_i. There is no division by each frame's
good probability. That fact is necessary for the final log domination
cost and is preserved in this integration.

The information bound 0<=-log2 rho_*^t<=(2k+1)t controls discarded
mass. The width average from C3 loses at most
eps(2k+1)t+log2 Bcells+2B0+24+2log2 e-log2 P, and changing to C1
loses at most 2eps kt. Guards

    ceil log2 Bcells+2B0+32<=tG/8,
    eps(4k+1)<=G/16

leave mean width >=t(3k/2+3G/4). Here the law is the final estimated
dyadic table, not the unattained exact p_i law. Widths lie in [0,2kt].
Hoeffding and s>=128 k^2 G^-2 ln(1/eta_w) make failure to reach
ell_parent=floor st(3k/2+G/2) at most eta_w.

Only TWO independent width sequences are tried. Failure is <=eta_w^2;
the first accepted sequence has exactly the original law conditioned
on acceptance. The factor 1/(1-eta_w) therefore suffices. No unbounded
rejection loop or conditional frame-failure denominator is hidden:
frames are sampled after width selection, and each cell's frame bound
is uniform. Their total failure is <=s eta_f.

For an accepted sequence, a fixed random PUBLIC prefix z of
sum ell_i-ell_parent bits embeds a common arbitrary-reference logical
domain. On all Good, the product gives a pure parent C with a known
full extension and definite total physical charge. Averaging that fixed
prefix in the proof, then the independent cells/frames, yields exactly

    E_program[1_allGood C(I/D_parent)C^*]
       <=F rho_*^(st), ln F<=5eps s+2eta_w.                (D2)

The indicator is retained. Bad programs are total finite CPTP operations
or an explicit compiler-failure flag before message insertion, not an
unknown-message postselection scheme. No hidden mixed runtime gauge is
needed for D2.

## E. Both complete-unitary comparisons and squared precision

For a known unitary U, input embedding R and target isometry C, the
cf90 completion lemma states

    ||UR-C||<=e<=1/4 => exists U0:
    U0R=C, ||U-U0||<=9e.                                 (E1)

It first rotates the close range projectors, then corrects the frame
within the range. The second correction retains global phase; equal
range projectors alone do not align e^(i theta)C with C. U0 is an
existential comparison object. The implemented circuit is always the
known finite U, and neither U0's matrix nor an ideal spectral oracle is
computed or called. Once fixed, the same U0 compares U^*, controls and
range reflections globally, including dirty helper inputs.

FIRST apply E1 to each full filter/bin coin from B2. The whole functional
unitary is within 9xi_A of one consistent exact completion with good
block A_i. This permits the polar circuit to use the stored inverse
without assuming its helpers remain initially zero on every actual
branch. Comparison is to one fixed completion throughout the circuit.

On Good, s_min(A_i V_i R_K)>=sqrt[(1-eps)mu_i]. Define

    Bgap=ceil[(Bmu+2)/2], g=2^-Bgap,
    BDelta=ceil log2(1/Delta), Bsig=2BDelta+32,
    delta_sig=2^-Bsig.

Choose the SMALLEST ODD degree at least 8g^-2(Bsig+2) for the bounded
majority polynomial, scale strictly inside the unit ball, and perform
parity-preserving finite coefficient rounding. Hoeffding gives more
than sufficient sign error <=delta_sig above g. This concrete smallest
degree choice makes the stated upper bound literal:

    Qinner<=2^(2Bgap)64(Bsig+1).                           (E2)

The ordinary projected-unitary/paired-walk construction and its input/
output flags determine the correct polar orientation. It uses no
square-root walk oracle. The primary
[Gilyen--Su--Low--Wiebe construction](https://arxiv.org/pdf/1806.01838)
gives the singular-vector circuit; the separately bound degree-to-query
argument supplies the conservative 4degree+4 count used in E2. The
polynomial coefficients and stable phases are constructible finite data.
[Haah's stable product decomposition](https://arxiv.org/pdf/1806.10236)
charges O(Qinner^3 polylog(Qinner/delta_sig)) classical work, including
its larger intermediate bit lengths. This is established machinery.

With xi_A<=delta_sig/(4096 max(1,Qinner)), all functional substitutions
after the first completion contribute <=9delta_sig/4096. Designs, phase
factors, projectors, helper arithmetic and native gates receive comparable
aggregate subbudgets. A conservative final good-block error is
<=4delta_sig. For a contraction block approximating an isometry,

    full isometry error^2 <=2*(good-block error).

Thus the final circuit is within sqrt(8delta_sig) on its input embedding.
SECOND apply E1 to this completed polar encoder: its full native unitary
is globally within 9sqrt(8delta_sig)<Delta of a single exact completion
of the desired charge-q C_i. The Bsig policy ensures
648delta_sig<Delta^2, explicitly checked in the new raw receipt.
A block error merely of order Delta would not justify this conclusion.

Product child circuits telescope to a parent completion. Choose
Delta_parent=z/(4096 I), Delta_inner=Delta_parent/(8s).
The s child comparisons cost <=Delta_parent/8, leaving ample prefix/
rank/control work. The actual physical sender may apply a CPTP legality
and charge conversion fixing the exact C. Contractivity preserves the
sender comparison on arbitrary references. Receiver simulation uses the
preconversion known full unitary and its stored inverse. It never inverts
that CPTP conversion or an inaccessible physical bath operation.

## F. Actual-root tail, emission, finite digital row and receiver

Only the conservative bounded k-call step is used here. The optional
new O(k) second moment is not imported. Since the source commutes with
total charge, the dual exp(t_L Ldepth) operator has no cross-depth terms.
Full bulk drift and the k-bounded step yield, for t_L=Kappa/(8k^2),

    Phi^* exp(t_L Ldepth)
       <=(1-Kappa t_L/2)exp(t_L Ldepth)
                         +exp(2kt_L)P_(Ldepth<k).

The low-depth ROOT TERM remains. Iterating the actual bath channel from
vacuum gives source tail <=(1+Ctail)exp(-t_L H),
Ctail=6/(Kappa t_L). This uses product source INPUT blocks, not an iid
or measured bath. D2 transfers this tail to the good-program ensemble.

The finite choice

    H=ceil[(5eps s+2eta_w+ceil log2(1+Ctail)+Bq
                         +ceil log2(1/eta_parent)+4)/t_L]

gives each sector ensemble overflow <=q eta_parent/16, q=2^-Bq.
Markov at q and a union over the TWO sectors therefore fit well inside
eta_parent. On the resulting parent good event, each sector's mean
body overflow is <=q. Count the actual terminal zero flush

    nflush=16(H+Bq+4).

For depth<=H, a=1-b>=1/2 and the exact zero-port absorbing-root descent
has failure <=exp(-nflush/16)<=q/16<q. Its vacuum effect is diagonal
in length and uniform in colors. Thus final mean word deficit <=2q;
all terminal OUTPUTS are retained by the decoder.

Let nbody=kst, T=nbody+nflush and choose power-of-two R>=16nbody.
The explicit guard nflush<=nbody ensures T<=2nbody and the actual
two-sector Fourier row count 2(2T+1)<=R. The digital simulator has a
stack at least T cells with explicit unitary root/top completions. The
vacuum-start T-call physical trajectory never needs a larger stack.
No real bath access or reversal is required.

The exact local word family is Laurent degree T in the known digital
angle. Its J=2T+1 Fourier samples define contractions E_i. The fixed
source encoder is held CONSTANT across those digital angle samples.
It is designed at the supplied actual b; no unknown-gain source transfer
is being inferred. Actual coefficient norm squared is J<=R, not 1.
Padded zero rows are realized by reversible reject flags. The explicit
rectangular row block is F/sqrt(R).

The independently selected outer design gives the simultaneous full
operator cross-KL bound

    ||F^*F-G tensor I||<=omega=128R sqrt(q).

Its coefficient contraction gives code word deficit u<=2q+Romega and
polar comparison error sqrt(Romega), with no logical-dimension factor.
G appears in the mathematical proof only; the circuit acquires none of
its entries or eigenvectors. The cutoff nu=z^2/(2^16R) discards at most
2sqrt(Rnu) in the actual synthesis norm. The high singular gap of the
normalized row is z/(256R). A complete unitary polar transform followed
by ordinary discards defines a CPTP receiver on every input, including
all low-singular, bad-word and helper branches.

The newly checked guards imply sqrt(Romega)<=z/256,
sqrt(2q+Romega)<=z/256, 2sqrt(Rnu)=z/128. With xi=z/128, the inherited
full-reference deterministic bound is

    4[sqrt(Romega)+2sqrt(Rnu)+xi+sqrt(2q+Romega)]
       <=3z/32.                                         (F1)

The two-sector span and root orthogonality include preserved sector/
reference coherences. This is not an unentangled-input or Bell-only
fidelity inference.

## G. Repeated full encoders, error, confidence and forward rate

Write a row branch as B_i D_enc where D_enc is the ENTIRE parent and
outer-frame unitary. The literal identity

    SELECT_i(B_i D_enc)=SELECT_i(B_i)(I tensor D_enc)

holds on every Hilbert-space input, including padded reject rows. The
inverse reverses that order and the controlled identity retains phases.
Consequently each row query uses the whole encoder once; including the
sender gives I=Qouter+1. This elementary factoring is available equally
to a matched baseline. It does not reduce the number of inner filter/
frame/polar operations inside one encoder.

The outer bounded-sign degree n and Qouter=4n+4 are recalculated at the
actual new R and cutoff. All I repeated calls contain s child encoders,
and every child contains up to Qinner full function/design/rank calls.
No old quartic m^5 or other whole-code exponent is imported. Global
completion comparisons justify an operator telescope across the whole
receiver, even when helpers are dirty. Conservatively using channel
distance 2I Delta_parent costs z/2048. Other outer digital/Fourier/sign/
phase/native work receives <=z/4. With initial term <=z/32, total

    3z/32+z/32+z/4+z/2048=769z/2048<z.                   (G1)

This bound intentionally does not use the extra factor-eight child
slack to improve the final number.

Condition on a good probability table. A safe total program failure is

    eta_table+eta_w^2+s eta_f+eta_parent+eta_outer<eta.       (G2)

It includes width failure, bad frames, both sector Markov events and the
outer Hermitian cross-product union. These events need not be independent
for the union bound. Quantum/statistical table confidence is once per
table. A fixed seed is not certified good by this argument.

ALL actual forward calls are

    N=ninitial+nbody+nflush.

Digital decoder calls and local table source preparations are additional
local resources, not physical transmissions. For the three rows,
A=Bq+8 and ninitial=16(A+Bq+4). The geometric initializer supplies
q_A<=q/256, and its coherent prefix error 4sqrt(q_A+nu_prefix)<=z/32 is
checked by squaring rational inequalities. There are no omitted physical
calibration, sector-probe or interprobe ports in this known-b protocol.
None are invoked; initial and terminal zeros are explicitly charged.

The finite rate guard is

    ell_code=ell_parent-Bq >=[3/2+G/(16k)]N.

Since k<=1/(5b), this is at least 3/2+b/59520. It is a sufficient
positive coefficient for this regularized-source protocol, not the exact
small-beta capacity coefficient. General source coding can potentially
use more of the inherited entropy margin; no optimality is claimed.

The flush's linear-in-s slope is <=640eps k^2/Kappa. The available
parent entropy margin has slope tG/2. The eps=O(k^-6) choice makes the
former's rate cost strictly smaller than that margin; remaining terms
grow logarithmically in s. Exact doubling therefore reaches the rate
and flush guards at a polynomial stopping value. All finite moment,
denominator and h<=K checks are still tested, not inferred just from
the large dimension. For extreme eta, increasing t until those guards
hold costs t=O(log k+log log(s/eta)), retaining polynomial parameters.

## H. Initializer qualification and asymptotic quantifiers

The d814 opening polynomial-onset statement must be read with frozen
736cebd. With geometric tails the displayed finite polynomial in
(k,z^-1,eta^-1,L_b) applies. For a general supplied A with
Tr P_(L>A)tau<=epsilon_init=z^2/2^16, use

    ninitial=16[A+ceil log2(1/epsilon_init)+4].

Then 4sqrt(q_A+nu_prefix)<=4sqrt(2epsilon_init)<z/32. Reapply the rate
doubling with this actual prefix cost. Complexity is polynomial in the
EXPLICIT A as well. No claim A is polynomial in z^-1, or that it was
physically learned, follows.

For arbitrary normal tau, one may instead use an initializer-independent
cutoff sequence A_N increasing to infinity, for example the original
Bq+8 policy with increasing horizons. The actual prefix contribution
4sqrt(Tr P_(L>A_N)tau+nu_prefix,N) tends to zero for each fixed normal
tau. Other error/confidence targets can be decreased and all guards
resolved anew. Good program events are independent of tau, so a good
program sequence has this pointwise statement for every fixed normal
initializer without an uncountable union argument. A summable failure
schedule even permits the usual almost-sure eventually-good sequence
interpretation; it does not identify a deterministic certified sequence.
There is no uniform finite normal-state modulus or uniform finite
polynomial error onset without an additional tail input.

## I. Cost scope, actual receipts and falsification boundary

With P_access as the explicitly expanded B2 constituent algorithms,

    Ginner <= Qinner[Gdesign+Gcharge+P_access
                                +poly(kt,Bsig,log(1/Delta_inner))],
    Gquantum <= I s Ginner+I Gouterdesign
                         +Qouter Gdigitalrow(T)+poly(Qouter,kt,s,log(1/z)).

The conservative digital SELECT can still charge R branches and a
polynomial word simulator per row. That cost was not reduced by factoring
the encoder. Classical work separately includes both stable phase
constructors, source/function coefficients, intermediate arithmetic,
table processing, all program randomness and writing the complete
program. Table experiments cost the displayed sample number TIMES t
source preparations and their local instruments/resets. Output bits,
measurement resets, reading/emission and storage are resources.

For fixed G,Kappa,c, Bmu=O(log k+log log(s/eta)); its numerical inverse
fraction and the N1/N3 accuracies therefore remain fixed polynomials in
the named numerical inputs. This is not polynomial in log k alone.
The exponent and constants may be enormous. P_access cannot be replaced
by a unit-cost function oracle or by Qinner's bit length.

The new checker reconstructs all 180 top-level raw row fields exactly,
including nested trial/guard/query values, from independent integer/
Fraction code. It imports no producer or peer module; it was written
after their text was read, so its provenance is co-informed. It additionally
checks actual Fourier row count, both source-error terms, squared block
precision, literal majority query count, final error/confidence and
required access precision. No floating point is used.

Required full function-isometry accuracy bits are 11201,11270,21828;
T_PE powers are 22471,22609,43728 for beta=1/128,1/512,1/2048. The
corresponding B-operator accuracy bits are 33690,33900,65580. These are
precision obligations, not achieved apparatus accuracy or full native
gate counts. The independently matched total forward calls are

    2027745784349686312784312598608,
    8307548208595766840594898275993936,
    68056408480476979321468946994890740496.

The rows' Qinner and phase logarithms are only partial primitive proxies.
No whole probability table, design seed, giant coefficient array, native
encoder/receiver or physical experiment at these horizons was executed.
Small earlier access diagnostics do not change that limitation.

The result would fail if any of the following premises were replaced:
trace-close source for uniform relative access; low-order design for the
transferred 2h moment; unbounded width rejection; conditioned-on-Good
normalization at every frame; linear block tolerance without leakage;
zero-helper inverse access without the two consistent completions;
source-only counts in place of I*s repeated nested calls; or a universal
normal-state finite tail bound without a supplied modulus. Each has an
explicit safeguard above. No defect of those forms was found in the
qualified target.

This conditional model-specific encoder removes the prior Schur route's
representation-specific exponential-k onset at the level of a charged
randomized quantum-generated program. Standard concentration, smooth
filters, designs, QSVT and polar recovery remain equally available to a
strong baseline. Generic novelty, best end-to-end prior cost, practical
advantage, calibration and physical implementation remain unestablished.
The new fixed-source factor-two band note 90f088 is outside this verdict.

