# Scoped reconstruction of the mesoblock functional-access interface

W39, 23 October 2026. Requested by W67 within root's retained source/compiler
allocation. Frozen target read in full:
`work/workers/w67_fresh_foundational_mechanism/high_design_audit/quadratic_source_frontier/MESOBLOCK_FILTERED_FRAME_CANDIDATE.md`,
SHA25626c7092cee2414b7681ea7c92b5f87e74b9f2482399a2a397697f2cbe4b784b2.

Verdict: **NO BLOCKING ACCESS OR SPECTRAL-ORACLE DEFECT FOUND IN THE SCOPED
INTERFACE, WITH THE EXPLICIT PRECISION AND COMPLETION QUALIFICATIONS BELOW.**
This reconstructs analytic relative/log access, bounded filter and bin
instruments, polynomial offline probability acquisition, charge-parent
enumeration, and the conditional polar circuit's consistent full-unitary
interface. It does NOT independently reconstruct M6--M9 concentration,
M13--M16 width/averaging, a new finite source/code resource ledger, the
shared-table operational model, or the complete communication theorem.
No native mesoblock/quantum sampler/program/hardware has been run. Generic
functional calculus, phase estimation, polar QSVT, concentration and
unitary-completion stability are established mathematics, not generic
novelty claimed here. All earlier frozen router/V4/Schur bytes are unchanged.

## 1. Exact analytic source and a uniform relative-operator approximation

Use the inherited V4 definitions, not an arbitrary trace-close native
density. Put sigma=diag(1/2,1/4,1/4)^k, alpha_H=k(k-1),

    B=(I-(4/25)bH)_+, M_B=1+(4/25)b alpha_H,
    D=P_pattern(B)>=I, J=D^(-1/2),
    T=I+(4delta/k)(Q-k/2), delta=t0/18,
    Mrel=T J B J, rho=sigma Mrel.

Here P_pattern is the COMPLETE binary charge-pattern conditional
expectation, retaining color fibers. T and sigma are functions of total Q;
all actual B,D,J commute with them. B and D need NOT commute with each
other. Thus Mrel>=0, ||Mrel||<=Tmax M_B, Tmax=1+2delta<2.
The frozen W56 analytic source gives

    S(rho)>=3k/2+t0/31, bulk drift<=-t0/480,
    Tr sigma(Mrel-I)^2<1/6400,
    1/300<=t0<=1/200,

for its stated beta<=1/128 and k=floor(1/(5beta^2)). These source results
are imported, not reproved by this access review. Under the regularization
rho_*=(rho+sigma)/2, M_*=(I+Mrel)/2 has lower bound I/2, norm O(k),
entropy gap at least t0/62 and bulk drift at most -t0/960. The latter uses
the actual diagonal sigma's exactly zero bulk drift. No source inverse
or bath operation is required.

The prior factories acquire PSD B_epsilon with ||B_epsilon-B||<=d<=1/4
by an explicit finite local H phase/coin instrument or the paid elementary
fallback. Its fresh-helper accepted Gram block gives B_epsilon/M_B (or
a separately paid known polynomial normalization). Copying the INPUT
pattern and retaining it gives D_epsilon=P_pattern(B_epsilon). Thus
D_epsilon>=(1-d)I>=3I/4. Its inverse root J_epsilon is acquired with a
known constant block scale, e.g. J_epsilon/(2sqrt2), or a paid polynomial
LCU scale. Inserting an explicit middle output-signal projector in every
Gram product is essential; multiplying a unitary by its inverse is not
such a Gram. All helpers are fresh and all inverses/controls are stored
finite circuits, not reverse access to the communication bath.

The inverse-root resolvent integral gives, for a=1-d,

    ||J_epsilon-J||<=d/(2a^(3/2))<=d,
    ||J_epsilon||<=a^(-1/2).

Expand the ordered J_epsilon B_epsilon J_epsilon-J B J by changing one
factor at a time. Since M_B>=1, the conservative full operator bound is

    ||J_epsilon B_epsilon J_epsilon-J B J||<=4 M_B d,
    ||M_*,epsilon-M_*||<=2 Tmax M_B d.              (A1)

This is ordinary operator norm and has no inverse sigma or dimension
factor. Positivity is exact for this ideal finite-instrument operator:
M_*,epsilon=(I+T J_epsilon B_epsilon J_epsilon)/2>=I/2, since the actual
Q commutators still hold. Generic native gate error is charged separately;
it is not assumed to preserve these algebraic identities exactly.

With B_epsilon/M_B and J_epsilon/(2sqrt2), their product and T/Tmax
block encode Mrel_epsilon at normalization8Tmax M_B. An LCU with I then
gives M_*,epsilon at normalization(1+8Tmax M_B)/2. All are known O(k)
scales, and the finite inverse-root compiler's conditioning is paid.
The already reviewed quadratic-scan H implementation suffices for the
POLYNOMIAL access assertion. The newer linear-times-logarithms router is
only an optional smaller G_H, with its own pending review; no new theorem
depends on silently inheriting its verdict.

## 2. Log access and noncommuting approximation

For positive A,B>=I/2, the resolvent identity and

    log A-log B=integral_0^infty [(B+sI)^(-1)-(A+sI)^(-1)]ds

give ||log A-log B||<=2||A-B||. Therefore for
L=sum_(a=1)^t ln M_*^(a), L_epsilon analogously,

    ||L_epsilon-L||<=4t Tmax M_B d.                (A2)

No commutation between M_* and its approximation is used. Obtain each
ln M_*,epsilon uniformly by bounded positive-interval polynomial calculus.
Its minimum eigenvalue is1/2 and a known norm bound is
L0=1+Tmax M_B, so this is an inverse-polynomial normalized spectral
gap, not the exponentially small minimum eigenvalue of rho_*.
If alpha_* is the ACTUAL acquired block normalization, use the even
bounded extension ln(clamp(alpha_*|x|,1/2,L0)), divided by a known
O(log L0) bound, on its normalized signal interval. The alpha_* factor,
not merely the operator-norm bound L0, is essential. Uniform
polynomial approximation, classical coefficient acquisition and stable
factorization have polynomial cost in k and inverse desired error.
Alternatively a coefficient LCU pays its polynomial coefficient sum.
The normalization of that fallback must be propagated; it is not the
operator's O(logk) norm for free. Known QSVT/phase-factorization compilers
and elementary finite rotation synthesis are paid here, not supplied as
free inverse/eigenbasis or exact-real oracles.

Legal-space extension is explicit: extend Mrel by0 on invalid physical
qutrit labels, then take M_*=(I+Mrel_ext)/2. The illegal block is I/2,
so logarithm has no zero eigenvalue there. All extensions preserve the
legal block, and total charge can be assigned consistently on the unused
labels. The prior full-Hermitian and physical-legalization qualifications
remain in force. No ambient pattern-algebra centrality is claimed.

IMPORTANT: scalar Lipschitz smoothness of a filter is not used as a
linear operator-perturbation bound for noncommuting L_epsilon,L. Instead
the explicit phase-estimation circuit below is compared using Duhamel:

    ||exp(iu L_epsilon)-exp(iu L)||<=|u| ||L_epsilon-L||. (A3)

This avoids an unproved operator-Lipschitz premise. Every approximate
simulator is required to have a coherent zero-helper guarantee on all
physical inputs, including references, controls and adjoints. The ideal
phase circuit and arithmetic leave those dedicated simulator helpers zero;
ideal-prefix/actual-suffix telescoping is therefore valid with dirty phase
or filter registers. Full native gate operator errors are separately paid.

## 3. Uniform bin and filter instruments, including phase uncomputation

Let retained integer bins be j=-J0,...,J0; the target uses J0=t.
The following argument also covers any later smaller finite bin range.
Choose a known integer a0>=max(1,ln L0),

    xmin=-max(t,J0)-2,
    xmax=max(t a0,J0)+2, R=xmax-xmin.

The spectrum of L lies in[-t ln2,t ln L0], away from wraparound, and all
retained supports[j-1,j+1] are at least one unit from the endpoints.
Extend every retained scalar function periodically over this interval;
it vanishes near both endpoints. The bin vector includes an EXPLICIT
reject label with amplitude sqrt(1-sum_retained f_j(x)^2). Its endpoints
are the same reject state. This periodic vector has physical-energy
Lipschitz constant pi/2<2: inside each unit interval it is just one
sine/cosine pair, with constant derivative norm pi/2. At the retained
edges the second component is reject. Outside all supports it is fixed.

The filter amplitude

    a_j(x)=exp((x-j-1)/2) cos(pi(x-j)/2), |x-j|<=1,
           0 otherwise

has scalar Lipschitz constant<3 and, USEFULLY, a_j<=4/5 globally. To see
the latter, split z=x-j: for z<=1/2, the exponential is at most e^(-1/4)
<4/5; for z>=1/2, cosine is at most1/sqrt2<4/5. Thus its coin vector

    w_j(x)=(sqrt(1-a_j(x)^2), a_j(x))

has Lipschitz constant at most3/(3/5)=5, since the rejected amplitude
is bounded below by3/5. The zeros at both support boundaries are
continuous, so no spectral-gap promise at a bin boundary is needed.
One never block encodes a huge exp(L/2) and later cancels its scale.

Use T=2^p point phase estimation for
U=exp[2pi i(L-xmin I)/R]. For an eigenphase phi, its output probability
at y has the usual geometric-sum form. If d_y is circular phase distance,

    p_y<=1/(4T^2 d_y^2), d_y>0,
    sum_y p_y d_y^2<=1/(4T).                       (A4)

The last inequality follows term by term, including exact-grid phases
by continuity. Let v be either the bin vector or filter coin vector.
After controlled preparation of v(y), uncompute the ENTIRE phase
estimator. Comparing to the ideal phase-zero v(phi) isometry before
that uncomputation gives EXACTLY the norm-square

    sum_y p_y ||v(y)-v(phi)||^2.

Consequently the full zero-phase/input-to-all-output ISOMETRY error is
at most5R/(2sqrtT), uniformly over every eigenvalue and hence arbitrary
physical/reference inputs. This is not merely a good-block norm estimate.
The uncomputed phase generally has small residual leakage; it is charged.
Postselecting it for an A_j block is explicit, while the sampling
instrument retains/traces it as part of its Stinespring environment.

For desired subroutine error0<xi<1, choose the next power2 satisfying

    T>=(40R/xi)^2,
    ||L_epsilon-L||<=xi R/(256pi T).              (A5)

The two phase estimators have total absolute L-evolution time less than
4pi T/R, so(A3) costs at most xi/64. The smooth-vector term is at most
xi/16. Scalar arithmetic, phase-offset controls, Hamiltonian compilation
and native synthesis fit the remaining xi budget. Choose the B error in
(A1) at most [xi R/(256pi T)]/[8t Tmax M_B], and the log polynomial error
per source block at most [xi R/(256pi T)]/(2t). These are inverse-
polynomial demands; all query counts, precision bits and helper widths
remain polynomial. Disjoint source log terms can be evolved sequentially
without a Trotter error; every binary-power time is included.

The scalar arithmetic has finite uniform algorithms. On a p-bit phase
label, compute the appropriate unit interval and fractional part, use a
bounded sine/cosine rotation, and coherently label one of its two adjacent
bins. Outside the retained range use the explicit reject cases. Temporary
interval/coin work can be erased from the unchanged input phase and
output label. For a_j evaluate exp only on[-1,0] and cosine only on
[-pi/2,pi/2], defining zero outside. Bounded Taylor series plus interval
arithmetic, reversible compute/rotate/uncompute and ordinary finite gate
synthesis use polynomial precision. Label changes at integer/support
boundaries are harmless because the vector is continuous and Lipschitz.
No table over eigenvectors or exponential number of amplitudes is used.

## 4. Offline probabilities and exact charge-parent access

The ideal bin instrument measured with exact Q has probability
p_(q,j)=Tr rho_*^t P_q f_j(L)^2. Prepare the known local rho_*^t to
trace accuracy eps_p/8 and compile the instrument to coherent accuracy
eps_p/16. Contractivity bounds its probability bias by a conservative
eps_p/2. Fresh local helpers/copies give independent trials. With
N=O(eps_p^(-2) log(Bcells/eta_table)) trials, elementary bounded-sampling
concentration estimates every cell to additive eps_p with confidence
1-eta_table. At retained p>=p_min choose eps_p sufficiently smaller than
zeta_p p_min to obtain its claimed relative table factor. All source
copies, reset operations, measurements, count bits and public table bits
are paid. No probability table or quantum experiment was actually acquired
by this review. Quantum preprocessing is distinct from a polynomial
CLASSICAL constructor, and the shared-public-table model is outside this
access verdict.

For a charge q parent with n=kt ports, N_q=binom(n,q)2^q and its dyadic
padding D_q are exact O(n)-bit integers. Enumerative rank/unrank uses
occupied-position binomial counts and q binary colors, with polynomial
arithmetic and no spectral information. To implement the partial E_q,
first coherently mark invalid padded ranks. On valid labels unrank into
blank physical ports, then XOR the rank of those output ports into the
old rank register to erase it. The invalid flag is retained; invalid
ranks may keep their original register and a fixed dummy physical word.
These are total reversible Boolean circuits on all basis strings. Their
stored inverse is explicit. Both input and output validity flags are
part of the signal projectors; invalid branches cannot re-enter the good
block by a bare unitary-times-inverse cancellation.

Thus A=E_q^* a_j(L) P_q E_q with zero action on padded invalid labels
has acquired normalization1 and uniform block accuracy, using distinct
validity helpers and the explicit bounded filter. This is a partial
embedding, not an impossible isometry from D_q>N_q into N_q dimensions.
On a good polar frame, the TARGET output is legal and exactly charge q.
A final CPTP conversion replacing any invalid/wrong-charge output by a
fixed legal charge-q word contracts the encoder's ideal-target channel
error. It is not postselected, and its inverse is never assumed available.

## 5. Conditional polar core and a consistent global unitary completion

This section assumes, rather than reproves, the frame event(M9): the
operator S=A V R_K satisfies S^*S>=(1-tau)mu I_K. Here V is the known
D_q-dimensional random-unitary circuit and R_K is a KNOWN fixed logical
embedding. The singular gap g_s>=sqrt((1-tau)mu_min) is inverse
polynomial under the candidate's finite guards. Odd bounded sign/polar
QSVT, using the explicit left/right signal projectors, gives a finite
unitary U whose good block approximates C=S(S^*S)^(-1/2). All S/S^*,
native rotations and stable phase-factorization calls are paid; there is
no Gram entry, eigenbasis, exact sign oracle or unknown-message success
amplification. On bad frame seeds U is still a total unitary, but the
pure physical target and source bound are NOT asserted. Every statement
of a physical pure isometry must be restricted to allframesGood.

A useful elementary completion lemma fixes the inverse/control issue.
Suppose R is a known isometric input embedding and C a target isometry
in the full output space (including its required zero helper slots).
Let U be an EXPLICIT finite unitary and

    ||U R-C||<=epsilon<=1/4.

Then there is an exact unitary U0 with U0R=C and

    ||U-U0||<=9epsilon.                            (A6)

Proof: set A=UR, P=AA^*, Q=CC^*. Then d=||P-Q||<=2epsilon<=1/2.
Let K0=QP+(I-Q)(I-P). Its polar unitary

    W0=K0[I-(P-Q)^2]^(-1/2)

maps P onto Q. Since ||K0-I||=d, direct norm bounds give
||W0-I||<=(1+d)/sqrt(1-d^2)-1<=2d<=4epsilon.
Inside Q, the unitary G=C A^* W0^*+(I-Q) maps W0A to C and obeys
||G-I||=||C-W0A||<=5epsilon. Therefore U0=G W0 U satisfies(A6).
This is an EXISTENCE comparison lemma. No matrix of W0,G,U0 is computed
or supplied to the algorithm: it runs the known U and its stored adjoint.

If only the good block F=P_left U R has ||F-C||<=delta_block, unitarity
gives

    ||UR-C||^2=||2I-F^*C-C^*F||<=2delta_block.      (A7)

Hence request delta_block<=delta_global^2/162 to make(A6) at most
delta_global, also ensuring epsilon<=1/4. This square-root leakage cost
must not be omitted. Choosing a stronger small constant denominator is
harmless. The SAME U0 then supports full inverse, controlled-U and range
reflections: adjoint/control error<=delta_global, reflection error at
most2delta_global. Arbitrarily many nested decoder calls therefore admit
an ordinary FULL-operator telescoping budget against one consistent
completion. No dirty-helper ideal-prefix assumption about C is needed
after this global comparison has been established. Relative phases matter:
a subspace-only rotation without G would fail for A=exp(i theta)C.

Native approximation and physical legalization compare the actual CPTP
encoder to the ideal good-seed C channel by contraction. Decoder calls
use the known unitary U/U^*, not an inverse of the legalization channel.
The number of repeated calls multiplies the required global accuracy;
its squared block tolerance in(A7) is still inverse polynomial. Public
fixed-prefix embeddings and products of mesoblock circuits are treated
with the same known R and per-call budgets. No bad seed is certified.

## 6. What this interface does and does not resolve

For supplied rational b and its bit length L_b, finite n=kt, positive
mu_min, and every requested accuracy/confidence, these operations have
a constructive polynomial quantum/classical/seed/precision cost in
k,t,L_b,mu_min^(-1),inverse error and log inverse confidence. A finite
policy must substitute its ACTUAL t,J0,mu_min, complete query counts and
table accuracy before claiming a numerical cost row. Large constants
or exponents are not practicality. The shared quantum-generated table,
concentration/width proof, initial/forward/flush calls, source-domination
factor, repeated receiver row calls and total error/rate ledger remain
separate load-bearing obligations. This review does not assign them a
positive verdict or import a frozen quartic exponent.

Primary generic baselines reopened: [Gilyen et al., QSVT and matrix
arithmetics,1806.01838v1](https://arxiv.org/abs/1806.01838), projected
singular-vector/polar operations and smooth matrix functions;
[Haah, stable product decomposition,1806.10236v4](https://arxiv.org/abs/1806.10236),
classical finite-precision compilation. Their generic mechanisms are
prior art, and all normalizations, phase generation, finite-precision
work and native circuit descriptions are charged. This is internal
scope-bound reconstruction, not external correctness, priority, a
physical acquisition or practical advantage. Mission NOT_ACHIEVED.
