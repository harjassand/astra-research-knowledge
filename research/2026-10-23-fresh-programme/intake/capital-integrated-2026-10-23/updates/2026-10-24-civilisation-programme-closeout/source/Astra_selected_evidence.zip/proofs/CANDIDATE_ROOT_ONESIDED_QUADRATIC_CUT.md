# Correlation cost removes the apparent linear-beta escape

23 October 2026. W64's independent invention, reconstructed by root before its frozen source arrived. W36 has been assigned fresh criticism. This note is a candidate until all critical reviews are reconciled. It strengthens the earlier two-cut weak converse, not a CP or exponential-fidelity theorem. All logs/entropies are bits except the explicit \(\ln2\) constants.

Use the exact resource/causality contract of ARBITRARY_RESOURCE_COMMUNICATION_CUT.md: fresh reference/logical state independent of the entire initial resource, arbitrary normal bath/laboratory entanglement and Alice–Bob preshares, exactly \(N\) device uses, arbitrary backward quantum communication, no additional forward carrier, unconditional TP processing.

For the cut assigning memory \(E\) to Bob, let \(C\) contain \(E\) and Bob's current systems immediately before Alice sends \(A\). The increase of \(I(R:C)\) is
\[
I(R:A\mid C)=S(A\mid C)-S(A\mid RC)
\le S(A\mid C)+S(A)
=2S(A)-I(A:C)
\le2S(A)-I(A:E).
\]
Finite-dimensional \(A\) makes these conditional entropies/CMI well defined with arbitrary normal infinite-dimensional auxiliaries. Local TP operations and backward messages cannot increase the receiving side's mutual information. The other cut still gives increase at most \(2S(B)\). Averaging the resulting two bounds,
\[
I(R:B_{\rm final})\le
\sum_t\{S(A_t)+S(B_t)-\tfrac12I(A_t:E_t)\}. \tag{1}
\]

For one call write \(u=\operatorname{Tr}q\rho_A\), \(v=\operatorname{Tr}q\rho_B\), \(a=1-b\), \(b=\beta^2\), \(q=\mathrm{diag}(0,1,1)\). Define
\[
f(u)=h_2(u)+u,\quad \rho_u=\mathrm{diag}(1-u,u/2,u/2),
\quad d_A=f(u)-S(A)\ge0.
\]
For the actual pre-call joint state set
\[
J=I(A:E)+d_A=D_2(\rho_{AE}\Vert\rho_u\otimes\rho_E).
\]
This identity holds even if \(\rho_A\) has charge or color coherences: \(\log\rho_u\) is scalar on its two charge sectors. Endpoint values are interpreted on their actual supports.

The Hermitian operator \(C_0=i(Uq-qU)\) has norm one: on each matched vacuum/nonroot–colored pair it is a Pauli matrix, and it vanishes on the root-vacuum subspace. Its expectation on \(\rho_u\otimes\rho_E\) is zero because it changes port charge. With \(c=\operatorname{Tr}C_0\rho_{AE}\), quantum Pinsker implies
\[
|c|\le\|\rho_{AE}-\rho_u\otimes\rho_E\|_1
\le\sqrt{2\ln2\,J}. \tag{2}
\]
If the relative entropy is infinite the desired bound is interpreted by approximation; the mutual information and \(d_A\) here are in fact finite because \(A\) is a qutrit.

The original exact root identity gives, with \(r_0=\operatorname{Tr}[(|0\rangle\langle0|\otimes P_0)\rho_{AE}]\ge0\),
\[
u+v-1=b(2u-1)-ar_0+\sqrt{ab}\,c. \tag{3}
\]
No bulk or depth premise is used in (3).

Since \(S(B)\le f(v)\) and \(d_A+I(A:E)/2\ge J/2\), the summand in (1) is at most
\[
f(u)+f(v)-J/2.
\]
Write \(x=u-1/2\). Binary Pinsker gives \(h_2(u)\le1-2x^2/\ln2\); use \(h_2(v)\le1\). Dropping the nonpositive root term and applying (2)–(3), this is at most
\[
3+\underbrace{2bx-2x^2/\ln2}_{\le b^2\ln2/2}
+\underbrace{\sqrt{2ab\ln2\,J}-J/2}_{\le ab\ln2}.
\]
Both scalar bounds are complete-square identities, valid for every real \(x\) and \(J\ge0\). Thus the per-call bound is
\[
3+\ln2\,(b-b^2/2).
\]
Together with the binary Bell-test lower \(I(R:B_{\rm final})\ge2F_e\log_2K-h_2(F_e)\), this yields
\[
\boxed{2F_e\log_2K-h_2(F_e)
\le N[3+\ln2\,(\beta^2-\beta^4/2)].}
\]
Reliable quantum communication therefore satisfies the all-initial-resource weak ceiling
\[
Q\le\min\{\log_2 3,\;3/2+(\ln2/2)\beta^2-(\ln2/4)\beta^4\}.
\]

If validated, arbitrary horizon-dependent initial entanglement cannot create a linear-in-beta reliable rate excess in this model. The earlier product/SEP strong-converse coefficient remains tighter under its own hypotheses. This does not determine the exact assisted coefficient, establish attainability, give a strong converse for entangled initial resources, or acquire/price a physical initializer. The previous apparent linear-versus-quadratic gap was a limitation of the coarser port-entropy proof.
