"""Synthetic causal acquisition plus exact finite algebra for frozen455c5a14.

The learner receives a measurement callable and public n,a,sigma,delta only.
Graph/weights are confined to the synthetic instrument. This is not hardware.
No import from any preceding producer algorithm or replay.
"""

from fractions import Fraction as F
from itertools import permutations
from pathlib import Path
import json
import math
import random
import numpy as np

ROOT = Path(__file__).resolve().parent
rr = random.Random(7300917)
assertions = 0


def check(p):
    global assertions
    assertions += 1
    assert p


def dot(x, y):
    return sum((a * b for a, b in zip(x, y)), F(0))


def eye(n):
    return [[F(i == j) for j in range(n)] for i in range(n)]


def inverse(a):
    n = len(a)
    b = [row[:] + extra for row, extra in zip(a, eye(n))]
    for j in range(n):
        k = next(i for i in range(j, n) if b[i][j])
        b[j], b[k] = b[k], b[j]
        z = b[j][j]
        b[j] = [x / z for x in b[j]]
        for i in range(n):
            if i != j:
                z = b[i][j]
                b[i] = [x - z * y for x, y in zip(b[i], b[j])]
    return [row[n:] for row in b]


def mv(a, x):
    return [dot(row, x) for row in a]


def lap(d, a, theta):
    n = 2 * d + 2
    L = [[F(0)] * n for _ in range(n)]
    edges = [(0, i) for i in range(2, d + 2)] + [(1, i) for i in range(d + 2, n)]
    if theta:
        edges.append((0, 1))
    for i, j in edges:
        L[i][i] += a
        L[j][j] += a
        L[i][j] -= a
        L[j][i] -= a
    return L


# Exact arbitrary selected-leaf circuit response and all-output information.
mixed_circuit_cases = 0
for d in (1, 2, 3):
    n, a, sig2 = 2 * d + 2, F(1), F(1, 4)
    L0, L1 = lap(d, a, 0), lap(d, a, 1)
    b = [F(1), F(-1)] + [F(0)] * (n - 2)
    C = F(129)
    for trial in range(5):
        q = 4
        xs, delta_means = [], []
        for t in range(q):
            chosen = set(rr.sample(list(range(2, n)), min(2, n - 2)))
            R = [F(1, 128 * (d + 1)) if i in chosen else F(1, 128) for i in range(n)]
            g = [1 / v for v in R]
            K0 = [[L0[i][j] + g[i] * F(i == j) for j in range(n)] for i in range(n)]
            K1 = [[L1[i][j] + g[i] * F(i == j) for j in range(n)] for i in range(n)]
            A0, A1 = inverse(K0), inverse(K1)
            u = [g[i] * z for i, z in enumerate(mv(A0, b))]
            c = a / (1 + a * dot(b, mv(A0, b)))
            Mdiff = [[g[i] * (A0[i][j] - A1[i][j]) * g[j] for j in range(n)] for i in range(n)]
            check(Mdiff == [[c * u[i] * u[j] for j in range(n)] for i in range(n)])
            check(sum(abs(z) for z in u) == 2)
            check(max(abs(z) for z in u) <= C / d)
            check(dot(u, u) <= 2 * C / d)
            x = [F(rr.randrange(-5, 6), 3) for _ in range(n)]
            dm = mv(Mdiff, x)
            check(dot(dm, dm) == c * c * dot(u, u) * dot(u, x) ** 2)
            check(dot(dm, dm) / (2 * sig2) <= 2 * a * a * C * C * dot(x, x) / (sig2 * d * d))
            xs.append(x)
            delta_means.append(dm)
            mixed_circuit_cases += 1
        B = max(sum(x[i] * x[i] for x in xs) for i in range(n))
        total_kl = sum(dot(z, z) / (2 * sig2) for z in delta_means)
        check(total_kl <= 2 * a * a * C * C * n * B / (sig2 * d * d))

metadata_cases = 0
for n in range(4, 15, 2):
    for s in range(n + 1):
        selected = set(range(s))
        count = sum(U in selected or V in selected for U, V in permutations(range(n), 2))
        check(F(count, n * (n - 1)) <= F(2 * s, n))
        metadata_cases += n * (n - 1)

# Exact large-degree scalar margins for all boundary/mixed weight profiles.
margin_cases = 0
for d in (131, 200, 500):
    for profile in (0, 1, 2):
        a, r0, A = F(1), F(1, 128), F(1, 2)
        wU = [a * (1 if profile == 0 else 3 if profile == 1 else 1 + (j % 3)) for j in range(d)]
        wV = list(reversed(wU))
        SU = sum(w / (1 + r0 * w) for w in wU)
        SV = sum(w / (1 + r0 * w) for w in wV)
        g = 1 / r0
        for theta in (0, 1):
            det = (g + SU) * (g + SV) + theta * a * (2 * g + SU + SV)
            Fhh = g * (g + SV + theta * a) / det
            for w in wU:
                effective = w / (1 + r0 * w) * Fhh
                check(effective >= g / (4 * d))
            g1 = 128 * a * (d + 1)
            det1 = (g1 + SU) * (g1 + SV) + theta * a * (2 * g1 + SU + SV)
            inactive_current = theta * a * A * g1 * g1 / det1
            check(inactive_current >= 7 * a * A / 8 if theta else inactive_current == 0)
            margin_cases += 1


class SyntheticInstrument:
    def __init__(self, n, a, sigma, delta, theta, weight_profile, seed):
        self.n, self.a, self.sigma = n, a, sigma
        self.d = (n - 2) // 2
        r = np.random.default_rng(seed)
        labels = r.permutation(n)
        self.hubs = tuple(int(v) for v in labels[:2])
        self.groups = (labels[2:2 + self.d], labels[2 + self.d:])
        self.weights = []
        for _ in range(2):
            self.weights.append(np.full(self.d, a if weight_profile == "floor" else 3 * a)
                                if weight_profile != "continuous"
                                else r.uniform(a, 3 * a, self.d))
        self.theta = theta
        self.noise = np.random.default_rng(seed + 10000019)
        K = max(1, math.ceil(8 * sigma ** 2 / a ** 2 * math.log(16 * n / delta)))
        T = max(1, math.ceil(128 * sigma ** 2 / a ** 2 * math.log(4 / delta)))
        self.q = K + T
        H = (3 * a * self.d + a) / 2 + sigma * math.sqrt(2 * math.log(4 * n * self.q / delta))
        self.step = a / 8
        self.max_index = math.ceil(H / self.step)
        self.bits = math.ceil(math.log2(2 * self.max_index + 1))
        self.row_energy = np.zeros(n)
        self.actions = self.scalars = self.clipped_scalars = self.precision_actions = 0
        self.max_abs_mean = self.max_source_power = 0.0
        self.cache = {}

    def acquire(self, x, selected):
        """Only this callable is handed to the learner."""
        x = np.asarray(x, dtype=float)
        selected = tuple(sorted(int(i) for i in selected))
        assert len(selected) <= 2 and len(set(selected)) == len(selected)
        assert np.all((x == 0) | (x == 0.5))
        self.row_energy += x ** 2
        key = (x.tobytes(), selected)
        if key not in self.cache:
            R = np.full(self.n, 1 / (128 * self.a))
            R[list(selected)] = 1 / (128 * self.a * (self.d + 1))
            g = 1 / R
            S, rhs, alpha = [], [], []
            for hub, leaves, weights in zip(self.hubs, self.groups, self.weights):
                aa = weights / (1 + R[leaves] * weights)
                alpha.append(aa)
                S.append(g[hub] + aa.sum())
                rhs.append(g[hub] * x[hub] + aa @ x[leaves])
            bridge = self.theta * self.a
            det = S[0] * S[1] + bridge * (S[0] + S[1])
            vh = ((rhs[0] * (S[1] + bridge) + bridge * rhs[1]) / det,
                  (rhs[1] * (S[0] + bridge) + bridge * rhs[0]) / det)
            mean = np.zeros(self.n)
            for hub, leaves, aa, v in zip(self.hubs, self.groups, alpha, vh):
                mean[hub] = g[hub] * (x[hub] - v)
                mean[leaves] = aa * (x[leaves] - v)
            assert abs(mean.sum()) < 1e-8 * max(1, np.max(abs(mean)))
            self.max_abs_mean = max(self.max_abs_mean, float(np.max(abs(mean))))
            power = float(x @ mean)
            assert power >= -1e-9
            self.max_source_power = max(self.max_source_power, power)
            self.cache[key] = mean
        y = self.cache[key] + self.noise.normal(0, self.sigma, self.n)
        indices = np.rint(y / self.step)
        self.clipped_scalars += int(np.count_nonzero(abs(indices) > self.max_index))
        indices = np.clip(indices, -self.max_index, self.max_index)
        self.actions += 1
        self.scalars += self.n
        self.precision_actions += bool(selected)
        return indices * self.step


def learner(acquire, n, a, sigma, delta, seed):
    """No reference to graph labels, weights, Laplacian or internal potentials."""
    r = np.random.default_rng(seed)
    K = max(1, math.ceil(8 * sigma ** 2 / a ** 2 * math.log(16 * n / delta)))
    T = max(1, math.ceil(128 * sigma ** 2 / a ** 2 * math.log(4 / delta)))
    command = r.integers(0, 2, n) / 2
    current = np.zeros(n)
    for _ in range(K):
        current += acquire(command, ())
    hubs = tuple(sorted(int(i) for i in np.argsort(abs(current))[-2:]))
    command = np.zeros(n)
    command[hubs[0]] = 0.5
    test_sum = 0.0
    for _ in range(T):
        test_sum += acquire(command, hubs)[hubs[1]]
    return bool(test_sum / T < -a / 4), hubs, K, T


acquisition_cases = []
for n in (264, 512, 1024):
    for sigma in (0.05, 0.5, 1.0):
        for theta in (0, 1):
            profile = ("floor", "ceiling", "continuous")[(n + theta + int(10 * sigma)) % 3]
            delta, a = 0.1, 1.0
            inst = SyntheticInstrument(n, a, sigma, delta, theta, profile, 101 * n + 17 * theta + int(100 * sigma))
            decision, learned, K, T = learner(inst.acquire, n, a, sigma, delta, 99991 + n + theta)
            check(set(learned) == set(inst.hubs))
            check(decision == bool(theta))
            check(inst.actions == K + T and inst.scalars == n * (K + T))
            check(inst.precision_actions == T)
            check(np.max(inst.row_energy) <= (K + T) / 4)
            check(inst.clipped_scalars == 0)
            acquisition_cases.append({"n": n, "sigma_over_a": sigma, "theta": theta,
                                      "weight_profile": profile, "actual_synthetic_actions": inst.actions,
                                      "actual_synthetic_scalars": inst.scalars, "phase1_samples": K,
                                      "phase2_samples": T, "encoded_bits_per_scalar": inst.bits,
                                      "max_command_row_energy": float(np.max(inst.row_energy)),
                                      "max_abs_mean_current": inst.max_abs_mean,
                                      "max_nominal_settled_source_power": inst.max_source_power,
                                      "clipped_scalars": inst.clipped_scalars,
                                      "hubs_acquired_from_data": True, "correct_decision": True})

result = {
    "status": "PASS",
    "scope": "finite exact algebra plus synthetic causal acquisition under stipulated sensor/port law",
    "assertions": assertions,
    "exact_mixed_selected_leaf_circuit_cases": mixed_circuit_cases,
    "exact_ordered_hub_metadata_cases": metadata_cases,
    "exact_large_degree_margin_cases": margin_cases,
    "synthetic_unknown_plant_cases": acquisition_cases,
    "total_synthetic_actions": sum(x["actual_synthetic_actions"] for x in acquisition_cases),
    "total_synthetic_scalar_readouts": sum(x["actual_synthetic_scalars"] for x in acquisition_cases),
    "physical_trials": 0,
    "real_unknown_experiment_acquisitions": 0,
}
(ROOT / "TWO_PRECISION_CHANNEL_REPLAY_RESULTS.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if not isinstance(v, list)}, indent=2))
