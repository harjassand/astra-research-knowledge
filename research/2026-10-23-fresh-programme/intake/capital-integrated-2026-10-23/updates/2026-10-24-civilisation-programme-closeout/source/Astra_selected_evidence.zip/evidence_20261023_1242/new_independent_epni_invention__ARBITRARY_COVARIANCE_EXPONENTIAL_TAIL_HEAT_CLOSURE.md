# Eventual amplifier EPnI for exponential-energy inputs, any covariance

23 October 2026, W38. NEW independent extension; fresh criticism pending.
The general UNHEATED finite-energy independent-input EPnI is NOT_ACHIEVED.
No frozen earlier source or review is altered by this note.

## 1. Exact theorem candidate and dependency

Fix finite n and G>1, lambda=G-1, s=2G-1. Let rho_A,rho_B be independent
n-mode states, each satisfying Tr rho_i exp(delta_i N_i)<infinity for
some supplied delta_i>0. No isotropic covariance, finite Fock support,
finite charge bandwidth, diagonal form or within-party factorization is
assumed. Apply ACTUAL independent isotropic heat H_T to every input mode.

For every sufficiently large finite T, depending on the fixed sources,
n and G, the retained amplifier output obeys the exact EPnI. Arbitrary
first moments may be removed by displacement equivalence. If at least
one input is non-Gaussian, the EPnI entropy gap is at least c T^-m for all
sufficiently large T, where m>=3 is the first unmatched Gaussian moment
order of either input and c>0 depends on the sources. If both are Gaussian,
the Gaussian EPnI below applies at every T without this asymptotic step.

The new analytic dependency is the separate frozen
`COHERENT_SANDWICH_HIGHER_MOMENT_BRIDGE.md`, SHA256
e51dd5d26d94d222032deab14232cc973e5825089b96e6dc8fcd7288378e4fff.
Its exact k-copy signed-measure kernel, moment coefficient and two-sided
quantum DPI sandwich are still pending fresh criticism. Section4 below
uses those general-covariance asymptotics, not that note's narrower
isotropic EPnI application. No N557, thermal optimizer or quantum L3 DPI
is imported. The known Gaussian prerequisite is explicitly reconstructed.

This remains a CHANGED-INPUT high-noise theorem. It supplies neither the
original unheated inequality nor arbitrary finite-energy heavy tails.

## 2. Established symplectic sum inequality, reconstructed

Let Omega=direct_sum [[0,1],[-1,0]]. For real positive definite A let
nu_1(A)<=...<=nu_n(A) be its symplectic eigenvalues. The established
variational formula is

    min_(S Omega S^T=Omega_k) Tr S A S^T
       =2 sum_(j=1)^k nu_j(A), 1<=k<=n.                  G1

Here S is a real 2k by2n symplectic frame. To independently verify the
lower bound, use Williamson's theorem to put A into diag(D,D) in paired
coordinates, D=diag(nu_j). A symplectic frame defines k canonical output
annihilation operators b=U a+V a^dagger, with

    U U^dagger-V V^dagger=I_k.

Their summed quadrature variance is

    Tr S A S^T=2 Tr(U D U^dagger+V D V^dagger).

Write U=(UU^dagger)^(1/2)W with WW^dagger=I_k. Since UU^dagger>=I,
trace positivity and ordinary Ky Fan give

    Tr U D U^dagger
       =Tr[(W D W^dagger)UU^dagger]
       >=Tr W D W^dagger>=sum_(j=1)^k nu_j(A).

The V term is nonnegative. Equality is obtained by taking V=0 and W to
select the k smallest Williamson modes. This proves G1 without assigning
new priority to this variational principle.

Minimizing the sum for A+B then gives

    sum_(j=1)^k nu_j(A+B)
       >=sum_(j=1)^k[nu_j(A)+nu_j(B)].                   G2

Thus nu(A+B) weakly supermajorizes the ordered sum nu(A)+nu(B). In
particular, for every increasing concave scalar h on the relevant interval,

    sum_j h(nu_j(A+B))
       >=sum_j h(nu_j(A)+nu_j(B)).                       G3

This is precisely the established symplectic sum theorem of
[Hiroshima, quant-ph/0511006v3, Lemma1 and Theorem1](https://arxiv.org/pdf/quant-ph/0511006v3).
Its exact statement and proof reduction were read. The passive Gaussian
EPnI application is explicitly in
[De Palma, 1710.09395, AppendixA.8](https://arxiv.org/pdf/1710.09395).
Those primary results are prior, not new claims of this note.

## 3. The amplifier Gaussian prerequisite follows with positive weights

Put J=direct_sum diag(1,-1). It is antisymplectic, J Omega J=-Omega,
and nu(JBJ)=nu(B). For independent Gaussian input covariances V_A,V_B,
the retained covariance is G V_A+lambda J V_B J. Apply G2-G3 to the
positive matrices G V_A and lambda J V_B J. If their original symplectic
eigenvalues are a_j,b_j (now covariance eigenvalues, not photon means),
the Gaussian output entropy is at least

    sum_j h(G a_j+lambda b_j),
    h(v)=g(v-1/2), v>=1/2.                              G4

The remaining scalar step is the convexity of

    F(u,v)=h(G h^-1(u)+lambda h^-1(v)).                  G5

Here is the active proof, rather than extrapolating a passive parameter.
For x>1/2 define ell(x)=h'(x)=log[(x+1/2)/(x-1/2)] and

    K(x)=(x^2-1/4)ell(x)
        =x-sum_(r>=1) 2 x^(-(2r-1))/[(4r^2-1)4^r].

The series is absolutely convergent. With c=G a+lambda b and s=G+lambda>1,
convexity of x->x^-p and weights G/s,lambda/s imply

    G a^-p+lambda b^-p>=s^(p+1)c^-p>c^-p.

Termwise subtraction in the positive series therefore yields

    K(c)>G K(a)+lambda K(b).                            G6

Set W_x=x^2-1/4. Direct differentiation at u=h(a),v=h(b) gives

    F_uu=G/[W_c ell(a)^2] *[K(c)/K(a)-G]>0,
    F_vv=lambda/[W_c ell(b)^2] *[K(c)/K(b)-lambda]>0,
    F_uv=-G lambda/[W_c ell(a)ell(b)],

    det Hess F=G lambda K(c)[K(c)-G K(a)-lambda K(b)]
       /[W_c^2 ell(a)^2ell(b)^2 K(a)K(b)]>0.             G7

So F is jointly strictly convex in the positive-entropy interior. Jensen
applied to the pairs h(a_j),h(b_j) in G4 gives EXACT Gaussian amplifier EPnI

    S(gamma_C)>=n F(S(gamma_A)/n,S(gamma_B)/n).           G8

In the heat application all Gaussian states are faithful and strictly
warm, so no zero-entropy endpoint is used. Boundary Gaussian cases, if
desired, follow by adding a fixed epsilon I to their finite covariances
and taking the finite-dimensional Gaussian entropy formula limit.

The generic Gaussian assertion is established prior; G1-G8 reconstruct
the exact prerequisite needed here. The known passive theorem alone was
not substituted outside its transmissivity range. G5-G7 also appear in
the separately reviewed scalar/block calculations in this worker's notes.

## 4. Compare each ACTUAL heated state with its matching Gaussian

Remove means by displacement; heat is displacement covariant and the
amplifier maps the two displacements linearly, so all entropies are unchanged.
Exponential Husimi moments are preserved under translation at a smaller
positive parameter. The exact identity S7 in the sandwich note then keeps
the supplied exponential-photon premise valid for the centered states.

Let gamma_A,gamma_B be the matching centered Gaussian input states and
let gamma_i(T)=H_T(gamma_i). The corresponding retained Gaussian output
gamma_C(T) has covariance

    V_C(T)=G V_A+lambda J V_B J+sTI.

Write s_i(T)=S(gamma_i(T)) and
d_i(T)=D(rho_i(T)||gamma_i(T)). Exact matching against the Gaussian
quadratic logarithm gives

    S(rho_i(T))=s_i(T)-d_i(T), i=A,B,C.                  G9

All energies and entropies are finite. The output sandwich is supplied by
the ACTUAL independent-input representation

    Y=sqrt(G)X_QA+sqrt(lambda)J X_QB,
    rho_C(T)=coherent_prepare(law(Y+Z_(sT-G))).

The two classical bounds differ by exactly one extra noise unit. No
independent exponential-energy propagation theorem about the unheated
amplifier output is assumed.

Suppose at least one input is non-Gaussian and let m>=3 be the smaller
first unmatched Gaussian moment order. Define A=Delta_(A,m) and
B=J^(tensor m)Delta_(B,m), assigning zero when matching extends beyond m.
At least one is nonzero. The sandwich note proves

    d_A=||A||^2/(2m!T^m)+O(T^-m-1),
    d_B=||B||^2/(2m!T^m)+O(T^-m-1),
    d_C=||G^(m/2)A+lambda^(m/2)B||^2
                       /(2m!s^mT^m)+O(T^-m-1).        G10

These are matching-Gaussian relative entropies, not defects from an
isotropic thermal reference. This distinction is essential when V_i
is not proportional to I.

## 5. Nonnegative Gaussian baseline plus a strict non-Gaussian margin

Let the Gaussian baseline entropy gap be

    B(T)=s_C(T)-n F(s_A(T)/n,s_B(T)/n)>=0               G11

by G8. Direct Gaussian entropy asymptotics show

    g^-1(s_A(T)/n)=T+O(1),
    g^-1(s_B(T)/n)=T+O(1).

For example the symplectic eigenvalues of TI+V_i are T+O(1), so their
entropy per mode is1+log T+O(1/T). Therefore the two first derivatives
of F at this Gaussian entropy pair satisfy

    F_u=theta+O(T^-1), F_v=phi+O(T^-1),
    theta=G/s, phi=lambda/s.

Its Hessian is uniformly bounded on the intervening segment: the
effective photon means stay of order T, ell is of order1/T, W_c of
order T^2 and all K-ratios in G7 are bounded. The actual differences
d_i/n are O(T^-m), so the same bounds hold across that segment.

Taylor's exact finite remainder and G9 give the actual EPnI gap

    Delta(T)=B(T)+theta d_A+phi d_B-d_C
                    +O(T^-m-1)+O((d_A+d_B)^2/n)
             =B(T)+kappa T^-m+O(T^-m-1),               G12

    kappa=[theta||A||^2+phi||B||^2
            -||theta^(m/2)A+phi^(m/2)B||^2]/(2m!).

The weighted tensor Cauchy inequality yields

    kappa>= [1-theta^(m-1)-phi^(m-1)]
              [theta||A||^2+phi||B||^2]/(2m!)>0.        G13

Use B(T)>=0; the remaining error is smaller than kappa/(2T^m) at every
sufficiently large T. This proves the stated eventual inequality and
strict lower margin for any non-Gaussian input pair under the premises.
The TOTAL gap need not have order T^-m: a positive Gaussian covariance
mismatch term can dominate it at order T^-2. If both inputs are Gaussian,
G8 itself proves the inequality with no high-order expansion.

## 6. Boundaries, costs and current status

This is a fixed-source/n/G theorem after applying real heat. It is not a
uniform-noise theorem, an approximation theorem for arbitrary finite
energy, a zero-noise limit, or a solution of the original general EPnI.
First-moment normalization is unitary equivalence, not a free acquired
displacement record. Covariance and exponential-tail data remain supplied
mathematical hypotheses; no finite tomography or tail certification is
performed here.

Each input gains nT photons. At T>=1 the native heat is entanglement
breaking and gives a positive mixture of product coherent states, even
from initially entangled groups. This establishes no surviving native
entanglement advantage or practical thermal device. Pump, ancilla,
preparation, phase, calibration, precision, entropy acquisition, disposal
and reset costs are not implemented. No apparatus, external message,
publication or public claim has been produced.

The all-orders signed kernel and quantum sandwich require fresh criticism;
the Gaussian prerequisite has been independently reconstructed here from
established primary mathematics. Computational diagnostics are not an
all-input proof. Historical priority, external acceptance, physical
validation and practical significance remain UNKNOWN/NOT_ESTABLISHED.
