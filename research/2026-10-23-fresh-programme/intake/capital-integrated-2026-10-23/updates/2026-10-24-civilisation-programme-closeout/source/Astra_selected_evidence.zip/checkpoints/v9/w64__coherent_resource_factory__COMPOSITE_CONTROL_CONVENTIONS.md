# Exact pulse conventions

This accompanies frozen EXACT_PORT_PHASE_INVERSE_V1.md SHA256 06cf56a3a937181822c8d4d04c36f832f2d3d11a452ae0ad0bb652848fbe5eec without changing its bytes.

Every D(z) in the actual construction (P1)--(P15) is precisely diag(z,1,1) on the local qutrit; its matched-pair restriction is diag(z,1), and its root-singleton scalar is z. The chronological pulse order in (P8) is zR, V, z1, V, z2, V, zL. In the odd-power reduction each V in that list is replaced by m physical forward calls, and m-1 physical calls are appended. Every physical call is followed by a coherent quantum qutrit return.

The informal elementary-echo sentence in section I should denote E_pi=diag(i,-i,-i), which has matched restriction diag(i,-i), rather than calling that gate D(i). In the defined notation E_pi=-i D(-1), while D(i)=diag(i,1,1). This expository symbol ambiguity has no role in P1--P15 or in the compiler/tests; the failed simple-echo idea must not be confused with the actual root-compatible pulse theorem.

The scalar g in the exact theorem is the SAME phase on every matched pair AND the root singleton of the selected known x sector. The full factory containing T inverse blocks therefore carries only the removable common scalar g^T. The diagnostics compare full output columns after this common phase. They never align separate words, separate depths, or separate seed sectors independently to manufacture a channel identity.

Finite diagnostics treat an effective |beta_m|<1e-13 as a numeric near-involution shortcut and retain its at-most 2|beta_m| coefficient error. The ideal algebraic proof uses an exact beta_m=0 branch, while section IV supplies rational-parameter certified compilation for finite implementations. Floating tests do not themselves certify exact algebraic parameter selection or hardware phase synthesis.
