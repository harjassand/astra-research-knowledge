# Independent finite-port complete-process reconstruction

W39, 24 October 2026. Exact reviewed source:
`FINITE_PORT_IMPEDANCE_OBSTRUCTION.md`, SHA256
`2e8fe1f52d9c6fb77f78578efc303b0089a73e0937fd56c5d86f765fb2c9706b`.
No finite-port producer code/output/report, peer verdict or root derivation
was read. The independently written pre-diagnostic derivation is frozen
at e58bd50e.... New controls are standalone, with no producer/peer imports.
The earlier ideal-action/compact-prior results are not altered.

## 1. The observation law is a stipulated passive circuit model

There are two equal-weight-a stars with d>=1 leaves each, n=2d+2,
and a possible weight-a hub edge. All labels, memberships, background
weights and constants are known to the learner. Only its presence bit
theta is unknown. This grants more information than the hidden-star
upper problem and therefore strengthens this obstruction.

Every terminal receives an external command x_i through the same known
series resistor r>0. Node KCL and the series relation are

    i=L_theta v=(x-v)/r.

Because L_theta is positive semidefinite, I+rL_theta is strictly positive
definite even though the graph is floating/disconnected. Solving gives

    A_theta=(I+rL_theta)^-1,
    v=A_theta x,
    i=M_theta x,
    M_theta=L_theta A_theta=(I-A_theta)/r.                (P1)

The last identity follows by multiplication, not by a small-r
approximation. The acquired data are ALL n currents plus independent
N(0,sigma^2) readout errors at each action. Settling and command
preparation are granted exact. Gaussian variance is a stipulated readout
law independent of theta and commands, not a thermal-noise inference.

The PATHWISE budget is sum_t x_ti^2<=B at every terminal, for every
realized admissible controller path under either hypothesis. It is a
budget on external x, not on internal v. A controller may choose x_t
from its independent seed and all past observations. Current-action
readout noise is generated after that command and is independent of
the prior history. This causal passive observation law is important
when interpreting the separate same-action feedback examples.

## 2. Exact full response difference

Let b=e_U-e_V and L1=L0+a bb^T. The rank-one inverse identity gives

    A1=A0-[ra/(1+ra b^TA0b)]A0bb^TA0.

Using P1,

    M1-M0=c uu^T,
    u=A0b, c=a/(1+ra b^Tu), 0<c<=a.                     (P2)

This is a statement about every entry of the full terminal operator.
It does not compare a single selected hub output.

Write beta=ra and D=1+beta(d+1). Within one disconnected star, let
h be the hub entry and l a leaf entry of A0 e_U. Its equations are
(1+beta)l-beta h=0 and (1+beta d)h-beta d l=1. Thus

    h=(1+beta)/D, l=beta/D, h+dl=1.

The two star columns have disjoint supports, so u is that positive
column and its negative counterpart. Exactly,

    ||u||_1=2,
    ||u||_2^2=2(h^2+d l^2), b^Tu=2h.                    (P3)

At fixed a,r, beta>0 is constant, ||u||_2^2~2/d and c->a. This
asymptotic is not substituted into any finite inequality.

## 3. Adaptive Gaussian transcript KL, with the SAME history

Let R denote all policy randomness, independent of theta. For each
common history h=(R,Y1,...,Y_(t-1)), the controller evaluates the SAME
function x_t(h) in the two likelihoods. Its distribution of histories
differs across hypotheses; that does not entitle the proof to compare
two unrelated command realizations inside a conditional KL term.

Conditional on this common history, the two next observations are
N(M1 x_t(h),sigma^2 I) and N(M0 x_t(h),sigma^2 I). Their conditional
relative entropy is

    ||(M1-M0)x_t(h)||^2/(2sigma^2)
       =c^2||u||_2^2(u^Tx_t(h))^2/(2sigma^2).

The seed has common law and known actions are deterministic functions
of that history. They add no KL. The ordinary chain rule therefore
gives the full-transcript equality

    D(P1||P0)=c^2||u||_2^2/(2sigma^2)
                              E1 sum_t (u^Tx_t)^2.       (P4)

All n acquired coordinates are in the conditional Gaussian; unlimited
decoding or reading the entire transcript is already allowed. No
unobserved-hub reduction or nonadaptive assumption appears in P4.

For fixed finite q this is direct. A bounded adaptive stopping rule
can be padded with zero commands and common independent readouts after
stopping; its decision kernel is identical at every common history.
An almost-sure finite stopping extension follows by finite transcript
limits and monotone convergence of the nonnegative conditional KL sum.
The pathwise bound below is uniform in truncation. This is an optional
extension, not required to interpret the source's arbitrary finite q.

## 4. A pathwise budget bounds all repetitions together

For one realized sequence, form temporal vectors s_i=(x_1i,...,x_qi).
Triangle and the row budget give

    sum_t(u^Tx_t)^2
       =||sum_i u_i s_i||^2
       <=(sum_i |u_i| ||s_i||)^2
       <=B||u||_1^2=4B.                                (P5)

This is true on EACH adaptive path, not just an unconditioned average.
Substituting into P4 and then Pinsker gives

    D(P1||P0)<=2c^2 B||u||_2^2/sigma^2,
    TV(P1,P0)<=c sqrt(B||u||_2^2)/sigma.                 (P6)

A randomized test of both fixed networks with risk<=delta<1/2
requires TV>=1-2delta. Therefore

    B>=sigma^2(1-2delta)^2/[c^2||u||_2^2].               (P7)

No number of passive adaptive repetitions avoids P7 under the SAME
total command budget and fixed scalar readout noise. Splitting that
budget into tiny amplitudes is explicitly included in P5. Repetitions
may of course help if the allowed total budget changes.

## 5. Sufficient control and exact scope of the scaling conclusion

The background is known here. For one command set

    x_i=sqrt(B) sign(u_i).

Each row spends exactly B, and u^Tx=2sqrt(B). M0x=0 because each
disconnected component receives a constant external voltage. By P2
the alternative mean is 2c sqrt(B)u. The full Gaussian mean distance
is 2c sqrt(B)||u||_2. Midpoint likelihood testing therefore has equal
endpoint error

    Phi[-c sqrt(B)||u||_2/sigma].                        (P8)

It saturates P5 and proves B=Theta(d) is sufficient as well as necessary
at fixed a,r,sigma and target delta. P7 and P8 have different statistical
constants; no exact adaptive minimax risk formula is asserted. This
sufficiency concerns the supplied-known-background pair, not hidden
topology recovery on a larger family.

For variable r_d, put gamma_d=a r_d d. The exact h,l imply

    h<=1/(1+gamma_d)+1/d, l<=1/d,
    ||u||_2^2<=4/(1+gamma_d)^2+4/d^2+2/d.                (P9)

Thus gamma_d->infinity forces ||u||_2->0. Since c<=a, fixed B and
fixed sigma/a>0 cannot achieve a uniform target delta<1/2. If gamma_d
is merely unbounded, the same obstruction holds on a divergent
subsequence. Consequently a uniform finite-error family requires
gamma_d bounded; r_d=O(1/(ad)) removes this particular vanishing-
information obstruction. In that regime h and c/a stay bounded below,
and P8 also gives fixed-budget sufficiency for the known-background
test when the fixed constants permit its target error.

At fixed r instead, a fixed B would require sigma/a=O(d^-1/2) in
this passive current-readout model. This last statement is an algebraic
resource scaling, not evidence that such sensor precision is feasible
or infeasible. Other r_d decay regimes interpolate via P3 and P7;
one cannot replace every variable-r case by the fixed-r Theta(d) law.

## 6. Duration has a separate explicitly charged observation law

Suppose conditional current variance is sigma0^2/tau_t, tau_t>0,
and time choices are fixed from the previous history like commands.
The Gaussian chain rule adds tau_t in each term of P4. Under the
time-weighted row budget sum_t tau_t x_ti^2<=E, use temporal vectors
(sqrt(tau_t)x_ti)_t. P5 then gives

    D(P1||P0)<=2c^2 E||u||_2^2/sigma0^2,
    E>=sigma0^2(1-2delta)^2/[c^2||u||_2^2].               (P10)

This also allows adaptive durations, since at a common history the
conditional covariance is the same known one under both hypotheses.
It is a stipulated white-noise averaging model. E is a time-weighted
command resource, not an automatically measured energy in Joules.
If integration time reduces noise but its cost is omitted, it is a
different resource accounting; P10 does not supply a thermodynamic law.

## 7. Current-feedback algebra does not restore the ideal oracle

Consider the separately stipulated ideal instantaneous law j=i+eta,
x=z+rj, with fresh independent spatial eta of covariance sigma_i^2I.
Substitute the actual series equation v=x-ri to obtain

    v=z+r eta,
    j=L_theta z+(I+rL_theta)eta,
    Cov(j)=sigma_i^2(I+rL_theta)^2.                      (P11)

This restores the ideal MEAN, not independent fixed-noise readout.
For a hub, L_ii>=ad and ||row_i L||^2>=a^2(d^2+d), giving raw variance

    sigma_i^2[1+2rad+r^2a^2(d^2+d)].

Thus a uniform raw hub-noise level at fixed a,r requires sigma_i=O(1/d)
under these independent-offset assumptions. Commands also have mean
(I+rL_theta)z and can grow with degree. Under nonzero Gaussian eta,
their random part r(I+rL_theta)eta has unbounded full support: this
ideal same-action loop does not automatically obey any deterministic
pathwise external budget B. Clipping, bandwidth, delay and stability
would require another complete law and analysis.

The feedback covariance depends on theta even at z=0. That covariance
can itself carry statistical information. Therefore P4--P7 for the
passive fixed-covariance observation law must NOT be transplanted to
this feedback experiment by keeping only its mean. Conversely, raw
variance growth alone is not an information lower bound against every
possible optimal correlated decoder/controller. The source presents
P11 as a stress/resource target and makes neither of those invalid
extensions. A Gaussian noise realization violating pathwise B is a
control on this distinction, not a counterexample to its passive theorem.

## 8. Voltage-sense feedback and correlations

Under the separately supplied ideal loop v=z-xi with independent
spatial sense errors Cov(xi)=sigma_v^2 I and separate independent
current errors Cov(eta)=sigma_i^2 I,

    j=Lz-Lxi+eta,
    Cov(j)=sigma_v^2 L^2+sigma_i^2 I.                    (P12)

Raw hub sense-noise variance is at least sigma_v^2 a^2(d^2+d), so
keeping it uniform requires sigma_v=O(1/d) in THIS independent-offset
model. Pure common-mode xi has covariance proportional to11^T and is
annihilated by L1=0. General calibrated correlations, extra sensing,
different readouts or feedback controllers are not excluded by P12.
Its raw diagonal bound is not a universal voltage-control/noise limit.

Neither feedback model establishes physical stability, response time,
power capacity, manufacturability, sensor cost or an implemented upper
protocol. These remain unacquired. P11 and P12 are algebraic controls
showing what the ideal Lx-plus-iid-noise interface omitted.

## 9. Newly acquired controls and primary instrument context

My standalone Fraction checker directly inverts complete I+rL matrices
in54 circuit cases, verifies5004 full rank-one entries,162 one-command
saturation cases and1944 feedback signal/noise basis vectors. It checks
1204 complete represented adaptive history paths,6412 same-history
conditional full-Gaussian KL identities, and1204 time-weighted paths.
The general adaptive theorem is P4--P7, not induction from those cases.
Common-mode cancellation and feedback covariance changes are tested
exactly. Fifty-four feedback noise witnesses violate a unit pathwise
command budget, detecting an invalid merger of the passive and ideal
instantaneous-loop classes.

For twelve explicit two-step policies, the full n-output likelihood
factors into a sufficient projection along u plus common independent
orthogonal Gaussian data. Action1 uses sign(u)/2; action2 repeats it
when the first acquired projection is positive, otherwise commands
the common-mode vector1/2. BOTH likelihoods use the same decision
function of the same observed projection. The exact chain-rule KL is
k1(1+p1), where k1=mu^2/(2sigma^2), p1=Phi(mu/sigma) and
mu=c||u||_2. New two-dimensional transcript quadrature agrees within
4.67e-15. These are floating synthetic controls, not interval-certified
proofs, sensor data or a built feedback circuit. Larger-d rows evaluate
only the exact rational closed forms in four specified impedance regimes.

The primary URL initially timed out. I independently hashed the retained
manufacturer PDF0697359aae9412045163401860a1a36c464dc57e3a14a3f3a6131865a1800a30,
confirmed its May2025 edition, and read actual PDF pages47--48. The
[Keysight manual](https://prc.keysight.com/Content/PDF_Files/N2820-97007.pdf)
describes series lead/shunt burden for certain heads and a different
head architecture without that head's added burden. This supports
context for one finite-r model and the need for architecture-specific
claims. It does NOT verify a uniform simultaneous n-port apparatus,
the model's fixed independent sigma, settling, operating range or cost.
No statement here asserts that a particular product implements P1/P4.

## 10. Verdict and preserved scopes

No blocking mathematical defect found in the exact passive model,
its arbitrary adaptive transcript lower bound, finite-n constants,
fixed-r scaling, variable-r target, charged averaging alternative or
the two explicitly separate feedback algebra statements. This is not
a universal electronics impossibility theorem. It does not negate the
previous ideal exact-node-voltage acquisition theorem; it specifies a
different external-command preparation/readout law under which its
constant-budget implementation cannot be assumed.

Source-method priority UNKNOWN; physical validation NOT_PERFORMED;
practical advantage/feasibility UNKNOWN; mission NOT_ACHIEVED. All
earlier compact-prior, two-round and quantum-code verdict bytes remain
unchanged. Actual instrumentation requires its own acquired complete
noise/control/settling/cost law before any positive advantage claim.

