# Direct efficient factory for the ORIGINAL inherited input

Internal theorem candidate, 23 October 2026. This is the final simplification of the preparation algorithm. It prepares the original Cycle10 pinch-normalized state at soft-O(k^2) quantum gate cost with precision logarithms, without changing that input and hence without needing the reversed-congruence drift comparison. The reversed-input theorem remains a separate valid candidate. The new generic ingredients are still established LCU, QSVT and amplification; the supplied short H access and the endpoint-label erasure are model-specific.

## 1. Definitions and exact scope

Keep the inherited model and operators from `POLYNOMIAL_PREPARATION.md`:

    sigma=diag(1/2,1/4,1/4)^tensor k,
    theta=gamma*b, gamma=ln(2)/4,
    C=I-theta H/2,
    D=P(C^2)=I+theta^2 P(H^2)/4,
    J=D^(-1/2),
    T=I+(4m/k)b^2(Q-k/2),
    rho = sigma T J C^2 J.                               (1)

k>=2 and r=bk<=1/256 ensure T>0 and Tr(sigma T)=1. H commutes with Q and sigma,T, and P(H)=0. P pinches COMPLETE binary charge patterns. No final full-pattern dephasing is applied to rho. The target (1) is exactly the inherited input, so every inherited rate/drift consequence transfers with no new state-comparison assumption.

All factory systems, including the helper purification, are local known encoder/workstation ancillas. The helper is not an unknown logical reference and is not remotely held entanglement. This is a factory for a known state, not an encoder for arbitrary logical quantum information.

## 2. Constant-cost H action on the known source

Prepare the canonical local purification of sigma T:

    |psi_T>_(A,R) = sum_a sqrt(p_a) |a>_A |a>_R,
    p_a=sigma_a*T(Q_a).

This uses the product sigma purifier, reversible charge count and the flagged sqrt(T/T_max) rotation, T_max=1+2mb^2=O(1). Its known source success probability is 1/T_max and can be amplified with constant overhead and precision logarithms.

Let N=binom(k,2). Prepare a uniform pair (i,j) and implement its acquired H_ij/2 block encoding. Before projecting its signal, the good component is

    (2sqrt(N))^(-1) sum_(i<j),a sqrt(p_a)
        |i,j> tensor H_ij|a>_A tensor |a>_R.              (2)

On every nonzero good matrix element, charge(A_output) differs from the original charge(a) in precisely i,j. The unchanged LOCAL helper R stores that original a, so compute the difference between charge(R) and charge(A_output), decode its two positions, and XOR them out of the pair register. Totalize invalid syndromes and uncompute decoder workspace as in `CONSTANT_GAP_RECTANGULAR_ACCESS.md`. Every good term in (2) now has the same pair label zero. Projecting all signal ancillas therefore gives exactly

    (H tensor I_R)|psi_T> /(2sqrt(N)).                   (3)

Unlike the earlier rectangular operator, no retained x flag is needed: the original charge information is already present in the known source purification. More formally let E=sum_x P_x^A tensor P_x^R project onto MATCHING input charge patterns. Compute this matching predicate into an initial good flag before applying the branch, and include that flag in the final good projection; the flag remains stored while A changes. This makes the reference-assisted good operator exactly (H tensor I_R)E/(2sqrt(N)). On E-perp the initial flag rejects, so a totalized invalid syndrome cannot contaminate the operator. The known source lies entirely in E. No normalization O(k) for H on arbitrary physical inputs is asserted; the restricted domain and helper dependence are essential.

Combine this unitary branch with identity by LCU. The identity source has identical A,R registers and padded zero work ancillas. The decoder is totalized to output zero on a zero charge difference, so the identity branch is also harmless. The combined good state is

    (C tensor I_R)|psi_T> /alpha_src,
    alpha_src=1+theta sqrt(N)<=1+gamma*r/sqrt(2)=O(1).     (4)

The source preparation can be composed coherently with the LCU; no intermediate successful measurement or bath operation is required.

## 3. A constant-normalization OPERATOR block encoding of D

Separately use the rectangular construction proved in `CONSTANT_GAP_RECTANGULAR_ACCESS.md`:

    B_H=sum_x |x> H P_x,
    alpha_H,rect=2sqrt(N),
    B_H^*B_H=P(H^2).                                    (5)

If U realizes the projected encoding A=Pi_L U Pi_R=B_H/(2sqrt(N)), the positive product is

    A^*A = Pi_R U^* Pi_L U Pi_R
          =P(H^2)/(4N)

on the physical input subspace. Pi_L is an efficiently testable signal projector that accepts every retained charge flag. Its block encoding is obtained by a controlled reflection about Pi_L; then U, that block encoding, and U^* give the product. No sum over 2^k charge flags is enumerated. The appropriate right zero-flag projections are part of the encoding, not physical bath postselection.

LCU with identity now supplies D at normalization

    alpha_D=1+theta^2 N
            <=1+gamma^2 r^2/2=O(1).                     (6)

This stronger normalization is acquired from (5), rather than starting with the O(k^2)-normalization operator H and squaring it. Since D>=I, its spectrum after normalization by max(2,alpha_D) has a constant gap from zero. The standard negative-power QSVT construction (Gilyén et al., Cor67, c=1/2) therefore supplies J/2 at operator error epsilon in O(log(1/epsilon)) queries. Each query has the soft-O(k^2) local simulator and symmetric-prefix cost already proved. It accesses no actual bath and no external reverse-device operation.

## 4. Assemble and normalize the original state

Apply the J/2 operator block encoding on A after the source-specific C construction (4). On the joint good signal the state is

    (J C tensor I_R)|psi_T> /(2alpha_src).               (7)

Its physical reduced operator is precisely rho/(4alpha_src^2), because sigma T commutes with J,C. Its squared target norm is exactly one before the explicit scaling:

    ||(J C tensor I)|psi_T>||^2
       =Tr(sigma T C J^2 C)
       =Tr(sigma T J^2 C^2)
       =Tr(sigma T J^2 P(C^2))
       =1.                                             (8)

Thus the combined good probability is 1/(4alpha_src^2), a positive constant. If the sigma T preparation flag is kept in the same coherent construction, the probability is 1/(4T_max alpha_src^2), also constant and known. Fixed-point amplitude amplification prepares the good purification with arbitrarily small prescribed error in O(log(1/epsilon)) calls to the complete local preparation circuit and its inverse. It is a known-state factory, so those inverses are available. Assigning a fixed state to its small residual failure component produces an ordinary CPTP approximate preparation, rather than a postselected communication process.

The J implementation itself takes O(log(1/epsilon)) pair queries, so a conservative direct composition has O(log^2(1/epsilon)) pair-query cost, with additional precision logarithms. The elementary gate cost is still

    soft-O(k^2) * polylog(1/epsilon),

O(k) local quantum workspace plus arithmetic precision, and classical compilation poly(k,L_b,log(1/epsilon)). No 3^k matrix, free quantum RAM, physical bath purifier, or spectral oracle is an input.

## 5. Exactification and coding boundary

Approximate gates can be synthesized inverse-polynomially more accurately than the target state budget. Only TOTAL-Q pinching is applied to the final factory output if exact charge preservation is needed. It contracts trace distance to the target and increases entropy; full-pattern dephasing would destroy the required input coherences. The established continuity bounds are

    drift change <=2k*trace_distance,
    entropy change <=trace_distance*k*log2(3)+h2(trace_distance).

Together with the precision bound in `PRECISION_AND_COMPILER_COSTS.md`, inverse-polynomial accuracy preserves the original strict margins. For any rate strictly below S(rho)/k, a finite synthesized factory can reach adequate accuracy before fixing the outer coding horizon. This does not prove an efficient outer encoder or decoder.

The factory uses exactly the ORIGINAL input and its complete-pattern-normalized coherence, so the only scientific dependencies for its original rate are the inherited theorem's own ones. The helper-reference trick here is an allowed local known-state preparation; it supplies no access to an arbitrary input reference in the communication protocol. Exact coefficient, improved rate, useful finite blocklength, novelty, hardware validation and practical advantage remain unresolved.

