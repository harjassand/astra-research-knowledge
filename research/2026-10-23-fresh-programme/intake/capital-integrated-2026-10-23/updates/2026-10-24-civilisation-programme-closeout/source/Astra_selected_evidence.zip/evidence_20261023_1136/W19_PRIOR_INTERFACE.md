# Exact inherited scope and the new beta0 interface

23 October 2026, w19. This is a scoped source/quantifier audit after the
independent beta0 strong-converse construction and full-source criticism.
It is not an exhaustive historical priority review. The pinned corpus is
`e606bfc587c76bdcae8b8fa3ec33e721efa2fbac`; exact byte identities, read
ranges and bounded lexical/routing searches are recorded in
`PRIOR_INTERFACE_SOURCE_LEDGER.json`, produced by `pin_prior_interface.py`.
No source corpus bytes were modified.

## 1. The value and the lower code are inherited

Cycle00 `pro1/RECURRENT_RESERVOIRS.tex` already proves the colored Dyck code
at lines281--300. Equation at291--292 is an OPERATOR identity on the code:
every physical bath vertex is returned and the same output injection is
performed. Line294 explicitly extends it to arbitrary coherent bath
states and external references. For d3 its rate tends to3/2. Thus the
value3/2, the Dyck construction and its bath-identity property are NOT new
discoveries of the present worker campaign.

The identity also supplies the lower direction for the enlarged initial
resource class: tensoring the code operation with the identity on E leaves
any initial E:whole-laboratory entanglement intact. A fresh logical input
remains independent of that whole resource. This is an immediate inherited
operator-identity consequence, not a newly invented entanglement-assisted
encoder or a physically acquired code. Finite-block construction, depth,
encoder complexity and physical gate access are not made free by that
logical observation.

## 2. The inherited upper bound has a narrower quantifier

Cycle00 lines304--340 bounds each vertex-conditioned Kraus rank and obtains
`F<=a_d^N/K`, with `a_d=2sqrt(d-1)`. Lines329--333 are uniform over every
vertex-diagonal density, so the same bound already extends immediately to
horizon-dependent DIAGONAL product baths. That easy extension is inherited.

For coherent normal baths, lines335--340 first choose a FINITE SET OF VERTEX
COORDINATES, with r elements and retained mass at least1-epsilon, and prove

    F_N(tau)<=r a_d^N/K + sqrt(epsilon).

The source then fixes that cutoff before sending N to infinity and only
afterwards enlarges it. It explicitly declines a uniform exponential
coherent-tail rate. The ordinary capacity theorem at342--350 quantifies
over each fixed normal initializer. It does not supply the present
initializer-independent exponent for arbitrary coherent tau_N, arbitrary
initial E:whole-laboratory entanglement, or quantum backward feedback.

Cycle01 `FEEDBACK_AND_STOPPING.tex` line55 makes the inherited operational
boundary explicit: the normal bath is fixed across horizons and initially
independent of the logical source AND local laboratories; no preshared
entanglement or backward quantum wire is supplied. Lines149--162 derive
the backward-CLASSICAL transcript bound with initially unentangled labs.
Lines205--220 retain the diagonal uniform estimate and coherent fixed-
cutoff order of limits. Those are substantive earlier results; a general
quantum-feedback/initially-entangled-resource converse is not among their
stated conclusions.

## 3. Latest governing integration does not silently enlarge that scope

The scientific-cycles `CURRENT.md` lines16--38 reports the Cycle11 whole-
bath entropy/displacement result with initially independent input and
normal bath. It expressly calls the new converse neither unrestricted
capacity nor feedback capacity. Cycle11 `COMPLETE_PROOF.tex.txt` lines108--112
excludes preshared entanglement and backward quantum communication and
specifies fixed-call unassisted encoders/decoders. Its stronger arbitrary
input correlations refer to the finite-port input state, not preexisting
correlation of a fresh logical source with a bath/laboratory resource.

The current agent notice/status registries were parsed through selected
summary fields and the recurrent lexical routes were checked. The obvious
recurrent dossiers N181/N339/N77 concern reaction recurrence, harmonic
lifetime and stationary tightness, respectively. A broad `coherent counter`
asset hit concerned energy-exponent preparation, not the present port-wire
converse. No target all-resource strong statement or this sector-counter
proof was found in those scoped searches. This does not establish absence
from every archive, dependency, unpublished source or external literature.
The immediate canonical Pro1 text scan covered129 files. Its five
`sector...counter` lexical hits all refer to Cycle11's rare-sector
COUNTEREXAMPLE and its status notices; the actual theorem at1042--1080 is
an abstract charge-preserving fake-response concentration obstruction,
explicitly not a physical channel-history construction. It is not the
coherent aggregate COUNTER process used here. The source ledger retains
every such hit rather than interpreting a substring match as a theorem.

## 4. Exact claim that may be carried forward internally

The present full proof `FULL_STRONG_CONVERSE_V1.md`, hash
`1f5997c7ba33c13e6f1a1a9f1cff183d68bad1a876b63f1c7a6ef3989bed16c7`,
gives a finite-N exponential upper bound, uniform over arbitrary NORMAL
eta_N of the entire persistent bath and all laboratories. Eta_N may vary
with horizon and include arbitrary E:whole-laboratory entanglement and
Alice--Bob preshares; backward quantum communication is allowed. The
fresh source is product with the ENTIRE eta_N, and the prescribed qutrit
calls are the only forward path. No postselected normalization is allowed.

With D_q=binom(N,q)2^q and the exact dimension sum S_N, the separate
w49-attributed aggregation improves the original polynomial to

    F<=S_N^2/K^2<=100*8^N/[(N+1)K^2].

The enlarged whole-resource/feedback quantifier, explicit uniform
finite-horizon bound and its sector-counter evaluation are the actual
internal interface under review. The numeric capacity value and matching
lower code are inherited. W36 independently developed a weighted
postselected-teleportation route before reading this construction, then
reconstructed the full sector-Choi proof; both routes and their chronology
are preserved. W49 supplied the sharper aggregation after the full proof
was frozen. Generic finite-wire CP/replacer comparisons, no-signalling,
positive linking and teleportation are established tools, not novel
scientific primitives claimed here. Historical novelty remains UNKNOWN.

## 5. Positive-beta history expansions are also inherited tools

Cycle01 lines395--441 already expands the coherent device
`alpha U+i beta I` by identity-site subsets, retains the complex history
amplitudes in an adaptive circuit, and charges a factor3^k for k identity
qutrit slots. It warns that the expansion is not a stochastic-mixture
model and a block-channel error estimate is not automatically an adaptive
strategy estimate. Any new all-resource soft-history consequence must
credit this mechanism and prove the broader causal/resource interface;
the expansion itself is not a new invention. A quadratic weak converse
does not by itself imply a quadratic exponential strong converse.

## Evidence and costs

The source reading/search uses already supplied local historical text.
The identity/hash pass and lexical search establish transport/routing
scope only; they are not theorem, novelty or physical validation. No new
experiment, bath state, apparatus, gate calibration, source factory,
reset, energy advantage or practical acquisition has been performed.
The independent finite sector diagnostics remain finite computations;
the all-N statement is the analytic proof, separately audited at its
exact frozen bytes. The remaining hard positive-beta all-resource strong
converse is not closed by this priority audit.
