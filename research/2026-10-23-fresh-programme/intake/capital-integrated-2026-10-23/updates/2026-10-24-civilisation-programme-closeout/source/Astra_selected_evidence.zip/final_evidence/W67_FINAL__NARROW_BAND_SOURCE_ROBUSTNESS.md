# A fixed source needs only a polynomial-precision public gain promise

23 October2026. New post-freeze component candidate, NOT independently
reviewed. It preserves the known-parameter finite rows and their reviews.
It does not supply parameter acquisition from the physical device, a
factor-two-band source theorem, or a free feedback/forward wire.

Let the source be built from a supplied rational reference b_ref obeying
the V4 theorem, with k=floor[1/(5b_ref)]. Put
theta_ref=arcsin sqrt(b_ref). The analytic source, table, filters, code
dimensions and full circuit are functions of this REFERENCE only.
The actual fixed unknown theta can lie in the supplied public interval

    |theta-theta_ref|<=dtheta, dtheta=Kappa/(8k²),
    Kappa=1/288000.                                  (B1)

An interval with rational endpoints contained in B1 can be constructed
by finite interval arithmetic; theta_ref is not supplied as an exact-real
oracle. Its required precision is O(log k+log(1/Kappa)) bits, independent
of the later message horizon. Source b_ref and its exact integer k remain
ordinary finite classical inputs. The input promise B1 must not be
described as an observation acquired by this work.

## 1. Full operator drift is uniformly stable

For either unchanged static sector s,

    V_(s,theta)=U_s exp(i theta U_s), U_s²=I,
    ||V_(s,theta)-V_(s,phi)||<=|theta-phi|.

The k-call ordered words on the ENTIRE infinite bath therefore satisfy

    ||W_(k,theta)-W_(k,phi)||<=k|theta-phi|.

The total port charge Q has norm k, so for
G_theta=Q-W_(k,theta)^*QW_(k,theta),

    ||G_theta-G_phi||<=2k²|theta-phi|.                 (B2)

No derivative of an unbounded depth observable is taken. These bounded
operator identities retain the actual root and arbitrary coherent bath
vectors. Partial expectation against a normalized input density is a
unital completely positive contraction, hence

    ||D_theta(rho_*)-D_theta_ref(rho_*)||
          <=2k²|theta-theta_ref|.

The source's supplied negative bulk drift at theta_ref is at most
-Kappa I. Thus B1 gives the uniform bound

    D_theta(rho_*)<=-(3Kappa/4) I
                  <=-Kappa_uniform I,
    Kappa_uniform=Kappa/2.                           (B3)

Its entropy, exact Q commutator, relative-density gap, chi² and table
probabilities are unchanged, because the source was not rebuilt at the
unknown actual theta. Flush probability a=cos²theta remains>=1/2 under
this tiny interval. The source/access circuit simulates the known family;
it never queries the actual device at a calibration angle.

## 2. A common finite program needs a uniform parent-tail event

A uniform source drift does not on its own make a pointwise parent
Markov event simultaneous over the continuum. Pay that step explicitly.
Let R>=16 n_body as before, and require terminal flush<=n_body. Then
T<=2n_body and2T<=R/4. The vacuum-word amplitude K_theta satisfies
||K_theta-K_phi||<=T|theta-phi|, so the parent mean bad effect

    mu_bad(theta)=Tr[I-K_theta^*K_theta]/D

has Lipschitz constant<=2T<=R/4, uniformly for every fixed pure parent.
Use an analysis grid of mesh q/(16R) over B1 (its length is<1). A safe
grid-size upper bound is2^Bgrid with

    Bgrid=Bq+log2R+5.                                (B4)

The grid is a proof device; no actual device experiment or explicit
evaluation of its points is performed by the code constructor. Its
cardinality must nevertheless enter the Markov/union budget.

In the source Lyapunov and all finite policies replace Kappa by
Kappa_uniform. In G8 add Bgrid+8 in the cutoff numerator. This makes
the GOOD-PROGRAM averaged body-tail at each grid point smaller than
eta_parent*q/[64*2^Bgrid]. Markov at q/4 and the grid union cost at most
eta_parent/16. Choose terminal zeros with the slightly stronger

    n_flush=16(H+Bq+6),

so the uniform descent probability is<=q/4. Each grid point then has
parent mean final-word deficit<=q/2. The Lipschitz interpolation adds
at most q/64; allowing a safe q bound has spare constants.

Consequently the SAME randomly programmed parent has mean deficit<=q
throughout B1, except for the charged uniform event. The common Fourier
cross-Gram event already holds for every theta because it controls a
fixed finite error span. Its bad-word/polar argument therefore applies
to the entire band with one encoder and one receiver. No actual theta
or static-sector estimate is sent to the encoder or receiver.

The original exact selected rows are NOT reused numerically: source
Kappa, eps/B0, the added Bgrid, H, terminal calls, moments and rate
guards must be recalculated. All changes are polynomial; Bgrid=O(log
n_body+log(1/z)). The full native/initializer/public-table qualifications
are unchanged. This note does not assert that such new rows were run.

## 3. Scope of the rate and input promise

For k>=3276, B1 implies dtheta<=sqrt(b_ref)/4 (the rational squared
inequality is elementary). Since sine is1-Lipschitz,

    b_actual=sin²theta <=(sqrt(b_ref)+dtheta)²
                              <=25b_ref/16<2b_ref.

If the recalculated code retains excess G/(16k), then

    G/(16k)>=b_ref/59520>=b_actual/119040.            (B5)

The purpose is to replace an exact-known-physical-parameter interpretation
by a fixed finite-precision public promise. It remains a narrow promise:
width Theta(k^-2) in theta, much narrower than a factor-two interval in b.
The theorem does not find that interval, recover a time-varying parameter,
or authorize backward calibration communication. Known model formulas
and reference source circuits are supplied information. If the initial
parameter location is unavailable, actual acquisition remains unresolved.

This component has no numerical execution, physical test, external review,
practical-advantage or novelty claim. Mission NOT_ACHIEVED.
