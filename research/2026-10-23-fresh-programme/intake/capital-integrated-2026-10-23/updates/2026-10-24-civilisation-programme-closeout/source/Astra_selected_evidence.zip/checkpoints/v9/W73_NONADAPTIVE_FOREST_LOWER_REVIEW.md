# Independent root reconstruction of the noisy-forest action lower bound

23 October 2026. Verdict: **INTERNAL CONDITIONAL PASS; no blocking defect found** in the all-design mathematical lower bound and its stated comparison with the direct adaptive decoder. This is a full analytic reconstruction, accompanied by finite independent diagnostics. Priority, a new physical acquisition capability, practical advantage and mission achievement do not follow. The review is correlated model-internal review, not external certification.

Frozen lower reviewed: `work/workers/w73_fresh_foundational_inventor/NONADAPTIVE_NOISE_LOWER_BOUND.md`, SHA256 `92f10ca28af3b945c166bf20de3290b348f58f6f5b6ac8003ae41aae32d124bb`. Also read the complete `DIRECT_STOCHASTIC_NOISE_PROOF.md` (`ee0680992c18fc63716c0860330848919cd2e8ee97326aa4181cf3350dc188be`) and its complete checkpoint-2 `ADAPTIVE_NOISE_PROOF.md`. The later fast-code and two-round-star claims are outside this verdict.

## Exact reviewed contract

The unknown input is fixed before control randomness: an even-n labelled positive forest Laplacian, all nonzero weights in [a,3a], a>0. Each complete action prepares all n input coordinates and acquires all n output coordinates with independent N(0,sigma^2) sensor errors. Every supported nonadaptive design satisfies sum_t x_ti^2 <= B for each vertex. The decoder may be unbounded and may learn the two hubs and the complete leaf partition after committing the design. This post-design information strengthens the lower-bound learner. No topology or weights are chosen after observing its random design.

For epsilon+delta<1/2 and K^2=2 ln[2(n-2)/epsilon], the claimed necessary condition is

    q [K^2 + 8 a^2 B / sigma^2] >= n(1-2delta-2epsilon)^2.

This counts full n-output actions. It is not a lower bound on one-coordinate query access, nor a noiseless statement.

## Reconstruction of the experiment and information accounting

Choose the two hubs uniformly and partition the remaining vertices into equally sized stars. The only hypothesis-dependent edge is the hub edge, of weight a. Initially use independent auxiliary Gaussian leaf weights of mean mu and variance tau^2. Negative auxiliary weights are permissible in this intermediate analytic Gaussian experiment; Section 5 removes them before any promised-input conclusion.

For a fixed design let s_i be the q-vector of controls at vertex i. A leaf attached to hub u has full observed row w_l(s_l-s_u)+Z_l. Conditioning on all leaf rows gives independent leaf-weight posteriors with variances

    v_l = [tau^-2 + ||s_l-s_u||^2/sigma^2]^-1.

These posterior laws are identical under the two hypotheses. The conditional hub means differ by +/- a(s_u-s_v). Each hub's conditional covariance is sigma^2 I + sum_l v_l r_l r_l^T, with disjoint leaf sets and independent hub noises. Therefore the conditional hub rows are independent. The relative-entropy chain rule gives exactly the source's Eq. (2): a^2/2 times the sum of the two inverse-covariance quadratic forms. This includes every leaf observation through posterior uncertainty; it does not pretend that nuisance weights were unobserved or supplied exactly. The covariance is independent of the realized leaf values, so no additional averaging term is missing.

For the ridge lemma, sample a (d+1)-set T and then a uniform j in T. This is exactly the same law as the independently described uniform j and uniform d-set excluding j. Set G=lambda I+sum_T r_l r_l^T and h_j=r_j^T G^-1 r_j. Sherman--Morrison yields t_j=h_j/(1-h_j). The deterministic bound t_j <= R^2/lambda and identity sum_T h_j=tr(I-lambda G^-1)<=q imply

    E t_j <= (1+R^2/lambda) q/(d+1).

No incoherence or distribution on the fixed vectors was used. Centering the design at a fixed hub is legal. All residuals have norm squared <=4B. Taking v_*=[tau^-2+4B/sigma^2]^-1 and lambda=sigma^2/v_*, inversion of the positive-semidefinite covariance lower bound and this ridge inequality give Eq. (4). Since d+1=n/2 and the symmetric hub has the same estimate, their two factors and the a^2/2 Gaussian prefactor give precisely

    D(P_1||P_0) <= (2 a^2 q/n) [tau^-2+8B/sigma^2].

The freely revealed metadata has the same distribution under both hypotheses, so its inclusion is handled by the entropy chain rule. A random nonadaptive design can be included as an independent transcript variable and averaged conditional on its seed. The uniform deterministic-design bound survives that averaging.

## Positive-input transfer and testing

Set mu=2a and tau=a/K. Conditioning all n-2 standard Gaussian leaf nuisances to [-K,K] fails with probability <=epsilon by the explicit union bound. The conditioned input prior is supported entirely on [a,3a] forests, including the optional weight-a hub edge. This input event is independent of design randomization. It changes each hypothesis's transcript by total variation at most epsilon, by data processing. It conditions the input weights, not sensor noise.

Pinsker then bounds the promised-hypothesis transcript TV by

    sqrt{(q/n)[K^2+8a^2B/sigma^2]} + 2epsilon.

Any test having error <=delta on every fixed promised input has equal-prior average error <=delta under the conditioned input prior; its transcript TV must be at least 1-2delta. Squaring the resulting nonnegative inequality proves exactly the displayed necessary condition. The lower does not exchange a worst-case graph with a graph selected after the control seed.

## Independently checked upper comparison

I reconstructed the direct decoder and the checkpoint-2 contraction proof. Inactive acquired components are actually set to zero in every code action, so internal edges are nulled before acquisition; fitted weights are never subtracted. Positive mixtures have certificate sum_k w_k d_H(b_k,b_j). A good code gives the gap a ell/4 against every wrong candidate. The ell repeated mass actions are necessary and explicitly counted: they reduce the repeated mass-error contribution to certificate variance <=2 ell sigma^2. The stated margins and union bound have slack. The ideal-process/first-failure coupling makes the adaptive noise argument valid without conditioning progress on future noise success.

Every nontrivial quotient forest has at least half its vertices of degree 1 or 2. An inactive such component with exactly one active neighbour occurs with probability 1/4 and exposes a genuine edge. These witnessing components expose distinct edges, giving the 7/8 contraction. Thus the direct upper uses Q=2 ell T=O((1+sigma^2/a^2) log^2(n/delta)) full actions and nominal row energy at most Q. Its naive arithmetic cost is O(n^2 ell T); this review does not replace it by an unreviewed fast decoder.

For fixed a/sigma and fixed error, the lower with B<=q gives Omega(sqrt n) actions; at matched allowance B=O(log^2 n), it gives Omega(n/log^2 n). The direct adaptive upper fits that allowance. The unit-row-energy corollary is also consistent: c=ceil(sqrt Q), sigma_n=a sqrt(ell)/(32 c sqrt Lambda) yields rescaled noise exactly satisfying the direct upper bound. Thus sigma_n=Theta(a/log n), Q=O(log^2 n), B<=1 and the nonadaptive lower is Omega(n/log^2 n). It is essential to retain this noise scaling; there is no B=1, fixed-nonzero-noise full-support upper theorem here.

## Independent diagnostics and limitations

`work/root/check_forest_adaptivity_lower.py` imports no producer code. `FOREST_ADAPTIVITY_INDEPENDENT_CHECKS.json` records PASS on 48 exact rational leverage aggregates comprising 1,156 terms, plus 30 fixed designs and 3,060 full metadata cases comparing a direct n q-dimensional Gaussian covariance calculation with the conditional-posterior formula. Largest floating identity discrepancy is 5.64e-11, with the script's explicit relative tolerance. Exact rational calculations establish their finite identities; floating diagnostics are not the universal proof.

The claimed advantage is mathematical action/energy adaptivity under a supplied stable full-control/full-readout Gaussian interface. Scalar readouts, dynamic range, preparation accuracy, resets and time remain paid scientific interface obligations. At worst-case degree n-1, preparation errors can require order 1/n coordinate accuracy. The naive upper's arithmetic cost can exceed the nonadaptive action lower, so an end-to-end computational advantage is not established by this comparison. Novelty must still be checked against strong primary literature on noisy graph reconstruction, active sensing and matrix-vector acquisition. Physical trials: zero. Broad mission: NOT_ACHIEVED.
