# Conditional finite/native binding of the mesoblock encoder

W67, 23 October2026. NEW INTEGRATION CANDIDATE, not independently reviewed.
It binds the ideal encoder26c7092c, finite guard sidecarbaea9faf and raw
selected guards0ec806a0 to two fresh scope-bound reviews. It does not
rewrite any frozen source, review, quartic code or first candidate.

The intended theorem is a MONTE CARLO quantum-generated public program:
for a supplied known rational b=beta² with beta<=1/128, an acquired V4
source/access circuit, target error z and confidence eta, it outputs a
finite encoder/receiver program. Except with the charged program-failure
probability, it transmits arbitrary quantum/reference states at positive
beta-SQUARED excess, with a joint-polynomial gate/call/onset bound in
k=Theta(beta^-2), inverse accuracy/confidence and parameter bit length.
The shared-program convention and supplied initial-state tail remain
explicit. This candidate does not claim a deterministic certified seed,
a polynomial CLASSICAL table constructor, a factor-two unknown-gain
source, a useful hardware budget or a priority result.

## 1. Reviewed mathematical and acquired-access dependencies

The first source-encoder proof is
MESOBLOCK_FILTERED_FRAME_CANDIDATE.md, SHA256
26c7092cee2414b7681ea7c92b5f87e74b9f2482399a2a397697f2cbe4b784b2.
W49's complete independent ideal review is
mesoblock_audit/INDEPENDENT_HARD_MATH_AUDIT_V1.md, SHA256
df4eb8b07f296adcad147026138cb757b92bac29cd89515bfa5b86565d8974b3.
It finds no blocking defect in M6--M16 conditional on their stated
premises. Its bounded-width-rejection and all-Good qualifications are
implemented in the separate finite sidecar; they are not silently
backdated into the first proof.

W39's acquired-access reconstruction is
recurrent/MESOBLOCK_FUNCTIONAL_ACCESS_RECONSTRUCTION.md, SHA256
cf90b44c29170ef321da0026c4fbef11f3f94d50210f661a43ee471dfe765aa8.
It checks relative/log/filter/bin/charge-embedding and conditional
global-unitary interfaces, not the full finite ledger or program model.
The scoped source premise is W56 V4b37eccac, unchanged. All inherited
actual-device root, colour, normal-initializer and static-sector contracts
remain as in the preceding reviewed code. Nothing factors H into a
classical colour mixture or ordinary collective hopping.

## 2. Explicit finite function access and precision allocation

For the analytic clipped source put

    M_B=1+(4/25)b k(k-1), T_max<=2,
    M_*=(I+T J B J)/2>=I/2.

W39 A1 gives an actual block normalization

    alpha_*=(1+8T_max M_B)/2,

not merely the smaller norm bound L0=1+T_max M_B. Use that acquired
normalization in every normalized polynomial/function constructor. Its
H access is an explicit known local word simulator; the older reviewed
O(k²)-up-to-logs implementation suffices. The optional faster router is
not required for the polynomial assertion. Source instruments, retained
input-pattern Gram, inverse-root compiler, coefficient acquisition,
rotations, Hamiltonian simulation, helper resets, controls and adjoints
are counted constituent algorithms, not oracle inputs.

For n=kt and bin cutoff w, choose

    a0=ceil log2(1+2M_B),
    xmin=-max(t,w)-2,
    xmax=max(t a0,w)+2, R_domain=xmax-xmin.

These integers contain the full analytic L spectrum away from phase
wraparound. The bin vector includes an explicit reject amplitude, so it
is normalized globally. Its Lipschitz constant is<2. The weighted filter
amplitude a_j is<=4/5 and its full coin vector has Lipschitz constant<=5.
These facts are used at the SAME exact L; no noncommuting operator-
Lipschitz assertion is inferred from scalar smoothness.

For a required full function-isometry error xi_A choose the next dyadic
phase-estimator length

    T_PE>=ceil[(40R_domain/xi_A)^2],
    delta_L=xi_A R_domain/(1024 T_PE).               (N1)

W39's exact QPE mean-square bound and Duhamel telescope prove this
suffices after the source/log/arithmetic/simulator/native error split.
Pi<4 makes every displayed choice rational. It is enough to acquire
the clipped B to operator error

    delta_B<=delta_L/(16t M_B),

and each source logarithm to error delta_L/(2t). The former contributes
at most delta_L/2 to the total L error by A1/A2, the latter at most the
other half. Native errors are further split across the actually counted
subroutine calls. No inverse sigma or exponentially small rho eigenvalue
is used. State-factory accuracy for probability sampling is a separate
trace error; it is not substituted for this operator-relative accuracy.

Because the source factory and these uniform functions have explicit
polynomial constructions, let P_access(k,t,L_b,xi_A^-1) denote the SUM of
their paid quantum gates, classical bit operations, working precision,
description output and resets at N1. This is a shorthand for the bound
of those constituent circuits, not one free matrix-function query. Its
normalizations, T_PE and required source/log errors are now specified.
The source's finite phase-instrument or elementary normalizer routes
are valid alternatives; their distinct classical work is retained. No
small power of k is claimed for this composed polynomial.

## 3. From full function isometries to one consistent encoder unitary

Two full-unitary completions make inverse/control/range statements safe.
If a known unitary U implements an isometry C on a known input embedding
R with ||UR-C||<=e<=1/4, W39 A6 proves there exists ONE exact unitary U0
with U0R=C and ||U-U0||<=9e. The proof uses a direct subspace rotation
and then a within-range frame correction, retaining global phase. U0
is a comparison object; no U0 circuit or spectral data is called.

First apply this to the phase-estimation/filter coin isometry. Thus an
explicit approximate functional circuit approximates one consistent
full unitary whose signal block is exactly A_j. Stored inverses and
controls approximate that same completion globally, including dirty
other helpers in the polar algorithm. Its additional factor9 is paid.

For the filtered frame S=A V R_K, all-Good guarantees

    s_min(S)>=sqrt[(1-tau)mu_min].

Put Bgap=ceil[(Bmu+2)/2], g_gap=2^-Bgap. This is a conservative known
singular gap. Hermitian dilation plus the previously reviewed ordinary
walk/Haah construction implements an odd bounded sign approximation;
no fractional walk, source eigenbasis or exact sign oracle is supplied.

For the aggregate per-inner global encoder budget Delta, set

    B_Delta=ceil log2(1/Delta), Bsig=2B_Delta+32,
    delta_sig=2^-Bsig.

An odd majority polynomial degree at least8g_gap^-2(Bsig+2), scaled
strictly inside the unit ball, has ample sign error<=delta_sig on the
gapped spectrum. Its dyadic coefficients are finite and constructible.
After odd rounding and the paired-walk Haah compilation, a conservative
row-query ceiling is

    Q_inner<=2^(2Bgap)*64(Bsig+1).                    (N2)

Stable phase generation, including intermediate working bits, costs
O(Q_inner³ polylog(Q_inner/delta_sig)) in the established constructor;
phase sequences and native output emission are paid. More efficient
standard sign polynomials may improve this bound but are not needed.

Compile every functional occurrence to

    xi_A<=delta_sig/[2^12 max(1,Q_inner)]             (N3)

before the factor9 completion. All Q_inner substitutions then cost
less than a fixed small fraction of delta_sig. The frame design circuit,
scalar phase sequence and native gates receive comparable full-operator
subbudgets. Their accuracy is operational, not a claim that the native
random circuit itself has the tiny ideal moment error.

A conservative final good signal-block error is<=4delta_sig. W39 A7
gives full-isometry error<=sqrt(8delta_sig), and another A6 completion
gives global encoder error<=9sqrt(8delta_sig)<Delta. Equivalently, the
squared signal-block tolerance is essential: a merely Delta-sized block
error would generally leak at order sqrt(Delta). The present Bsig policy
has substantial room below Delta²/200.

The same exact-completion comparison supports U/U*, controlled-U, and
range reflections. There is no inverse of a CPTP legalization channel.
The ideal good-seed C is exactly charge-q/legal. Actual encoder output
may be physically legalized and charge-pinched by a CPTP conversion;
contraction preserves its ideal-target channel error. Digital receiver
calls use the known unitary before that conversion, together with the
same comparison completion.

## 4. The parent and the reviewed universal receiver

The finite sidecar caps width sampling at two attempts, with counted
failure<=eta_w². Conditional on accepted cells, each frame failure is
<=eta_f even after width conditioning. A fixed public prefix supplies
one pure common logical slice. Thus on all-Good

    E_program C_parent(I/D)C_parent*<=F rho_*^m,
    lnF<=5eps*s+2eta_w, m=st.                       (N4)

The indicator form M16 is the rigorous statement; bad programs remain
total CPTP operations with a charged probability. The native comparison
does not remove that indicator or certify an individual seed.

Using source negative drift Kappa and the actual low-depth term, G8
and G9 choose a final body cutoff and count terminal zeros so the parent
mean vacuum-word deficit is<=2q, except with the additional parent
Markov probability. The source body is not an iid bath and no radial
closure is used. Initial zeros and the supplied/pointwise normal-state
tail are charged separately. Every zero call is part of the rate.

Supply C_parent to the already reviewed finite Fourier/common-cross-Gram
receiver. The digital word uses the exact root and a finite stack of
length at least the ACTUAL number T of body-plus-terminal calls, never
an inaccessible bath inverse. Both static sectors are included and
their sector/reference coherences retain the original orthogonality
argument. For R>=2(2T+1), the Fourier synthesis coefficient norm² is
<=R, not1. The same full operator KL bound and CPTP cutoff are used.

The outer ideal high-design sacrifices Bq bits, q=2^-Bq. G8--G10 make
the parent mean-tail, moment/denominator, physical row-count and rate
guards compatible. With omega=128R sqrt(q), nu=z²/(2^16R), xi=z/128,
the scalar checks imply

    sqrt(R omega)<=z/256,
    sqrt(2q+R omega)<=z/256.

Together with2sqrt(Rnu)=z/128, the ideal body/receiver diamond bound is
<=3z/32. The illustrated initial-tail prefix contributes<=z/32. These
are the same algebraic receiver budgets, newly evaluated at the actual
new parent/horizon, not old numerical rows transferred by analogy.

The explicit outer bounded-sign construction supplies Q_outer=4n+4.
The factored full row repeats the ENTIRE parent encoder I=Q_outer+1
times, including all child designs, filters, polar circuits and charge
coordinates. The matched baseline receives the same valid factoring.
Take

    Delta_parent=z/[2^12 I],
    Delta_inner=Delta_parent/(8s).                  (N5)

The global comparisons above make every repeated stored parent encoder
call accurate to its budget. All other outer digital, Fourier, sign,
phase and native operations receive aggregate error<=z/4. The total is
strictly below z, with spare constants. Error budgets depend on the
ACTUAL repeated-query envelope; the old quartic m5 gate exponent is
not inherited.

## 5. Complete cost structure and supplied information

One inner design at width E=2kt, order2h and design accuracy bits Bdes
uses the explicit finite Pauli step/seed count in the scalar packet,
plus the exact left Pauli twirl. Its target gate count includes every
Pauli-string parity gate and native angle synthesis. Each of the
Q_inner polar row calls includes the complete design circuit, the
bounded function at N1--N3, charge-rank embedding, signal reflections
and inverses. Denote their actually expanded quantum gate sum by

    G_inner<=Q_inner*[G_design+G_charge
                    +P_access(k,t,L_b,xi_A^-1)
                    +poly(kt,Bsig,log(1/Delta_inner))].

The large inverse xi_A includes Q_inner itself; one must not replace
P_access by a constant query. At N1, T_PE grows quadratically in that
inverse accuracy, and the acquired source/log precision follows it.
Consequently this bound may have a much larger polynomial degree than
Q_inner alone. The scalar output's Q_inner and phase logarithms are
partial primitive envelopes, NOT full native code gate counts.

One parent costs sG_inner plus polynomial prefix/control/coordinate
work. The quantum code then costs at most

    I*sG_inner + I*G_outer_design
       +Q_outer*G_digital_row(T)
       +poly(Q_outer,kt,s,log(1/z)),                 (N6)

with the previously supplied local coherent digital word/DFT/validity
implementations. Classical work additionally includes BOTH inner and
outer stable phase construction, all coefficient/scalar acquisition,
classical probability-table computation, every sampled seed and the
actual full circuit descriptions. Source preparation, sampler trials,
local measurement/reset operations and the O(table_cells*table_bits)
public probability table are explicit quantum/classical preprocessing.
None of these is included for free in N6.

For fixed positive margins G,Kappa,c, t=O(log k), w=O(log k), and
Bmu=O(log k). Hence mu_min^-1, Q_inner and all N1--N6 constituents are
fixed polynomials in k,s,z^-1,eta^-1,L_b. Very small eta may require
increasing t until h<=K; t=O(log k+log log(s/eta)) suffices, preserving
a joint-polynomial bound. The source was chosen at k=Theta(beta^-2),
so these are joint-polynomial in beta^-1 as a formal scaling statement.
The finite forward policy finds s by exact doubling; nonlogarithmic
padding slope is tiny by eps=O(k^-6), and remaining terms are logarithmic
in s. Thus that search also has a polynomially bounded stopping value.

The packet supplies THREE exact integer/Fraction illustrative horizons
at z=.001 and eta=.01, not giant compiled codes:

| beta | k | t | Bmu | actual forward calls |
|---|---:|---:|---:|---:|
| 1/128 |3276|67108864|10683|2027745784349686312784312598608|
| 1/512 |52428|67108864|10711|8307548208595766840594898275993936|
| 1/2048 |838860|134217728|21227|68056408480476979321468946994890740496|

All initial/body/terminal calls are included. The target finite excess
G/(16k)>=beta²/59520 is positive, but source/filter/query/table/phase
costs are huge. Even the first useful inverse-fraction bound alone has
thousands of bits. Polynomiality does not establish a useful cost,
wall time, physical advantage or dominance at every finite beta.

Inputs: the exact known recurrent interaction family, known rational
source parameter and bit length, analytic V4/source bounds, local
coherent finite universal gate model, target error/confidence and a
supplied initializer tail for a numerical horizon. Acquired information
in the proposed algorithm: a finite source-probability table through
known LOCAL quantum circuits and a finite random program. It acquires
no physical device/bath calibration, source eigenbasis, Gram matrix,
hidden bath labels, feedback or message-dependent wire.

## 6. Shared public programs and baseline limits

The quantum-generated table and all seeds are PUBLIC, fixed before the
message, with counted output bits and generation/storage/emission cost.
They are not preshared entanglement or runtime forward feedback. This
is a stronger construction resource than a purely classical compiler.
If a problem insists that every public-table bit be distributed through
the same forward device, a paid classical/bootstrap transport and its
initial-tail/error budget must be added; this note does not declare that
case closed. If public random seeds are excluded altogether, the earlier
random-program code convention also changes. No free wire is inferred.

An equally informed baseline can use all the same QSVT, matrix
concentration, rejection sampling, finite designs, polar transforms and
error-set recovery. These are established operations. The previous
Schur multiplicity branch has exp(k) onset from f_lambda<=sqrt(m!), but
that is a route-specific obstruction, not a lower bound for all source
encoders. This candidate supplies an alternative under the special
charge/relative-density/moment/access contract. Its generic priority and
the best prior end-to-end cost remain UNKNOWN. Source authorship is not
inferred from compiling its encoder. No physical experiment was made.

Pending: fresh integrated criticism of the actual guard/count policy,
shared-program interpretation, full native aggregation N1--N6 and
probability/error/rate quantifiers. This is not a declaration that the
quadratic mission or a civilisation-changing discovery was achieved.
