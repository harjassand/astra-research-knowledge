# Fresh audit: uniform vertex CP domination and correlated bath resources

23 October 2026. W62. **PASS for corrected frozen V2. The literal full-CP
distance-function step in V1 is false and is not approved.** V2 repairs it
by separating a positive scalar kernel from the physical CP transfer. No
fatal gap was found in the corrected theorem or its stated correlation
consequences. This is an independent analytic audit with exact finite
diagnostics, not formal verification, external acceptance, novelty evidence,
or a physical experiment.

Reviewed sources:

* V1 `VERTEX_CP_CORRELATIONS_received.md`, SHA256
  `3d3ea63ec9bb7e2ce0fe03ac46c63a453255303a1508fbb1237c94b688f15956`;
* corrected V2 `VERTEX_CP_CORRELATIONS_V2_received.md`, SHA256
  `f89a0d02aa7109f30f07b382fd9759f13a768a73b89c0a3a333708af31a705a7`;
* normalized-comb dependency `FEEDBACK_EXTENSION_V2_received.md`, SHA256
  `f532d88b454f974c4ea4e6333a7357c2d1d9b176f09cfceb23c53f11dc04112b`;
* inherited device/Choi comparison `W49_PROOF_V4_received.txt`, SHA256
  `ccd777dd4daea424e19d6b8fd4e8c6842fb7f0614aa0fb325cc1744fe532da11`.

The pinned physical model was separately read in
`cycle-11/pro1/ENTROPY_DRIFT_AND_DEPTH_COST.tex`, lines68-106. It has the same
two seed roots, binary push/pop operators, root exchange R, V_beta and actual
tau_pi weights. The corpus HEAD is `e606bfc587c76bdcae8b8fa3ec33e721efa2fbac`.
No producer implementation was imported. Peer verdicts were not used as
premises. W49 identified the original scalar/full-CP confusion; its ownership
is preserved. The explicit root-minor counterexample below was reconstructed
and checked independently in this audit.

## Exact approved contract and conclusion

The logical Bell pair Phi_RM is initially product with the **entire** normal
resource eta_(E A0 B0). The parties may have arbitrary normal local memories,
preshared resources and Bob-to-Alice quantum communication. The same
inaccessible bath is reused for a fixed prescribed N qutrit calls. There is
no other Alice-to-Bob carrier, direct bath access, accepted-branch
renormalization, or fresh-logical information preembedded in the resource.
Final fidelity is unconditional after a deterministic TP strategy. Normal
infinite-dimensional laboratories have a well-defined finite-horizon normal
strategy, with finitely many communication stages or a stated trace-norm
limit of such strategies.

For every bath basis vertex x, of arbitrary depth and word content, and
1<=t<=sqrt(2), corrected V2 proves the full chronological-channel order

    N_x <=_CP V_N(t) R_(sigma_t^tensorN),
    V_N(t)=2(N+1) h_b(t)^N,
    sigma_t=diag(1,t^-2,t^-2)/(1+2/t^2),
    g_b(t)=2sqrt(2)(1-b)t+b(1+2t^2),
    h_b(t)=g_b(t)(1+2/t^2),          b=beta^2.

The coefficient has no initial-depth or word-content penalty. The same
feedback strategy, with any normalized product laboratory resource at x,
has entanglement fidelity <=min(1,V_N/K^2). Arbitrary normal **classical-bath**
correlated resources inherit that same coefficient by convexity, including
horizon-dependent marginals, labels known to the laboratories, and arbitrarily
deep vertices.

For any normal quantum-correlated resource with computational bath diagonal
p_x and Z=sum_x sqrt(p_x)<infinity, the approved bound is

    F_e <=min(1,Z^2 V_N(t)/K^2).

At the actual tau_pi marginal, Z=2sqrt(3)+2sqrt(2) and
Z^2=20+8sqrt(6). This is a fixed correlation penalty and preserves the
2delta strong-converse exponent above 0.5log2 h_b(t). The classical-message
analogue replaces K^2 by the number M of equiprobable fresh messages.

## 1. Seed flip gives equality of full vertex combs

Let F flip the seed and preserve the entire stack word. It commutes with R,
each creation/annihilation operator, U and V_beta, by the actual model
definitions. Therefore it commutes with the chronological concatenation on
the bath. Replacing initial x by Fx conjugates the final bath by F and has
no effect on any external input/output matrix element after tracing that
bath. This holds with arbitrary reference/input coherence, so

    J_x=J_Fx=J_(sigma_x),
    sigma_x=(|x><x|+|Fx><Fx|)/2.

It is equality of full Choi operators and all prefixes, not equality only on
computational input probabilities. F is a mathematical symmetry, not a bath
control or accessible averaging flag. Sigma_x has depth H and rank two even
when H is large. It is generally nonradial.

## 2. Exact root cancellation and the necessary V1 correction

For K00=alpha R+i beta I, the physical transfer's root cross term is
i alpha beta(XR-RX). A diagonal invariant under the **global** seed flip has
equal root values, and this commutator vanishes. Push/pop updates preserve
diagonality and the global seed symmetry. Equality of only two root values,
without matching the subtrees, would not guarantee invariance under iteration.

On this actual invariant cone the diagonal transfer equals the positive
scalar kernel

    K_t=(1-b) A_t+b(1+2t^2) I,

where ordinary tree edges have weight t and the physical seed edge has
weight one. This scalar kernel can separately be applied to every bounded
nonnegative vertex function. It is not the full quantum map on arbitrary
diagonal inputs. The coefficient b(1+2t^2) includes both colored identity
choices as well as the vacuum identity choice.

The V1 error is real, rather than merely an unproved cancellation. Set t=1,
alpha=3/5, beta=4/5 and f(y)=2^(-dist(root0,y)/2). At the two roots f has
values1 and1/sqrt(2). The root1 diagonal slack of
diag(g f)-M_t(diag f) is zero, the root0 slack is (9/25)/sqrt(2), and its
offdiagonal entry has nonzero magnitude (12/25)(1-1/sqrt(2)). The root
principal determinant is

    -(9*16/625)(1-1/sqrt(2))^2
       = -216/625+(144/625)sqrt(2) <0.

Thus the full-CP inequality M_t(diag f)<=diag(g f) literally fails. The
corrected V2 never uses it: it uses scalar K_t on f, or the globally
F-invariant average of the two distance functions. This audit approves V2,
not the uncorrected literal intermediate assertion in V1.

## 3. No-depth scalar supersolution and charge blocks

The underlying two binary trees joined by the seed edge form the ordinary
3-regular tree. For any center z, f_z(y)=2^(-dist(z,y)/2) obeys
Af_z=2sqrt(2)f_z away from z, while at z it has value3/sqrt(2)<=2sqrt(2).
For t>=1 the scalar inequality A_t<=t A is entrywise, including the seed
edge. Hence K_t f_z<=g_b(t)f_z. All functions are bounded; no square
summability, state normalization, trace of an infinite identity, or finite
reflecting bath is used.

The symmetric average Psi_x=(f_x+f_Fx)/2 is globally F-invariant, dominates
the diagonal vector sigma_x and is a scalar supersolution. Positivity gives

    M_t^N(sigma_x)(y)
      <=g_b(t)^N [f_x(y)+f_Fx(y)]/2
      <=g_b(t)^N 2^(-|L_y-H|/2).

The second inequality uses |L_y-H|<=dist(x,y),dist(Fx,y), since depth is
1-Lipschitz on every actual edge, including the seed edge. The absolute
displacement is the reason no initial H appears. This is a scalar induction
on the invariant physical iterates; applying the CP map to a lone nonsymmetric
distance function is unnecessary.

The interaction conserves bath depth plus port charge and sigma_x commutes
with bath depth. Thus the unnormalized Choi operator commutes with
-Q_A^T+Q_B. Pinching output charge has N+1 sectors; covariance then makes
each surviving block have definite input charge q and output charge o.
Its final bath depth is H+q-o; a negative depth means that block is zero.

Purify sigma_x with an **inaccessible rank-two** label. The input/output block
and its bath/purifier Gram matrix have the same nonzero spectrum. The positive
two-block inequality bounds the latter norm by twice its bath marginal norm.
The weighted sum of all positive bath marginals is exactly M_t^N(sigma_x),
so the charge block has norm at most

    2g_b(t)^N t^(-q-o)2^(-|q-o|/2).

No individual charge marginal must be diagonal: it is positively dominated
by the diagonal weighted total. Neither an input-sector dimension nor the
initial purifier factor has been dropped. For Delta=q-o, relative to t^-2o
the remaining multiplier is (t sqrt(2))^-Delta for Delta>=0 and
(t/sqrt(2))^(-Delta) for Delta<0. Both are at most one on **the stated
interval**1<=t<=sqrt(2). A broader t interval is not justified by this step.

Summing orthogonal q,o blocks and applying the N+1 pinching loss gives
J_x<=2(N+1)g_b(t)^N I_A tensor B_t. Its trace normalization is
Tr B_t=(1+2/t^2)^N; normalization gives exactly V_N and sigma_t above.
The same exponent is inherited from the earlier tau_pi proof. For t<sqrt(2)
the earlier actual-marginal prefactor can be smaller; there is no claim that
the new vertex coefficient improves every product-state prefactor.

## 4. Why coherent feedback retains K squared

I reconstructed the normalized-comb dependency. With the same full-horizon
C=V_N at **every** prefix, set D_m=(C J_R,m-J_x,m)/(C-1). Positivity at the
full horizon descends through the causal partial traces. These prefixes obey
Tr_(B_m) D_m=I_(A_m) tensor D_(m-1), with D_0=1. They therefore define a
normalized deterministic comb, by the primary comb theorem. Thus
R=(1/C)N_x+(1-1/C)D is a convex mixture of two physical combs.

Closing a fixed legal strategy, including initial resources and quantum
return wires, is linear in the inserted comb and sends both terms to CPTP
logical channels. This proves logical CP order without claiming that a
partially transposed link-product expression preserves arbitrary positivity.

With the product forward replacer inserted, the untouched reference remains
product with **all Bob-held registers**. Alice's local TP maps cannot signal
to R/Bob, Bob's local maps preserve that product, and sending a register from
Bob to Alice only removes it from Bob. Each replacer output is independently
adjoined at Bob. Measurement outcomes are retained as registers and the
complete strategy is TP. There is no branch normalization. Hence the final
logical comparison channel is a normalized replacer, and its Bell overlap
with I_R/K is1/K^2. Both factors of K are accounted for.

This physical convex-mixture reasoning also works directly for a prescribed
finite-stage normal strategy with infinite-dimensional laboratories: the
comparison comb has a finite-memory realization and both closed physical
circuits remain normal CPTP. The source's finite-compression limit is a valid
alternative for the stated well-defined normal strategy class. No finite
energy, laboratory dimension, bandwidth, or computational bound follows.

## 5. Coherent resource comparison and fixed-normal tail limits

For any normal eta_EL, purify the resource alone as
Psi=sum_x sqrt(p_x)|x> a_x on E L G, with G inert and ||a_x||=1. The a_x need
not be orthogonal. Let w_x=sqrt(p_x)/Z and
chi_ELG=sum_x w_x |x><x| tensor |a_x><a_x|. Weighted Cauchy-Schwarz gives
Psi Psi*<=Z^2 chi. The coefficient is sum_x p_x/w_x=Z^2; the comparison is
normalized. The bath labels make the whole branch vectors orthogonal even
when the a_x overlap. Finite Z justifies the countable sum, or equivalently
the bounded inverse-weight quadratic form; no finite purification-rank
factor is introduced here.

Tracing inert G gives eta_EL<=Z^2 chi_EL with a normalized classical-bath
comparison state. The same actual physical strategy is applied to both sides.
The fresh Phi remains product with the entire resource on both sides. The
uniform classical-bath bound therefore yields Z^2 V_N/K^2. Giving G to a
laboratory, purifying logical data together with the resource, or replacing
chi by an unnormalized branch would be different arguments; none is used.

At actual tau_pi, each of 2^(H+1) depth-H vertices has p=(1/3)6^-H. The
geometric sum is exactly Z=2sqrt(3)+2sqrt(2), giving the stated20+8sqrt(6).
This controls all correlated extensions of that marginal, not only a product
initializer or a specified finite-rank purification.

If Z diverges, finite coordinate compression P has
Z_P^2<=rank(P) Tr(P tau)<=rank(P). Applying the same comparison to the
**unnormalized** compressed state and the gentle bound gives

    F_e(eta)<= Z_P^2 V_N/K^2+2sqrt(Tr[(I-P)tau]).

For fixed normal tau the tail is independent of its extension and of the
strategy. Fix P, take N to infinity above threshold, then enlarge P. This
proves the same strong-converse limit uniformly over horizon-dependent
extensions of that fixed marginal, without an entropy/depth assumption.
Varying coherent marginals require the stated supplied cutoff or Z_N resource
condition; arbitrary extensive coherence is not silently included. Arbitrary
varying **classical** bath marginals already need no such condition.

## 6. Independent exact diagnostics and falsifiers

`check_vertex_cp.py` is a new endpoint simulator with Gaussian-integer
amplitudes and no producer imports. Each chosen alpha,beta is rational, so
every coherent U/I path is summed exactly before forming any Gram matrix.
Bath vertices are exact seed/word tuples. No finite-depth boundary is imposed.
Raw results are `RAW_VERTEX_CP_CHECKS.json`.

The48 cases use N=1,2,3, initial depths0,1,3,20 with different seeds/words,
and(alpha,beta)=(1,0),(0,1),(3/5,4/5),(4/5,3/5). They verify full seed-flip
Choi equality, TP normalization, chronological causal prefix recursion and
depth/charge conservation exactly. For each pure vertex, an inverse-output-
weighted bath Gram has the same nonzero eigenvalues as the complete
replacer-weighted Choi matrix. Rational LDL of its real Hermitian embedding
certifies the **full global CP inequality at t=sqrt(2)** in all48 cases,
not merely a bound on unentangled test inputs. The external Choi convention
is unnormalized throughout. The coefficient after clearing denominators is
exactly2(N+1)(8d^2+2 beta_num^2)^N.

There are96 exact nonradial seed-pair weighted-transfer/scalar-kernel
comparisons at t=1,5/4 and1480 exact Q(sqrt(2)) pointwise comparisons to both
the two-center and absolute-depth-displacement envelopes. Pure-root transfer
does create the retained offdiagonal control, while the paired transfer
cancels it exactly. The invalid V1 root-minor inequality is an exact negative
control, not a floating suggestion of a failure.

Four resource fixtures with overlapping, partly entangled conditional a_x
verify the coherence domination by exact rational semidefinite checks before
and after tracing the inert two-dimensional G. These are abstract positive-
order checks, not independent simulations of arbitrary infinite laboratories.
The normalized-comb and no-forward-signalling steps are justified analytically.

Two checker representation bugs were corrected before drawing conclusions:
explicit zero scalar entries versus omitted direct-amplitude entries, then
integer-zero divisions introducing floating zeros into a rational partial
trace. `IMPLEMENTATION_REPAIR.txt` preserves both failures and repairs; the
final checker asserts reduced entries are Fractions. The channel amplitudes,
LDL certificates, root counterexample and final resource comparisons are exact.

Finite checks do not prove the all-N theorem. That conclusion rests on the
independent arguments above. They exercise the physical root, both seeds,
nonradial deep initial vertices, identity endpoint and coherent histories
without a surrogate bath.

## Primary comparison, costs, and status

Primary sources actually opened/read:

* Chiribella, D'Ariano and Perinotti, [quantum networks](https://arxiv.org/pdf/0904.4483),
  Theorem5/equation40: positivity and causal trace constraints characterize
  deterministic combs. This is an established realization tool.
* Cooney, Mosonyi and Wilde, [quantum-feedback/replacer converses](https://arxiv.org/pdf/1408.3373),
  Theorem4 and its communication section: a close established feedback and
  replacer comparison predecessor, for repeated memoryless channels. Its
  theorem is not imported as though this reused-bath comb were memoryless.
* Napoli et al., [Robustness of coherence](https://arxiv.org/pdf/1601.03781),
  the pure-state formula following equation9: the squared sum of amplitudes
  is established coherence-robustness machinery. The block-resource comparison
  here is proved directly, not promoted as a new generic coherence law.

Choi order, pinching, Gram spectra, positive regular-tree supersolutions,
weighted Cauchy-Schwarz and gentle compression are established mathematics.
Historical priority of the evaluated device-specific vertex/correlation
combination remains UNKNOWN; no broad priority search is claimed complete.

All N original qutrit calls remain charged. The theorem is an upper bound
even when backward quantum communication and shared resources are ideal
assistances; it does not acquire their bandwidth, preparation, memory,
synchronization, precision, energy or reset. No bath measurement, manipulation,
root deletion, shell flag, fresh environment, physical seed flip, or extra
forward communication is supplied. Diagnostic computation is finite and
exponential in the enumerated horizon; it is not an encoder or experimental
compiler. No new achievability, exact intermediate-beta capacity, efficient
code, useful physical operation, or mission completion follows. Any
Theta(beta^2) conclusion still needs the separately inherited lower proof.

Internal fresh analytic audit of corrected V2: PASS. Literal V1 intermediate
assertion: FAIL, repaired as recorded. Formal verification: NOT_PERFORMED.
External acceptance and physical inputs: UNACQUIRED. Historical novelty:
UNKNOWN. Practical advantage: NOT_ESTABLISHED. Mission: NOT_ACHIEVED.
