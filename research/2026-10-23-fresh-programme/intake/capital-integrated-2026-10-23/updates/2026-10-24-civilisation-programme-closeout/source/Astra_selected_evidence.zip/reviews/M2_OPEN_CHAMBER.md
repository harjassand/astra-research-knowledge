# Independent review of the N9 open-chamber construction

The frozen theorem in `CHAMBER_PROOF.md`, SHA-256
`826adaccb8c6dc183a849226cc60cf811e81d2da8ec2b4cd425bb15902aa285b`,
passes this audit. The scope is the full twelve-dimensional closed nodal
box of radius `1/1048576` about the displayed seed, and the open rational
chamber containing that box, on the specified physical N9 triangulation.
I found no fatal gap. This verdict does not establish coverage of all
nodal data, another geometry, Morrey's conjecture, or novelty.

The review uses a new script, `independent_audit.py`, with no producer
imports. The raw geometry and proposed tree are input data. Its receipt is
`INDEPENDENT_RECEIPT.json`. The script binds the producer proof, script and
receipt by their full hashes. An exact seed replay and twenty-four exact
single-coordinate endpoint replays are finite diagnostics. The separate
integer interval computation and the universal identities below establish
the all-values box statement.

## Actual gradients, physical masses and identities

For a physical face with vertices `a,b,c`, put `e=b-a`, `f=c-a` and
`d=e_1 f_2-e_2 f_1`. For each scalar nodal hat at interior vertex `v`, the
independently reconstructed gradient is

```
g_iv = (((1_{b=v}-1_{a=v}) f_2-(1_{c=v}-1_{a=v}) e_2)/d,
        (e_1(1_{c=v}-1_{a=v})-f_1(1_{b=v}-1_{a=v}))/d).
A_i = sum_v u_v outer g_iv.
```

The physical face area is `|d|/2`. Direct exact geometry checks give nine
vertices, twenty-one edges, thirteen triangles, only the three outer
boundary edges, no crossings, no unsplit vertex on an edge, no strict
containment of another mesh vertex inside a face, and total area fifty.
All interior vertices lie strictly in the outer triangle. Dividing the
areas by fifty gives, in physical face order,

```
(1/5,1/5,3/25,1/5,1/25,1/25,1/25,1/25,
 1/50,1/50,1/25,1/50,1/50).
```

These are actual cell weights, rather than adjustable atomic
probabilities. All thirteen atoms have the same positive physical masses
for every nodal assignment.

The mean and determinant balance were checked as polynomial identities,
not inferred from a finite nodal test. The twelve scalar coefficients
`sum_i w_i g_iv,c` vanish. All thirty-six coefficients

```
sum_i w_i cross(g_iv,g_iz)
```

of the monomials `u_v^1 u_z^2` vanish. Consequently the physical mean is
zero and `sum_i w_i det(A_i)=0` for all twelve independent nodal scalars.
For every physical adjacent face pair, all differences
`g_iv-g_jv` are mutually parallel. Hence `det(A_i-A_j)=0` identically,
including every middle and terminal pair used by the certificate.

## Universal initial steps

The direct hat coefficients give

```
A0=u4 outer (0,1/2),
A1=u3 outer (1/2,0),
A2=u3 outer (-1/6,1/3)+u4 outer (1/3,-1/6).
```

Thus face zero can be peeled from the root at zero with its full mass
`1/5`; the residual mean is `M=-A0/4`. The full `(1,2)` packet has mass
`8/25` and mean `Q=(5A1+3A2)/8`. Subtraction gives, identically,

```
Q-M=(2u3+u4) outer (1/8,1/16).
```

Both its inner physical pair jump and its outer root jump have rank at
most one. The remaining mean is

```
M2=-u3 outer (1/6,1/12)-u4 outer (1/12,1/6),
```

and the remaining ten original masses sum to `12/25`. No equality among
independent nodal values was used. Degenerate zero jumps are lawful rank
at most one jumps; strict nonzero jumps are not required by the theorem.

## The rational peeling lemma

The lemma is valid under its written assumptions. For `B_i=A_i-M`, a
rank-one difference `B_i-B_j` makes `det(q B_i+(1-q)B_j)` affine in `q`.
The displayed opposite-sign coefficients give its unique zero in `(0,1)`.
Removing the two positive packet masses gives
`Q-R=W(Q-M)/(W-t)`, so the outer jump is rank at most one. Determinant
affinity on both the packet and root splits preserves balance of the
residual. Maximal exhaustion of `i` gives precisely the stated update.
The positive remaining partner mass guarantees the packet is a proper
part of the current law. The independent interval replay also checks the
stronger directly computed lower bound on `W-t` at every step.

Every rational denominator used in the chosen six steps is nonzero on
the certified box. The inequalities are strict, so the conditions describe
an open semialgebraic chamber where the formula is defined. Clearing
denominators to describe that set must retain their signs; the proof need
not do that clearing because it evaluates the rational conditions on
their nonzero domain.

## Interval inclusion and simultaneous quantifiers

The independent implementation uses integer endpoints `(a,b)` representing
`[a/2^120,b/2^120]`. Multiplication takes the four integer endpoint products
and rounds their minimum down and maximum up after division by `2^120`.
Division takes the four endpoint quotients and rounds outward; it first
rejects any denominator interval containing zero. Addition and subtraction
on the grid are exact. Fractional input coefficients are rounded outward.
This implementation differs from the producer's Fraction interval class
and reciprocal-then-multiply quotient.

For each of the twelve independent coordinates the input is its whole
closed interval about the seed. Inductively every intermediate interval
contains the actual rational expression for every simultaneous choice of
the twelve coordinates in the box. Reusing a variable in an expression
does not compromise inclusion: it may enlarge the interval because the
arithmetic permits incompatible endpoint choices, but cannot omit a
permitted actual value. No independence assumption about intermediate
weights or gradients is made.

The following decimals are readability summaries only. The receipt keeps
the full exact rational endpoints. The exact bounds certify the sign
conditions, positive removed masses, positive remaining masses, positive
remaining total mass, and exclusion of zero from every divisor.

|Pair, exhausted first|Lower bound on `|f_i|`|Lower bound on `|f_j|`|Lower bound on new partner mass|
|---|---:|---:|---:|
|(3,7)|0.3541565|2.0208142|0.00494712|
|(4,10)|0.0188828|0.3585460|0.03788078|
|(8,10)|0.7615152|0.4328860|0.00266410|
|(5,11)|1.5474843|3.4164697|0.00184145|
|(6,9)|0.0683560|0.3791524|0.01201009|
|(7,12)|0.0253745|0.3639654|0.01837414|

The final four masses are positive uniformly. Consequently this is a
proof on a twelve-dimensional set with nonempty interior, rather than a
finite collection of nearby points. The additional twenty-four endpoint
tests would not imply that statement on their own.

## Terminal split, full tree and transformations

The two terminal physical pairs `(9,12)` and `(10,11)` each have rank-one
connected endpoints and preserve determinant in taking their mean. The
propagated residual balance is therefore exactly

```
s(1-s) det(B-C)=0.
```

Both group masses are strictly positive, so `s` lies in `(0,1)` and the
terminal outer jump has rank at most one. This uses an exact identity, not
an interval numerical equality test.

The independent reconstruction equals the supplied seed tree, preserves
all thirteen physical masses exactly, has nineteen positive leaves and
eighteen binary splits, and verifies every jump determinant as an exact
zero. The universal and interval arguments prove the same tree formula
works for each point in the box; one fixed numerical seed tree alone
would not establish that. Repeated labels represent different positive
occurrences of the same original physical gradient, and their masses sum
to its original cell area. There are no auxiliary terminal atoms.

An affine boundary trace translates all gradients by a common matrix;
rank and determinant balance at the translated mean are preserved.
Invertible output or domain transformations multiply all relevant
determinants by a common nonzero factor, preserving ratios and opposite
signs, and affine domain transformations preserve normalized area masses.
This transports the result to affine images of the specified mesh, not
to arbitrary new triangulations.

## The conditional dense-set closure argument

The compactness step is sound with the advertised uniform twenty-two
physical-atom leaf bound. Choose a sequence of covered nodal data tending
to any target datum. There are finitely many binary tree shapes with at
most twenty-two leaves and finitely many assignments of thirteen face
labels to their leaves, so a subsequence uses the same shape and labels.
Each nonnegative leaf mass is bounded by its fixed physical face mass;
extract a convergent mass vector. The original atom gradients converge
because they depend linearly on nodal data. All physical label totals
remain the exact prescribed masses. Prune zero-mass subtrees. At every
surviving split both child masses are positive, so their means converge;
rank at most one is closed. This yields a finite tree with at most the
same number of leaves for the target datum.

The generic normalization of `u3,u4` does not invalidate this argument
near `det(u3,u4)=0`: the compactness extraction must be performed after
pulling trees back to the original physical coordinates, where the atoms
converge and stay bounded. Uniform conditioning of the normalizing map
is unnecessary for this existence argument. This says nothing about
bounded rational precision, numerical conditioning, or efficient
construction at the boundary.

What remains unproved is density of the successful restricted peeling
chambers. A nonempty open box, finite stress successes, or a collection of
rank-one edges cannot supply it. The next phase of this audit investigates
that substantive missing premise. Failure of an exhaustive restricted
search, should one be found, would concern only that sufficient class of
trees and would not establish nonlamination.

All audit inputs are supplied exact mathematical geometry and nodal data.
There was no physical experiment or acquisition. The verifier uses tiny
finite matrices and twelve scalar intervals; the recorded run took less
than one tenth of a second on this host. Its operation count and exact
interval bounds are retained in the receipt. No computational advantage
over other equally informed exact verifiers is claimed.
