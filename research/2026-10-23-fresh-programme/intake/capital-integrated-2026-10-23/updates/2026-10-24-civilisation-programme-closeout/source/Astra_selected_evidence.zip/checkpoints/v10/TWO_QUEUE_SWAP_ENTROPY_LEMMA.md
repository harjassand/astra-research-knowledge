# A physical two-queue overlap bound from replica-swap positivity

23 October2026 UTC. Root's analytic construction, independently reconstructed by W18 in a subsequent message. Complete proof below; frozen-source fresh receipt still requested. Mathematical priority UNKNOWN. This is a scoped bridge, not the all-copy/many-clock converse or mission achievement.

Let u,v be arbitrary normalized complex vectors in C^(D1) tensor C^(D2), D1,D2>=2. They may each be entangled between the two queue factors. The second party's terminal vector is conjugate(v); if it is instead named v directly, transpose the reduced state in the overlaps below. Define

    a=Tr(rho_u,1 rho_v,1), b=Tr(rho_u,2 rho_v,2),
    c=|<u|v>|^2,
    g=(g00,g10,g01,g11)=(1,D1 a,D2 b,D1 D2 c).

Put Z=sum g and M=g10 lnD1+g01 lnD2+g11 ln(D1 D2). Then the physical pointwise remainder obeys the SHARP bound

    F(g)=ln Z-M/Z <= h(D1)+h(D2),
    h(z)=ln(1+z)-[z/(1+z)]ln z.

Equality is attained by aligned product u=v. In the unchanged equal-D native model this is r=2, L=1, with upper2h(D). It is stronger than the loose2c(1/D) bound for this finite scope. No inference to arbitrary r or L is made.

Proof. On the two replicas u and v, let F1 and F2 swap the first and second factors, respectively. They are commuting self-adjoint involutions. Their expectations on the positive product replica density are a,b,c for F1,F2,F1F2. The operators (I+F1)(I-F2), (I-F1)(I+F2) and (I-F1)(I-F2) are positive. Consequently

    a+c-b<=1, b+c-a<=1, a+b-c<=1.

In addition a,b,c>=0 by the positive reduced-overlap/whole-overlap formulas. Set t=max(0,(a+b+c-1)/2). The three inequalities imply t<=min(a,b,c). Thus the following five weights are nonnegative and sum to1:

    lambda111=t,
    lambda100=a-t, lambda010=b-t, lambda001=c-t,
    lambda000=1-a-b-c+2t.

They give an EXACT convex decomposition of (a,b,c) into 000,100,010,001,111. Affinity gives the same convex decomposition of g. These vertices need not all be physical pure-vector overlaps; they form a valid relaxation containing every physical overlap triple.

For arbitrary g=sum_i lambda_i g_i with positive Z_i=sum g_i, convexity of x ln x yields Z ln Z<=sum_i lambda_i Z_i ln Z_i. The energy M is linear. Therefore

    F(g) <= sum_i [lambda_i Z_i/Z] F(g_i).

The five vertex values are respectively0,h(D1),h(D2),h(D1D2),h(D1)+h(D2). Direct differentiation gives h'(z)=-ln z/(1+z)^2<=0 for z>=1, and h is nonnegative. Therefore every vertex value is at most h(D1)+h(D2), proving the bound. For aligned product u=v, all three overlaps equal1; g is the product of(1,D1) and(1,D2), and equality follows.

The result uses a cross-queue quantum positivity constraint absent from mere per-clock likelihood caps or adjacent CP nesting. All-size extension requires a new argument. On r replicas/factors, the analogous commuting-swap joint distribution gives positive Fourier constraints on every subset overlap, but its relaxation need not be a convex hull of rectangular cutoff profiles. W18 has already found nonrectangular vertices in a larger floating PPT projection; their existence does not disprove the entropy bound but blocks a naive rectangular-hull extrapolation. This lemma neither assumes nor proves that extrapolation.

No physical measurement of the swaps is granted by this proof. They are mathematical positive-operator witnesses on the two terminal-vector replicas. No new physical data, calibrated control, runtime advantage or external priority certification is claimed. The source-specific full multi-clock LOCC problem remains open; mission NOT_ACHIEVED.
