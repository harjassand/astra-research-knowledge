# W14 final continuation and exact scope

24 October 2026. This worker is FINISHED/IDLE at the parent's direct drain
instruction. No further investigation, assignment or review request is active.
All earlier frozen proof bytes are preserved. The original worker-root
REPORT.md/RESULT.json are initial-return records; this file and the sibling
RESULT.json describe the final continuation. CURRENT_MANIFEST.json is a
transport inventory, not mathematical validation.

## 1. Lead result: explicit closed-threshold rectangular locator

Let F:F2^n -> F2^(n+1) be an explicit circuit of bit description size S_F.
Actually try all n+1 coordinate deletions P_j. Suppose at least one P_j is
quadratic and its number of missing outputs satisfies

    H(P_j) <= L = 2^ceil(n/2).

Coordinate ranks and fiber sizes are unrestricted. There is a numerically
specified uniform deterministic FP^NP procedure which actually acquires a
nonempty affine flat of codimension at most FIVE containing no collision
output of its successful P_j, and returns one missing output of F. Every
point on the flat has at most one square preimage. The removed bit can be
any explicit circuit. Every success remains sound on arbitrary circuits.

The good projection, H, fiber bounds, collision membership oracle,
Fourier table, annihilator, classifiers, affine flat and proper decomposition
are NOT supplied. Numerical H<=L is not recognized. The geometric existence
class for one projection IS exactly recognized by the factored version.
No square-hole, count or whole-profile guarantee follows.

Frozen theorem:
EXPLICIT_CLOSED_L_FIVE_RESTRICTION_LOCATOR.md
SHA256 79d8032dbf31e76dd5951444135677851f73d6c8dcb09f99d91f05e2df32fc43.

Fresh complete W49 audit:
../w49_fresh_recurrent_capacity/walsh_locator_audit/FULL_FRESH_CLOSED_L_LOCATOR_AUDIT_V1.md
SHA256 581ae9540319e0102eaa2a284286663a3a4da10e2567c86ab7dd3910824160cd.
Read in full and hash-verified. Verdict INDEPENDENT_INTERNAL_REVIEW_PASS at
the exact source hashes; no mandatory mathematical repair was found.
Own receipt W49_CLOSED_THRESHOLD_AUDIT_RECEIPT.md.

With M5=sum_{i=0}^{min(5,n)} binom(n,i), the safe complete flat-and-word
decision cap is

    (n+1)*[(2n+1)*M5+6n+8].

Word-only cap is (n+1)*[(2n+1)*M5+n+2]. Query bits are
O(S_F+n^10). Outside work is
O((n+1)*(S_F+n+1)^4*(M5+1)^4), giving a safe n^33 bound at quadratic
S_F=O(n^3). These are oracle complexity bounds, not an ordinary polynomial
algorithm or evidence that an ordinary NP solver is efficient.

## 2. Mechanism and the acquisition obligation that was discharged

For one projection, w(y)=#P^-1(y)-1, W its raw Walsh transform. W(0)=0;
each nonzero quadratic Gauss sum has magnitude at least L. Parseval gives

    ||w||_A <= sum_y w(y)^2/L.

For simple fibers w is ternary, so H<=L gives ||w||_A<=2. The TRUE collision
indicator b=(w^2+w)/2 then has Fourier norm at most3 and density at most1/16
when n>=8. Classical Shpilka--Tal--Volk Lemma3.1, applied on its SAME side
which increases the positive constant coefficient of 1-2b, reduces the
collision norm until it is below1 after five restrictions. A nonzero
Boolean indicator cannot have norm below1, so the resulting flat has b=0.
The side is essential; an unspecified monochromatic-flat theorem would
not prove a zero flat. For n<=7, |C|<=16 and the elementary five-hash
existence proof supplies the flat. No random flat is supplied to the
algorithm.

Repeated fibers at H=L are treated separately in
EXPLICIT_AT_L_REPEATED_FIBER_EXTENSION.md,
SHA256 6d864d9602d53632e6882b28cee21bc39e127524a00ed0c2441e4357eee81ae2.
W49 independently reconstructed this full dependency as well. A saturated
2L moment puts all positive defects in one hyperplane. Otherwise the odd
support is strictly below2L; classical binary KT forms, a positive
idempotent quotient and an explicitly budgeted cover of the positive-even
outliers give a split quadratic annihilator. No simple signed-trade
classification is applied to repeated multiplicities.

The actual learner acquires the COMPLETE degree-d feature span of collision
outputs using ordinary NP queries about INPUT pairs u!=v with P(u)=P(v).
Each YES witness is obtained by bit self-reduction and increases rank. The
first query already contains every monomial slot and a physically padded
M_d-by-M_d row field. Full rank aborts; a terminal ordinary NO establishes
the span's completeness. No universal condition is put inside an NP
verifier. For actual flats a second ordinary NP relation guesses d affine
forms, checks their common one-coset is nonempty, and checks their Boolean
product on the saved source points. Those points span the acquired feature
space. The forms are self-reduced, then GF2 elimination returns the flat.
Its factorization is actually acquired, not presumed from degree alone.

Finally ordinary NP preimage existence and inversion distinguish zero from
one preimage at a selected noncollision point. The classical append/flip
reduction gives a rectangular hole. All coordinate deletions and original
bit insertion positions are charged. It is not a new append/flip reduction.

## 3. Stronger costs or outputs on narrower reviewed classes

The strict H<L theorem uses degree TWO, and remains valid:
EXPLICIT_SUB_L_RECTANGULAR_ANNIHILATOR.md,
SHA256 1272c471eaa0a4947358c01140795440f3f1f077c5feaba6fac5aefdfaad9dde.
W59 full audit SHA256
b8d76e6558ebafd03612024e7b531068fdb26fbc0437f72428a830f88d45bded.
With M2=1+n+binom(n,2), the all-coordinate word cap is
(n+1)*[(2n+1)*M2+n+2], query O(S_F+n^4), outside
O((n+1)*(S_F+n+1)^4*(M2+1)^4). Small n<=5 uses a paid finite branch.
The extra-point repair is essential: even positive w can lie outside odd
support. W59's coupling and repair are credited in the proof.

ALL_FIBERS_QUADRATIC_PROOF.md,0d52e59f...a883e, and
INTEGER_SPECTRAL_CAP.md,668de914...8dfb7, have separate W59 PASS reviews.
They actually recognize a bounded near-minimum regime and acquire a whole
weighted affine-coset profile/hole cover: fixed r with
H <= (1-2^(-r-1))*L is FP^NP, and inverse-POLYLOG margin is explicitly
QP^NP. This is a stronger output on a narrower range, not full-profile
acquisition for all H<=L. The complete ordinary-NP padding and threshold
witness costs are in those frozen files.

SHARP_FIBER_EQUALITY_LOCATOR.md,7921e37e...e16e9, has W59 PASS. It recognizes
the equality class of the sharp fiber-deficit bound by actually acquired
affine and Gauss data. W59's separately derived minimum-odd-support extension
has its own review/credit. QUADRATIC_PHASE_SPECTRAL_COMPILER.md,
a1a9e946...d4796, with CONING_QUADRATIC_PHASE_INDUCTION.md,
862b0359...4c0f9e, passed W59 full review fe18b118...439d1. It actually
acquires a global quadratic phase and a proper bounded union of spectral
flats; it does not assume that representation for every low-deficit map.

COHEN_COLLISION_ANNIHILATOR_PROOF.md,36157bb2...953a4, and its actual-query
encoding addendum d164cde5...7884 passed W61 audit2fc99300...718d. Classical
integer Cohen plus an inverse-arrangement argument proves EXISTENCE of a
uniform FP^NP machine for each fixed c under H<=cL. The universal numerical
coset count/degree is NOT_EXTRACTED. No input-dependent advice is involved;
this is an asymptotic existence theorem, not a numerically instantiated
recognizer. W61's separate integer refinement edce1750...94c937 reduces the
degree to a valid total coset count and passed owner review0bff3a0a...2a55e.
The later direction-count refinement32674727...190fa4 is UNREVIEWED.

## 4. Diagnostics and their limits

Closed-threshold owner raw:
EXPLICIT_CLOSED_L_FIVE_RESTRICTION_RAW.json,
SHA256 a3de6bbc5b90451c115e67f3cecf6f55c46bedefd527622479579bc0479e7bee.
It has44 actual projection acquisitions through n10 with8102 simulated
ordinary decisions,1242 actual Z3 calls for the factor P-verifier,13
all-coordinate runs with2535 more decisions,707 exact Boolean restriction
controls,1000 scalar checks and25 explicitly ABSTRACT Boolean controls.
The factor solver sees only the actually acquired source points and public
rows. Collision/preimage backends still enumerate exponentially.

W49's NEW independent stdlib raw f99ae4e7...d4b3f7 includes644 actual
quadratic maps,52 pair-query acquisitions with1198 simulated decisions,
709 Boolean indicators,60 abstract three-flat controls,2000 integer-c
checks and804 restriction steps. It does not import producer code. W49
audited the factor-verifier proof; its new replay does not claim another
complete factor-solver implementation. W59's strict-degree2 independent
replay has4591 whole maps and263636 simulated decisions, actual coned
controls through n16 and explicit nonquadratic extra-point controls.

These are bounded diagnostics. They neither replace the complete all-size
proofs nor provide a scalable SAT implementation, ordinary-time advantage,
large-instance practical benchmark or external certification. The
abstract support/Boolean fixtures are not asserted realized quadratic maps.

## 5. Completed but UNREVIEWED final substantive units

Keep all of these distinct from the reviewed closed-L theorem.

* ADDITIVE_SLACK_QUADRATIC_ANNIHILATOR.md,
  SHA256 07d22d7958c045b56869027730e6ac4cab46427f0473582dc1de5c05798f1f88:
  proposed H<=L+t arbitrary-fiber extension, numerical
  D=4t^2+14t+11, actual factor acquisition, fixed-t FP^NP and
  t<=log^c n explicit QP^NP. Structural raw a71d58a9...70f8b0 has916 actual
  map/parameter profiles, but its193 STRICT H>L controls are only n<=5.
  The two actual n14 guard-satisfying controls are at/below L. All-size
  realization of a growing strict additive sliver is UNKNOWN. A full large-D
  end-to-end acquisition replay and independent proof review are absent.
* CHI_POLAR_SIMPLE_GAP_OBSTRUCTION.md,
  SHA256 780647beb29df9bc355c2c28828c1842908b9c1ac8f74e2816b5ccd4ef4f51cc:
  proposed all-size obstruction for SIMPLE chi_n+T*x+c, arbitrary full
  linear T, even n>=6: H=L-1 or H>=5L/4-1. The proof uses fixed polar
  full-rank frequencies and an integer mixed-rectangle argument. It is
  scoped to that entire polar family and maxfiber2. It is not a generic
  quadratic hole gap. Raw2ddd7363...d4d50 retains exact finite controls;
  a stronger rank-one-search pattern is explicitly FINITE ONLY.
* THREE_BIT_CONING_GADGET_OBSTRUCTION.md,
  SHA256 e914511462f4afc59a02e9bcf5250675e2e875f48aa400a709daf39be55d539f:
  the last completed unit. For R0,R1 permutations, balanced affine u and
  ANY Boolean G:F2^3->F2^2 in
  P'(x,q,t)=(R_q(x),G(u(x),q,t)), exact
  H'=A*(2^(n-1)-H)+B*H. At the explicit small-deficit scale A must vanish,
  then H' is0,2H or4H and every new fiber has size at most two. It excludes
  H'=2H-1 and constant-positive-slack preservation in THIS entire operation
  class. All65536 gadgets are checked in raw560883fb...b3ffcde; the all-size
  conclusion rests on the selector-count/set-complementation proof. Other
  cut maps, old input bits, quadratic parts and dimension increments remain
  available. No generic obstruction follows.

## 6. Primary sources, classical credits and explicit corrections

The restriction machinery is Shpilka--Tal--Volk1304.0371v2 Lemma3.1,
with the sign/bias conversion explicitly charged. KT low-weight forms are
classical; W49 verified their literal parameters in the accessible primary
1810.02296v2 Lemma11 and minimum support in1001.2554. Original1970 KT
full text was not retrieved; this access limit is explicit. Only binary
odd supports below2L use those forms. The append/flip reduction is Chung
et al. TR23-193 revision1 Definition2.4/Theorem3.1; exact primary PDF SHA
28ee7a65f41ea0825aabfd1894d7119b9e19faa63ad620ae046605407279c4f2.
Monomial feature interpolation is classical algebraic-immunity machinery.
Dyadic leg-degree refinement and several minimum-odd/quotient refinements
are credited to W59, not reassigned as owner-independent discoveries.

The prior claim that a proper COLLISION hull alone does not suffice for a
rectangle was RETRACTED in c6c02d09...da8e8. It DOES suffice by the ordinary
NP empty/unique-fiber append/flip baseline. A proper WHOLE-defect hull is
needed only for the stronger entire-singleton-half geometry.

The old local primary/GreenSanders_General_2008.pdf and .txt are actually
mislabeled Talagrand artifacts and INVALID as Green--Sanders evidence.
They remain preserved with a warning. The correct math0611286v2 primary
PDF has SHA4c1e5ae4...cebe849. The corrected source and independent primary
reads support the Cohen theorem; no numerical constant was extracted.

An earlier knowledge-status UNKNOWN for an all-size repeated H=L family
is SUPERSEDED by CLASSICAL even-width Keccak chi, primary Schoone--Daemen
2024 DOI10.1007/s10623-023-01349-8 Theorem3. Exact profile H=L,maxfiber3,
w=(-1)^weight*(1_E+1_O), with E/O complementary coordinate K-flats,
is derived in5c28250c...61355. The direct ordinary-P missing word e0 is
already available on this family; there is no computational advantage
against that matched baseline. This does not realize the strict upper
sliver L<H<=L+t.

The ordinary local3 comparison is Huang--Li--Zhong ITCS2026 Theorem1.14,
O(n*2^(n/2)) deterministic rectangular avoidance. It does not make an
ordinary FP^NP solver free. Historical priority of the new structural and
acquisition compositions remains UNKNOWN. CURRENT_PRIMARY_PRIOR_ART.md
and ANNIHILATOR_PRIOR_ART_AND_PROVENANCE.md retain the exact source roles
and retrieval failures; search nonfindings do not establish novelty.

## 7. Remaining obligations and final status

The reviewed theorem is conditional on a low-deficit quadratic projection;
it does not solve generic near-square quadratic or literal3local Avoid.
All such numerical promises/classifiers must remain explicit. The full
simple H=L degree2 endpoint classification remains open in this packet,
although degree5 now suffices for rectangular location. Full-profile
acquisition at arbitrary bounded factor remains a different task from one
rectangular missing word. The unreviewed additive sliver has no known
all-size strict realization here. The failed coning/chi routes give scoped
guidance, not proof that that sliver is empty for all quadratics.

Future work, if separately authorized, should first review the frozen
extras, resolve historical priority against the exact classical sources,
and seek an operation outside the proved coning rigidity or a new acquired
representation for the generic case. No further unit was begun after the
parent's drain request.

Internal reviewed validity: PASS only at the specified source hashes.
Historical novelty: UNKNOWN. External validation: UNKNOWN.
Ordinary-time advantage and practical value: UNKNOWN.
Generic near-square Avoid: NOT_ACHIEVED. P versus NP: UNRESOLVED.
Programme mission: NOT_ACHIEVED. No public disclosure or outreach occurred.
