# Fresh hard-mathematics audit of the mesoblock filtered-frame candidate

23 October2026, w49. Exact reviewed source:
`work/workers/w67_fresh_foundational_mechanism/high_design_audit/quadratic_source_frontier/MESOBLOCK_FILTERED_FRAME_CANDIDATE.md`,
SHA256 `26c7092cee2414b7681ea7c92b5f87e74b9f2482399a2a397697f2cbe4b784b2`.
Read completely before reconstructing. No peer verdict or code was used.

**Verdict:** no blocking defect found in the IDEAL mathematical arguments
(M6)--(M16), conditional on their stated access/design/source premises and
finite guards. In particular the variance factor mu, the unconditioned
good-event normalization, source-weighted program law, variable widths
and fixed public logical slice all reconstruct. This does NOT certify an
end-to-end quadratic compiler. Two finite-constructor/scope sentences need
completion: bound the width-rejection sampler, and qualify pure-isometry
claims on bad frame seeds. These do not erase the ideal PSD/width argument.

## 1. Premises, bin fractions and what this audit does not import

Let `rho_*=sigma M_*`, with sigma fixed by total charge and `M_*>=I/2`,
`[M_*,Q]=0`, `Tr sigma M_*=1`. The candidate assumes an acquired efficient
local source preparation plus UNIFORM relative-operator/block access,
not access to the eigenbasis. The new actual-H router, log/filter native
circuits, unitary extensions and final encoder/decoder/flush costs are
separate dependencies; this audit does not silently certify them.

The mixture regularization(M1) follows from entropy concavity, linear
bulk drift and `D_b(sigma)=0`. Since `Tr sigma M_*=1`,
`Tr sigma M_*^2=1+Tr sigma(M_*-I)^2`. Consequently the moment bound for
`L=sum ln M_*` and the retained high-L probability are correct. The lower
bound `L>=-t ln2>-t` means no missing low bin is populated. At high L,
omission is bounded by the stated `Pr(L>t-1)`; this is conservative.
The smooth functions sum to one in square, with at most two adjacent
terms, so no hard-bin spectral-gap premise was inserted.

Inside a charge parent, sigma_q is scalar. The padded E_q is a partial
isometry, zero on invalid labels. Its filter A is positive, at most I,
and zero on invalid labels. The exact identity is

    A^2=E_q^* exp(L-j-1) f_j(L)^2 P_q E_q,
    p_(q,j)=sigma_q exp(j+1) D_q mu.                (A1)

Thus(M4) has no missing square, logarithm-base or padding factor.
Since `sigma_q D_q<=2` and j<=t, retained p>=p_min gives exactly(M5).
The gain in access is local to t=O(log k) mesoblocks; no global m-source
spectral-window fraction is being called polynomial.

## 2. Gaussian variance-sensitive compression

For `0<=B0<=I`, mu=TrB0/D and `C0=B0-mu I`,
`TrC0=0`, `||C0||<=1` and

    Tr C0^2=Tr B0^2-mu^2D<=mu D.                   (A2)

Take complex Gaussian coordinates with E|g_i|^2=1. For real |z|<=1/2,
the determinant formula gives

    ln E exp(z g^*C0g)
      =sum_{a>=2} z^a Tr(C0^a)/a.

Absolute-value bounding uses
`|TrC0^a|<=Tr|C0|^a<=TrC0^2` and
`sum_{a>=2}|z|^(a-2)/a<=1` on this interval. It yields the stated
`<=z^2 muD`, including the negative-z case. Choosing
`z=min{x/(2muD),1/2}` gives

    Pr(|g^*C0g|>x)<=2exp[-min{x^2/(4muD),x/4}].     (A3)

For Haar unit vector u=g/||g||, the event `||g||^2<D/2` costs at most
`exp[-(ln2-1/2)D]` by the elementary negative exponential moment of the
Gamma(D,1) norm. Every fixed Vv of a Haar frame is such a unit vector.
A complex K-sphere quarter-net has at most9^(2K) points, and its largest
quadratic form controls the Hermitian norm by factor2. Substituting the
candidate's threshold16[...], then union bounding, gives exactly

    Pr{Z>16[sqrt(mu(v0+u)/D)+(v0+u)/D]}
       <=exp(-u)+zeta,
    v0=2K ln9+ln2, zeta=exp(2K ln9-c0D).           (A4)

The constants are conservative: before the net factor the Gaussian
quadratic term has exponent at least4(v0+u), and the linear term at
least(v0+u), so the stated exp(-u) bound is safe.

## 3. Integrate first, then transfer one polynomial moment

Because Z<=1, integrating(A4) adds at most zeta to its2h moment. Let X
have an Exp(1) distribution. Minkowski at2h and
`||X||_h<=h`, `||X||_(2h)<=2h` bound the remaining moment by

    [16sqrt(mu(v0+h)/D)+16(v0+2h)/D]^(2h).

Finally `Tr[(V^*C0V)^(2h)]<=K Z^(2h)`, proving(M6). There is no
net argument transferred to an approximate design.

Here is an explicit exact sufficient check of(M7)'s constants. Since
h<=K and `2ln9+ln2+2<8`, both `v0+h` and `v0+2h` are at most8K.
With `K/D<=2^-20 tau^2mu`, tau<=1/2 and sqrt8<3, the bracket divided
by tau mu is bounded by

    16sqrt(8/2^20)+128tau/2^20
       <3/64+1/16384=769/16384<1/16.              (A5)

For m=2h, the trace polynomial is

    Tr[C0^tensor m U^tensor m X_K U^*tensor m],
    X_K=P^tensor m F_cycle,K P^*tensor m,

where P embeds the K columns and the cycle is unitary on K^m dimensions.
Thus `||X_K||_1=K^m`, whereas `||C0^tensor m||<=1`. A diamond-moment
channel error delta_des transfers the expectation with additive
`delta_des K^(2h)`, exactly as claimed. No factor D^(2h) is required.

Markov at tau mu now has three terms:

    K16^(-2h), K zeta/(tau mu)^(2h),
    delta_des(K/(tau mu))^(2h).

The corresponding guards(M8) bound each by eta_f/4. Their sum is at
most3eta_f/4, so(M9) follows with margin. The independent left uniform
Pauli gives the EXACT first frame moment KI/D and preserves diamond
design accuracy by channel contractivity and Haar left invariance.

The very large D,K make the guards plausible, but they must still be
tested by the actual finite constructor. Retained cells cannot have a
tiny D: from p>=p_min, mu<=1, j<=t and q>=0,
`D_q>=p_min 2^(kt) exp(-t-1)`. This explains why the guards become
feasible when t=O(log k); it does not supply the missing final scalar row.

## 4. Good-event polar normalization and source weighting

On Good, `G=V^*A^2V>=(1-tau)mu I`. Since A is zero on invalid labels,
`C=E_q A V G^-1/2` has C^*C=I. No unknown eigencoordinates are used in
this ideal identity. Operator order then gives

    1_Good CC^*/K
      <=1_Good E_q A V V^* A E_q^*/[K(1-tau)mu].

Only on this POSITIVE right side may the indicator be dropped. Exact
first moment then proves(M11):

    E[1_Good CC^*/K]
       <=E_q A^2 E_q^*/[(1-tau)D_qmu]
        =rho_*^t P_q f_j(L)^2/[(1-tau)p_(q,j)].     (A6)

This is an UNCONDITIONED expectation. No division by Pr(Good) occurs.
Sampling the retained cell with its ACTUAL source weight p/P cancels
the denominator p. The retained commuting sum is bounded by identity,
so(M12) follows. If public table probabilities obey
`w_(q,j)<=(1+zeta_p)p_(q,j)/P`, the same PSD inequality gains only the
factor1+zeta_p.

A sufficiently accurate two-sided relative estimate yields that one-sided
normalized condition. If a conservative mu estimate is within factor2
and K is the largest dyadic not exceeding(M7), its width is at worst
22 bits below `logD+logmu+2logtau`; the stated24-bit allowance is safe.
The estimator's confidence and filter/preparation errors remain separate
constructor budgets, as the source states.

## 5. The width estimate has the right entropy and normalization

By(A1), the dyadic width lower bound is

    ell>=log p-log sigma_q-(j+1)log2e
                         -2log(1/tau)-24.

On filter support x in[j-1,j+1],
`-log sigma_q-(j+1)log2e>=I(q,x)-2log2e`, where
`I(q,x)=-log sigma_q-x log2e`.

Since `rho_*>=sigma/2`, its t-fold information lies in
`[0,(2k+1)t]`. Removing mass at most d loses at most d(2k+1)t
unconditioned information. Renormalizing retained information by P
can only increase its nonnegative value. Also, with retained w=p/P,

    sum w log p=logP+sum w logw>=logP-logB.

These establish(M13) exactly, including its logP sign. The one-sided
normalized table bound implies TV<=zeta_p, so the expectation of a width
in[0,2kt] decreases by at most2zeta_p kt. No mu-squared width loss or
uncontrolled charge-fluctuation width was inserted.

The integer width condition `ell<2kt+1` means `ell<=2kt`. Hoeffding
with deviation `s t g_*/8` therefore has exponent at least the stated
`-s g_*^2/(128k^2)`. If the complete overhead is at most t g_*/4,
the mean width is at least t(1.5k+3g_*/4), with enough slack above
the parent target t(1.5k+g_*/2). This reproduces(M14)--(M15).

## 6. A common pure logical slice, not a mixed sender gauge

For a width-accepted cell sequence, put K_tot=2^sumell, D=2^ell_parent,
and W=sumell-ell_parent. For each fixed PUBLIC z in{0,1}^W the map

    |psi> -> C_product(|z> tensor |psi>)

is a pure isometry whenever all child frames are Good. It has the same
D-dimensional logical domain for every accepted program. Each child
range has exact predetermined charge, so the total charge is fixed for
all logical states in that program.

Uniformly averaging z, only as a proof ensemble, gives

    E_z C_parent(I_D/D)C_parent^*
       =C_product(I_Ktot/Ktot)C_product^*.          (A7)

Each individual physical encoder has its z fixed; no correlated gauge
is traced as a hidden runtime resource. Variable W costs a bounded
worst-case O(skt) public bit budget by preallocating independent fair bits.

Independent cell/frame sampling makes the unconditioned all-Good expected
product density a tensor product of the child expectations(A6). Drop the
width-pass indicator only on that positive product density and divide
by width-pass probability, at least1-eta_w. This proves(M16), with exactly

    F=[(1+zeta_p)/((1-tau)P)]^s/(1-eta_w).

The frame-failure probability after width conditioning is still at most
s eta_f, WITHOUT another1/(1-eta_w): conditional on EVERY cell sequence,
the union bound is at most s eta_f, while width acceptance depends only
on those cells and their predetermined widths, not on the sampled frames.

## 7. Two actual finite-constructor completion obligations

First, the phrase 'reject and resample' the width sequence is not by
itself a worst-case bounded fair-bit/program-seed algorithm. If width
failure has positive probability, an unlimited geometric rejection loop
has unbounded worst-case bits. The later finite-CDF discussion removes
an infinite sampler for individual cells; it does not explicitly cap
this separate width rejection.

A safe completion is to cap at R independent width attempts and emit
an explicitly counted fallback/failure program after all R fail. That
failure is at most eta_w^R. Conditional on an accepted sequence, its law
is exactly the width-conditioned law used in(M16). Unnormalized
success-indicator expectations are bounded by the same(M16) right side,
and all random bits are bounded by R times the cell-sampling bits plus
the chosen frame/prefix budgets. Another safe option is one attempt,
counting eta_w as program failure instead of conditioning. Neither option
has been instantiated in the frozen source; this is a constructor gap,
not a missing mu in the mathematical expectation.

Second, the later literal sentence that 'the result for every fixed
program is a PURE isometry' must be qualified to the ideal all-frames-Good
programs. The source earlier correctly admits bad programs are merely
total CPTP native operations and not isometries(M10). This is not just
pedantry: a padded filter has a kernel, and a design atom can put the
K-frame in that kernel, making G singular. Approximate design accuracy
allows such a tiny-probability atom. The mathematical average retains
the all-Good indicator correctly; the all-seeds native statement cannot
silently remove it. W39 is checking the actual native clean-isometry,
inverse and range-test implementation separately.

## 8. Independent finite checks and final scope

Own `check_compression_and_program_average.py` imports no peer code. It
constructs a k3,t1 relative-positive charge-commuting toy source, including
noncommuting internal charge-block eigenvectors and zero padding. These
small dimensions are deliberately outside(M7); no high-design failure
guarantee or source-rate/drift premise is inferred from them.

Across11 cells and1,154 exact-left-Pauli frames,427 Good frames were
retained. Maximum(M4) error was5.56e-17, exact first-moment error3.89e-16,
and Good polar-isometry error1.81e-15. The minimum eigenvalue of(M11)
RHS minus LHS was-1.74e-16 numerical roundoff; the source-weighted(M12)
margin was0.01056. The public fixed-prefix slice retained isometry to
1.09e-15 and its exact mixed-average identity to2.15e-17. The separate
M7 rational certificate is769/16384<1/16. Raw receipt is
`COMPRESSION_PROGRAM_AVERAGE_CHECKS.json`; runtime inside Python was
0.05251s with NumPy2.5.3 already installed. Peak memory and total
inference/review cost were not measured. No physical operation was made.

The ideal compression/normalization/width mechanism survives this fresh
audit. Finite guard rows, native log/filter/full-unitary error interfaces,
bounded width sampling, final body/flush/outer-design inequalities and
total gate/program/acquisition costs still have to be completed before
claiming a quadratic compiler. There is no claimed physical validation,
practical advantage, unknown-b-band transfer, external proof certification
or novelty verdict. The earlier frozen quartic rows remain unchanged.
