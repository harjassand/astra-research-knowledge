# Actual intermode information: conditional corollary of pending915d6d4b

24 October 2026. This is a short algebraic consequence conditional on the
FULL validity of SHARED_TEMPERATURE_MULTIMODE_LOG_ENVELOPE.md,
SHA915d6d4b5a555a0c8869ceef5abeacaa737be8c191a35e04d195f0b99cb1eb69.
That new theorem still awaits full fresh criticism. This note does not
independently validate it or import root/W42's separate correlated-input
results. Priority UNKNOWN; no experimental/record-acquisition claim.

For the actual unflagged state E theta_(T+R)^tensor N, every d-mode marginal
is E theta_(T+R)^tensor d. Define D_d=d g(T+a)-S_d. Pending(M2) gives

    D_d=d/T{M(l)-ell(l)[lnl+1-H_d+gamma]}+o(ell(l)/T).

All entropies are finite. For any fixed positive block sizes m,k,

    I(A^m:B^k)=D_(m+k)-D_m-D_k
      =[(m+k)H_(m+k)-mH_m-kH_k]ell(l)/T
          +o(ell(l)/T).                              (C1)

More generally the total correlation between fixed disjoint blocks of
sizes n_1,...,n_j summing to N is

    [N H_N-sum_i n_i H_(n_i)]ell(l)/T+o(ell(l)/T).   (C2)

For single native modes this is N(H_N-1)ell(l)/T. For three fixed blocks
of sizes m,k,p, conditional mutual information is

    I(A^m:B^k|C^p)
      =[N H_N+pH_p-(m+p)H_(m+p)-(k+p)H_(k+p)]ell(l)/T
        +o(ell(l)/T), N=m+k+p.                       (C3)

These follow by the exact entropy definitions; the larger M(l)/T,
lnl and Euler terms cancel. The coefficients are positive: for(C1) this
uses increasing H_d, and for(C3) it follows from strict discrete convexity
of f(d)=dH_d, whose increment f(d+1)-f(d)=H_d+1 strictly increases.
For example the two-mode mutual information is ell(l)/T+o(ell(l)/T),
and the three-single-mode conditional mutual information is
ell(l)/(2T)+o(ell(l)/T).

The state is diagonal in the product native photon basis, so these are
also the actual photon-count Shannon informations; no latent R record is
granted. Infinite photon moments above one do not make them infinite:
finite mean energy bounds each entropy. At the critical density q>1,
ell(l)=1/[l(lnl)^q], giving a definite small correlation scale even though
linear intensity covariance is not finite. No n-limit, recovery channel,
free common randomness, finite-data tail certificate or practical source
factory follows from these conditional formulas.
