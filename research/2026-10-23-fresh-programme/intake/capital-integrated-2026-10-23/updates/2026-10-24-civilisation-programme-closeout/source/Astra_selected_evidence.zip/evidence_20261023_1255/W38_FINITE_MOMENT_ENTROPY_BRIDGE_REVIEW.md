# Root fresh reconstruction: finite-moment moving-truncation entropy bridge

23 October 2026. Exact target W38
FINITE_MOMENT_TRUNCATION_ENTROPY_BRIDGE.md SHA
a3b10a025b2f6ff6782484f9814510b65569c23030c6f4583c05540b6efdad26.
Root did not develop this construction and read its full proof after the
author's initial claim. This is correlated internal review, not external
certification or a novelty finding. No producer diagnostics were used as
proof premises. Verdict: no blocking defect found in the classical bridge,
photon-moment transfer, or stated consequence, subject to the separately
reviewed exact Gaussian/amplifier prerequisites identified below.

## Independent tail reconstruction

Let p=2M+delta, M>=3, delta>0, and E|X|^p<infinity. Set R=t^beta with
M/p<beta<1/2. The omitted mass q is O(R^-p), and its second-moment mass
is O(R^-(p-2)). Compare both smoothed conditional laws against the ORIGINAL
matching Gaussian N(0,tI+Sigma); do not rematch the truncated covariance.
The binary mixture identity bounds the error of replacing the source by
its conditional core by the binary entropy h(q) and weighted tail KL.

For each shifted Gaussian, its KL to this matching Gaussian is at most
|x|^2/(2t)+C_Sigma/t^2. Convexity therefore gives the two error scales

    h(q)=O(t^(-beta p) log t),
    q KL_tail=O(t^(-1-beta(p-2)))+O(t^(-2-beta p)).

Both are o(t^-M): beta p>M and
1+beta(p-2)=beta p+(1-2beta)>M. This proof genuinely avoids the original
source's global chi-square. The comparison is mathematical; it performs
no source truncation or free physical tail test.

## Independent moving-density reconstruction

The auxiliary core is not exactly centered and does not have exactly the
original covariance. Its degree-j moment error is O(R^-(p-j)) for j<M;
these errors must be retained. In the rescaled Gaussian density ratio,
the j-th Hermite contribution is bounded by
t^(-j/2-beta(p-j))=o(t^-M/2). The degree-M difference converges to the
original tensor Delta_M.

On the core, |x|/sqrt(t)<=t^(beta-1/2)->0. Taylor's integral remainder
through degree M has Gaussian L2 AND L4 norm bounded by a constant times
(|x|/sqrt(t))^(M+1). Minkowski and the uniformly bounded (M+1)-st moment
give O(t^(-(M+1)/2)). For the subtracted genuine Gaussian comparison
source, the same bound follows with its finite exponentially weighted
moments. It is not legitimate to use that latter argument on the original
heavy-tailed source; the proof does not do so.

The rescaled covariance I+Sigma/t tends to I and the prefactor B_t tends
to one, with uniform polynomial Gaussian domination. Hermite orthogonality
therefore gives

    ||f_core||_2^2 = ||Delta_M||_F^2/(M! t^M)+o(t^-M),
    ||f_core||_4 = O(t^-M/2).

Scalar |(1+f)ln(1+f)-f-f^2/2|<=|f|^3/2 for f>=-1 and normalization
convert this to KL with error at most ||f||_2 ||f||_4^2/2=o(t^-M).
Together with the tail bounds this proves the stated classical coefficient
including Delta_M=0. Singular source covariance is harmless because the
added tI is faithful and the comparison Gaussian can be integrated on its
own source support when deriving the remainder.

## Quantum and two-port transfer

Root independently checked the radial Husimi identity: angular integration
kills off-diagonal number matrix units; on total shell k, |alpha|^2 has
Gamma(k+n,1) moments. Hence its real variable X=sqrt(2)(Re alpha,Im alpha)
satisfies E|X|^(2r)=2^r Tr rho Gamma(N+n+r)/Gamma(N+n), for real r>0 in
extended values. The gamma ratio is comparable to (N+1)^r. Thus the stated
finite photon moment supplies precisely the classical p-moment required.

The preparation/heterodyne sandwich at noise times T-1 and T, and output
times (2G-1)T-G and one unit higher, is the SAME exact normal-channel
interface in the independently reviewed earlier exponential-tail packet.
Applying the newly proved classical finite-moment limit at both offsets
preserves its coefficient because fixed time shifts have ratio tending to
one. No quantum relative-density moment is inferred.

For the amplifier consequence, the only imported analytic prerequisites are
the exact Gaussian EPnI baseline and its entropy-target derivative/Hessian
limits from W38 d0e95b06 Sections2--3,5, fully reconstructed in W17's frozen
52e1a998 review. Those Gaussian facts require no exponential source tails.
Independence and lower-order moment matching give the output tensor
G^(M/2)A+(G-1)^(M/2)B, with the conjugation reflection retained.
Weighted Cauchy-Schwarz yields the strict factor
theta^(M-1)+(1-theta)^(M-1)<1 for M>=3. Therefore at least one nonzero
first-unmatched tensor gives a positive order-T^-M correction to a
nonnegative Gaussian baseline. The remainder is little-o for each FIXED
source pair,n,G. No uniform threshold is proved.

For the all-photon-moments corollary, an all-Gaussian moment sequence is
determinate along every real projection (Gaussian Carleman), so equality
of every Husimi moment forces a Gaussian Husimi law by Cramer-Wold and a
Gaussian state by injectivity. Otherwise the first unmatched finite degree
exists. Choosing the smaller input degree and zero tensor for the other
input makes the stated argument valid. No moment determinacy of a general
non-Gaussian heavy-tailed law is being assumed.

The radial Pareto example also has the stated coefficient. For a=1/(p-2),
the real fourth cumulant is c_p times the sum of the three Kronecker
pairings, with c_p=1/[(p-2)^2(p-3)]. Its d=2 tensor norm squared is
24 c_p^2, hence KL coefficient c_p^2/2. The safe theorem premise needs
p>5, not merely finite mean energy p>2. Original-state chi-square can
remain infinite after every finite heat without contradicting this KL
calculation.

## Limits and unresolved novelty

This closes the stated proof obligation internally, not the unheated EPnI
problem or the general finite-energy class. Heavy tails with only a few
moments remain outside it. Actual heat changes the input and becomes
entanglement breaking at the stated T>=1 convention; its energy,
preparation, certification, pumping, precision, disposal and reset are real
unacquired costs. Moment bounds and an eventual threshold are not obtained
from mere normality or finite energy. As delta approaches zero, the
truncation-rate margins approach zero; practical threshold claims would
need numerical bounds that this proof does not provide.

Generic classical Gaussian-smoothing/low-SNR entropy asymptotics have strong
prior art. W38 records Chen--Niles-Weed's exact exponential-tail coefficient
and Guo--Wu--Shamai--Verdu's moment/low-SNR route; the latter's version
qualification is not treated here as an independently verified premise.
This proof stands on its own, and priority of the weakened-hypothesis
quantum consequence remains UNKNOWN. No numerical fixture, native code,
physical device or practical advantage was executed by this root review.
Mission NOT_ACHIEVED.
