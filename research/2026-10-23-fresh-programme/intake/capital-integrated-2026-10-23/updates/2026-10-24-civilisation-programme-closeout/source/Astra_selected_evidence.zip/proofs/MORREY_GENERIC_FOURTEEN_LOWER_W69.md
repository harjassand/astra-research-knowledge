# Geometry continuation: generic lower bound and the valid Jensen bridge

Worker w69, 23 October 2026. This follows the independent exact audit;
it does not change the source claim's public status or history. Generic
polynomial arguments and laminate Jensen iteration are standard tools.
Exact historical priority and external acceptance remain UNKNOWN.

## 1. A Zariski-open dense lower-bound class

Retain the fixed physical mesh, original positive area weights and zero
outer nodal values. The six interior nodal vectors
`u=(u3,...,u8)` range over all of R^12. The actual face gradients A_i(u)
are linear functions of these coordinates, as independently reconstructed.
For each nonempty subset S, its physical weighted mean M_S(u) is also
linear because W_S is a fixed positive rational constant.

Take the same 283-member family C as in the audited center certificate.
For each of its 3,682 disjoint pairs A,B whose union is outside C define

    p_AB(u)=det[M_A(u)-M_B(u)].

Each is a homogeneous quadratic polynomial with rational coefficients.
Every p_AB is nonzero as a polynomial, since its exact value at the audited
center is nonzero. For each of the 78 pairs of physical atoms, choose the
matrix-entry difference ell_ij(u) used by the distinctness certificate.
It is a nonzero linear polynomial, again because its center value is nonzero.

Define the finite product

    P(u)=(product over escaping pairs of p_AB(u))
           (product over atom pairs of ell_ij(u)).

It is a nonzero polynomial: its center value is nonzero. Let

    O={u in R^12:P(u)!=0}.

Then O is nonempty and Zariski open; it is also Euclidean open, dense and
of full Lebesgue measure. These are elementary facts about a nonzero real
polynomial. For every u in O, all atoms stay distinct and every family merge
that would leave C has a nonzero determinant. The same structural induction
therefore proves:

    For every u in O, every finite binary rank-at-most-one tree representing
    the exact actual physical law has at least fourteen positive terminal
    occurrences.                                             (G1)

This is a generic lower bound across the entire parameter space, rather
than merely a neighborhood of the center. It does not assert the existence
of any finite tree at a generic point, nor an upper bound of fourteen.
The audited center itself lies in O and has an exact fourteen-leaf tree.
The independently certified radius-2^-12 cube also lies in O.

## 2. Explicit polynomial representation and finite verification

Write h_i,v for the gradient of scalar nodal hat v on face i. For a subset,
let h_S,v be its fixed physical weighted mean hat gradient. If
`v_k=h_A,k-h_B,k`, then

    M_A(u)-M_B(u)=sum_{k=3}^8 u_k tensor v_k,
    p_AB(u)=sum_{k<l} det(u_k,u_l) det(v_k,v_l).     (G2)

Thus one stores fifteen rational coefficients per forbidden merge, rather
than sampling real coordinates or expanding an enormous product. The
independent program checks (G2) against the actual center determinants.
After clearing denominators, dividing the integer gcd and fixing the first
nonzero coefficient positive, the 3,682 escaping pairs have 3,633 distinct
primitive quadratic polynomials. Their exact coefficients and pair links
are retained in `INDEPENDENT_REPLAY.json`.

Using these distinct factors, P can be represented with degree at most
`2*3633+78=7344`; the number is only a certificate-size bound. There is no
need to expand P. The nonzero center evaluations certify that every factor
is nontrivial and their product is nonzero over the real polynomial ring.

The result does not promote an abstract graph into an actual gradient law:
the coefficients are derived from the original physical interpolation and
fixed area masses for every parameter point.

## 3. The valid all-background Jensen consequence at the center

The independently replayed fourteen-leaf tree gives a finite laminate with
root zero and coalesced physical measure nu. Translate every matrix in the
tree by an arbitrary background matrix B. Every jump remains rank at most
one, every positive split ratio is unchanged, and the root becomes B.
For every finite-valued globally rank-one-convex function f on R^(2x2),
iterate the defining two-point convexity inequality through the thirteen
binary splits to obtain

    f(B)<=sum_{i=0}^{12} w_i f(B+A_i)  for every B.    (G3)

This is a standard logical consequence of the explicit tree. The same
leaf-count lower/upper is preserved by translations of the matrices or
invertible output transformations; rank and positivity are preserved.
Adding a common affine boundary trace to the physical map supplies exactly
the matrix translation in G3.

G3 is a positive Jensen certificate for this supplied actual law. It cannot
be recast as a rank-one-convex/non-quasiconvex counterexample. Nor does it
prove Jensen for every law in the lower-bound box: those laws have only a
lower leaf-count certificate here, and require a separate upper tree or
another positive Jensen argument.

## 4. Paired transfer states

| Source and destination | State under the composition protocol |
| --- | --- |
| Exact fixed-geometry closed family and nonzero center jumps -> G1 | PROVEN LOGICAL DEPENDENCY. Gradients/means are linear in all twelve coordinates and forbidden jumps are explicit nonzero polynomials; the closed-family induction is preserved on their joint nonzero set. |
| Explicit center fourteen-leaf tree -> G3 for every background and globally rank-one-convex f | PROVEN LOGICAL DEPENDENCY. Translation preserves jumps and thirteen finite applications of rank-one convexity give the displayed inequality. |
| Box or generic lower>=14 -> nonlamination or a Morrey counterexample | REFUTED TRANSFER as an inference from this certificate. The center belongs to both lower-bound classes and has a legal fourteen-leaf tree and G3. |
| Center upper tree -> the same upper tree on the full box | REFUTED TRANSFER. The exact interior perturbation u3^1=2^-21 breaks eight jumps. |
| Center upper tree -> existence of some generic fourteen-leaf upper tree | CANDIDATE CONNECTION only; no such universal/existence lemma is supplied or disproved. One-exception common-line trace assumptions are absent at generic nodal values. |

`GEOMETRY_BRIDGE.json` records the paired representation, error, cost and
scope contract. This is a local research record; it changes no corpus
claim ledger and makes no publication or historical-priority claim.
