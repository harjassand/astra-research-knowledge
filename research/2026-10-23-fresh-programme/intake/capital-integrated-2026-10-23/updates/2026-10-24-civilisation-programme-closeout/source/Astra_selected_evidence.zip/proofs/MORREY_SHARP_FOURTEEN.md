# Trace-star replacement and an exact fourteen-leaf actual N9 law

The strongest result here is a sharp finite-order statement for one complete
actual N9 law: its minimum number of positive terminal occurrences in a
finite binary rank-at-most-one laminate tree is exactly fourteen. The lower
bound excludes every thirteen-leaf tree shape, including arbitrary
intermediate states. A full twelve-dimensional box has the same lower bound.
This is not nonlamination and is not a Morrey resolution. A constructive
fourteen-leaf tree is given at the center.

## Small-loop packet compiler

The first independent derivation in `CORE_DERIVATION.md` gave valid but
looser bounds C4->5, C5->7. W43 independently communicated the following
matching refinement, which is credited here. The current exact compiler
`cycle_module.py` is separately implemented with no producer-code imports.

For any positive two-by-two law balanced for determinant at its mean, if its
atoms admit a partition into two rank-one pairs, join each full pair and then
join their means. Determinant balance forces the last jump to have zero
determinant. Thus a rank-one C4, or a four-vertex rank-one path, has a
four-leaf tree with its exact current masses.

A positive balanced C5 admits a six-leaf tree. If some atom has zero
determinant displacement from the mean, peel it whole; the remaining four
vertices of the cycle form a path and have a perfect matching. Otherwise
the weighted determinant displacements sum to zero, so a connected cycle
has an opposite-sign edge. Peel its maximal pair. Exhausting one endpoint
leaves a four-vertex path, hence four terminal leaves. Exhausting both
endpoints leaves three vertices with a rank-one pair and therefore a
three-leaf tree by the same determinant-balance identity. The total is at
most six. Every original packet mass is retained and all terminal matrices
are original atoms.

## Universal actual one-exception module

Suppose five of the six N9 interior nodal values lie on a fixed output line
through zero, and the sixth value is arbitrary. Apply an invertible output
basis so the first component `phi` vanishes on that line. It is nonzero
only at the exceptional vertex `v` (the rank-one degenerate case is easier).
Its actual physical star has zero `phi` trace on its polygon boundary.
The boundary operation in `CORE_DERIVATION.md` proves that the star mean
has zero first row and its physical law has exact determinant balance.
The star's physical face-adjacency link is a four- or five-cycle.

The module above gives at most four leaves for a degree-four star and six
for a degree-five star. Every outside physical face has first gradient row
zero. All outside atoms and the star mean consequently have their columns
in one common output line, so they may be joined in any binary order by
rank-one splits. The full law therefore has at most thirteen leaves for a
degree-four exception, and fourteen for a degree-five exception, for ALL
nodal values in this subclass. Adding a common affine boundary trace simply
translates the matrices and preserves the construction.

The implementation verifies the universal physical hat identities for all
six stars: zero integrated first gradient, zero six determinant cross
coefficients, zero first-hat gradients outside the star, and an actual
physical four/five-cycle. The 180 additional exact rational examples in
`ONE_HAT_MODULE_RECEIPT.json` are finite tests and are not the basis of this
all-values module.

## Exact actual thirteen-atom example

Use the frozen physical N9 mesh and the original positive normalized face
masses. Set the outer values to zero and take

```
u3=(0,1), u4=(1,0), u5=(0,2),
u6=(0,5), u7=(0,7), u8=(0,11).
```

The thirteen independently reconstructed physical gradients are all
distinct. The exceptional star is at vertex four, with physical faces
`S={0,2,4,8,10}` and total mass `21/50`. Its mean and determinant
displacements, in that face order, are

```
M_S = ((0,0),(13/21,61/42)),
f = (13/42,-127/252,-11/28,197/42,-167/84).
```

Its only rank-one edges are

```
(0,2),(0,4),(2,8),(4,10),(8,10),
```

an exact five-cycle. No star atom is rank-one connected to the star mean.
This star itself needs at least six terminal occurrences in any binary
tree: with five leaves, the root is either `1+4`, which would require one
of the displayed `f` values to be zero, or `2+3`. In the latter case the
two-atom group must be an edge of the cycle. Its three-atom complement is
a three-vertex path. Its two existing pair determinants vanish, but the
missing diagonal determinant does not, so its positive physical law cannot
satisfy determinant balance at its own mean. This excludes every five-leaf
shape. The six-leaf compiler is therefore sharp for this actual trace-star
packet.

The complete thirteen-atom law also needs an additional occurrence, despite
being allowed to mix star and outside atoms in arbitrary intermediate
states. This stronger lower bound is established next.

## Complete closed-family lower certificate

Because all thirteen actual matrices are distinct and all physical masses
are positive, a tree with at most thirteen terminal occurrences must have
exactly one occurrence of every physical atom, each with its prescribed
area mass. For a nonempty face subset `T`, its total mass and mean are
fixed; any subtree with exactly those leaves must have that mean.

Let `C` be the finite family carried in
`OPTIMAL_FOURTEEN_CERTIFICATE.json`. It consists of 283 nonempty subsets,
contains every singleton, and omits the full set of thirteen faces. It is
closed under EVERY lawful disjoint rank-one merge:

```
A,B in C, A intersect B empty,
det(M_A-M_B)=0  =>  A union B in C.
```

Structural induction up any hypothetical once-per-face binary tree then
puts every node's leaf subset in `C`, contradicting exclusion of the full
set. This argument allows all binary shapes, all merge orders and arbitrary
intermediate means. It is not limited to a dictionary of packets, maximal
peeling, physical adjacency or root splittings of one/two atoms.

The constructor computes all 8,191 nonempty subsets. The necessary
determinant balance test can be evaluated by the exact identity

```
sum_i w_i det(A_i) - W_T det(M_T)
   = (1/W_T) sum_{i<j in T} w_i w_j det(A_i-A_j).
```

There are 549 balanced subsets. Recursing over every proper binary
partition yields the 283-member family and its rank-one merge witnesses.
No search budget or timeout is involved. All subsets of the eight outside
faces `{1,3,5,6,7,9,11,12}` belong to the family, plus 28 explicitly listed
exceptional subsets touching the star.

The separate verifier in `optimal_fourteen.py` does not rely on the dynamic
program's pair-sum decision. It reconstructs all actual gradients from
physical nodal data, reconstructs every actual weighted subset mean, and
checks every disjoint pair of family members directly. It verifies 3,061
rank-one merge pairs remain inside the family and 3,682 pairs whose union
would leave the family have nonzero jump determinant. It also replays the
family's internal merge witnesses. Thus the stated closed family alone is
a finite exact lower certificate, independently of the search that found
it.

## Explicit fourteen-leaf upper tree

Inside the star, peel the packet

```
face2 mass 3/25,
face0 mass 127/650.
```

The retained mass of face zero is `3/650`. Split the remaining star law
into its two full rank-one pairs

```
(face0 mass3/650, face4 mass1/25),
(face8 mass1/50,  face10 mass1/25).
```

The maximal-pair identity makes the first outer jump rank one, and
determinant balance forces the final pair-mean jump rank one. This is a
six-leaf star tree, duplicating only face zero. Join it to each of the eight
outside physical atoms with its full original weight; all those means have
zero first row. The resulting full physical tree has fourteen leaves and
thirteen binary splits. The independent exact replay verifies every jump,
root zero, total mass one and all thirteen prescribed face totals.

Together with the lower certificate this proves exact minimum fourteen
for the supplied complete actual gradient law. Auxiliary intermediate
matrices are allowed as the tree means; positive auxiliary terminal atoms
are not, because they would change the requested physical measure.

## Uniform full-dimensional lower box

Allow every one of the twelve displayed nodal coordinates to vary
independently by `1/1048576`. The interval verifier
`open_thirteen_lower.py` uses outward 120-bit integer-grid arithmetic.
It proves that all thirteen actual matrices stay distinct and that all
3,682 potentially escaping family merges have determinant intervals
strictly excluding zero throughout the box.

Formerly valid family merges are allowed to disappear; the lower proof
needs only that no new lawful merge can leave the family. Every singleton
remains in the same finite family, and the full subset stays excluded.
Thus every actual physical law in this full twelve-dimensional box needs
at least fourteen terminal occurrences in any finite binary laminate tree.
This is an all-values proof and not an extrapolation from finitely many
perturbations.

The upper fourteen-leaf tree uses common-line trace identities and is proved
at the center and on its one-exception subclass. It is NOT asserted on the
whole box. The box lower bound does not exclude larger finite trees,
limiting laminates or another representation.

All inputs are constructed exact mathematical fields. Historical priority,
external acceptance and practical/physical consequences remain unknown.
The finite subset constructor/direct verifier and the full interval lower
replay each ran in less than one second on this host; those body timings
exclude derivation, source reading and review costs. No physical acquisition
or experiment occurred.
