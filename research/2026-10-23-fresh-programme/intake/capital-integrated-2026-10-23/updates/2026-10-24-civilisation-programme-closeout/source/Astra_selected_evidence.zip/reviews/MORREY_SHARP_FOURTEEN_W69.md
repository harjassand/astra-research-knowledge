# Independent critical audit: the actual N9 law has minimum fourteen

Worker w69, 23 October 2026. The preceding amplifier files were left unchanged.
No descendant agents or producer code were used. Archived prompts were data.
The Astra source corpus remained read-only at
`e606bfc587c76bdcae8b8fa3ec33e721efa2fbac`; `agent/COMPOSITION.txt` was read
before deriving the separate geometry/Jensen bridges.

## Verdict

**PASS for the exact center minimum14 and the all-real 12-coordinate lower
bound in the assigned box.** I found no load-bearing mathematical gap.
The finite closed-family proof really excludes every binary tree with at
most thirteen positive terminal occurrences, not just a peeling grammar.
The explicit fourteen-leaf tree is legal with precisely the original
physical weights. The interval statement is an all-values statement over
real coordinates, including the closed box, and does not require rational
perturbations or extrapolation from sampled points.

The assigned inputs match their exact SHA256 pins:

- `SMALL_LOOP_AND_SHARP_FOURTEEN.md`:
  `e2ddb2b08e9aee00d84658fee8a2a464821b8af7da530eab424849e80222daf3`.
- `OPTIMAL_FOURTEEN_CERTIFICATE.json`:
  `b88c0f1d8b98c099d1c6137f9aa966b01494d11adc4a84b5d3e2ae62e902dc00`.
- `OPEN_THIRTEEN_LOWER.json`:
  `b6ae40a64b7625e0481e40141876abe22b4da1cac64c617b63186d264c2a09f5`.

All original inputs are frozen in `pinned/`; the physical geometry has SHA256
`fc0d299d8ff65b74adfcf6c7b312c354777604a92b4e6071715592aec689b05a`.
`INPUT_MANIFEST.json` preserves full paths and byte sizes. No source file
was executed or modified. The independent replay is `independent_replay.py`.

## 1. The exact object and leaf-count contract

The domain is the physical triangle with outer vertices `(0,0),(10,0),(0,10)`.
It contains the six fixed interior vertices from the pinned geometry and
the thirteen listed physical triangles. The outer nodal values are zero.
At interior vertices 3,...,8 the center values are

    (0,1), (1,0), (0,2), (0,5), (0,7), (0,11).

Let u be the continuous affine interpolant on each physical triangle, and
let A_i be its actual 2x2 gradient on face i. The requested measure is

    nu = sum_{i=0}^{12} w_i delta_(A_i),
    w_i=area(face_i)/50 >0.

A representation is a finite full binary tree. Every leaf has positive
mass and is one of the requested matrix atoms. Each internal matrix is its
two children's mass-weighted mean and the child jump has determinant zero
(rank at most one in 2x2). The root is the physical barycenter. Terminal
occurrences are counted before coalescing repeated copies of the same atom.
Zero jumps are allowed, but zero-mass leaves can be pruned. Negative weights
are not laminates. Positive auxiliary terminal matrices outside the support
would change the measure and are excluded by exact measure equality;
arbitrary auxiliary *intermediate means* are fully allowed.

## 2. Reconstructing the actual physical law

The independent program performs exact 3x3 affine interpolation on every
physical face, rather than taking any displayed gradient as a premise.
It independently checks that all triangle areas are positive, the total
area is 50, every vertex lies inside the outer triangle, every pair of
triangle interiors has zero intersection area by rational polygon clipping,
and every interior edge has two incident faces with only the three outer
boundary edges occurring once.

The reconstructed weights and actual matrices are:

| Face | Weight | First gradient row | Second gradient row |
| --- | --- | --- | --- |
| 0 | 1/5 | (0,1/2) | (0,0) |
| 1 | 1/5 | (0,0) | (1/2,0) |
| 2 | 3/25 | (1/3,-1/6) | (-1/6,1/3) |
| 3 | 1/5 | (0,0) | (-5/2,-5/2) |
| 4 | 1/25 | (-1/2,-1) | (1,3) |
| 5 | 1/25 | (0,0) | (1/2,2) |
| 6 | 1/25 | (0,0) | (19/2,3) |
| 7 | 1/25 | (0,0) | (-11/2,-9/2) |
| 8 | 1/50 | (0,-1/2) | (10,21/2) |
| 9 | 1/50 | (0,0) | (10,3) |
| 10 | 1/25 | (-1/2,-3/4) | (1,6) |
| 11 | 1/50 | (0,0) | (-6,-9/2) |
| 12 | 1/50 | (0,0) | (-6,-5) |

These match every supplied gradient exactly and are thirteen distinct
matrices. The program also checks every coefficient of the universal
zero-mean and determinant null-Lagrangian identities for the zero-boundary
PL interpolation: the weighted scalar-hat gradients sum to zero, and every
weighted cross coefficient of two hats is zero. Thus the physical root and
determinant balance are not properties of an invented abstract matrix law.

## 3. Why the closed family excludes ALL thirteen-leaf trees

Since all thirteen prescribed atoms are distinct with positive weights,
fewer than thirteen positive leaves cannot represent nu. If a tree has
exactly thirteen leaves, each atom appears once with mass w_i. Consequently
each subtree is determined by a nonempty face subset S, with

    W_S=sum_{i in S}w_i,
    M_S=(sum_{i in S}w_i A_i)/W_S.

This is why arbitrary intermediate matrices do not escape the certificate:
they must equal these barycenters. Every pair of children has disjoint
subsets, and their union is the parent subset.

For every nonempty subset I independently check the identity

    sum_{i in S} w_i det A_i - W_S det M_S
       =(1/W_S) sum_{i<j in S} w_i w_j det(A_i-A_j).

There are 8,191 nonempty subsets and exactly 549 balanced ones. More
importantly, the independent dynamic program does **not** use this balance
test as a prefilter. It considers all 788,970 unordered proper bipartitions
of all subsets and directly tests `det(M_A-M_B)=0` whenever both children
are already attainable. It reproduces exactly the proposed family C of
283 attainable once-per-face subsets.

For the lower bound, maximality or the dynamic program is unnecessary.
The following independently verified finite facts suffice:

1. Every singleton belongs to C, and the full mask 8191 does not.
2. For every pair of disjoint members A,B of C with a rank-at-most-one mean
   jump, their union belongs to C.

The direct pair replay finds 3,061 lawful disjoint merges, all remaining
inside C, and 3,682 disjoint pairs whose union would escape C, each with
nonzero jump determinant. It also verifies all supplied internal witnesses
and independently constructs its own witnesses.

Induction from the leaves of any hypothetical once-per-face binary tree
places every node's face subset in C. The root would then place all thirteen
faces in C, a contradiction. This includes every binary shape, every merge
order, zero jumps, nonphysical pairings, and every legally determined
intermediate mean. It does not rely on physical adjacency, maximal peels,+a packet dictionary, a timeout, or an unexplored tree search.

## 4. The fourteen-leaf upper and the star module

The actual exceptional star S={0,2,4,8,10} has mass 21/50 and mean

    M_S=((0,0),(13/21,61/42)).

Its five determinant displacements are, in that face order,

    13/42, -127/252, -11/28, 197/42, -167/84.

Its only rank-one edges are `(0,2),(0,4),(2,8),(4,10),(8,10)`, an exact C5.
The five-leaf star obstruction is sound: a 1+4 root would require a zero
determinant displacement, which does not occur. A 2+3 root must take an
edge as its two-atom subtree; the complementary three-vertex path has a
single nonzero missing-diagonal determinant and positive masses, so cannot
be determinant-balanced at its own mean. This covers all five-leaf shapes.
The independent subset replay also excludes that star subset directly.

The upper tree is constructed independently as

    pair(face2,3/25; face0,127/650)
       versus
    [pair(face0,3/650; face4,1/25)
       versus pair(face8,1/50; face10,1/25)].

This six-leaf star tree splits face0 into exactly two positive occurrences.
Attach faces 1,3,5,6,7,9,11,12 successively with their full physical weights.
Each outside atom and the accumulating star/outside mean has zero first
gradient row at the center, so these outside joins are rank at most one.

The replay directly checks all thirteen actual jump determinants are zero,
all fourteen terminal masses are positive, every coalesced face mass is
exactly its original w_i, the total mass is one, and the root is zero.
The lower and upper together prove exact minimum fourteen at the center.

The C4/C5 analytic modules in the source are also sound under their stated
positive determinant-balance premises. A balanced four-atom law with two
rank-one full pairs has a legal last join by the determinant identity.
For a C5 law, weighted displacements sum to zero. Either peel a zero-load
atom, leaving a four-vertex path with a perfect matching, or choose an
opposite-sign edge and peel its maximal balanced pair. Exhausting one
endpoint leaves four matched vertices; exhausting both leaves a three-path.
This gives at most six leaves and retains all physical mass. The matching
refinement's W43 attribution is preserved; this audit does not claim it.

## 5. The full real 12D interval proof

Every actual gradient is linear in the twelve real nodal coordinates.
Every fixed-mass subset mean is therefore linear too. I construct its exact
rational coefficients from the independently reconstructed scalar hats.
For a linear entry `L(u)=sum c_k u_k`, over the full cube of radius r,

    L(u) in [L(center)-r sum|c_k|, L(center)+r sum|c_k|].

These are exact bounds for real coordinates. For a determinant, take the
four endpoint products for each product of entries, then subtract intervals.
All arithmetic is rational and has no floating-point or finite-grid rounding.
Shared-variable dependence can widen this enclosure but cannot invalidate it.

At r=2^-20 all 3,682 potentially escaping merges have determinant intervals
strictly excluding zero. The minimum independently certified determinant
margin is `11528797/4060086272`. For all 78 pairs of atoms, one supplied
matrix-entry difference has a strict nonzero interval throughout the cube.
Every independent determinant and distinctness interval lies inside its
supplied 120-bit interval, and each supplied interval itself excludes zero.
Thus the stored interval data are validated, rather than merely trusted.

The same finite C then excludes every once-per-atom tree at every real point
in the cube. A center-valid merge is allowed to disappear. Only an escaping
merge could invalidate the induction, and every such merge stays blocked.
Atom distinctness ensures that thirteen leaves still means one per face.

As a separate continuation, the same independent exact method certifies
the larger closed cube **r=2^-12=1/4096**, with minimum determinant margin
`6317/6230016`. See `LARGER_BOX_REPLAY.json`. This is a new proof extension,
not an assertion about what the assigned original certificate claimed.
The first unresolved interval at r=2^-11 demonstrates only failure of that
enclosure method there; it is not a zero-determinant witness or a smaller
tree.

## 6. Critical falsifiers and one metadata defect

- The center itself refutes the inference “no thirteen-leaf tree implies
  nonlamination”: it has the explicit fourteen-leaf tree.
- The same fourteen-leaf tree does not extend to the full box. Change only
  u3's first coordinate to 2^-21, strictly inside the original open box.
  Its original weights and root remain correct, but eight jumps become
  illegal; the first nonzero determinant in the replay is
  `-63/121634816`. This does not exclude a different fourteen-leaf tree.
- Root determinant balance and connected physical rank-one adjacency do
  not imply a once-per-atom tree: this actual law satisfies both and still
  requires an atom to be duplicated.
- A list of center-valid joins need not remain valid under perturbation.
  The correct robust certificate forbids all escaping joins instead.
- Counting support atoms after coalescing would call both the impossible
  thirteen-leaf tree and the valid fourteen-leaf tree “thirteen atoms.”
  The terminal-occurrence convention is essential.

There is a non-load-bearing receipt-label defect. The reused producer
`replay` helper outputs a field named `all_18_jump_determinants_exact_zero`
even for this tree with thirteen splits. The actual jump list and independent
replay contain thirteen legal jumps, so the theorem survives. The field
should be renamed to `all_jump_determinants_exact_zero` or to the correct
number, rather than reported as eighteen checks.

## 7. Evidence and surviving boundaries

The independent replay passed **34,372 assertions**, including exact mesh,
physical weights, all-subset identity/completeness, every family witness,
all escaping intervals and atom pairs, and the upper-tree replay. Raw
data are in `INDEPENDENT_REPLAY.json`. The analytic induction explains why
these finite checks certify all tree shapes and all real parameters in the
box; numerical agreement alone is not being generalized.

`GENERIC_GEOMETRY_BRIDGE.md` proves a further generic lower bound by explicit
nonzero determinant polynomials and records the standard Jensen consequence
of the center's finite laminate. Neither conclusion gives a generic
fourteen-leaf upper, a universal N9 laminate cover, nonlamination, a limiting
laminate obstruction, or a Morrey resolution. Exact historical priority,
external acceptance and practical consequences remain UNKNOWN. No physical
experiment or acquisition occurred.
