# Coherent sandwich and the first non-Gaussian moment after heat

23 October 2026, W38. New independent proof candidate; fresh audit pending.
Earlier frozen proofs and audits remain unchanged. The general UNHEATED
all-finite-energy independent-input amplifier EPnI remains NOT_ACHIEVED.

## 1. Exact proposed results

Fix finite mode count n. Let rho have a supplied finite exponential photon
moment Tr rho exp(delta N)<infinity for some delta>0. Let gamma have the
same centered first/second moments. If rho is not Gaussian, there is a
finite first unmatched Gaussian moment order M>=3. Let Delta_M be the
real symmetric M-tensor of its Husimi moment difference from the matching
classical Gaussian; all lower moment differences vanish. Then

    D(H_T rho || H_T gamma)
      =||Delta_M||_F^2/(2 M! T^M)+O(T^(-M-1)).             S1

The coefficient is independent of the added vacuum covariance in the
Husimi representation. Equivalently it is the first nonzero Weyl cumulant
tensor, since Gaussian convolution changes only the second cumulant. The
state, n, exponential-moment constants and M are fixed first. This is a
normal infinite-dimensional quantum relative-entropy asymptotic, derived
by TWO data-processing bounds rather than quantum L3 contraction.

For the amplifier application, fix G>1, lambda=G-1, s=G+lambda and
J=direct_sum diag(1,-1). Let rho_A,rho_B be independent n-mode states with
finite exponential photon moments, centered covariances

    V_A=(a+1/2)I, V_B=(b+1/2)I, a,b>=0.                  S2

Within each group arbitrary coherences and correlations are permitted.
After adding ACTUAL independent H_T to every mode of both groups, EPnI
holds exactly for all sufficiently large finite T. If at least one input
is non-Gaussian, its entropy-form gap is kappa T^-m+O(T^-m-1), with an
explicit strictly positive kappa given in Section5. If both are Gaussian,
S2 makes them product thermal states, and EPnI is an exact equality.

This removes finite Fock support and finite charge bandwidth from the
earlier isotropic heated-input result. It does NOT remove the actual heat,
the exponential-tail hypothesis, isotropic covariance, fixed-source limit
order or independent-input premise. At T>=1 these actual heated states
are positive mixtures of native product coherent states; initially supplied
internal entanglement has been destroyed by the heat.

## 2. Exact k-copy classical kernel and moment cancellation

Let X be a centered random vector in R^d with covariance Sigma>=0 and
E exp(beta |X|^2)<infinity for some beta>0. Let Z~N(0,Sigma), independent
where appropriate, and put the finite signed measure

    mu=law(X)-law(Z).

Its total variation has an exponential quadratic moment at a sufficiently
small positive parameter. Suppose all its moments of degree <M vanish,
M>=3, and put Delta_M=integral x^(tensor M) mu(dx); this tensor may be zero
if matching extends farther. For t>0 write

    p_t=law(X+Z_t), gamma_t=N(0,tI+Sigma),
    f_t=(p_t-gamma_t)/gamma_t, epsilon=1/t.

For k=2 or4, Gaussian integration gives the EXACT identity

    integral gamma_t f_t^k
      =integral K_(k,epsilon)(x1,...,xk) product_i mu(dxi),

    K_(k,epsilon)=det(I+epsilon Sigma)^(k/2)
                    /sqrt[det(I+k epsilon Sigma)]
       *exp{epsilon sum_(i<j) xi.xj
          -(k-1)epsilon^2 U^T Sigma(I+k epsilon Sigma)^-1 U/2},
    U=sum_i xi.                                           S3

Indeed the Gaussian y precision in product_i G_t(y-xi)/gamma_t(y)^(k-1)
is epsilon(I+k epsilon Sigma)(I+epsilon Sigma)^-1. Completing its square
gives exactly the determinant and exponent in S3, including k=4.

All required derivatives at epsilon=0 can be passed under these signed
integrals, not merely formal power series. On a fixed sufficiently small
positive epsilon interval the log-kernel derivatives of any specified
finite order are bounded by C(1+sum_i |xi|^2). The kernel itself obeys

    |K_(k,epsilon)|<=C exp[epsilon(k-1)sum_i |xi|^2/2].

The negative quadratic exponent in S3 was dropped using Sigma>=0;
sum_(i<j)xi.xj<= (k-1)sum_i |xi|^2/2. Exponential moments of |mu| absorb
this factor and every fixed polynomial derivative. Thus absolute Fubini,
differentiation through any specified finite order, and Taylor's integral
remainder are justified after shrinking the positive epsilon interval.

The coefficient of epsilon^r in S3 is a polynomial in all xi of total
degree at most2r. Since each factor mu annihilates degrees <M separately,
an integrated coefficient can survive only when EACH xi has degree>=M,
and hence only if 2r>=kM.

For k=2 the first possible order is r=M. To attain degree2M there, only
the M-th power of epsilon x1.x2 in the exponential can contribute: every
other log term has degree2 at order at least2, or degree0. Therefore

    integral gamma_t f_t^2
       =||Delta_M||_F^2/(M! t^M)+O(t^(-M-1)).             S4

For k=4 all orders below2M vanish, so

    integral gamma_t f_t^4=O(t^(-2M)).                    S5

These statements include Delta_M=0. No finite support, finite number of
charge sectors, uniform pointwise relative-order bound, or arbitrary
classical Lp channel contraction was used.

Cauchy-Schwarz under gamma_t gives
integral gamma_t |f_t|^3=O(t^(-3M/2)). For every scalar f>=-1,

    |(1+f)log(1+f)-f-f^2/2|<=|f|^3/2.

Since integral gamma_t f_t=0, this and S4-S5 prove

    D(p_t||gamma_t)
      =||Delta_M||_F^2/(2M!t^M)+O(t^(-M-1)),              S6

using 3M/2>=M+1 for M>=3. All relative moments and this entropy are finite
at sufficiently large t by the same integral domination. This is a
classical heat asymptotic and should be compared with existing entropic
Edgeworth expansions; generic moment cancellation is not claimed novel.

## 3. The exact two-sided quantum sandwich

In quadrature coordinates X=sqrt(2)(Re alpha1,Im alpha1,...), the positive
Husimi law of rho has covariance Sigma=V_rho+I/2. Direct integration gives

    E exp(beta |X|^2)
      =(1-2beta)^-n Tr rho (1-2beta)^(-N),                S7

for sufficiently small beta>0. The supplied photon exponential moment
therefore guarantees the classical premise. Centering is harmless: a
fixed translation preserves an exponential quadratic moment at a smaller
parameter, and displacements preserve all entropies in this channel task.

Let C denote coherent-state preparation. For T>1 one has EXACTLY

    H_T rho=C(law(X+Z_(T-1))),
    Q_(H_T rho)=law(X+Z_T).                               S8

The matching Gaussian satisfies the same identities with X replaced by
its matching Gaussian. Preparation and heterodyne measurement are normal
channels, so DPI in the two directions yields

    D(p_T||gamma_T)
       <=D(H_T rho||H_T gamma)
       <=D(p_(T-1)||gamma_(T-1)).                         S9

The symbol gamma_t on the outer terms denotes the classical Gaussian from
Section2; the middle gamma is the matching QUANTUM Gaussian. Their
covariances are consistent: coherent preparation adds I/2, while a Husimi
measurement adds another I/2. Both exterior quantities have the SAME
leading coefficient in S6; shifting t by one changes only O(T^-M-1).
This proves S1 without a noncommutative entropy Taylor expansion.

The first unmatched order is finite unless rho is Gaussian. The Husimi
law has an exponential quadratic moment, so its characteristic function
is analytic near zero, with all its derivatives given by moments. If every
moment matched the Gaussian, analyticity followed by uniqueness of the
Fourier transform would give an identical Husimi law and hence identical
quantum Weyl characteristic. Conversely a Gaussian rho has Gaussian
Husimi law. Thus a non-Gaussian state has a finite M>=3. The matching
Gaussian's Husimi covariance is the same Sigma, including the vacuum
offset, so moments of order1 and2 always match by construction.

## 4. The ACTUAL amplifier output has the same sandwich structure

Independently draw X_A,X_B from the two input Husimi laws and put

    Y=sqrt(G)X_A+sqrt(lambda)J X_B,
    Sigma_Y=G Sigma_A+lambda J Sigma_B J.

Y has an exponential quadratic moment at a sufficiently small parameter.
For T>G/s the physical retained output for the heated product inputs is

    rho_C(T)=C(law(Y+Z_(sT-G))).                          S10

Its Weyl characteristic verifies S10 exactly: the two Husimi factors
contribute exp(-s|z|^2/2), coherent preparation exp(-|z|^2/2), and the
intermediate Gaussian exp[-(sT-G)|z|^2]. Since G=(s+1)/2, their product
is precisely the added output heat exp(-sT|z|^2). This uses the ACTUAL
independence of the two input groups and the creation-port reflection J.

Heterodyne measurement adds one classical noise unit to S10. The output
quantum relative entropy to the matching Gaussian is consequently between
the two classical quantities at times sT-G and sT-G+1. S6 applies to Y.
No positivity or exponential-energy propagation claim about an inverse
heat representation of the unheated output is needed.

Let m be the smallest first unmatched moment order of the two input
Husimi laws; use order infinity for a Gaussian input. For an input whose
first unmatched order is larger than m, set its degree-m difference tensor
to zero. Put A=Delta_(A,m) and B=J^(tensor m)Delta_(B,m). Independence and
moment matching through degree m-1 give the EXACT tensor relation

    Delta_(Y,m)=G^(m/2) A+lambda^(m/2) B.                 S11

Indeed all mixed terms in the expansion of Y^(tensor m) have component
degrees below m and agree with the corresponding independent Gaussians;
only the two pure degree-m terms can differ. Equations S6,S9,S10 therefore
give, with C_i=||Delta_i||^2/(2m!),

    d_A(T)=C_A T^-m+O(T^-m-1),
    d_B(T)=C_B T^-m+O(T^-m-1),
    d_C(T)=||G^(m/2) A+lambda^(m/2)B||^2
                  /(2m!s^m T^m)+O(T^-m-1).             S12

Here d_i are quantum relative entropies to matching Gaussian states.
The conclusion remains valid when Delta_(Y,m)=0: its leading coefficient
is then zero, and the proven remainder is still of the displayed order.

## 5. Strict positive EPnI coefficient for isotropic covariances

Under S2 the three matching quantum Gaussians are exactly thermal,
with means a_T=a+T, b_T=b+T and c_T=G a_T+lambda(b_T+1).
Thus the exact energy/entropy identities are S_i=ng(mean_i)-d_i.

Let theta=G/s, phi=lambda/s. Both are positive and theta+phi=1.
The entropy-target derivatives satisfy eta_A=theta+O(T^-1),
eta_B=phi+O(T^-1). Its Hessian is uniformly bounded on the relevant
high-temperature entropy rectangle. The same elementary Taylor argument
as in the earlier local/heat notes shows that the actual entropy-form
EPnI gap equals

    eta_A d_A+eta_B d_B-d_C+O((d_A+d_B)^2/n)
       =kappa T^-m+O(T^-m-1),

    kappa=[theta||A||^2+phi||B||^2
          -||theta^(m/2)A+phi^(m/2)B||^2]/(2m!).         S13

The curvature term is O(T^-2m) and is absorbed since m>=3. At least one
of A,B is nonzero. Weighted tensor Cauchy-Schwarz gives

    ||theta^(m/2)A+phi^(m/2)B||^2
      <=[theta^(m-1)+phi^(m-1)]
            [theta||A||^2+phi||B||^2].

Because m>=3, theta^(m-1)+phi^(m-1)<1. Therefore

    kappa>= [1-theta^(m-1)-phi^(m-1)]
             [theta||A||^2+phi||B||^2]/(2m!)>0.          S14

The exact eventual inequality follows for EVERY sufficiently large
finite T, not merely on a selected subsequence. If both inputs are
Gaussian, S2 makes both thermal and the original channel formula gives
equality. Vacuum inputs are included in that Gaussian case; all heated
references are faithful once T>1.

## 6. Boundaries and fresh falsification targets

The main new targets for criticism are the k=4 Gaussian determinant and
exponent, signed-measure absolute domination, separate-variable polynomial
degree cancellation, the one-unit quantum sandwich, and the creation-port
noise offset sT-G. None is replaced by numerical agreement.

The exact classical asymptotic and generic Gaussian/quantum heat tools
have a substantial prior literature. Priority of these particular quantum
coefficients and eventual two-port conclusion is UNKNOWN. No generic
Edgeworth, coherent-state or data-processing novelty is asserted.

The construction fixes source,n,G BEFORE heat grows. Finite mean energy
alone does not supply S7's exponential moment. No approximation/density
argument removes that premise, no threshold is uniform in source/n, and
no T->0 reversal is licensed. The separate Gaussian common-heat hump
explicitly refutes a tempting equal-heat backward monotonicity.

The ACTUAL added energy is nT per input group. For T>=1 the native heat is
entanglement breaking, so initially permitted internal entanglement is
not surviving in the eventual inputs. Husimi variables are analytic
representations, not free measured records. Ancilla, pump, preparation,
phase, calibration, precision, entropy acquisition and disposal/reset
costs remain unimplemented; no physical or practical advantage is claimed.

This note gives no general UNHEATED EPnI, heavy-tail theorem, arbitrary
covariance-pair completion or N557 prerequisite closure. Its exact new
scope requires independent proof criticism before promotion.
