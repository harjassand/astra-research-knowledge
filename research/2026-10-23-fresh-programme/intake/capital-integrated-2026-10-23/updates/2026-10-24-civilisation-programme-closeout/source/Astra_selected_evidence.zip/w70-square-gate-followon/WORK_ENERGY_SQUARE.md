# A second physical construction: reset-pair piezoelectric work as the square

This route was developed independently after the low-power electronic comparison exposed the strain bridge as a dominant common cost. It is a concrete alternative to demanding a new strain-squared material coefficient. It is not established as a new or superior invention.

## The energy identity supplies the missing nonlinearity

For a linear piezoelectric element, write its electrical port as

`Q=C_p V+alpha epsilon`.

Reset it to `epsilon=0,V=0`, hold the electrodes open, and apply a teaching strain `epsilon` without losing charge. Then `V=-alpha epsilon/C_p`. Fast synchronized extraction at fixed strain into a buffer releases

`W_square=(1/2) C_p V^2=alpha^2 epsilon^2/(2 C_p)`.

This performs squaring by physical work stored in a capacitor. Ordinary rectified charge gives approximately `|epsilon|` and a threshold, so directly connecting a piezo rectifier to a plating cell does not give this identity. The energy must be extracted and accounted, rather than merely counting piezo charge. A synchronized converter into a controlled-voltage reservoir can in principle produce slow cell dose proportional to the extracted energy. Alternatively its energy bucket can be compared with a reference and drive a sign-controlled conventional current source.

An electrical background offset gives `W∝(alpha epsilon+B)^2`. Symmetric physical `+f` and `-f` teaching loads plus matched zero cycles cancel the cross term and subtract the constant, in the same ideal algebra as the electronic construction. This is an additional mechanical load/reset requirement, not a free electronic sign flip. The force reversal has the same squared-strain objective only in the admitted linear, reversible regime.

## Mechanical back-action must be included

A bonded piezo is a spring as well as a sensor. Its open-circuit and short-circuit stiffness differ. At fixed applied force, discharging it can change strain; the assumed fixed-strain extraction is not automatically true. One may use a teaching fixture that holds displacement briefly during extraction, or extract faster than the relevant mechanical response and acquire a finite dynamic error. The piezo contribution to the sensed-state stiffness belongs in `Kcore`; the fixture's holds, unloading, relaxation and force-reversal cycles consume time and mechanical work. Harvested energy is drawn from that work. It is not free energy in the material update.

Charge leakage between reset and extraction, nonlinear capacitance, coupling drift with temperature/adhesion and source impedance all perturb the square. Stored energy can be inferred only if the relevant capacitance and voltage range are qualified. A low quiescent interface does not establish constant conversion efficiency versus input amplitude and buffer state.

## Existing primary hardware makes extraction attainable

[Lefeuvre et al.'s original 2006 random-excitation paper](https://arxiv.org/abs/0711.3309) implements synchronized charge extraction as a power-conditioning operation. [Morel et al.'s measured integrated SECE circuit](https://arxiv.org/abs/1810.06421) reports 30 nA sleeping current at 1.5 V, a measured 91% peak electrical efficiency for its specified shocks/storage state, and decreasing efficiency at smaller signals or long intervals. It has an actual cold-start sequence and an energy-monitoring output, rather than an ideal perpetual comparator. The raw paper was acquired. Its demonstrated generator/shock conditions do not certify this quasistatic axial-strain square transfer, and its custom ASIC is not an off-the-shelf fabrication-free component.

The [PI DuraAct manufacturer's historical brochure](https://www.pi-usa.us/fileadmin/user_upload/pi_us/files/catalogs/PI_Catalog_DuraAct_Piezo_Patch_Transducer_Piezo_Composite_C1_2007.pdf), acquired in full, lists an actual P-876.A12 patch with 90 nF nominal capacitance, 3.5 g mass and 61×35×0.5 mm envelope. Those are existing component scales. Its actuator contraction specification does not independently calibrate strain-to-voltage on the proposed grown composite; `alpha` must be acquired.

For an explicitly **hypothetical qualification result** of 40 V at 300 microstrain with 90 nF, one extraction contains 72 microjoule. At one extraction per second and an assumed 50% complete energy-to-cell efficiency, nominal 0.3 V cell operation would supply about 0.01588 mm³ Cu/hour, or about 62.98 hours/mm³ at unit Faradaic efficiency. These numbers are scenario arithmetic in `additional_calculations.json`; 40 V and 50% have NOT been measured here. Return/unload extraction may provide a second event but cannot be double-counted without its mechanical cycle and timing. The patch mass is about 390 times the mass of 1 mm³ Cu, so it belongs in a removable manufacturing fixture if the intended advantage is a light final part.

The 40 V scenario is not automatically compatible with the cited SECE ASIC, which uses 10 V devices. A qualified high-voltage frontend, different transducer geometry or coupling reduction has real fabrication, loss and calibration costs. At an illustrative 8 V instead, the same capacitor stores only 2.88 microjoule, and the same assumed efficiency/rate gives about 1574.6 hours/mm³. Neither voltage scenario is an acquired strain-to-voltage curve. Selecting a larger peak power from one source and low-loss electronics outside their voltage range would not establish a buildable chain.

## Strong incumbent and decisive gate

An ordinary controller is allowed the **same piezoelectric element, same energy-extraction interface and same energy supply**. It may sample the piezo voltage before extraction, square digitally, use a low-duty ADC, and actuate from the same buffer. Thus replacing an always-powered bridge is not by itself a native-computation advantage. In the 72-microjoule illustrative extraction scenario, the earlier roughly 1-microjoule/sample ordinary digital planning cost is already a small fraction of acquired mechanical work; even eliminating it leaves the chemical and fixture work. A measured low-power native energy bucket could still save a reference, divider, data wiring or calibration step, but that benefit has not been acquired.

The ordinary controller may also wake only on the existing harvester's energy-ready signal and retain its state in nonvolatile memory. It is not forced to maintain the earlier example's 1 Hz LPM3 timer or to digitize every mechanical cycle. If the same energy-bucket gate is the best controller for both, the proposed hardware operation has no exclusive advantage.

This path remains useful as a hard alternative square transducer if the bridge version fails. The central assay is not another square fit alone: it measures extracted energy versus independently measured strain over both signs, zero/reset states, rates and buffer states, then checks actual dose and stiffness. A waveform-dependent efficiency that destroys a bounded affine response, or a same-piezo ordinary controller with lower complete cost, kills the corresponding feasibility or advantage claim.
