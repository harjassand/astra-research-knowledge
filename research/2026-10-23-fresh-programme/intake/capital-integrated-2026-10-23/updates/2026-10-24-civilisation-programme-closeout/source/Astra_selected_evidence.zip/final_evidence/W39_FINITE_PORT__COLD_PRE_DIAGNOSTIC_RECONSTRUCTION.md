# Cold finite-port reconstruction before new diagnostics

W39, 24 October 2026. Exact target2e8fe1f52d9c6fb77f78578efc303b0089a73e0937fd56c5d86f765fb2c9706b.
Read only that source and the specified primary manufacturer manual
(retained May2025 PDF, independently hashed/read pages2,47--48). No
producer code/output/report, peer verdict or root derivation read.
The earlier ideal-action/compact-prior verdicts are distinct and unchanged.

1. From KCL i=Lv=(x-v)/r, (I+rL)v=x and M=L(I+rL)^-1.
The common-mode nullspace of L causes no singularity because I+rL is
strictly positive definite. M=(I-(I+rL)^-1)/r. Adding the hub edge
a bb^T to L0 and applying the rank-one inverse identity gives
M1-M0=c uu^T, u=(I+rL0)^-1b, c=a/(1+ra b^Tu)>0, c<=a.
This is the actual command-to-current operator, not L itself.

2. For beta=ra, solving one star's leaf and hub equations yields
hub h=(1+beta)/D, leaf l=beta/D, D=1+beta(d+1).
h+dl=1. Thus u has one positive star column and one negative column,
||u||1=2, ||u||2^2=2(h^2+dl^2), b^Tu=2h. At fixed beta>0,
||u||2^2~2/d and c->a. The formulas include all n observed currents.

3. For ANY adaptive history, the policy issues the SAME next command
function under both hypotheses when evaluated at the SAME history.
It is wrong to compare two independently drawn history/control paths.
Given common history/seed, conditional observations are Gaussians with
the same sigma^2I and difference c u(u^Tx). Chain rule therefore gives
KL(P1||P0)=c^2||u||2^2/(2sigma^2) E1 sum_t(u^Tx_t)^2.
No conditional noise covariance or side-information term is omitted;
the model explicitly fixes independent noise and the seed is common.

4. On EACH realized history, write temporal row vectors s_i. The
pathwise command budget implies
||sum u_i s_i||2^2<=(sum |u_i| ||s_i||2)^2<=B||u||1^2=4B.
Thus KL<=2c^2B||u||2^2/sigma^2, TV<=c sqrt(B||u||2^2)/sigma by
Pinsker. Endpoint worst-case error<=delta needs TV>=1-2delta and gives
exactly the stated B lower. This bound is independent of how large q
is and already uses all readouts. Bounded/adaptive stopping can be
handled by zero commands after stopping; even an almost-sure finite
stopping extension follows by finite transcript limits and monotone
sum. No adaptive control can obtain unpriced independent repetitions
under the fixed total pathwise command budget.

5. A single known-background command x=sqrt(B)sign(u) attains the
4B temporal inequality. Its full Gaussian mean separation is
2c sqrt(B)||u||2, so midpoint testing has equal endpoint risk
Phi[-c sqrt(B)||u||2/sigma]. Hence B=Theta(d) is both necessary and
sufficient for a fixed delta at fixed a,r,sigma in THIS known-background
passive instrument. This is not an exact adaptive minimax error formula.

6. If gamma_d=ar_d d diverges, h<=1/(1+gamma_d)+1/d and l<=1/d,
so ||u||2^2<=4/(1+gamma_d)^2+4/d^2+2/d ->0. Since c<=a, fixed
B,sigma/a cannot keep risk below a fixed delta<1/2. An unbounded
gamma sequence has a divergent subsequence, so a uniform finite-error
family requires gamma bounded. Conversely r_d=O(1/(ad)) keeps h and
c/a bounded below, removing this particular vanishing-information
obstruction. It is a resource scaling within this model, not an
electronics impossibility theorem.

7. With variance sigma0^2/tau_t and time-weighted per-row budget E,
the conditional Gaussian KL gains a factor tau_t. Use temporal vectors
sqrt(tau_t)x_ti; the same argument gives KL<=2c^2E||u||2^2/sigma0^2.
Adaptive times chosen from the prior history have the same conditional
kernel under both hypotheses. This is an explicitly stipulated averaging
law, not measured sensor physics or a justification for free duration.

8. For the separate algebraic current-feedback law x=z+rj, j=i+eta,
one solves v=z+r eta and j=Lz+(I+rL)eta. Its covariance is
sigma_i^2(I+rL)^2. A hub's raw variance is at least
sigma_i^2[1+2rad+r^2a^2(d^2+d)]. Exact mean restoration therefore
does not restore the independent fixed-noise ideal oracle. Commands
can grow with degree; moreover Gaussian same-action feedback commands
are unbounded, so this ideal loop is not automatically an admissible
pathwise-B passive command policy. Its theta-dependent covariance can
carry information; the passive KL theorem must not be transplanted
to the feedback model.

9. For separately supplied voltage loop v=z-xi and independent current
readout error eta, j=Lz-Lxi+eta has covariance sigma_v^2 L^2+sigma_i^2I.
Independent spatial sense errors give hub noise Omega(sigma_v^2 a^2d^2),
so a fixed raw scalar noise level requires sigma_v=O(1/d). Pure common-
mode errors are annihilated by L1=0 and evade this bound. Raw variance
inflation is not by itself a lower bound against every optimal correlated
decoder/controller. Stability, bandwidth, energy and hardware feasibility
remain unproved, as the source explicitly states.

No algebraic blocker found before tests. No product, apparatus, noise law
or feedback architecture is acquired. The manual's two head architectures
support the caution that series burden exists but is not universal.

