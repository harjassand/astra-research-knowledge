# Independent reconstruction of the critical operator lower

Root, 23 October 2026. This independently reconstructs w30's newly proposed
half-edge perturbation. It is an internal analytic review, not historical
priority or practical validation. The setting is the known subdivided K_k
support, free real diagonal, arbitrary signed symmetric coefficients, q real
action columns, and whole-row Euclidean norm at most one. The necessary
inverse inequality is ||D||op <= C ||DX||F for EVERY supported D.

At the critical constant C=sqrt(3/2), I obtain

 k <= 12q^2 + (9/4)q.                                      (1)

Together with the separately proved ordinary star-coordinate upper this
would give q=Theta(sqrt(k)) at the critical operator constant. This note
only proves the lower; it does not import or certify that upper.

Write v_i for the row of hub i and w_ij for the row of the mediator of
edge ij. Fix hub i. Let P_i be the orthogonal projector in R^(k-1) onto
the kernel of a -> sum_j a_j w_ij. Put p_ij=(P_i)_jj. Then
0<=p_ij<=1 and sum_j(1-p_ij)=rank(I-P_i)<=q. For a=P_i e_j,
a_j=p_ij=:p and ||a||^2=p.

Take the actual star matrix with edge coefficients +a or -a, centered at
hub i, and add free diagonal 1/2 at i and mediator s=ij. Its action on
hub i is v_i/2 because sum a_j w_ij=0. The sum of all other row energies is
the star contribution plus the chosen mediator's diagonal interference.
Thus its squared action norm is exactly

 (p+1/4)||v_i||^2 + (1/4)||w_ij||^2
       +/- p <v_i,w_ij>.                                  (2)

Now add the OTHER legal half-edge from mediator ij to hub j, of weight b.
Let rho=<v_i,v_j>, eta=<w_ij,v_j>. The added squared action is

 b^2 (||v_j||^2+||w_ij||^2)
       +2b(+/- p rho+eta/2)
 <=2b^2+2b(+/- p rho+eta/2).                               (3)

For each sign independently choose b=-(+/- p rho+eta/2)/2. Average the
two resulting squared action norms. Whole-row bounds and cancellation of
the sign-linear term yield

 average ||D_+ X||F^2,||D_- X||F^2
 <=p+1/2-(p^2 rho^2)/2-eta^2/8.                            (4)

The selected i,ij principal block stays [[1/2,+/-p],[+/-p,1/2]],
irrespective of b. Compression cannot increase operator norm, so BOTH
matrices obey ||D_+/-||op >=p+1/2. Apply the assumed critical inverse
inequality to both and average; discard the nonpositive eta term:

 (p+1/2)^2 <=(3/2)[p+1/2-p^2 rho^2/2].                    (5)

For p>0 this gives
rho^2 <=(4/3)(p+1/2)(1-p)/p^2.
If p>=1/2, the coefficient (4/3)(p+1/2)/p^2<=16/3.
If p<1/2 (including p=0), use rho^2<=1<=2(1-p). Hence always

 <v_i,v_j>^2 <=(16/3)(1-p_ij).                            (6)

Summing over j gives sum_(j!=i)<v_i,v_j>^2 <=(16/3)q. Let G be
the k by k hub-row Gram matrix. It has rank<=q. A matrix supported on a
single hub diagonal has operator norm1 and action norm||v_i||, so the
critical inverse bound forces ||v_i||^2>=2/3. Therefore

 Tr G >=2k/3,
 Tr G^2 <=k+(16/3)kq,
 (Tr G)^2 <=rank(G) Tr G^2 <=q[k+(16/3)kq].                (7)

Divide by k and rearrange to obtain (1).

All witnesses use the ORIGINAL support, actual global action rows and
arbitrary mediator probes. No local-decoder, equal-mediator, finite-palette,
or random-noise assumption enters. Free diagonal entries are essential to
this proof. This is not the conserved-diagonal/Laplacian problem, and it
does not transfer to it merely because the graphs are the same.

The row-energy bound, the all-D inverse constant and the operator/Frobenius
norm conventions must be retained when comparing with arbitrary-amplitude
noiseless matrix-vector query algorithms. The half-edge construction is
w30's proposed scientific step, with parallel related two-star work by
w62 and w58. Gram-rank and leverage tools are established mathematics.
