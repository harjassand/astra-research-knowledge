# A pure enumerative encoder for the explicit pair source

Worker w67, 23 October 2026. The rational two-qutrit source has an explicitly
known nine-vector eigenbasis. This removes the unknown-eigenbasis reason
for using a universal Schur/mixed-gauge encoder. The following conventional
type-class construction supplies a paid pure isometry and inverse directly.
It changes the representation and removes several dependencies; no generic
type coding or enumerative coding novelty is claimed.

The actual physical channel remains the original recurrent device. It is
not replaced by an iid channel. Only the ANALYTICAL reference input is a
product source. The high-design compression and counted forward-flush/local
inverse decoder remain separate reviewed dependencies.

## 1. Supplied source data is now explicit

Use the directly proved rational pair source from `fixed_k_tradeoff/`:
`x=b/12`, `u=b^2/60`, with probabilities

    p_0=(1-u)/4,
    p_1,...,p_4=(1+u)/16,
    p_5,p_6=(1-x)/8,
    p_7,p_8=(1+x)/8.

Its eigenvectors are, in the same order, `|00>`, the four charged basis
vectors, the two symmetric pair states, and the two antisymmetric pair
states. This is a FIXED constant-dimensional unitary basis change. Each
vector has definite physical total charge 0, 2 or 1. All probabilities
are rational functions of the known rational b, satisfy `1/16<=p_i<=1/4`,
and sum to one. Their Shannon entropy is exactly S(rho), at least
`3+g0`, where `g0=b^2/384`.

No physical copies of rho need be prepared by this encoder. Rho is a
certified reference for the tail comparison; the encoder actually prepares
arbitrary logical superpositions of known product eigenvectors.

## 2. Acquire one fixed type by exact rounding

For m>=1728, set

    n_i=floor(mp_i), i=0,...,7,
    n_8=m-sum_(i=0)^7 n_i, q_i=n_i/m.

The counts are exact polynomial-bit integer arithmetic on the rational p.
Let `delta_i=n_i-mp_i`. The first eight errors lie in `[-1,0]`; the last
lies in `[0,8]`, and

    sum delta_i=0, sum |delta_i|<=16, sum delta_i^2<=72.

Using the scalar relative-entropy/chi-square bound and `ln2>2/3`,

    m D_2(q||p)
       <=(1/ln2) sum_i delta_i^2/(mp_i)
       <=1728/m<=1.                                 (T1)

No approximate eigenvalues, spectral gap or probability table of exponential
size is acquired. There are exactly nine entries.

## 3. The selected type has polynomial weight

Let `f=m!/product_i n_i!` be the type size. Under the distribution q,
the type n is a multinomial mode. To see this directly, compare its
probability with another type n'. After the common powers of m cancel,
each factor for `n'_i=n_i+d` is

    product_(s=1)^d n_i/(n_i+s)<=1,

and each factor for `n'_i=n_i-d` is

    product_(s=0)^(d-1) (n_i-s)/n_i<=1.

Zero-count cases are immediate; all selected counts are positive at our
m anyway. Since there are at most `(m+1)^9` types and their probabilities
sum to one, the q-probability of n is at least `(m+1)^-9`. Changing from
q to p multiplies that probability by `2^[-mD_2(q||p)]`. Thus the
reference-source weight of this particular deterministic type is

    w=f product_i p_i^(n_i)>=1/[2(m+1)^9].           (T2)

This is a guaranteed acquired type, not an assumed rare-sector acceptance.
There is no retry or postselection.

The same mode bound gives `log2 f>=mH(q)-9log2(m+1)`. Moreover

    mH(q)=mH(p)-sum_i delta_i log2 p_i-mD_2(q||p)
           >=mS(rho)-17,

since the log-probability range is at most two, the total positive count
error is at most eight, and (T1) costs at most one. This sharper constant
was independently identified by w66 after my initial conservative bound.
Therefore, with `ell=floor(log2 f)` and `D=2^ell`,

    ell>=mS(rho)-9log2(m+1)-18.                     (T3)

## 4. A literal pure isometry and average domination

Order all nine-symbol strings having counts n lexicographically. Let C
map the computational ranks `0,...,D-1` to the corresponding FIRST D
strings, followed by the fixed local eigenbasis unitary on each block.
This is a known pure isometry from D logical dimensions into 2m qutrits.

Every string in the full type is an eigenvector of `rho^(tensor m)` with
the same eigenvalue `lambda=product_i p_i^(n_i)`. If P_type is its full
projector and P_D the selected first-D projector, then `f/D<2` and

    C(I_D/D)C* = P_D/D
       <=(f/D) P_type/f
       <=4(m+1)^9 rho^(tensor m).                  (T4)

The FULL image has definite total physical charge `sum n_i charge(i)`.
Thus every encoded logical operator commutes with that total charge, and
an arbitrary high-design unitary on its logical input preserves this property.
There is no gauge subsystem or untransmitted message-dependent helper.

It is essential to take D as the largest power of two BELOW f. Choosing
instead a much smaller preset `2^floor(mR)` could introduce an exponential
`f/D` domination loss and destroy the logarithmic tail cutoff. The rank f
is actually computed by the constructor at its paid polynomial cost.

## 5. Polynomial ranking, unranking and inverse

For remaining counts r of total length t and current total number
`F=t!/product_i r_i!`, the number of completions beginning with symbol j is

    F_j=F*r_j/t.

This is an exact integer. Compare the desired rank with the nine cumulative
F_j intervals, select a symbol, subtract the preceding intervals, decrement
its count, and repeat. The inverse ranking operation adds those same
intervals. These procedures take O(m) stages with nine branches, on
O(m)-bit type counts; intermediate factorial arithmetic can use
O(m log m) bits. They do not enumerate the f strings.

Because ranking and unranking are inverse polynomial-time classical
bijections on the legal domain, their reversible versions map
`|rank>|0>` to `|0>|string>` with workspace uncomputed: compute the string,
then erase the old rank using its recomputed rank. Invalid ranks or
non-type strings receive a fixed reversible reject extension. This gives
a polynomial-gate encoder and a known inverse extension, not a black-box
spectral projector. The final local eigenbasis changes and their inverses
cost O(m) fixed-dimensional gates plus the charged synthesis precision.

Classical type-size acquisition costs polynomial in m and the bit length
of b. Its O(m)-bit output is substantial and paid. A short resource-count
calculation that avoids writing f is not itself execution of this constructor.
No corrected high-dimensional Schur compiler or source factory is needed.

## 6. Complete uniform overflow and decoder binding

Let t and C_tail be the rational pair source Lyapunov parameters from the
preceding ledger. Applying (T4) to the actual recurrent bad-depth effect
gives mean-sector logical average overflow at most

    4(m+1)^9(1+C_tail) exp(-tH).

Choose H to make this at most `q_code=2^-s`. The reviewed high-design
theorem then selects a logical subcode of fraction `K/D=2^-s` with
compressed mean-sector effect at most `256q_code`, hence each conserved
sector effect at most `512q_code`. This is uniform over arbitrary logical
references. The code does not evaluate the physical overflow operator.

Now use the already reviewed PURE-ENCODER forward-flush digital decoder.
It retains all emitted body/flush ports, estimates the sector through
counted probes and zeros, supplies a local word vacuum, applies the
digital forward-unitary inverse, then C* and the sampled logical inverse.
There is no mixed-gauge extension to verify in this version. All forward
prefix, probe, reset-padding and terminal-zero calls remain counted.

For dyadic `m=2^J`, an integer sufficient cutoff is

    H=ceil{[s+2+9(J+1)+ceil(log2(1+C_tail))]/t}.      (T5)

Its larger logarithmic source-domination factor changes constants, not
the beta scaling. Formula (T3) supplies the finite rate condition directly.
At `0<beta<=1/32`, a sufficiently large

    m=O(beta^-8 log(1/beta))

still gives actual rate at least `3/2+beta^4/1536` and the same fixed-target
error guarantees. All primitive arithmetic, design generation, finite seed,
encoder and decoder operations are jointly polynomial in 1/beta at that
horizon. Their constants and polynomial degree remain huge. No deterministic
good-seed test or physical calibration is supplied.

Explicitly, for `r_target=3/2+g0/4`, it suffices that

    m g0/2>=9log2(m+1)+18+s+r_target S_padding.

This stronger half-source-excess target uses (T3) directly; it does not
assume a preset parent dimension below the type size.

## 7. Prior art and scope

The generic tool is ordinary enumerative coding. The primary
[Cover 1973 paper](https://isl.stanford.edu/~cover/papers/transIT/0073cove.pdf)
gives lexicographic ranking, inversion and finite-alphabet extension; its
full five pages were retrieved and the relevant propositions read. Quantum
source coding in known eigenbases also predates this work, e.g.
[Schumacher 1995](https://doi.org/10.1103/PhysRevA.51.2738). No theorem from
those papers substitutes an iid channel here; the only transfer is the
explicit average operator domination (T4) for the actual recurrent device.

The possible contribution is a simpler costed interface for this explicit
pair source. Priority remains UNKNOWN. Mathematical validity is internal,
pending independent reconstruction. Practical advantage, real parameter
acquisition and physical validation are NOT_ESTABLISHED/NOT_PERFORMED.
Mission: NOT_ACHIEVED.

## 8. Independent finite arithmetic scope and full-budget examples

`check_type_encoder.py` actually computes moderate full type sizes and
exact source weights at m=1728,4096,8192, obtaining parent widths
ell=5146,12245,24529. It checks (T2), (T4), the conservative entropy-dimension
bound and selected rank/unrank roundtrips using exact rational arithmetic.
It also exhausts all twelve words of a small type and verifies their complete
lexicographic bijection. The run took about 1.93 seconds and 22,888,448 bytes
maximum RSS. These moderate type checks do not claim positive communication
gain at those particular m.

`certify_type_budget.py` computes six entirely rational sufficient COMPLETE
code budgets, with the stronger target `3/2+beta^4/1536` and full-diamond
error at tau_pi at most 0.001 conditional on a successful offline seed.

| beta | Chosen outer m | Binary interval for prescribed ideal-local design length |
|---|---:|---:|
| 1/32 | 2^73 | [2^1006,2^1007) |
| 1/64 | 2^81 | [2^1110,2^1111) |
| 1/128 | 2^89 | [2^1215,2^1216) |
| 1/256 | 2^97 | [2^1319,2^1320) |
| 1/512 | 2^105 | [2^1423,2^1424) |
| 1/2048 | 2^122 | [2^1644,2^1645) |

It uses `ell_lower=floor[m(3+g0)-9(J+1)-18]` and `ell_upper=4m` to
certify all design guards, the exact rate inequality, every forward padding
call and finite seed cost without writing the enormous full type size.
The actual constructor must later compute that size at its explicitly paid
polynomial cost. The certificate itself is not execution of that constructor.
All six count calculations took about 0.027 seconds and 21,757,952 bytes
maximum RSS. Full exact records are in `PURE_TYPE_FINITE_BUDGETS.json`.
No physical system, huge circuit, seed or apparatus calibration was acquired.
