# All three-bit coning gadgets have a rigid deficit formula

Version1,24 October2026. New complete elementary operation obstruction,
fresh independent review PENDING. This strengthens a PARTICULAR coning
boundary; it is not an impossibility theorem for other quadratic operations
or generic Avoid. No additional peer or worker was tasked.

## 1. Exact operation class and formula

Let R0,R1:F2^n->F2^n be permutations, and let u(x) be one nonconstant affine
input bit. Define the old square map P(x)=R_(u(x))(x), with H missing outputs.
The cut-permutation coning family considered here is the ENTIRE class

    P_G'(x,q,t)=(R_q(x),G(u(x),q,t)),                        (1)

where G:F2^3->F2^2 is ANY Boolean two-output gadget. No locality, degree,
invertibility or particular formula for G is assumed. When R_q and G have
the suitable quadratic dependence, (1) is a quadratic n+2 square map; the
obstruction applies even without those restrictions.

For a,b in{0,1}, let

    h_ab=4-#{G(a,0,0),G(a,0,1),G(b,1,0),G(b,1,1)}.

Put A=h00+h11 and B=h01+h10. Then the exact new hole count is

    H_G'=A*(2^(n-1)-H)+B*H.                                (2)

In particular, no gadget coefficient or parameter-specific representation
is supplied for free: the formula follows from the whole four-input fiber
of the already specified operation. It does not solve generic image counting.

## 2. Proof of the selector counts

For an old output y, set x0=R0^-1(y),x1=R1^-1(y),a=u(x0),b=u(x1). The old
P-fiber consists of x0 when a=0 and x1 when b=1, so its size is1-a+b.
Thus the selector pattern10 gives a hole,01 a double fiber,00/11 a singleton.
Because R0,R1 are permutations and u is balanced, their inverse selector
bits each have exactly2^(n-1) zeros and ones over all y. Consequently

    N10=N01=H,
    N00=N11=2^(n-1)-H.                                     (3)

For (1), fixing the first n output bits to y leaves exactly four candidate
inputs: (x0,0,0),(x0,0,1),(x1,1,0),(x1,1,1). Their last two images are
exactly the four words in h_ab. Their hole contribution is therefore h_ab.
Summing with(3) proves(2). This holds at all n, without extrapolating any
finite circuit check.

## 3. Vanishing diagonal cost forces an even deficit multiplier

Suppose A=0. Since h_ab are nonnegative, h00=h11=0. Write

    S_a={G(a,0,0),G(a,0,1)},
    T_a={G(a,1,0),G(a,1,1)}.

The two zero costs force every S_a,T_a to have size2 and T_a to be the
complement of S_a in the four-word output alphabet. Hence

    h01=2-|S0 intersect S1|=h10,                            (4)

which can be0,1,or2. Equations(2)/(4) imply

    H_G' in{0,2H,4H}.                                      (5)

Moreover the maps t->G(a,q,t) are injective for every a,q, so EVERY new
fiber has size at most two: at most one candidate per q can hit a word.
This simplicity follows from A=0, rather than being imported as a premise
on the generalized gadget.

## 4. A numerical near-square threshold forces A=0

Set L=2^ceil(n/2), so after adding two input/output bits L'=2L. Suppose
H<=cL and a proposed continuation keeps H_G'<=C*L' for given constants
c,C. If A>=1, (2) gives

    H_G'>=2^(n-1)-H>=2^(n-1)-cL.

Therefore whenever

    2^(floor(n/2)-1) > c+2C,                               (6)

the latter lower bound exceeds C*L', contradicting the proposed scale.
Thus a scale-preserving continuation in this entire three-bit gadget family
must have A=0 at the explicit threshold(6), and then obeys(5) and remains
simple. A gadget with positive diagonal defect introduces order2^n holes,
rather than order2^(n/2) holes.

In particular the sought constant-slack inflation

    H=L+t -> H'=L'+t=2L+t, t>0,

cannot arise at large n: with A=0 the nonzero choices are2L+2t and4L+4t,
and the zero choice is a permutation. Nor can H'=2H-1 arise, since every
nonzero small-scale count is an even multiplier of H. Replacing the usual
gadget(q+t*u,t) by a clever arbitrary G on the SAME three available bits
does not change this obstruction.

The conclusion does not restrict operations which depend on more old input
bits, use different cut maps, alter the first n output blocks, add a larger
selector, or change the dimension increment. Those are actual remaining
operation obligations. A hidden stronger selector is not being treated as
free control.

## 5. Exact finite gadget universe and scope

The companion control exhausts all4^8=65,536 two-output Boolean truth tables
on three input bits, including all16,384 pairs of quadratic scalar tables.
It computes every h_ab and checks the formula's A=0 conclusion. Such a
finite universe is a complete test of THIS fixed gadget parameter, while
the all-size conclusion rests on the independently proved selector-count
identity and set-complementation argument above. It is not a finite
certificate promoted into general complexity progress.

The usual coning operation in CONING_QUADRATIC_PHASE_INDUCTION.md is one
instance of (1), with H'=2H. The earlier INFLATION_OBSTRUCTIONS.md correctly
showed maxfiber<=2 for the original two-cut setup. This addendum allows G
to introduce up to four preimages in general, then proves that any gadget
which stays at the desired small-deficit scale is forced BACK to maxfiber2
and the rigid multiplier set(5). Historical priority remains UNKNOWN.
