# Cold full review: actual heated smooth-log-envelope entropy bridge

W39,24 October2026. Exact targets:

- Main source `cbd968c585a332e49547f9a74b3b1e014ce2b3d36f695dfb7c46c8b327646399`.
- Mandatory growing-shift/Hessian detail
  `2c08cb95c0655d623563bf7c21c32fd50897fb3f2130e9ba4ee1c7454e1c4870`.
- Fixed-shift clarification
  `a4bf33438a397e21d7858e24a120488cd0bd5fa31a4acb84b4f45543c5a8af5a`.

**Verdict: no blocking defect found in the exact supplied-envelope,
actual-heated, independent one-mode thermal-mixture theorem, with the
mandatory detail.** This is a new cold full-proof reconstruction, not
an inherited verdict from the earlier power-log subclass. I read the
target, mandatory/fixed-shift details, underlying producer proof and
resource/acquisition prerequisites. I did not read/import/run producer
diagnostics, W49's narrower review, another verdict or root's preferred
derivation. The pre-diagnostic reconstruction is frozen separately;
`INDEPENDENT_RECONSTRUCTION.md` contains the complete argument.

For the stated C2 positive nonincreasing integrable envelope ell, with
its explicit derivative bounds and merely measurable density error
O(ell(x)/x^2), define M(x)=integral_x^infinity ell. I reconstruct the
ACTUAL normal quantum defect, with all logs natural:

    D(H_T rho_R||theta_(T+ER))
       =[M(ln T)-ell(ln T)(ln ln T+gamma_E)]/T
                                      +o(ell(ln T)/T).

The smaller error scale is essential because the larger M/T terms cancel
between the two ports and amplifier output. The proof retains it through:

- A local quadratic estimate only up to the moving radius T Y, with
  Y=ln T-ln ell(ln T)+2ln ln T. Its polynomial denominator factor and
  the omitted full mean tail are retained. No global chi-squared norm
  or higher moment is assumed.
- Three temperature ranges for direct REMOTE heat removal. The medium
  cutoff T/(ln T)^2 needs a negative growing shift, also controlled
  directly by the derivative hypotheses. The positive growing
  x-ln T=ln ln T+o(1) shift has the mandatory Taylor error
  O(ell(ln T)(ln ln T)^2/ln T)=o(ell(ln T)).
- The unheated Mellin correction
  ell(v)-(1-gamma_E)ell'(v)+O(ell(v)/v^2), including all remote first
  moment and logarithmic entropy integrals. Merely measurable errors
  are bounded without differentiation. Their integrated contribution
  is smaller than ell/T.
- A genuine quantum squeeze. Radial coherent preparation is the Poisson
  channel h_t->p_n; heterodyne radius is the Gamma(n+1,1) channel
  p_n->h_(t+1). The state's von Neumann entropy is the actual photon-law
  entropy, not the radial entropy. Both references transform the same
  way, and the one-unit change in the main term is O(M/T^2)=o(ell/T).

Independent sum closure and the fixed added amplifier temperature preserve
the required log-squared error. The proof uses smoothness only for the
principal envelope; it does NOT assert an O(1/r) shift modulus for a
rough error. The actual output is the unflagged thermal mixture with
temperature W=(G-1)+G R_A+(G-1)R_B at heat (2G-1)T. The primary
[amplifier Bogoliubov relation](https://arxiv.org/pdf/1402.0404)
agrees with that creation-port constant.

The mandatory bounded Hessian and exact thermal baseline then justify
the entropy-target Taylor formula. For theta=G/(2G-1),phi=(G-1)/(2G-1),
all M, ln ln T and Euler terms cancel COMPONENTWISE. The ACTUAL gap is

    [-theta ell_A(ln T)ln theta-phi ell_B(ln T)ln phi]/T
                        +o((ell_A(ln T)+ell_B(ln T))/T).

This is strictly positive eventually for each fixed source pair and
fixed G>1, without comparable envelopes or a convergent ratio. It does
not require a common logarithmic power. The near-critical densities
1/[r^2ln r(lnln r)^q], q>1, are admissible with exact mean1/(q-1), and
every source in this class has infinite photon moments above one and
infinite thermal chi-squared at EVERY finite heat. Those facts are
compatible with the finite relative-entropy proof.

New standalone controls pass150 exact Poisson coefficients,150 exact
Gamma coefficients and108 exact amplifier temperature identities.
Separate60-digit numerical controls cover36 Mellin cases,45 growing/
negative shifts,3 discontinuous-error cases,60 two-source cancellations
and12 actual output-density convolutions. The pairs include differing
critical indices/powers and an admissible envelope ratio with subsequences
tending to0 and infinity. The largest normalized principal cancellation
error at ln T=10^6 was8.89e-6.

Twelve additional ACTUAL photon-entropy calculations, through photon
cutoff8192 plus analytic entropy-tail formulas, lie within the separately
evaluated classical t+1/t squeeze. For example at T=64,q=2 the quantum
defect is numerically bracketed by .0078790410 and .0078790498, between
classical .0078135119 and .0079453077. Quadrature-order refinement is
<=1.96e-14. These are floating/arbitrary-precision diagnostic calculations,
NOT interval-certified proofs, measured quantum data, a finite actual
two-port gap certificate or an acquired useful threshold.

The source-first and acquisition boundaries also reconstruct. An
epsilon-scaled critical tail atop a fixed nonthermal finite core has
common bounded energy, common derivative constant and common tail start,
yet no uniform relative-asymptotic threshold as epsilon tends to zero.
Finite-copy trace distance bounds likewise prevent a fixed experiment
from uniformly certifying all positive tiny tail coefficients. This
does not exhibit a negative EPnI gap or rule out a different uniform
EPnI proof. Precise tail, mean and independence information remain
supplied mathematical premises.

The theorem changes the physical inputs: real H_T adds T photons to
EACH port, and H_T is entanglement breaking for T>=1. These sources were
already classical unflagged thermal mixtures. Heat/pump/preparation/
precision/entropy-measurement/reset costs and a useful threshold are
unacquired. No free temperature record is supplied. Arbitrary irregular
finite-energy states, unbounded atomic tails and the original unheated
all-input amplifier EPnI are NOT proved. Generic Mellin, convolution,
data-processing, heat and scalar entropy tools are established prior;
exact class-specific priority and best matched prior remain UNKNOWN.

All earlier compact-prior2a19, finite-porta91, quantum-code and reviewed
source bytes are preserved. Physical validation NOT_PERFORMED; practical
advantage UNKNOWN; general unheated EPnI/mission NOT_ACHIEVED. Per the
final drain instruction, this worker freezes its continuation/manifest
and returns idle after this review; no new branch is opened.

