# Acquiring a short gain interval: statistics, disturbance and information flow

23 October2026. New component analysis; fresh review pending. Root explicitly
assigned this theoretical acquisition check. No equipment operation,
physical preparation, detector measurement, external message or purchase
is authorized or performed. Only local proof/calculation is acquired.
The old supplied-band/known-parameter code rows remain unchanged.

The conclusion has two distinct parts. Ordinary receiver-side calibration
can reach the inverse-polynomial source precision with a charged number
of forward calls independent of the later message horizon, conditional on
the exact family and controlled preparation/readout promises. It does NOT
install the resulting source parameter at the sender in the unassisted
forward-only code. That is an exact no-signalling obstruction, not a
statistical inefficiency.

## 1. The intended communication and access contract

The pinned Cycle10 source states an unassisted isometric encoder and
deterministic decoder, one evolving infinite bath, no bath control,
fresh bath, preshared entanglement, postselection or backward quantum
wire. The present compiler contract also supplies no runtime backward
classical calibration message. Alice controls inputs and private local
work; Bob receives output ports. Public message-independent code programs
can be preinstalled from the known mathematical model. A quantum table
generated from that KNOWN model is not a measurement of its unknown
physical gain. If actual output observations are used to choose a new
source reference, their transport and the permitted access pattern must
be specified separately.

The exact device is V_theta=cos(theta)U+i sin(theta)I, U²=I,
b=sin²theta. A numerical source promise uses a known compact coarse
location 0<b_low<=b<=b_high<=1/16384 when sizing a finite calibration
budget. Without a positive lower location, an instance-wise adaptive
search is another obligation; no finite uniform relative-precision
budget at b=0 is asserted.

## 2. Exact receiver-visible trials and a predetermined reset schedule

Start with the bath WORD vacuum, retaining any seed state and its
static-sector/reference correlations. A charged input|1> followed by
computational-basis output measurement gives

    output1: probability b, word vacuum;
    output0: probability1-b, word1.

Both probabilities are independent of the seed sector. At word1, a zero
input either pops with probability1-b and output1, or stays with
probability b and output0. Before the first pop the outputs distinguish
those branches, so the reset duration is geometric. No classical I/U
mixture is being substituted for an unmeasured coherent data block.

The often-stated instruction 'send zeros until a pop is observed, then
send the next probe' needs receiver-to-sender feedback. It is not legal
as an adaptive sender strategy under the forward-only contract.

A legal fixed schedule instead uses n predetermined cycles, each of
one charged input and r zero inputs. Bob measures the appropriate ports
and records whether the word returned within that cycle. Extra zeros
after a return leave the word vacuum. Compare this process with a
hypothetical reset-completed reference experiment, using the same
Bernoulli charged trials and geometric reset randomness. Before the first
failed capped reset the probe histories agree exactly, and

    Pr(any capped reset fails)<=n b_high^r.          (C1)

Thus the classical probe record is within total variation n b_high^r of
n independent Bernoulli(b) trials. It is NOT exactly iid conditioned on
all capped resets succeeding; that conditioning can bias the record.
The coupling/error bound, rather than that false conditional-iid claim,
is sufficient. Worst-case physical calls are n(1+r), not the adaptive
mean2n. Bob can flag failure, but that flag is not sent back for free.

At vacuum, a zero input acts on the seed as cos(theta)R+i sin(theta)I.
It can change relative static-sector phases, and the number of extra
vacuum zeros depends on the measured record. This disturbance is retained.
It does not change the word or mix R sectors. The following data code
must work for the resulting arbitrary seed state, including its record/
reference correlations. The previously reviewed two-sector receiver has
precisely that scope; it does not assume the seed was reset or measured.
The message is prepared independently after calibration. No entanglement
with a logical message is discarded in this reset experiment.

## 3. A finite angular confidence interval at the receiver

For ideal Bernoulli trials let p_hat be the empirical mean and
theta_hat=arcsin sqrt(p_hat). For a candidate tail endpoint p,
Chernoff's binomial likelihood bound is

    Pr_b(p_hat>=p)<=exp[-n D(p||b)] for p>b,

with the analogous lower-tail statement. Jensen's inequality gives

    D(p||b)>=-2ln[sqrt(pb)+sqrt((1-p)(1-b))]
             =-2ln cos(theta(p)-theta(b)).

Since tan x>=x for x>=0, -ln cos x>=x²/2. Therefore for0<w<pi/2,

    Pr(|theta_hat-theta|>=w)<=2exp(-n w²).          (C2)

Endpoints outside[0,pi/2] have zero probability, so they cause no failure
of the statement. No asymptotic Fisher-information approximation is used.
A sufficient count is n>=w^-2 ln(2/eta_stat). Finite interval arithmetic
for theta_hat is charged separately and uses a smaller part of w.

For a source that needs interval radius Theta(Kappa/k_max²), choose a
statistical radius w that is a fixed small fraction of that value and
round a rational b_ref/angle interval inside the remaining margin. Here
k_max is a known upper bound on the reference k throughout the supplied
coarse location. Then

    n=O(k_max^4/Kappa² * ln(1/eta_stat)).           (C3)

This is independent of the later communication horizon T. The earlier
T² calibration obstruction concerned a different policy: approximating
a whole T-call digital inverse by the worst-case parameter telescope.
The common Fourier receiver does not demand that precision, so that
old policy is not a lower bound on C3 or on universal decoding.

The exact Bernoulli affinity cos(theta-phi) also gives a two-point lower
bound Omega(w^-2) for THIS independent-trial calibration family at fixed
confidence. Thus variance-aware angular estimation is the equally
informed ordinary statistical baseline; the cruder Hoeffding-in-b
conversion that costs k^5 is not used as an artificially weak comparator.
No universal lower bound on arbitrary coherent device metrology is made.

## 4. Initializer, native precision and reuse costs

An arbitrary normal initializer is not known to be vacuum. The original
zero prefix gives a full-channel error term of the form
4sqrt[q_A+nu_prefix]. To make the calibration record/joint-state bias
small, choose a supplied A at a tolerance polynomially smaller than the
desired confidence, and pay all initial zero calls. There is no uniform
finite A for all normal states. Geometric tails give explicit logarithmic
A; a general supplied modulus is priced as an explicit input. Pointwise
normal-state convergence remains distinct from a finite calibration bound.

Choose r so n b_high^r<=eta_reset. For b_high<=1/16384 it suffices that
14r>=ceil log2(n/eta_reset). The complete scheduled cost is

    N_cal=n_prefix+n(1+r).                         (C4)

Native preparation/readout/simulation defects require an actual control
promise. A safe sufficient contract gives a uniform full instrument error
epsilon_inst for every scheduled local preparation/measurement step,
including its conditional memory action. A hybrid bounds the entire
calibration record AND retained bath error by N_steps epsilon_inst.
Take epsilon_inst<=eta_native/(C N_steps), with the convention-dependent
fixed norm factor C explicit. Synthesis/measurement/reset working bits
are O(log(N_steps/eta_native)) in an ideal fault-tolerant gate/instrument
model, and all calls and descriptions are paid. An unknown fixed detector
bias does not average away; a fixed unbounded native error floor is NOT
covered by this sufficient contract. Hardware attainment of that promise
has not been measured or authorized.

One may instead use a separately calibrated bound on Bernoulli bias and
propagate it through theta(b), exploiting the supplied b_low. That can
reduce precision demands but still needs an acquired error bound. The
full-instrument telescope above is a conservative stable-native route,
and handles the word-return error as well as the scalar sampling bias.
It depends on N_cal, not the later message horizon. Reusing the estimate
requires the physical parameter and its instrument guarantees to remain
stable over the full intended use. Time-varying gain or nonparametric
device perturbations are outside this one-parameter calibration result.

On the no-failure reference branches the word is exactly vacuum. Record-
conditioned seed phases/states can be arbitrary within the static sectors;
the code must retain that uniformity. Prefix/native/reset comparison
errors are carried into the later full-channel budget. A high-confidence
estimate is not a free bath reset, and a classical statistical guarantee
alone is not a statement about the final quantum bath state.

## 5. Exact sender-side information-flow obstruction

Suppose the only unknown-b operations occur after registers leave Alice
and no output, feedback, bath subsystem or b-dependent side information
returns. Initially her local state and public program are independent of
b. For every trace-preserving remote map Lambda_b and joint state X_AR,

    Tr_R[(id_A tensor Lambda_b)(X_AR)]=Tr_R X_AR.     (C5)

Proof: pair either side with any Alice observable O_A and use
Lambda_b^*(I)=I. This is an operator identity, including arbitrary
entanglement and measurements represented by their full instruments.

Apply C5 after each sent probe. Alice's retained quantum state and every
local outcome transcript have the SAME distribution for all b. Local
adaptive choices and entangled future probes do not change this induction.
Remote bath memory and Bob's coherent measurements are contained in the
trace-preserving remote process. Conditioning on Bob's uncommunicated
outcome is not an operation available to Alice.

Consequently Alice cannot learn which one of two disjoint short intervals
contains b with success>1/2 for both, nor install a reference-specific
source from receiver data by any number of forward-only probes. This
obstruction is about the LOCATION of information, not shot noise or
computational complexity. It does not forbid an encoder that works
without estimating b, and does not lower-bound all universal codes.

A prior public narrow interval is legitimate supplied information for
the common code. A predeployment experimenter who has both input and
output access could run C1--C4 and then distribute its classical program,
but that is extra access/communication and must be stated and paid.
A backward classical calibration message would also resolve this
particular information-flow gap while changing the unassisted contract.
Its mere O(log k) bit length does not make it authorized or free.
Alice-to-Bob transmission of a program cannot carry Bob's unknown
estimate back to Alice. Public randomness independent of b cannot do so.

## 6. Present outcome

The narrow-band finite compiler remains conditional on a supplied public
location. Receiver-side charged statistical acquisition is polynomial in
k and independent of T under explicit initializer/native promises.
Actual source-parameter acquisition at the sender is NOT supplied by
the intended forward-only protocol. The exact no-signalling obstruction
explains that gap. No physical operation, parameter estimate or external
program distribution was performed. Proof status pending fresh review;
priority UNKNOWN; practical advantage NOT_ESTABLISHED; mission
NOT_ACHIEVED.
