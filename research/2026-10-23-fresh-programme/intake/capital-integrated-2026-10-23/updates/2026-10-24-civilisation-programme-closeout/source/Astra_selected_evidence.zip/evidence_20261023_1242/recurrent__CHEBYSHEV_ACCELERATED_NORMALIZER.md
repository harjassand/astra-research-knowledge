# Elementary Chebyshev acceleration of the rejected-coin inverse series

W39, 23 October 2026. New additive compiler candidate, separated from every
frozen earlier source/code review and operation count. This is standard
Chebyshev quantum fast-forwarding applied to the acquired instrument Gram;
it does not claim a new generic matrix algorithm. The derivation below
requires no QSP phase-factorization routine and no fractional walk oracle.

## 1. Acquired reflection walk, including its full right domain

Use the same pattern-copied accepted instrument B_rect from
RECTANGULAR_CLIPPED_NORMALIZER.md:

    B_rect=Pi_accept U_B Pi_R,
    B_rect*B_rect=D_tilde/M,
    (3/4)I<=D_tilde<=M I.

Pi_R requires the NEW instrument helpers zero, leaving the physical input
unrestricted. U_B copies its input charge pattern before physical phase
estimation and the coin. Pi_accept tests the coin; no output pattern is
uncopied. These are acquired local finite circuits and simple reflections.
Put

    A=I-D_tilde/M,       Y=2A-I=I-2D_tilde/M,
    R0=2Pi_R-I,
    Rrej=U_B*(I-2Pi_accept)U_B,
    W=Rrej R0.                                        (C1)

Both R0,Rrej are exact ideal reflections, and

    Pi_R W^j Pi_R=T_j(Y), j>=0.                       (C2)

This is the elementary two-reflection principal-angle identity. In a
right singular vector with squared accepted amplitude lambda=D_tilde/M,
Rrej has right block1-2lambda=Y, and the two-dimensional walk is a rotation
with cosine Y. Repeated walks give cos(j arccos Y)=T_j(Y). The domain is
the FULL physical input, and Y is a Hermitian contraction. No Markov-chain
embedding, source eigenbasis, physical bath or unacquired square root is
assumed. Each W or W* uses two U_B/U_B* calls and explicit helper tests.

The pattern, phase and helper registers here are fresh relative to the
ordinary source instrument used below. Its previously retained source
phase/purification registers are not part of Pi_R.

## 2. Positive Chebyshev expansion and a finite binomial tail

For l>=0 write c_l=binom(2l,l)/4^l. The exact scalar identity is

    ((1+y)/2)^l=sum_(j=0)^l a_(l,j) T_j(y),
    a_(l,0)=binom(2l,l)/4^l,
    a_(l,j)=2 binom(2l,l-j)/4^l, 1<=j<=l.             (C3)

All a_(l,j)>=0 and sum_j a_(l,j)=1. To verify (C3), set y=cos(theta),
expand cos^(2l)(theta/2) using exponentials and pair conjugate frequencies.
Thus it is an all-y polynomial identity, including both endpoints.

The coefficients are exactly the law of |S_(2l)|/2 for a2l-step simple
fair sign walk. For n>=1, Hoeffding's elementary exponential bound gives

    sum_(j>n) a_(l,j)<=2exp(-n^2/l), l>=1.             (C4)

For l<=n the tail is zero. This exponential bound is on a CLASSICAL
coefficient distribution, not a physical bath trajectory. It remains valid
for any operator Y with spectrum[-1,1].

Let

    C_(l,n)(Y)=sum_(j=0)^min(l,n) a_(l,j)T_j(Y).

Since ||T_j(Y)||<=1,

    ||A^l-C_(l,n)(Y)||<=2exp(-n^2/l).                 (C5)

This is the familiar quantum-fast-forwarding mechanism. Apers--Sarlette,
arXiv:1804.02321, develop the same positive-Chebyshev/binomial-tail method
for quantum walks. Here (C1) explicitly supplies its required walk and the
following argument prices its source normalization; no generic novelty is
claimed for (C3)--(C5).

## 3. Accelerate the already proved inverse binomial series

Use the previously reviewed COMPLEMENT_GRAM_TAYLOR_NORMALIZER.md. For a
target full trace error epsilon in(0,1], choose

    tau=epsilon/64,
    h0=ceil(log_2(4M/(3tau))),
    L=ceil(4M h0/3),
    P_L(A)=sum_(l=0)^L c_l A^l,
    r_L=sum_(l=0)^L c_l=(2L+1)c_L<=2sqrt(L+1).

The reviewed relative estimate is

    J_L=P_L/sqrt(M),
    (1-tau)I<=J_L D_tilde^(1/2)<=I.                 (C6)

No tiny eigenvalue spacing is needed; the displayed lower D bound suffices.

Now choose the INTEGER parameters

    h1=ceil(log_2(1024(L+1)/epsilon)),
    n=min{L,ceil(sqrt(L h1))}.                       (C7)

The square-root ceiling can be computed by integer square root and a
squared comparison. Define the NEW polynomial and coefficient sum

    P_acc(Y)=sum_(l=0)^L c_l C_(l,n)(Y)
            =sum_(j=0)^n b_j T_j(Y),
    b_j=sum_(l=j)^L c_l a_(l,j)>=0,
    r_acc=sum_(j=0)^n b_j,      1<=r_acc<=r_L.         (C8)

If n=L, P_acc=P_L exactly. Otherwise (C4)--(C7) give

    ||P_acc-P_L||<=2 r_L exp(-n^2/L)
                  <=2 r_L 2^(-h1).                  (C9)

Degree n is O(sqrt(M)log(M/epsilon)), while the unaccelerated inverse
series degree L is O(Mlog(M/epsilon)). Retaining the coefficient sum is
essential: it is r_acc<=2sqrt(L+1), not one and not free.

## 4. Literal LCU and its finite classical acquisition

Prepare an index j with squared amplitudes b_j/r_acc, apply controlled W^j,
unprepare the index, and require Pi_R in the output signal. Equation(C2)
then supplies the exact physical block

    P_acc(Y)/r_acc.                                  (C10)

SELECT powers use at most n sequential W calls: at step i apply W iff
j>=i. W is an ordinary unitary, so this requires no halted power failure
label or measurement. All control predicates are reversible and totalized;
the inverse is the stored reverse circuit. The global index preparation
has n+1 amplitudes, a polynomial-size table, not a source-Hilbert-space
table. The good LCU block has norm<=1 because b_j are nonnegative and the
normalization r_acc is paid exactly.

The weights in(C8) are explicitly computable rationals. c_l and a_(l,j)
have dyadic denominators of at most O(l) bits; all products/sums can use a
common denominator16^L. A direct O(Ln) rational calculation therefore has
polynomial bit cost in L,n. All table numerators/denominators have O(L+
log(L+1)) bits. No evaluations of the source density, eigenvectors or
unknown physical parameter are used.

A binary-tree state-preparation circuit for the KNOWN list b_j/r_acc uses
O(n) conditional rotations and reversible index arithmetic. Exact rational
subtree sums and divisions are paid, including small denominators; one
may compute angles classically using O(L+log(n/error)) working bits and
synthesize each rotation to the allocated absolute operator accuracy.
An exponentially small subtree probability does not introduce a new
promise or unbounded query. There is no free quantum RAM. All acquired
coefficient/rotation tables are polynomial in M and log(1/epsilon).

## 5. Same source orientation and complete error/probability bound

Prepare Gamma with its paid known tilt success1/T_max. Apply the ORDINARY
source instrument K, retaining its accepted coin and phase label. Apply
(C10) on the physical half, using the fresh normalizer workspace just
described. The good source operator is

    Gamma P_acc B_tilde P_acc/(M T_max r_acc^2).        (C11)

The ordering is AFTER K. D_tilde and B_tilde need not commute. Actual Gamma
commutes with P_acc and the operators needed by the pinching trace proof;
ambient-algebra centrality is not assumed.

For comparison, replace P_acc by P_L but KEEP the denominator r_acc. By
(C6), its good vector has squared norm

    N_L/(T_max r_acc^2),
    N_L=Tr(Gamma D_tilde J_L^2) in[(1-tau)^2,1].       (C12)

Its normalized density is within4tau=epsilon/16 of the exact normalized
rho_tilde. The vector perturbation from(C9) has relative norm at most

    [2r_L 2^(-h1)]/(1-tau)<=epsilon/192,             (C13)

where r_L<=2(L+1) and1-tau>=3/4 suffice. Normalizing two nonzero vectors
changes their density matrices in trace norm by at most four times their
relative vector difference. Thus the additional accelerated-polynomial
source error is at most epsilon/48. This estimate holds for the complete
accepted purification, including its retained phase and source records.

Equations(C12)--(C13), r_acc<=r_L and r_L^2<=4(L+1) imply the NEW source
good probability is at least1/[16T_max(L+1)]. A conservative known-source
amplifier may use the weaker explicit lower bound1/[32T_max(L+1)]. It
costs O(sqrt(T_max(L+1))log(1/epsilon)) calls to the known preparation and
its inverse. Its failure branch is assigned a fixed legal port state and
driven to full trace error at most epsilon/16. This is a local source
factory, never communication postselection on a message.

Use W30's separately identified M_FREE_SOURCE_STABILITY.md, when desired,
to allocate at most epsilon/6 to the ideal finite phase-instrument model
error by ||B_tilde-B||<=epsilon/16. Charge aggregate native/simulator/coin/
index/amplification synthesis error at most epsilon/16. The sum of all
displayed errors is below epsilon. Final CPTP physical-port legalization,
then exact total-Q pinch, contracts trace error and fixes the ideal target.
No sharper entropy tolerance, analytic variance or scalar calibration is
silently imported.

## 6. Coherent simulator scope and paid costs

Define ideal physical exponentials in K to leave simulator signal helpers
zero. Ideal K,K*, Boolean pattern COPY, R0,Rrej and controlled W powers
all preserve those zero simulator helpers, even for arbitrary phase/coin/
pattern inputs and logical references. All index operations act elsewhere.
The complete ideal-prefix/actual-suffix hybrid therefore uses only the
already proved coherent zero-helper and adjoint Hamiltonian-simulation
guarantees. It does NOT assume global approximation on arbitrary dirty
simulator signal inputs. Native local-gate error itself is full operator
error, and controlled enabling phases are retained exactly as qualified
in CONTROLLED_SIMULATOR_PHASES.md. Each substitution and repeated call is
paid in the aggregate synthesis budget.

The number of K/K* calls is, up to paid logarithms,

    O(n sqrt(T_max(L+1))log(1/epsilon))
       =sqrt(T_max) M times polylog(M/epsilon).        (C14)

With the M-independent model stability, the sufficient physical phase
grid is T_pe=O((M/epsilon)log(M/epsilon)). Every QPE binary simulation time
is included, so the sufficient H-block query class becomes

    sqrt(T_max) M^2/epsilon times logarithmic factors. (C15)

The paid local G_H and native arithmetic/synthesis costs remain. Coefficient
compilation costs polynomial in L,n and L_b and is not suppressed as free;
quantum workspace and complete gate descriptions are polynomial in
k,L_b,log(1/epsilon) since M=O(k) for V4. The reflected walk reuses the same
instrument workspace; controlled powers require only the index/counters,
not n separate instrument buffers. No QSP phases or Haah factorization are
needed in THIS elementary alternative.

The established rectangular QSVT route in RECTANGULAR_CLIPPED_NORMALIZER.md
has the same sufficient H-query class with a different classical compiler
and normalizer scaling. The earlier raw Taylor-powers implementation has
the valid but worse M^(5/2)/epsilon sufficient class after source stability.
No globally optimal query lower bound, practical gate count, executed huge
factory/code, useful physical advantage or historical priority is claimed.
The V4 source rate and exponential multiplicity onset are unchanged.

All earlier frozen V4 resource ledgers remain conservative valid alternatives
and are not rewritten. This new compiler needs a fresh scope-bound review.
Finite coefficient/walk/source diagnostics can falsify access or cost
mistakes, but cannot establish a large native implementation or hardware
accuracy. Mission remains NOT_ACHIEVED.

Primary historical baseline: [Apers--Sarlette, quantum fast-forwarding,
1804.02321](https://arxiv.org/abs/1804.02321), particularly the positive
Chebyshev coefficients and binomial-tail truncation. The source-specific
reflection, normalization, actual input orientation, precision and all-cost
composition are derived explicitly here.
