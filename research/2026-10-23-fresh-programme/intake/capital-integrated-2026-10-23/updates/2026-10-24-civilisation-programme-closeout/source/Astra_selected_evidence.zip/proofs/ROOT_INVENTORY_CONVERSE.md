# An aligned separable mixture closes the leading entropy coefficient

Root construction and proof, 23 October 2026. Built from w18's spaced-block
comparator, with independent reconstructions by w11 and w18 and a fresh
review assigned to w38. Internal mathematical result; historical novelty,
external correctness, practical implementation and mission achievement are
separate. This does not establish an efficient receiver or a physical device.

## Exact source and target

Use the unchanged Cycle11 Ultra source pinned at
e606bfc587c76bdcae8b8fa3ec33e721efa2fbac. Fix finite D,L>=2 and known prior
p on K in {1,...,L}. Set Phi_t=|Phi_t><Phi_t|, nu_t=I_(t^2)/t^2, and

    sigma_k=Phi_D^tensor k tensor nu_D^tensor(L-k),
    rho_p=sum_k p_k sigma_k,
    B=E[K] ln D, H=H(K), C_p=H(K|Y).

Y is only the mathematical product Bell label. The inaccessible duplicated
clock and old memory, normal independent local product apparatus, finite TP
LOCC, deterministic output Bell rank on EVERY branch, and vanishing half
trace error against the COMPLETE ACTUAL residual are unchanged. R(p) is the
reliable Bell-nat rate at fixed D,L,p as number r of iid complete queues
goes to infinity. Only afterwards may L vary. No realized K, Y, offset or
other record is supplied to the receiver.

The source entropy identity, independently reproducible from its Bell law, is

    S(rho_p)=2(L-EK)lnD+H-C_p,
    0<=C_p<=c(D^-2),
    c(q)=-ln(1-q)-q ln(q)/(1-q).

Indeed J, the number of leading zero Bell labels, has J-K a truncated
geometric(q) overshoot. Its mean is <=q/(1-q). Maximum entropy at that
mean and H(K|Y)<=H(J-K) give the displayed finite bound.

## Separable comparison states

For every integer t>=2 define the full-rank isotropic boundary state

    zeta_t=Phi_t/t+(I-Phi_t)/[t(t+1)]=(I+t Phi_t)/[t(t+1)].

It is separable: apply the common U tensor conjugate(U) twirl to a product
|00><00|. Its overlap with Phi_t is 1/t. This is established isotropic-state
machinery, not a new separability primitive. Direct eigenvalues give

    -Tr(Phi_t ln zeta_t)=ln t,
    -Tr(nu_t ln zeta_t)=2ln t+A_t,
    A_t=(1-t^-2)ln(t+1)-ln t,  0<A_t<=1/t.

For the upper bound, expand ln(t+1)=ln t+ln(1+1/t), use
ln(1+1/t)<=1/t, and drop -ln(t)/t^2. For positivity use
ln(1+1/t)>=1/(t+1) and t-1>ln t. Set A_1=0 for empty blocks.

Choose any integer g in {1,...,L}; d=D^g. For offset s in {0,...,g-1},
partition the L elementary pairs into: a first block of length s (omit if
zero), consecutive full blocks of length g, and one final block of length
h_s=(L-s) mod g (omit if zero). On every nonempty length a block use
zeta_(D^a), after the exact local register identification
Phi_D^tensor a=Phi_(D^a), nu_D^tensor a=nu_(D^a). Their tensor product is
tau_s. It is a fixed separable full-rank state on the ORIGINAL registers.

Let q_s=Pr(K mod g=s). Define the fixed separable full-rank comparison

    tau=sum_(s:q_s>0) q_s tau_s.

All choices depend only on the given prior, D,L,g. This is a mathematical
comparison state, never a source preparation, physical operation, donated
entanglement or observed inventory record.

## Alignment and entropy calculation

For component sigma_k choose s=k mod g. Then s<=k, and its pure/noisy
boundary is exactly a boundary of tau_s's blocks. The prefix block is
entirely Bell, the next (k-s)/g full blocks are Bell, every remaining block
is white noise. If h=(L-k) mod g, direct addition of the two cross entropies
above yields the EXACT identity

    -Tr sigma_k ln tau_s
      =(2L-k)lnD+floor((L-k)/g) A_d+A_(D^h).

This includes k<g, k=L, s=0 and empty final remainders. All comparison
states are full rank; no support regularization is needed. Since
tau>=q_s tau_s>0, operator monotonicity of ln gives

    -Tr sigma_k ln tau <= -ln q_s-Tr sigma_k ln tau_s.

Selecting a different comparison term in the ANALYSIS of each k does not
condition any experiment on k. Cross entropy is linear in the actual
mixture rho_p. Averaging -ln q_(K modg) costs exactly H(K mod g), denoted H_g.
Subtract the exact source entropy to get

    D(rho_p||tau) <= U_g := B-H+C_p+H_g+T_g,
    T_g=E[floor((L-K)/g) A_(D^g)+A_(D^((L-K) mod g))].

In particular

    T_g<=L/(gD^g)+1/D,
    U_g<=B-H+c(D^-2)+H_g+L/(gD^g)+1/D.

Uniform weights 1/g give the weaker H_g<=ln g bound and need no prior
computation. Prior zeros cause no issue because only positive-probability
components appear. The state tau itself need not be efficiently constructed.

## Finite-error converse with the actual output contract

Take ANY admitted receiver on r complete queues, output Bell rank N>=2,
and actual marginal or complete half-trace error epsilon<1/2. Compare its
accessible input rho_p^tensor r with tau^tensor r, and tensor both with the
same independent local apparatus. Finite TP LOCC sends tau's input to a
separable output, whose overlap with Phi_N is <=1/N. Data processing and
the binary test {Phi_N,I-Phi_N} give

    r D(rho_p||tau) >= D_Ber(p_out||q_out)
       >=p_out ln N-h2(p_out)
       >=(1-epsilon)ln N-h2(epsilon).

Here p_out>=1-epsilon and q_out<=1/N. The full residual condition implies
the marginal bound by contraction, so this necessary condition remains
valid for the unchanged actual-residual target. Nothing is postselected,
no failure branch is dropped, and no inaccessible record is measured.
Independent normal local workspaces retain separability and add zero input
relative entropy; the pinned finite-tree compression supplies an alternative
finite-dimensional treatment at fixed finite N.

Therefore

    (1-epsilon)ln N <= r U_g+h2(epsilon),    R(p)<=U_g.

One may also retain the old supply upper R<=B and take the minimum over g.
No useful finite blocklength, coding complexity or strong converse is claimed
by this elementary finite-error argument.

## Consequence: contiguous uniform inventories

Let g=ceil(log_D L), which lies in {1,...,L}; D^g>=L. Then

    B-R(p)>=H-H_g-c(D^-2)-1/g-1/D
           >=H-ln g-c(D^-2)-1/g-1/D.

For p uniform on EVERY k=1,...,L, H=ln L. The inherited original-D
constructive receiver gives B-R(p)<=H+kappa_D. Consequently

    ln L-ln ceil(log_D L)-c(D^-2)-1/g-1/D
      <= B-R(p) <= ln L+kappa_D,
    (B-R(p))/ln L -> 1    at each fixed D>=2.

Thus the previous half-versus-one LEADING coefficient is closed to one for
the contiguous uniform benchmark, with a remaining O_D(lnln L) converse
remainder versus an O_D(1) receiving remainder. More generally the leading
coefficient is one for any family with H(K) growing faster than lnln L,
or H_g=o(H) at a choice of g whose tail term is o(H). This does NOT prove
one for every growing-entropy prior with arbitrary support diameter.

The already proved universal receiver upper-deficit law H+kappa_D and the
explicit family also show coefficient one is the sharp universal worst-case
coefficient in any H-only achievable-deficit bound a H+O_D(1). The new
converse itself does not depend on the receiver theorem; the sandwich does.

## Importance, costs and remaining work

The construction replaces a failed single block partition by a small mixture
of aligned partitions. It removes the boundary-straddling entropy penalty
in a source-specific entanglement resource law. Entanglement theory methods
(isotropic separability, relative entropy, binary testing) are established;
source-specific novelty is UNKNOWN pending primary-literature review.

All registers remain finite before r->infinity. An explicit dense comparator
would occupy dimension D^(2L); no polynomial representation/algorithm or
experimental preparation is asserted. The proof representation has g block
partitions and their prior residue weights; computing those weights from an
explicit p costs O(L) arithmetic, log/precision costs additional. Source
formation, physical clock access, useful distillation blocklength and actual
technological consequence remain unestablished. No equipment operation.

Next decisive mathematical targets: (i) fresh audit and prior art; (ii) close
the lnln L remainder or show it is necessary; (iii) determine the correct
conditional-entropy/information-spectrum law for general priors and actual
correlated records. Mission NOT_ACHIEVED.
