"""No-producer-import arithmetic replay of the selected paid-reuse record.

Same author, not an independent scientific review. Reads recorded scalar
inputs, reconstructs caps/rate/error charges, and checks a generic absorbing
failure-memory control. No physical/native/quantum program is executed.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
RAW = HERE/'PAID_PROGRAM_REUSE_GUARDS.json'
RAW_SHA = 'c9bb72986bc497631b385684f3c6f4c77b0e0c81084409461ddb49e4537c23b6'


def ceilq(x):
    x = F(x)
    return -(-x.numerator//x.denominator)


def logceil(x):
    x = F(x)
    if x <= 1:
        return 0
    e = x.numerator.bit_length()-x.denominator.bit_length()
    return e if F(2)**e >= x else e+1


def main():
    assert hashlib.sha256(RAW.read_bytes()).hexdigest() == RAW_SHA
    record = json.loads(RAW.read_text())
    z, eta, gain = F(1,1000), F(1,100), F(1,74400)
    rows = []
    reconstructed = 0
    for row in record['rows']:
        x = row['block_scalar_guards']
        d = row['reference_beta_denominator']
        k = d*d//10
        t, s = x['t_mesoblock'], x['s_mesoblocks']
        cells, E = x['table_cells_upper'], 2*k*t
        assert k == row['k'] == x['k']
        assert cells == (k*t+1)*(2*x['w_bin']+1)
        assert E == x['E_inner']
        assert x['Bmu'] == x['Bp']+2*x['w_bin']+3
        assert x['cdf_sampler_bits_per_cell'] == logceil(
            F(128*cells)/(F(x['eps'])*F(1,2**x['Bp'])))
        bstat = logceil(F(64*cells)/(eta/2))+1
        assert bstat >= logceil(E+1)
        table = cells*(x['cdf_sampler_bits_per_cell']+bstat+2)
        assert table == x['probability_table_output_bits_upper'] == row['table_bits_to_transmit']
        pin, pout = 2*x['h_inner'], 2*x['h_outer']
        min_steps = 8*pin*(E*pin+x['Bdes_inner']+3)
        mout_steps = 8*pout*(x['parent_width']*pout+x['Bdes_outer']+3)
        assert min_steps == x['pauli_inner_steps']
        assert mout_steps == x['pauli_outer_steps']
        seed_inner = min_steps*(2*E+logceil(2*pin))+2*E
        seed_outer = mout_steps*(2*x['parent_width']+logceil(2*pout))
        seeds = (s*seed_inner+seed_outer+2*s*x['cdf_sampler_bits_per_cell']+2*k*s*t)
        assert seeds == x['all_random_seed_bits_upper'] == row['ideal_seed_bits_to_transmit']
        program = 1+table+seeds
        assert program == row['compact_program_bits']
        uses = 1 << row['repetitions_log2']
        assert uses == row['repetitions']
        block_z = z/(8*uses)
        assert block_z == F(row['block_error_target'])
        assert F(row['block_program_failure_target']) == eta/2
        zeros = max(1,ceilq(F(logceil(64*program/z),14)))
        assert zeros == row['zeros_per_program_bit']
        boot = program*(zeros+1)
        assert boot == row['program_forward_calls']
        fail = F(program,2**(14*zeros))
        assert fail == F(row['program_capped_reset_failure_upper']) <= z/64
        bits_init = logceil(F(2**24)/(z*z))
        cutoff = bits_init+8
        initial = 16*(cutoff+bits_init+4)
        assert 16*(F(1,2**cutoff)+F(1,2**bits_init)) <= (z/64)**2
        assert cutoff == row['global_initial_cutoff']
        assert initial == row['global_initial_forward_calls']
        nblock = x['forward_body']+x['forward_terminal']+x['forward_initial']
        assert nblock == x['forward_total'] == row['block_forward_calls']
        assert x['forward_body'] == k*s*t
        total = initial+boot+uses*nblock
        logical = uses*x['logical_width']
        assert total == row['total_forward_calls']
        assert logical == row['total_logical_width']
        target = F(3,2)+gain/(32*k)
        assert target == F(row['target_rate'])
        assert target-F(3,2) >= F(4,d*d*952320)
        assert x['logical_width'] >= (F(3,2)+gain/(16*k))*nblock
        margin = logical-target*total
        assert margin == F(row['exact_rate_margin_bits']) >= 0
        prev = row['last_failed_guard']
        assert prev['reuse_log2']+1 == row['repetitions_log2']
        assert F(prev['rate_margin']) < 0
        native_one = z/(1024*boot)
        assert logceil(1/native_one) == row['bootstrap_joint_native_accuracy_bits']
        assert 16*boot == row['bootstrap_instrument_steps_upper']
        error = z/32+2*fail+16*boot*native_one+uses*block_z
        assert error == F(row['global_error_bound']) <= 13*z/64 < z
        assert row['no_repetition_factor_on_same_program_good_event'] is True
        assert row['native_and_phase_lists_transmitted'] is False
        reconstructed += 38
        rows.append({'beta0_denominator':d,'log2_uses':row['repetitions_log2'],
                     'program_count_bitlength':program.bit_length(),
                     'forward_count_bitlength':total.bit_length(),
                     'exact_rate_and_error_checks':True,
                     'transported_width_fields_sufficient_bit_count':True})
    # Generic persistent-memory control: vacuum-start error is delta=2p.
    # On the test input with logical maximally mixed, an absorbing fault
    # flag makes the B-use complete distance exactly2[1-(1-p)^B], not
    # 2p^B. The complete hybrid 2Bp remains valid without iid faults.
    p = F(1,10000)
    memory = []
    for uses in [1,2,8,64,1024]:
        accumulated = 2*(1-(1-p)**uses)
        assert accumulated <= 2*uses*p
        if uses > 1:
            assert accumulated > 2*p**uses
        memory.append({'uses':uses,'joint_distance':str(accumulated),
                       'hybrid_bound':str(2*uses*p),
                       'local_stochastic_inference_rejected':uses>1})
    data = {'status':'PASS_SAME_AUTHOR_NO_IMPORT_RECORD_REPLAY',
            'scope':__doc__,'input_sha256':RAW_SHA,
            'reconstructed_scalar_groups':reconstructed,'rows':rows,
            'generic_absorbing_memory_controls':memory,
            'scientific_independent_review':False,
            'physical_status':'NOT_PERFORMED','mission':'NOT_ACHIEVED'}
    payload = json.dumps(data,indent=2)+'\n'
    out = HERE/'PAID_REUSE_RECORD_REPLAY.json'
    if out.exists():
        assert out.read_text() == payload, 'refuse changed frozen output'
    else:
        out.write_text(payload)
    print(json.dumps({'status':data['status'],'cases':len(rows),
                      'memory_controls':len(memory),'groups':reconstructed}))


if __name__ == '__main__':
    main()
