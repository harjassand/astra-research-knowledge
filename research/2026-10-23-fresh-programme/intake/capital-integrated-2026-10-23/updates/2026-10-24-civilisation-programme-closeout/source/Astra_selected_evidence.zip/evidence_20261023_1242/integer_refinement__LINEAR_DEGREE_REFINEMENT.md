# Linear degree in the signed-coset count

23 October 2026. W61 independent extension after completion of the fresh audit
of W14's frozen Cohen/collision packet. Full argument; fresh criticism PENDING.
This file does not alter that packet or its review. Priority and practical
advantage are UNKNOWN. The numerical universal Cohen constant is still
NOT_EXTRACTED.

## A. An averaging refinement for arbitrary real arrangements

Let

    w(y)=sum_(i=1)^t alpha_i (-1)^(a_i.y+b_i) 1_(A_i)(y), t<=C,

where the A_i are affine flats in F2^n and the positive set S={w>0} has density
at most 1/2. Then S has a nonzero Boolean annihilator of degree at most
floor(5C/2). This replaces the logarithmic factor in the elementary arrangement
bound, without using integer values or special coefficient sizes.

Proof. Let G={w<=0}, of density at least 1/2. For a flat A of codimension k,
the number of membership-fixing affine conditions needed at a point y is

    c_A(y)=k if y in A;  c_A(y)=1 if y outside A.

A containing flat is fixed by all its k defining equations. An excluding flat
is excluded by one equation violated at y. For k=0 the first cost is zero.
For k>=1,

    E[c_A(y) | y in G] = 1+(k-1) Pr[A | G]
                       <= 1+(k-1) 2^(1-k) <= 3/2.

The last scalar maximum is attained at k=2,3; k=1 gives cost 1. Each nonconstant
character needs at most one additional equation, and a constant character needs
none. Consequently the conditional mean total number of equations needed to
fix all t summands is at most 5t/2. Some y0 in G has integer cost at most
floor(5t/2).

Intersect these equations at that y0. Their consistency follows from y0 itself.
They fix every support membership and character phase, so w=w(y0)<=0 on the
nonempty intersection T. Its indicator is a product of at most floor(5C/2)
affine linear Boolean factors. It equals 1 at y0, so remains nonzero after
squarefree reduction, and vanishes on S. QED.

This is an existence argument; the complete NP evaluation-span algorithm
acquires an annihilator without receiving the flats, y0, or their weights.

## B. Exact inverse weights and integrality remove the factor entirely

Let C>=5 be an integer. Suppose w:F2^n->Z is integer valued, its positive set
has density at most 1/2, and it has the exact special representation

    w(y)=sum_(i=1)^t eps_i 2^ceil(n/2) 2^(k_i-n)
                     (-1)^(b_i.y) 1_(V_i^perp)(y),
    t<=C, eps_i in {+1,-1}, k_i=dim V_i.

Then its positive set has a nonzero Boolean annihilator of degree at most C.
In particular this applies to the inverse of the integer Cohen decomposition
of a square quadratic defect transform.

Proof. Put h=floor(log2 C). For C>=5,

    2h+1 <= C.                                             (B1)

For h=2 this reads 5<=C; for h>=3 it follows from 2h+1<=2^h<=C.

First suppose n<4h+2. Every subset of the cube of size at most 2^(n-1) has
a nonzero annihilator of degree ceil(n/2), by elementary dimension counting:
there are strictly more than 2^(n-1) squarefree monomials of degree at most
ceil(n/2), while evaluation at the set supplies at most 2^(n-1) linear
constraints. The binomial strict inequality holds for both even and odd n.
Thus there is an annihilator of degree at most

    ceil(n/2) <= 2h+1 <= C.                                (B2)

The case n=0 is immediate from the density assumption; for the application P
is the unique zero-bit square map and w=0. One may choose constant 1.

Now suppose n>=4h+2. Call a physical support V_i^perp high if its codimension
k_i is at least h+1. Its union U has density at most

    t 2^(-h-1) <= C/2^(h+1) < 1.                         (B3)

On y outside U, only low terms with k_i<=h contribute. Their total absolute
value is bounded by

    |w(y)| <= C 2^(h-floor(n/2))
            <= C/2^(h+1) < 1.                            (B4)

As w is integer, it is exactly zero there. By (B3) choose y0 outside every
high support. For each such support choose one vector v_i in V_i with
v_i.y0=1. Such a vector exists because y0 is not in V_i^perp. The linear
factor v_i.y vanishes throughout that support and equals 1 at y0. The product

    R(y)=product_(i: k_i>=h+1) (v_i.y)                    (B5)

has degree at most t<=C and R(y0)=1. It vanishes on U, and outside U there
are no positive w values by (B4). Hence it annihilates the positive set.
Repeated supports and redundant equations can only lower the degree. If
there are no high terms, use the empty product 1; integrality then gives
w=0 everywhere. QED.

The argument uses exact signed-coset coefficients and integrality of w. It does
not assert (B4) for general real weights, for approximate Fourier data, or for
an arbitrary claimed spectral representation. Nor does it assume the produced
point from an arbitrary acquired collision-annihilator has w=0: the final
ordinary NP preimage branch remains necessary.

## C. Scoped consequence and costs

For fixed c in H<=c 2^ceil(n/2), take any valid universal signed-coset count
bound C_c from the exact Green--Sanders integer theorem and enlarge it to at
least 5. By B, the chosen degree D=C_c suffices. Compose with the already
audited complete ordinary-NP collision evaluation-span algorithm.

This gives the same existential uniform FP^NP conclusion on the fixed-c
promised family with M_D=sum_(j<=min(D,n)) binom(n,j), now with D=C_c rather
than C_c(ceil(log2(4C_c))+1). Query count, physical dense-field serialization,
preimage branch and all off-promise caps remain as in the audited algorithm.
No decomposition is received or learned. C_c and the numerical exponent are
still NOT_EXTRACTED; this is not an instantiated practical algorithm or a
general Avoid/P-versus-NP claim.

The frequency-coset decomposition is classical Green--Sanders,
math/0611286v2 Theorem 1.3; exact primary source:
https://arxiv.org/html/math/0611286v2 . The complete acquisition/append-bit
composition is retained in the frozen W14 packet and independently audited
in the parent directory. Any novelty of these elementary refinements or their
composition is UNKNOWN pending wider priority review.
