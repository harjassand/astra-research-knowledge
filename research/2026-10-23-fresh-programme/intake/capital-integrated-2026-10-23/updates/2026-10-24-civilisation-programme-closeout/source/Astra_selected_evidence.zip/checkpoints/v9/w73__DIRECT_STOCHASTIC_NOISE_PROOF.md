# Direct stochastic-noise decoding without a scalarwise precision event

Checkpoint 3 candidate, 2026-10-23. Checkpoint 2 is preserved. This proof improves the sufficient control-energy cost of its Gaussian implementation. It does not claim an optimal energy theorem or a physical advantage.

## Contract

Use exactly the unknown positive weighted forest Laplacian/full-vector control/full-vector readout interface of ADAPTIVE_NOISE_PROOF.md. The labelled forest and all its continuous weights are fixed before design randomness; every edge has supplied lower floor a>0. Each action returns Lx plus independent mean-zero scalar sensor errors of sub-Gaussian variance proxy sigma^2, where sigma is supplied. Independence across the different actions at each vertex suffices; arbitrary correlation between different vertices in a given action is harmless. The noises are independent of the design and the input selection, or satisfy the corresponding conditional sub-Gaussian moment-generating-function bound after all controls for a batch are fixed. Preparations are initially exact 0/1 coordinates and L stays unchanged.

For n>=2 and 0<delta<1 set

    T = ceil(8 ln(4n/delta)),
    ell = ceil(max{8 ln(8n^2/delta),
                    1024 (sigma^2/a^2) ln(16 n T (n+1)/delta)}).

When sigma=0 the second term is zero. Draw independent fair binary label codes of length ell. Maintain known connected components exactly as in checkpoint 2. There are T batches. Each batch makes ell identical complete actions with input x_i=g_C (one fresh independent fair component mask g_C), and ell further complete actions x_i=g_C b_{i,r}, one per code bit. Thus

    Q = 2 ell T

is the worst-case total number of actual preparations/actions, including repeated mass measurements, and nQ is the number of acquired scalar readouts. Nominal total energy at each vertex is at most Q. No unit-total-energy assertion is made for this unscaled schedule.

Theorem (candidate). The learner below acquires the entire unknown support with probability at least 1-delta over both label/mask controls and sensor noise. It uses O((1+sigma^2/a^2) log^2(n/delta)) complete binary actions and that many units of nominal per-row control energy. Its naive computation is O(n^2 ell T) arithmetic operations, not near-linear time. There are no hidden label or adjacency queries.

## Decoder

Freeze the current known-component partition for a batch. Average the ell acquired responses to the mass control. For an inactive row i, negate this average to obtain mhat_0. Negate the acquired output of the rth code action to obtain mhat_r. Their true means are the positive mixture from checkpoint 2:

    m_0 = sum_{k in A} w_k,
    m_r = sum_{k in A} w_k b_{k,r}.

The mass error has variance proxy sigma^2/ell; each code error has proxy sigma^2. They come from disjoint action acquisitions. No mixture weight is known in advance.

If mhat_0<=a/2, declare empty. Otherwise evaluate every original label j, with no guessed-bit requirement:

    Chat_i(j) = sum_{r:b_jr=0} mhat_r
                + sum_{r:b_jr=1}(mhat_0-mhat_r).

If the minimum is <=a ell/8, accept its minimizing label as a singleton; otherwise declare nonsingleton. Check the returned label is active and outside the row's known component. Insert all resulting distinct true edges after completing the batch and merge their components. Estimate a found edge's weight by mhat_0. Controls never use these estimates.

The minimum can be computed by explicitly scanning all n labels. This is O(n ell) per row, hence O(n^2 ell T) over all rows/batches; the theorem charges this computation. No nearest-neighbour or efficient error-correcting decoder oracle is presumed. Store O(n ell) acquired moments/codes plus the forest and partition.

## A good label event

As before, Hoeffding and a union bound imply that every distinct code pair has Hamming distance >=ell/4 except with probability

    n(n-1) exp(-ell/8)/2 <=delta/16.

Fix a code on that event. For every row mixture and candidate j the exact certificate is

    C_i(j)=sum_{k in A} w_k d_H(b_k,b_j).

It is zero for the correct singleton, and at least a ell/4 for every candidate in any nonsingleton mixture and for every wrong singleton candidate. Positivity, the supplied floor, and the code distance give this statement without a maximum-degree or upper-weight premise.

## Direct noise certificate

Let h_j be the number of ones in b_j. Certificate noise is

    Z_ij = sum_r (1-2b_jr) xi_ir + h_j xi_i0bar.

The code errors xi_ir and the mass-average error xi_i0bar are independent across their acquired actions at row i. Conditional on the batch controls, Z_ij is mean zero and sub-Gaussian with variance proxy at most

    ell sigma^2 + h_j^2 sigma^2/ell <=2 ell sigma^2.

Therefore

    P[|Z_ij|>a ell/16 | controls]
       <=2 exp[-a^2 ell/(1024 sigma^2)].

Also

    P[|xi_i0bar|>a/4 | controls]
       <=2 exp[-a^2 ell/(32 sigma^2)].

Both bounds are zero for sigma=0. The certificate tail is independent of the actual mixture weights, number of active neighbours, and known-component size. Crucially, the mass control was averaged ell times: acquiring it only once would leave its h_j-weighted noise with order ell^2 variance and would forfeit this gain.

If all these mass and certificate margins hold, empty and nonempty are distinguished by a/2. A true singleton has certificate <=a ell/16<a ell/8. All other candidates have certificate >=3a ell/16>a ell/8. Thus classification and the accepted parent are exact. Each accepted edge's mass estimate has absolute error <=a/4 on this event. To demand a smaller absolute weight error, additional mass precision must be acquired and charged; exact continuous weights are not claimed.

## Adaptivity and probability

One must not condition the contraction argument on a future all-noise-good event. Instead define an ideal support process which uses the same code and component masks, classifies each actual mixture exactly, and ignores sensor errors. Its partition is independent of sensor noise. For that ideal process, evaluate the noisy tests using independent noise arrays indexed by batch, mass repetition/code coordinate, and row. Until the first failed test the real process and this ideal process coincide, including all future controls already chosen in that batch.

Conditioned on the complete ideal control sequence, or sequentially by the conditional bounds above, there are at most nT mass tests and n^2T candidate-certificate tests. The union bound gives ideal-test failure at most

    2nT(n+1) exp[-a^2 ell/(1024 sigma^2)] <=delta/8.

This bound does not require independence among tests or candidate labels. The first-failure coupling transfers it to the actual adaptive learner. The noise is never reused as evidence from an unacquired hypothetical query; the ideal coupling is an analysis of the actual acquisition up to its first possible error.

For the ideal process, the same degree-1-or-2 quotient-component events as checkpoint 2 expose distinct new edges. With P_t equal to the unacquired-edge count,

    E[P_{t+1}|past] <=(7/8)P_t,
    P[P_T>=1] <=n exp(-T/8) <=delta/4.

Combining the code, noise, and progress failures gives at most delta/16+delta/8+delta/4=7delta/16<delta. This proves the theorem with slack. In particular the noise-induced dependence of a failed decoder's future partition has not been ignored.

## Charged resources and limits

The action/energy bound is Q=2ell T=O((1+sigma^2/a^2)log^2(n/delta)). This includes all ell repetitions of every mass action. Inputs are binary, so there is no growing raw amplitude or hidden infinite-precision code coordinate. Each action prepares n coordinates and acquires n outputs; total physical readouts are nQ. All scalar noise acquisitions in the proof are actual measurements, not simulated extra samples.

Output dynamic range and control accuracy are still premises with costs. If weights are at most W and degree at most D, raw response magnitude is at most DW. If actual input-coordinate error is bounded by kappa, its response bias is at most 2DW kappa per coordinate. A fixed sensor/quantization bias beta contributes at most 2ell beta to a certificate. For example, reserving beta<=a/128 and replacing 1024 by 4096 in ell leaves ample margin for both stochastic and bounded bias errors. Such a bound must cover 2DW kappa plus sensor/quantization bias. Arbitrary fixed bias does not average away. Stochastic preparation errors with degree-dependent response variance must instead enter the supplied sigma proxy; the theorem does not infer a degree-independent proxy from hardware.

If all controls are divided by c, signal floor becomes a/c while sensor sigma remains fixed. In the stated sufficient bound ell and the action count must then increase with c^2 sigma^2/a^2. Repeating or rescaling cannot create a unit-total-energy result for fixed sigma/a. ENERGY_AND_BASELINES.md's ordinary Fano bound requires per-row energy at least order (sigma^2/a^2)log n already on single-edge forests. The present direct decoder is within one logarithmic factor in this upper order, with large unoptimized constants; no matching optimality is established.

For sigma=0 this stochastic theorem does not replace checkpoint 2's arbitrary bounded-error theorem: the current decoder has a different noise contract and a slower naive label scan. Strong graph-sketch and coding baselines remain relevant. Source/priority: UNKNOWN. Physical acquisition: NOT_ACQUIRED. Practical advantage: UNKNOWN. Mission achievement: NOT_ACHIEVED.
