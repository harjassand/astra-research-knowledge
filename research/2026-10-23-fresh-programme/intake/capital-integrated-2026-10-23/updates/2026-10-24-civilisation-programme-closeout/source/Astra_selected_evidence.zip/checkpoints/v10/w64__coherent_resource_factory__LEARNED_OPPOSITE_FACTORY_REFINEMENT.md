# Learned-parameter opposite uploader with fully charged confidence allocation

23 October 2026. Addendum to frozen UNKNOWN_BETA_CONTROL_ACQUISITION_V1.md SHA256 b96f5e19c8964682734bd85b6841a0640bfa50992aec3e237914ce873991a292. The original sufficient algorithm remains unchanged. This addendum uses the stronger controlling f64ed77... opposite uploader and removes an unnecessary logarithm in the confidence schedule. New universal proof candidate; fresh full criticism PENDING.

## L1. The final factory needs no physical inverse

Keep exactly the b96 native Rabi experiment, reference-restoring retrieval, compact known rational interval0<beta_lo<=beta<=beta_hi<1, and unknown fixed beta. F is held untouched during calibration. After learning a rational beta_tilde with ||V(beta)-V(beta_tilde)||<=kappa, simulate the OPPOSITE local download using V_H(beta_tilde)*. Send the prepared ports once each through actual V(beta), in reverse order. The complete channel error is

    2sqrt(2tau)+2T kappa+2e_loc+epsilon_root,
    tau=Pr[Bin(T,1-beta^2)<H].                      (L1)

No exact inverse pulse, n_star factor, physical inverse-precision cost, or backward quantum return enters THIS UPLOADER. Its known-root/known-sector target and joint UNHALVED root-error convention remain explicit. Learning beta by multi-pass Rabi experiments DOES use quantum backward returns; the zero-backward uploader is not silently promoted to a zero-backward acquisition algorithm.

Choose T using amin=1-beta_hi^2 and kappa of order epsilon/T, then assign numerical compilation/root/tail allowances and each of the three acquisition bad events a fixed fraction of epsilon as in b96. All acquisition aborts/statistical errors remain in the output; their total weight contributes at most twice that weight to unhalved diamond error. Local target preparation, precision and storage remain separately charged. The acquired estimate need not recover beta exactly.

## L2. Weight the level failures instead of using one sample count

The b96 two-frequency quadrature reconstruction and nearest-lift proof remain unchanged. In particular use nu=1/8 and the explicit SAFE condition3nu<pi. At level k=0,...,J with n_k=2^k, allocate the combined failure allowance for the TWO cosine estimates as

    zeta_k=zeta_high*2^(k-J-1).

Their sum is less than zeta_high. Let eta=sstar/128 as before. Since the probability of either cosine estimate missing eta is at most4exp(-K_k eta^2/2), it suffices to take

    K_k=ceil[(2/eta^2)ln(4/zeta_k)].                (L2)

The coarse sample count K0 retains its independently allocated zeta0. Thus on the union of good statistical events every phase lift is correct and |gammahat-gamma|<=nu/(2*2^J), exactly as before. No independence AFTER retrieval capping is assumed; couple to the uncapped iid experiments and union the cap event.

The number of probes and coherent-query count are

    P=K0+2sum_k K_k,
    Q_Rabi=K0+sum_k K_k(2n_k+1).                   (L3)

Add the shared worst-case retrieval cap M(P,ln(1/zeta_ret)) from b96. All returned quantum qutrits are at most Q_Rabi and all classical flags at most P+M.

For C=2/eta^2, K_k<=C[ln(8/zeta_high)+(J-k)ln2]+1. The exact sums

    sum_k2^k=2^(J+1)-1,
    sum_k2^k(J-k)=2^(J+1)-J-2

give

    total forward calls
      =O_interval[kappa^-1(1+ln(1/zeta))
          +(ln(1/kappa)+1)^2
          +(ln(1/kappa)+1)ln(1/zeta)].              (L4)

The last two terms are also bounded by a constant multiple of kappa^-1(1+ln(1/zeta)) for 0<kappa<1. This yields the familiar Heisenberg-order query scaling with a logarithmic confidence factor, without the original uniform-sample loglog(1/kappa) factor. It is standard confidence-allocation reasoning, not a new general phase-estimation theorem.

Substituting kappa of order epsilon/T and zeta of order epsilon into (L1)--(L4), a sufficient complete forward-query and backward-quantum-return bound is

    O_interval[(H+ln(1/epsilon)+1)/epsilon
                       * (1+ln(1/epsilon))].      (L5)

Only the acquisition uses the returns. The final upload still uses exactly T single-pass forward calls. All scalar sample, integer-cap and finite arithmetic costs remain paid; conservative interval constants can be extremely large. No practical advantage follows from the asymptotic order.

## L3. Deterministic horizon and a slower classical-feedback option

All calibration counts/frequencies and its shared retrieval cap are predetermined. On every fully completed calibration record the actual bath is still the initial known sector root, exactly. Once the estimate is known, spare call budget may be padded BEFORE local upload with fresh vacuum ports at that root, leaving it unchanged up to a scalar phase. This gives a deterministic total horizon without disturbing the final uploaded state or leaking its unknown length. Calibration itself never touched F. Abort branches are padded arbitrarily and remain in the bounded failure part.

If the allowed backward wire is CLASSICAL ONLY, do not use the n>1 Rabi probes. Repeated n=1 flags estimate a directly; each probe uses the already proved adaptive retrieval and returns the old bath on success. Hoeffding plus the same total retrieval cap gives O_interval[kappa^-2 ln(1/zeta)] forward acquisition calls, with no quantum backward carrier. With kappa=O(epsilon/T) this is a slower O_interval[T^2 epsilon^-2 ln(1/epsilon)] alternative. The wire/cost tradeoff must remain explicit in any body or capacity comparison.

A one-off calibrated estimate has finite precision. Reusing it in multiple operations must charge its error against their TOTAL sensitivity. A body with N additional parameter-dependent gates cannot silently use the factory's epsilon/T calibration budget to obtain epsilon/N control for free.

## L4. Resource windows and scope

For known-root resource families with bath depth H_N and a locally prepared m_N-qubit Bob portion, the latter can be distributed using the shared-pop budget of retry_upload/TOTAL_ATTEMPT_BUDGET_V1.md. This costs O_interval[m_N+ln(1/epsilon)] forward calls and classical flags, returning the root on successful stopped branches. The unknown-parameter quantum-return option then has (L5) plus that distribution cost. If H_N+m_N=o(N), a sufficiently slowly vanishing epsilon_N makes THESE PHYSICAL-CALL costs o(N), by taking for example epsilon_N=r_N^(1/4), r_N=(H_N+m_N+ln(N+1))/N, once r_N<1. The polynomial-log terms in (L4) are o(N) as well.

This is a PHYSICAL-QUERY window only. The explicit local word simulation still costs roughly T H polylog(H) gates, and arbitrary target preparation has its own supplied circuit cost G_N. Claiming sublinear TOTAL execution cost additionally requires all those local gates, phase synthesis, state preparation, storage/time/error correction and classical processing to fit the stated budget. Neither H_N+m_N=o(N) nor a large-dimension state description guarantees that. There is no best-control or autonomous representation-learning advantage claim.

Unknown-root preparation and whole initializer/sector equivalence are not newly endorsed by this addendum. Beta drift, arbitrary horizon-dependent deep initializers and initial seed-purifier return remain outside scope. Generic Rabi/robust phase estimation is PRIOR; full fresh proof criticism PENDING; programme mission NOT_ACHIEVED.
