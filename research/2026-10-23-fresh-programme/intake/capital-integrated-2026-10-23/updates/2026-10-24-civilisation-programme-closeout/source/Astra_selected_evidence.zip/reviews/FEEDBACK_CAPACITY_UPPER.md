# Fresh audit of the fixed-horizon quantum-feedback comb extension

23 October 2026. Auditor w17_bath_depth. Candidate: w36 `FEEDBACK_EXTENSION.md`, reviewed frozen SHA256 `6207ab3c900911bf4d4196097f97f0f9982e23e57dd7a86c8d6d61e2375b2601`. Exact bytes copied as `FEEDBACK_REVIEW_SNAPSHOT.md`. This is an independent internal reconstruction and new diagnostic, not external certification or a generic feedback-useless theorem.

## Verdict and exact result

No blocking defect was found at the exact stated interface, including the finite-horizon normal-auxiliary extension. Assume the independently audited full chronological channel/Choi order

```
J_N<=C_N J_replacer,N,
C_N=2(N+1)(8+2beta^2)^N,
J_replacer,N=I_(A^N) tensor sigma_*^(tensor N),
sigma_*=diag(1/2,1/4,1/4).
```

Then every deterministic fixed-N strategy transmitting a fresh K-dimensional quantum input from Alice to Bob, with arbitrary initial shared entanglement independent of the logical input/reference and bath, arbitrary local CPTP memories, and arbitrary noiseless Bob-to-Alice quantum messages, obeys

```
F_e<=min{1,C_N/K^2}.
```

No forward wire, branch flag, timing signal or other Alice-to-Bob carrier is allowed outside the N physical qutrit calls. The same quadratic threshold `.5log2(8+2beta^2)` is an exponential strong-converse ceiling at tau_pi, and a pointwise strong-converse ceiling for every fixed independent normal initializer. The log2(3) dimension cap can be retained where applicable. This does not prove equality of assisted and unassisted capacities, fix the quadratic coefficient, or say that feedback generally gives no advantage.

The candidate's source anchor is the older w49 v3 snapshot. Its bound has also been independently checked in corrected v4, SHA256 `ccd777dd4daea424e19d6b8fd4e8c6842fb7f0614aa0fb325cc1744fe532da11`; v4 repairs the overbroad radial-invariance wording without changing the global CP conclusion. I informed w36 to carry that provenance clarification into its next version.

## 1. Full causality is the indispensable extra premise

The actual N-port operation has unnormalized Choi operators J_m for its chronological prefixes, satisfying

```
Tr_(B_m)J_m=I_(A_m) tensor J_(m-1),   J_0=1.
```

The bath can be infinite dimensional: only the external qutrit port dimensions enter these Choi matrices, and the sequential physical dilation establishes the recursion directly. Future input slots cannot influence previous outputs. The product replacer obeys the identical recursion. An arbitrary CP comparison channel without these same causal constraints would not suffice to justify arbitrary feedback wiring.

Fix the full horizon N and a single scalar C=C_N>1. Define **every** prefix of the difference using that same scalar:

```
D_m=(C J_replacer,m-J_m)/(C-1),   0<=m<=N.
```

The full D_N is positive by the global order. Partial trace and the recursion give `Tr_(B_m)D_m=I_(A_m) tensor D_(m-1)`. Positivity therefore descends to each prefix, and D_0=1. The standard deterministic-comb characterization makes D a normalized physical sequential memory process. Replacing C by an independently varying C_m at each prefix would break this argument; the candidate correctly avoids that error. The resulting exact comb identity is

```
replacer=(1/C) actual+(1-1/C) difference.
```

The difference process is an analytical existence comparison, not a bath operation granted to the actual protocol.

## 2. Feedback order follows from physical convexity

Fix the complete strategy, including preshared state, Alice/Bob laboratory memories, all quantum return messages, local maps and final TP decoder. Connecting it to any normalized physical comb yields a normalized CPTP logical channel. Circuit contraction is linear in the inserted comb. The preceding convex identity therefore gives

```
Lambda_actual<=_CP C Lambda_replacer.
```

This reasoning is valid for coherent adaptive strategies. It does not freeze a classical transcript, and does not assert that a raw partially transposed link-product formula is positive on arbitrary matrices. The physical realization of the normalized difference process is exactly what makes the order safe.

Initial preshared entanglement does not invalidate this step: it is a fixed strategy resource, independent of the fresh logical R/M state and the internal bath. Allowing it in an upper-bound model strengthens the scope of the converse; it is not an uncharged resource supplied to the ordinary lower construction.

## 3. The comparison cannot signal forward

With every forward device tooth replaced by `Tr(.)sigma_*`, Bob's entire laboratory is initially independent of R. An Alice-local TP map cannot change the joint reduced state on R and Bob. Each replacement tooth discards its Alice input and appends a fixed Bob state, preserving that independence. A Bob-local operation or a quantum system sent from Bob to Alice likewise preserves independence of R and Bob's retained systems. This inductive statement includes Bob's measurement records and all retained quantum memories.

The same induction shows that Bob's reduced output depends only on his initial resource marginal and fixed operations, not on Alice's logical input parameter. Thus the resulting normalized logical channel is a replacer, even with initial entanglement and backward quantum communication:

```
Lambda_replacer(X)=Tr(X)zeta,  Tr zeta=1.
```

No accepted-branch normalization is used. Conditioning on a heralded success outcome, a free forward classical flag, an initial R/Bob correlation, or a forward side channel would change the comparison and invalidate this specific K-squared conclusion. Those possibilities are excluded explicitly by the interface.

Apply the channel order to the normalized Bell input. Its untouched R marginal is I/K regardless of all local encoding details. The comparison Bell overlap is exactly

```
<Phi_K|(I_R/K tensor zeta)|Phi_K>=1/K^2.
```

This proves the fidelity bound and the stated exponential ceiling. The same logical-channel order also bounds final logical mutual information by log2 C when its entropies are finite. It does not identify a globally prepared adaptive physical-input entropy, nor imply the original bath-only leakage formula used in the nonadaptive block theorem; extra laboratory systems and preshares change that purification bookkeeping.

## 4. Infinite-dimensional normal states and fixed-normal baths

For each fixed normal bath tau independent of the laboratories, its complete protocol fidelity remains a bounded positive initializer effect, even under adaptation. For a fixed finite vertex cutoff P of maximal depth A, the subnormalized `tau_P=P tau P` obeys `tau_P<=3*6^A tau_pi`. Hence

```
F_e(tau)<=3*6^A C_N/K^2+||tau-tau_P||_1.
```

Fix P before taking N to infinity and then enlarge it. Normality suffices for the same strong-converse limit at every fixed tau. This acquires no tail modulus, uniform finite horizon, uniform exponential normal-state rate, or new bath reset. Strategies may change with N because each bounded effect is at most the identity.

The core comb proof has finite port Choi spaces and allows arbitrarily large finite laboratory/register dimensions per code. The candidate's normal-auxiliary extension is sound for a prescribed finite-horizon circuit of finitely many normal CPTP laboratory stages, or a defined trace-norm limit of such circuits. At the finitely many original normal states, choose high-probability finite-rank local cutoffs and use deterministic compression with a fixed erasure output. Gentle projection controls the disturbance even when a laboratory is entangled with the bath, R or the other laboratory. An ordered hybrid argument inserting compressions from later stages toward earlier stages, with trace-norm contractivity of the remaining fixed circuit, bounds final disturbance by the finite sum of original-state compression errors. Compressing input/output supports turns the restricted laboratory stages into genuine finite-dimensional CPTP maps. A normal shared state is also approximable by local finite-support cutoffs. Only the actual final logical output needs approximation; every finite approximant already satisfies the uniform fidelity upper.

This is existence/continuity at a fixed circuit, not an efficient or uniform acquisition statement. Non-normal infinite resources, an unspecified infinite number of operations in finite time, expected-use horizons and postselected renormalization are not covered. The candidate states these boundaries explicitly.

## 5. Independent coherent-return diagnostics

To diversify the originator's shell tests, I implemented a separate exact two-call quantum-return fixture in `check_coherent_feedback.py`, importing no peer implementation. Initial baths are (i) a complex vacuum-seed superposition, (ii) a coherent superposition across seeds/depths/colors, and (iii) a mixed rank-two coherent normal state. These initializers are not charge diagonal. Both bath and full reachable endpoint amplitudes are retained.

The fresh logical Bell state is independent of a partially entangled Alice/Bob resource with Schmidt probabilities 0.3,0.7 and two tested complex phases. Alice embeds the logical qubit into the first qutrit. Bob applies a random joint unitary to that first output and his retained resource qubit and sends the entire qutrit back quantum coherently. Alice applies a random response unitary to it and her resource half, then sends it through call two. Bob applies a random joint unitary decoder and retains a qubit. There is no forward side wire. Beta=0,.02,.4,1 gives 24 cases.

The code directly computes the ordinary coherent-bath two-call Choi matrix, its smallest exact replacer CP coefficient, original causal recursion, normalized difference-comb prefix recursion using the same full coefficient, and the adaptive logical Choi order after the explicit quantum-return circuit. It also verifies that the comparator has R/Bob product form and Bell overlap 1/4. The faithful-normal domination bound is checked separately; it is much looser than the direct coefficient used by the adaptive-order diagnostic.

All 24 cases passed. Raw data: `coherent_feedback_checks.json`. Script-body time `0.07754687499254942` seconds; macOS maximum RSS `36,962,304` bytes; Python 3.14.3/NumPy 2.5.3. These are finite synthetic exact-model fixtures with floating checks, not acquired physical measurements, an all-N computational proof or a useful communication code. No historical scientific suite was replayed; total discovery/inference/review cost remains UNKNOWN.

## 6. Independently retrieved primary-method comparison

- Chiribella--D'Ariano--Perinotti, [*A theoretical framework for quantum networks*, 0904.4483v2](https://arxiv.org/pdf/0904.4483), Theorem 5 and equation (40), supplies exactly positivity plus causal trace recursion for deterministic combs, with physical memory-channel realization. This is an established tool, not a new comb theorem here.
- Gutoski--Watrous, [*Toward a General Theory of Quantum Games*, quant-ph/0611234v2](https://arxiv.org/pdf/quant-ph/0611234), Theorem 6, independently gives the positive-strategy/linear-normalization characterization and finite memory realization. Their strategy representation also supports the positive-order viewpoint for interactive tests.
- Cooney--Mosonyi--Wilde, [*Strong converse exponents for a quantum channel discrimination problem and quantum-feedback-assisted communication*, 1408.3373](https://arxiv.org/pdf/1408.3373), explicitly studies arbitrary-channel versus replacer comparison and adaptive quantum-feedback converses. It is a close generic method predecessor. Its repeated-memoryless-channel evaluation is not substituted for the present exact single recurrent N-comb.
- Bowen, [*Quantum Feedback Channels*, quant-ph/0209076v4](https://arxiv.org/pdf/quant-ph/0209076), defines noiseless receiver-to-sender quantum feedback and exhibits distinctions between assisted and unassisted capacity effects. This prevents interpreting the present common ceiling as a general statement that feedback is useless.

Historical priority for applying these established methods to the actual recurrent-tree bound remains UNKNOWN. The current upper preserves exact resource accounting: N fixed physical qutrit calls; ideal preshares and backward wires are allowed only to enlarge the upper-bound strategy class. Their energy, bandwidth, preparation, precision, storage and synchronization costs have not been supplied as a practical construction. No device reset, physical experiment, purchase, outreach or publication occurred. Exact assisted capacity, efficient encoding, physical usefulness and mission success remain unresolved.

## V2 delta acceptance and the full-parameter ceiling

I read the exact diff to the originator's Version 2, SHA256 `f532d88b454f974c4ea4e6333a7357c2d1d9b176f09cfceb23c53f11dc04112b`. It updates the corrected underlying proof anchor, adds independently executed coherent-return diagnostics, and applies the same generic comb lemma to every normalized product-replacer comparison in the audited source. Those extensions pass at their stated scope. I have not rerun the originator's diagnostic suite; its finite numerical claims are its own records, distinct from my new coherent-bath fixtures.

For each fixed `1<=t<3/sqrt2`, the source comparison has coefficient

```
A_N(t)=[2(N+1)/(3-t sqrt2)]h_b(t)^N,
h_b(t)=2sqrt2(1-b)(t+2/t)+b(5+2t^2+2/t^2),
sigma_t=diag(1,t^(-2),t^(-2))/(1+2/t^2).
```

Its product replacer is chronological and normalized, so the difference-comb and no-forward-signalling proof applies with the same full-horizon A_N(t). The derivative has negative sign at t=1 and positive sign at t=sqrt2 for 0<b<1, and the positive second derivative gives a unique minimizer inside that interval. For t>sqrt2 both derivative terms are positive. Therefore the stated optimized upper is valid. In particular the simple admissible t=1 certificate gives

```
Q_assisted<=.5log2[6sqrt2(1-b)+9b]<log2(3),  b<1.
```

Thus every nonzero strength of the U component has a strict deficit from the ideal-qutrit forward data rate even in the stated stronger assistance class. At b=1 the physical operation is iI and log2(3) is achievable. This is a new device-specific scope consequence of the same evaluated bound; it is not an equality formula, a claim that feedback cannot change capacity below the ceiling, or a generic theorem about arbitrary feedback channels.
