# Fresh audit of the scalar fresh-noise entropy budget

23 October 2026. W68 internal reconstruction. Frozen W40 source
SCALAR_ENTROPY_NOISE_TRADEOFF.md, SHA256
3c3d20ea2da678851b523a24f768860cca8ee757ebc2f6ce5bb8c5ba5b93e8f6.
Read afresh after the previous rank/support audits. **PASS: no gap found at
the exact scalar whole-channel scope.** Historical priority, external
validation, physical/practical value remain UNKNOWN; mission NOT_ACHIEVED.

## Exact finite statement and proof reconstruction

F is a scalar-block tracial expectation on S_N tensor A_K, N=r^3,
r>=2, with arbitrary orthogonal projection blocks Pi_j of rank t_j.
The prepared state is sigma_j=Pi_j/t_j, its system marginal is rho_j,
and its tracial weight is w_j=t_j/(NK). There is no product-basis,
separability, event-membership, or second-expectation assumption for the
single-channel bound. The recovered FULL enlarged-domain error to E_P D
is at most epsilon<=1, in the UNHALVED diamond normalization.

The signed quantity

    I_F=sum_j w_j[S(rho_j)-log t_j]

is the tracial average of -S(A|S) for the prepared states. It can be
negative, and it is bounded above by log K by Araki--Lieb. A positive-part
replacement would change the theorem and is not made.

F fixes sigma_j, so ||rho_j-E_P rho_j||_1<=epsilon. With delta=epsilon/2,
entropy continuity gives S(rho_j)>=S(E_P rho_j)-f_N(delta), where
f_N=h(delta)+delta log(N-1). Its monotone range contains delta<=1/2.
For a_j=Tr(P rho_j),

    S(E_P rho_j)=h(a_j)+a_j log r+(1-a_j)log L,
    sum_j w_j a_j=r/N=:p, L=N-r.

Dropping only the nonnegative h(a_j) term yields

    sum_j w_j log t_j >= p log r+(1-p)log L-f_N(delta)-I_F.

Since C_F=sum_j t_j^2 and C_F/(NK)=sum_j w_j t_j, scalar Jensen has the
correct direction and proves the source's finite bound. A useful EXACT
restatement is

    C_F >= N^2 K 2^[-h(p)-f_N(delta)-I_F],              (R1)
    log(C_F/N^2)>=log K-I_F-h(p)-f_N(delta).            (R2)

Indeed r^p L^(1-p)=N p^p(1-p)^(1-p)=N 2^(-h(p)). Thus no additional
asymptotic estimate is needed for this simplification. At epsilon=O(1/r),
h(p)+f_N(delta)=o(1), proving the asserted noise/coherent-information
budget. The input may be correlated with the retained ancilla; testing
the F-fixed sigma_j is precisely where prepared-only guarantees would
be insufficient.

## Bath charges and broader comparator

For an independent initial bath of dimension e and rank s implementing
the WHOLE enlarged F through one unitary and one final trace,
C_F<=es. Thus the same finite lower applies to es, with no extra K
factor. A pure bath has s=1; a general mixed bath has s<=e. The scalar
Choi formula sum t_j^2 is the key class restriction.

If every sigma_j has S(A|S)>=0, then I_F<=0, giving the mixed lower
(1-o(1))N sqrt(K) and pure lower (1-o(1))N^2 K. Conditional entropy
concavity also makes EVERY output mixture nonnegative in conditional
entropy. For exactly commuting F,G this includes the common output,
so the previously audited common-entropy lower gives K>=(1-o(1))r at
epsilon_star=2/(r+1). Hence the physical coloring matches both leading
bath ratios even in this broader class. An average condition I_F<=0
alone supplies the bath inequality, but not this common-state K lower;
the source preserves that distinction correctly.

PPT is a valid sufficient special case: the reduction map composed with
transpose is completely positive with Choi I-swap, so PPT implies
sigma<=sigma_S tensor I. Operator monotonicity of log gives
S(sigma)>=S(sigma_S), using a positive-support regularization if needed.
No PPT-to-separability claim is used.

## Near-optimal noise and flat-resolution calibration

If es<=(1+o(1))N^2, (R2) implies I_F>=log K-o(1), while Araki--Lieb
gives the opposite bound. This charges the tracial-average prepared
blocks' conditional entropy, not just one selected output's entanglement.

The source's flat-resolution expressions independently reconstruct. For
the rare, active, and common blocks respectively, write p1=r+1 to avoid
confusing it with p=r/N above:

    I_P=-log k,
    I_S=log(p1/k)-log(p1)/r,
    I_Z=log(p1/k)-log(p1/r)/r.

For S, the system masses are 1/r uniformly on B and (r-1)/r uniformly
on U; for Z they are 1/r uniformly on V and (r-1)/r uniformly on U.
Subtracting each uniform global block entropy yields exactly the stated
formulas. Their weights are 1/r^2, (r-1)/r^2, and r copies of
(r-1)/r^2. The weighted average equals log k-o(1), including the rounding
deficit log(k^2/(r+1))=O(r^(-1/2)). Small-r individual signed values
need not be positive, which is another reason not to truncate them.

## Boundaries and falsifiers

The range must be scalar. W61's nonabelian common-M_r construction has
internally separable outputs but a different Choi multiplicity formula;
it does not obey (R1) with the ranks of scalar prepared blocks. Conversely
external-reference entanglement breaking alone does not imply internal
S:A nonnegative conditional entropy. The quantum Fourier-flat scalar
pair explicitly escapes that replacement.

A scalar full-domain fixture violating (R1), or one with pointwise
nonnegative block conditional entropy and smaller leading whole-bath
cost, would falsify the corresponding result. A different enlarged map
with the same recovered marginal or a nonabelian range is outside the
claim. Entropy continuity, Jensen, Choi rank and conditional-entropy
facts are prior ingredients; this audit does not clear historical
priority or imply fast compilation, cheap reset, hardware or usefulness.

## Separate exact-optimum membership boundary

I also freshly reconstructed W40 EXACT_SEPARABLE_NONMEMBERSHIP_EXAMPLE.md,
SHA256 0bf19a2b509b72352d9cf22925e133b0565df64fda97063d2bebc3964bedd9d6,
with the precise joint-branch clarification in its independent audit
CROSS_REVIEW_W68_BATH_SEPARATIONS.md section 5.

The product system rotation mixes A=P minus Q with V, fixes the active
S=B_L+R block, and commutes with Q. Thus G's full-domain error is exactly
preserved. F's saturated S branch stays fixed; every other original
recovered branch has error at most2/[r(r+1)], so its small perturbation
remains strictly below2/(r+1). P_L does not commute with the rotated
minimal rare projection, establishing actual failure of membership at
the EXACT optimum. Scalar ranges, internal separability, block/bath ranks
and complete local hot return all persist under this product conjugation.

For its optional joint-return paragraph, the correct hot-input branches
are PHYSICAL B and B-complement. On hot U rows the original coloring
output is exactly the outside uniform joint state; on hot V rows the
error is2/(r+1); on hot P rows it is zero. Hence the B-complement hot
channel error is at most2/(r+1), while B attains2r/(r+1). The rotation
preserves that decomposition and the supplied perturbation is smaller
than its slack. The same joint maximum follows. An arbitrary enlarged
S-complement input would not be licensed by this hot-channel estimate.

## Independent retained diagnostics

`check_scalar_entropy_budget.py` passed 50,211 assertions, with largest
positive floating violation1.69e-14 inside its tolerance. It builds twelve
globally conjugated two-block expectations with a rigorous whole-domain
diamond upper4||U-I||, checks their fixed-state entropy budgets and signed
averages, directly calibrates the flat-block marginal probabilities through
r=10,000, and tests the reduction/conditional-entropy gate on36 explicit
separable states. Its r=2 flat average is NEGATIVE (-0.15564 bits), while
the r=3 value is positive (0.53740 bits), exercising the signed boundary.
The matrices are diagnostics and do not independently certify a diamond
norm optimum, an entangled PPT example, or the universal theorem.
