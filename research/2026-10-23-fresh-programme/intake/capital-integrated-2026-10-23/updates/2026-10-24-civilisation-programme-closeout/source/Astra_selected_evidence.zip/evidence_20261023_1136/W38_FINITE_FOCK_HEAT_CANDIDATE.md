# Higher-moment closure for finite-Fock quantum heated inputs

23 October 2026, W38. NEW GENERALIZATION CANDIDATE, fresh criticism pending.
The cubic candidate c6ad8e31... is preserved as the simpler special case.
The general UNHEATED independent-input amplifier EPnI is not established.

## 1. Proposed theorem and dependencies

Fix any finite n, G>1 and independent positive states rho_A0,rho_B0 with
finite joint Fock support. Require zero first moments, zero anomalous
second moments and occupations a I_n,b I_n, with a,b>0, exactly as V1 of
HEATED_FINITE_FOCK_QUANTUM_CUBIC_CANDIDATE.md. No nonzero cubic condition is
needed. Arbitrary coherences and internal entanglement are allowed subject
to these explicit covariance conditions.

For the ACTUAL heated inputs H_T^n(rho_A0),H_T^n(rho_B0), exact amplifier
EPnI holds for all sufficiently large finite T, with a positive entropy
gap of order T^-m, where m>=3 is the first unmatched Gaussian moment order
of the two original sources. Source,n,G are fixed before T grows. The
threshold and gap constants are source dependent. This is a changed-input
theorem, not a T->0 argument or a claim uniform over arbitrary finite energy.

Dependencies are the exact matrix-unit heat formulas V4,V5 and finite signed
polynomial output representation V6,V7 in the preserved cubic candidate;
the sharpened homogeneous BKM gap in the frozen quantum/heat notes; the
signed global third-moment entropy lemma; and the already displayed scalar
Hessian bound. The only new load-bearing step is the all-orders finite-band
cancellation below. No hypercontractivity, Gaussian CMOE or quantum L3 DPI
is imported.

## 2. First unmatched moment is a finite integer

For a fixed finite-support Hermitian trace-one operator sigma with thermal
covariance x I_n,x>0, its Weyl characteristic is exp(-|z|²/2)P(z,zbar),
where P is a finite polynomial. Compare with tau_x^n. The analytic function

    exp(x|z|²)P(z,zbar)-1

is not identically zero: a nonconstant positive-temperature exponential
cannot equal a finite polynomial. Let M be its smallest nonzero real
Taylor degree. The covariance hypotheses give M>=3. Equivalently all
Weyl-ordered moments of degree <M agree with the thermal state, and some
Hermitian degree-M moment differs. Normal-ordered moments have the same
property because their ordering corrections have lower degree. This
equivalence also follows directly from the normally ordered characteristic
function. The signed finite output operator used later need only match up
to a specified finite degree; positivity is not used in this algebra.

## 3. General finite-band lemma

Suppose sigma matches tau_x^n in EVERY moment of degree <M, M>=3.
Define F_t relative to H_t^n(sigma) and tau_(t+x)^n as in the cubic note.
For finitely many vector-charge bands D there are constants C,P,t_1 such
that

    |(F_t)_(m,m+D)|<=C t^(-M/2)(1+sum_j m_j/t)^P,            (W1)

for all t>=t_1 and every allowed m. Consequently

    Tr tau F_t²=O(t^-M),
    Tr tau F_t⁴=O(t^(-2M)),
    Tr tau|F_t|³=O(t^(-3M/2)).                              (W2)

Here is an all-orders proof of the cancellation, retaining the coefficient
argument rather than guessing a central-limit expansion. In one positive
charge d>=0, put epsilon=1/t,u=m/t. Formula V5 factors into

    R^m q_c^(-d/2) epsilon^(d/2)
      sqrt[product_(s=1)^d(u+s epsilon)]
      *sum_k sigma_(k,k+d) B_(k,d)(epsilon,u),

where R=t(t+x+1)/[(t+1)(t+x)], c=t+x, and the FINITE k sum has

    B_(k,d)=w_(k,d)[1+(x+1)epsilon](1+epsilon)^(-k-d-1)
       *sum_(v=0)^k binom(k,v) d!/(d+v)!
                    epsilon^v product_(s=0)^(v-1)(u-s epsilon),
    w_(k,d)=sqrt[(k+d)!/k!]/d!.                            (W3)

For EVERY r, the coefficient of epsilon^r in B_(k,d)/w_(k,d) is a
polynomial in k of degree at most r, with polynomial coefficients in u.
To verify this, the v term carries epsilon^v. A further power epsilon^j
from its falling product and epsilon^(r-v-j) from (1+epsilon)^(-k-d-1)
has k-degree at most v+(r-v-j)<=r. The extra linear prefactor does not
increase this degree. This is a finite coefficient calculation for each r.

The corresponding weighted k moments are exactly normally ordered moments:

    sum_k sigma_(k,k+d) w_(k,d)(k)_s
                =Tr[sigma (a^dagger)^(s+d)a^s]/d!.          (W4)

Thus each coefficient of order r is determined by moments of degrees
<=d+2r. Every such coefficient vanishes when d>0 and d+2r<M, because
the thermal comparison has zero nonzero-charge moments. No square-root
factor at u=0 is expanded; it is common to the whole band and bounded by
a polynomial. Taylor's finite remainder applied only to W3 therefore
gives order epsilon^(d/2+ceil((M-d)/2)) for d<M, at least M/2, and direct
power counting suffices for d>=M. All remainders are bounded by a fixed
polynomial in u because the k sum is finite and the denominators stay
away from zero for epsilon in a fixed positive compact interval.

For D=0 subtracting the identity requires the diagonal thermal comparison,
not zero nonzero-charge moments. The coefficient of epsilon^r is a
polynomial in k of degree <=r, so equality of all moments below M matches
it to the thermal coefficient whenever 2r<M. That comparison is exact:

    sum_(k>=0) P_x(k) B_(k,0)(epsilon,u)=R^(-m).             (W5)

For completeness sum the binomial coefficient in W3 using
sum_(k>=v) z^k binom(k,v)=z^v/(1-z)^(v+1). The remaining falling-factorial
series is (1+y)^m with y=x epsilon²/[1+(x+1)epsilon], and its prefactor
is one. Since R=1/(1+y), W5 follows. Finite-order coefficient extraction
is justified by the geometric k tail and its finite polynomial moments;
alternatively this binomial identity is analytic for sufficiently small
epsilon and fixed bounded u, then its coefficients are polynomials in u.

The matched coefficients force all terms of R^m sum sigma_(k,k)B_(k,0)-1
below epsilon^ceil(M/2) to vanish. The remainder bound is uniform for
unbounded u too. Indeed

    R^m=exp[u f(epsilon)],
    f(epsilon)=log R(epsilon)/epsilon,

extends analytically at zero, is nonpositive on the positive interval,
and has all finite derivatives bounded there. Its r-th derivative is
exp[u f] times a fixed-degree polynomial in u with bounded coefficients,
so is bounded by a polynomial for ALL u>=0. Multiplying by the finite
W3 sum and Taylor's integral remainder proves W1 on the diagonal band.

For finite n use products of W3. A coefficient of total order r is a
multivariate polynomial of total k-degree <=r, hence by W4 a combination
of moments of degree <=|D|_1+2r. Negative native charges are handled by
adjoint and a fixed index shift; the matching normal moment has that
orientation. The D=0 thermal sum factors and R^(sum m_j) has the same
nonpositive exponential argument with u=sum m_j/t. The identical Taylor
argument proves W1. This supplies all modes and all vector-charge sectors,
not merely a scalar radial expansion.

Finally W2 follows exactly as for V3: finitely many bands, uniformly
bounded scaled thermal polynomial moments, absolute four-step path sums,
then spectral Cauchy-Schwarz. No weighted quantum Lp triangle or arbitrary
L3 contraction is required.

## 4. Matching BKM scale and the output moment order

Let M_A,M_B be the finite first unmatched orders of the two positive
sources, and m=min(M_A,M_B). A Hermitian Weyl-ordered degree-M_i observable
O witnesses a nonzero initial difference mu against the matching thermal.
Heat's adjoint changes O only by lower-degree terms, whose differences
vanish. Thus the ACTUAL difference Tr[(rho_i(T)-tau_(x_i+T))O] is mu at
every T. Dual BKM Cauchy-Schwarz and logarithmic mean<=arithmetic mean give

    Q_i(T)>=|mu|²/Tr[tau_(x_i+T)(O-<O>)²]>=c_i T^(-M_i).

W2 gives the matching upper Q_i<=Tr tau F_i²=O(T^(-M_i)). Consequently
W=eta_A Q_A+eta_B Q_B is of order T^-m, since both eta limits are positive.

The signed finite sigma_C from V6 matches tau_(Ga+(G-1)b) through every
degree <m. To see this directly, its relative characteristic is the product
of the two relative input characteristics after the amplifier's linear
substitutions. A product of 1+O(|z|^M_A) and 1+O(|z|^M_B) differs from
one only from degree m onward. Therefore W1,W2 apply to the actual output
with this order m and its noise time (2G-1)T+(G-1). Its M3 is
O(T^(-3m/2)), even if its leading degree-m coefficient cancels.

## 5. Exact eventual EPnI follows

The high-temperature homogeneous BKM contraction still has a fixed positive
gap delta_0>0 after removing degrees0,1,2. Petz chi² and metric DPI bound
the bilinear term by the PRODUCT of the two relative second moments:

    Q_C(Z)<=P_A P_B=O(T^(-M_A-M_B)).

As W is of order T^-m, the BKM triangle gives

    Q_C(actual deviation)<=(1-delta_0)W+O(T^(-3m/2)).

The actual states are uniformly bounded above by constant multiples of
their thermal references, inherited from the finite-support source bounds
and CP positivity. The global signed third-moment entropy remainder is
therefore valid and W2 gives

    eta_A D_A+eta_B D_B-D_C>=delta_0 W/2-O(T^(-3m/2)).

The exact energy identities and entropy-target Taylor formula now leave
only O(W²/n)=O(T^(-2m)) curvature. Both errors are o(W). Thus for every
sufficiently large finite T the EPnI entropy gap is at least c T^-m>0.

All quantifiers retain fixed source,n,G before the high-noise limit. The
general theorem still assumes isotropic thermal covariance and finite
Fock support before heat; neither heavy tails nor arbitrary covariance
pairs nor the UNHEATED inequality is obtained by a hidden limiting step.
The all-orders coefficient cancellation W3-W5 is the precise new target
for fresh adversarial reconstruction. Priority and physical utility remain
UNKNOWN; no apparatus or outreach has been used.
