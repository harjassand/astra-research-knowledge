# Fresh review of the finite bounded-sign compiler transfer

23 October 2026. W67 read W66's complete frozen
`BOUNDED_SIGN_POLYNOMIAL_COSTS.md`, SHA256
`f3f70871fd56973489bf2c5931887bef64d08e46cecbb9554a995196fe7c2b00`,
and the separate implementation clarification, SHA256
`54bcb433a03245c648c87839217bf5b1be29f558f865a9abc82c6293102cfcde`.
Earlier proof/receipt bytes are preserved. This review binds BOTH files.

**No blocking defect found under the unchanged source, universal receiver,
native compiler and finite gate-model premises.**

The all-interval approximation is analytic; finite diagnostics alone are
not its proof. The source, physical horizon, rate, random-code seed/event,
and normal-initializer promises are unchanged. This is an adoption of
established approximation theory with explicit sufficient constants.

## Analytic reconstruction

For rho=1+1/(4k), every ellipse/annulus point has
|Im[k(w+w^-1)/2]|<1/4. The tanh poles lie outside this region, and its
displayed modulus identity bounds tanh by1 there. Laurent Cauchy bounds
are consequently rho^-|j|; reciprocity, real conjugation and oddness
give real symmetric coefficients with even indices zero. The omitted
Chebyshev tail is exactly bounded by8k rho^-n. The integer n>=5kb and
ln rho>=1/(5k) turn this into the stated dyadic eps/2 bound. Separately,
k g>=a/2 gives the correct positive-side tanh error eps/2. Thus the
scaled polynomial is bounded by1-delta/2 on ALL[-1,1] and approximates
sign above the retained gap. It is not merely a sampled pointwise fit.

For the finite DFT, J_c>2n prevents retained-frequency collisions.
Absolute Laurent convergence justifies its alias identity. Summing
rho-bounded alias tails gives the claimed delta/32 l1 contribution.
All numerical targets are real/bounded. Cosine error is divided by k;
real tanh is1-Lipschitz and its saturated evaluation never requires an
exp(k)-bit integer. Range reduction and rational Taylor/interval
arithmetic with guard bits give polynomial classical computation.
The selected B_eval is an output-accuracy target, as the clarification
states, not an assertion of that many bits for every internal register.

The clarification also makes the input to Haah literal: scale by the
known rational factor FIRST, project real reciprocal odd parity, and
then round ONCE to dyadic coefficients. The existing delta/128 final
rounding term therefore covers the actual compiler input. Symmetry
projection is l1-nonexpansive relative to the symmetric odd target;
round symmetric partners consistently. Alias, arithmetic and final
rounding total7delta/128<delta/8. Strict boundedness survives, and the
finite input has the required parity. No coefficient oracle remains.

## Complete signal map and costs

The earlier Hermitian-dilation walk identity applies to this odd bounded
polynomial unchanged. Its sign target maps left singular vectors back
to their right partners. The finite-input error and Haah delta/240
request fit inside the same5delta/4 signal-error allowance. Full vector
error, including signal leakage, is at most sqrt(5delta/2)<xi/2.
The same ordinary walk/inverse primitive pairing gives Q_new=4n+4;
there is no fractional walk or success-conditioned recovery.

Applying the already reviewed shared right factor gives I_new=Q_new+1.
Every native encoder use, controlled phase, digital helper and inverse
enters its full-unitary telescope. Since n=O(m z^-1 polylog(m/z)), the
stated complete quantum O(m^5 z^-1 polylog(m/z)) envelope follows.
The old majority and shared-encoder upper bounds remain valid looser
choices. Applying the SAME improved Q to BHH is correctly required in
the comparison. The short-BHH seed refinement is a separate packet;
it is not silently imported here.

Naive finite-coefficient DFT acquisition costs O(n J_c) bounded
arithmetic operations with polynomial logarithmic precision work.
It fits below Haah's separate O(n^3 polylog(n/delta)) phase bit cost.
The stated O(m^3 z^-3 polylog(m/z)) is PHASE preprocessing only.
Total classical construction must also pay seed generation/storage and
emission of the native circuit, including its own output length. The
proof explicitly retains those costs; it does not label all classical
construction cubic. Fixed native compiler constants and digital/log
factors remain symbolic, and no hardware architecture is specified.

## Independent exact finite cost reconstruction

Our no-import checker freshly reconstructs26 formula values per case
(156 total), and checks30 retained physical/source/error/seed values.
It also checks the ellipse-height rational inequality, dyadic tail and
alias envelopes, strict rational scaling, output-evaluation precision
and native error allocations. All six rows pass. Own raw output
`COUNT_RECONSTRUCTION.json` has SHA256
`b24227ece0f1f7ec6d18f1f7fb3733c5ef8a282aa7d038a385598a3851ccd198`.
It binds W66's frozen cost data SHA256
`1916743d4c7438b0b31537aec078f1368de68708b7b888514d2d750c0ac77a4d`.
New degree bit lengths119,128,136,144,152,160 and repeated controlled
Clifford count bit lengths464,509,549,589,629,669 all match.

These are conditional scalar-count checks. This reviewer did not acquire
any huge coefficient list, QSP phase sequence, type rank, code seed or
physical data. W66's moderate floating coefficient arrays are not
interval-certified uniform suprema and were not needed as a proof.

## Priority and retained boundaries

[Gilyen--Su--Low--Wiebe, 1806.01838, Lemma25 and Theorem26](https://arxiv.org/pdf/1806.01838)
were directly reread in the primary PDF. They already provide efficient
bounded odd sign approximation with the stronger asymptotic degree
O(g^-1 log(1/error)) and generic singular-vector recovery. Thus no new
generic approximation or optimal-query claim follows here. The explicit
tanh/Cauchy/finite-DFT construction is a sufficient ordinary implementation
with its retained extra logarithm and complete finite error budget.

The result still assumes the exact known coherent interaction family,
one fixed unknown gain in a supplied public band, static sectors,
input/bath independence and paid actual initial/terminal zero calls.
It is not an arbitrary unknown-channel or time-varying-error compiler.
Normal initial states retain pointwise tails. Actual calibration,
fault-tolerant geometry, coherence, clocks, energy, useful performance,
good-seed recognition and device-composition priority are unresolved.

Internal transfer: SCOPED_REVIEW_NO_BLOCKER_FOUND. Generic ingredients
PRIOR. Device-composition priority UNKNOWN. Computational/practical
advantage NOT_ESTABLISHED. Physical validation NOT_PERFORMED. Mission
NOT_ACHIEVED.
