# Fresh full audit of the affine three-action Laplacian construction

23 October 2026. Reviewer W62. **PASS: no fatal mathematical gap found in the
frozen candidate under the exact contract below.** This is an independent
analytic audit with exact finite diagnostics, not a formal proof assistant
verification, external acceptance, novelty finding, or physical experiment.

Reviewed candidate: W15 `laplacian_q3/AFFINE_THREE_PATTERN.md`, SHA256
`89d0c831476be21655d1929e7576b13738a5a5b184e6d92e333109acf63292c1`.
Its two proof dependencies were read and reconstructed, not inherited on
their prior audit status:

* `PROOF_UNIVERSAL_Q4.md`, SHA256
  `862560084687db0b43c20fec0c862bb42fc50d52c776c2c49dc095afab2ddbad`;
* `LLL_45BIT_SUPPLEMENT.md`, SHA256
  `5d833867f69a1509f9558c5f60015697854982795b9533e504f42ca806dfb6c7`.

All three current owner files were byte-compared to this review's received
copies after the checks. Pinned Astra HEAD was independently read as
`e606bfc587c76bdcae8b8fa3ec33e721efa2fbac`. No producer source was edited.
W29's parallel positive interface audit was received during this work; it
does not supply the reasoning or diagnostics below.

## Exact surviving statement

For every finite **known simple support** G with treewidth at most two and
maximum degree at most four, there is a graph-adapted rational n-by-3 matrix P,
with every actual whole row norm below one, for which every signed supported
conservative Laplacian satisfies

    ||L||F <= C ||LP||F,
    Q = 400*2^36 = 27487790694400,
    C = 283115520 Q^56,     log10 C = 761.0437944503906.

The actual acquired data are all **3n original cells** of Y=LP+E, with
arbitrary absolute Frobenius noise E. Canonical global least squares on the
original edge weights, with incident-sum diagonals, gives

    ||Lhat-L||op <= ||Lhat-L||F <= C ||E||F.

The fourth coordinate used in the proof is a computed lift. No fourth action,
independent fourth noise channel, noiseless row, transformed observation
oracle, known edge coefficient, or special decoder is supplied. Disconnected
graphs and isolates are covered. Positivity of a true baseline is compatible
with signed differences; the LS output itself is not asserted positive.

This is an all-size conditioning theorem with a very poor uniform constant,
not a useful precision guarantee. The native finite certificates below do
not improve its universal C.

## 1. The affine restriction really preserves the polynomials

Let H={x in R4:1^T x=s}, s=199/200. The map taking a row's first three
coordinates is an affine bijection H -> R3. Because s is nonzero, linear
independence of r lifted H rows is equivalent to affine independence of their
R3 points. In particular a four-row determinant is a nonzero polynomial: take
any tetrahedron in R3. For r<=3, the first r coordinates give a nonzero
maximal minor polynomial by free choice of those coordinates.

There is one harmless wording omission in the candidate: its sentence
"lower-degree ... r=degree+1<=3" omits degree-three vertices, whose r=4 minor
is needed. The preceding four-row determinant argument already proves that
case. W15 explicitly acknowledged the interpretation: degree three uses the
four-row determinant; degree at most two uses the first r<=3 columns. The
frozen proof bytes were preserved. My exact graph includes a degree-three
vertex, and checks its four-row event.

For an induced all-degree-four cycle C=(v_i), define the external pair
A_i=N(v_i) minus {v_(i-1),v_(i+1)}. Each numerator minor of its circuit-product
holonomy uses M_i={v_i,v_(i-1)} union A_i. Among denominator minors, the only
one containing those same two cycle vertices is indexed i-1. Therefore M_i
appears in the denominator product exactly when A_i=A_(i-1). If all pairs
were equal, a common outside vertex adjacent to all of C, after contracting
C to a triangle, would give a K4 minor. This is excluded by treewidth two.
Some numerator four-set M is consequently absent from all denominator sets.

Choose the four R3 points of M coplanar with every triple noncollinear. Their
lifted determinant vanishes and every lifted triple remains independent.
Every denominator set is different from M and therefore contains at most
three of its constrained points. Each such set can individually be completed
to an affine tetrahedron by its remaining free point variables. Its determinant
is thus a nonzero polynomial in those variables. The polynomial ring in the
shared remaining vertex variables has no zero divisors, so the product of
all denominator determinants is nonzero, and a simultaneous generic choice
exists. The numerator product is zero and the denominator product nonzero.
The holonomy is nonidentically zero **on H**.

This proves the new restriction step. Neither unrestricted four-dimensional
genericity nor independence of repeated outside neighbors was assumed. The
specialization need not satisfy row caps or sit in a small color box: it proves
polynomial nonidentity on H. The actual color-dependent parameterization is
an invertible affine map from three independent variables to H, and therefore
preserves that nonidentity on each product box.

## 2. Positive grid, row budgets, and exact three-channel metric

Write M=2^36 to avoid confusing the grid size with a Laplacian. The chosen rows
are

    Xi_v = [398 M e_c + (m1,m2,m3,-m1-m2-m3)]/(400 M),
    1 <= m1,m2,m3 <= M independently at every vertex.

For c<=3, the crude squared norm bound is
(399^2+1+1+9)/400^2<1. For c=4 the fourth numerator is positive and at most
398 M, giving the bound (398^2+3)/400^2<1. All rows have sum s. Their distance
from e_c is at most sqrt(28)/400<1/50. **Positivity of the grid matters** to
the c=4 estimate; a symmetric signed grid is not silently interchangeable.
I also checked all 32 corners of the larger continuous cube [0,M]^3 for
all four base colors using exact fractions. Convexity of each squared norm
extends those checks throughout that cube.

For the stated half-Hadamard T, direct multiplication gives
T^T T=I3 and TT^T=I4-11^T/4. Actual P=Xi T is rational and has row norm below
one. Its perturbation numerators are explicitly

    (m1+m2, m1+m3, -m2-m3),

plus the signed 199 M base numerators, all divided by Q. Thus no extra factor
two is needed in the common denominator: Q has exactly 45 binary digits.
There are at most 4*(2^36)^3=2^110 palette rows, independent of n; the palette
need not be expanded as a table.

For any conservative L, (LXi)1=L(s1)=0. Hence

    LXi = LP T^T,      ||LXi||F=||LP||F.

For arbitrary actual three-channel noise, ||ET^T||F=||E||F as well. The
computed lift's four entries are correlated; the proof never acquires them
as extra independent observations. Projection of a generic unrestricted
four-channel design would lose action norm; the constant affine row sum is
the essential hypothesis, not a cosmetic coordinate choice.

## 3. Local Lemma and finite precision are uniform, not just generic

Each bad rank or holonomy polynomial, after the affine substitution, is
nonzero in the 3n independent integer variables. Total degrees are bounded
by 4 and 52 respectively. The elementary polynomial root bound on a product
grid therefore gives p<=52/2^36. Grouping a row's three coordinates for
resampling is legitimate because different row groups are independent.

I recomputed every overlap constant. At most 25 rank events use a fixed row.
The number of cycles of length ell through a fixed vertex is at most
4*3^(ell-2), by counting nonbacktracking initial paths and requiring closure.
A cycle event can use a row only if a vertex of that row's closed neighborhood
lies on the cycle. Thus

    U = 25 + 5 sum_(ell=3)^13 4*3^(ell-2) = 5314405,
    D+1 <= 39 U = 207261795,
    4p(D+1) <= 43110453360/68719476736 < 1.

An event uses at most 39 row groups. The symmetric LLL criterion holds with
x=1/(D+1), and the standard variable-model resampling theorem applies. It
gives an assignment avoiding all events, and expected O(n) local resamplings
at these fixed but very large degree-dependent constants. This is not an
unconditional linear total preparation theorem: star coloring, event listing,
updates, exact arithmetic, matrix decoding, and outputs remain separate costs.

Nonzero maximal minors have magnitude at least Q^-4. The raw circuit
coefficients are determinants of unit rows and have magnitude at most one.
For an ell-cycle, nonzero product difference has denominator dividing Q^(4ell),
so its magnitude is at least Q^-52. These are actual quantitative separation
bounds, not an appeal to almost-sure injectivity of a finite generic sample.

## 4. Fresh reconstruction of the local-to-global inverse

Every local closed-neighborhood matrix has at most five unit rows and positive
singular values at least eta=1/(27 Q^4). A nonzero maximal minor bounds the
product of singular values from below; the remaining at most three values
are each below three. This also covers lower-degree vertices and isolates.

For any supported free-diagonal symmetric D, write its row as the local
minimum-norm solution R_i plus s_i k_i at degree four, and as R_i alone at
lower degree. Then ||R_i||<=eta^-1||(DXi)_i||. Symmetry on every original edge
gives

    k_i(j)s_i-k_j(i)s_j = R_ji-R_ij = q_ij,
    sum_(ij in F) q_ij^2 <= 2 sum_(i in V(F)) ||R_i||^2.

For an all-high selected short cycle, the ambiguity system is cyclic
bidiagonal, with determinant equal to its nonzero holonomy up to sign.
Its operator norm is at most two. At most 13 unknowns and the determinant
bound give inverse norm <=2^12 Q^52. If the selected cycle contains a
low-degree vertex, the high path to its first such vertex has at most 12
unknowns; its triangular determinant is a product of nonzero cofactors,
at least Q^-48. The same looser inverse bound applies. Raw circuit norms
are below three, so the stated safe local row constant is

    A = 2^15 eta^-1 Q^52 = 884736 Q^56.

Each vertex in S selects one short induced cycle containing it. A row can
belong to that witness only if its graph distance to the selected vertex
is at most six. The degree-four radius-six ball has at most
1+4(1+3+...+3^5)=1457 vertices. Summing squared row estimates therefore gives

    ||D_(S,all)||F <= C_S ||DXi||F,     C_S=A sqrt(1457).

For B=V minus S there is no cycle of length at most 13, since a shortest
cycle inside B would be induced in the original graph. G[B] is planar of
girth at least 14. A star-four coloring gives the selected-cell inverse
||H||F<=sqrt(2)||HZ||F on free-diagonal symmetric H: diagonals are read in
their own color, and each pair-color star edge is read in a leaf cell,
with all chosen cells distinct. Perturbing each row by less than 1/50 gives
coercivity beta=1/sqrt(2)-sqrt(5)/50, with beta^-1<2sqrt(2).

There are at most four cross-edge contributions per B row. Therefore
||D_BS Xi_S||F<=2||D_BS||F<=2 C_S||DXi||F. Subtracting these terms from the
**original B action rows** and using complement coercivity yields
||D_BB||F<=beta^-1(1+2C_S)||DXi||F. Finally

    ||D||F^2 <= ||D_BB||F^2+2||D_(S,all)||F^2.

The resulting constant is exactly
sqrt[2 C_S^2+beta^-2(1+2C_S)^2]. Since C_S>=2, it is bounded by
sqrt(52) C_S <320 A; 52*1457=75764<320^2. This verifies the candidate's
283115520 Q^56 sufficient constant. The argument has no separator-depth
amplification, no changing anchor oracle, and no uncharged reduced action.

## 5. Decoder, minimality, and scope of randomization

The forward inequality applies first to free-diagonal D measured against the
four-coordinate lift Xi. For conservative L it transfers isometrically to
actual P. The global LS decoder is over **original edge variables** and its
image is a linear subspace of R^(n by 3). Orthogonal projection of E into
that image has norm at most ||E||F. Applying the forward inverse to the LS
error proves the stated all-noise bound with C, with no extra factor two.
No unproved noisy local-subtraction algorithm is needed.

I separately read and analytically reconstructed W29's frozen all-design
two-action obstruction on G_n=P_n^2, SHA256
`936b0b0a6ffa0dadbea637d30aae5ccf752d9fdf4b079605b41d023d0774bddd`.
The actual row cap gives ||A_Z^T u||^2<=4 sum_edges||u_i-u_j||^2. If a
consecutive triangle is collinear, it has a stress kernel. Otherwise the
triangulated-chain elimination generates every balanced load. Choosing
u_i=(i-(n+1)/2)b with b parallel to sum_i(i-(n+1)/2)p_i makes it balanced.
Its squared norm is n(n^2-1)||b||^2/12 and its graph energy is
(5n-9)||b||^2. Cauchy-Schwarz with A_Zw=u gives the small singular witness;
||L(w)||F>=sqrt(2)||w|| and rank L<=n-1 give

    C_op >= sqrt[n(n+1)/(24(5n-9))] -> infinity.

The support really has treewidth two and maximum degree four. Thus three is
the minimum **uniform fixed-design, worst-case absolute-noise action count**
on this class, even for operator recovery. The same fixed-design lower
permits randomized decoders and uniform-after-seed sure statements. Its
forall-design/exists-witness order does not establish a private randomized
probe, per-fixed-unknown expected-loss minimax lower bound. W29's separate
scope clarification correctly excludes that stronger claim. A common-baseline
transcript also extends the obstruction to deterministic adaptive two-action
protocols under worst-case absolute noise. No private-random adaptive claim
is inferred here.

## 6. Exact checks, controls, and finite scope

`check_affine.py` is independently written and imports no producer code.
Its raw receipt is `RAW_AFFINE_CHECKS.json`. It builds a different 28-vertex,
31-edge graph: a high three-page book with pendants, attached to a 17-cycle.
It checks the S/B split, maximum degree, complement star property, all 48 rank
events including a degree-three row, and all three all-high short-cycle
holonomies. The deliberately equal initial grid has 35 bad events. Five
logged local resamplings repair them; the bad control is retained.

All actual row caps, constant row sums, denominator divisibility, and both
action/noise isometries are exact rational identities. The original 84-cell
three-action LS problem is solved exactly. Its normal gradient is zero.
The matrix 4096^2 A_P^T A_P-G_L is positive definite with all 31 exact LDL
pivots positive, certifying all edge weights and all noise for that finite
design. Smaller tested constants 1 through 2048 fail and are retained. This
does not imply a useful universal constant.

Four separate geometric specializations certify numerator zero and every
denominator nonzero inside H: the three shared-outside book triangles and
an all-high length-13 cycle. Each chosen four-set has every triple independent.
Two negative controls show why the new hypotheses matter: row-sum-zero H
forces four-row determinants to vanish; projecting an unrestricted q4 design
changes a two-vertex Laplacian action energy from 5/2 to 19/8.

`replay_native_data.py` independently reconstructs W15's supplied 36-vertex,
48-edge raw data after freezing it as `W15_NATIVE_DATA_received.json`. It
imports no producer source. It verifies a partial-two-tree fill order, actual
affine/grid form and row caps, all 108 original observation cells, exact LS
normal gradient, error/noise ratio, and lifted-noise isometry. It directly
recomputes all 48 positive rational LDL pivots of
16 N^T N-Q^2 G_L, where N=Q A_P. Thus the finite C=4 F/operator certificate
is independently confirmed. The failed C-squared trials 1,2,4,8 are retained.
The output rationals already exceed four thousand bits in this small exact
example; probe description precision is not decoder output precision.

These are synthetic finite algebra checks. No actions were physically
acquired. Only the analytic argument establishes the all-graph theorem.

## 7. Primary premises and cost boundary

Primary sources actually opened/read for this audit:

* Timmons, *Star coloring high girth planar graphs* (2008), Theorem 3.1 and
  Corollary 3.2: [primary PDF](https://www.combinatorics.org/ojs/index.php/eljc/article/download/v15i1r124/pdf).
  The girth-14 planar star-four statement supplies the complement premise.
* Moser and Tardos, *A constructive proof of the general Lovasz Local Lemma*,
  arXiv:0903.0544v3, Theorem 1.2 and the variable-event algorithm:
  [primary PDF](https://arxiv.org/pdf/0903.0544).
  Their per-event expected resampling bound supplies the claimed Las Vegas
  preparation statement after the explicitly checked LLL inequality.
* Bu et al., [primary manuscript](https://arxiv.org/pdf/2105.06641), Corollary
  3(i), independently gives the stronger girth-13 planar coloring statement;
  the construction uses only girth 14.

Raw retrievals are preserved locally. Firecrawl was attempted earlier in
this session and returned exhausted credits; it was not repeatedly retried.
The primary web fallback succeeded. These classical premises, standard
polynomial root counting, symmetry circuits, conservation projection, and
ordinary LS are not novelty claims. A full priority search for the combined
uniform q3 theorem has not been completed: historical novelty is UNKNOWN.

Supplied inputs: exact known G, promise of its graph class, actual linear
Laplacian action access, row-energy and absolute noise conventions. Unknown
support discovery, kinetic generator conversion, side information, physical
probes/readout/reset/calibration, measurement quantization, and useful target
instances are not acquired by this theorem.

All 3n action cells and all O(n) supported output entries are paid. Short-cycle
enumeration and LLL checking/updating have huge fixed constants. A guaranteed
star-four base-color preparation fallback can enumerate 4^|B| assignments;
no total O(n) implementation is asserted. Dense LS costs O(n^3) arithmetic and
O(n^2) storage, with rational bit growth separately charged. The optional
width-11 normal graph claim is sound **given** a width-two support decomposition:
expand each three-vertex bag into all incident original edges, at most 12;
an edge's bag subtree is the union of its endpoint subtrees, which intersect.
This covers all normal adjacencies and proves running intersection. Fixed
width permits O(n) arithmetic, not fixed word size or free decomposition.

The closest elementary matched control uses one additional action: a
distance-two coloring with at most 17 colors, a normalized four-dimensional
moment curve at those colors, and independent local four-chord inversion.
It gives a uniform q4 Laplacian bound even for arbitrary maximum-degree-four
supports. Thus q3 is a reduction in the exact worst-case action count; no
runtime, total acquisition cost, finite-noise, or physical advantage over
that equally informed control follows from the present huge C. Detailed
calibration and numerical-residual allowances are developed separately in
`COSTS_AND_BASELINE.md`.

## Status and next decisive work

Internal fresh full mathematical audit: PASS, with the degree-three wording
qualification above. Formal verification: NOT_PERFORMED. Historical novelty:
UNKNOWN. Physical validation: UNACQUIRED. Practical advantage: NOT_ESTABLISHED.
Mission: NOT_ACHIEVED. No public disclosure, outreach, purchase, or experiment
was performed.

The next load-bearing questions are quantitatively useful all-size designs,
the actual calibration/readout interface, and a matched total-cost comparison
against conventional q4 local recovery. Their answer is not supplied by a
45-bit palette or the positive finite receivers.
