# Controlling correction: the opposite-download uploader is stronger

23 October 2026. Root directed a full matched-incumbent reconstruction after our exact inverse packet. The construction below works and controls every BEST-UPLOAD cost comparison. All earlier frozen bytes are preserved: their inverse/factory algorithms remain valid sufficient constructions, but neither the recurrence nor the exact port-phase inverse is needed for the best uploader now identified.

Primary priority: Burgarth and Giovannetti, Full control by locally induced relaxation, Phys. Rev. Lett.99,100501(2007), https://arxiv.org/html/0704.3027 , final Uploading protocol section, equations12 and its surrounding argument, reopened in full today. Its opposite-H uploading mechanism is PRIOR. I had not previously carried that final mechanism through the native matched comparator; root identified this missed stronger incumbent. The native finite-depth/complete-channel/succinct-simulator details below are a source-bounded application, with special-case novelty UNKNOWN.

## O1. Use the adjoint ONLY in the explicit LOCAL simulator

Keep the known seed-X sector x, known root r_x, depth promise H, local word register F and T fresh local qutrits P from frozen c544c1a9... . Its finite compiled local involution U_H is unchanged. Define the opposite local unitary

    L_H=V_H*=alpha U_H-i beta I.

It is implemented by the same LOCAL eigenphase circuit with phases conjugated. No physical inverse is used. In the mathematical full native space write

    L_E=V_E*,
    W_-X=L_(P_T X)...L_(P_1 X),
    D_-X |psi>=W_-X(|0^T>_P |psi>_X).

The local W_-F exactly simulates this full native opposite VACUUM download on depth<=H: fresh vacuum never increases bath depth, so the arbitrary local colored-boundary completion is not reached. Word lengths can remain in coherent superposition throughout.

The opposite vacuum channel has Kraus operators

    K0-=alpha J-i beta I,
    Kj-=alpha S_j*, j=1,2.

Its root singleton phase is alpha x-i beta, of modulus one. At positive depth its survival probability is beta^2 and its pop probability is a=1-beta^2. Therefore its root-arrival EFFECT is exactly the same depth-diagonal effect:

    A_-* A_- >=(1-tau)I,
    A_-=(<r_x| tensor I_P)D_-,
    tau=Pr[Bin(T,a)<H].                            (O1)

This is an operator bound over all unknown reference-entangled F inputs, not a basis-average observation.

## O2. Its reverse is actual FORWARD physics, once per port

After applying W_-F locally, Alice sends the prepared qutrits through the physical device in the chronological order T,T-1,...,1. Each port is used ONCE with actual native V. The resulting physical operator is

    W_-E* = V_(P_1 E)...V_(P_T E).                  (O2)

The adjoint in this displayed mathematical name denotes the reverse of the fictitious opposite download; its actual gates are all forward native V. There is no negative-time operation, conjugation of the physical unknown gate, physical controlled V, Diophantine recurrence or composite inverse.

Bob can retain or discard each output port. It is never needed again, so there are ZERO quantum backward returns and ZERO feedback bits in this uploader. Discarding a past port commutes with all later operations on the other ports/bath and gives the same final reduced F,E channel. To state the stronger full-output isometry bound, simply retain all P at Bob.

Let J_- be this whole coherent isometry and S the target |psi>_F -> |r_x>_F |0^T>_P |psi>_E, with P now at Bob. Exactly the same bra-ket contraction gives

    S*J_-=A_-*A_-,
    ||J_--S||<=sqrt(2tau),
    ||channel(J_-)-channel(S)||_diamond<=2sqrt(2tau). (O3)

Root endpoint phases are included because BOTH the local opposite download and the mathematical D_- on the bra use alpha x-i beta. No independent root/pair phase adjustment is made. This checks the endpoint/order signs that could otherwise invalidate the short incumbent.

## O3. Actual costs and errors

Choose T=ceil max[2H/a,(8/a)ln(128/epsilon^2)] as in the frozen proof. The exact-root ideal channel error is at most epsilon/4. If the local compiled W_-F has operator error e_loc, add at most 2e_loc. An UNHALVED JOINT initial-root product error epsilon_root adds epsilon_root. If the local simulator uses a learned/rounded parameter beta_tilde with ||V(beta)-V(beta_tilde)||<=kappa, add at most 2T kappa. Hence

    total unhalved diamond error
       <=2sqrt(2tau)+2e_loc+2T kappa+epsilon_root.   (O4)

The physical count is EXACTLY T forward native calls. Backward quantum/classical communication needed by this uploader itself is ZERO. Local storage is O(H+T) up to encoding factors; local stack gate and phase precision costs remain the explicit T-step cost of the earlier proof. Unknown target-state preparation and Bob-register distribution still require their own local circuits/native calls. Initial reset and seed identification are still separate, pointwise in any old normal initializer.

At beta=0 this is valid with V=V*. At beta=1 there is no bath writing or opposite cooling, so the uploader fails. No uniform cost near that endpoint is inferred. An unresolved initial seed-sector superposition and old-purifier return remain outside the known-root theorem.

## O4. Consequences for the retained packets

The recurrence proof c544... and exact inverse proof06cf... are not falsified; their uploader cost claims are valid but dominated by (O2). The exact inverse remains a distinct acquired CONTROL capability on arbitrary states in a known sector, for applications requiring a gate inverse rather than just upload. No best-uploader advantage is assigned to it.

The matched uploader now has O_beta[H+ln(1/epsilon)+1] FORWARD calls with no backward wire. Its generic mechanism is inherited from the 2007 source. The actual additional finite statement is the native depth-binomial complete-channel bound and succinct local stack realization; whether even that special statement has distinct priority is UNKNOWN. No capacity gain, apparatus efficiency, autonomous scientific-learning capability or programme mission completion is promoted.

For unknown beta, UNKNOWN_BETA_CONTROL_ACQUISITION_V1.md remains a sufficient more elaborate algorithm, but inverse-pulse compilation is unnecessary in its final stage. Its Rabi observations and capped reference-restoring acquisition are unchanged; after calibration use (O2). Then replace its factory parameter-sensitivity term 2T(n_star+2)kappa by simply 2T kappa, and remove every factory quantum backward return. Rabi calibration still uses quantum returns to repeat the SAME probe; a slower first-flag Hoeffding calibration can instead use only classical feedback. Neither permission distinction is dropped.

Fresh new native diagnostics and a completed independent receipt remain separate obligations; no earlier audit is silently promoted to (O1)--(O4).
