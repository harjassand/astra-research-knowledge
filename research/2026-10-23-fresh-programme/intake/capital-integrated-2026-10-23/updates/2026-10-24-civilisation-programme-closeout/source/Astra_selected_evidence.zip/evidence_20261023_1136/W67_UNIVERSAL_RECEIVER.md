# A finite Fourier error span and a dimension-free polar receiver

W67, 23 October 2026. Independently developed candidate, frozen for fresh
criticism. Generic approximate KL recovery, row-polar recovery and QSVT
are PRIOR; no generic invention or physical implementation is claimed.
The core known-b type code has its separate completed scoped review.
This candidate concerns ONE FIXED unknown parameter in a supplied coarse
band, with the exact interaction FAMILY and digital gate model known.
It does not cover arbitrary unknown or time-varying interactions.

## 1. Fixed source, uniform flush, and the parameter family

Supply rational endpoints `0<b0<=b<=b1<=1/1024`. Build the explicit pair
source and pure type encoder C from b0. Its entropy surplus is at least
`g0=b0^2/384` and actual bulk drift is at most

    -kappa I, kappa=(1-b1)b0^2/240.

The frozen direct response proves this for the original recurrent device;
no physical rho copies or eigenbasis oracle is needed. The deterministic
parent type has actual width ell and average domination
`C(I_D/D)C*<=4(m+1)^9 rho0^m`, D=2^ell, with

    ell>=m(3+g0)-9log2(m+1)-18.

All selected codewords have the same physical total charge. Use the
worst-case rational Lyapunov constants `t=kappa/12,Ctail=18/(kappa*t)`.
Choose the body depth cutoff H so its mean parent overflow is at most q
uniformly in the band. The separate continuity-grid argument in
`../calibration_boundary/uniform_encoder/COARSE_BAND_UNIFORM_ENCODER.md`
gives, with a single high-design seed and its explicit finite guards,
body sector overflow<=514q uniformly in the continuum. Terminal zeros
chosen for the worst endpoint b1 add descent failure<=q. Thus the FULL
body-plus-flush isometry has nonvacuum word effect at most

    u=515q I                                             (F1)

in each static sector s and for every b in the band. The encoder is
common to the whole band; no receiver-to-sender fine-gain message occurs.

Keep the initial-zero-prefix argument separate. Conditional on ideal word
vacuum the construction below applies to both static sectors without
estimating either one. For an arbitrary normal initializer add exactly
the original initial-prefix term `4sqrt(q_A+nu_prefix)`. No uniform finite
tail over all normal states is assumed. The original input/initializer
independence and preserved static-sector/reference correlations remain.

## 2. A polynomial-size Fourier error span after the physical flush

Let T=2m+l be the number of body-plus-terminal-flush calls, and let
`theta=arcsin(sqrt(b))`. The known local involution in sector s satisfies

    V_(s,theta)=cos(theta)U_s+i sin(theta)I
               =U_s exp(i theta U_s).

Every matrix entry of its T-call digital unitary W_(s,theta) is a Laurent
polynomial in exp(i theta), with frequencies between -T and T. A finite
word stack of T cells and the known involutive boundary completion produce
the exact isometry from vacuum; no exponentially tabulated bath matrix is
used. Define the vacuum component on the PARENT logical space by

    K_(s,theta)=<vac_word| W_(s,theta)
                         (C tensor |0_flush> tensor |vac_word>).

It maps D parent dimensions into the retained output ports. Set J=2T+1,
`theta_j=2pi*j/J`, and for -T<=a<=T define

    E_(s,a)=(1/J) sum_(j=0)^(J-1) exp(-i a theta_j) K_(s,theta_j).

The full-circle digital angles are known compiler targets, including
angles outside the physical band. No physical query is made at them.
The exact finite Fourier identities give

    K_(s,theta)=sum_a exp(i a theta) E_(s,a),
    sum_a E_(s,a)^* E_(s,a)
       =(1/J)sum_j K_(s,theta_j)^* K_(s,theta_j)<=I.     (F2)

Each E_i is a contraction. Include both sectors, so r=2J operators.
For an actual fixed (s,theta), its coefficient vector c has J entries of
unit modulus in the s block and zero entries in the other block:

    ||c||^2=J<=r.                                     (F3)

This coefficient cost is essential; it is not silently normalized to one.
No final-bath basis of size exponential in H enters r: the omitted word
component is precisely the separately bounded physical error (F1).

## 3. Centered Hermitian high-design compression

Here is a self-contained finite moment lemma for all cross products.
Let B be Hermitian, `||B||<=1`, let `mu=Tr(B)/D`, and set C0=B-mu I.
Then `Tr C0=0,||C0||<=2`. For a Haar D-by-K frame V let
`Z=||V* C0 V||`, `c0=ln2-1/2`, and

    zeta=exp(2K ln9-c0 D), v0=2K ln9+ln2.

For independent standard complex Gaussian coordinates g, the exact mgf
and the zero trace give, for `|t|<=1/4`,

    log E exp(t g* C0 g)
       =sum_(j>=2) t^j Tr(C0^j)/j
       <=t^2 Tr(C0^2)<=4D t^2.

The series bound follows from
`|Tr C0^j|<=2^(j-2)Tr C0^2` and a geometric series. Chernoff with
`t=x/(8D)` yields `Pr(|g*C0g|>x)<=2exp[-x^2/(16D)]` for 0<=x<=2D.
The denominator event `||g||^2<D/2` has probability at most exp(-c0 D).
A one-quarter net of the complex K sphere has at most 9^(2K) points;
the Hermitian norm is at most twice the largest net quadratic form.
Consequently, on the relevant range 0<=z<=2,

    Pr(Z>z)<=2 exp(2K ln9-D z^2/256)+zeta.

Equivalently `Pr[Z^2>256(v0+x)/D]<=exp(-x)+zeta` for x>=0 (outside the
range the left side is zero). Integrate this tail before changing the
Haar distribution. Since Z^2<=4 and an exponential scalar X has
`(E X^h)^(1/h)<=h`,

    E_Haar Tr[(V* C0 V)^(2h)]
       <=K[256(v0+h)/D]^h+K 4^h zeta.                (F4)

For a DIAMOND-accurate 2h moment channel with error delta, the cyclic
trace identity transfers (F4) with additive error

    4^h delta K^(2h).                               (F5)

The two factors are explicit: `||C0^(tensor 2h)||<=4^h` and the trace
norm of the rank-K cyclic input is K^(2h). No net is transferred to a
low-order design. A 2h-moment diamond bound also gives every lower moment
bound with the same error by appending maximally mixed tensor factors
and tracing them out, which are complete trace-norm contractions.

Set q=K/D and tau=64sqrt(q). The following finite guards suffice for a
single B failure target eta0:

    q<=2^-12, h<=K,
    h>=ceil log2(4K/eta0),
    2K ln9<=c0D/2,
    c0D/2>=ln(4K/eta0)+h ln(4/tau^2),
    delta<=eta0/4 * [tau/(2K)]^(2h).                (F6)

Indeed v0+h<=8K, so the first Markov term is at most K*2^-h; the other
two terms are each at most eta0/4 by (F6). Thus centered compression is
at most tau except with probability eta0. Apply this to the Hermitian
real and imaginary parts of every E_i^*E_j, at most 2r^2 contractions.
No scalar mean or Gram matrix is acquired by the compiler. With their
union probability budget, one frame V has simultaneously

    ||V* E_i^* E_j V-G_ij I_K||<=128sqrt(q),
    G_ij=Tr(E_i^*E_j)/D.                            (F7)

The same seed also receives the separate overflow-grid union budget.
Take the maximum h and minimum delta required by all scalar guards.
All BHH width/length guards must be checked at moment order 2h; e.g. the
conservative width condition `ell>=4ceil(log2(8h))+4` is sufficient for
its logarithmic width requirement. The already audited finite-bit local
Haar compiler applies at order 2h, including its bounded random seed,
position rounding, inverse gate sequences and native precision costs.

## 4. A full block-KL bound with no logical-dimension loss

Define the row operator on coefficient label tensor logical message by

    F(|i> tensor |psi>)=E_i V|psi>, A=F*F,
    B0=G tensor I_K.

G is positive. The matrix of operator blocks in A-B0 has all block norms
at most `128sqrt(q)`, so elementary row/column sums give

    ||A-B0||<=omega:=128 r sqrt(q).                 (F8)

This is an OPERATOR norm on the full coefficient-times-logical space,
not a normalized trace distance or an unentangled-input bound.

For all positive operators X,Y,

    ||sqrt(X)-sqrt(Y)||<=sqrt(||X-Y||).             (F9)

For completeness, square root is operator monotone by its positive
resolvent integral. If `d=||X-Y||`, then `X<=Y+dI` gives
`sqrt(X)<=sqrt(Y+dI)<=sqrt(Y)+sqrt(d)I`; exchange X,Y for the other
order bound. Thus (F9) follows without commuting X and Y.

Let F=R sqrt(A) be the polar decomposition. Its partial inverse satisfies

    R*F=sqrt(A).

For ANY actual coefficient c in (F3), tensor any logical/reference input,
(F8)-(F9) give

    ||R*F(c tensor I)-(sqrt(G)c) tensor I||
       <=sqrt(r omega).                            (F10)

There is no K-dependent factor. The environment vector sqrt(G)c is the
same for every logical message. No claim from a state-weighted Petz bound
is imported here; the entire dimension-free implication is (F8)-(F10).

## 5. Spectral cutoff and a deterministic CPTP receiver

Direct polar inversion down to exponentially small singular values would
not be efficient. Choose a known nu>0. Let Q_hi select right singular
values of F at least sqrt(nu), and let Q_lo be its complement. Directly,

    ||F Q_lo(c tensor I)||<=sqrt(r nu),
    ||sqrt(A) Q_lo(c tensor I)||<=sqrt(r nu).       (F11)

This estimate is on the actual synthesis operator, so it requires neither
a Gram eigenbasis nor a trace bound on discarded Gram eigenvalues.

Compile a UNITARY singular-vector transformation that maps the high
left-singular subspace to its right-singular partner with FULL subspace
error xi. Its action on all other inputs is its ordinary unitary extension.
Then discard the coefficient register and clean/recovery work registers
to output the logical message. This defines a deterministic CPTP channel,
including every failure branch; no successful postselection is assumed.

On the actual good-word input F(c tensor psi), compare to the product
target `(sqrt(G)c) tensor psi` with known zero recovery flags. The high
part costs at most xi, since the actual good-word map is a contraction.
For the low part, the actual unitary output and target each have norm at
most sqrt(r nu); their difference costs at most twice that. Together,

    e_good<=sqrt(r omega)+2sqrt(r nu)+xi.            (F12)

Restoring the physical nonvacuum word part costs at most sqrt(u) in
isometry norm. The total product target environment may be unnormalized,
but its norm differs from one by at most e_good+sqrt(u), uniformly over
logical messages. Normalize this COMMON environment vector. The resulting
full-channel diamond error is at most

    4[e_good+sqrt(u)].                             (F13)

All norm comparisons remain true with an arbitrary logical reference.
Static-sector mixtures/reference correlations are allowed because the
same receiver works in both sectors and the physical process conserves
the seed-sector observable. Initial-word-prefix error is added separately.

## 6. Actual finite helper access and paid polar compilation

Every E_i has a known projected-unitary implementation. Prepare a uniform
J-index register, apply its known Fourier phase for frequency a, digitally
apply W_(s,theta_j) controlled by the index and sector, then unprepare the
index and project the DIGITAL word register to vacuum. Its top block is
exactly E_i, with normalization one. The uniform J state and its phases
can be synthesized by at most polynomially many explicit known rotations;
no unbounded random rejection or inaccessible physical projection occurs.
All projections here are the block-encoding algebra of a LOCAL unitary,
not permitted failure branches of the transmission protocol.

Coherently SELECT this implementation on i, and unprepare the coefficient
label onto its known uniform-r state. The resulting rectangular top block
is F/sqrt(r). The parent frame V is the explicitly stored design circuit
on the first-K coordinates, and C is the exact reversible type/basis
circuit. Their controlled versions and inverses are known local gates.
Input/output projections are known zero-register/valid-index tests, with
fixed reversible definitions on every invalid digital basis pattern.
All widths are polynomial in T and the parent logical width. No bath,
physical inverse, unknown gain, hidden gauge or Gram oracle is used.

The normalized retained singular gap is `sqrt(nu/r)`. Standard projected
singular-vector transformation therefore uses

    O(sqrt(r/nu) log(1/xi))

uses of this explicit local block unitary and inverse. Primary
[Gilyen--Su--Low--Wiebe, Theorem26](https://arxiv.org/pdf/1806.01838),
pp26--27, gives the constructive singular-vector circuit. To guarantee
FULL high-subspace error xi, make its projected polynomial error O(xi^2)
and include the unitary leakage amplitude; the logarithmic degree changes
only by a constant factor. A transition window below the retained cutoff
may be handled arbitrarily, as it is already paid in (F11).

If the singular transformation has degree L, synthesize every call to its
block unitary and every phase to operator error at most xi/(10L). A direct
unitary telescope charges all finite arithmetic, pi/angle evaluation,
known-angle digital simulation, controlled designs and native synthesis.
The inverse reverses finite gate sequences. This precision is polynomial
in its logarithmic input, because r and1/nu are polynomial resources.
There is no hidden condition number of an exponentially large output
density and no actual apparatus parameter estimation in this receiver.

## 7. Explicit small-error policy and eventual rate

For desired fixed vacuum-start error scale 0<z<=1, a safe sufficient choice
is

    q<=2^-48 z^4/r^4,
    nu=z^2/(2^16 r), xi<=z/128.                    (F14)

Then omega<=z^2/(2^17 r), and (F12) is less than z/32.
Also sqrt(u)<=32sqrt(q)<=z/2^19. The ideal bound (F13) is less than z/4,
leaving room for the charged native/parameter-grid arithmetic and initial
prefix allocations. The coefficient factor r has been retained throughout.

To avoid a circular choice of r and flush length, supply a tentative
upper bound Tbar=4m and use rbar=32m in (F14), choosing the dyadic loss

    s=48+4ceil(log2 rbar)+4ceil(log2(1/z)).

Compute H and terminal zeros from that s, and CHECK the finite guard
`T=2m+l<=Tbar`; otherwise enlarge m. All other moment/design/rate guards
must likewise be checked. For fixed band ratio b1/b0 and a fixed distance
from b=1, `s=O(log m+log(1/z))`,

    H,l=O[b0^-2(log m+log(1/b0)+log(1/z))].

The parent entropy bound therefore still pays a target rate at least
`3/2+b0^2/1536` at sufficiently large

    m=O[b0^-4 log(2/b0)]

for fixed target error at tau_pi, with every initial prefix, body and
terminal-zero call counted. Equivalently this is quartic gain and
O(beta0^-8 log(2/beta0)) sufficient calls, beta0=sqrt(b0). The previous
known-b numerical cases are NOT certificates of the new s/moment/grid
guards. No new giant code, native circuit or successful seed is executed.

The compiler is randomized with an explicitly allocated seed-failure
probability. It never certifies a particular successful seed. All local
compilation and gates remain polynomial in the horizon,1/b0,1/z and
charged input bit lengths, with huge constants and polynomial degree.
The SAME encoder and decoder depend on the public interval/family and
offline seed, and on neither the actual b nor the actual static sector.
Coarse-band acquisition and the physical realization/control family are
still supplied apparatus premises.

## 8. Prior art, precise status and falsifiers

Generic error-set universal/polar recovery is explicitly prior. The
primary [Elimelech--Albert--Barg paper](https://arxiv.org/html/2608.28962v1),
Section4, writes the error-synthesis row operator and polar/Petz decoder.
Primary [Gilyen et al2022](https://arxiv.org/html/2006.16924v2) constructs
Petz implementations with QSVT. Those results do not alone certify the
present dimension-free approximation or resource interface; that work is
spelled out above. Root separately found the still newer2610.20515 polar
formulation; I have not imported its theorem into this derivation.

The useful candidate claim is an explicit paid unknown-parameter receiver
for THIS flushed finite-Fourier recurrent family. Fresh criticism must
check: all-sector/parameter cross-KL concentration, the exact Fourier and
initial-vacuum promise, omission of no physical word component, coefficient
normalization, finite row block access, CPTP cutoff completion, full logical
reference error, and the complete finite rate/precision/compiler guards.
Time-varying parameters, an unmodelled control Hamiltonian, absent coarse
band knowledge, or analog gate errors outside their budgets invalidate
the contract. Quantum hardware acquisition and physical realization remain
unperformed. The ideal known-b code's completed review does not review this
extension.

Proof validity: INTERNALLY_DERIVED_CANDIDATE_PENDING_FRESH_CRITICISM.
Priority UNKNOWN; practical advantage NOT_ESTABLISHED; physical validation
NOT_PERFORMED; mission NOT_ACHIEVED.
