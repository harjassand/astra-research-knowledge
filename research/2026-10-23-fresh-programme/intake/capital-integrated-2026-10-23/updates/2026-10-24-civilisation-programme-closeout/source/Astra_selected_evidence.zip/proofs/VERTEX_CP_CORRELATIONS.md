# Vertexwise CP certificate and the cost of initial bath coherence

23 October 2026, w36. Version 2. **Internally reconstructed strengthening, pending fresh frozen-file critique.** Version 1 is preserved as `VERTEX_CP_CORRELATIONS_V1.md`, SHA256 `3d3ea63ec9bb7e2ce0fe03ac46c63a453255303a1508fbb1237c94b688f15956`. w49 identified its invalid identification of the full CP map with the extended scalar kernel on an individual non-symmetric distance function. Section 3 now explicitly distinguishes them; the physical iteration is used only on the invariant seed-symmetric class. The theorem and subsequent constants are unchanged. It preserves the exact device, fixed-N causal schedule, fresh logical input independent of the entire initial resource, arbitrary normal local memories/preshares and backward quantum messages, no extra bath access or Alice-to-Bob wire, and unconditional TP decoding. The generic tools are established; historical priority, external correctness and physical usefulness are UNKNOWN.

## 1. Claim: the CP exponent is uniform over every initial vertex

Let x=(seed,word) be ANY bath basis vertex, of any depth H. Let N_x denote the N-call chronological process from the pure bath state |x><x|. For every 1<=t<=sqrt2,

    N_x <=_CP V_N(t) R_{sigma_t^(tensor N)},                 (1)
    V_N(t)=2(N+1) h_b(t)^N,
    sigma_t=diag(1,t^-2,t^-2)/(1+2/t^2),
    h_b(t)=g_b(t)(1+2/t^2),
    g_b(t)=2sqrt2(1-b)t+b(1+2t^2),  b=beta^2.

This strengthens the initializer scope of the audited w49 global bound. It has the SAME exponent and, at t=sqrt2, the same 2(N+1) prefactor. For t<sqrt2 the original actual-tau_pi prefactor can be smaller. No initial depth or word content occurs in (1).

The interval t<=sqrt2 is essential to this new proof; the source's broader interval is not imported. The exponent minimum is already in [1,sqrt2], so this does not weaken the optimized capacity bound.

## 2. Seed symmetry supplies an exact two-point mixture

Let F|s,w>=|1-s,w>. It commutes with each bath block R,S_j,S_j^*, hence with U,V_beta and their N-call concatenation. Tracing the final bath therefore gives

    N_x=N_{Fx}=N_{sigma_x},
    sigma_x=(|x><x|+|Fx><Fx|)/2.                             (2)

This is exact equality of full chronological Choi operators, not an approximation, a mixture of controls, or an assumption that pure bath seed coherence vanishes. F is used mathematically; no bath control is supplied to Alice or Bob. The two vertices have the same depth H and sigma_x has purification rank two.

## 3. Positive transfer for the globally seed-symmetric diagonal class

For the weighted Choi bath transfer

    M_t(X)=sum_{i,o} t^(q_i+q_o) K_{oi} X K_{oi}^*,

the bath blocks are K_00=alpha R+i beta I, K_j0=alpha S_j^*, K_0j=alpha S_j, K_jj=i beta I. On a diagonal X invariant under F, its two root diagonal values coincide. The sole root interference term i alpha beta(XR-RX) is zero. The remaining push/pop/seed updates remain diagonal and F-invariant. Thus this is an actual invariant class containing sigma_x, even though sigma_x is not generally radial.

Define a positive SCALAR kernel on all nonnegative vertex functions by

    K_t=(1-b) A_t+b(1+2t^2) I.                             (3)

Here A_t has edge weight t on ordinary tree edges and 1 on the seed edge. On an F-invariant diagonal X=diag(f), the FULL CP map satisfies M_t(X)=diag(K_t f), and that class remains invariant. This identification is NOT asserted on a general diagonal operator: an unequal-root diagonal can create an offdiagonal seed commutator. If A is the ordinary adjacency of the entire 3-regular tree including that seed edge, then A_t<=t A entrywise for t>=1.

For a fixed center z, define f_z(y)=2^(-dist(z,y)/2). Directly,

    A f_z <=2sqrt2 f_z.

Away from z this is equality; at z, 3/sqrt2<=2sqrt2. These bounded functions need not be square summable. The pointwise finite-degree positive-SCALAR-kernel induction is sufficient. Thus K_t f_z<=g_b(t) f_z for each center z. The symmetric average Psi_x=(f_x+f_{Fx})/2 is F-invariant, dominates sigma_x's diagonal vector and obeys K_t Psi_x<=g_b(t)Psi_x. Since the actual initial diagonal vector and all its iterates are F-invariant, M_t^N(sigma_x)=diag(K_t^N sigma_x), and (3) gives

    [M_t^N sigma_x](y)
       <= (g_b(t)^N/2)[f_x(y)+f_{Fx}(y)].                  (4)

Every y of depth ell obeys dist(x,y),dist(Fx,y)>=|ell-H|. Consequently

    [M_t^N sigma_x](y) <=g_b(t)^N 2^(-|ell-H|/2).           (5)

This is the key difference from the original radial initial-depth supersolution: distance to each initial vertex retains the ABSOLUTE depth displacement and introduces no (t sqrt2)^H initializer weight.

## 4. Unnormalized charge-block Choi bound and both displacement signs

Use exactly the unnormalized Choi conventions and initial purifier bookkeeping of `QUADRATIC_AUDIT.md`. Because sigma_x commutes with bath depth L and the interaction conserves Q+L, the full J_x commutes with -Q_A^T+Q_B. Output charge pinching costs N+1 and yields mutually orthogonal q,o blocks J_{q,o}. An output block has final bath depth

    ell=H+q-o.

Purify sigma_x with an inaccessible rank-two F0 for this analytical representation. The block's J_{q,o} and joint E F0 Gram operator have the same nonzero eigenvalues. The finite-factor positive-block bound supplies the factor two, and the positive weighted bath sum gives

    ||J_{q,o}||_infinity
      <=2 t^(-q-o) sup_{L_y=H+q-o}[M_t^N sigma_x](y)
      <=2 g_b(t)^N t^(-q-o)2^(-|q-o|/2).                  (6)

No individual omega_{q,o} diagonality is assumed; it is positively dominated by the diagonal total M_t^N sigma_x, as in the audited proof. The initial rank-two factor has not been omitted.

For Delta=q-o, the scalar factor relative to t^(-2o) is

    t^(-Delta)2^(-|Delta|/2)
      = (t sqrt2)^(-Delta),       Delta>=0,
      = (t/sqrt2)^(-Delta),       Delta<0.

Both are <=1 precisely under the used conditions t>=1 and t<=sqrt2. Thus J_{q,o}<=2 g_b(t)^N t^(-2o) I_{A_q} tensor I_{B_o}. Summing orthogonal q sectors and pinching gives

    J_x <=2(N+1)g_b(t)^N I_A tensor B_t,
    B_t=sum_o t^(-2o)P_o,
    Tr B_t=(1+2/t^2)^N.                                    (7)

Normalize B_t and apply the Choi criterion. Equations (2) and (7) prove (1) for the original PURE vertex process. No bath depth limit, bath return, shell averaging, initial-tail deletion or accessible initial purifier is inserted.

## 5. Classical bath/laboratory correlations need no fixed marginal

The normalized-difference-comb argument in `FEEDBACK_EXTENSION_V2.md` applies to (1) at each x. Its comparison is a chronological normalized product replacer. Therefore every same-interface feedback strategy from |x><x| tensor omega_L has

    F_e <=min{1,V_N(t)/K^2},                                (8)

uniformly over x, all normalized laboratory resources and all legal strategies. It holds even if the initial vertex and laboratories' resource depend on N and the vertex is classically known to either laboratory.

For ANY normal classical-bath correlated initialization

    chi_EL=sum_x w_x |x><x| tensor omega_{L,x},
    w_x>=0, sum_x w_x=1,

the success probability is linear in chi. Apply (8) to each product branch and sum its actual weights. Hence the SAME one-shot bound (8) holds, with no assumption that its bath marginal is fixed in N or has a small depth/rank/entropy. There is no renormalized transcript sum. Classical stack information is already permitted in the arbitrary omega_{L,x}.

The classical-message version is P_correct<=min{1,V_N(t)/M} for M uniform messages under the same assistance and no extra forward wire.

## 6. A positive comparison prices quantum coherence by sum sqrt(p_x)

For an arbitrary normal eta_EL, let

    p_x=Tr[(|x><x| tensor I_L)eta],
    Z=sum_x sqrt(p_x).

The full bath marginal need NOT be diagonal. Suppose Z<infinity. Purify eta on E L G and decompose

    |Psi>=sum_{x:p_x>0} sqrt(p_x)|x>_E |a_x>_LG,
    ||a_x||=1.

The a_x need not be orthogonal; the whole vectors |x> tensor |a_x> are orthogonal because of the bath basis. Define normalized weights w_x=sqrt(p_x)/Z and the classical-bath density

    chi_ELG=sum_x w_x |x><x| tensor |a_x><a_x|.

Weighted Cauchy-Schwarz proves the exact positive operator order

    |Psi><Psi| <= Z^2 chi_ELG,                              (9)

since sum_x p_x/w_x=Z^2. Equivalently, for any vector v, square its overlap with Psi and apply Cauchy using weights w_x. The sum is absolutely controlled by finite Z; finite partial sums followed by the normal trace limit justify the countable case. Trace the INERT G to get

    eta_EL <= Z^2 chi_EL,                                   (10)

where chi_EL is a normalized classical-bath correlated state of Section 5. This is a mathematical comparison, not a filter, prepared resource, measured classical label or physical replacement of eta. It is the standard weighted-coherence domination mechanism, not a new generic Cauchy principle.

Apply the SAME physical strategy to (10). Initial fresh Phi_RM remains independent of both states. Positivity and (8) give the exact finite-N bound

    F_e(eta) <=min{1,Z^2 V_N(t)/K^2}.                       (11)

For uniform classical messages, P_correct<=min{1,Z^2 V_N(t)/M}. These bounds are uniform over all extensions of the same computational bath diagonal p_x; no laboratory dimension, conditional probability or purification rank occurs in Z.

For the actual tau_pi marginal,

    Z=sum_{H>=0}2^(H+1) sqrt((1/3)6^(-H))
      =2sqrt3+2sqrt2,
    Z^2=20+8sqrt6.

Thus every arbitrary normal initial bath/laboratory correlated extension with this marginal obeys

    F_e <=min{1,(20+8sqrt6) 2(N+1)h_b(t)^N/K^2}.            (12)

It retains the SAME exponential 2delta strong-converse slope as the product initializer, with a fixed explicit correlation penalty. This is stronger than the separately preserved hard-cutoff and Renyi bounds. Those remain valid; they are superseded quantitatively at this actual marginal. No new achievability or exact intermediate-beta capacity follows.

## 7. General normal marginals and varying resource budgets

When Z diverges, compress eta with a finite vertex projection P. Its compressed diagonal has Z_P=sum_{x in P}sqrt(p_x), and (9)-(10) hold UNNORMALIZED with coefficient Z_P^2 against a normalized classical comparison. In particular Z_P^2<=r Tr(P tau)<=r. Gentle projection then gives

    F_e(eta) <=min{1,Z_P^2 V_N(t)/K^2+2sqrt(Tr[(I-P)tau])}
              <=min{1,r V_N(t)/K^2+2sqrt(Tr[(I-P)tau])}.     (13)

For each fixed normal tau, the tail is uniform over all its extensions. Fix P, take N to infinity above the common threshold, then enlarge P. This proves the same strong-converse ceiling for every fixed normal marginal without finite entropy, finite Z or finite mean depth. It improves the previous cutoff's r c_P or r^2 factors to r and removes any depth dependence.

More generally, a horizon-dependent family has the same conclusion if supplied cutoffs P_N satisfy tail->0 and log2(Z_{P_N}^2)=o(N). In particular subexponential finite coordinate rank suffices REGARDLESS OF HOW DEEP those coordinates are. A finite global Z_N with log2 Z_N=o(N) gives the exact one-shot (11) and the same asymptotic threshold directly. This is an explicit initial-coherence resource condition, not free acquisition of an appropriate family. Arbitrary varying coherent marginals with extensive coherence are not claimed covered. Arbitrary CLASSICAL bath marginals are already covered without any condition by Section 5.

## 8. Status and physical boundary

The new critical certificate is Sections 2-4. The correlation comparison is a standard weighted positive-order consequence once the vertexwise coefficient is uniform. w17 and w49 independently reconstructed the algebra before this version was saved; the scalar-kernel correction above came from w49's frozen-file read. A fresh corrected hash-specific review is requested. Independent `vertex_cp_check.py` passed 128 vertex cases (N=1..4; initial depth0,1,3,20; beta0,.02,.4,1; t1,sqrt2), 1,728 direct charge-block bounds, eighteen nonradial seed-pair transfer/positive-kernel comparisons and twelve mixed/coherent bath/laboratory Cauchy comparisons. Maximum direct-kernel discrepancy1.33e-14, maximum normalization error1.70e-15. These are finite synthetic checks; they do not establish the all-N theorem, priority or physical implementation.

The generic coherence price is established: Napoli et al., [Robustness of coherence](https://arxiv.org/pdf/1601.03781), and Piani et al., [Robustness of asymmetry and coherence](https://arxiv.org/pdf/1601.03782), include the pure-state squared-sum amplitude formula. The block-purification comparison here is proved explicitly and no new generic coherence measure is claimed. The device-specific evaluated consequence remains historically UNKNOWN. Other prior tools include Choi order, deterministic-comb causality, pinching and positive graph supersolutions.

Initial resource acquisition, extensive coherent stack preparation, shared-purifier preparation, backward quantum bandwidth, control precision, energy, memory and reset remain costs in any construction. They are allowed ideal assistance only to strengthen an upper bound. All N forward calls count. No new bath control, free forward classical message, initial fresh-logical correlation or postselection is permitted. The full asymptotic ceiling is unchanged; exact capacity/coefficient for beta>0, efficient useful codes, physical implementation and mission success remain unresolved.
