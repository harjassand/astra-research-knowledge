# Arbitrary-resource quadratic bound from the incoming cut's correlation loss

Version 1. Independently developed by worker w64 after freezing its separate two-cut audit. All logarithms and entropies are in bits unless ln is displayed. This is a mathematical proof candidate, with novelty, external validation, physical implementation and optimality separate from the claimed inequality.

## Claim and protocol

Let 0<=beta<=1, b=beta^2, a=1-b. For the exact root-retaining tree device below, every admitted N-call protocol obeys

    I(R:Bob_final) <= N g(beta),                         (T1)
    g(beta)=min{2 log2 3, 3+(ln 2)b-(ln 2)b^2/2}.

If a trace-preserving decoder has unconditional K-dimensional Bell overlap F, then

    2 F log2 K-h2(F) <= N g(beta).                       (T2)

In particular, reliable fresh quantum transmission has rate

    Q <= min{log2 3, 3/2+(ln 2)beta^2/2-(ln 2)beta^4/4}. (T3)

The protocol starts from Phi_(R M) tensor eta_(E L_A L_B G), where R and M have dimension K<infinity, Alice owns M,L_A, Bob owns L_B, and G is inaccessible. Eta is an arbitrary normal state, may depend on N, may have infinite entropy and depth, and may entangle E and both laboratories without any separability restriction. The fresh R M state is independent of the ENTIRE eta. There are exactly N chronological, labeled qutrit calls A_t -> device -> B_t -> Bob. All local operations are normal and trace preserving when outcomes are included, and arbitrary quantum/classical backward communication from Bob to Alice is allowed. There is no additional forward classical or quantum wire, timing/selection carrier, direct bath access, or postselected renormalization. All failure branches count. The N calls are the only forward carriers.

The upper bound grants arbitrary initial entanglement without charging a cost. It therefore also applies when initial entanglement, its preparation, consumption, or borrowing must be charged. It does not provide a protocol that prepares or returns any resource. It does not establish equality, a strong converse, F tending to zero above the bound, or a physical memory realization.

## 1. Exact operator and the root term

The memory is E=C^2_seed tensor l2(binary words). Let S_j prepend color j and let J flip the root seed. With P0 the bath-root projector,

    S_i^*S_j=delta_ij I,  sum_j S_j S_j^*=I-P0,
    J=J^*, J^2=P0, J S_j=0, S_j^*J=0.

In qutrit port order 0,1,2, set

    U=[[J,S1,S2],[S1*,0,0],[S2*,0,0]],
    q=diag(0,1,1) tensor I_E,
    V=sqrt(a) U+i sqrt(b) I.

Direct multiplication gives U=U^*, U^2=I and

    U q U=|0><0| tensor(I-P0),
    U q U+q=I-P_root,
    P_root=|0><0| tensor P0.

Define the Hermitian bounded operator

    C=i(Uq-qU).

On each invariant pair (|0,S_j x>,|j,x>), U is Pauli X, q=diag(0,1), and C=[[0,i],[-i,0]]. On the two root-seed states C=0. Hence ||C||=1 and C has no port-diagonal blocks.

For an ACTUAL unconditional pre-call joint state rho_AE, let

    u=Tr(q rho_AE),  v=Tr(q V rho_AE V^*),
    r0=Tr(P_root rho_AE)>=0,
    c=Tr(C rho_AE),
    S_A=S(rho_A),  S_B=S(Tr_E[V rho_AE V^*]).

Expanding V^*qV gives

    V^*qV=a UqU+bq+sqrt(ab) C,
    u+v-1=b(2u-1)-a r0+sqrt(ab)c.                       (1)

No assumed product state or physical bath cutoff enters (1).

## 2. Two fixed cuts, retaining the first cut's slack

For the first mathematical cut, assign E and G permanently to the receiver side C_recv. Each A_t enters that side; V then acts locally there. The increment is

    I(R:C_recv A_t)-I(R:C_recv)
      =I(R:A_t|C_recv)
      =I(A_t:R C_recv)-I(A_t:C_recv)
      <=2 S(A_t)-I(A_t:C_recv)
      <=2 S(A_t)-I(A_t:E_t).                            (2)

Here E_t is the bath immediately before call t, and C_recv contains it. The first inequality is I(A:X)<=2S(A) for finite A; the second is data processing. Sender operations do not change the reference/receiver marginal; receiver operations cannot increase its mutual information; backward messages leave the receiver and cannot increase it. Initial I(R:C_recv)=0 by freshness, and final actual Bob is obtained by tracing out E and G. Therefore

    I(R:Bob_final)<=sum_t[2S(A_t)-I(A_t:E_t)].            (3)

This is an upper bound on an increment of REFERENCE information, not an initializer entanglement monotone or a claim that correlated ports have no communication ability. No negative increment is assumed: I(A:E)<=2S(A) makes every displayed allowance nonnegative.

For the separately fixed second cut, E and G stay on Alice's side throughout. Each device operation is local there, and only B_t enters Bob's side. The standard finite-port bound gives

    I(R:Bob_final)<=2 sum_t S(B_t).                      (4)

The cuts describe the SAME physical protocol under two distinct fixed partitions; E is not moved mid-protocol. Averaging (3) and (4),

    I(R:Bob_final)
      <=sum_t [S(A_t)+S(B_t)-I(A_t:E_t)/2].              (5)

This retained correlation loss is the ingredient absent from the earlier entropy-only bound linear in beta.

## 3. A finite relative-entropy budget controls the useful coherence

For 0<u<1 set

    sigma_u=diag(1-u,u/2,u/2),
    f(u)=h2(u)+u,
    d_A=f(u)-S_A=D_bits(rho_A||sigma_u)>=0,
    d_B=f(v)-S_B>=0,
    Jcorr=I(A:E)+d_A.

The relative-entropy chain identity is

    Jcorr=D_bits(rho_AE || sigma_u tensor rho_E).         (6)

It remains valid for arbitrary normal rho_E of infinite entropy. A has dimension three, so I(A:E)<=2 log2 3 and d_A is finite. The identity follows by replacing the first factor in rho_A tensor rho_E by sigma_u: the change in relative entropy is Tr rho_A(log2 rho_A-log2 sigma_u), a finite-dimensional quantity. It may equivalently be obtained from the generalized conditional entropy S(A|E)=S(A)-I(A:E). Thus (6) is not an infinity-minus-infinity entropy manipulation. At u=0 or u=1 restrict A to the support of sigma_u, on which rho_AE is supported; equivalently use endpoint limits. The identity and inequalities continue there.

Since sigma_u is port diagonal and C has zero port-diagonal blocks,

    Tr[C(sigma_u tensor rho_E)]=0.

Trace-norm duality and quantum Pinsker in bits imply

    |c|<=||rho_AE-sigma_u tensor rho_E||_1
        <=sqrt(2 ln(2) Jcorr).                          (7)

For clarity, (7) does not require a finite bath. For any two normal states rho,tau, let P be the positive spectral projector of the trace-class rho-tau. Their binary P-measurement probabilities p,q obey |p-q|=||rho-tau||_1/2. Relative-entropy data processing and the elementary binary bound

    D_nat(Ber(p)||Ber(q))>=2(p-q)^2

give D_bits(rho||tau)>=||rho-tau||_1^2/(2 ln2). The binary bound follows from the p-second derivative 1/[p(1-p)]>=4 and a Taylor integral at p=q. Boundary probabilities follow by limits. The Helstrom projector is a bounded measurement even in infinite dimension. This derives the exact normal-state version of Pinsker needed here.

## 4. The per-call entropy/correlation inequality

For each call, let I=I(A:E), Jcorr=I+d_A and x=u-1/2. By (1),

    S_A+S_B-I/2
      =h2(u)+h2(v)+u+v-d_A-d_B-I/2
      =h2(u)+h2(v)+1+b(2u-1)-a r0+sqrt(ab)c
         -Jcorr/2-d_A/2-d_B.

The binary-entropy curvature bound

    h2(u)<=1-(2/ln2)(u-1/2)^2

follows from h2''(u)=-1/[ln2 u(1-u)]<=-4/ln2. Also h2(v)<=1. Drop the nonpositive root and residual d_A,d_B terms and apply (7):

    S_A+S_B-I/2
      <=3+2b x-(2/ln2)x^2
           +sqrt(2ab ln2 Jcorr)-Jcorr/2.                (8)

The two elementary optimizations, over all real x and Jcorr>=0, are

    2b x-(2/ln2)x^2 <=(ln2)b^2/2,
    sqrt(2ab ln2 Jcorr)-Jcorr/2 <=ab ln2.

They are valid enlargements of the true parameter set; they do not assume these optimizing values can occur in a legal protocol. Hence

    S_A+S_B-I/2
      <=3+(ln2)b^2/2+ab ln2
      =3+(ln2)b-(ln2)b^2/2.                            (9)

Summing (9) in (5) gives the second entry of (T1). Separately, (3) implies I<=2N log2 3, yielding the displayed minimum. This proves (T1).

## 5. Finite error and reliable rate

After trace-preserving decoding to a K-dimensional L, the reference marginal is I_R/K. For K>=2 let F=<Phi_K|omega_RL|Phi_K>. Its Bell-test comparison probability under (I_R/K) tensor omega_L is exactly K^-2. Relative-entropy data processing gives

    I(R:L)>=D_bin(F||K^-2)
      =2F log2 K-h2(F)-(1-F)log2(1-K^-2)
      >=2F log2 K-h2(F).

Decoder data processing and (T1) prove (T2). K=1 is trivial. If F_N tends to one, division by 2NF_N gives (T3). The result is uniform over allowed N-dependent eta and strategies. A genuine excess c beta+o(beta) with c>0 is impossible in this contract: the arbitrary-resource upper excess is O(beta^2). This upper bound alone supplies neither a positive quadratic excess nor its optimal coefficient.

## 6. Normal strategies and causal edge cases

Use mutual information defined by relative entropy. Because R and each A_t,B_t are finite, all reference mutual informations and the finite-side quantities used above are finite. Generalized conditional entropy and the extended chain rule are valid for arbitrary normal states on the remaining systems; no finite depth, finite energy or finite bath entropy is imposed. The same statements cover classical outcome registers when they are represented by admitted normal registers/maps.

Every finite composition of normal local/device/backward maps is directly covered. If countably many local/backward operations are allowed between calls, require them to define a normal limiting strategy. Finite-round approximants converge in trace norm at the relevant call marginals. Finite-port conditional entropy is continuous with a dimension-three bound, so I(A:E) is continuous under these joint-state approximations even when E is infinite. Mutual information I(R:Bob) is lower semicontinuous. Consequently (3)-(5) and the uniform bound pass to such well-defined limits. Nonconvergent or nonnormal processes are not covered operational codes.

Giving the formal side containing E unlimited local control only enlarges the strategy class for the cut proof. Actual protocols do not receive bath access. Freshness rules out an initially transmitted logical reference; preshares are independent of R. Backward quantum communication, arbitrary initial E:labs entanglement, purification G, all measurement outcomes, and all failure branches are included. No initial entanglement accounting can evade this upper because the bound already grants it freely. An extra forward carrier, including publicly observable input-dependent timing/acceptance, would invalidate the contract and is excluded.

## 7. Provenance, costs and verification status

The exact device and base two-cut contract were supplied by the pinned source and earlier audit. The retained first-cut loss and the application of its entropy/correlation budget to the beta interference term were independently developed here before reading w19's positive-beta proposal. Parent independently reconstructed the one-cut calculation while this proof was written. Standard information inequalities are used as tools, not claimed as inventions. A later two-cut-loss improvement, if any, is a separate artifact and does not change the provenance of this frozen first proof.

This work consists of local reasoning and synthetic finite calculations, with no physical device calls, resource preparation, purchases or experimental resets. Finite checks will be recorded separately, including all executed cases and computation time. Complete reasoning/review costs and hardware energy are UNKNOWN. The comparison is a strictly stronger analytic upper bound for the same fully informed arbitrary-resource model, not a runtime or practical advantage claim. Independent criticism, precise prior-art review, sharpness/achievability, coefficient optimality and physical significance remain open. Programme mission NOT_ACHIEVED.

Primary information-theory sources checked:

- A. A. Kuznetsova, *Quantum conditional entropy for infinite-dimensional systems*, arXiv:1004.4519v2, definition (2), bound (5), proposition 1: https://arxiv.org/pdf/1004.4519
- M. E. Shirokov, *Tight continuity bounds for the quantum conditional mutual information, for the Holevo quantity and for capacities of quantum channels*, arXiv:1512.09047v7, section 3 equations (12)-(17), extended chain rule and finite-side bounds: https://arxiv.org/html/1512.09047v7
- E. A. Carlen, *A remainder term for Holder's inequality for matrices and quantum entropy inequalities*, arXiv:1605.04581, equation (2.2), natural-log Pinsker constant 1/2: https://arxiv.org/pdf/1605.04581
- P. E. Frenkel, *Integral formula for quantum relative entropy implies data processing inequality*, arXiv:2208.12194v4, section 7, the binary-measurement reduction attributed to Hiai, Ohya and Tsukada: https://arxiv.org/pdf/2208.12194

The proof above explicitly derives the normal-state Pinsker extension it uses. The new device-specific combination and its priority have not been exhaustively checked against the literature.
