"""Exact selected guards for a NEW compact-program paid-forward reuse route.

Uses the explicitly copied own block policy, not an independent audit.
No table, seed, phase/native list, physical prefix or message is executed.
All local synthesis/emission/operation costs remain additional paid costs.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import importlib.util
import json

HERE = Path(__file__).resolve().parent
POLICY = HERE/'reuse_block_policy.py'
POLICY_SHA = '0a720823c4127236f8beec4611fd2eea42c1e68a2f9af29a7739b054617e1d69'
assert hashlib.sha256(POLICY.read_bytes()).hexdigest() == POLICY_SHA
spec = importlib.util.spec_from_file_location('own_reuse_block_policy', POLICY)
policy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy)

Z, ETA = F(1,1000), F(1,100)


def one(beta_den):
    policy.ETA = ETA/2
    policy.ETAW = policy.ETA/32
    b0 = F(1,beta_den**2)
    assert 4*b0 <= F(1,16384)
    Binit = policy.clog2(F(2**24)/(Z*Z))
    Ainit = Binit+8
    ninit = 16*(Ainit+Binit+4)
    assert 16*(F(1,2**Ainit)+F(1,2**Binit)) <= (Z/32)**2
    power, tmin, retries, previous = 0, 1, 0, None
    while True:
        B = 1<<power
        policy.Z = Z/(8*B)
        try:
            row = policy.one(beta_den,t_min=tmin)
        except policy.NeedLargerMesoblock as need:
            tmin = 2*need.current_t
            retries += 1
            continue
        # Only irreproducible table output plus ideal recipe randomness
        # is sent. All phases/native lists are generated locally and paid.
        table = row['probability_table_output_bits_upper']
        seed = row['all_random_seed_bits_upper']
        L = 1+table+seed
        r = max(1,(policy.clog2(64*L/Z)+13)//14)
        boot = L*(1+r)
        p_fail = F(L,2**(14*r))
        assert p_fail <= Z/64
        N = ninit+boot+B*row['forward_total']
        logical = B*row['logical_width']
        target = F(3,2)+policy.G/(32*row['k'])
        assert target-F(3,2) >= 4*b0/952320
        margin = logical-target*N
        if margin >= 0:
            break
        previous = {'reuse_log2':power,'rate_margin':margin,
                    'program_bits':L,'block_calls':row['forward_total']}
        power += 1
    # Reuse proof requires the complete joint memory lemma. Its accurate
    # ideal-past/actual-future hybrid has this charged sum, not iid faults.
    joint_block_error = policy.Z
    reuse_error = B*joint_block_error
    assert reuse_error == Z/8
    bootstrap_instrument_steps = 16*boot
    one_instrument_error = Z/(1024*boot)
    bootstrap_native = bootstrap_instrument_steps*one_instrument_error
    assert bootstrap_native == Z/64
    total_error = Z/32+2*p_fail+bootstrap_native+reuse_error
    assert total_error <= 13*Z/64 < Z
    assert previous is None or previous['rate_margin'] < 0
    return {'reference_beta_denominator':beta_den,'k':row['k'],
            'repetitions_log2':power,'repetitions':B,
            'first_pass_in_exact_doubling_search':True,
            'earlier_failed_repetition_powers':power,
            'last_failed_guard':previous,'mesoblock_refinements':retries,
            'block_error_target':policy.Z,'block_program_failure_target':policy.ETA,
            'block_forward_calls':row['forward_total'],
            'block_logical_width':row['logical_width'],
            'table_bits_to_transmit':table,'ideal_seed_bits_to_transmit':seed,
            'compact_program_bits':L,'zeros_per_program_bit':r,
            'program_forward_calls':boot,'global_initial_cutoff':Ainit,
            'global_initial_forward_calls':ninit,'total_forward_calls':N,
            'total_logical_width':logical,'target_rate':target,
            'uniform_actual_b_rate_coefficient':F(1,952320),
            'exact_rate_margin_bits':margin,
            'program_capped_reset_failure_upper':p_fail,
            'bootstrap_joint_native_accuracy_bits':policy.clog2(1/one_instrument_error),
            'bootstrap_instrument_steps_upper':bootstrap_instrument_steps,
            'global_error_bound':total_error,
            'global_program_failure_target':ETA,
            'no_repetition_factor_on_same_program_good_event':True,
            'block_scalar_guards':row,
            'native_and_phase_lists_transmitted':False,
            'native_and_phase_work_paid_locally':True,
            'fault_model_assumption':'No iid/local-stochastic law; complete joint-vacuum comparison and ideal-past/actual-future hybrid required.'}


def serial(x):
    if isinstance(x,F):
        return str(x)
    raise TypeError(type(x))


def main():
    rows = [one(d) for d in [256,1024,4096]]
    data = {'status':'PASS_NEW_SELECTED_PAID_PROGRAM_GUARDS_PENDING_REVIEW',
            'scope':__doc__,'policy_sha256':POLICY_SHA,'rows':rows,
            'physical_status':'NOT_PERFORMED','practical_advantage':'NOT_ESTABLISHED',
            'mission':'NOT_ACHIEVED'}
    payload = json.dumps(data,default=serial,indent=2)+'\n'
    out = HERE/'PAID_PROGRAM_REUSE_GUARDS.json'
    if out.exists():
        assert out.read_text() == payload, 'refuse changed frozen output'
    else:
        out.write_text(payload)
    print(json.dumps({'status':data['status'],'rows':[{
        'beta_reference_denominator':r['reference_beta_denominator'],
        'log2_repetitions':r['repetitions_log2'],
        'compact_program_bits_bitlength':r['compact_program_bits'].bit_length(),
        'zeros_per_program_bit':r['zeros_per_program_bit'],
        'total_forward_calls_bitlength':r['total_forward_calls'].bit_length(),
        'rate_guard':r['exact_rate_margin_bits']>=0} for r in rows]},indent=2))


if __name__ == '__main__':
    main()
