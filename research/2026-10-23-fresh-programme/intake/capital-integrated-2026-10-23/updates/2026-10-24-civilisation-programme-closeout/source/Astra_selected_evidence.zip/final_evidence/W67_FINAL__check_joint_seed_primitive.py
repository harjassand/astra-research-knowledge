"""Exact finite retained-seed/vacuum fixtures and failure controls.

These small rational channels test the complete joint statement and its
boundaries. They are not huge-code, actual-H or physical experiments.
"""
from fractions import Fraction as F
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent


def zero(n, m=None):
    return [[F(0) for _ in range(m or n)] for _ in range(n)]


def eye(n):
    return [[F(i == j) for j in range(n)] for i in range(n)]


def trn(a):
    return list(map(list, zip(*a)))


def mul(a, b):
    return [[sum(x*y for x, y in zip(r, c)) for c in zip(*b)] for r in a]


def plus(a, b, c=F(1)):
    return [[x+c*y for x, y in zip(ar, br)] for ar, br in zip(a, b)]


def scale(a, c):
    return [[c*x for x in r] for r in a]


def kron(a, b):
    return [[x*y for x in ar for y in br] for ar in a for br in b]


def trace(a):
    return sum(a[i][i] for i in range(len(a)))


def index(l, s, a, f):
    return ((l*2+s)*2+a)*2+f


def target_channel_unit(T, i, j):
    # Trace only decoder environment A; retain logical, physical S and F.
    out = zero(8)
    for l in range(2):
        for s in range(2):
            for f in range(2):
                for ll in range(2):
                    for ss in range(2):
                        for ff in range(2):
                            out[(l*2+s)*2+f][(ll*2+ss)*2+ff] = sum(
                                T[index(l,s,a,f)][i]*T[index(ll,ss,a,ff)][j]
                                for a in range(2))
    return out


def main():
    I, X = eye(2), [[F(0), F(1)], [F(1), F(0)]]
    env = [[F(4,5), F(3,5)], [F(3,5), F(4,5)]]
    gram = mul(trn(env), env)
    assert gram == [[F(1), F(24,25)], [F(24,25), F(1)]]
    assert env[0][0] > 0 and env[0][0]*env[1][1]-env[0][1]**2 > 0
    n = 100
    good, bad = F(n*n-1, n*n+1), F(2*n, n*n+1)
    assert good*good+bad*bad == 1
    # Frow=good*env tensor I is PSD, so its exact polar inverse is I.
    Frow = scale(kron(env, I), good)
    Gamma = scale(gram, good*good)
    assert mul(trn(Frow), Frow) == kron(Gamma, I)
    assert mul(scale(env,good),scale(env,good)) == Gamma
    V, T = zero(16,4), zero(16,4)
    for l in range(2):
        for s in range(2):
            col = l*2+s
            for a in range(2):
                V[index(l,s,a,0)][col] = good*env[a][s]
                T[index(l,s,a,0)][col] = env[a][s]
            # Physical bad-word branch can alter the logical register.
            V[index(l^s,s,s,1)][col] = bad
    assert mul(trn(V),V) == eye(4)
    assert mul(trn(T),T) == eye(4)
    diff = plus(V,T,-F(1))
    norm_square = 2*(1-good)
    assert mul(trn(diff),diff) == scale(eye(4),norm_square)
    # This operator identity certifies the arbitrary-reference norm,
    # not just a particular seed state or Bell-state fidelity.
    checks = 0
    for i in range(4):
        l,s = divmod(i,2)
        for j in range(4):
            ll,ss = divmod(j,2)
            expected = zero(8)
            expected[(l*2+s)*2][(ll*2+ss)*2] = gram[ss][s]
            actual = target_channel_unit(T,i,j)
            assert actual == expected
            checks += 64
    # Incorrectly demanding seed identity fails even with exact logical
    # recovery and word vacuum: the actual map can be id tensor Z_seed.
    Z = [[F(1),F(0)],[F(0),-F(1)]]
    bell = zero(4)
    for i in [0,3]:
        for j in [0,3]:
            bell[i][j] = F(1,2)
    phase = kron(I,Z)
    phase_out = mul(mul(phase,bell),trn(phase))
    witness = trace(mul(kron(X,X),plus(phase_out,bell,-F(1))))
    assert witness == -2
    # Dropping CROSS-sector Gram conditions is invalid. Each individual
    # Kraus operator I or X has Gram I, but the combined deviation has norm1.
    badrow = [I[r]+X[r] for r in range(2)]
    cross_delta = plus(mul(trn(badrow),badrow),eye(4),-F(1))
    assert mul(cross_delta,cross_delta) == eye(4)
    # Counterexample to deriving a local-stochastic law from near reset.
    K0,K1,K2 = zero(4),zero(4),zero(4)
    for l in range(2):
        K0[l*2][l*2] = good
        K1[(l^1)*2+1][l*2] = bad
        K2[(l^1)*2+1][l*2+1] = F(1)
    completeness = zero(4)
    for K in [K0,K1,K2]:
        completeness = plus(completeness,mul(trn(K),K))
    assert completeness == eye(4)
    p = bad*bad
    # Word-flag orthogonality gives exact vacuum-start diamond distance2p.
    eps = 2*p
    paths = {(0,()):F(1)}
    for _ in range(8):
        nxt = {}
        for (flag,history),prob in paths.items():
            options = [(1,1,F(1))] if flag else [(0,0,1-p),(1,1,p)]
            for newflag,fault,weight in options:
                key = (newflag,history+(fault,))
                nxt[key] = nxt.get(key,F(0))+prob*weight
        paths = nxt
    assert sum(paths.values()) == 1
    all_faults = sum(prob for (flag,hist),prob in paths.items() if all(hist))
    any_fault = sum(prob for (flag,hist),prob in paths.items() if any(hist))
    assert all_faults == p and any_fault == 1-(1-p)**8
    assert all_faults > eps**8
    result = {'status':'PASS_EXACT_FINITE_JOINT_FIXTURES', 'scope':__doc__,
              'logical_seed_dimension':4, 'retained_isometry_output_dimension':16,
              'joint_target_matrix_unit_entries_checked':checks,
              'actual_and_target_isometries_exact':True,
              'full_joint_isometry_error_squared':str(norm_square),
              'seed_schur_offdiagonal':str(F(24,25)),
              'seed_identity_negative_witness':str(witness),
              'cross_sector_omission_deviation_norm':1,
              'memory_counterexample_CPTP_exact':True,
              'memory_vacuum_start_diamond_distance':str(eps),
              'eight_consecutive_fault_probability':str(all_faults),
              'incorrect_local_stochastic_epsilon_power_eight':str(eps**8),
              'eight_block_any_fault_probability':str(any_fault),
              'actual_H_or_large_code_test':False,
              'physical_status':'NOT_PERFORMED','mission':'NOT_ACHIEVED'}
    payload = json.dumps(result,indent=2)+'\n'
    out = HERE/'JOINT_SEED_PRIMITIVE_EXACT.json'
    if out.exists():
        assert out.read_text() == payload, 'refuse changed frozen output'
    else:
        out.write_text(payload)
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    main()
