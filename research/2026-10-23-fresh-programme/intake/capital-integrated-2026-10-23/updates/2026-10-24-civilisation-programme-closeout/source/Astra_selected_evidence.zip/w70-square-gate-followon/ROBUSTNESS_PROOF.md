# Uniform square-gate error is sufficient for bounded-optimum convergence

Internal mathematics; hardware hypotheses remain explicit. This extends rather than changes the frozen first packet.

## Contract and all-ensemble guarantee

Use the first packet's force-controlled fixed-geometry linear truss. Let

`y_e(a)=E_P[(epsilon_e/epsilon_max,e)^2]`, `S_e=E_e epsilon_max,e^2/2`, and `theta_e=lambda/S_e`.

The fixed load distribution `P` is arbitrary, subject to the acquired bound `|epsilon_e|<=epsilon_max,e` throughout the admitted geometry box. It may be discrete or continuous. It is fixed during convergence; a changing objective has a tracking problem instead. The objective gradient remains `partial_e F=l_e S_e(theta_e-y_e)`.

Suppose the COMPLETE observation chain—strain transfer, voltage encoding, electronic square, averaging, hold/delay and uncertainty in the mechanical state—delivers an estimate `y_hat,e` satisfying

`|y_hat,e-y_e|<=delta_e` at every update.

A uniform pointwise square error `|q_e(epsilon)-(epsilon/epsilon_max,e)^2|<=delta_gate,e` integrates to the same error bound for **every** distribution `P`. This statement does not assume a favorable load mixture. It does not acquire the strain range, the distribution or its temporal average. Those are separately charged controls/measurements.

Actual material actuation is a separate contract: its area/stiffness increment must have the commanded sign, stop at zero command, and obey the positive mobility and safe-step bounds below. An arbitrary additive post-deadband growth/corrosion bias cannot be hidden in `delta_e`. If material moves at zero command, monotone descent is generally false even with a perfect square gate. Faradaic efficiency varying within positive bounds changes mobility and time; it need not be misrepresented as a 0.2%-accurate material response. Spalling, steel attack, leaks, creep and uncontrolled open-circuit corrosion can violate the sign/zero contract and are explicit physical falsifiers.

Use a robust deadband AFTER averaging:

`D_delta(z)=sign(z) max(|z|-delta,0)`,

`a_dot,e=projection_to_feasible_tangent [M_e(a) D_delta_e(y_hat,e-theta_e)]`,

with mobility bounded above and bounded away from zero, `0<m<=M_e(a)<=Mmax`. If `d_e=y_e-theta_e>0`, no allowed error can command negative motion after this deadband. If `d_e<0`, no allowed error can command positive motion. Thus every component's contribution to `F_dot` is nonpositive, including projected lower and upper bounds.

When `|d_e|>2 delta_e` and the corresponding direction is feasible, the signed speed has magnitude at least `M_e(|d_e|-2delta_e)`. Hence

`F_dot <= -sum_e l_e S_e M_e |d_e|(|d_e|-2delta_e)_+`,

with outward directions at a bound omitted. This holds for arbitrary time-dependent bounded errors; independence of the errors is unnecessary.

The geometry box is compact and `K` stays uniformly positive definite. Therefore `y_e(a)` is continuous, bounded and locally Lipschitz, the velocities are bounded, and `F` decreases to a finite limit. Every limit point satisfies the approximate KKT conditions:

- interior member: `|y_e-theta_e|<=2delta_e`;
- at the lower bound: `y_e-theta_e<=2delta_e`;
- at the upper bound: `y_e-theta_e>=-2delta_e`.

For completeness, if a limit point violated one of these conditions by a positive margin, a neighborhood would have an inward feasible velocity and a strictly negative objective derivative bounded away from zero. Bounded velocity implies each repeated visit spends a positive amount of time in a slightly larger neighborhood. Infinitely many such visits, or remaining there forever, contradict finite total decrease of `F`. This proves the stated limit-point conditions without claiming a unique final geometry.

Convexity then gives the explicit objective bound at every limit point `a_bar`:

`0 <= F(a_bar)-F_star <= 2 sum_e l_e S_e delta_e (a_max,e-a_min,e)`.

This is the result needed for an approximate attainable gate: exact squaring is unnecessary, but a specified nonzero operating margin and complete uniform error budget are necessary. For equal `S` and threshold `theta`, the bound divided by `lambda` is `2(delta/theta) times the available variable-volume range`.

Exact optimization is not implied for fixed nonzero error. Even one force-loaded bar with a constant positive response bias `b` settles at true energy density `lambda-b` under uncorrected control, rather than `lambda`. Vanishing error/deadband could recover exact convergence but would require progressively more precision/calibration; it is not a free property of an actual sensor.

## Finite manufacturing updates, including unloaded growth

An infinitesimal flow is insufficient for a practical teach/unload/grow/reteach process. The same robust law supplies a finite safe update without a free objective readout. Write `c_e=l_e S_e>0`, `d_e=y_e-theta_e`, `w_e=D_delta(y_hat,e-theta_e)`, and `v_e=M_e w_e`. The complete error bound implies `sign(w_e)=sign(d_e)` whenever `w_e!=0` and `|w_e|<=|d_e|`. Let `F` have gradient Lipschitz constant `L_F` on the admitted box. For the clipped Euler update `Delta a=clip_box(a+h v)-a`, clipping preserves each component's sign and reduces its magnitude, so

`grad F . Delta a = -sum c_e d_e Delta a_e <= -(kappa/h)||Delta a||^2`,

where `kappa=min_e c_e/M_e`. Consequently

`F(a+Delta a)<=F(a)-(kappa/h-L_F/2)||Delta a||^2`.

Any `0<h<2 kappa/L_F` is a certified finite descent step. This permits the material update to happen unloaded. The actual increment may have an uncertain positive gain if its maximum magnitude is included in `M_e` and the clipping/safe-step inequality is respected. A fixed-duration on/off relay cannot be substituted arbitrarily near a deadband edge: it can overshoot. It requires a smaller certified step or a further safety margin. Conservative dose quantization that rounds a nominal increment toward zero also preserves the inequality; a minimum increment `q_a` enlarges the stationary tolerance by at most `q_a/(h m)` in the corresponding normalized drive. Additive material drift at zero remains outside this theorem.

An available conservative `L_F` comes from `K>=k0 I` and `K_e=partial K/partial a_e`: the compliance Hessian is the Gram matrix with entries `E_P[(K_e u)^T K^-1(K_j u)]`, so

`L_F <= E_P||f||^2 * sum_e ||K_e||^2 / k0^3`.

The manufacturing fixture must acquire a valid geometry, force range and lower stiffness bound to use this bound. A loose bound can make progress impractically slow. Exact knowledge of a Lipschitz constant is not available merely because a simulation can compute one.

`additional_calculations.py` checks this inequality on a one-bar synthetic example with constant, oscillating and alternating bounded errors. Its maximum objective increase is zero to the reported floating precision. This is a numerical check of a mathematical construction, not acquired material behavior.

## Constructive threshold-sweep square gate

Let a held normalized strain voltage be `x` in `[-1,1]`. For `M` shared thresholds

`u_k=(k+1/2)/M`, `r_k=sqrt(u_k)`, `k=0,...,M-1`,

two local comparators emit one when `x>r_k` or `x<-r_k`. Their mean output is

`q_M(x)=(1/M) sum_k 1{x^2>u_k}`.

It is the midpoint quantization of `x^2`; for every input, including negative strain,

`|q_M(x)-x^2|<=1/(2M)`.

At `M=256`, this is 0.001953125 of normalized squared-strain full scale. The square root is a 256-entry shared threshold table, not an inaccessible analog material law. No per-member ADC or multiplication is required for this conversion. A conventional controller remains allowed to use this same architecture.

Let all input encoding, threshold-voltage, comparator, and sample-motion errors be absorbed into `d`, measured in units of full-scale strain voltage. Perturbed comparison thresholds sandwich the ideal result between those at `max(|x|-d,0)` and `min(|x|+d,1)`. Therefore a conservative square error is

`delta_gate <= 2d+d^2+1/(2M)`.

Averager error, geometry-aging error and dose/efficiency error are then added in the same normalized units. Calibration error is not hidden inside a fitted coefficient. The inequalities require an acquired uniform bound, not an RMS fit or a typical datasheet number.

## Temporal obstruction and its repair

A broadcast sweep cannot be compared to arbitrary changing strain as though it were held. For `u` increasing uniformly from zero to one, take `x(u)=sqrt(u)/2`. Every comparator is OFF, yet true mean squared strain is `1/8`. Thus there is no all-load-trajectory guarantee from a deterministic threshold sweep alone.

The hardware must either hold its input during each sweep, keep the applied teaching load fixed until the sweep completes, or acquire a strain-rate bound. If normalized strain changes by at most `S T` during a sweep of duration `T`, that quantity is charged to `d`. Independent randomized thresholds are another unbiased construction, but their sample, randomization and concentration costs must be paid.

The load ensemble must be averaged BEFORE applying `D_delta`. Averaging deadbanded per-load commands is not the same operation and does not inherit the proof. A local analog integrating capacitor, a sample/hold stage and global sense/swap/reset timing can implement this ordering. The capacitor's leakage, switching injection, reset energy and geometry aging during one frame belong in the uniform error budget.

## Acquiring an unknown ensemble is not free

For bounded iid samples in `[0,1]`, Hoeffding plus a union bound gives

`n >= log(2 N K/alpha)/(2 eta^2)`

independent load samples per update to bound averaging error `eta` for `N` members across `K` updates with failure probability at most `alpha`. This is uniform over all underlying iid bounded distributions. It is not valid for an unqualified correlated service load.

For `N=100`, `K=100`, `alpha=0.01`, `eta=0.02`, the count is 18136 samples per update. At one genuinely independent sample per second this alone takes 5.038 hours per update. Controlled finite teaching loads can replace this acquisition with a known schedule, but force application, settling and repeated geometry updates remain physical time/energy costs. Native electronics do not remove them.
