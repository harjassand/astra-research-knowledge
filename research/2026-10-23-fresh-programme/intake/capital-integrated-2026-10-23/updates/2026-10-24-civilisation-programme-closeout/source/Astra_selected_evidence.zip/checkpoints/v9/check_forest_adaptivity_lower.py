"""Independent root diagnostics for W73's two-star lower. No producer imports.

The universal result is analytic; these floating Gaussian and exact rational
checks diagnose algebra/order errors rather than certify all input designs.
"""
import itertools, json, math
from fractions import Fraction as F
from pathlib import Path
import numpy as np

def qinv(A):
    n=len(A); rows=[list(row)+[F(i==j) for j in range(n)] for i,row in enumerate(A)]
    for k in range(n):
        p=next(i for i in range(k,n) if rows[i][k]); rows[k],rows[p]=rows[p],rows[k]
        z=rows[k][k]; rows[k]=[v/z for v in rows[k]]
        for i in range(n):
            if i!=k:
                z=rows[i][k]; rows[i]=[x-z*y for x,y in zip(rows[i],rows[k])]
    return [row[n:] for row in rows]

def quadratic(v,A):
    return sum(v[i]*A[i][j]*v[j] for i in range(len(v)) for j in range(len(v)))

exact=[]
for case in range(12):
    N=4+case%3; q=2; lam=F(1+case%4,1+case%2)
    vectors=[[F((i*(case+2)+j*3+case)%7-3) for j in range(q)] for i in range(N)]
    R2=max(sum(z*z for z in v) for v in vectors)
    for d in range(1,N):
        total=F(0); count=0
        for T in itertools.combinations(range(N),d+1):
            G=[[lam*F(i==j)+sum(vectors[l][i]*vectors[l][j] for l in T) for j in range(q)] for i in range(q)]
            inv=qinv(G); hs=[]
            for target in T:
                A=[[lam*F(i==j)+sum(vectors[l][i]*vectors[l][j] for l in T if l!=target) for j in range(q)] for i in range(q)]
                t=quadratic(vectors[target],qinv(A)); h=quadratic(vectors[target],inv)
                assert t==h/(1-h)
                assert t<=(1+R2/lam)*h
                hs.append(h); total+=t; count+=1
            assert sum(hs)<=q
        average=total/count; bound=(1+R2/lam)*q/F(d+1)
        assert average<=bound
        exact.append(dict(case=case,N=N,d=d,average=str(average),bound=str(bound),terms=count))

rng=np.random.default_rng(7316401)
gaussian=[]; totals=[]
for n in (4,6):
    for q in (1,2,3):
        for design_kind in range(5):
            S=rng.integers(-3,4,size=(n,q)).astype(float)
            if design_kind==0:S[:]=0
            if design_kind==1:S[:]=np.arange(q)+1
            if design_kind==2:S=np.eye(n,q)
            if design_kind==4:S*=7
            B=max(np.sum(S*S,axis=1)); sigma=1.3; tau=.7; a=1.1
            kl_values=[]; max_identity_error=0.
            for u in range(n):
                for v in range(n):
                    if u==v:continue
                    remaining=[i for i in range(n) if i not in (u,v)]
                    for A in itertools.combinations(remaining,(n-2)//2):
                        A=set(A); C=set(remaining)-A; coeff=[]
                        for leaf in remaining:
                            hub=u if leaf in A else v
                            edge=np.zeros((n,q)); edge[leaf]=S[leaf]-S[hub]; edge[hub]=-edge[leaf]
                            coeff.append(edge.ravel())
                        Z=np.array(coeff).T
                        covariance=sigma**2*np.eye(n*q)+tau**2*Z@Z.T
                        shift=np.zeros((n,q)); shift[u]=a*(S[u]-S[v]); shift[v]=-shift[u]
                        h=shift.ravel()
                        direct=float(.5*h@np.linalg.solve(covariance,h))
                        conditional=0.
                        for hub,leaves in ((u,A),(v,C)):
                            residual_cov=sigma**2*np.eye(q)
                            for leaf in leaves:
                                r=S[leaf]-S[hub]
                                variance=1/(tau**-2+float(r@r)/sigma**2)
                                residual_cov+=variance*np.outer(r,r)
                            dh=S[u]-S[v]
                            conditional+=.5*a*a*float(dh@np.linalg.solve(residual_cov,dh))
                        error=abs(conditional-direct)
                        assert error<1e-8*(1+direct)
                        max_identity_error=max(max_identity_error,error)
                        kl_values.append(direct)
            mean=float(np.mean(kl_values)); upper=2*a*a*q/n*(tau**-2+8*B/sigma**2)
            assert mean<=upper+1e-8
            gaussian.append(dict(n=n,q=q,design_kind=design_kind,metadata_cases=len(kl_values),B=float(B),mean_full_data_KL=mean,analytic_bound=upper,max_posterior_identity_error=max_identity_error))

report=dict(status='PASS_INDEPENDENT_FINITE_DIAGNOSTICS',exact_rational_leverage_cases=len(exact),exact_terms=sum(x['terms'] for x in exact),rational=exact,gaussian_designs=len(gaussian),full_joint_metadata_cases=sum(x['metadata_cases'] for x in gaussian),gaussian=gaussian,largest_gaussian_identity_error=max(x['max_posterior_identity_error'] for x in gaussian),limits='Finite exact rational identities and floating Gaussian diagnostics; universal all-design theorem requires the separate analytic audit. No physical acquisition.')
Path(__file__).with_name('FOREST_ADAPTIVITY_INDEPENDENT_CHECKS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('rational','gaussian')},indent=2))
