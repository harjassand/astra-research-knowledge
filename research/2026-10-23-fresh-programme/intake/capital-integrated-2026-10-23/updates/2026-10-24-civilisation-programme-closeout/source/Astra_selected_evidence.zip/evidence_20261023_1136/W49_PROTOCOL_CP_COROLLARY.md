# Beta0 all-resource protocol CP domination

w49 continuation after independently reconstructing w19's sector-counter
construction. This is a separate corollary, preserving all earlier frozen
bytes. It depends on the state-level positive sector comparisons proved
in w19 `FULL_STRONG_CONVERSE_V1.md`, SHA256
`1f5997c7ba33c13e6f1a1a9f1cff183d68bad1a876b63f1c7a6ef3989bed16c7`,
and freshly reconstructed in own full audit SHA256
`69929f95b7233ee8eaee610b173c8b4e498f794b18649eaec00d8ec09a673442`.
Its additional step is to retain source-independent comparison STATES
and use weighted OPERATOR Cauchy, rather than only Bell probabilities.

## 1. Fixed-protocol quantifiers

Fix beta0, N, a finite-dimensional fresh logical INPUT M, and ONE legal
protocol with fixed normal resource eta_N independent of M and of its
reference R. Eta may have arbitrary horizon-dependent bath/laboratory
entanglement, coherences, support and entropy. Local normal TP controls,
backward quantum/classical communication and initial preshares are allowed;
the N actual device calls are the sole forward path. Bob's final output B
includes any desired retained receiver systems; decoding, if present, is
TP and unconditional. There is no additional forward success/timing wire.

This fixed process defines a genuine CPTP logical channel
`Lambda:M->B`. The comparison replacer state below may depend on this
protocol, its resource and N, but NOT on the arbitrary logical input or
its purification. No universal common replacer across all strategies is
asserted. The coefficient is uniform across those strategies/resources.

## 2. Source-independent comparison states

Let s=(q,o) range over q+o<=N, with
`D_q=binom(N,q)2^q`. Tag the two ignored coherent counters and retain all
environments. Their final coefficient isometries are fixed linear maps
`W_s:M->B tensor F`; the original isometry is `W=sum_s W_s`.
Each `Lambda_s(X)=Tr_F W_s X W_s*` is a CP, unnormalized sector channel.
It is NOT asserted that Lambda=sum_s Lambda_s, since original coherent
cross terms must be retained.

For the incoming cut, replace the charge-q identity-wire instrument by
the normalized fixed correlated replacer sigma_q=P_q/D_q. Sum the OTHER
counter over ALL o=0,...,N, including comparison branches forbidden by
the original U. This is one completed causal no-forward TP protocol.
Its Bob channel is a constant channel R_(tau_q^in): no sender input M
can influence Bob under this replacement. The state tau_q^in is the same
for every logical density, not merely for a maximally mixed Bell input.
For any reference extension rho_RM, its full output is therefore
`rho_R tensor tau_q^in`.

Positive finite-port linking and positive selected-branch domination give
the COMPLETE order, tested with arbitrary references or a full Choi input,

`Lambda_s <=_CP D_q^2 R_(tau_q^in)`.

For the outgoing cut, use the fixed sigma_o=P_o/D_o and sum the sender's
q counter over ALL0,...,N, again including originally forbidden q+o>N
comparison branches. This full no-forward TP channel likewise has one
input-independent Bob state tau_o^out. A selected sender branch can steer
R/Bob, but its UNNORMALIZED output is bounded by the unconditional product.
Thus the complete map order is

`Lambda_s <=_CP D_o^2 R_(tau_o^out)`.

These are not fidelity-only conclusions: both comparisons were positive
OUTPUT-STATE orders for every independent fresh source/reference input.
The no-forward channel is completely constant. This is the key extra
obligation needed to promote a Bell bound to a CP bound.

For each s choose the smaller dimension, and set

```
d_s=min(D_q,D_o)>0,
tau_s=tau_q^in if D_q<=D_o, otherwise tau_o^out.
```

Then `Lambda_s<=_CP d_s^2 R_(tau_s)`. The cut choice is an analytical
comparison for each fixed sector; no party chooses a future cut or
learns a count in the actual protocol. All tau_s are fixed normal
normalized states independent of the logical input.

## 3. Weighted operator Cauchy retains coherence

Put `S_N=sum_s d_s`. For any vectors v_s and strictly positive d_s,

`|sum_s v_s><sum_s v_s| <=S_N sum_s |v_s><v_s|/d_s`.

For a test vector z this is scalar Cauchy applied to
`sum_s sqrt(d_s)<z,v_s>/sqrt(d_s)`. Applying it to the Choi isometry
amplitudes `|W_s>>` and tracing environments gives

`J_Lambda <=S_N sum_s J_(Lambda_s)/d_s`.

Use the complete sector orders from Section2 to conclude

```
Lambda <=_CP S_N sum_s d_s R_(tau_s)
       =S_N^2 R_(bar_tau),
bar_tau=(1/S_N)sum_s d_s tau_s.                         (P1)
```

Bar_tau is normal, normalized and input-independent. This is an actual
CP domination of the induced logical channel, with all original coherent
sector cross terms retained by the weighted inequality. No individual
sector/difference needs to be a normalized deterministic comb.

The exact dimension aggregation gives

```
S_N=sum_(r=0)^floor(N/2)[2(N-2r)+1]binom(N,r)2^r,
S_N^2<=100*8^N/(N+1).                                  (P2)
```

The first identity uses min(D_q,D_o)=D_min(q,o) for q+o<=N; the second
is the previously frozen geometric ratio and central-binomial-square
argument, with odd/even constants98/100. The exact S_N is preferable
when a finite value is wanted. Coefficient S_N^2>=1, as required for a
trace-preserving channel dominated by a normalized replacer.

## 4. All-input information and complement leakage

For any fresh input purification psi_RM, the actual protocol output obeys

`omega_RB <=S_N^2 rho_R tensor bar_tau_B`.

Log monotonicity/max-relative entropy implies
`D(omega_RB || rho_R tensor bar_tau)<=2log2 S_N`.
Decomposing this relative entropy into mutual information plus
`D(omega_B||bar_tau)` gives

`I(R:B)<=2log2 S_N`.

Since R is finite dimensional, this statement is well-defined even
when auxiliary/Bob entropies are infinite. For the induced channel
coherent information, equivalently `I_c=I(R:B)-S(rho_M)`, one obtains

`I_c<=min{S(rho_M),2log2 S_N-S(rho_M)}<=log2 S_N`.

Purify eta and all controls. Let F be the COMPLETE final environment
outside Bob's chosen B: this includes the actual final bath, the initial
resource purifier and all discarded/retained sender environments as
appropriate. Purity then gives

`I(R:F)=2S(rho_M)-I(R:B)>=[2S(rho_M)-2log2 S_N]_+`.

One must not replace F by the final bath alone or discard an initially
entangled laboratory/purifier. The logical source is fresh product with
eta; arbitrary preexisting R-resource correlations remain excluded.

For a K-dimensional logical Bell input and TP K-dimensional decoder,
(P1) reproduces `F_e<=S_N^2/K^2`, and therefore the sharper all-resource
strong converse. No information assertion here follows from fidelity
alone; it follows from the independently retained CP state orders.

## Status, costs and comparison

The generic CP-replacer-to-information step is the established
max-information/max-relative-entropy tool already documented in own
REFERENCES.md (Fang--Wang--Tomamichel--Berta, Datta). The current device
evaluation and broad fresh-resource protocol scope use w19's sector
construction and the weighted aggregation above. Historical priority
and external correctness remain UNKNOWN; fresh criticism is requested.

This is beta0 only, under a fixed protocol and fresh logical source.
It grants arbitrary resource entanglement for a converse, not physical
preparation or an uncounted forward operation. No achievable code,
source factory, practical cost advantage or positive-beta entangled-
resource quadratic theorem is supplied.
