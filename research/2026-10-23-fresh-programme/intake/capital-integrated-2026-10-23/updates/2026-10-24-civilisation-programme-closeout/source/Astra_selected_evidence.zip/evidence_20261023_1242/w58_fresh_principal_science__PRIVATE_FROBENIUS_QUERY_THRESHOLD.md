# A three-versus-four action threshold for private Frobenius risk

23 October 2026. Complete internal candidate; fresh independent audit
NOT_PERFORMED. The lower argument below is newly derived here from actual
supported matrix directions, rank perturbations, a trimmed sphere-energy
bound and an adaptive Gaussian likelihood. Those mathematical ingredients
are established. No identical-theorem priority or physical usefulness is
asserted. This changes the risk/adversary contract and does not modify the
frozen pathwise phase theorems. Mission NOT_ACHIEVED.

## 1. Precise uniform private-risk model and theorem

The actual support is S(K_k), k>=4: k hubs, T=binom(k,2) observable degree-
two mediators, N=k+T sites. All N diagonal entries and2T supported symmetric
couplings are arbitrary unknown real. The full signal space has dimension

                         p=N+2T=k+3T.                  (1)

Every one of Nq original observation cells is acquired/paid. Each COMPLETE
input row across the q actions has Euclidean norm<=1. The legal algorithm
may use private randomness and ADAPTIVELY choose action j from all earlier
observations and its private randomness; its whole-row cap must hold for
every realized history. Policies/decoders are measurable, D is fixed during
all actions, and no information beyond the stated support/action interface
is supplied.

For a fixed q define C_q(k) as the infimum uniform squared-risk constant's
square root: for EVERY fixed D and every fixed additive Nq noise E,

        E_private||Dhat-D||F^2 <= C_q(k)^2||E||F^2.       (2)

E is fixed independently of private randomness. It can be correlated across
all cells and depend on D. Queries may depend on past noisy observations;
this does not make E allowed to depend on the private seed. The target in
this note is WHOLE-MATRIX FROBENIUS loss. The q3 lower below is NOT claimed
for operator loss. Orthogonal projection of any estimate onto the supported
symmetric signal space decreases this loss, so arbitrary global decoders
are allowed without restricting their output format.

The conclusions are:

* q<=2: no finite C_q(k) for k>=4.
* q3, k>896, even with adaptive private policies:

       C_3(k)^2 >= [k^2/(768N)] ln(k/896).               (3)

  A nonadaptive finite-rational upper, with L=max{2,ceil(sqrt(k))}, has

       C_3(k)^2 <=1+72 H_(L-1),                         (4)

  where H_n=sum_(r=1)^n1/r. Thus C_3(k)=Theta(sqrt(log k)).
* q4: 1/2<=C_4(k)<=14, using the separately frozen rational-projector
  upper and its zero-noise qualification. Thus C_4(k)=Theta(1).

Four is therefore the LEAST fixed number of actions allowing a bounded
uniform private Frobenius-risk constant as k grows. These conclusions
already include all real adaptive global decoders in the lower. They do
not imply any analogous q3 operator-risk lower or any physical access.

## 2. Actual supported directions isolate hub correlations

Fix ANY realized q3 seed X, with whole-row norms<=1, and write v_i for
its hub rows and w_e for its actual mediator rows. Let A_X map a supported
symmetric matrix, expressed in a FROBENIUS-ORTHONORMAL parameter basis, to
its full3N actual action cells. Write H_X=A_X^T A_X.

If a row of X is zero, its FREE diagonal is an unobserved unit parameter,
so H_X has a zero eigenvalue. Otherwise normalize the hub rows as
u_i=v_i/||v_i|| in S^2. For every original pair e=ij and its actual
mediator e, use the symmetric supported matrix F_e whose two half-edge
entries are

              (i,e):1/||v_i||,    (j,e):-1/||v_j||.

It has NO diagonal. Its squared Frobenius norm is

        n_e^2=2[||v_i||^(-2)+||v_j||^(-2)]>=4.          (5)

The matrices Q_e=F_e/n_e are orthonormal: different e use different
original matrix entries, even when their hub rows overlap. They are legal
signal directions, not extra physical controls or unknown auxiliary sites.

Their actual action equations are:

 mediator e:   (u_i-u_j)/n_e;
 hub i:        w_e/(||v_i|| n_e);
 hub j:       -w_e/(||v_j|| n_e);
 every other original row: zero.

Hence on this T-dimensional orthonormal signal subspace, the FULL original
action Gram is

        Q^T H_X Q=diag(c_e)+B^T B,
 c_e=||u_i-u_j||^2/n_e^2<=||u_i-u_j||^2/4,
                         rank(B)<=3k.                  (6)

B contains ALL actual hub outputs. No hub equation is omitted; their
entire influence is the explicitly paid rank3k perturbation. Arbitrary
actual mediator inputs w_e are allowed. This is not a restriction to the
upper's projector inputs or to a local receiver.

## 3. Inverse compression and deletion of the closest3k pairs

For lambda>0, inverse compression/Schur complement gives

 tr(H_X+lambda I)^(-1)
       >=tr(Q^T H_X Q+lambda I)^(-1).                   (7)

Indeed Q^T(H_X+lambda I)^(-1)Q is at least
(Q^T H_X Q+lambda I)^(-1), and its trace is at most the full inverse
trace. This follows by writing the positive matrix in blocks in a basis
extending Q and taking its Schur complement.

A positive rank-r perturbation of a diagonal matrix can remove at most r
terms from the lower inverse-trace bound: increasing-eigenvalue interlacing
gives lambda_j(D+B^T B)<=lambda_(j+r)(D), j<=T-r. With r=3k and (6),

 tr(H_X+lambda I)^(-1)
    >=4 sum_(j=3k+1)^T 1/[4lambda+delta_(j)^2],         (8)

where delta_(j)^2 are the increasingly sorted squared chord distances of
ALL hub pairs. The coordinate-wise c_e bound remains true after sorting.
Repeated hub directions cause no difficulty because lambda>0. Equation(8)
explicitly permits deleting the3k CLOSEST pairs, which could carry most
of an untrimmed singular energy. An untrimmed Riesz lower alone would not
justify this step.

## 4. Elementary trimmed Riesz2 bound on S^2

For any0<a<=1, S^2 can be partitioned into at most64/a sets of chord
diameter<=sqrt(a). To see this, take a maximal sqrt(a)/2-separated set.
Chord caps of radius sqrt(a)/4 around its points are disjoint, each with
area pi*a/16. Their count is at most4pi/(pi*a/16)=64/a. Maximality covers
the sphere by chord caps of radius sqrt(a)/2; assigning every point to one
such cap gives the required partition.

For k arbitrary unit points, Cauchy on these cell occupancies shows the
number of unordered pairs of squared distance<=a is at least

                       k^2 a/128-k/2.                  (9)

After removing ANY3k pairs, at least k^2 a/128-7k/2 remain. Therefore for

                  a0=896/k<=a<=1,

the remaining count R(a) is at least k^2 a/256. This statement holds for
every configuration, including collisions or severe clusters.

For lambda=k^(-3), k>896, one has4lambda<=a0. Layer integration, dropping
only nonnegative terms, gives

 sum_(j=3k+1)^T1/[4lambda+delta_(j)^2]
   >=integral_(a0)^1 R(a)/(4lambda+a)^2 da
   >=(k^2/1024) ln(k/896).                             (10)

The second step uses(4lambda+a)^2<=4a^2. Equations(8)--(10) prove the
UNIFORM finite-resolvent bound for every legal realized q3 seed with
nonzero rows:

 tr(H_X+k^(-3)I)^(-1)>=[k^2/256]ln(k/896).              (11)

If any row is zero, its unobserved free diagonal gives inverse trace
at least k^3, which is larger than the RHS. Thus (11) holds for EVERY
legal X without a lower bound on individual row amplitudes.

The logarithmic critical growth of ordinary Riesz2 energy on S^2 is
established prior potential theory. The explicit deletion/resolvent
bound here has a complete elementary proof and is not claimed to be a
new spherical-energy theorem. Its role is to retain the hub rank cost.

## 5. Adaptive/private Gaussian Bayes lower without a limit interchange

Represent D by theta in R^p in the Frobenius-orthonormal basis of the
actual signal space. Take the mathematical test distribution

 theta~N(0,tau^2 I),     E cells iidN(0,sigma^2),
                       tau^2=sigma^2 k^3.              (12)

These are independent of the policy's private randomness. The unknown
matrix class is unbounded, so this finite prior is legal. These are proof
distributions, not acquired physical samples or an input-noise assumption
for the theorem's upper. A uniform bound(2) can be integrated against
any such independent distributions by nonnegative Tonelli integration.

Condition on the algorithm's private randomness and on a complete observed
history y=(y1,y2,y3). Every chosen x_j is then a FIXED known function of
the earlier parts of y. The sequential likelihood as a function of theta
is EXACTLY the product of Gaussian factors

 product_j exp[-||y_j-D(theta)x_j(y_<j)||^2/(2sigma^2)].  (13)

There is no extra theta-dependent factor for the policy's input choice:
the choice is determined by earlier observed data and the conditioned
private seed. Completing the square with the Gaussian prior yields
posterior covariance

            Sigma_y=sigma^2(H_(X(y))+k^(-3)I)^(-1).      (14)

The posterior mean minimizes conditional squared Frobenius risk, so EVERY
global decoder's conditional Bayes risk is at least trSigma_y. Equation
(11) bounds this for EVERY realized legal X(y), including feedback policies.
It follows that integrated Bayes risk is at least

                    sigma^2[k^2/256]ln(k/896).           (15)

But integrating the assumed uniform(2) gives at most
C^2 E||E||F^2=3N C^2 sigma^2. Comparing proves (3).

This is NOT an old zero-transcript argument extended to private noise.
It uses a new Gaussian proof distribution and a bound UNIFORM in the
realized adaptive information matrix. It also uses a FINITE prior (12):
there is no invalid exchange of a diffuse-prior limit with a policy that
depends on its observations. Exact real adaptive policies are included;
no computational restriction helps the lower.

For q<=2, rank(H_X)<=qN and p-qN>=T-k>0 for k>=4. For any Gaussian prior
variance tau^2, the same adaptive likelihood gives at least p-qN posterior
covariance eigenvalues tau^2. Letting that permitted prior variance grow
makes Bayes risk arbitrarily large relative to qN sigma^2. Thus no finite
uniform C is possible. This argument is also explicitly adaptive/private.

For ANY fixed q, each free-diagonal parameter's information diagonal is
the corresponding whole-row squared norm<=1. Positive inverse diagonal
entries satisfy[(H_X+lambda I)^(-1)]_(vv)>=1/(1+lambda). Summing the N
free diagonals and using the same finite-prior Bayes calculation gives
C^2>=1/[q(1+lambda)] for every lambda>0, hence

                              C^2>=1/q.                (16)

This supplies the constant lower at q4 and is compatible with C<1 when
more private actions are paid. No universal deterministic energy floor
has been silently applied to the new expected-risk model.

## 6. Matching rational q3 upper with all original free diagonals

Take L=max{2,ceil(sqrt(k))}, M=L^2, and rational unit hub-code candidates

 u(z)=(4Lz1,4Lz2,4L^2-||z||^2)/(4L^2+||z||^2),
                       z in{1,...,L}^2.                (17)

Assign distinct candidates uniformly without replacement. These positive
chart points are distinct and non-antipodal. They have O(log k)-bit
rational entries. For each pair use the3x3 rational projector

 P_e=I-U_e(U_e^T U_e)^(-1)U_e^T,      w_e=P_e e_maxdiag.

Now rankP_e=1, so p_e=||w_e||^2=maxdiagP_e>=1/3. All actual rows are
legal, with k+T/3<=S<=N. Apply an independent private signed permutation
of the three columns, a finite48-element group. Decode every hub/free
mediator diagonal and both couplings by EXACTLY the original-row
orthogonality equations in the four-action source; they remain valid in
dimension3. No unknown diagonal value is supplied and no extra tag exists.

The two-dimensional integer-shell calculation is explicit. For p=z/(2L),
s=w/(2L), J<=9/4, the sphere identities give

 1-rho^2>=16||z-w||^2/(81L^2).

An infinity shell r in Z^2 has8r possibilities. Thus

 A_L=mean1/(1-rho^2)
    <=(81/2)[L^2/(L^2-1)]H_(L-1)<=54H_(L-1).           (18)

The whole symmetric Frobenius loss at a mediator has quadratic trace
1/p_e+4/(1-rho^2)<=3+4/(1-rho^2). Finite signed-permutation isotropy
divides by3. Hub loss has trace1 and coefficient1/3. Summing the actual
row losses gives

 E_private||Dhat-D||F^2
       <=[1+(4/3)A_L]||E||F^2
       <=[1+72H_(L-1)]||E||F^2,                        (19)

valid NON-STRICTLY for every E, with exact0 at E0. This proves (4), and
the upper is nonadaptive. No asymptotic limit is substituted for the
finite code, finite group, exact rows or noise budget.

The q4 upper is the separately frozen source
PRIVATE_FOUR_ACTION_RATIONAL_PROJECTOR.md SHA256
673e89b12ecd75385118b3029f43fe40cc9539484cb796f85a0b2a59040a4a36,
with mandatory ZERO_NOISE_STRICTNESS_QUALIFICATION.md SHA256
e44f362f52a6445b0671491f5fcf9065402f35cab246352214f35143edf86c42.
Its code grid is3-dimensional, whose inverse-square shell sum is
integrable, giving constant risk. The two-dimensional grid's critical
harmonic sum is exactly the logarithmic distinction matched by the lower.

## 7. Costs, prior work, falsifiers and limits

Both upper grids have O(k) candidates, O(log k)-bit individual entries,
and O(k log k) expected unbiased random bits for no-replacement labels.
The3/4-column finite group needs O(1) expected bits. Exact bounded-integer
rejection sampling has no claimed fixed worst-case draw length. Every
actual outcome is finitely encoded, and no physical RNG/privacy has been
acquired in the synthetic diagnostics.

Each upper constructs T ACTUAL mediator projectors/receiver maps, costing
O(k^2) constant-dimensional rational arithmetic and O(N) storage. Its
action acquisition is3N or4N original cells. Input/receiver coefficients
use O(log k) additional bits, but data magnitude, global sums, exact
denominator growth and physical action preparation/reset/readout are
separate costs. The rank3k and sphere-cap arguments in the lower are
proof operations, not free experimental resources.

Every displayed upper has S>=k+T/q, so peak loading is at least S/q and
grows as Theta(k^2) for fixed q. A fixed per-action physical cap would
force many extra actions; private column permutations merely hide/reorder
the loading and do not balance it. Constant q is not a constant-power or
constant-bandwidth device. Fixed per-cell physical noise also changes
the full Frobenius budget as N grows.

Calibrating exact rational actuator inputs, leakage D DeltaX, stationary
unbounded D, all original site controls/readouts and seed-independent
additive noise remain essential unacquired resources. The Gaussian prior
lower uses the unbounded matrix class; an additional magnitude restriction
would require a separately rederived claim. No physical/financial purchase,
equipment operation, disclosure or outreach has occurred.

Critical Riesz-energy growth is established prior potential theory;
randomized row least squares/inverse-Gram averages and Gaussian conjugacy
are established prior machinery. The strong primary fixed-sparsity
incumbents Amsel et al.2402.09379 and Musco--Ramesh2606.12179 are retained.
The precise bounded-row/full-additive-oblivious-risk/adaptive threshold's
historical priority remains UNKNOWN. The argument is self-contained and
does not claim a new general sphere-energy or Gaussian Bayes principle.

Load-bearing falsifiers: the supported F_e directions are not Frobenius-
orthogonal; an original hub output escapes rank3k; inverse compression or
the rank-deletion ordering is reversed; sphere-cap counting fails after
3k pair deletions; feedback creates an omitted theta-dependent likelihood
factor; the finite prior resolvent is not uniform in realized legal X;
or q3 projector diagonal/coupling separation fails on any actual row.
No Frobenius lower should be relabeled an operator lower.

Status: complete internal candidate, fresh independent review and formal
verification NOT_PERFORMED; external correctness/priority UNKNOWN;
physical validation UNACQUIRED; practical advantage NOT_ESTABLISHED;
mission NOT_ACHIEVED.
