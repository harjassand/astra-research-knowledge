# Correlated thermal observations change the finite-port resource law

Root, 24 October 2026. New conditional analytic model, not an acquired
instrument or a priority claim. Full fresh review PENDING. It does not alter
W73's valid independent-readout-noise theorem. Its purpose is to retain the
information carried by a physically motivated noise covariance when examining
a different instrument, and to identify the limit of two precision ports
while the other terminals remain grounded through ordinary resistances.

## 1. A complete stipulated fluctuation model

Let a passive resistor network have graph Laplacian L and port conductance
matrix G=R^-1>0. All graph and port resistors have the same temperature.
For one sampled, quasi-static real observation, stipulate independent zero
mean Gaussian Norton fluctuations xi and zeta with covariances nu L and nu G,
respectively. The factor nu>0 includes the chosen filter/bandwidth convention.
It is supplied, not measured here. Assume successive sampled fluctuations
are independent, even when controls depend on the past. This assumption is
substantive; a real circuit must acquire its spectrum and sampling law.

With external command x, internal potential v and measured port current i,

    (L+G)v=Gx+zeta-xi,
    i=G(x-v)+zeta=M_R x+(I-GK^-1)zeta+GK^-1 xi,
    K=L+G,  M_R=G-GK^-1G.

Consequently the FULL joint current covariance is exactly

    Cov(i)/nu
       =(I-GK^-1)G(I-K^-1G)+GK^-1 L K^-1G
       =G-GK^-1G=M_R.                              (1)

Append independent readout noise of covariance sigma^2 I, sigma>0. The
defining observation law is therefore

    Y|x,R,theta ~ N(M_theta x, C_theta),
    C_theta=sigma^2 I+nu M_theta.                   (2)

The primitive resistor fluctuation law has classical Nyquist/Twiss prior.
The matrix identity(1) is derived here rather than inferring independent
terminal noise. No Gaussianity, independent sampled bandwidth or actual
ADC floor is established for hardware by that literature alone.

## 2. Exact Gaussian information in the full data

Take the known-background two equal stars (d leaves per hub, edge weight a),
with theta optionally adding the a-weight hub edge. Give all metadata to the
learner. For ANY fixed diagonal G, write b=e_U-e_V and

    u=G(L_0+G)^-1 b,
    c=a/[1+a b^T(L_0+G)^-1b].

Sherman--Morrison gives M_1-M_0=c u u^T. Let

    A=u^T C_0^-1 u,  rho=nu c A.

The Gaussian determinant lemma then gives the EXACT one-action full-data
relative entropy in direction1||0:

    D_1(x,R)=1/2[rho-ln(1+rho)]
                         +(c^2 A/2)(u^T x)^2.      (3)

In particular, x=0 still carries information whenever rho>0. Dropping this
term would falsely extend the fixed-independent-noise ANY-action-count
obstruction to a new covariance model. If x,R are predictable functions of
the acquired history, the complete transcript KL is the expectation of the
sum of(3), using the SAME history control under the two conditional laws.

## 3. Fixed ordinary resistance: energy and sample tradeoff

For uniform port resistance r, put D=1+ra(d+1),
lambda=a(d+1)/D. Decompose e_h=p+w in each star, where
p=1/(d+1) times its all-ones vector and w=e_h-p. Then

    u=(p_U-p_V)+(w_U-w_V)/D,
    A=2/(d+1)[1/sigma^2
                  +d/{D^2(sigma^2+nu lambda)}].    (4)

Thus A~2/(sigma^2 d), c->a and rho~2nu a/(sigma^2 d) at fixed positive
a,r,nu,sigma. With pathwise external row budget sum_t x_ti^2<=B,
the fixed-u triangle bound sum_t(u^T x_t)^2<=4B implies

    D(P_1||P_0)
       =q/2[rho-ln(1+rho)]
          +(c^2 A/2) E_1 sum_t(u^T x_t)^2
       <=q rho^2/4+2c^2 A B.                       (5)

A worst-case error<=delta<1/2 requires D>=2(1-2delta)^2 by Pinsker and
testing. For fixed delta this gives the NECESSARY resource order

    q/d^2+B/d = Omega(1).                          (6)

Both separate endpoints have ordinary matching order at fixed constants.
One signed command x=sqrt(B)sign(u) with B=Theta(d) succeeds with bounded
q. Alternatively at B=0, the scalar
Z=u^T C_0^-1Y/sqrt(A) is N(0,1) or N(0,1+rho); its empirical second
moment with q=O_delta(rho^-2)=O_delta(d^2) distinguishes the two.
For example, threshold1+rho/2 and Chebyshev give individual errors at most
8/(q rho^2) and 8(1+rho)^2/(q rho^2). Zero-command samples still require
readouts, elapsed time, electronics and bandwidth. No energy-free device
or scientific discovery of covariance sensing is claimed.

## 4. Even arbitrarily strong hub drivers do not remove this law's cost

Keep every leaf at ordinary resistance r0=1/(128a), and allow each KNOWN hub
any conductance g_h>=g0=128a, changed adaptively with no conductance cost.
Only the hub-driver resistances vary in this statement; arbitrary extra
leaf routing/floating is not included. Put alpha=a/(1+a r0). For one star,

    h=g_h/(g_h+d alpha), l=alpha/(g_h+d alpha),
    kappa=h-l, t=alpha h.

Its positive column of u has hub entry h and every leaf entry l. It sums
to1. The effective Laplacian has eigenvalue(d+1)t on w and eigenvalue0
on p, so that star's exact contribution to A is

    A_h=1/[(d+1)sigma^2]
        +d kappa^2/[(d+1)(sigma^2+nu(d+1)t)].        (7)

Since g_h>=g0>alpha, 0<=kappa<=h<=1. Hence kappa^2<=h and, summing the
two stars,

    A<=A_*:=2/(d+1)[1/sigma^2+1/(nu alpha)].        (8)

This is UNIFORM even for infinite-precision hub drivers g_h->infinity.
It uses every acquired leaf output through the full covariance inverse;
it is not a raw hub-variance argument.

For an adaptive sequence, each instantaneous u has l1 norm2, hub entries
of magnitude<=1 and leaf entries<=1/d. Therefore

    sum_t (u_t^T x_t)^2
       <=2 sum_ti |u_ti| x_ti^2
       <=2B[2+2d/d]=8B.                           (9)

The Gaussian chain rule and rho-ln(1+rho)<=rho^2/2 now give

    D(P_1||P_0)<=q(nu a A_*)^2/4+4a^2 A_*B.       (10)

At fixed a,r0,nu,sigma and target error, this again requires
q/d^2+B/d=Omega(1), even while arbitrary hub precision is granted.
In particular q=O(log d), B=O(log d) cannot succeed in this changed
thermal-plus-independent-readout model. W73's455c construction assumes
fixed iid sensor noise independent of routing; it makes no promise to
realize(2). The present theorem neither contradicts that construction nor
proves a universal physical obstacle for every reconfigurable interface.

## 5. Scope boundaries and ways the model can change

The additive full-rank readout floor matters. If sigma=0 and exact real
readout is allowed, the disconnected network's sum of currents over one
known star is identically0, while with the core present it is a continuous
nondegenerate Gaussian. One zero-command sample distinguishes these two
singular laws almost surely. Equations(4),(8) cannot be used at sigma=0.

A real two-bus or aggregate-current sensor can change which noise is added
before summation. Floating unselected terminals changes M and its settling
law. Common-mode voltage errors can cancel where independent ones do not.
Active non-equilibrium controllers need their actual noise law. Each is a
legitimate different operation requiring its own complete cost/observation
contract, rather than being excluded by(10).

The equal known-star metadata, positive sigma and nu, sampled quasi-static
Gaussian law, grounded ordinary leaves, and specified commands are essential
scope. No unknown-topology acquisition, actual temperature/noise bandwidth,
switch leakage, duration, hardware operation or practical advantage was
acquired. Generic fluctuation theory, Gaussian testing, matrix inversion
and covariance sensing are PRIOR; exact scoped theorem priority UNKNOWN.

Sources reopened: Nyquist1928 DOI10.1103/PhysRev.32.110 official abstract;
Twiss1955 DOI10.1063/1.1722048 bibliographic locator (original full text not
retrieved); Parra-Rodriguez/Egusquiza arXiv2110.14604v2 abstract describing
the multiport extension. Their existence does not certify this sampled
hardware law. Primary links:
https://journals.aps.org/pr/abstract/10.1103/PhysRev.32.110
https://arxiv.org/abs/2110.14604v2

Status: root analytic conditional construction, fresh review PENDING.
Physical NOT_ACQUIRED; practical NOT_ESTABLISHED; mission NOT_ACHIEVED.
