# All-resource beta-zero strong converse from weighted postselected teleportation

23 October 2026, w36. This proof was constructed after root assigned the arbitrary-initial-entanglement strong-converse question. Its mechanism and bound were sent to root BEFORE reading any peer sector-counter construction. Root subsequently reported an independently frozen w19 sector route with the same polynomial bound; that source remains UNREAD while this file is frozen. No preferred verdict is assumed. Fresh full-file criticism is PENDING.

## 1. Exact theorem and resource interface

Keep the original qutrit tree device at beta=0, so V=U, with

    U=[[R,S1,S2],[S1*,0,0],[S2*,0,0]].

The physical roots and root seed flip R are RETAINED. Let N>=1 be the prescribed number of chronological forward calls and let K be the dimension of a fresh logical Bell source. Define

    m_N=(N+1)(N+2)/2.

The proposed theorem is

    F_e <= min{1, m_N^2 8^N/K^2}.                     (T1)

In particular K_N>=2^[(3/2+delta)N] implies

    F_e <= m_N^2 2^(-2delta N) ->0.                   (T2)

The bound allows EVERY normal initial state eta_N of the bath and ALL initial laboratory/purifier systems. It may depend on N and have arbitrary support, depth, entropy, rank, coherence and bath/laboratory entanglement. Initial Alice--Bob preshares are also unrestricted. The only source constraint is exact

    Phi_(Rlog Mlogical) tensor eta_N.

Thus the fresh logical Bell pair is independent of the ENTIRE initial resource. Alice/Bob perform arbitrary local normal operations and arbitrary Bob-to-Alice quantum/classical communication between calls. Each actual physical call counts. There is no other Alice-to-Bob carrier, including a classical/timing/acceptance signal, no direct bath intervention, and no accepted-branch renormalization. Final decoding is TP with one unconditional K-dimensional output L.

The proof first treats finite causal circuits with normal maps, finite-dimensional port and counter registers, and arbitrary normal ancillary Hilbert spaces. It extends to well-defined normal strategy limits whose relevant joint states converge in trace norm, as specified below. This is a conditional mathematical theorem, not a physical implementation, efficient code, resource preparation or historical-priority claim.

## 2. A no-forward selected-branch lemma

Consider ANY completed physical protocol with only Bob-to-Alice messages, independent initial preshares and the fresh Bell source on Alice's side. Bob may have arbitrary ancillary systems; the side designated Bob can include the inaccessible bath for a mathematical upper bound. If all operations/outcomes are included, no Alice-to-Bob signalling implies

    omega_(Rlog L)=(I_Rlog/K) tensor zeta_L.

This follows stepwise: a local Alice TP operation preserves the reference/receiver marginal; a local receiver operation or sending a subsystem backward preserves its product form. All initial receiver systems are independent of Rlog. The final normalized Bell probability is therefore EXACTLY1/K^2, regardless of zeta_L.

Now select any joint subset of local measurement outcomes while leaving the branch UNNORMALIZED. Its positive output state is a summand of the completed TP output. Hence

    Tr(Phi_K omega_selected)<=1/K^2.                  (L1)

Selection can depend jointly on an Alice outcome and a Bob outcome in this ANALYSIS. Neither outcome is sent forward or used as an extra carrier. This is a bound on an unnormalized CP branch, not permission to run a heralded communication task or condition the input source. In particular no nonlocal Bell projection is inserted into the protocol; the Bell operator is only the final fidelity test.

## 3. Coherent counters give only polynomially many amplitude sectors

Let q=diag(0,1,1). Append independent counters C_A,C_B of dimension N+1, both initially zero. Alice increments C_A by q of each physical input immediately before sending it into the device. Bob increments C_B by q of each physical output immediately after receiving it and BEFORE applying his original next operation. The counters are otherwise ignored by the original strategy and are not sent in its backward messages.

Updates are controlled additions modulo N+1; since there are N calls, there is no count wrap. All original measurements and decoders may be purified, with every environment retained in an overall Stinespring space. Normal initial mixed resources are likewise purified independently of the logical source. Let W_aug be this augmented global isometry and define the coefficient operators

    W_(u,v)=(<u|_(C_A) tensor <v|_(C_B)) W_aug |0,0>.

Equivalently, expand each physical call into its port-charge blocks and group histories by total incoming/outgoing colored counts u,v. Arbitrary original local operations and coherent quantum backward messages remain between these blocks. The counter updates do NOT assert that charge histories are orthogonal in the original process. Instead the exact amplitude identity is

    W_original=sum_(u,v) W_(u,v).                     (C1)

Every device block with both input and output in the colored subspace is zero at beta0. The nonzero possibilities per call are colored/vacuum, vacuum/colored, or vacuum/vacuum at a physical root. Therefore

    W_(u,v)=0 unless u>=0,v>=0,u+v<=N.                (C2)

There are m_N such pairs. This uses only the actual zero block of U. Root visits are allowed and contribute the last,00 possibility. No initial-depth cutoff, history orthogonality, stationarity, bath product condition or root deletion is used.

For the fixed purified initial state define

    F_(u,v)=||( <Phi_K|_(Rlog L) tensor I_env)
                      W_(u,v)|initial>||^2.

This is precisely the UNNORMALIZED Bell probability in the augmented protocol when the two counters are measured at the end and outcomes u,v selected. Cauchy on the at most m_N amplitude vectors in(C1) gives

    F_e <=m_N sum_(u+v<=N) F_(u,v).                  (C3)

Coherent backward feedback can change the coefficient operators, but cannot invalidate the finite expansion or the local counters.

## 4. Weighted teleportation implements a diagonal filter without a forward wire

For any p0,pc>=0 with p0+2pc=1 put p=(p0,pc,pc). Give sender and receiver an independent preshare

    |psi_p>_(a b)=sum_(i=0)^2 sqrt(p_i)|i>_a|i>_b.

The sender applies the normalized rank-one measurement bra

    <psi_p|_(A a)=sum_i sqrt(p_i)<i|_A<i|_a.

On its designated success outcome the map from original port A to receiver's pre-existing register b is EXACTLY

    D_p=diag(p0,pc,pc).                              (P1)

Both factors sqrt(p_i) matter. Complete the measurement with its orthogonal failure effect, discard sender's measured registers, and retain every outcome in a local record. The receiver never learns this new outcome and executes its original operations blindly. The completed process has no forward communication. Its success branch alone acts as(P1), with no probability renormalization.

The zero-endpoint choices p0=0 or pc=0 are allowed normalized preshares and measurements. An empty product is1. The virtual preshares and measurements are only a mathematical comparison; they are not supplied hardware or an uncounted operational forward channel.

## 5. First cut: pay the total input charge

Use the fixed mathematical partition Alice | (E plus Bob plus inert purification systems). Every original physical input qutrit is a forward wire across this partition. The device interaction and Bob's output processing are local on the receiving side. All original backward communication remains backward. Granting the receiving side the device/bath action only enlarges its local ability; the actual parties do not acquire bath access.

Replace EACH of these N forward input wires by the weighted teleportation construction(P1), with the SAME fixed p on all calls. Keep the original Alice input counter and Bob output counter. Condition on every new teleportation measurement succeeding, and finally on counter outcomes u,v. There are now NO forward wires in the completed comparison protocol.

Along each original input-charge history the inserted diagonal filters contribute a product p0 for every vacuum input and pc for every colored input. The coefficient operator in a fixed total-u sector therefore satisfies the EXACT identity

    W_(u,v)^(input-filtered)=c_u(p) W_(u,v),
    c_u(p)=p0^(N-u) pc^u.                            (P2)

This holds even with arbitrary adaptive quantum feedback: the intervening operations need not commute with the filters. Expand their port indices; the scalar product is the SAME for every term with total count u. The inserted filter commutes with its own charge-counter update. No independence or stochastic interpretation of histories is invoked.

The selected comparison branch thus has Bell weight c_u(p)^2 F_(u,v). Apply the completed-no-forward lemma(L1):

    c_u(p)^2 F_(u,v)<=1/K^2.                         (P3)

The comparison p can be chosen separately for each bound on a fixed(u,v); it is fixed BEFORE that comparison protocol runs and is independent of the fresh source. This is not feedback from a future count.

For x=u/N choose p0=1-x,pc=x/2. Then c_u=2^[-N f(x)], where

    f(x)=h2(x)+x,

with the endpoint convention0^0=1. Therefore

    F_(u,v)<=2^[2N f(u/N)]/K^2.                      (P4)

## 6. Second cut: pay the total output charge

Now use the distinct FIXED mathematical partition (Alice plus E plus inert purification) | Bob. The same physical interaction acts locally on the sender side. Each physical outgoing qutrit B is the only original forward wire across this cut. Replace these N wires by(P1), BEFORE Bob's output-counter update and his next original operation. Keep the same original input counter. Both counters remain local to their respective parties and are selected only in the unnormalized branch at the end.

The all-success comparison coefficient in a fixed output-count sector is p0^(N-v)pc^v times W_(u,v). Applying(L1) and optimizing p0=1-v/N,pc=v/(2N), independently of the first comparison, gives

    F_(u,v)<=2^[2N f(v/N)]/K^2.                      (P5)

This uses the SAME actual branch F_(u,v) as(P4), under a different proof partition. The bath is never physically moved, and Alice and Bob do not exchange a count or a success flag forward. Arbitrary initial bath/laboratory entanglement is simply an allowed initial preshare across EACH of these two mathematical cuts. Freshness holds across both.

Combining(P4),(P5),

    F_(u,v)<=2^[2N min{f(u/N),f(v/N)}]/K^2.           (P6)

If u+v<=N, at least one of u/N,v/N is at most1/2. On[0,1/2], f is increasing and f(1/2)=3/2. Hence the minimum in(P6) is at most3/2 and EVERY nonzero branch obeys

    F_(u,v)<=8^N/K^2.                               (P7)

There is no assumption that f is monotone over its full domain; its decrease above2/3 is irrelevant to this argument.

## 7. Sum, normality and what has actually been proved

Substitute(P7) into(C3), with at most m_N nonzero pairs:

    F_e <=m_N sum F_(u,v)<=m_N^2 8^N/K^2.

This proves the proposed(T1) provided the exact counter/filter/no-forward construction is upheld by fresh criticism. It is already uniform over N-dependent normal initial resources and arbitrary auxiliary dimensions: finite ports and counters are all that enter the constants. Normal quantum instruments/purifications and bounded Bell effects suffice. There is no partial trace of an infinite identity, relative-entropy continuity limit, initial-resource rank factor or implicit finite bath.

For a normal strategy defined as a trace-norm limit of finite backward/local circuits at this fixed horizon, the same finite-dimensional counter instruments and virtual teleportation maps are bounded normal maps. Their composed output states and Bell probabilities converge. The finite-N bound is independent of the approximant, so passes to the limit. Arbitrary nonconvergent/nonnormal processes are not coded protocols. Infinite outcomes or auxiliary entropy are not themselves obstructions when the admitted normal strategy exists.

No all-resource positive-beta bound is claimed here: V_beta has nonzero colored-to-colored diagonal blocks i beta I, so(C2) fails. Retaining that amplitude, rather than asserting the beta0 support law at positive beta, is necessary for an extension. Nor does(T1) give a matching lower code or terminal-bath return. The inherited lower at beta0 is a separate audited corpus result, not re-proved here.

## 8. Critical falsifiers, costs and predecessor challenge

The proof would fail if: coherent counters do not yield(C1) under a legal adaptive circuit; inserted weighted teleportation does not implement D_p with both square roots; a selected unnormalized no-forward branch can exceed1/K^2 despite fresh source independence; different histories of a fixed count acquire different filter factors; an extra forward signal is supplied; or a colored/colored amplitude is omitted at positive beta. These are exact, local statements suitable for adversarial diagnostics and fresh proof review.

Weighted postselected teleportation, no-signalling and amplitude Cauchy are established tools. The candidate contribution is their evaluated two-cut/sector use in this persistent device with unrestricted initial entanglement. Mathematical priority is UNKNOWN. Before this construction, generalized entropy accumulation and information-disturbance/time-reversal sources were checked: their hypotheses are not imported here. In particular a nonlocal Bell-success filter is never treated as a legal causal operation, and an inaccessible bath purifier is never dropped from an alleged product-channel reduction. Generic predecessor review remains necessary.

All N actual device calls count. The proof grants unlimited initial normal resources and backward bandwidth; it does not acquire them, prepare an apparatus or supply free real forward communication. Precision, preparation, error correction, control, reset, hardware energy, practical value and efficient useful encoders remain UNACQUIRED/UNKNOWN. A polynomial strong-converse estimate is an analytic obstruction, not a civilization-changing practical operation. External correctness and historical novelty remain unestablished; programme mission NOT_ACHIEVED.
