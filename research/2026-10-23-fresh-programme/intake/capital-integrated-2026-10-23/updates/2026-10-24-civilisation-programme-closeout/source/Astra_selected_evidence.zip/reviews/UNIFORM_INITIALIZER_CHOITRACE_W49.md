# Frozen full V1 hash-specific audit

Reviewed `work/workers/w19_dose_matrix/coherent_initializer_invention/FULL_PROOF_V1.md`,
SHA256 `1556727069358baa8838813d3364eb2e33869dd32cc6d04df682a4dc868328cc`.
Verdict: **NO BLOCKING DEFECT FOUND IN THE FULL HASH-SPECIFIC RECONSTRUCTION**.

I read the entire frozen full proof after independently reconstructing the
initial construction at SHA38951ca5e5ff13929abeaa15f8675bc46d5f6f0ff85a3b3c07d289060d1d2d47.
`INDEPENDENT_AUDIT.md` supplies the complete algebraic reconstruction,
resource boundary, exact root identity and independently written finite checks.
The full V1 preserves that trace/CP theorem and explicitly includes the
same-global-constant deterministic-comb extension that this worker and w36
separately reconstructed. No theorem-changing delta or new gap was found.

The all-normal initializer quantifier is uniform even when tau depends on
N. The bath is product with the ENTIRE initial laboratory resource; freshness
of the logical input alone would not be sufficient. The inaccessible bath
purifier may be retained in the complement. Every call uses the same evolving
bath. No initial coordinate cutoff, depth/entropy bound or classicalized
history enters.

I verified the unnormalized-Choi trace convention, last-to-first Heisenberg
iteration, positive finite trace bound, the exact nonpositive root correction,
legality of the optimized p, and the arbitrary CPTP logical K^-2 overlap.
The deterministic difference process uses C_N=H_b^N at ALL prefixes, has
positive intermediate operators by partial trace and scalar initial value1,
and obeys the causal trace equations. Inserting a normalized legal strategy
preserves its mixture interpretation. Replacer outputs plus backward-only
communication and source-independent preshares cannot signal Alice's input
to Bob, so the reference/receiver product used in K^-2 is justified.
Normal infinite local memories do not change this finite-port positive
process argument. All final outputs are unconditional and TP.

The old t-optimized fixed-normal graph exponent can be numerically smaller
than this trace exponent at intermediate beta; full V1 correctly retains
that narrower-regime result. Initial bath-lab correlated resources remain
outside this proof and continue to require separate analysis. External
mathematical acceptance, novelty and physical/practical benefit remain
UNKNOWN. The finite diagnostics do not alter those statuses.
