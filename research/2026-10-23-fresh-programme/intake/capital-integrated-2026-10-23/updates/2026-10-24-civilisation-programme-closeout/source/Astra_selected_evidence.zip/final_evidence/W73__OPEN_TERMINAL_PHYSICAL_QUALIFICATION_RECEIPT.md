# Separate leakage/settling qualification receipt

24 October 2026. Read in full and SHA256-bound W75's
`work/workers/w75_fresh_physical_inventor/instrument_graph_ports/OPEN_TERMINAL_QUALIFICATION.md`,
SHA256 `149fb305e31dd169f00fa8f74e7cae7b2ad0382df85fe5043034db8a5d034740`.
Its standalone `replay_instrument.py` is SHA256
`b0c36f6e4f1b64c2eca71ba0b11ad0ade124521443e8fdcdc0c8944735534e55`;
raw `REPLAY_RESULTS.json` is SHA256
`fc1412f0c34a89eb70cb9898f3440e37a584a300eeb3eee3b7718f7bf57a4a48`.
This is inheritance of a separately derived producer qualification,
not an independent full proof review or acquired physical measurement.

The frozen ideal-open baseline119806 remains unchanged. It measures a
selected source current after full settling with zero off-load. W75
examines the received-current variant: those currents are equal and
opposite in the ideal zero-leak model, but are different once shunts
to the environment are introduced. Therefore the new law is not silently
claimed as a robustness theorem for the original source-current test.

For equal stars with a selected leaf in each, branch conductance
p=a/(1+a r_s), off-conductance g from EVERY unselected terminal including
the hubs to ground, and H=g+(d-1)ag/(a+g), the exact received core-present
DC mean magnitude is

    J_g=a p^2 A/[(p+H)(p+H+2a)].

The core-absent receiving-star mean is zero. At fixed g>0 this contrast
is Theta(d^-2); constant relative contrast requires aggregate H=O(a),
or dg=O(a) in the small-leakage regime. This is a mean-signal statement,
not an all-data lower bound: covariance, offset calibration, other
commands and receiver choices may carry additional information.

For a different explicit zero-leak model, attach capacitance C to each
unselected leaf, zero capacitance to hubs, and acquire/reset ALL capacitor
voltages to zero before the selected-pair step. The exact common and
difference time constants are

    tau_c=C[p+(d-1)a]/(ap),
    tau_d=C[p+(d+1)a]/[a(p+2a)].

These are Theta(d) settling times. They do NOT imply a Theta(d) minimum
discrimination duration. W75 derives the exact early waveform and, under
a separately stipulated fixed white receiver spectrum S, its mean-only
KL for 1<<T<<d:

    D_mean(T)~a^2p^4A^2 T^5/(40 S C^4 d^4).

This waveform can reach constant mean KL at T=Theta(d^(4/5)), before
full settling. This is model-/reset-/waveform-specific, not a bound
against every schedule, transient detector, correlated-noise observation
or alternate preparation. Resetting/charging order-d capacitances itself
has preparation, current and energy costs; those remain unacquired.

The manufacturer context and W75 finite nodal/ODE controls support only
their stated scopes. Neither worker acquired actual switch leakage,
capacitance, source/sensor spectra, reset tolerance, calibration or
wall-clock/Joule advantage. The ordinary ideal-open comparator is a
required fair benchmark; its action count alone proves neither its own
affordability nor an adaptive physical advantage. Physical NOT_ACQUIRED;
priority/practical advantage UNKNOWN; broad mission NOT_ACHIEVED.
