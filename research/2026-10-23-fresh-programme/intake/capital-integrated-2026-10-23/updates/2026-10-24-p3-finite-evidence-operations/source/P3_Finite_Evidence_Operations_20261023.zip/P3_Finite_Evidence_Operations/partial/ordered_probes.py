"""Reusable passive-probe estimates from randomly timed source observations.

This implements the established uniformization construction proved in
ORDERED_PROBES.md. It does not implement a physical source, certify passivity,
or establish a research benchmark advantage. Clock generation and arithmetic
use ordinary binary64; scientific adapters must budget their own precision,
measurement error, independence, preparation, and elapsed observation time.

The observation callback returns a categorical mark in {0,...,k}; conditional
on each source trajectory its mark law must have the calibrated feature
probabilities. For a directly observed region label it need not randomize.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
import math
import random
from typing import Any, Callable, Sequence


@dataclass(frozen=True)
class WordLibrary:
    words: tuple[tuple[int, ...], ...]
    horizon: float
    rate: float
    alphabet_size: int

    @property
    def source_trials(self) -> int:
        return len(self.words)

    @property
    def observed_marks(self) -> int:
        return sum(map(len, self.words))

    @property
    def scheduled_source_time(self) -> float:
        """Sum of complete horizons, not a claim about actual wall time."""
        return self.source_trials * self.horizon


def acquire(
    start_trial: Callable[[int], Any],
    observe_mark: Callable[[Any, float, random.Random], int],
    *,
    trials: int,
    horizon: float,
    rate: float,
    alphabet_size: int,
    seed: int,
) -> WordLibrary:
    """Schedule one Poisson observation stream per independently reset trial.

    Source callbacks, not this function, are responsible for independent
    trials, nonperturbing observation, and handling physical scheduling. A
    callback can inspect a saved path, or advance/observe an actual source.
    Trial preparation and full elapsed horizons must be charged externally.
    """
    if trials <= 0 or horizon < 0 or rate <= 0 or alphabet_size < 1:
        raise ValueError("Require trials>0, horizon>=0, rate>0, k>=1")
    if not math.isfinite(horizon) or not math.isfinite(rate):
        raise ValueError("Horizon and rate must be finite")
    clock_rng = random.Random(seed)
    mark_rng = random.Random(seed ^ 0xA570B3)
    records: list[tuple[int, ...]] = []
    for trial in range(trials):
        source = start_trial(trial)
        time = 0.0
        word: list[int] = []
        while True:
            time += clock_rng.expovariate(rate)
            if time >= horizon:
                break
            mark = observe_mark(source, time, mark_rng)
            if not isinstance(mark, int) or not 0 <= mark <= alphabet_size:
                raise ValueError("Observation callback returned invalid mark")
            word.append(mark)
        records.append(tuple(word))
    return WordLibrary(tuple(records), horizon, rate, alphabet_size)


def categorical_mark(features: Sequence[float], rng: random.Random) -> int:
    """Draw calibrated g_i marks; mark 0 is the slack probability.

    For vector access, retaining features and conditionally averaging over
    this randomness is a stronger variance baseline. Floating-point features
    are accepted only when nonnegative and their sum is at most 1.
    """
    if any(not math.isfinite(v) or v < 0 for v in features):
        raise ValueError("Features must be finite and nonnegative")
    if math.fsum(features) > 1.0:
        raise ValueError("Feature sum exceeds one")
    uniform = rng.random()
    cumulative = 0.0
    for i, probability in enumerate(features, 1):
        cumulative += probability
        if uniform < cumulative:
            return i
    return 0


def row_product(row: Sequence[float], matrix: Sequence[Sequence[float]]) -> list[float]:
    q = len(row)
    return [math.fsum(row[a] * matrix[a][b] for a in range(q)) for b in range(q)]


def check_program(
    matrices: Sequence[Sequence[Sequence[float]]],
    alpha: Sequence[float],
    reward: Sequence[float],
    *,
    alphabet_size: int,
) -> None:
    """Input sanity checks; tolerance is not a numerical error certificate."""
    q = len(alpha)
    if q == 0 or len(reward) != q or len(matrices) != alphabet_size:
        raise ValueError("Inconsistent program dimensions")
    if any(not math.isfinite(a) or a < 0 for a in alpha):
        raise ValueError("Initial distribution must be nonnegative and finite")
    if abs(math.fsum(alpha) - 1.0) > 1e-12:
        raise ValueError("Initial distribution must sum to one")
    if any(not math.isfinite(r) or not 0 <= r <= 1 for r in reward):
        raise ValueError("Reward must lie in [0,1]")
    for matrix in matrices:
        if len(matrix) != q:
            raise ValueError("Matrix must have q rows")
        for row in matrix:
            if len(row) != q or any(not math.isfinite(x) or x < 0 for x in row):
                raise ValueError("Invalid stochastic row")
            if abs(math.fsum(row) - 1.0) > 1e-12:
                raise ValueError("Matrix row must sum to one")


def word_value(
    word: Sequence[int],
    matrices: Sequence[Sequence[Sequence[float]]],
    alpha: Sequence[float],
    reward: Sequence[float],
) -> float:
    """Evaluate alpha P_word reward; matrices exclude identity mark 0."""
    row = list(alpha)
    for mark in word:
        if mark:
            row = row_product(row, matrices[mark - 1])
    return math.fsum(a * r for a, r in zip(row, reward))


def predict(
    library: WordLibrary,
    matrices: Sequence[Sequence[Sequence[float]]],
    alpha: Sequence[float],
    reward: Sequence[float],
    *,
    max_word_length: int | None = None,
) -> float:
    """Estimate endpoint reward; a long word contributes ZERO when truncated.

    The denominator remains the full trial count. Resampling/conditioning on
    short words is a different estimator and is not implemented here.
    """
    check_program(matrices, alpha, reward, alphabet_size=library.alphabet_size)
    if max_word_length is not None and max_word_length < 0:
        raise ValueError("Negative truncation length")
    if not library.words:
        raise ValueError("Empty library")
    return math.fsum(
        word_value(word, matrices, alpha, reward)
        if max_word_length is None or len(word) <= max_word_length else 0.0
        for word in library.words
    ) / len(library.words)


def poisson_tail_chernoff(mean: float, max_length: int) -> float:
    """Analytic upper bound on P(Poisson(mean)>max_length), in binary64."""
    if mean < 0 or max_length < 0:
        raise ValueError("Negative mean or length")
    if mean == 0:
        return 0.0
    threshold = max_length + 1
    if threshold <= mean:
        return 1.0
    exponent = -mean + threshold * (1 + math.log(mean) - math.log(threshold))
    return min(1.0, math.exp(exponent))


def uniform_budget(
    *, q: int, k: int, rate: float, horizon: float, epsilon: float, delta: float
) -> dict[str, float | int]:
    """Conservative all-program statistical budget from equation (7).

    Sensor, source-law, program-calibration, finite scheduling and arithmetic
    errors must receive additional budgets; this does not include them.
    """
    if q < 1 or k < 1 or rate < 0 or horizon < 0:
        raise ValueError("Invalid dimensions or rates")
    if not 0 < epsilon < 1 or not 0 < delta < 1:
        raise ValueError("epsilon and delta must lie in (0,1)")
    mean = rate * horizon
    if q == 1 or mean == 0:
        return {"trials": 0, "max_length": 0, "expected_marks": 0.0}
    length = max(1, math.ceil(mean))
    while poisson_tail_chernoff(mean, length) > epsilon / 3:
        length += 1
    resolution = math.ceil(12 * (q - 1) * length / epsilon)
    dimension = k * q * (q - 1)
    trials = math.ceil(9 / (2 * epsilon**2) *
                       (math.log(2 / delta) + dimension * math.log(resolution + 1)))
    return {
        "trials": trials,
        "max_length": length,
        "grid_denominator": resolution,
        "poisson_tail_bound": poisson_tail_chernoff(mean, length),
        "expected_marks": trials * mean,
        "scheduled_source_time": trials * horizon,
    }


def rate_change_log_second_moment(old_rate: float, new_rate: float, horizon: float) -> float:
    if old_rate <= 0 or new_rate < 0 or horizon < 0:
        raise ValueError("Require old_rate>0, new_rate>=0, horizon>=0")
    return horizon * (new_rate - old_rate)**2 / old_rate


def algebraic_check() -> dict[str, object]:
    """Counterexample check only; no scientific-data/transfer performance claim."""
    p1 = ((0, 1, 0), (0, 1, 0), (0, 0, 1))
    p2 = ((1, 0, 0), (0, 0, 1), (0, 0, 1))
    alpha, reward = (1, 0, 0), (0, 0, 1)
    check_program((p1, p2), alpha, reward, alphabet_size=2)
    forward = word_value((1, 2), (p1, p2), alpha, reward)
    reverse = word_value((2, 1), (p1, p2), alpha, reward)
    assert forward == 1 and reverse == 0
    return {
        "kind": "Algebraic sanity check, not a benchmark",
        "forward_word": forward,
        "reverse_word": reverse,
        "continuous_forward_probability_at_Lambda_H_2": (1 - math.exp(-1))**2,
        "continuous_reverse_probability": 0,
        "conservative_uniform_budget_example": uniform_budget(
            q=3, k=2, rate=2, horizon=1, epsilon=0.1, delta=0.05),
        "log_second_moment_rate_2_to_10_H_1": rate_change_log_second_moment(2, 10, 1),
    }


if __name__ == "__main__":
    print(json.dumps(algebraic_check(), indent=2))
