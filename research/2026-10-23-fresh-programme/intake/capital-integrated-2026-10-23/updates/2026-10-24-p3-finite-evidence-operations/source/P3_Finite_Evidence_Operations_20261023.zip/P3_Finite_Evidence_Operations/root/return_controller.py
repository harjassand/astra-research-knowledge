"""Finite-horizon minimax controller from a least return-kernel completion.

The objective is probability of collecting a chosen number of return events.
Only event/no-event observations are used; other terminal rewards are outside
the theorem. Exact data or coordinatewise lower first-return data are required.
Joint mass constraints generally have no universal least completion.
"""
from fractions import Fraction as F
from renewal import trie_completion,validate_first_return


def synthesize_count_controller_mass(kernel,alphabet,horizon,required_events):
    """Equivalent Bellman recursion in unnormalized mass, with no f/s division."""
    if type(horizon) is not int or horizon<0 or type(required_events) is not int or required_events<1:
        raise ValueError('Invalid horizon/event objective')
    f=validate_first_return(kernel)
    alphabet=tuple(alphabet)
    if not alphabet or any(a not in alphabet for w in f for a in w):
        raise ValueError('Incomplete action alphabet')
    states=sorted({()}|{w[:i] for w in f for i in range(1,len(w))},
                  key=lambda w:(len(w),w))
    mass={(0,u,need):F(0) for u in states for need in range(1,required_events+1)}
    policy={}
    for t in range(1,horizon+1):
        for need in range(1,required_events+1):
            for u in states:
                best=F(-1)
                for a in alphabet:
                    v=u+(a,)
                    after_event=F(1) if need==1 else mass[t-1,(),need-1]
                    score=f.get(v,F(0))*after_event+mass.get((t-1,v,need),F(0))
                    if score>best:
                        best,chosen=score,a
                mass[t,u,need]=best
                policy[t,u,need]=chosen
    return {'value':mass[horizon,(),required_events],
            'mass_values':mass,'policy':policy,'states':states}


def synthesize_count_controller(kernel,alphabet,horizon,required_events):
    if type(horizon) is not int or horizon<0 or type(required_events) is not int or required_events<1:
        raise ValueError('Invalid horizon/event objective')
    f=validate_first_return(kernel)
    states,matrices=trie_completion(f,alphabet)
    # On no event, an observed action-prefix state has at most one successor.
    values={(0,state,need):F(0) for state in range(len(states))
            for need in range(1,required_events+1)}
    policy={}
    transitions={}
    for a,p in matrices.items():
        for state in range(len(states)):
            event=p[0][state]
            continue_options=[(i,p[i][state]) for i in range(1,len(states)) if p[i][state]]
            if len(continue_options)>1:
                raise AssertionError('Trie no-event state must be observable')
            transitions[state,a]=(event,continue_options[0] if continue_options else None)
    for time_left in range(1,horizon+1):
        for need in range(1,required_events+1):
            for state in range(len(states)):
                best=F(-1)
                for a in matrices:
                    event,continuation=transitions[state,a]
                    score=event*(F(1) if need==1 else values[time_left-1,0,need-1])
                    if continuation is not None:
                        nxt,weight=continuation
                        score+=weight*values[time_left-1,nxt,need]
                    if score>best:
                        best,chosen=score,a
                values[time_left,state,need]=best
                policy[time_left,state,need]=chosen
    return {'value':values[horizon,0,required_events],
            'values':values,'policy':policy,'states':states,
            'matrices':matrices,'transitions':transitions,
            'scope':'Count-return success; event/no-event controller; no negative or no-event rewards'}


def all_policy_trees(alphabet,horizon):
    """Exhaustive independent comparison for tiny verification horizons only."""
    if horizon==0:
        return [None]
    sub=all_policy_trees(alphabet,horizon-1)
    return [(action,none,event) for action in alphabet for none in sub for event in sub]


def evaluate_tree(tree,matrices,need,state=None):
    """Full hidden-state unnormalized forward branching, no renewal compiler."""
    if need<=0:
        return sum(state) if state is not None else F(1)
    if tree is None:
        return F(0)
    size=len(next(iter(matrices.values())))
    if state is None:
        state=[F(1)]+[F(0)]*(size-1)
    action,no_tree,yes_tree=tree
    p=matrices[action]
    after=[sum((p[i][j]*state[j] for j in range(size)),F(0)) for i in range(size)]
    event=[after[0]]+[F(0)]*(size-1)
    after[0]=F(0)
    return (evaluate_tree(yes_tree,matrices,need-1,event)+
            evaluate_tree(no_tree,matrices,need,after))
