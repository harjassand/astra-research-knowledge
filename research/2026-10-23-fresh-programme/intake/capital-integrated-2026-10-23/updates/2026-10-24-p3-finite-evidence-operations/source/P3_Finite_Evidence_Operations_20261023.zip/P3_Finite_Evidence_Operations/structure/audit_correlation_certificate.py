"""Frozen boundary checks for the parent's exact correlation certificate.

This is a small authored algebraic audit, not a benchmark or transfer test.
The direct matrix endpoint oracle below does not use root's form machinery.
"""

from fractions import Fraction as F
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / "root" / "correlation_certificate.py"
CONTRACT = HERE / "CORRELATION_AUDIT_CONTRACT.json"
EXPECTED_CORE = "8c03a5841c8cbbe40112b0b61591b406749479103edc63cf5b2a0fcf4bafc798"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def direct_endpoint(matrices, pi, observable, word):
    state = list(observable)
    for a in reversed(word):
        state = [sum((x * y for x, y in zip(row, state)), F(0))
                 for row in matrices[a]]
    return sum((p * f * x for p, f, x in zip(pi, observable, state)), F(0))


def inside(interval_result, exact):
    return all(interval_result[lo] <= exact <= interval_result[hi]
               for lo, hi in (
                   ("lower", "upper"),
                   ("two_sided_lower", "two_sided_upper"),
                   ("one_sided_lower", "one_sided_upper")))


def main():
    core_hash = digest(ROOT)
    if core_hash != EXPECTED_CORE:
        raise RuntimeError("Root code changed after inspection; no silent audit of a different version")
    spec = importlib.util.spec_from_file_location("p3_correlation_audit_root", ROOT)
    cc = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(cc)
    frozen = json.loads(CONTRACT.read_text())
    rows = []

    def record(name, ok, **details):
        rows.append({"name": name, "pass": bool(ok), **details})

    def expect_raise(name, action, exception=(ValueError, TypeError)):
        try:
            action()
        except exception as exc:
            record(name, True, exception=type(exc).__name__, message=str(exc))
        except Exception as exc:
            record(name, False, exception=type(exc).__name__, message=str(exc))
        else:
            record(name, False, message="No required rejection")

    def display_interval(result):
        return {k: str(result[k]) for k in (
            "lower", "upper", "two_sided_lower", "two_sided_upper",
            "one_sided_lower", "one_sided_upper",
            "linear_radius", "cross_remainder")}

    # The frozen string action names are mapped to the integer API a=0,b=1.
    one = cc.Representation([()], {0: [[F(3, 2)]]})
    empty = one.certify((), cc.Correlations({(): (F(3, 4), F(1))}), sqrt_bits=7)
    record("empty_target",
           empty["lower"] == F(3, 4) and empty["upper"] == F(1)
           and empty["cross_remainder"] == 0,
           interval=display_interval(empty))
    data = cc.Correlations({(): (F(3, 4), F(1)),
                            (0,): (F(1, 2), F(1, 2)),
                            (0, 0): (F(1, 4), F(1, 4))})
    result = one.certify((0,), data, sqrt_bits=7)
    record("one_step_shared_word_cancellation",
           result["forms"]["corrected"] == {(0,): F(1)}
           and result["linear_radius"] == 0
           and result["cross_remainder"] == 0
           and result["lower"] == result["upper"] == F(1, 2),
           interval=display_interval(result))

    singular = frozen["checks"][2]
    m = {0: [[F(x) for x in row] for row in singular["physical_source"]["P_a"]]}
    pi = list(map(F, singular["physical_source"]["pi"]))
    obs = list(map(F, singular["physical_source"]["f"]))
    t = [[F(x) for x in row] for row in singular["T"]]
    rep = cc.Representation([(), (0,)], {0: t})
    raw = {w: direct_endpoint(m, pi, obs, w) for w in rep.acquisition_words()}
    intervals = cc.Correlations({w: (v, v) for w, v in raw.items()})
    record("true_Gram_is_singular",
           raw[()] * raw[(0, 0)] - raw[(0,)] ** 2 == 0)
    for length in (3, 4):
        target = (0,) * length
        q = direct_endpoint(m, pi, obs, target)
        result = rep.certify(target, intervals, sqrt_bits=7)
        record(f"singular_arbitrary_T_length_{length}",
               q == F(1, 2 ** length) and inside(result, q),
               exact=str(q), interval=display_interval(result))

    negative = frozen["checks"][3]
    src = negative["physical_source"]
    m = {a: [[F(x) for x in row] for row in src[name]]
         for a, name in enumerate(("P_a", "P_b"))}
    pi, obs = list(map(F, src["pi"])), list(map(F, src["f"]))
    zero = [[F(0), F(0)], [F(0), F(0)]]
    rep = cc.Representation([(), (0,)], {0: zero, 1: zero})
    raw = {w: direct_endpoint(m, pi, obs, w) for w in rep.acquisition_words()}
    data = cc.Correlations({w: (v, v) for w, v in raw.items()})
    q = direct_endpoint(m, pi, obs, (0, 1))
    result = rep.certify((0, 1), data, sqrt_bits=7)
    record("negative_mixed_correlation",
           q == F(-3, 200) and any(v < 0 for v in raw.values())
           and inside(result, q) and result["lower"] < 0,
           exact=str(q), interval=display_interval(result))

    rep = cc.Representation([()], {0: [[0]]})
    expect_raise("negative_residual_upper", lambda: rep.certify(
        (0, 0), cc.Correlations({(): (1, 1), (0,): (F(1, 2), F(1, 2)),
                                (0, 0): (F(-1, 4), F(-1, 8))})))
    crossing = rep.certify((0, 0), cc.Correlations(
        {(): (1, 1), (0,): (F(1, 2), F(1, 2)),
         (0, 0): (F(-1, 8), F(1, 4))}), sqrt_bits=7)
    record("crossing_zero_residual_interval", inside(crossing, F(1, 4)),
           interval=display_interval(crossing))
    expect_raise("empty_input_interval",
                 lambda: cc.Correlations({(): (F(3, 4), F(1, 2))}))

    for x in map(F, frozen["checks"][5]["values"]):
        for bits in frozen["checks"][5]["bits"]:
            r = cc.sqrt_upper(x, bits)
            step = F(1, 1 << bits)
            record(f"sqrt_upper_{x}_bits_{bits}",
                   r >= 0 and r * r >= x and
                   (r == 0 or (r - step) ** 2 < x),
                   upper=str(r))
    expect_raise("negative_radicand", lambda: cc.sqrt_upper(F(-1, 3), 7))
    expect_raise("negative_precision", lambda: cc.sqrt_upper(F(1, 3), -1))

    reverse = cc.Correlations({(0, 1): (F(1, 4), F(3, 4)),
                               (1, 0): (F(1, 2), F(1))})
    record("reverse_intersection",
           reverse.evaluate({(0, 1): F(1)}) == (F(1, 2), F(3, 4))
           and reverse.evaluate({(0, 1): F(1), (1, 0): F(-1)}) == (0, 0))
    expect_raise("conflicting_reverse_exact_inputs",
                 lambda: cc.Correlations({(0, 1): (F(1, 3), F(1, 3)),
                                          (1, 0): (F(1, 2), F(1, 2))}))
    expect_raise("float_transition",
                 lambda: cc.Representation([()], {0: [[0.5]]}), TypeError)
    expect_raise("float_confidence_endpoint",
                 lambda: cc.Correlations({(): (0.5, F(1))}), TypeError)
    expect_raise("bool_transition",
                 lambda: cc.Representation([()], {0: [[True]]}), TypeError)
    record("root_core_unchanged", digest(ROOT) == EXPECTED_CORE)

    output = {
        "scope": frozen["scope"], "contract_sha256": digest(CONTRACT),
        "root_core_sha256": core_hash, "checks": rows,
        "total_checks": len(rows),
        "failures": [r["name"] for r in rows if not r["pass"]],
        "status": "PASS" if all(r["pass"] for r in rows) else "FAIL",
        "prior_exposure": frozen["prior_exposure"],
    }
    (HERE / "CORRELATION_AUDIT_RESULTS.json").write_text(
        json.dumps(output, indent=2) + "\n")
    print(json.dumps({k: output[k] for k in
                      ("status", "total_checks", "failures")}, indent=2))
    if output["failures"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
