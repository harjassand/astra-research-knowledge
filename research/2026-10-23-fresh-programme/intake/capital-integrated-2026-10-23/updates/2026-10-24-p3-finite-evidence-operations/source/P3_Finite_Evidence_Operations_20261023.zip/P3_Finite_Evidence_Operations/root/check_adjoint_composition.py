from fractions import Fraction as F
from pathlib import Path
import json,hashlib,time
from correlation_certificate import mv
from adjoint_correlation import AdjointRepresentation,AdjointCorrelations,adjoint_metric_certificate
from finite_variance import variance,second_moment,chebyshev_failure
from uniform_correlation import run_program
from metric_correlation import mm
from check_correlation import invert,projector,serialize,max_bits


def main():
    start=time.perf_counter()
    cp=Path(__file__).with_name('ADJOINT_CHECK_CONTRACT.json')
    contract=json.loads(cp.read_text())
    checks=[]
    def check(name,v): checks.append({'name':name,'pass':bool(v)})
    p0,pu,pv=map(projector,([1,1,1],[1,-1,0],[1,1,-2]))
    def combine(a,b):
        return [[p0[i][j]+a*pu[i][j]+b*pv[i][j] for j in range(3)] for i in range(3)]
    a,b=combine(F(1,16),F(1,64)),combine(F(1,32),F(1,8))
    s=[[F(v) for v in row] for row in [[1,0,0],[0,0,1],[0,1,0]]]
    b=mm(mm(s,b),s)
    matrices={0:mm(a,b),1:mm(b,a)}
    f=[F(2,3),F(-1,3),F(-1,3)]
    def corr(w,source=matrices):
        z=f
        for action in reversed(w): z=mv(source[action],z)
        return sum((x*y for x,y in zip(f,z)),F(0))/3
    dagger={0:1,1:0}
    empty=AdjointRepresentation([(),(0,)],{0:[[0,0],[0,0]],1:[[0,0],[0,0]]},dagger)
    words=empty.acquisition_words()
    data=AdjointCorrelations({w:(corr(w),corr(w)) for w in words},dagger)
    units=[(F(1),F(0)),(F(0),F(1))]
    def fit(data):
        center=lambda form:sum(data.evaluate(form),F(0))/2
        g=[[center(empty.inner_form(x,y)) for y in units] for x in units]
        gi=invert(g)
        ts={a:mm(gi,[[center(empty.inner_form(x,y,(a,))) for y in units] for x in units]) for a in dagger}
        return AdjointRepresentation(empty.basis,ts,dagger),g
    rep,g=fit(data)
    compiled=adjoint_metric_certificate(rep,data,g)
    target=tuple(contract['target'])
    cert=rep.certify(target,data)
    check('forward_sweep_is_not_selfadjoint',matrices[0]!=matrices[1])
    check('left_and_right_propagated_Grams_differ',corr((1,0))!=corr((0,1)))
    check('full_adjoint_word_alias',corr(target)==corr(tuple(dagger[a] for a in reversed(target))))
    check('pure_reversal_alias_is_invalid',corr(target)!=corr(target[::-1]))
    check('uniform_certificate_exact',compiled['status']=='CERTIFIED_UNDER_CONTRACT' and compiled['uniform_error']==0)
    check('corrected_program_target_exact',run_program(compiled,target)==corr(target)==cert['corrected_center'])
    check('target_unqueried',target not in words and tuple(dagger[a] for a in reversed(target)) not in words)
    n=len(target)+1
    direct=(n*corr(())+2*sum((corr(target[i:j]) for i in range(n) for j in range(i+1,n)),F(0)))/(n*n)
    var=variance(compiled,target,(0,0))
    check('finite_variance_composition_exact',var['variance_lower']==var['variance_upper']==direct)
    check('empty_schedule_is_single_observation',variance(compiled,(),(0,0))['variance_upper']==corr(()))
    bad=AdjointRepresentation(empty.basis,{0:[[F(3,100),F(1,100)],[0,F(1,50)]],
                                          1:[[-F(1,100),F(1,25)],[F(1,50),0]]},dagger)
    bc=bad.certify(target,data)
    check('arbitrary_nonsymmetric_fit_covered',bc['lower']<=corr(target)<=bc['upper'])
    delta=F(contract['reverse_bias'])
    actual={0:matrices[0],1:[[(1-delta)*matrices[1][i][j]+delta*p0[i][j] for j in range(3)] for i in range(3)]}
    intervals={}
    for w in words:
        c=corr(w,actual);rad=delta*w.count(1)
        intervals[w]=(max(F(-1),c-rad),min(F(1),c+rad))
        check('calibrated_query_'+str(w),intervals[w][0]<=corr(w)<=intervals[w][1])
    calibrated=AdjointCorrelations(intervals,dagger)
    crep,cg=fit(calibrated)
    cc=adjoint_metric_certificate(crep,calibrated,cg)
    forward=tuple(contract['calibrated_forward_target'])
    check('calibrated_finite_pool_certifies_true_forward_word',
          cc['status']=='CERTIFIED_UNDER_CONTRACT' and
          abs(run_program(cc,forward)-corr(forward))<=cc['uniform_error'])
    for invalid in ((False,),(0.0,)):
        try:run_program(compiled,invalid)
        except ValueError:check('strict_action_repair_'+str(invalid),True)
        else:check('strict_action_repair_'+str(invalid),False)
    result={'status':'PASS' if all(x['pass'] for x in checks) else 'FAIL',
            'scope':contract['scope'],'prior_exposure':contract['prior_exposure'],
            'contract_sha256':hashlib.sha256(cp.read_bytes()).hexdigest(),
            'checks':checks,'paid_exact_fixture_protocols':len(words),
            'paid_exact_fixture_composite_pulses':sum(map(len,words)),
            'elementary_stage_multiplier':2,
            'exact_variance':direct,'variance_result':var,
            'arbitrary_fit_certificate':{k:v for k,v in bc.items() if k!='forms'},
            'calibration_uniform_error':cc['uniform_error'],
            'calibration_psd_checks':cc['exact_psd_checks'],
            'maximum_recorded_rational_bits':max_bits([compiled,cc,bc,var]),
            'elapsed_seconds':time.perf_counter()-start}
    Path(__file__).with_name('ADJOINT_COMPOSITION_CHECK.json').write_text(json.dumps(serialize(result),indent=2)+'\n')
    print(json.dumps({'status':result['status'],'checks':len(checks),
                      'failures':[x['name'] for x in checks if not x['pass']],
                      'protocols':len(words),'variance':str(direct),
                      'calibration_uniform_error':float(cc['uniform_error']),
                      'max_bits':result['maximum_recorded_rational_bits'],
                      'elapsed_seconds':result['elapsed_seconds']},indent=2))
    if result['status']!='PASS':raise SystemExit(1)


if __name__=='__main__':main()
