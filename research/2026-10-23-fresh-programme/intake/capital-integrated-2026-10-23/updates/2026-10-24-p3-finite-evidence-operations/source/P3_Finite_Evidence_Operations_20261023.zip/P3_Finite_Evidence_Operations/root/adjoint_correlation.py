"""Same residual certificate with executable adjoints, not self-adjoint pulses.

The audited self-adjoint arithmetic is reused with guarded front doors. An action
alphabet comes with an involution a -> dagger(a).  Ideal dagger actions are
the true Hilbert adjoints.  Actual approximate implementations may acquire
intervals for ideal moments only with a separately justified finite-query bias
budget.  The code does not obtain that bias or common stationary preparation.
"""
from fractions import Fraction as F
from correlation_certificate import Representation, Correlations, exact, word, mv
from metric_correlation import _metric_certificate


def involution(mapping):
    out = dict(mapping)
    if not out or any(type(a) is not int or a < 0 or type(b) is not int or b < 0
                      for a,b in out.items()):
        raise ValueError('Nonnegative integer adjoint action map required')
    if any(out.get(b) != a for a,b in out.items()):
        raise ValueError('Adjoint map must be an involution on the whole alphabet')
    return out


def star(w, mapping):
    return tuple(mapping[a] for a in reversed(word(w)))


def canon(w, mapping):
    w=word(w)
    return min(w,star(w,mapping))


def linear_add(*forms):
    # Every input is already canonical under the SAME dagger map.  Plain
    # reverse-word aliasing would be incorrect for this interface.
    out={}
    for form in forms:
        for w,c in form.items(): out[w]=out.get(w,F(0))+exact(c)
    return {w:c for w,c in out.items() if c}


def linear_scale(c,form):
    c=exact(c)
    return {w:c*x for w,x in form.items() if c*x}


class AdjointCorrelations(Correlations):
    def __init__(self,intervals,dagger):
        self.dagger=involution(dagger)
        self.intervals={}
        for w,pair in intervals.items():
            w=canon(w,self.dagger)
            if len(pair)!=2: raise ValueError('Lower and upper interval required')
            lo,hi=map(exact,pair)
            if not -1<=lo<=hi<=1: raise ValueError('Correlation interval outside [-1,1]')
            if w in self.intervals:
                oldlo,oldhi=self.intervals[w]
                lo,hi=max(lo,oldlo),min(hi,oldhi)
                if lo>hi: raise ValueError('Conflicting full-adjoint moment aliases')
            self.intervals[w]=(lo,hi)

    def evaluate(self,form):
        combined={}
        for w,c in form.items():
            w=canon(w,self.dagger)
            combined[w]=combined.get(w,F(0))+exact(c)
        lo=hi=F(0)
        for w,c in combined.items():
            if not c: continue
            a,b=self.intervals[w]
            if c<0: a,b=b,a
            lo+=c*a; hi+=c*b
        return lo,hi


class AdjointRepresentation(Representation):
    def __init__(self,basis,transitions,dagger):
        self.dagger=involution(dagger)
        super().__init__(basis,transitions)
        if set(self.transitions)!=set(self.dagger):
            raise ValueError('Fit all action and adjoint labels')

    def inner_form(self,left,right,middle=()):
        if len(left)!=len(self.basis) or len(right)!=len(self.basis):
            raise ValueError('Wrong coefficient dimension')
        middle=word(middle)
        out={}
        for i,x in enumerate(left):
            for j,y in enumerate(right):
                c=exact(x)*exact(y)
                if c:
                    w=canon(star(self.basis[i],self.dagger)+middle+self.basis[j],self.dagger)
                    out[w]=out.get(w,F(0))+c
        return {w:c for w,c in out.items() if c}

    def residual_form(self,a,z):
        tz=mv(self.transitions[a],z)
        return linear_add(self.inner_form(z,z,(self.dagger[a],a)),
                          linear_scale(-2,self.inner_form(tz,z,(a,))),
                          self.inner_form(tz,tz))

    def defect_form(self,a,left,right):
        return linear_add(self.inner_form(left,right,(a,)),
                          linear_scale(-1,self.inner_form(left,mv(self.transitions[a],right))))

    def acquisition_words(self):
        out=set()
        for u in self.basis:
            for v in self.basis:
                out.add(canon(star(u,self.dagger)+v,self.dagger))
                for a in self.transitions:
                    out.add(canon(star(u,self.dagger)+(a,)+v,self.dagger))
                    out.add(canon(star(u,self.dagger)+(self.dagger[a],a)+v,self.dagger))
        return tuple(sorted(out,key=lambda w:(len(w),w)))

    def forms_for(self,target):
        target=word(target)
        if any(a not in self.transitions for a in target):
            raise ValueError('Unacquired target action')
        n=len(target)
        left=[self.e0]
        for a in target: left.append(mv(self.transitions[self.dagger[a]],left[-1]))
        right=[None]*n+[self.e0]
        for j in range(n-1,-1,-1): right[j]=mv(self.transitions[target[j]],right[j+1])
        prediction=self.inner_form(self.e0,right[0])
        defect=linear_add(*(self.defect_form(a,left[j],right[j+1]) for j,a in enumerate(target)))
        return {'prediction':prediction,'correction':defect,
                'corrected':linear_add(prediction,defect),
                'left_residuals':[self.residual_form(self.dagger[a],left[j]) for j,a in enumerate(target)],
                'right_residuals':[self.residual_form(a,right[j+1]) for j,a in enumerate(target)],
                'left_coefficients':left,'right_coefficients':right}

    def certify(self,target,data,sqrt_bits=80):
        if not isinstance(data,AdjointCorrelations) or data.dagger!=self.dagger:
            raise ValueError('Data and representation must have the same adjoint map')
        return super().certify(target,data,sqrt_bits)


def adjoint_metric_certificate(rep,data,metric,precision=40,sqrt_bits=80):
    if not isinstance(rep,AdjointRepresentation) or not isinstance(data,AdjointCorrelations):
        raise TypeError('Explicit adjoint representation and data required')
    if rep.dagger!=data.dagger: raise ValueError('Adjoint maps disagree')
    out=_metric_certificate(rep,data,metric,precision,sqrt_bits)
    if out['status']=='CERTIFIED_UNDER_CONTRACT':
        d=len(rep.basis)
        for a,block in out['program'].items():
            u=rep.transitions[rep.dagger[a]]
            for i in range(d):
                for j in range(d): block[i][j]=u[j][i]
        out['adjoint_map']=rep.dagger
    return out
