#!/usr/bin/env python3
"""Exact small check for the private cross-family gauge obstruction.

This is an authored algebraic example, not an empirical generalization test.
All arithmetic uses fractions.Fraction; no external dependencies are needed.
Run: python gauge_example.py > gauge_example_results.json
"""

from fractions import Fraction as F
import json


def matrix(rows):
    return [[F(x) for x in row] for row in rows]


def eye(n):
    return matrix([[int(i == j) for j in range(n)] for i in range(n)])


def mul(a, b):
    assert len(a[0]) == len(b)
    return [[sum((a[i][k] * b[k][j] for k in range(len(b))), F(0))
             for j in range(len(b[0]))] for i in range(len(a))]


def scale(t, a):
    return [[t * x for x in row] for row in a]


def add(a, b):
    return [[x + y for x, y in zip(ar, br)] for ar, br in zip(a, b)]


def inverse(a):
    n = len(a)
    z = [row[:] + ident for row, ident in zip(a, eye(n))]
    for j in range(n):
        pivot = next(i for i in range(j, n) if z[i][j])
        z[j], z[pivot] = z[pivot], z[j]
        t = z[j][j]
        z[j] = [x / t for x in z[j]]
        for i in range(n):
            if i != j:
                t = z[i][j]
                z[i] = [x - t * y for x, y in zip(z[i], z[j])]
    return [row[n:] for row in z]


def determinant(a):
    z = [row[:] for row in a]
    out = F(1)
    for j in range(len(z)):
        pivots = [i for i in range(j, len(z)) if z[i][j]]
        if not pivots:
            return F(0)
        pivot = pivots[0]
        if pivot != j:
            z[j], z[pivot] = z[pivot], z[j]
            out = -out
        t = z[j][j]
        out *= t
        for i in range(j + 1, len(z)):
            q = z[i][j] / t
            z[i] = [x - q * y for x, y in zip(z[i], z[j])]
    return out


def power(a, k):
    z = eye(len(a))
    for _ in range(k):
        z = mul(z, a)
    return z


def response(operators):
    # List is written in matrix-product order: [A,B] means B then A.
    z = r
    for op in reversed(operators):
        z = mul(op, z)
    return mul(c, z)[0][0]


def reachability(m):
    columns = [mul(power(m, k), r) for k in range(3)]
    return [[columns[j][i][0] for j in range(3)] for i in range(3)]


def observability(m):
    return [mul(c, power(m, k))[0] for k in range(3)]


def column_stochastic(m):
    return all(sum(row[j] for row in m) == 1 for j in range(len(m[0])))


def dobrushin(m):
    return max(sum(abs(m[i][j] - m[i][k]) for i in range(len(m))) / 2
               for j in range(len(m[0])) for k in range(len(m[0])))


def string_fractions(x):
    if isinstance(x, F):
        return str(x)
    if isinstance(x, list):
        return [string_fractions(v) for v in x]
    if isinstance(x, dict):
        return {k: string_fractions(v) for k, v in x.items()}
    return x


A = scale(F(1, 10), matrix([[6, 4, 1], [3, 5, 2], [1, 1, 7]]))
B = scale(F(1, 10), matrix([[3, 2, 4], [6, 3, 1], [1, 5, 5]]))
S = matrix([[1, 0, 0], [0, 0, 1], [0, 1, 0]])
r = matrix([[F(1, 3)], [F(1, 3)], [F(1, 3)]])
c = matrix([[1, 0, 0]])
ones = matrix([[1, 1, 1]])
J = mul(r, ones)
P0 = scale(F(1, 2), add(eye(3), J))
B_swap = mul(mul(S, B), S)
D1 = matrix([[1, 0, 0], [0, 0, 0], [0, 0, 0]])
D0 = add(eye(3), scale(F(-1), D1))

assert mul(S, r) == r and mul(c, S) == c
assert mul(S, P0) == mul(P0, S)
assert mul(S, D1) == mul(D1, S) and mul(S, D0) == mul(D0, S)
for m in [A, B, B_swap, P0]:
    assert column_stochastic(m) and min(x for row in m for x in row) > 0

minimality = {}
for name, m in [
    ("A", A), ("B", B), ("B_swap", B_swap)
]:
    dr, do = determinant(reachability(m)), determinant(observability(m))
    assert dr and do
    minimality[name] = {
        "det_R": dr,
        "det_O": do,
        "one_step_state": mul(m, r),
        "dobrushin": dobrushin(m),
    }

assert response([A, B]) == F(7, 20)
assert response([A, B_swap]) == F(9, 25)
assert response([B, A]) == F(89, 300)
assert response([B_swap, A]) == F(91, 300)

# All single-family endpoint words agree by conjugation, not by enumeration.
assert B_swap == mul(mul(S, B), inverse(S))

RA, RB = reachability(A), reachability(B)
OA, OB = observability(A), observability(B)
HA, HB = mul(OA, RA), mul(OB, RB)
HAB = mul(OA, RB)
T = mul(inverse(HA), HAB)
AA = mul(inverse(HA), mul(mul(OA, A), RA))
BB = mul(inverse(HB), mul(mul(OB, B), RB))
assert T == mul(inverse(RA), RB)
assert AA == mul(mul(inverse(RA), A), RA)
assert mul(mul(T, BB), inverse(T)) == mul(mul(inverse(RA), B), RA)
assert mul(T, matrix([[1], [0], [0]])) == matrix([[1], [0], [0]])
assert mul(ones, T) == ones

# A normalization covector reduces four cross entries to two new moments.
normalization = add(add(scale(F(12), c), scale(F(-80), mul(c, A))),
                    scale(F(100), mul(c, power(A, 2))))
assert normalization == scale(F(13), ones)
for j in [1, 2]:
    assert HAB[2][j] == (13 - 12 * HAB[0][j] + 80 * HAB[1][j]) / 100

# A continuous endpoint-only gauge. S_cont need not itself be a stochastic
# physical operation: it is a coordinate transformation. The transformed B
# must be positive and stochastic, which is checked here.
a, b = F(1, 10), F(4, 5)
S_cont = matrix([[1, 0, 0], [a, b, 1-a-b], [-a, 1-b, a+b]])
B_cont = mul(mul(S_cont, B), inverse(S_cont))
assert determinant(S_cont) == F(7, 10)
assert mul(S_cont, r) == r and mul(c, S_cont) == c
assert mul(ones, S_cont) == ones
assert mul(S_cont, P0) == mul(P0, S_cont)
assert column_stochastic(B_cont) and min(x for row in B_cont for x in row) > 0
assert mul(S_cont, D1) != mul(D1, S_cont)
assert response([A, B_cont]) == response([A, B]) == F(7, 20)
assert response([A, B_cont, B_cont]) - response([A, B, B]) == F(3, 2000)

# Reset is obtainable through repeated known baseline steps: P0^k = J +
# 2^-k (I-J), with TV bias at most 2^-k from any initial distribution.
assert power(P0, 7) == add(J, scale(F(1, 128), add(eye(3), scale(F(-1), J))))

results = {
    "arithmetic": "exact rational, standard library fractions.Fraction",
    "exposure": "authored algebraic construction; no held-out/generalization claim",
    "A": A,
    "B": B,
    "B_swap": B_swap,
    "P0": P0,
    "r": r,
    "c": c,
    "minimality": minimality,
    "mixed_swap_probabilities": {
        "cABr": response([A, B]),
        "cAB_swap_r": response([A, B_swap]),
        "cBAr": response([B, A]),
        "cB_swap_Ar": response([B_swap, A]),
    },
    "H_A": HA,
    "H_AB": HAB,
    "connector_T": T,
    "continuous_endpoint_only_gauge": {
        "S": S_cont,
        "B_cont": B_cont,
        "dobrushin_B_cont": dobrushin(B_cont),
        "cABr": response([A, B]),
        "cAB_cont_r": response([A, B_cont]),
        "cAB2r": response([A, B, B]),
        "cAB_cont2r": response([A, B_cont, B_cont]),
        "difference_second_cross_statistic": F(3, 2000),
        "preserves_intermediate_observation_law": False,
    },
    "assertions": "all passed",
}
print(json.dumps(string_fractions(results), indent=2))
