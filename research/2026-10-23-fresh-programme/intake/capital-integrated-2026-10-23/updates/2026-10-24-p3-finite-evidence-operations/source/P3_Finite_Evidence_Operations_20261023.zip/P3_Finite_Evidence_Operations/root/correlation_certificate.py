"""Exact task-specific certificates from reversible endpoint correlations.

Access contract, NOT inferred by this code: real self-adjoint contractions A_a
on one Hilbert space, |f|<=1 in a common stationary probability space, and
simultaneous intervals for C(w)=<f,A_a1...A_aT f>.  Words have physical
chronological order for backward Markov operators.  No hidden-state dimension,
Gram inverse, exact rank recognition, or source equation enters verification.

The implementation is a certificate evaluator, not a novel replacement for
retaining ResDMD, moment methods, or goal-oriented residual estimation.
All numerics that affect validity use integers/Fractions and outward square
roots.  Repeated protocols are combined before interval evaluation.
"""
from fractions import Fraction as F
from math import isqrt


def exact(x):
    if type(x) not in (int, F):
        raise TypeError('Certificate input must be int or Fraction, never float/bool')
    return F(x)


def word(w):
    w = tuple(w)
    if any(type(a) is not int or a < 0 for a in w):
        raise ValueError('Action labels must be nonnegative integers')
    return w


def canonical(w):
    """C(w)=C(reverse(w)) under the stated common self-adjoint contract."""
    w = word(w)
    return min(w, w[::-1])


def add(*forms):
    out = {}
    for p in forms:
        for w, c in p.items():
            w, c = canonical(w), exact(c)
            out[w] = out.get(w, F(0)) + c
    return {w: c for w, c in out.items() if c}


def scale(c, p):
    c = exact(c)
    return {w: c*v for w, v in p.items() if c*v}


def mv(t, z):
    return tuple(sum((a*b for a, b in zip(row, z)), F(0)) for row in t)


def sqrt_upper(x, bits=80):
    """Smallest multiple of 2**(-bits) no smaller than sqrt(x)."""
    x = exact(x)
    if x < 0 or type(bits) is not int or bits < 0:
        raise ValueError('Nonnegative radicand and integer precision required')
    n, d = x.numerator << (2*bits), x.denominator
    k = isqrt(n // d)
    if k*k*d < n:
        k += 1
    return F(k, 1 << bits)


class Correlations:
    """One simultaneous confidence set, not a source-membership certificate."""
    def __init__(self, intervals):
        self.intervals = {}
        for raw_w, ends in intervals.items():
            w = canonical(raw_w)
            if len(ends) != 2:
                raise ValueError('Every correlation needs a lower/upper pair')
            lo, hi = map(exact, ends)
            if not -1 <= lo <= hi <= 1:
                raise ValueError('Correlation intervals must lie in [-1,1]')
            if w in self.intervals:
                oldlo, oldhi = self.intervals[w]
                lo, hi = max(lo, oldlo), min(hi, oldhi)
                if lo > hi:
                    raise ValueError('Incompatible intervals for reversed protocols')
            self.intervals[w] = (lo, hi)

    def evaluate(self, form):
        """Exact support interval after combining identical/reversed words."""
        lo = hi = F(0)
        for w, c in add(form).items():
            a, b = self.intervals[w]  # Missing paid observation is an error.
            if c < 0:
                a, b = b, a
            lo += c*a
            hi += c*b
        return lo, hi


class Representation:
    def __init__(self, basis, transitions):
        self.basis = tuple(word(w) for w in basis)
        d = len(self.basis)
        if not d or self.basis[0] != () or len(set(self.basis)) != d:
            raise ValueError('Distinct feature words with empty word first required')
        self.e0 = (F(1),) + (F(0),)*(d-1)
        self.transitions = {}
        for a, t in transitions.items():
            if type(a) is not int or a < 0:
                raise ValueError('Action labels must be nonnegative integers')
            t = tuple(tuple(exact(v) for v in row) for row in t)
            if len(t) != d or any(len(row) != d for row in t):
                raise ValueError('Every candidate matrix must be d by d')
            self.transitions[a] = t
        if not self.transitions or any(a not in self.transitions
                                       for w in self.basis for a in w):
            raise ValueError('Feature words use an undeclared action')

    def inner_form(self, left, right, middle=()):
        """<V left,A_middle V right> as an affine correlation functional."""
        if len(left) != len(self.basis) or len(right) != len(self.basis):
            raise ValueError('Wrong coefficient dimension')
        middle = word(middle)
        out = {}
        for i, x in enumerate(left):
            for j, y in enumerate(right):
                c = exact(x)*exact(y)
                if c:
                    w = canonical(self.basis[i][::-1]+middle+self.basis[j])
                    out[w] = out.get(w, F(0))+c
        return {w: c for w, c in out.items() if c}

    def residual_form(self, a, z):
        """||(A_a V - V T_a)z||², affine in the acquired correlations."""
        tz = mv(self.transitions[a], z)
        return add(self.inner_form(z, z, (a, a)),
                   scale(-2, self.inner_form(z, tz, (a,))),
                   self.inner_form(tz, tz))

    def defect_form(self, a, left, right):
        """left^T(H_a-G T_a)right."""
        return add(self.inner_form(left, right, (a,)),
                   scale(-1, self.inner_form(left, mv(self.transitions[a], right))))

    def acquisition_words(self):
        """G,H,J protocol pool.  A target only requires a subset of this pool."""
        out = set()
        for u in self.basis:
            for v in self.basis:
                out.add(canonical(u[::-1]+v))
                for a in self.transitions:
                    out.add(canonical(u[::-1]+(a,)+v))
                    out.add(canonical(u[::-1]+(a, a)+v))
        return tuple(sorted(out, key=lambda w: (len(w), w)))

    def forms_for(self, target):
        target = word(target)
        if any(a not in self.transitions for a in target):
            raise ValueError('Unacquired target action')
        n = len(target)
        left = [self.e0]
        for a in target:
            left.append(mv(self.transitions[a], left[-1]))
        right = [None]*n+[self.e0]
        for j in range(n-1, -1, -1):
            right[j] = mv(self.transitions[target[j]], right[j+1])
        prediction = self.inner_form(self.e0, right[0])
        defect = add(*(self.defect_form(a, left[j], right[j+1])
                       for j, a in enumerate(target)))
        return {'prediction': prediction,
                'correction': defect,
                'corrected': add(prediction, defect),
                'left_residuals': [self.residual_form(a, left[j])
                                   for j, a in enumerate(target)],
                'right_residuals': [self.residual_form(a, right[j+1])
                                    for j, a in enumerate(target)],
                'left_coefficients': left, 'right_coefficients': right}

    def certify(self, target, data, sqrt_bits=80):
        if not isinstance(data, Correlations):
            raise TypeError('Explicit simultaneous Correlations intervals required')
        if type(self) is Representation and type(data) is not Correlations:
            raise TypeError('Self-adjoint representation requires self-adjoint correlation aliases')
        f = self.forms_for(target)
        upper_l, upper_r = [], []
        for source, dest in ((f['left_residuals'], upper_l),
                             (f['right_residuals'], upper_r)):
            for form in source:
                lo, hi = data.evaluate(form)
                if hi < 0:
                    raise ValueError('Data exclude a nonnegative squared residual')
                dest.append(sqrt_upper(hi, sqrt_bits))
        # Sum_{i<j} rho_left_i*rho_right_j, O(length) after norms.
        prefix = cross = F(0)
        for l, r in zip(upper_l, upper_r):
            cross += prefix*r
            prefix += l
        clo, chi = data.evaluate(f['corrected'])
        lo, hi = max(F(-1), clo-cross), min(F(1), chi+cross)
        if lo > hi:
            raise ValueError('Data and the stated contract have empty target bounds')
        # Comparable generic one-sided accumulated-residual certificate.
        plo, phi = data.evaluate(f['prediction'])
        _, f2hi = data.evaluate({(): F(1)})
        if f2hi < 0:
            raise ValueError('Data exclude nonnegative squared observable norm')
        first_order = sqrt_upper(f2hi, sqrt_bits)*sum(upper_r, F(0))
        olo, ohi = max(F(-1), plo-first_order), min(F(1), phi+first_order)
        # Both certificates are sound under the same event; retain intersection.
        final_lo, final_hi = max(lo, olo), min(hi, ohi)
        if final_lo > final_hi:
            raise ValueError('Certificate intervals are inconsistent')
        return {'lower': final_lo, 'upper': final_hi,
                'two_sided_lower': lo, 'two_sided_upper': hi,
                'one_sided_lower': olo, 'one_sided_upper': ohi,
                'corrected_center': (clo+chi)/2,
                'linear_radius': (chi-clo)/2, 'cross_remainder': cross,
                'one_sided_remainder': first_order,
                'forms': f}


def rational_bits(x):
    x = exact(x)
    return max(abs(x.numerator).bit_length(), x.denominator.bit_length())
