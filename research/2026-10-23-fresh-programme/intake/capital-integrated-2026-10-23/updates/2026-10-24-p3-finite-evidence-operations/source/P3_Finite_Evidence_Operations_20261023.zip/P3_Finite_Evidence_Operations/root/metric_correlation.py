"""Exact common-metric version of the all-word correlation certificate.

The metric is a rational numerical proposal, often the measured Gram center.
It need not equal the true Gram matrix and does not certify source rank.
Every matrix inequality used here is checked with exact rational Schur
complements. Failed sufficient checks return UNKNOWN or reject bad inputs.
"""
from fractions import Fraction as F
from correlation_certificate import Representation, Correlations, exact, scale, sqrt_upper
from uniform_correlation import center_and_radius


def add(*forms):
    """Add already canonical affine forms without imposing a new word alias."""
    out = {}
    for form in forms:
        for w, c in form.items():
            out[w] = out.get(w, F(0)) + exact(c)
    return {w: c for w, c in out.items() if c}


def mm(a, b):
    return [[sum((x*y for x, y in zip(row, col)), F(0)) for col in zip(*b)] for row in a]


def transpose(a):
    return [list(row) for row in zip(*a)]


def psd(a, strict=False):
    """Exact symmetric PSD/PD test, including the zero-pivot obstruction."""
    a = [[exact(x) for x in row] for row in a]
    n = len(a)
    if not n or any(len(row) != n for row in a) or a != transpose(a):
        return False
    for i in range(n):
        p = a[i][i]
        if p < 0 or (strict and p == 0):
            return False
        if p == 0:
            if any(a[i][j] for j in range(i+1, n)):
                return False
            continue
        for j in range(i+1, n):
            for k in range(j, n):
                a[j][k] -= a[j][i]*a[i][k]/p
                a[k][j] = a[j][k]
    return True


def minus_scaled(c, m, b):
    return [[c*x-y for x, y in zip(rowm, rowb)] for rowm, rowb in zip(m, b)]


def dominate(b, m, precision=40, max_doublings=128):
    """Find a dyadic c>=0 with c*M-B PSD; keep all proposal costs visible."""
    if type(precision) is not int or precision < 1:
        raise ValueError('Positive integer search precision required')
    calls = 1
    if psd([[-x for x in row] for row in b]):
        return F(0), calls
    lo, hi = F(0), F(1)
    for _ in range(max_doublings):
        calls += 1
        if psd(minus_scaled(hi, m, b)):
            break
        lo, hi = hi, hi*2
    else:
        raise ArithmeticError('Bounded exact domination search exhausted')
    for _ in range(precision):
        mid = (lo+hi)/2
        calls += 1
        if psd(minus_scaled(mid, m, b)):
            hi = mid
        else:
            lo = mid
    # This final check prevents numerical proposals becoming assumed witnesses.
    calls += 1
    if not psd(minus_scaled(hi, m, b)):
        raise AssertionError('Internal exact certificate check failed')
    return hi, calls


def diag(values):
    return [[v if i == j else F(0) for j in range(len(values))] for i, v in enumerate(values)]


def metric_certificate(rep, data, metric, precision=40, sqrt_bits=80):
    """Public self-adjoint interface; reject incompatible alias/left actions."""
    if type(rep) is not Representation or type(data) is not Correlations:
        raise TypeError('Self-adjoint front door requires base Representation and Correlations; use adjoint_metric_certificate otherwise')
    return _metric_certificate(rep, data, metric, precision, sqrt_bits)


def _metric_certificate(rep, data, metric, precision=40, sqrt_bits=80):
    """Shared internal routine; validated adjoint wrapper replaces left blocks.

    Do not expose its intermediate program as an adjoint certificate before
    that replacement. Public callers must use a contract-specific front door.
    """
    if not isinstance(rep, Representation) or not isinstance(data, Correlations):
        raise TypeError('Representation and simultaneous Correlations required')
    d = len(rep.basis)
    m = [[exact(x) for x in row] for row in metric]
    if len(m) != d or any(len(row) != d for row in m) or not psd(m, strict=True):
        raise ValueError('Proposed coefficient metric must be exact symmetric positive definite')
    calls = 1
    norm_square = F(0)
    for t in rep.transitions.values():
        upper, count = dominate(mm(mm(transpose(t), m), t), m, precision)
        calls += count
        norm_square = max(norm_square, upper)
    r = sqrt_upper(norm_square, sqrt_bits)
    if r >= 1:
        return {'status': 'UNKNOWN', 'reason': 'No strict coefficient contraction in proposed metric',
                'coefficient_contraction_upper': r, 'exact_psd_checks': calls}
    units = [tuple(F(int(i == j)) for i in range(d)) for j in range(d)]
    gforms = [[rep.inner_form(x, y) for y in units] for x in units]
    gc, gr = center_and_radius(gforms, data)
    gmajorant = diag([sum(row, F(0)) for row in gr])
    eta_g, count = dominate(gmajorant, m, precision)
    calls += count
    eta_d, kappa = F(0), F(0)
    programs, diagnostics = {}, {}
    for a, t in rep.transitions.items():
        dforms = [[rep.defect_form(a, x, y) for y in units] for x in units]
        dc, dr = center_and_radius(dforms, data)
        row_majorant = diag([sum(row, F(0)) for row in dr])
        col_majorant = diag([sum(col, F(0)) for col in zip(*dr)])
        da1, c1 = dominate(row_majorant, m, precision)
        da2, c2 = dominate(col_majorant, m, precision)
        calls += c1+c2
        da = max(da1, da2)
        ra = [rep.residual_form(a, x) for x in units]
        rforms = [[scale(F(1, 2), add(
                      rep.residual_form(a, tuple(xx+yy for xx, yy in zip(x, y))),
                      scale(-1, ra[i]), scale(-1, ra[j])))
                   for j, y in enumerate(units)] for i, x in enumerate(units)]
        rc, rr = center_and_radius(rforms, data)
        if any(rc[i][i]+rr[i][i] < 0 for i in range(d)):
            raise ValueError('Data exclude a nonnegative residual square')
        rmajorant = [[rc[i][j]+(sum(rr[i], F(0)) if i == j else F(0))
                      for j in range(d)] for i in range(d)]
        ka, count = dominate(rmajorant, m, precision)
        calls += count
        kappa, eta_d = max(kappa, ka), max(eta_d, da)
        block = [[F(0) for _ in range(2*d)] for _ in range(2*d)]
        for i in range(d):
            for j in range(d):
                block[i][j], block[i][d+j], block[d+i][d+j] = t[j][i], dc[i][j], t[i][j]
        programs[a] = block
        diagnostics[a] = {'residual_metric_square_upper': ka,
                          'defect_metric_error_upper': da,
                          'residual_majorant': rmajorant}
    error = m[0][0]*(eta_g+eta_d/(1-r)+kappa/(1-r)**2)
    return {'status': 'CERTIFIED_UNDER_CONTRACT', 'uniform_error': error,
            'coefficient_contraction_upper': r, 'gram_estimation_norm_upper': eta_g,
            'defect_estimation_norm_upper': eta_d,
            'residual_operator_square_upper': kappa, 'metric': m,
            'program': programs, 'left': list(rep.e0)+gc[0],
            'right': [F(0)]*d+list(rep.e0), 'diagnostics': diagnostics,
            'exact_psd_checks': calls}
