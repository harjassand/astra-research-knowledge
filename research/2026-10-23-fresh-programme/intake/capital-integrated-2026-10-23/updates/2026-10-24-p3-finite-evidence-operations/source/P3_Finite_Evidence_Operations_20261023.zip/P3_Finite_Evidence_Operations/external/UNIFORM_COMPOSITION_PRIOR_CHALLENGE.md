# Bounded prior challenge: uniform corrected composition

Private P3 note, 2026-10-23. Two targeted primary sources were read. No
workers, experiments, or benchmark fixtures were launched. This note
assesses the parent's concrete construction in
`../root/CORRELATION_CERTIFICATE.md`; it does not independently certify
every detail of that theorem.

## 1. Finding

The corrected predictor is exactly an ordinary finite weighted automaton.
The product of forward and backward residual errors, squared geometric
stability denominator, and finite-statistics-to-all-words reasoning have
close established precedents. None supplies a basis for an architectural
novelty claim.

The remaining scoped question is the **obtainable information contract**:
whether adjoint scalar pulse experiments acquire the Gram and propagated
Gram information needed to certify a finite approximation to unknown,
possibly infinite-dimensional dynamics, without a promise that a finite
Hankel block identifies the whole system. The two sources below do not
establish that combined acquisition/certification construction. Historical
novelty remains **UNKNOWN** after this bounded check.

## 2. Two primary comparisons

### A. Balle, Gourdeau and Panangaden: stable weighted languages

[Bisimulation Metrics for Weighted Automata](https://arxiv.org/pdf/1702.08017),
arXiv:1702.08017v2 (14 May 2017), Corollary 11 defines

\[
d_\gamma(A,A')=\sup_{x\in\Sigma^\infty}
\sum_{t\ge0}\gamma^t|f_A(x_{\le t})-f_{A'}(x_{\le t})|.
\]

Lemma 25, equation (10), bounds its transition-perturbation contribution by

\[
\frac{\gamma\|\alpha\|\|\beta'\|_*
\max_a\|\tau_a-\tau'_a\|}{(1-\gamma\theta)^2},
\]

assuming a common norm bounds both sets of transitions by \(\theta\).
Section 6 learns operators from finite Hankel blocks. Theorem 22 requires
a finite-dimensional irreducible target and a complete block, including
equality of its rank with the full Hankel rank; its asymptotic error is
\(O(\|H-\widehat H\|_2)\). The paper explicitly distinguishes this
arbitrary-length guarantee from fixed-horizon errors.

This is close prior for the squared denominator and finite-statistics
route to language-wide control. It does not acquire hidden-space
residuals through reversed pulse correlations. Taking \(\gamma=1\)
requires strict stability of the true realization as well.

### B. Klindworth, Grepl and Vossen: corrected outputs

[Certified Reduced Basis Methods for Parametrized Parabolic Partial
Differential Equations with Non-Affine Source Terms](https://www.igpm.rwth-aachen.de/Download/reports/grepl/KGV_CMAME_preprint_revised.pdf),
author preprint dated 31 August 2011, equation (32) defines output as the
reduced primal output plus a sum of primal residuals evaluated on an
approximate backward dual. Proposition 2, equations (54)--(55), bounds
the corrected-output error by a product of primal and dual error bounds,
with additional interpolation terms. Section 4.4 explicitly identifies
this quadratic effect. The implementation has offline/online separation
and uses known variational forms, truth discretizations, and coercivity
bounds.

This is direct prior for the residual correction and product-error
principle. It does not provide hidden-state scalar-correlation acquisition.
Its result is for its stated PDE model and time interval; this audit does
not silently promote it to the parent's infinite switched-word theorem.

## 3. Exact compilation into a retaining weighted automaton

The following is an independent algebraic comparison, using the parent's
notation. Let the dictionary have \(m\) columns, with initial coordinate
\(e\). Let \(G\) be its Gram matrix, \(T_a\) the retained coefficient
matrix, and \(D_a=H_a-GT_a\). For \(w=a_1\cdots a_n\), write the corrected
predictor as

\[
Q_w=e^\top G T_{a_1}\cdots T_{a_n}e
+\sum_{j=1}^n
e^\top T_{a_1}^\top\cdots T_{a_{j-1}}^\top
D_{a_j}T_{a_{j+1}}\cdots T_{a_n}e.
\]

Define \(2m\)-dimensional matrices and boundary vectors

\[
M_a=\begin{pmatrix}T_a^\top&D_a\\0&T_a\end{pmatrix},
\qquad
\lambda^\top=\begin{pmatrix}e^\top&e^\top G\end{pmatrix},
\qquad
\rho=\begin{pmatrix}0\\e\end{pmatrix}.
\]

Then

\[
\boxed{Q_w=\lambda^\top M_{a_1}\cdots M_{a_n}\rho.}
\]

**Proof.** The product's lower-right block is the product of the \(T_a\).
Its upper-right block is the sum of all products with exactly one
\(D_{a_j}\), transposed \(T\)'s before that position, and ordinary
\(T\)'s afterwards. Multiplying the displayed boundary vectors yields
the two terms of \(Q_w\). The empty word gives \(e^\top Ge\), as required.
No matrix inversion, rank condition, or source equation is involved.

If \(\|T_a\|_2\le r<1\) and \(d=\max_a\|D_a\|_2\), put

\[
\|(x,y)\|_s=\max\{\|x\|_2,s\|y\|_2\}.
\]

The induced norm satisfies \(\|M_a\|_s\le r+d/s\). Choosing
\(s>d/(1-r)\) makes the retained corrected automaton jointly
contractive. This norm rescaling does not improve the acquisition error
or prove anything about the true hidden dynamics; it only makes the
retaining implementation explicit.

For a general common vector norm, use its dual norm on the first block,
the original norm on the second block, and the corresponding induced
norm of \(D_a\) from the second block to the first. The same argument
applies because the operator norm of \(T_a^\top\) in the dual norm equals
that of \(T_a\) in the original norm.

Therefore an equally informed program/library learner can store
\(G,D_a,T_a\) and evaluate the exact same corrected predictions in one
pass. The certificate and the measured data are the scientific content;
the inference operation is not exclusive to a new learner architecture.

## 4. The useful scope distinction

The parent's hypothesis permits true Hilbert-space actions with
\(\|A_a\|\le1\), while only the learned coefficient matrices satisfy a
strict common contraction. A true unobserved slow or invariant sector can
therefore remain. The residual condition bounds its effect on the
chosen observable operation rather than identifying that sector.

This is not equivalent to perturbing two fully identified, strictly
stable finite realizations. For example, a uniformly small persistent
output discrepancy can have an infinite undiscounted sum over prefixes.
A bound on each word need not bound that sum. A discounted sum, in turn,
only immediately bounds a length-\(n\) error after division by its
discount factor. These are elementary distinctions between norms on
sequences; they must be kept when comparing the two guarantees.

The parent's two-residual proof also has a transparent geometric source
for its denominator. If two insertions at positions \(i<j\) have residual
product bounded by \(\kappa\), the true operators between them have norm
at most one, and retained factors outside them have norm at most \(r\),
then the absolute sum is bounded by

\[
\kappa\sum_{i<j} r^{i-1+n-j}
=\kappa\sum_{k=0}^{n-2}(k+1)r^k
\le \frac{\kappa}{(1-r)^2}.
\]

This counting identity explains why no strict contraction of the
unobserved middle dynamics is required in that particular bound. It
does not itself establish that the full output remainder has exactly
those insertions; that is the substantive decomposition to verify in
the parent's proof.

## 5. Confidence and access qualifications

One finite confidence event can support infinitely many subsequent word
queries when the deterministic theorem holds uniformly on that event.
This is a logical implication, not an independent invention in
statistics. All data-dependent fitting choices must either be covered by
that event's uniform statements or use appropriate data separation.
The claim cannot quietly assume a fixed fit in one step and then search
over arbitrarily many fitted residual certificates in another.

Similarly, normalizer-free simulation is not precision-free. Exact
single-site Gibbs conditionals for finite local models are an obtainable
primitive, but arbitrary block conditionals may be expensive. Numerical
kernel errors need their own budget. For example, if each simulated
action differs from the intended action by at most \(\eta_j\) in total
variation uniformly over states, coupling and a union bound add at most
\(2B^2\sum_j\eta_j\) to a bounded endpoint-product bias. This does not
certify unbounded hidden operator error from a few scalar checks.

## 6. Status

- **Proven here:** exact \(2m\)-state retaining-WFA compilation and its
  common-norm stability bound; the displayed geometric counting bound.
- **Established prior overlap:** stable weighted-language approximation
  and primal/dual corrected outputs with product-error bounds.
- **Not found in the two inspected sources:** the combined reversed-pulse
  acquisition, inverse-free hidden-space residual certificate, and
  finite-event all-future-word guarantee under the parent's exact access
  and approximation assumptions.
- **UNKNOWN:** historical novelty of that combination, availability of a
  consequential scientific application, and practical advantage after
  acquisition, calibration, initialization, precision, fitting, and
  verification costs.

An additional search result titled “Finite Teaching, Infinite Horizons:
Sharp Guarantees for ...”, at
`https://openreview.net/pdf?id=al7TXa807t`, could not be read because
OpenReview required browser verification. A second search did not provide
a usable primary copy. Its content and relevance are UNKNOWN; no claim in
this note relies on it. No access control was bypassed.
