# Least renewal completion and finite-horizon control: independent audit

Private P3 continuation, 2026-10-23. This note challenges and precisely scopes the policy extension of the direct first-return completion result. It is a proof/audit, not an external application or novelty claim. See `RENEWAL_ACQUISITION_SUPERMODULARITY.md` for the completion construction and `RESET_ACCESS_CONTRACT.md` for the unresolved physical access warrant.

## 1. Setting and the positive result

There is a finite control alphabet A and horizon H. At each step the controller sees only the preceding actions and a binary return/no-return record. It may condition future actions on that entire history. A return resets the complete state relevant to future observations to the same distribution/state r, independent of the past. There are no unobserved context variables retained across this reset.

For a nonempty control word u, let f_M(u) be the probability that, starting from reset, the first return occurs at the final symbol of u under those controls. The available information consists of a finite set of exact coefficients and/or coordinatewise lower bounds f_M(u)>=ell(u), with ell(u)=0 elsewhere. The lower coefficients satisfy prefix-mass feasibility. The model class contains the finite controlled substochastic trie that realizes exactly f_*(u)=ell(u). Additional structural constraints are not silently imposed.

A **return-prefix reward** is a finite-horizon sum

\[
G=\sum_{t=1}^{H} 1_{\{e_t=1\}}\,g_t(h_t),
\qquad g_t(h_t)\ge0,
\]

where h_t is the full action/event history through t. The reward can depend on all earlier events, controls, waiting times, and a task state, but cannot depend on future observations. Assume it is bounded so all expectations exist; finite alphabets and finite horizon make this automatic for finite numerical rewards.

**Theorem.** For every admissible event-history policy pi, including a randomized policy,

\[
\inf_{M\in\mathcal C} J_M(\pi)=J_*(\pi),
\qquad
\sup_\pi\inf_{M\in\mathcal C}J_M(\pi)
=\sup_\pi J_*(\pi).
\]

The same trie model attains the infimum for all policies and all return-prefix rewards simultaneously.

### Proof

First fix a deterministic policy and a consistent history h_t ending in a return. Split its action word at its return times into completed excursion words u_1,...,u_k. All no-return outcomes within each excursion are already part of the definition of its first-return coefficient. Exact reset gives

\[
\Pr_M(h_t)=\prod_{j=1}^{k} f_M(u_j).
\]

There is no final survival factor, because the history ends at a return. The policy may change actions after either event outcome; once the history is fixed, those actions are fixed as well. Therefore

\[
J_M(\pi)=\sum_{t=1}^{H}\ \sum_{h_t:e_t=1}
g_t(h_t)\prod_{j=1}^{k(h_t)}f_M(u_j).
\]

This is a polynomial with nonnegative coefficients in the first-return coordinates. Replacing every coordinate by its simultaneous lower bound can only decrease it. The trie realizes all those lower coefficients together, so the lower bound is attained by a single model independent of pi. Conditioning on all the policy's private random coins proves the randomized case. Taking the supremum over policies yields the control equality.

The argument does not exchange infimum and supremum by an unjustified minimax theorem. A common least model makes the inner infimum explicit for each policy. It needs regeneration of the observable controlled process, not an underlying linear hidden-state equation: any history-independent post-reset excursion law has the same product factorization. The finite trie is a least realization in that broad regenerative class when the class includes it. Merely observing a coarse return macrostate does not establish regeneration.

## 2. Rewards that do and do not fit

Examples that fit are expected numbers of successful returns, return probability at the final time, discounted nonnegative return rewards, and probability of first completing a task by H when completion is registered at a return. For the last case, pay one at the first completing return and zero thereafter. Requiring at least K returns by H similarly pays one at the Kth return.

An event-sensitive policy is not itself an obstruction. Earlier returns can send the policy down a different branch, but every previously supported successful return prefix retains its own nonnegative product term. Added kernels supply further terms.

Arbitrary terminal rewards do not fit. In particular, rewarding the absence of returns requires a survival tail, which has subtractions rather than only nonnegative kernel products. Rewards for exactly K returns by the horizon can also depend on future non-events and need separate analysis.

### Minimal exact-data survival counterexample

Use one action a and exact data f(a)=p, with 0<p<1. The horizon is two, and the reward is one if there has been no return by the horizon. The zero-off-data trie has f(aa)=0 and reward probability 1-p. Another compatible completion can have

\[
f(aa)=q,\qquad 0<q\le1-p,
\]

and then the reward probability is 1-p-q. Taking q=1-p gives zero. Taking q<1-p already disproves leastness and admits a strictly transient two-state realization, for example the column-oriented substochastic action matrix

\[
P_a=\begin{pmatrix}
p & q/(1-p)\\
1-p & 0
\end{pmatrix}.
\]

Its spectral radius is below one when p+q<1. Thus the failure does not rely on a recurrent system.

### Negative expected action costs

Suppose only f(a)>=p is known. Probe with a, then take an action costing c>0 only if the probe returned; otherwise stop. With no other reward, this fixed policy has objective -c f(a). The trie gives -cp, while a completion with f(a)=1 gives -c. More returns can mean more action expense, reversing the order.

A fixed cost independent of the observations merely subtracts a model-independent constant and does not cause this problem. The failure concerns conditional execution cost, negative return rewards, or another model-dependent subtraction.

**Useful repair:** enforce a pathwise pulse, energy, or reset budget as a feasibility constraint, and retain a nonnegative return reward as the objective. Restrict the policy set to policies satisfying that budget on every history. The common-least-model proof still applies to every remaining policy. A finite budget can be included in the task state. This is more conservative than optimizing net expected reward or a yield/cost ratio, but it preserves the certified guarantee and accounts for execution resources.

## 3. Bellman implementation and what it acquires

Let v be the action word since the last return, represented by a proper-prefix trie state, and let q be a finite task-automaton state. Conditional on no earlier return in that excursion, define

\[
s(v)=1-\sum_{u\preceq v}\ell(u).
\]

At a reachable v with s(v)>0, action a has trie probabilities

\[
p_1(v,a)=\frac{\ell(va)}{s(v)},
\qquad
p_0(v,a)=\frac{s(va)}{s(v)}
\]

for returning to the reset state and continuing to trie state va, respectively; p_0 is present only if va is a proper-prefix state. Other mass enters an absorbing no-return state. Zero-survival states are unreachable. These are probabilities in the least compatible realization, not claims that the true system's hidden state or conditional law has been identified.

For task transitions T_1,T_0 and nonnegative event reward g, backward induction uses

\[
V_t(v,q)=\max_a\left\{
p_1(v,a)\left[g_t(q,a)+V_{t+1}(\epsilon,T_1(q,a))\right]
+p_0(v,a)V_{t+1}(va,T_0(q,a))
\right\}.
\]

Use terminal value V_(H+1)=0. The absorbing no-return contribution is zero. A time-dependent reward or pathwise resource budget can be included in q, restricting the maximization to actions feasible on every possible next branch. Budget feasibility must cover histories allowed by the full model class, including return branches assigned zero probability by the trie. The policy also needs a feasible continuation on off-trie no-return histories; stopping is sufficient when allowed. Feasibility checked only inside the least model does not suffice. With N trie states and Q task states, the finite-horizon arithmetic cost is O(H N Q |A|), plus trie construction, coefficient acquisition, numerical precision, and policy storage. Full history-dependent rewards without a compact task automaton can require exponentially many task states; the theorem does not remove that representation cost.

On a simultaneous confidence event establishing every retained lower coordinate, the bound holds for all policies at once. Selecting or searching for a policy using those same data does not require a new union bound over the policy class. Acquisition still needs valid simultaneous or sequential confidence bounds, and the exact reset/context warrant remains necessary.

Adding nonnegative lower coefficients can increase every fixed policy's guaranteed return-prefix reward and therefore cannot decrease the optimized value. The old policy remains available. This supports a scoped reusable operation: retain partial excursion knowledge, extend it with new measurements, and synthesize a guaranteed policy for a changed finite-state task without identifying the full hidden system.

An ordinary retaining renewal or weighted-automaton learner can store the same coefficients and execute the same Bellman recurrence. No architectural advantage or novel control algorithm has been established.

## 4. Joint information can destroy the least completion

The membership of the coordinatewise least trie in the full information set is essential. Consider one-step control with actions a and b, a unit reward for a return, and the exact joint constraint

\[
f(a)+f(b)=1,\qquad f(a),f(b)\ge0.
\]

Each coordinate separately has lower bound zero, but the coordinatewise-zero trie violates the joint constraint. There is no coefficientwise least compatible model: minimizing the a-policy requires f(a)=0, whereas minimizing the b-policy requires f(b)=0.

Writing f(a)=x, a policy choosing a with probability theta has reward

\[
J_x(\theta)=\theta x+(1-\theta)(1-x).
\]

For an unknown fixed model, the robust value is

\[
\max_{\theta\in[0,1]}\min_{x\in[0,1]}J_x(\theta)
=\max_\theta\min\{\theta,1-\theta\}=\frac12.
\]

The coordinatewise-zero relaxation would report zero. Here randomization matters; if the model could react to each private randomized action, that would be a different adversarial contract. A simultaneous lower box remains a valid conservative relaxation of joint information, but its trie need not be compatible or minimax sharp.

Known dimension, conservation, irreducibility, continuous-time embeddability, eventual return, or additional joint statistical constraints can likewise exclude the constructed trie. Those restrictions may create useful extra knowledge, but the present exact minimax reduction cannot be carried across them without a new proof.

## 5. Optimization changes acquisition geometry

The fixed-policy expected return-prefix reward is a nonnegative polynomial, so it has the same increasing coordinate interactions as a fixed-word renewal response. Maximizing over policies does not preserve that property.

The smallest example has horizon one, two actions, and unit return reward:

\[
V(f)=\max\{f(a),f(b)\}.
\]

Start with both coefficients absent and let either acquisition reveal its coefficient as one. Either singleton has value one, while the pair still has value one. Thus the optimized policy value is not a supermodular reveal-set function: the two control opportunities substitute for one another. Longer tasks can contain both this substitution and the complementary missing-block effects in the earlier note.

Consequently a fixed-policy derivative is a useful local accounting quantity, not a general experimental-design guarantee after control reoptimization.

## Scoped conclusion

The common-trie minimax statement is sound for nonnegative return-prefix rewards, exact reset, binary event history, coordinate information, and a model class containing the trie. It gives a useful partial-information operation without full hidden-system identification. It fails for survival rewards and can fail with conditional costs or joint information. Hard pathwise resource budgets preserve the positive result. A scientific advantage over retaining renewal control and direct task experiments remains unestablished; a concrete application must warrant the reset/observation interface and charge acquisition, confidence, policy representation, and execution.
