"""Bounded independent algebraic audit of uniform and metric certificates.

Checks were selected in the two saved contracts before reading parent code.
The sole source sequence C(w)=2**(-len(w)) was previously exposed. This is
not empirical confirmation, physical acquisition, or a transfer benchmark.
"""

from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / "root"
EXPECTED = {
    "correlation_certificate.py": "8c03a5841c8cbbe40112b0b61591b406749479103edc63cf5b2a0fcf4bafc798",
    "uniform_correlation.py": "48d76b92b66bdb7911956f597e42ec586c4bfb926a8162ac9d6cfbc70f9761eb",
    "metric_correlation.py": "910845d0db9bf74bca970cdc37ba6dbf85100d67c9961453aaf93e2e10e5a2c4",
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def matrix_product(a, b):
    return [[sum((a[i][k] * b[k][j] for k in range(len(b))), F(0))
             for j in range(len(b[0]))] for i in range(len(a))]


def vector_product(a, x):
    return [sum((a[i][j] * x[j] for j in range(len(x))), F(0))
            for i in range(len(a))]


def dot(x, y):
    return sum((a * b for a, b in zip(x, y)), F(0))


def transpose(a):
    return [[a[j][i] for j in range(len(a))] for i in range(len(a[0]))]


def subtract(a, b):
    return [[x-y for x, y in zip(arow, brow)] for arow, brow in zip(a, b)]


def exact_psd_2(a):
    return (len(a) == 2 and len(a[0]) == len(a[1]) == 2
            and a[0][1] == a[1][0] and a[0][0] >= 0 and a[1][1] >= 0
            and a[0][0] * a[1][1] >= a[0][1] ** 2)


def direct_center(transitions, gram, defects, target):
    """Independent prefix/suffix formula; no parent form machinery."""
    e = [F(1), F(0)]
    n = len(target)
    lefts = [e]
    for a in target:
        lefts.append(vector_product(transitions[a], lefts[-1]))
    rights = [None] * (n+1)
    rights[n] = e
    for j in range(n-1, -1, -1):
        rights[j] = vector_product(transitions[target[j]], rights[j+1])
    value = dot(e, vector_product(gram, rights[0]))
    for j, a in enumerate(target):
        value += dot(lefts[j], vector_product(defects[a], rights[j+1]))
    return value


def main():
    for filename, expected in EXPECTED.items():
        if digest(ROOT / filename) != expected:
            raise RuntimeError(f"Parent file changed before audit: {filename}")
    sys.path.insert(0, str(ROOT))
    import correlation_certificate as cc
    import uniform_correlation as uc
    import metric_correlation as mc

    rows = []

    def record(name, ok, **details):
        rows.append({"name": name, "pass": bool(ok), **details})

    def rejects(name, thunk, exceptions=(ValueError, TypeError)):
        try:
            thunk()
        except exceptions as exc:
            record(name, True, exception=type(exc).__name__, message=str(exc))
        except Exception as exc:
            record(name, False, exception=type(exc).__name__, message=str(exc))
        else:
            record(name, False, message="No rejection")

    t = {
        0: [[F(1, 4), F(1, 5)], [F(0), F(1, 3)]],
        1: [[F(1, 5), F(0)], [F(1, 7), F(1, 4)]],
    }
    rep = cc.Representation([(), (0,)], t)
    values = {w: F(1, 2 ** len(w)) for w in rep.acquisition_words()}
    data = cc.Correlations({w: (q, q) for w, q in values.items()})
    eps = F(1, 1000)
    widened = cc.Correlations({w: (q, q) if not w else (q-eps, q+eps)
                              for w, q in values.items()})

    # Independent feature Gram and defect matrices for the already exposed
    # one-dimensional observable orbit with V=(f, f/2), ||f||=1.
    v = [F(1), F(1, 2)]
    gram = [[x*y for y in v] for x in v]
    h = [[x/2 for x in row] for row in gram]
    defects = {a: subtract(h, matrix_product(gram, mat)) for a, mat in t.items()}
    residuals = {}
    for a, mat in t.items():
        vt = [sum((v[i] * mat[i][j] for i in range(2)), F(0)) for j in range(2)]
        d = [v[i]/2-vt[i] for i in range(2)]
        residuals[a] = [[x*y for y in d] for x in d]

    plain = uc.uniform_certificate(rep, data, bits=20)
    metric = [[F(4), F(0)], [F(0), F(1)]]
    weighted = mc.metric_certificate(rep, data, metric, precision=20, sqrt_bits=20)
    record("singular_true_Gram_allowed", gram[0][0]*gram[1][1] == gram[0][1]**2
           and plain["status"] == weighted["status"] == "CERTIFIED_UNDER_CONTRACT")
    for target in ((), (0,), (0, 1, 0)):
        direct = direct_center(t, gram, defects, target)
        qp, qm = uc.run_program(plain, target), uc.run_program(weighted, target)
        record(f"compiler_{target}", qp == qm == direct,
               direct=str(direct), plain=str(qp), metric=str(qm))
        true = F(1, 2 ** len(target))
        record(f"uniform_interval_coverage_{target}",
               abs(qp-true) <= plain["uniform_error"]
               and abs(qm-true) <= weighted["uniform_error"])
    record("empty_compiler_returns_G00", uc.run_program(plain, ()) == gram[0][0]
           and uc.run_program(weighted, ()) == gram[0][0])

    bad_t = [[F(3, 4), F(0)], [F(3, 4), F(0)]]
    bad_rep = cc.Representation([(), (0,)], {0: bad_t})
    upper = uc.norm2_upper(bad_t, bits=20)
    bad_plain = uc.uniform_certificate(bad_rep, data, bits=20)
    record("row_norm_not_mistaken_for_operator_norm", upper*upper >= F(9, 8)
           and bad_plain["status"] == "UNKNOWN", upper=str(upper))
    bad_metric = mc.metric_certificate(bad_rep, data, metric, precision=20, sqrt_bits=20)
    exact_b = matrix_product(matrix_product(transpose(bad_t), metric), bad_t)
    witness = [[F(45, 64)*metric[i][j]-exact_b[i][j] for j in range(2)]
               for i in range(2)]
    record("metric_rescues_nonnormal_contraction", exact_psd_2(witness)
           and bad_metric["status"] == "CERTIFIED_UNDER_CONTRACT"
           and bad_metric["coefficient_contraction_upper"] < 1)

    # This tests the theorem's finite combinatorics, not an absent parent API.
    for r in (F(0), F(1, 2)):
        for n in (0, 1, 2, 3, 10):
            pair_sum = sum((r**(i-1+n-j) for i in range(1, n+1)
                            for j in range(i+1, n+1)), F(0))
            series = sum(((k+1)*r**k for k in range(max(0, n-1))), F(0))
            record(f"pair_factor_r{r}_N{n}", pair_sum == series <= 1/(1-r)**2,
                   value=str(pair_sum), scope="independent theorem combinatorics")

    wider_plain = uc.uniform_certificate(rep, widened, bits=20)
    wider_metric = mc.metric_certificate(rep, widened, metric, precision=20, sqrt_bits=20)
    for name, narrow, wide in (("plain", plain, wider_plain), ("metric", weighted, wider_metric)):
        fields = ("gram_estimation_norm_upper", "defect_estimation_norm_upper",
                  "residual_operator_square_upper", "uniform_error")
        record(f"symmetric_widening_{name}",
               all(wide[k] >= narrow[k] for k in fields))
        for a in t:
            if name == "plain":
                ka = wide["diagnostics"][a]["residual_operator_square_upper"]
                majorant = [[ka*F(i == j)-residuals[a][i][j] for j in range(2)]
                            for i in range(2)]
            else:
                ka = wide["diagnostics"][a]["residual_metric_square_upper"]
                majorant = [[ka*metric[i][j]-residuals[a][i][j] for j in range(2)]
                            for i in range(2)]
            record(f"residual_domination_{name}_action{a}", exact_psd_2(majorant))

    rejects("negative_norm_precision", lambda: uc.uniform_certificate(rep, data, bits=-1))
    rejects("negative_metric_precision", lambda: mc.metric_certificate(rep, data, metric, precision=-1))
    rejects("negative_metric_sqrt_precision", lambda: mc.metric_certificate(rep, data, metric, sqrt_bits=-1))
    rejects("float_metric", lambda: mc.metric_certificate(rep, data, [[4.0, 0], [0, 1]]))
    rejects("float_contraction_matrix", lambda: cc.Representation([()], {0: [[0.5]]}))
    rejects("indefinite_metric", lambda: mc.metric_certificate(rep, data, [[1, 2], [2, 1]]))
    rejects("singular_metric", lambda: mc.metric_certificate(rep, data, [[1, 1], [1, 1]]))
    record("zero_pivot_PSD", mc.psd([[0, 0], [0, 1]]) and not mc.psd([[0, 0], [0, 1]], strict=True))
    record("zero_pivot_offdiagonal_obstruction", not mc.psd([[0, 1], [1, 1]]))

    c, calls = mc.dominate(exact_b, metric, precision=20)
    record("domination_witness_exact", c >= 0 and exact_psd_2(
        [[c*metric[i][j]-exact_b[i][j] for j in range(2)] for i in range(2)]),
        c=str(c), exact_threshold="45/64", psd_checks=calls)
    rejects("domination_budget_exhaustion", lambda: mc.dominate([[1, 0], [0, 1]], metric,
                                                                 max_doublings=0), ArithmeticError)

    # The selected nonsymmetric radius has row-only metric constant 1,
    # but normalized error [[0,2],[1/2,0]] has operator norm 2.
    radius = [[F(0), F(4)], [F(1), F(0)]]
    row_majorant = [[F(4), F(0)], [F(0), F(1)]]
    col_majorant = [[F(1), F(0)], [F(0), F(4)]]
    erow, _ = mc.dominate(row_majorant, metric, precision=20)
    ecol, _ = mc.dominate(col_majorant, metric, precision=20)
    record("nonsymmetric_row_only_would_fail", erow == 1 and erow < 2 <= max(erow, ecol),
           row_bound=str(erow), column_bound=str(ecol), exact_normalized_norm="2")
    # Inspectable code also calls both bounds; the theorem requires both.
    r = weighted["coefficient_contraction_upper"]
    formula = metric[0][0]*(weighted["gram_estimation_norm_upper"]
                           +weighted["defect_estimation_norm_upper"]/(1-r)
                           +weighted["residual_operator_square_upper"]/(1-r)**2)
    record("metric_initial_norm_factor", weighted["uniform_error"] == formula)
    for filename, expected in EXPECTED.items():
        record(f"unchanged_{filename}", digest(ROOT/filename) == expected)

    out = {
        "status": "PASS" if all(row["pass"] for row in rows) else "FAIL",
        "total_checks": len(rows),
        "failures": [row["name"] for row in rows if not row["pass"]],
        "contracts": {name: digest(HERE/name) for name in
                      ("UNIFORM_AUDIT_CONTRACT.json", "METRIC_AUDIT_CONTRACT.json")},
        "parent_code_sha256": EXPECTED,
        "checks": rows,
        "scope": "Frozen bounded algebraic audit; no scientific transfer claim.",
        "prior_exposure": "C(w)=2^(-len(w)) was already exposed in the core audit.",
    }
    (HERE / "UNIFORM_METRIC_AUDIT_RESULTS.json").write_text(json.dumps(out, indent=2)+"\n")
    print(json.dumps({k: out[k] for k in ("status", "total_checks", "failures")}, indent=2))
    if out["failures"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
