"""Independent oracle: source-matrix endpoints and direct killed-port paths.

No renewal deconvolution, trie implementation, or root code is imported.
The oracle computes first returns by setting port mass to zero at each proper
prefix, then retaining the endpoint port mass. All arithmetic is rational.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import time


HERE=Path(__file__).resolve().parent
INPUT=HERE/'renewal_confirmation_inputs.json'
EXPECTED_INPUT_SHA='d62db380579bff079b20332555a9f9908ae8940ae2e8ae031c5a4539d1057ee6'


class Direct:
    def __init__(self, matrices):
        self.matrices=matrices
        self.n=len(matrices[0])
        self.products=0
        self.additions=0
        self.max_numerator_bits=1
        self.max_denominator_bits=1

    def observe(self,x):
        self.max_numerator_bits=max(self.max_numerator_bits,abs(x.numerator).bit_length())
        self.max_denominator_bits=max(self.max_denominator_bits,x.denominator.bit_length())
        return x

    def step(self,state,action):
        mat=self.matrices[action]
        out=[]
        for i in range(self.n):
            acc=F(0)
            for j in range(self.n):
                term=self.observe(mat[i][j]*state[j])
                self.products+=1
                acc=self.observe(acc+term)
                self.additions+=1
            out.append(acc)
        return out

    def response(self,word,kill_intermediate_port=False):
        if not word and kill_intermediate_port:
            return F(0)  # Empty word is not a positive-time first return.
        state=[F(1)]+[F(0)]*(self.n-1)
        for index,action in enumerate(word):
            state=self.step(state,action)
            if kill_intermediate_port and index+1<len(word):
                state[0]=F(0)
        return state[0]


def main():
    start=time.perf_counter()
    raw=INPUT.read_bytes()
    sha=hashlib.sha256(raw).hexdigest()
    assert sha==EXPECTED_INPUT_SHA, ('Input changed after freeze',sha)
    source=json.loads(raw)
    output={
        'kind':'Independent direct exact algebra oracle; no scientific-transfer claim',
        'input_sha256':sha,
        'oracle_method':'Column-state multiplication; first-return oracle kills port mass at every proper prefix',
        'root_renewal_code_read_or_imported':False,
        'cases':[],
        'failures':[],
    }
    for case in source['cases']:
        case_start=time.perf_counter()
        n,k=case['dimension'],case['alphabet']
        matrices=[[[F(v) for v in row] for row in mat] for mat in case['matrices']]
        assert len(matrices)==k
        for mat in matrices:
            assert len(mat)==n and all(len(row)==n for row in mat)
            assert all(v>=0 for row in mat for v in row)
            assert all(sum(mat[i][j] for i in range(n))<=1 for j in range(n))
        dictionary={tuple(w) for w in case['dictionary']}
        assert () in dictionary and max(map(len,dictionary))<=4
        for w in dictionary:
            assert all(tuple(w[i:j]) in dictionary for i in range(len(w))
                       for j in range(i+1,len(w)+1))
        target_words={tuple(w) for w in case['target_words']}
        all_words=sorted(target_words|dictionary,key=lambda w:(len(w),w))
        oracle=Direct(matrices)
        records=[]
        for word in all_words:
            assert all(0<=a<k for a in word)
            q=oracle.response(word)
            f=oracle.response(word,kill_intermediate_port=True)
            assert 0<=q<=1 and 0<=f<=q
            records.append({'word':list(word),'endpoint':str(q),
                            'first_return':str(f),'in_dictionary':word in dictionary,
                            'designated_target':word in target_words})
        output['cases'].append({
            'id':case['id'],
            'dimension':n,
            'alphabet':k,
            'dictionary_count':len(dictionary),
            'target_count':len(target_words),
            'source_column_substochastic':True,
            'dictionary_factor_closed':True,
            'records':records,
            'direct_recurrence_multiplications':oracle.products,
            'direct_recurrence_additions':oracle.additions,
            'maximum_intermediate_numerator_bits':oracle.max_numerator_bits,
            'maximum_intermediate_denominator_bits':oracle.max_denominator_bits,
            'wall_seconds':time.perf_counter()-case_start,
        })
    output['total_wall_seconds']=time.perf_counter()-start
    output['status']='direct oracle complete; awaiting independent renewal comparison'
    payload=json.dumps(output,indent=2)+'\n'
    path=HERE/'renewal_direct_oracle_results.json'
    path.write_text(payload)
    print(json.dumps({'file':str(path),'sha256':hashlib.sha256(payload.encode()).hexdigest(),
                      'cases':[{key:c[key] for key in [
                          'id','dictionary_count','target_count',
                          'direct_recurrence_multiplications','direct_recurrence_additions',
                          'maximum_intermediate_numerator_bits',
                          'maximum_intermediate_denominator_bits','wall_seconds']}
                              for c in output['cases']],
                      'total_wall_seconds':output['total_wall_seconds'],
                      'failures':output['failures']},indent=2))


if __name__=='__main__':
    main()
