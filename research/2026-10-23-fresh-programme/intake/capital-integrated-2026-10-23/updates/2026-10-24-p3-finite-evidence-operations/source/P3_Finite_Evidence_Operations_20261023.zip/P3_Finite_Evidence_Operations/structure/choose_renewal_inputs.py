"""Bounded independent exact theorem-challenge inputs, chosen before root code.

These are authored algebraic cases, not scientific or empirical transfer data.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import hashlib
import json


def columns(cols, denominator=1):
    return [[str(F(cols[j][i], denominator)) for j in range(len(cols))]
            for i in range(len(cols[0]))]


def factors(seeds, alphabet, complete_depth=0):
    d = {()}
    for n in range(1, complete_depth + 1):
        d.update(product(range(alphabet), repeat=n))
    for w in seeds:
        d.update(tuple(w[i:j]) for i in range(len(w)) for j in range(i+1,len(w)+1))
    return [list(w) for w in sorted(d, key=lambda w:(len(w),w))]


def targets(alphabet, long):
    max_len = 6 if alphabet == 2 else 5
    t = {w for n in range(max_len+1) for w in product(range(alphabet),repeat=n)}
    t.update(tuple(w) for w in long)
    return [list(w) for w in sorted(t,key=lambda w:(len(w),w))]


def sparse_columns(n, entries):
    cols = [[F(0) for _ in range(n)] for _ in range(n)]
    for col, row, value in entries:
        cols[col][row] = F(value)
    return columns(cols)


cases = [
    {
        'id':'dense_loss_dim2',
        'alphabet':2,
        'dimension':2,
        'matrices':[
            columns([[F(1,5),F(1,2)],[F(2,5),F(1,4)]]),
            columns([[F(2,7),F(3,7)],[F(1,3),F(1,6)]])
        ],
        'dictionary':factors([],2,complete_depth=3),
        'target_words':targets(2,[(0,1)*4,(1,1,0)*3,(0,)*10]),
        'reason':'Dense positive operators with loss and unequal rational denominators; complete depth-three dictionary.',
    },
    {
        'id':'deterministic_zero_survival_dim4',
        'alphabet':2,
        'dimension':4,
        'matrices':[
            columns([[0,1,0,0],[1,0,0,0],[0,0,0,1],[0,0,1,0]]),
            columns([[0,0,1,0],[0,1,0,0],[0,0,0,1],[1,0,0,0]])
        ],
        'dictionary':factors([(0,0),(1,1,1),(0,1,0),(1,0,1,1)],2),
        'target_words':targets(2,[(0,0)*5,(1,1,1)*3,(1,0,1,1)*2]),
        'reason':'Sparse normalized operators; exact zero/one endpoints and zero-survival trie nodes; incomplete dictionary.',
    },
    {
        'id':'three_modes_mixed_support_dim5',
        'alphabet':3,
        'dimension':5,
        'matrices':[
            columns([[1,3,2,2,2],[4,1,3,2,0],[0,2,4,1,3],
                     [3,0,2,4,1],[2,3,1,0,4]],10),
            columns([[2,1,4,1,3],[1,4,2,3,1],[4,2,1,1,3],
                     [1,3,2,4,1],[3,1,1,2,4]],11),
            columns([[1,2,3,4,1],[2,0,1,4,3],[3,2,0,1,4],
                     [4,1,2,0,3],[0,3,4,2,1]],13)
        ],
        'dictionary':factors([(0,1,2,0),(2,2,1),(1,0,1),(0,0)],3),
        'target_words':targets(3,[(0,1,2)*3,(2,1,0,2,0,1,2,2),
                                (0,)*8,(1,2)*4]),
        'reason':'Three modes, varied support, incomplete factor-closed dictionary, and action-dependent loss.',
    },
    {
        'id':'long_hidden_excursions_dim6',
        'alphabet':2,
        'dimension':6,
        'matrices':[
            sparse_columns(6,[(0,0,'1/6'),(0,1,'2/3'),
                              (1,0,'1/8'),(1,2,'3/4'),
                              (2,1,'1/10'),(2,3,'4/5'),
                              (3,0,'1/12'),(3,4,'5/6'),
                              (4,2,'1/14'),(4,5,'6/7'),
                              (5,0,'7/8'),(5,5,'1/16')]),
            sparse_columns(6,[(0,0,'1/4'),(0,5,'1/2'),
                              (1,0,'2/3'),(1,3,'1/6'),
                              (2,1,'3/5'),(2,4,'1/5'),
                              (3,0,'1/7'),(3,2,'4/7'),
                              (4,1,'2/9'),(4,3,'5/9'),
                              (5,2,'3/11'),(5,4,'6/11')])
        ],
        'dictionary':factors([(0,0,0,0),(1,1,1),(0,1),(1,0,1)],2,1),
        'target_words':targets(2,[(0,)*12,(1,)*9,(0,1)*6,(0,0,1,1)*3]),
        'reason':'Sparse lossy modes with excursions beyond measured word lengths; incomplete dictionary.',
    },
]

out = {
    'purpose':'Four independent authored exact falsification cases; no empirical-transfer claim',
    'contract_sha256':'275315baca4cb4dc652922e9820fe3377b347f26f7cafe99374b379b55de92c5',
    'orientation':'column substochastic; chronological word; port index 0; initial state e_0',
    'prior_exposure':'General renewal theorem and root positive-system checks were seen; root renewal implementation was not inspected.',
    'selection':'Matrices and dictionaries chosen before any response or first-return oracle calculation; no filtering on results.',
    'cases':cases,
}
path=Path(__file__).with_name('renewal_confirmation_inputs.json')
payload=(json.dumps(out,indent=2)+'\n').encode()
if path.exists() and path.read_bytes()!=payload:
    raise RuntimeError('Frozen input file already exists with different contents')
path.write_bytes(payload)
print(json.dumps({'file':str(path),'sha256':hashlib.sha256(payload).hexdigest(),
                  'case_counts':[{'id':c['id'],'dictionary':len(c['dictionary']),
                                  'targets':len(c['target_words'])} for c in cases]},indent=2))
