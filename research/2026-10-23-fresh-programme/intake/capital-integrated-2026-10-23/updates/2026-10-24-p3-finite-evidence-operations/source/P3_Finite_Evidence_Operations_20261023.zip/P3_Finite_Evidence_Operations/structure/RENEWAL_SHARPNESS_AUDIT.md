# Independent audit and bounded exact falsification of the renewal theorem

Private P3 structure/access worker, 23 October 2026. This is a theorem and
implementation audit. The four matrices below are independently selected
authored constructions, not independent scientific systems or empirical
transfer evidence. No physical measurements were acquired.

## 1. Independent proof audit

The claimed theorem is valid for the stated class: common action operators
are nonnegative substochastic kernels with a genuinely atomic/regenerative
initial/readout port, and no upper bound on hidden dimension is known. Let D
be finite and factor-closed, including the empty word, with exact endpoint
responses q and q(empty)=1.

The renewal equation determines retained first-return coefficients by

```
f(w)=q(w)-sum_(w=uv, u,v nonempty) f(u)q(v).
```

Factor closure makes all required prefixes and suffixes available. These f
must be nonnegative, and the sum over nonempty prefixes of any retained word
must not exceed one. First-return events along the same controlled word are
disjoint, which proves the latter condition independently of matrix dimension.

Conversely, suppose these conditions hold. Let

```
s(v)=1-sum_(nonempty prefixes u of v) f(u).
```

A history-trie state v records the current action prefix since the last port
visit without a return. For a retained next prefix va, a state with s(v)>0
returns to the port with probability f(va)/s(v) and continues to va with
probability s(va)/s(v). The two probabilities sum to one. Off-trie mass is
killed. If s(v)=0, that history is unreachable without a previous return;
all descendant f must be zero, so its outgoing row/column may be zero.

Induction shows that the excursion mass surviving prefix v is s(v), and
that the first-return mass at va is f(va). Thus the construction realizes
the retained f and sets every unretained first-return word to zero. Storing
only proper prefixes and killing residual mass at a leaf immediately yields
the same port responses as storing every leaf and killing on its next action.

Every endpoint-return path has a unique decomposition into first-return
excursions. Consequently the response is the noncommutative renewal star.
Discarding unretained excursions gives the lower series

```
B_D(w)=sum_(partitions w=v1...vr, every vi in D\{empty}) product_i f(vi).
```

The trie attains B_D for every target word simultaneously. For any v in D,
every block in every partition of v is still in D, so the construction matches
all the original endpoint responses exactly. This proves compatibility and
simultaneous sharpness, rather than merely a separate minimizing source for
each target.

Expanding any retained-block product into first-return partitions selects a
subset of the same nonnegative terms. Therefore B_D dominates the strongest
maximum-over-retained-block-partitions lower bound under exact complete input
on the chosen factor-closed D. This does not imply dominance after noisy
endpoints have been reduced to separate conservative f bounds.

### Scope limits independently checked

* Nonnegative matrices are essential to this attainment statement. The trie
  has zeros and killing. It is not an attaining member of an extra strict
  positivity or quantitative mixing class.
* The feasibility conditions do not imply eventual transience. For example,
  retained first-return mass can sum exactly to one and regenerate indefinitely.
* A coarse observed port is insufficient. Hidden memory within the label
  can make its future law depend on how it was reached. The theorem requires
  genuine regeneration in the full future-relevant state.
* Exact q is an information contract, not the output of a finite number of
  generic Bernoulli trials. Noisy acquisition needs a separate confidence
  argument and precision cost.
* A retaining renewal/weighted-automaton method computes the same sharp
  operation. No architectural separation or historical novelty follows.

## 2. Frozen independent exact falsification round

Root froze the claims before the four worker cases were selected:

```
root/RENEWAL_CHECK_CONTRACT.json
SHA256 275315baca4cb4dc652922e9820fe3377b347f26f7cafe99374b379b55de92c5
```

I then selected all matrices, dictionaries and designated words before any
oracle response calculation and without inspecting root's renewal code:

```
structure/renewal_confirmation_inputs.json
SHA256 d62db380579bff079b20332555a9f9908ae8940ae2e8ae031c5a4539d1057ee6
```

| Case | Hidden dimension | Modes | Dictionary words | Designated targets | Challenge |
|---|---:|---:|---:|---:|---|
| dense_loss_dim2 | 2 | 2 | 15 | 130 | Dense loss, unequal denominators, complete depth 3 |
| deterministic_zero_survival_dim4 | 4 | 2 | 12 | 130 | Sparse exact zeros/ones, unreachable trie histories |
| three_modes_mixed_support_dim5 | 5 | 3 | 16 | 368 | Three modes, incomplete dictionary, mixed support/loss |
| long_hidden_excursions_dim6 | 6 | 2 | 11 | 131 | Sparse loss and excursions longer than measured words |

All binary words through length 6 and ternary words through length 5 were
designated, together with the frozen structured longer words. The total is
759 target words. None was selected after inspecting pass/fail results.

The independent oracle imports no root code and uses no renewal deconvolution
or trie. It directly multiplies the source matrices. To calculate a positive
first-return probability, it sets the port mass to zero after every proper
prefix, then reads the port mass at the final step. The empty endpoint is one;
the positive-time first-return coefficient of the empty word is zero.

```
structure/renewal_direct_oracle.py
structure/renewal_direct_oracle_results.json
results SHA256 828e98ead975f83fd4ff9f9db13f72d6c682458dfd9f77e41e76d09ed185ee59
```

All input substochastic and factor-closure checks passed. Independent oracle
runtime was approximately 0.331 seconds. The largest observed intermediate
numerator and denominator had 77 and 82 bits. These are implementation
observations, not source-acquisition or asymptotic cost claims. No failed input
selection or oracle calculation occurred. Parsing and validation costs are
included in wall time; the stored arithmetic counts cover direct multiplication
recurrences only.

Root's implementation was independently frozen before root opened these
cases:

```
root/renewal.py
initial SHA256 30f4311c96153291b3014e0c456d8b450d35e18e5cfe1501f93a78888e2addc5
```

After saving the oracle, I read that code. Its core deconvolution, prefix-mass
check, positive renewal DP and proper-prefix trie agree with the theorem.
Root subsequently executed the frozen comparison and recorded 2,381 passing
exact equalities/inequalities on the 759 designated words, with no failures,
in root/RENEWAL_CONFIRMATION.json. I inspected that result after my
independent oracle and code audit were complete. The original root core
is preserved as root/renewal_frozen.py with the initial SHA256 above.

### Preserved helper discrepancy

The initial root helper `matrix_endpoint((), ..., first_return=True)` returns
one, whereas the empty positive-time first-return coefficient is zero. The
core kernel excludes the empty word, so this does not invalidate its theorem
or nonempty first-return checks. I reported the discrepancy before seeing
the root comparison result. Root then corrected only the empty-word helper,
and preserved the focused checks in root/RENEWAL_BOUNDARY_REPAIR.json.
The current-file SHA256 in that repair record is
679b2dd0ae80c93cdfbd8ab9c2735c655c9b2409598ad68a76e7d592a3e5b383.
This correction does not enlarge the empirical scope of the frozen round.

## 3. Separate analytic audit of the noisy extension

The noisy formula was added beyond the frozen core and is not automatically
confirmed by this four-case exact round. Its derivation can nevertheless be
checked directly. Let Qhat be the noisy endpoint series with exact empty
coefficient one, and Fhat=1-Qhat^(-1). Then

```
F-Fhat = (1-F)(Q-Qhat)(1-Fhat).
```

If endpoint coefficient errors are bounded by eta, the coefficient of
`(Q-Qhat)(1-Fhat)` at w is bounded by

```
E(w)=eta(w)+sum_(w=uv, u,v nonempty) eta(u)*abs(Fhat(v)).
```

Multiplication by (1-F) adds a weighted sum of proper-suffix errors. The
nonnegative first-return prefix weights sum to at most one, giving

```
|F(w)-Fhat(w)| <= E(w)+max_(proper nonempty suffix v) E(v).
```

This justifies the code's conservative lower coefficients on the simultaneous
endpoint-confidence event. It does not make their resulting lower series
sharp under all original correlated endpoint intervals. Root should retain
the maximum of this certificate and any independently sound block bound.

The proposed coefficient derivative is also correct: for R=(1-F)^(-1),
variation of one first-return coefficient at word v gives `dR=R E_v R`.
The target coefficient sums over occurrences of v, multiplying the response
of the preceding and following word. It is an ambient sensitivity, not a
guarantee that a proposed coefficient change is feasible or that its acquisition
is worth the cost.

I also checked the partial worker's finite-T rare-loss separation and its
joint-mass certificate analytically. The KL sign/constants, the `gamma=3/T`
finite-horizon gap, and the separate first-return multinomial confidence
argument are consistent. The advantage belongs to the richer bounded-length
observation interface. Direct long endpoint experiments remove a broad
one-target efficiency claim, as explicitly acknowledged in that proof.
