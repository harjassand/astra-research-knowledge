"""Exact rational primitives for the atomic-return lower-envelope theorem.

No unknown system, atomic-port warrant, confidence coverage, or physical
measurements are invented by this module. Inputs are acquired endpoint tables
or already warranted first-return lower coefficients. See
ATOMIC_RETURN_KERNELS.md for the proofs, costs, and limitations.

Words are tuples of action names. Arithmetic is exact Fraction arithmetic;
its bit cost is not constant. The clear reference deconvolution uses tuple
slicing and therefore has extra preprocessing/key-lookup length costs beyond
the theorem's arithmetic count. Long-word evaluation uses a trie.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from fractions import Fraction as F
import json
from typing import Mapping

Word = tuple[str, ...]
Table = dict[Word, F]


def rational_table(values: Mapping[Word, F | int | str]) -> Table:
    if any(isinstance(value, float) for value in values.values()):
        raise TypeError("Use Fraction, integer, or explicit decimal/rational strings")
    return {tuple(word): F(value) for word, value in values.items()}


def check_dictionary(values: Mapping[Word, object]) -> list[Word]:
    if () not in values:
        raise ValueError("Dictionary must contain the empty word")
    ordered = sorted(values, key=lambda word: (len(word), word))
    for word in ordered:
        if word and (word[:-1] not in values or word[1:] not in values):
            raise ValueError("Dictionary is not factor-closed")
    return ordered


def deconvolve(q: Mapping[Word, F | int | str]) -> Table:
    """Formal first-return inversion; negative coefficients are not hidden."""
    q = rational_table(q)
    ordered = check_dictionary(q)
    if q[()] != 1:
        raise ValueError("q(empty) must equal one")
    first = {(): F(0)}
    for word in ordered[1:]:
        first[word] = q[word] - sum(
            (first[word[:cut]] * q[word[cut:]] for cut in range(1, len(word))), F(0)
        )
    return first


def survival_masses(first: Mapping[Word, F | int | str]) -> Table:
    """Validate nonnegativity and prefix mass, returning unreturned masses."""
    first = rational_table(first)
    ordered = check_dictionary(first)
    if first[()] != 0:
        raise ValueError("First return at empty word must be zero")
    survival = {(): F(1)}
    for word in ordered[1:]:
        if first[word] < 0:
            raise ValueError("Negative first-return coefficient")
        survival[word] = survival[word[:-1]] - first[word]
        if survival[word] < 0:
            raise ValueError("First-return prefix probabilities exceed one")
    return survival


@dataclass
class Trie:
    children: dict[str, "Trie"] = field(default_factory=dict)
    weight: F = F(0)


def make_trie(weights: Mapping[Word, F | int | str]) -> tuple[Trie, int]:
    root = Trie()
    longest = 0
    for word, weight in rational_table(weights).items():
        if not word:
            continue
        node = root
        for action in word:
            node = node.children.setdefault(action, Trie())
        node.weight = weight
        longest = max(longest, len(word))
    return root, longest


def renewal_value(first: Mapping[Word, F | int | str], word: Word) -> F:
    """Sum all first-return compositions, with O(TL) trie/arithmetic steps."""
    survival_masses(first)
    root, longest = make_trie(first)
    value = [F(0)] * (len(word) + 1)
    value[-1] = F(1)
    for start in range(len(word) - 1, -1, -1):
        node = root
        for end in range(start, min(len(word), start + longest)):
            node = node.children.get(word[end])
            if node is None:
                break
            value[start] += node.weight * value[end + 1]
    return value[0]


def block_product_value(q_lower: Mapping[Word, F | int | str], word: Word) -> F:
    """Strongest max-product partition using the retained endpoint bounds."""
    q_lower = rational_table(q_lower)
    if any(not 0 <= value <= 1 for value in q_lower.values()):
        raise ValueError("Endpoint lower coefficients must lie in [0,1]")
    root, longest = make_trie(q_lower)
    value = [F(0)] * (len(word) + 1)
    value[-1] = F(1)
    for start in range(len(word) - 1, -1, -1):
        node = root
        for end in range(start, min(len(word), start + longest)):
            node = node.children.get(word[end])
            if node is None:
                break
            value[start] = max(value[start], node.weight * value[end + 1])
    return value[0]


def lower_dyadic_value(
    first: Mapping[Word, F | int | str], word: Word, bits: int
) -> tuple[F, F]:
    """Downward certificate and upper bound on its rounding loss.

    Coefficients are rounded down, each complete local sum is rounded down
    once, and all intervening operations use exact integers. Loss relative
    to the exact supplied-kernel renewal value is <=T(L+1)*2^-bits.
    """
    if bits < 0:
        raise ValueError("Negative precision")
    survival_masses(first)
    scale = 1 << bits
    rounded = {
        w: F((F(x) * scale).numerator // (F(x) * scale).denominator, scale)
        for w, x in first.items()
    }
    root, longest = make_trie(rounded)
    value = [0] * (len(word) + 1)
    value[-1] = scale
    for start in range(len(word) - 1, -1, -1):
        node = root
        total = 0
        for end in range(start, min(len(word), start + longest)):
            node = node.children.get(word[end])
            if node is None:
                break
            coefficient = int(node.weight * scale)
            total += coefficient * value[end + 1]
        value[start] = total // scale
    return F(value[0], scale), F(len(word) * (longest + 1), scale)


def endpoint_noise_lower(
    nominal_q: Mapping[Word, F | int | str],
    radius: Mapping[Word, F | int | str],
) -> tuple[Table, Table, Table]:
    """Return (f_lower, fhat, B) from the formal inverse sensitivity bound.

    Validity is conditional on simultaneous endpoint coverage and the
    atomic-port source contract. This does not replace the sharper coupled
    robust optimization over all endpoint constraints.
    """
    nominal_q, radius = rational_table(nominal_q), rational_table(radius)
    ordered = check_dictionary(nominal_q)
    if set(radius) != set(nominal_q) or radius[()] != 0:
        raise ValueError("Radius table must match q and be zero at empty")
    if any(error < 0 for error in radius.values()):
        raise ValueError("Negative confidence radius")
    estimate = deconvolve(nominal_q)
    e_bound, b_bound, lower = {(): F(0)}, {(): F(0)}, {(): F(0)}
    for word in ordered[1:]:
        e_bound[word] = radius[word] + sum(
            (radius[word[:cut]] * abs(estimate[word[cut:]])
             for cut in range(1, len(word))), F(0)
        )
        suffix_bound = max(
            (e_bound[word[cut:]] for cut in range(1, len(word))), default=F(0)
        )
        b_bound[word] = e_bound[word] + suffix_bound
        lower[word] = max(F(0), estimate[word] - b_bound[word])
    # On a valid confidence event, these inequalities necessarily hold.
    # If not, reject rather than printing an apparently probabilistic result.
    survival_masses(lower)
    return lower, estimate, b_bound


def trie_realization(first: Mapping[Word, F | int | str]):
    """Construct the exact simultaneous attainer as sparse substochastic rows."""
    first = rational_table(first)
    survival = survival_masses(first)
    states = check_dictionary(first)
    index = {word: i for i, word in enumerate(states)}
    alphabet = sorted({action for word in states for action in word})
    matrices = {action: [dict() for _ in states] for action in alphabet}
    for state in states:
        if survival[state] == 0:
            continue
        for action in alphabet:
            successor = state + (action,)
            if successor not in first:
                continue
            row = matrices[action][index[state]]
            if first[successor]:
                row[0] = first[successor] / survival[state]
            if survival[successor]:
                row[index[successor]] = survival[successor] / survival[state]
            assert sum(row.values(), F(0)) <= 1
    return states, matrices


def sparse_port_response(matrices, word: Word) -> F:
    distribution = {0: F(1)}
    for action in word:
        if action not in matrices:
            return F(0)
        updated: dict[int, F] = {}
        for state, mass in distribution.items():
            for destination, probability in matrices[action][state].items():
                updated[destination] = updated.get(destination, F(0)) + mass * probability
        distribution = updated
    return distribution.get(0, F(0))


def algebraic_checks() -> dict[str, object]:
    """Exact proof witnesses only; no training, simulation or transfer benchmark."""
    q = {(): F(1), ("a",): F(1, 2), ("a", "a"): F(3, 4)}
    first = deconvolve(q)
    _, matrices = trie_realization(first)
    target = ("a",) * 3
    lower, block = renewal_value(first, target), block_product_value(q, target)
    assert lower == F(5, 8) and block == F(3, 8)
    assert sparse_port_response(matrices, target) == lower
    for word, value in q.items():
        assert sparse_port_response(matrices, word) == value
    rounded, loss = lower_dyadic_value(first, target, 12)
    assert rounded <= lower <= rounded + loss

    noisy = {(): F(1), ("a",): F(9, 10), ("a", "a"): F(81, 100)}
    radius = {(): F(0), ("a",): F(1, 100), ("a", "a"): F(1, 100)}
    noisy_lower, _, _ = endpoint_noise_lower(noisy, radius)
    endpoint_lower = {w: max(F(0), noisy[w] - radius[w]) for w in noisy}
    noise_bound = renewal_value(noisy_lower, target)
    retained_bound = block_product_value(endpoint_lower, target)
    assert noise_bound == F(704969, 1000000) < retained_bound == F(89, 125)
    return {
        "scope": "Exact algebraic witnesses; no empirical performance claim",
        "strict_exact_renewal_bound": str(lower),
        "max_product_bound": str(block),
        "trie_attains_every_retained_value": True,
        "trie_attains_unqueried_word_bound": True,
        "conservative_endpoint_noise_bound": str(noise_bound),
        "stronger_retained_endpoint_block_bound_in_noisy_case": str(retained_bound),
        "dyadic_lower": str(rounded),
        "dyadic_loss_upper": str(loss),
    }


if __name__ == "__main__":
    print(json.dumps(algebraic_checks(), indent=2))
