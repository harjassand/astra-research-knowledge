"""Post-confirmation exact policy checks on already exposed independent cases.

No new empirical/transfer claim: verifies the new return-reward theorem and
division-free recurrence against full hidden-state observation-tree enumeration.
"""
from fractions import Fraction as F
from pathlib import Path
import json
import time
import renewal as r
from return_controller import (all_policy_trees,evaluate_tree,
    synthesize_count_controller,synthesize_count_controller_mass)


def main():
    start=time.perf_counter()
    here=Path(__file__).resolve().parent
    raw=json.loads((here.parent/'structure/renewal_confirmation_inputs.json').read_text())
    results=[]
    comparisons=0
    for case in raw['cases']:
        matrices={i:[[F(v) for v in row] for row in p]
                  for i,p in enumerate(case['matrices'])}
        q={tuple(w):r.matrix_endpoint(w,matrices) for w in case['dictionary']}
        f=r.endpoint_to_first_return(q)
        alphabet=range(case['alphabet'])
        dp=synthesize_count_controller(f,alphabet,3,2)
        mass=synthesize_count_controller_mass(f,alphabet,3,2)
        assert mass['value']==dp['value']
        for (t,idx,need),value in dp['values'].items():
            u=dp['states'][idx]
            s=1-sum((f.get(u[:i],F(0)) for i in range(1,len(u)+1)),F(0))
            assert mass['mass_values'][t,u,need]==s*value
            comparisons+=1
        trees=all_policy_trees(alphabet,3)
        best=F(0)
        truebest=F(0)
        for tree in trees:
            actual=evaluate_tree(tree,matrices,2)
            lower=evaluate_tree(tree,dp['matrices'],2)
            assert lower<=actual
            best=max(best,lower)
            truebest=max(truebest,actual)
            comparisons+=1
        assert best==dp['value']
        results.append({'case':case['id'],'policies':len(trees),
            'guaranteed_optimum':str(best),'true_model_optimum':str(truebest),
            'first_action':dp['policy'][3,0,2]})
    # Explicit scope counterexamples, exact algebra.
    base={(0,):F(1,2)}
    extended={**base,(0,0):F(1,2)}
    assert 1-r.lower_endpoint((0,0),base)>1-r.lower_endpoint((0,0),extended)
    assert r.lower_endpoint((0,),{(0,):F(0),(0,0):F(1)})==0
    assert r.lower_endpoint((0,0),{(0,):F(1,2),(0,0):F(1,2)})==F(3,4)
    precision=[]
    for length in (3,17,64):
        fixed=r.dyadic_lower_endpoint((0,)*length,extended,20)
        exact=r.lower_endpoint((0,)*length,extended)
        assert 0<=exact-fixed['lower']<=fixed['rounding_loss_bound']
        precision.append({'horizon':length,'lower':str(fixed['lower']),
            'loss':str(exact-fixed['lower']),'bound':str(fixed['rounding_loss_bound']),
            'accumulator_bits':fixed['max_accumulator_bits']})
    result={'scope':'Post-confirmation algebra checks on already exposed authored matrices',
        'status':'PASS','cases':results,'policy_and_scaled_value_checks':comparisons,
        'fixed_bit_checks':precision,
        'scope_failures_preserved':['No-event reward reverses the least-model order',
          'Joint total-mass information has no universal least coefficient vector'],
        'baseline':'Same-information retaining renewal plus Bellman DP ties exactly',
        'wall_seconds':time.perf_counter()-start}
    (here/'RETURN_CONTROL_CHECK.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
