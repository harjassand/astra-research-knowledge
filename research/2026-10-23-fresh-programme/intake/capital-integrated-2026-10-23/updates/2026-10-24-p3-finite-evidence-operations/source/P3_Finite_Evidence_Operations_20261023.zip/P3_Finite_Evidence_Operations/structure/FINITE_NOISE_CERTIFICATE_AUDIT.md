# Audit of the finite-noise cross-family composition certificate

Private P3 independent audit, 23 October 2026. This note audits the mathematical
construction sent by root; it does not assert that the structural input class
has been recognized from data. No new empirical fixture suite was run.

## Verdict

The proposed log-convex tangent plus graph-flow lower certificate is valid under
an explicitly common two-dimensional positive linear realization, simultaneous
valid observation intervals, and exact derivative/flow verification. Its signs
are correct for edge incidence `e_j-e_i`. It can warrant a particular sequence
response without identifying every operator entry or solving the exact robust
nonlinear optimization problem. The finite-dimensional positive realization
and repeatable preparation/measurement access remain assumptions requiring an
external warrant in a scientific application.

A normalized two-state Markov interpretation removes the intended relative
gauge: column normalization implies `c_i=1-a_i`, `b_i=1-d_i`. A nontrivial
probabilistic interpretation can instead use a common two-state substochastic
active subsystem, completed by an unobserved absorbing exit state. Then the
normalized physical chain has three states. A general positive linear response
model is another option, but an arbitrary nonnegative matrix product need not
be a probability. Individual stability is not a substitute for a common
substochastic or other bounded-response contract under switching.

## 1. Structural and observational contract

For modes i assume one common latent coordinate system with

```
P_i = [[a_i,b_i], [c_i,d_i]] >= 0,     b_i>0,
p_i = b_i*c_i,
q_w = e1^T P_(w_m) ... P_(w_1) e1.
```

The word `(w_1,...,w_m)` is chronological. Thus `q_(i,j)` means apply i then
j and has matrix product `P_j P_i`. Initial preparation of e1 and observation
of e1 must be physically or computationally available, with their errors
charged. A hidden-state experiment does not automatically permit preparation
of a pure hidden state. Approximate preparation, calibration error and
non-destructive versus destructive observation semantics require their own
valid error intervals.

There is no claim that finite data certify the dimension, the common hidden
basis, the positivity contract, stationarity across experiments, or absence of
other jointly activated states. These are not acquired by fitting the short
moments below. If any operator needs `b_i=0`, the logarithmic coordinates for
that mode fail; use a different parametrization or a separately justified
limiting/zero-edge analysis.

## 2. Safe finite-noise acquisition from endpoint statistics

Suppose simultaneous confidence intervals enclose the isolated endpoint
probabilities

```
A_i = q_(i)       = a_i,
S_i = q_(i,i)     = a_i^2 + p_i,
T_i = q_(i,i,i)   = a_i^3 + 2*a_i*p_i + p_i*d_i.
```

All lower bounds below may be intersected with known nonnegativity, and with
known probability upper bounds only when the physical contract supplies them.
Write valid intervals `[a_i^-,a_i^+]`, `[S_i^-,S_i^+]`, etc. Conservative safe
choices are

```
p_i^- = max(0, S_i^- - (a_i^+)^2),
p_i^+ = max(0, S_i^+ - (a_i^-)^2),
N_i^- = T_i^- - (a_i^+)^3 - 2*a_i^+*p_i^+,
d_i^- = max(0,N_i^-)/p_i^+,             if p_i^+>0.
```

If `p_i^+=0`, setting `d_i^-=0` is safe but does not identify d_i. If a finite
upper d bound is needed and `p_i^->0`,

```
d_i^+ = max(0, T_i^+ - (a_i^-)^3 - 2*a_i^-*p_i^-)/p_i^-.
```

These bounds intentionally discard statistical correlations. They remain
valid jointly on the original interval-coverage event; independence between
the derived intervals is not required. Joint feasible-set inference using
all retained moments is a stronger equally informed comparison.

For the cross experiment apply i and then j:

```
Q_ij = q_(i,j) = a_i*a_j + b_j*c_i
                 = a_i*a_j + p_i*(b_j/b_i).
```

Given its interval `[Q_ij^-,Q_ij^+]`, set

```
h_ij^- = max(0,Q_ij^- - a_i^+*a_j^+),
h_ij^+ = max(0,Q_ij^+ - a_i^-*a_j^-),
L_ij = h_ij^- / p_i^+,
U_ij = h_ij^+ / p_i^-,
```

where the last two formulas require `p_i^+>0`, `p_i^->0` respectively.
Strictly positive L_ij further requires a positive certified numerator. Do
not replace a zero numerator lower bound by an arbitrary positive tolerance
to enable a logarithm. Reverse chronological/matrix-product conventions swap
the numerator's p index and invert the b ratio.

In a substochastic two-state contract, every b_i and c_i is at most one.
Thus `p_i^->0` implies `b_i,c_i>=p_i^-`. Even before a mixed experiment,

```
p_j^- <= b_j/b_i <= 1/p_i^-.
```

These crude bounds can make a connected ratio graph available, but their
strength is supplied by the physical normalization inequality and the paid
isolated estimates. They are not newly acquired mixed information.

### Confidence and total acquisition cost

For K prescribed independent Bernoulli means, N independent repeats per mean
give simultaneous sampling error at most epsilon with probability 1-delta
when `N>=log(2K/delta)/(2*epsilon^2)`. Independence between different means is
not needed for this union bound, but within-experiment sampling conditions
must justify each tail bound. Add deterministic preparation and measurement
bias bounds to each interval.

Adaptive experiment selection and optional stopping require a valid
confidence allocation over the entire candidate family or an anytime-valid
confidence sequence. Repeatedly testing fixed-N intervals until they shrink
enough does not preserve their nominal coverage automatically. All isolated
measurements, cross measurements, resets, pulse durations, failed intervals,
and calibration work are charged. A ratio near zero or a nearly canceled
`S_i-a_i^2` may require many more samples than the final response would need
under direct sequence estimation.

## 3. Positive lower matrices and log convexity

Retain nonnegative rational lower bounds `a_i^-`, `d_i^-`, `p_i^-`. Let

```
z_i = log b_i,
M_i(z) = [[a_i^-, exp(z_i)],
          [p_i^-*exp(-z_i), d_i^-]],
q_w^-(z) = e1^T M_(w_m)(z) ... M_(w_1)(z) e1.
```

At the true z, `M_i(z)<=P_i` entrywise. All matrices and endpoint vectors are
nonnegative, so product monotonicity gives `q_w^-(z_true)<=q_w`.

Every path term in q_w^- is a nonnegative coefficient times an exponential
of an integer linear form in z. Therefore, unless q_w^- is identically zero,
`f(z)=log q_w^-(z)` is a finite log-sum-exp and is globally convex.
The common gauge shift `z -> z+s*1` conjugates every M_i by the same diagonal
matrix and leaves the e1-to-e1 response unchanged. Consequently `sum_i g_i=0`
for `g=grad f(z0)`.

For any positive rational t_i, take `z0_i=log t_i`. M_i(z0) is rational.
Thus q0 and g are rational, provided q0>0. The derivative matrix for mode i is

```
dM_i/dz_i = [[0,t_i],[-p_i^-/t_i,0]].
```

Use the product rule over every occurrence of i, with the exact chronological
convention. The gradient components can be negative; discarding those signs
invalidates the result. A rational forward/backward matrix computation gives
the exact gradient without enumerating exponentially many paths.

The tangent point does not need to satisfy the ratio constraints or be a
physically normalized system. Global convexity makes the tangent a lower
bound everywhere. If q0=0, the logarithm and gradient are undefined; return
the trivial response lower bound zero or change the valid lower model.

## 4. Flow signs and the resulting certificate

Each measured edge `(i,j)` supplies

```
log L_ij <= z_j-z_i <= log U_ij.
```

Define edge incidence as `v_ij=e_j-e_i`. Choose exact rational nonnegative
flows lambda_ij^+, lambda_ij^- satisfying

```
sum_edges (lambda_ij^+ - lambda_ij^-)*v_ij = g.
```

Then

```
g dot z >= sum_edges lambda_ij^+*log L_ij
           - sum_edges lambda_ij^-*log U_ij.
```

Combining this with the global convex tangent inequality proves

```
log q_w >= B,
B = log q0 - sum_i g_i*log t_i
    + sum_edges lambda_ij^+*log L_ij
    - sum_edges lambda_ij^-*log U_ij.
```

This holds on the simultaneous coverage event. The signs in root's proposed
formula are correct with this incidence convention. Taking any feasible
flow is sufficient; optimizing the flow is an optional tightening cost.

### Failure conditions that the verifier must reject or handle

* Positive log arguments and q0>0 must be verified exactly.
* Every lambda must be nonnegative and the incidence equation must be exact.
  A floating-point LP result with an unchecked residual is not a certificate.
  In particular, a residual in a gauge direction has unbounded error. A
  candidate optimizer can select a support/tree, followed by exact rational
  flow reconstruction and verification.
* If the measured graph is disconnected, global `sum g=0` is insufficient.
  Each connected component must have zero gradient sum to admit a flow.
  Absent that condition, additional edges/information or a different tangent
  are needed. Bounds that are invariant within each component may still be
  possible, so failure of this particular flow is not a general impossibility.
* Ratio intervals should be checked for feasibility, including cycle
  consistency. On a valid coverage event the true z makes them feasible.
  Inconsistent intervals indicate sampling failure, model error, or a bug;
  they should yield a diagnostic instead of a vacuous arbitrary certificate.
* The lower-model matrices need not be normalized for every feasible z.
  Enlarging the domain with unphysical z is conservative for the lower bound,
  but can make it weak. Adding separately justified common normalization
  constraints can strengthen it and must also be available to the baseline.

## 5. Certified logarithms and precision costs

For positive rational x, let `y=(x-1)/(x+1)`. With N terms,

```
S_N = 2*sum_(k=0)^(N-1) y^(2k+1)/(2k+1),
|log x-S_N| <= 2*|y|^(2N+1)/((2N+1)*(1-y^2)).
```

The right side is a rational bound. All signed coefficient products in B
must be interval-multiplied with the correct endpoint directions. In
particular `-g_i*log t_i` does not always use the same log endpoint.

Use range reduction `x=2^k*u`, `1<=u<2`, and bound `k*log 2+log u` with
signed interval arithmetic. Without range reduction, exponentially small
q0 gives y very near -1 and this valid series can take exponentially many
terms in the input bit length. Exact integer comparisons/shifts find k.
Charge rational bit lengths, range reduction, series terms, matrix product
growth, gradient construction, and any search for t/flows.

To certify a rational target probability tau>0, it suffices to compare a
rational lower bound on B to a rational upper bound on `log tau`. This avoids
claiming that a floating-point `exp(B)` is a certified probability bound.
If a numeric probability interval is reported, its exponential evaluation
also needs directed/validated error control.

## 6. Comparison and what this audit does not establish

This is a task-specific robust response certificate under an acquired
interval set and an externally warranted model class. It does not identify
every P_i, and that is not necessary for its single lower-bound operation.
It does not recognize the common class, establish a general law of acquired
intelligence, or demonstrate a practical advantage over established switched
system realization, positive-system verification, robust optimization, or
retained sufficient-statistic methods.

The strongest equally informed comparator should retain all isolated and
mixed observations, exploit the same two-dimensional positive realization,
and use either validated joint feasible-set optimization or direct sampling
of the requested sequence when available. Analytic structure is shared input,
not acquired benefit. A useful demonstration would show that a small paid
cross-interface experiment certifies many consequential new protocol tasks
more cheaply than the complete best competing acquisition-and-verification
process. This note establishes correctness conditions, not that efficiency
claim.

## 7. Generalized log-domain formulation retaining p/h correlations

Root's extension sets `x=(z,t)` with `t_i=log p_i` and retains both isolated
p intervals and mixed-contrast intervals:

```
log p_i^- <= t_i <= log p_i^+,
log h_ij^- <= t_i+z_j-z_i <= log h_ij^+,
M_i(x) = [[a_i^-, exp(z_i)], [exp(t_i-z_i), d_i^-]].
```

This retains the exact relation between a given p and its mixed contrasts
instead of replacing it by independent ratio boxes. It is stronger information
use, though it still need not retain the full correlation through uncertain
a_i or the complete original observation likelihood.

As above, q_w^-(x) is a sum of nonnegative exponential monomials and is below
the true response at the true x. At rational positive values `s_i=exp t0_i`,
`v_i=exp z0_i`, the response and gradient are rational. Besides the z derivative,

```
dM_i/dt_i = [[0,0],[s_i/v_i,0]].
```

The t gradient is nonnegative, while the z gradient sums to zero. Each path
has equally many upper- and lower-off-diagonal transitions because it starts
and ends at state 1. Thus `sum_i g_(t_i)<=floor(|w|/2)` and
`||g_z||_1<=|w|`; these follow by taking expectations over the normalized
positive path weights. They provide sanity checks, not replacements for exact
derivative computation.

Collect the logarithmic inequalities as `A*x<=b`. A has exact integer entries;
b consists of signed logs of positive rational observation bounds. For any
exact rational lambda satisfying

```
lambda>=0,             A^T lambda = -g,
```

the convex tangent and weak LP duality give the certified lower bound

```
log q_w >= f(x0) - g dot x0 - lambda dot b.
```

The minus sign in `A^T lambda=-g` is correct: multiplying `Ax<=b` by lambda
gives `-g dot x<=lambda dot b`, hence `g dot x>=-lambda dot b`.
No optimizer optimality or floating-point accuracy is needed after exact
feasibility and directed log evaluation have passed. Numerical search may
propose x0 and a dual support, but its cost and unsuccessful candidates remain
part of acquisition/verification costs. A rationalized x0 need not be feasible.

### Zeros and boundary limits

A zero *lower confidence bound* is not an observed physical zero. It may mean
that the data have not resolved a small positive parameter. It cannot be
replaced by a positive constant for convenience. The corresponding logarithmic
lower constraint may be omitted, or the domain handled using an appropriate
closed nonnegative parametrization.

If the actual b_i or c_i is zero, no finite logarithmic x represents it. A
proof must explicitly assume strict positivity, handle a zero mode separately,
or justify a limiting closure argument for all constraints and the target
response. In particular, `p_i=0` does not imply both b_i and c_i are zero; a
cross contrast can remain positive with b_i=0 and c_i>0. Dividing by b_i in
that case is invalid.

The tangent-dual method can fail to give a finite lower bound even when a
simple positive lower bound exists. With unconstrained `t_i -> -infinity`, a
finite tangent having positive t slope goes to minus infinity, although the
original log-sum-exp approaches a positive all-diagonal contribution. Always
retain the exact rational baseline

```
q_w >= product_(k=1)^m a_(w_k)^-.
```

One can also retain other individually warranted path contributions. Failure
to find a feasible finite dual must not be reported as an impossibility of
the requested sequence guarantee.

### Precision and acquisition ill-conditioning

All exact 2x2 product and derivative calculations can be performed by
forward/backward recurrences rather than enumerating paths. With rational
operator/tangent inputs of bounded bit length, word length increases the
rational numerator/denominator bit lengths; counting only real-arithmetic
matrix multiplications omits that cost. Range-reduced log evaluation remains
necessary for very small q0.

The acquisition problem can be much worse conditioned than the subsequent
certificate checker. The signal `p_i=S_i-a_i^2` is a difference of estimated
probabilities; the signal `p_i*d_i=T_i-a_i^3-2*a_i*p_i` is another cancellation.
To resolve d_i to absolute error eta can require raw probability errors on
the order of `p_i*eta`, producing worst-case Bernoulli sample requirements on
the order of `(p_i*eta)^(-2)` with standard absolute-error concentration. A
variance-aware method can improve some regimes and is an appropriate baseline.

When p and h are small, their log-interval widths behave locally as relative
errors, of order `epsilon/p + epsilon/h` for derived ratios. The certificate
multiplies such widths by dual weights. Well-conditioned algebraic realization,
finite certificate bit length, and a useful high-confidence acquisition budget
are distinct requirements. Exact checking removes trust in an optimizer; it
does not remove the cost of acquiring a sufficiently narrow feasible set.
