"""A finite certificate for every finite word in an acquired action alphabet.

The common Hilbert/physical access contract is inherited from
correlation_certificate.py.  Stability is checked only for proposed coefficient
matrices, NOT asserted for the full unknown source.  The certificate can be
conservative or vacuous.  It recognizes neither full source rank nor mixing.
"""
from fractions import Fraction as F
from correlation_certificate import Representation, Correlations, add, scale, sqrt_upper, mv


def norm2_upper(matrix, bits=80):
    """Rigorous ||M||_2 <= sqrt(||M||_1 ||M||_infinity)."""
    ninf = max((sum((abs(x) for x in row), F(0)) for row in matrix), default=F(0))
    none = max((sum((abs(x) for x in col), F(0)) for col in zip(*matrix)), default=F(0))
    return sqrt_upper(ninf*none, bits)


def center_and_radius(forms, data):
    center, radius = [], []
    for row in forms:
        crow, rrow = [], []
        for form in row:
            lo, hi = data.evaluate(form)
            crow.append((lo+hi)/2)
            rrow.append((hi-lo)/2)
        center.append(crow)
        radius.append(rrow)
    return center, radius


def uniform_certificate(rep, data, bits=80):
    """Compile a 2d-dimensional weighted program and a uniform absolute error.

    Valid on the given simultaneous interval event.  Positive returned errors
    are not probabilities; an error >=2 is normally uninformative for [-1,1]
    correlations.  No sampling or matrix fitting is hidden in this routine.
    """
    if not isinstance(rep, Representation) or not isinstance(data, Correlations):
        raise TypeError('Representation and simultaneous Correlations required')
    d = len(rep.basis)
    units = [tuple(F(int(i == j)) for i in range(d)) for j in range(d)]
    r = max(norm2_upper(t, bits) for t in rep.transitions.values())
    if r >= 1:
        return {'status': 'UNKNOWN', 'reason': 'No strict common coefficient contraction certified',
                'coefficient_contraction_upper': r}
    gforms = [[rep.inner_form(x, y) for y in units] for x in units]
    gc, gr = center_and_radius(gforms, data)
    eta_g = norm2_upper(gr, bits)
    eta_d, kappa = F(0), F(0)
    programs, diagnostics = {}, {}
    for a, t in rep.transitions.items():
        dforms = [[rep.defect_form(a, x, y) for y in units] for x in units]
        dc, dr = center_and_radius(dforms, data)
        ra = [rep.residual_form(a, x) for x in units]
        rforms = []
        for i, x in enumerate(units):
            row = []
            for j, y in enumerate(units):
                z = tuple(xx+yy for xx, yy in zip(x, y))
                row.append(scale(F(1, 2), add(rep.residual_form(a, z),
                                                 scale(-1, ra[i]), scale(-1, ra[j]))))
            rforms.append(row)
        rc, rr = center_and_radius(rforms, data)
        # Gershgorin + symmetric interval perturbation, valid for all vectors.
        ka = max(rc[i][i]+sum((abs(rc[i][j]) for j in range(d) if j != i), F(0))
                 +sum(rr[i], F(0)) for i in range(d))
        if ka < 0 or any(rc[i][i]+rr[i][i] < 0 for i in range(d)):
            raise ValueError('Confidence set excludes a nonnegative residual Gram')
        da = norm2_upper(dr, bits)
        eta_d, kappa = max(eta_d, da), max(kappa, ka)
        # M_a=[[T_a^T,D_a(center)],[0,T_a]].
        block = [[F(0) for _ in range(2*d)] for _ in range(2*d)]
        for i in range(d):
            for j in range(d):
                block[i][j] = t[j][i]
                block[i][d+j] = dc[i][j]
                block[d+i][d+j] = t[i][j]
        programs[a] = block
        diagnostics[a] = {'residual_operator_square_upper': ka,
                          'defect_estimation_norm_upper': da,
                          'residual_center': rc, 'residual_radius': rr}
    error = eta_g+eta_d/(1-r)+kappa/(1-r)**2
    return {'status': 'CERTIFIED_UNDER_CONTRACT', 'uniform_error': error,
            'coefficient_contraction_upper': r, 'gram_estimation_norm_upper': eta_g,
            'defect_estimation_norm_upper': eta_d,
            'residual_operator_square_upper': kappa,
            'program': programs, 'left': list(rep.e0)+gc[0],
            'right': [F(0)]*d+list(rep.e0), 'diagnostics': diagnostics}


def run_program(compiled, target):
    if compiled['status'] != 'CERTIFIED_UNDER_CONTRACT':
        raise ValueError('No compiled uniformly certified program')
    z = compiled['right']
    for a in reversed(tuple(target)):
        z = mv(compiled['program'][a], z)
    return sum((x*y for x, y in zip(compiled['left'], z)), F(0))
