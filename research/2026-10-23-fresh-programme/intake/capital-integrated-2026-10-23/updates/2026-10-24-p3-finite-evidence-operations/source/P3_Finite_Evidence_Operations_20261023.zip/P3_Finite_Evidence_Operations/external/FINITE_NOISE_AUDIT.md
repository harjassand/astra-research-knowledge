# Audit of the finite-noise partial-alignment certificate

Private mathematical review, 2026-10-23. This supplements, and does not replace,
`JOINT_GAUGE_COMPOSITION.md`. Root proposed the finite-noise certificate;
this worker independently challenged acquisition, uncertainty propagation,
numerical certification, and the same-information baseline. No synthetic
transfer benchmark was run.

## 1. Valid part of the construction

For nonnegative pulse maps

\[
P_i=\begin{pmatrix}a_i&b_i\\c_i&d_i\end{pmatrix},\qquad
p_i=b_ic_i>0,
\]

write `z_i=log b_i`. At the true hidden parameters, entrywise lower matrices

\[
P_i^-(z)=\begin{pmatrix}a_i^-&e^{z_i}\\p_i^-e^{-z_i}&d_i^-\end{pmatrix}
\]

are below the true matrices. Products preserve entrywise order. Thus an infimum
of their return response over any set containing the true `z` is a valid lower
bound. Positive path expansions make the logarithm of that return response
convex: each path contributes a nonnegative constant times the exponential of
an affine function of `z`.

There are two support cases. If no path has a positive coefficient, the lower
response is identically zero and should be returned directly. Otherwise the
logarithm is finite and convex for every finite feasible vector. A declaration
that `log(0)` is an ordinary finite objective is invalid.

This proves validity of the proposed relaxation, not its usefulness. Its main
weakness is that separate interval substitutions discard correlations in the
information that was actually acquired.

## 2. What the raw measurements identify and cost

With a reproducible `e1` preparation and `e1` readout, let
`m_k=e1^T P_i^k e1`. Then

\[
a_i=m_1,\qquad p_i=m_2-m_1^2,\qquad
d_i=\frac{m_3-m_1^3-2m_1p_i}{p_i}.                         \tag{1}
\]

The one-, two-, and three-pulse experiments, their repetitions, and the raw
measurements used to construct these intervals are acquisition costs.
For small `p_i`, the subtraction defining `p_i` and division defining `d_i`
are ill-conditioned. If raw errors have a fixed scale, retaining many digits
in the final algebra does not recover information that was never measured.

For a pair, with i applied before j,

\[
q_{ij}=a_ja_i+b_jc_i,\qquad r_{ij}=q_{ij}-a_ja_i.
\]

Simultaneous confidence intervals imply conservative contrast bounds

\[
r_{ij}^- =\max\{0,q_{ij}^- -a_j^+a_i^+\},\qquad
r_{ij}^+ =q_{ij}^+ -a_j^-a_i^- .                           \tag{2}
\]

All entries here are nonnegative. A negative upper contrast or an empty joint
confidence set means that no certificate is supplied; it must not be converted
into a vacuous favorable bound. Negative raw lower bounds are clipped at zero.
Because `r_ij=p_i exp(z_j-z_i)`, ratio intervals are

\[
\log(r_{ij}^-/p_i^+)\leq z_j-z_i
 \leq \log(r_{ij}^+/p_i^-),                               \tag{3}
\]

when the required endpoints are positive. A zero lower contrast supplies no
finite lower bound; a zero lower `p_i` supplies no finite upper bound. Replacing
either with an arbitrary small number would add an unsupported input promise.

Adaptive acquisition requires confidence statements valid under the actual
selection/stopping protocol, or a prespecified allocation. Reusing a
simultaneous interval in many target computations does not require a new
measurement, but learning the interval once still costs work.

## 3. A cheap retaining baseline for every hidden dimension

For any nonnegative matrices with the stated pure port, and any two words u,v,

\[
q_{uv}=e_1^\top P_vP_u e_1
       =\sum_k(P_v)_{1k}(P_u)_{k1}\geq q_u q_v.             \tag{4}
\]

Suppose a retained library contains simultaneous lower bounds `ell(v)` for
measured words. For a target word `w` of length n, compute

\[
D(0)=1,\quad
D(t)=\max_{0\leq s<t:\,w_{s+1:t}\ \mathrm{retained}}
       D(s)\ell(w_{s+1:t}),                               \tag{5}
\]

with maximum zero when there is no usable segment. Induction using (4) shows
`D(n) <= q_w`. In log coordinates this is an ordinary best-segmentation dynamic
program. It requires no dimension estimate, local parameter identification,
relative gauge, or geometric-programming solve. A limited block length allows
O(n L) lookups/arithmetic operations after the library and substring index have
been acquired; data collection and index construction are not free.

This is a same-information retaining-program baseline, not a new architecture
claimed here. A method should at least return the maximum of its own bound and
this cheap bound. A target already measured should use its retained interval
directly. A small set of new target protocols should also be compared against
direct measurement of those protocols.

## 4. Exact example where fixed lower products waste acquired information

For `0<h<sqrt(1/5)`, consider strictly positive, substochastic matrices

\[
P_i=\begin{pmatrix}1/2&(5/2)h^2\\2/5&1/2\end{pmatrix},
\qquad
P_j=\begin{pmatrix}1/2&2/5\\(5/2)h^2&1/2\end{pmatrix}.
\]

Both have `p_i=p_j=h^2`, which becomes hard to estimate relative to raw
measurement noise. Yet

\[
q_{ij}=\frac{41}{100}
\]

is independent of h. If valid intervals contain `p_i^-=p_j^-=0`, both lower
matrices in section 1 are upper triangular. Their response for `ijij` is
exactly

\[
q_{ijij}^-=\frac1{16}=0.0625
\]

for every feasible `z`, even when `q_ij` has been measured accurately. The
retaining baseline instead gives

\[
q_{ijij}\geq q_{ij}^2=\frac{1681}{10000}=0.1681.
\]

The actual response is

\[
q_{ijij}=\frac{2081}{10000}+\frac12h^2+\frac{25}{16}h^4.
\]

These are symbolic identities, not a benchmark or unseen cases. For a noisy
pair observation the same comparison uses its positive lower confidence bound
in place of `41/100`.

For a single absolute-response threshold below `0.41`, direct pair measurement
has precision cost unrelated to `h^-4`. A strategy that insists on identifying
`p=h^2` to constant relative accuracy from fixed-scale noisy moments can incur
that inverse-fourth-power scaling. This is not a universal lower bound on the
best partial method: it can and should avoid identifying irrelevant small
parameters. If the task instead asks for an effect of order `h^2`, direct
measurement also has the corresponding precision burden.

## 5. Convex repair: retain products as uncertain correlated variables

Introduce `t_i=log p_i` and use

\[
P_i^-(z,t)=\begin{pmatrix}a_i^-&e^{z_i}\\e^{t_i-z_i}&d_i^-\end{pmatrix}.
\]

Retain log interval constraints for `t_i` and direct contrast constraints

\[
\log r_{ij}^-\leq t_i+z_j-z_i\leq\log r_{ij}^+.             \tag{6}
\]

Zero lower endpoints mean that the associated finite lower constraint is absent.
The confidence set is still a polyhedron in `(z,t)`, and the logarithm of each
target return remains a log-sum-exp of affine path weights. At the true
parameters, the lower matrices are entrywise valid. This preserves the acquired
correlation `p_i exp(z_j-z_i)=r_ij` and avoids the failure in section 4.

The method is an outer relaxation of all raw measurement constraints. For
example, treating raw lower bounds on full posynomials as convex constraints
would generally be wrong. The contrast intervals in (2) are a conservative
way to retain tractable monomial information. More information can be preserved
only when its feasible set remains justified; it cannot be silently assumed.

## 6. Numerically obtaining a lower certificate

A primal minimizer gives an upper bound on an infimum, which is the wrong
direction for this purpose. Let `f=log q^-`, let the feasible region be
`A x <= b`, and let `x0` be any point with evaluated gradient `g`. Convexity
gives

\[
f(x)\geq f(x_0)+g^\top(x-x_0).
\]

If `lambda>=0` and `A^T lambda=-g`, then every feasible x satisfies
`g^T x>=-lambda^T b`. Therefore

\[
\inf f\geq f(x_0)-g^\top x_0-\lambda^\top b.               \tag{7}
\]

This is a concrete certification wrapper: a floating-point optimizer proposes
`x0`; a verified linear dual/tangent calculation supplies a lower bound. If
stationarity has residual `r=g+A^T lambda` and all feasible x satisfy
`||x||<=R`, subtract `R||r||_*`. No such residual correction is justified on an
unbounded domain without additional information. Function, gradient, and
constraint arithmetic require outward bounds or another certified error
control. The exponential of a certified lower bound on `f` then certifies the
response. Raw solver status or a printed tolerance is insufficient.

## 7. Gauge and physical normalization

Diagonal hidden-state rescaling preserves the measured return response but
does not preserve ordinary column-substochasticity. Fixing, for example,
`z_1=0` sets `b_1=1`; it can make `b_1+d_1<=1` false even for an originally
valid physical realization. One may drop mass constraints as a conservative
outer relaxation, leave the physical gauge unfixed, or use a common positive
mass-weight vector. One must not impose unweighted mass constraints after an
arbitrary gauge normalization.

## 8. Exact scope of the conclusion

A lower bound can certify sufficient return, recovery, capture, or detection
yield only when that is the scientific target. It does not establish that one
ordering is better than another, or that unwanted survival is sufficiently
small; those tasks require an upper bound or a signed difference certificate.

Posynomial convexity is established geometric-programming machinery. Direct
prior includes Ogura, Kishida, and Lam, *Geometric Programming for Optimal
Positive Linear Systems*, TAC 2020, DOI `10.1109/TAC.2019.2960697`, primary
preprint `https://arxiv.org/pdf/1904.12976` (v2, inspected). It treats parameterized
positive systems and robustness. Zhu, Lam, and Ogura, Automatica 2022, DOI
`10.1016/j.automatica.2022.110553`, specifically addresses finite-time positive
systems and log-log convexity (author abstract inspected). The new question is
whether experimentally acquired partial constraints yield a useful new task
guarantee, not whether positive path sums can be convexified.

The endpoint block bound also requires a pure or genuinely regenerative port.
The following separate note, `RESET_ACCESS_CONTRACT.md`, records why ordinary
single-molecule state labels do not automatically satisfy that condition.
