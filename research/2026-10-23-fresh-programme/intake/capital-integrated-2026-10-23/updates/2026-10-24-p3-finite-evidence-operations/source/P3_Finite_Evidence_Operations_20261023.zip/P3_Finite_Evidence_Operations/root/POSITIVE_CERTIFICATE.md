# Finite-bit lower certification from correlated intervention measurements

Private exploratory P3 derivation, 23 October 2026. The completed circuit and
acquired-operation bundles remain unchanged. Historical novelty is UNKNOWN;
geometric programming, positive-system convexity and switched-model alignment
are established methods. This construction is a conditional certificate, not
proof that a physical system belongs to its model class.

## Contract and acquisition

Assume each pulse is a strictly positive two-transient-state substochastic map
`P_i=[[a_i,b_i],[c_i,d_i]]`, preparation is the same pure state e1, and endpoint
readout has probability `q(w)=e1^T P_last ... P_first e1`. The normalized physical
completion has at least one unobserved loss state. A normalized TWO-state chain
alone has no such scaling ambiguity. Preparation, readout, stationarity and
this common state-space promise are inputs requiring independent justification.

For each isolated mode, paid endpoint trials estimate

```
m1_i = a_i,
m2_i = a_i^2 + p_i,
m3_i = a_i^3 + 2*a_i*p_i + p_i*d_i,     p_i=b_i*c_i.
```

A paid mixed trial (i first, j second) estimates
`q_ij=a_i*a_j+h_ji`, where `h_ji=b_j*c_i`.
All endpoint probabilities must have simultaneous rational confidence intervals.
For example, preassigned independent Bernoulli trial counts and Hoeffding
intervals with outward rational rounding suffice; adaptive acquisition needs a
valid confidence sequence or an explicit failure-budget allocation. A finite
PRNG simulation does not instantiate the physical acquisition contract.

Safe intervals include

```
a^- = m1^- , a^+ = m1^+,
p^- = max(0,m2^- - (a^+)^2),
p^+ = max(0,m2^+ - (a^-)^2),
h_ji^- = max(0,q_ij^- - a_i^+*a_j^+),
h_ji^+ = max(0,q_ij^+ - a_i^-*a_j^-).
```

If `p^+>0`, use
`d^-=max(0,m3^--(a^+)^3-2*a^+*p^+)/p^+`, clipped only using independently
valid physical bounds. Otherwise one can always use `d^-=0`; do not divide by
zero. A useful positive lower d bound can be expensive near small p. Measured
interval inconsistency is a refusal condition, not a vacuous scientific proof.

## Keep measured products correlated

Use variables `x=(log b_i,log c_i)`. Isolated p bounds and mixed h bounds become
linear bounds on sums of two x coordinates. This is equivalent to retaining
`z_i=log b_i,t_i=log p_i`, but avoids ratio-box divisions. The discarded first
attempt separately bounded p and b ratios; it could lose a strong measured
mixed contrast when an isolated p lower bound was zero.

Replace only the diagonal entries by their rational lower bounds:

```
M_i(x) = [[a_i^-, exp(x_bi)], [exp(x_ci), d_i^-]].
```

At the true parameter, M_i<=P_i entrywise, so every lower-model endpoint is at
most its physical endpoint. Every endpoint is a sum of positive path monomials;
therefore `f_w(x)=log(e1^T M_last(x)...M_first(x)e1)` is convex if it has any
positive path. An entirely zero lower endpoint instead gives only bound zero.
The state-1 path always supplies the independent bound `product a_i^-`.

Let measured product constraints have form `A x <= beta`, with integer A and
each beta a signed logarithm of a positive rational bound. Minimize f over this
outer confidence set for a robust LOWER response. Maximizing f is a different,
generally nonconvex problem. Lower response alone does not prove treatment-order
advantage or reduced viability; the scientific question must need this direction.

## Exact independently checked tangent-dual witness

Choose any positive rational b/c vector t; it need not be feasible. Matrix
products and log-derivatives at t are rational. Write `q0=q(t)>0` and
`g=grad f(log t)`. Convexity implies

`f(x) >= log q0 + g dot (x-log t)`.

Any rational lambda>=0 satisfying the EXACT identity `A^T lambda=-g` gives

```
f(x) >= log q0 - sum_j g_j log t_j - lambda dot beta.
```

Thus numerical optimization can propose a point and a dual support, but cannot
manufacture validity. The supplied implementation reconstructs the dual with
rational elimination and rejects negative coefficients or any nonzero residual.
Unbounded gauge directions make an unchecked tiny residual unacceptable.
Failure to find a dual does not refute the diagonal or retained-block bounds.

To certify a rational threshold tau, subtract log(tau) and evaluate every log
outward. After scaling a rational x by a power of two to y in [1,2], set
u=(y-1)/(y+1). Then

```
log y = 2*sum_{k=0}^{N-1} u^(2k+1)/(2k+1) + R,
0 <= R <= 2*u^(2N+1)/((2N+1)*(1-u^2)).
```

The same series bounds log 2. Signs are propagated with exact fractions. A
positive lower margin is a certificate independent of numerical solver error.

## Strong alternatives and charged limitations

Retain all measured word bounds. Positivity at a genuine atomic port gives
`q(uv)>=q(u)q(v)`. Dynamic programming over retained blocks supplies a cheap
same-information lower bound; it can beat an ill-conditioned local fit. A
stronger renewal method sums disjoint return patterns and is being investigated
without a finite-state dimension promise. Ordinary retaining code can implement
all these algorithms; no architectural separation is claimed.

The code verifies arithmetic only. Trials, preparation duration, calibration,
simultaneous confidence, computation, LP search, failed supports and finite
precision all count. There is no universal acquisition advantage over measuring
the desired sequence directly. The common two-state contract is not learned by
isolated Hankel-rank fits or a finite number of successful mixed predictions.

Primary prior read by root: Ogura, Kishida and Lam, *Geometric Programming for
Optimal Positive Linear Systems*, arXiv:1904.12976v2; Bencherki, Turkay and Akcay,
*Basis transform in linear switched system models from input-output data*,
arXiv:2106.10888v3. The use of an acquired confidence set and a rational
certificate is not, by itself, an established novelty over this literature.
