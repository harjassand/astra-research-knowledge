"""Exact algebra checks for a two-compartment non-composition counterexample.

This is a proof check, not an empirical benchmark or independent confirmation.
Run with Python 3; only the standard library is used.  Results are printed as
JSON so the caller decides where to preserve them.
"""

from fractions import Fraction as F
from math import cosh, exp, sinh, sqrt
import json


def mat(rows):
    return tuple(tuple(F(v) for v in row) for row in rows)


def mul(a, b):
    return tuple(tuple(sum(a[i][k] * b[k][j] for k in range(len(b)))
                       for j in range(len(b[0]))) for i in range(len(a)))


def add(a, b):
    return tuple(tuple(x + y for x, y in zip(ar, br)) for ar, br in zip(a, b))


def scale(k, a):
    return tuple(tuple(k * x for x in row) for row in a)


def sub(a, b):
    return add(a, scale(-1, b))


def det(a):
    return a[0][0] * a[1][1] - a[0][1] * a[1][0]


def inv(a):
    return scale(1 / det(a), mat([[a[1][1], -a[0][1]], [-a[1][0], a[0][0]]]))


def similarity(s, a):
    return mul(mul(s, a), inv(s))


def elt(a):
    return a[0][0]


def check_two_state_generator(a):
    assert a[0][1] >= 0 and a[1][0] >= 0
    trace = a[0][0] + a[1][1]
    assert trace < 0 and det(a) > 0  # exact Hurwitz criterion in dimension 2
    sums = [sum(row[j] for row in a) for j in range(2)]
    assert all(v <= 0 for v in sums)
    return {"trace": str(trace), "determinant": str(det(a)),
            "column_sums": list(map(str, sums))}


def main():
    ident = mat([[1, 0], [0, 1]])
    b = mat([[1], [0]])
    c = mat([[1, 0]])
    a0 = scale(-1, ident)
    a = mat([[-2, 1], [1, -3]])
    bmode = mat([[-4, 1], [1, -5]])
    ap = mat([[-2, 2], [F(1, 2), -3]])
    bp = mat([[-4, F(1, 2)], [2, -5]])
    sa = mat([[1, 0], [0, F(1, 2)]])
    sb = mat([[1, 0], [0, 2]])

    assert similarity(sa, a) == ap
    assert similarity(sb, bmode) == bp
    for s in (sa, sb):
        assert similarity(s, a0) == a0
        assert mul(s, b) == b
        assert mul(c, inv(s)) == c

    generators = {name: check_two_state_generator(x)
                  for name, x in (("A", a), ("B", bmode),
                                  ("A_prime", ap), ("B_prime", bp))}
    assert sub(bmode, a) == scale(-2, ident)
    assert sub(bp, ap) != scale(-2, ident)  # rules out any common similarity
    assert mul(a, bmode) == mul(bmode, a)

    m = add(a, scale(F(5, 2), ident))
    ma = add(ap, scale(F(5, 2), ident))
    mb = add(bp, scale(F(9, 2), ident))
    lam_sq = F(5, 4)
    for centered in (m, ma, mb):
        assert mul(centered, centered) == scale(lam_sq, ident)
    cross_ab = elt(mul(mb, ma))
    cross_ba = elt(mul(ma, mb))
    assert cross_ab == F(1, 2)
    assert cross_ba == F(17, 4)
    assert (cross_ba - cross_ab) / lam_sq == 3
    assert (cross_ab - elt(mul(m, m))) / lam_sq == -F(3, 5)
    assert (cross_ba - elt(mul(m, m))) / lam_sq == F(12, 5)
    commutator_entry = elt(sub(mul(ap, bp), mul(bp, ap)))
    assert commutator_entry == F(15, 4)

    # Transfer-function coefficients: (s + d)/(s^2 + (a+d)s + ad-bc).
    # The high-frequency coefficient and known port remove scalar scaling.
    for left, right in ((a, ap), (bmode, bp)):
        assert left[1][1] == right[1][1]
        assert left[0][0] + left[1][1] == right[0][0] + right[1][1]
        assert det(left) == det(right)
        # Each local two-state realization is individually minimal.
        for x in (left, right):
            reachable = mat([[1, x[0][0]], [0, x[1][0]]])
            observable = mat([[1, 0], [x[0][0], x[0][1]]])
            assert det(reachable) != 0 and det(observable) != 0

    # Closed-form formulas evaluated at one illustrative dwell time.
    # These floating-point values are display aids; the exact claims above
    # and the analytic derivation in JOINT_GAUGE_COMPOSITION.md carry the proof.
    tau = 0.2
    base = exp(-7 * tau) * (cosh(sqrt(5) * tau)
                             + sinh(sqrt(5) * tau) / sqrt(5))
    factor = exp(-7 * tau) * sinh(sqrt(5) * tau / 2) ** 2
    q_ab_prime = base - 3 * factor / 5
    q_ba_prime = base + 12 * factor / 5

    # The preparatory additive-action example is also exact.
    dc_a = F(3, 6 - 2)
    dc_ap = F(3, 1) / (F(6) - F(3, 2))
    assert dc_a == F(3, 4) and dc_ap == F(2, 3)

    print(json.dumps({
        "status": "PASS",
        "kind": "exact rational identity checks; one display-only float evaluation",
        "not_claimed": ["independent empirical confirmation", "new biological measurement",
                        "novel basis-alignment algorithm", "efficiency advantage"],
        "generators": generators,
        "separate_mode_gauges_preserve_ports_and_baseline": True,
        "each_local_realization_minimal": True,
        "common_gauge_impossible": True,
        "centered_square": str(lam_sq),
        "cross_coefficients_AB_BA": [str(cross_ab), str(cross_ba)],
        "order_contrast_formula": "3*exp(-7*tau)*sinh(sqrt(5)*tau/2)^2",
        "small_time_order_contrast_coefficient": str(commutator_entry),
        "illustration": {"tau": tau, "world_1_either_order": base,
                         "world_2_A_then_B": q_ab_prime,
                         "world_2_B_then_A": q_ba_prime,
                         "world_2_order_contrast": 3 * factor},
        "additive_intervention_DC_outputs": [str(dc_a), str(dc_ap)],
    }, indent=2))


if __name__ == "__main__":
    main()
