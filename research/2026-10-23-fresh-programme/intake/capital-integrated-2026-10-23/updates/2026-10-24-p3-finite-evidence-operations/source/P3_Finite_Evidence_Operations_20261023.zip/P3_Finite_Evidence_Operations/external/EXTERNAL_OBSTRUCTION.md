# External scientific obstruction and competitive boundary

Private P3 research note, 2026-10-23. No new authored benchmark wave or biological
experiment was conducted. The exact mathematical result is in
`JOINT_GAUGE_COMPOSITION.md`; the primary-source record is `SOURCES.json`.

## Consequential task

Predict whether changing the order or timing of interventions changes a
biological response, using a retained representation learned under other
intervention protocols. The task only needs a justified prediction for those
protocols; it does not intrinsically require complete biochemical identification.
The intervention interface and the model's domain of validity must be obtained
from evidence rather than asserted by an evaluator.

Two primary papers give a concrete boundary:

* **Klinger et al., 2013 (S1).** Their signaling model combines perturbation data
  into identifiable parameter combinations, retains learned information while
  adding new inhibitors, and predicts combinations. The paper expressly excludes
  sequential applications. An inhibitor-specific unexpected response also
  illustrates that nominal target specificity can fail. This is an existing
  acquired, retained, extended scientific representation, not a novelty to claim
  for P3. Its many optimization restarts and validation experiments are real
  costs.
* **Lee et al., 2012 (S2).** EGFR-inhibitor pretreatment changes later
  chemotherapy response in selected cell lines; simultaneous and reverse-order
  protocols differ. Time-resolved measurements support a partial-least-squares
  predictor, reduced to four signals, followed by experimental tests of a
  nominated mechanism. This is a strong incumbent for task-directed prediction
  and experimental extension. It does not license transferring the result to
  arbitrary cells, compounds, or a clinical setting.

The gap between these tasks motivates examining mixed-protocol information. It
does not show that either published method is deficient for its stated goal.

## Exact result that changes the direction

The two-state construction proves that even complete isolated-intervention
input-output knowledge can fail to determine a sequential response. All
existing one-intervention data can be correct and all individual models minimal,
while their hidden state coordinates cannot be jointly aligned. The obstruction
persists in positive, stable compartment systems. Its missing information is a
mixed-action cross quantity, not additional compute on the retained isolated
responses.

For the restricted two-state class, a finite mixed protocol acquires
`rho_ij=b_j c_i`. Connected measured mode pairs align the representation up to a
harmless common scaling, allowing predictions of unmeasured sequences. No full
physical identification is needed. This gives a working acquisition/reuse/
extension mechanism, but its generic form has strong direct prior.

## Strong alternatives with the same information

| Alternative | What it already provides | Requirement for a fair P3 comparison |
|---|---|---|
| Retained local system identification plus basis correction (S7) | Learns local dynamics and aligns them from mixed experiments. | Supply the same old observations, mixed protocols, excitation and class warrants. Charge both fitting and calibration. |
| Switched partial realization (S5, S6) | Reconstructs a common realization from word-indexed response information. | Charge acquisition of that information, especially noisy derivative estimation. |
| Direct paired-protocol measurement | Answers an order-effect task without a full model. | Include it whenever the target set is small; it may be the best method. |
| Retained PLS or other tailored predictor (S2) | Uses selected time-dependent signals to predict the response of interest. | Grant the same measured signals, retained fits, interventions, and validation tools. |
| Identifiable-combination signaling model (S1) | Retains partial mechanistic structure and extends it to new perturbations. | Do not erase the old fitted representation or supply P3 free target specificity. |
| Predictive state representation (S4) | Represents state through future experimental predictions. | Distinguish existence/closure from affordable acquisition and recognition. |
| Prediction-focused acceptable-model-set analysis (S3) | Can certify some predictions while parameters remain unidentifiable. | Compare on target uncertainty, not parameter recovery alone. |

The exact counterexample shows why single-mode data cannot suffice for either
side. It supplies no reason for a newly named learner to outperform these
retaining methods after equally informative mixed data are provided.

## More targeted opportunity

A possible research direction is learning only those mixed response directions
needed for a chosen family of downstream protocols, with bounded uncertainty,
rather than aligning an entire hidden state. An operation would take a retained
set of observational constraints and a new task, determine which unresolved
cross quantities matter to that task, choose finite-time experiments for those
quantities, and reuse the resulting constraints in later tasks.

This is a research question, not an established novel method. Experimental
design, partial realization, predictive-state learning, and task-specific
uncertainty analysis already cover substantial parts. The central challenge is
to obtain a strict improvement or a useful new guarantee under a scientifically
obtainable contract. The finite-time formula gives one conditioning-aware
starting point. Merely increasing hidden dimension or collecting more mode
tables would not resolve novelty or application relevance.

## Model access and verification that must not be free

The exact construction assumes controllable switching, reproducible initial
preparation, a calibrated measured port, and a time-homogeneous linear mode for
each intervention. Real drug protocols can violate these assumptions through
delayed action, hidden exposure dynamics, off-target effects, and irreversible
cell-state changes. Those violations cannot be dismissed as noise by definition.

A candidate application should therefore begin with a measured protocol data
set and independently justified range of approximation, or with an actual
experimental collaboration that supplies the relevant reset and perturbation
access. This subtask acquired no such new experimental access. Published
measurement results remain source evidence, not private confirmation cases.

## Recommendation to the central branch

Preserve the exact result as a minimal obstruction and an explicit positive
interface. Do not commit P3 to inventing generic basis alignment: S7 is directly
on point. Continue only if a task-targeted partial alignment or a different
representation earns a new finite-noise capability against the equally informed
retaining baselines. The biological task is consequential; the bridge from this
mathematics to that task is currently UNKNOWN.
