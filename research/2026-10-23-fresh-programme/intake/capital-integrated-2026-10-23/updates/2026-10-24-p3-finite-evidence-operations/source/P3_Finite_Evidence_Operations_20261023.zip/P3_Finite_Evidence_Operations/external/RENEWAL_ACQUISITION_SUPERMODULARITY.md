# Renewal acquisition: complementarity, charged greedy failure, and sharp completion

Private P3 continuation, 2026-10-23. This is a bounded mathematical challenge to the proposed acquisition rule, not a new benchmark or an application claim. It preserves the reset/access caveats in `RESET_ACCESS_CONTRACT.md`.

## 1. Exact statement: kernel-coordinate gains are supermodular

Let the finite control alphabet be A. A direct first-return experiment starts in the same reset state and records the first return/event under a control word. Write its nonnegative first-return coefficients as f(u), for nonempty words u. There are no zero-length events. For a finite acquired dictionary S define the noncommutative formal series

\[
F_S=\sum_{u\in S}f(u)u,\qquad R_S=(1-F_S)^{-1}=\sum_{k\ge0}F_S^k.
\]

For a fixed target word w of length n, the coefficient R_S(w) is a finite polynomial: sum the product of block weights over every segmentation of w into words in S. Every coefficient of this polynomial is nonnegative. The formal-series inverse needs no analytic convergence assumption for this finite-word statement.

Consequently

\[
\frac{\partial R}{\partial f(u)}=R\,u\,R,
\quad
\frac{\partial R(w)}{\partial f(u)}
=\sum_{w=xuy}R(x)R(y),
\]

and

\[
\frac{\partial^2R}{\partial f(u)\partial f(v)}
=R u R v R+R v R u R.
\]

For u=v the two terms coincide and supply the factor two. Higher derivatives sum the corresponding ordered insertions, with their multiplicities, and are also coefficientwise nonnegative.

Fix an initial dictionary and a collection of previously absent, distinct kernel coordinates, each with a fixed nonnegative acquired value. If T is the subset acquired, then V(T)=R_T(w) is monotone and supermodular:

\[
V(T\cup\{u\})-V(T)
\le V(U\cup\{u\})-V(U)
\quad(T\subseteq U,\ u\notin U).
\]

The conclusion also holds for any nonnegative weighted sum of target responses. The smallest complement is w=uv with only f(u)=alpha and f(v)=beta available: each singleton has value zero, while the pair has value alpha beta, provided these are the only successful segmentations.

**Scope matters.** This is a fixed-coordinate reveal-set result. A physical protocol reveals multiple prefix coefficients, and two protocols can reveal the same coefficient. The induced set function on overlapping protocol bundles need not be supermodular: redundant acquisition can create diminishing returns. This result also does not establish supermodularity of Bayesian value of information, confidence-set reduction, adaptive sample allocation, or net value after cost. Data-dependent confidence bounds can decrease unless their construction explicitly preserves a nested lower envelope.

## 2. A prefix-aware two-block greedy counterexample

An initially tempting example with target ab, complementary kernels a and b, and a decoy ab is invalid as a physical query example: a first-return run on ab also records the prefix event a. Use a crossing decoy instead.

Take target w=abcd. Retain f(a)=g>0 and f(d)=h>0. The three missing nonzero kernels are

\[
f(ab)=\alpha,\qquad f(cd)=\beta,\qquad f(bc)=\eta.
\]

Set every other first-return coefficient to zero, with g+alpha <= 1 and all displayed coefficients in [0,1]. Then exactly two segmentations succeed:

\[
R(abcd)=\alpha\beta+g\eta h.
\]

The three available first-return protocols are ab, cd, and bc. Each includes its prefix bins. Those bins add only the already retained a, or the zero coefficients b and c; no protocol accidentally reveals both complementary kernels.

With two equal-cost protocol batches available, a rule maximizing immediate target-bound gain chooses bc: its gain is g eta h, whereas either ab or cd alone has gain zero. The remaining batch cannot acquire both complementary kernels, so its final target bound is g eta h. The best pair is ab and cd whenever alpha beta > g eta h, yielding alpha beta. The ratio is

\[
\frac{g\eta h}{\alpha\beta}.
\]

All newly acquired coefficients can remain 1/2: take alpha=beta=eta=h=1/2 and let the previously acquired g be small. The ratio is then g. Historical acquisition of small positive g is not free and must be included in an end-to-end comparison.

### A version without any rare nonzero kernel

Let m>=1 and use target w=a^m bcd. Retain f(a)=f(d)=1/2. The missing kernels are

\[
f(a^m b)=f(cd)=f(bc)=1/2,
\]

and every other coefficient is zero. Prefix feasibility holds because the only positive first-return prefixes of a^m b have total 1/2+1/2=1. The response is

\[
R(a^m bcd)=\frac14+2^{-m-2}.
\]

The complementary protocols are a^m b and cd; the crossing decoy is bc. Give the design budget exactly the cost of one batch of each complementary protocol. Since cd and bc have the same duration and no earlier positive first-return bin, their batch costs match. Greedy spends on bc first because it is the sole action with positive immediate gain. It then cannot acquire both complementary batches. Its bound is 2^(-m-2), whereas the complementary pair gives 1/4: approximation ratio 2^(-m).

The a^m b protocol records the retained a bin and zero intermediate bins as well as its final bin. This does not reveal cd. There is no uncharged scalar-oracle assumption. All positive first-return probabilities equal 1/2. Pulse cost grows with m; this is an exact family of mathematical counterexamples, not a new empirical benchmark or evidence for cumulative intelligence.

The counterexample is to **one-step, fixed-batch kernel acquisition**. An oracle supplying exact post-acquisition marginal values still does not repair this greedy rule. It is not a lower bound against policies that plan complementary batches jointly, allocate partial batches adaptively, or directly measure the target response. Physical experiments that record every return and reset, rather than stop at the first return, can also supply additional data and must be credited for it.

## 3. Acquisition, precision, and stronger alternatives

A run of word u produces a categorical first-return time, including a no-return category. Thus it acquires a prefix bundle, not one scalar. All existing prefix observations must be retained. If early termination is permitted, charge the executed pulses and reset/readout work rather than only nominal word length.

For example, in the all-one-half construction, an a^m b trial stops after its first pulse with probability 1/2 and otherwise uses m+1 pulses. Its expected executed pulse count is (m+2)/2; cd and bc each use two. Reset and readout overhead is paid for every trial in all methods. The protocol-level greedy failure still holds because cd and bc have equal cost and the budget equals the sum of the complementary batch costs.

For a predeclared finite plan with at most M distinct retained first-return bins, N independent reset trials per relevant protocol suffice for the elementary simultaneous lower bounds

\[
\ell(u)=\max\left\{0,\widehat f(u)
-\sqrt{\frac{\log(2M/\delta)}{2N}}\right\}.
\]

Pooling prefix data is allowed when the trials share the same initial state and control prefix. Adaptive stopping or allocation requires a valid sequential construction rather than blindly reusing this fixed-N formula. On the simultaneous two-sided concentration event, |fhat(u)-f(u)| is at most the displayed radius for every retained bin; this event has probability at least 1-delta. If that radius is at most 1/8, every true one-half coefficient has lower bound at least 1/4 on this event. Hence the all-one-half counterexample does not require exponential measurement precision: fixed-batch shot counts can be O(log(M/delta)), and pulse cost is O(m log(M/delta)). Its bad greedy ratio remains exponential in m, up to a constant, on that event. This is still a statement about the specified batch-selection rule, not about an optimal measurement policy.

By contrast, taking a newly measured decoy coefficient eta to zero and pretending the cost is unchanged is invalid. Even seeing a single decoy return with probability at least 1-delta requires N >= log(delta)/log(1-eta), asymptotically log(1/delta)/eta. Relative precision can cost more. The constant-probability construction avoids this particular artifact.

The equally informed strong alternatives are:

1. **Retaining renewal/weighted-automaton learner.** Store all first-return observations, confidence information, and reset assumptions; use exactly the same segmentation recurrence and derivative computation. This reproduces the construction without a special learning architecture.
2. **Pair or block lookahead.** Enumerating the three possible pairs solves the counterexample. A marginal-gradient rule overlooking complementary missing blocks is weaker than this inexpensive tailored method. No general hardness claim is established here.
3. **Direct target measurement.** If the physical interface permits recording the target endpoint/event probability, estimate it directly. For a single target this can cost O(|w| epsilon^(-2) log(1/delta)) pulses under elementary Bernoulli bounds, plus reset/readout work; a variance-sensitive analysis can improve the bound. The renewal library earns an efficiency claim only through demonstrated reuse or reduced acquisition cost over a specified target family.
4. **Full trajectory retention when available.** A reset-on-event run can provide later excursions as well as the first one. Those additional controlled-prefix observations belong to every baseline. Stopping at the first event is an input-contract choice, not an information advantage.

For a fixed target of length n, form the segmentation DAG on positions 0,...,n. An edge i->j has weight f(w[i:j]) when that substring is acquired. Forward and backward path sums compute R(w) and all coordinate derivatives by accumulating forward(i)*backward(j) over matching edges. This takes O(E) arithmetic operations after matching/preprocessing, where E is the number of matching occurrences, and O(n) working storage if the matches can be streamed. Precision and substring matching are additional costs. This is the standard weighted path-sum computation available to the retaining baseline; no novel algorithmic advantage is claimed.

## 4. Sharp direct-data completion needs prefix states, not factor closure

Let S be any finite set of nonempty words with exact nonnegative directly acquired first-return data f(u). Its necessary feasibility condition is

\[
\sum_{u\in S:\ u\preceq v}f(u)\le1
\quad\text{for every word }v,
\]

where u precedes v means that u is a prefix of v. These are disjoint possible first-return times along v. It suffices to check the finitely many maximal measured words. Define

\[
s(v)=1-\sum_{u\in S:\ u\preceq v}f(u).
\]

Construct a controlled finite substochastic Markov chain with reset state r and one state for each nonempty proper prefix of a word in S. Treat r as the empty-prefix state. At a reachable prefix state v, under control a:

- Return to r with probability f(va)/s(v), taking f(va)=0 when va is absent from S.
- If va is a proper-prefix state, continue to it with probability s(va)/s(v).
- Kill any remaining mass. Equivalently, send it to an absorbing unobserved state.

When the continuation state exists, the two displayed probabilities sum to one because s(va)=s(v)-f(va). At a leaf they sum to at most one. If s(v)=0, the state is unreachable from a fresh reset before a return; choose its outgoing transitions arbitrarily substochastic or omit it. Positive descendant first-return mass would contradict feasibility.

Induction along a first excursion gives unreturned mass s(v) at prefix state v. Therefore the first-return probability at va is exactly f(va), and there are no positive first-return coefficients outside S. After every return, the process restarts at the same state r. Thus its full endpoint series is exactly (1-F_S)^(-1).

Every other admissible completion adds nonnegative first-return coefficients, so its endpoint series dominates R_S coefficientwise. The construction attains this bound simultaneously for every target word. It uses at most one reset state plus the number of distinct nonempty proper prefixes of S, and optionally one death state.

**No factor closure or measured-prefix closure of S is necessary.** Prefix closure is needed for the internal state trie. Missing prefix coefficients can be set to zero in the extremal completion. For example, S={ab} needs an internal state a but does not require measured f(a) or f(b).

This sharpness statement concerns finite-horizon controlled nonnegative substochastic maps with an exact reset/return port. It does not establish continuous-time generator embeddability, a fixed hidden dimension, or a uniform physical reset warrant. If an actual acquisition already supplied additional prefix counts, sharpness relative to the full record must include them. A smaller retained dictionary only yields sharpness relative to that deliberately smaller information set. Joint statistical constraints can also be stronger than coordinatewise lower bounds.

## Result and remaining question

The sound result is an acquisition-geometry warning: useful new return kernels can be complementary, and first-order target gain can hide the value of acquiring a new pair. The formal derivative is useful for accounting and local design but does not justify submodular-greedy claims. The sharp completion is valid for arbitrary direct-data dictionaries in the stated class. Both operations are reproducible by an ordinary retaining renewal/weighted-automaton baseline.

The unresolved scientific question is whether an obtainable reset/observation interface and a real family of changed tasks make this retained partial representation cheaper to acquire and extend than direct task measurements and strong tailored model fitting. The present proofs do not settle that question or claim novelty for renewal theory, formal power series, or forward/backward path sums.
