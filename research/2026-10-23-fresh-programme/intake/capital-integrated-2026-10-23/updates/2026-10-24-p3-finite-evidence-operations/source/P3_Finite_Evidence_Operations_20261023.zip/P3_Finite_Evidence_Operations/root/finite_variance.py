"""Compose a uniform correlation certificate into finite-run variance bounds.

Requires common stationarity at every observation time and an open-loop
schedule.  No infinite integrated correlation time or global mixing is
estimated.  Mean intervals must share the stated confidence event or have a
separately charged allocation.  Exact Fraction evaluation is not unit cost.
"""
from fractions import Fraction as F
from correlation_certificate import exact, word


def row_times(row,mat):
    return [sum((row[i]*mat[i][j] for i in range(len(row))),F(0))
            for j in range(len(row))]


def second_moment(compiled,actions):
    if compiled['status']!='CERTIFIED_UNDER_CONTRACT':
        raise ValueError('A uniform all-word certificate is required')
    actions=word(actions)
    left,right=compiled['left'],compiled['right']
    n=len(actions)+1
    row=[F(0)]*len(left)
    cross=F(0)
    for a in actions:
        row=row_times([x+y for x,y in zip(row,left)],compiled['program'][a])
        cross+=sum((x*y for x,y in zip(row,right)),F(0))
    c0=sum((x*y for x,y in zip(left,right)),F(0))
    center=(n*c0+2*cross)/(n*n)
    error=compiled['uniform_error']
    lo,hi=max(F(0),center-error),min(F(1),center+error)
    if lo>hi: raise ValueError('Moment intervals exclude a bounded-square expectation')
    return {'center':center,'lower':lo,'upper':hi,
            'observations_in_deployment':n,'schedule_actions':n-1,
            'weighted_program_dimension':len(left),'uniform_error_used':error}


def variance(compiled,actions,mean_interval):
    lo,hi=map(exact,mean_interval)
    if not -1<=lo<=hi<=1: raise ValueError('Mean confidence interval must lie in [-1,1]')
    minimum=F(0) if lo<=0<=hi else min(lo*lo,hi*hi)
    maximum=max(lo*lo,hi*hi)
    result=second_moment(compiled,actions)
    vlower=max(F(0),result['lower']-maximum)
    vupper=min(F(1),result['upper']-minimum)
    if vlower>vupper: raise ValueError('Correlation and mean intervals exclude nonnegative variance')
    result.update({'variance_lower':vlower,'variance_upper':vupper,
                   'mean_interval':(lo,hi)})
    return result


def chebyshev_failure(variance_upper,absolute_error):
    v,e=exact(variance_upper),exact(absolute_error)
    if not 0<=v<=1 or e<=0: raise ValueError('Valid variance bound and positive error required')
    return min(F(1),v/e**2)
