"""Exact rational check of the reversible preparation-memory counterexample.

This checks the discrete counterpart. The finite-CTMC construction and its
closed correlation formula are proved in PREPARATION_OBSTRUCTION.md. No
physical measurement or performance benchmark is represented by this file.
"""

from fractions import Fraction as F
from itertools import product
import json


def source(leak, back, reset, lam=F(1, 2)):
    block = (
        ((1-leak)*(1+lam)/2, (1-leak)*(1-lam)/2, leak),
        ((1-leak)*(1-lam)/2, (1-leak)*(1+lam)/2, leak),
        (back/2, back/2, 1-back),
    )
    block_pi = (back/(2*(leak+back)), back/(2*(leak+back)), leak/(leak+back))
    pi = tuple(x/2 for _ in (0, 1) for x in block_pi)
    f = (F(1), F(-1), F(1), F(-1), F(1), F(-1))
    mu = (F(1, 2), F(0), F(0), F(1, 2), F(0), F(0))
    pulse = tuple(tuple(
        (1-reset)*(block[i % 3][j % 3] if i//3 == j//3 else 0)
        + reset*pi[j] for j in range(6)
    ) for i in range(6))
    assert all(sum(row) == 1 for row in pulse)
    assert all(p > 0 for row in pulse for p in row)
    assert all(pi[i]*pulse[i][j] == pi[j]*pulse[j][i] for i in range(6) for j in range(6))
    return pulse, pi, mu, f


def exact_correlations(pulse, preparation, f, horizon):
    vector = f
    result = []
    for _ in range(horizon+1):
        result.append(sum(preparation[i]*f[i]*vector[i] for i in range(6)))
        vector = tuple(sum(pulse[i][j]*vector[j] for j in range(6)) for i in range(6))
    return result


def closed_response(leak, back, reset, lam, horizon):
    return (1-reset)**horizon * (
        leak/(leak+back) * (1-(1-leak-back)**horizon)
        + ((1-leak)*lam)**horizon
    )


def observed_triples(pulse, preparation, f):
    law = {s: F(0) for s in product((-1, 1), repeat=3)}
    for i, j, k in product(range(6), repeat=3):
        law[(int(f[i]), int(f[j]), int(f[k]))] += preparation[i]*pulse[i][j]*pulse[j][k]
    return law


def checks():
    leak, lam = F(1, 64), F(1, 2)
    back = reset = leak**2
    pulse, pi, mu, f = source(leak, back, reset, lam)
    short = exact_correlations(pulse, mu, f, 4)
    assert short == [closed_response(leak, back, reset, lam, n) for n in range(5)]
    h, j = short[1:3]
    variance = j-h*h
    assert h == (1-reset)*(1+leak)/2
    assert variance == (1-reset)**2 * leak * (1-leak-back)
    assert 0 < variance and h*h < j < h < 1

    naive_radius = variance/(1-h)**2
    horizon = 64
    actual = closed_response(leak, back, reset, lam, horizon)
    naive_upper = h**horizon + naive_radius
    assert actual > F(3, 5)
    assert actual > naive_upper

    actual_law = observed_triples(pulse, mu, f)
    baseline_law = {
        (a, b, c): F(1, 2)*(1+lam*a*b)/2*(1+lam*b*c)/2
        for a, b, c in product((-1, 1), repeat=3)
    }
    short_tv = sum(abs(actual_law[s]-baseline_law[s]) for s in actual_law)/2
    coupling_bound = 1-((1-leak)*(1-reset))**2
    assert short_tv <= coupling_bound <= 2*(leak+reset)
    hidden_prep_tv = sum(abs(mu[i]-pi[i]) for i in range(6))/2
    assert hidden_prep_tv == 1-back/(2*(leak+back))
    stationary_short = exact_correlations(pulse, pi, f, 2)

    return {
        "scope": "Exact applicability counterexample, not a theorem counterexample or benchmark",
        "all_pulse_entries_positive": True,
        "exact_common_equilibrium_detailed_balance": True,
        "apparent_first_moment": str(h),
        "apparent_second_moment": str(j),
        "apparent_residual_variance": str(variance),
        "naive_uniform_radius": str(naive_radius),
        "unqueried_horizon": horizon,
        "actual_long_correlation_exact": str(actual),
        "naive_upper_exact": str(naive_upper),
        "actual_long_correlation_exceeds_three_fifths": True,
        "naive_all_horizon_bound_false": True,
        "two_action_visible_history_tv": str(short_tv),
        "two_action_coupling_upper": str(coupling_bound),
        "full_hidden_preparation_tv": str(hidden_prep_tv),
        "correct_equilibrium_first_moment": str(stationary_short[1]),
        "correct_equilibrium_second_moment": str(stationary_short[2]),
        "decimal_views_only": {
            "actual_long": float(actual),
            "naive_upper": float(naive_upper),
            "short_visible_tv": float(short_tv),
            "hidden_preparation_tv": float(hidden_prep_tv),
        },
    }


if __name__ == "__main__":
    print(json.dumps(checks(), indent=2))
