"""Execute frozen exact-algebra criteria on independently chosen worker cases."""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import time
import renewal_frozen as r


def main():
    start=time.perf_counter()
    here=Path(__file__).resolve().parent
    inp=here.parent/'structure/renewal_confirmation_inputs.json'
    oraclepath=here.parent/'structure/renewal_direct_oracle_results.json'
    digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    assert digest(here/'RENEWAL_CHECK_CONTRACT.json')=='275315baca4cb4dc652922e9820fe3377b347f26f7cafe99374b379b55de92c5'
    assert digest(inp)=='d62db380579bff079b20332555a9f9908ae8940ae2e8ae031c5a4539d1057ee6'
    assert digest(oraclepath)=='828e98ead975f83fd4ff9f9db13f72d6c682458dfd9f77e41e76d09ed185ee59'
    assert digest(here/'renewal_frozen.py')=='30f4311c96153291b3014e0c456d8b450d35e18e5cfe1501f93a78888e2addc5'
    raw=json.loads(inp.read_text())
    oracle=json.loads(oraclepath.read_text())
    results=[]
    failures=[]
    total_checks=0
    for case,observed in zip(raw['cases'],oracle['cases']):
        assert case['id']==observed['id']
        refs={tuple(v['word']):v for v in observed['records']}
        q={tuple(w):F(refs[tuple(w)]['endpoint']) for w in case['dictionary']}
        f=r.endpoint_to_first_return(q)
        states,p=r.trie_completion(f,range(case['alphabet']))
        count=0
        strict_improvements=0
        for w,value in f.items():
            assert value==F(refs[w]['first_return']),('deconvolution',case['id'],w)
            count+=1
        for w in q:
            assert r.matrix_endpoint(w,p)==q[w],('retained_fit',case['id'],w)
            count+=1
        for wlist in case['target_words']:
            w=tuple(wlist)
            lower=r.lower_endpoint(w,f)
            attained=r.matrix_endpoint(w,p)
            original=F(refs[w]['endpoint'])
            block=r.retained_block_lower(w,q)
            checks={'sharp_trie_equality':lower==attained,
                    'original_lower_bound':lower<=original,
                    'retained_block_domination':block<=lower}
            for name,ok in checks.items():
                count+=1
                if not ok:
                    failures.append({'case':case['id'],'word':w,'check':name,
                        'lower':str(lower),'trie':str(attained),
                        'original':str(original),'block':str(block)})
            strict_improvements+=lower>block
        total_checks+=count
        results.append({'case':case['id'],'source_dimension':case['dimension'],
           'dictionary_endpoints':len(q)-1,'trie_states':len(states),
           'target_words':len(case['target_words']),
           'exact_equalities_and_inequalities':count,
           'strict_over_block_bound':strict_improvements})
    result={'scope':'Independent authored exact theorem checks, not empirical or intelligence-transfer evidence',
            'contract_sha256':digest(here/'RENEWAL_CHECK_CONTRACT.json'),
            'root_core_sha256':digest(here/'renewal_frozen.py'),
            'independent_inputs_sha256':digest(inp),
            'independent_oracle_sha256':digest(oraclepath),
            'cases':results,'total_checks':total_checks,'failures':failures,
            'status':'PASS' if not failures else 'FAIL',
            'wall_seconds':time.perf_counter()-start,
            'known_helper_boundary_issue': 'matrix_endpoint(empty, first_return=True) returns1. Core kernel excludes empty and all checked claims use nonempty first-return coefficients. Independently found before this run; preserved for correction.'}
    (here/'RENEWAL_CONFIRMATION.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if failures:
        raise SystemExit(1)


if __name__=='__main__':
    main()
