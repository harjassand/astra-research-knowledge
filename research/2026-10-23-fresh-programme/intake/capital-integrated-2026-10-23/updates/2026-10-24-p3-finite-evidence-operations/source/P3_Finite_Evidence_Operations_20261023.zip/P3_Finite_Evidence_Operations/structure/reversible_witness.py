"""One exact algebraic check of the reversible composition obstruction.

This is an authored witness, not a benchmark or scientific measurement.
No root implementation is imported. Exponentials at t=log(2) are obtained
from independently checked rational spectral projectors, not rounded expm.
"""

from fractions import Fraction as F
import json
from pathlib import Path


def mm(a, b):
    return [[sum((x * y for x, y in zip(row, col)), F(0))
             for col in zip(*b)] for row in a]


def mv(a, v):
    return [sum((x * y for x, y in zip(row, v)), F(0)) for row in a]


def dot(x, y):
    return sum((a * b for a, b in zip(x, y)), F(0))


def projector(v):
    n = dot(v, v)
    return [[F(x * y, n) for y in v] for x in v]


def lincomb(*terms):
    return [[sum((c * m[i][j] for c, m in terms), F(0))
             for j in range(3)] for i in range(3)]


def symmetric(a):
    return a == list(map(list, zip(*a)))


def generator(a):
    return symmetric(a) and all(sum(row) == 0 for row in a) and all(
        a[i][j] > 0 for i in range(3) for j in range(3) if i != j)


def corr(p, f):
    # Uniform pi factors cancel in normalization by C(0).
    return dot(f, mv(p, f)) / dot(f, f)


def main():
    a = [[F(x) for x in row] for row in
         [[-3, 1, 2], [1, -3, 2], [2, 2, -4]]]
    b = [[F(x) for x in row] for row in
         [[-3, 2, 1], [2, -3, 1], [1, 1, -2]]]
    s = [[F(x) for x in row] for row in
         [[1, 0, 0], [0, 0, 1], [0, 1, 0]]]
    bp = mm(mm(s, b), s)
    f = [F(2, 3), F(-1, 3), F(-1, 3)]
    one, u, v = [1, 1, 1], [1, -1, 0], [1, 1, -2]
    p0, pu, pv = projector(one), projector(u), projector(v)
    ident = [[F(i == j) for j in range(3)] for i in range(3)]
    pa = lincomb((F(1), p0), (F(1, 16), pu), (F(1, 64), pv))
    pb = lincomb((F(1), p0), (F(1, 32), pu), (F(1, 8), pv))
    pbp = mm(mm(s, pb), s)
    alpha, alpha2 = corr(pa, f), corr(mm(pa, pa), f)
    beta, beta2 = corr(pb, f), corr(mm(pb, pb), f)
    low = corr(mm(pa, pb), f)
    high = corr(mm(pa, pbp), f)
    center = alpha * beta
    radius_squared = (alpha2 - alpha * alpha) * (beta2 - beta * beta)
    checks = {
        "A_symmetric_irreducible_generator": generator(a),
        "B_symmetric_irreducible_generator": generator(b),
        "Bprime_symmetric_irreducible_generator": generator(bp),
        "S_fixes_f": mv(s, f) == f,
        "projectors_sum_to_identity": lincomb((F(1), p0), (F(1), pu), (F(1), pv)) == ident,
        "A_spectral_decomposition": a == lincomb((F(-4), pu), (F(-6), pv)),
        "B_spectral_decomposition": b == lincomb((F(-5), pu), (F(-3), pv)),
        "P_A_stochastic_positive": all(sum(row) == 1 for row in pa) and all(x > 0 for row in pa for x in row),
        "P_B_stochastic_positive": all(sum(row) == 1 for row in pb) and all(x > 0 for row in pb for x in row),
        "isolated_B_correlation_equal": beta == corr(pbp, f),
        "isolated_B_doubletime_equal": beta2 == corr(mm(pbp, pbp), f),
        "normalized_isolated_A": alpha == F(13, 256),
        "normalized_isolated_B": beta == F(7, 128),
        "world_I_mixed": low == F(1, 512),
        "world_II_mixed": high == F(59, 16384),
        "positive_gap": high - low == F(27, 16384),
        "lower_is_below_center": low < center,
        "upper_is_above_center": high > center,
        "lower_saturates_Gram_bound": (low - center) ** 2 == radius_squared,
        "upper_saturates_Gram_bound": (high - center) ** 2 == radius_squared,
        "A_B_commute": mm(a, b) == mm(b, a),
        "A_Bprime_do_not_commute": mm(a, bp) != mm(bp, a),
    }
    result = {
        "scope": "One authored exact algebraic witness; no measurement, transfer, or novelty claim",
        "time": "t=s=log(2)",
        "C0": str(dot(f, f) / 3),
        "A": [[str(x) for x in row] for row in a],
        "B": [[str(x) for x in row] for row in b],
        "Bprime": [[str(x) for x in row] for row in bp],
        "normalized": {"alpha": str(alpha), "alpha2": str(alpha2),
                       "beta": str(beta), "beta2": str(beta2),
                       "world_I": str(low), "world_II": str(high),
                       "gap": str(high - low), "Gram_center": str(center),
                       "Gram_radius_squared": str(radius_squared)},
        "checks": checks,
        "status": "PASS" if all(checks.values()) else "FAIL",
    }
    path = Path(__file__).with_name("reversible_witness_results.json")
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "checks": len(checks),
                      "failures": [k for k, ok in checks.items() if not ok],
                      "gap": str(high - low)}, indent=2))
    if not all(checks.values()):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
