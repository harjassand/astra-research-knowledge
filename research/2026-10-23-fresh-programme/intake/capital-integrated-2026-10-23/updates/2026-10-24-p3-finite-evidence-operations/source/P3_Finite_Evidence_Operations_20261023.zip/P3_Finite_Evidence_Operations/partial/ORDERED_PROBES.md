# Acquired ordered observations for passive scientific probes

Private P3 mechanism challenge, 23 October 2026. Continuation of `RESULT.md`.
All results below are derivations under explicit contracts. No acquired
physical measurement, application advantage, independent transfer experiment,
architectural advantage, or historical novelty is claimed.

## Decision

An order-sensitive representation can be acquired without identifying the
source dynamics: observe a source at independent Poisson times and retain the
ordered environmental marks. The same records estimate the response of every
later finite-state passive probe within a calibrated rate and complexity
budget. Source dynamics may be non-Markov, continuous, partly hidden, or
otherwise unidentified.

This exact identity is conditional time-inhomogeneous uniformization. It is
not a new scientific algorithm. A retaining program supplied the same records
ties it; if full feature vectors or full trajectories are available, stronger
conditional-averaging baselines can beat the mark-only estimator. Its useful
contribution to the investigation is a rigorous partial-knowledge contract
with costs and compositional boundaries, rather than an architectural win.

## 1. Scientific and prior context

Diffusion-mediated reaction probabilities depend on where and how long a
particle encounters reactive regions. The occupation approach in Bressloff's
encounter-based models supplies the scalar-killing predecessor. Sequential
reaction selectivity additionally depends on the order of encounters. Neither
source dynamics nor the set of all microscopic states has to be recovered to
predict a bounded passive reaction output, if the reaction law is calibrated.
The physically restrictive condition is that the proposed probe does not
alter the source process that generated its environmental exposures.

Primary sources opened for this continuation:

1. N. M. van Dijk, S. P. J. van Brummelen, R. J. Boucherie,
   *Uniformization: Basics, extensions and applications*, Performance
   Evaluation 118 (2018), 8-32, DOI 10.1016/j.peva.2017.09.008. Section 5,
   Result 5.1 gives time-inhomogeneous uniformization; Section 3 gives its
   Poisson expansion. These supply the established identity used here.
   https://ris.utwente.nl/ws/files/24801192/2018_XDijkBrummelenBoucherie_S0166531617301451_main.pdf
2. Lorenzo Lucchese, Mikko S. Pakkanen, Almut E. D. Veraart,
   *Learning with Expected Signatures: Theory and Applications*,
   arXiv:2505.20465v1 (2025). Expected iterated integrals are an existing
   distributional representation, including estimation costs. The elementary
   finite-variation expansion below places this construction in that family.
   https://arxiv.org/pdf/2505.20465
3. P. C. Bressloff, *Diffusion-mediated surface reactions, Brownian
   functionals and the Feynman-Kac formula*, arXiv:2201.01671v1 (2022).
   https://arxiv.org/pdf/2201.01671
4. P. C. Bressloff, *Encounter-based reaction-subdiffusion model II:
   partially absorbing traps and the occupation time propagator*,
   arXiv:2303.10484v1 (2023), equations (2.1)-(2.5).
   https://arxiv.org/pdf/2303.10484

This is not an exhaustive novelty search. The central identity is already
standard, so a claim of a newly invented identity would be false regardless
of whether this exact statistical packaging appears elsewhere.

## 2. Input and output contracts

Fix a time horizon H and source version/initial law. Independent source trials
supply a measurable random feature process

    g(t) = (g_1(t),...,g_k(t)),  g_i(t)>=0, sum_i g_i(t)<=1,

on [0,H]. There need not be a Markov state, a known source equation, or a finite
source state space. Histories can enter the feature definition, but the
requested feature must actually be observable at the scheduled time. An
uncomputed history-dependent feature is not free point access.

Observation access is one of the following, with different costs:

- Categorical access: at a requested time, return an independent mark I with
  conditional probabilities g_i(t); mark 0 has probability 1-sum_i g_i(t).
  A directly observed environmental region is the important one-hot case.
- Vector access: return the full vector g(t), then generate a mark locally.
  This may require k scalar readouts per observation. Retaining the vector
  gives a stronger baseline discussed below.

All future probes have q states, initial row distribution alpha, terminal
reward vector r in [0,1]^q, and generators

    A(t) = sum_i g_i(t) A_i,
    A_i = Lambda (P_i-I),

where P_i is row-stochastic. Equivalently, the per-channel exit rates of A_i
are at most the known positive rate Lambda. The entire family shares this
rate ceiling. Set P_0=I.

Conditional on the source path, the probe follows this time-dependent Markov
law, using independent reaction randomness. Its state and actions must not
change the source feature law. This is a passive-probe condition. It can follow
from an instrument design or a separately tested perturbative approximation;
baseline prediction quality cannot establish it.

The output is the endpoint expected reward

    J(P_1,...,P_k) = E[r(Y_H)].

Absorption can be represented by absorbing probe states. Cause-specific capture,
bounded sequence completion and endpoint selectivity are included. Unbounded
mean completion times, arbitrary source-changing control and arbitrary new
features are not automatically included.

## 3. Exact acquisition theorem

For each source trial, generate independent homogeneous Poisson times

    0 < T_1 < ... < T_N < H,  N ~ Poisson(Lambda H).

At T_j observe the feature mark I_j, independently conditional on the source
path and times. Retain the ordered word W=(I_1,...,I_N). For any later probe
program define

    F_P(W) = alpha P_{I_1} ... P_{I_N} r.                 (1)

The empty product is I. Then

    0 <= F_P(W) <= 1,       J(P)=E[F_P(W)].              (2)

Times do not have to be retained for this time-independent matrix family.
Time-dependent future matrices require timestamps and a corresponding
statistical complexity/precision contract.

### Proof

Condition on the full source feature path. Let

    B(t) = g_0(t) I + sum_i g_i(t) P_i.

Conditional averaging over the marks replaces the product in (1) by the
chronological product of B(T_j). Averaging the independent Poisson points
gives the absolutely convergent series

    U(H) = exp(-Lambda H) sum_{n>=0} Lambda^n
           integral_{0<t_1<...<t_n<H} B(t_1)...B(t_n) dt_1...dt_n.

The matrix terms are stochastic, and their scalar weights sum to 1. Standard
termwise differentiation of the bounded integral series gives the unique
absolutely continuous solution

    U'(t)=U(t) Lambda(B(t)-I)=U(t) A(t),  U(0)=I.

For bounded measurable coefficients the same conclusion follows directly from
the associated Volterra equation; isolated pointwise discontinuities do not
matter. Thus alpha U(H)r is the conditional endpoint reward. Integrating over
the source proves (2). Stochasticity supplies the bound without a condition
number or a source normalizer. This is conditional uniformization.

## 4. Order is necessary and is acquired

Take q=3, alpha=(1,0,0), r=(0,0,1)^T. Let P_1 move state 0 to 1 and leave the
other states fixed, while P_2 moves state 1 to 2 and leaves the other states
fixed. Then

    alpha P_1 P_2 r = 1,    alpha P_2 P_1 r = 0.

Compare two deterministic environments: g_1=1 on the first half of [0,H] and
g_2=1 on the second, versus the reverse order. Both have total occupations
L_1=L_2=H/2. For the first environment the sequential reaction succeeds with
probability

    (1-exp(-Lambda H/2))^2;

for the reverse environment it succeeds with probability zero. Total
occupations cannot answer this task even with infinite training data. Ordered
Poisson marks can: their reaction functional counts whether a mark 1 precedes
a mark 2. This is an algebraic counterexample, not a transfer benchmark.

## 5. Source and observation costs

With m independent complete trials, the total mark count obeys exactly

    N_total ~ Poisson(m Lambda H),
    E[N_total] = m Lambda H.                              (3)

The count is independent of the source's hidden complexity. There are m source
resets/trials, scheduled physical duration mH, and one environmental readout
per Poisson event. Any required preparation, independent replication,
nondestructive sensing, time resolution and clock generation are charged
separately. Repeats cannot be assumed independent merely because the code
requests them. In vector access the number of scalar features can be k times
the readout count.

Storing a mark costs ceil(log_2(k+1)) bits plus word boundaries and metadata.
Evaluating one dense q-state program costs O(N_total q^2) scalar arithmetic
operations; sparse transition structure can reduce this. Each new probe's
matrix acquisition, calibration, search, optimization and numerical precision
are additional costs. The mechanism does not acquire those matrices for free.

The callback-based executable in `ordered_probes.py` realizes acquisition and
prediction. It uses ordinary floating-point random scheduling and arithmetic;
it is not an exact-real hardware oracle or a formal floating-point certificate.
The scientific source adapter and its calibration are external to that code.

`python ordered_probes.py` completed successfully and its output is preserved
in `CHECK.json`. It checks the exact order counterexample and displays a
conservative confidence budget, rather than running a synthetic performance
benchmark. For q=3, k=2, Lambda H=2, epsilon=0.1 and delta=0.05, equation (7)
with the stated Chernoff tail chooses K=6 and m=40,935: expected 81,870 feature
observations. This is a sufficient worst-case bound, not an optimal count or
a claim of practical affordability. The selected rate-change example has
log second moment 32, showing how quickly the reuse guarantee can deteriorate.

## 6. Confidence for a finite probe family

For a fixed family of M probe programs, empirical averaging of (1) yields

    Pr(max_P |J_hat(P)-J(P)| > epsilon)
       <= 2M exp(-2m epsilon^2).

Thus

    m >= log(2M/delta)/(2 epsilon^2)                       (4)

suffices. All M queries share the same source records. After the uniform event
holds, a program may be chosen adaptively from that family using the records.
Choosing an unrestricted new program after inspecting data is not covered by
a pointwise confidence statement.

## 7. Explicit confidence for all bounded-size programs

Here q,k,H,Lambda,alpha,r are fixed before acquisition, but every collection of
row-stochastic matrices P_i is allowed. This includes a later calibrated or
learned program within the same common coordinate convention.

Let lambda=Lambda H. Choose K>=1 with the known Poisson tail

    t_K = Pr(Poisson(lambda)>K) <= epsilon/3.

Define F_P^K(W)=F_P(W) when |W|<=K and zero otherwise. Do not condition on
short words or discard their contribution to the sample denominator: that
would change the target law. Uniformly in P,

    |E[F_P^K]-J(P)| <= t_K.                               (5)

For two matrix collections P,Q, telescoping and stochastic contraction give

    |F_P(W)-F_Q(W)|
      <= |W| max_i ||P_i-Q_i||_infinity,                 (6)

where matrix infinity norm is maximum row l1 distance. On short words this
is K-Lipschitz. For a probability row, round its first q-1 entries down to
multiples of 1/R and put the remainder in the last coordinate. This gives a
stochastic row at l1 distance at most 2(q-1)/R. The number of grid rows is at
most (R+1)^(q-1), so the matrix family has an eta-cover with at most

    (R+1)^[k q(q-1)]  elements,
    R = ceil(2(q-1)/eta).

Take eta=epsilon/(6K), hence R=ceil(12(q-1)K/epsilon). A union bound with
net error epsilon/3 gives a sufficient trial count

    m >= (9/(2 epsilon^2))
         [log(2/delta) + k q(q-1) log(R+1)].              (7)

Indeed, for any P, select its net point Q. The empirical and population
Lipschitz errors total at most 2K eta=epsilon/3. The net sampling error is at
most epsilon/3 and the truncation error at most epsilon/3. Therefore, with
probability at least 1-delta,

    sup_P |m^-1 sum_j F_P^K(W_j)-J(P)| <= epsilon.        (8)

The net is a proof device; it need not be enumerated to evaluate a supplied
program. Optimizing across the program family still incurs its actual search
cost and is not made easy by uniform convergence. The q=1 case is constant
and needs no observations for a fixed alpha,r. When lambda=0 the source is
unused and J=alpha r exactly.

The exact Poisson tail is source-independent. A convenient conservative
computable bound for K+1>lambda is

    t_K <= exp[-lambda + (K+1)(1+log(lambda)-log(K+1))].

This follows by applying the Poisson moment-generating function and optimizing
the Chernoff parameter. Numerical evaluation of a tail bound also needs
precision control if it is used as a formal certificate.

## 8. Approximation and a partial calibration warrant

Suppose a sensor returns marks from a calibrated distribution g_tilde(t)
instead of g(t), including the slack mark. Couple the two marks maximally at
each shared Poisson time. The chance of any discrepant mark is bounded by
the expected number of discrepancies, giving for every bounded probe

    |J_true(P)-J_sensor(P)|
      <= Lambda E[integral_0^H TV(g(t),g_tilde(t)) dt].  (9)

In particular an average random-time calibration error

    E[TV(g(U),g_tilde(U))] <= zeta,   U~Uniform[0,H],

adds at most Lambda H zeta. A worst-case certificate over every possible
microscopic state is unnecessary for this bounded output task. The warrant
does still require an obtainable reference measurement or instrument
guarantee for the relevant source distribution. A calibration estimate from
finite audits needs its own confidence and acquisition budget.

Likewise, if the source-law change between acquisition and deployment has
total variation at most kappa on these ordered observations, bounded response
changes by at most kappa. It is not necessary to certify full latent-path total
variation if the task only depends on the observed words. This statement
specifies a sufficient warrant; it does not provide a cheap algorithm for
estimating TV on a huge word alphabet.

Finite clock precision is not automatically harmless. Arbitrary measurable
sources can distinguish ideal random times from a quantized schedule. A useful
implementation needs either an actually calibrated random-time instrument or
a bound on the induced average mark-distribution discrepancy. Temporal
regularity is one sufficient route; claiming an exact continuum-time oracle
from finite-bit scheduling would silently strengthen the access contract.

For stored matrices, if each row-l1 error is at most eta_P, the error on a
word of length N is at most N eta_P. The truncated estimator incurs at most
K eta_P. Similarly, if each numerical vector update remains a probability
vector and has l1 error at most eta_num, its total error is at most K eta_num.
Errors in alpha and r add their l1 and infinity bounds respectively. These
errors must be budgeted alongside (8) and (9). Nonnegative rounded stochastic
rows can be represented at O(log(Kq/epsilon)) bits per entry for a specified
rounding budget; exact source scheduling has the separate issue just stated.

## 9. Composition and an exact extension-cost warning

The retained word law is a shared input interface. Programs expressed in the
same environmental alphabet and the same calibrated probe coordinates can be
assembled by ordinary matrix or finite-state constructions. Sequential
reaction logic can enlarge q; independently evolving probes can use a product
state space. The uniform guarantee must cover the resulting q and rate ceiling.

Parallel probe generators generally add exit rates. If their sum exceeds the
acquisition rate ceiling, the original bounded-program guarantee does not
cover them. This is not an absolute information impossibility: words acquired
at rate Lambda>0 can be importance weighted to a new rate Lambda_prime.
Given N, ordered uniform times and conditional marks do not depend on the
Poisson rate. Therefore define

    L(N) = exp[-(Lambda_prime-Lambda)H]
           (Lambda_prime/Lambda)^N.

For a probe bounded by Lambda_prime,

    J_prime(P) = E_Lambda[L(N) F_P(W)],                  (10)

with P_i=I+A_i/Lambda_prime. The likelihood ratio has exact second moment

    E_Lambda[L(N)^2]
      = exp[H (Lambda_prime-Lambda)^2 / Lambda].        (11)

Proof: substitute the Poisson moment-generating function into E[a^(2N)]
and simplify the exponent. Hence the bounded variance guarantee can become
exponentially poor in the rate increase. This second moment is a warning and
an upper bound on the weighted response's second moment, not a universal lower
bound on every tailored estimator. Conditioning, control variates or special
source structure can improve particular programs.

Increasing rate can alternatively be acquired by superposing new Poisson
observations on the same saved/replayable source paths. Independent new paths
cannot be spliced into old words while preserving temporal correlations. If
the old paths cannot be replayed and raw data are absent, fresh trials may be
needed for a practical bounded estimator. Thinning a sufficiently high-rate
acquisition supports lower-rate future programs without this difficulty.

Unbounded future state size is another limit: arbitrary finite-state programs
can distinguish increasingly detailed word properties. Equation (7) is not a
uniform guarantee over every possible future program at zero extra cost.

## 10. Failure when the probe changes transport

Let H=1 and source environment X(t)=0 throughout every unprobed trial. Let
g_1(t)=1{X(t)=1}. A two-state probe starts in a and moves a->b at rate Lambda
when g_1=1; terminal reward is 1{Y_H=b}.

Two physical implementations agree on every possible unprobed observation:

- Passive implementation: X remains 0 after probe activation. Response is 0.
- Feedback implementation: activating the probe changes X to 1 for the trial.
  Response is 1-exp(-Lambda).

Every acquired unprobed word consists only of zeros in both implementations.
No amount of those observations can certify which deployment response applies.
This is exact observational indistinguishability, not a finite-sample issue.
It demonstrates why passivity or a quantified feedback model needs independent
evidence. A physical reaction that changes charge, binding, drag or local
environment can violate the contract even if its internal transition matrix
was perfectly calibrated elsewhere.

## 11. Strong equally informed baselines

| Method and access | What it does | Comparison |
|---|---|---|
| Retained categorical words | Stores the same W and averages (1) | Exact tie in acquisition, information and evaluation |
| Retained feature vectors at Poisson times | Replaces each P_I by B(t)=g_0 I+sum_i g_i P_i | Conditional expectation over marks; no greater variance, more storage and usually more arithmetic |
| Full retained feature trajectories | Solves the conditional time-ordered probe equation on each path, then averages | Further conditional averaging can reduce variance; measurement, storage and integration precision must be charged |
| Expected signature / iterated integrals | Stores temporal integrals and contracts them with products of generator matrices | Same order information in another representation; truncation, dimensional growth and acquisition errors matter |
| Identified source generator plus Krylov or model reduction | Computes probe response from a learned source operator | Can be much stronger when a small, well-conditioned source model is actually obtainable; acquiring that model is not free |
| Direct intervention trials | Runs each physical probe and observes endpoint reward | Includes actual probe feedback; separate acquisitions per program unless a justified transfer operation is supplied |

The vector-access improvement is exact: condition (1) on the observed vectors
and times. Its conditional expectation is alpha product_j B(T_j) r. The law
of total variance proves that its variance cannot exceed the randomized-mark
estimator's. In the one-hot environmental-label case these two coincide.

For finite-variation cumulative controls Z_i(t)=integral_0^t g_i(s)ds, the
time-ordered exponential also has the standard expansion

    U(H) = I + sum_{n>=1} sum_{i_1,...,i_n}
            integral_{t_1<...<t_n} dZ_{i_1}(t_1)...dZ_{i_n}(t_n)
            A_{i_1}...A_{i_n}.

Those coefficients are signature coordinates. Averaging them produces an
expected-signature representation. Poisson uniformization expresses the same
bounded response using stochastic products rather than explicitly storing
all k^n order-n coordinates. An equally informed randomized-signature or
uniformization implementation can make the same choice. There is no proved
complexity separation from those incumbents.

## 12. What survives, and where to investigate next

The constructive principle survives: useful acquired knowledge can be a law
of experimentally observable words that is sufficient for a class of future
operations, rather than a full recovered source model. Its warranted domain
can be distributional and task-specific. It supports genuine new queries and
composition within its access and complexity envelope.

The stronger comparison removes a novelty/architecture claim. This operation
is established stochastic-process machinery, and its efficient reuse is
retention plus an analytic transfer law. No scientific application has been
shown newly tractable here. The proof does not establish a general law of
cumulative intelligence.

A stronger next target would have to acquire something absent from this
contract: for example, learn an intervention interface or cross-program
coordinate alignment from accessible experiments, with a task-level warrant
that is cheaper than full system identification. Root's common-gauge
compatibility investigation attacks that missing interface. Merely adding
more probe states, longer words or more authored source paths does not resolve
it. Alternatively, an external scientific source with costly temporal sensing
could make this existing random-observation mechanism useful, but that requires
actual sensor/calibration costs and a tailored incumbent comparison.
