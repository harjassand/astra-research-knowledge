# Separate acquisition does not fix a common latent gauge

Private bounded P3 construction, 23 October 2026. This is a mathematical
counterexample and exact arithmetic check. It is not an empirical scientific
result or a new system-identification algorithm. The completed earlier circuit
results and `STRUCTURE_ACCESS.md` are preserved unchanged.

## Result and access contract

Two intervention families can each have a minimal, reachable and observable
three-state realization, be known exactly from every experiment available
within that family, and share a known baseline/reset operation, while their
alternating compositions remain unidentified. The missing information is
their relative latent coordinate system. It can be supplied by a small set of
cross-family experiments under a common finite-dimensional closure promise.
The promise is not inferred from observing separate small-rank realizations.

The observable is the binary event that a hidden Markov chain is in state 1.
An intervention specifies a positive column-stochastic transition matrix.
Independent copies can be prepared at the stationary law of a common baseline.
Each experiment applies a chosen intervention sequence and measures the binary
endpoint. The first, permutation-based counterexample remains valid even if
all intermediate binary observations and adaptive within-family actions are
available. A second continuous-gauge example uses endpoint-only access; it is
not claimed to preserve intermediate observation laws.

Preparation does not require a hidden-state readout in this construction:
the supplied baseline has a known mixing bound. The bound is an input contract
about the physical or computational intervention, not something certified by
finite endpoint data. In an application it must be established or conservatively
replaced by an obtainable preparation-error bound.

## 1. An exact positive, uniformly mixing Markov counterexample

Use column distributions, and let

```
A = (1/10) [[6,4,1], [3,5,2], [1,1,7]],
B = (1/10) [[3,2,4], [6,3,1], [1,5,5]],
r = (1,1,1)^T / 3,             c = (1,0,0),
S = [[1,0,0], [0,0,1], [0,1,0]],
J = r (1,1,1),                P0 = (I+J)/2,
B_swap = S B S.
```

World I has interventions `(P0,A,B)`; world II has
`(P0,A,B_swap)`. We have

```
Sr=r,  cS=c,  S^2=I,  SP0=P0S.
```

Every matrix product over `{P0,B_swap}` is the conjugate by S of the
corresponding product over `{P0,B}`. Its scalar response from r through c is
therefore identical. The A/baseline family is unchanged. The same argument
includes any amplitude mixture `(1-u)P0+uB`, `0<=u<=1`.

For intermediate measurements let `D1=diag(1,0,0)`, `D0=I-D1`.
Both commute with S, as does the terminal covector `(1,1,1)`.
The probability of every binary outcome history is a product of intervention
matrices and these observation projectors. Conjugation therefore preserves
the complete history law within the B family. Conditioning on previous
observations also preserves the law of adaptive within-family policies.

Nevertheless, with matrix products written in mathematical order,

```
c A B r       = 7/20 = 0.35,
c A B_swap r  = 9/25 = 0.36,
c B A r       = 89/300,
c B_swap A r  = 91/300.
```

Here `c A B r` means apply B first and then A. A cross-family pulse sequence
reveals information absent from all isolated-family histories. No number of
additional within-family experiments can obtain that information.

### The ambiguity is not an unused hidden direction or instability

Let `R_M=[r,Mr,M^2r]`, `O_M=[c;cM;cM^2]`. Exact determinants are:

| Matrix | det R_M | det O_M | Dobrushin contraction coefficient |
|---|---:|---:|---:|
| A | 1/9000 | 39/1000 | 3/5 |
| B | 1/1800 | -3/50 | 1/2 |
| B_swap | -1/1800 | 3/50 | 1/2 |

Thus each homogeneous endpoint-response series has minimal dimension three.
All entries are positive. The baseline contraction coefficient is 1/2.
Uniform mixing therefore does not remove the relative-gauge obstruction.
If strict asymptotic stability rather than Markov normalization is desired,
scale all transition matrices by 1/2; the matrices remain positive and have
spectral radius 1/2. Two-step response gaps are then divided by four, while
reachability and observability ranks are unchanged.

The reset is explicit:

```
P0^k = J + 2^(-k)(I-J).
```

Starting from an arbitrary distribution and applying k baseline steps leaves
TV distance at most `2^(-k)` from r. Markov contraction and a bounded binary
measurement imply the same upper bound on endpoint-probability bias.
Reset duration must therefore be charged in every repeated experiment.

## 2. The classical cross-Hankel connector

Assume the two operators act on a common n-dimensional linear state space,
share initial vector r and scalar output c, and are each reachable/observable
on that whole space. Define

```
R_A = [r, Ar, ..., A^(n-1)r],
O_A = [c; cA; ...; cA^(n-1)],
H_A = O_A R_A,         H_A^+ = O_A A R_A,
H_AB = O_A R_B.
```

Each entry of H_A and H_A^+ is a single-family moment. Hence the representation

```
A_A = H_A^(-1) H_A^+ = R_A^(-1) A R_A
```

is obtained from that family, with `r_A=e1` and `c_A=c R_A`.
The B family similarly yields `B_B=R_B^(-1) B R_B`. The mixed block has entries

```
(H_AB)[i,j] = c A^i B^j r,      0<=i,j<n.
```

Consequently

```
T = H_A^(-1) H_AB = R_A^(-1) R_B,
B_A = T B_B T^(-1).
```

Both operators are now expressed in the same coordinates. Every finite word
of A and B is computable as its corresponding matrix product. The proof is
the displayed factorization; no recovery of physical hidden-state labels is
required. The first row and first column of H_AB were already obtained from
the two single families. In the generic arbitrary linear case at most
`(n-1)^2` new scalar cross moments suffice.

This is ordinary realization/Hankel machinery and a strong tailored baseline.
It is not presented as a new representation learner. Its value here is to
isolate exactly which new acquired information makes a further operation
possible and which structural promise makes that information sufficient.

### Markov normalization reduces the free connector information

For normalized Markov states, `1^T R_A = 1^T R_B = 1^T`. Therefore

```
T e1=e1,       c_A T=c_B,       1^T T=1^T.
```

When c_A and 1^T are independent, the affine dimension of matrices satisfying
these linear equalities is `(n-1)(n-2)`. Indeed the first column is fixed; each
remaining column satisfies two independent scalar constraints. Invertibility
and positivity of the induced physical operator restrict an open region when
they hold strictly, without adding affine equalities. This dimension count
is not a general statistical minimax bound.

For the explicit A above,

```
13*1^T = 12*c - 80*cA + 100*cA^2.
```

Hence every normalized x satisfies

```
cA^2x = (13 - 12*cx + 80*cAx)/100.
```

The mixed block H_AB is therefore filled by just two new moments

```
theta1 = cABr,         theta2 = cAB^2r.
```

Its row 0 and column 0 are known from isolated acquisition; each remaining
entry in row 2 follows from row 0, row 1, and normalization. These two moments
align the full endpoint-response models in this three-dimensional contract.
The exact connector for B is

```
T = [[1,2,-3/5], [0,-1,33/5], [0,0,-5]].
```

The coefficients need not be positive: these are predictive/reachability
coordinates, not physical hidden-state probabilities. Physical A and B remain
positive stochastic matrices.

## 3. One selected cross statistic need not align the models

For endpoint-only access, the transformations

```
S(a,b) = [[1,0,0], [a,b,1-a-b], [-a,1-b,a+b]]
```

fix r, c, and normalization. They commute with P0. Their determinant is
`a+2b-1`; S(0,1)=I. Near that point `B(a,b)=S(a,b) B S(a,b)^(-1)` remains
strictly positive and column-stochastic, while all single-family endpoint
responses remain unchanged. Direct calculation gives

```
c A B(a,b) r   = 9/25 - a/50 - b/100,
c A B(a,b)^2 r = 1097/3000 - 23*a/1000 - 19*b/1000.
```

The coefficient determinant is `(38-23)/100000=3/20000`, which is nonzero.
Thus the pair `(theta1,theta2)` locally identifies the two gauge parameters.
Along `b=1-2a`, theta1 is fixed at 7/20 but

```
theta2 = 26/75 + 3*a/200.
```

For `a=1/10`, `b=4/5`, exact arithmetic yields

```
B_cont = [[23/70,1/7,3/7],
          [1/2,7/20,3/20],
          [6/35,71/140,59/140]].
```

This is strictly positive, column-stochastic, and has Dobrushin coefficient
7/20. It agrees with B on theta1 but differs on theta2 by 3/2000. This is an
exact counterexample to declaring the one tested cross moment a complete
composition warrant. A single scalar finite-word endpoint probability is a
continuous rational function of `(a,b)` and cannot inject an open 2D family
into R; the two independent cross moments show that distinct parameter pairs
can correspond to distinct composition behavior. A full observation-history
distribution provides multiple scalar statistics and is not counted as one.

**Observation limitation:** these general S(a,b) do not commute with D1.
Unlike the permutation example, they need not preserve the law of intermediate
observations. This second example applies to destructive endpoint assays or
an interface that returns only final outputs. It does not establish a
two-moment lower bound when all within-run observations are available.

## 4. Acquisition, noise and the scientific limit of the result

The matrices above are exact mathematical witnesses. A laboratory receives
Bernoulli outcomes, not exact probabilities. For K prescribed probability
estimates, m independent repeats per experiment give simultaneous absolute
sampling error at most epsilon with probability at least 1-delta when

```
m >= log(2*K/delta)/(2*epsilon^2).
```

Add the preparation bias `2^(-k)` to each interval. Each repeat charges k
baseline reset steps, the pulse-sequence duration, and the endpoint assay.
The explicit 0.01 two-world gap can be resolved, but it does not imply that
all connector coordinates are well conditioned. Forming inverse Hankel
matrices can amplify noise strongly. A noisy learner must carry a validated
conditioning/error bound, solve a constrained compatible-system problem, or
directly estimate the requested sequence. Exact rational arithmetic here
only validates the algebraic construction, not physical measurement precision.

For a single requested short sequence, directly repeating that sequence is
the strong baseline: it may be much cheaper than learning a connector. The
connector can only claim an acquisition benefit for multiple changed sequence
tasks, or for sequences whose direct experiments are expensive or unavailable
but whose needed short cross experiments are feasible. All isolated-family
acquisition and cross-moment verification must be amortized honestly.

A common n-dimensional realization is a real sufficiency condition. Separate
rank-n response models alone do not exclude jointly reachable extra states.
Nor do finitely many consistent moment measurements certify exact finite rank.
The endpoint connector proves no physical model class, no exact applicability
outside that contract, and no general law of cumulative intelligence.

A consequential candidate application is prediction of ordered control or
perturbation protocols from previously learned response families when direct
long protocol experiments are costly. The counterexample identifies a genuine
information requirement for that operation. No external physical system,
dataset, or experimental implementation has yet established the required
finite-dimensional contract or a practical advantage. Those remain UNKNOWN.

## 5. Strong primary baselines and scope of reading

1. Petreczky, Realization Theory for Linear Switched Systems: Formal Power
   Series Approach, Part I, ESAIM COCV 17 (2011), 410-445. Full primary PDF read.
   The paper proves minimality from observability/reachability, uniqueness up
   to similarity, and Hankel constructions for switched realizations. This
   source is continuous-time; the discrete-time analogue is listed below.
   https://www.numdam.org/item/10.1051/cocv/2010014.pdf
2. Petreczky, Bako and van Schuppen, Realization Theory of Discrete-Time Linear
   Switched Systems (2011). Primary abstract read; full theorem not audited.
   https://arxiv.org/abs/1103.1343
3. Littman, Sutton and Singh, Predictive Representations of State, NeurIPS 2001.
   Full primary PDF read. Theorem 1 constructs a finite predictive-state
   representation from a given POMDP. The outcome-vector closure argument
   explains compositional sufficiency; it is not a black-box class-recognition
   guarantee. Learning multi-action representations is a separate issue.
   https://papers.nips.cc/paper_files/paper/2001/file/1e4d36177d71bbb3558e43af9577d70e-Paper.pdf
4. Sontag, Wang and Megretski, Input Classes for Identification of Bilinear
   Systems, IEEE TAC 54(2) (2009), 195-207, DOI 10.1109/TAC.2008.2006927.
   Primary institutional abstract read; full-PDF retrieval returned HTTP 429.
   The abstract distinguishes insufficient step/single-pulse inputs from a
   richer family of fixed-amplitude pulses of varying widths. Do not infer
   the exact assumptions of its sufficiency theorem from this note.
   https://dspace.mit.edu/entities/publication/eaa6dc67-f6a6-4ccd-9424-cc01a584148b
5. Sattar, Jedra, Fazel and Dean, Finite Sample Identification of Partially
   Observed Bilinear Dynamical Systems, L4DC 2025. Primary proceedings abstract
   read. The complete process estimates Markov-like parameters and realizes
   a system from an input-output trajectory under uniform stability. It is a
   stronger baseline than repeated isolated identification. Full-PDF retrieval
   did not render through the browsing tool; no detailed bound is quoted here.
   https://proceedings.mlr.press/v283/sattar25a.html

## Reproducibility and failed attempts

Run `python gauge_example.py > gauge_example_results.json` from this directory.
The saved results use exact `fractions.Fraction` arithmetic. All matrix,
minimality, positivity, connector, normalization, cross-statistic, and reset
identities asserted by the script passed. A first exploratory calculation
attempted SymPy, which was unavailable; it was replaced by standard-library
fraction arithmetic without an installation. These are authored constructions
and proof checks, with no withheld empirical test. No new worker, model
override, physical experiment, public disclosure, or external allocation was
used. Token and elapsed research costs beyond observed tool receipts are
UNKNOWN.
