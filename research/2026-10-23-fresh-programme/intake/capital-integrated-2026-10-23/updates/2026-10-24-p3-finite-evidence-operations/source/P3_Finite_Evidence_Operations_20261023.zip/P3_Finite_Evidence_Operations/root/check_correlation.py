"""Frozen-scope exact checks; authored exposed fixtures, not transfer evidence."""
from fractions import Fraction as F
from pathlib import Path
import json
import hashlib
import time
from correlation_certificate import Representation, Correlations, mv, rational_bits
from uniform_correlation import uniform_certificate, run_program
from metric_correlation import metric_certificate, mm, psd
from positive_certificate import log_interval


def invert(a):
    n = len(a)
    z = [list(row)+[F(int(i == j)) for j in range(n)] for i, row in enumerate(a)]
    for i in range(n):
        pivot = next(j for j in range(i, n) if z[j][i])
        z[i], z[pivot] = z[pivot], z[i]
        p = z[i][i]
        z[i] = [x/p for x in z[i]]
        for j in range(n):
            if j != i:
                c = z[j][i]
                z[j] = [x-c*y for x, y in zip(z[j], z[i])]
    return [row[n:] for row in z]


def projector(v):
    n = sum(x*x for x in v)
    return [[F(x*y, n) for y in v] for x in v]


def matrix_source():
    # The already exposed structure/reversible_witness.py example.
    p0, pu, pv = map(projector, ([1,1,1], [1,-1,0], [1,1,-2]))
    def combine(alpha, beta):
        return [[p0[i][j]+alpha*pu[i][j]+beta*pv[i][j] for j in range(3)] for i in range(3)]
    a, b = combine(F(1,16), F(1,64)), combine(F(1,32), F(1,8))
    s = [[F(x) for x in row] for row in [[1,0,0],[0,0,1],[0,1,0]]]
    source = {0:a, 1:mm(mm(s,b),s)}
    f = [F(2,3), F(-1,3), F(-1,3)]
    calls = []
    def query(w):
        calls.append(tuple(w))
        z = f
        for action in reversed(w):
            z = mv(source[action], z)
        return sum((x*y for x,y in zip(f,z)),F(0))/3
    return query, calls


def ceil_fraction(x):
    return -(-x.numerator//x.denominator)


def samples(radius, delta, quantities=1):
    _, log_hi, terms = log_interval(F(2*quantities,1)/delta, 90)
    return ceil_fraction(2*log_hi/radius**2), terms


def serialize(x):
    if isinstance(x,F): return str(x)
    if isinstance(x,dict): return {str(k):serialize(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)): return [serialize(v) for v in x]
    return x


def max_bits(x):
    if isinstance(x,F): return rational_bits(x)
    if isinstance(x,dict): return max((max_bits(v) for v in x.values()),default=0)
    if isinstance(x,(tuple,list)): return max((max_bits(v) for v in x),default=0)
    return 0


def main():
    start = time.perf_counter()
    contract_path = Path(__file__).with_name('CORRELATION_CHECK_CONTRACT.json')
    contract = json.loads(contract_path.read_text())
    checks = []
    def check(name, condition):
        checks.append({'name':name,'pass':bool(condition)})
    query, calls = matrix_source()
    shell = Representation([(),(0,)], {0:[[0,0],[0,0]],1:[[0,0],[0,0]]})
    pool = shell.acquisition_words()
    centers = {w:query(w) for w in pool}
    paid_oracle_calls = len(calls)
    exact_data = Correlations({w:(c,c) for w,c in centers.items()})
    e = [(F(1),F(0)),(F(0),F(1))]
    value = lambda form: exact_data.evaluate(form)[0]
    gram = [[value(shell.inner_form(x,y)) for y in e] for x in e]
    gi = invert(gram)
    actions = {a:mm(gi,[[value(shell.inner_form(x,y,(a,))) for y in e] for x in e])
               for a in (0,1)}
    rep = Representation([(),(0,)],actions)
    euclidean = uniform_certificate(rep,exact_data)
    check('natural_word_coordinates_fail_Euclidean_sufficient_test',euclidean['status']=='UNKNOWN')
    metric = metric_certificate(rep,exact_data,gram)
    check('paid_Gram_center_supplies_verified_candidate_metric',metric['status']=='CERTIFIED_UNDER_CONTRACT')
    check('exact_source_closure_gives_zero_uniform_error',metric.get('uniform_error')==0)
    noisy = Correlations({w:(c-F(1,10**8),c+F(1,10**8)) for w,c in centers.items()})
    noisy_metric = metric_certificate(rep,noisy,gram)
    target_results=[]
    for w in contract['existing_witness_targets']:
        w=tuple(w)
        truth=query(w)
        cert=rep.certify(w,exact_data)
        nc=rep.certify(w,noisy)
        prediction=run_program(metric,w)
        check('unqueried_target_'+str(w),w not in centers and w[::-1] not in centers)
        check('exact_program_'+str(w),prediction==truth==cert['corrected_center'])
        check('exact_zero_residual_'+str(w),cert['cross_remainder']==0)
        check('noisy_target_contains_truth_'+str(w),nc['lower']<=truth<=nc['upper'])
        check('uniform_noisy_contains_truth_'+str(w),
              abs(run_program(noisy_metric,w)-truth)<=noisy_metric['uniform_error'])
        target_results.append({'word':w,'truth':truth,'noisy_width':nc['upper']-nc['lower'],
                               'noisy_pair_remainder':nc['cross_remainder']})
    lam,v=F(1,2),F(1,10000)
    scalar=Representation([()],{0:[[lam]]})
    sx=Correlations({():(1,1),(0,):(lam,lam),(0,0):(lam*lam+v,lam*lam+v)})
    sc=uniform_certificate(scalar,sx)
    check('scalar_uniform_radius',sc['uniform_error']==v/(1-lam)**2)
    x=lam-v/(1-lam); p=v/((1-lam)**2+v)
    y=lam+v/lam; q=lam*lam/(lam*lam+v)
    scalar_results=[]
    for n in contract['scalar_horizons']:
        upper=p+(1-p)*x**n; lower=q*y**n
        cert=scalar.certify((0,)*n,sx)
        check('sharp_moment_envelope_inside_certificate_N'+str(n),
              cert['lower']<=lower<=upper<=cert['upper'])
        scalar_results.append({'horizon':n,'sharp_lower':lower,'sharp_upper':upper,
                               'two_sided_radius':cert['cross_remainder'],
                               'one_sided_radius':cert['one_sided_remainder'],
                               'corrected_center':cert['corrected_center']})
    # Complete sampled procedure: empirical lambda, two acquired moments.
    # On the simultaneous eta event, |lambda_hat-lambda|<=eta and
    # R_upper<=v+4eta+5eta²; this bound includes fluctuations of the centers.
    eta,delta,eps=F(1,40000),F(1,100),F(1,1000)
    worst_uniform=(v+4*eta+5*eta**2)/(1-lam-eta)**2+eta/(1-lam-eta)
    check('actual_sampling_event_suffices_for_promised_accuracy',worst_uniform<eps)
    m,logterms=samples(eta,delta,2)
    direct,dlterms=samples(eps,delta,1)
    costs={'scope':'Analytic sufficient counts; these trials were NOT executed',
           'epsilon':eps,'delta':delta,'lambda':lam,'variance':v,'moment_radius':eta,
           'all_horizon_error_on_simultaneous_event':worst_uniform,
           'independent_trials_per_required_moment':m,
           'endpoint_only_acquisition':{'preparations':2*m,'pulses':3*m,'readouts':4*m},
           'if_nondestructive_intermediate_readout_available':
               {'preparations':m,'pulses':2*m,'readouts':3*m},
           'direct_one_target':[{ 'length':n,'preparations':direct,'pulses':n*direct,
                                  'readouts':2*direct} for n in contract['cost_contract']['direct_target_lengths']],
           'exact_log_series_terms':logterms+dlterms,
           'unpriced_necessary_costs':['stationary preparation/equilibration','readout calibration',
                                      'hardware protocol switching','warrant for common reversibility'],
           'strong_retaining_moment_method':'Same paid moment table can implement sharper exact envelope; no algorithmic advantage established'}
    all_internal={'metric':metric,'noisy_metric':noisy_metric,'scalar':scalar_results,'costs':costs}
    result={'status':'PASS' if all(c['pass'] for c in checks) else 'FAIL',
            'scope':contract['scope'],'prior_exposure':contract['prior_exposure'],
            'contract_sha256':hashlib.sha256(contract_path.read_bytes()).hexdigest(),
            'checks':checks,'acquisition_oracle_protocols':paid_oracle_calls,
            'acquisition_oracle_pulses':sum(map(len,pool)),
            'existing_witness':{'gram':gram,'candidate_actions':actions,
                                'euclidean_status':euclidean['status'],
                                'metric_exact_error':metric.get('uniform_error'),
                                'metric_noisy_error':noisy_metric.get('uniform_error'),
                                'metric_contraction_bound':metric.get('coefficient_contraction_upper'),
                                'exact_psd_checks':metric.get('exact_psd_checks',0)+noisy_metric.get('exact_psd_checks',0),
                                'targets':target_results},
            'scalar_comparison':scalar_results,'costs':costs,
            'maximum_recorded_rational_bits':max_bits(all_internal),
            'elapsed_seconds':time.perf_counter()-start}
    path=Path(__file__).with_name('CORRELATION_CHECK.json')
    path.write_text(json.dumps(serialize(result),indent=2)+'\n')
    print(json.dumps({'status':result['status'],'checks':len(checks),
                      'failed':[c['name'] for c in checks if not c['pass']],
                      'protocols':paid_oracle_calls,'exact_psd_checks':result['existing_witness']['exact_psd_checks'],
                      'uniform_noisy_radius':float(noisy_metric['uniform_error']),
                      'sampled_all_horizon_radius':float(worst_uniform),
                      'trials_per_moment':m,'direct_trials':direct,
                      'max_rational_bits':result['maximum_recorded_rational_bits'],
                      'elapsed_seconds':result['elapsed_seconds']},indent=2))
    if result['status']!='PASS': raise SystemExit(1)


if __name__=='__main__': main()
