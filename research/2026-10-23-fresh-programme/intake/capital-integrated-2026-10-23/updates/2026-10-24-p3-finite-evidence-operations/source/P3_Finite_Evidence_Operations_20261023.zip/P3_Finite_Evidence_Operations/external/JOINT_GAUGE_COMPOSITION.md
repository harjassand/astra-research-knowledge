# Separate intervention knowledge need not compose

Private P3 working result, 2026-10-23. This document preserves a mathematical
construction and its limits. It is not a claim of a new general system
identification method, new biological evidence, or established practical benefit.

## 1. The operation-identifiability criterion

Let `M` be a candidate physical model, `O(M)` its entire accessible observational
signature, and `T(M)` the result of a proposed new operation. A predictor
`f(O(M)) = T(M)` exists on the model class exactly when

\[
 O(M)=O(M')\quad\Longrightarrow\quad T(M)=T(M').                 \tag{1}
\]

Necessity follows because equal inputs to `f` have equal outputs. For sufficiency,
define `f` on each signature to be the common value of `T` on its fiber. This is an
identifiability criterion, not an algorithm or a numerical stability guarantee.
Full model identification is sufficient but unnecessary.

For a model-changing operation `U`, a reusable quotient update
`O(U(M)) = Ubar(O(M))` exists exactly when `O(U(M))` is constant on the fibers of
`O`. If every allowed operation has this property on one common model class and
quotient, the updates compose by induction. Warranting separate operations
through different equivalences does not establish this common closure.

An analogous state-level statement is useful but distinct. A state representation
`r(x)` supports a flow `Phi_a^t` exactly when
`r(x)=r(x')` implies `r(Phi_a^t(x))=r(Phi_a^t(x'))`; measured outputs must also
factor through `r`. This is the familiar congruence/bisimulation idea. The
counterexample below concerns epistemic uncertainty across physical models.

## 2. A smaller preparatory example

Consider nonnegative two-compartment dynamics with one calibrated port:

\[
\dot x=A x+e_1u,\qquad y=e_1^\top x,\qquad
A=\begin{pmatrix}-a&b\\c&-d\end{pmatrix},
\quad a,d,b,c>0,\quad ad>bc.
\]

The measured transfer is

\[
G(s)=\frac{s+d}{(s+a)(s+d)-bc}.
\]

Thus the pairs `(b,c)=(1,1)` and `(2,1/2)` are indistinguishable when
`a=2,d=3`, under every waveform at that port. The hidden scaling
`S=diag(1,1/2)` maps the first generator to the second while fixing input and
output.

If an intervention multiplies `b` by a specified time-varying factor and/or
multiplies `c` by another, the same constant `S` intertwines the entire
intervened dynamics. All such protocols remain predictable from the common
quotient even though `b` and `c` remain physically unidentified.

If an intervention instead adds a calibrated `+1` to `b`, the two DC outputs
under unit input become `3/4` and `2/3`. The same observational quotient does not
support that operation. A new calibrated input into compartment 2 would separate
the worlds: its transfer to the original output is `b/((s+a)(s+d)-bc)`, with DC
values `1/5` and `2/5`. This is genuinely new information, but ordinary port
calibration and retaining system identification can acquire it too. Merely
declaring a hidden-state port to be accessible would supply the missing answer.

## 3. Minimal positive stable failure of joint composition

### Accessible experiments

An experiment starts from `x0=e1`, uses the input `e1 u(t)`, and measures
`y=e1^T x`. The initial state can instead be prepared by an ideal input impulse
from zero. The construction grants this strong reset/preparation interface.

There is a common baseline mode `A0=-I`. Existing data may include every
possible experiment using baseline and mode A, and every possible experiment
using baseline and mode B. An existing experiment never contains both A and B.
The input waveforms, observation precision, hold times, and number of such
experiments are unrestricted. Thus the impossibility is not caused by a small
finite training set.

### Two physical worlds

In world 1, the intervention generators are

\[
A=\begin{pmatrix}-2&1\\1&-3\end{pmatrix},\qquad
B=\begin{pmatrix}-4&1\\1&-5\end{pmatrix}=A-2I.
\]

In world 2, they are

\[
A'=\begin{pmatrix}-2&2\\1/2&-3\end{pmatrix},\qquad
B'=\begin{pmatrix}-4&1/2\\2&-5\end{pmatrix}.
\]

These are all Metzler matrices with negative trace and positive determinant.
They are therefore positive, Hurwitz stable two-dimensional systems. Their
column sums are respectively `(-1,-2)`, `(-3,-4)`, `(-3/2,-1)`, and `(-2,-9/2)`.
They can consequently be interpreted as two compartments with nonnegative
transfer and loss rates. A common mass-loss bound also makes arbitrary switching
in this example contractive in the positive 1-norm. No biological mechanism is
inferred from this mathematical interpretation.

The separate similarities are

\[
S_A=\operatorname{diag}(1,1/2),\quad A'=S_AAS_A^{-1},\qquad
S_B=\operatorname{diag}(1,2),\quad B'=S_BBS_B^{-1}.
\]

Both `S_A` and `S_B` fix `e1`, preserve the output row, and commute with `A0`.
It follows from ODE uniqueness that all accessible experiments agree between
the two worlds, including switching arbitrarily between baseline and one
intervention and applying arbitrary input waveforms.

Each isolated intervention is controllable and observable from this port:
the controllability determinant is its positive lower-left entry and the
observability determinant is its positive upper-right entry. The ambiguity is
therefore not attributable to an unobservable state within an isolated mode.

### The sequential operation differs

Let

\[
q_{AB}(\tau)=e_1^\top e^{B\tau}e^{A\tau}e_1
\]

denote A first and B second, with no input between preparation and readout;
define `q_BA` by reversing the order. World 1 has `AB=BA`, so both orders agree.
World 2 instead satisfies

\[
q'_{BA}(\tau)-q'_{AB}(\tau)
=3e^{-7\tau}\sinh^2\!\left(\frac{\sqrt5\tau}{2}\right)>0
\quad\text{for every }\tau>0.                              \tag{2}
\]

An exact derivation avoids numerical matrix-exponential evidence. Write
`lambda=sqrt(5)/2`, `h=cosh(lambda*tau)`, `z=sinh(lambda*tau)/lambda`, and

\[
M=\begin{pmatrix}1/2&1\\1&-1/2\end{pmatrix},\quad
M_A=\begin{pmatrix}1/2&2\\1/2&-1/2\end{pmatrix},\quad
M_B=\begin{pmatrix}1/2&1/2\\2&-1/2\end{pmatrix}.
\]

All three squares equal `(5/4)I`. Therefore each centered exponential is
`h I+z M_i`. The top-left entries of `M_B M_A` and `M_A M_B` are `1/2` and
`17/4`. Their difference is `15/4`, and multiplying by `z^2 e^(-7 tau)` gives
(2). More explicitly, if

\[
q_0=e^{-7\tau}\left[\cosh(\sqrt5\tau)
                +\frac{1}{\sqrt5}\sinh(\sqrt5\tau)\right],
\]

then

\[
q_{AB}=q_{BA}=q_0,\qquad
q'_{AB}=q_0-\tfrac35 e^{-7\tau}\sinh^2(\lambda\tau),\qquad
q'_{BA}=q_0+\tfrac{12}{5} e^{-7\tau}\sinh^2(\lambda\tau).
\]

The order difference begins at `(15/4) tau^2`. At the single illustrative value
`tau=0.2`, it is about `0.0376`; this is a value of the proven formula, not an
empirical result or a fresh evaluation case.

There cannot be a common similarity for both modes. Such a similarity would
imply `B'-A'=S(B-A)S^-1=-2I`, which is false.

Two hidden dimensions are minimal for this form of example. In dimension one,
a known nonzero input/output port and all isolated-mode responses determine each
scalar generator, and scalar flows commute. This minimality claim is restricted
to the stated linear model and access contract.

### Consequence for any learner

No estimator, representation learner, retained program library, or computation
using only the accessible experiments can decide the order-dependent output
across these worlds. Repeating isolated-action experiments with arbitrarily
good precision does not resolve the ambiguity. A mixed-action experiment, a
calibrated new port, or an independently warranted relation between the
interventions is necessary. A mixed-action experiment is an acquisition cost,
not a free compositional interface.

## 4. Positive common-intertwiner theorem

Let two switched linear systems have generators `{A_a}` and `{Atilde_a}`, common
input/output matrices `(D,C)` and `(Dtilde,Ctilde)`, and initial states `x0` and
`xtilde0`. If one invertible matrix `S` satisfies

\[
\widetilde A_a S=S A_a\ \text{for every }a,\qquad
\widetilde D=SD,\quad \widetilde C S=C,\quad
\widetilde x_0=Sx_0,                                       \tag{3}
\]

then every switched input-output experiment agrees. To prove this, set
`xtilde(t)=Sx(t)`. On every mode interval it satisfies the second ODE, including
the input term; it matches initial conditions and remains continuous across
switches. ODE uniqueness gives equality, and the output equation in (3)
finishes the proof. Equivalently, exponentials satisfy
`exp(Atilde_a t)S=S exp(A_a t)` and these identities compose.

For minimal jointly reachable and observable representations, a converse holds.
Include `x0` as an extra column of `D` if needed. For a word
`w=(a1,...,ak)`, put `A_w=A_ak ... A_a1`, with `A_empty=I`. Suppose every word
Markov parameter agrees:

\[
C A_w D=\widetilde C\widetilde A_w\widetilde D.
\]

Define `S` on reachable vectors by

\[
S\!\left(\sum_j A_{w_j}D v_j\right)
  =\sum_j\widetilde A_{w_j}\widetilde Dv_j.
\]

If the left argument is zero, applying any output continuation word to the
right gives zero by equality of the concatenated Markov parameters.
Observability of the second realization makes the right vector zero. Thus
`S` is well-defined. Reversing the argument shows injectivity; reachability
shows surjectivity. Appending a mode proves `S A_a=Atilde_a S`, and the empty
word gives the input/output relations. Hence a common invertible `S` exists.

This is a specialization and elementary proof of classical switched realization
theory, not a new theorem claimed by P3. In continuous time, equality of all
switched outputs implies equality of generator word parameters by differentiating
hold times at zero. That implication is a mathematical argument; measuring
those derivatives accurately is a separate experimental problem. See primary
sources S5 and S6 in `SOURCES.json`.

## 5. Finite-time acquisition of relative alignment

The two-compartment class gives a derivative-free construction. Suppose the
unknown mode `i` has

\[
A_i=\begin{pmatrix}-a_i&b_i\\c_i&-d_i\end{pmatrix},\qquad
p_i=b_i c_i>0,\qquad a_id_i>p_i.
\]

An exact isolated transfer identifies `a_i,d_i,p_i` but not `b_i,c_i` separately.
Define

\[
\mu_i=(a_i+d_i)/2,\quad
\lambda_i=\sqrt{(a_i-d_i)^2/4+p_i},\qquad
L_i(t)=e^{-\mu_i t}\frac{\sinh(\lambda_i t)}{\lambda_i},
\]

and retain the acquired isolated response `g_i(t)=(exp(A_i t))11`. The full
exponential has off-diagonal entries `b_i L_i(t)` and `c_i L_i(t)`. One
finite-time mixed protocol therefore obeys

\[
q_{ij}(s,t)=e_1^\top e^{A_j s}e^{A_i t}e_1
 =g_j(s)g_i(t)+L_j(s)L_i(t)b_jc_i.                         \tag{4}
\]

For positive dwell times the denominator is nonzero, so this experiment
acquires the new cross quantity

\[
\rho_{ij}=b_jc_i
 =\frac{q_{ij}(s,t)-g_j(s)g_i(t)}{L_j(s)L_i(t)}.             \tag{5}
\]

It does not identify an absolute hidden-state scale. Nevertheless,
`rho_ij/p_i=b_j/b_i`. If there are K modes and measured pairs form a connected
graph, K-1 edges of a spanning tree determine all relative ratios; choose an
arbitrary positive reference `b_1`, propagate the ratios, and set
`c_i=p_i/b_i`. The remaining common scaling is harmless for all switched
output predictions. The recovered realization can predict every dwell time,
order, and sequence under the assumed class. A newly acquired mode needs its
isolated dynamics plus one connecting mixed experiment, rather than a complete
catalogue of all protocols. This is the precise sense in which a representation
is learned, reused, and extended in this class.

This construction is an accessible special case of existing basis alignment.
The original scientific task still has to warrant the shared two-state switched
model, the known port, reproducible preparation, and the intervention's
time-independent generator. A finite success does not establish those promises
outside the tested domain.

### Precision and acquisition costs

Equation (5) is not a cost-free algebraic oracle. Even if the old single-mode
quantities were exact, an output error `eta` induces a cross-quantity error
`eta/|L_j(s)L_i(t)|`. If each independent measurement has zero-mean
sigma-sub-Gaussian noise, N repetitions suffice for error at most `epsilon`
in `rho_ij` with probability at least `1-delta` when

\[
N\geq \frac{2\sigma^2}{\epsilon^2L_j(s)^2L_i(t)^2}
        \log\frac{2}{\delta}.                             \tag{6}
\]

This assumes independent repeatable noise; bias, preparation drift, and class
mismatch are not covered. If old `g_i,g_j` have bounded errors `e_i,e_j`, the
numerator uncertainty includes
`|g_j|e_i+|g_i|e_j+e_i e_j`, in addition to new-readout error. Errors in the
estimated `L` factors must also be propagated and their denominators bounded
away from zero. Isolated-model fitting, replication, rank/model selection,
timing, and cross-edge alignment all cost work.

Very short holds have `L_i(t)~t`, causing quadratic signal suppression. Very
long holds also lose signal in stable systems. Mixed protocols should therefore
be designed for finite signal, not sent to an infinitesimal derivative oracle.
Multiplicative ratio uncertainty can grow along graph paths; a spanning-tree
count alone is not a confidence or precision guarantee.

## 6. Prior, application boundary, and recommendation

Primary prior directly solves the generic alignment problem. Bencherki,
Turkay, and Akcay's `arXiv:2106.10888v3` identifies different local state bases,
derives basis corrections from mixed input-output data under excitation and
model assumptions, and uses graph connections. Retaining subspace or switched
identification is consequently an equally informed baseline that can execute
the same update. No architectural or sample-efficiency advantage has been
established here. See S7; the earlier source discussed there is Verdult and
Verhaegen, CDC 2004, DOI `10.1109/CDC.2004.1429336`.

The externally motivated task is prediction of order-dependent perturbations
in partially observed signaling systems. S1 describes a retained, partially
identifiable signaling representation but excludes sequential applications;
S2 provides actual measured order effects and a strong retained statistical
predictor. Our two-state linear result isolates a logically possible missing
interface; it does not explain the biology in those sources. A useful next
attack must beat task-directed direct experimental prediction and retained
switched-system identification on equal data and access, while requiring less
than an unsupported full biological realization.

The strongest continuation is to seek a task-specific, finite-noise partial
alignment that supports a consequential new prediction without acquiring a
full switched realization. Its novelty and practical advantage are UNKNOWN.
The present construction rejects an overclaim and identifies a real acquisition
operation. It does not by itself substantiate cumulative scientific intelligence.

## 7. Verification and exposure

`exact_joint_gauge_check.py` checks all rational similarities, port identities,
stability/positivity criteria, local minimality, the obstruction to a common
similarity, and the centered exponential coefficients. The hyperbolic formula
then follows analytically. `exact_joint_gauge_result.json` records the run.

All matrices were authored during exploratory reasoning and inspected before
execution. There are no unseen evaluation cases, empirical measurements, or
benchmark claims. Old P3 bundles were not changed. This exact proof check is
the only execution in this subtask beyond workspace inspection and file work.
