# Atomic-return kernels from incomplete positive-system observations

Private P3 theoretical continuation, 23 October 2026. No empirical benchmark
or physical measurement was performed. Root proposed the endpoint-renewal
attack and strengthened the dictionary condition to arbitrary finite
factor-closed libraries. This note supplies proofs, noisy-access limitations,
a short-observation access separation, and physical-interface boundaries.

## Main scoped result

For an unknown-dimension controlled substochastic system with a genuinely
atomic regenerative reset/readout port, exact endpoint responses on a finite
factor-closed dictionary determine a finite first-return kernel. Its renewal
closure is the **simultaneously sharp lower envelope for every unqueried
word**, over every compatible hidden dimension. A finite prefix-history
realization attains the envelope for all words at once.

This improves the maximum retained-block product certificate by summing
disjoint return histories. It does not improve an equally informed renewal
or positive weighted-automaton implementation: that baseline computes the same
object. Full identification and a known rank/dimension are unnecessary for
this lower-bound operation. Atomic regeneration remains a real access promise.

Endpoint noise, directly observed first-return noise, and the physical cost of
seeing returns are different contracts. In particular, confidence regions that
throw away total return mass can destroy useful long-horizon certificates.

## 1. Contracts and notation

Let Sigma be a finite action alphabet. An unknown number n of hidden states
supports a row-substochastic matrix P_a for every action a:

    P_a(i,j)>=0,  sum_j P_a(i,j)<=1.

Missing row mass is killing/loss. A non-port cemetery state makes every matrix
stochastic if desired. No n or hidden matrix entry is supplied to the learner.
The same actions act on a common physical source throughout the acquisition
and prediction phases. They have no unmodelled dependence on earlier actions,
source age, experimental batch, or external history.

There is one known atomic port, state 1. Each trial resets to that state, and
the endpoint readout tests exactly membership in that state. For a word
w=a_1...a_t,

    q(w)=e_1^T P_{a_1}...P_{a_t} e_1,  q(empty)=1.

An endpoint observation is a Bernoulli return indicator for one independent
trial. A concentration measurement needs its own calibrated noise model and
does not automatically inherit Bernoulli trial counts.

"Atomic" means that arrival at the readout port restores exactly the same
future conditional law as initial preparation. It is stronger than an
observable fluorescence level or a set of hidden states with the same label.
It is weaker than knowing all hidden states or their count.

Fix a finite dictionary D containing the empty word. It is factor-closed:
every contiguous subword of a word in D also belongs to D. Let

    N=|D|-1,  L=max_{v in D}|v|.

The complete dictionary of all words through length L is one option, with
N=sum_{j=1}^L |Sigma|^j, but is not required. A dictionary containing the short
factors of specified protocol families can be much smaller. Acquiring any
missing factors needed to close a retained library is an additional cost.

## 2. Noncommutative first-return identity

For a nonempty word w of length t, define f(w) as the probability of being at
the port at step t while avoiding the port at steps 1,...,t-1, starting from
the port. The actions remain those in w. These probabilities are nonnegative.
For each fixed word v, its first-return prefix events are disjoint, so

    sum_{nonempty prefixes u of v} f(u) <= 1.             (1)

Partition the endpoint-return event according to its first positive return.
At that return the source regenerates at the same atomic port. Therefore

    q(w) = sum_{w=uv, u nonempty} f(u) q(v).             (2)

The empty suffix term is f(w). Thus exact q on D determines f on D by
increasing length:

    f(w)=q(w)-sum_{w=uv, u,v nonempty} f(u)q(v).         (3)

Factor closure supplies every prefix and suffix used here. In noncommutative
formal-series notation, Q=1+FQ, so Q=F*=sum_{j>=0}F^j and F=1-Q^{-1}.
These are formal identities: each word coefficient has only finitely many
contributing compositions, and analytic convergence is not assumed.

## 3. Sharp lower-envelope theorem

**Theorem.** Suppose exact values q on finite factor-closed D are compatible
with at least one atomic-port substochastic system of any finite dimension.
Compute f on D by (3), and define the truncated first-return series

    f_D(v)=f(v) if v in D and v nonempty; otherwise 0.

For every word w define

    B_D(w) = sum_{w=v_1...v_m, v_j in D nonempty}
                    product_j f(v_j),
    B_D(empty)=1.                                       (4)

Then:

1. Every compatible source satisfies q_source(w)>=B_D(w) for every w.
2. A finite substochastic source with the same atomic port and exactly the
   same retained q on D satisfies q_min(w)=B_D(w) for every w simultaneously.
3. Consequently no method using only this retained exact information and this
   source class can universally certify a larger lower value at any target w.

### Lower-bound proof

For any complete hidden path ending at the port, mark all positive times at
which it visits the port. Consecutive marked times decompose the action word
into its first-return excursions. This decomposition is unique. The weight of
a fixed sequence of excursions is the product of the corresponding f values,
by atomic regeneration. Summing only those paths whose excursion words lie
in D produces (4). The omitted paths have nonnegative weight. Distinct return
patterns are disjoint; there is no union-bound subtraction or double counting.

Equivalently, F_D<=F coefficientwise and every star coefficient is a polynomial
with nonnegative coefficients, hence F_D*<=F*.

### Attaining prefix-history realization

The construction below also proves a finite-data compatibility criterion.
For each v in D set

    s(v)=1-sum_{nonempty prefixes u of v} f(u),
    s(empty)=1.

Create a port state indexed by empty, and a history state for each nonempty
v in D. A history records the actions since the most recent port visit along
an excursion that has not returned. For state v with s(v)>0 and action a:

- If va belongs to D, return to the port with probability f(va)/s(v), and
  continue to history state va with probability s(va)/s(v).
- If va does not belong to D, kill the mass.

For a state with s(v)=0 choose the zero row. Such a state is unreachable on an
unreturned excursion. When va is in D,

    f(va)+s(va)=s(v),

so each defined row is stochastic, and the remaining rows are substochastic.
The same rule at v=empty starts each excursion. Leaves may retain nonreturn
mass until the next action, when it is killed; killing that leaf mass
immediately instead gives the same port responses.

By induction, an excursion following v has unreturned mass s(v). Its return
mass at the next retained word va is exactly f(va). It has zero first-return
mass at every off-D word. Thus the constructed source has first-return law
F_D and endpoint series F_D*.

For v in D, every block of every composition of v belongs to D, by factor
closure. The original renewal identity therefore gives B_D(v)=q(v). The
constructed source matches every retained observation and attains B_D on all
longer words at once. It uses at most |D| states plus an optional cemetery.

### Finite-data compatibility, not global class recognition

An exact table q with q(empty)=1 on factor-closed D has some finite atomic-port
substochastic realization if and only if the deconvolved f is nonnegative
and satisfies (1) on D. Necessity follows from first returns; sufficiency is
the trie construction.

This check establishes compatibility of a finite table. It does NOT establish
that an unknown physical source is globally regenerative/atomic or that its
future action law remains unchanged. A source outside the promised class can
match every retained observation. Section 11 gives an exact example.

Additional promises can change the envelope. A known hidden dimension,
irreducibility, a specified reaction topology, or a no-loss guarantee with
further connectivity restrictions is extra information. The theorem concerns
the stated unrestricted-dimensional substochastic class and claims no upper
envelope. Row-stochasticity alone does not defeat the construction because a
nonreturning cemetery state can absorb the otherwise killed mass.
Strictly positive matrices or quantitative mixing constraints are stronger
classes: the constructed zeros and killing do not establish exact attainment
there. Finite-data compatibility also does not force eventual transience.

## 4. Domination of the retained-block product

For a partition w=v_1...v_m into retained words, the quantity

    product_j q(v_j)

is the probability of being at the port at those selected block boundaries.
It is a valid lower bound on endpoint return. Expand each q(v_j) into its
first-return compositions. All resulting first-return blocks lie in D by
factor closure, and all these path patterns appear in (4). Therefore

    B_D(w) >= max_{partitions into D} product_j q(v_j).  (5)

Strict inequality is possible. For a single action with

    P = [[1/2,1/2],[1,0]],  D={empty,a,aa},

the retained values are q(a)=1/2 and q(aa)=3/4, so f(a)=f(aa)=1/2. At aaa,

    B_D(aaa)=1/8+1/4+1/4=5/8,
    max retained-block product = (1/2)(3/4)=3/8.

This is an exact witness to strict dominance, not a statistical benchmark.
An equally informed renewal/weighted-automaton baseline obtains 5/8 too.

No mixed-action information is free. If D contains only pure-a and pure-b
words, the construction cannot infer unmeasured mixed first-return kernels
such as f(ab). The sharp theorem makes this limitation explicit. Mixed words
in D can support lower bounds for new orders and longer compositions, without
requiring the entire hidden operators to be aligned or identified.

## 5. Computation and finite precision

Deconvolution uses O(sum_{v in D}|v|) arithmetic operations, plus dictionary
construction/checking and the actual measurement costs. Naive string slicing
can add another length factor; stored prefix/suffix references avoid it.

For a target w of length T, let H_T=1 and process suffix positions backwards:

    H_i = sum_{j>i: w[i:j] in D} f_D(w[i:j]) H_j.        (6)

Then H_0=B_D(w). A dictionary trie scans at most L symbols from each position,
giving O(TL) matching work and arithmetic operations. A hidden-state matrix
representation need not be constructed to evaluate the certificate.

These are arithmetic counts, not constant-cost exact-real claims. Exact
rational numerators and denominators can grow with T. A practical certified
implementation can use downward-rounded dyadic lower coefficients f^- and
the backward recursion. At each position its coefficient sum is at most one,
by (1). If the complete local sum is rounded downward with error at most rho,
the propagated error is at most T*rho: the error recursion is bounded by rho
plus a convex subcombination of later errors. Products can be accumulated
exactly at twice the fixed dyadic precision before one downward rounding.

Rounding each of at most L coefficients down by rho adds at most TL*rho to
the value loss. Thus O(log(TL/epsilon)) fractional bits suffice for an
epsilon rounding-loss budget, beyond the precision needed to acquire those
coefficients. The returned number remains a lower certificate. This says
nothing about how close B_D is to the true response when unobserved excursions
carry substantial mass.

## 6. Direct first-return intervals

The reference implementation `atomic_return.py` uses exact rational arithmetic
for deconvolution, the prefix-history attainer, the O(TL)-step target trie,
the noisy inverse certificate and directed dyadic rounding. Running
`python atomic_return.py` completed successfully; `ATOMIC_CHECK.json` preserves
the two algebraic witnesses: exact 5/8 versus 3/8 dominance, and noisy
0.704969 versus 0.712 loss of dominance. These are proof checks, not empirical
performance or transfer tests. The reference deconvolution uses tuple slicing,
so its extra dictionary/key preprocessing costs are stated in the module.

Suppose direct observations provide jointly valid bounds

    0<=ell(v)<=f(v)<=u(v),  v in D nonempty.

Conditional on that confidence event, set f^-(v)=ell(v) on D and zero
elsewhere. Positivity and prefix mass remain valid because they only decrease.
The trie realization gives the following exact conclusion:

**The coordinatewise-lower renewal series (F^-)^* is the simultaneous sharp
lower envelope under these first-return interval constraints alone.**

It fits all intervals whenever they are jointly feasible. The upper endpoints
do not force any larger coefficient, and unmeasured first returns can be zero.
This claim does not include extra retained endpoint constraints, shared
normalization information or other observations; those must also be used by
the strongest baseline and can improve the robust lower bound.

For direct acquisition, a first-return-terminated trial along a maximal
dictionary word supplies a categorical outcome: the first-return prefix, or
no return by its end. Trials along a shared action prefix can be pooled for
that prefix's event probability. One simple design repeats every maximal
prefix word m times and uses union-bound confidence across all retained
prefixes. Its trial count is m times the number of such maximal words, with
at most their total repeated lengths in action/readout cost. Earlier stopping
can reduce duration. Full monitored trajectories past returns give additional
information that a retaining estimator must be allowed to exploit.

Coordinatewise intervals are sometimes unnecessarily destructive: lowering
every first-return bin independently can invent a large loss of total return
mass. Section 9 quantifies this obstruction and a joint-confidence repair.

## 7. Endpoint-only noise: certified but coupled

Suppose independent endpoint measurements supply simultaneous intervals

    q(v) in [qhat(v)-eta(v), qhat(v)+eta(v)],  v in D,
    qhat(empty)=1, eta(empty)=0.

For N endpoints with m independent Bernoulli trials each, a simple sufficient
uniform radius is

    eta=sqrt(log(2N/delta)/(2m)).                         (7)

Actual cost is Nm source resets and m*sum_{v in D}|v| action applications,
plus readout, reset fidelity and controls. This confidence calculation is
separate from recognition of the atomic-port input contract.

Direct interval subtraction in (3) is valid when performed with correct
dependencies bounded outward, but may become very conservative. Naively
expanding the inverse into signed compositions suggests exponentially many
error terms. Positivity yields a better computable certificate.

Compute fhat by formal deconvolution of qhat, allowing negative values. Let

    E(w)=eta(w)+sum_{w=uv, u,v nonempty} eta(u)|fhat(v)|,
    B(w)=E(w)+max_{proper nonempty suffix v of w} E(v),  (8)

with the maximum zero for a one-letter word. Then on the endpoint confidence
event,

    |f(w)-fhat(w)|<=B(w),
    f^-(w)=max(0,fhat(w)-B(w)) <= f(w).                 (9)

### Proof of (8)-(9)

In formal-series notation set Delta Q=Q-Qhat. The inverse identity gives

    F-Fhat=(1-F)(Q-Qhat)(1-Fhat).                       (10)

Let R=Delta Q*(1-Fhat). Its coefficient at w has magnitude at most E(w).
The coefficient of (1-F)R at w is R(w) minus a sum over proper first-return
prefixes u, with nonnegative weights f(u) and suffix values R(v). Their
weights sum to at most one by (1). This proves (8)-(9). All needed factors
belong to D. No fitted hidden model or nonconvex feasibility solver is used.

The bound is data-dependent and can still be large on poorly determined
tables. If all radii are eta<=1/(4L), it has a coarse polynomial uniform
bound: max_D |fhat|<=3 and B(w)<=6L eta. To see this, call the maximum M;
from (8), |f-fhat|<=2eta(1+LM), while 0<=f<=1. Hence

    M<=1+2eta(1+LM),
    M<=(1+2eta)/(1-2Leta)<=3.

The stated bound on B follows. This removes a naive exponential stability
claim but does not make precision independent of horizon or dictionary size.

### What is and is not sharp with endpoint intervals

The robust sharp lower envelope is a finite optimization over first-return
coefficients f on D satisfying

    f>=0;  all prefix sums<=1;
    lower_q(v)<=F^*(v)<=upper_q(v) for every v in D.

For a target w minimize F^*(w) over that feasible set, with off-D coefficients
zero. The trie realization proves exactness of this characterization. The
feasible set is compact, but the endpoint conditions and target objective
are polynomial and coupled. Efficient global optimization is NOT established
here; its search cost cannot be omitted.

The coordinate certificate (9) is cheap and sound but generally not sharp
under those endpoint constraints. It can even lose (5) against block products
using the retained endpoint lower bounds. For example, qhat(a)=0.9 and
qhat(aa)=0.81 with radius 0.01 give f^-(a)=0.89 and f^-(aa)=0. Then its aaa
bound is 0.89^3=0.704969, while the retained-block bound is
0.89*0.80=0.712. Both intervals contain the valid one-state source P=0.9.

A safe implementation returns at least the maximum of the renewal
certificate and the strongest available block certificate. Mixed recurrences
can use max between sound decompositions; overlapping decompositions cannot
simply be added. Under exact endpoints the sharp theorem restores dominance.

On the single finite-dictionary confidence event, every lower first-return
coefficient is valid. Positivity then certifies its renewal lower bounds for
ALL finite future words simultaneously, including words selected after the
data and arbitrarily long words. No extra union bound over target words is
needed for this one-sided statement. It does not promise a useful or accurate
bound at every length: the value can become zero or very conservative.

## 8. Precision can control the useful horizon

If true retained coefficients f and lower coefficients g have differences
with prefix sums bounded by d_i along the target starting at position i,
the backward recurrence gives

    B_f(w)-B_g(w) <= sum_{i=0}^{T-1} d_i.               (11)

Indeed, split each difference into the local coefficient loss, bounded by
d_i because later response values lie in [0,1], plus a subconvex combination
of later errors. Uniform coefficient error epsilon_f gives the coarse bound
TL*epsilon_f. More precise joint uncertainty can be substantially better.

Even with exact coefficients, a finite dictionary may contain only a defective
return kernel. For a single action, if sum_{j<=L} f(a^j)<1, its finite-support
renewal lower bound generally decays with T, although the true process may
return through long unobserved excursions and retain positive late response.
The sharpness theorem says this uncertainty cannot be repaired from the same
retained endpoint information alone. New acquisition or additional physical
structure is required.

## 9. A rigorous noisy-access separation and its limit

This is a theoretical access comparison, not an empirical benchmark and not
an architectural separation. For one action let

    P_gamma = [[1/2,1/2],[1-gamma,0]],  0<=gamma<=1.

Its first-return law has f_1=1/2, f_2=(1-gamma)/2 and no later returns; the
remaining first-return mass is killed. Endpoint values are

    q_1=1/2, q_2=3/4-gamma/2,
    q_t=(1/2)q_{t-1}+((1-gamma)/2)q_{t-2}.             (12)

### Finite-T long-response separation

For T>=6 compare gamma=0 with gamma=3/T. The exact solution is

    r_plus=(1+sqrt(9-8gamma))/4,
    r_minus=(1-sqrt(9-8gamma))/4,
    A_gamma=1/2+1/(2sqrt(9-8gamma)),
    q_T=A_gamma*r_plus^T+(1-A_gamma)*r_minus^T.         (13)

At gamma=0, q_T=2/3+(1/3)(-1/2)^T. For gamma<=1/2,

    A_gamma <= 1/2+1/(2sqrt(5)),
    r_plus <= 1-gamma/3, |r_minus|<=1/2.

The r_plus inequality follows from concavity of sqrt at 9. Consequently for
gamma=3/T,

    q_T(0) >= 2/3-(1/3)2^-T,
    q_T(3/T) <= [1/2+1/(2sqrt(5))]/e + 2^-T.           (14)

For every T>=6 the difference is at least

    31/48 - [1/2+1/(2sqrt(5))]/e > 3/8.                (15)

The null value exceeds 0.66 and the alternative is below 0.29. These are
finite-T inequalities, not only an asymptotic limit. The asymptotic alternative
is (2/3)exp(-1), consistent with (13).

### Bounded-length endpoint access needs quadratic trial count

Suppose only endpoint trials of length at most 2 are available. A one-step
trial has the same Bernoulli law under both hypotheses. A two-step trial has
probabilities p=3/4 and p'=3/4-gamma/2. For gamma<=1/2,

    KL(Ber(p)||Ber(p'))
      <= (p-p')^2/[p'(1-p')] <= (4/3)gamma^2.           (16)

The first inequality follows from log(x)<=x-1; the denominator is at least
3/16. Chain rule therefore bounds transcript KL for m adaptive independent
short endpoint trials by (4/3)m gamma^2. If a test has error at most delta
under both hypotheses, binary data processing gives

    m >= [3/(4gamma^2)] (1-2delta)log((1-delta)/delta)
      = [T^2/12] (1-2delta)log((1-delta)/delta),         (17)

for gamma=3/T and 0<delta<1/2. Constant-accuracy prediction or certification
that separates the long responses in (15) therefore needs Omega(T^2) short
endpoint trials. This bound applies to every equally informed method.

### Direct return observation exposes the rare defect

A directly monitored, first-return-terminated two-step trial has outcomes

    R=1 with probability 1/2,
    R=2 with probability (1-gamma)/2,
    R>2 with probability gamma/2.                       (18)

Under the null no defect R>2 is ever seen. Under gamma=3/T the probability of
seeing no defect in m trials is (1-3/(2T))^m<=exp(-3m/(2T)). Thus
m>=(2T/3)log(1/delta) distinguishes the hypotheses with false-positive rate
zero and false-negative rate at most delta. This uses an additional temporal
observation within each short trial; the benefit belongs to acquisition.

### A valid long-response certificate needs joint mass information

Separate lower confidence bounds on f_1 and f_2 introduce an artificial mass
deficit of order m^-1/2, losing the O(T) acquisition benefit. Instead retain
the censored-return distribution. Let s=f_1+f_2 and d=1-s. After zero defects
in m trials, a valid one-sided bound at failure probability delta_1 is

    d <= 1-delta_1^(1/m) <= log(1/delta_1)/m.           (19)

Use a separate binomial lower bound on f_1. For any nonnegative f_1,f_2 with
s<=1, the two-term renewal sequence satisfies

    B_T >= f_1*s^(T-1),  T>=1.                          (20)

Proof: normalize the two return weights by s. The normalized renewal
sequence has initial values 1 and f_1/s, and its recurrence is a convex
combination, so every value is at least f_1/s. Every composition contributing
at time T has at most T return factors, and s^number_of_factors>=s^T.
This proves (20); s=0 is immediate. Direct induction is equivalent.

For an explicit constant certificate under gamma=0, set delta_1=delta/2 and
let a=sqrt(log(2/delta)/(2m)). Use f_1^- = max(0,f_1_hat-a) and s^- from
(19). If

    m >= max{4T log(2/delta), 200 log(2/delta)},         (21)

then with probability at least 1-delta/2 under the null, f_1^->=0.4, while
s^->=1-1/(4T). Equations (20) and Bernoulli's inequality certify

    q_T >= f_1^-*(s^-)^(T-1) >= 0.3.                  (22)

The certificate has failure probability at most delta for every source in the
atomic-port class, not only this two-state family: unobserved later returns
are nonnegative and can be omitted. The finite-T alternative in (14) is below
0.29, so it cannot reliably receive this certificate. The construction uses
O(T log(1/delta)) short trials, with at most twice that many action steps and
port observations. It preserves total return mass rather than lowering each
bin independently. An ordinary retaining multinomial/renewal method obtains
exactly this guarantee.

### Direct long experiments remove a broad efficiency claim

If length-T endpoint trials are available, directly measuring q_T to fixed
absolute accuracy uses O(log(1/delta)/epsilon^2) source resets, independently
of T, and O(T log(1/delta)/epsilon^2) action/time cost. For the constant gap
above this is O(1) resets and O(T) pulses at fixed confidence. The first-return
procedure uses O(T) resets and O(T) pulses. It therefore has no newly efficient
one-target advantage over unrestricted direct experimentation and may be worse
when resets are costly.

The strict advantage in (17)-(22) is against the bounded-length endpoint-only
interface. It can matter if long continuous experiments are unavailable, or
if a short library supports many later protocol certificates. A concrete
scientific application must establish those costs and restrictions; they are
not established by this mathematical family.

## 10. Strongest retaining and identification baselines

| Information/access | Strong equally informed method | Conclusion |
|---|---|---|
| Exact q on factor-closed D | Deconvolve f; positive renewal/weighted-automaton star | Exact tie with the theorem's construction |
| Exact q, but max-product blocks only | Optimize retained block boundaries | Can be strictly weaker because it selects one set of required returns |
| Noisy endpoint intervals | Optimize over all compatible retained first-return kernels | Sharp characterization; global computational efficiency unknown |
| Noisy endpoint intervals, cheap computation | Deconvolution bound (8), block DP, and max of sound bounds | Certified conservative baseline; no false exact-noise dominance claim |
| Direct first-return records | Retain multinomial dependence and total mass; renewal bounds | Preserves rare-defect benefit; coordinatewise intervals can waste it |
| Full monitored trajectories | Retain every excursion and all endpoint observations | More information; it must be allowed to use all of it |
| Known small rank/dimension and sufficient experiments | Positive realization, weighted automata, system identification | May give two-sided/exact responses; its rank/interface warrant and acquisition are extra inputs |
| Direct long endpoint trials | Estimate the actual long response | Often strongest for one available target; included in cost comparison |

No worker architecture or library-learning advantage is claimed. The useful
operation is a sharp one-sided extrapolation under a partial information
contract, with no hidden-dimension promise. It should be compared to renewal
methods, not only a weakened cached-product learner.

## 11. Physical obtainability and an exact recognition obstruction

### A plausible class, without a claim of an acquired physical example

Closed unimolecular conversion networks let a single molecule move between
chemical species according to a Markov generator. Loss reactions produce
substochastic evolution. A fixed-duration control pulse has matrix
P_a=exp(G_a*tau_a). Initial preparation of a known species and a species-selective
endpoint measurement can then supply q(w) without learning G_a or the number
of intermediate species. The conversion-only model must be warranted; general
first-order catalytic production, source injection, nonlinear interactions,
spatial memory and hidden conformations are not automatically covered.

Gadgil, Lee and Othmer derive the single-molecule random-walk and matrix
exponential description for closed first-order conversion networks in
Section 4.1.1. That supplies an external substantive scientific class, not a
verified experimental implementation of the reset/readout interface used here.

There is a further distinction: the trie attainer is an arbitrary switched
substochastic system and generally has zero or singular matrices. It need
not admit P_a=exp(G_a*tau_a) with finite continuous-time generators. Thus the
lower bound applies to the unimolecular continuous-time subclass, but exact
sharpness has only been proved for the broader substochastic class. A strong
physical baseline may exploit embeddability, known topology or other warranted
kinetic constraints. The discrete two-state access-separation witness likewise
is not asserted to be a fixed-duration unimolecular CTMC pulse.

### A coarse observable port is insufficient

For any finite L, take a deterministic hidden chain with states
0,1,...,L+1, initial state 0, and one action advancing along it. Label states
0,...,L as the same observed "port" and state L+1 as non-port. Its observed
endpoint table is q(a^j)=1 for every j<=L, matching the genuine one-state
absorbing port exactly. Deconvolution gives f(a)=1 and f(a^j)=0 for 2<=j<=L,
so the atomic-port theorem would predict lower bound 1 at a^(L+1).
The coarse-port source actually gives zero there.

Every finite compatibility check passes. The failure is not hidden dimension
alone: it is lack of regeneration at the observed label. This is why the
physical port condition cannot be inferred from a short table.

Single-enzyme data make this concern scientifically concrete. English et al.
observed correlated turnover activity and interpreted molecular memory through
interconverting conformers. A detected reaction product or a chemically named
"regenerated enzyme" therefore does not by itself establish an atomic reset
of all kinetically relevant state. Their experiment is a caution about the
interface, not evidence that the theorem's exact atomic contract was obtained.

### Engineered reset is a possible stronger access mechanism

After detecting a return event, an intervention can deliberately replace or
prepare the source in a validated common initial distribution. If that reset
erases all relevant history, excursions become regenerative by construction.
This can support a first-return library without identifying the internal
dynamics. It requires intermediate event detection and a reset-fidelity
warrant. It also changes the scientific task: predictions are for the
reset-assisted process, not automatically the original uninterrupted source.
Endpoint-only measurements of the original source do not magically become
first-return data for this modified process.

Approximate reset can be useful with a quantified error per regeneration, but
the error can accumulate over the horizon. A finite table alone cannot certify
that arbitrary unseen histories were erased. Experimental calibration should
be targeted to the actual repeated operation rather than assumed from a name.

## 12. Sources, prior scope and remaining uncertainty

Primary sources read:

- Robert Gallager, *Discrete Stochastic Processes*, Chapter 4, Example 4.1.1
  and the renewal equations. The standard regenerative decomposition is prior
  machinery. https://ocw.mit.edu/courses/6-262-discrete-stochastic-processes-spring-2011/931ffa0940899c27f34b71ad64fd2bb0_MIT6_262S11_chap04.pdf
- Francois Denis and Yann Esposito, *Rational stochastic languages*,
  arXiv:cs/0602093v1 (2006), Section 2.1. It defines the noncommutative Cauchy
  product, star and linear representations. Our controlled q is a response
  series, not generally a normalized distribution over all input words.
  https://arxiv.org/pdf/cs/0602093
- Chetan Gadgil, Chang Hyeong Lee, Hans G. Othmer, *A stochastic analysis of
  first-order reaction networks*, Bulletin of Mathematical Biology 67 (2005),
  901-946, Section 4.1.1, equations (51)-(52).
  https://pmc.ncbi.nlm.nih.gov/articles/PMC6388624/
- Brian P. English et al., *Ever-fluctuating single enzyme molecules:
  Michaelis-Menten equation revisited*, Nature Chemical Biology 2 (2006),
  87-94, DOI 10.1038/nchembio759. The author-hosted PDF includes a correction
  to an experimental-method sentence. The institutional publication page
  displays the erratum DOI; use the article DOI just given.
  https://bpb-us-e1.wpmucdn.com/sites.harvard.edu/dist/f/80/files/2022/05/MM-natureCB.pdf

The proofs in this note are explicit, but no historical priority claim is
made for the sharp-envelope packaging, trie realization, inverse sensitivity
identity or access comparison. The renewal/star mechanism is established.
An exhaustive prior search has not been performed.

The strongest result is a partial-knowledge theorem and a precise acquisition
comparison. Remaining practical uncertainty is whether a consequential
scientific source provides an atomic or actively regenerative port at a cost
that makes the resulting bounds valuable relative to direct long trials and
existing retaining renewal estimators. Finite authored examples would not
resolve that uncertainty.
