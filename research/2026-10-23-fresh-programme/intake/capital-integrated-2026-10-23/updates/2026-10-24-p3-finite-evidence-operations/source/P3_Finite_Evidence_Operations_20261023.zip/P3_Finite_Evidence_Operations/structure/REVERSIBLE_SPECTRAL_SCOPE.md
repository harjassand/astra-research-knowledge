# Reversible autocorrelations: useful partial completion and an exact composition obstruction

Private P3 structure/access worker, 23 October 2026. Bounded theory response
to the parent. These are mathematical deductions and one authored exact
witness, not measurements or scientific transfer evidence. Historical novelty
of the deductions is not claimed. The residual acquisition continuation is
audited separately in REVERSIBLE_RESIDUAL_AUDIT.md.

## 1. What physical structure changes

Let L generate a stationary reversible classical continuous-time Markov
process, with invariant probability pi. On the full future-relevant space
L2(pi), L is self-adjoint and nonpositive. For a real centered observable f,
assume C(0)=||f||²>0 and define

~~~
C(t)=<f,exp(tL)f>_pi.
~~~

The spectral theorem gives a finite positive measure nu with

~~~
C(t)=integral_[0,infinity) exp(-lambda*t) nu(dlambda).
~~~

At fixed lag Delta>0, x=exp(-lambda*Delta) gives

~~~
m_k=C(k*Delta)=integral_[0,1] x^k mu(dx).
~~~

Thus the data form a Hausdorff moment sequence. This contract can apply to
a coarse observable even when no atomic state or regenerative port can be
observed. It supplies relations between unqueried and queried lags without
requiring hidden-state identification.

This is established structure. Berg and Song derive shape-constrained
autocovariance estimation from spectral moment representations for reversible
chains; discrete-time reversibility alone allows support [-1,1], while this
continuous-time semigroup has positive spectrum and hence support [0,1].
Their consistency results use additional ergodicity assumptions. Their work
is a strong existing estimator, not a finite-data certificate for an arbitrary
process. [Berg–Song primary paper](https://arxiv.org/html/2207.12705v3).

The new warrant is physical/algorithmic: equilibrium, detailed balance of the
full process, a common measured observable, and calibrated non-disturbing
observation. Finitely many scalar correlations do not recognize these
properties. A stationary trajectory avoids resets but contains dependent
samples; confidence needs a dependent-data argument. Independent equilibrium
replicas permit ordinary concentration but their preparation cost counts.
Equilibration is not free when slow mixing is the scientific problem.

## 2. Sharp same-generator lower completion is classical quadrature

Suppose exact m_0,...,m_(2n-1) are retained and the moment matrices are
nondegenerate. Let

~~~
mu_G=sum_(j=1)^n w_j delta_(x_j)
~~~

be the n-node Gaussian quadrature measure, with positive weights and nodes
in [0,1], matching those moments. For every integer T>=2n,

~~~
m_T >= sum_j w_j*x_j^T.                            (1)
~~~

This is the standard sign of the Gaussian quadrature error; Meurant's
author exposition gives the quadratic-form interpretation and quadrature
bounds on pages 16–21. It also warns that reconstruction from ordinary
moments can be ill-conditioned on page 56.
[Primary author exposition](https://gerard-meurant.fr/p_canazei_2009.pdf).

For completeness, Hermite-interpolate x^T at all Gaussian nodes, matching
value and first derivative. The interpolant h has degree at most 2n-1.
Its remainder is a nonnegative multiple of product_j(x-x_j)^2 because
the 2n-th derivative of x^T is nonnegative on [0,1]. Thus x^T>=h.
Every compatible measure integrates h identically, and quadrature integrates
h exactly. This proves (1). The measure mu_G is itself compatible and
attains every bound simultaneously. For singular data one uses the smaller
support representation rather than inverting a singular moment matrix.

In particular, n=1 gives

~~~
m_T >= m_0*(m_1/m_0)^T.
~~~

This is a sharp moment-class completion, not a new learning algorithm.
For noninteger future times one must check the relevant derivative sign;
the integer statement does not automatically cover every real exponent.

Noisy moments should be retained as a simultaneous confidence set and
optimized over nonnegative measures on [0,1]. Substituting noisy moments into
Gaussian quadrature and reporting its output as a bound is invalid.
Moment optimization and polynomial/semidefinite certificates are the strong
general baseline. Lasserre's primary paper develops semidefinite bounds
from moment conditions:
[author repository](https://optimization-online.org/2002/01/433/).
No particular implementation cost or superiority is established here.

Scalar correlation acquisition is weaker than direct matrix-vector access.
One must not borrow the cost of a Lanczos step while silently supplying a
physical transfer operator or exact inner product. Moment precision,
confidence, conditioning, quadrature/optimization, and verification all count.

## 3. Full isolated laws still leave intervention composition unidentified

Use the common uniform stationary distribution on three hidden states and
the centered binary readout

~~~
f=(2/3,-1/3,-1/3)^T,     C(0)=2/9.
~~~

Take symmetric generators

~~~
A = [[-3, 1, 2],      B = [[-3, 2, 1],
     [ 1,-3, 2],           [ 2,-3, 1],
     [ 2, 2,-4]]           [ 1, 1,-2]].
~~~

Let S exchange hidden states 2 and 3, and set B'=S B S. All three
generators have strictly positive off-diagonal rates, are irreducible, and
are reversible with the same uniform stationary law. S fixes f.

Compare world I with actions (A,B) and world II with actions (A,B').
For every t>=0,

~~~
<f,exp(tB)f>_pi = <f,exp(tB')f>_pi.
~~~

This is stronger than identical spectra. Every isolated binary observation
history under B has the same law under B': conjugate every transition
matrix by S, and note that both output projectors, the stationary law,
and the terminal all-ones vector are invariant under S. Any number of
observations or variable B pulse durations therefore remains insufficient.
A is literally the same source in both worlds. An isotropic common baseline
that commutes with S can also be interspersed without breaking this ambiguity.

For u=(1,-1,0)/sqrt(2) and v=(1,1,-2)/sqrt(6), A has decay rates 4,6
and B has decay rates 5,3. The normalized isolated autocorrelations are

~~~
a(t) = (3/4)exp(-4t)+(1/4)exp(-6t),
b(s) = (3/4)exp(-5s)+(1/4)exp(-3s).
~~~

Define the normalized two-block endpoint response by the displayed matrix
order

~~~
K_I(t,s)=<f,exp(tA)exp(sB)f>_pi/C(0).
~~~

Then

~~~
K_I = (3/4)exp(-4t-5s)+(1/4)exp(-6t-3s),

K_II-K_I
  = (3/8)(exp(-4t)-exp(-6t))(exp(-3s)-exp(-5s)) > 0
~~~

for positive t,s. In particular, t=s=log(2) gives

~~~
K_I=1/512,     K_II=59/16384,     gap=27/16384.
~~~

No unstable dynamics, zeros in the off-diagonal rates, or nonergodic class
produces the obstruction. Separate spectral laws do not specify relative
hidden eigendirections. One mixed equilibrium correlation at these durations
distinguishes this pair. That experiment acquires missing cross information;
it does not identify an arbitrary hidden system or certify all future words.

The exact Fraction-based witness is reversible_witness.py, with result
reversible_witness_results.json. It checks spectral projectors, generator
properties, and the stated rational gap. The all-times/history claim follows
from the conjugation proof, not from finitely many computed times.

## 4. The example is sharp for a useful task-specific interval

Normalize f to have norm one. Let U=exp(tA), V=exp(sB), and suppose the
four isolated quantities are available:

~~~
alpha=<f,Uf>,   a2=<f,U²f>,
beta =<f,Vf>,   b2=<f,V²f>.
~~~

Decompose Uf=alpha*f+u_perp and Vf=beta*f+v_perp. By Cauchy–Schwarz,

~~~
alpha*beta - sqrt((a2-alpha²)(b2-beta²))
 <= <f,UVf> <=
alpha*beta + sqrt((a2-alpha²)(b2-beta²)).           (2)
~~~

The two worlds above attain the lower and upper endpoint respectively,
for every t,s>0. Indeed their transverse space relative to f within the
centered three-state plane is one-dimensional, and S reverses it.
The half-width equals

~~~
(3/16)(exp(-4t)-exp(-6t))(exp(-3s)-exp(-5s)).
~~~

Thus even complete isolated observation laws cannot uniformly tighten (2)
for these data within irreducible reversible CT dynamics. This is an exact
partial-identification statement; the Cauchy–Schwarz operation itself is
elementary prior.

## 5. Finite short moments cannot upper-bound an unseen slow tail

Fix N+1 distinct nodes x_j in (0,1), positive weights w_j, and the moments
through degree N of mu_0=sum_j w_j delta_(x_j). Let ell_j be the degree-N
Lagrange basis for those nodes. For x_* approaching 1, choose a single
epsilon>0 small enough that

~~~
w_j-epsilon*ell_j(x_*) >= 0
~~~

for all j and all x_* in a fixed closed neighborhood of 1. This is
possible because the finitely many ell_j are bounded there. Set

~~~
mu_(x_*) = sum_j [w_j-epsilon*ell_j(x_*)] delta_(x_j)
           + epsilon delta_(x_*).
~~~

Polynomial interpolation proves that every moment from 0 through N remains
exactly unchanged. Yet

~~~
integral 1/(1-x) dmu_(x_*) -> infinity,
integral 1/(-log x) dmu_(x_*) -> infinity.
~~~

These are respectively a discrete integrated-correlation quantity and the
continuous-time integrated correlation (up to Delta). Every x_*<1 still
corresponds to a strictly positive relaxation rate. No actual atom at 1 is
required. Some boundary moment data force a unique measure; the claim is
that the displayed nondegenerate inputs admit unbounded tails, not that
every finite moment list does.

### The obstruction can have an irreducible physical Markov realization

It is not necessary to hide a nonergodic component in this construction.
Let a finite positive spectral measure have rates lambda_j>0 and weights
nu_j summing to p(1-p), for a fixed p in (0,1). Form the probability measure

~~~
sigma = p*delta_0 + sum_j (nu_j/p)*delta_(-lambda_j).
~~~

In the orthonormal polynomial basis for sigma, multiplication by x has a
real symmetric Jacobi matrix J with positive off-diagonal entries. Its
largest eigenvalue is 0. Let v be its positive normalized eigenvector at
0; the first coordinate has v_0²=p. Put D=diag(v) and L=D^(-1) J D.
Then L has nonnegative off-diagonal entries, zero row sums, is irreducible,
and is reversible with pi_i=v_i².

For the same binary readout f=1_{state 0}-p,

~~~
Df=sqrt(p)*e_0-p*v,
<f,exp(tL)f>_pi
   = p*e_0^T exp(tJ)e_0-p²
   = sum_j nu_j exp(-lambda_j*t).
~~~

Applying this to the measures above, scaled to total p(1-p), realizes all
competing moment lists with the same binary marginal, finite irreducible
reversible CT sources, and arbitrarily large integrated correlation.
Their unobserved hidden dimension need not grow as x_* approaches 1.
The gap shrinks; a known quantitative gap would rule out this family.

This reinforces the statistical issue in Berg–Song: an unbounded spectral
functional near 1 needs additional tail control, not merely an accurate
fit to finitely many correlations. Their paper explicitly discusses the
role of the support gap in asymptotic-variance estimation.

## 6. What cross measurement can acquire without full identification

For multiple actions P_a, require each to be self-adjoint in the SAME L2(pi).
For a word w=a_1...a_k, write P_w=P_(a_1)...P_(a_k), v_w=P_w f, and
q(w)=<f,P_w f>. Then

~~~
<v_u,v_v> = q(reverse(u) v).
~~~

The reverse word uses the same forward-time interventions in reverse order,
not negative-time physical dynamics. Gram and localizing matrices satisfy

~~~
G_uv=q(reverse(u) v) >=0 as a matrix,
H_a(u,v)=q(reverse(u) a v),
0 <= H_a <= G
~~~

for positive contractions such as CT reversible semigroups. Each entry
requires its actual pulse protocol. A matrix optimizer does not acquire
unmeasured entries for free.

This is the structure of noncommutative moment optimization. Pironio,
Navascues and Acin treat unknown-dimensional bounded operators via moment
and localizing SDP matrices, with convergence under an Archimedean
boundedness condition. Their framework is a strong baseline, not a new
method supplied by this note. [Primary paper, sections 2–3](https://optimization-online.org/wp-content/uploads/2009/03/2266.pdf).
Abstract positive-contraction realizations need not satisfy pointwise Markov
positivity or continuous-time embeddability, so the SDP can be conservative
for the physical class.

The parent construction uses these cross measurements to acquire a local
span residual rather than reconstruct the full source. That is a worthwhile
change in the information contract. Its exact proof, prior overlap, physical
warrant, and goal-specific improvement are in the separate residual audit.
No complete acquisition-and-inference advantage has yet been demonstrated.

