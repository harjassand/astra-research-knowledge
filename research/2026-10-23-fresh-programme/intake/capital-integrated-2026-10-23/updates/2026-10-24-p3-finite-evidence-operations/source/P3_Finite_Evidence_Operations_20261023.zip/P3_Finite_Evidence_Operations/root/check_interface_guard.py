"""Focused regression after an exposed API counterexample; no transfer claim."""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time
from correlation_certificate import Representation, Correlations
from uniform_correlation import uniform_certificate, run_program
from metric_correlation import metric_certificate
from adjoint_correlation import AdjointRepresentation, AdjointCorrelations, adjoint_metric_certificate


def main():
    start=time.perf_counter()
    root=Path(__file__).resolve().parent
    contract_path=root/'INTERFACE_GUARD_CHECK_CONTRACT.json'
    contract=json.loads(contract_path.read_text())
    checks=[]
    def check(name,value): checks.append({'name':name,'pass':bool(value)})
    script=root.parent/'external'/'ADJOINT_GENERIC_API_REPRO.py'
    records={}
    for mode,flags in [('archived',['--archived']),('current',[])]:
        run=subprocess.run([sys.executable,str(script),*flags],check=True,text=True,capture_output=True)
        records[mode]=json.loads(run.stdout)
    old,new=records['archived'],records['current']
    check('old_false_certificate_reproduced',old['generic_metric']['status']=='CERTIFIED_UNDER_CONTRACT' and not old['generic_metric']['sound_on_target'])
    check('old_valid_adjoint_path',old['adjoint_wrapper']['sound_on_target'])
    check('current_bad_metric_path_rejected',new['generic_metric']['status']=='REJECTED')
    check('current_bad_uniform_path_rejected',new['generic_uniform']['status']=='REJECTED')
    check('current_adjoint_path_sound',new['adjoint_wrapper']['sound_on_target'])
    base=Representation([()],{0:[[F(1,2)]]})
    data=Correlations({():(1,1),(0,):(F(1,2),F(1,2)),(0,0):(F(1,4),F(1,4))})
    adj=AdjointRepresentation([()],{0:[[F(1,2)]],1:[[F(1,2)]]},{0:1,1:0})
    adata=AdjointCorrelations({w:(F(1,2)**len(w),F(1,2)**len(w)) for w in adj.acquisition_words()},adj.dagger)
    for name,call in [
        ('metric_base_adj_data',lambda:metric_certificate(base,adata,[[1]])),
        ('metric_adj_base_data',lambda:metric_certificate(adj,data,[[1]])),
        ('uniform_base_adj_data',lambda:uniform_certificate(base,adata)),
        ('uniform_adj_base_data',lambda:uniform_certificate(adj,data)),
        ('perword_base_adj_data',lambda:base.certify((0,),adata)),
        ('perword_adj_base_data',lambda:adj.certify((0,),data)),
        ('adjoint_metric_base_rep',lambda:adjoint_metric_certificate(base,adata,[[1]])),
        ('adjoint_metric_base_data',lambda:adjoint_metric_certificate(adj,data,[[1]]))
    ]:
        try:call()
        except (TypeError,ValueError):check(name,True)
        else:check(name,False)
    for name,out,target in [
        ('valid_base_metric',metric_certificate(base,data,[[1]]),(0,0,0)),
        ('valid_base_uniform',uniform_certificate(base,data),(0,0,0)),
        ('valid_adjoint_metric',adjoint_metric_certificate(adj,adata,[[1]]),(0,1,0))
    ]:
        check(name,out['status']=='CERTIFIED_UNDER_CONTRACT' and out['uniform_error']==0 and run_program(out,target)==F(1,8))
    result={'status':'PASS' if all(c['pass'] for c in checks) else 'FAIL',
            'contract':contract,'contract_sha256':hashlib.sha256(contract_path.read_bytes()).hexdigest(),
            'checks':checks,'exact_counterexample_records':records,
            'elapsed_seconds':time.perf_counter()-start}
    (root/'INTERFACE_GUARD_CHECK.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'checks':len(checks),
                      'failures':[c['name'] for c in checks if not c['pass']],
                      'elapsed_seconds':result['elapsed_seconds']},indent=2))
    if result['status']!='PASS':raise SystemExit(1)


if __name__=='__main__': main()
