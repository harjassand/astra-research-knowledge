# Audit of the uniform correlation certificate and proposed metric

## Finding and scope

The all-word theorem and the proposed-metric extension are valid under the
stated common-Hilbert-space contraction contract. The implementations inspected
in this audit passed all **42 preselected algebraic checks**. No mathematical
validity bug was found. This audit does not establish physical acquisition,
historical novelty, scientific transfer, or practical superiority.

The inspected files and SHA256 values are:

| File in `../root/` | SHA256 |
| --- | --- |
| `correlation_certificate.py` | `8c03a5841c8cbbe40112b0b61591b406749479103edc63cf5b2a0fcf4bafc798` |
| `uniform_correlation.py` | `48d76b92b66bdb7911956f597e42ec586c4bfb926a8162ac9d6cfbc70f9761eb` |
| `metric_correlation.py` | `910845d0db9bf74bca970cdc37ba6dbf85100d67c9961453aaf93e2e10e5a2c4` |

The authoritative machine-readable hashes are also recorded in
`UNIFORM_METRIC_AUDIT_RESULTS.json`; all three source files remained unchanged
during execution. The core correlation code had already passed its separate
27-check audit. The two new check contracts were frozen before reading their
implementations:

- `UNIFORM_AUDIT_CONTRACT.json`, SHA256
  `80f601d3d02c8bf46f9fc0771c2c2dfdbed70527ba9e412eb783f2bb288520e6`.
- `METRIC_AUDIT_CONTRACT.json`, SHA256
  `42d06ad6624c912e88d52bd59c8161e75c5682ee6120a1a861572e370d4bc68d`.

Execute the bounded audit from the workspace root with:

```sh
python p3_representation/next_opportunity/structure/audit_uniform_metric.py
```

## 1. Exact theorem, including chronology

Let the action operators A_a be contractions on a common real Hilbert space.
For the acquisition formulas, they must also be self-adjoint in that same
space. Let V map coefficient vectors to the acquired feature span, with
V e_0=f. Define arbitrary proposed coefficient actions T_a and

\[
G=V^*V,\quad H_a=V^*A_aV,\quad
B_a=A_aV-VT_a,\quad D_a=V^*B_a,\quad R_a=B_a^*B_a.
\]

There is no rank or invertibility requirement on V or G. A proposed positive
definite coefficient metric M is a separate numerical object.

For a target word w=(a_1,...,a_N), define

\[
\ell_0=e_0,\qquad \ell_j=T_{a_j}\ell_{j-1},\qquad
r_N=e_0,\qquad r_{j-1}=T_{a_j}r_j.
\]

The target uses backward-operator chronology,
q(w)=<f,A_{a_1}...A_{a_N}f>. The corrected center is

\[
Q_w=e_0^TGr_0+\sum_{j=1}^N\ell_{j-1}^TD_{a_j}r_j.
\]

The previously established two-sided residual identity and contraction give

\[
|q(w)-Q_w|\le\sum_{i<j}\rho_i^L\rho_j^R,
\qquad
(\rho_j^L)^2=\ell_{j-1}^TR_{a_j}\ell_{j-1},\quad
(\rho_j^R)^2=r_j^TR_{a_j}r_j.
\tag{1}
\]

This follows by telescoping the right suffix approximation, replacing each
exact left prefix by its coefficient approximation, and applying
Cauchy–Schwarz. The left-prefix approximation error is at most the sum of
earlier left residual norms. Self-adjointness supplies the required reversed
left prefix; contractions control the intervening true dynamics. The exact
D terms are signed and must be retained in the center.

Suppose exact checks establish

\[
T_a^TMT_a\preceq r^2M,\qquad R_a\preceq\kappa M,
\qquad M\succ0,\quad 0\le r<1.
\]

Then

\[
\rho_i^L\le\sqrt{\kappa M_{00}}r^{i-1},\qquad
\rho_j^R\le\sqrt{\kappa M_{00}}r^{N-j}.
\]

For N>=2, group the pairs i<j by k=i-1+N-j. There are exactly k+1 pairs
for k=0,...,N-2. Therefore

\[
|q(w)-Q_w|\le\kappa M_{00}S_N(r),\qquad
S_N(r)=\sum_{k=0}^{N-2}(k+1)r^k\le\frac1{(1-r)^2}.
\tag{2}
\]

For N=0 and N=1 the pair sum is empty. For r=0 and N>=2 the sum equals
one; no negative exponent needs to be evaluated.

## 2. Correlation uncertainty and the M00 factor

Let G_c,D_{a,c} be the centers obtained by evaluating the retained affine
correlation forms at their shared interval centers. Suppose the single
simultaneous data event gives, for all coefficient vectors x,y,

\[
|x^T(G-G_c)y|\le\eta_G\|x\|_M\|y\|_M,
\qquad
|x^T(D_a-D_{a,c})y|\le\eta_D\|x\|_M\|y\|_M.
\]

For N>=1,

\[
|Q_w-Q_{w,c}|\le M_{00}\bigl(\eta_G r^N+
N\eta_Dr^{N-1}\bigr)
\le M_{00}\left(\eta_G+\frac{\eta_D}{1-r}\right).
\tag{3}
\]

The second inequality uses
N r^(N-1)<=1+r+...+r^(N-1)<=1/(1-r). Handle N=0 directly:
Q_empty=G_00 and its center uncertainty is at most M00 eta_G.

Combining (2) and (3) gives a deterministic statement for **every finite
word simultaneously**:

\[
|q(w)-Q_{w,c}|\le M_{00}\left[
\eta_G+\frac{\eta_D}{1-r}+\frac{\kappa}{(1-r)^2}\right].
\tag{4}
\]

The prefactor is M00 because both the left and right initial vectors are
e0 and ||e0||_M^2=M00. It is not an optional normalization. M=I gives the
unweighted version. Changing the coefficient metric does not assume that
the true Gram matrix is invertible.

## 3. Exact compilation

Define

\[
\mathcal M_a=\begin{pmatrix}T_a^T&D_{a,c}\\0&T_a\end{pmatrix},\qquad
L=[e_0^T,\ e_0^TG_c],\qquad R=[0,e_0]^T.
\]

Then

\[
L\mathcal M_{a_1}\cdots\mathcal M_{a_N}R=Q_{w,c}.
\]

Each upper-right block term is
e0^T T_a1^T ... T_a(j-1)^T D_aj,c T_a(j+1) ... T_aN e0,
which equals the corresponding prefix/suffix correction. The lower-right
block contributes e0^T G_c r0. The empty product returns G_c,00.

The code applies matrices to the right vector in reversed word order,
which implements this product correctly. This is an ordinary finite
weighted-automaton representation. A retaining program learner with the
same acquired table can store and execute it. No architectural advantage
follows from the compiler itself.

## 4. Why the matrix uncertainty bounds are safe

If E is symmetric and |E_ij|<=B_ij with symmetric B>=0 entrywise, then

\[
|x^TEx|\le\sum_{ij}B_{ij}|x_i x_j|
\le\sum_i\left(\sum_j B_{ij}\right)x_i^2.
\]

Thus -diag(B1)<=E<=diag(B1). This justifies the Gram uncertainty majorant
and R_center+diag(B1) as an upper matrix bound for the true residual Gram.
Symmetry holds for the implementation's Gram and polarized residual forms,
including shared-word canonicalization.

For a possibly nonsymmetric defect error E, row and column radius sums
must both be used. The elementary inequality gives

\[
|x^TEy|\le\tfrac12\left[
x^T\operatorname{diag}(B1)x+
y^T\operatorname{diag}(B^T1)y\right].
\]

If both diagonal matrices are <=eta M, rescale x,y to equal M-norms;
the bilinear product remains unchanged and the bound becomes
eta ||x||_M ||y||_M. The code performs both domination checks.

The frozen counterexample to a row-only rule is

\[
B=\begin{pmatrix}0&4\\1&0\end{pmatrix},\qquad
M=\operatorname{diag}(4,1).
\]

The row majorant equals M, but M^(-1/2) B M^(-1/2) has operator norm 2.
The column majorant forces eta>=4 in this sufficient method, safely above
the needed 2. That conservatism is visible rather than silently optimized.

## 5. Exact arithmetic and finite search

The rational Schur-complement PSD test is correct. At a zero diagonal
pivot, PSD requires every remaining off-diagonal entry in that row to be
zero; the code checks this. A positive pivot permits exact Schur reduction.
Strict PD rejects zero pivots. Matrices are copied before elimination.

The domination search keeps a checked upper c with cM-B PSD. It doubles
until finding one, then bisects between a failed lower and checked upper.
It verifies the final upper again exactly. Bounded exhaustion raises an
error instead of treating the last trial as a certificate. Square roots
are rounded upward by the audited rational routine.

For fixed d and precision p, each successful default domination search
uses at most p+130 exact PSD calls; early negative-semidefinite B takes
one. Each PSD test uses O(d^3) rational arithmetic operations. This is not
a bit-complexity guarantee: large denominators, poorly conditioned metrics,
and arithmetic growth remain charged work. Matrix fitting and metric
selection are proposals outside this verifier. A failed sufficient norm
test does not establish instability of the representation or source.

The unweighted code uses sqrt(||T||_1 ||T||_infinity), which really bounds
the Euclidean operator norm. The selected matrix

\[
T=\begin{pmatrix}3/4&0\\3/4&0\end{pmatrix}
\]

has row norm 3/4 but Euclidean norm sqrt(9/8)>1; it is correctly rejected
by that unweighted sufficient test. With M=diag(4,1), however,
T^T M T<=(45/64)M. The metric implementation certifies r<1.

This distinguishes a coordinate failure from a scientific obstruction.
Natural exact word shifts T_a e0=e_a force Euclidean norm at least one
when both f and A_a f are dictionary columns. They do not rule out
strict contraction in an appropriate acquired numerical metric.

## 6. Executed checks and remaining limits

The 42 assertions cover the nonnormal norm witness, zero-pivot PSD/PD
boundaries, indefinite and singular metric rejection, exact domination
and search exhaustion, nonexact input and negative precision rejection,
shared-word compiler equality, empty-word behavior, the M00 factor,
interval widening, and exact residual domination. They also check the
finite pair combinatorics independently of the parent implementation.

The only source sequence was the already exposed C(w)=2^(-|w|), with
dictionary [empty,a]. Its true Gram is singular. Two deliberately
noncommuting rational candidate matrices are numerical proposals, not
new physical dynamics. The source sequence was used solely to challenge
compiler and interval boundaries. No unseen scientific evaluation is
claimed. Every result, including scope and exposure, is recorded in
`UNIFORM_METRIC_AUDIT_RESULTS.json`.

The theorem quantifies over all proposed T and M on the same deterministic
simultaneous interval event. Fitting or selecting these proposals after
seeing that fixed table does not require another union bound. Enlarging
the acquired pool, changing features, adaptive sampling, or data-dependent
stopping still requires valid joint confidence accounting. A finite
compiled representation also does not make arbitrary long-word execution,
word optimization, or acquisition free.

The quantified objects are finite open-loop action words. A word may be
chosen after inspecting the retained training evidence because the bound
already holds for all words on that event. A feedback policy that chooses
an action from intermediate observations during the new physical run is
a different object: its state-conditioned path law is not automatically a
mixture of the certified open-loop endpoint correlations. Such policies
need their own observable/conditional operator interface.

The conclusion is uniform **absolute correlation error**, not a bound on
integrated correlation, a full spectral gap, complete latent dimension,
or global mixing. The preserved slow-tail construction shows why those
stronger conclusions fail from the same finite moment data. The physical
common equilibrium, adjoint/reversal identities, and nondisturbing readout
remain an access contract, not facts inferred by this verifier.

The nearest established methods remain residual dynamic mode decomposition,
goal-oriented residual correction, common-metric switched model reduction,
and moment optimization. See `REVERSIBLE_RESIDUAL_AUDIT.md` and
`REVERSIBLE_SPECTRAL_SCOPE.md` for the primary-source comparison. This audit
supports the conditional construction; it does not resolve its historical
novelty or full acquisition-and-inference advantage over those methods.
