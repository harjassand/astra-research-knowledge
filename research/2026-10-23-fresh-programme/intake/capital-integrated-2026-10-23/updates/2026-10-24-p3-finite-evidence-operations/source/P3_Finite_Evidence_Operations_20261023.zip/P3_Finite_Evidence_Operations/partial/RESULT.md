# Partial scientific knowledge for intervention prediction

Private P3 independent mechanism challenge. 23 October 2026. No new empirical
benchmark, hidden encoding, physical measurement, historical-novelty claim, or
architectural separation is asserted here.

## Finding

A materially different route from local-dependency certification is to acquire
a **task sufficient distribution of path observables**. For controllable added
capture hazards, occupation histories predict an entire family of finite
interventions without identifying the underlying dynamics, global state space,
or a complete physical condition. The equally informed retaining Monte Carlo
method already realizes this construction. A proposed small resolvent kernel
is therefore not the strong new algorithm on this access contract.

This gives root a useful positive principle and a boundary: full identification
is unnecessary when the intervention semantics supplies a lawful pathwise
transport operation. The scientific question is whether that semantics is
obtainable and whether the necessary path statistics can be acquired at useful
cost. Neither question is answered by inventing a hidden encoding.

## 1. External scientific obstruction and sources

Diffusion-mediated capture depends jointly on transport to a target and its
reactivity. A perfectly absorbing boundary can be a poor model of a target
with finite reactivity. Bressloff derives partial reaction from boundary local
time or interior occupation time, including intracellular vesicle capture as
an example. The local-time/occupation-time representation and its Feynman-Kac
transforms are explicit prior methods, not new P3 discoveries.

- Paul C. Bressloff, *Diffusion-mediated surface reactions, Brownian functionals
  and the Feynman-Kac formula*, arXiv:2201.01671v1 (2022), Sections 1-3, especially
  the stopping representation and occupation-time construction.
  https://arxiv.org/pdf/2201.01671
- Paul C. Bressloff, *Encounter-based reaction-subdiffusion model II: partially
  absorbing traps and the occupation time propagator*, arXiv:2303.10484v1
  (2023), equations (2.1)-(2.5) and introduction. It derives the transport/reaction
  coupling rather than simply adding an unaltered fractional diffusion operator
  to a reaction term. This guards against transferring the operation outside
  its microscopic contract.
  https://arxiv.org/pdf/2303.10484
- Tommer D. Keidar and Shlomi Reuveni, *Universal Linear Response of the Mean
  First-Passage Time*, arXiv:2410.16129v2 (24 May 2025), equations (2), (4), (5).
  A strong prior alternative predicts rare-perturbation response using a few
  first-passage moments and a post-activation completion statistic. It does not
  require full dynamical identification. Finite moment existence is not itself
  a uniform finite acquisition bound.
  https://arxiv.org/html/2410.16129v2
- Juan M. Bello-Rivas and Ron Elber, *Exact milestoning*, J. Chem. Phys. 142,
  094102 (2015), Sections I-II. Acquired short-trajectory kernels and their
  source-consistent boundary distributions are established strong alternatives
  for rare kinetic events; knowing a low-dimensional boundary representation
  does not make its correct initial distributions free.
  https://pmc.ncbi.nlm.nih.gov/articles/PMC4352169/

These primary texts were opened. The two arXiv HTML requests for the Bressloff
papers failed; the PDFs succeeded. No secondary source supports the formulas
below. The derivations are stated directly so their access assumptions can be
checked independently.

## 2. First candidate: a small intervention resolvent

Let Q be the transient generator of a finite absorbing continuous-time Markov
chain, using the backward-generator convention. Set A=-Q and G=A^{-1}. Suppose
an intervention changes only k known channels and is implemented as

    Q_theta = Q + U Theta V^T,

where U,V are known channel incidence matrices and Theta is diagonal. A channel
s->t has column u=e_s and v=e_t-e_s; an absorbing t contributes zero e_t in the
transient coordinates. For initial distribution alpha and reward-rate g, the
integrated reward is J(theta)=alpha^T(-Q_theta)^{-1}g.

Whenever the perturbed source is valid and transient, elementary Woodbury gives

    J(theta) = j + h (I-Theta K)^{-1} Theta v,

where

    j=alpha^T Gg, h=alpha^T GU, K=V^T GU, v=V^T Gg.

Thus the full generator is unnecessary. The representation stores k^2+2k+1
response quantities. Different unknown generators with the same object give
the same scalar response for this entire intervention family.

These entries are occupation expectations or differences of occupation
expectations. With reset access to the channel endpoints and complete state
observation, they can be sampled without identifying Q. A discount s>0 replaces
G by (sI-Q)^{-1}; sampling the source at an independent Exp(s) time produces
sG(i,j) as an ordinary probability. The expected duration is at most 1/s.
Undiscounted moments may have enormous or unbounded acquisition cost.

Adding a new channel extends the retained kernel by a row, column and task
coefficients. Existing trajectory records can supply the new column only if
they retained the state information needed to recognize that new endpoint.
New resets/trajectories are required for unobserved start conditions. The
matrix inverse and condition number, acquisition precision, resets, trajectory
length and stored paths must all be charged.

**Baseline decision:** this is standard resolvent/model-reduction machinery.
It is a task-relevant quotient, not a new representation-learning algorithm.
For the scientifically natural positive-killing subclass, a simpler equally
informed retaining estimator below is stronger: it requires no resets to
interior ports and avoids an estimated matrix inverse.

## 3. A pathwise intervention representation without Markov identification

Fix an obtainable distribution of base trajectories X on [0,H], possibly
stopped earlier by a native completion time tau. X can be non-Markov and may
contain unobserved microscopic coordinates. The experiment must supply the
following observable path statistics:

    L_i = integral_0^{H wedge tau} g_i(t,X) dt,   i=1,...,k,

where g_i are nonnegative predictable hazard controls. They may depend on the
observable history. Let theta_i>=0. Implement an independent capture clock with
instantaneous hazard h_theta= sum_i theta_i g_i. Crucially, the control does not
alter the distribution of the motion before capture. The base stopping rule,
initial law, measurement convention and source version remain fixed.

Conditional on a realized base path, the probability that no added capture
occurs before H wedge tau is exp(-theta dot L). Consequently

    p(theta) = Pr(added capture before H wedge tau)
             = E[1-exp(-theta dot L)].                       (1)

This follows from the survival probability of an independent integrated hazard
clock; no Markov assumption, normalizer, complete state enumeration, generator
identification, or global source-membership certificate is needed.

The acquired object is the law of L, or its empirical approximation. Its
operation maps a newly supplied nonnegative vector theta to a capture
probability. A change in theta is a new intervention target, not another stored
answer. Independent hazards compose by addition of their vectors. This is a
concrete lawful reuse operation across a continuum of interventions.

The conditional expectation in (1) is a Rao-Blackwellized alternative to
simulating a fresh exponential capture clock on each stored trajectory. Its
variance is no larger than the corresponding binary capture indicator. This
is established conditional-expectation reasoning, not a novel variance claim.

A more general independently randomized occupation threshold has survival
function Psi(L). Its capture probability is E[1-Psi(L)]. Reusing the same
acquired law is valid when that threshold law is itself calibrated. Acquiring
an arbitrary Psi or an unknown threshold/path dependence is a separate task.

## 4. Explicit acquisition and confidence

Acquire m independent base trajectories and their vectors L^(j). Retain them.
For any later theta, evaluate

    p_hat(theta) = (1/m) sum_j [1-exp(-theta dot L^(j))].

For a prespecified finite family F of M hazard settings, Hoeffding and a union
bound give

    Pr(sup_{theta in F}|p_hat(theta)-p(theta)|>epsilon)
       <= 2 M exp(-2 m epsilon^2).                            (2)

Thus m >= log(2M/delta)/(2 epsilon^2) suffices. Once the event in (2) holds, the
setting can be selected adaptively from F using these data without spending a
second failure budget. Source acquisition is m trajectories, not M*m.

For bounded continuous controls theta in [0,Theta]^k and sum_i L_i<=H, choose a
grid with coordinate spacing at most epsilon/(2H), including both endpoints
on every coordinate, and use a nearest grid point. The map is H-Lipschitz in
l-infinity parameter distance because

    |exp(-theta dot L)-exp(-theta' dot L)|
       <= |(theta-theta') dot L| <= H ||theta-theta'||_infinity.

A grid with at most (2+2H Theta/epsilon)^k points has nearest-point distance
at most epsilon/(4H). The empirical and population approximation errors are
each at most epsilon/4. Their sum epsilon/2 and the Hoeffding error epsilon/2
yield the explicit sufficient count

    m >= (2/epsilon^2)
         [log(2/delta)+k log(2+2H Theta/epsilon)].             (3)

No grid enumeration is needed for this statistical union argument; a numerical
optimizer's own work and approximation error must still be charged. Optimizing
on the empirical representation does not prove global optimizer convergence.

The full nonnegative parameter family has pseudodimension k. For subgraph
thresholds r_j in (0,1),

    1-exp(-theta dot L_j) >= r_j
    iff theta dot L_j >= -log(1-r_j).

The upper bound follows from the k-dimensional linear function class. Taking
L_j to be the k coordinate vectors proves the lower bound by choosing each
nonnegative theta_j above or below log 2. Standard uniform-convergence bounds
therefore remove the bounded-Theta assumption at the usual logarithmic cost.
Equation (3), whose proof is entirely explicit here, is enough for a concrete
finite-precision implementation.

All path generation, trajectory discretization, tracking, local-time or
occupation-time numerical integration, synchronization, readout noise and
control calibration are substantive costs. The formulas assume exact L.
If an obtained vector L_tilde has ||L-L_tilde||_1 <= eta deterministically and
||theta||_infinity<=Theta, its extra capture-probability error is at most
Theta*eta. A probabilistic measurement bound requires its own failure allocation.

## 5. Why the acquisition scale is not free

For k=1, take L=H with probability p and L=0 otherwise. Fix theta H=log 2.
Then p(theta)=p/2. Any uniformly reliable absolute-error prediction procedure
therefore estimates an unknown Bernoulli probability. The ordinary minimax
Omega(epsilon^-2 log(1/delta)) sample requirement applies away from endpoints.

For k controls, take L on the k coordinate vectors. At controls with each
coordinate either zero or a common large finite value C, the expected capture
probability is (1-exp(-C)) times the probability of an arbitrary subset of the
k outcomes. Uniformly accurate prediction of this family entails learning the
categorical law in total variation. Its standard worst-case sample order is
Omega(k/epsilon^2), for fixed confidence and nontrivial k. Thus ordinary
retaining empirical estimation is already close to information optimal for
this unrestricted trajectory-distribution contract. A proposed neural library
or compressed response model must exploit additional structure to beat it.

For the categorical estimation rate, see Clement Canonne, *A short note on
learning discrete distributions*, arXiv:2002.11457v3 (2020), Theorem 1:
https://arxiv.org/pdf/2002.11457 . The reduction here permits an arbitrary
function estimate: select any categorical law whose subset probabilities
fit those estimates within the guaranteed tolerance. The true law is feasible,
and triangle inequality bounds the selected law's total variation error.

The task is absolute probability prediction. Relative accuracy for a capture
probability p much smaller than epsilon requires stronger acquisition. The
fixed-deadline formulation does not claim cheap mean first-passage estimation.

### A moment-existence obstruction

A source whose completion time is always 1 and a source whose time is 1 except
for probability p, when it is 1+1/p, have means 1 and 2. All moments of either
fixed distribution exist. With n ordinary samples, their transcripts agree
with probability (1-p)^n. Choosing p arbitrarily small defeats any fixed sample
budget for distinguishing the two means. More generally, a sequential method
with finite expected samples C under the deterministic source has rare-branch
hit probability at most p*C under the coupled alternative before divergence.
No uniform finite mean-estimation guarantee follows merely from existence of
moments. A quantitative tail or bounded-time contract is necessary.

This is not a criticism of the Keidar-Reuveni identity: their finite-moment
assumptions support the identity. It distinguishes the theorem's inputs from
the cost of acquiring those inputs.

## 6. Exact counterexamples to over-transfer

### Intervention changes motion before capture

Let H=1 and the observed control region be R. In the base source, X_t is always
outside R, so L=0 and every possible retained observation agrees. Consider two
physical implementations of a proposed switch. In implementation A it only
adds capture hazard theta*1_R and capture probability is zero. In implementation
B activating the switch first moves the particle into R, then applies the same
hazard; capture probability is 1-exp(-theta). Unperturbed trajectories cannot
distinguish the two. The pathwise operation needs independently justified
pre-capture invariance or intervention data. It must not infer that invariance
from baseline fit quality.

### New observable is absent from retained data

If the learner retained only old occupation vectors, two path laws can have
identical old L and different occupation of a new target region. The old
representation cannot infer that new coordinate. For example, old g=0 under
both laws, but a new indicator is constantly zero in one and constantly one in
the other. New raw path information or newly acquired measurements are needed.
Retaining full trajectories may permit the extension, but their measurement,
storage and reprocessing costs belong to the stronger baseline as well.

### Competing reaction identity is not contained in total occupation alone

Equation (1) predicts whether any added capture occurs. To predict *which*
channel captures first, the temporal order of occupancy can matter. Two paths
can each spend half their time in region 1 and half in region 2, in opposite
orders. They have the same L but different cause-specific capture probabilities.
For disjoint constant hazards theta on each region, order 1 then 2 gives

    P(cause 1)=1-exp(-theta/2),

while the reverse order gives

    P(cause 1)=exp(-theta/2)[1-exp(-theta/2)].

The total capture probability is 1-exp(-theta) in both. Thus a task-sufficient
representation can be exact for one operation and provably insufficient for a
consequential extension. The missing operation requires cumulative occupation
histories, not merely a larger table of final occupation totals.

With the full histories L_i(t), the valid extension is

    P(cause i by H) = E[integral_0^H
      exp(-sum_j theta_j L_j(t)) theta_i dL_i(t)].             (4)

This is again known competing-hazard/pathwise survival machinery. It requires
acquiring or retaining order information. It does not require identifying the
whole microscopic source.

## 7. Recommendation to root

Do not commit the branch to full-domain dependency certification. This example
shows an important scientific operation supported by partial path knowledge,
with a physically interpretable stronger access mechanism. It also shows why
a representation's sufficient scope must follow the task: final occupancies
suffice for total capture but fail for reaction selectivity, while ordered
histories support the latter.

The unresolved, potentially stronger direction is **acquiring a compact ordered
interaction representation that supports changed reaction selectivity or
feedback without measuring every path in full**, and proving its acquisition
cost against the retaining-history and exact-milestoning controls. The source
must make the intervention semantics obtainable, and the representation must
retain the order information the cause-specific counterexample identifies.
A new authored set of hazard parameters would not establish that advance.
