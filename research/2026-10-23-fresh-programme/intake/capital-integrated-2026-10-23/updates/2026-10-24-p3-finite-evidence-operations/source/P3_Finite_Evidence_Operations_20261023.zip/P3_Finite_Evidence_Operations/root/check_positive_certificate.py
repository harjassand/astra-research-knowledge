"""Exploratory algebra checks; these authored cases are not transfer evidence."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json
import time

from positive_certificate import (endpoint_gradient, product_interval,
    propose_dual, verify_threshold, verify_dual, log_interval,
    retained_block_bound, Constraint)


def scalar(word, matrices):
    v = [F(1), F(0)]
    for i in word:
        p = matrices[i]
        v = [p[0][0]*v[0]+p[0][1]*v[1], p[1][0]*v[0]+p[1][1]*v[1]]
    return v[0]


def intervals(matrices, width):
    a_lo, d_lo, constraints, retained = [], [], [], {}
    p_mid = []
    for i in range(len(matrices)):
        first, second, third = [scalar((i,)*length, matrices) for length in (1,2,3)]
        al, au = max(F(0),first-width), min(F(1),first+width)
        pl = max(F(0), second-width-au*au)
        pu = max(F(0), second+width-al*al)
        dl = max(F(0), third-width-au**3-2*au*pu)/pu
        a_lo.append(al)
        d_lo.append(dl)
        p_mid.append(second-first*first)
        constraints += product_interval(len(matrices),i,i,pl,pu,f"p{i}")
        for length, value in enumerate((first,second,third),1):
            retained[(i,)*length] = value-width
    # One mixed edge connects the two local gauges. The reverse was NOT queried.
    mixed = scalar((0,1), matrices)
    h = mixed-matrices[0][0][0]*matrices[1][0][0]
    hl = mixed-width-(matrices[0][0][0]+width)*(matrices[1][0][0]+width)
    hu = mixed+width-(matrices[0][0][0]-width)*(matrices[1][0][0]-width)
    constraints += product_interval(2,0,1,max(F(0),hl),hu,"h10")
    retained[(0,1)] = mixed-width
    # Canonical proposal from paid central endpoint moments, not hidden b/c.
    point = [F(1), h/p_mid[0], p_mid[0], p_mid[1]*p_mid[0]/h]
    return a_lo,d_lo,constraints,retained,point


def main():
    started=time.perf_counter()
    matrices=[[[F(1,2),F(1,5)],[F(1,4),F(1,3)]],
              [[F(2,5),F(3,10)],[F(1,5),F(1,4)]]]
    a,d,rows,retained,point=intervals(matrices,F(1,100000))
    target=(1,0,1,1,0,0)
    q,g=endpoint_gradient(target,a,d,point)
    dual=propose_dual(rows,g)
    threshold=F(99,100)*q
    certificate=verify_threshold(target,a,d,point,rows,dual,threshold,bits=70)
    assert certificate['certified']
    truth=scalar(target,matrices)
    assert threshold<=truth
    rejections=[]
    damaged=dual.copy()
    damaged[0]+=F(1,10**20)
    try:
        verify_dual(rows,g,damaged)
    except ValueError:
        rejections.append('nonzero_1e-20_dual_residual')
    else:
        raise AssertionError('Accepted an inexact dual')
    for label,invoke in [
        ('float_dual_rejected',lambda:verify_dual(
            [Constraint((-1,),1,F(1))],[F(1,3)],[1/3])),
        ('negative_diagonal_rejected',lambda:endpoint_gradient(
            (0,0),[F(-1,2)],[F(-1,2)],[F(1),F(1)])),
        ('negative_action_rejected',lambda:endpoint_gradient(
            (-1,),a,d,point))]:
        try:
            invoke()
        except (ValueError,TypeError):
            rejections.append(label)
        else:
            raise AssertionError('Accepted '+label)
    assert retained_block_bound((0,0),{(0,):F(-1,2)})==0
    impossible=rows+[Constraint((1,0,0,0),1,F(1,2),'contradictory_witness')]
    try:
        verify_threshold(target,a,d,point,impossible,dual+[F(0)],threshold)
    except ValueError:
        rejections.append('infeasible_provided_witness')
    else:
        raise AssertionError('Accepted invalid feasibility witness')
    assert log_interval(F(1))[0]==0
    lo,hi,n=log_interval(F(1,2**1000),bits=50)
    assert lo<hi<0 and n<100
    # Exhaustive small positive-path check: every certificate here uses the same
    # already-exposed authored matrices, not independent scientific evaluation.
    words=0
    for length in range(1,7):
        for word in product(range(2),repeat=length):
            lower,_=endpoint_gradient(word,a,d,point)
            assert lower<=scalar(word,matrices)
            words+=1
    # Independent worker counterexample to the discarded ratio-box proposal.
    h=F(1,100)
    ill=[[[F(1,2),h*h/F(2,5)],[F(2,5),F(1,2)]],
         [[F(1,2),F(2,5)],[h*h/F(2,5),F(1,2)]]]
    cross=scalar((0,1),ill)
    diagonal=F(1,2)**4
    block=cross*cross
    actual=scalar((0,1,0,1),ill)
    assert diagonal<block<=actual
    result={
      'scope':'Authored exploratory proof checks; no empirical or transfer claim',
      'common_rank2_contract':'assumed, not acquired',
      'source_probability_intervals':'authored rational +/- 1e-5, not measured',
      'distinct_endpoint_experiment_types':7,
      'unqueried_target':target,
      'certified_lower':threshold,
      'true_authored_response':truth,
      'retained_block_lower':retained_block_bound(target,retained),
      'log_margin_lower':certificate['log_margin_lower'],
      'series_terms':certificate['series_terms'],
      'exact_dual':dual,
      'exact_rejections':rejections,
      'path_word_checks':words,
      'range_reduced_log2_power1000_terms':n,
      'failed_ratio_box_case':{'diagonal_lower':diagonal,
          'retained_two_block_lower':block,'actual_response':actual},
      'equally_informed_retaining_GP':'identical certificate available; no separation',
      'physical_acquisition_and_reset_cost':'UNKNOWN; no physical experiment',
      'wall_seconds':time.perf_counter()-started,
    }
    # Full finite-confidence acquisition count, rather than free interval inputs.
    # Exact rational log upper bounds make the displayed sufficient counts safe.
    def ceiling(v):
        return -(-v.numerator//v.denominator)
    delta=F(1,100)
    eta=F(1,100000)
    per_type=ceiling(log_interval(2*7/delta,70)[1]/(2*eta*eta))
    direct_eta=(truth-threshold)/2
    direct=ceiling(log_interval(2/delta,70)[1]/(2*direct_eta*direct_eta))
    result['charged_acquisition_comparison']={
      'comparison_kind':'Worst-case Hoeffding sufficient counts, not measurements or minimax lower bounds',
      'simultaneous_failure_budget':str(delta),
      'raw_probability_radius':str(eta),
      'independent_resets_per_type':per_type,
      'total_model_based_resets':7*per_type,
      'model_based_pulse_applications':14*per_type,
      'direct_target_resets_sufficient':direct,
      'direct_target_pulses_sufficient':6*direct,
      'model_to_direct_sufficient_reset_ratio':7*per_type/direct,
      'limitation':'Ideal resets, stationary independent Bernoulli endpoints. Model intervals authored at truth. More efficient statistical baselines may improve counts; no acquisition advantage.'}
    result['exact_margin_fraction_bits']=max(
      certificate['log_margin_lower'].numerator.bit_length(),
      certificate['log_margin_lower'].denominator.bit_length())
    # Avoid serializing enormous rational log margins; retain decimal and exact
    # identity checks, with the full witness regenerable from this script.
    result['log_margin_lower']=float(result['log_margin_lower'])
    out=Path(__file__).with_name('POSITIVE_CHECK.json')
    out.write_text(json.dumps(result,default=str,indent=2)+'\n')
    print(json.dumps(result,default=str,indent=2))


if __name__=='__main__':
    main()
