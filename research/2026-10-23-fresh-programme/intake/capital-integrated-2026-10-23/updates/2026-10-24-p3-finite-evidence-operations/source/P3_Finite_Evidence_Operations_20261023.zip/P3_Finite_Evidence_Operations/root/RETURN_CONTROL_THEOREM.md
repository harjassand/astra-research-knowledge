# A least completion supports minimax return-reward control

Private P3 root derivation, 23 October 2026. This continues the proved
first-return construction into an operation, rather than merely enlarging
a prediction table. Historical novelty remains UNKNOWN; the computation is
ordinary finite-horizon dynamic programming on an acquired renewal model.

## 1. Claim and scope

Let a stationary controlled process have a genuine regenerative port. The
learner either has exact endpoint data on a finite factor-closed dictionary,
or exact/direct coordinatewise-lower first-return data on a finite dictionary.
In the latter case the ambiguity set contains all compatible coordinatewise
interval constraints and no discarded additional joint information.

Write f_min for the determined first-return values (or their lower bounds),
extended by zero outside the acquired dictionary. Its prefix-trie realization
is a compatible process M_min. Consider any finite-horizon controller that
observes only its actions and whether a return occurred. Rewards are
nonnegative and paid at specified return-event prefixes; an absorbing task
automaton can give reward one on first successful completion. There is no
reward for absence of an event and no negative action cost. A fixed horizon
can charge/control physical duration without adding an unsupported reward.

Then the SAME compatible source M_min minimizes every such controller's
expected reward:

    J_M(pi) >= J_M_min(pi) for all compatible M and all allowed pi.

Consequently

    sup_pi inf_M J_M(pi) = sup_pi J_M_min(pi).

The right side is an implementable finite-horizon control problem. Full system
identification, a hidden-state count and an unknown physical source equation
are not supplied to the learner. The regenerative input contract remains
essential, and its acquisition/calibration is not proven by finite tables.
If training used endpoint-only observations, feedback additionally requires
obtainable intermediate event detection that leaves the learned action law
valid. That stronger deployment access is not inferred from endpoint data.
Directly monitored first-event training and deployment can instead use the
same calibrated measurement/reset instrument throughout.

## 2. Proof

Condition first on the controller's private random seed; its decisions are
then deterministic functions of prior action/event history. Immediately after
each return, the source is in the same regenerative condition. Until the next
return, the controller follows a definite no-event branch. The probability
that the next return occurs after its word u is f(u), even though the word was
chosen using the previous return history.

For any specified finite return-prefix history, the probability is therefore
the product of the first-return coefficients for its consecutive excursion
words. Expected nonnegative return reward is the sum of those products times
the corresponding reward. Terms may involve different controller branches,
but their coefficients are nonnegative. Replacing f by f_min can only decrease
this sum. Repeated rewards are handled by linearity; an absorbing success
automaton ensures one-time success is not counted twice. Averaging over the
controller seed proves the randomized-policy statement.

The prefix-trie source realizes f_min for every input word and is compatible
with the retained information. It attains the lower value for every policy
simultaneously, proving the minimax equality without exchanging unrelated
suprema and infima. This is a uniform statement: selecting a policy after the
finite-library confidence event needs no further policy-count union bound.

## 3. Computation

Inside the trie, the action word since the most recent return is observable:
it is a function of the controller's action/event history. At a retained
proper prefix u with remaining first-return mass s(u)>0, action a has return
probability f_min(ua)/s(u), returns to the root on an event, and otherwise
continues to prefix ua when that prefix exists. Off-trie no-event mass enters
a cemetery state with zero future return reward. Zero-survival states are
unreachable and can have arbitrary zero-reward behavior.

For finite task-automaton state z and remaining horizon t, a Bellman recursion
on (u,z,t) therefore computes the best guaranteed return reward. There are at
most O(|prefixes(dictionary)|*|task states|*T) states and one comparison per
available action at each state. Exact rational costs can grow with T; finite
precision and acquisition are not counted as unit-cost operations.

`return_controller.py` implements the special task of collecting at least k
returns by a horizon. Its tiny-horizon comparison enumerates full observation
policy trees and evaluates them directly in the hidden-state matrices, using
no renewal compiler for that reference calculation.

### A division-free recurrence

Small prefix survival s(u) need not appear as a numerical divisor. Define
W_t(u,z)=s(u)V_t(u,z), with s(empty)=1. For an acquired edge ua,

    W_t(u,z) = max_a { f_min(ua)[r(z,a,1)+W_(t-1)(empty,z_1)]
                      + W_(t-1)(ua,z_0) }.

The continuation term is zero if ua is not a retained proper-prefix state.
Missing event coefficients are zero, even if their prefixes lead to a longer
retained word. This recurrence follows by multiplying the ordinary Bellman
equation by s(u); the maximizing action is unchanged. Zero-survival states
have zero mass values automatically. In the implemented counting task the
event term is f_min(ua) times either one on the final required event, or the
root value with one fewer event still required. This avoids dividing by a
rare conditional exposure probability; it does not eliminate its statistical
acquisition cost.

## 4. Two extensions that fail

**No-event reward is not covered.** Suppose only f(a)=1/2 is known. The least
completion sets f(aa)=0 and has endpoint q(aa)=1/4, so the probability of no
port event at step 2 is 3/4. A compatible source with f(aa)=1/2 has q(aa)=3/4,
and no-event probability only 1/4. The least return completion is therefore
not a universal pessimistic model for arbitrary terminal rewards.

**Joint mass evidence need not have a least completion.** Suppose f(a)+f(aa)=1
but the split is unknown. Minimizing q(a) requires f(a)=0, giving q(aa)=1.
Minimizing q(aa)=f(a)^2+1-f(a) instead requires f(a)=1/2 and gives 3/4. No one
model attains both minima. Replacing both coefficients by their individual
lower bounds zero would violate the known total mass. The scalar joint-mass
certificate in `ATOMIC_RETURN_KERNELS.md` retains this information; general
robust optimization over joint constraints is a separate computational task.

## 5. Scientific and learning interpretation

The acquired object can support a new contingent control operation, not only
lookups on previously sampled words. Adding a new certified return kernel
extends the dictionary and can improve many controllers through all return
contexts. A conservative policy can become executable before the complete
hidden process is identified. These are scoped mathematical capabilities.

An equally informed retaining program can perform the same deconvolution,
renewal composition and Bellman recursion. This resolves the architectural
comparison as a tie. The potential scientific value is the partial-information
guarantee under obtainable event/reset access. A concrete experimental reset
contract, task-specific advantage and historical priority are not established.
