# Obtainable local evidence, partial operations, and a task-dependent obstruction

Private bounded P3 investigation, 23 October 2026. Completed circuit and
operational-transport artifacts are unchanged. No new benchmark wave, physical
measurement, source-code disclosure, worker, or model override was launched.

## Scientific conclusion

There is an obtainable source of exact local applicability: execution traces
from an instrumented, deterministic scientific program. A trace can certify a
partial input region without recognizing a global mathematical class. Such
regions can support bounded-expectation operations before the whole input
domain is covered. However, ordinary symbolic execution and self-adjusting
computation already exploit this information. The access mechanism is useful;
it does not currently justify a new learning architecture or a branch-wide
commitment to local-dependency acquisition.

Replacing exact locality with small typical-input sensitivity also changes the
scientific task that can be warranted. A bounded ordinary average can tolerate
an unmodeled rare region. A free energy can change by order one on precisely the
same region. The explicit construction below distinguishes these tasks without
requiring full system identification for either one.

## 1. A local certificate obtainable from an instrumented evaluator

Consider a deterministic terminating program P whose input is a finite bit
string x. Every access to an input bit must go through an instrumented read(i).
The source version, non-input state, program semantics, and initial interpreter
state are fixed. There are no uncontrolled clock reads, hidden mutable state,
external I/O results, or unrecorded random values. Random bits can be included
as part of the explicit input if their law is known.

One execution returns its output y and a complete input-read transcript

    tau = ((i_1,x[i_1]),...,(i_m,x[i_m])).

Let C_tau be the cylinder of all input strings agreeing with the recorded values
at every distinct input address read in tau.

### Trace certificate theorem

For every x' in C_tau, execution of P on x' follows the same computation and
returns y. This is a certificate for one input region; it does not assert that
the program globally depends only on those input bits.

Proof. Couple the executions instruction by instruction. Their initial states
are equal. A non-input instruction has identical operands and deterministic
semantics, so it preserves equal interpreter states. At the next input read,
the address is determined by the same current state, hence is the same i_t.
By membership in C_tau, the returned bit also agrees. Induction preserves the
entire execution and reaches the same halt and output. No unseen branch is
assumed to obey the observed branch's dependency set. QED.

The certificate can be obtained by instrumenting or replaying an executable
program; it is not supplied by an evaluator as a mathematical locality promise.
It still requires a trusted complete access monitor or a separately checked
execution proof. A self-reported list of input addresses from an untrusted
black box is insufficient. Arbitrary physical measurements do not automatically
supply this interface.

For floating-point scientific code the theorem concerns the implemented finite
computation, including its actual arithmetic, not automatically the continuum
physical equations or their truncation/discretization error.

## 2. A partial operation before global coverage

Assume the controlled initial-input law mu is a known product law on the input
bits. A complete trace cylinder has exactly computable mass

    mu(C_tau) = product over distinct read addresses i of mu_i(x[i]).

Distinct complete read transcripts of the same deterministic program define
disjoint cylinders. If two different traces had an input in common, the first
differing input-read answer would have to take two values on that input; this
contradicts deterministic execution. Repeated traces are deduplicated.

Suppose retained, certified terminal traces cover U, with known output y_j on
C_j. Let r = 1 - sum_j mu(C_j). For a source output known to lie in [a,b],

    I = sum_j mu(C_j) y_j,
    E_mu[P(X)] lies in [I + a*r, I + b*r].

The interval width is (b-a)r. It is a deterministic certificate about the
requested bounded average, even though the program outside U is unidentified.
No full-domain completeness requirement is appropriate once this width meets
the scientific tolerance. Each observed trace may be selected adaptively;
there is no statistical selection correction because its certificate is exact.

The same traces can be reweighted for a changed, computably weighted initial
law. The uncovered mass must be recomputed under that new law. A certificate
under one law does not assert that a different law has small uncovered mass.
The program/source version must remain the same, or unchanged behavior on the
old regions must be separately established.

New output functions g can also be applied to the retained outputs. If g is a
new deterministic oracle whose sole input is y, querying it once for each
distinct retained y certifies g(P(x)) throughout the corresponding cylinders.
The contract that g depends only on its supplied argument is furnished by the
actual module interface and fixed-state semantics. If the scientific process
also depends on omitted hidden state, that composition claim is invalid.

### Cost and comparison

Every initial program execution, trace acquisition/check, retained trace,
probability computation, changed-law reweighting, and new g call is charged.
For an m-step trace, replay/checking takes at least the relevant m-step work;
one cannot charge only the number of source outputs. Exact product masses
require the supplied probabilities' bit precision. Correlated initial laws
need their own mass-evaluation or sampling interface; no hidden normalizer is
provided by this theorem.

The equally informed symbolic-execution or retaining-program baseline obtains
the same certified cylinders and expectations. Self-adjusting computation also
retains dependency graphs and memoized function calls to propagate updates.
This route currently gives no separation from these methods.

It can be much weaker than semantic analysis: P(x)=sum_i x_i reads every input
bit, so every trace cylinder is a singleton, even though the expectation under
a product law is available analytically in linear work. Total-energy evaluators
often read the full state. Locality of a single-bit energy *difference* then
requires paired cancellation or program analysis, not merely the read set of
one ordinary energy evaluation. Claiming a small difference scope directly
would reintroduce the missing interface.

## 3. Small average local sensitivity does not justify all scientific tasks

Let mu be uniform on a binary cube. Let C be one prefix cylinder with mass
q=2^-k, and define two possible energies

    E_0(x)=0,
    E_1(x)=-A * 1_C(x),       A=beta^-1 log(1/q), beta>0.

For the ordinary-input mean-square approximation,

    ||E_1-E_0||_L2(mu)^2 = q log(1/q)^2 / beta^2 -> 0.

For each of the k defining coordinates, the mean-square single-bit difference
is 2q A^2; for other coordinates it is zero. Therefore even the *sum* of these
mean-square local sensitivities is

    2 k q log(1/q)^2 / beta^2 -> 0.

Nevertheless, the normalized partition functions obey

    Z_0 = E_mu exp(-beta E_0) = 1,
    Z_1 = 1-q+q exp(beta A) = 2-q.

The free-energy change tends to -beta^-1 log 2, and the true beta-Gibbs mass of
C is 1/(2-q), tending to one half. A candidate that ignores this region has an
order-one thermodynamic error despite arbitrarily small ordinary-input energy
MSE and average sensitivity.

This is not a claim that a fixed bounded-energy, bounded-temperature problem
has the same obstruction: if the energy range stays fixed while q tends to
zero, the region's absolute partition-function contribution tends to zero.
The example explicitly charges an energy depth growing like log(1/q). Such
scales matter when the system's energy range grows with system size, but the
example is a mathematical challenge, not evidence that a particular molecular
system realizes it.

### Task-specific acquisition lower bound

Choose M=1/q disjoint prefix cylinders C_1,...,C_M. The source may be E_0 or any
one E_j=-A*1_(C_j). A procedure that distinguishes Z=1 from Z=2-q with false
reject alpha on E_0 and false accept beta_test on every E_j must, on E_0, hit
each cylinder with probability at least 1-alpha-beta_test. Until the first
hit the exact energy transcript is unchanged. Summing over disjoint cylinders,

    E_0[number of energy queries] >= (1-alpha-beta_test)/q.

This lower bound concerns the particular partition-function operation, not
full source reconstruction. The presence-versus-absence uncertainty is part of
the input contract. If a promise supplied that exactly one well existed with
known size and depth, its normalizer would already be known and this lower
bound would not apply.

By contrast, for an ordinary bounded mu-average, a residual region of mass q
changes the answer by at most its range times q. It can legitimately be ignored
at a coarser tolerance. The appropriate warrant is determined by the requested
operation and its sampling law, not a blanket demand for global completeness.

### The right residual for the thermodynamic operation

For a candidate energy Ehat with obtainable Gibbs sampler pihat and computable
normalizer Zhat, the exact identity is

    Z/Zhat = E_pihat exp[-beta(E-Ehat)].

In particular,

    |Z/Zhat - 1| <= E_pihat |exp[-beta(E-Ehat)] - 1|.

This asks for a transform- and distribution-specific residual warrant rather
than global identification. The candidate sampler, normalizer, exponential
tails, query precision, and residual estimation must all be obtained and
charged. The identity is standard importance sampling, not a new learning
mechanism. The earlier P3 negative comparison against an ordinary tilt remains
relevant; this observation is not a reason to reopen a defeated sampler.

## 4. Strong prior methods and the route-selection consequence

### Sparse/local-query learning

Awasthi, Feldman and Kanade (COLT 2013), Theorem 1, learn sparse real polynomials
under constant log-Lipschitz input distributions using logarithmically local
membership queries. Both a concept-class promise and controlled density change
under local interventions are doing real work. Their target is distributional
prediction, not arbitrary exact class recognition. A new local-structure
proposal with the same inputs must face this tailored baseline.

Brunton, Proctor and Kutz (PNAS 2016) give sparse identification of nonlinear
dynamics. Their scientific examples show why learning equations can enable
prediction outside observed trajectories, while their method explicitly relies
on measurement variables, data quality and a suitable sparsifying library.
Those ingredients are not automatically acquired by sparse regression itself.

### Instrumented reuse

Acar, Blelloch, Blume and Tangwongsan (PLDI 2006) instrument static programs and
retain dynamic dependence graphs plus memoization. Change propagation updates
results after input changes. Initial instrumentation and retained state incur
cost. A trace-based local-certificate proposal must compare to that complete
retaining process, not to repeated from-scratch execution.

### A materially different scientific opportunity

Bonati, Piccini and Parrinello (PNAS 2021) identify an external circularity:
useful slow collective variables are related to transfer-operator modes, but
estimating those modes generally requires long-time dynamics that are hard to
sample before good variables are available. Their Deep-TICA/OPES process learns
variables from an initial biased simulation and then changes sampling to obtain
better information. This is an actual example of partial learned knowledge
making further acquisition possible, without reconstructing every interaction
or certifying a full domain before acting.

The equally informed baseline must include that iterative biased-sampling
process, not ordinary unbiased sampling or an untrained coordinate. Any new
claim should charge the initial biased simulation, training, reweighting,
subsequent trajectories, and the risk of missing an unvisited transition route.
The archived project supplies code and inputs; larger trajectory data are on
Materials Cloud. No such external data were downloaded or used as evaluation
cases in this bounded note. Historical novelty and advantage remain UNKNOWN.

Recommendation: do not commit the branch to exact local-dependency learning
on the strength of a trace interface. It is a sound obtainable interface but
already has powerful retaining-program comparators. A more promising question
is when a learned *sampling/control coordinate* can be justified as sufficient
to improve the next acquisition step, despite an incomplete global model.
The molecular slow-mode circularity supplies an external test and a strong
existing mechanism; a genuine advance must address what that mechanism cannot
yet warrant or acquire.

## Sources and retrieval scope

1. Acar et al., An Experimental Analysis of Self-Adjusting Computation,
   PLDI 2006. Primary PDF read, especially introduction and instrumented-library
   interface: https://www.cs.cmu.edu/~guyb/papers/ABBT06.pdf .
2. Awasthi et al., Learning using Local Membership Queries, COLT 2013.
   Primary PDF read, Definition of log-Lipschitz access and Theorem 1:
   https://jmlr.csail.mit.edu/proceedings/papers/v30/Awasthi13.pdf .
   The proceedings.mlr.press PDF endpoint timed out; mirror supplied the paper.
3. Brunton et al., Discovering governing equations from data by sparse
   identification of nonlinear dynamical systems, PNAS 2016. Primary-author
   hosted PDF read: https://robotics.caltech.edu/wiki/images/a/a3/BPK_PNAS.pdf .
4. Bonati et al., Deep learning the slow modes for rare events sampling,
   PNAS 2021, DOI 10.1073/pnas.2113533118, arXiv:2107.03943.
   Primary abstract/search text and authors' repository read; full PDF retrieval
   failed and PMC returned a browser challenge. No detailed theorem or kinetic
   reweighting claim is attributed to unread full text.
   https://arxiv.org/abs/2107.03943 ;
   https://github.com/luigibonati/deep-learning-slow-modes .
   The repository reports it is archived supporting material and points to
   mlcolvar for maintained software. No repository revision was acquired because
   code was not executed or used for a capability comparison.

No historical novelty is claimed for the trace lemma, partial-coverage bound,
rare-well counterexample, or importance-sampling identity. The present result
is a source-bound interface challenge and a concrete choice of what to test
next, not a simulation or a demonstrated scientific speedup.
