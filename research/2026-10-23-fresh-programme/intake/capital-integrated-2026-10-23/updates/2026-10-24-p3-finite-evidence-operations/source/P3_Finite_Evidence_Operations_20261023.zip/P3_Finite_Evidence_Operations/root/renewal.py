"""Exact partial-information renewal operations, independent root implementation.

Known scientific contract: a genuinely regenerative port in a stationary
controlled process. No bound on hidden-state dimension is supplied or inferred.
This file proves no applicability claim about a real detector or reset.
"""
from fractions import Fraction as F


def exact(v):
    if type(v) not in (int,F):
        raise TypeError('Exact integer/Fraction inputs required')
    return F(v)


def factors(words):
    out={()}
    for w in words:
        w=tuple(w)
        out.update(w[i:j] for i in range(len(w)) for j in range(i+1,len(w)+1))
    return out


def prefixes(words):
    return {tuple(w[:i]) for w in words for i in range(len(w)+1)} | {()}


def endpoint_to_first_return(endpoint):
    q={tuple(w):exact(v) for w,v in endpoint.items()}
    if q.get(()) != 1 or factors(q) != set(q):
        raise ValueError('Endpoint dictionary must be factor-closed with q(empty)=1')
    if any(not 0 <= v <= 1 for v in q.values()):
        raise ValueError('Endpoint probabilities must lie in [0,1]')
    f={}
    for w in sorted(q,key=lambda w:(len(w),w)):
        if w:
            f[w]=q[w]-sum((f[w[:i]]*q[w[i:]] for i in range(1,len(w))),F(0))
    validate_first_return(f)
    return f


def validate_first_return(kernel):
    f={tuple(w):exact(v) for w,v in kernel.items()}
    if () in f or any(not 0<=v<=1 for v in f.values()):
        raise ValueError('Nonempty first-return words need nonnegative probabilities')
    for w in prefixes(f):
        if sum((f.get(w[:i],F(0)) for i in range(1,len(w)+1)),F(0)) > 1:
            raise ValueError('First-return prefix mass exceeds one')
    return f


def lower_endpoint(word,kernel):
    """Sum disjoint event compositions; exact lower response for any word."""
    word=tuple(word)
    f=validate_first_return(kernel)
    longest=max(map(len,f),default=0)
    dp=[F(1)]+[F(0)]*len(word)
    for stop in range(1,len(word)+1):
        dp[stop]=sum((dp[start]*f.get(word[start:stop],F(0))
                      for start in range(max(0,stop-longest),stop)),F(0))
    return dp[-1]


def retained_block_lower(word,endpoint):
    q={tuple(w):max(F(0),exact(v)) for w,v in endpoint.items()}
    if any(v>1 for v in q.values()):
        raise ValueError('Probability bound above one')
    word=tuple(word)
    dp=[F(1)]+[F(0)]*len(word)
    for stop in range(1,len(word)+1):
        dp[stop]=max((dp[start]*q.get(word[start:stop],F(0))
                     for start in range(stop)),default=F(0))
    return dp[-1]


def trie_completion(kernel,alphabet):
    """Attaining finite nonnegative substochastic model for all lower endpoints.

    For direct kernel data the measured dictionary need not be factor-closed.
    Missing first-return words receive zero. Proper prefixes are hidden states;
    leaving the trie loses the trajectory. State zero is the regenerative port.
    """
    f=validate_first_return(kernel)
    alphabet=tuple(alphabet)
    if any(a not in alphabet for w in f for a in w):
        raise ValueError('Unknown action in kernel')
    states={()}|{w[:i] for w in f for i in range(1,len(w))}
    states=sorted(states,key=lambda w:(len(w),w))
    index={w:i for i,w in enumerate(states)}
    def survival(w):
        return 1-sum((f.get(w[:i],F(0)) for i in range(1,len(w)+1)),F(0))
    result={}
    for action in alphabet:
        p=[[F(0) for _ in states] for _ in states]
        for u,col in index.items():
            s=survival(u)
            if s==0:
                continue  # Unreachable state: leave its column zero.
            v=u+(action,)
            p[0][col]=f.get(v,F(0))/s
            if v in index:
                p[index[v]][col]=survival(v)/s
        if any(sum(p[row][col] for row in range(len(states)))>1
               for col in range(len(states))):
            raise AssertionError('Completion is not substochastic')
        result[action]=p
    return states,result


def matrix_endpoint(word,matrices,first_return=False):
    """Exact reference multiplication; first_return kills earlier port visits."""
    if not word:
        return F(0) if first_return else F(1)
    size=len(next(iter(matrices.values())))
    state=[F(1)]+[F(0)]*(size-1)
    for step,action in enumerate(word):
        mat=matrices[action]
        state=[sum((exact(mat[i][j])*state[j] for j in range(size)),F(0))
               for i in range(size)]
        if first_return and step<len(word)-1:
            state[0]=F(0)
    return state[0]


def noisy_endpoint_lower(centers,radii):
    """Conservative formal-inverse certificate, NOT sharp coupled interval fit.

    On the simultaneous event |q(w)-center(w)|<=radius(w), all returned kernel
    entries are lower bounds. The regeneration contract is still required.
    """
    q={tuple(w):exact(v) for w,v in centers.items()}
    eta={tuple(w):exact(v) for w,v in radii.items()}
    if factors(q)!=set(q) or q.get(())!=1 or eta.get(())!=0 or set(q)!=set(eta):
        raise ValueError('Factor closure and exact empty coefficient required')
    if any(v<0 for v in eta.values()):
        raise ValueError('Negative error radius')
    fhat={}
    ebound={}
    lower={}
    for w in sorted(q,key=lambda w:(len(w),w)):
        if not w:
            continue
        fhat[w]=q[w]-sum((fhat[w[:i]]*q[w[i:]]
                          for i in range(1,len(w))),F(0))
        ebound[w]=eta[w]+sum((eta[w[:i]]*abs(fhat[w[i:]])
                             for i in range(1,len(w))),F(0))
        b=ebound[w]+max((ebound[w[i:]] for i in range(1,len(w))),default=F(0))
        lower[w]=max(F(0),fhat[w]-b)
    # On the confidence event prefix feasibility is guaranteed. If it fails,
    # reject observed input rather than issuing a vacuous certificate.
    validate_first_return(lower)
    return lower,fhat,ebound


def coefficient_derivative(word,kernel,queried_word):
    """d [R]_word / d f(queried_word), R=(1-F)^-1; query planning only."""
    word,queried_word=tuple(word),tuple(queried_word)
    if not queried_word:
        raise ValueError('No empty first-return coefficient')
    return sum((lower_endpoint(word[:i],kernel)*
                lower_endpoint(word[i+len(queried_word):],kernel)
                for i in range(len(word)-len(queried_word)+1)
                if word[i:i+len(queried_word)]==queried_word),F(0))


def dyadic_lower_endpoint(word,kernel,bits):
    """Certified fixed-bit backward recursion with additive rounding-loss bound.

    Compared to exact lower_endpoint(word,kernel), loss is at most
    T*(L+1)*2**(-bits). Coefficients round down once, each local sum once.
    Prefix first-return mass<=1 (not suffix mass) controls error propagation.
    """
    if type(bits) is not int or bits<1:
        raise ValueError('Positive integer precision required')
    word=tuple(word)
    f=validate_first_return(kernel)
    scale=1<<bits
    quantized={w:(v.numerator*scale)//v.denominator for w,v in f.items()}
    longest=max(map(len,f),default=0)
    values=[0]*len(word)+[scale]
    max_bits=0
    for start in range(len(word)-1,-1,-1):
        numerator=sum(quantized.get(word[start:stop],0)*values[stop]
                      for stop in range(start+1,min(len(word),start+longest)+1))
        if numerator>scale*scale:
            raise AssertionError('First-return prefix mass contract violated')
        max_bits=max(max_bits,numerator.bit_length())
        values[start]=numerator//scale
    return {'lower':F(values[0],scale),
            'rounding_loss_bound':F(len(word)*(longest+1),scale),
            'max_accumulator_bits':max_bits}
