"""Exact event-reward control over acquired return and hazard tries.

See CONTROL_AND_HAZARD_INTERVALS.md. This is executable algebra, not an
empirical benchmark or a claim that the atomic observation interface exists.
Exact Fraction bit complexity is not constant. The supplied reward and task
callbacks must obey the documented finite observed-task contract.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction as F
import json
from typing import Callable, Hashable, Mapping, Sequence

from atomic_return import rational_table, survival_masses

Word = tuple[str, ...]
Task = Hashable
Transition = Callable[[Task, str, int], Task]
Reward = Callable[[int, Task, str], F | int | str]


def exact(value: F | int | str) -> F:
    if isinstance(value, float):
        raise TypeError("Use Fraction, integer, or rational/decimal string")
    return F(value)


@dataclass
class ControlResult:
    value: F
    # Indexed by (actions remaining, observed prefix, task state).
    policy: dict[tuple[int, Word, Task], str]
    initial_values: dict[tuple[Word, Task], F]
    adversary: dict[tuple[int, Word, Task], F] | None = None


def event_control(
    first: Mapping[Word, F | int | str],
    actions: Sequence[str],
    task_states: Sequence[Task],
    task_initial: Task,
    task_transition: Transition,
    event_reward: Reward,
    horizon: int,
) -> ControlResult:
    """Sharp exact-data robust control via division-free W=sV recursion.

    first includes empty:0 and a factor-closed dictionary of coefficients.
    event_reward(elapsed, z, a) is paid only if the next action returns.
    Off-dictionary no-event continuation has no future event rewards.
    initial_values contains W, not conditional V at non-root histories.
    """
    if horizon < 0 or not actions or task_initial not in task_states:
        raise ValueError("Invalid horizon, actions, or initial task state")
    first = rational_table(first)
    survival_masses(first)  # Includes exact feasibility validation.
    histories = sorted(first, key=lambda w: (len(w), w))
    previous = {(u, z): F(0) for u in histories for z in task_states}
    policy = {}
    for remaining in range(1, horizon + 1):
        elapsed = horizon - remaining + 1
        current = {}
        for u in histories:
            for z in task_states:
                best = F(-1)
                best_action = actions[0]
                for a in actions:
                    child = u + (a,)
                    value = F(0)
                    if child in first:
                        reward = exact(event_reward(elapsed, z, a))
                        if reward < 0:
                            raise ValueError("Event rewards must be nonnegative")
                        z1 = task_transition(z, a, 1)
                        z0 = task_transition(z, a, 0)
                        value = first[child] * (
                            reward + previous[((), z1)]
                        ) + previous[(child, z0)]
                    if value > best:
                        best, best_action = value, a
                current[(u, z)] = best
                policy[(remaining, u, z)] = best_action
        previous = current
    return ControlResult(previous[((), task_initial)], policy, previous)


def rectangular_hazard_control(
    intervals: Mapping[Word, tuple[F | int | str, F | int | str]],
    actions: Sequence[str],
    task_states: Sequence[Task],
    task_initial: Task,
    task_transition: Transition,
    event_reward: Reward,
    horizon: int,
) -> ControlResult:
    """Exact robust DP for visitwise adversarial hazard intervals.

    intervals[w] bounds h(w[:-1], w[-1]); empty is not an edge. All proper
    nonempty prefixes must be present. This is generally a lower relaxation
    of one fixed stationary unknown hazard vector, not its exact solution.
    """
    if horizon < 0 or not actions or task_initial not in task_states:
        raise ValueError("Invalid horizon, actions, or initial task state")
    bounds = {}
    for word, pair in intervals.items():
        word = tuple(word)
        if not word:
            raise ValueError("Empty word is not a hazard edge")
        low, high = map(exact, pair)
        if not 0 <= low <= high <= 1:
            raise ValueError("Invalid hazard interval")
        bounds[word] = (low, high)
    for word in bounds:
        if len(word) > 1 and word[:-1] not in bounds:
            raise ValueError("Hazard dictionary must be prefix-closed")
    histories = [()] + sorted(bounds, key=lambda w: (len(w), w))
    previous = {(u, z): F(0) for u in histories for z in task_states}
    policy = {}
    adversary = {}
    for remaining in range(1, horizon + 1):
        elapsed = horizon - remaining + 1
        current = {}
        for u in histories:
            for z in task_states:
                best = F(-1)
                best_action = actions[0]
                best_hazard = F(0)
                for a in actions:
                    child = u + (a,)
                    value, hazard = F(0), F(0)
                    if child in bounds:
                        reward = exact(event_reward(elapsed, z, a))
                        if reward < 0:
                            raise ValueError("Event rewards must be nonnegative")
                        z1 = task_transition(z, a, 1)
                        z0 = task_transition(z, a, 0)
                        event_value = reward + previous[((), z1)]
                        noevent_value = previous[(child, z0)]
                        low, high = bounds[child]
                        hazard = low if event_value >= noevent_value else high
                        value = (
                            hazard * event_value
                            + (1 - hazard) * noevent_value
                        )
                    if value > best:
                        best, best_action, best_hazard = value, a, hazard
                current[(u, z)] = best
                policy[(remaining, u, z)] = best_action
                adversary[(remaining, u, z)] = best_hazard
        previous = current
    return ControlResult(
        previous[((), task_initial)], policy, previous, adversary
    )


def checks() -> dict[str, object]:
    actions = ("a",)
    states = (0,)
    transition = lambda z, a, e: z
    first = {(): 0, ("a",): F(1, 2), ("a", "a"): F(1, 2)}
    endpoint3 = event_control(
        first, actions, states, 0, transition,
        lambda t, z, a: int(t == 3), 3,
    )
    total3 = event_control(
        first, actions, states, 0, transition, lambda t, z, a: 1, 3
    )
    known3 = rectangular_hazard_control(
        {("a",): (F(1, 2), F(1, 2)), ("a", "a"): (1, 1)},
        actions, states, 0, transition, lambda t, z, a: int(t == 3), 3,
    )
    wide2 = rectangular_hazard_control(
        {("a",): (0, 1), ("a", "a"): (1, 1)},
        actions, states, 0, transition, lambda t, z, a: int(t == 2), 2,
    )
    narrow2 = rectangular_hazard_control(
        {("a",): (F(2, 5), F(3, 5)), ("a", "a"): (1, 1)},
        actions, states, 0, transition, lambda t, z, a: int(t == 2), 2,
    )
    assert endpoint3.value == known3.value == F(5, 8)
    assert total3.value == F(15, 8)
    assert wide2.value == 0
    assert wide2.adversary[(2, (), 0)] == 1
    assert wide2.adversary[(1, (), 0)] == 0
    assert narrow2.value == F(16, 25)

    # This is a recurrence check of the general analytic lower bound, not a
    # searched empirical task or evidence of transfer to a scientific source.
    a0, b0 = F(2, 5), F(99, 100)
    endpoint10 = rectangular_hazard_control(
        {("a",): (a0, F(3, 5)), ("a", "a"): (b0, 1)},
        actions, states, 0, transition, lambda t, z, a: int(t == 10), 10,
    )
    analytic_lower = min(a0, b0) * b0 ** ((10 - 1) // 2)
    assert endpoint10.value >= analytic_lower

    return {
        "scope": "Exact algebraic verification; no empirical benchmark",
        "endpoint_three": str(endpoint3.value),
        "expected_total_three_return_rewards": str(total3.value),
        "known_hazard_and_unnormalized_control_agree": True,
        "stationary_two_step_minimum": "3/4",
        "wide_interval_rectangular_two_step_value": str(wide2.value),
        "wide_interval_root_adversary_at_step_one": "1",
        "wide_interval_root_adversary_at_step_two": "0",
        "narrow_interval_rectangular_two_step_value": str(narrow2.value),
        "ten_step_hazard_certificate": str(endpoint10.value),
        "ten_step_analytic_lower": str(analytic_lower),
    }


if __name__ == "__main__":
    print(json.dumps(checks(), indent=2))
