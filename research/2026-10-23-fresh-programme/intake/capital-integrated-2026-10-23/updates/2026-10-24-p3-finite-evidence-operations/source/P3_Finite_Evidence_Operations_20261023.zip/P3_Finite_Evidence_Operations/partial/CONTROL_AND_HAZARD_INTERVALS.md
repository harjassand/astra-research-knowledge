# Acquired return kernels: control, hazard uncertainty, and a sharp failure

Private Astra P3 theoretical continuation, 2026-10-23. This extends
`ATOMIC_RETURN_KERNELS.md`; it does not replace its access and physical-class
caveats. The constructions and examples below are exact algebraic arguments,
not empirical transfer results. No novelty claim is made over renewal theory,
controlled prefix trees, or robust Markov decision processes.

## 1. A finite acquired library can support sharp robust control

The source is an unknown-dimensional switched nonnegative substochastic
system with a genuinely atomic regenerative port. A return event at an action
boundary restores all future-relevant state. Let f(w) be the first-return
probability along nonempty action word w. Exact endpoint responses on a finite
factor-closed dictionary D determine f on D by renewal deconvolution.

Set F_D(w)=f(w) for w in D and zero otherwise. The earlier note constructs a
finite prefix-history trie whose first-return series is F_D. It matches all
retained endpoint responses and is one simultaneously attaining lower model
for every future open-loop word.

Here is the controlled extension. A policy may choose actions from its entire
observed action/event history, with independent private randomization. Fix a
finite action horizon T. Reward is a sum of nonnegative increments, each paid
at a return-event prefix and determined by observations available at that
prefix. An increment may depend on the previous actions, observed events,
elapsed time and a finite task state. It cannot depend on a future suffix of
the history. A first successful event can be made absorbing in the task
state, so a success probability is included.

For every fixed admissible policy pi,

    J_source(pi) >= J_trie(pi).                                      (1)

The same trie attains (1) for all policies simultaneously. Consequently,

    sup_pi inf_{source compatible with retained endpoint data} J_source(pi)
       = sup_pi J_trie(pi).                                        (2)

There is no source-dimension or finite-rank bound in this statement. The
unknown source can contain arbitrarily many states. What is supplied is the
atomic-port warrant, which the finite table cannot recognize globally.

### Proof by complete event histories

First condition on a policy's entire private random seed. This gives a
deterministic policy on observed histories. Consider an observed history h
whose last observation is a return. Split its actions at all observed returns
into complete excursion words v_1,...,v_m. Its probability is

    product_j f(v_j),

if its actions agree with the policy, and zero otherwise. For a behavioral
policy, the equivalent expression additionally contains the product of the
chosen-action probabilities at the observed prefixes. These policy factors
do not depend on which compatible source is being evaluated.

There is no final survival factor: h ends at a return. Its no-return stretches
are already included in the first-return coefficients. Therefore the
expectation of each nonnegative reward increment is a sum of nonnegative
monomials in f. Replacing every unretained first-return coefficient by zero
can only decrease it. Sum over event times and then integrate over the
policy's random seed. This proves (1).

Extra returns can alter the controller's later actions. A naive pathwise
monotone coupling is therefore not the proof. Comparing the probabilities of
the same complete observed event histories handles adaptive behavior.

The trie is a compatible source. Thus every policy's worst compatible value
equals its trie value, and (2) follows. The conclusion includes policies that
try to learn more from deployment observations: their robust value still
cannot exceed their value on this one compatible trie.

### Why the reward contract matters

If reward is paid merely for no event, the statement fails. A retained lower
model with no returns gives reward one for no event at the first step; a
compatible source that always returns gives zero.

An event reward that is paid only after observing a future event-free suffix
is not a reward determined at the event prefix. It need not be monotone.

Negative action costs also break the argument. A policy may take a costly
action only after an event. A zero-return lower model avoids the cost and can
have value zero, while a compatible source with an additional return makes
the expected value negative. Budgeting the horizon is allowed; inserting
negative costs into (1) without a new argument is not.

## 2. Observable-state Bellman recursion, without rare-state division

Let u be the action prefix since the last return. In the trie, u is observed
from the action/event history, rather than an unidentified hidden state.
Let z belong to a finite task automaton Z, with transition
z_e=tau(z,a,e) for event indicator e. Let r_t(z,a)>=0 be the return reward
for the next action when t actions remain. Define

    s(u) = 1 - sum_{nonempty v prefix of u} f(v),   s(empty)=1.

At a retained edge ua in D with s(u)>0, the return probability is
f(ua)/s(u), and the no-return probability is s(ua)/s(u). Off-dictionary
continuation is sent to a cemetery with no future event rewards. A leaf can
be kept as an observationally empty state until the next action or killed
immediately; the event-reward value is the same.

The usual Bellman recursion is

    V_t(u,z) = max_a {
        [f(ua)/s(u)] [r_t(z,a)+V_{t-1}(empty,z_1)]
      + [s(ua)/s(u)] V_{t-1}(ua,z_0)
    },                                                            (3)

with the off-dictionary action value zero and V_0=0. Zero-survival histories
are unreachable and need no division.

There is a more useful unnormalized form. Put W_t(u,z)=s(u)V_t(u,z).
Since s(empty)=1, (3) becomes

    W_t(u,z) = max_a {
        f(ua) [r_t(z,a)+W_{t-1}(empty,z_1)]
      + W_{t-1}(ua,z_0)
    }.                                                            (4)

Again the off-dictionary action value is zero and W_0=0. Formula (4)
requires no division by a possibly tiny no-return mass. The maximizing
action is unchanged at every reachable history. Zero-survival states have
zero W by induction.

With an explicit trie and task automaton the cost is
O(T |D| |A| |Z|) arithmetic operations, or a smaller edge-based count when
only available edges are scanned. Two value layers take O(|D||Z|) numbers;
retaining the whole time-dependent policy takes
O(T|D||Z| log|A|) bits for action indices in addition to its indexing.
The task-automaton construction, dictionary preprocessing, acquisition,
confidence construction, reward encoding and deployment observations are
separate charged costs. Arbitrary history-dependent rewards are not a free
finite task oracle.

Exact rational arithmetic is an executable verification option, not unit-cost
real arithmetic. For finite-bit evaluation one can instead use the normalized
convex Bellman update with outward interval division, or establish an error
budget for the unnormalized recursion. Avoid claiming that division-free
evaluation alone makes acquisition of tiny probabilities cheap.

### A finite-bit lower policy certificate

Suppose the first-return coefficients and rewards are exact, and every
complete local expression in (4) is rounded down by at most rho, with values
clipped below at zero. The returned value remains a valid lower value by
induction; the selected policy has value at least this computed certificate.
Let L be the maximum dictionary word length. At the root, its possible loss
from exact optimal value is at most T L rho.

To see the error bound, consider the exact maximizing action and subtract
the rounded expression. Repeatedly expand its no-event continuation until
the next return or an off-dictionary edge. There are at most L local rounding
losses. Each reset continuation is multiplied by the corresponding retained
first-return coefficient along the policy's definite no-event branch; these
coefficients sum to at most one. If E_t bounds the worst root loss with at
most t actions left, this yields

    E_t <= L rho + max_{j<t} E_j,

and hence E_t<=t L rho. The same argument for the actions actually selected
shows that the certified value does not exceed that policy's exact value.
Intermediate values need enough integer bits for T times the largest reward.
Rounding or uncertain acquisition of f and reward requires additional error
accounting; this paragraph does not cover those errors automatically.

## 3. Dictionary extension is reusable, with an exact increment identity

If finite factor-closed dictionaries D subset E carry consistent exact
measurements, then their deconvolved coefficients agree on D and
F_D<=F_E coefficientwise. Let Q_D=(1-F_D)^(-1) and Q_E=(1-F_E)^(-1)
as noncommutative formal series. The resolvent identity is

    Q_E-Q_D = Q_E (F_E-F_D) Q_D.                                   (5)

Every coefficient on the right is nonnegative. A newly acquired return
mechanism improves bounds in every left and right context where it can
occur. Equation (1) similarly makes every fixed policy's certified event
reward monotone under dictionary extension, so its optimal robust value
also increases.

This is a genuine reuse/composition statement, but an ordinary retaining
renewal or weighted-automaton implementation obtains exactly the same
benefit with the same evidence. It is not an architectural separation.

## 4. What changes when uncertainty preserves mass

Independent first-return intervals with a feasible coordinatewise lower
vector have a common least trie. Thus the previous sharp robust-control
theorem extends directly if those intervals are the only retained evidence.

Retained joint constraints can remove that least vector. For example,
f(a) in [0.4,0.6] together with f(a)+f(aa)=1 implies

    q(aa)=f(a)^2+1-f(a) >= 3/4.

The coordinatewise lower vector (0.4,0.4) violates the total-mass constraint
and only gives 0.56. It remains a sound lower construction for a relaxation,
but is not the sharp envelope of the actual evidence.

This matters statistically: near a zero-probability defect, estimating total
defect mass can require O(1/epsilon) observations, while subtracting separate
O(1/sqrt(m)) errors from common categories can fabricate an O(1/sqrt(m))
mass deficit. Conditional hazards provide an obtainable representation that
preserves the elementary event/no-event normalization without requiring a
global hidden-state model.

## 5. Acquiring conditional hazards from actual exposures

For a retained history u and next action a, define

    h(u,a) = Pr(return on next action a | no return along u).         (6)

The conditioning event is defined by the prescribed actions in u, starting
at the atomic port. The probability includes any hidden loss that has
already happened: no return is not the same as physical survival. If the
conditioning probability is zero, the hazard is undefined but its history is
unreachable. An arbitrary interval can be assigned there without affecting
the source's event probabilities.

For nonzero conditioning probability,

    f(ua) = h(u,a) product_{v a' prefix of u} [1-h(v,a')].             (7)

Thus the no-event and event probabilities sum to one at every conditional
split. A finite prefix-closed dictionary suffices for direct hazard
acquisition; factor closure was needed to invert endpoint measurements.

### Access contract and counts

To expose h(u,a), prepare/reset at the atomic port, execute u, and stop and
restart the attempt if a return occurs before completing u. If no return
occurs on u, execute a and record its return indicator. Independent trials
or an equivalent warranted regenerative restart produce Bernoulli hazard
observations. The intermediate event readout must be nondisturbing for the
claimed dynamics, or its physical effect must be included in the controlled
process. Endpoint-only access does not supply these observations.

Write

    s(u)=Pr(no return along u)
        = product_{v a' prefix of u} [1-h(v,a')].

If s(u)>0, obtaining n exposures by this restart protocol takes exactly
n/s(u) attempts in expectation. Its expected action count is

    n / s(u) * sum_{j=0}^{|u|} s(u[1:j]),                          (8)

where s(empty)=1. This follows from the expected per-attempt action count
and the renewal reward identity, or Wald's identity applied to independent
attempts stopped at the nth exposed outcome. It is at most
(|u|+1)n/s(u). Readouts are needed at the attempted action boundaries.
The number of physical reset interventions can be smaller when an observed
atomic return itself gives the next prepared state; the trial/observation
count is not thereby free.

Rare conditional histories can therefore be expensive. A chosen-prefix
command is not a conditional-state oracle. Known upper budgets may be
enforced by stopping acquisition and returning a vacuous interval for a
history that has not supplied enough exposures. Without a lower bound on
s(u), there is no finite uniform trial bound for fixed exposure precision.

If K hazards are acquired with fixed exposure quotas n_e, two-sided
Hoeffding intervals of radius

    sqrt(log(2K/delta)/(2 n_e))

give simultaneous coverage at least 1-delta. More suitable binomial
confidence regions can be used, particularly near zero or one. For example,
after n successes and no failures, the lower bound

    h >= delta_e^(1/n)                                             (9)

has one-sided failure probability at most delta_e. Reporting zero if any
failure occurred makes (9) a simple globally valid, though conservative,
procedure. A full exact binomial interval uses the other outcomes too.

Using a random number of exposures with a fixed-n confidence formula after
outcome-dependent stopping is not automatically valid. Fixed exposure quotas,
prespecified trial caps with a vacuous fallback, or valid confidence sequences
avoid that issue. Observations can be shared across prefixes; a strong
retaining baseline retains all the action/event trajectories and shares them
too. Summing separate edgewise acquisition costs is an achievable upper
bound, not an optimal experimental-design claim.

## 6. Exact stationary uncertainty and its tractable rectangular relaxation

Suppose simultaneous intervals l_e<=h_e<=u_e have been acquired on a
finite prefix dictionary. Let H be their Cartesian product. For any fixed
stationary h in H, construct its finite hazard trie and kill off-dictionary
continuation. The trie matches all these hazards. Any compatible original
source with the same h has at least its return-prefix reward for every
policy by the first-return proof.

Therefore the exact robust problem over all compatible unknown-dimensional
sources is

    sup_pi inf_{h in H, fixed for the entire run} J_h(pi).           (10)

No hidden model fitting is necessary to state (10). However, the same
hazard parameter is reused after every return, across task states and time.
An adaptive policy may also acquire information about it during deployment.
General robust control under (10) need not admit a Bellman state consisting
only of current prefix, task state and remaining budget.

The inexpensive relaxation lets an adversary choose h in its interval
separately on every visit, after seeing the current action. Its Bellman step
is

    V_t(u,z) = max_a min_{h in [l_(u,a),u_(u,a)]} {
        h [r_t(z,a)+V_{t-1}(empty,z_1)]
      + (1-h) V_{t-1}(ua,z_0)
    }.                                                            (11)

Off-dictionary continuation has zero future event reward. The inner minimum
is attained at l if the return branch has the larger value, and at u if the
no-return branch has the larger value. Ties allow either endpoint.

Equation (11) is exact for that adversarial interval-MDP model and a sound
lower bound for (10). It has O(T|D||A||Z|) arithmetic cost after acquisition.
It generally fails to preserve the exact stationary-parameter envelope.
With rational interval endpoints and rewards it can be evaluated exactly;
with floating arithmetic, downward outward rounding is necessary for a
numerical lower certificate. Because each update is a convex combination,
rounding each whole update down by at most rho loses at most T rho in value,
separate from interval acquisition and endpoint rounding.

### A minimal time-reuse counterexample

Use one action a, horizon two, and the retained histories a and aa. Let

    h(empty,a)=x in [0,1],    h(a,a)=1.

The source returns at step one with probability x; after a no-return it
returns for certain at the next step. Its two observable-state matrix is

    P_x = [[x, 1-x], [1, 0]].

Pay one only for a return at time two. This is an allowed nonnegative
return-prefix reward. A stationary source gives

    q_2=x^2+(1-x)=(x-1/2)^2+3/4,

so the exact stationary worst case is 3/4. The rectangular adversary sets
x=1 on the first action and x=0 on the second action after the return. It
therefore gives value zero. No single stationary source can attain that
adversarial sequence.

For x in [2/5,3/5], the exact stationary minimum is still 3/4, while (11)
gives

    1 - 3/5 + (2/5)(3/5) = 16/25.

This example has no controller choice and no correlation between different
unknown rows. Only one scalar parameter is reused in time. Horizon one
cannot show a time-reuse gap; a depth-one trie, whose first no-return
terminates all future returns, has nonnegative event rewards that are
monotone in its sole hazard. A second return route is needed. In this sense
the example is minimal.

The gap is not a failure of confidence coverage or of the physical port. It
is the deliberate relaxation of a persistent unknown mechanism into a
time-varying adversary.

### A general width bound, with its cost implication

Let w be the largest acquired hazard interval width, and consider any fixed
policy and a total trajectory payoff in [0,1]. Couple the midpoint stationary
trie with any rectangular-adversary trie. As long as their observed histories
agree, their next event probabilities differ by at most w/2. Use common
policy randomization and maximal Bernoulli coupling. The probability of any
history disagreement by T is at most

    epsilon_T = 1-(1-w/2)^T <= T w/2.

Consequently the stationary robust value and rectangular robust value differ
by at most epsilon_T, for a fixed policy or after optimizing over policies.
For a sum of event rewards bounded by R per step, the corresponding bound
is R times sum_{t=1}^T [1-(1-w/2)^t], at most
R w T(T+1)/4. These are general upper bounds, not sharp for every source.

Uniform small-error approximation can thus require narrow common-category
hazard intervals and quadratic-in-horizon ordinary sampling cost. The
rare-defect certificate below is a weaker but useful objective and avoids
that uniform-accuracy requirement.

## 7. Hazard intervals retain the linear rare-defect certificate

Return to the source family used in the access separation:

    P_gamma = [[1/2, 1/2], [1-gamma, 0]].

Its monitored hazards are

    alpha=h(empty,a)=1/2,   beta=h(a,a)=1-gamma.

For a generic compatible two-edge hazard trie,

    f(a)=alpha,
    f(aa)=(1-alpha) beta,
    defect=1-f(a)-f(aa)=(1-alpha)(1-beta).                           (12)

Even a wide interval for alpha cannot fabricate a defect when beta=1. This
is the statistical advantage of preserving the conditional split. There is
no gain in information over retaining the same multinomial observations.

Suppose acquired intervals guarantee alpha>=a0 and beta>=b0. Under any
stationary or rectangular choice within these intervals, the probability
of a return at time T is at least

    min(a0,b0) * b0^floor((T-1)/2).                                (13)

For a simpler, weaker bound one may replace the exponent by T-1. To prove
(13), before the last action there can be at most floor((T-1)/2) risky
second-step transitions. A first-step transition retains all mass; a
second-step transition retains at least b0 and restores the port. Formal
induction gives survival through n actions at least b0^floor(n/2) from
the port, and b0^ceil(n/2) from the one-step no-return history. Conditional
on not being in the cemetery at time T-1, the last return probability is
at least min(a0,b0). Unknown later returns in the original source can only
increase its allowed event-prefix objective.

### One explicit bounded acquisition procedure

Fix T>=1 and delta in (0,1). Put b=log(4/delta),

    m0 = ceil(200 b),
    N  = ceil(4 T b),
    M  = 4 N.

1. Use m0 independent one-action preparations to estimate alpha. Report
   a0=max(0,alpha_hat-sqrt(b/(2m0))). Its undercoverage probability is at
   most delta/4.
2. Start fresh attempts from the port. Apply a; only if there is no return,
   apply a again and record its return indicator. Collect N second-step
   exposures or stop after M attempts. If the quota is not reached, return
   a vacuous certificate. If all N second-step observations return, set
   b0=exp(-b/N); otherwise set b0=0 for this simple proof procedure.
   The probability of reporting b0 above the true beta is at most delta/4.
3. Return the bound (13), or the larger exact rectangular Bellman bound.

This procedure is valid for every stationary atomic source under the access
contract, not only the two-state family. The bound can be vacuous away from
the zero-defect regime. A full binomial procedure would use all outcomes.

At the null alpha=1/2, beta=1:

- With probability at least 1-delta/4, alpha_hat is no less than
  1/2-sqrt(b/(2m0)); hence a0>=0.4.
- Every acquired second-step exposure is a success, so b0=exp(-b/N).
- The M first-step outcomes expose the second step with probability 1/2.
  A binomial Chernoff bound gives failure to obtain N exposures at most
  exp(-N/4)<=delta/4.
- Since N>=4Tb, even the weaker bound gives
  q_T >=0.4 exp[-b(T-1)/N] >=0.4 exp(-1/4)>0.3.

Thus the confidence statement fails with probability at most delta/2, and
at the null a nontrivial certificate above 0.3 is produced with probability
at least 1-delta/2. The conservative constants leave room within a declared
total delta budget.

Maximum preparation/attempt count is m0+4N, maximum action/readout count
is m0+5N, and expected counts at the null are m0+2N attempts and m0+3N
actions without the cap. All are O(T log(1/delta)). These counts explicitly
include rejected prefix attempts and second-step monitoring. The confidence
parameters, precision of the logarithm/exponential used for b0, and outward
rounding must be charged when implementing a certified finite-bit bound.

The earlier endpoint-only lower bound remains: if measurements are limited
to independent endpoint trials of length at most two, distinguishing gamma=0
from gamma=3/T with fixed confidence requires Omega(T^2) trials. Direct
first-return observation exposes a Bernoulli defect after conditioning and
attains O(T) short trials. This is a comparison between access processes.

If direct length-T endpoint measurements are obtainable, fixed absolute
accuracy needs O(1) resets and O(T) action/time cost at fixed confidence and
accuracy. There is therefore no broad one-target efficiency advantage over
direct long experiments. Repeated transfer tasks or an actual short-trial
experimental restriction may make the retained library useful, but that
application has not been established by this proof.

## 8. Strong incumbents and the remaining scientific issue

A retaining learner that keeps the same event histories, acquires the same
conditional intervals, and constructs the same prefix MDP obtains every
bound above. A learner retaining joint multinomial or likelihood information
can be sharper. A strong stationary-parameter optimizer can exceed the
rectangular value; the explicit two-step example quantifies that difference.
None of these alternatives needs the source's hidden dimension either.

Robust Bellman recursion for rectangular uncertainty is established. Nilim
and El Ghaoui (2005), Section 2.2, explicitly distinguish fixed transition
parameters from time-varying uncertainty, construct statistical uncertainty
under stationarity, and solve the time-varying bound as a relaxation. Their
Sections 3 and 7 treat robust dynamic programming and interval models.
Iyengar (2005) formulates rectangularity and robust dynamic programming.

Primary sources read:

- Arnab Nilim and Laurent El Ghaoui, *Robust Control of Markov Decision
  Processes with Uncertain Transition Matrices*, Operations Research 53(5),
  780-798 (2005), DOI 10.1287/opre.1050.0216. Author-hosted full text:
  https://people.eecs.berkeley.edu/~elghaoui/Pubs/RobMDP_OR2005.pdf
- Garud N. Iyengar, *Robust Dynamic Programming*, Mathematics of Operations
  Research 30(2), 257-280 (2005), DOI 10.1287/moor.1040.0129. Publisher
  abstract was read; the claims used here are its stated rectangularity
  result, not uninspected technical lemmas:
  https://pubsonline.informs.org/doi/abs/10.1287/moor.1040.0129

The acquired representation gives a scoped route from monitored short
experiments to certified longer behavior and event-based control. Its exact
least-model guarantee survives for positive first-return coefficient lower
information. Conditional hazards preserve useful mass information but lose
that universal leastness; stationarity is valuable structure rather than a
free consequence of local robust recursion.

The decisive external uncertainty remains the obtainable port and readout:
a consequential scientific source must provide regeneration of all relevant
state, monitoring that matches the claimed controlled dynamics, and acquisition
costs favorable to its actual task. A coarse signal that hides conformational
or spatial memory does not establish that interface. CTMC embeddability or
other warranted physical restrictions can also strengthen a tailored
baseline; sharpness here is for arbitrary substochastic switched sources.
