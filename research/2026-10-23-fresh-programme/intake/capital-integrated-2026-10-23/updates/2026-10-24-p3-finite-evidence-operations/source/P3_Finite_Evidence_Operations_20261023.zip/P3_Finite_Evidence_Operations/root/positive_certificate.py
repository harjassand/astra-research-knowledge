"""Private P3: exact verifier for a scoped positive-system lower certificate.

This is a geometric-programming certificate, not an architecture claim.
The common two-transient-state contract is assumed, never inferred by this file.
Numerical solvers only propose a tangent and LP support. Every accepted dual and
every logarithm comparison is rechecked with rational arithmetic.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction as F
from math import log
from typing import Sequence


def rational(value, name="value"):
    if type(value) not in (int, F):
        raise TypeError(name + " must be an integer or Fraction, never float")
    return F(value)


@dataclass(frozen=True)
class Constraint:
    """row dot log(x) <= sign * log(base), with rational positive base."""
    row: tuple[int, ...]
    sign: int
    base: F
    label: str = ""

    def __post_init__(self):
        if any(type(v) is not int for v in self.row):
            raise TypeError("Constraint exponents must be exact integers")
        if type(self.sign) is not int or self.sign not in (-1, 1):
            raise ValueError("Constraint sign must be +1 or -1")
        object.__setattr__(self, 'base', rational(self.base, 'constraint base'))
        if self.base <= 0:
            raise ValueError("Constraint base must be positive")


def product_interval(k: int, enter: int, leave: int,
                     lower: F, upper: F, label: str = ""):
    """b_leave*c_enter lies in [lower,upper]. Zero lower adds no log row."""
    lower, upper = rational(lower), rational(upper)
    if type(k) is not int or k <= 0 or any(type(i) is not int or not 0 <= i < k
                                         for i in (enter, leave)):
        raise ValueError("Invalid product coordinates")
    if not (0 <= lower <= upper and upper > 0):
        raise ValueError("Requires a nonempty product interval with positive upper")
    row = [0] * (2 * k)
    row[leave] = 1
    row[k + enter] = 1
    ans = [Constraint(tuple(row), 1, upper, label + ":upper")]
    if lower > 0:
        ans.append(Constraint(tuple(-v for v in row), -1, lower,
                              label + ":lower"))
    return ans


def endpoint_gradient(word: Sequence[int], a: Sequence[F], d: Sequence[F],
                      point: Sequence[F]):
    """Exact q and gradient of log q in log(b_0..b_K,c_0..c_K)."""
    a, d, point = ([rational(v) for v in seq] for seq in (a,d,point))
    k = len(a)
    if k == 0 or any(not 0 <= v <= 1 for v in a+d):
        raise ValueError("Diagonal probability lower bounds must lie in [0,1]")
    if len(d) != k or len(point) != 2 * k or min(point) <= 0:
        raise ValueError("Invalid positive tangent point")
    if any(type(i) is not int or not 0 <= i < k for i in word):
        raise ValueError("Invalid action index")
    state = [F(1), F(0)]
    deriv = [[F(0), F(0)] for _ in point]
    for action in word:
        b, c = point[action], point[k + action]
        old = state
        state = [a[action] * old[0] + b * old[1],
                 c * old[0] + d[action] * old[1]]
        deriv = [[a[action] * v[0] + b * v[1],
                  c * v[0] + d[action] * v[1]] for v in deriv]
        deriv[action][0] += b * old[1]
        deriv[k + action][1] += c * old[0]
    q = state[0]
    if q <= 0:
        raise ValueError("Log certificate has no positive path; use bound zero")
    return q, tuple(v[0] / q for v in deriv)


def solve_exact_columns(columns, rhs):
    """Solve overdetermined rational linear equations, free variables set zero."""
    n = len(columns)
    rows = [[F(columns[j][i]) for j in range(n)] + [F(rhs[i])]
            for i in range(len(rhs))]
    pivots = []
    row = 0
    for col in range(n):
        p = next((i for i in range(row, len(rows)) if rows[i][col]), None)
        if p is None:
            continue
        rows[row], rows[p] = rows[p], rows[row]
        factor = rows[row][col]
        rows[row] = [x / factor for x in rows[row]]
        for i in range(len(rows)):
            if i != row and rows[i][col]:
                factor = rows[i][col]
                rows[i] = [x - factor * y for x, y in zip(rows[i], rows[row])]
        pivots.append((row, col))
        row += 1
    if any(not any(v[:-1]) and v[-1] for v in rows):
        raise ValueError("Exact dual support is inconsistent")
    result = [F(0)] * n
    for row, col in pivots:
        result[col] = rows[row][-1]
    return result


def propose_dual(constraints: Sequence[Constraint], gradient: Sequence[F]):
    """Numerical support search followed by exact solve; may return no certificate."""
    import numpy as np
    from scipy.optimize import linprog
    cost = [r.sign * log(float(r.base)) for r in constraints]
    matrix = np.array([r.row for r in constraints], dtype=float).T
    lp = linprog(cost, A_eq=matrix, b_eq=-np.array(gradient, dtype=float),
                 bounds=(0, None), method="highs")
    if not lp.success:
        raise ValueError("Numerical dual proposal failed: " + lp.message)
    support = [i for i, v in enumerate(lp.x) if v > 1e-9]
    values = solve_exact_columns([constraints[i].row for i in support],
                                 [-v for v in gradient])
    dual = [F(0)] * len(constraints)
    for i, v in zip(support, values):
        dual[i] = v
    verify_dual(constraints, gradient, dual)
    return dual


def verify_dual(constraints, gradient, dual):
    gradient=[rational(v,'gradient') for v in gradient]
    dual=[rational(v,'dual multiplier') for v in dual]
    if len(dual) != len(constraints) or any(v < 0 for v in dual):
        raise ValueError("Dual must be nonnegative and complete")
    if any(len(row.row) != len(gradient) for row in constraints):
        raise ValueError("Dual dimensions differ")
    for j, g in enumerate(gradient):
        if g + sum((v * row.row[j] for v, row in zip(dual, constraints)), F(0)):
            raise ValueError("Nonzero exact stationarity residual")


def verify_feasible(point, constraints):
    """Exact monomial check prevents an empty log polyhedron proving anything."""
    point=[rational(v,'feasibility coordinate') for v in point]
    if not point or min(point) <= 0:
        raise ValueError("Feasibility witness must be positive")
    for row in constraints:
        if len(row.row) != len(point) or row.sign not in (-1, 1) or row.base <= 0:
            raise ValueError("Malformed logarithmic constraint")
        lhs = F(1)
        for x, power in zip(point, row.row):
            lhs *= x ** power
        if lhs > row.base ** row.sign:
            raise ValueError("Feasibility witness violates " + row.label)


def _unit_log_interval(x: F, bits: int):
    """1<=x<=2. Positive atanh series with an exact geometric tail bound."""
    if not F(1) <= x <= F(2):
        raise ValueError("Range reduction failure")
    u = (x - 1) / (x + 1)
    total, power, n = F(0), u, 0
    tolerance = F(1, 1 << bits)
    while True:
        total += 2 * power / (2 * n + 1)
        n += 1
        power *= u * u
        tail = 2 * power / ((2 * n + 1) * (1 - u * u))
        if tail <= tolerance:
            return total, total + tail, n


def log_interval(x: F, bits: int = 60):
    """Return exact rational lower, upper, and total series term count."""
    x=rational(x,'log argument')
    if type(bits) is not int or bits < 1:
        raise ValueError("Positive integer precision required")
    if x <= 0:
        raise ValueError("Log argument must be positive")
    exponent = x.numerator.bit_length() - x.denominator.bit_length()
    scale = F(1 << exponent) if exponent >= 0 else F(1, 1 << -exponent)
    y = x / scale
    if y < 1:
        y *= 2
        exponent -= 1
    if y > 2:
        y /= 2
        exponent += 1
    extra = (abs(exponent) + 1).bit_length()
    lo, hi, terms = _unit_log_interval(y, bits + extra)
    if exponent:
        l2, u2, count = _unit_log_interval(F(2), bits + extra)
        terms += count
        lo += exponent * (l2 if exponent > 0 else u2)
        hi += exponent * (u2 if exponent > 0 else l2)
    return lo, hi, terms


def verify_threshold(word, a, d, point, constraints, dual, threshold, bits=60,
                     feasible_point=None):
    """Certify q_true(word)>=threshold; validity is conditional on input bounds.

    Data confidence/model applicability are not supplied or checked by this
    algebraic verifier. No claim is made merely because the primal is infeasible.
    """
    point=[rational(v,'tangent coordinate') for v in point]
    threshold=rational(threshold,'threshold')
    if not F(0) < threshold <= F(1):
        raise ValueError("Probability threshold outside (0,1]")
    verify_feasible(point if feasible_point is None else feasible_point, constraints)
    q, grad = endpoint_gradient(word, a, d, point)
    verify_dual(constraints, grad, dual)
    terms = [(F(1), q), (F(-1), threshold)]
    terms += [(-g, x) for g, x in zip(grad, point)]
    terms += [(-v * row.sign, row.base) for v, row in zip(dual, constraints)]
    lo, hi, count = F(0), F(0), 0
    for coefficient, argument in terms:
        if coefficient:
            lower, upper, n = log_interval(argument, bits)
            count += n
            lo += coefficient * (lower if coefficient > 0 else upper)
            hi += coefficient * (upper if coefficient > 0 else lower)
    return {"certified": lo >= 0, "log_margin_lower": lo,
            "log_margin_upper": hi, "series_terms": count,
            "q_at_tangent": q, "gradient": grad}


def retained_block_bound(word, responses):
    """Strong simple baseline: best product over all retained block partitions."""
    responses={key:max(F(0),rational(value,'response bound'))
               for key,value in responses.items()}
    if any(value > 1 for value in responses.values()):
        raise ValueError("Probability lower bound greater than one")
    dp = [F(1)] + [F(0)] * len(word)
    for end in range(1, len(word) + 1):
        dp[end] = max((dp[start] * responses.get(tuple(word[start:end]), F(0))
                       for start in range(end)), default=F(0))
    return dp[-1]
