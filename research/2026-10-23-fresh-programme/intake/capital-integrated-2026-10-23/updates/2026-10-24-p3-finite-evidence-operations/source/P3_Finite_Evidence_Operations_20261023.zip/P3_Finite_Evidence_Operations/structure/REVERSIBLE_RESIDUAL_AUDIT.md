# Audit of correlation-acquired residuals for composed interventions

Private P3 structure/access worker, 23 October 2026. The parent owns the
construction and finite-bit implementation. This note independently checks
the information interface, gives a task-specific refinement, and identifies
close prior work. No new matrix benchmark or physical experiment was run.

## 1. Exact interface and orientation

Let each action P_a be a bounded self-adjoint contraction on the same real
Hilbert space L2(pi). A continuous-time reversible Markov pulse with the same
stationary law for every action is sufficient. Operator positivity is useful
for additional moment constraints but is not required for the residual bound.
Let f be the observed real function. It need not be a microscopic state
indicator. Define

~~~
P_w=P_(a1)...P_(ak),     q(w)=<f,P_w f>,
v_w=P_w f.
~~~

For a selected finite word list W, let V have columns v_w. Then

~~~
G_uv = <v_u,v_v>       = q(reverse(u) v),
H_a(u,v)=<v_u,P_a v_v> = q(reverse(u) a v),
J_a(u,v)=<P_a v_u,P_a v_v>
                       = q(reverse(u) a a v).
~~~

These equalities are exact and include all hidden dimensions. A scalar
stationary pulse-correlation experiment measures each entry. Reversing
an action order uses the same forward pulses; there is no negative-time
operation and no need to clone a hidden state.

Products must have a documented convention. Starting from f and applying
left updates in chronological order a1,...,ak produces P_(ak)...P_(a1)f.
For an f-to-f correlation, q(w)=q(reverse(w)), so either direction gives
the same scalar. General cross-observable forecasts do not have this
automatic symmetry; reverse the loop or explicitly use the right product.

Common stationarity alone gives Markov contraction in L2(pi), by Jensen's
inequality and invariance. Common reversibility supplies the physically
accessible adjoints needed in the displayed acquisition formulas.
Separate reversible laws pi_a are insufficient: the common inner product
and the reverse-word identity can fail when switching.

## 2. The original local residual certificate is sound

Suppose G is positive definite and let Pi=V G^(-1) V*. Define

~~~
T_a=G^(-1)H_a,
K_a=J_a-H_a*G^(-1)H_a.
~~~

Then K_a=V*P_a*(I-Pi)P_a V is positive semidefinite, and

~~~
||(I-Pi)P_a Vz||²=z*K_a z.
~~~

For an approximate state Vz_t evolved by z_(t+1)=T_a z_t, contraction
and the triangle inequality yield

~~~
||x_(t+1)-Vz_(t+1)||
 <= ||x_t-Vz_t|| + sqrt(z_t*K_a*z_t).
~~~

If f is included as the empty-word column and used as the initial state,
the initial error is zero. Taking an inner product with f gives the
parent's endpoint error bound. The claim concerns that acquired span and
the chosen action set. It makes no assertion that the hidden physical
system has dimension |W|, that every relevant observable is represented,
or that the physical model class has been recognized.

K_a=0 for every action certifies exact invariance of this span, when the
input is exact. Finite noisy data generally yield only a residual upper
bound; they do not certify a mathematical zero. That approximate statement
is enough for finite target protocols if its full error bound is small.

## 3. Strong prior: the residual and forecast accumulation already exist

Stochastic ResDMD defines an extra matrix of inner products of propagated
dictionary functions. Colbrook, Li, Raut and Townsend use it to compute
full-space residuals and sum propagated residuals to bound forecast error:
their equations (29)–(30) are the direct one-action counterpart of the
parent's residual and telescoping bound. Section 3.2 distinguishes ordinary
snapshot residuals, which contain stochastic variance, from the desired
conditional-mean residual; two independent outcomes from each initial
state acquire the latter. The paper also treats finite-data estimation.
[Primary paper, sections 3.2 and 4.2–4.3](https://arxiv.org/html/2308.10697v3).

Thus the mathematical residual theorem should not be presented as a
foundational invention. The possible interface contribution is acquiring
that information for implicit word functions through reversible scalar
correlations, without observing the hidden state or restarting from it.
Its historical novelty remains UNKNOWN after this bounded check.

Additional strong baselines already cover nearby tasks:

| Baseline | Relevant capability and access distinction |
|---|---|
| [Nüske et al., Finite-Data Error Bounds for Koopman-Based Prediction and Control](https://link.springer.com/article/10.1007/s00332-022-09862-1) | Finite-data approximation/prediction analysis, including controlled generators and ergodic or independent data. Its displayed dictionary evaluation and sampling assumptions must be compared with the scalar pulse interface. |
| [Petreczky, Wisniewski, Leth, Balanced truncation for linear switched systems](https://arxiv.org/pdf/1302.0221) | Switched-system reduction with input-output error bounds from common Gramian/LMI structure. It uses explicit system/Gramian information and is not a free substitute for acquiring unknown pulse correlations. |
| [Bastug et al., Model Reduction by Moment Matching for Linear Switched Systems](https://arxiv.org/abs/1403.1734) | Word-selected reachability/observability subspaces and partial realization are established reduction mechanisms. Only its primary abstract was read in this bounded check. |

An equally informed retaining learner can store the same correlations and
execute the same Galerkin/residual algorithm. This is not an architectural
separation from retained programs or libraries.

## 4. Goal-specific improvement: an error must return to the observed span

For the scalar endpoint task there is a stronger estimate than the
one-sided state norm. First consider exact Galerkin projections.
Write a target in explicit matrix order

~~~
q=<f,A1 A2 ... AT f>.
~~~

Let projected left states satisfy u_0=f, u_i=Pi A_i u_(i-1).
Let projected right states satisfy v_T=f, v_(j-1)=Pi A_j v_j.
Define

~~~
rho_i^L=||(I-Pi)A_i u_(i-1)||,
rho_j^R=||(I-Pi)A_j v_j||.
~~~

All these norms use the acquired K matrices. Then

~~~
|q-qhat|
 <= sum_(j=1)^T rho_j^R * sum_(i<j) rho_i^L.       (1)
~~~

Here qhat=<f,v_0>. To prove (1), telescope the right approximation:

~~~
q-qhat
 = sum_j <x_(j-1)^L, A_j v_j-v_(j-1)>,
x_(j-1)^L=A_(j-1)...A1 f.
~~~

The right defect is orthogonal to the span, so its inner product with
u_(j-1) vanishes. The remaining factor is bounded by

~~~
||x_(j-1)^L-u_(j-1)|| <= sum_(i<j)rho_i^L.
~~~

Contraction proves the last inequality. This gives (1), including the
correct zero error for every exact one-step endpoint. For uniformly
bounded residual squares kappa, its worst-case dependence is O(T²*kappa),
instead of O(T*sqrt(kappa)). It is a goal-oriented residual argument,
not a claim of new numerical-analysis theory.

## 5. Finite-noise-safe version for arbitrary fitted matrices

Using an estimated T_a breaks exact Galerkin orthogonality. Omitting that
defect would make (1) false even for a one-step target. A useful exact
certificate does not need the true inverse G^(-1), however.

Let T_a be ANY real fitted matrices of the appropriate size, and define

~~~
R_a(T)=J_a-H_a* T_a-T_a* H_a+T_a*G T_a,
D_a=H_a-G T_a.
~~~

R_a(T)=(P_a V-VT_a)*(P_a V-VT_a) is positive semidefinite.
If the empty-word column is indexed by e0, set

~~~
ell_0=e0,     ell_i=T_(a_i) ell_(i-1),
r_T=e0,       r_(j-1)=T_(a_j) r_j,
qhat=<f,V r_0>.
~~~

The exact state defect norms are

~~~
(rho_i^L)²=ell_(i-1)* R_(a_i)(T) ell_(i-1),
(rho_j^R)²=r_j* R_(a_j)(T) r_j.
~~~

Then the following bound is valid without invertibility of G:

~~~
|q-qhat|
 <= sum_j |ell_(j-1)* D_(a_j) r_j|
      + sum_j rho_j^R * sum_(i<j)rho_i^L.          (2)
~~~

Proof: use the same right telescoping identity, but split its left
argument as x_(j-1)^L=V ell_(j-1)+error. The first contribution is
exactly ell_(j-1)*D_(a_j)r_j. The second is bounded by the accumulated
left state defect and the right defect norm. This proof does not require
T_a to be self-adjoint in the true Gram metric.

Once fitted T and target coefficients are fixed, every squared residual
and each D bilinear form is affine in G,H,J. A simultaneous confidence
box for those entries therefore certifies all of them, even when T was
chosen from the same data. One must also include uncertainty in qhat,
whose readout is a row of G, and in ||f|| for a one-sided bound.
Choosing the dictionary or queried entries adaptively requires the
confidence procedure to cover that selection.

For example, with entrywise absolute errors eta_G, eta_H, eta_J, the
error in a residual-square evaluation at z is at most

~~~
eta_J*||z||_1²
 + 2*eta_H*||T_a z||_1*||z||_1
 + eta_G*||T_a z||_1².                            (3)
~~~

The corresponding D scalar error at (ell,z) is at most

~~~
eta_H*||ell||_1*||z||_1
 + eta_G*||ell||_1*||T_a z||_1.
~~~

Thus finite-bit verification can use fixed rational T, rational interval
arithmetic, and safe square-root upper bounds. Poor Gram conditioning
may cause large fitted coefficients and a poor certificate, but it does
not invalidate (2)–(3). The parent is implementing independently.

### Parent refinement: correct the center before taking intervals

The exact identity underlying (2) is stronger than its triangle-inequality
version. Define the corrected affine prediction

~~~
q_corr = <f,V r_0> + sum_j ell_(j-1)*D_(a_j)r_j.
~~~

Then

~~~
|q-q_corr| <= sum_j rho_j^R * sum_(i<j)rho_i^L.    (4)
~~~

The proof above gives the signed identity directly: the remainder consists
of inner products of true left errors and approximate right defects.
The parent proposed retaining that signed correction and combining its
coefficients before interval evaluation. This is sound and can be
substantially tighter than summing absolute D contributions.

In particular, all repeated occurrences of a measured q(w) must refer to
one quantity. For real self-adjoint actions, q(w)=q(reverse(w)); combine
these coefficients under one canonical word. An exact cancellation then
requires no confidence penalty. For a one-action target the corrected
affine form reduces identically to the measured q(a), with zero residual
remainder. This is a useful implementation boundary check.

Residual-corrected outputs and paired primal/dual errors are established
goal-oriented numerical analysis. Grepl and Patera's primary paper develops
adjoint output error estimation for reduced parabolic models:
[paper record and primary abstract](https://www.numdam.org/articles/10.1051/m2an:2005006/).
The publisher PDF was blocked during this bounded check, so no specific
equation in that paper is claimed to be the exact switched-correlation
formula above. The independently displayed derivation establishes (4).

## 6. Explicit failures when the common-metric contract is removed

These are short analytic counterexamples, not an additional evaluated
matrix fixture set.

**Stationarity without reversibility.** Consider the strictly positive-rate
three-state directed-cycle generator

~~~
L=[[-3,2,1],[1,-3,2],[2,1,-3]]
~~~

with uniform stationary distribution, and any nonzero centered real f.
On the centered plane, its symmetric part is -(9/2)I and its skew part
has rotation frequency sqrt(3)/2. Consequently

~~~
||exp(tL)f||² = exp(-9t)*||f||²,
<f,exp(2tL)f> = exp(-9t)*cos(sqrt(3)*t)*||f||².
~~~

At t=pi/sqrt(3) these have opposite signs. Thus the proposed twice-forward
pulse does not measure the positive residual Gram J. An actually available
adjoint/reversed-dynamics intervention could replace self-adjointness, but
its existence and cost are an additional access contract.

**Separate reversibility without common stationarity.** The two-state pulse

~~~
B=[[19/20,1/20],[9/20,11/20]]
~~~

is the time-log(2) semigroup of rates 1/10 and 9/10. It is reversible with
pi_B=(9/10,1/10). Suppose the reference metric is instead uniform, as for
a separate symmetric two-state intervention. For f=(1,0),

~~~
||f||_uniform²=1/2,
||Bf||_uniform²=221/400 > 1/2,
<f,B²f>_uniform=37/80 != 221/400.
~~~

So both the common contraction assertion and the forward-pulse Gram
identity can fail. Preparing each intervention's own equilibrium does not
repair a cross-action product: its correlations then belong to different
inner products.

**A coarse label does not warrant the metric.** Agreement of finitely many
forward/reversed pulse correlations can detect some violations but cannot
establish reversibility of every hidden state. The contract must follow
from the intervention design or other independently justified physical
information. The construction acquires a residual inside that contract;
it does not acquire arbitrary membership in the contract.

## 7. The physical and statistical costs still decide usefulness

The common equilibrium condition can be justified by an algorithm that
enforces detailed balance with a fixed target distribution. In a physical
system, changing kinetic barriers or mobilities while preserving the same
energy landscape can fit the contract. Changing temperature or potential
typically changes equilibrium; generic interventions are not covered.
For example, the formally symmetric diffusion generator

~~~
L_a g = pi^(-1) div(pi M_a grad(g))
~~~

with symmetric positive mobility M_a and appropriate boundary conditions
shares pi. This is a sufficient mathematical design, not evidence that
such controls have been acquired on an external physical system.

The observed coarse process need not be Markov, but its full latent process
must follow the common operators across all protocols. Preparation,
stationarity, measurement disturbance, and action drift remain interface
warrants. A single prepared stationary run can supply unbiased endpoint
correlations under switching because every pulse preserves pi; repeated
samples from that run remain dependent.

The naive cost can be severe. Ignoring coefficient growth, fixed confidence
and near-invariance, the one-sided bound demands squared-residual precision
of order epsilon²/T², giving ordinary bounded-average sample counts of
order T^4/epsilon^4. The goal-specific bound may reduce the precision
demand to order epsilon/T² and the corresponding count to
T^4/epsilon². These are scaling cautions for a particular conservative
construction, not lower bounds or complete cost comparisons.

Each of roughly O(|W|²*number_of_actions) distinct entries can require a
protocol of length up to twice the longest dictionary word plus two.
Duplicates can be shared. Acquisition, failed dictionary search, stationary
sampling, confidence, fitting, and certificate computation must all be
charged. Direct execution of one target word remains a strong baseline.
An information-equivalent ResDMD/moment learner can also use every cross
measurement; it should not be restricted to isolated data.

The useful next question is therefore the one the parent is pursuing:
can this obtainable interface certify many consequential new protocols
at a lower complete cost than direct experiments and equally informed
retaining reduction methods? The exact residual theorem alone does not
answer that question.

## 8. Bounded independent code audit

Before opening the parent's implementation or its results, I froze the
algebraic boundary checks in CORRELATION_AUDIT_CONTRACT.json:

~~~
SHA256 f1e3b5e568ee1b4cb1bb9591cce75d51ab1705ef660a997f1c0ef7a21ac468a4
~~~

The reviewed implementation was root/correlation_certificate.py:

~~~
SHA256 8c03a5841c8cbbe40112b0b61591b406749479103edc63cf5b2a0fcf4bafc798
~~~

I independently checked the product orientation, arbitrary-T identity,
reverse-word canonicalization, sign handling in interval evaluation,
outward dyadic square root, and the common-event argument for data-selected
fits and target words. No mathematical or API validity bug was found.

The frozen checks were then executed by audit_correlation_certificate.py,
using direct rational matrix endpoints for the few physical boundary
sources rather than root's form machinery. All 27 assertions passed,
and the root file hash remained unchanged. CORRELATION_AUDIT_RESULTS.json
preserves every assertion and its result.

The checks cover an empty target; exact one-step cancellation despite
uncertainty in C(empty); a singular true Gram matrix from distinct feature
words with a deliberately poor, signed candidate T; a legal negative mixed
correlation; rejection of wholly negative residual-square intervals and
empty input intervals; safe intervals crossing zero; dyadic square-root
direction; intersection/cancellation of reversed protocols; and rejection
of incompatible reversed intervals and nonexact float/bool inputs.

These were authored adversarial boundary cases, not unseen scientific
systems. Their prior exposure and selection time are recorded in the
contract. The audit does not recognize the physical access class, establish
historical novelty, compare complete acquisition cost, or prove transfer.
No further fixture expansion is justified by this completed validity audit.

