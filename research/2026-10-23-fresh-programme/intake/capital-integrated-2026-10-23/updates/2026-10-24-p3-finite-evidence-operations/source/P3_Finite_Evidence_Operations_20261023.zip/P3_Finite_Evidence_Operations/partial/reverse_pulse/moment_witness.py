"""Exact moment certificates and finite reversible-source witnesses.

No benchmark, simulation, fitted source, or physical measurement is supplied.
The matrices are adversarial witnesses to the explicit information contract
in MOMENT_SHARPNESS.md. Fraction arithmetic has nonconstant bit complexity.
The CTMC embedding is established analytically by commuting generators; a
floating matrix logarithm is deliberately not used to establish existence.
"""

from __future__ import annotations

from fractions import Fraction as F
from itertools import product
import json


def pair_sum(lam: F, horizon: int) -> F:
    if horizon < 2:
        return F(0)
    if lam == 1:
        return F(horizon * (horizon - 1), 2)
    return (
        1 - horizon * lam ** (horizon - 1)
        + (horizon - 1) * lam**horizon
    ) / (1 - lam) ** 2


def moment_bounds(lam: F, variance: F, horizon: int) -> tuple[F, F]:
    """Sharp [0,1]-spectral moment interval for integer horizon>=3."""
    if not 0 < lam < 1 or not 0 <= variance <= lam * (1 - lam):
        raise ValueError("Infeasible mean or variance")
    if horizon < 3:
        raise ValueError("Use the known input moments at horizons 0,1,2")
    x = lam - variance / (1 - lam)
    y = lam + variance / lam
    p = variance / ((1 - lam) ** 2 + variance)
    q = lam**2 / (lam**2 + variance)
    return q * y**horizon, p + (1 - p) * x**horizon


def pulse_from_modes(weights: tuple[F, ...], modes: tuple[F, ...], mix: F):
    """Return P,pi,f with correlation sum_k weights[k]*modes[k]**N.

    Requires 0<modes[k]<mix<1. P is strictly positive, reversible, and has
    finite irreducible CTMC generator diag(Q_(mode/mix))+(-log mix)(Pi-I).
    """
    if len(weights) != len(modes) or sum(weights) != 1:
        raise ValueError("Invalid mode weights")
    if not all(w > 0 for w in weights):
        raise ValueError("Weights must be strictly positive")
    if not 0 < mix < 1 or not all(0 < theta < mix for theta in modes):
        raise ValueError("Modes must lie strictly between zero and mix")
    n = 2 * len(weights)
    pi = tuple(w / 2 for w in weights for _ in (0, 1))
    f = tuple(F(sign) for _ in weights for sign in (1, -1))
    block = [[F(0) for _ in range(n)] for _ in range(n)]
    for k, theta in enumerate(modes):
        t = theta / mix
        for i in (0, 1):
            for j in (0, 1):
                block[2*k+i][2*k+j] = (1 + (t if i == j else -t)) / 2
    pulse = tuple(tuple(
        mix * block[i][j] + (1 - mix) * pi[j]
        for j in range(n)
    ) for i in range(n))
    assert all(sum(row) == 1 for row in pulse)
    assert all(entry > 0 for row in pulse for entry in row)
    assert all(
        pi[i] * pulse[i][j] == pi[j] * pulse[j][i]
        for i in range(n) for j in range(n)
    )
    assert sum(pi[i] * f[i] for i in range(n)) == 0
    return pulse, pi, f


def correlations(pulse, pi, f, horizon):
    vector = f
    result = []
    for _ in range(horizon + 1):
        result.append(sum(pi[i] * f[i] * vector[i] for i in range(len(f))))
        vector = tuple(
            sum(pulse[i][j] * vector[j] for j in range(len(f)))
            for i in range(len(f))
        )
    return result


def observed_triples(pulse, pi, f):
    out = {signs: F(0) for signs in product((-1, 1), repeat=3)}
    for i, j, k in product(range(len(f)), repeat=3):
        out[(int(f[i]), int(f[j]), int(f[k]))] += (
            pi[i] * pulse[i][j] * pulse[j][k]
        )
    return out


def moment_triples(first, second):
    return {
        (a, b, c): (1 + first * (a*b + b*c) + second * a*c) / 8
        for a, b, c in product((-1, 1), repeat=3)
    }


def fixed_equilibrium_family_parameters(variance, slow_mode):
    """Exact 6-state family data; paired fast modes are m±sqrt(squared).

    Check all needed positivity inequalities without approximating the square
    root. The first two moments and integrated correlation are rational.
    """
    if not 0 < variance <= F(1, 64) or not F(7, 8) <= slow_mode < 1:
        raise ValueError("Outside the proof's simple parameter range")
    p = variance / (2 * (F(1, 4) + variance))
    m = (F(1, 2) - p * slow_mode) / (1 - p)
    squared = (
        variance - p * ((slow_mode - F(1, 2))**2 + variance)
    ) / (1 - p)**2
    assert squared > 0 and m > 0 and m*m > squared
    assert slow_mode > m and (slow_mode - m)**2 > squared
    mean = p * slow_mode + (1 - p) * m
    second = p * slow_mode**2 + (1 - p) * (m*m + squared)
    total = (
        p / (1 - slow_mode)
        + (1 - p) * (1 - m) / ((1 - m)**2 - squared)
    )
    assert mean == F(1, 2) and second == F(1, 4) + variance
    assert total >= p / (1 - slow_mode)
    return {
        "fixed_slow_weight": p,
        "remaining_mode_midpoint": m,
        "remaining_mode_halfspacing_squared": squared,
        "integrated_correlation_from_time_zero": total,
    }


def run_checks():
    eps = F(1, 64)
    log_ceiling = 0
    while F(1, 2**log_ceiling) > eps:
        log_ceiling += 1
    horizon = log_ceiling + 2
    lam = F(1, 2)
    slow = 1 - F(1, horizon**2)
    fast = lam - eps / (slow - lam)
    weight = eps / ((slow - lam)**2 + eps)
    mix = (1 + slow) / 2
    weights = (weight, 1 - weight)

    alt, pi, f = pulse_from_modes(weights, (slow, fast), mix)
    null, pi_null, f_null = pulse_from_modes(weights, (lam, lam), mix)
    assert pi == pi_null and f == f_null
    alt_corr = correlations(alt, pi, f, horizon)
    null_corr = correlations(null, pi, f, horizon)
    assert alt_corr[:3] == [1, lam, lam**2 + eps]
    assert null_corr == [lam**n for n in range(horizon + 1)]
    assert alt_corr[horizon] == weight * slow**horizon + (1-weight) * fast**horizon

    alt_law = observed_triples(alt, pi, f)
    null_law = observed_triples(null, pi, f)
    assert alt_law == moment_triples(lam, lam**2 + eps)
    assert null_law == moment_triples(lam, lam**2)
    chi_square = sum((alt_law[s] - null_law[s])**2 / null_law[s] for s in null_law)
    assert chi_square == F(16, 9) * eps**2
    gap = alt_corr[horizon] - null_corr[horizon]
    assert gap >= F(207, 68) * eps > 2 * eps

    lower, upper = moment_bounds(lam, eps, horizon)
    residual_bound = eps * pair_sum(lam, horizon)
    assert lower <= alt_corr[horizon] <= upper
    assert upper - lam**horizon <= residual_bound
    assert pair_sum(lam, horizon) <= 1 / (1-lam)**2

    # A separate exactly moment-matched finite-CTMC pair, not just the
    # slightly separated moments used for the statistical lower bound.
    p = 4 * eps / (1 + 4 * eps)
    q = 1 - p
    a, r = F(1, 4), F(99, 100)
    x, y = lam - 2*eps, lam + 2*eps
    plus, pi2, f2 = pulse_from_modes((p, q), (r, r*(a+(1-a)*x)), F(199, 200))
    minus, pi3, f3 = pulse_from_modes((p, q), (r*a, r*(a+(1-a)*y)), F(199, 200))
    # The helper uses a larger mixing factor than r: this leaves the desired
    # readout eigenvalues unchanged and keeps all block generators finite.
    assert pi2 == pi3 and f2 == f3
    plus_corr = correlations(plus, pi2, f2, 8)
    minus_corr = correlations(minus, pi3, f3, 8)
    assert plus_corr[:3] == minus_corr[:3]
    assert observed_triples(plus, pi2, f2) == observed_triples(minus, pi3, f3)
    assert plus_corr[8] != minus_corr[8]

    family1 = fixed_equilibrium_family_parameters(eps, F(7, 8))
    family2 = fixed_equilibrium_family_parameters(eps, F(1023, 1024))
    assert family1["fixed_slow_weight"] == family2["fixed_slow_weight"]

    return {
        "scope": "Exact algebraic and access witnesses; no empirical benchmark",
        "lower_bound_epsilon": str(eps),
        "unqueried_target_horizon": horizon,
        "lower_bound_pair_common_equilibrium": [str(x) for x in pi],
        "ctmc_embedding": "Proved via commuting finite generators; all pulse entries strictly positive",
        "null_target": str(null_corr[horizon]),
        "alternative_target": str(alt_corr[horizon]),
        "target_gap": str(gap),
        "target_gap_exceeds_twice_epsilon": True,
        "short_history_chi_square": str(chi_square),
        "chi_square_equals_16_epsilon_squared_over_9": True,
        "sharp_same_moment_lower": str(lower),
        "sharp_same_moment_upper": str(upper),
        "residual_pair_radius": str(residual_bound),
        "exactly_matched_pair_short_raw_laws_equal": True,
        "exactly_matched_pair_horizon_eight_gap": str(plus_corr[8] - minus_corr[8]),
        "fixed_equilibrium_integrated_family_first": {k: str(v) for k, v in family1.items()},
        "fixed_equilibrium_integrated_family_second": {k: str(v) for k, v in family2.items()},
    }


if __name__ == "__main__":
    print(json.dumps(run_checks(), indent=2))
