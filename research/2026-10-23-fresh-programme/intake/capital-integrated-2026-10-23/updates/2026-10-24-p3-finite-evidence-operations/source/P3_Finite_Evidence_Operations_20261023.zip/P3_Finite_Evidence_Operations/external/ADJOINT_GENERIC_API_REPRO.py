"""Focused API counterexample on the already exposed adjoint fixture.

This is a code-correctness reproduction, not an independent transfer case.
Only the candidate coefficient matrices change from the existing fixture.
Run with --archived after the root preserves *_before_interface_guard.py to
reproduce the original faulty public interface. With no flag it reviews the
current public interface. No files are written by this script.
"""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import argparse
import importlib.util
import json
import sys


parser = argparse.ArgumentParser()
parser.add_argument('--archived', action='store_true')
args = parser.parse_args()
root = Path(__file__).resolve().parents[1] / 'root'
sys.path.insert(0, str(root))
names = ('correlation_certificate', 'uniform_correlation',
         'metric_correlation', 'adjoint_correlation')
hashes = {}
for name in names:
    suffix = '_before_interface_guard' if args.archived else ''
    path = root / (name + suffix + '.py')
    hashes[name] = sha256(path.read_bytes()).hexdigest()
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)

from correlation_certificate import mv
from uniform_correlation import run_program, uniform_certificate
from metric_correlation import metric_certificate, mm
from adjoint_correlation import (AdjointRepresentation, AdjointCorrelations,
                                  adjoint_metric_certificate)
from check_correlation import invert, projector

p0, pu, pv = map(projector, ([1, 1, 1], [1, -1, 0], [1, 1, -2]))


def combine(a, b):
    return [[p0[i][j] + a*pu[i][j] + b*pv[i][j]
             for j in range(3)] for i in range(3)]


a, b = combine(F(1, 16), F(1, 64)), combine(F(1, 32), F(1, 8))
s = [[F(v) for v in row] for row in [[1, 0, 0], [0, 0, 1], [0, 1, 0]]]
b = mm(mm(s, b), s)
matrices = {0: mm(a, b), 1: mm(b, a)}
f = [F(2, 3), F(-1, 3), F(-1, 3)]


def corr(w):
    z = f
    for action in reversed(w):
        z = mv(matrices[action], z)
    return sum((x*y for x, y in zip(f, z)), F(0))/3


dagger = {0: 1, 1: 0}
empty = AdjointRepresentation([(), (0,)],
    {0: [[0, 0], [0, 0]], 1: [[0, 0], [0, 0]]}, dagger)
words = empty.acquisition_words()
data = AdjointCorrelations({w: (corr(w), corr(w)) for w in words}, dagger)
units = [(F(1), F(0)), (F(0), F(1))]
center = lambda form: sum(data.evaluate(form), F(0))/2
g = [[center(empty.inner_form(x, y)) for y in units] for x in units]
gi = invert(g)
ts = {label: mm(gi, [[center(empty.inner_form(x, y, (label,)))
                     for y in units] for x in units]) for label in dagger}
v = [ts[0][i][0] - ts[1][i][0] for i in range(2)]
epsilon = F(1, 10000)
for i in range(2):
    ts[0][i][0] += epsilon*v[i]
rep = AdjointRepresentation(empty.basis, ts, dagger)
target = (0, 0)


def assess(call):
    try:
        out = call()
        result = {'status': out['status']}
        if out['status'] == 'CERTIFIED_UNDER_CONTRACT':
            error = abs(run_program(out, target) - corr(target))
            result.update(actual_error=str(error),
                          claimed_bound=str(out['uniform_error']),
                          sound_on_target=error <= out['uniform_error'])
        else:
            result['reason'] = out.get('reason')
        return result
    except (TypeError, ValueError, KeyError) as exc:
        return {'status': 'REJECTED', 'exception': type(exc).__name__,
                'message': str(exc)}


print(json.dumps({
    'scope': 'Focused interface counterexample; previously exposed exact fixture',
    'source_hashes': hashes,
    'target': target,
    'epsilon': str(epsilon),
    'perturbation': 'T_0 <- T_0 + epsilon*(T_0 e0 - T_1 e0)*e0^T; T_1 unchanged',
    'generic_metric': assess(lambda: metric_certificate(rep, data, g, precision=60)),
    'adjoint_wrapper': assess(lambda: adjoint_metric_certificate(rep, data, g, precision=60)),
    'generic_uniform': assess(lambda: uniform_certificate(rep, data)),
}, indent=2))
