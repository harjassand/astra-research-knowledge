# Can an obtainable port contract replace a small hidden dimension?

Private bounded P3 investigation, 23 October 2026. No new fixture suite,
physical experiment, or learned-device claim is made. The first-return-kernel
route is being handled separately; this note concerns deliberately controlled
boundaries and residual memory.

## 1. An exact replacement exists, but it is an intervention contract

Let X be an arbitrarily large hidden state space, including every environmental
variable that can affect later outputs. There are finitely many observable
ports j, and an actual preparation procedure for each j produces a fixed law
mu_j over X. The law need not be reconstructed or written explicitly. Its
operational requirement is that its future-relevant distribution does not
depend on the incoming history.

A module a evolves X through an unknown Markov kernel K_a and returns an
observed port k. After observing k, an implemented boundary operation discards
the incoming future-relevant state and prepares mu_k. Define

```
P_a(k,j) = Pr(output port k | prepare mu_j, run module a).
```

### Controlled-port composition theorem

The port sequence is exactly described by the stochastic matrices P_a.
For initial port law p and final bounded port observable ell,

```
E[ell(final port)] = ell^T P_(a_m) ... P_(a_1) p.
```

Proof. Conditional on any preceding history and current port j, the boundary
procedure prepares the same law mu_j. The next-port conditional law is therefore
P_a(:,j), independently of earlier history. Apply the chain rule repeatedly.
This does not require a small dimension, a finite rank, or full identification
of X or K_a. QED.

The acquired quantities are ordinary port-to-port probabilities. They are
obtained by real preparation, module execution and outcome counting, rather
than supplied by an evaluator as a hidden mathematical class promise. Once
acquired, they support changed sequence orders without further identification.
An equally informed retaining finite-channel/MDP learner obtains the same
capability. The theorem is standard stochastic composition, not a new learning
architecture.

The mechanism changes the scientific protocol by inserting boundary resets.
It says nothing by itself about the unreset source. Any task benefit must be
for the controlled protocol actually implemented, or include a warranted bound
on how resets alter the target operation. Preparation, reset time, discarded
specimens, and sampling all count. A claim that a conditional equilibrium law
mu_j can be freshly sampled must include the cost and validity of that sampler.

## 2. Partial reset quality gives a finite-horizon task bound

Suppose the actual boundary operation after port k produces a law within
epsilon_k in total variation of mu_k, uniformly over incoming histories allowed
by the task. Let initial preparation error be epsilon_0. Markov evolution is
TV nonexpansive. A coupling/telescoping argument therefore gives, for a word
of m modules and a final observable in [0,1],

```
|true controlled expectation - ideal port-model expectation|
    <= epsilon_0 + sum_(t=1)^(m-1) max_k epsilon_(t,k).
```

The final reset can be omitted because it does not change the already recorded
final port. A sharper version weights each boundary error by the ideal port
occupancy:

```
error <= epsilon_0 + sum_(t=1)^(m-1) sum_k p_t(k)*epsilon_(t,k),
p_t = P_(a_t) ... P_(a_1) p.
```

To prove it, telescope the difference between the real and ideal products
using an ideal prefix and a real suffix for each replacement. Contract the
suffix in TV. The difference at the replaced boundary is the average reset
error under the ideal prefix's port distribution. This is the usual Markov
simulation-lemma argument. Statistical uncertainty in each acquired P_a adds
its corresponding transition-kernel error; validated interval propagation can
retain dependence instead of summing worst-case errors.

Only the desired finite-horizon observable needs this bound. Exact full-domain
recognition of the source is unnecessary. But the claimed epsilon_k must be
obtained from an actuator/preparation guarantee or a task-specific residual
experiment; merely fitting a small model does not provide it.

## 3. Resetting the observed coordinate is not enough

Suppose hidden state consists of an observable bit Y and an unobserved bit H.
A nominal reset sets Y=0 but leaves H unchanged. One preceding intervention
sets H=0; another sets H=1. Both histories now have the identical visible port
Y=0. A later read operation copies H into Y, producing different future
outputs. The visible reset has not established a common full-state preparation.

This logical counterexample is not a benchmark fixture. It identifies the
missing interface: the operation must reset or control every state variable
that can carry relevant memory, or supply a bound on its remaining effect.
Classical environmental variables suffice; no quantum phenomenon is needed.
Fresh copies can provide the contract only if relevant shared apparatus and
environmental history are also controlled to the required tolerance.

## 4. A still weaker task-specific contract

One does not actually need TV control over every hidden-state test. It is
enough to bound the reset discrepancy for the future observables/protocols
that occur in the requested computation. Let V be the finite collection of
suffix-success functions relevant to a task. A bound of the form

```
sup_(v in V) |E[v(X_after_actual_boundary)] - E_mu_k[v(X)]| <= epsilon_k
```

can replace the corresponding TV step in a task-specific telescope, provided
the allowed incoming histories and the suffix functions are the actual ones
used by that telescope. This is a restricted observable-space warrant, not
full system identification.

Such discrepancies can in principle be measured using randomized boundary
interventions followed by the chosen suffix experiments. These are real
acquisition experiments. Their cost may approach the cost of directly
estimating the target long protocols. No general acquisition advantage follows
from writing the discrepancy as a short formula. Reuse requires an actually
obtainable smaller test family that spans or bounds the needed future tests,
or a physical contraction/reset guarantee. Supplying that span or closure by
assumption recreates the original missing-information problem.

## 5. Consequential external example and strong prior methods

Quantum devices supply a concrete version of this obstruction: an intervention
can reset the accessible qubit while its environment retains protocol history.
The scientific operation is prediction and control of new gate sequences in
the presence of correlated noise. This is an external task, not an authored
encoding challenge.

White et al., *Non-Markovian Quantum Process Tomography*, PRX Quantum 3, 020344
(2022), acquire process tensors, fit shorter memory blocks, and compose them
to predict/control gate sequences. Their conditional-memory ansatz truncates
history dependence and is assessed using reconstruction fidelity. The paper
discusses that fixed preceding operations can affect the approximation. It
also reports experiments on superconducting devices. This complete retained,
memory-aware process is a necessary baseline; isolated channel tomography is
too weak. Relevant full-PDF reading: sections IV A-D, especially pp. 14-18.

Taranto, Pollock and Modi, *Non-Markovian Memory Strength Bounds Quantum
Process Recoverability*, npj Quantum Information 7, 149 (2021), give a stronger
theoretical comparator. Their recovery bound can be restricted to the linear
span of the probing instrument. The memory-strength quantity involves a
supremum over history/future instruments, so its availability is not implied
by a few successful probes. The theorem supplies a task-relevant approximation
principle; efficient acquisition of a sufficiently strong upper bound remains
a separate obligation for this branch. Relevant reading: main theorem and
the discussion of restricted process tensors and instrument optimization.

Taranto et al., *Quantum Markov Order*, PRL 122, 140401 (2019), explicitly make
the finite-memory property instrument dependent. The primary abstract states
that non-Markovian processes cannot have finite Markov order relative to every
possible instrument. This cautions against turning success under one probing
family into an unrestricted composition guarantee. Only the primary abstract
was read for this paper; its proof was not audited here.

### Route-selection consequence

An enforced reset/port interface replaces a hidden-dimension promise by an
obtainable intervention guarantee and supports exact reusable operations. It
also places the capability within established finite-channel learning.
Observed-port resets without an environmental warrant do not solve the
problem. The stronger open target is a cheaply acquired *restricted memory
bound* that supports the actual scientific protocol class and improves further
acquisition or control. Existing process-tensor recovery and finite-memory
tomography already address much of this target. Any new construction must
locate a gap beyond those baselines and include the cost of learning the bound.

No practical advantage, new physical application, or historical novelty is
established by this note. Those remain UNKNOWN. In particular, a simulator
with explicit full state may furnish a reset interface, but it does not show
that a laboratory with latent environmental memory has the same access.

## Primary sources and retrieval scope

* White et al. (2022), full primary PDF read:
  https://journals.aps.org/prxquantum/pdf/10.1103/PRXQuantum.3.020344
* Taranto, Pollock and Modi (2021), primary arXiv v2 article read:
  https://arxiv.org/html/1907.12583v2
  The page identifies v2 as 12 October 2021; it also displays a later HTML
  rendering date. No claim of a 2026 scientific update is made.
* Taranto et al. (2019), primary abstract read:
  https://arxiv.org/abs/1805.11341

The Nature article page redirected to a blocked cookie authorization page;
the arXiv article supplied the mathematical content. An institutional PDF
retrieval of the 2019 paper returned HTTP 429. These retrieval failures did
not block the bounded theorem or primary-source comparison above.
