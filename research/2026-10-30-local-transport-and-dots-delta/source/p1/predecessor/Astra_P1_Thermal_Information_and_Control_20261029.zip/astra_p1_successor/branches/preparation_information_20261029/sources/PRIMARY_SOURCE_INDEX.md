# Primary sources and actual uses

29 October 2026. Selective primary retrieval, not a priority determination.
Detailed read scopes remain in the frontier source receipts.

## Quantitative kinetic stability

Issoglio, Pagliarani, Russo and Trevisani,
[Degenerate McKean-Vlasov equations with drift in anisotropic negative Besov
spaces, arXiv:2401.09165v2](https://arxiv.org/html/2401.09165v2), March 2026.
Read the kinetic setup, Proposition 2.9 (product bound), Theorem 2.10
(free-semigroup Schauder estimates), positive-regularity characterization,
backward stability, Lemma 5.8, Theorem 5.11 and COMPLETE Proposition 5.12 proof.
The latter gives whole-sequence weak convergence for ANY common initial law;
the fourth-moment restriction is only an intermediate lemma. Known weak
stability is a strong conventional route, not a missing conventional tool.
Our quantitative continuation directly USES the printed Schauder/product
estimates and adds the native stationary heat/static-information connection.
Numeric norm constants have not been instantiated.

Chen, Hao and Zhang, [Kinetic SDEs with subcritical distributional drifts,
arXiv:2508.12234v1](https://arxiv.org/html/2508.12234v1): relevant Section 4
Krylov and limit arguments were inspected as another conventional route,
retaining their own dimension/drift hypotheses. The exact comparisons and
the Proposition 5.12 correction are saved in alternative_frontier/
BOUNDED_FORCE_CLOSURE_TARGETED_SOURCE_COMPARISON.md and its source receipt.

## Thermal identity, projection and shear antecedents

Hao Ge, [Time reversibility and nonequilibrium thermodynamics of second-order
stochastic processes, arXiv:1209.3081v3](https://arxiv.org/abs/1209.3081v3):
relevant body and Section V.A read. General reversal and Maxwell equilibrium
differ; the position-force exact-zero characterization is a known ingredient.

Harmandaris, Kalligiannaki, Katsoulakis and Plechac,
[Path-space variational inference for non-equilibrium coarse-grained systems,
arXiv:1508.00289v2](https://arxiv.org/html/1508.00289v2): Theorems 4.1, 5.1 and
kinetic Section 6 read. Initial KL plus force error, and ordinary path-space
force matching, are established strong methods. Our geometry solves that
objective in its source class; Girsanov is not a claimed invention.

[EPR-Net, arXiv:2301.01946v3](https://arxiv.org/abs/2301.01946v3): weighted
gradient projection and supplementary Pythagoras read, at its overdamped scope.

Boi, Mazzino and Muratore-Ginanneschi,
[Eddy diffusivities of inertial particles in random Gaussian flows,
arXiv:1611.02747](https://arxiv.org/abs/1611.02747): equations 3--10 read.
Integrated-OU/shear kernels are known. Applied-work and carrier-flow
thermodynamic interpretations are kept distinct.

[Busiello, Ciarchi and Di Terlizzi, arXiv:2310.00620v2](https://arxiv.org/abs/2310.00620v2):
one-way linear coupling/elimination example read. An equilibrium subsystem
driving another out of equilibrium is an antecedent. The general record
here develops resolvent heat, exact native projection and paid preparation.

[Harada and Sasa, arXiv:cond-mat/0510723](https://arxiv.org/abs/cond-mat/0510723):
heat/response and bath/time-scale premises read. Visible reversal is not
automatically physical heat. Detailed comparisons are in alternative_frontier/
TARGETED_NATIVE_THERMAL_SOURCE_COMPARISON.md and its receipt.

## Relational information and Astra governing sources

[Bartlett, Rudolph and Spekkens, quant-ph/0610030](https://arxiv.org/abs/quant-ph/0610030)
and [Marvian and Spekkens, arXiv:1312.0680](https://arxiv.org/abs/1312.0680)
were selectively read for reference-frame/asymmetry antecedents. The native
phase proof is separate; ordinary phase alignment is an equally informed
comparator. Exact read scope: causal_frontier/sources/NATIVE_REFERENCE_PRIMARY_RECEIPT.json.

Current Astra N1220 and its complete 307-line governing proof were fetched
at revision 3e2cb7095bf53339c2249f35d182af62d324f95b.
N1220_BASELINE_INTERVENTION_PROOF.md has SHA256
53839b8b3ac637bfd4dfae58ca9713c65b08562e095fee7aeac30a2b38006501.
Its accepted abstract baseline/intervention ambiguity is not presumed to be
a native physical system. Its genuinely JOINT record condition is retained.

The materially different quantum-reference opening fetched N994/N995 with
their governing sources and corrections. The accepted complete-binary result
was not promoted to a general matrix SDPI theorem. Navigation-only searches
remain navigation. Earlier accepted Astra work remains unchanged in the
complete predecessor archive, with no routine re-audit.
