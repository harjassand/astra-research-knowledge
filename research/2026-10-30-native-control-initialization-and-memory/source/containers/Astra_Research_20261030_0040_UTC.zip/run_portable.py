"""Execute only a disposable package copy; preserve original scientific bytes."""
from pathlib import Path,PurePosixPath
import tempfile,shutil,subprocess,sys,os,json,hashlib
root=Path(__file__).resolve().parent
if len(sys.argv)<2:raise SystemExit('Usage: python run_portable.py topic/program.py [args]')
rel=PurePosixPath(sys.argv[1]);assert not rel.is_absolute() and '..' not in rel.parts
work=Path(tempfile.mkdtemp(prefix='astra_replay_'))/'package';shutil.copytree(root,work)
changes=[]
for p in work.rglob('*.py'):
 if p.name=='run_portable.py':continue
 old=p.read_bytes();new=old.replace(b'/workspace/shared/',(str(work)+'/').encode()).replace(b'/workspace/scratch/57d8dd795b13/',(str(work)+'/').encode())
 if old!=new:
  changes.append(dict(path=str(p.relative_to(work)),original_sha256=hashlib.sha256(old).hexdigest(),relocated_sha256=hashlib.sha256(new).hexdigest()));p.write_bytes(new)
(work/'PATH_RELOCATION_RECEIPT.json').write_text(json.dumps(changes,indent=2)+'\n')
print('Replay working copy:',work,flush=True)
result=subprocess.run([sys.executable,str(work/rel),*sys.argv[2:]],cwd=work/rel.parent,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'))
raise SystemExit(result.returncode)
