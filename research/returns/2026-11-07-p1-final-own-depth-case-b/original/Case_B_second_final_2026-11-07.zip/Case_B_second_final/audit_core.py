"""Finite audits of the B2 construction; not a test of the uniform theorem.
No physical system is sampled.  All examples and RNG seeds are explicit.
"""
import json, math
from pathlib import Path
import numpy as np

OUT = Path(__file__).resolve().parent
rng = np.random.default_rng(20261107)

def truncation_audit():
    records = []
    max_identity_error = 0.0
    minimum_slack = float('inf')
    for trial in range(80):
        shape = (7 + trial % 3, 6 + trial % 4)
        a = rng.normal(size=shape) + 1j*rng.normal(size=shape)
        a /= np.linalg.norm(a)
        x = a + .2*(rng.normal(size=shape)+1j*rng.normal(size=shape))
        x /= max(1.0, np.linalg.norm(x))
        u, sv, vh = np.linalg.svd(x, full_matrices=False)
        rank = 1 + trial % (min(shape)-1)
        y = (u[:, :rank]*sv[:rank]) @ vh[:rank]
        residual = x-y
        old = np.linalg.norm(x-a)**2
        new = np.linalg.norm(y-a)**2
        identity = old - np.linalg.norm(residual)**2 + 2*np.vdot(residual,a).real
        nuclear = np.linalg.svd(a, compute_uv=False).sum()
        upper = old + 2*nuclear/math.sqrt(rank+1)
        max_identity_error = max(max_identity_error, abs(new-identity))
        minimum_slack = min(minimum_slack, upper-new)
        if trial < 4:
            records.append(dict(shape=shape, rank=rank, old_error_squared=old,
                new_error_squared=new, certified_algebraic_upper=upper))
    return dict(trials=80, max_identity_residual=max_identity_error,
                min_upper_bound_slack=minimum_slack, examples=records)

def pauli_apply(v, spec, n):
    idx = np.arange(1 << n, dtype=np.int64)
    target = idx.copy()
    phase = np.ones(1 << n, dtype=np.complex128)
    for site, op in spec:
        bit = (idx >> site) & 1
        if op in 'XY': target ^= (1 << site)
        if op == 'Y': phase *= 1j*(1-2*bit)
        if op == 'Z': phase *= (1-2*bit)
    result = np.empty_like(v)
    result[target] = phase*v
    return result

def gate(v, spec, angle, n):
    den = 1+angle*angle/4
    c = (1-angle*angle/4)/den
    s = angle/den
    return c*v-1j*s*pauli_apply(v,spec,n)

def word(v, terms, time, steps, n, region=None, reverse=False):
    selected = [x for x in terms if region is None or all(i in region for i,_ in x[1])]
    seq = selected*steps
    if reverse: seq = list(reversed(seq))
    sign = -1 if reverse else 1
    for strength, spec in seq:
        v = gate(v,spec,sign*strength*time/steps,n)
    return v

def strip_audit():
    rows, cols = 2, 6
    n = rows*cols
    terms = []
    for r in range(rows):
        for c in range(cols):
            site = r*cols+c
            terms.append((.2,[(site,'X')]))
            if c+1<cols: terms.append((.25,[(site,'Z'),(site+1,'Z')]))
            if r+1<rows: terms.append((1/3,[(site,'Y'),(site+cols,'X')]))
    psi = np.zeros(1<<n,dtype=complex); psi[0]=1
    for site in range(n):
        if site%3==1:
            # A local rational Cayley rotation rather than sampled preparation.
            psi=gate(psi,[(site,'Y')],.5,n)
    central=[set(r*cols+c for r in range(rows) for c in range(2*j,2*j+2)) for j in range(3)]
    expanded=[set(r*cols+c for r in range(rows) for c in range(max(0,2*j-1),min(cols,2*j+3))) for j in range(3)]
    pattern={i: ('Z' if i%2 else 'X') for i in range(n)}
    records=[]
    for time in [.02,.05,.1]:
        steps=3
        evolved=word(psi,terms,time,steps,n)
        exact=np.vdot(evolved,pauli_apply(evolved,list(pattern.items()),n))
        exact_parities=[]; local_parities=[]
        for parity in [0,1]:
            subset=set().union(*(central[j] for j in range(3) if j%2==parity))
            v=word(psi,terms,time,steps,n)
            v=pauli_apply(v,[(i,pattern[i]) for i in sorted(subset)],n)
            v=word(v,terms,time,steps,n,reverse=True)
            exact_parities.append(v)
            v=psi.copy()
            for j in range(3):
                if j%2!=parity: continue
                v=word(v,terms,time,steps,n,region=expanded[j])
                v=pauli_apply(v,[(i,pattern[i]) for i in sorted(central[j])],n)
                v=word(v,terms,time,steps,n,region=expanded[j],reverse=True)
            local_parities.append(v)
        exact_overlap=np.vdot(*exact_parities)
        approx_overlap=np.vdot(*local_parities)
        a,b=local_parities
        z=np.vdot(a,a).real+np.vdot(b,b).real
        denominator=np.abs(a)**2+np.abs(b)**2
        mask=denominator>0
        q=denominator[mask]/z
        samples=z*np.conj(a[mask])*b[mask]/denominator[mask]
        expectation=np.sum(q*samples)
        records.append(dict(time=time, n=n, cayley_steps=steps,
            exact_mean=exact.real,
            parity_identity_error=abs(exact-exact_overlap),
            localized_overlap=approx_overlap.real,
            localization_actual_error=abs(exact-approx_overlap),
            bounded_estimator_expectation_error=abs(expectation-approx_overlap),
            estimator_max_absolute=float(np.max(np.abs(samples))),
            expanded_even_strips_disjoint=not bool(expanded[0]&expanded[2])))
    return records

def width_audit():
    records=[]
    for A in [1,4,32,1000]:
        for Lam in [64,256,4096,2**20]:
            z=A*math.log(Lam)
            q=math.ceil(16*(1+A)**2*Lam/(Lam.bit_length()-1))
            log_tail=q*math.log(z)-math.lgamma(q+1)
            records.append(dict(A=A,Lambda=Lam,q=q,
                 log_factorial_tail=log_tail,requested_log_upper=-2*Lam,
                 passes=log_tail<=-2*Lam))
    return records

result=dict(scope='Finite floating-point audits of algebraic identities and selected width parameters; no full-size predictor execution and no physical experiment.',
            seed=20261107, truncation=truncation_audit(),strip_overlap=strip_audit(),width_parameters=width_audit())
(OUT/'EXECUTED_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(truncation=result['truncation'],strip_overlap=result['strip_overlap'],
                     width_cases=len(result['width_parameters']),
                     width_all_pass=all(x['passes'] for x in result['width_parameters'])),indent=2))
