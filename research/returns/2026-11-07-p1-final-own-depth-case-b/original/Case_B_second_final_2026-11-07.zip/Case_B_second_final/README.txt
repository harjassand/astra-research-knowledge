Case B — second and final authorised frontier research turn
7 November 2026

Governing report: RESEARCH_REPORT.txt
Result: positive finite-input construction for the unchanged specified-input,
two-dimensional, continuous local-depolarization mean-value question.

Main addition: polynomial-cost contraction of the short hypercontractive
buffer using factorial locality, parity strips, constructive Schmidt nuclear
norm bounds, and bounded overlap sampling. This pays the buffer operation
left open in the first attempt. No fixed-strength noise-per-layer limit,
random-state averaging, physical reset, or peer B construction is used.

Files:
  RESEARCH_REPORT.txt   Full proof, algorithms, error budgets, bit costs,
                        explicit ratio-dependent polynomial envelope, limits.
  ENDPOINT.json        Frozen endpoint and current delivered scope.
  SOURCE_SCOPE.json    Primary credit, access and exposure record.
  audit_core.py        Reproducible finite algebra/strip/parameter audits.
  EXECUTED_AUDIT.json  Their executed numerical results and limited scope.
  MANIFEST.json        File sizes and SHA256 hashes.

The theorem is distinct from software execution. The full worst-case predictor
has not been run at its proof-level resource bounds. Finite audits do not
prove the uniform theorem. No claim of practical speed is made.

The first attempt and all earlier originals remain unchanged. No peer B
original was deliberately supplied or retrieved for this turn. No held
archive, new worker, infrastructure, physical experiment, spending or outreach
was used. This is the final authorised case-B turn.
