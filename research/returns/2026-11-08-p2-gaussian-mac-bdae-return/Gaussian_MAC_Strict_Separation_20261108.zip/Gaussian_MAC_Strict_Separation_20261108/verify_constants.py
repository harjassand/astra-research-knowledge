#!/usr/bin/env python3
"""Exact scalar certificate for the Gaussian-MAC separation.

This checks constants in REPORT.txt using rational arithmetic. It does not
replace the symbolic Gaussian inequality with a numerical covariance search,
and it does not execute the enormous deterministic outer-code search.
"""
from fractions import Fraction as Q
import argparse
import json
from pathlib import Path

def log_interval(x: Q, terms: int = 2):
    if not (x >= 1 and terms >= 1):
        raise ValueError("This certificate uses x >= 1 and terms >= 1.")
    z = (x - 1) / (x + 1)
    lower = sum((2 * z ** (2*k+1) / (2*k+1)
                 for k in range(terms)), Q(0))
    remainder = 2 * z ** (2*terms+1) / (
        (2*terms+1) * (1-z*z))
    return lower, lower + remainder

def code_parameters(error: Q):
    if not (0 < error <= Q(1, 4)):
        raise ValueError("Require 0 < error <= 1/4.")
    numerator = 4 * error.denominator
    denominator = error.numerator
    ell = max(0, numerator.bit_length() - denominator.bit_length())
    while (denominator << ell) < numerator:
        ell += 1
    while ell > 0 and (denominator << (ell-1)) >= numerator:
        ell -= 1
    blocks = (1 << 18) * ell
    message_bits = 116 * blocks
    physical_uses = (1 << 256) * blocks
    return {
        "error": str(error),
        "L_epsilon": ell,
        "PPM_blocks_T": blocks,
        "message_bits_K": message_bits,
        "physical_uses_N": str(physical_uses),
        "Alice_photons_every_codeword": str(blocks),
        "Bob_photons_every_codeword": str(physical_uses),
        "retained_matrix_bits": str(29696 * blocks * blocks),
        "search_base_two_exponent": str(
            29696 * blocks * blocks + blocks),
    }

def certificate():
    ln2_lo, ln2_hi = log_interval(Q(2), 2)
    assert ln2_lo == Q(56, 81)
    assert ln2_hi == Q(1123, 1620)
    assert Q(69, 100) < ln2_lo < ln2_hi < Q(7, 10)

    a = Q(3, 5)
    b = Q(4, 5)
    assert a*a + b*b == 1
    eta = a*a
    alpha = 2 * eta * (1-eta)
    assert eta == Q(9, 25)
    assert alpha == Q(288, 625)

    # g(eta*p)/p+7 <= eta*256*ln2 + eta*ln(1/eta)
    #                       + eta + eta^2*p + 7
    # and eta*ln(1/eta) <= 1-eta, p < 1.
    upper = eta * 256 * Q(7, 10) + (1-eta) + eta + eta*eta + 7
    assert upper == Q(45401, 625)
    assert upper < 73
    achieved_lower = 116 * ln2_lo
    assert achieved_lower > 80

    rho = Q(116, 256)
    gap = (alpha-rho)/2
    assert rho == Q(29, 64)
    assert gap == Q(307, 80000)
    hoeffding_multiplier = 2 * gap * gap * (1 << 18)
    rank_multiplier = 256 * gap * (1 << 18)
    assert hoeffding_multiplier > ln2_hi
    assert rank_multiplier > 1

    # The optional positive-positive tuple is dominated by the coded rates.
    assert Q(99, 100) * achieved_lower > Q(396, 5)
    assert ln2_lo / 400 > Q(1, 1000)
    assert Q(99, 100) + Q(1, 100) * Q(1, 2) == Q(199, 200)

    # Uniform real-input interval claimed in the report.
    eta_lo = Q(3599, 10000)
    eta_hi = Q(3601, 10000)
    alpha_min = 2 * eta_lo * (1-eta_lo)
    assert alpha_min > Q(4607, 10000)
    uniform_gap = Q(3, 800)
    assert alpha_min-rho > 2*uniform_gap
    real_upper = eta_hi*256*Q(7,10) + 1 + eta_hi*eta_hi + 7
    assert real_upper < 73
    assert 2*uniform_gap*uniform_gap*(1 << 18) > ln2_hi

    return {
        "all_checks_exact_rational": True,
        "channel_amplitudes": [str(a), str(b)],
        "eta": str(eta),
        "alpha": str(alpha),
        "p": "1/" + str(1 << 256),
        "ln2_interval": [str(ln2_lo), str(ln2_hi)],
        "Gaussian_upper_R1_over_p": str(upper),
        "Gaussian_upper_strictly_less_than": 73,
        "target_R1_over_p": 80,
        "actual_code_rate_R1_over_p": "116*ln(2)",
        "actual_code_rate_lower_bound": str(achieved_lower),
        "erasure_half_gap": str(gap),
        "Hoeffding_multiplier": str(hoeffding_multiplier),
        "rank_exponent_multiplier": str(rank_multiplier),
        "real_transmissivity_interval": [str(eta_lo), str(eta_hi)],
        "example_finite_code_parameters": code_parameters(Q(1, 1000)),
        "scope": "Scalar proof constants, not empirical optimization or executed code search."
    }

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = json.dumps(certificate(), indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(result, encoding="utf-8")
    print(result, end="")

