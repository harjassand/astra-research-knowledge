Gaussian MAC strict separation — 8 November 2026

REPORT.txt is the complete proof and resource construction.

It refutes the universal equality between the unassisted operational capacity
region and the entire Gaussian time-sharing region defined in the task.

Fixed rational instance:
X1=(3/5)I2, X2=(4/5)I2, Y=0;
E1=2^-256, E2=1.
Every Gaussian-hull rate has R1<73*2^-256.
The operational pair (80*2^-256,0) is achievable.
A positive-positive rate pair is also constructed.

verify_constants.py checks the scalar constants with exact fractions.
verification_output.json is its recorded output.

The proof includes an explicit deterministic outer-code search with a finite
bound. That astronomically large search was NOT executed. No numerical fixture,
unpriced oracle, physical experiment, or covariance-optimization guess is used
as a substitute for the analytic proof.

All source holds, actual exposure, accepted predecessor dependencies and
implementation limits are recorded in REPORT.txt. No historical-priority claim
is made.

