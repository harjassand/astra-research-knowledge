#!/usr/bin/env python3
"""Exact small checks of the softened, multiply marked tableau construction.

These finite checks supplement the proof in soft_certificates.md. They do not
decide arbitrary halting or verify infinite-volume Gibbs uniqueness.
"""

from collections import Counter, defaultdict
from dataclasses import replace
from fractions import Fraction
import importlib.util
from itertools import product
import json
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / "source" / "check_explicit_tableau_grammar.py"
spec = importlib.util.spec_from_file_location("pinned_tableau", SOURCE)
pinned = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = pinned
spec.loader.exec_module(pinned)


class SoftMachine(pinned.Machine):
    """Only the bottom row runs a nontrivial DFA."""

    def dfa_states(self, v):
        return super().dfa_states(v) if v == "B" else range(1)

    def dfa_step(self, v, k, x):
        return super().dfa_step(v, k, x) if v == "B" else 0

    def dfa_accept(self, v, k):
        return super().dfa_accept(v, k) if v == "B" else k == 0


def soft_tiles(machine):
    return [replace(t, marked=t.triple[1].head is not None
                    and t.triple[1].head[0] == pinned.HALT)
            for t in pinned.compile_tiles(machine)]


def count_rectangles_by_marks(tiles, width, height):
    """Assemble actual edge colors; do not use the update or DFA functions."""
    by = defaultdict(list)
    for tile in tiles:
        by[tile.h, tile.v, tile.colors[0], tile.colors[2]].append(tile)
    grid = []
    histogram = Counter()

    def visit(pos):
        if pos == width * height:
            histogram[sum(tile.marked for tile in grid)] += 1
            return
        row, col = divmod(pos, width)
        h = "L" if col == 0 else "R" if col == width - 1 else "I"
        v = "B" if row == 0 else "T" if row == height - 1 else "I"
        west = grid[-1].colors[1] if col else pinned.ZERO
        south = grid[pos - width].colors[3] if row else pinned.ZERO
        for tile in by[h, v, west, south]:
            if col == width - 1 and tile.colors[1] != pinned.ZERO:
                continue
            if row == height - 1 and tile.colors[3] != pinned.ZERO:
                continue
            grid.append(tile)
            visit(pos + 1)
            grid.pop()

    visit(0)
    return dict(sorted(histogram.items()))


def expected_history_marks(machine, width, height):
    row = machine.initial(width)
    if row is None:
        return None
    marks = 0
    for j in range(height):
        marks += sum(cell.head is not None and cell.head[0] == pinned.HALT
                     for cell in row)
        if j + 1 < height:
            row = machine.step(row)
    return marks


def check_one_component_character_identity():
    # Four occupied sites form a cycle, and all four internal edge colors are
    # the nontrivial character of Z/2. Every selected nonempty proper vertex
    # subset leaves an unmatched edge. Two of the sites are marked.
    internal_edges = ((0, 1), (1, 3), (2, 3), (0, 2))
    marked = {0, 3}
    activity_per_tile = Fraction(1, 137)
    checks = 0
    for spins in product((-1, 1), repeat=4):
        total = Fraction()
        for group in product((-1, 1), repeat=4):
            value = Fraction(1)
            for site in range(4):
                character = 1
                for edge, ends in enumerate(internal_edges):
                    if site in ends:
                        character *= group[edge]
                coefficient = 1 if site in marked and spins[site] == -1 else 2
                value *= 1 + activity_per_tile * coefficient * character
            total += value
        total /= 16
        minus_marks = sum(spins[x] == -1 for x in marked)
        expected = 1 + (2 * activity_per_tile) ** 4 * Fraction(1, 2) ** minus_marks
        assert total == expected
        checks += 1
    return checks


def check_soft_partition_ratios_and_reference_tilts():
    # A finite labelled species system, including an unmarked species, a
    # multiply marked species, and overlaps, to check the actual sum identities.
    species = [
        ({0, 1}, set(), Fraction(1, 41)),
        ({0, 2}, {0, 2}, Fraction(1, 43)),
        ({1, 2}, {2}, Fraction(1, 47)),
        ({3}, {3}, Fraction(1, 53)),
        ({0, 1, 2}, {0, 1, 2}, Fraction(1, 59)),
    ]
    families = []
    for bits in product((0, 1), repeat=len(species)):
        occupied = set()
        weight = Fraction(1)
        marks = set()
        for bit, (support, marked, activity) in zip(bits, species):
            if not bit:
                continue
            if occupied & support:
                break
            occupied |= support
            marks |= marked
            weight *= activity
        else:
            families.append((bits, occupied, marks, weight))

    def z(spins, allowed=lambda bits: True):
        return sum((weight * Fraction(1, 2) ** sum(spins[x] == -1 for x in marks)
                    for bits, _, marks, weight in families if allowed(bits)), Fraction())

    ratio_checks = 0
    tilt_checks = 0
    for spins_tuple in product((-1, 1), repeat=4):
        spins = dict(enumerate(spins_tuple))
        all_plus = {x: 1 for x in spins}
        z_plus = z(all_plus)
        # Reference-normalizer identity, with N_B <= |B| checked per family.
        minus_sites = {x for x in spins if spins[x] == -1}
        tilt_expectation = Fraction()
        for _, _, marks, weight in families:
            n_b = len(marks & minus_sites)
            assert n_b <= len(minus_sites)
            tilt_expectation += weight / z_plus * Fraction(1, 2) ** n_b
        assert z(spins) / z_plus == tilt_expectation
        assert Fraction(1, 2) ** len(minus_sites) <= tilt_expectation <= 1
        tilt_checks += 1

        for x in spins:
            plus, minus = dict(spins), dict(spins)
            plus[x], minus[x] = 1, -1
            marked_at_x = {i for i, (_, marked, _) in enumerate(species) if x in marked}
            no_marked_at_x = lambda bits: not any(bits[i] for i in marked_at_x)
            z0 = z(plus, no_marked_at_x)
            a_sum = Fraction()
            for i in marked_at_x:
                support, marked, activity = species[i]
                other_minus_marks = sum(plus[y] == -1 for y in marked)
                vacant_z = sum((weight * Fraction(1, 2) ** sum(plus[y] == -1 for y in marks)
                                for bits, occupied, marks, weight in families
                                if not occupied & support), Fraction())
                a_sum += activity * Fraction(1, 2) ** other_minus_marks * vacant_z / z0
            assert z(plus) == z0 * (1 + a_sum)
            assert z(minus) == z0 * (1 + a_sum / 2)
            assert z(plus) / z(minus) == (1 + a_sum) / (1 + a_sum / 2)
            ratio_checks += 1
    return {"species": len(species), "compatible_families": len(families),
            "single_site_ratio_checks": ratio_checks,
            "reference_tilt_checks": tilt_checks}


def main():
    machines = {
        "halt_after_one": SoftMachine(("_",), "_", ("S",), "S", {("S", "_"): (pinned.HALT, "_", 0)}),
        "stationary_nonhalt": SoftMachine(("_",), "_", ("S",), "S", {("S", "_"): ("S", "_", 0)}),
        "right_overflow_nonhalt": SoftMachine(("_",), "_", ("S",), "S", {("S", "_"): ("S", "_", 1)}),
        "left_fold_nonhalt": SoftMachine(("_",), "_", ("S",), "S", {("S", "_"): ("S", "_", -1)}),
        "cross_origin_halt": SoftMachine(("_",), "_", ("S", "A"), "S",
            {("S", "_"): ("A", "_", -1), ("A", "_"): (pinned.HALT, "_", 1)}),
        "halt_requires_width_three": SoftMachine(("_",), "_", ("S", "A"), "S",
            {("S", "_"): ("A", "_", 1), ("A", "_"): (pinned.HALT, "_", 1)}),
        "halt_at_start": SoftMachine(("_",), "_", (), pinned.HALT, {}),
    }
    records = {}
    rectangle_checks = 0
    marked_histograms = Counter()
    for name, machine in machines.items():
        tiles = soft_tiles(machine)
        checks = []
        for width in (2, 3, 4):
            for height in range(2, 6):
                expected_marks = expected_history_marks(machine, width, height)
                expected = {} if expected_marks is None else {expected_marks: 1}
                actual = count_rectangles_by_marks(tiles, width, height)
                assert actual == expected, (name, width, height, actual, expected)
                marked_histograms.update(actual)
                checks.append({"width": width, "height": height,
                               "mark_histogram": actual, "expected": expected})
                rectangle_checks += 1
        records[name] = {"tile_count": len(tiles), "locally_marked_tiles": sum(t.marked for t in tiles),
                         "checks": checks}

    b_rect = 200 * Fraction(2, 625) / (1 - Fraction(2, 625)) ** 2
    b_cont = 200 * 25 * 121 * Fraction(1, 80) ** 4 / (1 - Fraction(9, 320))
    assert b_rect + b_cont < Fraction(2, 3)
    assert 19**8 > 2560 * 7**8
    result = {
        "scope": "Finite exact combinatorics and rational identities only; no infinite-volume proof or nonhalting test.",
        "rectangle_checks": rectangle_checks,
        "rectangle_mark_histogram_across_checks": dict(sorted(marked_histograms.items())),
        "machines": records,
        "character_sum_checks": check_one_component_character_identity(),
        "soft_ratio_and_tilt_checks": check_soft_partition_ratios_and_reference_tilts(),
        "temperature_bounds": {"B_rect": str(b_rect), "B_cont_K8": str(b_cont),
                               "B_total": str(b_rect + b_cont), "B_total_lt_2_over_3": True},
    }
    target = HERE / "soft_certificate_checks.json"
    target.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"result_path": str(target), "rectangle_checks": rectangle_checks,
                      "rectangle_mark_histogram": result["rectangle_mark_histogram_across_checks"],
                      "character_sum_checks": result["character_sum_checks"],
                      "soft_ratio_and_tilt_checks": result["soft_ratio_and_tilt_checks"]}, indent=2))


if __name__ == "__main__":
    main()
