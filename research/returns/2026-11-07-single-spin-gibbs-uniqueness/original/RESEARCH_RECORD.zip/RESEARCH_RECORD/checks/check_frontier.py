"""Exact finite checks supplementing, not proving, the dossier theorems."""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import json

def bounds():
    assert sum((Q(1), Q(1), Q(1,2), Q(1,6), Q(1,24), Q(1,120))) > Q(19,7)
    assert Q(19,7)**8 > 2560
    r=Q(32,10000);q=Q(1,80)
    rectangle=200*r/(1-r)**2
    assert Q(6,5)**2*Q(13,11)**2<Q(9,4)
    contour=200*3025*q**4/(1-Q(9,4)*q)
    total=rectangle+contour
    minority=121*Q(1,160)**4/(1-2*Q(1,160))
    polymer=2*r/(1-r)**2
    assert total<Q(2,3) and total/(1-total)<2
    assert minority<Q(1,10**6) and polymer<Q(6442,10**6)
    return dict(beta_lower='2/5',mismatch_exponent_lower=8,
                rectangle_bound=str(rectangle),contour_bound=str(contour),
                total_bound=str(total),total_decimal=float(total),
                chain_constant=str(total/(1-total)),minority_bound=str(minority),
                polymer_two_soup_bound=str(polymer),susceptibility_absolute_bound=68)

SUPPORTS=(frozenset((0,1)),frozenset((1,2)),frozenset((3,)))
MARKS=(frozenset((0,1)),frozenset((2,)),frozenset())
ACTIVITIES=(Q(1,7),Q(1,11),Q(1,13))
ACTIVE_SUPPORTS=(frozenset((0,2)),frozenset((1,3)))

def activation_values(s):
    return (Q(1,5) if s[0]==s[2] else Q(1,10),
            Q(1,9) if (s[1],s[3])==(-1,1) else Q(0))

def weight(config):
    s,polymers,activations=config;occupied=set();w=Q(1)
    for i,present in enumerate(polymers):
        if present:
            if occupied&SUPPORTS[i]:return Q(0)
            occupied.update(SUPPORTS[i])
            w*=ACTIVITIES[i]*Q(1,2)**sum(s[x]==-1 for x in MARKS[i])
    for x in range(3):
        if s[x]==s[x+1]:w*=3
    for q,present in zip(activation_values(s),activations):
        if present:w*=q
    return w

def bad_component(first,second,seed=0):
    bad={x for x in range(4) if first[0][x]==-1 or second[0][x]==-1};hyperedges=[]
    for config in (first,second):
        for i,present in enumerate(config[1]):
            if present:hyperedges.append(SUPPORTS[i]);bad.update(SUPPORTS[i])
        for i,present in enumerate(config[2]):
            if present:hyperedges.append(ACTIVE_SUPPORTS[i]);bad.update(ACTIVE_SUPPORTS[i])
    if seed not in bad:return frozenset()
    found={seed}
    while True:
        new=set(found)
        for x in found:new.update(y for y in (x-1,x+1) if y in bad)
        for support in hyperedges:
            if support&found:new.update(support)
        if new==found:return frozenset(found)
        found=new

def exchange(first,second,region):
    def changed(a,b):
        spins=tuple(b[0][x] if x in region else a[0][x] for x in range(4))
        polys=tuple(b[1][i] if support&region else a[1][i] for i,support in enumerate(SUPPORTS))
        active=tuple(b[2][i] if support&region else a[2][i] for i,support in enumerate(ACTIVE_SUPPORTS))
        return spins,polys,active
    return changed(first,second),changed(second,first)

def finite_swap():
    configs=[]
    for spins in product((-1,1),repeat=4):
        for polymers in product((0,1),repeat=3):
            for activations in product((0,1),repeat=2):
                config=(spins,polymers,activations);w=weight(config)
                if w:configs.append((config,w))
    checked=0
    for first,w_first in configs:
        for second,w_second in configs:
            region=bad_component(first,second)
            a,b=exchange(first,second,region)
            assert bad_component(a,b)==region
            assert exchange(a,b,region)==(first,second)
            assert weight(a)*weight(b)==w_first*w_second
            assert a[0][0]==second[0][0] and b[0][0]==first[0][0]
            checked+=1
    return dict(positive_configs=len(configs),product_pairs_checked=checked,
                multiple_marks=True,unmarked_background=True,
                non_nearest_neighbor_activations=True,zero_activation_weights=True,
                status='All exact finite activation-swap checks passed')

if __name__=='__main__':
    result=dict(bounds=bounds(),finite_swap=finite_swap(),
                scope='Exact arithmetic and finite involution test; not an infinite-volume proof.')
    Path(__file__).with_name('frontier_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
