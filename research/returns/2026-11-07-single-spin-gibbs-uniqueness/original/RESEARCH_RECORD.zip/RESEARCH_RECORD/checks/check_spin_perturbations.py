#!/usr/bin/env python3
"""Exact finite identities for the spin-perturbation activation representation.

This checks finite weights and augmented component swaps, not infinite-volume
uniqueness or the required smallness bound.
"""

from fractions import Fraction
from itertools import product
import json
from pathlib import Path


SITES = (0, 1, 2)
CORE_EDGES = ({0, 1}, {1, 2})
SUPPORTS = ({0, 2}, {0, 1, 2}, {1})
POLYMERS = (({0}, {0}, Fraction(1, 11)),
            ({2}, {2}, Fraction(1, 13)))


def weights(spins):
    # These are exp(Psi_X), with arbitrary signs/interactions after taking logs.
    return (
        Fraction(3 if spins[0] == -1 and spins[2] == 1 else
                 2 if spins[0] == -1 and spins[2] == -1 else 1),
        Fraction(5, 2) if spins[0] * spins[1] * spins[2] == -1 else Fraction(1),
        Fraction(7, 5) if spins[1] == -1 else Fraction(1),
    )


ALL_SPINS = tuple(product((-1, 1), repeat=3))
MINS = tuple(min(weights(s)[i] for s in ALL_SPINS) for i in range(3))
MAXS = tuple(max(weights(s)[i] for s in ALL_SPINS) for i in range(3))
PS = tuple(1 - a / b for a, b in zip(MINS, MAXS))


def qs(spins):
    return tuple(w / a - 1 for w, a in zip(weights(spins), MINS))


def augmented_weight(state):
    spins, components, active = state
    value = Fraction(1)
    for edge in CORE_EDGES:
        a, b = sorted(edge)
        if spins[a] != spins[b]:
            value /= 3
    # A uniform exponent field, independent of the perturbation factors.
    for spin in spins:
        if spin == 1:
            value *= 2
    for bit, (_, marked, activity) in zip(components, POLYMERS):
        if bit:
            value *= activity * Fraction(1, 2) ** sum(spins[x] == -1 for x in marked)
    for bit, q in zip(active, qs(spins)):
        if bit:
            value *= q
    return value


def bad_components(first, second):
    bad = {x for x in SITES if first[0][x] == -1 or second[0][x] == -1}
    objects = []
    for i, (support, _, _) in enumerate(POLYMERS):
        if first[1][i] or second[1][i]:
            bad |= support
            objects.append(support)
    for i, support in enumerate(SUPPORTS):
        if first[2][i] or second[2][i]:
            bad |= support
            objects.append(support)
    components = []
    remaining = set(bad)
    while remaining:
        component = {next(iter(remaining))}
        while True:
            enlarged = set(component)
            for edge in CORE_EDGES:
                if edge & component and edge <= bad:
                    enlarged |= edge
            for support in objects:
                if support & component:
                    enlarged |= support
            if enlarged == component:
                break
            component = enlarged
        remaining -= component
        components.append(frozenset(component))
    return frozenset(components)


def swap_component(first, second, component):
    left = [list(part) for part in first]
    right = [list(part) for part in second]
    for x in component:
        left[0][x], right[0][x] = right[0][x], left[0][x]
    for i, (support, _, _) in enumerate(POLYMERS):
        if (first[1][i] or second[1][i]) and support & component:
            assert support <= component
            left[1][i], right[1][i] = right[1][i], left[1][i]
    for i, support in enumerate(SUPPORTS):
        if (first[2][i] or second[2][i]) and support & component:
            assert support <= component
            left[2][i], right[2][i] = right[2][i], left[2][i]
    return tuple(tuple(part) for part in left), tuple(tuple(part) for part in right)


def main():
    normalization_checks = 0
    domination_checks = 0
    states = []
    for spins in ALL_SPINS:
        activation_total = Fraction()
        q_values = qs(spins)
        for active in product((0, 1), repeat=3):
            w = Fraction(1)
            for bit, q in zip(active, q_values):
                if bit:
                    w *= q
            activation_total += w
        expected = Fraction(1)
        for w, a in zip(weights(spins), MINS):
            expected *= w / a
        assert activation_total == expected
        normalization_checks += 1
        for q, p in zip(q_values, PS):
            assert 0 <= q / (1 + q) <= p
            domination_checks += 1
        for components in product((0, 1), repeat=2):
            for active in product((0, 1), repeat=3):
                state = (spins, components, active)
                w = augmented_weight(state)
                if w:
                    states.append((state, w))

    pair_checks = 0
    nontrivial_swaps = 0
    disconnected_hyper_swaps = 0
    for first, w_first in states:
        for second, w_second in states:
            before = bad_components(first, second)
            # Swap the augmented bad component meeting the origin.
            component = next((c for c in before if 0 in c), frozenset())
            swapped_first, swapped_second = swap_component(first, second, component)
            assert augmented_weight(swapped_first) * augmented_weight(swapped_second) == w_first * w_second
            assert bad_components(swapped_first, swapped_second) == before
            assert swap_component(swapped_first, swapped_second, component) == (first, second)
            assert swapped_first[0][0] == second[0][0]
            assert swapped_second[0][0] == first[0][0]
            if (swapped_first, swapped_second) != (first, second):
                nontrivial_swaps += 1
            if component == frozenset({0, 2}):
                disconnected_hyper_swaps += 1
            pair_checks += 1

    result = {
        "scope": "Exact finite activation identities and augmented component swaps only; no infinite-volume or smallness claim.",
        "normalization_checks": normalization_checks,
        "activation_domination_checks": domination_checks,
        "positive_augmented_states": len(states),
        "replica_pair_checks": pair_checks,
        "nontrivial_swaps": nontrivial_swaps,
        "disconnected_hypercomponent_swaps": disconnected_hyper_swaps,
        "activation_upper_probabilities": [str(p) for p in PS],
    }
    destination = Path(__file__).with_name("spin_perturbation_checks.json")
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
