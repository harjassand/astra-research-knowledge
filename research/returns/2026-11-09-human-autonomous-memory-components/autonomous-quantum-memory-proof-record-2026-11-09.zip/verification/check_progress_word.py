"""Absorbing-target lemma and limited ACK-progress diagnostic, not a FIFO link."""
from collections import deque
from itertools import product
from math import exp
from pathlib import Path
import json

def universal_word(transitions, good):
    n=len(next(iter(transitions.values())))
    good=set(good)
    assert all(t[g] in good for t in transitions.values() for g in good)
    paths={}
    for source in range(n):
        todo=deque([(source,())])
        visited={source}
        while todo:
            state,path=todo.popleft()
            if state in good:
                paths[source]=path
                break
            for label,t in transitions.items():
                if t[state] not in visited:
                    visited.add(t[state])
                    todo.append((t[state],path+(label,)))
    unreachable=set(range(n))-set(paths)
    if unreachable:
        return None,sorted(unreachable)
    surviving=set(range(n))-good
    word=[]
    while surviving:
        old_count=len(surviving)
        for label in paths[min(surviving)]:
            word.append(label)
            surviving={transitions[label][s] for s in surviving}-good
        assert len(surviving)<old_count
    assert len(word)<=n*(n-1)
    for source in range(n):
        state=source
        for label in word:
            state=transitions[label][state]
        assert state in good
    return word,[]

states=list(product((0,1),repeat=4)) # data, delivered, ACK, sender done
index={s:i for i,s in enumerate(states)}
def link_model(reack):
    transitions={label:[] for label in ('send','receive','poll_ack')}
    for label,t in transitions.items():
        for data,delivered,ack,done in states:
            if not done:
                if label=='send':
                    data=1
                elif label=='receive' and data:
                    data=0
                    ack=int(bool(ack or not delivered or reack))
                    delivered=1
                elif label=='poll_ack' and ack:
                    ack=0
                    done=1
            t.append(index[(data,delivered,ack,done)])
    return transitions

good=[i for i,s in enumerate(states) if s[3]]
bad_word,traps=universal_word(link_model(False),good)
assert bad_word is None
assert index[(0,1,0,0)] in traps
word,traps_fixed=universal_word(link_model(True),good)
assert word is not None and not traps_fixed
report={'states':len(states),'target':'sender released by ACK; no content certification',
        'naive_protocol_unreachable_states':[states[i] for i in traps],
        'reack_toy_universal_word':word,'reack_word_length':len(word),
        'equal_unit_rate_slotted_word_probability':(exp(-1)/3)**len(word),
        'scope':'progress-only exhaustive finite diagnostic; no FIFO or threshold proof'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
