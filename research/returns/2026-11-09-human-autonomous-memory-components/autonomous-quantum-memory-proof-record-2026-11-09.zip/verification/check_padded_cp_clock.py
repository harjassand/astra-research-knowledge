"""Finite complex-matrix diagnostics for the paid CP-clock representation.
The proof is the full-Choi norm inequality, not these floating checks.
Uses analytic diamond-norm upper bounds, never a numerical norm proxy.
"""
from pathlib import Path
import json
import numpy as np
from completion_adversarial_check import dagger,choi,supermatrix,expm,basis

rng=np.random.default_rng(20261109+11)
cases=[]
for d in (2,3,4):
 for _ in range(12):
  raw=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d))
  h=(raw+dagger(raw))/2
  vs=[rng.normal(size=(d,d))+1j*rng.normal(size=(d,d)) for _ in range(3)]
  cs=(1.,-.8,-1.2)
  eps=2*np.linalg.norm(h,2)+2*sum(abs(c)*np.linalg.norm(v,2)**2 for c,v in zip(cs,vs))
  gamma=d*d*eps
  def g(rho):
   out=-1j*(h@rho-rho@h)
   for c,v in zip(cs,vs):
    a=dagger(v)@v
    out+=c*(v@rho@dagger(v)-(a@rho+rho@a)/2)
   return out
  def t(rho): return np.trace(rho)*np.eye(d)/d
  def phi(rho): return t(rho)+g(rho)/gamma
  def residual(rho): return g(rho)+gamma*(t(rho)-rho)
  jc=choi(phi,d)
  mineig=float(np.linalg.eigvalsh((jc+dagger(jc))/2).min())
  tp=max(float(abs(np.trace(phi(basis(d,i,j)))-(i==j))) for i in range(d) for j in range(d))
  sm=supermatrix(phi,d)
  rs=supermatrix(residual,d)
  identity=float(np.max(np.abs(rs-gamma*(sm-np.eye(d*d)))))
  poissonerr=0.
  for mu in (.3,3.):
   weight=np.exp(-mu)
   power=np.eye(d*d,dtype=complex)
   series=weight*power
   for n in range(1,81):
    power=sm@power
    weight*=mu/n
    series+=weight*power
   poissonerr=max(poissonerr,float(np.max(np.abs(series-expm((mu/gamma)*rs)))))
  cases.append({'dimension':d,'analytic_diamond_bound':float(eps),'gamma':float(gamma),
   'phi_min_choi_eigenvalue':mineig,'phi_trace_preservation_max_error':tp,
   'generator_identity_max_error':identity,'poisson_semigroup_max_error':poissonerr})
assert min(c['phi_min_choi_eigenvalue'] for c in cases)>-1e-12
assert max(c['phi_trace_preservation_max_error'] for c in cases)<1e-12
assert max(c['generator_identity_max_error'] for c in cases)<1e-9
assert max(c['poisson_semigroup_max_error'] for c in cases)<1e-11
result={'case_count':len(cases),'dimensions':[2,3,4],
 'scope':'Floating diagnostics for exact paid-padding identity, not a threshold proof or device simulation',
 'minimum_phi_choi_eigenvalue':min(c['phi_min_choi_eigenvalue'] for c in cases),
 'maximum_trace_preservation_error':max(c['phi_trace_preservation_max_error'] for c in cases),
 'maximum_generator_identity_error':max(c['generator_identity_max_error'] for c in cases),
 'maximum_poisson_semigroup_error':max(c['poisson_semigroup_max_error'] for c in cases),
 'cases':cases}
(here:=Path(__file__).resolve().parent).joinpath('padded_cp_clock_check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))
