"""Compile and exhaustively check the capacity-one finite SDL witness.
No external dependencies or network. C++ exhausts all typed combinations;
RX transition table covers every finite receiver queue, bit and packet.
This check does not prove robust streaming or a noisy quantum threshold.
"""
from pathlib import Path
import hashlib,json,subprocess
here=Path(__file__).resolve().parent
source=here/'check_finite_link_word.cpp'
exe=here/'check_finite_link_word.bin'
subprocess.run(['clang++','-std=c++17','-O3',str(source),'-o',str(exe)],check=True)
r=json.loads(subprocess.check_output([str(exe)],text=True))
r.update({
 'source_protocol':'arXiv:1011.3632v2 Fig.2; capacity-one chosen physical realization',
 'word':'POLL (SEND RX POLL)^10',
 'word_length':31,
 'coverage':'Cartesian product of held bit, alternating bit, phase SYN/DATA/DONE, count 0..5, sender pc SEND/POLL, all unique-key LRU queues of length <=2 with counts 0..2, receiver last bit, both mailboxes empty or one of six packets',
 'fresh_call_definition':'phase SYN, count 0, pc SEND; alternating bit has already been flipped at call start',
 'count5_repair':'sender-local normalization at SEND/POLL entry advances completed phase; count also normalized immediately on increment to 5',
 'assumptions':['overwrite-old capacity-one mailboxes',
  'atomic bounded-support RX+queue+reACK handler',
  'fresh held payload stable throughout its call',
  'DeliverMessage accepted immediately by application at the delivery event',
  'outside arrivals excluded/held and no new faults during witness word'],
 'inflight_scope':'termination only; arbitrary current call can ACK without delivering its payload',
 'not_proved':['readiness of an occupied downstream buffer','timed stream framing/epoch locality',
  'noisy processor decoder correctness','rolling-window commit','full autonomous quantum FT'],
 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()
})
(here/'finite_link_word_exact.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
