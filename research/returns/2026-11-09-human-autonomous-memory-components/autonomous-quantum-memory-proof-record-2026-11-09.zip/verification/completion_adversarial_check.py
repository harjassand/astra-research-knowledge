"""Finite diagnostics for the explicit depolarizing-completion decomposition.

Not a threshold proof or a device simulation. Uses an analytic upper bound on
each generated map's diamond norm; never substitutes a numerical proxy for it.
"""

import json
import numpy as np


def expm(matrix):
    """Numerical scaling/squaring Taylor diagnostic; not interval arithmetic."""
    norm=float(np.linalg.norm(matrix,1))
    scaling=max(0,int(np.ceil(np.log2(max(1.0,2*norm)))))
    scaled=matrix/(2**scaling)
    out=np.eye(matrix.shape[0],dtype=complex)
    term=out.copy()
    for order in range(1,100):
        term=term@scaled/order
        out+=term
        if np.linalg.norm(term,1)<2e-17:
            break
    for _ in range(scaling):
        out=out@out
    return out


def dagger(a):
    return a.conj().T


def basis(d, a, b):
    z = np.zeros((d, d), dtype=complex)
    z[a, b] = 1
    return z


def choi(fn, d):
    out = np.zeros((d * d, d * d), dtype=complex)
    for a in range(d):
        for b in range(d):
            out[a*d:(a+1)*d, b*d:(b+1)*d] = fn(basis(d, a, b))
    return out


def supermatrix(fn, d):
    out = np.zeros((d*d, d*d), dtype=complex)
    for b in range(d):
        for a in range(d):
            out[:, a + d*b] = fn(basis(d, a, b)).reshape(-1, order="F")
    return out


def max_entry_map_difference(fn, gn, d):
    return max(float(np.max(np.abs(fn(basis(d, a, b))-gn(basis(d, a, b)))))
               for a in range(d) for b in range(d))


def one_case(rng, d):
    raw = rng.normal(size=(d,d)) + 1j*rng.normal(size=(d,d))
    h = (raw+dagger(raw))/2
    jumps = [rng.normal(size=(d,d)) + 1j*rng.normal(size=(d,d)) for _ in range(3)]
    coefficients = np.array([1.0, -0.8, -1.2])
    # ||-i[H,.]||_diamond <=2||H||, ||D_V||_diamond <=2||V||^2.
    epsilon = 2*np.linalg.norm(h,2) + 2*sum(
        abs(c)*np.linalg.norm(v,2)**2 for c,v in zip(coefficients,jumps))

    def perturb(rho):
        result = -1j*(h@rho-rho@h)
        for c,v in zip(coefficients,jumps):
            g=dagger(v)@v
            result += c*(v@rho@dagger(v)-(g@rho+rho@g)/2)
        return result

    gamma=d*d*epsilon

    def residual(rho):
        return perturb(rho)+gamma*(np.trace(rho)*np.eye(d)/d-rho)

    e=np.eye(d).T.reshape(-1)/np.sqrt(d)
    p=np.eye(d*d)-np.outer(e,e.conj())
    jr=choi(residual,d)
    cmat=p@jr@p
    cmat=(cmat+dagger(cmat))/2
    vals,vecs=np.linalg.eigh(cmat)
    vl=p@jr@e
    alpha=np.vdot(e,jr@e).real
    avec=vl/np.sqrt(d)+alpha*e/(2*np.sqrt(d))
    amat=avec.reshape(d,d).T
    ham=(dagger(amat)-amat)/(2j)
    vs=[np.sqrt(max(0,x))*vecs[:,i].reshape(d,d).T
        for i,x in enumerate(vals) if x>1e-9]

    def reconstructed(rho):
        out=-1j*(ham@rho-rho@ham)
        for v in vs:
            g=dagger(v)@v
            out += v@rho@dagger(v)-(g@rho+rho@g)/2
        return out

    error=max_entry_map_difference(residual,reconstructed,d)
    smat=supermatrix(residual,d)
    min_cp=1.0
    for t in (0.0001,0.01,0.1):
        et=expm(t*smat)
        def channel(rho):
            return (et@rho.reshape(-1,order="F")).reshape(d,d,order="F")
        cj=choi(channel,d)
        min_cp=min(min_cp,float(np.linalg.eigvalsh((cj+dagger(cj))/2).min()))
    return {
        "dimension":d,
        "diamond_norm_analytic_upper_bound":float(epsilon),
        "completion_rate":float(gamma),
        "conditional_choi_min_eigenvalue":float(vals.min()),
        "reconstruction_max_entry_error":error,
        "jump_count":len(vs),
        "sum_jump_op_norm_squared":float(sum(np.linalg.norm(v,2)**2 for v in vs)),
        "claimed_rate_bound":float(d**3*epsilon),
        "hamiltonian_norm":float(np.linalg.norm(ham,2)),
        "claimed_hamiltonian_bound":float(np.sqrt(d)*epsilon),
        "minimum_channel_choi_eigenvalue":min_cp,
    }


if __name__=="__main__":
    rng=np.random.default_rng(20261109)
    cases=[one_case(rng,d) for d in (2,3,4) for _ in range(12)]
    assert max(c["reconstruction_max_entry_error"] for c in cases)<1e-8
    assert min(c["conditional_choi_min_eigenvalue"] for c in cases)>-1e-8
    assert min(c["minimum_channel_choi_eigenvalue"] for c in cases)>-1e-8
    assert all(c["sum_jump_op_norm_squared"]<=c["claimed_rate_bound"]+1e-8 for c in cases)
    assert all(c["hamiltonian_norm"]<=c["claimed_hamiltonian_bound"]+1e-8 for c in cases)
    print(json.dumps({"seed":20261109,"case_count":len(cases),"cases":cases},indent=2))
