"""Exact rational diagnostics for the joint fixed-box lemma; no threshold claim."""
from fractions import Fraction as F
from itertools import combinations
from math import exp, e, ceil, factorial
import json
from pathlib import Path

def zero(n):
    return [[F(0) for _ in range(n)] for _ in range(n)]

def ident(n):
    return [[F(i == j) for j in range(n)] for i in range(n)]

def add(a, b, scale=1):
    return [[x+scale*y for x,y in zip(r,s)] for r,s in zip(a,b)]

def mul(a,b):
    return [[sum(x*y for x,y in zip(r,c)) for c in zip(*b)] for r in a]

def channel(kraus):
    # Real Kraus matrices; column-vectorized matrix convention.
    out=zero(4)
    for v in kraus:
        for a in range(2):
            for b in range(2):
                for c in range(2):
                    for d in range(2):
                        out[a+2*b][c+2*d] += v[a][c]*v[b][d]
    return out

def product(factors):
    out=ident(4)
    for fac in factors:
        out=mul(fac,out)
    return out

def subsets(seq):
    seq=list(seq)
    for r in range(len(seq)+1):
        yield from combinations(seq,r)

t=F(1000)
a=(t*t-1)/(t*t+1)
b=2*t/(t*t+1)
amp=channel([[[1,0],[0,a]],[[0,b],[0,0]]])
rot=[[a,-b],[b,a]]
z=[[1,0],[0,-1]]
actual=[amp,channel([mul(rot,z)]),amp,channel([rot]),amp]
ideal=[ident(4),channel([z]),ident(4),ident(4),ident(4)]
fault=[add(c,l,-1) for c,l in zip(actual,ideal)]
fd=2*(1-a)+b*b
fu=2*(1-a+b)
weights=[fd,fu,fd,fu,fd]
groups=[{0,1},{1,2},{2,3},{3,4}]
checks=[]
for chosen in subsets(range(len(groups))):
    if not chosen:
        continue
    selected=[groups[j] for j in chosen]
    expanded=zero(4)
    envelope=F(0)
    for qtuple in subsets(range(5)):
        qset=set(qtuple)
        if not all(qset & g for g in selected):
            continue
        expanded=add(expanded,product([
            fault[i] if i in qset else ideal[i] for i in range(5)]))
        # Outside the marked union is resummed, not bounded as extra faults.
    union=set().union(*selected)
    for qtuple in subsets(union):
        qset=set(qtuple)
        if all(qset & g for g in selected):
            term=F(1)
            for i in qset:
                term*=weights[i]
            envelope+=term
    hybrid=zero(4)
    for removed in subsets(chosen):
        swapped=set().union(*(groups[j] for j in removed)) if removed else set()
        hybrid=add(hybrid,product([
            ideal[i] if i in swapped else actual[i] for i in range(5)]),
            (-1)**len(removed))
    assert expanded==hybrid
    r=len(chosen)
    k=max(sum(i in g for g in selected) for i in union)
    budget=max(sum(weights[i] for i in g) for g in selected)
    total=sum(weights[i] for i in union)
    m=ceil(r/k)
    tail=exp(float(total))*float(total)**m/factorial(m)
    root=(exp(float(budget))*(e*k*float(budget))**(1/k))**r
    assert e*k*float(budget)<1
    assert float(envelope)<=tail+1e-14
    assert tail<=root+1e-14
    checks.append({"marked_groups":list(chosen),"overlap":k,
                   "exact_hybrid_identity":True,
                   "positive_weight_envelope":float(envelope),
                   "factorial_tail_bound":tail,"root_bound":root})

# A channel difference is not a positive map.
assert fault[0][3][3]==-b*b
# One insertion shared by two boxes has first-order, not squared strength.
single_fault_output_trace_norm=2*b*b
assert single_fault_output_trace_norm>fd*fd
out={"scope":"exact algebra and scalar bound diagnostics, not a diamond SDP",
     "case_count":len(checks),"all_exact_hybrid_identities":True,
     "negative_fault_output_eigenvalue":str(-b*b),
     "shared_insertion_trace_norm_lower_bound":float(single_fault_output_trace_norm),
     "invalid_independent_square_bound":float(fd*fd),"checks":checks}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='checks'},indent=2))
