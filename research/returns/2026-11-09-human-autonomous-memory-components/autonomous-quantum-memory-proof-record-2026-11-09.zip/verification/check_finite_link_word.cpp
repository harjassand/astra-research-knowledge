// Exhaustive finite check of a chosen c=1 SDL realization.
// Public source: arXiv:1011.3632v2, Fig.2. See companion .py and report.
#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>
struct Queue { int n=0,k0=0,c0=0,k1=0,c1=0; };
struct Recv { int q,last,out; };
struct State { int a,m,phase,count,pc,q,last,fwd,back,out=0,completed=0; };
int main() {
 const int A=2, SYN=2, K=6, EMPTY=6;
 std::vector<Queue> qs(1);
 for(int k=0;k<K;k++) for(int c=0;c<3;c++) qs.push_back({1,k,c,0,0});
 for(int k=0;k<K;k++) for(int l=0;l<K;l++) if(l!=k)
  for(int c=0;c<3;c++) for(int d=0;d<3;d++) qs.push_back({2,k,c,l,d});
 auto qid=[&](const Queue& q) {
  if(q.n==0) return 0;
  if(q.n==1) return 1+q.k0*3+q.c0;
  return 1+K*3+(q.k0*(K-1)+(q.k1<q.k0?q.k1:q.k1-1))*9+q.c0*3+q.c1;
 };
 for(int i=0;i<(int)qs.size();i++) assert(qid(qs[i])==i);
 std::vector<Recv> rt(qs.size()*2*K);
 for(int qi=0;qi<(int)qs.size();qi++) for(int last=0;last<2;last++) for(int k=0;k<K;k++) {
  Queue old=qs[qi], q; int count=0, out=-1, nl=last;
  if(old.n>0 && old.k0==k) count=old.c0;
  else if(old.n>1 && old.k1==k) count=old.c1;
  q={1,k,(count+1<2?count+1:2),0,0};
  if(old.n>0 && old.k0!=k) q={2,k,q.c0,old.k0,old.c0};
  else if(old.n>1 && old.k1!=k) q={2,k,q.c0,old.k1,old.c1};
  if(q.c0==2) {
   if(last!=k%2) { if(k/2!=SYN) out=k/2; nl=k%2; }
   q={};
  }
  rt[(qi*2+last)*K+k]={qid(q),nl,out};
 }
 auto normalize=[](State& s) {
  if(s.phase<2 && s.count==5) {
   s.count=0; s.pc=0; s.phase++;
   if(s.phase==1) s.a^=1; else s.completed++;
  }
 };
 auto poll=[&](State& s) {
  normalize(s); if(s.phase==2 || s.pc!=1) return;
  int expected=(s.phase==0?SYN:s.m)*2+s.a;
  if(s.back==expected) s.count++;
  s.back=EMPTY; s.pc=0; normalize(s);
 };
 auto send=[&](State& s) {
  normalize(s); if(s.phase==2 || s.pc!=0) return;
  s.fwd=(s.phase==0?SYN:s.m)*2+s.a; s.pc=1;
 };
 auto receive=[&](State& s) {
  if(s.fwd==EMPTY) return;
  int k=s.fwd; auto t=rt[(s.q*2+s.last)*K+k];
  s.fwd=EMPTY; s.back=k; s.q=t.q; s.last=t.last;
  if(t.out>=0) { assert(t.out==s.m); s.out++; }
 };
 std::uint64_t total=0, active=0, terminal=0, fresh=0, fresh_fail=0;
 std::uint64_t not_done=0,current_no_delivery=0,current_once=0,current_more=0;
 int max_events=0;
 for(int m=0;m<A;m++) for(int a=0;a<2;a++) for(int phase=0;phase<3;phase++)
 for(int count=0;count<6;count++) for(int pc=0;pc<2;pc++)
 for(int q=0;q<(int)qs.size();q++) for(int last=0;last<2;last++)
 for(int fwd=0;fwd<=EMPTY;fwd++) for(int back=0;back<=EMPTY;back++) {
  total++; State s{a,m,phase,count,pc,q,last,fwd,back};
  int used=0;
  if(s.phase<2) {
   poll(s); used++;
   for(int cycle=0;cycle<10 && s.phase<2;cycle++) {
    send(s); used++; if(s.phase==2) break;
    receive(s); used++;
    poll(s); used++;
   }
  }
  if(used>max_events) max_events=used;
  if(phase==2) terminal++;
  else {
   active++;
   if(s.phase!=2) not_done++;
   if(s.out==0) current_no_delivery++;
   else if(s.out==1) current_once++;
   else current_more++;
  }
  if(phase==0 && count==0 && pc==0) {
   fresh++;
   if(!(s.phase==2 && s.out==1 && s.completed==1)) fresh_fail++;
  }
 }
 std::cout << "{\n"
 << "  \"payload_symbols\": 2,\n  \"packet_symbols_with_bit\": 6,\n"
 << "  \"queue_configurations\": " << qs.size() << ",\n"
 << "  \"total_typed_configurations\": " << total << ",\n"
 << "  \"active_inflight_configurations\": " << active << ",\n"
 << "  \"already_terminal_configurations\": " << terminal << ",\n"
 << "  \"fresh_call_configurations\": " << fresh << ",\n"
 << "  \"fresh_correct_delivery_failures\": " << fresh_fail << ",\n"
 << "  \"inflight_termination_failures\": " << not_done << ",\n"
 << "  \"inflight_current_payload_not_delivered\": " << current_no_delivery << ",\n"
 << "  \"inflight_current_payload_delivered_once\": " << current_once << ",\n"
 << "  \"inflight_current_payload_multiple_delivery\": " << current_more << ",\n"
 << "  \"max_events_until_done\": " << max_events << "\n}\n";
 return (fresh_fail||not_done||current_more)?1:0;
}
