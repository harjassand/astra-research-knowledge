"""Exact-entry qubit checks of the local QND/Pauli-frame instrument identity."""
import json
from pathlib import Path
import numpy as np

i2=np.eye(2,dtype=complex)
x=np.array([[0,1],[1,0]],dtype=complex)
z=np.diag([1,-1]).astype(complex)
projs=[(i2+z)/2,(i2-z)/2]
w=np.zeros((8,8),dtype=complex)
for xb in (0,1):
    for zb in (0,1):
        f=2*xb+zb
        p=np.linalg.matrix_power(x,xb)@np.linalg.matrix_power(z,zb)
        w[2*f:2*f+2,2*f:2*f+2]=p
assert np.array_equal(w.conj().T@w,np.eye(8))
wo=np.kron(w,i2)
count=0
for xb in (0,1):
    for zb in (0,1):
        f=2*xb+zb
        pf=np.zeros((4,4),complex)
        pf[f,f]=1
        for raw in (0,1):
            published=raw^xb
            record=np.eye(2)[:,[published]]
            physical=np.kron(np.kron(pf,projs[raw]),record)
            virtual=np.kron(np.kron(pf,projs[published]),record)
            assert np.array_equal(wo.conj().T@physical@w,virtual)
            count+=1

for xb in (0,1):
    for zb in (0,1):
        f=2*xb+zb
        for bit in (0,1):
            fp=2*(xb^(bit==0))+(zb^(bit==1))
            transition=np.zeros((4,4),complex)
            transition[fp,f]=1
            expected=np.zeros((8,8),complex)
            payload=w[2*fp:2*fp+2,2*fp:2*fp+2].conj().T@w[2*f:2*f+2,2*f:2*f+2]
            expected[2*fp:2*fp+2,2*f:2*f+2]=payload
            assert np.array_equal(w.conj().T@np.kron(transition,i2)@w,expected)
            count+=1

report={"scope":"exact entries 0,+1,-1,+1/2,-1/2; identities of Kraus operators",
        "operator_identities_checked":count,"all_equal":True,
        "reference_extension":"operator equality tensors with every untouched reference",
        "stale_frame_counterexample":{"raw_Z_bit":0,"frame_x_at_measurement":1,
            "correct_published_bit":1,"frame_x_later":0,
            "incorrect_retrospective_bit":0},
        "not_established":"a noisy classical streaming decoder or memory threshold"}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
