Autonomous quantum memory: component-proof record, 9 November 2026.

The full autonomous threshold remains unresolved. Read the separate HTML report
and the premises in proof-notes.txt before interpreting any diagnostic.

Reproduce finite checks from verification/ with Python3 and numpy:
  python3 check_fixed_box.py
  python3 check_qnd_frame.py
  python3 check_progress_word.py
  python3 completion_adversarial_check.py
  python3 check_finite_link_word.py
  python3 check_padded_cp_clock.py

The first three save their JSON next to their script. Completion prints JSON.
The padded-CP and finite-link drivers also save their own JSON.
Exact rational/operator-entry checks and floating diagnostics have different
scopes. None executes an actual streaming decoder or establishes a threshold.
The finite-link driver additionally requires clang++ and compiles its supplied
C++17 source. It exhausts typed finite configurations of a chosen base link.
Primary-source HTML files are not repackaged; the ledger records URLs/hashes.
