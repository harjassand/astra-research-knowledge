# Final attack: from observed cell gaps to finite-N prediction certificates

7 November 2026. This is a constructive follow-up, not a completed finite-N certificate theorem. It separates an additional operation that closes from the exact remaining entropy/replacement burden.

## 1. Result of the attack

**Closed:** one can construct a succinct, deterministic, admissible density-free local corrector and directly certify its uniform constitutive residual R(rho,F)=c(rho;F)-c(rho), using polynomial sampling and the observed primal/dual lower coefficient bracket. Neither the corrector nor its residual needs to be supplied as an unevaluated functional. The source's empirical-density gluing operation can be implemented with polynomial query/storage costs using fixed shared random seeds, rather than listing all microscopic inputs.

**Not closed:** a complete operational finite-N weak-prediction error bound with every coefficient numeric and checked. In the source's entropy proof, small R and a corrector norm are not the entire error: the canonical CLT variance in the gradient replacement, source/profile terms and the large-deviation entropy term also enter. The uniform finite-block canonical variance and a positive spectral lift can be made explicit as below, but I have not completed their full inhomogeneous entropy integration with all constants. It would be false to promote the acquired coefficient interval alone into a finite-N prediction certificate.

## 2. Why the closed dual optimizer is not automatically the needed corrector

The dual optimizer in `DUAL_ADAPTIVE_BRACKET.md` is a function u_(k,zeta) on the whole closed domain Gamma=Lambda^+, pasted across counts and outside environments. The source's translation/Jensen argument for a local corrector uses a function supported in Lambda^-, followed by F=phi/|Lambda|. These are different spaces. For SSEP on a path, the normalized closed dual optimizer is

u(eta)=sum_(i=0)^L(i-L/2)eta_i.

It already depends on both boundary occupations; subtracting ell leaves a count-dependent gauge supported on the whole path. A special cancellation repairs SSEP, but the claim that an arbitrary closed optimizer is a member of F_0(Lambda^-) is literally false. With nontrivial outside dependence there is an additional mismatch. A primal-dual scalar gap plus an infinity norm does not by itself supply the missing admissible-function conversion.

The safe route uses the source's actual construction, (6.34), not this shortcut. Write the large cell as a union of smaller cells. At each interior small cell use its **open primal** Poisson corrector at a clamped empirical density of the large cell; sum over small cells away from the large boundary. Normalize the resulting compactly supported function by the large volume. This is a density-free local function, because the density argument is computed from the input configuration itself. Proposition 6.7 and Lemma 6.8/Proposition 6.9 are the governing established construction and translation estimate. The density cutoff and boundary truncation are indispensable. In one dimension the source chooses small side about large_side^(1/12) and density cutoff about large_side^(-1/6).

## 3. Succinct construction of an actual finite function

Let f_p be the mean-zero open-cell Poisson solution at density p. For a queried microscopic input x it has the representation

f_p(x)=integral_0^infinity E_x j_p(X_t)dt,

with polynomial gap, bounded j_p and a fully explicit mixing-tail truncation as proved in `FOLLOWUP.md`. In the empirical-density gluing there are only polynomially many p values, namely clamped integer count/large-volume fractions. A finite computation can therefore represent all needed f_p as follows.

For each p store M independent random-seed blocks, each of sufficient finite length to specify a capped local trajectory from ANY input x. For a fixed x, the blocks generate independent trajectories of the specified open generator. Their averaged time-integrated drift is a bounded estimate fhat_p(x). Use the SAME stored seeds whenever the finite function is evaluated again. Thus fhat_p is an actual deterministic function once the seeds are fixed; it is not an oracle returning unrelated noise on repeated calls.

A union bound over all p and all 2^m microscopic inputs costs only log(number of inputs)=O(m+log(number of p)) in M. It does not require evaluating or storing all those inputs. Common randomness creates correlations between different x values, which do not invalidate this union bound. The expected value/concentration for each fixed x still uses independent seed blocks. Uniformization, a common hard proposal cap and a finite-bit probability approximation have uniform-in-x bias/failure bounds; charge their bits and allocate them before the union bound.

Consequently a polynomial seed array and a polynomial-time evaluation program give, with one high-probability event,

sup_(p,x)|fhat_p(x)-f_p(x)|<=e_f.

The minimum permitted p is inverse-polynomial in the large cell side, so every gap, logarithmic minimum-probability bound, trajectory duration and sample count remains polynomial. The function can be clipped at its explicit Poisson/mixing bound. The source's gluing then gives a finite, density-free Fhat supported in the large interior. Its radius and supremum norm are explicit program bounds. Its repeated evaluation is deterministic and local. The source's exact admissible glued function is uniformly approximated; no density differentiability of the sampled program is assumed.

### Explicit cutoff dependence and finite-bit program

Let b denote the large side, ell the small side, and a the density cutoff. The source's prescribed one-dimensional choice is ell=Theta(b^(1/12)), a=Theta(b^(-1/6)); rounding the clamped density grid changes these only by fixed factors. The open gap bound gives g^(-1)<=12 ell^2/a^2=O(b^(1/2)). Its current drift has magnitude J<=lambda ell. A truncation time

tau>=g^(-1)[(ell/2)log(1/a)+log(J/(g e_f))]

gives a uniform tail <=e_f; its size is polynomial in b and log(1/e_f). No unspecified cutoff-dependent source constant is used in this evaluator. Proposition 6.7's convergence constant already concerns this prescribed shrinking cutoff and is uniform in density; one must not reinterpret it as a fixed-cutoff theorem.

For a bounded implementation use f_p(x)=tau E_x[j_p(X_S)] plus its certified tail, with S uniform in [0,tau]. A seed block specifies a finite-grid S, a capped uniformization Poisson count, and at most H proposals, each with finitely many Bernoulli/acceptance bits. If each probability threshold has error <=2^(-b_bit), use q_bits as an upper count per proposal INCLUDING the amortized capped-Poisson categorical/CDF choices as well as local labels, and S-grid spacing <=tau 2^(-b_bit). A uniform expected-score bias bound is

2tau J[Poisson_tail+H q_bits 2^(-b_bit)+Rtau 2^(-b_bit)].

The last term uses the bounded generator time-continuity estimate; probabilities in the retained finite table are treated as the exact rational program inputs. Choose H from the explicit Poisson tail and b_bit logarithmically in the displayed polynomial parameters and inverse allocated bias. This makes the biased finite program's expectation uniformly close to the ideal truncated corrector, without assuming exact real random numbers or clocks.

Every trajectory score is bounded by B_score=tau J. For Q_p possible density values and 2^m small-cell inputs, a sufficient sample count is

M>=C B_score^2 e_f^(-2)[m log2+log(2Q_p/alpha)].

The uniform truncation/bit bias is allocated before this concentration bound. Q_p=O(b), H, q_bits, B_score and all rate-refinement precisions are polynomial in b and e_f^(-1). The source's adaptive residual test terminates at b polynomial in inverse residual accuracy, with class-dependent exponents, so shrinking the cutoff does not secretly make the construction exponential. Arbitrary physical systematic-noise floors still limit attainable precision; the digital polynomial conclusion does not remove those apparatus costs.

### Uniform approximation controls the translated energy

For two local functions of support size m with sup|F-Fhat|<=e_F,

|pi_(0,1) Gamma_(F-Fhat)|<=C m e_F,

because only O(m) translates contain an endpoint and each difference is <=2e_F. If ||F||infty,||Fhat||infty<=B_F, then the squared energy-score difference is bounded by

C lambda m e_F(1+mB_F)+C lambda m^2 e_F^2.

All quantities are polynomial in the chosen cell parameters. Choose e_f/e_F accordingly. The need for one deterministic finite function, rather than per-query random answers inside a formal density, is a real issue; the shared-seed construction resolves it.

## 4. Direct observed certificate for sup R(rho,Fhat)

For a fixed acquired local function in the **one-dimensional scalar q=1** construction, the score

Z_F(eta)=c_(0,1)(eta)[pi_(0,1)(ell+Gamma_F)(eta)]^2

is a nonnegative bounded observable on a finite interval. Its expectation is c(rho;F). Its deterministic score bound is

B_Z<=lambda[1+C m B_F]^2.

It is evaluated by finitely many local calls to the retained program. Ordinary product Bernoulli sampling estimates its expectation, with bounded-score confidence intervals. Use fresh validation coins conditional on the already frozen retained program, rather than unqualified reuse of its construction coins. No many-body equilibration is needed for this expectation.

For any bounded function Z of q Bernoulli bits, differentiation by one coordinate at a time gives the exact endpoint-safe bound

|d E_rho Z/d rho|<=2q||Z||infty,  0<=rho<=1.

Thus a uniform density mesh is effective even at rho=0,1. In particular the energy score is exactly zero at both constant configurations, because an exchange changes nothing. Densities within a_R=e_R/(CqB_Z) of the endpoints have energy <=e_R/4 and hence R<=e_R/4, since c(rho)>=0. On the remaining interval use the certified primal/dual lower coefficient bound from `DUAL_ADAPTIVE_BRACKET.md`, with that explicitly chosen inverse-polynomial cutoff. Subtract this lower c(rho) from the upper sampled energy. The resulting nonnegative envelope bounds R uniformly over ALL rho in [0,1].

Rate uncertainty is paid directly. If the retained table is within relative eta of the true table, then

R_true(rho,Fhat)
<= C_acquired(rho;Fhat)/(1-eta)-c_lower_acquired(rho)/(1+eta).

Refine eta to fit the residual budget. There is no need to prove that the retained Fhat approximates a true-material corrector: its actual true-material energy is bounded by this expression. The measured residual is the certificate.

Normalization check: the diffusion bracket is first converted by c_lower(rho)=2rho(1-rho)D_lower(rho). The sampled translated score above is already c(rho;F), not D and not a finite-cell volume-normalized coefficient. F is normalized by the large volume during the gluing/translation construction. Thus the subtraction certifies exactly the source's R=c(F)-c, with no missing factor of two or volume. At the endpoints c_lower=0 and the score is exactly zero.

An adaptive sequence of larger source-admissible gluing constructions, with the direct energy-minus-lower-coefficient test, stops when sup R<=e_R. Allocate strict error slack to approximation, rate, sampling and covering, with summable stage failure budgets such as alpha*2^(-stage^2). The published density-uniform corrector convergence proves polynomial termination at fixed physical class parameters. Its numeric rate constant is not an input to the observed test. Each stage's support, norm, seeds, rate intervals and confidence allocations are retained. This is a stronger constructive corrector acquisition operation than merely saying the source gives one.

## 5. An exact failure of naive conditional averaging

Consider the genuinely nongradient one-dimensional rate

c_(x,x+1)=1+eta_(x-1)eta_(x+2)

at density 1/2. The local-equilibrium mean exchange activity is 5/4. The exact rational open-cell calculation at L=7 gives the feasible primal upper diffusivity

U_7=276736825/222538988 <5/4.

Finite-scale variational order therefore proves D_infinity<=U_7<5/4. The correction is nonzero. Thus raw conditional averaging of the boundary activity into a density generator, without the nongradient corrector operation, gives the wrong transport coefficient even in this simple elliptic product-equilibrium system. It cannot be justified by saying that local conditional equilibrium is explicit. The exact finite witness is reproducible from `check_dual_bracket.py`; it is a finite variational certificate combined with the established infinite-volume order, not an experimental measurement.

Also, even in SSEP the coefficient duality gap and F norm can both vanish while a finite-N product source has order N^(-1/2) fluctuations of a normalized density readout. A finite-N prediction bound must separately pay source/concentration and stochastic terms. Zero coefficient residual cannot certify a noiseless finite sample.

## 6. What remains in the finite-N entropy proof

The explicit source decomposition (section 7.3, especially (7.54)–(7.62)) contains more than sup R. Schematically, with n=r(F), B=||F||infty and a mesoscopic replacement block L,

h_N(t)<=exp(t/delta)[h_N(0)+C(beta+1)sup R
 +Q_LD+integral(Q_En+Q_Omega1+Q_Omega2)],

where the reported bounds include

- Q_En <=C N^(-1)(1+n^(d+2)B)^3;
- Q_Omega2 <=C[N^(-1)L^((d+2)/2)+L^(-d)(1+n^d)](1+n^(2d)B^2+n^(d+1)B)+C/N;
- Q_Omega1 contains C/beta, beta^2 N^(-1)L^(2d+4)(1+n^(3d)B^3), and **beta times a canonical CLT replacement variance**;
- the large-deviation term uses the actual constitutive functions and the supplied smooth profile, as well as a block-size error.

The source replaces the canonical CLT term by a rate involving its quantitative homogenization constants. Replacing only sup R by an observed residual leaves that second imported quantitative term unresolved. A corrector-norm bound does not erase it.

### A concrete uniform canonical certificate

For a fixed replacement block, the source's A_L, B_(L,zeta), H_(L,zeta,F) are explicit finite observables. The relevant centered combination is of the form W=D(k/|Lambda|)A_L-(B-H). Conditional on fixed count and frozen outside, A_L is a boundary-density difference, B is a current divergence and H is a generator image, so each has canonical mean zero. A local D interval propagates into W with an explicit norm error.

Its CLT variance is a positive resolvent form <W,G^(-1)W> on that fixed-count chain. It can be certified by the same random-time correlation estimator as the dual cell, with its explicitly bounded gap and ||W||infty. A further primary-source check resolves an initially suspected exterior-size problem: in (6.78), H is L_(Lambda,zeta) applied to sum_(x in Lambda_(L-r(F)-1)) tau_x F. Every F translate is entirely INSIDE Lambda. Thus the observable's outside dependence comes only from the bare rates, within range r of the two boundaries. In one dimension there are only 2^O(r) outside patterns, independent of r(F). The earlier suspicion that H required exponentially many r(F)-dependent exterior patterns was incorrect and is corrected here before freezing this report.

Therefore enumerate all k=0,...,L and the fixed-size boundary patterns, prepare each uniform canonical inside law digitally, and estimate its resolvent form. Each chain has gap >=L^(-2). A conservative score bound is ||W||infty<=lambda+lambda L+2lambda L^2 B_F, which is polynomial. Empty/full shells are identically zero. Only the finite densities k/L with 1<=k<L are needed for D; the adaptive coefficient bracket handles their smallest density 1/L with polynomial cost.

If Dhat differs from D by e_D at k/L, then ||What-W||infty<=e_D||A||infty<=e_D in one dimension. Hence

|<W,G^(-1)W>-<What,G^(-1)What>|/L
<= [2||What||infty e_D+e_D^2]/(gL).

A microscopic rate error similarly gives ||deltaW||infty<=e_D+eta R_cell(1+2LB_F). Reversible form comparison and the resolvent Cauchy–Schwarz inequality propagate it with polynomial precision; a safe upper bound is

Var_true(W)/L <= (1-eta)^(-1)[sqrt(Var_acquired(What)/L)+||deltaW||infty/sqrt(g_acquired L)]^2.

Consequently the uniform canonical variance is an observable finite certificate. Increase the replacement block until the maximum certified value is small enough. Source Proposition 6.10 plus a sufficiently small observed R ensures termination at a class-dependent polynomial scale, but is not needed to recognize a valid measured variance bound. Typical-exterior sampling would still be invalid; enumerating all the constant-range patterns is the specific repair.

The order is essential: FIRST stop the corrector program at sup R below a strict fraction of the desired canonical-variance target and FREEZE F, its support and norm. THEN grow the replacement length L. The source gives Var(W)/L=(1/2)R+Q_L(F), where Q_L(F) decays with explicit polynomial dependence on the frozen support/norm. Growing F arbitrarily with L, or retaining a large residual floor, does not imply small canonical variance. Use safe geometry L>2r(F)+2r+4 and N>2(L+2r).

### Explicit positive spectral lift of a measured resolvent variance

Let G be a positive reversible canonical generator with gap g, let W be mean-zero multiplication, and set V=<W,G^(-1)W>. If theta=|s|||W||infty/g<1, then

lambda_max(-G+sW)<=s^2 V/(1-theta).

Proof: write a unit vector f=a1+h with <h,1>=0, and z=sqrt(<h,Gh>). The quadratic form is at most -(1-theta)z^2+2|s a|sqrt(V)z. Completing the square gives <=s^2 a^2 V/(1-theta)<=s^2V/(1-theta). This is a complete finite-dimensional positive Feynman–Kac lift, with no uncomputed constant.

Here beta>0 is an **entropy tilt parameter**, unrelated to physical inverse temperature elsewhere. For a ring of N sites and all translated contiguous L-site blocks, the sum of their closed generators is exactly (L-1)G_N. For a potential (beta N/L)sum_x a_x W_x with prescribed |a_x|<=A, decompose it together with -N^2G_N by these blocks. The conditional block parameter is s_x=beta a_x(L-1)/(NL). If beta A ||W||infty/(Ng)<=1/2, the preceding bound and conditional variational principle yield

lambda_max[-N^2G_N+(beta N/L)sum_x a_x W_x]/N
<=2 beta^2 A^2 max_(k,zeta)Var_(k,zeta)(W)/L.

The same bound holds for prescribed time-dependent a_x(t) by integrating the instantaneous norm bound. It is uniform over block counts and frozen exteriors, so overlapping blocks do not require independence. Entropy inequality against the stationary Bernoulli-1/2 path law then yields the explicit signed gradient-replacement bound

E integral_0^T (1/L)sum_x a_x(t)W_x(t)dt
<=log2/beta+2 beta A^2 T max Var(W)/L,

for any microscopic initial law, since its initial entropy is <=N log2. This is a signed integrated expectation; no integral-of-absolute-value or time-supremum statement is claimed. This closes an important pressure-input operation but is not yet the full inhomogeneous entropy theorem.

The principal identified a valid extension: a_x(t,eta) may depend on the current configuration if invariant under EVERY internal exchange of its own block, equivalently measurable with respect to that block's outside and particle count. It is a scalar on each conditional fiber, so exactly the same proof applies. This allows nonlinear block-count test coefficients. Arbitrary feedback is excluded: a two-state block with centered W=+/-1 and a=W has aW=1, hence a first-order spectral shift s rather than a centered quadratic bound. That a is not block invariant. This statement concerns mathematical test coefficients, not an unproved feedback-control generator family.

### The remaining profile/large-deviation step

The source also invokes negativity of g_delta(t), based on the PDE cancellation and regularity of the true constitutive law. A queried numerical PDE can instead use acquired coefficient intervals and a fully known smoothed profile. Its g_delta upper bound is a computable optimization over local density if every function interval/modulus is tracked, but proving it is sufficiently small and propagating it through the entropy argument is another operation. Merely citing uniform coefficient accuracy does not certify a derivative-dependent cancellation. Keeping a small positive g_delta contribution is possible, but it must appear in the final finite-N bound.

## 7. Direct weak-residual alternative: operation, failed shortcut and repair

The pressure lift bypasses unknown homogenization constants in fixed-test gradient replacement. With W normalized by L, its optimized entropy error scales like sqrt((L-1)Var(W/L)), equivalent to sqrt(Var(W)/L). The invariant-feedback extension is sound. A left-block-boundary cumulative height is outside-plus-count measurable before mean centering. Its mean-centering fiber oscillation is O(L^2/N^2), so projecting the coefficient changes the ALREADY FORMED block residual by O(L||W||infty/N). This does not automatically control the distinct bond-current to block-current averaging step.

**Exact rough-height obstruction.** In SSEP on an N-ring set eta_bar=N^(-1)sum eta_i and choose mean-zero periodic H with H_(i+1)-H_i=(eta_i-eta_bar)/N. Then summation by parts gives, identically,

sum_i H_(i+1)(eta_i-eta_(i+1))=eta_bar(1-eta_bar).

Its stationary Bernoulli(rho) expectation is chi(rho)(1-1/N). But B_x=eta_left-eta_right has canonical mean zero on every L-site block, hence E[a_x B_x]=0 for EVERY block-invariant a_x. Replacing the actual rough-height-weighted bond current by (L-1)^(-1)sum a_x B_x therefore loses an order-one term, even when the canonical residual W=A-B is exactly zero, as in SSEP. This is the equilibrium fluctuation term canceling the order-one rough-height Ito trace. The residual coefficient-projection bound does not pay this averaging error. This disproves that naive bridge, not the hydrodynamic theorem or the valid spectral lift.

**Fourier repair, identified by the principal.** Retain M fixed Fourier height modes before forming the energy. Its Ito trace is O(M/N); the deterministic H^(-1) tail of a bounded density is O(1/M). The smooth finite-mode kernel has derivative bounds C_M. Its conditional fiber oscillation is O(C_M L^2/N^2), and CENTERED block averaging has second-order coefficient error O(C_M L^2/N). This avoids the rough-height obstruction. Keep this positive repair; the counterexample does not refute it.

**Exact discrete primitive, also identified by the principal.** For block endpoint occupations a,b, interior core count k, and m_x the (L-1)-site window count, put F_L(s)=sum_(j=1)^s D(j/L). Then

D((k+a+b)/L)(b-a)=F_L(m_(x+1))-F_L(m_x).

If b!=a then k+a+b=k+1; if b=a both sides vanish. Divide by L-1 to obtain the density primitive. This removes any N/L^2 Taylor error and is computable from the acquired D intervals. It does NOT identify the nonlinear primitive of the SMALL block density with the primitive of the retained smoothed density.

A fixed weak-test net alone cannot provide that last nonlinear step. For example A(s)=s+s^2, choose smooth small a(x) with nonconstant square, let v_t=partial_xx[v+v^2+a(x)^2/2] from a constant interior density, and put r_m=v+a(x)sin(2pi m x). For sufficiently short times r_m lies in [0,1]. Its initial data converge weakly to the constant density, and its residual r_(m,t)-partial_xx A(r_m) tends to zero in H^(-s), s>2: sin^2 contributes its mean 1/2, and all remaining terms oscillate with two derivatives costing m^2. Yet v evolves while the unforced PDE from that constant density is stationary. The quadratic oscillations leave a Young-measure flux defect. This does not refute the stronger invariant-feedback/Fourier repair; it shows why boundedness and a weak residual net alone cannot substitute for nonlinear local equilibrium.

**Direct-route verdict:** the observed canonical variance, invariant pressure lift, Fourier smoothing and exact primitive are real constructive operations. The remaining gate is a compatible quantitative one-/two-block or renormalized-energy estimate linking the small-block nonlinear constitutive flux to the retained smoothed field, with correct stochastic fluctuation accounting. That operation is not proved here, so no full finite-N forecast theorem is claimed.

## 8. Precise final boundary

The adaptive coefficient certificate is complete at its stated source imports. The construction/direct energy test above supplies an admissible retained corrector with an observed all-density residual, rather than an asserted one. Uniform finite-block canonical variance and a local-to-ring spectral/entropy pressure bound are also explicit. What I have not earned is a fully effective finite-N weak-prediction certificate integrating those inputs with the inhomogeneous corrected reference, all source/profile errors, large-deviation cancellation and numerical constants. No arbitrary new-force theorem is supplied.

The local route has therefore gained another real acquisition operation, but the requested final finite-N closure remains CONDITIONAL / OPEN. It should not be promoted because the coefficient interval and corrector program are now computable.
