"""Binary radius-one PCA certificates. Floating LP search; exact Fraction verification."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json, math
import numpy as np
from scipy.optimize import linprog

ROOT=Path(__file__).resolve().parent
def words(n): return list(product((0,1),repeat=n))
def encode(w):
    v=0
    for b in w: v=2*v+b
    return v
def probability(q,x,y):
    p=F(1)
    for j,a in enumerate(y):
        z=q[encode(x[j:j+3])]
        p*=z if a else 1-z
    return p
def constraints(q,L):
    xs=words(L)
    A=[[F(1) for x in xs]]
    for y in words(L-1):
        A.append([F(int(x[:-1]==y)-int(x[1:]==y)) for x in xs])
    for y in words(L-2):
        A.append([F(int(x[1:-1]==y))-probability(q,x,y) for x in xs])
    return xs,A
def variations(g):
    k=len(g).bit_length()-1
    assert len(g)==2**k
    return [max(abs(g[x]-g[x^(1<<j)]) for x in range(len(g))) for j in range(k)]
def finish(q,L,sign,y,A,xs,extra):
    nh=2**(L-1)
    nz=[(i+1,z) for i,z in enumerate(y) if z]
    b=max(F(sign*x[L//2])-sum((z*A[i][j] for i,z in nz),F(0)) for j,x in enumerate(xs))
    h,g=y[:nh],y[nh:]
    span=max(g)-min(g); vs=variations(g)
    c=dict(L=L,sign=sign,q=list(map(str,q)),bound=str(b),bound_float=float(b),
           h=list(map(str,h)),g=list(map(str,g)),span_g=str(span),span_g_float=float(span),
           source_sensitivity=str(sum(vs,F(0))),coordinate_variations=list(map(str,vs)),
           coarse_source_sensitivity=str((L-2)*span),strict_bound_addition="1/1000000",**extra)
    verify(c)
    return c
def search_stationary(q,L,sign):
    xs,A=constraints(q,L)
    rhs=np.zeros(len(A));rhs[0]=1
    result=linprog(-np.array([sign*x[L//2] for x in xs],float),
                  A_eq=np.array(A,float),b_eq=rhs,bounds=(0,None),method="highs")
    if not result.success: raise RuntimeError(result.message)
    y=[F(float(-v)).limit_denominator(10**7) for v in result.eqlin.marginals[1:]]
    return finish(q,L,sign,y,A,xs,dict(lp_value_binary64=float(-result.fun)))
def search_operating(q,L,sign,T,delta):
    xs,A=constraints(q,L);nh=2**(L-1);ng=2**(L-2);k=L-2
    u=1+nh+ng;v=u+1;nv=v+1+k
    mat=np.zeros((len(xs)+2*ng+k*ng,nv));rhs=np.zeros(len(mat))
    mat[:len(xs),0]=-1
    mat[:len(xs),1:1+nh+ng]=-np.array(A[1:],float).T
    rhs[:len(xs)]=[-sign*x[L//2] for x in xs]
    for j in range(ng):
        mat[len(xs)+j,1+nh+j]=1;mat[len(xs)+j,u]=-1
        mat[len(xs)+ng+j,1+nh+j]=-1;mat[len(xs)+ng+j,v]=1
    row=len(xs)+2*ng
    for j in range(k):
        for x in range(ng):
            mat[row,1+nh+x]=1;mat[row,1+nh+(x^(1<<j))]=-1
            mat[row,v+1+j]=-1;row+=1
    cost=np.zeros(nv);cost[0]=1;cost[u]=1/T;cost[v]=-1/T;cost[v+1:]=float(delta)
    bounds=[(None,None)]*nv;bounds[1]=(0,0);bounds[1+nh]=(0,0)
    result=linprog(cost,A_ub=mat,b_ub=rhs,bounds=bounds,method="highs")
    if not result.success: raise RuntimeError(result.message)
    y=[F(float(z)).limit_denominator(10**7) for z in result.x[1:1+nh+ng]]
    c=finish(q,L,sign,y,A,xs,dict(T_optimized=T,delta_optimized=str(delta),
                                lp_operational_value_binary64=float(result.fun)))
    b=operating_bound(c,T,delta)
    c["operational_bound"]=str(b);c["operational_bound_float"]=float(b)
    return c
def verify(c):
    q=list(map(F,c["q"]));xs,A=constraints(q,c["L"])
    y=list(map(F,c["h"]+c["g"]));nz=[(i+1,z) for i,z in enumerate(y) if z]
    slacks=[F(c["bound"])-c["sign"]*x[c["L"]//2]+sum((z*A[i][j] for i,z in nz),F(0))
            for j,x in enumerate(xs)]
    assert min(slacks)>=0
    g=list(map(F,c["g"]))
    assert max(g)-min(g)==F(c["span_g"])
    assert sum(variations(g),F(0))==F(c["source_sensitivity"])
    return dict(exact=True,words=len(xs),minimum_slack=str(min(slacks)))
def operating_bound(c,T,delta):
    return F(c["bound"])+F(c["span_g"])/T+F(delta)*F(c["source_sensitivity"])
def ring_kernel(q,N):
    xs=words(N);P=np.empty((2**N,2**N))
    for a,x in enumerate(xs):
        ps=[float(q[4*x[(i-1)%N]+2*x[i]+x[(i+1)%N]]) for i in range(N)]
        for b,y in enumerate(xs):P[a,b]=math.prod(z if bit else 1-z for z,bit in zip(ps,y))
    return P
def ring_diagnostic(q,cs,N,horizons=(1,3,10,100)):
    P=ring_kernel(q,N);f=np.array([sum(x)/N for x in words(N)])
    val=f.copy();acc=np.zeros_like(f);out=[]
    for t in range(1,max(horizons)+1):
        acc+=val
        if t in horizons:
            lo=max(-float(operating_bound(c,t,0)) for c in cs if c["sign"]==-1 and c["L"]<=N)
            hi=min(float(operating_bound(c,t,0)) for c in cs if c["sign"]==1 and c["L"]<=N)
            a,b=float(min(acc/t)),float(max(acc/t));assert lo<=a+1e-9 and b<=hi+1e-9
            out.append(dict(T=t,min_binary64=a,max_binary64=b,certificate_lower=lo,certificate_upper=hi))
        val=P@val
    A=P.T-np.eye(len(P));A[-1,:]=1;rhs=np.zeros(len(P));rhs[-1]=1;pi=np.linalg.solve(A,rhs)
    return dict(N=N,stationary_density_binary64=float(pi@f),
                stationarity_residual=float(abs(pi@P-pi).max()),finite_time=out)
def acquisition(delta,zeta=.01):
    n=math.ceil(math.log(16/zeta)/(2*float(delta)**2))
    return dict(row_precision=float(delta),failure=zeta,rows=8,trials_per_row=n,total_trials=8*n)
def save(name,data):(ROOT/name).write_text(json.dumps(data,indent=2)+"\n")
def main():
    q=[F(1,10) if sum(x)<2 else F(4,5) for x in words(3)]
    cs=[search_stationary(q,L,s) for L in range(3,10) for s in (1,-1)]
    op=[search_operating(q,L,s,1000,F(1,1000)) for L in range(3,10) for s in (1,-1)]
    coarse=[search_operating(q,9,s,1000,F(1,100)) for s in (1,-1)]
    save("CLASSICAL_CERTIFICATES.json",cs);save("OPERATIONAL_CERTIFICATES.json",op)
    save("COARSE_PRECISION_CERTIFICATES.json",coarse)
    result=dict(exact_audits=[verify(c) for c in cs+op+coarse],
                ring_diagnostics=[ring_diagnostic(q,cs,N) for N in (5,7)],
                acquisition=[acquisition(d) for d in (.001,.01)],
                interval_T1000_delta001=[max(-c["operational_bound_float"] for c in op if c["sign"]==-1),
                                        min(c["operational_bound_float"] for c in op if c["sign"]==1)],
                interval_T1000_delta01=[-coarse[1]["operational_bound_float"],coarse[0]["operational_bound_float"]])
    save("CLASSICAL_DIAGNOSTICS.json",result)
    print(json.dumps(result,indent=2))
if __name__=="__main__":main()
