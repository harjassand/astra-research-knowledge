"""Exact local rechecks and an independent perturbed finite-ring calculation."""
from pathlib import Path
from fractions import Fraction as F
import json
import numpy as np
from local_certificates import verify,operating_bound,ring_kernel,words
from quantum_certificate import exact_certificate
p=Path(__file__).resolve().parent
checks=[]
for name in ("CLASSICAL_CERTIFICATES.json","OPERATIONAL_CERTIFICATES.json","COARSE_PRECISION_CERTIFICATES.json"):
    checks.extend(verify(c) for c in json.loads((p/name).read_text()))
ex=exact_certificate()
cs=[c for c in json.loads((p/"OPERATIONAL_CERTIFICATES.json").read_text()) if c["L"]==7]
q=list(map(F,cs[0]["q"]));delta=F(1,1000)
q=[z+(delta if j%2 else -delta) for j,z in enumerate(q)]
P=ring_kernel(q,7);v=np.array([sum(x)/7 for x in words(7)]);acc=np.zeros_like(v)
for _ in range(1000):acc+=v;v=P@v
lo=float(min(acc/1000));hi=float(max(acc/1000))
lower=max(-float(operating_bound(c,1000,delta)) for c in cs if c["sign"]==-1)
upper=min(float(operating_bound(c,1000,delta)) for c in cs if c["sign"]==1)
assert lower<=lo+1e-9 and hi<=upper+1e-9
out=dict(classical_certificates=len(checks),exact_word_inequalities=sum(x["words"] for x in checks),
         all_classical_checks_passed=True,complex_quantum_exact_LDL_checks=len(ex["exact_checks"]),
         perturbed_finite_system=dict(N=7,T=1000,row_TV="1/1000",law=list(map(str,q)),
             all_initial_configuration_min_binary64=lo,all_initial_configuration_max_binary64=hi,
             certificate_lower=lower,certificate_upper=upper),
         physical_experiments=0,additional_workers=0,
         qualification="Exact finite certificates and analytic proofs; binary64 diagnostics are separate.")
(p/"AUDIT_SUMMARY.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out,indent=2))
