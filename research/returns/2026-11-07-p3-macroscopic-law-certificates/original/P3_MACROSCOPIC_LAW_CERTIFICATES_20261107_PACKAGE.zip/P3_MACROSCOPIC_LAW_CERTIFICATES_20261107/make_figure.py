from pathlib import Path
from fractions import Fraction as F
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
p=Path(__file__).resolve().parent
c=json.loads((p/"CLASSICAL_CERTIFICATES.json").read_text())
o=json.loads((p/"OPERATIONAL_CERTIFICATES.json").read_text())
L=np.arange(3,10)
lo=np.array([-v["bound_float"] for v in c if v["sign"]==-1])
hi=np.array([v["bound_float"] for v in c if v["sign"]==1])
slo=np.array([-v["bound_float"]-.001*v["span_g_float"]-.001*float(F(v["source_sensitivity"])) for v in c if v["sign"]==-1])
shi=np.array([v["bound_float"]+.001*v["span_g_float"]+.001*float(F(v["source_sensitivity"])) for v in c if v["sign"]==1])
olo=np.array([-v["operational_bound_float"] for v in o if v["sign"]==-1])
ohi=np.array([v["operational_bound_float"] for v in o if v["sign"]==1])
plt.rcParams.update({"font.size":10,"axes.spines.top":False,"axes.spines.right":False,"svg.fonttype":"none"})
fig,ax=plt.subplots(1,2,figsize=(11.5,4.3),layout="constrained")
ax[0].fill_between(L,lo,hi,color="#1f77b4",alpha=.16)
ax[0].plot(L,lo,"o-",color="#1f77b4");ax[0].plot(L,hi,"o-",color="#1f77b4")
ax[0].set(title="Stationary bounds from exact local certificates",xlabel="Certificate window (sites)",ylabel="Mean occupation",ylim=(0,.85))
ax[0].text(5.1,.62,"9-site interval:\n[0.190199, 0.192550]",fontsize=11)
ax[1].plot(L,np.minimum(1,shi),"o--",color="#999999",label="Stationary objective, then pay costs")
ax[1].plot(L,np.maximum(0,slo),"o--",color="#999999")
ax[1].fill_between(L,olo,ohi,color="#d66b22",alpha=.18)
ax[1].plot(L,olo,"s-",color="#d66b22",label="Optimize finite-time and uncertainty cost")
ax[1].plot(L,ohi,"s-",color="#d66b22")
ax[1].set(title="Operating bounds: 1,000 cycles, row TV error 0.001",xlabel="Certificate window (sites)",ylabel="Time-averaged occupation",ylim=(0,.85))
ax[1].legend(frameon=False,loc="upper right",fontsize=8)
for a in ax:a.set_xticks(L);a.grid(alpha=.15)
fig.suptitle("A tighter stationary bound can be a worse operating certificate",fontsize=14)
fig.savefig(p/"MACROSCOPIC_CERTIFICATES.png",dpi=190)
fig.savefig(p/"MACROSCOPIC_CERTIFICATES.svg")
