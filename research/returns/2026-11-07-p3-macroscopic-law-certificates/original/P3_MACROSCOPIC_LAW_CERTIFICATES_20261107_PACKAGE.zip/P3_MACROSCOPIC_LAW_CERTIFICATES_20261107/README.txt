P3 — FINITE CERTIFICATES FOR MACROSCOPIC LAWS
7 November 2026

The complete scientific return is P3_MACROSCOPIC_LAW_CERTIFICATES_20261107_RETURN.txt.

This is a strict local-certificate completeness/operation/acquisition theorem
and a computational obstruction. It does not complete generic economical
full physical-state control.

local_certificates.py
  Binary64 LP search, exact Fraction rational repair and exhaustive local-word
  verification. Stationary and paid operating objectives for binary radius-one PCA.
quantum_certificate.py
  Exact complex-rational positive-certificate checks; separate small quantum
  binary64 dynamics.
run_audits.py
  Rechecks all exact certificates and an independently perturbed finite ring.
make_figure.py
  Research figure from emitted certificate data.
*_CERTIFICATES.json / QUANTUM_EXACT_CERTIFICATE.json
  Full inspectable witnesses.
*_DIAGNOSTICS.json / *_RUN.txt / AUDIT_SUMMARY.json
  Executed finite calculations, qualified by arithmetic type.
SOURCE_ACCESS_NOTES.txt
  New access outcomes and complete inherited notes, preserved verbatim.
MANIFEST.json
  SHA-256 package hashes.

Reproduce with existing Python, NumPy, SciPy and Matplotlib:
  OPENBLAS_NUM_THREADS=1 python local_certificates.py
  OPENBLAS_NUM_THREADS=1 python quantum_certificate.py
  OPENBLAS_NUM_THREADS=1 python run_audits.py
  python make_figure.py

The theorem covers complex quantum local laws in arbitrary fixed spatial
dimension. The finite classical emitter and supplied quantum example are
specified subsets, not a generic SDP implementation. No physical trial or
calibration record was acquired. A workspace change required restoring this
turn's own authored files and rerunning the checks; no held original was used.
All prior accepted results, source/transfer holds and activity limits remain.
