"""Exact complex-rational local certificate; separate binary64 quantum diagnostics."""
from fractions import Fraction as F
from pathlib import Path
import json,math
import numpy as np
ROOT=Path(__file__).resolve().parent

def pauli_matrix(terms):
    n=len(next(iter(terms)));D=2**n
    re=[[F(0) for _ in range(D)] for _ in range(D)]
    im=[[F(0) for _ in range(D)] for _ in range(D)]
    for word,co in terms.items():
        co=F(co)
        for col in range(D):
            row=col;phase=0
            for j,p in enumerate(word):
                mask=1<<(n-1-j);bit=int(bool(col&mask))
                if p in "XY":row^=mask
                if p=="Y":phase+=1+2*bit
                if p=="Z":phase+=2*bit
            phase%=4
            if phase==0:re[row][col]+=co
            elif phase==1:im[row][col]+=co
            elif phase==2:re[row][col]-=co
            else:im[row][col]-=co
    return re,im
def realify(re,im):
    D=len(re)
    assert all(re[i][j]==re[j][i] and im[i][j]==-im[j][i] for i in range(D) for j in range(D))
    return [re[i]+[-x for x in im[i]] for i in range(D)]+[im[i]+re[i] for i in range(D)]
def positive_ldl(A):
    n=len(A);L=[[F(int(i==j)) for j in range(n)] for i in range(n)];d=[]
    for i in range(n):
        z=A[i][i]-sum((L[i][k]**2*d[k] for k in range(i)),F(0))
        assert z>0;d.append(z)
        for j in range(i+1,n):
            L[j][i]=(A[j][i]-sum((L[j][k]*L[i][k]*d[k] for k in range(i)),F(0)))/z
    return d
def exact_certificate():
    c,a,b=F(31,100),F(27,170),F(9,34);margin=c*c-a*a-b*b
    assert margin>0;checks=[]
    for s in (1,-1):
        terms={"III":c,"IYI":-s*a,"YZY":-s*b}
        pivots=positive_ldl(realify(*pauli_matrix(terms)))
        checks.append(dict(sign=s,coefficients={k:str(v) for k,v in terms.items()},
                           realified_dimension=len(pivots),strict_LDL_pivots=list(map(str,pivots))))
    span_squared=4*(1+F(15,34)**2);assert F(11,5)**2>span_squared
    return dict(stationary_lower="9/100",stationary_upper="71/100",
                G_coefficients={"Z":"1","Y":"15/34"},G_span_squared=str(span_squared),
                G_span_certified_upper="11/5",strict_square_margin=str(margin),
                slack_min_binary64=float(c)-math.sqrt(float(a*a+b*b)),gate_cone_upper=8,
                exact_checks=checks,T1000_delta0001_interval=[.08604,.71396])
I=np.eye(2,dtype=complex);Y=np.array([[0,-1j],[1j,0]],complex);Z=np.diag([1,-1]).astype(complex)
def tensor(seq):
    out=np.array([[1]],complex)
    for a in seq:out=np.kron(out,a)
    return out
def at(A,i,N):return tensor([A if j==i else I for j in range(N)])
def unitary(N):
    W=np.array([[1,-1j],[1j,-1]],complex)/math.sqrt(2);U=tensor([W]*N);ph=[]
    for x in range(2**N):
        b=[(x>>(N-1-i))&1 for i in range(N)]
        ph.append((-1)**sum(b[i]*b[(i+1)%N] for i in range(N)))
    return np.array(ph)[:,None]*U
def reset(A,i,N,adjoint=False,p=.4):
    mask=1<<(N-1-i);iz=np.array([x for x in range(2**N) if not x&mask]);io=iz+mask;B=np.zeros_like(A)
    if adjoint:
        C=A[np.ix_(iz,iz)];B[np.ix_(iz,iz)]=C;B[np.ix_(io,io)]=C
    else:B[np.ix_(iz,iz)]=A[np.ix_(iz,iz)]+A[np.ix_(io,io)]
    return (1-p)*A+p*B
def maps(N):
    U=unitary(N)
    def forward(A):
        B=U@A@U.conj().T
        for i in range(N):B=reset(B,i,N)
        return B
    def dual(A):
        B=A.copy()
        for i in range(N):B=reset(B,i,N,True)
        return U.conj().T@B@U
    return forward,dual
def diagnostic(N):
    forward,dual=maps(N);D=2**N;zero=np.zeros((D,D),complex)
    O=sum((at(Z,i,N) for i in range(N)),zero)/N
    G=sum((at(Z+15/34*Y,i,N) for i in range(N)),zero)/N
    qs=[]
    for s in (1,-1):
        b=.71 if s==1 else -.09;Q=b*np.eye(D)-s*O+s*G-dual(s*G)
        qs.append(float(np.linalg.eigvalsh((Q+Q.conj().T)/2).min()))
    P=at(Y,0,N)@at(Z,1,N)@at(Y,2,N)
    e1=np.linalg.norm(dual(at(Z,1,N))-(.4*np.eye(D)+.6*at(Y,1,N)),ord=2)
    e2=np.linalg.norm(dual(at(Y,1,N))-.6*P,ord=2)
    val=O.copy();acc=np.zeros_like(O);out=[]
    for T in range(1,101):
        acc+=val
        if T in (1,2,10,100):
            ev=np.linalg.eigvalsh((acc+acc.conj().T)/(2*T));lo=.09-2.2/T;hi=.71+2.2/T
            assert lo<=ev.min()+1e-9 and ev.max()<=hi+1e-9
            out.append(dict(T=T,min_binary64=float(ev.min()),max_binary64=float(ev.max()),
                            certificate_lower=lo,certificate_upper=hi))
        val=dual(val)
    rho=np.eye(D)/D
    for _ in range(250):rho=forward(rho)
    return dict(N=N,dimension=D,heisenberg_identity_errors=[float(e1),float(e2)],
                global_certificate_min_eigenvalues_binary64=qs,finite_time=out,
                stationarity_residual_binary64=float(np.linalg.norm(forward(rho)-rho,ord="fro")),
                stationary_magnetization_binary64=float(np.trace(rho@O).real))
def main():
    ex=exact_certificate();ds=[diagnostic(n) for n in (4,6)]
    (ROOT/"QUANTUM_EXACT_CERTIFICATE.json").write_text(json.dumps(ex,indent=2)+"\n")
    (ROOT/"QUANTUM_DIAGNOSTICS.json").write_text(json.dumps(ds,indent=2)+"\n")
    print(json.dumps(dict(exact=ex,diagnostics=ds),indent=2))
if __name__=="__main__":main()
