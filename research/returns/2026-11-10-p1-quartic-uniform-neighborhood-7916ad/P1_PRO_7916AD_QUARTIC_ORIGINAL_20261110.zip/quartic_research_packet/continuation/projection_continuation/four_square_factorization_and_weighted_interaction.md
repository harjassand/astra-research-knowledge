# Exact translated-Hessian factorization and weighted interaction

## Scope

This note proves an exact four-square identity for the ORIGINAL J_k. It also
proves a weighted cubic interaction estimate that is uniform when the L2 mass
of a normalized one-source shear tends to zero. It does not by itself prove the
global quasiconvexity question. The near-one-source theorem below uses the
coarse compatible cubic bound (UC), whose independent proof is supplied in
`../moment_continuation/critical_cubic_and_band_stability.md` together with
`../construction_continuation/acoustic/UNIFORM_ACOUSTIC_NORMAL_FORM.md`.

Write ell=3k-1, n=k+1, m=3k+1, k>1/3, and

    lambda(A) = [3 ell (k |A_col1|^2 - |A_col2|^2) + 24k det A]/(2m).

This is exactly the supplied constitutive lambda.

## 1. Four squares

Let A have columns x,y and E have columns h,l. Write

    d_ij = A_col i . E_col j,
    c_ij = det(A_col i,E_col j).

Define bilinear forms

    L1 = c12+c21-3k d11-3d22,
    L2 = ell(k d11-d22)+(5k+1)(c12-c21),
    L3 = d12+c22+k c11+d21,
    L4 = d12+c22-k c11-d21.

Then the exact identity is

    D2J(A)[E,E] - 2 lambda(A) det E
      = ell/(4m) L1^2 + 3/(4nm) L2^2
        + 3ell/(4m) L3^2 + ell^2/(4nm) L4^2.       (1)

All four coefficients are strictly positive. Define S(A,E) to be the vector
of the four L_i multiplied by the positive square roots of their respective
coefficients. Then S is bilinear, and the right side of (1) is |S(A,E)|^2.
For compatible mean-zero V, the determinant integrates to zero, so

    H_V[A,A] = integral |S(A,V)|^2.                  (2)

At A=I and E=[[a,b],[c,d]], (1) becomes

    |S(I,E)|^2 = (ma+2d)^2/2 + ell*n*c^2/2.

The identity is proved by polynomial expansion. The accompanying verifier
checks it over the rational function field Q(k), with no numerical inference.

## 2. Fixed-source-axis control of D lambda

For every A and every X=z tensor e2,

    |Dlambda(A)[X]| <= C_lambda |S(A,X)|,
    C_lambda^2 = 3n(45k^2+12k-1)/(2m^3).            (3)

To verify this, use a constant left rotation and homogeneity to reduce X to
e1 tensor e2. At that X,

    Dlambda(A)[X] = kappa L1(A,X) + nu L2(A,X),
    kappa = 3 ell n/(4m^2),
    nu = 3(9k+1)/(4m^2).

Weighted Cauchy-Schwarz using the first two terms of (1) gives (3), with exactly
the displayed C_lambda. The left-rotation invariance of J and lambda then gives
the general z. The analogous bound holds on the first source axis by the exact
symmetry J(F B_k)=k^2 J(F), lambda(F B_k)=-k lambda(F).

This statement is restricted to the two source axes. Its constant cannot be
asserted uniform over nearby arbitrary source orientations: the acoustic
degeneracy there has fourth-order angular behavior.

## 3. Conditional-axis decomposition

Let G=Dphi be smooth and periodic. Define

    X(x2) = integral_0^1 G(x1,x2) dx1 = z(x2) tensor e2,
    V = G-X.

Both X and V are compatible mean-zero gradients, and V has zero x1-average.
The first column of X vanishes by periodicity. Since H_G is quadratic in G,
conditional averaging gives exactly

    H_G = H_X + H_V.                                (4)

Similarly the cubic moment has the exact expansion

    b_G = b_X + B + b_V,
    B:A = (1/2) integral D3J(X)[A,V,V].              (5)

The term containing X^2 V vanishes by conditional averaging. Differentiate
(1) with respect to A in the direction X, using quartic polarization, to get

    B:A = integral S(A,V).S(X,V)
          + integral Dlambda(A)[X] det V.           (6)

Choose any explicit C_S for which |S(U,W)| <= C_S |U| |W|. For example its
square can be the sum of the weighted squared Frobenius norms of the four
bilinear coefficient matrices. Hölder, (2), (3), and |det V|<=|V|^2/2 give

    |B:A| <= C_S ||X||_4 ||V||_4 sqrt(H_V[A,A])
             +(C_lambda/2)||V||_4^2 sqrt(H_X[A,A]). (7)

Consequently

    ||B||_{H_G^dagger} <= C_S ||X||_4 ||V||_4
                         +(C_lambda/2)||V||_4^2.   (8)

The notation in (8) is the dual seminorm; (7) also proves its range condition.
No lower bound on integral |X|^2 is used. In particular (7)-(8) hold uniformly
for arbitrarily concentrated normalized shears and for rotating output z(x2).

## 4. Uniform one-source reserve

Every pointwise rank-one matrix X has D2J(X) positive semidefinite, by quartic
polarization and rank-one convexity. Euler's identity gives

    D2J(X) X = 3 DJ(X),
    DJ(X):X = 4 J(X).

Thus for any rank-one-valued field X, pointwise matrix Cauchy-Schwarz followed
by integral Cauchy-Schwarz yields

    |b_X:A| <= sqrt((4/3)c_X) sqrt(H_X[A,A]).        (9)

In particular its optimized all-mean gap is at least c_X/3. For the column-2
field in Section 3, c_X=alpha ||X||_4^4 with alpha=ell/(8n).

The same reserve follows directly from the exact column identity. With p the
first column, y the second, R rotation by +90 degrees, and z=y-Rp,

    J(p,y) = alpha |z|^4 + (Rp.z)^2
             +(3n/2)|p|^2 Rp.z + n(3k+5)|p|^4/8.

For a one-source perturbation only the second column varies. Its radial
quartic Jensen remainder is at least alpha/3 times the fourth moment, while
the squared-linear term has nonnegative Jensen remainder and the linear term
has zero remainder.

## 5. Near-one-source theorem using the independently proved cubic bound

The two companion notes named in the scope statement establish the following
coarse bound uniformly for every compatible V and every A, with finite C_U(k):

    |b_V:A| <= C_U ||V||_4^2 sqrt(H_V[A,A]).        (UC)

This uses the independent compatible analysis, rather than following from
(1) alone. Let C_J satisfy |DJ(F):E|<=C_J |F|^3 |E|. Expansion of c_G, conditional
averaging, and positivity of D2J(X) give

    c_G >= alpha ||X||_4^4 - C_J ||X||_4 ||V||_4^3.

Using (4), (8), (9), and (UC),

    ||b_G||_{H_G^dagger}
       <= sqrt(4alpha/3)||X||_4^2
          + C_S ||X||_4||V||_4
          + (C_lambda/2+C_U)||V||_4^2.

Therefore there is delta(k)>0 such that ||V||_4<=delta||X||_4 implies the FULL
all-mean inequality, with optimized gap at least alpha||X||_4^4/12. One explicit
nonoptimal choice, with C'=C_lambda/2+C_U, is any positive delta satisfying

    delta<=1,
    (C_S+C')delta<=sqrt(alpha)/12,
    C_J delta^3<=alpha/12.

This conclusion is uniform over amplitudes, frequencies, and concentration of
the one-source component. It remains a neighborhood theorem, not the entire
global quasiconvexity problem. All formulas extend from smooth gradients to
W1,4 by strong periodic smoothing and conditional expectation continuity.

## 6. Computation receipt and remaining scope

The exact factorization was obtained by solving a finite linear system for a
quadratic Gram form in four bilinear invariants, then diagonalizing two 2x2
blocks. The displayed identity and all coefficients are independently checked
by verify_four_square_factorization.py. Exploratory floating-point samples
were used only to suggest the factorization and are not used in any proof.
The final verifier contains only finite symbolic arithmetic and polynomial
identity assertions. No optimization oracle, PDE oracle, installed dependency,
or external computational resource was used.

Another exact form, useful for tracking the unresolved term, is

    J_k(F) = j^2 + ell/(8n)(u+v-2j)^2
             + (ell/2)u j + ell(k-1)u^2/8.

The signed weighted minor u*j still needs a full compatible global argument.

## 7. Exact residual in a proposed sharp induction

Use the conditional-axis decomposition of Section 3 and set

    C2 = (1/2) integral D2J(X)[V,V] >= 0,
    C3 = integral DJ(V):X.

For the moment matrices M_U=[[2c_U,b_U^T],[b_U,H_U]], the exact identity is

    M_G = M_X + M_V + [[2(C2+C3),B^T],[B,0]].       (10)

The positivity of C2 does not make the interaction increment nonnegative.
For X=g E12, H_X has I in its kernel and b_X:I=0, whereas B:I need not vanish.
Hence M_X plus the interaction increment fails the PSD range condition whenever
B:I is nonzero, irrespective of the scalar C2+C3. One must transfer a reserve
from M_V; the assumption M_V>=0 alone gives no explicit amount of such reserve.

For a fully compatible exact illustration, put theta=2 pi x1, eta=2 pi x2,

    g=cos(2 eta),
    X=g E12,
    V=D[(sin(theta) cos(eta))/(2 pi) * (1,1)].

V has zero x1-average. Its entries are a=c=cos(theta)cos(eta) and
b=d=-sin(theta)sin(eta). The identity B:I=-2 integral g*c*((m/2)a+d)
therefore gives exactly B:I=-m/8. This example is NOT a negative quasiconvexity
witness: its V is rank-one-valued, and the complete field also permits direct
conditional Jensen. It only demonstrates that the putative PSD increment in
(10) is not available.

There is also an exact square completion. Combining H_V/2 with the first term
of B and the first term of C2 gives (1/2) integral |S(A+X,V)|^2. The remaining
variable-background expression contains

    integral DJ(V):X
      + integral [Dlambda(A)[X]+lambda(X)] det V.  (11)

The second integrand in (11) has a nonconstant weight. Constant-mean sharp
quasiconvexity of V cannot be applied with A+X(x2) in place of A, and the weighted
Jacobian in (11) has no free zero integral. The present exact completion does
not establish a sharp induction from V to X+V.
