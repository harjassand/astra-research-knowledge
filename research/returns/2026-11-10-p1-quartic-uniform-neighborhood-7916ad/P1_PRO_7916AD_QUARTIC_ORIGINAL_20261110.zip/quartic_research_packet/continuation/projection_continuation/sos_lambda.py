import sympy as s
k=s.symbols('k',positive=True);aa,bb,cc,dd,a,b,c,d=s.symbols('aa bb cc dd a b c d');AA=[aa,bb,cc,dd];EE=[a,b,c,d];ell=3*k-1;n=k+1;m=3*k+1
u=aa*aa+cc*cc;v=bb*bb+dd*dd;j=aa*dd-bb*cc
J=ell*(k*u-v+2*j)**2/(8*n)+ell*u*v/4+j*j;la=(3*ell*(k*u-v)+24*k*j)/(2*m)
Q=s.hessian(J,AA)-la*s.hessian(j,AA)
q=(s.Matrix(EE).T*Q*s.Matrix(EE))[0]
A=aa*a+cc*c;B=aa*b+cc*d;C=bb*a+dd*c;D=bb*b+dd*d
P=aa*c-cc*a;Qv=aa*d-cc*b;R=bb*c-dd*a;S=bb*d-dd*b
lA,lD,lQ,lR=s.symbols('lA lD lQ lR')
sol=s.solve([2*lA-m*lD-m*lQ-2*lR,m*lA-2*k*k*lD+2*k*lQ+k*m*lR],[lA,lD]);print('sol',sol,flush=True)
ls=[]
for vq,vr in [(1,0),(0,1)]:
 expr=s.factor((sol[lA]*A+sol[lD]*D+lQ*Qv+lR*R).subs({lQ:vq,lR:vr})*n*(5*k+1));ls.append(expr)
ls.extend([B+S,k*P+C]);print('ls',ls,flush=True)
inds=[(i,j) for i in range(4) for j in range(i,4)];vs=s.symbols('h:'+str(len(inds)))
target=sum(vv*ls[i]*ls[j]*(1 if i==j else 2) for vv,(i,j) in zip(vs,inds))
co=s.Poly(s.expand(target-q),*AA,*EE).coeffs()
res=s.linsolve(co,vs);print('gram',res,flush=True)
if res:
 vv=list(res)[0];H=s.zeros(4)
 for x,(i,j) in zip(vv,inds):H[i,j]=H[j,i]=s.factor(x)
 print('H',H,flush=True)
 print('H determinant',s.factor(H.det()),flush=True)
 print('H minors',[s.factor(H[:r,:r].det()) for r in range(1,5)],flush=True)
