"""Exact symbolic verification; no numerical optimization or sampling is used.

Run with the already available SymPy installation.  All assertions reduce to
equality of polynomials over Q(k), and hence hold for every real k at which the
displayed denominators are nonzero.
"""

import sympy as s

k = s.symbols("k")
ell, n, m = 3*k-1, k+1, 3*k+1
a, b, c, d, h, l, r, t = s.symbols("a b c d h l r t")
A = s.Matrix([[a, b], [c, d]])
E = s.Matrix([[h, l], [r, t]])
avec = [a, b, c, d]
evec = s.Matrix([h, l, r, t])
u, v, j = a*a+c*c, b*b+d*d, a*d-b*c
J = ell*(k*u-v+2*j)**2/(8*n) + ell*u*v/4 + j*j
lam = (3*ell*(k*u-v)+24*k*j)/(2*m)

dot = lambda x, y: (x.T*y)[0]
det = lambda x, y: s.det(s.Matrix.hstack(x, y))
x, y, H, L = A[:, 0], A[:, 1], E[:, 0], E[:, 1]
d11, d12, d21, d22 = dot(x, H), dot(x, L), dot(y, H), dot(y, L)
c11, c12, c21, c22 = det(x, H), det(x, L), det(y, H), det(y, L)
L1 = c12+c21-3*k*d11-3*d22
L2 = ell*(k*d11-d22)+(5*k+1)*(c12-c21)
L3 = d12+c22+k*c11+d21
L4 = d12+c22-k*c11-d21
weights = [ell/(4*m), 3/(4*n*m), 3*ell/(4*m), ell**2/(4*n*m)]
squares = sum(w*q*q for w, q in zip(weights, [L1, L2, L3, L4]))
translated = (evec.T*s.hessian(J, avec)*evec)[0]-2*lam*s.det(E)
assert s.cancel(squares-translated) == 0

# The zero acoustic background gives exactly the accepted two strains.
at_I = squares.subs({a: 1, b: 0, c: 0, d: 1})
assert s.cancel(at_I-(m*h+2*t)**2/2-ell*n*r*r/2) == 0

# Exact fixed-source-axis bound for D lambda.
at_E12 = {h: 0, l: 1, r: 0, t: 0}
dlambda = sum(s.diff(lam, z)*q for z, q in zip(avec, evec))
kappa = 3*ell*n/(4*m*m)
nu = 3*(9*k+1)/(4*m*m)
assert s.cancel((dlambda-kappa*L1-nu*L2).subs(at_E12)) == 0
C_lambda_sq = 3*n*(45*k*k+12*k-1)/(2*m**3)
assert s.cancel(kappa*kappa/weights[0]+nu*nu/weights[1]-C_lambda_sq) == 0

# Simplified column representation.
R = s.Matrix([[0, -1], [1, 0]])
z = y-R*x
alpha = ell/(8*n)
column_form = (alpha*dot(z,z)**2 + dot(R*x,z)**2
               + 3*n*dot(x,x)*dot(R*x,z)/2
               + n*(3*k+5)*dot(x,x)**2/8)
assert s.cancel(J-column_form) == 0
simple_form = j*j+ell*(u+v-2*j)**2/(8*n)+ell*u*j/2+ell*(k-1)*u*u/8
assert s.cancel(J-simple_form) == 0

print("PASS: four-square identity, strain reduction at I, fixed-axis lambda bound, and both column identities.")
