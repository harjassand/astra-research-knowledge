"""Bounded exploratory fixed-mean search from a projected matrix-measure seed.

The three target matrices are NOT a compatible witness. CG is used only to
produce an actually compatible nodal initial potential; every objective is
then evaluated on its actual finite-element gradients.
"""
import json
import numpy as np
from scipy.optimize import minimize
from scipy.sparse.linalg import LinearOperator,cg
from fe_search import field,adjoint,data

A=np.array([1.,0.,0.,1.])

def objective(z,N,k,details=False):
    G=field(z,N);v,g=data(G,k);c=v.mean()
    va,ga=data((G+A),k);ja=data(A[None,:],k)[0][0]
    gap=va.mean()-ja
    gr=adjoint(ga,N)/c-gap*adjoint(g,N)/c**2
    if details:return {'k':k,'N':N,'ratio':float(gap/c),'gap':float(gap),'c':float(c),
                        'A':A.tolist(),'z':z.tolist()}
    return gap/c,gr

def projected_seed(N,pattern):
    i,j=np.meshgrid(np.arange(N),np.arange(N),indexing='ij')
    scores=[j+.001*i,i+.001*j,np.cos(2*np.pi*(i+j)/N),
            np.cos(2*np.pi*(i-j)/N),np.cos(2*np.pi*(2*i+j)/N),
            np.cos(2*np.pi*(i+2*j)/N)][pattern]
    center=(N//2)*N+N//2
    order=[v for v in np.argsort(scores.ravel(),kind='stable') if v!=center]
    gp=np.array([599/600-1,11/150,-11/2880,721/720-1])
    gm=np.array([599/600-1,-11/150,11/2880,721/720-1])
    g0=np.array([1/5,0,0,-1/6])
    tar=np.empty((N*N,4));tar[center]=g0
    cut=len(order)//2;tar[order[:cut]]=gp;tar[order[cut:]]=gm
    tar=np.tile(tar,(2,1));rhs=adjoint(tar,N)
    def normal(v):
        mean=v.reshape(N,N,2).mean((0,1))
        return adjoint(field(v,N),N)+np.tile(mean,N*N)
    op=LinearOperator((rhs.size,rhs.size),matvec=normal,dtype=float)
    z,info=cg(op,rhs,rtol=1e-12,atol=1e-15,maxiter=10*N*N)
    if info!=0:raise ArithmeticError('Finite CG seed did not meet its tolerance.')
    residual=np.linalg.norm(normal(z)-rhs)
    return z,float(residual),float(np.mean(np.sum((field(z,N)-tar)**2,axis=1)))

def run(N,k,pattern,steps=900):
    z,resid,projection_error=projected_seed(N,pattern)
    start=objective(z,N,k,True)
    opt=minimize(lambda v:objective(v,N,k),z,jac=True,method='L-BFGS-B',
                 options={'maxiter':steps,'maxls':40,'ftol':1e-13,'gtol':1e-8})
    out=objective(opt.x,N,k,True)
    out.update(pattern=pattern,seed_cg_residual=resid,seed_projection_l2_squared=projection_error,
               start_ratio=start['ratio'],nit=int(opt.nit),success=bool(opt.success),message=str(opt.message))
    print(json.dumps(out),flush=True)
    return out

if __name__=='__main__':
    for k in [.334,.34,.4,1.]:
        for pattern in range(6):run(11,k,pattern)
