import sympy as S
k,s,t,x,y=S.symbols('k s t x y', real=True)
l=3*k-1;n=k+1
f1=S.Matrix([1,0]);f2=S.Matrix([s,t]);h=S.Matrix([t*x,-s*x+y]);D=k*x*f1-y*f2+h
u=1;v=s*s+t*t;q=k-v+2*t
sc=l/(2*n)*q*(k*x*x-y*y)+l/2*(v*x*x+u*y*y)
Q=l/n*(D*D.T)+sc*S.eye(2)+l*x*y*(f1*f2.T+f2*f1.T)+2*(h*h.T)
Q=S.simplify(Q)
print('Q11=',S.factor(Q[0,0]))
print('Q12=',S.factor(Q[0,1]))
print('Q22=',S.factor(Q[1,1]))
print('Qdetcoeff')
d=S.factor(Q.det());pol=S.Poly(d,x,y)
for e,c in pol.terms():print(e,S.factor(c))
# Expand determinant near t=1,s=0, slope z=x/y, weighted t-1~z²,s~z.
z,r=S.symbols('z r',real=True)
print('det y1=',S.factor(d.subs({x:z,y:1})))
print('at x0:',S.factor(Q.subs(x,0).det()))
