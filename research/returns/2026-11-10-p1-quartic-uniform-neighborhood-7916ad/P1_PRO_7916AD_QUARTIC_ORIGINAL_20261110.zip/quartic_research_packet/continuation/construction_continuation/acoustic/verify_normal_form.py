import sympy as S
k,r,s,z=S.symbols('k r s z')
ell=3*k-1;n=k+1;m=3*k+1;c=ell/(2*n);d2=r*r+s*s
A=m*m/2+(3*ell+4)*r+(2+3*c)*r*r+c*s*s
B=ell*n/2+ell*r+(2+3*c)*s*s+c*r*r
Q=S.Matrix([[A*z*z-4*c*r*s*z+c*(r*r+3*s*s), -s*(m+(2*c+2)*r)*z*z+(m+2*r+2*c*(s*s-r*r))*z+2*c*r*s],[-s*(m+(2*c+2)*r)*z*z+(m+2*r+2*c*(s*s-r*r))*z+2*c*r*s,B*z*z+(-4*s+4*c*r*s)*z+2+c*(s*s+3*r*r)]])
C4=n*m*m/4+(9*k*k+8*k+1)*r+(29*k*k+30*k+3)/(2*n)*r*r+(15*k*k+10*k+1)/(2*n)*s*s+(11*k+1)/n*r*d2+(13*k+1)/(4*n*n)*d2*d2
C2=2*r+(15*k*k+22*k+11)/(2*n)*r*r+(9*k*k-6*k-3)/(2*n)*s*s+(15*k+5)/n*r*d2+(15*k+3)/(2*n*n)*d2*d2
D=ell*(C4*z**4+6*k/n*s*(n*r+d2)*z**3+C2*z*z-6/n*s*(n*r+d2)*z+(r*r+3*s*s)/n+3*ell/(4*n*n)*d2*d2)
assert S.factor(Q.det()-D)==0
print('determinant identity: exact zero')
a,b,cc,d=S.symbols('a b cc d')
F=S.Matrix([[a,b],[cc,d]])
u=a*a+cc*cc;v=b*b+d*d;j=a*d-b*cc
J=ell*(k*u-v+2*j)**2/(8*n)+ell*u*v/4+j*j
eta=ell*n/4;sB=m*b/2+k*cc
cubic=-eta/k*b*(b*b+d*d)+sB*(-3*n/(2*k)*b*b+2/k*b*sB+ell/(2*k)*d*d-2*a*d)
assert S.factor(k*S.diff(J,b)+S.diff(J,cc)-cubic)==0
print('Bk cubic identity: exact zero')
x,y,p,q=S.symbols('x y p q')
H=S.hessian(J,(a,b,cc,d));e=S.Matrix([p*x,p*y,q*x,q*y]);h=S.expand((e.T*H*e)[0]).subs({a:1,b:s,cc:0,d:1+r})
assert S.factor(h.subs({x:z,y:1})-(S.Matrix([p,q]).T*Q*S.Matrix([p,q]))[0])==0
print('acoustic symbol identity: exact zero')
