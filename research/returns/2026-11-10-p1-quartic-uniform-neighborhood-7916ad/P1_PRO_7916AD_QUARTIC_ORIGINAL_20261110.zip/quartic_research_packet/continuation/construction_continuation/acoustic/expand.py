exec(open('/workspace/scratch/21b466b728a1/construction_continuation/acoustic/derive.py').read().split("print('Q11=")[0])
r,z=S.symbols('r z',real=True)
Q=S.simplify(Q.subs(t,1+r));d=S.Poly(S.expand(Q.det()),x,y)
print('Q entries nearI')
for i,j in [(0,0),(0,1),(1,1)]:
 print((i,j),S.factor(Q[i,j].coeff(x,0)))
 print(S.Poly(Q[i,j],x,y))
print('det coeff in r')
for e,c in d.terms():print(e,S.factor(c),S.Poly(S.factor(c/(3*k-1)),r,s))
