# Uniform acoustic normal form near the two critical orbits

Fix `k>1/3`, and write `ell=3k-1`, `n=k+1`, `m=3k+1`. Constants may depend on k, but not on Fourier support or profile concentration. This is a local coercivity theorem for the **original** density, and a nonsharp global cubic-estimate corollary. It does not prove the sharp global quasiconvexity bound.

## 1. Acoustic symbol

Define the symmetric matrix QF by

\[
a^TQ_F(\xi)a=D^2J_k(F)[a\otimes\xi,a\otimes\xi].
\]

For columns f1,f2 of F put `q=k|f1|^2-|f2|^2+2 det F`, `h=(cof F)xi`, and `D=k xi1 f1-xi2 f2+h`. Direct differentiation gives

\[
Q_F=\frac\ell n DD^T+2hh^T
+\left[\frac\ell{2n}q(k\xi_1^2-\xi_2^2)
+\frac\ell2(|f_2|^2\xi_1^2+|f_1|^2\xi_2^2)\right]I
+\ell\xi_1\xi_2(f_1f_2^T+f_2f_1^T).
\tag{1}
\]

Thus

\[
a^TQ_I(\xi)a=\tfrac12(m\xi_1a_1+2\xi_2a_2)^2
+\tfrac{\ell n}{2}\xi_1^2a_2^2,
\quad
\det Q_I(\xi)=\tfrac{\ell n m^2}{4}\xi_1^4.
\tag{2}
\]

For `B=[[0,k],[1,0]]`,

\[
a^TQ_B(\xi)a=\tfrac12(m\xi_2a_1+2k\xi_1a_2)^2
+\tfrac{\ell n}{2}\xi_2^2a_2^2.
\tag{3}
\]

The acoustic small eigenvalue at I vanishes to fourth order in source angle. A proof must retain this order.

## 2. Comparison theorem near I

There exist positive `delta_k,c_k,C_k` such that, for

\[
F_{r,s}=\begin{pmatrix}1&s\\0&1+r\end{pmatrix},
\qquad d^2=r^2+s^2\le\delta_k^2,
\]

one has, as matrix quadratic forms for every real source covector xi,

\[
\boxed{c_k[Q_I(\xi)+d^2|\xi|^2I]\le Q_{F_{r,s}}(\xi)
\le C_k[Q_I(\xi)+d^2|\xi|^2I].}
\tag{4}
\]

The transverse term has an exact distance interpretation:

\[
\operatorname{dist}(F_{r,s},\{tQ:t\in\mathbb R,Q\in SO(2)\})^2=d^2/2.
\tag{5}
\]

### Exact normal form

Put `c=ell/(2n)`, `xi=(z,1)`, and

\[
A=m^2/2+(3\ell+4)r+(2+3c)r^2+cs^2,
\quad B_0=\ell n/2+\ell r+(2+3c)s^2+cr^2.
\]

Formula (1) gives

\[
Q_{11}=Az^2-4crsz+c(r^2+3s^2),
\]
\[
Q_{12}=-s[m+(2c+2)r]z^2+[m+2r+2c(s^2-r^2)]z+2crs,
\]
\[
Q_{22}=B_0z^2+(-4s+4crs)z+2+c(s^2+3r^2).
\tag{6}
\]

For `D=r^2+s^2`, define

\[
\begin{aligned}
C_4={}&nm^2/4+(9k^2+8k+1)r
+\frac{29k^2+30k+3}{2n}r^2+\frac{15k^2+10k+1}{2n}s^2\\
&+\frac{11k+1}{n}rD+\frac{13k+1}{4n^2}D^2,
\\
C_2={}&2r+\frac{15k^2+22k+11}{2n}r^2
+\frac{9k^2-6k-3}{2n}s^2
+\frac{15k+5}{n}rD+\frac{15k+3}{2n^2}D^2.
\end{aligned}
\]

The exact determinant identity is

\[
\ell^{-1}\det Q_{F_{r,s}}(z,1)
=C_4z^4+\frac{6k}{n}s(nr+D)z^3+C_2z^2
-\frac6n s(nr+D)z+\frac{r^2+3s^2}{n}+\frac{3\ell}{4n^2}D^2.
\tag{7}
\]

### Principal part and finite remainder bound

The principal part of (7) is

\[
P_0=\frac{nm^2}{4}z^4+2rz^2+\frac{r^2+3s^2}{n}
=\frac1n\left[\frac{m^2}{4}(nz^2)^2+2r(nz^2)+r^2+3s^2\right].
\tag{8}
\]

The matrix `[[m^2/4,1],[1,1]]` is positive definite since m>2. Its least eigenvalue is at least determinant/trace,

\[
\mu_k=\frac{m^2-4}{m^2+4}>0.
\]

Because n>1,

\[
P_0\ge\frac{\mu_k}{n}(z^4+d^2).
\tag{9}
\]

Here are explicit finite coefficient bounds for the remainder. Let K4 be the sum of the absolute values of the five nonconstant coefficients in C4, and K2 the sum of the four coefficients in `C2-2r` in absolute value. Put

\[
K_3=6k(n+1)/n,\quad K_1=6(n+1)/n,\quad K_0=3\ell/(4n^2),
\quad K=K_4+K_3+K_2+K_1+K_0.
\]

For `|z|,d<=epsilon<=1`, direct estimates of (7) give

\[
|\ell^{-1}\det Q-P_0|\le K\epsilon(z^4+d^2).
\tag{10}
\]

Specifically, the five remainders are bounded by `K4 d z^4`, `K3 d^2 |z|^3`, `K2 d^2 z^2`, `K1 d^2 |z|`, and `K0 d^4`. Thus no uncontrolled asymptotic assertion is used. Taking `epsilon<=min(1,mu_k/(2nK))` proves

\[
\det Q_{F_{r,s}}(z,1)\ge\frac{\ell\mu_k}{2n}(z^4+d^2).
\tag{11}
\]

The same coefficients give the upper bound by a finite k-dependent multiple of `z^4+d^2`.

### Schur completion and the other source cone

Shrink epsilon further so that `1<=Q22<=3` in this region; (6), for example, gives

\[
|Q_{22}-2|\le(\ell n/2+\ell+6+10c)\epsilon^2.
\]

Set `q=Q12/Q22` and `q0=mz/[2+(ell n/2)z^2]`. Formula (6) implies `|q-q0|<=L_k d` by a finite coefficient bound. Exact completion gives

\[
a^TQ_Fa=Q_{22}(a_2+qa_1)^2+\frac{\det Q_F}{Q_{22}}a_1^2.
\]

Equations (11) and its upper counterpart show comparability to

\[
(a_2+qa_1)^2+(z^4+d^2)a_1^2.
\]

Replacing q by q0 preserves comparability since `(q-q0)^2<=L_k^2 d^2`. Completing the square in QI shows that this is comparable to `a^T[QI(z,1)+d^2 I]a`. The harmless factor `1+z^2` supplies the desired `|xi|^2` term. This proves (4) for `|xi1/xi2|<=epsilon`.

On the complementary cone normalize `|xi|=1`. Then `|xi1|>=epsilon/sqrt(1+epsilon^2)`. Equation (2) bounds the least eigenvalue of QI below by its positive determinant divided by its trace. Polynomial continuity gives `||Q_F-Q_I||<=L'_k d`. For sufficiently small d, QF and QI are uniformly positive definite and comparable there. Homogeneity in xi completes the proof of (4).

## 3. QR, scaling and the second orbit: no lattice change

Near a nonzero conformal matrix set `rho=|F_col1|` and take the constant output rotation Q with `Qe1=F_col1/rho`. Then `F=rho QF_{r,s}` and

\[
Q_{\rho QF_{r,s}}(\xi)=\rho^2Q Q_{F_{r,s}}(\xi)Q^T.
\tag{12}
\]

This changes only output coordinates. For the other orbit use the exact algebraic symmetry

\[
J_k(XB)=k^2J_k(X),\qquad B=\begin{pmatrix}0&k\\1&0\end{pmatrix}.
\tag{13}
\]

Indeed the column squares become v and `k^2u`, determinant becomes `-kj`, and the squared expression changes by factor `-k`. Differentiating gives

\[
Q_{FB}(\xi)=k^2Q_F(B^{-T}\xi).
\tag{14}
\]

Apply (4) to the arbitrary real argument `B^{-T}xi`, using `|B^{-T}xi|` comparable to `|xi|` with fixed k-dependent constants. This yields

\[
Q_{\rho QF_{r,s}B}(\xi)
\asymp_k\rho^2 Q[Q_B(\xi)+d^2|\xi|^2I]Q^T.
\tag{15}
\]

**No potential is pulled back by B.** Equation (14) is used only as an identity of acoustic symbols valid for all real arguments. Equation (15) is summed over the original integer Fourier lattice. No theorem uniform over transformed or arbitrary lattices is assumed.

## 4. Direct critical-B proof on the original torus

Write `G=[[a,b],[c,d]]=Dphi`, `eta=ell n/4`, `sB=(m/2)b+k c`. Exact algebra gives

\[
\tfrac12D^2J_k(B)[G,G]=s_B^2+\eta d^2-\frac{3kn}{2}\det G,
\tag{16}
\]

\[
DJ_k(G):B=-\frac\eta k b(b^2+d^2)
+s_B\left[-\frac{3n}{2k}b^2+\frac2k b s_B
+\frac\ell{2k}d^2-2ad\right].
\tag{17}
\]

The determinant in (16) has zero integral. At Fourier mode `(p,q)`, minimizing over the second-row potential gives

\[
|s_B|^2+\eta|d|^2\ge\frac{m^2\eta}{4}
\frac{q^2}{k^2p^2+\eta q^2}|b|^2,
\]

and consequently

\[
\tfrac12H_G[B,B]\ge\frac{m^2\eta}{4\max(k^2,\eta)}\|R_2b\|_2^2.
\tag{18}
\]

The coordinate-swapped scalar interpolation lemma proved by the moment role bounds `integral |b|^3` by `C ||G||4^2 ||R2 b||2`. All remaining terms in (17) have an explicit sB or d factor, and Holder controls them. Thus the critical B cubic estimate is valid directly on the original unit torus.

## 5. Uniform all-background nonsharp cubic estimate

Use the moment role's two critical estimates (with the direct original-lattice B proof above):

\[
|b_G:I|\le M_k\|G\|_4^2\sqrt{H_G[I,I]},\qquad
|b_G:B|\le M'_k\|G\|_4^2\sqrt{H_G[B,B]}.
\tag{19}
\]

Then a finite constant Ck exists such that every constant real matrix F and every mean-zero periodic compatible `G in L4` satisfy

\[
\boxed{|b_G:F|\le C_k\|G\|_4^2\sqrt{H_G[F,F]}.}
\tag{20}
\]

Here `b_G=integral DJ_k(G)` and `H_G[F,F]=integral D2J_k(F)[G,G]`, by quartic polarization.

Near the first orbit write `F=rho Q(I+D)`, `|D|=d`, and let `V=Q^T G`. This is still a compatible gradient on the original torus. Parseval in (4) and (12) gives

\[
H_G[F,F]\ge c_k\rho^2[H_V[I,I]+d^2\|V\|_2^2].
\tag{21}
\]

Left rotation invariance and (19) imply

\[
\begin{aligned}
|b_G:F|&\le\rho[|b_V:I|+|b_V:D|]\\
&\le\rho\|V\|_4^2[M_k\sqrt{H_V[I,I]}+C_k^{\rm poly}d\|V\|_2].
\end{aligned}
\]

The second term uses only `|DJ_k(X)|<=C_k^poly |X|^3` and Holder with exponents 4,4,2. Equation (21) proves (20). Near the other orbit use (15), the critical B bound and `|DB|<=max(1,k)d` in exactly the same argument.

For the remaining matrices normalize `|F|=1` and remove sufficiently small open neighborhoods of the two critical orbits. The supplied complete acoustic-zero classification implies strict positivity of QF on every unit output/source pair in this remaining compact set. Continuity and compactness therefore give a positive uniform ellipticity constant there. It follows that `H_G[F,F]>=c_k||G||2^2`, so the elementary cubic Holder estimate proves (20). Homogeneity in F includes all nonzero matrices, and F=0 is immediate.

This last compactness step is a finite-dimensional theoretical existence argument, not an optimization oracle. The near-orbit constants above arise from finite polynomial coefficient bounds. No efficient numerical value of the final Ck is asserted or needed.

## 6. Verification and scope

The standard exact-symbolic script `verify_normal_form.py` independently checks three polynomial identities against the original density: the acoustic formula (6), determinant formula (7), and cubic identity (17). All three differences simplified to exact zero. The derivation and finite remainder bounds are displayed above, so no floating sample or numerical optimizer is used as a proof step.

The interpolation input is proved in the moment role's `moment_continuation/critical_cubic_and_band_stability.md`, using classical multiplier and complex-interpolation theorems. The statement (20) is nonsharp. It does not establish `b_G^T H_G^dagger b_G<=2c_G`; its constant has not been shown to equal the required sharp value. It supports a concentration- and frequency-independent neighborhood theorem, but does not resolve the original inequality for arbitrary compatible fields.
