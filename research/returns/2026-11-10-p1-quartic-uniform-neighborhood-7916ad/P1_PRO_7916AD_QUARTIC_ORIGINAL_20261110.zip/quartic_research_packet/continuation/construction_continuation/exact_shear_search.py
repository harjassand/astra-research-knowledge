from exact_shear_polygons import *
import itertools, pathlib

def evaluate(shears):
 cells,counts=compose(shears,maxcells=10000)
 total=Z;mean=[[Z,Z],[Z,Z]];p0=Z;norm=Z;coeff=[Z,Z,Z]
 for poly,M,t in cells:
  ar=area(poly);total+=ar
  a,b=M[0];c,d=M[1]
  assert a*d-b*c==1
  for i in (0,1):
   for j in (0,1):mean[i][j]+=ar*M[i][j]
  u=a*a+c*c;v=b*b+d*d
  coeff[0]+=ar*u*u;coeff[1]+=ar*4*u;coeff[2]+=ar*(v*v+2*u*v-4*v)
  norm+=ar*((a-1)**2+b*b+c*c+(d-1)**2)**2
 assert total==1 and mean==[[1,0],[0,1]]
 coeff[0]-=1;coeff[1]-=4;coeff[2]+=1
 assert coeff[0]>=0 and coeff[1]>=0
 p0=coeff[0]/9+coeff[1]/3+coeff[2]
 return dict(cell_counts=counts,reduced_endpoint=str(p0),ratio=float(p0/norm) if norm else 0.,coeff=list(map(str,coeff)),strict_negative=p0<0)

if __name__=='__main__':
 outfile=pathlib.Path(__file__).with_name('exact_shear_search_results.jsonl')
 start=time.perf_counter();count=0;best=None
 with outfile.open('w') as out:
  for p,r,a,q,adjust,phase in itertools.product([Q(1,2),Q(1,8),Q(1,32)],[Q(1,2),Q(1,8),Q(1,32)],[Q(1,4),Q(1),Q(4),Q(16)],[Q(-1,5),Q(1,5)],[False,True],[False,True]):
   b=q/a;h=a*p;v=b*r;factor=1/(1+q) if adjust else O
   s=[(0,h,p,Z),(1,v,r,Z),(0,-h*factor,p,-v/2 if phase else Z),(1,-v*factor,r,h/2 if phase else Z)]
   d=evaluate(s);d.update(shears=[[int(z[0])]+list(map(str,z[1:])) for z in s],elapsed=time.perf_counter()-start)
   out.write(json.dumps(d)+'\n');out.flush();count+=1
   if best is None or d['ratio']<best['ratio']:best=d
   if count%24==0 or d['strict_negative']:print(json.dumps(dict(count=count,elapsed=time.perf_counter()-start,best_ratio=best['ratio'],max_cells=max(best['cell_counts']),negative=d['strict_negative'])),flush=True)
   if d['strict_negative']:break
 print(json.dumps(dict(done=count,elapsed=time.perf_counter()-start,best=best)),flush=True)
