"""Exact original-J_k verifier for periodic P1 finite elements.

Input: integer N>=2, rational-string k, 2x2 rational-string A, and N*N*2
rational-string nodal values z in (i,j,output) order. Every square is split
into (00,10,11) and (00,11,01). The potential is continuous and periodic;
its piecewise constant gradient is therefore admissible in W^{1,4}.
"""
from fractions import Fraction as Q
import json,sys

def J(F,k):
    a,b,c,d=F;u=a*a+c*c;v=b*b+d*d;j=a*d-b*c
    return (3*k-1)*(k*u-v+2*j)**2/(8*(k+1))+(3*k-1)*u*v/4+j*j

def verify(d):
    N=d['N'];k=Q(d['k'])
    if type(N)!=int or N<2 or k<=Q(1,3):raise ValueError('Invalid N or k.')
    vals=d['z']
    if len(vals)!=2*N*N or any(isinstance(v,float) for v in vals):
        raise ValueError('Nodal values must be exact rational strings.')
    z=list(map(Q,vals));A=[Q(v) for row in d['A'] for v in row]
    def p(i,j):
        ind=2*((i%N)*N+(j%N));return z[ind:ind+2]
    total=Q(0);sg=[Q(0)]*4;sd=Q(0)
    for i in range(N):
        for j in range(N):
            p00,p10,p01,p11=p(i,j),p(i+1,j),p(i,j+1),p(i+1,j+1)
            for left,right,bottom,top in [(p00,p10,p10,p11),(p01,p11,p00,p01)]:
                G=[]
                for a in range(2):G.extend([N*(right[a]-left[a]),N*(top[a]-bottom[a])])
                sg=[x+y for x,y in zip(sg,G)];sd+=G[0]*G[3]-G[1]*G[2]
                total+=J([x+y for x,y in zip(A,G)],k)
    assert sg==[0,0,0,0] and sd==0
    total/=2*N*N;gap=total-J(A,k)
    return {'integral_J':str(total),'J_A':str(J(A,k)),'gap':str(gap),
            'strict_negative':gap<0,'triangles':2*N*N,
            'arithmetic':'exact rational integration of compatible piecewise affine potential'}

if __name__=='__main__':
    with open(sys.argv[1]) if len(sys.argv)>1 else sys.stdin as f:d=json.load(f)
    print(json.dumps(verify(d),indent=2))
