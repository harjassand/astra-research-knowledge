"""Exact periodic PL shear compositions; standard library rational arithmetic only.
A shear is (output_axis, peak_height, knot_fraction, phase).
h has h(0)=h(1)=0 and h(p)=height, extended with period one.
It adds h(other coordinate + phase) to output coordinate.
Every retained polygon carries the exact affine map from the original unit square.
"""
from fractions import Fraction as Q
import json, sys, time
Z=Q(0); O=Q(1)

def area(poly):
 return abs(sum(x*poly[(i+1)%len(poly)][1]-y*poly[(i+1)%len(poly)][0] for i,(x,y) in enumerate(poly)))/2

def clip(poly, row, c, keep_above):
 if not poly:return []
 out=[]
 prev=poly[-1]; pv=row[0]*prev[0]+row[1]*prev[1]-c; pi=pv>=0 if keep_above else pv<=0
 for cur in poly:
  cv=row[0]*cur[0]+row[1]*cur[1]-c; ci=cv>=0 if keep_above else cv<=0
  if ci!=pi:
   t=pv/(pv-cv)
   out.append((prev[0]+t*(cur[0]-prev[0]),prev[1]+t*(cur[1]-prev[1])))
  if ci:out.append(cur)
  prev,pv,pi=cur,cv,ci
 # Remove successive repeats introduced at boundary vertices.
 ans=[]
 for p in out:
  if not ans or p!=ans[-1]:ans.append(p)
 if len(ans)>1 and ans[-1]==ans[0]:ans.pop()
 return ans

def compose(shears,maxcells=200000):
 cells=[([(Z,Z),(O,Z),(O,O),(Z,O)],((O,Z),(Z,O)),(Z,Z))]
 counts=[]
 for out,h,p,phase in shears:
  out=int(out);h=Q(h);p=Q(p);phase=Q(phase)
  assert out in (0,1) and 0<p<1
  source=1-out;new=[]
  if h==0: counts.append(len(cells));continue
  for poly,M,t in cells:
   row=M[source];shift=t[source]+phase
   vals=[row[0]*x+row[1]*y+shift for x,y in poly]
   low=min(vals); high=max(vals)
   for integer in range(low.numerator//low.denominator,high.numerator//high.denominator+1):
    for left,right,s,intercept in [(Q(integer),Q(integer)+p,h/p,Z),(Q(integer)+p,Q(integer+1),-h/(1-p),h/(1-p))]:
     if right<=low or left>=high:continue
     part=clip(clip(poly,row,left-shift,True),row,right-shift,False)
     if len(part)<3 or area(part)==0:continue
     N=[list(r) for r in M];T=list(t)
     N[out]=[M[out][i]+s*M[source][i] for i in (0,1)]
     T[out]+=s*(t[source]+phase-Q(integer))+intercept
     new.append((part,tuple(map(tuple,N)),tuple(T)))
  cells=new;counts.append(len(cells))
  if len(cells)>maxcells:raise RuntimeError('Finite cell budget exceeded')
 return cells,counts

def J(M,k):
 a,b=M[0];c,d=M[1];u=a*a+c*c;v=b*b+d*d;j=a*d-b*c
 return (3*k-1)*(k*u-v+2*j)**2/(8*(k+1))+(3*k-1)*u*v/4+j*j

def energy(shears,k=Q(17,50),maxcells=200000,include_cells=False):
 start=time.perf_counter();k=Q(k);cells,counts=compose(shears,maxcells)
 total=Z;Mmean=[[Z,Z],[Z,Z]];e=Z
 for poly,M,t in cells:
  ar=area(poly);total+=ar
  assert M[0][0]*M[1][1]-M[0][1]*M[1][0]==1
  for i in (0,1):
   for j in (0,1):Mmean[i][j]+=ar*M[i][j]
  e+=ar*J(M,k)
 assert total==1 and Mmean==[[1,0],[0,1]]
 gap=e-J(((O,Z),(Z,O)),k)
 result=dict(k=str(k),shears=[[int(s[0])]+list(map(str,s[1:])) for s in shears],cell_counts=counts,gap=str(gap),gap_float=float(gap),strict_negative=gap<0,seconds=time.perf_counter()-start)
 if include_cells:result['cells']=[dict(polygon=[[str(v) for v in p] for p in poly],M=[[str(v) for v in r] for r in M],t=list(map(str,t))) for poly,M,t in cells]
 return result

if __name__=='__main__':
 data=json.load(open(sys.argv[1]));print(json.dumps(energy(data['shears'],data.get('k','17/50'),include_cells=data.get('include_cells',False))))
