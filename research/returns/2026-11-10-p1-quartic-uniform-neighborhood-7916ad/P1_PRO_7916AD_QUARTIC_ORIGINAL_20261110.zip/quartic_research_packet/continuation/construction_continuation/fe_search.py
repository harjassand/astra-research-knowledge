"""Exploratory compatible periodic P1 finite-element search, not a certificate."""
import sys, json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'variational'))
from fourier_search import data
import numpy as np
from scipy.optimize import minimize

def field(z,N):
    p=z.reshape(N,N,2)
    px=np.roll(p,-1,axis=0);py=np.roll(p,-1,axis=1)
    pxy=np.roll(px,-1,axis=1)
    t1=np.stack((px-p,pxy-px),axis=-1)*N
    t2=np.stack((pxy-py,py-p),axis=-1)*N
    return np.stack((t1,t2)).reshape(-1,4)

def adjoint(d,N):
    P=d.reshape(2,N,N,2,2);P1,P2=P
    v=-P1[:,:,:,0]-P2[:,:,:,1]
    v+=np.roll(P1[:,:,:,0]-P1[:,:,:,1],1,axis=0)
    v+=np.roll(np.roll(P1[:,:,:,1]+P2[:,:,:,0],1,axis=0),1,axis=1)
    v+=np.roll(P2[:,:,:,1]-P2[:,:,:,0],1,axis=1)
    return (v/(2*N)).ravel()

def objective(z,N,k,details=False):
    G=field(z,N)
    val,grad,H=data(G,k,True);c=val.mean();b=grad.mean(0)
    ev=np.linalg.eigvalsh(H)
    if ev[0]>1e-13*ev[-1]:A=-np.linalg.solve(H,b)
    else:A=-np.linalg.pinv(H,rcond=1e-13)@b
    delta=c+b@A/2
    _,DJ=data(G+A,k)
    gr=adjoint(DJ,N)/c-delta*adjoint(grad,N)/c**2
    if details:
        return {'k':k,'N':N,'ratio':float(delta/c),'gap':float(delta),'c':float(c),
                'A':A.tolist(),'H_eigen':ev.tolist(),'mean_gradient':G.mean(0).tolist(),
                'mean_det_G':float(np.mean(G[:,0]*G[:,3]-G[:,1]*G[:,2])),
                'z':z.tolist()}
    return delta/c,gr

def seed_field(N,eps,seed,band=True):
    rng=np.random.default_rng(seed)
    g=np.full(N,-1/(N-1));g[N//2]=1
    p=np.zeros((N,N,2));p[:,:,0]=np.r_[0,np.cumsum(g[:-1])]/N
    r=rng.normal(size=p.shape)
    if band:
        mask=np.zeros(N);mask[N//2:N//2+2]=1
        r*=mask[None,:,None]
    G0=field(p.ravel(),N);Gr=field(r.ravel(),N)
    r*=eps*np.mean(np.sum(G0*G0,1)**2)**.25/np.mean(np.sum(Gr*Gr,1)**2)**.25
    p+=r;p-=p.mean((0,1))
    return p.ravel()

def run(N,k,eps,seed,steps=500,band=True):
    z=seed_field(N,eps,seed,band)
    before=objective(z,N,k,True)
    res=minimize(lambda x:objective(x,N,k),z,jac=True,method='L-BFGS-B',
                 options={'maxiter':steps,'maxls':40,'ftol':1e-13,'gtol':1e-8})
    out=objective(res.x,N,k,True)
    out.update(seed=seed,eps=eps,band=band,nit=int(res.nit),success=bool(res.success),
               start_ratio=before['ratio'],message=str(res.message))
    print(json.dumps(out),flush=True)
    return out

if __name__=='__main__':
    for k in [.334,.34,.4,1.]:
        for eps in [.03,.3]:
            run(8,k,eps,1,600,True)
