"""Bounded exploratory refinement of already compatible FE/Fourier seeds."""
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
from fe_search import objective,field

HERE=Path(__file__).resolve().parent

def prolong(z,N):
    p=np.array(z).reshape(N,N,2);r=np.zeros((2*N,2*N,2))
    r[::2,::2]=p
    r[1::2,::2]=(p+np.roll(p,-1,axis=0))/2
    r[::2,1::2]=(p+np.roll(p,-1,axis=1))/2
    r[1::2,1::2]=(p+np.roll(np.roll(p,-1,axis=0),-1,axis=1))/2
    return r.ravel()

def fourier_nodes(d,N):
    xy=np.arange(N)/N;x,y=np.meshgrid(xy,xy,indexing='ij')
    phi=np.zeros((N,N,2));z=d['z'];pos=0
    for q in d['modes']:
        norm=np.linalg.norm(q);arg=2*np.pi*(q[0]*x+q[1]*y)
        for v in [np.sin(arg),-np.cos(arg)]:
            for row in range(2):
                phi[:,:,row]+=z[pos]*v/(2*np.pi*norm);pos+=1
    return phi.ravel()

def refine(z,N,k,source,steps):
    start=objective(z,N,k,True)
    res=minimize(lambda v:objective(v,N,k),z,jac=True,method='L-BFGS-B',
                 options={'maxiter':steps,'maxls':40,'ftol':1e-13,'gtol':1e-8})
    d=objective(res.x,N,k,True)
    d.update(source=source,nit=int(res.nit),success=bool(res.success),start_ratio=start['ratio'])
    print(json.dumps(d),flush=True)
    return d

if __name__=='__main__':
    ds=[json.loads(l) for l in (HERE/'fe_results.jsonl').read_text().splitlines()]
    fs=[json.loads(l) for l in (HERE.parent/'variational/search_results_large.jsonl').read_text().splitlines()]
    for k in [.334,.34,.4,1.]:
        old=min((d for d in ds if d['k']==k),key=lambda d:d['ratio'])
        mid=refine(prolong(old['z'],8),16,k,'prolonged_FE8',900)
        refine(prolong(mid['z'],16),32,k,'prolonged_FE16',1200)
        f=min((d for d in fs if d['k']==k),key=lambda d:d['ratio'])
        refine(fourier_nodes(f,32),32,k,'Fourier4_nodes',1200)
