"""Certify the exact decimal-rational realizations of all saved FE outputs.

The optimizer's decimal tokens define rational nodal values and affine means.
No claim about the optimizer's optimality or floating arithmetic is used.
Every reported sign below is a Fraction comparison for an admissible P1 field.
"""
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import json
import time
from exact_fe_gap import verify

ROOT = Path(__file__).resolve().parent
SOURCES = ("fe_results.jsonl", "fe_refined_results.jsonl", "fe_fixed_mean_results.jsonl")


def main():
    start = time.perf_counter()
    results = []
    triangles = 0
    max_denominator_bits = 0
    source_hashes = {}
    for name in SOURCES:
        raw = (ROOT / name).read_bytes()
        source_hashes[name] = sha256(raw).hexdigest()
        for line_number, line in enumerate(raw.decode().splitlines(), 1):
            row = json.loads(line, parse_float=str)
            flat_mean = [str(v) for v in row["A"]]
            data = {
                "N": row["N"], "k": str(row["k"]),
                "A": [flat_mean[:2], flat_mean[2:]],
                "z": [str(v) for v in row["z"]],
            }
            for token in data["z"] + flat_mean + [data["k"]]:
                max_denominator_bits = max(max_denominator_bits, Fraction(token).denominator.bit_length())
            answer = verify(data)
            triangles += answer["triangles"]
            gap = Fraction(answer["gap"])
            results.append({"source": name, "line": line_number, "k": data["k"],
                            "N": data["N"], "gap": answer["gap"],
                            "strict_positive": gap > 0, "strict_negative": gap < 0,
                            "triangles": answer["triangles"]})
    summary = {
        "fields": len(results), "triangles_evaluated": triangles,
        "strict_positive": sum(r["strict_positive"] for r in results),
        "strict_negative": sum(r["strict_negative"] for r in results),
        "maximum_input_denominator_bits": max_denominator_bits,
        "seconds": time.perf_counter() - start,
        "source_sha256": source_hashes,
        "meaning": "Exact signs for decimal-rational P1 realizations; no optimization guarantee.",
        "results": results,
    }
    (ROOT / "saved_fe_exact_signs.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({k: v for k, v in summary.items() if k not in ("results", "source_sha256")}, indent=2))


if __name__ == "__main__":
    main()
