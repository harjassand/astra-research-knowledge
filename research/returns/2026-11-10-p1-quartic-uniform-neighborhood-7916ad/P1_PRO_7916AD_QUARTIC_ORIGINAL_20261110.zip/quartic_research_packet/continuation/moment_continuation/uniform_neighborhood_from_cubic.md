# A uniform neighborhood of every one-direction compatible field

The uniform cubic estimate (UC) used below is proved by combining the critical-background interpolation argument in `critical_cubic_and_band_stability.md` with the all-background acoustic comparison in `../construction_continuation/acoustic/UNIFORM_ACOUSTIC_NORMAL_FORM.md`. The moment principal independently reviewed that comparison's principal-part bound, remainder estimates, Schur completion, and unchanged-lattice handling. This is a restricted positive theorem, not full global quasiconvexity.

Let `J=J_k`, `k>1/3`, and write `J(F)=T(F,F,F,F)` for its symmetric polarization. For a compatible mean-zero field `G`, set

\[
c_G=\int J(G),\quad b_G=\int DJ(G),\quad
H_G[F,F]=\int D^2J(F)[G,G].
\]

Then `Delta_G(A)=c_G+b_G:A+H_G[A,A]/2` is the all-mean gap.

## Available uniform cubic estimate

The two proof components above establish a finite `C=C_k` satisfying

\[
|b_G:F|\le C\|G\|_4^2\sqrt{H_G[F,F]}
\quad\text{for every compatible }G\text{ and constant }F.
\tag{UC}
\]

This is homogeneous in `F`; no sharp constant is asserted.

## Polarization with two norms

For fixed `F`, put `N(U)=||U||4`, `E(U)=sqrt(H_U[F,F])`, and

\[
P_F(U)=b_U:F=4\int T(F,U,U,U),\qquad
C_F(U,V,W)=4\int T(F,U,V,W).
\]

The quadratic nonnegativity on compatible gradients makes `E` a seminorm. Real polarization over eight sign choices, after normalizing each nonzero input to have `N=1`, gives

\[
|C_F(U,V,W)|\le\frac32C\big[
E(U)N(V)N(W)+N(U)E(V)N(W)+N(U)N(V)E(W)\big].
\tag{1}
\]

Each signed sum has `N<=3` and `E<=sum E`; the prefactor is `1/48`, so the bound is `(8/48)*9=3/2`. Zero inputs follow by continuity.

## Projection to one source direction

Choose any primitive nonzero integer vector `q` (divide any given integer vector by the greatest common divisor of its coordinates). Let `S` be the Fourier projection of `G` onto frequencies parallel to `q`, and put `W=G-S`. This projection is conditional expectation along the compact subgroup transverse to `q`, hence contracts every `Lp`, `p>=1`.

Compatibility implies `S(x)=Y(q dot x) tensor xi`, with `xi=q/|q|`; thus `rank S<=1` pointwise even if its output direction varies. Put `s=||S||4` and `w=||W||4`. Orthogonality gives

\[
H_G=H_S+H_W,\qquad \int T(F,S,S,W)=0.
\tag{2}
\]

The product of two parallel-frequency fields has only parallel frequencies, whereas `W` has none. Strong `L4` Fejer approximation justifies (2) for general fields.

On these rank-one matrices,

\[
J(Y\otimes\xi)=\frac\ell{8n}
\left(k^2\xi_1^4+2\xi_1^2\xi_2^2+\xi_2^4\right)|Y|^4
\ge\gamma|Y|^4,
\quad\gamma=\frac{\ell\min(1,k^2)}{8n}>0.
\tag{3}
\]

## Keeping a quadratic reserve

The pointwise rank-one quartic increment lemma gives `Delta_S(A)>=c_S/3` for every `A`. Equivalently,

\[
b_S^T H_S^\dagger b_S\le\frac43c_S.
\]

Completing the square with coefficient `5/12` retains part of the quadratic term:

\[
\Delta_S(A)\ge\frac15c_S+\frac1{12}H_S[A,A]
\ge\frac\gamma5s^4+\frac1{12}H_S[A,A].
\tag{4}
\]

This does not depend on `||S||2`, concentration, orientation or Hessian conditioning.

## Paying for the cubic interactions

By (2), `(b_G-b_S):A=P_A(W)+3 C_A(S,W,W)`. Write `e_S=sqrt(H_S[A,A])` and `e_W=sqrt(H_W[A,A])`. Equations (UC) and (1) imply

\[
|(b_G-b_S):A|\le C(w^2+9sw)e_W+\frac92Cw^2e_S.
\tag{5}
\]

The original `H_W/2` and retained `H_S/12` pay for these independently:

\[
\tfrac12e_W^2-C(w^2+9sw)e_W\ge-\tfrac12C^2(w^2+9sw)^2,
\]

\[
\tfrac1{12}e_S^2-\tfrac92Cw^2e_S\ge-\tfrac{243}{4}C^2w^4.
\]

If `C_poly` is the sum of the absolute monomial coefficients of `J`, polarization also gives `|c_G-c_S|<=4 C_poly(s+w)^3 w`. Therefore, for every affine mean,

\[
\boxed{\Delta_G(A)\ge
\frac\gamma5s^4-4C_{\rm poly}(s+w)^3w
-\frac{C^2}{2}(w^2+9sw)^2-\frac{243}{4}C^2w^4.}
\tag{6}
\]

No reserve is spent twice.

## Uniform neighborhood

Set

\[
\theta_0=\min\left\{1,\frac{\gamma}{640C_{\rm poly}},
\frac{\gamma}{2215C^2}\right\}>0.
\]

If `s>0` and `w<=theta0 s`, then

\[
\boxed{\Delta_G(A)\ge\frac\gamma{10}s^4>0
\quad\text{for every real }A.}
\tag{7}
\]

Indeed for `theta=w/s<=1`, all three losses in (6), divided by `s^4`, are bounded by
`32 C_poly theta + (443/4) C^2 theta^2`. The two nontrivial choices above bound them by `gamma/20` each.

Equivalently, for any nonzero one-direction compatible field `G0`, put

\[
\delta_k=\frac{\theta_0}{2+\theta_0}.
\]

If `||G-G0||4<=delta_k ||G0||4`, conditional expectation gives `s>=(1-delta_k)||G0||4` and `w<=2delta_k||G0||4`, hence

\[
\Delta_G(A)\ge\frac\gamma{10}(1-\delta_k)^4\|G_0\|_4^4.
\]

The same `delta_k` works for every integer source direction, profile, amplitude, perturbation frequency and affine mean. This does not force a general field into the neighborhood and does not imply the full sharp moment bound.

## Independent review

The construction principal independently checked the polarization factor `1/48`, the orthogonal moment split and cubic cancellation, the separate `H_S/12` and `H_W/2` allocations, the constants `243/4` and `443/4`, and the conversion from `theta0` to `delta_k`. Its correction to use a primitive source vector is incorporated above.
