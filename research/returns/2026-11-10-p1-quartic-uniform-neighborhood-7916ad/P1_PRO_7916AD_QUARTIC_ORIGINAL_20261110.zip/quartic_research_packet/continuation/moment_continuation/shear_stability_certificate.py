#!/usr/bin/env python3
"""Exact all-affine-mean stability certificate along one Fourier perturbation.

Input: {"k":"...", "base_modes":[...], "perturbation_modes":[...]}.
The base must be a nonzero E12 shear (first component depending only on y).
The perturbed potential is base + epsilon * perturbation. A rational epsilon0
is returned for which the original inequality holds for EVERY affine mean
and every real |epsilon|<=epsilon0. This is a restricted directional theorem,
not a resolution of full quasiconvexity.

The script uses only finite rational arithmetic, with the exact Fourier
verifier already supplied in ../variational. No numerical optimization occurs.
"""
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path
import json
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'variational'))
from exact_mean_gap import gap, det


def field(data, epsilon):
    modes = [dict(z) for z in data['base_modes']]
    for mode in data['perturbation_modes']:
        new = dict(mode)
        for key in ('alpha', 'beta'):
            new[key] = [str(epsilon*Q(x)) for x in mode.get(key,[0,0])]
        modes.append(new)
    return {'k': data['k'], 'modes': modes}


def moment_matrix(data):
    zero=[Q(0)]*4
    c=gap(data,zero)
    b=[]
    H=[[Q(0)]*4 for _ in range(4)]
    positive=[]
    for i in range(4):
        e=zero.copy();e[i]=Q(1);p=gap(data,e)
        e[i]=Q(-1);m=gap(data,e)
        b.append((p-m)/2)
        H[i][i]=p+m-2*c
        positive.append(p)
    for i,j in combinations(range(4),2):
        e=zero.copy();e[i]=e[j]=Q(1)
        H[i][j]=H[j][i]=gap(data,e)-positive[i]-positive[j]+c
    return [[2*c]+b]+[[b[i]]+H[i] for i in range(4)]


# Columns: constant coordinate, E12, E21, diag(1,-1), I.
T=[[Q(x) for x in row] for row in
   [[1,0,0,0,0],[0,0,0,1,1],[0,1,0,0,0],
    [0,0,1,0,0],[0,0,0,-1,1]]]


def leading_minors(M):
    C=[[sum(T[a][i]*M[a][b]*T[b][j]
             for a in range(5) for b in range(5))
        for j in range(5)] for i in range(5)]
    return [det([row[:r] for row in C[:r]]) for r in range(1,6)]


def interpolate(values):
    """Exact Newton interpolation at integer nodes 0,...,len(values)-1."""
    differences=list(values)
    out=[Q(0)]*len(values)
    falling=[Q(1)]
    factorial=1
    for degree in range(len(values)):
        if degree:
            factorial*=degree
        weight=differences[0]/factorial
        for i,x in enumerate(falling):
            out[i]+=weight*x
        differences=[differences[i+1]-differences[i]
                     for i in range(len(differences)-1)]
        next_falling=[Q(0)]*(len(falling)+1)
        for i,x in enumerate(falling):
            next_falling[i]-=degree*x
            next_falling[i+1]+=x
        falling=next_falling
    while len(out)>1 and out[-1]==0:
        out.pop()
    return out


def certificate(data):
    k=Q(data['k'])
    if k<=Q(1,3):
        raise ValueError('k must exceed 1/3')
    for mode in data['base_modes']:
        if mode['q'][0]!=0:
            raise ValueError('Base field must have source axis e2')
        if any(Q(mode.get(key,[0,0])[1]) for key in ('alpha','beta')):
            raise ValueError('Base field must have output direction e1')
    if moment_matrix(field(data,Q(0)))[0][0]<=0:
        raise ValueError('The base shear must be nonzero after cancellations')

    # Every principal determinant has degree <=12 in epsilon. Thirteen
    # evaluations suffice to recover them exactly; there is no fitting error.
    samples=[leading_minors(moment_matrix(field(data,Q(t)))) for t in range(13)]
    polys=[interpolate([row[j] for row in samples]) for j in range(5)]
    if not all(p[0]>0 for p in polys[:4]):
        raise ArithmeticError('The regular base block is not positive definite')
    last=polys[4]
    if len(last)<3 or last[0]!=0 or last[1]!=0 or last[2]<=0:
        raise ValueError('No quadratic positive lifting detected; this routine does not certify this direction')
    reduced=polys[:4]+[last[2:]]
    eps=Q(1,2)
    for p in reduced:
        tail=sum(abs(x) for x in p[1:])
        if tail:
            eps=min(eps,p[0]/(2*tail))
    return {
        'k':str(k), 'epsilon0':str(eps),
        'holds_for':'Every real |epsilon| <= epsilon0 and every real affine mean A',
        'method':'Exact polynomial leading-principal-minor bounds after rational congruence',
        'full_quasiconvexity_resolved':False,
        'evaluated_epsilon_nodes':list(range(13)),
        'leading_minor_coefficients':[[str(x) for x in p] for p in polys],
        'determinant_divided_by_epsilon_squared_constant':str(last[2])
    }


if __name__=='__main__':
    with open(sys.argv[1]) if len(sys.argv)>1 else sys.stdin as stream:
        data=json.load(stream)
    print(json.dumps(certificate(data),indent=2))
