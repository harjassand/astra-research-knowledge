# Critical cubic estimate and finite-band stability

This is research progress on the original density. Neither result below proves its full global quasiconvexity.

Let

\[
J_k(F)=\frac{\ell}{8n}(k|F_{\cdot1}|^2-|F_{\cdot2}|^2+2\det F)^2
+\frac\ell4|F_{\cdot1}|^2|F_{\cdot2}|^2+(\det F)^2,
\quad \ell=3k-1,\ n=k+1,\ m=3k+1.
\]

All fields below are mean-zero periodic compatible gradients. The only computational algebra used in the first result is direct polynomial expansion; `sympy.factor` checked both displayed identities exactly, returning zero and the stated determinant term.

## 1. Uniform critical cubic estimate

Write

\[
V=D\varphi=\begin{pmatrix}a&b\\c&d\end{pmatrix},\qquad
s=\frac m2a+d,\quad \eta=\frac{\ell n}{4}>0,
\quad q_I(V)=\int(s^2+\eta c^2).
\]

Exact expansion gives

\[
\tfrac12D^2J_k(I)[V,V]
=s^2+\eta c^2+\frac{3n}{2}\det V,
\]

so that the integrated quadratic coefficient is exactly `q_I`, since the gradient determinant has zero integral. A second exact identity is

\[
DJ_k(V):I=-\eta a(a^2+c^2)
+s\left[-\frac{3n}{2}a^2+2as+\frac\ell2c^2-2bc\right].
\tag{1}
\]

**Claim.** For each fixed `k>1/3` there is a finite constant `C_k`, independent of the Fourier support, profile and amplitudes, such that

\[
\left|\int DJ_k(V):I\right|
\le C_k\|V\|_4^2\sqrt{q_I(V)}.
\tag{2}
\]

The other critical acoustic orbit has a direct proof on the original torus, given below. No source-lattice transformation is needed.

### Scalar interpolation lemma

There is a universal finite constant `C_*` such that every periodic scalar `f` with gradient in `L4` obeys

\[
\|\partial_1f\|_{8/3}^2
\le C_*\|\nabla f\|_4\|R_1\partial_1f\|_2.
\tag{3}
\]

Here the periodic Riesz transforms have multipliers `i xi_j/|xi|`, with their zero mode set to zero.

For a trigonometric polynomial, put `h=|D|f`, remove its `xi_1=0` modes, and put `T=|R_1|`. The analytic family `T^(2z)h`, `0<=Re z<=1`, has boundary norms

\[
\|T^{2it}h\|_4\le C(1+|t|)^r\|h\|_4,
\qquad
\|T^{2+2it}h\|_2\le\|T^2h\|_2.
\]

Indeed `T^(2it)=|D_1|^(2it)|D|^(-2it)` on these modes. The one-dimensional and two-dimensional Mikhlin multiplier estimates bound these two imaginary powers polynomially in `|t|`; the second boundary norm uses only the absolute value one of the imaginary-power multiplier. Multiplication by `exp((z-1/2)^2)` absorbs the polynomial boundary growth. The three-lines interpolation argument between `L4` and `L2`, at `Re z=1/2`, gives

\[
\|Th\|_{8/3}^2\le C\|h\|_4\|T^2h\|_2.
\]

The one-dimensional Hilbert transform turns `Th` into `partial_1 f`; the Riesz transforms give
`||h||4 <= C ||grad f||4`; and `||T^2h||2=||R_1 partial_1f||2`. This proves (3). Fejer approximation and strong `L4` gradient convergence extend it to the stated class. This argument uses classical multiplier and complex-interpolation theorems, rather than an optimization or PDE oracle, and gives a finite universal constant. No sharp constant is claimed.

Hölder then yields

\[
\int|\partial_1 f|^3
\le\|\partial_1f\|_{8/3}^2\|\partial_1f\|_4
\le C_*\|\nabla f\|_4^2\|R_1\partial_1f\|_2.
\tag{4}
\]

### Acoustic completion of the square

For each nonzero Fourier frequency `(p,q)`, fixing the first row and minimizing the expression `|s|^2+eta |c|^2` over the second-row potential gives

\[
|s|^2+\eta|c|^2
\ge\frac{m^2\eta}{4}\frac{p^2}{q^2+\eta p^2}|a|^2.
\]

Consequently

\[
q_I(V)\ge
\frac{m^2\eta}{4\max(1,\eta)}\|R_1a\|_2^2.
\tag{5}
\]

Equations (4)-(5) control the only term in (1) with no explicit factor `s` or `c`. All other terms follow directly from Hölder, using
`||s||2 <= sqrt(q_I)` and `||c||2 <= sqrt(q_I/eta)`.

For example, a permissible constant is

\[
C_k=
\frac{2C_*\sqrt{\eta\max(1,\eta)}}m
+\sqrt\eta+\frac{3n}{2}
+2\sqrt{m^2/4+1}+\frac\ell2+2.
\]

Its exact numerical value is not needed for (2). The dependence at the parameter endpoints is not uniform.

### Direct critical estimate at B_k on the original torus

Put `B_k=[[0,k],[1,0]]` and `s_B=(m/2)b+k c`. Exact polynomial expansion gives

\[
\tfrac12D^2J_k(B_k)[V,V]
=s_B^2+\eta d^2-\frac{3kn}{2}\det V,
\]

\[
DJ_k(V):B_k=-\frac\eta k b(b^2+d^2)
+s_B\left[-\frac{3n}{2k}b^2+\frac2kbs_B+\frac\ell{2k}d^2-2ad\right].
\]

Both identities were independently verified by exact symbolic expansion. Thus `q_B=H_V[B_k,B_k]/2=integral(s_B^2+eta d^2)`. Completing the Fourier square at an original torus frequency `(p,q)` gives

\[
q_B(V)\ge\frac{m^2\eta}{4\max(k^2,\eta)}\|R_2b\|_2^2.
\]

Apply (3)-(4) with the source coordinates interchanged to control the cubic `b^3`; all other terms contain an explicit `s_B` or `d`. Therefore

\[
\left|\int DJ_k(V):B_k\right|\le C'_k\|V\|_4^2\sqrt{q_B(V)}
\]

for a finite constant depending only on `k`, uniformly over frequencies and profiles. Fixed left rotations preserve the original density and compatibility, so these two critical estimates cover both complete acoustic zero orbits.

### Application and limitation

For `G0=g(y) E12`, direct polarization of (1) gives

\[
\int DJ_k(G_0+\varepsilon V):I
=-2\varepsilon^2\int gcs
+\varepsilon^3\int DJ_k(V):I.
\]

Thus

\[
\left|\int DJ_k(G_0+\varepsilon V):I\right|
\le\left[\frac2{\sqrt\eta}|\varepsilon|^2\|g\|_4\|V\|_4
+C_k|\varepsilon|^3\|V\|_4^2\right]\sqrt{q_I(V)}.
\tag{6}
\]

This is independent of the frequency support and of `||g||2`. However, the Schur complement of the full mean Hessian need not be comparable to `epsilon^2 q_I(V)`. It may have much smaller eigenvalues along changing near-rank-one directions. Equation (6) alone therefore does not establish a uniform neighborhood in the full all-mean problem.

## 2. Explicit finite-band all-mean stability around any one-axis field

This result is uniform over the shape, output directions and concentration of the one-axis profile, but its radius deteriorates with the cutoff.

Let `N>=1` be an integer and suppose all Fourier modes of `G=Dphi` satisfy `max(|q1|,|q2|)<=N`. Let `G0=Y0(y) tensor e2` be any nonzero mean-zero compatible one-axis field with the same cutoff. Set

\[
R=\|G_0\|_4,\qquad \varepsilon=\|G-G_0\|_4,
\qquad \alpha=\frac\ell{8n}.
\]

Let `C=C_k^poly` be the sum of the absolute monomial coefficients of the quartic polynomial `J_k` in its four entries, and let

\[
\mu=\frac{9\ell^4}{256(48C)^3N^4},
\]

\[
\delta_{k,N}=\min\left\{
\frac1{10},\frac\alpha{820C},
\frac{\alpha\mu}{64000C^2}
\right\}.
\tag{7}
\]

Then

\[
\varepsilon\le\delta_{k,N}R
\quad\Longrightarrow\quad
\int J_k(A+G)-J_k(A)\ge\frac\alpha{10}R^4>0
\quad\text{for every real }A.
\tag{8}
\]

For rational `k`, every constant in (7) is explicitly rational. For arbitrary fixed real `k`, the formula is an ordinary positive analytic expression, not a computational oracle.

### Rank-one acoustic bound

Write `J_k(F)=T(F,F,F,F)` with its symmetric four-linear polarization. Then
`|T(F1,F2,F3,F4)| <= C product |Fi|`.
For `B=a tensor xi`, `|a|=|xi|=1`, exact algebra gives

\[
\det D^2J_k(B)=\frac9{16}\ell^4\xi_1^4\xi_2^4.
\]

This matrix is positive semidefinite by quartic polarization and Legendre-Hadamard. Its trace is at most `48C`. A nonaxis integer frequency in the stated cutoff has
`xi1^2 xi2^2 >= 1/(4N^2)`, whence

\[
D^2J_k(B)\ge\mu I.
\]

If `W` has only frequencies with both coordinates nonzero, Parseval therefore gives

\[
H_W[A,A]=\int D^2J_k(A)[W,W]
\ge\mu\|W\|_2^2|A|^2.
\tag{9}
\]

### Axis decomposition

Set `X=E_y G`, `Y=E_x G`, `S=X+Y`, and `W=G-S`.
Compatibility makes `X=X1(x) tensor e1` and `Y=Y2(y) tensor e2`; `W` has only nonaxis modes. Conditional expectation and the zero means give

\[
\|X\|_4\le\varepsilon,\quad
\|Y-G_0\|_4\le\varepsilon,\quad
R-\varepsilon\le\|Y\|_4\le R+\varepsilon,
\quad\|S\|_4\le R+2\varepsilon,\quad
\|W\|_4\le3\varepsilon.
\]

Fourier orthogonality gives `H_G=H_S+H_W` exactly. Sequential rank-one convexity with its quartic increment reserve gives

\[
\Delta_S(A)\ge\frac\alpha3
\left(k^2\|X\|_4^4+\|Y\|_4^4\right)
\ge\frac\alpha3(R-\varepsilon)^4.
\tag{10}
\]

### Cubic and quartic errors

The cubic moment difference obeys

\[
|(b_G-b_S):A|\le L\sqrt{H_W[A,A]},
\]

where

\[
L=\frac C{\sqrt\mu}
\left[
24\|X\|_2\|Y\|_2
+12\|S\|_4\|W\|_4
+4\|W\|_4^2
\right].
\tag{11}
\]

For its first term, the pure `X^2 W` and `Y^2 W` integrals vanish by Fourier support. The remaining `XYW` integral uses independence of `x,y`, giving `|| |X||Y| ||2=||X||2||Y||2`. The other terms use ordinary Hölder with exponents `(4,4,2)`, followed by (9). No finite-mode Bernstein estimate is needed.

Young's inequality spends the full `H_W/2` and leaves `-L^2/2`. The quartic constant changes by at most

\[
|c_G-c_S|\le12C(R+5\varepsilon)^3\varepsilon.
\tag{12}
\]

If `epsilon<=R/10`, (10) is at least `alpha R^4/5`, (12) is at most `41 C R^3 epsilon`, and (11) gives

\[
\tfrac12L^2\le\frac{3200C^2}{\mu}R^2\varepsilon^2.
\]

The second choice in (7) bounds (12) by `alpha R^4/20`. The third choice, together with `delta<=1`, bounds the last display by `alpha R^4/20`. This proves (8).

The source-e1 counterpart has the corresponding rank-one reserve `alpha k^2`; alternatively replace `alpha` by `alpha min(1,k^2)` for a common two-axis statement.

## Scope

The frequency-free estimate (2) is a quantitative fact at a critical affine background. The all-mean theorem (8) is a uniform, explicit finite-band neighborhood of a one-axis class. Neither supplies the requested sharp global bound `b^T H^dagger b<=2c` for every compatible gradient. In particular, the radius in (7) decreases as the cutoff grows, so it cannot be passed unchanged to arbitrary `W^(1,4)` fields.

A subsequent stronger result now removes that frequency cutoff: the critical estimates here and the construction principal's all-background acoustic comparison prove the uniform cubic estimate used in `uniform_neighborhood_from_cubic.md`. That file proves a positive relative `L4` neighborhood of every one-direction compatible field, with a radius depending only on `k`, uniformly in concentration, source direction, frequency and mean. It remains a neighborhood theorem rather than the full endpoint.
