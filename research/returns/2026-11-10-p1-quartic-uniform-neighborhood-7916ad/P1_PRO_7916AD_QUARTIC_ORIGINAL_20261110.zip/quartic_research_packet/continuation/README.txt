CONTINUATION PROOF AND COMPUTATION FILES
======================================

Start with ../CONTINUATION_RESULTS.txt. The full original quasiconvexity question
has not been resolved. The original density is used in every certificate.

The main analytic proof chain is:
  moment_continuation/critical_cubic_and_band_stability.md
  construction_continuation/acoustic/UNIFORM_ACOUSTIC_NORMAL_FORM.md
  moment_continuation/uniform_neighborhood_from_cubic.md

It proves a nonsharp compatible cubic bound and a uniform relative L4 neighborhood
of every one-direction field. Standard periodic multiplier and interpolation
theorems are used explicitly. The final constant is finite but is not a sharp
constant or an efficient numerical certificate for arbitrary inputs.

The independent exact Hessian identity is in:
  projection_continuation/four_square_factorization_and_weighted_interaction.md
Its final section records the interaction left over by a proposed sharp induction.

Checks actually completed in this continuation:

1. verify_normal_form.py: exact original-density acoustic symbol, determinant
   normal form, and critical B_k cubic identity; all residuals are zero.
2. verify_four_square_factorization.py: four-square identity, strain at I,
   fixed-axis multiplier estimate, and both column identities; all pass.
   The principal agent also independently expanded the four-square identity
   after clearing denominators as a zero polynomial in nine real variables.
3. exact_fe_gap.py: exact compatible positive witness and exact obstruction to
   the stronger global c_G/3 reserve. The latter has positive original gap.
4. certify_saved_fe.py: all 44 saved decimal-rational P1 realizations have
   strictly positive original gaps. 25,264 triangles; 2.656 seconds; largest
   rational input denominator has 103 bits. Detailed exact results and source
   hashes are in construction_continuation/saved_fe_exact_signs.json.
5. exact_shear_search.py: 288 exact area-preserving four-shear compositions;
   10,347 final polygons; at most 148 for one map; 6.42 seconds. All rational
   endpoint values are positive and therefore these particular fields have
   positive gaps for every k>1/3. This is not an exhaustive search.

To reproduce the core exact checks from this directory:

  python construction_continuation/acoustic/verify_normal_form.py
  python projection_continuation/verify_four_square_factorization.py
  python construction_continuation/exact_fe_gap.py construction_continuation/exact_below_one_third_reserve.json
  python construction_continuation/certify_saved_fe.py

The symbolic scripts use the already available SymPy package. Rational FE and
polygon verifiers use only the Python standard library. Exploratory FE search
scripts use the already available NumPy and SciPy packages. No installation or
remote computation was performed. The small variational/ directory supplies
the previously generated code/data dependencies of the retained exploration
scripts; it contains no held external source.

The 44 floating optimization runs were discovery procedures, with finite caps
and recorded final fields. They are not optimality certificates. Their final
energy signs have been replaced by exact rational checks of the saved decimal
realizations. The optimization evaluation counts were not separately logged;
reported iteration counts and configured caps are documented in the construction
note. No mathematical assertion depends on floating sign or solver success.

The earlier directional-certificate and finite-band files are retained for
reproducibility, but the new neighborhood theorem is proved analytically and
does not depend on running an unbounded search or the directional script.

No extra source, access, transfer, model, account, installation, or hardware grant
is inferred. Existing holds remain in force; protected researchers were not
contacted and native Astra retrieval was not attempted.
