"""Exact-rational partial predictor for diagnostic case B.

The proved cost is quasipolynomial in inverse accuracy in two dimensions.
This is NOT the requested all-ratio polynomial-accuracy solver.
See REPORT.md for input promises, constants, proof, and source credits.

Run: python predictor.py instance.json
All rational numbers in JSON should be integers or strings such as "1/10".
Paulis are length-n lists with labels 0=I, 1=X, 2=Y, 3=Z.
Initial states use rational Bloch vectors [x,y,z], equivalent to the supplied
rational two-by-two density matrices. The operator norm bound on O is a promise.
"""
from fractions import Fraction as F
from collections import defaultdict
from pathlib import Path
import json
import sys

# Valid rational inputs and outputs may have more than Python's default decimal
# digit limit. Their actual bit lengths are charged by the proved cost bound.
if hasattr(sys, "set_int_max_str_digits"):
    sys.set_int_max_str_digits(0)


def ceil_fraction(x):
    x = F(x)
    return -((-x.numerator) // x.denominator)


def ceil_log2(x):
    """Exact ceil(log2(x)) for rational x >= 1."""
    x = F(x)
    if x < 1:
        raise ValueError("ceil_log2 requires x >= 1")
    e = max(0, x.numerator.bit_length() - x.denominator.bit_length())
    if x.numerator > (x.denominator << e):
        e += 1
    while e > 0 and x.numerator <= (x.denominator << (e - 1)):
        e -= 1
    return e


# Multiplication phase in powers of i, and the resulting Hermitian Pauli.
_MUL = {
    (0, 0): (0, 0), (0, 1): (0, 1), (0, 2): (0, 2), (0, 3): (0, 3),
    (1, 0): (0, 1), (2, 0): (0, 2), (3, 0): (0, 3),
    (1, 1): (0, 0), (2, 2): (0, 0), (3, 3): (0, 0),
    (1, 2): (1, 3), (2, 3): (1, 1), (3, 1): (1, 2),
    (2, 1): (3, 3), (3, 2): (3, 1), (1, 3): (3, 2),
}


def multiply_pauli(p, q):
    phase = 0
    out = []
    for a, b in zip(p, q):
        e, c = _MUL[a, b]
        phase = (phase + e) % 4
        out.append(c)
    return phase, tuple(out)


def apply_generator(vector, terms, gamma):
    """Heisenberg G(P)=i[H,P]-gamma*weight(P)*P."""
    out = defaultdict(F)
    for p, c in vector.items():
        weight = sum(x != 0 for x in p)
        if weight:
            out[p] -= gamma * weight * c
        for h, hpauli in terms:
            phase, q = multiply_pauli(hpauli, p)
            if phase == 1:
                out[q] -= 2 * h * c
            elif phase == 3:
                out[q] += 2 * h * c
    return {p: c for p, c in out.items() if c}


def expectation(vector, bloch):
    ans = F(0)
    for p, c in vector.items():
        value = c
        for axis, r in zip(p, bloch):
            if axis:
                value *= r[axis - 1]
        ans += value
    return ans


def exact_taylor(terms, observable, bloch, gamma, T, J, d, epsilon):
    """No Pauli truncation; the vector may grow to all 4**m Pauli words."""
    m = len(bloch)
    X = m * (2 * d * J + gamma) * T
    q = ceil_fraction(8 * X) + 8 * (m + ceil_log2(16 / epsilon) + 1)
    total = defaultdict(F, observable)
    term = dict(observable)
    for j in range(1, q + 1):
        term = apply_generator(term, terms, gamma)
        factor = T / j
        term = {p: c * factor for p, c in term.items() if c}
        for p, c in term.items():
            total[p] += c
        if not term:
            break
    return expectation(total, bloch), q, len(total)


def distance(x, y, periods=None):
    if periods is None:
        return max(abs(a - b) for a, b in zip(x, y))
    ds = []
    for a, b, period in zip(x, y, periods):
        z = abs(a - b) % period
        ds.append(min(z, period - z))
    return max(ds)


def parse_terms(raw, n):
    out = []
    for t in raw:
        p = tuple(t["pauli"])
        if len(p) != n or any(x not in (0, 1, 2, 3) for x in p):
            raise ValueError("invalid explicitly encoded Pauli")
        c = F(t["coeff"])
        if c:
            out.append((c, p))
    return out


def predict(data):
    coords = [tuple(x) for x in data["coordinates"]]
    n = len(coords)
    if n < 1 or any(len(x) != 2 for x in coords):
        raise ValueError("explicit two-dimensional coordinates required")
    if len(set(coords)) != n:
        raise ValueError("duplicate site")
    periods = data.get("periods")
    if periods is not None:
        if len(periods) != 2 or any(x <= 0 for x in periods):
            raise ValueError("invalid periodic lattice")
        coords = [tuple(c % L for c, L in zip(x, periods)) for x in coords]
        if len(set(coords)) != n:
            raise ValueError("duplicate periodic site")
    gamma, J, T, epsilon = (
        F(data[key]) for key in ("gamma", "J", "T", "epsilon")
    )
    if gamma <= 0 or J <= 0 or T < 0 or not (0 < epsilon < 1):
        raise ValueError("require gamma,J>0; T>=0; 0<epsilon<1")
    if "delta" in data and not (0 < F(data["delta"]) < 1):
        raise ValueError("invalid delta")
    bloch = [tuple(F(z) for z in r) for r in data["bloch"]]
    if len(bloch) != n or any(len(r) != 3 for r in bloch):
        raise ValueError("one explicit Bloch vector per qubit required")
    if any(sum(z*z for z in r) > 1 for r in bloch):
        raise ValueError("nonpositive input density matrix")
    all_terms = parse_terms(data["hamiltonian"], n)
    terms = [(h, p) for h, p in all_terms if any(p)]
    if any(abs(h) > J for h, p in terms):
        raise ValueError("coefficient exceeds J")
    obs = defaultdict(F)
    for c, p in parse_terms(data["observable"], n):
        obs[p] += c
    obs = {p: c for p, c in obs.items() if c}
    # ||O||_infinity <= 1 is a fixed-support input promise, not an HS shortcut.
    Y = {i for p in obs for i, x in enumerate(p) if x}
    finf = obs.get((0,) * n, F(0))
    if not Y:
        return {"estimate": str(finf), "error_bound": "0",
                "failure_probability": "0", "branch": "scalar",
                "retained_qubits": 0}
    if T == 0:
        return {"estimate": str(expectation(obs, bloch)), "error_bound": "0",
                "failure_probability": "0", "branch": "initial",
                "retained_qubits": len(Y)}
    supports = [{i for i, x in enumerate(p) if x} for h, p in terms]
    degree = [sum(i in S for S in supports) for i in range(n)]
    d = max(degree, default=0)
    k = max([len(S) for S in supports] + [1])
    a = 1
    for S in supports:
        for i in S:
            for j in S:
                a = max(a, distance(coords[i], coords[j], periods))
    w = len(Y)
    z = k * (d + 1)
    b = 2 * (d * J + gamma)
    v = 3 * z * b
    M = 32 * w * (d + 1) * (a + 1) ** 2
    A = 4 * M
    LA = ceil_log2(A)
    K = (1 + 2 * w * (4 * a * LA + 12 * a + 1)
         + 4 * a * w * (2 * v / gamma + 1))
    Lstar = ceil_log2(8 * K / epsilon)
    Tstar = 4 * F(Lstar) / gamma
    base = {
        "failure_probability": "0", "input_qubits": n,
        "geometry": {"a": a, "k": k, "d": d, "w": w},
        "v_bound": str(v), "K_bound": str(K), "horizon": str(Tstar),
        "warning": "quasipolynomial accuracy cost; full case B unresolved",
    }
    if T >= Tstar:
        return dict(base, estimate=str(finf), error_bound=str(epsilon / 2),
                    branch="equilibrium", retained_qubits=0)
    D = 4 + ceil_fraction(2 * v * T) + 2 * ceil_log2(4 * A / epsilon)
    V = {i for i in range(n)
         if min(distance(coords[i], coords[y], periods) for y in Y) < a * D}
    W = set(V)
    for S in supports:
        if S & V:
            W.update(S)
    indices = sorted(W)
    restricted_terms = []
    for (h, p), S in zip(terms, supports):
        if S <= W:
            restricted_terms.append((h, tuple(p[i] for i in indices)))
    restricted_obs = {
        tuple(p[i] for i in indices): c for p, c in obs.items()
    }
    restricted_bloch = [bloch[i] for i in indices]
    estimate, q, stored = exact_taylor(
        restricted_terms, restricted_obs, restricted_bloch,
        gamma, T, J, d, epsilon
    )
    return dict(base, estimate=str(estimate), error_bound=str(epsilon),
                branch="finite_volume_taylor", retained_qubits=len(indices),
                radius_index=D, taylor_degree=q, stored_paulis=stored,
                full_pauli_capacity=str(4 ** len(indices)))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python predictor.py instance.json")
    result = predict(json.loads(Path(sys.argv[1]).read_text()))
    print(json.dumps(result, indent=2))

