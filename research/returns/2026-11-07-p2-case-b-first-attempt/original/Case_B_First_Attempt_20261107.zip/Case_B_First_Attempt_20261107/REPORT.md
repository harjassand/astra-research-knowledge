# Case B: first frontier attempt — uniform local prediction under continuous depolarization

7 November 2026, Australia/Brisbane. First of the two allowed scientific turns for this role/case.

## Status

The full case-B proposition is NOT resolved by this return. No uniform polynomial-in-inverse-accuracy algorithm for every positive fixed noise ratio, and no model-preserving computational-hardness reduction, has been obtained.

This return constructs a deterministic worst-case predictor for the actual specified-input model, with a quasipolynomial accuracy cost. It proves a size-independent local prediction horizon, gives explicit conservative constants and an exact-rational finite computation, and identifies a valid hypercontractive time-splitting norm bridge whose remaining scalar evaluations are not supplied for free. It also records precisely why direct import of a newly retrieved discrete noisy-circuit theorem does not settle the continuous model.

These are partial results toward the frozen full endpoint, not a replacement endpoint or a claim of new historical priority. The principal upper bound is a constructive combination of established entropy-production and locality machinery. All accepted predecessors remain at their stated scopes.

## 1. Actual model, input and conventions

There are n explicitly listed qubits at distinct sites of a finite square lattice. Periodic boundary conditions can be handled using the corresponding graph metric. The supplied Hamiltonian is

\[
 H=\sum_{\alpha} h_\alpha P_\alpha,\qquad |h_\alpha|\le J.
\]

Each Pauli term has at most k nonidentity factors, support diameter at most a in the lattice infinity metric, and each site belongs to at most d listed nonidentity terms. Take integer a>=1. The quantities a,k,d and the observable support bound w are fixed class parameters; their costs are not hidden if allowed to grow.

The dynamics is exactly

\[
 \mathcal L(\rho)=-i[H,\rho]+\gamma\sum_i(E_i\rho-\rho),
 \qquad E_i\rho=(I_i/2)\otimes\operatorname{Tr}_i\rho.
\]

The microscopic coefficients, gamma>0, time T>=0, product initial density matrices, and fixed-support observable are supplied by finite rational data, or by the stated effective representation with its precision cost counted. The executable uses rational Pauli coefficients and rational local Bloch vectors, equivalent to rational local density matrices. The request is additive epsilon in (0,1), with confidence parameter delta. The construction below is deterministic and so has failure probability zero.

Let B denote the COMPLETE binary input length. There is no physical measurement, extra preparation, resetting operation, changed instrument, ensemble average, or instance-dependent advice. The observable is Hermitian, has operator norm at most one, and is supported on a nonempty set Y with |Y|<=w. A scalar observable can be returned directly.

The units are those in the input. Put r=gamma/J when J>0. The replacement-depolarizing rate convention is

\[
 \gamma(E_i-\mathrm{id})
 =\frac{\gamma}{4}\sum_{\alpha=X,Y,Z}\mathcal D[\sigma^\alpha_i].
\]

Consequently a Pauli word P is damped at rate gamma times its weight, not four times that rate. Time and all rates appear as their actual products. The case H=0 is elementary.

## 2. Frozen sources and the launch decision

The supplied packet already records that the current applicable predecessors do not resolve B. This attempt additionally read the pinned P2 REPORT.md, SOURCE_SCOPE.json and ENDPOINT.json at commit 7f09361dbd8359c2c0bdd352a222fcceffe8c776; the canonical report agrees with the local accepted original. It is a complete-mediation result for two-body Hamiltonians and noise linear in one-site Paulis. It gives a constructive classical section and a nonmediation witness, not numerical hardness outside that section.

Angrisani–Puig–Teng–Holmes, arXiv:2609.40174v2, was read at its target assumptions, Theorem 2 and S10, including Theorem S54 and Corollary S55. Its specified-state extension still averages over Hamiltonians independent of that state. Trivedi–Cirac, arXiv:2110.10638v2, was read at the model and Theorems 1–3: its positive regime is sufficiently strong noise, while its quoted hardness operations do not preserve B's combination of only unital replacement noise, static H, and additive local-observable prediction.

Thus no pretrial retirement as an already solved case is indicated by the frozen packet. This attempt did not retrieve another diagnostic participant's frontier response or a new Astra card containing one.

## 3. Finite-volume entropy contraction

For a system of m qubits let omega_m=I/2^m and

\[
 D(\rho\Vert\omega_m)=m\log 2-S(\rho).
\]

For the same generator on any finite subset, with any retained Hamiltonian,

\[
 D(\rho(t)\Vert\omega_m)\le e^{-\gamma t}D(\rho(0)\Vert\omega_m)
 \le m\log 2\,e^{-\gamma t}.                         \tag{1}
\]

This is a conservative rate; no optimal-rate claim is needed.

Here is the normalization check and derivation. Hamiltonian evolution has zero entropy derivative. Concavity of entropy gives

\[
 \frac{d}{dt}S(\rho(t))
 \ge\gamma\sum_i [S(E_i\rho)-S(\rho)]
 =\gamma\sum_i[\log2+S(\rho_{-i})-S(\rho)].
\]

Quantum Shearer's inequality for the family of all (m-1)-site marginals says

\[
 \sum_i S(\rho_{-i})\ge(m-1)S(\rho).
\]

Therefore the right side is at least gamma D(rho||omega_m), proving (1) by integration. Non-full-rank states follow by regularization. This argument applies to arbitrary initial states, not only product states. The entropy production/Shearer input is credited to Müller-Hermes–França–Wolf, Theorem 6.1 and Lemma 6.1, with the Hamiltonian term contributing zero. Their source also corrects an earlier proof of the needed entropy inequality; this return does not rely on that earlier erroneous proof.

Pinsker's inequality yields

\[
 \|\rho(t)-\omega_m\|_1
 \le \sqrt{2m\log2}\,e^{-\gamma t/2}.                \tag{2}
\]

For any norm-one Hermitian observable A on that system,

\[
 |\operatorname{Tr}[A\rho(t)]-2^{-m}\operatorname{Tr}A|
 \le \sqrt{2m\log2}\,e^{-\gamma t/2}.                \tag{3}
\]

Using (3) with m=n alone would introduce log n into the prediction horizon. Spatial locality removes that dependence for the local task.

## 4. Explicit locality constants

The following conservative choices make the reduction numerical and reviewable:

\[
 z=k(d+1),\quad
 b=2(dJ+\gamma),\quad
 v=3zb=6k(d+1)(dJ+\gamma),
\]
\[
 M=32w(d+1)(a+1)^2,\qquad A=4M.
                                                               \tag{4}
\]

Terms on identical supports may first be grouped. Each grouped local generator has operator-to-operator norm at most b, and its overlap degree is at most z. Thus v exceeds the standard Lieb–Robinson constant e times overlap degree times local generator norm. The shell count around Y in the square lattice is bounded by M times the shell index. The factor w covers a disconnected observable support.

For integer D>=4 let V_D be the union of lattice balls of radius aD around Y, with the strict boundary chosen so the complement is at distance at least aD. Let W_D be its interaction extension: include every support of a generator term meeting V_D. Then

\[
 m_D=|W_D|
 \le \min\{n,\ w[2a(D+1)+1]^2\}.                    \tag{5}
\]

Restrict H and the noise to W_D. The Markovian quasilocality theorem of Barthel–Kliesch gives, with the deliberately loose constants above,

\[
 \|e^{T\mathcal L^\dagger}O-e^{T\mathcal L_{W_D}^\dagger}O\|_\infty
 \le 2MD e^{vT-D}
 \le A e^{vT-D/2}.                                \tag{6}
\]

If W_D is the whole finite lattice the truncation error is zero. The union-of-balls version follows by summing the shell bound over the at most w support sites. Fixed open or periodic boundary conditions only reduce the infinite-lattice volume upper bound.

The important input here is a worst-case operator-norm locality bound, not an averaged Hilbert–Schmidt bound. Equation (6) holds against the particular supplied product state, and indeed against every state.

## 5. A uniform local prediction horizon

Define the integer logarithm

\[
 \ell(x)=\lceil\log_2x\rceil\quad(x\ge1).
\]

It is computable by integer bit lengths and comparisons for rational x, and satisfies ell(x)>=log x, with log the natural logarithm. Set

\[
 L_A=\ell(A),
\]
\[
 K=
 1+2w(4aL_A+12a+1)+4aw(2v/\gamma+1).              \tag{7}
\]

For the proof choose

\[
 D_{\rm mix}(T)=4+\lceil(2v+\gamma)T+2L_A\rceil.
\]

The locality error in (6) is at most exp(-gamma T/2). Equations (3) and (5), applied to W_D, then give, with u=gamma T,

\[
 |f(T)-f_\infty|
 \le K(1+u)e^{-u/2}
 \le 4K e^{-u/4},                                \tag{8}
\]
where

\[
 f(T)=\operatorname{Tr}[Oe^{T\mathcal L}(\rho_0)],
 \qquad f_\infty=2^{-|Y|}\operatorname{Tr}_Y O.
\]

For clarity about constants, D_mix+1 is at most
6+(2v+gamma)T+2L_A. Also sqrt(2w log2)<=2w. Substitution into (3) and (5) gives the affine polynomial bounded by K(1+u). Finally (1+u)e^{-u/4}<=4.

Consequently the rational horizon

\[
 L_*=\ell(8K/\epsilon),\qquad
 T_*=\frac{4L_*}{\gamma}                          \tag{9}
\]
has the property

\[
 T\ge T_*\quad\Longrightarrow\quad
 |f(T)-f_\infty|\le\epsilon/2.                    \tag{10}
\]

There is no n in this horizon. At fixed geometry and ratio r,

\[
 JT_*=O\!\left(r^{-1}\log\frac{C(1+r^{-1})}{\epsilon}\right).
\]

This is a local-observable statement. It does not say the whole n-qubit state is epsilon-close to the maximally mixed state at that time, nor does it prepare or sample a physical state.

## 6. A complete finite predictor, with its actual quasipolynomial cost

The algorithm is as follows.

1. Parse the explicit microscopic input and compute the class bounds and constants (4), (7), (9).
2. If T>=T_*, return the rational number f_infty.
3. Otherwise put
   \[
    D_\epsilon=4+\lceil2vT\rceil+2\ell(4A/\epsilon).
   \]
   Construct W_(D_epsilon) by scanning the explicit terms. The locality error is below epsilon/4.
4. Compute the evolution on the m=|W_(D_epsilon)| retained qubits by the rational Taylor procedure below. Evaluate it on the supplied restricted product state.
5. Return the resulting rational estimate.

There is no uncomputed oracle or lower bound in step 4. In the Pauli basis the finite Heisenberg generator is a real rational matrix G of dimension 4^m. Its diagonal entries are -gamma times Pauli weight. A term hP contributes i h[P,Q], a real multiple of another Hermitian Pauli whenever the commutator is nonzero. Each column has at most dm off-diagonal contributions.

Its normalized Hilbert–Schmidt induced norm obeys

\[
 \|G\|_{2\to2}\le m(2dJ+\gamma).
\]

Set

\[
 X=m(2dJ+\gamma)T,\quad
 b_\epsilon=\ell(16/\epsilon),
\]
\[
 q=\lceil8X\rceil+8(m+b_\epsilon+1).              \tag{11}
\]

Compute exactly over rational numbers

\[
 v_0=O,\qquad v_{j+1}=\frac{T}{j+1}Gv_j,\qquad
 \widehat O=\sum_{j=0}^{q}v_j.                    \tag{12}
\]

The exponential-series remainder is at most
exp(X) X^(q+1)/(q+1)! in normalized Hilbert–Schmidt norm. Since q>=8X, the bound
(q+1)!>=((q+1)/e)^(q+1) and e/8<1/2 show that this is much smaller than
epsilon/(4*2^(m/2)). The worst-case conversion

\[
 |\operatorname{Tr}[\rho_0(\widehat O-e^{TG}O)]|
 \le 2^{m/2}\|\widehat O-e^{TG}O\|_{2,\mathrm{norm}}
\]
therefore costs at most epsilon/4. Product-state Pauli expectations are just products of the supplied one-site Bloch components, computed exactly. Together with spatial truncation this gives error below epsilon. The algorithm is deterministic; delta creates no statistical cost.

For a simple explicit bit-cost bound, take

\[
 W_{\rm bits}=C(q+1)[B+\log_2(q+2)+m+1].
\]

All exact rational intermediates can be bounded at this bit length by clearing input denominators and using a common Taylor denominator. Their magnitudes and factorial denominators are also covered. Schoolbook arithmetic and sparse Pauli action give the conservative bound

\[
 C\,4^m(q+1)[m(d+1)+1]W_{\rm bits}^3              \tag{13}
\]
bit operations, plus input parsing and lattice restriction. Memory is at most a polynomial bit factor times 4^m. Keeping a dense Pauli vector or a dictionary that can grow to 4^m are both valid implementations; no sparsity promise is used.

Because the nontrivial branch has T<T_*, equations (5) and (9) imply

\[
 m\le
 C_{\rm geom}(1+r^{-1})^2
 \log^2\!\left(\frac{C_{\rm geom}(1+r^{-1})}{\epsilon}\right).
                                                               \tag{14}
\]

Moreover X is polynomial in m, log(1/epsilon), and 1+r^(-1). Thus

\[
 \mathrm{Work}\le
 \mathrm{poly}(B,n)
 \exp\!\left[
 C_{\rm geom}(1+r^{-1})^2
 \log^2\!\left(\frac{C_{\rm geom}(1+r^{-1})}{\epsilon}\right)
 \right],                                                     \tag{15}
\]
after enlarging the displayed constant to absorb polynomial factors.

This is uniform over the specified H and product input. It pays all coefficient and arithmetic lengths and requires no physical queries. Even if J or gamma has a large numerical value encoded in few bits, the algorithm compares their rational products with T and either returns the equilibrium value or works only in the bounded dimensionless-time branch.

Equation (15) is QUASIPOLYNOMIAL in inverse epsilon at fixed ratio. It is not the polynomial accuracy bound demanded by B.

## 7. Consequences that are actually earned

For every fixed ratio r>0 and every fixed additive accuracy epsilon_0>0, the local prediction task is in deterministic polynomial time in the complete explicit input. The constants can be enormous as r decreases; equations (4)–(13) expose them.

For epsilon=n^(-c) with fixed c, the result is quasipolynomial, not polynomial, in n. The unresolved difficulty can therefore be confined to a region of O_r(log^2 n) qubits and a time of O_gamma(log n), with a specified product initial state.

A constant-additive-gap BQP-hardness reduction to exactly B, at fixed noise ratio and fixed locality parameters and using a deterministic polynomial-time reduction, would by composition with the fixed-accuracy algorithm imply BQP=P. With a bounded-error randomized polynomial-time reduction the corresponding conclusion would instead be BQP=BPP. Thus a proposed ordinary constant-gap reduction cannot simply import a fault-tolerance construction that depends on cooling, resets, programmable time dependence or a global sampling contract.

This does not prove the absence of other computational obstructions at shrinking accuracy. Nor does it prove that the reduced logarithmic-size-window problem is hard. In one spatial dimension the same locality-volume argument would have a linear logarithm in (14), and hence a polynomial accuracy bound; that observation is not a resolution of the square-lattice endpoint.

## 8. A valid time-splitting norm bridge, and its unpaid operation

There is a useful deterministic norm bridge that does not average over inputs or Hamiltonians. On m qubits write normalized Schatten norms as ||.||_(p,n). Depolarizing hypercontractivity, unitary invariance of Schatten norms, and Trotter composition imply for the full physical semigroup

\[
 \|e^{s\mathcal L}(X)\|_{2,n}
 \le \|X\|_{1+e^{-2\gamma s},n}.                 \tag{16}
\]

The Hamiltonian does not need to commute with the noise. Each unitary factor preserves the current Schatten norm; each noise factor advances its hypercontractive exponent. Passing to the finite-dimensional Trotter limit proves (16). The primary hypercontractivity credit is King's unital-qubit theorem.

Apply (16) to R_0=2^m rho_0. For every density operator, including the supplied product state,

\[
 \|R_s\|_{2,n}
 \le 2^{m/(1+e^{2\gamma s})},
 \qquad R_s=2^m e^{s\mathcal L}(\rho_0).           \tag{17}
\]

Therefore a middle-interval observable error Delta gives

\[
 |\operatorname{Tr}[e^{s\mathcal L}(\rho_0)\Delta]|
 \le 2^{m/(1+e^{2\gamma s})}\|\Delta\|_{2,n}.      \tag{18}
\]

For s>=log(m)/(2gamma), the prefactor is at most 2. This uses an actual prefix of the supplied evolution; it does not insert an extra physical operation.

However, if a sparse middle-interval approximation is
A=sum_j c_j P_j, its predicted value still needs

\[
 \sum_j c_j\,\operatorname{Tr}[P_j e^{s\mathcal L}(\rho_0)].
                                                               \tag{19}
\]

Those prefix moments are not given by the microscopic input without computation. The Pauli words can have support growing logarithmically with inverse accuracy, rather than fixed support. On the reduced volume, s=O_gamma(log log(1/epsilon)), but a sufficiently efficient uniform computation of all the required moments has not been earned.

If there are M retained words and ||A||_(2,n)<=1+eta, then sum|c_j|<=sqrt(M)(1+eta). One can allocate individual moment errors epsilon/[2 sum|c_j|]; this explicitly identifies the precision and query load. It does not construct a polynomial-cost moment engine. Substituting an exact finite-volume calculation pays the quasipolynomial cost again.

## 9. Wider primary opening and why the immediate composition fails

This attempt retrieved and read Nelson–Rajakumar–Yin–Zhang–Gullans, arXiv:2610.00548v2, particularly Theorem 2.3, Section 5 and Appendix A. It is a distinct public primary source, not a participant's live diagnostic answer. It treats geometrically local unital circuits with depolarization p after every layer. Its polynomial marginal algorithm has threshold depth of order p^(-1) log(p^(-1)) and a stated exponent of order p^(-(D+1)) in spatial dimension D.

The direct continuous-time substitution does not preserve those constants. For a color-product formula with c layers per physical step h,

\[
 p_h=1-e^{-\gamma h/c}=\Theta(\gamma h),\qquad
 d_h=\Theta(T/h).
\]

At fixed physical gamma T, p_h d_h stays bounded while the theorem's required product p_h d_crit grows like log(1/h). Its supplied runtime exponent also grows as h^(-(D+1)). Thus that theorem cannot simply be evaluated at successively smaller Trotter steps to establish B.

An explicit refinement family is the three-site square-lattice subchain
H=X_1X_2+Z_2Z_3, rho_0=|000><000|, O=Z_1, gamma=r>0, T=1, with h=1/m and two interaction colors. The physical instance is fixed and easy by finite matrices; it is the asserted uniform theorem composition that fails as m grows. This is not a hardness family.

A continuous construction would need to control accumulation of noise against actual interaction strength and soft spatial propagation, rather than charge one full-strength interaction per arbitrarily short layer. No such complete polymer/path-weight computation is claimed in this return. The retrieved circuit construction is a concrete opening, not an unevaluated oracle supplying the answer.

## 10. Other attempted shortcuts and their exact scopes

### Hilbert–Schmidt conversion without dynamics

For the valid product state rho=|0^m><0^m|, take
Delta_m=|0^m><0^m|-2^(-m)I. Then

\[
 \|\Delta_m\|_{2,n}^2=2^{-m}-2^{-2m},\qquad
 \operatorname{Tr}(\rho\Delta_m)=1-2^{-m}.
\]

The ratio is sqrt(2^m-1). This refutes a dimension-free norm conversion for arbitrary error operators. It does not show that Delta_m is the error of the cited simulation algorithm on an allowed physical instance, and it is not a lower bound against other algorithms.

### Passive ancillas and imported resets

The full B dynamics is unital. It preserves I/2^n and cannot be a state-independent pure-reset primitive. Initially pure product ancillas are allowed only as part of the supplied initial state and thereafter undergo the same noise. Their total entropy deficit satisfies (1). A fault-tolerance reduction must construct and charge any purification, clock or state-refresh operation within this actual model. Neither the preceding diagnostic control's non-unital native generator nor the Trivedi–Cirac cooling operations are supplied in B.

### Separability and classical hardness

A reference-assisted failure of complete mediation establishes failure of that physical local-operations representation. It does not establish computational hardness of the specified scalar prediction. Even a two-qubit example outside the mediation cone is directly computable.

## 11. Executable and validation scope

The accompanying predictor.py is a standard-library exact-rational implementation of the finite-volume Pauli Taylor calculation and the conservative horizon/restriction planner. It is executable for small inputs and finite for every valid encoded input. Its large reduced-volume cost is exactly the exponential factor displayed above; no claim that a large instance was run is made.

Validation checks the Pauli sign and rate conventions, a single-qubit analytic expectation, a two-qubit zero-Hamiltonian expectation, a finite noncommuting fixture, and the immediate equilibrium branch at a very long binary-encoded time. These are implementation diagnostics. The general error and resource claims rest on the proof, not on passing the fixtures.

The numerical computation is classical only. No experiment, extra worker, peer message, spending, new hardware or infrastructure was used. No physical dynamics was run and no measurement instrument was acquired. The delivered predictor uses Python's standard library; the three independent floating-point implementation comparisons used the already installed NumPy/SciPy libraries, with one numerical thread. These comparisons are not the certified numerical engine.

## 12. Full endpoint retained

The missing central operation is still a uniform polynomial-cost evaluation at inverse-polynomial accuracy for the reduced worst-case specified-input square-lattice problem, or a computational obstruction proved by a reduction preserving every stated condition. The finite horizon, norm bridge and discrete-circuit opening do not supply that operation.

This is the first frontier attempt on B. It does not start a second attempt or the comparison stage. The coordinator retains control of the later fixed-case body.

## Sources

1. Angrisani, Puig, Teng, Holmes, Dissipation accelerates quantum and classical simulation of open-system dynamics, arXiv:2609.40174v2, 5 November 2026. Target assumptions, Theorem 2, S10.8, Theorem S54, Corollary S55.
   https://arxiv.org/html/2609.40174v2

2. Accepted P2 Complete_Mediation_20261107, immutable snapshot 7f09361dbd8359c2c0bdd352a222fcceffe8c776. REPORT.md, SOURCE_SCOPE.json, ENDPOINT.json.
   https://github.com/harjassand/astra-research-knowledge/blob/7f09361dbd8359c2c0bdd352a222fcceffe8c776/research/returns/2026-11-07-p2-complete-mediation/README.md

3. Trivedi, Cirac, Simulability transitions in continuous-time dynamics of local open quantum systems, arXiv:2110.10638v2. Model and Theorems 1–3.
   https://arxiv.org/html/2110.10638v2

4. Müller-Hermes, França, Wolf, Relative Entropy Convergence for Depolarizing Channels, arXiv:1508.07021v1; Journal of Mathematical Physics 57 (2016). Theorem 6.1 and Lemma 6.1.
   https://arxiv.org/html/1508.07021v1

5. Barthel, Kliesch, Quasi-locality and efficient simulation of Markovian quantum dynamics, arXiv:1111.4210v2; Physical Review Letters 108, 230504 (2012). Theorems 1–2.
   https://arxiv.org/html/1111.4210v2

6. King, Hypercontractivity for semigroups of unital qubit channels, arXiv:1210.8412; Communications in Mathematical Physics 328, 285–301 (2014). The depolarizing hypercontractive inequality, also explicitly stated as Fact 5.1 of source 7.
   https://arxiv.org/abs/1210.8412

7. Nelson, Rajakumar, Yin, Zhang, Gullans, A polynomial-time classical sampler for noisy quantum circuits from statistical mechanics, arXiv:2610.00548v2, 5 October 2026. Theorem 2.3, Section 5, Appendix A.
   https://arxiv.org/html/2610.00548v2

Exposure is not claimed blind. Prior context and the pinned P2 source already record earlier consideration of B, hypercontractivity and strong-noise literature. This turn made no Personal Context search and no retrieval of live experimental answers. Broad primary-literature search also surfaced secondary summaries; no criticism or construction from those summaries was used as a governing premise. Initial direct-fetch failures are not reported as successful reads; subsequent successful public primary-source links supplied the passages used above. The frozen source/access holds, including held P3 and N1686 originals and the unavailable N236 addendum, remain unchanged.

