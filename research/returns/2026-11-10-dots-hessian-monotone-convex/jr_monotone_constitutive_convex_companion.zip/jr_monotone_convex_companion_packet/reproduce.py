"""Read-only package integrity and original-density exact replay."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
count=0
for line in (root/'MANIFEST.sha256').read_text().splitlines():
    expected,name=line.split(maxsplit=1)
    if hashlib.sha256((root/name).read_bytes()).hexdigest()!=expected:
        raise SystemExit('Manifest mismatch: '+name)
    count+=1
print(json.dumps({'package_manifest':'pass','files':count}),flush=True)
start=time.monotonic()
result=subprocess.run([sys.executable,str(root/'independent_review/check_original_density.py')],cwd=root)
print(json.dumps({'exact_checker_returncode':result.returncode,'wall_seconds':time.monotonic()-start}),flush=True)
raise SystemExit(result.returncode)
