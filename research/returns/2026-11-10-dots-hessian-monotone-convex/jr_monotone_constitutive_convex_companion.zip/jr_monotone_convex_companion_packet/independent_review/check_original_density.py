"""Independent exact construction from the uncompleted original J.
No imports from author code, samples, fitting or numerical optimization.
"""
import hashlib, json, pathlib, time
import sympy as S
start=time.monotonic(); root=pathlib.Path(__file__).resolve().parent
k,a,b,c,d,A,B,C,D,r,s=S.symbols('k a b c d A B C D r s')
ell=3*k-1;n=k+1;m=3*k+1
f=S.Matrix([a,b,c,d]);e=S.Matrix([A,B,C,D]);gates=[]
def expand(q): return S.expand(q)
def check(name,q):
    if expand(q)!=0: raise AssertionError(name)
    gates.append(name)
u=a*a+c*c;v=b*b+d*d;j=a*d-b*c;w=a*b+c*d;H=k*u-v+2*j
J8=expand(ell*(k*k*u*u+v*v+2*u*v+4*k*u*j-4*v*j)+4*(5*k+1)*j*j)
lnum=3*ell*(k*u-v)+24*k*j # 2m lambda
Lnum=3*(k*u-v)+4*j       # 2m L
cof=S.Matrix([d,-c,-b,a]);grad=lambda q:S.Matrix([S.diff(q,x) for x in f])
Tnum=expand(1)* (m*grad(H*H+2*n*u*v)-4*n*Lnum*cof) # 8nm T
check('original constitutive decomposition',sum((m*grad(J8)-4*n*lnum*cof-ell*Tnum)[i]**2 for i in range(4)))
Psi=expand(m*J8-2*n*lnum*j) # 8nm Psi
check('explicit Psi SOS',m*Psi-(ell*(m*H-3*n*j)**2+2*n*m*m*ell*w*w+3*ell*n*n*(2*m-3)*j*j))

def sub(q,vals): return q.subs(dict(zip(f,vals)),simultaneous=True)
je=A*D-B*C
dj=(grad(j).dot(e));dl=grad(lnum).dot(e)
aa=A*a+C*c;bb=A*c-C*a;cc=A*b+C*d;dd=A*d-C*b
ee=B*a+D*c;ff=B*c-D*a;gg=B*b+D*d;hh=B*d-D*b
L1=3*(k*aa+gg)+dd+ff
L2=ell*(k*aa-gg)+(5*k+1)*(dd-ff)
L3=k*bb-cc+ee-hh
L4=k*bb-cc-ee+hh
Qnum=expand(ell*e.dot(Tnum.jacobian(f)*e))
channel=expand((dl-6*n*dj)**2/6+2*n*ell*L1**2+2*ell**2*L3**2+6*n*ell*L4**2)
check('full differential monotonicity identity',Qnum-channel)
Fplus=f+e;Fm=f+e/2
dlambda=sub(lnum,Fplus)-lnum;djac=sub(j,Fplus)-j
finite=expand(ell*(sub(Tnum,Fplus)-Tnum).dot(e))
finiteR=expand((dlambda-6*n*djac)**2/6+2*n*ell*sub(L1,Fm)**2+2*ell**2*sub(L3,Fm)**2+6*n*ell*sub(L4,Fm)**2+sub(Psi,e))
check('full finite secant identity',finite-finiteR)
check('rank-one row quartic floor',sub(Psi,e).subs({C:0,D:0})-m*sub(J8,e).subs({C:0,D:0}))

for i in range(4):
    for q in range(i+1,4):
        check('exterior curvature '+str((i,q)),S.diff(Tnum[q],f[i])-S.diff(Tnum[i],f[q])+4*n*(S.diff(Lnum,f[i])*S.diff(j,f[q])-S.diff(Lnum,f[q])*S.diff(j,f[i])))

Qswap=sub(Qnum,e).subs({A:a,B:b,C:c,D:d},simultaneous=True)
# Avoid symbol capture in the swap: substitute all eight variables simultaneously.
Qswap=Qnum.subs({a:A,b:B,c:C,d:D,A:a,B:b,C:c,D:d},simultaneous=True)
check('convex Psi Hessian reciprocity',e.dot(S.hessian(Psi,f)*e)-(Qnum+Qswap)/2)
check('radial coercivity identity',ell*Tnum.dot(f)-4*Psi)

T1=a*(u+v+2*j)/4+d*(v-u)/8
T2=b*(u+v-2*j)/4-c*(v-u)/8
check('k1 explicit first component',Tnum[0].subs(k,1)-64*T1)
check('k1 explicit second component',Tnum[1].subs(k,1)-64*T2)
K=S.Matrix([[3*a*a+b*b+c*c+d*d+3*a*d-2*b*c,2*a*b-(a*c+b*d)/2],[2*a*b-(a*c+b*d)/2,a*a+3*b*b+c*c+d*d-2*a*d+3*b*c]])
V=S.Matrix([T1,T2]).jacobian([a,b]);check('k1 symmetric derivative',sum((4*(V+V.T)/2-K)[i,q]**2 for i in range(2) for q in range(2)))
form=expand((S.Matrix([r,s]).T*K*S.Matrix([r,s]))[0]);R=r*r+s*s
cd=S.Matrix([c,d]);block=S.hessian(form,cd)/2
check('k1 eliminated block',sum((block-R*S.eye(2))[i,q]**2 for i in range(2) for q in range(2)))
linear=S.Matrix([S.diff(form,z).subs({c:0,d:0}) for z in (c,d)])
remainder=form.subs({c:0,d:0})-(linear.dot(linear))/(4*R)
claimed=(3*r*r*(r*r+9*s*s)*a*a+18*r*s*R*a*b+3*s*s*(9*r*r+s*s)*b*b)/(4*R)
check('k1 Schur remainder',S.cancel(remainder-claimed))
Schur=S.hessian(claimed,[a,b])/2
check('k1 Schur determinant',S.cancel(Schur.det()-36*r**4*s**4/R**2))
receipt={'status':'all exact original-density identities passed','gates':len(gates),'names':gates,'seconds':time.monotonic()-start,'source_sha256':hashlib.sha256((root/'SOURCE_SNAPSHOT.md').read_bytes()).hexdigest(),'arithmetic':'SymPy exact rational polynomials; no sampled states'}
print(json.dumps(receipt,indent=2))
