#!/usr/bin/env python3
"""Exact finite algebra for the fixed-contact J_1 Hessian theorem.
No sampled fields, floating optimization, or analytic-theorem inference.
"""
from fractions import Fraction as F
import json

ZERO = (0, 0, 0)

def scalar(x):
    x = F(x)
    return {ZERO: x} if x else {}

def add(*ps):
    out = {}
    for p in ps:
        for e, c in p.items():
            out[e] = out.get(e, F(0)) + c
    return {e: c for e, c in out.items() if c}

def scale(p, c):
    return {e: v * F(c) for e, v in p.items() if v * F(c)}

def mul(p, q):
    out = {}
    for e, c in p.items():
        for f, d in q.items():
            g = tuple(x + y for x, y in zip(e, f))
            out[g] = out.get(g, F(0)) + c * d
    return {e: c for e, c in out.items() if c}

def power(p, n):
    out = scalar(1)
    for _ in range(n):
        out = mul(out, p)
    return out

def monomial(i, j, k, c=1):
    return {(i, j, k): F(c)} if c else {}

def J(a, b, c, d):
    u = add(power(a, 2), power(c, 2))
    v = add(power(b, 2), power(d, 2))
    det = add(mul(a, d), scale(mul(b, c), -1))
    p = add(u, scale(v, -1), scale(det, 2))
    return add(power(det, 2), scale(power(p, 2), F(1, 8)), scale(mul(u, v), F(1, 2)))

U, V, W = monomial(1, 0, 0), monomial(0, 1, 0), monomial(0, 0, 1)
JX = J(scale(U, 2), scale(V, 2), scale(V, -4), scale(W, -4))
expanded = add(monomial(4, 0, 0, 2), monomial(0, 4, 0, 194), monomial(0, 0, 4, 32),
               monomial(2, 2, 0, 36), monomial(0, 2, 2, 16), monomial(2, 0, 2, 112),
               monomial(3, 0, 1, -16), monomial(1, 0, 3, 64), monomial(1, 2, 1, -240))
assert JX == expanded, 'Original quartic expansion failed'

shifted = J(scale(U, 2), add(scalar(1), scale(V, 2)),
            add(scalar(1), scale(V, -4)), scale(W, -4))
contact = add(scalar(2), scale(V, -2), monomial(1, 0, 1, 24), monomial(0, 2, 0, -24),
              monomial(0, 0, 2, 16), monomial(0, 3, 0, -8), monomial(0, 1, 2, -32), JX)
assert shifted == contact, 'Exact pointwise contact identity failed'

E = add(monomial(4, 0, 0, F(27, 25)), monomial(0, 4, 0, F(675, 16)),
        monomial(2, 2, 0, F(27, 2)), monomial(0, 2, 2, 48))
a = F(2429, 16)
b = add(monomial(2, 0, 0, F(45, 2)), monomial(1, 0, 1, -240), monomial(0, 0, 2, -32))
c = add(monomial(4, 0, 0, F(23, 25)), monomial(3, 0, 1, -16),
        monomial(2, 0, 2, 112), monomial(1, 0, 3, 64), monomial(0, 0, 4, 32))
assert add(JX, scale(E, -1)) == add(monomial(0, 4, 0, a), mul(b, power(V, 2)), c)
delta = add(scale(c, 4 * a), scale(power(b, 2), -1))
G = [[F(2621, 50), F(542), F(300)], [F(542), F(11252), F(11752)],
     [F(300), F(11752), F(18408)]]
z = [power(U, 2), mul(U, W), power(W, 2)]
gram = {}
for i in range(3):
    for j in range(3):
        gram = add(gram, scale(mul(z[i], z[j]), G[i][j]))
assert delta == gram, 'Discriminant Gram identity failed'

def det3(M):
    return (M[0][0] * (M[1][1] * M[2][2] - M[1][2] * M[2][1])
            - M[0][1] * (M[1][0] * M[2][2] - M[1][2] * M[2][0])
            + M[0][2] * (M[1][0] * M[2][1] - M[1][1] * M[2][0]))

minors = [G[0][0], G[0][0] * G[1][1] - G[0][1] ** 2, det3(G)]
assert all(x > 0 for x in minors), 'Positive principal minors failed'
a0 = G[0][0]
s11 = G[1][1] - G[0][1] ** 2 / a0
s22 = G[2][2] - G[0][2] ** 2 / a0
s12 = G[1][2] - G[0][1] * G[0][2] / a0
assert 52 < a0 < 53 and s11 > 5600 and s22 > 16600 and 0 < s12 < 8700
assert 5600 * 16600 - 8700 ** 2 == 17270000

lam = F(2, 5)
assert F(3, 2) * F(9, 2) * lam ** 2 == F(27, 25)
assert F(3, 2) * F(9, 2) / lam ** 2 == F(675, 16)
assert F(3, 2) * F(9, 2) * 2 == F(27, 2)
assert 3 * 16 == 48
print(json.dumps({
    'status': 'PASS',
    'arithmetic': 'Python standard-library fractions.Fraction; exact rational',
    'checks': ['original J_1 expansion', 'pointwise contact identity',
               'quartic reserve', 'discriminant Gram identity',
               'positive Gram principal minors', 'rational Schur bounds', 'heat-budget constants'],
    'gram_leading_principal_minors': [str(x) for x in minors],
    'scope': 'Finite algebra only. Heat admission, compatibility and Sobolev passage are proved analytically.'
}, indent=2))
