"""Read-only package integrity check and two exact mathematical replays.

Run with Python 3.12 and SymPy 1.14.0. No installation or network action occurs.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
manifest = root / "MANIFEST.sha256"
checked = 0
for line in manifest.read_text().splitlines():
    expected, name = line.split(maxsplit=1)
    target = root / name
    actual = hashlib.sha256(target.read_bytes()).hexdigest()
    if actual != expected:
        raise SystemExit("Manifest mismatch: " + name)
    checked += 1
print(json.dumps({"package_manifest": "pass", "files": checked}), flush=True)

scripts = [
    "quartic_all_k_endpoint_matched_support_20261109/replay_all_k_certificate.py",
    "quartic_all_r_hessian_independent_review_20261110/independent_closure_check.py",
]
for script in scripts:
    started = time.monotonic()
    result = subprocess.run([sys.executable, str(root / script)], cwd=root)
    print(json.dumps({"script": script, "returncode": result.returncode,
                      "wall_seconds": time.monotonic() - started}), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
print(json.dumps({"status": "both exact replays passed"}), flush=True)
