"""Independent original-density and certificate-closure supplement.

No constructor or replay imports. No optimization or parameter sampling.
"""
import ast, hashlib, json, pathlib, sys, time
import sympy as S
sys.set_int_max_str_digits(0)
start=time.monotonic()
root=pathlib.Path(__file__).resolve().parents[1]/'quartic_all_k_endpoint_matched_support_20261109'
k,x,y,V,t,alpha,beta,delta,e=S.symbols('k x y V t alpha beta delta e')
ell=3*k-1; n=k+1; m=3*k+1
checks=[]
def check(name, test):
    if not test: raise AssertionError(name)
    checks.append(name)
def load(name): return json.loads((root/name).read_text())
loc={str(z):z for z in (k,x,y,V)}
def expr(z): return S.sympify(z,locals=loc)

# Use the original uncompleted-square column formula, and a formal amplitude.
aa=alpha+t*x; bb=beta+2*k*t*V; cc=-m*t*V; dd=delta+t*y
u=aa**2+cc**2; v=bb**2+dd**2; j=aa*dd-bb*cc
J=(ell*(k*k*u*u+v*v+2*u*v+4*k*u*j-4*v*j)
       +4*(5*k+1)*j*j) # literal 8n J
poly=S.Poly(S.expand(J),t)
translation=2*alpha*delta+ell/m*(k*alpha**2-beta**2-delta**2+S.Rational(3,2)*n*alpha*delta)
P=S.expand(m*(poly.nth(2)+poly.nth(3)+poly.nth(4))-8*n*m*translation*(x*y+2*k*m*V**2))
stored=load('MATRIX.json')
means=S.Matrix([alpha,delta,beta])
Q=S.Matrix([[expr(z) for z in row] for row in stored['Q']])
C=S.Matrix([expr(z) for z in stored['C']]); E=expr(stored['E'])
check('literal original-density full affine polynomial',S.cancel(P-(means.T*Q*means)[0]-(C.T*means)[0]-E)==0)
check('stored matrix symmetric',Q==Q.T)

# Verify manifest before accepting any frozen dependency.
manifest=root/'FULL_CANDIDATE_MANIFEST.sha256'
for line in manifest.read_text().splitlines():
    sha,name=line.split(maxsplit=1)
    check('manifest '+name,hashlib.sha256((root/name).read_bytes()).hexdigest()==sha)

data={}
for name in ('Q11','Q2','Q3','M4'):
    obj=load(name+'.json')
    data[name]={ast.literal_eval(a):expr(b) for a,b in obj['coefficients'].items()}

# Pure off-diagonal Hessians: explicitly verify strict coefficient positivity,
# rather than infer it from a nonnegative homogeneous-form statement.
for name,top in [('Q2',2),('Q3',3),('M4',5)]:
    coeff=data[name]
    pure=S.expand(sum(f.subs({x:0,y:0})*e**a for (a,b),f in coeff.items() if b==top))
    # The endpoint ell=0 is excluded; an initial zero coefficient is allowed.
    check(name+' pure-V leading coefficient strictly positive',not pure.equals(0) and all(c>=0 for c in S.Poly(pure,e).all_coeffs()))
    check(name+' all other pure-V powers absent',all(f.subs({x:0,y:0})==0 for (a,b),f in coeff.items() if b!=top))

def binary(cs): return sum(S.Integer(c)*x**(len(cs)-1-i)*y**i for i,c in enumerate(cs))
F8=4*binary([47528,-67429,46000,30846,28941,47523,10692,-8424,1053])
P8=binary([33784,-58204,54811,-4098,7245,28872,-135,-2106,243])
P6=binary([1764,-3598,4147,-1950,747,972,-162])
P4=binary([164,-388,519,-378,189])
Q6=binary([281000,-469028,557859,-274008,243720,25380,2025])
Q5=binary([11488,-20906,24855,-14094,8694,648])
Q4=binary([284,-564,681,-432,216])
co=data['M4']
for a,form in [(8,F8),(9,P8),(10,2*x*x*P6),(11,x**4*P4)]:
    check('literal theorem T1 coefficient '+str(a),S.expand(co[(a,1)]-S.Rational(8,2187)*form)==0)
for a,form in [(11,Q6),(12,2*x*Q5),(13,3*x*x*Q4)]:
    check('literal theorem T2 coefficient '+str(a),S.expand(co[(a,2)]-S.Rational(8,6561)*form)==0)

records=load('JOINT_STURM_PROGRESS.json')
check('exactly one transparently unused failed record',[a for a,r in records.items() if r['status']!='positive']==['tail_T1_determinant'])
check('128 declared records',len(records)==128)
for name in ['M4_ell8_T1','tail_T1_P4','tail_T2_Q4','tail_T2_determinant']:
    rec=records[name]
    check(name+' has no coordinate factors',rec['even_coordinate_factors']==[0,0])

print(json.dumps({'status':'pass','checks':len(checks),'seconds':time.monotonic()-start,
 'source_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
 'scope':'Independent uncompleted original-density reconstruction, frozen manifest, explicit pure-V strictness, literal theorem tails and failed-record exclusion.'},indent=2))
