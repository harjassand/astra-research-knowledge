"""Exact Schur construction for the single remaining beta-elimination quartic."""
import sympy as s,json,pathlib,time,hashlib
start=time.monotonic();out=pathlib.Path(__file__).parent
k,x,y,al,de,e=s.symbols('k x y al de e');loc={str(v):v for v in (k,x,y,al,de)}
obj=json.loads((out/'TRANSVERSE_BLOCKS.json').read_text())
P=s.Poly(s.cancel(s.sympify(obj['K1_quartic'],locals=loc)/(2*(k+1)*(3*k-1)*(3*k+1))),al,de)
M=s.zeros(3)
M[0,0]=P.coeff_monomial(al**2);M[1,1]=P.coeff_monomial(de**2)
M[0,1]=M[1,0]=P.coeff_monomial(al*de)/2
M[0,2]=M[2,0]=P.coeff_monomial(al)/2
M[1,2]=M[2,1]=P.coeff_monomial(de)/2
M[2,2]=P.coeff_monomial(1)
results={}
for i in (1,2,3):
    det=s.factor(M[:i,:i].det(method='domain-ge'))
    expanded=s.Poly(s.expand(det.subs(k,(e+1)/3)),e)
    results[str(i)]={'full':str(det),'ell_coefficients':{str(ex[0]):str(s.factor(co)) for ex,co in expanded.terms()}}
result={'matrix':[[str(s.factor(v)) for v in row] for row in M.tolist()],
 'minors':results,'seconds':time.monotonic()-start,
 'source_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}
(out/'REMAINING_QUARTIC.json').write_text(json.dumps(result,indent=2));print(json.dumps({'seconds':result['seconds'],'source_sha256':result['source_sha256'],'minors':{key:val['full'] for key,val in results.items()}},indent=2))
