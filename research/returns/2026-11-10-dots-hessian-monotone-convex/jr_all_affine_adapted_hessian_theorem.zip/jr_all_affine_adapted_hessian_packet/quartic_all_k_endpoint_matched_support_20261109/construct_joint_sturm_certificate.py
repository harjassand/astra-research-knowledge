"""One exact all-parameter coefficient/tail certificate construction.

No parameter or state samples, optimizer, adaptive coefficients, or retuning.
The fixed high-parameter tails are grouped before any positivity test.
"""
import sympy as s,json,pathlib,time,hashlib,ast
start=time.monotonic();out=pathlib.Path(__file__).parent
x,y,z=s.symbols('x y z');loc={'x':x,'y':y}
data={name:json.loads((out/(name+'.json')).read_text()) for name in ('Q2','Q3','M4')}
coeff={name:{ast.literal_eval(key):s.sympify(value,locals=loc) for key,value in data[name]['coefficients'].items()} for name in data}
targets={}
for name in ('Q2','Q3'):
 for (ep,tp),co in coeff[name].items():
  if tp>=1:targets[f'{name}_ell{ep}_T{tp}']=co
for (ep,tp),co in coeff['M4'].items():
 if tp==0:continue # paid complete all-k diagonal block, not separate coefficients
 if tp==1 and ep>=9:continue
 if tp==2 and ep>=11:continue
 targets[f'M4_ell{ep}_T{tp}']=co

P8=s.expand(coeff['M4'][(9,1)]*s.Rational(2187,8))
P6=s.cancel(coeff['M4'][(10,1)]*s.Rational(2187,16)/x**2)
P4=s.cancel(coeff['M4'][(11,1)]*s.Rational(2187,8)/x**4)
Q6=s.expand(coeff['M4'][(11,2)]*s.Rational(6561,8))
Q5=s.cancel(coeff['M4'][(12,2)]*s.Rational(6561,16)/x)
Q4=s.cancel(coeff['M4'][(13,2)]*s.Rational(2187,8)/x**2)
for expr in (P8,P6,P4,Q6,Q5,Q4):s.Poly(expr,x,y,domain=s.QQ)
targets.update({'tail_T1_P4':P4,'tail_T1_determinant':s.expand(P8*P4-P6**2),
                'tail_T2_Q4':Q4,'tail_T2_determinant':s.expand(3*Q6*Q4-Q5**2)})
tail={'T1':{'P8':str(P8),'P6':str(P6),'P4':str(P4),
             'group':'(8/2187)*ell^9*[P8+2*(ell*x^2)*P6+(ell*x^2)^2*P4]'},
      'T2':{'Q6':str(Q6),'Q5':str(Q5),'Q4':str(Q4),
             'group':'(8/6561)*ell^11*[Q6+2*(ell*x)*Q5+3*(ell*x)^2*Q4]'}}
(out/'JOINT_TAIL_FORMS.json').write_text(json.dumps(tail,indent=2))

def variations(seq):
 vals=[int(v) for v in seq if v]
 return sum(vals[i]!=vals[i-1] for i in range(1,len(vals)))

receipts={};failed=[]
for name,expr in targets.items():
 P=s.Poly(s.expand(expr),x,y,domain=s.QQ)
 degs={sum(ex) for ex,co in P.terms()}
 assert len(degs)==1 and next(iter(degs))%2==0
 # Strip harmless even coordinate factors if present; do not strip signed factors.
 px=min(ex[0] for ex,co in P.terms());py=min(ex[1] for ex,co in P.terms())
 if px%2 or py%2:
  failed.append(name);receipts[name]={'status':'odd coordinate factor','x_power':px,'y_power':py};continue
 reduced=s.Poly(s.cancel(P.as_expr()/(x**px*y**py)).subs(y,1),x,domain=s.QQ)
 chain=reduced.sturm()
 plus=[s.sign(q.LC()) for q in chain if not q.is_zero]
 minus=[s.sign(q.LC())*(-1)**q.degree() for q in chain if not q.is_zero]
 vminus=variations(minus);vplus=variations(plus);roots=vminus-vplus
 ok=roots==0 and reduced.LC()>0 and reduced.degree()%2==0
 record={'status':'positive' if ok else 'not_certified','homogeneous_degree':next(iter(degs)),
         'even_coordinate_factors':[px,py],'polynomial_coefficients':[str(v) for v in reduced.all_coeffs()],
         'sturm_coefficients':[[str(v) for v in q.all_coeffs()] for q in chain],
         'signs_minus_infinity':[int(v) for v in minus],
         'signs_plus_infinity':[int(v) for v in plus],
         'variations':[vminus,vplus],'real_root_count':int(roots)}
 receipts[name]=record
 if not ok:failed.append(name)
 print(name,record['status'],'roots',roots,flush=True)
 (out/'JOINT_STURM_PROGRESS.json').write_text(json.dumps(receipts,indent=2))
result={'source_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
        'seconds':time.monotonic()-start,'status':'all_declared_forms_paid' if not failed else 'incomplete',
        'count':len(receipts),'failed':failed,
        'scope':'Exact fixed coefficient and grouped-tail construction. Full theorem requires stated diagonal and leading-minor dependencies, not numerical sampling.'}
(out/'JOINT_STURM_RECEIPT.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
