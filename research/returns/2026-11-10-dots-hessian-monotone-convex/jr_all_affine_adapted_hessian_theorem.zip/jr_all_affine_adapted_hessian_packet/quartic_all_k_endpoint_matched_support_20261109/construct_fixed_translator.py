# A fixed exact construction, not a parameter scan or an optimizer.
import sympy as s, itertools, json, pathlib, time, hashlib
from sympy.polys.rings import ring
from sympy.polys.domains import QQ
start=time.monotonic(); k,x,y,V,al,be,de=s.symbols('k x y V al be de'); e=s.symbols('e');a,b,c,d=s.symbols('a b c d');n=k+1;m=3*k+1;ell=3*k-1
u=a*a+c*c;v=b*b+d*d;j=a*d-b*c;h=k*u-v+2*j
Jbar=s.expand(ell*h*h+2*ell*n*u*v+8*n*j*j) # 8n times the original J
base={a:al,b:be,c:0,d:de};pert={a:x,b:2*k*V,c:-m*V,d:y}
JA=Jbar.subs(base,simultaneous=True)
lin=sum(s.diff(Jbar,z).subs(base,simultaneous=True)*pert[z] for z in [a,b,c,d])
full=Jbar.subs({z:base[z]+pert[z] for z in [a,b,c,d]},simultaneous=True)
jA=al*de;zA=k*al*al-be*be-de*de
# 8nm times lambda, kept polynomial.
lam_scaled=8*n*(2*m*jA+ell*(zA+s.Rational(3,2)*n*jA))
jX=x*y+2*k*m*V*V
P=s.Poly(s.expand(m*(full-JA-lin)-lam_scaled*jX),al,de,be)
Q=s.zeros(3);C=s.zeros(3,1)
for i in range(3):
 ex=[0]*3;ex[i]=1;C[i]=P.coeff_monomial(tuple(ex))
 for jj in range(3):
  ex=[0]*3;ex[i]+=1;ex[jj]+=1;Q[i,jj]=P.coeff_monomial(tuple(ex))/(1 if i==jj else 2)
E=P.coeff_monomial((0,0,0));M=Q.row_join(C/2).col_join((C.T/2).row_join(s.Matrix([[E]])))
# Save the acquired matrix before any determinant processing.
out=pathlib.Path(__file__).parent
matrix={'scale':'8*(k+1)*(3*k+1)','Q':[[str(s.factor(z)) for z in row] for row in Q.tolist()],'C':[str(s.factor(z)) for z in C],'E':str(s.factor(E))}
(out/'MATRIX.json').write_text(json.dumps(matrix,indent=2))
R,*gens=ring('k,x,y,V',QQ)
def detpoly(A):
 D=R.zero;N=A.rows
 for p in itertools.permutations(range(N)):
  sign=(-1)**sum(p[i]>p[j] for i in range(N) for j in range(i+1,N))
  term=R(sign)
  for i in range(N):term*=R.from_expr(A[i,p[i]])
  D+=term
 return s.expand(D.as_expr())
res={}
for name,A in [('q11',Q[:1,:1]),('q2',Q[:2,:2]),('q3',Q),('m4',M)]:
 D=detpoly(A);pv=s.Poly(D,V);assert all(ex[0]%2==0 for ex,co in pv.terms())
 # The parameter e=3k-1 is nonnegative on the sought half-line.
 De=s.Poly(s.expand(D.subs(k,(e+1)/3)),e,V,x,y)
 min_e=min(ex[0] for ex,co in De.terms());min_v=min(ex[1] for ex,co in De.terms())
 coeffs={}
 for (ep,vp,xp,yp),co in De.terms():
  key=(ep-min_e,vp//2)
  coeffs[key]=coeffs.get(key,s.S(0))+co*x**xp*y**yp
 record={'endpoint_factor_e':min_e,'terms':len(De.terms()),'coefficients':{str(key):str(s.factor(co)) for key,co in sorted(coeffs.items())}}
 (out/(name.upper()+'.json')).write_text(json.dumps(record,indent=2))
 res[name]={'endpoint_factor_e':min_e,'terms':len(De.terms()),'coefficient_forms':len(coeffs)}
 print(name,json.dumps(res[name]),flush=True)
receipt={'status':'constructed_exactly','source_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'seconds':time.monotonic()-start,'blocks':res,'scope':'Fixed original-J polynomial matrix; no positivity conclusion unless separately derived from all coefficient forms.'}
(out/'RECEIPT.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt),flush=True)
