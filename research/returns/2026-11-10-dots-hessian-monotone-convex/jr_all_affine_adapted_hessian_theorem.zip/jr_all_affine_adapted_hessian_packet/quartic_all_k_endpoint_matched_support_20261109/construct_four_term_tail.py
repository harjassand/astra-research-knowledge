"""One exact joint four-coefficient tail construction; candidate unchanged."""
import sympy as s,json,pathlib,time,hashlib,ast
start=time.monotonic();out=pathlib.Path(__file__).parent
x,y,e,z=s.symbols('x y e z');loc={'x':x,'y':y}
coeff={ast.literal_eval(key):s.sympify(value,locals=loc) for key,value in json.loads((out/'M4.json').read_text())['coefficients'].items()}
tails=json.loads((out/'JOINT_TAIL_FORMS.json').read_text())['T1']
P8,P6,P4=[s.sympify(tails[key],locals=loc) for key in ('P8','P6','P4')]
F8=s.expand(coeff[(8,1)]*s.Rational(2187,8))
a=P4;b=2*P6;c=P8;d=x*x*F8
f=a*z**3+b*z**2+c*z+d
original=sum(coeff[(i,1)]*e**i for i in range(8,12))
assert s.expand(x*x*original-s.Rational(8,2187)*e**8*f.subs(z,e*x*x))==0
disc=s.expand(b*b*c*c-4*a*c**3-4*b**3*d-27*a*a*d*d+18*a*b*c*d)
positive=s.Poly(-disc,x,y,domain=s.QQ)
degrees={sum(ex) for ex,co in positive.terms()};assert degrees=={28}
poly=s.Poly(positive.as_expr().subs(y,1),x,domain=s.QQ)
chain=poly.sturm()
plus=[int(s.sign(q.LC())) for q in chain if not q.is_zero]
minus=[int(s.sign(q.LC())*(-1)**q.degree()) for q in chain if not q.is_zero]
def variation(v):return sum(a!=b for a,b in zip(v,v[1:]))
counts=[variation(minus),variation(plus)]
ok=counts[0]==counts[1] and poly.LC()>0 and poly.degree()==28
result={'source_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
        'seconds':time.monotonic()-start,'status':'negative_cubic_discriminant_paid' if ok else 'not_certified',
        'group_identity':'x^2*sum_{i=8}^{11}coeff_i*ell^i=(8/2187)*ell^8*f(ell*x^2)',
        'cubic_coefficients':[str(s.expand(v)) for v in (a,b,c,d)],
        'minus_discriminant':str(positive.as_expr()),
        'sturm_coefficients':[[str(v) for v in q.all_coeffs()] for q in chain],
        'signs_minus_infinity':minus,'signs_plus_infinity':plus,
        'variations':counts,'real_root_count':counts[0]-counts[1],
        'x0_original_tail':'(8/2187)*ell^8*(4212+243*ell)*y^8'}
(out/'FOUR_TERM_TAIL_CERTIFICATE.json').write_text(json.dumps(result,indent=2));print(json.dumps({key:result[key] for key in ('source_sha256','seconds','status','variations','real_root_count')},indent=2))
