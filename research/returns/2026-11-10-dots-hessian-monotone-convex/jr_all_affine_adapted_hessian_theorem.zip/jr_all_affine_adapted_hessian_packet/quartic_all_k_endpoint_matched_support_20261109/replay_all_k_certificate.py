"""Read-only exact replay of the full all-k adapted-Hessian certificate.

Python3.12 / SymPy1.14. No floating computation, optimizer or parameter grid.
This checker does not overwrite construction data. It prints one JSON receipt.
"""
import sympy as s
import json,pathlib,hashlib,time,itertools,ast,sys
from sympy.polys.rings import ring
from sympy.polys.domains import QQ
sys.set_int_max_str_digits(0)
start=time.monotonic();root=pathlib.Path(__file__).parent;gates=[]
k,x,y,V,e,al,be,de=s.symbols('k x y V e al be de')
n=k+1;m=3*k+1;ell=3*k-1
loc={str(v):v for v in (k,x,y,V,e,al,be,de)}
def load(name):return json.loads((root/name).read_text())
def expr(v):return s.sympify(v,locals=loc)
def gate(name,condition):
    if not bool(condition):raise AssertionError(name)
    gates.append(name)

# Reconstruct the literal original density, tangent and translator.
a,b,c,d=s.symbols('a b c d');u=a*a+c*c;v=b*b+d*d;j=a*d-b*c
J8=s.expand(ell*(k*u-v+2*j)**2+2*ell*n*u*v+8*n*j*j)
base={a:al,b:be,c:0,d:de};pert={a:x,b:2*k*V,c:-m*V,d:y}
JA=J8.subs(base,simultaneous=True)
linear=sum(s.diff(J8,z).subs(base,simultaneous=True)*pert[z] for z in (a,b,c,d))
whole=J8.subs({z:base[z]+pert[z] for z in (a,b,c,d)},simultaneous=True)
P=s.expand(m*(whole-JA-linear)-8*n*(2*m*al*de+ell*(k*al*al-be*be-de*de+s.Rational(3,2)*n*al*de))*(x*y+2*k*m*V*V))
obj=load('MATRIX.json');Q=s.Matrix([[expr(t) for t in row] for row in obj['Q']])
C=s.Matrix([expr(t) for t in obj['C']]);E=expr(obj['E'])
avec=s.Matrix([al,de,be]);M=Q.row_join(C/2).col_join((C.T/2).row_join(s.Matrix([[E]])))
gate('literal original-J affine identity',s.expand(P-(avec.T*Q*avec)[0]-(C.T*avec)[0]-E)==0)

# Reconstruct every determinant coefficient, without invoking constructors.
R,*_=ring('k,x,y,V',QQ)
def determinant(A):
    rows=[[R.from_expr(t) for t in row] for row in A.tolist()]
    N=A.rows;result=R.zero
    for p in itertools.permutations(range(N)):
        term=R((-1)**sum(p[i]>p[j] for i in range(N) for j in range(i+1,N)))
        for i in range(N):term*=rows[i][p[i]]
        result+=term
    return result
coeff={}
for name,A in [('Q11',Q[:1,:1]),('Q2',Q[:2,:2]),('Q3',Q),('M4',M)]:
    data=load(name+'.json');items={ast.literal_eval(key):expr(value) for key,value in data['coefficients'].items()}
    coeff[name]=items
    rebuilt=ell**data['endpoint_factor_e']*sum(co*ell**ep*V**(2*tp) for (ep,tp),co in items.items())
    gate(name+' exact coefficient coverage',determinant(A)==R.from_expr(rebuilt))

# The full all-k V=0 diagonal matrix and its explicit positive Gram.
dd=k*x*x-y*y;jj=x*y;E2=dd*dd+4*k*jj*jj
a0=ell/(8*n);b0=ell/(2*n);c0=(3*k*k+12*k+1)/(4*n);L=ell*(dd+3*k*jj)/m
As=6*a0-L*jj/E2;Bs=ell*(7*k+1)/(4*n*m)+L*dd/(2*E2);Cs=(13*k+1)/(4*n)+L*k*jj/E2
v1=4*a0*dd+2*b0*jj;v2=b0*dd+2*c0*jj;f=a0*dd**2+b0*dd*jj+c0*jj**2
ss=k*al*x-de*y;tt=al*y+de*x
diagonal=As*ss**2+2*Bs*ss*tt+Cs*tt**2+v1*ss+v2*tt+f
gate('full diagonal invariant identity',s.cancel(diagonal-P.subs({V:0,be:0})/(8*n*m))==0)
d0,j0=s.symbols('d0 j0');F=6*k*k-7*k-1;h=2*k-s.Rational(1,3);aa=2*m*m
cc=ell*(9*k**3-23*k*k-7*k+1);ee=4*k*ell*(9*k*k+4*k-1);ff=4*k*n*(33*k*k-1)
quartic=aa*d0**4-2*m*F*d0**3*j0+cc*d0*d0*j0*j0+ee*d0*j0**3+ff*j0**4
gram=s.Matrix([[aa,-m*F,-aa*h],[-m*F,cc+2*aa*h,ee/2],[-aa*h,ee/2,ff]])
z=s.Matrix([d0*d0,d0*j0,j0*j0]);gate('all-k diagonal Gram identity',s.expand((z.T*gram*z)[0]-quartic)==0)
B=cc+2*aa*h-F*F/2;CC=ff-aa*h*h;O=ee/2-m*F*h
for name,p in [('B',B),('C',CC),('det',B*CC-O*O)]:
    p=s.Poly(s.expand(p.subs(k,(e+1)/3)),e)
    gate('positive diagonal Schur '+name,all(q>0 for q in p.all_coeffs()))
N=3*m*m*dd*dd-m*(18*k*k+7*k+1)*dd*jj+(54*k**4+69*k**3+16*k*k+k)*jj*jj
gate('diagonal metric determinant identity',s.cancel(As*Cs-Bs*Bs-ell*N/(4*E2*n*m*m))==0)
gate('diagonal augmented determinant identity',s.cancel(E2*(f*(As*Cs-Bs*Bs)-(Cs*v1*v1-2*Bs*v1*v2+As*v2*v2)/4)-ell**2*quartic.subs({d0:dd,j0:jj})/(64*n*n*m*m))==0)
reserve=s.Poly(s.expand((324*k**4+576*k**3+107*k*k-2*k-1).subs(k,(e+1)/3)),e)
gate('positive diagonal discriminant',all(q>0 for q in reserve.all_coeffs()))
gate('decoupled affine-beta identity',s.expand(Q[2,2].subs(V,0)-2*ell*(m*(x*x+y*y)+2*(1-k)*x*y))==0)
gate('D1 positive-T coefficient identity',s.expand(s.Poly(Q[0,0],V).coeff_monomial(V**2)-2*k*k*ell*(27*k**3+39*k*k+13*k+1))==0)

# Reconstruct the fixed required binary forms and both joint tails.
targets={}
for name in ('Q2','Q3'):
    for (ep,tp),co in coeff[name].items():
        if tp>=1:targets[f'{name}_ell{ep}_T{tp}']=co
for (ep,tp),co in coeff['M4'].items():
    if tp==0 or (tp==1 and ep>=9) or (tp==2 and ep>=11):continue
    targets[f'M4_ell{ep}_T{tp}']=co
P8=s.expand(coeff['M4'][(9,1)]*s.Rational(2187,8));P6=s.cancel(coeff['M4'][(10,1)]*s.Rational(2187,16)/x**2);P4=s.cancel(coeff['M4'][(11,1)]*s.Rational(2187,8)/x**4)
Q6=s.expand(coeff['M4'][(11,2)]*s.Rational(6561,8));Q5=s.cancel(coeff['M4'][(12,2)]*s.Rational(6561,16)/x);Q4=s.cancel(coeff['M4'][(13,2)]*s.Rational(2187,8)/x**2)
targets.update({'tail_T1_P4':P4,'tail_T1_determinant':s.expand(P8*P4-P6**2),'tail_T2_Q4':Q4,'tail_T2_determinant':s.expand(3*Q6*Q4-Q5**2)})
records=load('JOINT_STURM_PROGRESS.json');gate('complete declared target set',set(targets)==set(records))

def variation(signs):return sum(a!=b for a,b in zip(signs,signs[1:]))
def sturm_chain(poly,record,label):
    chain=[s.Poly.from_list([s.Rational(v) for v in row],x,domain=s.QQ) for row in record['sturm_coefficients']]
    gate(label+' square-free monic start',chain[0]==poly.sqf_part().monic())
    if chain[0].degree()>0:
        gate(label+' derivative',len(chain)>1 and chain[1]==chain[0].diff())
        for i in range(1,len(chain)-1):gate(label+' recurrence '+str(i),chain[i+1]==-chain[i-1].rem(chain[i]))
    gate(label+' nonzero constant endpoint',chain[-1].degree()==0 and not chain[-1].is_zero)
    plus=[int(s.sign(q.LC())) for q in chain];minus=[int(s.sign(q.LC())*(-1)**q.degree()) for q in chain]
    gate(label+' recorded signs',plus==record['signs_plus_infinity'] and minus==record['signs_minus_infinity'])
    variations=[variation(minus),variation(plus)]
    gate(label+' zero real roots',variations==record['variations'] and variations[0]==variations[1])
    gate(label+' positive polynomial',poly.LC()>0 and poly.degree()%2==0)

for label,form in targets.items():
    if label=='tail_T1_determinant':continue # Failed earlier allocation, expressly unused.
    record=records[label];poly2=s.Poly(s.expand(form),x,y,domain=s.QQ)
    degree={sum(ex) for ex,co in poly2.terms()};px=min(ex[0] for ex,co in poly2.terms());py=min(ex[1] for ex,co in poly2.terms())
    gate(label+' homogeneous even factors',len(degree)==1 and next(iter(degree))%2==0 and px%2==0 and py%2==0 and [px,py]==record['even_coordinate_factors'])
    poly=s.Poly(s.cancel(poly2.as_expr()/(x**px*y**py)).subs(y,1),x,domain=s.QQ)
    gate(label+' literal polynomial',poly.all_coeffs()==[s.Rational(v) for v in record['polynomial_coefficients']])
    sturm_chain(poly,record,label)

# The successful four-term replacement, with its original zero-x chart.
F8=s.expand(coeff['M4'][(8,1)]*s.Rational(2187,8));z0=s.symbols('z0')
f=P4*z0**3+2*P6*z0**2+P8*z0+x*x*F8
original=sum(coeff['M4'][(i,1)]*e**i for i in range(8,12))
gate('four-term group identity',s.expand(x*x*original-s.Rational(8,2187)*e**8*f.subs(z0,e*x*x))==0)
disc=s.expand((2*P6)**2*P8**2-4*P4*P8**3-4*(2*P6)**3*x*x*F8-27*P4**2*(x*x*F8)**2+18*P4*(2*P6)*P8*x*x*F8)
tail=load('FOUR_TERM_TAIL_CERTIFICATE.json')
gate('literal negative cubic discriminant',s.expand(-disc-expr(tail['minus_discriminant']))==0)
poly=s.Poly((-disc).subs(y,1),x,domain=s.QQ)
gate('strict degree28 including infinity',poly.degree()==28 and s.Poly(-disc,x,y).total_degree()==28 and poly.LC()>0)
sturm_chain(poly,tail,'four-term negative discriminant')
gate('zero-x original tail',s.expand(original.subs(x,0)-s.Rational(8,2187)*e**8*(4212+243*e)*y**8)==0)

print(json.dumps({'status':'all_required_exact_gates_pass','gates':len(gates),'seconds':time.monotonic()-start,
 'checker_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
 'scope':'All-k upper-triangular adapted-Hessian support certificates. Mathematical compactness/Sobolev/QR reasoning remains in the standalone proof; no full vector-gradient QC claim.'},indent=2))
