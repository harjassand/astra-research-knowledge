"""Exact beta-affine elimination of the fixed full matrix; no search."""
import sympy as s,json,pathlib,time,hashlib
start=time.monotonic();out=pathlib.Path(__file__).parent
k,x,y,V,al,de,e=s.symbols('k x y V al de e')
obj=json.loads((out/'MATRIX.json').read_text())
loc={str(v):v for v in (k,x,y,V)}
Q=s.Matrix([[s.sympify(v,locals=loc) for v in row] for row in obj['Q']])
C=s.Matrix([s.sympify(v,locals=loc) for v in obj['C']]);E=s.sympify(obj['E'],locals=loc)
q=s.Poly(Q[2,2],V);q0=q.coeff_monomial(1);q2=q.coeff_monomial(V**2)
R=s.Poly(s.expand(Q[0,0]*al**2+2*Q[0,1]*al*de+Q[1,1]*de**2+C[0]*al+C[1]*de+E),V)
R0,R1,R2=[R.coeff_monomial(V**j) for j in (0,2,4)]
Lc=s.Poly(s.expand((Q[0,2]*al+Q[1,2]*de+C[2]/2)/V),V)
L0,L1=[Lc.coeff_monomial(V**j) for j in (0,2)]
K1=s.expand(q2*R0+q0*R1-L0**2)
K2=s.expand(q2*R1+q0*R2-2*L0*L1)
K3=s.factor(q2*R2-L1**2)
vars=(al,de,x,y);G=s.hessian(K2,vars)/2
assert s.expand((s.Matrix([vars])*G*s.Matrix(vars))[0]-K2)==0
minors={str(i):str(s.factor(G[:i,:i].det(method='domain-ge'))) for i in (1,2,3,4)}
result={'normalization':'All inputs are scaled by8nm as in MATRIX.json; identity q_beta*reduced=P0+T*K1+T^2*K2+T^3*K3.',
        'q0':str(s.factor(q0)),'q2':str(s.factor(q2)),'R2':str(s.factor(R2)),
        'L0':str(s.factor(L0)),'L1':str(s.factor(L1)),'K3':str(K3),
        'K2_matrix':[[str(s.factor(v)) for v in row] for row in G.tolist()],
        'K2_principal_minors':minors,
        'K1_quartic':str(s.factor(K1)),
        'seconds':time.monotonic()-start,
        'source_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}
(out/'TRANSVERSE_BLOCKS.json').write_text(json.dumps(result,indent=2));print(json.dumps({a:result[a] for a in ('seconds','source_sha256','K3','K2_principal_minors')},indent=2))
