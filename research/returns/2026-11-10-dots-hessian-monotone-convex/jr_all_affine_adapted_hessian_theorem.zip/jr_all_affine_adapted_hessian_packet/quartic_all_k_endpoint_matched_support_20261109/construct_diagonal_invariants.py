"""Exact invariant grouping of the already fixed V=0 Schur, no search."""
import sympy as s,json,pathlib,time,hashlib
start=time.monotonic();out=pathlib.Path(__file__).parent
k,d,j=s.symbols('k d j');ell=3*k-1;n=k+1;m=3*k+1
a=ell/(8*n);b=ell/(2*n);c=(3*k*k+12*k+1)/(4*n)
E2=d*d+4*k*j*j;L=ell*(d+3*k*j)/m
A=6*a-L*j/E2;B=ell*(7*k+1)/(4*n*m)+L*d/(2*E2)
C=(13*k+1)/(4*n)+L*k*j/E2
v=s.Matrix([4*a*d+2*b*j,b*d+2*c*j]);f=a*d*d+b*d*j+c*j*j
detQ=s.factor(A*C-B*B)
schur=s.factor(E2*(f*detQ-(C*v[0]**2-2*B*v[0]*v[1]+A*v[1]**2)/4))
result={'detQ':str(detQ),'E2_times_full_schur_determinant':str(schur),
        'coefficient_by_d':{str(ex[0]):str(s.factor(co)) for ex,co in s.Poly(schur,d).terms()},
        'seconds':time.monotonic()-start,
        'source_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}
(out/'DIAGONAL_INVARIANTS.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
