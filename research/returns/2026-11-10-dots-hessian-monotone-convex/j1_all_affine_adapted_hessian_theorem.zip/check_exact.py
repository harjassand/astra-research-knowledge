import sympy as s, json, time, hashlib, pathlib
start=time.monotonic(); x,y,V,T,aa,dd,bb=s.symbols('x y V T aa dd bb')
a,b,c,d=s.symbols('a b c d')
u=a*a+c*c; v=b*b+d*d; j=a*d-b*c
J=s.expand((u-v+2*j)**2/s.Integer(8)+u*v/s.Integer(2)+j*j)
A={a:aa,b:bb,c:0,d:dd}; X={a:x,b:2*V,c:-4*V,d:y}
JA=J.subs(A,simultaneous=True); JX=J.subs(X,simultaneous=True)
linear=sum(s.diff(J,z).subs(A,simultaneous=True)*X[z] for z in [a,b,c,d])
full=J.subs({a:aa+x,b:bb+2*V,c:-4*V,d:dd+y},simultaneous=True)
lam=(aa*aa-bb*bb-dd*dd+7*aa*dd)/2
P=s.Poly(s.expand(full-JA-linear-lam*(x*y+8*V*V)),aa,dd,bb)
vars=[aa,dd,bb]; Q=s.zeros(3); C=s.zeros(3,1)
for i in range(3):
 e=[0]*3;e[i]=1;C[i]=P.coeff_monomial(tuple(e))
 for z in range(3):
  e=[0]*3;e[i]+=1;e[z]+=1;Q[i,z]=P.coeff_monomial(tuple(e))/(1 if i==z else 2)
M=Q.row_join(C/2).col_join((C.T/2).row_join(s.Matrix([[JX]])))
def even(p):
 p=s.Poly(s.expand(p),V);assert all(e[0]%2==0 for e,c in p.terms());return s.expand(sum(c*T**(e[0]//2) for e,c in p.terms()))
checks={}
qexp=s.Matrix([[5*V**2+3*x*x/4+x*y+7*y*y/4,V**2+3*x*x/4+7*x*y/4-3*y*y/4,V*(3*x+5*y)],[V**2+3*x*x/4+7*x*y/4-3*y*y/4,5*V**2+7*x*x/4-x*y+3*y*y/4,V*(5*x-y)],[V*(3*x+5*y),V*(5*x-y),23*V**2+(x*x+y*y)/4]])
cexp=s.Matrix([(x**3+3*x*x*y+7*x*y*y-y**3)/2+(18*x+30*y)*V**2,(x**3+7*x*x*y-3*x*y*y+y**3)/2+(30*x+2*y)*V**2,V*(3*x*x+10*x*y-y*y+124*V**2)])
checks['Q_original']=all(s.expand(z)==0 for z in Q-qexp);checks['c_original']=all(s.expand(z)==0 for z in C-cexp)
Jexp=(x**4+y**4)/8+s.Rational(7,4)*x*x*y*y+(x**3*y-x*y**3)/2+(9*x*x+30*x*y+y*y)*V*V+194*V**4
checks['JX_original']=s.expand(JX-Jexp)==0
D=x*x-y*y;K=x*y
Pdet=12*(D-s.Rational(13,12)*K)**2+s.Rational(251,12)*K*K
DQ=552*T**3+(238*x*x-273*x*y+376*y*y)*T*T/2+(128*x**4-220*x**3*y+225*x*x*y*y+80*x*y**3+124*y**4)*T/16+(x*x+y*y)*Pdet/64
checks['det_Q']=s.expand(even(Q.det(method='domain-ge'))-DQ)==0
D2=24*T*T+(22*x*x-7*x*y+28*y*y)*T/2+Pdet/16
checks['det_Q_first2']=s.expand(even(Q[:2,:2].det())-D2)==0
P0=4*(D*D+K*D/4-K*K)**2+s.Rational(11,4)*(K*D+s.Rational(28,11)*K*K)**2+s.Rational(112,11)*K**4
P2=4406*x*x-3339*x*y+6516*y*y
P4=4176*x**4-5064*x**3*y+8651*x*x*y*y-580*x*y**3+5788*y**4
P6=960*x**6-1228*x**5*y+1533*x**4*y*y+40*x**3*y**3+3377*x*x*y**4+120*x*y**5+484*y**6
P8=104*x**8-88*x**7*y-23*x**6*y*y+100*x**5*y**3+570*x**4*y**4+232*x**3*y**5+129*x*x*y**6-92*x*y**7+60*y**8
DM=14832*T**5+P2*T**4+P4*T**3/8+P6*T*T/32+P8*T/128+(x*x+y*y)*P0/512
checks['det_M']=s.expand(even(M.det(method='domain-ge'))-DM)==0
G=s.Matrix([[104,-44,-s.Rational(55,2),0,0],[-44,32,50,0,0],[-s.Rational(55,2),50,570,116,0],[0,0,116,129,-46],[0,0,0,-46,60]])
z=s.Matrix([x**4,x**3*y,x*x*y*y,x*y**3,y**4]);checks['P8_Gram']=s.expand((z.T*G*z)[0]-P8)==0
checks['Gram_left_det']=G[:2,:2].det()==1392;checks['Gram_right_det']=G[3:,3:].det()==5624
checks['Gram_left_cost']=(G[2,:2]*G[:2,:2].inv()*G[:2,2])[0]==s.Rational(3400,29)
checks['Gram_right_cost']=(G[2,3:]*G[3:,3:].inv()*G[3:,2])[0]==s.Rational(100920,703)
checks['Gram_schur']=570-s.Rational(3400,29)-s.Rational(100920,703)==s.Rational(6303710,20387)
checks['P4_Young']=4*2000*3206>5064**2;checks['P6_Young']=4*600*629>1228**2
checks['P0_uniform']=s.Rational(16851,5488)<6
checks['reserve_constant']=49152*552*194==5263589376
r={'status':'pass' if all(checks.values()) else 'fail','checks':{k:bool(v) for k,v in checks.items()},'seconds':time.monotonic()-start,'source_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}
print(json.dumps(r,sort_keys=True));assert all(checks.values())
