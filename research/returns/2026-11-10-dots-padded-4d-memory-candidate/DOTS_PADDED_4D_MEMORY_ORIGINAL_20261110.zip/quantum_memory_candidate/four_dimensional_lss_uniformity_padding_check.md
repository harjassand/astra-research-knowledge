# Focused independent check: finite-torus domination, uniform macro rules, and noise padding

Checked against standalone_padded_4d_memory_candidate.md. No fatal gap found in these three interfaces. This is not an independent check of the all-times cone/front estimates or of prior-art novelty.

## 1. Finite-torus product domination: exact formulation
For each macro block b=(z,n), let P_b be the deterministic set of primitive Poisson processes restricted to the bin whose realizations determine its good/bad test. Include every clock center whose batch can affect the finite test window and every fault center whose support touches it. The front test starts from a prescribed halfspace; the no-escape test is syntactic. Neither uses the random incoming syndrome or a random past.

Make a finite graph H on the macro spacetime slab, joining b and b' whenever P_b and P_b' overlap. The maximum degree D is bounded by a constant depending only on K, the fixed microscopic support range, and window conventions. It is independent of L,R and the horizon once R is at least the microscopic range. Increase D to at least 2. Independent Poisson increments make separate nonoverlapping time bins independent; allowing extra neighboring-bin edges is harmless.

For Y_b=1-eta_b, the whole collection outside H's closed neighborhood of b is measurable in primitives disjoint from P_b. Thus exactly

P(Y_b=1 | (Y_a)_{a outside N_H[b]}) = P(Y_b=1) >= 1-p_R.

This is stronger than, and implies, the LSS weak dependency hypothesis. Pairwise independence alone would NOT suffice; the primitive-cylinder argument gives independence from the entire outside sigma-field.

A precise available statement is Temmel, arXiv:1105.1683v3, Section 2 Eq.(4), and Section 8.3 Theorem 28, reproducing Liggett--Schonmann--Stacey Theorem 1.3 for bounded-degree graphs. For

p_R <= (D-1)^(D-1)/D^D,

the healthy field dominates iid variables of density at least

rho_D(p_R) = [1-(p_R/(D-1)^(D-1))^(1/D)]
              [1-(p_R(D-1))^(1/D)].

Therefore eta is dominated by iid bad marks with parameter delta_D(p_R)=1-rho_D(p_R), which tends to zero as p_R tends to zero. This applies directly to the finite slab graph. No infinite periodic repetition of the torus field is asserted. No independence between the iid dominating marks and the physical trajectory is needed: couple marks with eta, then extend that coupling to the physical primitives through the conditional law of primitives given eta.

The same bound works for each finite horizon with constants independent of that horizon. This is enough for the stated finite-time lifetime inequality; a single universal all-horizon coupling is not required.

Source: https://arxiv.org/html/1105.1683 . The original LSS DOI is 10.1214/aop/1024404279.

## 2. Finite-rule uniformity and non-circular parameter choice
Fix the front-time multiplier C first, and K large enough for the cone estimate. Restrict R>=max(1,r_support). Then every local macro map uses a subset of one fixed finite macro neighborhood A_K; extend missing inputs by ignored coordinates. There are at most 2^(2^|A_K|) Boolean functions on that input domain.

For every R, the OR over all good clock-realization maps therefore gives one member G_R of a fixed finite set. Its eroder proof is uniform:
- Each coordinate maximum is preserved or decreases.
- If macro input is confined to sum_i z_i>=b, every candidate output at z with sum_i z_i<=b sees an input subset of its own reference halfspace and is cleared by the good-front test. Thus the new minimum sum is at least b+1.

The second bullet must cover ALL outputs with sum_i z_i<=b, not just equality; monotonicity supplies this extension. This also makes G_R(0)=0 explicit. Finite initial sets therefore disappear after at most sum_i(max coordinate_i)-min(sum coordinates)+1 steps.

Fix a connectivity radius k covering both the neighborhood A_K and the intra-bin map. It depends on K, not R. Apply the cited contour theorem separately to every eroder on A_K that could occur, and take the minimum of its finitely many positive threshold parameters and exponent constants. If the constant-zero rule is included, its noise process is simply iid defects and can be handled by the elementary subcritical connected-animal bound. Thus there is no degeneracy hidden in the finite minimum.

A fully ordered choice is:
1. Fix microscopic support catalogue, C,K,A_K,k and dependency degree bound D.
2. Let delta_* be below all relevant finite-family contour thresholds (and below 1/2).
3. Choose p_* small enough that delta_D(p_*)<=delta_* and the LSS threshold condition holds.
4. Choose one fixed R large enough that the clock contribution to p_R is <=p_*/2.
5. Choose a_*>0 small enough that C_K a_* R^5<=p_*/2.
6. Choose gamma=a_* kappa/(2M) and epsilon_bar=gamma/4^m.

All choices precede L,T and are independent of them. Unoptimized and potentially tiny constants are not a logical gap, but do preclude a practical-threshold claim.

## 3. Padding/general-noise hypotheses
The normalized Choi proof in the standalone draft is correct. For a local HP/TA map Delta on dimension d, ||J(Delta)||op<=||Delta||diamond, J(D)=I/d^2, and gamma>=d^2||Delta||diamond ensures D+Delta/gamma is CPTP. It exactly absorbs signed differences of local engineered generators and local Hamiltonian commutators into the padded rare-event process.

Grouping smaller supports into deterministic enclosing anchor balls is valid by the triangle inequality and stability of the diamond norm under identity extension. Every original local term must be HP/TA; if a supplied decomposition does not have this property termwise, such a decomposition must first be supplied or justified. One cannot infer it solely from trace preservation of the extensive sum.

The budget must include faults of the padding implementation itself and cover the full supports of noisy syndrome guards/corrections, not merely the faces flipped. Fixed M counts every padded ball whose full syndrome-birth neighborhood meets a cell. Under the stated choice, its incident event rate is <=M gamma=a_* kappa/2.

The final cap decoder is chosen from the code geometry, not from Delta, Kraus outcomes, clocks, or fault locations. This is essential to the coherent-Kraus extension. The proof conditions on independent Poisson supports/times only; those have state-independent rates because each complete scheduled map is CPTP.

Time-independent bounded perturbations give the clean autonomous-generator statement. Deterministic measurable time-dependent bounds also permit time-dependent CPTP event maps at the same fixed clock rates. This does not automatically cover a non-Markovian environment, unbounded support tails, extra unmodeled controller Hilbert spaces, or state-dependent nonlinear dynamics.

## Result
The LSS/finite-torus, finite-family uniformity, and Choi-padding interfaces are defensible with the explicit formulations above. Recommend adding the precise dependency-graph definition, the LSS parameter/citation, and the ordered parameter selection to the standalone proof. No broadening to an unpadded or microscopic controller theorem is warranted.
