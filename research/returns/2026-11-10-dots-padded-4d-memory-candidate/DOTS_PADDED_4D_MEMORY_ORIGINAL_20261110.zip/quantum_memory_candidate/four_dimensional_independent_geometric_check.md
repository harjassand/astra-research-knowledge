# Independent geometric and quantum-transfer check

10 November 2026. Checked `standalone_padded_4d_memory_candidate.md`, Part I.3–I.9 and Part II.A, against the stated local maps and the actual Hartarsky–Toninelli Corollary 9.5. No proof-breaking counterexample found in this pass. This is not a prior-art or implementation validation.

## 1. All-times, all-input cone bound

There is a particularly direct bound avoiding a random number of sampled output times. At an output vertex v, a non-self backward dependency can arise from its own clearing clock (four predecessor choices), or one of six birth clocks at v-e_i-e_j (two predecessor choices each). Thus there are at most 16 spatial-step/clock-label choices. Every such step is from v to v-e_i for some i. Ignore self dependencies: they only delay the backward path and cannot help it escape spatially.

If ANY output v in Q is influenced from distance at least d at ANY time t in [0,B], there exists a sequence of n>=d non-self steps with strictly decreasing event times in [0,B]. For a fixed sequence of n clock labels, the expected number of such ordered distinct Poisson events is (kappa B)^n/n!, including repeated labels, by the factorial moment formula. Distinct spatial branches of a single batch cannot be concatenated at equal time because every read is pre-event. Consequently

    P(any all-times potential cone escapes) <= R^4 sum_{n>=d}(16 kappa B)^n/n!.

This bound is independent of the Boolean inputs and does not depend on realized occupancies or physical Kraus outcomes. Use d equal to the actual minimum distance from Q to the window boundary; do not silently identify a center-radius convention with a cube-distance convention. Include a fixed collar for every clock anchor whose write set intersects the window. Those geometric adjustments change K only by a fixed factor/additive constant.

This supplies the exponential estimate needed by Part I.4 with no additional event-count prefactor.

## 2. Reference-front quantifier

For output Q_z and inputs supported on macro sum q>=b with sum z<=b, their inflated micro support lies inside h(x)>=Rb, which is contained in h(x)>=R sum z. Monotonicity therefore compares to the single reference test centered at z. It clears not only outputs on sum z=b but also all outputs below b. This explicitly completes the claimed advance of the minimum diagonal coordinate.

Coordinate cap preservation remains valid for each good local map despite the occupied artificial boundary: no-escape makes its output equal to the infinite-volume evolution of the capped input. Taking the pointwise OR preserves both cap properties.

In the front recursion, define tau_v as the recursively constructed sufficient permanent-clearance time of v (and its finite backward cone above the initial boundary), rather than an unspecified global clearance time. Its lower-height predecessors use no clock at v. Independent Poisson residual waiting times then justify the last-passage domination.

## 3. Torus first-crossing witness

Use a fixed product metric on torus space times integer time, and state all range constants in that metric. Revealing a vertex joins old components, each of diameter <ell. Every old vertex in the newly formed component is within ell+k of the new vertex. When its spatial neighborhood has diameter <N/2, the local lift is unique relative to that vertex and preserves all short dependency edges.

For every occupied non-noise vertex choose the set of ALL occupied predecessors in the finite update neighborhood. Setting precisely those inputs to one is sufficient for G=1 by monotonicity; G(0)=0 ensures the set is nonempty. Their vertices occur earlier and belong to the same revealed component since k includes the update neighborhood. Recursion therefore gives a finite sufficient witness DAG inside that component. A purported non-noise leaf at the chart's bottom would contradict closure of this recursion; clean time-zero inputs are zero, so all leaves really are noise marks.

For each deterministic potential crossing vertex, define an event that such a sufficient occupied DAG/connected cluster of diameter at least ell exists inside its deterministic chart. This is a mark-only event, without conditioning on actual first crossing. Coupling its marks to infinite iid marks makes that same witness sufficient in the infinite process. Its cluster contains the fixed crossing vertex, so Corollary 9.5 applies without an additional union over roots or witnesses. A union over candidate crossing vertices gives the stated volume*time factor.

## 4. Intra-bin mapping

For each active micro cube in bin n choose a single actual occupied site/time. If its block is good, follow one occupied Boolean predecessor through the no-fault local graphical history to layer n. Such a predecessor always exists at a birth; a clearing update cannot generate occupancy. This gives an occupied macro input within K. If the block is bad, choose its forced auxiliary output at layer n+1. Hence each active cube has an image occupied auxiliary vertex displaced by at most K+O(1). Neighboring active cubes have k-adjacent images for fixed enlarged k. A connected micro syndrome therefore gives a connected image set; the spatial diameter loses at most twice the image displacement. Coincident images are harmless. This handles activity at every continuous time, not just endpoint syndrome values.

## 5. Fixed decoder and channel completeness

Choose, once and for all, a component-dependent small chart and filling; unchanged components must use identical fillings. Complete the decoder arbitrarily on all remaining syndromes, so it is a globally defined CPTP channel independent of perturbations and histories.

For a local event, every changed component before or after meets its bounded support neighborhood. If all are small, all their chosen caps lie in one larger contractible chart. The closed 2-chain cap_before + event + cap_after is then a stabilizer boundary. This includes local closed Pauli events whose syndrome does not change. The dual calculation and Pauli phases do not affect logical channels.

For a fixed good support/clock history, a local Kraus expansion and fixed final syndrome outcome yield a decoded Kraus operator equal to a scalar times identity on the logical code. The SAME cap decoder works for all expansion branches. Conditional channels are trace preserving because event locations and ideal sweep clocks have scalar total rates. Thus scalar squared norms sum to one, and the decoded conditional channel is exactly identity, even with a reference. No Pauli coefficient sum or probability union bound is introduced.

## Status

The targeted quantifier checks pass with the clarifications above. Remaining separate tasks are the bounded-degree product-domination citation/check, numerical resource estimates, physical implementation, and novelty comparison. This pass provides no basis to relabel the 4D engineered-generator result as a practical 2D/3D memory.
