# Standalone candidate theorem: padded autonomous 4D quantum memory under bounded local generator perturbations

10 November 2026. Research construction and detailed proof draft, not an independently validated publication or novelty claim.

## Main statement

On the cubical four-dimensional torus of side L, put qubits on faces and use the local primal/dual sweep generator specified below. Fix a finite interaction radius r and a catalogue of anchor balls X_v of that radius, one per lattice cell (or a fixed finite number of support types per cell). Let m bound the number of qubits in each ball and M bound the number of balls whose syndrome neighborhoods touch any cell. These constants do not grow with L.

There exist positive constants a_*, R, K, B, c, δ<1 and a fixed depolarizing padding rate γ>0, all independent of L, with the following candidate guarantee. Construct

    L_pad = L_sweep + Σ_v γ(D_(X_v)−Id).

For any local Hermiticity-preserving trace-annihilating perturbations Δ_v supported on X_v with

    ||Δ_v||diamond ≤ εbar := a_*κ/(2M 4^m),
    γ := a_*κ/(2M),

the actual generator L_pad+Σ_vΔ_v preserves clean encoded quantum information until time T with final decoded error bounded by

    p_bad(T) ≤ C0 (L/R)^4 [1+ceil(T/B)]
                  δ^[c floor(L/(1000R))].                (MAIN)

Here L is divisible by R and L/R is sufficiently large compared with K. The ideal final decoder is fixed in advance and is the SAME decoder for all perturbations. Decoded entanglement infidelity is at most p_bad(T), and decoded diamond distance from the identity logical channel is at most 2p_bad(T). The initial encoded state may be arbitrarily entangled with an external reference.

This is a deliberately padded architecture, not a statement about unpadded arbitrary noise. All local jumps, dimensions, rates and ranges are fixed independently of L. Numerical thresholds are not claimed.

## Grouping arbitrary local decompositions

If the physical perturbation is presented as Σ_Y Δ_Y over smaller supports, assign each Y deterministically to an enclosing anchor ball X_v and define Δ_v=Σ_(Y assigned v)Δ_Y. The sufficient budget is Σ_(Y assigned v)||Δ_Y||diamond≤εbar. Thus the theorem does not require padding every subset: one fixed enclosing ball per anchor suffices. Bounded-range interactions admit such a grouping with fixed m,M. A uniform global diamond norm of the extensive sum is neither required nor appropriate.

## Primitive assumptions

* Finite-dimensional face qubits on a 4D cubical torus; fixed geometry and orientation.
* Ideal syndrome-conditioned local sweep Lindblad terms, stated explicitly below.
* Deliberate local depolarizing terms on the fixed support catalogue.
* Local Markovian HP/TA perturbations with the grouped local norm bounds above. Deterministic time dependence with uniform bounds is also allowed. Non-Markovian nonlocal bath dynamics is not covered.
* Clean encoded initialization and an ideal final syndrome measurement/cap decoder.

The proof first treats a stochastic local support-event model in Part I, then establishes the reference-safe quantum transfer and exact padding reduction in Part II. The stochastic-Pauli trajectory description in Part I is a proof scaffold, not the final restriction on MAIN.

# Part I. Geometry, stochastic support histories, and finite-volume lifetime

## I.1. Ideal sweep generator

For each primal vertex w, let s denote the full incident-edge X-stabilizer syndrome. Let P_(w,s) be the projector onto that syndrome. A syndrome is trailing when no negative-coordinate incident edge is occupied. The local cycle constraint forces an even number of occupied positive-coordinate edges. If trailing, pair its 2 or 4 occupied outgoing directions in a fixed deterministic order and let U_(w,s) be the product of Pauli Z on the corresponding faces at w. If not trailing, or empty, take U_(w,s)=I.

Define jumps L_(w,s)=sqrt(κ) U_(w,s) P_(w,s), for all local syndromes s. Repeat on dual vertices with X corrections and dual syndrome projectors. The generator is the sum of dissipators

    D[L](ρ)=LρL†−{L†L,ρ}/2.

For each vertex, sum_s L†L=κ I, so the jump interpretation is one rate-κ clock followed by the syndrome-selected local operation. Only finitely many local projectors and faces occur. The dual construction is the same on dual cells. A Z correction preserves every Z-check outcome, and an X correction preserves every X-check outcome. Thus the two syndrome processes decouple conditional on the common stochastic Pauli history, even when faults correlate them.

Add noise jumps sqrt(λ_a) P_a, with P_a a Pauli supported in a ball of fixed radius r0 and total rates involving any fixed cell bounded by λ. One may absorb the fixed r0 into geometric constants and the block halo.

Starting from a clean code state, every trajectory is a Pauli frame applied to that state. Stabilizer projectors do not measure the encoded information. The no-jump evolution contributes only scalar normalization because the sums of L†L and noise P†P are scalar. Consequently syndrome arguments apply to arbitrary encoded information, including entanglement with a reference.

## I.2. Exact pathwise syndrome envelope

Let D_v be a Boolean upper envelope of syndrome-vertex occupancy. At each rate-κ clock at w, use ALL pre-jump values to perform the simultaneous monotone batch

    D_w := D_w AND (OR_i D_(w−e_i));
    D_(w+e_i+e_j) := D_(w+e_i+e_j)
                    OR (D_(w+e_i) AND D_(w+e_j)),  i<j.

Other sites are unchanged. A Pauli noise event forces D=1 at all syndrome vertices in its bounded neighborhood.

This dominates actual occupancy pathwise. If w has no occupied envelope predecessor, the actual syndrome at w is either absent or trailing, and the sweep clears it. The intermediate corners of every applied face were already occupied. A newly occupied high corner has both required pre-jump intermediate corners. All six possible births are retained as ONE correlated batch. No independence of births is used.

Each map is monotone. It cannot increase any coordinate maximum of a finite occupied set: every new high corner has a parent attaining its value in each coordinate. Birth dependencies and the root-death dependencies point only to v−e_i; all inputs are pre-jump. This strict chronological interpretation is important for shared-clock bounds.

The construction concerns syndrome occupancy, not raw Pauli support. Stabilizer-equivalent errors need not physically disappear.

## I.3. Clean-front service

Start from the occupied halfspace h(x)=sum_i x_i≥0. Sites below it stay empty. Let τ_v be the time by which all sites of height at most h(v) in v's backward cone have permanently cleared. A sufficient clearing recursion is

    τ_v ≤ max_i τ_(v−e_i) + E_v,     E_v ~ Exp(κ).

After all predecessors are permanently empty, births at v are impossible; the next clock at v clears it. Because predecessors are strictly lower in h, their clearing construction does not use v's clock. Poisson memorylessness supplies the required independent exponential increments in this sufficient last-passage construction.

To clear the origin macro cube [0,R−1]^4 it suffices to clear at most 4R layers. A union bound over sites and directed paths, followed by the exponential moment at κ/2, gives

    p_front ≤ R^4 8^(4R+1) exp(−κB/2).

Set B=CR/κ with a fixed C>8 log 8; C=40 is one conservative choice.

## I.4. State-independent finite-range good blocks

Partition space into cubes Q_z=Rz+[0,R−1]^4 and time into bins of length B. Use a core local window of radius KR around each output cube. Add a fixed primitive collar large enough to contain every clock anchor whose batch writes a core vertex, and every fault-support anchor that can affect its syndrome neighborhood (at least two lattice steps for the sweep, enlarged by the fixed fault/check radius). All block events are functions of primitive marks in this enlarged window; constants below absorb the collar. A good block requires:

1. No POTENTIAL backward dependency path from any point and any time in that output cube/bin reaches the window boundary. This includes all syntactic read/write dependencies, not merely dependencies realized by the current syndrome.
2. The reference halfspace h(x)≥R sum_i z_i, restricted to the local window and evolved with fixed occupied exterior boundary, clears the output cube by the end of the bin.
3. No physical fault occurs in the full local space-time window.

The finite-window front test agrees with the infinite halfspace test whenever no escape occurs. Therefore its extra failure probability is bounded by the infinite-front failure plus the cone-escape probability; it does not import outside randomness into a block definition.

A dependency path is traced from POST-event output to PRE-event input. Even when one clock writes several corners, a path cannot traverse that same batch repeatedly at zero elapsed time. Clock-anchor collars ensure that every transition inspected before a path hits the core boundary is determined by the listed local primitive marks.

The no-escape condition must cover intra-bin activity, not only the endpoint. It is measurable using clocks in the finite window, stopping potential paths at the boundary. One can impose an arbitrary fixed exterior Boolean boundary when computing the local map; on the good event it cannot affect the output for ANY input.

For a fixed ancestral path, simultaneous batches use pre-jump values, so successive events on that path have strictly decreasing times. Each spatial dependency step has at most four possible directions and at most four relevant clock labels per direction. A factorial-moment bound gives the conservative endpoint estimate

    sum_(n≥KR) (16κB)^n/n!.

For all-times coverage, a backward path starts either at a time-zero output value or just after an update affecting an output vertex. Count the latter by Poisson factorial moments (equivalently a Campbell–Mecke insertion of its start mark), not by declaring its random count independent of the path. The expected number of starts is O(R^4(1+κB)); the strictly ordered ancestral n-tuples have time-volume B^n/n!. This introduces only a polynomial factor in R, with constants depending on fixed K,C. Taking K sufficiently larger than C (for example larger than 32eC, after accommodating window conventions and r0) makes this bounded by poly(R) exp(−c1 R). No independence between overlapping paths or batch births is assumed.

The bad-block field has fixed finite dependency range O(K) in macro coordinates and time range one bin, because its defining primitive clocks and faults are confined to the window. Its marginal obeys

    p_R ≤ poly(R) exp(−c2 R) + C_K (λ/κ) R^5.           (2)

The fault term uses the full spatial volume O((KR)^4) and duration O(R/κ), not just a rail length or one syndrome site.

Checkpoint: constants in the all-times cone estimate should be written out if numerical thresholds are wanted. Only a polynomial prefactor and an exponential-in-R tail are needed here. The precise finite spatial neighborhood can be enlarged by fixed factors without changing the argument.

## I.5. A single deterministic coarse eroder

For each good local clock realization, inflate macro input bits to full micro cubes, evolve the envelope, and OR the micro output over Q_0. This is a finite-range monotone Boolean function of macro input bits. Define G to be the pointwise OR over ALL such good functions. Different output sites need not choose compatible clock realizations: the resulting rule is an upper envelope, not a claimed common physical realization.

G is deterministic, translation-invariant and monotone, with a fixed macro neighborhood depending only on K. It has two uniform properties:

* Coordinate caps do not expand: inputs contained in z_i≤a_i give outputs contained there.
* Diagonal minimum advances: inputs in sum_i z_i≥b give outputs in sum_i z_i≥b+1.

For the second property, at an output z with sum_i z_i=b, inflated inputs lie in the translated micro halfspace h≥Rb. The good front event clears Q_z. For an output with sum_i z_i<b, the inflated input support is a subset of the reference halfspace h≥R sum_i z_i as well. Monotonicity therefore clears those outputs too. This below-boundary comparison is necessary because inflating cubes can otherwise move the rounded macro diagonal. Only ONE reference halfspace test per translated output is needed; all offsets and lower output diagonals follow by translation and monotonicity. Taking the OR over good histories preserves both properties.

If initial finite input D lies in z_i≤a_i and sum_i z_i≥b, then G^n(D) lies in those caps and sum_i z_i≥b+n. It is empty once n>sum_i a_i−b. Thus G is an eroder, with a linear clean finite-seed erosion bound.

Writing η_(z,n) for the bad-block indicator yields, pathwise,

    D_macro(n+1,z) ≤ G(D_macro(n))_z OR η_(z,n).

Use the bounded-degree form of Liggett–Schonmann–Stacey domination. Form a graph whose vertices are macro blocks and whose edges join blocks with overlapping defining primitive cylinders, INCLUDING the clock/fault-anchor collars. Let D≥2 bound its maximum degree, uniformly in torus size and finite time horizon. A block’s primitive randomness is independent of the entire sigma-field generated by all nonneighboring blocks, so its healthy indicator has conditional probability at least 1−p_R given that sigma-field.

The precise bounded-degree theorem, reproduced as Theorem 28 of Temmel, arXiv:1105.1683v3 §8.3 (from LSS Theorem 1.3), gives iid BAD domination with

    δ_D(p) = 1 − [1 − (p/(D−1)^(D−1))^(1/D)]
                    [1 − (p(D−1))^(1/D)],

provided p≤(D−1)^(D−1)/D^D. Thus η can be coupled coordinatewise below iid ξ of parameter δ_D(p_R), tending to zero with p_R. This applies directly to the finite torus × finite-horizon dependency graph: no infinite periodic repetition or boundary-independence assumption is used. The iid marks need NOT be independent of the physical trajectory: coordinatewise domination and deterministic recursion from zero suffice.

There is an important non-circularity point. G can change with R. Fix K first. There are only finitely many Boolean functions on the fixed macro neighborhood, hence only finitely many possible eroders G obtained here. Take minima of the positive contour constants and thresholds over this finite family. Then choose R large enough to suppress the clock term in (2), and finally λ/κ small enough to suppress its fault term. This gives a uniform existential threshold.

## I.6. The external spacetime-cluster theorem used

Hartarsky–Toninelli, Kinetically constrained models out of equilibrium (2024), Corollary 9.5:
https://arxiv.org/html/2212.08437

For an attractive eroder with sufficiently small independent deaths, its stationary upper-invariant trajectory has exponentially small fixed-range-connected zero clusters. Complement G so that healthy=1. For every fixed connectivity radius k there exist c,δ0>0 such that the maximal connected error cluster A through a prescribed space-time point obeys

    P(diam A≥ℓ) ≤ δ^[c(ℓ+1)] .                         (3)

Hypotheses checked: finite Boolean neighborhood, deterministic translation-invariant rule, monotonicity, eroder property, iid marks, and clean initialization. A process begun clean at any finite time is dominated by the stationary low-error process constructed with marks extending to negative time. This initialization domination is used only on the infinite lattice; no torus stationary-state assertion is made.

The published proof uses bounded-range Toom contours and disjoint decorated-set selection, hence counts distinct noise sinks rather than independently charging one old fault repeatedly. We use (3), not a fresh fault charge at every scale. The entire coarse reduction is performed once at fixed R.

## I.7. Finite-torus transfer without wrapping the whole past

Let N=L/R and choose k larger than both G's update range and the intra-bin mapping range below. Consider the auxiliary iid-mark CA on the finite N-torus, begun identically zero (no errors). Reveal its occupied space-time vertices chronologically, with a fixed spatial tie order in each time slice.

Stop when a k-connected component first reaches diameter ℓ. It was formed by adding one vertex whose neighboring old components all have diameter below ℓ. Every vertex in the merged component is within ℓ+k of the new vertex, so the whole component has diameter at most 2ℓ+2k. Choose 4(ℓ+k)<N; then the component has a single local Euclidean chart about the new vertex.

Every occupied non-fault vertex has a finite occupied-input witness for G=1 in the previous time slice. All those predecessors have already been revealed and are k-neighbors, hence belong to the same component. Iteration gives a finite sufficient witness DAG entirely inside the crossing component. Its leaves are iid noise marks, because the initial state is zero. No assumption about the size of the unconstrained full backward cone is needed.

For any deterministic candidate crossing site/time, take a deterministic space-time chart of radius 2ℓ+2k about it. Couple torus iid marks in this chart to independent infinite-lattice marks there, extending independently outside. The event that a sufficient witness cluster of the specified size exists inside the chart depends only on those marks and implies an occupied cluster of at least the same diameter in the infinite process initialized clean before the chart's lower boundary. Infinite stationary domination and (3) bound its probability by δ^[c(ℓ+1)]. One does not condition on the random first-crossing event.

A union bound over candidate sites and time layers gives

    P(first large auxiliary cluster by layer n)
       ≤ N^4(n+1) δ^[c(ℓ+1)].                         (4)

This is valid for arbitrarily long finite time horizons. It avoids identifying torus noise copies at repeated spatial windings, or coupling a whole long-time stationary trajectory to an infinite one. A second route uses the published zero-contained explanation/contour construction, but is unnecessary for (4).

## I.8. Intra-bin transient checkpoint

Endpoint-only suppression is not enough: a large loop might be born and disappear during a bin. The all-times potential-cone event in the good-block construction fixes this.

If a good output cube contains syndrome activity at any time in a bin, tracing an actual Boolean ancestor reaches an occupied macro INPUT cube within distance K. If the output block is bad, its auxiliary OUTPUT bit is forced occupied by ξ. Thus every active micro cube in that bin maps to an occupied auxiliary site in time layer n or n+1, within spatial distance K+O(1). Adjacent active cubes map to sites within distance 2K+O(1). Choose a fixed k, for example any sufficiently enlarged 4K+10 after fixing norm conventions, to connect all images.

Therefore a connected actual syndrome component of macroscopic spatial diameter produces a k-connected auxiliary space-time component of comparable diameter, up to a 2K+O(1) additive loss. Before the crossing in (4), every actual syndrome component at EVERY continuous time fits a chart of diameter at most R(ℓ+2K+O(1)). Take ℓ=floor(N/1000) and N sufficiently large compared with K so that this is below L/100. Constants can be decreased further without affecting exponential scaling.

## I.9. Homology and the final decoder

Fix the decoder on ALL syndromes before running the process. On syndromes with only small components, use the componentwise construction below. On any other allowed syndrome, choose an arbitrary predetermined Pauli recovery with that syndrome, for example the lexicographically first solution of the stabilizer equations. Follow it by the fixed code-space identification. This defines a trace-preserving syndrome-measurement/recovery channel on the entire physical Hilbert space, including bad histories; no success postselection is used.

For each small connected syndrome component, choose a deterministic 2-chain filling in a contractible cubical box containing that component. Such a filling exists because its edge syndrome is a closed 1-cycle and the box has trivial first homology. Choose each small cyclic coordinate interval by a fixed tie rule, then choose a filling by a fixed finite linear-algebra/lexicographic rule within that box. These choices depend ONLY on that component, not on the whole syndrome, the current time, event history, or other components. Hence an unchanged component keeps literally the same cap even when unrelated components appear or disappear. Use this deterministic choice of the small torus chart and filling throughout. Let C(σ) be the sum of those caps.

At any bounded-support Pauli event e, including an engineered correction, σ changes to σ+∂e. Components untouched by the event keep identical caps. If all components before and after the event are small, then

    C(σ) + e + C(σ+∂e)

is a closed 2-chain supported in a contractible chart around the event and all touched components. Each touched component meets the bounded event neighborhood, and its cap lies in its small local box, so their union still lies in a contractible chart for the chosen size margin. Every closed 2-chain there is a stabilizer boundary. Hence the decoded homology class cannot change at this event.

Starting clean and inducting over events proves zero decoded logical Z action until a macroscopic primal syndrome component appears. The identical dual argument proves zero decoded logical X action. Correlation between the sectors does not matter: union bound their failure probabilities. Composing the final X and Z cap corrections changes at most a Pauli phase. The stated exponential-lifetime bound follows from (4), the intra-bin mapping and the two-sector union bound.

The cap argument is specific to loop syndromes: a singleton point charge does not admit a local cap. It therefore cannot silently solve the point sector of a 3D toric code.


# Part II. Quantum channel transfer and padded local perturbations

## A. Uniform support-history quantum transfer

### A1. Event model

Keep the ideal syndrome-conditioned sweep generator from Part I. Replace Pauli faults by independent Poisson event processes on a fixed catalogue of bounded supports X. An event on X applies an arbitrary local CPTP map Φ_X, at a state-independent rate γ_X. Its generator is γ_X(Φ_X−Id). If Φ_X has Kraus operators K_(X,a), jumps sqrt(γ_X)K_(X,a) satisfy sum_a J_a†J_a=γ_X I. Consequently event times and support labels can be sampled independently of the quantum state; conditional on that history, one applies the indicated CPTP maps.

Let every support event force the Boolean envelope to 1 at EVERY syndrome vertex that could be affected by any Pauli operator supported in X. This is a fixed bounded neighborhood. No Kraus outcome or observed syndrome is used to decide whether a history is geometrically good. The same clock/support history defines both sector envelopes.

### A2. Simultaneous Pauli-branch domination

Fix a finite event-support history and correction-clock history. Expand each local K_(X,a) in the finite Pauli basis on X. Expand the resulting product of fault Kraus operators and ideal syndrome instruments U_sP_s. On an encoded input, a Pauli word has a definite syndrome. Each P_s either annihilates that branch or acts as identity on its syndrome sector; the following U_s is another bounded-local Pauli. Thus every surviving expansion term is an allowed Pauli-error history with exactly the prescribed support events.

The support-only envelope dominates all such histories simultaneously, using the same correction clocks. This is a deterministic statement, not a union bound over Pauli expansions. The number and coefficients of expansion terms do not enter the fault probability.

### A3. A common final decoder, including coherences

Use the deterministic final decoder from Part I: measure the final syndrome and cap each connected small component by the fixed local 2-chain choice, in both primal and dual lattices. For every Pauli branch of a good support history, the event-by-event cap identity proves that this SAME decoder returns the encoded state with only a scalar Pauli phase.

Fix all Kraus labels of the support channels, all syndrome-instrument outcome labels, and the final measured syndrome label. The corresponding decoded Kraus operator restricted to the code is a sum of scalar multiples of the identity logical operator. It is therefore itself a scalar multiple of that identity. Equivalently, if syndrome and environment registers are retained, the restricted decoded evolution has the form I_logical tensor V_environment.

There is no assumption that the physical state is a classical mixture of Paulis: the argument explicitly retains coherent sums within each Kraus operator. Trace preservation of the conditional channel makes the squared scalar coefficients sum to one. Hence every geometrically good support history yields exactly the identity channel on the logical subsystem, including arbitrary entanglement with an external reference.

### A4. Consequence

The full dynamics is a positive mixture over state-independent support/clock histories. Its bad-history probability is bounded by precisely the same contour argument, with local fault intensity

    λ_event = sup_v sum_(X: dist(X,v)≤r_check) γ_X,

up to fixed neighborhood-counting conventions already absorbed into constants. Two-sector correlations within one Φ_X cause no difficulty: both envelopes are seeded and their bad-event probabilities are union-bounded.

Thus the exponential-lifetime bound of Part I holds for arbitrary local CPTP channel events, without a Pauli-term-count penalty. Decoded entanglement infidelity is ≤p_bad, and diamond-norm error is ≤2p_bad.

## B. Deliberate depolarizing padding

### B1. Exact local identity

Let X have Hilbert-space dimension d_X. Define complete local depolarization

    D_X(A) = Tr(A) I_X/d_X.

On the full lattice this map is tensored with identity on the complement. Let Δ_X be a local Hermiticity-preserving, trace-annihilating superoperator, and suppose

    ||Δ_X||_diamond ≤ ε_X.

Choose a fixed padding rate γ_X satisfying

    γ_X ≥ d_X² ε_X.                                      (B1)

Then

    Φ_X = D_X + Δ_X/γ_X

is CPTP. To verify, use normalized Choi matrices. J(D_X)=I_(d_X²)/d_X². Hermiticity preservation makes J(Δ_X) Hermitian; diamond-norm domination gives ||J(Δ_X)||_op≤ε_X. Hence J(Φ_X)≥0 under (B1). Trace annihilation makes Φ_X trace preserving.

It follows EXACTLY that

    γ_X(D_X−Id) + Δ_X = γ_X(Φ_X−Id).                     (B2)

No Trotter approximation, quasi-probability interpretation, signed contour sum or fictitious positive mixture is used. This deliberately ADDS depolarization to the architecture before treating Δ_X as an unknown perturbation.

### B2. Uniform perturbed architecture

Specify a finite-range support catalogue and perturbation budgets εbar_X in advance. Construct

    L_pad = L_sweep + sum_X γ_X(D_X−Id),

with fixed γ_X≥d_X² εbar_X. For every collection of local HP/TA perturbations Δ_X obeying ||Δ_X||diamond≤εbar_X, the actual generator

    L_actual = L_pad + sum_X Δ_X

is, by (B2), an ideal sweep plus positive Poisson CPTP events. The proof in Part A applies uniformly to this entire perturbation class.

Although individual Δ_X need not be completely positive generators, the padded local term is a legitimate Lindbladian. This is an open local-norm stability neighborhood around the deliberately padded generator, not a claim of stability of the unpadded architecture.

## C. Explicit dimension-dependent tolerance

Let q be the on-site dimension, m the maximal number of sites in a permitted support, and M the maximal number of permitted supports whose fault neighborhoods touch any given lattice cell. Then d_X≤q^m.

Suppose Part I allows total local event rate at most a_* κ, where a_*>0 is its existential constant. For a uniform support budget εbar, choose fixed

    γ = a_* κ/(2M),
    εbar = γ/q^(2m) = a_* κ/[2M q^(2m)].                (C1)

Then every support has enough Choi padding, while total padded local event intensity is at most a_*κ/2. The remaining half can accommodate additional separately modeled local channel events, or simply provide slack. For qubits q=2, the dimension factor is 4^m.

A nonuniform sufficient condition is to choose γ_X≥d_X² εbar_X with

    sup_v sum_(X near v) γ_X < a_* κ.

The constants are independent of L but can be extremely small. In particular, this construction does not produce a practical numerical noise threshold.

## D. Concrete Hamiltonian/Lindblad perturbations

For a bounded local Hamiltonian term H_X,

    Δ_X(ρ)=−i[H_X,ρ],        ||Δ_X||diamond≤2||H_X||.

For a local dissipator with jump A,

    Δ_X(ρ)=AρA†−{A†A,ρ}/2,  ||Δ_X||diamond≤2||A||².

Consequently a sufficient local budget for a Hamiltonian plus local dissipators is

    2||H_X|| + 2 sum_a ||A_(X,a)||² ≤ εbar_X.

Differences between ideal and perturbed local dissipators are also HP/TA local maps and can be bounded directly in diamond norm. The fixed catalogue must contain their full supports, including any finite range enlargement. Arbitrary extensive noise with no uniform local bound is not covered.

Time-independent Markovian perturbations are the clean statement. Deterministic time-dependent local HP/TA perturbations with uniform bounds can likewise use time-dependent CPTP maps at fixed Poisson rates. An unrestricted non-Markovian bath or history-dependent nonlocal channel is not covered.


# Part III. Status, checkpoints and significance

## What is constructed

An explicit fixed-range 4D generator; exact asynchronous batch syndrome domination; a fixed-block deterministic eroder; a finite-volume all-times error-history bound; a common cap decoder; a reference-safe arbitrary-CPTP event argument; and an exact local Choi-padding reduction from bounded HP/TA perturbations. General local Hamiltonian and Lindblad perturbations are included only through the padded reduction and their stated local norm budget.

## Proof checkpoints

1. The bounded-degree form of Liggett–Schonmann–Stacey domination is used on the finite macro dependency graph, uniformly in torus size. Its conditional-outside-neighborhood hypothesis holds: primitive clock/fault cylinders are disjoint beyond a fixed neighborhood, so a block indicator is independent of the full collection outside it. Finite graphs are a special case of the countable bounded-degree graph formulation. This is not an application to a periodically repeated infinite random field.
2. All-times cone counting uses chronological pre-event/post-event batch dependencies. Shared clocks never justify independent births, nor may a path traverse a simultaneous batch repeatedly at zero time. The proof needs only an exponential tail times a polynomial prefactor; those constants have not been optimized.
3. First-cluster transfer uses sufficient occupied witnesses contained in a small deterministic chart, not a claimed equality of torus and infinite trajectories over their whole past. Clean initialization prevents unexplained initial-boundary leaves.
4. The radius K is fixed before R. Uniform contour thresholds over the finite family of possible macro Boolean rules remove a potential circular choice of R.
5. Arbitrary CPTP branch coherence is handled with the SAME final decoder and scalar logical Kraus restrictions, not a probability union bound over Pauli terms.

## Remaining gap status

No additional unproved physical service, noisy-record or global-clock lemma is being assumed in MAIN: its engineered local Lindbladian is the primitive model. The construction is nevertheless a detailed proof draft requiring independent checking of the geometric/coarse-graining lemmas and their combination. A microscopic implementation of these ideal multi-body dissipators using explicitly noisy gates/controllers is NOT supplied. Numerical performance and prior-art novelty have not been established. These limitations must not be described as a completed practical North Star.

## Why this does not yet solve 3D

The key local cap invariant requires every small connected syndrome component to have a local filling. Both syndrome sectors of the face-qubit 4D toric code are loops and satisfy that condition. In the analogous 3D toric code one sector consists of point charges; an individual charge has no local cap, and two distant charges require a pairing decision. Therefore replacing 4 by 3 in the proof is invalid.

A 3D extension needs an independently proved fixed-resource asynchronous point-sector eroder or another code/decoder whose BOTH sectors satisfy a comparable locally fillable syndrome-history invariant. Gauge redundancy or single-shot syndrome estimation alone does not supply that decoder. Fracton codes change the mobility and pairing problem but do not automatically make each connected syndrome component locally neutral. These are precise construction targets, not reasons to assert an impossibility theorem for all 3D autonomous memories.

## Sources and novelty boundary

The finite-graph LSS formulation and explicit parameters are available in Temmel, *Shearer’s measure and stochastic domination of product measures*, arXiv:1105.1683v3, §2 and §8.3 Theorem 28: https://arxiv.org/abs/1105.1683 .

Hartarsky–Toninelli, Kinetically constrained models out of equilibrium, Corollary 9.5 (2024): https://arxiv.org/html/2212.08437 . Liggett–Schonmann–Stacey, Domination by product measures, Annals of Probability 25 (1997), 71–95. The specific role of each imported theorem is stated in Part I. Four-dimensional Toom-style quantum memories have substantial prior art. This document does not claim that padding, local sweep correction, or 4D error suppression is individually new. Establishing whether their combination is a substantive new result requires comparison to the exact existing autonomous-memory and robustness theorems.

### Fixed-width compactification is not a 3D extension

Setting the fourth torus circumference to a fixed width w leaves noncontractible syndrome loops winding that short circle. A membrane extending in a long direction and the fourth direction has two such boundary loops. Each has O(w) size, yet cannot be capped inside a contractible box. Seen in three dimensions they are separated point charges. Thus the local-cap hypothesis fails at constant-size components; the large-component failure criterion no longer applies. Increasing w with L restores resources that are not fixed-width 3D local hardware.

### Updated direct prior-art comparison

Drechsler–Oreg–Aharonov, *Autonomous Quantum Memories from Classical Stochastic Processes*, arXiv:2610.05589 (October 2026), proves quantum/classical reductions and a 4D Toom memory in the synchronous/PCA setting, with a Floquet Lindbladian implementation. Its discussion explicitly identifies asynchronous continuous-time classical memory for that Toom model as open. Therefore the candidate's genuinely time-independent asynchronous envelope/coarse-eroder construction is a potentially distinct contribution; this needs comparison of the exact local sweep rule, not an assertion that every version of the cited Toom rule has been solved. The padded local-generator robustness reduction is another separate component whose prior art must be checked.
