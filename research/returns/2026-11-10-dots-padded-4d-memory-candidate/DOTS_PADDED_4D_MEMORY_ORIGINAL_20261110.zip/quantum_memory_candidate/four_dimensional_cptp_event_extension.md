# Extension to bounded-local arbitrary CPTP Poisson events

Research lemma, 10 November 2026. This extends the scoped 4D ideal engineered-jump construction; it does not provide a noisy-controller implementation or cover arbitrary Hamiltonian perturbations.

## Noise model

Replace a Pauli jump generator by a sum of terms lambda_a (Phi_a - Id), where each Phi_a is an arbitrary CPTP channel supported in a ball of fixed radius r0. The total rate involving each fixed physical cell is bounded by lambda. Primitive event locations are independent Poisson processes, or have the same stipulated local-stochastic location domination. Within one event the channel may have arbitrary correlated/coherent action on its bounded support. All event clocks are independent of the encoded input.

This is a valid Lindbladian: if Phi_a(rho)=sum_j K_aj rho K_aj^dagger, use jumps sqrt(lambda_a) K_aj. Since sum_j K_aj^dagger K_aj=I, the total rate for event a is lambda_a, independent of state, and its nonselective update is precisely Phi_a.

## Common pathwise envelope

Condition on the locations/times of engineered updates and fault events, not on Kraus outcomes. At a fault event, force both primal/dual Boolean envelopes to 1 throughout the bounded syndrome neighborhoods of the event support. At an engineered update use the exact simultaneous monotone T_w batch already specified in the main draft.

Expand every local fault Kraus operator in the finite local Pauli basis. Each Pauli changes syndrome only in the forced neighborhood. The main draft's T_w domination holds for EVERY possible syndrome branch. Hence the SAME location-dependent envelope dominates all Kraus/Pauli branches simultaneously. The block bad-event probability and finite-torus cluster estimate are unchanged except constants for r0.

## Logical factorization on a good envelope history

For every syndrome sigma with small components choose the same local-cap correction C(sigma) as in the main draft. Define V_sigma=C(sigma)V, where V is a code encoding isometry; Pauli phases/order conventions may be fixed arbitrarily but consistently. The ranges of V_sigma are orthogonal syndrome sectors. Extend these to a global syndrome-decoding isometry W by arbitrary choices outside the good set.

Let E be any Pauli supported in the bounded event ball, taking sigma to sigma'. If the before/after envelope is good, all touched components are small. The cap argument gives

    V_sigma'^dagger E V_sigma = alpha_(sigma',sigma,E) I_logical,

with a scalar Pauli phase, or zero if E does not map those syndromes. The closed primal/dual cap differences lie in contractible charts, so cannot be logical operators. This holds separately in each sector; opposite Pauli phases are irrelevant.

For a local Kraus operator K=sum_E c_E E, linearity therefore gives

    V_sigma'^dagger K V_sigma = m_(sigma',sigma,K) I_logical.

Thus in decoded coordinates each Kraus operator on the reachable good subspace is I_logical tensor M_syndrome. The engineered U_s P_s Kraus operators satisfy the same property, using their actual envelope update. Multiplication and summation preserve this factorization. No assumption that the state is syndrome-diagonal is needed.

Starting from an arbitrary code state entangled with an external reference, the decoded logical-reference state is therefore EXACTLY unchanged on every good location history, even for coherent fault Kraus operators and interference between syndrome branches. No sum of absolute Pauli coefficients and no exponential fault-path multiplicity is incurred.

## Error bound

The good/bad location event depends only on primitive clocks, not on logical information. Let p_bad be the probability bound from the main draft, unioned over primal and dual sectors. After ideal final cap decoding, the logical channel is

    (1-p_bad) Id + p_bad Psi_bad

for some CPTP Psi_bad (or the analogous expression using the actual bad probability bounded by p_bad). Hence worst-case entanglement infidelity <=p_bad and diamond distance from Id <=2 p_bad. The same bound can hold uniformly before a finite horizon via the already-defined no-large-cluster event.

## Scope boundaries

This does NOT assert that every bounded local Lindblad perturbation has the form lambda(Phi-Id). In particular generic coherent Hamiltonian drift is not included by this argument. Arbitrary ongoing controller-state corruption is not included unless an explicit physical implementation shows it is a bounded-local channel event on the modeled qubits with no unmodeled persistent control effect. The correctness of the underlying occupancy envelope, contour theorem, and finite-torus transfer remains a prerequisite.
