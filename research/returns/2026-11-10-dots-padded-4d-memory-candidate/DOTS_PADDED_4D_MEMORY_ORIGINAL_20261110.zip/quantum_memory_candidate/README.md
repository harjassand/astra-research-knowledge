# Padded 4D autonomous quantum memory: candidate proof packet

Date: 10 November 2026. Status: **complete proof candidate, not independently certified or peer reviewed**. It is supplied as research capital, not as an accepted theorem, a verified civilization-changing result, or completion of the North Star.

## Claimed mathematical result

The main manuscript proposes a fixed-range, time-independent Lindbladian on a four-dimensional toric code with deliberately added local depolarizing padding. For sufficiently weak bounded local generator perturbations, it claims an existential exponential-in-linear-size storage lifetime, with clean encoded initialization and a fixed ideal final decoder. The noise model includes local coherent/nonunitary perturbations only under the stated decomposition, support and norm bounds, and only around the padded architecture.

This is **not a physical three-dimensional machine**. Constants and threshold are existential and potentially extremely small. The packet does not establish a practical hardware implementation, efficient noisy initialization or readout, universal computation, or a 2D/3D geometric memory threshold.

## Contents

- `standalone_padded_4d_memory_candidate.md`: main integrated proposed theorem and proof; start here.
- `four_dimensional_async_loop_memory_theorem.md`: underlying stochastic-Pauli construction and proof.
- `four_dimensional_cptp_event_extension.md`: extension to local CPTP Poisson-event histories.
- `depolarizing_padding_general_noise_bridge.md`: exact local Choi-padding reduction.
- `finite_torus_first_cluster_transfer.md`: finite-volume first-crossing transfer.
- `four_dimensional_independent_geometric_check.md`: targeted independent check, with limitations.
- `four_dimensional_lss_uniformity_padding_check.md`: separate targeted check of domination, parameter ordering and padding.
- `proof_checks/check_4d_sweep_envelope.py` and its JSON result: exhaustive finite microscopic sweep/envelope check. Run with Python 3. This does not verify the global proof or its imported theorems.

## Review status and important comparison

Two focused checks found no breaking flaw in the portions they examined, and a finite local enumeration passed. These are not a complete independent line-by-line verification. The proof relies on the cited Liggett–Schonmann–Stacey domination and Hartarsky–Toninelli eroder/space-time-cluster results, and further critical review of all applications is needed. Novelty has not been established.

Drechsler, Oreg and Aharonov, arXiv:2610.05589, already prove related 4D synchronous/Floquet quantum-memory results and discuss the time-independent case as open. The proposed contribution here is the specific time-independent asynchronous sweep/coarse-eroder construction and padded perturbation bridge, if correct and distinct; do not state that this prior work proved a fully autonomous 4D theorem or that this packet resolves the exact previously studied Toom model without rule-by-rule comparison.

## Suggested next step

Have an independent mathematical researcher review the manuscript end to end, especially microscopic-to-macro domination, finite-torus lifting, intra-bin activity, common quantum decoder, local-noise padding, and comparison to prior art. Continue the separate 3D construction; fixed-width compactification of this 4D proof does not supply it.
