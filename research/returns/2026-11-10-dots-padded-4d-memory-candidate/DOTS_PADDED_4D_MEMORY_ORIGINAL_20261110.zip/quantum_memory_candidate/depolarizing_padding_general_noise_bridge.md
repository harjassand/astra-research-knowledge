# Exact depolarizing-padding bridge to arbitrary local generator perturbations

Status: elementary exact construction. It modifies the proposed autonomous architecture by intentionally adding weak, local depolarization. It does NOT show the unpadded architecture tolerates general signed perturbations. Its memory consequence is conditional on the uniform-support arbitrary-CPTP-event threshold and fixed-decoder proof.

## Local lemma
Let B have Hilbert dimension d, and let D_B be its completely depolarizing channel, D_B(rho)=Tr(rho) I/d. Let Delta be any Hermiticity-preserving, trace-annihilating linear map on B, with diamond norm at most epsilon (units inverse time). Choose gamma >= d^2 epsilon. Then

Phi = D_B + Delta/gamma

is CPTP, and exactly

gamma(D_B-Id)+Delta = gamma(Phi-Id).

Proof: use the normalized Choi operator J(M)=(M tensor Id)(|Omega><Omega|), |Omega>=d^(-1/2) sum_i |ii>. J(D_B)=I/d^2. Hermiticity preservation makes J(Delta) Hermitian. By the diamond bound, ||J(Delta)||_infinity <= ||J(Delta)||_1 <= epsilon. Hence J(Phi)>= (1/d^2-epsilon/gamma)I>=0. Trace annihilation gives the channel trace-preservation constraint. The generator identity is algebraic.

In particular Delta need NOT be CP, a Lindblad generator, or a positive-probability fault mechanism. A local Hamiltonian commutator is covered. So are signed differences between actual and intended engineered attempt channels.

## Uniform architecture
Fix bounded-radius balls B_x covering every admitted perturbation support, with one ball per lattice cell or a fixed finite number per cell. Their size, dimension d_x<=d_max, and overlap multiplicity nu are constants independent of memory size.

Assign each admitted local perturbation Delta_X to a fixed anchor x with X subset B_x. Extend it by the identity outside X and define Delta_x=sum_{X assigned x} Delta_X. Assume every Delta_X is HP/TA and

sup_x sum_{X assigned x} ||Delta_X||_diamond <= epsilon_0.

Use the architecture

L_design = L_sweep + gamma sum_x (D_{B_x}-Id),

where gamma is fixed and gamma >= d_max^2 epsilon_0. The actual perturbed generator is EXACTLY

L_actual = L_sweep + gamma sum_x (Phi_x-Id),
Phi_x = D_{B_x}+Delta_x/gamma.

Each Phi_x is a bounded-support CPTP map. Consequently it admits a state-independent Poisson-attempt representation at rate gamma per anchor, regardless of its internal coherence or nonunitality. This is a genuine positive fault-event representation of the PADDED generator, not of Delta_x alone.

If the support-only contour argument works below an incident attempt rate lambda_*, choose nu gamma<lambda_*; then epsilon_0 < lambda_*/(nu d_max^2) is a nonzero uniform admissible perturbation budget. When the contour parameter is per-anchor rather than per-site, pay its actual support-size and overlap constants instead of silently identifying these rates.

All intentional noise, faults in its implementation, and engineered-correction faults must be included in the same assigned Delta budget. The padding must cover their full supports. A perturbation with larger support than admitted is not covered.

## Quantum correctness interface
Condition on ideal proposal clocks and padding-attempt supports/times. Every arbitrary CPTP fault has a local Kraus expansion in the Pauli basis. Thus all data Kraus operators are linear combinations of the bounded-support Pauli histories considered by a uniform support envelope.

To conclude exact correction on a good event, one needs ONE final decoder D, independent of fault locations, Kraus branches, syndrome histories and clock history, such that every Pauli history in the good support event is corrected by D. Equivalently, the entire resulting error-operator family must satisfy the corresponding common Knill--Laflamme condition. 'Each branch has some decoder' is insufficient.

Given that property, the conditioned good-event channel is logically identity for any encoded state, including a reference. Averaging yields logical diamond error at most 2 times the probability of the support-only bad event. The Poisson attempt supports and clocks are sampled independently of quantum outcomes, so conditioning does not introduce a state-dependent event distribution.

## Interpretation and limitations
This is intentional extra noise used to put the local map in the interior of the CPTP cone. It is mathematically legitimate in a bounded-body autonomous Lindbladian model, but may produce a terrible constant: d_max^2=4^s for a ball of s qubits. It provides no two-body implementation, practical threshold, low-dimensional embedding of a 4D lattice, or independent proof of the underlying eroder/CPTP-event threshold.

No novelty claim is made for the elementary Choi interior argument; the potential research contribution is its application to this specific continuous-time memory construction if all remaining interfaces are proved.

## Explicit fixed-decoder argument for the 4D loop construction
Let V encode the logical Hilbert space into the toric-code subspace. For each allowed syndrome s, choose the deterministic component-cap Pauli C_s used in the loop construction when all components are small; extend it arbitrarily to a Pauli with syndrome s on remaining sectors. The decoder has Kraus operators R_s=V^dagger C_s P_s, with harmless phase/convention adjustments. These maps define a CPTP decoder because each syndrome sector is carried isometrically to the logical space.

Fix a finite Poisson history consisting of all ideal sweep proposal times and all arbitrary-CPTP fault-event supports/times. Do not condition on quantum measurement or Kraus outcomes. On the good support history, the common Boolean birth envelope controls all Pauli branches. Write a Kraus operator K_h of the conditioned physical evolution, where h includes the local Kraus and ideal syndrome outcomes. Expand each local fault Kraus in Paulis. For every Pauli word in that expansion, intervening stabilizer projectors either annihilate the word on V or supply its definite syndrome projector. The surviving word is a Pauli E acting on V.

The component-cap homology induction gives, for its final syndrome s, C_s E V = alpha V, with alpha a scalar phase. Consequently

R_s K_h V = a_(h,s) I_logical

for every h,s, even after summing interfering Pauli terms. Summing Kraus operators gives the identity logical channel, since trace preservation forces sum_(h,s)|a_(h,s)|^2=1. Tensoring a reference changes none of these identities.

The conditioned full channel is CPTP for every clock/support history, because each scheduled event is CPTP. Histories are distributed independently of the input state. Splitting their classical distribution into good and bad gives

||D_final exp(T L_actual) Enc - Id||_diamond <= 2 P(bad support history).

This proof uses neither a Pauli-twirling approximation nor a claim that individual coherent Kraus terms have probabilities. The required error-envelope event must be defined from complete event supports, not from whichever Pauli term happens to occur in an expansion.
