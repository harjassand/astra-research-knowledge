# Finite-torus first-cluster transfer for a noisy monotone eroder

Status: constructive lemma, jointly developed with find_new_bridges. This transfers an assumed infinite-volume spacetime-cluster estimate to a finite clean-start torus. It does not prove the proposed sweep macro rule satisfies the assumptions, and does not convert signed quantum perturbations to positive iid marks.

## Assumptions
Let D(x,n) in {0,1} denote defects on the side-L d-dimensional discrete torus, with D(x,0)=0 and

D(x,n)=xi(x,n) OR G((D(x+a,n-1))_{a in A}).

Here G is a fixed finite-range monotone Boolean function with G(0)=0, and xi are independent Bernoulli(delta) marks. A process merely dominated by this one is sufficient. Let k be at least the spacetime l-infinity length of every dependence edge. Connectivity below is k-neighbor connectivity in spacetime, using torus distance in space and ordinary distance in time.

Assume the corresponding stationary infinite-lattice defect process has, at every anchor z, the estimate

P(diameter(C_z) >= ell) <= delta^[c(ell+1)]

for all ell>=0, as supplied under its hypotheses by Hartarsky--Toninelli, arXiv:2212.08437, Corollary 9.5 (with healthy/defect convention complemented).

## Statement
Choose ell with 4(ell+k)<L. For the finite process through time N,

P(any defect spacetime component has diameter >= ell)
 <= L^d N delta^[c(ell+1)].

Up to floors, ell=L/10 is allowed once L>constant*k. Thus the bound is exponentially small in L for times exponentially large in L, with fixed small delta. This is a cluster statement, not by itself a logical-decoding theorem.

## Proof
Reveal occupied vertices chronologically, with any fixed ordering inside a time layer. Consider the first addition z at which a component C reaches diameter ell. Each pre-existing component joined to z has diameter <ell and contains a neighbor of z within distance k. Hence every vertex of C is within distance ell+k of z, and diameter(C)<=2ell+2k. C is contained in a unique spatial coordinate chart because 4(ell+k)<L. All its times are no later than z's time.

Each occupied vertex u with xi(u)=0 has a sufficient occupied predecessor set S_u: by monotonicity, G(1_{S_u})=1 and every predecessor in S_u is occupied. Choose one such set. Every predecessor is joined to u by a k-edge and is in an earlier layer, so it is already revealed and belongs to C. Recursively choosing these sets yields a finite witness DAG contained in C. Its leaves have xi=1, since the initial layer is clean and G(0)=0. Do this for every vertex of C. These witnesses certify occupancy regardless of all inputs or marks outside C.

For each deterministic candidate z, fix the chart centered at z with spatial radius ell+k and time interval [n_z-(ell+k),n_z], intersecting the nonnegative time slab as needed. Its torus marks have exactly the same joint distribution as iid marks in the corresponding infinite-lattice chart. Let E_z be the event that chart marks admit a family of the preceding finite witness DAGs forcing a connected defect set containing z with diameter at least ell. The event of first crossing at z implies E_z. Under iid infinite-lattice marks, E_z forces a stationary defect component of diameter at least ell, irrespective of marks outside the chart. The assumed infinite-volume estimate therefore bounds P(E_z) by delta^[c(ell+1)]. Union over the L^d N possible z proves the statement.

No stationarity assertion is made for the torus, no full long-time causal cone is unwrapped, and no conditioning on absence of previous large clusters is used in the probability estimate.

## Necessary interfaces
1. A genuine pointwise domination by the stated finite-torus iid-mark CA, including the proposed LSS step.
2. The macro map G must be an attractive eroder satisfying the cited infinite-volume theorem; clean-box erosion alone is insufficient.
3. The physical activity-to-macro-cluster map must show that absence of these macroscopic clusters gives one fixed reference-safe logical recovery.
4. For arbitrary coherent/signed generator perturbations, iid Bernoulli mark domination cannot be assumed. A separate quantum comparison or signed-contour estimate is still required.
5. Non-clean initial states require a separately paid initial defect field; the above clean initial boundary cannot be replaced silently by arbitrary controller/data corruption.
