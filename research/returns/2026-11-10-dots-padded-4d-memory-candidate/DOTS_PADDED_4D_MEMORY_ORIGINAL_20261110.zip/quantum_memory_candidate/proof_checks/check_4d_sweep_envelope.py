"""Exhaustive local support check; not a global threshold proof.
8 incident root edges; 15 Boolean envelope sites: root, +/-e_i, e_i+e_j.
Both sectors have this identical cubical incidence geometry.
"""
from itertools import combinations
import json
D=4
O=(0,)*D
E=[tuple(int(i==j) for i in range(D)) for j in range(D)]
def add(a,b): return tuple(x+y for x,y in zip(a,b))
def neg(a): return tuple(-x for x in a)
pairs=list(combinations(range(D),2))
verts=[O]+[neg(e) for e in E]+E+[add(E[i],E[j]) for i,j in pairs]
index={v:i for i,v in enumerate(verts)}
def vertexmask(edges):
    s=set()
    for x,i in edges: s|={x,add(x,E[i])}
    return sum(1<<index[x] for x in s)
def boundary(i,j):
    return {(O,i),(O,j),(E[i],j),(E[j],i)}
def update(mask):
    pre=mask
    if not any(pre&(1<<(1+i)) for i in range(D)):
        mask &= ~1
    for i,j in pairs:
        if pre&(1<<(5+i)) and pre&(1<<(5+j)):
            mask |= 1<<index[add(E[i],E[j])]
    return mask
checks=0
syndromes=0
pairing_cases=0
for incident in range(256):
    if incident.bit_count()%2: continue
    syndromes+=1
    negative=incident&15
    outgoing=[i for i in range(D) if incident&(1<<(4+i))]
    before={(neg(E[i]),i) for i in range(D) if negative&(1<<i)}
    before|={(O,i) for i in outgoing}
    after=set(before)
    if not negative and outgoing:
        pairing_cases+=1
        for i,j in zip(outgoing[::2],outgoing[1::2]):
            after ^= boundary(i,j)
        assert all(O not in (x,add(x,E[i])) for x,i in after)
    b=vertexmask(before)
    a=vertexmask(after)
    # Exhaust all supersets including arbitrary other envelope occupancies.
    free=((1<<len(verts))-1)^b
    sub=free
    while True:
        m=b|sub
        out=update(m)
        assert out&a==a, (incident,m,out,a)
        # Arbitrary outside edges can make other vertices occupied initially.
        # All non-root existing occupancy survives envelope update.
        assert (m&~1)&out == (m&~1)
        # Monotonic root criterion: actual negative edge forces predecessor.
        if negative: assert out&1
        checks+=1
        if sub==0: break
        sub=(sub-1)&free
# Check monotonicity of the entire simultaneous map on every Boolean cover edge.
monotone_checks=0
for m in range(1<<len(verts)):
    out=update(m)
    for bit in range(len(verts)):
        if m&(1<<bit): continue
        assert out & update(m|(1<<bit)) == out
        monotone_checks+=1
result={"status":"pass","incident_even_syndromes":syndromes,
        "nonempty_trailing_pairings":pairing_cases,
        "envelope_superset_checks":checks,"monotonicity_cover_checks":monotone_checks,
        "sites":len(verts),"dual_sector":"identical 4D cubical incidence under duality",
        "scope":"local pre-state batch support domination; not contour, LSS, or quantum-channel proof"}
print(json.dumps(result,indent=2))
