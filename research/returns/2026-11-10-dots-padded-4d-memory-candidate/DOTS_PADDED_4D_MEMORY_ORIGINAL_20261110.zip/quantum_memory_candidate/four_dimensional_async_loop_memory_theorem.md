# Four-dimensional asynchronous loop memory under local stochastic Pauli noise

Research proof draft, 10 November 2026. This is a scoped mathematical construction, not a claim of a practical three-dimensional memory, a complete microscopic noisy-controller compilation, or novelty relative to existing four-dimensional Toom memories. The finite-volume transfer is also written separately in `finite_torus_first_cluster_transfer.md`.

## 1. Statement and scope

Consider the cubical four-dimensional torus of side L, with qubits on 2-cells, X stabilizers on edges, and Z stabilizers on 3-cells. Give its primal and dual lattices fixed positive-coordinate orientations. There is a translation-invariant, finite-range, bounded-rate Lindbladian specified below such that, for sufficiently small local stochastic-Pauli noise intensity λ/κ, clean encoded initialization followed by an ideal final syndrome-dependent decoder has

    P(decoded logical Pauli error before time T)
       ≤ 2 C0 (L/R)^4 (1 + ceil(T/B)) δ^[c floor(L/(1000R))].       (1)

Here R, B=CR/κ, K, C0, c>0 and δ<1 are constants independent of L and T. The statement initially takes L divisible by R and L/R sufficiently large compared with K. The threshold is existential and extremely conservative, not an engineering estimate. Both X and Z logical sectors are included. For an arbitrary encoded state entangled with a reference, decoded entanglement infidelity is at most the right side of (1), and decoded diamond-norm error is at most twice that bound.

Noise scope: sums of bounded-support Pauli-jump generators, with a uniform bound λ on total local intensity. Correlations within one bounded-support event, including simultaneous X/Z components, are allowed. Independent Poisson primitive events, or an explicitly supplied local stochastic domination, are required. Arbitrary coherent Hamiltonian perturbations, arbitrary local CPTP perturbations, temporally adversarial noise, and an implemented noisy classical controller are not established by this statement.

The model has fixed local Hilbert dimension, interaction range and rates. It uses ideal engineered multi-body dissipative jumps. It does not secretly assume a global clock, but it does assume those jumps can be supplied. Its final decoder is a mathematical readout map, not an online local controller.

## 2. Local generator

For each primal vertex w, let s denote the full incident-edge X-stabilizer syndrome. Let P_(w,s) be the projector onto that syndrome. A syndrome is trailing when no negative-coordinate incident edge is occupied. The local cycle constraint forces an even number of occupied positive-coordinate edges. If trailing, pair its 2 or 4 occupied outgoing directions in a fixed deterministic order and let U_(w,s) be the product of Pauli Z on the corresponding faces at w. If not trailing, or empty, take U_(w,s)=I.

Define jumps L_(w,s)=sqrt(κ) U_(w,s) P_(w,s), for all local syndromes s. Repeat on dual vertices with X corrections and dual syndrome projectors. The generator is the sum of dissipators

    D[L](ρ)=LρL†−{L†L,ρ}/2.

For each vertex, sum_s L†L=κ I, so the jump interpretation is one rate-κ clock followed by the syndrome-selected local operation. Only finitely many local projectors and faces occur. The dual construction is the same on dual cells. A Z correction preserves every Z-check outcome, and an X correction preserves every X-check outcome. Thus the two syndrome processes decouple conditional on the common stochastic Pauli history, even when faults correlate them.

Add noise jumps sqrt(λ_a) P_a, with P_a a Pauli supported in a ball of fixed radius r0 and total rates involving any fixed cell bounded by λ. One may absorb the fixed r0 into geometric constants and the block halo.

Starting from a clean code state, every trajectory is a Pauli frame applied to that state. Stabilizer projectors do not measure the encoded information. The no-jump evolution contributes only scalar normalization because the sums of L†L and noise P†P are scalar. Consequently syndrome arguments apply to arbitrary encoded information, including entanglement with a reference.

## 3. Exact pathwise syndrome envelope

Let D_v be a Boolean upper envelope of syndrome-vertex occupancy. At each rate-κ clock at w, use ALL pre-jump values to perform the simultaneous monotone batch

    D_w := D_w AND (OR_i D_(w−e_i));
    D_(w+e_i+e_j) := D_(w+e_i+e_j)
                    OR (D_(w+e_i) AND D_(w+e_j)),  i<j.

Other sites are unchanged. A Pauli noise event forces D=1 at all syndrome vertices in its bounded neighborhood.

This dominates actual occupancy pathwise. If w has no occupied envelope predecessor, the actual syndrome at w is either absent or trailing, and the sweep clears it. The intermediate corners of every applied face were already occupied. A newly occupied high corner has both required pre-jump intermediate corners. All six possible births are retained as ONE correlated batch. No independence of births is used.

Each map is monotone. It cannot increase any coordinate maximum of a finite occupied set: every new high corner has a parent attaining its value in each coordinate. Birth dependencies and the root-death dependencies point only to v−e_i; all inputs are pre-jump. This strict chronological interpretation is important for shared-clock bounds.

The construction concerns syndrome occupancy, not raw Pauli support. Stabilizer-equivalent errors need not physically disappear.

## 4. Clean-front service

Start from the occupied halfspace h(x)=sum_i x_i≥0. Sites below it stay empty. Let τ_v be the time by which all sites of height at most h(v) in v's backward cone have permanently cleared. A sufficient clearing recursion is

    τ_v ≤ max_i τ_(v−e_i) + E_v,     E_v ~ Exp(κ).

After all predecessors are permanently empty, births at v are impossible; the next clock at v clears it. Because predecessors are strictly lower in h, their clearing construction does not use v's clock. Poisson memorylessness supplies the required independent exponential increments in this sufficient last-passage construction.

To clear the origin macro cube [0,R−1]^4 it suffices to clear at most 4R layers. A union bound over sites and directed paths, followed by the exponential moment at κ/2, gives

    p_front ≤ R^4 8^(4R+1) exp(−κB/2).

Set B=CR/κ with a fixed C>8 log 8; C=40 is one conservative choice.

## 5. State-independent finite-range good blocks

Partition space into cubes Q_z=Rz+[0,R−1]^4 and time into bins of length B. Use a local window of radius KR around each output cube. A good block requires:

1. No POTENTIAL backward dependency path from any point and any time in that output cube/bin reaches the window boundary. This includes all syntactic read/write dependencies, not merely dependencies realized by the current syndrome.
2. The reference halfspace h(x)≥R sum_i z_i, restricted to the local window and evolved with fixed occupied exterior boundary, clears the output cube by the end of the bin.
3. No physical fault occurs in the full local space-time window.

The finite-window front test agrees with the infinite halfspace test whenever no escape occurs. Therefore its extra failure probability is bounded by the infinite-front failure plus the cone-escape probability; it does not import outside randomness into a block definition.

The no-escape condition must cover intra-bin activity, not only the endpoint. It is measurable using clocks in the finite window, stopping potential paths at the boundary. One can impose an arbitrary fixed exterior Boolean boundary when computing the local map; on the good event it cannot affect the output for ANY input.

For a fixed ancestral path, simultaneous batches use pre-jump values, so successive events on that path have strictly decreasing times. Each spatial dependency step has at most four possible directions and at most four relevant clock labels per direction. A factorial-moment bound gives the conservative endpoint estimate

    sum_(n≥KR) (16κB)^n/n!.

Covering all output sites and all event times in the bin introduces a polynomial factor in R, with constants depending on fixed K,C. Taking K sufficiently larger than C (for example larger than 32eC, after accommodating window conventions and r0) makes this bounded by poly(R) exp(−c1 R). No independence between overlapping paths or batch births is assumed.

The bad-block field has fixed finite dependency range O(K) in macro coordinates and time range one bin, because its defining primitive clocks and faults are confined to the window. Its marginal obeys

    p_R ≤ poly(R) exp(−c2 R) + C_K (λ/κ) R^5.           (2)

The fault term uses the full spatial volume O((KR)^4) and duration O(R/κ), not just a rail length or one syndrome site.

Checkpoint: constants in the all-times cone estimate should be written out if numerical thresholds are wanted. Only a polynomial prefactor and an exponential-in-R tail are needed here. The precise finite spatial neighborhood can be enlarged by fixed factors without changing the argument.

## 6. A single deterministic coarse eroder

For each good local clock realization, inflate macro input bits to full micro cubes, evolve the envelope, and OR the micro output over Q_0. This is a finite-range monotone Boolean function of macro input bits. Define G to be the pointwise OR over ALL such good functions. Different output sites need not choose compatible clock realizations: the resulting rule is an upper envelope, not a claimed common physical realization.

G is deterministic, translation-invariant and monotone, with a fixed macro neighborhood depending only on K. It has two uniform properties:

* Coordinate caps do not expand: inputs contained in z_i≤a_i give outputs contained there.
* Diagonal minimum advances: inputs in sum_i z_i≥b give outputs in sum_i z_i≥b+1.

For the second property, at an output z with sum_i z_i=b, inflated inputs lie in the translated micro halfspace h≥Rb. The good front event clears Q_z. Only ONE reference halfspace test per translated output is needed; all offsets follow by translation. Taking the OR over good histories preserves both properties.

If initial finite input D lies in z_i≤a_i and sum_i z_i≥b, then G^n(D) lies in those caps and sum_i z_i≥b+n. It is empty once n>sum_i a_i−b. Thus G is an eroder, with a linear clean finite-seed erosion bound.

Writing η_(z,n) for the bad-block indicator yields, pathwise,

    D_macro(n+1,z) ≤ G(D_macro(n))_z OR η_(z,n).

Use finite-dependence domination (Liggett–Schonmann–Stacey) to couple η below iid Bernoulli marks ξ of parameter δ_K(p_R)→0 as p_R→0. On a finite torus this uses the same bounded-dependency-graph version, with uniform constants. Alternatively its finite-graph coupling follows from the usual bounded-degree proof. The iid marks need NOT be independent of the physical trajectory: coordinatewise domination and deterministic recursion from zero suffice.

There is an important non-circularity point. G can change with R. Fix K first. There are only finitely many Boolean functions on the fixed macro neighborhood, hence only finitely many possible eroders G obtained here. Take minima of the positive contour constants and thresholds over this finite family. Then choose R large enough to suppress the clock term in (2), and finally λ/κ small enough to suppress its fault term. This gives a uniform existential threshold.

## 7. The external spacetime-cluster theorem used

Hartarsky–Toninelli, Kinetically constrained models out of equilibrium (2024), Corollary 9.5:
https://arxiv.org/html/2212.08437

For an attractive eroder with sufficiently small independent deaths, its stationary upper-invariant trajectory has exponentially small fixed-range-connected zero clusters. Complement G so that healthy=1. For every fixed connectivity radius k there exist c,δ0>0 such that the maximal connected error cluster A through a prescribed space-time point obeys

    P(diam A≥ℓ) ≤ δ^[c(ℓ+1)] .                         (3)

Hypotheses checked: finite Boolean neighborhood, deterministic translation-invariant rule, monotonicity, eroder property, iid marks, and clean initialization. A process begun clean at any finite time is dominated by the stationary low-error process constructed with marks extending to negative time. This initialization domination is used only on the infinite lattice; no torus stationary-state assertion is made.

The published proof uses bounded-range Toom contours and disjoint decorated-set selection, hence counts distinct noise sinks rather than independently charging one old fault repeatedly. We use (3), not a fresh fault charge at every scale. The entire coarse reduction is performed once at fixed R.

## 8. Finite-torus transfer without wrapping the whole past

Let N=L/R and choose k larger than both G's update range and the intra-bin mapping range below. Consider the auxiliary iid-mark CA on the finite N-torus, begun identically zero (no errors). Reveal its occupied space-time vertices chronologically, with a fixed spatial tie order in each time slice.

Stop when a k-connected component first reaches diameter ℓ. It was formed by adding one vertex whose neighboring old components all have diameter below ℓ. Every vertex in the merged component is within ℓ+k of the new vertex, so the whole component has diameter at most 2ℓ+2k. Choose 4(ℓ+k)<N; then the component has a single local Euclidean chart about the new vertex.

Every occupied non-fault vertex has a finite occupied-input witness for G=1 in the previous time slice. All those predecessors have already been revealed and are k-neighbors, hence belong to the same component. Iteration gives a finite sufficient witness DAG entirely inside the crossing component. Its leaves are iid noise marks, because the initial state is zero. No assumption about the size of the unconstrained full backward cone is needed.

For any deterministic candidate crossing site/time, take a deterministic space-time chart of radius 2ℓ+2k about it. Couple torus iid marks in this chart to independent infinite-lattice marks there, extending independently outside. The event that a sufficient witness cluster of the specified size exists inside the chart depends only on those marks and implies an occupied cluster of at least the same diameter in the infinite process initialized clean before the chart's lower boundary. Infinite stationary domination and (3) bound its probability by δ^[c(ℓ+1)]. One does not condition on the random first-crossing event.

A union bound over candidate sites and time layers gives

    P(first large auxiliary cluster by layer n)
       ≤ N^4(n+1) δ^[c(ℓ+1)].                         (4)

This is valid for arbitrarily long finite time horizons. It avoids identifying torus noise copies at repeated spatial windings, or coupling a whole long-time stationary trajectory to an infinite one. See the separate first-cluster lemma for a fully expanded version. A second route uses the published zero-contained explanation/contour construction, but is unnecessary for (4).

## 9. Intra-bin transient checkpoint

Endpoint-only suppression is not enough: a large loop might be born and disappear during a bin. The all-times potential-cone event in Section 5 fixes this.

If a good output cube contains syndrome activity at any time in a bin, tracing an actual Boolean ancestor reaches an occupied macro INPUT cube within distance K. If the output block is bad, its auxiliary OUTPUT bit is forced occupied by ξ. Thus every active micro cube in that bin maps to an occupied auxiliary site in time layer n or n+1, within spatial distance K+O(1). Adjacent active cubes map to sites within distance 2K+O(1). Choose a fixed k, for example any sufficiently enlarged 4K+10 after fixing norm conventions, to connect all images.

Therefore a connected actual syndrome component of macroscopic spatial diameter produces a k-connected auxiliary space-time component of comparable diameter, up to a 2K+O(1) additive loss. Before the crossing in (4), every actual syndrome component at EVERY continuous time fits a chart of diameter at most R(ℓ+2K+O(1)). Take ℓ=floor(N/1000) and N sufficiently large compared with K so that this is below L/100. Constants can be decreased further without affecting exponential scaling.

## 10. Homology and the final decoder

For each small connected syndrome component, choose a deterministic 2-chain filling in a contractible cubical box containing that component. Such a filling exists because its edge syndrome is a closed 1-cycle and the box has trivial first homology. Use a deterministic choice of the small torus chart and filling, depending only on that component. Let C(σ) be the sum of those caps.

At any bounded-support Pauli event e, including an engineered correction, σ changes to σ+∂e. Components untouched by the event keep identical caps. If all components before and after the event are small, then

    C(σ) + e + C(σ+∂e)

is a closed 2-chain supported in a contractible chart around the event and all touched components. Each touched component meets the bounded event neighborhood, and its cap lies in its small local box, so their union still lies in a contractible chart for the chosen size margin. Every closed 2-chain there is a stabilizer boundary. Hence the decoded homology class cannot change at this event.

Starting clean and inducting over events proves zero decoded logical Z action until a macroscopic primal syndrome component appears. The identical dual argument proves zero decoded logical X action. Correlation between the sectors does not matter: union bound their failure probabilities. Composing the final X and Z cap corrections changes at most a Pauli phase. Equation (1) follows from (4), the intra-bin mapping and the two-sector union bound.

The cap argument is specific to loop syndromes: a singleton point charge does not admit a local cap. It therefore cannot silently solve the point sector of a 3D toric code.

## 11. Remaining boundaries of the claim

* This document is a detailed proof draft requiring independent mathematical checking, especially bookkeeping of finite-dependence domination on periodic graphs and the all-times potential-cone event. No numerical threshold has been computed.
* The ideal local Lindbladian is explicit. Its implementation using noisy syndrome records, gates and classical states is a separate construction. A generic statement that controller faults are local Pauli marks would be an extra assumption, not a consequence proved here.
* Clean encoded initialization is essential to the present finite-witness argument. Initial errors can be added only under an independently proved local-stochastic initialization bound; arbitrary initial controller/data damage is not covered.
* No general coherent/CPTP fault theorem follows merely by replacing the word Pauli. That requires a separate fault-path norm argument.
* Four-dimensional loop protection and Toom-style memories have substantial prior art. This draft does not establish a new practical primitive or that the user's North Star has been attained.
