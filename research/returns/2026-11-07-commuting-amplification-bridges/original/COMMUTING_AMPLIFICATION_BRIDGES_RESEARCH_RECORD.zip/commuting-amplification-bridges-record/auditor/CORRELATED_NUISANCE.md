# A correlated-state nuisance repair with exact limits

Independent auditor derivation, 7 November 2026. This note weakens the previous
independent-state assumption in a precise direction. It does not solve the
general question-correlated nuisance problem.

## 1. Fixed commuting event absorption

Let `H` be any Hilbert space, `psi` a unit vector, and `A_a^x,B_b^y` complete
finite POVMs with exact cross-player commutation. Let `C` be an input-independent
positive contraction commuting with every `A_a^x` and `B_b^y`. Put
`p=<psi,C psi> > 0` and `psi_C=C^(1/2) psi/sqrt(p)`. Then

\[
 \frac{\langle\psi,C A_a^xB_b^y\psi\rangle}{p}
   =\langle\psi_C,A_a^xB_b^y\psi_C\rangle.\tag{1}
\]

Thus postselection on this fixed event is exactly an input-independent change
of shared resource. The same local POVMs remain complete and commuting. The
identity follows by commuting `C^(1/2)` through the joint effect. It preserves
every fine observable in the declared main algebras, rather than only a scalar
payoff. It makes no locality/implementation claim about preparing `psi_C`.

This works for arbitrarily correlated initial resources. A literal tensor
factorization of the state is unnecessary. If the auxiliary test is perfect,
`p=1`, positivity of `I-C` implies `C psi=psi`, so even the declared main
correlations do not change.

It is important that `C` be input-independent and commute with every retained
fine effect. This is a semantic quotient of the retained observables. It does
not automatically retain auxiliary fine outputs which fail that commutation
condition, and it does not remove fresh-question-dependent filters.

## 2. Exact nuisance-log cancellation without a product state

Let `M=M_0 tensor N` be a tensor product of finite tracial von Neumann algebras.
Let `sigma>=0` be any bounded element with `tau(sigma^2)=1`; it need not factor.
Define

\[
 \chi(F,H)=\tau(\sigma F\sigma H),\qquad f(t)=t\log t,
 \quad f(0)=0.
\]

Suppose a family of main effects `F_x,H_y` is tensored with fixed nuisance
effects `R_l,S_l` (positive contractions in `N`). In an exposure step let
`F_y=sum_x q(x|y) F_x`, and keep each `R_l,S_l` independent of the fresh live
question and of the exposure stage. Then

\[
 \begin{split}
 &\sum_x q(x|y) f(F_x\otimes R_l)-f(F_y\otimes R_l)\\
 &\hspace{12mm}=
 \left(\sum_x q(x|y)f(F_x)-f(F_y)\right)\otimes R_l.
 \end{split}\tag{2}
\]

Indeed joint scalar functional calculus gives, including zero spectrum,

\[
 f(F\otimes R)=f(F)\otimes R+F\otimes f(R).
 \tag{3}
\]

The second summand cancels exactly in (2) because `F_y` is the stated convex
average. No trace or state independence was used. Applying the positive
functional `T -> chi(T,H_y tensor S_l)` gives the exact Jensen increment in the
full correlated state. The transposed identity holds for `H`.

For a finite exact nuisance acceptance partition with nonnegative weights
`q_l`, define the nuisance accepting operator on `L^2(M)` by

\[
 C=\sum_l q_l L(I\otimes R_l)R(I\otimes S_l).
\]

Assume `0<=C<=I`. This is automatic when these are factors of an exact Boolean
predicate evaluated on complete nuisance POVMs. It commutes with all main
left/right effects. If `C sigma=sigma`, summing (2) against all nuisance factors
gives exactly the unpadded increment:

\[
 \begin{split}
 &\sum_l q_l\chi\left(
       [\sum_xq(x|y)f(F_x)-f(F_y)]\otimes R_l,
                       H_y\otimes S_l\right)\\
 &=\chi\left(
       [\sum_xq(x|y)f(F_x)-f(F_y)]\otimes I,
                       H_y\otimes I\right).
 \end{split}\tag{4}
\]

The proof moves `C` to the vector `sigma`; it commutes with the displayed main
operators. Thus all scalar weights, tested masks and original independent
question averages can be retained. In an entire resolvent exposure telescope,
the nuisance logarithms contribute no increment and, for a perfect nuisance
test, the remaining increments are exactly those of the unpadded strategy on
the same correlated resource. This statement is stronger than literal
independent-product-state cancellation, while preserving the fixed nuisance
effect hypothesis.

If `C sigma` is not `sigma`, equations (2)--(3) still hold. The remaining main
bilinear form is the main correlation evaluated in the fixed filtered resource
`C^(1/2) sigma`, by (1). It is generally not a scalar multiple of the original
unfiltered main form. Subtracting it as if the state were independent is wrong.

## 3. A quantitative version

Suppose the fixed nuisance event has probability `p=1-delta>0`. The normalized
vectors obey

\[
 \|\psi_C-\psi\|^2\le2(1-\sqrt p)\le2\delta.
 \tag{5}
\]

To verify the first inequality, functional calculus gives
`<psi,C^(1/2)psi> >= <psi,C psi>=p`, hence
`Re<psi,psi_C> >= sqrt(p)`. For any losing effect `0<=L<=I`, with
`alpha=<psi,L psi>`, contraction of `sqrt(L)` gives

\[
 \langle\psi_C,L\psi_C\rangle
 \le\alpha+2\sqrt{2\alpha\delta}+2\delta.
 \tag{6}
\]

The constant in (5) is deliberately safe. If one also conditions on a main
event of probability `q`, an absolute error can be amplified by `1/q`; (6) is
not permission to erase rare-event costs. A useful extension must prove a
relative estimate at the actual conditioned mass.

## 4. Exact boundary: fresh-question control can be nonlocal

Let `X,Y,A,B` be independent uniform bits and let the retained answers be
`A,B`. Condition on `E={A xor B = X*Y}`. Then `Pr(E|X=x,Y=y)=1/2` for every
pair, so the question law is unchanged. But the conditional box is

\[
 \Pr(A=a,B=b\mid x,y,E)
 =\tfrac12\,\mathbf1\{a\oplus b=xy\},\tag{7}
\]

a perfect CHSH box. It has uniform local marginals and cannot be a commuting
correlation. For a direct proof, the two binary effects on either input define
self-adjoint contractions `A_0,A_1,B_0,B_1`. For
`S=A_0(B_0+B_1)+A_1(B_0-B_1)`, Cauchy--Schwarz on the direct sum of two vector
spaces gives
`|<S>| <= sqrt(||A_0 psi||^2+||A_1 psi||^2)` times
`sqrt(||(B_0+B_1)psi||^2+||(B_0-B_1)psi||^2) <= sqrt(2)*2`.
The last equality uses cancellation of the cross terms in the two squared
norms and the contraction bounds. A perfect box would give `<S>=4`, a contradiction.
Equivalently its CHSH win probability one exceeds `(2+sqrt(2))/4`.

Here the initial data are completely classical and the conditional question
drift is zero. The event's acceptance operator depends on both fresh questions.
Consequently zero referee-law drift and an apparently harmless fixed-probability
postselection do not supply a legal local correction. The R/H/S construction
correctly charges more than referee-law divergence; this example does not
contradict it or the original repetition theorem.

## 5. Constructive next operation

The exact fixed-event result suggests a precise sufficient target: identify a
retained local observable algebra and an input-independent event operator in
its commutant which agrees with the original tested event on the relevant
fine correlation functionals, to relative error at the tested probability.
Absorb that event first, then run the original reconstruction on the retained
algebra. A general question-controlled replacement is not proved here and is
blocked by (7) without additional hypotheses. The extension in (2)--(4) is
an elementary entropy identity, not a new recovery theorem or a claimed
general quadratic-repetition result.
