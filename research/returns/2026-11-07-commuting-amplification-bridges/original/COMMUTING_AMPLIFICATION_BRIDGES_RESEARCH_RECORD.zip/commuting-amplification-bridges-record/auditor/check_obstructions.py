"""Finite diagnostics for independently proved identities; not theorem certificates."""
from __future__ import annotations
import hashlib
import json
import math
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent
RNG = np.random.default_rng(20261107)


def adj(a):
    return a.conj().T


def op(a):
    return float(np.linalg.norm(a, 2))


def f(a):
    v, u = np.linalg.eigh((a + adj(a)) / 2)
    assert float(v.min()) > -1e-10
    v = np.maximum(v, 0)
    z = np.zeros_like(v)
    positive = v > 1e-14
    z[positive] = v[positive] * np.log(v[positive])
    return (u * z) @ adj(u)


def effect(n):
    z = RNG.normal(size=(n, n)) + 1j * RNG.normal(size=(n, n))
    a = z @ adj(z)
    return a / (1.1 * op(a))


def state(n):
    a = effect(n)
    return a / np.sqrt(np.trace(a @ a).real / n)


def chi(sigma, a, b):
    return float(np.trace(sigma @ a @ sigma @ b).real / len(sigma))


entropy_errors = []
for trial in range(80):
    sigma = state(4)  # No product-state restriction.
    fs = [effect(2), effect(2)]
    r, s, h = effect(2), effect(2), effect(2)
    q = float(RNG.uniform(.05, .95))
    fy = q * fs[0] + (1 - q) * fs[1]
    full = q * f(np.kron(fs[0], r)) + (1 - q) * f(np.kron(fs[1], r))
    full -= f(np.kron(fy, r))
    main = np.kron(q * f(fs[0]) + (1 - q) * f(fs[1]) - f(fy), r)
    entropy_errors.append(op(full - main))
    entropy_errors.append(abs(chi(sigma, full, np.kron(h, s))
                              - chi(sigma, main, np.kron(h, s))))

perfect_errors = []
for trial in range(40):
    p0, p1 = np.diag([1., 0.]), np.diag([0., 1.])
    a, b = effect(2), effect(2)
    sigma = np.kron(a, p0) + np.kron(b, p1)
    sigma /= np.sqrt(np.trace(sigma @ sigma).real / 4)
    fs = [effect(2), effect(2)]
    hs = [effect(2), effect(2)]
    mu = RNG.uniform(.1, 1., size=(2, 2)); mu /= mu.sum()
    mux, muy = mu.sum(axis=1), mu.sum(axis=0)
    fy = [sum(mu[x, y] / muy[y] * fs[x] for x in range(2)) for y in range(2)]
    hx = [sum(mu[x, y] / mux[x] * hs[y] for y in range(2)) for x in range(2)]
    # A nonfactor sigma and a deliberately non-coarsened nuisance partition.
    rs = [.3*p0, .7*p0, .4*p1, .6*p1]
    ss = [p0, p0, p1, p1]
    full0 = sum(muy[y] * chi(sigma, f(np.kron(fy[y], r)), np.kron(hs[y], s))
                for y in range(2) for r, s in zip(rs, ss))
    full1 = sum(mux[x] * chi(sigma, f(np.kron(fs[x], r)), np.kron(hx[x], s))
                for x in range(2) for r, s in zip(rs, ss))
    main0 = sum(muy[y] * chi(sigma, np.kron(f(fy[y]), np.eye(2)),
                            np.kron(hs[y], np.eye(2))) for y in range(2))
    main1 = sum(mux[x] * chi(sigma, np.kron(f(fs[x]), np.eye(2)),
                            np.kron(hx[x], np.eye(2))) for x in range(2))
    perfect_errors.append(abs((full1-full0)-(main1-main0)))
    # The nuisance log endpoint can be nonzero, despite its increment being zero.
    c0 = full0-main0; c1 = full1-main1
    perfect_errors.append(abs(c0-c1))

clock = []
for n in [7, 11, 16, 32, 64]:
    u = np.diag(np.exp(2j * np.pi * np.arange(n) / n))
    v = np.roll(np.eye(n, dtype=complex), 1, axis=0)
    w = u @ v @ adj(u) @ adj(v)
    bott = float(np.angle(np.linalg.eigvals(w)).sum() / (2*np.pi))
    es = [(np.eye(n)+(u+adj(u))/2)/2,
          (np.eye(n)+(u-adj(u))/(2j))/2]
    fs = [(np.eye(n)+(v+adj(v))/2)/2,
          (np.eye(n)+(v-adj(v))/(2j))/2]
    cm = max(op(e @ g-g @ e) for e in es for g in fs)
    clock.append({'n': n, 'unitary_commutator': op(u@v-v@u),
                  'bott': bott, 'effect_cross_commutator': cm,
                  'effect_bound': .5*math.sin(math.pi/n)})
    assert abs(bott-1) < 1e-10
    assert cm <= .5*math.sin(math.pi/n)+1e-10

repairs = []
for m in [2, 3, 4]:
    n, length = m**3, m**2
    u = np.diag(np.exp(2j*np.pi*np.arange(n)/n))
    v = np.roll(np.eye(n, dtype=complex), 1, axis=0)
    d = np.repeat(np.exp(2j*np.pi*np.arange(m)*length/n), length)
    u0 = np.diag(d)
    v0 = np.zeros_like(v)
    for block in range(m):
        for j in range(length):
            v0[block*length+(j+1)%length, block*length+j] = 1
    hs = lambda a: float(np.linalg.norm(a, 'fro') / np.sqrt(n))
    repairs.append({'m': m, 'commutator': op(u0@v0-v0@u0),
                    'u_hs_error': hs(u-u0), 'u_bound': 2*np.pi/m,
                    'v_hs_error': hs(v-v0), 'v_exact': np.sqrt(2)/m})
    assert op(u0@v0-v0@u0) < 1e-12
    assert hs(u-u0) <= 2*np.pi/m+1e-12
    assert abs(hs(v-v0)-np.sqrt(2)/m) < 1e-12

locality = []
for n in range(2, 25):
    for k in range(1, n+1):
        energies = [1-(math.comb(n-w,k) if n-w >= k else 0)/math.comb(n,k)
                    for w in range(1,n+1)]
        gap = min(energies)
        assert abs(gap-k/n) < 1e-12
        locality.append({'n': n, 'k': k, 'gap': gap, 'bound': k/n})

assert max(entropy_errors) < 1e-10
assert max(perfect_errors) < 1e-10
result = {
    'scope': 'Numerical diagnostics only; mathematical proofs are in the notes.',
    'random_correlated_state_jensen_identity_max_error': max(entropy_errors),
    'perfect_correlated_nuisance_increment_max_error': max(perfect_errors),
    'clock_shift': clock,
    'explicit_tracial_hs_repairs': repairs,
    'normalized_locality_saturation_records': len(locality),
    'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
(ROOT/'checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
