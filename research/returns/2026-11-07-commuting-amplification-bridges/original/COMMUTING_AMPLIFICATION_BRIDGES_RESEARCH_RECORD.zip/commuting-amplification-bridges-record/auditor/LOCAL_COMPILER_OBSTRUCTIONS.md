# Exact obstructions to two local-compilation shortcuts

Independent auditor proofs, 7 November 2026. These are restrictions on particular
proposed operations. They do not disprove a local consistency compiler with an
encoding, additional tests and a new soundness proof.

## 1. Small cross commutators do not provide nearby legal POVMs in operator norm

The clock/shift example is the classical Voiculescu obstruction. Exel--Loring
gave an elementary winding proof. The proof below records an explicit constant
and its conversion into two families of binary POVMs, for this programme's exact
legality question; no novelty is claimed for the obstruction.

### Theorem 1

For every integer `n>=7`, there are four effects `E_1,E_2,F_1,F_2` in `M_n(C)`
such that

\[
 [E_1,E_2]=[F_1,F_2]=0,
 \qquad
 \max_{j,k}\|[E_j,F_k]\|\le\tfrac12\sin(\pi/n),\tag{1}
\]

but no four effects `E'_1,E'_2,F'_1,F'_2` with all cross commutators zero can
satisfy

\[
 \max\{\|E'_j-E_j\|,\|F'_k-F_k\|:j,k=1,2\}\le1/32.
 \tag{2}
\]

Thus each pair `{E_j,I-E_j}` and `{F_k,I-F_k}` is a complete binary POVM,
approximate cross commutation tends to zero, and a dimension-independent
operator-norm correction to exact cross commutation is impossible.

### Proof

Let `omega=exp(2 pi i/n)` and, on the cyclic standard basis, put

\[
 Ue_j=\omega^j e_j,\qquad Ve_j=e_{j+1}.
\]

Then `UV=omega VU`, so
`||UV-VU||=|omega-1|=2 sin(pi/n)` and `UVU*V*=omega I`.

First no commuting unitaries `U',V'` can both be within `1/4` of `U,V`.
For otherwise the principal-logarithm geodesics
`U(t)=U exp(t log(U*U'))`, `V(t)=V exp(t log(V*V'))` exist and stay within
`1/4` of their initial unitaries. Indeed the eigenangles are strictly between
`-pi,pi` and `|exp(it theta)-1|<=|exp(i theta)-1|` for `0<=t<=1`.
Writing `W(t)=U(t)V(t)U(t)*V(t)*`, a four-term telescoping estimate gives

\[
 \|W(t)-I\|\le 4(1/4)+2\sin(\pi/n)<2\qquad(n\ge7).
\]

Consequently `W(t)` never has eigenvalue `-1`, and

\[
 b(t)=\frac1{2\pi i}\operatorname{Tr}\log W(t)
\]

is continuous. It is integer-valued, since
`exp(Tr log W(t))=det W(t)=1`. At `t=0` the principal logarithm of `omega I`
gives `b(0)=1`; at `t=1` commutation gives `W(1)=I` and `b(1)=0`. This is a
contradiction.

Now set

\[
 E_1=(I+\Re U)/2,\quad E_2=(I+\Im U)/2,\quad
 F_1=(I+\Re V)/2,\quad F_2=(I+\Im V)/2.
\]

These are effects and their same-side commutators vanish. Each real/imaginary
cross commutator is a sum of four unitary commutators, with coefficients of
modulus `1/4`; each of those has norm `2 sin(pi/n)`. The additional factors
`1/2` in both effects yield (1).

If the approximants in (2) existed, define

\[
 C=(2E'_1-I)+i(2E'_2-I),\quad
 D=(2F'_1-I)+i(2F'_2-I).
\]

Then `||C-U||,||D-V||<=1/8`. Their polar unitaries `U_C,V_D` exist. If an
operator `C` is within `r<1` of a unitary, all its singular values are within
`r` of one, whence `||C-U_C||=|||C|-I||<=r` and
`||U_C-U||<=2r`. Thus here both polar unitaries are within `1/4` of `U,V`.
All cross commutators of the two generated C-star algebras vanish because the
effect approximants are self-adjoint and cross commute. In particular the
polar unitaries commute. This contradicts the previous paragraph. QED.

### An explicit weaker-topology repair

This example does not obstruct tracial two-norm correction. Put `n=m^3` and
partition the cyclic basis into `m` consecutive blocks of length `L=m^2`.
Let `U_0` be constant, equal to `U`'s first diagonal entry, on each block.
Let `V_0` shift cyclically *within* each block. Then `U_0,V_0` commute and

\[
 \|U-U_0\|_{2,\tau}\le2\pi/m,\qquad
 \|V-V_0\|_{2,\tau}=\sqrt2/m\quad(m\ge2).\tag{3}
\]

The first estimate follows from the maximum phase variation within one block.
Only `m` columns of `V-V_0` are nonzero; each has squared norm two, proving
the second. This correction is specific to normalized trace. A vector state
can concentrate on changed block boundaries, so it is not a uniform correction
of all physical correlations.

The constructive lesson is precise: preserve a state-weighted correlation
contract and exact cross commutation from the start, as the opposite-algebra
sampler does. A subsequent operator-norm exactification step is unavailable in
generality. Neither (1) nor (3) refutes that sampler.

## 2. A normalized local Hamiltonian cannot directly represent a global AND

### Theorem 2

On `n` qubits let `Q=I-|0^n><0^n|`. Suppose

\[
 H=\sum_\alpha h_\alpha,\quad h_\alpha\ge0,
 \quad |\operatorname{supp}h_\alpha|\le k,
 \quad \sum_\alpha\|h_\alpha\|\le T,
 \quad H|0^n\rangle=0.
\]

If `H>=lambda Q`, then

\[
 \lambda\le kT/n.\tag{4}
\]

In particular a normalized term budget `T=1` cannot retain constant detection
probability for every nonzero excitation at fixed locality `k`. If the ground
state is unique, its gap is at most `kT/n`.

### Proof

Positivity and zero ground energy imply `h_alpha |0^n>=0` for every term. For
the one-excitation states `e_i=|0...010...0>`, a term with support `S_alpha`
annihilates `e_i` when `i` is outside `S_alpha`. Otherwise its expectation is
at most its norm. Therefore

\[
 n\lambda\le\sum_{i=1}^n\langle e_i,H e_i\rangle
 \le\sum_\alpha |S_\alpha|\|h_\alpha\|
 \le kT.
\]

The gap assertion follows from the variational principle applied to the same
one-excitation states, all orthogonal to the unique ground state. QED.

There is also an exact locality obstruction without any positivity or budget
assumption: `Q` is not a sum of terms of locality smaller than `n`. Its Pauli
coefficient against `Z tensor ... tensor Z` equals `-2^-n`. Every term missing
even one qubit has zero such coefficient because `Tr Z=0` on that unused site.

These are ancilla-free statements. They do not rule out encoded constructions,
additional consistency checks, growing locality, or growing total interaction
strength. They show why the norm-one projector `Q`, or an all-wins product of
accepting effects, is not already a bounded-locality, normalized gap amplifier.
Anshu--Arad--Vidick's established amplification theorem uses coarse-graining and
its explicit locality/geometry assumptions; repetition alone supplies none of
those hypotheses.

## 3. Repetition success does not force coordinate question causality

Take any finite game `G` with independent uniform question bits available to
Alice. Append to her answer an ignored bit, so the new game has exactly the
same commuting values for every product: dropping the bit is an upper bound;
appending a fixed bit is a lower bound. In an `n>=2` product strategy she may
instead put `parity(X_1,...,X_n)` in every appended answer bit, leaving all
winning probabilities unchanged.

For any candidate table whose `i`th appended output law depends on Alice's
question string only through `X_i`, its mean total-variation error on that bit,
relative to the parity table, is exactly `1/2` under uniform questions. Indeed
the parity of the other `n-1` bits is a fair independent bit given `X_i`, so
averaging the distance from any fixed Bernoulli law to the two point masses is
`1/2`. Shared randomness or an input-independent quantum resource cannot change
this marginal conditional-independence argument.

This tests an attempted structural inference, not the repetition bound.
Existence of a successful repeated strategy does not provide coordinatewise
input dependence or a local observable decoder for its entire fine-answer
table. A compiler must either quotient this redundancy explicitly or prove a
separate observable-level reconstruction theorem. The R/H/S value extraction
does not assert such tablewise coordinate causality.

## 4. Primary predecessors inspected

- Ruy Exel and Terry A. Loring, *Almost commuting unitary matrices*, Proceedings
  of the American Mathematical Society 106 (1989), 913--915. Author-hosted paper:
  <https://mtm.ufsc.br/~exel/papers/Almost-commuting-unitary-matrices.pdf>.
  This is the predecessor for Theorem 1; the proof above is given in full.
- Exel--Loring, *Invariants of almost commuting unitaries*, JFA 95 (1991),
  364--376, DOI <https://doi.org/10.1016/0022-1236(91)90034-3>, identifies the
  established K-theory/winding invariant. No broader stability theorem is
  imported.
- Anurag Anshu, Itai Arad and Thomas Vidick, *A simple proof of the detectability
  lemma and spectral gap amplification*, arXiv:1602.01210v2, Section 4 and
  Theorem 5: <https://arxiv.org/html/1602.01210v2>. The coarse-graining theorem
  is a comparator, not an imported compiler for arbitrary commuting games.
