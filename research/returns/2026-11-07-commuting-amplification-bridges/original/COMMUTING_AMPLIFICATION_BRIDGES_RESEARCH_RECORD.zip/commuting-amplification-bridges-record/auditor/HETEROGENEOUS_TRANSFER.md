# A direct heterogeneous transfer from the original iid repetition theorem

Independent auditor derivation, 7 November 2026. This is an elementary transfer
of the supplied original theorem, not a new replacement for its proof and not a
claim of historical novelty. It does not consume `FR(K)`.

## The model and the imported theorem

Let `co` mean arbitrary two-player commuting strategies on arbitrary Hilbert
spaces, including arbitrary joint measurements on complete question strings.
Questions may be correlated within a coordinate. Different coordinates are
sampled independently.

The exact imported capital is: for every finite Boolean two-player game `M`,
with `e=1-omega_co(M)` and `ell=log(|A_M||B_M|)`,

\[
 \omega_{\rm co}(M^{\otimes k})
 \le \exp\{-c k f(e,\ell)\},\qquad
 c=2^{-75},\quad f(e,\ell)=\frac{e^3}{e+\ell}.
 \tag{1}
\]

Use `f(0,0)=0`; if `e=0` the bound is one. This theorem is supplied mathematical
capital at its stated scope. The proof below only invokes (1) for an explicitly
constructed finite labelled mixture.

## Theorem 1: labelled-mixture transfer

Let `G_1,...,G_N` be arbitrary finite two-player Boolean games. Write
`epsilon_i=1-omega_co(G_i)`. For any probability vector `r=(r_i)` let

\[
 J=\{i:r_i>0\},\quad r_* =\max_i r_i,\quad
 e_r=\sum_i r_i\epsilon_i,
 \qquad
 \ell_J=\log\left(\max_{i\in J}|A_i|\,
                         \max_{i\in J}|B_i|\right).
\]

Then

\[
 \boxed{\quad
 \omega_{\rm co}(G_1\otimes\cdots\otimes G_N)
 \le \exp\left\{-\frac{2^{-75}}{r_*}
                    \frac{e_r^3}{e_r+\ell_J}\right\}.
 \quad}\tag{2}
\]

The bound can be optimized over `r`, including distributions supported on a
proper subfamily. In particular every nonempty `J` gives

\[
 \omega_{\rm co}(\bigotimes_{i=1}^N G_i)
 \le\exp\left\{-2^{-75}|J|
          \frac{\bar\epsilon_J^3}{\bar\epsilon_J+\ell_J}\right\},
 \quad \bar\epsilon_J=|J|^{-1}\sum_{i\in J}\epsilon_i.
 \tag{3}
\]

These are upper bounds on arbitrary joint product-game strategies, rather than
only product-algebra strategies. They do not multiply upper bounds for separate
subproducts.

### Proof: the mixture has the required exact gap

Construct `M_r` by first drawing `i~r`, then the question pair of `G_i`; send the
label `i` to both players together with their respective question. Pad Alice's
answer alphabet to `max_J |A_i|` and Bob's to `max_J |B_i|`. An answer outside the
active game's legitimate alphabet loses. This changes no legitimate game value.

A fixed strategy for `M_r`, restricted to the input label `i`, is a legal
commuting strategy for `G_i`. Therefore its payoff is at most
`sum_i r_i omega_co(G_i)`. Conversely, take a finite tensor product of
arbitrarily near-optimal commuting resources, one per game, and let each player
use the resource for the received common label. The fixed enlarged algebras
commute on every pair of inputs. Sending the finitely many accuracies to zero
proves

\[
 \omega_{\rm co}(M_r)=\sum_i r_i\omega_{\rm co}(G_i)=1-e_r.
 \tag{4}
\]

No optimizer or finite-dimensional strategy is assumed. The new information is
in the questions, so the answer charge in (1) is exactly `ell_J`.

### Proof: the exact legal embedding

Fix an arbitrary strategy for `H=G_1 tensor ... tensor G_N` of all-wins
probability `theta>0`. Let `T` be a positive integer and take `T` independent
copies of its shared resource and its `N`-coordinate joint measurements. When
all `NT` coordinates are independently sampled, the probability every copy of
`H` wins is exactly `theta^T`.

Fix `0<delta<1` and put

\[
 k_T=\left\lfloor\frac{(1-\delta)T}{r_*}\right\rfloor.
\]

In `M_r^{k_T}`, the common label string is `I=(I_1,...,I_{k_T})`. Let `B_T` be
the event that each label occurs at most `T` times. Both players know `B_T`
from their own received label string. If `B_T` holds, assign the successive
occurrences of label `i` to cells `(i,1),(i,2),...` in a fixed array of `N*T`
original-game coordinates. Put each actual fresh question in its assigned cell.
In every remaining cell use a previously shared independently sampled dummy
question pair with the appropriate law `mu_i`.

Each player sends the resulting complete *local* question string for row/copy
`t` into the corresponding original `H` strategy. They return, at each actual
mixture coordinate, its assigned original answer. This is a local operation:
the common labels specify the cell assignment, while Alice's inserted fresh
questions are only Alice's and Bob's are only Bob's. The dummy pairs are shared
randomness fixed independently of all fresh inputs. A player may know the
other side's dummy question, but the prescribed measurement ignores it.

For a fixed good label string, the full array of inserted fresh and dummy
question pairs has exactly law `product_{i,t} mu_i`. Hence the full-array event
that every original `H` copy wins has probability `theta^T`, and this event
implies every actual mixture coordinate wins. On bad label strings use any
complete local default measurements. It follows that the constructed strategy
has score at least

\[
 \omega_{\rm co}(M_r^{\otimes k_T})
       \ge \Pr(B_T)\theta^T.\tag{5}
\]

For completeness, all these operations are complete coarse-grainings of the
original full-answer POVMs, conditional on local labels and shared classical
dummy data. All Alice effects continue to commute with all Bob effects,
including unsupported inputs in which their label strings differ. Define the
same local rule on such inputs, with arbitrary local defaults if necessary.
Thus a pairwise choice of resource, communication, or postselection is absent.

Since `k_T r_i <= (1-delta)T`, the weak law of large numbers, or a binomial
Chernoff bound followed by a finite union bound, gives `Pr(B_T)->1`. In
particular `T^{-1} log Pr(B_T)->0`. Apply (1) to (5), divide logarithms by `T`,
and let `T` tend to infinity:

\[
 \log\theta\le
 -\frac{(1-\delta)c}{r_*}f(e_r,\ell_J).
\]

Then let `delta` decrease to zero. This proves (2) for every actual strategy;
take the supremum over `theta`. The case `theta=0` is immediate. Uniform `r`
on `J` gives (3). QED.

## A useful dyadic corollary

Suppose all positive gaps lie in `[epsilon_min,1]` and the padded answer charge
is at most `ell`. Let `B=1+floor(log_2(1/epsilon_min))`. Partition positive gaps
into the at most `B` nonempty dyadic bins
`(2^{-j-1},2^{-j}]`, assigning endpoint gaps consistently. In each bin the
maximum gap is at most twice the minimum. Since `f(x,ell)` is increasing and

\[
 f(2x,\ell)\le8f(x,\ell),
\]

we have

\[
 |J| f(\bar\epsilon_J,\ell)
 \ge\frac18\sum_{i\in J} f(\epsilon_i,\ell).
\]

Choose the bin carrying the largest sum on the right. Equations (2)--(3) imply

\[
 \omega_{\rm co}(\bigotimes_iG_i)
 \le\exp\left\{-\frac{2^{-78}}{B}
                \sum_i\frac{\epsilon_i^3}{\epsilon_i+\ell}\right\}.
 \tag{6}
\]

The convention is that zero-gap coordinates contribute zero and may be
discarded. This logarithmic range loss is explicit. It is not the fully
intrinsic sum-rate target and does not prove the conditional quadratic
heterogeneous claims in the previous dossier.

## What this repairs, and what it does not

This supplies a genuine heterogeneous bound with no additional `FR(K)` premise,
using the original accepted iid theorem alone. For comparable gaps and common
bounded answer alphabets it has the expected cubic scale. It does not prove a
quadratic rate for projection games, remove the answer charge, optimize
thresholds, produce matrices, or give a local Hamiltonian compiler. The original
constant `2^-75` has been retained, not improved. This simulation is elementary;
historical priority is unestablished. General heterogeneous products are already
studied, for example by Dinur--Steurer for classical projection games; that
classical theorem is not imported as a commuting theorem here.
