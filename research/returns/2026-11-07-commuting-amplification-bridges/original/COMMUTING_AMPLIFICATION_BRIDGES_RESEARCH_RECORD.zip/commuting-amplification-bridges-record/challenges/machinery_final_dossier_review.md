# Final machinery/source review of the amplification dossier

7 November 2026. Focused final checking, after the frozen independent investigation and substantive cross-challenges. No dossier or initial report was edited by this reviewer.

## Version reviewed and disposition

The reviewed dossier is outputs/COMMUTING_AMPLIFICATION_BRIDGES_RESEARCH_DOSSIER.md, SHA256 39513d26b9a8ec2128e4119337462ca71174568eec09f2fe56d9c4edfe89ac64. The accompanying challenges/principal_final_proof_checks.md has SHA256 1ad5be0a759b55fd8c39d6164c63fa1f6a79e121ea9b6269ac8c64e40b509d18. My initial report still has SHA256 c0da194c7c94e2ed40220d10494cfcc520760280368230cc398a4a980ba2409d.

**Disposition:** the central finite-tracial reconstruction, its one-target/two-parent charged application, positive-slack limit, finite-trace measured-fidelity bridge, and continuous actual-mass scalar closure pass this final check. I found no theorem-level counterexample or missing operation at their stated scopes. The three corrections below should be made to prevent a false conditional quantifier, an operational overreading of Lin, and one incorrect citation label. They do not require weakening the final mathematical conclusions.

## Corrections required in the reviewed version

1. **Section 6.1, after (6.3): distinguish conditional and averaged masses.** The displayed quantity is \(G_{A,c}\). The correct inequalities are
   \[
   G_{A,c}\ge p_c,\qquad G_{B,c}\ge p_c,\qquad
   G_A=\mathbb E_{\mu_D}G_{A,c}\ge p_D,\quad
   G_B=\mathbb E_{\mu_D}G_{B,c}\ge p_D.
   \]
   The sentence saying the displayed masses “are at least \(p_D\)” is false if read for each \(c\). A branch of zero conditional success can have \(G_{A,c}=0\) although \(p_D>0\). The logarithms in (6.2) involve the averaged masses, whose positive lower bound at fixed \(p_D>0\) is sufficient. Say their **arguments** stay bounded away from zero, rather than the logarithms themselves.

2. **Section 6.2: state the finite-tracial quantifier before using operational witnesses.** The paragraph starts with “an actual repeated strategy,” then mixes the extracted strategies and uses their raw \(t_i\). Those objects have only been constructed for a finite-tracial input strategy. The clean repair is: first take an arbitrary finite-tracial repeated strategy; perform the entire greedy contradiction there; obtain the uniform scalar all-wins bound; apply Lin to that scalar payoff bound. Alternatively derive the contradiction entirely from (6.2). The current wording should not imply that raw extracted strategies or descriptors survive the table-closure limit. The tensor proof already correctly starts in finite matrices and uses its own gap.

3. **Section 12, Kulpe et al.:** the exact labels in arXiv:2408.06711v3 are **Theorem 6.1 and Corollary 6.2**, not “Theorems 6.1–6.2.” The fixed-game/QPT/asymptotic scope attributed to them is otherwise correct.

## Checks of Sections 3–5

### Conditional comparisons and the physical corner

Equation (3.2) allows an arbitrary positive normalized seed. Its local input law need not agree with the target law. This is essential for actual-mass normalization, and the proof of (4.8) does not silently reintroduce marginal agreement: its Cauchy–Schwarz step uses only normalization of the comparison law \(r_x\mu(y|x)\). Alice's comparison aligns the common pure target; Bob's independently chosen comparison bounds variation of the same target's right marginal. No common reference purification is required.

For an explicit statement of the physical corner, let \(X_y=\{x:\mu(x,y)>0\}\). The full algebra for Alice is

\[
\mathcal A=\bigoplus_{y\in\operatorname{supp}\mu_Y}M_{X_y}(\mathcal N).
\]

The retained algebra is the \(X\)-diagonal copy of \(\bigoplus_x\mathcal N\), extended to each permitted \(y\) block. Thus \(r,n\) and \(L_s\) are \(X\)-block diagonal; they preserve this corner and commute with the scalar conditional-amplitude factors. No unrestricted inverse of a zero-supported \(X,Y\) matrix is used. A diagonal seed with strictly positive mass on every supported \(x\) supplies a conditional comparison \(\nu_0\) bounded below on \(\mathcal A\). The phrase “supported finite-question corner” is correct; giving this explicit formula would make its load-bearing meaning unambiguous. “\(K\) is classical in \(X\)” means its \(X\) control is classical, while its residual algebra can be quantum and infinite dimensional.

The half-four-log specialization of Junge–LaRacuente has the order required in (4.2): after taking \(p=2\), squaring, applying scalar Jensen, and using cyclicity/reflection of the even \(\beta_0\) weight, the right side is precisely \(\int\beta_0(s)\tau(WL_s\nu L_s^*)ds\). The retained marginal of each summand is \(r\). This is an actual finite-von-Neumann-algebra application, with bounded logarithms at each positive slack.

### Positive slack and measured fidelity

The direct proof in principal_final_proof_checks.md is sound. For bounded \(\rho,\nu\) of finite relative entropy, mixing each with the same \(\nu_0\ge cI\) makes the \(x\log x\) entropy terms converge by uniform continuity. For the cross term, operator monotonicity provides one limit inequality; at fixed \(\delta>0\), \(\log(\nu_\eta+\delta I)\) converges in operator norm and its decreasing regularizer gives the other. The extra \(\eta\nu_0\log\nu_\eta\) term is \(O(\eta(1+|\log\eta|))\). The retained marginal has the same proof. Full and retained finite divergences therefore converge **separately**, so their difference is legitimate. There is no normal-state compactness assertion and no claim of inverse-power convergence at zero.

The replacement at positive slack is also boundedly invertible. Explicitly, if \(\nu_\eta\ge c_\nu I\), \(r_\eta\ge c_rI\), and \(n_\eta\le M_nI\), then uniformly in \(s\),

\[
\|L_s^{-1}\|\le\sqrt{M_n/c_r},\qquad
L_s\nu_\eta L_s^*\ge(c_\nu c_r/M_n)I.
\]

This justifies applying the faithful finite-trace fidelity argument to the integrated replacement. Its positive operator \(H\) obeys \(H\rho H=\widetilde\nu\) and \(\tau(\rho H)=F(\rho,\widetilde\nu)\). On increasingly fine finite spectral partitions of bounded invertible \(H\), the classical fidelities converge to that trace. Jensen then gives \(D_{\rm meas}\ge-2\log F\). The measured-entropy variational formula follows from operator concavity of log and spectral step approximations. Finally, the uniform trace Hölder bound against **any** normalized varying replacement proves the passage from \(\rho_\eta\) to the original target. None of these steps assumes a matrix algebra.

### Common amplification, locality, and sampling

The row purification (4.6) and block rows (4.7) yield one right polar \(U_y\) independent of the external coherent \(x\) row. Its all-input Bob effect really is \(U_y^*B_yU_y\). The left polar \(J_x\) acts on the other side. Finite padding gives unitary completions, and left/right actions commute on **every** input pair. Trace normalization rescales vectors consistently. The Hölder \(4,2,4\) estimate and the canonical square-root descriptor bound are correct.

The standalone sampler import is still necessary. Its Section 8 controls the actual unconditional fine-output protocol and the rare losing event, with the stated source hash. It is stronger than a mean-TV statement. At zero descriptor discrepancy, interpret the displayed \(h=D_{\rm desc}^{1/4}\) choice by a positive \(h\downarrow0\) and sufficiently small subsequent errors; no protocol uses \(h=0\). This is already covered by the sampler source but can be said explicitly in §4.3. The fresh-law Hellinger reverse triangle applies to the same all-input losing function. The coefficients \(152,5776<65536\) are correct.

### One target and two one-sided parents

Equation (5.4) has norm one at each \(p_c>0\), and its fine table is exactly the original table conditioned on the checked wins: orthogonality removes cross terms and the exact fractional partition sums to the Boolean mask. The coefficient is \(\sqrt{w_l}\), not \(w_l\). The separately chosen parent states never multiply their two weights.

Alice's domination is the positive matrix congruence \(ZZ^*-ZQ_TZ^*=Z(I-Q_T)Z^*\ge0\) in a finite matrix algebra over \(\mathcal M\). This remains valid for a type-II finite algebra. Bob uses the opposite algebra with the corresponding order. The uncompleted seed normalized by actual \(G_{A,c}\) or \(G_{B,c}\) is a valid conditional comparison; no physical local preparation of that reference is needed. The private common-label copy lies in the retained algebra. Hence Donald's identity has a zero conditional-mutual-information label term, including question-correlated labels. All external copies are omitted from reference parents.

The exact tilted-law identity (5.7) is correct, including its entropy remainder. The actual masses are representation-independent finite linear one-sided table functionals. Only averaged quantities enter the logarithmic scalar budget. They converge under full finite-table approximation at fixed \(p_D>0\); raw witnesses are eliminated first. The unconditional \(d_i\) sum is at most \(L\). The parity fixture rules out a conditional-history replacement of this claim but does not attack the full-workspace construction.

## Minimal proof spine and scope

The minimal spine is: copied-input entropy/direct-sum identities; the common weighted target and two one-sided positive parents; finite-trace four-log replacement at positive slack; explicit common-amplification polar correction; the standalone actual sampler; fresh-law Hellinger transfer; scalar elimination and Lin closure; scalar repetition allocation. The old resolvent production \(R\) and a separately prepared history protocol \(H\) are both unnecessary. Histories are inside the one global target to which reconstruction is applied.

Operational witnesses, including actual-mass-normalized comparisons, are proved for finite-tracial inputs. Arbitrary commuting inputs receive the resulting scalar table inequalities through Lin. A separate finite-matrix construction yields the tensor theorem with \(\epsilon_*\). Neither matrix density, tensor/commuting equality, finite hierarchy convergence, uniform resources, nor a physical implementation follows. The charged result closes the old FR premise at exact positive fractional partitions; it does not make general predicate charges small and does not prove general quadratic repetition.

## Primary-source/version checks

The following exact source checks were made in this branch, with the final spot checks noted where relevant:

| Source | Checked statement/hypotheses and disposition |
|---|---|
| Jain 2610.21410v1 | Definitions 2.6/2.8, Lemmas 2.24–2.25 and 4.1–4.2 are the finite-tensor copied-input/allocation/local-description predecessors. The new proof does not silently promote them to arbitrary algebras; the extension is supplied explicitly. |
| Junge–LaRacuente 2009.11866v2; JMP 63, 122204 (2022) | ArXiv Theorem 1.2 / published Theorem I.2 assumes bounded Hermitian operators and a faithful full-support \(L^1\) reference. The finite-trace identity reference and positive-slack logarithms satisfy it. Reopened the published primary PDF: measured variational formula is indeed Lemma VI.2; arXiv numbering is 6.2. |
| Lin 2304.01940v3 | Definition 3.1/Theorem 3.2 is full finite correlation-table closure of finite-tracial standard-form strategies in \(C_{qc}\), not finite-matrix density. The bounded starting vector and scalar continuity are respected. |
| KRT 0710.0655v3 | SDP 3, Lemma 5.7, Theorems 5.2/5.5 supply the stronger unique-game quadratic predecessor; their finite SDP applies to commuting Gram vectors. Their finite tensor rounding remains a valid lower bound on commuting value. No unique-game novelty is claimed. |
| DSV 1310.4113v2 | Theorem 1 gives the stated projection tensor gap power (at most 12), with the stronger linear-gap expanding conclusion in this version. It supplies no commuting/tensor equality. |
| Lin 2510.07162v1 | Theorem 9.3/A.1 is anchored commuting repetition; Theorem 1.1 already gives \(\mathsf{MIP}^{co}=\mathsf{coRE}\). The dossier preserves both scope and priority. |
| Kempe–Regev 0911.0201v1 | Definition 3.1, Theorem 3.2, Theorem 4.4 give fixed binary answers, gap \(1/(2n-1)\), and a repeated classical lower bound of quadratic gap order. Matching classical/no-signalling values give the commuting gap by sandwiching. |
| Gupta–Wilde 1310.7028v3 | Reopened Lemma 5/(5.16), minimax (5.19)–(5.20): exact unchanged-reference marginal orientation, every \(\alpha>1\). Lemma 6 is additivity. No input-dependent choice of replacer is used in the interactive telescope. |
| WBHK 1808.01498v2 | Reopened Proposition 41/(283): arbitrary finite channel versus a fixed replacer, \(\alpha>1\), and arbitrary **different** \(\rho_{RA},\sigma_{RA}\). This supplies the feedback/reference-memory hypothesis used by §8. It does not claim general-channel amortization collapse. |
| Li–Yao 2209.00555v3 | Reopened Theorem 6: exact entanglement-assisted strong-converse exponent for every finite channel and rate. Its feedback discussion is §III-C. The dossier credits the solved coding exponent rather than claiming a new coding theorem. |
| Kulpe et al. 2408.06711v3 | Reopened Theorem 6.1 and **Corollary** 6.2: fixed game, each QPT strategy, asymptotic security limit. Growing-game and security limits are not exchanged. |
| Cui et al. 2507.17581v1 | Reopened Theorem 3.5: a fixed nice-SoS certificate yields a strategy-dependent negligible compiled excess. Certificate costs are not uniformly polynomial. |
| Klep et al. 2507.17006v3 | Reopened Theorem 2.7/Corollary 2.8: fixed hierarchy level, level-dependent negligible term; finite-level convergence gives commuting excess; flat optimality gives tensor identification/extraction via Theorem 3.4. A finite-dimensional optimizer alone is not substituted for either premise. |

The recovery-norm counterexample remains valid at Bhattacharya 2605.08829v1's inspected hypotheses. The two Zenodo records are not conflated: 22061117 was read and supplies no explicit counterexample to this reconstruction; 22060622 remains unread after HTTP 410. The arXiv greedy-polarity objection was withdrawn in current 2608.14673v3; its superseded version is not a surviving objection. None of these source checks awards historical firstness.

Subject to the three exact corrections above, I accept the dossier at its stated scopes. The optional corner/invertibility/zero-discrepancy sentences make already proved details explicit; they do not supply an additional hypothesis.

## Concurrent integration check

A subsequent read of dossier SHA256 145c1f6296c78909c4c1e96077610012cc285efd1bc888ae3b254d454102bc47 confirmed that the principal had already corrected the finite-tracial operational quantifier and the Kulpe citation label. In its newly explicit common-charge greedy proof, use the stopping rule “test any live coordinate with conditional loss exceeding \(\epsilon/2\) until none remains.” The preceding block proof instead allows stopping when the mean live loss is at most \(\epsilon/2\); that mean criterion is insufficient for the new per-coordinate inverse-deficit lower bound. With the stated any-coordinate stopping rule, the charge calculation and denominator are correct. This is a precision of that newly written proof, not a new mathematical operation.
