# Constructor final correctness review of the consolidated dossier

7 November 2026. No dossier or frozen initial report was edited.

Reviewed `outputs/COMMUTING_AMPLIFICATION_BRIDGES_RESEARCH_DOSSIER.md`,
816 lines, 64,755 bytes, SHA256
`39513d26b9a8ec2128e4119337462ca71174568eec09f2fe56d9c4edfe89ac64`.
Scope: Theorem B summary, §§8–10, and the central weighted-target/parent
construction in §5, checked against the constructor's completed proofs and
retained tests. This is final correctness verification, not an additional
research round.

## Disposition

**The mathematical formulas and positive constructions pass at the stated
finite-order and arbitrary-commuting maximum-order scopes.** There is one
hypothesis that should be made explicit in the standalone Theorem B statement,
and one negative assertion whose wording should be restricted to what its
counterexample actually establishes. Neither requires changing a formula or
reopening the positive proof.

**No other fatal concern was found in the reviewed scope.** This disposition
applies to the precise SHA256 version pinned above, subject to the two agreed
wording corrections below; it is not an unversioned approval of later edits.

## 1. Explicit hypothesis needed in the standalone Theorem B statement

At line 27, “arbitrary prior entanglement” should explicitly be independent
of the referee questions. The zero-source-cost bound (B) assumes

\[
 \rho_{UAB}^{\rm initial}=\mu_H(U)\otimes\sigma_{AB}.
\]

The local question copies are then delivered through the same controlled
CPTP map in the two comparison executions. The §8.1 proof uses this
independence when concluding that the all-replacer execution is a legal
zero-communication game strategy. It is also assumed by the §8.3 capacity
criterion without a source cost.

Suggested concrete insertion into Theorem B: “Their initial resource is
independent of the referee questions; initial correlations are treated in
§8.2.” Without that hypothesis a source can preload Bob with Alice's uniform
guessing string, giving acceptance one with no message channels despite
`q0=2^-n`.

This is an omitted explicit hypothesis, rather than a defect in the supplied
proof: the proof and separate source section already implement the correct
model. Ordinary game terminology often implies it, but the distinct source
extension makes the explicit sentence important.

## 2. Scope precision for the hockey-stick paragraph

At lines 624–626 the two-dimensional example correctly proves that an
operational hockey-stick defect `eta` does not imply a normalized dominated
state within trace distance `eta`. Therefore the source interfaces cannot be
silently identified, and (8.4) is a valid unamplified-error consequence.

The sentence “One cannot move h inside the Rényi factor at nonzero defect
without a stronger hypothesis” is broader than the displayed counterexample
alone proves: that example disproves the proposed same-error smoothing
conversion, not every conceivable direct inequality with an inside-h term.
The positive proof does not need that stronger impossibility assertion.

Suggested scope-tight wording: “This interface directly yields (8.4).
Moving h inside the Rényi factor is not justified by the normalized-smoothing
argument: the two smoothing notions are not equivalent.” The existing
two-dimensional calculation then proves exactly the stated warning.

## 3. Additional small definitions that would make scope fully explicit

These are clarifications of already correct formulas, not new assumptions:

- At the sandwiched-divergence definition, specify support-restricted inverse
  powers and divergence `+infinity` when the actual support is not contained
  in the comparison support. Finite `J_alpha` therefore requires the actual
  referee law to lie in the reference support.
- In §8.2, let `A,B` denote the initial device resource before delivery of
  ordinary local question copies. The displayed source cost can include
  both source/device correlation and a changed question law; the comparison
  uses the prescribed `mu_H`. Including legitimate input copies in the
  charged resource would give a valid but unnecessarily weaker estimate.
- State explicitly that the `t` answer-record edits occur after the
  interaction and that the referee retains its original questions. The
  pointwise `r+t` failure implication then has exactly the proved scope.
- If retaining the optional completion paragraph in §5.3, the failure
  sentinel can be copied into the external as well as private label records,
  ensuring that tracing external records dephases success/failure. The
  actual central successful-parent normalization does not need a failure
  completion at all, so this is not a gap in (5.5)–(5.10).

## 4. Central §5 construction: pass

The dossier faithfully incorporates the proved operation:

1. Equation (5.4) uses one factor `sqrt(w_c,l)` in the common target.
   Summing the orthogonal label probabilities gives the exact Boolean
   predicate, including losing cells. All original questions and full fine
   outputs have precisely the original event-conditioned measured table.
   Changed unmeasured coherences are permitted because Theorem C takes an
   arbitrary copied-input target. The original local answer-record
   projectors remain valid local measurements.
2. At fixed `c,y,l`, the stated matrices obey
   `S_l-T_l=Z(I-Q_T)Z*>=0` in the finite matrix algebra over the original
   algebra. The one-sided local completion has contraction norm at most
   one. No illegal simultaneous weighting and no same-algebra interchange
   is used.
3. The uncompleted positive seed divided by its actual mass is a normalized
   conditional comparison. Its local X marginal may differ from both the
   original marginal and the target marginal; this is permitted by (3.2)
   and was preserved in the common-amplification proof. The analogous Bob
   seed is independently chosen. Their compatibility as margins of one
   preselection state is not an assumption of the preparation theorem.
4. Retaining the private label in each retained local workspace makes the
   Donald/direct-sum cancellation exact. The charge is
   `log(G_A,c/p_c)` and its Bob analogue. All supported normalized blocks
   have finite full divergences by the displayed operator domination.
5. Equation (5.7) is exact, with the deficit equal to the relative entropy
   to the tilted law `mu_D(c)G_A,c/G_A`. It does not replace a posterior
   expectation by a prior expectation. The raw matrix formula defines
   `G_A,c` even when `p_c=0`; only normalized targets/comparisons on such
   zero-target branches are omitted.
6. The coordinate targets are views of the same refined pure family for
   the fixed tested set. Ordered allocation keeps its inherited comparisons
   fixed, histories remain inside the prepared workspace, and (5.9) uses
   unconditional coordinate question drift. Consequently the total budget
   in (5.10), and then (5.11), match the charged FR condition exactly.

The stronger actual-mass formulation is correctly retained before the
presentation-load upper bounds. It does not assert that those masses are
universally small, so §10.5 and the surviving general-quadratic barrier are
consistent with §5.

## 5. Theorem B, source profile and capacity criterion: pass

At the independence scope in §1 above, the §8.1 proof matches the checked
imports: Gupta–Wilde Lemma 5 uses the untouched reference marginal, and
Wilde–Berta–Hirche–Kaur Proposition 41 allows different inputs and arbitrary
finite retained memories at each slot. The same local CPTP maps are used
in both executions. Fixed replacers work on all input states and at every
history, including after feedback. The final binary inequality has the
correct factor `alpha/(alpha-1)` and yields (B).

The finite-dimensional ordinary-quantum communicating scope is preserved.
Using the larger commuting value as the zero-communication comparator is
valid. No finite-order arbitrary-von-Neumann communicating theorem or matrix
density assertion has been inserted. The maximum-order extension is
separately restricted to the explicitly admissible commuting-start local
instrument model, where complete positive order is reference-uniform.

Equation (8.3) correctly includes the actual initial cq source divergence
before question delivery in the same telescope, at the **same order** as
every channel term. Trace-distance smoothing is applied to the complete
protocol once; (8.4) likewise applies the operational source defect before
channel comparison. The additive `eta` is not amplified.

The fixed finite family, prescribed directions/use counts, independent
inaccessible environments and full signal accounting in §8.3 are the needed
conditions. Continuity at order one then supplies a fixed order and positive
exponent whenever the strict capacity-rate inequality holds. The warning
that `J_1/n` alone is insufficient for general n-dependent sources is correct
and necessary; the rare-leak fixture establishes it.

## 6. Threshold edits and constants: pass

With nonnegative integer tolerances `r,t` and post-interaction answer-record
edits, acceptance implies at most `r+t` original failures. Taking
`delta=epsilon-(r+t)/n>0` gives an original score at least
`ceil((1-epsilon+delta)n)`, with no rounding loss.

The inherited general exponent in (2.2) is therefore

\[
 2^{-78}\delta^5/[\epsilon^2(\delta+\log(|A||B|))].
\]

For identical blocks, `S=n epsilon^2`, and the weighted threshold parameter
is `r_rel=delta/epsilon`. Thus (6.7) gives

\[
 2^{-85}r_{rel}^5S/n=2^{-85}\delta^5/\epsilon^3,
\]

exactly the displayed rate. Perfect honest completeness with tolerance at
least the number of edits, and supremum-one completeness as a supremum,
are stated without assuming a noisy honest quantum implementation.

## 7. Erasure example and code costs: pass

Equation (9.1) has the correct reference-fixed orientation and exact formula.
The pure-state Schmidt bound supplies one side, and joint twirling of the
maximally entangled input supplies the other. The scalar minimization is
correct. The separate CP primal/dual certificate agrees with its limit.

For `0<g<=1/4`, survival `3g/(8 ln2)` lies in `(0,1)`. At order `4/3`, the
cost is less than `15g/16`, giving exponent at least `g/64`; meanwhile the
maximum-order cost exceeds g. The dossier correctly restricts this to a
formal resource comparison and retains its extreme-noise cost.

In the guessing fixture the exact zero-communication value is `2^-n`.
For survival `1/10` and `4n` forward slots, optimization gives
`4^u=9/7` and exponent `4 D_bin(1/8||1/10)` with the stated decimal value.
The lower bound for even n is correct: conditional on exactly `n/2`
survivors, the retained rows form an iid square binary matrix with
invertibility probability at least `9/32`; its binomial probability gives
the displayed polynomial prefactor.

The accounting `4n` qubits, `4n` EPR pairs, `8n^2` shared independent random
bits, quadratic encoding work and cubic binary elimination work is faithful
to the executable randomized construction. No deterministic-code search is
silently charged as free. The executable artifact is accurately described
as a logical simulation, and established Li–Yao coding exponents are credited.

## 8. Counterexample summaries: pass at their stated scopes

- §10.1's pair-mixing operator has eigenvalues approaching one off its fixed
  subspace. The displayed L2 operator-norm difference is exactly one at
  every positive power, while strong convergence holds. The counterexample
  and its spectral-gap repair are mathematically consistent.
- §10.2's independent rare branch gives expected communication one bit,
  mutual information `ln2`, and success at least `1/n`. Vanishing
  source/device trace-distance dependence does not repair the missing
  exponential tail control.
- §10.3's unchanged-input-law postselection gives the PR box and does not
  define a legal commuting strategy. The CHSH upper bound is correct.
- The positive ancilla-free Hamiltonian bound in §10.4 follows because every
  positive term annihilates the vacuum and contributes on at most k
  one-excitation states. Its stated exclusions preserve the proof's scope.
- The clock/shift obstruction is summarized with its operator-norm topology
  and established predecessor attribution. It does not contradict the exact
  opposite-algebra construction or a tracial-two-norm approximation.
- §10.5 does not turn the older positive-filter obstruction into a
  disproof of general quadratic repetition or of the present charged
  theorem.

No new tests were needed for this final textual verification: the inspected
statements match the already retained exact arithmetic and operator
diagnostics. The general proof conclusions rest on the written arguments,
not on those finite checks.
