# Hostile review of the interactive Renyi communication bound

7 November 2026. Reviewed `principal_renyi_bridge.md` P3--P6 and the exact
primary sources. **Disposition: PASS for the stated finite-dimensional,
fixed-memoryless-channel, all-cross-cut-communication-accounted model.** The
proof tolerates arbitrary local adaptation and interaction in either prescribed
direction. It uses the commuting value as an upper comparator for the ordinary
zero-communication tensor strategy; it does not define a communicating arbitrary
commuting-operator model.

## 1. Exact imported inequalities

Wilde--Berta--Hirche--Kaur, arXiv:1808.01498v2, Proposition 41, equation (283),
states sandwiched-Renyi amortization collapse for every `alpha>1` when the
comparison channel is a replacer:
<https://arxiv.org/html/1808.01498v2>. Its proof explicitly takes two different
arbitrary input states `rho_RQ,sigma_RQ`. Therefore the required inequality is

\[
 \widetilde D_\alpha((id_R\otimes N)(\rho)\|
                              \sigma_R\otimes\zeta)
 \le\widetilde D_\alpha(\rho\|\sigma)
                   +\widetilde D_\alpha(N\|R_\zeta).\tag{1}
\]

This is exactly the real-input versus comparison-input pair produced by
feedback. The reference can include the referee, all question copies,
opposite-side laboratories, local workspaces and saved outcomes. It is not
restricted to the emitted marginal. Collapse for two arbitrary channels is
neither stated nor needed.

Gupta--Wilde, arXiv:1310.7028v3, Lemma 5, equations (5.16)--(5.22), exchanges
the input supremum and output-state infimum for every `alpha in (1,infinity)`:
<https://arxiv.org/html/1310.7028v3>. The exact minimax exchange is (5.20);
(5.19) is the preceding displayed expression. In the source's orientation,
the fixed marginal is the untouched input reference, agreeing with P3. Hence

\[
 I_\alpha(N)=\inf_\zeta\widetilde D_\alpha(N\|R_\zeta).
 \tag{2}
\]

The reference of dimension `dim Q` in this channel quantity does not limit the
large reference in (1): the latter inequality is reference-uniform. Finite
channels and full-rank replacers have finite costs, and arbitrarily small
full-rank perturbation slack is permissible.

## 2. Global comparison remains legal after arbitrary feedback

Fix `alpha>1` and choose a replacer for every prescribed channel slot within
positive cost slack `u`. Keep every local instrument identical between the
actual protocol and the comparison protocol. Instruments with saved outcomes
are CPTP maps into a laboratory memory containing those outcomes; adaptation
is simply controlled CPTP evolution of that memory. One need not condition on
a transcript or compare only successful branches.

Initially the full states, including the referee's original joint question
register and the question-independent shared resource, coincide. Each local
step obeys data processing. At a channel slot put every system other than the
channel input in `R` and apply (1). The slot direction changes which tensor
factor is transmitted, not the inequality. Thus the final full-state divergence
is at most

\[
 C_\alpha=\sum_j I_\alpha(N_j)+mu.\tag{3}
\]

In the all-replacer comparison, the sender discards its message locally and
the receiver prepares a fixed local state. With a prescribed schedule this
requires no cross-player signal. The entire comparison is an ordinary
zero-communication tensor strategy with the original referee law, so its
accepted-event probability satisfies `q<=q0=omega_co(H)`.

Apply the same binary accepted-event measurement to both final states. For
`p` the actual success probability, data processing and the first nonnegative
term of the classical Renyi sum give

\[
 C_\alpha\ge D_\alpha(\mathrm{Ber}(p)\|\mathrm{Ber}(q))
 \ge\frac{\alpha}{\alpha-1}\log p-\log q.
\]

Therefore

\[
 p\le\inf_{\alpha>1}\exp\left[
 \frac{\alpha-1}{\alpha}
       (\log\omega_{co}(H)+\sum_jI_\alpha(N_j))\right],
\]

after taking `u` to zero; cap the bound at one. If `q=0` and `p>0`, binary
divergence is infinite, contradicting (3). This proves the stated zero-value
case too. The acceptance effect must be between zero and identity, as for the
games and threshold events used here. A raw unbounded nonnegative payoff would
need normalization before the binary argument.

## 3. Capacity tolerance and calibrated boundary

For a fixed finite channel family and asymptotic use ratios, the source's
finite-dimensional limit `I_alpha(N)->I(N)=C_E(N)` as `alpha` decreases to one
justifies choosing one fixed `alpha>1` close enough to one to retain a strict
rate margin. A zero-communication exponent `g` consequently survives
exponentially when `sum_l beta_l C_E(N_l)<g`. Neither uniform convergence over
an unbounded channel family nor memory-channel additivity is being claimed.

The noiseless identity/dephasing/replacer checks have costs `2 log d, log d,0`,
respectively. The one-use binary input-guessing game with a binary symmetric
forward channel is also a useful exact check: `q0=1/2`, actual optimum is
`1-eta`, and `I_alpha=log 2-H_alpha(eta)`. The proposed bound becomes
`[(1-eta)^alpha+eta^alpha]^(1/alpha)`, whose infimum is exactly `1-eta`.

The input-guessing achievability example in P4 should be read with channels
carrying Alice's message toward Bob (or a network with that achievable forward
rate). A sum of capacities in both directions is a valid sufficient upper-bound
budget, but is not an achievable Alice-to-Bob communication rate for every
direction pattern. The existing statement that this is a fixture-specific rate
boundary, rather than a necessary condition for every game, is essential.

## 4. Falsifiers of broader hypotheses, not of P3

The fixed-list hypothesis cannot be relaxed without charging the resulting
control. If Alice selects between the two constant replacers `R_|0>` and
`R_|1>` according to an input bit and Bob learns which output arrived, she has
sent one bit although each individual channel has `I_alpha=0`. An uncharged
choice of channel identity, transmission direction or message timing is itself
a cross-cut message and is excluded by P3.

Likewise independent inaccessible environments matter. A two-slot classical
memory device can output a fresh random mask `R` on the first use, store
`X xor R`, and output the stored bit on its second use. Each isolated marginal
may look like a constant uniform channel, yet the joint outputs reveal `X`.
It is not a sequence of the prescribed independent replacer channels. The
all-reference proof correctly prevents substituting marginal-noise estimates
for a memoryless channel contract.

These tests establish the precise safe scope. I found no objection to P3's
actual interactive theorem, its application to the original N443 exponent, or
its strict-capacity-margin corollary in that scope. Historical novelty, cryptographic compilation and physical implementation remain separate claims.
