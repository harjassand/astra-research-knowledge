# Hostile audit of finite-tracial local preparation

7 November 2026. Exposed review of machinery's
`finite_tracial_transfer_candidate.md` and `common_amplification_lemma.md`.
The initial auditor report remains unchanged.

**Disposition:** T1--T5 passes the operator-order, support, locality,
normalization and constant checks reconstructed below. The exact multivariate
trace inequality and actual inherited sampler are named mathematical imports.
Together with the separately audited common-label parent construction this
closes the disjoint-block finite-tracial reconstruction route. This does not
prove the arbitrary charged/non-block version of public `FR(K)`.

## 1. Marginal replacement and zero spectrum

I checked Junge--LaRacuente, arXiv:2009.11866v2, Theorem 1.2 in the primary
source, <https://arxiv.org/html/2009.11866v2>. Its finite-tracial `p=2`
specialization, applied to half the four logarithms, followed by scalar Jensen,
gives the exact operator order needed here:

\[
 \tau e^{\log W+\log r-\log n+\log\nu}
 \le\int\beta_0(s)\tau[W L_s\nu L_s^*]ds,
 \quad L_s=r^{(1+is)/2}n^{-(1+is)/2}.
 \tag{1}
\]

Initially all logs are bounded in the supported corner. In expanding the
squared `L2` norm the endpoint imaginary powers of `W` and `nu` disappear by
cyclicity. Here `r=rho_K`, `n=nu_K`, embedded in the full algebra. Therefore
`nu_tilde=int beta_0(s)L_s nu L_s^* ds` has exactly retained marginal `r` and
trace one: partial trace gives `L_s n L_s^*=r` pointwise. The question control
`X` is classical in both retained marginals, so `L_s` commutes with every scalar
conditional-law attachment `K_y^mu`. The replacement preserves the comparison
form. These are stronger claims than generic approximate recovery.

Gibbs' variational formula and (1), for every positive invertible `W`, imply

\[
 b=D(\rho\|\nu)-D(r\|n)
 \ge\tau(\rho\log W)-\log\tau(\widetilde\nu W).
\]

Optimizing is the measured-relative-entropy variational formula, so
`D_meas(rho||nu_tilde)<=b`. Normal-state measured divergence bounds fidelity,
giving `F(rho,nu_tilde)^2>=exp(-b)`.

Continuous spectrum reaching zero is handled correctly by positive slack,
not by removing a kernel. Choose the conditional-comparison reference `nu_0`
diagonal and positive on every supported finite question cell, tensor the
tracial density on the residual algebra. It is bounded below on the supported
corner. Set `rho_delta=(1-delta)rho+delta nu_0` and
`nu_delta=(1-delta)nu+delta nu_0`. Joint convexity gives the upper limiting
bound for each full relative entropy, and lower semicontinuity the reverse;
thus full and retained divergences converge separately to their finite limits,
and `b_delta->b`. At each positive `delta`, (1) applies with bounded inverse
powers. Fidelity continuity gives

\[
 F(\rho,\widetilde\nu_\delta)^2\ge e^{-b}-o(1).\tag{2}
\]

No normal limiting replacement or convergence of inverse powers is needed.
Each slack uses an actual normal bounded comparison. Its marginal differs
from the original `rho_K` by a vanishing amount; the next step needs only its
normalized question law, so exact original marginal equality is unnecessary.

## 2. Common amplification and a genuinely right-algebra correction

Use `P=M_k(N)`, `k=|X|`, with unnormalized matrix trace for now. Write the
comparison seed density as `T=[T_xx']`, `C=sqrt(T)` and
`r_x=tau(T_xx)`. For positive `r_x`,

\[
 \chi_x=r_x^{-1/2}\sum_z e_{1z}\otimes C_{xz},
 \qquad\psi_{xy}^{emb}=e_{11}\otimes\psi_{xy}.
 \tag{3}
\]

They are unit vectors. Direct multiplication gives
`chi_x chi_x'^*=e_11 tensor T_xx'/sqrt(r_x r_x')`, so the whole coherent
conditional-input family purifies the desired comparison. The finite column
index is its opposite-side purifier.

For fixed `y`, define

\[
 A_y=\sum_xe_{x1}\otimes\sqrt{q(x,y)}\psi_{xy},\qquad
 B_y=\sum_{xz}e_{xz}\otimes\sqrt{\mu(y|x)}C_{xz}.
\]

Their left densities are exactly the unnormalized `y` blocks of target and
comparison. Polar decomposition gives

\[
 F_y=\|A_y^*B_y\|_1
 =\|(A_yA_y^*)^{1/2}(B_yB_y^*)^{1/2}\|_1.
\]

Choose the polar optimizer `U_y` of `B_y^*A_y`, so that
`Re tau(B_y^*A_y U_y)=F_y`. It acts by **right multiplication**. Under
`|x> tensor e_1z h <-> e_xz h`, the coherent question is the external row;
right multiplication changes the purifier column and the original right
algebra only. It does not act on the protected question row or depend on `x`.
The exact trace expansion is

\[
 \tau(B_y^*A_yU_y)
 =\sum_x\sqrt{q(x,y)r_x\mu(y|x)}
       \langle\chi_x,\psi_{xy}^{emb}U_y\rangle.
 \tag{4}
\]

Since `r_x mu(y|x)` is normalized, Cauchy--Schwarz and the direct-sum fidelity
formula yield

\[
 e_A=\mathbb E_q[1-|\langle\chi_x,\psi_{xy}^{emb}U_y\rangle|^2]
 \le1-(\sum_y F_y)^2\le b_A+o(1).\tag{5}
\]

The regularized `r_X` need not equal `q_X` for this argument.

Partial polar operators are harmless with a common finite extra matrix factor:
for a partial isometry `v`,

\[
 \begin{pmatrix}v&I-vv^*\\I-v^*v&-v^*\end{pmatrix}
\]

is an explicit unitary dilation in `M_2(P)`. Its corner preserves the desired
overlap. All finite families use the same amplification; left and right
completions can use separate finite matrix factors. This avoids an unspecified
global Uhlmann unitary. No infinite-algebra tensor factorization is used.

## 3. Canonical descriptors and exact fine-effect orientation

Write `chi_x=J_x u_x`, `u_x=|chi_x|`, inside the same algebra. `J_x` is a left
polar correction. Let `d_y` be the original right density averaged over
`x|y`, and `v_y=[U_y^*(e_11 tensor d_y)U_y]^(1/2)`. The finite-classical-record
information bound gives `e_B=E_q P^2(d_xy,d_y)<=b_B`; it uses relative
entropies and subtracts no infinite individual von Neumann entropies.

For normalized positive densities `a,b`, Holder with exponents `4,2,4` gives

\[
 F(a,b)\le\|a^{1/4}\|_4\|a^{1/4}b^{1/4}\|_2\|b^{1/4}\|_4
       =[\tau(a^{1/2}b^{1/2})]^{1/2}.
\]

Hence `||sqrt(a)-sqrt(b)||_2^2<=2P(a,b)^2`. Contract (5) to right marginals,
use the triangle inequality through corrected `d_xy`, square and average:

\[
 D_{desc}=\mathbb E_q\|u_x-v_y\|_2^2
                       \le4(b_A+b_B)+o(1).\tag{6}
\]

The corrected target is `J_x u_x U_y^*`. Therefore the correct transported
fine effects are exactly

\[
 A'_x=J_x^*(I\otimes A_x)J_x,\qquad
 B'_y=U_y^*(I\otimes B_y)U_y.\tag{7}
\]

Trace cyclicity verifies the Bob order:
`<J u U*,L(A)R(B)J u U*>=<u,L(J* A J)R(U* B U)u>`.
Complete unitary transport preserves POVMs; support-only transport assigns the
complement to one fixed default answer. All left effects commute with all
right effects on every input pair.

To normalize the trace after finite matrix amplification, divide the trace by
the matrix size and multiply every vector by its square root; densities scale
by that size too. Probabilities, Hilbert distances, fidelities and relative
entropy differences are unchanged. This is necessary bookkeeping, not a
matrix-size-dependent error.

## 4. Rare-event estimate and fresh-law transfer

Put `s=b_A+b_B`. The actual inherited sampler's good-vector squared error plus
bad probability is `F<=896(h^2+Dbar/h^2)+o(1)`. Using
`Dbar<=2Ddesc+o(1)` and `h=Ddesc^(1/4)` when `Ddesc<1/16` gives

\[
 F\le2688\sqrt{Ddesc}+o(1)\le5376\sqrt s+o(1).
\]

Alignment (5) changes square-root rejection by at most `sqrt(s)+o(1)` and
sampling changes it by at most `sqrt(F)`. Thus for `s<=1`,

\[
 \sqrt{\beta_q}\le\sqrt\alpha+75s^{1/4}+o(1).\tag{8}
\]

For an all-input losing function `ell(x,y) in [0,1]`, reverse triangle on
`sqrt(q ell)` and `sqrt(mu ell)` gives

\[
 |\sqrt{E_q\ell}-\sqrt{E_\mu\ell}|
 \le\|\sqrt q-\sqrt\mu\|_2\le\sqrt{D(q\|\mu)}.\tag{9}
\]

This Hellinger step justifies the square-root-law term; using TV and then
taking another square root would unnecessarily weaken it. If
`t=s+D(q||mu)<=1`, (8)--(9) yield

\[
 \beta_\mu\le\alpha+152\sqrt\alpha\,t^{1/4}
                            +5776\sqrt t+o(1).
\]

When `Ddesc>=1/16` or `t` is large, the trivial upper bound one fits the same
claim with `K=65536`. All accuracies are chosen at fixed finite family and
fixed positive tested probability; every final witness is finite amplification
of the original possibly infinite-dimensional finite algebra.

Combining with `sum_i(b_A,i+b_B,i+d_i)<=3 log(1/p_D)` proves the finite-tracial
disjoint-block instance of `FR(65536)`. Eliminate auxiliary quantities by the
scalar inverse inequality **before** the Lin table limit. At fixed `p_D>0`,
the event probabilities and conditional losses then converge. This proves the
block/projection scalar consequences at the stated constant using the already
proved scalar theorem. It leaves charged non-block masks, general quadratic
repetition, efficient implementation and historical priority outside the claim.

## 5. Direct finite-tracial parent matrix check

I also read `finite_tracial_parent_matrices.md`. Its parent densities are genuine
finite matrices over the original algebra, not an infinite commutant partial
trace. In Alice's block `k`, the unselected matrix entries are
`sqrt(mu(x,y)mu(x',y)) A_xa sigma^2 A_x'a'`; selected entries replace `sigma^2`
by `sigma Q_y,k sigma`, with `0<=Q_y,k<=I`. Their difference is a positive
operator-matrix congruence of `I-Q_y,k`. Replacing the two joint-law square-root
factors by the local-marginal factors gives the seed, and attaching
`sqrt(mu(y|x)mu(y|x'))` recovers the comparison exactly. The Bob argument is in
the opposite algebra. This verifies both domination and comparison form before
any entropy inequality.

The proposed finite-ancilla embedding
`sqrt(d_A d_B) sum_ab e_a1 tensor e_1b tensor w_ab` is an isometry for normalized
matrix traces. Scalar Bob matrices transpose their finite index under right
multiplication. For operator-valued matrices the correct map reverses the
coefficient algebra too: it is the canonical star isomorphism between the
matrix algebra over the opposite algebra and the opposite of the matrix
algebra. It preserves positivity and does not apply a positive-partial-transpose
assumption. Thus the same accepted pure target and all its fine local effects
fit one finite amplification while leaving the protected fresh references
outside for the entropy calculation.
