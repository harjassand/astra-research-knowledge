# Constructor follow-up: strict noisy-channel gains and exact coding comparators

7 November 2026. This accompanies
[`constructor_renyi_audit.md`](constructor_renyi_audit.md). All logs are natural.
The finite-order game-relative Rényi theorem is denoted R1 below. These are
complete constructions and resource comparisons, not a claim of new channel
coding or capacity theorems.

## 1. Exact Rényi costs of a quantum erasure channel

Let `E_{s,d}` transmit a `d`-dimensional input faithfully with probability
`s in (0,1)` and otherwise replace it by a flag orthogonal to its input space:

\[
 E_{s,d}(\rho)=s\rho\oplus(1-s)\operatorname{Tr}(\rho)|e\rangle\langle e|.
\]

The environments of different uses are independent and inaccessible. The
receiver learns the erasure flag. The sender does not learn it for free.
The exact fixed-reference channel costs are

\[
 \boxed{I_\alpha(E_{s,d})=
 \frac1{t_\alpha}\log[1-s+s d^{2t_\alpha}],
 \qquad t_\alpha=(\alpha-1)/\alpha.}
 \tag{E1}
\]

Consequently

\[
 C_E(E_{s,d})=2s\log d,
 \qquad I_\infty(E_{s,d})=\log(1-s+s d^2).
 \tag{E2}
\]

Here the first equality also follows directly from the usual
entanglement-assisted mutual-information capacity formula; the finite-order
formula is verified explicitly rather than assumed from a differently oriented
conditional Rényi entropy.

**Complete derivation of (E1).** Put `t=t_alpha`. Consider a replacer output

\[
 \tau_r=r I_d/d\oplus(1-r)|e\rangle\langle e|.
\]

For any pure input `psi_RA` with `rho_R=Tr_A psi`, the successful block in
the sandwiched Rényi power has trace

\[
 s^\alpha r^{1-\alpha}d^{\alpha-1}
       (\operatorname{Tr}\rho_R^{1/\alpha})^\alpha
 \le s^\alpha r^{1-\alpha} d^{2(\alpha-1)}.
\]

The inequality follows from scalar concavity of `x^(1/alpha)` on the at most
`d` nonzero Schmidt coefficients. The flag block contributes exactly
`(1-s)^alpha(1-r)^(1-alpha)`. Equality in the successful-block bound holds
for the maximally entangled input. Therefore the channel divergence against
this fixed replacer is exactly

\[
 \frac1{\alpha-1}\log\{s^\alpha r^{1-\alpha}d^{2(\alpha-1)}
                 +(1-s)^\alpha(1-r)^{1-\alpha}\}.
 \tag{E3}
\]

For the lower bound against arbitrary replacer outputs, fix that maximally
entangled input. Apply a joint twirl by `bar U` on the reference and `U` on
the successful output space, together with an independent phase on the flag.
Its channel output is invariant. The independent reference
`I_R/d tensor tau` is sent to `I_R/d tensor tau_r` for some `r`. Data
processing therefore cannot increase the latter's quality as a comparison
state. Thus no arbitrary output state can improve on minimizing (E3).

Writing `a=s d^(2t)` and `b=1-s`, the minimum of
`a^alpha r^(1-alpha)+b^alpha(1-r)^(1-alpha)` is `(a+b)^alpha`, at
`r=a/(a+b)`. This follows from scalar Hölder or a direct derivative. It proves
both sides of (E1). Taking the finite-order limits proves (E2).

There is also a complete CP-order certificate for the maximum-order value.
With normalized maximally entangled projector `Phi_d`,

\[
 J_E=s d\Phi_d+(1-s)I_R\otimes|e\rangle\langle e|.
\]

The primal SDP choice `S=s d I_d op (1-s)|e><e|` has trace
`s d^2+1-s` and satisfies `I_R tensor S>=J_E`. The dual witness

\[
 Y=d\Phi_d+(I_R/d)\otimes|e\rangle\langle e|
\]

is positive with `Tr_R Y=I_B` and objective `Tr J_E Y=s d^2+1-s`.
Hence the CP-order optimum is exactly `1-s+s d^2`. This reference-uniform
test is stronger than inspecting the emitted marginal.

## 2. A universal strict gain for every supplied repetition exponent

**Corollary E1.** Suppose a family of zero-communication games `H_n` has a
certified bound `omega_co(H_n)<=exp(-g n)` with `0<g<=1/4`. Allow the ordinary
finite-dimensional provers to communicate through `n` independent qubit
erasure slots, in any prescribed directions, of survival probability

\[
 s=\frac{3g}{8\log2}.
\]

Every such communicating strategy satisfies

\[
 \boxed{p_n\le e^{-gn/64}.}
 \tag{E4}
\]

The raw qubit-counting bound and the best per-slot CP-domination bound are
both vacuous for this same communication model.

**Proof.** Choose `alpha=4/3`, so `t=1/4`. By (E1) and `log(1+x)<=x`,

\[
 I_{4/3}(E_{s,2})
 =4\log[1+s(\sqrt2-1)]
 \le\frac{3(\sqrt2-1)}{2\log2}g<\frac{15}{16}g.
\]

The last strict inequality follows from `sqrt2<17/12` and `log2>2/3`.
The latter follows, for example, by strict Jensen on the integral of `1/x`
over `[1,2]`. R1 gives `p<=exp[-(1/4)(g-I_{4/3})n]<=exp[-gn/64]`.

On the other hand put `a=9/(8 log2)`, so `3/2<a<2`. The maximum-order
cost is `I_infty=log(1+a g)`. The elementary inequality
`log(1+x)>=x/(1+x)` gives

\[
 I_\infty>\frac{(3/2)g}{1+2g}\ge g
 \qquad(0<g\le1/4).
\]

Thus CP domination yields an exponent with the wrong sign. Counting each
slot as a noiseless qubit charges `2 log2>g` and also fails. The actual
entanglement-assisted capacity is `2s log2=3g/4<g`; (E4) gives an explicit
finite order rather than relying only on continuity at order one. ∎

Both original N443 and N446 conservative exponents lie far below `1/4`, so
this is a strict mathematical capability transfer for the actual supplied
capital, not only for the exactly solvable fixture below. It retains all
`n` full game questions and answers. The required channel is extremely noisy
when `g` is tiny; the result is not a claim of practical efficiency.

If an initial finite-order source cost obeys
`J_{4/3}<=g n/32`, the same argument gives `p<=exp(-gn/128)`. A trace-distance
smoothing error is added once, after this bound. The operational hockey-stick
source defect instead uses the separate formula (A7) in the audit report.

## 3. Explicit guessing game: strict gain and exact exponent

Consider the base game `F`: Alice receives a uniform bit `x`, Bob receives
one fixed question, Alice has a singleton answer, and Bob wins iff his
answer is `x`. In `F^n`, Alice receives `X in {0,1}^n`, and Bob must reproduce
it exactly. No-signaling of any commuting strategy makes Bob's law independent
of `X`, so

\[
 \omega_{\rm co}(F^n)=2^{-n}.
 \tag{E5}
\]

This exact zero-communication bound is used instead of the much smaller
general repetition exponent. Allow `m=4n` one-way qubit erasure slots from
Alice to Bob, with survival `s=1/10`, and arbitrary preshared entanglement.

Per game coordinate the competing costs are:

| Bound | Communication cost per `n` | Conclusion |
|---|---:|---|
| Noiseless qubit counting | `4 log4 = 5.545177444...` | Vacuous against `g=log2` |
| Exact CP order | `4 log(13/10) = 1.049457058...` | Vacuous against `g=log2` |
| Capacity limit | `4(1/5)log2 = 0.554517744...` | Strictly below `g=0.693147180...` |
| Finite order `alpha=5/4` | R1 exponent `>1/100` | `p_n<=exp(-n/100)` |

Optimizing the finite-order expression gives the exact exponent

\[
 E_* =\sup_{0<t<1}
   \{t\log2-4\log(9/10+(1/10)4^t)\}
 =4D_{\rm bin}(1/8\Vert1/10)
 =0.0129737062736677511671983\ldots .
 \tag{E6}
\]

The maximizer satisfies `4^t=9/7`, equivalently
`t=log(9/7)/log4` and `alpha=1/(1-t)=1.2214263186...`. Differentiation gives
this point; the function is strictly concave, so it is its global maximum.
In particular R1 proves `p_n<=exp(-E_* n)`.

### A rational certificate of a positive exponent

At `alpha=5/4`, write `T=9/10+(1/10)2^(2/5)`. Since
`2^(2/5)<33/25`, `T<129/125`. Exact rational arithmetic verifies

\[
 (129/125)^{20}<19/10.
\]

Therefore the exponent is

\[
 \frac15\log(2/T^{20})>
 \frac15\log(20/19)>1/100.
\]

The last inequality is `log(1+x)>x/(1+x)`. This proof of positivity does not
depend on floating-point optimization.

### A fully specified linear coding construction matching the exponent

For even `n`, the following ordinary entanglement-assisted protocol has success
at least

\[
 \boxed{\frac9{32(4n+1)}e^{-E_* n}\le p_{\rm construction}
       \le p_{\rm optimal}\le e^{-E_* n}.}
 \tag{E7}
\]

1. Before inputs, share `4n` EPR pairs and a uniformly random binary matrix
   `B in F_2^(8n x n)`, independently of the input. This is allowed shared
   randomness, not a leakage correlated with the questions.
2. Alice computes `BX`. Group the `8n` bits into `4n` ordered pairs. Dense-code
   each pair into her corresponding EPR half using one of the four Pauli
   operations, and send it through its erasure slot.
3. On each surviving slot Bob makes the Bell measurement, obtaining the
   corresponding two bits of `BX`. Erased slots are known flags.
4. Bob solves the resulting binary linear equations and samples uniformly
   from their affine solution set.

If `K` slots survive, the receiver has a uniformly random `2K x n` submatrix
of `B`. Conditional on this submatrix, step 4 succeeds with probability
`2^(rank(B_S)-n)`, for every input `X`. For a uniformly random square `n x n`
binary matrix, the probability of full rank is

\[
 \prod_{j=1}^n(1-2^{-j})\ge9/32.
\]

For `n>=2`, take the first two factors `3/8`, then bound the remaining product
below by `1-sum_{j>=3}2^-j=3/4`; `n=1` is even stronger. On `K=n/2`, the
submatrix is square and the protocol therefore succeeds with probability at
least `9/32`. Since `K` is binomial with `4n` trials and mean `2n/5`, the usual
binomial type bound gives

\[
 \Pr\{K=n/2\}\ge(4n+1)^{-1}
          e^{-4nD_{\rm bin}(1/8\Vert1/10)}.
\]

Indeed the binomial probability at `k` for parameter `u=k/m` is a modal
probability and is at least `1/(m+1)`. Reweighting that same term from
parameter `u` to `s` multiplies it by `exp[-mD_bin(u||s)]`.

Multiplying proves the lower bound in (E7). The upper bound was already
proved from R1. Odd lengths give the same asymptotic exponent after an
integer rounding or by ignoring one input bit with a constant guessing cost.
Thus the exact strong-converse exponent is achieved by this explicit
polynomial-description randomized linear protocol, up to a polynomial factor.

The complete costs are `4n` transmitted qubits, `4n` EPR pairs, `8n^2`
pre-shared independent random matrix bits, `O(n^2)` binary work to encode,
`O(n^3)` binary Gaussian-elimination work to decode, and `4n` local Bell
measurement attempts. Shared matrix randomness may be fixed offline to an
instance meeting the average success, but this argument does not supply an
efficient search for that deterministic instance. The randomized protocol is
already completely specified and requires no exponential codebook.

An executable version of the binary encoding, erasure record and uniform
affine decoder is `../constructor/linear_erasure_protocol.py`. It simulates
the logical two-bit erasure channel induced by ideal dense coding; it is not
a physical quantum experiment. A retained run at `n=16`, 64 slots and 2,000
trials is `../constructor/linear_erasure_demo.json`. The decoder's bijection
onto every consistent affine solution set was exhaustively checked in 584
small cases. The exact ensemble success calculations below, rather than
Monte Carlo, supply the finite arithmetic comparisons with (E7).

This is a transparent coding realization of the known strong-converse
mechanism. Li–Yao Theorem 6 identifies the optimal exponent for arbitrary
finite channels; the special-case matching proof here is included to make the
resource comparator concrete without attributing new priority to it.

## 4. Finite source Rényi information is strictly stronger than a max-order charge

Keep the uniform `n`-bit guessing task, but let Bob initially receive

\[
 L=X\oplus Z,\qquad Z_i\text{ independent Bernoulli}(\theta),
 \quad 0<\theta<1/2.
\]

The preshared EPR resource is independent of `X,L,Z`. The reference uses a
uniform independent `L`, plus that same EPR resource. Direct minimization over
the reference distribution of `L` (or XOR symmetry) gives the exact source
profile

\[
 J_\alpha/n=\log2-H_\alpha(\theta),
 \quad H_\alpha(\theta)=
 \frac1{1-\alpha}\log[(1-\theta)^\alpha+\theta^\alpha].
 \tag{E8}
\]

To see the minimization explicitly, apply the classical formula from (A10):
the quantities `sum_x mu(x) P(l|x)^alpha` are identical for every `l`.
Their minimizing reference distribution is therefore uniform. Discarding the
independent EPR registers lower-bounds any full-resource source divergence,
and choosing their actual common state in the reference achieves that bound.
Thus the formula is not only a convenient upper estimate.

Use `theta=1/4`, `s=1/10`, and now only `m=3n` erasure-qubit slots. R1 gives

\[
 p_n\le \exp[-nE(t)],
 \quad E(t)=tH_{1/(1-t)}(1/4)
       -3\log[9/10+(1/10)4^t].
 \tag{E9}
\]

At `alpha=5/4`, `t=1/5`, the exponent is

\[
 E(1/5)=0.0127187501548409286854888\ldots>1/100.
\]

Hence `p_n<=exp(-n/100)` by a certified fixed-order calculation.

By contrast, the exact best maximum-order source cost is

\[
 h/n=J_\infty/n=\log(3/2)=0.4054651081\ldots .
\]

Even putting this charge inside the finite-order telescope cannot prove any
decay: `h/n+3 C_E = log(3/2)+(3/5)log2 > log2`. Since every `I_alpha>=C_E`,
the exponent has the wrong sign at every order. The older external `e^h`
multiplier is no stronger. Exact CP domination and raw qubit counting also
fail. This strict separation therefore uses genuinely finite-order source
information as well as genuinely finite-order channel information.

### Exact rational positivity certificate

Put

\[
 S=(3/4)^{5/4}+(1/4)^{5/4}
   =\frac{3\,3^{1/4}+1}{4\sqrt2},
 \qquad T=9/10+(1/10)2^{2/5}.
\]

The exact elementary bounds

\[
 3^{1/4}<1317/1000,\quad
 \sqrt2>707/500,\quad
 2^{2/5}<33/25
\]

follow by taking fourth, second and fifth powers, respectively. With the
resulting rational upper bounds `S_+,T_+`, exact integer arithmetic gives

\[
 S_+^4T_+^{15}<19/20.
\]

Consequently `E(1/5)=-(1/5)log(S^4T^15)>1/100`. The diagnostic script
retains and checks the integer inequalities; decimal values only orient
the reader.

## 5. Exact capacity boundary, including the noisy source

For the preceding source with arbitrary fixed `theta in (0,1/2)` and qubit
erasure survival `s`, take `m/n -> beta`. The boundary for asymptotically
successful reconstruction of `X` is

\[
 \boxed{\beta\,2s\log2=H(\theta).}
 \tag{E10}
\]

Below this boundary, the profile (E8) is continuous at order one, and a
fixed order above one in R1 gives an exponentially small probability of
guessing every bit. Above it, a concrete source-and-channel construction
succeeds with probability tending to one. No assertion is made at equality.

**Constructive achievability above the boundary.** Choose a small positive
margin so that a binary syndrome length `r_n` satisfies

\[
 n(H(\theta)+\gamma)<r_n\log2
       <2ms\log2-\gamma n.
\]

Let `T_n` be the set of noise strings whose log probability is at most
`n(H(theta)+gamma/2)` in magnitude. Its size is at most
`exp[n(H(theta)+gamma/2)]` and it contains the actual noise with probability
tending to one, by the elementary law of large numbers. Share a random binary
matrix `A in F_2^(r_n x n)` and use `AX` as the source syndrome. Given `L`
and the syndrome, Bob seeks the unique `z in T_n` with
`Az=AX xor AL`. For every distinct candidate noise string, the probability
of hash collision is `2^-r_n`, so a union bound makes the additional decoding
error exponentially small. This is the usual random-binning proof of the
Slepian–Wolf operation, with no assumption that Alice knows `L`.

Transmit the syndrome through the erasure channel using a second shared random
binary matrix `B in F_2^(2m x r_n)` and the dense-coding construction of §3.
With high probability `K>=m(s-o(1))`, and the surviving `2K x r_n` matrix has
full column rank except with probability at most `2^(r_n-2K)`, by a union
bound over its nonzero kernel vectors. The strict margin makes this error
exponentially small. Bob first recovers `AX`, then the noise `Z`, then
`X=L xor Z`. Both local inputs and every channel use have been accounted for.

There are `m` EPR pairs and `O(n^2)` shared random matrix bits. Source encoding,
channel encoding and channel decoding are polynomial in `n`. The direct
typical-set source decoder may enumerate exponentially many strings; no
efficient Slepian–Wolf decoder is claimed by this argument. Fixed matrices
with the asserted average performance exist; deterministic acquisition costs
are not supplied. The completely specified randomized protocol avoids any
unreported search.

For `theta=1/4,s=1/10`, the boundary is

\[
 \beta_*=H(1/4)/[(1/5)\log2]
          =4.0563906222956643\ldots .
\]

Thus the explicit `beta=3` finite-order bound is below the sharp boundary.
With no useful side information (`theta=1/2`), this becomes `beta_*=5`, the
ordinary guessing-game channel-capacity comparator in §3. The matching
boundary is an established source/channel coding phenomenon, not a newly
proved general game-capacity characterization.

## 6. Supporting checks and scientific limits

`../constructor/renyi_checks.py` checks:

- arbitrary different noncommuting input/reference matrices in the replacer
  amortization inequality for the erasure family, with arbitrary finite
  retained reference systems;
- the exact erasure cost against the maximally entangled input and random
  Schmidt spectra, and the matching primal/dual CP-order certificates;
- exact rational positivity certificates in §§3–4;
- exact finite binary-rank averages of the explicit coding construction for
  small even lengths, compared to the type lower bound and Rényi upper bound;
- the closed classical BSC and rare-leak source Rényi profiles.

These are diagnostics, not a replacement for the proofs. The source and
channel theorems retain their finite-dimensional ordinary-quantum scope. The
arbitrary-commuting maximum-order theorem remains separately proved in the
audit report. No inference about physical device performance, quantum PCP,
answer reduction, or a new coding priority follows.
