# Final mathematical review of the amplification dossier

7 November 2026. Reviewed
`outputs/COMMUTING_AMPLIFICATION_BRIDGES_RESEARCH_DOSSIER.md`, SHA256
`39513d26b9a8ec2128e4119337462ca71174568eec09f2fe56d9c4edfe89ac64`,
with particular scrutiny of sections 3--6 and 11. Also read
`principal_final_proof_checks.md`, `actual_one_sided_mass_reconstruction.md`
and `actual_mass_table_identity.md`. This is a correctness/scope review;
initial reports and the dossier were not edited.

## Disposition

**Explicit scope pass.** No surviving theorem-level error was identified in
the two-comparison reconstruction, full charged FR closure, actual-mass scalar
closure, separate tensor-gap proof, constants or the stated computability
obstruction. One local lower-bound quantifier should be made explicit below.

## One lower-bound quantifier to clarify

The sentence following (6.3) says the displayed masses are at least `p_D`.
For the averaged masses `G_A(P,D),G_B(P,D)` this is correct. For the displayed
question-conditioned quantity `G_A,c(P)` it must instead read `G_A,c>=p_c`.
Both facts should be stated explicitly so that (6.3) cannot be read as the
false per-c bound `G_A,c>=p_D`.

A concrete counterexample to that stronger per-c reading is a test requiring
Alice's answer zero, with two equally likely tested question values and a
classical strategy outputting zero with probabilities `1/10` and `9/10`.
Then `G_A,c=p_c` is `1/10` or `9/10`, whereas `p_D=1/2`. The proof and Lin
passage actually use the correct averaged lower bound, so this is not a gap in
the theorem. Section 5.3 already states the correct per-c bound.

## Correctness checks passed

1. **Comparisons and common target.** Equation (3.2) permits an arbitrary
   normalized positive seed with its own supported local question law.
   Alice's and Bob's comparisons need not be margins of one reference state.
   The proof uses Alice's state for coherent alignment, Bob's only for variation
   of the same target's right marginal. The common square-root-weighted target
   and all required fine measured laws are preserved. No second factor of
   `sqrt(w_l)` is applied to it.
2. **Finite trace and zero spectrum.** The four-log operator order matches the
   `p=2` Junge--LaRacuente specialization. Positive faithful mixing makes all
   inverse powers bounded at each chosen slack. Full and retained divergences
   converge separately; fidelity continuity is uniform in the varying
   replacement state by the displayed Holder estimate. The explicit spectral
   measurement proof of the fidelity bound works in finite trace. No compactness,
   matrix density, or inverse-power convergence is needed.
3. **Locality.** The row purification and polar optimizer of `B_y^*A_y` act on
   the correct purifier columns. The right operator is independent of the
   coherent external `x` row. Equation (4.11) has the correct Bob order.
   Finite common padding preserves complete fine POVMs on all input pairs.
4. **Actual masses.** The raw one-sided seeds are positive and have finite
   traces `G_A,c,G_B,c`. Dividing by those traces is allowed by (3.2), even if
   a trace is below one. The domination factors and private-label cancellation
   are therefore exactly `log(G_A,c/p_c)` and its Bob counterpart. The tilted
   identity (5.7) is exact; no prior/posterior expectation interchange occurs.
   Formula (6.3) is a finite positive linear functional of the original
   no-signaling table. Summing the opposite answers computes its marginal,
   independently of the chosen opposite input. Hence the averaged actual
   masses pass the full-table Lin limit.
5. **Scalar before Lin.** The operational costs and descriptors are eliminated
   into continuous `Phi_K` first. At fixed `p_D>0`, conditional probabilities
   and the positive averaged masses converge, so their logarithms and deficits
   converge. No assertion about convergence of raw costs, states or algebras is
   made. This is the required exact quantifier order.
6. **Constants.** The sampler/target-alignment estimates give coefficients 152
   and 5776, both below `K=65536`. For blocks,
   `1/2+K(6*2^-75)^(1/4)/sqrt(2)+K sqrt(6*2^-75)<0.665` as stated.
   For common charge, the exact sufficient exponent denominator is
   `3+4*kappa/epsilon+2*t0*epsilon`, `t0=2^-72`; it is bounded by
   `8(1+kappa/epsilon)`. This gives (6.4) for positive gap, with the separately
   stated trivial zero-gap interpretation. The heterogeneous greedy and
   tilted-subset arguments retain the necessary cap
   `alpha'_i=min(alpha_i,epsilon_i)` and have the stated `2^-75,2^-85`
   conservative constants. Full/zero-probability tested sets are handled.
7. **Distinct tensor gap.** The tensor claim is a separate finite-matrix
   pointwise proof: its comparison constructions, amplifications and finite
   sampler trials remain full matrix algebras and give an actual finite tensor
   extracted strategy. Its loss is therefore bounded below by `epsilon_star`.
   Only then is the tensor supremum taken. The commuting proof separately uses
   `epsilon_co` and scalar Lin closure. No equality of the values is assumed.

## Section 11: absolute Hamiltonian scope

The stated obstruction is valid with its explicit **uniform computable** and
**explicitly finite** qualifications. Lin 2510.07162v1, Theorem 1.1 and section
6.1 give effective finite two-player one-round games with completeness one and
soundness at most one-half for an undecidable coRE language. Thus the relevant
constant-gap promised game problem is undecidable.

Suppose a computable transformation, defined on every promised input, produced
an explicitly finite Hamiltonian with uniformly computable entries and known
separated computable energy thresholds, preserving the answer. Its dimension
is part of the finite output. Approximate the finite matrix in operator norm
to less than one quarter of the energy gap and compute certified eigenvalue
intervals; Weyl's bound decides the promised case. Composing with the game
reduction would decide the undecidable language. Polynomial runtime is
irrelevant. This confirms section 11.

It does not rule out nonuniform existence, an infinite thermodynamic
Hamiltonian, noncomputable coefficients, an undisclosed non-effective finite
dimension, or a genuinely restricted promised game family with an acquired
finite encoding. Those are outside the stated transformation. The dossier
correctly distinguishes this obstruction from quantum-PCP statements and
credits the existing games/Hamiltonians distinction.

## Requested addition: quadratic gap power is optimal inside the block class

Confirmed against the primary Kempe--Regev 0911.0201v1, Definition 3.1,
Theorems 3.2 and 4.4:
<https://arxiv.org/html/0911.0201v1>.

Use the original **binary line game** `G_L`, not its three-answer unique
variant. On `m` vertices the referee samples uniformly one of `2m-1` edges,
including one loop per vertex. Every interior constraint is equality; the two
endpoint loops accept only `(1,1)` and `(2,2)`, respectively. These are all
disjoint-block masks (the endpoint masks are partial projections).

Theorem 3.2 gives matching classical, tensor and no-signaling value
`1-1/(2m-1)`. Every commuting strategy is no-signaling and includes classical
strategies, so its exact commuting gap is
`epsilon_m=1/(2m-1)`. Theorem 4.4 is explicitly for this binary `G_L` and gives
a **classical** repeated lower bound `(1-O(m^-2))^n` for `n>=m^2`. Hence, for
sufficiently large `m`,

\[
 \omega_{co}(G_L^n)\ge\omega(G_L^n)
          \ge\exp(-C\epsilon_m^2 n),\qquad n\ge m^2,
\]

with an absolute constant `C`. A universal upper exponent with gap rate
`f(epsilon)` satisfying `f(epsilon_m)/epsilon_m^2->infinity` would contradict
this lower bound. Thus the power two is optimal within Theorem A's full
disjoint-block class, up to constants. This says nothing about optimality of
`2^-75`, answer-size dependence, or historical priority. It should not be
silently strengthened to the narrower class of *total* one-way projections
using this binary endpoint fixture alone. No unique-game conversion or
probabilistic-predicate mixture is needed for the stated block-class claim.
