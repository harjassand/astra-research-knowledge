# Independent hostile audit of the one-sided rectangle parents

7 November 2026. Written after reading only the principal's new
`principal_one_sided_rectangle_candidate.md`, before exchanging new findings
about this candidate with machinery or another researcher. Earlier block and
finite-tracial preparation audits remain intact.

**Disposition: the proposed full charged reconstruction survives this audit.**
The target can be one common pure vector while Alice's and Bob's comparisons
come from different one-sided completions. The previously audited preparation
lemma assumes two conditional comparisons for one target, not two marginals of
a common comparison state. No counterexample was found. The precise proofs and
non-block tests follow.

## 1. One target and the exact square-root weights

Fix tested questions `c` and finite decomposition

\[
 V_c(a_D,b_D)=\sum_l w_l R_l(a_D)T_l(b_D),\quad w_l\ge0,
\]

exact on every winning and losing cell. Retain the original full fine output
records on their respective sides in a coherent dilation. If their residual
vectors are `zeta_x,y,a,b`, define the unnormalized target by attaching six
orthogonal copies of `l` and multiplying that fine amplitude by
`sqrt(w_l)R_l(a_D)T_l(b_D)`. Its squared norm is exactly

\[
 \sum_{xyab}\mu_J(x,y)\sum_l w_l R_l(a_D)T_l(b_D)
                                    \|\zeta_{xyab}\|^2=p_c.
\]

After normalization, measuring any joint subset of original fine outputs and
questions therefore gives the original event-conditioned table. Orthogonality
of the new labels is crucial. No product of two weighted local filters is
asserted; that incorrect construction would square `w_l`.

The refined target can change other coherences and need not arise by physically
local filtering of the original resource. The preparation theorem is a theorem
for specified pure target families; it does not require that additional
preparation operation. Every required fine measured correlation is preserved.

Each party has one private `l` copy and external copies used in the already
audited common-history partition. All external copies are omitted from the
comparison parents. Conditional on `c,l`, those external copies are fixed basis
vectors, so the residual target is pure. The same globally refined vector,
partitioned in complementary coordinate orders, supplies both target parents.

## 2. Complete local one-sided maps

Let Alice's original fine joint POVM at local string `x` be `P_a^x`, and set

\[
 D_{A,x}=\sum_a\sum_l w_l R_l(a_D)P_a^x\le A_c I.
\]

Her successful coherent map has components
`sqrt(w_l/A_c) R_l(a_D) sqrt(P_a^x)`, with orthogonal original fine `a`, private
`l` and external `l` output registers. Add an orthogonal failure component

\[
 F_{A,x}=\sqrt{I-D_{A,x}/A_c}.
\]

The sum of its Kraus adjoint-products is exactly identity. This is a local
isometry depending only on fixed `c` and Alice's own live string `x`. The
failure can use a distinguished private sentinel and fixed padded fine record;
the target has zero support on that failure sector. The same construction
works for Bob using `B_c` and `T_l`.

Overlapping rectangles cause no violation of completeness: their local weighted
loads are exactly what `A_c,B_c` bound. Zero weights can be omitted. Empty
rectangles and zero-success label branches have zero target mass. The case
`p_c=0` is omitted from the conditioned law. Empty tested set has one trivial
label. All operators, including the failure square root, belong to the
appropriate finite von Neumann algebra.

## 3. Direct operator-matrix domination in arbitrary finite trace

Let the original standard-form vector be bounded positive `sigma`, and write
`A_xa=sqrt(P_a^x)`. At fixed `y,l`, index Alice's coherent rows by `(x,a)` and
put

\[
 Z_{x,a}=\sqrt{\mu_J(x,y)w_l}\,R_l(a_D)A_{xa}\sigma.
\]

The successful unnormalized comparison block before dividing by `A_c` is the
finite matrix `S_l,y=[Z_xa Z_x'a'^*]` over the original algebra. The target block
is

\[
 T_{l,y}=[Z_{x,a}Q_{y,T_l}Z_{x',a'}^*],\qquad
 Q_{y,T_l}=\sum_{b:T_l(b_D)=1}Q_b^y\le I.
\]

Thus `S_l,y-T_l,y` is the positive operator-matrix congruence of
`I-Q_y,T_l`. There is no partial trace over an infinite commutant, and no
same-algebra commutation of `P` and `Q` is used. Tracing Alice's external label
copy dephases her private label in the comparison. Bob's traced fine isometry
has disappeared by completeness. Adding the failure block yields

\[
 p_c\rho_{A,c}\le A_c\sigma_{A,c}.\tag{1}
\]

Bob's proof is the identical calculation in the opposite algebra with Alice's
unweighted effect `sum_{a:R_l(a_D)=1}P_a^x<=I`. It gives
`p_c rho_B,c<=B_c sigma_B,c` for the **same target**.

Both comparisons retain the exact original conditional question law. To see
this directly, replace the row coefficient `sqrt(mu_J(x,y))` in Alice's
comparison by `sqrt(mu_J,X(x))`; this defines its seed. Attaching
`sqrt(mu_J(y|x)mu_J(y|x'))` reconstructs the comparison entries. The failure
component is another Alice-local controlled map, so it has the same property.
Bob is symmetric. Each comparison is normalized by its own local completion;
they need not be compatible preselection marginals.

## 4. Conditional entropy and ordered budgets

Let `q_c(l)` be the target label law. Every supported target block retains
private `l`, and is dominated by `A_c sigma_A,c/(p_c q_c(l))`. Hence all full
divergences used below are finite. Donald's identity on the full and retained
marginals gives

\[
 \begin{split}
 &\sum_lq_c(l)[D(\rho_{A,c,l}\|\sigma_{A,c})
                 -D(\rho_{A,c,l}^{K_A}\|\sigma_{A,c}^{K_A})]\\
 &=D(\rho_{A,c}\|\sigma_{A,c})
       -D(\rho_{A,c}^{K_A}\|\sigma_{A,c}^{K_A})
       +I(l:R_J\mid K_A)\\
 &\le\log(A_c/p_c).
 \end{split}\tag{2}
\]

The CMI is zero because the private orthogonal label remains in `K_A`; (1)
bounds the full divergence. Bob's bound is `log(B_c/p_c)`. These facts do not
depend on existence of a joint comparison state.

The local-description proof first uses Alice's comparison to construct her
coherent pure descriptions and right corrections. It uses Bob's comparison
only to bound the variation `I(X:B|Y)`. No step identifies one comparison's
purifier with the other comparison. Both are required to compare to the same
pure target, which was explicitly constructed in section 1. This meets the
audited hypotheses exactly.

Let `Q_C(c)=mu_D(c)p_c/p`, `L=log(1/p)` and
`Z_A=E_muD A_c`. The useful exact identity is

\[
 \mathbb E_{Q_C}\log(A_c/p_c)
 =L+\log Z_A
       -D\left(Q_C\middle\|\frac{\mu_D A_c}{Z_A}\right)
 \le L+\log Z_A.\tag{3}
\]

This avoids an invalid change between conditioned and unconditioned load
expectations. With product tested partitions, `Z_A=product_{j in D}a_j` and
likewise for Bob. Apply the already audited ordered allocation, leaving the
comparison's internal private label unconditioned, and restore external
histories with target weights. Then

\[
 \sum_i b_{A,i}\le L+\sum_{j\in D}\log a_j,\quad
 \sum_i b_{B,i}\le L+\sum_{j\in D}\log b_j.
\]

Question-law drift is the original **unconditional** coordinate divergence:
the refined target's measured table is unchanged, so `sum_i d_i<=L` still
holds. Set `t_i=b_A,i+b_B,i+d_i`. This proves exactly

\[
 \sum_{i\notin D}t_i\le3L+2\sum_{j\in D}\kappa_j.\tag{4}
\]

All histories remain inside the target workspaces. The previous parity-history
counterexample is handled exactly as in the block audit: no conditional-history
question divergence or independent posterior-history sampling is substituted.

## 5. Explicit non-block and overlap tests

For the three-edge mask `[[1,1],[0,1]]`, take four rectangles of weight `1/2`:

- `{0} x {0,1}`;
- `{0,1} x {1}`;
- `{0} x {0}`;
- `{1} x {1}`.

Each winning cell belongs to exactly two half-weight rectangles and the losing
cell to none. Both maximum local loads are `3/2`. Alice's successful norm is
`(3/2)P_0+P_1`; after dividing by `3/2`, her failure adjoint-product is
`P_1/3`. Bob's is `Q_0/3`. These identities hold for arbitrary binary POVMs,
not only projective effects. The accepted target has total fine mass
`p_00+p_01+p_11`, with each component appearing twice at amplitude `sqrt(1/2)`.
Using amplitude `1/2` instead would halve the mass, so this fixture detects the
weight-squaring error. The congruence proof in section 3 gives both parent
inequalities even for noncommuting original coefficient matrices.

For the all-ones mask, duplicate the whole rectangle with weights `1/2,1/2`.
Then `A_c=B_c=1`, `p_c=1`, and the target adds a shared coherent two-label
register. Each one-sided comparison has a locally dephased private label;
the selected and unselected blocks agree. Both conditional deficits are zero,
consistent with creating the shared label in the new input-independent
resource. It is not necessary to generate that entangled label from the old
resource by local operations. The measured original fine table is unchanged
although a different global target purification has been selected.

## 6. Consequence and remaining boundary

Combining (4) with the audited finite-tracial local-preparation/sampler theorem
gives the public full charged `FR(65536)` statement at its exact finite-tracial
scope, for arbitrary finite exact positive rectangle partitions. Scalar
elimination before Lin's finite-table closure gives the corresponding budget
for arbitrary joint commuting tables. Raw descriptors or algebra-dependent
costs need not converge. Thus the earlier conditional charged heterogeneous
consequences can be used after inserting this proof dependency.

The charge remains presentation dependent. No answer-free rate for arbitrary
predicates follows: non-block masks can keep positive charge when the game gap
tends to zero. The earlier large-positive-mass/filter obstructions do not
contradict this charged theorem. General quadratic repetition, an intrinsic
fully heterogeneous sum-rate without the extra ratio/range restriction,
efficient resources, physical advantage and historical priority remain
unestablished. The already proved block theorem remains valid independently.
