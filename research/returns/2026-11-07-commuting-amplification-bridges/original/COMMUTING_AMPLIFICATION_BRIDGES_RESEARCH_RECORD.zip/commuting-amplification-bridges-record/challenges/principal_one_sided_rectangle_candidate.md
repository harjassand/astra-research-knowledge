# Principal candidate: full charged FR from two one-sided completions

7 November 2026. Developed after reading and independently checking the completed common-label, finite-tracial marginal-replacement and common-amplification constructions. Submitted to all three existing researchers for challenge. This is a NEW candidate, not yet an approved extension. It must not overwrite earlier frozen reports.

## Decisive idea

The two conditional-comparison parents need not be margins of ONE preselection vector. The TARGET must be the same pure copied-input vector for both orientations. Each parent may instead come from a separate one-sided local completion. That lets the target use rectangle amplitude sqrt(w), while both one-sided parents use the same sqrt(w), without multiplying the weights to w^2. Exact positive predicate decomposition preserves the measured table.

## General predicate presentation

At a fixed tested-question string c=(x_D,y_D), write the accepted mask on tested fine outputs as

  V_D(c,a_D,b_D)=sum_l w_{c,l} 1_{R_{c,l}}(a_D)1_{T_{c,l}}(b_D),

an exact identity on every cell, w>=0. Overlapping rectangles and arbitrary positive fractional weights are allowed. Let A_c,B_c>=1 bound the maximum row/column loads

  sum_{l:a_D in R_l}w_l <= A_c,
  sum_{l:b_D in T_l}w_l <= B_c.

For coordinatewise chosen partitions, A_c=product_{j in D} A_j(c_j), B_c=product B_j(c_j). Their unconditioned moments factor: E_muD A_c=product a_j, E_muD B_c=product b_j.

Dilate the ORIGINAL full repeated measurements coherently, retaining every fine output in its original party's local register. Denote their pure family at fixed c by zeta_c, with amplitudes for the live question strings and fine outputs. In a tensor realization its fine vectors are (U_{c,x,a} tensor V_{c,y,b})psi; in finite standard form use U_{c,x,a} sigma V_{c,y,b}. No assumption of coordinatewise measurements is made.

## One common target

Form the mathematical vector

  Phi_c=(1/sqrt(p_c)) sum_{x,y,a,b,l}
     sqrt(mu_J(x,y) w_{c,l}) 1_Rl(a_D)1_Tl(b_D)
     |xx>|yy>|a>_A|b>_B |l,l,l>_A |l,l,l>_B zeta_{c,x,y,a,b}.

The labels are analysis records. This is not claimed to be a physically local preparation from the original resource. The exact decomposition gives ||Phi_c||=1 when p_c>0, and every measured live fine-answer probability is EXACTLY the original probability conditioned on all tested coordinates winning. No pointwise coherence claim beyond that declared observable table is needed. The same pure Phi_c, with the three private/external copy roles of the common-label construction, supplies both coordinate targets.

## Alice's conditional-comparison parent

For fixed c and local live x, consider the controlled map which coherently retains Alice's full fine output a and appends three l copies with amplitude sqrt(w_l)1_Rl(a_D). Completeness of the original fine POVM gives norm square at most A_c I. Divide this map by sqrt(A_c), and complete it with one orthogonal failure branch to an isometry. This is a LOCAL isometry depending only on c and x, and its control coefficients lie in Alice's original algebra. Her parent sigma_A,c comes from this completed one-sided map and the original copied-input prior mu_J; there is NO Bob-selected-label operation in this comparison.

Trace the external l copies so Alice's retained private l is classical. Its l block, before division by A_c, is S_l^A with weight w_l. The corresponding unnormalized accepted target block T_l^A is obtained by Bob's original fine-output restriction b_D in T_l. That is a positive contraction on Bob's local side; summing other Bob fine outcomes gives identity. Hence

  0 <= T_l^A <= S_l^A,
  p_c rho_A,c <= A_c sigma_A,c.                              (R1)

Here rho_A,c is the mixture of Phi_c's common-l blocks. Alice's failure block only adds positivity. The comparison sigma_A,c retains the exact original conditional-question form because its map is local in x and Bob's full isometry disappears. No Bob-created external history copy is retained in the parent.

Donald/direct-sum cancellation of the private l copy then yields

  E_{l|c,E}[D(rho_A,c,l||sigma_A,c)
              -D(rho_A,c,l^K_A||sigma_A,c^K_A)]
       <= log(A_c/p_c).                                     (R2)

Bob uses a SEPARATE local map with amplitudes sqrt(w_l)1_Tl(b_D), divided by sqrt(B_c) and completed, giving

  corresponding conditional deficit <= log(B_c/p_c).         (R3)

Both parents compare to the SAME target Phi_c. They are not required to be compatible parents of one preselection state. That is exactly the point needing hostile verification against the assumptions of the marginal-replacement/local-description theorem.

## Averaging tested questions preserves distribution-averaged loads

Let Q_C(c)=mu_D(c)p_c/p, p=Pr E_D. With L=log(1/p),

  E_Q log(A_c/p_c)
    =L-D(Q_C||mu_D)+E_Q log A_c
    <=L+log E_muD A_c,                                     (R4)

by the Gibbs variational/log-sum inequality. The same holds for B_c. No assertion E_Q A_c=E_mu A_c is used. Product partitions therefore give total parent charges

  B_A <= L+sum_D log a_j,
  B_B <= L+sum_D log b_j.                                   (R5)

The coordinate-order allocation and full-workspace history treatment are exactly the common-label proof, except the two separate comparisons above. The original unconditional fresh-question drift still obeys sum_i d_i<=L. Thus

  sum_{i notin D}(b_A,i+b_B,i+d_i)
     <=3L+sum_D log(a_j b_j)
      =3L+2sum_D kappa_j.                                  (R6)

The completed finite-tracial description/sampler theorem would supply the per-coordinate legal loss bound with K=65536 and arbitrary positive slack. This is full FR(K) for arbitrary exact positive fractional rectangle partitions, closing the precise charged premise of the published games section, not merely a coefficient-doubled variant.

## Nontrivial obstruction tests to run

1. Three-edge 2x2 mask, exact overlapping/fractional partitions: show both parent block inequalities and output-table exactness without an illegal joint physical instrument. A 3-edge mask is not a disjoint-block mask, so passing only equality predicates is insufficient.
2. A fractional decomposition of an all-ones matrix into overlapping rectangles should show the normalized target changes coherences but preserves the original fine measured table; local preparation may depend on presentation, and a nonminimal charge is allowed.
3. Common target vs different one-sided parents: verify local-description theorem never requires both parents to be the two reduced states of the SAME reference purification.
4. Continuous spectra/type-II: one-sided Kraus completion sqrt(I-U*U/A) lies in the respective original finite algebra; derive S_l-T_l as explicit operator-matrix congruence over M, not an undefined partial trace.
5. Fully supported / zero winning mask / p_c=0 corners and zero weights; restrict successful c and l, which is finite. Empty tested set has one trivial l.
6. The parity-history example must still have unconditional d_i only and exact local posterior coupling.

If any test fails, retain the proven block result and mark the full charged extension open. If all pass, strengthen the final dossier's reconstruction theorem and heterogeneous/near-block consequences while keeping general all-predicate QUADRATIC repetition open: kappa still appears and can stay positive at small gap.
