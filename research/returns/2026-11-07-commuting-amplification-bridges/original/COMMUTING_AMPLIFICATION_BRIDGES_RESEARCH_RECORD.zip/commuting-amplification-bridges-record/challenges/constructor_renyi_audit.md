# Constructor cross-challenge: Rényi channel bound and source correlation

7 November 2026. Follow-up to the frozen constructor report. The principal's
`principal_renyi_bridge.md` was read after the independent initial reports were
frozen. No initial report is altered by this follow-up.

## Audit disposition

**The principal's P3 is sound at its stated finite-dimensional tensor-protocol
scope**, using the exact fixed-reference Rényi mutual information and charging
every cross-player channel. The proof is a valid application of established
channel discrimination/entanglement-assisted strong-converse machinery. No new
channel-capacity principle is needed. The arbitrary-commuting initial-resource
extension is kept separately at maximum-order/CP-order scope.

Two useful strengthening operations are completed here:

1. An initial **finite-order source Rényi cost** enters the same divergence
   telescope, with the same Rényi order, instead of being paid as an external
   maximum-order multiplier.
2. Corruption of a bounded number of coordinate records and source smoothing
   can be included with an **unamplified additive error**. The original
   operational domination defect and trace-distance Rényi smoothing are
   distinguished; they are not interchangeable definitions.

Exact erasure-channel examples, a strict improvement over both CP domination
and raw message counting, and an exact guessing-game exponent/capacity
comparator are developed in
[`constructor_renyi_examples.md`](constructor_renyi_examples.md).

## 1. Exact import audit

All logarithms below are natural. Source formulas expressed in bits are
multiplied by `ln 2`. The sandwiched divergence is

\[
 \widetilde D_\alpha(\rho\Vert\sigma)=
 \frac1{\alpha-1}\log\operatorname{Tr}
 (\sigma^{(1-\alpha)/(2\alpha)}\rho
  \sigma^{(1-\alpha)/(2\alpha)})^\alpha,
 \qquad \alpha>1.
\]

It is infinite when the required support inclusion fails. No logarithm of an
uncontrolled zero eigenvalue is taken.

### 1.1 Wilde–Berta–Hirche–Kaur

Primary source: *Amortized Channel Divergence for Asymptotic Quantum Channel
Discrimination*, arXiv:1808.01498v2, 18 June 2020. The paper restricts its
systems to finite dimension in §II.1. Proposition 41, equation (283), states
amortization collapse for an arbitrary finite channel `N` against a fixed
replacer `R_tau`, for **every alpha>1**. Its proof begins with arbitrary
different input states `rho_RA,sigma_RA`, equations (284)–(291).

The exact applicable implication is

\[
 \widetilde D_\alpha((\mathrm{id}_R\otimes N)(\rho)
       \Vert\sigma_R\otimes\tau)
 \le\widetilde D_\alpha(\rho\Vert\sigma)
       +\widetilde D_\alpha(N\Vert R_\tau).
 \tag{A1}
\]

The proof actually upper-bounds the increment after subtracting the reference
marginal divergence; subtracting the full input divergence is weaker by data
processing. The unrestricted finite reference `R` may therefore contain both
laboratories, their memories, all question registers, and all previous records.
Its dimension need not equal the emitted message dimension in this amortized
application. The equality does **not** assert amortization collapse for two
arbitrary channels.

I read the complete displayed proof through (291). Its final completely
bounded norm step is an imported established result identified by the source;
I have not silently replaced it by an unproved scalar Hölder inequality.

Primary link: [Proposition 41 and proof](https://arxiv.org/html/1808.01498v2).

### 1.2 Gupta–Wilde

Primary source: *Multiplicativity of completely bounded p-norms implies a
strong converse for entanglement-assisted capacity*, arXiv:1310.7028v3,
11 August 2014. Lemma 5, **equation (5.16)**, is the exact minimax result;
the minimax exchange occurs between **(5.19) and (5.20)** and finishes at
(5.22). In particular, (5.19) alone is not the exchanged minimax identity.

The quantity has the untouched reference marginal in the denominator:

\[
 I_\alpha(N)=\sup_{\psi_{RA}\ \mathrm{pure}}\inf_{\tau_B}
  \widetilde D_\alpha(N(\psi)\Vert\psi_R\otimes\tau_B)
 =\inf_{\tau_B}\widetilde D_\alpha(N\Vert R_{\tau_B}).
 \tag{A2}
\]

This is exactly the principal's orientation. Neither a denominator with the
actual output marginal fixed and the reference optimized, nor a one-system
output norm, is substituted. The source's preceding Lemma 4 supplies the
convexity/concavity used by Sion's theorem. I read that proof and the complete
Lemma 5 proof. All channels in the current theorem meet the source's finite
CPTP hypotheses. A full-rank perturbation of `tau_B` can supply arbitrarily
small slack when a minimizer has a kernel; nothing requires an inverse on the
kernel of a zero marginal.

Primary link: [Lemma 5, equations (5.16)–(5.22)](https://arxiv.org/html/1310.7028v3).

### 1.3 Strongest exact predecessor of the guessing-game specialization

Cooney–Mosonyi–Wilde, arXiv:1408.3373v2, Theorem 4, equation (2.18), already
gives the Rényi upper bound on success in entanglement/quantum-feedback-assisted
channel coding. Li–Yao, arXiv:2209.00555v3 (27 June 2024; IEEE TIT 70(7),
5017–5029), **Theorem 6, equation (29)**, proves that this exponent is exact
for entanglement-assisted classical coding. Its **Corollary 7, equation (30)**,
proves the same exact exponent with quantum feedback. Thus this fixture's
capacity boundary and optimal exponent are established channel-coding facts,
not a new discovery from repetition.

Jain–Kundu arXiv:2106.04299v3, Lemma 8, already supplies the noiseless
teleportation/transcript-guessing bridge. Kundu–Lalonde arXiv:2609.05122v1,
Lemma 17 and its general noisy-entanglement repetition argument, also use a
Rényi probability-transfer inequality against a game-value comparator. Their
noise acts on the preshared entanglement, rather than arbitrary interactive
message channels, so that theorem is not substituted for (A1).

The present proof is a synthesis/application of these established entropy,
channel and game-comparison mechanisms. Historical novelty of its exact
general-game statement has **not** been established by the literature search.

## 2. The strengthened source-and-channel theorem

Let `H` be a finite game with a `[0,1]` acceptance payoff and joint question
law `mu`. Set `s_H=omega_co(H)`. A source state has the cq form

\[
 \rho_{QAB}=\sum_u |u\rangle\langle u|_Q\otimes\rho^u_{AB},
 \qquad \sum_u\operatorname{Tr}\rho^u=1.
\]

The question register `Q=(X,Y)` is copied classically into the respective
players' local input registers when the protocol starts. The actual question
law may differ from `mu`; that deviation is included in the source cost. An
independent reference state is

\[
 \sigma^{\rm ind}_{QAB}=\mu_Q\otimes\sigma_{AB}.
\]

The players use finite-dimensional ordinary tensor-product resources and
finite local quantum instruments. They communicate through a **fixed finite
list** of finite-dimensional memoryless CPTP slots `N_1,...,N_m`, in prescribed
directions, with independent inaccessible channel environments. Every
cross-player classical control, timing signal, feedback message and quantum
register must be in that list. Local operations can depend arbitrarily on
local input, received systems and local outcomes.

For a fixed order, define

\[
 J_\alpha(\rho\mid\mu)=\inf_{\sigma_{AB}}
 \widetilde D_\alpha(\rho_{QAB}\Vert\mu_Q\otimes\sigma_{AB}),
 \qquad C_\alpha=\sum_j I_\alpha(N_j),
 \qquad t_\alpha=\frac{\alpha-1}{\alpha}.
 \tag{A3}
\]

The infimum is over initial device states of the same tensor protocol. A
different independent reference state and different fixed replacers may be
chosen for each order; the resulting comparison strategy is always bounded
by the same game value.

**Theorem R1.** Under these assumptions,

\[
 \boxed{p_H\le\min\left\{1,\inf_{\alpha>1}
 \exp\big[t_\alpha(\log s_H+J_\alpha+C_\alpha)\big]\right\}.}
 \tag{A4}
\]

**Proof.** Fix `alpha>1`, an initial independent reference state, and
fixed replacers within arbitrarily small positive slack of (A2). Run exactly
the same local controlled CPTP maps on the actual and reference states, but
replace every communication channel in the reference execution by its fixed
discard-and-prepare map. The initial divergence is at most `J_alpha` plus
the chosen source slack. Between slots, data processing does not increase
it. At a slot, use (A1) with all remaining global systems in `R`; the actual
and comparison inputs can be different because of every earlier channel
and every local adaptive operation. Thus after all slots,

\[
 \widetilde D_\alpha(\rho_{\rm final}\Vert\sigma_{\rm final})
 \le J_\alpha+\sum_j I_\alpha(N_j)+o(1).
 \tag{A5}
\]

Every reference receiving system is prepared locally in a fixed state. The
sender only discards its local system. The all-replacer execution is
therefore a legal zero-communication tensor strategy with the original joint
question law, even when its local maps branch adaptively. Its acceptance
probability `z` is at most `s_H`. Apply the same binary accept/reject
measurement to both final states. Classical binary divergence gives

\[
 \widetilde D_\alpha(\rho_{\rm final}\Vert\sigma_{\rm final})
 \ge \frac1{\alpha-1}\log[p^\alpha z^{1-\alpha}
                  +(1-p)^\alpha(1-z)^{1-\alpha}]
 \ge \frac\alpha{\alpha-1}\log p-\log z.
\]

Rearrange, use `z<=s_H`, send the independently chosen slacks to zero, and
optimize over `alpha`. This proves (A4). If the source cost is finite and
`s_H=0`, support inclusion and the same binary argument force `p=0`.
When `s_H=1` the trivial upper bound one is retained. ∎

There is no need to force a finite-matrix approximation to arbitrary commuting
strategies into this proof. It is uniform over finite resource dimensions and
uses the larger commuting game value as the zero-communication comparator.

## 3. Smooth sources, maximum-order defects and transcript edits

### 3.1 Trace-distance Rényi smoothing

Suppose the actual cq source is within trace distance `eta` of a normalized
cq source `rho'` for which the costs in (A3) are certified. The complete
protocol, including the final event, is a CPTP map followed by a binary effect.
Hence its acceptance probabilities differ by at most `eta`, and

\[
 p_H\le \min\{1,\eta+
 \inf_{\alpha>1}\exp[t_\alpha(\log s_H+J_\alpha(\rho'\mid\mu)
                                  +C_\alpha)]\}.
 \tag{A6}
\]

No channel-use factor multiplies `eta`. One may optimize over the nearby cq
state separately at each order, obtaining a smooth source Rényi profile,
provided the smoothing distance and normalization convention are stated.

### 3.2 The frozen initial report's operational defect

The earlier `E_h<=eta` hypothesis means exactly that every controlled initial
effect obeys `P_actual<=e^h P_ind+eta`. Applying it to the **entire actual
channel protocol** first, then using R1 for the independent source, gives

\[
 p_H\le \min\{1,\eta+e^h
        \inf_{\alpha>1}\exp[t_\alpha(\log s_H+C_\alpha)]\}.
 \tag{A7}
\]

This also leaves `eta` unamplified. It is not legitimate to replace this
operational defect by a trace-distance smoothing statement at the same `eta`
without proving such a quantum smoothing lemma.

The two interfaces already differ for `2 x 2` states. Let
`rho=|0><0|`, `sigma=|+><+|` and `e^h=2`. Then

\[
 \operatorname{Tr}(\rho-2\sigma)_+=(\sqrt5-1)/2,
 \qquad T(\rho,\sigma)=1/\sqrt2>(\sqrt5-1)/2.
\]

Any normalized state `rho'<=2 sigma` has support in the one-dimensional
support of `sigma`, so it must equal `sigma`. Therefore this operational
defect does not imply existence of a normalized dominated state within the
same trace-distance error. The distinction is mathematical, not just a
choice of smoothing notation.

If exact order domination holds (`eta=0`), it additionally implies
`J_alpha<=h` for every order, by `D_alpha<=D_max`, and (A4) gives the potentially
stronger bound with `h` **inside** `t_alpha`. For a genuinely nearby normalized
dominated state, (A6) gives that stronger form plus its actual smoothing error.

### 3.3 Adversarial record edits

Apply R1 to the `n`-copy threshold event for a base game `G`. If the referee
accepts at most `r` observed coordinate failures, and an adversary modifies
at most `t` answer records after the exchange, acceptance implies at most
`r+t` original failures. With

\[
 \delta=\epsilon-(r+t)/n>0,
 \quad b=2^{-78}\delta^5/[\epsilon^2(\delta+\log|A||B|)],
\]

the stipulated N446 capital supplies `s_H<=exp(-bn)`. Thus (A6) becomes

\[
 \boxed{p_{\rm accept}\le\min\{1,\eta+
 \inf_{\alpha>1}\exp[-t_\alpha(bn-J_\alpha-C_\alpha)]\}.}
 \tag{A8}
\]

The exact integer/ceiling argument is the one in the frozen constructor
report and its 11,734 checked rational cases; no independence of coordinate
wins is asserted. For no edits and all-wins acceptance, use the original
stronger N443 exponent instead. This is independent of `FR(K)`.

## 4. Capacity tolerance and the source regularity obstruction

For a fixed finite family of channels with use counts `m_k(n)/n -> beta_k`,
`I_alpha(N_k)->C_E(N_k)` as `alpha` decreases to one. Hence, for independent
sources, `sum beta_k C_E(N_k)<b` gives a fixed order above one with a positive
exponent in (A8), for all sufficiently large `n`.

For correlated sources the exact sufficient condition is the existence of a
**fixed** `alpha>1` with

\[
 \limsup_{n\to\infty}J_\alpha(\rho_n\mid\mu^n)/n
       +\sum_k\beta_k I_\alpha(N_k)<b.
 \tag{A9}
\]

A criterion using only the rate of the Shannon/relative-entropy source cost
is false for arbitrary `n`-dependent sources. Here is an explicit optimized
source calculation strengthening the initial rare-leak obstruction.

Let `X` be uniform on `N=2^n` strings. With probability `tau`, give Bob a
complete copy of `X`; otherwise give a distinguished no-leak symbol. The
branch choice is independent of `X`. Direct classical minimization over
the independent distribution on Bob's symbol gives

\[
 J_\alpha=\frac1{t_\alpha}
    \log[(1-\tau)+\tau N^{t_\alpha}].
 \tag{A10}
\]

To verify this, put `A_l=sum_x mu(x) P(l|x)^alpha`. Minimizing
`sum_l A_l sigma_l^(1-alpha)` gives `sigma_l` proportional to `A_l^(1/alpha)`;
the sum of these roots is `(1-tau)+tau N^t`. For the guessing game `s_H=1/N`,
R1 then gives

\[
 p\le \tau+(1-\tau)N^{-t_\alpha}.
\]

The limit `alpha->infinity` is exactly the actual success
`tau+(1-tau)/N`. Taking `tau=1/n` gives `J_1=ln2`, but for **every fixed**
`alpha>1`, `J_alpha/n -> ln2`. Thus the naive use of `J_1/n->0` would falsely
predict exponential security. Fixed i.i.d. finite-alphabet sources do have
the needed regularity; the BSC source in the companion report is a worked
example. General uniform Rényi regularity must be an assumption or a proof.

## 5. Constructive hostile tests and non-negotiable scope

I found no counterexample within P3/R1's exact hypotheses. These scope
changes do break the proposed argument and, in simple cases, the conclusion:

- **Uncharged classical control or free reverse communication.** A channel
  label, skipped-slot signal or timing choice can itself communicate. The
  fixed slot list and all charged cross-cut systems are essential. The
  general game bound does not assert that arbitrary free backward channels
  cost nothing; ordinary channel-coding feedback theorems exploit the
  special one-way message task.
- **Correlated channel environments.** If a single uniform bit `K` masks
  every classical message as `Y_j=X_j xor K`, each isolated one-use marginal
  is a zero-capacity replacer. A pilot `X_1=0` reveals `K` to the receiver,
  after which all later bits are recovered. Treating these memory channels
  as independent zero-capacity slots would give a false bound. Include the
  memory as part of the channel process, or retain the memoryless hypothesis.
- **Accessible environments.** A discarded environment can carry the
  supposedly lost message. Every accessible environmental output must be
  included in the channel output or separately charged.
- **Expected use counts.** The initial one-bit expected-communication attack
  still applies. A rare high-use branch can carry a full input while leaving
  a small average count. The theorem needs its fixed finite budget/list or
  a separately proved process-divergence bound.
- **One-system marginal tests.** Dense coding uses identical emitted qubit
  marginals for four orthogonal joint states with the receiver's reference.
  Replacing `I_alpha(N)` by a marginal-state divergence fails. Stabilization
  and the exact untouched-reference denominator in (A1)–(A2) are essential.
- **Arbitrary commuting Rényi import.** All cited finite-order theorems
  explicitly use finite-dimensional systems. The proof does not acquire
  arbitrary finite-von-Neumann amortization/minimax merely from Lin's
  finite-table closure. That unproved extension remains separate.

## 6. Arbitrary-commuting maximum-order channel theorem remains valid

The explicit commuting-start instrument model in the frozen constructor
report does permit a channel generalization without a finite-order entropy
import. For a finite message channel `N`, define

\[
 M(N)=\min\{\operatorname{Tr}S:S\ge0,\ I\otimes S\ge J_N\},
\]

with unnormalized Choi matrix `J_N`. The constraint means
`N<=M(N) R_{S/M(N)}` in **complete positive order**, including every reference.
Replacing a slot by this domination in the positive protocol network and
iterating gives, for a question-independent arbitrary commuting-start resource,

\[
 p_H\le s_H\prod_j M(N_j).
\]

The controlled-effect source defect applied to the entire network then yields

\[
 \boxed{p_H\le\min\{1,e^h s_H\prod_j M(N_j)+\eta\}.}
 \tag{A11}
\]

CP positivity of the difference is reference-uniform and remains positive
when applied to finite message matrices with entries in the local resource
algebras. Thus the positive-functional argument does not require a matrix
approximation of the original resource. For identity qubit channels,
`M=4`; for classical bit channels, `M=2`, recovering the frozen theorem.
This is a CP-order extension of that theorem, with its explicit local
instrument model, not a finite-order von Neumann Rényi theorem.

## 7. Scientific accounting

The full finite-order telescope and its source extension have complete proofs
from checked primary imports. The mechanism is inherited from strong-converse
channel discrimination, not renamed as a new foundational discovery. The
concrete examples demonstrate a real strict mathematical increase over crude
counting, while retaining the linear questions/answers and potentially enormous
repetition cost. They supply no alphabet reduction, efficient single-device
cryptographic verifier, new DIQKD theorem, quantum PCP compiler, or physical
demonstration.

The separate decisive operation pursued by the other researchers—removing
question-correlated answer charges with one legal commuting local resource—is
not solved by R1. This theorem treats additional information flow once a valid
zero-communication game bound is already available.
