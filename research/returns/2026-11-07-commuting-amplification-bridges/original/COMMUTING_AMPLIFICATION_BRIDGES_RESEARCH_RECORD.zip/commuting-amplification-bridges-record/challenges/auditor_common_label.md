# Constructive hostile audit: retained common block labels

7 November 2026. Post-freeze exposed review. The initial auditor report is
unchanged. Reviewed machinery's initial report, `common_label_register_proof.md`,
`common_amplification_lemma.md`, and `finite_tracial_transfer_candidate.md`.

## Disposition

**M5--M9 pass the finite-tensor register audit with the explicit private/external
copy separation now supplied.** I did not find a counterexample. The proof below
reconstructs the contested operation and isolates the exact necessary choices.
Parent domination alone would not establish operational extraction; the final
section separately resolves the principal's parity-history challenge.

The private own-label copy must remain in each residual workspace. Every
external history copy must be omitted from the parent comparison. In
particular, retaining a Bob-created history copy inside Alice's preselection
parent is invalid: Bob's question-controlled isometry would then fail to
disappear. Nor may one trace all extra label copies from the accepted *global*
vector while subsequently treating it as pure. The corrected construction
does neither.

## 1. Explicit local dilation and common pure target

Fix tested questions `c=(x_D,y_D)`. Choose a coherent Stinespring dilation of the
original complete local joint POVMs, retaining every fine answer and the full
environment. No checked fine-answer copy is traced out: this preserves
coherence between fine answers within an accepted block.

For disjoint-block predicates the tested acceptance event has local labels
`k_A=f_c(a_D)`, `k_B=g_c(b_D)`, with distinct losing sentinels, and is exactly
`k_A=k_B` in the legitimate block set. At fixed `c` these are ordinary local
controlled isometries, depending on `c` and the own live string only. Computing
three copies `L_A^1,L_A^2,L_A^3` of the local block label and likewise for Bob is
a basis-copy isometry. Keep `L_A^2` and every original Alice fine record in
`E_A`; similarly define `E_B`.

Project the complete pure preselection vector onto equality of legitimate
labels. The accepted vector is still pure. On this vector all six copies have
the same value `k`. Put

\[
 H_{A,\mathrm{label}}=(L_A^1,L_B^3),\qquad
 H_{B,\mathrm{label}}=(L_B^1,L_A^3).
\]

These are analytic register assignments of the accepted target, not claims of
physical communication. Both histories contain the same label; the two
redundant copies inside either history can be compressed by a fixed basis
isometry. Fine checked records stay in `E_A,E_B` throughout. Conditional on
`c,k`, all omitted history copies are fixed basis factors, so the residual
copied-input vector on `R_J X_J Y_J E_A E_B` is genuinely pure.

For coordinate `i`, use exactly the complementary question-copy partition

\[
 \begin{split}
 A_i&=H_{A,i}\,\widehat X_{<i}X_{<i}E_A,\\
 B_i&=H_{B,i}\,\widehat Y_{>i}Y_{>i}E_B,
 \end{split}
\]

where `H_A,i` contains the Alice history-label pair, both tested question
strings through their assigned copies, `hat Y_<i,X_>i`; `H_B,i` contains the
matching opposite copies. Together with protected `R_i=hat X_i hat Y_i` and
fresh `X_i,Y_i`, these partition the same accepted pure vector. Thus the two
parents used for extraction are margins of **one** target. Reading its fresh
questions and original fine output positions gives the original conditioned
coordinate table exactly.

## 2. Parent domination and the conditional-comparison property

Set `K_A=X_J E_A`. In Alice's preselection comparison trace every external
history-label copy, all Bob systems and `Y_J`. Tracing an Alice external label
copy dephases her private `L_A^2`; tracing Bob's complete isometry eliminates
it. What remains is an isometry depending only on Alice's own live string,
followed by a local channel dephasing the block label. Hence the result has
Jain's original `mu_J`-conditional comparison form. The seed need not be pure.
It can retain private labels, fine checked records, local controlled outputs
and arbitrary local environment. Its reference law still attaches
`mu_J(y|x)` coherently in `x`.

In private-label block `k`, Bob's accepting restriction is a positive
contraction on a subsystem which is then traced. Applying it gives a positive
operator `T_k` bounded by the unselected Alice block `S_k`. This argument is an
operator inequality on the full copied-question/Alice system, not only on its
diagonal measured entries. Therefore

\[
 p_c\rho_{A,c}=\bigoplus_k T_k\le\bigoplus_{k_A}S_{k_A}
                       =\sigma_{A,c}.
 \tag{1}
\]

Every supported normalized target block `rho_A,c,k` is dominated by
`sigma_A,c/(p_c q_c(k))`, so all full divergences needed below are finite.

Let `Z` be the external ensemble label for the successful common block. Each
target retains the orthogonal private copy `L_A^2=Z` in `K_A`. Donald's identity
on the two relevant marginals gives

\[
 \begin{split}
 &\sum_k q_c(k)[D(\rho_{A,c,k}\|\sigma_{A,c})
       -D(\rho_{A,c,k}^{K_A}\|\sigma_{A,c}^{K_A})]\\
 &=D(\rho_{A,c}\|\sigma_{A,c})
       -D(\rho_{A,c}^{K_A}\|\sigma_{A,c}^{K_A})
       +I(Z:R_J\mid K_A)\\
 &\le\log(1/p_c).
 \end{split}\tag{2}
\]

The CMI is zero because the retained private orthogonal copy determines `Z`,
and (1) bounds the first divergence by `log(1/p_c)`. Bob is symmetric. This
proof does not assume that `k` is independent of questions or physically
available to both players before the fresh inputs.

## 3. Ordered allocation: what is and is not conditioned in the comparison

For each fixed successful `c,k`, apply the ordered chain rule to
`rho_A,c,k` and `sigma_A,c`. The private label remains in `K_A`; it is **not**
chosen as an additional conditioning record in the comparison. Alice traces
`R_>i` and conditions only on `Y_<i,X_>i`. This operation is outside the fresh
`hat X_i,X_i,hat Y_i` triple and commutes with the original conditional-law
attachment map, so the restricted comparison remains a `mu_i`-conditional
comparison. Bob uses the complementary reverse order. Each state uses its own
normalization on the exposed record.

Restore the external history `h=(c,k,Y_<i,X_>i)` in both recorded coordinate
states, with the target history weights. The target block has private label
`L_A^2=k`; the comparison block still averages its internal private label. This
need not equal the external history label in the comparison. That difference
is permitted by the definition of a conditional comparison and is exactly the
retained-marginal divergence being subtracted.

Jain Lemma 2.24 is a direct relative-entropy telescope under these choices.
Summing (2) and then averaging `c` gives

\[
 \sum_i b_{A,i}\le L,\qquad\sum_i b_{B,i}\le L,
 \qquad L=\log(1/p_D),\tag{3}
\]

because
`E_{c|E} log(1/p_c)=log(1/p_D)-D(P_{c|E}||mu_D)<=L`.
The same construction permits independent heterogeneous referee laws by using
the coordinate's own conditional-law attachment map. The separate ordinary
postselection inequality gives

\[
 \sum_i D(q_i^{X_iY_i}\|\mu_i)\le L.\tag{4}
\]

Equations (3)--(4) prove M9 for the **unconditional recorded coordinate
family**, with `t_i=b_A,i+b_B,i+d_i` and `sum_i t_i<=3L`.

## 4. The parity challenge is real but does not break this construction

Let all live referee pairs be `(X_j,Y_j)=(Z_j,Z_j)` for independent fair bits.
Let a checked common label be `k=parity(Z_1,...,Z_m)`, accepted with certainty.
For history `h=(k,Z_<i,Z_>i)`, the conditional live pair is a point mass, so

\[
 \mathbb E_h D(q_i^{XY\mid h}\|\mu_i)=\log2,
 \qquad D(q_i^{XY}\|\mu_i)=0.\tag{5}
\]

Thus a proof substituting conditional-history drift into (4) would be false,
and drawing `h` from its posterior marginal independently of the fresh pair
would be incorrect.

The current construction prepares the full target family

\[
 |\phi_{xy}\rangle=
 \sum_h\sqrt{q(h\mid x,y)}\,|h,h\rangle\,|\phi_{hxy}\rangle,
\]

then reads the original answer positions. It does not make either substitution.
In the parity fixture the two players can pre-share the outside bits and
compute the required parity from their respective equal fresh bit. Both
history outputs then have the exact correct conditional law. The relevant
conditional deficits are zero: the copied diagonal relation `Y=X` is already
determined by the retained local `X` or `Y`, so deleting the protected copies
loses no relative entropy. This illustrates why the external history must stay
inside the preparation target rather than become fresh-question-independent
side information.

If one wishes instead to extract explicit local history kernels, let `Q` be
the actual recorded classical question/history law and define
`P_A(h|x)=Q(h|x)`, `P_B(h|y)=Q(h|y)`. The chain rule gives exactly

\[
 D(Q\|\mu P_A)=D(Q_{XY}\|\mu)+I(Y:H\mid X)
                         \le d_i+b_{A,i},\tag{6}
\]

with the symmetric inequality for Bob; the last step is Jain's information
lower bound and data processing of retained workspaces to history. Pinsker
then supplies the same kind of input-dependent local history coupling as H.
No `Q_H tensor mu` premise follows or is needed.

## 5. Finite-von-Neumann qualification

The argument above has a normal-state finite-tracial analogue: all quantum
systems beyond finite classical controls are handled by restriction to the
appropriate left/right algebra, and complete opposite-side instruments
disappear by commutation and completeness. Parent densities are bounded when
the initial standard-form vector and finite local coefficients are bounded.
Operator domination, finite classical direct sums and relative-entropy chain
identities do not require matrix approximation.

That statement does not by itself supply local preparation. The separate
finite-tracial replacement/common-amplification proof must be checked; it is
addressed in `auditor_finite_tracial_transfer.md`. Subject to that proof, there
is no remaining private-label/pure-target counterexample in M5--M9. There is
also no permission to extend the common-label identity to arbitrary masks:
its exact local common output depends on the disjoint-block hypothesis.
