# Principal final proof checks and small simplifications

7 November 2026. Written after independent reports and cross-challenges. This is a proof check, not a rewrite of the initial record. The original published files remain unchanged.

## 1. The positive-slack limit needs no new infinite-dimensional compactness theorem

Let (P,tr) be finite, rho,nu bounded densities with D(rho||nu)<infinity, and let nu0 be a bounded density with nu0>=cI in the supported finite-question corner. Define rho_d=(1-d)rho+d nu0 and nu_d=(1-d)nu+d nu0. Both are uniformly bounded above, and nu_d>=dcI. The entropy term tr rho_d log rho_d converges by uniform continuity of x log x on a fixed bounded spectral interval. For the cross term:

  tr rho_d log nu_d=(1-d)tr rho log nu_d+d tr nu0 log nu_d.

The second summand tends to zero because its absolute value is O(d(1+|log d|)). Operator monotonicity gives log nu_d>=log nu+log(1-d), so limsup[-tr rho log nu_d]<=-tr rho log nu. Conversely for every eta>0,

  -tr rho log nu_d >= -tr rho log(nu_d+eta I).

The right side converges in operator norm at fixed eta; let eta decrease to zero using normal monotone spectral integration. This gives the reverse liminf and proves D(rho_d||nu_d)->D(rho||nu). The retained marginal has exactly the same proof. Thus the difference of the two finite divergences converges, without subtracting infinite entropies or assuming a spectral gap at zero.

Also rho_d->rho in operator norm. Uniform continuity of square root gives ||sqrt(rho_d)-sqrt(rho)||_2->0. The trace-norm Holder bound

  | ||sqrt(rho_d)sqrt(eta_d)||_1-||sqrt(rho)sqrt(eta_d)||_1 |
      <=||sqrt(rho_d)-sqrt(rho)||_2

holds for EVERY normalized eta_d, regardless of how its spectra depend on d. This directly proves the fidelity-slack passage needed by the replacement construction. No state compactness is used.

## 2. A self-contained measured-divergence/fidelity bridge in finite trace

For bounded invertible densities rho,eta in a finite algebra put

  H=rho^(-1/2)(rho^(1/2) eta rho^(1/2))^(1/2)rho^(-1/2).

Then H rho H=eta and tr rho H=F(rho,eta). Finite spectral partitions of the bounded invertible H give finite projective measurements with classical fidelity sum_j sqrt(p_j q_j) tending to tr rho H. Indeed q_j=tr rho H^2 E_j and H varies by arbitrarily little on each spectral interval. Scalar Jensen gives D(p||q)>=-2log sum sqrt(pq). Thus supremum measured relative entropy is at least -2log F(rho,eta). This is established fidelity-measurement machinery, proved here so no finite-matrix-only import is silently used. The positive-slack replacement states in the proof are boundedly invertible, which is enough; the original target is reached by the preceding limit.

The measured-divergence variational formula is also elementary here: operator concavity of log converts an arbitrary finite POVM/test vector into one positive invertible W, and spectral partitions of W give the reverse inequality by finite step approximation. Junge–LaRacuente's Lemma VI.2 in the published JMP version is the exact general-von-Neumann primary comparator. No novelty claim is attached to either fact.

## 3. Where relative-entropy monotonicity enters

The four-log replacement inequality itself gives b>=D_meas>=0 for discarding any finite reference matrix algebra. Hence the finite-register data-processing steps used to bound target conditional mutual information are already contained in the same imported multivariate trace theorem; no finite-dimensional-only monotonicity theorem is needed. Pinching or a finite classical output may be realized by a finite controlled isometry and discarding a finite register. All other chain/direct-sum identities follow from block functional calculus. Standard relative-entropy monotonicity is of course established machinery; it is not newly discovered here.

## 4. Same target, different parents: checks of the new central operation

I independently reconstructed the factor sqrt(w_l) on the common target and the congruence Z(I-Q_T)Z* on Alice's parent. The Bob version is in the opposite algebra and never exchanges noncommuting same-algebra factors. The parents are separate comparisons, so their two sqrt(w_l) factors are never multiplied together. Raw-success normalization by G_A,c/G_B,c is valid because the conditional-comparison seed allows any local fresh-X/fresh-Y marginal. The square-root/polar local-description proof explicitly does not require reference marginal agreement with the target: the overlap estimate uses only normalization of the comparison law and Cauchy–Schwarz. This was the decisive missing operation.

For fixed tested questions, every supported target branch l is dominated by its reference with factor G_A,c/(p_c q_c(l)). Thus all displayed full divergences are finite, despite original zero spectra. The private l copy makes the CMI term zero. The exact tilted averaging gap is a classical relative entropy, not an unproved comparison of posterior and prior expectations. The actual G quantities are finite linear functions of the observed one-sided correlation table and therefore pass the scalar Lin limit.

## 5. Sampler and constants

The standalone sampler accepts finite unit L2 families in any finite von Neumann algebra and arbitrary fine local/opposite POVMs. It is not an original-algebra trace-preserving output channel. Its Section 8 good-vector/bad-probability estimate gives sqrt(beta_q)<=sqrt(alpha)+75s^(1/4)+o(1), s=b_A+b_B. For an all-input loss function ell in [0,1],

  |sqrt(E_q ell)-sqrt(E_mu ell)|
      <=||sqrt q-sqrt mu||_2<=sqrt(D(q||mu)).

For t=s+D(q||mu)<=1, the resulting coefficients are 152 and 5776; both are below K=65536. For t or descriptor discrepancy outside the small regime the bound one is enough. The parity-history fixture uses UNCONDITIONAL d_i and whole-workspace reconstruction, so no conditional-history drift is smuggled into this step.

With t0=1/(256K^4)=2^-72, the homogeneous charged greedy denominator is 3+4kappa/epsilon+2t0 epsilon. It is bounded above by 8(1+kappa/epsilon), proving the conservative rate 2^-75 epsilon^3/(epsilon+kappa). At kappa=0 this is the claimed quadratic rate. The heterogeneous zero/controlled-charge proof uses the same cap alpha_i'=min(alpha_i,epsilon_i) as the earlier scalar dossier; omitting that cap would invalidate its Holder step.

## 6. Remaining scope tests

- The new construction supplies finite-tracial operational witnesses; after Lin only a scalar table statement is claimed. It does not give matrix approximations of arbitrary commuting tables.
- All opposite-algebra finite amplifications remain exact on every local input pair, even unsupported ones. Degenerate input branches use fixed complete defaults.
- The classical private-label and question records are finite. No infinite individual von Neumann entropy is subtracted.
- The general charge can remain positive when epsilon decreases. This closes the charged FR premise and gives quadratic block/projection repetition; it does not prove arbitrary-predicate quadratic repetition.
- The Renyi channel telescope uses ordinary finite-dimensional protocol states and fixed memoryless cross-cut channels. It is not silently extended to arbitrary co initial algebras. The independent CP-order/transcript result has its own broader explicit local-instrument model.
- In the channel theorem, input/source and all channel terms use one common Renyi order. The original hockey-stick operational source defect is not trace-distance smoothing; its e^h remains outside the finite-order bound, with eta added once afterward.
