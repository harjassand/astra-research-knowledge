# Constructor audit: one common weighted target and two local completions

7 November 2026. Cross-challenge of
`principal_one_sided_rectangle_candidate.md`. Frozen initial reports are
unchanged. This report checks the finite-tensor construction, its exact
operator-matrix identities, preservation of the required measured table,
the separate-parent quantifier, and the tilted load average. The finite
von Neumann recovery/sampler transfer is checked separately by the other
researchers.

## 1. Disposition

**The candidate passes these checks.** The crucial operation is legitimate:
one target carries amplitude `sqrt(w_l)`, while Alice and Bob each use their
own local parent with that same amplitude. They need not be simultaneous
margins of one preselection state. The target's unmeasured coherences may
change; its complete original question/fine-answer probability table is
preserved exactly. The preparation theorem applies to the new common pure
target, with its original local answer-record measurements.

This proves the general fractional-rectangle parent inequalities and charges,
without a disjoint-block assumption, and supplies the missing charged input
to the separately checked finite-tracial reconstruction theorem. It does not
remove `kappa`, and therefore does not prove general quadratic repetition.

## 2. Setup and one refined target

Fix tested questions `c` and suppress that index temporarily. Let the full
live questions be `x,y` with independent-between-coordinate prior `mu_J`.
The original full local answer strings are `a,b`; write

\[
 U_x=\sum_a |a\rangle\otimes A_{x,a},\qquad
 V_y=\sum_b |b\rangle\otimes B_{y,b},
\]

where `A_xa=sqrt(P_xa)`, `B_yb=sqrt(Q_yb)` and the original full POVMs obey
`sum_a P_xa=sum_b Q_yb=I`. This is a coherent dilation of the original joint
measurements. No product across answer coordinates and no same-party
commutation is assumed.

Choose an exact finite nonnegative decomposition

\[
 V_D(c,a_D,b_D)=\sum_lw_l\,1_{R_l}(a_D)1_{T_l}(b_D).
 \tag{S1}
\]

Its row and column loads are bounded by `A_c,B_c>=1`. Nonempty rectangles
with zero weight can be dropped. Define the accepted refined vector by
attaching three copies of `l` on each side with amplitude

\[
 \sqrt{w_l}\,1_{R_l}(a_D)1_{T_l}(b_D)
\]

to every original coherent fine-output vector, then normalizing by
`sqrt(p_c)`. Its norm squared is exactly `p_c`, by (S1).

For every complete original question/fine-output tuple,

\[
 \sum_l \Pr_{\Phi_c}(x,y,a,b,l)
 =\frac{\mu_J(x,y)}{p_c}V_D(c,a_D,b_D)
      \|(A_{x,a}\otimes B_{y,b})\psi\|^2.
 \tag{S2}
\]

Thus **the entire measured table**, not merely its winning mean, is exactly
the original table conditioned on the tested event. Every live-coordinate
conditional loss, every joint win-indicator law, and every further tested
event derived by classical sums from that table is preserved.

### Why changed coherences are allowed

On the original winning fine-record subspace define the global controlled
isometry

\[
 W_c:|a,b\rangle\longmapsto|a,b\rangle
      \sum_l\sqrt{w_l}1_{R_l}(a_D)1_{T_l}(b_D)
                 |l,l,l\rangle_A|l,l,l\rangle_B.
 \tag{S3}
\]

Each appended vector has norm one by (S1), and distinct fine records remain
orthogonal. This is therefore an isometry on that subspace. It generally is
not a local physical isometry. It is used only to define the new mathematical
target. It intertwines every diagonal original question/fine-record projector,
which proves (S2) directly. After tracing label records, off-diagonal
fine-record coherences can change and usually do.

The local reconstruction theorem does not require the target to be obtained
by a physical local operation on the original resource. It requires an
arbitrary copied-input pure family, two valid conditional comparisons with
finite divergences, and local answer measurements. The new target meets the
first condition by construction. The answer measurements remain the local
projectors reading `a_i` and `b_i`; they commute across players on every
input pair. Sections 3–5 verify the comparisons and charges. Consequently the
new target is reconstructed with its own charged preparation error, rather
than assumed freely available.

Across different tested sets `D`, different target extensions may be used.
The finite scalar hypothesis requires an existence statement for each `D`;
it does not require one simultaneous physical protocol for all tested sets.
For a fixed `D,c`, the same full `Phi_c` is used for every live coordinate and
both orientations, so the ordered relative-entropy allocation remains valid.

## 3. Explicit parent matrices for arbitrary full POVMs

For finite tensors write the original pure resource as a coefficient matrix
`Psi` under the convention
`(A tensor B)|psi> <-> A Psi B^T`. Its norm is the Frobenius norm.
For fixed `c,y,l`, construct the rectangular matrix `C^A_l,y` with rows
`(x,a,i_A)` and columns `j_B`:

\[
 (C^A_{l,y})_{(x,a,i),j}
  =\sqrt{w_l\mu_J(x,y)}1_{R_l}(a_D)
                      (A_{x,a}\Psi)_{i,j}.
\]

Let `Q_y,T_l=sum_{b:b_D in T_l}Q_yb`, an ordinary positive contraction.
The unnormalized one-sided parent and common target blocks are exactly

\[
 S^A_{l,y}=C^A_{l,y}(C^A_{l,y})^*,
 \qquad T^A_{l,y}=C^A_{l,y}Q_{y,T_l}^{\mathsf T}(C^A_{l,y})^*.
 \tag{S4}
\]

The transpose arises only from the specified vectorization convention;
`Q^T` is positive. Summing Bob's complete fine outcomes gives `S`, while
restricting them to `T_l` gives `T`. Hence

\[
 S^A_{l,y}-T^A_{l,y}
 =C^A_{l,y}(I-Q_{y,T_l}^{\mathsf T})(C^A_{l,y})^*\ge0.
 \tag{S5}
\]

All cross terms in `x,x',a,a'` are retained. This is a full operator
inequality, not a statement only about diagonal probabilities. It is valid
for arbitrary noncommuting `P_xa,Q_yb`.

Bob has the symmetric matrices, using `Psi^T` and rows `(y,b,j_B)`,

\[
 S^B_{l,x}=C^B_{l,x}(C^B_{l,x})^*,
 \quad T^B_{l,x}=C^B_{l,x}P_{x,R_l}^{\mathsf T}(C^B_{l,x})^*,
 \quad S^B-T^B\ge0.
 \tag{S6}
\]

Both `T` families are the appropriate margins of **the same target** of §2.
Neither has a doubled weight: each matrix contains one factor `w_l`, not
`w_l^2`.

### Exact local completions

The successful part of Alice's parent is the local map

\[
 K_x^A=\frac1{\sqrt{A_c}}
   \sum_{a,l}\sqrt{w_l}1_{R_l}(a_D)
       |a\rangle|l,l,l\rangle A_{x,a}.
\]

Orthogonality of the retained fine/label records gives

\[
 (K_x^A)^*K_x^A
  =\frac1{A_c}\sum_a
       \Big(\sum_{l:a_D\in R_l}w_l\Big)P_{x,a}\le I.
 \tag{S7}
\]

Add `F_x^A=sqrt(I-(K_x^A)^*K_x^A)` in one orthogonal failure-record
branch, using a distinct failure sentinel in both private and external label
copies. Tracing external copies then dephases success/failure as well as the
legitimate labels. The complete map is an isometry. The square root lies in the same
local algebra and depends only on `c,x`. Bob uses his own construction with
`B_c,T_l`; its failure operator generally differs from Alice's.

Trace external label copies and the entire unselected opposite-party
isometry. The successful blocks of Alice's normalized parent are
`S^A_l,y/A_c`; the failure blocks make its trace exactly one. Its target
blocks are `T^A_l,y/p_c`, with zero target mass on failures. Therefore

\[
 p_c\rho_{A,c}\le A_c\sigma_{A,c},
 \qquad p_c\rho_{B,c}\le B_c\sigma_{B,c}.
 \tag{S8}
\]

The comparison is not conditioned on the successful common label. It still
averages its internal private label and all failure branches.

### Conditional-question form

In Alice's parent the complete Bob isometry is traced out. In the entries
of every remaining `y` block, the only `y` dependence is
`sqrt(mu_J(x,y)mu_J(x',y))`. Factoring this as

\[
 \sqrt{\mu_{J,X}(x)\mu_{J,X}(x')}
 \sqrt{\mu_J(y|x)\mu_J(y|x')}
\]

shows exactly `sigma_A,c=C_muJ(tau_A,c)`. Both the successful blocks and the
failure blocks have this property. The seed may be mixed and include the
private label and all original local fine records. Bob's separate parent
has the symmetric `mu_J(x|y)` form. Retaining a Bob-created history record
inside Alice's parent would invalidate this argument; no such record is
retained.

For a finite tracial original algebra, replace the coefficient-matrix
columns by entries `sqrt(w_l mu_J(x,y)) A_xa sigma` in a finite matrix
algebra over `M`. Then (S4) reads `T=C Q_T C*`, and (S5) is the same
congruence in `M`. Bob's calculation is in `M^op` with the matrix index and
coefficient-algebra orientation handled together. This proves parent
positivity algebraically without an infinite-commutant partial trace. The
subsequent finite-tracial entropy/recovery transfer remains the separately
audited step.

## 4. Private labels remove the ensemble charge

Trace external label copies in the parent/target marginal, but retain each
party's private copy. The label `l` is then a classical direct-sum block of
both the full state and its retained local marginal. Put

\[
 \rho_{A,c}=\bigoplus_l q_c(l)\rho_{A,c,l},\qquad
 b_A(\eta\Vert\nu)=D(\eta\Vert\nu)-D(\eta^{K_A}\Vert\nu^{K_A}).
\]

Direct-sum relative-entropy identities give exactly

\[
 \sum_lq_c(l)b_A(\rho_{A,c,l}\Vert\sigma_{A,c})
       =b_A(\rho_{A,c}\Vert\sigma_{A,c}).
 \tag{S9}
\]

Indeed each normalized block contributes a `-log q_c(l)` term to both
relative entropies, and the two terms cancel. Equivalently the private label
forces `I(l:R_J|K_A)=0` in Donald's identity. The target labels need not be
question independent. Full divergences are finite because each supported
normalized block is dominated by a finite multiple of the full comparison.

By (S8), operator monotonicity of logarithm gives
`D(rho_A,c||sigma_A,c)<=log(A_c/p_c)`. The retained divergence is
nonnegative, and therefore

\[
 \sum_lq_c(l)b_A(\rho_{A,c,l}\Vert\sigma_{A,c})
       \le\log(A_c/p_c).
 \tag{S10}
\]

Bob's bound is `log(B_c/p_c)`. The private label must remain in `K_A,K_B`;
tracing it out before subtracting the retained marginal would lose (S9).

## 5. Why the two parent states may be different

I independently checked the actual primary statement of Jain,
arXiv:2610.21410v1, Definitions 2.5, 2.6 and 2.8, Lemmas 2.24–2.25 and
the complete statement/proof of Lemma 4.1 through the two error bounds.

- Definition 2.5 takes an arbitrary copied-input **pure target family**.
- Definition 2.6 defines Alice's comparison by an arbitrary seed `tau_A`;
  Bob has an independently chosen symmetric seed `tau_B`.
- Lemma 4.1 constructs coherent alignment using Alice's comparison only.
  Bob's independently chosen comparison is used through Lemma 2.25 to bound
  `I(X:B|Y)` of the **same target**. Its proof never requires the two
  comparisons to be margins of a common preselection purification.
- The ordered allocation Lemma 2.24 is a relative-entropy identity for any
  fixed target/reference pair of the prescribed conditional form. It does
  not require the reference to be the original strategy's preselection
  state. Alice and Bob use the identity separately.

Thus the candidate supplies precisely the permitted quantifiers. The
finite-tracial common-amplification proof has the same structure: one
target, an Alice conditional density for alignment, and a separate Bob
information lower bound. The two local completion maps can occupy the
same finite ancillary register sizes by padding; compatible preselection
purifications are not required.

The earlier disjoint-block construction used one preselection state because
it was convenient, not because the preparation theorem required it. The
present generalization must nevertheless be stated as this explicit new
construction, not as an unsupported extension of the old common-label
identity for arbitrary masks.

## 6. Tilted averaging: the distribution-averaged loads survive

Let `p=sum_c mu_D(c)p_c>0` and
`Q_C(c)=mu_D(c)p_c/p`. On successful contexts,

\[
 \begin{split}
 \mathbb E_Q\log(A_c/p_c)
  &=\log(1/p)-D(Q_C\Vert\mu_D)+\mathbb E_Q\log A_c\\
  &\le\log(1/p)+\log\mathbb E_{\mu_D}A_c.
 \end{split}
 \tag{S11}
\]

For completeness, put `Z=sum_c mu_D(c)A_c` and
`R(c)=mu_D(c)A_c/Z`. Then the difference between the second line and the
first line is exactly `D(Q_C||R)>=0`. This proves R4 with its actual
posterior tilt. It never asserts that the posterior and prior averages
of `A_c` are equal.

The bound is sharp: choosing `p_c=A_c/M` for a constant `M>=max_c A_c`
makes `Q_C=R` and the two sides equal `log M`. Product partitions give
`E_muD A_c=product_j a_j` and similarly for `B_c`, so the two parent
budgets are exactly

\[
 L+\sum_{j\in D}\log a_j,
 \qquad L+\sum_{j\in D}\log b_j.
\]

The separate unconditional fresh-question marginal drift remains at most
`L`. No history-conditioned drift is substituted. Therefore the combined
budget is precisely `3L+sum_D log(a_j b_j)`, as in the published charged
`FR(K)` condition.

## 7. Explicit non-block and overlapping fixtures

### Three-edge mask

For `V=[[1,1],[1,0]]` and any `u in [0,1]`, use

| Rectangle | Weight |
|---|---:|
| `{0} x {0,1}` | `u` |
| `{0,1} x {0}` | `1-u` |
| `{0} x {1}` | `1-u` |
| `{1} x {0}` | `u` |

This is an exact overlapping positive decomposition on every cell.
Its loads are `A=2-u`, `B=1+u`; `u=1/2` gives balanced loads `3/2`.
The tested mask is genuinely non-block. The numerical construction uses
four-outcome full POVMs indexed by `(a_D,a_i)` and `(b_D,b_i)` with positive,
noncommuting effects, an entangled complex two-qubit resource, and arbitrary
joint live questions. It checks the complete fine table and all coherent
parent matrix blocks, not a classical special case.

### Fractional all-ones masks

A five-label example uses one full rectangle of weight `gamma` and four
singletons of weight `1-gamma`, with loads `2-gamma`. The target norm and
all measured fine probabilities are unchanged; after tracing label records,
coherences between distinct tested fine cells are multiplied by `gamma`.

A seven-label example uses a full rectangle of weight `gamma`, row stars
of weights `r_0,r_1`, and each singleton in row `a` of weight
`1-gamma-r_a`. This also sums to the all-ones matrix. Choose unequal splits,
for example `gamma=1/5,r_0=1/10,r_1=3/10`. If one mistakenly puts
`sqrt(w_l)` on **both** local sides of a common physical preselection,
the squared-weight sum on row zero is `27/50` and on row one is `19/50`.
It changes the normalized original fine table in general. This is an
explicit failed alternative, not a flaw in the two-parent candidate.

Question-varying weights are tested by choosing a separate `u_c` or
`gamma_c,r_a,c` for each supported tested question pair, while keeping the
original full measurement family dependent only on its own tested/live
questions. The operators forming each completion remain local at fixed `c`.
The R4 calculation then uses the actual measured `p_c` and the original
`mu_D`, including the induced posterior tilt.

## 8. Corners, checks and remaining status

Zero-probability contexts and zero-mass label branches are omitted only from
normalizations; their weights in all averages are zero. Local comparison
maps still have fixed complete extensions. A zero winning mask has no
successful context. The empty tested set has one trivial full rectangle,
weight one, and load one. These conventions preserve the exact quantifiers.

The script `../constructor/one_sided_rectangle_checks.py` constructs both
orientations from arbitrary noncommuting four-outcome full POVMs, checks
the completed isometries, common-target marginal identities, S–T positivity,
full-minus-retained entropy budgets, private-label cancellation, R4 with
question-varying weights, genuine coherence changes and the squared-weight
failed alternative. Its retained JSON reports numerical tolerances and
which identities were checked. These tests supplement the proofs above.

The retained run passes 224 contexts, including zero-weight endpoints and
all-zero/trivial masks, and 192 tilted-average checks. It explicitly verifies
the failure blocks' conditional-law attachment too. Maximum measured-table
error is below `4.2e-17`; common-target marginal error is below `5.1e-16`.
The most negative numerical `S-T` eigenvalue is above `-4.7e-16`, consistent
with roundoff in the proved positive congruence. Completed versus
success-normalized deficits agree within `1.9e-15`. These numerical scales
describe diagnostics, not a numerical proof of positivity.

The mathematical conclusion from this report is the general weighted
one-sided-parent construction and exact charged budget. Promotion to the
full arbitrary-commuting `FR(65536)` additionally uses the independently
checked finite-tracial preparation/sampler theorem and scalar-before-Lin
passage. General quadratic repetition still needs removal/control of the
positive presentation charge. No efficient matrix implementation or
historical priority is claimed here.

## 9. Further simplification: normalize the successful parent by its actual mass

The one-sided completions above are sufficient. The exact conditional-
comparison definition permits an even simpler and sometimes stronger parent.
Let `S_A,c` be the **uncompleted** direct sum of the raw successful matrices
in (S4), and put

\[
 G_A(c)=\operatorname{Tr}S_{A,c}
 =\sum_lw_l\,\mathbb E_{\mu_{J,X}}
       \Pr\{a_D\in R_l\mid c_A,x\}.
\]

The raw positive seed already has the original conditional-question form,
`S_A,c=C_muJ(tau_A,c,raw)`. The comparison map is trace preserving, so the
seed has the same mass `G_A(c)`. Since `p_c rho_A,c<=S_A,c` and `p_c>0`,
`G_A(c)>=p_c>0`. Therefore

\[
 \widehat\sigma_{A,c}=S_{A,c}/G_A(c)
  =C_{\mu_J}(\tau_{A,c,raw}/G_A(c))
\]

is a valid normalized conditional comparison, giving

\[
 p_c\rho_{A,c}\le G_A(c)\widehat\sigma_{A,c},
 \quad \sum_lq_c(l)b_A(\rho_{A,c,l}\Vert\widehat\sigma_{A,c})
              \le\log(G_A(c)/p_c).
 \tag{S12}
\]

The local question marginal of this seed need not equal the original
`mu_J,X` or the target marginal. It is exactly the arbitrary local seed
marginal permitted in Definition 2.6 and in the audited common-amplification
proof. No physical preparation by a success-conditioned local filter is being
asserted. Bob uses his independently normalized successful parent with
`G_B(c)`.

In fact the conditional deficit is **identical** for this parent and the
completed parent: on the target's successful sector their reference densities
differ by the scalar `A_c/G_A(c)`, which adds `log(A_c/G_A(c))` to both the
full and retained divergences and cancels on subtraction. The retained
success/failure flag is essential to this statement. Thus the sharper bound
can also be read as keeping a contribution that the crude nonnegativity
bound on the retained divergence discarded.

R4 applies verbatim with `G_A(c)` in place of `A_c`, even if zero masses occur
on unsuccessful contexts: `p_c<=G_A(c)` makes every target-supported context
positive. Hence

\[
 \mathbb E_Q\log(G_A(c)/p_c)
 \le L+\log\mathbb E_{\mu_D}G_A(c)
 \le L+\log\mathbb E_{\mu_D}A_c,
 \tag{S13}
\]

and likewise for Bob. This retains actual one-sided masses before replacing
them by distribution-averaged presentation loads. It reproduces the desired
charged `FR(K)` budget and can improve its strategy-dependent intermediate
bound. It does not universally bound those actual masses independently of
answer size, and does not evade the earlier positive-filter obstructions.

The diagnostic script checks both normalized-success variants, their sharper
bounds, equality of completed/uncompleted conditional deficits, and the
corresponding tilted R4 identities. The completion version remains in the
record as an independently explicit sufficient construction.
