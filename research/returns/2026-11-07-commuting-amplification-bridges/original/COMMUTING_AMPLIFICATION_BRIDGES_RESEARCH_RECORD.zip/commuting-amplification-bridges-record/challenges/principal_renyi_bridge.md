# Principal continuation: arbitrary interactive noisy-channel soundness

7 November 2026. This continues the frozen principal report. It was developed independently of the constructor's communication theorem (their initial report had not been read); machinery's initial report was read before writing this continuation. No full commuting quadratic theorem is used.

## P3. An interactive channel-capacity penalty for any nonnegative game

All logarithms in this note are natural; convert source quantities in bits by multiplying by ln 2. Let H be any finite two-player game, or any finite nonnegative acceptance event on a product question table. Let q0=omega_co(H). Two ordinary tensor-product quantum players initially share an arbitrary finite-dimensional state independent of the referee questions. They receive the questions with their original joint law. They may apply arbitrary local quantum instruments and communicate interactively through a predetermined finite list of finite-dimensional CPTP channels N1,...,Nm, in either direction. Every cross-player message, including classical control, must be in that list. The channel environments are independent and inaccessible; memory and adaptation within each laboratory are unrestricted. Local operations may depend on all received local data and outcomes. No efficiency assumption is imposed.

For a>1 define

  D_a(rho||sigma) = (a-1)^(-1) log Tr[(sigma^((1-a)/(2a)) rho sigma^((1-a)/(2a)))^a],
  I_a(N) = sup_{pure psi_RQ} inf_{state zeta_B}
                D_a((id_R tensor N)(psi) || psi_R tensor zeta_B).

The reference has dimension dim Q. Inverses use supports; the infimum may be approximated with full-rank states. Then every such interactive strategy satisfies

  P_H <= min{1, inf_{a>1} exp[(a-1)/a (log q0 + sum_j I_a(Nj))]}.       (P3)

If q0=0 then P_H=0: use the finite positive costs and the binary divergence argument, or take q0 down to zero. All finite channels have a finite full-rank replacer divergence. If q0=1 the bound is one. The theorem controls ordinary finite-dimensional communicating strategies using the larger commuting value as its zero-communication comparator. It makes no undeclared definition of a communicating arbitrary-co strategy.

### Exact imported operations and applicability

1. Gupta–Wilde, arXiv:1310.7028v3, Section 5, the minimax identity culminating in (5.19)/(2.18):

     I_a(N)=inf_zeta D_a(N || R_zeta),
     D_a(N||R_zeta)=sup_{psi_RQ}D_a(N(psi)||psi_R tensor zeta).

   This uses the SAME orientation as the definition above: the fixed marginal is the untouched reference. The opposite marginal convention found in some channel-simulation papers is not substituted. Complete bounded norms/Sion minimax are established machinery, not a new import from the repetition theorem. The channels here meet the source's finite-dimensional CPTP hypotheses. Full-rank perturbation of a minimizing zeta incurs arbitrarily small slack.

2. Wilde–Berta–Hirche–Kaur, arXiv:1808.01498v2, Proposition 41, equation (283): for every finite channel N, replacer R_zeta, a>1, and arbitrary pairs of states rho_RQ,sigma_RQ,

     D_a(N(rho)||sigma_R tensor zeta)
       <= D_a(rho||sigma)+D_a(N||R_zeta).                       (P4)

   This is sandwiched-Renyi amortization collapse against a replacer. It is NOT asserted for two arbitrary channels. All laboratory memories, question registers, output records and the opposite player's systems are part of the reference R; its size is unrestricted. Local steps are the same CPTP maps in the actual and comparison executions. Thus the two different input states in (P4), including after feedback, meet its hypotheses.

### Complete proof from the imported inequalities

Fix a>1 and choose for each j a state zeta_j with D_a(Nj||R_zeta_j)<=I_a(Nj)+u, u>0. Compare the actual protocol to the same local protocol with every cross-player Nj replaced by the local discard-and-prepare map R_zeta_j. Initially the global states, including the referee's joint questions and the shared entanglement, coincide, so their D_a is zero. Between message slots, data processing cannot increase this divergence. At slot j, (P4) increases it by at most I_a(Nj)+u. Direction of transmission is irrelevant to the global inequality. Consequently the final states have divergence at most sum I_a(Nj)+mu.

The all-replacer protocol has no communication. Alice's receiving replacers prepare fixed local states and discard the sender's messages. Arbitrary local branching and shared entanglement still give a legal zero-communication tensor strategy, and hence its accepted-event probability q is at most q0. The same final binary accept/reject measurement is applied to both executions. Binary data processing gives

  sum I_a+mu >= D_a(Ber(p)||Ber(q))
              >= a/(a-1) log p - log q.

Therefore log p <= (a-1)/a(log q0+sum I_a+mu). Let u decrease to zero and optimize a. This is (P3). No conditioning on rare successful transcripts, classical copying of quantum histories, or finite-matrix approximation of arbitrary commuting correlations occurs. QED.

## P4. Consequence for original-game repetition, capacity and noise

Suppose an independently established zero-communication bound gives omega_co(G^n)<=exp(-g n). Then

  p_n <= inf_{a>1} exp[-(a-1)/a (g n - sum_j I_a(Nj))].        (P5)

In particular this applies with g=2^-75 epsilon^3/(epsilon+log|A||B|), relying only on the given original N443 capital. Threshold games use their original exponent instead; they are finite nonnegative events, so P3 applies verbatim. No FR(K) claim enters.

Let channels come from a fixed finite family M1,...,Mk, with m_l(n)/n -> beta_l finite, fixed predetermined slots in arbitrary order/direction, and no other cross-cut communication. Finite-dimensional continuity I_a(Ml)->I(Ml) as a decreases to one gives exponential soundness whenever

  sum_l beta_l C_E(Ml) < g,                                  (P6)

where C_E=I is the entanglement-assisted classical capacity in nats. Choose a>1 close enough to one to retain a positive margin, and (P5) then gives a uniform positive exponent for all large n. In the bit convention, multiply the capacity sum by ln 2. This improves the coarse CP-domination/worst-case-message-dimension sufficient criterion when noise lowers C_E below I_infinity. It includes interactive feedback because P4 amortizes. It does not allow channel memory to be silently treated as independent noise.

For a noiseless c-bit classical channel, I_a=c ln2; for q noiseless qubits, I_a=2q ln2, for every a>1. Taking a to infinity recovers transcript-guessing and teleportation penalties exactly. This includes a reproducible comparison against the independent constructor's later communication theorem once reports are exchanged.

### Rate obstruction and exact comparator

For the input-guessing game x uniform in [d], y constant, Alice output irrelevant, Bob must output x, q0=d^-n. The allowed communicating strategy is entanglement-assisted transmission of a uniform d^n-ary message. At channel use ratio beta, beta C_E > log d permits success tending to one by ordinary channel coding. Thus P6 has the optimal *rate boundary* for this fixture when g=log d; there is no universal improvement using only the zero-communication exponent and channel capacities. This is an established channel-coding application, not a new capacity theorem or a statement that P6 is necessary for every game.

The known strong converse for entanglement-assisted coding (Gupta–Wilde 2015) is the strongest direct comparator. P3 reuses its meta-converse mechanism with a nonlocal-game zero-communication comparison. Jain–Kundu's communication-tolerant repetition and resource-theoretic signalling robustness are additional predecessors. Historical novelty of this precise synthesis is NOT established.

## P5. Equivalent explicit CP-order interface

For any finite channel N with unnormalized Choi J_N, define

  M(N)=min{Tr S: S>=0, I_Q tensor S >= J_N}.

This equals exp I_infinity(N), a known max-information/simulation quantity. CP order gives N<=M R_{S/M}. Any positive accepted-event functional on a network is monotone in each channel in this order, so p<=product_j M(Nj) q0. This proves the a=infinity form without the finite-a imports, and is reference-uniform. For identity_d, dephasing_d and a replacer, the exact values are d^2,d,1. For N_delta=(1-delta)R_{I/d}+delta id_d, M=1-delta+delta d^2; unitary twirling gives the optimizer, and the largest Choi eigenvalue verifies it.

Do not estimate M only on the emitted-system marginal: d^2 Bell-state phase encodings have identical emitted marginals (apparent M=1) while their joint state with the receiver's preshared reference is perfectly distinguishable (M=d^2). The full CP test is needed.

## Remaining decisive operation

The theorem supplies a rigorous information-flow tolerance for amplification, not an efficient single-device cryptographic verifier. QHE computational indistinguishability does not bound these full-cone divergences. A compiler bridge still needs a uniform certificate-relative replacement inequality for growing games, with polynomial degree/coefficient norm and physical complete-reference security. The retained-common-label conditional-entropy route is a separate prospect for strengthening the no-communication exponent itself.
