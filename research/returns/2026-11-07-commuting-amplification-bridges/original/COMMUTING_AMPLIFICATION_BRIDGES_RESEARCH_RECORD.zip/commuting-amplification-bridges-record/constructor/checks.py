"""Finite diagnostics for the constructor proof; not theorem certificates."""

from collections import defaultdict
from fractions import Fraction as F
from itertools import product
from math import log, ceil
from pathlib import Path
import hashlib
import json


def check_transcript_guessing():
    # Two interactive classical messages and local private randomness.
    # A sends m1=x xor s; B sends m2=y xor m1 xor t.
    # Final outputs may depend on all locally available information.
    checked = 0
    for x, y in product(range(2), repeat=2):
        original, simulated = defaultdict(F), defaultdict(F)
        for s, t in product(range(2), repeat=2):
            m1, m2 = x ^ s, y ^ x ^ s ^ t
            a, b = s ^ m2, t ^ m1
            original[a, b] += F(1, 4)
        for z1, z2, s, t in product(range(2), repeat=4):
            own_a_matches = z1 == x ^ s
            own_b_matches = z2 == y ^ z1 ^ t
            if own_a_matches and own_b_matches:
                a, b = s ^ z2, t ^ z1
                simulated[a, b] += F(1, 16)
        for ab in set(original) | set(simulated):
            assert simulated[ab] == original[ab] / 4
            checked += 1
        assert sum(simulated.values()) == F(1, 4)
    return {"fine_output_identities": checked, "consistent_branch_mass": "1/4"}


def check_teleportation():
    # Reference R has dimension 3; M is one qubit.
    # Pair and Bell bra each contribute 1/sqrt(2), giving exact coefficient 1/2.
    psi = {(r, m): complex(2*r + m + 1, r - 2*m)
           for r, m in product(range(3), range(2))}
    out = defaultdict(complex)
    for r, m, a, b in product(range(3), range(2), range(2), range(2)):
        if a == b and m == a:
            out[r, b] += psi[r, m] / 2
    assert all(out[k] == z / 2 for k, z in psi.items())
    norm_input = sum(abs(z)**2 for z in psi.values())
    norm_output = sum(abs(z)**2 for z in out.values())
    assert abs(norm_output / norm_input - 0.25) < 1e-15
    return {"reference_dimension": 3, "branch_probability": 0.25,
            "amplitude_identity": "out=psi/2"}


def tensor_rows(rows, n):
    # Each row is the bit vector of its support.
    out = []
    for labels in product(range(len(rows)), repeat=n):
        row = tuple(all(rows[labels[j]][cols[j]] for j in range(n))
                    for cols in product(range(len(rows[0])), repeat=n))
        out.append(row)
    return out


def check_tensor_row_count():
    checked = 0
    for bits in product(range(2), repeat=4):
        if not any(bits):
            continue
        rows = [bits[:2], bits[2:]]
        r = len({row for row in rows if any(row)})
        for n in range(1, 5):
            actual = {row for row in tensor_rows(rows, n) if any(row)}
            assert len(actual) == r**n
            checked += 1
    return {"nonzero_boolean_masks": 15, "powers": [1, 2, 3, 4],
            "exact_count_checks": checked}


def check_corruption_rounding():
    checked = 0
    for n in range(1, 17):
        for denominator in range(1, 8):
            for numerator in range(1, denominator + 1):
                eps = F(numerator, denominator)
                for r in range(n + 1):
                    for t in range(n + 1):
                        if r + t >= n * eps:
                            continue
                        delta = eps - F(r+t, n)
                        assert ceil((1-eps+delta)*n) == n-r-t
                        # Any at-most-t record changes can lower failure count by at most t.
                        for original_failures in range(n + 1):
                            min_after = max(0, original_failures-t)
                            if min_after <= r:
                                assert original_failures <= r+t
                        checked += 1
    return {"integer_threshold_checks": checked}


def check_rare_leak():
    rows = []
    for n in range(1, 9):
        prob_z = F(1, n)
        count = 2**n
        # L has token 'none' or a copy of X with Z=1.
        joint = {}
        marginal_l = defaultdict(F)
        for x in range(count):
            joint[x, "none"] = F(1, count) * (1-prob_z)
            joint[x, x] = F(1, count) * prob_z
            marginal_l["none"] += joint[x, "none"]
            marginal_l[x] += joint[x, x]
        mi, tv = 0.0, F(0)
        max_ratio = F(0)
        for x in range(count):
            for label, pl in marginal_l.items():
                p = joint.get((x, label), F(0))
                independent = pl / count
                tv += abs(p-independent) / 2
                if p:
                    mi += float(p) * log(float(p/independent))
                    max_ratio = max(max_ratio, p/independent)
        assert abs(mi-log(2)) < 1e-12
        assert tv == prob_z * (1-F(1,count))
        assert max_ratio == count
        success = prob_z+(1-prob_z)/count
        assert success >= F(1,n)
        assert prob_z*n == 1
        rows.append({"n":n,"all_win_probability":str(success),
                     "mutual_information_nats":mi,
                     "total_variation":str(tv),
                     "max_density_ratio":int(max_ratio),
                     "expected_communication_bits":1})
    return rows


def main():
    results = {
        "scope": "Finite arithmetic diagnostics supplement complete proofs in initial/constructor.md",
        "transcript_guessing": check_transcript_guessing(),
        "teleportation": check_teleportation(),
        "tensor_row_count": check_tensor_row_count(),
        "corruption_rounding": check_corruption_rounding(),
        "rare_leak": check_rare_leak(),
    }
    initial = Path(__file__).resolve().parents[1] / "initial" / "constructor.md"
    results["frozen_initial_sha256"] = hashlib.sha256(initial.read_bytes()).hexdigest()
    out = Path(__file__).with_name("check_results.json")
    out.write_text(json.dumps(results, indent=2)+"\n")
    print(json.dumps({k:v for k,v in results.items() if k != "rare_leak"}, indent=2))
    print("rare_leak_checks", len(results["rare_leak"]))


if __name__ == "__main__":
    main()
