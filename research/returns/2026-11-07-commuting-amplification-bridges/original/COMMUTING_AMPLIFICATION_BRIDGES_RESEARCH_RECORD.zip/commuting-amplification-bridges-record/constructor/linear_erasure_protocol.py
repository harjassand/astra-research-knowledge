"""Executable logical simulation of the explicit dense-coding protocol.

Each surviving ideal dense-coded qubit delivers its two Pauli-label bits.
This program simulates that induced classical erasure channel, not a physical
quantum device, and uses binary elimination to sample the receiver's affine
solution. It never constructs an exponential-size Hilbert-space matrix.
"""

import argparse
from fractions import Fraction
import json
import random


def parity(value):
    return value.bit_count() & 1


def echelon(equations):
    """Map a pivot to its binary row and RHS; raise on inconsistent data."""
    basis={}
    for mask, rhs in equations:
        while mask:
            pivot=mask.bit_length()-1
            if pivot not in basis:
                basis[pivot]=(mask,rhs)
                break
            old_mask,old_rhs=basis[pivot]
            mask^=old_mask
            rhs^=old_rhs
        else:
            if rhs:
                raise ValueError("inconsistent erasure transcript")
    return basis


def affine_solution(n,basis,free_assignment):
    """Bijection from n-rank free bits to all solutions of a consistent system."""
    free_positions=[i for i in range(n) if i not in basis]
    if not 0 <= free_assignment < 2**len(free_positions):
        raise ValueError("free assignment outside its specified range")
    answer=0
    for j,position in enumerate(free_positions):
        answer|=((free_assignment>>j)&1)<<position
    for pivot in sorted(basis):
        mask,rhs=basis[pivot]
        if parity(mask&answer)^rhs:
            answer|=1<<pivot
    return answer


def run_one(n,m,survival,rng):
    x=rng.getrandbits(n)
    rows=[rng.getrandbits(n) for _ in range(2*m)]
    encoded=[parity(row&x) for row in rows]
    equations=[]
    survivors=0
    for slot in range(m):
        if rng.random()<survival:
            survivors+=1
            equations.extend((rows[2*slot+j],encoded[2*slot+j]) for j in range(2))
    basis=echelon(equations)
    free_count=n-len(basis)
    decoded=affine_solution(n,basis,rng.getrandbits(free_count))
    assert all(parity(mask&decoded)==rhs for mask,rhs in equations)
    return {"success":decoded==x,"rank":len(basis),"surviving_slots":survivors,
            "conditional_success":Fraction(1,2**free_count)}


def exhaustive_decoder_check():
    cases=0
    for n in range(1,4):
        # Every ordered two-row binary matrix and every transmitted message.
        for first in range(2**n):
            for second in range(2**n):
                for x in range(2**n):
                    equations=[(first,parity(first&x)),(second,parity(second&x))]
                    basis=echelon(equations)
                    answers=[affine_solution(n,basis,z)
                             for z in range(2**(n-len(basis)))]
                    assert len(set(answers))==len(answers)
                    actual={v for v in range(2**n)
                            if all(parity(mask&v)==rhs for mask,rhs in equations)}
                    assert set(answers)==actual
                    assert x in actual
                    cases+=1
    return cases


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--n",type=int,default=16)
    parser.add_argument("--ratio",type=int,default=4)
    parser.add_argument("--survival",type=float,default=.1)
    parser.add_argument("--trials",type=int,default=2000)
    parser.add_argument("--seed",type=int,default=20261107)
    args=parser.parse_args()
    if args.n<1 or args.ratio<1 or args.trials<1 or not 0<=args.survival<=1:
        parser.error("invalid positive length, ratio, trials or probability")
    decoder_cases=exhaustive_decoder_check()
    rng=random.Random(args.seed)
    values=[run_one(args.n,args.ratio*args.n,args.survival,rng)
            for _ in range(args.trials)]
    result={"model":"logical classical simulation induced by ideal dense coding and erasures",
            "physical_quantum_validation":False,
            "n":args.n,"slots":args.ratio*args.n,"survival":args.survival,
            "trials":args.trials,"seed":args.seed,
            "observed_success_fraction":sum(v['success'] for v in values)/args.trials,
            "mean_exact_conditional_success":float(sum(v['conditional_success'] for v in values)/args.trials),
            "mean_rank":sum(v['rank'] for v in values)/args.trials,
            "exhaustive_decoder_cases":decoder_cases,
            "resources":{"EPR_pairs":args.ratio*args.n,
                         "transmitted_qubits":args.ratio*args.n,
                         "shared_matrix_bits":2*args.ratio*args.n**2}}
    print(json.dumps(result,indent=2))


if __name__=="__main__":
    main()
