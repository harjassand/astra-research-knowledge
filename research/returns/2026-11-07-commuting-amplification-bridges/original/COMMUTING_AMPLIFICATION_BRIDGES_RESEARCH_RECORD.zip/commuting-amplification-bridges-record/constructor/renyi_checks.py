"""Checks supplementing, not replacing, the constructor Renyi proofs.

Uses numpy for finite operator diagnostics and exact Fractions for all coding
and algebraic positivity certificates. The frozen initial report is read-only.
"""

from fractions import Fraction as F
from math import comb, exp, log
from pathlib import Path
import hashlib
import json
import numpy as np


def ptr_a(rho, r, a):
    return np.trace(rho.reshape(r, a, r, a), axis1=1, axis2=3)


def ptr_r(rho, r, a):
    return np.trace(rho.reshape(r, a, r, a), axis1=0, axis2=2)


def erasure(rho, r, d, survival):
    marginal = ptr_a(rho, r, d)
    out = np.zeros((r*(d+1), r*(d+1)), dtype=complex)
    for i in range(r):
        for j in range(r):
            out[i*(d+1):i*(d+1)+d, j*(d+1):j*(d+1)+d] = (
                survival*rho[i*d:(i+1)*d, j*d:(j+1)*d]
            )
            out[i*(d+1)+d, j*(d+1)+d] = (1-survival)*marginal[i,j]
    return out


def renyi(rho, sigma, alpha):
    evals, vecs = np.linalg.eigh((sigma+sigma.conj().T)/2)
    keep = evals > 1e-13
    if not np.all(keep):
        null = vecs[:, ~keep]
        if np.linalg.norm(null.conj().T@rho@null) > 1e-10:
            return float("inf")
    powers = np.zeros_like(evals)
    powers[keep] = evals[keep]**((1-alpha)/(2*alpha))
    sandwich = (vecs*powers)@vecs.conj().T
    transformed = sandwich@rho@sandwich
    vals = np.linalg.eigvalsh((transformed+transformed.conj().T)/2)
    assert np.min(vals) > -1e-9
    return log(float(np.sum(np.maximum(vals,0)**alpha)))/(alpha-1)


def random_state(rng, dimension):
    m = rng.normal(size=(dimension,dimension))+1j*rng.normal(size=(dimension,dimension))
    rho = m@m.conj().T+0.2*np.eye(dimension)
    return rho/np.trace(rho)


def channel_i(alpha, d, s):
    t = (alpha-1)/alpha
    return log(1-s+s*d**(2*t))/t


def replacer_tau(alpha, d, s):
    t = (alpha-1)/alpha
    r = s*d**(2*t)/(1-s+s*d**(2*t))
    return np.diag([r/d]*d+[1-r])


def operator_checks():
    rng = np.random.default_rng(20261107)
    d, r, s = 2, 3, 0.1
    max_violation = -float("inf")
    max_stronger_violation = -float("inf")
    minimum_noncommutator = float("inf")
    checks = 0
    for alpha in [1.25, 4/3, 1.5, 2., 4.]:
        tau = replacer_tau(alpha,d,s)
        cost = channel_i(alpha,d,s)
        for _ in range(80):
            rho, sigma = random_state(rng,r*d), random_state(rng,r*d)
            minimum_noncommutator = min(minimum_noncommutator,
                float(np.linalg.norm(rho@sigma-sigma@rho)))
            output = erasure(rho,r,d,s)
            sigmar, rhor = ptr_a(sigma,r,d), ptr_a(rho,r,d)
            dout = renyi(output,np.kron(sigmar,tau),alpha)
            din = renyi(rho,sigma,alpha)
            dmarg = renyi(rhor,sigmar,alpha)
            max_violation = max(max_violation,dout-din-cost)
            max_stronger_violation = max(max_stronger_violation,dout-dmarg-cost)
            assert dout <= din+cost+2e-10
            assert dout <= dmarg+cost+2e-10
            checks += 1
    pure_checks = 0
    max_pure_difference = -float("inf")
    maximum_entangled_error = 0
    for alpha in [1.25,4/3,1.5,2.,4.]:
        tau = replacer_tau(alpha,d,s)
        cost = channel_i(alpha,d,s)
        v = np.array([1,0,0,1],dtype=complex)/np.sqrt(2)
        pure = np.outer(v,v.conj())
        value = renyi(erasure(pure,d,d,s),np.kron(np.eye(d)/d,tau),alpha)
        maximum_entangled_error = max(maximum_entangled_error,abs(value-cost))
        assert abs(value-cost) < 2e-11
        for _ in range(80):
            v = rng.normal(size=d*d)+1j*rng.normal(size=d*d)
            v = v/np.linalg.norm(v)
            pure = np.outer(v,v.conj())
            marginal = ptr_a(pure,d,d)
            value = renyi(erasure(pure,d,d,s),np.kron(marginal,tau),alpha)
            max_pure_difference = max(max_pure_difference,value-cost)
            assert value <= cost+2e-9
            pure_checks += 1
    return {"different_input_amortization_checks":checks,
            "maximum_violation":max_violation,
            "maximum_stronger_reference_marginal_violation":max_stronger_violation,
            "minimum_input_noncommutator_norm":minimum_noncommutator,
            "pure_input_cost_checks":pure_checks,
            "maximum_pure_input_violation":max_pure_difference,
            "maximally_entangled_cost_error":maximum_entangled_error}


def cp_certificate():
    d, s = 2, 0.1
    gamma = np.zeros(d*(d+1)); gamma[0]=1; gamma[4]=1
    G = np.outer(gamma,gamma)
    flag = np.diag([0.,0.,1.])
    J = s*G+(1-s)*np.kron(np.eye(d),flag)
    S = np.diag([s*d]*d+[1-s])
    Y = G+np.kron(np.eye(d)/d,flag)
    slack = np.kron(np.eye(d),S)-J
    expected = 1-s+s*d*d
    assert np.min(np.linalg.eigvalsh(slack)) > -1e-14
    assert np.min(np.linalg.eigvalsh(Y)) > -1e-14
    assert np.linalg.norm(ptr_r(Y,d,d+1)-np.eye(d+1)) < 1e-14
    assert abs(np.trace(S)-expected) < 1e-14
    assert abs(np.trace(J@Y)-expected) < 1e-14
    return {"primal_trace":float(np.trace(S)),"dual_value":float(np.trace(J@Y)),
            "minimum_primal_slack_eigenvalue":float(np.min(np.linalg.eigvalsh(slack)))}


def smoothing_interface_counterexample():
    rho=np.diag([1.,0.])
    sigma=np.ones((2,2))/2
    difference=np.linalg.eigvalsh(rho-2*sigma)
    defect=float(np.maximum(difference,0).sum())
    distance=float(np.abs(np.linalg.eigvalsh(rho-sigma)).sum()/2)
    assert abs(defect-(np.sqrt(5)-1)/2)<1e-14
    assert abs(distance-1/np.sqrt(2))<1e-14
    assert distance>defect
    return {"hockey_stick_defect":defect,"minimum_normalized_dominated_state_distance":distance,
            "same_error_smoothing_implication":False}


def exact_positive_exponents():
    assert F(1317,1000)**4 > 3
    assert F(707,500)**2 < 2
    assert F(33,25)**5 > 4
    sup_s = (3*F(1317,1000)+1)/(4*F(707,500))
    sup_t = (9+F(33,25))/10
    source_product = sup_s**4*sup_t**15
    plain_product = sup_t**20
    assert source_product < F(19,20)
    assert plain_product < F(19,10)
    return {"BSC_source_product_upper":str(source_product),
            "BSC_source_product_decimal":float(source_product),
            "plain_channel_product_upper":str(plain_product),
            "plain_channel_product_decimal":float(plain_product),
            "certified_exponent_lower_for_both":"1/100"}


def count_rank(rows,cols,rank):
    if rank == 0:
        return 1
    num, den = 1, 1
    for i in range(rank):
        num *= (2**rows-2**i)*(2**cols-2**i)
        den *= 2**rank-2**i
    assert num%den == 0
    return num//den


def mean_linear_decode(rows,cols):
    counts = [count_rank(rows,cols,k) for k in range(min(rows,cols)+1)]
    assert sum(counts) == 2**(rows*cols)
    value = sum(F(counts[k]*2**k,2**(rows*cols+cols))
                for k in range(len(counts)))
    return value


def exact_coding_checks():
    results = []
    survival = F(1,10)
    for n in [2,4,6,8,12,16,24,32]:
        m=4*n
        success = sum(F(comb(m,k))*survival**k*(1-survival)**(m-k)
                      *mean_linear_decode(2*k,n) for k in range(m+1))
        # exp(-nE*) is rational for even n.
        upper = F(7,9)**(n//2)*F(36,35)**(4*n)
        lower = F(9,32*(4*n+1))*upper
        k=n//2
        binomial = F(comb(m,k))*survival**k*(1-survival)**(m-k)
        direct_lower = F(9,32)*binomial
        assert lower <= direct_lower <= success <= upper
        results.append({"n":n,"linear_protocol_mean_success":float(success),
                        "renyi_upper":float(upper),"type_lower":float(lower),
                        "direct_full_rank_lower":float(direct_lower),
                        "exact_success_numerator_bits":success.numerator.bit_length(),
                        "exact_success_denominator_bits":success.denominator.bit_length(),
                        "all_comparisons_exact":True})
    return results


def bsc_source_check():
    results = []
    theta=0.25
    for n in range(1,5):
        N=2**n
        for alpha in [1.25,4/3,1.5,2.,4.]:
            power = 0.
            for x in range(N):
                for l in range(N):
                    distance=(x^l).bit_count()
                    p=(theta**distance*(1-theta)**(n-distance))/N
                    reference=1/N**2
                    power+=p**alpha*reference**(1-alpha)
            direct=log(power)/(alpha-1)
            closed=n*(log(2)+log(theta**alpha+(1-theta)**alpha)/(alpha-1))
            assert abs(direct-closed)<2e-12
            results.append({"n":n,"alpha":alpha,"direct":direct,"closed":closed})
    return {"checks":len(results),"maximum_identity_error":max(abs(x['direct']-x['closed']) for x in results)}


def rare_source_check():
    results=[]
    for n in [1,2,4,8]:
        N=2**n; tau=1/n
        for alpha in [1.25,1.5,2.,4.]:
            t=(alpha-1)/alpha
            Z=1-tau+tau*N**t
            sigma_none=(1-tau)/Z
            sigma_copy=tau*N**(-1/alpha)/Z
            power=0.
            if tau<1:
                p=(1-tau)/N; ref=sigma_none/N
                power+=N*p**alpha*ref**(1-alpha)
            p=tau/N; ref=sigma_copy/N
            power+=N*p**alpha*ref**(1-alpha)
            direct=log(power)/(alpha-1)
            closed=log(Z)/t
            assert abs(direct-closed)<2e-12
            bound=exp(t*(-log(N)+closed))
            expected=tau+(1-tau)*N**(-t)
            assert abs(bound-expected)<2e-12
            results.append(abs(direct-closed))
    return {"checks":len(results),"maximum_identity_error":max(results)}


def main():
    output = {"status":"PASS","scope":"Finite diagnostics and exact arithmetic only",
              "operator":operator_checks(),"CP_certificate":cp_certificate(),
              "smoothing_interface_counterexample":smoothing_interface_counterexample(),
              "rational_positive_exponents":exact_positive_exponents(),
              "coding":exact_coding_checks(),"BSC_source":bsc_source_check(),
              "rare_source":rare_source_check()}
    initial=Path(__file__).resolve().parents[1]/"initial"/"constructor.md"
    output["initial_sha256"]=hashlib.sha256(initial.read_bytes()).hexdigest()
    out=Path(__file__).with_name("renyi_check_results.json")
    out.write_text(json.dumps(output,indent=2)+"\n")
    print(json.dumps({k:v for k,v in output.items() if k != 'coding'},indent=2))
    print("exact_coding_lengths",[r['n'] for r in output['coding']])


if __name__=="__main__":
    main()
