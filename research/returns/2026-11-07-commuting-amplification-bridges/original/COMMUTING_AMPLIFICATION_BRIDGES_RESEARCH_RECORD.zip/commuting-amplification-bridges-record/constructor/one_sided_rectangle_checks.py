"""Finite tensor diagnostics of the one-sided rectangle-parent construction.

Random full POVMs contain noncommuting effects. Both parent margins are
compared with one explicitly constructed common pure target. Matrix tests do
not certify the independent finite-von-Neumann recovery/sampler import.
"""

from pathlib import Path
from itertools import product
from fractions import Fraction as F
import hashlib
import json
import math
import numpy as np


def hermitian_power(a,power):
    vals,vecs=np.linalg.eigh((a+a.conj().T)/2)
    assert np.min(vals)>-1e-10
    vals=np.maximum(vals,0)
    powers=np.where(vals>1e-13,vals**power if power>0 else np.maximum(vals,1e-300)**power,0)
    return (vecs*powers)@vecs.conj().T


def povm(rng,count=4,dimension=2):
    effects=[]
    for _ in range(count):
        m=rng.normal(size=(dimension,dimension))+1j*rng.normal(size=(dimension,dimension))
        effects.append(m@m.conj().T+.2*np.eye(dimension))
    inverse=hermitian_power(sum(effects),-.5)
    return [inverse@e@inverse for e in effects]


def relative(a,b):
    a=(a+a.conj().T)/2; b=(b+b.conj().T)/2
    if np.trace(a).real<1e-13:
        return 0.
    av=np.linalg.eigvalsh(a)
    assert np.min(av)>-2e-10
    av=av[av>1e-13]
    bv,bu=np.linalg.eigh(b)
    weights=np.diag(bu.conj().T@a@bu).real
    assert abs(sum(weights[bv<1e-11]))<3e-9
    keep=bv>1e-11
    return float(np.sum(av*np.log(av))-np.sum(weights[keep]*np.log(bv[keep])))


def rectangles(kind,c):
    ca,cb=c; index=2*ca+cb
    if kind in ('three_edge','three_edge_boundary'):
        u=([.1,.35,.6,.9] if kind=='three_edge' else [0.,1.,0.,1.])[index]
        return [(u,{0},{0,1}),(1-u,{0,1},{0}),
                (1-u,{0},{1}),(u,{1},{0})],np.array([[1,1],[1,0]])
    if kind in ('all_ones_five','all_ones_zero_weight'):
        gamma=([.1,.3,.6,.9] if kind=='all_ones_five' else [0.,1.,0.,1.])[index]
        return [(gamma,{0,1},{0,1})]+[(1-gamma,{a},{b}) for a,b in product(range(2),repeat=2)],np.ones((2,2))
    if kind=='all_ones_seven':
        gamma=[.1,.2,.3,.4][index]
        r0=.1*(1-gamma);r1=.4*(1-gamma)
        result=[(gamma,{0,1},{0,1}),(r0,{0},{0,1}),(r1,{1},{0,1})]
        result += [(1-gamma-[r0,r1][a],{a},{b}) for a,b in product(range(2),repeat=2)]
        return result,np.ones((2,2))
    if kind=='trivial':
        return [(1.,{0,1},{0,1})],np.ones((2,2))
    if kind=='zero':
        return [],np.zeros((2,2))
    raise ValueError(kind)


def parent_entropy(S,T,load,p,question_count=2,answer_count=4,dim=2):
    # S,T indexed label, opposite question; each matrix has coherent local
    # question/fine-answer/physical rows. Failure target mass is zero.
    full=sum(relative(T[l][y]/p,S[l][y]/load) for l in range(len(S)) for y in range(question_count))
    retained=0.;weighted_block_deficit=0.
    block_width=answer_count*dim
    for l in range(len(S)):
        mass=sum(np.trace(T[l][y]).real for y in range(question_count))
        q=mass/p
        if mass<1e-13:
            continue
        full_l=sum(relative(T[l][y]/mass,S[l][y]/load) for y in range(question_count))
        retained_l=0.
        for x in range(question_count):
            ix=slice(x*block_width,(x+1)*block_width)
            tr=sum(T[l][y][ix,ix] for y in range(question_count))
            sr=sum(S[l][y][ix,ix] for y in range(question_count))
            retained+=relative(tr/p,sr/load)
            retained_l+=relative(tr/mass,sr/load)
        weighted_block_deficit+=q*(full_l-retained_l)
    delta=full-retained
    assert full<=math.log(load/p)+3e-8
    assert delta>=-3e-8
    assert delta<=math.log(load/p)+3e-8
    assert abs(delta-weighted_block_deficit)<3e-8
    return {'full':full,'retained':retained,'deficit':delta,
            'bound':math.log(load/p),
            'private_label_cancellation_error':abs(delta-weighted_block_deficit)}


def run_context(P,Q,Psi,mu,c,kind):
    ca,cb=c
    parts,mask=rectangles(kind,c)
    rowload=np.array([sum(w for w,R,T in parts if a in R) for a in range(2)])
    colload=np.array([sum(w for w,R,T in parts if b in T) for b in range(2)])
    A=max(1.,float(max(rowload)));B=max(1.,float(max(colload)))
    presented=np.array([[sum(w for w,R,T in parts if a in R and b in T)
                         for b in range(2)] for a in range(2)])
    assert np.max(np.abs(presented-mask))<1e-13
    As=[[hermitian_power(P[ca][x][a],.5) for a in range(4)] for x in range(2)]
    Bs=[[hermitian_power(Q[cb][y][b],.5) for b in range(4)] for y in range(2)]
    original=np.empty((2,2,4,4,2,2),dtype=complex)
    probs=np.zeros((2,2,4,4))
    for x,y,a,b in product(range(2),range(2),range(4),range(4)):
        original[x,y,a,b]=As[x][a]@Psi@Bs[y][b].T
        probs[x,y,a,b]=mu[x,y]*np.linalg.norm(original[x,y,a,b])**2
    weighted=[]
    for w,R,T in parts:
        one=np.zeros_like(original)
        for x,y,a,b in product(range(2),range(2),range(4),range(4)):
            if a//2 in R and b//2 in T:
                one[x,y,a,b]=math.sqrt(w*mu[x,y])*original[x,y,a,b]
        weighted.append(one)
    p=sum(np.linalg.norm(one)**2 for one in weighted)
    desired=probs*np.array([[mask[a//2,b//2] for b in range(4)] for a in range(4)])[None,None,:,:]
    achieved=sum((np.sum(abs(one)**2,axis=(-2,-1)) for one in weighted),start=np.zeros_like(probs))
    fine_error=float(np.max(abs(achieved-desired)))
    assert fine_error<3e-13
    assert abs(np.sum(desired)-p)<3e-13
    SA=[];TA=[];SB=[];TB=[]
    psd_min=0.;target_error=0.;form_error=0.
    muX=np.sum(mu,axis=1);muY=np.sum(mu,axis=0)
    for l,(w,R,T) in enumerate(parts):
        sA=[];tA=[];sB=[];tB=[]
        CseedA=np.vstack([math.sqrt(w*muX[x])*(As[x][a]@Psi) if a//2 in R else np.zeros((2,2))
                         for x,a in product(range(2),range(4))])
        CseedB=np.vstack([math.sqrt(w*muY[y])*(Bs[y][b]@Psi.T) if b//2 in T else np.zeros((2,2))
                         for y,b in product(range(2),range(4))])
        for y in range(2):
            C=np.vstack([math.sqrt(w*mu[x,y])*(As[x][a]@Psi) if a//2 in R else np.zeros((2,2))
                         for x,a in product(range(2),range(4))])
            qT=sum(Q[cb][y][b] for b in range(4) if b//2 in T)
            s=C@C.conj().T;t=C@qT.T@C.conj().T
            direct=weighted[l][:,y].transpose(0,1,3,2,4).reshape(16,8)
            target_error=max(target_error,float(np.linalg.norm(t-direct@direct.conj().T)))
            psd_min=min(psd_min,float(np.min(np.linalg.eigvalsh((s-t+(s-t).conj().T)/2))))
            control=np.repeat(np.sqrt(mu[:,y]/muX),8)
            attached=(control[:,None]*(CseedA@CseedA.conj().T))*control[None,:]
            form_error=max(form_error,float(np.linalg.norm(attached-s)))
            sA.append(s);tA.append(t)
        for x in range(2):
            C=np.vstack([math.sqrt(w*mu[x,y])*(Bs[y][b]@Psi.T) if b//2 in T else np.zeros((2,2))
                         for y,b in product(range(2),range(4))])
            pR=sum(P[ca][x][a] for a in range(4) if a//2 in R)
            s=C@C.conj().T;t=C@pR.T@C.conj().T
            direct=weighted[l][x].transpose(0,2,4,1,3).reshape(16,8)
            target_error=max(target_error,float(np.linalg.norm(t-direct@direct.conj().T)))
            psd_min=min(psd_min,float(np.min(np.linalg.eigvalsh((s-t+(s-t).conj().T)/2))))
            control=np.repeat(np.sqrt(mu[x,:]/muY),8)
            attached=(control[:,None]*(CseedB@CseedB.conj().T))*control[None,:]
            form_error=max(form_error,float(np.linalg.norm(attached-s)))
            sB.append(s);tB.append(t)
        SA.append(sA);TA.append(tA);SB.append(sB);TB.append(tB)
    assert psd_min>-3e-12
    assert target_error<3e-12
    assert form_error<3e-12
    # Failure branches of the separate complete local maps.
    failuresA=[];failuresB=[];isometry_error=0.
    for x in range(2):
        success=sum(rowload[a//2]*P[ca][x][a]/A for a in range(4))
        f=hermitian_power(np.eye(2)-success,.5)
        isometry_error=max(isometry_error,float(np.linalg.norm(success+f.conj().T@f-np.eye(2))))
        failuresA.append(f)
    for y in range(2):
        success=sum(colload[b//2]*Q[cb][y][b]/B for b in range(4))
        f=hermitian_power(np.eye(2)-success,.5)
        isometry_error=max(isometry_error,float(np.linalg.norm(success+f.conj().T@f-np.eye(2))))
        failuresB.append(f)
    # Failure blocks have the same exact conditional-question attachment.
    seedA=np.vstack([math.sqrt(muX[x])*(failuresA[x]@Psi) for x in range(2)])
    seedB=np.vstack([math.sqrt(muY[y])*(failuresB[y]@Psi.T) for y in range(2)])
    for y in range(2):
        direct=np.vstack([math.sqrt(mu[x,y])*(failuresA[x]@Psi) for x in range(2)])
        control=np.repeat(np.sqrt(mu[:,y]/muX),2)
        attached=(control[:,None]*(seedA@seedA.conj().T))*control[None,:]
        form_error=max(form_error,float(np.linalg.norm(direct@direct.conj().T-attached)))
    for x in range(2):
        direct=np.vstack([math.sqrt(mu[x,y])*(failuresB[y]@Psi.T) for y in range(2)])
        control=np.repeat(np.sqrt(mu[x,:]/muY),2)
        attached=(control[:,None]*(seedB@seedB.conj().T))*control[None,:]
        form_error=max(form_error,float(np.linalg.norm(direct@direct.conj().T-attached)))
    assert form_error<3e-12
    parentA=sum(np.trace(s).real/A for rows in SA for s in rows)
    parentB=sum(np.trace(s).real/B for rows in SB for s in rows)
    for x,y in product(range(2),repeat=2):
        parentA+=mu[x,y]*np.linalg.norm(failuresA[x]@Psi)**2
        parentB+=mu[x,y]*np.linalg.norm(failuresB[y]@Psi.T)**2
    assert abs(parentA-1)<3e-12 and abs(parentB-1)<3e-12
    entA=parent_entropy(SA,TA,A,p) if p>1e-12 else None
    entB=parent_entropy(SB,TB,B,p) if p>1e-12 else None
    GA=sum(np.trace(s).real for rows in SA for s in rows)
    GB=sum(np.trace(s).real for rows in SB for s in rows)
    entA_success=parent_entropy(SA,TA,GA,p) if p>1e-12 else None
    entB_success=parent_entropy(SB,TB,GB,p) if p>1e-12 else None
    if p>1e-12:
        assert GA>=p-3e-12 and GB>=p-3e-12
        assert GA<=A+3e-12 and GB<=B+3e-12
        assert abs(entA['deficit']-entA_success['deficit'])<3e-8
        assert abs(entB['deficit']-entB_success['deficit'])<3e-8
    coherence_change=0.;bad_normalized_TV=0.
    if kind.startswith('all_ones'):
        # Fine-record coherences after tracing all appended labels/physical bodies.
        original_rows=original[0,0].reshape(16,4)
        old=original_rows@original_rows.conj().T
        new=np.zeros_like(old)
        for w,R,T in parts:
            filt=np.array([math.sqrt(w) if a//2 in R and b//2 in T else 0.
                           for a,b in product(range(4),repeat=2)])
            new+=(filt[:,None]*old)*filt[None,:]
        coherence_change=float(np.linalg.norm(old-new))
        assert np.max(abs(np.diag(old)-np.diag(new)))<2e-12
        squared_mask=np.array([[sum(w*w for w,R,T in parts if a in R and b in T)
                               for b in range(2)] for a in range(2)])
        wrong=probs*np.array([[squared_mask[a//2,b//2] for b in range(4)] for a in range(4)])[None,None,:,:]
        if wrong.sum()>0:
            bad_normalized_TV=float(np.sum(abs(wrong/wrong.sum()-probs/probs.sum()))/2)
    return {'p':float(p),'A':A,'B':B,'G_A':float(GA),'G_B':float(GB),
            'fine_error':fine_error,'minimum_S_minus_T_eigenvalue':psd_min,
            'common_target_margin_error':target_error,'conditional_form_error':form_error,
            'completion_error':isometry_error,'parent_trace_error':max(abs(parentA-1),abs(parentB-1)),
            'Alice_entropy':entA,'Bob_entropy':entB,
            'Alice_success_parent_entropy':entA_success,'Bob_success_parent_entropy':entB_success,
            'coherence_change_norm':coherence_change,
            'squared_weight_normalized_table_TV':bad_normalized_TV}


def r4(mu,pc,load):
    p=float(np.dot(mu,pc));q=mu*pc/p
    keep=q>0
    L=math.log(1/p)
    D=float(np.sum(q[keep]*np.log(q[keep]/mu[keep])))
    lhs=float(np.sum(q[keep]*np.log(load[keep]/pc[keep])))
    identity=L-D+float(np.dot(q,np.log(load)))
    rhs=L+math.log(float(np.dot(mu,load)))
    assert abs(lhs-identity)<3e-12
    assert lhs<=rhs+3e-12
    return {'lhs':lhs,'rhs':rhs,'gap':rhs-lhs,'identity_error':abs(lhs-identity),
            'prior_mean_load':float(np.dot(mu,load)),'posterior_mean_load':float(np.dot(q,load))}


def main():
    rng=np.random.default_rng(20261107)
    mu=np.array([[.11,.19],[.27,.43]])
    muD=np.array([.43,.07,.19,.31])
    data=[];tilts=[];minimum_povm_noncommutativity=float('inf')
    for trial in range(8):
        P=[[povm(rng) for x in range(2)] for ca in range(2)]
        Q=[[povm(rng) for y in range(2)] for cb in range(2)]
        for family in [P,Q]:
            for coarse in family:
                for measurement in coarse:
                    comm=max(np.linalg.norm(a@b-b@a) for a,b in product(measurement,repeat=2))
                    minimum_povm_noncommutativity=min(minimum_povm_noncommutativity,float(comm))
        Psi=rng.normal(size=(2,2))+1j*rng.normal(size=(2,2));Psi/=np.linalg.norm(Psi)
        for kind in ['three_edge','three_edge_boundary','all_ones_five','all_ones_zero_weight','all_ones_seven','trivial','zero']:
            contexts=[]
            for c in product(range(2),repeat=2):
                row=run_context(P,Q,Psi,mu,c,kind)
                row.update({'trial':trial,'kind':kind,'c':list(c)})
                contexts.append(row);data.append(row)
            if kind!='zero':
                pc=np.array([r['p'] for r in contexts])
                for side in ['A','B','G_A','G_B']:
                    load=np.array([r[side] for r in contexts])
                    tilt=r4(muD,pc,load);tilt.update({'trial':trial,'kind':kind,'side':side})
                    tilts.append(tilt)
    assert minimum_povm_noncommutativity>1e-4
    ones=[r for r in data if r['kind']=='all_ones_seven']
    assert min(r['coherence_change_norm'] for r in ones)>1e-3
    assert min(r['squared_weight_normalized_table_TV'] for r in ones)>1e-3
    classical_tilt=r4(np.array([.99,.01]),np.array([.0001,1.]),np.array([1.,100.]))
    saturation=r4(np.array([.2,.3,.5]),np.array([.2,.6,1.]),np.array([1.,3.,5.]))
    assert abs(saturation['gap'])<1e-12
    summaries={}
    for kind in ['three_edge','three_edge_boundary','all_ones_five','all_ones_zero_weight','all_ones_seven','trivial','zero']:
        rows=[r for r in data if r['kind']==kind]
        summaries[kind]={'contexts':len(rows),'p_range':[min(r['p'] for r in rows),max(r['p'] for r in rows)],
                         'maximum_fine_table_error':max(r['fine_error'] for r in rows),
                         'minimum_S_minus_T_eigenvalue':min(r['minimum_S_minus_T_eigenvalue'] for r in rows),
                         'maximum_common_target_margin_error':max(r['common_target_margin_error'] for r in rows),
                         'maximum_conditional_form_error':max(r['conditional_form_error'] for r in rows),
                         'maximum_completion_error':max(r['completion_error'] for r in rows),
                         'maximum_parent_trace_error':max(r['parent_trace_error'] for r in rows),
                         'minimum_coherence_change':min(r['coherence_change_norm'] for r in rows),
                         'minimum_squared_weight_table_TV':min(r['squared_weight_normalized_table_TV'] for r in rows)}
        if kind!='zero':
            ent=[r[side] for r in rows for side in ['Alice_entropy','Bob_entropy']]
            success_ent=[r[side] for r in rows for side in ['Alice_success_parent_entropy','Bob_success_parent_entropy']]
            summaries[kind].update({'maximum_entropy_budget_excess':max(e['deficit']-e['bound'] for e in ent),
                                    'minimum_conditional_deficit':min(e['deficit'] for e in ent),
                                    'maximum_private_label_cancellation_error':max(e['private_label_cancellation_error'] for e in ent),
                                    'maximum_actual_mass_budget_excess':max(e['deficit']-e['bound'] for e in success_ent),
                                    'maximum_completion_deficit_change':max(abs(a['deficit']-b['deficit']) for a,b in zip(ent,success_ent))})
    result={'status':'PASS','scope':'Finite tensor diagnostics; proofs are in challenges/constructor_one_sided_rectangles.md',
            'contexts_checked':len(data),'summary':summaries,'R4_checks':len(tilts),
            'maximum_R4_identity_error':max(t['identity_error'] for t in tilts),
            'minimum_povm_noncommutativity':minimum_povm_noncommutativity,
            'extreme_posterior_tilt':classical_tilt,'R4_saturation':saturation}
    initial=Path(__file__).resolve().parents[1]/'initial'/'constructor.md'
    result['initial_sha256']=hashlib.sha256(initial.read_bytes()).hexdigest()
    Path(__file__).with_name('one_sided_rectangle_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
