# Greedy-conditioning audit version correction

The current arXiv record 2608.14673 is v3, 9 September 2026, *A Human Audit of OpenAI's AI-Generated Mathematical Proofs*. Section 3.1 withdraws v1's claimed Chapter 6 greedy-polarity defect: PDF extraction lost an overbar, while the typeset original already conditioned on failure. The older v1 is therefore not evidence of a surviving original-proof defect. Both the current metadata and relevant full v3 section were read; the latest HTML is cached and hashed.

The current source distinguishes favorable review evidence from complete independent reconstruction. It does not certify every operator calculation. Our own all-n greedy proof explicitly continues on mean conditional failure greater than epsilon/2 and is independent of the disputed extraction. This note does not change the unread status of Zenodo record 22060622 or the separate assessment of record 22061117.

Primary source: https://arxiv.org/html/2608.14673v3#S3.SS1
