# Independent constructor: bounded-communication robust verification

Frozen initial investigation, 7 November 2026, Australia/Brisbane.
Researcher: the constructor in the prescribed three-researcher team.
No other researcher's construction or interim conclusion was read before this file.

## 1. Disposition and strongest achieved statement

The concrete bridge achieved here is **exponentially reliable verification with
bounded inter-prover communication**, including finite quantum communication,
quantified correlation between the referee's questions and the initial device
resource, and an adversarial fraction of transcript errors. Its proof works
directly with arbitrary commuting initial resources; no matrix approximation or
the unproved heterogeneous reconstruction hypothesis `FR(K)` is used.

This is a consequential capability available from the inherited theorem, but
**not a new amplification mechanism**. Transcript guessing and teleportation are
established machinery, notably Jain–Kundu, arXiv:2106.04299v3, Lemma 8. The new
scope obtained from the supplied capital is arbitrary within-round joint
questions and arbitrary commuting initial resources, with explicit threshold,
leakage and corruption accounting. No novelty claim beyond this scoped transfer
is made. In particular it is not quantum PCP, alphabet reduction, efficient
finite-dimensional realization, or an optimal communication direct-product rate.

The strongest proved transfer is the following. All logarithms are natural.

**Theorem C1 (robust verification).** Let
`G=(X,Y,A,B,mu,V)` be a finite two-player Boolean game with

\[
 \omega_{\rm co}(G)=1-\epsilon<1,
 \qquad \ell=\log(|A||B|).
\]

Draw `n` question pairs independently with law `mu^n`. Let integers `r,t>=0`
satisfy `r+t<n epsilon`, and set

\[
 \delta=\epsilon-\frac{r+t}{n}>0,
 \qquad
 b_G(\delta)=
 \frac{2^{-78}\delta^5}{\epsilon^2(\delta+\ell)}.
 \tag{C1}
\]

The referee accepts if at most `r` of its `n` coordinate checks fail. The two
provers may start with an arbitrary commuting resource and then exchange at
most `c` classical bits and `q` qubits in an arbitrary finite interactive
protocol after receiving their full question strings. The budgets are
**worst-case budgets**, counted over both directions. The communication model
and its exact local-algebra requirements are defined in §3.

An external adversary may then modify at most `t` coordinate answer records,
adaptively using the full generated transcript. It may change both answers in
one modified coordinate; the referee retains its original questions.

Initially the actual question-dependent resource may be correlated with the
questions. Suppose it obeys the `(h,eta)` operational domination condition
in §2 relative to `mu^n` and some question-independent commuting resource.
Then every such protocol obeys

\[
 \boxed{\Pr\{\text{accept}\}\le
 \min\{1,\exp[h+(c+2q)\log2-b_G(\delta)n]+\eta\}.}
 \tag{C2}
\]

In particular, take `r=t=floor(tau n)` with `0<=tau<epsilon/2`, and use the
slightly weaker rate `b_G(epsilon-2tau)`. If

\[
 h/n+(c+2q)\log2/n < b_G(\epsilon-2\tau),
\]

the soundness is exponentially small, up to `eta`. Applied as a compiler to a
promise family, a yes-instance having a perfect commuting honest strategy
remains perfectly complete despite `t` worst-case answer-record errors when
the acceptance tolerance is `r=t`. If a yes-instance's completeness is only
a supremum, its supremum completeness remains one, by using arbitrarily
accurate product strategies for each fixed finite `n`.

For all-wins acceptance with no transcript errors, the stronger inherited rate
gives

\[
 \boxed{\Pr\{\text{all win}\}\le
 \min\{1,\exp[h+(c+2q)\log2-a_G n]+\eta\},
 \quad
 a_G=\frac{2^{-75}\epsilon^3}{\epsilon+\ell}.}
 \tag{C3}
\]

These statements are proved **relative to the stipulated N443/N446 capital**,
at its exact independent-round, Boolean-game, arbitrary-commuting scope. Their
additional transfer lemmas are proved below. They do not rely on `FR(K)`.

An immediate distributed-computation consequence is a lower bound on the total
communication needed to satisfy the distributed relation `V` on nearly all
independent inputs with constant probability. If `p>eta` is achieved, then

\[
 c+2q\ \ge\
 \frac{b_G(\delta)n-h+\log(p-\eta)}{\log2}.
 \tag{C4}
\]

This is a direct-product lower bound in terms of a zero-communication gap.
It is not a strong direct-product theorem in terms of the optimal one-copy
communication complexity: its certified communication rate can be much smaller.

## 2. Source dependence: an exact dimension-free interface

Fix the initial resource algebra `M` on which the protocol's initial effects
act, including any independent ancillary registers. For each full referee
question pair `u=(x^n,y^n)`, let `phi_u` be a positive bounded functional on `M`,
with

\[
 \sum_u\phi_u(I)=1.
\]

Thus `phi_u(I)` is the actual probability of `u`, and the normalized functional
is its conditional device state whenever that probability is positive. Let
`phi` be a state on `M`, independent of `u`, whose local measurement/instrument
algebras are commuting. The direct-sum independent reference state has entries
`mu^n(u) phi`.

Define the domination defect

\[
 \mathcal E_h(\Phi\Vert\mu^n\phi)
 =\sup_{0\le F_u\le I}
   \sum_u\{\phi_u(F_u)-e^h\mu^n(u)\phi(F_u)\}.
 \tag{C5}
\]

The `(h,eta)` condition means `E_h<=eta`. This uses order and bounded
functionals only, and is meaningful without a density matrix or finite
dimension. For density matrices it equals

\[
 \sum_u \operatorname{Tr}
   (\rho_u-e^h\mu^n(u)\sigma)_+.
\]

In particular exact pointwise order domination
`phi_u <= e^h mu^n(u) phi` gives `eta=0`. This is the usual max-relative-entropy
idea in an algebraic formulation. The definition and the following argument
are explicit; Datta's finite-dimensional results are credited as antecedents,
not imported as a theorem about general von Neumann algebras.

**Lemma C2 (source transfer).** For any protocol with controlled acceptance
effects `0<=F_u<=I`,

\[
 P_{\rm actual}\le e^hP_{\rm independent}+\eta.
 \tag{C6}
\]

**Proof.** Substitute its family of effects into the supremum (C5). This proof
applies to the complete communicating protocol, before any communication
removal. Consequently `eta` is **not multiplied** by `2^(c+2q)` in (C2).
For normalized states within trace distance `eta` of an exactly dominated
state, the same bound follows from the elementary binary-effect trace-distance
bound. No state reconstruction or local recovery operation is required. ∎

Examples of the interface:

1. For question-independent resources and an altered question law `nu`,
   `nu(u)<=e^h mu^n(u)` suffices. This allows dependencies between repetitions,
   at a cost paid explicitly by `h`; the reference theorem still uses `mu^n`.
2. If all source–device correlation is through a classical value `L` with at
   most `M` possibilities, with conditional resource state `sigma_L`
   independent of questions given `L`, then `h=log M` works. Choose the
   independent reference `M^-1 sum_l |l><l| tensor sigma_l`; every coefficient
   `P(L=l|u)` is at most one. Any nonuniform question-law defect must be added
   separately.
3. If `mu` is uniform on `K` supported question pairs, a device-independent
   question law with min-entropy at least `n log K-h` obeys the density bound.
   This condition alone does not control correlation with the devices.

The domination condition is an assumption about a source/resource pair. This
investigation supplies no device-independent procedure to certify `h` or
`eta` for an unknown apparatus. It therefore does not supply a physical
randomness-certification protocol.

## 3. Exact communication removal in the commuting model

An admissible commuting-start protocol begins with commuting von Neumann
algebras `A_0,B_0` on a Hilbert space `H`, an arbitrary state, and local
ancillary registers. Each player uses local instruments/isometries whose
operator matrix coefficients belong to its respective algebra, tensored with
its currently held ancillary/message registers. Finite-dimensional message
registers may be transferred between players. Classical messages are classical
branches, not coherent uses of a classical channel. The protocol is a fixed
finite public protocol tree with worst-case budgets; public transcript-dependent
schedules and variable stopping can be padded along the tree. Private
uncommunicated local outcomes may affect subsequent local operations.

This includes ordinary tensor-product, arbitrary-prior-entanglement quantum
communication protocols. It also allows infinite-dimensional and non-type-I
commuting initial algebras. It does not claim that every abstract CP map on a
type-II algebra, with no specified locality implementation, is already an
admissible instrument. Locality implementation is part of the model.

**Lemma C3 (transcript guessing).** If such a protocol uses at most `C`
classical bits and has conditional output law `p(a,b|x,y)`, there is a legal
zero-communication commuting strategy and a subevent `T` of its local internal
histories such that, for every input pair,

\[
 \Pr\{a,b,T\mid x,y\}=2^{-C}p(a,b\mid x,y).
 \tag{C7}
\]

On its other branches the strategy can output any fixed legitimate answer
locally. Therefore for every nonnegative Boolean output predicate `W`,

\[
 P_{\rm communicating}(W)\le2^C\omega_{\rm co}(W).
 \tag{C8}
\]

**Proof.** Pad the public communication tree to depth `C`. Pre-share a uniformly
random `C`-bit string `z`. Each player simulates the protocol locally, replacing
every received classical message by the corresponding bits of `z`. When it
would send a message, it checks whether the locally generated message agrees
with `z`; a disagreement marks that player locally unsuccessful. It still has
a complete local procedure and returns a default answer on local failure.

For a fixed guessed transcript `z`, the branch in which every sent bit agrees
has exactly the same sequence of local CP maps as the original protocol's
transcript-`z` branch. Summing all its private local outcomes gives the same
unnormalized fine-output law on this branch. This equality follows by
composition of instruments, not by treating quantum outcomes from
counterfactual transcripts as predetermined classical randomness. Averaging
over `z` multiplies every original branch by `2^-C`, proving (C7).

In the zero-communication simulation, Alice's complete local instrument uses
only `x,z,A_0` and her ancillas, and Bob's uses only `y,z,B_0` and his ancillas.
Their output effects are complete POVMs in commuting amplified algebras.
Shared classical randomness is a central direct-sum register. Hence it is a
legal commuting strategy. On `T` it has the claimed payoff; on other branches
the payoff is nonnegative. This proves (C8). ∎

**Lemma C4 (quantum communication).** With `c` classical bits and `q` qubits,

\[
 P_{\rm communicating}(W)\le2^{c+2q}\omega_{\rm co}(W).
 \tag{C9}
\]

**Proof.** Replace each transmitted qubit by standard teleportation, using an
additional EPR pair and two classical correction bits. The complete replaced
protocol has exactly the same output law and at most `c+2q` classical bits.
The teleportation identity holds with arbitrary operator coefficients and an
arbitrary entangled reference, so no type-I factorization of the original
resource is used. The added finite matrix ancillas can be assigned to the two
players with commuting local amplified algebras. Apply Lemma C3.

Equivalently, postselecting the `00` Bell outcome transfers one qubit by the
identity map times `1/4` in unnormalized probability, uniformly for every
input and reference system; composing the identities and then guessing any
remaining classical transcript yields the same factor. This alternate
calculation clarifies that the communication penalty is `4^q`, not `2^q`.
No postselection is performed by the referee in the actual verification
protocol; it is only a lower-bounded branch of an existence simulation. ∎

This argument is the established teleportation/transcript method of
Jain–Kundu, Lemma 8, here written with its commuting-locality check and a full
fine-output identity. It is not a new quantum communication principle.

## 4. Complete proof of Theorem C1

First remove transcript corruption. A modification of a coordinate answer
record changes at most one of the `n` Boolean scores. If the modified transcript
has at most `r` failures after at most `t` modifications, its original
transcript had at most `r+t` failures. Thus acceptance implies the unmodified
score event

\[
 W\ge n-r-t=(1-\epsilon+\delta)n.
 \tag{C10}
\]

Since `W` is an integer this is exactly the corresponding ceiling event.
The implication holds pointwise, with arbitrary adaptive corruption.

The complete communicating protocol has a positive acceptance effect for each
question pair. Lemma C2 first bounds its original-score event under the actual
source by `e^h` times that event under a fixed independent resource, plus `eta`.
Under the independent resource, Lemma C4 bounds the event by `2^(c+2q)` times
the zero-communication commuting value of the threshold game in (C10).
The stipulated N446 threshold theorem bounds that value by
`exp[-b_G(delta)n]`. Combining gives (C2).

No product structure of the players' output measurements was used. There is
no assumption of independence of their coordinate wins. The only independent
objects in the reference experiment are the referee's `n` question pairs.
The inherited N443 all-wins theorem in place of N446 proves (C3).

For completeness, a product of perfect base strategies has zero original
failures, and `t` edits cause at most `t` failures. With `r=t` the verifier
always accepts. If only value-one supremum completeness is assumed, for fixed
`n` take a base strategy of loss at most `zeta/n`; the product strategy has
all-wins probability at least `1-zeta` by the union bound. Send `zeta` to zero.
This also shows that changing the question distribution within the original
support preserves any actual perfect honest strategy: every supported
question pair has zero loss individually.

## 5. Sharp obstructions and failed simplifications

### 5.1 The communication factors are best possible universally

Let `H_m` have a uniformly random `x in {0,1}^m` sent to Alice, one question
and one answer for Alice's opposite role as needed, and Bob's answer
`b in {0,1}^m`; accept exactly when `b=x`. Alice's answer is a singleton.
No-signaling of any commuting strategy forces Bob's output law to be
independent of `x`, so

\[
 \omega_{\rm co}(H_m)=2^{-m}.
\]

With `c` classical bits Alice can send a prefix of `x`; with `q` qubits and
prior EPR pairs she can transmit another `2q` bits by dense coding. Bob guesses
the rest uniformly. For `c+2q<=m` the resulting success is exactly

\[
 2^{c+2q-m}=2^{c+2q}\omega_{\rm co}(H_m).
 \tag{C11}
\]

The upper bound is Lemma C4, so the equality is exact. This elementary family
rules out any universally smaller exponential communication penalty. It
does not say that the inherited repetition exponent gives an optimal
communication threshold for every relation.

### 5.2 Expected communication and ordinary mutual information are insufficient

Use `H_1^n`, so Alice receives a uniform `n`-bit string `X`, and Bob must
reproduce it. Pre-share an independent bit `Z` with `Pr(Z=1)=1/n`. On `Z=1`,
Alice communicates all `n` input bits to Bob; on `Z=0`, Bob guesses a fixed
string. The expected communication is exactly one bit, but

\[
 \Pr\{\text{all win}\}=1/n+(1-1/n)2^{-n}\ge1/n.
 \tag{C12}
\]

Thus replacing a worst-case communication bound by an expected bound is
false even at the most elementary commuting gap `epsilon=1/2`.

The same example is a source-leakage counterexample: communicate nothing,
but leak `L=(Z,X)` to the devices when `Z=1`, and only `Z` otherwise. The
questions remain exactly uniform, and

\[
 I(X;L)=\Pr(Z=1)H(X)=\log2.
 \tag{C13}
\]

The shared resource is purely classical. Its total-variation dependence on
`X` is at most `1/n`, yet its all-wins probability is at least `1/n`.
Therefore `O(1)` Shannon/quantum mutual information, or merely vanishing
source–device trace distance, does not preserve exponential soundness.
The max-relative/order requirement in C1 cannot silently be weakened to an
ordinary mutual-information requirement.

For perspective, classical relative-entropy data processing gives only

\[
 p\,\log(1/s)-h_2(p)\le J
 \quad\Longrightarrow\quad
 p\le\frac{J+\log2}{\log(1/s)}
 \tag{C14}
\]

from a reference success at most `s` and a relative-entropy cost at most `J`.
With `s=exp(-a n)`, this is `O((J+1)/n)`, consistent with (C12)–(C13).
This paragraph uses classical log-sum/data processing only; no unverified
Araki-relative-entropy extension is imported.

### 5.3 This transfer does not derandomize question sampling

Suppose `mu` is uniform on `K` supported pairs. A law `nu` supported on at
most `M` repeated question pairs necessarily has a point of mass at least
`1/M`; hence any pointwise density bound `nu<=e^h mu^n` requires

\[
 h\ge n\log K-\log M.
 \tag{C15}
\]

Using (C6) to certify soundness `exp(-gamma n)` from a reference exponent
`b` therefore requires

\[
 \log M\ge n\log K-(b-\gamma)n.
 \tag{C16}
\]

In particular an `O(log n)`-bit seed and polynomial support are not obtained
from this proof. Source robustness is not a randomness-efficient repetition
theorem. Classical derandomized-repetition no-go results are relevant
comparators, but this elementary obstruction already suffices for this route.

### 5.4 Exact local answer re-encoding cannot compress a generic product

**Proposition C5.** Let a nonzero Boolean matrix `V` have `r` distinct nonzero
rows. Its tensor power `V^(tensor n)` has exactly `r^n` distinct nonzero rows.
Consequently, if deterministic local encoders satisfy

\[
 V^{\otimes n}(a,b)=D(f(a),g(b))
 \quad\text{for every }a,b,
 \tag{C17}
\]

then `|range(f)|>=r^n`. The analogous bound holds for distinct nonzero columns.

**Proof.** Nonzero tensor rows are tensors of nonzero rows, so there are at
most `r^n` distinct ones. For two different row strings, choose a coordinate
where their Boolean rows differ and choose a column there at which exactly
one of the two rows is one. For every other coordinate choose a column in
the nonempty support of the row string that was one at the distinguished
coordinate. The resulting tensor-column makes that entire tensor row one
and the other zero. Thus the `r^n` rows are distinct. Any two rows with the
same encoded message would be identical in (C17), which proves the bound. ∎

For any game all of whose supported question pairs admit a winning answer
pair, independent uniform answers also give

\[
 \omega_{\rm co}(G)\ge\frac1{|A||B|}.
 \tag{C18}
\]

Thus locally satisfiable games of soundness at most `s` require total answer
alphabet size at least `1/s`, or at least `log_2(1/s)` total answer bits. Neither
proposition forbids a genuine PCP/answer-reduction compiler: (C17) concerns
exact local re-encoding with no new consistency mechanism, and (C18) requires
local satisfiability of the compiled no-instance. These are scoped obstructions,
not impossibility results for quantum PCP.

## 6. Complete costs and dependency boundary

The actual verifier samples `n` base question pairs, sends `n` base questions
to each prover, receives `n` base answers from each, and evaluates `n` copies
of `V` plus one integer threshold. If a base sampler and evaluator use times
`T_mu,T_V`, its runtime is `O(n(T_mu+T_V))` plus linear-size bookkeeping.
Fixed-length classical communication is

\[
 n(\lceil\log_2|X|\rceil+\lceil\log_2|Y|\rceil)
 \quad\text{question bits},
\]
\[
 n(\lceil\log_2|A|\rceil+\lceil\log_2|B|\rceil)
 \quad\text{answer bits}.
\]

If the base sampler uses exactly `R_mu` unbiased bits, it uses `n R_mu`
independent random bits. An arbitrary rational law need not have a fixed-length
exact fair-bit sampler; its actual exact-sampling costs must be retained.
No seed reduction has been proved.

A circuit/program description can reuse the base verifier and contain `n`
and the threshold in binary, with size `O(|description(G)|+log n)`, and run
for linear time. An explicitly tabulated game has exponentially large question
and answer alphabets. The succinct description is not an explicit polynomial
table-size compiler.

For target soundness `s>eta` and fixed budgets `h,c,q`, sufficient length is

\[
 n\ge\frac{h+(c+2q)\log2+\log(1/(s-\eta))}{b_G(\delta)},
\]

with the appropriate threshold relation, or use `a_G` for all wins. The
conservative constants are extremely small. This is a mathematical capability,
not a demonstrated practical resource advantage. The model imposes no dimension
bound on the dishonest resource. An honest known `d`-dimensional base tensor
strategy uses dimension `d^n` on each corresponding side; an arbitrary
commuting base strategy need not have any finite-matrix implementation.
Teleportation adds `q` EPR pairs only in the proof simulation.

The only load-bearing prior scientific inputs are N443 and N446 at their
supplied scopes. `FR(K)`, heterogeneous quadratic repetition, projection
quadratic repetition, and nuisance-cancellation extensions play no role.
The local instrument definition and finite message assumption are explicit.

## 7. Primary-source comparison and novelty audit

The primary sources cached for this investigation are in
`../constructor/sources/`. Their hashes are recorded in `source_manifest.json`.

| Source | Checked part and relation |
|---|---|
| Governing N443/N446 composition, upstream `d4f37ab168f9312707b47709945cb0da5e896f33` | The pinned original general cubic and threshold rates (C1)/(C3), arbitrary joint within-round questions, independent repetitions, arbitrary commuting strategies; no efficiency. Root's source-only refresh reported all fourteen earlier proof hashes unchanged, corroborated by `../sources/UPSTREAM_PINS.json`. The old TXT composition and exact threshold scope were read. |
| Jain–Kundu, *A direct product theorem for quantum communication complexity with applications to device-independent cryptography*, arXiv:2106.04299v3 (20 Jan 2023), Lemma 8, §4; Theorem 1 | Lemma 8's teleportation and transcript-guessing argument is already exactly the needed finite-dimensional tensor predecessor for (C9). Its proof has no product-distribution requirement. Theorem 1's main quantitative direct product assumes distribution product **across players**, unlike the arbitrary joint `mu` here. Its introduction and later applications explicitly anticipate multiplying a repeated-game value by the communication-guessing penalty. This defeats any claim that communication tolerance itself is a newly discovered mechanism. The commuting transfer is proved in §3 instead of assuming matrix density. |
| Suruga, *The Exact Communication Threshold for Parallel Repetition*, arXiv:2611.01339v1 (31 Oct 2026), Introduction and Theorem 1.1 | For finite total relations and arbitrary joint distributions, claims the exact **classical** worst-case communication-rate threshold `IC_mu(g,0)` with all-wins success. It explicitly identifies transcript guessing as the elementary existing subcritical-rate consequence of repetition. It is a preprint comparator, not an imported quantum/commuting theorem. Its complete main proof was not independently audited here. It exposes the substantial missing operation beyond (C2): rates tied to information complexity rather than the very small repetition exponent. |
| Datta, *Min- and Max-Relative Entropies and a New Entanglement Monotone*, arXiv:0803.2770v3, §§II–III, Lemma 1 and max-relative-entropy definition | Supplies the established finite-dimensional order/positive-part context for (C5); (C6) is proved directly on positive functionals. The source restricts its Hilbert spaces to finite dimension, so it is not being silently used as an arbitrary-von-Neumann theorem. |
| Moshkovitz–Ramnarayan–Yuen, arXiv:1607.07130, abstract and bibliographic identification only | Relevant classical derandomized-repetition barrier. It was used for route discovery, not as an imported theorem; no exact applicability claim is made. The source-support obstruction (C15) is proved independently. |

Primary links:

- [Jain–Kundu v3](https://arxiv.org/html/2106.04299v3)
- [Suruga v1](https://arxiv.org/html/2611.01339v1)
- [Datta v3](https://arxiv.org/html/0803.2770v3)
- [Moshkovitz–Ramnarayan–Yuen](https://arxiv.org/abs/1607.07130)
- [Pinned original source](https://github.com/harjassand/astra-research-knowledge/blob/d4f37ab168f9312707b47709945cb0da5e896f33/web/pages/d-4307bff4c3cc7d61.html)

No claim of historical novelty follows from this bounded search. The strongest
positive conclusion is a complete, resource-accounted capability transfer of
the stipulated original theorem; the generic communication principle and
entropy principles are established machinery.

## 8. Decisive next operation

The route now has a precise ceiling. The generic factors `2^c` and `4^q` are
sharp, so improving their constants cannot produce a large new capability.
The meaningful next operation is a **communication-sensitive coordinate
reconstruction bound**: allocate the conditional information carried by actual
messages to individual game coordinates, preserve the original arbitrary
joint question law, and remove a low-information coordinate by local operations
on one question-independent commuting resource. A worst-case transcript-length
charge alone cannot do this.

A successful theorem of that kind could certify positive communication rates
substantially above the inherited repetition exponent, perhaps governed by an
appropriate quantum information complexity, and could then earn a stronger
distributed-verification primitive. This investigation does not define such a
quantum invariant as if its operational characterization were proved. General
interactive quantum compression/recovery and arbitrary-commuting locality are
real missing steps, not supplied by Lin's correlation-table closure or by
`FR(K)`.

For answer/question-efficient verification, the different decisive operation
is an actual locally sound composition/consistency test that avoids the exact
row-quotient obstruction (C17) while preserving quantum perfect completeness.
Neither hidden coordinate subsampling nor exact re-encoding accomplishes that.
The construction above intentionally retains the full linear transcript cost.

## 9. Status ledger

| Claim | Status |
|---|---|
| C2 robust threshold verification; C3 all-wins communication/leakage bound | Proved transfer relative to stipulated original N443/N446 capital |
| Positive-functional source transfer C6 | Proved, arbitrary resource algebra |
| Classical/quantum transcript removal C8–C9 | Proved at the explicit commuting-start instrument scope; established tensor antecedent credited |
| Universal factors `2^c` and `4^q` sharp | Proved by input-guessing/dense-coding family |
| Expected communication or `O(1)` mutual information preserving exponential security | Disproved by explicit rare-leak construction |
| Exact deterministic local answer compression below tensor row/column count | Disproved in the exact re-encoding model |
| Small-support question derandomization from max-density transfer | Disproved as a consequence of this transfer bound; no general derandomization impossibility claimed |
| Improved information-complexity communication threshold, alphabet reduction, constant-locality gap amplification | Open/not achieved here |
| New quantum PCP, physical demonstration, efficient matrices, new DIQKD security theorem, priority | Not established |

The initial report is frozen before cross-challenge; subsequent repairs belong
in separate files, not retrospective edits to this report.
