# Frozen independent initial report: decisive commuting amplification operations

Researcher: hostile constructive auditor, GPT-6.1 Sol, maximum reasoning.
Date: 7 November 2026, Australia/Brisbane.

I worked independently of the other three current researchers' constructions.
The principal sent a source-refresh notice only: upstream revision
`d4f37ab168f9312707b47709945cb0da5e896f33`, with all fourteen earlier proof
hashes unchanged. I read no other current initial report or new finding before
freezing this report. Prior-round reports and governing proof bodies were
permitted source material. No agents or descendants were created.

## 1. Strongest achieved mathematical repair

The original iid commuting repetition theorem alone implies a heterogeneous
product theorem, without assuming the newer `FR(K)` premise. This is an
elementary labelled-mixture simulation, not a claimed new foundational
mechanism or priority result.

Let `G_1,...,G_N` be arbitrary finite Boolean two-player games, with arbitrary
joint question laws inside coordinates and independent laws between
coordinates, and put `epsilon_i=1-omega_co(G_i)`. For any probability vector
`r=(r_i)`, let

\[
 r_* =\max_i r_i,\quad e_r=\sum_i r_i\epsilon_i,\quad
 J=\{i:r_i>0\},\quad
 \ell_J=\log(\max_{i\in J}|A_i|\;\max_{i\in J}|B_i|).
\]

Then, using precisely the supplied original constant,

\[
 \boxed{\displaystyle
 \omega_{\rm co}(G_1\otimes\cdots\otimes G_N)
 \le \exp\left[-\frac{2^{-75}}{r_*}
                  \frac{e_r^3}{e_r+\ell_J}\right].}
 \tag{A}
\]

This quantifies over arbitrary joint commuting product-game strategies.
It is not restricted to coordinatewise answering or product-algebra strategies.
The zero-gap case is assigned exponent zero. Uniform `r` on any subfamily
gives `|J| bar(epsilon)_J^3/(bar(epsilon)_J+ell_J)` in the exponent. Optimizing
over `r` is permitted. If all positive gaps exceed `epsilon_min`, a dyadic
corollary is

\[
 \omega_{\rm co}(\bigotimes_iG_i)
 \le \exp\left[-\frac{2^{-78}}{1+\lfloor\log_2(1/\epsilon_{\min})\rfloor}
               \sum_i\frac{\epsilon_i^3}{\epsilon_i+\ell}\right]
 \tag{B}
\]

for a common padded answer charge `ell`. Zero-gap coordinates contribute zero.
The logarithmic gap-range loss is explicit. Neither (A) nor (B) proves the
intrinsic fully heterogeneous sum-rate target or any quadratic general rate.

### Complete proof of the decisive operation

Construct a finite game `M_r` by drawing `i~r`, revealing `i` to both players,
and playing `G_i`. Pad answers to the two maximum sizes. Restricting a strategy
to an input label gives an upper bound, while a finite tensor product of
near-optimal component resources gives the reverse bound. Therefore
`omega_co(M_r)=sum_i r_i omega_co(G_i)=1-e_r` exactly, without attainment.

Fix any actual joint strategy for the full product of score `theta>0`. On `T`
independent copies its full-array all-wins probability is `theta^T`. Set
`k_T=floor((1-delta)T/r_*)`, with fixed `0<delta<1`. In `M_r^{k_T}`, the common
label string has, with probability tending to one, at most `T` occurrences of
each type. On that event assign occurrences of type `i` to successive cells
`(i,t)` in the original `N*T` array. Fill unused cells with pre-shared dummy
question pairs of their proper joint laws. Each player runs the original joint
measurement on the resulting own question string and returns the assigned
answers. Conditional on any good label string the full array has exactly the
original independent referee law. Full-array success implies success of every
actual mixture coordinate. Thus

\[
 \omega_{\rm co}(M_r^{\otimes k_T})\ge\Pr(\text{good labels})\theta^T.
\]

This is a genuine complete commuting strategy. The resource and dummy random
table are fixed independently of all actual questions; cell assignments depend
only on the common labels; the input effects are complete coarse-grainings of
the original full-answer POVMs. Define the same local rule with defaults also
on unsupported mismatched label strings, so all-input commutation holds.

Apply the original iid theorem to `M_r`, divide logarithms by `T`, let `T` tend
to infinity (the label-count good probability tends to one), and then let
`delta` decrease to zero. This proves (A). Applying it to the dyadic bin which
carries the largest total `epsilon_i^3/(epsilon_i+ell)` proves (B), since gaps
within a bin differ by at most two and `f(2e,ell)<=8 f(e,ell)`.

The full statement, legal simulation and all limiting quantifiers are in
[`HETEROGENEOUS_TRANSFER.md`](../auditor/HETEROGENEOUS_TRANSFER.md).

## 2. Constructive entropy repair: state correlation alone is not the barrier

The previous independent-nuisance result can be weakened in one definite
direction. Let `M=M_0 tensor N`, take an arbitrary bounded positive correlated
`sigma` with `tau(sigma^2)=1`, and let nuisance effects `R,S` be fixed across
the live questions and exposure stages. If `F_y=sum_x q(x|y)F_x`, then, for
`f(t)=t log t` with `f(0)=0`,

\[
 \sum_xq(x|y)f(F_x\otimes R)-f(F_y\otimes R)
 =\left[\sum_xq(x|y)f(F_x)-f(F_y)\right]\otimes R.
 \tag{C}
\]

The full proof is the functional-calculus identity
`f(F tensor R)=f(F) tensor R+F tensor f(R)`: the nuisance-log term cancels
because the main effects average exactly. No product-state assumption occurs.
Pairing with `chi_sigma(.,H_y tensor S)` proves the exact correlated-state
Jensen-increment identity. The transposed result holds for Bob's telescope.

For a fixed nuisance accepting contraction
`C=sum_l q_l L(I tensor R_l)R(I tensor S_l)`, if `C sigma=sigma`, its sum of
remaining main increments equals the unpadded increments exactly. This follows
by commuting `C` through every main effect to the vector. More generally a
fixed positive contraction `C` commuting with all retained local effects is
absorbed exactly into an input-independent shared vector
`C^(1/2)psi/sqrt(<psi,Cpsi>)`. Every declared main fine correlation is preserved.

This is a concrete repair of the **state-independence** assumption. It does
not remove fresh-question dependence of nuisance POVMs, and it does not promise
to retain nuisance fine outputs outside the retained observable algebra.
Question-correlated semantic subtraction in the general setting remains open.
Full statements, proof, a quantitative losing-event estimate and the exact
limitations are in [`CORRELATED_NUISANCE.md`](../auditor/CORRELATED_NUISANCE.md).

### An exact obstruction to erasing the fresh-question boundary

Start with independent uniform bits `X,Y,A,B`, and postselect
`E={A xor B=X*Y}`. Its probability is exactly `1/2` at every question pair, so
the full question law and both question marginals are unchanged. The resulting
conditional box is uniform on the two CHSH-winning answer pairs, with uniform
local marginals. It wins CHSH perfectly, whereas every commuting strategy wins
with probability at most `(2+sqrt(2))/4`.

For completeness the latter bound follows directly from Cauchy--Schwarz:
binary effects define self-adjoint contractions `A_0,A_1,B_0,B_1`, and

\[
 |\langle A_0(B_0+B_1)+A_1(B_0-B_1)\rangle|
 \le \sqrt{\|A_0\psi\|^2+\|A_1\psi\|^2}
       \sqrt{\|(B_0+B_1)\psi\|^2+\|(B_0-B_1)\psi\|^2}
 \le2\sqrt2.
\]

Thus zero question-law divergence is not a local reconstruction theorem.
This does not contradict the inherited R/H/S argument, which charges the
state/history alignment as well as referee-law drift.

## 3. Exact local-compilation obstructions

Two tempting operations fail even before their resource costs are considered.

**Uniform operator-norm exactification fails for binary POVMs.** For every
`n>=7` there are same-side commuting effects `E_1,E_2,F_1,F_2` in `M_n` whose
cross commutators have norm at most `sin(pi/n)/2`, yet no exactly cross-commuting
effect families are all within `1/32` in operator norm. The proof converts
Voiculescu's clock/shift pair into real and imaginary effects and uses the
integer `Tr log(UVU*V*)/(2 pi i)`: it is one for the clock/shift pair and zero
for a commuting pair, and remains constant under the specified small norm
perturbation. Polar decomposition converts nearby cross-commuting effects to
nearby commuting unitaries, a contradiction.

This is established Voiculescu/Exel--Loring machinery, not new priority. I give
the complete constant calculation and also an explicit commuting approximation
in normalized tracial two-norm with error `O(n^-1/3)`. That repair shows why
one must state the topology and state dependence exactly. It does not establish
a correction for arbitrary state-weighted correlations. The inherited sampler
already uses exact opposite algebras, so this is not a counterexample to it.

**A normalized sum of local positive terms cannot directly equal global AND
rejection with a constant gap.** Let `Q=I-|0^n><0^n|` and
`H=sum_alpha h_alpha`, with positive terms of locality at most `k`,
`sum_alpha ||h_alpha||<=T`, and `H|0^n>=0`. If `H>=lambda Q`, then

\[
 \lambda\le kT/n.\tag{D}
\]

Proof: every term annihilates `|0^n>`. On one-excitation states `e_i`, a term
vanishes unless its support contains `i`, and otherwise its expectation is at
most its norm. Therefore `n lambda <= sum_i<e_i,H e_i> <= kT`. With a unique
ground state the variational principle gives the same upper bound on the gap.
Also `Q` cannot be a sum of terms with locality below `n`, even allowing signs:
its Pauli coefficient against `Z tensor ... tensor Z` is `-2^-n`, whereas every
term missing a site has coefficient zero.

These statements are ancilla-free. Encodings, extra consistency checks, greater
locality or interaction strength can evade them and must be accounted for.
They show why the global all-wins accepting operator is not already a local
Hamiltonian gap compiler. Anshu--Arad--Vidick, arXiv:1602.01210v2, Theorem 5,
is an established geometric coarse-graining comparator, with extra hypotheses.

Finally an ignored answer bit can be the parity of every local question in a
repeat. Its game value is unchanged, but no coordinate-question-causal table
approximates that fine bit with mean TV error below `1/2`. Repetition success
therefore does not force local question dependence of the full answer table.

All three proofs and topology/locality scopes are in
[`LOCAL_COMPILER_OBSTRUCTIONS.md`](../auditor/LOCAL_COMPILER_OBSTRUCTIONS.md).

## 4. Audit of the inherited operational production and the FR discrepancy

I read the governing R, H, S_actual, E and interface bodies, not only theorem
cards. Their exact bytes are recorded in
[`INPUT_PINS.json`](../auditor/INPUT_PINS.json). The verified key hashes are:

| Body | SHA256 |
|---|---|
| R/resolvent | `2acf3c9e5d067de16c873e16bf0fbe52e6becdd47c6db55a3fd526ac086e8627` |
| H/history | `0893936c7ab79d8a5b3fac87af28a90e4e7e9b45d52bd23b20d4b94629f02475` |
| S_actual | `f37b03a0a84487328c4d1b96b30bbc03468e085bef5593a635126775310beb2b` |
| E/near-perfect | `55c2956bb771d630307639a4fd5ff46ea772b484985499dcd765d34f9183cbce` |

The completed internal interface audit identified no fatal mathematical error
in these inspected original operations. In particular:

- R keeps exact `F_T^*F_T=T` after finite auxiliary compression; it does not
  approximate the ambient algebra by matrices. The bounded support effects and
  the left-column/right-row polar orientations preserve all fine main answers.
- H compares the actual posterior `Q` with `mu(x,y)P_A(r|x)` and
  `mu(x,y)P_B(r|y)`. It does not assert `Q_R tensor mu`. The finite shared
  exponential race provides a legal input-dependent local history coupling.
- S_actual supplies complete unconditional all-input POVMs in amplified fixed
  left/right algebras. The actual common-trial branch and bad probability give
  the rare-event estimate for the same protocol. It supplies no fixed-original-
  algebra trace-preserving output channel, so the known central-channel
  obstruction is inapplicable.
- E retains the losing-event form `alpha+2 sqrt(alpha F)+F`, and charges history
  TV/mismatch additively. Its finite-accuracy limits are ordered at fixed tested
  probability, with all resources input-independent.
- Lin 2304.01940v3, Definition 3.1/Theorem 3.2, was checked in the primary source.
  It gives finite-table closure using finite tracial von Neumann algebras. It
  does not give finite-matrix closure or convergence of representation-dependent
  vectors. The scalar inequality must be proved before taking that table limit.

The original supplied theorem remains intact at its exact scope and constant.
The public `games.tex` and previous private dossier are not identical logical
assertions: the former explicitly assumes `FR(K)`; the latter derives its new
coordinate budget **relative to** the complete source production lemmas. The
positive-functional endpoint estimate alone does not prove `FR(K)`. Nor does
the original iid all-wins theorem imply that per-tested-set reconstruction
condition. A new unconditional heterogeneous quadratic statement cannot be
promoted just by citing the public paper.

This initial audit does not silently close that public hypothesis. The new
theorem (A) intentionally avoids it. A separate current proof/acceptance of the
entire coordinatewise charged production can close the relative dependency;
the exact R/H/S laws, fine transport, all-input legality and rare-event scaling
must remain present. Internal mathematical checking is meaningful at the scope
just stated; no external review gate is being inserted.

## 5. Primary literature and source access

The Astra connector tools were absent from this turn's available tool catalog.
The exact local source caches were used read-only, with the principal's refreshed
upstream pin. The repository and unrelated files were not modified.

Primary sources checked or cached:

- Lin, arXiv:2304.01940v3, Definition 3.1 and Theorem 3.2:
  <https://arxiv.org/html/2304.01940v3>. Exact tracial closure, not matrix closure.
- Song, ECCC TR26-199, Lemma 4.1 and Theorems 1.1/4.6:
  <https://eccc.weizmann.ac.il/report/2026/199/download/>. Its finite-dimensional
  tensor sampler is a predecessor, not itself the arbitrary-von-Neumann import.
- Anshu--Arad--Vidick, arXiv:1602.01210v2, Section 4/Theorem 5:
  <https://arxiv.org/html/1602.01210v2>. Projector, frustration-free,
  nearest-neighbour chain setup was checked. No general-game compiler imported.
- Exel--Loring, *Almost commuting unitary matrices*, Proc. AMS 106 (1989),
  913--915, DOI <https://doi.org/10.1090/S0002-9939-1989-0975641-9>.
  The primary author/publisher indexed text and bibliographic facts were checked;
  full PDF fetching encountered a certificate error at the author host and 403
  at AMS. The obstruction proof used here is supplied in full independently.
  The author-hosted primary abstract explicitly credits Voiculescu's example.
- Exel--Loring, JFA 95 (1991), 364--376:
  <https://doi.org/10.1016/0022-1236(91)90034-3>. The primary abstract confirms
  the established winding/K-theory invariant comparison; no new stability
  theorem is imported from it.

The original line-game obstruction, KRT restrictions, anchored Lin theorem and
prior positive-filter obstruction remain governing comparators, rather than
new findings in this report. No priority claim follows from this search.

## 6. Checks, ledger and decisive next operation

[`check_obstructions.py`](../auditor/check_obstructions.py) reproduced the
correlated-state identities on noncommuting 4-by-4 controls, with maximum error
`1.41e-15`; perfect correlated-nuisance increments with error `2.23e-16`; clock
Bott index one on all five tested sizes; the explicit tracial two-norm repairs;
and 299 saturation cases of the normalized locality bound. Exact proof, rather
than these diagnostics, establishes all asymptotic assertions.

| Statement | Status |
|---|---|
| Original general iid commuting cubic theorem and threshold capital | Preserved at exact supplied scope |
| Labelled-mixture heterogeneous bound (A), and dyadic (B) | Proved from original iid theorem alone |
| Fixed nuisance-log increment cancellation with correlated state | Proved under fixed literal tensor nuisance effects |
| Fixed commuting event absorption preserving declared main observables | Proved for arbitrary correlated resources |
| General question-correlated semantic entropy subtraction | Open; CHSH postselection blocks an unrestricted claim |
| Uniform operator-norm cross-POVM exactification | Disproved by explicit clock/shift construction |
| Direct normalized ancilla-free constant-locality AND gap compiler | Disproved at the scope of (D) |
| General encoded local consistency compiler or quantum PCP consequence | Not established or disproved here |
| General quadratic commuting repetition / fully intrinsic heterogeneous rate | Not established here |
| Efficient finite matrices / physical advantage / historical priority | Not established |

The strongest enabling missing operation is an **observable-level local
correction which controls relative loss at the actual postselection mass and
keeps one legal all-input strategy**. For the entropy direction, identify a
retained local algebra plus a common event in its commutant, or prove a relative
approximate substitute, rather than subtracting a nominal nuisance entropy.
For a local consistency/Hamiltonian direction, give an explicit encoding and
normalized test family with a reconstruction map sound against arbitrary joint
commuting strategies; a product accepting operator or small commutators do not
supply it. Those targets are concrete operations with falsifiers above, not
consequences already earned by repetition.
