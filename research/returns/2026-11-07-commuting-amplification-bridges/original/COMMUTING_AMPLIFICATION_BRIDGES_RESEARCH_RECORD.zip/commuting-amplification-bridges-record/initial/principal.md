# Independent principal investigation — 7 November 2026

This report is frozen before reading the three new researchers' returns. The shared previous dossier and published manuscript were read; no new construction from another researcher was used.

## Chosen capability and decisive operation

Can the commuting repetition theorem give quantitative, scalable soundness for one untrusted quantum device, replacing physical separation by bounded information flow? The strongest target is a constant-round cryptographic compiler with negligible soundness for growing repeated games and efficient honest implementation. Existing qualitative compilation only treats fixed games before taking the encryption-security limit. A double limit is not a uniform theorem.

The current primary comparison is Kulpe–Malavolta–Paddock–Schmidt–Walter, arXiv:2408.06711v3, Theorems 6.1–6.2; Cui–Falor–Natarajan–Zhang, arXiv:2507.17581v1, one-sided nice-SOS hierarchy; and Klep et al., arXiv:2507.17006v3 (16 October 2026), sequential NPA hierarchy. The latter revision must be used rather than the stronger wording of older abstract snippets. All finite-certificate bounds retain certificate/game/strategy dependence; finite convergence is an additional property. Their proofs do not yet supply a polynomial-cost certificate for arbitrary repeated games.

## An exact multiplicative information-flow bridge

**Theorem P1 (common positive-functional domination).** Let G=(X,Y,A,B,mu,V) be any finite two-player game with nonnegative payoff. A sequential algebraic strategy consists of a unital C*-algebra B, Bob POVMs b_{b|y} in B, and positive bounded functionals phi_{a|x} on B with rho_x=sum_a phi_{a|x} a state. Its score is p=sum mu(x,y)V(x,y,a,b)phi_{a|x}(b_{b|y}). Suppose a positive functional psi dominates every rho_x in positive-functional order, and psi(1)=M<infinity. Then p <= M omega_co(G). The bound applies to every nonnegative event/payoff on an entire parallel table.

**Proof.** Fix one legitimate output a0 per x and define theta_{a|x}=phi_{a|x}+1_{a=a0}(psi-rho_x). These are positive and sum to psi. Let (pi,H,Omega) be the GNS representation of psi, with ||Omega||^2=M. The C*-algebra Radon–Nikodym theorem gives, for each theta_{a|x}<=psi, a unique positive contraction E_{a|x} in pi(B)' satisfying theta_{a|x}(z)=<Omega,E_{a|x}pi(z)Omega>. Their sum equals identity on the cyclic GNS space, because the sum of functionals is psi. With vector Omega/sqrt(M), Alice's E POVMs commute with Bob's pi(b) POVMs. Its score is at least p/M since the added terms have nonnegative payoff. This is a legal commuting strategy. Take its score below omega_co(G). No matrix approximation or uniform limiting argument is used. QED.

In finite dimension, the hypothesis is simply psi(z)=Tr(Sz), S>=rho_x for all x, M=Tr S. Thus the best M is the semidefinite covering number

  M*=min{Tr S:S>=rho_x all x}.

This is a known information radius / state-discrimination quantity, not a newly invented norm. For uniform x over k labels, SDP duality gives M*=k p_guess(X|B); hence log M* is a quantum maximal-leakage/min-entropy information measure. For an abstract C*-algebra a finite common dominator always exists, e.g. sum_x rho_x; the point is the smallest mass. Predecessors for the domination/assemblage correspondence must be checked before any novelty claim.

**Consequence P2 (conditional on original N443 capital only).** If the entire n-coordinate sequential assemblage has a common dominator of mass M_n, its all-win probability obeys

  p_n <= min{1, M_n exp[-2^-75 epsilon^3 n/(epsilon+log(|A||B|))]}.

For log M_n <= kappa n with kappa less than the repetition exponent, soundness still decays exponentially. This is a quantitative replacement for exact strong nonsignaling, without an additive error floor. The theorem does not assume FR(K), block predicates, finite matrix density, or efficient physical access. The corresponding threshold inequality follows from the original threshold theorem applied to the same nonnegative event. The construction consumes an abstract dominating functional; it is not an algorithm acquiring it.

## Exact obstruction to substituting Shannon leakage

Let x be a uniform m-ary label, y constant, Alice output irrelevant, and V=1{b=x}. Then omega_co(G)=1/m. In n rounds let K=m^n. Prepare an orthogonal classical flag which, with probability delta, sends the entire x-string to Bob, and otherwise sends an erasure symbol. Bob then wins all rounds with probability delta+(1-delta)/K. The mutual information is delta log K. Taking delta=1/n gives I(X^n:B)=log m (constant), but all-win probability at least 1/n. Thus an exponential repetition guarantee under merely bounded or o(n) Shannon information leakage is false. In contrast, common domination has exact mass 1+delta(K-1), and P1 is an equality for this fixture. This identifies a rare-revelation obstruction, not failure of the original no-communication theorem.

## Stronger route still missing

Cryptographic indistinguishability tests only efficient observables and does not imply common domination in the full algebraic positive cone. Ciphertexts can be statistically distinguishable while computationally hidden. Applying P1 directly to QHE would therefore be false reasoning.

A plausible route is a certificate-relative domination condition: only the positive cone needed by a polynomial-size nice-SOS certificate must be controlled. The missing operation is to turn the operational repetition proof into such a certificate with polynomial degree, coefficient norm, and description length for growing games. The needed quantitative output has form

  score_comp(G^n,lambda) <= exp(-r n) + C(G,n,d) Adv_QHE(poly(lambda,n,d)),

with a genuinely polynomial/controlled C and extractor runtime. Presently this is an open capability, not achieved. Existing special XOR-game products already have stronger certificate machinery; they cannot be relabelled new.

The general positive-functional bridge above is mathematically complete but likely an application/extension of established steering-domination and leakage robustness. Its substantive role this round is locating a multiplicative error interface and proving why average information is insufficient; it is not an extraordinary new verifier by itself.

## Source and scope checks

Upstream head was refreshed by GitHub API to d4f37ab168f9312707b47709945cb0da5e896f33; fourteen selected proof files have unchanged hashes from the earlier pinned revision. Recorded in ../sources/UPSTREAM_PINS.json. Astra connector tools are absent, so this investigation used exact local indexed sources and pinned GitHub passages, not an invented connector result. The old shared local research checkout has unrelated untracked ammonia files and was left read-only.

The published games.tex makes FR(K) explicitly unproved. The previous dossier's heterogeneous game rates remain relative to its named reconstruction interfaces; they are not promoted to unconditional capital here. The given original general commuting cubic theorem retains its own accepted status.
