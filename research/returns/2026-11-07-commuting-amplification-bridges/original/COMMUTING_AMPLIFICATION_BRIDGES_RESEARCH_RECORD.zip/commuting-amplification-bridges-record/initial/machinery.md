# Independent initial report: retained common outputs and conditional sufficiency

Frozen 7 November 2026. Researcher: existing-machinery researcher, GPT-6.1 Sol at maximum reasoning. No other researcher's new mathematical results were read or exchanged before this report. No descendants were spawned. Supporting material belongs in `../machinery/`.

## Highest-upside route

Retain a private copy of a **common coarse checked output** in each player's residual workspace, and charge conditional relative entropy after subtracting its retained marginal. For a disjoint-block predicate the accepted block label is a common output. Its entropy then cancels exactly, including when question-correlated. This is more general than subtracting an independent tensor nuisance and does not require a small positive separator.

I prove an answer-free **parent conditional-relative-entropy budget** for finite-dimensional tensor strategies in products of disjoint-block games. Jain's new local-preparation theorem appears to turn this into quadratic tensor repetition. It identifies a precise standard-form transfer target for commuting strategies, which is **not completed here**. In particular, this report does not assert `FR(K)` or remove the published paper's hypothesis. The bookkeeping from parent budgets to two compatible pure coordinate targets is a concrete construction to challenge.

A second substantial finding blocks a tempting 2026 recovery shortcut: a recent primary source wrongly infers that a positive contraction with nonzero fixed space has an isolated eigenvalue at one. The strictly CPTP counterexample below disproves the stated operator-norm convergence theorem. A true spectral-gap hypothesis repairs it.

## 1. Capital and scope

Accepted capital: the given general cubic commuting theorem and associated threshold theorem. `outputs/commuting-repetition-paper/games.tex` explicitly leaves its new heterogeneous/quadratic game applications conditional on unproved `FR(K)`; SHA256 `57942b283febf9402aefad82e91bf5b03af981f8594086553cc31184c45606a0`.

Read: standing workflow, prior dossier, finite-tracial resolvent proof, root weighted-mass refinement. Local resolvent SHA256 `2acf3c9e5d067de16c873e16bf0fbe52e6becdd47c6db55a3fd526ac086e8627`; refinement SHA256 `10d17bb56009a173cb3b4807e5fca58fb9b3eb5728b3baeac3a10dbd4b453250`.

Read-only `git ls-remote` independently found upstream HEAD `d4f37ab168f9312707b47709945cb0da5e896f33`. The weighted-mass file fetched through the GitHub connector at that revision retains its explicit internal conditional status and named sampler/density premises. The principal later supplied a source-only update that all 14 earlier proof hashes are unchanged; no mathematical construction was shared.

## 2. Exact imports

- **Jain, arXiv:2610.21410v1 (15 October 2026).** Definition 2.6 gives copied-input conditional comparisons with the original conditional question law. Lemma 2.24 allocates conditional relative-entropy deficits in complementary orders. Lemma 4.1(ii) constructs compatible local pure descriptions; Lemma 4.1(i) gives mean preparation infidelity at most `Cprep sqrt(bA+bB)` with finite positive-slack witnesses. Lemma 4.2 supplies exact-marginal replacement, rather than a generic recovery appeal. The model is finite-dimensional tensor. [Primary source](https://arxiv.org/html/2610.21410v1).
- **Faulkner–Hollands, arXiv:2010.05513v1, Theorem 2.** A normal unital 2-positive map between von Neumann algebras, a faithful normal reference state and a normal target obey a relative-entropy-deficit bound on minus log squared root-fidelity to averaged rotated-Petz recovery. This is available beyond matrices. It does not itself give the exact retained marginal or bilateral local implementation needed here. [Primary source](https://arxiv.org/html/2010.05513#S3).
- **Lin, arXiv:2510.07162v1.** Theorem 9.3 supplies anchored commuting repetition with gap power 17. Lemma 9.4 checks conditionally-linear sampler closure. Sections 6–8 already supply question/answer reduction and gap compression; `MIPco=coRE` is already Theorem 1.1. A better amplifier improves one stage, not that classification. [Primary source](https://arxiv.org/html/2510.07162v1).
- **Bhattacharya, arXiv:2605.08829v1, Theorem 1.** Claims operator-norm convergence of iterated Petz recovery for every strict CPTP map on a finite tracial algebra with bounded invertible reference. Its proof infers isolation of one from a nonzero fixed space. Section 6 below gives a counterexample meeting its hypotheses, so I do not import it. [Primary source](https://arxiv.org/html/2605.08829).
- **Comparators.** KRT already gives commuting unique-game quadratic products. DSV's projection theorem is not automatically the quadratic result sought here. Culf's March 2026 projection-to-tracial rounding contains the inverse least supported conditional-question probability; under products this can grow exponentially. It does not replace the local-preparation transfer.

## 3. Conditional entropy identifies the semantic answer charge

Use natural logarithms. Let finite classical `Z` label states `rho_z` on `RK`, with probabilities `q_z`, and set `rho=sum_z q_z rho_z`. Let `sigma` be a reference with finite displayed divergences. Donald's identity on the two marginals gives exactly

    sum_z q_z [D(rho_z || sigma) - D(rho_z^K || sigma^K)]
      = D(rho || sigma) - D(rho^K || sigma^K) + I(Z:R | K).       (M1)

If `rho <= sigma/p`, operator monotonicity of log gives `D(rho||sigma)<=log(1/p)`, hence

    sum_z q_z [D(rho_z || sigma) - D(rho_z^K || sigma^K)]
      <= log(1/p) + I(Z:R | K).                                (M2)

If an orthogonal classical copy `L=Z` is retained in `K`, both `H(Z|K)` and `H(Z|RK)` vanish, so the CMI in (M1) is zero. Correlation with questions does not prevent cancellation. More generally

    I(Zb Znu:R | K) = I(Zb:R | K) + I(Znu:R | K Zb),             (M3)

so a quantum-Markov redundant label incurs no additional parent charge. The identity is standard; the application is the retained common output construction below. Finite classical direct sums give the analogous normal-state identity over a finite tracial algebra; operational reconstruction remains separate.

## 4. A common checked block label gives answer-free parent budgets

Fix an arbitrary finite-dimensional tensor product-game strategy, proper tested set `D`, and disjoint-block predicates. First fix the entire tested-question string `c=(x_D,y_D)`. Each accepted tested answer pair belongs to a unique product block `k`. There are local maps

    f_c:A_D -> K_c union {bottom_A},
    g_c:B_D -> K_c union {bottom_B},

with distinct losing sentinels such that

    E_D = { f_c(a_D)=g_c(b_D) in K_c }.                         (M4)

For projections, `k` is Bob's tested answer string. Dependence on both **tested** question strings is allowed in the analysis: `c` is fixed before the fresh live coordinate, and is shared reconstructed history. No opposite fresh question enters a local operation.

Dilate the local measurements coherently and retain fine live outputs. Compute enough basis copies of each local block label to reserve (a) a dephasing copy traced out in parent marginals, (b) a retained own-label copy in the player's residual workspace and (c) shared-history copies. At fixed `c` these are local controlled isometries. The original measured table is unchanged.

Conditioning on an accepted common label `k` leaves a pure global conditional vector: discarded label copies are then fixed basis vectors. Fine tested answers within a block stay coherently in the local workspaces. Averaging over `k` preserves the original event-conditioned live fine-answer law.

### Parent operator inequality

Let `R_J` contain live protected question copies. Let `K_A` contain Alice's live question controls, residual workspace and retained own-label copy `L_A`. Trace another label copy so the preselection Alice parent `sigma_A,c` is block diagonal in `L_A`. Then

    sigma_A,c = direct_sum_{k_A} S_{k_A},
    p_c rho_A,c = direct_sum_{k in K_c} T_k,   0 <= T_k <= S_k. (M5)

The inequality holds because, on an Alice label block, Bob's selected label effect is bounded by identity; partial trace preserves positivity. Thus

    rho_A,c <= sigma_A,c / p_c.                                (M6)

The same construction works for Bob. It permits arbitrary joint local measurements on all question strings, without product-state or independent-answering assumptions.

Let `rho_A,c,k` be successful common-label blocks, normalized with event-conditioned probabilities `q_c(k)`. Since each target retains `L_A=k`, (M1)–(M2) give

    sum_k q_c(k) [D(rho_A,c,k^{R_J K_A} || sigma_A,c)
                  - D(rho_A,c,k^{K_A} || sigma_A,c^{K_A})]
       <= log(1/p_c).                                        (M7)

Both orientations have this bound. If `p=P(E_D)>0`, averaging over the conditioned tested-question law gives

    E_{c|E_D} log(1/p_c)
      = log(1/p) - D(P_{c|E_D} || mu_D) <= log(1/p).             (M8)

There is no alphabet-size term, even if the common block label depends on live questions through a joint strategy.

### Ordered-coordinate construction to challenge

At fixed `c`, tracing Bob's physical systems removes Bob's isometry. Alice's parent, including her own copied block label, still comes from an isometry controlled only by the full Alice live string. Its retained-label dephasing is local. It therefore has Jain's `mu_J`-conditional comparison form. Bob has the symmetric form.

Apply Jain's Lemma 2.24 in complementary orders. Shared histories contain `c,k` and the exposed complementary live questions, rather than full tested fine answer pairs. Local fine tested records remain in the workspaces. The retained private `k` copy must stay in each parent/coordinate workspace; the external shared-history `k` copy is distinct. A preselection comparison averages its internal local-label copy while the target fixes it. This is legitimate because its marginal divergence is subtracted, rather than pretending that the comparison is conditioned on the successful common output.

The expected result is

    sum_{i notin D} (b_A,i+b_B,i) <= 2 log(1/p),
    sum_{i notin D} D(q_i^{X_i Y_i} || mu_i) <= log(1/p).        (M9)

Full divergences on supported label blocks are finite by (M5). Question-law divergence is ordinary classical postselection. The first line is an allocation of (M7), not an acceptance-mask mass bound.

**Status:** (M1)–(M8) are proved elementary information/operator statements. The complete register construction leading to (M9) is offered for hostile checking. The exact issue is whether both pure coordinate targets and both conditional-comparison parents can be chosen simultaneously with the retained private label copies as claimed. It is not a declaration that commuting `FR(K)` is solved.

If the bookkeeping passes, Jain's finite-dimensional Lemma 4.1 yields a legal extraction with mean loss bounded by

    alpha + C [sqrt(alpha) t^(1/4) + sqrt(t)],
    t = log(1/p)/m,                                          (M10)

for a universal constant and positive finite slack. Greedy testing gives quadratic tensor block-game repetition. The previous dossier's all-finite-length scalar calculations can then be reused after reconciling constants. This is not yet a commuting theorem: a finite von Neumann algebra need not be a matrix algebra, and Lin's correlation-table closure supplies no matrix density.

## 5. The exact commuting transfer still required

Jain's Lemma 4.2 forms

    nu_tilde = integral beta_0(s) (I_R tensor L_s) nu
                                      (I_R tensor L_s)^* ds,
    L_s = rho_K^((1+is)/2) nu_K^(-(1+is)/2),

and proves an exact target retained marginal, a measured-divergence bound by the conditional entropy deficit, and preservation of the conditional-comparison form. In a finite von Neumann algebra inverse powers can be unbounded. General universal recovery does not automatically give these stronger exact-marginal properties or the two compatible local descriptions.

The strongest focused next operation is to prove this exact-marginal replacement for finite classical protected references over arbitrary finite tracial algebras; first boundedly invertible densities, then a justified zero-spectrum regularization. Next establish the coherent-ensemble Uhlmann correction in the required commutant. Finally feed the compatible descriptions to the actual all-input standard-form sampler, preserving fine-answer laws and its rare-event loss estimate. A generic trace-norm approximation of a recovered state does not complete this chain.

Even success would establish the block/projection route, not general all-predicate quadratic repetition or local Hamiltonian gap amplification.

## 6. A 2026 recovery shortcut is false; its spectral-gap repair

Take the commutative finite tracial algebra

    M = ell_infinity(N x {+,-}),
    tau(f)=sum_{j>=1} 2^(-j) [f(j,+)+f(j,-)]/2,

and reference `B=1`. Let `a_j=1/(j+2)` and let `phi` act on each pair by the symmetric stochastic matrix with diagonal `1-a_j` and off-diagonal `a_j`. This is unital, trace preserving and completely positive; it is strict CPTP because it is unital. It is self-adjoint on `L2(tau)`. Its Petz map for `B=1` is `R=phi`, so `T=R phi=phi^2`.

On the normalized sign vector supported on pair `j`, `T` has eigenvalue `(1-2a_j)^2<1`, approaching one. Its fixed space consists of functions constant in each pair; let `P` average within each pair. Then

    ||T^n-P||_{2->2} = sup_j (1-2a_j)^(2n) = 1,   n>=1.       (M11)

Powers converge strongly to `P` by dominated convergence, but not in operator norm. This contradicts Bhattacharya's Theorem 1 under its stated hypotheses. The source's false step is explicit: a nonzero fixed space of a positive contraction does not force one to be isolated.

With the additional assumption `spec(T|Fix(T)^perp) <=1-gamma`, spectral calculus repairs the norm rate to `(1-gamma)^n`, and gives in the weighted Petz Hilbert space

    ||A-PA||_{B,2}^2 <= gamma^(-1)
            [||A||_{B,2}^2 - ||phi A||_{phi B,2}^2].           (M12)

Noncommutative Holder gives `||A-PA||_1 <= ||A-PA||_{B,2}` when `tau(B)=1`. This is a useful conditional-sufficiency projection estimate once the gap and weighted square-integrability are given. An entropy budget does not automatically control the required chi-square deficit, nor has a game-derived complete spectral gap been proved. Iterated recovery is therefore not an automatic answer to correlated nuisance subtraction.

## 7. Existing compiler bridge and exact limitation

Lin's question/answer-reduction compiler provides a concrete route from repetition to succinct verification. Direct products preserve synchrony and perfect oracularizability by tensor products. Their CL samplers compose in parallel at the same depth; anchoring is what adds a depth level. Accepted N443 gives target soundness `delta` using

    n >= 2^75 (epsilon+log(|A||B|)) epsilon^(-3) log(1/delta).

Its small-gap exponent improves the anchored comparator's power 17 inside that particular stage. This is an application of the capital with explicit compiler hypotheses, not a new complexity classification, efficient physical construction or demonstrated practical advantage.

A threshold game ceases to be synchronous: equal full questions may receive unequal answer strings yet pass. Forcing exact equality on the global diagonal only decreases acceptance and preserves ideal perfect synchronous completeness. Robust honest completeness through answer reduction still needs its own quantitative proof.

## 8. Zenodo audits actually checked

Record `22061117` was fetched via the public API and its six-page PDF fully text-extracted and read. It is Nicholas Micah Taylor's August 2026 audit of an earlier OpenAI tensor repetition report. Its claimed contradiction between a polynomial upper bound and a stronger exponential upper bound is invalid. Its quotations give no explicit game counterexample. A dimension objection needs a dimension-dependent final estimate; a uniform pointwise estimate passes directly to the supremum. Unfamiliarity of techniques or weak constants is not a contradiction. Its model-clarity and noncommutative-conditioning questions still require proof-level checks; the retained resolvent source explicitly uses finite classical-question averages. This reading is not external certification of the full theorem.

Record `22060622` returned HTTP `410 GONE` from the API and was inaccessible through the web reader. It remains unread and uncleared. Metadata/PDF/text for the readable audit are cached in `../machinery/sources/`.

## 9. Ledger

| Claim | Status |
|---|---|
| Conditional entropy / CMI identity | Proved; established identity |
| Entropy cancellation of a retained common label, including question correlations | Proved |
| Parent block-event domination and budgets (M5)–(M8) | Proved elementary construction, for challenge |
| Full ordered-register construction / tensor quadratic theorem | Concrete candidate pending hostile bookkeeping check |
| Arbitrary finite-tracial/commuting `FR(K)` | Open; exact-marginal and compatible-local-correction transfer missing |
| General quadratic repetition | Open |
| Uniform iterated-Petz operator-norm convergence under cited 2026 hypotheses | Disproved by (M11) |
| Spectral-gap repaired estimate (M12) | Proved conditional Hilbert theorem |
| Anchor-free CL amplifier resource substitution | Application of accepted capital and established compiler |
| Quantum PCP / local Hamiltonian / practical or physical advantage / historical priority | Not established |

No published manuscript, public release, website or other researcher's files were edited.
