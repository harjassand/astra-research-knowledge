# Supporting record: commuting amplification bridges

7 November 2026. This record supports the
[consolidated research dossier](../COMMUTING_AMPLIFICATION_BRIDGES_RESEARCH_DOSSIER.md)
and [machine-readable theorem ledger](../COMMUTING_AMPLIFICATION_BRIDGES_THEOREM_LEDGER.json).
Their final statements govern scientific status. An earlier candidate or
conditional statement below is retained as research history, not silently
promoted or erased.

## Independence and challenge

The four frozen initial reports are [principal](initial/principal.md),
[machinery](initial/machinery.md), [constructor](initial/constructor.md), and
[auditor](initial/auditor.md). Three GPT-6.1 Sol researchers at maximum reasoning
worked independently of one another and the principal until these reports were
written. The same three were subsequently reused for cross-challenge and final
review; no additional researchers were spawned.

The final reviewers pinned the pre-correction dossier SHA256
`39513d26b9a8ec2128e4119337462ca71174568eec09f2fe56d9c4edfe89ac64`.
Their reports are [machinery](challenges/machinery_final_dossier_review.md),
[constructor](challenges/constructor_final_dossier_review.md), and
[auditor](challenges/auditor_final_dossier_review.md). The principal incorporated
their explicit-hypothesis, quantifier and citation corrections. The root
`FINAL_REVIEW.json` records the final file hash and the exact disposition of
each correction. These are internal mathematical checks with named scopes;
they do not establish historical priority or physical advantage.

## Completed reconstruction proof, in dependency order

1. [Common retained labels and exact entropy cancellation](machinery/common_label_register_proof.md).
   This initially treats blocks and records the whole-workspace history
   construction. Its block-only scope is superseded by the charged proof below.
2. [Positive operator parent matrices and finite-ancilla embedding](machinery/finite_tracial_parent_matrices.md).
   No partial trace over an infinite commutant is used.
3. [Finite-tracial local description transfer](machinery/finite_tracial_transfer_candidate.md).
   The filename retains its initial candidate status; the completed proof is
   in dossier §§3–4 with the next common-amplification lemma.
4. [Explicit common amplification and local polar corrections](machinery/common_amplification_lemma.md).
5. [Parity challenge and unconditional question drift](machinery/fresh_history_parity_challenge.md).
   Histories stay inside the prepared output workspace.
6. [Principal one-sided construction](challenges/principal_one_sided_rectangle_candidate.md),
   [auditor challenge](challenges/auditor_one_sided_rectangles.md),
   [constructor challenge and checks](challenges/constructor_one_sided_rectangles.md),
   and [machinery review](machinery/charged_rectangle_reconstruction_review.md).
   One common square-root-weighted target is compared to two separately
   normalized positive one-sided parents.
7. [Actual-mass refinement](machinery/actual_one_sided_mass_reconstruction.md)
   and [continuous finite-table identity](machinery/actual_mass_table_identity.md).
   Earlier doubts about the actual-mass Lin passage are resolved by the exact
   finite-table marginal formula. Only scalar quantities pass the closure.
8. [Minimal dependencies](machinery/MINIMAL_PROOF_DEPENDENCIES.md).
   The old resolvent and separate posterior-history constructions are
   unnecessary. The actual sampler, the trace inequality and Lin remain.
9. [Quadratic block theorem](machinery/QUADRATIC_BLOCK_THEOREM.md).
   The dossier adds the independent tensor-gap proof, full charged statement,
   and line-game gap-power optimality at their exact scopes.
10. [Earlier scalar all-wins proof](prior-scalar-proof/constructor_cross_review.md)
    and [weighted threshold audit](prior-scalar-proof/auditor_weighted_threshold_review.md).
    Their conditional premise is now proved; their scalar assumptions and
    constants are retained, and the principal deduction is reprinted in §6.

The decisive inherited sampler is [sampler.txt](inherited-source/sampler.txt),
with [precision addendum](inherited-source/sampler_precision.txt) and
[toy/endpoints addendum](inherited-source/sampler_toy.txt). These are the user's
governing proof sources, reproduced with source pins. In particular, Section 8
provides an actual rare-losing-event estimate for the same operational POVMs.
A generic mean-total-variation sampler is not interchangeable with it.

The prior paper's [games module](inherited-source/prior-published-games.tex)
is copied unchanged to pin the exact earlier FR hypothesis. It is a source
fragment for dependency inspection, not a standalone new manuscript.

## Interactive channel bridge and executable construction

The [principal Rényi proof](challenges/principal_renyi_bridge.md) is challenged in
the [auditor review](challenges/auditor_renyi_bridge.md) and
[constructor review](challenges/constructor_renyi_audit.md).
The [exact erasure/source examples](challenges/constructor_renyi_examples.md)
include explicit cost accounting and existing coding comparators.

Finite-order Rényi statements concern ordinary finite-dimensional protocols
with prescribed memoryless channel slots and question-independent initial
resources, or the separately charged source extension. The broader commuting
start is covered only by the stated maximum-order local-instrument theorem.
No uncharged control messages, timing or routing are allowed.

[linear_erasure_protocol.py](constructor/linear_erasure_protocol.py) is a
standalone Python logical simulation of ideal dense coding followed by a
random linear code. It requires no exponential codebook. For example:

```sh
python3 constructor/linear_erasure_protocol.py --help
```

The artifact is not a quantum hardware experiment. Its
[retained run](constructor/linear_erasure_demo.json) and decoder checks are
diagnostics alongside, not substitutes for, the coding proof.

## Obstructions, predecessors and finite diagnostics

The [independent labelled-mixture transfer](auditor/HETEROGENEOUS_TRANSFER.md)
uses original iid capital alone. [Correlated nuisance cancellation](auditor/CORRELATED_NUISANCE.md)
and [local compiler obstructions](auditor/LOCAL_COMPILER_OBSTRUCTIONS.md) retain
their exact topology, ancilla and computability restrictions. Dossier §§10–12
state the repaired and disproved claims, exact primary-source imports,
priority limits and remaining constructive attacks.

The diagnostic scripts and their retained JSON results include noncommuting
fractional partitions, tilted-average identities, common-label negative
controls, channel amortization with different input states, exact rational
exponents, decoder/rank tests and frozen initial hashes. The principal's
[final proof checks](challenges/principal_final_proof_checks.md) and
[arithmetic/provenance receipt](checks/principal_final_checks.json) distinguish
written proofs from finite checks.

`source-pins/` and the researchers' source manifests record primary URLs,
versions and cached hashes. Third-party full articles remain in the read-only
workspace caches and are not redistributed in this package. Historical source
manifests may refer to those original `work/` paths; they are not claims that
all such article files are in this archive.

`MANIFEST.json` inventories the final supporting record and hashes the governing
dossier and theorem ledger. Researchers' earlier branch manifests retain their
own historical scopes and are not final-package receipts.
