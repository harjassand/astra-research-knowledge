# Completed common-output reconstruction and quadratic block repetition

7 November 2026. This is the consolidated outcome of the existing-machinery branch. Initial report SHA256: `c0da194c7c94e2ed40220d10494cfcc520760280368230cc398a4a980ba2409d`, unchanged. The hostile auditor independently reconstructed and passed the retained-copy parent/coordinate construction and finite-tracial local-preparation proof in:

- `../challenges/auditor_common_label.md`;
- `../challenges/auditor_finite_tracial_transfer.md`.

This is a completed internal mathematical check at those exact scopes. Historical priority, external review and efficient implementation are separate claims and are not asserted.

## Formal theorem

Let G be a finite two-player Boolean game. Suppose that for every supported question pair its winning answer graph is a disjoint union of vertex-disjoint complete bipartite blocks, with isolated vertices allowed. Put epsilon=1-omega_co(G). Then, for every integer n>=1,

    omega_co(G^n)<=exp(-2^(-75) epsilon^2 n).                  (Q1)

The quantifiers permit arbitrary correlated within-round questions and arbitrary joint commuting strategies across independent repetitions. The theorem includes noninjective and partial one-way projection predicates. No optimizer, finite-matrix approximation, uniform dimension bound or efficiency is assumed.

There is also the distinct tensor statement with its own gap: if epsilon_star=1-omega_*(G), then `omega_*(G^n)<=exp(-2^(-75)epsilon_star^2 n)`. It is not inferred by substituting epsilon_star into Q1. Start with each finite tensor strategy, represented in standard form over a full matrix algebra after padding. All comparison, amplification and finite-trial sampler algebras then remain full finite matrix algebras, whose left/right standard form is an actual finite tensor resource. The extracted strategy is consequently tensor, so its loss is bounded below by epsilon_star. Run the same pointwise greedy argument and only then take the finite-dimensional supremum. This independently supplies the tensor projection comparison to DSV without equating omega_* and omega_co.

More generally, for an independent heterogeneous family of such games, every joint finite-tracial product-strategy table and every positive-probability proper tested event E_D, there are coordinate reconstruction costs satisfying

    sum_{i notin D} t_i <=3 log(1/p_D),                       (Q2)

with legal single-game commuting witnesses, for every positive accuracy, of loss at most

    alpha_i(D)+K[sqrt(alpha_i(D)) t_i^(1/4)+sqrt(t_i)]
        +accuracy,       K=65536.                            (Q3)

Each witness has one input-independent resource and complete commuting POVMs on every local input pair. Different i may use different resources. This proves the **disjoint-block instance** of FR(K), not the arbitrary charged/non-block hypothesis in the public paper.

## The decisive proof operation

The tested block event is equality of local labels k_A,k_B. Three copied labels per party separate external shared target histories from a private own-label copy retained inside each parent. Every external cross-created copy is traced from the comparison parents, so Bob's isometry genuinely disappears from Alice's parent and conversely. Both coordinate pure targets are partitions of one accepted vector.

In each private k block the selected parent is bounded by its preselection parent: at fixed y the difference is a positive congruence of I-Q_y,k. Thus p_c rho_A,c<=sigma_A,c, and similarly Bob. Donald's two-marginal identity gives

    E_k[D(rho_k||sigma)-D(rho_k^K||sigma^K)]
      =D(rho||sigma)-D(rho^K||sigma^K)+I(k:R|K).

The last term is zero because the private orthogonal copy in K determines k. This cancels common-label entropy even when the label depends on live questions. Averaging c and applying complementary ordered chain rules gives sum_i b_A,i<=log(1/p_D), sum_i b_B,i<=log(1/p_D). Ordinary postselection gives sum_i d_i<=log(1/p_D), where d_i is the **unconditional** coordinate question divergence. Set t_i=b_A,i+b_B,i+d_i.

Histories remain inside the pure target workspace. They are not independently sampled from a posterior marginal. The exact H-kernel identity

    D(Q_i^{RXY}||mu_i P_A(R|X))
      =d_i+I(Y:R|X)<=d_i+b_A,i

and its Bob counterpart handle question-dependent histories. The principal's parity fixture passes exactly by sharing the outside bits and computing parity from each player's equal fresh bit.

## Exact finite-tracial operational bridge

The four-log inequality follows from Junge–LaRacuente, arXiv:2009.11866v2, Theorem 1.2, specialized to finite trace, p=2 and half-logarithms. It gives Jain's exact-marginal comparison replacement when densities are boundedly invertible. Mix both states with one faithful conditional comparison at positive delta. Joint convexity and lower semicontinuity make full and retained divergences converge separately. Every delta uses bounded inverse powers; no inverse limit or normal-state compactness claim is needed. Fidelity continuity gives arbitrary positive-slack alignment to the original target.

Rows of the square root of the comparison seed produce local vectors chi_x in one M_|X|(N). At fixed y, the coherent target/comparison matrices A_y,B_y have fidelity ||A_y^*B_y||_1. The polar optimizer of B_y^*A_y acts on purifier columns by right multiplication, independently of the external coherent X row. Alice's polar correction is left multiplication in the same finite amplification. The transported Bob effect is U_y^* B_y U_y; unitary completions keep every fine POVM complete on all input pairs. Holder with exponents 4,2,4 gives the needed affinity/fidelity comparison and descriptor cost at most 4(b_A+b_B)+vanishing slack.

The actual inherited S_actual Section 8 (SHA256 `f37b03a0a84487328c4d1b96b30bbc03468e085bef5593a635126775310beb2b`) supplies real unconditional left/right POVMs and its same-protocol rare-event estimate. It gives (Q3) with K=65536 conservatively. This is not a trace-preserving output-channel claim on the original algebra. All resource parameters remain finite-family, spectrum and accuracy dependent.

For arbitrary commuting tables eliminate t_i into the continuous scalar Phi_K deficit before applying Lin 2304.01940v3 Theorem 3.2 at fixed positive p_D. Only finite table probabilities and conditional losses are passed to the limit; no descriptors, algebras or raw costs converge. This proves the block scalar budget for arbitrary commuting strategies.

## All-finite-length proof of Q1 and its constant

Fix a table with all-wins probability theta>exp(-gamma epsilon^2 n), gamma=2^(-75), and let L=log(1/theta). Greedily test a coordinate of conditional loss greater than epsilon/2 while the mean remaining loss exceeds epsilon/2. Every test raises log inverse success by at least epsilon/2. Since all-wins is contained in every tested event, fewer than 2L/epsilon<n/2 coordinates can be tested. The process stops properly with m>=n/2, p_D>=theta and mean live loss alpha<=epsilon/2.

Mix the live coordinate witnesses using a shared uniform index. Cauchy–Schwarz and Jensen bound its loss by

    alpha+K[sqrt(alpha)(E t_i)^(1/4)+sqrt(E t_i)]

at arbitrarily small positive accuracy. Q2 gives E t_i<=3L/m<6gamma epsilon^2. Hence the limiting loss divided by epsilon is at most

    1/2+K(6gamma)^(1/4)/sqrt(2)+K sqrt(6gamma)<1.

Indeed 6gamma<2^(-72), so the two error terms are below 1/(4sqrt(2)) and 2^(-20). Sufficiently small finite accuracy preserves the strict inequality, contradicting the base gap. This proves Q1 pointwise and then for the supremum. Zero gap or zero all-wins probability is trivial. No asymptotic-length or attained-optimum assumption occurs.

## Proof record and checks

Detailed derivations: `common_label_register_proof.md`, `finite_tracial_parent_matrices.md`, `fresh_history_parity_challenge.md`, `finite_tracial_transfer_candidate.md`, `common_amplification_lemma.md`. The historical word candidate in filenames is retained to preserve provenance; the separate audit records the completed disposition.

Forty-eight noncommuting noninjective-projection controls checked parent order, exact event mass and CMI cancellation, with maximum cancellation residual 1.39e-15. Omitting the required dephasing failed parent order in all 48 negative controls. These validate orientation; general proofs establish the theorem. See `check_common_label_budget.py` and `common_label_checks.json`.

## Predecessors and limits

KRT 0710.0655v3 Theorem 5.2 already gives (1-epsilon^2/16)^n for unique games. DSV 1310.4113v2 Theorem 1 gives a general projection gap power at most 12 and **optimal linear gap for expanding games**; v1's weaker expanding comparison is outdated. Song ECCC TR26-199 and Jain 2610.21410v1 give the general cubic comparison. Jain's conditional-comparison and marginal-replacement construction is a load-bearing predecessor; this branch is not claiming to invent those entropy identities. No primary source located in the current search states the full quadratic block/projection conclusion, but absence of hits is not priority clearance.

The previous scalar heterogeneous all-wins and weighted-threshold proofs may now be applied unconditionally to the block class through Q2–Q3. General charged masks and general all-predicate quadratic repetition remain open. No quantum PCP, local Hamiltonian compiler, new MIPco classification, bounded finite-dimensional realization or physical advantage is established.

Subsequent same-day strengthening: the principal's two separate one-sided comparison parents close the general **charged** FR premise as well, as proved in `charged_rectangle_reconstruction_review.md` and audited independently in `../challenges/auditor_one_sided_rectangles.md`. The preceding open-status sentence records the earlier block-stage boundary. General all-predicate **quadratic** repetition remains open. The actual one-sided-mass scalar refinement and its finite-table continuity are developed in `actual_one_sided_mass_reconstruction.md` and `actual_mass_table_identity.md`; minimal proof dependencies are recorded in `MINIMAL_PROOF_DEPENDENCIES.md`.

Separately, initial Section 6 gives an explicit strict-CPTP counterexample to the operator-norm recovery claim in Bhattacharya 2605.08829 Theorem 1. Its spectral-gap repair is valid but is not used by Q1. Zenodo audit 22061117 was read; record 22060622 returned 410 and remains unread. Source HTML/hash manifest is in `sources/primary_manifest.json`.
