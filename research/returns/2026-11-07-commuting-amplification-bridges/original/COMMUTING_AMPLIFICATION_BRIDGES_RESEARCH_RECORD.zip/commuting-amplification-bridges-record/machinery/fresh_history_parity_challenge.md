# Response to the principal's parity-history challenge

7 November 2026. The challenge is valid against conditioning on a shared history and then paying its conditional question divergence. The present construction must instead prepare the **whole question-indexed history family**. Here are its exact laws, comparisons and resource quantifiers.

## Exact target law

Write r0=(c,y_{J<i},x_{J>i}) for the original unconditioned exposure and k for the successful common block label. Let nu_i(r0) be its original product-referee probability. For fixed fresh pair (x,y), average over the still unexposed questions under their original conditional referee kernels. Let h_{i,r0,k}(x,y) be the resulting probability of tested acceptance in common block k under the original joint strategy. Then

    Q_i(r,x,y)=nu_i(r0) mu_i(x,y) h_{i,r0,k}(x,y)/p_D,
    r=(r0,k).                                                (H1)

This is the actual event-conditioned history/question law. Including the fine live answers in the same expression gives the exact original conditional answer table. The construction does not assert that Q_i factors as Q_R tensor mu_i.

Let q_i(x,y)=sum_r Q_i(r,x,y) and d_i=D(q_i||mu_i). This is the **unconditional coordinate marginal** divergence. Product-referee postselection gives sum_i d_i<=log(1/p_D). In general

    sum_i E_R D(Q_i^{XY|R}||mu_i)

has no such bound and is never used here.

## One pure family with histories inside the workspace

The accepted global vector and its complementary exposed-question copies give, for each fixed fresh pair (x,y), the normalized pure vector

    psi_i,xy = sum_r sqrt(Q_i(r|x,y)) |r>^{H_A}|r>^{H_B}
                                      psi_i,r,xy^{A_i^0 B_i^0}. (H2)

All phases and residual vectors come from that same accepted vector; there is no independent choice of Alice versus Bob targets. Set A_i=H_A A_i^0 and B_i=H_B B_i^0. Their finite-tracial counterparts are the identical finite-copy algebraic construction. The local-preparation theorem is applied to (H2) as a family indexed only by x and y, with q_i as its question law. It is not applied separately at fixed r followed by an invalid change from Q_i^{XY|r} to mu_i.

The resulting resource depends on the finite target family, original strategy, D and desired accuracy; it is fixed before the realized fresh (x,y). Alice's description and complete POVM depend only on x, Bob's only on y. Shared history is an output within their reconstructed workspace, allowed to depend on the appropriate local fresh question.

## Both comparison families

At each fixed tested c the preselection parent sigma_A,c is obtained by tracing Bob's entire physical isometry and every external label copy. Its only retained checked label is the Alice-created private copy. Hence

    sigma_A,c=C_{mu_J}(tau_A,c).

Take the normalized complementary restriction specified by r0, without conditioning the parent on common k. By the product conditional-amplitude identity this gives

    nu_A,c,r0=C_{mu_i}(tau_A,c,r0).

Restore the external history with the **target** weights:

    nu_A,i=sum_r Q_R(r)|r><r|^{H_A} tensor nu_A,c,r0.           (H3)

Its internal private local label remains the preselection random variable k_A. Only in the target is that private label fixed to the external k. Formula (H3) is itself a mu_i-conditional comparison, because its external classical history is part of A_i and the attachment map C_mu acts blockwise. Bob's comparison is

    nu_B,i=sum_r Q_R(r)|r><r|^{H_B} tensor nu_B,c,r0,           (H4)

using the reverse complementary restriction. Both are comparisons for the same target (H2).

For clarity their ordinary measured reference laws have form

    nu_A,i(r,x,y)=Q_R(r) s_A,c,r0(x) mu_i(y|x),
    nu_B,i(r,x,y)=Q_R(r) s_B,c,r0(y) mu_i(x|y),

where s_A,s_B are the normalized preselection restricted local-question laws. They are not the posterior question distributions conditioned on r. The conditional entropy differences may contain large full and retained marginal divergences, which cancel exactly. That cancellation is why the conditional question divergence of a fixed history is the wrong cost.

The retained-record identity gives

    b_A,i=sum_r Q_R(r)[D(rho_A,i,r||nu_A,c,r0)
                         -D(rho_A,i,r^{X A_i^0}||nu_A,c,r0^{X A_i^0})].

Jain's ordered chain rule makes its sum telescope to the answer-free parent budget. The corresponding Bob identity is simultaneous. This is the quantum calculation behind the initial M9 statement.

## The H coupled kernels incur no spurious conditional drift

The history coordinate R is a finite classical output inside the target workspace. The conditional-comparison data-processing inequality gives

    I_Q(Y:R|X)<=b_A,i,    I_Q(X:R|Y)<=b_B,i.

Define local kernels P_A(r|x)=Q_i(r|X=x), P_B(r|y)=Q_i(r|Y=y), with arbitrary completions on zero-mass inputs. The exact elementary identities are

    D(Q_i^{RXY} || mu_i^{XY} P_A^{R|X})
       =d_i+I_Q(Y:R|X),
    D(Q_i^{RXY} || mu_i^{XY} P_B^{R|Y})
       =d_i+I_Q(X:R|Y).                                    (H5)

Thus Pinsker bounds the two local-history law discrepancies by square roots of d_i+b_A,i and d_i+b_B,i. These are H's **input-dependent** kernels. A shared exponential-race coupling chooses a history from each local kernel using shared randomness fixed before inputs. It gives complete local rules on every input pair, with mismatch controlled by their actual discrepancy; it does not presample R independently of the fresh questions.

The global descriptor/sampler proof can reconstruct the history registers together with all fine observables, so it does not require a separate H step. Equation (H5) nevertheless explicitly verifies that the standard H interface pays no averaged conditional-question penalty.

## The parity fixture

Take m independent uniform bits with X_j=Y_j. Let the certain accepted block label be k=parity(X_J). With r0 containing all m-1 exposed bits except the fresh one,

    Q_i(r0,k,x,y)=2^(-m) 1{x=y} 1{k=x xor parity(r0)}.        (H6)

The fresh marginal is exactly mu_i, so d_i=0. Conditioned on the full history r=(r0,k), x is determined; hence the principal's conditional divergence is ln 2 per coordinate. That quantity is irrelevant to (H5).

Both local kernels in (H5) are uniform over r0 with k determined by the local fresh bit. On every supported x=y they are identical. Preshare uniform r0, and let each player compute k=local_bit xor parity(r0). This is an exact question-independent-resource implementation of (H6), with no history mismatch. The quantum conditional entropy charges are zero: the protected question references are already functions of the retained local question controls, and the full and retained marginal divergences cancel. The local preparation theorem accordingly permits zero error in the infimum, with all-input completions off the diagonal.

Therefore the parity fixture confirms the necessity of global workspace preparation and unconditional d_i; it does not obstruct the corrected construction. A proof which conditioned on r and then paid D(Q_i^{XY|r}||mu_i), or independently sampled the posterior r, would fail this test.
