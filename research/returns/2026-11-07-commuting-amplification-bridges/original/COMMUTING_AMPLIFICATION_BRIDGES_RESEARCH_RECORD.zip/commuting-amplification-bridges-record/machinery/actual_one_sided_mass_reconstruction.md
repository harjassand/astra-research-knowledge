# Stronger one-sided references normalized by their actual mass

7 November 2026. Follow-up to the principal's charged-rectangle construction. **Claim for independent review:** the reference seed need not come from a complete local isometry. The audited local-description theorem permits any normalized positive conditional-comparison seed with matching-copy support. Normalize the one-sided seed by its actual trace instead of a maximum row load. The physical completed-parent proof remains a valid simpler route to full charged FR.

Fix tested questions c and the common sqrt(w_l) target. Define the unnormalized positive Alice seed S_A,c by its private-l blocks and row indices (x,a):

    [S_A,c]_{l;x,a;x',a'}
      =w_l sqrt(mu_X(x)mu_X(x')) r_l(a_D)r_l(a_D')
                                  A_xa sigma^2 A_x'a'.

Its trace is

    G_A,c=sum_l w_l E_{X_J} sum_{a:r_l(a_D)=1}
                                      tau(sigma^2 P_a^{c_A,X_J}).

The full comparison form C_muJ(S_A,c) has the same trace. The direct positive congruences of I-Q_y,T_l give

    p_c rho_A,c<=C_muJ(S_A,c).

Thus G_A,c>=p_c>0 on successful c. Set sigma_A,c=C_muJ(S_A,c)/G_A,c. This is a normalized conditional comparison. Its local X law is tilted, which the comparison definition explicitly permits; it still attaches the original mu(Y|X), and its X support remains inside supp(mu_X).

Nothing in the preparation theorem requires a physical local operation producing that comparison from the original resource. It only requires this normalized conditional form. The comparison's standard-form purification, coherent local corrections and actual sampler subsequently produce the legal fixed resource. The target itself, including all fine probabilities, is unchanged.

Bob's separate one-sided seed is normalized by

    G_B,c=sum_l w_l E_{Y_J} sum_{b:t_l(b_D)=1}
                                      tau(sigma^2 Q_b^{c_B,Y_J}).

It obeys p_c rho_B,c<=G_B,c sigma_B,c and compares to the same target. These are exactly the old actual one-sided masses, now entering an operational reconstruction proof rather than an unproved sampler assertion.

Private-label Donald cancellation gives parent costs at most log(G_A,c/p_c) and log(G_B,c/p_c). They are nonnegative even if G_A,c or G_B,c is below one. Put p=P(E_D)>0, L=log(1/p), Q_C(c)=mu_D(c)p_c/p, and G_A=E_muD G_A,c, G_B=E_muD G_B,c. Then

    E_Q log(G_A,c/p_c)
      =L-D(Q_C||mu_D)+E_Q log G_A,c <=L+log G_A.

This follows by the Gibbs variational bound; successful c have G_A,c>0, and zero-success c can be handled by positive regularization. Bob is symmetric. Ordered allocation and unconditional question drift yield

    sum_i t_i<=3L+log(G_A G_B).                              (W*)

The same K=65536 coordinate loss witnesses follow. All normalizations are finite at fixed successful c and target accuracy; no uniform resource bound is inferred.

Completeness bounds G_A,c<=A_c and G_B,c<=B_c. Product partitions give G_A<=product_j a_j, G_B<=product_j b_j. Hence (W*) implies exactly 3L+2sum_j kappa_j, with no doubled weights or charges.

This does not prove uniformly small G_A,G_B or general quadratic repetition. Independent nuisance increments can cancel more strongly than this endpoint estimate. Existing positive-mass obstructions remain intact.

Scope correction after this first derivation: the fixed-partition actual G quantities ARE continuous finite-table functionals, via the ordinary one-sided answer marginals. Their exact identity and the consequent direct Lin transfer are proved in `actual_mass_table_identity.md`. The raw entropy costs and descriptors, rather than these G quantities, remain representation-dependent. Thus the strengthened scalar deficit estimate passes to arbitrary commuting tables at fixed positive tested mass; no added uniform mass hypothesis is needed merely for that passage. A general quadratic conclusion still needs a separate quantitative small-mass or direct-increment bound.
