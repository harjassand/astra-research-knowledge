"""Noncommuting finite tensor diagnostics for the common-label parent proof.

These verify orientation and support on random controls, not the general proof.
The tested projection is noninjective: Alice labels 0,1 map to Bob 0; 2 to 1.
Both parties use arbitrary joint question-string unitary measurements.
"""
from pathlib import Path
import json
import numpy as np

RNG = np.random.default_rng(7112026)
MU = np.array([[.17, .23], [.11, .49]])


def block_diag(*blocks):
    size = sum(a.shape[0] for a in blocks)
    out = np.zeros((size, size), dtype=complex)
    start = 0
    for a in blocks:
        stop = start + a.shape[0]
        out[start:stop, start:stop] = a
        start = stop
    return out


def unitary(d):
    z = RNG.normal(size=(d, d)) + 1j * RNG.normal(size=(d, d))
    q, r = np.linalg.qr(z)
    return q @ np.diag(np.diag(r) / np.abs(np.diag(r)))


def herm(a):
    return (a + a.conj().T) / 2


def drel(rho, sigma):
    rho, sigma = herm(rho), herm(sigma)
    es, us = np.linalg.eigh(sigma)
    support = es > 1e-11
    nullmass = np.trace(us[:, ~support].conj().T @ rho @ us[:, ~support]).real
    if nullmass > 2e-9:
        raise ValueError(f"Unsupported target mass {nullmass}")
    er = np.linalg.eigvalsh(rho)
    term = np.sum(er[er > 1e-12] * np.log(er[er > 1e-12]))
    logs = (us[:, support] * np.log(es[support])) @ us[:, support].conj().T
    return float(term - np.trace(rho @ logs).real)


def retained(blocks, da):
    # Trace protected hat-X: keep physical X, dephase x != x', then forget hat-Y.
    z = np.zeros((2 * da, 2 * da), dtype=complex)
    for block in blocks:
        for x in range(2):
            sl = slice(x * da, (x + 1) * da)
            z[sl, sl] += block[sl, sl]
    return z


def trial():
    da, db = 6, 4
    eta = RNG.normal(size=(da, db)) + 1j * RNG.normal(size=(da, db))
    eta /= np.linalg.norm(eta)
    rhoa = eta @ eta.conj().T
    ua = [unitary(da) for _ in range(2)]
    vb = [unitary(db) for _ in range(2)]
    alabel = np.repeat([0, 0, 1], 2)
    blabel = np.repeat([0, 1], 2)
    pa = [np.diag(alabel == k) for k in range(2)]
    pb = [np.diag(blabel == k) for k in range(2)]
    sigma = []
    sigma_undephased = []
    raw = [[None, None], [None, None]]
    law = np.zeros((2, 2, da, db))
    for y in range(2):
        s = np.zeros((2 * da, 2 * da), dtype=complex)
        sn = np.zeros_like(s)
        targets = [np.zeros_like(s) for _ in range(2)]
        selected = [[pa[k] @ ua[x] @ eta @ vb[y].T @ pb[k]
                     for x in range(2)] for k in range(2)]
        for x in range(2):
            coeff = ua[x] @ eta @ vb[y].T
            law[x, y] = MU[x, y] * np.abs(coeff)**2
            for xp in range(2):
                sl = slice(x * da, (x + 1) * da)
                sp = slice(xp * da, (xp + 1) * da)
                factor = np.sqrt(MU[x, y] * MU[xp, y])
                base = factor * ua[x] @ rhoa @ ua[xp].conj().T
                sn[sl, sp] = base
                s[sl, sp] = sum(p @ base @ p for p in pa)
                for k in range(2):
                    targets[k][sl, sp] = factor * selected[k][x] @ selected[k][xp].conj().T
        sigma.append(s)
        sigma_undephased.append(sn)
        for k in range(2):
            raw[k][y] = targets[k]
    fulls = block_diag(*sigma)
    rets = retained(sigma, da)
    probs = np.array([sum(np.trace(b).real for b in raw[k]) for k in range(2)])
    p = probs.sum()
    parent = sum(block_diag(*raw[k]) for k in range(2)) / p
    parent_ret = sum(retained(raw[k], da) for k in range(2)) / p
    avg_deficit = 0.
    for k in range(2):
        r = block_diag(*raw[k]) / probs[k]
        rr = retained(raw[k], da) / probs[k]
        avg_deficit += probs[k] / p * (drel(r, fulls) - drel(rr, rets))
    aggregate_deficit = drel(parent, fulls) - drel(parent_ret, rets)
    accepted = alabel[:, None] == blabel[None, :]
    direct_p = np.sum(law * accepted[None, None])
    domination = np.linalg.eigvalsh(herm(fulls - p * parent)).min()
    negative_control = np.linalg.eigvalsh(herm(block_diag(*sigma_undephased) - p * parent)).min()
    return {
        "p": float(p),
        "mass_error": float(abs(p - direct_p)),
        "preselection_trace_error": float(abs(np.trace(fulls).real - 1)),
        "parent_order_min_eigenvalue": float(domination),
        "avg_conditional_deficit": float(avg_deficit),
        "log_inverse_p": float(-np.log(p)),
        "CMI_cancellation_residual": float(abs(avg_deficit - aggregate_deficit)),
        "omitted_dephasing_control_min_eigenvalue": float(negative_control),
    }


def main():
    records = [trial() for _ in range(48)]
    for r in records:
        assert r["mass_error"] < 1e-10
        assert r["preselection_trace_error"] < 1e-10
        assert r["parent_order_min_eigenvalue"] > -1e-10
        assert r["avg_conditional_deficit"] >= -1e-9
        assert r["avg_conditional_deficit"] <= r["log_inverse_p"] + 1e-9
        assert r["CMI_cancellation_residual"] < 1e-9
    summary = {
        "trials": len(records),
        "max_mass_error": max(r["mass_error"] for r in records),
        "max_CMI_cancellation_residual": max(r["CMI_cancellation_residual"] for r in records),
        "min_parent_order_eigenvalue": min(r["parent_order_min_eigenvalue"] for r in records),
        "negative_controls_violating_order": sum(r["omitted_dephasing_control_min_eigenvalue"] < -1e-7 for r in records),
        "status": "diagnostics_passed_not_general_proof",
    }
    assert summary["negative_controls_violating_order"] == len(records)
    out = {"summary": summary, "records": records}
    Path(__file__).with_name("common_label_checks.json").write_text(json.dumps(out, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
