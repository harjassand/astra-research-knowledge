# Direct finite-tracial parent matrices and finite-ancilla embedding

7 November 2026. This supplies the finite-von-Neumann parent domination without an illicit partial trace over an infinite right algebra.

Let (M,tau) be finite tracial and sigma in M bounded positive with tau(sigma^2)=1. The original strategy has left/right effects P_a^x,Q_b^y. Coherent fine-output vectors are

    v_{x,y,a,b}=(P_a^x)^(1/2) sigma (Q_b^y)^(1/2).

Their squared L2 norms equal the original fine probabilities. Fix tested questions c; let x,y be the full live strings, and k_A=f_c(a_D), k_B=g_c(b_D). Set A_xa=(P_a^{(c_A,x)})^(1/2) and Q_y,k=sum_{b:g_c(b_D)=k}Q_b^{(c_B,y)}. Each Q_y,k is an effect.

The Alice parent is a finite matrix over M, with row index (x,a), classical y blocks, and an extra dephased private k_A label. In its block k_A=k the entries are

    (S_{k,y})_{x,a;x',a'}
      =sqrt(mu_J(x,y)mu_J(x',y)) A_xa sigma^2 A_x'a',

where a,a' have label k. Losing-sentinel blocks complete the preselection parent. The formula follows by summing Bob's fine outputs and restricting to the left algebra, since

    sum_b A_xa sigma (Q_b^y)^(1/2)(Q_b^y)^(1/2) sigma A_x'a'
       =A_xa sigma^2 A_x'a'.

The selected common-k parent instead has entries

    (T_{k,y})_{x,a;x',a'}
      =sqrt(mu_J(x,y)mu_J(x',y)) A_xa sigma Q_y,k sigma A_x'a'.

The difference S_{k,y}-T_{k,y} is a congruence of I-Q_y,k by the operator-valued column with entries sqrt(mu_J(x,y)) A_xa sigma. It is positive in a finite matrix algebra over M. Therefore

    direct_sum_{k,y} T_{k,y} <= direct_sum_{k_A,y} S_{k_A,y}.

Ordinary finite matrix trace tensor tau gives p_c and one for the two sides. This is p_c rho_A,c<=sigma_A,c. Bob's calculation is the same in M^op, respecting the right representation's reverse multiplication. No same-algebra commutation of P and Q is assumed.

Form tau_A,c from the same matrices with sqrt(mu_J(x,y)mu_J(x',y)) replaced by sqrt(mu_{J,X}(x)mu_{J,X}(x')) and no y register. Then directly

    sigma_A,c=C_{mu_J}(tau_A,c).

This includes all Alice fine outputs and her private label. Thus the conditional-comparison form is exact at the density-matrix-over-M level. Finite classical-register restrictions and relative-entropy allocation apply in these finite matrix algebras, with no tensor-factor partial trace interpretation of M's commutant.

## A common standard form for finite target ancillas

For psi in C^dA tensor C^dB tensor L2(M), write psi=sum_ab |a>|b> tensor w_ab. Put N=M_dA tensor M_dB tensor M, using normalized matrix traces. The map

    psi -> sqrt(dA dB) sum_ab e_a1 tensor e_1b tensor w_ab

is an L2 isometry. Alice's finite matrix A embeds by left multiplication on the first factor. Bob's scalar finite matrix B embeds by right multiplication by B^T on the second. Original M acts left/right on the third factor. For operator-valued Bob matrices this means the canonical *-isomorphism from M_dB(M^op) to (M_dB(M))^op, transposing the matrix index and reversing the coefficient algebra together; it is not an unsupported positive partial transpose on M_dB(M). Thus positivity/completeness of finite-ancilla POVMs are preserved, and all left/right representatives commute on every input pair.

This embeds every finite history/fine-output register partition in the common-label construction into one finite amplification. Protected fresh-question copies stay outside for the entropy calculation; all target workspace registers are inside. Their finite number permits one algebra for the entire input family. A fixed different assignment of finite history copies between the parties is accommodated by this embedding without changing the original left/right M actions.

All entries from coherent POVM dilation and finite sums are bounded. Positive-slack regularization keeps later comparison square roots bounded too. The descriptor/corrected-POVM families therefore meet the inherited actual sampler's L2 contract; its finite-family approximation covers L2 vectors if needed. This gives no finite-matrix approximation of M and no efficient acquisition guarantee.
