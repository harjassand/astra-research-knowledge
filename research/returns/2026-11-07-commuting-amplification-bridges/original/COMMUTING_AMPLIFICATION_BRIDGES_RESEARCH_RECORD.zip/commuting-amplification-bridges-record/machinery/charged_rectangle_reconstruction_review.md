# Independent proof review: full charged reconstruction by one-sided completions

7 November 2026. Exposed follow-up reviewing the principal's `principal_one_sided_rectangle_candidate.md`. This is subsequent research; all independent initial reports remain unchanged.

**Disposition: the principal's construction is valid at the stated exact fractional-rectangle scope.** The two comparisons need not be marginals of one reference state. Only the pure target is common. This is precisely allowed by the already checked local-description theorem; its proof uses the Alice comparison for coherent alignment and the Bob comparison solely for the other marginal's variation. I reconstruct the algebra and cost below. General quadratic repetition does not follow: the positive presentation charge remains.

## 1. One exact common target

Fix tested questions c and an exact identity

    V_D(c,a_D,b_D)=sum_l w_l r_l(a_D)t_l(b_D),

where r_l,t_l are rectangle indicators, w_l>=0. Omit zero weights and empty rectangles. Let A_c,B_c>=1 bound the weighted row and column loads. In a finite tracial strategy let sigma be bounded positive with tau(sigma^2)=1 and put

    A_xa=(P_a^{(c_A,x)})^(1/2),
    B_yb=(Q_b^{(c_B,y)})^(1/2).

The target coefficient at fine outputs (a,b), live strings (x,y) and common label l is

    sqrt(mu_J(x,y)w_l/p_c) r_l(a_D)t_l(b_D) A_xa sigma B_yb.

Adjoin the original fine outputs in their own parties' registers and three copies of l on each side. Orthogonality of the fine and l registers and the exact rectangle identity imply unit norm and

    P_target(x,y,a,b)=mu_J(x,y)V_D(c,a_D,b_D)
                         tau(sigma P_a^x sigma Q_b^y)/p_c.

Thus every measured fine live table is the original conditional table exactly. The target may change coherences, which is harmless because the original argument only claims the declared fine table. It is a mathematical pure target, not an asserted local instrument preparing it.

Partition private and external l copies exactly as in the audited common-label construction. On every target branch both private labels equal the external l. The same target supplies both pure coordinate families and all fine POVMs.

## 2. Local one-sided completion exists in the original finite algebra

Alice's success coefficients, with fine a and label l retained, are

    C_x,a,l=sqrt(w_l/A_c) r_l(a_D) A_xa.

They satisfy

    sum_{a,l} C_x,a,l^* C_x,a,l
      =(1/A_c)sum_a [sum_l w_l r_l(a_D)] P_a^x <=I.

Add the failure coefficient

    C_x,fail=[I-sum C_x,a,l^* C_x,a,l]^(1/2).

This is a bounded element of M; it and the finitely many success coefficients give a complete local column isometry at every x. Distinct orthogonal failure records pad its output to the same ambient finite workspace. Every target failure amplitude is zero. At fixed c the map uses x only, even if c contains both tested question strings. Bob's analogous completion uses sqrt(w_l/B_c)t_l(b_D) B_yb in the opposite algebra, with the correct row orientation.

These are DIFFERENT preselection maps. Nothing requires the Alice-reference map and Bob-reference map to act together or to produce compatible reference marginals.

## 3. Direct type-II parent congruences

Use classical y blocks and matrix row indices (x,a) within each label l. Define

    (S_l,y^A)_{x,a;x',a'}
       =w_l sqrt(mu_J(x,y)mu_J(x',y))
                    r_l(a_D)r_l(a_D') A_xa sigma^2 A_x'a',

and

    (T_l,y^A)_{x,a;x',a'}
       =w_l sqrt(mu_J(x,y)mu_J(x',y))
                    r_l(a_D)r_l(a_D') A_xa sigma Q_y,T_l sigma A_x'a',

where `Q_y,T_l=sum_{b:t_l(b_D)=1}Q_b^y` is an effect. Then S_l,y^A-T_l,y^A is an explicit congruence of I-Q_y,T_l, hence positive in a finite matrix algebra over M. Alice's completed preselection parent has success block S_l,y^A/A_c and one additional positive failure block. The target's unnormalized parent has block T_l,y^A. Therefore

    p_c rho_A,c <= A_c sigma_A,c.                            (R1)

Trace of sigma_A,c is one by the completed local isometry. Summing target blocks has trace p_c by the exact mask decomposition. Replacing mu_J(x,y) by its X marginal defines the local seed; scalar conditional-amplitude attachment recovers sigma_A,c, so it has the exact original mu_J-conditional-comparison form. The failure branch is local and preserves this property.

Bob's construction gives the symmetric inequality in M^op,

    p_c rho_B,c <= B_c sigma_B,c.                            (R2)

This proves the type-II claim directly and avoids a nonexistent tensor-factor partial trace over the commutant. Noncommuting coefficients cause no issue because positivity is established by congruence, not entrywise multiplication.

## 4. Parent charge and the actual local-description assumptions

Every supported target l block is dominated by a finite multiple of its corresponding reference block; all required full divergences are finite. Since the target privately retains l, its ensemble CMI I(l:R_J|K_A) is zero. Donald's identity gives

    E_{l|c,E}[D(rho_A,c,l||sigma_A,c)
                 -D(rho_A,c,l^{K_A}||sigma_A,c^{K_A})]
      =D(rho_A,c||sigma_A,c)-D(rho_A,c^{K_A}||sigma_A,c^{K_A})
      <=log(A_c/p_c).                                      (R3)

The Bob bound is log(B_c/p_c). The target registers and fine positions are common to both; each comparison is separately conditional with the same prescribed mu_J. Those are all the local-description lemma's required relations between its inputs. Its proof never uses a common purification of the two comparisons: marginal replacement constructs chi_x from the Alice comparison; data processing of the separate Bob comparison bounds I(X:B|Y) of the SAME target. Both then meet in canonical marginals of that target. Hence separate one-sided parents satisfy the actual theorem hypotheses.

Restore external history labels with target weights while leaving the reference's internal l unconditioned. The audited ordered chain rule and global-workspace preparation apply unchanged. Every resource remains independent of the realized fresh pair. The parity-history challenge still uses unconditional d_i only.

## 5. Averaged asymmetric loads: no coefficient doubling

Let Q_C(c)=mu_D(c)p_c/p, L=log(1/p). The exact change-of-measure identity is

    E_Q log(A_c/p_c)
      =L-D(Q_C||mu_D)+E_Q log A_c.

Gibbs' variational principle yields

    E_Q log A_c-D(Q_C||mu_D)<=log E_muD A_c.

Thus Alice's complete allocated budget is at most L+log E_muD A_c; Bob's is at most L+log E_muD B_c. For product partitions these moments factor into product_j a_j and product_j b_j. Including the unconditional question divergence gives

    sum_{i notin D}(b_A,i+b_B,i+d_i)
       <=3L+sum_{j in D}log(a_j b_j)
       =3L+2sum_{j in D}kappa_j.                            (R4)

The same sqrt(w_l) appears in EACH distinct one-sided reference, but only once in the common target. No physical joint reference is formed, so no w_l^2 is introduced. This exactly recovers the asymmetric arithmetic-mean-load charge in the published FR premise.

The already audited finite-tracial comparison/reconstruction/sampler chain supplies the legal coordinate loss bound with K=65536 and arbitrary positive slack. Hence (R4) closes full FR(65536) for the stated exact positive fractional rectangle partitions. For arbitrary commuting input tables, first pass the continuous scalar deficit inequality through Lin; do not transport the raw descriptors or costs. New general quadratic repetition is still not obtained because kappa_j may be independent of or much larger than the gap.

## Boundary and obstruction checks

- For p_c=0 the target is unused under Q_C. Supported l have positive mass and finite divergences; zero-weight or empty rectangles are omitted.
- A fully rejecting mask cannot occur at successful c. Empty D has the single all-ones rectangle with unit loads.
- Overlapping rectangles can change target coherences. Fine-output orthogonality and the exact mask identity preserve all declared measured tables; neither reference must preserve the target's coherences.
- Failure completion is genuinely local in the original finite algebra, with finite extra records. It supplies no efficient acquisition claim.
- Existing common-information/positive-filter obstructions remain compatible: they can force large weighted loads or representation costs; this theorem does not bound those loads by gap times tested-set size.
- The full target is prepared as one x,y-indexed family with history inside its workspace. Conditioning on history and then changing its conditional question law would remain invalid.

The principal's new operation therefore survives this independent proof review. Numerical overlapping/fractional controls are being tested by the other two researchers; they supplement these exact algebraic arguments.
