# Actual one-sided masses are finite-table functionals

7 November 2026. This corrects the unnecessarily conservative final paragraph of `actual_one_sided_mass_reconstruction.md`: the fixed-partition actual masses below are not representation-dependent. Their formulas involve only ordinary one-sided marginals of the original finite correlation table. The raw entropy costs and descriptors remain representation-dependent and are still eliminated before closure.

Fix an independent product game, tested D and exact product rectangle partition at tested questions c. Write P(a,b|xvec,yvec) for its full finite correlation table and P_A(a|xvec),P_B(b|yvec) for its no-signaling marginals. Arbitrary commuting tables have these well-defined marginals. Define

    G_A,c(P)=sum_l w_c,l sum_xJ mu_{X,J}(xJ)
                sum_{a:a_D in R_c,l} P_A(a|c_A,xJ),

    G_B,c(P)=sum_l w_c,l sum_yJ mu_{Y,J}(yJ)
                sum_{b:b_D in T_c,l} P_B(b|c_B,yJ),

and G_A(P)=E_muD G_A,c(P), G_B(P)=E_muD G_B,c(P).

These are finite positive linear functionals of P. To express a one-sided marginal directly from the full table, fix any opposite full question string and sum its answers; the choice does not matter on commuting/no-signaling tables. Thus convergence of full finite tables implies convergence of both G quantities, with a finite presentation-dependent Lipschitz constant. There is no matrix-algebra approximation claim.

In a finite-tracial realization,

    P_A(a|xvec)=tau(sigma^2 P_a^xvec),
    P_B(b|yvec)=tau(sigma^2 Q_b^yvec).

Hence these table formulas coincide EXACTLY with the seed traces in `actual_one_sided_mass_reconstruction.md`. They do not depend on which finite-tracial realization was chosen. Positivity of the original table also gives p_D<=G_A,G_B directly: drop one side of each weighted accepted-rectangle indicator before summing. This uses only nonnegativity and marginal no-signaling.

## Scalar theorem and Lin limit

The proved finite-tracial actual-mass reconstruction gives nonnegative t_i with the operational loss witnesses and

    sum_{i notin D}t_i<=3 log(1/p_D)+log(G_A(P)G_B(P)).

Eliminate them into the continuous inverse deficit Phi_K. At fixed target p_D>0,

    sum_{i notin D}Phi_K(epsilon_i,alpha_i(D))
       <=3 log(1/p_D)+log(G_A(P)G_B(P)).                     (Wtable)

All terms now depend only on the finite table, fixed games and fixed partition. Lin's full-table closure applies. At sufficiently close approximants p_D remains positive; G_A,G_B>=p_D keep their logarithms away from zero. Therefore (Wtable) holds for arbitrary commuting product-game tables, with no additional uniform state-dependent mass hypothesis.

The operational finite-tracial costs/descriptors still do not converge. At the purely existential level one can reconstruct scalar t_i=Phi_K afterward, but that is a separate scalar choice and not an operational descriptor limit.

For chosen coordinate presentation loads, G_A<=product_{j in D}a_j and G_B<=product b_j, yielding the published scalar budget. The actual table functional can be substantially smaller. A quadratic consequence still requires a genuine sufficiently small-mass theorem on the relevant tested sets, or some stronger direct-increment cancellation; no such general theorem is inferred here.
