# Full tensor register proof for the common-label budget

7 November 2026. Follow-up to the frozen initial report. This supplies the explicit partition required by M9. It is submitted to the hostile auditor, not silently assumed approved.

Fix tested questions c and write the live strings as x,y with independent-coordinate referee law mu_J(x,y). For every supported c the tested winning relation is a disjoint union of vertex-disjoint rectangles. Coherently compute the corresponding local labels k_A=f_c(a_D), k_B=g_c(b_D), using distinct losing sentinels. This computation is legitimate in the analysis at fixed c: its controlled isometry depends on c and the local live string only.

Add **three copies** L_A^1,L_A^2,L_A^3 of k_A to Alice's output isometry U_{c,x}, and similarly three copies L_B^1,L_B^2,L_B^3 of k_B to V_{c,y}. Let E_A contain L_A^2 and all Alice's original fine outputs/remaining workspace; define E_B similarly. All fine tested outputs are retained in E_A,E_B. Thus, at fixed c,

    psi_c = sum_{x,y} sqrt(mu_J(x,y)) |xx>^{hat X X}|yy>^{hat Y Y}
            sum_{k_A,k_B}|k_A,k_A>^{L_A^1 L_A^3}
                         |k_B,k_B>^{L_B^1 L_B^3}
                         w_{c,x,y,k_A,k_B}^{E_A E_B},

where w is an unnormalized vector and its E_A/E_B components retain private label k_A/k_B in L_A^2/L_B^2. This is an expansion of the ordinary local isometries, so it requires no new joint operation.

The tested event is k_A=k_B=k in K_c. Its probability is p_c. Apply its diagonal projector and normalize. On the accepted state, partition the external label copies as

    H_A,label = (L_A^1,L_B^3),
    H_B,label = (L_B^1,L_A^3).

Every pair contains two identical copies of k. **Only these external copies are assigned across the analysis partition.** E_A retains Alice's private copy and original fine records; it contains no Bob-created copy. E_B is symmetric. Hence

    phi_c = sum_k sqrt(q_c(k)) |k,k>^{H_A,label}
                                   |k,k>^{H_B,label} phi_{c,k},

with phi_{c,k} a pure normalized copied-input vector on R_J X_J Y_J E_A E_B. The redundant duplicate within each history can be suppressed by a fixed isometry. The resulting history label is one k on each side. No physical transmission is asserted by this analysis partition: the reconstructed resource will create the required workspace anew.

## Parent states and domination

Let K_A=X_J E_A. Define

    sigma_A,c = psi_c^{R_J K_A},
    rho_A,c,k = phi_{c,k}^{R_J K_A}.

In sigma_A,c all four external label copies are traced out, as are Bob's full physical systems and Y_J. In particular tracing L_A^1 dephases the private label L_A^2. Bob's entire local isometry disappears by isometry invariance of partial trace; Alice's own controlled isometry, including local label dephasing, remains. Thus sigma_A,c is an Alice mu_J-conditional comparison in precisely Jain Definition 2.6. It is not conditioned on k. Its label blocks are S_k and sentinel blocks.

At fixed Alice label k, restricting Bob's local outcome to k is a positive contraction on the traced subsystem. Therefore the unnormalized selected Alice block T_k satisfies 0<=T_k<=S_k. With rho_A,c=sum_k q_c(k)rho_A,c,k,

    p_c rho_A,c = direct_sum_k T_k <= sigma_A,c.

All target blocks rho_A,c,k keep private L_A^2=k. Donald's identity for the ensemble gives

    E_{k|c,E} [D(rho_A,c,k||sigma_A,c)
                   -D(rho_A,c,k^{K_A}||sigma_A,c^{K_A})]
      = D(rho_A,c||sigma_A,c)
          -D(rho_A,c^{K_A}||sigma_A,c^{K_A})
          +I(k:R_J|K_A)
      <=log(1/p_c),

because the CMI vanishes for the perfectly retained private classical k copy. Bob's parent has the identical proof. Full divergences are finite: every target common-label block occurs as a positive summand in the corresponding preselection mixture, so it is dominated by a finite multiple of sigma_A,c. No limit or optimum is used.

## Both pure coordinate targets simultaneously

Fix an ordering of J. For live i define external histories from the **same accepted vector**:

    H_A,i = (c copies, H_A,label, hat Y_{J<i}, X_{J>i}),
    H_B,i = (c copies, H_B,label, Y_{J<i}, hat X_{J>i}).

On the accepted vector their basis labels agree. The residual spaces are

    A_i^0 = hat X_{J<i} X_{J<i} E_A,
    B_i^0 = hat Y_{J>i} Y_{J>i} E_B.

Together R_i=hat X_i hat Y_i, physical X_i,Y_i, these histories and residual bodies partition all registers of the accepted pure vector (fixed duplicate tested-question/history copies may be suppressed). Thus one obtains a copied-input pure family on

    A_i=H_A,i A_i^0,   B_i=H_B,i B_i^0

whose measured answers are exactly the original event-conditioned i-th fine answer table. There is no separately invented Alice target versus Bob target: both are margins of this same partitioned vector.

For Alice's comparison, take the normalized restriction of sigma_A,c after tracing R_{J>i} and conditioning only on exposed (Y_{J<i},X_{J>i}). It **does not condition on successful k**. Restore the external history h=(c,k,y_{<i},x_{>i}) with its target probability. The internal private label L_A^2 remains random in this comparison; it is fixed to k only in the target. The comparison is still mu_i-conditional because the restriction acts outside the fresh protected i-th reference and commutes with the conditional-amplitude attachment map. Bob uses the reverse restriction, with exposed (X_{J>i},Y_{J<i}).

Jain Lemma 2.24 therefore telescopes each orientation, at fixed c,k, to its parent full-minus-retained divergence. Averaging k,c yields

    sum_{i notin D} b_A,i <=log(1/p_D),
    sum_{i notin D} b_B,i <=log(1/p_D).

The separate classical postselection bound gives sum_i d_i<=log(1/p_D). Thus t_i=b_A,i+b_B,i+d_i obeys sum_i t_i<=3 log(1/p_D).

## Resource freshness and information-flow checks

The postselection history law is not asserted independent of X_i,Y_i. It is part of the target's quantum workspace and conditional descriptions. Jain's local preparation theorem, or its proposed finite-tracial counterpart, reconstructs that whole family from one resource fixed before the realized fresh pair. The comparison retains the original conditional question law and is never replaced by the product of a posterior history and mu_i.

The external history copies are legitimate target-preparation outputs. They do not give Alice a copy of Bob's fine tested answers in the **preselection comparison**. The parent deliberately traces every external history copy. Retaining such a cross-created copy in the parent would destroy the conditional-comparison argument and is not done here.

## Complete tensor consequence using the existing theorem

For finite tensor strategies, Jain Lemma 4.1 is an actual local preparation theorem under exactly the two comparisons just constructed. Its Proposition 5.1 yields a universal constant C such that

    sqrt(epsilon) <=sqrt(alpha_D)+C[log(1/p_D)/m]^(1/4)

whenever the latter ratio is at most one, with arbitrary positive-slack legal finite strategies. Greedy selection of tested coordinates then gives

    omega_*(G^n)<=exp(-c epsilon^2 n)

for a universal c>0 and every disjoint-block G, n>=1. One conservative derivation is to use the existing all-finite-length scalar theorem with the displayed parent budget; an explicit c follows from the chosen local-preparation constant. A finite tensor optimizer is neither assumed nor needed, since the bound is pointwise uniform before taking a supremum.

The finite-tracial transfer report proposes K=65536 and thus the original quadratic constant 2^-75. Its independent algebraic verification is a separate required gate. Historical novelty remains unestablished; the tensor theorem above is currently a complete proof submission relying on Jain's published Lemmas 2.24 and 4.1, submitted for hostile checking.
