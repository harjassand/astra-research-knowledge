# Explicit common amplification and local coherent Uhlmann correction

7 November 2026. This closes the abstract-algebra implementation step proposed in the transfer candidate, subject to hostile verification of the calculations below. It uses only square roots and polar decompositions in finite von Neumann algebras; no tensor factorization of an infinite algebra or matrix approximation occurs.

Let (N,tau) be a finite tracial algebra and let k=|X|. Use the finite algebra P=M_k(N) with **unnormalized** matrix trace Tr_k tensor tau in the following calculations. At the end divide that trace by k and multiply every displayed L2 vector by sqrt(k). All probabilities and Hilbert distances are unchanged by that common normalization.

Suppose unit target vectors psi_xy lie in L2(N). Suppose an Alice conditional comparison is specified by a density T=[T_xx'] in M_k(N), with ordinary matrix trace one, and matching copied-X support. Write its positive square root as C=[C_xz]. Then

    T_xx'=sum_z C_xz C_x'z^*,
    r_x=tau(T_xx)=sum_z tau(C_xz C_xz^*).

For every r_x>0 define the row vector in L2(P)

    chi_x = r_x^(-1/2) sum_z e_1z tensor C_xz.

It has norm one. Embed each original target as

    psi_xy^emb=e_11 tensor psi_xy.

The original Alice/Bob effects embed as I_k tensor A_x and I_k tensor B_y. Their probabilities on embedded targets are unchanged.

The left density of chi_x, and the coherent cross left densities, satisfy

    chi_x chi_x'^* = e_11 tensor T_xx'/sqrt(r_x r_x').

Consequently the copied-X coherent family chi_x purifies exactly the desired comparison on the **original left N algebra**, with an extra fixed left row e_11. Its right column index z is the finite ancillary purifier. The comparison question law is r(x,y)=r_x mu(y|x).

## A right-algebra correction acting on the whole coherent X block

For fixed y form two operator-valued matrices in M_k(N):

    A_y = sum_x e_x1 tensor sqrt(q(x,y)) psi_xy,
    B_y = sum_xz e_xz tensor sqrt(mu(y|x)) C_xz.

Their left densities A_y A_y^* and B_y B_y^* are precisely the unnormalized y blocks of the target and comparison on the matching X-reference / left-N algebra. In particular their root fidelity is

    F_y=||A_y^* B_y||_1.

To check this identity directly, write polar decompositions of A_y and B_y. Multiplication by their partial polar factors preserves the supported singular values, giving

    ||A_y^* B_y||_1
      =||(A_y A_y^*)^(1/2)(B_y B_y^*)^(1/2)||_1.

Choose a contraction or unitary U_y in M_k(N) attaining (or approximating to arbitrary positive slack) the polar variational formula

    Re (Tr_k tensor tau)(B_y^* A_y U_y)=F_y.

Finite-algebra polar partial isometries can be completed after a 2-by-2 amplification, so a unitary choice with the same positive slack is always legitimate. This U_y acts by **right multiplication** on the embedded vectors e_11 tensor psi_xy. It mixes only their purifier column and the original right-N algebra. It does not act on the external coherent X row of A_y, and cannot depend on its realized value x.

Expanding the trace gives

    (Tr tensor tau)(B_y^* A_y U_y)
      =sum_x sqrt(q(x,y) r(x,y))
              <chi_x, (e_11 tensor psi_xy) U_y>.

Thus one right operator U_y simultaneously aligns every x component at fixed y. Summing y and applying Cauchy–Schwarz with the normalized r law yields

    E_q [1-|<chi_x,psi_xy^emb U_y>|^2]
       <=1-(sum_y F_y)^2.

The right side is precisely the squared purified-distance error controlled by the comparison-fidelity bound. This proves the coherent standard-form correction at exactly the required locality, rather than invoking an unspecified global Uhlmann unitary.

## Alice's polar correction and canonical descriptors

Within the SAME algebra P write

    chi_x=J_x u_x,    u_x=|chi_x|.

J_x acts by left multiplication. After the same finite completion it can be made unitary. Right multiplication by U_y commutes with every J_x, for all x,y. Let d_y be the original right density averaged over x conditional on y, embedded as e_11 tensor d_y. Define

    v_y=(U_y^* (e_11 tensor d_y) U_y)^(1/2).

The left J_x correction changes no right density. Hence comparison of right marginals of chi_x and psi_xy^emb U_y, together with the variation of d_y, gives the descriptor estimate in the transfer candidate using only finite-tracial fidelity and Holder.

Transport any original fine POVM by these unitary corrections:

    A_x' = J_x^* (I tensor A_x) J_x,
    B_y' = U_y^* (I tensor B_y) U_y,

with the right-representation order checked against the chosen convention. These are complete POVMs in P. All their left/right representatives commute on **every** x,y, including mismatched inputs. A partial-isometry implementation instead adds the support complement to one default outcome, with the identical target correlations. Thus the actual inherited sampler may evaluate these corrected fine POVMs on the canonical descriptors in this one algebra.

No output state is promised on the original N on sampler failure branches. Only the actual unconditional commuting correlations, with the same rare-losing-event estimate, are used.
