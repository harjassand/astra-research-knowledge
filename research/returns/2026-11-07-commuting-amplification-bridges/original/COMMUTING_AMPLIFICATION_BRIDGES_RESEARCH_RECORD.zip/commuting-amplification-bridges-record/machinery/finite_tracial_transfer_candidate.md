# Finite-tracial conditional-entropy reconstruction: post-freeze candidate

7 November 2026. This does not modify the initial report. The new import and transfer below were investigated independently before reading the other initial reports. Those have now been exchanged. **Full proof candidate for hostile checking**, especially common finite-amplification and label-register bookkeeping. This is not yet a promotion of `FR(K)`.

## 1. Exact multivariate trace import

Junge–LaRacuente, *Multivariate Trace Inequalities, p-Fidelity, and Universal Recovery Beyond Tracial Settings*, arXiv:2009.11866v2 (1 April 2021), J. Math. Phys. 63, 122204 (2022), Theorem 1.2, supplies multivariate Golden–Thompson over von Neumann algebras. Its finite-tracial specialization gives precisely the four-operator inequality needed by Jain's Lemma 4.2. The proof treats finite algebras before the Haagerup extension. No approximation of a type-II algebra by matrices occurs. [Primary source](https://arxiv.org/html/2009.11866).

## 2. Positive-slack marginal replacement, including continuous zero spectrum

Let N be a finite von Neumann algebra. Work on the finite direct sum over classical hat-Y of the matching-copy hat-X=X matrix corner tensor N. The supported prior cells define a corner S_mu. Let rho be a bounded normal density there, and let nu=C_mu(tau) be a bounded conditional-comparison density, with finite full divergence. Set

    b=D(rho||nu)-D(rho_K||nu_K),   K=X A.

Choose tau0 diagonal uniform over supported local X labels, tensor the tracial density 1_N, and put nu0=C_mu(tau0). It is boundedly invertible on S_mu, since alphabets are finite and all supported prior entries are positive. Define

    rho_delta=(1-delta)rho+delta nu0,
    nu_delta =(1-delta)nu +delta nu0,    0<delta<1.

Both are invertible in S_mu; nu_delta remains a conditional comparison. Joint convexity gives an upper bound `(1-delta)D(rho||nu)` for their divergence; lower semicontinuity gives the reverse limiting bound. The full divergences therefore converge. The same applies to retained marginals, hence b_delta tends to b. This makes no smallest-eigenvalue assertion for the unregularized states.

At fixed delta define bounded operators

    L_s=rho_K,delta^((1+is)/2) nu_K,delta^(-(1+is)/2),
    nu_tilde_delta=integral beta0(s)(I_R tensor L_s) nu_delta
                                      (I_R tensor L_s)^* ds.

The integral is a normal L1 integral, bounded in the algebra with a delta-dependent bound. Direct partial trace gives `(nu_tilde_delta)_K=rho_K,delta`. L_s is X block diagonal, so commutes with the scalar operators attaching the conditional Y amplitudes. Thus nu_tilde_delta keeps exactly the conditional-comparison form.

Apply the imported four-operator inequality with logarithms ordered as

    log W, log rho_K,delta, -log nu_K,delta, log nu_delta.

Gibbs' variational formula, followed by the measured-relative-entropy variational formula, gives Jain's bound verbatim in the finite tracial algebra:

    D_meas(rho_delta||nu_tilde_delta) <= b_delta.

The normal-state measured-divergence/fidelity inequality yields

    F(rho_delta,nu_tilde_delta)^2 >= exp(-b_delta).

Since rho_delta converges to rho in L1, fidelity continuity gives

    F(rho,nu_tilde_delta)^2 >= exp(-b)-o_delta(1).              (T1)

There is no need for a normal limiting replacement state, convergence of inverse powers, or weak compactness of the L1 unit ball. Every positive delta supplies an actual comparison; the final game argument takes an infimum over finite positive-slack protocols. This avoids the continuous-spectrum gap in simply copying a matrix regularization proof.

## 3. Coherent corrections in the commutant

Let a copied-input target family be represented by unit vectors psi_xy in L2(N), after finite local ancillas, with physical left/right measurements. Suppose Alice and Bob comparisons have conditional deficits bA,bB. Purify the comparison nu_tilde_delta in the standard form of a finite matrix amplification of N. Its matching-X rows give vectors chi_x depending only on x and a law

    r_delta(x,y)=r_X,delta(x) mu(y|x).

The right matrix index of the square root of the finite-control density is a finite ancillary purifier. Add it to the opposite side and pad all finite families into one amplification. This does not factor N as a tensor product.

At each y, apply the standard-form Uhlmann transition-probability theorem to the **entire coherent X ensemble** on Alice's algebra, including its X references. The correction W_y belongs to that algebra's commutant, and cannot depend on x. Partial isometries can be completed after finite matrix amplification. Arbitrary positive fidelity slack is sufficient. For

    a_xy=<chi_x,psi_xy W_y>,

the block-fidelity formula and Cauchy–Schwarz, using only that r_delta is normalized, give

    eA=E_q[1-|a_xy|^2] <=1-F(rho_A,nu_tilde_delta)^2
                              <=bA+o_delta(1).                (T2)

An exact equality r_X,delta=q_X is unnecessary. For Bob, tracing the protected X reference makes the questions classical. The ordinary direct-sum identity and data processing give Jain's Lemma 2.25 over the finite normal algebra: `I(X:B|Y)<=bB`. With d_y the right marginal averaged over x conditional on y,

    eB=E_q P^2(psi_xy^B,d_y) <=bB.                            (T3)

No infinite individual von Neumann entropy is subtracted: these are relative entropies with finite classical records.

## 4. Canonical descriptors without Schmidt decomposition

Write chi_x as v_x in the common L2 standard form. Put

    u_x=(v_x^*v_x)^(1/2).

Polar decomposition supplies v_x=J_x u_x with J_x in Alice's left algebra, completed after finite amplification. For the corrected Bob density take

    v_y=(W_y^* d_y W_y)^(1/2),

using consistently the convention that Bob's correction acts on vectors on the right. For normalized positive densities a,b, noncommutative Holder gives

    F(a,b)=||a^(1/2)b^(1/2)||_1
      <=||a^(1/4)||_4 ||a^(1/4)b^(1/4)||_2 ||b^(1/4)||_4
      =[tau(a^(1/2)b^(1/2))]^(1/2).

Consequently

    ||a^(1/2)-b^(1/2)||_2^2 <=2 P(a,b)^2.

Using (T2)–(T3), the squared triangle inequality and contraction to the right marginal yields

    Ddesc=E_q||u_x-v_y||_2^2 <=4(bA+bB)+o_delta(1).             (T4)

The corrections J_x,W_y take u_x within mean infidelity bA+o(1) of the target. This is the proposed finite-tracial version of Jain's pure-description lemma.

**Audit gate:** the common finite amplification must embed the original local measurements so both the coherent Uhlmann commutant correction and polar correction transport to complete POVMs on every input. An abstract global unitary would not suffice. The standard-form construction above claims the needed left/right membership; this is the operation to reconstruct independently.

## 5. The actual sampler earns the rare-loss estimate

The inherited S_actual sampler accepts arbitrary finite unit L2(N) descriptor families and original local/opposite POVMs. Its Section 8 gives actual unconditional all-input commuting POVMs, with

    beta<=alpha'+2 sqrt(alpha' F)+F,
    F=896(h^2+Dbar/h^2)+vanishing finite-resource errors.

For Ddesc<1/16 choose h=Ddesc^(1/4), after finite descriptor approximation, obtaining `F<=2688 sqrt(Ddesc)+o(1)`. From (T4), `F<=5376 sqrt(s)+o(1)` for s=bA+bB. Target alignment changes square-root loss by at most sqrt(s)+o(1). Thus for s<=1

    sqrt(beta)<=sqrt(alpha)+75 s^(1/4)+o(1).

Changing the classical input law q to mu costs at most sqrt(d), d=D(q||mu). For t=s+d<=1,

    beta_mu<=alpha+152 sqrt(alpha)t^(1/4)+5776 sqrt(t)+o(1).

For Ddesc>=1/16 use the trivial loss bound and s>=1/64, with conservative constants. The large-t regime is likewise trivial. Thus K=65536 is safely sufficient for

    loss<=alpha+K[sqrt(alpha)t^(1/4)+sqrt(t)]+positive_slack.    (T5)

All resource parameters are finite at fixed positive slack, but may depend on spectra, input families and the algebra. This is a correlation protocol, not a trace-preserving output channel on the original algebra.

## 6. Common labels, freshness and the PR-box audit

The frozen report supplies a parent budget with each successful block label k retained privately by both players. The comparison averages its own local label k_A or k_B; it is **not** silently conditioned on successful equality. This permits cancellation after subtracting the retained marginal. In the target, the external shared-history k copies are distinct from the private retained copy.

One must not pre-sample k from its postselection marginal independently of fresh questions. Instead include all history copies inside the copied-input target and invoke the local-description/sampler theorem on that whole family. Its all-input resource is fixed in advance; local histories can depend on the corresponding fresh local question, as in Jain's construction and the inherited H interface.

The auditor's PR-box postselection has zero question drift but positive conditional preparation deficit. It is not covered by a claim that drift alone controls preparation. A CHSH condition `A xor B=XY` uses the fresh pair jointly and cannot be represented by a fixed-c local common-label identity with those same local outputs. A detection-loophole implementation via local question guesses can realize PR after postselection, but its event probability pays the parent log(1/p) cost. Nothing here sets that cost to zero.

If the ordered common-label construction passes, it gives `sum_i(bA_i+bB_i)<=2 log(1/p_D)` and `sum_i d_i<=log(1/p_D)`. Then (T5) is precisely FR(65536) for disjoint-block products. Scalar elimination followed by Lin's finite-table closure would give commuting quadratic block/projection repetition. This is the strongest candidate attained; full hostile checking is still required before promotion. General all-predicate quadratic repetition is not proved.
