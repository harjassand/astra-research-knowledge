# Minimal operational reconstruction spine: R and H are unnecessary

7 November 2026. Principal integration response after the completed block and charged constructions. This records which old machinery is actually used, and does not modify the published manuscript.

**Neither the old resolvent production R nor the separate posterior-history production H is needed.** The new proof applies conditional-comparison preparation directly to the full copied-input target, with every history label inside its output workspace. There is no preliminary attempt to generate a shared posterior history. The parity fixture makes this distinction necessary.

## Minimal chain

1. **Finite-tracial model and finite coherent dilation.** Start with a bounded positive sigma in a finite von Neumann algebra and arbitrary complete local/opposite POVMs. Square roots and finite left-column/right-row matrix ancillas record all fine outputs coherently. Standard finite-ancilla embeddings preserve exact left/right commutation on all inputs. No resolvent feature is introduced.

2. **One pure exact rectangle target, two separate one-sided positive references.** For an exact nonnegative fractional rectangle partition, append the same common l label with amplitude sqrt(w_l) on both target sides. The mask identity preserves the original tested mass and complete conditional fine table. Build Alice's positive reference from sqrt(w_l)r_l and Bob's separately from sqrt(w_l)t_l. Their actual traces normalize legitimate conditional comparisons. Alternatively complete each local contraction using the row/column load bound; this proves the presentation version directly. The references need not be two margins of a common preselection state.

3. **Positive matrix domination and entropy allocation.** Over M, each selected Alice block is Z Q_T Z^*, below Z Z^*. Bob is symmetric in M^op. A private own-label copy stays in each reference; all external cross-created history copies are traced from it. Donald's full-minus-retained identity cancels the common-label entropy. Gibbs change of measure gives the arithmetic-mean presentation loads. The copied-reference ordered chain rule (Jain Lemma 2.24, proved by direct-sum relative entropy) allocates the parent deficits. Ordinary postselection bounds the sum of UNCONDITIONAL fresh-question divergences. The resulting target for each coordinate is one pure x,y-indexed vector with all history registers retained.

4. **Conditional-comparison local descriptions.** The finite-tracial four-log trace inequality follows from Junge–LaRacuente 2009.11866v2 Theorem 1.2, with p=2 and half-logarithms. Gibbs/measured-divergence variational formulas give fidelity-controlled exact marginal replacement at positive faithful slack. Mixing with a faithful conditional comparison makes all logarithms/inverses bounded at every positive slack; joint convexity and lower semicontinuity give separate convergence of the two finite divergences. There is no zero-spectrum inverse limit.

5. **Explicit local polar corrections and descriptors.** Rows of the comparison seed square root give chi_x. At each y, the polar optimizer of B_y^*A_y acts on purifier columns in one finite matrix amplification; it is a right-algebra operator independent of external coherent x. Alice's polar correction is left-local in that same algebra. Finite unitary completions transport complete fine POVMs. Holder gives fidelity squared <= affinity, hence descriptor squared distance <=4(b_A+b_B)+vanishing slack. This replaces the entire resolvent/alignment/history interface.

6. **The standalone actual sampler S_actual, Section 8.** Its contract accepts arbitrary finite families of unit L2 vectors and original fine POVMs in a finite algebra. It supplies one input-independent amplified resource, complete unconditional left/right POVMs for every input, and its actual rare-losing-event estimate. The sampler's proof uses graph projections, finite spectral approximation and finite first-success trials; it does not invoke old R or H. The named governing sampler is SHA256 `f37b03a0a84487328c4d1b96b30bbc03468e085bef5593a635126775310beb2b`. Generic TV sampling or an abstract original-algebra channel is not substituted.

7. **Fresh-law transfer and scalar closure.** Change from the target's unconditional coordinate law q_i to mu_i using the Hellinger square-root bound, `||sqrt(q_i)-sqrt(mu_i)||_2<=sqrt(D(q_i||mu_i))`. Alternatively Pinsker may be used by adding its TV term directly to the LOSS outside the rare-losing-event square root. The Hellinger route is the checked 152/5776 constant calculation, safely below K=65536. Eliminate raw costs into the continuous Phi_K scalar inequality before applying Lin 2304.01940v3 Theorem 3.2. Only finite-table quantities converge.

8. **Scalar applications.** The earlier finite-probability all-wins and weighted-threshold arguments now take this proved scalar budget as input. They need neither the original general cubic theorem as a black box nor the original threshold theorem. Their standard predecessors and exact constants remain credited. The original accepted N443/N446 statements remain intact as capital and comparators.

## Exact reusable scalar interface

For fixed tested D, actual p_D>0, fixed exact partition and original full finite table P, let G_A(P),G_B(P) be the one-sided marginal masses explicitly defined in `actual_mass_table_identity.md`. They are finite continuous positive linear table functionals and satisfy G_A,G_B>=p_D. The strengthened scalar budget is

    sum_{i notin D} Phi_K(epsilon_i,alpha_i(D))
       <=3 log(1/p_D)+log(G_A(P)G_B(P)),    K=65536.

Since G_A<=product_D a_j and G_B<=product_D b_j, this implies the exact public budget `3 log(1/p_D)+2 sum_D kappa_j`. Thus the finite-tracial FR hypothesis is closed at its full exact-positive-fractional-rectangle scope, and its scalar arbitrary-commuting game consequences follow through Lin. General quadratic repetition is still open because the charge can stay positive as the gap vanishes.

The operational t_i and descriptors exist for finite-tracial input tables. They are not claimed to converge with Lin approximants. A purely existential scalar choice from Phi_K after closure is a different statement. No manuscript, Zenodo or website bytes were changed by this proof work.
