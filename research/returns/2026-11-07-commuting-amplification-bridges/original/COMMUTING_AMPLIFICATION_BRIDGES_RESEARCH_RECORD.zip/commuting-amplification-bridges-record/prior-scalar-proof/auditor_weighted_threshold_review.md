# Hostile check of the heterogeneous weighted threshold

6 November 2026. Exposed follow-up after the independent initial reports.
The principal supplied the skeleton; the constructor then supplied his
current derivation directly. I independently reconstructed the posterior,
weighted inequalities, derivative and constants before receiving his full
derivation. No additional agents were used.

## Disposition and exact theorem

The theorem and stated constant pass. It uses the previously audited
scalar coordinate budget, with no new sampler, state-convergence or
independence premise. Capping conditional losses is essential. A full
tested set uses a trivial empty sum, not extraction with no live round.
The horizontal barrier below is simpler than the initially proposed
sloped barrier and gives a slightly better final numerical factor.

Let epsilon_i in [0,1] be finitely many base commuting gaps and D_i in
{0,1} the actual losses of an arbitrary joint product-game strategy. Set

    S=sum_i epsilon_i^2,       Z=sum_i epsilon_i D_i.

The D_i need not be independent. Let K>=1 and charges kappa_i>=0 satisfy
kappa_i<=c epsilon_i for a specified c>=0. Define

    Phi_K(e,a)=[(sqrt(a+4(e-a)_+/K)-sqrt(a))/2]^4.

Assume for every tested subset T with actual tested success p_T>0 and
alpha_i(T)=P(D_i=1 | all tested wins) that

    sum_(i notin T) Phi_K(epsilon_i,alpha_i(T))
                   <=3log(1/p_T)+2sum_(j in T) kappa_j.     (H)

For proper T, this is the heterogeneous scalar R/H/S_actual bound after
eliminating representation-dependent errors before fixed-p Lin closure.
For T=[N], extend it trivially: its left side is zero and right side
nonnegative. Subsets with p_T=0 are omitted from conditional expressions.

For disjoint-block/projection games, the audited production gives
kappa_i=0, c=0 and K=2^16. The charged version applies only when the
uniform load hypotheses producing these charges have actually been
verified. A merely declared charge does not supply (H).

Then for every finite N and 0<r<=1,

    P{Z<=(1-r)S}
       <=exp[-r^5 S/(2^21 K^4(1+c))].                     (T)

If S=0 this is the bound one. At r=1, losses on zero-gap games are
ignored, so the weighted event is winning every positive-gap coordinate;
the ordinary all-wins event is contained in it. At r=0 the bound one
also holds trivially. The game theorem retains exactly the inherited
S_actual/R/H/Lin dependencies; it is not independent external verification
or a claim of historical novelty.

## 1. Cap and weighted Holder calculation

Fix T with p_T>0. Write

    tau_i=Phi_K(epsilon_i,alpha_i(T)),
    alpha'_i=min(alpha_i(T),epsilon_i),
    S_T=sum_(i notin T) epsilon_i^2,
    A_T=sum_(i notin T) epsilon_i alpha_i(T),
    M_T=3log(1/p_T)+2sum_(j in T) kappa_j.

The scalar quadratic inversion defining Phi gives

    epsilon_i<=alpha'_i+K[sqrt(alpha'_i)tau_i^(1/4)
                                      +sqrt(tau_i)].       (1)

If alpha_i<epsilon_i this is equality after inversion. Otherwise
alpha'_i=epsilon_i and tau_i=0, also giving equality. This justifies the
cap: one is not arbitrarily reducing alpha in a previously known bound.

Multiply (1) by epsilon_i and sum over live coordinates. Since
alpha'_i<=epsilon_i, Holder with exponents 4/3 and 4 gives

    sum_live epsilon_i sqrt(alpha'_i)tau_i^(1/4)
       <=sum_live epsilon_i^(3/2)tau_i^(1/4)
       <=S_T^(3/4)(sum_live tau_i)^(1/4).

Cauchy-Schwarz gives sum_live epsilon_i sqrt(tau_i)
<=sqrt(S_T sum_live tau_i). The uncapped A_T dominates the capped
weighted loss. Thus (H) implies

    A_T>=S_T-K[S_T^(3/4)M_T^(1/4)+sqrt(S_T M_T)].            (2)

If S_T=0, both S_T and A_T vanish and (2) is trivial. This includes
the full tested set and subsets leaving only zero-gap coordinates live.
Without the cap, alpha_i may exceed epsilon_i, so the claimed Holder
bound by S_T^(3/4) would not follow.

## 2. Sparse tests and the same posterior throughout

For u>=0 draw a subset T independently of the original strategy,
including coordinate i with probability

    q_i(u)=u epsilon_i/(1+u epsilon_i).

Call its product law pi_u. Zero-gap coordinates are never tested. Put

    f_u(D)=product_i (1+u epsilon_i)^(-D_i),
    F(u)=E f_u(D),              ell(u)=-log F(u).

For a fixed loss pattern, passing all selected tests has probability
product_(i:D_i=1)(1-q_i)=f_u(D). Consequently

    F(u)=sum_T pi_u(T)p_T.                                 (3)

F(u)>0 at every finite u, even when all-wins probability is zero. The
posterior test-subset distribution after passing is

    w_u(T)=pi_u(T)p_T/F(u).                                (4)

The posterior loss distribution is the original law tilted by f_u/F;
write its expectation as E_u. Given a fixed D under this posterior,
tests are independent: losing coordinates cannot be selected, and
winning coordinates retain their original selection probability. Thus

    P_u(i in T | D)=q_i(u)(1-D_i).                         (5)

This is independence of artificially drawn tests conditional on an
outcome, not independence among the strategy's actual losses.

The exact load-bearing consequences are:

* Tested coordinates have D_i=0, so E_(w_u) A_T=E_u Z.
* By (5), epsilon_i<=1 and kappa_i<=c epsilon_i,

      E_(w_u) sum_(i in T) epsilon_i^2
         <=sum_i epsilon_i^2 q_i
         <=u sum_i epsilon_i^3<=uS,
      E_(w_u) S_T>=(1-u)S,
      E_(w_u) sum_(i in T) kappa_i<=c uS.                  (6)

* Relative entropy of (4) against pi_u gives

      E_(w_u) log(1/p_T)
          =ell(u)-D(w_u||pi_u)<=ell(u).                   (7)

The identities are on the supported subset family; p_T=0 terms have
posterior mass zero. At u=0 only T empty is selected and (7) is zero.

Average (2). Inside its subtracted nonnegative error use S_T<=S, then
concavity of x^(1/4), sqrt(x), and (6)-(7). This proves

    E_u Z >= (1-u)S
       -K[S^(3/4)(3ell(u)+2c uS)^(1/4)
                    +sqrt(S(3ell(u)+2c uS))].             (8)

All terms use exactly the same joint subset/outcome posterior. In
particular alpha_i(T) remains the original conditional loss given the
actual tested event; no new conditional strategy is asserted.

## 3. Derivative and horizontal barrier

F is a finite positive smooth function. Direct differentiation yields

    ell'(u)=E_u sum_i epsilon_i D_i/(1+u epsilon_i)
            >=E_u Z/(1+u)>=0.                            (9)

The final monotonicity is from the exact expectation, even when (8)
has a negative right side. It is needed below.

Assume S>0 and put lambda=r^4/[2^20 K^4(1+c)]. If
ell(lambda)>=lambda S, then the desired weaker bound
ell(lambda)>=(1-r/4)lambda S is immediate. Otherwise monotonicity keeps
ell(u)<lambda S throughout 0<=u<=lambda. Hence on that interval,

    [3ell(u)+2c uS]/S
       <=(3+2c)lambda<=3r^4/(2^20 K^4).

The normalized sum of errors in (8) is therefore at most

    (3^(1/4)/32)r+(sqrt(3)/(1024K))r^2 <r/16.             (10)

Its coefficient is at most 0.04282, below 1/16, for all K>=1 and
r<=1. Also lambda<=r/2^20<r/16. Equations (8)-(9) give

    ell'(u)/S >=(1-u-r/16)/(1+u)
              >=1-2u-r/16>1-r/4.

Integrate from ell(0)=0 to obtain, in either case,

    ell(lambda)>=(1-r/4)lambda S.                         (11)

This is stronger than the initially proposed coefficient 1-r/2. There
is no first-crossing regularity issue or circular assumption about a
sloped barrier.

## 4. Tail comparison, endpoints and scope

Since log(1+u epsilon_i)<=u epsilon_i, f_u(D)>=exp(-uZ). On the event
Z<=(1-r)S this is at least exp[-u(1-r)S]. Thus, with P the event's
probability,

    F(lambda)>=P exp[-lambda(1-r)S],
    P<=exp[-ell(lambda)+lambda(1-r)S]
      <=exp[-(3r/4)lambda S]
      <=exp[-r^5 S/(2^21 K^4(1+c))].

The exponential comparison has the correct direction: a small weighted
loss makes f_lambda large, and an upper bound on its expectation bounds
the event probability.

The checks do not leave an endpoint gap:

* S=0 gives Z=0 almost surely and both sides of (T) equal one.
* epsilon_i=0 gives zero weight, zero test probability and, under
  the charged hypothesis, kappa_i=0. No individual gap is divided by.
* r=1 is allowed. When gaps vanish, its event is larger than ordinary
  all wins, as noted in the statement.
* Some p_T can vanish; no such event is conditioned on. F remains
  positive. Full tested subsets retain their posterior mass and use
  a trivial empty-live inequality.
* N can be one. No large-length cutoff or tensor-block amplification
  is required.
* Nonidentical finite games and different joint mu_i are allowed.
  Between-round question independence enters only in producing (H).
* The sparse subset experiment is analytical bookkeeping. It supplies
  no new efficient sampler, finite-dimensional compiler or physical
  resource. All resources and accuracy limits are inherited through
  the established scalar (H).

With K=2^16 and c=0 the conservative displayed constant is 2^-85.
For identical gaps epsilon and delta=r epsilon the rate is the known
delta^5 n/epsilon^3 scale of the separately audited homogeneous wrapper,
with a weaker numerical constant. For heterogeneous gaps it accumulates
the actual sum of squared gaps and controls the corresponding weighted
loss; this is a distinct extension beyond a public-mixture estimate.
The earlier heterogeneous direct-product theorem gives a better constant
at the all-wins endpoint.

The fifth-power deviation dependence is not proved optimal. No theorem
for arbitrary games without a verified charge bound, historical priority,
or physical advantage follows. The scalar derivation of (T) from (H)
is complete at its stated quantifiers.

## 5. Additional substantive check: exact tensor-entropy cancellation

The principal additionally requested review of the constructor's appended
Section 5. That proposition passes, with its strict independence scope
retained. It repairs the independently padded strategies in our examples
while preserving their actual tested event. It does not assert a repair
for arbitrary strategies of the enlarged game.

The assumptions must be literal: the original repeated strategy has a
product finite-tracial state sigma_b tensor sigma_nu, product full-answer
POVMs between the base and nuisance factors, and nuisance POVMs and tested
mask independent of every referee question. Nuisance measurements can
correlate their own rounds and players. Let the two tested events have
positive masses p_b,p_nu. Then their intersection is the original augmented
tested event and has mass p_b p_nu.

Use product positive factorizations of the two tested masks. Since the
nuisance does not depend on questions exposed during R, its merged coarse
effects F_nu^ell,H_nu^ell are constant with respect to the exposure stage.
The augmented coarse effects are exactly
F_b,j^k tensor F_nu^ell and H_b,j^k tensor H_nu^ell. Their bilinear
positive functional factors as chi_b times chi_nu.

For f(t)=t log t, f(0)=0, continuous joint functional calculus gives

    f(A tensor B)=f(A) tensor B+A tensor f(B),   0<=A,B<=I.

The scalar identity holds on [0,1]^2, including either coordinate zero,
so kernels and continuous zero spectrum cause no exception. Substituting
and summing product factorization coefficients yields, for the **averaged**
R potentials,

    U_aug,j=p_nu U_b,j+p_b U_nu,
    Z_aug,j=p_nu Z_b,j+p_b Z_nu.                            (13)

The p_b coefficient here uses the base stage mass after averaging over
exposure flags. R's exact identity makes that average p_b at every stage.
There is no assumption that the base mass is p_b at each individual flag;
in general it is not. The nuisance terms U_nu,Z_nu are fixed constants.

Every potential increment therefore equals p_nu times its base increment.
After dividing by actual augmented mass p_b p_nu, the normalized entropy
increments are exactly those of the base construction. The augmented
raw resolvent errors are bounded by these increments, so they inherit the
base normalized entropy budget. This does not claim equality of the
actual squared resolvent errors, only the exact increment identity and
the resulting upper bound.

There is no hidden live fine-POVM defect. The original augmented fine
effects have the same tensor structure and satisfy their required coarse
domination and completeness. Apply the existing R support-form/polar
transport in the full augmented algebra. Its exact norm and fine-answer
identities remain valid, preserving the complete conditional live table.
The transported POVMs and resolvent vectors need not themselves factor
as tensor products: the R theorem applies directly to the augmented
effects, and the entropy argument only controls their error upper bounds.
One must not infer an unproved factorization of those transported objects.

Finite feature compression still retains all exact masses and fine
correlations. Its coefficient-dependent accuracy cost can be very large,
but tends to zero at fixed p_b p_nu>0 as in the inherited proof. The
same fixed-p and finite-family limit order is required.

The referee-question posterior also simplifies exactly:

    P(questions | E_b and E_nu)=P(questions | E_b),

because the nuisance event is independent of all questions and the base
experiment. Thus its KL cost is bounded by log(1/p_b), without charging
log(1/p_nu). At the exact norm-table level the nuisance rectangle-label
mass similarly factors out of the base posterior; no equality of arbitrary
transported state descriptions is needed.

This explains why large exact-mask masses and large separator information
can coexist with small or zero exposure increments: the excess entropy
can be constant through exposure. The mass and common-information no-go
theorems remain valid, but they do not lower-bound these increments.
General correlated strategies can make nuisance effects depend on base
questions or share nonproduct workspace, in which case (13) has not been
proved. Removing that dependence, or identifying a different invariant
entropy term to subtract, remains an open substantive operation.
