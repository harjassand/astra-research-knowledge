# Constructor cross-review: heterogeneous weighted tails and the filter obstruction

6 November 2026. This is exposed synthesis after all four independent initial reports were frozen. I read `initial/{machinery,auditor,principal}.md`, `principal_heterogeneous_candidate.md` and `principal_independent_continuation.md`. Initial reports are unchanged. No new agents were created.

## 1. A heterogeneous weighted-loss theorem

This is the strongest positive construction from this review. Its new scalar operation is a family of independent sparse success tests, with inclusion probability proportional to each component gap. It uses the acquired individual-coordinate producer; it does not posit a new postselection on a threshold event.

### Exact scalar premise

Let W_i∈{0,1} be arbitrary correlated success indicators, i∈[N], let ε_i∈[0,1], κ_i≥0, and K≥1. For each proper subset C set E_C={W_i=1 for every i∈C}, p_C=P(E_C), and α_i(C)=P(W_i=0|E_C) for i∉C, whenever p_C>0. Put

\[a=(\epsilon-\alpha)_+,\qquad
\Phi_K(\epsilon,\alpha)=
\left[\frac{\sqrt{\alpha+4a/K}-\sqrt\alpha}{2}\right]^4.\]

Assume, for every proper C with p_C>0,

\[\sum_{i\notin C}\Phi_K(\epsilon_i,\alpha_i(C))
\le M_C:=3\log(1/p_C)+2\sum_{j\in C}\kappa_j.\tag{P}\]

This is a finite-table scalar statement. It is the correct form to transfer through Lin: the original resolvent errors need not converge with the correlation tables. Define the empty-live-set assertion to be 0≤M_[N], so it is automatic if the full subset has positive probability and calls for no reconstruction.

### Theorem

Suppose κ_i≤C₀ ε_i for all i, with C₀≥0. Let

\[S=\sum_i\epsilon_i^2,\qquad Z=\sum_i\epsilon_i(1-W_i).\]

If S>0, then for every 0<r≤1,

\[\boxed{\Pr\{Z\le(1-r)S\}
\le\exp\!\left[-\frac{r^5S}{2^{21}K^4(1+C_0)}\right].}\tag{WT}\]

At K=2¹⁶ this constant is 2⁻⁸⁵/(1+C₀). This holds directly for every finite N, including N=1, without a floor, large-length condition or tensor-amplification argument. If S=0 the corresponding bound is the trivial 1. The condition is a genuine weighted threshold: ε_i weights the loss in component i and S is the sum of the squared component gaps.

For a family of games with ε_i=1−ω_co(G_i), independent joint referee laws across coordinates, and intrinsic loads κ_i satisfying the stated bound, the game application of (WT) retains the exact inherited R/H/operational-sampler/Lin premises needed to acquire (P). For disjoint-block/projection predicates κ_i=0. This is not an unconditional certification of that inherited chain, nor a priority claim.

### Proof, step 1: conditional weighted rejection

Set τ_i=Φ_K(ε_i,α_i(C)). If α_i≤ε_i, the quadratic equation in x=τ_i^(1/4) gives

\[\epsilon_i=\alpha_i+K(\sqrt{\alpha_i}\,\tau_i^{1/4}+\sqrt{\tau_i}).\]

If α_i>ε_i, then τ_i=0. Hence, in both cases, with α'_i=min{α_i,ε_i},

\[\epsilon_i\le\alpha'_i+K(\sqrt{\alpha'_i}\,\tau_i^{1/4}+\sqrt{\tau_i}).\]

Write S_C=Σ_live ε_i² and A_C=Σ_live ε_i α_i(C). Since α'_i≤α_i, Hölder and Cauchy–Schwarz imply

\[\begin{split}
S_C-A_C&\le K\sum_{i\notin C}
\left(\epsilon_i^{3/2}\tau_i^{1/4}+\epsilon_i\sqrt{\tau_i}\right)\\
&\le K\left[S_C^{3/4}\left(\sum_i\tau_i\right)^{1/4}
+\sqrt{S_C\sum_i\tau_i}\right]\\
&\le K[S_C^{3/4}M_C^{1/4}+\sqrt{S_CM_C}].\tag{1}
\end{split}\]

The cap α'_i is necessary: one cannot bound √α_i by √ε_i on coordinates already losing more than their one-game gap. For the full subset set S_C=A_C=0; (1) then holds trivially, irrespective of its p_C.

### Proof, step 2: sparse success tests and their exact tilt

For u>0 independently include coordinate i in a random test set with probability

\[q_i(u)=\frac{u\epsilon_i}{1+u\epsilon_i}.\]

Let ν_u(C) be this subset law. Its mean success probability is

\[F(u)=\sum_C\nu_u(C)p_C
=\mathbb E\prod_i[1-q_i(u)(1-W_i)]
=\mathbb E\prod_i(1+u\epsilon_i)^{-(1-W_i)}>0.\tag{2}\]

Set L(u)=−log F(u), so L(0)=0. Condition the joint outcome/subset experiment on success of every selected coordinate. Its subset marginal has weights

\[w_u(C)=\nu_u(C)p_C/F(u).\]

Zero-probability E_C have weight zero. Its outcome marginal is the original law tilted by the product in (2); call it T_u. Given an outcome, selected coordinates are independent with inclusion probability q_i(u)W_i. In particular, a loss is never selected. Therefore

\[\begin{split}
\mathbb E_{w_u}A_C&=\mathbb E_{T_u}Z,\\
\mathbb E_{w_u}S_C&=S-\sum_i\epsilon_i^2q_i(u)\mathbb E_{T_u}W_i
\ge(1-u)S,\\
\mathbb E_{w_u}\sum_{j\in C}\kappa_j
&\le u\sum_i\kappa_i\epsilon_i\le C_0uS.\tag{3}
\end{split}\]

The second line uses q_i≤uε_i and ε_i³≤ε_i²; it is only used for u<1. The exact entropy identity

\[\mathbb E_{w_u}\log(1/p_C)=L(u)-D(w_u\|\nu_u)\le L(u)\tag{4}\]

gives \(\overline M(u):=E_{w_u}M_C\le3L(u)+2C_0uS\).

Average (1) under w_u, and apply Hölder/Cauchy–Schwarz once more. Since E S_C≤S,

\[\mathbb E_{T_u}Z\ge(1-u)S
-K[S^{3/4}\overline M(u)^{1/4}+\sqrt{S\overline M(u)}].\tag{5}\]

All expressions are finite classical expectations. No reconstruction is requested for the random test set as a whole, and no threshold predicate is passed into R/H.

### Proof, step 3: a differential entropy barrier

Differentiation of the finite sum in (2) gives exactly

\[L'(u)=\mathbb E_{T_u}\sum_i
\frac{\epsilon_i(1-W_i)}{1+u\epsilon_i}
\ge\frac{\mathbb E_{T_u}Z}{1+u}.\tag{6}\]

In particular L is nondecreasing. Fix r∈(0,1] and set

\[\lambda=\frac{r^4}{2^{20}K^4(1+C_0)}.\]

On any u∈[0,λ] for which L(u)≤λS, (4) gives

\[\frac{\overline M(u)}S\le(3+2C_0)\lambda
\le\frac{3r^4}{2^{20}K^4}.\]

The normalized error in (5) is at most

\[\frac{3^{1/4}}{32}r+\frac{\sqrt3}{1024K}r^2<r/16.\tag{7}\]

Also λ≤r/16. Thus (5)–(6) imply

\[L'(u)\ge\frac{1-u-r/16}{1+u}S\ge(1-r/4)S.\tag{8}\]

If L(λ)≥λS, the next bound is automatic. Otherwise monotonicity gives L(u)<λS throughout the interval, so integrate (8). In either case

\[L(\lambda)\ge(1-r/4)\lambda S.\tag{9}\]

Finally log(1+λε_i)≤λε_i gives, on Z≤(1−r)S,

\[\prod_i(1+\lambda\epsilon_i)^{-(1-W_i)}
\ge e^{-\lambda Z}\ge e^{-\lambda(1-r)S}.\]

Together with (2) and (9), this yields

\[\Pr\{Z\le(1-r)S\}\le
\exp[-3r\lambda S/4]
\le\exp[-r\lambda S/2],\]

which is (WT). ∎

## 2. Hostile check of individual heterogeneous production

The principal's operator-production claim survives the following checks, relative to the same source interfaces:

- At fixed tested C and p>0, heterogeneous independent coordinate laws preserve the R prefix/suffix conditional independence. Each unrevealed question is sampled using its own μ_j conditional kernel. No within-round product law is inserted.
- Exact fine-answer transport is coordinatewise. Its Q_i is the original event-conditioned live question/answer law, not an auxiliary posterior requiring independence. Varying answer alphabets changes only finite label sets and finite feature accuracy.
- The unaveraged Jensen-gap telescope gives Σ_live e_A,i≤p[L+Σ_Cκ_j] and the same for Bob. The question-law chain rule gives Σ_live d_i≤L for d_i=D(Q_XiYi||μ_i). Hence τ_i=(e_A,i+e_B,i)/p+d_i has Στ_i≤3L+2Σ_Cκ_j.
- The one-mode H lemma has no hidden uniform-coordinate assumption. For each i its raw norm identities and total mass p hold. Its local history kernels use its own μ_i, with Pinsker marginal drift≤√(d_i/2). The safe source constants D_i≤16τ_i and alignment≤4τ_i hold.
- Each coordinate's operational sampler is one all-input resource across that coordinate's histories and fresh questions. Different i may use different finite resources because only separate existence of a strategy for G_i is asserted. This is sufficient to compare with each ω_co(G_i).
- Feature compression is taken to zero at fixed finite family and p. Before Lin, eliminate the representation-dependent τ_i by the exact quadratic inversion defining Φ_K. The resulting (P) is continuous in the finite table at p>0. The table limit is then legitimate without convergence of raw resolvent errors.

I found no new missing production step at this interface. I have not independently certified every line of the inherited all-input sampler; this review does not turn its source status into external validation.

## 3. Universal relative-filter criterion from the initial report is false

The sufficient conditional implication (O)⇒quadratic repetition in my initial note remains mathematically valid. Its proposed **universal acquisition for every tested instance** is disproved by the principal's robust common-information construction. The derivation below checks the side-information issue explicitly.

Let an original scalar prefilter law have form ν(c)P_c(a)Q_c(b), and let a bounded nonnegative replacement filter factor as Σ_k λ_c,k f_c,k(a)g_c,k(b), with f,g≤1. Write x_c,k=P_c(f_c,k), y_c,k=Q_c(g_c,k), and p' for total filtered mass. Ignore zero xy terms. In the filtered law,

\[w(c,k)=\nu(c)\lambda_{c,k}x_{c,k}y_{c,k}/p'.\]

Given c,k the output laws P_cf/x and Q_cg/y are independent. Their divergences to the original local laws are bounded by −log x and −log y. The conditional chain rule thus gives

\[I(K;AB\mid C)+E_C D(R_{AB|C}\|P_CQ_C)
\le E_w\log\frac1{xy}
\le\log\frac{G_AG_B}{p'^2}.\tag{10}\]

For the last step, E_w(1/y)=G_A/p' and E_w(1/x)=G_B/p', followed by scalar Jensen. This controls common information conditional on the exposure flag; it does not require that the posterior flag law equal the original one.

Suppose the target has nuisance law R_m^⊗t independent of C, where R_m is uniform on unequal ordered pairs in [m]², m even. If a filtered output law is within TV β≤1/m of that target, and U^t,V^t are conditionally independent given (C,K), the principal's robust entropy argument gives

\[I(K;U^tV^t\mid C)\ge
t\{\log[4(1-1/m)]-2h(\tfrac12\sqrt{m\beta})-2\beta\log m\}-h(\beta).\tag{11}\]

The lower bound remains valid when the C marginal changes. Indeed, common-part mixture decomposition of two finite joint laws at TV β gives

\[|H_P(X\mid C)-H_Q(X\mid C)|\le\beta\log|X|+h(\beta),\]

independent of |C|: conditional entropy is concave, and adjoining the mixture flag raises it by at most h(β). For (11), collision probability P(U_i=V_i)≤β. Conditional product laws p,q have fidelity≤√(mΣ_a p_aq_a), so binary Fano bounds their entropy sum by 2log m−2log2+2h(error). Average over (C,K), use Jensen, then combine conditional entropy continuity on m^(2t) outputs with conditional independence. This proves (11) under arbitrary side flags.

Data processing and (10) imply

\[\log\max(G_A,G_B)\ge\log p'+\tfrac12\,\text{RHS of (11)}.\tag{12}\]

Use the line game of length L, gap ε=1/(2L−1), and its classical N=L² strategy with constant all-wins probability. Greedy testing supplies C₀ of size O(1/ε), tested p≥constant and remaining conditional loss≤ε/2. Append t=m=2L dummy rounds using the constant-answer base strategy, and test all of them. Their base success factor (1−ε)^t is bounded below. On tested dummy nuisance outputs use independent uniform [m] symbols and require inequality; on every live coordinate use deterministic distinct accepted symbols. The enlarged game has exactly the original gap and all repeated values, by forgetting nuisance symbols and by appending a fixed accepted pair.

The full tested event has probability bounded below, |C|=O(1/ε), and unchanged live loss≤ε/2. Conditional on its exposure flag, the dummy nuisance target is R_m^⊗t and is independent of that flag. A replacement filter with relative error β≤ε/8 has p' bounded below and normalized output TV≤β. Here mβ≤(1+ε)/8, so the coefficient in braces in (11) tends to a positive constant (~0.4533 nats). Therefore every such replacement factorization has B≥exp(Ω(1/ε)), whereas the proposed universal bound exp(κ ε|C|) remains bounded for fixed κ.

Thus universal every-instance acquisition (O) is disproved, even for legal classical strategies at bounded tested probability and near-perfect remaining success. An adaptive choice of tested set, removal of nuisance by semantic retraction, and direct entropy-increment estimates remain escapes. This is an obstruction to that filter interface, not to a general quadratic repetition theorem.

The exact scatter/common-information formula is prior work of Cuff–Permuter–Cover (2010), as corrected in the principal's continuation. The use here is a scoped robust interface obstruction, not a new definition or a claim to have discovered Wyner common information.

## 4. Alternative representation: what Jain's route can and cannot repair

Primary source read: Rahul Jain, [arXiv:2610.21410v1](https://arxiv.org/html/2610.21410v1), especially §§1.3–1.5, Proposition 3.4, Lemmas 4.1–4.2. It explicitly works with finite-dimensional tensor workspaces. Its parent conditioning budget is B_C=log(1/p_C)+|C|log(|A||B|), and the per-coordinate charges telescope beneath that budget. Therefore a standard-form transfer alone would produce an alternative cubic commuting mechanism, not general quadratic repetition.

The genuinely different operation is Lemma 4.2's exact marginal replacement:

\[\widetilde\nu=\int\beta_0(s)
(I_R\otimes L_s)\nu(I_R\otimes L_s)^*\,ds,
\quad L_s=(\rho^K)^{(1+is)/2}(\nu^K)^{-(1+is)/2}.\]

It matches ρ's retained marginal, controls measured divergence by the conditional relative-entropy difference, and preserves the original conditional question kernel. This can remove redundant comparison information without factoring the entire acceptance mask. However its general finite-von-Neumann transfer is not acquired here: one must prove the four-operator trace estimate in that setting, handle inverse powers at continuous zero spectrum in noncommutative Lp, and implement the canonical purifications and coherent-ensemble Uhlmann corrections in the correct local algebra while leaving question references untouched. Correlation-table closure alone proves none of those facts.

Even after those operations, removing the checked-answer parent charge would require another theorem. The scatter/common-information obstruction rules out simply demanding an exact classical separator with information O(log(1/p)); it does not rule out operator-valued histories or cancellation of direct entropy increments. No such answer-free allocation is proved in this review.

## 5. An exact direct-entropy repair of independent nuisance padding

There is a concrete repair beyond optimizing the factor masses or replacing the predicate. It directly cancels the entropy of an independent question-free register, including the triangle and scatter padding used in the obstructions above.

**Proposition (tensor entropy cancellation).** Let the original finite-tracial tested construction be a product of a base strategy in (M,τ) and a nuisance strategy in (N,υ), with state σ_M⊗σ_N. The nuisance answer POVMs and nuisance tested mask are independent of every referee question. Use product positive factorizations of the base and nuisance masks. Let p_b>0 and p_ν>0 be their tested masses. For the exposure potentials U_j,Z_j of the exact R telescope, one has

\[U_j^{\rm aug}=p_\nu U_j^{\rm base}+p_b U^{\nu},\qquad
Z_j^{\rm aug}=p_\nu Z_j^{\rm base}+p_b Z^{\nu}.\tag{13}\]

Here U^ν,Z^ν are fixed, independent of exposure stage. Therefore every entropy increment is exactly p_ν times its base increment. After dividing by the augmented event mass p_b p_ν, the normalized telescope budget is identical to the base budget.

**Proof.** The augmented coarse factors are F_j^k⊗F_ν^ℓ and H_j^k⊗H_ν^ℓ, because the nuisance part is independent of the questions being exposed. Positive bilinear masses factor. For f(t)=t log t with f(0)=0, joint functional calculus gives

\[f(A\otimes B)=f(A)\otimes B+A\otimes f(B),\qquad0\le A,B\le I.\tag{14}\]

This includes kernels by continuous extension. Insert (14) into the definition of U_j and sum product coefficients. The first term is p_ν U_j^base. The second is U^ν times the base stage mass. R's exact mass identity says that its average over flags is p_b at every j. This proves the first equality; the transposed identity proves the second. Taking differences proves the claim. ∎

R's individual squared resolvent errors are bounded by these Jensen-gap increments. Thus the augmented normalized error inherits the base entropy budget even when every exact factorization of the nuisance mask has exponentially large G_A or G_B. The finite feature compression remains legal; its coefficient-mass accuracy cost can worsen, but its positive error is sent to zero at fixed p_b p_ν. No algebra has been replaced by matrices.

The question-law cost also cancels: independence gives

\[P(\text{questions}\mid E_b\cap E_\nu)
=P(\text{questions}\mid E_b),\]

so its relative entropy is bounded by log(1/p_b), rather than log(1/(p_b p_ν)). This shows explicitly why the robust common-information/filter obstruction is not a direct-increment obstruction. The large classical separator entropy may be completely constant through the exposure and disappear from every increment.

This proposition repairs independent product nuisance padding, without changing the actual tested event or any conditional live table. It does not handle a general strategy that correlates nuisance outputs or workspace with the base questions. A general answer-free direct-increment theorem would have to identify and subtract the relevant invariant marginal without assuming this tensor factorization. Jain's conditional-relative-entropy subtraction is one possible representation for that operation, but its standard-form producer and its answer-free conditioning allocation remain unproved here.

## 6. Scientific accounting

The weighted threshold proof is a complete new scalar consequence of (P), and the heterogeneous R/H production was checked at the stated interfaces. Its game application retains their conditions and resource limitations: finite but potentially enormous feature dimension, sampler spectral cutoffs, arbitrary finite-tracial algebras, and no efficient or physical compiler.

[constructor_weighted_checks.py](constructor_weighted_checks.py) and [its output](constructor_weighted_checks.json) check the sparse-subset tilt, posterior inclusion probabilities, weighted loss identity, entropy identity, selected κ cost and derivative inequality using exact rational arithmetic on two nonproduct four-coordinate laws, including zero and unit gaps. They also check the safe numerical barrier coefficient. These diagnostics do not prove the scalar premise or replace the all-N proof.

The filter obstruction is complete after the supplied line-game and robust entropy inputs, with the exposure-flag and conditional-information identities proved above. The universal filter target in the initial report should be marked **disproved in its all-tested-sets form**. Its conditional implication remains valid. Exact tensor entropy cancellation is a constructive repair for independent padding, with the actual tested event preserved. General quadratic commuting repetition remains open in this work. A semantic quotient or an answer-free direct entropy allocation for general correlated strategies is still the decisive missing operation.
