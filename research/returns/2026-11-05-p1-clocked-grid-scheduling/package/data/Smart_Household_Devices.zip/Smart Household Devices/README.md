# Data from Smart Household Devices

This folder contain the data (in file Smart_Device.csv) used to generate Fig. S10

- **Smart Oven**: Use the data from '2025-09-06 09:00:00' to '2025-09-06 09:20:00'
- **Thermomix**: Use the data from '2025-09-06 13:42:00' to '2025-09-06 14:02:00'