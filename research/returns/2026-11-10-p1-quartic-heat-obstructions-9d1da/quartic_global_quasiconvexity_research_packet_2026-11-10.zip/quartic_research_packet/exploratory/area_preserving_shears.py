"""Exploratory correlated-shear search; all maps exactly area-preserving.
Numerical output is not a proof. No claim of certified quadrature.
"""
import numpy as np
from scipy.optimize import minimize
import json
U=np.diag([1.,0,1,0]);V=np.diag([0.,1,0,1]);C=np.array([[0,0,0,1],[0,0,-1,0],[0,-1,0,0],[1,0,0,0.]])

def rval(F,k):
 X=F.reshape(-1,4);Q=k*U-V+C;QX=X@Q;UX=X@U;VX=X@V
 q=np.sum(X*QX,1);u=np.sum(X*UX,1);v=np.sum(X*VX,1)
 al=1/(8*(k+1));be=.25
 val=al*q*q+be*u*v
 grad=(4*al*q[:,None]*QX+2*be*(v[:,None]*UX+u[:,None]*VX)).reshape(F.shape)
 return val,grad

def shear_map(theta,steps=3,modes=1,grid=48,ad=True):
 P=2*steps*modes;n=grid*grid
 xx=np.arange(grid)/grid;x,y=np.meshgrid(xx,xx,indexing='ij');X=np.stack([x.ravel(),y.ravel()],1)
 F=np.broadcast_to(np.eye(2),(n,2,2)).copy()
 if ad:dX=np.zeros((n,2,P));dF=np.zeros((n,2,2,P))
 for step in range(steps):
  r=step%2;q=1-r;T=X[:,q];s=np.zeros(n);p=np.zeros(n);p2=np.zeros(n)
  if ad:ds=np.zeros((n,P));dp=np.zeros((n,P))
  for m in range(1,modes+1):
   off=2*(step*modes+m-1);a,b=theta[off:off+2];w=2*np.pi*m;si=np.sin(w*T);co=np.cos(w*T)
   s+=(a*si+b*co)/w;p+=a*co-b*si;p2-=w*(a*si+b*co)
   if ad:ds[:,off]=si/w;ds[:,off+1]=co/w;dp[:,off]=co;dp[:,off+1]=-si
  if ad:
   ds+=p[:,None]*dX[:,q,:];dp+=p2[:,None]*dX[:,q,:]
   dF[:,r,:,:]+=p[:,None,None]*dF[:,q,:,:]+F[:,q,:,None]*dp[:,None,:]
   dX[:,r,:]+=ds
  F[:,r,:]+=p[:,None]*F[:,q,:];X[:,r]+=s
 return (X,F,dF) if ad else (X,F)

def problem(k,steps,modes,grid):
 P=2*steps*modes
 def fun(z,details=False):
  theta=z[:P];A=np.array([[z[P],z[P+1]],[0,z[P+2]]]);_,F,dF=shear_map(theta,steps,modes,grid)
  AF=np.einsum('ij,njl->nil',A,F);vals,D=rval(AF,k);va,Da=rval(A[None],k);base=va[0];Da=Da[0];delta=vals.mean()-base
  DA=np.einsum('nij,nkj->ik',D,F)/len(F)-Da
  DT=np.einsum('nij,ik,nkjp->p',D,A,dF)/len(F)
  db=np.array([Da[0,0],Da[0,1],Da[1,1]])
  de=np.concatenate([DT,[DA[0,0],DA[0,1],DA[1,1]]]);db=np.concatenate([np.zeros(P),db])
  obj=delta/base;grad=de/base-delta*db/base**2
  if details:return {'k':k,'steps':steps,'modes':modes,'grid':grid,'relative_gap_R':float(obj),'base_R':float(base),'delta_R':float(delta),'theta':theta.tolist(),'A':A.tolist(),'det_error':float(np.max(np.abs(np.linalg.det(F)-1))), 'mean_F_error':float(np.max(np.abs(F.mean(0)-np.eye(2))))}
  return obj,grad
 return fun

def run(k,steps,modes,grid,seed):
 P=2*steps*modes;rng=np.random.default_rng(seed);z=np.r_[rng.normal(size=P)*.4,[1.,.2,1.]]
 fun=problem(k,steps,modes,grid)
 res=minimize(fun,z,jac=True,method='L-BFGS-B',bounds=[(-2,2)]*P+[(-3,3)]*3,options={'maxiter':180,'ftol':1e-12,'gtol':1e-8,'maxls':30})
 d=fun(res.x,True);d.update(nit=int(res.nit),success=bool(res.success),message=str(res.message),seed=seed)
 print(json.dumps(d),flush=True)
 if d['relative_gap_R'] < -1e-7:
  for finer in [2*grid,4*grid]:
   print(json.dumps(problem(k,steps,modes,finer)(res.x,True)),flush=True)
 return d
if __name__=='__main__':
 for k in [1/3,0.34,0.5,1.]:
  for steps,modes in [(3,2),(5,1),(5,2)]:
   for seed in range(2):run(k,steps,modes,48,seed)
