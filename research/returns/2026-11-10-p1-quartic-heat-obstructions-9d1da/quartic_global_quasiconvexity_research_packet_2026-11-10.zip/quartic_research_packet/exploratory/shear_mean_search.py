"""Targeted exploratory search with correlated area-preserving shear maps.
All affine means eliminated analytically. Numerical output is not a certificate.
"""
import numpy as np
from scipy.optimize import minimize
from area_preserving_shears import shear_map
from fourier_search import data
import json

def problem(k,steps,modes,grid):
 P=2*steps*modes
 def fun(theta,details=False):
  _,F,dF=shear_map(theta,steps,modes,grid);G=(F-np.eye(2)).reshape(-1,4)
  val,D,H=data(G,k,True);c=val.mean();b=D.mean(0)
  ev=np.linalg.eigvalsh(H)
  A=-np.linalg.pinv(H,rcond=1e-13)@b
  delta=c+b@A/2
  _,Ds=data(G+A,k)
  ddelta=np.einsum('nij,nijp->p',Ds.reshape(-1,2,2),dF)/len(F)
  dc=np.einsum('nij,nijp->p',D.reshape(-1,2,2),dF)/len(F)
  value=delta/c;grad=ddelta/c-delta*dc/c**2
  if details:return {'k':k,'steps':steps,'modes':modes,'grid':grid,'relative_gap':float(value),'c':float(c),'gap':float(delta),'A':A.reshape(2,2).tolist(),'H_eigen':ev.tolist(),'theta':theta.tolist(),'det_error':float(np.max(np.abs(np.linalg.det(F)-1))), 'mean_F_error':float(np.max(np.abs(F.mean(0)-np.eye(2))))}
  return value,grad
 return fun

def run(k,steps,modes,grid,seed,init_amp=.8):
 P=2*steps*modes;rng=np.random.default_rng(seed);z=rng.normal(size=P)*init_amp
 fun=problem(k,steps,modes,grid)
 res=minimize(fun,z,jac=True,method='L-BFGS-B',bounds=[(-3,3)]*P,options={'maxiter':250,'ftol':1e-12,'gtol':1e-8,'maxls':30})
 d=fun(res.x,True);d.update(seed=seed,nit=int(res.nit),success=bool(res.success),message=str(res.message))
 print(json.dumps(d),flush=True)
 if d['relative_gap'] < -1e-7:
  for fine in [2*grid,4*grid]:print(json.dumps(problem(k,steps,modes,fine)(res.x,True)),flush=True)
 return d
if __name__=='__main__':
 for k in [.3334,.34,.4]:
  for steps,modes in [(3,2),(5,1),(5,2),(7,1)]:
   for seed in range(2):run(k,steps,modes,48,seed)
