"""Targeted endpoint incompressible R search, identity mean fixed.
Only exploratory numerical output; no asserted sign certificate.
"""
import numpy as np,json,pathlib
from scipy.optimize import minimize
from area_preserving_shears import shear_map,rval

def problem(k,steps,modes,grid):
 RI=(k+3)/8
 def fun(theta,details=False):
  _,F,dF=shear_map(theta,steps,modes,grid);G=F-np.eye(2)
  val,D=rval(F,k);vg,Dg=rval(G,k);delta=val.mean()-RI;c=vg.mean()
  dd=np.einsum('nij,nijp->p',D,dF)/len(F);dc=np.einsum('nij,nijp->p',Dg,dF)/len(F)
  value=delta/c;grad=dd/c-delta*dc/c**2
  if details:return {'k':k,'steps':steps,'modes':modes,'grid':grid,'relative_R_gap':float(value),'c_R':float(c),'gap_R':float(delta),'theta':theta.tolist(),'mean_F_error':float(np.max(np.abs(F.mean(0)-np.eye(2))))}
  return value,grad
 return fun

def optimize(k,steps,modes,grid,z):
 fun=problem(k,steps,modes,grid)
 res=minimize(fun,z,jac=True,method='L-BFGS-B',bounds=[(-3,3)]*len(z),options={'maxiter':300,'ftol':1e-12,'gtol':1e-8,'maxls':30})
 d=fun(res.x,True);d.update(nit=int(res.nit),success=bool(res.success),message=str(res.message));print(json.dumps(d),flush=True)
 print(json.dumps(problem(k,steps,modes,2*grid)(res.x,True)),flush=True)
 return res.x
if __name__=='__main__':
 rs=[json.loads(l) for l in pathlib.Path('/workspace/scratch/21b466b728a1/variational/shear_mean_results.jsonl').read_text().splitlines()]
 d=min(rs,key=lambda d:d['relative_gap']);old=np.array(d['theta']).reshape(7,1,2)
 for steps,modes in [(7,2),(11,2),(11,3)]:
  z=np.zeros((steps,modes,2));z[:7,:1]=old
  z=optimize(1/3,steps,modes,48,z.ravel())
