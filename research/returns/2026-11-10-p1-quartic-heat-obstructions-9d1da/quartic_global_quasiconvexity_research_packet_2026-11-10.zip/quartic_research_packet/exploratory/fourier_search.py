import numpy as np
from scipy.optimize import minimize
import json, sys, time
U=np.diag([1.,0,1,0]); V=np.diag([0.,1,0,1]); C=np.array([[0,0,0,1],[0,0,-1,0],[0,-1,0,0],[1,0,0,0.]])

def data(F,k,hess=False):
 Q=k*U-V+C; al=(3*k-1)/(8*(k+1)); be=(3*k-1)/4
 UF=F@U; VF=F@V; CF=F@C; QF=F@Q
 u=np.sum(F*UF,1); v=np.sum(F*VF,1); j=np.sum(F*CF,1)/2; q=np.sum(F*QF,1)
 val=al*q*q+be*u*v+j*j
 grad=4*al*q[:,None]*QF+2*be*(v[:,None]*UF+u[:,None]*VF)+2*j[:,None]*CF
 if not hess: return val,grad
 N=len(F)
 H=8*al*(QF.T@QF)/N+4*al*q.mean()*Q+4*be*(UF.T@VF+VF.T@UF)/N+2*be*(v.mean()*U+u.mean()*V)+2*(CF.T@CF)/N+2*j.mean()*C
 return val,grad,H

def run(k,nfreq,seed,steps=300):
 modes=[(i,j) for i in range(nfreq+1) for j in range(-nfreq,nfreq+1) if (i>0 or j>0) and max(abs(i),abs(j))<=nfreq]
 N=4*nfreq+1
 xx=np.arange(N)/N; x,y=np.meshgrid(xx,xx,indexing='ij'); pts=np.array([x.ravel(),y.ravel()]).T
 basis=[]
 for q in modes:
  norm=np.linalg.norm(q); q=np.array(q)/norm
  arg=2*np.pi*pts@(np.array(q)*norm)
  for trig in [np.cos(arg),np.sin(arg)]:
   for row in range(2):
    b=np.zeros((len(pts),4)); b[:,2*row:2*row+2]=trig[:,None]*q
    basis.append(b)
 B=np.stack(basis,axis=-1); B2=B.reshape(-1,B.shape[-1]); Np=len(pts)
 rng=np.random.default_rng(seed); z=rng.normal(size=B.shape[-1]); z/=np.linalg.norm(z)
 def fun(z,save=False):
  G=(B2@z).reshape(-1,4)
  val,grad,H=data(G,k,True); c=val.mean(); b=grad.mean(0)
  try: A=-np.linalg.solve(H,b)
  except np.linalg.LinAlgError: A=-np.linalg.pinv(H)@b
  delta=c+b@A/2
  _,d=data(G+A,k)
  dc=B2.T@grad.ravel()/Np
  dd=B2.T@d.ravel()/Np
  gr=dd/c-delta*dc/c**2
  if save: return dict(k=float(k),nfreq=nfreq,seed=seed,ratio=float(delta/c),c=float(c),A=A.tolist(),z=z.tolist(),modes=modes,eigen=np.linalg.eigvalsh(H).tolist())
  return delta/c,gr
 res=minimize(fun,z,jac=True,method='L-BFGS-B',options={'maxiter':steps,'ftol':1e-12,'gtol':1e-8,'maxls':30})
 d=fun(res.x,True);d.update(nit=int(res.nit),success=bool(res.success),message=str(res.message))
 print(json.dumps(d),flush=True)
 return d
if __name__=='__main__':
 for k in [0.34,0.4,0.6,1.,2.,5.,20.,100.]:
  for seed in range(3): run(k,2,seed,200)
