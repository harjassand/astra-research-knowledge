"""Exact checks of additional obstructions; no quasiconvexity verdict."""
import sympy as S

k, sx, ty, a, c, b = S.symbols('k sx ty a c b', real=True)
ell, n, m = 3*k-1, k+1, 3*k+1
Q = S.Matrix([[m*m*sx*sx/2, m*sx*ty],
              [m*sx*ty, ell*n*sx*sx/2+2*ty*ty]])
R90 = S.Matrix([[0,-1],[1,0]])
N = (a*sx*sx+c*ty*ty)*S.eye(2)+2*b*sx*ty*R90
sym_product = (Q*N+N.T*Q)/2
assert S.factor(Q.det()-m*m*ell*n*sx**4/4) == 0
expected = ((a*sx*sx+c*ty*ty)**2*Q.det()
            -b*b*sx*sx*ty*ty*(S.trace(Q)**2-4*Q.det()))
assert S.factor(sym_product.det()-expected) == 0
assert S.simplify(S.limit(expected.subs(ty,1)/sx**2, sx, 0)+4*b*b) == 0

P, Qv, R = S.symbols('P Qv R', real=True)
T = Qv*Qv-P*R
X = k*(T*T+P*P)-(1+R*R)+2*Qv*Qv
Z = T*R-P
W = (1+ell/4)*Qv+ell*(X*X+2*n*Z*Z)/(8*n*Qv**3)
lam = -ell*n/(2*Qv)
D = S.hessian(P*R-Qv*Qv, (P,Qv,R))
H = (S.hessian(W,(P,Qv,R))-lam*D).subs({k:1,P:0,Qv:2,R:0})
target = S.Matrix([[S.Rational(25,16),0,-S.Rational(21,4)],
                   [0,S.Rational(1531,64),0],
                   [-S.Rational(21,4),0,S.Rational(9,16)]])
assert H == target
v1, v2 = S.Matrix([0,3,0]), S.Matrix([3,0,28])
assert (v1.T*H*v1+v2.T*H*v2)[0] == -S.Rational(13545,64)
print('PASS: constant-system acoustic obstruction and failed mixed-coordinate candidate.')
print('The full original quasiconvexity inequality remains unresolved.')
