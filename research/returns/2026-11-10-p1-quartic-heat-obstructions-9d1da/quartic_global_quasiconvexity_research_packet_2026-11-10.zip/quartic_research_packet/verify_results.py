#!/usr/bin/env python3
"""Reproduce the finite exact results in this research packet.

Python standard library only. This checks a heat-flow obstruction and the
all-mean calculation. It does NOT prove or disprove global quasiconvexity.
"""
from fractions import Fraction as Q
from pathlib import Path
import json

from exact_fourier_gap import verify
from exact_mean_gap import optimize

HERE = Path(__file__).resolve().parent


def energy(data):
    return Q(verify(data)['integral_J'])


def heat_variation(data, i, j):
    """Exact first derivative of a polynomial of degree at most four.

    The normalized generator has Fourier multiplier -q_i q_j. The symmetric
    four-point identity below is EXACT for a quartic, not a numerical finite
    difference approximation.
    """
    def at(t):
        varied = dict(data)
        varied['modes'] = []
        for term in data['modes']:
            factor = 1 - t * term['q'][i] * term['q'][j]
            new = dict(term)
            for name in ('alpha', 'beta'):
                new[name] = [str(Q(v) * factor)
                             for v in term.get(name, [0, 0])]
            varied['modes'].append(new)
        return energy(varied)
    return (8 * (at(Q(1)) - at(Q(-1)))
            - (at(Q(2)) - at(Q(-2)))) / 12


def run():
    with open(HERE / 'examples' / 'heat_obstruction.json') as f:
        heat = json.load(f)
    k = Q(heat['k'])
    e0 = energy(heat)
    mat = [[heat_variation(heat, i, j) for j in range(2)]
           for i in range(2)]
    expected = [[Q(188732971, 13400000000), Q(0)],
                [Q(0), Q(3867031, 536000000)]]
    assert mat == expected
    assert e0 == Q(504146101, 53600000000)
    assert mat[0][0] > 0 and mat[1][1] > 0

    # Independent trigonometric-moment calculation of energy and trace.
    U, V, D = Q(44009, 40000), Q(22281, 40000), Q(1, 200)
    Up, Vp, Dp = -Q(36343, 5000), -Q(18687, 5000), Q(1, 20)
    weights = ((3*k-1)*(k*k+1)/(8*(k+1)),
               (3*k-1)/(4*(k+1)), (5*k+1)/(2*(k+1)))
    assert sum(w*z for w, z in zip(weights, (U, V, D))) == e0
    rate = sum(w*z for w, z in zip(weights, (Up, Vp, Dp)))
    assert rate == mat[0][0] + mat[1][1]
    assert rate == Q(142704373, 6700000000)

    with open(HERE / 'examples' / 'shear_with_cubic_moment.json') as f:
        shear = json.load(f)
    best = optimize(shear)
    assert best['finite_minimum']
    assert best['rank_H'] == 3
    assert best['b'] == ['0', '1/4', '1/4', '0']
    assert best['witness']['A'] == [['0', '-3/13'], ['0', '0']]
    assert Q(best['gap']) == Q(2485, 22464)
    assert not best['strict_negative']

    return {
        'status': 'Exact checks passed; full quasiconvexity question unresolved.',
        'heat': {
            'k': str(k), 'A': heat['A'], 'energy_at_zero_time': str(e0),
            'normalized_heat_derivative': str(rate),
            'first_variation_matrix': [[str(x) for x in row] for row in mat],
            'positive_definite': True,
            'is_quasiconvexity_counterexample': False,
            'reason': 'A=0 and original J_k is nonnegative pointwise.'
        },
        'singular_mean_elimination_example': best,
        'arithmetic': 'Exact rational Laurent convolution and rational linear algebra.'
    }


if __name__ == '__main__':
    print(json.dumps(run(), indent=2))
