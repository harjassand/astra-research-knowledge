import sympy as s
k,a,p,q=s.symbols('k a p q')
U=3*a**4/s.Integer(8)+a*a*(p*p+3*q*q)/8+3*p**4/s.Integer(128)+3*p*p*q*q/s.Integer(16)+9*q**4/s.Integer(64)
V=a**4/s.Integer(4)+a*a*(p*p+q*q)/8+(p**4+q**4+8*p*p*q*q)/64
D=a*a*(p-q)**2/8
E=(3*k-1)*(k*k+1)/(8*(k+1))*U+(3*k-1)/(4*(k+1))*V+(5*k+1)/(2*(k+1))*D
Et=s.factor(-a*s.diff(E,a)-4*p*s.diff(E,p)-2*q*s.diff(E,q))
print('Et general',Et)
z=s.factor(Et.subs({p:s.Rational(4,5),q:1}))
print('Et(p4/5,q1)',z)
print('Et(a1)',s.factor(z.subs(a,1)))
for kv in [s.Rational(1,3),s.Rational(67,200),s.Rational(17,50),s.Rational(7,20),s.Rational(1,2)]:
 print(kv,s.factor(z.subs({a:1,k:kv})))
