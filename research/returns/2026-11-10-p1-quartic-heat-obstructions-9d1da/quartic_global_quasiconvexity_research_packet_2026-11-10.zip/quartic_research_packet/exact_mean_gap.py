#!/usr/bin/env python3
"""Eliminate all affine means exactly for one rational compatible Fourier field.
Uses only Python standard library plus sibling exact_fourier_gap.py.
Input JSON: same k,modes as exact_fourier_gap.py; A is optional and ignored.
Output includes rational H,b,c, an optimal rational A (if finite) and exact gap.
"""
from fractions import Fraction as Q
from itertools import combinations
import json,sys
from exact_fourier_gap import verify

def gap(d,a):
 z=dict(d);z['A']=[[str(v) for v in a[:2]],[str(v) for v in a[2:]]]
 return Q(verify(z)['gap'])
def rref(mat):
 a=[list(row) for row in mat];m=len(a);n=len(a[0]);r=0;piv=[]
 for c in range(n):
  i=next((i for i in range(r,m) if a[i][c]),None)
  if i is None:continue
  a[r],a[i]=a[i],a[r];v=a[r][c];a[r]=[x/v for x in a[r]]
  for i in range(m):
   if i!=r and a[i][c]:
    v=a[i][c];a[i]=[x-v*y for x,y in zip(a[i],a[r])]
  piv.append(c);r+=1
  if r==m:break
 return a,piv

def det(mat):
 a=[list(row) for row in mat];n=len(a);v=Q(1)
 for c in range(n):
  i=next((i for i in range(c,n) if a[i][c]),None)
  if i is None:return Q(0)
  if i!=c:a[c],a[i]=a[i],a[c];v=-v
  p=a[c][c];v*=p
  for i in range(c+1,n):
   t=a[i][c]/p
   for j in range(c+1,n):a[i][j]-=t*a[c][j]
 return v

def optimize(d):
 zero=[Q(0)]*4;c=gap(d,zero);b=[];H=[[Q(0)]*4 for _ in range(4)];vp=[]
 for i in range(4):
  e=zero.copy();e[i]=Q(1);p=gap(d,e);e[i]=Q(-1);m=gap(d,e)
  b.append((p-m)/2);H[i][i]=p+m-2*c;vp.append(p)
 for i,j in combinations(range(4),2):
  e=zero.copy();e[i]=e[j]=Q(1);H[i][j]=H[j][i]=gap(d,e)-vp[i]-vp[j]+c
 psd=all(det([[H[i][j] for j in ix] for i in ix])>=0 for n in range(1,5) for ix in combinations(range(4),n))
 if not psd:raise ArithmeticError('Exact integrated Hessian is not PSD; this contradicts the accepted LH premise or indicates invalid input/code.')
 R,piv=rref([H[i]+[-b[i]] for i in range(4)])
 finite=4 not in piv
 if finite:
  A=zero.copy()
  for i,col in enumerate(piv):A[col]=R[i][4]
  predicted=c+sum(x*y for x,y in zip(b,A))/2
 else:
  RH,ph=rref(H);Z=None
  for free in [j for j in range(4) if j not in ph]:
   z=zero.copy();z[free]=Q(1)
   for i,col in enumerate(ph):z[col]=-RH[i][free]
   bz=sum(x*y for x,y in zip(b,z))
   if bz:Z=z;break
  if Z is None:raise ArithmeticError('Inconsistent range and nullspace calculations.')
  t=-(c+1)/bz;A=[t*v for v in Z];predicted=Q(-1)
 actual=gap(d,A)
 if actual!=predicted:raise ArithmeticError('Mean-elimination identity failed exact verification.')
 witness=dict(d);witness['A']=[[str(v) for v in A[:2]],[str(v) for v in A[2:]]]
 return {'finite_minimum':finite,'c':str(c),'b':list(map(str,b)),
  'H':[[str(v) for v in row] for row in H],'rank_H':len(rref(H)[1]),
  'gap':str(actual),'strict_negative':actual<0,'witness':witness,
  'arithmetic':'exact fractions; all 15 principal minors checked; rational Gaussian elimination'}
if __name__=='__main__':
 with open(sys.argv[1]) if len(sys.argv)>1 else sys.stdin as f:d=json.load(f)
 print(json.dumps(optimize(d),indent=2))
