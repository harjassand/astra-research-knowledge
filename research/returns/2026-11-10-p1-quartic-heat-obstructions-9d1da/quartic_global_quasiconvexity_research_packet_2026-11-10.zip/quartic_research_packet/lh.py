"""Self-contained symbolic derivation of the acoustic quadratic form."""
import sympy as s
x0,x1,x2,x3,k=s.symbols('x0 x1 x2 x3 k', real=True)
x=s.Matrix([x0,x1,x2,x3])
u=x0*x0+x1*x1
v=x2*x2+x3*x3
j=x0*x3-x1*x2
J=(3*k-1)*(k*u-v+2*j)**2/(8*(k+1))+(3*k-1)*u*v/4+j*j
p,q=s.symbols('p q',real=True)
H=s.Matrix([p,0,q,0]);R=s.factor((H.T*s.hessian(J,x)*H)[0]);M=s.hessian(R,x)/2
print('LH=',s.factor(R))
print('det',s.factor(M.det()))
for minor in [M[:2,:2],M[1:,1:]]:print('minor',s.factor(minor.det()))
print('diagF')
a,b,c=s.symbols('a b c')
print(s.factor(R.subs({x[0]:a,x[1]:0,x[2]:0,x[3]:b})))
print('H=e12',s.factor(R.subs({p:0,q:1})))
print('Q e12',M.subs({p:0,q:1}).applyfunc(s.factor))
print('Q e11',M.subs({p:1,q:0}).applyfunc(s.factor))
