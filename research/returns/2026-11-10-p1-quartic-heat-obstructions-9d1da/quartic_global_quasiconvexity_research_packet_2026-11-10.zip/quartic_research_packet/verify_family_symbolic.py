"""Finite symbolic checks supporting family_geometry.txt; no numerical assumptions."""
import sympy as s
x0,x1,x2,x3,k,p,q,t,eps=s.symbols('x0 x1 x2 x3 k p q t eps')
x=s.Matrix([x0,x1,x2,x3]);ell=3*k-1;n=k+1;m=3*k+1
u=x0*x0+x1*x1;v=x2*x2+x3*x3;j=x0*x3-x1*x2
J=ell*(k*u-v+2*j)**2/(8*n)+ell*u*v/4+j*j
H=s.hessian(J,x); V=s.Matrix([p,0,q,0]);LH=s.factor((V.T*H*V)[0]);M=s.hessian(LH,x)/2
assert s.factor(M.det()-9*p**4*q**4*ell**4/16)==0
assert s.factor(LH.subs({p:0,q:1})-ell*((x0-x3)**2+3*(x1+x2)**2)/(2*n)-2*x1*x1)==0
assert s.factor(LH.subs({p:1,q:0})-ell*(3*(k*x0+x3)**2+(k*x1-x2)**2)/(2*n)-2*x3*x3)==0
I=s.Matrix([1,0,0,1]);point=dict(zip(x,I));P=H.subs(point)-3*n*s.hessian(j,x)/2
assert s.factor((x.T*P*x)[0]/2-(m*x0+2*x3)**2/4-ell*n*x1*x1/4)==0
D=s.Matrix([2,0,0,-m]);E=t*D
remainder=s.factor(J.subs(dict(zip(x,I+E)),simultaneous=True)-J.subs(point)-sum(s.diff(J,xi).subs(point)*Ei for xi,Ei in zip(x,E))-3*n*(E[0]*E[3]-E[1]*E[2])/2)
assert s.factor(remainder+2*n*ell*t**3-J.subs(dict(zip(x,D)))*t**4)==0
R=s.Matrix([eps,-m*eps**2/2,1,-m*eps/2])
assert s.factor(R[0]*R[3]-R[1]*R[2])==0
assert s.factor((R.T*H.subs(point)*R)[0]-ell*n*m*m*eps**4/8)==0
assert s.factor((R.T*s.hessian(j*j,x).subs(point)*R)[0]-ell*ell*eps*eps/2)==0
FB=s.Matrix([x2,x3,k*x0,k*x1]);assert s.factor(J.subs(dict(zip(x,FB)),simultaneous=True)-k*k*J)==0
print('PASS: LH determinant, both axis SOS identities, translated Hessian, cubic obstruction, rank-one det-squared obstruction, and within-k symmetry.')
