#!/usr/bin/env python3
"""Exact rational original-J_k Fourier witness verifier.
phi=(1/(2*pi))*sum(alpha_q*sin(2*pi*q.x)+beta_q*cos(2*pi*q.x)).
Input JSON: k rational string, A 2x2 rational strings, modes objects with integer
q pair and rational alpha,beta pairs. Computes exact integral J(A+Dphi)-J(A).
This is a verifier, not a positivity theorem or an exhaustive search.
"""
from fractions import Fraction as Q
import json, sys
ZERO=(Q(0),Q(0))
def addz(a,b):return (a[0]+b[0],a[1]+b[1])
def mulz(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def clean(p):return {i:v for i,v in p.items() if v!=ZERO}
def add(p,q):
 r=dict(p)
 for i,v in q.items():r[i]=addz(r.get(i,ZERO),v)
 return clean(r)
def scale(p,c):return clean({i:(v[0]*c,v[1]*c) for i,v in p.items()})
def mul(p,q):
 r={}
 for i,a in p.items():
  for j,b in q.items():
   ij=(i[0]+j[0],i[1]+j[1]);r[ij]=addz(r.get(ij,ZERO),mulz(a,b))
 return clean(r)
def sq(p):return mul(p,p)
def const(a):return {} if a==0 else {(0,0):(a,Q(0))}
def rational(x):
 if isinstance(x,float):raise TypeError('Use exact rational strings, not floating-point inputs.')
 return Q(x)
def density(F,k):
 u=add(sq(F[0][0]),sq(F[1][0]));v=add(sq(F[0][1]),sq(F[1][1]))
 j=add(mul(F[0][0],F[1][1]),scale(mul(F[0][1],F[1][0]),-1))
 h=add(add(scale(u,k),scale(v,-1)),scale(j,2));ell=3*k-1;n=k+1
 return add(add(scale(sq(h),ell/(8*n)),scale(mul(u,v),ell/4)),sq(j))
def verify(d):
 k=rational(d['k'])
 if k<=Q(1,3):raise ValueError('k must exceed 1/3.')
 if len(d['A'])!=2 or any(len(r)!=2 for r in d['A']):raise ValueError('A must be 2x2.')
 A=[[rational(v) for v in row] for row in d['A']];F=[[const(v) for v in row] for row in A]
 for term in d.get('modes',[]):
  q=tuple(term['q'])
  if len(q)!=2 or any(type(v)!=int for v in q) or q==(0,0):raise ValueError('q must be nonzero integer pair.')
  al=list(map(rational,term['alpha']));be=list(map(rational,term.get('beta',[0,0])))
  if len(al)!=2 or len(be)!=2:raise ValueError('alpha,beta must be pairs.')
  qm=(-q[0],-q[1])
  for i in range(2):
   for j in range(2):
    z=(al[i]*q[j]/2,be[i]*q[j]/2)
    F[i][j]=add(F[i][j],{q:z,qm:(z[0],-z[1])})
 P=density(F,k);p0=P.get((0,0),ZERO)
 if p0[1]!=0:raise ArithmeticError('Nonreal constant coefficient from real input.')
 ja=density([[const(v) for v in row] for row in A],k).get((0,0),ZERO)[0];gap=p0[0]-ja
 return {'k':str(k),'integral_J':str(p0[0]),'J_A':str(ja),'gap':str(gap),'strict_negative':gap<0,
 'arithmetic':'exact fractions, finite Laurent convolution','density_fourier_terms':len(P),'input_modes':len(d.get('modes',[]))}
if __name__=='__main__':
 with open(sys.argv[1]) if len(sys.argv)>1 else sys.stdin as f:d=json.load(f)
 print(json.dumps(verify(d),indent=2))
