from fractions import Fraction as R
import sympy as s

def add(*ds):
 out={}
 for d in ds:
  for n,v in d.items():out[n]=out.get(n,0)+v
 return {n:v for n,v in out.items() if v!=0}
def sc(d,c):return {n:c*v for n,v in d.items() if c*v!=0}
def mul(d,e):
 out={}
 for (n,m),v in d.items():
  for (p,q),w in e.items():
   z=(n+p,m+q);out[z]=out.get(z,0)+v*w
 return {n:v for n,v in out.items() if v!=0}
def diff(d,i):return {n:v*s.I*n[i] for n,v in d.items() if n[i]!=0}
def heat(d,i,j):return {n:-v*n[i]*n[j] for n,v in d.items() if n[i]*n[j]!=0}
def co(d,e):return s.expand(mul(d,e).get((0,0),0))
def cos(n,m):return {(n,m):s.Rational(1,2),(-n,-m):s.Rational(1,2)}
f=add(cos(1,0),cos(0,1));g=add(sc(cos(2,0),s.Rational(1,5)),sc(cos(0,2),s.Rational(1,5)),mul(cos(1,0),cos(0,1)))
X=[diff(f,0),diff(g,0)];Y=[diff(f,1),diff(g,1)]
u=add(*(mul(z,z) for z in X));v=add(*(mul(z,z) for z in Y));det=add(mul(X[0],Y[1]),sc(mul(X[1],Y[0]),-1))
k=s.symbols('k');ell=3*k-1;n=k+1
U=co(u,u);V=co(u,v);D=co(det,det)
print('moments',U,co(v,v),V,D,'cross',co(u,det),co(v,det))
Es=s.factor(ell/(8*n)*(k*k*U+co(v,v)-2*k*V+4*k*co(u,det)-4*co(v,det)+4*D)+ell*V/4+D)
print('E',Es)
Mat=s.zeros(2)
for i in range(2):
 for j in range(i,2):
  HX=[heat(z,i,j) for z in X];HY=[heat(z,i,j) for z in Y]
  up=sc(add(*(mul(z,w) for z,w in zip(X,HX))),2)
  vp=sc(add(*(mul(z,w) for z,w in zip(Y,HY))),2)
  jp=add(mul(HX[0],Y[1]),mul(X[0],HY[1]),sc(mul(HX[1],Y[0]),-1),sc(mul(X[1],HY[0]),-1))
  q=add(sc(u,k),sc(v,-1),sc(det,2));qp=add(sc(up,k),sc(vp,-1),sc(jp,2))
  Ep=s.factor(ell/(4*n)*co(q,qp)+ell/4*(co(up,v)+co(u,vp))+2*co(det,jp))
  Mat[i,j]=Mat[j,i]=Ep
  print('direction',i,j,Ep)
print('trace',s.factor(s.trace(Mat)))
for kv in [s.Rational(17,50),s.Rational(67,200)]:
 M=Mat.subs(k,kv).applyfunc(s.factor); print('k',kv,'M',M,'det',s.factor(M.det()),'trace',s.factor(s.trace(M)))
