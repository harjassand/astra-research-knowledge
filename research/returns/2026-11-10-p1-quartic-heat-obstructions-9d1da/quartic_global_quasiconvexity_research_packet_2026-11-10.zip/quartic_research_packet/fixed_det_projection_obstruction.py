"""Exact matrix-measure obstruction. No compatible-gradient witness is claimed."""
from fractions import Fraction as Q

k = Q(17, 50)
ell, n = 3 * k - 1, k + 1

def det(F):
    a, b, c, d = F
    return a * d - b * c

def energy(F):
    a, b, c, d = F
    u, v, j = a*a+c*c, b*b+d*d, det(F)
    return ell*(k*u-v+2*j)**2/(8*n)+ell*u*v/4+j*j

I = (Q(1), Q(0), Q(0), Q(1))
Fs = [(Q(6,5),Q(0),Q(0),Q(5,6)),
      (Q(599,600),Q(11,150),Q(-11,2880),Q(721,720)),
      (Q(599,600),Q(-11,150),Q(11,2880),Q(721,720))]
ws = [Q(1,121),Q(60,121),Q(60,121)]
assert all(det(F)==1 for F in Fs)
assert tuple(sum(w*F[i] for w,F in zip(ws,Fs)) for i in range(4))==I
gap = sum(w*energy(F) for w,F in zip(ws,Fs))-energy(I)
assert gap==Q(-2716236809591,480146227200000000000)<0
print('All determinants 1; matrix barycenter I; original-density gap:',gap)
print('No compatible-gradient realization is supplied or claimed.')
