# Independent principal construction (before exchanging research results)

Date: 6 November 2026. Research question: can a thermal rare-boundary certificate yield a reference-safe, exact-Hamiltonian memory theorem without a Davies approximation or an input-dependent correlated-state assignment? N1645's unavailable theorem is not used as a premise.

## P1. Stationary-state logical-swap theorem

Let the finite physical system admit a fixed accessible subsystem identification H_S = C^d_L tensor H_A; let H_G = H_A tensor H_B include an arbitrary finite bath. Let H be any self-adjoint operator on C^d tensor H_G and let omega be any density matrix with [H,omega]=0. Set omega_G=Tr_L omega. This need not be a product state across A/B or commute with the logical algebra. Let {W_a}_{a=0}^{d^2-1} be a unitary orthogonal logical Weyl basis, Tr(W_a^*W_b)=d delta_ab and W_0=I. Define

q = d^{-2} sum_a Tr[omega [H,W_a]^*[H,W_a]].

The deterministic encoder E(rho)=rho tensor omega_G is implemented by swapping an unknown input into L of an actual joint state omega and discarding the old L. This leaves the bath marginal unchanged; it is not a positive consistent assignment on arbitrary preexisting S marginals. Let N_t=Tr_G Ad(exp(-itH)) E. For normalized maximally entangled Phi_RL,

1-F_e(N_t) <= min(1,t^2 q),
||N_t-id_d||_diamond <= min(2,2d |t| sqrt(q)).

These are mathematical access statements. Preparing omega and implementing the subsystem swap/readout are charged assumptions; the swap may be a highly nonlocal physical operation.

### Proof

Put P=Phi_RL tensor I_G, Xi=I_R/d tensor omega. Xi commutes with I_R tensor H and d^2 P Xi P = Phi_RL tensor omega_G (a direct matrix-unit calculation). Hence the entanglement failure equals

d^2 ||(I-P) U_t P Xi^{1/2}||_2^2.

Since (I-P)P=0, replace U_tP by [U_t,P]. Duhamel and stationarity imply

||(I-P)[U_t,P] Xi^{1/2}||_2 <= |t| ||[H,P] Xi^{1/2}||_2.

Here each integrand U_{t-s}[H,P]U_s Xi^{1/2} has the same Hilbert--Schmidt norm, because Xi^{1/2} commutes with U_s. The exact Bell expansion P=d^{-2} sum_a conjugate(W_a)_R tensor W_a,L tensor I_G gives

d^2 ||[H,P] Xi^{1/2}||_2^2 = d^{-2} sum_a Tr[omega [H,W_a]^*[H,W_a]]=q.

This proves the fidelity bound. The normalized-Choi inequality ||N-id||_diamond <= d ||J_N-Phi||_1 and Fuchs--van de Graaf give the stated diamond bound. Every reference-correlated input is thereby covered. No Markov, detailed-balance, bath reset, weak-coupling, temperature or geometry hypothesis is used.

## P2. Exact long-time noisy-admission condition

Let W=W_good+W_bad be a CPTP writing channel L to L tensor G, with both summands CP. Suppose W_good <=_CP kappa E and ||W_bad^*(I)||_infinity <= delta. For the same hold/read channel, entanglement failure is <= kappa t^2 q + delta, because failure is a positive linear functional of the encoded Choi state, CP order is preserved, and the bad Choi state has trace <=delta. Thus the diamond error is <=2d sqrt(kappa t^2 q+delta), capped by2. An additional diamond-norm writing/readout error contributes additively by contractivity.

This is a conditional bridge, not a noisy preparation construction. In particular CP domination by a perfect logical encoder forces the good writer to have no logical corruption at release. Exact support matters; small trace distance does not prove such domination. A sufficient physical form is a logical-neutral gauge map with Gibbs-subpreservation plus a flagged bad event. Generic terminal local noise need not have this form.

## P3. Thermodynamic-limit version and rare boundaries

The same Bell-projection proof should extend to an invariant state omega of a C*-dynamical system, a unital logical M_d subalgebra, and logical Weyl operators in the L2(omega) domain of the generator delta. Use Xi=tr_d tensor omega and stationarity in the GNS seminorm. Formal proof/check still needed before promoting this version.

In finite volume, if for every a the positive operator [H,W_a]^*[H,W_a] <= J_a^2 Q_a, then q<=d^{-2} sum J_a^2 omega(Q_a), even if Q_a does not commute with omega. If J_a is polynomial in system size and omega(Q_a)<=exp(-c n^eta), the lifetime lower bound is exp(c n^eta/2)/poly(n) at fixed fidelity. The decisive operation is proving these inequalities and a rare-tail estimate in the *actual perturbed interacting stationary state*, uniformly in bath volume. Commuting-reference Peierls estimates alone do not supply that operation.

## P4. Marginal-only preparation is insufficient: explicit obstruction

Two qubits S,B, H=g X_S tensor Z_B. For0<c<=1 define rho_+/-=(I tensor I +/- c Y_S tensor Z_B)/4. Both have identical maximally mixed S and B marginals, while after t=pi/(4g) their S marginals are (I +/- c Z)/2. Their trace-norm distance is2c. Thus zero marginal initialization error cannot control later physical outputs under a common exact local joint Hamiltonian. Full joint/reference-safe preparation or an explicitly proved quotient of inaccessible bath information is necessary.

## Priority status and intended challenge

P1 is a complete elementary stationary-projection/quantum-speed-limit derivation, not a historical-first claim. Compare against Alicki/Fannes/Horodecki dressed-observable memory, projected-Gibbs quantum bottlenecks, Petz recovery and finite-temperature phase transport. A May2026 BDL3D Lindbladian thermal-memory construction already excludes novelty in bare3D self-correction. Seek whether P1/P2 is known verbatim or a useful joint formulation; do not call routine inequalities a transformative advance. Any application to N1645 is currently unavailable because its code and exact bounds are missing.

The strongest target remains an explicit realistically noisy writer with a time-uniform admitted-basin guarantee for the same interacting bath, with a decoder and matched total-resource advantage. P1/P2 isolate sufficient operations but do not earn this target.
