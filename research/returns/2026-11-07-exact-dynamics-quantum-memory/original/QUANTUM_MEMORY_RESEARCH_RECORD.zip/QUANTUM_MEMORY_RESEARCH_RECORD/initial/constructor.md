# Independent constructor initial report: an operational thermal-correlation bridge

Written independently on 2026-11-06, before reading any peer's initial report.
Role: independent constructor, one of three researchers. No subagents spawned.

## Result and status

I obtain a self-contained, finite-dimensional theorem converting equilibrium
autocorrelation bounds for an accessible exact Pauli algebra into an explicit
write–hold–read quantum channel. It allows the initial memory and bath to be
arbitrarily correlated in their **joint interacting Gibbs state**, and allows an
arbitrary reference-entangled input. Its error has the same long-time scale as
the thermal autocorrelation bound, without a global Gibbs-density domination
constant and without a square-root loss in that time scale.

The nontrivial operation is a deterministic logical SWAP, followed by a Pauli
randomization of the complete memory channel. A real-time thermal filter controls
the disturbance caused by removing the initial logical–gauge correlations. This
is more than a short-time Hamiltonian perturbation estimate: HOLD is the exact
unchanged Hamiltonian, and the theorem applies throughout any time window in
which its equilibrium hypotheses are proved.

**PROVED HERE, subject to mathematical cross-check:** the theorem and corollaries
below. **CONDITIONAL:** a useful finite-resource implementation, because an
accessible exact logical algebra, its circuit costs and a joint-process control
error must be supplied. **NOT ESTABLISHED:** applicability to N1645, novelty of
the bridge, a constant-rate noisy access threshold, efficient generic interacting
thermal preparation, any experimental device or an advantage over active QEC.

## Governing source and acquisition boundary

I read root `AGENTS.md`, the research stage of
`outputs/RESEARCH_TO_PUBLICATION_WORKFLOW.md`, the pinned N1645 packet and its
complete visible update. The current source manifest identifies repository
`harjassand/astra-research-knowledge` revision
`78ff1e3a865e3d0a05af901f77eb1ffd128b00d4` (the initial brief named
`3918bf6eb69e3b8e902bcbeaae3c5a72f26d6b62`; principal subsequently supplied this
new exact source pin). Local files:

- `../sources/N1645.json`, SHA256
  `3a435021097019a34398aec5a9eee055247917ef12d438e4685f375074c3be01`.
- `../sources/DOTS_VISIBLE_UPDATE.txt`, SHA256
  `ed3c13e3785d4dd015ef3537f1e95ec5d7a4820bea4f51c49307ce03d08e26dc`.
- `../sources/SOURCE_MANIFEST.json` records the exact raw GitHub URLs.

N1645 remains a visible-only report. Its original theorem/code/bounds/review
artifacts are unavailable. I have not retried, reconstructed or inferred that
package. In particular, nothing in the source establishes the Pauli-algebra
interface or thermal autocorrelation inequality required below. N1646, N1649,
N1653 and N1694 are not dependencies of this theorem; I did not compose their
distinct models or access contracts.

## 1. Exact physical setup and protocol

Let the physically accessible memory Hilbert space be `S`, and let `B` be a
finite spin bath of arbitrary dimension. Suppose an identified system-only
unitary

\[
 V:S\longrightarrow L\otimes A,\qquad L\cong\mathbb C^2
\]

exposes an exact logical qubit algebra. This requires `dim(S)` even; no code
subspace postselection is allowed. Set `G=A⊗B`. After changing representation by
`V⊗I_B`, let `H` denote the **actual total Hamiltonian** on `L⊗G`, including all
memory–bath interactions, and let

\[
 \tau=Z^{-1}e^{-\beta H},\quad U_t=e^{-itH},\quad
 \tau_G=\operatorname{Tr}_L\tau,\qquad 0<\beta<\infty.
\]

Units are `ℏ=k_B=1`. No factorization of `τ`, weak coupling, Markovianity,
commuting Hamiltonian or bath reset is assumed. The Pauli observables
`P=X,Y,Z` act on `L` and trivially on `G`; their physical representatives act on
`S` only. Define

\[
 P(t)=U_t^\dagger P U_t,\qquad
 e_P(t)=\operatorname{Tr}\tau\,[P(t)-P]^2.
\]

These are nonnegative, at most four, and even in `t`.

The protocol, with an external input qubit `Q`, is:

1. Choose a uniformly random `q∈{I,X,Y,Z}` and apply `q` to `Q`.
2. Apply `V` to `S`, SWAP `Q` with the exposed `L`, apply `V†` to `S`, and
   discard the old `Q`. The old logical state and any of its bath correlations
   leave with that discarded system. All gauge/bath degrees of freedom remain.
3. HOLD under the original total Hamiltonian for time `t`.
4. Apply `V` to `S`, output `L`, discard `A`, and apply `q†` to the output.

The two classical random bits are stored until readout and their storage/control
costs are charged. Step 2 is deterministic and CPTP, not postselection. With an
arbitrary input `ρ_RQ` independent of the resource `τ`, it yields exactly
`ρ_RL⊗τ_G`; thus it works coherently with any external reference `R`.

Without steps 1 and the last Pauli correction the effective qubit channel is

\[
 T_t(\rho)=\operatorname{Tr}_G
 [U_t(\rho\otimes\tau_G)U_t^\dagger].                 \tag{1}
\]

The randomized protocol is its Pauli twirl `\widetilde T_t`.

## 2. Formal operational theorem

Define

\[
 k_\beta(s)=\beta^{-1}\operatorname{sech}(\pi s/\beta),\qquad
 b_Q=\int_{\mathbb R} k_\beta(s)e_Q(s)\,ds\quad(Q=X,Y,Z),
 \quad b_I=0.
\]

**Theorem 1.** In the preceding exact physical setup, with
`d⋄(Φ,Ψ)=½‖Φ−Ψ‖⋄`,

\[
 d_\diamond(\widetilde T_t,\mathrm{id})
 \le {1\over32}\sum_{P=X,Y,Z}\sum_{Q=I,X,Y,Z}
       \bigl(\sqrt{e_P(t)}+2\sqrt{b_Q}\bigr)^2.         \tag{2}
\]

The constants are independent of the bath size, memory dimension, minimum
Gibbs eigenvalue and logical–bath mutual information. Equation (2) is valid for
every real `t`, with no accumulated noisy-generator replacement error.

If `e_P(t)≤ε(t)` and `b_P≤b` for all three Pauli observables, then

\[
 d_\diamond(\widetilde T_t,\mathrm{id})
 \le {3\over8}\epsilon(t)+{9\over8}\sqrt{\epsilon(t)b}
                      +{9\over8}b
 \le {15\over16}\epsilon(t)+{27\over16}b.             \tag{3}
\]

All upper bounds may of course be capped at one.

### Proof: the thermal filter

The elementary Fourier transform of `k_β` is

\[
 \int_{\mathbb R}k_\beta(s)e^{i\omega s}\,ds
       =\operatorname{sech}(\beta\omega/2).
\]

Let `H|n⟩=E_n|n⟩`, `p_n=e^{-βE_n}/Z`. Since `P=P†` and `P²=I`,

\[
 e_P(s)=2-2\operatorname{Re}\sum_{m,n}
                     p_n |P_{mn}|^2e^{i(E_m-E_n)s}.
\]

Pairing `(m,n)` with `(n,m)` and using

\[
 {p_m+p_n\over2}\operatorname{sech}
           (\beta(E_m-E_n)/2)=\sqrt{p_mp_n}
\]

gives the exact identity

\[
 b_P=2-2\operatorname{Tr}(\sqrt\tau P\sqrt\tau P)
     =\|[P,\sqrt\tau]\|_2^2.                          \tag{4}
\]

This is twice the Wigner–Yanase skew information. It uses the actual joint
Gibbs state and the same Hamiltonian that generates HOLD. It is precisely the
step that is unavailable for an arbitrary stationary state with unrelated
modular dynamics.

### Proof: exact SWAP channel and entanglement fidelity

Let

\[
 \Omega={I_L\over2}\otimes\tau_G
       ={1\over4}\sum_{Q=I,X,Y,Z}Q\tau Q.
\]

For the channel (1), expanding a maximally entangled qubit pair in Pauli
operators yields

\[
 1-F_e(T_t)
   ={1\over8}\sum_{P=X,Y,Z}
             \operatorname{Tr}\Omega[P(t)-P]^2.       \tag{5}
\]

For completeness, `F_e(T)=¼[1+Σ_{P=X,Y,Z}½Tr(P T(P))]` and
`Tr ΩP(t)P=½Tr(P T_t(P))`; the latter is real because `P` commutes with
`Ω`. This proves (5), including its normalization.

Put `Δ_P=P(t)−P`. Then `‖Δ_P‖∞≤2`, and

\[
 \begin{split}
 [\operatorname{Tr}(Q\tau Q)\Delta_P^2]^{1/2}
 &=\|\Delta_P Q\sqrt\tau\|_2\\
 &\le\|\Delta_P\sqrt\tau Q\|_2
        +\|\Delta_P[Q,\sqrt\tau]\|_2\\
 &\le\sqrt{e_P(t)}+2\sqrt{b_Q}.                     \tag{6}
 \end{split}
\]

The last equality for `b_Q` is (4); for `Q=I` the commutator is zero. Average
the square of (6) over `Q`, then substitute into (5). This gives the right-hand
side of (2) as an upper bound on `1−F_e(T_t)`.

Finally, Pauli twirling produces a Pauli channel and preserves entanglement
fidelity. Its identity-Pauli probability is exactly `F_e(T_t)`. The half diamond
distance of a Pauli channel from identity is exactly its total nonidentity
probability: convexity gives the upper bound and a maximally entangled input
gives the matching lower bound by orthogonal Bell states. Thus
`d⋄(\widetilde T_t,id)=1−F_e(T_t)`, proving (2). Uniform substitution gives
the first inequality (3), and `√(εb)≤(ε+b)/2` gives the second. QED.

### Why a naive trace-norm proof is weaker

One could use (4) to show that `Ω` is close to `τ` in trace norm, compare their
autocorrelations, and obtain an additive `O(√b)` disturbance. That would lose
half the exponential suppression exponent. Equation (6) moves the Pauli through
`√τ` before squaring, retaining `O(ε+b)` instead. No operator ordering such as
`Ω≤Cτ` is needed. For macroscopic local noisy writes a crude such `C` can be
exponential in the volume, so avoiding that constant is a substantive feature.

## 3. Long-time corollary with all constants

Suppose, for every `P=X,Y,Z`,

\[
 e_P(s)\le\kappa |s|\quad (|s|\le T_*).
\]

Outside the proved window use only `e_P≤4`. Let `G_C=Σ_{n≥0}(-1)^n/(2n+1)²`
be Catalan's constant. Since

\[
 \int k_\beta(s)|s|ds={4G_C\beta\over\pi^2},\qquad
 \int_{|s|>T_*}k_\beta(s)ds
       ={4\over\pi}\arctan(e^{-\pi T_*/\beta}),
\]

we obtain

\[
 b\le {4G_C\over\pi^2}\beta\kappa
      +{16\over\pi}e^{-\pi T_*/\beta}.               \tag{7}
\]

Combining (3) and (7), for `0≤t≤T_*`,

\[
 d_\diamond(\widetilde T_t,id)
 \le {15\over16}\kappa t
       +{27G_C\over4\pi^2}\beta\kappa
       +{27\over\pi}e^{-\pi T_*/\beta}.              \tag{8}
\]

Thus if a family has `κ_L=poly(L)e^{-aL^ν}` (or any other verified suppression
scale), `β` grows at most polynomially, and the correlation theorem holds over
a sufficiently long window, the explicit operational channel has the same
stretched-exponential storage time up to constants/polynomials. This is a
conditional scaling statement; no such `κ_L`, `ν`, temperature or window is
supplied by the visible N1645 update.

## 4. Finite access errors and the exact remaining noise gate

**Corollary 2 (finite access implementation).** Suppose the implemented writer
and reader, including finite control durations, background memory–bath dynamics,
ancillas and the Pauli frame, are within half diamond errors `η_W` and `η_R` of
the ideal **joint** maps specified above. Suppose the resource state `σ_SB`
satisfies, in the exposed representation,

\[
 {1\over2}\|\operatorname{Tr}_L\sigma-	au_G\|_1\le\zeta.
\]

Then the resulting input-to-output memory channel obeys (2), (3), or (8), with
`η_W+η_R+ζ` added. This remains uniform in HOLD time because subsequent exact
joint unitary evolution and final channels contract trace distance. No fresh
bath, renewal assumption or memoryless noise is used.

Only the gauge–bath marginal must approximate `τ_G`: initial logical–gauge
correlations are discarded by SWAP. This is formally weaker than preparing the
entire interacting Gibbs state, but does not by itself make preparation easy.
The required gauge state is the Gibbs state of the generally nonlocal
Hamiltonian of mean force
`−β^{-1}log Tr_L(e^{-βH})` up to an additive scalar.

If `V` has `g_V` physical gates, elementary SWAP costs `g_swap`, and all gates
admit suitable joint-location diamond errors `δ_j`, the elementary hybrid bound
gives access error at most their sum. The ideal protocol uses about
`3g_V+g_swap+2` gates, plus routing, ancilla disposal and storage of two classical
bits. All these gates occur at access, not throughout HOLD.

This corollary does **not** establish a useful constant-rate noisy access
threshold. At fixed physical error `p`, a large circuit may have total error
`Θ(g_Vp)`. Calling `V` finite rather than efficient does not repair this. Either
one must give a fault-tolerant implementation compatible with the same joint
bath model, or prove a stronger writer basin allowing many correctable faults
without globally small joint-process error. Ordinary continuity is the last
small-error interface step, not the main theorem.

## 5. Obstruction and failed routes preserved

### A. Local equilibrium data do not certify an encoder

Let a distance-`d` quantum code isometrically encode a qubit by `E`. Its uniformly
mixed code state `χ=E(I/2)` has the same reduced state on every region supporting
fewer than `d` sites as every encoded state. Compare two CPTP writers:

- `W_good(ρ)=EρE†`;
- `W_bad(ρ)=χ Trρ`.

Every such local marginal after writing is identical for both writers and for
every input. Yet the second writer is a replacer channel, so even at `t=0` a
reference-entangled input has lost its entanglement with the memory. For example,
after ideal decoding its entanglement fidelity is `1/4`, whereas the first
writer decodes perfectly. Therefore a criterion based only on small-region
thermal marginals cannot establish the noisy-write gate. This remains true even
if the later dynamics is exactly identity.

### B. Per-site error rates do not imply local-stochastic fault control

For any nontrivial logical Pauli `Z̄` of large support, the noise channel
`(1−p)id+p Ad_{Z̄}` has local error probability at most `p` at every site in
that support, but logical error probability `p` independent of distance.
It violates the multiplicative joint-support condition required by a
local-stochastic model. Arbitrary bath correlations cannot be silently replaced
by independent noise or by this stronger fault condition. A physically bounded
system–bath fault-amplitude theorem can give stronger control, but must be
proved under its own local norm/time hypotheses.

### C. Generic global Gibbs domination is an expensive sufficient condition

An alternative safe theorem would dominate each prepared gauge state by
`c τ_G` and multiply the storage error by `c`. This is valid but can have
`log c=Θ(p volume)` after extensive faults, defeating a storage barrier whose
exponent scales only with a length or smaller power of volume. It is not a
general constant-rate noisy-writer solution. Theorem 1 avoids domination for the
ideal logical reset but does not prove robustness under arbitrary such faults.

### D. Exact logical algebra is an access assumption

Abstract anticommuting Hermitian unitaries on `S` do imply an abstract tensor
factorization `S≅C²⊗A`, by pairing their eigenspaces. This gives no efficient
local circuit for `V`. If the slow observables only exist on a low-energy
subspace, or involve bath operators, the present exact SWAP construction is not
available as stated. A heralded projection can destroy determinism and cannot be
silently substituted. Approximate algebra rounding plus physical access is an
additional research problem, not proved here.

## 6. Primary-source predecessor and priority audit

No primary theorem is imported into the proof of Theorem 1: the finite spectral
calculation, Pauli-twirl identity and inequalities are supplied above. The broad
idea of relating thermal correlations to encoded fidelity is established, and
the access/reset operation itself is established. Accordingly this report makes
**no claim of priority**. Closest checked predecessors and conflicts:

1. R. Alicki and M. Fannes, *Decay of fidelity in terms of correlation functions*,
   PRA **79**, 012316 (2009), arXiv:0809.4180v1 (24 September 2008).
   [Primary full text](https://arxiv.org/html/0809.4180), especially Sections 2–4,
   equations (11)–(14) and the product assignment map following (14). They
   already formulate an encoded matrix algebra, a correlated faithful reference
   state, exact or CP dynamics, CPTP preparation and correlation/fidelity
   relations. Their construction explicitly includes logical replacement leaving
   the syndrome marginal fixed. I must credit this, not rename it a new write
   operation. The quantitative candidate worth further novelty checking is the
   dimension-free `O(ε(t)+∫k_β ε)` reference-uniform upgrade using (4) and (6),
   rather than an uncontrolled modular-analytic preparation norm.

2. S. Balasubramanian, M. Davydova and T.-C. Lin, *A passive self-correcting
   quantum memory in three dimensions*, arXiv:2605.10943v1 (11 May 2026).
   [Primary full text](https://arxiv.org/html/2605.10943), Sections 1.1, 1.3 and
   2.5, Theorem 1.1, Theorem 2.6 and equations (48)–(49). The checked formulation
   supplies a 3D bounded-density local CSS stabilizer family and thermal logical
   encoding under specified stationary local Lindbladian dynamics. Section 1.3
   explicitly leaves efficient passive initialization unaddressed. It is a major
   predecessor for any general 3D exponential-lifetime claim; it does not itself
   prove this report's arbitrary joint-Hamiltonian thermal hypothesis or a noisy
   access protocol. No theorem from that manuscript is used here.

3. R. Ma, V. Khemani and S. Sang, *Circuit-based characterization of
   finite-temperature quantum phases and self-correcting quantum memory*,
   arXiv:2509.15204v3 (16 October 2026), PRX Quantum DOI
   [10.1103/sh48-wmy4](https://journals.aps.org/prxquantum/abstract/10.1103/sh48-wmy4).
   [Primary full text](https://arxiv.org/html/2509.15204v3), Section IV,
   Theorems 2–3. They give explicit encoding/decoding channel constructions under
   stable-clustering and local-reversibility hypotheses, and a long memory bound
   for a quasi-local Lindbladian having the Gibbs state as a frustration-free
   stationary state. This is strong recent access/thermal-phase prior art; it
   cannot be automatically applied to the same exact spin–bath dynamics used
   here. No theorem from it is imported.

4. N. Drechsler, Y. Oreg and D. Aharonov, *Autonomous Quantum Memories from
   Classical Stochastic Processes*, arXiv:2610.05589v1 (4 October 2026).
   [Primary full text](https://arxiv.org/html/2610.05589), Sections 2.1.5 and
   4.6. The checked paper develops the effective logical channel and Pauli
   structure for CSS/syndrome-based dynamics. Its asynchronous and Floquet
   constructions have their own assumptions. It is another direct conflict with
   any claim that the elementary Pauli-channel/fidelity step is new.

Recent-2026 Zenodo searches used combinations of quantum memory, thermal,
autocorrelation, encoding, exact dynamics, Gibbs, passive, 3D and Sandhu. They
found experimental datasets and broad speculative deposits, but no inspected
primary source establishing priority for the specific inequality (2). This is
**not an absence theorem or a completed novelty audit**. For example,
[Zenodo 20778451](https://zenodo.org/records/20778451), a June 2026 Aksman deposit,
invokes the 3D sheaf-code construction while making much broader claims; its
metadata does not establish the exact dynamical/access theorem needed here. I
did not import those claims or any biological part of that deposit. The
existing-machinery researcher should identify any more specific recent Zenodo
record singled out in the user's full context before a priority conclusion.

The acquired PDFs and extracted text of Alicki–Fannes, Ma–Khemani–Sang and
Drechsler–Oreg–Aharonov are under `../literature/constructor/`. Detailed primary
checks above are against the actual full text, not search snippets.

## 7. Verification and resource comparison

`../literature/constructor/check_thermal_swap_bridge.py` checks thermal spectral
identity (4), exact Choi identity (5), inequality (2), and the Pauli probability
normalizations for 360 random finite-Hamiltonian cases with gauge dimensions
2, 3 and 5, inverse temperatures 0.1, 1 and 5, and five HOLD times. All pass;
largest equality discrepancy is about `2.7e−15`. Report:
`../literature/constructor/thermal_swap_bridge_check.json`.

These checks catch finite algebra and normalization mistakes. They neither prove
the theorem, certify asymptotic memory scaling, verify N1645, establish novelty,
nor test a physical device. The written argument is the proof.

A full-cost comparison must include:

- system and accessible bath size, geometry and coupling knowledge/precision;
- preparation or cooling to a resource with the required gauge–bath marginal,
  with mixing time and reset cost explicitly charged;
- the actual local circuit/routing, gate time, ancillas, classical frame bits,
  calibration and achievable joint access error;
- refrigeration, Hamiltonian switching, readout, disposal and repeated-use reset;
- the same hardware, rates, cooling, control, routing and classical assistance
  granted to an active-QEC comparator.

If an “active strategy” is allowed to leave hardware idle, its admissible
strategy set contains this passive protocol; its optimized error cannot be worse
under the same constraints. Any nontrivial advantage statement must specify the
resource objective (for example control operations or power) and a concrete
competing operating point, rather than declare that passive storage beats the
unrestricted active optimum. The theorem earns a possible reduction of control
operations during HOLD, conditional on access and preparation costs. No numerical
or asymptotic total-cost advantage has been proved.

## 8. Strongest next operation and proposed cross-challenges

For N1645, first obtain an actual exact **source theorem** proving slow
equilibrium correlations of a system-accessible exact Pauli algebra and identify
its physical circuit `V`. The missing archive is not to be reconstructed or
retried; absent that interface, applicability remains UNKNOWN.

For an independent new construction, choose a concrete Hamiltonian family whose
logical algebra and stationary thermal correlations can be proved, then attack
a writer basin accepting constant-rate local physical faults under the same
spin–bath model. Theorem 1 removes the initial logical–bath correlation obstacle
for ideal reset and small total access errors. It does not remove the much
stronger constant-density-fault or preparation obstruction.

The hostile audit should target (i) the KMS spectral pairing in (4), (ii) Choi
normalization and reference-uniform Pauli randomization, (iii) whether the
system-only exact algebra is available in the inherited model, and (iv) whether
any noise claim inadvertently uses only a reduced channel or a fresh bath.
The machinery audit should target Alicki–Fannes and quantum-skew-information
literature for the precise quantitative inequality (2), while preserving its
elementary/established components and avoiding a broad novelty claim.

## Status ledger

| Claim | Status |
|---|---|
| Thermal filter identity (4) | PROVED here; finite checks supplement proof |
| Explicit deterministic SWAP writer with correlated Gibbs resource | PROVED here; established operation credited |
| Theorem 1 operational diamond bound | PROVED here, awaiting cross-check |
| Same lifetime scale as slow thermal correlations | CONDITIONAL corollary with explicit hypotheses |
| Small total joint access-error robustness | PROVED continuity corollary |
| Constant-rate noisy local write/read threshold | OPEN |
| Efficient preparation of generic interacting gauge–bath marginal | OPEN |
| Application to N1645 | UNKNOWN from available visible-only source |
| Novelty of the quantitative bridge | NOT ESTABLISHED |
| Device or practical advantage | NOT ESTABLISHED |

Memory informed only the existing focus on the noisy-write/long-HOLD gate and
matched full-cost comparison, not a mathematical premise: MEMORY.md lines
76–109, rollout `01a1a757-d574-7b83-994a-f34ae9273a90`.
