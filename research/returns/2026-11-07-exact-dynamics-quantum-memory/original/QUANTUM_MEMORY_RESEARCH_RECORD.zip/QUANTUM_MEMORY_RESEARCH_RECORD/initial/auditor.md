# Independent hostile audit: N1645 and an operational exact-dynamics repair

Date: 6 November 2026, Australia/Brisbane. Researcher: hostile mathematical auditor. This initial report was written without reading the other researchers' intermediate conclusions. It is to remain unaltered after exchange; corrections belong in a separate challenge report.

## 1. Governing evidence and actual result of this audit

The assigned governing source is `sources/N1645.json`, content version `8568a0701e531c32a3047a2aa824266345bcc6da99638759506e0bab8baa9101`, originally supplied under repository `harjassand/astra-research-knowledge` revision `3918bf6eb69e3b8e902bcbeaae3c5a72f26d6b62`, together with `sources/DOTS_VISIBLE_UPDATE.txt`. The original visible-update evidence hash is `ed3c13e3785d4dd015ef3537f1e95ec5d7a4820bea4f51c49307ce03d08e26dc`. A later principal message identifies a newer raw-source manifest at revision `78ff1e3a865e3d0a05af901f77eb1ffd128b00d4`; this report has not silently substituted its distinct models for N1645.

The visible update reports a restricted 3D encoded-qubit result under weak generic local interaction with a spin environment, exact dynamics, an actual interacting thermal resource, ideal logical write/read, and enormous existence constants. It supplies no theorem, code, norm, temperature, size/time/error relation, proof, or review artifacts. Consequently this report does **not** reprove or disprove N1645. Its review/check claims remain producer-reported at that source scope. No attempt was made to acquire its missing archive.

The substantive work here is:

1. A sharp two-spin obstruction to interpreting conditional Gibbs preparation as a writer for an unknown qubit.
2. A complete conditional theorem that gives a deterministic writer using one fixed interacting Gibbs resource, a system-supported logical Pauli algebra, exact joint Hamiltonian dynamics, a system-only decoder, and a diamond-norm guarantee for arbitrary reference-entangled inputs. Its decisive premise is a thermally small Hamiltonian commutator, not a Markov approximation.
3. An elementary time-uniform access-error transfer lemma and explicit counterexamples to weaker norm, weak-coupling, and stationarity imports.

The implication theorems below are proved here. Their applicability to an actual 3D family and their historical novelty are **not established**. The second theorem identifies a concrete operation that could be checked against an eventually available model without borrowing N1646, N1649, N1653, or N1694.

Throughout, finite-dimensional Hilbert spaces are assumed unless stated otherwise, and hbar=1. Trace distance is half the trace norm; channel error is half the diamond norm.

## 2. The strongest explicit access obstruction

### Proposition A: exact consistent quantum assignment is a product

Let A map a logical system L into L tensor E by a CPTP map. If Tr_E A = id_L on all logical states, then there exists one state tau_E such that

    A(rho_L) = rho_L tensor tau_E

for every rho_L, including when L is entangled with an arbitrary reference.

**Proof.** Feed half of a maximally entangled state Omega_RL into A. The RL marginal of the resulting Choi state is the pure state Omega_RL. Any positive state with a pure marginal factors across that marginal, so the complete Choi state is Omega_RL tensor tau_E. The Choi correspondence gives the asserted product channel. This is the operational CP version of the Pechukas assignment obstruction; no assumption that E initially was uncorrelated is needed for this implication. More generally, perfect recovery from the memory makes the complete complementary output independent of the logical input. KSW's information-disturbance theorem supplies an approximate version, but the proof just given is self-contained for the exact claim. QED.

This does not prohibit correlated thermal resources. It prohibits assigning **input-dependent bath information while simultaneously preserving a completely unknown quantum state in the recoverable logical subsystem**. A logical label sampled classically is a different task.

### Proposition B: a sharp conditional-Gibbs coherence loss

Take a memory qubit L and a bath spin E with

    H = g Z_L Z_E,   beta > 0,   g > 0,
    r = tanh(beta g),
    omega_LE = (I - r Z_L Z_E)/4.

This is the actual finite-temperature Gibbs state of the interacting two-spin Hamiltonian. Its bath marginal is I/2. Its conditional bath states for Z_L=+1 and Z_L=-1 are

    tau_0 = (I-r Z_E)/2,   tau_1 = (I+r Z_E)/2.

Consider the apparently natural target endpoints

    A(|z><z|) = |z><z| tensor tau_z,   z=0,1.

The following statements hold.

**B1. Strictly local instantaneous access.** Starting from one fixed omega_LE and an independent input qubit Q, a writer W_Q L->L tensor id_E cannot approximate both target endpoints with worst-case trace-distance error below r/2. Indeed every such output has bath marginal I/2, and

    (1/2)||tau_z-I/2||_1 = r/2.

This particular lower bound assumes that the effective writing channel is tensor id_E. System-only **controls** during a finite writing interval do not by themselves imply that condition: the uncontrolled L-E Hamiltonian can still act. Such a writer requires a joint dynamical calculation. It cannot be described as an instantaneous local channel while also using the drift to rearrange the bath.

**B2. Even global endpoint preparation cannot preserve all coherence.** Let A be any CPTP channel, with arbitrary joint control allowed, satisfying the two endpoints exactly. Its reduced channel on L must have the form

    |0><1| -> c |0><1|,   with   |c| <= F(tau_0,tau_1) = sech(beta g),

where F is root fidelity. Hence the Bell-input trace-distance error from the identity is at least

    [1-sech(beta g)]/2.

This lower bound is sharp.

**Proof.** The Choi matrix, restricted to its nonzero logical blocks, has the positive block matrix

    [ tau_0   K   ]
    [ K^*    tau_1].

Positivity implies K=sqrt(tau_0) C sqrt(tau_1) for a contraction C. Therefore c=Tr K obeys |c|<=||sqrt(tau_1)sqrt(tau_0)||_1. In the displayed commuting example the latter equals sqrt(1-r^2)=sech(beta g). Evaluating the Choi output on the Bell state gives error at least (1-Re c)/2 >= (1-sech(beta g))/2. Taking K=sqrt(tau_0)sqrt(tau_1) realizes the bound: diagonal Kraus operators with diagonal entries sqrt((tau_z)_ee), with the label e retained in E, give a CP extension and precisely this dephasing channel. QED.

Thus arbitrarily weak g does not give an arbitrarily accurate unknown-qubit writer when beta g is unrestricted. At beta g=4, B1's floor is about 0.499665 and B2's sharp coherent floor about 0.481691. These are obstructions to an **overstrong operational interpretation**, not counterexamples to a particular protected 3D model that has not been supplied.

**Failed repair preserved.** Preparing conditional Gibbs states separately for the two computational-basis inputs succeeds as a classical task. Extending the rule linearly by simply retaining all off-diagonal input coherences violates CP unless the bath states coincide. Replacing that extension by the CP channel above repairs positivity by introducing exactly the coherence loss in B2. Granting joint bath access also fails to evade B2 if the same recoverable logical subsystem and conditional endpoints are retained.

## 3. Constructive repair: a fixed-resource exact-dynamics channel theorem

The useful replacement for an unspecified correlated assignment is an explicit logical subsystem and a swap writer. The important condition is that the logical algebra be supported on the **accessible memory**, not on an unknown joint dressed memory-bath algebra.

### Theorem C: Gibbs-weighted approximate conservation gives an operational memory

Let S be the accessible memory and E a finite bath. Suppose an exact representation of the qubit Pauli algebra on S gives a specified decomposition

    H_S = C^2_L tensor H_G,

with Pauli operators P in {X_L,Y_L,Z_L} tensor I_G supported on S. Let H be any self-adjoint Hamiltonian on S tensor E; it may be interacting and noncommuting. Put

    omega = exp(-beta H)/Tr exp(-beta H),   0 <= beta < infinity,
    tau_GE = Tr_L omega,
    omega_bar = (I_L/2) tensor tau_GE,
    eta_P = [Tr omega [H,P]^* [H,P]]^(1/2),
    Delta = ||omega_bar-omega||_1.

Prepare one copy of this fixed omega. Write an arbitrary unknown input Q by swapping Q with the specified L subsystem and discarding the former L, now in Q. Leave GE inaccessible. The resulting encoding channel is exactly

    Gamma(rho_RQ) = rho_RL tensor tau_GE,

for every reference R. Store under U_t=exp(-itH), and decode by the specified S->L tensor G identification followed by tracing G (and the inaccessible E).

Let Phi_t be the resulting logical channel. Then, simultaneously for all real t,

    1-F_e(Phi_t)
      = (1/8) sum_P ||[U_t,P]||_(2,omega_bar)^2
      <= (t^2/8) sum_P eta_P^2 + (3/2) Delta,

and

    (1/2)||Phi_t-id_L||_diamond
      <= min{1, sqrt[(t^2/2) sum_P eta_P^2 + 6 Delta]}.

Moreover

    Delta <= (beta/4) sum_P eta_P,

so a bound requiring only the three thermal commutators is

    (1/2)||Phi_t-id_L||_diamond
      <= min{1, sqrt[(t^2/2) sum_P eta_P^2
                       + (3 beta/2) sum_P eta_P]}.

Here F_e is entanglement fidelity for the maximally mixed logical qubit; ||A||_(2,w)^2=Tr w A^*A. All sums are over the three nonidentity logical Paulis. No weak-coupling limit, Markov property, bath independence approximation, detailed balance, or termwise stationarity is used.

#### Complete proof

**Step 1: actual deterministic writer.** The initial joint state is rho_RQ tensor omega_LGE. Swapping Q and L and tracing the old L in Q leaves exactly rho_RL tensor Tr_L omega. This is a CPTP map, works on an unknown entangled input, and leaves the physical bath marginal equal to omega_E. The target family is now explicitly fixed and linear. No conditional re-equilibration of E has been assumed.

**Step 2: exact fidelity identity.** Define the Pauli twirl on operators by

    T(A) = (1/4) sum_{P in {I,X,Y,Z}} P A P
         = I_L tensor [(1/2)Tr_L A].

Because omega_bar commutes with every P, T is an orthogonal projection for the omega_bar-weighted Hilbert-Schmidt inner product. For a unitary U,

    (1/8) sum_{P != I} ||[U,P]||_(2,omega_bar)^2
        = 1-||T(U)||_(2,omega_bar)^2.

Write A_0=(1/2)Tr_L U. The standard Kraus expression, or direct Bell-input expansion, gives

    F_e = Tr tau_GE A_0^* A_0 = ||T(U)||_(2,omega_bar)^2.

For completeness, diagonalize tau=sum_j p_j |j><j|. Kraus operators of the logical channel are sqrt(p_j)<k|U|j>. Summing their squared normalized traces gives precisely Tr tau A_0^*A_0. This proves the identity without any covariance assumption on the logical channel.

**Step 3: use stationarity of the actual interacting state.** Duhamel's identity gives

    [U_t,P] = -i integral_0^t U_(t-s) [H,P] U_s ds.

Since [omega,U_s]=0, every integrand has omega-weighted 2-norm eta_P. Hence ||[U_t,P]||_(2,omega)<=|t| eta_P. Also ||[U_t,P]||_infinity<=2, so

    ||[U_t,P]||_(2,omega_bar)^2
       <= t^2 eta_P^2 + 4 Delta.

Summing the three inequalities and dividing by eight proves the first upper bound.

**Step 4: bound the Gibbs decoupling defect.** For a full-rank state omega define K_omega(A)=integral_0^1 omega^s A omega^(1-s) ds. In an eigenbasis of omega this multiplies A_ij by the logarithmic mean of p_i,p_j. The logarithmic mean is at most (p_i+p_j)/2. For Hermitian A and O, Cauchy-Schwarz in this logarithmic-mean inner product gives

    |Tr O K_omega(A)|
       <= [Tr omega O^2]^(1/2) [Tr omega A^2]^(1/2).

Taking the supremum over Hermitian ||O||_infinity<=1 yields ||K_omega(A)||_1 <= [Tr omega A^2]^(1/2). The commutator identity for the exponential gives

    [P,omega] = beta K_omega([H,P]).

Apply the preceding inequality to the Hermitian operator i[H,P]. It follows that ||P omega P-omega||_1 <= beta eta_P. Averaging over the Pauli twirl gives Delta<=beta sum_P eta_P/4. The beta=0 case has omega_bar=omega directly.

**Step 5: arbitrary logical references.** Let J be the normalized Choi state of Phi_t. Its trace distance from the pure Bell state is at most sqrt(1-F_e). For any qubit channel difference Lambda, ||Lambda||_diamond <= 2||(id tensor Lambda)(Omega)||_1. One direct proof writes any pure reference-input state as (A tensor I)|Omega>, with ||A||_infinity^2<=2, and uses trace-norm submultiplicativity; convexity covers mixed inputs and Schmidt compression covers arbitrary references. Therefore half the diamond distance is at most 2 sqrt(1-F_e). Substituting Step 3 gives the claimed bounds. QED.

### What this theorem earns and what it does not

If all three eta_P are at most a_n, then

    error(t) <= sqrt[(3/2)t^2 a_n^2 + (9/2) beta a_n].

Consequently a_n exponentially small in a size parameter gives exponentially long reference-safe storage at fixed beta and fixed target error, with an exponentially small preparation-induced floor in this bound. The result remains valid when H has finite disordered local terms and noncommuting system-bath interactions, **provided the actual three eta bounds are proved for that H and its actual Gibbs state**.

This is a sufficient-condition theorem, not a completed 3D memory construction. A bare energy barrier, finite script, small operator coefficient, or Davies decay estimate does not establish its eta premise. The assigned N1645 source does not provide its logical algebra or the required estimates. An algebra involving inaccessible bath operators cannot be substituted.

The swap and identification are abstract ideal quantum operations. Their circuit depth, spatial routing, control amplitudes, switching precision, cooling, classical processing, finite-time drift, and noise have not been bounded. An exact algebra representation on S gives a Hilbert-space operation, not an efficient gate decomposition. A code subspace alone is also insufficient: the displayed theorem requires a specified logical subsystem on the whole support of the finite-temperature resource. Extending the algebra into syndrome sectors is a real mathematical step.

This implication is naturally adjacent to the old dressed-observable/autocorrelation framework. It should be credited as a reconstruction and quantitative extension of that machinery unless a deeper novelty audit establishes otherwise.

## 4. Access error can be charged once, uniformly in HOLD time

### Proposition D: preparation and access errors do not automatically grow with storage time

Let Gamma_0 and Gamma_a be CPTP logical-to-SE encoding channels, and suppose

    half||Gamma_a-Gamma_0||_diamond <= delta_w.

Let one fixed exact storage evolution U_t act in both protocols. Let D_0 and D_a be readout channels with half diamond difference at most delta_r on the required joint input domain. If

    half||D_0 U_t Gamma_0-id||_diamond <= epsilon(t),

then for every t in the same interval

    half||D_a U_t Gamma_a-id||_diamond
       <= epsilon(t)+delta_w+delta_r.

**Proof.** Add and subtract D_0 U_t Gamma_a and D_0 U_t Gamma_0. Composition by a CPTP map has diamond norm one. Apply the triangle inequality. QED.

A seed-state trace-distance error delta_seed contributes at most delta_seed to delta_w, including all references. State-restricted readout bounds can replace a global diamond bound if their domain explicitly contains the encoded storage outputs with reference. This is a useful repair: a constant preparation error need not be exponentially small merely because the desired HOLD time is exponential. One instead must prove closeness in the **joint channel norm actually used by the storage theorem**. The proposition does not prove that a noisy local circuit achieves that closeness. A local-stochastic error bound alone does not imply a small global diamond error for a large code.

The same argument does not remove model error in future dynamics. In finite dimension,

    half||U_t^H-U_t^(H+V)||_diamond <= min{1, |t| ||V||_infinity}.

This elementary Duhamel bound is usually useless at exponentially long time. A local interaction strength bound can allow an extensive total ||V||. A successful uniform perturbation theorem must use the protecting structure rather than relabel this estimate as robustness.

## 5. Additional destructive tests that a claimed contract must survive

### 5.1 Weak local coupling alone is insufficient, even with the actual Gibbs resource

Take H=g SWAP_SE for two spins. Its actual Gibbs state has both one-spin marginals I/2. The swap writer in Theorem C produces rho_S tensor I_E/2. At t=pi/(2g), exact evolution is -i SWAP, so the accessible memory becomes I/2 for every unknown input, while the bath carries that input. No reader accessing S alone can retrieve it. The minimum possible half-diamond error of any replacer from the identity qubit channel is 3/4: the Bell-input overlap is always 1/4, giving the lower bound, and the maximally mixed replacer attains it. Making g arbitrarily small delays this loss to order 1/g; it does not create an arbitrarily long protected-memory theorem. At t=pi/g the information returns. Thus recurrence does not imply useful storage at all intermediate times.

This is a test of unsupported quantifiers, not a disproof of a special protected code family.

### 5.2 A correct reduced initial state is insufficient

The two Bell states Phi+ and Phi- have identical memory marginals and identical bath marginals. A CNOT with memory as control maps them to |+>_S|0>_E and |->_S|0>_E. Their memory outputs are perfectly distinguishable. A proposed initial error norm that sees only either one-spin marginal can therefore be zero while the future logical error is maximal. Mixing each Bell state with the same small maximally mixed component gives a full-rank version. Joint correlations, or a justified dynamical seminorm that controls their effect, must enter the contract.

### 5.3 Global Gibbs stationarity does not imply termwise stationarity

For H=X+Z on one spin, omega_beta commutes with H, but [X,omega_beta] and [Z,omega_beta] are both nonzero at beta>0. Therefore an exact-Hamiltonian Gibbs state cannot be declared a frustration-free steady state of each local generator -i[h_X, .] merely because the total generator annihilates it. This blocks an unqualified import of the thermal-phase self-correction theorem of Ma-Khemani-Sang into exact joint spin-bath dynamics.

### 5.4 Finite baths, time, and unknown inputs

A finite exact bath gives a quasiperiodic global unitary. It does not provide the irreversible semigroup or scale-uniform mixing estimates needed by a Davies argument. Recurrence is also not a universal impossibility theorem: a decoupled logical subsystem stores forever. One must state the bath-size sequence, accessible portion, preparation resource, time interval, and whether bounds are uniform in bath volume. Passing Theorem C to an infinite-spin bath requires a thermodynamic-limit construction with uniform constants and channel convergence. The finite-dimensional proof alone does not establish that extension.

A decoder allowed access to the whole bath can undo U_t and trivialize storage. A decoder given a classical description of the unknown logical state can simply reprepare it. Neither is the quantum-memory task. An unknown input must be independent of the fixed resource, may be entangled with a reference, and must have no uncharged coherent side copy. The complete discarded complement, including preparation purifications, must obey the information-disturbance constraint when recovery succeeds.

### 5.5 Readout and noisy write

A measurement of a dressed Z observable gives a classical bit. A separate dressed-X measurement on another prepared sample does not constitute coherent retrieval of an arbitrary unknown qubit from one stored instance. The report needs a CPTP reader into an output qubit, plus finite-time control/noise costs, or a carefully scoped classical-readout claim. Similarly, receiving an already encoded unknown qubit is not a physical encoding procedure.

## 6. Primary-source import and priority checks

Cached primary HTML, converted text, and SHA-256 pins are in `../literature/auditor/SOURCES.json`. No theorem below is imported into an unavailable N1645 proof. Items 1-3 explain standard foundations; items 4-6 are competing methods whose extra hypotheses cannot be erased.

1. **Rodriguez-Rosario, Modi, Aspuru-Guzik, Linear Assignment Maps for Correlated System-Environment States**, arXiv:0910.5568v2, 18 December 2009, [primary text](https://arxiv.org/html/0910.5568v2), Theorem 1 and Theorems 2-3. Theorem 1 states the product conclusion under linearity, consistency, and positivity on the full state domain. Restriction to commuting inputs avoids the universal conclusion by changing the task. Proposition A above has its own CP/Choi proof. This is established prior art, not a new impossibility result.

2. **Kretschmann, Schlingemann, Werner, The Information-Disturbance Tradeoff and the Continuity of Stinespring's Representation**, arXiv:quant-ph/0605009v1, 30 April 2006, [primary text](https://arxiv.org/html/quant-ph/0605009v1), Theorems 1 and 3; published IEEE Trans. Inf. Theory 54 (2008), 1708-1717, DOI 10.1109/TIT.2008.917696. For a finite-dimensional channel and its full Stinespring complement, recovery and proximity of that complement to a constant channel have dimension-independent stabilized-norm tradeoffs. Correlated-resource purifications belong in the complement. Proposition A requires no approximate import.

3. **Alicki, M. Horodecki, P. Horodecki, R. Horodecki, On thermal stability of topological qubit in Kitaev's 4D model**, arXiv:0811.0033v1, 2 November 2008, [primary text](https://arxiv.org/html/0811.0033v1), Section II.1, Proposition 1, equations (20)-(24). Their observable-to-fidelity bridge explicitly assumes a Gibbs factor I_Q/2 tensor rho_anc and a Davies weak-coupling semigroup. Section II.2 uses Gibbs-weighted local commutators. Theorem C supplies an explicit swap resource and accounts for failure of exact Gibbs factorization, while using exact joint unitary dynamics. This is a concrete extension of a known framework, with novelty still unestablished.

4. **Balasubramanian, Davydova, Lin, A passive self-correcting quantum memory in three dimensions**, arXiv:2605.10943v1, 11 May 2026, [primary text](https://arxiv.org/html/2605.10943v1), Theorem 1.1 and the preceding evolution equation. The source already claims a 3D geometrically local CSS family with stretched-exponential-in-size lifetime at low nonzero temperature. Its stated dynamics are Markovian with local jump operators, and its thermal encoder uses an exact logical/gauge factorization. It is serious priority competition for a broad 3D-memory claim, but it does not itself supply the exact interacting-spin-bath contract sought here. Stability to arbitrary Hamiltonian perturbations is explicitly left for an update in this pinned version.

5. **Ma, Khemani, Sang, Circuit-based characterization of finite-temperature quantum phases and self-correcting quantum memory**, arXiv:2509.15204v3, 16 October 2026, [primary text](https://arxiv.org/html/2509.15204v3), Definitions 1-3, Theorems 1-3. Theorem 1 needs a path with stable clustering. The self-correction theorem additionally assumes a normalized quasi-local Lindbladian with the Gibbs state frustration-free stationary term by term. It provides explicit ideal encoding/decoding circuits and stretched-exponential lifetime. None of stable clustering, the path, or termwise stationarity follows from N1645's visible report. The exact-Hamiltonian stationary-state substitution fails by Section 5.3. This is a major nearby predecessor, not an automatic solution to the access problem.

6. **Pastawski, Kay, Schuch, Cirac, Limitations of Passive Protection of Quantum Information**, arXiv:0911.3843v1, 19 November 2009; Quantum Inf. Comput. 10 (2010), 580-618, [primary version record](https://arxiv.org/abs/0911.3843). The primary abstract concerns weak Hamiltonian perturbations or coupling to a ground-state environment, final correction thresholds, and a 2D toric-code attack. It warns against pure-state survival as a memory criterion. I have not imported a universal logical-memory impossibility theorem from it: the abstract does not state one, and its bath/preparation contract differs from the interacting Gibbs resource.

**Recent Zenodo search.** Searches on 6 November 2026 explicitly included `site:zenodo.org/records/` with self-correcting, quantum memory, 3D, thermal, exact, and spin. They found record [20778451](https://zenodo.org/records/20778451), 21 June 2026, whose description advertises a projection mechanism and cites the 3D sheaf-code paper, and the unrelated optical-memory simulation dataset [23628626](https://zenodo.org/records/23628626), version 1.2, 25 October 2026. The first direct page retrieval was rate-limited; no proof from it was verified. The second describes a Maxwell-Bloch model and is not a competing spin-code theorem. Search pollution and a rate-limited candidate mean that no absence-of-prior-art conclusion is earned. Priority of Theorem C or any N1645 construction remains UNKNOWN.

## 7. Reproducible diagnostics and exact status ledger

`../literature/auditor/check_channel_identity.py` independently checks the Pauli-twirl identity, Gibbs-decoupling inequality, and resulting infidelity bound on 80 random finite-dimensional Hamiltonians, including noncommuting H. It uses numpy eigendecomposition, no Markov approximation. Output is `../literature/auditor/channel_identity_checks.json`. Maximum algebraic identity residual was about 1.34e-15; no inequality violations occurred. These finite diagnostics check constants and tensor ordering; the proofs above carry the mathematical claims.

| Claim | Status | Governing gap or scope |
| --- | --- | --- |
| CP consistent assignment forces a product bath | PROVED; established framework | Full quantum input domain |
| Two-spin conditional-Gibbs access/coherence floors | PROVED | Explicit counterexample to stronger interpretation |
| Theorem C exact finite-bath channel implication | PROVED | Specified accessible Pauli algebra; actual Gibbs-weighted eta |
| Theorem D time-uniform access-error transfer | PROVED; elementary known machinery | Same exact future dynamics and justified joint channel norm |
| N1645's reported full theorem | UNVERIFIED HERE | Mathematical package unavailable |
| N1645 satisfies Theorem C | OPEN / UNKNOWN | No supplied algebra, H, beta, or eta estimate |
| Noisy efficient logical swap and coherent readout | OPEN | Physical control/noise/cost theorem missing |
| Infinite spin-bath extension with uniform constants | OPEN | Thermodynamic-limit contract missing |
| Practical passive benefit against matched active encoding | NOT ACHIEVED | Full cycle costs and incumbent comparison missing |
| Historical novelty of the implication or construction | UNKNOWN | Nearby established frameworks and incomplete current search |

## 8. Strongest next mathematical operation

Do not try to reconstruct the missing N1645 package. For an independently specified candidate family, construct a **system-supported exact logical Pauli algebra** and prove, in the actual interacting Gibbs state, exponentially small values of

    Tr omega [H,P]^* [H,P],   P=X,Y,Z,

uniformly over the declared local interaction class, bath cutoff, disorder, and temperature regime. Then Theorem C immediately supplies a fixed-resource, reference-safe ideal write-store-read theorem with explicit time/error parameters. Failure should be localized: bath-supported dressing, a non-small Gibbs factorization defect, thermal weight on bad syndromes, coherent splitting, or inaccessible algebra implementation.

After that mathematical operation, the practical gate is to implement the swap and coherent decoder with noisy controls while proving a joint encoding/readout error bound of Proposition D's kind, and to charge those same controls to an active fault-tolerant comparator. The present audit closes neither resource gate. It does replace an ambiguous ideal correlated assignment by one explicit legal channel and a sharply testable dynamical certificate.
