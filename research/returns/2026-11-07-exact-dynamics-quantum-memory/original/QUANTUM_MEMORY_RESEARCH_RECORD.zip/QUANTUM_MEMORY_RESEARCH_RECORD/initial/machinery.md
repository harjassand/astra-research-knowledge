# Independent machinery initial return

Date: 6 November 2026. This initial records conclusions independently derived before reading the other initial reports. A constructor follow-up message arrived while the long save call was twice interrupted, after the derivation and primary-source investigation were formulated; none of its construction is used below. Detailed proofs and source notes will be saved separately without rewriting this initial.

## Strongest achieved result

I independently derived the following finite-dimensional implication. Let the memory have an accessible exact factorization S=L⊗A, dim L=2, with logical Pauli operators P_a acting on S only. Let H be any finite memory-plus-bath Hamiltonian, gamma=exp(-beta H)/Z its actual joint Gibbs state, tau=Tr_L gamma, and q_a²=Tr gamma [H,P_a]†[H,P_a], q=sum_a q_a. The ideal logical replacement encoder is Enc(rho)=rho⊗tau; the decoder traces out A and the bath. Then, for U_t=exp(-itH),

    ||U_t Enc(rho) U_t† - Enc(rho)||_1 <= (beta+|t|)q,
    ||Dec Tr_B U_t Enc(.) U_t† - id||_diamond <= min(2,3(beta+|t|)q).

This requires no Markov, Davies, independent bath or bath-mixing hypothesis. It assumes actual joint equilibrium and ideal logical access; it is not a noisy preparation theorem. Its proof uses Gibbs square-root commutators, logical twirling and Duhamel, detailed in the follow-up notes. If [H,P_a]=[H,P_a]P_bad, then q_a <= ||[H,P_a]|| sqrt(Tr gamma P_bad). The decisive operation is therefore a bath-volume-uniform interacting-Gibbs rare-boundary estimate at fixed local coupling and temperature, plus a noisy writer basin. Neither is established for N1645.

I also proved a two-level counterexample to naive noncommuting Gibbs event comparison. For H0=Delta|1><1|, V=lambda X, P=|1><1| and 0<2lambda<Delta, the actual perturbed Gibbs population tends to (1-Delta/sqrt(Delta²+4lambda²))/2>0 as beta→infinity. The proposed bound exp(2beta||V||)Tr P gamma_H0 tends to zero. One cannot silently transfer a classical Peierls probability bound by operator monotonicity of the exponential.

The script literature/machinery/check_weighted_commutator.py and weighted_commutator_checks.json verify 80 finite random examples and the two-level diagnostic. They do not check N1645 or prove the thermodynamic result.

## Direct prior-art conflicts

1. Balasubramanian–Davydova–Lin, arXiv:2605.10943v1, submitted 11 May 2026: a direct 3D passive thermal-memory existence predecessor. Formal construction/lifetime chain: Theorem 3.16, Theorem 5.13, Corollary 5.14. Uses local Gibbs-stationary Lindbladians and thermal syndrome encoding; initialization remains open (Section 1.3). Theorem 1.2 gives bounded density and constant geometric range. No first-3D-passive-memory claim is available to N1645.
2. Chesi–Loss–Bravyi–Terhal, arXiv:0907.2807v2, Theorem 1: protected exact logical algebra, Gibbs-stationary Lindbladian, good subspace, exact commutation with H, and thermal replacement encoder. The factorization and drift proof were inspected. Generic noncommuting full-Hamiltonian dynamics are not its hypotheses.
3. Ma–Khemani–Sang, arXiv:2509.15204v3: v1 18 September 2025, v3 16 October 2026. Theorem 1 gives locally reversible Gibbs transport along stable-clustering paths. Theorems 2–3 require quasi-local Lindbladians with termwise frustration-free stationary state. Annular local-to-nonlocal stable clustering is stronger than ordinary two-point clustering. No such import was verified for N1645.
4. Bergamaschi–Gheissari–Liu, arXiv:2507.10976v1: ground-state-to-thermal-sector preparation, Theorem 1.7/7.8, under local metacheck/connectedness/correction hypotheses. BDL explicitly lacks the LDPC metachecks required for direct application. Efficient general block implementation is separate from the 4D toric-code special case.
5. Rakovszky–Placke–Breuckmann–Khemani, arXiv:2412.09598v2: Theorem 2/S II.12 bottleneck drift uses off-diagonal Gibbs weight. Theorem S III.4 perturbative stability assumes an extensive kappa*n barrier, bounded-incidence commuting projectors, low minimum energy density and ||V||<=g*n. It does not directly cover a subextensive 3D barrier plus arbitrary large spin bath, and slow mixing alone is not coherent memory.
6. Wildeboer–Iadecola–Williamson, arXiv:2110.05710v2: exact Hamiltonian noiseless subsystems under symmetry/gauge-algebra dynamics; Sections II.F/III.D and Eq.45 give prethermal lifetime in field/perturbation ratio with extra symmetry structure. Exact Hamiltonian memory is not a new general phrase in 2026.
7. Merkli, arXiv:2105.00023v2, Theorem 1.1, already gives uniform-in-time Davies approximation for a finite system and regular free bosonic bath, with spectral/golden-rule assumptions and product initialization. No size-uniform arbitrary-spin-bath import is earned. Active exact-dynamics fault tolerance (Aharonov–Kitaev–Preskill, quant-ph/0510231) is the ordinary full-resource comparator.

## Important recent Zenodo result found and actual proof read

Soryun IV: Erasure-Optimal Quantum Memory under Noncommuting Spatial Fields and Non-Markovian Quantum Baths, DOI 10.5281/zenodo.23859937, concept 23859936, publicly created 2026-11-01T14:25:39.029742Z. Actual PDF and source ZIP obtained (103 pages). Internal label IV/version4.0 does not establish earlier public deposits: the versions API returns one public record and exact Soryun search returns one record.

Theorem 4.2, Corollary 4.3 and Theorem 3.3 provide one ideal encoder and final loss-flag decoder retaining independent-erasure leading rate (1-2p)+ for known sites in a fixed compact domain, bounded integrable finite-dimensional joint Hamiltonians, arbitrary bath memory, exogenous loss flags and one integrated operator-norm spatial continuity envelope uniform over array size and the entire field/bath family. Strong backgrounds must lie in declared collective cell algebras. General efficient decoding is open; Clifford encoder sampling is supplied.

I read the load-bearing Auerbach coefficient lemma 3.1, CP domination lemma3.2, Haar variance lemma5.1, finite coding theorem3.3, collective-module lemma4.1, Dyson tail and theorem4.2/corollary4.3. No flaw found in that central chain. This is a focused proof reading, not a full independent audit or priority certification.

Its sharp applicability obstruction is elementary: independent local bath coefficients B(x_j)=g Z_j have ||B(x_i)-B(x_j)||=2g for distinct sites, even when spatial positions become arbitrarily close. Any common fixed-time modulus must remain >=2gT/hbar and cannot vanish. If spacing/density instead stay fixed in growing 3D volume, sufficiently small cells need C_N=N, violating sublinear covering. This theorem is a meaningful correlated-field alternative, not an automatic generic-local thermal-memory theorem.

Other actual 2026 Zenodo files inspected: Limsuwan18858059 (4 March; Appendix X pp88–89 explicitly leaves 3D existence conditional); Aksman20778451 (June21, after BDL; assumes instantaneous projection/infinite penalty); Aksman23428551 (October17; invalid exact identification of 2^N-dimensional qubit CSS space with N-dimensional real/complex one-chain Hodge space after small-angle approximation); Caldin21356498 and23972523 (July14/November5; 2.7kB actual text files contain no scaling Hamiltonian/bath/lifetime proof). DOI family/version chronology and source details are preserved in exact API caches. These searched records do not establish matching priority. Searches are bounded, not exhaustive historical proof.

## Scope and status

N1645 remains visible-report-only. No unknown theorem or original checks were reconstructed. New independent implication: PROVED at stated finite conditional scope, no novelty claim. Naive Gibbs comparison: DISPROVED. Soryun generic-local-bath import: obstructed. Fixed-strength generic 3D exact thermal memory: NOT ESTABLISHED here. Noisy write–store–read and matched full-cycle advantage: NOT ACHIEVED. Historical priority: NOT ESTABLISHED; concrete predecessors identified.

Sources/cache: work/quantum-memory-20261106/literature/machinery/. SOURCE_MANIFEST.json records SHA-256 and bytes. Source pin initially3918bf6eb69e3b8e902bcbeaae3c5a72f26d6b62; principal later supplied78ff1e3a865e3d0a05af901f77eb1ffd128b00d4 with N1645 unchanged. No N1646/N1649/N1653/N1694 composition is used. Actual initial reports from others have not been read.
