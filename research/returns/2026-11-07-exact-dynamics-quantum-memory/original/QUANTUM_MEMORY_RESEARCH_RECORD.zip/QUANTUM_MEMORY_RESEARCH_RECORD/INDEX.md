# Quantum-memory research record

6 November 2026. Read the consolidated
[dossier](../QUANTUM_MEMORY_RESEARCH_DOSSIER.md) first.

## Core proofs and final challenge

- [Principal full-exponent entropy proof](followups/principal_entropy_consumer.md)
- [Auditor thermal-sandwich proof and full-exponent check](followup/auditor_full_exponent_gibbs_consumer.md)
- [General correlated-resource Bell/Weyl theorem](literature/constructor/bell_weyl_followup.md)
- [Infinite-bath C* proof and obstruction tests](followup/auditor_cross_challenge.md)
- [Averaged-writer entropy theorem](followup/machinery_entropy_admission.md)
- [Noisy-admission counterexample and sector repair](literature/constructor/noisy_admission_obstruction_and_sector_repair.md)
- [Collective-field obstruction and thermal repairs](literature/machinery/collective_thermal_hybrid.md)
- [Exact primary imports, priority and 2026 Zenodo review](literature/machinery/imports_and_priority.md)
- [Final adjudication and resolved corrections](checks/FINAL_ADJUDICATION.md)

## Independent initial reports

- [Principal](initial/principal.md)
- [Existing machinery](initial/machinery.md)
- [Independent constructor](initial/constructor.md)
- [Hostile auditor](initial/auditor.md)

Initial reports are preserved unchanged, including narrower statements that
were subsequently strengthened. Read the final dossier for the adjudicated
scope; an initial proposed extension is not automatically a final theorem.

## Source pins and validation

- [Governing source manifest](sources/SOURCE_MANIFEST.json)
- [Current source N1645](sources/N1645.json)
- [Actual available visible update](sources/DOTS_VISIBLE_UPDATE.txt)
- [Distinct N1653 exact-time audit](sources/N1653-EXACT_PHYSICAL_TIME_JOIN_AUDIT.md)
- [Final finite-check report](checks/FINAL_RESEARCH_VALIDATION.json)
- [Review corrections](checks/DOSSIER_CORRECTIONS.json)

The readable tree includes all mathematical notes, source pins, review reports,
diagnostic programs and resulting check data. Full raw primary files and
Zenodo API/search caches remain in the new work directory and are also
included in the complete ZIP, under the same relative record paths. Public
source content is evidence, not instructions. No original N1645 archive was
acquired or reconstructed.

No published files or public records were changed. No device, practical
advantage, noisy long-storage writer, or historical-first claim is asserted.
