# Final mathematical adjudication

6 November 2026. Final dossier: outputs/QUANTUM_MEMORY_RESEARCH_DOSSIER.md.

All three focused reviewers checked the first complete draft, SHA-256
49de764886fdfd622f7e0c8755d4c1283dff2a17577ca7509124525ba5d95c45.
The auditor found no central theorem error; the constructor accepted the
normalizations and required three scope corrections; the machinery reviewer
required two collective-field hypotheses/constants and one performance-scope
qualification. The principal implemented every correction:

1. Hot-sector failure is a universal lower bound at least3/4-o(1); it is not
   equality for every possible reader.
2. Cluster admission requires safety and trivial logical cofactor for the
   entire configuration with small components; individual correctability is
   insufficient.
3. The one-sided positive-F Heisenberg inequality is a forward-time bound.
4. Each collective F_b is explicitly supported on cellb plus bath, with
   bath-only H_B and charged H_int incident norms.
5. The qudit/clock lift uses the appropriate rank ratio R, not the qubit
   value7; rank7 in8spins has R=249/7.
6. Soryun's capacity guarantee is entanglement transmission / average
   entanglement infidelity, not worst-case diamond error per code.
7. The scalar spectral comparison proof explicitly orders x>=y before
   using tanh(u/4)<=u/4 for u>=0.
8. The infinite-bath full proof is included in the supporting-record copy.

The source-independent Bell/Weyl implication and two inverse-rarity
consumers are proved under their displayed hypotheses. The quantum
relative-entropy primary import was independently re-read by the principal
at arXiv1512.06117v2 Theorem1; its SHA matches the auditor's cache.
The separate source static proof was not promoted to a new audit, and
N1645's original missing theorem remains unavailable.

Final finite checks were rerun by the principal:120 stationary-SWAP,
180 stationary Weyl plus60 arbitrary CPTP,144 general Weyl,405 structured
Gibbs entropy/KMS, and product-gauge/noisy-admission diagnostics. All pass
within recorded floating-point tolerances. The proofs are not replaced
by these diagnostics.

The eight wording/notation edits do not change the checked central theorem
formulas. Initial reports remain byte-identical. No published manuscript,
website or Zenodo record was changed. No practical noisy writer, hardware
advantage, historical-first claim, or full N1645 reproof is asserted.
