from pathlib import Path
import re,json,hashlib

p=Path('outputs/QUANTUM_MEMORY_RESEARCH_DOSSIER.md')
s=p.read_text()
original_sha=hashlib.sha256(s.encode()).hexdigest()
changes=[
('Every accessible reader then has half diamond error approaching (3/4), despite exactly correct input at release.',
 'Every accessible reader then has half diamond error at least (3/4-o(1)), despite exactly correct input at release; the natural logical reader attains the limiting value (3/4).'),
('equilibrium rarity plus individual fault correctability to a general noisy-writer theorem',
 'equilibrium rarity plus exact logical neutrality of gauge faults at release to a general noisy-writer theorem'),
('A concrete stochastic geometry interface is available: if background defects obey (\\Pr(R\\subset T)\\le q^{|R|}), faults obey (\\Pr(R\\subset F\\mid T)\\le f^{|R|}), and a bounded-degree-(D) geometric lemma declares every union component of size below (\\ell) dynamically safe and logically correctable, then',
 'A concrete stochastic geometry interface is available: suppose background defects obey (\\Pr(R\\subset T)\\le q^{|R|}), faults obey (\\Pr(R\\subset F\\mid T)\\le f^{|R|}), and a bounded-degree-(D) geometric lemma proves that **every entire configuration whose union components all have size below (\\ell)** is dynamically safe with trivial logical cofactor. Then'),
('where all terms preserve all flags, (F_bP_b=0), (\\|F_b\\|\\le M), and the sum of incident interaction norms per cell is at most (J). The (F_b) may use shared quantum-bath coefficients.',
 'where (H_B) acts on the bath alone, all terms preserve all flags, and each (F_b) is supported on **cell (b) and the bath only**, collective on that cell, with (F_bP_b=0) and (\\|F_b\\|\\le M). The sum of norms of (H_{\\rm int}) terms incident to any cell is at most (J). The (F_b) may use shared quantum-bath coefficients.'),
('The lift also covers fixed-dimensional outer clock spins by choosing sufficiently large fixed singlet multiplicity. It does not remove the outer theorem\'s own bath restrictions.',
 'For fixed-dimensional clock/qudit lifts, choose a rank-(d_b) subspace of a sufficiently large singlet multiplicity in an (n_b)-spin cell and replace (7) throughout by (R=\\max_b(2^{n_b}-d_b)/d_b). A rank-seven factor in eight spins has (R=249/7); the displayed (7) applies only to four-spin/qubit cells. This changes the penalty bound accordingly and does not remove the outer theorem\'s own bath restrictions.'),
('General efficient decoding is separate. This is meaningful common-recovery machinery',
 'The guarantee concerns entanglement transmission and averaged entanglement infidelity, not worst-case diamond error of each code. General efficient decoding is separate. This is meaningful common-recovery machinery'),
('It gives (p_{\\rm bad}(t)\\le\\eta+\\epsilon t) and, for correct initial logical input, deterministic error at most',
 'For forward times (t\\ge0), it gives (p_{\\rm bad}(t)\\le\\eta+\\epsilon t) and, for correct initial logical input, deterministic error at most'),
('proves (2b_Q\\le D(Q\\omega Q\\|\\omega)\\le\\beta a_Qp). The scalar inequality follows by setting (x/y=e^u) and using (\\tanh(u/4)\\le u/4).',
 'proves (2b_Q\\le D(Q\\omega Q\\|\\omega)\\le\\beta a_Qp). For the scalar inequality, exchange (x,y) if necessary so (x\\ge y), set (x/y=e^u), and use (\\tanh(u/4)\\le u/4) for (u\\ge0).')
]
for a,b in changes:
    assert a in s,a
    s=s.replace(a,b)

# Restore inline math delimiters lost by a non-raw string in the first draft.
# Leave equation references, ordinary prose, code and Markdown links.
converted=[]
def line_math(line):
    out=[];i=0;backtick=False;dollar=False
    while i<len(line):
        c=line[i]
        if c==chr(96):backtick=not backtick
        if c=='$' and not backtick:dollar=not dollar
        if c!='(' or backtick or dollar or (i and line[i-1]==']'):
            out.append(c);i+=1;continue
        depth=1;j=i+1
        while j<len(line) and depth:
            if line[j]=='(':depth+=1
            elif line[j]==')':depth-=1
            j+=1
        if depth:out.append(c);i+=1;continue
        inner=line[i+1:j-1]
        math=bool(re.search(r'\\[A-Za-z]|\^|_|[<>=]|^[A-Za-z]$|^3/4(?:-o\(1\))?$',inner))
        if math:
            out.append('$'+inner+'$');converted.append(inner)
        else:out.append(line[i:j])
        i=j
    return ''.join(out)

result=[];fence=False;display=False
for line in s.splitlines(keepends=True):
    if line.lstrip().startswith(chr(96)*3):fence=not fence;result.append(line);continue
    if line.strip()==r'\[':display=True;result.append(line);continue
    if line.strip()==r'\]':display=False;result.append(line);continue
    result.append(line if fence or display else line_math(line))
s=''.join(result)
s=s.replace('replace (7) throughout','replace $7$ throughout').replace('the displayed (7) applies','the displayed $7$ applies')
s=s.replace('\u200b','')
p.write_text(s)
report={'pre_review_sha256':original_sha,'corrections':len(changes),
        'inline_math_delimiters_restored':len(converted),
        'final_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
        'reviews_addressed':['auditor_final_dossier_audit.md','constructor_dossier_review.md','machinery_final_review.md']}
Path('work/quantum-memory-20261106/checks/DOSSIER_CORRECTIONS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
