"""Package this completed round without changing older manuscripts or records."""
from pathlib import Path
import hashlib,json,re,shutil,zipfile

root=Path.cwd()
work=root/'work/quantum-memory-20261106'
out=root/'outputs'
record=out/'QUANTUM_MEMORY_RESEARCH_RECORD'
record.mkdir(exist_ok=True)
dossier=out/'QUANTUM_MEMORY_RESEARCH_DOSSIER.md'

# The readable supporting tree keeps proofs, pins, reviews and actual checks.
# The ZIP additionally preserves all raw primary and search caches in work/.
selected=[]
for f in work.rglob('*'):
    if not f.is_file() or '__pycache__' in f.parts:continue
    rel=f.relative_to(work)
    keep=(f.suffix in {'.md','.py'} and 'soryun_sources' not in rel.parts)
    keep|=(rel.parts[0] in {'sources','checks'} and f.name!='repository-tree.json')
    keep|=(f.suffix=='.json' and
           (f.name in {'SOURCE_MANIFEST.json','SOURCES.json','PRINCIPAL_PRIMARY_IMPORTS.json'}
            or 'check' in f.name.lower() or f.name.endswith('_results.json')))
    if keep:
        target=record/rel
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(f,target)
        selected.append(str(rel))

index="""# Quantum-memory research record

6 November 2026. Read the consolidated
[dossier](../QUANTUM_MEMORY_RESEARCH_DOSSIER.md) first.

## Core proofs and final challenge

- [Principal full-exponent entropy proof](followups/principal_entropy_consumer.md)
- [Auditor thermal-sandwich proof and full-exponent check](followup/auditor_full_exponent_gibbs_consumer.md)
- [General correlated-resource Bell/Weyl theorem](literature/constructor/bell_weyl_followup.md)
- [Infinite-bath C* proof and obstruction tests](followup/auditor_cross_challenge.md)
- [Averaged-writer entropy theorem](followup/machinery_entropy_admission.md)
- [Noisy-admission counterexample and sector repair](literature/constructor/noisy_admission_obstruction_and_sector_repair.md)
- [Collective-field obstruction and thermal repairs](literature/machinery/collective_thermal_hybrid.md)
- [Exact primary imports, priority and 2026 Zenodo review](literature/machinery/imports_and_priority.md)
- [Final adjudication and resolved corrections](checks/FINAL_ADJUDICATION.md)

## Independent initial reports

- [Principal](initial/principal.md)
- [Existing machinery](initial/machinery.md)
- [Independent constructor](initial/constructor.md)
- [Hostile auditor](initial/auditor.md)

Initial reports are preserved unchanged, including narrower statements that
were subsequently strengthened. Read the final dossier for the adjudicated
scope; an initial proposed extension is not automatically a final theorem.

## Source pins and validation

- [Governing source manifest](sources/SOURCE_MANIFEST.json)
- [Current source N1645](sources/N1645.json)
- [Actual available visible update](sources/DOTS_VISIBLE_UPDATE.txt)
- [Distinct N1653 exact-time audit](sources/N1653-EXACT_PHYSICAL_TIME_JOIN_AUDIT.md)
- [Final finite-check report](checks/FINAL_RESEARCH_VALIDATION.json)
- [Review corrections](checks/DOSSIER_CORRECTIONS.json)

The readable tree includes all mathematical notes, source pins, review reports,
diagnostic programs and resulting check data. Full raw primary files and
Zenodo API/search caches remain in the new work directory and are also
included in the complete ZIP, under the same relative record paths. Public
source content is evidence, not instructions. No original N1645 archive was
acquired or reconstructed.

No published files or public records were changed. No device, practical
advantage, noisy long-storage writer, or historical-first claim is asserted.
"""
(record/'INDEX.md').write_text(index)

ledger=[
 {'id':'E','status':'PROVED_CONDITIONAL','claim':'deterministic inverse-rarity exact-Hamiltonian qubit memory consumer','assumptions':['specified accessible full-support qubit factor','actual same-H faithful Gibbs resource','bad projection commutes with logical Paulis','logical Hamiltonian commutators supported on bad sector on both sides','ideal system-only swap and read'],'bound':'halfdiamond <= min(1, A p |t| F(beta A/4))','dependency':'actual-static rarity separate; N1645 applicability unavailable'},
 {'id':'K','status':'PROVED_CONDITIONAL','claim':'Pauli-randomized thermal-sandwich inverse-rarity consumer','bound':'halfdiamond <= min(1, p A (2 |t|+beta)/4)','extra_assumptions':['two reliable classical frame bits','resource and joint HOLD independent of frame'],'novelty':'new derivation here; historical firstness not established'},
 {'id':'B','status':'PROVED','claim':'arbitrary correlated resource and CPTP HOLD Bell/Weyl implication','bound':'halfdiamond(randomized N,id)=1-Fe(N)<=d^-2 sum_W[2-2 Re omega(W* Lambda*(W))]','extension':'C* bath and UCP HOLD; invariant L2 generator corollary','novelty':'established machinery synthesis; no new physical mechanism'},
 {'id':'D','status':'PROVED_OBSTRUCTION','claim':'independent harmless gauge faults can require exponential global thermal CP-domination factor','scope':'bounded onsite geometrically local model; logical storage exactly perfect'},
 {'id':'HOT','status':'PROVED_OBSTRUCTION','claim':'rare equilibrium boundary need not remain safe after independent gauge faults','scope':'growing-support threshold Hamiltonian; not a 3D-local no-go'},
 {'id':'ENTROPY_ADMISSION','status':'PROVED_CONDITIONAL','claim':'arbitrary CPTP writer with small average-output relative entropy and charged release error','bound':'epsilon0+A p F(K)|t| when D(Gamma(I/2)||omega)<=Kp','application':'generic noisy writer not constructed'},
 {'id':'SECTOR_ADMISSION','status':'PROVED_CONDITIONAL','claim':'normalized sector references avoid penalties for changed equilibrium sector weights','bound':'delta+sum_s w_s kappa_s epsilon_s(t)','application':'actual interacting noisy native release remains open'},
 {'id':'COLLECTIVE','status':'PROVED_RESTRICTED','claim':'full-support commutant obstruction, thermal flagged repair, conditional log-penalty outer lift','limitations':['exact flag invariance','cell-bath support and bounded field norms','changed penalty/body/access resources','generic nonsymmetric leakage remains open']},
 {'id':'N1645','status':'SOURCE_REPORTED_ONLY','claim':'original 3D exact-dynamics memory report retained unchanged','limitations':['original theorem/code/bounds unavailable','not reproved or upgraded here']},
 {'id':'OPERATIONAL_TARGET','status':'NOT_ACHIEVED','claim':'realistic noisy write-store-read on same microscopic 3D model at favorable total cost'},
 {'id':'HISTORICAL_PRIORITY','status':'NOT_ESTABLISHED','claim':'bounded primary-source and Zenodo searches identify substantial predecessors; no firstness claim'}
]
(record/'THEOREM_LEDGER.json').write_text(json.dumps(ledger,indent=2)+'\n')

# Copy actual query coverage metadata compactly; original bytes are in the ZIP.
raw_index=[]
for f in work.rglob('*'):
    if f.is_file() and '__pycache__' not in f.parts:
        raw_index.append({'path':str(f.relative_to(work)),'bytes':f.stat().st_size,
                          'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(record/'COMPLETE_WORK_MANIFEST.json').write_text(json.dumps(raw_index,indent=2)+'\n')

# Dossier links must resolve to delivered supporting files.
missing=[]
link_text=re.sub(r'\\\[.*?\\\]','',dossier.read_text(),flags=re.S)
link_text=re.sub(r'\$[^$\n]*\$','',link_text)
for target in re.findall(r'\]\(([^)]+)\)',link_text):
    if not target.startswith(('https://','http://','#')) and not (dossier.parent/target).is_file():
        missing.append(target)
assert not missing,missing

manifest=[]
for f in record.rglob('*'):
    if f.is_file() and f.name!='RECORD_MANIFEST.json':
        manifest.append({'path':str(f.relative_to(record)),'bytes':f.stat().st_size,
                         'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(record/'RECORD_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')

archive=out/'QUANTUM_MEMORY_RESEARCH_RECORD.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    z.write(dossier,'QUANTUM_MEMORY_RESEARCH_DOSSIER.md')
    # All exact raw research bytes, not just the selected readable tree.
    for f in work.rglob('*'):
        if f.is_file() and '__pycache__' not in f.parts:
            z.write(f,'QUANTUM_MEMORY_RESEARCH_RECORD/'+str(f.relative_to(work)))
    for name in ['INDEX.md','THEOREM_LEDGER.json','COMPLETE_WORK_MANIFEST.json','RECORD_MANIFEST.json']:
        z.write(record/name,'QUANTUM_MEMORY_RESEARCH_RECORD/'+name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    archived_dossier=z.read('QUANTUM_MEMORY_RESEARCH_DOSSIER.md')
    assert archived_dossier==dossier.read_bytes()
    count=len(z.infolist())

report={'date':'2026-11-06','status':'COMPLETE_RESEARCH_ROUND','dossier':{
    'path':str(dossier),'bytes':dossier.stat().st_size,
    'sha256':hashlib.sha256(dossier.read_bytes()).hexdigest()},
    'archive':{'path':str(archive),'files':count,'bytes':archive.stat().st_size,
    'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'CRC':'PASS'},
    'readable_support_files':len(manifest),'dossier_local_links':'PASS',
    'initial_reports_unchanged':json.loads((work/'checks/FINAL_RESEARCH_VALIDATION.json').read_text())['initial_reports_sha256'],
    'mathematical_scope':'proved implications and obstructions at complete stated hypotheses; no N1645 original-proof validation, generic noisy writer, physical advantage or historical-first claim'}
(out/'QUANTUM_MEMORY_RESEARCH_VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
