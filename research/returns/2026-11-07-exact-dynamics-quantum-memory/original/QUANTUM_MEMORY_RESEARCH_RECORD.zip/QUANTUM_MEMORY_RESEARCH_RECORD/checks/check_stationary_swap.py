"""Finite diagnostics for the independently proved stationary-swap inequalities.

These checks test algebra, constants, and obstruction examples. They are not
infinite-volume proofs or evidence of practical quantum-memory advantage.
"""
import json
from pathlib import Path
import numpy as np

rng = np.random.default_rng(16452026)

def adj(a):
    return a.conj().T

def herm(n):
    a = rng.normal(size=(n, n)) + 1j*rng.normal(size=(n, n))
    return (a+adj(a))/(2*np.sqrt(n))

def spectral(a, f):
    x,v = np.linalg.eigh(a)
    return (v*f(x))@adj(v)

def thermal(h,beta):
    a = spectral(h, lambda x: np.exp(-beta*(x-x.min())))
    return a/np.trace(a)

def partial_l(a,d,g):
    return np.einsum('iaib->ab',a.reshape(d,g,d,g))

def weyl(d):
    z=np.diag(np.exp(2j*np.pi*np.arange(d)/d))
    x=np.roll(np.eye(d),1,axis=0)
    return [np.linalg.matrix_power(x,a)@np.linalg.matrix_power(z,b)
            for a in range(d) for b in range(d)]

rows=[]
for d,g in [(2,1),(2,2),(2,3),(3,2),(3,3)]:
    for trial in range(4):
        h=herm(d*g)
        omega=thermal(h,0.3+trial)
        gauge=partial_l(omega,d,g)
        bell=np.eye(d).reshape(-1)/np.sqrt(d)
        phi=np.outer(bell,bell)
        p=np.kron(phi,np.eye(g))
        xi=np.kron(np.eye(d)/d,omega)
        j0=np.kron(phi,gauge)
        w=weyl(d)
        q=sum(float(np.trace(omega@adj(h@np.kron(a,np.eye(g))-
                np.kron(a,np.eye(g))@h)@(h@np.kron(a,np.eye(g))-
                np.kron(a,np.eye(g))@h)).real) for a in w)/(d*d)
        hr=np.kron(np.eye(d),h)
        comm=hr@p-p@hr
        qb=d*d*np.trace(xi@adj(comm)@comm).real
        assert np.linalg.norm(d*d*p@xi@p-j0)<1e-11
        assert abs(q-qb)<1e-10
        assert np.linalg.norm(h@omega-omega@h)<1e-11
        for t in [0.,0.01,0.1,0.5,1.,3.]:
            u=np.kron(np.eye(d),spectral(h,lambda e:np.exp(-1j*t*e)))
            failure=1-np.trace(p@u@j0@adj(u)).real
            assert failure<=t*t*q+1e-10
            rows.append(dict(d=d,g=g,trial=trial,t=t,q=q,
                             entanglement_failure=float(failure),bound=t*t*q))

# Same-system-and-bath-marginals do not control exact joint dynamics.
i=np.eye(2,dtype=complex)
x=np.array([[0,1],[1,0]],complex)
y=np.array([[0,-1j],[1j,0]],complex)
z=np.diag([1.,-1.])
c=.8
h=np.kron(x,z)
u=spectral(h,lambda e:np.exp(-1j*np.pi*e/4))
rho_plus=(np.eye(4)+c*np.kron(y,z))/4
rho_minus=(np.eye(4)-c*np.kron(y,z))/4
def partial_b(a):
    return np.einsum('aibi->ab',a.reshape(2,2,2,2))
assert np.linalg.norm(partial_b(rho_plus)-partial_b(rho_minus))<1e-12
assert np.linalg.norm(partial_l(rho_plus,2,2)-partial_l(rho_minus,2,2))<1e-12
distance=sum(abs(np.linalg.eigvalsh(partial_b(u@rho_plus@adj(u))-
                     partial_b(u@rho_minus@adj(u)))))
assert abs(distance-2*c)<1e-11

# Small coherent logical errors have no finite CP domination by the ideal
# identity writer: distinct rank-one Choi supports already exclude it.
theta=.01
v=spectral(z,lambda e:np.exp(1j*theta*e))
bell=np.eye(2).reshape(-1)/np.sqrt(2)
bad=np.kron(i,v)@bell
outside=1-abs(np.vdot(bell,bad))**2
assert outside>0

result=dict(status='PASS',seed=16452026,inequality_cases=len(rows),
            max_bound_violation=max(r['entanglement_failure']-r['bound'] for r in rows),
            identical_marginal_output_trace_norm=float(distance),
            coherent_writer_choi_outside_support=float(outside),cases=rows,
            scope='finite diagnostics only; proofs and infinite-volume assumptions separate')
path=Path(__file__).with_name('stationary_swap_results.json')
path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))
