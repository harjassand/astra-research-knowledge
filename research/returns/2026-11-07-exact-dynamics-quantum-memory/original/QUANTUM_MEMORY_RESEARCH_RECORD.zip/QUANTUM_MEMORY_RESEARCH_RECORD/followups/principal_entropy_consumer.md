# Full rare-event lifetime exponent from an entropy estimate

6 November 2026. This derivation was obtained after the initial reports were exchanged and after reading the existing N1653 exact-time consumer. All three researchers independently checked the core inequalities. It strengthens that consumer at its displayed conditional hypotheses; it does not supply N1645's missing code or theorem. Existing relative-entropy and channel machinery is credited, not claimed as newly discovered.

## 1. Exact theorem, with a general imperfect writer

Let the accessible physical memory have a specified full-support tensor factorization S=C^2_L tensor A. Include all inaccessible bath degrees of freedom in G=A tensor B. Let H be any finite-dimensional self-adjoint Hamiltonian on L tensor G and let omega be a faithful state with [H,omega]=0. Let Q_X,Q_Y,Q_Z be the specified system-supported logical Pauli algebra. Suppose a projector P commutes with all three Q_a, and

    A_a=i[H,Q_a]=P A_a P,  ||A_a|| <= a_a,
    p=Tr(omega P),  A=sum_a a_a.

Let Gamma:M_2 -> trace-class(L tensor G) be a physically specified CPTP writing channel, including its resource state, ancillas and finite control interval. Its input is independent of its fixed resource and can be entangled with an arbitrary reference. Set sigma=Gamma(I/2). Suppose

    D(sigma||omega) <= K p,
    half||Tr_G Gamma - id_2||_diamond <= epsilon_0.

Then the SAME exact-Hamiltonian HOLD and specified logical readout obey, for every real t,

    half||Tr_G Ad(e^{-itH}) Gamma-id_2||_diamond
       <= min{1, epsilon_0 + A p |t| F(K)},
    F(K)=inf_{lambda>0} (K+e^lambda-1)/lambda
       <= K+e-1.

For K=0 take F(0)=1 by the limit lambda down to0. No bath renewal, Markov approximation, detailed balance or weak-coupling time rescaling occurs. Only the averaged joint output of the writer is constrained by entropy; initial logical error is charged separately. This is a sufficient admission condition, not a construction of a constant-rate noisy writer. It is not necessary: harmless extensive gauge faults may have large D.

### Complete proof

Write sigma_t=U_t sigma U_t^*. Unitary invariance of relative entropy and stationarity of omega give D(sigma_t||omega)=D(sigma||omega)<=Kp. Measure the two-outcome observable {P,I-P}. If q_t=Tr(P sigma_t), data processing gives

    d_binary(q_t||p) <= D(sigma_t||omega).

The classical exponential variational inequality for Bernoulli laws gives, for any lambda>0,

    lambda q_t <= d_binary(q_t||p)+log(1-p+p e^lambda)
               <= Kp+p(e^lambda-1).

The scalar inequality follows directly by nonnegativity of relative entropy to the tilted Bernoulli distribution with success probability p e^lambda/(1-p+p e^lambda). Therefore q_t<=p F(K), uniformly for all times.

For any input-reference state xi_LR, its physical marginal at release is Gamma(xi_L). Since 0<=xi_L<=I=2(I/2), positivity gives Gamma(xi_L)<=2 sigma and hence its time-t bad probability is at most2q_t. This comparison is only on the physical marginal; no incorrect reference-dimension domination is used.

Let theta_LR(t) be the decoded joint logical-reference state. Expand its derivative in the Pauli basis:

    theta'_LR(t)=(1/2) sum_a Q_a tensor C'_a,R(t),
    C'_a,R(t)=Tr_(L,G)[(A_a tensor I_R) theta_total(t)].

For every Hermitian reference contraction B_R, the two-sided support and norm hypotheses give

    |Tr[(A_a tensor B_R)theta_total(t)]|
       <= a_a Tr[(P tensor I_R)theta_total(t)].

By trace-norm duality, ||C'_a,R(t)||_1 is at most the right-hand side. Since ||Q_a||_1=2, half||theta'_LR(t)||_1 <= (A/2) p_bad(t) <= A q_t. Integrate between0 andt, add the initial complete-channel error epsilon_0, and take the supremum over every reference and input. This proves the theorem. QED.

The quantum-relative-entropy import is the finite CPTP data-processing inequality, for example Theorem1 in Mueller-Hermes--Reeb, arXiv:1512.06117v2 (26 September2016), which actually allows positive trace-preserving maps on separable trace-class spaces. Here omega is faithful and both flag measurement and the writer maps are finite CPTP, so support/domain hypotheses are satisfied. The scalar exponential estimate, Pauli expansion and domination are proved above. The source's entropy theorem is credited to established Lindblad/Uhlmann machinery; no historical-first claim is made.

## 2. Actual joint Gibbs resource and ideal logical SWAP

Assume now omega=e^{-beta H}/Z, beta>=0 finite. Write an independent unknown logical qubit into the exposed L by deterministic SWAP and discard the old L. This produces the legal joint encoding

    E(rho)=rho tensor omega_G,  omega_G=Tr_L omega.

In particular its averaged output is

    Omega=E(I/2)=(1/4)sum_(Q=I,X,Y,Z) Q omega Q.

For each nonidentity Hermitian Pauli Q,

    D(Q omega Q||omega)=beta Tr[omega(Q H Q-H)].

Because QHQ-H=-i Q A_Q, the assumed commutation of Q and P and the two-sided support of A_Q imply QHQ-H=P(QHQ-H)P and norm at most a_Q. Consequently its expectation is at most a_Q p. Convexity of relative entropy in its first argument gives

    D(Omega||omega) <= (beta p/4) sum_Q a_Q = beta A p/4.

The writing channel decodes perfectly at time0. Applying the theorem with epsilon_0=0 and K=beta A/4 yields

    half||N_t-id||_diamond
       <= min{1, A p |t| F(beta A/4)}
       <= min{1, A p |t| (beta A/4+e-1)}.       (E)

This is a deterministic reference-safe channel, with no added Weyl-frame randomness and no nonzero bound at time0. Convexity here can be derived directly from entropy concavity; the faithful finite Gibbs state guarantees every relative entropy exists. The full actual joint equilibrium state, logical subsystem access, finite write/read controls and their costs remain assumptions.

## 3. Consequence for the supplied rare-boundary model

If a separately established family satisfies

    p_n <= C n^r exp(-c n^eta),   A_n <= C' n^s,

at a fixed finite beta, then (E) has upper bound poly(n)|t|exp(-c n^eta). For every fixed epsilon>0, it tends to zero uniformly for |t|<=exp((c-epsilon)n^eta). This retains the FULL rare-event exponent c, whereas the cached N1653 consumer first used Pinsker and retained only coefficients below c/2. This is an improvement of a conditional exact-dynamics consumer, not an improvement of a hardware model or a proof of N1645.

The cached N1653 root/audit state the required bad-supported commutator and actual-Gibbs rare-probability premises for their own distinct native qubit/seven-level-clock construction. The new consumer uses those displayed premises but does not independently reprove the mixed rod/source static construction or silently identify it with the missing N1645 package. The historical audit root SHA cited inside that receipt differs from the currently cached root SHA; both are retained in the record and no exact-current-byte audit is inferred from the old receipt.

## 4. What fails under generic noisy loading

A small local fault rate does not imply D(Gamma(I/2)||omega)=O(p_n) when p_n is exponentially small. Independent faults on many entirely harmless gauge spins already produce extensive relative entropy and exponentially large global CP-domination constants, while the logical subsystem can remain perfectly protected forever. Thus this theorem gives an honest sufficient basin and a stronger exact-equilibrium consumer; it neither identifies a necessary basin nor earns a physical threshold.

The most promising repair is a family of dynamically safe conditional gauge references or a code-specific fault-cluster admission theorem. Such a theorem must control the same joint actual-bath process over the complete storage interval, preserve input references, and account for preparation/readout/reset resources. Those operations remain unproved here.
