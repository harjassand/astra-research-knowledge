"""Finite diagnostics for the independently proved Pauli-twirl identity.

This is an algebra/constant check, not an infinite-size memory proof.
Run with the available system Python that has numpy.
"""
import json
from pathlib import Path
import numpy as np

I = np.eye(2, dtype=complex)
X = np.array([[0, 1], [1, 0]], complex)
Y = np.array([[0, -1j], [1j, 0]], complex)
Z = np.diag([1.0, -1.0]).astype(complex)
paulis = [I, X, Y, Z]
rng = np.random.default_rng(1645)


def norm1(a):
    return float(np.linalg.svd(a, compute_uv=False).sum())


def norm2w_sq(a, w):
    return float(np.trace(w @ a.conj().T @ a).real)


def ptr_l(a, m):
    return np.einsum("abad->bd", a.reshape(2, m, 2, m))


def exp_hermitian(h, c):
    values, vectors = np.linalg.eigh(h)
    return (vectors * np.exp(c*values)) @ vectors.conj().T


identity_residual = []
gibbs_twirl_residual = []
hold_residual = []
samples = []
for m in (1, 2, 3, 4):
    for k in range(20):
        a = rng.normal(size=(2*m, 2*m)) + 1j*rng.normal(size=(2*m, 2*m))
        h = (a+a.conj().T)/(4*m)
        beta = float(rng.uniform(0.01, 2))
        t = float(rng.uniform(0, 3))
        w = exp_hermitian(h, -beta)
        w /= np.trace(w)
        tau = ptr_l(w, m)
        wbar = np.kron(I/2, tau)
        u = exp_hermitian(h, -1j*t)
        ps = [np.kron(p, np.eye(m)) for p in paulis]
        au = ptr_l(u, m)/2
        fe = float(np.trace(tau @ au.conj().T @ au).real)
        comms = [u@p-p@u for p in ps[1:]]
        rhs = sum(norm2w_sq(c, wbar) for c in comms)/8
        identity_residual.append(abs(1-fe-rhs))
        eta = [np.sqrt(max(0, norm2w_sq(h@p-p@h, w))) for p in ps[1:]]
        delta = norm1(wbar-w)
        gibbs_twirl_residual.append(delta-beta*sum(eta)/4)
        certified = t*t*sum(q*q for q in eta)/8+1.5*delta
        hold_residual.append((1-fe)-certified)
        samples.append({"gauge_dimension":m,"beta":beta,"t":t,"entanglement_infidelity":1-fe,
                        "identity_rhs":rhs,"gibbs_twirl_distance":delta,
                        "eta":eta,"certified_infidelity_bound":certified})

thermal_examples = []
for x in (0.001, 0.1, 1, 4):
    r = float(np.tanh(x))
    tau0, tau1 = (I-r*Z)/2, (I+r*Z)/2
    coherence = float(np.sqrt(1-r*r))
    thermal_examples.append({"beta_g":x,"bath_distance":norm1(tau0-tau1)/2,
                             "local_writer_distance_floor":norm1(tau0-I/2)/2,
                             "sharp_coherent_access_error_floor":(1-coherence)/2})

summary = {"samples":len(samples),"max_twirl_identity_residual":max(identity_residual),
           "max_gibbs_twirl_bound_violation":max(0,max(gibbs_twirl_residual)),
           "max_hold_bound_violation":max(0,max(hold_residual)),
           "thermal_examples":thermal_examples}
assert summary["max_twirl_identity_residual"] < 1e-12
assert summary["max_gibbs_twirl_bound_violation"] < 1e-12
assert summary["max_hold_bound_violation"] < 1e-12
p = Path(__file__).with_name("channel_identity_checks.json")
p.write_text(json.dumps({"summary":summary,"samples":samples},indent=2)+"\n")
print(json.dumps(summary,indent=2))
