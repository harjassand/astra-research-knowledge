"""Check stationary Bell/Weyl bridge; finite diagnostics, not asymptotic proof."""
import json
from pathlib import Path
import numpy as np

rng = np.random.default_rng(20261106)


def partial_trace_l(a, d, m):
    return np.einsum('abad->bd', a.reshape(d, m, d, m))


def partial_trace_g(a, d, m):
    return np.einsum('abcb->ac', a.reshape(d, m, d, m))


def n2(a, w):
    return float(np.trace(w @ a.conj().T @ a).real)


def weyls(d):
    x = np.roll(np.eye(d), 1, axis=0)
    z = np.diag(np.exp(2j*np.pi*np.arange(d)/d))
    return [np.linalg.matrix_power(x,a) @ np.linalg.matrix_power(z,b)
            for a in range(d) for b in range(d)]


cases = []
max_bell_expansion = max_q_normalization = max_r_normalization = 0.0
max_twirl_offdiag = max_channel_identity = max_ch_bound = max_q_bound = 0.0
for d in (2, 3, 4, 5, 7):
    for m in (1, 2, 3):
        ws = weyls(d)
        wps = [np.kron(w,np.eye(m)) for w in ws]
        phi = np.eye(d).reshape(-1)/np.sqrt(d)
        bell = np.outer(phi,phi)
        p = np.kron(bell,np.eye(m))
        bell_basis = np.stack([np.kron(np.eye(d),w) @ phi for w in ws],axis=1)
        p_expand = sum(np.kron(w.conj(),wp) for w,wp in zip(ws,wps))/(d*d)
        max_bell_expansion=max(max_bell_expansion,float(np.linalg.norm(p-p_expand)))
        for state_type in ('full_rank','pure','two_eigenvalues'):
            a = rng.normal(size=(d*m,d*m))+1j*rng.normal(size=(d*m,d*m))
            h = (a+a.conj().T)/(d*m)
            energies,vectors=np.linalg.eigh(h)
            if state_type=='full_rank': weights=rng.random(d*m)
            elif state_type=='pure': weights=np.eye(1,d*m,0).reshape(-1)
            else: weights=np.array([1 if k<2 else 0 for k in range(d*m)])
            weights=weights/weights.sum()
            omega=(vectors*weights) @ vectors.conj().T
            tau=partial_trace_l(omega,d,m)
            xi=np.kron(np.eye(d)/d,omega)
            hp=np.kron(np.eye(d),h)
            q=sum(n2(h@wp-wp@h,omega) for wp in wps)/(d*d)
            q_bell=d*d*n2(hp@p-p@hp,xi)
            max_q_normalization=max(max_q_normalization,abs(q-q_bell))
            for t in (0.001,0.3,1.0,4.0):
                u=(vectors*np.exp(-1j*t*energies)) @ vectors.conj().T
                a0=partial_trace_l(u,d,m)/d
                fe=float(np.trace(tau @ a0.conj().T @ a0).real)
                infid=1-fe
                rt=sum(n2(u.conj().T@wp@u-wp,omega) for wp in wps)/(d*d)
                up=np.kron(np.eye(d),u)
                r_bell=d*d*n2(up@p-p@up,xi)
                max_r_normalization=max(max_r_normalization,abs(rt-r_bell))
                j=np.zeros((d*d,d*d),complex)
                for i in range(d):
                    for j0 in range(d):
                        eij=np.zeros((d,d));eij[i,j0]=1
                        output=partial_trace_g(u@np.kron(eij,tau)@u.conj().T,d,m)
                        j += np.kron(eij,output)/d
                jt=sum(np.kron(w.T,w.conj().T) @ j @ np.kron(w.conj(),w) for w in ws)/(d*d)
                diag=bell_basis.conj().T @ jt @ bell_basis
                offdiag=diag-np.diag(np.diag(diag))
                max_twirl_offdiag=max(max_twirl_offdiag,float(np.linalg.norm(offdiag)))
                half_ch_trace=float(np.linalg.svd(jt-bell,compute_uv=False).sum()/2)
                max_channel_identity=max(max_channel_identity,abs(half_ch_trace-infid))
                max_ch_bound=max(max_ch_bound,infid-rt)
                max_q_bound=max(max_q_bound,infid-t*t*q)
                cases.append(dict(d=d,gauge_dim=m,state=state_type,t=t,infidelity=infid,
                                  r=rt,q=q,twirled_half_choi_trace_distance=half_ch_trace))

cp_cases=[]
max_cp_identity=max_cp_bound=0.0
for d in (2,3,4):
    for m in (1,2):
        n=d*m
        ws=weyls(d)
        wps=[np.kron(w,np.eye(m)) for w in ws]
        for k in range(10):
            a=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n))
            omega=a@a.conj().T;omega/=np.trace(omega)
            tau=partial_trace_l(omega,d,m)
            a=rng.normal(size=(3*n,n))+1j*rng.normal(size=(3*n,n))
            isometry=np.linalg.qr(a)[0]
            kraus=[isometry[j*n:(j+1)*n] for j in range(3)]
            fe=0.0
            for a in kraus:
                a0=partial_trace_l(a,d,m)/d
                fe+=float(np.trace(tau@a0.conj().T@a0).real)
            comm_avg=sum(n2(a@w-w@a,omega) for a in kraus for w in wps)/(d*d)
            corr_avg=sum(2-2*float(np.trace(omega@w.conj().T@sum(a.conj().T@w@a for a in kraus)).real)
                         for w in wps)/(d*d)
            max_cp_identity=max(max_cp_identity,abs(comm_avg-corr_avg))
            max_cp_bound=max(max_cp_bound,1-fe-corr_avg)
            cp_cases.append(dict(d=d,gauge_dim=m,infidelity=1-fe,
                                 kraus_commutator_average=comm_avg,correlation_average=corr_avg))

summary=dict(cases=len(cases),general_cptp_cases=len(cp_cases),max_bell_expansion_residual=max_bell_expansion,
             max_q_normalization_residual=max_q_normalization,max_r_normalization_residual=max_r_normalization,
             max_weyl_twirl_offdiagonal=max_twirl_offdiag,max_twirl_error_identity_residual=max_channel_identity,
             max_direct_correlation_bound_violation=max(0,max_ch_bound),
             max_commutator_bound_violation=max(0,max_q_bound),
             max_general_cp_correlation_identity_residual=max_cp_identity,
             max_general_cp_bound_violation=max(0,max_cp_bound))
for key,value in summary.items():
    if key not in ('cases','general_cptp_cases'): assert value<1e-10,(key,value)
out=Path(__file__).with_name('stationary_weyl_bridge_checks.json')
out.write_text(json.dumps(dict(summary=summary,cases=cases,general_cptp_cases=cp_cases),indent=2)+'\n')
print(json.dumps(summary,indent=2))
