"""Finite checks of both-sided bad-sector Gibbs correlation and entropy bounds."""
import json
from pathlib import Path
import numpy as np
rng=np.random.default_rng(1653)
I=np.eye(2,dtype=complex)
X=np.array([[0,1],[1,0]],complex)
Y=np.array([[0,-1j],[1j,0]],complex)
Z=np.diag([1.,-1.]).astype(complex)
checks=[]
errors={k:0. for k in ('bad_support','relative_entropy_bound','skew_bound',
                      'symmetric_derivative_bound','spectral_comparison_bound',
                      'linear_correlation_bound','linear_channel_bound',
                      'entropy_uniform_bad_probability_bound')}

def pt_l(a,m):return np.einsum('abad->bd',a.reshape(2,m,2,m))

for m in (2,3,4):
 for beta in (0.2,1.,5.):
  for gap in (0.,5.,20.):
   for mix in (0.,0.02,0.5):
    pg=np.diag([0.]*(m-1)+[1.]).astype(complex)
    pbad=np.kron(I,pg)
    z=rng.normal(size=(m,m))+1j*rng.normal(size=(m,m))
    kg=mix*(z+z.conj().T)/(2*m)+gap*pg
    v=sum(rng.uniform(-0.8,0.8)*np.kron(p,pg) for p in (X,Y,Z))
    h=np.kron(I,kg)+v
    en,vec=np.linalg.eigh(h)
    weights=np.exp(-beta*(en-en.min()));weights/=weights.sum()
    omega=(vec*weights)@vec.conj().T
    sw=(vec*np.sqrt(weights))@vec.conj().T
    prob=float(np.trace(omega@pbad).real)
    tau=pt_l(omega,m)
    omegabar=np.kron(I/2,tau)
    facts=[]
    for p in (X,Y,Z):
     q=np.kron(p,np.eye(m));aq=1j*(h@q-q@h)
     anorm=float(np.linalg.norm(aq,2))
     skew=float(np.linalg.norm(q@sw-sw@q,'fro')**2)
     drel=float(beta*np.trace(omega@(q@h@q-h)).real)
     errors['bad_support']=max(errors['bad_support'],float(np.linalg.norm(aq-pbad@aq@pbad)))
     errors['relative_entropy_bound']=max(errors['relative_entropy_bound'],drel-beta*anorm*prob)
     errors['skew_bound']=max(errors['skew_bound'],2*skew-drel)
     facts.append((q,aq,anorm,skew,drel))
    for time in (0.01,0.3,2.,100.,min(1/max(prob,1e-40),1e5)):
     u=(vec*np.exp(-1j*time*en))@vec.conj().T
     e_sum=0.
     for q,aq,anorm,skew,drel in facts:
      qt=u.conj().T@q@u;dq=qt-q
      err=float(np.trace(omega@dq.conj().T@dq).real)
      s0=float(np.trace(sw@q@sw@q).real)
      st=float(np.trace(sw@q@sw@qt).real)
      deriv=abs(np.trace(sw@q@sw@(u.conj().T@aq@u)))
      bound=anorm*prob*(2*time+beta)
      errors['symmetric_derivative_bound']=max(errors['symmetric_derivative_bound'],float(deriv-anorm*prob))
      errors['spectral_comparison_bound']=max(errors['spectral_comparison_bound'],err-2*(s0-st)-2*skew)
      errors['linear_correlation_bound']=max(errors['linear_correlation_bound'],err-bound)
      e_sum+=err
     a0=pt_l(u,m)/2
     infid=1-float(np.trace(tau@a0.conj().T@a0).real)
     chbound=prob*sum(f[2] for f in facts)*(2*time+beta)/4
     errors['linear_channel_bound']=max(errors['linear_channel_bound'],infid-chbound)
     amax=max(f[2] for f in facts)
     evolved_bad=float(np.trace(pbad@u@omegabar@u.conj().T).real)
     uniform_bound=prob*(beta*amax+np.e-1)
     errors['entropy_uniform_bad_probability_bound']=max(errors['entropy_uniform_bad_probability_bound'],evolved_bad-uniform_bound)
     checks.append(dict(gauge_dim=m,beta=beta,gap=gap,mix=mix,t=time,p=prob,
                        commutator_norms=[f[2] for f in facts],infidelity=infid,
                        linear_channel_bound=chbound,correlation_average=e_sum/4,
                        actual_twirl_bad_probability=evolved_bad,entropy_uniform_bound=uniform_bound))
summary=dict(cases=len(checks),max_violations=errors,min_bad_probability=min(x['p'] for x in checks))
for key,val in errors.items():assert val<1e-9,(key,val)
Path(__file__).with_name('bad_sector_linear_bound_checks.json').write_text(json.dumps(dict(summary=summary,cases=checks),indent=2)+'\n')
print(json.dumps(summary,indent=2))
