# Two-generator strengthening of the thermal operational bridge

Derived after saving the independent initial report, 2026-11-06. No peer
construction used. All notation is from `../../initial/constructor.md`.

The three-correlation hypothesis can be reduced to two exact anticommuting
Hermitian unitaries `X,Z` on the accessible system. Define `Y=iXZ` (the harmless
sign convention does not matter). Suppose only

\[
 e_X(t),e_Z(t)\le\epsilon(t),\qquad
 b_X,b_Z\le b,
\]

where the two `b` values are controlled by the same Gibbs sech-kernel identity
proved in the initial report. Then the same explicit protocol obeys

\[
 d_\diamond(\widetilde T_t,id)
 \le {3\over4}\epsilon(t)+3\sqrt{\epsilon(t)b}+{15\over4}b
 \le {9\over4}\epsilon(t)+{21\over4}b.              \tag{A1}
\]

Thus two slow thermal generators suffice to obtain the same asymptotic
operational lifetime; one does not need a separate bound on the product Pauli.

Proof. The product commutator identity gives

\[
 \sqrt{b_Y}=\|[XZ,\sqrt\tau]\|_2
 \le\|X[Z,\sqrt\tau]\|_2+\|[X,\sqrt\tau]Z\|_2
 \le\sqrt{b_X}+\sqrt{b_Z}\le2\sqrt b.               \tag{A2}
\]

Also

\[
 X(t)Z(t)-XZ=X(t)[Z(t)-Z]+[X(t)-X]Z.
\]

Moving `Z` through `sqrt(tau)` in the second term, as in equation (6) of the
initial report, gives

\[
 \sqrt{e_Y(t)}\le\sqrt{e_X(t)}+\sqrt{e_Z(t)}
                           +2\sqrt{b_Z}
 \le2\sqrt{\epsilon(t)}+2\sqrt b.                  \tag{A3}
\]

For a fixed `P`, write `a_P=sqrt(e_P(t))`, `c=sqrt(b)`. Equation (2) of the
initial report, together with (A2), bounds its four-`Q` contribution by

\[
 {a_P^2+2(a_P+2c)^2+(a_P+4c)^2\over32}
 ={a_P^2\over8}+{a_Pc\over2}+{3c^2\over4}.
\]

Substitute `a_X,a_Z≤sqrt(ε)` and `a_Y≤2sqrt(ε)+2c`, then sum. The result is
the first inequality (A1); `sqrt(εb)≤(ε+b)/2` gives the second. QED.

This strengthens the mathematical input contract, not the physical control
claim. It still requires that the two generators define an exact full qubit
algebra on the accessible system, with an accurately implementable exposed
factorization. Two merely long-lived classical observables, two approximate
Paulis only on a projected subspace, or bath-supported operators do not suffice
as stated. Priority of this quantitative strengthening is unassessed.
