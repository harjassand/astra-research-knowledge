"""Finite checks for the noisy-admission obstruction; proof is in the Markdown note."""
import json
import math
from pathlib import Path
import numpy as np


def log_binomial(n, prob):
    return np.array([math.lgamma(n+1)-math.lgamma(w+1)-math.lgamma(n-w+1)
                     +w*math.log(prob)+(n-w)*math.log1p(-prob)
                     for w in range(n+1)])


def relative_entropy(a, b):
    return a*math.log(a/b)+(1-a)*math.log((1-a)/(1-b))


def run():
    q, p, delta = .02, .1, .01
    r = q+p*(1-2*q)
    theta = (q+r)/2
    rows = []
    for m in [64, 256, 1024, 4096]:
        lt, ls = log_binomial(m,q), log_binomial(m,r)
        h = math.ceil(theta*m)
        pt, ps = float(np.exp(lt[h:]).sum()), float(np.exp(ls[h:]).sum())
        lo, hi = 0., m*math.log(r/q)
        for _ in range(90):
            mid=(lo+hi)/2
            goodmass=float(np.exp(np.minimum(ls,lt+mid)).sum())
            if goodmass >= 1-delta: hi=mid
            else: lo=mid
        loglower=math.log(max(ps-delta,1e-300))-math.log(pt)
        assert hi+1e-8>=loglower
        assert pt <= math.exp(-m*relative_entropy(h/m,q))*(1+1e-10)
        rows.append(dict(m=m,thermal_hot=pt,noisy_hot=ps,
                         log_event_lower_bound_kappa=loglower,
                         log_exact_minimum_kappa_bad_mass_01=hi))
    beta, strength, m = 1., .2, 10
    alpha=(3*math.exp(-beta*strength)+math.exp(beta*strength))/4
    h=math.ceil(theta*m)
    strings=np.arange(2**m,dtype=int)
    weights=np.array([int(z).bit_count() for z in strings])
    hot=weights>=h
    base=q**weights*(1-q)**(m-weights)
    mu=base*np.where(hot,alpha,1.); mu/=mu.sum()
    noisy=mu.copy()
    for site in range(m):
        noisy=(1-p)*noisy+p*noisy[strings^(1<<site)]
    thermal_hot=float(mu[hot].sum())
    noisy_hot=float(noisy[hot].sum())
    assert abs(noisy.sum()-1)<1e-12
    swap=np.array([[1,0,0,0],[0,0,1,0],[0,1,0,0],[0,0,0,1]],complex)
    u=-1j*swap
    gauge=np.eye(2)/2
    phi=np.array([1,0,0,1])/np.sqrt(2)
    choi=np.zeros((4,4),complex)
    for i in range(2):
        for j in range(2):
            e=np.zeros((2,2));e[i,j]=1
            out=u@np.kron(e,gauge)@u.conj().T
            reduced=np.trace(out.reshape(2,2,2,2),axis1=1,axis2=3)
            choi+=np.kron(e,reduced)/2
    fehot=float(np.real(phi.conj()@choi@phi))
    assert abs(fehot-.25)<1e-12
    return dict(status='PASS',scope='finite algebra and diagonal optimization only',
                parameters=dict(q=q,p=p,r=r,theta=theta,bad_mass=delta),
                product_gauge=rows,
                hot_swap=dict(m=m,thermal_hot=thermal_hot,noisy_hot=noisy_hot,
                              hot_entanglement_fidelity=fehot,
                              any_reader_entanglement_failure_lower=.75*noisy_hot))


if __name__=='__main__':
    out=run();print(json.dumps(out,indent=2))
    Path(__file__).with_name('noisy_admission_check.json').write_text(json.dumps(out,indent=2)+'\n')
