# Noisy admission: a complete obstruction and a sector-conditioned repair

Focused followup, 2026-11-06. Same independent constructor; no new agents.
The original independent report and earlier post-exchange notes are preserved.

## What this round establishes

The proposed admission target

\[
 W=W_{\mathrm{good}}+W_{\mathrm{bad}},\qquad
 W_{\mathrm{good}}\le_{\mathrm{CP}}\kappa E_\gamma,
 \quad \|W_{\mathrm{bad}}^*(I)\|_\infty\le\delta,
 \quad E_\gamma(\rho)=\rho\otimes\gamma               \tag{1}
\]

cannot generally hold with subexponential `κ` under fixed-rate independent local
terminal faults. This fails even when the faults only disturb harmless thermal
gauge spins and the logical qubit remains perfectly protected forever under a
bounded-strength geometrically local Hamiltonian. Thus (1) is an excessively
strong sufficient condition, not a necessary noisy-memory gate.

A second finite construction shows why merely dropping (1) is insufficient:
equilibrium rare-bad-sector protection plus individually correctable stochastic
writer faults need not protect the noisy released state. In that construction
the input is exactly correct at release and is then transferred to an
inaccessible bath with probability tending to one. This second Hamiltonian has
a nonlocal control term and is explicitly **not** a counterexample to the 3D
local N1653 model.

A constructive repair is to replace domination by a single equilibrium
distribution with domination **inside normalized sectors**, retaining arbitrary
changed sector weights, and to prove conditional dynamical safety of every
sector reached with appreciable probability. An explicit theorem and a concrete
fault-cluster admission criterion are provided below. The missing N1653 step is
that sector/cluster dynamical certificate for the actual noncommuting joint bath
and physical noisy writer, not another norm-continuity estimate.

## Governing N1653 scope read in this round

I read the cached complete files
`../../sources/N1653-ROOT_ROBUST_NATIVE_MEMORY_JOIN.md` and
`../../sources/N1653-EXACT_PHYSICAL_TIME_JOIN_AUDIT.md`.

The accepted exact-time consumer assumes the separately checked actual-Gibbs
rare-bad-syndrome estimate, an exact full-space fixed decoder Pauli algebra,
and two-sided bad support of its commutators with the actual total Hamiltonian.
It uses the supplied actual joint equilibrium resource and ideal system/clock
access. The native model includes qubits and seven-level clock spins, a fixed
finite-temperature window, fixed local geometry/body/norm restrictions and a
bounded-spin bath. Its local admission enlargement handles every Pauli prefix
on each fixed-size perturbation footprint; it does not by itself handle a
positive-density collection of terminal writer faults.

The logical SWAP and same-H exact storage route was already present internally.
This note makes no novelty claim for that route and does not fill in N1645's
unreceived package. No theorem below invalidates N1653 at its stated scope.

## 1. The CP target necessarily demands exact logical neutrality

**Lemma 1.** If a CP map `F:L→L⊗G` obeys
`F≤CP κ E_γ`, then there exists a positive, possibly subnormalized gauge state
`σ≤κγ` such that

\[
 F(\rho)=\rho\otimes\sigma                       \tag{2}
\]

for every logical input, including inputs entangled with a reference.

**Proof.** The normalized Choi operator of `E_γ` is
`Φ_RL⊗γ`. Positive operator domination forces the support of `J_F` into
`span{|Φ⟩}⊗supp(γ)`, so `J_F=Φ⊗σ` with `0≤σ≤κγ`. Choi inversion gives (2).
QED.

Consequently, a theorem meeting (1) cannot “avoid assuming exact logical
neutrality” in the good component: (1) mathematically entails it. One may
**derive** neutrality from exact correction conditions, rather than assume it,
but one cannot permit residual good-component logical distortion while retaining
the same rank-one logical Choi reference.

The condition is also brittle against coherent logical errors. Let
`W_θ(ρ)=U_θρU_θ†⊗γ`, with a non-scalar logical unitary `U_θ` arbitrarily close
to identity. The supports of `J_Wθ=Φ_θ⊗γ` and `J_Eγ=Φ⊗γ` intersect trivially.
Any positive Choi operator dominated by both is zero. Therefore in (1)
`W_good=0` and `δ≥1`, even though the operational error can be arbitrarily
small. Applying a known exact inverse or a physical logical Pauli randomization
can repair special cases; neither is automatically a noisy physical primitive.

## 2. Geometrically local obstruction: independent harmless gauge faults

Fix `0<q<1/2` and `0<p<1/2`. Let the accessible memory consist of an exactly
noiseless logical qubit `L` and `m` gauge qubits `G_1,…,G_m`, arranged at bounded
density in 3D. Put

\[
 H=I_L\otimes\Delta\sum_{i=1}^m n_i,
 \qquad n_i=|1\rangle\langle1|_i,
 \quad q=(1+e^{\beta\Delta})^{-1}.                 \tag{3}
\]

All Hamiltonian terms are onsite with a fixed finite strength `Δ` independent
of `m`. A decoupled arbitrary finite bath may be included without changing the
argument. The joint Gibbs state is

\[
 \tau={I_L\over2}\otimes\gamma_q^{\otimes m},
 \qquad\gamma_q=\operatorname{diag}(1-q,q).
\]

Start with the exact thermal logical writer
`E_q(ρ)=ρ⊗γ_q^{⊗m}`. Apply independent terminal bit flips of probability `p`
on every gauge site. This is an exact local-stochastic Pauli fault model:
for every set of sites `R`, `Pr(R⊂F)=p^{|R|}`. The resulting actual writer is

\[
 W_p(\rho)=\rho\otimes\gamma_r^{\otimes m},
 \qquad r=q+p(1-2q)>q.                            \tag{4}
\]

The writer is exactly correct at release and the logical qubit is stored
perfectly for every physical time. There is no operational failure to repair.

Nevertheless (1) has an exponential `κ` cost. Choose any fixed `q<θ<r`, and
let `A_m` be the gauge event `|g|≥θm` (use a sequence with integer threshold,
or round it and adjust by `O(1/m)`). Write

\[
 d(x\|y)=x\log{x\over y}+(1-x)\log{1-x\over1-y}.
\]

The elementary exponential-Markov/binomial Chernoff estimate gives

\[
 a_m=\Pr_q(A_m)\le e^{-m d(\theta\|q)},\qquad
 b_m=\Pr_r(A_m)\ge1-e^{-m d(\theta\|r)}.            \tag{5}
\]

For completeness, apply `Pr(S≥θm)≤inf_{λ>0}e^{-λθm}(1-q+qe^λ)^m` and choose
`e^λ=θ(1-q)/(q(1-θ))`; the lower tail follows with `λ<0`.

For **any** decomposition (1), even without invoking Lemma 1, evaluate the
positive effect `I_L⊗1_A` on one normalized logical input. The bad part
contributes at most `δ`, and CP domination bounds the good part by `κa_m`.
Thus

\[
 \boxed{\quad
 \kappa\ge{b_m-\delta\over a_m}
 \ge\bigl(1-\delta-e^{-m d(\theta\|r)}\bigr)
             e^{m d(\theta\|q)}.\quad}             \tag{6}
\]

For every fixed `δ<1`, `κ` is exponential in `m`. This holds for **every fixed
nonzero physical fault probability** `p`, with the same Hamiltonian (3): choose
`θ` between the resulting `q` and `r`. It does not rely on a nonlocal fault,
an adversarial bath, a large local Hamiltonian norm or a poorly protected logical
input. Even exact logical neutrality is insufficient to rescue global thermal
domination.

The same argument applies to subnormalized gauge density operators and quantum
reference systems, because it uses a positive output effect on a CP order.

### Exact finite smooth-domination accounting

For this diagonal example the optimal `κ` with allowed bad mass `δ` is the
smallest value for which

\[
 \sum_{w=0}^m\min\{\Pr_r(|g|=w),\kappa\Pr_q(|g|=w)\}
       \ge1-\delta.                               \tag{7}
\]

The per-string likelihood ratio is constant within each weight sector, so the
cap in (7) is achievable by a CP gauge map. It follows simply by taking the
good gauge state to be the pointwise minimum and placing the remainder in the
bad part. This confirms that the obstruction concerns the chosen global
reference, not an inability to write or retain the logical qubit.

For `q=.02,p=.1,δ=.01`, a finite calculation gives `log κ_min≈18.62,51.28,
160.04,550.71` for `m=64,256,1024,4096`. These figures illustrate the exact
finite optimization only; inequality (6) is the proof of exponential necessity.

## 3. Rare equilibrium protection can still fail after noisy release

This second example prevents the opposite inference that a rare equilibrium
bad sector is automatically harmless under distributed faults.

Let `L` be the accessible logical qubit, `G_1,…,G_m` accessible classical gauge
qubits, and `B` an inaccessible bath qubit. Choose `0<q<θ<r=q+p(1-2q)` as
above, let `A=1_{|g|≥θm}`, and let `S_LB` be the two-qubit SWAP, a Hermitian
unitary. Define the actual total Hamiltonian

\[
 H_m=\Delta\sum_i n_i+g A\otimes S_{LB},
 \quad g>0,\quad q=(1+e^{\beta\Delta})^{-1}.         \tag{8}
\]

**Scope:** the `A⊗SWAP` term has growing support. Equation (8) is an explicit
finite-dimensional obstruction to a black-box transfer using only equilibrium
rarity and two-sided commutator support. It is not a bounded-body geometric
3D Hamiltonian and is not a no-go theorem for N1653.

For `A=0` the logical–bath Hamiltonian is zero; for `A=1` its Gibbs partition
factor is `z_h=3e^{-βg}+e^{βg}`. Consequently the actual Gibbs gauge law is

\[
 \mu(g)={\pi_q(g)\alpha^{A(g)}\over
                  1+(\alpha-1)\pi_q(A)},
 \qquad \alpha={3e^{-\beta g}+e^{\beta g}\over4}.    \tag{9}
\]

The bath marginal conditioned on every gauge string is exactly `I_B/2`, since
`Tr_L(e^{-βgSWAP})` is scalar. The exact logical SWAP overwrite of the actual
interacting Gibbs state therefore prepares
`ρ_L⊗μ_G⊗I_B/2`, with any reference entanglement retained.

There are constants depending only on `βg` such that

\[
 \mu(A)\le C\,e^{-m d(\theta\|q)}.                \tag{10}
\]

Moreover, every logical Pauli `Q` satisfies

\[
 [H_m,Q]=g A[S_{LB},Q],\qquad
 [H_m,Q]=A[H_m,Q]A,
 \quad\|[H_m,Q]\|\le2g.                           \tag{11}
\]

Thus the actual Gibbs bad-sector probability is exponentially small and the
logical commutators have the exact two-sided support required by the abstract
storage consumer. In fact the ideal thermal-reset memory has logical error at
most `3μ(A)/4` for **all times**, because it is identity on the cold sector and
a partial-SWAP depolarizing channel on the hot sector.

Now apply the same independent single-site gauge bit flips of rate `p` after
writing. They leave `ρ_L` exactly unchanged at release and are individually
logically harmless. Let the resulting gauge law be `μ'`. The total variation
distance between `μ` and `π_q` is at most `C'π_q(A)`; a stochastic channel
contracts that distance and sends `π_q` to `π_r`. Therefore

\[
 a'_m=\mu'(A)\ge1-e^{-m d(\theta\|r)}
                         -C'e^{-m d(\theta\|q)}\longrightarrow1. \tag{12}
\]

At the fixed time `t*=π/(2g)`, the hot-sector unitary is `−iSWAP_LB`.
It transfers the entire input to the inaccessible bath and leaves the
accessible logical qubit in `I/2`. The accessible gauge string contains no
information about the input. Thus **every** CPTP reader acting on all accessible
memory spins has

\[
 F_e\le(1-a'_m)+\tfrac14a'_m,
 \qquad {1\over2}\|N_{t_*}-id\|_\diamond
                  \ge\tfrac34a'_m\longrightarrow\tfrac34. \tag{13}
\]

The hot branch is a replacer channel, so its entanglement fidelity against a
maximally entangled reference is `1/4` for every reader; the cold branch has
fidelity at most one. This proves (13) without assuming a particular decoder.
It also rules out repairing this example merely by reading the gauge flag and
inverting a known logical rotation: the input has left the accessible system.

The example does not preclude a different writer/encoding or an environment
accessible reader. It proves failure of noisy admission for the specified
otherwise ideal thermal-reset protocol, under local stochastic terminal faults,
when no additional dynamical/geometry condition is imposed.

## 4. Positive repair: normalized sector references

The harmless example identifies a natural replacement for (1). Product Gibbs
and independently heated product Gibbs have **identical normalized conditional
states within each Hamming-weight sector**. Their sector weights differ
exponentially, but no physical failure occurs. Charging that weight change as a
single global `κ` is unnecessary.

Let `{Π_s}` be mutually orthogonal gauge-sector projectors and let `γ_s` be
normalized gauge–bath states supported in `Π_s`. Define
`E_s(ρ)=ρ⊗γ_s`. The sector label may be a syndrome, defect-cluster geometry,
weight, or another physically verified decomposition. Its existence alone does
not guarantee efficient measurement or preparation.

**Theorem 2 (sector-conditioned admission).** Suppose after the specified
physical recovery the writer has a CP decomposition

\[
 W=W_{\rm bad}+\sum_s W_s,\quad
 W_s(\rho)=\rho\otimes\sigma_s,\quad
 \sigma_s\le\kappa_s w_s\gamma_s,
 \quad\operatorname{Tr}\sigma_s=w_s,
 \quad\|W_{\rm bad}^*(I)\|_\infty\le\delta.         \tag{14}
\]

Let `Λ_t` be the actual common joint HOLD and `D` the common physical reader.
Suppose the complete-channel Weyl randomization of `DΛ_tE_s` has entanglement
failure at most `ε_s(t)`. Then the randomized actual memory satisfies

\[
 {1\over2}\|\widetilde N_t-id\|_\diamond
       \le\min\{1,\delta+\sum_s w_s\kappa_s\epsilon_s(t)\}. \tag{15}
\]

**Proof.** Entanglement failure is a positive linear functional of the written
Choi state. CP order and the common CPTP HOLD/reader preserve (14), so the
`s` term contributes at most `w_s κ_s ε_s(t)`. The bad Choi trace is at most
`δ`. Sum, and use the exact Weyl-channel equality between half diamond error
and entanglement failure. QED.

There is no penalty for changes in sector weights `w_s` relative to their
equilibrium probabilities. One must instead prove that the sectors carrying
those weights remain dynamically safe. For (3), every sector has `ε_s=0` and
`κ_s=1`, so (15) proves perfect operation despite the obstruction (6). For (8),
the hot sectors have order-one `ε_s(t*)`, and (15) correctly gives no useful
protection after their weight approaches one.

### Deriving, rather than assuming, good-sector logical neutrality

Equation (14) is not automatic. With stochastic Pauli fault instruments,
exactly correctable sets give a constructive route: verify that the fixed
decoder/recovery has trivial logical cofactor for every admitted combination
of the preexisting syndrome and the terminal fault pattern. In a decoder frame,
each admitted Kraus operator must then intertwine as
`I_L⊗K`, so summing its CP branch gives (14). This is an algebraic correction
check on the full admitted ensemble; individual fault correctability alone does
not imply simultaneous correction against unknown preexisting excitations.

For a pure subspace code this reduces to the familiar Knill–Laflamme check on
the admitted error set; an interacting thermal background requires the
corresponding joint syndrome/gauge condition. Coherent sums of good and bad
Pauli amplitudes do not automatically split into CP branches. One must justify
the stochastic instrument, implement a compatible randomization, or use a
coherent fault-amplitude argument instead. An ideal syndrome measurement in a
noncommuting Gibbs state changes that state and must be charged in the actual
release-state certificate.

### A concrete sufficient geometry condition for stochastic faults

Here is an elementary useful special case, not an import into N1653. Let a
bounded-degree graph of maximum degree `D≥2` describe syndrome/error geometry.
Suppose the actual background defect set `T` obeys
`Pr(R⊂T)≤q^{|R|}`, and the terminal fault set obeys the stronger conditional
bound `Pr(R⊂F | T)≤p^{|R|}`. Then for every finite `R`,

\[
 \Pr(R\subset T\cup F)\le(p+q)^{|R|}.             \tag{16}
\]

Proof: sum over the subset of `R` assigned to `F`, apply its conditional bound,
then the background bound, and use the binomial theorem.

Suppose additionally a verified fixed-decoder geometric lemma says that if
every connected component of `T∪F` has fewer than `ℓ` vertices, then its logical
cofactor is trivial and its resulting sector belongs to a declared dynamically
safe family. A depth-first walk through a rooted connected `ℓ`-vertex set has
length at most `2(ℓ−1)`; fixing deterministic spanning trees gives at most
`D^{2(ℓ−1)}` candidate rooted sets. Union bounding with (16) therefore gives

\[
 \delta\le nD^{2(\ell-1)}(p+q)^\ell.              \tag{17}
\]

For fixed `D²(p+q)<1` and growing `ℓ`, (17) earns a small bad probability from
many extensive faults without globally small writer distance. Together with
normalized sector domination and conditional storage bounds, it closes (15).

The actual N1653 static estimate is a witness/contour estimate, not the
sitewise local-stochastic assumption on `T` used here. Its noncommuting Gibbs
state may also contain syndrome coherences. Those two interfaces must be
proved for the real state or replaced by an appropriate quantum cluster
certificate. They cannot be inferred from the scalar rare-boundary probability.

## 5. Minimal dynamical certificate beyond equilibrium rarity

For the source's fixed decoder algebra, let `P_bad` support the logical
commutators. A concrete sufficient all-state condition is a positive operator
`F≥P_bad` and a controlled Heisenberg inequality

\[
 i[H,F]\le\varepsilon I,\qquad
 \sup_{\rho_L}\operatorname{Tr}[F W(\rho_L)]\le\eta. \tag{18}
\]

Then actual noisy release and exact HOLD satisfy
`Pr_bad(t)≤η+εt`, independently of whether the released state is Gibbs or close
to it. If the sum of logical commutator norms is `A`, the same two-sided support
argument gives deterministic half diamond error at most

\[
 \tfrac A2(\eta t+\varepsilon t^2/2),              \tag{19}
\]

provided the logical input at release is correct; an explicitly proved
release error must be included separately. A reference-safe joint initial
bound is required if release correctness itself is approximate.

Equation (18) is a **new certificate to construct**, not supplied by N1653's
equilibrium estimate. An equally sufficient sector version controls
`Tr(P_bad U_t E_s(ρ)U_t†)` uniformly over the admitted conditional ensembles.
The hot-SWAP example violates such a condition on the sectors reached after
writing; the decoupled gauge example satisfies it with `F=0`.

For a useful long-memory theorem, `η` and `ε` must have the required suppressed
size dependence under realistic fixed-rate writer faults, uniformly in bath
volume and all reference states. Locality can help establish such a certificate
through cluster geometry, but locality and equilibrium rarity are not by
themselves the certificate. Preparation, recovery controls, syndrome acquisition,
readout and reset must remain in the same-resource active-QEC comparison.

## Verification and conclusion at exact scope

`noisy_admission_check.py` and `noisy_admission_check.json` verify finite
binomial tails, the exact diagonal optimization (7), independent fault updates
in a finite hot-sector model, and its SWAP/replacer Choi normalization. These
are finite algebra/numerical checks only; proofs are above.

The strong negative result (6) is compatible with geometrically local bounded
Hamiltonians and independent local stochastic faults, and shows that global CP
thermal domination is not the right universal access criterion. The operational
failure example (8)–(13) requires a nonlocal control term and exposes exactly
what a geometry/dynamics theorem must exclude. The positive repair (15)–(17)
identifies a path, but its actual interacting-N1653 release/basin hypotheses
remain **OPEN**. No N1645 model or original proof has been reconstructed.
