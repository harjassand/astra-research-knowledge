# Post-exchange constructive audit: a stronger Bell–Weyl theorem

2026-11-06. This followup combines the principal's independently saved Bell
compression with the constructor's channel randomization. It was written after
the initial reports were exchanged. The initial constructor report is preserved
unchanged. This is the strongest mathematical version reached by this researcher.

## 1. Stronger theorem: neither Gibbs nor stationarity is needed

Let `S≅C^d_L⊗A` be an exact, physically accessible system-only subsystem
identification, and put `G=A⊗B`, including the entire initially correlated bath.
Let `ω` be **any** density matrix on `L⊗G`, of any rank, and let `Λ` be any CPTP
map on `L⊗G`. For exact HOLD dynamics, `Λ=Ad(U_t)` with the actual total unitary.
Let `{W_a}` be the standard `d²` discrete Weyl operators on `L`, tensor identity
on `G`. Define the memory channel after an exact logical SWAP write by

\[
 N(\rho)=\operatorname{Tr}_G\Lambda(\rho\otimes\omega_G),
 \qquad\omega_G=\operatorname{Tr}_L\omega.
\]

Let `\widetilde N=d^{-2}Σ_a Ad(W_a†)∘N∘Ad(W_a)` be the complete-channel Weyl
twirl. With `Λ*` denoting the Heisenberg adjoint, define

\[
 e_a=2-2\operatorname{Re}\operatorname{Tr}
                  [\omega W_a^\dagger\Lambda^*(W_a)],
 \qquad \bar e=d^{-2}\sum_a e_a.                  \tag{B1}
\]

**Theorem B.**

\[
 {1\over2}\|\widetilde N-id_d\|_\diamond
       =1-F_e(N)\le\min(1,\bar e).                \tag{B2}
\]

For unitary dynamics,

\[
 e_a=\operatorname{Tr}\omega
       [W_a(t)-W_a]^\dagger[W_a(t)-W_a],
 \quad W_a(t)=U_t^\dagger W_aU_t.                 \tag{B3}
\]

This is uniform over reference-entangled inputs and independent of `d`, bath
size and the spectrum of `ω`. No stationarity, thermal state, local interaction,
weak coupling, detailed balance or fresh bath is required for this channel
theorem. The hard physical work is proving the small errors (B1)/(B3), preparing
the required gauge–bath marginal, and implementing the exposed subsystem at
acceptable noise and resource cost.

### Complete proof

Use a reference `R≅C^d`, normalized maximally entangled `Φ_RL`, and

\[
 P=\Phi_{RL}\otimes I_G,\quad
 \Xi={I_R\over d}\otimes\omega,
 \qquad d^2P\Xi P=\Phi_{RL}\otimes\omega_G.         \tag{B4}
\]

The last identity follows by expanding `Φ=d^{-1}Σ_{ij}|ii⟩⟨jj|`; it is the
principal's exact Bell compression. Let `{A_α}` be Kraus operators for `Λ` and
extend them trivially to `R`. Then

\[
 \begin{split}
 1-F_e(N)
 &=d^2\sum_\alpha
       \|(I-P)A_\alpha P\Xi^{1/2}\|_2^2\\
 &=d^2\sum_\alpha
       \|(I-P)[A_\alpha,P]\Xi^{1/2}\|_2^2\\
 &\le d^2\sum_\alpha
       \|[A_\alpha,P]\Xi^{1/2}\|_2^2.             \tag{B5}
 \end{split}
\]

The Weyl expansion and orthogonality are

\[
 P=d^{-2}\sum_a\overline{W_a}_R\otimes W_a,
 \qquad d^{-1}\operatorname{Tr}(W_a^\dagger W_b)=\delta_{ab}.
\]

Consequently the last line of (B5) equals

\[
 d^{-2}\sum_{a,\alpha}\operatorname{Tr}
         [\omega[A_\alpha,W_a]^\dagger[A_\alpha,W_a]]. \tag{B6}
\]

Expand the commutators and use `Σ_α A_α†A_α=I` and `W_a†W_a=I`. Their sum is

\[
 \sum_\alpha[A_\alpha,W_a]^\dagger[A_\alpha,W_a]
 =2I-W_a^\dagger\Lambda^*(W_a)-\Lambda^*(W_a^\dagger)W_a.
\]

Thus (B6) is exactly `\bar e`. This proves the inequality in (B2) and the
nonnegativity of each (B1). For a unitary single Kraus operator it gives (B3).

Discrete Weyl conjugation diagonalizes the normalized Choi matrix of a channel
in the maximally entangled Weyl basis; its diagonal entries are nonnegative
probabilities. The identity-Weyl probability is `F_e(N)` and is unchanged by
twirling. The resulting channel is a random Weyl channel. Its half diamond
distance from identity is its total nonidentity probability: the mixture gives
an upper bound, and the normalized maximally entangled input gives an equal
trace-distance lower bound through orthogonal Weyl–Bell states. This proves the
equality in (B2). QED.

### Why the original constructor's thermal filter is unnecessary here

In the initial report I compared `ω` to its logical twirl by moving operators
through `√ω`. Bell compression instead projects the correlated resource directly
into the Choi input and sums a complete operator basis. Dropping the output
projection in (B5) yields the stronger answer immediately. The thermal-filter
theorem remains true, but is not the strongest full-basis bridge.

The exact identity behind (B5) also shows what is discarded: the squared norm
`d²Σ_α||[A_α,P]Xi^{1/2}||²` is the desired leakage plus a second nonnegative
term with output projection `P`. There is no hidden sign or independence
assumption in the bound.

The dimension-independent diamond conclusion refers to the actually randomized
protocol, averaged over its charged classical randomness. It is not asserted
for each fixed random seed. The seed has `d²` possible values, requiring
`ceil(log₂(d²))` classical storage bits in a direct encoding. The theorem also
works with the tensor-Pauli group for `d=2^k`, using exactly `2k` frame bits and
ordinary single-qubit external Pauli gates. Reliable retention and use of these
bits is included in the access/controller contract.

Randomization matters at growing dimension. With no gauge, `ω=I/d`, and
`U=I−2|0⟩⟨0|`, the untwirled channel has half diamond distance one from identity,
but `1−F_e=4/d−4/d²` and `\bar e=8/d−8/d²`. The Weyl-randomized channel has
the smaller half diamond error `1−F_e`; the fixed deterministic channel does not.
Thus a dimension-free untwirled interpretation would be false.

## 2. Audit of principal's independent P1/P2

I checked `../../initial/principal.md`, P1 line by line. The compression (B4),
entanglement-failure expression, Bell expansion and weighted Hilbert–Schmidt
Duhamel estimate are correct in finite dimension at their stated scope.

If `ω` is stationary for a self-adjoint `H`, define

\[
 q=d^{-2}\sum_a\operatorname{Tr}
              \omega[H,W_a]^\dagger[H,W_a].
\]

Stationarity makes the weighted 2-norm of the integrated Heisenberg derivative
constant, giving `e_a(t)≤t²ω([H,W_a]†[H,W_a])`. Hence Theorem B strengthens the
operational conclusion of P1 to

\[
 {1\over2}\|\widetilde N_t-id_d\|_\diamond
        \le\min(1,t^2q),                           \tag{B7}
\]

with no dimension factor or square-root loss. The principal's untwirled
`2d|t|√q` diamond bound remains valid; (B7) is a different protocol with charged
classical randomization. If the actual stationary-state commutator certificate
has `q≤poly(L)e^{-aL^ν}`, this gives lifetime proportional to `q^{-1/2}` at
fixed diamond error, not `q^{-1}`. No thermal filter changes that exponent unless
a stronger real-time autocorrelation theorem is available.

P2's CP domination statement is also correct as a sufficient interface. Because
the encoded logical channel is exactly reversible, CP domination of the good
writer by `ρ↦ρ⊗ω_G` forces its good component to preserve the logical factor
exactly; it is not automatic from a generic noisy circuit. Its bad component
trace bound holds uniformly on entangled inputs by positivity and the effect
operator norm. For the twirled protocol, a CP-dominated good part with factor
`c` and a bad part of probability at most `δ` gives half diamond error at most
`c \bar e(t)+δ`, capped at one. This avoids the dimension/square-root conversion
while retaining the same strong admission assumption.

## 3. Requested non-Hermitian KMS check

For a Gibbs state `ω=e^{-βH}/Z`, define
`b_a=||[W_a,√ω]||₂²`. For a **single non-Hermitian Weyl** one must not assert

`b_a=∫k_β(s)e_a(s)ds`.

That equality uses symmetric matrix-element weights and can fail. The averaged
identity is valid:

\[
 \bar b=d^{-2}\sum_a b_a
       =\int_{\mathbb R}k_\beta(s)\bar e(s)ds,\qquad
 k_\beta(s)=\beta^{-1}\operatorname{sech}(\pi s/\beta). \tag{B8}
\]

Indeed the Weyl set is closed under adjoints up to a scalar phase. Pair each
`W` with `W†`; matrix-element weights become
`(|W_mn|²+|W_nm|²)/2`, so the spectral Gibbs pairing from the initial report
applies. Equivalently, `∫k e_W` and `∫k e_W†` average to `b_W=b_W†`. Summing the
adjoint-closed basis proves (B8).

The proposed general estimate

\[
 {1\over2}\|\widetilde N_t-id\|_\diamond
 \le\tfrac12(\sqrt{\bar e(t)}+2\sqrt{\bar b})^2
 \le\tfrac32\bar e(t)+3\bar b
\]

is valid for Gibbs states by the constructor's initial argument with two basis
averages and Cauchy–Schwarz. It is superseded by (B2), which needs no `\bar b`.

The finite check script below found a single non-Hermitian filter discrepancy
about `0.098`, while the averaged identity held to `1.9e−15`. This is a useful
scope correction, not a numerical theorem proof.

## 4. A real use for the filter: two generators instead of the full basis

The separate file `two_generator_addendum.md` proves that for one exact
accessible Pauli pair `X,Z`, if only `e_X,e_Z≤ε(t)` and their thermal-filter
values are at most `b`, then the protocol has half diamond error at most

\[
 {3\over4}\epsilon(t)+3\sqrt{\epsilon(t)b}+{15\over4}b
 \le{9\over4}\epsilon(t)+{21\over4}b.              \tag{B9}
\]

The proof uses `[XZ,√ω]=X[Z,√ω]+[X,√ω]Z` to control `b_Y`, and a corresponding
product identity to bound `e_Y`. This reduces the needed thermal memory
certificate to two anticommuting generators. Priority is unassessed.

The Gibbs qualification has content. Take `L,G` two qubits,
`ω=|Φ+⟩⟨Φ+|` and HOLD unitary `U=SWAP_LG`. This is even a stationary resource
for that unitary. Both `e_X=e_Z=0`: acting with either generator on `Φ+` gives
a symmetric Bell state, as is `Φ+` itself. But `YΦ+` is antisymmetric, so
`e_Y=4`. The logical-reset memory channel is the completely depolarizing
channel because SWAP replaces the input by `ω_G=I/2`; its entanglement fidelity
is `1/4`. Thus two-generator autocorrelations in an arbitrary stationary
correlated state do not certify an operational quantum memory. The full-basis
Theorem B detects the failure, with `\bar e=1`.

## 5. Literature and exact predecessor check

I re-read the **complete** Alicki–Fannes arXiv:0809.4180v1 source after the
exchange. Section 3 equations (11)–(14), and its final assignment-map remark,
already contain the CPTP logical-replacement preparation leaving the syndrome
marginal fixed. Sections 2–4 include an abstract full matrix algebra,
faithful correlated stationary state, exact or unital-CP dynamics and
correlation/fidelity estimates. Their main bound (23) is an upper bound on
surviving pure-state fidelity using a modular-analytic preparation-dependent
norm. Their simple example after (23) assumes the logical algebra commutes with
the modular dynamics.

I did **not** locate the particular Bell-compression inequality (B2), averaged
weighted Kraus commutators, or its dimension-free Weyl-randomized diamond
conclusion verbatim in that nine-page source. This is a bounded negative finding
about the inspected source, not a claim of novelty. The lemma is elementary
channel/noiseless-subsystem machinery and should not be framed as a new passive
memory mechanism. Exact reset, Weyl randomization, Bell basis diagonalization,
and “conserved logical algebra protects information” are established ingredients.

Primary source:
[Alicki–Fannes full text](https://arxiv.org/html/0809.4180),
[PRA DOI](https://doi.org/10.1103/PhysRevA.79.012316).
Further searches in approximate noiseless subsystems and quantum-memory
correlation literature did not verify a verbatim quantitative source. The
existing-machinery researcher should continue the broad priority check and the
specific recent-2026 Zenodo search before any novelty claim.

## 6. The decisive physical application is still open

The source-independent generality of (B2) sharpens the missing operation:

1. exhibit an exact accessible logical algebra and its implementable subsystem
   identification;
2. prove `\bar e(t)` stays small for the **actual joint state after physically
   noisy writing**, over a long HOLD window, or prove a compatible CP admission
   condition with controlled constants;
3. construct its resource gauge–bath marginal or a validated replacement, with
   preparation and reset costs;
4. produce a feasible reader and a matched active-QEC operating point.

A Gibbs-state thermal autocorrelation theorem alone plus an abstract finite
encoder does not supply any of these costs. N1645's visible-only source supplies
neither (1) nor a quantitative version of (2). This followup cannot verify its
unreceived proof or turn its ideal-access claim into a device.

## 7. Verification artifacts

`check_general_swap_bridge.py` checks (B4), Bell/Weyl expansion, the exact
commutator average behind (B5), inequality (B2), stationary `t²q`, and averaged
KMS identity (B8) for logical dimensions 2, 3, 4, 5, gauge dimensions 2, 3,
thermal and arbitrary nonstationary resources, and three times (144 cases).
It also checks the explicit non-Gibbs two-generator counterexample. All pass;
largest equality discrepancy `3.6e−15`. Report:
`general_swap_bridge_check.json`.

The CPTP version (B1) is proved algebraically above; that script tests unitary
instances. These checks establish finite normalization/algebra consistency only.
