# Hostile check of the principal's entropy rare-event improvement

2026-11-06. Written after the principal supplied the proposed proof. The
constructor's original independent notes remain unchanged.

**Conclusion:** the deterministic reference-safe `p^{-1}`-scale consumer is
correct in finite volume under the stated exact Gibbs, two-sided bad-support
and accessible logical-algebra hypotheses. It strengthens the earlier N1653
consumer's use of Pinsker. It does not supply noisy admission or improve the
source's unverified engineering constants. Historical priority is not assessed
by this algebraic audit.

## Precise hypotheses

Let `H` be the actual finite memory–bath Hamiltonian and
`ω=e^{-βH}/Tr(e^{-βH})`. Let `X,Y,Z` be an exact system-accessible full-space
logical Pauli algebra. Let `P` be a projector commuting with all three logical
Paulis such that

\[
 C_Q=i[H,Q]=PC_QP,\quad a_Q=\|C_Q\|,
 \quad p=\operatorname{Tr}(P\omega),
 \quad A=\sum_{Q=X,Y,Z}a_Q,\quad a=\max_Q a_Q.
\]

The logical overwrite and reader are the ideal SWAP/partial-trace operations of
the N1653 exact-time join, retaining the actual gauge–bath marginal `ω_G`.
Input/reference is initially independent of the resource. No bath factorization
or physical bath reset is assumed. Define

\[
 \Omega={1\over4}\sum_{Q=I,X,Y,Z}Q\omega Q
        ={I_L\over2}\otimes\omega_G.
\]

## 1. Initial relative entropy is proportional to the rare probability

For `Q≠I`, use `log(QωQ)=Q(logω)Q` to obtain

\[
 D(Q\omega Q\|\omega)
       =\beta\operatorname{Tr}\omega(QHQ-H).
\]

The perturbation `Δ_Q=QHQ−H=Q[H,Q]` is Hermitian, has norm `a_Q`, and is
supported on `P` on both sides. The support uses both `[Q,P]=0` and the stated
support of `C_Q`; it would not follow from one-sided mean-square smallness
alone. Therefore

\[
 0\le D(Q\omega Q\|\omega)\le\beta a_Qp.
\]

Convexity in the first argument gives the slightly sharper version of the
principal's proposed estimate:

\[
 D_0:=D(\Omega\|\omega)
       \le{\beta Ap\over4}\le\beta ap.              \tag{E1}
\]

The second inequality is deliberately loose (`A≤3a`). Both are valid. No
commuting reference Gibbs factor or exponential operator-monotonicity claim is
used.

## 2. Binary rare-event entropy avoids Pinsker's square root

Let `Ω_t=U_tΩU_t†`. Gibbs stationarity gives
`D(Ω_t||ω)=D_0`. Set `q_t=Tr(PΩ_t)`. Measuring `{P,I−P}` and using relative
entropy data processing gives

\[
 d(q_t\|p)\le D_0.
\]

For every `λ>0`, the binary variational formula, or directly binary Jensen,
gives

\[
 \lambda q_t\le D_0+\log(1+p(e^\lambda-1))
       \le D_0+p(e^\lambda-1).                    \tag{E2}
\]

At `λ=1`, equations (E1)–(E2) yield uniformly for all real physical times

\[
 q_t\le p(\beta A/4+e-1)
       \le p(\beta a+e-1).                        \tag{E3}
\]

All probabilities may be capped at one. If desired, optimize the right-hand
side of (E2) over `λ`; the fixed choice suffices for the claimed scale. Finite
Gibbs faithfulness means `p=0` only for the zero projector, so the binary
endpoint poses no hidden finite-volume exception.

## 3. Arbitrary reference inputs and deterministic diamond error

For any normalized logical input marginal `ρ_L`,

\[
 E(\rho_L)=\rho_L\otimes\omega_G\le2\Omega.
\]

Under the same unitary `U_t`, positivity implies that the actual physical
system/bath marginal `σ_t` has `Tr(Pσ_t)≤2q_t`, regardless of its reference
dimension or entanglement.

Let `σ_LR(t)` be the decoded reference/logical output. Its Pauli expansion has
coefficients `Tr_{LG}[(Q⊗I_R)σ_LGR(t)]`. Differentiating gives coefficients
`Tr_{LG}[(C_Q⊗I_R)σ_LGR(t)]`. For arbitrary joint reference states,

\[
 \left\|\operatorname{Tr}_{LG}
              [(C_Q\otimes I_R)\sigma_{LGR}(t)]\right\|_1
       \le a_Q\operatorname{Tr}(P\sigma_t).         \tag{E4}
\]

To check (E4), pair the partial trace with an arbitrary unitary on `R`, insert
`P` on both sides of the positive joint state using `C_Q=PC_QP`, and bound the
result by `a_Q Tr(Pσ_t)`. This is exactly where two-sided support avoids a
`sqrt(Pr_bad)` estimate.

Since each Pauli has trace norm two, the expansion factor `1/2` cancels and

\[
 {1\over2}\|\dot\sigma_{LR}(t)\|_1
       \le{A\over2}\operatorname{Tr}(P\sigma_t)
       \le A q_t.
\]

The output at zero time is exactly the input/reference. Integrating and
supremizing over reference-entangled inputs proves the deterministic bound

\[
 \boxed{\quad
 {1\over2}\|N_t-id_2\|_\diamond
       \le\min\{1,A p(\beta A/4+e-1)|t|\}
       \le\min\{1,A p(\beta a+e-1)|t|\}.
 \quad}                                          \tag{E5}
\]

No channel randomization or classical Pauli frame is required for (E5).
Negative times follow by reversing the integration; the stationary entropy
bound remains valid. The displayed error is a half diamond norm, consistently
with the derivative convention.

## 4. What this earns, and what it does not

If `p_n≤poly(n)e^{-cn^η}` and `A_n,β_n` grow only polynomially, equation (E5)
permits storage time `e^{c'n^η}` for any `c'<c`, with vanishing error after
accounting for the polynomial factors. This recovers the full rarity exponent,
unlike the older Pinsker consumer's `c/2` restriction. If `β` or the commutator
norm grows exponentially, its cost must instead be retained explicitly.

The proof applies to N1653 only conditional on its separately audited actual
joint-Gibbs probability and local-protection premises. It neither re-proves the
mixed-source/rod static theorem nor widens the bath/geometry/temperature class.
It does not apply to a merely approximately stationary state without an
additional long-time relative-entropy guarantee.

For a noisy writer, a globally extensive entropy cost can again destroy the
useful bound; the separate product-gauge obstruction demonstrates why requiring
global thermal closeness or global thermal CP domination is too strong.
Sector-conditioned or dynamical basin certificates are still needed. The
improved ideal-endpoint consumer is substantive mathematical progress at its
actual scope, and the noisy-access gate remains open.

At the initial save I had not yet received the auditor's complete sharper KMS
proof. The auditor subsequently sent it; the following independent check closes
that earlier qualification. The original independent initial reports remain
unchanged.

## 5. Subsequent check: the sharper KMS randomized bound is also correct

Fix one logical Hermitian involution `Q`, and keep all hypotheses above. Define

\[
 S_Q(t)=\operatorname{Tr}(\sqrt\omega Q\sqrt\omega Q(t)),
 \quad C_Q^{\rm corr}(t)=\operatorname{Tr}(\omega Q Q(t)),
 \quad b_Q=\|[Q,\sqrt\omega]\|_2^2=2-2S_Q(0).
\]

`S_Q(t)` is real; its spectral expansion has symmetric square-root Gibbs
weights. Write the Hermitian commutator as `B_Q=i[H,Q]=PB_QP`. Exact
stationarity permits the derivative to be written

\[
 S'_Q(t)=\operatorname{Tr}
                  (\sqrt\omega Q(-t)\sqrt\omega B_Q).
\]

Using both-sided support and Schatten Hölder,

\[
 \begin{split}
 |S'_Q(t)|
 &\le a_Q\|P\sqrt\omega Q(-t)\sqrt\omega P\|_1\\
 &\le a_Q\|P\sqrt\omega\|_2
                 \|Q(-t)\sqrt\omega P\|_2
 =a_Qp.                                          \tag{K1}
 \end{split}
\]

This is a genuine `p`, rather than `sqrt(p)`, because the commutator is supported
on the bad sector on both sides. No assumption that `P` commutes with `ω` is
made or needed.

The relative-entropy calculation of Section 1 gives
`D_Q=D(QωQ||ω)≤βa_Qp`. In an eigenbasis of `ω`, pair indices `i<j`; Hermiticity
of `Q` makes the matrix-element weights symmetric. The ratio of the paired
contribution to `b_Q` to that of `D_Q` is

\[
 {2(\sqrt{p_i}-\sqrt{p_j})^2\over
       (p_i-p_j)(\log p_i-\log p_j)}
 ={2\tanh(x/4)\over x}\le{1\over2},
 \qquad x=\log(p_i/p_j),                          \tag{K2}
\]

with the continuous zero-energy limit. Therefore `2b_Q≤D_Q≤βa_Qp`.

The real parts of the ordinary and square-root correlations differ by the
arithmetic-minus-geometric spectral weights. Their total mass is `b_Q/2`, so

\[
 |\operatorname{Re}C_Q^{\rm corr}(t)-S_Q(t)|\le b_Q/2.
                                                               \tag{K3}
\]

Since `e_Q(t)=2−2Re C_Q^{corr}(t)`, equations (K1)–(K3) give

\[
 \begin{split}
 e_Q(t)
 &\le2(S_Q(0)-S_Q(t))+2b_Q\\
 &\le a_Qp(2|t|+\beta).                          \tag{K4}
 \end{split}
\]

Applying the independently checked Bell/Weyl channel theorem to the complete
qubit Pauli basis yields

\[
 \boxed{\quad
 {1\over2}\|\widetilde N_t-id_2\|_\diamond
       \le\min\{1,{pA\over4}(2|t|+\beta)\}.
 \quad}                                          \tag{K5}
\]

Equation (K5) refers to the **actually Pauli-randomized complete protocol** and
its average over the two charged classical frame bits. Equation (E5) is a
deterministic protocol. Their parameter factors differ, so neither should be
silently substituted for the other. The nonzero upper bound at `t=0` in (K5)
is harmless; the exact zero-time channel is identity.

This validates the auditor's sharper coefficient at its exact finite-volume
hypotheses. The argument uses standard relative-entropy/spectral and
Schatten-norm machinery; this algebraic check makes no claim of historical
priority. The actual-Gibbs static/protection theorem, ideal preparation/access,
clock dimensions and bath restrictions remain separate dependencies.
