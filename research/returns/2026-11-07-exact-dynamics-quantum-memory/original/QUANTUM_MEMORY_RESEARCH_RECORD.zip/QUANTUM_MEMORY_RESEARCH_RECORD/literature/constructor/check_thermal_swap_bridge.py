"""Finite algebra/factor checks for the thermal SWAP bridge, not a memory theorem test."""
import json
from pathlib import Path

import numpy as np


def dagger(a):
    return a.conj().T


def ptrace_logical(a, g):
    return np.trace(a.reshape(2, g, 2, g), axis1=0, axis2=2)


def ptrace_gauge(a, g):
    return np.trace(a.reshape(2, g, 2, g), axis1=1, axis2=3)


def run():
    rng = np.random.default_rng(4616445)
    paulis = [np.eye(2), np.array([[0, 1], [1, 0]]),
              np.array([[0, -1j], [1j, 0]]), np.diag([1, -1])]
    phi = np.array([1, 0, 0, 1]) / np.sqrt(2)
    worst = dict(kernel_identity=0., choi_identity=0., bridge_violation=0.,
                 pauli_eigenvalue_identity=0., physical_probability_violation=0.)
    n = 0
    for g in [2, 3, 5]:
        dim = 2 * g
        for trial in range(8):
            raw = rng.normal(size=(dim, dim)) + 1j * rng.normal(size=(dim, dim))
            h = (raw + dagger(raw)) / (2 * np.sqrt(dim))
            energies, basis = np.linalg.eigh(h)
            for beta in [.1, 1., 5.]:
                weights = np.exp(-beta * (energies - energies.min()))
                weights /= weights.sum()
                tau = (basis * weights) @ dagger(basis)
                sqrt_tau = (basis * np.sqrt(weights)) @ dagger(basis)
                gauge = ptrace_logical(tau, g)
                omega = np.kron(np.eye(2) / 2, gauge)
                fullp = [np.kron(p, np.eye(g)) for p in paulis]
                b = [np.linalg.norm(p @ sqrt_tau - sqrt_tau @ p, 'fro') ** 2
                     for p in fullp]
                for j in range(1, 4):
                    p_eigen = dagger(basis) @ fullp[j] @ basis
                    delta = energies[:, None] - energies[None, :]
                    # Integral against sech(pi t / beta) / beta has this transform.
                    kernel_value = 2 * np.sum(weights[None, :] * abs(p_eigen) ** 2
                                              * (1 - 1 / np.cosh(beta * delta / 2)))
                    worst['kernel_identity'] = max(worst['kernel_identity'],
                                                   abs(kernel_value - b[j]))
                for t in [0., .1, 1., 5., 20.]:
                    u = (basis * np.exp(-1j * t * energies)) @ dagger(basis)

                    def channel(a):
                        return ptrace_gauge(u @ np.kron(a, gauge) @ dagger(u), g)

                    choi = np.zeros((4, 4), dtype=complex)
                    for i in range(2):
                        for j in range(2):
                            eij = np.zeros((2, 2)); eij[i, j] = 1
                            choi += np.kron(eij, channel(eij)) / 2
                    ent_fid = np.real(dagger(phi) @ choi @ phi)
                    e, eomega = [], []
                    for p in fullp[1:]:
                        change = dagger(u) @ p @ u - p
                        square = dagger(change) @ change
                        e.append(np.real(np.trace(tau @ square)))
                        eomega.append(np.real(np.trace(omega @ square)))
                    exact_error = sum(eomega) / 8
                    worst['choi_identity'] = max(worst['choi_identity'],
                                                 abs(1 - ent_fid - exact_error))
                    bridge = sum((np.sqrt(max(ep, 0.)) + 2 * np.sqrt(max(bq, 0.))) ** 2
                                 for ep in e for bq in b) / 32
                    worst['bridge_violation'] = max(worst['bridge_violation'],
                                                   exact_error - bridge)
                    bell = [np.kron(np.eye(2), p) @ phi for p in paulis]
                    probs = [np.real(dagger(v) @ choi @ v) for v in bell]
                    worst['pauli_eigenvalue_identity'] = max(
                        worst['pauli_eigenvalue_identity'], abs(probs[0] - ent_fid),
                        abs(sum(probs[1:]) - exact_error))
                    worst['physical_probability_violation'] = max(
                        worst['physical_probability_violation'], -min(probs),
                        abs(sum(probs) - 1))
                    n += 1
    assert all(v < 1e-11 for v in worst.values()), worst
    return dict(scope='finite algebra and constants only; no asymptotic or device validation',
                cases=n, maxima=worst, status='PASS')


if __name__ == '__main__':
    result = run()
    print(json.dumps(result, indent=2))
    Path(__file__).with_name('thermal_swap_bridge_check.json').write_text(
        json.dumps(result, indent=2) + '\n')
