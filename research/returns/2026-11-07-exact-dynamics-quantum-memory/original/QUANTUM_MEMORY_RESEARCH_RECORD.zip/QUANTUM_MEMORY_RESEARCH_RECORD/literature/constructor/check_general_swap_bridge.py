"""Finite checks of the post-exchange Bell/Weyl bridge and its edge cases."""
import json
from pathlib import Path
import numpy as np


def adj(a):
    return a.conj().T


def gauge_trace(a, d, g):
    return np.trace(a.reshape(d, g, d, g), axis1=0, axis2=2)


def logical_trace(a, d, g):
    return np.trace(a.reshape(d, g, d, g), axis1=1, axis2=3)


def weyls(d):
    x = np.roll(np.eye(d), 1, axis=0)
    z = np.diag(np.exp(2j * np.pi * np.arange(d) / d))
    return [np.linalg.matrix_power(x, a) @ np.linalg.matrix_power(z, b)
            for a in range(d) for b in range(d)]


def run():
    rng = np.random.default_rng(4616446)
    maxima = dict(compression=0., bell_expansion=0., commutator_expansion=0.,
                  bridge_violation=0., averaged_filter=0., q_bound_violation=0.)
    nonhermitian_individual_kernel_gap = 0.
    n = 0
    for d in [2, 3, 4, 5]:
        for g in [2, 3]:
            dim = d * g
            ws = weyls(d)
            fullws = [np.kron(w, np.eye(g)) for w in ws]
            phi = np.eye(d).reshape(-1) / np.sqrt(d)
            p0 = np.outer(phi, phi.conj())
            p = np.kron(p0, np.eye(g))
            expansion = sum(np.kron(w.conj(), wf) for w, wf in zip(ws, fullws)) / d**2
            maxima['bell_expansion'] = max(maxima['bell_expansion'],
                                           np.linalg.norm(p - expansion))
            for trial in range(3):
                raw = rng.normal(size=(dim, dim)) + 1j * rng.normal(size=(dim, dim))
                h = (raw + adj(raw)) / (2 * np.sqrt(dim))
                eng, bas = np.linalg.eigh(h)
                weights = np.exp(-1.3 * (eng - eng.min())); weights /= weights.sum()
                thermal = (bas * weights) @ adj(bas)
                rawrho = rng.normal(size=(dim, dim)) + 1j * rng.normal(size=(dim, dim))
                arbitrary = rawrho @ adj(rawrho); arbitrary /= np.trace(arbitrary)
                for rho in [thermal, arbitrary]:
                    gauge = gauge_trace(rho, d, g)
                    xi = np.kron(np.eye(d) / d, rho)
                    ev, bv = np.linalg.eigh(xi)
                    sqrtxi = (bv * np.sqrt(np.maximum(ev, 0))) @ adj(bv)
                    target = np.kron(p0, gauge)
                    maxima['compression'] = max(maxima['compression'],
                        np.linalg.norm(d**2 * p @ xi @ p - target))
                    q = sum(np.real(np.trace(rho @ adj(h@w-w@h) @ (h@w-w@h)))
                            for w in fullws) / d**2
                    for t in [0., .1, 1.2]:
                        u = (bas * np.exp(-1j * t * eng)) @ adj(bas)
                        fullu = np.kron(np.eye(d), u)
                        failure = np.real(np.trace((np.eye(d*dim)-p) @ fullu @ target @ adj(fullu)))
                        comm = fullu @ p - p @ fullu
                        norm = d**2 * np.linalg.norm(comm @ sqrtxi, 'fro')**2
                        eavg = sum(np.real(np.trace(rho @ adj(u@w-w@u) @ (u@w-w@u)))
                                   for w in fullws) / d**2
                        maxima['commutator_expansion'] = max(maxima['commutator_expansion'],
                                                             abs(norm-eavg))
                        maxima['bridge_violation'] = max(maxima['bridge_violation'], failure-eavg)
                        if rho is thermal:
                            maxima['q_bound_violation'] = max(maxima['q_bound_violation'], failure-t*t*q)
                        n += 1
                sqrtthermal = (bas * np.sqrt(weights)) @ adj(bas)
                bs, integrals = [], []
                delta = eng[:, None] - eng[None, :]
                for w in fullws:
                    bs.append(np.linalg.norm(w@sqrtthermal-sqrtthermal@w, 'fro')**2)
                    we = adj(bas) @ w @ bas
                    integral = 2 * np.sum(weights[None, :] * abs(we)**2
                                           * (1-1/np.cosh(1.3*delta/2)))
                    integrals.append(integral)
                    if d > 2:
                        nonhermitian_individual_kernel_gap = max(
                            nonhermitian_individual_kernel_gap, abs(bs[-1]-integral))
                maxima['averaged_filter'] = max(maxima['averaged_filter'],
                                                abs(np.mean(bs)-np.mean(integrals)))
    assert all(v < 2e-11 for v in maxima.values()), maxima
    # Two-generator obstruction without Gibbs: correlated Bell resource, HOLD=SWAP.
    x = np.array([[0,1],[1,0]], dtype=complex)
    z = np.diag([1.,-1.])
    swap = np.array([[1,0,0,0],[0,0,1,0],[0,1,0,0],[0,0,0,1]], dtype=complex)
    psi = np.array([1,0,0,1])/np.sqrt(2)
    rho = np.outer(psi,psi)
    exz = []
    for w in [np.kron(x,np.eye(2)),np.kron(z,np.eye(2))]:
        change = adj(swap)@w@swap-w
        exz.append(np.real(np.trace(rho@adj(change)@change)))
    assert max(abs(v) for v in exz)<1e-12
    return dict(status='PASS', cases=n, maxima=maxima,
                nonhermitian_individual_filter_discrepancy=nonhermitian_individual_kernel_gap,
                nongibbs_two_generator_counterexample=dict(eX=exz[0],eZ=exz[1],entanglement_fidelity=.25),
                scope='finite identities and edge cases; not asymptotic or physical validation')


if __name__ == '__main__':
    out=run()
    print(json.dumps(out,indent=2))
    Path(__file__).with_name('general_swap_bridge_check.json').write_text(json.dumps(out,indent=2)+'\n')
