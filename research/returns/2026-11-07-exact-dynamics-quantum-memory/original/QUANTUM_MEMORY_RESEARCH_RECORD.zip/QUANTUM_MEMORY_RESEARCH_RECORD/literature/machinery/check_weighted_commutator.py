"""Finite diagnostics for the independently proved thermal-commutator lemma.

This is not a check of N1645 or an infinite-volume proof.
Only Python and NumPy are required. No external code is executed.
"""
from pathlib import Path
import json
import numpy as np


def trace_norm(a):
    return float(np.linalg.svd(a, compute_uv=False).sum())


def gibbs(h, beta):
    e, v = np.linalg.eigh(h)
    w = np.exp(-beta * (e - e.min()))
    return (v * (w / w.sum())) @ v.conj().T


def exp_i(h, t):
    e, v = np.linalg.eigh(h)
    return (v * np.exp(-1j * t * e)) @ v.conj().T


def hermitian(rng, d):
    a = rng.normal(size=(d, d)) + 1j * rng.normal(size=(d, d))
    a = (a + a.conj().T) / 2
    return a / np.linalg.norm(a, 2)


def main():
    rng = np.random.default_rng(1645)
    paulis = [
        np.array([[0, 1], [1, 0]], complex),
        np.array([[0, -1j], [1j, 0]], complex),
        np.diag([1, -1]).astype(complex),
    ]
    rows = []
    maximum_ratios = {"gibbs_commutator": 0.0, "twirl": 0.0, "storage": 0.0}
    for case in range(80):
        junk = 4
        strength = [1.0, 0.1, 0.001, 0.00001][case % 4]
        h = np.kron(np.eye(2), hermitian(rng, junk)) + strength * hermitian(rng, 2 * junk)
        beta = [0.1, 0.7, 2.0, 9.0][(case // 4) % 4]
        gamma = gibbs(h, beta)
        tau = np.einsum("iaib->ab", gamma.reshape(2, junk, 2, junk))
        gamma0 = np.kron(np.eye(2) / 2, tau)
        qs = []
        for p in paulis:
            p0 = np.kron(p, np.eye(junk))
            c = h @ p0 - p0 @ h
            q = float(np.sqrt(max(0.0, np.trace(gamma @ c.conj().T @ c).real)))
            qs.append(q)
            err = trace_norm(gamma @ p0 - p0 @ gamma)
            assert err <= beta * q + 1e-11
            if q:
                maximum_ratios["gibbs_commutator"] = max(maximum_ratios["gibbs_commutator"], err / (beta * q))
        qsum = sum(qs)
        delta = trace_norm(gamma - gamma0)
        assert delta <= beta * qsum / 4 + 1e-11
        if qsum:
            maximum_ratios["twirl"] = max(maximum_ratios["twirl"], delta / (beta * qsum / 4))
        r = rng.normal(size=3)
        r /= np.linalg.norm(r)
        rho = (np.eye(2) + sum(r[a] * paulis[a] for a in range(3))) / 2
        encoded = np.kron(rho, tau)
        for t in [0.0, 0.1, 2.0, 100.0]:
            u = exp_i(h, t)
            err = trace_norm(u @ encoded @ u.conj().T - encoded)
            bound = (beta + abs(t)) * qsum
            assert err <= bound + 1e-10
            if bound:
                maximum_ratios["storage"] = max(maximum_ratios["storage"], err / bound)
        rows.append({"case": case, "strength": strength, "beta": beta, "qsum": qsum})

    # Counterexample to the false noncommuting Gibbs event comparison.
    gap, perturbation, beta = 1.0, 0.1, 200.0
    h0 = np.diag([0.0, gap])
    h = h0 + perturbation * paulis[0]
    population = float(gibbs(h, beta)[1, 1].real)
    unperturbed_population = float(gibbs(h0, beta)[1, 1].real)
    claimed_upper = float(np.exp(2 * beta * perturbation) * unperturbed_population)
    exact_ground_population = (1 - gap / np.sqrt(gap**2 + 4 * perturbation**2)) / 2
    assert abs(population - exact_ground_population) < 1e-12
    assert population > claimed_upper * 1e20
    result = {
        "status": "PASS_FINITE_DIAGNOSTICS_ONLY",
        "n1645_checked": False,
        "cases": len(rows),
        "maximum_observed_ratios": maximum_ratios,
        "false_gibbs_comparison_counterexample": {
            "gap": gap, "lambda": perturbation, "beta": beta,
            "actual_population": population,
            "false_upper_bound": claimed_upper,
            "zero_temperature_limit": exact_ground_population,
        },
        "parameters": rows,
    }
    output = Path(__file__).with_name("weighted_commutator_checks.json")
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "parameters"}, indent=2))


if __name__ == "__main__":
    main()
