# Retained independent proof and failed shortcut

6 November2026. The derivation below was formulated before initial exchange;
saved after exchange without modifying the independent initial report. The
stronger Bell/entropy/KMS theorems now supersede its main channel bound.

Assume an exact accessible memory subsystem L=C², full finite H on L tensor G,
gamma=exp(-beta H)/Z, tau=Tr_L gamma, logical Hermitian Paulis P_a, and
q_a²=Tr gamma[H,P_a]†[H,P_a], q=sum_a q_a. With the actual-Gibbs logical
replacement Enc(rho)=rho tensor tau and U_t=exp(-itH),

    ||U_t Enc(rho) U_t†-Enc(rho)||_1 <=(beta+|t|)q,
    ||Tr_G Ad(U_t)Enc-id||_diamond <=min(2,3(beta+|t|)q).

Complete proof. The scalar inequality
`(sqrt(x)-sqrt(y))²<=(x+y)(log x-log y)²/8`
follows from `1-sech(z)<=z²/2`. The latter follows by convexity of
`sech(z)-1+z²/2`: its second derivative is
`1+sech(z)-2sech(z)^3=(1-sech(z))(2sech(z)^2+2sech(z)+1)>=0`.
In an energy eigenbasis, Hermiticity pairs |P_ij|²=|P_ji|², giving
`||[sqrt(gamma),P_a]||_2<=beta q_a/2`. Schatten Cauchy–Schwarz then gives
`||[gamma,P_a]||_1<=beta q_a`.

The Pauli twirl gamma0=I/2 tensor tau obeys
delta=||gamma0-gamma||_1<=beta q/4. Write rho=(I+r.P)/2 and R=I+r.P, so
||R||<=2 and Enc(rho)=R gamma0. Stationarity and triangle inequality give

    ||U R gamma0 U†-R gamma0||_1
       <=4delta+||(U R U†-R)sqrt(gamma)||_2.

Duhamel and stationarity bound each
`||(U P_a U†-P_a)sqrt(gamma)||_2<=|t|q_a`. Sum with |r_a|<=1 to prove
the first inequality. If the induced trace-norm error on every logical state
is epsilon, write each matrix unit |u><v|, u perpendicular v, as half of a
difference of +/- pure states plus i/2 times a difference of +/-i pure states.
Its output error is at most2epsilon. On a Schmidt-rank2 reference-input pure
state, diagonal blocks contribute epsilon and off-diagonal blocks at most
4sqrt(lambda(1-lambda))epsilon<=2epsilon. Convexity covers all references.
This proves the diamond bound. QED.

If a projection Q satisfies C_a=[H,P_a]=C_a Q, then
`C_a†C_a<=||C_a||²Q`, without requiring [Q,gamma]=0. Therefore
q_a<=||C_a||sqrt(Tr gamma Q). The missing physical step is an actual
interacting-Gibbs rare-tail bound uniform in bath volume, not this inequality.

Counterexample to a tempting noncommuting event comparison: let
H0=Delta|1><1|, V=lambda X, Q=|1><1|, 0<2lambda<Delta. Direct diagonalization
gives

    Tr Q gamma_(H0+V)
      =[1-Delta/sqrt(Delta²+4lambda²)
                tanh(beta sqrt(Delta²+4lambda²)/2)]/2.

As beta tends to infinity this is positive, whereas the proposed upper bound
`exp(2beta||V||)Tr Q gamma_H0=exp(2beta lambda)/(1+exp(beta Delta))`
tends to zero. For Delta1,lambda0.1,beta200 the values are
0.009709662154539918 and3.257488532207522e-70. Classical event-wise Gibbs
comparison cannot be transferred by exponential operator monotonicity.

`check_weighted_commutator.py` and `weighted_commutator_checks.json` retain
80 finite random diagnostics and this two-level calculation. They do not
verify N1645 or prove a thermodynamic limit. The matrix argument above is
the proof at its stated finite ideal-resource scope; no novelty is claimed.
