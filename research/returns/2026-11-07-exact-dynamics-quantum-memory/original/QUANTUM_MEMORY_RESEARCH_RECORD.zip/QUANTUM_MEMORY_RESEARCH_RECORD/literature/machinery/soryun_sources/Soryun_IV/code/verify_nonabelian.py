#!/usr/bin/env python3
"""Finite nonabelian operator-module checks and conservative coding certificates.

All matrix tests are finite-dimensional illustrations of the accompanying
proofs. Certificate plots evaluate stated sufficient bounds for explicitly
chosen norm budgets; they are not device measurements or decoder benchmarks.
Requires Python 3.10+, NumPy, SciPy, Matplotlib.
"""
from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
from pathlib import Path

import numpy as np
from scipy.linalg import expm, svd
from scipy.special import gammaln

SEED=20261104
TOL=3e-10
I2=np.eye(2,dtype=complex)
X=np.array([[0,1],[1,0]],complex)
Y=np.array([[0,-1j],[1j,0]],complex)
Z=np.diag([1,-1]).astype(complex)
SINGLE=[I2,X,Y,Z]


def kron(ops:list[np.ndarray])->np.ndarray:
    a=np.ones((1,1),complex)
    for op in ops:a=np.kron(a,op)
    return a


def onsite(op:np.ndarray,j:int,n:int)->np.ndarray:
    return kron([op if k==j else I2 for k in range(n)])


def paulis(n:int)->list[tuple[tuple[int,...],int,np.ndarray]]:
    return [(label,sum(a!=0 for a in label),kron([SINGLE[a] for a in label]))
            for label in itertools.product(range(4),repeat=n)]


def collective_algebra(n:int)->list[np.ndarray]:
    """Permutation-invariant Pauli sums form a basis of collective SU(2) algebra."""
    groups={}
    for label,weight,op in paulis(n):
        counts=tuple(label.count(j) for j in (1,2,3))
        groups[counts]=groups.get(counts,np.zeros_like(op))+op
    answer=[op/np.linalg.norm(op,'fro') for op in groups.values()]
    assert len(answer)==math.comb(n+3,3)
    gram=np.array([[np.vdot(a,b) for b in answer] for a in answer])
    assert np.linalg.norm(gram-np.eye(len(answer)))<TOL
    return answer


def orthogonal_module_basis(n:int,s:int)->np.ndarray:
    algebra=collective_algebra(n)
    columns=np.column_stack([(p@a).reshape(-1) for label,w,p in paulis(n) if w<=s
                             for a in algebra])
    u,singular,_=svd(columns,full_matrices=False)
    rank=int(np.sum(singular>1e-10*singular[0]))
    return u[:,:rank]


def model_hamiltonians(r:int)->tuple[np.ndarray,np.ndarray,float]:
    """r survivors, one erased physical qubit, then a shared bath qubit."""
    n=r+1
    j=[sum((onsite(op/2,k,n) for k in range(n)),np.zeros((2**n,2**n),complex))
       for op in (X,Y,Z)]
    h0=.71*np.kron(j[0],X)+.53*np.kron(j[1],Z)+.39*np.kron(j[2],Y)
    h0+=np.kron(np.eye(2**n),.21*X-.17*Y+.13*Z)
    # An explicit erased-site flip demonstrates that E is not assumed inert.
    h0+=.27*np.kron(onsite(X,r,n),Y)+.19*np.kron(onsite(Z,r,n),X)
    h1=np.zeros_like(h0)
    budget=0.0
    for k in range(r):
        amplitude=.018*(k+1)/r
        bath=(.43+.03*k)*SINGLE[1+k%3]+.17*SINGLE[1+(k+1)%3]
        term=amplitude*np.kron(onsite(SINGLE[1+k%3],k,n),bath)
        h1+=term
        budget+=amplitude*np.linalg.norm(bath,2)
    assert np.linalg.norm(h0-h0.conj().T)<TOL
    assert np.linalg.norm(h1-h1.conj().T)<TOL
    return h0,h1,float(budget)


def dyson_coefficients(h0:np.ndarray,h1:np.ndarray,duration:float,order:int)->list[np.ndarray]:
    """Exact constant-H interaction-Dyson coefficients via block exponential.

    The (0,k) block of exp(I tensor A + shift tensor B) is the coefficient
    of lambda^k in exp(A+lambda B), with A=-itH0 and B=-itH1.
    """
    d=len(h0)
    shift=np.diag(np.ones(order),1)
    generator=np.kron(np.eye(order+1),-1j*duration*h0)
    generator+=np.kron(shift,-1j*duration*h1)
    big=expm(generator)
    return [big[:d,k*d:(k+1)*d] for k in range(order+1)]


def coefficient_blocks(op:np.ndarray,d_r:int,d_eb:int)->np.ndarray:
    return op.reshape(d_r,d_eb,d_r,d_eb).transpose(0,2,1,3).reshape(d_r*d_r,d_eb*d_eb)


def projection_checks()->tuple[list[dict],list[np.ndarray],float,float]:
    r=4
    h0,h1,local_budget=model_hamiltonians(r)
    duration=.83
    exact=expm(-1j*duration*(h0+h1))
    coeff=dyson_coefficients(h0,h1,duration,2)
    d_r,d_eb=2**r,4
    rows=[]
    approximations=[]
    a=duration*local_budget
    for s in (0,1,2):
        approximation=sum(coeff[:s+1],np.zeros_like(h0))
        approximations.append(approximation)
        blocks=coefficient_blocks(approximation,d_r,d_eb)
        q=orthogonal_module_basis(r,s)
        module_error=np.linalg.norm(blocks-q@(q.conj().T@blocks),'fro')/np.linalg.norm(blocks,'fro')
        raw=np.column_stack([p.reshape(-1)/math.sqrt(d_r) for _,w,p in paulis(r) if w<=s])
        raw_error=np.linalg.norm(blocks-raw@(raw.conj().T@blocks),'fro')/np.linalg.norm(blocks,'fro')
        tau=math.exp(a+(s+1)*math.log(a)-gammaln(s+2))
        actual_tail=float(np.linalg.norm(exact-approximation,2))
        assert module_error<TOL
        assert actual_tail<=tau+TOL
        # Baseline collectively couples survivors; raw low-weight Pauli support
        # already grows even though the collective module remains invariant.
        assert raw_error>1e-3
        rows.append({"surviving_qubits":r,"erased_qubits":1,"bath_dimension":2,
                     "joint_dimension":len(h0),"Dyson_order_s":s,
                     "collective_algebra_dimension":math.comb(r+3,3),
                     "module_dimension_numerical":q.shape[1],
                     "module_dimension_upper_bound":sum(math.comb(r,w)*3**w for w in range(s+1))*math.comb(r+3,3),
                     "relative_Frobenius_module_projection_error":float(module_error),
                     "relative_Frobenius_raw_Pauli_projection_error":float(raw_error),
                     "actual_operator_tail_norm":actual_tail,"safe_Dyson_tail_tau":tau,
                     "integrated_residual_budget_a":a,
                     "erased_site_flip_in_baseline":True})
    return rows,approximations,a,duration


def choi(kraus:list[np.ndarray])->np.ndarray:
    size=kraus[0].size
    out=np.zeros((size,size),complex)
    for k in kraus:
        v=k.reshape(-1,order='F')
        out+=np.outer(v,v.conj())
    return out


def psd_sqrt(a:np.ndarray)->np.ndarray:
    eig,u=np.linalg.eigh((a+a.conj().T)/2)
    assert eig[0]>=-TOL
    return (u*np.sqrt(np.maximum(eig,0)))@u.conj().T


def amplitude_kraus(joint:np.ndarray,r:int)->tuple[list[np.ndarray],np.ndarray]:
    """Bath initially |0>; E input unrestricted; E output and bath discarded."""
    d_r,d_a=2**r,2**(r+1)
    v=joint[:,np.arange(d_a)*2]
    ks=[]
    for e_out in range(2):
        for b in range(2):
            ks.append(v[(np.arange(d_r)*2+e_out)*2+b,:])
    return ks,v


def canonical_kraus(dictionary:list[np.ndarray],r:int,complete:bool)->list[np.ndarray]:
    d_r,d_a,m=2**r,2**(r+1),len(dictionary)
    erase=[]
    for e in range(2):
        k=np.zeros((d_r,d_a),complex)
        for a in range(d_r):k[a,a*2+e]=1
        erase.append(k)
    result=[a@k/math.sqrt(m) for a in dictionary for k in erase]
    if complete:
        deficit=np.eye(d_r)-sum((a.conj().T@a for a in dictionary),np.zeros((d_r,d_r),complex))/m
        completion=psd_sqrt(deficit)
        result.extend(completion@k for k in erase)
    trace=sum((k.conj().T@k for k in result),np.zeros((d_a,d_a),complex))
    assert np.linalg.norm(trace-np.eye(d_a))<TOL
    return result


def dual_coordinate_norm(dictionary:list[np.ndarray])->tuple[float,float]:
    matrix=np.column_stack([a.reshape(-1,order='F') for a in dictionary])
    inverse=np.linalg.inv(matrix)
    duals=[inverse[i].conj().reshape(dictionary[0].shape,order='F') for i in range(len(dictionary))]
    gram=np.array([[np.trace(d.conj().T@a) for a in dictionary] for d in duals])
    assert np.linalg.norm(gram-np.eye(len(dictionary)))<TOL
    norm=max(float(np.linalg.svd(d,compute_uv=False).sum()) for d in duals)
    offdiag=matrix.conj().T@matrix
    offdiag-=np.diag(np.diag(offdiag))
    return norm,float(np.linalg.norm(offdiag,'fro'))


def cp_domination_checks()->list[dict]:
    r=2
    d=2**r
    h0,h1,budget=model_hamiltonians(r)
    duration=.71
    coefficients=dyson_coefficients(h0,h1,duration,1)
    approximate=coefficients[0]+coefficients[1]
    exact=expm(-1j*duration*(h0+h1))
    a=duration*budget
    tau=math.exp(a+2*math.log(a)-gammaln(3))
    assert np.linalg.norm(exact-approximate,2)<=tau+TOL
    approx_ks,v=amplitude_kraus(approximate,r)
    vnorm=float(np.linalg.norm(v,2))
    assert vnorm<=1+tau+TOL
    jpsi=choi(approx_ks)
    pauli=[p for _,_,p in paulis(r)]
    units=[]
    for aindex in range(d):
        for bindex in range(d):
            e=np.zeros((d,d),complex);e[aindex,bindex]=1;units.append(e)
    nonorthogonal=[]
    for i,p in enumerate(pauli):
        aop=p+.21*pauli[(i+1)%len(pauli)]
        nonorthogonal.append(aop/np.linalg.norm(aop,2))
    cases=[('orthonormal_unitary_Paulis',pauli,False,'m*v^2'),
           ('matrix_unit_Auerbach_basis',units,True,'m^2*c^2*v^2'),
           ('nonorthogonal_contraction_dictionary',nonorthogonal,True,'m^2*c^2*v^2')]
    rows=[]
    for name,dictionary,complete,formula in cases:
        m=len(dictionary)
        c,offdiag=dual_coordinate_norm(dictionary)
        if name!='nonorthogonal_contraction_dictionary':assert abs(c-1)<TOL
        else:assert c>1 and offdiag>1
        canonical=canonical_kraus(dictionary,r,complete)
        jphi=choi(canonical)
        factor=m*vnorm**2 if formula=='m*v^2' else m*m*c*c*vnorm**2
        diff=factor*jphi-jpsi
        minimum=float(np.linalg.eigvalsh((diff+diff.conj().T)/2)[0])
        assert minimum>=-TOL
        safe_factor=m*(1+tau)**2 if formula=='m*v^2' else m*m*c*c*(1+tau)**2
        rows.append({"dictionary":name,"surviving_qubits":r,"input_physical_qubits":r+1,
                     "dictionary_size_m":m,"maximum_basis_operator_norm":max(float(np.linalg.norm(op,2)) for op in dictionary),
                     "maximum_dual_coordinate_norm_c":c,"HS_offdiagonal_Gram_norm":offdiag,
                     "approximate_amplitude_operator_norm_v":vnorm,"safe_tail_tau":tau,
                     "CP_domination_formula":formula,"tested_CP_domination_factor":factor,
                     "safe_factor_using_1_plus_tau":safe_factor,
                     "minimum_unnormalized_Choi_domination_eigenvalue":minimum,
                     "canonical_channel_completed":complete,"Choi_dimension":len(jpsi),
                     "arbitrary_erased_site_flip_present":True})
    return rows


def h2(q:float)->float:
    if q<=0 or q>=1:return 0.0
    return -q*math.log2(q)-(1-q)*math.log2(1-q)


def log_collective_algebra_dimension(n:int,b:int)->float:
    full,rem=divmod(n,b)
    out=full*math.log2(math.comb(b+3,3))
    if rem:out+=math.log2(math.comb(rem+3,3))
    return out


def log2_one_plus_exp2(x:float)->float:
    if x>50:return x+math.log1p(2**(-x))/math.log(2)
    return math.log2(1+2**x)


def finite_certificate_rows()->list[dict]:
    """Conservative m^2 CP bound, full input dimension 2^N.

    User-facing curves assert only the assumed per-site residual budget;
    they do not measure or infer it for an experimental platform.
    """
    rows=[]
    p,target=.1,.01
    for nu in (1,2,3):
        for beta in (.25,.5,1.):
            for amplitude in (.001,.01):
                for exponent in range(4,13):
                    n=10**exponent
                    b=max(2,int(math.ceil(math.sqrt(n))))
                    epsilon=amplitude*(b/n)**(beta/nu)
                    a=n*epsilon
                    s=int(math.ceil(math.e**2*a+4*math.log(n)))
                    logtau=a+(s+1)*math.log(a)-gammaln(s+2)
                    tau=math.exp(logtau) if logtau>-745 else 0.0
                    tail_error_log=logtau+math.log(2+tau)
                    tail_ok=tail_error_log<=math.log(target/4)
                    cutoff_ok=s<=n/2
                    q=s/n
                    pauli_log=n*h2(q)+s*math.log2(3) if cutoff_ok else 2*n
                    alg_log=log_collective_algebra_dimension(n,b)
                    logm=pauli_log+alg_log
                    # Using the upper dimension estimate is conservative even
                    # when it exceeds the full operator-space dimension.
                    eta=math.sqrt(math.log(4/target)/(2*n))
                    u=n*(p+eta)
                    logm1=log2_one_plus_exp2(logm)
                    correction=2*math.log2(target/(2*(1+tau)**2))
                    logical_bound=n-2*u-4*logm-logm1-1+correction
                    logical=max(0,int(math.floor(logical_bound))-32) if tail_ok and cutoff_ok else 0
                    if logical:
                        logcoding=(2*logm+u+.5*(1+logical+logm1-n))*math.log(2)+2*math.log1p(tau)
                        assert logcoding<=math.log(target/2)+1e-9
                    rows.append({"N":n,"nu":nu,"Holder_beta":beta,"residual_amplitude":amplitude,
                                 "cell_qubits_b":b,"erasure_probability_p":p,"target_error":target,
                                 "per_site_residual_epsilon":epsilon,"Dyson_order_s":s,
                                 "support_fraction_s_over_N":q,"log_safe_tail_tau":float(logtau),
                                 "tail_budget_passes":bool(tail_ok),"entropy_envelope_applicable":bool(cutoff_ok),
                                 "log2_Pauli_ball_upper_bound":pauli_log,
                                 "log2_collective_algebra_dimension":alg_log,
                                 "log2_operator_module_dimension_upper_bound":logm,
                                 "erasure_slack_eta":eta,"erasure_cutoff_u":u,
                                 "logical_qubits_certified":logical,"certified_rate":logical/n,
                                 "interpretation":"Sufficient bound for an assumed residual norm budget; no implemented decoder"})
    # Independent small-size verification of both exact dimension counts.
    for n in (4,8,16,32):
        for s in range(n//2+1):
            exact=sum(math.comb(n,w)*3**w for w in range(s+1))
            assert math.log2(exact)<=n*h2(s/n)+s*math.log2(3)+TOL
    return rows


def write_csv(path:Path,rows:list[dict])->None:
    with path.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def plots(output:Path,projection:list[dict],certificates:list[dict])->None:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(1,2,figsize=(9,3.8),layout='constrained')
    orders=[r['Dyson_order_s'] for r in projection]
    axes[0].semilogy(orders,[max(r['relative_Frobenius_module_projection_error'],1e-17) for r in projection],
                     marker='o',color='#267882',label='Collective operator module')
    axes[0].semilogy(orders,[r['relative_Frobenius_raw_Pauli_projection_error'] for r in projection],
                     marker='o',color='#a66c55',label='Raw weight ≤s Pauli span')
    axes[0].set(xlabel='Interaction-Dyson order s',ylabel='Relative projection residual',
                title='Four survivors, one erased site, shared bath',xticks=orders)
    axes[0].legend(frameon=False,fontsize=8)
    axes[1].semilogy(orders,[r['actual_operator_tail_norm'] for r in projection],marker='o',
                     color='#267882',label='Exact unitary minus truncation')
    axes[1].semilogy(orders,[r['safe_Dyson_tail_tau'] for r in projection],marker='o',
                     color='#9174b3',label='Proved tail upper bound')
    axes[1].set(xlabel='Interaction-Dyson order s',ylabel='Operator norm',title='Finite matrix tail check',xticks=orders)
    axes[1].legend(frameon=False,fontsize=8)
    for ax in axes:ax.grid(alpha=.16)
    for ext in ('png','pdf'):fig.savefig(output/f'nonabelian_module_checks.{ext}',dpi=220)
    plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(9,3.8),layout='constrained')
    for nu,color in [(1,'#267882'),(2,'#9174b3'),(3,'#a66c55')]:
        chosen=[r for r in certificates if r['nu']==nu and r['Holder_beta']==.5 and r['residual_amplitude']==.001]
        axes[0].plot([r['N'] for r in chosen],[r['certified_rate'] for r in chosen],marker='o',
                     color=color,label=f'Dimension {nu}')
    for beta,color in [(.25,'#a66c55'),(.5,'#9174b3'),(1.,'#267882')]:
        chosen=[r for r in certificates if r['nu']==2 and r['Holder_beta']==beta and r['residual_amplitude']==.001]
        axes[1].plot([r['N'] for r in chosen],[r['certified_rate'] for r in chosen],marker='o',
                     color=color,label=f'Hölder β={beta:g}')
    for ax in axes:
        ax.axhline(.8,color='#354052',linestyle='--',linewidth=1)
        ax.set(xscale='log',xlabel='Physical qubits N',ylabel='Sufficient certified rate',ylim=(-.02,.83))
        ax.legend(frameon=False,fontsize=8);ax.grid(alpha=.16)
    axes[0].set_title('Hölder β=1/2')
    axes[1].set_title('Spatial dimension 2')
    fig.suptitle('Generic nonabelian bound: p=0.1, target error=0.01, residual amplitude=0.001',fontsize=10)
    for ext in ('png','pdf'):fig.savefig(output/f'nonabelian_finite_certificates.{ext}',dpi=220)
    plt.close(fig)


def main()->None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parents[1]/'results'/'nonabelian')
    parser.add_argument('--no-plot',action='store_true')
    args=parser.parse_args();args.output_dir.mkdir(parents=True,exist_ok=True)
    projection,_,_,_=projection_checks()
    cp=cp_domination_checks();certificates=finite_certificate_rows()
    result={'seed':SEED,'numerical_tolerance':TOL,
            'status':'Finite matrix checks and analytic certificate evaluations, not proofs or novelty certification',
            'Dyson_operator_module_checks':projection,'generic_CP_domination_checks':cp,
            'finite_nonabelian_rate_certificates':certificates}
    (args.output_dir/'nonabelian_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    write_csv(args.output_dir/'Dyson_module_checks.csv',projection)
    write_csv(args.output_dir/'generic_CP_checks.csv',cp)
    write_csv(args.output_dir/'finite_certificates.csv',certificates)
    if not args.no_plot:plots(args.output_dir,projection,certificates)
    print(json.dumps({'all_assertions_passed':True,
                      'module_dimensions':[r['module_dimension_numerical'] for r in projection],
                      'maximum_module_projection_residual':max(r['relative_Frobenius_module_projection_error'] for r in projection),
                      'raw_Pauli_projection_residuals':[r['relative_Frobenius_raw_Pauli_projection_error'] for r in projection],
                      'minimum_CP_domination_eigenvalue':min(r['minimum_unnormalized_Choi_domination_eigenvalue'] for r in cp),
                      'certificate_rows':len(certificates),'positive_certificates':sum(r['logical_qubits_certified']>0 for r in certificates)},indent=2))


if __name__=='__main__':main()
