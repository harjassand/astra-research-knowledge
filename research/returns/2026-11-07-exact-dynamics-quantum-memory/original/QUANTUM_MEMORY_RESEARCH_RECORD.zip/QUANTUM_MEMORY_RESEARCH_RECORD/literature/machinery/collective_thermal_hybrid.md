# Collective fields, full thermal resources, and a repaired transfer

6 November 2026. Post-exchange response to the principal's hybrid challenge.
This does not import N1653's static theorem into N1645. All systems and baths
are finite unless a separate uniform limit is proved. hbar=1.

## 1. Exact full-support obstruction

For n spin-1/2 particles, the collective SU(2) representation decomposes as

    (C²)^tensor n = directsum_j V_j tensor M_j,
    A_collective = directsum_j End(V_j) tensor I_(M_j),
    A_collective' = directsum_j I_(V_j) tensor End(M_j).

The maximum-spin irrep j=n/2 has multiplicity dim(M_j)=1. Consequently the
commutant has a unital scalar character: restrict an element to that summand.
There is no unital *-homomorphism M_2 into the full commutant. Otherwise
composition with this character would give a unital *-homomorphism M_2 to C,
impossible because M_2 is simple and a nonzero homomorphism is injective.
Equivalently, putative Pauli X,Z would restrict to nonzero scalar unitaries,
which cannot anticommute.

For multiple cells with independently allowed collective fields, the tensor
product of maximum-spin sectors still has multiplicity one, giving the same
obstruction. Shared quantum bath coefficients do not remove it: permitting
all coefficients includes scalar fields in each axis, so a universally
conserved system algebra must commute with every cell's collective generators.

A finite-temperature Gibbs state of a finite Hamiltonian is faithful.
An exactly vanishing Gibbs-weighted commutator therefore vanishes as an
operator: C sqrt(gamma)=0 implies C=0. A finite energy penalty cannot make the
maximum-spin summand have zero Gibbs weight. Thus a full-support, exact
logical M_2 algebra commuting with all these fields cannot be supplied by
simply declaring a preferred collective noiseless multiplicity space.

This is a narrow algebraic no-go, not an impossibility theorem for approximate
recovery, sector preparation, flag-dependent writing, or the Soryun code.
Soryun uses approximate final recovery in the entire space, not an exact
unital M_2 in the collective commutant.

## 2. A uniform finite-temperature flag estimate

Four spins have a total-spin-zero projector P_b of rank2 and complement Q_b
of rank14. The rank2 factor is a true noiseless multiplicity qubit. Consider

    H = H_B + Delta sum_b Q_b + sum_b F_b + H_int.

Assume: all terms commute with every P_b; each F_b is a collective field on
cell b with arbitrary bath coefficients, F_b P_b=0 and ||F_b||<=M; and
H_int is a sum of terms with sum of incident norms at each cell at most J.
Bath-only terms belong to H_B and may be arbitrarily large. H_int can be
noncommuting inside each fixed flag sector. M,J,Delta,beta are declared
numbers, not hidden in an asymptotic limit.

Let gamma be the actual Gibbs state. Its measured flags form a classical
distribution because all P_b commute with H. For every specification of all
other flags,

    Pr(Q_b | other flags)/Pr(P_b | other flags)
       <= r := 7 exp[-beta(Delta-M-2J)].                       (1)

Proof: within that fixed other-flag sector, remove all terms incident to b.
The remaining H_rest is identity on cell b, with partition function Z_rest.
The bad sector has dimension14, penalty Delta, and perturbation norm at most
M+J, so Z_bad<=14 exp[-beta Delta+beta(M+J)] Z_rest. The good sector has
dimension2, no field F_b, and incident perturbation norm at most J, so
Z_good>=2 exp[-beta J] Z_rest. Divide. These ordinary trace-exponential
bounds follow from eigenvalue monotonicity under scalar operator bounds;
there is no false event-wise noncommuting Gibbs comparison.

All conditional bad probabilities are at most p=r/(1+r). The same holds
when conditioning on only some flags, by averaging the full conditional
probabilities. Generate flags sequentially from independent uniform random
numbers: at each step the bad threshold is at most p. This couples the bad
set to a containing Bernoulli(p) set without any FKG assumption. Therefore

    Pr(all N cells bad)<=p^N,
    Pr(number bad>=aN)<=exp[-N D(a||p)]  for p<a<1.             (2)

The bounds are uniform in bath volume and allow arbitrary correlations
mediated by the shared bath. They require the stated field norm M and exact
flag invariance. They do not follow just from spatial smoothness.

## 3. A genuine full-resource repair for exactly collective noise

Set H_int=0. Start from the full actual gamma. Measure the commuting
system-only flags P_b. If some cell is good, select the first such cell and
swap the unknown input into its rank2 singlet factor, discarding the old
qubit. Retain the classical index. If every cell is bad, use a declared
failure channel.

All collective generators vanish on the selected singlet factor. Arbitrary
subsequent time-dependent collective fields with shared bath memory act as
identity there. The selected flag is conserved and the final system-only
reader returns the qubit exactly, including its reference entanglement.
The overall half-diamond error is at most p^N at every time. This is a CPTP
protocol with a failure branch, not a postselected success claim. It uses
the full finite-temperature resource and finite Delta.

One may similarly route k qubits into k selected good cells, failing if fewer
than k are available. For k<=(1-p-eta)N, equation(2) bounds that failure
exponentially. The ideal writer, classical mapping, reliable index record,
routing and final access are charged costs. This is established noiseless-
subsystem/flag-selection machinery, not generic local self-correction.

A field norm cannot be omitted from the thermal estimate: F_b=-K J_b^z
favors maximum-spin polarization, while singlets have energy0. For independent
cells with fixed Delta, their good probability tends to zero as K increases.
Choosing K with N so that N Pr(P_b) tends to zero makes finding any singlet
unlikely. This obstructs this flag-preserving protocol's uniform estimate
over unbounded fields. It does not prohibit a powered writer that resets a
cell to a singlet sector and pays its preparation and energy cost.

The flag protocol can also be written as an exact full-support logical SWAP,
so measurement is not essential to this repair. A flag sector with g good
cells has dimension `2^g 14^(N-g)=2^N 7^(N-g)`. For any k<=N it admits a
factor C^(2^k). In sectors with g>=k, choose that factor as the first k good
singlet qubits; in the remaining sectors choose any factor of that size.
The direct sum gives one system-only full-support factorization L tensor G.
Swap the unknown k-qubit input into this fixed L and decode the same factor.
Flags belong to G, so their probabilities and bath marginal are unchanged.
On every g>=k sector, all hold Hamiltonians act as identity on L. Initial
Gibbs flag sectors have no cross-sector coherences, and the complete channel
is a convex mixture with perfect success branches. Its half-diamond error
is bounded by Pr(g<k), exactly as above. The conditional subsystem unitary
can be nonlocal and expensive. The maximum-spin character prohibits exact
conservation on the failure sectors, consistently with Section1.

## 4. Conditional lift of a supplied outer memory

Suppose an N-qubit outer Hamiltonian H_out=H_B+sum_X h_X, possibly coupled to
the same finite bath, has an actual-Gibbs write/store/read theorem of half-
diamond error epsilon(t). Assume sum_(X contains b)||h_X||<=J. Choose
isometries V_b:C²->P_b(C²)^tensor4. Lift h_X by V_X h_X V_X†, extending by
zero if any touched cell is bad, and call the sum H_lift. Define

    H_phys=H_B+H_lift+Delta sum_b Q_b+sum_b F_b.                (3)

The lifted interactions commute with all flags and retain their exact norms
and bounded-body geometric support, up to replacing one spin by a four-spin
cell. On all good, H_phys equals V H_out V†. Its normalized Gibbs state
conditioned on all good is therefore exactly the isometric image of the
actual interacting outer Gibbs state. No factorized bath has been substituted.

Measure all flags; on all good use the supplied outer writer, hold dynamics
and reader through V. On failure use a declared failure channel. Additional
time-dependent collective fields vanish on the success sector, whose flags
remain conserved. The total logical channel has

    halfdiamond error <= epsilon(t)+Pr(some bad)
                       <= epsilon(t)+Np.                     (4)

In particular

    Delta >= M+2J+beta^-1 log(7N/delta)                       (5)

suffices for error epsilon(t)+delta throughout the outer theorem's interval.
This is a complete conditional transfer to model(3), under its ideal flag
writer and norm budgets. It does not verify the outer theorem for N1645 or
enlarge the bath class permitted by a supplied outer theorem.

The penalty in(5) grows logarithmically with volume at fixed temperature and
global delta. This changes the fixed-strength resource class. Already for
independent penalty cells, F=H_int=0, Pr(all good) is exactly
`[1+7 exp(-beta Delta)]^-N`. At fixed Delta, all-good postselection is thus
exponentially unlikely. O(log N) candidate cells per outer site can avoid a
growing penalty, while introducing growing cell size, selection controls and
routing. Neither route is a free fixed-density, fixed-range, fixed-strength
3D implementation.

At fixed penalties, the stronger route is an outer memory robust to a positive
density of known bad cells, with actual sector-conditioned Gibbs measures
and surviving interactions controlled. Equation(2) supplies a stochastic
domination input. No such dilution-robust exact-thermal 3D memory theorem was
verified here; a punctured geometry need not retain the outer barrier.

## 5. Why small noncollective spatial residuals are a separate operation

For each physical spin i and axis a,

    P_b sigma_i^a P_b=0,    ||sigma_i^a P_b||=1.

The first identity follows because P_b is invariant under every collective
rotation, whereas the three sigma components transform as a vector, which
has no invariant component. The second follows from Pauli unitarity. Thus a
physical onsite residual maps a singlet directly out of its noiseless sector.
It is not a small logical perturbation inside an invariant multiplicity
qubit. Its commutator with the flag has norm1 on that sector.

A gap alone does not suppress such leakage uniformly over arbitrary bath
spectra. Choose a normalized singlet s, let v=sigma_i^z s, a bath qubit with
H_B=Delta|1><1|, and residual lambda sigma_i^z tensor X_B. The span of
`s tensor |1>` and `v tensor |0>` is invariant: sigma_i^z swaps s,v, both
joint states have energy Delta, and the off-diagonal coupling is lambda.
The exact leakage from the first to the second is sin²(lambda t), reaching
one at t=pi/(2lambda), independently of the size of Delta. At finite beta
the resonant bath excitation has positive weight. This is a counterexample
to a bath-uniform gap-only leakage argument, not to a complete outer code.

The generic smooth-field residual in Soryun has precisely this possible
noncollective onsite form. The theorem handles it by a filtered operator
envelope and approximate outer recovery. Our model(3) instead requires exact
sector preservation. General smooth residuals can be covered only by adding
and proving an outer leakage/thermal-dilution theorem or a suitable actual-
Gibbs commutator certificate. The blockwise symmetry and penalty do not
produce that theorem automatically.

## Status and predecessors

The algebraic no-go, thermal flag bound, flagged exact-symmetry protocol and
conditional log-penalty lift above are proved at their stated finite scopes.
Generic smooth-field plus fixed-parameter outer thermal protection remains
open here. Collective noiseless multiplicities and Schur–Weyl decomposition
are established machinery. Soryun23859937 Theorem4.2 uses the same collective
algebra but a different full-space approximate-recovery construction; it
does not assert an exact full-support noiseless qubit. No historical-first
claim or practical advantage is made for these repairs.

### Fixed-dimensional outer spins, including clocks

The conditional lift also covers any fixed local outer dimension d. Choose
2m physical spins whose singlet multiplicity is Catalan(m)>=d and a rank-d
projector P inside that singlet space. Every collective generator still
annihilates P. The proof replaces rank ratio7 by R=(2^(2m)-d)/d. For finitely
many fixed outer dimensions, use their maximum R, M and J. The sufficient
penalty is `Delta>=M+2J+beta^-1 log(RN/delta)`.

Thus the7-level native clocks in a separately proved outer theorem do not
create a dimensional obstacle to the conditional construction: eight spins
have singlet multiplicity14 and can contain a selected rank7 factor. This
does not establish the outer theorem, remove its weak-bath restrictions or
the growing-penalty cost, or license generic nonsymmetric residuals.
