# Exact imports, priority, and strongest capability assessment

6 November 2026. This follow-up was written after the independent initial
return was saved and then exchanged. Primary files are cached in this
directory. No N1645 theorem, missing archive or original check was invented.
Search coverage is bounded and cannot establish historical firstness.

## 1. What is new relative to existing capital

| Operation | Exact predecessor or current status | Novelty consequence |
|---|---|---|
| Matrix logical algebra, correlated stationary reference, exact total dynamics | Alicki–Fannes0809.4180(2008), Sections2–4 | Established framework. |
| Physical logical replacement leaving gauge/bath marginal fixed | Same, equations11–14 and final assignment-map remark | Explicitly present in2008. |
| Actual interacting Gibbs, memory/clock-only swap, reference-safe physical time and volume-uniform perturbation norm budget | Dated2November N1653 roots and exact physical-time audit, at their stated static premises | Existing internal capital; no new access capability claim. The dated text does not establish its public priority date. |
| General correlated-resource Bell compression, arbitrary CPTP dynamics, weighted Kraus commutator bound | Principal/constructor post-exchange proof checked line by line; no verbatim primary predecessor located | Useful elementary formulation; historical novelty UNKNOWN. |
| Dimension-free randomized diamond conclusion | Weyl/Pauli channel twirl plus Bell orthogonality; reliable classical frame charged | Routine channel machinery, not a new passive mechanism. |
| Full inverse-tail physical lifetime under bad-supported commutators | Principal entropy and auditor KMS arguments independently checked; stronger than N1653's saved Pinsker consumer | New quantitative upgrade within this research round, conditional on actual static tail; historical priority NOT ESTABLISHED. |
| Arbitrary CPTP writer admitted by entropy of its average joint output | Complete proof in ../../followup/machinery_entropy_admission.md | Conditional admission tool; no realistic noisy writer constructed. |
| Generic 3D exact bath with noisy write/store/read at useful cost | Not established by any completed implication in this round | NOT ACHIEVED. |

The strongest current consequence is the inverse-tail consumer, not my
weaker independent Gibbs-twirl estimate. If actual p<=poly(n)exp(-c n^eta)
and bad-supported commutator norms are polynomial, it yields a fixed-error
horizon exp(c' n^eta) for every c'<c, at fixed beta and ideal access. The old
square-root/pinsker or t² estimate only gave c'<c/2. This is a real exponent
improvement, while the underlying 3D static construction and access resource
remain earlier dependencies. No claim of the first historical microscopic
memory theorem follows from failing to find an identical inequality.

## 2. Load-bearing source checks

**Alicki–Fannes**, *Decay of fidelity in terms of correlation functions*,
[0809.4180v1](https://arxiv.org/abs/0809.4180v1), submitted24September2008;
PRA79,012316(2009), DOI10.1103/PhysRevA.79.012316. Full nine-page text read.
Section2 assumes A=Q tensor B, Q=M_d, faithful normal invariant reference
state and normal unital CP dynamics; the introduction explicitly includes
exact automorphism dynamics of the total system. Section3 equations11–14
give CPTP preparation. Its assignment-map remark explicitly states
sigma->sigma tensor omega_B for logical replacement. Equation23 is an
UPPER fidelity bound under contraction/mixing, not our lower memory bound.
An example after23 additionally assumes the logical algebra fixed by modular
dynamics. General correlation-to-memory language is therefore old.

**Chesi–Loss–Bravyi–Terhal**, *Thermodynamic stability criteria for a quantum
memory based on stabilizer and subsystem codes*,
[0907.2807v2](https://arxiv.org/abs/0907.2807v2); v1 16July2009,
v2 30September2009; NJP12,025013(2010), DOI10.1088/1367-2630/12/2/025013.
Theorem1, Section6, assumes a Gibbs-stationary Lindbladian, logical Pauli
algebra and good projection commuting with H, and contacts protecting the
good sector. Its thermal replacement encoding and drift proof were read.
The error is at most8||L||_1 t Tr(P_bad gamma). Theorem1 does not need
detailed balance; Section8's low-energy/gap simplification has additional
Davies/detailed-balance assumptions. It already has inverse-tail thermal
memory in this semigroup scope; it does not silently imply exact dynamics
under a perturbed H that fails to commute with the logical algebra.

**Balasubramanian–Davydova–Lin**, *A passive self-correcting quantum memory
in three dimensions*, [2605.10943v1](https://arxiv.org/abs/2605.10943v1),
submitted11May2026 17:59:56UTC; one arXiv version verified. Formal construction
and thermal chain: Theorem3.16, decoder witnesses Lemmas5.10–5.12,
Peierls Theorem5.13, lifetime Corollary5.14. Theorem1.2 supplies bounded
density and geometric range; Section2.5 permits O(1)-support Gibbs-stationary
Lindbladian contacts, not necessarily detailed balance. Thermal syndrome
encoding is assumed; passive initialization remains open in Section1.3.
The source notes non-LDPC metachecks and enormous construction constants.
Proof-chain inspection is not a full independent audit of its102pages.
This is a direct priority conflict for an unqualified first3Dpassive claim.

**Ma–Khemani–Sang**, *Circuit-based characterization of finite-temperature
quantum phases and self-correcting quantum memory*,
[2509.15204v3](https://arxiv.org/abs/2509.15204v3); v1 18September2025,
v2 24December2025, v3 16October2026. PRXQuantum7,033052,
DOI10.1103/sh48-wmy4. Theorem1: locally reversible Gibbs transport along
paths satisfying stable clustering, with polylogarithmic circuit range.
Definitions1–2 use annular local-to-possibly-nonlocal correlations in the
interaction algebra, uniformly under local Hamiltonian changes; ordinary
two-point clustering does not suffice. Theorem2 assumes the code-projector
transport and a quasilocal Lindbladian TERM-WISE frustration-free for the
Gibbs state; Theorem3 transfers within such a thermal phase. Low-temperature
stable clustering is not universally proved by its4Dtoric discussion. No
exact interacting-bath import was checked for N1645.

**Bergamaschi–Gheissari–Liu**, [2507.10976v1](https://arxiv.org/abs/2507.10976v1),
submitted15July2025, *Rapid mixing for Gibbs states within a logical sector:
a dynamical view of self-correcting quantum memories*. Theorem1.7/formal7.8
provides ground-to-thermal-sector
preparation under its metacheck, connectedness and local correction
hypotheses (Section5). This starts from a ground code state, not an arbitrary
easy product state. Efficient general block realization is distinct from
Theorem1.8/8.2's4Dtoric specialization. BDL explicitly lacks the LDPC
metachecks needed for direct substitution. No preparation premise is thereby
verified for N1645.

**Rakovszky–Placke–Breuckmann–Khemani**, *Bottlenecks in quantum channels
and finite temperature phases of matter*,
[2412.09598v2](https://arxiv.org/abs/2412.09598v2); v1 12December2024,
v2 16October2026; PRL137,050402, DOI10.1103/y9z2-52rl.
Theorem2/SII.12: a Gibbs-stationary r-local Kraus channel and subspace V
give projected-state drift at most10Delta, with
Delta=||P_(boundary2r V)rho||_1/Tr(P_V rho). SII.14 allows a quasilocal
approximation error f(r). The numerator is off-diagonal operator weight,
not just a classical event probability. SIII.4's perturbation theorem assumes
bounded-incidence commuting projectors, an EXTENSIVE kappa*n barrier,
E_min(V)=epsilon*n with epsilon<kappa/2, finite-body V with ||V||<=g*n,
large beta and small g. Its spectral-localization proof was inspected.
It neither verifies a subextensive3D barrier with arbitrary large bath nor
gives coherent unknown-qubit storage from slow mixing alone. Printed
threshold/inequality direction typos in the HTML should not be inherited;
the proof and explicit exponential bottleneck bound govern the comparison.

**Wildeboer–Iadecola–Williamson**, *Symmetry-protected infinite-temperature
quantum memory from subsystem codes*,
[2110.05710v2](https://arxiv.org/abs/2110.05710v2); v1 12October2021,
v2 14June2022; PRXQuantum3,020330. SectionsIII.A–C give exact Hamiltonian
noiseless subsystems for the stipulated gauge/symmetry-preserving noise,
including arbitrary initial states. SectionsII.F/III.D Eq45 give prethermal
times in a large-field/perturbation ratio under U(1)^K structure, not a
generic fixed-noise size-divergent3D thermal theorem. Exact Hamiltonian
quantum memory as a broad phrase is therefore not new.

**Merkli**, *Dynamics of Open Quantum Systems II, Markovian Approximation*,
[2105.00023v2](https://arxiv.org/abs/2105.00023v2), Quantum6,616(2022),
DOI10.22331/q-2022-01-03-616. Theorem1.1 gives an all-time approximation
error C|lambda|^(1/4) to the Davies semigroup for a finite system and regular
free bosonic reservoir. Its form-factor differentiability/infrared behavior,
golden-rule transitions, simple level-shift spectral hypotheses and product
initialization are substantive. Proposition1.2's constants depend on
temperature/spectral quantities. No n-uniform exponentially long memory
comparison for a generic local spin bath follows. Correlated-initial-state
work2107.02515 is a lead, not a fully checked import here.

**Aharonov–Kitaev–Preskill**, *Fault-tolerant quantum computation with
long-range correlated noise*,
[quant-ph/0510231](https://arxiv.org/abs/quant-ph/0510231): arbitrary bath
Hamiltonian, pair system-bath terms with t0 max_i sum_j||H_ij|| sufficiently
small, allowing summable long-range correlations. It is an active exact-
dynamics threshold with gates, resets and ongoing correction charged.
Terhal–Burkard's earlier local non-Markovian threshold has stronger locality
assumptions on bath coupling. Active fault tolerance is a serious full-cycle
comparator; its controlled operations cannot be silently removed.

**Petz**, *A Variational Expression for the Relative Entropy*, CMP114,
345–349(1988), [author PDF](https://math.bme.hu/~petz/pdf/35variational.pdf),
DOI10.1007/BF01225040. Proposition1/Theorem9 and Corollary5 verify the
relative-entropy variational/Golden–Thompson imports in the inverse-tail and
averaged-writer arguments. Faithful normal states and bounded self-adjoint
tests include the finite Gibbs reference and lambda P_bad. These tools are
old; their newly derived memory application is not a new entropy principle.

Additional exact primary checks: Thorngren2607.20605v1, Theorem1, explicitly
restricts ALL Hamiltonians/perturbations to be diagonal in a classical basis;
it proves perturbatively stable3D Wegner CLASSICAL memory, not a quantum
coherence theorem. Guo2610.35099v1(26October2026) requires local dimension
q=Theta(N) and single-qudit X^+/-1,Z^+/-1 Metropolis increments, charging
that growing-dimension/noise-resource change. Xu–Xu2611.06469v1(4November)
is partial self-correction under specified local Davies dynamics, with a
temperature-dependent useful size window. None is a generic exact-bath
finite-local-dimension theorem imported here. Their primary full texts were
cached; these limited scope readings are not complete proof audits.

## 3. Soryun IV: real primary proof, different mechanism

[Soryun IV](https://zenodo.org/records/23859937), version DOI
10.5281/zenodo.23859937, concept DOI10.5281/zenodo.23859936, public record
created2026-11-01T14:25:39.029742UTC. Metadata creators are Maciej Nowicki
and Artificial Hyperintelligence Eve. The internal IV/version4.0 label does
not establish four earlier public versions: the versions API lists one
record and exact Soryun search returned one record. Broader author search
does not establish earlier SoryunI–III deposits. API JSON and both artifacts
are cached, including actual LaTeX. No missing Astra archive was involved.

The103-page paper's load-bearing Theorem3.3, Lemmas3.1–3.2 and5.1,
Lemma4.1, Theorem4.2, Corollaries4.3–4.4 were read at the source/proof level.
No flaw was found in this central chain. This is a focused proof reading,
not a full103-page audit or priority certification.

Its model is N qubits at known sites in a fixed compact metric domain, a
finite-dimensional but arbitrarily large shared quantum bath, and bounded
integrable time-dependent Hamiltonians

    H_A(t)=I tensor H_B(t)+sum_(j active,a) sigma_j^a tensor B_a,N(x_j,t).

Bath operators can fail to commute across axes, positions and times. Initial
bath state is independent of the unknown logical input. Losses are exogenous,
flagged at readout; endpoint sites have independent erasure probability p,
while removal times may be arbitrary. Extra strong backgrounds must lie in
the declared permutation-invariant cell algebras. The central hypothesis is
ONE integrated OPERATOR-NORM continuity envelope, uniform over N, bath,
field and removal history:

    hbar^-1 integral_0^T sup_(d(x,y)<=h) sum_a
        ||B_a,N(x,t)-B_a,N(y,t)|| dt <= w(h),  w(h)->0.       (S1)

For a partition into C cells, residual budget q=N w(h), and Dyson cutoff s,
the fixed survivor operator module has dimension at most

    mbar = [sum_(k<=s)3^k binomial(N,k)]
               product_cells binomial(occupancy+3,3),
    tau_s(q)=sum_(k>s)q^k/k!.                               (S2)

The cell algebra dimension binomial(n+3,3) follows from Schur–Weyl duality.
Lemma4.1 proves the filtered product rule even when the interaction picture
spreads literal support: collective rotations normalize bounded Pauli
weight, so modules multiply by adding insertion counts. The norm error of
the full joint unitary is at most tau_s, independent of bath dimension.

Lemma3.1 uses an Auerbach basis with operator norm1 and scalar coefficient
functionals norm1. Hahn–Banach plus the trace-dual singular-value expansion
prove ||A_i||<=||G|| for matrix-valued coefficients. Lemma3.2 makes a
canonical erasure-plus-basis channel and proves CP domination by
m²||G||² times that channel. The proof bounds one row operator rather than
summing an extra erased-basis factor; no hidden2^|E| factor occurs there.
The erasure dimension is charged later by Haar decoupling.

Theorem3.3 gives one encoder and one flag-dependent decoder family for the
ENTIRE declared bath/field family, with averaged entanglement infidelity

    e <= Pr(|E|>u)+(1+tau)² mbar² 2^u sqrt[2K(mbar+1)/D]
                    +tau(2+tau).                           (S3)

Here D is the known coding-sector dimension, D=2^N in the primary full-space
application. A positive linear failure functional makes the CP order work
with the SAME decoder and trace-changing truncated maps. Selecting one code
using the canonical channels controls every realization without a union
bound over baths. This is substantive common-recovery machinery, not just a
small Kraus rank for each unknown realization separately.

Choose s=ceil(e²Nw(h)+c log N). If C=o(N), w(h)->0, then log mbar=o(N),
and Theorem4.2/Corollary4.3 retain erasure leading rate(1-2p)+. Zero-field
ordinary erasure capacity gives the converse. This is an entanglement-
transmission/average-infidelity capacity theorem, not a worst-case diamond
claim for each code. General efficient decoding/certification remains open;
Corollary3.4 supplies an efficiently sampled Clifford encoding ensemble.

“Full-space coding” here means that the random encoding isometry is selected
in the entire physical Hilbert space rather than a prescribed inner singlet
sector. Its output is still a code subspace with an independently supplied
bath. It is not a full-rank actual joint-Gibbs overwrite theorem. Turning a
faithful thermal resource into that isometric code requires a separate writer
and entropy/resource accounting; one cannot identify this preparation with
the full-support logical SWAP merely from the phrase full-space.

For w_T(h)<=L0 T h^gamma and domain covering exponent nu, its stated
sufficient horizon is T_N=o(N^(gamma/nu)). This is neither a necessary
lifetime ceiling nor exponential fixed-strength thermal self-correction.
The endpoint erasure probability must stay below1/2, so the theorem does
not overcome a fixed ongoing loss hazard for arbitrary time.

The exact generic-local-bath obstruction is B(x_j)=g Z_j on independent
bath spins: for i!=j, ||B(x_i)-B(x_j)||=2g. In a fixed compact domain with
densifying sites, no uniform vanishing modulus in(S1) exists. If instead
lattice spacing and density stay fixed while volume grows, sufficiently
small cells require C=N, violating the sublinear-cover hypothesis.
Bath correlation decay cannot replace an operator-norm continuity bound.

The constructive finite-temperature hybrid and its precise limits are proved
in `collective_thermal_hybrid.md`: multiplicity-one obstruction to an exact
full-support noiseless qubit; flagged thermal multiplicity selection; a
conditional outer-memory lift paying log(N) energy; and a resonant bath
counterexample to ignoring leakage from noncollective spatial residuals.

The direct PDF has1611824bytes, SHA256
0079ab0d5d70356eb4ba3649841ccf8653f4ef96cb43a7bfcc974d99a24efa91.
The ZIP's embedded PDF has1433127bytes, SHA256
3e295e246fc1042af13e384a02cc9769ccea237a0798dc475eb500ef487faf15.
Both have103pages and identical whitespace-normalized extracted text,
SHA2568f596cdc897e651ede7ecb28e78865e24df00eb759903b250db7fb51d6e93d23.
Byte inequality was therefore not treated as observed mathematical-content
inequality. Full source/artifact hashes are in SOURCE_MANIFEST.json.

Soryun cites Elimelech–Albert–Barg2607.22995 (v1 25July2026, v2 12August,
v3 4October) and universal-recovery2608.28962 (v1 29August, v2 4October).
The latter's latest primary full text was checked: Definition2 requires a
spectral-norm coefficient contraction, Definition3 defines environment
leakage, Theorem4 gives common worst-case recovery. The Petz map's worst-case
bound in Theorem11 additionally uses Definition7's stronger coefficient
control; average-case Petz bounds are separate. Mere approximate span
membership does not grant one universal recovery. These are exact scopes,
not a complete independent audit of both papers or an import into N1645.

## 4. Other recent Zenodo claims: actual files and DOI families

Dates below are live API created times, with the self-reported publication
date distinguished where different. Related titles/author names do not turn
separate concept DOIs into a version chain. Source metadata alone is not a
proof or a claim that every other version in a family has been audited.

| Version DOI suffix; concept suffix | Public created dateUTC | Actual-file finding |
|---|---|---|
| [18858059](https://zenodo.org/records/18858059);18858058 |4March2026 04:58:30 |Limsuwan, *Energy–Entropy Controlled Quantum Stability*,92pages. AppendixX pp88–89 explicitly leaves3D quantum-memory existence as a conditional blueprint. Its dynamics onp8 is Davies/Markov/detailed balance. No matching exact-H3D model was imported. |
| [20379524](https://zenodo.org/records/20379524);20379523 |25May2026 12:58:41 |Aksman, *KAN–DAM Quantum Computing: Algorithm*. Exact metadata read, full file not read; no proof judgment assigned. This is a distinct concept family from its later memory papers. |
| [20778451](https://zenodo.org/records/20778451);20778450 |20June2026 22:07:15; publication date21June |Aksman,8-page *DSM-861 Error Correction Across Scales*. Page2 assumes instantaneous projection/infinite energetic penalty. It cites the MayBDL work. No bounded finite-H local implementation/lifetime proof supplied for that projection model. |
| [21356498](https://zenodo.org/records/21356498);21356497 |14July2026 10:59:13 |Caldin, actual2671-byte text. Internal file date29June is not the public deposit date. Inspected artifact has no scaling Hamiltonian/code/bath/lifetime proof. |
| [23428551](https://zenodo.org/records/23428551);23428550 |17October2026 01:22:16 |Aksman,9-page *Homological Projection*. Equations14–16p3 replace a qubit stabilizer Hamiltonian by a continuous small-angle phase-field approximation and then identify it EXACTLY with the1-chain Hodge Laplacian. Equation22p4 identifies the CSS code Hilbert space with harmonic1-forms. These have incompatible dimensions:2^N1 versus N1, and a3-torus harmonic space has dimension3 whereas its three-qubit ground code has dimension8. The exact equivalence and lifetime conclusion are unsupported. Correct boundary-nilpotency/CSS commutativity does not repair it. |
| [23972523](https://zenodo.org/records/23972523);23972522 |5November2026 07:14:42 |Caldin, actual2680-byte text, internal file date16September. A132Hz self-correcting-memory title does not substitute for absent Hamiltonian/scaling/bath proof in the inspected file. |

Full PDFs/texts were downloaded for the Limsuwan/Aksman memory entries and
both Caldin files. Long multi-topic descriptions produced many false
positives. No dismissal of unread records or broad claim about an author's
entire programme follows from these specific checks.

Search record: exact phrase self-correcting-quantum-memory returned22 records,
and its title-focused variant16; passive-quantum-memory24; thermal-memory54
with all three size25 pages cached; exact-quantum-memory with2026 date range
99 with all four size25 pages cached. Broader self-correcting/stabilizer/
Hamiltonian/disorder searches also yielded many unrelated records; only
their bounded first pages were read, not all their totals. Exact API caches
preserve the queries and returned metadata. Soryun exact-title search and
versions endpoint were checked separately. Some query date filters returned
older records, so each relevant API publication/created time was inspected
rather than inferred from the query. This search is substantive but not
exhaustive historical verification.

## 5. Governing internal-source boundary and strongest route

Read in full after exchange:
`../../sources/N1653-ROOT_NATIVE_THERMAL_MEMORY_JOIN.md`,
`N1653-ROOT_ROBUST_NATIVE_MEMORY_JOIN.md`, and
`N1653-EXACT_PHYSICAL_TIME_JOIN_AUDIT.md`, pinned in the source manifest at
revision78ff1e3a865e3d0a05af901f77eb1ffd128b00d4. The robust root's static
premises concern a native7-level-clock implementation, bounded local spin
bath with bounded onsite reference, weak bath–bath and memory–bath terms in
the perturbation class, a compact nonzero temperature interval, and its
specific signed mixed-source/rod Gibbs estimate. Its exact consumer uses a
fixed full-space system/clock Pauli algebra and enlarged decoder-good set.

The audit's physical-time proof is conditional on that static input, with
actual joint Gibbs and ideal overwrite/readout including clock access.
Bath-only terms drop from the dynamical norm budget but remain restricted
by the static theorem. It therefore does not cover arbitrary strong bath
references merely because the final abstract channel lemma does.

Its explicit old error is6vnT[2p+2sqrt(beta vnp)], with the square-root
Peierls loss. The new entropy/KMS checks recover inverse-p lifetime at those
exact same BOTH-SIDED support and static premises. They preserve static
assumptions, local norm parameters, source exponent and endpoint ideality.
The source-dependent static proof was not independently validated in this
literature task merely by reading the integrated statement and consumer.

For N1645 the original theorem/code/norm/temperature/lifetime remain absent.
Related records cannot be composed into it. The decisive route remains:
verify an actual-system logical algebra, a full interacting Gibbs tail and
bad-supported local commutators, then apply the inverse-tail consumer and
build a writer satisfying a genuinely earned admission condition. A new
noisy full-cycle capability requires that last operation and a matched
resource comparison. It has not been replaced by the entropy admission
lemma, a DOI deposit, or the smooth-field alternative.

Supporting completed proofs are `collective_thermal_hybrid.md` and
`../../followup/machinery_entropy_admission.md`. Status: implication and
obstruction proofs PROVED at their stated finite scopes; applicability to
N1645 UNKNOWN; full static N1653 import NOT INDEPENDENTLY VERIFIED HERE;
generic noisy writer and practical advantage NOT ACHIEVED; historical-first
claims NOT ESTABLISHED.
