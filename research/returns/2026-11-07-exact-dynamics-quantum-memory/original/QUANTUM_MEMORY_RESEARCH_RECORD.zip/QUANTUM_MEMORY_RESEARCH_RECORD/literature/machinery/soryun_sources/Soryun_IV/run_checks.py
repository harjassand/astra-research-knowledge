#!/usr/bin/env python3
"""Run all reproducible finite-dimensional checks from the release package."""
from pathlib import Path
import argparse
import subprocess
import sys


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--no-plot', action='store_true', help='Verify without redrawing figures.')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    jobs = [('verify.py', 'sectors'), ('verify_spatial.py', 'spatial'), ('verify_broad.py', 'broad'), ('verify_nonabelian.py', 'nonabelian')]
    for filename, folder in jobs:
        command = [sys.executable, str(root / 'code' / filename), '--output-dir', str(root / 'results' / folder)]
        if args.no_plot:
            command.append('--no-plot')
        subprocess.run(command, cwd=root, check=True)
    print('All verification programs completed successfully.')


if __name__ == '__main__':
    main()
