#!/usr/bin/env python3
"""Compile the editable manuscript with a local TeX installation."""
from pathlib import Path
import shutil
import subprocess


def main() -> None:
    root = Path(__file__).resolve().parent
    output = root / 'build'
    output.mkdir(exist_ok=True)
    latexmk = shutil.which('latexmk')
    if latexmk:
        subprocess.run([latexmk, '-pdf', '-interaction=nonstopmode', '-halt-on-error',
                        '-outdir=' + str(output), 'Soryun_IV.tex'], cwd=root, check=True)
    else:
        pdflatex = shutil.which('pdflatex')
        if not pdflatex:
            raise SystemExit('Install TeX Live or MiKTeX with pdflatex, then run this script again.')
        for _ in range(3):
            subprocess.run([pdflatex, '-interaction=nonstopmode', '-halt-on-error',
                            '-output-directory=' + str(output), 'Soryun_IV.tex'], cwd=root, check=True)
    print(output / 'Soryun_IV.pdf')


if __name__ == '__main__':
    main()
