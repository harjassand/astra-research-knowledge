# Final focused dossier audit

6 November 2026. Reviewed dossier SHA-256: 49de764886fdfd622f7e0c8755d4c1283dff2a17577ca7509124525ba5d95c45.

Scope: complete central statements/proofs in Sections 2-4, inverse-tail scaling in 2.4, source/model distinctions in Sections 0-1, and concluding status claims. Initial reports were not changed. This review does not independently certify the separate static mixed-gas proof or every predecessor manuscript.

## Scientific adjudication

No substantive mathematical error found in Sections 2-4. Theorem E correctly uses A=sum a_Q, D(Omega||omega)<=beta A p/4, the binary rare-event entropy bound, and reference-safe derivative <=A q_t. The F(K) infimum and F(0)=1 are consistent. Theorem K correctly uses both-sided bad support, [P,Q]=0, the symmetric thermal correlation derivative, 2b<=D, and full-channel Pauli randomization. Its stronger guarantee is for the randomized mean channel, as stated.

The direct arbitrary-resource/CPTP Bell-Weyl theorem is correctly normalized. Its dimension-free operational statement is correctly restricted to the fully randomized protocol and an actual projective Weyl/Pauli group. The C*-bath statement has the correct unital algebra, UCP, GNS continuity and generator-domain hypotheses. Stationarity is required only for the initial-generator reduction, not for the direct correlation bridge.

Both noisy-admission sufficient theorems are valid. The global-domination obstruction is an interface obstruction even for harmless faults. The hot-SWAP example is correctly marked nonlocal. The geometry/sector interfaces remain explicitly unproved for the actual quantum Gibbs writer.

## Inverse-tail claim

The actual upgrade is stated correctly. From p_n<=poly(n)exp(-c n^eta), polynomial A_n and a fixed finite beta window, both central consumers give vanishing error uniformly up to exp((c-epsilon)n^eta) for every fixed epsilon>0, with polynomial slack. This retains the full rare-tail exponential coefficient rather than c/2. It does not change the functional stretched-exponential class, supply a noisy native writer, or establish practical sizes or advantage.

The dossier correctly preserves the existing N1653 Gibbs-SWAP/exact-dynamics capital, distinct native hardware and bath/temperature quantifiers, actual-static/protection dependencies, ideal endpoints, source-hash mismatch, and N1645 unavailable-theorem boundary. Historical novelty remains unestablished.

## Delivery observation

At review time the linked outputs/QUANTUM_MEMORY_RESEARCH_RECORD/followup/auditor_cross_challenge.md was absent. The complete proof exists in the corresponding work/followup file and was checked earlier. Complete record assembly and resolve these supporting links before final delivery. This is a packaging observation, not a gap in the reviewed work proof or central inverse-tail derivation.

Decision: central conditional inverse-tail upgrade PASSES this focused mathematical audit at the exact stated scope. No request for additional broad research or new agents.
