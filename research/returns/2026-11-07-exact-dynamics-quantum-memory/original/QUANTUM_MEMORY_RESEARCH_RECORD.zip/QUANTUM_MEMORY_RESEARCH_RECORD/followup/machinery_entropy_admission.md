# Averaged-writer entropy admission

6 November 2026, derived after exchange. This extends the principal's entropy
admission proof to an arbitrary CPTP writer; it does not construct a noisy
encoder. Finite dimensions and hbar=1 are assumed.

Let the accessible memory contain a specified full-space logical qubit with
system-only Paulis P_a. Let omega=exp(-beta H)/Z be the actual joint Gibbs
state and let Q be a projection. Assume

    A_a=i[H,P_a]=Q A_a Q,  ||A_a||<=a_a,  p=Tr omega Q.

Let Gamma:L->memory+bath be any CPTP writing channel with initial input
independent of its supplied resource, and set sigma=Gamma(I/2). Suppose

    D(sigma||omega)<=K p,
    half||Dec Gamma-id||_diamond<=epsilon_0.                    (1)

Then the logical channel after exact HOLD under H obeys, simultaneously for
all real times,

    half||Dec Ad(exp(-itH)) Gamma-id||_diamond
      <=min(1,epsilon_0+(sum_a a_a)(K+e-1)p|t|).                (2)

Proof. For every input marginal rho_L, positivity gives
Gamma(rho_L)<=2Gamma(I/2)=2sigma. Stationarity preserves
D(U_t sigma U_t†||omega). For any state eta, the variational formula and
Golden–Thompson give

    Tr eta Q <= D(eta||omega)+log Tr exp(log omega+Q)
             <= D(eta||omega)+log[1+(e-1)p].                  (3)

Hence Tr Q U_t sigma U_t†<=(K+e-1)p at all t, and the actual writer's evolved
bad probability is at most twice this. The same bound holds with arbitrary
reference entanglement since it depends only on the logical input marginal.

For a joint reference state at time t, write its decoded L-R state as
`(I/2)tensor rho_R+(1/2)sum_a P_a tensor B_a,R(t)`. Trace-norm duality and
A_a=Q A_a Q imply `||dot B_a,R||_1<=a_a Pr(Q)`: after inserting Q, the joint
state is positive and has trace Pr(Q), while the dual reference test and A_a
have product norm at most a_a. Since ||P_a||_1=2, the decoded derivative has
trace norm at most sum_a a_a Pr(Q). Integrate, divide by2 for half diamond,
and add the initial channel error epsilon_0. This proves(2). Negative times
follow by reversing H. QED.

For the ideal logical swap, sigma=Omega=I/2 tensor omega_G. If additionally
Q commutes with the logical Paulis, convexity and the conjugation energy
identity give `D(Omega||omega)<=(beta p/4)sum_a a_a`, recovering the
principal's inverse-p ideal-access theorem.

This admission condition is less rigid than CP domination by a reversible
encoder. For example, any unital logical channel N followed by ideal gauge
preparation has sigma=Omega, even with a nonzero coherent logical rotation;
its initial logical error is charged as epsilon_0. A channel preserving omega
cannot increase this relative-entropy cost by data processing.

No generic noisy writer has been supplied. The condition concerns its
average JOINT output and requires entropy O(p), with K explicitly charged.
A constant average entropy cost, local-stochastic fault rate or correct
memory marginal does not imply this condition. Fixed-rate distributed
physical faults typically require additional correction/thermal structure.

The primary entropy machinery is Petz(1988), *A Variational Expression for
the Relative Entropy*, CMP114,345–349, Proposition1/Theorem9 and Corollary5
(the variational and generalized Golden–Thompson statements). Its faithful-
normal-state hypotheses hold for the finite Gibbs reference; lambda Q is
bounded self-adjoint. Numbering verified in the author-hosted full PDF:
https://math.bme.hu/~petz/pdf/35variational.pdf ; DOI10.1007/BF01225040.
The inequality and proof above are finite specializations, not a novelty
claim for relative-entropy variational theory.
