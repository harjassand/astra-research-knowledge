# Final focused constructor review of the consolidated dossier

6 November 2026. Reviewed `outputs/QUANTUM_MEMORY_RESEARCH_DOSSIER.md`, sections
2–4 and 9, with the detailed constructor and auditor supporting proofs. This
review precedes the principal's final wording corrections and record bundle.
No initial reports were changed and no new agent or broad search was used.

Reviewed draft: 48,776 bytes; SHA256
`49de764886fdfd622f7e0c8755d4c1283dff2a17577ca7509124525ba5d95c45`.

## Verdict

The entropy consumer E, randomized KMS consumer K, Bell/Weyl theorem B,
arbitrary-writer entropy admission, normalized-sector admission, and the
displayed local-stochastic counting constants are mathematically sound at their
stated hypotheses. The independent-source/N1645 boundary, exact N1653
conditionals, classical randomization cost, and unearned noisy writer/resource
acquisition are retained. No central normalization or hidden bath reset was
found.

Three scope wordings should be corrected before finalization; one optional
scalar-proof clarification is also listed. The principal was notified directly.

## Required wording corrections

1. **Section 4.2, reader-independent hot-sector bound.** The sentence “Every
   accessible reader then has half diamond error approaching 3/4” overstates
   equality. The proved universal statement is

   `liminf_m d_diamond(N_m,id) >= 3/4`.

   Some intentionally poor readers have larger error. Write “every accessible
   reader has error at least `3/4-o(1)`”; the natural partial-trace reader
   attains the limiting `3/4` if an attainment statement is desired. The
   underlying CP/Choi calculation and inaccessible-bath obstruction are sound.

   Also replace “individual fault correctability” in the following paragraph
   with “exact logical neutrality of the gauge faults at release.” The example
   does not demonstrate a physical simultaneous recovery against unknown
   thermal defects.

2. **Section 4.3, fault-cluster interface.** The geometric premise must concern
   the **entire union configuration**: if every connected component of `T∪F`
   has size below `ell`, then the complete configuration is dynamically safe
   and has trivial logical cofactor. It is insufficient to know that each
   component considered separately is correctable; individually correctable
   actions need not compose into a correctable logical action. This was
   explicit in the full constructor proof but is ambiguous in the compressed
   dossier sentence. With the global premise, the union bound

   `delta <= n D^(2(ell-1)) (q+f)^ell`

   is correct. The background and conditional fault-probability hypotheses
   are not imported into the actual quantum Gibbs model.

3. **Section 9.A, positive-F drift certificate.** State `epsilon>=0` and
   `t>=0`. The one-sided inequality `i[H,F]<=epsilon I` proves forward-time
   expectation growth at most `epsilon t`. It does not automatically prove
   the same result for negative times. The error coefficient

   `A/2 * (eta t + epsilon t^2/2)`

   is correct for `t>=0` and initially correct logical input. To claim both
   directions, require the corresponding inequality for `-H` as well. The
   main E/K theorems already have valid arguments for all real times.

## Optional proof clarification

In Section 2.3's scalar inequality, either assume `x>=y` by symmetry before
setting `x/y=e^u`, or use `|tanh(u/4)|<=|u|/4`. The written inequality
`tanh(u/4)<=u/4` is for `u>=0`. The scalar inequality being proved and all KMS
coefficients are correct.

## Normalizations checked

- **Theorem E.** Exact ideal logical reset gives `Omega=I_L/2 tensor omega_G`;
  convexity gives `D(Omega||omega)<=beta A p/4`. Binary data processing yields
  `q_t<=p F(beta A/4)`. The actual input marginal obeys `E(rho)<=2Omega`.
  Reference Pauli expansion contributes the factor `A/2`; the factor two in
  occupation cancels it. Thus deterministic half diamond error is correctly
  `A p |t| F(beta A/4)`.
- **Theorem K.** The thermal sandwich derivative is bounded by `a_Q p`, using
  support on both sides and Schatten Holder. The spectral factor is
  `2 b_Q<=D(Q omega Q||omega)`, not merely `b_Q<=D`. Arithmetic/geometric
  correlation weights differ by at most `b_Q/2`. Hence
  `e_Q(t)<=a_Q p(2|t|+beta)`. The qubit Weyl average is `sum_Q e_Q/4`, giving
  the stated randomized half diamond bound. It applies to the actual averaged
  protocol with retained frame bits.
- **Theorem B.** The Bell compression coefficient is `d^2`, the reference
  trace is normalized by `1/d`, and Bell/Weyl orthogonality leaves the factor
  `d^-2` multiplying the Kraus commutator sum. CP expansion yields
  `2-2 Re omega(W^* Lambda^*(W))`. Complete-channel randomization must use
  the stated Weyl projective group, as the dossier requires.
- **Derivative bound.** For an arbitrary reference the trace-norm Pauli
  coefficient is at most `a_Q Pr_bad`, by inserting the bad projector on
  both sides. No reference-dimension or hidden square-root factor occurs.
- **Entropy admission.** Positivity of the full CPTP writer gives
  `Gamma(rho)<=2Gamma(I/2)` for every logical marginal. Initial decoded
  diamond error is explicitly charged, and the joint average relative-entropy
  promise is not inferred from local error rates.
- **Sector admission.** Failure is a positive linear functional of the
  subnormalized written Choi state; the bad branch trace is bounded by its
  effect norm. Its reference-uniform randomized error is correctly bounded by
  `delta+sum_s w_s kappa_s epsilon_s(t)`.
- **Counterexamples.** CP domination forces exact logical neutrality by
  rank-one Choi support. Product-gauge fault heating gives the exponential
  likelihood-ratio lower bound with fixed local physical strength. The
  operational hot-SWAP example retains the actual interacting Gibbs law and
  conditional maximally mixed bath, while correctly declaring its nonlocal
  threshold interaction. It is not a 3D/N1653 no-go.

## Final scientific accounting

Once the three wording corrections are made, the reviewed sections support the
stated conditional full-rarity-exponent theoretical improvement. They do not
establish a fixed-rate noisy writer, generic interacting resource preparation,
a practical quantum memory, a completed active-QEC advantage, or historical
firstness. Those remain correctly open.
