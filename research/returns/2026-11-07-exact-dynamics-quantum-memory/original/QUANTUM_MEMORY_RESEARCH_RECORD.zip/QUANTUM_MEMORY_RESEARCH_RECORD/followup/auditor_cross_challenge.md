# Hostile cross-challenge: Bell/Weyl, infinite baths, and access rigidity

6 November 2026. Written after initial reports were saved and exchanged. Initial `../initial/auditor.md` remains unchanged, SHA-256 `1f2f7a92c42de0ab51a17dd905c2ffbec8dac938bba21c340cf78b75468b85d1`.

Checked `../initial/principal.md`, `../initial/constructor.md`, and the subsequently exchanged constructor files `bell_weyl_followup.md` and `two_generator_addendum.md`. This is not an audit of N1645's unavailable proof.

## 1. Adjudication and strongest combined implication

Principal P1's Bell compression, normalization, stationary weighted-norm argument, and finite-dimensional conclusion are correct. The constructor's initial qubit thermal-filter identity, weighted Hilbert-Schmidt step, Choi identity, Pauli twirl, and constants are correct at their stated hypotheses. No false lemma was found in these stated versions.

The principal's projection argument applied directly to a joint HOLD channel, then combined with complete-channel Weyl randomization, is stronger and simpler. The constructor independently wrote the same generalization after exchange, and I checked its Kraus expansion. For any fixed correlated resource omega and any joint CPTP HOLD Lambda,

    half||N_tw-id_d||_diamond = 1-F_e(N)
      <= min(1, r_Lambda),
    r_Lambda = d^(-2) sum_W [2-2 Re omega(W^* Lambda^*(W))].

For this direct correlation implication neither Gibbs nor stationarity is needed. It supersedes my initial Gibbs-decoupling-defect bound and makes the constructor's thermal filter unnecessary for the full-basis bridge. Those earlier bounds remain true. The algebraic interface, reset and correlation/fidelity programme are established machinery; this is a source-independent simplification and no new physical access mechanism or historical priority is claimed.

## 2. Complete C*-algebra extension

**Theorem.** Let A be a unital C*-algebra with a specified accessible unital M_d subalgebra. Matrix units identify A with M_d tensor B, where B is the relative commutant. Let omega be any state on A, omega_B its restriction to B, and T:A->A any unital CP map. Define the logical channel by

    N^*(a)=(id_(M_d) tensor omega_B)[T(a tensor 1)].

Let {W_a} be the standard d^2 discrete Weyl projective error group, Tr(W_a^*W_b)=d delta_ab. Define e_a=2-2 Re omega(W_a^*T(W_a)) and r=d^(-2)sum_a e_a. Then complete-channel Weyl randomization obeys

    half||N_tw-id_d||_diamond = 1-F_e(N) <= min(1,r).

This holds for arbitrary entangled references. No density matrix, finite bath, faithful state, normality or invariance is assumed.

**Proof of the factor and writer.** For matrix units e_ij, a -> [e_1i a e_j1] identifies A with matrices over the corner e_11 A e_11; the inverse is [b_ij] -> sum e_i1 b_ij e_1j. The corner identifies with the relative commutant. An external input swaps with the logical M_d through the finite unitary sum e_ij^(input) tensor e_ji^(logical). Tracing the old logical register leaves exactly rho tensor omega_B, including for reference-entangled rho. The resource omega is fixed independently of the input.

**Proof of the inequality.** On M_d^R tensor A put P=Phi_RL tensor 1_B and Xi=tr_R tensor omega, with normalized trace. Matrix-unit multiplication gives

    d^2 Xi(P a P)=(Phi_RL tensor omega_B)(a).

Let (pi,H_Xi,Omega) be the GNS representation of Xi. Apply the following standard dilation to pi composed with id_R tensor T: there are a representation pi' and an isometry V with V^*pi'(a)V=pi[(id_R tensor T)(a)]. To supply the needed construction explicitly, complete the algebraic tensor product (M_d^R tensor A) tensor H_Xi under

    <a tensor xi,b tensor eta>
      =<xi,pi[(id_R tensor T)(a^*b)]eta>.

CP makes the form positive; quotient its null space. Left multiplication gives pi', bounded by ||c|| because c^*c<=||c||^2 I. Set Vxi=1 tensor xi; unitality makes V an isometry. This is precisely the Stinespring construction and requires no Kraus representation or normality.

Write p=pi(P), p'=pi'(P). The encoded Bell state's vector is d p Omega. Its output failure probability is

    1-F_e(N)=d^2||(1-p')VpOmega||^2
       <=d^2||(Vp-p'V)Omega||^2.

Expand the square. It equals d^2 times

    Xi(P)+Xi[(id_R tensor T)(P)]
      -2 Re Xi[P(id_R tensor T)(P)].

The first two terms are d^(-2), by the normalized reference partial trace and unitality. The Bell expansion

    P=d^(-2)sum_a conjugate(W_a)_R tensor W_a

gives Xi[P(id_R tensor T)(P)]=d^(-4)sum_a omega(W_a^*T(W_a)). Thus the displayed squared norm is r.

Each e_a is nonnegative by Kadison's inequality, since

    2I-W^*T(W)-T(W)^*W
      =[W-T(W)]^*[W-T(W)]+I-T(W)^*T(W)>=0.

Finally, Weyl conjugation diagonalizes the normalized logical Choi state in the orthogonal Weyl-Bell basis. Its probabilities sum to one; its identity probability is F_e(N). The resulting mixture of Weyl conjugations has half-diamond error at most its nonidentity probability, and a Bell input attains equality. QED.

This proves the requested infinite-bath version, and even permits any joint UCP map. The logical input/output remains finite-dimensional, so its diamond norm is ordinary. It does not establish a finite-resource preparation of an infinite bath.

**Invariant-state generator corollary.** Suppose alpha_t preserves omega and is strongly continuous in its GNS implementation U_t=exp(itK). Assume pi(W_a)Omega belongs to Dom(K) for every Weyl and put

    q=d^(-2)sum_a ||K pi(W_a)Omega||^2.

Then r(t)=d^(-2)sum_a||[alpha_t(W_a)-W_a]Omega||^2 <=t^2q by |exp(itx)-1|<=|tx| in the spectral theorem. Hence half-diamond error of the randomized protocol is at most min(1,t^2q). In finite dimension q is the principal's d^(-2)sum omega([H,W]^*[H,W]). No global Hamiltonian or full norm-derivation domain is needed in the C* formulation; the stated L2 domain suffices.

## 3. Growing logical dimension and false stronger extensions

There is no dimension factor for the randomized channel even when d grows. One must still prove the full Weyl average, have an exact accessible M_d, and charge its physical access. For d=2^k the tensor-Pauli group uses 2k reliable classical frame bits. The guarantee is for the averaged protocol, not each seed. A merely orthogonal unitary basis supports the Bell expansion but need not support a Bell-diagonal channel twirl; use an actual projective Weyl/Pauli group. Algebraic tests with d=3 do not grant qutrit hardware to a spin-half model.

**Invariance is necessary for reducing initial generator errors to t^2q.** Take two qubits,

    H=I_L tensor X_G+Z_L tensor |1><1|_G,
    omega=(I_L/2) tensor |0><0|_G.

Every omega([H,W]^*[H,W]) vanishes, so q=0, but omega is nonstationary. At t=2pi/sqrt(5), the gauge conditional Hamiltonians X+|1><1| and X-|1><1| evolve to -exp(-it/2)I and -exp(+it/2)I respectively. The reset logical channel is exp(-it Z/2), whose twirled half-diamond error is sin^2(pi/sqrt(5))=0.9727504637. Thus initial rarity without invariance is insufficient. The direct r(t) theorem still holds.

**Two generators are insufficient in an arbitrary stationary correlated state.** The constructor's counterexample is correct: omega=Phi+ on L,G, H=SWAP. X_L Phi+ and Z_L Phi+ are symmetric, giving e_X(t)=e_Z(t)=0 for every t; Y_L Phi+ is antisymmetric, giving e_Y(t)=4sin^2(t). At t=pi/2 the reset channel is completely depolarizing. The Gibbs two-generator addendum has an additional modular hypothesis and does not make this false claim.

**The single non-Hermitian filter identity fails.** For H=diag(0,1,2), beta=1, and cyclic qutrit shift W, direct evaluation gives

    ||[W,sqrt(omega)]||_2^2=0.40669434434381246,
    integral k_beta(s)e_W(s)ds=0.26935446149718967,
    integral k_beta(s)e_(W^*)(s)ds=0.5440342271904357.

The last two average to the first. Pairing adjoints or using a full adjoint-closed basis repairs the identity. The constructor's qubit identity is correct; its followup already records the generalized correction.

## 4. P2 CP domination: valid but rigid

If a finite-dimensional good CP branch A satisfies A<=_CP kappa E_tau, where E_tau(rho)=rho tensor tau_G, then necessarily

    A(rho)=rho tensor sigma_G,
    0<=sigma_G<=kappa tau_G.

Indeed its positive Choi operator is dominated by kappa Phi_RL tensor tau_G, so its support lies in a single Bell factor; it is Phi_RL tensor sigma_G. Choi inversion proves the claim. The good event is exactly logically neutral, and its probability is input-independent. For a TP good+bad decomposition, the bad effect is (1-Tr sigma_G)I.

A nontrivial arbitrarily small coherent logical rotation followed by tau_G has a different one-dimensional Bell support, and has no nonzero good subchannel dominated by E_tau. Its bad probability in such a decomposition must be one. Small diamond error is a separate interface, not a proof of CP domination. This does not invalidate P2, which explicitly keeps the good branch logically neutral.

With full-channel Weyl randomization, P2 improves to half-diamond error <=min(1,kappa r(t)+delta), or <=min(1,kappa t^2q+delta) under invariance. The bad probability contributes linearly. No generic physical noisy-admission construction has thereby been earned.

## 5. Relation to the access obstruction and verification

The swap writer deliberately outputs rho_L tensor omega_B, not input-dependent conditional Gibbs bath states. It therefore obeys the assignment/no-cloning obstruction. Bell compression is only a normalized-Choi calculation, not physical postselection. A bath-supported algebra, a low-energy subspace without a full extension, an uncharged reference copy, or bath-access readout cannot replace the declared interface. All finite-time control and frame errors remain charged.

`../literature/auditor/check_stationary_weyl_bridge.py` checks 180 stationary unitary cases at d=2,3,4,5,7, gauge sizes 1,2,3, and full-rank/pure/rank-two invariant states. It also checks 60 arbitrary-resource nonunitary CPTP cases. Bell and q normalizations, Weyl diagonality, exact randomized error, the direct correlation inequality, and the invariant generator bound all pass; maximum equality residual is below 1.78e-15. Results: `../literature/auditor/stationary_weyl_bridge_checks.json`. These are finite algebra diagnostics, not asymptotic validation.

I read the full primary [Alicki-Fannes 0809.4180v1](https://arxiv.org/html/0809.4180v1). Section 2 already treats an encoded matrix algebra and infinite-volume exact/CP dynamics. Section 3, equations (11)-(14) and its assignment-map remark, already provides logical replacement retaining the syndrome marginal. Its main displayed estimate (23) uses a modular preparation norm. The underlying programme and operations are established. The particular Bell/Weyl simplification has no claimed priority.

Stinespring's original Theorem 1, Proc. AMS 6 (1955), 211-216, has exactly the CP unital-C*-algebra-to-B(H) hypotheses needed above. AMS indexed primary text was available but direct full-PDF retrieval returned 403; the needed construction is supplied explicitly above rather than treating search text as a full-source import check.

N1645 applicability, a noisy native writer basin, efficient interacting-resource preparation, and full-cost advantage remain UNKNOWN/OPEN. The stronger algebraic result earns a clear mathematical interface, not a working memory.
