# Full-exponent Gibbs consumer: focused hostile check

6 November 2026. Post-exchange proof. Initial auditor report remains unchanged.

The cached N1653 consumer ALREADY has actual joint-Gibbs SWAP and reference-safe exact dynamics. The Bell/Weyl bridge is a source-independent simplification, not a new physical access mechanism. Below is a stronger consumer, conditional on the same static inputs.

Assume accessible exact logical Paulis Q, actual omega=exp(-beta H)/Z, SAME-H exact HOLD, P=P_bad with [P,Q]=0, A_Q=i[H,Q]=P A_Q P, ||A_Q||<=a_Q, and p=Tr omega P. Ideal SWAP retains tau_G=Tr_L omega.

**Theorem K.** Full-channel Pauli randomization gives half-diamond error <= min(1, p sum_Q a_Q (2|t|+beta)/4). With a_Q<=2vn this is <=3vn p|t|+(3/2)beta vn p. The stationary generator t^2q bound may also be included in the minimum.

## Complete proof of Theorem K

Fix one Pauli Q. Define C(t)=Tr omega Q Q(t), S(t)=Tr sqrt(omega) Q sqrt(omega) Q(t), b=||[Q,sqrt(omega)]||_2^2=2-2S(0), and e(t)=2-2 Re C(t).

Stationarity gives S'(t)=Tr sqrt(omega) Q(-t) sqrt(omega) A_Q. Both-sided support and Schatten Cauchy-Schwarz imply

    |S'(t)| <= a_Q ||P sqrt(omega) Q(-t) sqrt(omega) P||_1
             <= a_Q ||P sqrt(omega)||_2 ||sqrt(omega)P||_2
             = a_Q p.

No omega/P commutation is assumed. Thus S(0)-Re S(t)<=a_Q p|t|.

The Gibbs conjugation identity gives D(QomegaQ||omega)=beta omega(QHQ-H). Since [P,Q]=0, QHQ-H is also both-sided supported on P and has norm <=a_Q. Therefore D<=beta a_Qp.

In an omega eigenbasis, the paired i<j contributions to b and D are 2(sqrt(p_i)-sqrt(p_j))^2|Q_ij|^2 and (p_i-p_j)(log p_i-log p_j)|Q_ij|^2. Their ratio is 2tanh(x/4)/x<=1/2, x=log(p_i/p_j). Hence 2b<=D<=beta a_Qp.

The same spectral pairing compares arithmetic and geometric Gibbs weights and gives |Re C(t)-S(t)|<=b/2. Consequently

    e(t)<=2[S(0)-Re S(t)]+2b<=a_Qp(2|t|+beta).

The full-channel Bell/Weyl theorem gives half-diamond error equal to entanglement infidelity and at most sum_Q e_Q(t)/4. Substitution proves Theorem K. QED.

This rules out an unavoidable sqrt(p) lifetime loss under these extra exact hypotheses. Full-channel randomization is charged: two reliable frame bits and endpoint Paulis; HOLD is unchanged.

## Independently checked principal entropy theorem

The principal independently supplied a deterministic consumer. I checked each step and its arbitrary-reference coefficient.

**Theorem E.** Let a=max a_Q. Under the same hypotheses the original deterministic channel has half-diamond error <=min(1,3a p |t|(beta a+exp(lambda)-1)/lambda) for every lambda>0. In particular lambda=1 gives 3a p(beta a+e-1)|t|, capped at one, without a frame or beta floor.

**Proof.** Put Omega=I_L/2 tensor tau_G=(1/4)sum_Q QomegaQ. Relative-entropy data processing under discarding a uniform Pauli flag implies D(Omega||omega)<=average_Q D(QomegaQ||omega)<=beta a p. All these flag maps are trace-preserving, not postselection.

Stationarity gives D(U_t Omega U_t*||omega)=D(Omega||omega). Binary measurement {P,I-P} therefore bounds d(q_t||p)<=beta a p, q_t=Tr P U_t Omega U_t*. For p_lambda=p exp(lambda)/(1-p+p exp(lambda)), expanding classical KL yields

    d(q||p)=d(q||p_lambda)+lambda q-log(1-p+p exp(lambda)).

KL nonnegativity and log(1+x)<=x give q_t<=p(beta a+exp(lambda)-1)/lambda uniformly for all time. If p=0, finite-beta full rank forces P=0 and the result is trivial.

For every unknown input marginal rho_L, rho_L tensor tau_G<=2Omega. Positivity of exact evolution thus gives actual bad probability p_bad(t)<=2q_t. For arbitrary reference input, z_Q=Tr_system[(Q tensor I_R)rho(t)] has derivative with A_Q. Trace-norm duality and -aP tensor I_R<=A_Q tensor B_R<=aP tensor I_R for every Hermitian ||B_R||<=1 imply ||z'_Q||_1<=a p_bad(t).

The qubit Pauli expansion then gives half||rho'_LR||_1<=(3/2)a p_bad(t)<=3a q_t. Integrate from the exactly correct decoded state at t=0 and take the reference supremum. QED.

Theorems K and E both retain the full p exponent; E has a larger polynomial norm coefficient but no random frame. This independently verifies the principal's construction, rather than attributing it to this auditor.

## Import, validation, and exact status

Theorem E uses relative-entropy data processing. Verified complete primary source: Mueller-Hermes and Reeb, arXiv:1512.06117v2 (26 September 2016), Theorem 1, https://arxiv.org/html/1512.06117v2 ; published DOI 10.1007/s00023-017-0550-9. Exact hypotheses: positive trace-preserving linear map between trace-class operators on separable Hilbert spaces, positive trace-class inputs. Here finite-dimensional normalized states and CPTP flag-trace/binary-measurement maps meet all conditions; omega is full rank. No trace-decreasing entropy assertion is used. CP-special-case credit belongs to Lindblad 1975, DOI 10.1007/BF01609396. The full original Lindblad paper was not acquired, so no theorem number from it is invented. Cached modern primary HTML SHA-256: 8499f0db0f5fe763302d46682555670e5ce4bcd738f218d5e68801e36eb76b91.

Current N1653 root SHA-256 is 5aa2c40543e2d305e6a26f9a9ef18eb3705d637e532dbd83ffb7606408e84660; exact audit is ebc7327fb39390dc8989d0a3c5f3e3755a60823076a88e286a56bc778525e626. Historical audit names audited root d833625e..., different from current bytes. This followup checks current consumer premises independently; it does not extend the historical receipt or redo the separate static proof.

For p_n<=poly(n)exp(-c n^eta), polynomial a_n, and fixed finite beta window, both theorems give vanishing error up to exp(c' n^eta) for every c'<c with polynomial slack. The old Pinsker consumer used c'<c/2. This changes the exponential coefficient, not the functional class or practical hardware capability.

The script ../literature/auditor/check_bad_sector_linear_bound.py and output bad_sector_linear_bound_checks.json test 405 structured Gibbs instances. All support, entropy, skew, symmetric derivative, spectral comparison, channel, and uniform entropy probability inequalities pass. Minimum p is 6.71e-37; largest numerical violation is 6.67e-16. Proofs, not these finite diagnostics, establish the implications.

Both conditional consumer implications are PROVED under the exact premises. Actual-Gibbs static rarity/protection remain separate dependencies. Ideal resource preparation, clock access, coherent overwrite/readout, native qubit/seven-level hardware, local perturbation class, finite-temperature window, and prohibitive constants are unchanged. No N1645 reproof, noisy writer construction, practical advantage, or historical priority is claimed. Finite-bath uniformity requires uniform p and a; infinite thermal limits need their own hypotheses. The separate C* Bell/Weyl theorem has its own infinite-bath scope.
