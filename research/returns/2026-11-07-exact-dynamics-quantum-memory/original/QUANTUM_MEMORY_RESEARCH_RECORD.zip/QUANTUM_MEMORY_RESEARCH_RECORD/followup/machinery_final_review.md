# Final focused machinery review

Reviewed: outputs/QUANTUM_MEMORY_RESEARCH_DOSSIER.md, sections1 and5–8,
6November2026. Compared against the already acquired primary sources and
saved machinery record. No new research or changes to initials. Verdict:
priority and model separation are sound; make the following substantive
scope/assumption corrections before finalizing.

## 1. Make the cell support of F_b explicit (Section5.2, line484)

The Gibbs-odds proof and exact noiseless-success claim require F_b supported
only on cell b tensor bath, collective on that cell; H_B must be bath-only.
The norm sum J is for H_int terms incident to b. The displayed conditions
that all terms preserve flags, F_b P_b=0 and ||F_b||<=M do not by themselves
imply that support.

For example, with two cells and no bath, F_1=M Q_1 tensor Z_2^(0), where
Z_2^(0) is a nontrivial Pauli on cell2's singlet space extended by zero,
preserves every flag and annihilates P_1, with normM. On a bad1/good2 sector
it rotates the supposedly protected selected singlet qubit in cell2. It
also makes removing only F_b fail to leave an identity on cellb in the
partition-function argument. This example is excluded by the intended
cell-plus-bath support, which the saved full proof states.

Concrete insertion: “Here H_B acts only on the bath, each F_b acts only on
cell b and the bath and is collective on cell b, and J bounds the sum of
norms of H_int terms incident to any cell.”

## 2. Charge the correct rank ratio for clock/qudit lifts (lines497–503)

The factor7 and penalty log(7N/delta) are correct for a rank2 chosen sector
inside four spins, whose ambient dimension is16. The adjacent statement
extending the same lift to fixed-dimensional outer clocks needs its changed
rank ratio stated. For a selected rank-d_b sector in n_b physical spins,

    R=max_b (2^(n_b)-d_b)/d_b,
    Delta>=M+2J+beta^-1 log(RN/delta).

For a seven-level clock represented by a rank7 subspace of the eight-spin
singlet multiplicity, R=249/7, not7. This is still a fixed constant and
does not alter the logarithmic energy cost or the qualitative conclusion;
it does alter the explicit sufficient inequality. State the displayed7
formula as the qubit case and give the R replacement for the extension.

## 3. State Soryun's performance criterion (Section7.1, line534)

Its capacity guarantee is entanglement transmission / averaged entanglement
infidelity, rather than a worst-case diamond guarantee for each selected
code. Because this dossier otherwise uses half-diamond error, that distinction
should be explicit in the summary, not only in the linked import ledger.

Suggested addition: “The rate is certified in the entanglement-transmission
and average-infidelity sense; it is not the present per-channel worst-case
diamond criterion. Joint Hamiltonians are finite-dimensional, bounded and
integrable, and erasure flags are exogenous and independent of the input.”

The existing summary correctly preserves the uniform integrated operator-
norm spatial envelope, compact domain, distinct initial preparation,
generic-local-bath obstruction and open decoder-efficiency problem.

## Findings requiring no correction

Section1 correctly retains N1645 as visible-only, distinguishes the related
models, credits preexisting N1653 access and physical-time machinery, and
does not reassign a historical audit to changed root bytes. The missing
static proof was not promoted by checking its consumer.

Section6's theorem/source versions and failed applicability operations match
the saved record. Inverse-rarity Lindbladian memory is credited to Chesi;
BDL prevents an unqualified first3Dmemory claim; Alicki–Fannes prevents a
new logical-overwrite/correlation-framework claim. The new full-exponent
consumer is accurately described as this round's conditional quantitative
upgrade, with historical firstness unestablished.

Section7 correctly distinguishes version/concept DOI, record creation date,
publication field and internal manuscript dates. The Soryun version endpoint
does not establish earlier publicI–III deposits; other actual-file judgments
are bounded to the inspected artifacts. No source-family amalgamation or
exhaustive historical-absence claim was found. Section8 preserves the
conditional mathematical statuses and unearned noisy/practical capabilities.
