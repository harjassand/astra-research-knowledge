Fixed case A, first frontier turn, 7 November 2026 Brisbane.

FULL ENDPOINT UNRESOLVED. Read RESEARCH_REPORT.txt for the actual results and costs.
The negative result concerns ordinary whole-history field-reweighting estimators.
The positive reference is deterministic but exponential in n.

Run python3 case_a_reference.py to reproduce EXACT_AUDIT.json using the standard library.
The 3x3 audit is outside the governing growing-volume promise; no random trajectories or physical experiments were run.
The rational early-envelope formula retains all original source hypotheses and was not executed on a growing source-valid instance.

FROZEN_ENDPOINT.json is unchanged. Accepted predecessors and all access/transfer holds remain.
No peer scientific answer, new worker, or next diagnostic stage is supplied or initiated by this package.
