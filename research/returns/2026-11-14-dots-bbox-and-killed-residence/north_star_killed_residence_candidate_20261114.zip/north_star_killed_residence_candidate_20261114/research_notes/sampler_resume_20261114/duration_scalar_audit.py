from fractions import Fraction as F
from math import factorial,log
from pathlib import Path
import json
n=2560000
# Exact inequalities use e>27/10 and e<11/4, each established by a finite sum and tail.
elo=sum(F(1,factorial(j))for j in range(5));ehi=elo+F(1,factorial(5))/(1-F(1,6));assert elo>F(27,10)and ehi<F(11,4)
record_length=20*n**5;assert record_length<F(27,10)**80
assert 16*n**3<10*n**4 and 4*n**2<10*n**4
assert sum(F(8)**j/F(factorial(j))for j in range(50))>2980
cylinder=16+F(1280001,2980);assert cylinder<446
# ln(1+exp(15.96))<17 since exp(1.04)>2 and exp(15.96)>1.
assert 1+F(26,25)>2
# ln(1+exp(-.04))<ln2<1 (bootstrap additions); deletion uses separate944 certificate.
phase=dict(erosion=944,bootstrap=878+32+1+80+1,prewrap=191+16+17+80+1,cylinder=446+80+17+80+1)
assert max(phase.values())==992
# Four phase sums <4 exp992 <exp994 <exp1000, from exp2>1+2+2>4.
assert 1+2+F(2**2,2)>4
assert F(11,4)**1000<10**446
# Killed mean prefactor: ln2<.7 via exp(.7)>2; then .5(ln2+16.02)<8.36.
assert sum(F(7,10)**j/F(factorial(j))for j in range(20))>2
assert 1+F(836,100)*n<22000000
momentfiles=list(Path('flow_resume_recovery/unpacked').glob('*/dependencies/global_cut_corrected/01_global_cut/cert_r200/moment_*.txt'))+[Path('research_notes/flow_resume_20261114/moment_765151_750000.txt')]
exponents=[]
for p in momentfiles:
 for line in p.read_text().splitlines():
  if line and not line.startswith('#'):exponents.append(int(line.split()[2]))
assert min(exponents)>=0
out=dict(scope='Independent exact rational phase/rate/record audit, CONDITIONAL on globalpath injection and quoted local entropy bounds',native_clock='Per-site heatbath q=1/(1+exp(deltaE)); no discrete-time1/n factor',common_records_times_length=str(record_length),common_log_diagnostic=log(record_length),common_log_strictly_less_than=80,phase_log_upper=phase,total_log_strictly_less_than=994,conservative_log_congestion_claim=1000,exp1000_strictly_less_than_10pow446=True,killed_mean_multiplier=22000000,cylinder_log_bound=str(cylinder),moment_exponents_nonnegative=[min(exponents),max(exponents)],phase_overlap='Sum fourphase loads. Same undirectededge maycarrydeletion andaddition loads; no disjointnessassumption.',still_required=['Globaldeterministicpathandrecordinjection','Rawouterface applicability toK878','Allmarked/unmarked gases and fullperimetertails','Firstmajoritystopping and finalseamcomparison'])
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
