from pathlib import Path
import sys,json,time
b=Path(__file__).parent;sys.path.insert(0,str(b.parent/'source_reconstructed_20261114'))
from filled_trace import boundary_cycles
D4=[(1,0),(0,1),(-1,0),(0,-1)];D8=[(x,y)for x in[-1,0,1]for y in[-1,0,1]if x or y]
def connected(S):
 seen={min(S)};todo=list(seen)
 while todo:
  x,y=todo.pop()
  for dx,dy in D8:
   z=x+dx,y+dy
   if z in S and z not in seen:seen.add(z);todo.append(z)
 return seen==S
def hull(S):
 a=min(x for x,y in S)-1;bb=max(x for x,y in S)+1;c=min(y for x,y in S)-1;d=max(y for x,y in S)+1;outside={(a,c)};todo=list(outside)
 while todo:
  x,y=todo.pop()
  for dx,dy in D4:
   z=x+dx,y+dy
   if a<=z[0]<=bb and c<=z[1]<=d and z not in S and z not in outside:outside.add(z);todo.append(z)
 return frozenset((x,y)for x in range(a+1,bb)for y in range(c+1,d)if(x,y)not in outside)
def resolution(S):return lambda x,y:((x,y)in S and(x+1,y+1)in S)or not((x+1,y)in S and(x,y+1)in S)
start=time.perf_counter();seen=set();words={};touch=0;polymers=0
for mask in range(1,1<<12):
 S={(i%4,i//4)for i in range(12)if mask>>i&1}
 if not connected(S):continue
 polymers+=1;H=hull(S);ox=min(x for x,y in H);oy=min(y for x,y in H);H=frozenset((x-ox,y-oy)for x,y in H)
 if H in seen:continue
 seen.add(H);cycles=boundary_cycles(set(H),resolution(H));assert len(cycles)==1;cycle=cycles[0];dirs=tuple(x[2]for x in cycle);P=len(dirs);assert len(set(cycle))==P;assert all(dirs[(i+1)%P]!=(dirs[i]+2)%4 for i in range(P));area2=sum(x*(y+D4[d][1])-y*(x+D4[d][0])for x,y,d in cycle);assert area2==2*len(H)
 rotations={dirs[i:]+dirs[:i]for i in range(P)};assert len(rotations)==P
 touch+=len({e[:2]for e in cycle})<P
 for word in rotations:
  if word in words:assert words[word]==H
  words[word]=H
out=dict(scope='Rawgeometricouterface encoding audit, countsbroader8-connected closed-cellunions toincludeoriginalaugmentedclass',connected_inputs=polymers,distinct_anchored_filled_hulls=len(seen),touching_hulls=touch,rooted_words=len(words),all_nonbacktracking=True,all_P_rotations_distinct=True,anchored_word_injection=True,signed_area_exact=True,seconds=time.perf_counter()-start,not_proof='Finite evidence supplements general edge-no-bridge/rootperiod argument, not allR200 reconstruction.')
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
