"""Exact integer finite tests of wired completion and row-prefix energy inequalities."""
import json,time
st=time.time();N=4;coords=[(x,y)for y in range(N)for x in range(N)]
neigh=lambda x,y:[(x+1,y),(x-1,y),(x,y+1),(x,y-1),(x+1,y+1),(x-1,y-1)]
def connected(S):
 seen={next(iter(S))};stack=list(seen)
 while stack:
  x,y=stack.pop()
  for v in neigh(x,y):
   if v in S and v not in seen:seen.add(v);stack.append(v)
 return len(seen)==len(S)
def en(S):return 200*sum((x+dx,y+dy)not in S for x,y in S for dx,dy in[(1,0),(-1,0),(0,1),(0,-1)])-len(S)
components=edges=0;maxgap=0
for mask in range(1,1<<(N*N)):
 C={coords[i]for i in range(N*N)if mask>>i&1}
 if not connected(C):continue
 components+=1;R=set(C);xmin=min(x for x,y in C);xmax=max(x for x,y in C)
 for gate in sorted(C,key=lambda v:(-v[1],v[0])):
  x,y=gate;U={z for z in C if z[1]>y};D={z for z in C if z[1]==y and z[0]<x};wire={(i,y)for i in range(xmin,xmax+1)}
  assert C==R|D|U and not R&D and not R&U
  assert connected(U|wire)
  assert en(C)-en(R|D)>=en(U|wire)-en(wire)
  runs=sum((z[0]-1,y)not in D for z in D);delta=int((x-1,y)in D)
  assert en(R|D)-en(R)>=400*runs-len(D)-400*delta
  k=sum((x+dx,y+dy)in R for dx,dy in[(1,0),(-1,0),(0,1),(0,-1)])
  assert k<=2
  edges+=1;R.remove(gate)
out=dict(box=N,augmented_components=components,erosion_edges=edges,exact_integer_wire_energy=True,wire_connectivity=True,row_run_energy=True,all_deletion_k_le_2=True,runtime=time.time()-st,scope='Finite test of reconstruction inequalities, not enumeration of R200 thermal preimages.')
open('research_notes/flow_resume_20261114/erosion_wire_check.json','w').write(json.dumps(out,indent=2));print(out)
