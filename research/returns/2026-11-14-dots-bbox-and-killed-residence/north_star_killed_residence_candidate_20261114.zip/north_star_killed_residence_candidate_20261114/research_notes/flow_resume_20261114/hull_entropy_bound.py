"""Uniform bbox-relative filled-domain magnetic envelope, inherited contour interface."""
from pathlib import Path
from decimal import Decimal as D,localcontext,ROUND_CEILING,ROUND_FLOOR,getcontext
from fractions import Fraction as F
import json,time
st=time.time();getcontext().prec=70;getcontext().rounding=ROUND_CEILING
root=next(Path('flow_resume_recovery/unpacked').glob('*/dependencies/global_cut_corrected/01_global_cut/cert_r200'))
def df(x,up=True):
 x=F(x)
 with localcontext()as c:c.rounding=ROUND_CEILING if up else ROUND_FLOOR;return D(x.numerator)/D(x.denominator)
def loglo(x):return df(x,False).ln().next_minus()
def loghi(x):return df(x).ln().next_plus()
def hf(s):
 a,e=s.split('p');u,v=(a.removeprefix('0x').split('.')+[''])[:2];return F(int(u+v,16),16**len(v))*F(2)**int(e)
inputs=[]
for p in sorted(root.glob('moment_*.txt'))+[Path(__file__).parent/'moment_765151_750000.txt']:
 a,b=map(int,p.stem.split('_')[1:]);logs={}
 for line in p.read_text().splitlines():
  if line and not line.startswith('#'):
   P,h,e=line.split();logs[int(P)]=loghi(hf(h))+D(int(e))*loghi(2)
 inputs.append((F(a,b),logs,loglo(F(a,b))))
log3=loghi(3);log4=loghi(4);logsP={P:loglo(P)for P in range(4,1901,2)}
items=[]
for s in range(2,801):
 # Largest allowed aspect imbalance minimizes WH and maximizes every envelope term.
 area=s-1 if s<=401 else 400*(s-400)
 vals=[];choices={}
 for P in range(2*s,1901,2):
  opts=[(log4+(P-1)*log3,'1')]
  for r,z,lr in inputs:
   with localcontext()as c:c.rounding=ROUND_FLOOR;sub=2*area*lr
   opts.append((z[P]-sub,str(r)))
  v,r=min(opts);vals.append(v-logsP[P]+16*s-8*P);choices[r]=choices.get(r,0)+1
 with localcontext()as c:
  c.rounding=ROUND_FLOOR;tailden=1-(log3-8).exp().next_plus()
 tail=16*s+loghi(F(4,3))+1901*(log3-8)-tailden.ln().next_minus()
 top=max(vals+[tail]);upper=top+sum((x-top).exp().next_plus()for x in vals+[tail]).ln().next_plus()
 items.append(dict(semiperimeter=s,min_area=area,log_upper=str(upper),tilt_counts=choices))
worst=max(items,key=lambda x:D(x['log_upper']))
out=dict(scope='Filled embedded domains only via inherited magnetic-word interface. Not yet arbitrary spin-shape holes nor path congestion. Uniform widths/heights<=400.',worst=worst,all=items,runtime=time.time()-st)
Path('research_notes/flow_resume_20261114/hull_entropy_bound.json').write_text(json.dumps(out,indent=2));print(worst,'runtime',time.time()-st)
