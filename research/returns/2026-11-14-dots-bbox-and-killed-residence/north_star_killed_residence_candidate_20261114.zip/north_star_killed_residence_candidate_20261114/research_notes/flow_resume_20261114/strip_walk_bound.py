"""Directed confined magnetic WALK resolvent; no y-closure or simplicity assumed."""
from decimal import Decimal as D,localcontext,ROUND_CEILING,ROUND_FLOOR,getcontext
from fractions import Fraction as F
from old_scalar import exp_bounds
import json,time
st=time.time();getcontext().prec=80;getcontext().rounding=ROUND_CEILING
Pcut=12000;n=1600**2;em8=exp_bounds(-8)[1]
def upper(W,lam):
 ld=D(lam.numerator)/D(lam.denominator);b=ld*em8;bb=b*b;p=[]
 for i in range(W+1):
  eu=exp_bounds(F(-8)+F(2*i-W,50))[1];ed=exp_bounds(F(-8)-F(2*i-W,50))[1]
  off=ld*(eu+ed)
  correction=bb/p[-1]if p else D(0)
  with localcontext()as c:c.rounding=ROUND_FLOOR;pv=1-off-correction
  assert pv>0,(W,i,pv);p.append(pv)
 with localcontext()as c:
  c.rounding=ROUND_FLOOR
  logden=p[-1].ln().next_minus()+2*sum((z.ln().next_minus()for z in p[:-1]),D(0))
  logdiscount=Pcut*ld.ln().next_minus()
 log=2*W*b.ln().next_plus()-logden-logdiscount
 return log,min(p),p[-1]
rows=[]
for W in range(1,401):
 lam=F(9999,10000)if W==400 else F(1)
 z,m,last=upper(W,lam);rows.append(dict(width=W,lambda_exact=str(lam),log_rooted_spanning_mass_upper=str(z),minimum_pivot_lower=str(m),last_pivot_lower=str(last)))
logratio=(4*em8).ln().next_plus()
with localcontext()as c:
 c.rounding=ROUND_FLOOR
 tailden=1-4*em8
logtail=D(25600)+(Pcut+1)*logratio-tailden.ln().next_minus()
low=D(rows[-1]['log_rooted_spanning_mass_upper'])
combined=max(low,logtail)+((low-max(low,logtail)).exp().next_plus()+(logtail-max(low,logtail)).exp().next_plus()).ln().next_plus()
marked=combined+6400
Gamma=n*(sum((D(r['log_rooted_spanning_mass_upper']).exp().next_plus()for r in rows),D(0))+logtail.exp().next_plus())
r=4*em8
with localcontext()as c:c.rounding=ROUND_FLOOR;holesden=1-r
holes=D(n)*r**4/holesden
out=dict(perimeter_cutoff=Pcut,n=n,critical_width=400,log_marked_mass_relative_exp_minus_6400=str(marked),log_marked_mass_with_vertical_root_record=str(marked+D(1601).ln().next_plus()),log_uniform_high_perimeter_tail_per_root=str(logtail),unmarked_outer_loop_gas_log_upper=str(Gamma),all_hole_loop_gas_log_upper=str(holes),all=rows,runtime=time.time()-st,scope='Positive confined magnetic walk envelope. Shape/topology injection and path reconstruction must be stated separately. Discounted low-perimeter sector plus explicit arbitrary-perimeter tail using area≤640000; uniform for contractible filled domains inside400×1600.')
open('research_notes/flow_resume_20261114/strip_walk_bound.json','w').write(json.dumps(out,indent=2));print({k:v for k,v in out.items()if k!='all'})
