from seed_transition import *
I=np.eye(d);out=[]
for b in [0,.1,.2,.3,.4,.5,.6,.8,1.,1.5,2.,3.]:
 q,P,H,r,h=matrices(b);rho=float(max(abs(eigvals(H))));cost=float(mu@solve(I-P,np.ones(d)));qp=float(mu@solve(I-P,r))
 second=float(mu@solve(I-H,h)) if rho<1 else None
 out.append({'bias':b,'rho':rho,'proposal_success':qp,'mean_events':cost,'second_success_moment':second,'second_moment_times_cost':second*cost if second else None})
print(json.dumps(out,indent=2))
