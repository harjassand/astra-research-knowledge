"""Exact positive dyadic heuristic guide; not a flux or committor certificate.
Only initial logweight DESIGN uses floats. The resulting dyadic guide and range
operations are exact integers. No global floor; no full kinetic simulation.
"""
import math,time,json,random,sys
import numpy as np
from coarse_count_guide import area_upper_inputs

def norm(x):
 m,e=x
 if not m:return (0,0)
 z=(abs(m)&-abs(m)).bit_length()-1
 return (m>>z,e+z)
def add(x,y):
 if not x[0]:return y
 if not y[0]:return x
 e=min(x[1],y[1]);return norm(((x[0]<<(x[1]-e))+(y[0]<<(y[1]-e)),e))
def sub(x,y):return add(x,(-y[0],y[1]))
def logval(x):
 assert x[0]>0
 return math.log(x[0])+x[1]*math.log(2)

class DyadicGuide:
 def __init__(self,mantissas,exponents,block=256):
  self.m=np.asarray(mantissas,dtype=np.int64);self.e=np.asarray(exponents,dtype=np.int32)
  assert len(self.m)==len(self.e) and np.all(self.m>0)
  self.n=len(self.m);self.block=block;self.prefix=[];self.bexp=[];totals=[]
  for start in range(0,self.n,block):
   stop=min(start+block,self.n);e=int(self.e[start:stop].min());p=[0];s=0
   for i in range(start,stop):s+=int(self.m[i])<<(int(self.e[i])-e);p.append(s)
   self.prefix.append(p);self.bexp.append(e);totals.append(norm((s,e)))
  self.size=1<<(len(totals)-1).bit_length();self.tree=[(0,0)]*(2*self.size)
  self.tree[self.size:self.size+len(totals)]=totals
  for j in range(self.size-1,0,-1):self.tree[j]=add(self.tree[2*j],self.tree[2*j+1])
 def weight(self,i):
  assert 0<=i<self.n
  return (int(self.m[i]),int(self.e[i]))
 def gap(self,l,u):
  assert 0<=l<=u<=self.n
  if l==u:return (0,0)
  b=self.block;lb=l//b;ub=(u-1)//b
  if lb==ub:return norm((self.prefix[lb][u-lb*b]-self.prefix[lb][l-lb*b],self.bexp[lb]))
  ans=add(norm((self.prefix[lb][-1]-self.prefix[lb][l-lb*b],self.bexp[lb])),norm((self.prefix[ub][u-ub*b],self.bexp[ub])))
  left=lb+1+self.size;right=ub+self.size
  while left<right:
   if left&1:ans=add(ans,self.tree[left]);left+=1
   if right&1:right-=1;ans=add(ans,self.tree[right])
   left//=2;right//=2
  return ans
 def update(self,h,l,u,dl,du):
  """Exact hot-loop next gap; each endpoint moves at most one, or stays."""
  assert dl in (-1,0,1) and du in (-1,0,1)
  assert 0<=l+dl<=u+du<=self.n
  if dl==1:h=sub(h,self.weight(l))
  if dl==-1:h=add(h,self.weight(l-1))
  if du==1:h=add(h,self.weight(u))
  if du==-1:h=sub(h,self.weight(u-1))
  assert h[0]>=0
  return norm(h)

def build(target=1280000,bits=24):
 rows=area_upper_inputs();grid=np.array([x['area_cap'] for x in rows],float)
 values=-np.array([x['log_area_cut_envelope'] for x in rows],float)
 a=np.arange(target,dtype=float)+.5;w=np.interp(a,grid,values)
 def free(x):return 32*np.sqrt(x)-.04*x
 left=a<grid[0];right=a>grid[-1]
 w[left]=values[0]+free(a[left])-free(grid[0]);w[right]=values[-1]+free(a[right])-free(grid[-1])
 w-=w.max();powers=np.floor(w/math.log(2)).astype(np.int32)
 m=np.rint(np.exp(w-powers*math.log(2))*(1<<(bits-1))).astype(np.int64)
 guide=DyadicGuide(m,powers-(bits-1))
 return guide,{'target':target,'mantissa_bits':bits,'min_log_increment':float(w.min()),'max_log_increment':float(w.max()),'inputs':rows,'scope':'Unfloored exact dyadic HEURISTIC design. Area envelope is not level flux; extrapolated free energy is unvalidated. No variance or native-runtime guarantee.'}

def test_small():
 from fractions import Fraction as F
 r=random.Random(17)
 for n in [1,3,17,65]:
  m=[r.randrange(1,256) for _ in range(n)];e=[r.randrange(-200,10) for _ in range(n)]
  g=DyadicGuide(m,e,8);v=[F(x)*F(2)**y for x,y in zip(m,e)]
  for l in range(n+1):
   for u in range(l,n+1):
    h=g.gap(l,u);assert F(h[0])*F(2)**h[1]==sum(v[l:u],F(0))
    for dl in [-1,0,1]:
     for du in [-1,0,1]:
      if 0<=l+dl<=u+du<=n:assert g.update(h,l,u,dl,du)==g.gap(l+dl,u+du)
 return True
if __name__=='__main__':
 test_small();t=time.time();g,out=build();out['build_seconds']=time.time()-t
 out['memory_bytes_estimate']=g.m.nbytes+g.e.nbytes+sum(sys.getsizeof(p)+sum(sys.getsizeof(x) for x in p) for p in g.prefix)+sum(sys.getsizeof(x)+sys.getsizeof(x[0])+sys.getsizeof(x[1]) for x in g.tree)
 out['examples']=[{'lower':l,'upper':u,'log_gap':logval(g.gap(l,u))} for l,u in [(0,1),(153516,153517),(158000,158001),(1279999,1280000),(0,1280000)]]
 r=random.Random(18);t=time.time()
 for _ in range(10000):
  l=r.randrange(g.n-1000);u=l+r.randrange(1,1000);h=g.gap(l,u)
  assert g.update(h,l,u,1,1)==g.gap(l+1,u+1)
 out['10000_range_and_update_checks_seconds']=time.time()-t;out['small_exhaustive_tests']=True
 print(json.dumps(out,indent=2))
