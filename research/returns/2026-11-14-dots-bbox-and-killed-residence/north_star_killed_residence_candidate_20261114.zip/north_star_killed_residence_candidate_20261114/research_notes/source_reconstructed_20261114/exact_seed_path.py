"""Exact random-bit event decisions for 3x3 seed diagnostic.
Likelihood enclosure is optional: exp inequalities and rational arithmetic.
"""
from source import F,Uniform,expneg_bounds,exp_bernoulli,secrets,lru_cache
from seed_transition import D,idx,sp,neighbors,A,seed,L,n
from collections import Counter
TH=F(6,5);FIELD=F(6,25);K=F(1,20);RATE=n+K
@lru_cache(maxsize=512)
def logistic_bounds(d,bits=128):
 lo,hi=expneg_bounds(abs(d),bits)
 lo,hi=lo/(1+lo),hi/(1+hi)
 return (lo,hi) if d>=0 else (1-hi,1-lo)
def logistic_coin(d):
 u=Uniform();bits=96
 while True:
  lo,hi=logistic_bounds(d,bits);u.refine();ul,uh=u.bounds()
  if uh<=lo:return True
  if ul>=hi:return False
  bits+=32

def rate_delta(j,i):
 return 2*int(sp[j,i])*(TH*sum(int(sp[j,k]) for k in neighbors[i])+FIELD)

def acquire_seed():
 pool=[j for j in range(len(D)) if seed[j]]
 while True:
  j=pool[secrets.randbelow(len(pool))]
  if exp_bernoulli(F(228,25)*(D[j].bit_count()-1)):return j

def draw(bias=F(2,5)):
 j=acquire_seed();counts=Counter();steps=0
 while True:
  steps+=1;u=secrets.randbelow(20*n+1)
  if u==20*n:
   if A[j]:return False,steps,counts
   continue
  i=u//20;d=rate_delta(j,i);qdelta=d+2*bias*int(sp[j,i]);flip=logistic_coin(qdelta)
  counts[(d,qdelta,flip)]+=1
  if flip:
   y=D[j]^(1<<i)
   if y.bit_count()>=5:return True,steps,counts
   j=idx[y]

def likelihood_bounds(counts,bits=128):
 lo=hi=F(1)
 for (d,qd,flip),count in counts.items():
  cl,ch=logistic_bounds(d,bits);ql,qh=logistic_bounds(qd,bits)
  if not flip:cl,ch=1-ch,1-cl;ql,qh=1-qh,1-ql
  scale=1<<bits
  for _ in range(count):
   z=lo*cl/qh;lo=F((z.numerator*scale)//z.denominator,scale)
   z=hi*ch/ql;hi=F(-((-z.numerator*scale)//z.denominator),scale)
 return lo,hi

def certify_divergent_selfloop():
 j=idx[98];lower=F(0)
 for i in range(n):
  d=rate_delta(j,i);cl,ch=logistic_bounds(d);ql,qh=logistic_bounds(d+2*int(sp[j,i]))
  lower+=(1-ch)**2/(1-ql)/RATE
 if not A[j]:lower+=K/RATE
 assert lower>F(5,4)
 return float(lower)
if __name__=='__main__':
 import json
 out={'divergent_bias1_selfloop_lower_gt_1_25':certify_divergent_selfloop(),'exact_paths':[]}
 for b in (F(0),F(2,5),F(1)):
  for _ in range(5):
   hit,steps,counts=draw(b);lo,hi=likelihood_bounds(counts)
   if b==0:assert lo<=1<=hi
   assert hi-lo<F(1,10**20)
   out['exact_paths'].append({'bias':float(b),'hit':hit,'events':steps,'likelihood_lower':float(lo),'likelihood_upper':float(hi),'exact_interval_width_lt_1e_20':True})
 print(json.dumps(out,indent=2))
