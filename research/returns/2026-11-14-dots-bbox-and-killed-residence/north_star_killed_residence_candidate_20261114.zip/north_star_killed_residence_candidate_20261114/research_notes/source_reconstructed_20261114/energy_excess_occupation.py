"""All-topology direct Gibbs occupation bound conditioned on E−3.2P."""
from fractions import Fraction as F
from math import factorial
import json
n=2560000
assert sum((F(16,5)**k/F(factorial(k)) for k in range(60)),F(0))>24
assert sum((F(1,1)/F(factorial(k)) for k in range(6)),F(0))>F(8,3)
G=F(n,1080);threshold=2600
assert G-threshold<-229
bound=2*F(3,8)**229
assert bound<F(1,10**97)
print(json.dumps({'condition':'(24/5)*P−Nplus/25 ≥2600, equivalently Nplus≤120P−65000','loop_gas_log_upper':float(G),'exponent_upper':float(G-threshold),'exact_normalized_occupation_less_than':'1e-97','rational_upper':float(bound),'topology':'Unrestricted torus configurations; boundary loops may wind.','example':'Straight full-height strips of width≤199 satisfy the condition; thin winding crosses and filaments are also included when the displayed inequality holds.'},indent=2))
