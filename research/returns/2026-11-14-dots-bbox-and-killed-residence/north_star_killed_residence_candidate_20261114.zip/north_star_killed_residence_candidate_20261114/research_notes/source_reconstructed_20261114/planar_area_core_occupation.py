"""Static area-core constants: requires injectively projected planar hulls."""
from fractions import Fraction as F
import json
n=2560000
kappa=F(1,745)**4/(1-F(1,745))
holes=n*kappa
hull=n*(F(10,27)**31+2*F(10,27)**47+9*F(10,27)**63+F(1,674)**10/(1-F(1,674))+F(2602,2**260))
G=hull/(1-holes);excess=G/(1-G)
assert excess<F(1087,10**10)
print(json.dumps({'component_area_cap':422500,'topological_condition':'Each component has an injectively projected finite planar raw filled hull. Winding or noninjective hulls are excluded.','global_hole_root_budget':n,'hole_gas_exponent_upper':float(holes),'normalizer_excess_upper':float(excess),'exact_excess_less_than':'1.087e-7','prior_constant_checks':'core650_occupation.py and renewal_box164_raw_faces.py'},indent=2))
