"""Small finite diagnostic; floats in benchmark, exact rates defined rationally.
Proposal is local field tilt only. No committor is passed to sampling code.
"""
import numpy as np,json,time
from scipy.linalg import solve,eigvals
L=3;n=L*L;kappa=.05;theta=1.2;field=theta/5;Lam=n+kappa
B=lambda x:x.bit_count()>=5
neighbors=[];aug=[]
for i in range(n):
 x,y=divmod(i,L)
 neighbors.append([((x+dx)%L)*L+(y+dy)%L for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]])
 aug.append(neighbors[-1]+[((x+1)%L)*L+(y+1)%L,((x-1)%L)*L+(y-1)%L])
def core(x):return all(not(x>>i&1) or all(not(x>>j&1) for j in aug[i]) for i in range(n))
D=[x for x in range(1<<n) if not B(x)];idx={x:i for i,x in enumerate(D)};d=len(D)
sp=np.array([[1 if x>>i&1 else -1 for i in range(n)] for x in D])
delta=np.array([[2*sp[j,i]*(theta*sum(sp[j,k] for k in neighbors[i])+field) for i in range(n)] for j in range(d)])
c=1/(1+np.exp(delta));A=np.array([core(x) for x in D]);
w=np.array([np.exp(theta*sum(sp[j,i]*sp[j,k] for i in range(n) for k in neighbors[i])/2+field*sum(sp[j])) for j in range(d)])
# Pin vertex0 as entire component. Since C1 all components singleton, require bit0.
seed=np.array([A[j] and bool(x&1) for j,x in enumerate(D)])
mu=w*seed;mu/=mu.sum()

def matrices(bias):
 q=1/(1+np.exp(delta+2*bias*sp))
 P=np.zeros((d,d));H=np.zeros((d,d));r=np.zeros(d);h=np.zeros(d)
 for j,x in enumerate(D):
  P[j,j]+=sum(1-q[j])/Lam+(0 if A[j] else kappa/Lam)
  H[j,j]+=sum((1-c[j])**2/(1-q[j]))/Lam+(0 if A[j] else kappa/Lam)
  for i in range(n):
   y=x^(1<<i);pv=q[j,i]/Lam;hv=c[j,i]**2/(q[j,i]*Lam)
   if B(y):r[j]+=pv;h[j]+=hv
   else:P[j,idx[y]]+=pv;H[j,idx[y]]+=hv
 return q,P,H,r,h

def run_paths(q,draws,seed_rng):
 rng=np.random.default_rng(seed_rng);prob=[];duration=[];counts=[];hit=[]
 for _ in range(draws):
  j=int(rng.choice(d,p=mu));weight=1.;steps=0
  while True:
   steps+=1
   # Site clock rate1 each plus source clock rateκ; source attempts null outsideA.
   u=int(rng.integers(20*n+1))
   if u==20*n:
    if A[j]:success=False;break
    continue
   i=u//20
   if rng.random()<q[j,i]:
    weight*=c[j,i]/q[j,i];x=D[j]^(1<<i)
    if B(x):success=True;break
    j=idx[x]
   else:weight*=(1-c[j,i])/(1-q[j,i])
  prob.append(weight*success);duration.append(weight*steps/Lam);counts.append(steps);hit.append(success)
 return {'draws':draws,'weighted_success_mean':float(np.mean(prob)),'weighted_success_se':float(np.std(prob,ddof=1)/np.sqrt(draws)),'weighted_duration_mean':float(np.mean(duration)),'weighted_duration_se':float(np.std(duration,ddof=1)/np.sqrt(draws)),'proposal_success_fraction':float(np.mean(hit)),'proposal_mean_events':float(np.mean(counts))}
if __name__=='__main__':
 t=time.time();I=np.eye(d);_,P0,_,r0,_=matrices(0)
 p=solve(I-P0,r0);m=solve(I-P0,np.ones(d)/Lam)
 out={'L':L,'theta':theta,'R':5,'kappa':kappa,'core':'C1 uniform NE diagonal','seed':'site0 is singleton component','seed_support_states':int(seed.sum()),'native_p':float(mu@p),'native_m':float(mu@m),'variants':[]}
 for b in [0,.1,.3,.6]:
  q,P,H,r,h=matrices(b);rho=float(max(abs(eigvals(H))));cost=float(mu@solve(I-P,np.ones(d)));qp=float(mu@solve(I-P,r))
  z={'field_bias':b,'second_moment_spectral_radius':rho,'expected_proposal_events':cost,'proposal_p':qp}
  if rho<1:z['success_second_moment']=float(mu@solve(I-H,h))
  else:z['success_second_moment']='infinite: irreducible positive-weight kernel spectral radius >=1'
  z.update(run_paths(q,2000,20261114+int(10*b)))
  out['variants'].append(z)
 out['seconds']=time.time()-t
 print(json.dumps(out,indent=2))
