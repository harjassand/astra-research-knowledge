"""Exact full-core sampler for a supplied fixed diagonal-orientation oracle.
Oracle diag(x,y) is True for SW-NE in plaquette anchored at (x,y), False for SE-NW.
Never substitutes an inferred original C5 convention. Ideal random-bit semantics.
"""
import source as base
from source import F,isqrt,secrets,expneg_bounds,exp_bernoulli,rational_choice,Uniform
DIR=((1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,-1),(1,-1),(-1,1))
class Core:
 def __init__(self,L,box_sites,diag,max_area=None):
  assert L>=3 and 1<=box_sites<L/2
  self.L=L;self.box=box_sites;self.diag=diag;self.A=max_area or box_sites**2
  assert self.A>=box_sites**2
  self.b=[None];self.w=[]
  for a in range(1,self.A+1):
   t=isqrt(4*a);t+=t*t<4*a;x=F(16*t)-F(a,25)
   assert x>=0
   b=F(10,27)**(x.numerator//x.denominator)
   self.b.append(b);self.w.append(L*L*64**(a-1)*b)
  self.G=sum(self.w)
 def step(self,v,j):
  dx,dy=DIR[j];return ((v[0]+dx)%self.L,(v[1]+dy)%self.L)
 def allowed(self,v,j):
  if j<4:return True
  x,y=v;dx,dy=DIR[j]
  # Each diagonal is indexed by its unique lower-left plaquette anchor.
  ax=(x+min(dx,0))%self.L;ay=(y+min(dy,0))%self.L
  return bool(self.diag(ax,ay))==(dx==dy)
 def neighbors(self,v):
  return [self.step(v,j) for j in range(8) if self.allowed(v,j)]
 def canonical(self,S):
  root=min(S);seen={root};out=[]
  def dfs(v):
   for j in range(8):
    if not self.allowed(v,j):continue
    u=self.step(v,j)
    if u in S and u not in seen:
     seen.add(u);out.append(j);dfs(u);out.append(j^1)
  dfs(root)
  return root,tuple(out)
 def valid(self,S):
  root=min(S);lift={root:(0,0)};stack=[root]
  while stack:
   v=stack.pop()
   for j,(dx,dy) in enumerate(DIR):
    if not self.allowed(v,j):continue
    u=self.step(v,j)
    if u not in S:continue
    q=(lift[v][0]+dx,lift[v][1]+dy)
    if u in lift:
     if q!=lift[u]:return False
    else:lift[u]=q;stack.append(u)
  return len(lift)==len(S) and all(max(v[d] for v in lift.values())-min(v[d] for v in lift.values())+1<=self.box for d in (0,1))
 def decode(self,root,code,a):
  v=root;S={v}
  for j in code:
   if not self.allowed(v,j):return None
   v=self.step(v,j);S.add(v)
  if v!=root or len(S)!=a or not self.valid(S) or self.canonical(S)!=(root,code):return None
  return S
 def mark(self):
  a=1+rational_choice(self.w);root=(secrets.randbelow(self.L),secrets.randbelow(self.L))
  S=self.decode(root,tuple(secrets.randbelow(8) for _ in range(2*(a-1))),a)
  if S is None:return None
  p=sum(self.step(v,j) not in S for v in S for j in range(4))
  return S if exp_bernoulli(F(8*p)-F(a,25),1/self.b[a]) else None
 def poisson(self,positive=False):
  u=Uniform();bits=64
  while True:
   lo,hi=expneg_bounds(self.G,bits)
   u.refine();ul,uh=u.bounds()
   k=1 if positive else 0;term=self.G if positive else F(1);summ=term
   if positive and hi>=1:bits+=32;continue
   while True:
    lower=lo*summ/(1-lo) if positive else lo*summ
    upper=hi*summ/(1-hi) if positive else hi*summ
    if uh<=lower:return k
    if ul<upper:break
    k+=1;term*=self.G/k;summ+=term
   bits+=32
 def sample(self,nonempty=False):
  attempts=0
  while True:
   attempts+=1;union=set();valid=True
   for _ in range(self.poisson(nonempty)):
    s=self.mark()
    if s is None:continue
    if any(v in union or any(u in union for u in self.neighbors(v)) for v in s):valid=False;break
    union|=s
   if valid and (union or not nonempty):return union,attempts

 def sample_given_component(self,component):
  """Gibbs core conditional on this exact augmented plus component being present.
  Not conditional merely on its spins being plus; not transition-success law.
  """
  component=set(component)
  assert component and self.valid(component)
  attempts=0
  while True:
   attempts+=1;union=set(component);valid=True
   for _ in range(self.poisson()):
    s=self.mark()
    if s is None:continue
    if any(v in union or any(u in union for u in self.neighbors(v)) for v in s):valid=False;break
    union|=s
   if valid:return union,attempts
