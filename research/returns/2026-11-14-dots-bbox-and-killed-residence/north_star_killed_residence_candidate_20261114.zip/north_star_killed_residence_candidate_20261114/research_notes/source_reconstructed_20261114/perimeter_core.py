"""Exact finite R200 auxiliary thermal-core sampler, supplied augmentation.
Perimeter boundary-cycle code (128 letters), singleton special channel.
Supports box_sites<=18; no core convention inferred; theta4, beta*h=.02.
"""
from source8 import Core
from source import F,Uniform,expneg_bounds,exp_bernoulli,secrets,rational_choice
from collections import defaultdict
D4=((1,0),(0,1),(-1,0),(0,-1))

def boundary(S):
 edges=set()
 for x,y in S:
  if (x,y-1) not in S:edges.add((x,y,0))
  if (x+1,y) not in S:edges.add((x+1,y,1))
  if (x,y+1) not in S:edges.add((x+1,y+1,2))
  if (x-1,y) not in S:edges.add((x,y+1,3))
 return edges

def edge_end(e):
 x,y,d=e;dx,dy=D4[d];return x+dx,y+dy

def encode(S):
 """S already consistently lifted relative to canonical anchor root(0,0)."""
 E=boundary(S);inc=defaultdict(list);out=defaultdict(list)
 for e in E:out[e[:2]].append(e);inc[edge_end(e)].append(e)
 nxt={}
 for v in out:
  assert len(out[v])==len(inc[v])
  nxt.update(zip(sorted(inc[v]),sorted(out[v])))
 unused=set(E);code=[]
 while unused:
  first=min(unused);loop=[];e=first
  while True:
   assert e in unused;unused.remove(e);loop.append(e);e=nxt[e]
   if e==first:break
  assert len(loop)>=4
  x,y,d=first
  cx=x-(d in (1,2));cy=y-(d in (2,3))
  assert -17<=cx<=17 and -17<=cy<=17
  header=((cx+17)*35+(cy+17))*4+d
  digits=[(header>>(4*(3-i)))&15 for i in range(4)]
  for i,e in enumerate(loop):code.append((e[2]<<5)|(int(i==len(loop)-1)<<4)|(digits[i] if i<4 else 0))
 return tuple(code)

def decode(code):
 """Decode all oriented boundary cycles; return plane plus set or None."""
 loops=[];start=0
 for i,s in enumerate(code):
  if s&16:
   if i+1-start<4:return None
   loops.append(code[start:i+1]);start=i+1
 if start!=len(code) or not loops:return None
 edges=set()
 for loop in loops:
  header=0
  for s in loop[:4]:header=(header<<4)|(s&15)
  if header>=35*35*4 or any(s&15 for s in loop[4:]):return None
  loc,d=divmod(header,4);cx,cy=loc//35-17,loc%35-17
  x=cx+(d in (1,2));y=cy+(d in (2,3));first=(x,y)
  if loop[0]>>5!=d:return None
  for s in loop:
   direction=s>>5;e=(x,y,direction)
   if e in edges:return None
   edges.add(e);dx,dy=D4[direction];x+=dx;y+=dy
   if not(-18<=x<=18 and -18<=y<=18):return None
  if (x,y)!=first:return None
 # Exact horizontal ray winding; oriented edges have occupied cell on left.
 S=set()
 for y in range(-17,18):
  wind=0
  for x in range(17,-18,-1):
   wind+=((x+1,y,1) in edges)-((x+1,y+1,3) in edges)
   if wind not in (0,1):return None
   if wind:S.add((x,y))
  wind+=((-17,y,1) in edges)-((-17,y+1,3) in edges)
  if wind:return None
 if not S or boundary(S)!=edges:return None
 if encode(S)!=tuple(code):return None
 return S

class PerimeterCore(Core):
 def __init__(self,L,box_sites,diag):
  assert L>2*box_sites and 1<=box_sites<=18
  self.L=L;self.box=box_sites;self.diag=diag;self.A=box_sites**2
  self.r=128**2*F(10,27)**15;assert self.r<1
  self.G1=L*L*F(10,27)**31
  self.GL=L*L*128**6*F(10,27)**46/(1-self.r)
  self.G=self.G1+self.GL
 def geometric(self):
  k=0
  while secrets.randbelow(self.r.denominator)<self.r.numerator:k+=1
  return k
 def mark(self):
  singleton=rational_choice([self.G1,self.GL])==0
  root=(secrets.randbelow(self.L),secrets.randbelow(self.L))
  if singleton:
   return {root} if exp_bernoulli(F(799,25),F(27,10)**31) else None
  k=self.geometric();p=6+2*k
  if p>4*self.A:return None
  code=tuple(secrets.randbelow(128) for _ in range(p));plane=decode(code)
  if plane is None:return None
  if (0,0) not in plane or any(max(v[d] for v in plane)-min(v[d] for v in plane)+1>self.box for d in (0,1)):return None
  S={((root[0]+x)%self.L,(root[1]+y)%self.L) for x,y in plane}
  if min(S)!=root or (0,0) not in plane or not self.valid(S):return None
  # Unique contractible image relative to root, no duplicated torus sites.
  if len(S)!=len(plane):return None
  x=F(8*p)-F(len(S),25);b=F(10,27)**(46+15*k)
  return S if exp_bernoulli(x,1/b) else None

class CompactPerimeterCore(PerimeterCore):
 """Same exact law, explicit P4/P6/P8 channels give Γ<1e-6 atL1600.
 All remaining perimeter≥10 boundary words are still retained exactly.
 """
 def __init__(self,L,box_sites,diag):
  super().__init__(L,box_sites,diag)
  self.G6=2*L*L*F(10,27)**47
  self.G8=8*L*L*F(10,27)**63
  self.GL=L*L*128**10*F(10,27)**78/(1-self.r)
  self.G=self.G1+self.G6+self.G8+self.GL
 def mark(self):
  ch=rational_choice([self.G1,self.G6,self.G8,self.GL])
  root=(secrets.randbelow(self.L),secrets.randbelow(self.L));x,y=root
  if ch==0:return {root} if exp_bernoulli(F(799,25),F(27,10)**31) else None
  if ch==1:
   off=[(0,0),(1,0)] if secrets.randbelow(2)==0 else [(0,0),(0,1)]
   S={((x+dx)%self.L,(y+dy)%self.L) for dx,dy in off};p=6;exponent=47
  elif ch==2:
   forms=[[(0,0),(1,0),(2,0)],[(0,0),(0,1),(0,2)],
    [(0,0),(1,0),(0,1)],[(0,0),(1,0),(1,1)],
    [(0,0),(0,1),(1,1)],[(1,0),(0,1),(1,1)],
    [(0,0),(1,0),(0,1),(1,1)]]
   j=secrets.randbelow(8)
   off=forms[j] if j<7 else ([(0,0),(1,1)] if self.diag(x,y) else [(1,0),(0,1)])
   S={((x+dx)%self.L,(y+dy)%self.L) for dx,dy in off};p=8;exponent=63
  else:
   k=self.geometric();p=10+2*k;exponent=78+15*k
   if p>4*self.A:return None
   plane=decode(tuple(secrets.randbelow(128) for _ in range(p)))
   if plane is None:return None
   if (0,0) not in plane or any(max(v[d] for v in plane)-min(v[d] for v in plane)+1>self.box for d in (0,1)):return None
   S={((x+dx)%self.L,(y+dy)%self.L) for dx,dy in plane}
   if min(S)!=root or len(S)!=len(plane):return None
  if not self.valid(S):return None
  return S if exp_bernoulli(F(8*p)-F(len(S),25),F(27,10)**exponent) else None
