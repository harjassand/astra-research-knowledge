from source8 import *
import json,time
c=Core(1600,6,lambda x,y:True)
cases={'wrapped_pair':{(1599,0),(0,0)},'diagonal_pair':{(0,0),(1,1)},'full_6x6':{(x,y) for x in range(6) for y in range(6)}}
out=[]
for name,seed in cases.items():
 start=time.time();attempts=0;extras=0
 for i in range(1000):
  S,k=c.sample_given_component(seed);assert seed<=S
  assert all(u not in S-seed for v in seed for u in c.neighbors(v))
  attempts+=k;extras+=bool(S-seed)
 out.append({'seed':name,'seed_size':len(seed),'draws':1000,'attempts':attempts,'background_nonempty':extras,'seconds':time.time()-start})
print(json.dumps(out,indent=2))
