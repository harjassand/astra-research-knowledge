from perimeter_core import *
from source8 import DIR
import random,json,time
rng=random.Random(20261114);records=[];checked=0
for name,diag in [('NE',lambda x,y:True),('NW',lambda x,y:False),('alternating',lambda x,y:(x+y)%2==0)]:
 c=PerimeterCore(1600,16,diag);valid=0
 for _ in range(1000):
  ox=rng.choice([0,1598,1599]);oy=rng.choice([0,1598,1599])
  mask=rng.randrange(1,1<<16);S={((ox+i%4)%1600,(oy+i//4)%1600) for i in range(16) if mask>>i&1}
  if not c.valid(S):continue
  root=min(S);lift={root:(0,0)};stack=[root]
  while stack:
   v=stack.pop()
   for j,(dx,dy) in enumerate(DIR):
    if not c.allowed(v,j):continue
    u=c.step(v,j)
    if u not in S:continue
    q=(lift[v][0]+dx,lift[v][1]+dy)
    if u in lift:assert lift[u]==q
    else:lift[u]=q;stack.append(u)
  plane=set(lift.values());code=encode(plane);decoded=decode(code)
  assert decoded==plane
  assert {((root[0]+x)%1600,(root[1]+y)%1600) for x,y in decoded}==S
  valid+=1;checked+=1
 # Pinned conditional source draw retains whole exact background.
 seed={(x,y) for x in range(16) for y in range(16)}
 start=time.time();attempts=0
 for _ in range(100):
  S,a=c.sample_given_component(seed);assert seed<=S
  assert all(u not in S-seed for v in seed for u in c.neighbors(v));attempts+=a
 records.append({'orientation':name,'valid_wrapped_subsets':valid,'pinned_16x16_draws':100,'attempts':attempts,'pinned_seconds':time.time()-start})
print(json.dumps({'passed':True,'total_wrapped_roundtrips':checked,'tests':records},indent=2))
