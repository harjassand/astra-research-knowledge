from perimeter_core import *
import json,time
# Exhaustively classify all small perimeter shapes (translation-normalized).
observed={4:set(),6:set(),8:set()}
for mask in range(1,1<<16):
 S={(i%4,i//4) for i in range(16) if mask>>i&1};p=len(boundary(S))
 if p not in observed:continue
 seen={min(S)};todo=list(seen)
 while todo:
  x,y=todo.pop()
  for dx in (-1,0,1):
   for dy in (-1,0,1):
    u=(x+dx,y+dy)
    if u in S and u not in seen:seen.add(u);todo.append(u)
 if seen!=S:continue
 ax=min(x for x,y in S);ay=min(y for x,y in S)
 observed[p].add(tuple(sorted((x-ax,y-ay) for x,y in S)))
assert [len(observed[p]) for p in (4,6,8)]==[1,2,9]
# 9 P8 geometric shapes =7 NN shapes+2 diagonal types; fixed graph has1 diagonal/plaquette.
results={'small_perimeter_geometric_shape_counts':{str(p):len(s) for p,s in observed.items()},'runs':[]}
for name,diag in [('NE',lambda x,y:True),('alternating',lambda x,y:(x+y)%2==0)]:
 c=CompactPerimeterCore(1600,18,diag)
 assert 1/(1-c.G)<F(1000001,1000000)
 elo,ehi=expneg_bounds(c.G,160);zlo,zhi=expneg_bounds(F(799,25),160)
 lower=1600**2*zlo*elo/(1-elo);assert lower>F(1,25)
 for p in range(10,4*18**2+1,2):assert F(391*p,50)>=78+15*((p-10)//2)
 for a,p,e in [(1,4,31),(2,6,47),(2,8,63),(3,8,63),(4,8,63)]:assert expneg_bounds(F(8*p)-F(a,25),160)[1]<=F(10,27)**e
 start=time.time();attempts=0;hist={}
 for _ in range(2000):
  S,k=c.sample(nonempty=True);attempts+=k;hist[len(S)]=hist.get(len(S),0)+1
 results['runs'].append({'orientation':name,'box_sites':18,'gamma':float(c.G),'normalizer_upper':float(1/(1-c.G)),'conditional_acceptance_lower':float(lower),'nonempty_draws':2000,'attempts':attempts,'sizes':hist,'seconds':time.time()-start})
print(json.dumps(results,indent=2))
