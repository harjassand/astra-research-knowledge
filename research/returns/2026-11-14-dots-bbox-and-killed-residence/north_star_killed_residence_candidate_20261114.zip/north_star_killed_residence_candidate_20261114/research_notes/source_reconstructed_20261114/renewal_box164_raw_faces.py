"""Exact static renewal constants conditional on raw-face counting injection.
No excursion-duration bound asserted. Native heatbath clock preserved.
"""
from fractions import Fraction as F
from math import factorial,log
import json

def explower(x):return sum((F(x)**k/F(factorial(k)) for k in range(100)),F(0))
n=2560000
for x,y in [(F(8),F(2980)),(F(79,10),F(2696)),(F(636,100),F(576)),(F(471,100),F(108))]:assert explower(x)>y
for x,k in [(F(799,25),31),(F(1198,25),47),(F(1596,25),63)]:assert explower(x)>F(27,10)**k
assert explower(F(799,25))>n*10**7
kappa=F(1,745)**4/(1-F(1,745))
gh_core=165**2*kappa;gh_exit=330**2*kappa
base=n*(F(10,27)**31+2*F(10,27)**47+9*F(10,27)**63+F(1,674)**10/(1-F(1,674))+F(1,144)**42/(1-F(1,144)))
G=base/(1-gh_core)
T=n*F(1,27)**332/(1-F(1,27))/(1-gh_exit)
p=F(1,1-G)*329**2*T*(1+3**32)/n
assert G<F(11,10**8)
assert p<F(1,10**450)
# Float only logarithms of exact rationals: avoid underflow.
def lograt(x):return log(x.numerator)-log(x.denominator)
out={'core_box':164,'new_component_box':329,'min_outer_exit_perimeter':332,'hole_activity_core_upper':float(gh_core),'hole_activity_exit_upper':float(gh_exit),'core_polymer_activity_upper':float(G),'core_numerator_excess_upper':float(G/(1-G)),'gate_multiplicity':329**2,'log_exit_probability_upper_diagnostic':lograt(p),'exact_exit_probability_less_than':'1e-450','native_lambda_less_than':'1e-7','sufficient_uniform_duration_bound':'1e454 gives outside numerator correction below1e-3 using coarse exact bounds','all_rational_comparisons_passed':True,'premise':'Injective raw geometric outer-face and bounded-face word encoding, separately proved/reviewed. This script certifies constants, not topology or duration.'}
print(json.dumps(out,indent=2))
