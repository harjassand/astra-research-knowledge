"""Exact raw-face normalizer bound for analytical box650 core.
No first-exit probability or post-exit mean bound claimed.
"""
from fractions import Fraction as F
from math import factorial
import json

def explower(x):return sum((F(x)**k/F(factorial(k)) for k in range(100)),F(0))
n=2560000;b=650
assert explower(F(7,5))>4 # ln4<1.4
assert explower(F(8))>2980
assert explower(F(79,10))>2696
for x,k in [(F(799,25),31),(F(1198,25),47),(F(1596,25),63)]:assert explower(x)>F(27,10)**k
f=lambda p:F(7,5)*p-8*p+F(p*p,400)
assert f(42)<-260 and f(2600)==-260 # convex maximum on interval
holes=651**2*F(1,745)**4/(1-F(1,745))
hull=n*(F(10,27)**31+2*F(10,27)**47+9*F(10,27)**63+F(1,674)**10/(1-F(1,674))+F(2602,2**260))
G=hull/(1-holes);excess=G/(1-G)
assert excess<F(1087,10**10)
print(json.dumps({'core_box':b,'core_polymer_activity_upper':float(G),'core_numerator_excess_upper':float(excess),'exact_excess_less_than':'1.087e-7','hole_gas_exponent_upper':float(holes),'all_rational_checks_passed':True,'scope':'Static core occupation only; all outside-box650/winding occupation remains unbounded.'},indent=2))
