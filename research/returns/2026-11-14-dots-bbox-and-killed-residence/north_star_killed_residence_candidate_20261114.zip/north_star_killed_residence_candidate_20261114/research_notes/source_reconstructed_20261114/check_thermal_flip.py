from fractions import Fraction as F
import json
L=1600;D={(x,y) for x in range(400) for y in range(395)}
def P(S):return sum(((x+dx)%L,(y+dy)%L) not in S for x,y in S for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)])
def E(S):return 8*P(S)-F(len(S),25)
base=E(D);out=[]
for name,Y in [('interior_single',{(200,200)}),('interior_pair',{(200,200),(201,200)}),('interior_plus_exterior',{(200,200),(1000,1000)})]:
 X=D.symmetric_difference(Y);m=len(Y&D);diff=E(X)-E(Y);assert diff==base+F(2*m,25)
 gate=(400,200);k=sum(((gate[0]+dx)%L,(gate[1]+dy)%L) in X for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)])
 assert k==1 and E(X|{gate})-E(X)==F(399,25)
 out.append({'case':name,'inverse_plus_count':len(Y),'interior_thermal_plus':m,'exact_E_restored_minus_E_inverse':str(diff),'upper_activity_E':str(base),'extra_thermal_acceptance_exponent':str(-F(2*m,25)),'native_gate_deltaE':str(F(399,25))})
print(json.dumps({'model':'originalL1600theta4phi.02','domain_bbox':[400,395],'gate_bbox':[401,395],'target':'majorityunchanged','exact_fraction_checks':out},indent=2))
