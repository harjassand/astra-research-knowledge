"""Exact rational static core/exit envelopes, NOT duration bounds."""
from fractions import Fraction as F
from math import factorial,log
import json

def explower(x):return sum((F(x)**k/F(factorial(k)) for k in range(100)),F(0))
n=2560000
assert explower(F(79,10))>2688 #128e^-7.9<1/21
assert explower(F(737,100))>1536 #128e^-7.37<1/12
assert explower(F(673,100))>832 #128e^-6.73<2/13
assert explower(F(799,25))>F(27,10)**31
assert explower(F(1198,25))>F(27,10)**47
assert explower(F(1596,25))>F(27,10)**63
assert explower(F(799,25))>n*10**7 # native lambda_a<1e-7
G=n*(F(10,27)**31+2*F(10,27)**47+9*F(10,27)**63+F(1,21)**10/(1-F(1,21))+F(1,12)**42/(1-F(1,12)))
assert G<F(1,3000000)
# exp(G)<=1/(1-G), and lambda=n/(1+exp31.96).
# exp31.96 < exp32 < 3^32, elementary e<3; rational certificate.
T=n*F(2,13)**130/(1-F(2,13))
p=F(1,1-G)*16129*T*(1+3**32)/n
# Also a tighter numeric log shown as diagnostic, not exact displayed bound.
out={'core_box':63,'new_component_box':127,'min_exit_perimeter':130,'gamma_upper':float(G),'core_numerator_excess_upper':float(G/(1-G)),'gate_multiplicity':16129,'rational_probability_upper':float(p),'rational_log_probability_upper_diagnostic':log(float(p)),'using_exp32_lt_3pow32':True,'all_taylor_checks':True,'status':'Static renewal envelope only; no post-exit duration estimate.'}
assert p<F(1,10**86)
print(json.dumps(out,indent=2))
