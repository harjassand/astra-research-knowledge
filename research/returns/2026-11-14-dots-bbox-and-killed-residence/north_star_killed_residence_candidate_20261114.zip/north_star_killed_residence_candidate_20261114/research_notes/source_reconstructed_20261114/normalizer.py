import source,json
from fractions import Fraction as F
lo,hi=source.expneg_bounds(source.G,100)
# Z/weight(empty)>=1; <=exp(G). No floating arithmetic in proof.
upper=1/lo
assert upper<F(100000011,100000000)
print(json.dumps({'normalizer_ratio_lower':'1','normalizer_ratio_upper_float':float(upper),'proved_upper':'1.00000011','both_box_conventions':True,'meaning':'ZA / w(allminus), includes all source states; not an equality'},indent=2))
