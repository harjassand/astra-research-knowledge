import source,json,time
from fractions import Fraction as F
t=time.time();out={}
for name,S in [('singleton',{(0,0)}),('physical_pair',{(0,0),(1,0)}),('diagonal_pair',{(0,0),(1,1)})]:
 a=len(S);p=source.perimeter(S);x=8*p-F(a,25);lo,hi=source.expneg_bounds(x,100);scale=1/source.b[a]
 assert 0<=lo*scale<=hi*scale<=1
 N=10000
 out[name]={'accepted':sum(source.exp_bernoulli(x,scale) for _ in range(N)),'trials':N,'probability_interval':[float(lo*scale),float(hi*scale)],'probability_float':float(lo*scale)}
# Sparse set test: independent, adjacent, diagonal adjacency and wrapped core.
assert source.validate_lift({(1599,1599),(0,0)},5)
assert not source.validate_lift({(x,0) for x in range(6)},5)
assert source.validate_lift({(x,0) for x in range(6)},6)
out['elapsed_seconds']=time.time()-t
print(json.dumps(out,indent=2))
