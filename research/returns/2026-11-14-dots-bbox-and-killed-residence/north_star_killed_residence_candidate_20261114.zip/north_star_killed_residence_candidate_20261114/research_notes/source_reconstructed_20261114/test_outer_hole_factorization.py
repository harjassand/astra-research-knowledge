from filled_trace import connected,fill_holes,boundary_cycles,neighbors
from perimeter_core import boundary
from fractions import Fraction as F
import json,time

def pieces(S,diag):
 S=set(S);out=[]
 while S:
  seen={min(S)};todo=list(seen)
  while todo:
   for u in neighbors(todo.pop(),diag):
    if u in S and u not in seen:seen.add(u);todo.append(u)
  S-=seen;out.append(seen)
 return out

def energy(S):return 8*len(boundary(S))-F(len(S),25)
t=time.time();count=holescount=touch=0
for name,diag in [('NE',lambda x,y:True),('NW',lambda x,y:False),('alt',lambda x,y:(x+y)%2==0)]:
 for mask in range(1,1<<12):
  S={(i%4,i//4) for i in range(12) if mask>>i&1}
  if not connected(S,diag):continue
  D=fill_holes(S,diag);hs=pieces(D-S,diag)
  assert len(boundary_cycles(D,diag))==1
  for H in hs:
   assert fill_holes(H,diag)==H
   cs=boundary_cycles(H,diag);assert len(cs)==1
   touch+=len(set(e[:2] for e in cs[0]))<len(cs[0])
  assert len(boundary(S))==len(boundary(D))+sum(len(boundary(H)) for H in hs)
  assert energy(S)==energy(D)+sum(8*len(boundary(H))+F(len(H),25) for H in hs)
  count+=1;holescount+=len(hs)
print(json.dumps({'connected_polymers':count,'bounded_holes':holescount,'touching_hole_traces':touch,'same_graph_holes_filled':True,'perimeter_and_energy_factorization_exact':True,'seconds':time.time()-t},indent=2))
