"""Finite torus checks of boundary-loop decomposition and spin recovery."""
import json,time
L=4;n=L*L;t=time.time();winding_states=0;maxloops=0
for mask in range(1<<n):
 def spin(x,y):return (mask>>((y%L)*L+x%L))&1
 edges=set()
 for y in range(L):
  for x in range(L):
   if spin(x,y)!=spin(x+1,y):edges.add(tuple(sorted((((x+1)%L,y),((x+1)%L,(y+1)%L)))))
   if spin(x,y)!=spin(x,y+1):edges.add(tuple(sorted(((x,(y+1)%L),((x+1)%L,(y+1)%L)))))
 unused=set(edges);loops=[];winding=False
 while unused:
  first=min(unused);root=first[0];v=root;walk=[];dxsum=dysum=0
  while True:
   e=min(e for e in unused if v in e);unused.remove(e);u=e[1] if e[0]==v else e[0]
   dx=(u[0]-v[0])%L;dy=(u[1]-v[1])%L
   if dx==L-1:dx=-1
   if dy==L-1:dy=-1
   assert abs(dx)+abs(dy)==1
   dxsum+=dx;dysum+=dy;walk.append(e);v=u
   if v==root:break
  assert len(walk)>=4
  winding|=bool(dxsum or dysum);loops.append(walk)
 assert sum(map(len,loops))==len(edges)
 # Boundary differences determine every original spin once site0 is set.
 recovered={(0,0):spin(0,0)};todo=[(0,0)]
 while todo:
  x,y=todo.pop()
  for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]:
   u=((x+dx)%L,(y+dy)%L)
   if dx:
    xx=(x+(dx==1))%L;dual=tuple(sorted(((xx,y),(xx,(y+1)%L))))
   else:
    yy=(y+(dy==1))%L;dual=tuple(sorted(((x,yy),((x+1)%L,yy))))
   difference=int(dual in edges)
   value=recovered[x,y]^difference
   if u in recovered:assert recovered[u]==value
   else:recovered[u]=value;todo.append(u)
 assert all(v==spin(*u) for u,v in recovered.items())
 winding_states+=winding;maxloops=max(maxloops,len(loops))
print(json.dumps({'L':L,'states_checked':1<<n,'states_with_winding_loop':winding_states,'maximum_loops':maxloops,'all_edges_used_once':True,'min_loop_length_at_least4':True,'spin_recovery_up_to_global_flip':True,'seconds':time.time()-t},indent=2))
