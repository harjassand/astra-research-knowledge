from perimeter_core import *
from source import expneg_bounds
import json,time
start=time.time();count=0;lengths=set()
# Exhaust all nonempty subsets: permits holes, diagonal touches, disconnected
# physical sets, multiple cycles. Only final augmented core membership filters.
for mask in range(1,1<<16):
 S={(i%4,i//4) for i in range(16) if mask>>i&1}
 code=encode(S);T=decode(code)
 assert T==S,(mask,code,T)
 assert len(code)==len(boundary(S))
 count+=1;lengths.add(len(code))
# Extreme coordinates and wrapped pin geometry.
for S in [{(-17,0),(0,0)} ,{(x,y) for x in range(-17,1) for y in range(18)}, {(x,y) for x in range(18) for y in range(18) if (x in (0,17) or y in (0,17))}]:
 assert decode(encode(S))==S
c=PerimeterCore(1600,18,lambda x,y:(x+y)%2==0)
assert c.G<F(163,1000)
assert expneg_bounds(c.G,160)[0]>F(84,100)
for p in range(6,4*18**2+1,2):
 k=(p-6)//2;x=F(391*p,50)
 # Uniform exponent inequality; e^-1<10/27 via rational Taylor.
 assert x>=46+15*k
assert sum(F(1,__import__('math').factorial(i)) for i in range(6))>F(27,10)
attempts=0;nonempty=0;t=time.time()
for i in range(10000):
 S,a=c.sample();attempts+=a;nonempty+=bool(S)
print(json.dumps({'exhaustive_4x4_masks':count,'perimeters':sorted(lengths),'all_boundary_code_roundtrips':True,'extreme_coordinate_and_hole_tests':True,'gamma':float(c.G),'acceptance_lower_gt':.84,'draws':10000,'attempts':attempts,'nonempty':nonempty,'sampling_seconds':time.time()-t,'total_seconds':time.time()-start},indent=2))
