"""All-topology high-perimeter Gibbs/occupation tail; exact scalar constants."""
from fractions import Fraction as F
from math import factorial,log
import json
n=2560000;p0=11200;s=F(24,5)
assert sum((F(16,5)**k/F(factorial(k)) for k in range(60)),F(0))>24
assert sum((F(1,1)/F(factorial(k)) for k in range(6)),F(0))>F(8,3)
r=F(1,6);G=n*r**4/(1-r)
exponent=F(n,50)-s*p0+G
assert exponent<-189
bound=2*F(3,8)**189
assert bound<F(1,10**80)
print(json.dumps({'L':1600,'perimeter_threshold':p0,'native_energy':'8P−Nplus/25','tilt':str(s),'loop_gas_log_upper':float(G),'combined_exponent_upper':float(exponent),'exact_occupation_upper_less_than':'1e-80','rational_upper':float(bound),'scope':'Every non-majority configuration with physical perimeter≥11200, including winding and arbitrary companions; uses h_a≤1, not dynamics modification.'},indent=2))
