"""Portable per-increment dyadic design; regenerable binary, not a proof artifact."""
from pathlib import Path
import hashlib,json,sys,time
import numpy as np
from dyadic_count_guide import build
out=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent/'guide_export'
out.mkdir(parents=True,exist_ok=True)
t=time.time();g,meta=build()
files={}
for name,a in [('mantissa_u32le.bin',g.m.astype('<u4')),('exponent_i32le.bin',g.e.astype('<i4'))]:
 p=out/name;p.write_bytes(a.tobytes());files[name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
# Use exponent/mantissa identity, not subtracting giant global prefixes.
logw=np.log(g.m.astype(float))+g.e.astype(float)*np.log(2)
p=out/'logweight_f64le.bin';p.write_bytes(logw.astype('<f8').tobytes());files[p.name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
meta.update({'files':files,'build_export_seconds':time.time()-t,'layout':'Separate arrays of target entries. weight[i]=mantissa[i]*2^exponent[i], strictly positive. No headers in binary. Log file is a floating approximation to THIS exact dyadic design.','boundary':'Use effective count0 for chain frozen at a and target for chain frozen at majority; frozen coordinates do not update. Equal effective counts give zero guide.'})
(out/'metadata.json').write_text(json.dumps(meta,indent=2))
print(json.dumps({'path':str(out),'files':files,'seconds':meta['build_export_seconds']},indent=2))
