"""R200 positive count guide from archived area-cut UPPER certificates.
Not actual level flux. A heuristic proposal guide; exact integer increments.
No committor, no improved native law claim. Small inputs only; no word caches.
"""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal as D,localcontext
from math import factorial
import json,time,math
import numpy as np
HERE=Path(__file__).resolve().parent
FOLDER=HERE.parent/'flow_resume_20261114/optimized_bbox/cert_r200'

def hf(s):
 a,e=s.split('p');a=a.removeprefix('0x');z=(a.split('.')+[''])[:2]
 return F(int(''.join(z),16),16**len(z[1]))*F(2)**int(e)
def area_upper_inputs():
 rows=[]
 with localcontext() as ctx:
  ctx.prec=100
  n=2560000;u=F(6*n)*F(3,40)**10/(1-F(3,40))
  def dec(v):v=F(v);return D(v.numerator)/D(v.denominator)
  def lse(v):m=max(v);return m+sum((x-m).exp() for x in v).ln()
  for p in sorted(FOLDER.glob('certificate_marked_s*.json')):
   c=json.loads(p.read_text());s=F(c['s']);P0=c['perimeter_threshold'];J=c['convolution_shift_J']
   raw=FOLDER/f'marked_convolution_s{s.numerator}_{s.denominator}.output'
   terms=[]
   for line in raw.read_text().splitlines():
    j,h=line.split();j=int(j)
    terms.append(D(j*J-4*P0)+dec(hf(h)).ln()+D(3).ln()-D(factorial(j)).ln())
   # Restore UNDISCOUNTED j1: these are area-cut envelopes, not the bbox rate refinement.
   tail=D(n).ln()+D(c['log_tuple_tail_upper'])
   target=D(n).ln()-dec(F(n,50)*(F(1,2)-F(1,500000)))+D('.02')
   source=-dec(F(n,50)*(F(1,2)-F(1,500000)))
   U=lse(terms+[tail,target,source])-dec(1-u).ln()
   rows.append({'area_cap':c['area_cap'],'log_area_cut_envelope':float(U),'source_file':p.name})
 return sorted(rows,key=lambda x:x['area_cap'])

def make_guide(target=1280000,bits=40,rows=None):
 if rows is None:rows=area_upper_inputs()
 assert target==1280000 and bits<=40 # finite calibrated R200 only
 grid=np.array([x['area_cap'] for x in rows],float)
 values=-np.array([x['log_area_cut_envelope'] for x in rows],float)
 a=np.arange(target,dtype=float)+.5
 logweights=np.interp(a,grid,values)
 def free(x):return 32*np.sqrt(x)-.04*x
 left=a<grid[0];right=a>grid[-1]
 logweights[left]=values[0]+free(a[left])-free(grid[0])
 logweights[right]=values[-1]+free(a[right])-free(grid[-1])
 # Positive integer floor supplies support; quantization is intentional guide design.
 peak=float(logweights.max())
 weights=np.maximum(1,np.floor(np.exp(np.maximum(-745,logweights-peak))*(1<<bits))).astype(np.uint64)
 prefix=np.empty(target+1,dtype=np.uint64);prefix[0]=0;np.cumsum(weights,out=prefix[1:])
 assert prefix[-1]<(1<<63) and np.all(prefix[1:]>prefix[:-1])
 return prefix,{'target':target,'bits':bits,'min_step':int(weights.min()),'max_step':int(weights.max()),'normalizer':int(prefix[-1]),'peak_count':float(a[np.argmax(logweights)]),'inputs':rows,'scope':'Positive heuristic count guide from area-basin envelope, not acquired level flux or committor. Tail free energy is an explicit unvalidated guide choice.'}

def gap(prefix,lower_count,upper_count):
 target=len(prefix)-1
 l=min(max(int(lower_count),0),target);u=min(max(int(upper_count),0),target)
 assert l<=u
 return int(prefix[u])-int(prefix[l])

if __name__=='__main__':
 t=time.time();prefix,out=make_guide();out['build_seconds']=time.time()-t
 out['gap_examples']=[{'lower':a,'upper':b,'integer_gap':gap(prefix,a,b)} for a,b in [(0,1),(153516,153517),(158000,158001),(160000,160001),(1279999,1280000)]]
 assert all(x['integer_gap']>0 for x in out['gap_examples'])
 print(json.dumps(out,indent=2))
