from filled_trace import *
import json
out={'domains':0,'side_slots':0,'corner_slots':0,'passed':True}
for diag in [lambda x,y:True,lambda x,y:False,lambda x,y:(x+y)%2==0]:
 for mask in range(1,512):
  S={(i%3,i//3) for i in range(9) if mask>>i&1}
  if not connected(S,diag):continue
  D=fill_holes(S,diag);xs=[x for x,y in D];ys=[y for x,y in D];a,b,c,d=min(xs),max(xs),min(ys),max(ys)
  span=b-a+d-c+2;P=len(boundary(D));side=corner=0
  for z in set(u for v in D for u in neighbors(v,diag))-D:
   x,y=z;ox=x<a or x>b;oy=y<c or y>d
   if not(ox or oy):continue
   k=sum((x+dx,y+dy) in D for dx,dy in D4)
   new=fill_holes(D|{z},diag);ns=max(x for x,y in new)-min(x for x,y in new)+max(y for x,y in new)-min(y for x,y in new)+2
   if ox and oy:corner+=1;assert k==0 and ns==span+2
   else:side+=1;assert k<=1 and ns==span+1
   for H in (span,span+1):
    if ns>H:assert P>=(2*H-2 if ox and oy else 2*H)
  assert side<=2*span<=P and corner<=4
  out['domains']+=1;out['side_slots']+=side;out['corner_slots']+=corner
print(json.dumps(out,indent=2))
