"""CONDITIONAL implication only: assumes an independently proved rho<exp(K)."""
from fractions import Fraction as F
from math import factorial,log
from pathlib import Path
import runpy,io,contextlib,json
# Prove e<87/32 using explicit factorial tail.
N=12
upper_e=sum((F(1,factorial(k)) for k in range(N+1)),F(0))+F(1,factorial(N+1))/(1-F(1,N+2))
assert upper_e<F(87,32)
assert sum((F(7,10)**k/F(factorial(k)) for k in range(20)),F(0))>2
assert 22000000>1+F(836,100)*2560000
with contextlib.redirect_stdout(io.StringIO()):d=runpy.run_path(str(Path(__file__).with_name('renewal_box164_raw_faces.py')))
p=d['p'];G=d['G'];core=G/(1-G);results=[]
for K in [1000,1004,1010]:
 M=22000000*F(87,32)**K
 outside=p*F(1,10**7)*M
 total=core+outside
 assert total<F(1087,10**10)
 results.append({'ASSUMED_log_congestion_upper':K,'uniform_mean_log_upper_diagnostic':log(M.numerator)-log(M.denominator),'outside_numerator_correction_upper':float(outside),'total_numerator_excess_upper':float(total),'exact_total_excess_less_than':'1.087e-7'})
print(json.dumps({'status':'CONDITIONAL scalar corollary, not proof of the congestion assumption.','native_clock':'Per-site heatbath; lambda_a<1e-7.','mean_from_congestion':'M<22000000*rho','core_box':164,'results':results},indent=2))
