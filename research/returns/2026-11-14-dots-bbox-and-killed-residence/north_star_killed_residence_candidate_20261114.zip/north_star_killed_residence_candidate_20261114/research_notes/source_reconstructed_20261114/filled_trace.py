"""Fixed-triangulation filled-domain validator allowing repeated vertices.
Coordinate convention: primal site(x,y) occupies unitcell[x,x+1]×[y,y+1].
Physical dual direction alphabetE,N,W,S. Not a word-proposal sampler.
"""
from perimeter_core import boundary,edge_end,D4
from collections import defaultdict

def neighbors(v,diag):
 x,y=v
 for dx,dy in [(1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,-1),(1,-1),(-1,1)]:
  if dx and dy:
   ax=x+min(dx,0);ay=y+min(dy,0)
   if bool(diag(ax,ay))!=(dx==dy):continue
  yield x+dx,y+dy

def connected(S,diag):
 if not S:return False
 seen={min(S)};todo=list(seen)
 while todo:
  for u in neighbors(todo.pop(),diag):
   if u in S and u not in seen:seen.add(u);todo.append(u)
 return seen==S

def fill_holes(S,diag):
 xs=[x for x,y in S];ys=[y for x,y in S];a,b,c,d=min(xs)-1,max(xs)+1,min(ys)-1,max(ys)+1
 seen={(a,c)};todo=list(seen)
 while todo:
  for u in neighbors(todo.pop(),diag):
   if a<=u[0]<=b and c<=u[1]<=d and u not in S and u not in seen:seen.add(u);todo.append(u)
 return {(x,y) for x in range(a+1,b) for y in range(c+1,d) if (x,y) not in seen}

def boundary_cycles(S,diag):
 E=boundary(S);incoming=defaultdict(list);outgoing=defaultdict(list)
 for e in E:incoming[edge_end(e)].append(e);outgoing[e[:2]].append(e)
 nxt={}
 for v,inc in incoming.items():
  out=outgoing[v];assert len(inc)==len(out)
  if len(out)==1:nxt[inc[0]]=out[0]
  elif len(out)==2:
   x,y=v;sw=(x-1,y-1) in S;ne=(x,y) in S;se=(x,y-1) in S;nw=(x-1,y) in S
   assert (sw and ne and not se and not nw) or (se and nw and not sw and not ne)
   plus_joined=(sw and ne and bool(diag(x-1,y-1))) or (se and nw and not bool(diag(x-1,y-1)))
   turn=-1 if plus_joined else 1
   for e in inc:
    candidates=[f for f in out if f[2]==(e[2]+turn)%4];assert len(candidates)==1;nxt[e]=candidates[0]
  else:raise AssertionError('invalid physical boundary degree')
 unused=set(E);cycles=[]
 while unused:
  first=min(unused);e=first;cycle=[]
  while True:
   assert e in unused;unused.remove(e);cycle.append(e);e=nxt[e]
   if e==first:break
  cycles.append(tuple(cycle))
 return cycles

def filled_domain_from_steps(steps,diag,start=(0,0)):
 x,y=start;path=[];seen=set()
 for direction in steps:
  if direction not in range(4):return None
  e=(x,y,direction)
  if e in seen:return None
  seen.add(e);path.append(e);dx,dy=D4[direction];x+=dx;y+=dy
 if (x,y)!=start or len(path)<4:return None
 # Derive cell occupancy by integer winding, preserving vertex contacts.
 xs=[e[0] for e in path];ys=[e[1] for e in path]
 a,b,c,d=min(xs),max(xs),min(ys),max(ys);S=set()
 for yy in range(c,d):
  wind=0
  for xx in range(b-1,a-1,-1):
   wind+=((xx+1,yy,1) in seen)-((xx+1,yy+1,3) in seen)
   if wind not in (0,1):return None
   if wind:S.add((xx,yy))
  wind+=((a,yy,1) in seen)-((a,yy+1,3) in seen)
  if wind:return None
 if not S or boundary(S)!=seen or not connected(S,diag) or fill_holes(S,diag)!=S:return None
 cycles=boundary_cycles(S,diag)
 if len(cycles)!=1:return None
 actual=cycles[0]
 # Both traces visit every edge exactlyonce. Validate successor map, independentofstartrotation.
 successor={actual[i]:actual[(i+1)%len(actual)] for i in range(len(actual))}
 if any(successor[path[i]]!=path[(i+1)%len(path)] for i in range(len(path))):return None
 return S

if __name__=='__main__':
 import json,time
 start=time.time();count=0;touches=0
 for name,diag in [('NE',lambda x,y:True),('NW',lambda x,y:False),('alternating',lambda x,y:(x+y)%2==0)]:
  for mask in range(1,512):
   S={(i%3,i//3) for i in range(9) if mask>>i&1}
   if not connected(S,diag):continue
   D=fill_holes(S,diag);cycles=boundary_cycles(D,diag);assert len(cycles)==1
   cycle=cycles[0];assert filled_domain_from_steps([e[2] for e in cycle],diag,cycle[0][:2])==D
   touches+=len({e[:2] for e in cycle})<len(cycle);count+=1
 S={(0,0),(1,1)};cycle=boundary_cycles(S,lambda x,y:True)[0]
 assert len(cycle)==8 and len({e[:2] for e in cycle})==7
 assert filled_domain_from_steps([e[2] for e in cycle],lambda x,y:True,cycle[0][:2])==S
 assert filled_domain_from_steps([e[2] for e in cycle],lambda x,y:False,cycle[0][:2]) is None
 print(json.dumps({'connected_masks_checked':count,'accepted_vertex_touching_traces':touches,'explicit_figure8_accepts_correct_diagonal_rejects_wrong':True,'seconds':time.time()-start},indent=2))
