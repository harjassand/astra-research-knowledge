"""Finite-state diagnostic of exact hard-allminus architecture; no R200 timing claim."""
from seed_transition import *
I=np.eye(d);_,P0,_,r0,_=matrices(0)
psoft=solve(I-P0,r0);msoft=solve(I-P0,np.ones(d)/Lam)
keep=[j for j,x in enumerate(D) if x!=0];pos={j:k for k,j in enumerate(keep)}
Ph=np.zeros((len(keep),len(keep)));rh=np.zeros(len(keep))
for k,j in enumerate(keep):
 x=D[j];Ph[k,k]+=sum(1-c[j])/n
 for i in range(n):
  y=x^(1<<i)
  if B(y):rh[k]+=c[j,i]/n
  elif y:Ph[k,pos[idx[y]]]+=c[j,i]/n
qh=solve(np.eye(len(keep))-Ph,rh);mh=solve(np.eye(len(keep))-Ph,np.ones(len(keep))/n)
Cratio=sum(c[idx[0],i]*qh[pos[idx[1<<i]]] for i in range(n))
muH=mu[keep]
# direct whole mean solves original killed-atB generator, no sourcekill.
Pfull=np.zeros((d,d))
for j,x in enumerate(D):
 Pfull[j,j]=sum(1-c[j])/n
 for i in range(n):
  y=x^(1<<i)
  if not B(y):Pfull[j,idx[y]]+=c[j,i]/n
u=solve(np.eye(d)-Pfull,np.ones(d)/n)
h=np.ones(d);h[keep]=1-qh
Nratio=float((w/w[idx[0]])@h)
Thard=Nratio/Cratio
assert abs(Thard/u[idx[0]]-1)<1e-8
out={'native_model':{'L':3,'theta':theta,'field':field,'rate_per_site':1},'soft_seed_success':float(mu@psoft),'soft_seed_duration':float(mu@msoft),'hard_seed_success':float(muH@qh),'hard_seed_duration':float(muH@mh),'hard_capacity_over_wminus':float(Cratio),'hard_residence_over_wminus':Nratio,'full_mean_via_N_over_C':Thard,'full_mean_direct_linear_system':float(u[idx[0]]),'identity_relative_error':float(abs(Thard/u[idx[0]]-1)),'scope':'Finite exact linear systems evaluated in float; hard-source architecture, not soft capacity equality orR200decisionbound'}
print(json.dumps(out,indent=2))
