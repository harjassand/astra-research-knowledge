"""Certifies only rate-table rounding error, not RNG/time/categorical implementation."""
from source import F,expneg_bounds
from scipy.special import expit
import json

def plus_bounds(k):
 a=F(16*k-32)+F(1,25);lo,hi=expneg_bounds(abs(a),128);lo,hi=lo/(1+lo),hi/(1+hi)
 return (lo,hi) if a<=0 else (1-hi,1-lo)
p=[float(expit(16*k-32+.04)) for k in range(5)];bounds=[plus_bounds(k) for k in range(5)]
worst=F(0);arg=None
for kl in range(5):
 for ku in range(kl,5):
  ll,lh=bounds[kl];ul,uh=bounds[ku]
  br=[(1-uh,1-ul),(ul-lh,uh-ll),(ll,lh)]
  if kl==ku:br[1]=(F(0),F(0))
  floats=[1-p[ku],p[ku]-p[kl],p[kl]]
  for state in range(3):
   err=F(0)
   for j in range(3):
    if j==state:continue
    value=F.from_float(max(floats[j],0.0));lo,hi=br[j]
    err+=max(abs(value-lo),abs(value-hi))
   if err>worst:worst=err;arg=(kl,ku,state)
bound=2560000*100*worst
assert bound<F(1,10**6)
print(json.dumps({'rate_table_only':True,'per_site_total_rate_error_upper':float(worst),'worst_class':arg,'L1600_time100_generator_path_TV_upper':float(bound),'rational_check_less_than_1e_6':True,'not_certified':['RNG_discretization','floating_categorical_selection','floating_holding_time_generation','total_algorithm_TV'],'interpretation':'rate error small for coarse pilot, not automatically small versus e^-18 rare committor mean'},indent=2))
