"""Auxiliary raw square-face decomposition, NOT original graph fill."""
from filled_trace import connected,boundary_cycles
from perimeter_core import boundary
from fractions import Fraction as F
import json,time
D4=[(1,0),(-1,0),(0,1),(0,-1)]
def components(S):
 S=set(S);out=[]
 while S:
  seen={min(S)};todo=list(seen)
  while todo:
   x,y=todo.pop()
   for dx,dy in D4:
    u=x+dx,y+dy
    if u in S and u not in seen:seen.add(u);todo.append(u)
  S-=seen;out.append(seen)
 return out
def decompose(S):
 a=min(x for x,y in S)-1;b=max(x for x,y in S)+1;c=min(y for x,y in S)-1;d=max(y for x,y in S)+1
 holes=[H for H in components({(x,y) for x in range(a,b+1) for y in range(c,d+1)}-S) if not any(x in(a,b) or y in(c,d) for x,y in H)]
 return S.union(*holes),holes
def plus_resolution(S):
 return lambda x,y: ((x,y) in S and(x+1,y+1) in S) or not ((x+1,y) in S and(x,y+1) in S)
def energy(S):return 8*len(boundary(S))-F(len(S),25)
t=time.time();count=holescount=touch=0
for mask in range(1,1<<12):
 S={(i%4,i//4) for i in range(12) if mask>>i&1}
 if not any(connected(S,diag) for diag in [lambda x,y:True,lambda x,y:False,lambda x,y:(x+y)%2==0]):continue
 F0,hs=decompose(S);outer=boundary_cycles(F0,plus_resolution(F0));assert len(outer)==1
 for H in hs:assert len(boundary_cycles(H,plus_resolution(H)))==1
 assert len(boundary(S))==len(boundary(F0))+sum(len(boundary(H)) for H in hs)
 assert energy(S)==energy(F0)+sum(8*len(boundary(H))+F(len(H),25) for H in hs)
 count+=1;holescount+=len(hs);touch+=len(set(e[:2] for e in outer[0]))<len(outer[0])
print(json.dumps({'polymers':count,'raw_holes':holescount,'touching_outer_walks':touch,'auxiliary_face_exact_factorization':True,'seconds':time.time()-t},indent=2))
