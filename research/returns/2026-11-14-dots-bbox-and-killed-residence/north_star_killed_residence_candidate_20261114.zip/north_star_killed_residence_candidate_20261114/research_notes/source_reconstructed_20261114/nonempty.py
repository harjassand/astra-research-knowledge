"""Exact Gibbs core conditional on at least one plus spin; not flux tilt."""
from source import *

def positive_poisson():
    u=Uniform();bits=64
    while True:
        lo,hi=expneg_bounds(G,bits)
        assert hi<1
        u.refine();ul,uh=u.bounds();term=G;summ=G;k=1
        while True:
            lower=lo*summ/(1-lo)
            upper=hi*summ/(1-hi)
            if uh<=lower:return k
            if ul<upper:break
            k+=1;term*=G/k;summ+=term
        bits+=32

def sample_nonempty(core_sites=5):
    assert core_sites in (5,6)
    attempts=0
    while True:
        attempts+=1;polys=[]
        for _ in range(positive_poisson()):
            s=mark(core_sites)
            if s is not None:polys.append(s)
        if not polys:continue
        union=set();valid=True
        for s in polys:
            if any(v in union or any(((v[0]+dx)%L,(v[1]+dy)%L) in union for dx,dy in DIR) for v in s):valid=False;break
            union|=s
        if valid:return union,attempts

if __name__=='__main__':
    zlo,zhi=expneg_bounds(F(799,25),160)
    elo,ehi=expneg_bounds(G,160)
    # All singleton configurations alone supply the acceptance lower bound.
    lower=L*L*zlo*elo/(1-elo)
    assert lower>F(3,10)
    out={'acceptance_lower_gt_0_3':True,'numerical_lower':float(lower),'experiments':[]}
    for box in (5,6):
        start=time.time();hist={};attempts=0
        for _ in range(2000):
            s,a=sample_nonempty(box);attempts+=a
            assert s and validate_lift(s,box) # These observed outputs have one component.
            hist[len(s)]=hist.get(len(s),0)+1
        out['experiments'].append({'box_sites':box,'draws':2000,'attempts':attempts,'size_histogram':hist,'seconds':time.time()-start})
    print(json.dumps(out,indent=2))
