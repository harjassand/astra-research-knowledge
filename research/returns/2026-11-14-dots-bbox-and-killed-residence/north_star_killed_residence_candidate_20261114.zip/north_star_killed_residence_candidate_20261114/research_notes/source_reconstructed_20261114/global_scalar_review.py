"""Independent exact scalar audit of phase assembly.
Static K<878 and strip marked<191 are separately directed computational inputs.
"""
from fractions import Fraction as F
from math import factorial
import json

def exp_lower(x,terms=240):return sum((F(x)**k/F(factorial(k)) for k in range(terms)),F(0))
n=2560000
assert 200*n**5<exp_lower(80) #100n^4 records, length2n
assert exp_lower(F(1,50))>F(765151,750000)
for r in [F(201,200),F(101,100),F(51,50)]:assert exp_lower(F(1,50))>r
assert exp_lower(8)>2980
cylinder=16+F(1280001,2980);assert cylinder<446
row=32+F(401,2980);assert row<F(32135,1000)
# e^.04 <= 1/(1-.04)=25/24, so native inverse deletion<=49/24.
erosionfactor=2*n*F(49,24)*80200*400
assert erosionfactor<exp_lower(F(169,5)) #log factor<33.8
erosionlog=F(878)+F(32135,1000)+F(169,5)+F(1,10**6)
assert erosionlog<944
phase={'erosion':944,'bootstrap':878+32+1+80+1,'prewrap':191+16+17+80+1,'cylinder':446+80+17+80+1}
assert phase=={'erosion':944,'bootstrap':992,'prewrap':305,'cylinder':624}
assert exp_lower(2)>4
print(json.dumps({'status':'Scalar audit passed; analytic path and static contour inputs listed separately.','record_length_log_upper':80,'erosion_simple_log_upper':str(erosionlog),'cylinder_simple_log_upper':str(cylinder),'phase_log_uppers':phase,'sum_log_upper':994,'relaxed_total_log_upper':1000,'rational_tilt_admissibility':True,'static_inputs':['hull_entropy_bound.py/json: logK<878, saved upward magnetic moments','strip_walk_bound.py/json: marked log<191, companion/hole gas<1','core650_occupation.py/json: original small-component gas<1e-6'],'finite_tests_not_used_as_proof':True},indent=2))
