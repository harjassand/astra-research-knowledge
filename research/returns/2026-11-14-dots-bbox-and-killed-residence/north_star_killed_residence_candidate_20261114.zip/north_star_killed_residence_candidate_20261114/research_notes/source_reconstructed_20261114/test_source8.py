from source8 import *
from itertools import combinations
import json,time
orientations={'uniform_NE':lambda x,y:True,'uniform_NW':lambda x,y:False,'alternating':lambda x,y:(x+y)%2==0}
results={'exhaustive_small':[],'R200_draws':[]}
for name,diag in orientations.items():
 c=Core(5,2,diag);verts=[(x,y) for x in range(5) for y in range(5)];tested=valid=0;codes=set()
 for v in verts:
  for j in range(8):assert c.allowed(v,j)==c.allowed(c.step(v,j),j^1)
 for a in range(1,5):
  lo,hi=expneg_bounds(F(16*(isqrt(4*a)+(isqrt(4*a)**2<4*a)))-F(a,25),160);assert hi<=c.b[a]
  for tup in combinations(verts,a):
   S=set(tup);tested+=1
   if not c.valid(S):continue
   valid+=1;root,code=c.canonical(S)
   assert len(code)==2*(a-1)
   assert c.decode(root,code,a)==S
   assert (root,code) not in codes;codes.add((root,code))
 results['exhaustive_small'].append({'orientation':name,'subsets_tested':tested,'valid_connected_polymers':valid,'edge_symmetry':True,'canonical_inverse_and_unique':True})
 for box in (5,6):
  c=Core(1600,box,diag)
  for a in range(1,c.A+1):
   t=isqrt(4*a);t+=t*t<4*a
   assert expneg_bounds(F(16*t)-F(a,25),160)[1]<=c.b[a]
  elo,ehi=expneg_bounds(c.G,160);zlo,zhi=expneg_bounds(F(799,25),160)
  lower=1600**2*zlo*elo/(1-elo)
  assert lower>F(31,100)
  assert elo>F(99999989,100000000)
  attempts=0;hist={};start=time.time()
  for _ in range(1000):
   S,k=c.sample(nonempty=True);attempts+=k;hist[len(S)]=hist.get(len(S),0)+1
  results['R200_draws'].append({'orientation':name,'box_sites':box,'gamma':float(c.G),'acceptance_lower':float(lower),'draws_nonempty':1000,'attempts':attempts,'size_histogram':hist,'seconds':time.time()-start})
print(json.dumps(results,indent=2))
