from fractions import Fraction as F
from math import factorial,isqrt
import secrets,json,time
from functools import lru_cache
DIR=((1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,-1))
PH=DIR[:4]
L=1600; RBOX=5; MAXA=49
b=[None]+[F(10,27)**31]+[F(10,27)**40/F(36)**(a-1) for a in range(2,50)]
w=[None]+[L*L*F(10,27)**31]+[L*L*F(10,27)**40 for a in range(2,50)]
G=sum(w[1:])
@lru_cache(maxsize=512)
def expneg_bounds(x,bits=100):
    assert x>=0
    # range reduction, alternating Taylor, exact rational squaring
    s=0
    while x>F(1,2):x/=2;s+=1
    term=F(1); total=F(1); k=0
    target=F(1,2**(bits+s+5))
    while True:
        k+=1;term*=-x/k;total+=term
        nxt=term*(-x)/(k+1)
        lo,hi=sorted((total,total+nxt))
        if abs(nxt)<target:break
    for _ in range(s):lo*=lo;hi*=hi
    return lo,hi
class Uniform:
    def __init__(self): self.k=0;self.n=0
    def refine(self):self.n=(self.n<<32)|secrets.randbits(32);self.k+=32
    def bounds(self):return F(self.n,1<<self.k),F(self.n+1,1<<self.k)
def exp_bernoulli(x,scale=F(1)):
    u=Uniform();bits=64
    while True:
        lo,hi=expneg_bounds(x,bits);lo*=scale;hi*=scale
        assert hi>=0
        u.refine();ul,uh=u.bounds()
        if uh<=lo:return True
        if ul>=hi:return False
        bits+=32

def poisson():
    u=Uniform();bits=64
    while True:
        lo,hi=expneg_bounds(G,bits)
        u.refine();ul,uh=u.bounds();term=F(1);summ=F(1);k=0
        while True:
            if uh<=lo*summ:return k
            if ul<hi*summ:break
            k+=1;term*=G/k;summ+=term
        bits+=32

def rational_choice(weights):
    den=1
    from math import lcm
    for a in weights:den=lcm(den,a.denominator)
    ints=[a.numerator*(den//a.denominator) for a in weights]
    q=secrets.randbelow(sum(ints))
    for i,a in enumerate(ints):
        if q<a:return i
        q-=a

def canonical(S):
    root=min(S);seen={root};out=[]
    def dfs(v):
        for j,(dx,dy) in enumerate(DIR):
            y=((v[0]+dx)%L,(v[1]+dy)%L)
            if y in S and y not in seen:
                seen.add(y);out.append(j);dfs(y);out.append(j^1)
    dfs(root)
    return root,tuple(out)
def validate_lift(S,box=RBOX):
    root=min(S);lift={root:(0,0)};stack=[root]
    while stack:
        x=stack.pop();v=lift[x]
        for dx,dy in DIR:
            y=((x[0]+dx)%L,(x[1]+dy)%L)
            if y not in S:continue
            t=(v[0]+dx,v[1]+dy)
            if y in lift:
                if lift[y]!=t:return False
            else:lift[y]=t;stack.append(y)
    if len(lift)!=len(S):return False
    return all(max(v[d] for v in lift.values())-min(v[d] for v in lift.values())+1<=box for d in (0,1))
def perimeter(S):return sum(((x+dx)%L,(y+dy)%L) not in S for x,y in S for dx,dy in PH)
def mark(core_sites=RBOX):
    a=1+rational_choice(w[1:]);root=(secrets.randbelow(L),secrets.randbelow(L));code=tuple(secrets.randbelow(6) for _ in range(2*(a-1)))
    v=root;S={v}
    for j in code:
        dx,dy=DIR[j];v=((v[0]+dx)%L,(v[1]+dy)%L);S.add(v)
    if v!=root or len(S)!=a or not validate_lift(S,core_sites) or canonical(S)!=(root,code):return None
    p=perimeter(S);x=F(8*p)-F(a,25)
    if not exp_bernoulli(x,1/b[a]):return None
    return S

def sample(core_sites=RBOX):
    assert core_sites in (5,6), "Resolve governing rectangle convention explicitly"
    attempts=0
    while True:
        attempts+=1;polys=[]
        for _ in range(poisson()):
            s=mark(core_sites)
            if s is not None:polys.append(s)
        union=set();valid=True
        for s in polys:
            if any(v in union or any(((v[0]+dx)%L,(v[1]+dy)%L) in union for dx,dy in DIR) for v in s):valid=False;break
            union|=s
        if valid:return union,attempts

def tests():
    env=[]
    for a in range(1,50):
        t=isqrt(4*a);t+=t*t<4*a;p=2*t
        lo,hi=expneg_bounds(F(8*p)-F(a,25),200)
        assert hi<=b[a],a
        env.append(a)
    assert validate_lift({(1599,0),(0,0)})
    assert not validate_lift({(x,0) for x in range(6)})
    for s in [{(0,0)},{(0,0),(1,0)},{(0,0),(1,1)}, {(x,y) for x in range(5) for y in range(5)}]:
        root,code=canonical(s);v=root;t={v}
        for j in code:
            dx,dy=DIR[j];v=((v[0]+dx)%L,(v[1]+dy)%L);t.add(v)
        assert t==s and v==root and len(code)==2*(len(s)-1)
    return {'envelope_sizes_verified':env,'gamma_upper':float(G),'core_convention':'site-count box width max-min+1<=5, pending governing-source confirmation'}
if __name__=='__main__':
    out=tests();t=time.time();out['draws']=10000;out['nonempty']=0;out['attempts']=0
    for _ in range(out['draws']):
        s,a=sample();out['nonempty']+=bool(s);out['attempts']+=a
    out['seconds']=time.time()-t
    print(json.dumps(out,indent=2))
