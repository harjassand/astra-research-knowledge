from source8 import Core,DIR
import json
L=9;H=6
out={'L':L,'H':H,'embedded_additions':0,'isolated_structural_gates':0,'winding_gates':0,'max_gate_k':0}
def lift(c,S):
 root=min(S);coords={root:(0,0)};stack=[root]
 while stack:
  v=stack.pop()
  for j,(dx,dy) in enumerate(DIR):
   if not c.allowed(v,j):continue
   u=c.step(v,j)
   if u not in S:continue
   q=(coords[v][0]+dx,coords[v][1]+dy)
   if u in coords:
    if coords[u]!=q:return None
   else:coords[u]=q;stack.append(u)
 if len(coords)!=len(S):return False
 return coords
for pattern in [lambda x,y:True,lambda x,y:False,lambda x,y:(x+y)%2==0]:
 c=Core(L,4,pattern)
 for shift in (0,8):
  block=[((shift+x)%L,(shift+y)%L) for x in range(3) for y in range(3)]
  for mask in range(1,512):
   S={block[i] for i in range(9) if mask>>i&1};old=lift(c,S)
   if old is False or old is None:continue
   assert sum(max(v[d] for v in old.values())-min(v[d] for v in old.values())+1 for d in (0,1))<=H
   for z in set(u for v in S for u in c.neighbors(v))-S:
    new=lift(c,S|{z});out['embedded_additions']+=1
    if new is None:out['winding_gates']+=1;raise AssertionError('unexpected winding')
    assert new is not False
    span=sum(max(v[d] for v in new.values())-min(v[d] for v in new.values())+1 for d in (0,1))
    if span>H:
     out['isolated_structural_gates']+=1
     k=sum(c.step(z,j) in S for j in range(4));assert k<=1
     out['max_gate_k']=max(out['max_gate_k'],k)
assert out['isolated_structural_gates']>0
print(json.dumps(out,indent=2))
