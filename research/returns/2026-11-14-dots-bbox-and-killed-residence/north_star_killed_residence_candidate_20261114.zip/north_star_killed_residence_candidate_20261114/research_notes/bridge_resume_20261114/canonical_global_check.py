"""Scaled torus geometry/reconstruction check; not large-system contour proof."""
import random,json,time
from pathlib import Path
L=9;b=3;n=L*L;target=(n+1)//2;rng=random.Random(910732)
NN=[(1,0),(-1,0),(0,1),(0,-1)];AUG=NN+[(1,1),(-1,-1)]
def pid(v):return (v[1]%L)*L+v[0]%L
def xy(i):return i%L,i//L
def adjacent(i,dirs):
 x,y=xy(i);return [pid((x+dx,y+dy))for dx,dy in dirs]
def energy(S):return 200*sum(j not in S for i in S for j in adjacent(i,NN))-len(S)
def components(x):
 rem=set(x);out=[]
 while rem:
  root=min(rem);rem.remove(root);C={root};todo=[root]
  while todo:
   i=todo.pop()
   for j in adjacent(i,AUG):
    if j in rem:rem.remove(j);C.add(j);todo.append(j)
  out.append(C)
 return out
def explore(C):
 root=min(C);coords={root:xy(root)};queue=[root];seq=[coords[root]];lo=list(seq[0]);hi=list(seq[0])
 for i in queue:
  x,y=coords[i]
  for dx,dy in AUG:
   v=(x+dx,y+dy);j=pid(v)
   if j not in C or j in coords:continue
   coords[j]=v;queue.append(j);seq.append(v)
   lo=[min(lo[k],v[k])for k in[0,1]];hi=[max(hi[k],v[k])for k in[0,1]]
   if max(hi[k]-lo[k]+1 for k in[0,1])>=b:return seq,coords,False
 return seq,coords,True
stats=dict(cases=0,allminus=0,majority=0,updates=0,small_components_erased=0,crossing_T_records=0,wrap_reached=0)
for trial in range(3000):
 density=[.03,.10,.20,.35,.46][trial%5];x={i for i in range(n)if rng.random()<density}
 if len(x)>=target:continue
 stats['cases']+=1;z=set(x);T=set();U=set();updates=0;done=False
 def check():
  global updates
  xp=x-T
  assert U<=z and z-U==xp-U
  assert (z-U)|(xp&U)|T==x
  assert energy(x)==energy(T)+energy(xp)
  if T&U and T-U:stats['crossing_T_records']+=1
 def add(v):
  global done,updates
  i=pid(v);check();U.add(i)
  if i not in z:z.add(i);updates+=1
  check()
  if len(z)>=target:done=True
 for C in components(x):
  seq,coords,small=explore(C)
  if small:
   for i in sorted(C,key=lambda j:(-coords[j][1],coords[j][0])):
    assert sum(j in z for j in adjacent(i,NN))<=2;z.remove(i);updates+=1
   T|=C;stats['small_components_erased']+=1
   if not z:done=True;break
   continue
  lo=list(seq[0]);hi=list(seq[0]);add(seq[0])
  for v in seq[1:]:
   if done:break
   lo=[min(lo[k],v[k])for k in[0,1]];hi=[max(hi[k],v[k])for k in[0,1]];add(v)
   rect=[(xx,yy)for yy in range(lo[1],hi[1]+1)for xx in range(lo[0],hi[0]+1)]
   while not done and any(pid(a)not in U for a in rect):
    candidates=[a for a in rect if pid(a)not in U and sum(pid((a[0]+dx,a[1]+dy))in U for dx,dy in NN)>=2]
    assert candidates;add(min(candidates,key=lambda a:(a[1],a[0])))
  if done:break
  swap=hi[0]-lo[0]+1!=b
  if swap:lo=lo[::-1];hi=hi[::-1]
  def physical(a):return a[::-1]if swap else a
  width=hi[0]-lo[0]+1;assert width==b
  while not done and hi[1]-lo[1]+1<L:
   hi[1]+=1
   for xx in range(lo[0],hi[0]+1):
    if done:break
    v=physical((xx,hi[1]));assert sum(j in z for j in adjacent(pid(v),NN))>=1;add(v)
  if not done:stats['wrap_reached']+=1
  while not done:
   hi[0]+=1;assert hi[0]-lo[0]+1<=(L+1)//2
   for yy in range(lo[1],hi[1]+1):
    if done:break
    v=physical((hi[0],yy));assert sum(j in z for j in adjacent(pid(v),NN))>=1;add(v)
  break
 assert not z or len(z)>=target;assert updates<=2*n
 stats['updates']+=updates;stats['allminus']+=not z;stats['majority']+=len(z)>=target
stats.update(L=L,seed_threshold=b,scope='Randomscaledtorus tests of ORIGINALcomponentclassification, erase/grow paths, TcrossU reconstruction, firstmajority stopping andlength. Not contour/congestion proof.')
Path(__file__).with_suffix('.json').write_text(json.dumps(stats,indent=2));print(json.dumps(stats,indent=2))
