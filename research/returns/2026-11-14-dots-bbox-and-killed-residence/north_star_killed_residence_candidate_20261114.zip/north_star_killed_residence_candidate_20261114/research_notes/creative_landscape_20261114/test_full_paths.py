"""Independent finite canonical construction: exhaustive 4x4 plus larger random tori.
Thresholds scaled to2/3; geometry, target and reconstruction checks, not R200 constants.
"""
import json,random,time
DIR=[(1,0),(0,1),(-1,0),(0,-1),(1,1),(-1,-1)]
NN=DIR[:4]
stats={'initial_states':0,'native_flips':0,'growth_paths':0,'wrapped_paths':0,'history_crossing_U':0,'max_path_length':0}
def run(X,L,C):
 X=set(X); z=set(X);T=set();n=L*L;steps=0
 def phys(a):return (a[0]%L,a[1]%L)
 def components():
  todo=set(X);out=[]
  while todo:
   root=min(todo);s={root};q=[root];todo.remove(root)
   for p in q:
    for d in DIR:
     a=phys((p[0]+d[0],p[1]+d[1]))
     if a in todo:todo.remove(a);s.add(a);q.append(a)
   out.append(s)
  return out
 def explore(comp):
  root=min(comp);lift={root:root};q=[root];pref=[root]
  for p in q:
   for d in DIR:
    a=phys((p[0]+d[0],p[1]+d[1]))
    if a not in comp or a in lift:continue
    v=(lift[p][0]+d[0],lift[p][1]+d[1]);lift[a]=v;q.append(a);pref.append(v)
    if max(max(b[k] for b in pref)-min(b[k] for b in pref)+1 for k in [0,1])>=C:return pref,True
  assert len(lift)==len(comp)
  return pref,False
 def native(v,add):
  nonlocal steps
  v=phys(v)
  assert (v not in z) if add else (v in z)
  if add:z.add(v)
  else:z.remove(v)
  steps+=1;stats['native_flips']+=1
  assert steps<=2*n
  return len(z)>=n/2 or not z
 def check(U,sw=False):
  P={phys((v[1],v[0]) if sw else v) for v in U}
  assert P<=z
  S=(X-T)&P
  assert (z-P)|S|T==X
  if T&P and T-P:stats['history_crossing_U']+=1
  return P
 for comp in components():
  pref,large=explore(comp)
  if not large:
   for v in sorted(pref,key=lambda a:(-a[1],a[0])):
    p=phys(v);k=sum(phys((p[0]+d[0],p[1]+d[1])) in z for d in NN)
    assert k<=2
    if native(v,False):
     assert not z
     stats['initial_states']+=1;stats['max_path_length']=max(stats['max_path_length'],steps);return
   T|=comp
   continue
  stats['growth_paths']+=1
  U={pref[0]};seen={pref[0]};check(U)
  for witness in pref[1:]:
   seen.add(witness)
   if witness in U:continue
   U.add(witness);check(U)
   xmin,xmax=min(x for x,y in U),max(x for x,y in U);ymin,ymax=min(y for x,y in U),max(y for x,y in U)
   R={(x,y) for x in range(xmin,xmax+1) for y in range(ymin,ymax+1)}
   while U!=R:
    elig=[v for v in R-U if sum((v[0]+d[0],v[1]+d[1]) in U for d in NN)>=2]
    assert elig
    v=min(elig);p=phys(v)
    if p not in z:
     done=native(v,True);U.add(v);check(U)
     if done:
      stats['initial_states']+=1;stats['max_path_length']=max(stats['max_path_length'],steps);return
    else:U.add(v);check(U)
  xmin,xmax=min(x for x,y in U),max(x for x,y in U);ymin,ymax=min(y for x,y in U),max(y for x,y in U)
  sw=xmax-xmin+1!=C
  if sw:U={(y,x) for x,y in U}
  xmin,xmax=min(x for x,y in U),max(x for x,y in U);ymin,ymax=min(y for x,y in U),max(y for x,y in U)
  assert xmax-xmin+1==C
  def add_uv(v):
   p=(v[1],v[0]) if sw else v
   if phys(p) not in z:
    done=native(p,True);U.add(v);check(U,sw);return done
   U.add(v);check(U,sw);return False
  for yy in range(ymax+1,ymin+L):
   for xx in range(xmin,xmax+1):
    if add_uv((xx,yy)):
     stats['initial_states']+=1;stats['max_path_length']=max(stats['max_path_length'],steps);return
  stats['wrapped_paths']+=1
  for xx in range(xmax+1,xmin+L):
   for yy in range(ymin,ymin+L):
    if add_uv((xx,yy)):
     stats['initial_states']+=1;stats['max_path_length']=max(stats['max_path_length'],steps);return
  raise AssertionError('failed to reach target')
start=time.time()
for m in range(1,1<<16):
 if m.bit_count()<8:run({(i%4,i//4) for i in range(16) if m>>i&1},4,2)
r=random.Random(419)
for L,C in [(8,3),(10,3),(12,4)]:
 for _ in range(400):
  p=r.uniform(.01,.48);X={(x,y) for x in range(L) for y in range(L) if r.random()<p}
  if 0<len(X)<L*L/2:run(X,L,C)
# Explicit winding diagonal, thin cross, vertical stripe, and companion-rich variants.
for L,C in [(8,3),(12,4)]:
 for X in [{(x,x) for x in range(L)}, {(0,y) for y in range(L)}, {(x,0) for x in range(L)}|{(0,y) for y in range(L)}]:
  run(X,L,C)
stats['runtime_seconds']=time.time()-start
stats['scope']='finite scaled-threshold geometry/reconstruction tests only; not full-size scalar or analytic proof'
print(json.dumps(stats,indent=2))
