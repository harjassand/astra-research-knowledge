"""Adversarial fixed-current overwrite record decoder and weighted subset test.
Small exact lattice boxes, all orientations, arbitrary untouched exterior.
"""
import itertools,json,random
NN=[(1,0),(-1,0),(0,1),(0,-1)]
def E(S):return 200*sum((x+dx,y+dy) not in S for x,y in S for dx,dy in NN)-len(S)
def decode(old,witness,progress):
 U=set(old)|{witness};xs=[p[0] for p in U];ys=[p[1] for p in U]
 R=set(itertools.product(range(min(xs),max(xs)+1),range(min(ys),max(ys)+1)))
 for _ in range(progress):
  elig=[p for p in R-U if sum((p[0]+dx,p[1]+dy) in U for dx,dy in NN)>=2]
  assert elig
  U.add(min(elig))
 return U,R
r=random.Random(84);count=0;subs=0;maxdef=0
for w in range(1,8):
 for h in range(1,8):
  old=set(itertools.product(range(w),range(h)))
  witnesses=({(x,-1) for x in range(w)}|{(x,h) for x in range(w)}|{(-1,y) for y in range(h)}|{(w,y) for y in range(h)}|{(-1,-1),(-1,h),(w,-1),(w,h)})
  for v in witnesses:
   U,R=decode(old,v,0)
   for progress in range(len(R-U)+1):
    U,R=decode(old,v,progress);count+=1
    diff=E(U)-E(R);maxdef=max(maxdef,diff)
    # Physical perimeter cannot exceed completed rectangle perimeter.
    assert diff<=len(R-U)
    ext={(x+dx,y+dy) for x,y in U for dx,dy in NN}-U
    for _ in range(8):
     eta={p for p in ext if r.random()<.5}
     S={p for p in U if r.random()<.5}
     cross=sum((x+dx,y+dy) in eta for x,y in U-S for dx,dy in NN)
     lhs=E(S|eta)-E(U|eta);rhs=E(S)-E(U)+400*cross
     assert lhs==rhs and lhs>=E(S)-E(U)
     subs+=1
print(json.dumps({'overwrite_records':count,'exact_conditional_subset_checks':subs,'max_isolated_energy_deficit':maxdef*.04,'all_orientations':True,'progress_decoder_uses_no_unknown_original_bits':True},indent=2))
