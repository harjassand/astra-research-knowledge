import random,json
r=random.Random(17)
R={(x,y) for x in range(4) for y in range(3)}
N=[(1,0),(-1,0),(0,1),(0,-1)]
outer={(x+dx,y+dy) for x,y in R for dx,dy in N}-R
def E(s): return 200*sum((x+dx,y+dy) not in s for x,y in s for dx,dy in N)-len(s)
for t in range(10000):
 x={p for p in R if r.random()<.5}; eta={p for p in outer if r.random()<.5}
 extra=sum((u+dx,v+dy) in eta for u,v in R-x for dx,dy in N)
 lhs=E(x|eta)-E(R|eta);rhs=E(x)-E(R)+400*extra
 assert lhs==rhs
print(json.dumps({'cases':10000,'exact_integer_energy_identity':True,'extra_bond_cost':16,'seed':17},indent=2))
