import math,json
from fractions import Fraction
import numpy as np
# Exact rational scalar certificate.
s=sum((Fraction(8)**k/Fraction(math.factorial(k)) for k in range(40)),Fraction())
assert s>2980
rational_log=Fraction(16)+Fraction(1280001,2980)
assert rational_log<446
# Check transfer energy decomposition independently for all states small cylinders.
checked=0
for w,L in [(2,3),(3,3),(4,3)]:
 def energy(mask):
  S={(x,y) for y in range(L) for x in range(w) if mask>>(y*w+x)&1}
  p=0
  for x,y in S:
   for xx,yy in [(x-1,y),(x+1,y),(x,(y-1)%L),(x,(y+1)%L)]:p+=(xx,yy) not in S
  return 200*p-len(S)
 for m in range(1<<(w*L)):
  rows=[(m>>(w*y))&((1<<w)-1) for y in range(L)]
  runs=lambda a:sum(bool(a>>i&1) and (i==0 or not(a>>(i-1)&1)) for i in range(w))
  excess=sum(400*(runs(a)-1)+(w-a.bit_count()) for a in rows)+200*sum((rows[y]^rows[(y+1)%L]).bit_count() for y in range(L))
  assert excess==energy(m)-(400-w)*L
  checked+=1
out={'exact_small_cylinder_energy_cases':checked,'exp8_Taylor_partial_sum_gt2980':True,'rational_log_upper':float(rational_log),'diagnostic_log_upper':16+1280001*math.log1p(math.exp(-8)),'scope':'full cylinder partition; not full killed congestion'}
print(json.dumps(out,indent=2))
