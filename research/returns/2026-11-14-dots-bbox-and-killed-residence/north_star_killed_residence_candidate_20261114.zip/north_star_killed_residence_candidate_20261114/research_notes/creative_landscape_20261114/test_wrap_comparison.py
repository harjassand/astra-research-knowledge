import random,json
r=random.Random(21);w=4;L=5
R={(x,y) for x in range(w) for y in range(L)}
def E(S,periodic):
 p=0
 for x,y in S:
  ns=[(x-1,y),(x+1,y),(x,(y-1)%L if periodic else y-1),(x,(y+1)%L if periodic else y+1)]
  p+=sum(v not in S for v in ns)
 return 200*p-len(S)
def B(S):return sum((x,0) in S and (x,L-1) in S for x in range(w))
for _ in range(10000):
 U={p for p in R if r.random()<.8};X={p for p in U if r.random()<.5}
 dp=E(X,True)-E(U,True);do=E(X,False)-E(U,False)
 assert dp==do+400*(B(U)-B(X)) and dp>=do
print(json.dumps({'cases':10000,'exact_integer_seam_identity':True,'deletion_comparison':True,'seed':21},indent=2))
