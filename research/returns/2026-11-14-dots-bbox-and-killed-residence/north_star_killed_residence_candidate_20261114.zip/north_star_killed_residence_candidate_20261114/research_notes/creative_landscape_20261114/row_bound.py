import numpy as np,json,math
# Explicit restricted dent birth-death chain, not native full-lattice domination.
a=1/(1+math.exp(.04));b=1-a
rows=[]
for ell in [19,63,127,399,400]:
 # Reflect0, absorb ell, interior rates(a,b); final physicaldeathenhancedso this is conservative withinrestrictedmodel.
 r=b/a;M=((r**(ell+1)-r)/(r-1)**2-ell/(r-1))/a
 p=(r-1)/(r**ell-1)
 rows.append({'rowlength':ell,'success_from_dent1':p,'reflected_completion_mean':M})
r={'up_rate':a,'down_rate':b,'rows':rows,'n_times_worst':2560000*rows[-1]['reflected_completion_mean'],'warning':'Otherlatticeupdatesfrozen. No censoring/hittingtimecomparisonproved, so notnativepostexitbound.'}
open('research_notes/creative_landscape_20261114/row_bound.json','w').write(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
