import json
# Exhaustively test arbitrary subsets of 4x4; row-run energy increments.
def energy(s):
 p=sum((x+dx,y+dy) not in s for x,y in s for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)])
 return 200*p-len(s) # energy units .04
worst=0; checked=0
for mask in range(1<<16):
 s={(i%4,i//4) for i in range(16) if mask>>i&1}; initial=energy(s)
 for y in range(3,-1,-1):
  xs=sorted(x for x,yy in s if yy==y)
  for x in xs:
   s.remove((x,y)); worst=max(worst,energy(s)-initial)
   assert energy(s)<=initial+3
   if (x+1,y) not in s: assert energy(s)<=initial
 checked+=1
print(json.dumps({'all_subsets_tested':checked,'max_energy_rise':worst*.04,'bound_for_width4':.12,'note':'finite check supplements general proof; no duration claim'},indent=2))
