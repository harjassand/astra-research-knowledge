"""Independent exact factorization checks in canonical erosion with companions."""
from pathlib import Path
import json,random,time
NN=[(1,0),(-1,0),(0,1),(0,-1)]
counts={'erosion_edges':0,'nonempty_earlier_history':0,'wire_touches_unchanged_companion':0};example=None
def E(A,L):return 200*sum(((x+dx)%L,(y+dy)%L)not in A for x,y in A for dx,dy in NN)-len(A)
def probe(X,z,T,comp,pref,gate,L,C):
 global example
 counts['erosion_edges']+=1;counts['nonempty_earlier_history']+=bool(T);phys=lambda v:(v[0]%L,v[1]%L);gg=next(v for v in pref if phys(v)==gate);xmin=min(v[0]for v in pref);xmax=max(v[0]for v in pref);wire={phys((x,gg[1]))for x in range(xmin,xmax+1)};U={phys(v)for v in pref if v[1]>gg[1]};D={phys(v)for v in pref if v[1]==gg[1]and v[0]<gg[0]};rem=z&comp;other=z-comp
 assert comp-rem==U|D,'active deletion labels missing'
 assert X==z|U|D|T,'erosion reconstruction failed'
 assert E(z,L)-E(X,L)==E(rem,L)-E(comp,L)-E(T,L),'full original component factorization failed'
 assert E(z,L)==E(other,L)+E(rem,L),'thermal companion contacts active residual'
 isolated=E(rem|U|wire,L)-E(rem,L);full=E(z|U|wire,L)-E(z,L)
 if isolated!=full:
  counts['wire_touches_unchanged_companion']+=1
  assert full<=isolated,'exterior plus should favor wire insertion'
  if example is None:example={'L':L,'X':sorted(X),'current':sorted(z),'original_component':sorted(comp),'earlier_history':sorted(T),'wire':sorted(wire),'U':sorted(U),'D':sorted(D),'isolated_insertion_energy_units_point04':isolated,'actual_full_insertion_energy_units_point04':full}
src=Path('research_notes/creative_landscape_20261114/test_full_paths.py').read_text().split('start=time.time()')[0];needle='  assert (v not in z) if add else (v in z)';assert src.count(needle)==1;src=src.replace(needle,needle+'\n  if not add: erosion_probe(X,z,T,comp,pref,v,L,C)');ns={'erosion_probe':probe};exec(compile(src,'borrowed_generator','exec'),ns);run=ns['run'];T=time.perf_counter()
for mask in range(1,1<<16):
 if mask.bit_count()<8:run({(i%4,i//4)for i in range(16)if mask>>i&1},4,2)
r=random.Random(89054)
for L,C in[(7,3),(8,3),(12,4)]:
 for _ in range(2000):
  p=r.uniform(.005,.25);X={(x,y)for x in range(L)for y in range(L)if r.random()<p}
  if 0<len(X)<L*L/2:run(X,L,C)
o={'scope':'independent exact erosion/exterior factorization probes using borrowed canonical generator; finite only','counts':counts,'case_count':ns['stats']['initial_states'],'seconds':time.perf_counter()-T,'wire_exterior_example':example};Path(__file__).with_suffix('.json').write_text(json.dumps(o,indent=2));print(json.dumps({k:v for k,v in o.items()if k!='wire_exterior_example'},indent=2));print('example found',bool(example))
