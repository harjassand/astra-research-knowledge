"""Complete finite killed-chain check of canonical congestion constants."""
from pathlib import Path
import json,math,numpy as np
L=3;n=9;C=2;path=[]
def mask(s):return sum(1<<(x*L+y)for x,y in s)
def capture(z,v,add):
 a=mask(z);i=v[0]*L+v[1];bb=a^(1<<i);path.append(tuple(sorted((a,bb))))
src=Path('research_notes/creative_landscape_20261114/test_full_paths.py').read_text().split('start=time.time()')[0];needle='  assert (v not in z) if add else (v in z)';src=src.replace(needle,needle+'\n  capture(z,v,add)');ns={'capture':capture};exec(compile(src,'borrowed_generator','exec'),ns)
def energy(m):
 s={(i//L,i%L)for i in range(n)if m>>i&1};P=sum(((x+dx)%L,(y+dy)%L)not in s for x,y in s for dx,dy in[(1,0),(-1,0),(0,1),(0,-1)])
 return .8*P-.04*len(s)
E=[energy(i)for i in range(1<<n)];w=[math.exp(-e)for e in E];states=[m for m in range(1,1<<n)if m.bit_count()<n/2];index={m:i for i,m in enumerate(states)};loads={};maxlen=0;repeat=0
for m in states:
 path.clear();ns['run']({(i//L,i%L)for i in range(n)if m>>i&1},L,C);maxlen=max(maxlen,len(path));repeat+=len(path)!=len(set(path))
 for e in path:loads[e]=loads.get(e,0.)+w[m]*len(path)
def rate(a,b):return 1/(1+math.exp(E[b]-E[a]))
rho=max(load/(w[a]*rate(a,b))for(a,b),load in loads.items());Q=np.zeros((len(states),len(states)))
for m in states:
 i=index[m]
 for bit in range(n):
  y=m^(1<<bit);q=rate(m,y);Q[i,i]+=q
  if y in index:Q[i,index[y]]=-q*math.sqrt(w[m]/w[y])
assert np.max(abs(Q-Q.T))<1e-13
lam=float(np.linalg.eigvalsh(Q)[0]);assert lam>=1/rho-1e-12
# Solve native nonsymmetric killed generator via similarity, using same physical rates.
rhs=np.sqrt([w[m]for m in states]);u=np.linalg.solve(Q,rhs)/rhs;Z=sum(w[m]for m in states);bounds=np.array([rho*(1+.5*math.log(Z/w[m]))for m in states]);assert np.all(u<=bounds*(1+1e-12))
o={'scope':'complete3x3nativekilledchain theta-likeenergy.8P−.04A; scaledpaththreshold2; NOT R200','states':len(states),'undirected_edges_used':len(loads),'maximum_path_length':maxlen,'paths_with_repeated_undirected_edges':repeat,'rho_occurrence_counted':rho,'killed_smallest_eigenvalue':lam,'inverse_rho':1/rho,'gap_times_rho':lam*rho,'maximum_exact_mean_kill_time':float(max(u)),'maximum_spectral_duration_bound':float(max(bounds)),'native_per_site_clock':True};Path(__file__).with_suffix('.json').write_text(json.dumps(o,indent=2));print(json.dumps(o,indent=2))
