"""Independent exact-integer energy/provenance checks on canonical path generator.
Reuses path generation ONLY; probes implemented independently below.
"""
from pathlib import Path
import json,random,time,math
src=Path('research_notes/creative_landscape_20261114/test_full_paths.py').read_text().split('start=time.time()')[0]
assert src.count('  return P')==1;src=src.replace('  return P','  energy_probe(X,z,T,U,sw,L,C)\n  return P')
counts={'probes':0,'history_crossing':0,'history_crossing_NN_bonds':0,'periodic_seam_probes':0,'partial_bootstrap_probes':0,'strict_exterior_improvement':0};examples={}
NN=[(1,0),(-1,0),(0,1),(0,-1)]
def E(A,L=None):
 def nb(v,d):return((v[0]+d[0])%L,(v[1]+d[1])%L)if L else(v[0]+d[0],v[1]+d[1])
 return 200*sum(nb(v,d)not in A for v in A for d in NN)-len(A)
def energy_probe(X,z,T,U,sw,L,C):
 counts['probes']+=1
 P={((v[1]if sw else v[0])%L,(v[0]if sw else v[1])%L)for v in U};S=(X-T)&P;R=X-T
 assert E(X,L)==E(T,L)+E(R,L),'original component factorization failed'
 assert R-P==z-P,'unrecorded exterior deletion/addition'
 lhs=E(z,L)-E(X,L);rhs=E(P,L)-E(S,L)-E(T,L)
 assert lhs<=rhs,'conditional exterior-plus comparison wrong'
 counts['strict_exterior_improvement']+=lhs<rhs
 # Lift subset through the exact overwrite map, valid even final wrap row.
 Slift={v for v in U if((v[1]if sw else v[0])%L,(v[0]if sw else v[1])%L)in S}
 assert len(P)==len(U),'overwrite lift not injective before first majority'
 assert E(P,L)-E(S,L)<=E(U)-E(Slift),'periodic seam comparison wrong'
 xs=[x for x,y in U];ys=[y for x,y in U];w=max(xs)-min(xs)+1;h=max(ys)-min(ys)+1
 if w==L or h==L:counts['periodic_seam_probes']+=1
 if w<=C and h<=C:
  rectangle={(x,y)for x in range(min(xs),max(xs)+1)for y in range(min(ys),max(ys)+1)}
  if U!=rectangle:
   counts['partial_bootstrap_probes']+=1
   assert E(U)-E(rectangle)<=2*C,'partial bootstrap gap beyond scaled bound'
 if T&P and T-P:
  counts['history_crossing']+=1;cross=sum(((x+dx)%L,(y+dy)%L)in(T-P)for x,y in T&P for dx,dy in NN)
  if cross:
   counts['history_crossing_NN_bonds']+=1
   assert E(T&P,L)+E(T-P,L)-E(T,L)==400*cross
   if 'split_history_counterexample'not in examples:examples['split_history_counterexample']={'L':L,'C':C,'X':sorted(X),'z':sorted(z),'T':sorted(T),'U':sorted(P),'cross_NN_bonds':cross,'spurious_split_energy_in_units_point04':400*cross,'true_T_energy':E(T,L),'split_T_energy':E(T&P,L)+E(T-P,L)}
ns={'energy_probe':energy_probe};exec(compile(src,'borrowed_canonical_generator','exec'),ns);run=ns['run'];T=time.perf_counter()
for mask in range(1,1<<16):
 if mask.bit_count()<8:run({(i%4,i//4)for i in range(16)if mask>>i&1},4,2)
rng=random.Random(611141)
for L,C in[(5,2),(7,3),(8,3),(9,4),(12,4)]:
 for _ in range(300):
  p=rng.uniform(.02,.49);X={(x,y)for x in range(L)for y in range(L)if rng.random()<p}
  if 0<len(X)<L*L/2:run(X,L,C)
 for X in[{(x,x)for x in range(L)},{(0,y)for y in range(L)},{(x,0)for x in range(L)}]:
  if len(X)<L*L/2:run(X,L,C)
out={'scope':'independent exact integer energy/history/seam checks; canonical generator borrowed, not independent construction or analytic proof','counts':counts,'path_stats':ns['stats'],'seconds':time.perf_counter()-T,'examples':examples};Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items()if k!='examples'},indent=2))
