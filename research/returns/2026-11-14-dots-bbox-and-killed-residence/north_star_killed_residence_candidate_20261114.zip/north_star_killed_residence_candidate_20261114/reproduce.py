#!/usr/bin/env python3
"""Fresh-copy reproduction. Default does NOT rerun large magnetic recurrences."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys,tempfile,time
p=argparse.ArgumentParser();p.add_argument('--full-moments',action='store_true');p.add_argument('--report',type=Path);a=p.parse_args()
root=Path(__file__).resolve().parent;manifest=root/'MANIFEST.json'
if manifest.exists():
 for rel,digest in json.loads(manifest.read_text()).items():
  assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==digest,rel
start=time.time();receipt={'status':'running','full_magnetic_recurrences_rerun':a.full_moments,'input_integrity_checked':manifest.exists(),'runs':[],'scope':'Proof-candidate reproduction: exact/scalar checks and finite geometry are distinct from the general analytic arguments. No formal proof-assistant verification or practical estimator test.'}
with tempfile.TemporaryDirectory(prefix='north_star_killed_repro_') as td:
 work=Path(td)/'candidate';shutil.copytree(root,work,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 def run(cmd,label,stdout_path=None):
  t=time.time();r=subprocess.run(cmd,cwd=work,text=True,capture_output=True)
  entry={'label':label,'command':cmd,'seconds':time.time()-t,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr};receipt['runs'].append(entry)
  if stdout_path is not None:(work/stdout_path).write_text(r.stdout)
  if r.returncode:raise RuntimeError(label+' failed: '+r.stderr)
 if a.full_moments:
  base=next((work/'flow_resume_recovery/unpacked').glob('*/dependencies/global_cut_corrected/01_global_cut'))
  binary=work/'magnetic_upper_fresh';run(['g++','-O3','-std=c++17','-frounding-math','-ffp-contract=off','-fno-fast-math',str(base/'magnetic_upper.cpp'),'-o',str(binary)],'compile repaired single-mode magnetic recurrence')
  for rn,rd in [(201,200),(101,100),(51,50),(765151,750000)]:
   target=(base/'cert_r200'/f'moment_{rn}_{rd}.txt') if rd!=750000 else work/'research_notes/flow_resume_20261114/moment_765151_750000.txt'
   run([str(binary),'1900',str(rn),str(rd)],f'FULL magnetic M1900 activity{rn}/{rd}',target.relative_to(work))
 s='research_notes/source_reconstructed_20261114/'
 f='research_notes/flow_resume_20261114/'
 c='research_notes/creative_landscape_20261114/'
 b='research_notes/bridge_resume_20261114/'
 j='research_notes/sampler_resume_20261114/'
 scripts=[
  (s+'renewal_box164_raw_faces.py','exact raw-face core/departure constants'),
  (s+'core650_occupation.py','exact large-core normalizer'),
  (s+'planar_area_core_occupation.py','planar-area occupation extension'),
  (s+'high_perimeter_occupation.py','all-topology high-perimeter occupation'),
  (s+'energy_excess_occupation.py','all-topology energy-excess occupation'),
  (s+'global_scalar_review.py','independent exact global phase scalar audit'),
  (s+'conditional_duration_numerator.py','exact residence corollary implication'),
  (s+'test_geometric_face_count.py','raw-face finite topology and energy checks'),
  (s+'test_torus_loop_encoding.py','exhaustive4x4 torus loop checks'),
  (f+'hull_entropy_bound.py','fresh hull scalar from REUSED upward moments' if not a.full_moments else 'fresh hull scalar from regenerated moments'),
  (f+'strip_walk_bound.py','fresh directed confined-walk certificate'),
  (f+'erosion_wire_check.py','exact finite wired erosion inequalities'),
  (c+'test_cylinder_partition.py','exact cylinder energy and rational partition bound'),
  (c+'test_bootstrap_records.py','finite bootstrap record checks'),
  (c+'test_wrap_comparison.py','finite seam comparison'),
  (c+'test_boundary_comparison.py','finite exterior comparison'),
  (c+'test_full_paths.py','finite complete path and stopping checks'),
  (b+'canonical_global_check.py','independent scaled torus reconstruction checks'),
  (j+'duration_scalar_audit.py','independent native-rate/scalar audit'),
  (j+'raw_outer_root_audit.py','independent primitive-root contour audit'),
  ('research_notes/residual_duration_20261114/test_killed_congestion.py','complete finite killed-chain spectral and clock diagnostic'),
  ('research_notes/residual_duration_20261114/test_energy_records.py','independent exact overwrite energy records'),
  ('research_notes/residual_duration_20261114/test_erosion_exterior.py','independent erasure exterior factorization')]
 for script,label in scripts:run([sys.executable,script],label)
 H=json.loads((work/(f+'hull_entropy_bound.json')).read_text())
 assert float(H['worst']['log_upper'])<878
 W=json.loads((work/(f+'strip_walk_bound.json')).read_text());assert float(W['log_marked_mass_with_vertical_root_record'])<191
 assert float(W['unmarked_outer_loop_gas_log_upper'])+float(W['all_hole_loop_gas_log_upper'])<1
 receipt['fresh_scalar_checks']={'hull_log_upper':H['worst']['log_upper'],'strip_marked_log_upper':W['log_marked_mass_with_vertical_root_record']}
receipt['status']='passed';receipt['total_seconds']=time.time()-start
out=json.dumps(receipt,indent=2)
if a.report:a.report.write_text(out)
print(out)
