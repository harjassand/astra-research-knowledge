from pathlib import Path
from itertools import product
from collections import Counter
import sys,json

from proposal import partitions,addable
from area import corner_powers,marked_coeff
out=[]
for k in [1,2]:
 a,b=2*k+4,2*k+5;ps=corner_powers(k);E=marked_coeff(k);coef=[0]*(4*k*k)
 for i,x in enumerate(E):
  for j,y in enumerate(ps[3]):
   if i+j<len(coef):coef[i+j]+=4*x*y
 count=Counter();seen=set();checks=0
 xy=lambda x,y,c: [(x,y),(a-1-x,y),(a-1-x,b-1-y),(x,b-1-y)][c]
 for ls in product(list(partitions(k)),repeat=4):
  D={(x,y)for x in range(a)for y in range(b)}
  for c,lam in enumerate(ls):D.difference_update(xy(x,y,c)for y,l in enumerate(lam)for x in range(l))
  A=sum(map(sum,ls));P=lambda S:sum((x+dx,y+dy)not in S for x,y in S for dx,dy in[(1,0),(-1,0),(0,1),(0,-1)])
  assert P(D)==2*(a+b)
  for c,lam in enumerate(ls):
   for row,col in addable(lam,k):
    z=xy(col,row,c);assert z in D
    assert sum((z[0]+dx,z[1]+dy)in D for dx,dy in[(1,0),(-1,0),(0,1),(0,-1)])==2
    S=D-{z};assert P(S)==P(D) and len(S)==a*b-A-1
    key=(frozenset(D),z);assert key not in seen;seen.add(key)
    count[A]+=1;checks+=1
 assert all(count[i]==v for i,v in enumerate(coef))
 out.append(dict(k=k,exact_native_cut_edges=checks,all_marked_area_coefficients_match=True,no_duplicate_edges=True))
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
