from fractions import Fraction as F
from collections import defaultdict
from pathlib import Path
import json
from magnetic_moment_check import moments
D=[(1,0),(0,1),(-1,0),(0,-1)]
def square(M,r):
 dp={(dx,dy,j):F(1) for j,(dx,dy) in enumerate(D)};out={}
 for p in range(1,M+1):
  out[p]=sum(w for(x,y,j),w in dp.items() if x==y==0)
  if p==M:break
  nd=defaultdict(F)
  for(x,y,j),w in dp.items():
   for jj,(dx,dy) in enumerate(D):
    if jj==(j+2)%4:continue
    nd[x+dx,y+dy,jj]+=w*r**(x*dy-y*dx)
  dp=nd
 return out
def run():
 rows=[]
 for r in (F(1),F(101,100)):
  a,_=moments(8,0,r);b,_=moments(8,1,r);s=square(8,r**9)
  for p in range(1,9):assert s[p]==a[p]+b[p]
  rows.append({'dual_local_activity':str(r),'all_perimeters_through':8,'all_four_physical_trace_starts_equal_both_dual_roots':True})
 out={'scope':'Exact validation of physical square-walk contraction and its signed-area weight; general equality still needs explicit geometric proof','rows':rows}
 print(json.dumps(out,indent=2));Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')

if __name__=="__main__":run()
