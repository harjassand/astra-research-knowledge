from fractions import Fraction as F
from pathlib import Path
import subprocess,json
from check_directed_arithmetic import hexfrac
M=8;S0=8;q=F(1,2);w=[F(0)]*9;w[4]=F(1,10);w[6]=F(1,100);w[8]=F(1,1000)
inp='8 8 0.5\n'+'\n'.join(['0']*4+['0.1','0','0.01','0','0.001'])+'\n'
text=subprocess.check_output([__import__('os').environ['N1722_CONVOLUTION']],input=inp,text=True)
a=[F(1)];rows=[]
for line in text.splitlines():
 j,h=line.split();b=[F(0)]*(len(a)+M)
 for i,x in enumerate(a):
  for p,y in enumerate(w):b[i+p]+=x*y
 a=b;exact=sum(a[s]*q**(s-S0) for s in range(S0,len(a)));upper=hexfrac(h)
 assert upper>=exact and upper/exact-1<F(1,10**12)
 rows.append({'power':int(j),'upper_dominates_exact_rational':True,'relative_excess':float(upper/exact-1)})
out={'scope':'Independent exact rational comparison for directed positive convolution and geometric tail evaluation','rows':rows}
print(json.dumps(out,indent=2));Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
