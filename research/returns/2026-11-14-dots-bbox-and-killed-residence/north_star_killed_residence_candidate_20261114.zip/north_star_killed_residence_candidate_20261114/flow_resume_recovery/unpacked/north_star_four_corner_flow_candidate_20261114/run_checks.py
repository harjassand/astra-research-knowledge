"""Reproduce checks in an isolated temporary copy, preserving distributed receipts."""
from pathlib import Path
import tempfile,shutil,subprocess,sys,json,time,platform
from decimal import Decimal
from fractions import Fraction
root=Path(__file__).resolve().parent
thermal=1600**2*(Fraction(10,27)**31+48*Fraction(10,27)**40)
assert thermal<Fraction(1,10**6)
print('PASS exact thermal normalization scalar:',float(thermal),flush=True)
with tempfile.TemporaryDirectory(prefix='four_corner_check_') as td:
 work=Path(td)/'package';shutil.copytree(root,work,ignore=shutil.ignore_patterns('__pycache__','validation_stdout.txt'))
 a='research_notes/capacity_resume_20261114/'
 scripts=[a+'certify_four_corner_scalar.py',a+'certify_width1.py',a+'corner_channel_check.py',a+'corner_channel_exact.py','research_notes/radical_structure_20261114/four_corner_independent.py']
 if '--with-cut' in sys.argv:scripts.append('dependencies/global_cut_corrected/run_checks.py')
 receipts=[]
 for script in scripts:
  start=time.perf_counter();print('\nRUN',script,flush=True)
  subprocess.run([sys.executable,str(work/script)],cwd=work,check=True)
  receipts.append({'script':script,'exit_code':0,'wall_seconds':time.perf_counter()-start})
 scalar=json.loads((work/(a+'four_corner_directed_scalar_degree2.json')).read_text())
 assert scalar['target_log_inverse_capacity']==6267
 assert scalar['conditional_W_over_C_upper']=='exp(52)'
 assert Decimal(scalar['normalized_resistance_over_exp_target_upper'])<1
 exact=json.loads((work/(a+'corner_channel_exact_results.json')).read_text())
 assert [r['max_divergence'] for r in exact]==[0,0]
 review=json.loads((work/'research_notes/radical_structure_20261114/four_corner_independent.json').read_text())
 assert [r['maximum'] for r in review]==[2,6,12,20,30]
 result={'status':'PASS executed arithmetic/finite tests, NOT full proof verification','python':sys.version,'platform':platform.platform(),'runs':receipts,'full_R200_magnetic_recurrences_regenerated':False,'conditional_scaled_quadratic_upper':scalar['normalized_resistance_over_exp_target_upper']}
 print('\nVALIDATION_SUMMARY\n'+json.dumps(result,indent=2))
