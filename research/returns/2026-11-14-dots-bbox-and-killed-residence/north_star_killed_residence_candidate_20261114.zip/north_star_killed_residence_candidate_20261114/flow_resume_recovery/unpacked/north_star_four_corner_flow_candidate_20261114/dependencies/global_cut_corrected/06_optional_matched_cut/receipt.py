from pathlib import Path
import sys,json,time,math
from decimal import Decimal as D,localcontext,ROUND_FLOOR,ROUND_CEILING

from area import corner_powers,marked_coeff
R=200;k=int(sys.argv[1])if len(sys.argv)>1 else 50
L=8*R;n=L*L;V=156025
start=time.process_time();ps=corner_powers(k);ec=marked_coeff(k);bits=8*k+(4*k).bit_length()+2;chunk=(bits+7)//8
enc=lambda a:int.from_bytes(b''.join(int(v).to_bytes(chunk,'little')for v in a),'little')
prod=4*enc(ec)*enc(ps[3]);length=4*k*k
raw=prod.to_bytes((length+2)*chunk,'little');marked=[int.from_bytes(raw[j*chunk:(j+1)*chunk],'little')for j in range(length)]
H={};rects=0
for a in range(2*k+4,L-1):
 lo=max(2*k+4,(V+1+a-1)//a);hi=min(L-2,(V+4*k*k)//a)
 for b in range(lo,hi+1):
  A=a*b-V-1
  if 0<=A<len(marked) and marked[A]:H[a+b]=H.get(a+b,0)+marked[A];rects+=1
Path(__file__).with_name(f'coefficients_k{k}.json').write_text(json.dumps({str(t):str(c) for t,c in H.items()},sort_keys=True)+'\n')
with localcontext()as ctx:
 ctx.prec=100;ctx.rounding=ROUND_FLOOR
 phi=D(4)/R;qlo=D(1)-2*phi
 terms=[D(c).ln().next_minus()-16*t for t,c in H.items()];m=max(terms)
 logsum=m+sum((x-m).exp().next_minus()for x in terms).ln().next_minus()
 logG=D(n).ln().next_minus()+(qlo/(1+qlo)).ln().next_minus()+2*phi*(V+1)+logsum
with localcontext()as ctx:
 ctx.prec=100;ctx.rounding=ROUND_CEILING
 pressure=D(6*n)/(D(500)**3*499);logZA=D(2).ln().next_plus()+pressure
with localcontext()as ctx:
 ctx.prec=100;ctx.rounding=ROUND_FLOOR
 loglower=logG-logZA
out=dict(R=R,k=k,Vcap=V,rectangle_boxes=rects,perimeter_classes=len(H),log_native_subset_over_wminus_lower=str(logG),log_native_subset_over_ZA_lower=str(loglower),CPU_seconds=time.process_time()-start,scope='Positive exact integer marked counts; outward Decimal logarithms/exponentials and rational native-rate lower24/49. SAME global M_s native cut, pure companions; not capacity lower.')
Path(__file__).with_name(f'receipt_k{k}.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
