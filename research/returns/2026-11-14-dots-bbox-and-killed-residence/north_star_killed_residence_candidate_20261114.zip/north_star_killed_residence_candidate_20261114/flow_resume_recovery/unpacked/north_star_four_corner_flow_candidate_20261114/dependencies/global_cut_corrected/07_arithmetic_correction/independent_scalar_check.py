from pathlib import Path
from decimal import Decimal as D,localcontext,ROUND_CEILING,ROUND_FLOOR,getcontext
from fractions import Fraction as F
from math import factorial
import json
getcontext().prec=220;getcontext().rounding=ROUND_CEILING
HERE=Path(__file__).resolve().parent;BASE=HERE.parent/'01_global_cut'/'cert_r200'
def cv(f,up=True):
 f=F(f)
 with localcontext() as c:c.rounding=ROUND_CEILING if up else ROUND_FLOOR;return D(f.numerator)/D(f.denominator)
def hi(f):return cv(f).ln().next_plus()
def lo(f):return cv(f,False).ln().next_minus()
def mullo(a,b):
 with localcontext() as c:c.rounding=ROUND_FLOOR;return D(a)*b
def hx(s):
 a,e=s.split('p');a=a.removeprefix('0x');u,v=(a.split('.')+[''])[:2];return F(int(u+v,16),16**len(v))*F(2)**int(e)
def lse(vals):
 m=max(vals);return m+sum((v-m).exp().next_plus() for v in vals).ln().next_plus()
receipt=json.loads((BASE/'certificate_marked_s79_40.json').read_text());n=2560000;M=1900;V=156025;S0=1576;J=receipt['convolution_shift_J'];inputs=[]
for path in BASE.glob('moment_*.txt'):
 a,b=map(int,path.stem.split('_')[1:]);r=F(a,b);z={}
 for line in path.read_text().splitlines():
  if not line or line.startswith('#'):continue
  P,h,e=line.split();assert int(e)>=0;z[int(P)]=hx(h)*F(2)**int(e)
 inputs.append((r,z))
assert len(inputs)==3
weights=(BASE/'marked_convolution_s79_40.input').read_text().splitlines()[1:];checks=0
for P in range(4,M+1,2):
 vp=min(V,P*P//16)
 la=hi(n)-8*P+cv(F(vp,25))+min(hi(z[P])-mullo(2*vp,lo(r)) for r,z in inputs)-lo(P)
 upper=(la+4*P-J).exp().next_plus()
 assert D(weights[P])>=upper,(P,D(weights[P])-upper)
 checks+=1
terms=[]
for line in (BASE/'marked_convolution_s79_40.output').read_text().splitlines():
 j,h=line.split();j=int(j);terms.append(D(j*J-4*S0)+hi(hx(h))+hi(3)-lo(factorial(j)))
# Independent complete reconstruction, using rational functions whenever possible.
a_s=F(81,20);q_s=4*cv(-a_s).exp().next_plus()
with localcontext() as c:c.rounding=ROUND_FLOOR;den=1-q_s
logall=hi(6*n)+4*q_s.ln().next_plus()-den.ln().next_minus()
qt=F(3)/sum(F(8)**j/factorial(j) for j in range(73))
tail=hi(36)+hi(F(4*n,3))+cv(F(V,25))+(M+1)*hi(qt)-lo(1-qt)+7*max(D(0),logall)
u=F(6*n)*F(3,40)**10/(1-F(3,40));phi=F(1,50);bulk=phi*n*(F(1,2)-F(1,500000))
target=hi(n)-cv(bulk,False)+cv(phi);source=-cv(bulk,False)
complete=lse([lse(terms),hi(n)+tail,target,source])-lo(1-u)
assert D(receipt['log_capacity_over_ZA_upper'])>=complete
assert complete<-6215
ans={'precision':220,'exact_hex_moments_used':len(inputs)*checks,'all_949_repaired_convolution_inputs_dominate_independent_220digit_bounds':checks,'complete_independent_upper':str(complete),'delivered_repaired_110digit_upper':receipt['log_capacity_over_ZA_upper'],'repaired_scalar_dominates_independent_upper':True,'rounded_exponent6215_valid':True,'scope':'Checks repaired scalar/convolution inputs against independently recomposed higher-precision outward bounds; magnetic recurrence correctness is separate.'}
HERE.joinpath('final_scalar_check.json').write_text(json.dumps(ans,indent=2)+'\n');print(json.dumps(ans,indent=2))
