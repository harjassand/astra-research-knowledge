from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path
import json
# Coordinates are three times the dual triangle centroids.
steps={0:[(-1,1,0),(-1,-2,1),(2,1,1)],1:[(1,-1,0),(-2,-1,1),(1,2,1)]}
def counts(M,kind, signed=False):
 dp={(0,0,0,0,0,0):1} # u,v, twice signed area in scaled coordinates,p,lastdu,lastdv
 out=defaultdict(int);peak=0
 for length in range(1,2*M+1):
  nd=defaultdict(int);typ=kind^((length-1)&1)
  for (u,v,area,p,pu,pv),n in dp.items():
   for du,dv,c in steps[typ]:
    if (du,dv)==(-pu,-pv) or p+c>M:continue
    uu=u+du;vv=v+dv;aa=area+u*dv-v*du;pp=p+c
    if (length+1)//2>pp:continue
    nd[(uu,vv,aa,pp,du,dv)]+=n
  dp=nd;peak=max(peak,len(dp))
  if length%2==0:
   for (u,v,aa,p,du,dv),n in dp.items():
    if u==v==0 and (signed or aa>0) and aa%18==0 and p>=4:out[p,aa//18]+=n
 return out,peak

def loop_geometry(S):
 adj=defaultdict(list)
 for x in range(-1,4):
  for y in range(-1,4):
   A=(3*x+2,3*y+1)
   for B,e,c in [((3*x+1,3*y+2),((x,y),(x+1,y+1)),0),((3*x+1,3*y-1),((x,y),(x+1,y)),1),((3*x+4,3*y+2),((x+1,y),(x+1,y+1)),1)]:
    if (e[0] in S)!=(e[1] in S):adj[A].append((B,c));adj[B].append((A,c))
 assert all(len(v)==2 for v in adj.values())
 seen=set();out=[]
 for start in adj:
  if start in seen:continue
  prev=None;cur=start;aa=0;p=0;length=0
  while True:
   seen.add(cur);nxt,c=next((z,c) for z,c in adj[cur] if z!=prev)
   aa+=cur[0]*nxt[1]-cur[1]*nxt[0];p+=c;length+=1
   prev,cur=cur,nxt
   if cur==start:break
  assert abs(aa)%18==0 and length<=2*p
  out.append((p,abs(aa)//18))
 return out
def run():
 out,peak=counts(8,0);outb,peakb=counts(8,1);assert out==outb
 checks=0;one=0
 for mask in range(1,512):
  S={(i%3,i//3) for i in range(9) if mask>>i&1};loops=loop_geometry(S);checks+=1
  if len(loops)==1:
   p,v=loops[0];assert v==len(S);one+=1
   if p<=8:assert out[p,v]>0
 assert out[4,1]>=1
 res={'scope':'Exact dual geometry on all511 nonempty3x3 patterns and positive closed-walk counts through physical perimeter8; not a large-R capacity computation','patterns_checked':checks,'single_loop_area_equal_spin_count':one,'root_types_agree':True,'max_dp_states':max(peak,peakb),'rooted_positive_counts':[{'perimeter':p,'filled_area':v,'count_per_root_type':n}for(p,v),n in sorted(out.items())]}
 print(json.dumps(res,indent=2));Path(__file__).with_suffix('.json').write_text(json.dumps(res,indent=2)+'\n')

if __name__=="__main__":run()
