from fractions import Fraction as F
from math import factorial
from pathlib import Path
import json,itertools
L=3;n=9
nn=[[(x+dx)%L+L*((y+dy)%L) for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]] for y in range(L) for x in range(L)]
aug=[nn[i]+[((i%L+1)%L)+L*((i//L+1)%L),((i%L-1)%L)+L*((i//L-1)%L)] for i in range(n)]
def core(x):return all(not(x>>i&1) or all(not(x>>j&1) for j in aug[i]) for i in range(n))
def w(x):return F(2)**x.bit_count()/F(4)**sum(1 for i in range(n) if x>>i&1 for j in nn[i] if not(x>>j&1))
def marks(site,root):
 x=site%L;y=site//L;out=[];dirs=[(1,0),(0,1),(-1,0),(0,-1)]
 for dx,dy in dirs[root:]+dirs[:root]:
  ox=x+dx;oy=y+dy;tx=-dy;ty=dx
  for z in [-1,0,1]:out.append((ox+z*tx)%L+L*((oy+z*ty)%L))
 return out
ss=[x for x in range(1<<n) if core(x)];Z=sum(map(w,ss));b=F(1,128);Q=sum(F(12*j,factorial(j))*(n*b)**j for j in range(1,9));W=F(0);accept=F(0);representations=0;edges=0
for x in ss:
 for i in range(n):
  if x>>i&1 or core(x|1<<i):continue
  label=tuple(j for j in aug[i] if x>>j&1);j=len(label);y=x
  for z in label:y^=1<<z
  assert core(y);assert w(x)/w(y)==b**j
  c=w(x|1<<i)/(w(x)+w(x|1<<i));g=w(x)*c;total=F(0)
  for perm in itertools.permutations(label):
   for roots in itertools.product(range(4),repeat=j):
    mm=sum((marks(z,r) for z,r in zip(perm,roots)),[]);assert len(mm)==12*j and i in mm
    canonical_first=mm.index(i);assert mm[canonical_first]==i
    # Only this ONE mark is allowed for each rooted ordered representation.
    proposal=(b/F(4))**j*F(12*j,factorial(j))/Q*F(1,12*j)*w(y)/Z
    a=c*w(x)/w(y)/b**j;assert 0<=a<=1
    total+=proposal*a;representations+=1
  assert total==g/(Q*Z);W+=g;accept+=total;edges+=1
assert accept==W/(Q*Z)
out={'native_edges':edges,'root_order_representations_checked':representations,'boundary_first_mark_check':True,'exact_refined_accepted_density':True,'acceptance_probability':float(accept),'scope':'Independent exact small native refinement check; no large walk sampler execution.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
