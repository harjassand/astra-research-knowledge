"""Exact rational Gibbs/pointed-Young DP on a bounded Ferrers corner."""
from fractions import Fraction as F
import random

def tables(k,q):
 q=F(q);assert 0<q<=1
 powers=[q**j for j in range(k+1)]
 Z=[[F(1)]*(k+1)];E=[[F(0)]*(k+1)]
 for j in range(1,k+1):
  rz=[];re=[];sz=se=F(0)
  for p in range(k+1):
   oldsz=sz
   sz+=powers[p]*Z[-1][p]
   se+=powers[p]*E[-1][p]
   rz.append(sz);re.append(se+oldsz)
  Z.append(rz);E.append(re)
 return Z,E

def choose(weights,rng):
 # Exact rational choice via integer cumulative masses; no float conversion.
 from math import lcm
 den=1
 for w in weights:den=lcm(den,w.denominator)
 ints=[int(w*den) for w in weights];tot=sum(ints);assert tot>0
 x=rng.randrange(tot)
 for i,w in enumerate(ints):
  if x<w:return i
  x-=w
 raise AssertionError

def sample(k,q,rng,pointed=False,precomputed=None):
 q=F(q);Z,E=precomputed or tables(k,q);rows=[];p=k;mark=None
 for j in range(k,0,-1):
  weights=[q**l*(E[j-1][l]+(Z[j-1][l] if l<p else 0)) if pointed else q**l*Z[j-1][l] for l in range(p+1)]
  l=choose(weights,rng)
  if pointed:
   source=[E[j-1][l],Z[j-1][l] if l<p else F(0)]
   if choose(source,rng)==1:
    mark=(len(rows),l);pointed=False
  rows.append(l);p=l
 assert not pointed
 return tuple(rows),mark

def addable(lam,k):
 return [(i,l) for i,l in enumerate(lam) if l<k and(i==0 or l<lam[i-1])]

def partitions(k):
 def walk(prefix,p):
  if len(prefix)==k:yield tuple(prefix);return
  for v in range(p+1):yield from walk(prefix+[v],v)
 yield from walk([],k)
