from fractions import Fraction as F
from math import factorial
from decimal import Decimal as D,localcontext,ROUND_CEILING,ROUND_FLOOR
from pathlib import Path
import json
root=Path(__file__).parent;receipt=json.loads((root/'cert_r200'/'certificate_s79_40.json').read_text())
assert D(receipt['log_capacity_over_ZA_upper'])<=-6202
n=2560000;q=F(3,40);rp=64

def explower(x,N):return sum(F(x)**j/factorial(j) for j in range(N+1))
def expupper(x,N):
 x=F(x);return explower(x,N)+x**(N+1)/factorial(N+1)/(1-x/F(N+2))
assert explower(F(4),12)>F(160,3)
assert q<F(1,13)
assert expupper(F(5,2),30)<13
assert explower(18,60)>F(6*n)/(1-q)
# Therefore u_aux<exp(18-128*2.5)=exp(-302).
assert 18-2*rp*F(5,2)==-302
# U/ell<=e247, so auxiliary omission/C<e-55.
u=F(6*n)*q**10/(1-q)
with localcontext() as c:
 c.prec=100;c.rounding=ROUND_CEILING
 ln_n=D(n).ln().next_plus()
 with localcontext() as d:
  d.prec=100;d.rounding=ROUND_FLOOR
  denom=D((1-u).numerator)/D((1-u).denominator)
  ln_den=denom.ln().next_minus()
 tail=D(receipt['log_tuple_tail_upper'])+ln_n-ln_den
 assert tail<-6803
 # target/source terms with kappa<=1 are much below exp(-25584)
 v=F(4,200)*n*(F(1,2)-F(1,500000))
 with localcontext() as d:
  d.prec=100;d.rounding=ROUND_FLOOR;vlow=D(v.numerator)/D(v.denominator)
 target=ln_n-vlow+D('.02')-ln_den
 assert target<-25585
assert explower(55,10)>3000 #3e^-55<.001
assert expupper(F(147,10),120)<n
assert F(17*147,10)>247+F(7,10)
out={'scope':'Exact rational core/error comparison plus inherited outward global upper receipt; finite R200 only','original_source_r':5,'auxiliary_proposal_r':rp,'epsilon_original':'1/100','capacity_upper_ratio_to_ZA':'exp(-6202)','conservative_original_clock_capacity_lower':'exp(-6449)','auxiliary_core_omission_probability_upper':'exp(-302)','auxiliary_missing_energy_over_C_upper':'exp(-55)','tail_missing_energy_over_C_upper':'exp(-354)','total_omitted_energy_over_C_upper':'1/1000','acceptance_probability_lower':'0.5 exp(-247)','expected_attempts_upper':'2 exp(247) < n^17 at this n only','practicality':'Enormous; no uniform polynomial or practical-rate claim.'}
print(json.dumps(out,indent=2));Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
