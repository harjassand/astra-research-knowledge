from fractions import Fraction as F
from pathlib import Path
import json
L=3;n=L*L
nn=[];aug=[]
for i in range(n):
 x=i%L;y=i//L
 nn.append([((x+dx)%L)+L*((y+dy)%L) for dx,dy in[(1,0),(-1,0),(0,1),(0,-1)]])
 aug.append(nn[-1]+[((x+1)%L)+L*((y+1)%L),((x-1)%L)+L*((y-1)%L)])
def core(x):return all(not((x>>i&1) and any(x>>j&1 for j in aug[i])) for i in range(n))
def weight(x):
 P=sum(1 for i in range(n) if x>>i&1 for j in nn[i] if not(x>>j&1))
 return F(2)**x.bit_count()/F(4)**P
states=[x for x in range(1<<n) if core(x)];Z=sum(weight(x) for x in states)
b=F(1,128);T=sum((4*n*b)**j for j in range(1,9));W=F(0);pacc=F(0);edges=0
for x in states:
 for i in range(n):
  if x>>i&1:continue
  dest=x|(1<<i)
  if core(dest):continue
  label=tuple(sorted(j for j in aug[i] if x>>j&1));assert label
  y=x
  for j in label:y^=1<<j
  assert core(y)
  ratio=weight(x)/weight(y);assert ratio==b**len(label)
  c=weight(dest)/(weight(x)+weight(dest));g=weight(x)*c
  # One canonical root/order for actual tuple. All other proposal labels reject.
  attempt=(b**len(label)/T)*(weight(y)/Z)/n
  accept=c*ratio/(b**len(label));assert 0<=accept<=1
  assert attempt*accept==g/(n*T*Z)
  W+=g;pacc+=attempt*accept;edges+=1
assert pacc==W/(n*T*Z)
out={'scope':'Exact3x3 native Ising trial-energy proposal identity; not a simulation of the large contour DP or a capacity theorem','thermal_core_states':len(states),'structural_edges_checked':edges,'cut_energy_exact':str(W),'tuple_upper_normalizer_exact':str(T),'acceptance_probability_exact':str(pacc),'acceptance_probability':float(pacc),'weight_and_unique_label_energy_identity':True}
print(json.dumps(out,indent=2));Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
