"""Conditional positive directed certificate. Geometry/overlap supplied separately."""
from fractions import Fraction as F
from decimal import Decimal,localcontext,ROUND_FLOOR,ROUND_CEILING,getcontext
import math,json,time
getcontext().prec=80;getcontext().rounding=ROUND_CEILING

def decfrac(f,rounding):
 with localcontext() as c:
  c.rounding=rounding
  return Decimal(f.numerator)/Decimal(f.denominator)
def exp_bounds(x):
 x=F(x);neg=x<0;x=abs(x);s=0
 while x>F(1,8):x/=2;s+=1
 term=F(1);lo=term
 for j in range(1,33):term*=x/j;lo+=term
 # Following positive tail ratios bounded by x/34.
 first=term*x/33;hi=lo+first/(1-x/34)
 dl=decfrac(lo,ROUND_FLOOR);du=decfrac(hi,ROUND_CEILING)
 with localcontext() as c:
  for _ in range(s):
   c.rounding=ROUND_FLOOR;dl*=dl
   c.rounding=ROUND_CEILING;du*=du
  if neg:
   c.rounding=ROUND_FLOOR;nl=Decimal(1)/du
   c.rounding=ROUND_CEILING;nu=Decimal(1)/dl
   return nl,nu
  return dl,du

def run(d=132,T=6272,degree=3):
 start=time.perf_counter();R=200;n=64*R*R;t=F(1,25);K=2*d+1;M=3*R;N=math.comb(2*d,d)
 ql,qu=exp_bounds(-t)
 # Positive Gaussian-binomial recursion, all operations rounded down.
 with localcontext() as c:
  c.rounding=ROUND_FLOOR
  previous=[Decimal(1)]*(d+1);qa=Decimal(1)
  for a in range(1,d+1):
   qa*=ql;current=[Decimal(1)]
   for b in range(1,d+1):current.append(previous[b]+qa*current[-1])
   previous=current
  Zlo=previous[-1]
 with localcontext() as c:
  c.rounding=ROUND_CEILING
  invZ=Decimal(1)/Zlo;invZ4=invZ*invZ;invZ4*=invZ4
  nz=Decimal(N)*invZ;nz4=nz*nz;nz4*=nz4
  Bpre=32*K-t*K*K+t*K;Bm=32*M-t*M*M
  pre=Decimal(2*K*K)*exp_bounds(Bpre-T)[1]*nz4
  core=Decimal(2*(d+1)**degree)/Decimal(n)*exp_bounds(F(6423-T))[1]*invZ4
  merge=Decimal(8*d*d)*exp_bounds(Bm-T)[1]*nz4
  late=Decimal(2*n)*exp_bounds(Bm+16-T)[1]
  source=exp_bounds(F(12968,5)-T)[1]
  total=(source+Decimal(3)*(pre+core+merge+late))/(Decimal(1)-Decimal('0.000001'))
 assert total<1
 out={'status':'CONDITIONAL scalar certificate: requires proof of geometric channel resistance, stated overlap degree, prefix/merge and source normalization assumptions', 'R':R,'d':d,'K':K,'M':M,'target_log_inverse_capacity':T,'Z_lower':str(Zlo),'q_lower':str(ql),'q_upper':str(qu),'N_exact':str(N),'core_overlap_bound':2*(d+1)**degree,'overlap_degree':degree,'scaled_upper_terms':{k:str(v) for k,v in [('prefix',pre),('core',core),('merge',merge),('late',late),('source',source)]},'normalized_resistance_over_exp_target_upper':str(total),'conditional_W_over_C_upper':'exp('+str(T-6215)+')','decimal_digits':80,'partition_DP_cells':d*d,'seconds':time.perf_counter()-start,'bare_path_reference':'Rbare<=exp6423 from prior directed native path receipt; not floating6422.77'}
 print(json.dumps(out,indent=2));open('research_notes/capacity_resume_20261114/four_corner_directed_scalar_degree'+str(degree)+'.json','w').write(json.dumps(out,indent=2));return out
if __name__=='__main__':
 run()
 run(T=6267,degree=2)
