from fractions import Fraction as F
from pathlib import Path
import sys,subprocess,json
sys.path.insert(0,str(Path(__file__).parent.parent/'01_global_cut'))
from physical_trace_check import square

def hx(s):
 a,e=s.split('p');a=a.removeprefix('0x');u,v=(a.split('.')+[''])[:2]
 return F(int(u+v,16),16**len(v))*F(2)**int(e)
rows=[]
for num,den in [(1,1),(201,200),(101,100),(51,50),(41,40),(11,10),(6,5),(3,2),(2,1),(10001,10000),(1003,997)]:
 truth=square(20,F(num,den))
 text=subprocess.check_output([__import__('os').environ['N1722_MAGNETIC'],'20',str(num),str(den)],text=True)
 low=0;hi=F(0)
 for line in text.splitlines():
  if line.startswith('#'):continue
  p,h,e=line.split();v=hx(h)*F(2)**int(e);t=truth[int(p)]
  assert v>=t,(num,den,p,v-t)
  hi=max(hi,v/t-1)
 rows.append({'r':f'{num}/{den}','max_perimeter':20,'all_outputs_upper':True,'max_relative_excess':str(hi)})
out={'scope':'Exact Fraction comparison of single-rounding-mode repair. No claim tests alone prove all compiler semantics.','rows':rows}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
