from fractions import Fraction as F
from pathlib import Path
import json,subprocess
from physical_trace_check import square

def hexfrac(s):
 mant,e=s.split('p');e=int(e);mant=mant.removeprefix('0x');a,b=(mant.split('.')+[''])[:2]
 return F(int(a+b,16),16**len(b))*F(2)**e
def run():
 rows=[]
 for num,den in [(1,1),(101,100),(51,50)]:
  txt=subprocess.check_output([__import__('os').environ['N1722_MAGNETIC'],'16',str(num),str(den)],text=True)
  exact=square(16,F(num,den));mx=F(1)
  for line in txt.splitlines():
   if line.startswith('#'):continue
   p,h,e=line.split();upper=hexfrac(h)*F(2)**int(e);truth=exact[int(p)]
   assert upper>=truth;mx=max(mx,upper/truth)
  assert mx-1<F(1,10**12)
  rows.append({'r':f'{num}/{den}','all_perimeters_through':16,'upper_dominates_exact_rational':True,'max_relative_excess':float(mx-1)})
 out={'scope':'Independent exact rational validation of compiled directed-rounding magnetic recurrence on small cases; general enclosure also relies on stated floating-point/compiler semantics','rows':rows}
 print(json.dumps(out,indent=2));Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')

if __name__=="__main__":run()
