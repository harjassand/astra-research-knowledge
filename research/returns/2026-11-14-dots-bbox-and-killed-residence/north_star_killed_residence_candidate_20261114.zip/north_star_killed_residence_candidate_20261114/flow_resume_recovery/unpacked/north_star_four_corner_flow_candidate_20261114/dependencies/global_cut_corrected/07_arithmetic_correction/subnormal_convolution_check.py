from fractions import Fraction as F
from decimal import Decimal as D, localcontext
import subprocess,json
from pathlib import Path

def hx(s):
 a,e=s.split('p'); a=a.removeprefix('0x'); z=a.split('.'); v=z[1] if len(z)>1 else ''; return F(int(z[0]+v,16),16**len(v))*F(2)**int(e)
rows=[]
for w in ['0.01','1e-4950','1e-4960']:
 q='0.33333333333333333333333333333333333333333333333333333'
 inp=f'4 4 {q}\n0 0 0 0 {w}\n'
 p=subprocess.run([__import__('os').environ['N1722_CONVOLUTION'],'marked'],input=inp,text=True,capture_output=True,check=True)
 for line in p.stdout.splitlines():
  j,s=line.split(); j=int(j)
  exact=4*j*F(w)**j*F(q)**(4*j-4)
  val=hx(s)
  assert val>=exact,(w,j)
  rows.append({'input_weight':w,'power':j,'upper':True,'positive_output':val>0})
 rows[-1]['flags']=p.stderr.strip()
z={'scope':'Exact rational positive convolution check including inputs below long-double subnormal minimum; checked single-mode upward parser and operations. Not a substitute for full run.','checks':rows}
Path(__file__).with_suffix('.json').write_text(json.dumps(z,indent=2)+'\n')
print(json.dumps(z,indent=2))
