from decimal import Decimal,localcontext,ROUND_CEILING,ROUND_FLOOR
from fractions import Fraction as F
from collections import Counter
import math,json,time
start=time.perf_counter();L=1600;w=0;h=1;cutoff=5000;target=6423;counts=Counter();edges=0
while(w,h)!=(L//2,L):
 axis=0 if w==0 or(w<h and w<L//2) else 1
 length=h if axis==0 else w
 def E25(a):
  if axis==0:
   pos=h if w else a;mx=w+(a>0);mn=w+(a==h) if h==L else 0
  else:
   pos=h+(a>0);mx=w;mn=a if h+1==L else 0
  return 400*(pos+mx-mn)-(w*h+a)
 for a in range(length):
  for e in [E25(a),E25(a+1)]:
   j=25*target-e;assert j>=0;counts[min(j,cutoff)]+=1
  edges+=1
 if axis==0:w+=1
 else:h+=1
# e^.04 strictly greater than its positive Taylor truncation.
lo=sum((F(1,25)**k/F(math.factorial(k)) for k in range(13)),F(0))
with localcontext() as c:
 c.prec=70;c.rounding=ROUND_FLOOR
 dlo=Decimal(lo.numerator)/Decimal(lo.denominator)
 c.rounding=ROUND_CEILING
 q=Decimal(1)/dlo
 val=Decimal(0)
 for j in range(cutoff,-1,-1):val=val*q+Decimal(counts[j])
 # Reservoir term e^(2593.6-6423) < e^-200 < q^5000.
 source=Decimal(1)
 for _ in range(cutoff):source*=q
 val+=source
 # Pay log(ZA/wminus)<1e-6: e^1e-6 < 1/(1-1e-6).
 normalized=val/(Decimal(1)-Decimal('0.000001'))
 assert normalized<1
 out={'target_log_inverse_lower':target,'normalized_resistance_over_exp_target_upper':str(normalized),'q_upper':str(q),'directed_decimal_digits':70,'edges':edges,'seconds':time.perf_counter()-start,'meaning':'Original Ckappa/ZA > exp(-6423), conditional only on stated geometry/core and inherited kappa bound. Positive arithmetic directed upward; tail explicitly lumped.'}
 print(json.dumps(out,indent=2))
 open('research_notes/capacity_resume_20261114/certify_width1_results.json','w').write(json.dumps(out,indent=2))
