"""Exact area coefficients and exact area-conditioned boxed Young draws."""
from math import comb
from functools import lru_cache

def rectangle_coeff(a,b,limit=None):
 if a<0 or b<0:return []
 a,b=min(a,b),max(a,b);degree=a*b
 if limit is not None:degree=min(degree,limit)
 c=[0]*(degree+1);c[0]=1
 for i in range(1,a+1):
  end=min(degree,b*i)
  for j in range(i,end+1):c[j]+=c[j-i]
  for j in range(end,b+i-1,-1):c[j]-=c[j-b-i]
 assert all(x>=0 for x in c)
 return c

def corner_powers(k,limit=None):
 limit=4*k*k if limit is None else min(limit,4*k*k)
 s=rectangle_coeff(k,k,limit);chunk=k+1;bits=8*chunk
 base=int.from_bytes(b''.join(x.to_bytes(chunk,'little') for x in s),'little')
 mask=(1<<(bits*(limit+1)))-1
 packed=1;out=[]
 for d in range(5):
  if d:packed=(packed*base)&mask
  b=packed.to_bytes((limit+1)*chunk,'little')
  out.append([int.from_bytes(b[i*chunk:(i+1)*chunk],'little') for i in range(limit+1)])
 return out

def pick_int(weights,rng):
 total=sum(weights);assert total>0;x=rng.randrange(total)
 for i,w in enumerate(weights):
  if x<w:return i
  x-=w
 raise AssertionError

def sample_rectangle_area(a0,b0,A,rng):
 @lru_cache(None)
 def count(a,b,t):
  if t<0 or t>a*b:return 0
  return rectangle_coeff(a,b,t)[t]
 a=a0;b=b0;rows=[0]*a0
 assert count(a,b,A)>0
 while a and b:
  weights=[count(a-1,b,A),count(a,b-1,A-a)]
  if pick_int(weights,rng)==0:a-=1
  else:
   for i in range(a):rows[i]+=1
   A-=a;b-=1
 assert A==0 and all(x>=y for x,y in zip(rows,rows[1:]))
 return tuple(rows)

def sample_corner_area(k,A,rng):
 return sample_rectangle_area(k,k,A,rng)

def sample_four_area(k,A,rng,powers=None):
 ps=powers or corner_powers(k,A);parts=[]
 for remaining in range(4,0,-1):
  weights=[ps[1][a]*ps[remaining-1][A-a] for a in range(min(k*k,A)+1)]
  a=pick_int(weights,rng);parts.append(sample_corner_area(k,a,rng));A-=a
 assert A==0
 return parts


def marked_coeff(k,limit=None):
 limit=k*k-1 if limit is None else min(limit,k*k-1)
 g=rectangle_coeff(k-1,k,limit);out=[];running=0
 for A in range(limit+1):
  if A<len(g):running+=g[A]
  if 0<=A-k<len(g):running-=g[A-k]
  out.append(running)
 return out

def sample_marked_area(k,A,rng):
 g=rectangle_coeff(k-1,k,A)
 weights=[g[A-j] if 0<=A-j<len(g) else 0 for j in range(k)]
 j=pick_int(weights,rng)
 lam=sample_rectangle_area(k-1,k,A-j,rng)
 # Binary word: a row length equals the number of zeros after its 1.
 word=[];zeros=k
 for l in lam:
  word.extend([0]*(zeros-l));word.append(1);zeros=l
 word.extend([0]*zeros)
 ordinal=k-j;seen=0
 for pos,bit in enumerate(word):
  if bit==0:seen+=1
  if seen==ordinal:
   markrow=sum(word[:pos+1]);word.insert(pos+1,1);break
 out=[];zeros=k
 for bit in word:
  if bit==0:zeros-=1
  else:out.append(zeros)
 mark=(markrow,out[markrow]);assert sum(out)==A
 return tuple(out),mark
