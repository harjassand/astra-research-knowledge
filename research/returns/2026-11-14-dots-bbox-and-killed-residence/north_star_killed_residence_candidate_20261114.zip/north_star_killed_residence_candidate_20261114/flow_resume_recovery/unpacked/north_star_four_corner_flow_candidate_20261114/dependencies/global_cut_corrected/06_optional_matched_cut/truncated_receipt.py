from pathlib import Path
from decimal import Decimal as D,localcontext,ROUND_FLOOR,ROUND_CEILING
import json
p=Path(__file__).resolve().parent
H={int(t):int(c) for t,c in json.loads((p/'coefficients_k100.json').read_text()).items() if 2*int(t)<=1900}
assert H
with localcontext() as c:
 c.prec=110;c.rounding=ROUND_FLOOR
 terms=[D(v).ln().next_minus()-16*t for t,v in H.items()];m=max(terms)
 logsum=m+sum((x-m).exp().next_minus() for x in terms).ln().next_minus()
 logG=D(2560000).ln().next_minus()+(D(24)/49).ln().next_minus()+D(156026)/25+logsum
with localcontext() as c:
 c.prec=110;c.rounding=ROUND_CEILING
 logZA=D(2).ln().next_plus()+D(15360000)/(D(500)**3*499)
with localcontext() as c:
 c.prec=110;c.rounding=ROUND_FLOOR
 lo=logG-logZA
assert lo>=-6236
out=dict(perimeter_cap=1900,retained_classes=len(H),minimum_perimeter=2*min(H),maximum_perimeter=2*max(H),log_subset_over_wminus_lower=str(logG),log_subset_over_ZA_lower=str(lo),integer_lower='exp(-6236)',scope='Same actual cut; pure Ferrers companions; inverse full-domain flip is all-minus in auxiliary core. Restricts exact coefficient sum explicitly. Not capacity lower.')
(p/'truncated_receipt.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
