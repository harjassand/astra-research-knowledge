#pragma STDC FENV_ACCESS ON
#include <vector>
#include <iostream>
#include <cfenv>
#include <cmath>
#include <string>
#include <cfloat>
#include <limits>
int main(int argc,char** argv){
 bool marked=argc>1;
 std::fesetround(FE_UPWARD);
 volatile long double one=1.L,tiny=std::ldexp(1.L,-LDBL_MANT_DIG-1),rounded=one+tiny;
 volatile long double sub=std::numeric_limits<long double>::denorm_min(),half=.5L,subrounded=sub*half;
 if(!(rounded>one)||!(sub>0)||!(subrounded>=sub)){std::cerr<<"rounding/subnormal test failed";return 5;}
 std::feclearexcept(FE_ALL_EXCEPT);
 int M,S0;std::string qs;if(!(std::cin>>M>>S0>>qs))return 1;long double q=strtold(qs.c_str(),0);
 std::vector<long double>w(M+1);for(int i=0;i<=M;i++){std::string s;std::cin>>s;w[i]=strtold(s.c_str(),0);}
 std::vector<long double> a(1,1.L);
 for(int j=1;j<=8;j++){
  std::vector<long double>b(a.size()+M,0.L);
  for(size_t i=0;i<a.size();i++)if(a[i]>0)for(int p=4;p<=M;p+=2)if(w[p]>0)b[i+p]+=a[i]*w[p];
  a.swap(b);long double h=0;
  for(int s=(int)a.size()-1;s>=S0;s--)h=h*q+(marked?s*a[s]:a[s]);
  if(!std::isfinite(h))return 2;
  std::cout<<j<<" "<<std::hexfloat<<h<<std::defaultfloat<<"\n";
 }
 std::cerr<<"underflow_flag="<<(bool)std::fetestexcept(FE_UNDERFLOW)<<" overflow_flag="<<(bool)std::fetestexcept(FE_OVERFLOW)<<"\n";
}
