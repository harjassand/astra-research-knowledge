"""Exact rational original-clock benchmark, no thermal pair receipt required."""
from fractions import Fraction as F
from math import factorial
from pathlib import Path
import json
assert sum(F(7,10)**j/factorial(j) for j in range(6))>2
def logup(q):
 q=F(q);b=0
 while F(2)**b<q:b+=1
 return F(7*b,10)
R=200;r=5;n=64*R*R;eps=F(1,100)
# gamma0^-1=384(r+2)^8(1+e40)e^{(8log2+352)(r+2)}.
# kappa^-1=128 gamma0^-1 [n(log2+24)+log2]/eps.
pref=F(256*384)/eps*(r+2)**8*(n+1)*F(247,10)
ku=logup(pref)+40+F(1788,5)*(r+2)
Gamma=F(32*R*50000,49999)+32
old=max(ku,logup(2*n)+Gamma)+F(7,10)
assert ku<=F(12968,5) and old<6449
out={'original_epsilon':'1/100','original_r':r,'R':R,'log_kappa_inverse_upper_exact':str(ku),'log_bulk_free_lower_denominator_upper_exact':str(old),'capacity_lower':'exp(-6449)','marked_cut_energy_upper':'exp(-6215)','original_trivial_capacity_upper_not_stronger_than_marked':True,'safe_retained_acceptance_lower':'0.5 exp(-234)','safe_expected_attempts_upper':'2 exp(234)','uniform_polynomial_or_practical_claim':False}
print(json.dumps(out,indent=2));Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
