import math,json
R=200;n=64*R*R;t=8/R;bare_log=6422.77191876298;out=[]
for d in [100,128,130,131,132,133]:
 K=2*d+1;M=3*R
 zlog=sum(math.log1p(-math.exp(-t*(d+i)))-math.log1p(-math.exp(-t*i)) for i in range(1,d+1));Nlog=math.log(math.comb(2*d,d))
 prefix=math.log(2*K*K)+32*K-t*K*K+t*K+4*(Nlog-zlog)
 core=math.log(2*(d+1)**3)+bare_log-math.log(n)-4*zlog
 merge=math.log(8*d*d)+32*M-t*M*M+4*(Nlog-zlog)
 after=math.log(2*n)+32*M-t*M*M+16
 vals=[prefix,core,merge,after];v=max(vals);total=math.log(3)+v+math.log(sum(math.exp(x-v) for x in vals))+1e-6
 out.append(dict(R=R,d=d,K=K,M=M,log_Z=zlog,log_N=Nlog,log_prefix=prefix,log_core=core,log_merge=merge,log_post=after,log_upper_inverse_capacity_candidate=total,log_W_over_C_candidate=total-6215,status='conditional scalar diagnostic, not an outward certificate; geometry/overlap proof requires review'))
print(json.dumps(out,indent=2));open('research_notes/capacity_resume_20261114/corner_bound_scalar_results.json','w').write(json.dumps(out,indent=2))
