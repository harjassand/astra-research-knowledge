import math,itertools,time,json,collections

def partitions(d):
 out=[]
 def rec(a,cap):
  if len(a)==d:out.append(tuple(a));return
  for x in range(cap+1):rec(a+[x],x)
 rec([],d);return out

def run(R,d):
 L=8*R;t=8/R;K=2*d+1;M=3*R;n=L*L;ps=partitions(d);q=math.exp(-t);Z=sum(q**sum(p) for p in ps);flows=collections.defaultdict(float);multiplicity=collections.Counter();t0=time.perf_counter();worst=0;div=collections.defaultdict(float);coreedges=0;prefixcheck=0;labelmax=0
 def shape(w,h,C):
  bl,br,tl,tr=C;S=0
  for y in range(h):
   left=bl[y] if y<d else tl[h-1-y] if y>=h-d else 0
   right=br[y] if y<d else tr[h-1-y] if y>=h-d else 0
   for x in range(left,w-right):S|=1<<(y*L+x)
  return S
 def neigh(S,v):
  x=v%L;y=v//L
  return sum((S>>u)&1 for u in [y*L+(x-1)%L,y*L+(x+1)%L,((y-1)%L)*L+x,((y+1)%L)*L+x])
 def rectangle(w,h):return sum(((1<<w)-1)<<(y*L) for y in range(h))
 def coreorder(w,h,C,axis):
  bl,br,tl,tr=C;length=h if axis==0 else w;lo=br if axis==0 else tuple(sum(a>i for a in tl) for i in range(d));hi=tr if axis==0 else tuple(sum(a>i for a in tr) for i in range(d))
  # For upward growth left active=TL, right active=TR.
  rows=[]
  for z in range(d-1,-1,-1):
   if hi[z]>0:rows.append(length-1-z)
  for z in range(d-1,-1,-1):
   if lo[z]>0:rows.append(z)
  rows += [z for z in range(length) if (lo[z] if z<d else hi[length-1-z] if z>=length-d else 0)==0]
  ans=[]
  for z in rows:
   cut=lo[z] if z<d else hi[length-1-z] if z>=length-d else 0
   ans.append(z*L+w-cut if axis==0 else (h-cut)*L+z)
  return ans
 for C in itertools.product(ps,repeat=4):
  A=sum(map(sum,C));p=q**A/Z**4;S=0;E=0;coreR=0;actualR=0;seen=set()
  def add(v,phase):
   nonlocal S,E,coreR,actualR,prefixcheck
   assert not (S>>v)&1
   nn=neigh(S,v);E1=E+32-16*nn-t;r=math.exp(E)+math.exp(E1);actualR+=r
   if phase=='core':
    assert nn in [1,2];coreR+=r;multiplicity[(S,v)]+=1
   flows[(S,v)]+=p;S|=1<<v;E=E1
   if phase=='prefix':
    xs=[];ys=[];b=S
    while b:
     bit=b&-b;i=bit.bit_length()-1;xs.append(i%L);ys.append(i//L);b-=bit
    w=max(xs)-min(xs)+1;h=max(ys)-min(ys)+1
    # Check energy upper from bounding box, full label deficit, and one partialrow.
    assert E <= 16*(w+h)-t*w*h+t*(A+K)+1e-8
  target=shape(K,K,C)
  prev=None
  for y in range(K):
   xs=[x for x in range(K) if (target>>(y*L+x))&1];lo=min(xs);hi=max(xs)
   start=lo if prev is None else max(lo,prev[0]);assert start<=hi and(prev is None or start<=prev[1])
   for x in [start]+list(range(start-1,lo-1,-1))+list(range(start+1,hi+1)):add(y*L+x,'prefix')
   prev=(lo,hi)
  assert S==target
  w=h=K
  while(w,h)!=(M,M):
   axis=0 if w==h else 1
   oldS=S
   for v in coreorder(w,h,C,axis):add(v,'core')
   if axis==0:w+=1
   else:h+=1
   assert S==shape(w,h,C)
  miss=rectangle(M,M)^S
  while miss:
   b=miss;v=None
   while b:
    bit=b&-b;u=bit.bit_length()-1;b-=bit
    if neigh(S,u)>=2:v=u;break
   assert v is not None;add(v,'fill');miss^=1<<v
  w=h=M
  while(w,h)!=(L//2,L):
   axis=0 if w<=h and w<L//2 else 1
   if axis==0:
    for y in range(h):add(y*L+w,'after')
    w+=1
   else:
    for x in range(w):add(h*L+x,'after')
    h+=1
  # Exactly majority reached, no intermediate target state.
  assert S.bit_count()==n//2
 # physical anchored resistance, no translation claim in this numerical sum
 Rflow=0.;maxdiv=0.
 for (S,v),f in flows.items():
  # native energy exactly from NN physical perimeter, small finite test only
  b=S;per=0
  while b:
   bit=b&-b;u=bit.bit_length()-1;b-=bit;per+=4-neigh(S,u)
  E=8*per-t*S.bit_count();E1=E+32-16*neigh(S,v)-t
  Rflow+=f*f*(math.exp(E)+math.exp(E1));div[S]+=f;div[S|(1<<v)]-=f
 for S,v in div.items():
  if S and S.bit_count()<n//2:maxdiv=max(maxdiv,abs(v))
 assert maxdiv<1e-10
 return {'R':R,'d':d,'partitions':len(ps),'channels':len(ps)**4,'core_Multiplicity':max(multiplicity.values()),'safe_core_M_bound':2*(d+1)**3,'anchored_logR':math.log(Rflow),'physical_edges':len(flows),'max_divergence':maxdiv,'source_outflow':div[0],'seconds':time.perf_counter()-t0,'all_prefix_bounds_and_core_steps_checked':True}
if __name__=='__main__':
 out=[run(2,1),run(4,2)];print(json.dumps(out,indent=2));open('research_notes/capacity_resume_20261114/corner_channel_check_results.json','w').write(json.dumps(out,indent=2))
