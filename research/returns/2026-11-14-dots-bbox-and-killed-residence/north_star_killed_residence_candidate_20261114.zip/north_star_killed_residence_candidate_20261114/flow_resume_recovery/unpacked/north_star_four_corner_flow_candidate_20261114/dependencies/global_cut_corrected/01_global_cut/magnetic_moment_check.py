from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path
import json
from walk_area_check import counts,steps

def moments(M,kind,r):
 dp=defaultdict(F)
 for du,dv,c in steps[kind]:
  if c==1:dp[(du,dv,1-kind,du,dv)]+=1
 out={};peak=0
 for p in range(1,M+1):
  peak=max(peak,len(dp));total=F(0)
  for (u,v,typ,pu,pv),val in dp.items():
   if u==v==0:total+=val
   zu,zv,_=steps[typ][0]
   if u+zu==v+zv==0:total+=val*r**(u*zv-v*zu)
  out[p]=total
  if p==M:break
  nd=defaultdict(F)
  for (u,v,typ,pu,pv),val in dp.items():
   for du,dv,c in steps[typ]:
    if c==1 and (du,dv)!=(-pu,-pv):nd[(u+du,v+dv,1-typ,du,dv)]+=val*r**(u*dv-v*du)
   zu,zv,_=steps[typ][0];uu=u+zu;vv=v+zv;ar=u*zv-v*zu
   for du,dv,c in steps[1-typ]:
    if c==1:nd[(uu+du,vv+dv,typ,du,dv)]+=val*r**(ar+uu*dv-vv*du)
  dp=nd
 return out,peak
def run():
 rows=[]
 for kind in (0,1):
  raw,_=counts(8,kind,signed=True)
  for r in (F(1),F(101,100)):
   got,peak=moments(8,kind,r)
   for p in range(1,9):
    target=sum(F(n)*r**(18*a) for (pp,a),n in raw.items() if pp==p)
    assert got[p]==target
   rows.append({'root_type':kind,'rational_shoelace_activity':str(r),'physical_perimeters_checked':8,'exact_area_sum_equals_endpoint_DP':True,'max_endpoint_states':peak})
 out={'scope':'Independent exact area-enumeration versus positive endpoint-only magnetic moment DP; not large-R sharpness','rows':rows}
 print(json.dumps(out,indent=2));Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')

if __name__=="__main__":run()
