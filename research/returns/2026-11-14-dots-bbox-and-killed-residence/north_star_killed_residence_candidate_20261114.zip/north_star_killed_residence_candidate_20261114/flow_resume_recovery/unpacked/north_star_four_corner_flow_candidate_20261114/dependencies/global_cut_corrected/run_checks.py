"""Run on a disposable copy; never mutate the distributed receipts. --full regenerates large DP."""
from pathlib import Path
import tempfile,shutil,subprocess,sys,os,json
root=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='n1722_global_check_') as td:
 work=Path(td)/'package';shutil.copytree(root,work)
 g=work/'01_global_cut';env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
 for stem,key in [('magnetic_upper','N1722_MAGNETIC'),('convolution_upper','N1722_CONVOLUTION')]:
  exe=Path(td)/stem
  subprocess.run(['g++','-O3','-std=c++17','-frounding-math','-ffp-contract=off','-fno-fast-math',str(g/(stem+'.cpp')),'-o',str(exe)],check=True)
  env[key]=str(exe)
 if '--full' in sys.argv:
  for num,den in [(201,200),(101,100),(51,50)]:
   with (g/f'cert_r200/moment_{num}_{den}.txt').open('w') as f:
    subprocess.run([env['N1722_MAGNETIC'],'1900',str(num),str(den)],stdout=f,env=env,check=True)
 for script in ['walk_area_check.py','magnetic_moment_check.py','physical_trace_check.py','check_directed_arithmetic.py','check_convolution_arithmetic.py','energy_proposal_identity_check.py','certify_global_upper.py','certify_global_upper_marked.py','auxiliary_core_error_check.py','original_clock_benchmark.py']:
  subprocess.run([sys.executable,str(g/script)],env=env,cwd=work,check=True)
 for script in ['02_old_cut_dependency/check.py','04_independent_proposal_review/check.py','03_thermal_core_dependency/thermal_capacity_flow_test.py','07_arithmetic_correction/check_single_mode.py','07_arithmetic_correction/independent_scalar_check.py','07_arithmetic_correction/subnormal_convolution_check.py']:
  subprocess.run([sys.executable,str(work/script)],env=env,cwd=work,check=True)
 subprocess.run([sys.executable,str(work/'06_optional_matched_cut/receipt.py'),'100'],env=env,cwd=work,check=True)
 for script in ['geometry_check.py','truncated_receipt.py']:
  subprocess.run([sys.executable,str(work/'06_optional_matched_cut'/script)],env=env,cwd=work,check=True)
 new=json.loads((g/'cert_r200/certificate_marked_s79_40.json').read_text())
 from decimal import Decimal
 assert Decimal(new['log_capacity_over_ZA_upper']) < -6215
 print('PASS: complete marked upper < exp(-6215); all small exact and arithmetic tests passed.')
 print('Large magnetic recurrence regenerated:', '--full' in sys.argv)
