#pragma STDC FENV_ACCESS ON
#include <array>
#include <vector>
#include <cmath>
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <chrono>
#include <cfenv>
#include <cfloat>
using A=std::array<long double,4>;
int main(int argc,char**argv){
 int M=argc>1?atoi(argv[1]):16;long long rn=argc>2?atoll(argv[2]):101,rd=argc>3?atoll(argv[3]):100;
 if(rn<rd||rd<=0)return 4;
 std::fesetround(FE_UPWARD);volatile long double one=1.L,tiny=std::ldexp(1.L,-65);volatile long double z=one+tiny;
 if(!(z>one)||LDBL_MANT_DIG<64){std::cerr<<"rounding test failed";return 5;}
 int h=M/2+1,N=2*h+1;std::vector<A> a(N*N),b(N*N);int dx[4]={1,0,-1,0},dy[4]={0,1,0,-1};
 auto ix=[&](int x,int y){return (x+h)*N+y+h;};
 for(int j=0;j<4;j++)a[ix(dx[j],dy[j])][j]=1;
 std::vector<long double> plo(h+1),phi(h+1),ep(N),em(N);plo[0]=phi[0]=1;
 std::fesetround(FE_DOWNWARD);volatile long double rlo=(long double)rn/(long double)rd;
 for(int i=1;i<=h;i++)plo[i]=plo[i-1]*rlo;
 std::fesetround(FE_UPWARD);volatile long double rhi=(long double)rn/(long double)rd;
 for(int i=1;i<=h;i++)phi[i]=phi[i-1]*rhi;
 for(int i=0;i<=h;i++){ep[h+i]=em[h-i]=phi[i];em[h+i]=ep[h-i]=1.L/plo[i];}
 long long scale=0;auto tm=std::chrono::steady_clock::now();
 std::cout<<"# M "<<M<<" rational_r "<<rn<<"/"<<rd<<" mantissa "<<LDBL_MANT_DIG<<" upward\n";
 std::feclearexcept(FE_ALL_EXCEPT);
 for(int p=1;p<=M;p++){
  long double root=0;for(auto v:a[ix(0,0)])root+=v;
  if(root>0)std::cout<<p<<" "<<std::hexfloat<<root<<std::defaultfloat<<" "<<scale<<"\n";
  if(p==M)break;
  std::fill(b.begin(),b.end(),A{});int d=std::min(p,M-p),dn=std::min(p+1,M-p-1);long double vmax=0;
  for(int x=-d;x<=d;x++)for(int y=-(d-abs(x));y<=d-abs(x);y++){
   if(((x+y-p)&1)!=0)continue;
   auto &v=a[ix(x,y)];if(v[0]==0&&v[1]==0&&v[2]==0&&v[3]==0)continue;
   long double weights[4]={em[y+h],ep[x+h],ep[y+h],em[x+h]};
   for(int j=0;j<4;j++){
    int xx=x+dx[j],yy=y+dy[j];if(abs(xx)+abs(yy)>dn)continue;
    long double add=(v[j]+v[(j+1)%4]+v[(j+3)%4])*weights[j];
    auto &w=b[ix(xx,yy)][j];w+=add;vmax=std::max(vmax,w);
   }
  }
  if(!std::isfinite(vmax)){std::cerr<<"overflow";return 3;}
  if(vmax>std::ldexp(1.L,4000)){
   for(int x=-dn;x<=dn;x++)for(int y=-(dn-abs(x));y<=dn-abs(x);y++)for(auto &v:b[ix(x,y)])v=std::ldexp(v,-4000);
   scale+=4000;
  }
  a.swap(b);
 }
 std::cerr<<"M="<<M<<" r="<<rn<<"/"<<rd<<" seconds="<<std::chrono::duration<double>(std::chrono::steady_clock::now()-tm).count()<<" underflow_flag="<<(bool)std::fetestexcept(FE_UNDERFLOW)<<" overflow_flag="<<(bool)std::fetestexcept(FE_OVERFLOW)<<"\n";
}
