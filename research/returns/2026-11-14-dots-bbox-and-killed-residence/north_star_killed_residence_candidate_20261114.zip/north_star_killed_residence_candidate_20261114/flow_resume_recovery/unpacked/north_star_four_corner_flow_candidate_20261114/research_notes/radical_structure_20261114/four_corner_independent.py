import itertools,collections,json,time

def parts(d):
 return [x for x in itertools.combinations_with_replacement(range(d+1),d)][::-1] # reverse individual below

def run(d):
 ps=[tuple(reversed(x)) for x in parts(d)]
 h=2*d+1; counts=collections.Counter(); witness={}; maxc=0
 for low,high in itertools.product(ps,repeat=2):
  original=low+(0,)+tuple(reversed(high)); deficits=list(original)
  rows=[h-1-z for z in range(d-1,-1,-1) if high[z]]+[z for z in range(d-1,-1,-1) if low[z]]+[z for z in range(h) if original[z]==0]
  born=False
  for z in rows:
   # Endpoint shape is represented by deficit vector against its actual bbox.
   state=tuple(v+int(born) for v in deficits)
   # Added cell horizontal coordinate against old width; y=z.
   key=(born,state,z,-original[z])
   counts[key]+=1
   deficits[z]-=1
   if original[z]==0:born=True
 return dict(d=d,partitions=len(ps),pairs=len(ps)**2,edges=sum(counts.values()),maximum=max(counts.values()),bound=(d+1)**3)
start=time.time();out=[run(d) for d in range(1,6)];print(json.dumps(out,indent=2));print(time.time()-start)
open('research_notes/radical_structure_20261114/four_corner_independent.json','w').write(json.dumps(out,indent=2))
