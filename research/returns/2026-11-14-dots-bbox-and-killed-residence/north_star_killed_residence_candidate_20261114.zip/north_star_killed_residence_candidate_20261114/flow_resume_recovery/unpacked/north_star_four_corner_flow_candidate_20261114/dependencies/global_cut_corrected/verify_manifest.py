from pathlib import Path
import hashlib
root=Path(__file__).resolve().parent
seen=set()
for line in (root/'SHA256SUMS.txt').read_text().splitlines():
 digest,name=line.split('  ',1);p=root/name
 assert p.is_file(),name
 assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,name
 seen.add(name)
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt' and '__pycache__' not in p.parts}
assert seen==actual,(seen-actual,actual-seen)
print('PASS:',len(seen),'manifest entries, no missing or unexpected files.')
