#pragma STDC FENV_ACCESS ON
#include <cfenv>
#include <iostream>
#include <cstdlib>
int main(int argc,char**argv){long long rn=atoll(argv[1]),rd=atoll(argv[2]);
 std::fesetround(FE_DOWNWARD);volatile long double rlo=(long double)rn/(long double)rd;
 std::fesetround(FE_UPWARD);volatile long double rhi=(long double)rn/(long double)rd;
 std::cout<<std::hexfloat<<(long double)rlo<<" "<<(long double)rhi<<"\n";
 volatile long double n=rn,d=rd;
 volatile long double rfixed=n/d;
 std::cout<<(long double)rfixed<<"\n";
}
