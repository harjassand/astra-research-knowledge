"""Reproduce frozen package in a temporary copy; no network or file changes to release."""
from pathlib import Path
import tempfile,subprocess,shutil,json,os,time,hashlib,sys
root=Path(__file__).resolve().parent;start=time.time();rows=[]
def run(cmd,cwd,env=None):
 t=time.time();p=subprocess.run(cmd,cwd=cwd,env=env,text=True,capture_output=True)
 rows.append({'command':list(map(str,cmd)),'cwd':str(Path(cwd).relative_to(work)),'exit_code':p.returncode,'seconds':time.time()-t,'stdout':p.stdout,'stderr':p.stderr})
 if p.returncode:raise RuntimeError(rows[-1])
try:
 with tempfile.TemporaryDirectory(prefix='bbox-reproduce-') as tmp:
  work=Path(tmp)/'release';shutil.copytree(root,work)
  f=work/'research_notes/flow_resume_20261114';s=work/'research_notes/source_reconstructed_20261114'
  dep=work/'flow_resume_recovery/unpacked/north_star_four_corner_flow_candidate_20261114/dependencies/global_cut_corrected'
  run(['python','verify_manifest.py'],dep)
  run(['python','run_checks.py']+(['--full'] if '--full' in sys.argv else []),dep)
  run(['python',str(f/'certify_reconstructed_pushforward.py')],work)
  run(['python',str(f/'check_pushforward_moments.py')],work)
  run(['python',str(f/'check_augmented_bbox.py')],work)
  run(['python',str(f/'check_bbox_flip.py')],work)
  run(['python',str(s/'check_torus_bbox.py')],work)
  run(['python',str(f/'bbox_paid_scalar.py')],work)
  binary=f/'optimized_bbox/convolution_rebuilt'
  run(['g++','-O2','-std=c++17','-frounding-math','-fno-fast-math','-fno-tree-pre','-fno-tree-fre',str(f/'optimized_bbox/convolution.cpp'),'-o',str(binary)],work)
  env=dict(os.environ,N1722_CONVOLUTION=str(binary))
  run(['python',str(f/'optimized_bbox/certify.py'),'200','159/80'],work,env)
  run(['python',str(f/'check_omissions.py')],work)
  r=json.loads((f/'certify_reconstructed_pushforward.json').read_text())
  u=json.loads((f/'optimized_bbox/cert_r200/certificate_marked_s159_80.json').read_text())
  from decimal import Decimal
  assert Decimal(r['normalized_resistance_upper'])<1
  assert Decimal(u['log_capacity_over_ZA_upper'])+6251<20
  if (f/'bbox_sampler_toy.py').exists():run(['python',str(f/'bbox_sampler_toy.py')],work)
  summary={'passed':True,'seconds':time.time()-start,'full_magnetic_recurrences_recomputed':'--full' in sys.argv,'normalized_resistance_upper':r['normalized_resistance_upper'],'log_bbox_energy_upper':u['log_capacity_over_ZA_upper'],'log_ratio_upper':str(Decimal(u['log_capacity_over_ZA_upper'])+6251),'steps':rows}
except Exception as e:
 summary={'passed':False,'error':str(e),'seconds':time.time()-start,'steps':rows}
(root/'REPRODUCTION_RECEIPT.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='steps'},indent=2))
assert summary['passed']
