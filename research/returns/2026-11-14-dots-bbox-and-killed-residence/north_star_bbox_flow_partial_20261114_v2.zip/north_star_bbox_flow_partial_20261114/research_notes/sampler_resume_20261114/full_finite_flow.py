from core_occupancy import *
import itertools,heapq

def deterministic_prefix(C,K,d):
 S=set();previous=None
 for y in range(K):
  row=sorted(x for x,z in shape(C,K,K,d) if z==y);lo,hi=row[0],row[-1];s=lo if previous is None else max(lo,previous)
  for x in [s]+list(range(s-1,lo-1,-1))+list(range(s+1,hi+1)):
   yield frozenset(S),(x,y);S.add((x,y))
  previous=lo

def deterministic_merge(C,M,d):
 S=shape(C,M,M,d);holes={(x,y) for x in range(M) for y in range(M)}-S
 def nn(x,y):return sum(z in S for z in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)])
 H=[(y,x) for x,y in holes if nn(x,y)>=2];heapq.heapify(H)
 while H:
  y,x=heapq.heappop(H)
  if (x,y) not in holes:continue
  assert nn(x,y)>=2
  yield frozenset(S),(x,y);holes.remove((x,y));S.add((x,y))
  for xx,yy in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
   if (xx,yy) in holes and nn(xx,yy)>=2:heapq.heappush(H,(yy,xx))
 assert not holes

def late(M,L):
 S={(x,y) for x in range(M) for y in range(M)};w=h=M
 while (w,h)!=(L//2,L):
  axis=0 if w<=h and w<L//2 else 1
  for z in range(h if axis==0 else w):
   v=(w,z) if axis==0 else(z,h);yield frozenset(S),v;S.add(v)
  if axis==0:w+=1
  else:h+=1

def key(S,v,ox,oy,L):
 return sum(1<<(((y+oy)%L)*L+(x+ox)%L) for x,y in S),((v[1]+oy)%L)*L+(v[0]+ox)%L
if __name__=='__main__':
 start=time.perf_counter();d=1;K=3;M=4;L=8;n=L*L;q=F(1,2);ps=parts(d);Z=sum(q**sum(p) for p in ps);D={p:defaultdict(F) for p in ['prefix','core','merge','late']}
 for C in itertools.product(ps,repeat=4):
  weight=q**sum(map(sum,C))/(Z**4*n)
  paths={'prefix':[(S,v,weight) for S,v in deterministic_prefix(C,K,d)],'merge':[(S,v,weight) for S,v in deterministic_merge(C,M,d)],'core':[]}
  for a in range(K,M):
   for axis in (0,1):
    for S,v,z in forward(C,a,a+axis,d,q):
     if axis:S=frozenset((y,x) for x,y in S);v=v[::-1]
     paths['core'].append((S,v,z/(Z**4*n)))
  for phase,path in paths.items():
   for S,v,z in path:
    for ox,oy in itertools.product(range(L),repeat=2):D[phase][key(S,v,ox,oy,L)]+=z
 for S,v in late(M,L):
  for ox,oy in itertools.product(range(L),repeat=2):D['late'][key(S,v,ox,oy,L)]+=F(1,n)
 total=defaultdict(F)
 for dd in D.values():
  for e,x in dd.items():total[e]+=x
 neighbors=[[(y*L+(x+1)%L),(y*L+(x-1)%L),(((y+1)%L)*L+x),(((y-1)%L)*L+x)] for y in range(L) for x in range(L)]
 @lru_cache(None)
 def potential(s):
  perimeter=sum(1 for i in range(n) if s>>i&1 for j in neighbors[i] if not s>>j&1)
  return 2*perimeter-s.bit_count()
 def resistance(e):
  s,v=e;return F(2)**potential(s)+F(2)**potential(s|(1<<v))
 div=defaultdict(F)
 for (s,v),val in total.items():div[s]+=val;div[s|(1<<v)]-=val
 assert div[0]==1 and all(x==0 or s.bit_count()==n//2 for s,x in div.items() if s)
 assert sum(-x for s,x in div.items() if s.bit_count()==n//2)==1
 phaseE={p:sum(z*z*resistance(e) for e,z in dd.items()) for p,dd in D.items()}
 fullE=F(1)+sum(z*z*resistance(e) for e,z in total.items())
 overlaps={};cross={}
 for a,b in itertools.combinations(D,2):
  es=set(D[a])&set(D[b]);overlaps[a+'_'+b]=len(es)
  cross[a+'_'+b]=2*sum(D[a][e]*D[b][e]*resistance(e) for e in es)
 assert fullE==1+sum(phaseE.values())+sum(cross.values())
 out={'d':d,'K':K,'M':M,'L':L,'channels':len(ps)**4,'translations':n,'physical_edges_by_phase':{p:len(v) for p,v in D.items()},'distinct_physical_edges':len(total),'overlap_edge_counts':overlaps,'phase_resistances':{p:float(x) for p,x in phaseE.items()},'cross_phase_resistances':{p:float(x) for p,x in cross.items()},'reservoir_resistance':1,'full_resistance':float(fullE),'capacity_lower_bound':float(1/fullE),'exact_flow_conservation_verified':True,'exact_energy_cross_identity_verified':True,'seconds':time.perf_counter()-start,'scope':'Full finite translated path flow. d1 rational parameter, not R200. Deterministic lexicographic eligible-hole merge explicitly specified.'}
 Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
