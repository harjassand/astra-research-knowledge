from core_occupancy import *
from channel_sampler import table,qbounds,dec
from decimal import Decimal,localcontext,ROUND_FLOOR,ROUND_CEILING
import itertools

def merge_path(C,M,d):
 S=shape(C,M,M,d)
 for corner,lam in enumerate(C):
  for k in range(d-1,-1,-1):
   for r in range(lam[k],0,-1):
    x=r-1 if corner in(0,2) else M-r;y=k if corner in(0,1) else M-1-k;v=(x,y)
    assert sum(p in S for p in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)])>=2
    yield frozenset(S),v;S.add(v)
 assert len(S)==M*M

def merge_formula(S,v,M,d):
 C=decode(S,M,M,d)
 if C is None or v in S:return
 x,y=v
 if not(0<=x<M and 0<=y<M):return
 if y<d:k=y;top=0
 elif y>=M-d:k=M-1-y;top=2
 else:return
 if x<d:r=x+1;c=top
 elif x>=M-d:r=M-x;c=top+1
 else:return
 if C[c][k]!=r or any(C[c][i] for i in range(k+1,d)):return
 if any(any(C[i]) for i in range(c)):return
 b=d if k==0 else C[c][k-1]
 if r>b:return
 fixed=sum(C[c][:k])+sum(sum(z) for z in C[c+1:])
 return {'erased_corners':c,'fixed_area':fixed,'suffix_rows':d-k-1,'min_length':r,'max_length':b}

def qtable(d,q):
 z=[[q**0]*(d+1) for _ in range(d+1)]
 for i in range(1,d+1):
  for j in range(1,d+1):z[i][j]=z[i-1][j]+q**i*z[i][j-1]
 return z

def evalformula(f,d,q,z):
 if f is None:return q**0*0
 return z[d][d]**f['erased_corners']*q**f['fixed_area']*sum(q**l*z[f['suffix_rows']][l] for l in range(f['min_length'],f['max_length']+1))
if __name__=='__main__':
 start=time.perf_counter();d=2;M=7;q=F(1,2);z=qtable(d,q);edges=defaultdict(F)
 for C in itertools.product(parts(d),repeat=4):
  for S,v in merge_path(C,M,d):edges[S,v]+=q**sum(map(sum,C))
 for (S,v),weight in edges.items():assert evalformula(merge_formula(S,v,M,d),d,q,z)==weight
 out={'d':d,'M':M,'channels':len(parts(d))**4,'distinct_merge_edges':len(edges),'all_exact_rational_currents_match':True,'seconds':time.perf_counter()-start}
 Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(out)
