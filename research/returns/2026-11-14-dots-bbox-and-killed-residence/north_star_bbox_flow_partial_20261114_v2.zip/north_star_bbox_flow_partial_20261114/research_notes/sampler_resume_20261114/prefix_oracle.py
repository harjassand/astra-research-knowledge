from ordered_merge_oracle import *
from full_finite_flow import deterministic_prefix

def constraints(S,v,K,d):
 # S is unwrapped and anchored at its occupied min x,min y, not final box anchor.
 if not S:return None # all channel weight gives current1/n for every first flip
 x,y=v
 if not(0<=y<K) or any(z>y for a,z in S):return []
 rows=[sorted(a for a,z in S if z==b) for b in range(y+1)]
 if any(not row or row!=list(range(row[0],row[-1]+1)) for row in rows[:-1]):return []
 if rows[-1] and rows[-1]!=list(range(rows[-1][0],rows[-1][-1]+1)):return []
 width=max(a for a,z in S)+1;out=[]
 def slot(row):
  if row<d:return 0,row
  if row>=K-d:return 2,K-1-row
  return None
 for shift in range(K-width+1):
  xx=x+shift
  if not 0<=xx<K:continue
  A=[[set(range(d+1)) for _ in range(d)] for c in range(4)];ok=True
  for z,row in enumerate(rows[:-1]):
   l=row[0]+shift;r=K-1-row[-1]-shift;where=slot(z)
   if where is None:
    if l or r:ok=False;break
   else:
    c,i=where
    if not(0<=l<=d and 0<=r<=d):ok=False;break
    A[c][i]={l};A[c+1][i]={r}
  if not ok:continue
  previous=rows[-2][0]+shift if y else None;J=[a+shift for a in rows[-1]];where=slot(y)
  lefts=range(d+1) if where else [0];rights=set(range(d+1)) if where else {0}
  if not J:ls={l for l in lefts if (l if previous is None else max(l,previous))==xx}
  elif xx==J[0]-1:ls={l for l in lefts if l<=xx and (l if previous is None else max(l,previous))==J[-1]}
  elif xx==J[-1]+1:
   ls={l for l in lefts if l==J[0] and (l if previous is None else max(l,previous))<=J[-1]};rights={r for r in rights if K-1-r>=xx}
  else:continue
  if not ls or not rights:continue
  if where:
   c,i=where;A[c][i]=ls;A[c+1][i]=rights
  out.append(tuple(tuple(tuple(sorted(v)) for v in a) for a in A))
 return out

def partition_sum(allowed,q,d):
 prev=[q**0]*(d+1)
 for row in reversed(allowed):
  row=set(row);new=[];acc=q**0*0
  for b in range(d+1):
   if b in row:acc+=q**b*prev[b]
   new.append(acc)
  prev=new
 return prev[d]

def prefix_current(S,v,K,d,q):
 if not S:return qtable(d,q)[d][d]**4
 ox=min(x for x,y in S);oy=min(y for x,y in S);S={(x-ox,y-oy) for x,y in S};v=(v[0]-ox,v[1]-oy)
 cases=constraints(S,v,K,d);out=q**0*0
 for case in cases:
  p=q**0
  for allowed in case:p*=partition_sum(allowed,q,d)
  out+=p
 return out
if __name__=='__main__':
 start=time.perf_counter();d=2;K=5;q=F(1,2);edges=defaultdict(F)
 # All translations on a finite torus, including prefix origin ambiguity.
 L=12;n=L*L
 from full_finite_flow import key
 for C in itertools.product(parts(d),repeat=4):
  weight=q**sum(map(sum,C))
  for S,v in deterministic_prefix(C,K,d):
   # Fixed observed flip origin. Align its canonical site to0; translation factor1/n later.
   T=frozenset((x-v[0],y-v[1]) for x,y in S);edges[T,(0,0)]+=weight
 for (S,v),weight in edges.items():assert prefix_current(S,v,K,d,q)==weight, (S,v,weight,prefix_current(S,v,K,d,q))
 out={'d':d,'K':K,'channels':len(parts(d))**4,'distinct_flip_aligned_edges':len(edges),'all_exact_rational_currents_match':True,'seconds':time.perf_counter()-start,'normalization':'divide by nZ4'}
 Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(out)
