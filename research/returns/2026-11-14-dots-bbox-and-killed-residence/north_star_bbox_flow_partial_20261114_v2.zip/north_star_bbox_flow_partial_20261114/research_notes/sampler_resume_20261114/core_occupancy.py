"""Exact rational full core edge occupancy, inverse Ferrers decoding."""
from fractions import Fraction as F
from functools import lru_cache
from collections import defaultdict
import json,time
from pathlib import Path

def parts(d):
 def rec(a):
  if len(a)==d:yield tuple(a);return
  for x in range(a[-1] if a else d,-1,-1):yield from rec(a+(x,))
 return list(rec(()))
def valid(a,d):return len(a)==d and all(0<=x<=d for x in a) and all(a[i]>=a[i+1] for i in range(d-1))
def lift(c,p):return tuple(x+int(i<p) for i,x in enumerate(c))
def shape(C,w,h,d):
 bl,br,tl,tr=C;s=set()
 for y in range(h):
  l=bl[y] if y<d else tl[h-1-y] if y>=h-d else 0
  r=br[y] if y<d else tr[h-1-y] if y>=h-d else 0
  s.update((x,y) for x in range(l,w-r))
 return s
def decode(S,w,h,d):
 if not S or any(not (0<=x<w and 0<=y<h) for x,y in S):return
 ls=[];rs=[];rows=[[] for _ in range(h)]
 for x,y in S:rows[y].append(x)
 for y in range(h):
  row=sorted(rows[y])
  if not row or row!=list(range(row[0],row[-1]+1)):return
  ls.append(row[0]);rs.append(w-1-row[-1])
 if any(ls[y] or rs[y] for y in range(d,h-d)):return
 C=(tuple(ls[:d]),tuple(rs[:d]),tuple(reversed(ls[-d:])),tuple(reversed(rs[-d:])))
 if not all(valid(c,d) for c in C):return
 return C

def oriented_current(S,v,w,h,d,q):
 # Contributions for one known oriented macro; unnormalized by Z^4.
 u,z=v;out=F(0)
 if not (0<=u<=w and 0<=z<h) or v in S:return out
 if u==w: # central: remove outer line and decode completed corners
  base={(x,y) for x,y in S if x<w};C=decode(base,w,h,d)
  if C is None or any(x>w for x,y in S):return out
  bl,mu,tl,nu=C;J=sorted(y for x,y in S if x==w)
  if J and J!=list(range(J[0],J[-1]+1)):return out
  if z in J or not 0<=z<h:return out
  r=sum(x>0 for x in mu);s=sum(x>0 for x in nu)
  fixed=sum(map(sum,C))
  for p in range(r,d+1):
   if not valid(lift(mu,p),d):continue
   for t in range(s,d+1):
    if not valid(lift(nu,t),d):continue
    m=h-p-t;j=len(J)
    if j==0:prob=F(1,m) if p<=z<h-t else F(0)
    elif J[0]>=p and J[-1]<h-t and j<m:
     if z==J[0]-1:prob=F(J[0]-p,(m-j+1)*(m-j))
     elif z==J[-1]+1:prob=F(h-t-1-J[-1],(m-j+1)*(m-j))
     else:prob=F(0)
    else:prob=F(0)
    out+=q**(fixed+p+t)*prob
  return out
 C=decode(S,w,h,d)
 if C is None:return out
 bl,lo,tl,hi=C
 if z>=h-d: # high corner is partially processed; low original intact
  k=h-1-z
  if hi[k]<=0 or u!=w-hi[k]:return out
  for t in range(k+1,d+1):
   a=tuple(x+int(i>k and i<t) for i,x in enumerate(hi))
   if valid(a,d) and sum(x>0 for x in a)==t:
    out+=q**(sum(bl)+sum(lo)+sum(tl)+sum(a))
 elif z<d: # high completed, low partially processed
  k=z
  if lo[k]<=0 or u!=w-lo[k]:return out
  for p in range(k+1,d+1):
   a=tuple(x+int(i>k and i<p) for i,x in enumerate(lo))
   if not valid(a,d) or sum(x>0 for x in a)!=p:continue
   for t in range(sum(x>0 for x in hi),d+1):
    b=lift(hi,t)
    if valid(b,d):out+=q**(sum(bl)+sum(a)+sum(tl)+sum(b))
 return out

def current(S,v,d,K,M,q):
 # Coordinates already unwrapped with unique bounding-box anchor (0,0).
 out=F(0)
 for axis in [0,1]:
  T=S if axis==0 else {(y,x) for x,y in S};z=v if axis==0 else (v[1],v[0])
  h=max(y for x,y in T)+1
  a=h-axis
  if K<=a<M:out+=oriented_current(T,z,a,h,d,q)
 return out

def forward(C,w,h,d,q):
 S=shape(C,w,h,d);bl,lo,tl,hi=C;weight=q**sum(map(sum,C))
 order=[h-1-z for z in range(d-1,-1,-1) if hi[z]>0]+[z for z in range(d-1,-1,-1) if lo[z]>0]
 for z in order:
  cut=lo[z] if z<d else hi[h-1-z];v=(w-cut,z)
  yield frozenset(S),v,weight
  S.add(v)
 p=sum(x>0 for x in lo);t=sum(x>0 for x in hi);m=h-p-t
 for z in range(p,h-t):yield frozenset(S),(w,z),weight/F(m)
 for j in range(1,m):
  for i in range(m-j+1):
   T=S|{(w,z) for z in range(p+i,p+i+j)}
   if i:yield frozenset(T),(w,p+i-1),weight*F(i,(m-j+1)*(m-j))
   if i<m-j:yield frozenset(T),(w,p+i+j),weight*F(m-j-i,(m-j+1)*(m-j))

if __name__=='__main__':
 import itertools
 start=time.perf_counter();d=2;K=5;M=7;q=F(1,2);ps=parts(d);edges=defaultdict(F);channels=0
 for C in itertools.product(ps,repeat=4):
  channels+=1
  for a in range(K,M):
   for axis in [0,1]:
    for S,v,z in forward(C,a,a+axis,d,q):
     if axis:S=frozenset((y,x) for x,y in S);v=(v[1],v[0])
     edges[S,v]+=z
 mismatches=0
 for (S,v),z in edges.items():
  zz=current(S,v,d,K,M,q)
  if zz!=z:
   mismatches+=1
   if mismatches<3:print('mismatch',v,z,zz,sorted(S))
 out={'d':d,'K':K,'M':M,'q':str(q),'channels':channels,'distinct_physical_core_edges':len(edges),'exact_rational_mismatches':mismatches,'seconds':time.perf_counter()-start,'normalization':'divide all currents by Z^4 times torus site count for uniform translation'}
 Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(out)
 assert mismatches==0

def unwrap(S,v,L):
 """Unique anchor for compact nonwrapping-in-some-chart core shapes."""
 anchors=[]
 for axis in (0,1):
  vals=sorted({p[axis] for p in S});gaps=[((vals[(i+1)%len(vals)]-vals[i]-1)%L,i) for i in range(len(vals))]
  gap,i=max(gaps);assert sum(a==gap for a,b in gaps)==1
  origin=vals[(i+1)%len(vals)];assert max((x-origin)%L for x in vals)<L/2
  anchors.append(origin)
 ox,oy=anchors
 return frozenset(((x-ox)%L,(y-oy)%L) for x,y in S),((v[0]-ox)%L,(v[1]-oy)%L),(ox,oy)
