from prefix_oracle import *
from r200_occupancy import Poly,Symbol,evaluate
from functools import lru_cache

def prefix_interval(S,v,K,d,n):
 ox=min(x for x,y in S);oy=min(y for x,y in S);S={(x-ox,y-oy) for x,y in S};v=(v[0]-ox,v[1]-oy);cases=constraints(S,v,K,d);zs=table(d,80);qs=qbounds();res=[]
 for lower,rnd,qq,zz in [(True,ROUND_FLOOR,qs[0],zs[1][d][d]),(False,ROUND_CEILING,qs[1],zs[0][d][d])]:
  with localcontext() as c:
   c.prec=80;c.rounding=rnd;q=dec(qq,80,rnd);powers=[q**i for i in range(d+1)]
   @lru_cache(None)
   def part(allowed):
    prev=[Decimal(1)]*(d+1)
    for row in reversed(allowed):
     row=set(row);acc=Decimal(0);new=[]
     for b in range(d+1):
      if b in row:acc+=powers[b]*prev[b]
      new.append(acc)
     prev=new
    return prev[d]
   val=Decimal(0)
   for case in cases:
    p=Decimal(1)
    for allowed in case:p*=part(allowed)
    val+=p
   with localcontext() as cc:cc.rounding=ROUND_CEILING if lower else ROUND_FLOOR;den=zz**4*n
   res.append(str(val/den))
 return res,len(cases)
def merge_interval(f,d,n):
 zs=table(d,80);qs=qbounds();res=[]
 for lower,rnd,qq,zt,zz in [(True,ROUND_FLOOR,qs[0],zs[0],zs[1][d][d]),(False,ROUND_CEILING,qs[1],zs[1],zs[0][d][d])]:
  with localcontext() as c:
   c.prec=80;c.rounding=rnd;q=dec(qq,80,rnd);val=evalformula(f,d,q,zt)
   with localcontext() as cc:cc.rounding=ROUND_CEILING if lower else ROUND_FLOOR;den=zz**4*n
   res.append(str(val/den))
 return res
start=time.perf_counter();d=132;K=265;M=600;n=1600**2;C=[tuple(c) for c in json.loads(Path(__file__).with_name('channel_sampler.json').read_text())['corners']]
Fshape=shape(C,K,K,d);y=100;row=sorted(x for x,z in Fshape if z==y);prev=min(x for x,z in Fshape if z==y-1);seed=max(row[0],prev);last=min(seed+10,row[-1]-1);S={(x,z) for x,z in Fshape if z<y}|{(x,y) for x in range(row[0],last+1)};v=(last+1,y)
pref,cases=prefix_interval(S,v,K,d,n);tp=time.perf_counter()-start
# A late merge state overlapping final core central growth: only outer top-right row holes.
r=20;corners=[(0,)*d for _ in range(4)];corners[3]=(r,)+(0,)*(d-1);T=shape(corners,M,M,d);vv=(M-r,M-1);f=merge_formula(T,vv,M,d);mi=merge_interval(f,d,n)
cp=current(T,vv,d,K,M,Symbol());ci=evaluate(cp,d,n)
# Local normalized cross-current product, without native resistance factor.
with localcontext() as c:c.prec=60;cross=str(2*Decimal(mi[0])*Decimal(ci[0]))
out={'R':200,'d':d,'q':'exp(-1/25)','prefix_state_sites':len(S),'prefix_hidden_anchor_cases':cases,'prefix_current_interval':pref,'prefix_seconds':tp,'merge_state_sites':len(T),'merge_formula':f,'merge_current_interval':mi,'same_edge_core_current_interval':ci,'twice_core_merge_current_product_lower':cross,'total_seconds':time.perf_counter()-start,'scope':'Original prefix and explicit ordered-merge inverse; real R200 core/merge shared edge acquired. Product needs native resistance for energy cross term.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
