from core_occupancy import *
from channel_sampler import table,qbounds,dec
from decimal import Decimal,localcontext,ROUND_FLOOR,ROUND_CEILING
class Poly(dict):
 def __add__(self,b):
  if b==0:return self
  a=Poly(self)
  for k,v in b.items():a[k]=a.get(k,F(0))+v
  return a
 __radd__=__add__
 def __mul__(self,b):return Poly({k:v*b for k,v in self.items()})
 __rmul__=__mul__
 def __truediv__(self,b):return self* (1/b)
class Symbol:
 def __pow__(self,k):return Poly({k:F(1)})
def evaluate(poly,d,n):
 z=table(d,80);ql,qh=qbounds();res=[]
 for lower,rnd,qq,zz in [(True,ROUND_FLOOR,ql,z[1][d][d]),(False,ROUND_CEILING,qh,z[0][d][d])]:
  with localcontext() as c:
   c.prec=80;c.rounding=rnd;q=dec(qq,80,rnd);total=Decimal(0)
   for k,v in poly.items():total+=dec(v,80,rnd)*q**k
   # denominator opposite rounding required
   with localcontext() as cc:
    cc.rounding=ROUND_CEILING if lower else ROUND_FLOOR;den=zz**4*Decimal(n)
   res.append(str(total/den))
 return res
start=time.perf_counter();data=json.loads(Path(__file__).with_name('channel_sampler.json').read_text());C=[tuple(c) for c in data['corners']];d=132;a=300
bl,lo,tl,hi=C;Cp=(bl,tuple(max(0,x-1) for x in lo),tl,tuple(max(0,x-1) for x in hi));S=shape(Cp,a,a,d)
p=sum(x>0 for x in lo);t=sum(x>0 for x in hi);left=p+3;j=10;S|={(a,y) for y in range(left,left+j)};v=(a,left-1)
poly=current(S,v,d,2*d+1,600,Symbol());central=evaluate(poly,d,1600**2)
S0,v0,_=next(forward(C,a,a,d,F(1,2)));polyp=current(S0,v0,d,2*d+1,600,Symbol());positive=evaluate(polyp,d,1600**2)
out={'R':200,'d':d,'q':'exp(-1/25)','central_state_sites':len(S),'central_edge':v,'central_positive_polynomial_terms':len(poly),'central_current_interval':central,'positive_edge':v0,'positive_polynomial_terms':len(polyp),'positive_current_interval':positive,'seconds':time.perf_counter()-start,'scope':'Exact inverse core occupancy polynomial, interval evaluation; includes both macro orientations. Excludes prefix merge late reservoir currents.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
