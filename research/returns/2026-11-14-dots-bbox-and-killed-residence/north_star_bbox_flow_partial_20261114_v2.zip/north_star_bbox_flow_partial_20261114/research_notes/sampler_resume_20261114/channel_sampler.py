"""Exact lazy-bit sampler for four q-weighted Ferrers corners.
Exactness conditional on Python Decimal directed arithmetic contract.
Does not sample a Gibbs configuration or solve transition time.
"""
from fractions import Fraction as F
from decimal import Decimal, localcontext, ROUND_FLOOR, ROUND_CEILING
from secrets import randbits
import json,time
from pathlib import Path

def qbounds(t=F(1,25),terms=80):
 # e^-t alternating series, decreasing terms, even partial upper.
 s=F(1);term=F(1)
 for k in range(1,terms+1):term*= -t/k;s+=term
 nxt=term*(-t)/(terms+1)
 return (s+nxt,s) if terms%2==0 else (s,s+nxt)
def dec(x,prec,rounding):
 with localcontext() as c:c.prec=prec;c.rounding=rounding;return Decimal(x.numerator)/Decimal(x.denominator)
def table(d,prec):
 lo,hi=qbounds(terms=max(80,prec));qs=[dec(lo,prec,ROUND_FLOOR),dec(hi,prec,ROUND_CEILING)];out=[]
 for q,rnd in zip(qs,(ROUND_FLOOR,ROUND_CEILING)):
  with localcontext() as c:
   c.prec=prec;c.rounding=rnd
   z=[[Decimal(1)]*(d+1) for _ in range(d+1)];powers=[Decimal(1)]
   for i in range(1,d+1):powers.append(powers[-1]*q)
   for i in range(1,d+1):
    for j in range(1,d+1):z[i][j]=z[i-1][j]+powers[i]*z[i][j-1]
   out.append(z)
 return out
class Sampler:
 def __init__(self,d):self.d=d;self.prec=80;self.z=table(d,self.prec);self.bits=0;self.refinements=0
 def coin(self,i,j):
  u=0;bits=0
  while True:
   l,h=self.z
   with localcontext() as c:c.prec=self.prec;c.rounding=ROUND_FLOOR;pl=l[i-1][j]/h[i][j]
   with localcontext() as c:c.prec=self.prec;c.rounding=ROUND_CEILING;ph=h[i-1][j]/l[i][j]
   u=(u<<64)+randbits(64);bits+=64;self.bits+=64
   if F(u+1,1<<bits)<=F(pl):return True
   if F(u,1<<bits)>=F(ph):return False
   # Refine arithmetic before its bracket could mask random-bit resolution.
   if bits>2*self.prec:
    self.prec*=2;self.z=table(self.d,self.prec);self.refinements+=1
 def draw(self):
  lam=[0]*self.d;i=j=self.d
  while i and j:
   if self.coin(i,j):i-=1
   else:
    for k in range(i):lam[k]+=1
    j-=1
  assert all(lam[k]>=lam[k+1] for k in range(self.d-1))
  return lam
if __name__=='__main__':
 start=time.perf_counter();s=Sampler(132);setup=time.perf_counter()-start
 corners=[s.draw() for _ in range(4)];elapsed=time.perf_counter()-start
 r={'d':132,'q':'exp(-1/25)','corners':corners,'areas':[sum(x) for x in corners],'bits':s.bits,'decimal_precision':s.prec,'refinements':s.refinements,'setup_seconds':setup,'total_seconds':elapsed,'Z_interval':[str(s.z[0][132][132]),str(s.z[1][132][132])],'scope':'Exact lazy-bit weighted channel-law draw under directed arithmetic contract, not physical Gibbs/energy-edge law.'}
 Path(__file__).with_suffix('.json').write_text(json.dumps(r,indent=2));print(json.dumps({k:v for k,v in r.items() if k!='corners'},indent=2))
