import numpy as np, json, math
from scipy.linalg import solve
from pathlib import Path
L=3;n=9;N=1<<n;kappa=1.
ne=[[(r*L+(c+1)%L),(((r+1)%L)*L+c), (r*L+(c-1)%L),(((r-1)%L)*L+c)] for r in range(L) for c in range(L)]
phys=sorted({tuple(sorted((i,j))) for i in range(n) for j in ne[i]})
aug=set(phys)
for r in range(L):
 for c in range(L):aug.add(tuple(sorted((r*L+c,((r+1)%L)*L+(c+1)%L))))
k=np.array([x.bit_count() for x in range(N)])
P=np.array([sum(((x>>i)&1)!=((x>>j)&1) for i,j in phys) for x in range(N)])
mu=2.**(-(2*P-k)); A=np.array([not any((x>>i)&1 and (x>>j)&1 for i,j in aug) for x in range(N)])
I=np.where(k<5)[0]; ix={int(x):i for i,x in enumerate(I)}; M=np.zeros((len(I),len(I)));b=np.zeros(len(I))
for x in I:
 i=ix[int(x)]
 for v in range(n):
  y=x^(1<<v);r=1/(1+2.**(int(2*P[y]-k[y]-2*P[x]+k[x])))
  M[i,i]+=r
  if y in ix:M[i,ix[int(y)]]-=r
 if A[x]:M[i,i]+=kappa;b[i]+=kappa
h=np.zeros(N);h[I]=solve(M,b); C=sum(kappa*mu[x]*(1-h[x]) for x in I if A[x])
ed=[]
for x in range(N):
 for v in range(n):
  y=x^(1<<v)
  if k[x]==2 and k[y]==3:
   r=1/(1+2.**(int(2*P[y]-k[y]-2*P[x]+k[x])))
   ed.append((mu[x]*r,h[x]-h[y],('native',sum((x>>j)&1 for j in ne[v]))))
for x in range(N):
 if A[x] and k[x]>=3:ed.append((kappa*mu[x],1-h[x],('source',int(k[x]))))
w=np.array([e[0] for e in ed]);p=np.array([e[1] for e in ed]);groups=[e[2] for e in ed]
assert min(p)>-1e-12
p=np.maximum(0,p);cross=w@p;assert abs(cross/C-1)<1e-10
W=sum(w)
def assess(q):
 return float(sum(w*w*p/q)/(C*C)-1)
q0=w/W;qo=w*np.sqrt(p);qo/=sum(qo)
strata={g:np.array([i for i,a in enumerate(groups) if a==g]) for g in set(groups)}
gmean=np.zeros(len(w))
for g,ids in strata.items():gmean[ids]=np.dot(w[ids],p[ids])/sum(w[ids])
qg=w*np.sqrt(gmean);qg/=sum(qg)
# Explicit pilot uses simulator-free Bernoulli oracle solely diagnostic, NOT claimed physical runtime.
rng=np.random.default_rng(20261114);pilot=[]
for budget in (100,1000,10000):
 vals=[]
 for rep in range(100):
  ids=rng.choice(len(w),size=budget,p=q0);hits=rng.random(budget)<p[ids]
  est=np.zeros(len(w))
  for g,ii in strata.items():
   mask=np.isin(ids,ii);est[ii]=(1+sum(hits[mask]))/(2+sum(mask))
  qp=w*np.sqrt(est);qp/=sum(qp);qp=.1*q0+.9*qp
  vals.append(assess(qp))
 pilot.append({'pilot_draws':budget,'median_relative_variance':float(np.median(vals)),'p95':float(np.quantile(vals,.95))})
r={'scope':'3x3 rational-parameter floating diagnostic, full C1 source, not original N1722','edges':len(ed),'C':float(C),'W':float(W),'W_over_C':float(W/C),'cross_identity_relative_error':float(cross/C-1),'energy_proposal_relative_variance':assess(q0),'oracle_optimal_relative_variance':assess(qo),'exact_stratum_mean_relative_variance':assess(qg),'pilot':pilot,'caveat':'Bernoulli pilot is oracle-generated from solved h; full-state solve and downstream decision costs uncharged. No practical speedup claim.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
