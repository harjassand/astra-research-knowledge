from core_occupancy import *
import itertools,random
start=time.perf_counter();d=1;K=3;M=5;q=F(1,2);edges=defaultdict(F)
for C in itertools.product(parts(d),repeat=4):
 for a in range(K,M):
  for axis in (0,1):
   for S,v,z in forward(C,a,a+axis,d,q):
    if axis:S=frozenset((y,x) for x,y in S);v=(v[1],v[0])
    edges[S,v]+=z
states=list({S for S,v in edges});count=0
for S in states:
 for v in itertools.product(range(6),repeat=2):
  if v in S:continue
  assert current(S,v,d,K,M,q)==edges.get((S,v),0);count+=1
rng=random.Random(42);tests=0;L=16
for S,v in rng.sample(list(edges),100):
 for ox,oy in [(15,14),(9,13),(0,0)]:
  T=frozenset(((x+ox)%L,(y+oy)%L) for x,y in S);vv=((v[0]+ox)%L,(v[1]+oy)%L)
  SS,V,anchor=unwrap(T,vv,L);assert SS==S and V==v and anchor==(ox,oy)
  assert current(SS,V,d,K,M,q)==edges[S,v];tests+=1
out={'finite_d':d,'all_states':len(states),'all_absent_site_edge_tests':count,'wrapped_translation_tests':tests,'all_exact_checks_passed':True,'seconds':time.perf_counter()-start}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(out)
