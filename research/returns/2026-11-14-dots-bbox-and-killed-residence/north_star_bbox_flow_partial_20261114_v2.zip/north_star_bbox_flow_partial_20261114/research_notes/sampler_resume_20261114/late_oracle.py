from fractions import Fraction as F
from pathlib import Path
import json,time

def stage(k,M,L):
 w=h=M
 assert M*M<=k<L*L//2
 while True:
  axis=0 if w<=h and w<L//2 else 1;length=h if axis==0 else w
  if k<w*h+length:return w,h,axis,k-w*h
  if axis==0:w+=1
  else:h+=1

def occupancy(S,v,M,L):
 k=len(S)
 if not M*M<=k<L*L//2:return F(0)
 w,h,axis,j=stage(k,M,L);canonical=(w,j) if axis==0 else (j,h)
 ox=(v[0]-canonical[0])%L;oy=(v[1]-canonical[1])%L
 for x,y in S:
  x=(x-ox)%L;y=(y-oy)%L
  if not ((x<w and y<h) or (axis==0 and x==w and y<j) or(axis==1 and y==h and x<j)):return F(0)
 return F(1,L*L)
if __name__=='__main__':
 start=time.perf_counter();L=1600;M=600;k=M*M+100;w,h,axis,j=stage(k,M,L);S={(x,y) for x in range(w) for y in range(h)}|{(w,y) for y in range(j)};v=(w,j);ox,oy=1550,1590
 S={((x+ox)%L,(y+oy)%L) for x,y in S};v=((v[0]+ox)%L,(v[1]+oy)%L)
 z=occupancy(S,v,M,L);assert z==F(1,L*L)
 # State-preserving but wrong next flip must not acquire the flow.
 assert occupancy(S,((v[0]+1)%L,v[1]),M,L)==0
 out={'R':200,'state_sites':len(S),'wrapped_translation':[ox,oy],'late_current':str(z),'wrong_flip_current':0,'seconds':time.perf_counter()-start,'reservoir_current':1,'scope':'Exact coalesced late-stage current, not whole-flow current below M².'}
 Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(out)
