import runpy, numpy as np, math,json,time
from pathlib import Path
base=Path(__file__).parent
z=runpy.run_path(str(base/'downstream.py'));globals().update({a:z[a] for a in ['n','N','k','P','mu','A','h','C','W','kappa']})
rng=np.random.default_rng(20261114);target=5
rates=np.zeros((N,n));kill=A.astype(float)*kappa
for x in range(N):
 for v in range(n):
  y=x^(1<<v);rates[x,v]=1/(1+2.**(int(2*P[y]-k[y]-2*P[x]+k[x])))
# Source reservoir -> empty -> monotone random-permutation path -> majority.
resistance_exact=1/(kappa*mu[0]);path_bound=1/(kappa*mu[0]);layer_bounds=[]
for j in range(target):
 f=1/(math.comb(n,j)*(n-j));layer=0;mx=0
 for x in range(N):
  if k[x]!=j:continue
  for v in range(n):
   if x>>v&1:continue
   val=f/(mu[x]*rates[x,v]);layer+=f*val;mx=max(mx,val)
 resistance_exact+=layer;path_bound+=mx;layer_bounds.append(mx)
rvals=[]
for rep in range(10000):
 x=0;r=1/(kappa*mu[0])
 for j,v in enumerate(rng.permutation(n)[:target]):
  r+=1/(math.comb(n,j)*(n-j)*mu[x]*rates[x,v]);x|=1<<v
 rvals.append(r)
# Full cut includes source edges from reservoir into complement.
edges=[]
for x in range(N):
 if k[x]==2:
  for v in range(n):
   if not x>>v&1:edges.append((x,x|(1<<v),mu[x]*rates[x,v],1/(math.comb(n,2)*(n-2))))
 if A[x] and k[x]>=3:edges.append((-1,x,kappa*mu[x],0.))
w=np.array([e[2] for e in edges]);qe=w/w.sum();qf=np.array([e[3] for e in edges]);assert abs(qf.sum()-1)<1e-12
q=.5*qe+.5*qf
# Exact finite-state reference cost second moment. No monotonic coupling assumed.
px=np.array([1 if x<0 else h[x] for x,y,_,_ in edges]);py=np.array([h[y] for x,y,_,_ in edges]);d2=px+py-2*px*py
rv=float(np.sum(w*w*d2/q)/C**2-1)
def absorb(x):
 if x<0:return 1,0,0.
 jumps=0;t=0.
 while k[x]<target:
  total=rates[x].sum()+kill[x];t+=rng.exponential(1/total);u=rng.random()*total
  if u>=rates[x].sum():return 1,jumps,t
  v=np.searchsorted(np.cumsum(rates[x]),u);x^=1<<int(v);jumps+=1
 return 0,jumps,t
vals=[];jumps=0;clock=0.;start=time.perf_counter()
for rep in range(2000):
 e=int(rng.choice(len(edges),p=q));x,y,ww,_=edges[e];a,ja,ta=absorb(x);b,jb,tb=absorb(y)
 vals.append(ww*(a-b)/q[e]);jumps+=ja+jb;clock+=ta+tb
out={'scope':'3x3 rational-parameter full augmented C1 soft-source model, not R200','C_reference':float(C),'flow_resistance_exact':resistance_exact,'flow_capacity_lower_bound':1/resistance_exact,'capacity_to_flow_lower_bound_ratio':float(C*resistance_exact),'path_resistance_deterministic_bound':path_bound,'flow_mc_draws':len(rvals),'flow_mc_mean':float(np.mean(rvals)),'flow_mc_se':float(np.std(rvals,ddof=1)/np.sqrt(len(rvals))),'cut_proposal':'half energy, half monotone-flow crossing; includes reservoir crossing edges','signed_actual_path_draws':len(vals),'capacity_mc_mean':float(np.mean(vals)),'capacity_mc_se':float(np.std(vals,ddof=1)/np.sqrt(len(vals))),'exact_relative_variance_signed':rv,'actual_native_jumps':jumps,'actual_simulated_physical_time':clock,'simulation_wall_seconds':time.perf_counter()-start,'limitation':'No monotonicity assumption or oracle Bernoulli. Endpoint decisions are actual killed chains. Finite sample mean is not a rigorous capacity bound; exact enumerated flow resistance gives one. No scaling guarantee.'}
(base/'flow_capacity_bridge.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
