import json,time,secrets,hashlib
from pathlib import Path
from collections import deque
R=200;L=8*R;n=L*L;d=132;K=2*d+1;M=3*R
C=json.loads(Path(__file__).with_name('channel_sampler.json').read_text())['corners'];A=sum(map(sum,C));bl,br,tl,tr=C
S=bytearray(n);count=P=0;NN={};phasecounts={};maxenergy={};ox=secrets.randbelow(L);oy=secrets.randbelow(L);digest=hashlib.sha256();start=time.perf_counter()
def idx(x,y):return ((y+oy)%L)*L+(x+ox)%L
def neigh(x,y):return S[idx(x-1,y)]+S[idx(x+1,y)]+S[idx(x,y-1)]+S[idx(x,y+1)]
def add(x,y,phase):
 global count,P
 u=idx(x,y);assert not S[u];z=neigh(x,y)
 if phase=='core':assert z in (1,2)
 if phase=='merge':assert z>=2
 S[u]=1;count+=1;P+=4-2*z;assert count<=n//2
 NN[(phase,z)]=NN.get((phase,z),0)+1;phasecounts[phase]=phasecounts.get(phase,0)+1;maxenergy[phase]=max(maxenergy.get(phase,-10**9),200*P-count)
 digest.update(u.to_bytes(4,'little'))
def interval(y,w,h):
 left=bl[y] if y<d else tl[h-1-y] if y>=h-d else 0
 right=br[y] if y<d else tr[h-1-y] if y>=h-d else 0
 return left,w-right-1
def check(w,h):
 assert count==w*h-A
 for y in range(h):
  lo,hi=interval(y,w,h)
  assert all(S[idx(x,y)]==(lo<=x<=hi) for x in range(w))
 assert P==2*(w+h)
prev=None;bx=by=0
for y in range(K):
 lo,hi=interval(y,K,K);s=lo if prev is None else max(lo,prev[0]);assert s<=hi and(prev is None or s<=prev[1])
 for x in [s]+list(range(s-1,lo-1,-1))+list(range(s+1,hi+1)):
  add(x,y,'prefix');bx=max(bx,x+1);by=max(by,y+1)
  assert 200*P-count <= 400*(bx+by)-bx*by+A+K
 prev=(lo,hi)
check(K,K);w=h=K;macros=0
while w<M or h<M:
 axis=0 if w==h else 1;length=h if axis==0 else w
 lo=br if axis==0 else [sum(a>i for a in tl) for i in range(d)]
 hi=tr if axis==0 else [sum(a>i for a in tr) for i in range(d)]
 order=[length-1-z for z in range(d-1,-1,-1) if hi[z]>0]+[z for z in range(d-1,-1,-1) if lo[z]>0]
 order +=[z for z in range(length) if (lo[z] if z<d else hi[length-1-z] if z>=length-d else 0)==0]
 assert len(order)==length and len(set(order))==length
 for z in order:
  cut=lo[z] if z<d else hi[length-1-z] if z>=length-d else 0
  add(w-cut,z,'core') if axis==0 else add(z,h-cut,'core')
 if axis==0:w+=1
 else:h+=1
 assert count==w*h-A and P==2*(w+h);macros+=1
 if macros%100==0:check(w,h)
check(M,M)
holes={(x,y) for y in range(M) for x in range(M) if not S[idx(x,y)]};assert len(holes)==A
q=deque([z for z in holes if neigh(*z)>=2])
while q:
 x,y=q.popleft()
 if (x,y) not in holes:continue
 if neigh(x,y)<2:continue
 holes.remove((x,y));add(x,y,'merge')
 for z in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)):
  if z in holes:q.append(z)
assert not holes
w=h=M
while (w,h)!=(L//2,L):
 axis=0 if w<=h and w<L//2 else 1
 if axis==0:
  for y in range(h):add(w,y,'late')
  w+=1
 else:
  for x in range(w):add(x,h,'late')
  h+=1
assert count==n//2 and P==2*L
r={'R':R,'L':L,'d':d,'removed_area':A,'translation':[ox,oy],'native_additions':count,'phase_counts':phasecounts,'neighbor_counts':{str(k):v for k,v in NN.items()},'maximum_energy_times25':maxenergy,'path_digest_sha256':digest.hexdigest(),'seconds':time.perf_counter()-start,'all_additions_legal':True,'all_core_macro_counts_and_perimeters_checked':True,'sampled_full_endpoints_checked':True,'target_first_hit_final':True,'scope':'One exact-weight channel partition draw followed by deterministic native monotone path; not full-energy/capacity sampling.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
