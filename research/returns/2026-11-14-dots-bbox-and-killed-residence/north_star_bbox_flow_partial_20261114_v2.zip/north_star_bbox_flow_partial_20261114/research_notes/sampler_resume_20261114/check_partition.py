from fractions import Fraction as F
import json
from pathlib import Path
from channel_sampler import qbounds,table
out=[]
for d in range(1,6):
 def parts(i,cap):
  if i==0:yield ();return
  for a in range(cap+1):
   for p in parts(i-1,a):yield (a,)+p
 ps=list(parts(d,d));q=F(1,2)
 z=[[F(1)]*(d+1) for _ in range(d+1)]
 for i in range(1,d+1):
  for j in range(1,d+1):z[i][j]=z[i-1][j]+q**i*z[i][j-1]
 assert z[d][d]==sum((q**sum(p) for p in ps),F(0))
 # Positive recurrence decomposition covers every partition uniquely.
 assert all((p[-1]==0) != (min(p)>=1) for p in ps)
 out.append({'d':d,'partitions':len(ps),'exact_normalizer_agrees':True})
a,b=qbounds();assert a<b
lo,hi=table(5,80)
# A distinct120-digit recurrence has intervals nested within80-digit ones.
l2,h2=table(5,120)
for i in range(6):
 for j in range(6):assert lo[i][j]<=l2[i][j]<=h2[i][j]<=hi[i][j]
r={'enumeration':out,'q_interval_width':str(b-a),'nested_precision_check':True}
Path(__file__).with_suffix('.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
