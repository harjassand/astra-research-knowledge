from fractions import Fraction as F
from pathlib import Path
import json
out=[]
for m in range(1,65):
 p=[F(1,m)]*m
 for j in range(1,m):
  z=[F(0)]*(m-j)
  for i,v in enumerate(p):
   if i: z[i-1]+=v*F(i,m-j)
   if i<m-j:z[i]+=v*F(m-j-i,m-j)
  assert z==[F(1,m-j)]*(m-j)
  p=z
 out.append({'m':m,'all_length_marginals_exactly_uniform':True})
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
print('Exact rational interval marginals passed for every m=1..64.')
