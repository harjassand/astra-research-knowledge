import math
R=200;d=131;t=.04;q=math.exp(-t);K=2*d+1;M=600;n=1600**2
# stable scaled Gaussian recurrence normalizers
Ztab=[[1.]*(d+1) for _ in range(d+1)]
for a in range(1,d+1):
 for b in range(1,d+1): Ztab[a][b]=Ztab[a-1][b]+q**a*Ztab[a][b-1]
Z=Ztab[d][d]
G=[1.]+[q**r*Ztab[r][d-2] for r in range(1,d+1)]
S=[sum(q**p for p in range(r,d+1)) for r in range(d+1)]
U=[q**p*sum(G[r]*S[r] for r in range(p+1)) for p in range(d+1)]
T=sum(G[r]*S[r]**2 for r in range(d+1))
V=[sum(U[p]*U[s-p] for p in range(max(0,s-d),min(d,s)+1)) for s in range(2*d+1)]
assert abs(sum(U)/T-1)<1e-12
TARGET=6251
corepos=corecentral=0
c=(1+q)/(1-q)
for a in range(K,M):
 for w,h in [(a,a),(a+1,a)]:
  side=h if w==h else w
  E=16*(w+h)-t*w*h
  corepos+=math.exp(E-TARGET-4*math.log(Z))*c
  F=sum(V[s]*((1+math.exp(16-t))/(side-s)+math.exp(16)*(1+q)*sum(q**j*(2*(side-s-j)+1)/(3*(side-s-j)*(side-s-j+1)) for j in range(1,side-s))) for s in range(2*d+1))
  corecentral+=math.exp(E-TARGET-6*math.log(Z))*F
corepos*=2*(d+1)**2/n
corecentral*=2/n
N=math.comb(2*d,d);lnNZ=math.log(N)-math.log(Z)
pre=2*K*K*math.exp(32*K-t*K*K+t*K-TARGET+4*lnNZ)
merge=8*d*d*math.exp(32*M-t*M*M-TARGET+4*lnNZ)
late=2*n*math.exp(32*M-t*M*M+16-TARGET)
print(dict(logZ=math.log(Z),D=T/Z**2,pos=corepos,central=corecentral,pre=pre,merge=merge,late=late,normalized=(1.0001*(corepos+corecentral)+10001*(pre+merge+late))*math.exp(1e-6)))
