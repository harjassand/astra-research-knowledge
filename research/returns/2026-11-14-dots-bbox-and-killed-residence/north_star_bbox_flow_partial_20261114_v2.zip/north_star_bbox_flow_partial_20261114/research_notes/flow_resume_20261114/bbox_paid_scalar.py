from decimal import Decimal as D, localcontext, ROUND_CEILING, ROUND_FLOOR,getcontext
from fractions import Fraction as F
from pathlib import Path
from math import factorial
import json
getcontext().prec=100;getcontext().rounding=ROUND_CEILING
root=next(Path('flow_resume_recovery/unpacked').glob('*/dependencies/global_cut_corrected/01_global_cut/cert_r200'))
def hexfrac(h):
 a,e=h.split('p');a=a.removeprefix('0x');u,v=(a.split('.')+[''])[:2];return F(int(u+v,16),16**len(v))*F(2)**int(e)
def dd(x,up=True):
 x=F(x)
 with localcontext() as c:
  c.rounding=ROUND_CEILING if up else ROUND_FLOOR
  return D(x.numerator)/D(x.denominator)
def hi(x):return dd(x).ln().next_plus()
def lo(x):return dd(x,False).ln().next_minus()
def lse(xs):
 m=max(xs);return m+sum((v-m).exp().next_plus() for v in xs).ln().next_plus()
old=json.load(open(root/'certificate_marked_s79_40.json'));terms=[]
for line in (root/'marked_convolution_s79_40.output').read_text().splitlines():
 j,h=line.split();j=int(j);v=D(j*273-4*1576)+hi(hexfrac(h))+hi(3)-lo(factorial(j));terms.append(v)
new=[terms[0]-D('15.96')]+terms[1:]
n=2560000;phi=F(1,50);u=F(6*n)*F(3,40)**10/(1-F(3,40));tail=hi(n)+D(old['log_tuple_tail_upper'])
target=hi(n)-dd(phi*n*(F(1,2)-F(1,500000)),False)+dd(phi)
source=-dd(phi*n*(F(1,2)-F(1,500000)),False)
upper=lse([*new,tail,target,source])-lo(1-u)
out=dict(status='conditional geometric transfer, directed scalar using archived certified marked convolution',H=790,terms_original=list(map(str,terms)),log_old_recomputed=str(lse(terms)),log_new_structural=str(lse(new)),log_normalized_full_upper=str(upper),ratio_with_lower_exp_minus6251=str(upper+6251),gain=str(D(old['log_capacity_over_ZA_upper'])-upper))
Path('research_notes/flow_resume_20261114/bbox_paid_scalar.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
