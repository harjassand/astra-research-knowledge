from fractions import Fraction as F
from collections import defaultdict
import json
q=F(2,3)
def parts(d,lim=None,k=None):
 if k is None:k=d
 if lim is None:lim=d
 if not k:yield ();return
 for a in range(lim+1):
  for b in parts(d,a,k-1):yield(a,)+b
def qb(a,b):
 dp=[F(1)]*(b+1)
 for i in range(1,a+1):
  for j in range(1,b+1):dp[j]=dp[j-1]+q**j*dp[j]
 return dp[b]
rows=[]
for d in range(1,7):
 fibers=defaultdict(list)
 for p in parts(d):fibers[tuple(max(x-1,0) for x in p)].append(p)
 z=sum(q**sum(p) for ps in fibers.values() for p in ps)
 assert z==qb(d,d)
 G=[F(1)]+[q**r*qb(r,d-2) if d>=2 else F(0) for r in range(1,d+1)]
 direct=[F(0)]*(d+1)
 U=[F(0)]*(d+1)
 for mu,ps in fibers.items():
  r=sum(x>0 for x in mu);direct[r]+=q**sum(mu)
  S=sum(q**p for p in range(r,d+1))
  assert sorted(sum(x>0 for x in p) for p in ps)==list(range(r,d+1))
  for p in ps:
   k=sum(x>0 for x in p);assert sum(p)==sum(mu)+k
   U[k]+=q**sum(mu)*q**k*S
 assert direct==G
 for p in range(d+1):assert U[p]==q**p*sum(G[r]*sum(q**k for k in range(r,d+1)) for r in range(p+1))
 rows.append(dict(d=d,partitions=sum(map(len,fibers.values())),fibers=len(fibers),exact_checks=True))
open('research_notes/flow_resume_20261114/check_pushforward_moments.json','w').write(json.dumps(rows,indent=2));print(rows)
