from fractions import Fraction as F
from math import factorial
from decimal import Decimal as D
from pathlib import Path
import json
n=2560000;q=F(3,40);u=F(6*n)*q**32/(1-q)
assert sum(F(161,40)**k/factorial(k) for k in range(40))>F(160,3)
delta=3**20*u;assert delta<F(1,10**18)
x=json.load(open(Path(__file__).parent/'optimized_bbox/cert_r200/certificate_marked_s159_80.json'))
assert D(x['log_capacity_over_ZA_upper']) < -6231
assert sum(F(16)**k/factorial(k) for k in range(100))>n
assert D(x['log_tuple_tail_upper'])+16+1+6251 < -470
assert 2**470>10**18
# original rho=1/500000,phi=.02; normalization1/(1-u4)<2
u4=F(6*n)*q**10/(1-q);assert u4<F(1,2)
target_exponent=-F(1,50)*n*(F(1,2)-F(1,500000))+F(1,50)
assert target_exponent+16+2+6251 < -19000
out=dict(auxiliary_r=16,aux_ratio_exact_upper=str(delta),aux_ratio_less_than='1e-18',tail_ratio_less_than='exp(-470)<1e-18',target_and_source_ratio_less_than='exp(-19000)<1e-18',total_omitted_energy_over_capacity_less_than='3e-18',scope='Exact rational elementary scalar checks plus inherited directed contour-tail certificate; conditional on bbox geometry and recovered capacity lower. kappa<=1 used only for source upper.')
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(out)
