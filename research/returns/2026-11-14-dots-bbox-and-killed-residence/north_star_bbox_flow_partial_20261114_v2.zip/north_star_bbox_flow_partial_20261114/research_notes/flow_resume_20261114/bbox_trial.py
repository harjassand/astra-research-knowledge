import math,json,time
import numpy as np
start=time.time();L=4;n=L*L;N=1<<n
nb=[[((i//L+dy)%L)*L+(i%L+dx)%L for dy,dx in [(1,0),(-1,0),(0,1),(0,-1)]] for i in range(n)]
def span(coords):
    a=sorted(set(coords)); gaps=[(a[(j+1)%len(a)]-a[j])%L for j in range(len(a))]
    if len(a)==1:return 1
    return L-max(gaps)+1
def geometry(s):
    seen=set();g=0;wind=False;comps=0
    for seed in range(n):
        if not(s>>seed&1) or seed in seen:continue
        comps+=1; todo=[seed];lift={seed:(0,0)};seen.add(seed);nodes=[]
        while todo:
            v=todo.pop();nodes.append(v);x,y=lift[v]
            for u,(dx,dy) in zip(nb[v],[(0,1),(0,-1),(1,0),(-1,0)]):
                if not(s>>u&1):continue
                xy=(x+dx,y+dy)
                if u in lift:
                    if lift[u]!=xy:wind=True
                else:lift[u]=xy;seen.add(u);todo.append(u)
        g=max(g,span([v%L for v in nodes])+span([v//L for v in nodes]))
    return g,wind,comps
A=np.array([s.bit_count() for s in range(N)])
P=np.array([sum(((s>>i)^(s>>j))&1 for i in range(n) for j in nb[i][:1]+nb[i][2:3]) for s in range(N)])
G=np.zeros(N,int);W=np.zeros(N,bool);C=np.zeros(N,int)
for s in range(N):G[s],W[s],C[s]=geometry(s)
# Original target uses >= half, retain it exactly for toy.
B=A>=n//2
edges=[]
for i in range(n):
    x=np.arange(N);x=x[(x&(1<<i))==0];edges.append((x,x|(1<<i)))
def lse(v):
    if not len(v):return None
    v=np.asarray(v);m=float(np.max(v));return m+math.log(float(np.exp(v-m).sum()))
rows=[]
for theta,phi in [(0.4,0.1),(1.,0.3),(4.,2.)]:
 E=2*theta*P-2*phi*A
 for h in range(3,9):
    geom=(G>=h)|W;event=geom|B
    logs=[];cat={k:[] for k in ['target_override','winding_involved','merge_involved']}
    for x,y in edges:
        cross=event[x]!=event[y];xx=x[cross];yy=y[cross]
        lc=-np.logaddexp(E[xx],E[yy]);logs.extend(lc)
        cat['target_override'].extend(lc[(~geom[xx])&(~geom[yy])])
        cat['winding_involved'].extend(lc[W[xx]|W[yy]])
        cat['merge_involved'].extend(lc[(C[xx]-C[yy])>=1])
    rows.append(dict(theta=theta,phi=phi,h=h,logcut=lse(logs),edges=len(logs),category_logcut={k:lse(v) for k,v in cat.items()},target_override_states=int(np.sum(B&~geom))))
 area=[]
 for x,y in edges:
    use=B[x]!=B[y];area.extend(-np.logaddexp(E[x[use]],E[y[use]]))
 rows[-1]['area_logcut']=lse(area)
# explicit majority counterexample against large-bbox claim
bad=np.where(B&(G<6)&~W)[0]
out=dict(L=L,n=n,target='area>=8',source='all-minus only; not original thermal core',states=N,native_undirected_edges=n*N//2,runtime=time.time()-start,rows=rows,counterexample=int(bad[0]) if len(bad) else None)
open('research_notes/flow_resume_20261114/bbox_trial.json','w').write(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve
opt=[]
for theta,phi in [(0.4,0.1),(1.,0.3),(4.,2.)]:
 E=2*theta*P-2*phi*A
 for typ in ['area','bbox','joint']:
    labels=[];lookup={}
    for s in range(N):
        if s==0:key=('source',)
        elif B[s]:key=('target',)
        elif typ=='area':key=(int(A[s]),)
        elif typ=='bbox':key=(int(G[s]),bool(W[s]),int(C[s]))
        else:key=(int(A[s]),int(G[s]),bool(W[s]),int(C[s]))
        if key not in lookup:lookup[key]=len(lookup)
        labels.append(lookup[key])
    labels=np.array(labels);v=len(lookup);ii=[];jj=[];vv=[]
    for x,y in edges:
        c=np.exp(-np.logaddexp(E[x],E[y]));a=labels[x];b=labels[y];use=a!=b;a=a[use];b=b[use];c=c[use]
        for aa,bb,cc in [(a,a,c),(b,b,c),(a,b,-c),(b,a,-c)]:ii.extend(aa);jj.extend(bb);vv.extend(cc)
    H=coo_matrix((vv,(ii,jj)),shape=(v,v)).tocsr();src=lookup[('source',)];tgt=lookup[('target',)];free=np.array([i for i in range(v) if i not in [src,tgt]])
    f=np.zeros(v);f[src]=1;f[free]=spsolve(H[free][:,free],-H[free,src].toarray().ravel());energy=0.
    for x,y in edges:energy+=float(np.sum(np.exp(-np.logaddexp(E[x],E[y]))*(f[labels[x]]-f[labels[y]])**2))
    opt.append(dict(theta=theta,phi=phi,features=typ,quotient_vertices=v,logenergy=math.log(energy),potential_min=float(f.min()),potential_max=float(f.max())))
out['optimized_trials']=opt;out['runtime_with_optimization']=time.time()-start
open('research_notes/flow_resume_20261114/bbox_trial.json','w').write(json.dumps(out,indent=2));print(json.dumps(opt,indent=2))
