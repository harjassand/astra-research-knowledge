import random,json,time
rng=random.Random(20261114);start=time.time();L=8;H=5
steps=[(1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,-1)]
def domains(mask):
 seen=set();out=[]
 for seed in range(L*L):
  if not(mask>>seed&1) or seed in seen:continue
  lifts={seed:(seed%L,seed//L)};seen.add(seed);q=[seed];bad=False
  while q:
   u=q.pop();x,y=lifts[u]
   for dx,dy in steps:
    v=((y+dy)%L)*L+(x+dx)%L
    if not(mask>>v&1):continue
    a=(x+dx,y+dy)
    if v in lifts:
     if lifts[v]!=a:bad=True
    else:lifts[v]=a;seen.add(v);q.append(v)
  if bad:return None
  cc=set(lifts.values());xs=[p[0] for p in cc];ys=[p[1] for p in cc];lo,hi,bot,top=min(xs),max(xs),min(ys),max(ys)
  if hi-lo+top-bot+2>H:return None
  # fill all finite holes of fixed triangulation's complement
  ext={(lo-1,bot-1)};q=list(ext)
  while q:
   x,y=q.pop()
   for dx,dy in steps:
    p=(x+dx,y+dy)
    if lo-1<=p[0]<=hi+1 and bot-1<=p[1]<=top+1 and p not in cc and p not in ext:ext.add(p);q.append(p)
  filled={(x,y) for x in range(lo,hi+1) for y in range(bot,top+1) if (x,y) not in ext}
  dm=sum(1<<((y%L)*L+x%L) for x,y in filled)
  out.append(dm)
 return out
valid=flips=holes=0
for _ in range(20000):
 mask=sum(1<<v for v in range(L*L) if rng.random()<.08)
 ds=domains(mask)
 if ds is None:continue
 valid+=1
 for d in ds:
  holes+=bool(d&~mask)
  assert domains(mask^d) is not None
  assert (mask^d)^d==mask
  flips+=1
# deliberate filled ring+interior patterns: H limits area; 3x3 ring H6 >H5 so increaseH7 (<L−? test no source threshold guarantee)
H=7
for inner in [0,1]:
 mask=sum(1<<(y*L+x) for y in range(2,5) for x in range(2,5) if x in [2,4] or y in [2,4] or inner)
 ds=domains(mask);assert ds is not None
 for d in ds:assert domains(mask^d) is not None;holes+=bool(d&~mask);flips+=1
out=dict(scope='deterministic random torus8x8, fixed diagonal, H5; complete holes filled via complement flood; two deliberate ring casesH7',trials=20000,accepted_cut_states=valid,whole_domain_flips=flips,holes_observed=holes,passed=True,runtime=time.time()-start)
open('research_notes/flow_resume_20261114/check_bbox_flip.json','w').write(json.dumps(out,indent=2));print(out)
