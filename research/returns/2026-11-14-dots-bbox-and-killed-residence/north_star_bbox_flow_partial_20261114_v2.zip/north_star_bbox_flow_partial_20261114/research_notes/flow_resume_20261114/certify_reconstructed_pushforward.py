"""Directed positive scalar reconstruction, conditional on documented flow geometry.
No transcendental floating primitive; coefficients are rational; all numerator
operations round upward and the partition denominator rounds downward.
"""
from old_scalar import exp_bounds,decfrac
from fractions import Fraction as F
from decimal import Decimal,localcontext,ROUND_CEILING,ROUND_FLOOR
import math,json,time

def certify(d=131,T=6251):
 start=time.perf_counter();R=200;n=1600**2;t=F(1,25);K=2*d+1;M=600
 ql,qu=exp_bounds(-t)
 with localcontext() as c:
  c.prec=80;c.rounding=ROUND_FLOOR
  low=[[Decimal(1)]*(d+1) for _ in range(d+1)];p=Decimal(1)
  for a in range(1,d+1):
   p*=ql
   for b in range(1,d+1):low[a][b]=low[a-1][b]+p*low[a][b-1]
  Zlo=low[d][d]
 with localcontext() as c:
  c.prec=80;c.rounding=ROUND_CEILING
  qp=[Decimal(1)]
  for i in range(M+1):qp.append(qp[-1]*qu)
  z=[[Decimal(1)]*(d+1) for _ in range(d+1)]
  for a in range(1,d+1):
   for b in range(1,d+1):z[a][b]=z[a-1][b]+qp[a]*z[a][b-1]
  G=[Decimal(1)]+[qp[r]*z[r][d-2] for r in range(1,d+1)]
  S=[sum(qp[r:d+1],Decimal(0)) for r in range(d+1)]
  U=[qp[p]*sum((G[r]*S[r] for r in range(p+1)),Decimal(0)) for p in range(d+1)]
  V=[sum((U[p]*U[s-p] for p in range(max(0,s-d),min(d,s)+1)),Decimal(0)) for s in range(2*d+1)]
  invZ=Decimal(1)/Zlo;iz4=invZ**4;iz6=invZ**6
  e16=exp_bounds(16)[1]
  # F(m) is exact homogeneous interval-flow resistance / exp(Estart).
  fm=[None]
  for m in range(1,M+1):
   birth=(1+e16*qu)/Decimal(m)
   growth=sum((qp[j]*decfrac(F(2*(m-j)+1,3*(m-j)*(m-j+1)),ROUND_CEILING) for j in range(1,m)),Decimal(0))
   fm.append(birth+e16*(1+qu)*growth)
  with localcontext() as cc:
   cc.rounding=ROUND_FLOOR;den=1-qu
  cpos=(1+qu)/den
  Bweighted=2*cpos*cpos
  B=min(Decimal(2*(d+1)**2),Bweighted)
  central=Decimal(0);positive=Decimal(0)
  for a in range(K,M):
   for w,h,side in [(a,a,a),(a+1,a,a+1)]:
    E=16*(w+h)-t*w*h
    ee=exp_bounds(E-T)[1]
    positive+=ee*cpos
    central+=ee*sum((V[s]*fm[side-s] for s in range(2*d+1)),Decimal(0))
  positive*=B*iz4/Decimal(n)
  central*=2*iz6/Decimal(n)
  N=math.comb(2*d,d);nz4=(Decimal(N)*invZ)**4
  pre=2*K*K*exp_bounds(32*K-t*K*K+t*K-T)[1]*nz4
  merge=8*d*d*exp_bounds(32*M-t*M*M-T)[1]*nz4
  late=2*n*exp_bounds(32*M-t*M*M+16-T)[1]
  source=exp_bounds(F(12968,5)-T)[1]
  total=(source+Decimal('1.0001')*(central+positive)+Decimal(10001)*(pre+merge+late))/(1-Decimal('0.000001'))
 out={'status':'CONDITIONAL directed arithmetic, requires geometric pushforward/weighted decoder/phase proofs and original-model dependencies', 'R':R,'L':1600,'d':d,'target_inverse_capacity_exponent':T,'q_upper':str(qu),'Z_lower':str(Zlo),'weighted_positive_decoder_upper':str(B),'scaled_terms':{k:str(v) for k,v in [('central',central),('positive',positive),('prefix',pre),('merge',merge),('late',late),('source',source)]},'normalized_resistance_upper':str(total),'passed':total<1,'conditional_capacity_lower':'exp(-%s)'%T,'conditional_Wcut_over_C_upper':'exp(%s)'%(T-6215),'seconds':time.perf_counter()-start}
 return out
if __name__=='__main__':
 import pathlib
 out=certify();print(json.dumps(out,indent=2));pathlib.Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
 assert out['passed']
