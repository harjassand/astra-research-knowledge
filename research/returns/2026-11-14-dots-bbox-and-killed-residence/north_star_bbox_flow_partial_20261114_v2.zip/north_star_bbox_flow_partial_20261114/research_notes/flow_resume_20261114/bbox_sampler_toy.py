from fractions import Fraction as F
from math import factorial,lcm
import random,json,time
rng=random.Random(20261114);start=time.time();L=3;n=9
steps=[(1,0),(-1,0),(0,1),(0,-1)]
def move(i,dx,dy):return ((i%L+dx)%L)+L*((i//L+dy)%L)
nn=[[move(i,*z) for z in steps] for i in range(n)]
aug=[nn[i]+[move(i,1,1),move(i,-1,-1)] for i in range(n)]
def core(x):return all(not(x>>i&1 and any(x>>j&1 for j in aug[i])) for i in range(n))
def weight(x):return F(2)**x.bit_count()/F(4)**sum(1 for i in range(n) if x>>i&1 for j in nn[i] if not(x>>j&1))
states=[x for x in range(1<<n) if core(x)];weights=[weight(x) for x in states];Z=sum(weights);b=F(1,128)
a=lambda j:F(1,8) if j==1 else F(1)
terms=[a(j)*F(12*j,factorial(j))*(n*b)**j for j in range(1,9)];Q=sum(terms)
def table(ws):
 den=lcm(*(w.denominator for w in ws));return [int(w*den) for w in ws]
def draw(v):
 k=rng.randrange(sum(v))
 for i,w in enumerate(v):
  if k<w:return i
  k-=w
W=F(0);edges=0
for x in states:
 for i in range(n):
  if x>>i&1 or core(x|1<<i):continue
  labels=tuple(j for j in aug[i] if x>>j&1);j=len(labels);y=x
  for v in labels:y^=1<<v
  assert core(y);ratio=weight(x)/weight(y);assert ratio==b**j
  c=weight(x|1<<i)/(weight(x)+weight(x|1<<i));accept=c*ratio/(a(j)*b**j);assert 0<=accept<=1
  representations=factorial(j)*4**j
  one=a(j)*F(12*j,factorial(j))*(b/4)**j/Q * F(1,12*j)*weight(y)/Z*accept
  assert representations*one==weight(x)*c/(Q*Z)
  W+=weight(x)*c;edges+=1
jt=table(terms);yt=table(weights);accepted=0;N=20000;sectors={}
for _ in range(N):
 j=draw(jt)+1;vs=[rng.randrange(n) for _ in range(j)];roots=[rng.randrange(4) for _ in range(j)];marks=[]
 for v,root in zip(vs,roots):
  for off in range(4):
   dx,dy=steps[(root+off)%4]
   marks += [move(v,dx,dy),move(v,dx-dy,dy+dx),move(v,dx+dy,dy-dx)]
 mark=rng.randrange(len(marks));i=marks[mark];y=states[draw(yt)]
 if len(set(vs))<j or mark!=marks.index(i):continue
 x=y
 for v in vs:x^=1<<v
 if not core(x) or x>>i&1 or core(x|1<<i):continue
 actual=set(v for v in aug[i] if x>>v&1)
 if actual!=set(vs):continue
 c=weight(x|1<<i)/(weight(x)+weight(x|1<<i));p=c*weight(x)/weight(y)/(a(j)*b**j)
 assert 0<=p<=1
 if rng.randrange(p.denominator)<p.numerator:accepted+=1;sectors[j]=sectors.get(j,0)+1
out=dict(scope='Executed toy bboxH2 proposal on3x3torus; full finite native structural support; exact rational sampling/acceptance, not R200 word-DP implementation',states=len(states),edges_identity_checked=edges,Q=str(Q),exact_acceptance=float(W/(Q*Z)),attempts=N,accepted=accepted,empirical_acceptance=accepted/N,accepted_sectors=sectors,runtime=time.time()-start)
open('research_notes/flow_resume_20261114/bbox_sampler_toy.json','w').write(json.dumps(out,indent=2));print(out)
