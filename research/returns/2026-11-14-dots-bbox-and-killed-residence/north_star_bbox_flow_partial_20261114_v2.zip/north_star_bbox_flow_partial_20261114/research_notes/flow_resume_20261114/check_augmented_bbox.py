import json,time
L=4;n=L*L;start=time.time()
def adj(v,diag=True):
 x,y=v%L,v//L
 for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]+([(1,1),(-1,-1)] if diag else []):
  a,b=x+dx,y+dy
  if 0<=a<L and 0<=b<L:yield b*L+a
nb=[list(adj(v)) for v in range(n)];phys=[list(adj(v,False)) for v in range(n)]
checks=isolated=mergers=0
for mask in range(1<<n):
 lab={};comps=[];boxes=[]
 for v in range(n):
  if not(mask>>v&1) or v in lab:continue
  j=len(comps);q=[v];lab[v]=j;cc=[]
  while q:
   u=q.pop();cc.append(u)
   for w in nb[u]:
    if mask>>w&1 and w not in lab:lab[w]=j;q.append(w)
  comps.append(cc);boxes.append((min(u%L for u in cc),max(u%L for u in cc),min(u//L for u in cc),max(u//L for u in cc)))
 for v in range(n):
  if mask>>v&1:continue
  ids=set(lab[w] for w in nb[v] if mask>>w&1)
  if not ids:continue
  points=[v]+[w for j in ids for w in comps[j]]
  new=(min(w%L for w in points),max(w%L for w in points),min(w//L for w in points),max(w//L for w in points))
  sp=lambda b:b[1]-b[0]+b[3]-b[2]+2
  assert sp(new)<=sum(sp(boxes[j]) for j in ids)+2
  if len(ids)==1 and new!=boxes[next(iter(ids))]:
   assert sum(mask>>w&1 for w in phys[v])<=1;isolated+=1
  if len(ids)>=2:mergers+=1
  checks+=1
out=dict(scope='all planar4x4 patterns; fixed(+1,+1) diagonal augmentation; no torus winding or filled-domain injection test',states=1<<n,additions_checked=checks,isolated_expansions=isolated,mergers=mergers,all_assertions_pass=True,runtime=time.time()-start)
open('research_notes/flow_resume_20261114/check_augmented_bbox.json','w').write(json.dumps(out,indent=2));print(out)
