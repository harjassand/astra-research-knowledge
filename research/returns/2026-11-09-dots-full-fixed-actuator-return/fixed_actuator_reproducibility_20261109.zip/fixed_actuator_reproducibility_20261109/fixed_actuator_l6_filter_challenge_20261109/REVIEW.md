# Separate challenge of the physical-L6 native filter

Date: 2026-11-09. Reviewer: resume_qec_benchmark. The exact inspected files and SHA-256 hashes are in BINDINGS.json. No author file was changed.

## Disposition and scope

I found no concrete mathematical blocker in the stated local native filter, strong endpoint reset, or paid heat-reference comparison. This is a separate source-and-algebra challenge, with direct primary-source reading and ten exact scalar reserve checks. It is not a PDE execution, a device test, an independent implementation of a controller, or clearance of the fixed-universal-calibration theorem. The reviewer had previously constructed a related Wiener-space filter and discussed the architecture with the author; that collaboration is disclosed rather than presented as blind replication.

The operation is genuinely unforced Navier-Stokes. Its reference background is initially its own nonlinear solution; the later heat-reference appendix explicitly pays the difference from linear heat. The initial split into an L6-bounded background and a small critical-heat remainder is an input hypothesis, not an acquired representation.

## 1. Critical-space mapping constant

I rederived the source-time split rather than assuming Koch--Tataru supplies the numerical value C=2^40. For G_s=(I-exp(s Delta))F_s,

    ||G_s||Hdot^-1^2 <=s||F_s||2^2.

The retarded heat-gradient operator has time-L2 gain at most 1/|xi| at each nonzero spatial frequency, by the time convolution kernel's L1 norm. Therefore its full space-time L2 norm squared is bounded by integral s||F_s||2^2, and this is at most ||F||Y ||F||L1. Leray contraction and tensor divergence do not add a dimension factor in this step.

For the complementary term, z(t)=grad exp(t Delta) H(t), H(t)=integral_0^t F(s)ds. Expanding the square and integrating in t gives exactly

    integral_0^1 ||z(t)||2^2 dt
      = Re integral_0^1 <F(s),[exp(2s Delta)-exp(2 Delta)]H(s)>ds.

The factor is one: two symmetric source-time triangles cancel the 1/2 from integrating the heat derivative. This identity does not require F to be positive. Gaussian absolute bounds and the Y cylinder mass control both convolutions. The small-scale cylinders needed here are among those allowed by the rescaled local norm.

The spatial near/far decomposition, source-time split at 1/2, and cube shells have enough explicit reserve. For example, the far-source coefficient is

    (343*6+26*6*16*2)*2^12 <2^25.

The displayed Gaussian shell reserve 1296 can be justified without numerical quadrature: grouping n in blocks of eight gives a bound below

    512*[1+4/7+16/(49*45)] <1296,

using exp(2)>7. There is a possible sqrt(3) when the first Gaussian derivative is embedded in the full Oseen tensor. Including it still leaves the claimed 2^12 kernel reserve valid in both r<=sqrt(t) and r>=sqrt(t) regimes, so this is not a needed correction to the final bound.

The source-localization estimates are uniform in the scaled cylinder size and apply to periodic extensions. No finite global R3 energy is needed for those extensions. Periodizing the integrable Oseen derivative kernel gives the torus mild operator, and uniqueness gives periodicity of the constructed solution.

## 2. Heat admission and viscosity normalization

For the unit torus and T<=1, the physical L6 heat estimate 2t^(-1/4)A yields an X_T bound at most 5A T^(1/4). The critical-heat remainder contributes at most 2 epsilon: heat L-infinity contraction bounds its pointwise component by its full time-integrated square, and the cylinder component is bounded by the same quantity.

The viscosity rescaling is U(tau)=u(t)/nu, tau=nu t. Under the stated duration and epsilon restrictions the total linear X_T size is at most 1/(8C), the nonlinear radius is 1/(4C), and the difference denominator is 1-3/8. Thus the factor 4epsilon/sqrt(nu delta) is valid. The smallness is local in time, not an assumption that the full L6 background is globally small.

## 3. Polynomial strong regularity

I checked the elementary derivative estimates underlying the tame constant. With full ordered derivative tensors, integration by parts gives

    ||Du||6^2 <=(4+sqrt(3))||u||infinity||D2u||3,
    ||D2u||3^2 <=(1+sqrt(3))||Du||6||D3u||2.

Replacing the two constants by 6 and 3 gives the author's product bound ab<=18Mc. The third-order ordered Leibniz constant is at most 110, below 128. The second/lower derivatives fit the same reserve, and the binomial Bessel norm preserves it.

Young's inequality consequently gives Y'<=2^13 ||u||infinity^2 Y/nu. The initial H3 bootstrap and the later t^(-1/2) critical velocity estimate produce the stated polynomial intermediate H3 bound. Smooth initial data first have a classical solution. Matching to the critical mild solution and bounded velocity away from zero provides continuation; this does not assume the desired global three-dimensional theorem.

## 4. Strong endpoint reset

For the squared Bessel energies, the exact identity ||grad u||Hk^2=E_(k+1)-E_k explains the additional nu E_k term. On [delta/4,delta], multiplication by exp[-a(t-t0)] makes

    F_k'+nu F_(k+1)<=0.

The derivative of sum_(k=0)^3 [nu(t-t0)]^k F_k/k! is nonpositive by exact telescoping. Native L2 contraction then yields the H3 endpoint constant 16; exp(2)*6*(4/3)^3<128 is sufficient. No initial H3 norm is present in this endpoint, although it remains in the intermediate ledger.

The remainder H^(3/4) estimate uses the final half-interval only. Its derivative heat singularity 7/8 is integrable. The free term has coefficient below 16, and the source coefficient is 384R<16; hence 32 is safe. The subsequent single-shear map follows from fiber L2 unitarity and summability of beta^(-5/2) in the transverse two-dimensional lattice. It does not need scattering, a maximum principle, or full Lp boundedness of a shear.

## 5. Heat-reference appendix

I separately rederived the periodic Oseen L^(6/5) kernel bound with a safe coefficient 2^24. Splitting the periodization into 27 near cells and the remaining summable r^-4 shells gives the stated t^(-3/4) scale for 0<t<=1. The original much stronger duration restriction makes the ordinary L6 Kato map contract in the ball 2A. Thus ||v||6<=2A is proved, not supplied for free.

Unit volume gives ||v tensor v||2<=||v||6^2<=4A^2. Integrating the H^(3/4) derivative heat multiplier therefore yields

    ||v(delta)-heat(delta)v0||H^(3/4)
      <=64 A^2 nu^(-7/8) delta^(1/8).

Adding the critical remainder gives the stated 32/64 two-term error. This legalizes a local heat reference under the explicit error budget. It does not automatically legalize a whole heat-interleaved controller.

## 6. Remaining construction obligation

The background/remainder split remains unpaid under arbitrary fixed-size transverse calibration. The known one-shear candidate takes H3 input to L6 output, not L6 input to L6 output. Endpoint smoothing is powerful but the next admitted wait may depend on the previous wait through H3. Earlier native errors may then be amplified by later smoothing factors. A fixed number of formal stages makes each formula polynomial, but does not by itself prove that their simultaneous accuracy inequalities have a polynomial solution. A small final L2 norm alone is not an arbitrary-data critical continuation criterion.

The proposed robust shear--heat sandwich construction must still close those dependencies and the final critical-space endpoint. No such closure is included in this review.

## Primary source and execution record

Koch--Tataru, Well-posedness for the Navier-Stokes equations, Theorems 2--3 and Lemmas 3.1--3.2, was read directly at https://math.berkeley.edu/~tataru/papers/nas.pdf. It establishes the local critical-space method and uses the same localization/high-low frequency architecture. The numerical constant here is supported by the separate displayed derivation, not attributed to a numerical value in that paper. No novelty claim is made for local critical-space well-posedness or derivative smoothing.

SCALAR_RESERVES.json contains ten exact elementary inequalities checked in a single lightweight local command. No timing-performance claim follows from that command. No fluid dynamics, spectral solve, empirical calibration, or full controller compilation was executed.
