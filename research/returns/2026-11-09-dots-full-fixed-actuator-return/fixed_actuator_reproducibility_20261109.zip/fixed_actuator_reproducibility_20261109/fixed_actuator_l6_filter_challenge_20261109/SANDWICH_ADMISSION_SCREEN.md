# Heat-sandwich construction: real linear gain, unresolved native accuracy loop

Date: 2026-11-09. Constructive feasibility screen, not a no-go theorem. The filter review and its bound source files remain unchanged.

## 1. A useful linear operation is available

Let H_t=exp(nu t Delta), and let U_j be one exact inviscid native coordinate shear with its actual static allowed gain, phase and transverse direction. Consider

    S_j=H_(b_j) U_j H_(a_j), a_j,b_j>0.

On a nonresonant transverse fiber, input and output heat tails make the longitudinal complement of a finite interval small in L2 operator norm. The remaining finite matrix has entries controlled by the already available quantitative Jacobi dispersion (and the free-polarization analogue). Thus a polynomial action can make S_j small on every admitted active fiber. Large transverse fibers are handled directly by the heat factors. Neither an input H3 assumption nor an impossible inviscid L2-to-negative operator contraction is needed in this LINEAR sandwich statement. Its cutoff and action constants still need to be written in a final compiler.

Two first shears with p=e1 and nominal transverse directions e2,e3 preserve each transverse fiber. Under small constant calibration, at least one has a uniformly nonzero projected speed in every nonzero transverse fiber. All sandwich factors are L2 contractions; a sector contracted by either stage cannot recover its norm in the other. Their common longitudinal axis is handled by a third p=e2 shear with nominal direction e1. The usual E/Q decomposition gives a full linear contraction at most sqrt(2) times the sector tolerance. Adjacent heat factors can be combined algebraically, but actual native intervals must still pay their self-advection.

This is a genuine way heat can erase the previously exhibited inviscid echo. It does not prove a native nonlinear controller.

## 2. What the new filter actually supplies

For a physical-L6 background bound A and a tiny pulse-error critical remainder, the filter supplies an actual native wait with a paid heat-reference error. The background's L6 remains <=2A. Besides the established H^(3/4) error, its simpler L2 heat error obeys

    ||v(delta)-H_delta v0||2 <=16 A^2 sqrt(delta/nu),

from the L2 derivative heat multiplier and the L2 source bound 4A^2. Constants here are deliberately conservative. Tiny native-pulse errors can be made independently smaller after the pulse action is chosen.

The native endpoint also resets H3 to at most16 K2/(nu delta)^(3/2). The available action-uniform one-shear physical-Lp candidate uses this H3 as its NEXT input bound: A_next<=C_p H3. It is not an action-uniform L6-to-L6 theorem.

## 3. Explicit failure of the obvious sequential allocation

Hold K2, nu and all fixed theorem constants fixed while inspecting accuracy exponents. If one chooses the next waiting time from a local L2 nonlinear-error budget e_j using the displayed sufficient bound, then

    delta_j is proportional to e_j^2 / A_j^4.

After resetting H3 and applying the currently available H3-to-L6 bound,

    A_(j+1) is proportional to delta_j^(-3/2).

Consequently the direct three-stage factory has

    delta_1 ~ e_1^2,
    delta_2 ~ e_2^2 e_1^12,
    delta_3 ~ e_3^2 e_2^12 e_1^72.

These are dependency exponents of sufficient allocations, not asserted physical asymptotics. Smaller initial errors make later admitted filters much shorter.

A generic L2 error carried by contractive linear factors is converted by the final heat into the critical heat norm with a factor of order (nu delta_3)^(-1/4). This follows directly by integrating the L2-to-Linfinity heat estimate from time nu delta_3 onward. The certificate for the first error then scales as

    e_1 delta_3^(-1/4)
      ~ e_1^(-17) e_2^(-3) e_3^(-1/2),

which grows when all error budgets shrink. The stronger H^(3/4) local-error factory has an even worse version of this dependence. Therefore the statement 'there are only three stages, hence all allocations close polynomially' is not a valid argument. A small final L2 target alone is not an arbitrary-data Navier-Stokes critical continuation criterion either.

This calculation refutes that PARTICULAR generic sufficient allocation, not the existence of a better allocation, true cancellation, a robust controller, or even a better estimate for these same paths.

## 4. Exact missing operation and possible repairs

At least one further estimate is needed:

- a shear-adapted physical input norm that survives a native filter without passing back through the full H3 smoothing cost;
- an action-uniform physical-Lp propagation/smoothing theorem of the type the constructor is investigating;
- sector-aware nonlinear error information proving that the next active sandwich contracts the actual error rather than treating it as arbitrary L2 data;
- a native dissipative block estimate that pays self-advection directly, instead of accumulating absolute heat-reference errors.

The first two are currently unproved in the supplied material. The third cannot be assumed from a linear frequency cone, since nonlinear sums can leave that cone. The fourth is a serious nonlinear observability/hypocoercivity target, not the scalar-shear maximum principle.

The completed filter remains a useful legal operation and the linear sandwich remains a promising representation. Their composition is conditional until this accuracy loop is repaired. No fluid execution, parameter search, or controller run occurred in this screen.
