# Dependency and external-source guide

The governing candidate is `fixed_actuator_universal_return_20261109/PROOF_CANDIDATE.md`. Its exact hash is in the original and package manifests. The candidate's standard-theory dependencies are not claimed to be newly proved from first principles here.

## Governing analytic chain included locally

The separate `fixed_actuator_universal_return_20261109/H3_BALL_EXTENSION.md` adds the full closed-H3-ball statement through an explicit H3 product/stability estimate, Fourier truncation and same-programme limiting argument. It does not change the frozen smooth-data proof. Its separate coordinated narrow review is `fixed_actuator_heat_sandwich_audit_20261109/H3_BALL_EXTENSION_REVIEW.md`, bound by `H3_EXTENSION_BINDING.json`; it found no blocker conditional on the governing smooth-data theorem. The later `fixed_actuator_three_sandwich_check_20261109/GOVERNING_MATCH.md` relates its dependency reconstruction to the final governing proof; its author also authored the physical-Lp component, so it is not independent certification of that component.

- Native coordinate-shear chain, moment budgets and polynomial-beta sector dispersion: `controlled_fluid_fixed_actuator_20261109/PROOF_CANDIDATE.md`, Sections 1–4, with `JOST_DIRECT_RECURRENCE_REPAIR.md`. The superseded index interpretation is preserved only for historical comparison in `JOST_CONSTANT_LEDGER.md`. The challenge is `fixed_actuator_return_20261109/JACOBI_SOURCE_CHALLENGE.md`.
- New physical-L6 fiber synthesis: `fluid_uniform_spectral_edge_20261109/PHYSICAL_LP_CANDIDATE.md`, supported by the companion Volterra derivation and the final audit's direct reconstruction checks.
- Critical heat estimates and actual nonlinear waiting: the five proof/interface documents in `fixed_actuator_critical_heat_bridge_20261109/`, culminating in `L6_BACKGROUND_NATIVE_FILTER.md`, `STRONG_ENDPOINT_RESET.md`, and `NATIVE_HEAT_REFERENCE.md`.
- Native short-pulse H3 hierarchy, H1 discrepancy and final critical-Fourier continuation: the complete mathematical 8EB and BCA response excerpts under `fixed_actuator_return_20261109/sources/`.
- Prior robust controller with growing spatial frequencies: the complete mathematical 2B5 response excerpt in that same directory. This is prior control capital, not a competing claim that its frequencies are fixed.
- Current polynomial Jacobi operation: `fixed_actuator_return_20261109/followup_review/CURRENT_POLYNOMIAL_JACOBI_EXCERPT.md`. Original path/hash and extraction are in the provenance map.

Relative filenames in a proof normally mean the same directory. Cross-directory paths retain their original names. Where an original source filename was replaced by a labeled excerpt, use `DEPENDENCY_RESOLUTION.json`. The older exact-direction construction and its own original proof are included because the governing inventory references them; their shrinking-tolerance controller is not substituted for the new fixed-radius result.

The scoped physical-Lp review mentions `WEAK_BRANCH_ESCAPE.md`. That separate-route note, the referenced `REPEATED_WORD_PHASE_FLOOR.md`, its check script and frozen exact results are included in `fixed_actuator_independent_audit_20261109/repeated_cyclic_obstruction/`. These are bounded-schedule obstruction/context records, not premises for the new nonlinear heat-sandwich construction and not universal impossibility claims.

## Standard primary sources not bundled

1. I. Egorova, M. Holzleitner and G. Teschl, Jacobi dispersive/scattering paper, arXiv:1506.06555v2. Sections 2–3, scattering relation (2.5), kernel formulas (3.2)–(3.3), and same-sign scattering case. https://arxiv.org/html/1506.06555v2
   The physical-circle Lp application is the present derivation; it is not a quoted theorem of that paper.
2. Gerald Teschl, *Jacobi Operators and Completely Integrable Nonlinear Lattices*, Chapter 10, printed pp. 167–169, especially (10.2), (10.6), (10.8)–(10.12). https://www.mat.univie.ac.at/~gerald/ftp/book-jac/jacop.pdf
   The direct repaired recurrence avoids relying on the earlier ambiguous extracted index.
3. B. Hollenbeck and I. Verbitsky, *Best constants for the Riesz projection*, Journal of Functional Analysis 175 (2000), 370–392. DOI 10.1006/jfan.2000.3616. https://doi.org/10.1006/jfan.2000.3616
   Only a generous classical O(p) projection estimate is needed. The source record reports an indexed abstract, not a successful full-text read of this paper; no new full-text access is claimed here.
4. H. Koch and D. Tataru, *Well-posedness for the Navier–Stokes equations*, Theorems 2–3 and Lemmas 3.1–3.2. https://math.berkeley.edu/~tataru/papers/nas.pdf
   The quantitative constants and physical-L6 allocation are spelled out in the included bridge proof, not attributed as numerical constants from this paper.

## Research-repository provenance

Repository: https://github.com/harjassand/astra-research-knowledge

The inherited response sources were recorded against commit `b94558eb630b431f03a7e14aba043f564c10cf70`:

- https://github.com/harjassand/astra-research-knowledge/blob/b94558eb630b431f03a7e14aba043f564c10cf70/research/returns/2026-11-09-p1-Xi-native-velocity-8eb-return/P1_XI_NATIVE_VELOCITY_8EB_RETURN_PUBLIC_PATHS.md
- https://github.com/harjassand/astra-research-knowledge/blob/b94558eb630b431f03a7e14aba043f564c10cf70/research/returns/2026-11-09-p1-Xi-polynomial-native-velocity-bca-return/P1_XI_POLY_NATIVE_VELOCITY_BCA_RETURN_PUBLIC_PATHS.md
- https://github.com/harjassand/astra-research-knowledge/blob/b94558eb630b431f03a7e14aba043f564c10cf70/research/returns/2026-11-09-p1-Xi-fixed-calibration-2b5-return/P1_XI_FIXED_CALIBRATION_2B5_RETURN_PUBLIC_PATHS.md

Current source binding recorded on 9 November 2026:

- N1777 default-branch path: https://github.com/harjassand/astra-research-knowledge/blob/main/research/returns/published-20261109/N1777.md
  Git blob: `8234680c3c1d9c9959ffd3725a80de3fee32f2cc`. Local full snapshot: `followup_review/N1777_current.md` under the return directory. SHA-256: `38cfa72ee9935983281c96f808512411d1022745e125c075c46f523c19c951a6`.
- Current Jacobi derivation default-branch path: https://github.com/harjassand/astra-research-knowledge/blob/main/research/returns/2026-11-09-root-fixed-jacobi-scattering/ROOT_A43D_COMPLETE_UNIFORM_POLYNOMIAL_JACOBI_DISPERSION.txt
  Git blob: `126343984fa78902d5d7cba89a09fcc005178507`. Original SHA-256: `e89b2d25030b96a45eb97a32c040e2a3a17f963602204b98d8769243b5721833`. The package contains the labeled mathematical excerpt.

The default branch may move. A Git blob identifies content, not a commit permalink. The packaged snapshots/excerpts and provenance hashes supply the reproducible local evidence. Full N1777 links to broader knowledge cards, units, and repository tooling are external navigation references, not additional local proof files bundled here.

The historical `SOURCE_INDEX.json` additionally names a qualitative sector note at `research/returns/2026-11-09-p1-Xi-fixed-calibration-2b5-return/ROOT_2B5_QUALITATIVE_SECTOR_SPECTRUM_AND_SCOPE.txt` in the same pinned repository commit. That external historical note is not a required premise of the governing quantitative derivation and is not bundled. Its complete repository location is identified by that index.

## Auxiliary comparisons, not substitute premises

The included historical notes cite these sources for comparisons or stronger known context:

- Coti Zelati–Delgadino–Elgindi, arXiv:1806.03258v1, Theorem 2.1 and abstract assumptions: https://arxiv.org/html/1806.03258v1. Linear mixing-to-dissipation, not the nonlinear bridge used by the new programme.
- Germain–Pavlovic–Staffilani, higher derivatives/analyticity context: https://arxiv.org/html/math/0609781. Not an unpriced numerical constant in the local-filter proof.
- Additional scalar/stochastic/comparator links remain in the included source index and historical source snapshots. No full-text inclusion, new fetch, permission to redistribute externally, novelty search, or independent reproof is implied.

No external source was retrieved anew while producing this archive. Access failures reported in historical source records were not retried.

The full external navigation targets from the N1777 snapshot, including its A43D response and older assessment/moment records, are resolved in `EXTERNAL_REFERENCE_INDEX.json`. They are historical external context. Governing local proof prerequisites are covered by the chain and resolution map above. `programme.json` is an example output name, not a missing executed artifact.
