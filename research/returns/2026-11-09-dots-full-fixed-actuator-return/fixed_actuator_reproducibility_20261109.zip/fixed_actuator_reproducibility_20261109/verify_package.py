#!/usr/bin/env python3
"""Offline package integrity verifier. Does not execute research scripts."""
from pathlib import Path, PurePosixPath
import hashlib, json, sys
ROOT = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    errors=[]
    manifest=json.loads((ROOT/'PACKAGE_MANIFEST.json').read_text())
    expected={x['path']:x for x in manifest['files']}
    for rel,row in expected.items():
        p=PurePosixPath(rel)
        if p.is_absolute() or '..' in p.parts:
            errors.append('Unsafe path in manifest: '+rel); continue
        f=ROOT/rel
        if not f.is_file() or f.is_symlink(): errors.append('Missing or nonregular file: '+rel)
        elif f.stat().st_size!=row['bytes'] or sha(f)!=row['sha256']: errors.append('Hash/size mismatch: '+rel)
    allowed=set(expected)|{'PACKAGE_MANIFEST.json','MANIFEST.sha256'}
    actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    if actual!=allowed:
        errors.append('File inventory differs: '+repr(sorted(actual^allowed)))
    sums={}
    for line in (ROOT/'MANIFEST.sha256').read_text().splitlines():
        digest,rel=line.split('  ',1); sums[rel]=digest
    if set(sums)!=set(expected)|{'PACKAGE_MANIFEST.json'}:
        errors.append('SHA-256 inventory differs')
    for rel,digest in sums.items():
        if not (ROOT/rel).is_file() or sha(ROOT/rel)!=digest: errors.append('SHA-256 list mismatch: '+rel)
    provenance=json.loads((ROOT/'SOURCE_PROVENANCE.json').read_text())['files']
    by_original={r['original_path']:r for r in provenance}
    for r in provenance:
        f=ROOT/r['archive_path']
        if not f.is_file() or sha(f)!=r['archive_sha256']: errors.append('Source archive mismatch: '+r['archive_path'])
        if r['form']=='verbatim' and r['original_sha256']!=r['archive_sha256']: errors.append('Verbatim source mismatch: '+r['original_path'])
    bindings=json.loads((ROOT/'DEPENDENCY_RESOLUTION.json').read_text())['bindings']
    for b in bindings:
        r=by_original.get(b['original_path'])
        if r is None or r['original_sha256']!=b['expected_original_sha256'] or r['archive_path']!=b['archive_path']:
            errors.append('Dependency resolution mismatch: '+b['original_path'])
    # Original manifest of the governing directory still verifies verbatim.
    governing=ROOT/'fixed_actuator_universal_return_20261109'
    for rel,digest in json.loads((governing/'MANIFEST.json').read_text()).items():
        if sha(governing/rel)!=digest: errors.append('Governing original manifest mismatch: '+rel)
    result={'status':'PASS' if not errors else 'FAIL','payload_files':len(expected),'total_files':len(actual),'included_source_files':len(provenance),'governing_binding_entries':len(bindings),'errors':errors,'scope':'File integrity and provenance only, not mathematical validation or scientific replay.'}
    print(json.dumps(result,indent=2))
    return 1 if errors else 0

if __name__=='__main__':
    sys.exit(main())
