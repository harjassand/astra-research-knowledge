from fractions import Fraction as F
import json
# Exact scalar reserves, not a PDE solve or executed synthesis.
checks={
 'rational_cover_surrogate': F(7,10)**2 < F(1,2) and F(7,10)-F(1,1024)>F(1,2),
 'fiber_amplitude': 16*(2**200*6**4)**2 < 2**600,
 'stage_one_admission': 8*F(1,8)==1,
 'stage_two_admission':16*F(1,32)+8*F(1,16)==1,
 'stage_three_admission':16*(F(1,64)+F(1,64))+8*F(1,16)==1,
 'first_two_sector_budget':F(2,16)+F(4,16)<1,
 'third_sector_budget':F(2,8)<1,
 'critical_endpoint':16*(F(1,4096)+F(1,4096))==F(1,128)<F(1,4),
}
assert all(checks.values())
def delta_inv(einv): return max(1,4+3,8*einv+7+16)
def eps_inv(einv,dinv): return max(1,einv+1+dinv)
e3i=1; d3i=delta_inv(e3i); ep3i=eps_inv(e3i,d3i)
e2i=ep3i; d2i=delta_inv(e2i); ep2i=eps_inv(e2i,d2i)
e1i=ep2i; d1i=delta_inv(e1i); ep1i=eps_inv(e1i,d1i)
tinv=[d1i+1,d2i+1,d3i+1]
S=[13*(1+ep3i+tinv[0]+tinv[1])]*2+[13*(1+e3i+tinv[2])]
L=[3*x for x in S]
Kin=[1,1+2*tinv[0],1+2*tinv[1]]
M=[x+y for x,y in zip(L,Kin)]
rhoi=[ep1i,ep2i,ep3i]
hinv=[max(0,2*l+k,r+l+max(1+m,2*m),m) for l,k,r,m in zip(L,Kin,rhoi,M)]
globalM=max(3*m+2 for m in M)
resources={
 'global_H3':globalM,
 'terminal_time':globalM+6,
 'peak_W3':max(s+h for s,h in zip(S,hinv)),
 'peak_time_derivative_W2':max(s+2*h for s,h in zip(S,hinv)),
 'squared_actuation_integral':max(2*s+3*h for s,h in zip(S,hinv)),
 'expanded_pulse_coefficients':max(s+7*h+6 for s,h in zip(S,hinv)),
}
assert max(resources.values())<4000000
result={'scope':'Exact scalar and symbolic degree checks only. No PDE, calibrated experiment, spectral replay or full controller expansion.',
 'scalar_checks':checks,
 'degrees':{'delta_inverse':[d1i,d2i,d3i],'epsilon_inverse':[ep1i,ep2i,ep3i],
 'nu_delta_inverse':tinv,'actions':S,'L':L,'native_input_H3':Kin,'partial_pulse_H3':M,
 'pulse_duration_inverse':hinv,'resources':resources,'safe_envelope':4000000}}
print(json.dumps(result,indent=2))
