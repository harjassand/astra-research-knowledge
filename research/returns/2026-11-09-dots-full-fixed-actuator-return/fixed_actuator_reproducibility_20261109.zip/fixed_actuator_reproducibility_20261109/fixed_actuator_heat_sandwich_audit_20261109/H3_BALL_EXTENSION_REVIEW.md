# Narrow review of the closed-H3-ball extension

Date: 2026-11-09. Inspected source: fixed_actuator_universal_return_20261109/H3_BALL_EXTENSION.md, SHA256 c96b7118b18b0d63195a8dfaba05175ed10902e467dc2ec17b0754614f2037f3. Governing smooth-data proof remains SHA256 d27a5663b6fc139733e1de7147b2acfc550dbca0019c5fda517bbf22a3d18875. Neither source was edited.

## Disposition

No mathematical blocker was found in this extension, assuming the governing uniform smooth-data result and its stated dependencies. It legitimately extends the same programme to every real, mean-zero, divergence-free datum in the closed H3 ball, with the same resource and endpoint bounds. This is an analytic review; no numerical solve or initial-data approximation was executed.

## Checks

1. Product constant. The weight inequality follows from the triangle inequality for sqrt(1+|q|^2) and (a+b)^3<=4(a^3+b^3). Young convolution and the stated Fourier-l1 embedding give4*(2+2)=16. The three-dimensional maximum-coordinate shell has24r^2+2<=26r^2 points; 4pi^2>36 and sum r^-4<2 leave ample room in the embedding constant2. Euclidean vector/Frobenius tensor norms obey the same convolution estimate without another dimension factor.

2. Divergence form. With F_ij=w_i u_j+v_i w_j-w_i b_j, div F=(u.grad)w+(w.grad)v-(b.grad)w, using div u=div w=div b=0. This is precisely the difference of the two native equations. The sign and order of the prescribed-transport term are correct.

3. Difference energy. Pairing after three Bessel derivatives and integrating the divergence by parts costs one derivative of w, which viscosity pays. The bound16(2M+B)||w||H3 gives128(2M+B)^2/nu after Young's inequality. The squared-norm Gronwall exponent is256/nu; the stated NORM exponent128/nu is therefore correct. There is no hidden H4 norm of u or v on the right side.

4. Approximation at the boundary. Symmetric Fourier cube truncation preserves reality, mean zero, divergence-free constraint, and H3 norm<=K exactly. All approximants use the same programme and the same fixed actual calibration tuple. The finite-time stability factor is independent of truncation, so their H3 convergence is strong and uniform in time on every compact interval. This proves C([0,infinity);H3), including strong continuity at t=0, without claiming weak compactness supplies it.

5. Passing the equation and regularity. Products converge in C_tH3. In mild form, the derivative heat singularity is(t-s)^(-1/2), which is integrable. Alternatively the PDE right side converges in C_tH1. The uniform H3 flux-energy estimate controls integral ||grad u_n||H3^2, hence integral ||u_n||H4^2; weak compactness identifies the same already-established strong H3 limit. Its right side is continuous in H1, so u_t is continuous in H1, with the one-sided initial derivative understood at t=0. Standard local parabolic spatial smoothing gives a classical positive-time solution. The globally C2 time envelope is sufficient for this assertion; infinite time differentiability across switches is not claimed.

6. Uniqueness. The difference estimate extends to the stated H3-strong class by the energy argument with u,v in L2_locH4 and their time derivatives in L2_locH2, or by regularization. On each compact interval, the finite maximum of the two H3 bounds replaces M. Zero initial difference forces equality. No assertion of uniqueness among arbitrary energy-class weak solutions follows.

7. Uniform endpoints and calibration. Strong H3 convergence preserves the common terminal H1 and switch-off H^(3/4) estimates. The continuous H^(3/4)-to-Fminus1 embedding preserves critical smallness. The argument fixes an arbitrary allowed pulse-static calibration tuple; programme parameters and bounds are independent of that choice, and the prescribed-field bound can be uniform. No countable-net, exceptional-set or feedback argument is required.

8. Resources. The exponential stability bound is solely a mathematical existence/convergence constant. No cutoff is computed, measured, or used by the controller, and no error radius from this exponential enters the programme. Thus the extension does not add an uncharged exponential physical resource or synthesis cost. It does not establish efficient numerical approximation of each H3 initial datum, which is a different claim.

## Scope

The extension corrects a literal statement gap between smooth inputs and the closed H3 ball. It does not strengthen the underlying spectral or native control premises, cover frequency/timing errors or time-varying calibration, qualify an implemented solver, or independently validate the entire controller a second time. The earlier smooth-data proof and failed allocation records remain unchanged.
