# Separate challenge of the three-block heat-sandwich ledger

Date: 2026-11-09. This is a mathematical dependency, norm and resource audit, not a PDE solve, numerical controller execution, hardware certificate or novelty assessment. The reviewer coordinated with the two construction workers and previously checked the single-shear physical-Lp source. That collaboration is disclosed; this is not blind replication.

## Disposition

The generic reset-based composition does have the suspected accuracy loop. The new same-coordinate, two-background construction genuinely avoids that particular loop. I found no concrete blocker in its norm tracking, fixed-calibration sector cover, backward error allocation, or conservative resource degrees. A complete governing synthesis and its binding to inherited BCA/8EB interfaces are separate deliverables; this report challenges the displayed memo and supplies a compatible explicit ledger.

The distinction is essential: the large physical-L6 background is bounded from the ORIGINAL H3 input by a fixed-coordinate fiber argument. The ACTUAL intermediate H3 reset is used only to shorten the next native pulse and pay intermediate resources. Substituting that reset into the next L6 background would reintroduce the failed circle.

## 1. The failed generic allocation is a real certificate failure

Using only A_next <= C ||actual input||H3 and the reset ||actual input||H3 <=16 K/(nu delta_prev)^(3/2), a sufficient next lifespan scales as delta_next <= const delta_prev^6. Paying a fixed H^(3/4) heat-reference error through the A^-16 condition worsens that exponent to24. In the simpler L2-error factory, delta1~e1^2, delta2~e2^2 e1^12, delta3~e3^2 e2^12 e1^72. The final generic heat-to-critical amplification then charges the first error by e1 delta3^(-1/4)~e1^(-17)e2^(-3)e3^(-1/2).

These are dependencies of chosen sufficient upper bounds, not lower bounds on physical errors or a no-go theorem. A fixed stage count alone does not resolve them. The new allocation does not claim otherwise.

## 2. Fixed-coordinate fiber composition removes the amplitude loop

The nominal pairs are (e1,e2), (e1,e3), (e2,e1). Let U_j denote each actual static calibrated inviscid propagator, including its arbitrary phase and allowed gain, and D_j=exp(nu delta_j Delta).

The first two preserve the SAME transverse Fourier label xi=(k2,k3). On each such fiber, the supplied physical-circle L6 theorem bounds each full native propagator by C_f=2^200*6^4, uniformly in xi, action, phase and direction. The longitudinal heat operator is L6-contracting; its transverse heat factor is a scalar of modulus at most one. Hence

    ||(U2 D1 U1 f)_xi||L6(T1) <= C_f^2 ||f_xi||L6(T1).

Minkowski and the INITIAL H3 transverse Cauchy estimate then give the claimed fixed bound A=2^600 K. For an explicit reserve, one-dimensional H1-to-L6 costs at most2, and sum_xi(1+|xi|^2)^(-2)<17, so the original fiber sum is at most16 K. Thus16 C_f^2 K<2^425 K<A. The zero-transverse fiber is the identity and fits the same bound.

This is a finite composition within one fixed fiber decomposition. It does not assert three-dimensional L6-to-L6 boundedness, an arbitrary-coordinate word bound or a viscous L6 semigroup theorem. Neither native nonlinearity nor its remainder is subjected to this fiber bound.

Let P project onto the k1 axis. Both first shears fix that axis and cannot move another transverse fiber into it, so

    P D2 U2 D1 U1 f = D2 D1 P f.

The surviving axis has H3<=K. A single third shear therefore has the same safe L6 background bound A. The full complementary reference and every inherited native error are placed in the SMALL remainder, not folded into A.

## 3. The active-sector decomposition includes all return paths

For xi!=0, max(|k2|,|k3|)>=|xi|/sqrt(2). If the two transverse direction errors have length at most1/1024, at least one actual unscaled direction satisfies |(a_j+e_j).xi|>=|xi|/2. The allowed gain is absorbed in the fixed mixing constant Q=2^3000. For the third shear every nonzero k1-axis mode is active, since its projected speed is at least(1-1/1024)|k1| before the gain.

Define E1 by the first active condition. E1 depends on the actual calibration only in the proof; it need not be known to the controller. It and its complement inside I-P commute with BOTH first propagators and both heat stages. There is no pathwise truncation or discarded leave-and-return contribution.

The inherited active-sector estimate is H1 -> homogeneous Hminus1 with norm <=Q S^(-1/13). Heat converts homogeneous Hminus1 to L2 with norm <=t^(-1/2), L2 to H^(3/4) with norm <=2t^(-3/8), and homogeneous Hminus1 to H^(3/4) with norm <=2t^(-7/8), for t=nu delta<=1. Native inviscid evolution is L2-unitary. Therefore the memo's two bounds are valid:

    E1 branch: 2 Q K t1^(-1/2)t2^(-3/8) S1^(-1/13),
    other branch: 4 Q K t1^(-1/2)t2^(-7/8) S2^(-1/13).

Using S1,S2 >=max(1,[16QK/(q2 t1 t2)]^13), their sum is at most3q2/8, leaving spare margin. The third axis bound with S3>=max(1,[8QK/(zeta3 t3)]^13) is at most zeta3/4. The memo uses the looser q2 and zeta3 bounds.

Heat after an active stage removes its L2 mass before the other shear can return it. This is why the previous inviscid cyclic-word obstruction does not contradict this construction.

## 4. Backward small-remainder allocation really is acyclic

For the constant A use the local filter's

    delta(A,e)=min(1/nu, nu^3/(80*2^40*A)^4,
                         e^8 nu^7/(128^8 A^16)),
    eps(A,e,delta)=min(nu/(32*2^40), e nu delta/64).

First set e3=zeta3=nu/4096 and compute delta3,eps3. Next set e2=q2=eps3/64 and compute delta2,eps2. Last set e1=eps2/32 and compute delta1,eps1. Choose native-pulse H1 errors rho1=eps1/8, rho2=eps2/16, rho3=eps3/16.

The one-shear H^(3/4)-to-Fminus1 map has norm at most16, independently of its action; Hcal<=Fminus1/sqrt(2). An H1 native-pulse error has Hcal<=8rho. Thus

    stage1: 8rho1 = eps1,
    stage2: 16e1+8rho2 = eps2,
    stage3: 16(e2+q2)+8rho3 = eps3.

The background at stage2 is U2(reference output1), not U2(actual output1). The difference U2(actual-reference) is small in the admitted critical norm because the first block error is in H^(3/4). The same distinction is applied at stage3 after the P/(I-P) split. No nonlinear-sector invariance is claimed or needed.

Each block's native wait is supplied by the local nonlinear filter. The reference D_j is only an analysis object, with its nonlinear discrepancy already paid. The final actual H^(3/4) norm is <=e3+zeta3=nu/2048; the identity case of the16 embedding gives Fminus1<=nu/128, strictly below the inherited nu/4 global continuation threshold. The conclusion is not inferred from small L2 alone.

All waits/errors are chosen before actions. Actions cannot change A or those waits. Actual endpoint H3 affects only the later pulse duration. There is therefore no directed cycle in the displayed dependency graph.

## 5. Conservative explicit numerical-resource ledger

Let X=2+K+nu+nu^-1. A degree d below means <=C X^d with a fixed computable C; reciprocal quantities have their own displayed degrees. Correlations between factors are intentionally ignored, making these safe upper bounds.

Backward allocation:

    delta3^-1:31; eps3^-1:33;
    delta2^-1:287; eps2^-1:321;
    delta1^-1:2591; eps1^-1:2913.

The degrees of (nu delta_j)^-1 are2592,288,32. The action degrees are37882,37882,442. Put L_j=(1+2^29 S_j)^3 and b_j=2L_j. L_j degrees are113646,113646,1326.

Use rational reset inputs

    K1=K,
    K2=16K/(nu delta1)^2,
    K3=16K/(nu delta2)^2.

Their degrees are1,5185,577. The ordinary BCA partial-pulse reserves M_j=4L_j K_j have degrees113647,118831,1903. With C0=2^20, the familiar sufficient pulse durations are the minimum of

    1/3,
    1/(32 C0 L_j^2 K_j),
    rho_j/[b_j(nu M_j+C0 M_j^2)],
    1/(24 M_j).

Their reciprocal degrees are343853,351629,5165. These allocations are made after actions and reset inputs are fixed and give the requested H1 discrepancies without later inviscid-growth multipliers, because inherited errors are handled by the critical filter admission instead.

The filter intermediate estimate2M_j max(1,2^18 M_j^2 delta_j/nu) has degrees at most3deg(M_j)+2. Thus a common global H3 reserve has degree356495 after multiplying by the inherited fixed continuation constant. The rational terminal-time formula has degree at most356501.

Peak W3 actuation has degree389511, its time derivative in W2 degree741140, and the integrated squared actuation/derivative degree1130651. Expanded degree-six pulse coefficients have degree at most2499291: each is bounded by C S_j h_j^-7 times a sixth power of its pulse start time. The pulse starts are <=3+3/nu, hence have degree1. Do not substitute the much later terminal continuation time into this particular estimate.

Therefore the fixed numerical exponent4,000,000 comfortably covers this ledger. The three pulses and three waits have fixed degree/piece counts. The long final zero interval can be merged with the last wait or kept as an additional zero piece. Spatial frequencies remain e1,e2; the three nominal actuator pairs are fixed independently of K and nu.

There are only a fixed number of rational operations with fixed integer powers. Every intermediate height is O(B+1) with an enormous absolute constant, where B is the full binary input length; ordinary exact arithmetic gives polynomial synthesis bit work. This is a symbolic resource certificate, not a practical actuation claim or an executed full coefficient expansion.

## 6. Remaining qualifications

- The governing full assembly must bind the particular corrected Jacobi source, physical-L6 dependency, local nonlinear filter, BCA pulse interface and small-Fminus1 continuation. This audit does not silently replace those sources.
- The physical-L6 input is the one-shear author construction previously reviewed at its stated scope. Its substantive spectral reconstruction is not independently rederived a second time here.
- The programme is robust to the stated independent static gains, phases and transverse direction errors. No time-dependent phase/error, spatial-frequency error, timing error, or unmodelled forcing is covered.
- This does not prove arbitrary-data unforced Navier-Stokes regularity: the three controlled intervals supply an external skew transport before certified small-data continuation.
- The inherited 8EB/BCA/2B5 results remain accepted capital at their recorded scope. The prospective increment is fixed spatial actuator indices with universal transverse calibration, not the already-established broad robust-control theorem.
- No primary-literature novelty, hardware feasibility, scientific runtime or numerical propagation claim follows.

The earlier failed generic allocation is preserved separately and is not relabelled as a successful proof. The new repair works by changing the tracked reference structure, not by ignoring that failure.
