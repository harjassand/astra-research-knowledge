# Hostile end-to-end challenge of the universal-calibration candidate

Date: 2026-11-09. This is an additional analytic review, not an inference from the scalar checks. It preserves the earlier memo review unchanged. Exact version bindings are in END_TO_END_BINDINGS.json.

## Finding

The full candidate survives this challenge: I found no concrete counterexample, circular dependency, missing critical-continuation step, or incompatible inherited hypothesis at its stated static-calibration scope. The fixed-fiber physical-L6 estimate received a substantive mathematical check, not merely a check that the composition cites its conclusion.

This is a coordinated separate review by the same reviewer who earlier examined the physical-Lp candidate. It is not a fresh blind replicate, an independently implemented PDE solver, a proof-assistant certificate, a hardware trial, or a publication/priority judgment. The full argument still depends on the explicitly recorded standard Jacobi spectral/Riesz-projection facts and inherited native 8EB/BCA interfaces. The scalar script is bookkeeping only.

## 1. Re-derivation of the sensitive physical-L6 step

Write w_n=2a_n, c_n=1-w_n^2 and A_n=product_(m>=n)w_m. Substituting f_n=z^n g_n/A_n into the eigen-equation gives

    g_(n-1)+z^2(1-c_n)g_(n+1)=(1+z^2)g_n,

and hence exactly

    g_n-g_(n-1)=z^2[g_(n+1)-g_n-c_n g_(n+1)].

The vanishing-at-infinity coefficients therefore obey the repaired recurrence, not the obsolete index interpretation. At order z^2, Q1(n)=sum_(m>=n+1)c_m. At higher orders, summing the difference equation yields

    Qr(n)=Q_(r-1)(n+1)+sum_(m>=n+1)c_m Q_(r-1)(m+1).

All coefficients are nonnegative. Subtracting the equation at n+1 from that at n proves that each Qr decreases with n>=0. A_n increases toward1, so d_(n,r)=A_n^-1 Qr(n) is also nonnegative and decreasing. This direction of monotonicity was checked rather than inferred from positivity alone.

At z=1 the equivalent future-directed Volterra equation has kernel (m-n)c_m and later argument m+1. In its iterates the selected bond indices strictly increase. Replacing each m-n by m+1 bounds the expansion by the subset expansion of product_m[1+(m+1)c_m]. The inherited first-moment budget bounds this by exp(21), and A_0^-1<=exp(21). Thus sum_r d_(0,r)<=exp(42). This is a uniform coefficient-mass bound with no beta-dependent exponential.

For each r, the decreasing multiplier d_(n,r)1_(n>=0) is a positive mixture of finite interval Fourier projections plus its limiting half-line projection. Its total mass equals d_(0,r). The classical Riesz projection estimate consequently gives an Lp multiplier bound <=p d_(0,r) for p>=2; its adjoint at p has the same estimate by the dual exponent. Modulation is isometric. The series of modulation times these multipliers converges in operator norm, yielding both physical-circle Jost synthesis and adjoint bounds <=p exp(42).

This is an actual physical Fourier multiplier argument. It does not confuse a sequence-space lp wave-operator theorem with an Lp theorem on the circle. The zero-order coefficient's nonzero limit contributes a paid half-line projection; it is not omitted.

## 2. Spectral reconstruction: explicit checks against a triangular truncation failure

I reread the primary EHT paper directly: https://arxiv.org/html/1506.06555v2, Section2 scattering relation(2.5), spectral kernel(3.2)-(3.3), and the same-sign case formula in Section3. Its first-moment spectral theorem gives only possible point spectrum outside[-1,1]. Here the Jacobi norm is at most1, and the positive form excludes endpoint eigenvectors. Thus no unrepresented point-spectrum evolution remains. The scattering coefficients obey the required modulus bounds.

On the right half-line the ordered kernel, after scattering substitution, has two terms:

    integral m_t(theta) f_n(theta) f_k(-theta) dtheta,
    integral m_t(theta) R(theta) f_n(theta) f_k(theta) dtheta,

where m_t(theta)=exp(it cos(theta)). The second expression is manifestly symmetric in n,k. The first becomes its swapped version after theta -> -theta, because m_t is even. Therefore the factorized kernel covers the entire same-half block, not merely one triangle. There is no unbounded triangular truncation to be paid.

Each term is a composition of a Jost map or adjoint, reflection if needed, and multiplication by a bounded spectral function. The opposite-half block similarly uses only its own-side Jost factors and T. The left block follows by reflection. This verifies the operator factorization needed for physical Lp, not just entrywise kernel estimates. The use of the full circle is essential.

There are finitely many terms, covered by the reserved factor16. Spectral phase, reflection and T/R multiplication do not acquire time-dependent Lp norms. Combining both Jost factors gives the claimed scalar bound16 exp(84)p^2, uniformly in beta and time.

The native in-plane polarization components beta/sqrt(beta^2+n^2) and n/sqrt(beta^2+n^2) have bounded variation on their two half-lines, uniformly in beta. Each component multiplier can conservatively be bounded by4p. Extraction and reconstruction each cost at most12p after summing the three physical components. The in-plane part is therefore bounded by2304 exp(84)p^4, below2^200 p^4. The perpendicular free part is a physical multiplication of modulus one. Constant changes needed to add it fit the same large reserve. Static phase is a physical translation, not an extra oscillatory multiplier estimate.

The physical-L6 theorem therefore has a complete analytic route at the scope used by the composition. This recheck did not find an action growth, an omitted half-line projection, a missing bound state, an uncontrolled inverse scattering multiplier, or a polarization loss that would invalidate it.

## 3. Full composition rather than a scalar test

The first two shears share the same transverse fiber label; their action-independent L6 bounds compose with the actual linear heat reference within that decomposition. The initial H3 fiber sum pays both. The third large background is only the unchanged longitudinal axis, whose H3 remains at mostK. This background/remainder separation is maintained at every native filter admission.

Actual nonlinear errors need not preserve any active sector. They are instead admitted in the critical heat norm through the uniform ONE-shear H^(3/4)-to-Fminus1 map. The sector decomposition applies only to the exact linear reference. This avoids an otherwise invalid nonlinear cone-invariance assumption.

The full candidate incorporates gains into the actual transverse vectors. The safe perturbation bound is |v_j-a_j|<=2rho0+rho0^2<1/256, not merely rho0. Its displayed cover2(1/2+1/256)^2<1 is valid. On the surviving axis the third projected speed is at least(1-rho0)^2 times the transverse magnitude. Unknown actual phase/gain/error is used only in analysis; no algorithm reads it.

All reference actions are selected after the backwards waits/errors. The first two reference L6 amplitudes and the axis amplitude are unchanged by increasing those actions. Actual H3 influences only the subsequently selected pulse durations. This is a genuine acyclic dependence, not a claim that any fixed-depth rational factory must be feasible.

The final state is small in H^(3/4), hence in Fminus1. It is not a claim that a small L2 endpoint implies strong global continuation. All leave-and-return paths remain in the unitary operators and heat factors; there is no intervening physical projection.

## 4. Inherited native assumptions matched explicitly

The BCA differentiated hierarchy uses derivatives parallel to the actual shear direction and normal to its spatial frequency. The direction is static and transverse, exactly as required here. Its rotation is an analysis choice and does not need rational coefficients. Constant derivatives commute with Leray. Every shear commutator lowers the normal derivative count, native viscosity is nonpositive in those energies, and the self-advection estimate is an energy-pairing estimate, not a false H3-to-H3 bound on the nonlinearity.

For coordinate frequency |p|_1=1 and the admitted actual vector, |v|_1<=4. Thus the BCA envelope(1+2^24 S |v|_1(1+|p|_1)^3)^3 is covered by L=(1+2^29 S)^3. The chosen duration1/(32 C0 L^2 M_input) supplies the stated4L M_input reserve. The actual-versus-inviscid H1 Duhamel error uses nu||u||H3 plus C0||u||H3^2 and the paid partial-propagator bound2L. No nominal-direction comparison or small-angle interpolation is involved.

The governing duration formula omits the extra1/(24Z) cap used in my earlier conservative memo ledger. That cap is NOT needed here: it belonged to an earlier calibration-comparison allocation. The present BCA existence and local H1 error use only the three listed caps. Moreover its degree was smaller than the controlling reciprocal-duration degree in all three stages, so this omission does not change the conservative resource table.

For each native gap the admitted background is smooth, mean-zero and divergence-free, as is the full remainder. The local filter accepts a large H3 norm with small critical remainder and fixed L6 background. Its endpoint reset and intermediate polynomial H3 bound apply separately. The H^(3/4) source singularity is7/8<1; replacing it by an unintegrable H1 kernel would invalidate the proof, but the candidate does not do that.

The heat-reference discrepancy is explicitly the sum32eps/(nu delta)^(7/8)+64A^2 nu^(-7/8)delta^(1/8). The two min-conditions each pay half of the target. Thus the wait is genuinely nonlinear native Navier-Stokes, not a silently switchable heat semigroup.

At the final endpoint Fminus1<=nu/128, the torus Fourier inequality gives integral Fplus1<=1/127. The inherited H3 commutator coefficient1000 is covered by multiplication by2^1000. Mean-zero energy decays under both native self-advection and the prescribed skew transport. Interpolation H1^3<=L2^2 H3 then validates the stated rational common terminal time. Strong existence is obtained successively, never assumed for arbitrary initial data through the entire experiment.

## 5. Resources and quantifier boundaries

The governing full formulas match the earlier independent degree ledger. The constant3+3/nu used there can be tightened to1+3/nu because all three pulse durations are<=1/3. The post-control long interval must not be used as the pulse-start bound when expanding coefficients. With actual pulse starts, the degree2499291 bound remains valid and the4,000,000 common envelope has margin.

The numerical-resource constants are computable by finite arithmetic from displayed constants. The bit-work argument relies on a fixed number of rational operations and fixed powers, not polynomial runtime in the numerical value nu^-1. No infinitely precise calibration, spectral search, real oracle or PDE solve enters synthesis.

The nominal actuator programme is rational; the actual unknown phases/directions need not be. Uniform bounds cover them without claiming the actual perturbed field has rational coefficients. Exact frequency indices, exact switching times and pulse-static uncertainties remain essential. No claim for drifting phase, inaccurate frequencies/timing, residual forcing during nominal zero gaps, or arbitrary stochastic hardware error follows.

## Conclusion

The earlier generic sandwich loop is a failed sufficient allocation, preserved honestly. The full new candidate repairs it through fixed-coordinate fiber composition and an axis/critical-remainder split. The substantive new physical-L6 lemma and the end-to-end native norm chain both survived this hostile analytic challenge. This finding is stronger than agreement of scalar arithmetic, but narrower than an external independent validation, implemented scientific experiment, or novelty claim.
