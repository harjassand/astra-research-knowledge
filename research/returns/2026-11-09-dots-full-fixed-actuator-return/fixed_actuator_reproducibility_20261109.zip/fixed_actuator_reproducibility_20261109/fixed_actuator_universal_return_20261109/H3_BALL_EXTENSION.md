# Extension from smooth inputs to the entire closed H3 ball

Date: 2026-11-09. Separate mathematical addendum. Governing smooth-data proof: PROOF_CANDIDATE.md, SHA d27a5663b6fc139733e1de7147b2acfc550dbca0019c5fda517bbf22a3d18875. No frozen proof, compiler, source check, or earlier manifest is changed.

## 1. Literal earlier scope and strengthened conclusion

The frozen governing statement explicitly assumes smooth initial velocities. Its written statement therefore does not, by itself, claim every nonsmooth H3 datum.

The same construction and bounds extend to EVERY real, mean-zero, divergence-free u0 in H3(T3) with ||u0||H3<=K, including the boundary of this closed ball. For each allowed actual pulse-static calibration, the same prescribed programme has a unique global strong solution

    u in C([0,infinity);H3) intersect L2_loc([0,infinity);H4),
    partial_t u in C([0,infinity);H1).

The solution is classical for positive time, with spatial smoothing. No classical differentiability at t=0 beyond that supplied by H3 is asserted. It has the SAME rational common global H3 bound M, switch-off critical bound, terminal time T and terminal H1<=nu/4 bound. The same static-calibration quantifiers and exclusions apply.

This conclusion retains all spectral/control premises and analytic-review qualifications of the governing candidate. The extension does not strengthen those premises, cover arbitrary energy-class data, or claim uniqueness among arbitrary nonsmooth solution notions.

## 2. One explicit H3 product and stability estimate

Write Lambda=(1-Delta)^(1/2), and use Euclidean vector/Frobenius tensor norms. The elementary convolution estimate on the unit torus is

    ||f tensor g||H3 <=16 ||f||H3 ||g||H3.            (2.1)

Indeed, with q_k=2*pi*k, the weight obeys

    (1+|q_(l+m)|^2)^(3/2)
       <=4[(1+|q_l|^2)^(3/2)+(1+|q_m|^2)^(3/2)].

Young's sequence inequality and sum_k |fhat(k)|<=2||f||H3 give(2.1). The latter Fourier inequality includes the zero mode: square-shell counting gives

    sum_k(1+4*pi^2|k|^2)^(-3)
      <=1+[26/36^3]*sum_(r>=1)r^(-4)<4.

No H4 norm is hidden in this product estimate.

Let u and v be two smooth solutions driven by the SAME actual prescribed b, and w=u-v. Their exact difference equation can be written

    w_t-nu Delta w =-P div F,
    F=w tensor u+v tensor w-w tensor b,

with the tensor convention (div F)_i=sum_j partial_j F_ij. The prescribed b is divergence-free, so this is exactly the original transport term. On an interval on which both H3 norms are <=M, put B(t)=||b(t)||H3. Then

    ||F||H3 <=16[2M+B(t)]||w||H3.

Leray and Lambda commute and are orthogonal/self-adjoint on the divergence-free component. Pairing against Lambda^6 w and integrating the divergence by parts gives

    (1/2)d||w||H3^2/dt+nu||grad w||H3^2
      <=||grad w||H3||F||H3
      <=(nu/2)||grad w||H3^2
          +[128/nu][2M+B(t)]^2||w||H3^2.

Consequently, for every finite L>0,

    sup_(0<=t<=L)||u(t)-v(t)||H3
      <=exp{[128/nu] integral_0^L [2M+B(s)]^2 ds}
                     ||u(0)-v(0)||H3.              (2.2)

The field b is a finite collection of spatial trigonometric modes with bounded C2 time envelopes, followed by zero forcing. Thus B is finite and bounded on every finite interval. A uniform rational upper bound over the admitted actual calibration follows from the displayed actuator bounds; for example2^20 sum_j S_j/tau_j suffices. This estimate does not require derivatives of u or v above H3 on its right side.

The exponential in(2.2) is an existence/stability proof constant. It is NOT used as an additional controller amplitude, waiting time, synthesis cost, or physical resource. No operational approximation of u0 is required by the programme.

## 3. Same-programme Fourier approximation

Let Pi_n cut off the Fourier cube |k|infinity<=n and put u0_n=Pi_n u0. Then:

- u0_n is a smooth trigonometric polynomial;
- it remains real, mean-zero and divergence-free;
- ||u0_n||H3<=||u0||H3<=K, without replacing K by K+epsilon;
- u0_n converges strongly to u0 in H3.

Fix ANY one of the allowed actual calibration tuples. Use the SAME prescribed programme and that SAME tuple for every u0_n. The governing smooth-data result produces global smooth positive-time solutions u_n, all with the same global H3 bound M and endpoint bounds. Formula(2.2) applies to every pair u_n,u_m. They are Cauchy in C([0,L];H3) for each finite L. Completeness yields consistent limits u on all finite intervals, hence a global u in C([0,infinity);H3), with u(0)=u0 and ||u(t)||H3<=M.

This is strong H3 convergence, not merely weak compactness. In particular no lower-semicontinuity argument is being used to infer strong continuity at t=0.

## 4. Passing the equation, regularity and uniqueness

The product estimate(2.1) makes the nonlinear fluxes and prescribed transport flux converge in C([0,L];H3). The heat-divergence multiplier has H3 operator bound at most[nu(t-s)]^(-1/2), integrable in s. Therefore one may pass to the exact mild equation on every finite interval. Equivalently, the equation passes in C([0,L];H1), since Delta:H3->H1 and divergence:H3->H2 are continuous.

The uniform H3 energy estimate also gives a finite bound on integral_0^L ||u_n||H4^2: absorb the flux against nu||grad u_n||H3^2 using(2.1), the uniform M, and the bounded prescribed B. Weak compactness in L2H4 identifies the same strong H3 limit, proving u in L2_loc H4. The mild equation then gives partial_t u continuous into H1. Standard local parabolic smoothing, applied on intervals bounded away from zero with this smooth spatial coefficient field, gives the positive-time classical solution. The C2 time envelope is sufficient for the classical time derivative; no infinitely smooth time dependence across switches is claimed.

For any other H3-strong solution with the same datum and actual b, use(2.2) on each finite interval with the maximum of the two finite H3 bounds. The initial difference is zero, so the two solutions agree. This proves uniqueness in the stated strong class. It does not infer unrestricted weak-solution uniqueness.

## 5. Endpoints and all-calibration quantifiers

The actual smooth solutions all satisfy the switch-off H^(3/4) and Fminus1 bounds and the terminal H1 bound. Strong H3 convergence preserves H1 and H^(3/4) norms. It also preserves Fminus1, since the proved embedding Fminus1(g)<=16||g||H^(3/4) is continuous. Thus the SAME inequalities hold for u at the SAME rational times.

The argument fixed an arbitrary admissible actual calibration tuple. All programme choices and bounds M,T were independent of that tuple, and the B bound in(2.2) can also be chosen uniformly. Therefore the conclusion holds for every allowed tuple, with no exceptional set, feedback or calibration-dependent programme.

## 6. Resource and verification scope

No programme parameter is changed. The Fourier approximation is solely a proof device, not an additional synthesis algorithm, input measurement, spectral oracle or physical preparation. The exact numerical and bit-resource claims remain those already displayed in the governing candidate.

No PDE propagation, numerical initial-data approximation, full giant synthesis or hardware test was executed for this addendum. Its role is to close the literal smooth-versus-H3 statement gap using the already uniform smooth-data theorem and a directly displayed strong stability estimate. Separate mathematical review of this addendum should be recorded without rewriting the frozen source proof.
