# Fixed-actuator universal-calibration construction candidate

## Result and scope

The complete candidate now closes the previously explicit assembly gap by combining three fixed coordinate shears with actual nonlinear native waiting intervals. It uses the same prescribed rational programme for the whole mean-zero divergence-free H3<=K initial ball, and allows independent static gain, transverse-angle and arbitrary phase errors in every pulse at the fixed radius1/1024. Its target is global strong native evolution and H1<=nu/4 at a common rational time.

The governing proof is PROOF_CANDIDATE.md, SHAd27a5663b6fc139733e1de7147b2acfc550dbca0019c5fda517bbf22a3d18875. This remains an analytic construction candidate with its new physical-fiber L6 dependency and inherited Astra premises explicit. No PDE, hardware or practical-speed claim accompanies it.

## Mechanism that removes the old circularity

The first two pulses share the same longitudinal direction. Their fixed-fiber physical L6 bounds compose with one-dimensional fiber heat, so both reference backgrounds remain bounded by2^600K independently of actions and waiting times. The remaining one-dimensional axis is unchanged and has H3<=K. Only that axis is the final pulse's background; the small complement and implementation errors are carried in a paid critical remainder.

This allows all wait/error budgets to be chosen backwards before the actions. Native H3 growth affects only subsequently chosen very-short pulse durations, not the background amplitudes or previously fixed waits. The final state is small in a critical norm, not merely L2. The old generic H3-reset allocation failure is preserved separately in fixed_actuator_l6_filter_challenge_20261109/SANDWICH_ADMISSION_SCREEN.md.

## Complete formal costs

The exact straight-line compiler is synthesize.py, SHA1bb6529b7f27e0d57484167d5e5a394ed86014575bbe7248b29aeb05f4e71793. It outputs rational degree-six local pulse envelopes, rational breakpoints, the uncertainty radius, and native regularity/time/resource bounds. Rationals serialize in binary. For decimal input strings of arbitrary length, invoke Python with its standard digit-limit override, for example:

    python -X int_max_str_digits=0 synthesize.py --nu 1 --K 1 --output programme.json

This is a usage specification, not a reported executed synthesis. Even those simple parameter values produce immense formal integers; a full coefficient output has deliberately not been generated.

The proof gives a computable universal constant times(2+K+nu+nu^-1)^4000000 for all numerical resources and polynomial synthesis bit work/output height in the binary input length. This very large formal polynomial is not a practical engineering advantage or affordable-calibration claim. Frequencies and pulse timing remain exact; arbitrary time-varying, spatially varying or misindexed actuator errors are excluded.

## Executed evidence

One parent-authorized, pre-frozen source-only qualification passed all33 checks in0.079183 seconds whole child,11,448KiB. Checks include calibration covering, backwards critical budgets, unit-action/C2 pulse identities, the complete symbolic degree ledger, and compiler syntax. It did NOT execute the full giant synthesis, PDE evolution, scattering, or a parameter search. SOURCE_QUALIFICATION_FREEZE.json, SCALAR_RESULTS.json, SOURCE_CHECK.log and SOURCE_CHECK_COST.json preserve the inputs and actual outcome.

Two separate workers have reproduced the resource/error bookkeeping and found no remaining dependency loop in the corrected reference architecture. The local L6 filter has a separate source/algebra challenge. These scopes must not be conflated with a full independent executable proof or experiment. Final independent review of the governing composition and the physical-L6 dependency should be recorded in separate bindings without rewriting frozen evidence.

## Prior and credit

A fresh current N1777 read returned the same immutable Git blob8234680c3c1d9c9959ffd3725a80de3fee32f2cc. Current Astra already supplies the polynomial sector Jacobi operation and the stronger growing-frequency2B5 calibrated controller. The fixed-spatial-actuator endpoint is still stated open in that source. The candidate here credits that spectral/control capital and uses established local Koch--Tataru and heat-smoothing machinery. The team's new physical-fiber L6 reconstruction and the present reference/error assembly are distinct dependencies, not silently supplied by the old source.

No external novelty, priority, published-theorem acceptance, unforced arbitrary-data Navier-Stokes result, or device validation is asserted. The precise primary-source/dependency record is in DEPENDENCIES.json and the governing proof.
