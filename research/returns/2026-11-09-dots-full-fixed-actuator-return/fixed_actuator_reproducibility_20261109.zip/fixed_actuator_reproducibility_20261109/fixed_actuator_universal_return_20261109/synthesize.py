"""Exact straight-line synthesis. Full giant numerical output is NOT a tested benchmark.
All rationals serialize in binary to preserve the intended bit-size contract.
"""
from fractions import Fraction as F
import argparse, json

def ceilq(x):
    return -(-x.numerator // x.denominator)

def build(nu, K):
    nu, K = F(nu), F(K)
    if nu <= 0 or K < 1:
        raise ValueError('Require rational nu > 0 and K >= 1.')
    C, C0, Q = 2**40, 2**20, 2**3000
    A = 2**600*K
    def wait(eta):
        delta = min(1/nu, nu**3/(80*C*A)**4,
                    eta**8*nu**7/(128**8*A**16))
        eps = min(nu/(32*C), eta*nu*delta/64)
        return delta, eps
    e3 = zeta3 = nu/4096
    d3, ep3 = wait(e3)
    e2 = q2 = ep3/64
    d2, ep2 = wait(e2)
    e1 = ep2/32
    d1, ep1 = wait(e1)
    ds = [d1,d2,d3]
    ts = [nu*d for d in ds]
    es = [e1,e2,e3]
    eps = [ep1,ep2,ep3]
    rhos = [ep1/8,ep2/16,ep3/16]
    s12 = ceilq(max(F(1),(16*Q*K/(q2*ts[0]*ts[1]))**13))
    s3 = ceilq(max(F(1),(8*Q*K/(zeta3*ts[2]))**13))
    actions = [F(s12),F(s12),F(s3)]
    resets = [16*K/t**2 for t in ts]
    inputs = [K,resets[0],resets[1]]
    freqs = [[1,0,0],[1,0,0],[0,1,0]]
    dirs = [[0,1,0],[0,0,1],[1,0,0]]
    pulses, peaks, waits, now = [], [K], [], F(0)
    for j,(S,Min,d,rho) in enumerate(zip(actions,inputs,ds,rhos)):
        L = (1+2**29*S)**3
        b = 2*L
        Z = 4*L*Min
        tau = min(F(1,3),1/(32*C0*L**2*Min),
                  rho/(b*(nu*Z+C0*Z**2)))
        Fj = 2*Z*max(F(1),2**18*Z**2*d/nu)
        peaks += [Z,Fj]
        pulses.append({'start':now,'duration':tau,'action':S,
                       'frequency':freqs[j],'nominal_direction':dirs[j],
                       'local_r_coefficients':[F(0),F(0),F(0),
                           140*S/tau,-420*S/tau,420*S/tau,-140*S/tau],
                       'H3_during_pulse':Z,'pulse_H1_error':rho})
        now += tau
        waits.append({'start':now,'duration':d,'H3_during_wait':Fj,
                      'H3_endpoint':resets[j],'Hthreequarters_error':es[j],
                      'critical_input_budget':eps[j]})
        now += d
    M = 2**1000*max(peaks+[resets[2]])
    T = now+(1+64*K**2*M/nu**3)/nu
    W3 = 2**20*sum(p['action']/p['duration'] for p in pulses)
    dW2 = 2**40*sum(p['action']/p['duration']**2 for p in pulses)
    energy = 2**80*sum(p['action']**2*(1/p['duration']+1/p['duration']**3)
                         for p in pulses)
    return {'nu':nu,'K':K,'fixed_calibration_radius':F(1,1024),
            'background_L6_bound':A,'pulses':pulses,'native_waits':waits,
            'switch_off_time':now,'global_H3_bound':M,'terminal_time':T,
            'terminal_H1_bound':nu/4,'switch_off_Fminus_bound':nu/128,
            'peak_spatial_W3_bound':W3,'peak_time_derivative_W2_bound':dW2,
            'integrated_squared_actuation_bound':energy,
            'zero_field_after_last_pulse':True}

def encode(x):
    if isinstance(x,F): return {'num_binary':bin(x.numerator),'den_binary':bin(x.denominator)}
    if isinstance(x,list): return [encode(v) for v in x]
    if isinstance(x,dict): return {k:encode(v) for k,v in x.items()}
    return x

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--nu',required=True)
    parser.add_argument('--K',required=True)
    parser.add_argument('--output',required=True)
    args=parser.parse_args()
    program=build(args.nu,args.K)
    with open(args.output,'w') as f:
        json.dump(encode(program),f,indent=2)
        f.write('\n')
