# Three fixed-actuator blocks with universal static calibration

Date: 2026-11-09. End-to-end constructive candidate. The new physical-fiber L6 dependency, the separate local-filter challenge, inherited Astra premises, and execution limits are explicit below. This document is not a claim of practical control, experimental validation, external novelty, or an independently executed PDE theorem.

## 1. Target and exact uncertainties

On the unit three-torus retain the actual equation

    u_t + P[(u.grad)u] = nu Delta u + P[(b.grad)u].

Here P is Leray, nu>0 and K>=1 are rational, and the initial velocity is any smooth, real, mean-zero, divergence-free field with H3<=K. One prescribed rational programme must work simultaneously for this entire initial ball.

The only nominal frequency/direction pairs, in order, are

    (p1,a1)=(e1,e2), (p2,a2)=(e1,e3), (p3,a3)=(e2,e1).

During pulse j the actual field is

    b_j(t,x)=f_j(t) theta_j(a_j+e_j)
                    cos(2*pi*p_j.x+phi_j),

where |theta_j-1|<=rho0, |e_j|<=rho0, e_j.p_j=0 and rho0=1/1024. The phase is arbitrary. Each gain, direction error and phase is static within its own pulse and may differ independently between pulses. Timing and frequency indices are exact. There is no measurement, feedback, random-phase success event, or shared-calibration assumption.

The programme has three nonnegative rational-polynomial C2 pulses separated by zero-driver intervals. It will give unique global strong evolution, an explicit common rational global H3 bound M, and a common rational T at which H1<=nu/4. All numerical resources are bounded by C_*(2+K+nu+nu^-1)^4000000 for an explicitly computable universal constant C_*. Synthesis has polynomial bit work and output height/length in the full binary input length. These are huge formal resource bounds, not a practical proposal.

## 2. Dependencies and their scope

A. Current Astra N1777/A43D supplies quantitative fundamental Jacobi dispersion. The existing accepted 8EB/BCA interfaces supply native short-pulse continuation and small-critical-Fourier global continuation. Their exact sources are inherited from fixed_actuator_return_20261109/sources and followup_review. A fresh default-branch N1777 read on this date returned the unchanged blob8234680c3c1d9c9959ffd3725a80de3fee32f2cc. It still declares the fixed-spatial-actuator nonlinear endpoint open; its existing full 2B5 theorem instead permits growing spatial frequencies. We do not re-count the current polynomial Jacobi result as new work.

B. For a coordinate shear U(S), both native velocity polarizations give, on the sectors |v.xi|>=|xi|/2,

    ||U(S)||H1->Hdot^-1 <= Q S^(-1/13), Q=2^3000, S>=1.  (2.1)

This is a consequence of the already audited beta^8 dispersion plus the trivial beta^-2 bound. It does NOT require the newer proposed uniform-beta dispersion. Both phase gauges and the admitted gain are included. L2 is exactly unitary on each transverse fiber.

C. The NEW spectral dependency is fluid_uniform_spectral_edge_20261109/PHYSICAL_LP_CANDIDATE.md, SHA6b4ddd9328498adafa0774102cfbde188a2c9cea09574ea9a3fc775a3f6f2923. For one fixed nonzero transverse fiber, the physical longitudinal L6 operator norm of any static native inviscid shear is <=C_f=2^200*6^4, uniformly in action, direction and phase. The zero transverse fiber is unchanged. Its proof uses positive monotone own-half Jost coefficients and full-circle spectral reconstruction. This is not a full three-dimensional L6-to-L6 or viscous-semigroup theorem. It has separate narrow analytic reads, not a PDE experiment; the end-to-end candidate depends on this precise operation.

D. The local actual nonlinear filter, endpoint reset and heat-reference comparison are in fixed_actuator_critical_heat_bridge_20261109: L6_BACKGROUND_NATIVE_FILTER.md (c6f87541...), STRONG_ENDPOINT_RESET.md (f3bb8bf2...), NATIVE_HEAT_REFERENCE.md (b114fb07...). A separate source/algebra challenge at fixed_actuator_l6_filter_challenge_20261109/REVIEW.md (b627ef25...) found no local blocker. It is not clearance of this new composition.

For clarity, their usable local interface is restated. Write incoming state v0+w0 with L6(v0)<=A and Hcal(w0)<=eps, where Hcal(f)^2=integral_0^infinity ||heat(t)f||infinity^2dt. Put C=2^40. Given eta>0 choose

    delta=min{1/nu, nu^3/(80 C A)^4,
                       eta^8 nu^7/(128^8 A^16)},
    eps=min{nu/(32C), eta*nu*delta/64}.                 (2.2)

Then the ACTUAL unforced native wait exists strongly and ends within eta in H^(3/4) of exp(nu delta Delta)v0. Its two error terms are

    32eps/(nu delta)^(7/8)
       +64A^2 nu^(-7/8)delta^(1/8) <=eta.             (2.3)

Its endpoint H3 is <=16||incoming state||2/(nu delta)^(3/2), with rational reserve16K/(nu delta)^2. During the interval, initial H3 bound Z>=1 gives the polynomial reserve

    2Z max{1,2^18 Z^2 delta/nu}.                     (2.4)

The reference in (2.3) is legal only because the nonlinear background-to-heat error is explicitly paid. Native self-advection is not switched off during any gap.

Also, uniformly over any one such inviscid shear and all actions,

    Fminus1(Ug)<=16||g||H^(3/4),
    Hcal(g)<=Fminus1(g)/sqrt(2), Hcal(g)<=8||g||H1.  (2.5)

The first is only fiber unitarity plus summable transverse weights. It does not assume arbitrary-word propagation in a critical norm.

## 3. Action- and wait-independent reference backgrounds

Let D_j=exp(nu delta_j Delta), and let U_j denote the actual calibrated inviscid propagator for the selected action. Define

    f0=u0, f1=D1 U1 f0, f2=D2 U2 f1.

Set E to be the Fourier projection onto k=(n,0,0), and Q0=I-E. Since the first two shears share p=e1, they preserve every transverse fiber xi=(k2,k3), and they fix xi=0 exactly. Thus

    E f2=D2 D1 E f0,  ||E f2||H3<=K.                (3.1)

The physical fiber L6 bound in dependency C composes TWICE because p is unchanged. Longitudinal heat is a one-dimensional L6 contraction and transverse heat is scalar damping. Summing the INITIAL transverse fiber L6 norms with the H3 Cauchy estimate gives the common bound

    ||U1 f0||6<=A,
    ||U2 D1 U1 f0||6<=A,
    ||U3 E f2||6<=A,
    A=2^600 K.                                     (3.2)

No endpoint H3 from a previous wait enters (3.2). In particular A does not change when a wait is shortened or an action is increased. This is the specific repair of the failed generic H3-reset recurrence. The discarded Q0 f2 will be small and is charged as a critical remainder, not added to the third background.

The reference fields depend on the actual unknown calibration and initial datum only in the proof. No implementation step computes or observes them.

## 4. Backward rational wait and error allocation

Use the function delta(A,eta),eps(A,eta,delta) in(2.2), with the same A for all blocks. First choose

    e3=zeta3=nu/4096,
    delta3=delta(A,e3), eps3=eps(A,e3,delta3).

Then choose

    e2=q2=eps3/64,
    delta2=delta(A,e2), eps2=eps(A,e2,delta2),
    e1=eps2/32,
    delta1=delta(A,e1), eps1=eps(A,e1,delta1).

Finally allocate native pulse H1 implementation errors

    rho1=eps1/8, rho2=eps2/16, rho3=eps3/16.          (4.1)

This is a finite backward rational computation. All waits are now fixed, before any action is selected. It is not the earlier forward allocation whose background norm depended on the preceding wait.

## 5. Calibrated linear reference estimate

For the first two actual transverse vectors v_j=theta_j(a_j+e_j),

    max(|v1.xi|,|v2.xi|)>=|xi|/2, xi!=0.            (5.1)

Indeed each coordinate error is at most(2rho0+rho0^2)|xi|<|xi|/256, and 2(1/2+1/256)^2<1. Let E1 be the sectors active for pulse1. E1 commutes with both first shears and both heat operators, since they preserve xi. Its definition need not be known to the controller.

Write t_j=nu delta_j<=1 and theta=3/4. Heat multipliers, (2.1), and unitarity give

    ||E1 f2||Htheta
      <=2 Q K t1^(-1/2)t2^(-3/8) S1^(-1/13),
    ||(I-E-E1) f2||Htheta
      <=4 Q K t1^(-1/2)t2^(-7/8) S2^(-1/13).       (5.2)

In the first line heat1 changes Hdot^-1 to L2 and heat2 changes L2 to Htheta. In the second line heat1 supplies H1 from the original L2 bound, pulse2 mixes, and heat2 changes Hdot^-1 to Htheta. This keeps all longitudinal modes and both polarizations. It does not use an inviscid L2-to-negative contraction, which would be false.

Choose integer actions

    S1=S2=ceil(max{1,[16 Q K/(q2*t1*t2)]^13}),
    S3=ceil(max{1,[8 Q K/(zeta3*t3)]^13}).           (5.3)

The first two lines of (5.2) then sum to less than q2, since t_j<=1. Every nonzero k1-axis mode is active for the third actual vector near e1 with p3=e2. Equation(3.1), mixing, and heat3 give

    ||D3 U3 E f2||Htheta
      <=2 Q K t3^(-7/8) S3^(-1/13)<zeta3.          (5.4)

All three actions are selected AFTER the waits. Increasing them cannot invalidate (3.2).

## 6. Actual native state tracking

Implement each U_j by a sufficiently short native pulse with H1 error at most rho_j. The quantitative implementation is given in the next section; it includes both viscosity and self-advection.

For block1, use background U1 f0 and the pulse error. Its Hcal size is at most8rho1<=eps1. The filter gives actual output

    u1=f1+w1, ||w1||Htheta<=e1.

Before the second filter, the background is U2 f1, not U2 u1. The remainder is U2 w1 plus pulse implementation error. By(2.5),

    Hcal(remainder)<=16e1+8rho2<=eps2.

Thus the actual second output is

    u2=f2+w2, ||w2||Htheta<=e2.

Before the third filter use background U3 E f2. The remainder is U3(Q0 f2+w2) plus pulse error. Equations(4.1),(5.2) give

    Hcal(remainder)<=16(q2+e2)+8rho3<=eps3.

Consequently

    ||u3-D3 U3 E f2||Htheta<=e3,
    ||u3||Htheta<=e3+zeta3=nu/2048,
    Fminus1(u3)<=nu/128.                            (6.1)

This is a critical-space endpoint, not merely a small L2 conclusion. The backwards budgets specifically pay the inherited remainders through the next shear and nonlinear wait. The programme does not need any actual projection or pinching of the velocity.

## 7. Legal native pulses and the complete strong-solution ledger

Let M0=K and, after each wait, use the rational actual endpoint reserve

    M_j=16K/t_j^2.                                  (7.1)

Native energy is nonincreasing throughout every pulse and wait, because the prescribed field is divergence-free and Leray is orthogonal. Thus the same K bounds every actual L2 norm.

For pulse j set

    L_j=(1+2^29 S_j)^3, b_j=2L_j,
    Z_j=4L_j M_(j-1), C0=2^20,
    tau_j=min{1/3, 1/[32 C0 L_j^2 M_(j-1)],
                       rho_j/[b_j(nu Z_j+C0 Z_j^2)]}. (7.2)

The inherited native BCA hierarchy applies uniformly since the actual coordinate shear vector has bounded length, independently of its particular angle. It gives actual H3<=Z_j and existence throughout the pulse. Duhamel in H1 against the ACTUAL calibrated inviscid shear gives

    ||u_after-U_j u_before||H1
       <=tau_j b_j(nu Z_j+C0 Z_j^2)<=rho_j.         (7.3)

No comparison with a nominal direction is made; there is no small-angle perturbative loss in(7.3).

On the pulse interval beginning at a rational breakpoint a_j use

    f_j(t)=(S_j/tau_j)*140 r^3(1-r)^3,
    r=(t-a_j)/tau_j,

and zero elsewhere. Its integral is S_j; its first two derivatives vanish at both endpoints. Each pulse is followed by the ACTUAL unforced wait delta_j. All coefficients and breakpoints are rational. The total input remains smooth, with a globally C2 prescribed field.

During wait j take the H3 reserve

    F_j=2Z_j max{1,2^18 Z_j^2 delta_j/nu}.          (7.4)

Equation(7.1) then replaces it at the endpoint. This does not shrink the already selected wait: the local filter lifespan is independent of this possibly enormous Z_j. The reference amplitude remains the different bound(3.2).

Let T0=sum_j(tau_j+delta_j), and define a rational common bound

    M=2^1000 max{K,Z1,Z2,Z3,F1,F2,F3,M3}.

After T0 set the field to zero permanently. From(6.1) and the inherited torus inequality

    (Fminus1)' +(nu-Fminus1) Fplus1<=0,

the solution remains globally strong and H3<=M. The usual H3 commutator reserve1000 is more than covered by2^1000, since integral_(T0)^infinity Fplus1<=1/127. Mean-zero energy decay and interpolation give H1<=nu/4 at the common rational time

    T=T0+[1+64K^2 M/nu^3]/nu.                      (7.5)

This final zero-driver interval is also nonlinear native evolution, not linear heat. Strong existence follows block by block from the pulse hierarchy, the local filter, and then the critical continuation; no arbitrary-data global regularity is assumed.

## 8. Explicit resource exponents and bit work

Put X=2+K+nu+nu^-1. Each entry below means a computable universal constant times X to the displayed exponent. Negative powers are bounded through the indicated reciprocals. Independent arithmetic gives:

    e3^-1:1; delta3^-1:31; t3^-1:32; eps3^-1:33;
    e2^-1:33; delta2^-1:287; t2^-1:288; eps2^-1:321;
    e1^-1:321; delta1^-1:2591; t1^-1:2592; eps1^-1:2913.

    S1,S2:37882; S3:442.
    L1,L2:113646; L3:1326.
    M0:1; M1:5185; M2:577; M3:65.
    Z1:113647; Z2:118831; Z3:1903.
    tau1^-1:343853; tau2^-1:351629; tau3^-1:5165.
    max F_j, M:356495; T:356501.

For example, delta^-1 has degree max{1,7,8deg(eta^-1)+23}; eps^-1 has degree max{1,deg(eta^-1)+deg(delta^-1)+1}. These reproduce the full backward table without a parameter search.

Peak spatial W3 actuation is bounded by a fixed multiple of sum S_j/tau_j, and the time derivative in W2 by sum S_j/tau_j^2. The integrated squared actuation/derivative cost is bounded by a fixed multiple of sum S_j^2(tau_j^-1+tau_j^-3), with degree at most1130651. Expanding the degree-six envelope in global time has coefficients bounded by C S_j tau_j^-7 times breakpoint powers at most6. All active breakpoints are <=1+3/nu, so degree2499291 suffices. The announced4000000 envelope covers these quantities, all nonzero piece-duration reciprocals, M,T and fixed frequencies. Constants can be computed directly from the displayed finite formulas.

There is a fixed number of rational operations, integer powers of fixed degree, comparisons, and integer ceilings. If B is the complete binary input length, every numerator and denominator has O(B+1) bits with a very large absolute multiplier. Standard rational arithmetic therefore gives polynomial bit work and output length. There is no spectral search, calibration measurement, PDE solve, real-root oracle or count depending on a numerical value such as nu^-1. The enormous fixed bit multiplier is not concealed as practical efficiency.

Three active degree-six pieces and their zero-driver gaps suffice. The last wait and subsequent continuation can be represented as one zero piece while retaining the analysis breakpoint. No full coefficient synthesis or fluid propagation has been executed in preparing this candidate.

## 9. Why this differs from the failed routes

The old fixed-length INVISCID phase/resonance floors remain valid. This programme uses actual native waits, explicitly approximated by heat only within paid errors. The finite-frequency escape is then converted by heat, so the inviscid floors do not contradict it.

The failed generic filter allocation fed an endpoint H3 cost back into the next background amplitude. Here the first two same-p fiber bounds and the unchanged axis make all three reference amplitudes depend only on initial K. Actual H3 is still paid, but only in separately chosen native pulse durations and common regularity bounds. It never changes a previously chosen wait or critical-error budget.

The programme uses no uniform physical three-dimensional L6-to-L6 shear theorem, no viscous maximum principle, no simultaneous stochastic stirring, and no assumed enhanced-dissipation nonlinear theorem. The genuinely new dependency is the fixed-fiber physical-L6 synthesis, whose precise proof status must accompany this candidate. Known local Koch--Tataru/heat smoothing and inherited Astra control/spectral operations receive their existing scope and credit.

## 10. Verification status

The local filter has a separate algebra/source challenge; the older shrinking-angle controller had its own independent scoped audit. Neither automatically clears this stronger composition. The active-sector and backwards-budget calculations are being independently challenged in the current team. No claim of a published new theorem, priority, physical experiment, realistic calibration cost, or unforced arbitrary-data Navier-Stokes result is made. Preserve the earlier failed generic allocation and all frozen sources.
