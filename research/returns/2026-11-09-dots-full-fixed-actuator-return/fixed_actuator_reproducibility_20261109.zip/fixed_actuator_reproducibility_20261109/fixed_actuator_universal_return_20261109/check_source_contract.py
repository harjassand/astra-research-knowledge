"""Frozen scalar/source qualifier only. Never imports or runs giant synthesis."""
from fractions import Fraction as F
from pathlib import Path
import ast,json,hashlib
root=Path(__file__).resolve().parent
checks={}
def check(k,v):
    checks[k]=bool(v)
    if not v: raise AssertionError(k)
source=(root/'synthesize.py').read_text()
ast.parse(source)
compile(source,'synthesize.py','exec')
check('compiler_syntax',True)
r=F(1,1024)
check('coordinate_cover_error',2*r+r*r<F(1,256))
check('two_direction_cover',2*(F(1,2)+F(1,256))**2<1)
check('third_axis_cover',(1-r)**2>F(1,2))
check('actual_direction_length',(1+r)**2<2)
check('stage1_critical_budget',8*F(1,8)==1)
check('stage2_critical_budget',16*F(1,32)+8*F(1,16)==1)
check('stage3_critical_budget',16*(F(1,64)+F(1,64))+8*F(1,16)==1)
check('final_critical_embedding',16*(F(1,4096)+F(1,4096))==F(1,128))
check('linear_Q_budget',F(2,16)+F(4,16)<1)
check('linear_axis_budget',F(2,8)<1)
check('heat_error_share',F(64,128)==F(1,2))
check('critical_error_share',F(32,64)==F(1,2))
poly=[F(0),F(0),F(0),F(140),F(-420),F(420),F(-140)]
check('pulse_unit_action',sum(c/F(j+1) for j,c in enumerate(poly))==1)
for d in range(3):
    check(f'pulse_right_C{d}',sum(poly)==0)
    check(f'pulse_left_C{d}',poly[0]==0)
    poly=[j*poly[j] for j in range(1,len(poly))]
# Degree calculation follows the formulas, not the stated final table.
D,E,Ti={}, {}, {}
error=1
for j in [3,2,1]:
    D[j]=max(1,7,8*error+23)
    Ti[j]=D[j]+1
    E[j]=max(1,error+D[j]+1)
    if j>1: error=E[j]
S={1:13*(1+E[3]+Ti[1]+Ti[2]),2:13*(1+E[3]+Ti[1]+Ti[2]),3:13*(1+1+Ti[3])}
L={j:3*S[j] for j in S}
M={0:1,1:1+2*Ti[1],2:1+2*Ti[2],3:1+2*Ti[3]}
Z={j:L[j]+M[j-1] for j in S}
H={j:max(0,2*L[j]+M[j-1],L[j]+2*Z[j]+E[j]) for j in S}
Fpeak={j:3*Z[j]+2 for j in S}
globalM=max([1,M[3]]+list(Z.values())+list(Fpeak.values()))
ledger={'delta_inverse':[D[j] for j in [1,2,3]],'eps_inverse':[E[j] for j in [1,2,3]],
 't_inverse':[Ti[j] for j in [1,2,3]],'actions':[S[j] for j in [1,2,3]],
 'H3_after_pulse':[Z[j] for j in [1,2,3]],'pulse_duration_inverse':[H[j] for j in [1,2,3]],
 'global_H3':globalM,'terminal_time':globalM+6,
 'peak_W3':max(S[j]+H[j] for j in S),'time_derivative_W2':max(S[j]+2*H[j] for j in S),
 'squared_actuation':max(2*S[j]+3*H[j] for j in S),
 'expanded_pulse_coefficients':max(S[j]+7*H[j]+6 for j in S)}
expected={'delta_inverse':[2591,287,31],'eps_inverse':[2913,321,33],
 't_inverse':[2592,288,32],'actions':[37882,37882,442],
 'H3_after_pulse':[113647,118831,1903], 'pulse_duration_inverse':[343853,351629,5165],
 'global_H3':356495,'terminal_time':356501,'peak_W3':389511,'time_derivative_W2':741140,
 'squared_actuation':1130651,'expanded_pulse_coefficients':2499291}
for k in expected: check('degree_'+k,ledger[k]==expected[k])
check('single_numerical_envelope',max(v for v in ledger.values() if isinstance(v,int))<4000000)
result={'scope':'Source syntax, exact rational reservations and symbolic resource degrees only; no synthesis/PDE/scattering execution.',
        'checks':checks,'count':len(checks),'resource_degrees':ledger,
        'compiler_sha256':hashlib.sha256(source.encode()).hexdigest()}
(root/'SCALAR_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
