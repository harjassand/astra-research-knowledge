# Fixed-actuator fluid construction: reproducibility package

**Snapshot: 9 November 2026. Status: complete analytic construction candidate with coordinated internal research audits. It is not an externally peer-reviewed theorem, a proof-assistant certificate, or an experimental demonstration.**

This package preserves the governing candidate, its precise dependencies, the final end-to-end challenge, executable source-arithmetic checks, and the recorded test evidence. It is intended for careful mathematical review and reproducible bookkeeping, not for running a feasible fluid-control experiment.

## Exact claim and assumptions

On the unit three-torus, with the orthogonal Leray projection P, the equation is

    u_t + P[(u.grad)u] = nu Delta u + P[(b.grad)u].

For every rational viscosity nu > 0 and rational K >= 1, the candidate constructs **one prescribed rational, globally C2 programme** for every smooth, real, mean-zero, divergence-free initial velocity with H3 norm at most K. The programme uses three nonnegative degree-six pulse envelopes and zero-driver intervals. The three nominal frequency/direction pairs, in order, are

    (e1,e2), (e1,e3), (e2,e1).

During pulse j, the actual driver is

    b_j(t,x) = f_j(t) theta_j (a_j + e_j)
               cos(2*pi*p_j.x + phi_j).

The uncertainty radius is rho0 = 1/1024. Each pulse admits independently |theta_j - 1| <= rho0, |e_j| <= rho0, e_j.p_j = 0, and arbitrary phase phi_j. Gain, transverse direction and phase are constant within that pulse. Frequency indices and timing are exact. The zero-driver gaps really have zero prescribed driver. Native viscosity and nonlinear self-advection remain present throughout.

The claimed outcome is unique global strong evolution, a common explicit rational global H3 bound M, and a common rational time T with H1 norm at most nu/4. **The frozen governing statement literally assumes smooth initial data with an H3 bound. It does not by itself state an extension to every possibly nonsmooth H3 element.** The separately included `H3_BALL_EXTENSION.md` supplies an explicit approximation/stability argument for the full closed H3 ball with the same programme and bounds. Its statement and separate review status must not be silently attributed to the earlier frozen audit. The extended strong class is C([0,infinity);H3) intersect L2_loc H4, with time derivative continuous into H1 and positive-time classical regularity. It is not an arbitrary weak-data theorem. No measurements, feedback, observed calibration or favorable random realization are used. The claim does not cover drifting phases, time-varying or spatially varying calibration errors, erroneous frequencies or timing, or residual forcing in a gap.

**Resources:** all stated numerical resource bounds are at most a computable universal constant times

    (2 + K + nu + nu^(-1))^4,000,000.

The straight-line compiler is claimed to have polynomial bit work and output length in the full binary input length, with enormous fixed constants. The resource degrees include 356,495 for the global H3 reserve, 356,501 for terminal time, 1,130,651 for integrated squared actuation/derivative cost, and 2,499,291 for globally expanded pulse coefficients. This is a formal computability/resource result. No practical speed, affordable calibration, attainable actuation, or engineering advantage follows.

## What changed mathematically

The first two shears share the same longitudinal coordinate. A new, action-uniform **physical one-dimensional fiber L6 bound** composes with fiber heat, so the reference backgrounds can be bounded by 2^600 K without depending on prior waiting times or actions. The remaining coordinate axis is unchanged and supplies the third background. All other components and implementation errors are paid as critical-norm remainders.

This permits an acyclic choice: waiting/error budgets first, shear actions next, and very short native pulse durations last. The final endpoint is small in a critical Fourier norm, not merely in L2. The argument does not replace nonlinear waiting periods by literal heat: their heat-reference discrepancies are explicitly paid.

## Read in this order

1. `fixed_actuator_universal_return_20261109/PROOF_CANDIDATE.md`: governing full construction, quantifiers, error allocation, pulse implementation and resource ledger.
2. `fixed_actuator_universal_return_20261109/H3_BALL_EXTENSION.md`: separate extension from smooth inputs to the complete closed H3 ball, with its own narrow coordinated review at `fixed_actuator_heat_sandwich_audit_20261109/H3_BALL_EXTENSION_REVIEW.md`.
3. `fixed_actuator_heat_sandwich_audit_20261109/END_TO_END_CHALLENGE.md`: final analytic challenge of that exact version and its physical-L6 dependency. `END_TO_END_BINDINGS.json` records the reviewed source hashes.
4. `fluid_uniform_spectral_edge_20261109/PHYSICAL_LP_CANDIDATE.md`: the new fixed-fiber physical-L6 operation. Its scope is not three-dimensional L6-to-L6 boundedness or a viscous maximum principle.
5. `controlled_fluid_fixed_actuator_20261109/JOST_DIRECT_RECURRENCE_REPAIR.md` together with Sections 1–3 of that directory's `PROOF_CANDIDATE.md`: exact chain, bond moments and repaired Jost recurrence. The earlier `JOST_CONSTANT_LEDGER.md` is preserved as **superseded history**, not the governing recurrence.
6. `fixed_actuator_critical_heat_bridge_20261109/L6_BACKGROUND_NATIVE_FILTER.md`, `STRONG_ENDPOINT_RESET.md`, and `NATIVE_HEAT_REFERENCE.md`: actual nonlinear filter, strong endpoint reset and paid heat comparison. The earlier interface notes supply supporting estimates, not an assumed unproved viscous theorem.
7. `fixed_actuator_l6_filter_challenge_20261109/REVIEW.md` and the two scoped physical-Lp reviews: narrower analytic challenges. `SANDWICH_ADMISSION_SCREEN.md` preserves the failed generic H3-based allocation instead of silently erasing it.
8. `REFERENCE_GUIDE.md` and the inherited 8EB/BCA/2B5 response excerpts: source credit, inherited native short-pulse/global-continuation interfaces, and the prior growing-frequency robust controller.

The auxiliary uniform-beta dispersion candidate in the spectral directory is included for its Jost/Volterra background. **Its proposed improved dispersion rate is not required by the full controller**, which uses the earlier polynomial-beta estimate and the active-sector rate S^(-1/13). Older documents saying that the full endpoint was open retain their historical date and scope; the new governing file above is the assembled candidate.

## Audit status

The end-to-end challenge reports no concrete counterexample, circular dependency, missing critical-continuation step, or mismatched inherited hypothesis at the stated scope. It rechecks the physical-space Jost synthesis and full-circle reconstruction, including the same-half-line ordering issue. That is a mathematical review, not merely agreement of scalar arithmetic.

The reviews were coordinated within the same research effort. The final reviewer had also examined the physical-Lp candidate earlier. **They are not fresh blind replications, external peer review, independent PDE implementations or exhaustive reproofs of every inherited source.** Standard Jacobi spectral/scattering and Riesz-projection results remain cited inputs. Known Koch–Tataru/heat-smoothing methods and the earlier Astra control constructions are credited explicitly.

The separate H3 extension also received a narrow source-bound review, which found no blocker in the approximation, strong stability, regularity, quantifiers or unchanged-resource argument, conditional on the governing smooth-data result. Its exponential stability factor is a proof-only constant, not an additional controller or synthesis resource. This review is not a second independent validation of the full theorem. `H3_EXTENSION_BINDING.json` records the exact extension and review hashes.

No external novelty or priority judgment, practical device validation, unforced arbitrary-data Navier–Stokes result, or numerical confidence/impact score is claimed.

## What was actually run

The preserved candidate evidence records one frozen source-only qualification:

- 33/33 checks passed: compiler syntax, exact rational calibration/error allocations, unit-action and C2 pulse identities, and the symbolic resource-degree ledger.
- The original run recorded 0.079183 seconds for the whole child process and 11,448 KiB. These are provenance for that small bookkeeping run, **not** a compiler, PDE or scientific-performance benchmark.
- The separate audit preserves eight exact scalar assertions and its degree ledger. The local-filter review preserves ten scalar reserve checks. These narrow checks do not certify the infinite-dimensional theorem.

During packaging, only file existence, hashes, dependency resolution, Python syntax parsing, ZIP integrity and extracted-content verification were checked. The original scientific checks were not rerun. See `PACKAGING_CHECKS.json` and the verification receipt in `verification/`.

**Not run:** full giant coefficient synthesis, a PDE evolution, a scattering/spectral propagation, a parameter search or fit, a physical calibration experiment, a hardware trial, or a proof-assistant formalization. No output file containing the full generated programme is included.

## Verify and reproduce safely

Requirements: Python 3.10 or newer; standard library only. No downloads, installation, credentials or network access are required for the included utilities.

From the extracted package root:

    python3 verify_package.py

This verifies the archive's file list, SHA-256 hashes, included-source provenance and binding resolution. It does not execute the compiler or scientific checks. On systems with GNU coreutils, `sha256sum -c MANIFEST.sha256` is an additional transport-integrity check.

To replay only the two small scalar/source scripts, when desired:

    python3 replay_scalar_checks.py

The replay helper copies the needed files into a temporary directory before running them, enforces a three-second timeout per child, and compares results with the preserved evidence. It never imports or calls `synthesize.build`, never overwrites the frozen evidence, and does not run the historical path-obstruction checks. The helper itself was syntax-checked during packaging but was not executed as a new scientific replay.

The compiler source is included for inspection. Its documented command is

    python3 -X int_max_str_digits=0 \
      fixed_actuator_universal_return_20261109/synthesize.py \
      --nu 1 --K 1 --output ../programme.json

**This is a specification example, not a reported completed run or a recommendation to run it casually.** Even these inputs lead to immense integers. The compiler has no resource/time safety guard. The digit-limit option is relevant to Python versions that enforce that limit. Its rational outputs are serialized in binary. The source returns local normalized-coordinate polynomial coefficients; the proof separately bounds expansion into global time.

## Provenance, excerpts and completeness

The governing candidate, separate H3 extension, physical-L6 proof, direct recurrence repair, three native bridge proofs, and final end-to-end challenge are byte-for-byte copies. Original source files were not modified. `SOURCE_PROVENANCE.json` distinguishes every verbatim copy from every labeled excerpt and records both original and packaged hashes. `DEPENDENCY_RESOLUTION.json` resolves every file in the candidate's dependency inventory, the audit inventories, the completed-review bindings and the separate H3 extension/review binding, including the excerpts.

The inherited 8EB/BCA/2B5 captures include their complete mathematical responses, but omit preceding prompts/activity captures. The current polynomial Jacobi derivation is reproduced as a labeled mathematical excerpt without introductory assessment/score commentary or closing workflow commentary. One non-mathematical allocation paragraph is omitted from the auxiliary uniform-beta proof. These changes do not silently masquerade as matching the original hashes. Historical binding files continue to identify their original sources; use the resolution map to locate the packaged excerpt. An excerpt's hash cannot authenticate text that was not included.

External papers, monographs and the full remote research repository are **not bundled**. Their exact known URLs, versions and relevant sections are identified in `REFERENCE_GUIDE.md` and source files. The current N1777 snapshot and its Git blob identity are included; a Git blob is not a commit permalink. Remote sources were not freshly fetched during packaging, and remote availability/access is not guaranteed.

The package is a research snapshot, not a self-contained formal proof library. SHA-256 and ZIP checks establish byte integrity, not mathematical truth. No rights or license in third-party source material are asserted or changed by this package.
