# Repeated cyclic words: phase extraction controls every return path

Date: 2026-11-09. Status: constructive obstruction with an explicit, very weak rate; not a negative theorem for general fixed-actuator stabilization.

## 0. Main result

Let L>=3 be fixed. Take the cyclic prefix of length L of the nominal pairs

    (e1,e2), (e2,e3), (e3,e1), (e1,e2), ... .

Let every action before the last satisfy s_j>=1; the last action may be any nonnegative number. Allow independent static phase, gain, and transverse-direction error on each pulse, as in the prescribed contract.

There is one fixed real smooth initial field u0 with ||u0||H3<1 such that, for every such action list, one can choose admissible errors |e_j|<=1/1024, gains equal to 1, and static phases for which

    Fminus1(U_L ... U_1 u0) >= 2^(-E_(L-1)).             (A)

The explicit integer E_J defined below is O(J*1024^J), independent of all actions. This extends the earlier one-pass obstruction to any fixed number of repeated cycles. All paths that leave a Fourier cube and return are included. They are not discarded, assumed small, or replaced by a projected evolution.

The crucial representation is the Fourier series in the independent pulse phases. A specified frequency trajectory is one coefficient of that series. Other trajectories cannot cancel that coefficient. This proves that at least one allowed phase choice retains its amplitude.

The floor is astronomically small and degrades extremely rapidly with the pulse count. It does not prevent a programme whose number of pulses grows with the input. It does not obstruct genuinely dissipative resets or prove failure of later stabilization. The actions-bounded-below hypothesis is part of (A); no theorem for every action list with vanishing pulses is claimed.

The one-cycle frequency pattern came from a collaborator. The extension through repeated coordinate visits, uniform two-polarization block bound, phase-coefficient argument, and rate accounting are derived here. No external priority claim is made.

## 1. A calibrated trajectory through an arbitrary cyclic prefix

Put

    m=1024, tau=2^-12, J=L-1,
    u0(x)=2^-10 e2 cos(2 pi x3),
    k_0=(0,0,1).

As before, ||u0||H3^2<65^3/2^21<1.

For j=1,...,J, let i=1+((j-1) mod 3), and obtain k_j from k_(j-1) by replacing its i-th coordinate by m^j. Write

    d_j = (k_j)_i - (k_(j-1))_i.

Then d_1=m, d_2=m^2, and d_j=m^j-m^(j-3) for j>=3. Every d_j is positive. In particular

    d_j<=m^j,   sum_j d_j<2m^J,   |k_J|<2m^J.          (B)

Indices of coordinate vectors below are taken cyclically modulo 3. On the first pulse, choose

    e_1 = [tau/(2 pi s_1)] e3.

On pulse j=2,...,J, choose

    e_j = [-1/m + tau/(2 pi s_j m^(j-1))] e_(i+2).

The other two coordinates at the start of such a pulse are exactly

    (k_(j-1))_(i+1)=m^(j-2),
    (k_(j-1))_(i+2)=m^(j-1).

Hence every selected transition has exactly the same effective time:

    2 pi s_j (a_j+e_j).k_(j-1)=tau.                  (C)

All errors are transverse to p_j. Since s_j>=1, their norms are at most 1/m. The first error is smaller than tau/6<1/m; later errors lie strictly between -1/m and 0 along one transverse coordinate.

On the final pulse j=L, use e_L=-(1/m)e_(i+2). Its coupling vanishes on the entire transverse fiber through k_J. Thus U_L is exactly the identity on that fiber, regardless of its action or phase. We set k_L=k_J.

This is a fixed static error on each pulse. Dependence of the selected adversarial errors on the prescribed action list is legitimate in a claim quantified over all admitted calibrations. The initial field is fixed independently of that list.

## 2. Uniform lower bound for each native velocity block

For a coordinate shear, the Fourier block from an input longitudinal index n to an output index n+d has two orthonormal velocity polarizations. Its singular values are the moduli of the free Jacobi entry and the in-plane J_beta entry. The transverse magnitude is beta>=1. The in-plane bonds are

    a_r = [beta^2+r(r+1)] /
          [2 sqrt((beta^2+r^2)(beta^2+(r+1)^2))].

Every selected trajectory has n>=0 and d>=1. Put w_r=2a_r and c_r=1-w_r^2. For r>=0,

    0<c_r<=1/2,
    c_r=beta^2/[(beta^2+r^2)(beta^2+(r+1)^2)]
        <=beta^2/(beta^2+r^2)^2.

A decreasing-integrand comparison gives, uniformly for beta>=1,

    sum_(r>=0)c_r
       <=1/beta^2 + integral_0^infinity beta^2/(beta^2+x^2)^2 dx
       =1/beta^2 + pi/(4beta) <2.

Since log(w_r)>=-c_r, every positive-index bond product satisfies

    product_(r=n)^(n+d-1) w_r >exp(-2)>1/8.           (D)

This is an elementary uniform bound, not an imported Jost or dispersive estimate.

For a zero-diagonal Jacobi chain with bonds at most 1/2, the shortest walk of length d has leading coefficient

    i^d tau^d/d! * product_(r=n)^(n+d-1)a_r.

Walks of length d+2h number binom(d+2h,h). If the product is at least c*2^-d, their total relative absolute remainder is bounded by

    c^-1 [exp(tau^2/[4(d+1)])-1].                   (E)

This follows directly from the norm-convergent exponential series and the inequality d!/(d+h)!<=(d+1)^(-h).

For the in-plane chain take c=1/8 using (D); for the free chain c=1. With tau=2^-12, the right side of (E) is less than 1/2 in either case. Therefore the physical block B_j, restricted from the divergence-free plane at k_(j-1) to the divergence-free plane at k_j, obeys

    sigma_min(B_j) >= kappa_(d_j),
    kappa_d = (tau/2)^d/(16 d!).                   (F)

The bases on the input and output planes need not agree between stages. Minimum singular values still multiply, so no polarization alignment or accidental annihilation can spoil

    ||B_J ... B_1 v|| >= product_j kappa_(d_j) ||v||.

This explicitly keeps both native Leray polarizations.

## 3. Independent phase variables separate all trajectories

Let phi_j be the phase of pulse j. The phase gauge for a shear with coordinate p_j is exact:

    [U_j(phi_j)]_(k',k)
       = exp(i ((k'-k).p_j) phi_j) [U_j(0)]_(k',k)

whenever k'-k is parallel to p_j, with a harmless simultaneous sign change if the opposite Fourier convention is used.

Consider the target vector coefficient

    F(phi_1,...,phi_J)
       = [U_L U_J(phi_J)...U_1(phi_1)u0]hat(k_J).

This is a continuous vector-valued function of the phase torus. Extract its Fourier coefficient at the increment list (d_1,...,d_J). Starting from a given initial Fourier mode, that list fixes every intermediate frequency exactly. Thus its coefficient is

    C = 2^-11 B_J ... B_1 e2.                       (G)

The negative Fourier mode of the real initial cosine cannot contribute to this same phase coefficient at the same target: the fixed increment list would instead end at k_J-2e3. The final resonant pulse cannot repair that difference.

All other paths, including arbitrary excursions outside and returns into every proposed cutoff cube, are present in F. They have different increment lists and hence different phase harmonics. They do not contribute to C.

No absolute summability over trajectories is required for this extraction. Each U_j(phi_j) is a bounded unitary on divergence-free L2 and depends strongly continuously on its phase. Integrating its matrix elements over one phase selects the exact prescribed frequency shift. Iterating these bounded integrals proves (G) directly. This avoids an unjustified interchange of an infinite path sum.

By the triangle inequality for the normalized phase integral,

    sup_phi ||F(phi)|| >= ||C||.

Equivalently, Parseval gives an average squared norm at least ||C||^2. Consequently at least one admissible static phase tuple satisfies

    ||F(phi)|| >= 2^-11 product_j kappa_(d_j).        (H)

The phase tuple is proved to exist; it was not numerically optimized or represented as an exact real oracle. Existence suffices to refute a guarantee required for every phase tuple. Independence of phases from pulse to pulse is essential to this argument and is expressly allowed in the target contract.

## 4. Explicit floor and pulse-count consequence

Since 2 pi |k_J|<16m^J, (F) and (H) imply

    Fminus1(U_L...U_1u0)
       >= 2^(-15-14J) * 2^[-13 sum_j d_j] / product_j d_j!.

Using d_j!<=d_j^(d_j)<=2^(10j d_j), define

    E_J = 15+14J + sum_(j=1)^J (13+10j)d_j.          (I)

Then (A) follows. Moreover,

    E_J <=15+14J+(26+20J)m^J
         <=64(J+1)m^J,       J>=2.                 (J)

For one cycle, J=2 and E_2=34626603. This is four bits weaker than the sharper earlier one-cycle calculation because the common block bound here deliberately treats both polarizations uniformly at every stage.

The same selected coefficient also gives a homogeneous H^-1 lower bound 2^(-E_J). For the heat norm

    Hcal(f)^2=integral_0^infinity ||exp(t Delta)f||infinity^2 dt,

one Fourier coefficient yields Hcal(f)>=|fhat(k)|/(sqrt(8) pi|k|). Thus the constructed output has Hcal at least 2^(-E_J)/sqrt(2). Changing from Fminus1 to these norms does not eliminate the fixed-word obstruction.

If a cyclic programme with J+1 pulses were to guarantee Fminus1<epsilon uniformly over all admissible phases/errors and all H3<=1 inputs, with epsilon in (0,1), it would necessarily have

    log2(1/epsilon) <= E_J,

and therefore, by (J),

    11J+6 >= log2(log2(1/epsilon)).                 (K)

This is only a necessary lower bound. No matching decay upper bound or sufficient pulse count is proved. It grows like log log(1/epsilon), which is fully compatible with polynomial output length in the input bit length. It creates no full resource impossibility.

In particular, a bounded repetition count cannot be repaired solely by choosing larger actions within the regime covered here. Allowing the repetition count to grow remains a real possibility.

## 5. Consequence for a native near-inviscid pulse implementation

Suppose a native nonlinear/viscous implementation of this word has been independently certified to differ from the calibrated inviscid word by at most nu/256 in H1. The usual lattice bound transfers that error to Fminus1. When nu<=2^(-E_J), the constructed calibration/phases then give

    Fminus1(u_actual(T0)) >=2^(-E_J)-nu/256>nu/4.

Thus a short-pulse argument whose final step is uniform entry into that sufficient critical-Fourier region cannot use a fixed repetition count and arbitrarily large actions to handle every positive nu at this fixed error radius.

This is not a demonstration that the actual native solution blows up or misses its later terminal H1 target. Genuine dissipation may erase the high-frequency witness; a different continuation criterion may apply; a longer word may change the floor. Nor does this statement supply the native approximation bound for an arbitrary new long word. That bound must be paid separately.

## 6. Where the constructive frequency-growth strategy still stands

The geometric idea is correct in one restricted sense: a trajectory kept near successive nominal resonances can be forced to larger coordinate ratios. The obstruction uses precisely that growth. It also shows why growth alone does not establish uniform arbitrary-precision evacuation: a bounded-length trajectory still ends at one finite frequency, and independent phase choices protect a nonzero coefficient there.

For an input-dependent longer word, this calculation provides only a microscopic floor. A constructive theorem would still need an upper bound on the aggregate return amplitudes, or a legitimate dissipative reset between blocks, with the full H3 and bit/physical costs. Exact cube-projection insertion remains false after coordinates are revisited. The phase representation solves the cancellation problem for a lower bound; it does not bound all return paths from above.

The other open avenue is a genuinely viscous contraction or a native decomposition into a controlled regular background and small critical remainder. Nothing here proves that impossible.

## 7. Source and execution record

The proof uses the exact coordinate-shear Leray decomposition already checked in the frozen candidate, elementary nearest-neighbor matrix powers, Fourier phase gauges, and bounded Hilbert-space integrals. It does not depend on a new uniform-beta dispersive theorem or on the old quantitative Jost constant.

Primary material checked during this investigation:

- NIST DLMF 10.2.2 and 10.12.1, for the free-chain Bessel series/generating function: https://dlmf.nist.gov/10.2.E2 and https://dlmf.nist.gov/10.12.E1.
- Egorova–Holzleitner–Teschl, arXiv:1506.06555v2, Theorem 1.1 and the Jacobi convention: https://arxiv.org/html/1506.06555. Its large-effective-time dispersion is not contradicted: all selected effective times here remain tau.

No cited source is claimed to contain this repeated-word obstruction. No comprehensive external novelty search was performed.

`check_path_bounds.py` checks the integer trajectory, rational calibration admission, final resonance, relative Taylor-tail budget, and exponent formulas for several lengths. Output is `EXACT_CHECK.json`. These finite checks are bookkeeping, not the proof for all lengths. No phase search, Fourier/PDE propagation, enormous denominator expansion, or physical test was performed. Earlier proof packets were not changed.
