# Exact escape of the all-weak branch, and the remaining strong-branch barrier

Date: 2026-11-09. This is a positive operator lemma and an exact reduction. It is not a full repeated-word mixing theorem.

## 1. Weak sectors lie in a narrow coordinate cone

Use the cyclic actuators (p,a)=(e_i,e_(i+1)), with coordinate indices taken modulo 3. Let

    v=theta(a+e),   theta in [1/2,2],
    e.p=0,   |e|<=rho=1/1024.

On a transverse fiber xi, put beta=|xi|. Define W to be the Fourier projection onto

    |v.xi| <= beta/2048.                            (1)

The zero-transverse fiber is included. W depends only on unchanged transverse coordinates, so it commutes with the full native inviscid shear U, for every action and phase.

Write x=k_(i+1), y=k_(i+2). Since theta>=1/2, (1) implies |(a+e).xi|<=rho beta. Hence

    |x| <= |e.xi| + |(a+e).xi|
         <=2rho beta <=2rho(|x|+|y|),

and therefore every weak fiber lies in the cone

    |x| <= |y|/511.                                 (2)

Let A_j=U_j W_j. Each A_j is an L2 contraction and preserves the mean-zero subspace.

## 2. Exact all-weak Fourier escape

For every cyclic prefix length L>=3, all choices of actions, phases, and admitted calibrations satisfy

    supp Fourier(A_L ... A_1 f)
       subset {k: |k|infinity >=511^(L-2)}           (3)

for every mean-zero f in L2. In particular,

    ||A_L ... A_1||_(L2 -> Hdot^-1)
       <= 1/[2 pi * 511^(L-2)].                    (4)

The bound is uniform in the actions, including zero actions. No H3 bound or finite input support is required.

Proof of support: consider any trajectory with nonzero matrix coefficients in the product. Each stage changes only its p coordinate; before that change the two other coordinates obey (2). Let a_j be the absolute value of the coordinate just changed at stage j. From the cone condition before stage j+2,

    a_(j+1) >=511 a_j.

If the initial k3 is nonzero, the cone before stage 2 gives a_1>=511|k3|>=511. Thus a_(L-1)>=511^(L-1).

If initial k3=0, the first cone forces initial k2=0. The initial mean-zero frequency must then have k1 nonzero. Stage 1 has zero transverse frequency, so the shear is exactly the identity and a_1=|k1|>=1. Thus a_(L-1)>=511^(L-2).

The final stage does not change the coordinate written at stage L-1. This proves (3). The same argument works for any cyclic starting coordinate after relabeling axes. Operator Fourier support follows by applying these frequency-selection relations to finite Fourier inputs and passing to L2 limits. It does not require absolute summation over paths. Unitarity/contraction and the homogeneous Fourier weight give (4).

This includes all excursions and returns of the all-weak branch. Such a branch cannot return to a fixed low cube after enough stages; its support is forbidden there, not merely small.

## 3. Exact full-word decomposition

Put B_j=U_j(I-W_j), so U_j=A_j+B_j. Splitting according to the final strong-coupling occurrence gives the exact identity

    U_L...U_1 = A_L...A_1
      + sum_(j=1)^L A_L...A_(j+1) B_j U_(j-1)...U_1. (5)

There are L+1 terms, not an uncontrolled 2^L expansion. Every omitted suffix or prefix is interpreted as the identity.

If a term has at least r>=3 weak stages after its final strong stage, (4) bounds it by 1/[2 pi *511^(r-2)] from L2 to Hdot^-1. Summing all such terms is a geometric series. Thus strong occurrences far before the endpoint are paid by the subsequent weak escape.

The unresolved terms are the ones whose last strong stage is near the endpoint. Their incoming fields are arbitrary outputs of the preceding word. A one-shear H1-to-H^-1 dispersive theorem applies only after those incoming H1 costs are explicitly controlled. This calculation supplies no such bound.

## 4. Why an L2 replacement is false

One cannot repair the gap by claiming that a large-action strong shear is small from L2 to Hdot^-1. Take the active transverse frequency xi=a, which has beta=1. Its actual coupling has magnitude at least (1-rho)/2>1/2048, so it belongs to the strong part. Choose a normalized divergence-free output supported at the frequency k=a. Its inverse image under the same shear has L2 norm 1 and remains in that strong transverse sector. Applying B returns the prescribed unit low mode.

Consequently, for every action,

    ||B||_(L2 -> Hdot^-1) >=1/(2 pi).                (6)

This is an actual operator counterexample, not failure of a particular upper bound. The inverse image may have a costly H1/H3 norm; exploiting that fact is precisely what a successful whole-word argument would need to pay.

## 5. Relationship to the repeated-word floor

The adversarial trajectory in REPEATED_WORD_PHASE_FLOOR.md remains weak on its selected fibers, travels to frequencies of order 1024^L, and ends at a fixed high mode for each fixed L. Its tiny nonzero coefficient is consistent with the exponentially decaying upper bound (4). That floor prevents arbitrary-precision evacuation at bounded L, but does not refute the all-weak escape lemma or a possible longer-word theorem.

The full nonlinear controller is not obtained by combining (4) with a formal strong-sector dispersive estimate. The unresolved late-strong terms, native H3 growth, and synthesis/physical resources remain essential. A genuine dissipative reset could supply a different interface, but is not asserted here.
