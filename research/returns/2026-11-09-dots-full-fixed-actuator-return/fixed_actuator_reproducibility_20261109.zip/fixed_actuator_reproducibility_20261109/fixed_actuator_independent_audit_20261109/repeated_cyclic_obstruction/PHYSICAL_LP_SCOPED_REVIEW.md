# Scoped review of the single-shear physical Lp candidate

Date: 2026-11-09. This is a mathematical/source challenge, not a numerical propagation or nonlinear theorem certification.

Inspected: `fluid_uniform_spectral_edge_20261109/PHYSICAL_LP_CANDIDATE.md`, SHA256 `6b4ddd9328498adafa0774102cfbde188a2c9cea09574ea9a3fc775a3f6f2923`.

No concrete blocker was found in the claimed action-uniform one-shear H3-to-Lp estimate.

1. Subtracting the corrected Q_r recurrence at n+1 from its value at n gives exactly the displayed nonnegative difference. A_n increases with n, so A_n^-1 decreases. Each coefficient of d_n is therefore nonnegative and decreasing on the own half-line.

2. At z=1, the future-directed Volterra expansion is bounded by the product of (1+(m+1)c_m). Every ordered chain is a subset term of that product after enlarging its positive factors. This supplies the proposed exp(21) bound for g_0 and hence exp(42) for d_0 after normalization. The fixed coefficient budget is used explicitly; it is not an unquantified spectral constant.

3. A decreasing nonnegative one-sided multiplier is a positive combination of finite interval projections and its limiting half-line projection. Total mass equals its initial coefficient. Modulation is an Lp isometry. The resulting operator-norm sum for Jost synthesis converges by the coefficient mass bound. Using the dual exponent for its adjoint preserves the same stated O(p) bound for p>=2.

4. The EHT primary full-circle kernel and same-sign scattering relation were reread directly at https://arxiv.org/html/1506.06555, equations (3.2)–(3.3) and the same-sign formula following the case split in Section 3. For same-side indices the free term is an integral of f_n(theta) f_k(-theta) times exp(-it cos(theta)). Swapping the indices and changing theta to -theta leaves that integral unchanged. The reflection term is symmetric in n,k without that substitution. Therefore the same-side factorization does apply across both index triangles; no triangular truncation has been smuggled into the Lp bound.

5. Opposite-side blocks use only own-half-line Jost factors and the bounded transmission coefficient. The scattering factors act by multiplication in the physical spectral circle and require their supremum bounds, not a derivative or Wiener inverse bound. Reflections and Fourier half-line projections have the paid Lp bounds.

6. The native polarization multipliers beta/sqrt(beta^2+n^2) and n/sqrt(beta^2+n^2) have uniformly bounded variation on their frequency half-lines. Extraction/reconstruction therefore have the stated O(p) cost with large constant slack. Minkowski followed by transverse Cauchy–Schwarz with sum |xi|^-4 in two dimensions genuinely gives H3-to-Lp in all three variables. It does not give a three-dimensional Lp-to-Lp theorem.

7. The optional logarithmic L-infinity consequence is consistent with the ball-around-a-maximum interpolation and the accepted cubic H3 envelope. It is still a single-shear inviscid conclusion.

The standard Riesz projection estimate remains an explicitly cited classical input. This review did not retrieve a publisher page already reported inaccessible. No assertion of a new primary full-text read for that theorem is made.

Scope retained: this does not justify multiplying fixed constants over arbitrarily many Trotter steps, an actual viscous Lp bound, a full repeated-word Lp estimate, or a calibrated nonlinear controller. In particular, the strong-branch incoming regularity problem in WEAK_BRANCH_ESCAPE.md remains open.
