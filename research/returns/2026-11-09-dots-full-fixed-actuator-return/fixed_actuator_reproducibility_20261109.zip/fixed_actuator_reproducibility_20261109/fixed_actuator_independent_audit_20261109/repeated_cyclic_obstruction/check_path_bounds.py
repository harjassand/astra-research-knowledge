from fractions import Fraction as F
from pathlib import Path
import json

m=1024
tau=F(1,4096)
rho=F(1,m)
rows=[]
for L in (3,4,6,9,12,30):
    J=L-1
    k=[0,0,1]
    ds=[]
    for j in range(1,J+1):
        i=(j-1)%3
        nominal=(i+1)%3
        error=(i+2)%3
        if j==1:
            assert k[nominal]==0 and k[error]==1
            assert tau/6 < rho
        else:
            assert k[nominal]==m**(j-2)
            assert k[error]==m**(j-1)
            assert F(k[nominal],k[error])==rho
            assert 0 < tau/(6*k[error]) < rho
        d=m**j-k[i]
        assert 1 <= d <= m**j
        ds.append(d)
        k[i]=m**j
    final_i=(L-1)%3
    assert F(k[(final_i+1)%3])-rho*k[(final_i+2)%3]==0
    assert sum(k)<2*m**J
    assert sum(ds)<2*m**J
    # Uniform positive-chain bound c=1/8, exp(x)-1<=2x.
    tail_uppers=[16*tau*tau/(4*(d+1)) for d in ds]
    assert max(tail_uppers)<F(1,2)
    E=15+14*J+sum((13+10*j)*d for j,d in enumerate(ds,start=1))
    E_upper=15+14*J+(26+20*J)*m**J
    assert E<=E_upper
    rows.append({'pulses':L,'max_frequency':str(m**J),'target':list(map(str,k)),
                 'floor_is_2_to_minus_E':str(E),'coarse_E_upper':str(E_upper),
                 'maximum_relative_tail_upper':str(max(tail_uppers))})
assert rows[0]['floor_is_2_to_minus_E']=='34626603'
out={'checks':rows,
     'scope':'Integer/rational path, calibration, Taylor-budget, and exponent checks. No Fourier evolution, PDE run, phase optimizer, or huge denominator expansion.',
     'all_passed':True}
p=Path(__file__).with_name('EXACT_CHECK.json')
p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
