# Fixed spatial frequencies with a paid, shrinking angle tolerance

Date: 2026-11-09. Status: constructive theorem candidate, with the dependencies and narrow independent checks stated below. No fluid evolution or practical controller experiment is reported.

## 0. Exact claim and inherited capital

On the unit three-torus retain the native equation

    u_t + P[(u.grad)u] = nu Delta u + P[(b.grad)u].

Here P is the orthogonal Leray projection, nu>0 is rational, initial velocities are smooth, divergence-free, mean zero, and have inhomogeneous H3 norm at most rational K>=1. The same prescribed programme must cover the entire initial ball.

Use exactly three fixed nominal shear pairs, in this order:

    (p1,a1)=(e1,e2), (p2,a2)=(e2,e3), (p3,a3)=(e3,e1).

During each pulse the actual driver may have arbitrary static phase, gain theta_j in [1/2,2], and a static transverse direction error e_j perpendicular to p_j. The construction below first treats e_j=0, then gives an explicit rational tolerance rho(nu,K)>0 for |e_j|<=rho. Its reciprocal is polynomial in 2+K+nu+nu^-1. It is NOT the fixed universal tolerance 1/1024 in the stronger 2B5 question.

The synthesis outputs rational C2 piecewise-polynomial pulse envelopes, a common rational H3 bound M, and rational T with ||u(T)||H1<=nu/4. Numerical resources are bounded by one fixed computable polynomial of 2+K+nu+nu^-1. Synthesis bit work and output height/length are bounded by a fixed polynomial in the full binary input length. The constants and degrees are enormous; no practical actuation or calibration advantage is asserted.

Dependencies, rather than newly claimed general results:

1. Accepted Astra 8EB/BCA supplies the torus critical-Fourier continuation and the explicit nilpotent H3 shear hierarchy. The inherited, pinned source files are in sources/. We use the native velocity equation, not a scalar convection surrogate.
2. The repaired quantitative fundamental-Jacobi derivation is in the collaborator's controlled_fluid_fixed_actuator_20261109/PROOF_CANDIDATE.md, Section 3, together with JOST_DIRECT_RECURRENCE_REPAIR.md. Its source-based conclusion used here is

       ||exp(it J_beta)||l1->linfty <= Q beta^8 |t|^(-1/3),
       Q=2^2700, beta>=1.

   Both fundamental velocity polarizations obey this envelope. The direct b=0 recurrence repair, threshold flux, and inverse-Wronskian accounting received a narrow source/algebra challenge, not a numerical scattering replay. No enhanced-dissipation or collaborator nonlinear theorem is imported.
3. The action-uniform norms and exact assembly below are proved in our PROOF_CANDIDATE.md Sections 2 and 4. This document replaces its unbounded search and exponential resource allocation, without altering those historical bytes.

## 1. Two useful action-uniform bounds

Define Fminus1(f)=sum_(k!=0)|fhat(k)|/(2*pi*|k|), with Euclidean vector coefficients. For any fundamental coordinate shear group U and any action, gain and phase,

    Fminus1(U f) <= ||f||H1.                         (1)

This follows by fiber unitarity, longitudinal Cauchy-Schwarz, and transverse square-shell summation. The two squared shell bounds are 4/9 and 1/9, strictly below one in total. It is not an Fminus1-to-Fminus1 estimate. The same lattice argument with U=I also applies to a general H1 error.

Let P0 project onto k1=0. Since output longitudinal index zero has the minimum Sobolev weight on its fiber,

    ||P0 U1 f||Hr <= ||f||Hr, r>=0.                 (2)

These are infinite-ball bounds, including all longitudinal modes and both Leray polarizations.

## 2. A closed rational action factory

For rational M>=1 and eps>0 set

    a = 2 + M/eps,
    R = ceil(4a),
    L = ceil([8(2R+1)a]^2),
    din = 3(2R+1)^3,
    dout = 3(2R+1)^2(2L+1),
    W = 1+8(L+2R),
    tau = 1/[16 a din dout W],
    S(M,eps) = ceil([8 Q (2R)^8/tau]^3).           (3)

All expressions are rational/integer arithmetic. No matrix exponential, gain grid, spectral search, PDE call, or unencoded real number is used in this synthesis.

The resulting action pays either of the maps

    Fminus1(U(S) Q_a f) < eps,
    ||P0 U1(S)(I-R0) f||H1 < eps,                 (4)

uniformly on ||f||H3<=M. Here Q_a selects the active integer modes a.k!=0; R0 projects onto k2=0 in the second map. Unknown gain theta in [1/2,2] and arbitrary static phase are included.

Proof of (4). The input outside the cube |k_i|<=R has H1 norm <=M/[1+4*pi^2(R+1)^2]. Bounds (1)-(2) make its contribution <eps/8. On the remaining transverse fibers, cutting the longitudinal output at L costs at most (2R+1)M/sqrt(L)<=eps/8 for the first map. The plane map has no longitudinal output tail.

On any retained active fiber beta<=2R and |a.xi|>=1. Actual Jacobi time is |2*pi*theta*(a.xi)S|>=S. Expanding the two orthonormal polarizations gives the physical vector-block entry bound

    2 Q (2R)^8 S^(-1/3) <= tau/4.

Every relevant H1 output weight and every inverse Fourier weight is below W. Summing all din*dout component entries costs at most M din dout W tau/4<=eps/64. These deliberately excessive dimensional bounds also cover Euclidean-to-component conversions. The sum of all errors is strictly below eps. Phase changes are diagonal gauges, so do not alter the coefficient magnitudes. The original source-check script incorrectly tested equality here; its stopped run and the original prose are preserved under historical/. Correcting that equality to an inequality only weakens the diagnostic to the actual stated budget and changes no scientific input or constant.

For explicit resource bookkeeping, a>=2 implies

    R<=5a, L<=7745a^4, din<=2^12 a^3,
    dout<=2^23 a^6, W<=2^16 a^4,
    tau^-1<=2^55 a^14, S(M,eps)<=2^8371 a^66.     (5)

Thus (3) is a polynomial resource factory, not merely an eventual-decay argument.

## 3. Three-stage exact-direction evacuation

Set eps=min(nu,1)/256, and S1=S2=S(K,eps). For every Sj put

    Lj=(1+2^29 Sj)^3, bj=2Lj.                     (6)

The generous coefficient covers |theta(a+e)|_1<=4 whenever |e|<=1/2 and theta<=2. For exact direction, the accepted triangular hierarchy gives both H3 and H1 linear propagator norms <=bj on every partial pulse. The H1 statement is the same hierarchy restricted to derivative orders zero and one; using the larger H3 envelope is conservative.

Define Mstar=b2*b1*K, S3=S(Mstar,eps), and then L3,b3 by (6).

The identity

    P0 U2 U1 f = U2 P0 R0 f + U2 P0 U1(I-R0)f

uses that U2 commutes with P0 and U1 fixes R0. The second term has Fminus1<eps by (1) and the plane estimate. The first is an active U2 evolution of a k3-axis input of H3 norm <=K, so it also contributes <eps. The remaining Q0=I-P0 component has H3 norm <=Mstar, and U3 evacuates it with error <eps. Finally U3 fixes P0 exactly. Hence

    sup_(||f||H3<=K) Fminus1(U3 U2 U1 f) <3eps.   (7)

No Fminus1 amplification bound, heat-only interval, assumed return suppression, or smallness of intermediate H3 norms appears. The exact direction identities in this paragraph must not be used for a fixed transverse error.

## 4. Native nonlinear and viscous pulses

Let C0=2^20, M0=K, Mj=4Lj M_(j-1). Choose each positive rational duration as the minimum of the following positive rational upper bounds:

    1/3,
    1/[32 C0 Lj^2 M_(j-1)],
    eps/[3 bj (nu Mj + C0 Mj^2) product_(l>j) bl],
    1/[24 Mj].                                   (8)

The BCA differentiated energy hierarchy, with native viscosity nonpositive, gives actual H3<=Mj throughout pulse j. It also supplies existence/continuation through the controlled intervals without presupposing global regularity. This bound is uniform over the enlarged transverse-error class |e|<=1/2, although the nominal evacuation is not.

The pulses are adjacent, without a free gap. On the j-th interval starting at tj, use

    fj(t)=(Sj/deltaj) 140 r^3(1-r)^3,
    r=(t-tj)/deltaj,

and zero elsewhere. The envelope is rational-polynomial, has area Sj, and joins globally C2. All derivatives of order <=2 vanish at its endpoints.

For exact directions, Duhamel in H1 against the inviscid shear gives error

    ||u_j-U_j u_(j-1)||H1
       <=deltaj bj(nu Mj+C0 Mj^2).

The H1 nonlinear product estimate with C0 follows from the same elementary torus product/embedding estimates as BCA. Propagating each error through later inviscid groups and using (8) makes their total <=eps. Therefore actual terminal Fminus1<4eps<=nu/64. Both self-advection and viscosity have remained active throughout.

## 5. Explicit shrinking transverse tolerance

Set D=sum_j Sj Mj, Mf=M3, epscal=min(nu/64,1), and prescribe

    rho = min(1/2, epscal^2/[256(1+D)(1+Mf)]).      (9)

Compare the actual path with the exact-direction path having the SAME actual static phases/gains. Both have the H3 bounds just earned. From (8), sum_j deltaj Mj<=1/8. Transport skewness and the ordinary H3 Lipschitz bound yield

    ||u_actual-u_ref||2 <=6 rho D.

H1 interpolation and the safe Fourier embedding then give

    Fminus1(u_actual-u_ref)
       <=8(6rho D)^(2/3)(2Mf)^(1/3) <=epscal.      (10)

For the last inequality, cube the left expression, obtaining 36864 rho^2 D^2 Mf. Substitute (9), use Mf/(1+Mf)^2<=1/4 and epscal<=1. This is the collaborator's separately written NONLINEAR_CALIBRATION_LEMMA, with its constants checked algebraically.

The actual terminal Fminus1 is therefore <=nu/32, strictly within the accepted nu/4 continuation region. This proves robustness only at the explicitly shrinking tolerance (9). Achieving or certifying a physical angular error of this size is not made cheap by its binary encoding.

## 6. Global continuation and common terminal time

Let T0=sum_j deltaj, M=2^1000 M3, and

    T=T0+[1+64 K^2 M/nu^3]/nu.                    (11)

Turn the controller off after T0. Accepted 8EB/BCA's torus critical-Fourier inequality gives global strong continuation and H3<=M. Energy decays throughout the native controlled and uncontrolled equation, since both u and b are divergence-free. In particular ||u(t)||2<=K/(1+nu t). Interpolating with H3<=M at (11) gives ||u(T)||H1<=nu/4. The zero-driver interval [T0,T] is genuine native Navier-Stokes evolution; it is not treated as an exact heat semigroup.

## 7. Complete resource scope

Let B be the full binary input length and X=2+K+nu+nu^-1. Formula (3) has a fixed arithmetic operation count and constant exponents, as do (6)-(11). Every intermediate rational has O(B+1) bits with an enormous absolute multiplier. Ordinary integer multiplication, division, comparison and ceiling therefore give polynomial bit work and output size. The fixed constant Q has a 2701-bit explicit representation. There is no per-input search or numerical integration.

The following conservative exponents mean C times X to the listed power, with computable absolute C obtained directly from the formulas:

    S1,S2: 132; L1,L2: 396;
    Mstar: 793; S3: 52404; L3: 157212;
    M3 and M: 158005; D: 210409;
    every deltaj^-1: 473223; rho^-1: 368416;
    terminal T: 158011.

Peak spatial W3 actuation is <=C sum Sj/deltaj and its time derivative in W2 is <=C sum Sj/deltaj^2. The total squared actuation/derivative integral is <=C sum Sj^2(deltaj^-1+deltaj^-3). Thus the single safe numerical exponent 4,000,000 bounds all these resources, the pulse coefficient magnitudes after expansion, every nonzero time-piece reciprocal duration, T, M, rho^-1 and the fixed spatial frequency. Constants are computable from (3),(6)-(11), not fitted from a finite parameter grid.

There are three active degree-six polynomial pieces and one zero-driver piece, with spatial frequencies always e1,e2,e3. The expanded global-time coefficients have rational height O(B+1): translating a fixed-degree polynomial by a rational breakpoint does not change the polynomial bit conclusion. The duration of the final zero interval has reciprocal at most nu, hence is also paid.

No attempt has been made to construct the immense full coefficient list even at K=nu=1. A small separate certificate checks the integer/symbolic bookkeeping only; it is not a fluid experiment or a practical resource benchmark.

## 8. What remains open and what this changes

This construction replaces growing spatial frequencies by three fixed ones while retaining native nonlinear dynamics and a polynomial resource description. It does so by a different exact resonance decomposition, an action-uniform H1-to-Fminus1 map, a quantitative Jacobi bound, and a shrinking calibration specification.

It does not settle fixed-actuator stabilization under a fixed 1/1024 transverse angle error. It neither proves that impossible nor infers practical feasibility. The known BCA/2B5 growing-frequency theorem remains the stronger established calibration contract. The collaborator's genuinely viscous robust sector-composition route is a separate possible repair, with its nonlinear compatibility still unpaid. No claim of external novelty is made before a broader control-theory prior comparison.
