# Three fixed-coordinate shears: finite-computable exact-direction control

## Status and exact boundary

This is an author construction, not an independently cleared fluid theorem. It proves a proposed finite-computable successor at a STRICTLY WEAKER calibration/resource contract than the full open question. Spatial frequencies and polarizations are fixed:

(p1,a1)=(e1,e2), (p2,a2)=(e2,e3), (p3,a3)=(e3,e1).

Each actual pulse may have an unknown constant gain theta_j in[1/2,2] and an arbitrary constant phase phi_j. The polarization directions are EXACT: there is no transverse vector error e_j. The construction supplies a terminating finite-arithmetic synthesis, but no polynomial bound in input bit length or numerical K,nu. It does not downgrade the already accepted2B5 growing-frequency robust polynomial result, and does not solve its fixed-actuator, transverse-error-robust polynomial successor.

The proposed nonlinear transfer retains exactly the native equation on the unit three-torus:

u_t+P[(u.grad)u]=nu Delta u+P[(b.grad)u], divu=0, meanu=0.

The target is one prescribed rational C2 three-pulse programme for every smooth H3<=K datum, with native viscosity, global strong continuation and a common terminal H1 basin. The torus critical-Fourier continuation/terminal-time machinery is imported from accepted8EB, not independently reproved here. The new part is a fixed-frequency infinite-H3-ball evacuation/composition, plus its explicit elementary short-pulse interface.

## 1. Fundamental-shear structure and primary spectral input

Write U_j(s,phi)=exp(s B_j(phi)), B_j=P[(a_j cos(2pi p_j.x+phi).grad)]. This is unitary on divergence-free L2 and preserves mean zero. Its Fourier evolution shifts only the coordinate p_j. For p=e1, each transverse integer sector xi=(k2,k3) is invariant. Set beta=|xi| and n=k1. The scalar strength is2pi(a.xi). The two velocity polarizations of the selfadjoint cosine compression are:

- constant transverse polarization: free Jacobi coefficients a_n=1/2;
- in-plane polarization:
  a_n=(beta^2+n(n+1))/(2 sqrt((beta^2+n^2)(beta^2+(n+1)^2))), b_n=0.

Here beta uses integer-frequency units; the common2pi has been taken out. For beta>=1 the coefficients are positive and bounded by1/2. If A=(beta^2+n^2)(beta^2+(n+1)^2) and B=beta^2+n(n+1), then A-B^2=beta^2. Thus1/2-a_n=O_beta((1+|n|)^-4), including the first weighted summability required by Egorova–Holzleitner–Teschl arXiv1506.06555v2, Theorem1.1. The compression norm is at most1. The no-L2-point-spectrum argument is the governing N1777 fixed-coordinate addendum (or its direct weak Sturm form). EHT therefore implies that every fixed matrix coefficient tends to zero as |t| grows; it also gives a sector-dependent t^-1/3 estimate.

Only this qualitative, fixed-sector decay is used for termination. No uniform numerical scattering constant is assumed. Both polarizations are retained. A phase change conjugates the ladder by diagonal factors exp(i n phi), so individual coefficient magnitudes do not change. Gain theta simply rescales t. A finite collection of coefficients therefore tends to zero uniformly for theta in[1/2,2] as s tends to infinity.

Primary source read: https://arxiv.org/html/1506.06555, introduction and Theorem1.1. Its constants are not claimed explicit/uniform in beta. Exact Jacobi normalization and the no-point-spectrum source are inherited/derived as stated, not a new scattering theorem.

## 2. An action-uniform output norm, not a Wiener composition assumption

For mean-zero f define F_-1(f)=sum_(k!=0) |fhat(k)|/(2pi |k|). Vector coefficients use their Euclidean norm.

For ANY unitary that preserves the transverse sectors of a coordinate shear, Cauchy–Schwarz on one ladder gives, for beta>=1,

sum_n |(U f)hat(n,xi)|/(2pi sqrt(n^2+beta^2))
 <= [sum_n 1/(4pi^2(n^2+beta^2))]^(1/2) ||f_xi||l2
 <= beta^-1/2 ||f_xi||l2.

The last bound follows by comparing the positive decreasing sum to its integral. On the two-dimensional transverse lattice, square-shell counting gives

sum_(xi!=0) beta^-1/(1+4pi^2 beta^2)
 <= (2/pi^2) sum_(m>=1) m^-2 <4/9.

For xi=0 the shear is identity, and the mean-zero axis contribution has squared L2 functional norm sum_(n!=0)(2pi n)^-2<1/9. Combining the disjoint sectors yields the deliberately loose but explicit uniform estimate

                         F_-1(U f) <= ||f||H1.                 (1)

It holds for every shear action, phase and gain, including resonant sectors. It does NOT say U is bounded on F_-1 itself. Such a Wiener-norm assertion is unnecessary and generally unsafe.

Let P0 be the projection onto k1=0. For U1, output in each transverse xi is just one unitary row, and its H^r weight is the minimum longitudinal weight. Hence for every r>=0,

                         ||P0 U1 f||H^r <= ||f||H^r.          (2)

Both estimates extend by density from finite Fourier sums. They also hold on any restricted collection of invariant sectors.

## 3. Two effectively certifiable small maps

For any rational M>=1 and epsilon>0 the following searches terminate, producing a positive rational action S and a finite rational certificate, uniform in phase and theta in[1/2,2].

(A) Active-shear evacuation. If Q_a projects onto a.k!=0, find S such that

             sup_(||f||H3<=M) F_-1(U(S) Q_a f) < epsilon.      (3)

(B) Plane evacuation. For R0={k2=0}, find S such that

       sup_(||f||H3<=M) ||P0 U1(S)(I-R0) f||H1 < epsilon.      (4)

These are complete infinite-ball maps, not pointwise assertions on one initial velocity.

Proof and effective tails. Cut the input to the cube |k_i|<=R. The high-input H1 norm is at most M/(1+4pi^2(R+1)^2). Equations(1) and(2) control this tail uniformly in action, so R can be fixed BEFORE choosing S. Take R so this error is at most epsilon/4.

For(4), the remaining input and plane output have finitely many transverse modes, and the needed coefficients all belong to active sectors k2!=0. Each tends to zero by Section1. A finite matrix-entry test, including the H1 output weights, makes the low-input contribution <epsilon/2.

For(3), the finite set of transverse sectors still has infinitely many longitudinal output modes. Cut them at |n|<=L. Uniform unitarity gives the omitted F_-1 tail at most (2R+1)M/sqrt(L). Choose L so this is <=epsilon/4, again BEFORE S. The remaining matrix is finite, consists only of active-sector coefficients, and decays entrywise. Its entry thresholds can be chosen rationally, e.g. epsilon/[8 M d_in d_out (1+8(L+2R))], where d_in and d_out are the full three-component finite matrix dimensions. The coarse integer expression dominates all Euclidean/weight conversions.

No unknown spectral number is queried. For successive positive INTEGER candidate S, approximate the relevant infinite-ladder matrix coefficients by a finite ladder. A ladder generator has norm <=2pi R. With gains<=2, use the rational action bound x=16RS. If the retained ladder extends q steps beyond every input index, the omitted unitary return has norm <=tail_(q+1)(x). Increase q until its rational geometric factorial bound is below the desired coefficient error. Also retain the selected output indices through L.

The finite physical three-vector representation uses rational Leray projectors P_k=I-kk^T/|k|^2 and neighbor blocks P_(k+p)P_k/2, so no unencoded eigenvector basis or spectral oracle is needed. The selfadjoint norm bound is analytic. Rational Taylor interval arithmetic approximates its exponential; pi is enclosed by ordinary convergent rational series. The skew-adjoint Taylor remainder is bounded by |t|^(m+1)/(m+1)!, and arithmetic intervals explicitly include all operations.

For the unknown gain, cover[1/2,2] by a rational grid. Each coefficient is Lipschitz in theta with constant at most8RS. A mesh below the entry threshold/(64RS), combined with strict interval margins, certifies the entire gain interval. Phase magnitudes were already eliminated exactly. Search terminates because for all sufficiently large S every one of the finitely many exact coefficients is below half its strict threshold uniformly on the gain interval. Increasing arithmetic precision and finite-ladder padding at each candidate makes the computed error smaller than the reserved margin.

Each candidate is a finite explicitly bounded calculation. Its number of ladder sites is O(RS+L+log(1/tolerance)); its dense-matrix or sparse-polynomial arithmetic and bit work are paid. The total search is a total computable function of rational inputs, but there is currently NO polynomial or practically usable upper bound on the first accepted S. No successful execution of the full synthesis search is claimed in this packet.

## 4. Exact three-stage assembly

Let P0={k1=0}, R0={k2=0}, Q0=I-P0. U2 preserves k1, U1 is exactly identity on R0, and U3 is exactly identity on P0. Therefore

P0 U2 U1 f = U2 P0 U1 f
           = U2 P0 R0 f + U2 P0 U1(I-R0) f.                 (5)

This is the critical decomposition. It neither assumes commuting full shear propagators nor bounds their F_-1-to-F_-1 norms.

Set epsilon0=nu/48. Use(4) to choose S1 with M=K and error epsilon0. Use(3) for U2 on the k3-axis P0R0, again M=K and error epsilon0, to choose S2. The second term in(5) has F_-1 at most epsilon0 by(1). Thus

                  F_-1(P0 U2 U1 f) < 2epsilon0.             (6)

The chosen first two linear shears have an explicitly finite H3 bound Mstar for all initial H3<=K, phases and gains. Ordinary fixed-coefficient commutator energy gives Mstar<=K exp(C(S1+S2)), with any explicitly certified sufficiently large Sobolev constant C. An integer ceiling replaces the exponential. Polynomial nilpotent bounds from accepted BCA can improve this but are unnecessary for finiteness.

Use(3) for U3 on Q0 with M=Mstar and error epsilon0. The physical action S3 depends only on nu,K and the first two certified actions, not on an initial velocity or unknown calibration. Since U3 fixes P0, equations(5)-(6) imply

            sup_(||f||H3<=K) F_-1(U3 U2 U1 f) < nu/16.     (7)

This is a finite-computable uniform inviscid evacuation with THREE FIXED spatial frequencies and exact polarizations. Unknown phases/gains are covered simultaneously. The previous growing-frequency off-diagonal-remainder construction is not invoked to assert(7).

An auxiliary exact cube identity gives a second view of low-frequency return. Let Pi_R be the Fourier cube projection. Each coordinate is changed only once, in order1,2,3. If a path starts and ends in this cube, every intermediate coordinate equals either its initial or final value and is also inside. Thus

Pi_R U3 U2 U1 Pi_R = Pi_R U3 Pi_R U2 Pi_R U1 Pi_R.           (8)

Identity(8) is exact even with transverse errors, because support directions p_j stay fixed. However the active/resonant decomposition(5) is NOT robust to those errors. No transverse-error theorem follows from(8).

## 5. Actual native nonlinear pulses: no fictitious heat switch

This section supplies a finite-computable interface rather than treating viscosity or self-advection as switchable. All three physical pulses retain both terms of the stated native PDE. There is no heat-only surrogate stage.

Fix a rational absolute C sufficiently large for the standard torus H3 commutator/product and H1 linear shear estimates. Such a constant is explicitly computable by finite Leibniz sums and square-shell upper bounds on the convergent Fourier embedding sums; no solution-dependent constant occurs. One may use an overestimate instead of optimizing it. The inequalities needed are, on a strong existence interval,

Y' <= C f(t) theta Y + C Y^2,  Y=||u||H3,
||U_j(t,s)||H1->H1 <= exp(C integral_s^t theta f),
||P(u.grad u)||H1 <= C ||u||H3^2.

Native viscosity contributes nonpositively to the H3 energy. The fixed cosine W3 norms are absorbed in C. The usual smooth local solution can be continued while this bound stays finite.

Choose rational/integer E_j>=exp(2 C S_j), for example2^ceil(4CS_j). Set M0=K and Mj=2 E_j M_(j-1). Select positive rational durations delta_j so that

delta_j <= [4 C M_(j-1) E_j]^-1,
delta_j <= nu/[96 E_j (nu Mj+C Mj^2) product_(l>j) E_l].

The elementary Riccati estimate bounds the actual H3 norm throughout pulse j by Mj. In physical time use f_j=(S_j/delta_j)*140 r^3(1-r)^3 on its interval, r in[0,1]. It has area S_j, is nonnegative rational-polynomial of degree6, and patches to zero globally C2.

Duhamel in H1 against the inviscid shear, with viscosity and self-advection retained as forcing, gives

||u_j-U_j u_(j-1)||H1
 <=delta_j E_j (nu Mj+C Mj^2).

Propagating the three errors through the later H1-bounded linear shears costs at most nu/32 in H1, hence at most nu/32 in F_-1 by the ordinary torus lattice estimate. Together with(7), the actual terminal state has F_-1<3nu/32<nu/4. Accepted8EB critical-Fourier continuation then supplies global unforced strong evolution, a common finite H3 bound and a computable later rational time with H1<=nu/4. Its source sections3 and6 state the inequalities/terminal procedure; they are premises here, not newly verified consequences of an L2 stability estimate.

All controller coefficients, breakpoints, uniform bounds, output lengths and actuation integrals are finite/computable from the terminating searches and the rational allocations above. Their magnitudes may be extremely large and NO polynomial or practical specification is claimed. This differs materially from the still-open stronger fixed-actuator robust polynomial contract.

## 6. Why this does not silently solve transverse robustness

The exact identities U1 R0=R0 and U3 P0=P0 require exact polarization. If a1 acquires an e3 component, modes k2=0,k3!=0 move under stage1. If a3 acquires an e2 component, it no longer fixes k1=0, and its resonant plane tilts. The proof cannot insert the nominal P0/R0 and call that small in a large-action programme.

An explicit caution for a DIFFERENT common-p schedule: p1=p2=e1, nominal a1=e2,a2=e3 and equal phases. If s2>=1024s1, the allowed second error e2_actual=-(s1/s2)e2 gives exact inviscid cancellation on k=e2. A third p=e2,a=e1 is resonant there. This is a schedule-specific echo, not a general fixed-actuator obstruction, and native viscous dissipation can break it. It explains why hierarchical actions alone cannot simply replace the spatial separation in2B5.

Current boundary: fixed3-mode exact-direction finite synthesis is proposed complete as above; fixed1/1024 transverse errors and polynomial resources remain unearned. Collaborator's conditional viscous-sector contraction and quantitative Jacobi work are complementary, not assumed supplied by this manuscript.
