# Three-sandwich dependency and hidden-assumption check

Date: 2026-11-09. Analytic collaboration check by the author of the physical-Lp component. This is not independent certification of that component or of the entire controller. No PDE, scattering, parameter-grid, or timing run was performed.

## 1. Disposition

I find no remaining accuracy/resource circle in the displayed THREE_BLOCK_ALLOCATION_CANDIDATE, conditional on its explicitly named local-filter, native-short-pulse, active-sector-mixing and critical-continuation inputs. The important repair is structural: all three L6 background bounds are fixed from the INITIAL H3 radius before choosing waits. Neither the actual endpoint H3 reset nor the preceding approximation error is used as the next background amplitude.

The proposed construction therefore does not need the still-open controlled-viscous L6/parabolic estimate. It uses actual very-short native pulses followed by actual unforced nonlinear waits, paying their differences from an inviscid-shear/literal-heat reference.

This note independently reconstructs the norm dependencies and polynomial exponents. It does not replace the governing full proof or its separate review of the local nonlinear filter.

## 2. Bound source snapshots

- THREE_BLOCK_ALLOCATION_CANDIDATE.md: facec2c5681d75ceb25a7438a6893a94f81a68f2b57d719e3aae9fed25f2099d.
- L6_BACKGROUND_NATIVE_FILTER.md: c6f87541b7e2108cf8de8bdeffa2e59bb30e4af1b202b8a424796b6d8f9ec443.
- STRONG_ENDPOINT_RESET.md: f3bb8bf29ffc06487d1ddcb02de1384eb9156d7d77dbc1a5708fe36ad9492c2f.
- NATIVE_HEAT_REFERENCE.md: b114fb078476d5baa1fbdc5048ec0431c494df12dfbf0b01dc0d4d68449a1ee1.
- PHYSICAL_LP_CANDIDATE.md: 6b4ddd9328498adafa0774102cfbde188a2c9cea09574ea9a3fc775a3f6f2923.
- Old active-sector source PROOF_CANDIDATE.md: aba26f62748787c71db33275d2a2e71a8cb7f61a37a137afffca993ebb1fad60, with mandatory JOST_DIRECT_RECURRENCE_REPAIR.md: 0f95e76249df8cf8fc1e24a0e73ce0c07745fec70065234a7c08f209a533cd01.
- Inherited BCA/continuation assembly POLYNOMIAL_EXACT_DIRECTION.md: b11a682fc7695229f03fb27af560822f5867b5bdc4c43e8e6fe2b6bd0c671fc9.

The first four sources are in fixed_actuator_critical_heat_bridge_20261109; the physical-Lp source is in fluid_uniform_spectral_edge_20261109. The last two roots are controlled_fluid_fixed_actuator_20261109 and fixed_actuator_return_20261109 respectively. Original bytes were not changed.

## 3. Why a common amplitude A can be fixed first

Write f0 for arbitrary initial mean-zero divergence-free data with H3 norm<=K, K>=1. Let

 U1: (p,a)=(e1,e2), U2: (e1,e3), U3: (e2,e1),
 Dj=exp(tj Delta), tj=nu*delta_j,
 f1=D1U1f0, f2=D2U2f1, P=projection onto k=(n,0,0).

Every Uj uses its actual allowed static direction, phase and gain. On each fixed transverse xi relative to e1, the native physical longitudinal L6 bound is C_f=2^200*6^4. This is uniform in alpha=a.xi, including alpha=0. It does not require a nonresonance condition. The native polarization basis depends on xi and the frequency axis, not on the transverse direction a.

Fiber heat is exp(-4pi^2|xi|^2 t) times the one-dimensional vector heat operator, hence is L6-contracting. Consequently

 ||U1f0||6 <=C_f sum_xi||f0,xi||L6(T1),
 ||U2D1U1f0||6 <=C_f^2 sum_xi||f0,xi||L6(T1).

These are finite products of bounded fiber maps; there is no Trotter limit and no implied full three-dimensional L6-to-L6 theorem.

An explicit input bound is sum_xi||f0,xi||L6<=16K. Indeed one-dimensional Fourier Cauchy gives ||g||infinity<=2||g||H1. The nonzero two-dimensional lattice satisfies sum_xi|xi|^-4<=16 by its8m maximum-coordinate shells. Transverse Cauchy then gives at most4K, with another K for xi=0, before the factor2. The safe16 covers all terms. Therefore the first two background bounds are below2^426K.

Both first shears preserve each xi and FIX xi=0 pointwise. Thus

 P f2=D2D1P f0,       ||P f2||H3<=K.

The third sheared background U3P f2 has L6<=2^267K by the one-shear H3-to-L6 bound. Hence A=2^600K is a common action-, wait-, datum- and calibration-independent supplied amplitude reserve.

No unknown Fourier projection or reference state is evaluated by the controller. The backgrounds are proof objects. The active-sector projections used below are only used in Hilbert/Sobolev estimates, not treated as physical L6 contractions.

## 4. The single-error bridge is genuine and not a word bound

For any ONE native coordinate shear U, fiber L2 unitarity implies

 Fminus1(Uw)<=16||w||H^(3/4),
 Hcal(Uw)<=Fminus1(Uw)/sqrt(2)<=16||w||H^(3/4).

The nonzero transverse-fiber estimate uses sum_n(n^2+beta^2)^-1<=5/beta, followed by sum_(xi!=0)beta^-5/2<=24. The zero fiber is unchanged and has the elementary one-dimensional Fourier Cauchy bound. This covers both native polarizations and arbitrary static phase/direction. It does not use the new Jost Lp theorem.

This estimate is applied only ONCE before the NEXT native filter. Errors are not propagated through an unbounded number of shears, and no H^(3/4)-to-H^(3/4) uniform shear bound is asserted.

## 5. Backward errors and waits

Use the memo's exact rational factories

 delta(A,e)=min{1/nu, nu^3/(80*2^40*A)^4, e^8 nu^7/(128^8 A^16)},
 eps(A,e,delta)=min{nu/(32*2^40), e*nu*delta/64}.

Choose

 e3=zeta3=nu/4096; delta3,eps3 from these factories;
 e2=q2=eps3/64;    delta2,eps2 from these factories;
 e1=eps2/32;       delta1,eps1 from these factories.

Then native-pulse H1 errors rho1<=eps1/8, rho2<=eps2/16 and rho3<=eps3/16 have the precise reserves

 block1 input Hcal <=8rho1<=eps1,
 block2 input Hcal <=16e1+8rho2<=eps2,
 block3 input Hcal <=16(e2+q2)+8rho3<=eps3.

The background for block2 is U2f1, not U2 applied to the entire actual state. The background for block3 is U3P f2, not U3f2. The omitted pieces are added to the explicitly charged critical remainder. Native pulse approximation applies to the FULL actual input, with its separately paid H3 bound, so this split does not suppress native nonlinearity or implement a physical projection.

All waits are selected before any actions. Actual-state Sobolev bounds never feed back into A, e or delta.

## 6. Linear contraction and all-error quantifiers

For each xi!=0 relative to e1, at least one first-stage transverse direction is active. One nominal coordinate has magnitude at least|xi|/sqrt(2); a perturbation of norm<=1/1024 leaves a margin above|xi|/2 even after the allowed gain is charged. Let E1 denote the actual active mask for U1. It commutes with U1,U2 and heat because these preserve xi. Its complement inside I-P is active for U2.

The old audited H1-to-Hdot^-1 mixing bound with a safe Q=2^3000 then gives, without summing transverse mode counts,

 ||E1 f2||H^.75 <=2QK t1^-1/2 t2^-3/8 S1^-1/13,
 ||(I-P-E1)f2||H^.75 <=4QK t1^-1/2 t2^-7/8 S2^-1/13.

In the second line, D1 supplies H1 from L2; the first shear is only used as an L2 unitary. In the first, D1 converts negative norm to L2 and U2 cannot restore that lost L2 norm. Thus all leave-and-return paths are retained. There is no inviscid-word evacuation claim.

Since tj<=1, choose

 S1,S2>=max{1,[16QK/(q2 t1 t2)]^13}.

The sum above is at most3q2/8, strictly below q2. Similarly every nonzero axis mode P f2 is active for U3, and

 S3>=max{1,[8QK/(zeta3 t3)]^13}

makes ||D3U3P f2||H^.75<=zeta3/4. The memo's weaker final reserves are therefore safe.

The controller uses no knowledge of E1 or any calibration. Its action formulas depend only on K,nu and fixed constants. The full actual endpoint has H^.75<=e3+zeta3=nu/2048, hence Fminus1<=nu/128 by the stated16 embedding reserve.

## 7. Independent polynomial resource exponents

Let X=2+K+nu+nu^-1. A quantity assigned exponent d below is bounded by C X^d, where C is an absolute computable constant assembled from the displayed formulas. All sums/maxima involve a fixed number of terms.

If e^-1 has exponent E, the rational factories give

 delta^-1: 23+8E,
 t^-1=(nu delta)^-1: 24+8E,
 eps^-1: 24+9E.

Starting with E3=1 yields

                     stage1       stage2       stage3
 e_j^-1               321           33            1
 eps_j^-1            2913          321           33
 delta_j^-1          2591          287           31
 t_j^-1              2592          288           32
 rho_j^-1            2913          321           33
 S_j                37882        37882          442
 L_j=(1+2^29S_j)^3  113646       113646         1326

The native energy bound is always K in L2. The exact filter resets allow the rational pre-pulse H3 reserves

 K1=K, K2=16K/t1^2, K3=16K/t2^2,

with exponents1,5185,577. Post-pulse Mj=4LjKj has exponents113647,118831,1903.

With C0=2^20, choose the native pulse duration hj as a positive rational at most

 1/3,
 1/(32 C0 Lj^2 Kj),
 rho_j/[2Lj(nu Mj+C0 Mj^2)].

These are the inherited BCA strong-existence and H1-approximation requirements for the ACTUAL calibrated shear, not a nominal-direction perturbation. The resulting inverse-duration exponents are343853,351629,5165. The third bound dominates the other displayed degree bounds in every stage. A fixed extra factor2 may be inserted for strict margins without changing exponents.

The native filter's intermediate H3 bound is at most2Mj max{1,2^18 Mj^2 delta_j/nu}. Since delta_j<=nu^-1, its exponents are340943,356495,5711. Thus a common controlled H3 upper bound has exponent356495. A fixed-factor enlarged common bound can also cover the inherited final critical continuation.

Controlled total time is at most3+3/nu. The inherited terminal-time rule

 T=T0+[1+64K^2 M/nu^3]/nu

has exponent at most356501. Every nonzero wait/pulse/terminal-idle reciprocal duration is polynomial.

For completeness, pulse f_j=(Sj/hj)140r^3(1-r)^3 has peak amplitude Sj/hj and second time derivative at most a fixed constant Sj/hj^3. Their largest exponents are389511 and1092769. The squared second-derivative integral is bounded by a fixed constant Sj^2/hj^5, with largest exponent1833909. Expansion into global-time polynomial coefficients costs at most C Sj hj^-7(1+T0)^6, with exponent at most2499291. Fixed spatial derivatives and allowed calibration only alter constants. A single safe numerical degree4000000 therefore covers these resources and the previous ledger.

These are intentionally loose symbolic majorants, not fitted exponents or practical actuation estimates. Binary synthesis uses a fixed number of rational operations and fixed integer powers. Each intermediate has O(B+1) bits with an enormous fixed multiplier, where B is full input bit length. No real-root oracle, parameter search, dynamics solve or hidden calibration-estimation step occurs.

## 8. Exact remaining obligations and limitations

- The governing assembly must bind the physical-Lp and local-filter sources at their actual scopes. I authored the former, so this is not its independent review. The verifier's earlier scoped review and the separate filter challenge remain necessary provenance.
- The local PDE filter/continuation and BCA duration contracts must be retained, not replaced by a scalar heat or transport theorem.
- The final programme has three fixed spatial shears and six nontrivial pulse/wait pieces, plus terminal unforced evolution. Its reference decomposition is not a physical state-dependent operation.
- All bounds cover static independent calibration in each pulse, as specified. Time-varying direction/phase/timing error is not included.
- The enormous fixed polynomial degree and constants establish a mathematical resource statement only; no practical control cost advantage is claimed.

The old generic sequential allocation failure and fixed inviscid-word floors remain true in their scope. This candidate uses a different legal nonlinear filtering mechanism and does not retroactively amend them. No universal-tolerance controller is declared complete by this dependency note alone.
