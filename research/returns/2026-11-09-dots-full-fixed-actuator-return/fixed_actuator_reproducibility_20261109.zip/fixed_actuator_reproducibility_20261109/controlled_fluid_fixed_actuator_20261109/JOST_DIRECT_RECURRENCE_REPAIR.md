# Direct even coefficient recurrence and correction record

Date2026-11-09. This supersedes the j-cutoff explanation in
JOST_CONSTANT_LEDGER.md, whose original bytes are preserved.
The final C_J=2^256 and all later constants are unchanged.

## Issue found

Reading the double-bracket index in the extracted Teschl equation10.10
as floor(j/2)+1 is inconsistent with the separately displayed
K_2(n)=sum_(m>=n+1)c_m for a single-bond defect.
The earlier ledger's claim that m contributes only up to j=2(m-n)-1
must therefore not be used. This may be a source/index-extraction issue;
no assertion about a monograph erratum is needed.

## Direct repair for this particular chain

We need no general transformation-kernel estimate.
Set w_n=2a_n, c_n=1-w_n^2, A_n=product_(m>=n)w_m.
Write the right Jost solution as

 f_+(z,n)=z^n g_n(z)/A_n,
 g_n(z)=1+sum_(r>=1) Q_r(n) z^(2r).

Substitution into the Jacobi equation gives the exact identity

 g_n-g_(n-1)=z^2[g_(n+1)-g_n-c_n g_(n+1)].

Consequently the coefficients, vanishing at plus infinity, satisfy

 Q_1(n)=C(n+1),  C(k)=sum_(m>=k)c_m,

 Q_r(n)=Q_(r-1)(n+1)
         +sum_(m>=n+1)c_m Q_(r-1)(m+1), r>=2.

All coefficients are nonnegative. Define

 D_r(n)=product_(l=1)^(r-1)(1+C(n+l)).

A direct induction yields Q_r(n)<=D_r(n) C(n+r).
Indeed, D_(r-1)(m+1)<=D_(r-1)(n+1) and C(m+r)<=C(n+r)
for m>=n+1. These inequalities bound the recurrence by
D_(r-1)(n+1)*(1+C(n+1))*C(n+r)=D_r(n)C(n+r).

For n>=-1, the budgets in the main proof give

 D_r(n)<=exp(sum_(m>=n+1)(m-n)c_m)<=exp(21),
 A_n^(-1)<=exp(21).

Thus

 sum_(r>=1)Q_r(n)
 <=exp(21)*sum_(m>=n+1)(m-n)c_m <=21exp(21),

 sum_(r>=1)2r Q_r(n)
 <=exp(21)*sum_(m>=n+1)(m-n)(m-n+1)c_m
 <=256 beta exp(21).

The right Jost demodulated Fourier-l1 norm is at most22exp(42),
and its theta derivative has norm at most256 beta exp(42).
At n=0,1,-1 reinstating z^n adds at most22exp(42), so
278 beta exp(42) suffices for the derivative.

These bounds prove convergence of the series and its first theta
derivative, permit substitution into the equation, and recover the
right Jost asymptotics. Reflection n->-n gives the left Jost solution.
The reserved2^256 bound is therefore valid without the disputed index.

This is a repaired analytic derivation. No physical or numerical
propagation was run, and the original source interpretation is retained.
