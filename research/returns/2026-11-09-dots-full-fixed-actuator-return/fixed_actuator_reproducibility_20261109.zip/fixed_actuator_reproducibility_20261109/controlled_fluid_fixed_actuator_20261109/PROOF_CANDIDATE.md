# Quantitative fundamental Leray shear and robust linear composition

Date: 2026-11-09. Status: author-derived candidate, not independently cleared.
This note gives an explicit linear lemma and a separate obstruction to a naive
nonlinear transfer. It does NOT claim fixed-actuator stabilization of the
nonlinear three-dimensional velocity equation.

## 1 Model and conventions

The unit torus has Fourier functions exp(2*pi*i*k.x). P is the canonical
orthogonal Leray projection. Work on mean-zero divergence-free velocities.
The positive Sobolev operator is Gamma=-Delta; its Fourier eigenvalues are
4*pi^2*|k|^2. Homogeneous norms are used below.

For a fundamental shear b=a*cos(2*pi*x_1+phi), with a.e_1=0, the native
transport B=P(b.grad) is skew-adjoint. Fix transverse frequency
xi=(k_2,k_3), beta=|xi|>=1, and write k=(n,xi). Two orthonormal polarizations
are: the constant direction perpendicular to e_1 and xi, and
v_n=(beta*e_1-n*xi/beta)/sqrt(beta^2+n^2).
The first polarization is the free Jacobi chain. The second is J_beta,
with zero diagonal and bonds

 a_n = [beta^2+n(n+1)] /
       [2 sqrt((beta^2+n^2)(beta^2+(n+1)^2))].

The transport group in this sector is exp(i*omega*t*J_beta), where
omega=2*pi*(a.xi), up to a diagonal phase gauge. That gauge commutes with
Gamma. Both polarizations and all longitudinal n are retained.

Put w_n=2a_n and c_n=1-w_n^2. Direct algebra gives

 c_n=beta^2/[(beta^2+n^2)(beta^2+(n+1)^2)],
 0<c_n<=1/2, 1/sqrt(2)<=w_n<1.

Reflection n -> -n-1 leaves c_n unchanged.

## 2 Explicit coefficient budgets

The following deliberately loose bounds hold for all real beta>=1:

 sum_n (1+|n|) c_n <= 21,
 sum_n (1+|n|)^2 c_n <= 128 beta.

For verification, let m=ceil(beta). On n>=0,
c_n<=beta^2/(beta^2+n^2)^2.
For 0<=n<=m, bound the first weighted sum by 6 and the second by 14 beta.
For n>m, use c_n<=beta^2/n^4; the corresponding tails are <=1 and
<=4 beta. Reflection weights are at most 3(n+1) and 5(n+1)^2.
This gives 21 and 90 beta, respectively; 128 beta is reserved.

Also sum_n (1+|n|)|a_n-1/2|<=21/2<11.
The coefficient sequence is therefore a short-range Jacobi perturbation.

## 3 Quantifying the scattering estimate

Primary inputs are Teschl, Jacobi Operators and Completely Integrable
Nonlinear Lattices, Chapter 10, especially the explicit transformation
coefficient recursion/product estimate (10.10)-(10.12); and
Egorova-Holzleitner-Teschl, arXiv:1506.06555, Sections 2-3.
No unquantified Wiener-inverse constant is used in the following accounting.

Let f_+(z,n), f_-(z,n) be Jost solutions normalized by z^(+n), z^(-n)
at their respective infinities. Let tilde f denote removal of that free
power. The transformation estimate bounds the remaining series by a
one-sided tail of c, times a product of (1+one-sided tails of c).
The product of reciprocal w's contributes at most exp(sum c), because
-log(w)<=c for 0<=c<=1/2.

The budgets in Section 2 imply, using the product and tail-sum estimates,
the following ample common envelope C_J=2^256:

 - ||tilde f_+(.,n)||_A <= C_J for n>=0;
 - ||tilde f_-(.,n)||_A <= C_J for n<=0;
 - their theta derivatives have A norm <= C_J beta;
 - the same undemodulated value/derivative bounds hold for BOTH Jost
   solutions at n=0,1.

Here A is the Fourier l1 algebra on the unit circle. The one-step extension
to n=0,1 is included in C_J. A direct ledger is: shifting a one-sided
origin by one multiplies first/second moment budgets by at most 4;
the product exponents are at most 84, and tail summation contributes
at most 2^16 beta. Thus 2^16 exp(84)<2^256.
This intentionally dominates the sharper estimates; the power of beta
is from the second moment, not hidden in an exponential.

### Threshold separation

Since a_n<=1/2, define V_n=1-a_n-a_(n-1)>=0. Then

 <f,(I-J_beta)f>
 =sum_n a_n |f_(n+1)-f_n|^2 + sum_n V_n |f_n|^2.

For the right Jost solution at z=1, positivity of the discrete flux
equation implies f_+(1,n)>=1. This follows first for finite truncations
with a=1/2 outside, by recursion from the right, and then by the
short-range Jost limit. Its flux at minus infinity has magnitude
sum_n V_n f_+(1,n), so the endpoint Wronskian obeys

 |W(1)| >= sum_n V_n
         =sum_n(1-w_n)
         >=2[1-beta/sqrt(beta^2+1)]
         >=1/(8 beta^2).

The last constant is deliberately weakened. Bipartite symmetry gives
the same lower bound at z=-1. The linear growth of the opposite Jost
solution at the other end is permitted; the weighted tails guarantee
the stated flux limit. This is not a claim that either threshold
solution is square-integrable.

All spectrum lies in [-1,1] since J_beta is a compression of multiplication
by cos (also by the form bounds). Short-range Jacobi theory excludes
embedded point/singular continuous spectrum; the endpoint lower bounds
exclude threshold resonances. Thus the propagator has only its
absolutely continuous part.

### A quantitative inverse Wronskian

The value/derivative bounds above imply

 ||W||_A <= 2^512,
 sup_theta |dW/dtheta| <= M_beta := 2^514 beta.

Use the endpoint lower bounds within distance
(8 beta^2)^(-1)/(2 M_beta) of 0 and pi.
Away from these neighborhoods scattering unitarity gives
|W(exp(i theta))|>=|sin(theta)|/2.
Together these imply the safe global lower bound

 |W(exp(i theta))| >= delta_beta := 2^(-524) beta^(-3).

For a periodic C^1 function F, Cauchy-Schwarz on Fourier coefficients gives
||F||_A<=2(||F||_infty+||F'||_infty).
Consequently

 ||1/W||_A <= 2^1568 beta^7,
 ||R_+||_A, ||R_-||_A <= 2^2080 beta^7,
 ||T||_A <= 2^1568 beta^7.

This supplies an explicit bound instead of merely invoking Wiener's lemma.

### Dispersion

The standard Jost spectral kernel has phase -t*cos(theta) plus a linear
integer multiple of theta. For opposite half-lines use T times the two
own-half-line Jost factors. For equal half-lines the scattering relation
uses two own-half-line factors and 1+R. The A-norm of every such amplitude
is bounded by 2^2593 beta^7.

Partition the circle into at most eight intervals on each of which
either |cos(theta)|>=1/2 or |sin(theta)|>=1/2. Apply order-two or
order-three van der Corput separately to every Fourier coefficient of
the amplitude. The added integer-linear phase changes neither derivative.
The deliberately loose combined numerical constant 2^16 covers these
intervals and both derivative orders.

Therefore the following common envelope is admitted in this candidate:

 ||exp(i t J_beta)||_(l1 -> linfty)
 <= Q beta^8 |t|^(-1/3),  Q=2^2700, t!=0.               (3.1)

The free polarization has the usual oscillatory integral with amplitude1,
and satisfies this much larger envelope as well.

All constants in this section are author-derived; the sensitive review
points are the shifted one-sided transformation budget and the threshold
flux normalization. No numerical propagation was used.

## 4 Uniform mixing on nonresonant sectors

Assume |a|<=2 and restrict to the Fourier sectors satisfying

 |a.xi|>=beta/2.                                       (4.1)

This restriction commutes with B and Gamma. For each sector,

 sum_n [4*pi^2*(n^2+beta^2)]^(-1) <= 1/beta.

Cauchy-Schwarz on the input and output converts (3.1) into

 ||exp(t B)||_(H1_beta -> Hminus1_beta)
 <= Q beta^(20/3) t^(-1/3).

The trivial unitary bound is at most beta^(-2).
For t>=1 split beta at t^(1/26). The two bounds imply

 ||exp(t B)||_(H1 -> Hminus1) <= Q t^(-1/13).           (4.2)

For t<1 the same statement follows from the trivial bound.
This direct-sum estimate does not sum over the number of transverse modes.
Static phase changes have no effect.

## 5 An explicit viscous sector contraction

The native operator satisfies
|Re <Bf,Gamma f>|<=16 ||f||_H1^2 and
||Bf||_L2<=2||f||_H1.
The first inequality follows by differentiating once, using skew
transport cancellation, and bounding ||grad b||_infty<=4*pi<16.
P commutes with derivatives and is orthogonal; no scalar replacement
of the in-plane Leray component is made.

Apply Coti Zelati-Delgadino-Elgindi, arXiv:1806.03258, Theorem2.1,
to (4.2), with exponent p=1/13. Its enhanced-dissipation exponent is
q=26/27. A safe decay constant is 1/(512Q).

For physical viscosity nu>0 and multiplier A>nu, on (4.1),

 ||exp[t(nu Delta + A B)]||_(L2 -> L2)
 <= exp[-nu^(26/27) A^(1/27) t/(512Q)]

whenever nu^(26/27) A^(1/27) t>1.

Given rational plateau duration delta>0 and rational 0<eta<=1/4, choose
an integer ell>=1+log_2(1/eta), and the rational/integer amplitude

 A=ceil(2nu + nu^(-26) [1024Q ell/delta]^27).           (5.1)

Then the plateau contracts its nonresonant sectors by at most eta.
All formula evaluation is finite rational arithmetic except the integer
bit-count choice of ell, which does not require a real logarithm.
The bound is polynomial in nu, nu^(-1), delta^(-1), and eta^(-1),
with huge fixed constants. It is not a practical amplitude claim.

## 6 Three fixed actuators and transverse calibration

Use nominal pairs

 (p1,a1)=(e1,e2), (p2,a2)=(e1,e3), (p3,a3)=(e2,e1).

Each actual direction is v_j=theta_j(a_j+e_j), where
|theta_j-1|<=rho, |e_j|<=rho, e_j.p_j=0, rho=1/1024.
Each pulse can have arbitrary fixed phase. These are exactly static
within each pulse; timing/frequency and the amplitude envelope are not
perturbed here.

For xi=(k2,k3), the first two transverse vectors form a near-identity
2x2 frame. Hence

 max(|v1.xi|,|v2.xi|)>=|xi|/2,  |v_j|<=2.

Let E be the k=(n,0,0) axis and Q0=I-E. The first two stages preserve
every xi sector and act as pure heat on E. Each xi!=0 is contracted
by eta by at least one stage, while the other stage is contractive.
Thus ||S2 S1 Q0||<=eta.

For the third shear each mode in E lies in a sector with transverse
(k1,k3)=(n,0), and |v3.(n,0)|>=|n|/2. Thus ||S3 E||<=eta.
It follows that

 ||S3 S2 S1||_(mean-zero L2 -> L2)<=sqrt(2)*eta.        (6.1)

This argument uses genuine viscous operator contraction, not merely
small central return coefficients. No inter-stage low-frequency return
can restore dissipated norm.

To meet a C2 temporal contract, each stage may have a ramp of duration
delta, plateau delta, and ramp-down delta, using the rational quintic
10x^3-15x^4+6x^5. The ramps preserve the same sectors and are L2
contractions. The plateau still supplies the stated contraction.
Three stages have duration9delta, and b is C2 and zero outside.
The phase and direction remain fixed throughout each entire stage.

## 7 What this does not prove

Equation (6.1) is a LINEAR native-Leray transport-diffusion theorem
candidate. It does not establish a global strong solution of
u_t+P(u.grad u)=nu Delta u+P(b.grad u) for arbitrary H3 data.

The inherited BCA pulse estimate controls H3 by L~(1+s)^3 at fixed
spatial frequency and asks delta*L^2*K to be small. Merely choosing
(5.1) and declaring the nonlinear term a perturbation does not work:
s=A delta grows as delta^(-26), and delta*s^6 grows rather than shrinks.

Turning b off does not turn native self-advection off; a heat-filter
stage cannot be inserted as an exact nonlinear operation.

The Iyer-Xu-Zlatos abstract convection-suppression theorem requires an
L2 bound on the nonlinear term from H1 of a form not satisfied by the
three-dimensional velocity quadratic. It is not an automatic bridge.

A remaining possible repair is a mixing-adapted nonlinear norm or a
time/derivative budget exploiting actual dissipation, rather than
the worst-case H3 envelope. No such estimate is asserted here.

## 8 An exact robustness echo against the naive fast inviscid schedule

The common-p schedule cannot simply be run as rapid inviscid evacuations.
Let its first two actions be s1>0 and s2>=1024*s1. Choose equal phases,
actual a1=e2, actual a2=e3-(s1/s2)e2, and third direction a3=e1.
This is an allowed transverse error.

Take u0=c*e3*cos(2*pi*x2). Throughout these shears the solution is of
the form e3*f(x1,x2), so it is divergence-free, P is inactive on the
scalar transport, and the native nonlinear term is IDENTICALLY ZERO.
Inviscidly, the first two pulses give opposite accumulated x2 shifts
and cancel exactly. The third shear is then inactive on u0.

For finite nu compare to this inviscid path v. Its intermediate phase
has accumulated displacement q in [0,s1], and

 ||Delta v||_2 <=16*pi^4*(1+s1)^2 ||u0||_2.

Duhamel and L2 contractivity of the actual scalar drift-diffusion imply,
for total duration T,

 ||u(T)-u0||_2
 <=16*pi^4*nu*T*(1+s1)^2 ||u0||_2.                    (8.1)

Thus if the right-hand coefficient is <=1/4, at least3/4 of the initial
L2 norm remains. The example applies to actual native nonlinear dynamics,
but only to this specified schedule/fast-pulse implementation.
It is not a no-go theorem for fixed-actuator control.

## 9 Primary sources and scope

Astra source chain is pinned to commit
b94558eb630b431f03a7e14aba043f564c10cf70 in
harjassand/astra-research-knowledge:
research/returns/published-20261109/N1777.md;
the 8EB, BCA, and2B5 return files listed in SOURCE_INDEX.json.

Teschl's transformation recursions and the EHT scattering/dispersion
representation are established methods, not new methods claimed here.
Coti Zelati-Delgadino-Elgindi supplies the established linear transfer.
The proposed incremental contribution is explicit specialization to the
fundamental Leray fibers plus calibration-robust sector composition.

This note is not a claim of new nonlinear stabilization, an unforced
Navier-Stokes result, practical actuation, or independent verification
of all inherited Astra proofs.
