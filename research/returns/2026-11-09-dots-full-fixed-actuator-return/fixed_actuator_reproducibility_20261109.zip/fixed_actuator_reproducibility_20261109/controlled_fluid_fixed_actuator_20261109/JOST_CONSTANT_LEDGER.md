# Explicit shifted Jost coefficient ledger

This addendum resolves the one-sided transformation-series constant in
PROOF_CANDIDATE.md without changing its inspected bytes.

Primary source: Gerald Teschl, Jacobi Operators and Completely Integrable
Nonlinear Lattices, printed pp167-169, equations10.2,10.6,10.10-10.12:
https://www.mat.univie.ac.at/~gerald/ftp/book-jac/jacop.pdf

Use c_m=1-4a_m^2 and the already derived budgets S1<=21, S2<=128 beta.
For the right Jost series, with n>=-1, the product factor obeys

 D_j(n)<=exp(sum_(m>=n+1)(m-n)c_m)<=exp(21).

The normalizing product obeys A_+(n)^(-1)<=exp(21).
In the tail estimate for the j-th transformation coefficient, a fixed
m contributes only when 1<=j<=2(m-n)-1. Therefore

 sum_(j>=1)|K_j(n)| <=42 exp(21),
 sum_(j>=1)j|K_j(n)| <=256 beta exp(21).

After multiplication by A_+(n)^(-1), the demodulated Jost series has
Fourier-l1 norm <=43 exp(42), and its theta derivative has norm
<=256 beta exp(42).

At n=0,1,-1 the free z^n factor adds at most43 exp(42) to the derivative.
Thus the value and derivative bounds needed at the Wronskian anchor are
at most43 exp(42) and299 beta exp(42), respectively.

For this particular chain, a_n=a_(-n-1), hence reflection n->-n yields
f_-(z,n)=f_+(z,-n). The left Jost value at n=1 is therefore covered by
the right Jost n=-1 estimate. On its own half-line the left demodulated
series has the same uniform estimates.

Since299 exp(42)<2^70, the reserved C_J=2^256 in the candidate has ample
slack. There is no exponential dependence on beta in this argument.

This is an analytic source-bound calculation, not a numerical replay or
an independent audit of the full research programme.
