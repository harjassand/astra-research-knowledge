# Paid transverse calibration for a nominal nonlinear controller

Date2026-11-09. This is a stability lemma, not a constant-tolerance theorem.
It can transfer a valid fixed-frequency exact-polarization controller to
an explicitly shrinking transverse-error class.

## Lemma

Consider the native equation on the unit three-torus,

 u_t+P(u.grad u)=nu Delta u+P(b.grad u),

for two drivers b_ref and b_actual, with the same initial datum.
Both drivers are divergence-free. On pulse j, both use the SAME actual
static phase and multiplicative gain theta_j, with |theta_j|<=2:

 b_ref(t,x)=theta_j f_j(t) a_j cos(2*pi*p_j.x+phi_j),
 b_actual(t,x)=theta_j f_j(t)(a_j+e_j)cos(2*pi*p_j.x+phi_j).

Here |a_j|=1, e_j.p_j=0, |e_j|<=rho<=1/2, and f_j>=0 has action
s_j=integral f_j. Between pulses the drivers agree (in particular may be0).

Assume uniform native strong-solution H3 bounds M_j on each pulse for BOTH
paths, a final bound M_f>=1 for BOTH paths, and a reference envelope M(t)
over the full controlled interval [0,T0], including all gaps.
Put

 D=sum_j s_j M_j,
 E=integral_0^T0 M(t)dt.

Then

 ||u_actual(T0)-u_ref(T0)||_2 <=2 rho D exp(8E).          (1)

If E<=1/8, the endpoint critical Fourier error is bounded by

 Fminus1(u_actual-u_ref)
 <=8(6rho D)^(2/3)(2M_f)^(1/3).                        (2)

Here Fminus1(v)=sum_(k!=0)|vhat(k)|/(2*pi*|k|).

For any rational 0<epsilon<=1, the rational tolerance

 rho=epsilon^2/[256(1+D)(1+M_f)]                       (3)

suffices to make (2) at most epsilon. One may lower rho further.
No angle or calibration value is inferred from data.

## Proof

Let w=u_actual-u_ref. Use u_actual as the leading nonlinear advecting
field. The difference equation has nonlinear remainder w.grad u_ref,
driver forcing (b_actual-b_ref).grad u_ref, and skew transport by
b_actual. Both leading transports cancel in the L2 energy estimate;
viscosity is nonpositive. Consequently,

 d||w||_2/dt <= ||grad u_ref||_infty ||w||_2
                +||b_actual-b_ref||_infty ||grad u_ref||_2.

On the unit torus, ||grad v||_infty<=8||v||_H3 and
Fminus1(v)<=8||v||_H1 are safe Fourier-Cauchy bounds.
For example, integer l-infinity shells give
sum_(k!=0)|k|^(-4)<=26 sum_(m>=1)m^(-2)<=52;
the actual2*pi factors make these constants considerably smaller.
Also ||grad v||_2<=||v||_H3.

Since ||b_actual-b_ref||_infty<=2rho f_j on pulse j,
Gronwall proves (1). If E<=1/8, exp(8E)<=exp(1)<3.
Interpolation between L2 and H3 gives
||w||_H1<=||w||_2^(2/3)||w||_H3^(1/3), while ||w||_H3<=2M_f.
This proves (2).

Cubing (2) gives the bound36864 rho^2 D^2 M_f.
Using (3), D^2/(1+D)^2<=1, M_f/(1+M_f)^2<=1/4, and epsilon<=1
shows this is at most epsilon^3. This proves the rational admission.

## How the lemma can be used without assuming strong solutions

The short-pulse triangular H3 argument in the inherited BCA construction
can supply the required uniform H3 bounds before continuation. It depends
on the spatial shear magnitude and frequency, not on the exact axis of its
transverse direction. Use one common enlarged bound for |theta(a+e)|<=3,
arbitrary phase and the same fixed p.

Pulse durations may be shortened at fixed action. Add to their existing
upper restrictions the requirement E<=1/8, paying reference bounds in
every included free gap as well. This only changes the pulse clock and
amplitude, not the inviscid endpoint action.

If the reference endpoint obeys Fminus1<=nu/32 and epsilon<=nu/32,
the actual endpoint obeys Fminus1<=nu/16, inside the inherited small-data
continuation region. This final inference depends on the validity of that
small-data theorem and on an independently valid nominal controller.

When actions, H3 bounds and inverse durations are polynomial in the input
parameters, (3) requires only polynomial inverse calibration tolerance.
Its binary precision cost is O(log(1/epsilon)+log(1+D)+log(1+M_f)).
Physical effort to achieve or verify that precision is NOT priced by this
mathematical bit count.

## Scope

This does not establish the fixed universal rho=1/1024 tolerance in2B5.
It is a shrinking-tolerance result. Arbitrary phase and gain are handled
by comparing to the corresponding member of a nominal uniformly valid
phase/gain family, not by calling their perturbation small.

No assumed switch-off of native nonlinearity, artificial viscosity, or
exact heat-only evolution is used. No practical calibration apparatus or
noise/time-dependent-error theorem is claimed.
