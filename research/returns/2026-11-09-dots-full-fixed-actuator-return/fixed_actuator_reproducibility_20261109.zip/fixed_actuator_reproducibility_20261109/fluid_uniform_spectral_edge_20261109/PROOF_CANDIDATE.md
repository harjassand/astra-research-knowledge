Packaging note: This is a mathematical excerpt. One non-mathematical project-allocation paragraph in Section 7 is omitted; mathematical sections and source statements are unchanged. The original file hash is in SOURCE_PROVENANCE.json.

# Uniform transverse-frequency dispersion by removing spectral-edge strips

Date: 2026-11-09. Status: new author proof candidate, not yet independently cleared. No PDE evolution, scattering computation or control programme is executed. The result below is a linear component, NOT the fixed-actuator universal-calibration theorem.

## 1. Target and inherited exact chain

For every real beta>=1, let J_beta on l2(Z) have zero diagonal and positive bonds

 a_n=[beta^2+n(n+1)]/[2 sqrt((beta^2+n^2)(beta^2+(n+1)^2))].

Write w_n=2a_n and

 c_n=1-w_n^2=beta^2/[(beta^2+n^2)(beta^2+(n+1)^2)].

The elementary inherited bounds are 0<=c_n<=1/2, a_n<=1/2, reflection w_(-n-1)=w_n, and sum_n(1+|n|)c_n<=21. See controlled_fluid_fixed_actuator_20261109/PROOF_CANDIDATE.md section2. The free polarization has c=0 and is included in all arguments below.

Proposed conclusion, with one explicit but deliberately enormous constant:

 sup_(beta>=1) ||exp(it J_beta)||_(l1->linfty)
     <= min(1, 2^1200 |t|^(-1/12)),  t!=0.                 (1)

Compared with the existing Q beta^8 |t|^-1/3 estimate, (1) trades time exponent for a constant independent of beta. It does not assert a uniform sharp t^-1/3 theorem or a bounded inverse threshold Wronskian.

## 2. Exact Volterra representation away from the edges

Use the repaired direct even-coefficient recurrence in JOST_DIRECT_RECURRENCE_REPAIR.md, not its superseded extracted-index explanation. Put A_n=product_(m>=n) w_m and f_+(z,n)=z^n g_n(z)/A_n. Summing that recurrence gives the exact Volterra equation

 g_n(z)=1+sum_(m>=n+1) c_m H_(m-n)(z) g_(m+1)(z),
 H_l(z)=z^2+z^4+...+z^(2l)=z^2(1-z^(2l))/(1-z^2).       (2)

This identity can first be checked for finitely supported c; the first weighted moment gives the infinite limit. For n>=-1 and m>=n+1,

 |H_(m-n)|<=m-n<=m+1,
 sum_(m>=0)(m+1)c_m<=21.

Iterated Volterra kernels have strictly increasing m. Their total absolute sum is bounded by product_(m>=0)(1+(m+1)c_m)<=exp(21). Therefore |g_n|<=exp(21). Also A_n^-1<=exp(21), using -log(sqrt(1-c))<=c for c<=1/2. Thus the demodulated Jost function has magnitude <=exp(42), uniformly for n>=-1 and beta>=1.

For z=exp(i theta), sigma=|sin theta|>0, direct differentiation gives

 |dH_l/dtheta| <= 3l/sigma+1/sigma^2.

Differentiate (2). Its inhomogeneous source is at most

 exp(21) [63/sigma+21/sigma^2] <=84 exp(21) sigma^-2.

The SAME Volterra resolvent contributes only another exp(21); division by A_n adds exp(21). Hence

 |d(g_n/A_n)/dtheta| <=84 exp(63) sigma^-2.               (3)

This step uses the first weighted moment, not the beta-dependent second moment. Differentiation is justified first for finite tails and then uniformly on every closed arc away from z=+/-1. At n=0,1 reinstating z^n adds only the already bounded value. Reflection gives the analogous left Jost estimates on n<=1. The ample common bounds

 |demodulated Jost|<=C_J,
 |its theta derivative|<=C_J sigma^-2, C_J=2^256,        (4)

hold on each own half-line, and the ordinary Jost bounds at n=0,1 have the same envelope. One can verify the constants using exp(1)<3; no real-oracle constant is hidden.

## 3. Scattering coefficients only away from the edges

Primary input: Egorova, Holzleitner and Teschl, arXiv:1506.06555v2 (2015), equations2.5-2.7 and3.2-3.3. These are the usual Jost scattering relation and spectral kernel. Its Theorem1.1 does not by itself state the uniform-beta conclusion here.

On sigma>0, flux conservation gives |T|,|R_+|,|R_-|<=1. With the cited normalization, |W| is at least sigma; the weaker sigma/2 is sufficient. The Wronskians use only n=0,1. Equation(4) gives their derivatives <=2 C_J^2 sigma^-2, after enlarging harmless fixed constants if a convention changes a unit phase. Differentiating the quotient formula while retaining |T|,|R|<=1 yields

 |T'|<=6 C_J^2 sigma^-3,
 |R_+'|,|R_-'|<=8 C_J^2 sigma^-3.                       (5)

There is NO inversion of W on an entire circle with a beta-dependent threshold gap. We only use it on an arc where sigma is bounded below.

For opposite spatial half-lines the kernel amplitude is T times two own-half-line demodulated Jost functions. For equal half-lines use the scattering relation to write it as a sum of at most two amplitudes involving1 orR and own-half-line Jost functions. Each free power z^l is retained in the oscillatory phase, rather than differentiated as amplitude. The resulting amplitudes are bounded by C_J^2 and their first derivatives by12 C_J^4 sigma^-3. Increasing the number of terms to four is a safe convention-independent allowance.

The short-range positive-bond Jacobi spectrum is absolutely continuous in[-1,1], with possible discrete eigenvalues only outside that band by the cited standard theory. The row-sum bound ||J||<=1 excludes those outside eigenvalues. The heat estimate below also excludes edge atoms. No point-spectrum contribution has been dropped.

## 4. Uniform mass of a spectral-edge strip

This step replaces threshold inversion. All matrix entries of J are nonnegative and bounded by the corresponding free-chain entries. Path expansion therefore gives

 <delta_n,exp(sJ)delta_n> <= <delta_n,exp(sJ_free)delta_n>
   =I_0(s), s>=0,

uniformly in beta and n. For s>=1,

 exp(-s) I_0(s)
 = (1/(2pi)) integral_(-pi)^pi exp[-s(1-cos theta)]dtheta
 <=s^-1/2,

using 1-cos theta>=2theta^2/pi^2. Let0<alpha<=1 and choose s=alpha^-2. For the spectral projection E_+=1_[cos alpha,1](J),

 <delta_n,E_+delta_n>
 <=exp[s(1-cos alpha)] exp(-s)I_0(s)
 <=exp(1/2)alpha <=2alpha.                              (6)

Bipartite symmetry gives the same estimate at the lower edge. Cauchy-Schwarz in spectral measure implies, for every t and m,n,

 |<delta_m, exp(itJ)(E_++E_-)delta_n>|<=4alpha.           (7)

This bound is uniform through the limiting free threshold resonance. It is a spectral-projection bound, not a bound on the absolute value of a possibly cancellation-sensitive Jost integrand.

## 5. Interior oscillatory estimate and optimization

On the remaining arcs, sigma>=sin alpha>=alpha/2. Partition into at most16 pieces on which either |cos theta|>=1/2 or |sin theta|>=1/2. The phase is +/-t cos theta+l theta. The integer l changes neither the second nor third derivative. For t>=1 the second/third derivative van der Corput estimate and bounded variation of the amplitude give

 |interior kernel| <=2^1100 alpha^-3 t^-1/3.             (8)

An explicit constant ledger is: at most four own-half-line amplitudes; their supremum plus total variation is at most2^12 C_J^4 alpha^-3; at most16 pieces; second/third order oscillatory constants may be taken below2^16. Their product is below2^1100. For the third derivative estimate one can split where |phase''|<=t^(2/3) (length at most4t^-1/3) and apply the second derivative estimate on at most two remaining pieces, giving a constant below32. Thus the deliberately larger2^16 does not rely on an unspecified asymptotic constant.

Choose alpha=t^-1/12. Then (7)+(8) is at most(4+2^1100)t^-1/12<=2^1200 t^-1/12. For |t|<1, unitarity bounds every matrix entry by1. This proves the proposed envelope(1), subject to independent checking of the source normalization and the Volterra differentiation ledger.

## 6. What this supplies to the fluid programme

On a physical shear fiber xi with beta=|xi|>=1 and |a.xi|>=beta/2, actual Jacobi time has magnitude at least pi beta t (or a fixed comparable value after the allowed gain). The fiber Sobolev Cauchy-Schwarz factor is sum_n[4pi^2(n^2+beta^2)]^-1<=1/beta. Equation(1) therefore gives

 ||U(t)||_(H1_beta->Hminus1_beta)
 <=2^1200 beta^(-13/12) t^-1/12
 <=2^1200 t^-1/12,                                    (9)

up to one explicitly harmless gain constant. Taking a direct sum costs no number of transverse modes. Static spatial phase is a diagonal gauge. The established Coti Zelati–Delgadino–Elgindi linear transfer would correspond to enhanced-dissipation exponent24/25 rather than26/27, but that linear result does NOT control the native nonlinear equation by itself.

A uniform active-fiber entry bound may help a robust repeated cone-escape construction with a fixed large action per cycle. It does not imply that such a word has a uniform output contraction, much less that independent angle/phase errors at every pulse can be averaged. No deterministic or probabilistic composition theorem is assumed here. A negative norm cannot be claimed contractive merely because its matrix entries are small.

## 7. Current obstacle and division of work

The full target still requires ONE prescribed rational C2 fixed-actuator programme valid for every initial H3 ball member and every pulsewise unknown transverse error at rho0=1/1024, with all numerical and binary resources polynomial. The nominal exact-direction three-cycle plus shrinking tolerance does not provide that.


Primary sources actually consulted: arXiv:1506.06555v2, sections2-3; arXiv:1806.03258v1, abstract framework and Theorem2.1. The latter is a linear mixing-to-dissipation theorem, not a theorem about this controlled native3D velocity nonlinearity. The heat domination and edge/interior interpolation above are elementary established types of arguments; no external novelty claim is made.
