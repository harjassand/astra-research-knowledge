#!/usr/bin/env python3
"""Optional small scalar/source replay. Never runs the giant compiler or a PDE."""
from pathlib import Path
import json, shutil, subprocess, sys, tempfile
ROOT = Path(__file__).resolve().parent

def main():
    source = ROOT / 'fixed_actuator_universal_return_20261109'
    audit = ROOT / 'fixed_actuator_heat_sandwich_audit_20261109'
    with tempfile.TemporaryDirectory(prefix='fluid_scalar_replay_') as d:
        tmp = Path(d)
        for name in ('check_source_contract.py', 'synthesize.py'):
            shutil.copyfile(source / name, tmp / name)
        result = subprocess.run([sys.executable, '-B', str(tmp / 'check_source_contract.py')], cwd=tmp, text=True, capture_output=True, timeout=3, check=True)
        actual = json.loads(result.stdout)
        expected = json.loads((source / 'SCALAR_RESULTS.json').read_text())
        if actual != expected:
            raise AssertionError('Candidate replay differs from preserved SCALAR_RESULTS.json')
        shutil.copyfile(audit / 'check_ledger.py', tmp / 'check_ledger.py')
        result = subprocess.run([sys.executable, '-B', str(tmp / 'check_ledger.py')], cwd=tmp, text=True, capture_output=True, timeout=3, check=True)
        actual_audit = json.loads(result.stdout)
        expected_audit = json.loads((audit / 'EXACT_LEDGER.json').read_text())
        if actual_audit != expected_audit:
            raise AssertionError('Audit replay differs from preserved EXACT_LEDGER.json')
    print(json.dumps({'candidate_checks': actual['count'], 'audit_scalar_checks': len(actual_audit['scalar_checks']), 'both_recorded_outputs_match': True, 'scope': 'Scalar/source checks only; no full synthesis, PDE, scattering or hardware execution.'}, indent=2))

if __name__ == '__main__':
    main()
