# Candidate noncircular three-block allocation

Date: 2026-11-09. This is an internal construction memo, not the governing complete controller proof. The return/composition worker owns the final assembly and its resource ledger. All local filter sources remain frozen.

## Dependencies and claim status

- Local nonlinear filter and reset: L6_BACKGROUND_NATIVE_FILTER.md (c6f87541...), STRONG_ENDPOINT_RESET.md (f3bb8bf2...), NATIVE_HEAT_REFERENCE.md (b114fb07...). Separate scoped challenge found no local blocker; no PDE run.
- Active-fiber mixing H1 to Hdot^-1: the already audited fixed-direction polynomial Jacobi construction gives Q*s^(-1/13), with a safe Q=2^3000 after all fixed gain conventions. The newer uniform-beta spectral claim is not needed for this memo.
- New dependency: the constructor's physical per-fiber L6 bound C_f=2^200*6^4 for a SINGLE inviscid native shear, uniform in action/phase/direction. Its spectral reconstruction and physical-space multiplier proof remain a candidate needing the stated check.
- Native very-short-pulse H1 implementation and final small-Fminus1 continuation: inherited audited BCA interfaces, not redeveloped here.

Let K>=max(1,||initial datum||H3), nu>0, theta=3/4, C=2^40. Use three nominal directions

    (p1,a1)=(e1,e2), (p2,a2)=(e1,e3), (p3,a3)=(e2,e1),

with independent static admissible phase/gain/transverse error per invocation. The first two share p, which is essential. Put D_j=exp(nu*delta_j*Delta) and let U_j be the ACTUAL calibrated inviscid shear.

## 1. Background amplitudes do not depend on preceding waits

The per-fiber L6 candidate implies

    ||U1 f||6<=A,
    ||U2 D1 U1 f||6<=A,

with the common safe bound A=2^600 K, independent of every action and delta1. Indeed, on each fixed transverse xi the first two propagators have L6_x1 norms <=C_f, while longitudinal heat is L6-contracting and transverse heat is a scalar contraction. Sum the INITIAL fiber L6 norms by the same H3 Cauchy estimate. This is not a full three-dimensional L6-to-L6 assertion.

Let P be the projection on the k1 axis. Then

    P D2 U2 D1 U1 f = D2 D1 P f,

because both shears fix xi=0 exactly. This axis background has H3<=K. Consequently its third sheared image U3 P D2 U2 D1 U1 f also has L6<=A.

The small complementary part is carried as a critical remainder, never charged to the background's L6 or H3. This is the proposed repair of the earlier circular allocation A_next~delta_prev^(-3/2).

## 2. Backward rational wait allocation

For a background bound A and desired local Htheta block error eta define

    delta(A,eta)
      =min{1/nu, nu^3/(80 C A)^4,
                         eta^8 nu^7/(128^8 A^16)},
    eps(A,eta,delta)
      =min{nu/(32C), eta*nu*delta/64}.

The local heat-reference theorem then permits a native block with Htheta error <=eta, provided its filter input has Hcal remainder <=eps.

Choose all waits BEFORE any shear action:

    e3=zeta3=nu/4096;
    delta3=delta(A,e3);
    eps3=eps(A,e3,delta3);

    e2=q2=eps3/64;
    delta2=delta(A,e2);
    eps2=eps(A,e2,delta2);

    e1=eps2/32;
    delta1=delta(A,e1);
    eps1=eps(A,e1,delta1).

All are rational. Because A is fixed above, this is an acyclic finite computation. It uses only a fixed number of polynomial/rational operations; no growing recurrence or real-root oracle is hidden.

Native short-pulse H1 errors can be allocated as

    rho1<=eps1/8, rho2<=eps2/16, rho3<=eps3/16.

The stage2 critical input error is at most16e1+8rho2<=eps2. The stage3 critical input error is at most16(e2+q2)+8rho3<=eps3. Here the factor16 is the already derived one-shear Htheta-to-Fminus1 bound, and Hcal<=Fminus1/sqrt(2). The factor8 converts a native-pulse H1 error to Hcal.

## 3. Linear sector contraction after waits are fixed

Set t_j=nu*delta_j<=1. For every transverse xi!=0, at least one of the first two actual transverse directions satisfies the active condition |(a_j+error_j).xi|>=|xi|/2, since rho0=1/1024 is much smaller than1/sqrt(2)-1/2. The allowed gain is paid in Q.

Let E1 be the actual transverse active projection for stage1. It commutes with both first shears and heat. On E1, the first mixing estimate, first heat, unitary second shear and final heat give

    ||E1 D2 U2 D1 U1 f||Htheta
       <=2 Q K t1^(-1/2)t2^(-3/8) S1^(-1/13).

On its complement within xi!=0, stage2 is active. The first heat supplies H1 input from L2, and the second heat converts the mixed Hminus1 output:

    ||(I-P-E1) D2 U2 D1 U1 f||Htheta
       <=4 Q K t1^(-1/2)t2^(-7/8) S2^(-1/13).

Therefore the conservative choices

    S1,S2 >=max{1, [16 Q K/(q2*t1*t2)]^13}

make the full Q=I-P reference remainder smaller than q2. The controller need not know E1; it appears only in the proof and all bounds are uniform.

Every nonzero k1-axis mode is active for the third actual direction near e1 with p3=e2. Since the axis H1 norm remains <=K,

    ||D3 U3 P D2 U2 D1 U1 f||Htheta
       <=2 Q K t3^(-7/8) S3^(-1/13).

Thus

    S3>=max{1,[8 Q K/(zeta3*t3)]^13}

makes this reference smaller than zeta3.

These actions are selected only after the backward wait allocation. All powers are fixed. No late change in action increases any of the three background A bounds.

## 4. Actual state tracking and endpoint

After block1 let the actual output be f1+w1 with f1=D1U1f and ||w1||Htheta<=e1. Before block2 filter, use background U2f1 and remainder U2w1 plus native-pulse error. The filter theorem and the allocations give actual block2 output f2+w2, f2=D2U2f1, ||w2||Htheta<=e2.

Before block3 filter, use background U3 P f2 and remainder U3[(I-P)f2+w2] plus native-pulse error. Its Hcal input is <=eps3. The actual final state differs from D3U3P f2 by at most e3 in Htheta. Its Htheta norm is therefore at most e3+zeta3=nu/2048, and its critical Fourier norm is at most nu/128 by the conservative embedding constant16.

This is a proposed complete norm ledger, pending the governing composition check. In particular the native equations during every wait remain nonlinear and the background may depend on the unknown actual calibration; it is an analysis object, not a computed or measured state.

## 5. Resource ordering and remaining checks

Native energy is nonincreasing during both the skew-transport pulses and unforced waits. Consequently each filter resets the actual endpoint H3 to at most16K/t_j^(3/2), or the rational reserve16K/t_j^2. These bounds supply the NEXT native short-pulse duration allocation. They do not alter the already chosen background A_j, which uses the separate reference/fiber argument.

Each BCA pulse duration is chosen after its action, its input-H3 reserve and rho_j are fixed. The actual post-pulse H3 can be large, but the local filter lifespan does not depend on it; its intermediate growth remains polynomial in that supplied norm. There are only three blocks. Hence the suggested order avoids the specific action/accuracy and wait/amplitude circles identified earlier.

The final whole-resource polynomial, the precise inherited short-pulse and continuation constants, the physical-Lp dependency, and all quantifiers still need to be bound in the governing assembly. This memo is not itself an independent clearance or an external breakthrough claim.
