# Strong endpoint reset for the L6-background native filter

Date: 2026-11-09. This is an analytic addendum to L6_BACKGROUND_NATIVE_FILTER.md, SHA c6f87541b7e2108cf8de8bdeffa2e59bb30e4af1b202b8a424796b6d8f9ec443. No preceding proof is overwritten. The parent theorem's hypotheses and constants C=2^40, nu*delta<=1 remain in force.

## 1. The full state loses its pre-filter Sobolev cost

Write K2=||u0||2. The actual unforced native filter satisfies

    ||u(delta)||H3 <=16 K2/(nu delta)^(3/2).             (1)

The same bound holds for the background v with K2 replaced by ||v0||2<=A. In particular, the endpoint H3 cost does not depend on the initial H3 norm. The parent theorem still pays a polynomial bound on that norm during the initial portion of the interval; endpoint smoothing is not retroactive regularity.

Here is a direct energy proof with constants. Set E_k(t)=||u(t)||Hk^2 for k=0,1,2,3,4. The explicit tame product estimate with constant128 from the parent proof applies for every k<=3. Therefore

    E_k'+nu E_(k+1)
       <=[nu+2^14 ||u||infinity^2/nu] E_k,
       k=0,1,2,3.                                    (2)

The Hk convention is the Bessel weight (1+4pi^2|k|^2)^k, so the gradient norm squared is exactly E_(k+1)-E_k. This explains the harmless extra nu in (2).

On the final interval [t0,delta], t0=delta/4, critical-space control gives

    ||u(t)||infinity^2 <=nu R^2/t, R=1/(4C).

Put a=nu+2^16 R^2/delta. Since nu*delta<=1, a*delta<2. For F_k(t)=exp[-a(t-t0)]E_k(t), equation(2) reads F_k'+nu F_(k+1)<=0. The derivative of

    sum_(k=0)^3 [nu(t-t0)]^k F_k(t)/k!

is nonpositive. Thus, using native L2 energy contraction,

    E_3(delta)
      <=exp(2) *6/[nu*(3delta/4)]^3 *E_0(t0)
      <128 K2^2/(nu delta)^3.

This proves (1) with16. The argument applies after the already-proved strong existence and also follows uniformly from smooth approximations.

## 2. Fractional regularity of the small remainder

For w=u-v the endpoint estimate improves to

    ||w(delta)||H^(3/4)
        <=32 epsilon/(nu delta)^(7/8).                 (3)

Only an integrable heat singularity is used; no unpriced H1 maximal-regularity theorem is invoked.

On [delta/2,delta], the parent proof gives

    ||w(t)||2 <=||w(t)||infinity
                 <=6 epsilon/sqrt(nu delta),
    ||u(t)||infinity+||v(t)||infinity
                 <=4R sqrt(nu/delta).

Consequently the exact difference source F=v tensor w+w tensor u has

    ||F(t)||2 <=24R epsilon/delta.

For mean-zero data and 0<nu*t<=1, elementary Fourier multipliers give

    ||heat(t)f||H^(3/4) <=2(nu*t)^(-3/8)||f||2,
    ||heat(t)P div F||H^(3/4)
           <=2(nu*t)^(-7/8)||F||2.

Restart the exact difference Duhamel formula at delta/2. Its heat term is below16 epsilon/(nu delta)^(7/8). The source term is at most

    384R epsilon/(nu delta)^(7/8),

because integral_0^(delta/2) t^(-7/8)dt=8(delta/2)^(1/8). Since R=1/(4*2^40), the sum is below32 times the displayed scale. This proves (3).

This bound is substantially stronger than mere L2 proximity. It remains a bound on the native nonlinear remainder; the background is its own actual nonlinear evolution.

## 3. A single subsequent inviscid shear has an action-independent error map

For ANY one native coordinate shear, any static admissible direction/phase/gain, and any action s, its exact inviscid propagator U satisfies

    Fminus1(Uf)<=16||f||H^(3/4).                       (4)

This follows from fiber L2 unitarity, not a physical Lp maximum principle or a scattering constant. For transverse xi!=0, beta=|xi|>=1,

    sum_n 1/(n^2+beta^2)<=5/beta.

Thus the longitudinal contribution is at most
sqrt(5)/(2pi) beta^(-1/2)||f_xi||2. Cauchy--Schwarz over the transverse two-dimensional lattice uses

    sum_(xi!=0) beta^(-5/2)
       <=8 sum_(n>=1) n^(-3/2)<=24.

The complementary weight beta^(3/2) is bounded by the H^(3/4) Fourier weight. The zero-transverse fiber is unchanged and is bounded separately by the ordinary one-dimensional Fourier Cauchy inequality. All fixed factors fit well below16.

The vector polarizations and the phase gauge preserve fiber L2 exactly. Therefore (4) includes both physical polarizations without an additional action-dependent factor.

Combining (3)-(4),

    Fminus1(Uw(delta))
       <=512 epsilon/(nu delta)^(7/8)
       <=512 epsilon/(nu delta).                     (5)

The latter is a simpler entirely rational reserve because nu*delta<=1. Also Hcal<=Fminus1/sqrt(2), so the same conservative bound controls the critical heat error after this one inviscid shear.

This is NOT permission to propagate the same error through an arbitrary word for free. A native short pulse still needs its paid approximation error; successive filters and backgrounds require their own admission budgets. In particular, neither full three-dimensional L6-to-L6 control nor the robust repeated word has been assumed.

## 4. Finite resources and interpretation

The sharper endpoint exponents in(1),(3) can be evaluated with certified rational roots, but this is unnecessary. Since nu*delta<=1, the rational bounds

    ||u(delta)||H3 <=16 K2/(nu delta)^2,
    ||w(delta)||H^(3/4)<=32epsilon/(nu delta)

suffice. They are polynomial in the parent's supplied bounds and reciprocal parameters. For a desired one-shear critical error eta, epsilon<=eta*nu*delta/512 is a paid rational choice.

The important incremental operation is an ACTUAL native nonlinear wait that resets endpoint Sobolev cost using only initial energy, while keeping a small critical remainder with a subsequent action-independent one-shear error map. It removes the need to carry a pre-filter action-cubed H3 bound indefinitely. Producing the admitted L6-background/critical-remainder split under unknown fixed-size transverse errors, and avoiding circular budgets over a growing word, remain open.

All ingredients are established heat, Sobolev and critical-stability methods specialized with explicit constants. No external novelty claim, independent numerical replay, or completed universal-calibration controller is made.
