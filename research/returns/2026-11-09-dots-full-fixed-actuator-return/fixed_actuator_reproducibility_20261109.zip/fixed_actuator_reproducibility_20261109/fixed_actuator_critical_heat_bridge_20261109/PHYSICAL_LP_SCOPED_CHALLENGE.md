# Scoped challenge of the physical per-fiber L6 dependency

Date: 2026-11-09. Reviewer: audit_planar_matchgate. This is a coordinated analytic challenge, not blind replication or a PDE computation. The inspected source is ../fluid_uniform_spectral_edge_20261109/PHYSICAL_LP_CANDIDATE.md; its exact hash is in PHYSICAL_LP_REVIEWED.sha256.

## Disposition

I found no concrete algebraic blocker in the physical-space synthesis argument at the stated ONE-shear/per-fiber scope. The same-p two-factor use needed by the proposed three-block controller follows from that scope. This review relies on the already stated full-line Jost spectral normalization and absence of omitted point spectrum; it does not independently rederive the entire scattering theorem from the original primary source.

## 1. Coefficient monotonicity and physical multiplier norm

The repaired recurrence gives, for r>=2,

    Q_r(n)-Q_r(n+1)
      =Q_(r-1)(n+1)-Q_(r-1)(n+2)
        +c_(n+1)Q_(r-1)(n+2).

The induction for positivity and monotonicity in n is valid. It is not the separate, more delicate monotonicity-in-r claim used in the later diffusion work. Multiplying by the positive decreasing A_n^-1 preserves monotonicity. The ordered Volterra sum and the inherited first weighted moment give the stated uniform sum of coefficient masses <=exp(42).

For each fixed r, the half-line coefficient sequence is a positive mixture of longitudinal Fourier interval projections and its limiting half-line projection. The total mixture mass is its first coefficient. These are physical-circle Fourier multipliers, not estimates on sequence l^p. Modulation preserves physical Lp, so the sum of all r operators converges in operator norm. Duality proves the adjoint bound with the same displayed p-dependent reserve. No scattering-coefficient derivative or inverse-Wiener bound is used at this step.

## 2. The same-half-line ordering issue

This is the most important reconstruction check. For n,k>=0, the ordered spectral kernel after the scattering relation has the two types of integrals

    integral exp(it cos(theta)) R(theta)
             f_+(theta,k) f_+(theta,n) dtheta,

and

    integral exp(it cos(theta))
             f_+(theta,k) f_+(-theta,n) dtheta.

The first is symmetric in n,k. The second is also symmetric AFTER integration: interchange n,k and change theta to -theta. The evolution phase is unchanged because cos is even, and real Jost coefficients give the required reflected functions. Thus the factored expression extends to the whole half-line block rather than only one ordered triangle. No triangular truncation operator has been silently invoked.

Opposite-half-line terms use the two own-side Jost functions and a bounded transmission multiplier. The same-side reflected term uses a bounded reflection multiplier and the physical-circle reflection operator. All those multipliers have modulus at most one by the stated flux identities. Finite component/block counting is absorbed in the large reserve.

Half-lines can be split as n>=0 and n<0 to avoid double-counting the index zero. The uniform coefficient bound at n=0 also dominates the shifted left half-line. Endpoint scattering values occur on a measure-zero set; the separate no-point-spectrum argument remains necessary and is part of the cited dependency.

These identities can first be applied to finite input Fourier polynomials. The absolutely summable coefficient-operator expansion then extends them by density. I found no exchange-of-infinite-sums issue at this use.

## 3. Native polarization and the actual norm needed

The extraction/reconstruction coefficients beta/sqrt(beta^2+n^2) and n/sqrt(beta^2+n^2) have uniformly bounded total variation on the frequency half-lines. The same interval-projection argument therefore gives physical longitudinal Lp multiplier bounds uniformly in beta. Fiber Euclidean L2 unitarity is preserved separately.

For p=6, denote the constructor's safe native per-fiber constant by

    C_f=2^200*6^4.

Longitudinal heat is a vector-valued L6 contraction; transverse heat contributes the scalar exp(-4pi^2 nu|xi|^2 t). Hence two shears with the SAME spatial frequency, with any intervening heat, have per-fiber norm at most C_f^2. Their phases and transverse directions may differ: the two uniform operator bounds are simply composed.

The initial transverse sum is paid from H3. Explicitly, one-dimensional H1-to-L6 costs less than2, and

    sum_xi (1+|xi|^2)^(-2) <13.

Thus sum_xi ||f_xi||L6 <=8||f||H3. With C_f<2^211,

    8 C_f^2 K <2^425 K <2^600 K.

This verifies the common background reserve in THREE_BLOCK_ALLOCATION_CANDIDATE.md. It does not prove full three-dimensional L6-to-L6 boundedness of one shear or arbitrary words. The zero-transverse fiber is drift-fixed, so its H3 norm is only decreased by heat.

## 4. Exact limits of this check

The source argument does not supply an actual viscous Lp maximum principle, a heat/shear Trotter contraction, a diffusion/Jost commutator theorem, or all-word critical-norm control. None is used in the stated common-p reference estimate.

The nonlinear three-block implementation still requires the separately proved native filter, small-error admission, robust active-sector contraction, backward parameter ordering, short-pulse implementation and final continuation. Those are distinct dependencies. This review adds no external novelty or priority assessment and contains no numerical propagation.
