# Critical heat norm and native relative-energy bridge

Date: 2026-11-09. Status: new analytic construction notes. No numerical propagation or full fixed-calibration controller is claimed. This note changes the possible continuation target and pays a native nonlinear error estimate; it does not earn the missing robust word or strong-solution bootstrap.

## 1. Model and norms

On the unit three-torus, let

    u_t = nu Delta u + P[(b.grad)u] - P[(u.grad)u],

with mean-zero divergence-free u and prescribed smooth divergence-free b. The viscosity nu is positive and is not changed. Set lambda_k=4 pi^2 |k|^2 and

    m(f)^2 = sum_(k!=0) |fhat(k)|^2/lambda_k,
    Hcal(f)^2 = integral_0^infinity ||exp(t Delta)f||infinity^2 dt.

All vector norms are Euclidean. Hcal is an output heat certificate, not the physical controlled evolution and not a fictitious heat stage.

For the periodic extension of f to R3, its Koch–Tataru caloric BMO^-1 norm is bounded by Hcal(f): every spatial average of the heat extension is at most its global supremum, and every truncated time integral is bounded by the full integral. Periodic smooth mean-zero functions are tempered distributions, and their R3 heat extensions agree with the periodic heat evolution.

## 2. An explicit negative-norm/amplitude bound

For all t>0,

    ||exp(t Delta)f||infinity
       <= min(||f||infinity, 4 t^(-5/4) m(f)).                (1)

The first bound is heat-kernel positivity. For the second, Fourier Cauchy–Schwarz gives the square root of

    sum_(k!=0) lambda_k exp(-2 lambda_k t).

On the max-coordinate shell |k|infinity=n, there are 24n^2+2<=26n^2 terms, lambda_k<=12 pi^2 n^2, and lambda_k>=4 pi^2 n^2. Hence this sum is at most

    312 pi^2 sum_(n>=1) n^4 exp(-8 pi^2 n^2 t).

For x in [n-1/2,n+1/2], n<=2x and n>=2x/3. Therefore

    sum n^4 exp(-a n^2)
       <=16 integral_0^infinity x^4 exp(-4a x^2/9) dx
       <=96 a^(-5/2).

Using 3<=pi<=4 shows the original lattice sum is less than 16 t^(-5/2), proving (1).

Let M=||f||infinity and m=m(f). The zero cases are immediate. Otherwise split the heat integral at t0=(4m/M)^(4/5). Direct integration yields

    Hcal(f)^2 <= (5/3) (4m)^(4/5) M^(6/5),

and in particular

    ||f||BMO^-1 <=Hcal(f)<=3 m(f)^(2/5) M^(3/5).            (2)

No physical-space maximum principle for Leray transport has been used. Applying (2) after a control word requires a proved amplitude envelope for that word.

There is also the linear perturbation estimate

    Hcal(f)<=Fminus1(f)/sqrt(2)<=8||f||H1,                 (3)

where the first inequality is Minkowski in L2 of heat time, and the second uses the already paid periodic Fourier embedding. Thus an H1 error from actual native pulses can be charged in this weaker output norm without a new PDE oracle.

## 3. Native nonlinear relative energy with no actuator derivative

Let v solve the ACTUAL linear controlled equation

    v_t=nu Delta v+P[(b.grad)v],  v(0)=u0,

with the same b, including its actual phase, gain and transverse errors. Let ||u0||2<=K and assume v is smooth. Its L2 norm is at most K. For a strong u, put w=u-v. The same calculation extends as a relative-energy inequality to an energy-class Leray solution with smooth test path v.

All terms involving b cancel by skewness. The v.grad w and w.grad w terms also cancel. Integrating the remaining terms by parts gives

    (1/2) d||w||2^2/dt +nu||grad w||2^2
       <= ||v||infinity (||w||2+K)||grad w||2
       <= (nu/2)||grad w||2^2
          +||v||infinity^2 (||w||2^2+K^2)/nu.

Consequently

    ||u(t)-v(t)||2^2
       <=K^2 {exp[(2/nu) integral_0^t ||v(s)||infinity^2 ds]-1}.   (4)

This uses no derivative of b, no derivative of v in the exponential, and no H3-squared nonlinear forcing estimate. It is a genuine native nonlinear estimate, not a scalar replacement.

For example, if ||v(s)||infinity<=L K on [0,delta] and 0<epsilon<=K, then

    delta<=nu epsilon^2/(4 L^2 K^4)

suffices for ||u(delta)-v(delta)||2<=epsilon. The elementary inequality exp(x)-1<=2x for x<=1/2 pays the last step.

The gain is conditional on the amplitude bound L. Substituting the crude L proportional to (1+action)^3 reproduces the incompatible short-pulse power and earns no improvement. A uniform, logarithmic, or otherwise sufficiently mild physical-space bound for native Leray evolution would change this estimate materially.

## 4. Why the old Wiener inflation is not a general critical obstruction

The earlier moving-frequency stress case lies on u=e1 f(x2,x3), where the native quadratic nonlinearity vanishes. After the second scalar shear, take a normalized complex mode

    f_A=exp(2 pi i x3+i A cos(2 pi x2)).

The real and imaginary parts give real examples. Scalar transport preserves its supremum norm. Standard free Bessel dispersion gives |J_n(A)|<=C A^(-1/3), so summing (1+n^2)^-1 shows m(f_A)<=C A^(-1/3).

The calibrated third shear in the previous stress case has fixed effective action. It is a fixed volume-preserving Lipschitz map Phi, so duality gives

    m(f_A composed with Phi)<=||D Phi^-1||infinity m(f_A),

up to the fixed torus norm convention. The supremum norm stays bounded. Equation (2) therefore gives Hcal<=C A^(-2/15), which tends to zero, even though the critical Fourier l1 quantity in that example can retain a positive lower bound.

This only removes the moving-frequency/l1 objection. The independently constructed FIXED Fourier-mode calibration floor for the one-pass cyclic programme is stronger and also obstructs uniform BMO^-1/heat evacuation. No one-pass theorem follows from replacing the norm.

## 5. Published continuation and what still needs payment

Koch–Tataru's Theorem 2 gives global small-data solutions from BMO^-1 data:
https://math.berkeley.edu/~tataru/papers/nas.pdf

Germain–Pavlovic–Staffilani give higher derivative bounds and analyticity:
https://arxiv.org/html/math/0609781

For viscosity nu, apply the unit-viscosity theorem to u/nu with time rescaled by nu. Thus a sufficiently small fixed multiple of nu in Hcal is an adequate unforced continuation condition. Periodicity follows from uniqueness under integer translations; smooth periodic data have the matching local strong solution.

This is established prior, not a new continuation theorem. Its explicit rational smallness threshold and derivative constants have NOT been extracted in this packet. They must be extracted before claiming the same fully numeric synthesis and common H3/terminal-time resource contract as the original Fourier-Wiener construction.

A stronger recent comparison is Cheskidov–Eguchi's frequency-localized criterion:
https://arxiv.org/html/2503.11642

That result assumes finite-energy data on R3 and distinguishes high-frequency BMO^-1 from weaker low-frequency Besov smallness. It is not imported unchanged for periodic infinite-total-energy extensions. It reinforces that Wiener smallness is not a necessary regularity target, but supplies no free controller.

## 6. The precise unearned transfer

Two obstacles remain distinct.

A. Robust linear output: prove a common calibrated word has a small critical heat norm, or prove both negative-norm decay and a sufficiently mild physical-space amplitude envelope. Uniform-beta sequence-space Jacobi dispersion alone does not provide the required physical-space amplitude bound or control noncommuting returns.

B. Native strong evolution: (4) controls energy-class output error but does not prove regularity before switch-off. In three dimensions, small L2 perturbation does not imply small critical norm or a strong-solution continuation. For a localized divergence-free bump, rescaling f_N(x)=N phi(N(x-x0)) makes L2 tend to zero while the critical BMO^-1 scale stays fixed. This is a norm counterexample, not a Navier–Stokes singularity.

One safe route remains: earn a polynomial H3 bound for a finite inviscid word, use independently short native pulses to ensure strong existence and H1 discrepancy, then apply (3) at switch-off. This works only after the robust linear heat-output word is actually proved. The alternative is an advected critical-space bilinear estimate that closes native strong evolution during the genuinely viscous mixing interval; such an estimate is not established here.

## 7. Cost and scope

Only analytic derivations and primary-source reads were performed. No fluid, spectral, calibration, or statistical experiment was run. The scalar inequalities above are explicit, but their availability is not a full fixed-universal-tolerance solution.

Ownership: constructor pursues uniform-beta scattering and a physical-space mixed bound; verifier pursues repeated near-resonant paths and leave-and-return; resume pursues a distinct nonlinear viscous route. This note owns the critical heat target and native relative-energy interface.
