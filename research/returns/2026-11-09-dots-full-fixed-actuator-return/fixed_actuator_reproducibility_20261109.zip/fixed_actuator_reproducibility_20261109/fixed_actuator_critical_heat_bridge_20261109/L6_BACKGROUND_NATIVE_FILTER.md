# Native filter with a physical L6 background and a critical heat remainder

Date: 2026-11-09. Analytic construction. No fluid propagation, numerical scattering, hardware experiment or completed universal-calibration controller is claimed. This is an explicit quantitative application of local Koch--Tataru theory, not a new generic Navier--Stokes regularity principle.

## 1. Precise operation

On the unit three-torus take smooth, real, mean-zero, divergence-free initial data u0=v0+w0. The actual equation during the filter is the UNFORCED native equation

    u_t=nu Delta u-P div(u tensor u).

No artificial viscosity, physical projection or linearization is substituted. Suppose rational upper bounds A>=max(1,||v0||6), K>=max(1,||u0||H3) and epsilon>=Hcal(w0) are supplied, where

    Hcal(f)^2=integral_0^infinity ||exp(t Delta)f||infinity^2 dt.

Set C=2^40. Choose

    epsilon<=nu/(32 C),
    0<delta<=min{1/nu, nu^3/(80 C A)^4}.                 (1)

Then the actual native strong solution exists on [0,delta]. Let v be the native nonlinear solution with initial data v0, not its linear heat image. The following estimates hold:

    ||u(delta)-v(delta)||infinity
        <=4 epsilon/sqrt(nu delta),                    (2)

and therefore the same bound holds in every finite physical Lp on this unit-volume domain. Also

    sup_(0<=t<=delta)||u(t)||H3
        <=2K max{1, 2^18 K^2 delta/nu}.                 (3)

The permitted waiting time does not involve ||v0||H3, Fzero(v0), or ||w0||H3. The total initial H3 norm still appears in the polynomial intermediate bound (3); it has not been erased from the resource ledger.

The input split is an admission condition, not an oracle. A preceding calibrated control word must actually prove its L6-background and small-Hcal-remainder bounds. This packet does not supply that robust word.

## 2. Explicit local critical-space constant

This section works first on R3, with unit viscosity. It will be applied to periodic extensions. For T>0 define

    ||z||X_T =
       sup_(0<t<=T) sqrt(t)||z(t)||infinity
       +sup_(x,0<R<=sqrt(T))
           [ |B_R|^-1 integral_0^(R^2) integral_(B_R(x)) |z|^2 ]^(1/2),

    ||F||Y_T =
       sup_(0<t<=T) t||F(t)||infinity
       +sup_(x,0<R<=sqrt(T))
           |B_R|^-1 integral_0^(R^2) integral_(B_R(x)) |F|.

Vector and tensor norms are Euclidean and Frobenius. For the retarded Oseen bilinear operator

    B(z1,z2)(t)
      =integral_0^t exp((t-s)Delta) P div(z1 tensor z2)(s) ds,

we claim the deliberately generous numerical bound

    ||B(z1,z2)||X_T <= C ||z1||X_T ||z2||X_T,
    C=2^40,                                            (4)

uniformly in T. The proof below pays the constant rather than treating the critical-space theorem as a numerical oracle.

### 2.1 The Oseen kernel

The R3 Gaussian is G_t=(4pi t)^(-3/2)exp(-|x|^2/(4t)). The kernel of exp(t Delta)P div is a first derivative of G_t plus a time integral from t to infinity of third derivatives of G_s. Differentiating the Gaussian and taking the full tensor Hilbert norm gives the safe bounds

    |D G_t(x)|<=t^-2 exp(-|x|^2/(8t)),
    |D^3 G_t(x)|<=t^-3 exp(-|x|^2/(8t)).

For the second inequality one bounds
[(r/sqrt(t))^3/8+3sqrt(3)(r/sqrt(t))/4]
exp(-r^2/(8t))/(4pi)^(3/2) by 1. If r<=sqrt(t), integrate s^-3 directly. If r>=sqrt(t), use

    t^-2 exp(-r^2/(8t))<=36 r^-4,
    integral_0^infinity s^-3 exp(-r^2/(8s))ds=64 r^-4.

Both regimes are contained in

    |Oseen(x,t)|<=2^12(sqrt(t)+|x|)^-4.                 (5)

Its L1 norm is at most 2^15 t^-1/2, since the radial integral of r^2/(sqrt(t)+r)^4 is 1/(3sqrt(t)). There is no hidden dependence on a driving field, as this filter is genuinely unforced.

### 2.2 Localization and pointwise estimate

Scale and translate a target cylinder to B_1(0) times (0,1); this is legitimate for every cylinder allowed in X_T. Split F into F_near supported in B_2 times (0,1) and F_far.

Write Y=||F||Y_T in these rescaled coordinates. Cover space by unit cubes centered at integer points. Each cube lies in a unit ball and carries time-integrated mass at most 6Y. For x in B_1, y outside B_2, the kernel is bounded by 2^12|x-y|^-4. The 343 cubes with maximum coordinate index <=3 cost at most 343*6*2^12 Y. In the maximum-coordinate shell n>=4 there are <=26n^2 cubes and distance >=n/2. Since sum n^-2<=2, their total costs at most 26*6*16*2*2^12 Y. Thus

    ||Oseen*F_far||Linf(B_1 times (0,1))<=2^25 Y.       (6)

The near source has total space-time L1 mass <2^10Y (125 covering cubes suffice). At (0,1), split its source time at 1/2. The early part costs at most 4*2^12*2^10Y=2^24Y by (5). The late part has L-infinity norm <=2Y, and the L1 kernel bound makes its integral <2^17Y. Together with (6), the normalized pointwise X_T contribution is <2^26Y.

### 2.3 The localized L2 estimate without a cutoff oracle

For the near source write, at its source time s,

    F_near(s)=(I-exp(s Delta))F_near(s)
                 +exp(s Delta)F_near(s).               (7)

This heat split replaces the compact Fourier cutoff in the usual proof. The high part satisfies

    ||(I-exp(s Delta))F_near(s)||Hdot^-1
       <=sqrt(s)||F_near(s)||2.

The inhomogeneous heat energy estimate therefore bounds the global space-time L2 norm squared of its gradient evolution by

    Y ||F_near||L1(space-time).

For the low part, its gradient evolution is exactly

    z(t)=grad exp(t Delta) integral_0^t F_near(s) ds.

Integration in t, or first performing it for finite smooth sources, gives

    integral_0^1 ||z(t)||2^2 dt
     = Re integral_0^1 <F_near(s),
          [exp(2s Delta)-exp(2 Delta)]
            integral_0^s F_near(theta)dtheta> ds.        (8)

Both heat convolutions on the right have L-infinity norm <=2^18Y. To see this, use cubes of side sqrt(s) for exp(2s Delta), and unit cubes for exp(2 Delta). Each cube has time-integrated mass <=6s^(3/2)Y or <=6Y. The Gaussian shell sum is bounded by

    6[1+26 sum_(n>=1) n^2 exp(-n^2/32)] <2^18.

Indeed, integration over [n-1/2,n+1/2] gives the safe bound sum n^2 exp(-n^2/32)<=1296. This proves that (8) is at most 2^19Y||F_near||1.

Leray and tensor divergence cost no extra L2 factor relative to the full gradient norm. Adding high and low parts, using ||F_near||1<2^10Y, and then adding (6), the normalized local L2 contribution is <2^26Y. The pointwise and local contributions together are <2^27Y. Taking 2^40 in (4) leaves ample room.

Finally,

    ||z1 tensor z2||Y_T <=||z1||X_T ||z2||X_T

by pointwise multiplication and Cauchy--Schwarz on each cylinder. This completes (4). The argument is exactly the established Koch--Tataru localization/critical-space mechanism with a fully displayed conservative ledger. It is not presented as a new general mapping theorem.

## 3. The admitted initial heat extension

The unit-torus heat bounds previously established in L6_NATIVE_INTERFACE.md give

    ||exp(t Delta)v0||infinity<=2t^-1/4 A.

Thus its X_T pointwise part is <=2A T^1/4 and its local L2 part is <=sqrt(8)A T^1/4. Consequently

    ||heat(v0)||X_T<=5A T^1/4.                         (9)

For w0, heat-kernel contraction makes ||heat(w0)(t)||infinity nonincreasing in t. Hence

    t||heat(w0)(t)||infinity^2
       <=integral_0^t ||heat(w0)(s)||infinity^2 ds
       <=epsilon^2.

Its local space-time component is also <=epsilon, so

    ||heat(w0)||X_T<=2epsilon.                        (10)

These hold for periodic extensions on R3. No finite total R3 energy is assumed. The heat equation of the periodic extension agrees with the torus heat equation.

## 4. Native nonlinear contraction and endpoint difference

Rescale viscosity by U(tau)=u(t)/nu, tau=nu t, and let T=nu delta. Equations (9)-(10) and (1) imply

    ||heat(U0)||X_T
      <=5(A/nu)(nu delta)^1/4+2epsilon/nu
      <=1/(8C).

The mild fixed point contracts on the ball ||U||X_T<=1/(4C): its self-map reserve is 3/4 of the radius and its Lipschitz factor is at most 1/2. The background V separately satisfies ||V||X_T<=1/(8C).

Their difference W obeys

    ||W||X_T
       <=2epsilon/nu
          +C(||U||X_T+||V||X_T)||W||X_T
       <=2epsilon/nu +(3/8)||W||X_T.

Therefore ||W||X_T<4epsilon/nu. The pointwise part at T yields (2). Periodicity follows by translation uniqueness in this same contraction class.

For smooth data the mild solution agrees initially with the ordinary local strong solution. On every compact subinterval away from zero, its velocity is bounded in L-infinity. The standard Serrin continuation argument then precludes an earlier strong-solution singularity. The next section supplies a fully polynomial H3 bound, rather than leaving intermediate regularity as a qualitative assertion.

## 5. Complete polynomial H3 bound

An elementary explicit tame estimate on the unit torus is

    ||u tensor u||H3<=128||u||infinity ||u||H3.          (11)

One can verify it without an unspecified interpolation constant. Put M=||u||infinity, a=||Du||6, b=||D^2u||3, c=||D^3u||2. Periodic integration by parts gives

    a^2<=6Mb,    b^2<=3ac,

so ab<=18Mc. A second-order version gives ||Du||4^2<=6M||D^2u||2. The ordered Leibniz rules then bound the third derivative by (2+6*18)Mc=110Mc, the second by 14M||D^2u||2, and lower orders by still smaller constants. The Bessel H3 norm is the binomial sum of these ordered derivative squares, proving (11) with 128.

Let Y=||u||H3. Its native energy inequality and (11) give

    Y'<=2^13 ||u||infinity^2 Y/nu.                     (12)

The crude Fourier embedding ||u||infinity<=2Y implies Y'<=2^15Y^3/nu. Therefore Y<=2K up to

    t_* = min{delta, nu/(2^18 K^2)}.

For later times use the actual critical-space solution, not the crude embedding:

    ||u(t)||infinity^2 <=nu/[16 C^2 t].

Equation (12) gives Y'<=Y/t because C=2^40. Integrating from t_* proves (3). The same proof applies to the smooth background with its own supplied initial H3 norm if that bound is needed. This norm affects intermediate resources, not the permitted waiting time.

All estimates can first be performed on smooth approximations. The mild critical-space solution and the strong solution coincide, so neither regularity nor uniqueness is assumed as the conclusion of an a priori bootstrap.

## 6. A nontrivial amplitude-versus-Fourier distinction

For N>=1 let

    v0=e1 cos(2pi x3+N cos(2pi x2)).

It is divergence-free, mean zero, and ||v0||6<=1 regardless of N. Its Fourier absolute mass and Sobolev norms need not stay bounded as N grows. For n>=2 add

    w0=epsilon(2pi n)e2 cos(2pi n x1).

Here Hcal(w0)=epsilon/sqrt(2)<=epsilon. The two native cross advections are nonzero, so the full solution is not merely a passive scalar or linear heat example. The admissible filter interval (1) is independent of N and n, while (3) honestly retains their effect through the total initial H3 norm.

This is an analytic input family, not an executed PDE experiment. It illustrates precisely why replacing a Fourier-absolute background bound by a physical L6 bound can matter.

## 7. Compiler, costs and remaining gap

Given rational bounds A, K, nu and epsilon satisfying (1), the waiting field is exactly zero. Choosing delta as the minimum of the two rational quantities in (1) is a finite rational operation. Every numerical resource displayed is polynomial in A, K, nu, nu^-1 and the requested output tolerance.

For an L6 or L-infinity reset error eta, it suffices additionally to require

    epsilon<=eta sqrt(nu delta)/4.

For the displayed factory, sqrt(nu delta) is rational on either branch: it is 1 or nu^2/(80CA)^2. Thus no real-root oracle is needed. The conservative constants are enormous; no practical runtime or control claim follows.

The input Hcal certification is not free. The preceding lemmas Hcal<=4(Hdot^-1)^1/4(L6)^3/4 and Hcal<=8H1 provide possible paid routes, but an adversarially calibrated repeated word still needs to produce the required split. Single-shear H3-to-L6 bounds cannot be iterated as full L6-to-L6 bounds. A fixed-word low-mode floor cannot be removed merely by changing the continuation norm.

The filter's reference v(delta) is its own nonlinear background solution. It is not asserted close to v0 without an additional regularity/time charge, nor is this a projection onto a known low-dimensional state. No generic fixed-universal-calibration theorem is claimed.

## 8. Primary prior and verification status

Primary source read directly: Koch--Tataru, Well-posedness for the Navier--Stokes equations, Theorems 2--3 and Lemmas 3.1--3.2, https://math.berkeley.edu/~tataru/papers/nas.pdf . Its local critical-space theorem is the exact methodological prior. The quantitative heat split (7), constants, viscosity allocation, physical-L6 background, difference endpoint and polynomial H3 bookkeeping above are the present programme's explicit specialization.

Germain--Pavlovic--Staffilani, https://arxiv.org/html/math/0609781 , supplies stronger known analyticity/derivative context but is not needed as an unpriced numerical constant in this proof. The companion native Wiener filter credits the periodic analytic-Wiener literature separately.

This note is author-derived and awaits a scoped mathematical challenge. No independent constant replay, PDE execution or external novelty assessment is implied.
