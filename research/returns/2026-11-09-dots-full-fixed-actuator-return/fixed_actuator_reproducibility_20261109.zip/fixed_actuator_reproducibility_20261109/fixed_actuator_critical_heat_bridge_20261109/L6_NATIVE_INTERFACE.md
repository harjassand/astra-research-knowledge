# L6 critical-heat and native nonlinear interface

Date: 2026-11-09. Analytic continuation of PROOF_NOTE.md (SHA c7742c1042817cede5395ee8b05600b339688c6e9b7960abe17bac3542a4603c). No propagation, scattering computation, or full calibrated controller is claimed. The first two estimates are unconditional analytic lemmas for the stated solution classes. Section 3 is explicitly a sufficient condition whose native linear hypotheses remain unproved.

## 1. A weaker amplitude target suffices

Use the mean-zero unit-torus norms from PROOF_NOTE.md. Write V=||f||6 and m=||f||Hdot^-1. Then

    Hcal(f) <=4 m^(1/4) V^(3/4).                         (1)

Thus a physical L-infinity bound is not required to convert negative-norm mixing into critical heat smallness.

Here is an explicit heat-kernel ledger. For 0<t<=1, the unit-volume periodic heat kernel K_t is positive with L1 norm 1, and

    ||K_t||infinity
      <= [1+1/sqrt(pi t)]^3 <=8 t^(-3/2).

The first inequality follows by bounding the positive decreasing one-dimensional Gaussian sum by its integral. Young's convolution inequality and interpolation give ||K_t||_(6/5)<=sqrt(2)t^(-1/4). For t>=1, subtract its constant mode. The remaining Fourier sum is at most 8 exp(-18t), by 4pi^2>=36 and splitting half of the spectral gap. This is at most 2t^(-1/4). Consequently for all t>0,

    ||exp(t Delta)f||infinity <=2 t^(-1/4) V.

Combine with the previously proved bound 4t^(-5/4)m. Splitting at t0=2m/V yields

    Hcal(f)^2
       <=8 V^2 sqrt(t0)+(32/3)m^2 t0^(-3/2)
       =(32 sqrt(2)/3) m^(1/2)V^(3/2)
       <16 m^(1/2)V^(3/2).

This proves (1). The zero cases are immediate. As before, Hcal dominates the caloric BMO^-1 norm of the periodic extension, so established small-BMO continuation applies after a sufficiently small output is actually reached.

A single-shear H3-to-L6 estimate is not an L6-to-L6 estimate and cannot be iterated as one. Likewise sequence-space Jacobi dispersion is not already the physical L6 bound. The constructor's proposed Jost multiplier route is a separate, currently author-level hypothesis.

## 2. Native relative energy needs only L6

Let v be the actual smooth linear controlled path with the same prescribed drift b and viscosity nu as the nonlinear solution u. Put w=u-v, y=||w||2^2, D=||grad w||2^2, and ||u0||2<=K. Smooth mean-zero divergence-free solutions satisfy the same cancellations as in PROOF_NOTE.md. The remaining contributions obey

    (1/2)y'+nu D
       <=||v||6 ||w||3 sqrt(D)+||v||4^2 sqrt(D).

An explicit safe torus Sobolev constant is

    ||w||6<=32||grad w||2.

For completeness, extend the periodic w to [-1,2]^3, multiply by a cutoff equal to 1 on [0,1]^3, bounded by 1, with derivative at most 2 in each coordinate. The elementary R3 Sobolev inequality ||g||6<=2||grad g||2, periodic Poincare ||w||2<=(2pi)^-1||grad w||2, and the 27 copied cells give a constant below 32. The argument applies to |w| by the usual weak gradient inequality and hence to vector fields.

Interpolation gives ||w||3<=sqrt(32)y^(1/4)D^(1/4). Young's inequality with nu D/4 for each contribution yields

    y'+nu D
       <=(2^14/nu^3)||v||6^4 y +(2/nu)||v||4^4.          (2)

The coefficient 2^14 safely exceeds 27*32^2/2. Hence

    y(t)<=(2/nu) integral_0^t ||v(s)||4^4
          exp[(2^14/nu^3) integral_s^t ||v(r)||6^4 dr] ds. (3)

This estimate also holds as a relative-energy inequality for an energy-class Leray solution tested against smooth v. It contains no derivative of b or v. It is not a strong-solution regularity theorem.

Since ||v||2<=K, interpolation also gives ||v||4^4<=K||v||6^3. If ||v||6<=L K throughout [0,delta], then

    y(delta)<=2 L^3 K^4 delta/nu
              *exp(2^14 L^4 K^4 delta/nu^3).

In particular, for epsilon>0, the two explicit requirements

    delta<=nu^3/(2^15 L^4 K^4),
    delta<=nu epsilon^2/(8 L^3 K^4)

imply ||u(delta)-v(delta)||2<=epsilon. These constants are conservative. If K=0, both paths vanish.

The missing step cannot be hidden here: L2 closeness plus (1) does not bound the error in Hcal without an L6 bound on that error. Nor does (3) establish regularity before switch-off.

## 3. A precise sufficient native parabolic estimate

The following conditional statement identifies an operation that WOULD close a native strong pulse without actuator-derivative losses. Let U_b(t,s) be the actual linear viscous Leray evolution. Suppose on an interval of length delta it satisfies, with constants independent of the pulse action and every allowed calibration,

    ||U_b(t,s)f||6 <=C0||f||6,                            (4)
    ||U_b(t,s) P div F||6
        <=C1[nu(t-s)]^(-3/4)||F||3.                     (5)

The tensor norm in (5) is the pointwise Euclidean/Frobenius norm. For K6=||u0||6>0, the mild Navier-Stokes map is a contraction on the ball

    sup_(0<=t<=delta)||u(t)||6 <=2 C0 K6

provided

    delta <=nu^3/(32 C0 C1 K6)^4.                        (6)

Indeed, the nonlinear bilinear operator has norm at most

    4 C1 nu^(-3/4) delta^(1/4)

because the time singularity is (t-s)^(-3/4). At radius 2C0K6, (6) makes its radius product at most 1/4, so the self-map and contraction estimates follow. Standard mild/strong matching for smooth data and a smooth drift then gives the strong solution throughout this interval; an L-infinity-in-time L6 bound is a Serrin continuation bound. Approximation can supply the usual continuity at the left endpoint.

Neither (4) nor (5) has been proved uniformly for the calibrated native Leray pulses in this packet. Even a uniform inviscid Lp group estimate does not automatically imply them. A Trotter product with a factor C_p for each shear substep produces C_p^n, which is not a uniform bound as the mesh is refined. A genuinely shear-adapted equivalent norm or a controlled parabolic kernel is required. The nonlinear contraction argument is standard Kato/Serrin machinery, not claimed as a new general Navier-Stokes theorem.

This is a precise target, not a new assumption in the controller's claimed scope. It could remove the old delta*action^6 incompatibility if earned for actual viscous pulses, but earning it remains the research problem.

## 4. Current obstructions and published comparison

The verifier has now extended the adversarial phase/path argument to any FIXED cyclic word length when phase and transverse error may vary independently by invocation. A selected fixed Fourier coefficient survives for some admissible phases; therefore not only Fminus1 but also Hdot^-1 and Hcal retain a positive floor. The phase argument retains leave-and-return paths. It is a fixed-word obstruction, not a no-go for length growing with the requested precision or for later physical dissipation.

The constructor's proposed uniform-beta sequence-space dispersion and physical Jost multiplier work should be judged against this word obstruction. Neither a single entry estimate nor one-shear L6 control is an all-word endpoint certificate.

Primary sources read directly:
- Koch and Tataru, https://math.berkeley.edu/~tataru/papers/nas.pdf, Theorem 2 and the caloric BMO^-1 norm.
- Germain, Pavlovic and Staffilani, https://arxiv.org/html/math/0609781, higher derivatives and analyticity of small-BMO solutions.
- Daniel Goodair, https://arxiv.org/html/2507.00787v1, especially the introduction and Sections 1.4/2.2. This work treats the SAME distinction between pure transport under Leray projection and transport-stretching noise. It proves closed Sobolev noise estimates and local strong stochastic solutions, not a pulse-action-independent physical Lp/parabolic bound. Its coefficient constants depend on smooth norms of the driving fields; it cannot be imported as (4)-(5).
- The existing linear mixing-to-dissipation results and the audited short-pulse BCA estimates remain complementary, not proofs of the new conditional hypotheses.

The exact R3 Sobolev and Kato/Serrin estimates used above are established analysis. The incremental research contribution is the explicit interface and its cost/obstruction separation for this controlled-fluid programme, not a novelty claim for interpolation or relative energy.

## 5. Resource and claim ledger

No fluid, spectral, random-control or nonlinear numerical run occurred. Only algebra, primary-source reads and persistence were performed. Equations (1)-(3) have explicit finite constants. Equations (4)-(5) are unpaid hypotheses. Published BMO smallness and higher-derivative constants are not numerically extracted. There is no fixed-universal-tolerance stabilization theorem in this note.
