# Native heat-reference endpoint and legal shear--heat block

Date: 2026-11-09. Analytic addendum to the frozen L6_BACKGROUND_NATIVE_FILTER.md (c6f87541b7e2108cf8de8bdeffa2e59bb30e4af1b202b8a424796b6d8f9ec443) and STRONG_ENDPOINT_RESET.md (f3bb8bf29ffc06487d1ddcb02de1384eb9156d7d77dbc1a5708fe36ad9492c2f). No existing proof bytes are changed.

## 1. The background has a paid L6 bound

Under the parent filter hypotheses, the actual unforced nonlinear background v obeys

    sup_(0<=t<=delta)||v(t)||6<=2A,                     (1)

where A>=max(1,||v0||6). This is not a maximum principle. It follows from ordinary local heat-Kato contraction with explicit constants.

The Euclidean Oseen kernel bound from the parent proof gives, by Young's inequality and periodization, for 0<nu*t<=1,

    ||exp(nu*t*Delta)P div F||6
       <=2^24 (nu*t)^(-3/4)||F||3.                    (2)

A conservative constant ledger is as follows. Its R3 L^(6/5) norm is below 2^15 t^(-3/4), by the kernel bound 2^12(sqrt(t)+|x|)^(-4) and the radial integral
integral_0^infinity r^2/(1+r)^(24/5) dr <=1/3.
For periodic convolution, the 27 nearest translated cubes cost less than 2^20 t^(-3/4). The remaining maximum-coordinate shells cost below 2^21 because their distances are at least half their index and sum_(n>=2)n^-2<=1. Since t<=1, all of this fits within 2^24 t^(-3/4). Tensor and vector norms remain Frobenius/Euclidean.

Heat itself is L6-contracting. Thus the native mild map on a ball sup||v||6<=2A has bilinear constant at most

    4*2^24 nu^(-3/4) delta^(1/4).

It contracts whenever delta<=nu^3/(32*2^24 A)^4. This is implied by the stronger parent choice delta<=nu^3/(80*2^40 A)^4. The resulting native solution agrees with the parent background by local strong uniqueness, proving (1).

## 2. Native nonlinearity versus literal heat

The true background is not silently replaced by heat. Its difference from heat is the exact Duhamel term

    v(delta)-exp(nu*delta*Delta)v0
       =-integral_0^delta exp(nu(delta-s)Delta)
             P div(v tensor v)(s) ds.

The unit torus has volume 1, so (1) implies ||v tensor v||2=||v||4^2<=4A^2. The fractional Fourier heat estimate from STRONG_ENDPOINT_RESET.md gives

    ||exp(nu*t*Delta)P div F||H^(3/4)
        <=2(nu*t)^(-7/8)||F||2.

Integrating the singularity, which is strictly integrable, yields the paid bound

    ||v(delta)-exp(nu*delta*Delta)v0||H^(3/4)
        <=64 A^2 nu^(-7/8) delta^(1/8).               (3)

This is the key positive time exponent. The analogous direct H1 kernel would have exponent1 and cannot be integrated from an L2 source by the same argument. The choice H^(3/4) is deliberate: it still feeds a single subsequent shear into the critical Wiener norm with a uniform constant.

## 3. Full nonlinear filter compared to heat of the admitted background

Combining (3) with the previously proved difference estimate gives

    ||u(delta)-exp(nu*delta*Delta)v0||H^(3/4)
       <=32 epsilon/(nu delta)^(7/8)
          +64 A^2 nu^(-7/8) delta^(1/8).              (4)

For a requested error eta>0, the entirely rational sufficient choices are

    delta <=min{1/nu, nu^3/(80*2^40 A)^4,
                         eta^8 nu^7/(128^8 A^16)},
    epsilon<=min{nu/(32*2^40), eta*nu*delta/64}.        (5)

The first term of(4) is at most eta/2 because nu*delta<=1; the second is at most eta/2 by the third waiting-time constraint. Therefore the left-hand side is <=eta.

The full native state also has the endpoint smoothing bound

    ||u(delta)||H3<=16||u0||2/(nu delta)^(3/2),

and its intermediate H3 cost is polynomial as stated in the parent theorem. Thus the waiting stage has both a paid linear-reference error and a genuine Sobolev reset.

## 4. How this can realize one shear--heat block

Suppose a separately certified native short pulse applied to f approximates the ACTUAL calibrated inviscid shear U_s f in H1 with error at most rho. Suppose also a proved action-uniform bound

    ||U_s f||6<=A

is available. These are separate inputs: the current physical-Lp construction is a candidate for the second, and the audited BCA short-pulse machinery supplies the first after its required duration/cost allocation.

Decompose the true post-pulse state as

    u0=v0+w0, v0=U_s f.

The already proved Hcal<=8H1 inequality makes epsilon=8rho an admissible bound. Following the real short pulse by the unforced native wait allocated in(5) produces

    ||actual block output-exp(nu*delta*Delta)U_s f||H^(3/4)<=eta.

The wait time is independent of the shear action s once the action-uniform A is paid. The native pulse duration can be chosen separately after s is known. This avoids identifying the short pulse duration with the viscosity/filter duration, which was the earlier source of the delta*action^6 incompatibility.

No fictitious heat evolution was performed: heat is an analysis reference, and(4) pays the actual nonlinear difference. No extra viscosity was introduced. Native energy gives the L2 bound used in the endpoint H3 reset.

## 5. Remaining composition and verification obligations

A robust finite shear--heat word is not proved here. In particular:
- the action-uniform native inviscid H3-to-L6 estimate must be checked at its stated physical-space scope;
- the linear word must be uniformly contracting for every allowed transverse error and phase, retaining all leave-and-return paths;
- pulse durations, actual H3 input bounds, filter intervals and every approximation error must be allocated sequentially without circular or super-polynomial growth;
- the final critical-smallness continuation and terminal-time requirements retain their existing costs.

A potentially useful feature is that the linear shear and literal heat stages are L2 contractions, so already-paid L2 approximation errors cannot be amplified by later LINEAR blocks. This does not by itself prove the active/resonant sector decomposition or the nonlinear implementation.

The local nonlinear theorem, (1)-(5), uses only established heat-Kato/critical-space methods with displayed constants. The three-stage robust composition is owned by the separate return/composition worker. There has been no PDE propagation, numerical control optimization, or external novelty claim.
