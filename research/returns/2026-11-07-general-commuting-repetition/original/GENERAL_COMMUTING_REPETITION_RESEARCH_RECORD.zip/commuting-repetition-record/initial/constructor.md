# Independent constructor: exact mass obstruction and support repair

6 November 2026, Australia/Brisbane. Initial independent report: no other new researcher's construction or conclusion was read before this file. The principal supplied source logistics only. No descendants were created.

## Strongest result and scope

The exact pointwise positive-factorization mechanism has a sharp structural boundary. **Disjoint unions of vertex-disjoint complete bipartite blocks are exactly the masks for which subexponential one-sided mass can be guaranteed uniformly over all finite-tracial tested strategies, even allowing arbitrary joint factorizations of tensor powers.** Outside this class there is a legal classical finite-tracial strategy with tested success probability exactly one such that every exact factorization has

\[\max(G_A,G_B)\ge(\sqrt5/2)^t.\]

This closes the tensor-factorization loophole left open in §7 of the supplied `ROOT_WEIGHTED_MASS_REFINEMENT.txt`, at the exact pointwise-mask interface. It does not disprove general quadratic repetition, nor lower-bound the actual resolvent error. I give an exact state-dependent LP, a standard nuclear-norm certificate proving the obstruction, a value-preserving nuisance-register test, and a constructive support/smoothing repair.

A positive scalar consequence is also available. Under the supplied no-answer-cost near-perfect inequality, block/projection games satisfy

\[\Pr\{W\ge\lceil(v+\delta)n\rceil\}\le
\exp[-2^{-77}\delta^5 n/\epsilon^3],\qquad0<\delta\le\epsilon=1-v.\tag{T}\]

This alphabet-free threshold theorem has quadratic-gap rate when δ is a fixed fraction of ε. It remains conditional on S_actual/R/H/Lin; its fifth power in δ is not claimed optimal.

## Sources and acquisition status

Capital root: `/Users/harjas/Documents/Codex/2026-10-27/astra-capital-scientific-curator-20261027/work/astra-research-knowledge/`.

I read the N443 JSON including material updates, N445/N446 JSONs, and both complete weighted-mass notes. The notes pin revision `0451552424b4679fa9a73faf5849ea5a4af21cf6`. I extracted the actual R/H, near-perfect and scalar-wrapper texts from indexed HTML; hashes match their card pins. See [constructor_sources/manifest.json](../constructor_sources/manifest.json):

| Source | SHA256 |
|---|---|
| R, 307 lines | `2acf3c9e5d067de16c873e16bf0fbe52e6becdd47c6db55a3fd526ac086e8627` |
| H, 264 lines | `0893936c7ab79d8a5b3fac87af28a90e4e7e9b45d52bd23b20d4b94629f02475` |
| Near-perfect, 292 lines | `55c2956bb771d630307639a4fd5ff46ea772b484985499dcd765d34f9183cbce` |
| Threshold wrapper | `e2e346f5da05acaf90aedee56ce94b605b0677d9470ac8cf20946637941f67df` |
| Event wrapper | `921bfb00364c1a3865920eafc25c690364812da4e6e5c245e8c7449960f6f818` |
| Composition | `325437631d3da2492a90575f0114d214192f379740a702681ab759c63601a81e` |

R/H identities relevant to the proposed replacement use positivity, bounded tested factors depending only on tested questions, finite classical exposure, exact norm identities and bounded conditional losing observables. Product-winning structure is used later in greedy selection. The actual sampler/precision/toy texts were also extracted at their pinned hashes; I inspected the model, theorem, operational event estimate and costs, but did not independently verify the entire all-input POVM construction. Repetition conclusions here therefore remain conditional. The finite-dimensional obstruction below needs none of these imports.

## 1. Exact marginal-mass invariant

Fix a finite 0/1 mask M, probabilities P,Q, and an exact bounded positive factorization

\[M_{ab}=\sum_k\lambda_k f_k(a)g_k(b),\quad\lambda_k\ge0,
\quad0\le f_k,g_k\le1.\]

Its masses are \(G_A=\sum_k\lambda_k P(f_k)\), \(G_B=\sum_k\lambda_k Q(g_k)\). In the finite-tracial interface take \(P_a=\chi(F^a,I)\), \(Q_b=\chi(I,H^b)\). Thus this endpoint bound depends only on the two marginal distributions, even if the tested joint correlation is quantum.

Let R range over nonempty rectangles S×T inside the support of M. The optimum over all such fuzzy factorizations is exactly the finite LP

\[\begin{split}
\mathsf L(M;P,Q)=\min z:\quad&\sum_{R\ni(a,b)}w_R=1\quad(M_{ab}=1),\\
&\sum_Rw_R P(S_R)\le z,\quad\sum_Rw_R Q(T_R)\le z,\quad w_R\ge0.
\end{split}\tag{LP}\]

Proof: hard factors are allowed. Conversely layer cake gives
\[f(a)g(b)=\int_0^1\int_0^1 1_{f(a)\ge s}1_{g(b)\ge t}\,ds\,dt.\]
There are finitely many threshold intervals. Each nonempty rectangle lies in the mask support, because all summands are nonnegative. Before dropping empty rectangles, the loads integrate to the original loads; dropping empties decreases them. Hence hard factors achieve no worse mass. Each nonempty rectangle weight is at most one, so the finite feasible polytope is compact and an optimum exists. The zero mask has optimum zero.

The dual is
\[\max\sum_{M_{ab}=1}u_{ab},\qquad
\sum_{(a,b)\in S\times T}u_{ab}\le sP(S)+(1-s)Q(T),\quad0\le s\le1,\tag{D}\]
where edge variables u may be signed. This is a local marginal-cost variant of established fractional biclique partition machinery, not a new factorization theory.

For \(T=\left(\begin{smallmatrix}1&1\\0&1\end{smallmatrix}\right)\), P=Q=(1/2,1/2), the one-step optimum is 5/4. A primal uses half weight on each rectangle {0}×{0,1}, {0}×{0}, {0,1}×{1}, {1}×{1}. A dual has s=1/2, \(u_{00}=u_{11}=1/2,u_{01}=1/4\). This is a one-step optimum; multiplicativity of this LP is not assumed.

## 2. Tensorizing nuclear certificate

For every exact bounded positive factorization,

\[\|D_P^{1/2}MD_Q^{1/2}\|_*\le\sqrt{G_AG_B}\le\max(G_A,G_B).\tag{N}\]

Proof: the matrix is \(\sum_k\lambda_k(D_P^{1/2}f_k)(D_Q^{1/2}g_k)^T\). Nuclear norm of a rank-one term is the product of Euclidean norms. Since f²≤f and g²≤g, triangle inequality and Cauchy–Schwarz give
\[\|D_P^{1/2}MD_Q^{1/2}\|_*\le\sum_k\lambda_k\sqrt{P(f_k)Q(g_k)}\le\sqrt{G_AG_B}.\]
Zero marginal entries cause no problem. This is standard nuclear-factorization machinery. Its ordinary nuclear norm tensorizes exactly; no nonnegative-rank or fractional-partition multiplicativity is needed.

For an entirely explicit witness let \(W=\left(\begin{smallmatrix}2&1\\-1&2\end{smallmatrix}\right)\). Then WᵀW=5I and ⟨W,T⟩=5. The orthogonal dual witness \(W^{\otimes t}/5^{t/2}\) gives
\[\|T^{\otimes t}/2^t\|_*=(\sqrt5/2)^t.\tag{N-T}\]
This applies to every global exact factorization of the tensor power.

For the source's biased full-support marginals P=(1−r,r), Q=(r,1−r),
\[A_r=\begin{pmatrix}\sqrt{r(1-r)}&1-r\\0&\sqrt{r(1-r)}\end{pmatrix},
\quad\|A_r\|_*^2=(1-r)(1+3r).\]
The last identity follows from \(\|A\|_*^2=\|A\|_F^2+2\det A\) for this positive-determinant 2×2 matrix. Hence with product scalar correlation
\[p_t=(1-r^2)^t,\qquad\max(G_A,G_B)\ge[(1-r)(1+3r)]^{t/2}.\tag{B}\]
Taking r=t^(−3/4) yields p_t→1 while the lower bound is exp((1+o(1))t^(1/4))→∞. Thus even arbitrary tensor factorizations cannot make the exact-mask mass automatically approach one from high tested success.

## 3. Sharp structural boundary

Call M a block mask if its nonisolated connected bipartite components are complete bipartite graphs.

**Theorem.** For a fixed finite mask M these are equivalent:

1. M is a block mask.
2. For every t and every finite-tracial pair of tested POVMs with mask M^⊗t, some exact bounded positive factorization has G_A,G_B≤1.
3. The same assertion holds with a uniform exp(o(t)) bound, even when the factorization may depend on the whole strategy and factor all t coordinates jointly.

Proof: disjoint block row/column supports give both sums of merged effects ≤I, proving 1⇒2⇒3. If a connected bipartite component is not complete, the first four vertices of a shortest path between a nonadjacent row and column give an induced three-edge path, hence an induced T after relabeling. Restrict all answer effects to those two rows and columns. For t copies use the commutative algebra C^(2^t), uniform trace, σ=1, and let both players output the same uniformly shared bit string. Then
\[\chi(F^u,H^v)=2^{-t}1_{u=v}.\]
Both diagonal entries of T are accepted, so tested p=1. The active marginals are uniform. Restrict any exact full-mask factorization to these active answers and apply (N-T). The mass is at least (√5/2)^t, contradicting 3. ∎

This is maximality at the exact pointwise-mask interface, not maximality of all possible repetition methods. It leaves open extra positive-gap/selected-instance hypotheses, support quotients, approximate filters, and sharper entropy endpoints. In the commutative witness, hard merged effects are projections, so the actual entropy potentials can vanish. A large bound p log(G/p) does not force large actual telescope error.

## 4. Value-preserving nuisance test

Given any game G, append one answer bit per player and define H by
\[V_H(x,y,a,u,b,v)=V_G(x,y,a,b)1_{u\le v}.\]
For every n, \(\omega_{co}(H^n)=\omega_{co}(G^n)\): forgetting bits locally maps H strategies to G strategies with at least the same success; appending constants u=0,v=1 maps G strategies back exactly. Both maps are legal commuting POVM operations.

Instead append independent shared equal uniform bits to any strategy. This preserves the original tested event, p and conditional live loss α. Nevertheless every exact factorization of the enlarged tested mask satisfies
\[\max(G_A,G_B)\ge p(\sqrt5/2)^t.\tag{I}\]

Proof: for each accepted original tested answer pair (a,b), restrict the factorization to that pair's nuisance variables. Write \(U_{k,a}=2^{-t}\sum_u f_k(a,u)\), \(V_{k,b}=2^{-t}\sum_v g_k(b,v)\). The rank-one proof of (N-T) gives \(\sum_k\lambda_k\sqrt{U_{k,a}V_{k,b}}\ge(\sqrt5/2)^t\). Multiply by the original accepted joint mass h_ab and sum. For each atom, Cauchy–Schwarz and domination of accepted submarginals by full marginals give at most √(P(U_k)Q(V_k)); Cauchy–Schwarz over atoms then gives √(G_AG_B). Averaging tested questions or flags uses another Cauchy–Schwarz and gives (I). ∎

Thus raw exact-mask mass is not a semantic game invariant. The example is strategically removable, which is the point: a credible general invariant must survive removal of such nuisance structure.

## 5. Constructive support and smoothing repair

Let θ_c∈[0,1] be a tested filter depending only on tested questions/answers, with original tested joint law h_c. For another bounded filter θ̃ define
\[\eta=E_c\sum_{a,b}h_c(a,b)|\theta_c(a,b)-\widetilde\theta_c(a,b)|.\]
Then |p−p̃|≤η; the full unnormalized live question/answer subprobability tables differ in l1 by at most η. If η<p, normalized conditional laws differ in half-l1 TV by at most η/p. If η=0, the event mass and full conditional live table are exactly unchanged.

Proof: finer live probabilities are nonnegative and sum to each coarse tested joint mass, so summing the absolute filter difference proves the unnormalized estimate. Normalization adds at most |p−p̃|, giving half-l1 TV ≤(η+|p−p̃|)/(2p)≤η/p. Positivity also implies χ(G,K)=0 whenever G≤F,K≤H and χ(F,H)=0. Hence unused coarse support can be changed without affecting any fine observable; total expectation preserves this through the exposure. ∎

For the p=1 correlated triangle, replace T^⊗t by equality on the used strings: η=0 and both masses≤1. For the biased product example replace the entire filter by the all-ones rectangle: both masses=1 and η=1−p_t. These actually repair both obstruction families. For rare events the needed error is relative, η≪pε; a small absolute error is insufficient.

**Conditional filter transfer.** Under the named R/H, operational S_actual and Lin premises, suppose θ̃ has masses≤B and η/p=β<1. Put
\[\widehat\tau=\frac{\log(\max\{1,B\}/p)+\log(1/(1-\beta))}{m}.\]
Then
\[\epsilon\le\alpha+\beta+K[\sqrt{\alpha+\beta}\,\widehat\tau^{1/4}+\sqrt{\widehat\tau}],\quad K=2^{16}.\tag{F}\]
Indeed p̃≥p(1−β), conditional loss α̃≤α+β, the endpoint budgets are p̃ log(B*/p̃), and full-question density≤1/p̃ because θ̃≤1. The R/H and operational reconstruction are unchanged. Factors must depend on tested questions only, not fresh live inputs. Compression still costs coefficient mass in accuracy; no efficient compiler follows. Transfer to arbitrary commuting tables requires uniform error/mass bounds on finite-tracial approximants, possibly with different filters; Lin alone does not supply them.

One decisive sufficient operation is: uniformly for every repeated strategy and proper tested C with p>0, find such a filter satisfying
\[\eta\le\epsilon p/8,\qquad\max\{1,B\}\le e^{\kappa\epsilon t}.\tag{O}\]
Together with the source interfaces and closure under tensor amplification, this would imply
\[\omega_{co}(G^n)\le\exp[-2^{-82}\epsilon^2 n/(1+2\kappa)]\quad(n\ge1).\tag{Q-F}\]

Proof: greedy testing with cutoff ε/2 gives t≤2L/ε, p≥Θ, α≤ε/2 for L=log(1/Θ), if Θ exceeds the proposed bound. Then m≥n/2 and
\[\widehat\tau\le2(1+2\kappa)L/n+\epsilon/(2n),\]
using log(1/(1−β))≤2β. Set a=2^(−80), γ=a/[4(1+2κ)]. If L<γε²n and n≥1/(aε), the budget is ≤aε² and α+β≤5ε/8. Substitution into (F) gives ratio to ε at most 5/8+K√(5/8)a^(1/4)+K√a<1, a contradiction. The length cutoff is strategy independent; independent tensor products of an entire original n-copy strategy have probability Θ^r, so taking r-th roots removes the cutoff. Fixed-p Lin transfer is the same scalar-continuity limit as in the source. ∎

**(O) is open for general games.** The real next operation is a relative low-mass approximation to a rare conditioning event after semantic nuisance removal. Better exact pointwise factorizations cannot acquire it uniformly.

## 6. Alphabet-free threshold consequence

Assume uniformly for all repeated commuting strategies and proper C that
\[\epsilon\le\alpha_C+K[\sqrt{\alpha_C}\tau_C^{1/4}+\sqrt{\tau_C}],
\quad\tau_C=\log(1/p_C)/(n-|C|),\quad K\ge1.\tag{R0}\]
This is the source's conditional block-mask conclusion. It is required also for tensor-product amplifiers. No independence of win indicators is assumed.

**Theorem.** Under (R0), for n≥1 and 0<δ≤ε,
\[P:=\Pr\{W\ge\lceil(v+\delta)n\rceil\}\le
\exp[-\delta^5n/(8192K^4\epsilon^3)].\tag{T0}\]

Proof: define \(p_j=\binom nj^{-1}\sum_{|C|=j}p_C=E[(W)_j/(n)_j]\). For p_j>0 use weights \(w_C=p_C/[\binom nj p_j]\). Double counting gives q̄=p_(j+1)/p_j, ᾱ=1−q̄. The identity
\[\sum_Cw_C\log(1/p_C)=\log(1/p_j)-D(w\|u)\le\log(1/p_j)\]
and Cauchy–Schwarz/Jensen average (R0) to
\[\epsilon\le\bar\alpha+K[\sqrt{\bar\alpha}\,t_j^{1/4}+\sqrt{t_j}],\quad
t_j=\log(1/p_j)/(n-j).\tag{A}\]
Set a=δ⁴/(256K⁴ε²), s=v+3δ/4, L₀=log(1/s)+a. If t_j≤a then q̄≤v+δ/2: otherwise ᾱ<ε−δ/2 but the two errors total≤δ/4+δ/16<δ/2. Also L₀≥1−s=ε−3δ/4≥ε/4.

For n≥8L₀/a let k=floor(an/(4L₀)). Then k≥an/(8L₀)≥1 and k/n≤a/ε≤δ/256<δ/4. For j≤k and P>0, the factorial-moment identity gives p_j≥P s^j>0, since each falling-factorial ratio is at least v+δ−k/n≥s.

Call j good when log(1/p_j)≤a(n−j). If some j≤k is not good, log(1/P)>an−jL₀≥3an/4. Otherwise each j<k is good, so p_k≤(v+δ/2)^k. Consequently
\[\log(1/P)\ge k\log\frac{s}{v+\delta/2}\ge k\delta/(4s)
\ge a\delta n/(32sL_0).\]
Here sL₀=s log(1/s)+sa≤1−s+a≤ε, because a≤δ/256<3δ/4. This gives (T0); the nongood case is stronger since δ≤ε. Tensor r independent blocks of any original n-copy strategy: all r block threshold events imply the rn threshold event, including ceilings, and have probability P^r. Apply the uniform long-length bound and take r-th roots. Thus every n is covered. At v=0, (R0) for C empty forces EW=0, so the tail is zero. At ε=0 the allowed δ range is empty. ∎

With K=2¹⁶ the constant is 2^(−77). Simply substituting ell=0 into the old wrapper would not justify this: that proof used ell≥ln2 to control k/n. Here L₀≥ε/4 replaces that step, with no singleton-output independence claim.

## Primary comparators, costs and status

- Fawzi–Parrilo, [arXiv:1210.6970v2](https://arxiv.org/html/1210.6970v2), §2.3 equation (7) and Theorem 4: ordinary nuclear factorization characterization and its nonnegative restriction. The certificate above is a direct standard application with a complete proof; no new norm is claimed.
- Watts, [EJC 13 (2006), R74](https://www.combinatorics.org/ojs/index.php/eljc/article/view/v13i1r74), equations (3)–(4): fractional exact biclique partition LP and signed dual. The journal abstract and primary indexed passage were accessible; the Kyoto full-PDF fetch returned 403. The marginal objective is a routine LP modification.
- Pinto, [arXiv:1307.6363v2](https://arxiv.org/html/1307.6363v2), introduction: established local biclique cover/partition parameters. No theorem from it is required here.
- Ghosal–Karrenbauer, [SEA 2025](https://drops.dagstuhl.de/storage/00lipics/lipics-vol338-sea2025/html/LIPIcs.SEA.2025.18/LIPIcs.SEA.2025.18.html), §§1–3: fractional binary-rank tensor nonmultiplicativity. Accordingly (LP) multiplicativity is not assumed; the explicit ordinary-norm witness is used.
- Lin, [arXiv:2304.01940v3](https://arxiv.org/html/2304.01940v3), Definition 3.1/Theorem 3.2: finite-table closure of finite-tracial standard-form correlations equals C_qc. I checked its definitions/theorem, not the entire modular-theoretic proof. It is not finite-matrix density.

The supplied notes identify Kempe–Regev–Toner's quadratic unique-game result and Dinur–Steurer–Vidick projection repetition as necessary repetition comparators. No priority claim about the conditional commuting or threshold consequence is made without a full independent comparator audit. The norm, fractional partition and local biclique machinery are established predecessors; the exact-mask structural classification and its application to this source interface are the independently derived operation here.

The LP has at most (2^|A|−1)(2^|B|−1) rectangles, and tensor alphabets grow exponentially. Layer-cake hardening can multiply labels by a polynomial in the two alphabet sizes per atom. The source compression accuracy still scales as p times error slack divided by coefficient mass; sampler resources depend on finite-family spectral cutoffs and requested accuracy. No efficient algorithm, uniform finite matrix dimension, physical protocol or practical advantage follows.

[constructor_checks.py](../constructor_checks.py) and [constructor_checks.json](../constructor_checks.json) verify the one-step primal/dual, integer tensor witness through t=6, and all block/induced-triangle classifications for 2×2, 2×3 and 3×3 masks. These finite diagnostics supplement the all-t proofs.

| Claim | Status |
|---|---|
| Marginal LP; nuclear certificate; tensor obstruction | Proved here from established machinery |
| Maximality of block masks at exact pointwise interface | Proved here |
| Value-preserving nuisance amplification | Proved here |
| Exact support quotient and relative smoothing estimate | Proved here |
| Filter transfer / quadratic criterion | Conditional on named source interfaces and uniform filter acquisition |
| Alphabet-free threshold wrapper | Complete scalar proof from (R0); game theorem conditional |
| General relative filter theorem / general quadratic commuting repetition | Open |
| External validation and historical priority | Not established |

The strongest next attack is to prove or refute a relative support-sensitive filter theorem for selected rare near-perfect events. It must tolerate nuisance registers, preserve dependence on tested questions only, control full local fine tables, and hold uniformly on finite-tracial approximants. This is a materially different operation from improving rectangle coefficient counts.
