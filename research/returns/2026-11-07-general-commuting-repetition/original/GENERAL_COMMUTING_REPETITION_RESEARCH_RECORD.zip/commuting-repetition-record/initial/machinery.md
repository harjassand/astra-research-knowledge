# Independent initial machinery report: commuting repetition

Researcher: machinery; 6 November 2026, Brisbane. This initial report was written before reading any other researcher's new notes or exchanging mathematical conclusions. No subagents were used.

## Main judgment

The most useful extension I can presently justify is **an intrinsic, distribution-averaged positive-rectangle load in place of the answer-length charge**. Conditional on the exact inherited operational sampler, resolvent, history, and finite-table interfaces, it gives

\[
 \omega_{\rm co}(G^{\otimes n})
 \leq \exp\!\left[-2^{-75}\frac{\varepsilon^3}{\varepsilon+\kappa(G)}n\right],
 \qquad \kappa(G)=\log\mathbb E_{(x,y)\sim\mu}\rho(V_{xy}).
\]

Here \(\rho\) is a fractional local **partition** load of the Boolean winning matrix, defined below. Consequently, a game whose non-block question pairs have probability \(\eta\) and load at most \(R\) has
\[
 \kappa(G)\leq\log(1+\eta(R-1)).
\]
Thus \(\eta(R-1)=O(\varepsilon)\) retains an alphabet-independent quadratic rate. This is a conditional mathematical extension, not a fresh unconditional certification of N443 and not a priority claim.

There are two reasons not to advertise a generic factorization breakthrough. First, the load-one Boolean masks are **exactly** unions of vertex-disjoint complete bipartite rectangles; positive factorizations with zero entropy cost cannot enlarge that class. Second, an induced three-edge \(2\times2\) mask already has optimal fractional load \(3/2\). Signed/operator-space factorizations do not enter the positive-functional Jensen telescope without a new positivity argument.

One prior-art scope correction is immediate and unconditional: the quadratic commuting repetition theorem for **unique games** already follows from the actual SDP proof of Kempe–Regev–Toner. No tracial sampler or Lin import is needed. The inherited projection/disjoint-block theorem can be consequential beyond this special case, but its unique-game restriction is established machinery.

## 1. Source pin and what was actually checked

Local source repository:
`/Users/harjas/Documents/Codex/2026-10-27/astra-capital-scientific-curator-20261027/work/astra-research-knowledge`, revision `377e86be0b69c91c611824f561ca96bdf3e34aad`.

I read the requested N443 JSON, N445/N446/L02 cards and the governing original texts, extracted independently into `../machinery_sources/`:

| Source ID | Original governing text | Read scope |
| --- | --- | --- |
| `d-4307bff4c3cc7d61` | `COMMUTING_COMPOSITION.txt` | Entire composition/DAG |
| `d-b71a560b31672c1c` | `resolvent_production.txt` | Resolvent, telescope, finite scalar compression and exact norm law |
| `d-bf7b325467f08ce7` | `history_production.txt` | Entire mass/referee-law construction |
| `d-b9ddce9845d86bc5` | `near_perfect.txt` | Entire operational event extraction and greedy deduction |
| `d-00f0e05d83477c7b` | `algebra_exposed_interface.txt` | Interface and scope |
| `d-c0c60d5f60048037` | `sampler_original.txt` | Entire tracial graph-projection/first-success construction |
| `d-e9f40be49c4895dc` | `event_wrapper.txt` | Entire nonlinear factorial-moment wrapper |
| `d-96883d496bd6be12` | `threshold_wrapper.txt` | Entire baseline wrapper |
| `d-fddb0b961502d7cb` | `line_game_rate_obstruction.txt` | Gap and lower-bound controls |
| `src-N443-root-weighted-mass-20261023` | `N443_WEIGHTED_MASS.txt` | Entire 142-line correction |

I also read the original L02 extension/audit passages relevant to its Lin comparison. These are inherited analytical sources, not the present team's notes. The principal subsequently supplied a logistics-only notice that current upstream `d4718a92e3a0f5e1fa49cb09bb10d0acf68ae461` leaves the four requested cards unchanged; I did not independently inspect that upstream revision.

The most important source identities checked directly were: the resolvent Jensen-gap inequality and regularization at zero spectrum; exact scalar-feature normalization \(\sum g_\ell(T)^2=T\); graph-projection left/right orientations; operational good/bad loss transfer; the positive-functional weighted log-sum; and preservation of the original finite conditional table before the fixed-positive-\(p\) Lin limit. I have not reconstructed every line of every underlying imported operator-algebra theorem. The proposed extension therefore retains the inherited named interfaces explicitly.

Primary-source HTML snapshots and SHA256 pins are in `../machinery_sources/primary/manifest.json`. A direct Song PDF download failed, but its full primary ECCC PDF was read through the web tool. No cached secondary summary was used as a theorem premise.

## 2. Verified prior machinery and applicability

### 2.1 Lin's actual finite-table closure

Junqiao Lin, *Tracially embeddable strategies: Lifting MIP* tricks to MIPco*, arXiv:2304.01940v3, revised 15 September 2025, Definition 3.1 and Theorem 3.2:
\[
 \overline{\mathcal C^{\rm Tr}_{qc}(X,A)}^{\ell_1}=\mathcal C_{qc}(X,A)
\]
for finite input/output alphabets. The model is a finite tracial von Neumann algebra in standard form, a bounded positive \(\sigma\) with \(\|\sigma\|_2=1\), left/right measurement algebras. The algebra need not be a matrix algebra. [Primary source](https://arxiv.org/html/2304.01940v3#S3).

Applicability: a fixed finite repeated-game table is finite; its event probability \(p>0\), conditional success and all polynomial payoff functionals vary continuously under table approximation, with the usual conditional error proportional to \(1/p\). One first proves the uniform finite-tracial scalar inequality and then passes to tables at that fixed \(p\). This does not approximate state vectors, enforce a common algebra across approximants or supply a finite tensor strategy. The statement therefore supports the inherited limiting order, not a tensor/commuting identification.

### 2.2 Existing quadratic commuting bound for unique games

Kempe, Regev and Toner, *Unique Games with Entangled Provers are Easy*, arXiv:0710.0655v3, Theorem 5.2 proves the tensor-model bound \((1-\varepsilon^2/16)^n\). Its proof uses SDP 3 in Section 5.3, Lemma 5.7 and the bipartite SDP product theorem, Theorem 5.5. SDP 3 has within-question orthogonality and normalization of the sum of squared norms, with a bilinear objective. [Primary source](https://arxiv.org/html/0710.0655v3#S5).

**Direct applicability proof to commuting strategies.** For commuting projective measurements \(P_a^x,Q_b^y\) on an arbitrary Hilbert space and unit \(\psi\), set \(u_a^x=P_a^x\psi\), \(v_b^y=Q_b^y\psi\) and realify their finite span. These vectors satisfy SDP 3 exactly, and their objective equals the commuting payoff. POVMs can first be dilated in separate finite ancillas with coefficients in the respective commuting algebras. Thus
\[
 \omega_{\rm co}(G)\le s(G):=\omega_{\rm SDP3}(G).
\]
Lemma 5.7 constructs an actual finite-dimensional tensor strategy from **any** SDP 3 solution. If \(s(G)=1-t\), then
\[
 \omega_{\rm co}(G)\ge\omega^*(G)\ge1-2\sqrt{2t}-4t.
\]
Consequently, for \(\varepsilon=1-\omega_{\rm co}(G)\in(0,1]\), \(s(G)\le1-\varepsilon^2/16\): if \(t<\varepsilon^2/16\), then \(2\sqrt{2t}+4t<(1/\sqrt2+1/4)\varepsilon<\varepsilon\), a contradiction. Strict feasibility of SDP 3 is witnessed by orthogonal vectors of appropriate norms. Theorem 5.5 and the relaxation inclusion proved in Section 5.3 give
\[
 \omega_{\rm co}(G^{\otimes n})\le s(G^{\otimes n})\le s(G)^n
 \le (1-\varepsilon^2/16)^n.
\]
This is an extension of an explicitly verified proof, credited entirely to existing machinery. It does not imply equality of tensor and commuting values of unique games.

### 2.3 Projection games: what DSV supplies

Dinur, Steurer and Vidick, arXiv:1310.4113v2, Theorem 1 gives
\(\operatorname{val}^*(G^{\otimes k})\le[1-C(1-\operatorname{val}^*(G))^c]^{k/2}\), with \(c\le12\) from their proof; the expanding case has \(c=1\). Lemmas 6–8 give the square-norm comparison and multiplicative relaxed value. Their operator formulas use matrix amplifications/tensor products, and the nonexpanding rounding uses quantum correlated sampling. [Primary source](https://arxiv.org/html/1310.4113v2).

Missing applicability step: the whole relaxed-value rounding construction must be rebuilt for arbitrary finite von Neumann algebras or an independently valid commuting relaxation. Merely citing Lin's correlation closure does not turn a finite-matrix SDP/norm argument into such a theorem. This source does not directly dispose of N443's general projection commuting refinement.

### 2.4 Exact anchored commuting comparator

Lin, *MIPco=coRE*, arXiv:2510.07162v1, Definition 9.1, Theorem 9.3 and Appendix A, Theorem A.1, treat the anchored transformation \(G_\bot\), not the original game:
\[
 \omega^t(G_\bot^{\otimes r})
 \le\frac{16}{\varepsilon}
 \exp\!\left[-c^{\rm para}\varepsilon^{17}r/\log(|A|+1)\right],
 \quad t\in\{*,co\},\quad\omega^t(G)\le1-\varepsilon.
\]
Each player's question is independently erased with probability one half; erased questions require the anchoring answer. [Primary source](https://arxiv.org/html/2510.07162v1#S9).

There is no implication from an anchored upper bound to an unanchored one: allowing the anchor generally helps the players, while conditioning on a run with no erasures costs probability \(4^{-r}\), which overwhelms this estimate. This comparator is genuine commuting literature but not a prior proof of N443's unanchored rate.

### 2.5 Current general tensor comparators

Song, ECCC TR26-199, *Parallel Repetition for Entangled Games with Gap Exponent Three*, Theorem 1.1 and its detailed Theorem 4.6 give \(\exp[-\Omega(\varepsilon^3n/(\varepsilon+\ell))]\) for finite-dimensional entangled games. Lemma 4.1 supplies the soft-label sampler adopted by the inherited tracial construction. [Primary ECCC PDF](https://eccc.weizmann.ac.il/report/2026/199/download/).

Rahul Jain, arXiv:2610.21410v1, *Parallel Repetition for Entangled Games via Conditional Relative Entropy*, Theorem 1.1 and Corollary 5.2 give the same cubic rate and a \(\delta^5/(\varepsilon^2L)\) threshold rate, with \(L=\max\{1,\log(|A||B|)\}\). Section 2 explicitly makes all systems finite dimensional. [Primary source](https://arxiv.org/html/2610.21410v1).

These sources prevent any claim that cubic gap dependence or its basic soft-label mechanism is new. Jain's relative-entropy/marginal-replacement construction is a serious alternate representation, but its coherent local systems, four-matrix estimates, canonical purifications and local corrections need a separate standard-form transfer. It is not a black-box commuting theorem. I found no verified direct general commuting theorem in the bounded search beyond the inherited source; this is not exhaustive priority clearance.

### 2.6 Other current routes that do not silently transfer

Culf, arXiv:2603.14746v1, Theorem 6.1: for a non-degenerate projection game and a strategy of value at least \(1-\epsilon\), there is a tracial correlation of value at least \(1-148(L\epsilon)^{1/4}\), where \(L\) is the inverse smallest supported conditional question probability. The proof section expressly covers commuting strategies. [Primary source](https://arxiv.org/html/2603.14746v1#S6).

This is useful structural machinery, but applying it to \(G^{\otimes n}\) replaces \(L\) by \(L^n\); it does not produce the uniform entropy reconstruction needed for repetition. Near-perfect one-round rounding alone also does not control arbitrary postselection laws.

Braverman–Minzer, arXiv:2610.30455v1, Theorem 1.3 proves exponential **classical** repetition for every multiplayer XOR game. Lemma 2.3 characterizes the stronger no-commuting-embedding condition by an ordered contradiction, and Section 3 tensorizes Cauchy–Schwarz/gluing. [Primary source](https://arxiv.org/html/2610.30455v1).

This is a valuable independent contradiction mechanism. The theorem's target is classical, and its BLR transformation increases the number of players. A commuting embedding in Definition 1.6 uses arbitrary unitaries satisfying exact word relations; it must not be silently identified with a quantitative commuting game gap for an arbitrary game. I have not acquired a general-game transfer from this route.

## 3. Positive rectangle load: a formal extension

Let \(T\in\{0,1\}^{A\times B}\). A fractional rectangle partition is a finite family \((w_r,U_r,V_r)\), \(w_r\ge0\), \(U_r\subseteq A,V_r\subseteq B\), with
\[
 T(a,b)=\sum_r w_r\mathbf1_{U_r}(a)\mathbf1_{V_r}(b)
 \quad\text{for every }a,b.
\]
Every rectangle lies inside the winning support. Define
\[
 \rho(T)=\max\left\{1,\inf_{\mathcal R}
 \max\left(\max_a\sum_{r:a\in U_r}w_r,
           \max_b\sum_{r:b\in V_r}w_r\right)\right\}.
\]
For fixed finite \(A,B\), this is a finite linear program over all nonempty rectangles, hence its infimum is attained. It is a fractional local partition parameter, related to established biclique partition machinery, rather than a renamed operator-space norm. Fractional partitions were studied by Watts (2006); local biclique cover/partition load by Pinto (2014). [Watts](https://www.kurims.kyoto-u.ac.jp/EMIS/journals/EJC/Volume_13/PDF/v13i1r74.pdf), [Pinto](https://www.combinatorics.org/ojs/index.php/eljc/article/view/v21i1p19).

Basic facts proved directly:

1. \(\rho(T)\le\min\{|A|,|B|\}\) when both sets are nonempty: partition into row stars or column stars; one side's load is one and the other's is at most the opposite alphabet size. Empty support is assigned load one by convention.
2. \(\rho(T\otimes S)\le\rho(T)\rho(S)\), by multiplying rectangle weights and taking Cartesian products of supports.
3. The source's mass-one class has \(\rho=1\). Conversely, \(\rho=1\) forces that class; proof below.

For a finite game put
\[
 \Lambda(G)=\mathbb E_{\mu}\rho(V_{xy}),\qquad\kappa(G)=\log\Lambda(G)\ge0.
\]

### Entropy budget theorem (proved here)

At every exposure stage of the inherited R construction, replace singleton accepted answer pairs by the products of the per-question rectangle partitions. For a tested question string \(c\) of length \(t\), coarse-grain each player's tested-answer POVM over the corresponding rectangular support. The resulting factors \(F_r,H_r\) remain positive contractions. Their weighted sums satisfy
\[
 \sum_r w_rF_r\le\Big(\prod_{j\in C}\rho(V_{x_jy_j})\Big)I,
 \qquad
 \sum_r w_rH_r\le\Big(\prod_{j\in C}\rho(V_{x_jy_j})\Big)I.
\]
The exact decomposition of the mask preserves the tested event measure, its probability \(p\), every live fine-answer measure, and the referee law. Grouping fine effects remains compatible with the source's local POVM reconstruction because sums of grouped fine effects are exactly the grouped coarse effect.

For \(\chi(F,H)=\tau(\sigma F\sigma H)\), positive-functional Jensen and weighted log-sum give
\[
 -\sum_r w_r\chi(F_r\log F_r,H_r)
 \le p\log(G_B/p),\qquad
 G_B=\sum_r w_r\chi(I,H_r),
\]
and the symmetric formula with \(G_A\). This is the inherited corrected entropy lemma. Average over the **original** exposure flag law, before normalizing on success. Since the tested question coordinates retain original law \(\mu^{\otimes t}\),
\[
 G_A,G_B\le\mathbb E_{c\sim\mu^{\otimes t}}
              \prod_{j\in C}\rho(V_{x_jy_j})
           =\Lambda(G)^t.
\]
No posterior independence is assumed. The entropy telescope therefore gives each side's average squared unnormalized alignment error at most
\[
 \frac{p}{n-t}\big(\log(1/p)+t\kappa(G)\big).
\]
The ordinary referee-question drift costs only \(\log(1/p)\), so it is bounded by the same larger budget. Finite scalar-feature compression still costs the total rectangle coefficient mass times its chosen accuracy; that finite resource cost can be driven to zero at fixed positive \(p\) and is not an extra entropy term.

### Conditional repetition theorem (conditional on inherited interfaces)

Assume the inherited operational all-input sampler S_actual, exact R/H fine-answer and history reconstruction, and Lin's fixed-finite-table transfer at their stated scopes. For every proper tested set \(C\), \(p_C>0\), put
\[
 \tau_C=\frac{\log(1/p_C)+|C|\kappa(G)}{n-|C|},
 \quad\alpha_C=1-\frac1{n-|C|}\sum_{i\notin C}\Pr(W_i\mid W_C).
\]
The same operational calculation as N443 gives, with \(K=65536\),
\[
 \varepsilon\le\alpha_C+
 K\big(\sqrt{\alpha_C}\tau_C^{1/4}+\sqrt{\tau_C}\big).
\]
The source's greedy proof in `near_perfect.txt`, Sections 5–6, uses only nonnegativity of its charge parameter; substitute \(\kappa(G)\) for \(\ell\). It yields the all-\(n\) bound displayed at the start of this report. The scalar steps do not need \(\kappa\) to be an alphabet logarithm. In particular \(\kappa=0\) is legal in that **greedy all-wins proof**.

If all but \(\eta\) of the question probability consists of disjoint-block masks and the remainder has load at most \(R\), then \(\Lambda\le1+\eta(R-1)\). For \(\eta(R-1)\le C\varepsilon\),
\[
 \omega_{\rm co}(G^{\otimes n})
 \le\exp[-2^{-75}\varepsilon^2n/(1+C)].
\]
This is a robust quadratic class beyond the exact projection/disjoint-block class, while respecting the line-game quadratic obstruction. No uniform finite-dimensional or efficient realization is asserted.

## 4. Decisive obstructions and failed stronger transfers

### 4.1 Exact classification of load one

Take a load-one partition. At a winning pair \((a,b)\), the sum of weights of rectangles containing that pair is exactly one. The total weight incident to each endpoint is at most one. Therefore every positive-weight rectangle incident to \(a\) must also contain \(b\), and conversely. Thus the sets of positive-weight incident rectangles of \(a\) and \(b\) coincide. Along any path of winning edges these sets remain equal. If \(a,b'\) are opposite-side vertices in the same nontrivial connected component, every rectangle incident to \(a\) also contains \(b'\), so their entry is one. Each component is complete bipartite.

This proof also applies to factors \(0\le f_r,g_r\le1\) with weighted one-sided sums at most one: each winning entry saturates the domination inequalities, forcing every active factor to have value one at the opposite endpoint. Alternatively, finite layer-cake decompositions turn such factors into indicator rectangles without increasing one-sided loads.

Hence positive factorization cannot remove the answer information charge on all Boolean predicates while retaining this exact mass-one argument. A new operation is needed, such as a valid signed entropy telescope, a different postselection representation, or another reconstruction mechanism.

### 4.2 Sharp smallest forbidden mask

For
\[
 T=\begin{pmatrix}1&1\\1&0\end{pmatrix},
\]
every rectangle is a row star, a column star, or a singleton. Let \(r\) be the total weight of the full top row and \(c\) that of the full left column. Exact coverage gives \(r+c\le1\). The top vertex load is \(2-r\) and the left vertex load is \(2-c\). Their maximum is at least \(3/2\), attained by \(r=c=1/2\), no central singleton, and weights \(1/2\) on each off-diagonal singleton. Thus \(\rho(T)=3/2\).

Any non-block Boolean mask contains such a three-edge submatrix: take the first missing cross-edge along a shortest path in a non-complete component. Restricting a partition cannot increase load. Therefore every non-block mask has \(\rho\ge3/2\). Pointwise load cannot approach one continuously; only the distribution-averaged defect mass can do so.

### 4.3 The threshold substitution trap

The inherited threshold wrapper's displayed formula with \(\ell=0\) is justified there by **singleton answer alphabets**, which force independent winning indicators. It is not an abstract theorem that one can invoke after replacing \(\ell\) by an unrelated zero charge. Its nondegenerate proof explicitly uses \(\ell\ge\log2\) in its sample-size and denominator estimates. Thus it is invalid to announce \(\exp[-c\delta^4n/\varepsilon^2]\) for all projection games merely by inserting \(\kappa=0\) into that old display.

A fresh factorial-moment analysis with \(\kappa=0\) encounters the additional cost \(s\log(1/s)\), with \(s\approx1-\varepsilon\), which is of order \(\varepsilon\). The straightforward adaptation therefore suggests \(\delta^5/(\varepsilon^2(\varepsilon+\kappa))\), not the unearned zero-charge displayed rate. I have not completed a sharp threshold theorem here. The line-game and independent-binomial lower controls must still be respected.

### 4.4 Operator-space and product-algebra trap

A norm representation of a single game's commuting value on a maximal tensor product does not identify the algebra of **all** joint repeated measurements with the tensor product of the single-game algebras. A repeated measurement may depend on the entire local question string. Product-algebra strategies give an allowed subclass and hence a lower bound, not the upper bound required for repetition. Signed Grothendieck factorizations likewise fail the positive-weight Jensen hypothesis above. These are missing applicability operations, not matters of terminology.

## 5. Strongest next mathematical operations

1. Challenge the distribution-averaged load theorem at the exact fine-POVM reconstruction step and all fixed-positive-\(p\) limits. This is the smallest nontrivial extension with a complete local argument and a useful quadratic robustness consequence.
2. For a foundational improvement beyond it, seek an entropy reconstruction that handles an induced three-edge mask at zero per-tested-coordinate charge. The \(3/2\) lemma shows that rearranging positive rectangles alone cannot do this.
3. Independently transfer Jain's conditional-relative-entropy/marginal-replacement route to standard forms. This is a plausible competing construction; it needs its own operator-algebra proof and does not follow from the current finite-table density theorem.
4. A heterogeneous quadratic product theorem \(\omega_{\rm co}(\bigotimes_iG_i)\le\exp[-c\sum_i\varepsilon_i^2]\) for disjoint-block games is an attractive next target. The source's averaged entropy theorem hints at coordinatewise information charges, but the required weighted extraction has not been acquired in this report. Dyadic grouping alone loses a gap-range factor and should not be presented as the desired theorem.

## 6. Claim ledger

| Claim | Status |
| --- | --- |
| KRT quadratic repetition extends to commuting unique games by its existing SDP proof | Proved from verified primary imports; established machinery |
| Positive weighted Jensen and intrinsic averaged partition-load entropy budget | Proved here, using the explicitly checked inherited exposure representation |
| All-wins rate with \(\ell\) replaced by \(\kappa(G)\), and rare-defect quadratic class | Conditional on inherited S_actual/R/H/Lin interfaces |
| Load-one iff disjoint-block Boolean support; smallest forbidden mask has load \(3/2\) | Proved here; elementary structural obstruction; priority unassessed |
| General-game quadratic commuting repetition | Open in this investigation |
| Sharp projection/near-projection threshold rate | Open; naive zero-charge substitution invalid |
| Generic operator-space/tensor-algebra transfer | Unsupported; explicit applicability obstruction identified |
| Historical priority of the new load application | Unknown; bounded primary search only |

