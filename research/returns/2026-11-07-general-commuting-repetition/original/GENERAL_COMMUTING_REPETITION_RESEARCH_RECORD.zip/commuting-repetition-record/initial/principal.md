# Principal initial investigation — independent, 6 November 2026

Written before reading any new researcher report. Governing sources inspected: N443 card and material updates, N443_WEIGHTED_MASS and ROOT_WEIGHTED_MASS_REFINEMENT at local repo 377e86be0b69c91c611824f561ca96bdf3e34aad. Source interfaces S_actual/R/H/Lin remain imports.

## Chosen decisive operation

Can exact positive mask decompositions have subexponential actual one-sided mass for arbitrary near-perfect conditioned answer laws? A positive answer would remove the tested-answer entropy penalty and support a general quadratic-gap theorem. The old L-shaped one-step obstruction does not address tensor powers, and its perfect one-question core is semantically removable.

## New complete elementary obstruction: crown masks tensorize exactly

Let m>=2 be even, A=B=[m], theta(a,b)=1{a != b}; let P=Q be uniform. For t>=1 let theta_t(a^t,b^t)=product_i theta(a_i,b_i). Consider ANY finite exact positive bounded product decomposition

 theta_t(u,v)=sum_k lambda_k f_k(u)g_k(v), lambda_k>=0, f_k,g_k in [0,1].

Set G_A=sum lambda_k E_P^t f_k and G_B=sum lambda_k E_Q^t g_k. Then

 inf_decompositions max(G_A,G_B) = [2(1-1/m)]^t.

Proof lower: positivity forces every nonzero rectangle supp f_k x supp g_k into theta_t^{-1}(1). Its coordinate projections R_i,C_i are disjoint subsets of [m]. Thus |supp f| |supp g| <= product_i |R_i||C_i| <= (m^2/4)^t. Set x=E f,y=E g; xy<=4^{-t}, so xy <= 2^{-t-1}(x+y). The exact identity under the product measure gives p_t=(1-1/m)^t=sum lambda_k x_k y_k. Hence G_A+G_B>=2^{t+1}p_t and max>=2^t p_t.

Upper: average the rectangles S x S^c over all m/2-element S. A fixed unequal ordered pair lies in a random rectangle with probability m/[4(m-1)]. Multiply this average by 4(m-1)/m. This is an exact decomposition of theta. Both masses equal 2(m-1)/m. Tensoring the decompositions gives equality for t. No coordinatewise restriction on competitors is used in lower bound.

Consequences: one-step probability 1-1/m tends to1 but optimised mass tends to2. Moreover log mass=t log[2(1-1/m)], not O((1/m)t). Even choosing m growing with t makes p_t arbitrarily close to1 while mass remains exponentially large. This disproves the general event-preserving positive-factorization route to a witness-independent log mass <=kappa (observed failure)t solely from high acceptance and completeness. Arbitrary global decompositions do not repair it. It is not a lower bound on the optimal repetition rate: this one-question game has value1 and admits fixed winning outputs. Semantic quotient/retraction, changing representation, or a genuinely operator-valued reconstruction could evade it.

## Potential broader structural theorem

For any 0/1 mask M under independent local measures P,Q, define b(M)=max_{R x C subset M^{-1}(1)} P(R)Q(C), and p=E_{P Q}M. The same proof gives ANY exact decomposition of M^tensor t:

 max(G_A,G_B) >= [p/sqrt(b(M))]^t.

Coordinate projections show rectangle density multiplicativity b(M^tensor t)=b(M)^t for product measures. This formulation resembles rectangle/factorization bounds in communication complexity; novelty must be checked before calling it new. Crown equality is an exact sharp test fixture, not an external priority claim.

## Stronger positive avenues to investigate after independent exchange

1. Replace scalar separable history labels by operator-valued accepted-event compression, keeping the event contraction <=I without introducing illicit interplayer communication. Exact missing operation: localize a nonlocal acceptance filter while preserving conditional local laws and rare-event error, rather than ordinary total variation.
2. Semantic reduction of winning masks to disjoint blocks while preserving commuting value with controlled gap and resource costs. Standard projection/oracularization does not automatically preserve arbitrary commuting strategies; must prove both completeness and soundness and not assume tensor/co equality.
3. Study actual finite-table import Lin2304.01940v3 and modern MIPco=coRE (2510.07162): general repetition is not by itself a new complexity classification or quantum-PCP theorem.

## Status

Crown/global rectangle mass theorem proved above, pending hostile check and novelty comparison. General quadratic repetition and general optimal thresholds are open in this investigation. Prior scoped source capital preserved.
