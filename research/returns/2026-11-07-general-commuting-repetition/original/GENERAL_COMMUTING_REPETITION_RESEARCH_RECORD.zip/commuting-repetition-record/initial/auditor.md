# Independent hostile audit: general commuting repetition

Written 6 November 2026 by the hostile-auditor researcher, before reading any
other current researcher or principal mathematical notes. No descendants were
used. The principal supplied source-logistics information only. Mathematical
novelty of the results below has not been established.

## Initial disposition

1. I found no fatal error in the actual first-success correlation sampler,
   its operational losing-event comparison, the exact resolvent/history
   producer-consumer interface, or fixed-positive-probability application of
   Lin's finite-table closure, at the precise scopes stated in the pinned
   sources. The claimed cubic all-wins deduction is consistent with those
   inputs. This is a mathematical audit of the supplied arguments, not formal
   certification or a proof of priority.
2. The weighted-mass refinement for disjoint-block masks, including ordinary
   projection games, survives the obvious positivity, noninjectivity,
   opposite-algebra and zero-mass attacks. Its conditional quadratic rate is
   a real improvement of the coarser coefficient-count argument. The large
   label count remains a resource/accuracy cost.
3. I derived a stronger obstruction than the recorded one-step L-mask
   example. For tensor powers of that mask, **every exact bounded positive
   factorization**, including a globally optimized nonproduct one, has
   diverging actual one-sided mass along a sequence for which the tested
   event probability tends to one. Moreover, a padding construction places
   this obstruction inside fixed-alphabet positive-gap games with bounded
   tested-event probability, near-perfect remaining conditional success and
   `|C| = O(1/epsilon)`. This disproves a proposed *uniform every-instance*
   bound `G_A,G_B <= exp(O(epsilon |C|))` based only on these conditions.
   It does not disprove a general quadratic repetition theorem, an adaptive
   choice of a better tested set, or a sharper entropy argument.
4. The obstruction admits a constructive repair: quotient/removal of harmless
   answer factors. A precise local-answer retraction lemma gives equality of
   all repeated commuting values and extends the quadratic conclusion to
   games outside the syntactic disjoint-block class. This is a straightforward
   transfer lemma, not a claimed foundational breakthrough.

## Governing sources and pin

Local research repository:
`/Users/harjas/Documents/Codex/2026-10-27/astra-capital-scientific-curator-20261027/work/astra-research-knowledge`.
The locally observed checkout was `377e86be0b69c91c611824f561ca96bdf3e34aad`.
The principal independently reported that current-main commit
`d4718a92e3a0f5e1fa49cb09bb10d0acf68ae461` retained the relevant governing
card versions. This audit itself uses the exact bytes below.

Read N443, including both weighted-mass material updates, N445 and N446.
The original source paths in their cards are archival paths; the available
local `web/pages/<source-id>.html` wrappers contain exact UTF-8 text in a
`pre` element. I extracted and hashed that text into
`../auditor_sources/`. The hashes match the indexed-source hashes:

| Source | Source ID | SHA256 of extracted UTF-8 text |
|---|---|---|
| Final composition | `d-4307bff4c3cc7d61` | `325437631d3da2492a90575f0114d214192f379740a702681ab759c63601a81e` |
| Actual sampler | `d-c0c60d5f60048037` | `f37b03a0a84487328c4d1b96b30bbc03468e085bef5593a635126775310beb2b` |
| Sampler precision | `d-cbce5f1d99288e42` | `75e4a4c876b9e07b5d2578c1ddd76d4e30773aa0756c015ebb9cb71a3e868304` |
| Mandatory central-toy correction | `d-fd95c6e54489b2d0` | `9ab9939a3682d737ceda06970df30577cb17ccd70d0e197956bcc5a0cc5b5a10` |
| Resolvent production R | `d-b71a560b31672c1c` | `2acf3c9e5d067de16c873e16bf0fbe52e6becdd47c6db55a3fd526ac086e8627` |
| History production H | `d-bf7b325467f08ce7` | `0893936c7ab79d8a5b3fac87af28a90e4e7e9b45d52bd23b20d4b94629f02475` |
| Near-perfect deduction | `d-b9ddce9845d86bc5` | `55c2956bb771d630307639a4fd5ff46ea772b484985499dcd765d34f9183cbce` |
| Algebra exposed interface | `d-00f0e05d83477c7b` | `375b5a2aa6bb2e23ced3333c8c32d621be694516beca336ee039f391d5802752` |
| Threshold wrapper | `d-96883d496bd6be12` | `e2e346f5da05acaf90aedee56ce94b605b0677d9470ac8cf20946637941f67df` |
| Line-game obstruction | `d-fddb0b961502d7cb` | `85c5913d23aa3c4982f80d223c04b28b5156b990afb5bdfc886faec43f4bc4bf` |

Additional archived audits were read as evidence of earlier scrutiny, not as
proof substitutes: sampler audit `d-2739da39f267db63`, raw audit
`d-b40529e66742523e`, near-perfect audit `d-ad845f22d882a5e2`, event audit
`d-4ee2bee73937de92` and scalar review `d-495ae2fb4b68af1f`.

The later weighted-mass source texts are directly available at:

`research/2026-10-23-fresh-programme/intake/capital-integrated-2026-10-23/updates/2026-10-23-n443-weighted-mass-correction/source/root/N443_WEIGHTED_MASS.txt`

and `source/passive_lag/ROOT_WEIGHTED_MASS_REFINEMENT.txt` in that same
directory. Their card-pinned hashes are respectively
`9710eeb55748208212cc6e61317a16e0c667bae6162cdbd582597beb3fb43f94` and
`10d17bb56009a173cb3b4807e5fca58fb9b3eb5728b3baeac3a10dbd4b453250`.

## Load-bearing audit

### The actual unconditional protocol is essential and appears sound

The inspected sampler is a theorem about complete commuting answer POVMs on
one fixed finite amplification and finite tensor power of a finite tracial
von Neumann algebra. It is not a theorem about a trace-preserving channel
returning a requested state on the original algebra.

I checked the following delicate operations in its proof:

* The elements `E_i F_j` for spectral projections of two noncommuting
  self-adjoint elements are orthogonal in tracial L2. For `i != k`, the
  inner product vanishes using `E_i E_k = 0`; for equal `i` and distinct
  `j,l`, trace cyclicity puts `F_l F_j` together. Thus the spectral coupling
  identity does not import commutation between the two moduli.
* The 2-by-2 self-adjoint dilation bounds both left- and right-modulus
  discrepancies together. Keeping the left term is legitimate. The trace
  on that matrix factor is unnormalized, so the displayed factor 2 is
  correct.
* Zero spectrum is omitted from graph columns, and Bob's factor has
  `K_B K_B^* = P_d`. This is the required order because right
  multiplication reverses products. The all-input effects in sampler
  equations (15)-(16) sum to the identity and commute between players for
  every pair of input labels.
* The synchronized branch really has erased vector
  `x = (sum_k t_k g_k(c) g_k(d))u`, with squared norm C. The coefficient
  estimate controls `||x-b||_2`, and normalization costs at most a factor
  2 in vector norm. No unitary extension of the partial polar factor is
  needed.
* Independent copies of the fixed resource give exactly
  `w_same=(C/U)(1-(1-U/S)^N)`. Prior joint failures factor into a scalar;
  conditioning on a common retained index leaves the same erased vector.
  Every other branch remains part of a genuine unconditional correlation.

For a losing effect `0 <= L <= I`, synchronized loss obeys

`<v,Lv> <= (sqrt(<f,Lf>) + ||v-f||)^2`.

If squared discrepancy plus bad-branch probability is at most F, then the
unconditional loss is at most

`alpha + 2 sqrt(alpha F) + F`.

This is exactly the needed event comparison. A mean-TV bound alone would
not imply it. The source derives this inequality for the *same* all-input
POVMs used downstream. No extra protocol is silently substituted.

The central-sector counterexample to a fixed-original-algebra channel is
valid. It does not attack this amplified first-success construction. The
mandatory toy correction is also valid: identical soft graph filters can
have nonzero mismatch; the exact central success probability one-half and
timeout `2^-N` describe the separate plain-central-projector illustration.
The proof already charges the soft filter's mismatch.

### R/H preserve the actual event and the needed law

In R, fixed prefix/suffix question exposure makes the unexposed Alice and
Bob questions conditionally independent under the original product of joint
round laws. This does not assert independence after conditioning on wins.
The weights and winning mask depend only on tested questions and answers.

For the scalar resolvent feature `f_t(s)=t/(t+s)`, its L2 squared norm is
exactly t. The operator Jensen-gap proof is a resolvent identity followed by
`s(A+s)^(-2) <= (A+s)^(-1)`. Regularization
`A -> (1-delta)A + delta I` removes a genuine zero-spectrum issue; a support
restriction alone would not give bounded invertibility. The regularized
feature maps converge in operator norm by the uniform L2 continuity of
`t -> f_t` on `[0,1]`.

The finite compression explicitly renormalizes its scalar features so
`sum_l g_l(T)^2=T` exactly. It therefore preserves the posterior masses,
not merely approximately. The distinct column/row matrix-unit orientations
give the same `chi(F,H)=tr(sigma F sigma H)` norm. The bounded support-form
construction and polar transport for fine POVMs remain valid with
nonclosed ranges; no unbounded inverse is placed in the algebra.

H uses local posterior kernels, not a falsely independent common history.
Its exact law is `Q proportional to w mu ||v||^2`. Local norm identities
produce `J_A=mu P_A(r|x)` and `J_B=mu P_B(r|y)`. Cauchy-Schwarz controls
their TV distances from Q; the referee marginal drift is controlled by
`D(P_questions(.|E) || mu^n) <= log(1/p)`. The shared exponential race
couples the local history kernels, and the finite-family pushforward gives
finite shared classical randomness. On a history mismatch, the sampler
still gives legal commuting effects. Its guarantee is invoked only under
the original diagonal Q. TV transfer and mismatch are paid outside the
event square root.

The near-perfect source's order of limits is adequate: first fixed
repeated table and fixed `p>0`; then finite feature accuracy at fixed
`eta>tau`; then spectral/timeout accuracies; then `eta down to tau`.
The resulting scalar bound is continuous at zero. None of this gives a
uniform dimension bound or an attained limiting finite protocol.

### Lin: source statement and application checked

I checked the primary [Lin v3 Definition 3.1 and Theorem 3.2](https://arxiv.org/html/2304.01940v3#S3).
The import is closure, in finite correlation-table l1 norm, of strategies
on standard forms of tracial von Neumann algebras with a positive bounded
state element. It is not finite-matrix density. The standard commutant is
right multiplication by the opposite algebra.

For a fixed tested event of probability p, finite-table convergence makes
its probability and conditional live success converge; the conditioning
error is bounded by a constant times `table_error/p`. This application
does not require convergence of state descriptions or a uniform limit as
p tends to zero. Finite different input/output alphabets are accommodated
by padding and restriction. I have not re-proved Lin's density theorem;
it remains a correctly scoped primary import.

### Weighted positive masses and projection predicates

The useful scalar entropy inequality is

`-chi(F log F,H) <= h log(g/h)`, where
`h=chi(F,H)`, `g=chi(I,H)`.

It follows from Jensen on the normalized positive functional; if g=0,
positivity gives h=0. Applying log-sum before discarding g yields

`-sum_k lambda_k chi(F_k log F_k,H_k) <= p log(G_B/p)`.

The transposed bound uses G_A. This preserves the original event and live
table when the mask factorization is exact, nonnegative, bounded and
depends only on tested questions. Tested mask factors with disjoint row
and column supports give `sum F_k <= I` and `sum H_k <= I`, hence both
masses at most one. Projection masks qualify after grouping all rows with
the same projected column. Noninjective projections cause no overlap of
the grouped row sets. Product masks retain this property.

Thus I find no error in the conditional conclusion

`omega_co(G^n) <= exp(-2^-75 epsilon^2 n)`

for disjoint-block masks, under the same exact S_actual/R/H/Lin inputs.
No target FKG, finite dimension, or within-round product-question
assumption is used. The general coefficient/entropy-budget proof instead
has `log(1/p)+|C|log d`, giving the cubic rate in the source. A coefficient
count lower bound cannot refute the weighted refinement.

## New obstruction: globally optimized tensor masks

### Proposition A: positive tensor-factorization masses can diverge at p tending to one

Let `theta(a,b)=1{a<=b}` on `{0,1}^2`; its matrix is
`[[1,1],[0,1]]`. For `0<r<=1/2`, let P give Alice probability r of 1 and
Q give Bob probability r of 0. Let `P_T=P^tensor T`, `Q_T=Q^tensor T`
and `theta_T=theta^tensor T`. Consider **any** exact finite factorization

`theta_T(a,b) = sum_k lambda_k f_k(a) g_k(b)`

with `lambda_k>=0` and `0<=f_k,g_k<=1`; the factors can depend on all T
coordinates. Define

`G_A = sum_k lambda_k E_{P_T} f_k`,
`G_B = sum_k lambda_k E_{Q_T} g_k`.

Then

`max(G_A,G_B) >= [(1+r)sqrt(1-r)]^T`.                 (A)

**Proof.** By nonnegativity and exactness at the zero cells, every nonzero
atom has support a rectangle `A_k x B_k` contained in the coordinatewise
order relation. At each coordinate, either every member of A_k is 0 or
every member of B_k is 1. Choose one such restriction at each coordinate.
If j restrictions are assigned to Alice and the others to Bob, product
measure gives

`P_T(A_k) Q_T(B_k) <= (1-r)^j (1-r)^(T-j) = (1-r)^T`.

Write `x_k=E_P f_k`, `y_k=E_Q g_k`. These numbers also satisfy
`x_k y_k <= (1-r)^T`; therefore

`x_k y_k <= (1-r)^(T/2) (x_k+y_k)/2`.

Integrating the exact mask identity gives
`sum lambda_k x_k y_k = p_T = (1-r^2)^T`. Sum the preceding inequality:

`G_A+G_B >= 2 (1-r^2)^T/(1-r)^(T/2)`.

At least one mass is at least half that sum, proving (A). Empty atoms
contribute zero. No product structure of the chosen factorization was
assumed. QED.

Now set `r=T^(-2/3)` for sufficiently large T. Then

`p_T = (1-T^(-4/3))^T -> 1`,

while (A) gives

`log max(G_A,G_B) >= (1/2) T^(1/3) + o(1) -> infinity`.

This extends the recorded single-mask obstruction: optimizing over all
global exact positive factorizations cannot keep both actual masses
bounded in this near-certain-event example. It already holds with
`M=C`, scalar POVM effects, and no quantum resource.

The accompanying exact-arithmetic diagnostic
`../check_tensor_mask_obstruction.py` exhausts every nonempty support
rectangle for T=1,2,3 and r=1/10,1/2. It confirms the maximum product
rectangle mass `(1-r)^T` and accepted mass `(1-r^2)^T`. Its output is
finite supporting evidence; the argument above proves all T.

### Proposition B: near-perfect positive-gap instances do not force the proposed mass invariant

There are fixed-answer-alphabet games with positive commuting gaps
`epsilon -> 0` and actual tested-set instances satisfying all of

* `p >= c > 0` for a universal constant along the sequence;
* average remaining conditional loss `alpha <= epsilon/2`;
* `|C| <= K/epsilon` for a constant K;

for which every exact bounded positive factorization of the tested mask
has `max(G_A,G_B) -> infinity`. Consequently there is no universal kappa
such that all such instances have both masses at most
`exp(kappa epsilon |C|)`.

**Construction and proof.** Let `H_L` be the Kempe-Regev binary line game.
Its commuting gap is `epsilon=1/(2L-1)`, since its classical and
no-signaling values coincide. Their primary Theorem 4.4 supplies a
deterministic classical strategy on `N=L^2` rounds with all-wins
probability at least a constant c_0>0 for all large L. A random classical
construction may be fixed to a seed attaining its mean.

Apply the elementary greedy lemma with stopping loss epsilon/2 to this
strategy. It supplies `C_0`, `|C_0| <= 2 log(1/c_0)/epsilon`, tested
success probability at least c_0 and remaining conditional loss at most
epsilon/2. The process is proper for large L because N is of order
epsilon^-2.

Form a new game G_L with the same questions and two bits of answer per
player: the old line-game bit and an auxiliary nuisance bit. Require both
the old predicate and the nuisance predicate `a<=b`. Its commuting value
equals that of H_L: dropping nuisance bits gives the upper bound, and
constant auxiliary answers `(0,1)` give the reverse bound. Thus the
positive base gap is unchanged and each answer alphabet has size four.

Add `T=floor(epsilon^(-3/4))` independent dummy rounds to the old N-round
strategy. On those dummy rounds use the base line game's constant-answer
optimal strategy. On their nuisance bits use independent local P,Q with
`r=T^(-2/3)`. On every original N-round coordinate use deterministic
accepted nuisance answers `(0,1)`. Test `C=C_0 union {all dummy rounds}`.
Then

`p_C >= c_0 (1-epsilon)^T (1-r^2)^T -> at least c_0`,

so eventually `p_C>=c_0/2`. The remaining live coordinates are precisely
the old live coordinates, with unchanged conditional loss at most
epsilon/2. Also `|C|<=K/epsilon` for some fixed K.

It remains to show that arbitrary factorization using *all* tested
answers, including the old base answers, cannot evade Proposition A.
At any original R exposure flag, the coarse local scalar output laws
factor as `P_0(a)P_T(z)` and `Q_0(b)Q_T(w)`. Here `(a,b)` collects old
base answers and deterministic nuisance coordinates; the old base mask
is `vartheta_0(a,b)`. Restrict an arbitrary exact full-mask factorization
to any accepted base pair `(a,b)`. Its factors in z,w constitute an exact
factorization of theta_T. Proposition A's proof therefore gives

`sum_k lambda_k [E f_k(a,Z)+E g_k(b,W)] >= 2 beta_T`,

where `beta_T=[(1+r)sqrt(1-r)]^T`. Multiply by
`P_0(a)Q_0(b)vartheta_0(a,b)` and sum. Each one-sided acceptance weight
is at most one, so the left side is at most the full `G_A+G_B`.
The right side is `2 beta_T p_0` with p_0 the old base tested-event
probability at that flag. Averaging flags yields

`max(G_A,G_B) >= beta_T p_base,C`,

with `p_base,C >= c_0(1-epsilon)^T >= c_0/2` eventually. Since
`log beta_T = (1/2+o(1))T^(1/3) = Omega(epsilon^-1/4)`, the actual
masses diverge. But `epsilon |C|` stays bounded. QED.

This is an obstruction to a **uniform per-instance mass claim**. It
does not show that the greedy algorithm must select these dummy rounds;
an adaptive choice can avoid nuisance. Nor does a large upper-bound
normalization G imply a large actual entropy telescope. An argument using
the telescope itself, a semantic quotient, or a specially selected C may
still recover a quadratic rate. The construction is itself reducible to
the line game, so its actual repetition rate has no new obstruction.

## Constructive repair: local-answer retractions

### Proposition C: exact equality of all commuting repeated values

Let G and H have the same finite question sets and joint referee law.
Suppose there are local answer maps `pi_x:A_G->A_H`,
`rho_y:B_G->B_H` and local lift maps `s_x:A_H->A_G`,
`t_y:B_H->B_G` such that for every supported question pair and answers,

`V_G(x,y,a,b) <= V_H(x,y,pi_x(a),rho_y(b))`,

`V_H(x,y,a',b') <= V_G(x,y,s_x(a'),t_y(b'))`.

Then for every positive integer n,

`omega_co(G^n)=omega_co(H^n)`.

**Proof.** Coarse-grain each player's n-round answer POVM coordinatewise
using pi and rho. Positivity, completeness and between-player commutation
are preserved, and every G-winning tuple becomes H-winning. Hence
`omega_co(G^n)<=omega_co(H^n)`. Conversely deterministically postprocess
an H answer tuple by s and t. Every H-winning tuple becomes G-winning,
which proves the reverse inequality. Approximate optimizers suffice;
neither maximum attainment nor finite Hilbert dimension is used. QED.

In particular the quadratic conclusion transfers, under its named source
premises, to every game locally equivalent in this sense to a
disjoint-block game. Multiplying by an arbitrary auxiliary answer-only
predicate with a fixed accepted pair is an example. Such masks can have
overlapping rectangles and can exhibit the mass obstruction above.
This is a useful larger class, but the transfer mechanism is elementary
and its priority is unassessed. It does not turn arbitrary games into
projection games while preserving their values.

## Existing literature and limits of the audit

* [Lin, arXiv:2510.07162v1, Theorem 9.3 / Theorem A.1](https://arxiv.org/html/2510.07162v1#S9)
  gives commuting repetition after his specific anchoring transformation,
  with a displayed epsilon^17 exponent and an epsilon-dependent prefactor.
  The transformed game is essential; its theorem does not apply directly
  to every original unanchored G. I checked the primary statement and
  anchoring restriction, not the full 167-page paper.
* [Song, ECCC TR26-199](https://eccc.weizmann.ac.il/report/2026/199/)
  explicitly claims the same cubic-gap dependence in the tensor-entangled
  model, with smooth labels. That is the source-credited predecessor of
  the sampler's smooth-label mechanism; the current tracial/opposite-algebra
  construction is the extra interface. An ECCC posting alone does not
  independently validate the preprint. I did not reconstruct Song's
  entire repetition proof as an alternative import.
* [Kempe-Regev, arXiv:0911.0201v1, Definition 3.1, Theorems 3.2 and 4.4](https://arxiv.org/html/0911.0201)
  provide the primary line-game gap and classical repetition lower bound.
  Commuting correlations are no-signaling, so their equal base values
  sandwich the commuting value exactly. This gives the fixed-answer
  quadratic-rate obstruction. It remains compatible with the conditional
  disjoint-block quadratic upper rate.

The generic product-strategy binomial tail prevents threshold rates
exceeding the binary-relative-entropy scale. The line game's all-wins
event supplies an additional quadratic-gap ceiling. Neither lower bound
establishes a matching universal threshold rate. I found no algebraic
error in the scalar factorial-moment wrapper read here; its premise must
remain the precise uniform conditional inequality for all relevant
strategies and repetition lengths. Its legally constructed independent
blocks are compatible with the commuting model. The improved event
wrapper is not automatic from an all-wins bound alone.

## Initial claim ledger and next attacks

| Claim | Initial audit status |
|---|---|
| Actual S/R/H near-perfect interface as written | No fatal gap found in inspected proofs; correctly scoped Lin import retained |
| General cubic all-wins rate with the displayed source constant | Supported conditional deduction from that chain; no priority claim |
| Disjoint-block/projection quadratic rate | Weighted-mass proof survives inspected attacks, conditional on same full interfaces |
| p tending to one forces bounded optimal positive-factorization masses | **Disproved**, Proposition A |
| Bounded p, alpha<=epsilon/2 and `|C|=O(1/epsilon)` force masses `exp(O(epsilon|C|))` in every R/H instance | **Disproved**, Proposition B |
| Retraction-equivalent games have the same repeated commuting values | **Proved here**, elementary Proposition C; novelty unassessed |
| Every game has a quadratic commuting repetition rate | **Open in this audit**; obstruction does not refute it |
| An adaptive tested-set choice always avoids the mass obstruction | **Open** |
| Direct entropy-endpoint control bypasses large optimal masses | **Open** and a more promising target than another coefficient bound |
| Efficient finite-dimensional/physical implementation | **Not established** |

The most consequential next operation is to make the entropy argument
invariant under such harmless answer extensions, either by an appropriate
semantic quotient before reconstruction or by controlling actual entropy
increments instead of their mass upper bounds. A proof merely asserting
small optimal one-sided mass from near-perfect p and alpha is blocked by
Propositions A-B. A different choice of C is a distinct possible repair
and must be proved, not inferred from this counterexample.
