# Synthesis candidate: heterogeneous quadratic direct product

Developed by principal after initial independent notes were frozen and after reading machinery/auditor initial reports. Not an independent initial report.

## Candidate theorem

For arbitrary finite two-player games G_1,...,G_N, each with vertex-disjoint biclique winning masks for every supported question pair, independent between-coordinate referee laws mu_i, and commuting gaps epsilon_i=1-omega_co(G_i),

 omega_co(G_1 tensor ... tensor G_N) <=exp[-2^-75 sum_i epsilon_i^2].

Conditional on the inherited exact resolvent/fine-POVM construction and operational all-input sampler, with Lin finite-table closure at fixed tested probability. This should follow without new sampler by retaining individual coordinate budgets instead of averaging them.

## Coordinate reconstruction claim and proof target

For an actual tested event E_C of probability p>0, put L=log1/p. Let e_u,i,e_z,i be the unnormalized squared resolvent alignment errors for live coordinate i before averaging over i. Weighted mass one gives

 sum_i e_u,i <=p L; sum_i e_z,i <=p L.

Let d_i=D(Q_{X_iY_i|E_C} || mu_i). Product-question relative entropy gives sum_live d_i<=L. Define

 tau_i=(e_u,i+e_z,i)/p+d_i, so sum_i tau_i<=3L.

For each coordinate, apply the original abstract H mass lemma with ONE mode and with mu=mu_i. Its raw norm equalities and mass p hold coordinatewise. Pinsker bounds both live marginal TV errors by sqrt(d_i/2). Consequently delta_A,i,delta_B,i<=(1+1/sqrt2)sqrt(tau_i); D_i<=16tau_i; Aalign_i<=4tau_i. The source's actual operational sampler proof therefore yields an individual legal strategy for G_i with loss at most

 alpha_i+K[sqrt(alpha_i)tau_i^(1/4)+sqrt(tau_i)]+accuracy,

where alpha_i=P(loss_i|E_C), K=65536. Different coordinates may use different finite resources; only existence of a separate single-game strategy is asserted. Each fixed i must still use one all-input resource across its own histories and fresh questions. Finite compression errors go to zero at fixed p, then scalar continuity and Lin close the finite table. Nonidentical mu_i do not change conditional independence in fixed exposure: each live coordinate still has its own original joint mu_i.

Thus each positive-gap live coordinate with alpha_i<=epsilon_i/2 must have tau_i>=t0 epsilon_i², where t0=2^-72, by the same source scalar contradiction.

## Weighted greedy proof

Fix any repeated strategy with all-wins probability theta>0 and Ltheta=log1/theta. Starting C empty, add any positive-gap coordinate for which alpha_i>epsilon_i/2. After every addition, negative log tested success increases by at least epsilon_i/2. Hence

 sum_{i in C} epsilon_i <=2 log1/p_C<=2 Ltheta.

If Ltheta>=S/4, S=sum_i epsilon_i², the desired gamma=2^-75 bound is trivial. Otherwise the process cannot exhaust all positive-gap coordinates: their epsilon sum >=S>2Ltheta. Stop with every remaining positive-gap alpha_i<=epsilon_i/2. Then

 t0 (S-2Ltheta) <= t0 sum_live epsilon_i² <= sum_live tau_i <=3 log1/p_C<=3 Ltheta.

Therefore Ltheta>=t0 S/(3+2t0)>2^-74 S, in particular >=2^-75 S. Taking supremum over strategies proves the claim. epsilon_i=0 contributes nothing; if S=0 use bound1. No attained optimum or finite-dimensional approximation is needed. Tested questions/alphabets may vary by coordinate.

## Why it matters and limitations

This accumulates the square of each component gap, whereas the easy public-mixture extension only gives N times the square of the average gap. For very heterogeneous gaps these differ by an arbitrarily large factor. KRT SDP machinery already implies such a product bound for unique games; the meaningful target is general one-way projections/disjoint bicliques. This is an extension of source capital, not an independent replacement proof or a claim of priority.

Audit decisive point: verify individual Q_i really coincides with the original per-coordinate event-conditioned marginal and that the unaveraged telescopes retain sum error <=pL after heterogeneous fine-answer reconstruction. Check source R H coefficient/fine POVM layout and no hidden uniform-mode hypothesis. If this fails, retain only the abstract coordinate-budget theorem and state missing production precisely.
