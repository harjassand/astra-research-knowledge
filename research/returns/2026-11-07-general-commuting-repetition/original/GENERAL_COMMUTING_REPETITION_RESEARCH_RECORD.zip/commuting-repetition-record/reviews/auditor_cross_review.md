# Hostile cross-review after the independent freezes

6 November 2026. The independent auditor initial report remains unchanged.
This follow-up reads the principal's heterogeneous candidate, initial crown
calculation and common-information continuation, the machinery threshold
follow-up and constructor initial report. This is an exposed cross-review.
The scalar inversion Phi and the proposed common-information attack on
relative filters were supplied by the principal during this exchange. No
additional subagents were used.

## Disposition

The heterogeneous quadratic direct-product theorem survives this audit,
conditional on exactly the inherited S_actual/R/H interfaces and Lin
finite-table closure. The production steps do not require identical
coordinate games or identical within-round referee laws. Retaining the
unaveraged errors yields the sum of squared gaps.

One limit-passage qualification is essential: raw vector errors and tau_i
are representation-dependent, so Lin does not make them converge. Eliminate
them into the continuous scalar inequality (6) below before using Lin. The
stated constant 2^-75 is safe; the argument gives t0/(3+2t0), t0=2^-72.

The principal's exact crown mass optimum and robust common-information
inequality also pass, with a block-TV wording correction in Section 3.
The constructor's nuclear certificate strengthens my initial fixed-alphabet
positive-gap obstruction. Finally, the universal relative-filter criterion
(O) in the constructor report fails in its every-instance form with a
fixed universal kappa: the
conditional common-information argument in Section 5 supplies a rigorous
counterfamily. Adaptive choice of C, semantic quotient, or a different
representation remains possible. These conclusions are mathematical checks
of supplied arguments, not independent external verification or priority.

## 1. Heterogeneous production

Let G_i=(X_i,Y_i,A_i,B_i,mu_i,V_i), 1<=i<=N, be finite two-player games
with nonempty answer alphabets. Full question law is tensor_i mu_i; each
mu_i can be arbitrarily correlated within its round. Every supported
fixed-question winning mask is assumed to be a union of vertex-disjoint
complete bipartite blocks. Put epsilon_i=1-omega_co(G_i), K=2^16.

Fix a product-game strategy, a proper tested set C, its actual event E of
winning every tested coordinate, p=P(E)>0 and L=log(1/p). Let I=[N]\\C
be live coordinates and alpha_i=P(loss_i|E). Initially use the bounded
positive finite-tracial representation in R; the algebra can be infinite.

### 1.1 Unaveraged entropy telescopes

Order the live coordinates i_1,...,i_m. At exposure stage j the flag has
all tested question pairs, Alice's questions at i_1,...,i_j and Bob's at
i_(j+1),...,i_m. At every live round one question is fixed and the other
has its original conditional law from mu_i. Different rounds remain
independent. Thus unrevealed Alice and Bob questions are independent
conditional on this flag, as required by R Section 1. Equality of the
mu_i is not used.

For each tested question string, factor the product tested mask by one
rectangle for every tuple of accepted blocks. Row supports and column
supports are disjoint. These factors use tested questions only. The
merged coarse effects F_j^k,H_j^k therefore satisfy, at each flag,

    sum_k F_j^k <= I,   sum_k H_j^k <= I.

For chi(F,H)=tr(sigma F sigma H), define the source potentials

    U_j=E_flag sum_k chi(F_j^k log F_j^k,H_j^k),
    Z_j=E_flag sum_k chi(F_j^k,H_j^k log H_j^k).

The exact tested mass equals p at every stage, by R (A1) and total
expectation. Positive-functional Jensen/log-sum with both masses <=1
gives -pL<=U_j,Z_j<=0. R lines 137-146 give individual error bounds by
the corresponding potential increments, with mu_i in the finite
conditional expectations. Summing before dividing by m yields

    sum_(i in I) e_u,i <= pL,
    sum_(i in I) e_z,i <= pL.                              (1)

Here e_u,i compares v_i with Alice-local u_i, and e_z,i compares v_i with
Bob-local z_i. The source divides only after telescoping. No uniform-mode
assumption is hidden in (1). Varying answer alphabets also causes no
problem: the tested mask is fixed globally, while live fine measurements
have their respective finite alphabets A_i,B_i.

### 1.2 Exact per-coordinate posterior and fine POVMs

For live i remove its question pair from the flag to obtain r_0, with
original law nu_i. This r_0 is independent of the fresh pair distributed
as mu_i. Augment it by the tested rectangle label and use the inherited
nonnegative weight w_i(r). The R resolvent construction gives

    ||u_(i,r,x)||^2=sum_y mu_i(y|x)||v_(i,r,x,y)||^2,
    ||z_(i,r,y)||^2=sum_x mu_i(x|y)||v_(i,r,x,y)||^2,
    sum_(r,x,y) w_i(r)mu_i(x,y)||v_(i,r,x,y)||^2=p.          (2)

Consequently

    Q_i(r,x,y)=w_i(r)mu_i(x,y)||v_(i,r,x,y)||^2/p            (3)

is normalized separately for each i. Its question-pair marginal is
exactly the original coordinate-i marginal conditioned on E. The R
support/polar fine-POVM transports preserve, after summing r, the actual
conditional live answer table. Their mean ideal loss is alpha_i. The
original event, p and joint referee law have not changed.

Finite scalar-feature compression has sum_l g_l(T)^2=T exactly. Thus
(2)-(3) and alpha_i stay exact in every finite auxiliary amplification.
Each compressed error converges to its raw error as accuracy improves.
Only finitely many effects occur; one common compression accuracy is
possible, or separate single-coordinate existence arguments can use
separate finite accuracies. Coefficient mass still enters the required
accuracy, exactly as in R (A7), and is finite at fixed table and p.

### 1.3 Coordinate KL and the one-mode H lemma

Let d_i=D((Q_i)_(X_iY_i)||mu_i). The conditioned full question density
relative to tensor_i mu_i is P(E|questions)/p<=1/p. Marginalizing to live
rounds and applying relative entropy to a product gives

    sum_(i in I) d_i <= L.                                (4)

This does not require identical mu_i or within-round independence.
Zero-mu_i cells also have zero conditioned probability.

Apply H (M1)-(M7) with one mode, mu_i, w_i and mass p. Put

    tau_i=(e_u,i+e_z,i)/p+d_i.

Each local-law TV error is at most (1+1/sqrt(2))sqrt(tau_i), from the
raw norm error and Pinsker sqrt(d_i/2). Normalized descriptor discrepancy
is <=16tau_i and ideal-target alignment <=4tau_i, retaining the source's
safe constants. For each fixed i, S_actual is used on that entire finite
history/question family under Q_i. The single-game resource may differ
between i's: separate legal strategies for the base games suffice. Within
one i there is one input-independent resource and complete commuting
effects on all histories, including mismatches. H's finite shared history
coupling and law transfer are unchanged. The quantitative promise remains
under Q_i; TV and mismatch stay outside the event cross term.

The ordered source accuracy limits, at fixed p, therefore prove

    epsilon_i <= alpha_i+K[sqrt(alpha_i)tau_i^(1/4)
                                       +sqrt(tau_i)].       (5)

Equations (1),(4) give sum_i tau_i<=3L. The precise inherited dependencies
are sampler (15)-(22), R (A1)-(A9), H (M1)-(M8), and the weighted-mass
Jensen endpoint refinement. No arbitrary-Hilbert descriptor theorem,
finite-matrix approximation or new device assumption is added.

### 1.4 Eliminate raw errors before using Lin

For e,a>=0 set

    b=(e-a)_+,
    Phi_K(e,a)=[(sqrt(a+4b/K)-sqrt(a))/2]^4.

This is continuous and nonnegative. With z=tau^(1/4), (5) implies
b<=K(sqrt(a)z+z^2). Solving this scalar quadratic yields
tau>=Phi_K(e,a). Thus the finite-tracial result is the purely scalar
inequality

    sum_(i in I) Phi_K(epsilon_i,alpha_i)<=3log(1/p).         (6)

Now apply Lin to the entire finite heterogeneous product-game table. At
fixed C,p>0, approximant probabilities and conditional losses converge.
Base gaps epsilon_i are fixed and unchanged. Apply (6) to each approximant
and use scalar continuity. This proves (6) for arbitrary commuting
strategies. No raw errors, modules, vectors or tau_i need converge.

More generally, uniform tested load bounds G_A,G_B<=exp(sum_C kappa_j)
give sum_live Phi<=3log(1/p)+2sum_C kappa_j by the same calculation,
provided those bounds hold uniformly on finite-tracial approximants.
Only the zero-load disjoint-block case is used here.

## 2. Complete heterogeneous direct-product deduction

Set t0=1/(256K^4)=2^-72. For e>0 and a<=e/2,

    Phi_K(e,a)>=t0 e^2.                                   (7)

Indeed if tau<=t0 e^2, the right side of (5), divided by e, is <=
1/2+1/(4sqrt(2))+1/(16K)<1, a contradiction.

Fix a product strategy with all-wins probability theta>0 and write
L_theta=log(1/theta). Start C empty, adding any positive-gap coordinate
whose current conditional loss exceeds epsilon_i/2. Its conditional
success is positive because theta>0. Each addition increases log(1/p_C)
by at least epsilon_i/2. Hence throughout the process,

    sum_(i in C) epsilon_i<=2log(1/p_C)<=2L_theta.           (8)

If all positive-gap coordinates are exhausted, S=sum_i epsilon_i^2 is
<=2L_theta, already stronger than required; no empty-live-set R/H step
is attempted. Otherwise the process stops with alpha_i<=epsilon_i/2
at every positive-gap live coordinate. Equations (6)-(7) give
t0 sum_live epsilon_i^2<=3L_theta. Since epsilon_i^2<=epsilon_i, the
tested contribution is <=2L_theta by (8). Thus

    S<=(2+3/t0)L_theta,
    L_theta >= [t0/(3+2t0)]S >2^-74 S >2^-75 S.             (9)

Taking the supremum proves

    omega_co(G_1 tensor ... tensor G_N)
                          <=exp[-2^-75 sum_i epsilon_i^2].

Theta=0 is trivial; S=0 gives bound one. Zero-gap coordinates contribute
zero and are never selected. There is no minimum positive gap, dimension
bound, attained optimum or large-N restriction. N is finite in each
application. This is stronger than the public-mixture consequence
exp[-cN(average epsilon)^2] for heterogeneous gaps. Known unique-game SDP
product arguments remain an essential comparator; novelty for general
projection/disjoint-block products has not been established here.

## 3. Crown and common-information checks

### 3.1 Exact crown mass optimum: PASS

For even m and mask 1{a!=b}, each positive atom's coordinate row/column
projections are disjoint. Its product measure is <=4^-t. The principal's
AM-GM argument gives max(G_A,G_B)>=2^t(1-1/m)^t for every global
factorization. Averaging all balanced rectangles with total coefficient
4(m-1)/m achieves both masses 2(m-1)/m in one coordinate; tensoring
achieves equality for all t. At m=2 this is one, correctly matching a
block mask. No multiplicativity of a nonnegative-factorization LP is used.

The growing-alphabet p->1 example is valid. It is an exact optimum,
whereas my initial triangular-mask argument gave a lower bound and the
positive-gap/fixed-alphabet quantifiers. The constructor's nuclear
certificate below improves the latter quantitatively.

### 3.2 Exact common information: PASS, established predecessor

Conditional independence of the full vectors makes each component's
support a rectangle of cardinality <=(m^2/4)^t. Its conditional entropy
is <=2t log(m/2). Subtract from target entropy to obtain the lower bound
t log[4(1-1/m)]; independent balanced-subset components attain it. No
coordinatewise restriction on possible separator variables is assumed.

I inspected the primary [Cuff-Permuter-Cover, Coordination Capacity,
Example 7 after Theorem 10](https://isl.stanford.edu/~cover/papers/2010coordination.pdf).
It is the same unequal-task distribution and Wyner common-information
calculation. The principal's correction crediting that source is necessary.
The current proof applies established common information rather than
introducing it.

### 3.3 Robust inequality: PASS, with a block-TV wording correction

Suppose the full-vector law R' is within TV eta of R_m^tensor t and
eta<=1/m. Each coordinate collision probability is <=eta. Conditional on
the separator K, let p,q be its two coordinate marginals and
c=sum_a p_a q_a. Independence given K makes c the collision probability.
For a fair binary selector of p or q, Bayes error obeys

    e=(1-TV(p,q))/2 <=(sum sqrt(p_a q_a))/2 <=sqrt(m c)/2.

Binary Fano and mixture entropy give
(H(p)+H(q))/2<=log m-log2+h(e). Average over K, then use concavity of
h and Cauchy-Schwarz. Since E e<=sqrt(m eta)/2<=1/2, monotonicity of h
on that interval is applicable. Conditional entropy subadditivity and
continuity on m^(2t) outcomes give exactly

    I(K;A^t B^t)>=t{log[4(1-1/m)]
              -2h(sqrt(m eta)/2)-2eta log m}-h(eta).

All logarithms and h are in natural units, with h(0)=0. The per-coordinate
conclusion for eta=o(1/m) is uniform over finite t>=1.

Required wording correction: independent uniform U on the two full vectors
has

    TV(U,R_m^tensor t)=1-(1-1/m)^t,

because the target is U conditioned on no coordinate equality. This is
1/m only at t=1. Thus error 1/m erases the one-coordinate obstruction.
For growing t the independent-block repair costs 1-(1-1/m)^t, of order
t/m when t/m->0. The robust theorem is unaffected; the erasure example
must not be stated as a uniform full-block claim.

These separator bounds do not attack the acquired S_actual/H interfaces.
H does not require a classical K making the full conditioned answer law
independent; it uses one-sided local histories and an operational
approximation of correlations.

## 4. Stronger fixed-alphabet positive-gap obstruction

The constructor's nuclear certificate is correct:

    ||D_P^(1/2) M D_Q^(1/2)||_* <=sqrt(G_A G_B).

Use nuclear-norm triangle inequality on rank-one terms, f^2<=f, g^2<=g
and Cauchy-Schwarz. The triangular binary mask under uniform marginals
has nuclear norm sqrt(5)/2, which tensorizes. Shared equal uniform
nuisance bits are always accepted by this mask, so the tested p can be
exactly one. This strengthens my skew-product example. It remains true
that actual entropy increments can vanish despite large mass bounds.

The constructor's general nuisance inequality also passes: restrict to
each accepted original answer pair, apply the nuclear certificate, average
with its accepted joint mass, and use two Cauchy-Schwarz steps plus
domination by full marginals. This yields

    max(G_A,G_B)>=p (sqrt(5)/2)^|C|.

Combine it with my positive-gap padding construction. Use the line-game
N=L^2 classical strategy with all-wins >=c_0 and greedy near-perfect C_0.
Add T=floor(1/epsilon) independent dummy rounds playing the base constant
answer optimum, testing all of them. Their success (1-epsilon)^T stays
bounded below. Append shared equal uniform nuisance bits to all rounds;
they always win and preserve p and conditional live loss. The resulting
game has four answers per player and the same positive gap epsilon.
Its tested instance satisfies bounded p, alpha<=epsilon/2 and
|C|=O(1/epsilon), |C|>=T, yet every exact pointwise positive
factorization has

    max(G_A,G_B)>=exp(Omega(1/epsilon)).

For fixed kappa, exp(kappa epsilon |C|) stays bounded. This is the strongest
combined exact-factorization obstruction. Adaptive C, support changes,
semantic quotient and direct entropy control remain escapes; the nuisance
game has the same product values as the underlying line game.

## 5. Universal relative-filter acquisition is obstructed

This section checks the principal's proposed common-information attack on
the constructor's open criterion (O) with fixed universal kappa. The attack
is valid, including when
factorizations and filter errors are averaged over the R exposure flags.
It uses growing answer alphabets; no fixed-alphabet approximation
impossibility is asserted here.

### 5.1 Positive filter masses bound separator information

Start with independent scalar local laws P,Q and a bounded filter

    theta'(a,b)=sum_k lambda_k f_k(a)g_k(b),
    lambda_k>=0, 0<=f_k,g_k<=1, 0<=theta'<=1.

Let x_k=P(f_k), y_k=Q(g_k), p'=E_PQ theta'>0. Discard zero-weight
components and put w_k=lambda_k x_k y_k/p'. The conditional law
R'=P Q theta'/p' is the mixture with weights w_k of the product laws
P f_k/x_k and Q g_k/y_k. Thus A and B are independent given k.

The relative-entropy chain rule gives

    I(k;AB)+D(R'||P Q)
      =sum_k w_k[D(P f_k/x_k||P)+D(Q g_k/y_k||Q)]
      <=E_w log(1/(x_k y_k)).

The inequality uses f_k,g_k<=1. Jensen and the exact identities
E_w(1/x_k)=G_B/p', E_w(1/y_k)=G_A/p' then give

    I(k;AB)+D(R'||P Q)<=log(G_A G_B/(p')^2).                (10)

In particular the required separator information is <=2log(B/p') if
both masses are <=B. Zero marginal cells cause no problem.

The same argument allows arbitrary finite shared context c with original
law nu(c), local laws P_c,Q_c, factors lambda_(c,k),f_(c,k),g_(c,k), and
globally averaged masses and probability. It gives

    I(k;AB|c)+E_(R'_c) D(R'_(AB|c)||P_c Q_c)
                          <=log(G_A G_B/(p')^2).           (11)

The posterior marginal of c can differ from nu. Formula (11) follows by
the same mixture chain rule conditional on c; no entropy of c is paid.

### 5.2 The robust crown inequality survives arbitrary side context

Suppose a target law on (S,Z^t,W^t) is pi(S) times R_m^tensor t, while
the actual law R' is within full TV beta<=1/m. Suppose Z^t,W^t are
independent given (k,S). Then

    I(k;Z^t W^t|S)>=t{log[4(1-1/m)]
              -2h(sqrt(m beta)/2)-2beta log m}-h(beta).     (12)

Proof: each coordinate collision probability under R' is <=beta. Apply
the Fano argument from Section 3 conditional on (k,S) and average. This
bounds H(Z^t W^t|k,S) by
2t log m-2t log2+2t h(sqrt(m beta)/2).

For the other entropy, conditional-entropy continuity gives

    H_(R')(Z^t W^t|S)>=t log[m(m-1)]
                                    -2t beta log m-h(beta).

Here the continuity cost is independent of the alphabet of S. A direct
proof writes the target and actual laws as mixtures of their common
part of mass 1-delta and two residual laws of mass delta, with
delta=TV<=beta. Conditional entropy is concave, and its mixture defect
is at most h(delta). Its range for the nuisance variables is
[0,2t log m]. Their difference is therefore <=2t delta log m+h(delta),
which is <=the displayed beta bound. Subtraction proves (12).

For use with (11), put S=(c,a,b), where a,b collect original base-game
answers and c is the exposure context. A positive factor's full local
outputs are product given (c,k), so nuisance outputs remain independent
given (k,c,a,b). The chain rule yields

    I(k;nuisance pair|c,a,b)<=I(k;all outputs|c).

Consequently (11)-(12) force large averaged masses even if filter error
is concentrated on exceptional flags or base answer pairs. No separate
per-flag accuracy hypothesis is required.

### 5.3 Positive-gap near-perfect counterfamily to criterion (O)

Let the base be the length-L line game with
epsilon=1/(2L-1). Set even m=2L and t=m. Enlarge each local answer by
a nuisance symbol in [m], accepting it iff the two symbols differ.
The new game's commuting gap is still epsilon: dropping symbols gives
one inequality, and fixed distinct symbols give the other.

As above, use an N=L^2 line-game strategy with all-wins >=c_0, and select
C_0 greedily so |C_0|=O(1/epsilon), p_(C_0)>=c_0 and conditional
live loss <=epsilon/2. Add t independent dummy rounds playing the base
constant-answer optimum. On dummy nuisance answers use independent local
uniform symbols; on the old N-round block use fixed distinct nuisance
symbols. Test C=C_0 union {all dummy rounds}. Then

    p>=c_0 (1-epsilon)^t (1-1/m)^t,

so p stays bounded below. Conditional live loss remains <=epsilon/2,
|C|=O(1/epsilon), and epsilon |C| stays bounded. Conditioned on the
actual tested event, the t active nuisance pairs have law R_m^tensor t
independent of all tested/exposure/base-answer context.

Consider any proposed bounded filter theta' on the tested questions and
answers with original weighted l1 error eta<=epsilon p/8 and an exact
bounded positive factorization. As in the constructor's smoothing lemma,
its success p' obeys p'>=p(1-epsilon/8), and its normalized conditional
table R' is within TV beta=epsilon/8 of the target. This statement also
holds after including R's exposure flag: the flag is an original
classical question function and total expectation preserves the error.

At any R exposure stage, the classical construction has independent
unrevealed local questions, so its coarse local effects are scalar
product laws P_c Q_c. Thus (11) applies to its actual averaged masses.
After conditioning base answers, (12) applies to the nuisance pair.
Now m beta=(2L)/(8(2L-1))->1/8, and

    log4-2h(1/(4sqrt(2)))>0.

The other per-coordinate terms in (12) vanish as L grows. Hence the
separator information is >=c t for some absolute c>0 and all large L.
Equations (11)-(12), with both masses <=B, imply

    B>=p' exp(c t/2)=exp(Omega(1/epsilon)).                 (13)

But criterion (O) asks for B<=exp(kappa epsilon |C|), which stays bounded
for any fixed kappa. This is a contradiction. Therefore that universal
every-instance relative-filter acquisition criterion with kappa independent
of the game family is **disproved**, even on actual positive-gap
near-perfect tested instances. Allowing kappa to grow with the gap or
alphabet is not excluded and gives weaker rates. The source
filter-transfer theorem remains a valid sufficient conditional statement;
its hypothesized filters simply cannot always be acquired as stated.

This obstruction does not refute an existence theorem selecting a
different C, a preprocessing quotient that removes nuisance answers, an
operator-valued construction or a direct entropy-increment argument.
The constructed game's product values equal those of the underlying
line game. No lower bound on its actual repetition rate is claimed.

## 6. Competing threshold wrappers

The machinery and constructor independently derive the valid intrinsic
zero-charge threshold rate delta^5/epsilon^3. Their decisive correction
replaces the old positive alphabet-log argument by
log(1/s)>=epsilon/4, s=v+3delta/4, keeping the factorial-moment cutoff
proper even when the charge is zero. The constructor improves the
constant using s[log(1/s)+a]<=epsilon: indeed
s log(1/s)<=1-s=epsilon-3delta/4 and a<=delta/256.
Thus his constant 2^-77 for K=2^16 is consistent with the proof; the
machinery constant 2^-78 is safely weaker.

These wrappers require the uniform operational near-perfect premise over
all relevant strategies and lengths. Their legal tensor-block construction
removes the short-length cutoff without assuming original coordinate-win
independence. The heterogeneous theorem is a distinct direct-product
operation, not obtained merely by inserting varying gaps in these formulas.

No optimal threshold rate, general quadratic theorem outside the stated
class, efficient finite-dimensional compiler, physical advantage or
historical-priority claim is established by this cross-review.
