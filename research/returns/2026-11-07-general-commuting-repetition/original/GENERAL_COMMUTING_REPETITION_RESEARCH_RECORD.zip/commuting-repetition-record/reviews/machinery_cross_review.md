# Machinery cross-review: heterogeneous quadratic commuting products

6 November 2026. Synthesis-stage report. I read `principal_heterogeneous_candidate.md` after my independent initial report was frozen. This report incorporates the principal's coordinatewise route and the auditor's scalar-before-Lin repair. It does not change the independent report.

## Disposition

The heterogeneous route is viable at the exact inherited R/H/S_actual interfaces. In particular, the conditioning mass is the same positive number \(p\) for every live coordinate, and no uniform-mode hypothesis is needed. The two details that should be in the final proof are:

1. Retain the **sum** of the two unaveraged squared alignment errors and the per-coordinate referee relative entropies.
2. Eliminate these representation-dependent errors into a continuous finite-table inequality **before** applying Lin's closure. Do not claim convergence of the raw errors.

The following is a stronger clean version of the principal's candidate, still conditional on the inherited reconstruction and operational sampler. It covers genuinely heterogeneous one-way projection/disjoint-block games and suitable near-block games. It does not claim a new complexity-class identification.

## 1. Formal theorem with an averaged intrinsic charge

Let \(G_1,\ldots,G_N\) be finite two-player games, with independent between-coordinate referee laws \(\mu_i\), arbitrary correlations within each \(\mu_i\), finite nonempty alphabets, and Boolean predicates \(V_i\). Write
\[
 \epsilon_i=1-\omega_{\rm co}(G_i),\qquad S=\sum_{i=1}^N\epsilon_i^2.
\]

For every supported question pair \((x,y)\) of \(G_i\), choose a finite nonnegative fractional rectangle partition
\[
 V_i(x,y,a,b)=\sum_r w_{i,xy,r}\mathbf1_{U_{i,xy,r}}(a)
                                  \mathbf1_{T_{i,xy,r}}(b).
\]
Choose bounds \(A_i(x,y),B_i(x,y)\ge1\) on its two local loads:
\[
 \max_a\sum_{r:a\in U_r}w_r\le A_i(x,y),\qquad
 \max_b\sum_{r:b\in T_r}w_r\le B_i(x,y).
\]
Set
\[
 a_i=\mathbb E_{\mu_i}A_i(X,Y),\quad
 b_i=\mathbb E_{\mu_i}B_i(X,Y),\quad
 \kappa_i=\tfrac12\log(a_ib_i)\ge0. \tag{1}
\]
This allows asymmetric partitions. The initial report's simpler choice is \(A_i=B_i=\rho(V_{i,xy})\), giving \(\kappa_i=\log\mathbb E\rho\). Formula (1) can be strictly smaller: for the three-edge matrix \(\left(\begin{smallmatrix}1&1\\1&0\end{smallmatrix}\right)\), a row-star partition has load bounds \((1,2)\), hence charge \(\tfrac12\log2<\log(3/2)\).

Assume the inherited exact finite-tracial resolvent/fine-POVM and history reconstruction and operational all-input event sampler S_actual hold at their source scopes, and use Lin's finite-table closure, arXiv:2304.01940v3, Theorem 3.2. If, for a constant \(C\ge0\),
\[
 \kappa_i\le C\epsilon_i \tag{2}
\]
for every positive-gap component, then
\[
 \omega_{\rm co}(G_1\otimes\cdots\otimes G_N)
 \le\exp\!\left[-\frac{2^{-75}}{1+C}
                         \sum_{i=1}^N\epsilon_i^2\right]. \tag{3}
\]
The same argument gives the sharper explicit coefficient
\[
 \frac{t_0}{3+4C+2t_0},\qquad t_0=2^{-72}, \tag{4}
\]
which exceeds \(2^{-74}/(1+C)\). The conservative coefficient in (3) is adequate and avoids making constants the contribution.

In the disjoint-block class take \(A_i=B_i=1\), so \(C=0\). This includes ordinary projections in either direction, partial matchings, and arbitrary fixed-question vertex-disjoint unions of bicliques. All alphabets and question laws may vary with \(i\). There is no finite-dimensional realization or resource-efficiency claim.

Zero-gap components with nonzero charge can be discarded before applying the theorem. Indeed, marginalizing the full strategy to a subset of coordinates is legal: sample the omitted independent question pairs as shared randomness and run the original strategy on the completed local questions. The all-wins event on all coordinates is contained in all wins on the retained subset. Dropping zero-gap components therefore leaves \(S\) unchanged and only weakens the upper bound.

## 2. Source production: the unaveraged heterogeneous budget

Fix a strategy for the whole product and a proper tested set \(D\), with actual event \(E_D\), probability \(p>0\), and \(L=\log(1/p)\). Write \(J=[N]\setminus D\).

The fixed-exposure flags remain
\[
 \Omega_j=(X_D,Y_D,X_{J,\le j},Y_{J,>j}).
\]
Under the original referee law \(\prod_i\mu_i\), full Alice/Bob question strings are conditionally independent given each flag, exactly as in the source. Each live coordinate retains its own conditional laws \(\mu_i(x\mid y)\), \(\mu_i(y\mid x)\). Neither the operator Jensen gap nor the resolvent representation requires these kernels to agree between coordinates.

For each \(i\in J\), the source's exact unnormalized vectors \(v_i,u_i,z_i\) satisfy the one-mode norm-marginal identities and have total mass **exactly \(p\)**. After dividing by \(p\), their measure \(Q_i\) is precisely the original law conditioned on \(E_D\), restricted to that coordinate's questions, history and fine answers. This follows from the source fine-answer identity A9 and total expectation; it is not an assumed posterior independence statement.

Let \(e_{u,i},e_{z,i}\) be the unnormalized squared alignment errors before averaging over \(i\). The rectangle partitions depend only on tested question pairs. Their products preserve the tested event and every fine-answer measure. The two positive-functional endpoint masses obey
\[
 G_A\le\prod_{j\in D}a_j,\qquad G_B\le\prod_{j\in D}b_j. \tag{5}
\]
To verify (5), first bound each fixed tested-question string by its product of local load bounds; then average under the **unconditioned** tested-question law \(\prod_{j\in D}\mu_j\). This is where the expectations in (1), rather than maximum loads or posterior loads, enter.

Weighted log-sum at the two ends of the exposure telescope gives, with the appropriate orientation,
\[
 \sum_{i\in J}e_{u,i}\le p\left[L+\sum_{j\in D}\log b_j\right],\qquad
 \sum_{i\in J}e_{z,i}\le p\left[L+\sum_{j\in D}\log a_j\right]. \tag{6}
\]
The factors are positive contractions even when their weighted total load exceeds one; the Jensen step only requires positivity and the displayed total mass. The coefficients influence finite-feature accuracy requirements, not this entropy budget.

Put
\[
 d_i=D(Q_i^{X_iY_i}\Vert\mu_i).
\]
The actual event density is at most \(1/p\), so relative entropy to the product referee law and its marginal lower bound give
\[
 \sum_{i\in J}d_i\le L. \tag{7}
\]
Define on a finite-tracial representation
\[
 t_i=(e_{u,i}+e_{z,i})/p+d_i.
\]
Equations (6)–(7) yield the key charge identity
\[
 \boxed{\sum_{i\in J}t_i\le3L+2\sum_{j\in D}\kappa_j.} \tag{8}
\]

For a fixed \(i\), apply the abstract source H mass lemma with one mode and question law \(\mu_i\). Pinsker gives each marginal question drift at most \(\sqrt{d_i/2}\), and hence
\[
 \Delta_{A,i},\Delta_{B,i}\le(1+1/\sqrt2)\sqrt{t_i},\quad
 D_i\le16t_i,\quad A_{{\rm align},i}\le4t_i.
\]
The source operational sampler calculation therefore produces a separate legal single-game strategy for \(G_i\) with loss at most
\[
 \alpha_i+K\big(\sqrt{\alpha_i}t_i^{1/4}+\sqrt{t_i}\big)+o(1),
 \qquad K=65536,\quad
 \alpha_i=\Pr(\text{loss at }i\mid E_D). \tag{9}
\]
There is no requirement that different \(i\) use a common sampler resource: these are separate existence statements for separate games. For each \(i\), its resource must still be fixed across all its own inputs and histories, including mismatched histories. S_actual supplies exactly that requirement.

Finite scalar compression adds arbitrarily small nonnegative error to the sum in (8). Since \(N\), the full finite alphabet and \(p>0\) are fixed, choose one sufficiently fine compression for the whole finite family, and send that error to zero after the sampler's inner accuracies. The original ideal \(\alpha_i\) and \(p\) are preserved. This step invokes only source R's exact normalization and fine-POVM construction, not matrix density.

## 3. Necessary Lin repair: eliminate representation-dependent errors

The principal's original wording should not assert that the raw \(t_i\) converge under Lin approximation. They need not. The auditor's scalar repair removes this issue completely.

For \(\epsilon,\alpha\in[0,1]\), define
\[
 a=(\epsilon-\alpha)_+,\qquad
 \Phi_K(\epsilon,\alpha)=
 \left[\frac{\sqrt{\alpha+4a/K}-\sqrt\alpha}{2}\right]^4. \tag{10}
\]
This function is continuous, including at zero and at \(\alpha=\epsilon\). If
\(\epsilon\le\alpha+K(\sqrt\alpha\,t^{1/4}+\sqrt t)\), put \(z=t^{1/4}\). When \(a>0\),
\(z^2+\sqrt\alpha z\ge a/K\), so the positive root gives
\(t\ge\Phi_K(\epsilon,\alpha)\). When \(a=0\), the conclusion is trivial.

The one-game commuting value bounds every rounded strategy in (9), so apply this inversion and then sum (8). First take all inner accuracies to zero in the finite-tracial calculation. The result is the scalar statement
\[
 \boxed{\sum_{i\in J}\Phi_K(\epsilon_i,\alpha_i)
 \le3\log(1/p)+2\sum_{j\in D}\kappa_j.} \tag{11}
\]
Now approximate an arbitrary commuting **finite product table** by Lin's finite-tracial tables. At the fixed target event with \(p>0\), \(p_m\to p\) and every conditional \(\alpha_{i,m}\to\alpha_i\). The \(\epsilon_i\) are fixed properties of the base games and the \(\kappa_i\) are fixed chosen load bounds. Continuity of (10) transfers (11). No raw-error/vector/state convergence, attained optimum, common limiting algebra, or efficient representation is used.

This is the right finite-table proposition to state before the greedy lemma. It isolates all operator-algebra production in one exact numerical interface.

For later use, the source scalar contradiction yields
\[
 \alpha\le\epsilon/2\quad\Longrightarrow\quad
 \Phi_K(\epsilon,\alpha)\ge t_0\epsilon^2,
 \qquad t_0=1/(256K^4)=2^{-72}. \tag{12}
\]
One can check (12) without differentiating \(\Phi\): if \(t<t_0\epsilon^2\), the right side of (9) is at most
\(\epsilon[1/2+1/(4\sqrt2)+1/(16K)]<\epsilon\).

## 4. Heterogeneous weighted greedy proof

Fix a product strategy with all-wins probability \(\theta>0\), and let \(L_\theta=\log(1/\theta)\). Start with \(D=\varnothing\). Whenever a positive-gap live coordinate has conditional loss \(\alpha_i>\epsilon_i/2\), test it and add it to \(D\).

Every event probability remains positive: all wins is contained in every tested success event. The increase in \(\log(1/p_D)\) on adding \(i\) is
\[-\log(1-\alpha_i)\ge\alpha_i>\epsilon_i/2.\]
Consequently, at every stage,
\[
 \sum_{j\in D}\epsilon_j\le2\log(1/p_D)\le2L_\theta,
 \quad\sum_{j\in D}\epsilon_j^2\le2L_\theta,
 \quad\sum_{j\in D}\kappa_j\le2CL_\theta. \tag{13}
\]
The algorithm terminates after finitely many additions. If it exhausts all positive-gap coordinates, \(S\le2L_\theta\), which is stronger than (3). Otherwise the terminal tested set is proper and every positive-gap live coordinate satisfies (12). Equations (11)–(13) give
\[
 t_0(S-2L_\theta)
 \le t_0\sum_{i\notin D}\epsilon_i^2
 \le\sum_{i\notin D}\Phi_K(\epsilon_i,\alpha_i)
 \le(3+4C)L_\theta.
\]
Thus \(L_\theta\ge t_0S/(3+4C+2t_0)\). The case \(\theta=0\) is trivial; \(S=0\) has the bound one. Taking the supremum over all strategies proves (3).

No hypothetical conditional strategy is used here. All \(p_D,\alpha_i\) belong to the actual original probability table, and the only consumed analytic proposition is the already transferred scalar statement (11).

## 5. Exact established heterogeneous comparators

### KRT: the unique-game restriction is already covered

For every unique \(G_i\), the proof in the independent report establishes
\[
 \omega_{\rm co}(G_i)\le s(G_i)\le1-\epsilon_i^2/16,
\]
where \(s\) is KRT SDP 3. KRT arXiv:0710.0655v3, Theorem 5.5, Lemma 5.7 and Section 5.3 prove the needed SDP product and rounding statements for **any pair of games**. Their product relaxation inclusion iterates over nonidentical games. Hence
\[
 \omega_{\rm co}(\bigotimes_iG_i)
 \le\prod_i s(G_i)
 \le\prod_i(1-\epsilon_i^2/16)
 \le\exp[-\tfrac1{16}\sum_i\epsilon_i^2].
\]
The direct commuting applicability uses measurement vectors in SDP 3, not a tensor/commuting equivalence. [Primary source](https://arxiv.org/html/0710.0655v3#S5).

### Dinur–Steurer: heterogeneous classical quadratic products are established

In the author PDF dated 10 June 2014, Theorem 3.3 gives
\(\|G\otimes H\|\le\operatorname{val}_+(G)\|H\|\), Theorem 4.1 compares \(\operatorname{val}_+(G)^2\) to \(2\sqrt{\operatorname{val}(G)}/(1+\operatorname{val}(G))\), and Claim 2.3 compares collision norm and game value. Iterating these statements gives heterogeneous classical products with a rate proportional to the sum of squared classical gaps. The arXiv:1305.1979v3 numbering calls the approximation theorem Theorem 1.10. [Author PDF](https://www.dsteurer.org/paper/productgames.pdf), [versioned arXiv](https://arxiv.org/html/1305.1979v3).

A search snippet from an older manuscript labels a mixed-product display Theorem 1.5 and loses a square-root/exponent in text extraction. Do not import that snippet's exact formula or numbering. The verified collision/product theorems above are sufficient for the comparison.

### DSV: heterogeneous tensor projection products with a larger gap power

DSV arXiv:1310.4113v2, Lemmas 6–8 imply, for arbitrary nonidentical projection games,
\[
 \omega^*(\bigotimes_iG_i)
 \le\left[\prod_i\operatorname{val}_+^*(G_i)\right]^{1/2}
 \le\prod_i[1-c\epsilon_{i,*}^{\,q}]^{1/2},\qquad q\le12,
\]
where \(\epsilon_{i,*}=1-\omega^*(G_i)\). The first inequality follows by iterating Lemma 8, using the lower relaxed-value comparison for the final factor and \(\omega^*\le\|\cdot\|_\square^*\). Lemma 7 supplies the factor gap; Theorem 1 records the exponent bound. Their expanding case has a better exponent with expansion dependence. [Primary source](https://arxiv.org/html/1310.4113v2).

This does not directly imply (3) for arbitrary commuting projection strategies. Its finite-matrix norm/rounding argument requires a separate commuting transfer. KRT subsumes the unique restriction; DSV supplies a strong conceptual predecessor for heterogeneous projection products, not the exact co/quadratic interface under discussion.

The bounded current-literature search found no primary theorem that directly subsumes the complete heterogeneous commuting projection claim at these hypotheses. This is not a historical priority certificate.

## 6. Scope and consequence audit

Lin's arXiv:2510.07162v1, Theorem 1.1 already states \(\mathsf{MIP}^{co}=\mathsf{coRE}\). Its anchored repetition Theorem 9.3 / Theorem A.1 already supplies exponential gap amplification after changing the game. Generic claims of a new undecidability theorem, a new identification of \(\mathsf{MIP}^{co}\), or the mere existence of polynomial repetition for inverse-polynomial gaps would therefore overstate the consequence. [Primary source](https://arxiv.org/html/2510.07162v1).

The candidate theorem instead provides quantitative accumulation of **each component's square gap**, for the original independent product and for commuting strategies, with no answer-alphabet penalty in the block class. A public selector mixture plus homogeneous repetition gives only \(N(\frac1N\sum_i\epsilon_i)^2\); it can be arbitrarily weaker than \(\sum_i\epsilon_i^2\). This is the meaningful product improvement to assess.

For the near-block extension, compare with replacing exceptional predicates by automatic wins. If their probability is \(\eta_i<\epsilon_i\), that trivial deletion can retain a block gap \(\epsilon_i-\eta_i\). The intrinsic-charge theorem adds scope when exceptional mass is comparable to or exceeds the gap but \(\kappa_i/\epsilon_i\) remains bounded. It should not be sold as a new result in the easy deletion regime.

The principal's common-information/crown obstruction and the constructor's nuclear-norm positive-mass certificate concern attempts to remove the information charge on arbitrary masks. They are compatible with (3): this theorem pays the tested charge explicitly and imposes (2). The known common-information formula should be credited to Cuff–Permuter–Cover/Cuff when used. It does not itself disprove general quadratic repetition; it obstructs a specified positive posterior reconstruction mechanism.

## 7. Remaining strongest generalization

Without the uniform ratio bound (2), (11) remains a valid exact scalar conditional theorem for the chosen finite partitions. It does **not** immediately imply
\(\exp[-c\sum_i\epsilon_i^3/(\epsilon_i+\kappa_i)]\). The entropy charged by a tested coordinate affects all remaining coordinates, and the sum budget in (11) does not allocate that cost separately by \(i\). A proof of that fully intrinsic heterogeneous product would require a new weighted/multiscale charge argument or a sharper product relaxation. Neither replacing \(C\) by a weighted average nor multiplying bounds for disjoint coordinate groups is justified for arbitrary joint strategies.

The near-projection heterogeneous theorem (3), with the scalar-before-Lin repair, is the strongest complete route I can support at present. Its operator-algebra premises remain the inherited ones, explicitly checked at their interfaces rather than replaced by a claim of fresh external certification.

