# Independent continuation: exact and robust classical common-information barrier

Written before reading sibling results. Does not overwrite initial report.

## Important limitation of the mass obstruction

An exponential optimum G_A,G_B does NOT force an exponential loss in the exact entropy telescope. Scalar constant descriptors can have zero endpoint difference even when the endpoint mass bound is poor. Therefore crown mass alone defeats a proposed uniform mass bound, not the whole R/H mechanism. The remaining opportunity is to estimate entropy increments directly, cancel redundant label information, or use operator-valued histories.

## Exact common-information theorem

Let m>=2 be even and R_m be uniform on ordered unequal pairs (a,b) in [m]^2. For t>=1, over all random variables K with A^t independent of B^t conditional on K and law(A^t,B^t)=R_m^tensor t,

 inf I(K;A^t B^t)=t log[4(1-1/m)].

Proof: every positive product component has support R x C avoiding equality in each coordinate. Coordinate projections R_i,C_i are disjoint. Thus |R||C|<=m^(2t)/4^t. Conditional entropy H(A^t B^t|K)<=2t log(m/2); unconditional entropy=t log[m(m-1)]. Difference proves lower bound. Achieve with independent uniformly random balanced subsets S_i: conditional A_i uniform S_i, B_i uniform S_i^c. Their output is exactly uniform on unequal pairs. This proves equality without assuming coordinatewise competitors. This is Wyner common information, not a new definition or a claimed invention; priority of this exact special formula requires checking.

Yet I(A^t;B^t)=t log[m/(m-1)] and the original rejection entropy is -log p_t=t log[m/(m-1)], both ~t/m. Thus exact classical dependency-breaking needs ~2 bits per coordinate even as conditioning creates vanishing mutual information. Any universal bound on classical separator information by a constant times log(1/p_t) is false.

## Robust version (complete derivation)

Let R' be a distribution on [m]^t x [m]^t at total variation distance <=eta from R_m^tensor t, 0<=eta<=1/m. For ANY classical K making A^t independent of B^t conditionally,

 I(K;A^t B^t) >= t{log[4(1-1/m)]-2h(.5 sqrt(m eta))-2eta log m}-h(eta),

where h is binary entropy in natural units.

Proof: For each coordinate, R'(A_i=B_i)<=eta. Given K=k, let p,q be its two marginal laws in that coordinate, c=sum_a p_a q_a, and f=sum_a sqrt(p_a q_a)<=sqrt(m c). Consider a fair binary label L selecting p or q and observation X. Its optimal discrimination error e=(1-TV(p,q))/2 <=f/2. Binary Fano gives

 .5[H(p)+H(q)] =H(X)-I(L;X) <=log m-log2+h(e).

Average over K: E c<=eta, hence E e<=.5 sqrt(m eta); Jensen for h gives

 H(A_i|K)+H(B_i|K)<=2log m-2log2+2h(.5 sqrt(m eta)).

Conditional independence of the full vectors, then conditional entropy subadditivity across coordinates bounds H(A^t B^t|K) by t times this expression. Classical entropy continuity on m^(2t) outcomes gives H(R')>=t log[m(m-1)]-h(eta)-2t eta logm. Subtract. This proves the bound.

Consequence: for m tending to infinity and eta=o(1/m), separator information per coordinate remains >=log4-o(1). An approximation of order eta~1/m can erase the whole obstruction (the original independent uniform distribution has TV=1/m and K constant). Thus the relevant exact operation is rare-error-accurate conditional reconstruction: ordinary TV at the scale of the rejection probability can be too crude. This is a mechanism obstruction, not a commuting repetition lower bound or proof of novelty.

## Immediate prior-art correction

The exact common-information formula is already published: Cuff, Permuter and Cover, Coordination Capacity, IEEE Trans. IT 56(9), 4181–4206 (2010), Example 7, equation display following Theorem 10; DOI 10.1109/TIT.2010.2054651. Primary PDF https://isl.stanford.edu/~cover/papers/2010coordination.pdf. This is the task-assignment/scatter channel. It is a predecessor to be applied, not a discovery. Our explicit bounded-factor mass identity and uniform robust block lower bound still require priority checking. The research opening is their applicability to exact event reconstruction, not rebranding common information.
