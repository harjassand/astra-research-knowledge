# Follow-up: a valid threshold wrapper for a nonnegative intrinsic charge

Written after the independent initial report. No other researcher's new mathematical notes were read for this derivation. The initial report is unchanged (SHA256 `de30cebab897e644b2734d55b00a0296cdd5180d7a945d3cf33fa3da3c2ff8fc`).

## The precise conditional premise

Let a binary-score repeated-game strategy have indicators \(W_1,\ldots,W_n\). Fix \(v\in[0,1)\), \(\epsilon=1-v\), \(\kappa\ge0\), and \(K\ge1\). Suppose that every strategy in the class, every repetition length, and every proper \(C\subset[n]\) with \(p_C=\Pr(W_i=1\ \forall i\in C)>0\) obey
\[
 \epsilon\le\alpha_C+K\left(\sqrt{\alpha_C}\tau_C^{1/4}+\sqrt{\tau_C}\right),
 \quad
 \tau_C=\frac{\log(1/p_C)+|C|\kappa}{n-|C|},
\]
where \(\alpha_C\) is the mean conditional loss on the remaining coordinates. Assume the class is closed under the legal product-block strategies used below, with the same parameters. No assumption that \(\kappa\) is an alphabet logarithm is made.

Then, for \(0<\delta\le\epsilon\) and every \(n\ge1\),
\[
 \Pr\!\left[\sum_iW_i\ge\lceil(v+\delta)n\rceil\right]
 \le
 \exp\!\left[-\frac{\delta^5n}
 {16384K^4\epsilon^2(\epsilon+\kappa)}\right]. \tag{T}
\]
In particular \(\kappa=0\) gives a valid \(\delta^5/\epsilon^3\) rate and a quadratic all-wins rate, without making any singleton-output claim. This repairs the invalid shortcut of substituting zero for the alphabet logarithm in the old wrapper's special singleton branch.

## Complete proof

Set
\[
 p_j=\binom nj^{-1}\sum_{|C|=j}p_C
     =\mathbb E\frac{(W)_j}{(n)_j},\qquad W=\sum_iW_i.
\]
For \(j<n\), \(p_j>0\), weight \(j\)-subsets by
\(w_C=p_C/[\binom njp_j]\). Double counting gives
\(\bar q_j=p_{j+1}/p_j=\sum_Cw_Cq_C\), and
\[
 \sum_Cw_C\log(1/p_C)
 =\log(1/p_j)-D(w\|u)\le\log(1/p_j).
\]
By Cauchy–Schwarz and Jensen, averaging the nonlinear premise yields
\[
 \epsilon\le1-\bar q_j+
 K\left(\sqrt{1-\bar q_j}\,t_j^{1/4}+\sqrt{t_j}\right),
 \quad t_j=\frac{\log(1/p_j)+j\kappa}{n-j}. \tag{1}
\]

Put
\[
 a=\frac{\delta^4}{256K^4\epsilon^2},\quad
 s=v+3\delta/4=1-\epsilon+3\delta/4,\quad
 L=\kappa+\log(1/s)+a.
\]
The numbers satisfy \(0<s<1\), \(L>0\), and \(a\le\epsilon^2/256\). If \(t_j\le a\), (1) forces
\[
 \bar q_j\le v+\delta/2. \tag{2}
\]
Indeed, a violation gives \(1-\bar q_j<\epsilon-\delta/2\), while the two error terms total at most \(\delta/4+\delta/16<\delta/2\).

Suppose first that \(n\ge8L/a\), and set \(k=\lfloor an/(4L)\rfloor\). Then \(k\ge an/(8L)\). The new point needed at \(\kappa=0\) is
\[
 L\ge\log(1/s)\ge1-s=\epsilon-3\delta/4\ge\epsilon/4.
\]
Therefore
\[
 \frac{k}{n}\le\frac a{4L}\le\frac a\epsilon
 =\frac{\delta^4}{256K^4\epsilon^3}\le\frac\delta{256}<\frac\delta4.
\]
Thus \(k<n\). Let \(P=\Pr(W\ge\lceil(v+\delta)n\rceil)\). If \(P>0\), the factorial-moment identity gives
\[
 p_j\ge P s^j>0\qquad(0\le j\le k), \tag{3}
\]
since every factor of \((\lceil(v+\delta)n\rceil)_j/(n)_j\) is at least \(v+\delta-k/n\ge s\).

Call \(j\) good if \(\log(1/p_j)+j\kappa\le a(n-j)\). If some \(1\le j\le k\) is not good, (3) yields
\[
 \log(1/P)>an-j[\kappa+\log(1/s)+a]=an-jL\ge3an/4. \tag{4}
\]
Otherwise (2) applies successively through \(k-1\), so
\[
 p_k\le(v+\delta/2)^k,
 \quad
 \log(1/P)\ge k\log\frac{s}{v+\delta/2}
 \ge\frac{k\delta}{4s}\ge\frac{a\delta n}{32sL}. \tag{5}
\]
The denominator estimate valid for arbitrary \(\kappa\ge0\) is
\[
 sL=s\kappa+s\log(1/s)+sa
 \le\kappa+(1-s)+a
 \le\kappa+\epsilon+\epsilon/256
 \le2(\kappa+\epsilon). \tag{6}
\]
Here \(-s\log s\le1-s\), a scalar inequality, replaces the old use of \(\ell\ge\log2\). Equations (5)–(6) give
\[
 \log(1/P)\ge\frac{a\delta n}{64(\kappa+\epsilon)}
 =\frac{\delta^5n}{16384K^4\epsilon^2(\kappa+\epsilon)}.
\]
Case (4) is stronger because \(\delta\le\epsilon\le\kappa+\epsilon\).

For short \(n\), tensor \(m\) whole copies of the strategy on independent blocks. This is a legal commuting strategy: Alice's and Bob's product POVMs commute factor by factor. Blocks, deliberately constructed independently, each cross the original threshold with probability \(P\). If they all cross it, the total number of wins is at least
\(m\lceil(v+\delta)n\rceil\ge\lceil(v+\delta)mn\rceil\). Choose \(m\) with \(mn\ge8L/a\), apply the long-length bound to this product-block strategy and take the \(m\)-th root. This proves (T) at every length without an additive prefactor. The parameters are those of the original base game, so \(\epsilon,\kappa,K\) do not change under this artificial amplification.

At \(v=0\), the premise with \(C=\varnothing\) gives \(\mathbb EW=0\), so the positive tail vanishes. Zero tail probabilities are trivial. No zero-probability conditioning is used; a positive tail makes all moments in (3) positive. The endpoint \(\delta=\epsilon\) is exactly all wins.

## Consequence for the averaged-load candidate

Subject to the inherited operational interfaces, use
\(\kappa(G)=\log\mathbb E_\mu\rho(V_{xy})\), as proved in the independent initial report, and \(K=2^{16}\). Then (T) has constant \(2^{-78}\). In the disjoint-block class \(\kappa=0\), it gives
\[
 \Pr[W\ge\lceil(v+\delta)n\rceil]
 \le\exp[-2^{-78}\delta^5n/\epsilon^3].
\]
For a constant tolerated fraction of the base loss, \(\delta=\theta\epsilon\), the rate is \(2^{-78}\theta^5\epsilon^2\). For \(\delta\ll\epsilon\), this is far from the independent-binomial upper ceiling \(D(1-\epsilon+\delta\|1-\epsilon)\asymp\delta^2/\epsilon\); no optimal-threshold claim follows.

## Simpler comparator: deleting the exceptional masks

If non-block question pairs have total probability \(\eta\), replace their predicates by automatic wins to obtain a disjoint-block game \(H\). Then \(G\le H\) pointwise and
\[
 \omega_{\rm co}(H)\le\omega_{\rm co}(G)+\eta,
 \qquad\epsilon_H\ge\epsilon_G-\eta.
\]
The inherited block theorem alone therefore gives quadratic repetition when \(\eta\le(1-c)\epsilon_G\), with fixed \(c>0\). Any proposed rare-defect result must be compared with this trivial deletion argument.

The load argument supplies additional content when \(\eta\) is comparable to or exceeds \(\epsilon_G\), but \(\eta(R-1)\le C\epsilon_G\) for a fixed \(C\): deletion may make \(H\) perfectly satisfiable, whereas the intrinsic-budget candidate still retains an \(\Omega_C(\epsilon_G^2)\) rate. This does not remove the inherited S_actual/R/H/Lin dependencies or establish novelty.

