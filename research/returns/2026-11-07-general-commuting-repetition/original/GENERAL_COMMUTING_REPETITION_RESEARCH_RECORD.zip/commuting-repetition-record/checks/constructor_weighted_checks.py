"""Exact finite checks of sparse-success-test identities; proofs are in the review."""
from fractions import Fraction as F
from itertools import product
from math import log, sqrt
from pathlib import Path
import json


def prod(xs):
    ans = F(1)
    for x in xs:
        ans *= x
    return ans


def check(eps):
    n = len(eps)
    outcomes = list(product((0, 1), repeat=n))
    # Nonproduct, full-support distribution on success strings.
    weights = [1 + ((sum((i+2)*b for i,b in enumerate(w)) + 3*sum(w)**2) % 11)
               for w in outcomes]
    total = sum(weights)
    law = {w:F(v,total) for w,v in zip(outcomes,weights)}
    subsets = outcomes
    u, C0 = F(3,7), F(3,2)
    qs = [u*e/(1+u*e) for e in eps]
    prior = {c:prod(q if b else 1-q for q,b in zip(qs,c)) for c in subsets}
    pc = {c:sum(p for w,p in law.items() if all(not ci or wi for ci,wi in zip(c,w)))
          for c in subsets}
    norm = sum(prior[c]*pc[c] for c in subsets)
    filters = {w:prod(1/(1+u*e) if not wi else 1 for e,wi in zip(eps,w)) for w in outcomes}
    assert norm == sum(law[w]*filters[w] for w in outcomes)
    post = {c:prior[c]*pc[c]/norm for c in subsets}
    tilted = {w:law[w]*filters[w]/norm for w in outcomes}
    S = sum(e*e for e in eps)
    z = {w:sum(e for e,wi in zip(eps,w) if not wi) for w in outcomes}
    A = {}
    for c in subsets:
        A[c] = sum(p*sum(e for e,ci,wi in zip(eps,c,w) if not ci and not wi)
                   for w,p in law.items() if all(not ci or wi for ci,wi in zip(c,w)))/pc[c]
    assert sum(post[c]*A[c] for c in subsets) == sum(tilted[w]*z[w] for w in outcomes)
    selected_square = sum(post[c]*sum(e*e for e,ci in zip(eps,c) if ci) for c in subsets)
    assert selected_square == sum(e*e*q*sum(p*w[i] for w,p in tilted.items())
                                  for i,(e,q) in enumerate(zip(eps,qs)))
    assert selected_square <= u*S
    selected_kappa = sum(post[c]*sum(C0*e for e,ci in zip(eps,c) if ci) for c in subsets)
    assert selected_kappa <= C0*u*S
    for w in outcomes:
        denom = sum(prior[c] for c in subsets if all(not ci or wi for ci,wi in zip(c,w)))
        for i in range(n):
            selected = sum(prior[c] for c in subsets
                           if c[i] and all(not ci or wi for ci,wi in zip(c,w)))
            assert selected/denom == qs[i]*w[i]
    derivative = sum(tilted[w]*sum(e/(1+u*e) for e,wi in zip(eps,w) if not wi)
                     for w in outcomes)
    assert derivative >= sum(tilted[w]*z[w] for w in outcomes)/(1+u)
    entropy = sum(float(post[c])*log(1/float(pc[c])) for c in subsets if post[c])
    kl = sum(float(post[c])*log(float(post[c]/prior[c])) for c in subsets if post[c])
    assert abs(entropy + kl + log(float(norm))) < 1e-12
    return {"gaps":list(map(str,eps)), "F":str(norm), "S":str(S),
            "derivative":str(derivative), "entropy_identity_error":abs(entropy+kl+log(float(norm)))}


cases = [check([F(0),F(1,10),F(1,2),F(1)]),
         check([F(1,20),F(1,10),F(1,3),F(2,3)])]
error_coefficient = 3**.25/32 + sqrt(3)/1024
assert error_coefficient < F(1,16)
result = {"status":"PASS finite identities only", "cases":cases,
          "barrier_error_coefficient_at_K1_r1":error_coefficient,
          "theorem_constant_at_K65536": "2^-85/(1+C0)"}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
