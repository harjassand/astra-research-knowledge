"""Finite diagnostics for the analytic tensor-mask obstruction.

The proof is in initial/auditor.md. This exhaustive exact-arithmetic check
only verifies the support-rectangle lemma for t <= 3.
"""
from fractions import Fraction
from itertools import product
import json


def run():
    records = []
    for t in (1, 2, 3):
        words = list(product((0, 1), repeat=t))
        all_sets = [
            [words[i] for i in range(len(words)) if bits & (1 << i)]
            for bits in range(1, 1 << len(words))
        ]
        for r in (Fraction(1, 10), Fraction(1, 2)):
            def pmass(a):
                return r ** sum(a) * (1-r) ** (t-sum(a))

            def qmass(b):
                return (1-r) ** sum(b) * r ** (t-sum(b))

            maximum = Fraction(0)
            rectangles = 0
            for aa in all_sets:
                for bb in all_sets:
                    if all(all(a[i] <= b[i] for i in range(t))
                           for a in aa for b in bb):
                        rectangles += 1
                        p = sum(map(pmass, aa), Fraction(0))
                        q = sum(map(qmass, bb), Fraction(0))
                        assert p*q <= (1-r)**t
                        maximum = max(maximum, p*q)
            assert maximum == (1-r)**t
            accepted_mass = sum(
                (pmass(a)*qmass(b) for a in words for b in words
                 if all(a[i] <= b[i] for i in range(t))),
                Fraction(0),
            )
            assert accepted_mass == (1-r*r)**t
            records.append({
                "t": t, "r": str(r), "rectangles": rectangles,
                "max_rectangle_product": str(maximum),
                "accept_probability": str(accepted_mass),
            })
    print(json.dumps({"status": "PASS", "records": records}, indent=2))


if __name__ == "__main__":
    run()
