"""Finite orientation checks for the independent constructor report.

These checks do not establish the infinite family claims; the report proves them.
No third-party packages are required.
"""
from itertools import product, combinations
from fractions import Fraction
from math import sqrt
import json
from pathlib import Path


def kron(a, b):
    return [[x * y for x in ra for y in rb] for ra in a for rb in b]


def block_mask(a):
    neigh = [{j for j, x in enumerate(row) if x} for row in a]
    return all(not (u & v) or u == v for u in neigh for v in neigh)


def has_triangle(a):
    return any(sum(a[i][j] for i in rr for j in cc) == 3
               for rr in combinations(range(len(a)), 2)
               for cc in combinations(range(len(a[0])), 2))


classification = []
for n, m in [(2, 2), (2, 3), (3, 3)]:
    masks = [tuple(tuple(bits[i*m:(i+1)*m]) for i in range(n))
             for bits in product((0, 1), repeat=n*m)]
    assert all(block_mask(a) == (not has_triangle(a)) for a in masks)
    classification.append({"rows": n, "columns": m,
                           "total": len(masks),
                           "block_masks": sum(map(block_mask, masks))})

T = [[1, 1], [0, 1]]
W = [[2, 1], [-1, 2]]
t_tensor, w_tensor = [[1]], [[1]]
tensor_checks = []
for t in range(1, 7):
    t_tensor, w_tensor = kron(t_tensor, T), kron(w_tensor, W)
    n = 2**t
    assert sum(w_tensor[i][j] * t_tensor[i][j]
               for i in range(n) for j in range(n)) == 5**t
    assert all(sum(w_tensor[k][i] * w_tensor[k][j] for k in range(n))
               == (5**t if i == j else 0)
               for i in range(n) for j in range(n))
    tensor_checks.append({"t": t, "matrix_size": n,
                          "mass_lower_bound": (sqrt(5)/2)**t})

# Uniform one-step primal with four half-weight rectangles.
rectangles = [((1, 0), (1, 1), Fraction(1, 2)),
              ((1, 0), (1, 0), Fraction(1, 2)),
              ((1, 1), (0, 1), Fraction(1, 2)),
              ((0, 1), (0, 1), Fraction(1, 2))]
assert all(sum(w*f[i]*g[j] for f,g,w in rectangles) == T[i][j]
           for i in range(2) for j in range(2))
GA = sum(w*Fraction(sum(f), 2) for f,g,w in rectangles)
GB = sum(w*Fraction(sum(g), 2) for f,g,w in rectangles)
assert GA == GB == Fraction(5, 4)

# The matching dual is multilinear, so it is enough to check cube vertices.
dual = [[1, Fraction(1, 2)], [0, 1]]
for f in product((0, 1), repeat=2):
    for g in product((0, 1), repeat=2):
        if f[1]*g[0] == 0:
            assert sum(dual[i][j]*f[i]*g[j]
                       for i in range(2) for j in range(2)) <= Fraction(sum(f)+sum(g), 2)

result = {"status": "PASS finite checks only", "classification": classification,
          "tensor_witness": tensor_checks,
          "triangle_uniform_one_step_optimum": str(GA)}
out = Path(__file__).with_name("constructor_checks.json")
out.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
