"""Case B first frontier: exact rational finite-region channel reference.
No physical experiment. No implementation of the missing polynomial predictor.
The certified interval follows from the channel-error proof in RESEARCH_REPORT.txt.
Optional SciPy comparison is a floating-point diagnostic, not the certificate.
"""
from fractions import Fraction as F
from itertools import product
from math import ceil
from pathlib import Path
import json

LETTERS="IXYZ"
MUL={
("X","Y"):("Z",1),("Y","Z"):("X",1),("Z","X"):("Y",1),
("Y","X"):("Z",3),("Z","Y"):("X",3),("X","Z"):("Y",3)
}
def mul(a,b):
    out=[]; phase=0
    for x,y in zip(a,b):
        if x=="I": out.append(y)
        elif y=="I": out.append(x)
        elif x==y: out.append("I")
        else:
            z,p=MUL[x,y];out.append(z);phase=(phase+p)%4
    return "".join(out),phase

def round_out(x,digits,upper=False):
    scale=10**digits
    q=(x.numerator*scale)//x.denominator
    if upper and F(q,scale)<x:q+=1
    sign="-" if q<0 else ""
    aq=abs(q)
    decimal=sign+str(aq//scale)+"."+str(aq%scale).zfill(digits)
    return str(F(q,scale)),decimal

def main():
    n=4
    labels=["".join(p) for p in product(LETTERS,repeat=n)]
    ix={p:i for i,p in enumerate(labels)}
    terms=[("ZZII",F(1)),("IXIX",F(1)),("IIZZ",F(1,2)),
           ("YIXI",F(1,2)),("XIII",F(1,4)),("IIIY",F(1,4))]
    gamma=F(1,4);T=F(1,100);epsilon=F(1,100)
    local=[
        {"I":F(1),"X":F(0),"Y":F(0),"Z":F(1)},
        {"I":F(1),"X":F(1),"Y":F(0),"Z":F(0)},
        {"I":F(1),"X":F(0),"Y":F(0),"Z":F(1,3)},
        {"I":F(1),"X":F(0),"Y":F(1),"Z":F(0)}
    ]
    initial=[]
    for P in labels:
        x=F(1)
        for j,c in enumerate(P):x*=local[j][c]
        initial.append(x)
    r=initial.copy()
    S=2*sum(abs(c) for _,c in terms)+2*gamma*n
    N=max(1,ceil(S*T),ceil(32*(S*T)**2/epsilon))
    h=T/N;q=gamma*h
    assert 0<=q<=1
    transformations=[]
    for P,c in terms:
        x=h*c
        assert abs(x)<=1
        cosine=(1-x*x/4)/(1+x*x/4)
        sine=x/(1+x*x/4)
        c2=cosine*cosine-sine*sine;s2=2*cosine*sine
        mapping=[]
        for Q in labels:
            R,phase=mul(P,Q)
            mapping.append((ix[R],phase))
        transformations.append((c2,s2,mapping))
    damp=[(1-q)**sum(c!="I" for c in P) for P in labels]
    for _ in range(N):
        for c2,s2,mapping in transformations:
            rnew=[F(0) for _ in labels]
            for j,value in enumerate(r):
                if not value:continue
                dest,phase=mapping[j]
                if phase%2==0:rnew[j]+=value
                else:
                    rnew[j]+=c2*value
                    rnew[dest]+=(1 if phase==1 else -1)*s2*value
            r=rnew
        r=[x*d for x,d in zip(r,damp)]
    estimate=(r[ix["ZIII"]]+r[ix["IXII"]])/2
    bound=2*(S*T)**2/N
    assert bound<=epsilon/8
    lower_str,lower_dec=round_out(estimate-bound,14)
    upper_str,upper_dec=round_out(estimate+bound,14,True)
    result={
      "scope":"Exact rational four-qubit finite-region execution; no asymptotic validation.",
      "n":n,"geometry":"2 by 2 square, sites 0=(0,0),1=(0,1),2=(1,0),3=(1,1)",
      "hamiltonian":[[P,str(c)] for P,c in terms],
      "gamma":str(gamma),"J":"1","gamma_over_J":"1/4",
      "initial_local_bloch_vectors":[{p:str(v) for p,v in d.items()} for d in local],
      "observable":"(ZIII+IXII)/2","T":str(T),"epsilon":str(epsilon),
      "S":str(S),"rational_steps":N,
      "estimate_numerator":str(estimate.numerator),
      "estimate_denominator":str(estimate.denominator),
      "estimate_float_display":float(estimate),
      "proved_channel_error_bound":str(bound),
      "certified_interval_rational":[lower_str,upper_str],
      "certified_interval_decimal_outward":[lower_dec,upper_dec],
      "max_fraction_bit_length":max(max(v.numerator.bit_length(),v.denominator.bit_length()) for v in r),
      "identity_coefficient":str(r[ix["IIII"]])
    }
    try:
        import numpy as np
        from scipy.linalg import expm
        G=np.zeros((len(labels),len(labels)))
        for P,c in terms:
            for j,Q in enumerate(labels):
                R,phase=mul(P,Q)
                if phase%2:G[ix[R],j]+=2*float(c)*(1 if phase==1 else -1)
        for j,P in enumerate(labels):G[j,j]-=float(gamma)*sum(c!="I" for c in P)
        reference=expm(float(T)*G)@np.array([float(v) for v in initial])
        f=(reference[ix["ZIII"]]+reference[ix["IXII"]])/2
        result["floating_reference"]={"method":"SciPy dense exponential, not used for certification",
          "value":float(f),"absolute_difference":float(abs(f-float(estimate)))}
    except ImportError:
        result["floating_reference"]={"status":"optional packages unavailable"}
    counter=[]
    for m in (1,2,4,8,16,32,64):
        counter.append({"m":m,"specified_product_expectation":"1",
                        "normalized_HS_squared":str(F(1,2**m-1)),
                        "operator_norm":"1","trace":"0",
                        "scope":"Norm-conversion counterexample; not an error produced by a proved dynamical algorithm."})
    result["norm_counterexample_family"]=counter
    path=Path(__file__).with_name("EXECUTED_RESULTS.json")
    path.write_text(json.dumps(result,indent=2)+"\n")
    summary={k:result[k] for k in ("n","rational_steps","estimate_float_display",
      "proved_channel_error_bound","certified_interval_decimal_outward","max_fraction_bit_length","floating_reference")}
    print(json.dumps(summary,indent=2))
if __name__=="__main__":main()
