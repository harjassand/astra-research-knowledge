CASE B — FIRST FRONTIER ATTEMPT, 7 NOVEMBER 2026

Full frozen question: UNRESOLVED.
This archive is the producer's new first-turn record, not a recovery or
modification of any predecessor archive.

RESEARCH_REPORT.txt contains the complete derivations, explicit constants,
algorithm, finite-bit costs, source scopes, valid smoothing reduction and
remaining gap.

reference_channels.py is a standard-library rational finite-region kernel.
Run: python reference_channels.py
It creates EXECUTED_RESULTS.json. NumPy/SciPy, if already installed, are used
only for an optional floating-point comparison; the interval certificate does
not depend on them.

ENDPOINT.json separates the full question from completed scoped results.
FAILURE_OBJECTS.json preserves explicit failures without generalizing them.
SOURCE_SCOPE.json records allowed source use and retained exposure/holds.
MANIFEST.json records the bytes and SHA256 of the other archive members.

The complete deterministic theorem has quasipolynomial inverse-accuracy cost
in 2D. The finite example and the smoothing norm theorem do not turn that bound
into the polynomial bound requested by case B. No general negative result has
been established.
