Case A, second and final authorized frontier return, 7 November 2026.

The full frozen microscopic mean-and-CDF predictor remains UNRESOLVED.
Read RESEARCH_REPORT.txt for the proofs, costs, actual scope, and remaining gap.
The original first-A archives are not overwritten or repackaged here.

Run the exact algebra audit with Python 3.10 or later:
  python analysis_checks.py
It uses only the standard library. The 3x3 Ising fixture is outside the
growing-volume promise. This audit is not a polynomial predictor.

retained_first_reference.py is an unchanged copy of the code member from
my retained first-A original. Its exponential-state computation is charged.
FROZEN_ENDPOINT.json is copied unchanged from that original.
SOURCES_AND_SCOPE.json records the authorized designated-source exposure.
EXACT_CHECKS.json contains exact rational audit values.
