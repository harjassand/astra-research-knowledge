"""Exact audits for the second/final Case A turn.

This is not a polynomial microscopic predictor.  The Ising audit reuses the
retained exponential finite-state reference on the same 3x3 fixture, which is
outside the growing-volume promise.  No physical or random samples are used.
"""
from fractions import Fraction as F
from pathlib import Path
import json
import retained_first_reference as ref


def solve(a, b):
    n = len(b)
    mat = [[F(x) for x in row] + [F(y)] for row, y in zip(a, b)]
    for k in range(n):
        pivot = next(i for i in range(k, n) if mat[i][k])
        mat[k], mat[pivot] = mat[pivot], mat[k]
        z = mat[k][k]
        mat[k] = [x/z for x in mat[k]]
        for i in range(k+1, n):
            z = mat[i][k]
            if z:
                mat[i] = [x-z*y for x, y in zip(mat[i], mat[k])]
    ans = [F(0)]*n
    for i in range(n-1, -1, -1):
        ans[i] = mat[i][-1] - sum(mat[i][j]*ans[j] for j in range(i+1, n))
    assert all(sum(F(a[i][j])*ans[j] for j in range(n)) == F(b[i]) for i in range(n))
    return ans


def projected_mean(g, d):
    """Exact positive recurrence; inputs must be actual occupation averages."""
    assert len(g) == len(d) and all(x > 0 for x in g)
    h = [F(0)]*len(g)
    for j in range(len(g)-1, -1, -1):
        h[j] = (1 + (d[j+1]*h[j+1] if j+1 < len(g) else 0))/g[j]
    return sum(h), h


def projected_interval(g_lo, g_hi, d_lo, d_hi):
    lo, _ = projected_mean(g_hi, d_lo)
    hi, _ = projected_mean(g_lo, d_hi)
    return lo, hi


def projected_generator(g, d):
    k = len(g)
    q = [[F(0)]*k for _ in range(k)]
    for j in range(k):
        q[j][j] = -(g[j]+d[j])
        if j: q[j][j-1] = d[j]
        if j+1 < k: q[j][j+1] = g[j]
    return q


def level_rates(q, levels):
    k = max(levels)+1
    gu, dn = [], []
    for i, lev in enumerate(levels):
        assert all(not q[i][j] or i == j or abs(levels[j]-lev) == 1 for j in range(len(q)))
        kill = -sum(q[i])
        assert kill >= 0 and (kill == 0 or lev == k-1)
        gu.append(kill + sum(q[i][j] for j in range(len(q)) if levels[j] == lev+1))
        dn.append(sum(q[i][j] for j in range(len(q)) if levels[j] == lev-1))
    return gu, dn


def averaged_rates(q, levels, weights):
    gu, dn = level_rates(q, levels)
    k = max(levels)+1
    totals = [sum(weights[i] for i in range(len(q)) if levels[i] == j) for j in range(k)]
    g = [sum(weights[i]*gu[i] for i in range(len(q)) if levels[i] == j)/totals[j] for j in range(k)]
    d = [sum(weights[i]*dn[i] for i in range(len(q)) if levels[i] == j)/totals[j] for j in range(k)]
    return g, d, totals


def analyze(q, levels, start=0):
    n = len(q)
    H = [[-x for x in row] for row in q]
    m = solve(H, [1]*n)
    second = solve(H, [2*x for x in m])
    source = [F(i == start) for i in range(n)]
    occ = solve(list(map(list, zip(*H))), source)
    assert all(x > 0 for x in occ) and sum(occ) == m[start]
    g, d, totals = averaged_rates(q, levels, occ)
    pm, residence = projected_mean(g, d)
    assert pm == m[start] and residence == totals
    assert all(g[j]*totals[j] - (d[j+1]*totals[j+1] if j+1 < len(g) else 0) == 1 for j in range(len(g)))
    bq = projected_generator(g, d)
    bH = [[-x for x in row] for row in bq]
    bm = solve(bH, [1]*len(g))
    bsecond = solve(bH, [2*x for x in bm])
    eps = F(1,1000)
    eta = eps/(16*len(g))
    lo, hi = projected_interval([x*(1-eta) for x in g], [x*(1+eta) for x in g],
                                 [x*(1-eta) for x in d], [x*(1+eta) for x in d])
    assert lo <= m[start] <= hi and hi/lo <= 1+eps
    return {"mean":m[start], "second_moment":second[start],
            "projected_mean":pm, "projected_second_moment":bsecond[0],
            "occupation":occ,"g":g,"d":d,"layer_residence":totals,
            "rate_interval_eta":eta,"mean_interval":[lo,hi],
            "relative_interval_width":hi/lo-1}


def reversible_weights(q, start=0):
    weights = [None]*len(q)
    weights[start] = F(1)
    queue = [start]
    for i in queue:
        for j in range(len(q)):
            if i != j and q[i][j] > 0:
                assert q[j][i] > 0
                candidate = weights[i]*q[i][j]/q[j][i]
                if weights[j] is None:
                    weights[j] = candidate
                    queue.append(j)
                else:
                    assert weights[j] == candidate
    assert all(x is not None for x in weights)
    return weights


def graph_distance_levels(q, start=0):
    levels = [None]*len(q)
    levels[start] = 0
    queue = [start]
    for i in queue:
        for j in range(len(q)):
            if i != j and q[i][j] > 0 and levels[j] is None:
                levels[j] = levels[i]+1
                queue.append(j)
    assert all(x is not None for x in levels)
    return levels


def regeneration_bound(ell, u):
    """Rational upper bound for return to all-minus before the target
    after the first departure. Proof uses the frozen promises u^2<v<1.
    This routine is polynomial in the EXPLICIT site count, not log(n).
    It does not check the temperature/volume promises.
    """
    u = F(u)
    n = ell*ell
    alpha = u**4/(1+u**4)
    k = (alpha.numerator*n)//(4*alpha.denominator)
    if k < 2:
        return {"bound":F(1),"reason":"thermal population cutoff below two","alpha":alpha,"k":k}
    b = ref.ceil_log2(1/u)
    Gamma = 2*n/u**(4*ell+4)
    U = 4*Gamma*(n*(1+4*b)+4)
    h = max(1,k//8)
    early = F(4,3)/(alpha*(n-1))
    late = 4*U*h*(1-F(k,2*n))**n
    tail = F(1,1<<h)
    return {"bound":min(F(1),early+late+tail),"early":early,"late":late,
            "tail":tail,"alpha":alpha,"k":k,"h":h,"U":U}


def audit():
    # Reversible diamond a--{b,c}--B: a generic chain, not an Ising embedding.
    q = [[F(-1),F(1,2),F(1,2)], [F(1),F(-3,2),F(0)], [F(1),F(0),F(-3)]]
    diamond = analyze(q,[0,1,1])
    assert diamond["g"] == [F(1),F(1)]
    assert diamond["d"] == [F(0),F(1)]
    assert diamond["mean"] == 3
    assert diamond["second_moment"] == F(148,9)
    assert diamond["projected_second_moment"] == 16
    g,d,_ = averaged_rates(q,[0,1,1],reversible_weights(q))
    diamond["equilibrium_projected_mean"] = projected_mean(g,d)[0]
    assert diamond["equilibrium_projected_mean"] == F(13,5)
    # Retained physical reference, with exact spatial symmetry lumping only.
    q,start,meta = ref.build_killed(3,F(1,4096),F(255,256))
    levels = graph_distance_levels(q,start)
    ising = analyze(q,levels,start)
    g,d,_ = averaged_rates(q,levels,reversible_weights(q,start))
    ising["equilibrium_projected_mean"] = projected_mean(g,d)[0]
    ising["equilibrium_projection_ratio"] = ising["equilibrium_projected_mean"]/ising["mean"]
    ising["second_moment_projection_ratio"] = ising["projected_second_moment"]/ising["second_moment"]
    assert ising["equilibrium_projection_ratio"] != 1
    assert ising["second_moment_projection_ratio"] != 1
    ising["metadata"] = meta
    ising["scope"] = "3x3 torus OUTSIDE growing-volume promise; exact algebra audit only"
    return {"status":"all exact assertions passed","endpoint_status":"UNRESOLVED",
            "physical_experiments":0,"random_samples":0,"diamond":diamond,"ising":ising}


if __name__ == '__main__':
    result = audit()
    Path(__file__).with_name('EXACT_CHECKS.json').write_text(json.dumps(result,default=ref.enc,indent=2)+'\n')
    print(json.dumps({"status":result["status"],"endpoint_status":result["endpoint_status"],
      "diamond":{"mean":str(result['diamond']['mean']),"second":str(result['diamond']['second_moment']),
      "projected_second":str(result['diamond']['projected_second_moment']),
      "equilibrium_mean":str(result['diamond']['equilibrium_projected_mean'])},
      "ising":{"mean":float(result['ising']['mean']),
      "equilibrium_projection_ratio":float(result['ising']['equilibrium_projection_ratio']),
      "second_moment_projection_ratio":float(result['ising']['second_moment_projection_ratio']),
      "metadata":result['ising']['metadata'],"scope":result['ising']['scope']}}))
