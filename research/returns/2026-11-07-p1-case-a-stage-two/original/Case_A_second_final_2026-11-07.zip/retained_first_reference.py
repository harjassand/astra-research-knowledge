"""Case A first-turn finite-state reference: exponential in n, not endpoint completion."""
from fractions import Fraction as F
from pathlib import Path
import json

def ceil_log2(x):
    x=F(x)
    if x<=0: raise ValueError("positive argument required")
    k=x.numerator.bit_length()-x.denominator.bit_length()
    y=F(1<<k) if k>=0 else F(1,1<<(-k))
    return k+(y<x)

def rate(u,v,spin,S):
    r=F(u)**(spin*S)*F(v)**spin
    return r/(1+r)

def neighbours(ell):
    if ell<3: raise ValueError("simple square torus requires ell>=3")
    return [tuple(((x+dx)%ell)*ell+(y+dy)%ell
                  for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)))
            for x in range(ell) for y in range(ell)]

def permutations(ell):
    out=set()
    for swap in (False,True):
      for sx in (-1,1):
       for sy in (-1,1):
        for tx in range(ell):
         for ty in range(ell):
          p=[]
          for x in range(ell):
           for y in range(ell):
            xx,yy=(y,x) if swap else (x,y)
            p.append(((sx*xx+tx)%ell)*ell+(sy*yy+ty)%ell)
          out.add(tuple(p))
    return sorted(out)

def move_bits(x,p):
    z=0
    while x:
        bit=x&-x
        z|=1<<p[bit.bit_length()-1]
        x-=bit
    return z

def build_killed(ell,u,v,max_microstates=512):
    """Internal full enumeration, followed by exact spatial symmetries.
    The run guard is not a polynomial complexity claim. Target membership
    is the actual spin count; no target-state list is supplied.
    """
    n=ell*ell
    if 1<<n>max_microstates: raise ValueError("exponential run budget exceeded")
    nb=neighbours(ell); pp=permutations(ell)
    rep=[-1]*(1<<n)
    for x in range(1<<n):
        if rep[x]!=-1: continue
        orbit={move_bits(x,p) for p in pp}; a=min(orbit)
        for z in orbit: rep[z]=a
    states=sorted({rep[x] for x in range(1<<n) if 2*x.bit_count()<n})
    idx={x:i for i,x in enumerate(states)}; m=len(states)
    def row(x):
        out=[F(0)]*m; ix=idx[rep[x]]
        for i in range(n):
            spin=1 if x>>i&1 else -1
            S=sum(1 if x>>j&1 else -1 for j in nb[i])
            c=rate(u,v,spin,S); out[ix]-=c
            y=x^(1<<i)
            if 2*y.bit_count()<n: out[idx[rep[y]]]+=c
        return out
    q=[row(x) for x in states]
    for x in range(1<<n):
        if 2*x.bit_count()<n: assert row(x)==q[idx[rep[x]]]
    assert all(sum(r)<=0 for r in q)
    return q,idx[0],{"microstates":1<<n,"transient_orbits":m,"automorphisms":len(pp)}

def solve_mean(q):
    m=len(q); a=[[-x for x in r]+[F(1)] for r in q]
    for k in range(m):
        p=next(i for i in range(k,m) if a[i][k])
        a[k],a[p]=a[p],a[k]
        pivot=a[k][k]
        for j in range(k,m+1): a[k][j]/=pivot
        for i in range(k+1,m):
            c=a[i][k]
            if c:
                for j in range(k,m+1): a[i][j]-=c*a[k][j]
    x=[F(0)]*m
    for i in range(m-1,-1,-1):
        x[i]=a[i][m]-sum(a[i][j]*x[j] for j in range(i+1,m))
    assert all(sum(q[i][j]*x[j] for j in range(m))==-1 for i in range(m))
    return x

def square_down(a,b):
    cols=list(zip(*a))
    out=[[sum(x*y for x,y in zip(r,c))>>b for c in cols] for r in a]
    assert all(sum(r)<=1<<b for r in out)
    return out

def cdf_enclosure(q,start,n,t,epsilon,exact_mean=None):
    """Deterministic width<=epsilon band. Cost exponential in spin count,
    polynomial in binary time length. exact_mean, if used, must be paid for.
    """
    t,e=F(t),F(epsilon)
    if t<0 or not 0<e<1: raise ValueError("bad query")
    if t==0: return {"lower":F(0),"upper":F(0),"method":"zero"}
    if n*t<=e:
        return {"lower":F(0),"upper":n*t,"method":"first-proposal bound"}
    if exact_mean is not None and F(exact_mean)/t<=e:
        return {"lower":1-F(exact_mean)/t,"upper":F(1),
                "method":"paid exact-mean Markov tail"}
    m=len(q); nt=n*t
    s=max(0,ceil_log2(max(F(1),nt,8*nt*nt/e))); N=1<<s
    h=t/N; b=max(1,ceil_log2(F(8*N*m)/e)); scale=1<<b
    a=[]
    for i in range(m):
        r=[]
        for j in range(m):
            x=(1 if i==j else 0)+h*q[i][j]
            assert x>=0
            r.append((x.numerator*scale)//x.denominator)
        assert sum(r)<=scale
        a.append(r)
    for _ in range(s): a=square_down(a,b)
    centre=1-F(sum(a[start]),scale)
    discretization=2*nt*nt/N
    rounding=F((2*N-1)*m,scale)
    radius=discretization+rounding
    lo,hi=max(F(0),centre-radius),min(F(1),centre+radius)
    assert hi-lo<=e
    return {"lower":lo,"upper":hi,"method":"dyadic scaling and squaring",
            "squarings":s,"precision_bits":b,
            "discretization_bound":discretization,"rounding_bound":rounding}

def mean_upper(n,u):
    """Uses frozen promise u^2<v<1."""
    d=F(u)**6/(1+F(u)**6)
    return (F(n)/d)**n

def relative_mean_interval(T,n,e):
    T,e=F(T),F(e)
    b=max(0,ceil_log2(F(2*n)/e)); scale=1<<b
    lo=F(T.numerator*scale//T.denominator,scale); hi=lo+F(1,scale)
    assert 0<lo<=T<=hi and hi/lo<=1+e
    return {"lower":lo,"upper":hi,"precision_bits":b}

def rational_early_envelope(b0,D,k):
    """Only evaluates the proved rational outward formulas.
    DOES NOT decide source-temperature, geometric or volume promises.
    Their validity is an external accepted theorem hypothesis, not inferred.
    """
    if b0<8 or b0%8 or D<1 or k<2: raise ValueError("formula domain")
    n=D*D*4**k
    r=b0+4*k+4*ceil_log2(D+1)
    qc=F(1,1<<(3*b0//2-3))
    q5=F(1,1<<(7*b0//8-2))
    eta=6*n*q5**(2*r)/(1-q5)
    if eta>=1: raise ValueError("formula requires eta<1")
    per=4*b0*(2**k-1)-8
    db=F(1,1<<((3*n)//(16*2**k)))
    A=((8*n)**10*qc**per/(1-qc)+n*db)/(1-eta)
    bb=db/(1-eta)
    upper=F(1,24)/A
    j=ceil_log2(upper)
    dy=F(1<<j) if j>=0 else F(1,1<<(-j))
    if dy>upper: dy/=2
    assert F(1,48)/A<=dy<=upper
    return {"a_cap_upper":A,"b_cap_upper":bb,"time":dy,
            "conditional_on_original_source_hypotheses":True}

def enc(x):
    if isinstance(x,F):
        return {"numerator":str(x.numerator),"denominator":str(x.denominator)}
    raise TypeError(type(x).__name__)

def audit():
    u,v=F(1,4096),F(255,256); w=u**5
    ku=u**4/(1+u**4)**2; local=[]
    for spin in (-1,1):
        for S in (-4,-2,0,2,4):
            c,cp=rate(u,v,spin,S),rate(u,w,spin,S)
            assert abs(c-cp)>=ku*abs(v-w)
            assert c*c/cp+cp-2*c==(c-cp)**2/cp
            local.append({"spin":spin,"neighbour_sum":S,
                          "physical_rate":c,"proposal_rate":cp})
    q,start,meta=build_killed(3,u,v)
    means=solve_mean(q); T=means[start]
    assert T==max(means) and F(1,9)<=T<=mean_upper(9,u)
    e=F(1,1000); j=ceil_log2(T)-2
    t0=F(1<<j) if j>=0 else F(1,1<<(-j))
    assert T/4<=t0<=T/2
    queries=[]
    for t in (t0,4*t0,F(1<<4096)):
        out=cdf_enclosure(q,start,9,t,e,T)
        if t==t0: assert out["lower"]<=t/T
        queries.append({"time":t,"time_bits":t.numerator.bit_length(),**out})
    fine=cdf_enclosure(q,start,9,t0,e/4,T)
    assert max(fine["lower"],queries[0]["lower"])<=min(fine["upper"],queries[0]["upper"])
    return {"status":"exact arithmetic checks passed",
            "scope":"3x3 fixture OUTSIDE growing-volume promise; no polynomial predictor",
            "physical_experiments":0,"native_samples":0,"random_samples":0,
            "u":u,"v":v,"proposal_v":w,**meta,"local_rate_checks":local,
            "exact_mean":T,"mean_display_only":float(T),
            "mean_interval":relative_mean_interval(T,9,e),
            "cdf_queries":queries,"finer_first_query":fine,
            "rational_early_envelope":"implemented and proved, not executed on a growing source-valid instance"}

if __name__=="__main__":
    out=audit()
    Path(__file__).with_name("EXACT_AUDIT.json").write_text(json.dumps(out,default=enc,indent=2)+"\n")
    print(json.dumps({"status":out["status"],"microstates":out["microstates"],
      "transient_orbits":out["transient_orbits"],"mean":out["mean_display_only"],
      "cdf":[{"interval_display":[float(x["lower"]),float(x["upper"])],
              "time_bits":x["time_bits"],"squarings":x.get("squarings"),
              "precision_bits":x.get("precision_bits")} for x in out["cdf_queries"]],
      "native_samples":0,"random_samples":0}))
