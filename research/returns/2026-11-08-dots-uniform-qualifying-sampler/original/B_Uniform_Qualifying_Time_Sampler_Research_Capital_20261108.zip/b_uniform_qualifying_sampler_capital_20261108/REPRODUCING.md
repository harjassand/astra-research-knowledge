# Reproducing the finite checks

## Environment

The clean release run uses Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0, SymPy 1.14.0 and mpmath 1.3.0. Exact pinned versions are in `requirements.txt`. The supplied tests do not download data or use network services. Dependency installation, if needed, is separate from running them.

From the extracted release directory:

    python VERIFY_MANIFEST.py
    python RUN_CHECKS.py --suite smoke
    python RUN_CHECKS.py --suite full

Use `--output /an/empty/directory` to retain logs at a chosen location outside the release. Without it, a new temporary result directory is created and printed. The smoke suite focuses on the new coefficient-MPO constructor, exact gauges, warm product queries, combined parameters and representative older contracts. The full suite runs all 31 bundled Python diagnostic programs, including the slower exhaustive historical language and correction tests.

`RUN_CHECKS.py` makes a temporary **copy** of the entire proof tree before running anything. Several original checks write adjacent result JSONs, and the MPO prototype imports a gauge module. The runner prevents those behaviors from altering the distributed reports or evidence. It also disables bytecode output and fixes numerical-library thread counts. Executable Python syntax trees are unchanged; one operational code comment was edited and is recorded in the provenance map.

Each test's output and elapsed time are saved. Regenerated JSONs differing from the bundled historical evidence are copied to the chosen result directory. Timing fields and small floating-point differences are expected; the bundle does not promise byte-identical regenerated JSONs. The runner verifies that the distributed proof tree is unchanged. `verification/CLEAN_RUN_SUMMARY.json` records the release's clean full run; `verification/TEST_INTERPRETATION.md` states what the checks do and do not establish.

## What is and is not implemented

`prototype_mpo_dp.py` implements an exact-rational coefficient-MPO dynamic program for a three-qubit noncommuting example. It builds the generator from local terms, canonicalizes coefficients, compares against separate dense coefficients, and evaluates normalized scalar examples. It is a primitive implementation, not an end-to-end implementation of the final asymptotic sampling theorem.

The final theorem also depends on general proofs and established source theorems. A successful run of finite examples does not prove asymptotic rank bounds, positivity of a truncated polynomial, practical speed, or historical novelty. The truncated polynomial is used to approximate scalars and need not itself be a physical channel.

## Integrity and provenance

`MANIFEST.sha256` is the authoritative portable release manifest. It excludes itself. `VERIFY_MANIFEST.py` checks all its entries, unexpected files and the packaged hashes in `SOURCE_PROVENANCE.json`.

The original reviewed source hashes and presentation-only release-copy hashes are distinct. `SOURCE_PROVENANCE.json` records both and summarizes each transformation; the original identities are also listed in `START_HERE.md`. Presentation edits remove operational text, relocate absolute source paths and mark historical status. No mathematical statement or executable test code was changed. Superseded historical source manifests are not shipped as if they were current integrity checks.
