# Sources, closest prior, and the claim boundary

This is a synthesis of established methods plus a specific paid closure. The package does not claim invention of hypercontractivity, polymers, Fourier heavy hitters, coefficient propagation, exact tensor interpolation, or cut-count MPO compression. It does not make a historical-first claim.

## Essential primary sources

- Mackay, Kim, Vu and Kuwahara, **Optimal low-rank compression of quantum dynamics**, arXiv:2609.27497v1: https://arxiv.org/html/2609.27497v1 . Supplementary Corollary 6 and Proposition 49, equations (864)–(873), supply the algebraic coefficientwise phase/cut-count construction. Sections XI–XII count exact field operations and do not provide a uniform floating-point stability theorem. The present proof exposes growing layer size and pays exact rational interpolation separately.
- King, arXiv:1210.8412: https://arxiv.org/html/1210.8412v1 . Theorem 1/Corollary 2 give the full 1<p<=q hypercontractive range for unital qubit channels. Alternating with unitary conjugation proves the interacting physical inequality used here.
- Angrisani et al., arXiv:2609.40174v2: https://arxiv.org/html/2609.40174v2 . Coefficient regularity and sparse Pauli propagation are close prior. Supplied/local-observable or state-design guarantees are not by themselves a worst-case full-output initialization oracle.
- Nelson et al., arXiv:2610.00548v2: https://arxiv.org/html/2610.00548v2 . Theorem 2.3 proves noisy discrete-circuit marginal/sampling results and provides close polymer/log-normalization prior. The inverse noise-per-layer dependence does not remain uniform under a naive continuous-time Trotter limit.
- McDonough et al., arXiv:2502.02652v2: https://arxiv.org/html/2502.02652v2 . Many-region Lieb–Robinson and path-resummation methods motivate the spatial step. This release uses the explicit two-body first-discovery repair for multi-site targets rather than relying on the defective literal interval interpretation.
- Oseledets and Tyrtyshnikov, **TT-cross approximation for multidimensional arrays**, Linear Algebra and its Applications 432(1), 70–88 (2010): https://doi.org/10.1016/j.laa.2009.07.024 . Exact matrix/tensor skeleton interpolation is established prior. No generic black-box tensor discovery or stable floating-point rank selection is assumed here.
- Trivedi and Cirac, Physical Review Letters 129, 260405 (2022): https://journals.aps.org/prl/abstract/10.1103/PhysRevLett.129.260405 . Continuous-time sampling at sufficiently high noise rate is prior. Waiting to a qualifying accumulated time for every fixed positive ratio is a different parameter regime.

The discovery notes also identify the standard Kushilevitz–Mansour/Goldreich–Levin Fourier-search lineage. Its normalized membership oracle is explicitly implemented here, not replaced by ordinary physical output samples.

## What the current assembly adds relative to the preceding project result

The direct static-patch evaluator retains exact rational coefficients, explicit growing-width bond costs and bit heights. Applied to retiled child activity patches at logarithmic warm time, it stops the old repeated membership recursion after one level. This changes the preceding nonuniform log-star-recursive bound into a uniform polynomial bound in the **same** qualifying-time regime.

The independently checked nearest source statements do not directly subsume this complete finite-bit assembly. That observation is not an exhaustive literature search or novelty determination. The imported rank theorem remains an external established mathematical input: the package includes all project derivations and exact references, not a verbatim reproduction of the source paper.

## Counterexamples and boundaries respected

The construction uses the explicit local static generator, not a generic bounded-error product-query oracle, so it does not contradict abstract sparse-spectrum hiding examples. It averages the Lindblad dynamics before compression, rather than simplifying every unitary noise trajectory. It does not rely on raw Bell postselection, an unproved positive interpretation of a signed MPO, or a rare-prefix relative probability oracle.

The included exact source-language failure and rational denominator counterexample are regression cases. They expose failed intermediate arguments without being promoted to generic simulation hardness. Likewise, the new patch primitive can evaluate a finite early-time example, but cannot by itself make an unproved early-time global expansion converge.
