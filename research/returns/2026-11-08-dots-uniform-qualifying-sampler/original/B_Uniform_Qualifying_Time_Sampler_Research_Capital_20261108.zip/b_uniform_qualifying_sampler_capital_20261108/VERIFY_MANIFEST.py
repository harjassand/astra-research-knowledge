#!/usr/bin/env python3
"""Verify release integrity and presentation-copy provenance, without external tools."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent
fail=[];expected={}
for line in (ROOT/'MANIFEST.sha256').read_text().splitlines():
 sha,name=line.split('  ',1);p=ROOT/name
 if Path(name).is_absolute():fail.append('absolute path: '+name);continue
 if name in expected:fail.append('duplicate path: '+name);continue
 if '..' in Path(name).parts:fail.append('unsafe path: '+name);continue
 expected[name]=sha
 if not p.is_file():fail.append('missing: '+name)
 elif hashlib.sha256(p.read_bytes()).hexdigest()!=sha:fail.append('hash mismatch: '+name)
actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p.name!='MANIFEST.sha256' and '__pycache__' not in p.parts}
for name in sorted(actual-set(expected)):fail.append('unlisted: '+name)
prov=json.loads((ROOT/'SOURCE_PROVENANCE.json').read_text())
for row in prov['files']:
 p=ROOT/row['file']
 if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=row['packaged_sha256']:fail.append('provenance mismatch: '+row['file'])
if fail:
 print('\n'.join(fail));sys.exit(1)
print(f'PASS: {len(expected)} release files and {len(prov["files"])} source-provenance mappings verified.')
