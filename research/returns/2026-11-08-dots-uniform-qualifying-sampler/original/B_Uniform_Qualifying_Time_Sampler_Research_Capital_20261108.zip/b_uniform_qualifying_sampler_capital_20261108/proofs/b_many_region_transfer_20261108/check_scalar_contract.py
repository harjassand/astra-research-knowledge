from fractions import Fraction as F
from math import comb
import json
from pathlib import Path

def ceil(x): return -(-x.numerator//x.denominator)
def clog2(n): return (n-1).bit_length()

def certify(ratio, c=6, degree=5):
    # gamma=1 fixes the physical unit; all choices are exact rationals/integers.
    T=F(1)
    R0=max(1024,128*(c+3))
    iterations=0
    while True:
        r=R0+ceil(12*ratio*degree*T)
        threshold=2*clog2(r)+2+32*(c+4)
        if T>=threshold: break
        T*=2;iterations+=1
    # These rational inequalities are deliberately stronger than analytic logs.
    assert 2*3*ratio*degree*T/r <= F(1,2) # e<3
    assert F(r,2)>=9+3*clog2(r)+32*(c+3)
    assert T-(2+2*clog2(r))>=32*(c+4)
    assert r>=R0
    return dict(h_over_gamma=str(ratio),gammaT=str(T),r=r,V=9*r*r,
                iterations=iterations,threshold=threshold,
                leakage_log_upper_rational=str(F(5)+2*clog2(r)-F(r,2)),
                tested_with_exact_arithmetic=True)

out={"scope":"Scalar certificate only; no global sampling theorem or quantum simulation.",
     "parameters":[certify(F(1,16)),certify(F(1)),certify(F(10)),certify(F(10**6))]}
# Replace e by 3 in the weaker elementary count, checking after clearing powers.
cases=0
for N in range(1,101):
  for m in range(1,N+1):
    k=(m+1)//2
    count=sum(comb(N,w)*3**w for w in range(k))
    # count <= (18N/m)^(m/2) equivalent to count^2 m^m <=(18N)^m.
    assert count*count*m**m <= (18*N)**m
    cases+=1
out['counting_cases_checked']=cases
out['all_checks_passed']=True
p=Path(__file__).with_name('scalar_results.json');p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
