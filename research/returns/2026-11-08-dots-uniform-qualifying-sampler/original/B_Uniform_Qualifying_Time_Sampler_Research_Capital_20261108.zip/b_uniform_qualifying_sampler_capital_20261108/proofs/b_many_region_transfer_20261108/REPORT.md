# A simultaneous-erasure lemma for continuous noisy dynamics

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

8 November 2026. Research continuation toward the original full-output sampling problem. This note proves a quantitative replacement for a false hard-support invariant, on finite patches. It does not yet construct global connected activities or a full-output sampler. The many-commutator and hypercontractive ingredients are established prior work; no historical priority is claimed for the combination.

## Useful result and exact remaining gap

For an operator that is tracefree on q separated cores, projecting its evolved operator to identity on all q surrounding buffers costs a product delta^q in normalized trace norm, rather than an additive q delta. This holds for arbitrary local Hamiltonian terms with the stipulated every-site depolarizing replacement noise; the noise is not increased, observed, or conditioned on physically.

On a finite patch containing at most Vg sites, this erasure estimate controls the low-Pauli-weight leakage of a product of g centered measurement-projector factors. Combining that leakage bound with two hypercontractive intervals yields exponential decay in g at a physical time independent of a Trotter step. Both the number of sites per block and the threshold constants are enormous in the conservative construction.

The missing operation is NOT merely this norm bound. In continuous time, separated regions do not have exactly disjoint backward light cones. Consequently separately truncated patch weights are not an exact compatible-polymer representation of a full marginal. A connected-history expansion with controlled relative normalization is still required. Dividing an additive truncation error by a rare prefix probability is not permitted.

## 1. Setup and notation

On a finite set of N qubits use normalized trace tau_N=2^{-N}Tr and Schatten norms ||X||_{p,tau}=(tau_N|X|^p)^{1/p}. Let

    L_+(X)= i[H,X]+gamma sum_i(E_i X-X),
    L_-(X)=-i[H,X]+gamma sum_i(E_i X-X),
    E_i X=I_i/2 tensor Tr_i X,     Phi_t=exp(t L_+).

Here H is a bounded-incidence, finite-range local Hamiltonian, gamma>0, and both signs of H satisfy the same strength and locality conditions. All analytic statements apply to exact real time. An algorithmic use requires rational time, gamma, coefficients and accuracy, or explicitly paid certified representations.

For a region C, E_C is normalized partial trace over C followed by the identity on C; Q_C=Id-E_C. The maps E_C and Q_C are self-adjoint in the tau inner product. Disjoint regions give commuting such maps. A tracefree core means Q_C M=M, not that the entire operator M is supported on C.

Choose q cores S_j, each inside a surrounding buffer B_j. The B_j are mutually separated by at least one interaction factor. Put A=(union_j B_j)^c. The cores are at least r interaction-graph steps from A.

## 2. Imported input and its precise scope

McDonough, Yin, Lucas and Zhang, arXiv:2502.02652v2, Theorem 4.4 and Corollary 4.9, give a product bound on nested commutators of Hamiltonian-evolved operators with separated-region probes. Their Section 4.4 treats time-dependent interactions. For local-term norm at most h, choose Delta as a conservative bound on both the source factor-graph degree and the branching of the counted factor paths, with distance counted in interaction factors. If each term has arity at most k and each site incidence at most d, taking Delta>=max(2,k,d,d(k-1)) suffices; Delta is not merely a loosely identified lattice coordination number. For the two-body square-lattice example with one grouped term per edge and one on-site term per vertex, Delta=5 is conservative. The source estimate then gives, for t<r/(2h Delta),

    ||ad_{U_q} ... ad_{U_1} Psi_t(Z)||_infty
       <= [delta(t)]^q ||Z||_infty,
    delta(t)=2 max_j(|boundary B_j| |boundary S_j|)
                (2 e h Delta t/r)^r,                 (1)

when Z is supported on A and each unitary U_j is supported on S_j. Source: https://arxiv.org/html/2502.02652v2 . This is the relevant many-region statement, not the source's separate local-observable simulation algorithm.

The depolarizing hypercontractivity input is the normalized p-to-q inequality at e^{2 gamma t}>=(q-1)/(p-1), p>1, including arbitrary interspersed Hamiltonian conjugations. King, arXiv:1210.8412, is already credited in the supplied dossier. Trotter product limits transfer this norm inequality to the actual noisy semigroup without importing a circuit-sampling runtime.

The supplied dossier, lines 1245 onward in Pasted text(20261107-183118).txt, already identifies the connected-activity/relative-normalization problem and warns that factorial spatial tails alone do not solve it. The new calculation below addresses one quantitative support-leakage step, not that entire missing operation.

## 3. Replacement noise preserves the many-region estimate

Every-site replacement has the exact random-unitary unraveling

    gamma(E_i-Id)=(gamma/4) sum_{P=X,Y,Z}(Ad_{P_i}-Id).

For each finite Poisson history, move the product of on-site Pauli kicks into a toggling frame. The remaining time-dependent Hamiltonian consists of the original local terms conjugated by on-site Paulis, so it has identical supports and term norms. The final on-site Pauli conjugation preserves support and merely conjugates the unitary probes in (1). The imported time-dependent estimate is therefore uniform over all histories. Averaging and the triangle inequality establish (1) for exp(t L_+) and exp(t L_-).

No extra noise is introduced. The number of kicks does not enter (1). The histories here justify an analytic inequality, not an assumed efficient sampler. Static H avoids any ordering issue; for driven H, Hilbert-Schmidt duality also reverses the schedule, which the uniform bounds allow.

## 4. Simultaneous-erasure lemma

**Lemma.** If Q_{S_j} M=M for every selected core, and (1) holds uniformly up to time t, then

    ||E_{union B_j} Phi_t(M)||_{1,tau}
       <= delta(t)^q ||M||_{1,tau}.                  (2)

**Proof.** For any Z with ||Z||_infty<=1, E_{union B_j}Z is supported on A and still has norm at most one. The trace-inner-product adjoint of Phi_t is exp(t L_-), which obeys the same bound. Move all Q_{S_j} from M onto the dual evolved observable. Haar averaging on each core gives

    Q_S(X)=integral [X,U_S] U_S^dagger dU_S.

Since the cores are disjoint, their unitaries commute with one another, and the product of these projections is the average of a q-fold nested commutator, multiplied on the right by a unitary. Equation (1) bounds its operator norm by delta(t)^q. Schatten duality and taking the supremum over Z prove (2). This proof works for arbitrary, not necessarily positive, M.

This is a product erasure bound. It does NOT say a coefficient vanishes, or that the resulting channel factors across buffers.

## 5. Finite-patch low-weight leakage

Let g disjoint blocks carry nonempty sets of b_j<=a measured sites, and let

    M=product_{j=1}^g [2^{b_j}|x_j><x_j|-I]

with identities on unmeasured sites. Then each block is tracefree, and

    ||M||_{1,tau}<=2^g,
    ||M||_{1+1/a,tau}<=3^g.                         (3)

Indeed each factor has normalized p-th absolute moment at most 2^{b_j(p-1)}+1<=3 when p=1+1/a. Tensor products multiply these norms.

Suppose m>=g/chi of the blocks can be chosen as separated cores with disjoint buffers as above, and the entire simulated patch contains

    N<=Vg,    V>=1.                                 (4)

Assume delta(s)<=delta<=1 for every 0<=s<=T. Put k=ceil(m/2), and let Pi_<k project onto Pauli strings of weight less than k.

Every such Pauli string acts nontrivially on fewer than m/2 of the disjoint buffers. Apply (2) to the remaining >m/2 buffers. Its coefficient in Phi_s(M) has magnitude at most 2^g delta^{m/2}. The number of weight-<k strings is bounded by

    sum_{w<k} 3^w binom(N,w)
      <= (6 e N/m)^{m/2}
      <= (6 e chi V)^{m/2}.                         (5)

For the first inequality, embed the colored-site choices in subsets of 3N elements and use the standard binomial lower-tail counting bound; floor(m/2) only improves it. The m=1 case is also harmless: the only low-weight coefficient is the identity, which is exactly zero.

Orthogonality of Pauli strings yields the uniform leakage estimate

    ||Pi_<k Phi_s(M)||_{2,tau}
      <= E := 2^g (6 e chi V)^{m/4} delta^{m/2}.      (6)

The site bound (4) is essential. Substituting the size n of an arbitrary large surrounding system instead makes this coefficient-counting cost grow with n. This note does not silently perform that substitution.

## 6. Hypercontractivity closes the finite-patch norm estimate

Set

    t_pre=log(a)/(2 gamma),
    t_post=log(V)/(2 gamma),
    U=T-t_pre-t_post >=0.

The first interval and (3) give ||Phi_{t_pre}(M)||_{2,tau}<=3^g.
For O_s=Phi_s(M), Hamiltonian evolution contributes zero to the derivative of its squared 2-norm. Replacement gives exactly

    d/ds ||O_s||_2^2 = -2 gamma sum_P |P| |c_P(s)|^2
      <= -2 gamma k (||O_s||_2^2-E^2).               (7)

Integrating over the middle interval and taking a square root gives

    ||O_{T-t_post}||_2 <= 3^g exp(-gamma k U)+E.

The final interval sends normalized 2-norm to normalized q-norm for q=1+V. The inequality ||X||_infty<=2^{N/q}||X||_{q,tau}, together with N<=Vg, costs at most 2^g. If

    B_delta=(6 e chi V)^{1/4} delta^{1/2} <=1,

then m>=g/chi and k>=g/(2chi) imply

    ||Phi_T(M)||_infty
      <= [6 exp(-gamma U/(2chi))]^g
         +[4 (6 e chi V)^{1/(4chi)}
                 delta^{1/(2chi)}]^g.              (8)

In particular, for c>0 the sufficient conditions

    gamma U >= 2chi(c+log 12),
    delta <= exp[-2chi(c+log 8)]/(6 e chi V)^(1/2)   (9)

give ||Phi_T(M)||_infty<=exp(-cg). The two terms in (8) are each at most exp[-(c+log 2)g], so their sum has the claimed bound for g>=1. Conditions (9) also imply B_delta<=1.

## 7. Concrete square-lattice parameters

For nearest-neighbor two-body Hamiltonian terms plus on-site fields, tile the lattice into core squares of side r. Work on the union of the g cores enlarged by r in each direction. Its size is at most 9r^2 g. A 4-by-4 coloring selects at least g/16 cores whose side-3r buffers are separated. Therefore one may take

    chi=16,    a=r^2,    V=9r^2,
    delta <=96r^2 (2 e h Delta T/r)^r.               (10)

Boundary truncation can reduce these counts. For longer but fixed interaction ranges, the abstract lemma remains applicable, but geometry and degree constants must be recomputed rather than borrowing (10).

A fully rational conservative scalar contract for integer c>=1 is:

    R0=max(1024,128(c+3)),
    r=R0+ceil(12 h Delta T),
    gamma T >= 2 ceil(log_2 r)+2+32(c+4).            (11)

Start at T=1/gamma and double T until the final inequality holds, recomputing r each time. Exponential growth of gamma T versus logarithmic growth of r guarantees termination. In (10), 2 e h Delta T/r<1/2, so delta<=96r^2 2^{-r}. Using log2>=1/2, log96<5 and log(2592)<8 verifies (9) from (11). More explicitly, it suffices that

    r/2 >= 9+3 log_2 r+32(c+3),

which follows from r>=max(1024,128(c+3)). The first part of (9) follows from log(3r^2)<=2+2ceil(log_2 r) and log12<4.

For each fixed numerical h/gamma and locality bound, T and r are constants independent of lattice size, target accuracy, and Trotter step. Their conservative scales are

    gamma T=O(c+log(1+h/gamma)+log(c+2)),
    r=O(c+1+(h/gamma)Delta[gamma T]).

This is a norm-decay statement on the specified finite patches, not a constant-time thermalization or sampling theorem on the complete lattice.

## 8. What it would cost to use these patch weights

A patch has N<=Vg qubits. Direct dense Liouville arithmetic costs exp(O(N)), with paid coefficient bits, numerical action N(h+gamma)T and requested scalar precision. A rational matrix-exponential series can use polynomially many terms in that action plus log(1/eta)+ag to compute a weight to additive error eta: the ag term pays the observable norm ||M||_infty<=2^{ag}. Dense matrix dimensions and integer bit lengths remain charged. This is an exponential patch calculation, not an oracle.

If a valid connected-activity expansion needed only g=O(log(n/epsilon)) and V were fixed, these calculations and enumeration of connected block sets would be polynomial with an exponent proportional to V. Here V=9r^2 can already be astronomically large. There is no implementation or practical superiority claim at those bounds.

Crucially, the supposition in the previous paragraph has not been earned for the actual continuous-time output distribution. Independent truncated evolutions on different patches need not be compatible with any one global law. Equation (8) cannot itself license a sequential sampler, relative probabilities, or a zero-free logarithm.

## 9. Failure test and review status

The independent reviewer has an exact static nearest-neighbor Pauli-chain construction in which an initially many-block centered diagonal operator acquires a nonzero single-site coefficient at every t>0, even with fixed positive gamma/J. This falsifies the literal minimum-weight invariant used by a naive circuit-to-continuum import. It is consistent with (2) and (6), which bound leakage instead of declaring it zero. Its separate proof and computation are to be retained with the independent review.

The attached scalar script checks (11), the conservative inequalities, and the coefficient-count bound on a finite range using exact integer or rational arithmetic where possible. It is not a large quantum simulation. The first completed independent audit supports the erasure duality, physical-noise transfer, leakage counting, hypercontractive composition, geometry and scalar constants; see INDEPENDENT_AUDIT.md. A second source-focused independent review is still underway. The distinct all-time hard-support counterexample is preserved in obstruction/. No full-output general-B result follows unless the missing connected-activity and relative-normalization operation is completed.

## 10. Why naive patch gluing can lose the low-noise gain

The following is an accounting warning about one proposed proof strategy, not a lower bound on algorithms or on the true dynamics.

Suppose a connected-patch expansion with k added coarse blocks has at most A^{g+k} terms. Suppose the only available envelopes for each term are a small-patch decay exp(-cg) and an ordinary operator-norm growth tail

    exp[(log 2) a g-beta r k],

where a=r^2 is the number of sites in a 2D core. The latter starts from ||M||_infty<=2^{ag}; factors from a patch inclusion-exclusion can be absorbed into A. Even granting these envelopes, summing their minimum encounters the crossover

    k_* approximately [(log 2)a+c]g/(beta r).

The counting penalty there is exp((log A)k_*). To beat it using exp(-cg), c must be of order at least a/r=r. But (8) supplies at most c=O(gamma T) at a fixed coloring, while the geometric buffer already needs r=Omega(h T). This crude norm-plus-triangle gluing therefore tends to require a high-noise ratio again; a finite physical-time patch lemma is not by itself the desired low-noise global transfer.

A useful next target is consequently sharper than merely repeating ordinary locality: a normalized connected-activity estimate whose source cost is exp(O(g)), comparable to ||M||_{1,tau}<=2^g, rather than exp(O(ag)). It must also retain a decaying cost for each added region and control the compatibility/log-normalization structure. Section 4 supplies such an exp(O(g)) input for simultaneous erasures, but this note has not converted it into that global activity norm. The displayed crossover analysis does not exclude cancellations, alternative latent representations, or a better gluing method.
