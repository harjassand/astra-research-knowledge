# Second independent audit: finite-patch many-region transfer

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

## Verdict

The simultaneous-erasure lemma and its stated finite-patch norm-decay consequence are mathematically consistent under the specified replacement noise and source hypotheses. Independent examination found no missing dimension factor, lost power of two, or invalid Hamiltonian interspersing in those steps. The author clarified the path-branching convention for Delta during review.

**No global connected-activity construction, relative normalization guarantee, or full-output sampler follows.** Those remain substantive missing theorems, not implementation details. The new global-gluing section is correctly presented as an accounting warning about one proof strategy, not a hardness result or a completed extension.

The quantitative constants are prohibitive. For the displayed h/gamma=1, c=6, degree-5 example, gamma T=512, r=31,872, and V=9,142,419,456. An exponential-in-patch-size calculation remains entirely impractical even if a later logarithmic-cluster cutoff were proved.

## 1. Imported source conditions

Checked sources:

- McDonough, Yin, Lucas and Zhang, arXiv:2502.02652v2, Theorem 4.4, Corollary 4.9, and Section 4.4: https://arxiv.org/html/2502.02652v2 . The bound requires disjoint buffers separated in the factor graph, probes inside their cores, an exterior-supported test operator, uniformly bounded local interactions, and the stated time/distance inequality. Its nested commutator is normalized by 2^q. The report's delta includes the necessary factor 2 per region. The driven version keeps supports fixed and interaction norms uniformly bounded.
- King, arXiv:1210.8412, Theorem 1/Corollary 2: https://arxiv.org/html/1210.8412 . The depolarizing normalized Schatten p-to-q contraction holds for every 1<p<=q and all matrices, not only positive observables. Hamiltonian interspersing is justified separately by unitary invariance and a finite-dimensional Trotter limit.

Distances count interaction factors, not raw bipartite-graph edges. The revised definition of Delta should be retained: it upper-bounds both the source degree and the path branching used in the counting estimate. For interaction arity k and site incidence d, max(2,k,d,d(k-1)) is a safe choice. For grouped two-body square-lattice bonds plus one grouped on-site term, Delta=5 is conservative. If several Pauli terms share a support, h must bound their grouped operator norm or incidence must count the separate terms. A bare per-Pauli coefficient bound is not automatically the same h.

Replacing individual distances r_j by a common lower bound r is safe in the stated time range. The function (2 e h Delta t / x)^x decreases for x>2h Delta t, so the source distance dependence can only improve when the actual distance exceeds r.

## 2. Exact replacement-noise transfer

The local Pauli-jump representation is exact: each axis has rate gamma/4. For any finite history, all kicks are on-site unitaries. Toggling them into the Hamiltonian preserves every interaction support and operator norm, producing a piecewise time-dependent Hamiltonian satisfying the cited hypotheses. A terminal on-site unitary only conjugates probes within their original supports.

The source bound is uniform over these histories. Averaging therefore does not pay a factor depending on the number of noise events. This is an analytic use of an unraveling, not a claim that sampling its many-body trajectories is computationally efficient. The finite patch has finitely many jumps almost surely at finite time.

Both signs of the static Hamiltonian obey the same bound; this is essential because normalized trace duality uses the adjoint semigroup, with the opposite commutator sign. For driven dynamics the order is reversed as well, which remains within the uniform driven hypotheses.

This argument does not transfer automatically to amplitude damping or arbitrary nonunital noise. Already with H=0, amplitude-damping Heisenberg evolution sends a traceless Z to a combination containing identity, contradicting a zero-H erasure bound with delta=0. Every-site replacement is also needed for the later Pauli-weight dissipation and hypercontractivity steps.

## 3. Simultaneous erasure and low-weight leakage

For the normalized trace, conditional expectations E_C and Q_C=Id-E_C are orthogonal projections in the Hilbert-Schmidt pairing. If Q_(S_j)M=M for each selected core, their product can be moved from M to the dual evolved observable. The dual test after erasing all buffers is supported outside those buffers.

Each Q_S is the average of [X,U_S]U_S^dagger. For disjoint cores the probe unitaries commute, and the product becomes a nested commutator times a unitary, up to an irrelevant sign. Schatten 1/infinity duality then gives delta^q times the original normalized trace norm. M need not be positive, Hermitian, or supported only on the cores. No ordinary-trace dimension factor is introduced.

For the centered measurement product, normalized trace norm is at most 2^g. The normalized (1+1/a)-moment of each factor is at most 3, giving the report's conservative norm bound 3^g.

A Pauli string of weight below ceil(m/2) misses more than m/2 of the disjoint buffers. Its coefficient is bounded using simultaneous erasure on exactly those missed buffers. Delta<=1 licenses weakening the integer exponent to m/2. The string count can also be derived without floor ambiguities: put z=m/(6N); then

sum_(w<m/2) 3^w binom(N,w) <= z^(-m/2)(1+3z)^N <= (6eN/m)^(m/2).

The resulting low-sector 2-norm bound agrees with the report. The assumptions N<=Vg and B_delta<=1 are indispensable to its subsequent rewriting in terms of g. The first cannot be replaced by an arbitrarily large global n without paying the resulting count/dimension costs.

## 4. Hypercontractive composition

A precise interspersing argument uses p(s)=1+(p0-1)exp(2gamma s). A small replacement-noise step contracts from p(s) to p(s+ds); an arbitrary Hamiltonian conjugation is an isometry at the intervening exponent. Composing and taking the finite-dimensional Trotter limit yields the stated bound for the actual continuous noisy semigroup. This imports no circuit-sampling runtime and requires no noise increase.

Hamiltonian evolution contributes zero to the squared normalized 2-norm derivative. Replacement contributes exactly -2gamma times the Pauli-weight moment. The uniform low-sector leakage estimate therefore gives the stated differential inequality and integrated middle-interval bound.

The final q=1+V conversion pays 2^(N/q)<=2^g only because N<=Vg. Combining the three intervals reproduces the constants 6 and 4 in equation (8). Conditions (9) give at most 2 exp[-(c+log2)g]<=exp(-cg) for g>=1. There is no hidden positivity assumption in this calculation.

## 5. Geometry, scalar contract and actual scale

For r-by-r cores enlarged by r on each side, a buffer has 9r^2 sites. Its boundary has at most 12r sites; a core boundary has at most 4r. Thus the product-prefactor bound is 2(12r)(4r)=96r^2. The four-by-four coloring leaves at least g/16 selected cores. Nearest same-color buffers have site distance r+1, so nearest-neighbor interaction factors do not bridge them directly. Truncating at a physical patch boundary cannot create a shorter path or increase the boundary count for this open square geometry. Periodic or longer-range geometries require their own check.

The rational doubling contract is sufficient. It pays the two hypercontractive intervals and the middle damping interval, while r>12h Delta T makes the propagation factor smaller than 1/2. The scalar logarithmic bounds hold with substantial slack in the independent parameter checks below.

The runtime implications must remain explicit:

- Direct patch work is exp(O(Vg)), with coefficient bits, matrix-exponential action, and scalar accuracy paid.
- Only **if** a valid global expansion later supplied g=O(log(n/epsilon)) would this become a polynomial with a potentially enormous exponent proportional to V.
- In the displayed h/gamma=1 example, V exceeds nine billion. Even h/gamma=1/16 gives V=84,934,656 at c=6.
- At gamma T=512 and n=10^6, the simpler global entropy-mixing estimate already makes uniform-output TV less than 4e-109. This does not negate the asymptotic finite-patch statement, but the conservative constants demonstrate no practically accessible new simulation regime.

The analytic thresholds depend on the physical numerical ratios, not merely their bit lengths. Fixing h/gamma and locality is essential when calling T, r, and V constants.

## 6. Exact patch-to-global blocker

For exact global dynamics, a marginal written using centered block factors has an identity of the form

P(x_A)=2^(-B) sum_(S subset selected blocks) w_global(S),

where all moments w_global(S) come from the **same** evolved global state. Replacing each moment by a separate evolution on its own truncated neighborhood does not preserve that common moment functional. Enlarging the subset generally changes the retained Hamiltonian and hence the lower-order moments. The resulting family is not automatically consistent under marginalization.

Continuous-time tails also prevent an exact declaration that disconnected coarse sets factorize. Therefore one cannot simply call the separately computed patch quantities compatible polymers. Even a hypothetical uniform moment bound |w(S)|<=u^|S| would not by itself prove spatial connectedness, summability over positions, or controlled cumulants. A naive partition-cumulant estimate additionally pays the sum of (|partition|-1)! over partitions, unless a separate structure/cancellation argument controls it.

The final step needs an exact global connected-history or equivalent representation, a summable bound on its activities, and a relative/log-normalization estimate strong enough for sequential conditionals. Dividing an additive local error by a rare prefix probability supplies none of these. Clipping or independently renormalizing such local estimates is not a substitute for a global TV proof.

Section 10's proposed envelope calculation is a useful warning, not a proof of impossibility. If one only combines exp(-cg) with exp[(log2)ag-beta r k] and A^(g+k) term counts, their crossover occurs at k of order ag/r. Making this particular worst-case upper bound small can force c of order a/r, which is order r in two dimensions and tends back toward a high-noise condition when r scales with hT. Actual cancellations, sharper norms, alternative representations, or better combinatorics could evade that accounting. No algorithmic lower bound follows.

## 7. Independent executed checks

`check_transfer.py` and `checks.json` accompany this audit.

- A four-qubit non-Hermitian test operator projected tracefree on two separated cores: finite-Pauli-twirl versus nested-commutator residual 1.53e-15.
- Nine dense continuous-time erasure/duality checks at gamma=0,0.7,3 and three short times. All satisfy the stated product bound; the largest observed erasure/bound ratio is 0.000293. Opposite-sign adjoint duality is checked explicitly.
- 11,325 exact-integer coefficient-count checks, N<=150, using the slightly stronger rational constant 16<6e.
- Twenty-four independent scalar contracts over c=1,2,6,20 and h/gamma from zero through 10^6.
- Eight explicit square geometries, r=1 through 8, checking volume, boundary sizes, coloring separation and buffer distance.

These are sanity checks and scalar certificates, not a large-system quantum simulation or proof by experiment. The proof obligations above are analytic. The first reviewer's separate all-time Pauli-chain counterexample refutes a hard minimum-support invariant, not this weighted erasure lemma.
