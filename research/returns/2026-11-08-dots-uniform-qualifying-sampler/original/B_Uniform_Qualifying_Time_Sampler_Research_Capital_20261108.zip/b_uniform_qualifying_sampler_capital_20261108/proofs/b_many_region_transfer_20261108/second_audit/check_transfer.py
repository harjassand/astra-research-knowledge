"""Independent small-matrix checks and scalar/geometry audits; no global sampler."""
from fractions import Fraction as F
from math import comb,log,exp,ceil
import pathlib,json
import numpy as np
from scipy.sparse.linalg import expm_multiply
I=np.eye(2,dtype=complex);X=np.array([[0,1],[1,0]],complex);Y=np.array([[0,-1j],[1j,0]],complex);Z=np.diag([1,-1]).astype(complex)
def kron(ms):
 a=np.ones((1,1),complex)
 for m in ms:a=np.kron(a,m)
 return a
n=4;d=2**n
P=[[kron([p if j==q else I for j in range(n)])for p in [I,X,Y,Z]]for q in range(n)]
def E(m,sites):
 for q in sites:m=sum(p@m@p for p in P[q])/4
 return m
trnorm=lambda m:float(np.linalg.svd(m,compute_uv=False).sum()/d)
rng=np.random.default_rng(261108)
a=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d))
q=a-E(a,[0]);q=q-E(q,[3]);twirl=sum((((a@p-p@a)@r-r@(a@p-p@a))@p@r)for p in P[0]for r in P[3])/16
q2=a-E(a,[0])-E(a,[3])+E(a,[0,3])
twirlres=float(np.linalg.norm(twirl-q2));assert twirlres<1e-12
h=.4;Delta=3
H=.3*(P[0][1]@P[1][1])+.4*(P[1][2]@P[2][3])+.2*(P[2][1]@P[3][2])+.11*P[1][3]
unit=np.eye(d*d);L0=1j*(np.kron(np.eye(d),H)-np.kron(H.T,np.eye(d)))
rows=[]
for gamma in [0,.7,3.]:
 L=L0.copy()
 for j in range(n):
  for p in P[j][1:]:L+=gamma/4*(np.kron(p.conj(),p)-unit)
 for t in [.005,.02,.05]:
  evolved=expm_multiply(t*L,q.reshape(-1,order='F')).reshape(d,d,order='F')
  actual=trnorm(E(evolved,[0,3]))/trnorm(q);delta=2*(2*exp(1)*h*Delta*t)
  assert actual<=delta**2+1e-12
  # Duality uses the opposite Hamiltonian sign, not the same semigroup.
  z=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d));z=E(z,[0,3])
  dual=expm_multiply(t*L.conj().T,z.reshape(-1,order='F')).reshape(d,d,order='F')
  dualres=float(abs(np.trace(z.conj().T@evolved)-np.trace(dual.conj().T@q))/d)
  assert dualres<1e-11
  rows.append({'gamma':gamma,'time':t,'observed_erasure_ratio':actual,'delta_power2_bound':delta**2,'duality_residual':dualres})
# Exact conservative count test stronger than replacing e by3: 16<6e.
countcases=0
for N in range(1,151):
 for m in range(1,N+1):
  count=sum(3**w*comb(N,w)for w in range((m+1)//2))
  assert count*count*m**m<=(16*N)**m
  countcases+=1
# Exact-rational time/radius choices, independently recompute analytic log targets.
params=[]
for c in [1,2,6,20]:
 for ratio in [F(0),F(1,2**16),F(1,16),F(1),F(10),F(10**6)]:
  T=F(1);R0=max(1024,128*(c+3))
  while True:
   rr=12*ratio*5*T;r=R0-(-rr.numerator//rr.denominator)
   clog2=(r-1).bit_length();threshold=2*clog2+2+32*(c+4)
   if T>=threshold:break
   T*=2
  V=9*r*r;U=float(T)-log(3*r*r)
  ldelta=log(96)+2*log(r)-r*log(2)
  target=-32*(c+log(8))-.5*log(6*exp(1)*16*V)
  assert U>=32*(c+log(12)) and ldelta<=target
  params.append({'c':c,'h_over_gamma':str(ratio),'gammaT':str(T),'r':r,'V':V,'middle_time_slack':U-32*(c+log(12)),'leakage_log_slack':target-ldelta})
# Four-by-four block coloring, coordinate geometry for separated buffers.
geoms=[]
for r in range(1,9):
 core=lambda i,j:{(x,y)for x in range(i*r,(i+1)*r)for y in range(j*r,(j+1)*r)}
 buf=lambda i,j:{(x,y)for x in range((i-1)*r,(i+2)*r)for y in range((j-1)*r,(j+2)*r)}
 S=core(0,0);B=buf(0,0)
 boundary=lambda C:{(x,y)for x,y in C if any(v not in C for v in [(x+1,y),(x-1,y),(x,y+1),(x,y-1)])}
 bs,bb=len(boundary(S)),len(boundary(B));assert bs<=4*r and bb<=12*r and len(B)==9*r*r
 # Same-color nearest buffers are shifted by4r; their site-distance is r+1.
 B2=buf(4,0);dist=min(abs(x-u)+abs(y-v)for x,y in B for u,v in B2)
 assert dist==r+1 and B.isdisjoint(B2)
 geoms.append({'r':r,'core_boundary':bs,'buffer_boundary':bb,'buffer_sites':len(B),'nearest_same_color_buffer_distance':dist})
out={'twirl_projection_residual':twirlres,'dense_erasure_checks':rows,'exact_count_cases':countcases,'scalar_contracts':params,'square_geometry':geoms,'scope':'Independent sanity checks and scalar certificates only; no global connected activities or sampler.'}
pathlib.Path(__file__).with_name('checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'twirl_residual':twirlres,'dense_cases':len(rows),'max_ratio_to_erasure_bound':max(q['observed_erasure_ratio']/q['delta_power2_bound']for q in rows),'count_cases':countcases,'scalar_cases':len(params),'geometry_cases':len(geoms)},indent=2))
