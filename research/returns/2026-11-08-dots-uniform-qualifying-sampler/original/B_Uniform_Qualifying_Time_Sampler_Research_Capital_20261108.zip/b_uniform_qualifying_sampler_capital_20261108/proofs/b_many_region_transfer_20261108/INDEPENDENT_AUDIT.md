# Continuous-time many-block support: independent audit

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

8 November 2026. This review addresses the actual many-region support step, not the previously identified nonuniform Trotter-runtime problem.

## Result

1. A literal transfer of the noisy-circuit minimum-Pauli-weight invariant is false. An explicit static, nearest-neighbor, rational Pauli Hamiltonian with every-site replacement noise develops a nonzero one-site coefficient from a many-block centered measurement observable at **every positive physical time**.
2. The proposed replacement, simultaneous support erasure bounded multiplicatively across separated buffers, is valid under the cited many-commutator theorem. Its noise extension, duality, low-weight counting and finite-patch hypercontractive composition check out.
3. This establishes a finite-patch norm-decay statement, not a global sampler. The remaining blocker is a controlled global connected-activity representation and relative/log normalization. Independently truncated patches cannot simply be declared compatible polymers.

## A. Exact all-time counterexample to hard minimum support

For a chain of m qubits set gamma=1 and J=1/16, with

    H = -J sum_(j=1)^(m-2) Y_j X_(j+1) - J Y_(m-1) Z_m.

This is a static rational nearest-neighbor two-body Hamiltonian. It embeds in a square lattice. Use every-site noise gamma(E_i-Id), without changing its strength.

Define Pauli strings

    O_k = Z_1 ... Z_(k-1) X_k,  1<=k<m,
    O_m = Z_1 ... Z_m.

The exact adjoint generator satisfies

    L_+(O_k) = 2J O_(k-1) - 2J O_(k+1) - gamma k O_k,

omitting nonexistent endpoint terms. The span is reducing: it is invariant under the Hamiltonian commutator and the diagonal Pauli noise separately, as is its Hilbert-Schmidt orthogonal complement.

Partition the chain among any number of coarse blocks, and put a centered all-zero computational projector factor on the measured chain sites in each block:

    M = product_B [2^{|B|}|0...0><0...0|_B-I_B].

Unused sites in a larger square block carry identities. In the invariant span, M has coefficient one on O_m and zero on every O_k with k<m, because those strings contain X. Its evolved single-site X_1 coefficient is consequently

    c_m(t) = [exp(t A)]_(1,m),

where A is tridiagonal with diagonal -k, upper diagonal 1/8 and lower diagonal -1/8.

Each Gershgorin disk has radius at most 1/4 around its integer center -k. The disks are disjoint and each contains exactly one eigenvalue. Since A is real and the disks have real centers, a nonreal eigenvalue and its conjugate would occupy the same disk; therefore all eigenvalues are distinct and real.

For these eigenvalues lambda_1,...,lambda_m, the endpoint resolvent, or the elementary tridiagonal determinant formula, gives

    c_m(t) = (2J)^(m-1) exp(t dot)[lambda_1,...,lambda_m],

where the bracket is the divided difference. The Hermite-Genocchi integral representation is strictly positive for exp(t x) when t>0 and all nodes are real. In particular,

    (2Jt)^(m-1) exp[-(gamma m+4J)t]/(m-1)!
      <= c_m(t)
      <= (2Jt)^(m-1) exp[-(gamma-4J)t]/(m-1)!.

Thus c_m(t)>0 at every t>0, including any proposed long middle interval. Choosing enough coarse blocks makes weight one smaller than any claimed constant fraction of the block count.

This example falsifies only an exact zero-leakage invariant. The coefficient is very small and is entirely compatible with a useful exponential leakage bound. It is not a hardness example or a counterexample to high-noise simulation. A product input polarized along X on site1 and maximally mixed elsewhere also makes this coefficient a physical expectation of M.

`check_chain.py` verifies the full Pauli-generator identities for two through six sites and evaluates the tridiagonal exponential at 100-digit precision for m=4,8,16,32 and physical times 0.1,1,4. All coefficients are positive and satisfy the proved bounds. The all-time claim comes from the analytic proof, not finite numerical tests.

## B. Source hypotheses and the valid erasure replacement

The circuit source uses finite backward light cones to retain a nonzero Pauli factor in a fixed fraction of separated coarse blocks. This exact property is unavailable in continuous time. The substantive alternative is the product nested-commutator estimate in McDonough, Yin, Lucas and Zhang, Theorem4.4/Corollary4.9, with time-dependent extension in Section4.4. Its hypotheses require disjoint factor-separated buffers, probes inside their cores, a dual test observable outside the buffers, bounded interaction norm and degree, and a time smaller than the buffer-distance/interaction-speed bound.

Sources checked:
- https://arxiv.org/html/2610.00548v1
- https://arxiv.org/html/2502.02652v2

The following audit concerns `REPORT.md`.

### Noise extension

Every-site maximally mixed replacement is exactly a mixture of local Pauli jumps with rates gamma/4 per axis. In each history, on-site Pauli conjugations preserve all interaction supports and norms. Moving them to a toggling frame leaves a time-dependent local Hamiltonian to which the source estimate applies uniformly. The terminal Pauli product only conjugates the probes within their existing supports. Averaging does not introduce a jump-count prefactor.

This extension depends on the actual random-unitary noise model. It is not an automatic statement about nonunital noise: for example amplitude damping can turn a traceless local Z into an identity contribution even with H=0. Uniform every-site noise is separately essential to the later weight-dissipation/hypercontractive step.

### Erasure duality

Use normalized trace tau and E_C for tracing out C and inserting its maximally mixed identity. Let Q_C=Id-E_C and assume Q_(S_j)M=M on q selected cores. Trace-norm duality tests E_(union B_j) Phi_t(M) against operators supported outside the buffers.

Move the Q projections to the dual evolved test observable. Each Q_S is the Haar average of [X,U_S]U_S^dagger. Since core supports are disjoint, their unitary probes commute; the product of q such differences is an averaged nested commutator times a unitary. Applying the source bound and normalized trace/operator-norm duality proves

    ||E_(union B_j) Phi_t(M)||_(1,tau)
       <= delta(t)^q ||M||_(1,tau).

There is no missing dimension factor or positivity assumption on M. Both Hamiltonian signs required by the adjoint have the same source bounds.

### Low-weight counting

Suppose m>=g/chi disjoint buffers can be selected and N<=Vg. A Pauli of weight below ceil(m/2) misses more than m/2 buffers. Its coefficient is bounded by 2^g delta^(m/2), using the erasure estimate and the initial normalized trace norm. For delta<=1, the exponent weakening is valid.

A direct counting proof avoids integer-floor ambiguity. Put z=m/(6N)<=1. The number of strings of weight at most m/2 is bounded by

    z^(-m/2)(1+3z)^N <= (6eN/m)^(m/2).

Taking the square root of the count yields exactly the reported low-sector Hilbert-Schmidt bound. The passage from m to g/chi needs the combined base (6e chi V)^(1/4)delta^(1/2)<=1; this condition is explicit in the corrected report.

### Hypercontractive composition and geometry

The initial normalized (1+1/a)-norm is at most 3^g, where a bounds measured sites per core. Hamiltonian evolution contributes zero to the squared 2-norm derivative. Every-site replacement contributes exactly -2gamma times the Pauli-weight moment. A uniform low-sector error E therefore gives

    d ||O||_2^2/dt <= -2gamma k (||O||_2^2-E^2).

The middle-interval integration, final 2-to-(1+V) hypercontractivity, and conversion from normalized Schatten norm to operator norm reproduce the report's factors6 and4. This norm use of a Trotter limit is not a claim about a uniform circuit-sampling runtime.

The square-lattice choice also checks out: r-by-r cores enlarged to side3r have volume at most9r^2; a four-color choice on each axis leaves at least g/16 separated buffers. Boundary cardinalities are at most12r and4r, giving delta<=96r^2(2eh Delta T/r)^r. Longer-range interactions require redoing these constants.

The rational scalar conditions imply both required analytic inequalities. In particular e<3 makes the propagation factor below1/2, while

    r/2 >= 9+3log_2(r)+32(c+3)

is sufficient for the leakage condition, and the physical-time condition pays both hypercontractive intervals plus the damping interval. The report's large-r choices satisfy these inequalities. The resulting time and radius depend on the physical numerical ratio h/gamma and locality, not on a microscopic time step.

## C. What is still not earned

The finite-patch estimate explicitly needs N<=Vg. For the full surrounding system, replacing N by n defeats the local dimension/counting factors. Separately evolving a patch discards weak but nonzero exterior influences; those patch channels need not be marginals of one global channel.

Exponential support leakage does not itself give exact factorization between compatible polymers. Nor does it provide an error bound for log probabilities, a zero-free region, or conditional kernels at rare prefixes. Those require a connected-history/quasi-local activity construction with a paid summability and normalization proof. Dividing an additive local truncation estimate by a rare marginal is still invalid.

If that global step were established with g=O(log(n/epsilon)), direct patch computations would be polynomial for fixed V, but with an exponent proportional to V. At the report's illustrative h/gamma=1, degree5, c=6, V already exceeds9 billion. Neither this statement nor the explicit counterexample is a practical sampler or a completed general-B result.

## Review status

The quantitative many-region support-erasure and finite-patch norm lemma are independently supported. The hard-support witness is separately proved and checked. The global connected-activity/relative-normalization step remains an identified mathematical blocker, not an implementation delay.
