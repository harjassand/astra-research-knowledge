"""Independent finite-dimensional check of exact all-time support leakage."""
import numpy as np, mpmath as mp, json,pathlib
mp.mp.dps=100
I=np.eye(2,dtype=complex);X=np.array([[0,1],[1,0]],complex);Y=np.array([[0,-1j],[1j,0]],complex);Z=np.diag([1,-1]).astype(complex)
def kron(xs):
 out=np.array([[1]],complex)
 for a in xs:out=np.kron(out,a)
 return out
checks=[]
for m in range(2,7):
 ops=[kron([Z if j<k else X if j==k else I for j in range(m)])for k in range(m-1)]+[kron([Z]*m)]
 H=sum(-1/16*kron([Y if i==j else (Z if j==m-2 else X)if i==j+1 else I for i in range(m)])for j in range(m-1))
 maximum=0
 for k,O in enumerate(ops):
  v=1j*(H@O-O@H)-(k+1)*O
  wanted=-(k+1)*O
  if k>0:wanted=wanted+1/8*ops[k-1]
  if k<m-1:wanted=wanted-1/8*ops[k+1]
  maximum=max(maximum,float(abs(v-wanted).max()))
 assert maximum==0;checks.append({'sites':m,'full_operator_generator_max_residual':maximum})
rows=[]
for m in [4,8,16,32]:
 A=mp.matrix(m)
 for k in range(m):
  A[k,k]=-(k+1)
  if k<m-1:A[k,k+1]=mp.mpf(1)/8;A[k+1,k]=-mp.mpf(1)/8
 for t in [mp.mpf('0.1'),mp.mpf(1),mp.mpf(4)]:
  c=mp.expm(t*A)[0,m-1];lo=(t/8)**(m-1)/mp.factorial(m-1)*mp.exp(-(m+mp.mpf(1)/4)*t);hi=(t/8)**(m-1)/mp.factorial(m-1)*mp.exp(-(1-mp.mpf(1)/4)*t)
  assert 0<lo<=c<=hi;rows.append({'sites':m,'physical_time':str(t),'single_site_coefficient':mp.nstr(c,45),'proved_lower_bound':mp.nstr(lo,30),'proved_upper_bound':mp.nstr(hi,30)})
r={'scope':'Exact Pauli-matrix identities in binary-exact floating arithmetic; high-precision exponential diagnostics. All-time nonzero theorem is proved separately via real eigenvalues and positive divided differences.','gamma':1,'J':'1/16','generator_checks':checks,'coefficient_checks':rows}
pathlib.Path(__file__).with_name('chain_results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
