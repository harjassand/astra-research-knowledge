"""Exact combinatorial check of a causal path's free-interval language.
Diamond-with-cross-edge graph exercises alternate arrivals and cycles.
Compares the geometric earliest-parent forest to the cut-alphabet language,
without final-commutator cancellations. All local Pauli noise letters are
admitted in every interval and are deleted before the geometric classifier.
"""
from itertools import product
import json
from pathlib import Path
edges=[frozenset(x) for x in [(0,1),(1,3),(0,2),(2,3),(1,2)]]
root=frozenset([0]); target=frozenset([3])
def classify(word):
    previous=[(root,-1)];parent={};hit=None;first={}
    for pos,e in enumerate(word):
        X=edges[e]
        candidates=[(Y,i) for Y,i in previous if X&Y]
        if not candidates:return None
        if not any(X<=Y for Y,_ in previous):
            parent[e]=candidates[0][1];first[e]=pos
        if hit is None and X&target:hit=e
        previous.append((X,e))
    if hit is None:return None
    rev=[]; e=hit
    while e!=-1:
        rev.append(e); e=parent[e]
    return tuple(reversed(rev))
def allowed(path,j):
    if j==len(path):bad=frozenset()
    elif j==len(path)-1:bad=target
    else:bad=frozenset.union(*(edges[e] for e in path[j+1:]))
    return frozenset(e for e,X in enumerate(edges) if not X&bad)
def accepts(path,word):
    j=0
    for e in word:
        # A skeleton factor is never in its preceding allowed alphabet,
        # so the placement is unique rather than an uncharged multiplicity.
        A=allowed(path,j)
        if j<len(path):assert path[j] not in A
        if e in A:continue
        if j<len(path) and e==path[j]:j+=1
        else:return False
    return j==len(path)
# Discover all possible irreducible paths, then exhaust every H-word <=8.
paths=set()
for length in range(1,6):
    for word in product(range(5),repeat=length):
        c=classify(word)
        if c:paths.add(c)
counts={'words':0,'geometrically_causal':0,'noncausal_words_accepted':0,'multiply_accepted_words':0}
for length in range(9):
    for word in product(range(5),repeat=length):
        c=classify(word); acc=[p for p in paths if accepts(p,word)]
        counts['words']+=1
        if c:
            counts['geometrically_causal']+=1
            assert acc==[c] or (len(acc)==1 and acc[0]==c),(word,c,acc)
        elif acc:
            # Source allows disconnected prefixes whose operator product is
            # identically zero for support reasons. They are not a bijection
            # of formal words, but are harmless independently of final probes.
            counts['noncausal_words_accepted']+=1
            seen=set(root); zero=False
            for e in word:
                if edges[e].isdisjoint(seen):zero=True;break
                seen.update(edges[e])
            assert zero,(word,acc)
        if len(acc)>1:counts['multiply_accepted_words']+=1
out={'graph_edges':[sorted(e) for e in edges],'source':sorted(root),'target':sorted(target),'irreducible_paths':sorted(paths),'max_word_length':8,**counts,'status':'All assertions passed. Allowed-alphabet bijection holds modulo support-zero words, without invoking a terminal commutator.'}
Path(__file__).with_name('forest_language_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
