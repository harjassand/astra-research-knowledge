"""Exhaustive check of the independently derived first-vertex-discovery repair.
Uses the 2x3 ladder, including the middle and target vertical edges. Target
is a multi-site connected region. No source final-commutator identity used.
"""
from itertools import product
from pathlib import Path
import json
edges=[frozenset(x) for x in [(0,1),(1,2),(3,4),(4,5),(1,4),(2,5)]]
root=frozenset([0,3]); target=frozenset([2,5])
def classify(word):
 seen=set(root);parent={};hit=None
 for e in word:
  X=edges[e]
  if X.isdisjoint(seen):return None
  new=X-seen
  if new:
   assert len(new)==1
   x=next(iter(new));old=next(iter(X-new));parent[x]=(old,e)
   if hit is None and x in target:hit=x
   seen.add(x)
 if hit is None:return None
 out=[];x=hit
 while x not in root:
  old,e=parent[x];out.append((e,x));x=old
 return tuple(reversed(out))
def allowed(path,j):
 bad=({x for _,x in path[j:]}|set(target)) if j<len(path) else set()
 return frozenset(e for e,X in enumerate(edges) if X.isdisjoint(bad))
def accepts(path,word):
 j=0
 for e in word:
  A=allowed(path,j)
  if j<len(path):assert path[j][0] not in A
  if e in A:continue
  if j<len(path) and e==path[j][0]:j+=1
  else:return False
 return j==len(path)
paths=set()
for length in range(5):
 for word in product(range(6),repeat=length):
  c=classify(word)
  if c:paths.add(c)
counts={'words':0,'causal_words':0,'geometric_zero_extras':0,'multiple_causal_acceptances':0}
for length in range(8):
 for word in product(range(6),repeat=length):
  c=classify(word);a=[p for p in paths if accepts(p,word)];counts['words']+=1
  if c:
   counts['causal_words']+=1
   assert len(a)==1 and a[0]==c,(word,c,a)
  elif a:
   counts['geometric_zero_extras']+=1
   seen=set(root);zero=False
   for e in word:
    if edges[e].isdisjoint(seen):zero=True;break
    seen.update(edges[e])
   assert zero,(word,a)
  if c and len(a)>1:counts['multiple_causal_acceptances']+=1
out={'physical_graph':'2x3 ladder, qubit3*y+x, root is left column and target is right column','edges':[sorted(x) for x in edges],'root':sorted(root),'target':sorted(target),'retained_paths_edge_and_new_vertex':sorted(paths),'max_word_length':7,**counts,'status':'Every causal word has exactly one first-discovery path language. The target-inclusive future-vertex restriction handles alternative routes, cycles and a multi-site target.'}
Path(__file__).with_name('vertex_discovery_repair_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
