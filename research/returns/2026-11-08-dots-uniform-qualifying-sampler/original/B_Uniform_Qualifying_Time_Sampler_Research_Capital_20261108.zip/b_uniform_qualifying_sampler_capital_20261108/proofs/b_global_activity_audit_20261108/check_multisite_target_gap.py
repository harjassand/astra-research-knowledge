"""Exact counterexample to the literal multi-site target cut alphabet.
2x4 nearest-neighbor lattice; target is its rightmost 2x2 interface strip.
One central switch controls the two horizontal edges inside that strip.
Full replacement noise is retained. The proposed corrected alphabet is
also checked, but finite success is not a proof on arbitrary graphs.
"""
from collections import defaultdict
from fractions import Fraction
import json, math
from pathlib import Path
N=8
phase={(1,2):1j,(2,3):1j,(3,1):1j,(2,1):-1j,(3,2):-1j,(1,3):-1j}
def mul(p,q):
 z=1;out=[]
 for a,b in zip(p,q):
  if a==0:out.append(b)
  elif b==0:out.append(a)
  elif a==b:out.append(0)
  else:z*=phase[a,b];out.append(6-a-b)
 return z,tuple(out)
def pstr(terms):
 p=[0]*N
 for i,a in terms:p[i]=a
 return tuple(p)
H=[pstr([(0,1),(1,1)]),pstr([(1,2),(2,1)]),pstr([(2,2),(3,1)]),
   pstr([(4,1),(5,1)]),pstr([(5,2),(6,1)]),pstr([(6,2),(7,1)])]
support=[set(i for i,x in enumerate(h) if x) for h in H]
label=[0,0,1,0,0,1]
S={2,3,6,7};paths=[(0,1),(3,4)]
start={(pstr([(0,3),(4,3)]),0):1}
def add(a,b):
 out=a.copy()
 for k,v in b.items():
  out[k]=out.get(k,0)+v
  if not out[k]:del out[k]
 return out
def comm(v,e):
 out=defaultdict(int)
 for (p,mask),coef in v.items():
  a,q=mul(H[e],p);b,_=mul(p,H[e]);c=1j*(a-b)
  assert c.imag==0
  if c:out[q,mask|label[e]]+=coef*int(c.real)
 return dict(out)
def gen(v,allowed):
 out={k:-sum(x!=0 for x in k[0])*v for k,v in v.items()}
 for e in allowed:out=add(out,comm(v,e))
 return {k:v for k,v in out.items() if v}
def proj(v):return{k:c for k,c in v.items() if k[1] and c}
def alph(path,j,repair):
 if j==len(path):bad=set()
 elif j==len(path)-1:bad=set(S)
 else:bad=set().union(*(support[e] for e in path[j+1:]))
 if repair and j<len(path):bad|=S
 return [e for e in range(len(H)) if support[e].isdisjoint(bad)]
def skeleton(path,upto,repair):
 dp=[[{} for _ in range(upto+1)] for _ in range(len(path)+1)]
 dp[0][0]=start
 for n in range(1,upto+1):dp[0][n]=gen(dp[0][n-1],alph(path,0,repair))
 for j in range(1,len(path)+1):
  for n in range(j,upto+1):
   dp[j][n]=add(comm(dp[j-1][n-1],path[j-1]),gen(dp[j][n-1],alph(path,j,repair)))
 return dp[-1]
upto=12
full=[start]
for n in range(upto):full.append(gen(full[-1],range(len(H))))
results={}
for repair in [False,True]:
 rhs=[{} for _ in range(upto+1)]
 for path in paths:rhs=[add(a,b) for a,b in zip(rhs,skeleton(path,upto,repair))]
 mismatches=[]
 for n in range(upto+1):
  a,b=proj(full[n]),proj(rhs[n])
  if a!=b:
   examples=[]
   for key in sorted(a.keys()|b.keys()):
    if a.get(key,0)!=b.get(key,0):
     examples.append({'pauli':''.join('IXYZ'[x] for x in key[0]),'true_integer_coefficient':a.get(key,0),'resummed_integer_coefficient':b.get(key,0),'true_Taylor_coefficient':str(Fraction(a.get(key,0),math.factorial(n))),'resummed_Taylor_coefficient':str(Fraction(b.get(key,0),math.factorial(n)))})
   mismatches.append({'order':n,'examples':examples[:4]})
 results['repaired' if repair else 'literal_source_tail_only']={'orders_checked':upto+1,'first_mismatch':mismatches[0] if mismatches else None,'all_orders_equal':not mismatches}
assert results['literal_source_tail_only']['first_mismatch']['order']==5
assert results['repaired']['all_orders_equal']
out={'geometry':'2 rows x4 columns, physical qubit4*y+x','source_qubits':[0,4],'target_strip':sorted(S),'one_shared_switch_on_edge_indices':[2,5],'Hamiltonian_Paulis':[''.join('IXYZ'[x] for x in h) for h in H],'gamma':1,'source_observable':'ZIIIZIII','target_paths':paths,'diagnostic':results,'interpretation':'Literal pre-arrival tail alphabets double count histories that first enter another site of the multi-site target. Adding the entire target strip to every pre-arrival forbidden set fixes this finite example. The desired norm inequality is not disproved.'}
Path(__file__).with_name('multisite_target_gap_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
