"""Independent exact-integer Taylor check of full-noise causal-forest lift.
Not a proof for arbitrary geometries; checks two length-two disjoint-buffer
paths with every-site replacement, all interleavings, and return histories.
"""
import itertools, json, math
from collections import defaultdict
from fractions import Fraction
from pathlib import Path
# Pauli 0,I;1,X;2,Y;3,Z. Product phase in {1,-1,i,-i}.
phase={(1,2):1j,(2,3):1j,(3,1):1j,(2,1):-1j,(3,2):-1j,(1,3):-1j}
def mul(p,q):
    z=1; out=[]
    for a,b in zip(p,q):
        if a==0: out.append(b)
        elif b==0: out.append(a)
        elif a==b: out.append(0)
        else: z*=phase[a,b];out.append(6-a-b)
    return z,tuple(out)
def add(a,b):
    out=a.copy()
    for k,v in b.items():
        out[k]=out.get(k,0)+v
        if not out[k]:del out[k]
    return out
N=5
H=[(1,1,0,0,0),(0,2,1,0,0),(1,0,0,1,0),(0,0,0,2,1)]
support=[{i for i,p in enumerate(h) if p} for h in H]
paths=[(0,1),(2,3)]
targets=[{2},{4}]
start={((3,0,0,0,0),0):1}
def comm(v,e):
    out=defaultdict(int)
    for (p,mask),coef in v.items():
        a,q=mul(H[e],p);b,_=mul(p,H[e]);c=1j*(a-b)
        assert abs(c.imag)<1e-10
        if c:out[q,mask|1<<e]+=coef*int(c.real)
    return {k:v for k,v in out.items() if v}
def gen(v,allowed):
    out={k:-sum(p!=0 for p in k[0])*c for k,c in v.items()}
    for e in allowed:out=add(out,comm(v,e))
    return {k:v for k,v in out.items() if v}
def project(v):return {k:c for k,c in v.items() if k[1]==15}
def forbidden(progress):
    ans=set()
    for j,k in enumerate(progress):
        if k==0:ans|=support[paths[j][1]]
        elif k==1:ans|=targets[j]
    return ans
orders=[p for p in itertools.permutations(range(4)) if p.index(0)<p.index(1) and p.index(2)<p.index(3)]
def stage_alphabets(order):
    prog=[0,0];ans=[]
    for i in range(5):
        bad=forbidden(prog)
        ans.append(tuple(e for e in range(4) if support[e].isdisjoint(bad)))
        if i<4:prog[0 if order[i]<2 else 1]+=1
    return ans
# Recurrence sums all compositions of n-4 reducible generator letters
# among the five intervals, keeping each skeleton letter exactly once.
def skeleton_coefficients(order, upto):
    alph=stage_alphabets(order)
    dp=[[{} for _ in range(upto+1)] for _ in range(5)]
    dp[0][0]=start
    for n in range(1,upto+1):dp[0][n]=gen(dp[0][n-1],alph[0])
    for j in range(1,5):
        for n in range(j,upto+1):
            dp[j][n]=add(comm(dp[j-1][n-1],order[j-1]),gen(dp[j][n-1],alph[j]))
    return dp[4]
upto=12
full=[start]
for n in range(upto):full.append(gen(full[-1],range(4)))
rhs=[{} for _ in range(upto+1)]
for order in orders:
    coeff=skeleton_coefficients(order,upto)
    rhs=[add(x,y) for x,y in zip(rhs,coeff)]
checks=[]
for n in range(upto+1):
    a,b=project(full[n]),project(rhs[n])
    assert a==b,(n,a,b)
    checks.append({'order':n,'nonzero_all_label_paulis':len(a),'max_integer_coefficient':max(map(abs,a.values()),default=0)})
return_series={str(n):str(Fraction(full[n].get(((3,0,0,0,0),15),0),math.factorial(n))) for n in range(upto+1) if full[n].get(((3,0,0,0,0),15),0)}
# If a putative proof discards every word ending outside both targets,
# these nonzero source-only coefficients would be omitted.
assert return_series and min(map(int,return_series))==8
# Pauli-diagonal noise means the no-noise and full-noise first nonzero
# term coincide, but noise genuinely changes subsequent coefficients.
# Exact multiset cluster coefficient check independent implementation.
def connected_recurrence(n,edges):
    z=[1]*(1<<n); c=[0]*(1<<n)
    for W in range(1,1<<n):
        z[W]=int(not any(W>>a&1 and W>>b&1 for a,b in edges))
        root=W&-W;total=z[W]; S=(W-1)&W
        while S:
            if S&root:total-=c[S]*z[W^S]
            S=(S-1)&W
        c[W]=total
    return c[-1]
def connected_brute(n,edges):
    out=0
    for mask in range(1<<len(edges)):
        seen={0}
        changed=True
        while changed:
            changed=False
            for k,(a,b) in enumerate(edges):
                if mask>>k&1 and ((a in seen) != (b in seen)):
                    seen|={a,b};changed=True
        if len(seen)==n:out+=(-1)**mask.bit_count()
    return out
count=0
for n in range(1,6):
    possible=list(itertools.combinations(range(n),2))
    for mask in range(1<<len(possible)):
        edges=[e for k,e in enumerate(possible) if mask>>k&1]
        assert connected_recurrence(n,edges)==connected_brute(n,edges)
        count+=1
out={'purpose':'Finite stress test, not a general source-extension proof. Exact integer Pauli algebra; gamma=h=1.','physical_qubits':N,'paths':paths,'ordered_skeletons':len(orders),'Taylor_identity_checks':checks,'source_only_roundtrip_coefficients_in_time_series':return_series,'connected_graph_recurrence_graphs_checked':count,'status':'All assertions passed; retaining visited-label roundtrips is essential.'}
Path(__file__).with_name('roundtrip_forest_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
