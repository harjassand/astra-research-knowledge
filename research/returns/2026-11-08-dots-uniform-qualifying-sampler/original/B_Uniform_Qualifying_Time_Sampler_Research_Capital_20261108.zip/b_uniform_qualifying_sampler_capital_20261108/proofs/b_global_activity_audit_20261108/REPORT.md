# Global activities and relative normalization: independent continuation

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

8 November 2026. This follows the verified finite-patch simultaneous-erasure lemma. It identifies an exact local-to-global algebraic operation, proves two distinct limitations, and specifies a stronger spatial estimate that would complete the analytic normalization step. It does not establish that estimate for the target noisy Hamiltonian family and does not claim a general sampler.

## Useful findings

- **Exact algebra exists:** ordinary joint cumulants turn arbitrary global subset moments into an exact hard-core polymer partition function. Exact finite light cones are not required for this identity.
- **The missing estimate is substantive:** small moments alone do not control these activities or the zero-free region. A strictly positive classical distribution has arbitrarily strong exponential moment decay and partition-function zeros arbitrarily close to the expansion origin.
- **The physical factorization shortcut is false:** a static nearest-neighbor XY chain, a product input and every-site replacement noise produce nonzero connected correlations between arbitrarily separated endpoint measurements. Those effects are small, but not zero.
- **A precise sufficient target is available:** a uniform, trace-normalized spatial tree bound on cumulants would imply a Kotecky-Preiss activity bound. The verified patch lemma has not yet supplied that tree bound, effective connected-activity enumeration or relative normalization.

## 1. The exact global algebra

For a fixed marginal assignment, let M_i be the centered measurement factor of coarse block i. The M_i commute because their supports are disjoint. Let

    m(S)=Tr[rho_out product_(i in S) M_i],  m(empty)=1.

After extracting the usual 2^(-number of measured qubits), the target marginal is

    Xi = sum_(S subset blocks) m(S).

These must be moments of the **same full output state**. Independently truncated patch evolutions are not interchangeable with them.

Define the set cumulant

    kappa(S)=sum_(partitions pi of S)
              (-1)^(|pi|-1)(|pi|-1)! product_(B in pi) m(B).

Moment-cumulant inversion gives

    m(S)=sum_(partitions pi of S) product_(B in pi) kappa(B).

Summing over S yields the exact identity

    Xi=sum_(collections of pairwise disjoint nonempty sets)
          product_(S in collection) kappa(S).

Thus all nonempty subsets can be regarded as polymers, with incompatibility defined by overlap alone. The identity is valid for real signed cumulants; positivity of the probability distribution does not make all activities positive. For a finite-cone circuit, many cumulants vanish or admit local control. For continuous time, nonlocal subsets generally remain.

This operation repairs the exact factorization algebra, but it does not prove convergence. It replaces a bounded-degree collection of connected polymers by potentially every subset, and requires spatial summability of their signed connected weights.

### Finite-bit/accounting distinction

Naively listing all partitions costs a Bell number, but that is not an unavoidable computational lower bound. Fix a root v in S. The recurrence

    kappa(S)=m(S)-sum_(proper B subset S, v in B) kappa(B)m(S minus B)

computes all cumulants within a k-site set in O(3^k) arithmetic from its 2^k moments. For k=O(log n), this overhead is polynomial.

Cumulant subtraction can amplify moment errors by exp(O(k log k)) under crude absolute bounds. Paying O(k log k) additional precision bits remains polynomial. The serious unresolved costs are obtaining the correct **global** moments/activities locally and enumerating only the important subsets with a rigorous tail, not the existence of a finite-precision implementation of the combinatorial recurrence.

## 2. Moment decay does not imply relative/log normalization

This is a logical counterexample to an inference from moment bounds alone, **not** a counterexample satisfying the product-input finite-time local-Hamiltonian assumptions of B.

Draw a single fair latent sign L. Conditional on L, let n binary spins Z_i be independent with E[Z_i|L]=aL, where 0<a<1. Equivalently the state is

    rho = (1/2) tensor_i (I+aZ_i)/2
         +(1/2) tensor_i (I-aZ_i)/2.

It is a mixture of product states and every output probability is strictly positive. Nevertheless its latent sign is global. For every nonempty subset,

    m(S)=a^|S| if |S| is even, and 0 otherwise.

Thus |m(S)|<=exp(-c|S|) for arbitrarily large fixed c, by taking a small enough. Already kappa({i,j})=a^2 at every separation, so the activity mass incident on one site grows as (n-1)a^2. Higher even cumulants alternate signs and grow factorially: divided by a^k the first values are 1,-2,16,-272 at orders2,4,6,8.

Introduce a common source z. The exact generating partition function is

    Xi(z)=(1/2)[(1+az)^n+(1-az)^n].

Its nearest imaginary zero is exactly

    z_0 = i tan(pi/(2n))/a.

Therefore the zero-free radius tends to zero as n grows, despite arbitrarily strong exponential subset-moment decay and strict positivity at all real output configurations. The logarithm's expansion about zero cannot be evaluated at z=1 merely from these moment bounds.

For example a=1/512, n=4096 gives |z_0| approximately0.19635. This exceeds six units of exponential decay per measured site, yet the relevant logarithmic series still has a singularity inside the unit disk. The distribution is easy to sample through its latent variable; the counterexample targets this particular normalization inference, not classical sampling itself.

`check_cumulants.py` verifies the exact disjoint-polymer identity with rational arithmetic, reproduces the cumulant signs, and checks the analytic zero at high precision. The exact zero formula, not a floating residual, proves the obstruction.

## 3. Exact factorization also fails inside the physical target

Let d+1 qubits form a chain, with rational nearest-neighbor Hamiltonian

    H=(1/2) sum_(j=1)^d J_j (X_j X_(j+1)+Y_j Y_(j+1)).

Take product input |1,0,...,0>, and the stipulated every-site replacement noise with any fixed gamma>0. Define the connected endpoint correlation

    C(t)=<Z_1 Z_(d+1)>_t-<Z_1>_t<Z_(d+1)>_t.

This analytic function is even in each individual J_j. To see this, conjugate all sites on one side of edge j by Z: only that edge coupling changes sign, while the initial state, endpoint observables and noise remain unchanged. Also, if any J_j=0, the chain disconnects, the product input/noise factorize, and C(t)=0. Consequently its Taylor series is divisible by product_j J_j^2.

The first possible time order is2d. No noise insertion contributes at that order, because each would add another generator factor. In the noiseless one-excitation walk, the endpoint transfer amplitude starts as (-it)^d product_j J_j/d!, and the connected Z correlation is minus four times the product of endpoint occupation probabilities. Hence

    C(t) = -4 [product_j J_j^2] t^(2d)/(d!)^2
           + O(t^(2d+1)).

It is nonzero for sufficiently small positive time at every separation d. Since it is analytic and not identically zero, it also cannot vanish throughout any later open time interval. Exact factorization cannot be recovered simply by declaring any finite collection of sufficiently distant coarse blocks compatible; an appropriate chain can exceed the buffer range.

This example remains within static two-body local Hamiltonians, product inputs and every-site replacement noise. It is not a hardness result and does not exclude quantitatively controlled approximate factorization. It shows why the omitted connected contribution must be represented or rigorously budgeted.

`check_physical_factorization.py` verifies the leading coefficient exactly for distances1,2,3, obtaining -4,-1,-1/9 at J=gamma=1. For three sites at time1, the connected endpoint correlation is about-0.0355364, and the endpoint law has TV distance about0.0177682 from the product of its actual one-site marginals. The last figures are floating diagnostics; the short-time nonfactorization is analytic.

## 4. A concrete sufficient replacement target

One useful next theorem would bound the exact global cumulants, uniformly over all marginal assignments, by

    |kappa(S)| <= eta^|S|
                 sum_(trees T on S) product_(ij in T) f(i,j),
    F=sup_i sum_(j!=i) f(i,j) < infinity,

with positive f carrying spatial decay and eta sufficiently small. Singleton tree weight is one. Unlike bare moment decay, this explicitly controls connected spatial organization.

Indeed, rooting at i and summing over all sets of size k, a tree/leaf summation gives

    sum_(S containing i, |S|=k) |kappa(S)| e^(lambda k)
      <= eta^k e^(lambda k)
         [k^(k-2)/(k-1)!] F^(k-1).

Using k^(k-2)/(k-1)!<=e^(k-1) gives

    sup_i sum_(S containing i) |kappa(S)|e^(lambda|S|)
      <= eta e^lambda/[1-e eta e^lambda F].

When the denominator is positive and the last expression is at most a, overlap incompatibility implies the Kotecky-Preiss bound with a(S)=a|S|, provided lambda>=a. Taking lambda>a leaves a tail margin. For instance lambda=2,a=1 has a simple sufficient smallness condition eta(e^2+e^3F)<1.

This specifies a genuine analytic normalization target. It is not proved by the existing simultaneous-erasure lemma: erasure controls a single observable's support loss, whereas the cumulants require cancellation among many global moments and connected spatial dependence. An algorithm would additionally need paid evaluation and enumeration/truncation of the spatially important activities, with the bound uniform for every requested prefix. A summable f without an effective tail/computation guarantee is not by itself a polynomial sampler.

For the standard polymer/cluster-expansion context see the primary noisy-circuit paper, https://arxiv.org/html/2610.00548v1. The algebra and counterexamples above are spelled out independently rather than imported as a sampling theorem.

## 5. Current boundary

The finite-patch norm estimate is preserved. The exact cumulant identity resolves the purely algebraic absence of strict compatible-component factorization. What remains missing is a dimension-independent, trace-normalized spatial activity bound, along with efficient computation and summable truncation, strong enough to control log marginals of the actual global dynamics.

Independent patch weights can have a well-behaved small partition function without representing the physical marginal at all. Conversely, positive physical probabilities and small global moments need not grant the zero-free region used by a cluster expansion. Neither mistake can be repaired by clipping negative approximations or dividing an additive error by a rare prefix probability.

No full-output general-B sampler, worst-case polynomial theorem, practical advantage or historical-first claim is earned here.

## 6. Stronger exact local-to-global operation: switch whole block interfaces

The construction switches coarse-block Hamiltonian interfaces. Independent algebraic review confirms this gives an exact representation with spatially connected polymers, avoiding the all-subset compatibility problem of ordinary cumulants.

Let E be the bounded-degree coarse interface graph. Group all Hamiltonian interactions crossing a given interface e into V_e; keep every internal block Hamiltonian and all original on-site noise. For A subset E let f_A be the normalized target marginal under the Hamiltonian with only interfaces A switched on. Let b_v be the normalized isolated-block marginal and B_0=product_v b_v. Define F_A=f_A/B_0, so F_empty=1.

With product input, retained local noise and a product measurement, dynamics with interfaces A factorizes across the vertex components of A. Therefore F_A is the product of component factors; isolated blocks cancel against B_0.

Now define edge-set Möbius differences

    Delta_A=sum_(B subset A) (-1)^(|A|-|B|) F_B.

If A has vertex-disjoint connected edge components A_1,...,A_j, the subset sum factors and

    Delta_A=product_i Delta_(A_i).

Möbius inversion then yields

    f_E=B_0 sum_(pairwise vertex-disjoint connected edge sets)
                   product_C Delta_C.

This is an exact global connected-edge polymer partition function for the actual Hamiltonian. The activities are calculated using disconnected exterior interfaces, but the Möbius inversion, rather than an unjustified light-cone identification, restores their exact global meaning. Activities can have either sign.

### Normalization and computability

For a measured block, b_v=1+Tr[rho_iso M_v]. The one-block norm estimate at the chosen physical time implies |b_v-1|<=e^(-c), uniformly over the selected local outcome. Unmeasured blocks have b_v=1. Consequently the denominator for a connected v-block activity costs at most (1-e^(-c))^(-v), which is exp(O(v)), not exp(O(block volume times v)). It does not divide by the tiny actual full-prefix probability.

The full marginal has logarithm

    -(number of measured qubits) ln2
      + sum_v log b_v + log Z_interfaces.

The isolated factors are positive and can be approximated locally with paid precision. A connected edge set has O(v) interfaces on a bounded-degree coarse lattice. Its Möbius sum has exp(O(v)) terms, each simulated on v blocks, with scalar work exp(O(r^2 v)) in two dimensions plus charged numerical-action/bit factors. Thus for fixed r and v=O(log(n/epsilon)), activity evaluation is formally polynomial. No sampling theorem follows until a truncation-size bound is proved.

### A genuine proof hazard in switch-register bookkeeping

To represent Delta_C as a Fourier coefficient, one can attach conserved classical switch bits. Two seemingly interchangeable implementations have different costs:

1. One independent bit per physical boundary edge preserves the physical interaction graph but creates O(r v) switch bits in two dimensions. Fourier extraction and undamped-register norm factors can then reintroduce exp(O(r v)), not exp(O(v)).
2. One shared bit per whole coarse interface uses only O(v) bits, but that register couples to O(r) physical terms. Applying the cited factor-graph LR theorem literally raises its maximum degree to O(r), and the interface term also has macroscopic support if grouped as one interaction. The physical h Delta scale cannot be left unchanged without an argument.

Because these are commuting classical labels, they need not truly mediate physical propagation: terms on disjoint physical sites sharing only a classical Z label still commute. A switch-aware conditional physical-path proof may recover the desired constants. But this is an additional lemma, not a direct application of the existing bounded-degree theorem. It is where the proposed hypercontractive connected-history resummation needs independent justification.

The updated boundary is therefore more precise: **exact connected compatibility and local baseline normalization now have a valid algebraic construction; the summable, trace-normalized bound on the resulting signed activities remains unproved.** All counterexamples above retain their stated scope and do not contradict this exact representation.

`check_interface_mobius.py` independently checks this algebra on a four-block noisy XY chain with input1001 and measured outcome0110. Its disconnected two-edge difference agrees with the product of its component differences, and the connected-edge polymer partition reconstructs the full normalized marginal, both within2.5e-14 in floating arithmetic. The connected activities include negative values; at this deliberately short time some activities are large, so the test certifies neither convergence nor a long-time activity bound.

## 7. Hypercontractivity with insertions: a rigorous intermediate bound

The switch-free mixed-derivative bound is independently verified. Write

    L_lambda=D+sum internal commutators+sum_e lambda_e C_e,
    C_e=i[V_e,.],  lambda_e in[0,1].

For a set of distinct interfaces C, the mixed derivative of exp(T L_lambda) is the sum over all |C|! orders of time-ordered Duhamel insertions C_e between full-noise semigroups. Choose the continuous exponent schedule

    p(t)=1+(p(0)-1)exp(2gamma t).

Each intervening semigroup is hypercontractive along this schedule; each insertion is bounded on the same Schatten p-space by2||V_e||. The simplex volume cancels the permutation count. Therefore

    ||partial_C Phi_T(M)||_(p(T),tau)
       <=(2T)^|C| product_(e in C)||V_e||
                     ||M||_(p(0),tau).

Integrating over the interface parameters gives the corresponding finite Möbius-difference bound. No switch-register ancilla or jump-count assumption is required. Since ||V_e|| can be O(hr) per coarse interface, this bound alone does not establish convergence for strong interfaces. It does show that hypercontractive time and arbitrary Hamiltonian response insertions coexist with fully charged normalization.

## 8. Structural repair of the shared-label support issue

Further inspection supports the following precise repair to the literal ancillary-graph argument. It should be used in place of applying the physical LR theorem to a high-degree quantum switch vertex.

Work in the direct sum over classical assignments sigma of the physical operator algebra. Each Hamiltonian factor H_X(sigma) has bounded norm h and actual physical support X. Classical coefficients lie in the center. Consequently

    [f(sigma)H_X,g(sigma)A_R]=f(sigma)g(sigma)[H_X,A_R],

so disjoint physical supports still commute, even when the same label appears in many terms. There is no physical propagation through a shared classical label.

For a chosen interface e, assign its label to the physical strip S_e containing the supports of all Hamiltonian factors controlled by e. Let Q_e be the nonconstant Fourier projection in that bit, namely half the difference under flipping the bit. It is a contraction in every normalized Schatten p-norm of the direct-sum algebra. If the initial observable is independent of selected labels, Q_e annihilates a Hamiltonian word unless a factor carrying e has been used. A nonzero such word must contain a physically connected causal path from the initial support to S_e. Thus the role of the source's final nested-commutator annihilation test can be played by the product of these commuting Fourier projections. The factor graph used for causal paths is the physical one, not the switch ancilla graph.

The full-noise resummation can be stated at word level. Expand in the alphabet of Hamiltonian commutators and on-site D_i=gamma(E_i-Id). Classify the causal forest after erasing all D_i letters. Every D_i is scalar or zero on each physical Pauli string and introduces neither physical support nor label dependence. It cannot create a missing causal path. All placements of the erased letters are reducible; their order relative to Hamiltonian letters is retained, not commuted away. Applying the source's allowed-word partition to the remaining Hamiltonian words and re-exponentiating the arbitrary insertions gives

    exp[(full D + allowed Hamiltonian commutators) Delta t]

in every reducible segment. Extra noncausal words still vanish under the final Fourier projections. This is the required extension of the source's Lemma4.5/Schwinger-Karplus word identity; it uses support-preserving diagonal noise, not a false commutation of D with H.

Each resulting segment is a direct sum of physical unital noisy semigroups. For K conserved bits, changing from a normalized p-sum over branches to a normalized q-sum costs at most2^{K(1/p-1/q)}. Applying the same exponent schedule through all segments makes these exponents telescope. Local commutator insertions cost2h at their current p. Consequently, for selected strips inside separated buffers, the simultaneous physical path factors can be combined with hypercontractivity, with total undamped-label loss2^{K(1/p_initial-1/p_final)}, not a new loss at every insertion and not a factor-graph velocity proportional to r.

This word-level structural argument supports the proposed combined path/hypercontractive extension. It still does not by itself provide the final activity estimate: selected interface buffers must be packed quantitatively relative to the marked measurement blocks; dense and sparse marked terms must be combined with all Fourier, subset-count and local-baseline factors; and the resulting sum must meet a convergence criterion. Those constants and the required activity tail should be written out and independently checked before claiming the fixed-time polymer theorem.

There is also a separate all-time cost issue. Even if activity convergence is established at every fixed T beyond a threshold, a patch radius r=O(hT) leads to dense activity work exp(O(r^2 v)) in two dimensions. At T=O(log n/gamma), that is not automatically polynomial in n. A uniform all-time theorem needs an additional efficient long-time activity calculation or another argument before the global mixing cutoff. Neither the word-level repair nor the fixed-time patch lemma supplies that computational step.

## 9. Independent check of the proposed convergence constants

The continuation's proposed dense/sparse closure has the following checked arithmetic, conditional on using the structural path/hypercontractive lemma with all its hypotheses:

- Color coarse interfaces by orientation and endpoint coordinates modulo8. This gives128 colors. Interfaces of one color have separated radius-r buffers around their two-column-by-r physical strips.
- Count as near every interface whose **closed buffer intersects** a marked core. Merely excluding distance<r leaves an off-by-one intersection at distance exactlyr. The conservative bound50 near interfaces per r-by-r core still holds with the corrected exclusion.
- For a connected edge polymer with v>=2 vertices, e>=v/2 and e<=2v. If the number s of marked blocks is below eta v with eta=1/200, at least v/4 interfaces remain far. One color therefore supplies at least v/512 separated targets. The conservative delta<=256r^2(2eh Delta T/r)^r pays their physical path factors.
- Fourier extraction, the telescoped direct-sum norm loss, conversion to physical operator norm, all marked subsets and baselines at least1/2 give the sparse envelope [128 times3^eta times delta^(1/512)]^v.
- The dense envelope is [16 exp(-c eta)]^v. Setting c=200(b+4) and delta<=exp[-512(b+7)] gives enough slack that the **sum** of both envelopes is at most exp(-bv), rather than silently dropping a factor2.
- A rooted connected vertex set of size v has at most16^(v-1) canonical depth-first walk encodings on the degree-four coarse graph. At most4^v edge subsets live on it. Thus64^v bounds the number of connected edge polymers of size v incident on a fixed vertex.
- With b=8, a=1 in the KP criterion and one additional unit of exponential tail slack, the root activity mass is at most sum_(v>=2)(64e^(-6))^v<0.03<1. This part of the convergence accounting is ample, not borderline.

The source norm and final time conditions must remain uniform over deleted-interface Hamiltonians and every marginal assignment. Dense marked terms use N<=r^2 v<=r^2 s/eta; enlarging that bound to9r^2 s/eta is safe. The same dense time condition also pays the sparse p-to-q interval.

If assembled with the explicit word-level lemma, these steps support a **fixed-physical-time** convergence proposition. Signed activity computation by interface subset sums costs exp(O(v)) evaluations, with cancellation paid by O(v) additional precision bits beyond the requested scalar accuracy. Dense simulation remains exp(O(r^2 v)), so this is not yet the desired uniform all-time polynomial theorem. The latter computational obstacle is independent of the now-resolved exact factorization algebra.

## 10. New exact tests of roundtrips and forest multiplicity

The independent `check_roundtrip_forest.py` does not merely compare final norms. It compares exact integer Taylor coefficients of two proposed representations of the same Boolean-label response.

Take five physical qubits with source observable Z_0 and four Hamiltonian terms

    H_1=X_0 X_1, H_2=Y_1 X_2,
    H_3=X_0 X_3, H_4=Y_3 X_4,

each with its own binary on/off label. Every site has replacement rate one. The two target paths have length two. There are six orderings of the four irreducible factors that preserve the within-path order. For each ordering, the test builds the cut Hamiltonian in each of its five intervals, retaining the full Pauli-diagonal dissipator in every interval. It then sums all placements of reducible letters without floating arithmetic.

All-label coefficients of this resummation equal those of the direct full generator at every Taylor order from zero through twelve. In particular, the coefficient on the original source-only observable is

    (4/9) T^8 Z_0 - (52/45) T^9 Z_0 + (802/675) T^10 Z_0 + ... .

Thus a history can visit both distant targets, retain every switch label, and return entirely to the source. Removing words according to their final physical support would be wrong. The visited-region/first-arrival forest used in the candidate does retain this term. The test would detect its loss.

A second program, `check_forest_languages.py`, exhaustively compares the geometric earliest-parent forest to its cut-alphabet language for the diamond graph with a cross-edge. It checks all 488,281 Hamiltonian words of lengths zero through eight, including repeated factors, alternate arrival paths and cycles. There are four possible irreducible paths. All 139,928 geometrically causal words belong to exactly their assigned interval language; no word is counted twice, and no noncausal word is accepted in this example. This comparison does not invoke a final commutator to hide a mismatch. Arbitrary on-site diagonal-noise letters can be inserted in every interval and deleted before this geometric classification.

These are finite stress tests, not a substitute for the general word-language proof. They support the proposed extension and identify the necessary roundtrip guard explicitly. The source is McDonough et al., arXiv:2502.02652v2, Algorithm 1 and Lemmas 4.5–4.7. The noisy, classically labelled, changing-Schatten-exponent extension remains an additional argument, not a theorem quoted verbatim from that paper.

## 11. End-to-end finite algorithm audit

The current `FINITE_ALGORITHM.md` is independently consistent **conditional on** its uniform activity estimate. In detail:

1. A connected incompatibility cluster has a connected coarse vertex union. Enumerating such unions and then size-budgeted multisets of polymers costs n exp(O(m)), rather than n^m. The generating-product bound at z=1/128 controls the number of multisets because the rooted polymer count is at most 64^k.
2. Repeated polymer occurrences must be distinct vertices in the incompatibility graph when computing the connected graph coefficient. Dividing afterwards by each polymer multiplicity factorial gives the correct unordered cluster contribution. The stated subset recurrence was checked independently against direct connected-subgraph enumeration for all 1,099 simple graphs on at most five vertices, with exact agreement.
3. The bound 2^{O(m^2)} on the integer coefficient and the activity-precision budget are conservative. Since activities have absolute value below one, telescoping a product of approximations with error at most eta incurs only a polynomial occurrence factor and a harmless exp(O(m)) bound. Requested precision has O(m^2+log n+log(1/delta_log)) bits; it is not an uncharged exact-real oracle.
4. Each activity's local normalizers are at least 1/2. Boolean subtraction has exp(O(v)) terms and inverse local baselines cost exp(O(v)), so stable local precision is sufficient. No exponentially small global prefix mass appears as a denominator.
5. Rational Taylor evaluation of a finite Lindblad exponential is a finite, if enormous, algorithm. Its degree and integer bit length must be charged in the numerical action N(h+gamma)T, input bits and scalar precision. The current file does so. This is not a practical simulation claim.
6. Two additive log-marginal approximations within delta_log produce a normalized conditional probability whose multiplicative error is at most exp(2 delta_log). Sequential composition pays exp(2n delta_log). Approximating each coin to additive O(epsilon/n) with a bounded number of random bits then gives the stated TV guarantee. Logarithmic evaluation rather than raw tiny marginal division is essential.

There is one scope correction. **Fixing T and h/gamma alone does not fix the block radius or polynomial exponent.** For example, T=1 and h=gamma=n keep h/gamma=1 but make r grow with n. A fixed-parameter polynomial statement should fix the dimensionless actions gamma T and h/gamma (equivalently gamma T and hT), or fix h, gamma and T individually. The full displayed work bound exp(O(r^2 m)) remains correct. This correction is incorporated in the governing theorem.

## 12. Present judgment and prior boundary

No counterexample to the proposed simultaneous spatial-hypercontractive estimate was found in the new finite tests. The only general source-extension step still requiring an explicit final proof in the candidate file is the geometric word-language lift with full noise and all-label Fourier selection. A five-step outline and successful finite tests should not silently be relabelled a published or established theorem. The later first-discovery proof replaces that outline with an explicit lift modulo geometrically support-zero words.

The exact interface Möbius identity, its local denominators, the finite-patch estimate, the mixed derivative bound without spatial improvement, and the conditional finite computation/sampling reduction have been independently checked. The convergence constants have ample slack. The proof must uniformly cover every deleted-interface Hamiltonian and every partial output assignment.

The background mechanisms remain prior work: linked-cluster/Möbius algebra, causal-path resummation, quantum hypercontractivity and logarithmic marginal sampling. Wild and Alhambra, PRX Quantum 4,020340 (2023), DOI 10.1103/PRXQuantum.4.020340, develop short-time dynamical cluster algorithms; Nelson et al., arXiv:2610.00548, provide the noisy-circuit polymer comparator. Neither citation alone proves this continuous-time strong-interface response estimate. No historical-first assertion is warranted by the limited source search.

Even a cleared fixed-qualifying-action theorem would leave early times and the time-uniform computational interval open. At T scaling with log n/gamma, the currently used dense patch evaluator has a growing exponent. The exact factorization also cannot be restarted at a late interval with an invented product input. These remain separate barriers to a general-B sampler.

## 13. A genuine multi-site-target defect and its proposed repair

A later stress test found a substantive defect in the **literal** factor-tail interval formula being imported from source Eq. (33). A target strip is a multi-site set. Excluding only future factors of one retained path can leave another site of the same target available before that path's first factor. A word can then reach that other target site first, so its true first-arrival skeleton differs. Such a word is not geometrically null and is double-counted.

For example, with root {0}, target {2,4}, and two arms 0–1–2 and 0–3–4, a nominal path through 1–2 permits the other whole arm in its first interval if that interval excludes only the factor {1,2}. The same word can also occur in the other path's interval expansion. In the five-qubit exact test, the all-four-label coefficient at Taylor order four is -96 in the actual generator and -128 in that literal interval sum.

The stronger test in `check_multisite_target_gap.py` realizes the issue on an actual 2-by-4 nearest-neighbor lattice with a **single shared switch** and a connected 2-by-2 target interface strip. The six Hamiltonian factors, in row-major site order, are

    XXIIIIII, IYXIIIII, IIYXIIII,
    IIIIXXII, IIIIIYXI, IIIIIIYX.

The last factor of each row is controlled by the same binary switch. Every physical site has replacement rate one, the source is ZIIIZIII, and the target is the rightmost two columns. At order five, the true switch-response coefficient of YZXIYZZX (also of YZZXYZXI) is 320, while the literal first-interval formula gives 416. Dividing by 5! gives 8/3 versus 52/15. Full-noise insertions do not remove the discrepancy.

This is a counterexample to the asserted exact **word identity**, not to the desired spatial norm inequality. It also means that earlier singleton-target tests and a generic citation to the source cannot clear the candidate theorem. Adding the entire unvisited target to every pre-arrival forbidden set repairs this concrete example through order twelve.

For the theorem's explicitly two-body interaction class, a cleaner repair avoids the suspect factor-tail formula. Use the monotone **first-discovery vertex tree**: a geometrically connected two-site factor either discovers one new vertex, with its old endpoint as parent, or discovers none. On-site factors discover none. The target event is the first discovery of any vertex in that target set. Retain the parent path to that first target vertex. In every interval before arrival, forbid all its still-undiscovered retained path vertices **and the entire target set**. This makes any earlier arrival impossible by construction.

The independent `check_vertex_discovery_repair.py` tests this proposed replacement on the 2-by-3 ladder, with the left column as enlarged root and the connected right column as a multi-site target. It exhausts 335,923 words of lengths zero through seven, including the middle cross-edge and both alternative routes. Each of the 45,262 causal words has exactly one path/interval decomposition. The 5,538 admitted extras all have a disconnected prefix and are genuinely support-zero, rather than being canceled by a final observation map. This supports the required quotient argument.

**Updated status:** the literal imported formula is not cleared. A direct two-body vertex-discovery proof is needed at this historical stage. Until that proof is reviewed, the fixed-action sampler remains conditional. This finding supersedes any earlier suggestion that the original factor-alphabet source invocation alone was sufficient.

## 14. Review of the written two-body repair and final restricted conclusion

The completed `FIRST_DISCOVERY_PROOF.md` was read independently after Section 13. Its direct induction resolves the identified defect for **on-site and two-site Hamiltonian supports**:

- In a geometrically non-null word, a two-site factor can discover at most one vertex. Its old endpoint fixes the unique parent of that discovery. Retaining the ancestry of each target's first discovered vertex therefore has no tie or forest-multiplicity ambiguity.
- Before a retained vertex's designated discovery, every earlier touching factor would either be a disconnected-prefix zero or would have discovered it earlier. Before target arrival, the same argument applies to every vertex of the full target set. These are exactly the exclusions in the repaired alphabet.
- Conversely, the repaired exclusions force each next skeleton edge to discover its designated vertex from its designated parent. The separated buffers prevent another target's skeleton from preempting it. Induction proves sufficiency and uniqueness, modulo genuinely support-zero extras.
- Erasing and reinserting arbitrary support-preserving, label-independent local replacement letters preserves this classification and assigns each noise occurrence to a unique interval. The resulting cut-Hamiltonian propagators retain the entire depolarizing generator, so the changing-exponent hypercontractive argument applies without lost noise or an inverse semigroup.
- The central labels contribute the explicitly paid telescoping finite direct-sum norm factor. They create no physical path edges. Target visitation rather than final support preserves the verified nonzero roundtrips.
- Paths in different separated buffers have disjoint nonroot vertices and edges. Their order-preserving shuffles have the stated multinomial count, which cancels the ordered-simplex factorial. For a path-count check, count backwards from its endpoint in the target boundary: at most Delta^l length-l walks per endpoint suffice. Multiplication by the nonempty buffer-boundary count is a safe overbound, with no unpriced extra Delta factor.

The final scalar assembly was rechecked. The dense finite-patch hypothesis is applied at V=1800 r^2, not at the earlier smaller V. The selected time has substantial slack for both hypercontractive buffers and for the sum of the two moment-decay terms. The sparse envelope pays every switch, subset, final-dimension and local-normalization factor. The b=8 activity bound gives the KP criterion with one additional exponential tail factor. The finite algorithm then pays local evolution, cancellation, connected coefficient arithmetic, log accuracy and bounded random coins.

**Current independent conclusion:** no remaining proof or finite-cost blocker was found for the stated nearest-neighbor two-body, product-input, every-site-replacement **fixed-qualifying-action proposition**, when the corrected first-discovery proof is used. “Fixed” must mean bounded fixed dimensionless gamma T and h/gamma (or, more restrictively, fixed h, gamma and T), so the exp(O(r^2)) polynomial exponent does not itself grow with n. The conclusion is an independently reviewed mathematical construction, not an externally peer-reviewed publication or a historical-priority claim.

This conclusion supersedes the conditional status in Section 13 **only for the corrected arity-at-most-two formulation**. The literal source factor-tail identity remains rejected and its nonzero counterexample is retained. The audit still does not certify a uniform all-time polynomial sampler, early-time sampling below the sufficient threshold, higher-arity extensions, or practical advantage. The general-B problem is not declared solved.

## 15. Physical-probe dependency and adaptive time-cost check

The added physical-probe corollary in `FIRST_DISCOVERY_PROOF.md` also checks. Replace the label Fourier projection by the product of normalized physical commutators on the targets. Words that never visit a target are then killed by its probe, while disconnected-prefix words remain zero. The final probe product is a contraction in each Schatten norm. Thus the repaired two-body path identity supplies the corresponding simultaneous-probe bound needed by the finite-patch lemma, without depending on the rejected literal multi-site interval formula.

The resource refinement in `ALL_TIME_COST_BOUNDARY.md` is consistent. If the actual supplied time certifies activity decay exp(-b v), use the tail exponent kappa=b-7. The weighted KP root sum remains sum_{v>=2}(64 exp(-6))^v. A cutoff max(1,ceil(L/kappa)), L=log(10n/delta_log), therefore suffices. The minimum one-block work still pays isolated baselines, even if no nonempty interaction cluster remains.

At fixed rho=h/gamma, sufficiently large qualifying tau=gamma T allows b=Theta(tau) while r=O_rho(tau). The dense evaluator's exponent improves from O(tau^2 L) to O_rho(tau^2+tau L). Enumeration, numerical action and scalar bit accuracy remain paid. The largest admissible b can be found by monotone binary search with O(log tau) exact rational scalar tests.

This is an improved **upper bound for that evaluator**, not an algorithmic lower bound or a practical result. Before the global mixing cutoff tau=O(log(n/epsilon)), its worst scaling is still quasipolynomial, exp(O(log^2(n/epsilon))), rather than a uniform polynomial. Earlier unqualified times remain outside this construction. The replacement-rate convention must stay D_i=gamma(E_i-Id) when applying the entropy-mixing shortcut.
