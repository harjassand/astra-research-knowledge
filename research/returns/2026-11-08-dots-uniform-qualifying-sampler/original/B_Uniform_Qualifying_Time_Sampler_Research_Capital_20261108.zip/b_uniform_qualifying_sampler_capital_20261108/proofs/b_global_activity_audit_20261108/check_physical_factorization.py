"""Exact low-order test of factorization across arbitrarily separated endpoint observables."""
import sympy as s, json,pathlib,numpy as np
from scipy.linalg import expm
I=s.eye(2);X=s.Matrix([[0,1],[1,0]]);Y=s.Matrix([[0,-s.I],[s.I,0]]);Z=s.diag(1,-1)
def kron(xs):
 out=s.ones(1)
 for x in xs:out=s.kronecker_product(out,x)
 return out
rows=[]
for n in [2,3,4]:
 D=2**n;eye=s.eye(D);H=s.zeros(D)
 for j in range(n-1):
  for P in [X,Y]:H+=kron([P if i in [j,j+1]else I for i in range(n)])/2
 local=[[kron([P if i==j else I for i in range(n)])for P in [X,Y,Z]]for j in range(n)]
 def L(r):return -s.I*(H*r-r*H)+sum((P*r*P-r for ps in local for P in ps),s.zeros(D))/4
 psi=s.zeros(D,1);psi[2**(n-1),0]=1;rho=psi*psi.T
 A=kron([Z]+[I]*(n-1));B=kron([I]*(n-1)+[Z]);AB=A*B
 coeff=[[],[],[]];r=rho
 for k in range(2*(n-1)+1):
  for dst,O in zip(coeff,[A,B,AB]):dst.append(s.trace(O*r)/s.factorial(k))
  r=L(r)
 cov=[s.simplify(coeff[2][k]-sum(coeff[0][i]*coeff[1][k-i]for i in range(k+1)))for k in range(len(coeff[0]))]
 target=-s.Rational(4,s.factorial(n-1)**2);assert all(v==0 for v in cov[:-1]);assert cov[-1]==target
 rows.append({'sites':n,'distance':n-1,'gamma':1,'J':1,'connected_ZZ_taylor_coefficients':[str(c)for c in cov],'leading_formula':str(target)})
 if n==3:
  Hn=np.array(H,dtype=complex);In=np.eye(D);Ln=-1j*(np.kron(Hn,In)-np.kron(In,Hn.T))
  for ps in local:
   for P in ps:
    Pn=np.array(P,dtype=complex);Ln+=(np.kron(Pn,Pn.conj())-np.eye(D*D))/4
  numerical=[]
  for t in [.1,1.,4.]:
   rr=(expm(t*Ln)@np.array(rho,dtype=complex).ravel()).reshape(D,D)
   a=np.trace(np.array(A,dtype=complex)@rr).real;b=np.trace(np.array(B,dtype=complex)@rr).real;ab=np.trace(np.array(AB,dtype=complex)@rr).real;c=ab-a*b
   numerical.append({'t':t,'endpoint_covariance':float(c),'endpoint_joint_TV_from_product_of_its_marginals':float(abs(c)/2)})
  rows[-1]['numerical_checks']=numerical
out={'scope':'No general sampling hardness claim. Product input, static rational local Hamiltonian and every-site replacement noise. Leading connected coefficient checked exactly; long-distance proof uses edge-sign symmetry and disconnected-cut factorization.','checks':rows}
pathlib.Path(__file__).with_name('physical_factorization_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
