"""Exact moment/cumulant identity and a positive-distribution zero-free counterexample."""
from fractions import Fraction as Q
import math,json,pathlib,mpmath as mp
mp.mp.dps=100
a=Q(1,16);n=8
m={s:(a**s.bit_count() if s.bit_count()%2==0 else Q(0))for s in range(1<<n)};kappa={}
for size in range(1,n+1):
 for S in range(1,1<<n):
  if S.bit_count()!=size:continue
  root=S&-S;v=m[S];B=(S-1)&S
  while B:
   if B&root:v-=kappa[B]*m[S^B]
   B=(B-1)&S
  kappa[S]=v
# Independent disjoint-polymer partition recursion: vertex may be unused or in one polymer.
Z={0:Q(1)}
for size in range(1,n+1):
 for S in range(1,1<<n):
  if S.bit_count()!=size:continue
  root=S&-S;v=Z[S^root];B=S
  while B:
   if B&root:v+=kappa[B]*Z[S^B]
   B=(B-1)&S
  Z[S]=v
full=(1<<n)-1;assert Z[full]==sum(m.values())
coeff=[{'order':j,'kappa_over_a_power':str(kappa[(1<<j)-1]/a**j)}for j in range(1,n+1)]
q=9;aa=mp.mpf(1)/(2**q);N=4096;zz=1j*mp.tan(mp.pi/(2*N))/aa;xi=((1+aa*zz)**N+(1-aa*zz)**N)/2
out={'exact_identity_test':{'sites':n,'a':str(a),'hard_core_cumulant_partition':str(Z[full]),'sum_of_all_subset_moments':str(sum(m.values())),'equal':True},'cumulants':coeff,'zero_free_counterexample':{'scope':'Logical insufficiency of moment decay, NOT a product-input finite-time local B counterexample. Distribution is a global latent-sign mixture.','a':'1/512','sites':N,'exact_zero_formula':'i tan(pi/(2n))/a','zero_absolute_value':mp.nstr(abs(zz),40),'high_precision_partition_residual':mp.nstr(abs(xi),10),'all_nonempty_moments_bounded_by':'a^|S|','all_real_output_probabilities_strictly_positive':True,'root_pair_activity_sum_for_n_1048576':str(Q((1<<20)-1,512**2))}}
pathlib.Path(__file__).with_name('cumulant_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
