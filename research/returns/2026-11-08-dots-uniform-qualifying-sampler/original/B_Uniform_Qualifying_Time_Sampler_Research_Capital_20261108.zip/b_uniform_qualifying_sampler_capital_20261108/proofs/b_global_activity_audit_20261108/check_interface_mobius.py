"""Physical finite test of exact interface-switch polymer factorization."""
import numpy as np,json,pathlib
from scipy.linalg import expm
I=np.eye(2);X=np.array([[0,1],[1,0]]);Y=np.array([[0,-1j],[1j,0]]);Z=np.diag([1,-1])
def kron(xs):
 a=np.array([[1]],complex)
 for x in xs:a=np.kron(a,x)
 return a
n=4;D=16;Id=np.eye(D);terms=[]
for e in range(3):terms.append(sum(kron([P if i in [e,e+1]else I for i in range(n)])for P in [X,Y])/2)
noise=np.zeros((D*D,D*D),complex)
for i in range(n):
 for P in [X,Y,Z]:
  Q=kron([P if j==i else I for j in range(n)]);noise+=(np.kron(Q,Q.conj())-np.eye(D*D))/4
rho=np.zeros((D,D),complex);rho[9,9]=1;t=.5;f={}
for A in range(8):
 H=sum((terms[e]for e in range(3)if A>>e&1),np.zeros((D,D),complex));L=noise-1j*(np.kron(H,Id)-np.kron(Id,H.T));r=(expm(t*L)@rho.ravel()).reshape(D,D);f[A]=float((16*r[6,6]).real)
F={A:v/f[0]for A,v in f.items()};delta={}
for A in range(8):
 delta[A]=sum((-1)**(A.bit_count()-B.bit_count())*F[B]for B in range(8)if B&A==B)
connected=[1,2,4,3,6,7];poly=1+sum(delta[A]for A in connected)+delta[1]*delta[4]
error1=abs(delta[5]-delta[1]*delta[4]);error2=abs(F[7]-poly);assert error1<1e-11 and error2<1e-11
out={'scope':'Finite floating physical check of independently proved exact algebra; not an activity convergence test.','model':'4 singleton blocks on path, XY interfaceJ1, gamma1,T.5,input1001,output0110','normalized_marginals_by_edge_bitmask':f,'normalized_baseline':f[0],'edge_mobius_activities':delta,'disjoint_component_factorization_error':error1,'connected_polymer_partition_reconstruction_error':error2,'full_relative_partition':F[7]}
pathlib.Path(__file__).with_name('interface_mobius_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
