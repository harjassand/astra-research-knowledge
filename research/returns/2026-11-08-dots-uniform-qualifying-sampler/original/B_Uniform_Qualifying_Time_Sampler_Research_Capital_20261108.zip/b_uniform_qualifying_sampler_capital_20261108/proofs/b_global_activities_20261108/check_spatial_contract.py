from fractions import Fraction as F
from pathlib import Path
from math import log
import json

def ceil(x):return -(-x.numerator//x.denominator)
def clog2(n):return (n-1).bit_length()
def certificate(ratio,b=8,Delta=5):
 c=200*(b+4);R0=max(4096,4096*(b+7),128*(c+3));T=F(1)
 while True:
  r=R0+ceil(12*ratio*Delta*T)
  threshold=4+2*clog2(r)+32*(c+4)
  if T>=threshold:break
  T*=2
 assert 6*ratio*Delta*T/r<=F(1,2) # e<3
 assert r-8-2*clog2(r)>=1024*(b+7)
 assert F(r,2)>=12+3*clog2(r)+32*(c+3)
 assert T-4-2*clog2(r)>=32*(c+4)
 return dict(h_over_gamma=str(ratio),gammaT=str(T),r=r,c=c,
             physical_sites_per_block=r*r,finite_patch_V=1800*r*r,
             all_rational_sufficient_conditions_passed=True)

def distrect(A,B):
 return max(0,A[0]-B[1],B[0]-A[1],A[2]-B[3],B[2]-A[3])
def strip(orient,i,j,r):
 if orient==0:return((i+1)*r-1,(i+1)*r,j*r,(j+1)*r-1)
 return(i*r,(i+1)*r-1,(j+1)*r-1,(j+1)*r)
def buffer(S,r):return(S[0]-r,S[1]+r,S[2]-r,S[3]+r)
geom=[]
for r in range(1,17):
 M=(0,r-1,0,r-1);near=0
 for o in [0,1]:
  for i in range(-5,6):
   for j in range(-5,6):
    if distrect(strip(o,i,j,r),M)<=r:near+=1
 assert near<=50
 for o in [0,1]:
  for di,dj in [(8,0),(0,8),(8,8),(-8,8)]:
   assert distrect(buffer(strip(o,0,0,r),r),buffer(strip(o,di,dj,r),r))>=2
 geom.append(dict(r=r,near_edges=near,bound50=True,color_buffer_separation=True))
# A roundtrip witness: C=i[Z1Z2,.] maps X1 -> -2Y1Z2 -> -4X1.
# Delta switch difference after tracing site2 retains coefficient -2J^2 T^2.
out=dict(scope='Scalar/geometry checks for a conditional proof candidate; no sampler execution.',
 certificate_cases=[certificate(F(1,16)),certificate(F(1)),certificate(F(10))],
 geometry=geom,roundtrip_erased_site_Taylor_T2_coefficient_at_J_1_16=str(-2*F(1,16)**2),
 kp_geometric_ratio_upper_using_e_gt_2=F(64,2**(8-2)).numerator/F(64,2**(8-2)).denominator,
 note='The last crude e>2 check is insufficient; actual KP ratio64 exp(-6)<.159 is analytic or can use e>5/2.',
 kp_ratio_rational_upper=str(F(64)*F(2,5)**6))
q=F(64)*F(2,5)**6
assert q*q/(1-q)<1
out['kp_tail_sum_rational_upper']=str(q*q/(1-q))
Path(__file__).with_name('spatial_contract_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
