"""Exact integer Taylor-coefficient tests of full-noise forest resummation.
Five physical qubits, two separated targets, source at the middle, return paths retained.
This tests a nontrivial geometry, not a proof of the general source extension.
"""
import numpy as np,itertools,json,time,pathlib,math
O=pathlib.Path(__file__).resolve().parent;t0=time.perf_counter();n=5;N=4**n
paulis=np.array(list(itertools.product(range(4),repeat=n)),dtype=int)
# local P_a P_b = i**phase[a,b] P_(mul[a,b])
mul=np.array([[0,1,2,3],[1,0,3,2],[2,3,0,1],[3,2,1,0]])
phase=np.array([[0,0,0,0],[0,0,1,3],[0,3,0,1],[0,1,3,0]])
weights=(paulis!=0).sum(axis=1); powers=4**np.arange(n-1,-1,-1)
def word(s):return np.array([int(x)for x in s])
H=[word('01100'),word('33000'),word('00220'),word('00011')]
# A:1-2; B:0-1; C:2-3; D:3-4.  B and D carry independent switches.
H += [np.array([2 if j==i else 0 for j in range(n)])for i in range(n)]
supports=[set(np.flatnonzero(h))for h in H]
ops=[]
for h in H:
 q=mul[h[None,:],paulis]; ph=phase[h[None,:],paulis].sum(axis=1)%4
 coeff=np.where(ph==1,-2,np.where(ph==3,2,0)).astype(np.int64);perm=q@powers
 ops.append((perm,coeff))
def applyC(k,v):
 perm,c=ops[k]; out=np.zeros(N,dtype=np.int64);out[perm]=c*v;return out
initial=np.zeros(N,dtype=np.int64);initial[int(word('00300')@powers)]=1
states=list(itertools.product(range(3),repeat=2))
def forbidden(state):
 a,b=state;v=set()
 if a==0:v|={0,1}
 if a==1:v|={0}
 if b==0:v|={3,4}
 if b==1:v|={4}
 return v
allowed={s:[k for k,sp in enumerate(supports)if not(sp&forbidden(s))]for s in states}
def run(bits,maxk=8,keep_noise=True):
 scales=[1,bits[0],1,bits[1]]+[1]*n
 def step(v,ks):
  out=-weights*v if keep_noise else np.zeros(N,dtype=np.int64)
  for k in ks:
   if scales[k]:out+=applyC(k,v)
  return out
 full=[initial]; dp={(0,0):initial};done=[np.zeros(N,dtype=np.int64)];countmax=0
 for order in range(1,maxk+1):
  full.append(step(full[-1],range(len(H))))
  nxt={}
  for state,v in dp.items():
   nxt[state]=nxt.get(state,np.zeros(N,dtype=np.int64))+step(v,allowed[state])
   for axis in range(2):
    if state[axis]<2:
     k=2*axis+state[axis];new=list(state);new[axis]+=1;new=tuple(new)
     if scales[k]:nxt[new]=nxt.get(new,np.zeros(N,dtype=np.int64))+applyC(k,v)
  dp=nxt;done.append(dp.get((2,2),np.zeros(N,dtype=np.int64)))
  countmax=max(countmax,max(int(np.max(np.abs(v)))for v in dp.values()),int(np.max(np.abs(full[-1]))))
 return full,done,countmax
rows=[]
for noise in [False,True]:
 deltafull=[np.zeros(N,dtype=np.int64)for _ in range(9)];deltadone=[np.zeros(N,dtype=np.int64)for _ in range(9)];maxentry=0
 for bits in itertools.product(range(2),repeat=2):
  f,d,m=run(bits,keep_noise=noise);sgn=(-1)**(2-sum(bits));maxentry=max(maxentry,m)
  for k in range(9):deltafull[k]+=sgn*f[k];deltadone[k]+=sgn*d[k]
 for k in range(9):
  residual=int(np.max(np.abs(deltafull[k]-deltadone[k])));assert residual==0,(noise,k,residual)
  rows.append({'noise':noise,'order':k,'max_integer_residual':residual,'nonzero_terms':int(np.count_nonzero(deltafull[k])),'largest_coefficient':int(np.max(np.abs(deltafull[k])))})
 assert maxentry<2**60
# Explicit return: a label remains after physical target support disappears.
# Apply A B B A to source Z2. It returns to the source, and B's Boolean label survives as lambda²=lambda.
v=initial.copy()
for k in [0,1,1,0]:v=applyC(k,v)
returned={''.join(map(str,paulis[i])):int(v[i])for i in np.flatnonzero(v)}
assert returned=={'00300':16},returned
# Simultaneous long-distance defect is not confused with a final-support projection.
r={'scope':'Exact integer coefficient checks of the proposed noisy free-word lift on one five-site/two-buffer geometry. Not a general proof or a convergence benchmark.','tests':rows,'return_word_ABBA':returned,'maximum_intermediate_integer':maxentry,'wall_seconds':time.perf_counter()-t0}
(O/'noise_forest_checks.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
