# Spatially resolved hypercontractive response and activity convergence

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

8 November 2026. The repaired at-most-two-body proposition has completed the first independent end-to-end audit. The filename is retained for continuity. FIRST_DISCOVERY_PROOF.md is the governing word identity; the old literal-source interval rule is not used. A second independent audit has also completed and supports the repaired two-body construction; see second_audit/INDEPENDENT_AUDIT.md. This is a fixed-qualifying-action result, not uniform all-time B.

## 1. Repaired physical-word lemma

Use static on-site and nearest-neighbor two-site Hamiltonian terms, grouped by physical support, with norm at most h and physical path-branching bound Delta. Coefficients may depend on K conserved classical binary labels. Work in the normalized direct sum of physical matrix algebras, not a high-degree ancillary factor graph. Retain every physical replacement-noise term of rate gamma.

Each selected label appears only in a physical target strip S_j inside a separated buffer B_j. The initial operator M is physically outside all selected buffers and label independent. For p_1>=p_0>1 with p_1-1<=(p_0-1)exp(2gamma T), the repaired lemma gives

    ||Delta_all Phi_T(M)||_(p_1,tau_phys)
      <= 2^{K(1+1/p_0-1/p_1)} delta(T)^q ||M||_(p_0,tau_phys),

where q is the number of selected targets, every root-to-target distance is at least r, and

    delta(T)=2 max_j |boundary B_j||boundary S_j|
                        (2 e h Delta T/r)^r,
    T<r/(2h Delta).

FIRST_DISCOVERY_PROOF.md gives the complete two-body proof. Initialize visited vertices to the entire buffer complement; every non-null two-body factor discovers at most one new vertex. Keep the first-discovery path to the first visited site of each target. Before its arrival, forbid every future retained path vertex and the ENTIRE target strip. Every non-null Hamiltonian word then has a unique retained path family, shuffle and free-interval split. Arbitrary support-preserving D_i insertions lift that split uniquely and sum to full-noise allowed-Hamiltonian propagators. Hypercontractive direct-sum costs telescope, and all-label Fourier extraction supplies the displayed factors. Physical path counting is independent of the number of shared label occurrences.

The whole-target exclusion repairs a concrete multi-site early-arrival error in the previously attempted literal source formula. WORD_LIFT_LEMMA.md preserves that superseded argument and its exact source obligation. The failed rule and positive repaired tests remain in the artifacts. The physical-probe version of the direct proof also supplies the two-body multi-site estimate used by the earlier finite-patch lemma.

## 2. Conservative packing for sparse marks in two dimensions

Tile the physical square lattice into r-by-r blocks. A coarse edge controls the entire interface between adjacent blocks. Its physical strip has width2 and length r. A radius-r buffer around such a strip has boundary at most14r; the strip has boundary at most6r. The following round bound is safe:

    delta(T)<=256r^2(2 e h Delta T/r)^r.                    (3)

When buffers extend outside the finite polymer patch, pad with decoupled sites and set missing interactions to zero on the ambient grid. The evolved operator is identity on padding, so normalized Schatten norms and the actual physical norm-conversion cost are unchanged.

Color coarse edges by orientation and the two endpoint-anchor coordinates modulo8. There are128 colors. Edges of one color have separated buffers. For each marked block, at most50 coarse edges have interface strips within distance at most r of that whole block. These are deliberately loose counts.

A connected edge polymer has v>=2 block vertices and e>=v-1>=v/2 edges, with e<=2v. Let s marked blocks satisfy

    s<eta v,     eta=1/200.

Removing all interfaces too close to marks leaves at least e-50s>v/4 edges. A largest color class therefore supplies q>=v/512 separated far interfaces. If s=0, the finite difference of the identity observable is exactly zero; the argument is only needed for nonempty S.

## 3. Activity bound

Use the exact edge-Mobius activities from EXACT_EXPANSION.md. Let a=r^2, and choose p_0=1+1/a, p_1=1+a with gamma T>=log a. A centered marked product on s blocks has input norm at most3^s. Its physical polymer patch has av sites, so converting final p_1-norm to operator norm costs at most2^v. There are K=e<=2v labels.

By the repaired lemma, a sparse-mark contribution is bounded by

    2^{2e+v}3^s delta^{v/512}.

Summing all marked subsets and using isolated-block normalizers z_v>=1/2 yields the sparse contribution

    [128·3^eta·delta^{1/512}]^v.                           (4)

For dense marks s>=eta v, the independently audited finite-patch theorem applies with chi=16 and V=9r^2/eta, retaining all switch subsets of the Hamiltonian. Its contribution after the same local normalization is at most

    [16 exp(-c eta)]^v.                                    (5)

Thus taking

    c=200(b+4),
    delta<=exp[-512(b+7)]                                  (6)

makes the sum of (4) and (5) at most exp(-bv). Each term is bounded by exp[-(b+log2)v]. The conditions on the finite-patch lemma must be imposed at the displayed larger V, not reused from a smaller patch.

## 4. Rational scalar choices and convergence

For integer b>=1, set c=200(b+4) and

    R0=max(4096,4096(b+7),128(c+3)),
    r=R0+ceil(12h Delta T).

It suffices to require

    gamma T>=4+2ceil(log_2 r)+32(c+4).                       (7)

Then (3) is at most256r^2 2^{-r}, small enough for (6). The finite-patch conditions with V=1800r^2 also follow from these conservative choices. Starting at T=1/gamma and doubling until (7) holds terminates for every fixed numerical h/gamma. This is a way to exhibit a qualifying physical time, not a change to the supplied time. For an actual supplied T, test its conditions rather than replacing T.

There are fewer than64^v connected coarse edge polymers with v vertices containing a fixed block: count connected vertex sets on the degree-four grid and then their possible internal edge subsets. Consequently b=8 implies the Kotecky-Preiss condition with an extra exp(v) tail factor, using

    sum_(v>=2) [64 exp(-(b-2))]^v <1.

This provides an absolutely convergent logarithmic cluster expansion and a controlled finite cutoff. The convergence uses the repaired response lemma, the packing and the stated counting bounds. The exact Möbius identity alone would not imply it.

## 5. Cost and status

With a cluster-size cutoff m=O(log(n/epsilon)), brute finite-activity evaluation costs exp(O(r^2 m)), multiplied by paid polynomial input/action/precision factors. Connected-polymer and incompatibility-cluster enumeration must use the standard exponential-in-m algorithms, not an uncharged enumeration of all graphs on m objects. At fixed dimensionless action gamma T, fixed h/gamma and fixed locality, this is polynomial in n and1/epsilon, with an enormous exponent.

As T grows, r grows. No time-uniform polynomial bound through the global mixing cutoff follows from this evaluator. A final fixed-length interval cannot be restarted from a product input. Even after a successful review of this candidate, that all-time cost problem would remain separate from early-time TV sampling below the thermalization threshold.

Current established capital under the stated two-body scope: exact compatible edge-polymer algebra; isolated normalizers; finite-patch norm decay; the repaired full-noise shared-label response; exponential activity decay; and the independently checked finite cluster/log-sampling reduction. No generic all-time B solution or practical speed claim is made. See ALL_TIME_COST_BOUNDARY.md for the adaptive time-dependent upper bound and its remaining gap.
