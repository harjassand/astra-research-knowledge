import numpy as np
from scipy.sparse import csr_matrix,eye,kron,bmat
from scipy.sparse.linalg import expm_multiply
from pathlib import Path
import json,time
I=np.eye(2);X=np.array([[0,1],[1,0]]);Y=np.array([[0,-1j],[1j,0]]);Z=np.diag([1,-1])
def run(branches,T,gamma):
 n=1+2*branches;d=2**n;D=d*d
 def op(dic):
  a=np.ones((1,1),complex)
  for i in range(n):a=np.kron(a,dic.get(i,I))
  return csr_matrix(a)
 ID=eye(d,format='csr');SID=eye(D,format='csr')
 noise=csr_matrix((D,D),dtype=complex)
 for i in range(n):
  for p in [X,Y,Z]:
   P=op({i:p});noise+=gamma/4*(kron(P.conj(),P)-SID)
 terms=[]
 for b in range(branches):
  mid=1+2*b;end=mid+1
  terms.extend([(.31+.17*b)*op({0:Z,mid:Z}),(.43+.11*b)*op({mid:X,end:X})])
 C=[1j*(kron(ID,H)-kron(H.T,ID)) for H in terms]
 M=op({0:X}).toarray()+.2j*op({0:Y}).toarray();v=M.reshape(-1,order='F')
 # Full label Fourier/Mobius coefficient, including physical roundtrips.
 diff=np.zeros(D,complex)
 for mask in range(1<<(2*branches)):
  L=noise.copy()
  for e in range(2*branches):
   if mask>>e&1:L+=C[e]
  diff+=(-1)**(2*branches-mask.bit_count())*expm_multiply(T*L,v)
 # Exact first-arrival automaton: each branch has0,1,2 reachededges.
 states=list(np.ndindex(*(3,)*branches));lookup={s:i for i,s in enumerate(states)}
 rows=[[None for _ in states] for _ in states]
 for j,s in enumerate(states):
  L=noise.copy()
  for b,progress in enumerate(s):
   for step in range(progress):L+=C[2*b+step]
  rows[j][j]=L
  for b,progress in enumerate(s):
   if progress<2:
    dest=list(s);dest[b]+=1;k=lookup[tuple(dest)]
    rows[k][j]=C[2*b+progress]
 A=bmat(rows,format='csr');init=np.zeros(D*len(states),complex);init[:D]=v
 reached=expm_multiply(T*A,init)[-D:]
 return dict(branches=branches,n=n,T=T,gamma=gamma,
             max_entry_discrepancy=float(np.max(abs(diff-reached))),
             frobenius_discrepancy=float(np.linalg.norm(diff-reached)),
             signal_frobenius=float(np.linalg.norm(diff)),automaton_dimension=A.shape[0],
             note='Exact first-arrival identity for this tree geometry; diagnostic is floating, not formal verification of all forests.')
t=time.time();out={'cases':[run(1,.8,.7),run(1,2.,1.3),run(2,.8,.7),run(2,2.,1.3)],'elapsed_seconds':time.time()-t}
Path(__file__).with_name('word_lift_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
