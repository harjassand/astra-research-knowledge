import math,json,pathlib,time
O=pathlib.Path(__file__).resolve().parent;t0=time.perf_counter()
def axisdist(a,b,c,d):return max(0,c-b,a-d)
def rectdist(A,B):return sum(axisdist(*A[i],*B[i])for i in range(2))
rows=[]
for r in [1,2,3,4,8,17,64,307584]:
 core=((0,r-1),(0,r-1));near=[]
 for ori in [0,1]:
  for i in range(-5,6):
   for j in range(-5,6):
    # vertical coarse interface at x=i*r, with endpoint anchors (i-1,j),(i,j).
    strip=((i*r-1,i*r),(j*r,(j+1)*r-1)) if ori==0 else ((j*r,(j+1)*r-1),(i*r-1,i*r))
    if rectdist(core,strip)<=r:near.append((ori,i,j))
 assert len(near)<=50,(r,len(near)); rows.append({'r':r,'near_interfaces_closed_L1_buffer':len(near)})
# Conservative parameter construction, gamma normalized to 1, actual action gamma*T.
parameters=[]; b=8;c=200*(b+4);R0=max(4096,4096*(b+7),128*(c+3))
for ratio in [.01,1,100]:
 T=1
 while True:
  r=R0+math.ceil(12*ratio*5*T);rhs=4+2*math.ceil(math.log2(r))+32*(c+4)
  if T>=rhs:break
  T*=2
 logdelta=math.log(256)+2*math.log(r)+r*math.log(2*math.e*ratio*5*T/r)
 parameters.append({'h_over_gamma':ratio,'gamma_T':T,'r':r,'r_squared':r*r,'required_gamma_T_rhs':rhs,'log_delta_upper':logdelta,'log_delta_target':-512*(b+7)})
 assert logdelta<=-512*(b+7)
rho=64*math.exp(-6);rootmass=rho*rho/(1-rho);assert rootmass<1
out={'geometry':rows,'parameters':parameters,'KP_root_mass_bound':rootmass,'scope':'Conservative integer geometry and scalar bounds only. Fixed gamma*T and h/gamma make r constant; fixed physical T alone does not when rates are variable input.','wall_seconds':time.perf_counter()-t0}
(O/'geometry_cost_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
