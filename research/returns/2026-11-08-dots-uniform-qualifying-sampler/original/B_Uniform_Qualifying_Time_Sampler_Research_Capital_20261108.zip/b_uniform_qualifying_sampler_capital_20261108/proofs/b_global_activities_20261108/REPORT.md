# A repaired connected-activity sampler at fixed qualifying action

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

8 November 2026. This report records a restricted theorem and its limits. The general all-time problem B remains open.

## Result

For product inputs on a finite open square lattice, static on-site and nearest-neighbor two-qubit Hamiltonian terms, and replacement noise on every site, the connected-interface expansion gives a certified full-output sampler when the explicit accumulated-noise condition below holds. All Hamiltonian terms may be strong and noncommuting; there is no weak-interface or separable-trajectory assumption.

Write the noise generator as gamma sum_i(E_i-Id), where E_i replaces qubit i by I/2. Let h bound the norm of every Hamiltonian term after grouping by its one- or two-site physical support. Delta=5 is a conservative physical path-branching bound on the square lattice. The Hamiltonian, product input, positive gamma, positive time T and requested accuracy epsilon have paid rational encodings, or an equivalently charged certified representation.

Set

    b=8, c=2400,
    r=max(4096,4096(b+7),128(c+3))+ceil(12h Delta T).

The supplied experiment qualifies if

    gamma T >= 4+2ceil(log_2 r)+32(c+4).

The algorithm tests this actual T. It never substitutes a larger physical time. At a qualifying time it samples one n-bit output within total variation epsilon using finite bit work bounded by

    poly(paid input bits, n, numerical action, log(1/epsilon))
       times exp[O(r^2 log(n/epsilon))].

Thus the bound is polynomial in n and1/epsilon for fixed dimensionless action gamma T and fixed ratio h/gamma, with fixed locality. Fixing T and h/gamma alone is insufficient if h and gamma are allowed to grow with n. The polynomial exponent and constants are enormous. No practical speed advantage is established.

## What closes the analytic chain

1. **Exact spatial compatibility.** Switch entire coarse interfaces, keep all internal dynamics and original noise, and take Möbius differences in the interface set. Product input makes disconnected switched components factor exactly. This yields an exact signed hard-core polymer partition function with vertex-overlap incompatibility. Isolated block normalizers are uniformly at least1/2 at the qualifying time, so no division by a rare global-prefix probability occurs.

2. **Trace-normalized local control.** The previously audited finite-patch estimate controls densely marked measurement blocks. The repaired simultaneous spatial response controls sparse marks. Both retain all physical noise and pay the normalized Schatten and physical dimension factors.

3. **The required repair.** A literal source interval rule was found to permit arrival at another site of a multi-site target before the designated path. The final proof does not use that rule. For two-body interactions, first-discovery vertex trees give a direct bijection: before a target is first reached, interval words must avoid its entire strip and every still-undiscovered retained path vertex. Noise letters insert uniquely into those intervals and resum to full-noise propagators. Classical switch labels do not mediate physical propagation. Return histories retain their label dependence and are not discarded.

4. **Convergence and sampling.** The dense and sparse bounds give |w(C)|<=exp(-8|V(C)|). At most64^v connected edge polymers of size v contain a chosen block. The resulting KP bound provides a convergent logarithmic expansion and an exponentially small truncation tail, uniformly for every output prefix. Explicit cluster enumeration, activity precision, stable conditional normalization and finite-bit coins produce the stated full-output TV guarantee.

The proof is distributed across FIRST_DISCOVERY_PROOF.md, SPATIAL_RESPONSE_CANDIDATE.md and FINITE_ALGORITHM.md. The candidate filename is retained for continuity; the first-discovery proof is the governing repaired version.

## Independent checks and correction history

The first independent reviewer completed the repaired word-identity, normalization, scalar, KP and finite-algorithm review with no remaining blocker under the displayed two-body, fixed-qualifying-action scope. A second independent audit also completed the repaired identity, noise lift, path counting, dense/sparse normalization and finite evaluator review. Its report is second_audit/INDEPENDENT_AUDIT.md. The first report is in the sibling b_global_activity_audit_20261108 directory.

The saved diagnostics include:

- Four-qubit exact-switched-dynamics reconstruction, with Möbius/factorization errors below1.6e-14 in floating arithmetic. At short time, an uncertified size-two truncation gives a negative partition approximation while the true one is positive. Exact algebra alone therefore does not justify truncation.
- Three- and five-qubit finite-time first-arrival/noise identities, agreeing to below5e-16 entrywise. These are floating checks, not substitutes for the proof.
- Exact word-language checks on655,516 words with multi-site targets, cycles, alternative paths and two separated buffers, with no failure of the repaired rule.
- A saved explicit failure of the original target-omitting rule. The independent reviewer also found a physical2-by-4 coefficient mismatch and verified its repair through Taylor order12.
- Exact integer/rational checks of the scalar contract, geometry and time-adaptive cluster budget.

WORD_LIFT_LEMMA.md is deliberately retained as superseded history, with its failed source-language import marked. Do not cite its unmodified Section2 as the final proof.

## Remaining all-time evaluator

Stronger physical time can earn stronger activity decay. Choosing a qualifying b adaptively gives tail exponent kappa=b-7 and cluster cutoff m=O(1+log(n/epsilon)/kappa). For fixed rho=h/gamma and sufficiently large tau=gamma T, one can take b=Theta(tau), r=O_rho(tau). This sharpens the dense evaluator's upper bound to

    poly(paid inputs/actions) exp[O_rho(tau^2+tau log(n/epsilon))].

It remains quasipolynomial, rather than polynomial uniformly in tau, before the known global mixing shortcut applies. Early times below the accumulated-noise condition are also not covered. The missing operation is an efficient certified evaluator for connected activities or logarithmic marginals across that scaling interval, including signed cancellation and correlated-input dependence. Restarting a final short interval from a product state is invalid.

ALL_TIME_COST_BOUNDARY.md gives the derivation, exact scalar checks, and scope. These are upper bounds for this evaluator, not computational lower bounds or a claim that no better representation exists.

## Prior and scope

Physical path resummation, hypercontractivity, linked-cluster expansions, KP and log-marginal sampling are established techniques. The cited multi-commutator source is McDonough et al., arXiv:2502.02652v2; the direct two-body proof repairs the multi-site interval issue encountered in importing that source. The noisy-circuit comparison and its nonuniform continuous-time transfer limitation remain acknowledged. No historical-first claim is made.

This report does not cover arbitrary higher-arity local terms, nonunital noise, arbitrary correlated initial states, all physical times, or production-scale speed. It is not a general solution to B.
