"""Independent support-language test for the repaired two-body first-discovery proof.
Tests broad targets, alternative paths, loops and repeated edge occurrences.
"""
import itertools,json,pathlib,time,random
O=pathlib.Path(__file__).resolve().parent;t0=time.perf_counter()
R={0};S={3,4};edges=[(0,1),(0,2),(1,3),(2,4),(1,2),(3,4)];E=[set(x)for x in edges]
paths=[]
def paths_from(v,vs,es):
 if v in S:
  paths.append((tuple(vs),tuple(es)));return
 for j,(x,y)in enumerate(edges):
  if v not in(x,y):continue
  z=y if v==x else x
  if z in vs or z in R:continue
  paths_from(z,vs+[z],es+[j])
paths_from(0,[0],[])
def classify(w):
 seen=set(R);parent={};hit=None
 for pos,k in enumerate(w):
  a,b=edges[k]
  if not(E[k]&seen):return None
  new=E[k]-seen
  if new:
   x=next(iter(new));p=b if x==a else a;seen.add(x);parent[x]=(p,pos,k)
   if hit is None and x in S:hit=x
 if hit is None:return None
 vs=[hit]; es=[];pos=[]
 while vs[-1]not in R:
  p,t,k=parent[vs[-1]];vs.append(p);pos.append(t);es.append(k)
 return (tuple(vs[::-1]),tuple(es[::-1]))
def matches(w,path):
 vs,es=path;k=0
 for j in w:
  if k==len(es):continue
  forbidden=set(vs[k+1:])|S
  if not(E[j]&forbidden):continue
  if j==es[k]:k+=1
  else:return False
 return k==len(es)
count=0;causal=0;nullaccepted=0
for length in range(8):
 for w in itertools.product(range(len(edges)),repeat=length):
  actual=classify(w);found=[p for p in paths if matches(w,p)];count+=1
  if actual is not None:
   causal+=1;assert found==[actual],(w,actual,found)
  elif found:nullaccepted+=1
# Long repeated/cyclic words test no late rediscovery or changed first-target issue.
rng=random.Random(20261108)
for _ in range(10000):
 w=[rng.randrange(len(edges))for j in range(24)];actual=classify(w);found=[p for p in paths if matches(w,p)]
 if actual is not None:assert found==[actual],(w,actual,found)
# Literal future-factor-only alphabet fails for this concrete word.
w=(1,3,0,2);claimed=((0,1,3),(0,2));actual=classify(w)
assert actual==((0,2,4),(1,3));assert not matches(w,claimed)
out={'scope':'Finite exact support-language check of repaired two-body first-discovery intervals, not a general proof.','graph_edges':edges,'root':sorted(R),'target':sorted(S),'possible_first_hit_paths':paths,'exhaustive_words_lengths_0_through_7':count,'causal_words':causal,'null_words_admitted_but_discarded':nullaccepted,'long_random_words_length24':10000,'causal_identity_failures':0,'literal_alphabet_counterexample':{'word_edges':[edges[k]for k in w],'premature_target_path':actual,'wrong_path_rejected_by_repair':claimed},'wall_seconds':time.perf_counter()-t0}
(O/'discovery_language_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
