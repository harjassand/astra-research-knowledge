import numpy as np
from scipy.sparse import csr_matrix,kron,eye
from scipy.sparse.linalg import expm_multiply
from itertools import product
from pathlib import Path
import json,time
n=4;d=2**n
I=np.eye(2);X=np.array([[0,1],[1,0]]);Y=np.array([[0,-1j],[1j,0]]);Z=np.diag([1,-1]);paulis=[X,Y,Z]
def op(dic):
 a=np.ones((1,1),complex)
 for i in range(n):a=np.kron(a,dic.get(i,I))
 return csr_matrix(a)
H0=.23*op({0:X})+.17*op({1:Z})-.19*op({2:Y})+.11*op({3:X})
edges=[(0,1),(1,3),(2,3),(0,2)]
terms=[.7*op({0:X,1:X}),-.6*op({1:Z,3:X}),.8*op({2:Z,3:Z}),.5*op({0:Y,2:Y})]
Id=eye(d,format='csr');Isuper=eye(d*d,format='csr')
noise=csr_matrix((d*d,d*d),dtype=complex)
for i in range(n):
 for p in paulis:
  P=op({i:p});noise+=(kron(P.conj(),P)-Isuper)/4
psi=np.kron(np.kron(np.kron(np.array([1,1])/np.sqrt(2),[1,0]),[1,0]),[1,0]).astype(complex)
rho=np.outer(psi,psi.conj());vec=rho.reshape(-1,order='F')
def components(mask):
 left=set(i for i in range(4) if mask>>i&1);out=[]
 while left:
  e=left.pop();part={e};verts=set(edges[e]);changed=True
  while changed:
   changed=False
   for f in list(left):
    if set(edges[f])&verts:left.remove(f);part.add(f);verts.update(edges[f]);changed=True
  out.append((sum(1<<e for e in part),verts))
 return out
comps={a:components(a) for a in range(16)}
connected=[a for a in range(1,16) if len(comps[a])==1]
subsets={a:[b for b in range(16) if b&a==b] for a in range(16)}
start=time.time();max_fact=0;max_rec=0;min_trunc=(1e9,None);records=[]
for gamma,T in [(1.,.8),(.1,.2),(.1,1.4)]:
 probs=[];min_eig=1
 for mask in range(16):
  H=H0.copy()
  for j,h in enumerate(terms):
   if mask>>j&1:H+=h
  L=-1j*(kron(Id,H)-kron(H.T,Id))+gamma*noise
  final=expm_multiply(T*L,vec).reshape((d,d),order='F')
  min_eig=min(min_eig,float(np.linalg.eigvalsh(final).min()))
  probs.append(np.diag(final).real)
 probs=np.array(probs)
 for measured in [(0,1,2,3),(0,2),(1,)]:
  for bits in product([0,1],repeat=len(measured)):
   inds=[x for x in range(d) if all((x>>(n-1-i)&1)==b for i,b in zip(measured,bits))]
   G=probs[:,inds].sum(axis=1)*2**len(measured)
   F=G/G[0]
   delta=np.array([sum((-1)**((a^b).bit_count())*F[b] for b in subsets[a]) for a in range(16)])
   for a in range(16):
    pred=np.prod([delta[c] for c,v in comps[a]])
    max_fact=max(max_fact,abs(delta[a]-pred))
   recon=sum(np.prod([delta[c] for c,v in comps[a]]) for a in range(16))
   max_rec=max(max_rec,abs(recon-F[-1]))
   # Keep polymers of at most two vertices; this is an uncertified truncation.
   trunc=sum(np.prod([delta[c] for c,v in comps[a]]) for a in range(16) if all(len(v)<=2 for c,v in comps[a]))
   if trunc<min_trunc[0]:min_trunc=(float(trunc),dict(gamma=gamma,T=T,measured=measured,bits=bits,exact_normalized_partition=float(F[-1])))
 records.append(dict(gamma=gamma,T=T,min_state_eigenvalue=min_eig))
out=dict(scope='Four-qubit floating diagnostic; exact algebra is proved separately, no interval certificate or global sampler.',
 max_component_mobius_factorization_error=max_fact,max_partition_reconstruction_error=max_rec,
 smallest_uncertified_two_vertex_truncation=min_trunc[0],truncation_case=min_trunc[1],
 physical_runs=records,elapsed_seconds=time.time()-start)
Path(__file__).with_name('mobius_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
