# Second audit of the connected-activity closure

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

8 November 2026. Reviewed-file hashes are in `reviewed_files.json`.

## Disposition

The original literal source-alphabet import was **not correct for the multi-site target strips used here**. Independent review found a concrete multiplicity defect, described below. The replacement `FIRST_DISCOVERY_PROOF.md` supplies a direct, target-inclusive proof for the actual at-most-two-body model. I find its word bijection, full-noise lift, central-label norm accounting and path factors sound under its explicit assumptions.

Combined with the previously checked finite-patch estimate, the corrected dense/sparse bounds and paid cluster evaluator support a **qualifying fixed-action existence result** for the specified two-dimensional two-body model. This is not a uniform all-time polynomial sampler, a practical algorithm, a higher-arity theorem or a historical-priority claim. The direct repaired proof supersedes the source-dependent word-language assertion; old conditional files must not be cited alone as the final proof.

## 1. The actual defect and why tests needed multi-site targets

Take root R={0}, a target S={3,4}, and the retained path 01,13. A future-path-factor-only exclusion initially forbids {1,3} but can allow the word 02,24 before 01,13. That word already reached target site4 through a different path. It cannot also belong to the designated first-arrival skeleton01,13. This is a formal multiplicity error, not a rare numerical condition or final-support cancellation.

The other reviewer independently found a corresponding nonzero Taylor discrepancy: −128 versus −96 at order4 under the literal old alphabet. I did not reproduce those exact coefficients; my independent support-language test reproduces the wrong assignment and its rejection by the repair. The defect concerns importing the displayed source language unchanged for broad strips, not a claim here that the source's ultimate locality bound is false.

## 2. Why the two-body discovery repair works

Initialize the visited set to the entire complement of the selected buffers. A two-site factor in a geometrically non-null word has at most one new endpoint. Record that new vertex's unique parent edge occurrence. On-site factors and edges between already visited vertices introduce no vertices. For each target take the path to its first discovered vertex.

For a chosen path and its current progress, an interval must avoid all still-undiscovered vertices of that path and the **whole target** until first arrival. After arrival that target imposes no further exclusion.

Necessity is support-theoretic: touching an undiscovered retained vertex earlier would give an earlier discovery, and touching any part of the unfinished target would give an earlier target visit. Sufficiency follows by induction: the next skeleton edge has a visited parent and an unvisited child, and no other buffer's skeleton can visit that child. Thus it is exactly the designated discovery occurrence. The selected path and its occurrence positions are unique. Extra admitted interval words can have a disconnected prefix, which evaluates to zero; they do not become alternative causal skeletons.

Separated buffers and the enlarged exterior root are essential. A path cannot leave its buffer and then continue its ancestry through another buffer, since exterior vertices were visited at initialization. Paths therefore have disjoint Hamiltonian edge factors, although they can share a root-side physical vertex. Higher-arity terms can discover several vertices at once and are not covered by this proof.

## 3. Full noise and returning paths

Deleting every D_i=gamma(E_i−Id) letter leaves a Hamiltonian word with exactly the same support-based discovery classification. If that word has a disconnected prefix, inserting D_i cannot enlarge its preceding physical support and cannot rescue it. If it never touches a selected strip, no corresponding label was used; D_i introduces no labels, so the Fourier coefficient is zero.

For every remaining word, the skeleton occurrences survive deletion in a unique order. Cutting at those occurrences assigns each D_i to one and only one interval. Conversely every interval permits every physical D_i. Expanding each full-noise allowed-subset propagator therefore reproduces each formal mixed word with its correct T^n/n! coefficient. No noise is commuted through Hamiltonian terms or removed from an interval.

One must not discard an algebraically zero Hamiltonian word before inserting noise, or discard words whose physical support later returns to the source. Those would be stronger, false statements. For example, the independent integer test has C_A C_B C_B C_A(Z_source)=16 Z_source. The target physical support has disappeared, but its Boolean label dependence remains.

The same repaired two-body discovery construction can be used with final physical nested-commutator probes instead of label extraction. Untouched targets are then killed by those probes, with their usual factors2. Consequently the two-body finite-patch locality dependency also has a direct target-inclusive repair, rather than resting on the defective literal alphabet import.

## 4. Norm and multiplicity accounting

Every interval retains the full physical depolarization and a subset of Hamiltonian factors. It is hypercontractive along p(t)=1+(p0−1)e^(2 gamma t), branchwise in the classical labels. The normalized direct-sum comparison pays 2^[K(1/p_before−1/p_after)]; these factors telescope. Each skeleton commutator costs2h at the current exponent. Extracting the normalized label Fourier coefficient is contractive, and converting it to the Boolean difference pays2^K. A shared label is a central coefficient, not a physical propagation vertex.

For paths of lengths l_i, order-preserving shuffles number (sum l_i)!/product l_i!. The simplex factor cancels this into the product of individual path time factors. No factorial or repeated-use factor is missing. An explicit path count chooses the first inside-buffer boundary vertex, its root-side neighbor, then its remaining steps. This is at most |boundary B| Delta^l; the additional |boundary S| factor used by the report is safe. Grouped physical edge terms and the meaning of h must be retained.

The sparse bound pays Fourier extraction, label norm loss, physical dimension conversion, all marked subsets and local denominators. With e≤2v these give128^v before the 3^s and spatial decay factors. The dense bound gives16^v exp(−c eta v). The choices eta=1/200, q≥v/512, c=200(b+4) and log(delta)≤−512(b+7) leave sufficient slack to sum both envelopes. Rooted polymer counting64^v and b=8 give modified KP root mass below0.029912, not a borderline inequality.

## 5. Exact normalization and finite work

Switching interfaces off factorizes the corresponding Hamiltonian components because the original input, noise and effect factor across those components. Boolean Möbius inversion then restores the full coupled marginal exactly. Compatibility is vertex-disjointness of switched-edge polymers, not alleged exact independence of distant regions under the unswitched dynamics.

The isolated normalized factors z_v are bounded below by1/2 uniformly for all requested marginal assignments at the qualifying action. Keeping the explicit2^(−|S|) factor separate avoids division by the tiny true prefix probability. KP convergence fixes a zero-free logarithm branch and a tail bounded by n exp(−m).

I checked the finite enumeration accounting: connected vertex animals have exponentially many depth-first encodings; polymer multisets with total multiplicity≤m have exp(O(m)) count from the generating product at z=1/128. A cluster union is connected. The alternating connected-graph coefficient has an O(3^R) subset recurrence and O(m²) bits, including repeated incompatible polymer copies and their multiplicity factorials. No n^m or all-graphs enumeration is silently called free.

Each activity requires2^e switched evolutions on at most r²v qubits. Dense rational exponential evaluation, observable norm conversion, inclusion-exclusion cancellation and denominator precision are paid. With m=O(log(n/epsilon)), work exp(O(r²m)) is polynomial only when r is fixed. Certified log marginals followed by normalized two-branch exponentials and paid finite-bit coins give positive sampling without rare-prefix division.

## 6. Independent checks and their limits

- `check_noise_forest.py`: exact integer Taylor coefficients on a five-qubit, two-buffer geometry through order8, both with and without full depolarization. Every coefficient agreed with the free-interval construction. Return histories were retained. Wall time about0.0123s, excluding imports.
- `check_discovery_language.py`: all335,923 words of length0–7 on a six-edge graph with a broad target, alternative paths, cross edge, target-target edge and repetitions. Every causal word occurred exactly once with its actual repaired discovery path. Another10,000 words of length24 passed. Wall time about0.892s. Admitted disconnected words were counted and explicitly treated as null.
- `check_geometry_cost.py`: closed L1-buffer intersection counts were16 per marked core for eight side lengths, below the conservative50. Scalar choices and KP mass were independently evaluated. These finite checks support, but do not replace, the general induction proof.

## 7. Scope, impractical constants and prior

Fixing numerical physical time T and h/gamma alone does not fix the action when rates vary as inputs. The useful parameter statement fixes gamma T and h/gamma (equivalently the relevant dimensionless actions). With h/gamma=1 and Delta=5, the conservative doubling recipe gives gamma T=131,072, r=8,171,904 and r²=66,780,014,985,216. No practical computation or speed advantage is established.

When T scales toward the entropy mixing cutoff, r grows and dense activity work is not uniformly polynomial. Restarting a final fixed interval from a product input is invalid because the true intermediate state is correlated. The uniform-output shortcut covers sufficiently late times, not the intervening gap; early actions below the sufficient condition also remain uncovered.

McDonough et al., https://arxiv.org/html/2502.02652v2 , supply the established locality/resummation framework; the target-inclusive two-body proof here is an explicit repair rather than a literal unchanged import. Nelson et al., https://arxiv.org/html/2610.00548v2 , already provide polymer, hypercontractive and log-marginal sampling machinery for discrete circuits. Their fixed per-layer-noise result cannot simply be passed through arbitrarily fine Trotterization: p≈gamma Delta t tends to zero and its threshold/runtime are not uniform in that limit. The present audit does not establish novelty or supersede their separate all-depth evaluator.
