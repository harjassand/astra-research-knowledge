# Explicit word-level reduction for the spatial response

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

8 November 2026. SUPERSEDED for the two-body theorem by FIRST_DISCOVERY_PROOF.md. Review found that the literal source multi-site-target interval formula needs repair; do not treat Section 2 below as verified unchanged. This supplements the candidate rather than silently promoting it to an established theorem. Its exact remaining source obligation is identified below. No all-time evaluator is supplied here.

## 1. Physical alphabet and the observation map

There are finitely many physical qubits and K classical binary labels sigma. Work in the direct sum of the physical matrix algebra over the 2^K label assignments. Write C_X(sigma)=i[H_X(sigma), .], with physical support X and branchwise norm at most h. All label dependence is central. Let D_i=gamma(E_i-Id) be the original one-site replacement generator. The formal alphabet consists of distinct letters c_X and d_i, even if some of their evaluated operators vanish.

Fix q physical target strips S_j, inside separated buffers B_j. Every term carrying the selected label j has its complete physical support inside S_j. Define the enlarged root R_*=V\\(union_j B_j). The initial physical support lies in R_* and the initial observable is independent of every label. Enlarging the root in this way is conservative: the initial observable need not act nontrivially on all of R_*.

Let Q be the all-K nonconstant Fourier coefficient, Q(X)=2^{-K} sum_sigma (-1)^{K-|sigma|} X(sigma). The original finite difference is 2^K Q. If a word never uses a factor controlled by one selected label, Q kills it. This remains true if the word uses other, unselected labels arbitrarily often.

A Hamiltonian word is geometrically noncausal if the support-only algorithm of the primary source either encounters a factor disjoint from the root and all preceding factor supports, or fails to visit at least one selected target strip. No word is discarded because its *evaluated* Hamiltonian product happens to vanish, or because its final physical operator no longer acts on a visited target.

## 2. The precise source-language statement used

For each causal Hamiltonian word, run the support-only forest algorithm with root R_* and targets S_j. Retain its irreducible skeleton Lambda=(Lambda_1,...,Lambda_l). For each interval k, let A_k(Lambda) be the source's allowed alphabet, consisting of Hamiltonian factors avoiding the source's disallowed vertex set V_k(Lambda). Thus source Eq. (31), with its explicit disallowed sets, is used without changing a factor support or adding a switch vertex.

The required form of source Lemma 4.5 is the following statement in the vector space spanned by finite Hamiltonian words, modulo the span of geometrically noncausal words:

    sum_(causal Hamiltonian words w) w
      = sum_Lambda sum_(u_k in A_k(Lambda)^*)
               u_l c_(Lambda_l) ... c_(Lambda_1) u_0.

This is a coefficient-by-coefficient formal-language identity; in a fixed word length all sums are finite. In particular:

(a) Each geometrically causal word has exactly one retained skeleton and exactly one decomposition into skeleton occurrences and allowed intervals.

(b) Any extra word admitted by a right-hand allowed alphabet is geometrically noncausal, rather than merely a word canceled by the particular final commutators in the original application.

Source Lemma 4.5 gives uniqueness in its proof and explains extras through the support-only construction. The current review must confirm this exact strength, especially (b) on alternative paths/cycles. Importing only the displayed operator equality with the source's final nested commutators would not suffice, since our final observation map is Q instead.

## 3. Every geometrically noncausal word remains killed after noise insertion

Let erase(w) delete all d letters in a mixed word w.

If erase(w) first becomes noncausal because c_X is disjoint from the enlarged root and preceding Hamiltonian supports, then immediately before that factor the evaluated operator is supported inside their union. Each earlier d_i maps operators on a fixed physical support back into that same support and introduces no labels. Therefore C_X annihilates the current operator. All subsequent operations leave zero.

If erase(w) has no such disconnected step but never visits target S_j, no c_X carrying label j appears, because every such support is contained in S_j. The initial observable is label independent and every d_i is label independent. The evaluated word remains independent of j, so Q annihilates it.

These cover the geometric null words in Section 2. They do not assert that an algebraically vanishing Hamiltonian word remains zero after insertion. Nor do they assert that final physical support records the labels already used. Both stronger assertions are false in general and are unnecessary.

## 4. Explicit deletion/insertion bijection

Take a mixed word w whose erased Hamiltonian word is geometrically causal. By Section 2(a), locate the uniquely specified occurrences of its irreducible Hamiltonian skeleton in erase(w). Their corresponding positions in w are unique, since erasure preserves the order and identity of every Hamiltonian occurrence.

Split w immediately before and after these skeleton occurrences. Each interval is a free word in the enlarged alphabet

    A'_k(Lambda)=A_k(Lambda) union {d_i : all physical sites i}.

Conversely, concatenate any such interval words and the indicated skeleton occurrences. Erasing d letters produces the corresponding allowed Hamiltonian word. If that word is causal, Section 2(a) assigns exactly this unique skeleton split. If it is an extra geometric-null word, Section 3 shows that Q kills its full mixed-word evaluation.

Thus, after Q, there is a coefficient-preserving bijection between all mixed causal words and the free-interval expansion. No d letter is commuted through a Hamiltonian factor. No physical noise term is omitted. Different insertions that happen to give equal evaluated matrices are still different formal words, as required by the Taylor expansion.

After multiplying a length-n word by T^n/n!, the resulting equality is

    Q exp[T(D+sum_X C_X)] M
      = sum_Lambda Q integral_(0<t_1<...<t_l<T)
          exp[(D+C_(A_l))(T-t_l)] C_(Lambda_l) ...
          C_(Lambda_1) exp[(D+C_(A_0))t_1] M dt.

Here C_(A_k) is the sum of all allowed physical Hamiltonian commutators in that interval. Finite-dimensional absolute convergence justifies first grouping by total word length and then the exponential/Duhamel resummation. For time-dependent terms, the corresponding ordered integrals give the same deletion/insertion argument, but the current theorem only needs the static case.

## 5. Norm estimate, with every label factor paid

Each free-interval generator retains the full physical D and a subset of the original bounded Hamiltonian factors. For the schedule p(t)=1+(p_0-1)exp(2gamma t), physical hypercontractivity applies separately to every label branch. Passing between normalized direct-sum p and q norms costs at most 2^{K(1/p-1/q)}. These costs telescope over the intervals. Each skeleton insertion costs at most 2h in its current Schatten exponent.

Q is a normalized Fourier average, hence a contraction from the direct-sum Schatten-p norm to the physical Schatten-p norm. Multiplying it by 2^K recovers the Boolean finite difference. The initial observable has the same physical and direct-sum norm, because it is label independent.

The root R_* contains all sites outside the selected buffers. Consequently the source's retained paths for different targets live in separated buffers and have disjoint Hamiltonian factors. Their valid interleavings are counted by the multinomial factor, which cancels the ordered-simplex factorial exactly as in the source. Bounding their norms then gives the product of physical path sums. Using the source's path-count estimate yields

    ||Delta_all Phi_T(M)||_(p_1,tau)
       <= 2^{K(1+1/p_0-1/p_1)} delta(T)^q ||M||_(p_0,tau),

provided p_1-1 <= (p_0-1)exp(2gamma T). The delta used in the spatial candidate is a conservative bound on each physical path sum. The labels are never treated as physical graph vertices.

## 6. What is and is not now reduced

If the precise geometric-language form in Section 2 is accepted, Sections 3–5 are an explicit proof of its full-noise/shared-label lift and the claimed spatial hypercontractive response. The independent finite-activity/counting analysis then gives the conditional fixed-action sampler.

The exact tree checks in word_lift_results.json verify the lifted identity at finite time on three- and five-qubit branches. The independent reviewer additionally verified Taylor coefficients through order 12, including histories that visit every label and return to the root. These are useful failure tests, not a substitute for Section 2 on general physical graphs.

Source: McDonough, Yin, Lucas and Zhang, arXiv:2502.02652v2, Algorithm 1, Proposition 4.2, Lemmas 4.5 and 4.7, Theorem 4.4. Primary text re-opened on 8 November 2026: https://arxiv.org/html/2502.02652v2 . This document describes the adaptation in original words and retains the source obligation explicitly.
