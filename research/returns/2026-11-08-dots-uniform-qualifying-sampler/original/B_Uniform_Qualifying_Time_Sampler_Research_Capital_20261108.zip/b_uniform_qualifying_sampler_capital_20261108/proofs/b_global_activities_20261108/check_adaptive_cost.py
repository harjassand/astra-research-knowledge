"""Exact scalar accounting, not a simulation or a lower bound on all algorithms."""
from fractions import Fraction
import json, math, pathlib
P=pathlib.Path(__file__).parent

def clog2(x): return (x-1).bit_length()
def ceilq(x): return -(-x.numerator//x.denominator)
def params(tau,b,ratio=Fraction(1),Delta=5):
 c=200*(b+4)
 r=max(4096,4096*(b+7),128*(c+3))+ceilq(12*ratio*Delta*tau)
 rhs=4+2*clog2(r)+32*(c+4)
 return {'b':b,'c':c,'r':r,'condition_rhs':rhs,'qualifies':tau>=rhs}
def best(tau):
 lo,hi=8,max(8,tau//6400+1)
 if not params(tau,8)['qualifies']: return None
 while lo<hi:
  mid=(lo+hi+1)//2
  if params(tau,mid)['qualifies']:lo=mid
  else:hi=mid-1
 return params(tau,lo)
rows=[]
for tau in [2**k for k in range(17,25)]:
 p=best(tau); f=params(tau,8)
 # L is log(10n/delta_log), represented directly to avoid constructing n.
 L=8*tau
 kap=p['b']-7
 ma=max(1,(L+kap-1)//kap)
 mf=L
 rows.append({'gamma_T':tau,'h_over_gamma':1,'Delta':5,'log_accuracy_budget_L':L,
   'adaptive':{**p,'tail_exponent':kap,'cluster_cutoff':ma,'dense_site_budget':p['r']**2*ma},
   'fixed_b8':{**f,'tail_exponent':1,'cluster_cutoff':mf,'dense_site_budget':f['r']**2*mf},
   'maximal_b_check':not params(tau,p['b']+1)['qualifies']})
out={'scope':'Exact scalar checks of an optimized upper bound; no large physical system was simulated and no lower bound on alternative evaluators is implied.',
 'rows':rows,'all_maximality_checks':all(r['maximal_b_check'] for r in rows)}
(P/'adaptive_cost_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
