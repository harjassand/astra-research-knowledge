"""Exhaustive combinatorial failure test of a TWO-BODY word-language identity.
No matrix cancellation is used. This is a finite check, not its general proof.
"""
from itertools import product
from collections import defaultdict
from pathlib import Path
import json, random,time
P=Path(__file__).parent

def paths(edges,root,target):
 adj=defaultdict(list)
 for j,e in enumerate(edges):
  if len(e)==2:
   u,v=e;adj[u].append((v,j));adj[v].append((u,j))
 out=[]
 def dfs(u,vs,es):
  for v,j in adj[u]:
   if v in root or v in vs:continue
   nvs=vs+(v,);nes=es+(j,)
   if v in target:out.append((nvs,nes))
   else:dfs(v,nvs,nes)
 for u in root:dfs(u,(),())
 return out

def ref(word,edges,root,targets):
 reached=set(root);parent={};answer=[None]*len(targets)
 for j in word:
  e=set(edges[j])
  if not e&reached:return None
  new=e-reached
  if new:
   assert len(new)==1
   v=next(iter(new));u=next(iter(e&reached));parent[v]=(u,j);reached.add(v)
   for i,S in enumerate(targets):
    if answer[i] is None and v in S:
     vs=[];es=[];at=v
     while at not in root:
      vs.append(at);at,jj=parent[at];es.append(jj)
     answer[i]=(tuple(reversed(vs)),tuple(reversed(es)))
 return tuple(answer)

def accepts(word,edges,targets,pf,repair=True):
 k=[0]*len(pf)
 for j in word:
  forbidden=set()
  for i,(vs,es) in enumerate(pf):
   if k[i]<len(es):
    forbidden.update(vs[k[i]:])
    if repair or k[i]==len(es)-1:forbidden.update(targets[i])
  if not set(edges[j])&forbidden:continue
  found=False
  for i,(vs,es) in enumerate(pf):
   if k[i]<len(es) and j==es[k[i]]:
    k[i]+=1;found=True;break
  if not found:return False
 return all(k[i]==len(pf[i][1]) for i in range(len(pf)))

def check(name,edges,root,targets,maxlen,nrandom=0):
 families=list(product(*(paths(edges,root,S) for S in targets)))
 causal=complete=checked=0;bad=[]
 def one(w):
  nonlocal causal,complete,checked
  checked+=1;r=ref(w,edges,root,targets)
  if r is None:return
  causal+=1
  acc=[pf for pf in families if accepts(w,edges,targets,pf)]
  expected=[] if None in r else [r]
  if expected:complete+=1
  if acc!=expected:
   # family enumeration order cannot matter when expected length <=1.
   bad.append({'word':w,'reference':r,'accepted':acc})
 for l in range(maxlen+1):
  for w in product(range(len(edges)),repeat=l):one(w)
 rng=random.Random(8192)
 for _ in range(nrandom):one(tuple(rng.randrange(len(edges)) for _ in range(12)))
 return dict(name=name,word_count=checked,causal_count=causal,all_targets_visited=complete,
  path_family_count=len(families),failures=bad[:3],failure_count=len(bad))
start=time.time()
rows=[check('multisite alternative paths and target cycle',[(0,1),(1,3),(0,2),(2,4),(1,2),(3,4)],{0},[{3,4}],7,10000),
 check('two separated multisite buffers',[(0,1),(1,2),(1,3),(2,3),(0,4),(4,5),(4,6),(5,6)],{0},[{2,3},{5,6}],6,10000)]
edges=[(0,1),(1,3),(0,2),(2,4)];w=(2,3,0,1);pf=(((1,3),(0,1)),)
literal={'word_edges':[edges[j] for j in w], 'designated_path_edges':[edges[j] for j in pf[0][1]],
 'literal_accepted':accepts(w,edges,[{3,4}],pf,False),'repaired_accepted':accepts(w,edges,[{3,4}],pf,True),
 'actual_first_arrival_path':ref(w,edges,{0},[{3,4}])}
out={'scope':'Finite exact word checks. General identity requires the accompanying first-discovery proof.',
 'cases':rows,'literal_rule_counterexample':literal,'seconds':time.time()-start}
(P/'first_discovery_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
assert all(r['failure_count']==0 for r in rows)
assert literal['literal_accepted'] and not literal['repaired_accepted']
