# Audit of time composition and activity-oracle shortcuts

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

8 November 2026. Continuation of the independently reviewed fixed-qualifying-action construction. No general all-time polynomial sampler is claimed. This note gives exact obstructions to particular shortcuts, a useful stronger mixing bound, and a sharper local-oracle precision target. These are not complexity lower bounds on other algorithms.

## 1. An exact obstruction to composing visible output laws

A classical sampler for the output distribution of one time interval is not a transition kernel for the quantum state in the next interval. The following example is fully within the static nearest-neighbor, two-body, product-input, every-site-replacement model.

Take two qubits, initial state |00><00|, Hamiltonian H=J X_1 X_2, and generator

    L(rho) = -i[H,rho] + gamma sum_i(E_i(rho)-rho).

Let z(t)=<Z_1>=<Z_2> and w(t)=<Z_1 Z_2>. Put omega^2=4J^2-gamma^2/4 and assume 0<gamma<4J. Direct closure of the two observable equations gives

    z(t)=exp(-3gamma t/2)[cos(omega t)+(gamma/(2omega))sin(omega t)],
    w(t)=exp(-2gamma t).

The output law in order 00,01,10,11 is

    ((1+2z+w)/4, (1-w)/4, (1-w)/4, (1-2z+w)/4).

Suppose an interval ends at t and its exact computational-basis output law is retained, but its off-diagonal density-matrix entries are discarded. This is more information than retaining independent single-bit marginals. Evolving that diagonal state for a further interval t gives z_wrong(2t)=z(t)^2 and w_wrong(2t)=w(2t). The true answer has z(2t). Their difference is exactly

    z(2t)-z(t)^2 = -(4J^2/omega^2) exp(-3gamma t) sin^2(omega t).

Hence the pairwise output-TV error is

    delta = (2J^2/omega^2) exp(-3gamma t) sin^2(omega t).

For rational J=1, gamma=1/10 and t=4/5, delta=0.3932357419374382. A dense Lindblad calculation agrees with the analytic probabilities to 1.12e-16; see `composition_results.json`.

This failure is not confined to early times. For nonzero rational J,gamma,t in the underdamped range, omega t is nonzero algebraic, so it is not an integer multiple of pi. Thus delta remains positive at arbitrarily large fixed rational slab times, although it becomes extremely small.

Place M independent copies on disjoint nearest-neighbor edges of a square lattice. Their initial state is still a physical product and the Hamiltonian is static and local. Testing the empirical frequency of outcome 00 distinguishes the true and restarted product laws. Hoeffding's inequality gives

    TV(P_true^M,P_restart^M) >= 1-2 exp(-M delta^2/2).

Therefore an n-independent tiny per-slab error is not a uniform global-TV argument: sufficiently many independent copies amplify it. In particular, merely applying the fixed-action sampler repeatedly to computational-basis output laws does not solve the long-time problem. This is a counterexample to that composition operation, not a hardness result; this two-qubit model itself is easy to sample exactly.

## 2. Correlated intermediate input breaks the exact baseline factorization

The connected-activity identity used an original product input. A late-time interval starts from a correlated quantum state. Turning off every cross-block Hamiltonian during that interval does not erase correlations already present in its input.

In the same rational two-qubit example, take the true state at t=4/5, switch H off, and apply only the original local noise for another interval of length t. With each qubit as a separate block, the normalized joint 00 probability is

    G_empty = 1+2 exp(-gamma t)z(t)+exp(-4gamma t).

The product of the isolated one-qubit normalizers is

    z_1 z_2 = [1+exp(-gamma t)z(t)]^2.

The exact finite check gives G_empty=1.7200869272874693 and z_1 z_2=0.9939470775075432, so F_empty=G_empty/(z_1 z_2)=1.7305618842411812, not one.

Thus the former empty-edge baseline and disconnected-component factorization cannot simply be reused after a time cut. One would need a paid representation of the correlated input, with its own compatible activity structure or quantum boundary data. Restarting with a product state changes the experiment. Allowing larger blocks can absorb particular local correlations but is not, by itself, a uniform closure theorem for arbitrary evolved inputs.

## 3. Patch TV mixing does not give logarithmic accuracy

Even an easy noninteracting example defeats a black-box conversion from small state/output TV to an accurate log marginal.

Set H=0, start N qubits in |0>, let tau=gamma T and q=exp(-tau). The normalized all-zero output probability is

    G(0^N)=2^N P(0^N)=(1+q)^N,
    log G=N log(1+q).

The output TV to uniform is at most

    (1/2) sqrt((1+q^2)^N-1)

by the exact chi-square divergence. Set N=2^(4m) and rational tau=2m. The TV bound tends to zero, while log G grows exponentially in m. For example:

- N=1,048,576, tau=10: TV upper bound0.023258, but log G=47.6042.
- N=1,099,511,627,776, tau=20: TV upper bound0.001081, but log G=2266.2624.

No large state was instantiated to obtain these values; they are evaluations of the displayed scalar formulas. The model is trivially sampleable and its activities cancel when normalized appropriately. The counterexample concerns only the proposed black-box TV-to-log shortcut.

For q<=1, log(1+q)>=q/2. Consequently approximating this log G by zero within delta requires

    tau >= log[N/(2delta)].

Thus a generic local mixing replacement by uniform does not deliver inverse-global-size log precision merely because the patch has modest volume.

## 4. Stronger relative mixing is available, but still insufficient here

There is a useful uniform relative-operator estimate, derived from the same hypercontractivity and spectral-gap assumptions already used in the checked proof. Let sigma_t=2^N rho_t on a patch of N qubits. For any initial density matrix,

    ||sigma_0-I||_(1+1/N,tau_norm) <= 3.

Spend (log N)/(2gamma) evolving from exponent 1+1/N to2. Evolve the trace-zero part through the remaining middle interval using the L2 spectral gap gamma; Hamiltonian commutators are skew-adjoint and do not change that dissipation estimate. Spend another (log N)/(2gamma) evolving from2 toN+1. Final normalized-Schatten-to-operator-norm conversion costs at most2. Therefore, for tau>=log N,

    ||2^N rho_T-I||_infinity <= 6N exp(-tau).

Every normalized computational-basis marginal G then obeys |G-1|<=6N exp(-tau). If the bound is at most1/2, setting log G to zero has error at most12N exp(-tau).

This is stronger than a TV statement and applies even to correlated input. Nevertheless obtaining the activity evaluator's required delta-level logarithmic precision still asks for tau of order log N+log(1/delta). With delta inverse-polynomial in the global n, this is still the global logarithmic-time scale. At intermediate tau, the residual may be tiny but not small enough to omit uniformly over all output prefixes. The already available global-TV shortcut is at least as relevant at sufficiently late times.

## 5. A sharper certified precision target for local activity evaluation

The first finite algorithm used a deliberately crude per-activity error budget involving 2^(m^2), from bounding individual Ursell coefficients before summation. This is sufficient but not necessary for the quantum-evolution oracle.

Suppose the exact activities satisfy |w(C)|<=exp(-b v(C)), b>=8. Require an approximation error

    |delta w(C)| <= eta exp(-b v(C)),    0<eta<=1.

Along the straight interpolation between exact and approximate weights, magnitudes are at most2 exp(-bv). There is ample KP slack for this doubled family. The standard pinned-cluster/partition-ratio estimate gives

    |partial log Z / partial w(C)| <= exp(v(C)).

Integrating the derivative and using at most n64^v polymers of size v gives

    |delta log Z| <= eta n sum_(v>=2)[64 exp(-(b-1))]^v.

At b=8, the geometric sum is below0.004. Thus eta=delta_log/(10n) is more than sufficient. The same reasoning applies to the finite retained cluster polynomial by bounding its derivative with the absolute pinned cluster series; separately pay its omitted tail.

The local activity oracle therefore needs O(log(n/delta_log)+b v) precision bits, plus O(v) bits for its Boolean subset subtraction and bounded local denominators. Under the adaptive cutoff v<=O(1+L/(b-7)), and below the global mixing cutoff, this is O(L), rather than O(m^2+L). Exact connected coefficients and naive rational summation can still carry O(m^2) bits. The refinement does not erase those classical arithmetic costs or authorize uncontrolled cancellation.

This sharper accuracy target may help a future low-Pauli-weight or compressed-trajectory evaluator. It does not change the current dense-state exponent: the physical patch still has O(tau^2+tau L) qubits in the adaptive bound. No generic compressed evaluator with the required logarithmic guarantees has been supplied.

## 6. Current conclusion

The fixed-qualifying-action construction remains intact. The present continuation rules out three tempting shortcuts: treating visible output samples as quantum time-boundary data, assuming product baseline factorization after a time cut, and deriving log accuracy from small patch TV. It also provides a stronger relative mixing certificate and a less wasteful activity-oracle precision target.

None of these establishes a universal lower bound, nor does it complete a time-uniform polynomial evaluator. The missing operation remains a certified computation of the signed connected activities (or an exact correlated-input composition) in the intermediate scaling interval. The low-Pauli investigation is a separate historical possibility and was not assumed successful in this report.
