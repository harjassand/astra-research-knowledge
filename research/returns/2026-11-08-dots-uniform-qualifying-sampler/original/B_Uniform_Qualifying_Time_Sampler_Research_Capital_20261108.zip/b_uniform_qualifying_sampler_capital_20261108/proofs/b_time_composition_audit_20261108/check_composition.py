"""Independent exact-formula and dense checks of naive time composition.
All model parameters J=1,gamma=1/10,t=4/5 are rational. Floating expm is
only a cross-check of the displayed analytic two-dimensional observable ODE.
"""
import math,json
import numpy as np
from scipy.linalg import expm
from pathlib import Path
I=np.eye(2,dtype=complex);X=np.array([[0,1],[1,0]],complex)
Y=np.array([[0,-1j],[1j,0]],complex);Z=np.diag([1,-1]).astype(complex)
ops=[I,X,Y,Z];paulis=[np.kron(a,b) for a in ops for b in ops]
J=1.;gamma=.1;t=.8;H=J*np.kron(X,X);d=4
# Build superoperator by applying it to matrix units, column-major vec.
def L(rho,hamiltonian=H):
 out=-1j*(hamiltonian@rho-rho@hamiltonian)
 for i in range(2):
  twirl=sum(np.kron(p,I)@rho@np.kron(p,I) if i==0 else np.kron(I,p)@rho@np.kron(I,p) for p in ops)/4
  out+=gamma*(twirl-rho)
 return out
def matrix(hamiltonian=H):
 out=np.empty((d*d,d*d),complex)
 for k in range(d*d):
  E=np.zeros((d,d),complex);E[k%d,k//d]=1
  out[:,k]=L(E,hamiltonian).reshape(-1,order='F')
 return out
rho0=np.zeros((4,4),complex);rho0[0,0]=1
Phi=expm(t*matrix())
evolve=lambda rho: (Phi@rho.reshape(-1,order='F')).reshape(d,d,order='F')
rho1=evolve(rho0);rho2=evolve(rho1)
dephased=np.diag(np.diag(rho1));restart=evolve(dephased)
probs=lambda rho:np.diag(rho).real
actual=probs(rho2);wrong=probs(restart);tv=np.abs(actual-wrong).sum()/2
omega=math.sqrt(4*J*J-gamma*gamma/4)
def z(s):return math.exp(-1.5*gamma*s)*(math.cos(omega*s)+gamma/(2*omega)*math.sin(omega*s))
def analytic_p(zz,ww):return np.array([(1+2*zz+ww)/4,(1-ww)/4,(1-ww)/4,(1-2*zz+ww)/4])
expected=analytic_p(z(2*t),math.exp(-4*gamma*t));expected_wrong=analytic_p(z(t)**2,math.exp(-4*gamma*t))
assert np.max(np.abs(actual-expected))<1e-13
assert np.max(np.abs(wrong-expected_wrong))<1e-13
assert abs(tv-abs(z(2*t)-z(t)**2)/2)<1e-13
# Switched-off cross interaction in final slab: exact baseline needn't factor
# when its input is the correlated state produced by the first slab.
Phi0=expm(t*matrix(np.zeros((4,4),complex)))
rho_off=(Phi0@rho1.reshape(-1,order='F')).reshape(4,4,order='F')
zlocal=math.exp(-gamma*t)*z(t)
G_off=4*probs(rho_off)[0];product_local=(1+zlocal)**2
F_empty=G_off/product_local
assert abs(G_off-(1+2*zlocal+math.exp(-4*gamma*t)))<1e-13
# Product depolarization: small TV does not grant log-relative precision.
product_cases=[]
for m in [2,5,10]:
 N=2**(4*m);tau=2*m;q=math.exp(-tau)
 logG=N*math.log1p(q)
 log_second_moment=N*math.log1p(q*q)
 tv_upper=min(1.,math.sqrt(math.expm1(log_second_moment))/2)
 product_cases.append({'N':N,'tau_rational':tau,'TV_to_uniform_chi_square_upper':tv_upper,'log_normalized_all_zero_probability':logG})
out={'model':{'J':'1','gamma':'1/10','slab_time':'4/5','initial_state':'|00><00|','Hamiltonian':'X⊗X','noise':'gamma sum_i(E_i-Id)'},'actual_final_probabilities_00_01_10_11':actual.tolist(),'classical_intermediate_restart_probabilities':wrong.tolist(),'TV_restart_error':float(tv),'max_dense_formula_error':float(max(np.max(np.abs(actual-expected)),np.max(np.abs(wrong-expected_wrong)))),'cross_edges_off_in_final_slab':{'normalized_joint_00_G':float(G_off),'product_isolated_normalizers':float(product_local),'F_empty':float(F_empty),'factorization_error':float(G_off-product_local)},'product_H_zero_examples':product_cases,'scope':'Counterexamples to naive classical time composition, product restart and TV-to-log conversion. Not hardness results or counterexamples to the fixed-action sampler.'}
Path(__file__).with_name('composition_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
