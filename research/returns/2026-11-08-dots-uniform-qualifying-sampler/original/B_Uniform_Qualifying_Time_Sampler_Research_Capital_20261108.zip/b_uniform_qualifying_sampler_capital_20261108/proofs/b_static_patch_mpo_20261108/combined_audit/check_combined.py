"""Independent algebra/geometry diagnostics, not an end-to-end sampler implementation."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
from fractions import Fraction
import json,math,itertools,time
import numpy as np
from scipy.linalg import expm
ROOT=Path(__file__).resolve().parent
I=np.eye(2,dtype=complex); X=np.array([[0,1],[1,0]],complex); Y=np.array([[0,-1j],[1j,0]],complex); Z=np.diag([1,-1]).astype(complex)
P=[I,X,Y,Z]
def tensor(xs):
 out=np.array([[1]],complex)
 for x in xs:out=np.kron(out,x)
 return out
def word(n,terms):
 return tensor([P[terms.get(j,0)] for j in range(n)])
def state(v):return (I+sum((float(a)*p for a,p in zip(v,P[1:])),start=np.zeros((2,2),complex)))/2
states=[state(v) for v in [(Fraction(1,3),Fraction(-1,4),Fraction(1,5)),(Fraction(-1,5),Fraction(1,6),Fraction(1,3)),(Fraction(1,4),Fraction(1,3),Fraction(-1,7))]]
effects=[2*state(v) for v in [(Fraction(-1,4),Fraction(1,3),Fraction(1,5)),(Fraction(1,3),Fraction(-1,4),Fraction(1,7)),(Fraction(1,5),Fraction(1,4),Fraction(-1,3))]]
on=[(Fraction(1,5),{0:3}),(Fraction(-2,9),{1:1}),(Fraction(3,13),{2:2})]
ed=[(Fraction(2,7),{0:1,1:1}),(Fraction(-3,11),{1:2,2:3})]
def scalar(n,terms,rhos,As,t,gamma):
 d=2**n; eye=np.eye(d,dtype=complex); eye2=np.eye(d*d,dtype=complex)
 H=sum((float(a)*word(n,p) for a,p in terms),start=np.zeros((d,d),complex))
 L=-1j*(np.kron(eye,H)-np.kron(H.T,eye))
 for i in range(n):
  for k in (1,2,3):
   q=word(n,{i:k});L+=float(gamma)/4*(np.kron(q.conj(),q)-eye2)
 out=(expm(float(t)*L)@tensor(rhos).reshape(-1,order='F')).reshape((d,d),order='F')
 z=np.trace(tensor(As)@out);assert abs(z.imag)<1e-12
 return float(z.real)
checks=[]
for t,gamma in [(Fraction(1,4),Fraction(2,5)),(Fraction(3,5),Fraction(3,7))]:
 vals=[]
 for mask in range(4):vals.append(scalar(3,on+[ed[j] for j in range(2) if mask>>j&1],states,effects,t,gamma))
 # Exact scalar Möbius identity under a different block decomposition.
 z=[scalar(1,[(a,{0:next(iter(p.values()))}) for a,p in on if j in p],[states[j]],[effects[j]],t,gamma) for j in range(3)]
 zero=math.prod(z); w01=(vals[1]-zero)/zero;w12=(vals[2]-zero)/zero;w012=(vals[3]-vals[1]-vals[2]+vals[0])/zero
 reconstructed=zero*(1+w01+w12+w012)
 assert abs(vals[0]-zero)<1e-12
 mapping={0:0,1:1,2:3}; terms4=[(a,{mapping[k]:v for k,v in p.items()}) for a,p in on+ed]
 rho4=[states[0],states[1],I/2,states[2]]; A4=[effects[0],effects[1],I,effects[2]]
 padded=scalar(4,terms4,rho4,A4,t,gamma)
 # Adjoint sign swap: exchanging normalized product boundaries is another legal scalar.
 swapped=scalar(3,[(-a,p) for a,p in on+ed],[a/2 for a in effects],[2*r for r in states],t,gamma)
 checks.append({'t':str(t),'gamma':str(gamma),'original':vals[3],'padded':padded,'block_mobius':reconstructed,'adjoint_query':swapped,'max_error':max(abs(padded-vals[3]),abs(reconstructed-vals[3]),abs(swapped-vals[3]))})
 assert checks[-1]['max_error']<1e-12

# Exhaust all connected subsets of a 3-by-3 square and every rational candidate slope.
points=list(itertools.product(range(3),repeat=2)); geom={'connected_shapes':0,'slopes':0,'max_average_ratio':0.,'nearest_edge_span_max':0}
for mask in range(1,1<<9):
 S={points[i] for i in range(9) if mask>>i&1};seen={next(iter(S))}
 while True:
  more=seen|{p for p in S if any(abs(p[0]-q[0])+abs(p[1]-q[1])==1 for q in seen)}
  if more==seen:break
  seen=more
 if seen!=S:continue
 N=len(S);Q=N*N;total=0
 for a in range(Q):
  layers={p:(Q*p[0]+a*p[1])//Q for p in S};occ={}
  for l in layers.values():occ[l]=occ.get(l,0)+1
  assert len(occ)==max(occ)-min(occ)+1
  total+=sum(x*x for x in occ.values())
  for p,q in itertools.combinations(S,2):
   if abs(p[0]-q[0])+abs(p[1]-q[1])==1:
    span=abs(layers[p]-layers[q]);assert span<=1;geom['nearest_edge_span_max']=max(geom['nearest_edge_span_max'],span)
 geom['connected_shapes']+=1;geom['slopes']+=Q;geom['max_average_ratio']=max(geom['max_average_ratio'],(total/Q)/(N**1.5))
 assert (total/Q)<=64*N**1.5

# Exact original threshold and a conservative fixed-threshold doubling algorithm.
thresholds=[]
def ceil_log2_int(n):return (n-1).bit_length()
for rho in (Fraction(0),Fraction(1,1000),Fraction(1),Fraction(1000),Fraction(10**6)):
 t=4
 while True:
  r=307584+math.ceil(60*rho*t);bound=76932+2*ceil_log2_int(r)
  if t>=bound:break
  t*=2
 # On continuous upper bound 76934+2log2(R0+60rho*t), derivative <1 for t>=4.
 assert t>=4 and t>=bound
 for j in range(20):
  tj=t*(2**j);rj=307584+math.ceil(60*rho*tj)
  assert tj>=76932+2*ceil_log2_int(rj)
 thresholds.append({'rho':str(rho),'tau0_doubling':t,'r_at_tau0':r,'contract_rhs':bound})
out={'scope':'Small independent algebra and exact geometry/cutoff diagnostics; not proof of an asymptotic sampler or runtime benchmark.','noncommuting_Y_product_padding_and_retiling':checks,'geometry':geom,'threshold_checks':thresholds}
(ROOT/'combined_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
