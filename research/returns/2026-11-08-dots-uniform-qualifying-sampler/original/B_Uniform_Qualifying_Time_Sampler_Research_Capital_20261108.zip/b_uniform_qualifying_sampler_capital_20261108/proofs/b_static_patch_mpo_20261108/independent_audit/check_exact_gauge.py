"""Independent exact test of selected-index TT compression.

Uses raw rational cores with deliberately redundant bonds and a huge cancelling
virtual gauge. The compressor never materializes the full tensor. Dense entries
are generated afterward only for validation. No floating-point rank tests.
"""
import itertools
import json
import random
from pathlib import Path

import sympy as s


def bits(x):
    x = s.Rational(x)
    return max(abs(int(x.p)).bit_length(), int(x.q).bit_length(), 1)


def entry(cores, indices):
    v = s.ones(1, 1)
    for a, core in zip(indices, cores):
        v = v * core[a]
    return v[0]


def compress(cores):
    n = len(cores)
    ds = [len(c) for c in cores]
    # K[k] is a basis of actual suffixes after physical position k.
    K = [None] * (n + 1)
    V = [None] * (n + 1)
    K[n], V[n] = [()], s.ones(1, 1)
    for k in range(n - 1, 0, -1):
        candidates = [(a,) + z for a in range(ds[k]) for z in K[k + 1]]
        X = s.Matrix.hstack(*[cores[k][a] * V[k + 1]
                              for a in range(ds[k])])
        pivots = X.rref()[1]
        K[k] = [candidates[j] for j in pivots]
        V[k] = X[:, list(pivots)]
    I = [()]
    out = []
    rank_profile = []
    suffix_sizes = []
    all_J = []
    for k in range(1, n):
        candidates = [p + (a,) for p in I for a in range(ds[k - 1])]
        X = s.Matrix([[entry(cores, p + z) for z in K[k]]
                      for p in candidates])
        rows = X.T.rref()[1]
        if not rows:
            return [[s.zeros(1, 1) for _ in range(ds[0])]] + [
                [s.ones(1, 1) for _ in range(d)] for d in ds[1:]
            ], {"zero": True, "ranks": [0] * (n - 1)}
        cols = X[list(rows), :].rref()[1]
        new_I = [candidates[j] for j in rows]
        J = [K[k][j] for j in cols]
        B = X[list(rows), list(cols)]
        C = X[:, list(cols)] * B.inv()
        old_r, new_r, d = len(I), len(new_I), ds[k - 1]
        out.append([s.Matrix(old_r, new_r,
                             lambda i, j: C[i * d + a, j]) for a in range(d)])
        I = new_I
        rank_profile.append(new_r)
        suffix_sizes.append(len(K[k]))
        all_J.append(J)
    out.append([s.Matrix([entry(cores, p + (a,)) for p in I])
                for a in range(ds[-1])])
    return out, {"zero": False, "ranks": rank_profile,
                 "raw_suffix_basis_sizes": suffix_sizes,
                 "selected_suffixes": all_J}


def product_sum(ds, R, rng, zero=False):
    fs = [[[s.Integer(rng.randrange(-3, 4)) for _ in range(d)]
           for d in ds] for _ in range(R)]
    # One unreachable raw direction, and repeated product terms.
    fs[-1][0] = [s.Integer(0)] * ds[0]
    if R > 3:
        fs[-2] = [list(x) for x in fs[0]]
    if zero:
        for c in range(R):
            fs[c][0] = [s.Integer(0)] * ds[0]
    cores = [[s.Matrix([[fs[c][0][a] for c in range(R)]])
              for a in range(ds[0])]]
    for k in range(1, len(ds) - 1):
        cores.append([s.diag(*[fs[c][k][a] for c in range(R)])
                      for a in range(ds[k])])
    cores.append([s.Matrix([fs[c][-1][a] for c in range(R)])
                  for a in range(ds[-1])])
    return cores


def huge_cancelling_gauge(cores, power):
    n, R = len(cores), cores[0][0].cols
    gauges = [s.ones(1, 1)]
    for k in range(1, n):
        U = s.eye(R)
        for j in range(R - 1):
            U[j, j + 1] = (j + 2) * (k + 1)
        gauges.append(U * s.diag(*[
            s.Rational(2 ** (power * (j + 1)), 3 ** (k * (j + 1)))
            for j in range(R)]))
    gauges.append(s.ones(1, 1))
    return [[gauges[k].inv() * A * gauges[k + 1] for A in core]
            for k, core in enumerate(cores)]


def run_case(seed, ds, R, power, zero=False):
    cores = huge_cancelling_gauge(product_sum(ds, R, random.Random(seed), zero), power)
    out, metadata = compress(cores)
    vals = []
    for ix in itertools.product(*map(range, ds)):
        x, y = entry(cores, ix), entry(out, ix)
        assert x == y, (seed, ix, x, y)
        assert x.q == 1
        vals.append(x)
    exact_ranks = []
    for k in range(1, len(ds)):
        left = list(itertools.product(*map(range, ds[:k])))
        right = list(itertools.product(*map(range, ds[k:])))
        exact_ranks.append(s.Matrix([[entry(cores, p + z) for z in right]
                                    for p in left]).rank())
    assert metadata["ranks"] == exact_ranks
    metadata.update({"seed": seed, "dimensions": ds, "raw_bond": R,
                     "gauge_power": power, "verified_entries": len(vals),
                     "raw_core_max_bits": max(bits(x) for c in cores for A in c for x in A),
                     "canonical_core_max_bits": max(bits(x) for c in out for A in c for x in A),
                     "integer_tensor_entry_max_bits": max(map(bits, vals))})
    return metadata


if __name__ == "__main__":
    cases = [run_case(7, [2, 3, 2, 2], 7, 60),
             run_case(11, [3, 2, 2, 3], 6, 100),
             run_case(19, [2, 2, 2, 2, 2], 6, 80),
             run_case(23, [2, 3, 2, 2], 7, 60, zero=True)]
    result = {"all_passed": True, "cases": cases,
              "scope": "Finite exact tests, supplementary to the algebraic proof."}
    target = Path(__file__).with_name("exact_gauge_results.json")
    target.write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
