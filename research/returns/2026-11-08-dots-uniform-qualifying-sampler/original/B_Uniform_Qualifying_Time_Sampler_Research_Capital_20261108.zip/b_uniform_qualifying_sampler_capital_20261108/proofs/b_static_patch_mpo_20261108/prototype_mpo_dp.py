"""Small exact-rational implementation of the coefficient-MPO dynamic program.

Three noncommuting noisy qubits; this is an algebraic prototype, not a large
sampler or speed claim. Generator MPOs are built from constant-size local terms.
The exact selected-index compressor is the independently tested primitive.
"""
import sys, itertools, math, json, time
from pathlib import Path
import numpy as np
import scipy.linalg as la
import sympy as s
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'independent_audit'))
from check_exact_gauge import compress, entry, bits
I=np.eye(2,dtype=complex);X=np.array([[0,1],[1,0]],complex);Y=np.array([[0,-1j],[1j,0]]);Z=np.diag([1.,-1.]).astype(complex);P=[I,X,Y,Z]
def kron(xs):
 a=np.ones((1,1),complex)
 for x in xs:a=np.kron(a,x)
 return a
def hgen_pauli(H,n):
 d=2**n;V=np.stack([kron([P[a] for a in ix]).reshape(-1,order='F')/np.sqrt(d) for ix in itertools.product(range(4),repeat=n)],axis=1)
 L=-1j*(np.kron(np.eye(d),H)-np.kron(H.T,np.eye(d)))
 return np.rint((V.conj().T@L@V).real).astype(np.int64)
def idcore():return [s.Matrix([[int(o==i)]]) for o in range(4) for i in range(4)]
def local_term(C,positions,n):
 if len(positions)==1:
  cores=[idcore() for _ in range(n)];cores[positions[0]]=[s.Matrix([[int(C[o,i])]]) for o in range(4) for i in range(4)];return cores
 assert len(positions)==2 and positions[1]==positions[0]+1
 M=s.Matrix(C.reshape(4,4,4,4).transpose(0,2,1,3).reshape(16,16).tolist())
 _,J=M.rref();U=M[:,list(J)];_,rows=U.T.rref();V=U[list(rows),:].inv()*M[list(rows),:]
 cores=[]
 for k in range(n):
  if k==positions[0]:cores.append([U[a,:] for a in range(16)])
  elif k==positions[1]:cores.append([V[:,a] for a in range(16)])
  else:cores.append(idcore())
 return cores
def add(A,B):
 out=[];n=len(A)
 for k in range(n):
  if k==0:out.append([s.Matrix.hstack(a,b) for a,b in zip(A[k],B[k])])
  elif k==n-1:out.append([s.Matrix.vstack(a,b) for a,b in zip(A[k],B[k])])
  else:out.append([s.diag(a,b) for a,b in zip(A[k],B[k])])
 return out
def compose(A,B):
 out=[]
 for ac,bc in zip(A,B):
  core=[]
  for o in range(4):
   for i in range(4):
    core.append(sum((s.kronecker_product(ac[o*4+j],bc[j*4+i]) for j in range(4)),s.zeros(ac[0].rows*bc[0].rows,ac[0].cols*bc[0].cols)))
  out.append(core)
 return out
def scalar(cores,z):
 v=s.ones(1,1)
 for core,bit in zip(cores,z):
  rin=[1,0,0,1];f=[1,0,0,(-1)**bit]
  W=sum((f[o]*rin[i]*core[o*4+i] for o in range(4) for i in range(4)),s.zeros(core[0].rows,core[0].cols));v=v*W
 return v[0]
start=time.time();n=3
D=np.diag([0,-1,-1,-1]).astype(np.int64)
H0=hgen_pauli(np.kron(Y,X),2);H1=hgen_pauli(np.kron(Y,Z),2)
G0,_=compress(add(add(local_term(H0,[0,1],n),local_term(D,[0],n)),local_term(D,[1],n)))
G1,_=compress(add(local_term(H1,[1,2],n),local_term(D,[2],n)))
# Dense matrices for independent diagnostic only, not used by the MPO recursion.
Cd0=np.kron(H0,np.eye(4,dtype=int))+np.kron(D,np.eye(16,dtype=int))+np.kron(np.eye(4,dtype=int),np.kron(D,np.eye(4,dtype=int)))
Cd1=np.kron(np.eye(4,dtype=int),H1)+np.kron(np.eye(16,dtype=int),D)
Mmax=5;mp={(0,0):[idcore() for _ in range(n)]};dp={(0,0):np.eye(64,dtype=object)};stats=[];rnd=np.random.default_rng(111)
for r in range(1,2*(Mmax-1)+1):
 for a in range(Mmax):
  b=r-a
  if not 0<=b<Mmax:continue
  terms=[];dense=np.zeros((64,64),dtype=object)
  if a:terms.append(compose(G0,mp[a-1,b]));dense+=Cd0.astype(object)@dp[a-1,b]
  if b:terms.append(compose(G1,mp[a,b-1]));dense+=Cd1.astype(object)@dp[a,b-1]
  raw=terms[0] if len(terms)==1 else add(*terms)
  reduced,meta=compress(raw);mp[a,b]=reduced;dp[a,b]=dense
  for _ in range(16):
   o=int(rnd.integers(64));i=int(rnd.integers(64));od=np.unravel_index(o,[4]*n);ind=np.unravel_index(i,[4]*n);ix=tuple(x*4+y for x,y in zip(od,ind));assert entry(reduced,ix)==dense[o,i]
  stats.append(dict(m=[a,b],ranks=meta['ranks'],max_raw_bond=max(c[0].cols for c in raw),max_canonical_bits=max(bits(x) for c in reduced for A in c for x in A),max_true_entry_bits=max(abs(int(x)).bit_length() for x in dense.flat)))
comparisons=[]
rin=np.array([np.prod([1 if p in [0,3] else 0 for p in ix]) for ix in itertools.product(range(4),repeat=n)],float)
for T in [s.Rational(1,32),s.Rational(1,16)]:
 evolved=la.expm(float(T)*(Cd0+Cd1))@rin
 for M in [3,4,5]:
  errs=[];suma=s.Integer(0)
  for z in itertools.product(range(2),repeat=n):
   val=sum((T**(a+b)/s.factorial(a+b)*scalar(mp[a,b],z) for a in range(M) for b in range(M)),s.Integer(0))
   f=np.array([np.prod([1 if p==0 else (-1)**bit if p==3 else 0 for p,bit in zip(ix,z)]) for ix in itertools.product(range(4),repeat=n)])
   exact=float(f@evolved);errs.append(abs(float(val)-exact));suma+=val
  assert suma==8  # trace preservation is exact for every nonzero generator coefficient.
  a=float((6*T)**M/s.factorial(M));bound=8*((1+a)**2-1)
  assert max(errs)<=bound+1e-12
  comparisons.append(dict(t=str(T),M=M,max_normalized_scalar_error=max(errs),certified_bound=bound,half_l1_output_error=sum(errs)/16))
res=dict(coefficient_count=len(mp),coefficient_checks=16*len(stats),stats=stats,scalar_checks=comparisons,seconds=time.time()-start,scope='Exact small coefficient-MPO dynamic program; no production or asymptotic performance claim.')
(root/'prototype_mpo_results.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps(dict(coefficients=len(mp),checks=res['coefficient_checks'],max_bond=max(max(x['ranks']) for x in stats),max_bits=max(x['max_canonical_bits'] for x in stats),seconds=res['seconds'],scalars=comparisons),indent=2))
