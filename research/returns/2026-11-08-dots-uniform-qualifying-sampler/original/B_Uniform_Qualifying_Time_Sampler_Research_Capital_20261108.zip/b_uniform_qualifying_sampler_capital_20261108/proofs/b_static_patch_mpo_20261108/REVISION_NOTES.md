# Review corrections retained

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

- The final interpolation suffix sets need not be nested. Only the physical prefix sets are nested; raw suffix-span sets are obtained by a separate right sweep.
- A zero coefficient tensor uses a zero/rank-one representation, not an inverse of an empty pivot matrix.
- Interpolation numerators can be replaced-row minors of the true tensor, not merely minors of the selected pivot matrix.
- The local norm bound used to choose the Taylor degree is a supplied rational bound or a constant-dimensional rational entrywise bound, not an uncharged exact diamond-norm computation.
- An initial proposed raw-contraction bit bound O(h[B_raw+log R]) was false for arbitrary unrelated rational entry denominators. The corrected proof pays the product of all stored raw-core denominators, with polynomial bit length in the materialized MPO. The true integer coefficient tensor still supplies the separate minor-based output-gauge reset.
- Warmtime sigma is dimensionless action. The patch algorithm is applied to L/gamma for time sigma, charging rational division bits. No uniform bound on inverse gamma is silently assumed.

These are corrections within the candidate construction. The full method still requires the independent scope verdict; tests alone are not an asymptotic proof.
