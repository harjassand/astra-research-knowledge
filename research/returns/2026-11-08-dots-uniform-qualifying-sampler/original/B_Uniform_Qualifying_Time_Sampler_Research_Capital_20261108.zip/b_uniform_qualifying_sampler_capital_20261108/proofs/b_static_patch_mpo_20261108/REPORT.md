# Candidate direct static-patch evaluator

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

8 November 2026. Historical pre-review summary; superseded by the final end-to-end reviews.

The current candidate bypasses trajectory simplification and recursive probe precision by directly constructing a signed Liouville MPO for each warm-time activity patch. It combines the coordinatewise Taylor/cut-count method of Mackay et al., arXiv:2609.27497v1, with an explicit tilted slicing of an irregular 2D patch and a proposed exact-rational tensor-train gauge.

The target cost is exp[O(N^(7/8) polylog N)] for a patch of N qubits at polylogarithmic time and exponentially small scalar error. On previously audited warm-time patches N=O(L log L), L=log(n/epsilon), this would fit exp(O L) and stop the time recursion after one level. It would improve the qualifying-time complexity, not solve all-time B or the early-time gap.

PROOF_DRAFT.md states the proof, imported algebra, complete error/size costs and two unverified operations: growing-layer coefficient-rank control and exact-rational rank compression with bounded bit growth. The analytic rectangular Taylor error uses only CPTP backgrounds. No floating-point rank decision or free coefficient oracle is assumed.

Next: independently attack these two operations, test the tilted-layer and coefficient identities on irregular/noncommuting inputs, and check the actual source/dossier overlap before any novelty or completed-result claim.
