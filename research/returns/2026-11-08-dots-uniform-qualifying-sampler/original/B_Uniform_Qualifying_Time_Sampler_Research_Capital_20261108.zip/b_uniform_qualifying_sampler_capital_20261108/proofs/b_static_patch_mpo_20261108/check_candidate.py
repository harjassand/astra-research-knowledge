import numpy as np, scipy.linalg as la, sympy as sp, math, json, time
from pathlib import Path
out=Path(__file__).resolve().parent
rng=np.random.default_rng(20261108);start=time.time()
I=np.eye(2,dtype=complex);X=np.array([[0,1],[1,0]],complex);Y=np.array([[0,-1j],[1j,0]]);Z=np.diag([1.,-1.]).astype(complex);P=[I,X,Y,Z]
def kron(xs):
 a=np.ones((1,1),complex)
 for x in xs:a=np.kron(a,x)
 return a
def ps(s):return kron([P[i] for i in s])
def ham_super(H):
 d=H.shape[0];return -1j*(np.kron(np.eye(d),H)-np.kron(H.T,np.eye(d)))
def noise(n,i):
 d=2**n;ans=np.zeros((d*d,d*d),complex)
 for a in [1,2,3]:
  st=[0]*n;st[i]=a;q=ps(st);ans+=(np.kron(q.conj(),q)-np.eye(d*d))/4
 return ans
# Rational slopes, including elongated, branched and irregular patches.
def best_layers(points):
 p=np.array(sorted(points),dtype=np.int64);p-=p.min(axis=0);n=len(p);Q=n*n;best=None
 for a in range(Q):
  bins=(Q*p[:,0]+a*p[:,1])//Q
  _,counts=np.unique(bins,return_counts=True);sq=int(counts@counts)
  if best is None or sq<best[0]:best=(sq,a,int(counts.max()),int(bins.max()-bins.min()+1))
 return dict(n=n,slope_numerator=best[1],slope_denominator=Q,sum_squares=best[0],max_layer=best[2],height=best[3],sum_bound=64*n**1.5,max_layer_bound=8*n**.75)
geoms=[]
for n in [16,32,64]:
 shapes=[];shapes.append({(i,0) for i in range(n)})
 shapes.append({(i//2,i//2+(i%2)) for i in range(n)})
 cross={(0,0)}
 for k in range(1,n):
  arm=(k-1)%4;r=(k-1)//4+1;cross.add([(r,0),(-r,0),(0,r),(0,-r)][arm])
 shapes.append(cross)
 s={(0,0)}
 while len(s)<n:
  x,y=list(s)[int(rng.integers(len(s)))];dx,dy=[(1,0),(-1,0),(0,1),(0,-1)][int(rng.integers(4))];s.add((x+dx,y+dy))
 shapes.append(s)
 for j,s in enumerate(shapes):
  ans=best_layers(s);ans['kind']=['line','diagonal','cross','random_growth'][j];assert ans['sum_squares']<=ans['sum_bound'];geoms.append(ans)
# Noncommuting two-coordinate Taylor polynomials, direct CPTP error checks.
trunc=[]
for n in [2,3]:
 d=2**n
 s=[0]*n;s[0]=2;s[1]=1;H0=.25*ps(s)
 s=[0]*n;s[-2]=2;s[-1]=3;H1=.125*ps(s)
 G0=ham_super(H0)+noise(n,0)
 G1=ham_super(H1)+sum((noise(n,i) for i in range(1,n)),np.zeros((d*d,d*d),complex))
 bound=max(.5+1,.25+n-1)
 Mmax=12;coef={(0,0):np.eye(d*d,dtype=complex)}
 for r in range(1,2*(Mmax-1)+1):
  for a in range(Mmax):
   b=r-a
   if not 0<=b<Mmax:continue
   mat=np.zeros((d*d,d*d),complex)
   if a:mat+=G0@coef[a-1,b]
   if b:mat+=G1@coef[a,b-1]
   coef[a,b]=mat
 for T in [.05,.2,.5]:
  exact=la.expm(T*(G0+G1))
  for M in [3,5,8,12]:
   approx=sum((T**(a+b)/math.factorial(a+b)*coef[a,b] for a in range(M) for b in range(M)),np.zeros_like(exact))
   # Choi trace norm is an upper bound on diamond norm; dividing it by d gives a lower diagnostic.
   diff=exact-approx;choi=diff.reshape(d,d,d,d,order='F').transpose(0,2,1,3).reshape(d*d,d*d,order='F')
   choiupper=float(np.linalg.svd(choi,compute_uv=False).sum())
   a=(T*bound)**M/math.factorial(M);theory=(1+a)**2-1
   # Allow floating point residual once the analytic bound is below machine accuracy.
   assert choiupper/d <= theory+2e-12
   trunc.append(dict(n=n,T=T,M=M,choi_upper=choiupper,remainder_bound=theory,spectral_error=float(la.norm(diff,2))))
# Exact integer Pauli-coordinate coefficients and exact interpolation TT gauge.
n=3;d=8;paulis=[ps(s) for s in __import__('itertools').product(range(4),repeat=n)]
V=np.stack([p.reshape(-1,order='F')/np.sqrt(d) for p in paulis],axis=1)
G0=ham_super(ps([2,1,0]))+noise(n,0)+noise(n,1)
G1=ham_super(ps([0,2,3]))+noise(n,2)
C=[np.rint((V.conj().T@G@V).real).astype(np.int64) for G in [G0,G1]]
coef={(0,0):np.eye(64,dtype=object)}
for r in range(1,5):
 for a in range(3):
  b=r-a
  if not 0<=b<3:continue
  mat=np.zeros((64,64),dtype=object)
  if a:mat+=C[0].astype(object)@coef[a-1,b]
  if b:mat+=C[1].astype(object)@coef[a,b-1]
  coef[a,b]=mat
def ttcross_dense(T,dims):
 current=sp.Matrix(np.array(T,dtype=object).reshape(dims[0],-1).tolist());cores=[];rprev=1;ranklist=[];maxbits=0
 for k,dim in enumerate(dims[:-1]):
  if k:current=sp.Matrix(np.array(current.tolist(),dtype=object).reshape(rprev*dim,-1).tolist())
  # Row basis of current; its values remain selected rows of the true global tensor.
  _,piv=current.T.rref();B=current[list(piv),:];r=len(piv);_,cols=B.rref();J=list(cols)
  A=current[:,J]*B[:,J].inv();cores.append(np.array(A.tolist(),dtype=object).reshape(rprev,dim,r));current=B;rprev=r;ranklist.append(r)
 cores.append(np.array(current.tolist(),dtype=object).reshape(rprev,dims[-1],1))
 for core in cores:
  for x in core.flat:
   x=sp.Rational(x);maxbits=max(maxbits,abs(int(x.p)).bit_length(),int(x.q).bit_length())
 ans=cores[0]
 for core in cores[1:]:ans=np.tensordot(ans,core,axes=([-1],[0]))
 assert all(x==0 for x in (ans.reshape(T.shape)-T).flat)
 return dict(ranks=ranklist,max_core_numerator_denominator_bits=maxbits)
exact=[]
for m in [(1,1),(2,1),(2,2)]:
 mat=coef[m];tensor=mat.reshape([4]*6).transpose(0,3,1,4,2,5).reshape(16,16,16)
 result=ttcross_dense(tensor,[16]*3);result['multiindex']=m;result['max_integer_entry_bits']=max(abs(int(x)).bit_length() for x in mat.flat);exact.append(result)
res=dict(geometry=geoms,taylor=trunc,exact_gauges=exact,seconds=time.time()-start)
(out/'candidate_results.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps(dict(geometry_cases=len(geoms),taylor_cases=len(trunc),exact_gauges=exact,seconds=res['seconds']),indent=2))
