# Reproducible checks and their limits

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

## Parent implementation checks

`python check_candidate.py` checks:

-12 tilted-layer searches on connected line, diagonal, cross and irregular-growth shapes of16–64 sites, using exhaustive rational slopes.
-24 noncommuting2/3-qubit rectangular Taylor cases. The normalized Choi trace norm is used as a necessary lower diagnostic for the diamond-error certificate, with floating-point tolerance; this is not an exact diamond-norm computation.
-3 exact integer coefficient tensors compressed and reconstructed in rational TT interpolation gauge.

`python prototype_mpo_dp.py` is an actual small coefficient-MPO dynamic program rather than an existence test. Its3-qubit Hamiltonian is Y0 X1+Y1 Z2, with replacement rate1 on every qubit. It builds generator MPOs only from constant-size local terms, constructs all25 retained coefficients with two coordinate degrees below5, and compresses each using the independent exact selected-index routine. Dense coefficient matrices are computed separately only for diagnostic checks, not used in the MPO recurrence.

The saved run verified384 selected integer coefficient entries, exact trace preservation of the rectangular polynomial, and48 normalized output scalars across6 time/order combinations. The largest observed bond was6; largest canonical numerator/denominator size was25 bits. At t=1/16 and degree cap5, the maximum scalar error against dense evolution was1.61e-6, below the deliberately conservative9.89e-4 certificate. The run took about24 seconds in this workspace. This timing is not a production benchmark, a speedup over dense simulation, or evidence about large-instance complexity.

The half-L1 error of the approximate diagonal is reported as a diagnostic; the truncated channel is not assumed CP, and the full sampler does not directly sample a signed truncated channel. It uses certified scalar/logarithmic queries and the separately proven sampling conversion.

## Independent checks

The independent exact-gauge script checks raw redundant tensor trains and deliberately large cancelling rational virtual gauges, including a zero tensor. The recompression uses only raw cores and selected finite interfaces; full dense tensors are generated afterward for validation. Its detailed outputs, audit and source hashes are under `independent_audit/`.

Small tests supplement the general proofs. They do not replace the growing-layer rank bound, rational bit bound, activity theorem, precision ledger or sequential TV coupling.
