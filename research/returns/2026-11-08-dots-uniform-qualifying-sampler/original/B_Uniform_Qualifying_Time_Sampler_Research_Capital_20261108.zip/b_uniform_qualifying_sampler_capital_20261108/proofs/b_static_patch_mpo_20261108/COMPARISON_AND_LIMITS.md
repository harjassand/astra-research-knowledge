# What the candidate does and does not bypass

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

## Existing counterexamples

The generic Pauli-list hiding examples assumed access through bounded-error product-probe scalar queries under norm promises. This constructor uses the explicit local rational generator and product boundaries, generating coefficient tensors by a finite recurrence; it does not infer coefficients from that black box. It therefore does not contradict the hidden-Pauli or four-site tensor-power oracle lower bounds. Those abstract operators are not a free input family to the proposed physical constructor.

The pathwise depth obstruction concerns approximating each sampled unitary Pauli-jump trajectory by a shallow positive probe mixture. Here the actual static Lindblad generator is averaged first and retained exactly inside the Taylor coefficients. No sampled trajectory is simplified. The scalar can be computed through a signed numerical MPO without interpreting it as a physical state or stochastic process.

The early two-qubit XX pair remains exactly solvable, and its small-time product-reference activity can still be large. The proposed patch evaluator can evaluate that finite pair directly, but it does not make an unproved early-time cluster expansion converge. Its potential polynomial full-output consequence begins only after the previous explicit accumulated-noise threshold.

The Bell-folding investigation is a separate exact representation. Its raw postselection and uniform-Pauli estimators have exponential variance even for independent spins, and repeated folding retains entangled replica boundaries. The candidate static-patch algorithm does not use Bell postselection or a replica state as an oracle.

## Strongest applicable prior

Mackay, Kim, Vu and Kuwahara, arXiv:2609.27497v1, https://arxiv.org/html/2609.27497v1, explicitly provide coordinatewise coefficient-MPO constructions for static 1D Hamiltonian/Liouville evolution in an exact-arithmetic model. Their algebraic phase/cut-count representation is an essential imported tool, not a claimed new discovery here. The proposed adaptation keeps physical qubits of fixed dimension, exposes growing layer size and cross-layer rank, and separately pays rational exact elimination. It does not invoke a generic stable floating-point tensor truncation theorem.

The already-audited noisy activity construction, Pauli regularity, membership heavy hitters and sparse propagation remain separate dependencies. This candidate would replace only the repeated physical membership recursion with a direct warm-time patch computation. It does not improve the huge constants in those dependencies or supply an implemented end-to-end sampler.

## Verification scope

check_candidate.py checks12 geometrical slicing instances,24 small noncommuting Taylor truncations and3 exact integer coefficient tensor decompositions. The independent audit additionally stress-tests redundant raw tensor-train bonds, very large cancelling rational gauges, and zero tensors. These are diagnostic checks of formulas and implementation primitives, not numerical evidence for asymptotic efficiency. The general rank and bit proofs are necessary.

No performance or novelty claim is made.

Exact matrix skeleton interpolation and its tensor-train extension are also established prior: Oseledets and Tyrtyshnikov, TT-cross approximation for multidimensional arrays, Linear Algebra and its Applications432(1),70–88 (2010), DOI10.1016/j.laa.2009.07.024, https://doi.org/10.1016/j.laa.2009.07.024 . The present proof uses exact ranks from an already explicit MPO and exposes denominator/minor costs. It does not claim that generic black-box TT-cross discovers every low-rank tensor efficiently, nor does it import numerical max-volume heuristics as certified exact algorithms.
