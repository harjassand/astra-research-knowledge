"""Exact rational audit of both warm-boundary scalar reductions.

Noncommuting two-qubit Hamiltonian with Y terms; all local inputs and effects are
explicit positive product matrices. Tests Taylor coefficients, Walsh attenuation,
and every prefix-energy identity without using a physical sampling oracle.
"""
import itertools
import json
from pathlib import Path
import sympy as s

I=s.eye(2)
X=s.Matrix([[0,1],[1,0]])
Y=s.Matrix([[0,-s.I],[s.I,0]])
Z=s.diag(1,-1)
ps=[I,X,Y,Z]
labels=list(itertools.product(range(4), repeat=2))
P=[s.kronecker_product(ps[a],ps[b]) for a,b in labels]
H=s.kronecker_product(X,X)/3+s.kronecker_product(Y,Z)/5+s.kronecker_product(I,Y)/7
gamma=s.Rational(2,11)
G=s.zeros(16)
for j,Q in enumerate(P):
    V=s.I*(H*Q-Q*H)-gamma*sum(x!=0 for x in labels[j])*Q
    for i,R in enumerate(P):
        G[i,j]=s.simplify(s.trace(R*V)/4)
assert all(x.is_Rational for x in G)

def probe(a,b):
    return (I+(a*X+b*Y+a*b*Z)/2)/2

def vec_density(rho):
    return s.Matrix([s.simplify(s.trace(Q*rho)) for Q in P])

def local_noise(M):
    tr_first=s.Matrix(2,2,lambda b,c: sum(M[2*a+b,2*a+c] for a in range(2)))
    tr_second=s.Matrix(2,2,lambda a,c: sum(M[2*a+b,2*c+b] for b in range(2)))
    return gamma*(s.kronecker_product(I/2,tr_first)+s.kronecker_product(tr_second,I/2)-2*M)

def raw_generator(M,sign):
    return (sign*s.I*(H*M-M*H)+local_noise(M)).applyfunc(s.simplify)

rho=s.kronecker_product((I+X/3+Y/4)/2,(I-Z/3+Y/5)/2)
A=s.kronecker_product(2*probe(1,-1),2*probe(-1,-1))
R=vec_density(rho)
avec=s.Matrix([s.simplify(s.trace(Q*A)/4) for Q in P])
signs=list(itertools.product([-1,1],repeat=4))
probe_vec={z:vec_density(s.kronecker_product(probe(*z[:2]),probe(*z[2:]))) for z in signs}
code={0:(0,0),1:(1,0),2:(0,1),3:(1,1)}
indices=[code[a]+code[b] for a,b in labels]

def chi(a,z):
    v=1
    for bit,sign in zip(a,z):
        if bit:
            v*=sign
    return v

closure_checks=0
fourier_checks=0
direct_R=rho
direct_A=A
warm_R=R
warm_A=avec
for degree in range(7):
    f={z:(probe_vec[z].T*warm_A)[0] for z in signs}
    for z in signs:
        rho_z=s.kronecker_product(probe(*z[:2]),probe(*z[2:]))
        # State boundary: effect 4 rho_z, input rho.
        assert s.simplify((probe_vec[z].T*warm_R)[0]-4*s.trace(rho_z*direct_R))==0
        # Effect boundary: effect A, input rho_z, Schrödinger transpose.
        assert s.simplify(f[z]-s.trace(direct_A*rho_z))==0
        closure_checks+=2
    for j,alpha in enumerate(indices):
        fhat=sum(f[z]*chi(alpha,z) for z in signs)/16
        weight=sum(a!=0 for a in labels[j])
        assert s.simplify(fhat-warm_A[j]/2**weight)==0
        fourier_checks+=1
    warm_R=G.T*warm_R
    warm_A=G*warm_A
    direct_R=raw_generator(direct_R,-1)
    direct_A=raw_generator(direct_A,1)

# Prefix identity on the positive unevolved product effect A.
f={z:(probe_vec[z].T*avec)[0] for z in signs}
fhat={alpha:sum(f[z]*chi(alpha,z) for z in signs)/16 for alpha in indices}
prefix_checks=0
for k in range(5):
    for alpha in itertools.product([0,1],repeat=k):
        left=sum(value**2 for a,value in fhat.items() if a[:k]==alpha)
        right=0
        for v in itertools.product([-1,1],repeat=4-k):
            for u in itertools.product([-1,1],repeat=k):
                for u2 in itertools.product([-1,1],repeat=k):
                    right+=f[u+v]*f[u2+v]*chi(alpha,u)*chi(alpha,u2)
        right/=s.Integer(2)**(4+k)
        assert s.simplify(left-right)==0
        prefix_checks+=1

result={"all_passed":True,"model":"exact rational noncommuting two-qubit Hamiltonian including Y terms",
        "warm_boundary_taylor_identity_checks":closure_checks,
        "walsh_attenuation_checks":fourier_checks,"prefix_energy_checks":prefix_checks,
        "maximum_taylor_degree":6,"physical_oracles_used":False,
        "scope":"Exact finite diagnostics; does not replace the general proof or practical runtime study."}
Path(__file__).with_name("warm_probe_closure_results.json").write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
