"""Small dense numerical failure tests of analytic regularity bounds."""
import itertools,json,time,math
from pathlib import Path
import numpy as np
from scipy.linalg import expm
from scipy.optimize import minimize
P=Path(__file__).parent
I=np.eye(2);X=np.array([[0,1],[1,0]],complex);Y=np.array([[0,-1j],[1j,0]]);Z=np.diag([1,-1]);single=[I,X,Y,Z]
n=3;labels=list(itertools.product(range(4),repeat=n));basis=[]
for a in labels:
 b=np.array([[1.]],complex)
 for q in a:b=np.kron(b,single[q])
 basis.append(b)
basis=np.array(basis);wt=np.array([sum(t!=0 for t in a) for a in labels]);idx={a:i for i,a in enumerate(labels)}
terms=[(.4,(1,3,0)),(-.3,(0,2,3)),(.2,(2,0,0)),(.1,(0,0,1))]
gamma=.5;J=.4;d=2;k=2
H=sum(c*basis[idx[a]] for c,a in terms)
C=np.array([[np.trace(b.conj().T@(1j*(H@a-a@H)))/2**n for a in basis] for b in basis]).real
L=C-np.diag(gamma*wt)
p=2/(1+min(1,gamma/(4*d*J)));u=1/p-.5
rng=np.random.default_rng(2609)
rows=[]
start=time.time()
for s in [.1,.3,1.,3.]:
 E=expm(s*L);bound=(1+3*math.exp(-gamma*s/(2*u)))**(n*u)
 best=0;success=0
 def f(x):
  y=E@x;v=np.sum(np.abs(y)**p);norm=v**(1/p)
  grad=E.T@(np.sign(y)*np.abs(y)**(p-1))*v**(1/p-1)
  return -norm,-grad
 for trial in range(12):
  x=rng.normal(size=4**n);x/=np.linalg.norm(x)
  fit=minimize(lambda x:f(x),x,jac=True,constraints=[{'type':'eq','fun':lambda x:x@x-1,'jac':lambda x:2*x}],method='SLSQP',options={'maxiter':150,'ftol':1e-11})
  best=max(best,-fit.fun);success+=int(fit.success)
 rows.append({'T':s,'sampled_optimized_2_to_p_norm':best,'analytic_upper_bound':bound,'ratio':best/bound,'successful_optimizations':success,'note':'Optimization is a failure search, not a certified induced norm.'})
A=np.prod(1+np.array(labels)==0) if False else np.array([1. if all(j in [0,3] for j in a) else 0. for a in labels])
tH=math.log(n)/(2*gamma);tP=2*u/gamma*math.log(3*n);theta=min(1,gamma/(4*d*J))/(2*k);tW=2*theta/gamma
a=expm((tH+tP+tW)*L)@A
warm={'t_H':tH,'t_P':tP,'t_W':tW,'total_time':tH+tP+tW,'coefficient_p_norm':float(np.linalg.norm(a,ord=p)),'coefficient_p_bound':2*math.exp(u),'weighted_2_norm':float(np.linalg.norm(a*np.exp(theta*wt))),'weighted_2_bound':2}
out={'scope':'Three-qubit dense floating diagnostics of the independent norm derivation. No asymptotic algorithm or worst-case numerical certification.', 'n':n,'gamma':gamma,'J':J,'d':d,'p':p,'theta':theta,'induced_norm_tests':rows,'extensive_effect_warmup':warm,'seconds':time.time()-start}
(P/'regularity_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
assert all(x['ratio']<1+1e-8 for x in rows)
assert warm['coefficient_p_norm']<=warm['coefficient_p_bound']+1e-8
assert warm['weighted_2_norm']<=2+1e-8
