"""Independent finite tests of the two-sided regularity derivation.
No imports from the constructor's scripts. Full dense algebra is used only
for these three-qubit diagnostics, not as a proposed efficient warmstart.
"""
from itertools import product
from pathlib import Path
import math,json
import numpy as np
from scipy.linalg import expm
I=np.eye(2,dtype=complex);X=np.array([[0,1],[1,0]],complex);Y=np.array([[0,-1j],[1j,0]],complex);Z=np.diag([1,-1]).astype(complex)
pa=[I,X,Y,Z]
def kron(xs):
 out=np.array([[1]],complex)
 for x in xs:out=np.kron(out,x)
 return out
n=3;labels=list(product(range(4),repeat=n));basis=np.array([kron([pa[x] for x in s]) for s in labels]);idx={s:i for i,s in enumerate(labels)};wt=np.array([sum(x!=0 for x in s) for s in labels]);dim=2**n
terms=[(.7,(1,2,0)),(-1.,(0,3,1)),(.4,(2,0,0)),(.2,(0,0,3))];J=1.;incidence=2;k=2
H=sum(h*basis[idx[s]] for h,s in terms)
C=np.array([[np.trace(Q@(1j*(H@P-P@H))).real/dim for P in basis] for Q in basis])
assert np.max(abs(C+C.T))<1e-14
R=kron([I+X,I+Y,I+Z]);A=kron([I-Z,I,I+Z])
coeff=lambda O:np.array([np.trace(P@O).real/dim for P in basis])
cR=coeff(R);cA=coeff(A)
rows=[];weighted=[]
for gamma in [.1,1.,8.,128.]:
 p=2/(1+min(1,gamma/(4*incidence*J)));u=1/p-.5;theta=min(1,gamma/(4*incidence*J))/(2*k)
 L=C-np.diag(gamma*wt);Ls=-C-np.diag(gamma*wt)
 # Explicitly test each allocated local generator after weight conjugation.
 gamma0=gamma/(2*incidence)
 for h,s in terms:
  Pa=basis[idx[s]];Ca=np.array([[np.trace(Q@(1j*h*(Pa@P-P@Pa))).real/dim for P in basis] for Q in basis])
  damping=gamma0*np.array([sum(a!=0 and b!=0 for a,b in zip(label,s)) for label in labels])
  La=Ca-np.diag(damping);W=np.exp(theta*wt);transformed=W[:,None]*La/W[None,:]
  max_log_norm=float(np.linalg.eigvalsh((transformed+transformed.T)/2).max())
  assert max_log_norm<1e-13
  weighted.append({'gamma':gamma,'term':s,'theta':theta,'max_weighted_log_norm':max_log_norm})
 for tau in [4*theta+.05,4*theta+1.,4*theta+5.]:
  T=tau/gamma;a=math.exp(-(tau-4*theta)/(1+4*u));Cp=math.exp((math.log(2)+3*u)*n*a);C2=math.exp(math.log(2)*n*a)
  left=expm((T/2)*L)@cA;right=expm((T/2)*Ls)@cR
  lp=max(np.linalg.norm(left,ord=p),np.linalg.norm(right,ord=p));w2=max(np.linalg.norm(left*np.exp(theta*wt)),np.linalg.norm(right*np.exp(theta*wt)))
  assert lp<=Cp*(1+1e-12) and w2<=C2*(1+1e-12)
  direct=float(cA@(expm(T*Ls)@cR));paired=float(left@right)
  assert abs(direct-paired)<1e-12
  # Actual best-S truncation on this tiny example, to test the stated size
  # inequality rather than presume an algorithm can identify such terms.
  eta=.1;Wcut=math.ceil(math.log(2*C2/eta)/theta);logScap=math.log(2*Cp/eta)/u
  compressed=[];sizes=[]
  for vec in [left,right]:
   keep_weight=wt<=Wcut;order=np.argsort(-abs(vec)*keep_weight)
   sq=np.cumsum(np.square(vec[order]));total=float(vec@vec)
   size=next(i+1 for i,v in enumerate(sq) if total-v<=(eta/2)**2)
   retained=order[:size];approx=np.zeros_like(vec);approx[retained]=vec[retained]
   assert np.linalg.norm(vec-approx)<=eta/2+1e-13
   assert math.log(size)<=logScap+1e-10 and max(wt[retained])<=Wcut
   compressed.append(approx);sizes.append(size)
  err=abs(paired-float(compressed[0]@compressed[1]));assert err<=2*C2*eta+eta*eta+1e-12
  rows.append({'gamma':gamma,'tau':tau,'p':p,'u':u,'theta':theta,'max_coefficient_p':float(lp),'Cp_bound':Cp,'max_weighted_2':float(w2),'C2_bound':C2,'pairing_identity_error':abs(direct-paired),'small_dense_discovered_list_sizes':sizes,'paired_truncation_error':err,'W_bound':Wcut,'log_S_bound':math.log(2*Cp/eta)/u})
# Uniform scalar envelope at N<=K*tau*L. This is not a simulation.
envelope=[]
for gamma in [1e-4,.1,1,8,128,1e4]:
 p=2/(1+min(1,gamma/(4*incidence*J)));u=1/p-.5;theta=min(1,gamma/(4*incidence*J))/(2*k);den=1+4*u
 sup=den/math.e*math.exp(4*theta/den)
 vals=[tau*math.exp(-(tau-4*theta)/den) for tau in np.linspace(4*theta,4*theta+100,10001)]
 assert max(vals)<=sup*(1+1e-12)
 envelope.append({'gamma_over_J':gamma,'p':p,'theta':theta,'analytic_sup_tau_a':sup,'grid_max_tau_a':max(vals)})
out={'scope':'Finite diagnostics plus analytic scalar-envelope check. Does not discover coefficients on large patches or certify an efficient sampler.','weighted_local_checks':weighted,'two_sided_cases':rows,'uniform_envelope_cases':envelope}
Path(__file__).with_name('results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'two_sided_cases':len(rows),'local_weighted_cases':len(weighted),'max_pairing_identity_error':max(x['pairing_identity_error'] for x in rows),'max_p_bound_ratio':max(x['max_coefficient_p']/x['Cp_bound'] for x in rows),'max_weighted_bound_ratio':max(x['max_weighted_2']/x['C2_bound'] for x in rows),'uniform_envelope_cases':envelope},indent=2))
