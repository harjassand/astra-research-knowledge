# Independent audit: uniform sparse boundary descriptions versus discovery

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

8 November 2026. Reviewed the current REGULARITY_LEMMA.md through Section9, its source contractivity assumptions, the optimized time split, the adaptive patch-volume bound, and the activity precision budget. Independent finite checks are separate from the primary diagnostic scripts.

## Disposition

The revised statement supports **uniform polynomial-size approximate two-sided Pauli descriptions for each required activity query** in the qualifying pre-mixing regime, at fixed local strength/noise ratio and locality. I found no remaining norm, exponent or bit-size gap after the revisions below.

It does **not** provide a polynomial algorithm to locate the retained Pauli strings, calculate their coefficients, or certify that the omitted tail is small. Neither an all-time sampler nor an efficiently verifiable witness follows from the size bound. Early times outside the activity theorem remain outside this continuation as well.

The important corrections/clarifications incorporated during review are:

- Fix p=p_* and hence u>0 using the fixed strength/noise ratio. Letting p approach2 with n would change the polynomial exponent.
- Define weighted2 with exp(2theta|P|) inside its squared norm, and choose a positive rational admissible theta.
- Charge the conversion from grouped physical terms to constantly many Pauli terms, including their incidence count.
- Allocate coefficient-rounding error over the entire retained list, not independently at the full vector tolerance.
- Explicitly use the sharper KP activity-perturbation budget. The original termwise 2^(-m^2) oracle budget would not establish this uniform polynomial-size conclusion.

## 1. Local contractivity is valid with the stated noise allocation

Split the physical replacement generator into two equal halves. For each Pauli Hamiltonian term, allocate gamma/(2d) at every site in its support from the first half. No site is overcharged because it meets at most d terms. Every nonidentity local Pauli coefficient is damped at least gamma0=gamma/(2d).

A Pauli commutator pairs anticommuting coefficients into two-dimensional rotations at rate at most2J. Its active-sector coefficient1 growth is at most2J-gamma0, while coefficient2 growth is at most-gamma0. Riesz–Thorin interpolation gives the stated local exponent

    2J(2/q-1)-gamma0.

Thus q>=p_*=2/(1+a_*), a_*=min(1,gamma/(4dJ)), contracts. The identity sector is a disjoint fixed coordinate sector. Tensoring the local coefficient map with outside coefficients preserves its induced l_q bound. Product formulas and leftover diagonal damping extend contractivity to overlapping terms without requiring commutation.

This reproduces the relevant prior mechanism in Angrisani et al., arXiv:2609.40174v2, Lemma S15, Corollary S16 and Theorem S20. The source's sparse-propagation algorithms still depend on the initial observable's support/norm and explicit sparse initialization; that dependence cannot be dropped when the initial boundary is extensive.

For the weighted norm, conjugating a rotation pair by exp(theta|P|) gives symmetric logarithmic-norm contribution at most2J sinh(k theta). Subtracting gamma0 proves weighted contractivity whenever this is nonpositive. The revised rational theta=a_*/(2k) is safe: sinh(a_*/2)<=a_* for0<=a_*<=1. The same result holds with the adjoint Hamiltonian sign.

## 2. Changing the coefficient exponent pays its dimension factor correctly

For ordinary counting-measure coefficient l_p spaces, a diagonal multiplier has q-to-p norm equal to its l_r multiplier norm, where1/r=1/p-1/q. Applying the residual half-noise over time ds while increasing reciprocal exponent by du therefore costs

    [1+3 exp(-gamma ds/(2du))]^(N du).

Choose du/ds constant. Multiplying these factors over the product formula yields exactly

    ||exp(sL)||_(P,2 to P,p)
       <=[1+3 exp(-gamma s/(2u))]^(N u).

There is no missing4^N normalization factor: this is an unnormalized coefficient norm, not a Schatten-p norm. The residual noise pays that factor explicitly. The other half-noise was already charged to local coefficient contractivity.

Increasing the weight parameter linearly during s_W=2theta/gamma is similarly exact: residual damping exp(-gamma ds |P|/2) cancels the added weight exp(dtheta |P|). Full physical time is not doubled by this Lie–Trotter reasoning; the two generators are the two summands of L.

## 3. The optimized two-sided exponents check

Both normalized boundaries A=2^bP and R=2^N rho are positive with normalized trace one. Physical hypercontractivity from exponent1+a to2 gives

    ||exp(t_H L)A||_2 <=2^[N a/(1+a)]

when a=exp(-2gamma t_H). The same applies to R and L^*.

For each half-evolution, the revised allocation is

    t'=T/2-2theta/gamma,
    t_H=t'/(1+4u), t_P=4u t'/(1+4u),
    a=exp[-(gamma T-4theta)/(1+4u)].

It requires gamma T>=4theta, which every qualifying activity time satisfies. The coefficient-p multiplier then has the same a. The final weighted interval preserves the coefficient-p bound and uses the pre-existing coefficient2 bound, giving

    C_p=exp[(log2+3u)N a],
    C_2=exp[(log2)N a]

as valid bounds on coefficient-p and weighted2, respectively. These are worst-case bounds for the actual positive boundaries, with no state-design average.

The pairing identity

    G_B(T)=tau[(exp(TL_B/2)A)(exp(TL_B^*/2)R)]

is exact. Hermiticity makes its Pauli coefficients real; it is the ordinary coefficient inner product. Two coefficient2 approximations of error eta give scalar error at most2C_2 eta+eta^2. This removes the earlier one-sided 2^(N/2) conversion loss, but only if both approximations are actually obtained.

## 4. Patch-volume and global-polynomial accounting

Let L denote the logarithmic global accuracy budget, not the generator. The already checked adaptive activity construction has

    N<=K_rho(tau^2+tau L), tau=gamma T, rho=h/gamma.

Before the global mixing shortcut applies, tau=O(L), so N<=K'_rho tau L. For the bounded initial interval of qualifying times, the same bound holds after enlarging the fixed constant. At larger times, b=Theta(tau) and the adaptive cluster cutoff supplies it directly.

The remaining uniformity calculation is elementary and valid:

    tau exp[-(tau-4theta)/(1+4u)]
       <=[(1+4u)/e] exp[4theta/(1+4u)].

Therefore log C_p and log C_2 are O_rho(L), uniformly over all qualifying pre-mixing times. This is not an O(1)-norm assertion; polynomially growing norms in the global budget are enough.

Fixing rho is substantive. A safe Pauli expansion of the original one-/two-qubit grouped terms uses at most15 nonidentity Pauli summands per edge, with each coefficient at most h. Choosing fixed upper bounds d<=63 and J<=h is sufficient. The polynomial exponent is not uniform over arbitrarily large encoded h/gamma. The dimensionless numerical action gamma T, rather than time units alone, is the relevant scale.

For a scalar tolerance delta_G, choose eta<=delta_G/[4(C_2+1)]. Coefficient pruning, weight pruning and rounding can be allocated eta/4, eta/4 and eta/2. At most

    S<=(4C_p/eta)^(1/u)

terms and weight cutoff W<=min(N,ceil[theta^(-1)log(4C_2/eta)]) suffice. Rounding every retained coefficient to eta/(2sqrt(S)) costs O(log C_p+log(1/eta)+log S) bits. With the corrected oracle accuracy below, all these logarithms and W are O_rho(L); support indices cost O(W log(N+1)) bits per term. Thus total description length and a supplied-list pairing are polynomial in the global n/epsilon budget.

The conclusion is per requested activity and prefix. It does not assert one polynomial library for exponentially many possible prefixes, or a polynomial Pauli expansion of the global n-qubit state.

## 5. The sharper oracle precision is a necessary dependency

The original fixed-action evaluator used a sufficient but crude activity tolerance involving2^(-m^2). Feeding that tolerance into S polynomial in1/eta would give a quasipolynomial description in parts of the range. The revised Section9 correctly avoids this inference.

If activity errors satisfy |delta w_C|<=eta0 exp(-b v), eta0<=1, the interpolation family is bounded by2exp(-b v) and retains ample KP slack. The pinned-cluster derivative bound gives |partial log Z/partial w_C|<=exp(v). Consequently

    |delta log Z|<=eta0 n sum_(v>=2)[64 exp(-(b-1))]^v.

Taking eta0=delta_log/(10n) suffices. Boolean interface subtraction and bounded local denominators then require only O(log(n/delta_log)+bv+v)=O_rho(L) bits from each physical scalar oracle under the adaptive cutoff. Baseline perturbations can be budgeted separately using their lower bound1/2 and the certified activity bound.

Large connected-graph integers may still require O(m^2) bits in the classical cluster arithmetic. This is polynomial bit work and does not force every physical oracle value to have that many accuracy bits. Exact evaluation of the finite cluster polynomial on rational approximate activities is one valid separation of these costs.

## 6. Existence is not coefficient discovery or certification

The proof uses the operation “delete all coefficients below the threshold,” and then keeps the large ones. This specifies a small approximation mathematically. It gives no procedure to identify the large coordinates among4^N possibilities or evaluate them to the required precision from the compact product input.

The prior sparse propagator begins with a supplied sparse list. A product projector may have2^N initial coefficients, while a general product density has up to4^N. Physical hypercontractivity bounds the evolved operator without providing those coefficients. Applying a sparse update algorithm after an unknown warm-up does not pay the warm-up.

Nor does the norm upper bound alone certify a proposed sparse list. Verification needs a computable error bound for the difference, including omitted coordinates. The exact evolution can of course be evaluated densely and compared, but that is the exponential operation the continuation was trying to replace. A scalar-specific algorithm might avoid finding either list; no such algorithm is proved here.

A narrow oracle illustration clarifies the logical gap. Let N=L^2, W=L, and consider the positive normalized-trace operators

    F_P=I+exp(-theta W)P

for an unknown weight-W Pauli P. Each has a two-term representation, coefficient-p norm bounded by a constant, and weighted2 norm sqrt(2). Accuracy below exp(-theta W)/3 must identify the nonidentity coordinate. There are binom(N,W)3^W possible positions, exp(Theta(L log L)). In an unstructured coordinate-value query model, the promise of this tiny description does not reveal its location; randomized discovery can still require order that many queries.

This is **not** a construction of such operators from the present local product-input dynamics, and not a physical sampling-hardness claim. An actual algorithm may exploit Hamiltonian/input structure or richer queries. The example only prevents the invalid logical inference from compressibility to efficient coordinate discovery.

## 7. Independent finite checks

`check_sparse_bounds.py` uses separate three-qubit Pauli-transfer code with mixed noncommuting two-body terms and fields. It checks:

-16 allocated local weighted-generator logarithmic norms, including the identity-sector zero eigenvalue;
-12 two-sided cases across weak and strong noise, with rational theta and p=p_*;
-the exact scalar pairing identity, worst residual2.23e-16;
-coefficient-p and weighted2 bounds, with maximum observed bound ratios below.985;
-small-system best-list truncations against the analytic size/weight and pairing-error inequalities;
-the uniform scalar envelope over six strength/noise ratios.

These floating checks are failure tests, not asymptotic certificates or an efficient large-patch discovery algorithm. The analytic arguments above carry the conclusion. The stronger-theta diagnostic performed before the rational-parameter refinement is preserved separately. One test initially overflowed when explicitly forming the enormous S upper bound; it was corrected to compare logarithms, not by weakening the bound.

## Final conclusion

The revised uniform polynomial **representation-size** statement passes this audit under its fixed-ratio, qualifying-time and per-query scope. It is useful progress because the earlier dense matrix size is not a lower bound on the minimum boundary description size. The central missing operation is now particularly explicit: find and certify those sparse boundaries, or compute their pairing by another paid method, in polynomial time. No constructive all-time sampler has been earned by the norm result alone.
