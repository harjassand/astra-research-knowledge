# A dimension-controlled Pauli regularization operation

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

8 November 2026. This is a derived norm/representation statement, not an algorithm for finding the representation. Independent review is complete; see independent_audit/REPORT.md. The review supports the norm and per-query representation-size statements, not a list constructor or an all-time algorithm. It is proposed as a concrete all-time activity-evaluation target, separate from patch-mixing/composition.

## 1. Prior and conventions

Angrisani, Puig, Teng and Holmes, arXiv:2609.40174v2 (5 November 2026), prove continuous-time sparse Pauli propagation in normalized Hilbert–Schmidt error. Their local coefficient-norm contractivity (Lemmas S15–S16 and Theorem S20) compares coherent and dissipative rates without a fixed noise-per-Trotter-step assumption. Their stated expectation-value guarantee is over a state1-design, not a worst-case rare output prefix. Initial observable support/Pauli norm enters the cost. We use that contractivity as prior capital, not a new claim.

Let L=i[H,.]+gamma sum_i(E_i-Id) act on N qubits. Write H=sum_a J_a P_a with |J_a|<=J, Pauli support size<=k, and each qubit in at most d supports. J>0 is a paid upper bound. Replacement noise uses E_i(P)=0 if P is nonidentity on i and E_i(P)=P otherwise.

For O=sum_P c_P P, write ||O||_{P,p}=(sum_P |c_P|^p)^(1/p), and ||O||_{P,2,theta}=(sum_P exp(2theta|P|)|c_P|^2)^(1/2). The coefficient2-norm equals the normalized Schatten2-norm, but coefficient p and Schatten p are different for p!=2.

## 2. Split noise and uniform coefficient contractivity

Split L=L_c+L_r, where

    L_c=i[H,.]+(gamma/2)sum_i(E_i-Id),
    L_r=(gamma/2)sum_i(E_i-Id).

Allocate rate gamma/(2d) from each site in a Pauli term to that term's dissipator. The total allocation is at most gamma/2 per site; any leftover is additional diagonal contractive noise. Every nonidentity local Pauli mode of a term is damped at least gamma/(2d).

Set

    a_*=min(1,gamma/(4dJ)),
    p_* = 2/(1+a_*).

For the uniform complexity statement, fix p=p_* and u=a_*/2>0. Do not let p approach2 as a function of system size while holding the claimed exponent fixed.

The prior local interpolation bound gives ||exp(t L_c)||_{P,q -> P,q}<=1 for every q in[p_*,2]. A direct check is short: on each term's local traceless sector, its Pauli commutator consists of coefficient rotations with rate at most2J. The allocated damping gamma0=gamma/(2d) gives coefficient2 growth at most exp(-gamma0 t), and coefficient1 growth at most exp[(2J-gamma0)t]. Riesz–Thorin interpolation gives exp{t[2J(2/q-1)-gamma0]}. The local identity sector is fixed and disjoint in coefficient space. The displayed p_* makes the traceless bound contractive. Product formulas and the leftover diagonal noise extend this to L_c; overlapping terms need not commute.

## 3. A changing-exponent diagonal calculation

Fix p in[p_*,2), let u=1/p-1/2>0, and consider a time s>0. The claim is

    ||exp(sL)||_{P,2 -> P,p}
       <= [1+3 exp(-gamma s/(2u))]^(N u).             (1)

Proof: divide s into m intervals and choose reciprocal exponents

    1/q_j=1/2+u j/m,   j=0,...,m.

Apply exp((s/m)L_c) at q_{j-1}, where it contracts, followed by exp((s/m)L_r), which changes the exponent to q_j. For a diagonal multiplier a_P on ordinary counting-space coefficients, its exact q_{j-1}->q_j norm is ||a||_r with 1/r=1/q_j-1/q_{j-1}=u/m. Here a_P=exp[-gamma s|P|/(2m)], so

    sum_P |a_P|^r=[1+3 exp(-gamma s/(2u))]^N.

The norm for one interval is the bracket to power Nu/m. Multiplying the m bounds and taking the finite-dimensional product-formula limit proves (1). The coefficient-space norm is unnormalized counting measure, so no hidden4^N normalization factor is omitted.

In particular, for

    s_P=(2u/gamma) log(3N),

(1) is at most e^u. The dimension dependence is logarithmic in the time needed to regularize the coefficient norm; the statement is uniform over Hamiltonians satisfying the local promises.

## 4. Extensive effects become Pauli-compressible after logarithmic time

Take a normalized partial-output effect A=2^b P, where P is a b-site product projector times identity elsewhere. More generally, take A=2^N rho for any density matrix rho. For p0=1+1/N, normalized Schatten norms satisfy ||A||_{p0,tau}<=2.

Physical hypercontractivity gives

    ||exp(t_H L)A||_{P,2}<=2,
    t_H=(log N)/(2gamma).

Applying (1) for a further s_P gives

    ||exp[(t_H+s_P)L]A||_{P,p}<=2e^u.              (2)

Subsequent full evolution is coefficient-p contractive, so this bound persists.

For a weight cutoff, use the positive rational choice theta=a_*/(2k). The prior weighted coefficient2 bound makes L_c contractive in ||O||_{P,2,theta'} for every0<=theta'<=theta. Directly, each weighted two-Pauli rotation has logarithmic2-norm at most2J sinh(k theta')-gamma/(2d). Since k theta<=1/2 and sinh x<=2x on that interval, the rational theta above makes this nonpositive. This pays the weighted regularity without an uncharged transcendental parameter. During an additional interval s_W=2theta/gamma, increase theta' linearly from0 to theta. Each residual-noise step exactly pays the increase in the weight factor exp(theta'|P|), while each L_c step contracts at its current theta'. Product-formula convergence therefore gives

    ||exp(s_W L)O||_{P,2,theta}<=||O||_{P,2}.

At t_*=t_H+s_P+s_W, both (2) and the weighted bound<=2 hold. For any eta>0, deleting coefficients below a threshold and all weights above

    W=ceil(theta^(-1)log(4/eta))

produces a Pauli approximation within normalized Schatten2 error eta, with at most

    S<=(4e^u/eta)^[2p/(2-p)]

retained coefficients, up to a harmless constant allocation between the two errors. Its description has O(S W log N) support bits plus coefficient precision. At fixed dJ/gamma this is polynomial in1/eta and log N. The same conclusions hold for the adjoint sign of H.

## 5. A stable two-sided activity pairing, conditional on finding the sparse lists

Let R=2^N rho be the normalized physical input density and A a normalized partial-output effect. For the exact switched generator L_B and its trace adjoint L_B^*,

    G_B(T)=tau[A exp(T L_B^*)R]
          =tau[(exp((T/2)L_B)A)(exp((T/2)L_B^*)R)].

Both half-evolved operators have coefficient2 norm at most2 and the above sparse approximation promises when T/2>=t_*. Approximate each to coefficient2 error eta. Cauchy–Schwarz then bounds their scalar pairing error by4eta+eta^2, with no2^(N/2) conversion factor and no division by a rare prefix. Their inner product can be computed from the intersection of the two sparse Pauli lists.

Every interface-deleted Hamiltonian satisfies the same degree/strength bounds. A v-block activity has at most2^e terms, e<=2v, and inverse isolated baseline at most2^v. Thus requesting each scalar G_B to error delta_w 2^[-(e+v)] controls its contribution to activity error, before separately paying baseline approximation. The needed coefficient precision is still O(log(1/delta_w)+v). At delta_w=exp[-O(L+bv)], fixed dJ/gamma and bv=O(L), the sparse-list sizes and pairing work would be polynomial in the global accuracy budget exp(L).

The sufficient smoothing condition is explicit:

    gamma T >= log N+4u log(3N)+4theta.

For activity patches N=O(tau L), this is a logarithmic-in-patch-size condition, much earlier than the log-relative uniformity requirement tau approximately log N+L. It gives a genuine representation/error target rather than assuming ordinary mixing solves rare-prefix normalization.

## 6. The unresolved warmstart operation

The norm derivation proves existence, not efficient initialization. A normalized extensive projector begins with exponentially many Pauli coefficients. The prior sparse propagation algorithm needs sparse/explicit initial coefficients; being promised that a later sparse list exists does not reveal its coefficients or positions.

A falsifiable target is therefore: given a compact product description of R or A and the local generator, construct the promised half-evolved sparse Pauli list to coefficient2 error eta with work polynomial in N, dimensionless action gamma T, paid input bits and1/eta at fixed dJ/gamma, after the displayed logarithmic smoothing time. For the more general polynomial-norm regime of Section7, include the explicit analytic norm budgets C_p and C_2 in that polynomial cost. A quasipolynomial dependence on1/eta is not enough for the outer all-time sampler. An efficient list constructor would complete the two-sided local scalar operation above; proving the list small does not.

Nor does one-sided normalized Schatten2 accuracy by itself imply logarithmic marginal accuracy. BARRIERS.md gives exact H=0 witnesses. The two-sided norm calculation fixes that conversion *if both regularized boundaries can actually be obtained*. Naively sampling initial Pauli terms has exponential variance even in an easy product model, so that is not a free way to obtain them.

No complete warmstart constructor, uniform all-time sampler or priority claim is supplied. Section7 below removes the bounded-norm smoothing condition at the level of representation size, but not at the level of constructing a list.

Primary sources: https://arxiv.org/html/2609.40174v2 (coefficient and weighted regularity), and King arXiv:1210.8412 for the physical hypercontractive ingredient. All combinations above are stated explicitly so their constants and access model can be challenged.

## 7. Uniform polynomial representability without waiting for bounded norms

The bounded-norm threshold is stronger than the outer activity computation needs. Only a polynomial bound in the *global* accuracy budget is required. This gives a more useful version of the operation.

Use the positive rational theta from Section4, which is already at most1. Suppose tau=gamma T>=4theta. In each half-evolution reserve s_W=2theta/gamma at the end. For the remaining t'=T/2-s_W choose

    t_H=t'/(1+4u),     t_P=4u t'/(1+4u).

Define

    a=exp[-(tau-4theta)/(1+4u)].

Physical hypercontractivity now starts at Schatten exponent1+a and gives

    ||exp(t_H L)A||_2 <= 2^[N a/(1+a)] <= exp[(log2)N a].

The coefficient regularization multiplier for t_P is(1+3a)^(Nu), at most exp(3uN a). The last weighted-noise interval preserves coefficient p and promotes the2-norm bound to a weighted bound. Consequently each half-evolved boundary satisfies

    ||boundary||_{P,p} <= exp[(log2+3u)N a] =: C_p,
    ||boundary||_{P,2,theta} <= exp[(log2)N a] =: C_2.

This derivation applies both to normalized product input and normalized product effect, and uniformly to every switched Hamiltonian. It does not require a state average.

For scalar error delta_G, choose each boundary approximation to coefficient2 error eta<=delta_G/[4(C_2+1)]. Then the two-sided scalar error is at most2C_2 eta+eta^2<=delta_G. Allocate eta/4 to coefficient pruning, eta/4 to weight pruning and eta/2 to coefficient rounding. At most(4C_p/eta)^[2p/(2-p)] terms and weight cutoff ceil(theta^(-1)log(4C_2/eta)) suffice. Round each retained coefficient to absolute error at most eta/(2sqrt(S)); their squared errors then sum to at most eta^2/4. The magnitude and precision bits are O(log C_p+log(1/eta)+log S).

Now use the previously proved time-adaptive cluster budget. At fixed rho=h/gamma and locality, in the qualifying pre-mixing regime a retained activity patch has

    N <= K_rho(tau^2+tau L) <= K'_rho tau L,

where L=O(log(n/epsilon)) and tau=O(L). The finite initial interval of qualifying times can be absorbed into K_rho; above it the adaptive activity exponent is proportional to tau. Therefore

    log C_p, log C_2 <= K''_rho L tau exp[-tau/(1+4u)]
                      <= K'''_rho L.

The scalar activity accuracy, including interface subtraction and local denominators, has log(1/delta_G)=O_rho(L). It follows that the required boundary lists have exp(O_rho(L)) terms and O_rho(L) precision/weight parameters, uniformly over qualifying physical times before mixing. Their descriptions and their scalar pairing are polynomial in the global n/epsilon budget. This statement concerns each requested local activity, not a polynomial Pauli description of the global n-qubit state.

Thus the present dense time exponent is not forced by the *minimum description size* of these approximate patch boundaries. A polynomial-size description exists under the audited norm ingredients. What remains missing is a uniform polynomial algorithm to find and certify it from the original compact product description. The norm proof is not such an algorithm, and this result must not be reported as an all-time sampler or an efficiently verifiable certificate.

## 8. Original-input and bit-cost conversion

For the original square-lattice grouped one- and two-qubit Hamiltonian terms, expand each into at most15 nonidentity Paulis. Each coefficient has magnitude at most the grouped operator norm h. A safe incidence bound is d<=4*15+3=63, and J<=h; sharper regrouping is optional. Thus fixed h/gamma implies fixed dJ/gamma, p_*, u and rational theta. Arbitrarily large encoded ratios are not silently treated as constants.

For each activity request in Section7, log C_p, log C_2, log(1/eta), log S and the coefficient rounding precision are O_rho(L), while N=O_rho(L^2) before mixing and W<=min(N,O_rho(L)). Support indices and rational coefficient approximations therefore have a polynomial total description length. Computing the sparse inner product has polynomial bit cost *if the lists are supplied*. There is still no paid procedure here to find or independently certify those approximations.

## 9. Why the local oracle needs O(L+bv), rather than O(L^2), precision bits

The polynomial-list conclusion uses a sharper activity-perturbation bound supplied by the independent composition audit. The original fixed-action algorithm's termwise arithmetic budget was sufficient but unnecessarily stringent for the *input activity values*.

Suppose true activities obey |w_C|<=e^(-bv), b>=8, and approximate activities obey

    |w'_C-w_C|<=eta_0 e^(-bv),  eta_0<=1.

Every straight-line interpolation between them is bounded by2e^(-bv), which still satisfies KP with ample slack, including the tail weight kappa=b-7. The pinned-cluster derivative bound gives |partial_(w_C) log Z|<=e^v. Integrating along the interpolation yields

    |log Z(w')-log Z(w)|
       <=eta_0 sum_C e^[-(b-1)|V(C)|]
       <=eta_0 n sum_(v>=2)(64e^[-(b-1)])^v.

Thus eta_0=delta_log/(10n) suffices with slack. Apply this perturbation only to activities required by the finite cluster cutoff; other activities can remain equal to their uncomputed true values in the analytic comparison. The perturbed full partition has the same controlled tail, so the finite cluster approximation remains justified.

For a v-block activity, approximating each switched scalar to O(eta_0 e^(-bv)2^[-(e+v)]) pays the2^e summands and inverse local baseline<=2^v. Baseline precision can be chosen so that its small relative product error contributes at most another fixed fraction of eta_0e^(-bv). Hence local scalar accuracy uses O(log(n/delta_log)+bv+v) bits. With the adaptive cutoff and pre-mixing tau=O(L), this is O_rho(L).

Connected-graph integers and the finite sum can still require O(m^2) arithmetic bits to avoid roundoff cancellation. That is a polynomial bit-operation cost, not an O(m^2)-bit requirement on every physical scalar oracle. One may evaluate the finite expression on the rational approximate activities exactly, or use paid higher-precision arithmetic. The KP perturbation bound, not a worst-case termwise derivative estimate, controls their input errors.

See also the independent report ../b_time_composition_audit_20261108/REPORT.md for this precision argument and the separate composition obstructions. This does not supply the missing warmstart constructor.
