"""Exact/computable scalar witnesses, not simulation of 2^N states."""
from pathlib import Path
import math,json,mpmath as mp
mp.mp.dps=100
rows=[]
k=8
for r in [2,3,4,5,6,8,10]:
 N=2**(4*r);z=mp.mpf(2)**(-3*r)
 logG=N*mp.log1p(z)
 retained=sum(mp.mpf(math.comb(N,j))*z**j for j in range(k+1))
 log_ret=mp.log(retained)
 first=mp.mpf(math.comb(N,k+1))*z**(2*(k+1))
 ratio=N*z*z/(k+2)
 assert ratio<1
 l2lo=mp.sqrt(first);l2hi=mp.sqrt(first/(1-ratio))
 logsecond=N*(mp.log(2)+mp.log1p(z*z)-2*mp.log1p(z))
 rows.append({'r':r,'N':N,'z_exact':'2^(-%d)'%(3*r),'pauli_weight_cutoff':k,
  'tau':str(3*r*mp.log(2)),'normalized_HS_error_lower':mp.nstr(l2lo,18),
  'normalized_HS_error_upper':mp.nstr(l2hi,18),
  'true_log_normalized_all_zero_probability':mp.nstr(logG,18),
  'log_marginal_error_after_truncation':mp.nstr(logG-log_ret,18),
  'relative_error_after_exact_product_baseline':mp.nstr(1-mp.exp(log_ret-logG),18),
  'initial_Pauli_importance_second_moment_ratio_log2':mp.nstr(logsecond/mp.log(2),18),
  'uniform_TV_entropy_upper':mp.nstr(mp.sqrt(mp.mpf(N)*mp.log(2)/2)*z,18),
  'interpretation':'H=0 and product input. Baseline is exactly G; this diagnoses norm conversion and naive proposal, not computational hardness.'})
out={'scope':'Scalar binomial formulas with rigorous tail enclosure. Full quantum vectors are never instantiated. Times 3r log2 have a certified representation; nearby rational times preserve the asymptotic witness.', 'cases':rows}
p=Path(__file__).parent/'exact_barrier_results.json';p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
