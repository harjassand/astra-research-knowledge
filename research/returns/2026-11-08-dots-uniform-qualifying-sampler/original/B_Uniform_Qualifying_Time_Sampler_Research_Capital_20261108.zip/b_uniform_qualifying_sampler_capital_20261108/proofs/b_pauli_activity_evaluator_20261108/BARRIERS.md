# Exact failure tests for a Pauli activity evaluator

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

8 November 2026. These examples reject specific norm-conversion and sampling shortcuts. They do not imply hardness of the easy product model, or rule out another algorithm.

## 1. Tiny Hilbert–Schmidt error can miss a normalized prefix almost entirely

Set H=0, start from |0> on each of N qubits, and measure the all-zero output after replacement noise with tau=gamma T. Put z=exp(-tau). The normalized output effect is

    O_N=product_i(I+z Z_i).

Its normalized all-zero marginal is G_N=(1+z)^N. Keep only Pauli terms of weight at most k, obtaining O_N^{<=k}. Orthogonality gives the exact normalized Hilbert–Schmidt error

    ||O_N-O_N^{<=k}||_2^2
       =sum_(j=k+1)^N binom(N,j)z^(2j).

But evaluating on the actual all-zero product input gives the positive error

    G_N-sum_(j=0)^k binom(N,j)z^j.

Choose N=2^(4r), z=2^(-3r)=N^(-3/4), and fixed k=8. The Hilbert–Schmidt error is asymptotic to N^(-9/4)/sqrt(9!), while log G_N is asymptotic to N^(1/4). The truncated scalar grows only polynomially, so its ratio to G_N tends to zero and its log-marginal error diverges. Dividing both exact and approximate scalars by the exact product baseline G_N does not fix this: the correct normalized partition is1, while the approximate value tends to0.

At N=1,048,576, the high-precision evaluation of an analytic tail enclosure gives Hilbert–Schmidt error between4.7180357e-17 and4.7182661e-17. Nevertheless, the all-zero log-marginal error is14.6031 and the baseline-normalized relative error is0.999999545. No quantum statevector was constructed; these are binomial formulas.

The analytic enclosure uses the first omitted positive term a=binom(N,k+1)z^(2k+2):

    a <= error^2 <= a/[1-Nz^2/(k+2)],

when the denominator is positive. Decimal values are high-precision evaluations of these bounds, not directed-rounding interval certificates.

This example does not challenge the prior sparse-Pauli theorem, whose error metric is Hilbert–Schmidt/average-case. It shows why that metric cannot simply replace a worst-case normalized-marginal oracle. The exact H=0 output remains trivial to sample; even uniform output is close in TV at these times. A bad rare-prefix log approximation is not a proof that all TV samplers fail.

## 2. Naive initial-Pauli sampling has exponential variance after smoothing

The initial effect product_i(I+Z_i) has2^N equal Pauli coefficients. Sample a subset S uniformly and estimate G_N with

    Y=2^N z^|S|.

Then E Y=G_N, but

    E Y^2/(E Y)^2
       =[2(1+z^2)/(1+z)^2]^N.

Thus relative variance is the displayed quantity minus1. At z=N^(-3/4), its base2 logarithm is N-O(N^(1/4)); it is exponential in the physical patch size despite the final operator's strong coefficient decay. The easy model's appropriate tilted subset distribution proportional to z^|S| removes this variance completely. Therefore this is an obstruction only to the naive initial-term proposal, not to importance sampling in general or to the product model's complexity.

The unproved generic step is obtaining a comparably useful proposal or sparse representation under noncommuting evolution without already solving the activity. Small final norms do not supply that proposal automatically.

## 3. Relevance to the positive target

REGULARITY_LEMMA.md derives a stronger two-sided smoothing promise: half-evolved input and output operators can both have bounded coefficient2 norm and polynomial-size approximate Pauli lists. Pairing those lists would give stable scalar accuracy. The present examples explain why both the boundary pairing and the cost of constructing the lists must be paid. They do not invalidate that conditional two-sided operation.
