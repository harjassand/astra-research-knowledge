# Pauli warmstarts: a uniform size bound, not yet an all-time evaluator

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

8 November 2026. This continues the independently reviewed fixed-action connected-activity result. It does not claim a uniform all-time sampler.

## Useful result

The time-dependent dense patch cost is not forced by the size of a good Pauli description. For every retained local activity, both half-evolved product boundaries admit sparse Pauli approximations whose total description size, precision and pairing work are polynomial in the outer n/epsilon budget, uniformly over qualifying times before global mixing, at fixed h/gamma.

The proof splits the physical noise. One part makes the Hamiltonian evolution contractive in a coefficient-p norm for a fixed p<2; the other part changes the coefficient exponent from2 toward p with an exactly paid dimension factor. Combining that calculation with physical hypercontractivity and a weighted-Pauli bound gives controlled sparse descriptions of extensive, rather than initially local, effects. A two-sided trace pairing controls scalar error without dividing by a rare output probability.

This is a representation/existence statement. We do not yet have a uniform polynomial-time method to find the sparse coefficients from the original compact product input. Claiming that their eventual sparsity makes them available would skip the main remaining computation.

## Falsifiable missing operation

Given a local generator and compact product density/effect, construct a certified coefficient2-accurate Pauli list for its noisy evolution, with cost polynomial in physical patch size, dimensionless action gamma T, paid input bits, inverse accuracy and the explicit analytic norm budgets C_p,C_2 at fixed noise-to-coupling ratio. Those budgets are polynomial in the outer n/epsilon for the retained activities. The routine must find the coefficient locations and values, not receive them as an oracle or enumerate the exponentially large initial Pauli expansion.

If supplied, two such lists yield the required scalar activity through a sparse inner product. The interface subtraction, local denominators and finite-bit accuracy remain paid. The precise target and uniform size derivation are in REGULARITY_LEMMA.md.

## Strong prior

Angrisani et al., arXiv:2609.40174v2, directly handles continuous-time sparse Pauli propagation and vanishing per-step noise. Its coefficient-norm and weighted-norm estimates are relevant prior capital. The normalized Hilbert–Schmidt/average-state error guarantee and sparse initial observable access do not directly provide worst-case product-input rare-prefix logarithms. The present derivation identifies that missing conversion and initialization rather than reannouncing the prior compression theorem.

## Failure tests that constrain a constructor

Two exact H=0 examples reject plausible shortcuts, while leaving the trivial product sampler untouched:

- At N=1,048,576, retaining weight<=8 has normalized Hilbert–Schmidt error about4.72e-17, yet misses the normalized all-zero marginal by relative error0.999999545 and log error14.6031. A one-sided norm guarantee cannot simply replace the required scalar oracle.
- Sampling the initial Pauli terms uniformly has relative variance [2(1+exp(-2tau))/(1+exp(-tau))^2]^N−1. This is exponential after smoothing. A tilted proposal solves the easy product case; it is the naive proposal, not importance sampling generally, that fails.

Small three-qubit dense numerical searches found no violation of the new norm bound. Those checks are diagnostics, not the general proof. High-dimensional examples use scalar binomial formulas, not a claimed simulation of those many qubits. See BARRIERS.md and the saved scripts/results.

## Costs and limits

Let L=O(log(n/epsilon)), tau=gamma T and rho=h/gamma. Time-adaptive activities have patch size N=O_rho(tau L) before mixing. The optimized two-sided regularization gives log coefficient norms O_rho(N exp(-c_rho tau)), hence O_rho(L). At the needed scalar accuracy, each approximate list has exp(O_rho(L)) terms, O_rho(L) coefficient bits and weight parameters, and polynomial pairing work. The construction cost is **not** proved by these size bounds.

The O(L)-bit physical-oracle budget uses the pinned-cluster KP perturbation bound, not the older O(L²) termwise input budget. O(L²) classical cluster arithmetic bits remain paid separately. The representation promise is per requested activity/prefix, not one polynomial-size list covering every possible prefix.

The existing fixed-action proof is preserved. No new generic all-time runtime, practical advantage, higher-arity extension, or priority claim is made. The independent audit is complete and supports the scoped representation-size and conditional pairing statements. See independent_audit/REPORT.md. It explicitly does not clear a warmstart constructor, efficient certification or an all-time sampler.
