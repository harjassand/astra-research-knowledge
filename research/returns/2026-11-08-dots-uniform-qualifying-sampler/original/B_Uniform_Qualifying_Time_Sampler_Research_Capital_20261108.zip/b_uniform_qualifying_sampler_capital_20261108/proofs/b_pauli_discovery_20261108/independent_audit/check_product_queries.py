import numpy as np,itertools,math,json
from pathlib import Path
rng=np.random.default_rng(20261109);N=3;d=1<<N
I=np.eye(2,dtype=complex)
ps=[I,np.array([[0,1],[1,0]],complex),np.array([[0,-1j],[1j,0]],complex),np.diag([1,-1]).astype(complex)]
def kron(v):
 o=np.ones((1,1),complex)
 for a in v:o=np.kron(o,a)
 return o
z=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d));rho=z@z.conj().T;rho/=np.trace(rho);O=d*rho
D=2*N;ss=list(itertools.product((-1,1),repeat=D));inds=list(itertools.product((0,1),repeat=D))
f=[];eigmin=1
for s in ss:
 local=[(I+(s[2*i]*ps[1]+s[2*i+1]*ps[2]+s[2*i]*s[2*i+1]*ps[3])/2)/2 for i in range(N)]
 eigmin=min(eigmin,*[np.linalg.eigvalsh(x)[0] for x in local])
 f.append(float(np.trace(O@kron(local)).real))
f=np.array(f);chars=np.array([[math.prod(s[i] for i,a in enumerate(ix) if a) for s in ss] for ix in inds]);fh=chars@f/len(ss)
errs=[];ec=[]
for ix,v in zip(inds,fh):
 labels=[{(0,0):0,(1,0):1,(0,1):2,(1,1):3}[ix[2*i:2*i+2]] for i in range(N)]
 w=sum(a!=0 for a in labels);c=float(np.trace(rho@kron([ps[a] for a in labels])).real)
 errs.append(abs(v-2**(-w)*c))
# membership bucket-energy identity, exact average via conditional Fourier transform
for k in range(D+1):
 for pref in itertools.product((0,1),repeat=k):
  e=sum(v*v for ix,v in zip(inds,fh) if ix[:k]==pref)
  vals=[]
  for suffix in itertools.product((-1,1),repeat=D-k):
   acc=0
   for prefix in itertools.product((-1,1),repeat=k):
    s=prefix+suffix;j=ss.index(s)
    acc+=f[j]*math.prod(prefix[i] for i,a in enumerate(pref) if a)
   vals.append((acc/(2**k))**2)
  ec.append(abs(e-sum(vals)/len(vals)))
# Product-effect centered norm bounds on blocks of sizes1..7
center=[]
for a in range(1,8):
 vals=np.array([1+np.sqrt(3)/2,1-np.sqrt(3)/2]);eig=np.array([1.])
 for _ in range(a):eig=np.multiply.outer(eig,vals).ravel()
 p=1+1/a;M=eig-1
 center.append({'sites':a,'trace_norm':float(np.mean(abs(M))),'p_norm':float(np.mean(abs(M)**p)**(1/p)),'op_norm':float(max(abs(M))),'bound_trace':2,'bound_p':3})
 assert center[-1]['trace_norm']<=2+1e-12 and center[-1]['p_norm']<=3+1e-12
# Warmtime envelope factors: log norms proportional to N=tau*L, divide by L.
constants=[]
for u in (0.0001,.1,.5):
 theta=.1; base=4
 row=[]
 for t in (1,2,4,8,16,32,128,1024,1e6):
  s=base+2*math.ceil(math.log2(t+2))
  row.append({'tau':t,'sigma':s,'logB_per_L':2*math.log(2)*t/(1+math.exp(s)),'logCp_per_L':(math.log(2)+3*u)*t*math.exp(-(2*s-4*theta)/(1+4*u))})
 constants.append({'u':u,'samples':row})
result={'tetrahedral_queries':len(ss),'min_local_eigenvalue':float(eigmin),'max_Fourier_attenuation_error':max(errs),'membership_bucket_checks':len(ec),'max_membership_bucket_error':max(ec),'centered_block_norms':center,'warmtime_envelopes':constants}
Path(__file__).with_name('product_query_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='warmtime_envelopes'},indent=2))
