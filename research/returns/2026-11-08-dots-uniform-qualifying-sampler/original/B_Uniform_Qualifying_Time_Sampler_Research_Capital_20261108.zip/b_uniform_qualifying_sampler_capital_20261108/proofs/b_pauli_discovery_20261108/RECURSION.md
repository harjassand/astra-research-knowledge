# Paying the membership oracle by logarithmic physical-time descent

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

8 November 2026. Proposed constructive upper bound; independent audit pending. This is not a polynomial all-time theorem. It builds on the repaired, twice-reviewed two-body activity theorem, not on the rejected literal source alphabet. Early physical times below that theorem's qualifying contract remain uncovered.

## 1. Scalar problem and paid parameters

Fix rho=h/gamma and physical locality. The scalar problem is

    G(n,tau)=Tr[ exp(T L*) rho_in * product_i A_i ],
    tau=gamma T,

where rho_in is a rational compact product density, each A_i is positive with trace2 and norminfinity<=2, and the local Hamiltonian, positive gamma and T have paid rational encodings. We seek log G to additive error delta, with failure probability at most beta. Both delta,beta are positive and at most1/4. Set

    L=1+ceil(log(100n/(delta beta))).

Base2 rather than natural logarithms changes only constants. Input-encoding costs remain additional polynomial factors throughout. Product-effect admissibility is proved in DISCOVERY_LEMMA Section5.

For all qualifying tau, the established adaptive activity decomposition has at most exp(O_rho(L)) classical work/terms, scalar precision exp(-O_rho(L)), and patch size

    N<=K_rho(tau^2+tau L).

Use the sharper pinned-cluster perturbation budget, not the original termwise 2^-m^2 physical-oracle tolerance. The latter would defeat the recurrence below. Classical Ursell integers still need O(m^2) bits and are paid separately.

There is an immediate late-time scalar shortcut. The audited HC/gap sandwich gives

    ||2^n rho_T-I||infinity<=6n exp(-tau),  tau>=log n.

A positive normalized product effect then gives |G-1|<=6n exp(-tau). If this is <=delta/2, return log G=0 to error delta. A sufficient test uses rational upper logarithm bounds, without computing an exponentially tiny real. In every non-shortcut call tau<=C L for an absolute constant C. Thus every required patch has N<=K'_rho tau L.

## 2. Fixed finite base interval

Choose an integer s_base, depending only on fixed rho and locality, such that the b=8 activity condition holds for every action >=s_base. For an explicit construction, write R0=max(4096,4096*15,128*2403), a=12rho Delta and C0=4+32*2404. The b=8 condition has right side at most C0+2log_2(R0+a tau+1)+2. Its derivative is at most2/(tau log2)<1 for tau>=4. Choose an integer s_base>=4,4theta by doubling until it exceeds this continuous upper bound at itself, using a certified upper logarithm. The inequality then holds for every larger tau.

Define the integer warmtime action

    sigma(tau)=s_base+2 ceil(log_2(tau+2)).

Choose a finite constant tau_base so that for every tau>tau_base, sigma(tau)<=tau/3. For example choose tau_base>=12 by doubling until s_base+2log_2(tau_base+2)+2<=tau_base/3. The difference of the right side and this continuous upper bound is increasing thereafter. This is a paid constant preprocessing step at fixed rho. Qualifying calls with tau<=tau_base use the established dense activity evaluator. Their cost is exp(O_rho(L)), with constants depending on this finite base interval. No procedure alters the supplied physical time.

This base handles all originally qualifying small times; it does not claim to handle unqualifying early times.

## 3. Construct boundaries at sigma, not at earlier backward halvings

Consider one switched patch scalar at total action tau>tau_base. Let R=2^N rho_in and A=product A_i. Evolve each boundary only for sigma/gamma:

    R_sigma=exp[(sigma/gamma)L*]R,
    A_sigma=exp[(sigma/gamma)L]A.

Both are positive with normalized trace one. The exact scalar equals

    G=tau_normalized[ A_sigma exp[((tau-2sigma)/gamma)L*] R_sigma ].

They need not have bounded norms independent of outer size; polynomial outer budgets suffice.

Physical hypercontractivity, starting at exponent1+exp(-sigma) and ending at1+exp(sigma), gives

    ||R_sigma||infinity, ||A_sigma||infinity
       <=2^[2N/(1+exp(sigma))] =: B.

Indeed normalized Schatten-q to infinity costs2^(N/q), and the initial positive normalized operator costs2^[N(1-1/p)]. Their sum is2N/(1+exp(sigma)).

The earlier audited coefficient/weight regularity, replacing its total half-evolution action tau by2sigma, gives

    a=exp[-(2sigma-4theta)/(1+4u)],
    C_p=exp[(log2+3u)N a],
    C_theta=exp[(log2)N a],

with fixed u=1/p-1/2 in(0,1/2], theta>0. Because sigma>=s_base+2log(tau+2), N<=K'_rho tau L, and 1+4u<=3,

    log B, log C_p, log C_theta <=K''_rho L.

All are replaced computationally by certified rational/integer upper bounds with constant-factor slack in their logarithms. This is uniform over switched subpatches and both Hamiltonian signs.

Let the desired patch scalar error be delta_G=exp(-O_rho(L)). Choose each boundary and propagation error eta<=delta_G/[10(C_p+1)]. The final Cauchy-Schwarz pairing error is then <=delta_G, including input-list propagation error. DISCOVERY_LEMMA constructs both warm boundaries with membership-query count exp(O_rho(L)), normalized additive query error xi=exp(-O_rho(L)), and failure budgets exp(-O_rho(L)). Its O_sigma norm bounds certify the omitted tails.

The discovered approximate list need not preserve the exact p-norm C_p: estimation error can spread among its S_0 leaves. After the mandatory clipping of every recovered coefficient to[-1,1], a safe explicit supplied-list bound is C_in=S_0, since there are at most S_0 entries. This bound holds on bad randomized runs as well as successful ones. It is still exp(O_rho(L)). Use this larger C_in in SPARSE_PROPAGATION, rather than assuming that2-norm approximation preserves p. That paid routine propagates R_sigma for the remaining nonnegative time tau-2sigma at total work exp(O_rho(L)), then computes the sparse coefficient pairing.

We never try to sparsify a boundary at time sigma/2 or earlier on this same N-site patch. The H=0 backward-halving obstruction therefore does not apply to this step.

## 4. Each membership query is a strictly shorter scalar call

For a queried sign string s, f(s)=Tr[O_sigma rho_s] is a scalar product-input/product-effect evolution at action sigma. The Hamiltonian is the original restricted/switched Hamiltonian, or its sign reversal. The queried product effects have rational entries of constant bit length. Original input states stay compact product states; no correlated restart occurs.

Finite switched patches are retiled at the child scale with their deleted interactions still deleted; no full-rectangle interaction promise is invented. If a full rectangular host is wanted, a connected union of parent blocks has a bounding rectangle with O(N^2) sites. Pad missing sites by decoupled maximally mixed inputs and effect-I outputs. They multiply G by one, and multiply the normalized boundary operators by identities, leaving all coefficient and operator norms unchanged. This polynomial padding only adds O(log N) to the child logarithmic budget. Local activity patches still contain at most r_child^2 v sites, independent of this global padding; do not use the whole bounding rectangle as the warm-boundary patch.

Call the same scalar evaluator on n'<=O(N^2) sites (n'=N when no padding is needed), action tau'=sigma(tau), log tolerance

    delta'<=xi/[4(B+1)],

and failure probability beta'<=beta_local/(4Q_max). Before exponentiation, compare the returned log with certified thresholds: above log B return B, below log(xi/4) return0, and only exponentiate in the bounded intervening interval to additive xi/4. This prevents a failed child from creating enormous transient numbers. Clipping preserves the good-event additive guarantee with the stated constant slack. Q_max is the deterministic cap on all membership calls in the current scalar evaluation, including all activities and the two boundaries. All random branches have deterministic work caps. Discovery clips coefficients to[-1,1], scalar answers are clipped to their certified value range, and a failed size, positivity or finite-log check returns a fixed finite fallback plus a failure flag. In particular no bad discovery event can trigger an unbounded norm-dependent propagation. Baseline logs are only taken after checking z>=1/4; the true baselines exceed1/2, so the prescribed precision leaves slack. These safeguards do not promise correctness on failed runs; their probabilities are charged to beta. The local concentration bounds use fresh randomness. A union bound is valid conditionally on every previous adaptive query, since each child guarantee is uniform in its supplied product input/effect.

After including n', all arithmetic, final list rounding, cluster count and failure allocation, there is a constant A_rho>1 such that

    L'<=A_rho L.

This constant is real resource inflation, not hidden in a uniform polynomial exponent. Input coefficient bits are inherited, time sigma/gamma is rational, and the binary logarithm ceiling is obtained by integer comparisons. Child queries introduce no uncharged irrational state parameters. Required transcendental upper bounds and exponentiation use precision O_rho(L) plus paid input/action bits.

The child action is strictly smaller than the parent for tau>tau_base, so this is a terminating recursion rather than a circular oracle assumption. At each level it re-decomposes the smaller-time scalar problem into its own smaller activity patches. It does not run the shorter-time dense simulation on the original N-site patch.

## 5. Full recurrence and what it does not prove

Let d(tau) be the number of iterations of sigma required to enter the finite base interval. With the fixed additive s_base and logarithm factor,

    d(tau)=O_rho(1+log* tau).

At depth j the logarithmic accuracy/confidence budget is at most A_rho^j L. The number of child calls and all local work at that depth have logarithms O_rho(A_rho^j L). Multiplying the branching factors and adding the work of the base calls yields a conservative total bit bound

    poly(paid original input/action factors)
      * exp[ L exp(O_rho(1+log* tau)) ].

For qualifying full-output sampling before the usual mixing shortcut, tau=O(log(n/epsilon)). With polynomially many log-marginal calls and per-call confidence/error budgets epsilon/poly(n), this becomes

    poly(paid inputs/actions)
      * exp[ O(log(n/epsilon))
             * exp(O_rho(1+log* log(n/epsilon))) ].

Failures contribute at most their total probability to output TV; the existing log-to-conditional and finite-random-bit construction pays the rest. This is a constructive near-polynomial bound if every dependency and finite implementation above survives audit. It is asymptotically smaller than the previously dense exp(O_rho(log^2(n/epsilon))) bound, but its exponent is not uniformly bounded as n grows. It is not a uniform polynomial algorithm, does not cover the early unqualifying interval, and has no practical implementation or novelty claim.

## 6. Current bottleneck to true polynomiality

The Fourier attenuation, threshold-energy accuracy and two-sided pairing make each recursive log-precision budget a fixed multiple of its parent's. At unbounded log* depth this yields A_rho^d. It is invalid to call this a constant simply because log* grows slowly. A uniform polynomial claim would need a sharper error/precision recurrence, a direct paid membership operation, or another constructor. No such step is established here.
