# Constructing approximate Pauli lists from paid normalized membership queries

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

8 November 2026. Derived reduction, currently under independent review. This is not a claim that output samples implement the value oracle, nor a uniform polynomial simulator. The prefix-energy search is standard Fourier-learning machinery. See PRIOR.md for the directly relevant quantum literature.

## 1. Rational product probes and the exact access model

Let O be a positive N-qubit operator with normalized trace one, O=sum_P c_P P. Its coefficients are real. Suppose a certified upper bound B>=max(1,||O||infinity) is available. For each pair of signs a,b define

    rho(a,b) = [I+(aX+bY+abZ)/2]/2.

Its Bloch radius is sqrt(3)/2<1, and its matrix entries are rational complex numbers. On D=2N sign bits s take the product state rho_s. Define the normalized membership function

    f(s)=Tr(O rho_s),     0<=f(s)<=B.

Encode each local Pauli as I:00, X:10, Y:01, Z:11. With the corresponding Walsh character chi_P,

    f(s)=sum_P c_P 2^(-wt(P)) chi_P(s).

Thus fhat(P)=2^(-wt(P))c_P. The 2^-wt factor is explicitly paid below. Access means evaluating f(s) to a requested additive error, not drawing s or an output from the physical state. A physical probability may be 2^-N times this value. Ordinary output sampling therefore does not provide this oracle to inverse-polynomial normalized error.

## 2. Analytic tail budgets

Assume fixed 1<=p<2 and theta>0, with certified norm bounds

    sum|c_P|^p <= C_p^p,
    sum exp(2theta wt(P))|c_P|^2 <= C_theta^2,

where C_p,C_theta>=1. For a requested coefficient2 error 0<eta<=1, choose a positive rational threshold sigma no larger than

    [eta/(4 C_p^(p/2))]^[2/(2-p)]

and a nonnegative integer W, capped at N, no smaller than

    theta^(-1) log(4C_theta/eta).

If the cap N is reached there is no weight tail. Otherwise the weight tail has2-norm<=eta/4. Coefficients of magnitude below sigma have2-norm at most

    C_p^(p/2) sigma^(1-p/2) <= eta/4.

Any retained set containing all coefficients with wt<=W and |c|>=sigma therefore has omitted2-norm<=eta/2. Set lambda=sigma 2^-W. Every required coefficient has |fhat|>=lambda. Rational lower/upper approximations to the thresholds with fixed constant slack suffice; evaluating real powers to their stated one-sided bounds uses polynomial precision in the logarithms of these budgets.

## 3. A robust complete prefix search

For a coefficient prefix alpha of length k in the D-bit Fourier index, let

    E_alpha=sum_beta fhat(alpha,beta)^2.

The exact identity is

    E_alpha = E_(v,u,u') [ f(u,v) f(u',v) chi_alpha(u)chi_alpha(u') ],

where v is a uniform suffix and u,u' are independent uniform prefixes. The two strings share v. Every sample is in[-B^2,B^2]. This is a membership-query identity, not a two-copy physical measurement claim.

Starting from the root, estimate the energies of the two children of every retained prefix. Retain a child if its estimate is at least lambda^2/2. Make every energy estimate accurate to lambda^2/4. Then every leaf with |fhat|>=lambda survives. Every retained prefix has true energy at least lambda^2/4. Parseval and f<=B imply total energy<=B^2, so at most

    S_0=ceil(4B^2/lambda^2)

nodes are retained at any level. Explicitly abort to a declared failure if a level exceeds S_0. At most K=2D S_0 energies are tested, including adaptive choices.

Each membership answer is clipped to[0,B]. If its additive error is at most xi, the bias of a product sample is at most2B xi. Choose xi<=lambda^2/[64(B+1)]. With O(B^4 lambda^-4 log(4K/beta)) independent samples per node, Hoeffding gives statistical error<=lambda^2/8 except with total probability beta/4. Together these are below lambda^2/4. Conditional versions of the bound and a union bound apply to adaptive prefixes.

Thus the number of membership queries in the tree is

    O(D B^6 lambda^-6 log(4D S_0/beta)).

This deliberately loose bound is sufficient; no optimization is claimed.

## 4. Signed leaf values, rounding and certification

Discard discovered leaves of Pauli weight>W. There are at most S_0 others. Set

    delta_hat = eta 2^-W/(2 sqrt(S_0)).

Estimate each signed Fourier coefficient from E_s[f(s)chi_P(s)] with accuracy delta_hat/2, reserving the other half for common-dyadic rounding. O(B^2 delta_hat^-2 log(4S_0/beta)) samples per leaf suffice, with statistical error delta_hat/4. Also require xi<=delta_hat/8. The coefficient recovered by multiplying by2^wt has error at most eta/(2sqrt(S_0)). Clip every recovered real Pauli coefficient to[-1,1] before common-dyadic rounding: since O is positive with normalized trace one, each true coefficient is a Pauli expectation in[-1,1], so clipping cannot increase error. Round toward zero on the chosen dyadic grid, with its error included in the eta/2 coefficient allocation (equivalently halve delta_hat for statistical estimation). This also bounds every returned coefficient on unsuccessful randomized runs. Their total coefficient2 rounding/estimation error is at most eta/2. The tail estimate from Section2 gives final error<=eta.

The complete sample count is polynomial in D, B, C_p, C_theta, 1/eta and log(1/beta), at fixed p and theta. Each Fourier character takes O(D) bit operations; each query uses O(D) unbiased random bits. Thresholds, signed means and products need O(log B+log S_0+log(1/lambda)+log(1/eta)+log(1/beta)) bits, plus polynomial accumulation overhead. Use fixed caps on samples and retained nodes so failure never produces unbounded work.

If membership calls are randomized, give each call failure probability at most beta/(4Q_max), where Q_max is the deterministic cap on all calls. Fresh child randomness plus the uniform error guarantee for every input makes the adaptive union bound valid. On any declared failure return a fixed fallback list; this does not certify that failed run. The algorithmic guarantee is that a successfully analyzed run has2-norm error<=eta with probability at least1-beta. It is not an efficiently verifiable proof for an arbitrary externally supplied list.

The certificate of omitted mass is the analytic p/weight norm bound together with completeness of the threshold search. No unpriced purity oracle is needed.

## 5. Why the values are physical scalar subproblems

If O=exp(tL)(2^N rho_in) for compact product rho_in, then

    f(s)=Tr[exp(tL)rho_in * product_i(2rho(s_i))].

This is a normalized positive product-effect expectation for the same local noisy dynamics. The adjoint boundary is another such problem with the Hamiltonian sign reversed. Mixed product inputs remain compact. Product effects A_i=2rho(s_i) have normalized trace one and norminfinity<2.

The repaired connected-activity argument extends directly from computational projectors to these effects: on each block A_v is positive, normalized trace one and norminfinity<=2^a. Hence M_v=A_v-I has normalized1-norm<=2 and normalized(1+1/a)-norm<=3, exactly the constants used by that proof. Every switched scalar is positive; isolated block normalizers retain their lower bound1-e^-c. All other spatial, Fourier-label, normalization and KP steps are unchanged. This is a product-effect scalar extension, not permission to insert arbitrary correlated effects.

A log evaluator for this scalar with additive log error delta<=xi/[4(B+1)] yields an additive-xi value after exponentiation and rounding, since f<=B and delta<=1. The extension and this conversion are the basis of the paid recursion in RECURSION.md. No actual output sample is used as a normalized-membership answer.
