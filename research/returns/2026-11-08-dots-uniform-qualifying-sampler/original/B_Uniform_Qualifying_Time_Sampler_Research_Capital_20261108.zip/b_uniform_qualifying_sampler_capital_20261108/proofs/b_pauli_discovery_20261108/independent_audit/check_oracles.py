import numpy as np, itertools, math, json
from pathlib import Path
out=Path(__file__).parent
rng=np.random.default_rng(20261108)
I=np.eye(2,dtype=complex)
ps=[I,np.array([[0,1],[1,0]],complex),np.array([[0,-1j],[1j,0]],complex),np.diag([1,-1]).astype(complex)]
def kron(v):
 a=np.ones((1,1),complex)
 for x in v:a=np.kron(a,x)
 return a
def swap_suffix(n,m):
 d=1<<n;U=np.zeros((d*d,d*d),complex); mask=(1<<(n-m))-1
 for a in range(d):
  for b in range(d):
   aa=(a&~mask)|(b&mask);bb=(b&~mask)|(a&mask)
   U[aa*d+bb,a*d+b]=1
 return U
n=3;d=1<<n
z=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d));rho=z@z.conj().T;rho/=np.trace(rho)
labels=list(itertools.product(range(4),repeat=n));P={a:kron([ps[x] for x in a]) for a in labels}
c={a:float(np.trace(rho@P[a]).real) for a in labels}
bucket_errors=[]; unitary_errors=[]; examples=[]
rho2=np.kron(rho,rho)
for m in range(n+1):
 swap=swap_suffix(n,m)
 for a in itertools.product(range(4),repeat=m):
  pa=P[a+(0,)*(n-m)]
  U=np.kron(pa,pa)@swap
  energy=sum(v*v for b,v in c.items() if b[:m]==a)
  measured=float(np.trace(rho2@U).real)*(2**(n-m))
  bucket_errors.append(abs(measured-energy));unitary_errors.append(float(np.max(abs(U@U-np.eye(d*d)))))
  if len(examples)<5:examples.append({'prefix':a,'energy':energy,'scaled_swap':measured,'raw_variance':4**(n-m)-energy**2})
# The Pauli-conjugation correlation has squared coefficients as its symplectic Fourier transform.
def sign(a,b):return (-1)**sum(x!=0 and y!=0 and x!=y for x,y in zip(a,b))
O=d*rho
F={q:float(np.trace(O@P[q]@O@P[q]).real/d) for q in labels}
conj_err=max(abs(sum(F[q]*sign(p,q) for q in labels)/(4**n)-c[p]**2) for p in labels)
# Fixed-axis normalized outcome functions have exactly the matching Pauli Fourier coefficients.
axis_err=[];norm_bounds=[];B2=sum(x*x for x in c.values())
for axes in itertools.product((1,2,3),repeat=n):
 f={x:float(np.trace(rho@kron([I+sgn*ps[a] for sgn,a in zip(x,axes)])).real) for x in itertools.product((-1,1),repeat=n)}
 energy=sum(v*v for v in f.values())/d
 norm_bounds.append(energy/B2)
 for subset in itertools.product((0,1),repeat=n):
  value=sum(v*math.prod(sgn for take,sgn in zip(subset,x) if take) for x,v in f.items())/d
  a=tuple(axis if take else 0 for take,axis in zip(subset,axes))
  axis_err.append(abs(value-c[a]))
# Verify Parseval query exclusion bound for hidden fixed-weight diagonal parity candidates.
N=10;W=3;a=0.3;tol=0.015
xs=np.array(list(itertools.product((-1,1),repeat=N)),dtype=np.int8)
supports=list(itertools.combinations(range(N),W))
chars=np.array([np.prod(xs[:,S],axis=1) for S in supports],float)
sqchecks=[]
for _ in range(20):
 g=rng.uniform(-1,1,size=len(xs));gh=chars@g/len(xs)
 sqchecks.append({'energy':float(gh@gh),'query_l2':float(g@g/len(xs)),'detected':int(np.count_nonzero(abs(a*gh)>tol)),'upper_count':(a/tol)**2})
assert all(t['energy']<=t['query_l2']+1e-12 and t['detected']<=t['upper_count'] for t in sqchecks)
# Exact raw sample-mean variance, no algorithmic lower bound.
variance=[{'N':N,'prefix_length':m,'maxmix_identity_prefix_energy':1,'raw_scaled_swap_variance':4**(N-m)-1} for N in (4,8,12,20) for m in (0,N//2,N)]
# Conservative energy-oracle tree search includes all heavy leaves with bounded work.
vec=rng.normal(size=4**6);vec*=rng.random(size=vec.size)<0.015;vec/=max(np.linalg.norm(vec),1)
t=0.03;budget=t*t/4;total=float(vec@vec);found=[];front=[((),vec)];counts=[]
for dep in range(6):
 nxt=[]
 for pre,v in front:
  for lab,child in enumerate(np.split(v,4)):
   e=float(child@child); est=e+rng.uniform(-budget,budget)
   if est>=t*t/2:nxt.append((pre+(lab,),child))
 counts.append(len(nxt));front=nxt
for pre,v in front:found.append(np.ravel_multi_index(pre,(4,)*6))
heavy=set(np.flatnonzero(abs(vec)>=t));assert heavy.issubset(found)
# Fixed-weight entropy illustrating SQ/list-description distinction; log10 values avoid enormous ints.
size=[]
for L in (4,8,16,32,64,128):
 N=L*L;W=L;logM=(math.lgamma(N+1)-math.lgamma(W+1)-math.lgamma(N-W+1))/math.log(10)
 size.append({'L':L,'N':N,'W':W,'log10_candidate_supports':logM,'log10_outer_budget_expL':L/math.log(10)})
res={'bucket_count':len(bucket_errors),'max_bucket_identity_error':max(bucket_errors),'max_observable_unitarity_error':max(unitary_errors),'max_pauli_conjugation_fourier_error':conj_err,'fixed_axis_fourier_checks':len(axis_err),'max_fixed_axis_fourier_error':max(axis_err),'max_fixed_axis_L2_to_Pauli_L2_squared_ratio':max(norm_bounds),'bucket_examples':examples,'statistical_query_parseval_checks':sqchecks,'raw_swap_variance':variance,'energy_tree':{'N':6,'threshold':t,'total_energy':total,'heavy_count':len(heavy),'found_count':len(found),'level_counts':counts,'per_level_bound':4*total/t**2,'all_heavy_found':True},'support_count_scaling':size}
(out/'results.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps({k:v for k,v in res.items() if k not in ('statistical_query_parseval_checks','raw_swap_variance','bucket_examples','support_count_scaling')},indent=2))
