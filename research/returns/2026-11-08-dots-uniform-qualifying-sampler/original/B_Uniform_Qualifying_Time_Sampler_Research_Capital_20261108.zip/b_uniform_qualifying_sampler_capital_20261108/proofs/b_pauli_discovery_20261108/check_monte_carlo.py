"""Operational prefix search with a cheap, exactly known membership oracle.
This tests concentration implementation, not physical scalar-oracle complexity.
"""
import json,math
from pathlib import Path
import numpy as np
rng=np.random.default_rng(9861);N=4;D=8;B=1.4;lam=.3;beta=.05
# O=(I+.8 X_1) tensor I, so f=1+.4 a_1.
def oracle(s):
    return 1.+.4*(1.-2.*(s&1))
def parity(v):
    # Fixed D-bit parity, vectorized.
    v=v.copy();v^=v>>4;v^=v>>2;v^=v>>1
    return 1.-2.*(v&1)
S0=math.ceil(4*B*B/lam**2);K=2*D*S0
# Two-sided Hoeffding at statistical error lam^2/8.
count=math.ceil(128*B**4/lam**4*math.log(4*K/beta))
xi=lam**2/(64*(B+1));calls=0;tested=[];alive=[0]
for k in range(1,D+1):
    new=[]
    for old in alive:
        for bit in [0,1]:
            alpha=old+(bit<<(k-1));sm=0.;rem=count
            while rem:
                m=min(rem,200000);rem-=m
                u=rng.integers(0,2**k,size=m,dtype=np.int64)
                up=rng.integers(0,2**k,size=m,dtype=np.int64)
                v=rng.integers(0,2**(D-k),size=m,dtype=np.int64)
                # Deliberately biased but within the allowed membership tolerance.
                fa=np.clip(oracle(u+(v<<k))+xi,0,B)
                fb=np.clip(oracle(up+(v<<k))+xi,0,B)
                sm+=np.sum(fa*fb*parity(alpha&u)*parity(alpha&up));calls+=2*m
            est=sm/count
            truth=(1. if alpha==0 else 0.)+(.16 if alpha==(1%(1<<k)) else 0.)
            tested.append(dict(k=k,alpha=alpha,true_energy=truth,estimate=float(est),error=float(abs(est-truth))))
            if est>=lam**2/2:new.append(alpha)
    alive=new;assert len(alive)<=S0
assert set([0,1])<=set(alive)
out=dict(scope='Monte Carlo implementation with explicitly free analytic product-model membership; not an implementation of the recursive physical oracle.',N=N,lambda_test=lam,beta=beta,samples_per_node=count,membership_calls=calls,leaf_indices=alive,max_energy_error=max(x['error'] for x in tested),allowed_energy_error=lam**2/4,all_heavy_found=True,tests=tested)
Path(__file__).with_name('monte_carlo_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='tests'},indent=2))
