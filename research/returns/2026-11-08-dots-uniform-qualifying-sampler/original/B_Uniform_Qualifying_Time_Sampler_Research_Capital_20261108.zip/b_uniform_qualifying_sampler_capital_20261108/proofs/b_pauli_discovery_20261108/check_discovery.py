"""Dense small-system diagnostics of the membership reduction.
Not an implementation of the recursively paid large-system scalar evaluator.
"""
import itertools,json,math
from pathlib import Path
import numpy as np
from scipy.linalg import expm
OUT=Path(__file__).parent
I=np.eye(2,dtype=complex); X=np.array([[0,1],[1,0]],complex)
Y=np.array([[0,-1j],[1j,0]],complex); Z=np.diag([1,-1]).astype(complex)
P1=[I,X,Y,Z]
# Walsh local index agrees with I00 X10 Y01 Z11; integer bit significance is immaterial.
enc=[0,1,2,3]
def kron(xs):
    z=np.array([[1]],complex)
    for x in xs:z=np.kron(z,x)
    return z
def hadamard(v):
    v=np.asarray(v,float).copy(); h=1
    while h<len(v):
        for i in range(0,len(v),2*h):
            a=v[i:i+h].copy();b=v[i+h:i+2*h].copy()
            v[i:i+h]=a+b;v[i+h:i+2*h]=a-b
        h*=2
    return v
rng=np.random.default_rng(20261108)
results=[]
for N in [2,3,4]:
    words=list(itertools.product(range(4),repeat=N)); mats=np.array([kron([P1[p] for p in w]) for w in words]); dim=2**N
    H=np.zeros((dim,dim),complex)
    for i in range(N-1):
        for a,b,j in [(1,1,.63),(2,3,-.37),(3,2,.21)]:
            w=[0]*N;w[i]=a;w[i+1]=b;H+=j*mats[words.index(tuple(w))]
    for i in range(N):
        w=[0]*N;w[i]=2;H+=.19*mats[words.index(tuple(w))]
    # Generator in the orthonormal normalized Pauli basis.
    L=np.zeros((4**N,4**N),float)
    for k,P in enumerate(mats):
        C=-1j*(H@P-P@H)
        L[:,k]=np.einsum('aij,ji->a',mats,C).real/dim
        L[k,k]-=.7*sum(x!=0 for x in words[k])
    local=[]
    for i in range(N):
        b=rng.normal(size=3);b*=.8/np.linalg.norm(b);local.append((I+b[0]*X+b[1]*Y+b[2]*Z)/2)
    R=dim*kron(local)
    c0=np.einsum('aij,ji->a',mats,R).real/dim
    for t in [.3,1.2]:
        c=expm(t*L)@c0;O=np.einsum('a,aij->ij',c,mats)
        f=np.empty(4**N); expected=np.zeros(4**N)
        for j,w in enumerate(words):
            idx=sum(enc[w[i]]<<(2*i) for i in range(N));expected[idx]=c[j]*2.**(-sum(x!=0 for x in w))
        for s in range(4**N):
            rr=[]
            for i in range(N):
                a=1 if ((s>>(2*i))&1)==0 else -1
                b=1 if ((s>>(2*i+1))&1)==0 else -1
                rr.append((I+(a*X+b*Y+a*b*Z)/2)/2)
            f[s]=np.trace(O@kron(rr)).real
        fh=hadamard(f)/len(f);D=2*N
        err=float(np.max(abs(fh-expected)));engerr=0.
        # Exhaustive shared-suffix identity, all prefixes, using conditional means.
        for k in range(D+1):
            for alpha in range(2**k):
                direct=sum(fh[alpha+(beta<<k)]**2 for beta in range(2**(D-k)))
                vals=[]
                for v in range(2**(D-k)):
                    mean=sum(f[u+(v<<k)]*((-1)**((alpha&u).bit_count())) for u in range(2**k))/2**k
                    vals.append(mean**2)
                engerr=max(engerr,abs(direct-np.mean(vals)))
        # Test threshold completeness under independently chosen worst-admissible energy perturbations.
        lam=.01;alive=[0];cap=math.ceil(4*np.max(f)**2/lam**2);maxalive=1
        for k in range(1,D+1):
            new=[]
            for a0 in alive:
                for bit in [0,1]:
                    a=a0+(bit<<(k-1));E=sum(fh[a+(b<<k)]**2 for b in range(2**(D-k)))
                    perturb=rng.choice([-1,1])*lam**2/4
                    if E+perturb>=lam**2/2:new.append(a)
            alive=new;maxalive=max(maxalive,len(alive));assert len(alive)<=cap
        heavy=set(np.flatnonzero(abs(fh)>=lam));assert heavy<=set(alive)
        results.append(dict(N=N,t=t,min_f=float(min(f)),max_f=float(max(f)),operator_bound=float(np.linalg.eigvalsh(O)[-1]),fourier_error=err,prefix_identity_error=float(engerr),lambda_test=lam,heavy_count=len(heavy),retained_count=len(alive),all_heavy_found=True,max_nodes=maxalive))
        assert err<1e-12 and engerr<1e-12 and min(f)>-1e-12
# Hidden support, not a B hardness instance: its Fourier coordinate is found by membership prefixes.
N=12;Pidx=sum(3<<(2*i) for i in [0,3,7,11]);amp=.125;weight=4;fh={0:1.,Pidx:amp/2**weight};lam=amp/2**weight
alive=[0];history=[]
for k in range(1,2*N+1):
    new=[]
    for a0 in alive:
        for bit in [0,1]:
            a=a0+(bit<<(k-1));E=sum(val*val for key,val in fh.items() if key%(1<<k)==a)
            if E-lam**2/4>=lam**2/2:new.append(a)
    alive=new;history.append(len(alive))
assert Pidx in alive
out={'scope':'Small dense exact-value diagnostics; no large recursive scalar evaluator was executed.','physical_cases':results,'hidden_support_membership_test':{'N':N,'weight':weight,'found':Pidx in alive,'max_nodes':max(history),'index':Pidx},'max_fourier_error':max(x['fourier_error'] for x in results),'max_prefix_identity_error':max(x['prefix_identity_error'] for x in results)}
(OUT/'discovery_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
