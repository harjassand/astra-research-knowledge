# Constructing the Pauli lists by a paid time recursion

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

8 November 2026. The proposed construction and its resource accounting have passed a first independent analytic review, subject to the previously reviewed two-body fixed-action activity theorem. The signed/numerical diagnostics are not a production implementation. The completed independent audit, reviewed source hashes and independent checks are in independent_audit/REPORT.md.

## What changed

The previous result proved that every required local activity has polynomial-size two-sided Pauli approximations, but did not say how to find them. The current construction supplies a randomized finite-bit discovery procedure whose probability queries are recursively paid, rather than assumed free. Its cost is weaker than polynomial but improves the earlier dense upper bound.

For fixed noise-to-coupling ratio and locality, write tau=gamma T and L=O(log(n/epsilon)). Throughout the existing qualifying-time regime, the resulting bound is

    poly(paid inputs and dimensionless actions)
      * exp[ L exp(O_rho(1+log* tau)) ].

Before the familiar global mixing shortcut, tau=O(L), giving exp[L exp(O_rho(1+log* L))]. This is asymptotically smaller than the dense exp(O_rho(L^2)) bound. It is not uniformly polynomial: the log-precision budget grows by a fixed factor at each unbounded log* recursion depth. Early times below the activity theorem's qualifying contract remain uncovered. Constants are enormous and no practical speedup is demonstrated.

## The concrete construction

1. **Rational normalized membership probes.** Four positive one-qubit states rho(a,b)=[I+(aX+bY+abZ)/2]/2 turn an evolved operator's Pauli coefficients into the Walsh spectrum fhat(P)=2^-weight(P)c_P. The queried function is a normalized positive product-effect probability, bounded by a paid operator-norm estimate. Ordinary physical output samples do not implement these queries.

2. **Complete heavy-coefficient discovery.** A standard Fourier prefix-energy search finds every coefficient above the paid threshold. The existing coefficient-p and exponentially weighted2 bounds control all omitted small coefficients and high-weight coefficients. Signed leaf estimation, common-dyadic rounding, query concentration, adaptive failure probabilities and retained-node caps are explicit. This certifies the algorithm's error with high probability; it is not a public proof checker for an arbitrary supplied list.

3. **Pay the value queries at shorter physical time.** Construct the two patch boundaries at action sigma=s_base+2ceil(log2(tau+2)), then propagate one explicit sparse list across the remaining time using the established coefficient-p-contractive sparse mechanism. Each membership value is evaluated by the same connected-activity log evaluator at the strictly shorter action sigma, with compact product input and product effects. The finite base interval uses the already paid dense fixed-action evaluator. No correlated product restart or free quantum oracle occurs.

4. **Do not hide the remaining cost.** Patch size is O_rho(tau L), while warm-boundary norm budgets and inverse query tolerances are exp(O_rho(L)). A child query has logarithmic accuracy/confidence budget at most A_rho L, for a fixed A_rho>1. Multiplying those factors through O_rho(log* tau) levels gives the stated bound. Making A_rho^depth a uniform constant would be an error.

## Scope and evidence

The physical model is unchanged: rational/certified product input, static on-site and nearest-neighbor two-body Hamiltonians on the square lattice, and depolarizing replacement on every site. The Hamiltonian may be strongly noncommuting with fully two-dimensional connectivity. Product-effect scalar queries are internal computation; they do not change the requested computational-basis output. Deleted-edge irregular patches are explicitly retiled or polynomially padded with inert sites.

DISCOVERY_LEMMA.md proves the membership reduction and tail certification. SPARSE_PROPAGATION.md pays one conservative local-map/Trotter implementation after the list is constructed. RECURSION.md gives termination, confidence, bit and total-work accounting, including bad-event clipping/fallback safeguards. PRIOR.md identifies the standard Fourier and Pauli-discovery machinery and the access-model differences from current papers.

Executed diagnostics:
- Six noncommuting noisy2-,3- and4-qubit cases verify the rational-probe Fourier map, with maximum error1.12e-16.
- Every prefix-energy identity in those cases agrees within1.34e-15. Perturbing each energy by its maximum allowed error still retains every above-threshold Fourier coefficient.
- A12-qubit hidden-support oracle example is recovered by at most two retained nodes per level. This is an access-model test, not a local-dynamics complexity result.
- An actual randomized prefix search on a known4-qubit product model used42,368,340 cheap analytic membership evaluations. It found both heavy leaves; largest energy error .00319 was below the allowed .0225. The large conservative count illustrates paid concentration cost, not a practical benchmark.

No large recursive physical scalar evaluator has been executed. No claim is made that a quantum sampling oracle, statistical queries, approximate sparsity or sparse-row access alone solves discovery. The independent audit preserves explicit generic/SQ obstructions and the H=0 backward-halving failure.

## What remains for a uniform polynomial result

The previously unpaid membership operation is now reduced all the way to a finite dense base at the above cost. The next exact target is removing repeated constant-factor precision inflation, or supplying a direct polynomial-cost normalized membership/list constructor. A route that merely assumes the queries or hides A_rho^depth does not finish that task. The separate early-time regime also remains open. Neither this construction nor the earlier representation theorem is a general solution to B, and no historical-first claim is made.
