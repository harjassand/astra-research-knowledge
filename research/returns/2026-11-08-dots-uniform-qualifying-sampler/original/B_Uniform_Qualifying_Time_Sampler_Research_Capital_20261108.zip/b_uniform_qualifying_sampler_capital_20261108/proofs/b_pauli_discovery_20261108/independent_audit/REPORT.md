# Independent audit of structured Pauli discovery

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

8 November 2026. This is an audit of access models and proposed construction steps, not a proof of a classical sampler. The previously reviewed polynomial description-size result remains valid. Its missing step is a physical polynomial-cost method to discover the descriptions from the local generator and compact product boundaries.

## Current findings

1. A prefix-energy oracle is sufficient for polynomial heavy-coefficient discovery, and the already proved analytic norm budgets can certify the tail. A separate purity oracle is unnecessary once the discovery guarantee is established.
2. The obvious physical implementations of the oracle have unpaid exponential normalization. This is visible even for the maximally mixed state, which is easy to sample. It is therefore an estimator/access-model barrier, not a sampling-hardness result.
3. Rational product probes give an exact Boolean Fourier reduction and fit the fixed-action product-effect extension. The later paid logarithmic-time recursion is reviewed below: it is constructive but its log-accuracy inflation gives a nonpolynomial bound.
4. Generic small-list promises do not imply efficient discovery even with arbitrary bounded statistical queries. A hidden-parity family gives a precise oracle separation. That family is not asserted to arise from the specified local product-input dynamics.

## Conventions

There are N physical qubits, d=2^N, a positive normalized operator O=d rho, and Pauli coefficients c_P=Tr(rho P)=tau(O P). The proved budgets are

    sum |c_P|^p <= C_p^p,  p<2,
    sum exp(2 theta wt(P)) |c_P|^2 <= C_2^2.

For the intended activity queries, theta and p are fixed by a fixed coupling/noise ratio, while log C_p, log C_2 and the requested log accuracy are O(L), with L=O(log(n/epsilon)). Physical patch size can be O(L^2). These are per-query statements, not a global compact-state claim.

## Conditional discovery and tail certification

For a prefix alpha of length m in the four-letter Pauli alphabet, define

    E_alpha = sum_{Q on the remaining N-m sites} c_(alpha Q)^2.

Suppose each queried E_alpha can be returned with certified absolute error at most t^2/4. Retain a prefix whenever its estimate is at least t^2/2. Every coefficient with |c_P|>=t survives every level. Each retained prefix has true energy at least t^2/4. Since energies at a fixed depth partition the total energy, there are at most 4 C_2^2/t^2 retained prefixes per level. Including children, this gives O(N C_2^2/t^2) energy queries. Leaf signs/values need a separate accurate linear query; squared values alone are insufficient.

The omitted small coefficients satisfy

    sum_{|c_P|<t} |c_P|^2 <= t^(2-p) C_p^p.

Separately, deleting all weights above W has squared error at most C_2^2 exp(-2 theta W). Choose t and W so these two quantities fit the allocated error budget, then charge coefficient rounding in Euclidean norm. This gives a rigorous error certificate from analytic promises and guaranteed discovery. Empirical success on a few coefficients is not such a guarantee. If queries are randomized, their failure probabilities must be union-bounded over the adaptively bounded total query count.

This is an oracle reduction, not a new heavy-hitter principle. Ciancaglini et al., arXiv:2605.00341v1, already use the Pauli prefix-energy tree, Bell measurements and subsystem SWAP tests. Their internal-node estimates retain an exponential factor and their Section IV explicitly discusses the resulting uncertainty. Kushilevitz–Mansour and Goldreich–Levin are the earlier Fourier-search background.

## Exact energy queries and their normalization

Let A be the prefix subsystem and B its complement. Define the Hermitian contraction

    U_alpha = (P_alpha on A copy1) (P_alpha on A copy2) SWAP_B.

Then exactly

    E_alpha = 2^(N-m) Tr[(rho tensor rho) U_alpha].

U_alpha is a Hermitian unitary. A direct projective measurement followed by multiplication by 2^(N-m) has outcomes plus or minus 2^(N-m), hence variance

    Var = 4^(N-m) - E_alpha^2.

For the maximally mixed state and an identity-only prefix, E_alpha=1. The variance is 4^(N-m)-1, despite the entire spectrum being known to consist of the identity coefficient. For a nonidentity prefix it is 4^(N-m). Consequently this raw sample mean does not implement early energy queries with polynomial samples. This is not a claim that every estimator, classical representation, collective measurement or physical simulation must pay that variance.

An alternative exact identity also does not make its query free. For Pauli Q,

    F(Q)=tau(O Q O Q)
        =sum_P c_P^2 (-1)^[P,Q],

where [P,Q] is the binary commutation parity. The symplectic Fourier transform of F is c_P^2. However F(Q)=2^N Tr(rho Q rho Q): it again needs a normalized two-copy overlap. Simulating this correlated two-copy boundary is not automatically the original positive product-boundary scalar operation.

## Normalized outcome queries and rational product probes

For a fixed axis choice s_i in {X,Y,Z},

    f_s(x)=Tr[rho product_i(I+x_i sigma_(s_i))]
          =2^N p(x | s).

Its Boolean Fourier coefficients are exactly those c_P whose nonidentity axes match s. Parseval gives ||f_s||_2<=C_2. Clipping the nonnegative function to M changes each Fourier coefficient by at most C_2^2/M. Thus bounded-function membership-query algorithms can be invoked after paying clipping, normalized-query accuracy and axis coverage. Additive error zeta in f requires additive error 2^-N zeta in the physical outcome probability. Ordinary output samples are not that membership oracle.

The proposed rational tetrahedral probes are

    rho_(a,b) = [I+(a X+b Y+ab Z)/2]/2,  a,b in {-1,+1}.

Their Bloch length is sqrt(3)/2<1. For their N-site product and any O,

    f(a_1,b_1,...,a_N,b_N)=Tr[O tensor_i rho_(a_i,b_i)]
       =sum_P c_P 2^-wt(P) chi_P(a,b).

The map I,X,Y,Z to 1,a,b,ab is a bijection onto the local two-bit Walsh characters. The Fourier transform is therefore exact, with no omitted Y sign or normalization. A Pauli coefficient of magnitude t and weight at most W becomes a Fourier coefficient of magnitude at least t 2^-W. Both this attenuation and the amplification of coefficient-estimation errors must be charged. Since W=O(L), they are polynomial factors in exp(L), but a fresh factor at every recursive level is not a uniform constant.

The fixed-action activity theorem can extend from product rank-one effects to these mixed positive product effects directly. On each block let A_v be the product of the normalized one-site factors 2 rho_i. It has normalized trace1 and operator norm at most2^a for a block of a sites. Its centered factor M_v=A_v-I has normalized trace norm at most2 and normalized Schatten-(1+1/a) norm at most3. These are the same source estimates used in the fixed-action proof. Product factorization, positivity of switched scalar marginals and the near-one isolated baselines are preserved. No spectral sampling or irrational eigenbasis is required. This validates the boundary class, not the recursive runtime.

## A precise generic statistical-query barrier

Take an unknown subset S of size W and

    rho_S = 2^-N (I+a Z_S),  0<a<=1.

It is a valid state with only two Pauli coefficients. With a=exp(-theta W), its weighted2 norm is sqrt2 and its coefficient-p norm is at most2. Its computational-basis law is

    q_S(x)=2^-N[1+a chi_S(x)].

For any bounded query g:{-1,+1}^N to [-1,1], the difference between its expectation under q_S and under uniform is a ghat(S). Parseval gives sum_S ghat(S)^2<=1. A tolerance-delta query can therefore distinguish the uniform response from at most (a/delta)^2 candidate supports.

Answer an adaptive algorithm's queries by the uniform expectations. After Q queries, at most Q(a/delta)^2 supports have been excluded. If the algorithm outputs K candidate supports, any remaining support outside that list is still consistent with all answers. Thus a uniform guarantee requires

    Q(a/delta)^2 + K >= binom(N,W).

For N=L^2,W=L and delta/a=exp[-O(L)], polynomial Q,K in exp(L) do not suffice, because binom(N,W)=exp[Theta(L log L)]. Approximation error below a/2 requires identifying the hidden coefficient. This is an adversarial-tolerance statistical-query statement for a broad promised-state class. It is not a lower bound against arbitrary sample-processing algorithms, and the states have not been realized here as the required local product-input evolution. It cannot be used to claim B is hard. It does falsify a black-box inference from the norm promises to an ordinary bounded-query constructor.

## False shortcut in explicit sparse time recursion

Even the H=0 product model exposes an invalid recursion assumption. Starting from O_0=product_i(I+Z_i), at time t,

    O_t=product_i(I+exp(-gamma t)Z_i),
    sum c_P(t)^2=[1+exp(-2gamma t)]^N.

Every coefficient has magnitude at most1. Therefore an explicit sparse list with absolute coefficient2 error eta needs at least [1+exp(-2gamma t)]^N-eta^2 entries.

At gamma t=(1/2)log N, the final energy is bounded. After two backward halvings, gamma(t/4)=(1/8)log N, the energy is exp[Omega(N^(3/4))]. For N=L^2 this exceeds every exp(O(L)) list size. Thus a recursive algorithm cannot assume sparse lists at every earlier time. The product model remains easy in a factored representation; this is only a counterexample to that particular sparse-intermediate invariant.

## Independent finite checks

check_oracles.py checks all85 prefixes of a random positive three-qubit state against the two-copy identity, all64 symplectic Fourier coefficients of the conjugation overlap, and216 fixed-axis Fourier coefficients. Maximum discrepancies are2.23e-16,1.12e-16 and1.12e-16 respectively. It also checks observable unitarity,20 Parseval query bounds and a bounded-error six-site energy-tree search that retains all40 heavy coefficients.

These floating checks support the algebra and catch normalization/sign mistakes. They do not certify a physical oracle, a recurrence complexity bound or a sampler.

## Sources and scope

- Ciancaglini, Cifuentes, Bellomo, Figueira and Bendersky, Measuring the largest coefficients of a quantum state, https://arxiv.org/html/2605.00341v1 . Direct prefix-tree/Bell/SWAP prior; equations12 and17 expose the scaling.
- Bshouty and Feldman, On Using Extended Statistical Queries to Avoid Membership Queries, JMLR2(2002), https://www.jmlr.org/papers/v2/bshouty02a.html . Its discussion distinguishes membership queries from specified product-distribution statistical queries. Those stronger distribution-control assumptions are not ordinary samples from the target state.
- The preceding representation audit is in ../b_pauli_activity_evaluator_20261108/independent_audit/REPORT.md . It remains a representation result until query implementation is paid.

No uniform polynomial all-time sampler or novelty claim follows from this report. The completed recursion review and its strictly weaker bound are recorded next.

## Review of the paid logarithmic-time recursion

The later construction in ../b_pauli_discovery_20261108 supplies a terminating implementation of the normalized membership oracle. Its supported bound is weaker than polynomial. This section supersedes the earlier ongoing-review status. The final all-outcomes guards listed below were confirmed in the reviewed files. It relies on the previously independently checked, repaired two-body fixed-action activity theorem; it does not import the discarded source word-language identity.

### Warmtime and norms

For a qualifying scalar call let L=1+ceil(log(100n/(delta beta))). The log-relative mixing shortcut returns zero when6n exp(-tau)<=delta/2. Non-shortcut calls therefore have tau=O(L), and their activity patches have N<=K_rho tau L.

Choose a fixed integer s_base that qualifies at every larger action. The written continuous upper envelope for the b=8 scalar condition has derivative less than1 beyond4, so doubling until the envelope lies below s_base gives an executable certificate. Define

    sigma(tau)=s_base+2ceil(log_2(tau+2)).

A second certified constant tau_base ensures sigma<=tau/3 above it. All qualifying actions below tau_base use the existing dense fixed-action evaluator; its exponent is a fixed constant depending on rho. This does not cover unqualifying early times.

Evolve each positive normalized product boundary to action sigma. Physical hypercontractivity from p0=1+exp(-sigma) to q0=1+exp(sigma) gives

    ||O_sigma||infinity <= 2^[2N/(1+exp(sigma))].

The coefficient regularity estimate is applied with its original total half-evolution parameter replaced by2sigma:

    a=exp[-(2sigma-4theta)/(1+4u)],
    C_p=exp[(log2+3u)N a],
    C_theta=exp[(log2)N a].

The shift and the factor2 are correct. Since1+4u<=3 and sigma grows at least as2log(tau+2), all three log norm budgets are O_rho(L). No exact-real or bounded-norm-independent-of-n assumption is required.

The exact scalar is the pairing of A_sigma with R_sigma propagated for the remaining action tau-2sigma. For warm-list errors at most eta and subsequent propagation error at most eta, the total pairing error is at most3 C_p eta+2eta^2, before separately allocated arithmetic. Thus eta<=delta_G/[10(C_p+1)] leaves adequate slack.

### Discovery and supplied-list propagation

The robust Fourier tree in DISCOVERY_LEMMA.md pays attenuation2^-W, bounded-value sampling, signed leaf estimation, rounding and adaptive confidence. Membership values are not physical output samples. It searches the2N-bit Walsh tree and estimates each prefix energy from two function values with a shared suffix. This identity is exact.

Recovered coefficients must be clipped to[-1,1] before common-dyadic rounding. Every true coefficient has that bound because O/d is a density matrix. Clipping preserves the good-event error and supplies an unconditional input-norm bound C_in<=S_0 for the at-most-S_0 returned coefficients, including bad randomized runs. Without this guard, the earlier claim that true C_p controlled every returned list was unjustified. The revised construction pays C_in explicitly.

SPARSE_PROPAGATION.md then uses local coefficient-p/2-contractive maps, an ordinary first-order product formula and coefficient deletion. With Q=sum_j||L_j||_(2->2), M>=8t^2 Q^2 C/eta sweeps pay the Trotter error without an exp(Qt) norm penalty. The maps have1-by1 or2-by2 Pauli blocks, so one update at most doubles an explicit list. A threshold satisfying

    (2C)^(p/2) cutoff^(1-p/2)<=eta/(8R)

pays each of R deletions. Finite map approximations can amplify earlier errors by at most2; the revised total deletion allocation is eta/4, leaving total error below eta. Map-entry precision and common dyadic denominators make bit lengths polynomial in R, the input precision and log(1/eta). This is a finite-bit implementation of known sparse propagation after a supplied warmstart, not an average-state expectation conversion.

### Recursive query cost

Each tetrahedral membership value of a sigma-evolved boundary is another positive product-input/product-effect scalar problem at action sigma, with Hamiltonian sign changed when required. The actual input stays product; no correlated-state product restart is introduced. Deleted interactions stay deleted. A finite connected patch can be padded to a square-lattice rectangle of O(N^2) sites with decoupled maximally mixed/effect-I ancillas, which multiply the scalar by one and leave operator/Pauli norms unchanged. The child retiles this problem and only builds its own O_rho(sigma L') activity patches. It does not dense-simulate the entire padded rectangle.

The membership accuracy, total number of queries, confidence union bound, norm budgets and pairing precision all cost exp(O_rho(L)). Consequently the child log budget obeys L'<=A_rho L for a fixed A_rho>1. Child action is strictly smaller above tau_base. The number of levels is O_rho(1+log* tau). Multiplying the branching costs gives

    poly(paid input bits/actions)
      times exp[L exp(O_rho(1+log* tau))].

The input-bit polynomial does not multiply into a fresh exponent at every level: physical coefficients are inherited, query probes have constant-bit entries, and the branching bound depends on L. The per-node arithmetic remains polynomial in inherited bit length and the current expanded precision budget.

For output sampling, logarithmic marginal calls and per-call failure budgets add the usual polynomial factors. At qualifying pre-mixing times tau=O(log(n/epsilon)), the bound is

    exp[O(log(n/epsilon)) exp(O_rho(1+log* log(n/epsilon)))],

times paid input factors. This is an explicit randomized finite-bit upper bound once the described deterministic caps are enforced. It improves the earlier dense exp(O_rho(log^2(n/epsilon))) upper bound asymptotically. It is not a uniform polynomial: A_rho raised to an unbounded recursion depth cannot be called a constant. No practical speed result or priority claim has been established.

### All-outcomes guards and confidence

The reviewed construction includes fixed tree/query/sample caps, clipping of membership values and leaf coefficients, and finite fallback answers on failed positivity/size/log checks. Baseline logs require a lower-bound check such as z>=1/4; true values are at least1/2. A failed child must not force unbounded norm-dependent propagation. Before exponentiation, compare its returned log against log B and a log-accuracy floor, returning B or0 outside the relevant interval; this prevents an erroneous huge log from creating unbounded intermediate work. These guards preserve the proof on the joint good event and only charge failed events to the total beta budget.

Certification here means a probabilistic algorithmic guarantee from analytic norm bounds, validated query error and a confidence union bound. It is not a cheaply independently checkable certificate for an arbitrary supplied list, and no complete implementation of the enormous recursive algorithm has been benchmarked.

### Additional independent checks

check_product_queries.py verifies64 tetrahedral query values and their exact Fourier attenuation on a random positive three-qubit operator, with maximum error9.8e-17. All127 binary prefix-energy identities agree to4.5e-16. Centered product-block source norms satisfy the stated trace/p bounds through7 sites, even though their infinity norms grow above1. It also checks the warmtime norm envelopes at27 parameter combinations. These are floating diagnostics, not a substitute for the preceding proof or a large-instance runtime test.

Final scientific scope: the structured constructor has a paid, slower-than-polynomial recursive implementation in the qualifying-time regime. The requested physical polynomial query cost, uniform all-time polynomial sampling, and the early-time regime remain unproved.

## Reviewed source snapshot

- DISCOVERY_LEMMA.md SHA256: 5750e08f89060fc1a7380c1a9eb3e8c9e1fa6be5b1922ffb797576fa84e30bce
- SPARSE_PROPAGATION.md SHA256: 62b2731d155635f18795fd6c0c49ffa995e7ff920b2f154aa25055865a8345bf
- RECURSION.md SHA256: 9b42d29ade45f1d7c1c97fc04cbae3d89815608ab156ee03efdc65672ed98ab4

Review outcome: no remaining mathematical or finite-bit blocker was found for the displayed slower-than-polynomial, qualifying-time recursive upper bound, under the previously audited two-body activity theorem. The full recursive implementation has not been executed. This review does not clear any polynomial or all-time claim.
