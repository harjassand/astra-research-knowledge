# Paid propagation after a constructed warmstart

> Release-copy note: this historical proof/review snapshot has presentation-only edits recorded in SOURCE_PROVENANCE.json. Mathematical content is unchanged. Current status and superseded steps are identified in START_HERE.md and DEPENDENCY_MAP.md at the package root.

8 November 2026. This is an explicit conservative implementation of the established coefficient-p-contractive sparse-Pauli mechanism, not a new structural simulation claim. It is included to make the recursion's use of a supplied warmstart auditable. The input is an explicit sparse coefficient list, not a promised small list.

Use the local Pauli generator/noise allocation from ../b_pauli_activity_evaluator_20261108/REGULARITY_LEMMA.md. Fix p<2 at the local contractivity threshold. Write L=sum_(j=1)^D L_j, D=O(N), with each local term containing its assigned depolarization and all remaining noise as additional diagonal terms. Every exp(tL_j) contracts both coefficient-p and coefficient2. One local Pauli Hamiltonian couples a global Pauli string to at most one other string; its allocated damping is diagonal. Hence each local update creates at most twice as many listed strings, through independent matrices of size at most2. Duplicate strings are merged.

Let input p-norm<=C, target2-error eta<=1 and evolution duration t. Set Q=sum_j||L_j||_(2->2)=O(N(J+gamma)); all numerical action is paid. The product of local contractions has one-sweep error bounded by dt^2 Q^2, from the commutator Duhamel identity and contraction of all exponential factors. After M sweeps the error is at most t^2 Q^2 C/M. Choose M>=8t^2 Q^2 C/eta, and also M>=1. This pays the ordinary first-order Trotter error without an exp(Qt) factor. There are R=DM local updates.

Use a coefficient cutoff sigma such that

    (2C)^(p/2) sigma^(1-p/2) <= eta/(8R).

Each exact local update contracts p; coordinate deletion also contracts p. For finite-bit maps, approximate every entry of the constant-size local exponential to delta<=min(1/(8R),eta/(32RC)). Its p- and2-operator error is at most2delta. Thus repeated approximate maps increase the p budget by at most exp(2Rdelta)<=2, and their summed2-error is at most4Rdelta C<=eta/8. All retained/intermediate lists have p norm<=2C. Deleting below sigma costs at most eta/(8R) per update. Later approximate maps amplify any earlier error by at most exp(2Rdelta)<=2, so the total propagated deletion error is at most eta/4 (not eta/8). At most

    S<=(2C/sigma)^p

coefficients remain. Before the next pruning at most2S coefficients are present. The real sign convention and local identity/commuting sectors do not change this bound. Input rounding and final rounding can each be given another eta/8, leaving slack below eta.

Computing the2-by2 exponential to delta is a constant-dimensional certified elementary-function calculation with work polynomial in the local action and log(1/delta), using rational Taylor scaling if desired. Use a common dyadic denominator for all initial coefficients and a common dyadic denominator for all local entries at the selected precision. Store coefficients as exact rationals with those common denominators and merge exactly, or use a separately charged rounding budget. Under common-denominator storage, denominator bit lengths grow additively across R updates and hence polynomially in R and the input/entry precision; numerators have the same polynomial bound from the p-norm budget. Comparisons to a rational cutoff are exact. Pauli words use O(N) bits, and dictionary updates cost polynomial in S and N.

Consequently the full bit work is polynomial in N, dimensionless action gamma t, C, 1/eta, input bits and the original local coefficients, with an exponent depending on fixed dJ/gamma through p. This is intentionally conservative and not a production algorithm. It does not initialize an extensive product operator's exponentially many coefficients. The new proposed initialization is DISCOVERY_LEMMA.md with its membership queries paid recursively.
