#!/usr/bin/env python3
"""Run bundled diagnostics in a temporary copy, without altering release evidence."""
from pathlib import Path
import argparse, hashlib, json, os, platform, shutil, subprocess, sys, tempfile, time
ROOT=Path(__file__).resolve().parent
SMOKE=[
'b_static_patch_mpo_20261108/check_candidate.py',
'b_static_patch_mpo_20261108/independent_audit/check_exact_gauge.py',
'b_static_patch_mpo_20261108/independent_audit/check_warm_probe_closure.py',
'b_static_patch_mpo_20261108/combined_audit/check_combined.py',
'b_static_patch_mpo_20261108/prototype_mpo_dp.py',
'b_global_activities_20261108/check_spatial_contract.py',
'b_pauli_discovery_20261108/check_discovery.py',
]
def digest_tree():
 return {p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'proofs').rglob('*') if p.is_file()}
def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--suite',choices=['smoke','full'],default='smoke')
 parser.add_argument('--output',type=Path,help='Fresh directory outside the release for logs/results; default: a new temporary directory.')
 args=parser.parse_args()
 out=args.output.resolve() if args.output else Path(tempfile.mkdtemp(prefix='b-diagnostics-results-'))
 if out==ROOT or ROOT in out.parents:parser.error('--output must be outside the distributed release.')
 out.mkdir(parents=True,exist_ok=True)
 if any(out.iterdir()):parser.error('--output must be empty.')
 before=digest_tree();tests=SMOKE if args.suite=='smoke' else sorted(p.relative_to(ROOT/'proofs').as_posix() for p in (ROOT/'proofs').rglob('*.py'))
 import numpy,scipy,sympy,mpmath
 result={'suite':args.suite,'python':sys.version,'platform':platform.platform(),'versions':{x.__name__:x.__version__ for x in [numpy,scipy,sympy,mpmath]},'scope':'Independent finite checks and prototype primitives, not an end-to-end sampler or asymptotic proof. Script success includes its built-in assertions; numerical diagnostics remain numerical.','tests':[]}
 env=os.environ.copy();env.update({'PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTHONHASHSEED':'0'})
 start=time.perf_counter()
 with tempfile.TemporaryDirectory(prefix='b-diagnostics-work-') as tmp:
  work=Path(tmp)/'proofs';shutil.copytree(ROOT/'proofs',work)
  for i,name in enumerate(tests,1):
   print(f'[{i}/{len(tests)}] {name}',flush=True);t=time.perf_counter()
   p=subprocess.run([sys.executable,str(work/name)],cwd=(work/name).parent,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
   log=out/'logs'/Path(name).with_suffix('.log');log.parent.mkdir(parents=True,exist_ok=True);log.write_text(p.stdout)
   row={'script':name,'returncode':p.returncode,'seconds':time.perf_counter()-t,'log':log.relative_to(out).as_posix()};result['tests'].append(row)
   print(f"  returncode={p.returncode}, seconds={row['seconds']:.3f}",flush=True)
   if p.returncode:
    result['failure_output_tail']=p.stdout[-5000:];break
  generated=out/'generated_results'
  for f in work.rglob('*.json'):
   src=ROOT/'proofs'/f.relative_to(work)
   if not src.exists() or f.read_bytes()!=src.read_bytes():
    dst=generated/f.relative_to(work);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dst)
 result['seconds']=time.perf_counter()-start;result['distributed_proof_tree_unchanged']=(before==digest_tree())
 result['all_scripts_completed_successfully']=len(result['tests'])==len(tests) and all(x['returncode']==0 for x in result['tests'])
 (out/'run_summary.json').write_text(json.dumps(result,indent=2)+'\n')
 print(f'Results: {out}',flush=True)
 if not result['distributed_proof_tree_unchanged'] or not result['all_scripts_completed_successfully']:return 1
 return 0
if __name__=='__main__':raise SystemExit(main())
