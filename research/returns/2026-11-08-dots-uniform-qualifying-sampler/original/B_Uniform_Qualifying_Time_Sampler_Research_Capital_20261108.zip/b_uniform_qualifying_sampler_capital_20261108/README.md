# B: uniform polynomial full-output sampling in the qualifying late regime

Start with [START_HERE.md](START_HERE.md) for the exact model, cutoff, result, limitations and review identities.

This release closes the previous repeated-recursion complexity gap for static two-body square-lattice dynamics with uniform maximally mixed replacement noise, rational product input and fixed coupling/noise ratio. **Early/intermediate times remain open, the constants are enormous, and this is not a production sampler or a novelty claim.**

The archive includes complete project proof dependencies, two independent end-to-end reviews, correction and source-provenance records, a small exact-rational MPO prototype, and reproducible diagnostic programs. Run `python VERIFY_MANIFEST.py`, then consult [REPRODUCING.md](REPRODUCING.md).
