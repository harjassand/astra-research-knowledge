# Coupled Fourier lifting: exact interface and finite Riesz assessment

This continuation sought a genuinely coupled quadratic Fourier correction for the original quartic. No lift with the sharp global norm bound has been obtained. The calculations below are an exact algebraic reduction and a finite exclusion of one bounded multiplier ansatz; neither is a negative original-energy witness.

## 1. Output-rotation-invariant triad interface

Write the two columns of A as x,y. For a rank-one Fourier amplitude `a tensor p`, define two 2-by-4 matrices D(p),C(p) by

\[
L_i(A,a\otimes p)
=D(p)_{1i}(x\cdot a)+D(p)_{2i}(y\cdot a)
+C(p)_{1i}\det(x,a)+C(p)_{2i}\det(y,a).
\]

For the accepted four strains,

\[
D(p)=\begin{pmatrix}
-3kp_1&\ell kp_1&p_2&p_2\\
-3p_2&-\ell p_2&p_1&-p_1
\end{pmatrix},
\]

\[
C(p)=\begin{pmatrix}
p_2&(5k+1)p_2&kp_1&-kp_1\\
p_1&-(5k+1)p_1&p_2&p_2
\end{pmatrix}.
\]

The lambda derivative has the corresponding coefficient vectors

\[
d(p)=\frac{3\ell}{m}(kp_1,-p_2)^T,
\qquad c(p)=\frac{12k}{m}(p_2,-p_1)^T.
\]

For a resonant triad `p+q+s=0`, put `Delta=det(p,q)=det(q,s)=det(s,p)`. Its output amplitudes are u,v,w. A general rotation-invariant bilinear correction at the p leg has the form

\[
\theta_p(v,w)=\alpha_p(v\cdot w)+\beta_p\det(v,w),
\qquad\alpha_p,\beta_p\in\mathbb R^4.
\]

Here theta is the unweighted coefficient vector: if the strain-square weights are w_i, the actual Hilbert-space correction component is `theta_i/sqrt(w_i)`. There are analogous vectors at q and s, giving 24 scalar unknowns for the triad.

The four-vector identities

\[
\det(u,v)(x\cdot w)=\det(x,v)(u\cdot w)-\det(x,u)(v\cdot w),
\]

\[
\det(u,v)\det(x,w)=(x\cdot u)(v\cdot w)-(x\cdot v)(u\cdot w)
\]

reduce the correction identity to the following 12 scalar equations (each displayed equality is in R2):

\[
D(p)\alpha_p+C(s)\beta_s-C(q)\beta_q
=\Delta[c(s)-c(q)],
\]

\[
D(q)\alpha_q+C(p)\beta_p-C(s)\beta_s
=\Delta[c(p)-c(s)],
\]

\[
D(s)\alpha_s+C(q)\beta_q-C(p)\beta_p
=\Delta[c(q)-c(p)],
\]

\[
C(p)\alpha_p+D(q)\beta_q-D(s)\beta_s
=\Delta[d(q)-d(s)],
\]

\[
C(q)\alpha_q+D(s)\beta_s-D(p)\beta_p
=\Delta[d(s)-d(p)],
\]

\[
C(s)\alpha_s+D(p)\beta_p-D(q)\beta_q
=\Delta[d(p)-d(q)].
\]

Solving these equations separately for a triad is not enough: the resulting quadratic operator must have the sharp L4-to-L2 bound including all four-frequency interactions. The previously obtained output-frequency j-only lift is one exact solution with alpha=0, but it has the documented axis poles.

An attempted constant determinant-channel redistribution removes some poles but leaves others. A three-channel choice eliminating channel 4 can be solved by a 3-by-3 exact system, but the resulting coefficients acquire inverse powers of Delta near collinear triads. Neither choice provided a bounded sharp symbol.

## 2. A fixed bounded Riesz ansatz

A natural candidate using the supplied Beurling norm would take every correction component to be a linear combination of second-order Riesz transforms of the four quadratic invariants

\[
u=|G_{\cdot1}|^2,\quad v=|G_{\cdot2}|^2,
\quad w=G_{\cdot1}\cdot G_{\cdot2},\quad j=\det G.
\]

More precisely, for each component and invariant let the multiplier be

\[
\frac{a\xi_1^2+b\xi_1\xi_2+c\xi_2^2}{|\xi|^2}.
\]

There are 48 scalar coefficients at fixed k. This includes the identity multiplier and arbitrary linear combinations of the three second-order Riesz symbols. It is substantially broader than a multiplier acting on j alone, but does not include general input-frequency-dependent bilinear symbols.

At `k=1`, substitute this ansatz into the twelve triad equations above and multiply by
`|p|^2 |q|^2 |p+q|^2`. The result is a finite polynomial linear system in the 48 coefficients, with no frequency sampling.

The exact result is:

| Quantity | Value |
|---|---:|
| Unknown coefficients | 48 |
| Nonzero polynomial coefficient equations | 1392 |
| Coefficient matrix rank | 48 |
| Augmented matrix rank | 49 |

Thus the ansatz cannot even satisfy the correction identity at k=1, before its norm is considered.

The reproducible calculation is `riesz_lift_linear_system.py`; the exact receipt is `riesz_lift_linear_system.json`. It expands all coefficients in the four real source-frequency variables and computes an exact rational row reduction. No optimizer, floating sample, unbounded search, installation, or external resource was used.

The construction principal independently checked the six vector equations against the original r triad, including all cyclic signs, the lambda derivative vectors, the determinant cross coefficient with no extra factor two, and the script's u/v/w/j cross normalizations. In this convention theta is the full cross coefficient at the output frequency. The independent review checked the formulation and did not repeat the exact row reduction.

### Sparse exact inconsistency witness

A subsequent single exact elimination pass extracted an eight-row integer witness. Thus the exclusion no longer relies solely on reported ranks. All coefficient rows were multiplied by the common denominator 2. Let the monomial key be the exponent tuple in `(p1,p2,q1,q2)`; the component index is the row among the twelve scalar triad equations in the script.

| Original row | Component | Monomial key | Integer weight | Scaled right side |
|---|---:|---|---:|---:|
| 1 | 0 | (0,3,1,5) | -4 | 12 |
| 3 | 0 | (0,3,3,3) | 1 | 24 |
| 24 | 0 | (1,2,2,4) | 1 | -24 |
| 118 | 1 | (0,3,2,4) | -2 | -12 |
| 698 | 6 | (0,3,2,4) | -2 | -6 |
| 813 | 7 | (0,3,1,5) | 4 | 6 |
| 815 | 7 | (0,3,3,3) | -1 | 12 |
| 836 | 7 | (1,2,2,4) | -1 | -12 |

The weighted sum of all 48 coefficient columns is exactly zero, while the weighted right-hand side is exactly 12. The resulting contradiction is `0=12`.

The complete selected coefficient rows, row keys, integer weights, zero column pairings, and nonzero right-hand pairing are retained in `riesz_infeasibility_witness.json`. The standalone `verify_riesz_infeasibility_witness.py` replays only integer additions and multiplications and passed. The extractor is `extract_riesz_infeasibility_witness.py`.

The extraction used one exact row-elimination pass, examined 837 equations, and stored 45 pivots before the inconsistency appeared. Exact polynomial reconstruction took 7.267 seconds, elimination took 0.175 seconds, and the whole extraction took 7.444 seconds under a 180-second external cap. Maximum absolute bit lengths were 3 for weights, 6 for selected coefficients, 5 for selected right sides, and 4 for the nonzero pairing. There was no new optimization or frequency search. These costs are retained in `riesz_witness_receipt.json`.

## 3. What remains sharp and unresolved

The general triad system still permits many frequency-dependent choices. The finite exclusion above does not rule out a coupled bilinear multiplier depending on both input directions, nor a nonlinear compatible lift.

The balanced companion formulation remains

\[
z=\tfrac32g+w,\qquad K^*w=\tfrac32(r-b),
\]

\[
\|w\|_2^2+3\langle g,w\rangle
\le-9\ell\int K_{\rm comp}(G).
\]

No estimate in this continuation establishes that required negative cross term. The completed mixed weighted-minor estimate controls a norm and proves the small-Jacobian neighborhood, but it does not supply the sign or sharp coefficient here. No global original-density proof or compatible negative follows from these calculations.
