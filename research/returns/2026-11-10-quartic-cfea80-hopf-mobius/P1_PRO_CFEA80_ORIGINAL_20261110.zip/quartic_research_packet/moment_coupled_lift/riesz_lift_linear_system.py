"""Exact 48-coefficient second-order Riesz ansatz for the weighted-minor lift.

No frequency sampling: all coefficients of the cleared triad polynomial are imposed.
"""
import sympy as s
import json
from pathlib import Path

k=s.Rational(1)
ell,m=3*k-1,3*k+1
p1,p2,q1,q2=s.symbols('p1 p2 q1 q2')
xs=(p1,p2,q1,q2)
P=[s.Matrix([p1,p2]),s.Matrix([q1,q2]),s.Matrix([-p1-q1,-p2-q2])]
R=[p.dot(p) for p in P]
Delta=p1*q2-p2*q1
DD=lambda p:s.Matrix([[-3*k*p[0],ell*k*p[0],p[1],p[1]],[-3*p[1],-ell*p[1],p[0],-p[0]]])
CC=lambda p:s.Matrix([[p[1],(5*k+1)*p[1],k*p[0],-k*p[0]],[p[0],-(5*k+1)*p[0],p[1],p[1]]])
dd=lambda p:s.Matrix([3*ell*k*p[0]/m,-3*ell*p[1]/m])
cc=lambda p:s.Matrix([12*k*p[1]/m,-12*k*p[0]/m])
D,C=[DD(p) for p in P],[CC(p) for p in P]
dc,ccv=[dd(p) for p in P],[cc(p) for p in P]
den=s.prod(R)

def polynomial_vector(vec):
    out={}
    for row,ex in enumerate(vec):
        for mon,coef in s.Poly(s.expand(ex),*xs).terms():
            if coef: out[(row,mon)]=coef
    return out

target=[s.S.Zero]*12
for i in range(3):
    j,l=(i+1)%3,(i+2)%3
    for out in range(2):
        target[2*i+out]=Delta*(ccv[l][out]-ccv[j][out])*den
        target[6+2*i+out]=Delta*(dc[j][out]-dc[l][out])*den
rhs=polynomial_vector(target)

cols=[]; names=[]
for strain in range(4):
    for inv in range(4):
        for monomial in range(3):
            vec=[s.S.Zero]*12
            for i in range(3):
                j,l=(i+1)%3,(i+2)%3
                p,q,r=P[i],P[j],P[l]
                numerator=[p[0]**2,p[0]*p[1],p[1]**2][monomial]
                pair=[2*q[0]*r[0],2*q[1]*r[1],q[0]*r[1]+q[1]*r[0],Delta][inv]
                factor=numerator*pair*R[j]*R[l]
                for out in range(2):
                    if inv<3:
                        vec[2*i+out]+=D[i][out,strain]*factor
                        vec[6+2*i+out]+=C[i][out,strain]*factor
                    else:
                        vec[2*j+out]+=C[i][out,strain]*factor
                        vec[2*l+out]-=C[i][out,strain]*factor
                        vec[6+2*j+out]-=D[i][out,strain]*factor
                        vec[6+2*l+out]+=D[i][out,strain]*factor
            cols.append(polynomial_vector(vec))
            names.append((strain+1,('u','v','w','j')[inv],monomial))

keys=sorted(set(rhs).union(*(set(col) for col in cols)))
matrix=s.Matrix([[col.get(key,0) for col in cols] for key in keys])
target_col=s.Matrix([rhs.get(key,0) for key in keys])
reduced,pivots=matrix.row_join(target_col).rref()
compatible=len(cols) not in pivots
result={'k':str(k),'unknowns':len(cols),'polynomial_equations':len(keys),
        'coefficient_rank':len([p for p in pivots if p<len(cols)]),
        'augmented_rank':len(pivots),'has_solution':compatible,
        'ansatz':'Each strain component is a second-order Riesz multiplier of u,v,w,j.'}
if compatible:
    particular=[s.S.Zero]*len(cols)
    for row,pivot in enumerate(pivots):
        if pivot<len(cols): particular[pivot]=reduced[row,-1]
    assert matrix*s.Matrix(particular)==target_col
    result['particular']=[{'index':names[i],'coefficient':str(v)}
                          for i,v in enumerate(particular) if v]
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
