"""Pure-integer replay of the retained <=49-row Riesz inconsistency witness."""
import json, math
from pathlib import Path
p=Path(__file__).resolve().parent/'riesz_infeasibility_witness.json'
d=json.loads(p.read_text());rows=d['selected_rows']
assert len(rows)<=49
assert all(len(r['integer_coefficients'])==48 for r in rows)
pairings=[sum(r['integer_weight']*r['integer_coefficients'][i] for r in rows) for i in range(48)]
rhs=sum(r['integer_weight']*r['integer_rhs'] for r in rows)
assert pairings==[0]*48==d['column_pairings']
assert rhs==d['rhs_pairing'] and rhs!=0
g=0
for r in rows:g=math.gcd(g,abs(r['integer_weight']))
assert g==1
print(f'PASS: {len(rows)} integer-weighted rows annihilate all 48 columns and pair to {rhs} on the right-hand side.')
