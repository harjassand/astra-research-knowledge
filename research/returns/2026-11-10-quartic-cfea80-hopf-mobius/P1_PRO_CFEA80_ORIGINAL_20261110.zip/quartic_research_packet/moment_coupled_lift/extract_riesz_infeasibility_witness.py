"""One exact elimination pass extracting a <=49-row inconsistency witness.

No optimizer and no new frequency search. Rebuilds the exact polynomial rows
from the existing ansatz script, then tracks rational row combinations. The
caller enforces one external 180-second cap.
"""
import json, math, time
from fractions import Fraction
from pathlib import Path

started=time.perf_counter()
root=Path(__file__).resolve().parent
receipt={'task':'sparse rational Riesz-ansatz inconsistency witness',
         'external_time_cap_seconds':180,'optimization_calls':0,
         'elimination_passes':1,'verified':False}
def checkpoint():
    receipt['elapsed_seconds']=time.perf_counter()-started
    (root/'riesz_witness_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')

source=root/'riesz_lift_linear_system.py'
prefix,sep,_=source.read_text().partition('reduced,pivots=')
assert sep
namespace={'__file__':str(source),'__name__':'exact_row_reconstruction'}
exec(compile(prefix,str(source),'exec'),namespace)
A=namespace['matrix']; b=namespace['target_col']
keys=namespace['keys'];names=namespace['names']
assert A.cols==48 and A.rows==1392
scale=1
for value in list(A)+list(b):scale=math.lcm(scale,int(value.q))
integerA=[[int(scale*v) for v in row] for row in A.tolist()]
integerb=[int(scale*v) for v in b]
receipt['preprocessing_seconds']=time.perf_counter()-started
receipt['global_coefficient_multiplier']=scale
receipt['total_equations']=A.rows;receipt['unknowns']=A.cols
checkpoint()

elimination_started=time.perf_counter()
basis={}
witness=None
examined=0
for row_index,(original,rhs) in enumerate(zip(integerA,integerb)):
    if time.perf_counter()-started>165:
        receipt['outcome']='internal time guard before external cap';checkpoint()
        raise SystemExit(2)
    examined=row_index+1
    row=[Fraction(v) for v in original]+[Fraction(rhs)]
    combo={row_index:Fraction(1)}
    for pivot in sorted(basis):
        coefficient=row[pivot]
        if not coefficient:continue
        brow,bcombo=basis[pivot]
        for col in range(pivot,49):
            if brow[col]:row[col]-=coefficient*brow[col]
        for index,value in bcombo.items():
            combo[index]=combo.get(index,Fraction(0))-coefficient*value
            if not combo[index]:del combo[index]
    pivot=next((i for i in range(48) if row[i]),None)
    if pivot is None:
        if row[48]:
            witness=combo
            break
        continue
    divisor=row[pivot]
    row=[v/divisor for v in row]
    combo={i:v/divisor for i,v in combo.items()}
    basis[pivot]=(row,combo)

receipt['elimination_seconds']=time.perf_counter()-elimination_started
receipt['equations_examined']=examined
receipt['stored_pivots']=len(basis)
if witness is None:
    receipt['outcome']='no inconsistency extracted';checkpoint()
    print(json.dumps(receipt,indent=2));raise SystemExit(1)

den=1
for value in witness.values():den=math.lcm(den,value.denominator)
weights={i:int(value*den) for i,value in witness.items()}
gcd=0
for value in weights.values():gcd=math.gcd(gcd,abs(value))
weights={i:value//gcd for i,value in weights.items()}
pairings=[sum(weight*integerA[i][j] for i,weight in weights.items()) for j in range(48)]
rhs_pairing=sum(weight*integerb[i] for i,weight in weights.items())
assert all(v==0 for v in pairings) and rhs_pairing!=0 and len(weights)<=49
if rhs_pairing<0:
    weights={i:-v for i,v in weights.items()};rhs_pairing=-rhs_pairing

selected=[]
for i,weight in sorted(weights.items()):
    selected.append({'original_row_index':i,'row_key':keys[i],
                     'integer_weight':weight,'integer_coefficients':integerA[i],
                     'integer_rhs':integerb[i]})
proof={'k':'1','source_variables':['p1','p2','q1','q2'],
       'unknown_labels':names,'global_coefficient_multiplier':scale,
       'selected_rows':selected,'column_pairings':pairings,
       'rhs_pairing':rhs_pairing,'weight_gcd':1,
       'equation_convention':'rows are the exact cleared-triad equations A*x=b'}
(root/'riesz_infeasibility_witness.json').write_text(json.dumps(proof,indent=2)+'\n')
receipt.update({'verified':True,'outcome':'exact inconsistency witness extracted',
    'witness_rows':len(weights),'rhs_pairing':rhs_pairing,
    'max_weight_bit_length':max(abs(v).bit_length() for v in weights.values()),
    'max_selected_coefficient_bit_length':max(abs(v).bit_length() for i in weights for v in integerA[i]),
    'max_selected_rhs_bit_length':max(abs(integerb[i]).bit_length() for i in weights),
    'rhs_pairing_bit_length':abs(rhs_pairing).bit_length()})
checkpoint();print(json.dumps(receipt,indent=2),flush=True)
