# Signed pressure work and its nonexactness on compatible potentials

## Scope

This note supplies an exact finite-amplitude L2-growth example for the
pressure-corrected flow, a paid sign change for its natural distance's
curvature term, and a nonzero exterior derivative of the corresponding
work one-form. It does not exclude other endpoint functionals, integrating
factors, metrics, or special path estimates. It does not settle original
quasiconvexity.

## 1. The pressure metric and a stronger coercive distance

For F=A+Dphi and G=Dphi, put j_F=det F, j_G=det G, and

\[
L_Fv=\operatorname{cof}F:Dv,\qquad L_F^*p=-\operatorname{cof}F\nabla p.
\]

Let w=div T(F) and choose eta>0. The pressure construction is

\[
(L_FL_F^*+\eta\ell I)p=L_Fw+\eta\lambda,
\quad v=w-L_F^*p,\quad r=\lambda-\ell p.
\]

It gives the exact identities

\[
L_Fv=-\eta r,\quad DE_J[Dv]=-\ell\|v\|_2^2-\eta\|r\|_2^2,
\quad (\ell I+\eta^{-1}L_F^*L_F)v=\operatorname{div}DJ(F).
\tag{1}
\]

Consider the natural distance for the Jacobian embedding,

\[
\mathcal D=\frac\ell2\|\phi\|_2^2+
\frac1{2\eta}\|j_F-\det A\|_2^2.
\]

Since L_Fphi=cof A:G+2j_G while j_F-det A=cof A:G+j_G, pairing (1) with phi
gives

\[
\boxed{\mathcal D'=-\int DJ(F):G+\int rj_G.}
\tag{2}
\]

The second term is the curvature remainder of the nonlinear determinant
embedding. The first term has no supplied global sign either: its all-mean
nonnegativity would require b^T H-dagger b<=16c/9, stronger than the desired
quasiconvexity bound 2c.

## 2. A finite-amplitude compatible wave increases ordinary L2 distance

Set k=1, A=I, eta=2pi^2, xi=(1,2), a=(2,-5), and

\[
\phi_\varepsilon=\frac\varepsilon{2\pi}a\sin(2\pi\xi\cdot x).
\]

The identity cof(I+epsilon a tensor xi cos(theta))xi=xi holds exactly.
Consequently the pressure operator preserves this one-phase subspace and
has constant coefficients there. Its positive zero-order term makes the
full scalar pressure solution unique. On harmonic h the operator in (1) is

\[
R_h=2I+2h^2\xi\xi^T.
\]

Write DJ(I+t a tensor xi)xi=f0+f1t+f2t^2+f3t^3. Direct rational algebra gives

\[
a^TR_1^{-1}f_1=-1/3,\qquad a^TR_1^{-1}f_3=39875/12.
\]

Only harmonic one pairs with phi, yielding the full exact formula

\[
\frac d{dt}\frac12\|\phi_\varepsilon\|_2^2
=\frac{\varepsilon^2}{6}-\frac{39875}{32}\varepsilon^4.
\]

At epsilon=1/1000 this is 127043/768000000000>0. The Jacobian equals
1-8epsilon cos(theta), hence stays uniformly positive. Original J still
decreases by (1). This is not a negative quasiconvexity gap.

## 3. The new curvature term has both signs, with a paid remainder

Keep k=1, A=I, eta=2pi^2. Set

\[
\psi=\frac{\cos(2\pi x)+\cos(2\pi y)+\cos(2\pi(x+y))}{(2\pi)^2},
\quad \phi_\varepsilon=\varepsilon D\psi,\quad G_0=D^2\psi.
\]

Writing Cx=cos(2pi x), Cy=cos(2pi y), Cxy=cos(2pi(x+y)),

\[
G_0=\begin{pmatrix}-C_x-C_{xy}&-C_{xy}\\-C_{xy}&-C_y-C_{xy}\end{pmatrix},
\quad \det G_0=C_xC_y+C_xC_{xy}+C_yC_{xy}.
\]

Pointwise |G0|<=4 and |det G0|<=8. The pressure residual's exact first-order
term is

\[
r_1=-4C_x-C_y-\frac{20}{3}C_{xy},
\qquad\int r_1\det G_0=-\frac{35}{12}.
\tag{3}
\]

The remainder is controlled as follows. Write
lambda=3+epsilon lambda1+epsilon^2 lambda2 and
w=epsilon w1+epsilon^2 w2+epsilon^3 w3. Finite rational Laurent expansion
gives

\[
\|w_i\|_2\le2\pi A_i,\quad(A_1,A_2,A_3)=(6,35/2,85/4),
\quad (\|\lambda_1\|_2,\|\lambda_2\|_2)\le(C_1,C_2)=(12,39/4).
\]

For |epsilon|<=1/8 the pressure form is at least one quarter of
||q||0^2=||Dq||2^2+4pi^2||q||2^2. Let p0=3/2, let p1 solve its first-order
equation, put Bi=2pi Ai, and z=p-p0-epsilon p1. Subtraction of the first-order
equation gives

\[
\|p_1\|_0\le B_1+\pi C_1,
\]

\[
\|z\|_0\le4\varepsilon^2\left[
\tfrac32B_2+4B_1+\tfrac3{16}B_3+\pi C_2+10(B_1+\pi C_1)\right].
\]

Here the operator perturbation is bounded by 8|epsilon|+16epsilon^2, using
||cof G0||infinity<=4. Since r-epsilon r1=epsilon^2 lambda2-2z, one obtains

\[
\boxed{\|r(\varepsilon)-\varepsilon r_1\|_2
\le C_r\varepsilon^2,\qquad C_r=11541/8.}
\tag{4}
\]

The rational constant is exactly
5C2+40C1+12A2+112A1+(3/2)A3. Combining (3)--(4),

\[
\left|\int r(\varepsilon)\det(\varepsilon G_0)
+\frac{35}{12}\varepsilon^3\right|\le8C_r\varepsilon^4.
\]

Take N=7914 and epsilon=+/-1/N. Since 8Cr/N<35/24,

\[
\int r(1/N)\det(G_0/N)<-\frac{35}{24N^3},
\quad
\int r(-1/N)\det(-G_0/N)>\frac{35}{24N^3},
\]

with margin 35/(24N^3)=35/11895956830656.

No unspecified PDE solver is required. At these amplitudes the pressure is
constructible by the Fourier-Neumann series about -Delta+4pi^2, whose
operator perturbation norm is at most 8/N+16/N^2<1/900. Finite iterates have
finite rational Fourier data after cancelling common pi factors, and the
tail has a geometric bound. This certification uses only the computed
first-order coefficient and the paid remainder (4).

## 4. The time-work one-form itself is not exact

The residual in (2) equals -beta_phi(v)/eta, where

\[
\beta_\phi(v)=\int j_G\operatorname{cof}(A+G):Dv
=\frac12d\left(\int j_G^2\right)[v]+\alpha_\phi(v),
\quad \alpha_\phi(v)=\int j_G\operatorname{cof}A:Dv.
\]

Its exterior derivative on the space of compatible potentials is

\[
(d\beta)_\phi(v,w)=\int\left[
(\operatorname{cof}G:Dv)(\operatorname{cof}A:Dw)
-(\operatorname{cof}G:Dw)(\operatorname{cof}A:Dv)\right].
\tag{5}
\]

At A=I take

\[
\phi=(\sin(2\pi x)/(4\pi),0),
\quad v=(0,\sin(2\pi y)/(2\pi)),
\quad w=(\sin(2\pi(x+y))/(2\pi),0).
\]

The background is F=diag(1+Cx/2,1), uniformly invertible. The first term in
(5) is Cx Cy Cxy/2; the second is zero. Thus the curvature is exactly 1/8.
Consequently beta itself is not an exact differential on this compatible
neighborhood. Its integral cannot simply be identified with a free endpoint
correction.

This statement does not exclude a different state functional, an integrating
factor, a path-dependent correction, or a signed estimate along a specially
constructed evolution. Each would require its own argument.

## 5. Verification and status

`verify_pressure_curvature.py` checks the finite-amplitude distance formula,
the Laurent coefficients, the cubic average, the rational remainder constant,
N=7914 and its signed margin. Its recorded exact run passed in 2.317 seconds.
The computation uses no numerical sign, unbounded search, or PDE oracle.

No complete affirmative original quasiconvexity proof or compatible negative
original energy gap has been obtained here.
