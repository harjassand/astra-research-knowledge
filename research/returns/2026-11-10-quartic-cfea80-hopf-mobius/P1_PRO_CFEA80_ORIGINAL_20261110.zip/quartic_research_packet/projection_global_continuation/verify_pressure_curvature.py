"""Exact pressure-distance wave and bounded signed curvature remainder."""
import sympy as s
from time import perf_counter
start=perf_counter()
a,b,c,d,t,eps,z,w=s.symbols('a b c d t eps z w')
Fvars=[a,b,c,d]
u=a*a+c*c;v=b*b+d*d;j=a*d-b*c
J=(u-v+2*j)**2/8+u*v/2+j*j
lam=s.Rational(3,4)*(u-v)+3*j
DJ=s.Matrix(2,2,[s.diff(J,x) for x in Fvars])
T=(DJ-lam*s.Matrix([[d,-c],[-b,a]]))/2

# The full pressure metric restricts to constant coefficients on this wave.
xi=s.Matrix([1,2]);aa=s.Matrix([2,-5]);E=aa*xi.T
line=dict(zip(Fvars,list(s.eye(2)+t*E)))
flux=(DJ*xi).subs(line,simultaneous=True).applyfunc(s.expand)
f1=flux.applyfunc(lambda q:q.coeff(t,1))
f3=flux.applyfunc(lambda q:q.coeff(t,3))
R1=2*s.eye(2)+2*xi*xi.T
distance_derivative=s.factor(-eps**2*(aa.T*R1.inv()*f1)[0]/2
                            -3*eps**4*(aa.T*R1.inv()*f3)[0]/8)
assert s.expand(distance_derivative-(eps**2/6-s.Rational(39875,32)*eps**4))==0
finite=distance_derivative.subs(eps,s.Rational(1,1000))
assert finite>0
print('Exact ordinary-distance derivative at epsilon=1/1000:',finite)

# Scalar-Hessian triad G. All Fourier coefficients are rational Laurent data.
Cx=(z+1/z)/2;Cy=(w+1/w)/2;Cxy=(z*w+1/(z*w))/2
G=s.Matrix([[-Cx-Cxy,-Cxy],[-Cxy,-Cy-Cxy]])
sub=dict(zip(Fvars,list(s.eye(2)+eps*G)))
Te=T.subs(sub,simultaneous=True).applyfunc(s.expand)
le=s.expand(lam.subs(sub,simultaneous=True))
W=[]
for order in (1,2,3):
    Tj=Te.applyfunc(lambda q:s.expand(q).coeff(eps,order))
    W.append(s.Matrix([s.expand(z*s.diff(Tj[i,0],z)+w*s.diff(Tj[i,1],w)) for i in (0,1)]))

def coefficients(expression):
    poly=s.Poly(s.expand(expression*z**3*w**3),z,w)
    return {(i-3,j-3):q for (i,j),q in poly.terms() if q}

wc=[[coefficients(component) for component in vector] for vector in W]
lc=[coefficients(le.coeff(eps,order)) for order in (1,2)]
A=[sum(abs(q) for component in vector for q in component.values()) for vector in wc]
B=[sum(abs(q) for q in co.values()) for co in lc]
r1={}
for nu in set(lc[0])|set(wc[0][0])|set(wc[0][1]):
    nn=nu[0]**2+nu[1]**2
    r1[nu]=s.factor((nn*lc[0].get(nu,0)+2*sum(nu[i]*wc[0][i].get(nu,0) for i in (0,1)))/(nn+1))
r1expr=s.expand(sum(q*z**nu[0]*w**nu[1] for nu,q in r1.items()))
assert s.expand(r1expr+4*Cx+Cy+s.Rational(20,3)*Cxy)==0
detG=s.expand(G.det())
cubic=coefficients(s.expand(r1expr*detG)).get((0,0),0)
assert cubic==-s.Rational(35,12)

# Proven Hilbert-resolvent bound in pressure_curvature_details.md:
# ||r(eps)-eps*r1||_2 <= Cr*eps^2 for |eps|<=1/8.
Cr=s.factor(5*B[1]+40*B[0]+12*A[1]+112*A[0]+s.Rational(3,2)*A[2])
N=max(9,int(s.floor(192*Cr/35))+1)
assert s.Rational(8)*Cr/N<s.Rational(35,24)
print('Fourier l1 bounds A1,A2,A3 (w_j/(2*pi)):',A)
print('Fourier l1 bounds lambda1,lambda2:',B)
print('Exact cubic coefficient <r1 detG>:',cubic)
print('Paid remainder constant Cr:',Cr)
print('Choose epsilon=+/-1/N, N=',N)
print('Guaranteed signed curvature magnitude at least:',s.Rational(35,24*N**3))
print(f'PASS: exact finite verification completed in {perf_counter()-start:.3f} seconds.')
