# Nonlinear constitutive flows and a paid pressure correction

## Scope

These results retain the original J_k. They certify failures of proposed
dissipative flows and an exact pressure identity. They do not give a negative
quasiconvexity gap. The pressure identity supplies dissipation but does not
supply convergence to the affine mean. No full endpoint follows.

Write ell=3k-1, n=k+1, m=3k+1. The accepted constitutive identities are
DJ=ell T+lambda cof F and K=(J-lambda det F/2)/ell.

## 1. The exact finite-amplitude test

For a cubic flux S, set M_S(F,xi)a=DS(F)[a tensor xi]xi. At a constant
background F, a necessary condition for phi_t=div S(A+Dphi) to decrease J is
nonnegativity of a^T M_J M_S a for every output a and source xi.

An exact two-form cannot change this test: for a single-phase gradient the
two spatial derivatives of F are collinear, so its pullback vanishes
pointwise.

For integer xi and the smooth periodic potential

\[
\phi_\varepsilon(x)=\frac{\varepsilon}{2\pi}a\sin(2\pi\xi\cdot x),
\qquad E=a\otimes\xi,
\]

define the degree-at-most-four polynomial
P(t)=a^T M_J(I+tE,xi)M_S(I+tE,xi)a, with coefficients P_r. Exact averaging gives

\[
\frac{E_J'(0)}{(2\pi)^2}=-\varepsilon^2
\left(\frac{P_0}{2}+\frac{\varepsilon^2P_2}{8}
+\frac{\varepsilon^4P_4}{16}\right).
\tag{1}
\]

Thus an increasing instantaneous direction can be certified without an
existence theorem for the proposed evolution.

## 2. The uncorrected T-flow fails

At I and xi=(r,s),

\[
M_J=\begin{pmatrix}m^2r^2/2&mrs\\mrs&2s^2+\ell n r^2/2\end{pmatrix},
\quad
M_T=\begin{pmatrix}
\frac{m^2-2}{2m}r^2&\frac{m+1}{m}rs\\
-rs/m&nr^2/2+s^2/m
\end{pmatrix}.
\]

Therefore e1^T M_J M_T e1=m(m^2-2)r^4/4-r^2s^2. At k=1, xi=(1,4), a=e1,
this equals -2. With epsilon=1/1000, the complete expression (1) is

\[
\boxed{\frac{E_J'(0)}{(2\pi)^2}
=\frac{127952477248311}{128000000000000000000}>0.}
\]

The initial field is a one-direction rank-one perturbation, a class already
known to satisfy quasiconvexity. This is only a failure of the proposed flow.

## 3. The convex companion flow fails near the lower endpoint

At I and xi=(z,1), direct differentiation of the original polynomial gives

\[
M_K=\frac{M_T+M_T^T}{2}-\frac{3(kz^2-1)}{2m}I.
\]

The determinant of its symmetric energy product is

\[
\begin{aligned}
\det\operatorname{sym}(M_JM_K)=\frac{z^4n}{16}\big[&
(81k^5+27k^4+9k^3-3k^2-5k+1)z^4\\
&+(126k^3-12k-6)z^2+15\ell\big].
\end{aligned}
\]

Its critical-source alignment is exact, since the z^2 term vanishes. At
k=17/50 and xi=(1,1), however, the matrix is

\[
\begin{pmatrix}
1530251/500000&18501/5000\\
18501/5000&219295039/50500000
\end{pmatrix},
\]

with determinant -100330874111/250000000000. The rational output (7,-6)
gives acoustic value -228414797/50500000. At epsilon=1/1000 the exact full
nonlinear average yields

\[
\boxed{\frac{E_J'(0)}{(2\pi)^2}
=\frac{65616751398184165341243}
{29016896000000000000000000000}>0.}
\]

Thus K supplies a convex energy, but original J is not a Lyapunov functional
for its gradient flow throughout the stated parameter range.

## 4. Fixed-metric radial quartics cannot repair both critical sets

Consider S_D(F)=tr(FDF^T)FD with constant positive symmetric D. At I, xi=e2,
the acoustic kernel forces D12=0. Write D=diag(d1,d2), d1,d2>0. Then at I,
xi=(z,1),

\[
\det\operatorname{sym}(M_JM_{S_D})
=-d_2^2(md_2-2d_1)^2z^2+O(z^4).
\]

At B_k=[[0,k],[1,0]] and xi=(1,z), the corresponding expression is

\[
\det\operatorname{sym}(M_JM_{S_D})
=-k^2d_1^2(md_1-2k^2d_2)^2z^2+O(z^4).
\]

The necessary ratios d1/d2=m/2 and d1/d2=2k^2/m are incompatible for k>1/3.
In particular D=I gives the leading negative coefficient -(m-2)^2 at I,
and D=diag(k,1) gives -n^2. This does not exclude arbitrary nonlinear or
nonlocal compatible operators.

## 5. Pressure accounts for the variable-minor work, but not convergence

For smooth periodic F=A+Dphi define

\[
L_Fv=\operatorname{cof}F:Dv
=\operatorname{div}((\operatorname{cof}F)^Tv),
\qquad L_F^*p=-\operatorname{cof}F\nabla p.
\]

The divergence formula uses Piola. Put w=div T(F), and use the compatible
velocity v=w-L_F^*p. Integration by parts gives the exact identity

\[
DE_J(F)[Dv]=-\ell\|v\|_2^2+
\langle\lambda-\ell p,L_Fv\rangle.
\tag{2}
\]

Orthogonally projecting w onto ker L_F decreases J but preserves the whole
determinant field. It therefore cannot reach the affine mean when the
initial determinant fluctuates.

To allow determinant evolution, choose eta>0 and impose

\[
(L_FL_F^*+\eta\ell I)p=L_Fw+\eta\lambda.
\tag{3}
\]

With r=lambda-ell p one obtains

\[
L_Fv=-\eta r,
\qquad
\boxed{DE_J(F)[Dv]=-\ell\|v\|_2^2-\eta\|r\|_2^2.}
\tag{4}
\]

The positive pressure bilinear form is
<L_F^*p,L_F^*q>+eta ell<p,q>. At a fixed smooth F it can be treated in the
completion for this weighted norm; finite Galerkin versions are strictly
positive linear systems. No global time-dependent PDE construction or
convergence theorem is asserted here.

Eliminating pressure exposes the precise limitation:

\[
(\ell I+\eta^{-1}L_F^*L_F)v=\operatorname{div}DJ(F).
\tag{5}
\]

This is a preconditioned original-energy gradient direction. Its stationary
equation is div DJ(F)=0, rather than div T(F)=0.

Indeed, with G=Dphi,

\[
\frac d{dt}\frac12\|\phi\|_2^2
=-\int[T(F)-T(A)]:G
-\int p\,[\operatorname{cof}A:G+2\det G].
\tag{6}
\]

The first term has the accepted negative quartic bound from T monotonicity.
The second term has no supplied sign. Pressure normalization cannot change
it: adding a constant to p pairs with zero because both cof A:G and det G
integrate to zero. Consequently (4) does not supply the affine convergence
required for a quasiconvexity proof. Dropping the second term of (6) would
leave the variable-minor work unpaid.

## 6. Finite costs and status

`verify_nonlinear_flow_witnesses.py` evaluates the finite-amplitude wave
polynomials exactly over the rationals and checks the acoustic formulas by
direct differentiation of original J and K. The recorded run passed in
1.841 seconds. The increasing directions rely on no numerical sign or PDE
oracle.

One exploratory exact grid check at k=1 used V=J+3W/8=8K. All 624 nonzero
backgrounds in {-2,-1,0,1,2}^4 and eight source directions passed the
acoustic positivity test: 4,992 exact integer checks after clearing a
denominator of 2, taking 10.91 seconds. This is no positivity theorem beyond
that finite set, and no integrated entropy certificate. The moment role
owns the separate bounded finite certificate assessment at k=1; no positive
certificate is asserted here.

The construction role separately proved that some real s makes J+sW convex
if and only if k(3k+5)^2>=32. That classification rules out this generator
family below its threshold; it is not reproved here.

No compatible negative energy gap and no full affirmative endpoint have
been established by the results in this note.
