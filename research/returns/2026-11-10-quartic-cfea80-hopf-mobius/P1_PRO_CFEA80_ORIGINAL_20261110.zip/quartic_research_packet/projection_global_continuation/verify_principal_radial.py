"""Exact finite symbolic checks for principal_and_radial_calculations.md."""
from time import perf_counter
import sympy as s

start = perf_counter()
k, P, Q, R = s.symbols("k P Q R", real=True)
ell, n = 3*k-1, k+1
Cp = n*(3*k+5)/8
Cq = (3*k**3-13*k**2+45*k-3)/(8*n)
Cpq = n*(3*k-7)/4
Cr = ell*(k-1)/2
Cpr = ell*n/2
Cqr = ell*(k-3)/2
u, v, j = P+Q+2*R, P+Q-2*R, P-Q
original = ell*(k*u-v+2*j)**2/(8*n)+ell*u*v/4+j*j
complex_form = Cp*P**2+Cq*Q**2+Cpq*P*Q+Cr*R**2+Cpr*P*R+Cqr*Q*R
assert s.cancel(original-complex_form) == 0

# Use the numerator to avoid accidental non-Laurent rational coefficient
# extraction. The variable zeta represents exp(2 i theta).
a, b, x, y, z, t, zeta = s.symbols("a b x y z t zeta", real=True)
p = x+s.I*y+a/zeta**2
pc = x-s.I*y+a*zeta**2
q = z+s.I*t+b/zeta
qc = z-s.I*t+b*zeta
PP, QQ, RR = p*pc, q*qc, (p*qc+pc*q)/2
numerator = (
    n*n*(3*k+5)*PP**2
    +(3*k**3-13*k*k+45*k-3)*QQ**2
    +2*n*n*(3*k-7)*PP*QQ
    +4*n*ell*(k-1)*RR**2
    +4*n*n*ell*PP*RR
    +4*n*ell*(k-3)*QQ*RR
)
angular = s.expand(numerator).coeff(zeta, 0)/(8*n)
mean_vars = (x, y, z, t)
gap = s.expand(angular-angular.subs({a: 0, b: 0}))
zero_mean = dict.fromkeys(mean_vars, 0)
c = gap.subs(zero_mean)
expected_c = Cp*a**4+Cq*b**4+(3*k*k-4*k-3)*a*a*b*b/2
assert s.cancel(c-expected_c) == 0
bvec = [s.diff(gap, variable).subs(zero_mean) for variable in mean_vars]
expected_b = [ell*(k-1)*a*b*b/2, 0, ell*(k-3)*a*b*b/2, 0]
assert all(s.cancel(actual-expected) == 0 for actual, expected in zip(bvec, expected_b))

# Integrated a^2 and b^2 are the same q2. Setting both to 1 extracts H/q2.
H = s.hessian(gap, mean_vars)
H_balanced = H.applyfunc(lambda e: s.expand(e).subs({a*a: 1, b*b: 1}))
M = s.Matrix([[3*k*k+2*k+1, ell*(k-1)],
              [ell*(k-1), (3*k**3-7*k*k+19*k-3)/n]])
expected_H = 2*s.Matrix([
    [M[0,0], 0, M[0,1], 0],
    [0, M[0,0], 0, M[0,1]],
    [M[1,0], 0, M[1,1], 0],
    [0, M[1,0], 0, M[1,1]],
])
assert all(s.cancel(e) == 0 for e in H_balanced-expected_H)
D = 12*k**3+2*k*k+5*k-1
assert s.cancel(M.det()-4*D/n) == 0
vv = s.Matrix([k-1, k-3])
C = k*ell**2*(2*k*k-5*k+9)/(8*D)
assert s.cancel(ell**2*(vv.T*M.inv()*vv)[0]/16-C) == 0
reserve_numerator = 18*k**4+93*k**3-10*k*k+37*k-6
assert s.cancel(ell*(k+3)/4-C-ell*reserve_numerator/(8*D)) == 0
shift = s.symbols("shift", real=True)
assert s.expand(D.subs(k, shift+s.Rational(1,3))
                -(12*shift**3+14*shift**2+s.Rational(31,3)*shift+s.Rational(4,3))) == 0
assert s.expand(reserve_numerator.subs(k, shift+s.Rational(1,3))
                -(18*shift**4+117*shift**3+95*shift**2+64*shift+s.Rational(80,9))) == 0

# Disk, exterior and determinant-translation coefficients.
eps = s.symbols("eps", real=True)
disk = (3*k*k-4*k-3)*eps**2+s.Rational(16,3)*Cq*eps**4
exterior = Cp*(8*eps**2+s.Rational(16,5)*eps**4)
full = 2*(3*k*k+2*k+1)*eps**2+16*(Cq/3+Cp/5)*eps**4
assert s.cancel(disk+exterior-full) == 0
assert s.cancel(disk+3*n*eps**2-k*ell*eps**2-s.Rational(16,3)*Cq*eps**4) == 0
assert disk.subs({k: 1, eps: s.Rational(1,4)}) == -s.Rational(5,24)

print("PASS: exact complex polynomial, angular moments, balanced Hessian,")
print("      affine minimization, positive coefficient shifts, and exterior cost.")
print(f"Finite symbolic verification elapsed: {perf_counter()-start:.3f} seconds.")
