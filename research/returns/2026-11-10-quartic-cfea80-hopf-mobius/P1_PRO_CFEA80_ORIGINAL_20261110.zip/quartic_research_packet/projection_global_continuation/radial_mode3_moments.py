import sympy as s
k,a,b,x,y,z,w,t=s.symbols('k a b x y z w t', real=True)
ell,n=3*k-1,k+1
p=x+s.I*y+a/t**2;pc=x-s.I*y+a*t**2
q=z+s.I*w+b/t;qc=z-s.I*w+b*t
P=p*pc;Q=q*qc;r=(p*qc+pc*q)/2
Jnum=n*n*(3*k+5)*P*P+(3*k**3-13*k*k+45*k-3)*Q*Q+2*n*n*(3*k-7)*P*Q+4*n*ell*(k-1)*r*r+4*n*n*ell*P*r+4*n*ell*(k-3)*Q*r
ang=s.expand(Jnum).coeff(t,0)/(8*n)
A=[x,y,z,w]
J0=ang.subs({a:0,b:0})
gap=s.factor(ang-J0)
c=s.factor(gap.subs(dict.fromkeys(A,0)))
bv=[s.factor(s.diff(gap,u).subs(dict.fromkeys(A,0))) for u in A]
H=s.hessian(gap,A).applyfunc(s.factor)
print('c =',c,flush=True)
print('b =',bv,flush=True)
print('H =',H,flush=True)
open('projection_global_continuation/radial_mode3_moments.txt','w').write('c='+str(c)+'\nb='+str(bv)+'\nH='+str(H)+'\n')
