# Principal-map and radial calculations for the original quartic

## Scope and conclusion

These calculations concern the original

\[
J_k(F)=\frac{\ell}{8n}(ku-v+2j)^2+\frac\ell4uv+j^2,
\qquad \ell=3k-1,\quad n=k+1,\quad k>\tfrac13.
\]

They do **not** settle its global quasiconvexity. They give an exact failed
principal-disk test whose exterior cost restores positivity, and an exact
positive result for every compact radial profile in the first angular class
with a cubic resonance. No compatible negative gap and no full-scope
translated principal-map theorem emerged.

The principal-map papers whose exact opens failed or whose publisher required
login/payment were not imported as premises. See `source_receipts.md`.

## 1. Complex-coordinate polynomial

Write a planar map as a complex function, and put

\[
p=f_z,\quad q=f_{\bar z},\quad P=|p|^2,\quad Q=|q|^2,
\quad R=\operatorname{Re}(p\bar q).
\]

Then \(u=P+Q+2R\), \(v=P+Q-2R\), and \(j=P-Q\). Direct expansion gives

\[
J=C_pP^2+C_qQ^2+C_{pq}PQ+C_RR^2+C_{pR}PR+C_{qR}QR,
\]

where

\[
\begin{aligned}
C_p&=\frac{(k+1)(3k+5)}8,\\
C_q&=\frac{3k^3-13k^2+45k-3}{8(k+1)},\\
C_{pq}&=\frac{(k+1)(3k-7)}4,\\
C_R&=\frac{(3k-1)(k-1)}2,\\
C_{pR}&=\frac{(3k-1)(k+1)}2,\\
C_{qR}&=\frac{(3k-1)(k-3)}2.
\end{aligned}
\]

In particular \(J(I)=C_p\), and
\(C_{pq}+C_R/2=(3k^2-4k-3)/2\).

## 2. An explicit disk map and its full exterior cost

For \(0<\varepsilon<1/2\), define

\[
f_\varepsilon(z)=
\begin{cases}
z+\varepsilon\bar z^2,& |z|\le1,\\
z+\varepsilon z^{-2},& |z|\ge1.
\end{cases}
\]

The two formulas agree on the circle. The interior perturbation has Lipschitz
constant at most \(2\varepsilon<1\), so the interior is injective and
orientation preserving. The exterior is injective because, for \(|z|,|w|\ge1\),

\[
f(z)-f(w)=(z-w)
\left[1-\varepsilon\frac{z+w}{z^2w^2}\right],
\qquad
\left|\varepsilon\frac{z+w}{z^2w^2}\right|\le2\varepsilon<1.
\]

Its derivative is nonzero there; matching the Jordan boundary and the
normalization at infinity gives a global orientation-preserving
homeomorphism. This verification does not use a principal-map theorem.

Inside the unit disk, \(p=1\) and \(q=2\varepsilon\bar z\). The mean derivative
is \(I\), but the mean determinant is \(1-2\varepsilon^2\). Angular averaging
and exact radial integration give

\[
\frac1\pi\int_{|z|<1}[J(Df_\varepsilon)-J(I)]
= (3k^2-4k-3)\varepsilon^2+\frac{16}{3}C_q\varepsilon^4.
\tag{2.1}
\]

For \(k=1\) and \(\varepsilon=1/4\), this equals \(-5/24\). Thus the uncorrected
disk statement \(\fint_DJ(Df)\ge J(\fint_DDf)\) fails even for this explicitly
verified homeomorphism. The boundary is not affine, and its determinant
deficit prevents (2.1) from being a quasiconvexity counterexample.

Outside, the map is holomorphic, with
\(p=1-2\varepsilon z^{-3}\), \(q=0\). Therefore

\[
\frac1\pi\int_{|z|>1}[J(Df_\varepsilon)-J(I)]
=C_p\left(8\varepsilon^2+\frac{16}{5}\varepsilon^4\right).
\tag{2.2}
\]

Adding (2.1) and (2.2) yields the strictly positive full-space gap

\[
\frac1\pi\int_{\mathbb R^2}[J(Df_\varepsilon)-J(I)]
=2(3k^2+2k+1)\varepsilon^2
+16\left(\frac{C_q}{3}+\frac{C_p}{5}\right)\varepsilon^4>0.
\tag{2.3}
\]

Both \(C_p,C_q\) are positive for \(k>1/3\): they are the values of the positive
original quartic at nonzero conformal and anti-conformal matrices,
respectively. At \(k=1\), the exterior contribution is exactly
\(16\varepsilon^2+(32/5)\varepsilon^4\).

The perturbation decays as \(r^{-2}\) and its derivative as \(r^{-3}\).
Multiplying it by a smooth radial cutoff at radius \(R\), then smoothing the
circle interface, changes the full-space energy gap by a quantity tending to
zero. This follows directly from the polynomial estimate

\[
|J(A+E)-J(A+E')|
\le C_k\bigl(|A|+|E|+|E'|\bigr)^3|E-E'|
\]

and the explicit integrable exterior decay; ordinary compact smoothing uses
strong \(W^{1,4}\) convergence. Thus the exterior cost has been accounted for
in the compact-support formulation as well.

### Determinant translation on this example

The constitutive coefficient at \(I\) is \(\lambda(I)=3n/2\). For
\(J-\lambda(I)\det\), the disk gap is

\[
k\ell\varepsilon^2+\frac{16}{3}C_q\varepsilon^4>0.
\tag{2.4}
\]

This verifies that particular translated inequality on the displayed family.
It supplies neither the translated inequality for all principal maps nor the
operation needed to extend such a theorem to arbitrary vector gradients.

## 3. Two inexpensive exclusions for radial extension searches

For a compact perturbation \(\phi=h(r)\bar z^2\), its two Wirtinger derivatives
have angular frequencies \(-3\) and \(-1\). Every cubic monomial has an odd
angular frequency, hence \(\int DJ(D\phi)=0\). The exact affine-mean expansion
and the accepted \(H\succeq0\) then prove the all-mean inequality for the entire
class, at every admissible \(k\). No search over radial tails in this class can
produce a negative gap.

There is also a general rank-one-convex argument for maps of the form
\(f(x)=M(r)x\), where \(M(r)\) is a differentiable matrix profile equal to
\(A\) outside a compact interval. With \(e=x/r\),

\[
Df=M+rM'e\otimes e.
\]

Rank-one convexity gives

\[
\fint_{S^1}J(Df)\ge J(M)+\frac r2\frac d{dr}J(M),
\]

because \(\fint e\otimes e=I/2\). Multiplication by \(2r\) and integration
telescopes \((r^2J(M))'\), proving the compact all-mean inequality. This rules
out those radial matrix profiles for any differentiable rank-one-convex
density, not just this family.

## 4. The first cubic angular class is positive for all radial profiles

Let

\[
\phi(z)=h(r)\bar z^3
\]

be a smooth compactly supported perturbation, with real radial \(h\), smooth
at the origin as a radial function. Write

\[
a(r)=\frac{r^3h'(r)}2,\qquad
b(r)=3r^2h(r)+a(r).
\]

Then

\[
\phi_z=a(r)e^{-4i\theta},\qquad
\phi_{\bar z}=b(r)e^{-2i\theta}.
\]

Unlike the preceding angular class, this class has a cubic resonance. Define

\[
q_2=\int_0^\infty a^2r\,dr=\int_0^\infty b^2r\,dr,
\quad T_3=\int_0^\infty ab^2r\,dr,
\quad U_4=\int_0^\infty a^2b^2r\,dr.
\]

The equality defining \(q_2\) is the integrated determinant identity. More
explicitly, with \(w=r^2h\), one has
\(a=rw'/2-w\), \(b=rw'/2+2w\), and

\[
(a^2-b^2)r=-\frac32(r^2w^2)'.
\]

For an affine mean, let \(p_0=x+iy\), \(q_0=z+it\), and set
\(X=(x,z)^T\), \(Y=(y,t)^T\), \(v=(k-1,k-3)^T\). Exact angular integration gives

\[
\frac{\Delta(A,D\phi)}{2\pi}
=C_4+\frac\ell2T_3v^TX+q_2(X^TMX+Y^TMY),
\tag{4.1}
\]

where

\[
M=\begin{pmatrix}
3k^2+2k+1&\ell(k-1)\\
\ell(k-1)&\dfrac{3k^3-7k^2+19k-3}{k+1}
\end{pmatrix}
\]

and

\[
C_4=\int_0^\infty
\left[C_pa^4+C_qb^4+\frac{3k^2-4k-3}{2}a^2b^2\right]r\,dr.
\]

Put \(D_k=12k^3+2k^2+5k-1\). Then

\[
\det M=\frac{4D_k}{k+1}>0,
\qquad
D_{s+1/3}=12s^3+14s^2+\frac{31}3s+\frac43>0.
\]

Hence \(M\) is positive definite. For a nonzero profile, \(q_2>0\), and exact
minimization of (4.1) over all affine means gives

\[
\inf_A\frac{\Delta(A,D\phi)}{2\pi}
=C_4-C_k\frac{T_3^2}{q_2},
\qquad
C_k=\frac{k\ell^2(2k^2-5k+9)}{8D_k}.
\tag{4.2}
\]

Cauchy--Schwarz gives \(T_3^2/q_2\le U_4\). The original nonnegative-square
formula gives a particularly simple quartic reserve:

\[
\begin{aligned}
\fint_{S^1}J(D\phi)
={}&\frac\ell{8n}\left[(na^2+(k-3)b^2)^2+2n^2a^2b^2\right]\\
&+\frac\ell4(a^4+b^4)+(a^2-b^2)^2\\
\ge{}&\frac{\ell(k+3)}4a^2b^2.
\end{aligned}
\]

Consequently

\[
\inf_A\frac{\Delta(A,D\phi)}{2\pi}
\ge\left[\frac{\ell(k+3)}4-C_k\right]U_4\ge0.
\tag{4.3}
\]

The bracket is strictly positive for every admissible \(k\), since

\[
\frac{\ell(k+3)}4-C_k
=\frac{\ell(18k^4+93k^3-10k^2+37k-6)}{8D_k},
\]

and, after \(k=s+1/3\), its numerator polynomial inside the factor \(\ell\)
is

\[
18s^4+117s^3+95s^2+64s+\frac{80}9.
\]

Thus every radial profile in this angular class satisfies the full
all-affine-mean inequality for every \(k>1/3\). The argument permits arbitrary
profile amplitude, radial concentration, and radial frequency. It does not
cover mixtures of angular modes or arbitrary compatible vector gradients.

## 5. Verification and remaining endpoint

`verify_principal_radial.py` verifies the complex-coordinate polynomial,
the exact angular moments, the mean-minimization coefficient, and the
positive shifted-polynomial identities using finite rational symbolic
algebra. The proof above uses no numerical minimizer, PDE oracle, limiting
search assumption, or unquantified numerical error.

The full remaining task is still a sharp global compatible-gradient estimate
or a rigorously negative compatible witness. The displayed calculations
provide neither. In particular, the raw disk obstruction cannot be promoted
to a compact counterexample after omitting its positive exterior energy.
