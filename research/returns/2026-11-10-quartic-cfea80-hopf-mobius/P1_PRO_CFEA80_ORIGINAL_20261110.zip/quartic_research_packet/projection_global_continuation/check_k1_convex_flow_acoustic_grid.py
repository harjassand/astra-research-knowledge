"""Finite exact generator check; a pass does not certify global positivity."""
import sympy as s
from itertools import product
from time import perf_counter
start=perf_counter()
a,b,c,d,r,t=s.symbols('a b c d r t')
F=[a,b,c,d]
u=a*a+c*c;v=b*b+d*d;j=a*d-b*c
J=(u-v+2*j)**2/8+u*v/2+j*j
W=(u+v-2*j)*(u+v+2*j)
V=J+s.Rational(3,8)*W
B=s.Matrix([[r,0],[t,0],[0,r],[0,t]])
MJ=B.T*s.hessian(J,F)*B;MV=B.T*s.hessian(V,F)*B
Q=s.simplify((MJ*MV+MV*MJ)/2)
entries=[s.Poly(s.expand(Q[i,j]),a,b,c,d,r,t) for i,j in [(0,0),(0,1),(1,1)]]
scale=s.ilcm(*[x.q for p in entries for x in p.coeffs()])
fs=[s.lambdify((a,b,c,d,r,t),s.expand(p.as_expr()*scale),'math') for p in entries]
directions=[(1,0),(0,1),(1,1),(1,2),(2,1),(1,-1),(1,-2),(2,-1)]
count=0
for background in product(range(-2,3),repeat=4):
    if background==(0,0,0,0):
        continue
    for xi in directions:
        q11,q12,q22=[f(*background,*xi) for f in fs]
        assert all(isinstance(v,int) for v in (q11,q12,q22))
        assert q11>=0 and q22>=0 and q11*q22-q12*q12>=0
        count+=1
assert count==4992
print('PASS for specified finite grid only:',count,'checks, denominator',scale)
print('elapsed',perf_counter()-start,'seconds')
