# Primary-source receipts for the global projection continuation

All earlier holds remain in force. No protected person was contacted, no held
source was retried or recovered by an alternative route, and no dependency was
installed.

Successful exact opens:

1. Voss et al., *Numerical Approaches for Investigating Quasiconvexity in the
   Context of Morrey's Conjecture*, exact publisher HTML:
   https://link.springer.com/article/10.1007/s00332-022-09820-x
   Web ref: turn15view0. This discusses numerical methods and narrower
   isotropic examples. It supplies no theorem settling the present anisotropic
   quartic.

2. Bandeira and Pedregal, *Finding new families of rank-one convex polynomials*,
   EMS primary publication PDF:
   https://ems.press/content/serial-article-files/16987
   Web ref: turn19view0. Its main criteria determine rank-one convexity; they
   do not establish the required compatible global inequality.

3. Bandeira and Pedregal, *Quasiconvexity: the quadratic case revisited, and some
   consequences for fourth-degree polynomials*, author-hosted preprint:
   https://matematicas.uclm.es/omeva/wp-content/preprints/preprint10-08.pdf
   Web ref: turn20view0. The quartic analysis produces a coupled Fourier
   extremality system; it does not provide a terminating sharp certificate for
   J_k or eliminate the present affine-mean moment inequality.

New hold:

4. First open of https://arxiv.org/html/2112.10563 returned DisabledError
   (turn22view0). No retry, mirror, alternate version, PDF route, or other
   recovery was attempted. Its governing contents were not imported.

General search results mentioning previously held sources were not used to
recover those sources.

Further principal-map source receipts:

5. First exact open of https://arxiv.org/html/2309.03495 returned
   `DisabledError` (turn29view0). No retry, mirror, alternate version, PDF,
   published counterpart, or other recovery was attempted. Its governing
   definitions and theorems remain unread.

6. The exact publisher abstract page for *Lower semicontinuity, Stoilow
   factorization and principal maps*,
   https://www.aimsciences.org/article/doi/10.3934/cpaa.2024069?viewType=HTML,
   opened successfully (turn31view0). It provided the abstract and references,
   not the governing proofs. Its offered Full Text link was followed once:
   https://www.aimsciences.org/article/noLoginPage?id=66d1685ee7a25d6c964ed794&journalPublisherId=cpaa&type=HTML
   (turn32view0). The publisher explicitly required login/payment, displaying
   a $39 price. The full text is now held. No author-repository, arXiv, or other
   alternate copy was used. No theorem from its unavailable full text is a
   premise of the calculations in this directory.

7. The previously successful exact Agazzi et al. HTML remained available at
   https://arxiv.org/html/2609.28311v2 (turn28view0). Its supplied Burkholder
   quasiconvexity theorem and scalar projection machinery were treated at
   their actual stated scope. They did not provide a proved translated
   principal-map inequality for the original anisotropic J_k.

A later general web-search call was aborted before dispatch. It produced no
new source receipt or imported mathematical result.
