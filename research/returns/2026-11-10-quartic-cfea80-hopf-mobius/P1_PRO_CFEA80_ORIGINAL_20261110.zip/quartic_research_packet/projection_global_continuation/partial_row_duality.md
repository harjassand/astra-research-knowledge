# Partial row duality for the original quartic

## Status

This is an exact global variational reformulation and a check of the proposed
partial-Legendre route. It does not prove global quasiconvexity and does not
produce a compatible negative. It uses the accepted rank-one convexity of the
original J_k, not a replacement density.

Write a matrix by its rows as F=(x;y), x,y in R^2, and let
R=[[0,-1],[1,0]]. Then det F=(R x).y and

    (cof F)_row1 = -R y,   (cof F)_row2 = R x.

## 1. The global scalar-row conjugate exists

For fixed x, the function y -> J_k(x;y) is convex: any difference in one row
has rank at most one. It is strictly convex and quartically coercive. More
quantitatively, the homogeneous quartic rank-one increment identity gives

    [D_yJ(x;y)-D_yJ(x;y')].(y-y')
       >= (2/3) J_k(0;y-y')
       >= (2 gamma/3)|y-y'|^4,

where gamma=ell min(1,k^2)/(8n)>0. Thus the gradient map onto R^2 has a unique
continuous inverse, with a 1/3-Holder estimate uniform in x.

Define the finite partial convex conjugate

    P(x,sigma)=sup_y {sigma.y-J_k(x;y)}.

The maximizer y=Y(x,sigma) is unique and satisfies D_yJ(x;Y)=sigma. Homogeneity
gives P(sx,s^3 sigma)=s^4 P(x,sigma) for s>0. The conjugate has degree 4/3 in
sigma when x=0; this anisotropic homogeneity is not ordinary homogeneous
quartic structure.

## 2. Exact fixed-first-row primal/dual problem

Fix an affine-periodic scalar f with Df=x0+Deta in L^4. For a prescribed second
row mean y0, the scalar minimization

    E(f)=min_zeta integral J_k(Df;y0+D zeta)

has a unique minimizing gradient, by convexity, coercivity, weak lower
semicontinuity in the second row, and the direct method. If y=y0+D zeta is
that gradient, sigma=D_yJ(Df;y) belongs to L^(4/3) and satisfies div sigma=0.
Fenchel equality therefore yields the exact dual representation

    E(f)=sup_{div sigma=0}
          { y0.integral sigma - integral P(Df,sigma) }.

The pairing is legitimate in L^4-L^(4/3). Every periodic divergence-free
sigma has the form sigma=sigma0+R Dh, with h in W^(1,4/3); the constant affine
part sigma0 is retained. The minimizing gradient itself supplies an attaining
dual field. No PDE oracle or numerical minimization is being assumed.

The original full question is precisely whether E(f)>=J_k(x0;y0) for every
admissible f. The dual representation alone does not establish this bound.

## 3. The natural mixed-potential density is a saddle density

Absorb sigma0 into the affine part of h and write sigma=R z, z=Dh. Define

    L(x,z)=J_k(x;Y(x,Rz))-Y(x,Rz).Rz = -P(x,Rz).

At points where D^2_yy J is invertible,

    L_x=D_xJ,    L_z=R y,
    L_zz=R (J_yy)^(-1) R.

The last matrix is negative definite because R^T=-R. In fact, at x=0,
L(0,z) is the negative of the strictly convex conjugate of the scalar
restriction g_k. Consequently L is not rank-one convex and cannot be used as
an ordinary quasiconvex lower-growth density. Changing one row alone already
detects the concavity. This does not exclude a saddle-point or compensated
duality argument.

For full stationary pairs, the equations and compatibility become

    div L_x=0,    div L_z=0,

since y=-R L_z and curl y=0 is equivalent to div L_z=0.

## 4. Constant versus variable determinant translations

For a constant tau, translating the density to J_k-tau det F changes the
second-row stress by -tau R x. In the dual scalar potential this is simply

    z -> z-tau x,    h -> h-tau f.

It preserves compatibility exactly.

For the supplied nonconstant constitutive multiplier lambda(F), the analogous
replacement lambda(F) Df has curl

    curl(lambda(F) Df)=Dlambda(F) wedge Df.

This is generally nonzero. Thus replacing tau by lambda(F) is not an allowed
scalar-potential substitution without a further Hodge correction and a bound
for its work.

The constitutive identity DJ=ell T+lambda cof F gives the exact row equations

    Dh = lambda(F) Df - ell R T_row2(F),
    Dg = -lambda(F) Dw - ell R T_row1(F)

whenever the relevant stresses are divergence-free. These equations retain
the variable pressure term. The monotonicity of T does not by itself identify
T with the gradient of the partial-Legendre density L in compatible variables.

## 5. What a full positive use of this route still requires

A successful dual proof would construct, for every Df=x0+Deta, a divergence-
free sigma=sigma0+R Dh such that

    y0.sigma0 - integral P(Df,sigma) >= J_k(x0;y0).

The accepted scalar projection work identity supplies no such inequality
automatically when the natural lambda-level constraint depends on the second
row. In particular, discarding curl(lambda Df), dropping the affine dual part,
or applying ordinary quasiconvexity to the saddle density L would not prove the
original statement.
