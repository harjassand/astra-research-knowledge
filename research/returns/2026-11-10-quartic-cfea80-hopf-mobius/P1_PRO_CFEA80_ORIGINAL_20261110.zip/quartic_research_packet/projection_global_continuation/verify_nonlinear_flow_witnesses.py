"""Exact flow-increase witnesses. These are not counterexamples to QC."""
from time import perf_counter
import sympy as s

started = perf_counter()
a,b,c,d,t = s.symbols('a b c d t', real=True)
flat = [a,b,c,d]
cof = s.Matrix([[d,-c],[-b,a]])

def matrices(k):
    ell,n,m = 3*k-1,k+1,3*k+1
    u,v,j = a*a+c*c,b*b+d*d,a*d-b*c
    J = ell*(k*u-v+2*j)**2/(8*n)+ell*u*v/4+j*j
    lam = (3*ell*(k*u-v)+24*k*j)/(2*m)
    K = (J-lam*j/2)/ell
    DJ = s.Matrix(2,2,[s.diff(J,z) for z in flat])
    DK = s.Matrix(2,2,[s.diff(K,z) for z in flat])
    T = (DJ-lam*cof)/ell
    return J,K,DJ,DK,T

def verify_wave(k, xi, output, generator_name, eps):
    J,K,DJ,DK,T = matrices(k)
    generator = {'T':T,'DK':DK}[generator_name]
    line = s.eye(2)+t*output*xi.T
    subst = dict(zip(flat,list(line)))
    flux_j = (DJ*xi).subs(subst, simultaneous=True)
    flux_s = (generator*xi).subs(subst, simultaneous=True)
    P = s.Poly(s.expand((flux_j.diff(t).T*flux_s.diff(t))[0]),t)
    assert P.degree() <= 4
    weighted = s.factor(P.nth(0)/2+eps**2*P.nth(2)/8+eps**4*P.nth(4)/16)
    assert weighted < 0
    print(f'{generator_name}: k={k}, xi={list(xi)}, output={list(output)}, eps={eps}')
    print('  acoustic value at I =',P.nth(0))
    print('  exact <sin^2(theta) P(eps cos(theta))> =',weighted)
    print('  energy derivative / (2*pi)^2 =',s.factor(-eps**2*weighted),'> 0')
    return P

P_T = verify_wave(s.Integer(1),s.Matrix([1,4]),s.Matrix([1,0]),'T',s.Rational(1,1000))
assert P_T.nth(0) == -2
P_K = verify_wave(s.Rational(17,50),s.Matrix([1,1]),s.Matrix([7,-6]),'DK',s.Rational(1,1000))
assert P_K.nth(0) == -s.Rational(228414797,50500000)

k,z = s.symbols('k z',real=True)
J,K,DJ,DK,T = matrices(k)
xi = s.Matrix([z,1])
B = s.Matrix([[z,0],[1,0],[0,z],[0,1]])
at_I = {a:1,b:0,c:0,d:1}
MJ_direct = (B.T*s.hessian(J,flat)*B).subs(at_I)
MK_direct = (B.T*s.hessian(K,flat)*B).subs(at_I)
ell,n,m = 3*k-1,k+1,3*k+1
MJ = s.Matrix([[m*m*z*z/2,m*z],[m*z,2+ell*n*z*z/2]])
MT = s.Matrix([[(m*m-2)*z*z/(2*m),(m+1)*z/m],[-z/m,n*z*z/2+1/m]])
MK = (MT+MT.T)/2-3*(k*z*z-1)*s.eye(2)/(2*m)
assert all(s.cancel(e)==0 for e in MJ_direct-MJ)
assert all(s.cancel(e)==0 for e in MK_direct-MK)
QK = (MJ*MK+MK*MJ)/2
expected_det = z**4*n/s.Integer(16)*(
    (81*k**5+27*k**4+9*k**3-3*k*k-5*k+1)*z**4
    +(126*k**3-12*k-6)*z*z+15*ell)
assert s.cancel(QK.det()-expected_det)==0

d1,d2 = s.symbols('d1 d2', positive=True)
metric = s.diag(d1,d2)
ms = (d1+d2)*(d1*z*z+d2)*s.eye(2)+2*(metric*xi)*(metric*xi).T
q = (MJ*ms+ms*MJ)/2
assert s.cancel(s.limit(q.det()/z**2,z,0)+d2*d2*(m*d2-2*d1)**2)==0
print(f'PASS: finite exact verification completed in {perf_counter()-started:.3f} seconds.')
