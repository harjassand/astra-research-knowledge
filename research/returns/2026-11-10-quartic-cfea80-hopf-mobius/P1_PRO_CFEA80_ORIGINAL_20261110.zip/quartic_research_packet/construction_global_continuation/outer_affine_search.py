"""Bounded deterministic generating-function search with all-A elimination.
Floating calculations generate candidates only; negative claims require exact rational verification.
"""
from generating_search import *
from outer_mean_support import moments,reduced_gap,serial

T=np.array([[1.,0.,-1.],[0.,1.,0.]])
t0=np.array([1.,0.,1.])
def sphere(R,l=None):
 M=np.zeros((3,3));M[:2,:2]=T@R@T.T;h=np.zeros(3);h[:2]=T@R@t0;c=float(t0@R@t0)
 if l is not None:M[:2,2]=M[2,:2]=2*T@l;h[2]=2*l@t0
 return M,h,c

def trsolve(M,h,c,steps=70):
 e,U=np.linalg.eigh(M);g=U.T@h;scale=max(1.,np.linalg.norm(M),np.linalg.norm(h));tol=1e-13*scale
 low=(e-e[0]<tol);v=np.zeros(3);other=~low;v[other]=-g[other]/(e[other]-e[0]);nv=float(v@v)
 if np.linalg.norm(g[low])<tol and nv<=1:
  v[np.flatnonzero(low)[0]]=np.sqrt(max(0.,1-nv))
 else:
  width=max(1.,np.linalg.norm(h),np.linalg.norm(M));lo=e[0]-width
  for j in range(32):
   if np.sum((g/(e-lo))**2)<1:break
   width*=2;lo=e[0]-width
  hi=np.nextafter(e[0],-np.inf)
  for j in range(steps):
   mid=(hi+lo)/2
   if np.sum((g/(e-mid))**2)>1:hi=mid
   else:lo=mid
  v=-g/(e-(hi+lo)/2);v/=np.linalg.norm(v)
 v=U@v
 return v,float(v@M@v+2*h@v+c)

def qvalue(co,v):M,h,c=co;return float(v@M@v+2*h@v+c)
def affine(v):
 x,y,d=v;a=np.sqrt(max(0.,1+x))
 if a>1e-8:return np.array([[a,y/a],[0.,d/a]])
 # Equivalent lower triangular factor avoids division by a nearly zero entry.
 b=np.sqrt(max(1e-20,1-x));return np.array([[d/b,0.],[y/b,b]])

class OuterProblem(Problem):
 def __init__(self,dirs,N):super().__init__(dirs,N);self.inner_calls=0;self.max_inner=0
 def objective_outer(self,zz,details=False):
  self.neval+=1;z=zz[:-1];k=float(zz[-1]);H,a,B,DB=self.fields(z);w=self.weights*a
  if min(a)<=0:return 1e6+1e6*np.sum(np.minimum(a,0)**2),np.r_[2e6*self.aB.T@np.minimum(a,0),0.]
  p=np.array([B[:,0]**2,2*B[:,0]*B[:,2],B[:,2]**2]).T
  q=np.array([B[:,1]**2,2*B[:,1]*B[:,3],B[:,3]**2]).T
  R=k*k*(p.T@(w[:,None]*p))+(p.T@(w[:,None]*q)+q.T@(w[:,None]*p))+q.T@(w[:,None]*q)
  R[0,0]-=k*k;R[0,2]-=1;R[2,0]-=1;R[2,2]-=1
  l=np.sum(w[:,None]*(k*p-q),axis=0)-np.array([k,0.,-1.]);pc=sphere(R,l)
  E=B-np.array([1.,0.,0.,1.]);ev=np.array([E[:,0]**2+E[:,1]**2,2*(E[:,0]*E[:,2]+E[:,1]*E[:,3]),E[:,2]**2+E[:,3]**2]).T
  RD=ev.T@(w[:,None]*ev);dc=sphere(RD)
  v,_=trsolve(*pc);self.inner_calls+=1
  dd=qvalue(dc,v)
  if dd<=1e-18:
   vv=[np.array([0.,0.,1.]),np.array([0.,0.,-1.]),np.array([1.,0.,0.]),np.array([-1.,0.,0.])]
   v=max(vv,key=lambda x:qvalue(dc,x));dd=qvalue(dc,v)
  if dd<=1e-24:return 1e5,np.zeros_like(zz)
  ratio=qvalue(pc,v)/dd
  used=0
  for it in range(12):
   M=pc[0]-ratio*dc[0];hh=pc[1]-ratio*dc[1];cc=pc[2]-ratio*dc[2]
   vv,resid=trsolve(M,hh,cc);self.inner_calls+=1;used+=1;den=qvalue(dc,vv)
   if den<=1e-20:break
   new=qvalue(pc,vv)/den
   v=vv
   if abs(new-ratio)<=1e-10*(1+abs(ratio)):
    ratio=new;break
   ratio=new
  self.max_inner=max(self.max_inner,used);A=affine(v);F=(A[None]@B.reshape(-1,2,2)).reshape(-1,4);AG=F-A.ravel()
  det=float(np.linalg.det(A));u=F[:,0]**2+F[:,2]**2;vv=F[:,1]**2+F[:,3]**2;uA=float(A[:,0]@A[:,0]);vA=float(A[:,1]@A[:,1])
  val=k*k*u*u+2*u*vv+vv*vv+4*det*(k*u-vv);base=k*k*uA*uA+2*uA*vA+vA*vA+4*det*(k*uA-vA)
  pgap=float(w@val-base);g2=np.sum(AG*AG,axis=1);denval=g2*g2;den=float(w@denval)
  if den<=1e-24:return 1e5,np.zeros_like(zz)
  pu=2*k*k*u+2*vv+4*det*k;pv=2*u+2*vv-4*det
  gradF=np.array([2*F[:,0]*pu,2*F[:,1]*pv,2*F[:,2]*pu,2*F[:,3]*pv]).T
  gradD=4*g2[:,None]*AG
  gradB=(A.T[None]@gradF.reshape(-1,2,2)).reshape(-1,4);gradDB=(A.T[None]@gradD.reshape(-1,2,2)).reshape(-1,4)
  de=a[:,None]*np.einsum('ij,ijk->ik',gradB,DB);de[:,1]+=val
  dden=a[:,None]*np.einsum('ij,ijk->ik',gradDB,DB);dden[:,1]+=denval
  gp=np.einsum('i,ij,ijp->p',self.weights,de,self.B);gd=np.einsum('i,ij,ijp->p',self.weights,dden,self.B)
  gk=float(w@(2*k*u*u+4*det*u)-(2*k*uA*uA+4*det*uA))
  obj=pgap/den;grad=np.r_[gp/den-pgap*gd/den**2,gk/den]
  if details:return dict(N=self.N,directions=self.directions,coefficients=z.tolist(),k=k,A=A.tolist(),ratio=obj,reduced_gap=pgap,denominator=den,amin=float(min(a)),cell_counts=self.counts,evaluations=self.neval,inner_calls=self.inner_calls,max_inner=self.max_inner)
  return obj,grad

def certify(row):
 d=dict(N=row['N'],directions=row['directions'],coefficients=[str(Q(round(x*2**20),2**20)) for x in row['coefficients']]);m=moments(d)
 A=[Q(round(x*2**20),2**20) for rr in row['A'] for x in rr]
 k=Q(1,3) if abs(row['k']-1/3)<1e-9 else Q(round(row['k']*2**20),2**20)
 gap=reduced_gap(m,k,A)
 if gap>=0:return None
 if k<=Q(1,3):
  eps=Q(1,2)
  for j in range(100):
   k=Q(1,3)+eps;gap=reduced_gap(m,k,A)
   if gap<0:break
   eps/=2
  else:return None
 d.update(k=str(k),A=[[str(A[0]),str(A[1])],[str(A[2]),str(A[3])]],reduced_gap=str(gap),original_gap=str((3*k-1)*gap/(8*(k+1))))
 return d

if __name__=='__main__':
 base=pathlib.Path(__file__).parent
 rows=[json.loads(x) for x in (base/'generating_search_results.jsonl').read_text().splitlines()]
 seeds=[rows[1],rows[2],rows[7],json.loads((base/'generating_refined_results.jsonl').read_text().splitlines()[-1])]
 with (base/'outer_affine_search_results.jsonl').open('w') as out:
  for ind,row in enumerate(seeds):
   st=time.perf_counter();p=OuterProblem(row['directions'],row['N']);z=np.r_[row['coefficients'],1/3 if ind%2==0 else .6]
   init=p.objective_outer(z,True)
   con=LinearConstraint(np.c_[p.aB,np.zeros(len(p.weights))],np.full(len(p.weights),-.95),np.full(len(p.weights),10.))
   opt=minimize(p.objective_outer,z,jac=True,method='SLSQP',constraints=[con],bounds=[(-2.,2.)]*p.P+[(1/3,1.)],options={'maxiter':200,'ftol':1e-10,'disp':False})
   r=p.objective_outer(opt.x,True);r.update(seed_index=ind,nit=int(opt.nit),success=bool(opt.success),message=str(opt.message),start_ratio=init['ratio'],seconds=time.perf_counter()-st);out.write(json.dumps(r)+'\n');out.flush()
   print(json.dumps({k:r[k] for k in ['seed_index','N','k','ratio','reduced_gap','amin','nit','success','evaluations','inner_calls','max_inner','seconds']}),flush=True)
   if r['reduced_gap']< -1e-8:
    exact=certify(r)
    if exact:
     (base/'outer_affine_negative_certificate.json').write_text(json.dumps(exact,indent=2)+'\n');print('EXACT_NEGATIVE',exact['original_gap'],flush=True);break
