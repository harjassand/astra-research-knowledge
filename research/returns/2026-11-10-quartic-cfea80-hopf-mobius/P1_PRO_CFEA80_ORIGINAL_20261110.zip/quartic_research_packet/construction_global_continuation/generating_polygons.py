"""Periodic C1 quadratic ridge generating functions; exact polygon geometry."""
from fractions import Fraction as Q
import sys, pathlib, json
sys.path.insert(0,str(pathlib.Path(__file__).parents[1]/'construction_continuation'))
from exact_shear_polygons import clip,area

def partition(directions,N):
 cells=[([(Q(0),Q(0)),(Q(1),Q(0)),(Q(1),Q(1)),(Q(0),Q(1))],())]
 counts=[]
 for v in directions:
  row=list(map(Q,v));out=[]
  for poly,bands in cells:
   vals=[sum(a*b for a,b in zip(row,p)) for p in poly]
   low=min(vals);hi=max(vals)
   first=(low*N).numerator//(low*N).denominator
   last=(hi*N).numerator//(hi*N).denominator
   for j in range(first,last+1):
    left=Q(j,N);right=Q(j+1,N)
    if right<=low or left>=hi:continue
    part=clip(clip(poly,row,left,True),row,right,False)
    if len(part)>=3 and area(part)>0:out.append((part,bands+(j%N,)))
  cells=out;counts.append(len(cells))
 assert sum(area(p) for p,b in cells)==1
 return cells,counts

def exact_verify(d):
 N=d['N'];directions=d['directions'];v=list(map(Q,d['coefficients']))
 assert len(v)==len(directions)*(N-1)
 values=[]
 for i in range(len(directions)):
  a=v[i*(N-1):(i+1)*(N-1)];values.append(a+[-sum(a)])
 cells,counts=partition(directions,N)
 total=Q(0);mean=[Q(0)]*4;detH=Q(0);hmean=[Q(0)]*3;coef=[Q(0)]*3;norm=Q(0);amin=None
 for poly,bands in cells:
  w=area(poly);b=h=c=Q(0)
  for (p,q),vs,bi in zip(directions,values,bands):
   b+=p*p*vs[bi];h+=p*q*vs[bi];c+=q*q*vs[bi]
  a=1+h
  if a<=0:raise ValueError('Generating function violates strict twist constraint.')
  amin=a if amin is None else min(a,amin)
  F=[1/a,-c/a,b/a,a-b*c/a];weight=w*a;total+=weight
  for i in range(4):mean[i]+=weight*F[i]
  detH+=w*(b*c-h*h)
  for i,x in enumerate([b,h,c]):hmean[i]+=w*x
  assert F[0]*F[3]-F[1]*F[2]==1
  u=F[0]**2+F[2]**2;vv=F[1]**2+F[3]**2
  coef[0]+=weight*u*u;coef[1]+=weight*4*u;coef[2]+=weight*(vv*vv+2*u*vv-4*vv)
  norm+=weight*sum((x-y)**2 for x,y in zip(F,[1,0,0,1]))**2
 assert total==1 and mean==[1,0,0,1] and detH==0 and hmean==[0,0,0]
 coef[0]-=1;coef[1]-=4;coef[2]+=1
 endpoint=coef[0]/9+coef[1]/3+coef[2]
 assert coef[0]>=0 and coef[1]>=0
 out=dict(cell_counts=counts,amin=str(amin),coefficient=list(map(str,coef)),endpoint=str(endpoint),endpoint_negative=endpoint<0,endpoint_float=float(endpoint))
 if endpoint<0:
  # Choose dyadic k-1/3 small enough, checking exact polynomial sign.
  e=Q(1,2)
  while coef[0]*(Q(1,3)+e)**2+coef[1]*(Q(1,3)+e)+coef[2]>=0:e/=2
  k=Q(1,3)+e;gap=(3*k-1)/(8*(k+1))*(coef[0]*k*k+coef[1]*k+coef[2])
  out.update(k=str(k),original_gap=str(gap),strict_negative=gap<0)
 return out

if __name__=='__main__':print(json.dumps(exact_verify(json.load(open(sys.argv[1]))),indent=2))
