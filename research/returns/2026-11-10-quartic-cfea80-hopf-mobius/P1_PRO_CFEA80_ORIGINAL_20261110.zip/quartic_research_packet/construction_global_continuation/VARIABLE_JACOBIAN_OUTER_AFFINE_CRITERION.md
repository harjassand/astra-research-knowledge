# Exact outer-affine criterion with a variable determinant

This extends `OUTER_AFFINE_CRITERION.md` from determinant-one fields to arbitrary compatible fields with mean I. It remains an equivalence/reduction, not a proof that the criterion holds for every field.

Let B=I+Dpsi be a real periodic L4 gradient field on the unit torus, and let h=det B. Then `integral h=1` and `integral B=I`. No pointwise sign or constancy of h is required. For every real constant A, the field AB=A+D(A psi) is compatible with affine mean A.

## 1. Exact quartic metric moments

Write

\[
C=A^TA=\begin{pmatrix}c_1&c_2\\c_2&c_3\end{pmatrix},
\quad z=(c_1,c_2,c_3)^T,\quad d=\det A.
\]

For the two columns of B define

\[
p=(B_{11}^2,2B_{11}B_{21},B_{21}^2)^T,
\qquad q=(B_{12}^2,2B_{12}B_{22},B_{22}^2)^T.
\]

Then `u(AB)=p dot z`, `v(AB)=q dot z`, and `j(AB)=d h`. Set e=(1,0,0)^T and f=(0,0,1)^T, and put

\[
U=\int pp^T-ee^T,\qquad V=\int qq^T-ff^T,
\]
\[
W=\frac12\int(pq^T+qp^T)-\frac12(ef^T+fe^T),
\]
\[
l_1=\int hp-e,\qquad l_2=\int hq-f,
\qquad \eta=\int h^2-1\ge0.
\tag{1}
\]

All moments are finite quartic moments of B. For fixed k set R_k=k^2U+2W+V and l_k=kl_1-l_2. Direct expansion of the ORIGINAL density yields

\[
8nJ_k(F)
=\ell\bigl[k^2u^2+2uv+v^2+4j(ku-v)\bigr]
 +4(5k+1)j^2.
\tag{2}
\]

Consequently

\[
\boxed{8n\left[\int J_k(AB)-J_k(A)\right]
=\ell\left[z^TR_kz+4d\,l_k^Tz\right]
 +4(5k+1)\eta d^2.}
\tag{3}
\]

The h weights in l_1,l_2 and the determinant-variance term are essential. Dropping the weights would incorrectly reuse the determinant-one formula. Equation (3) retains the original density exactly.

## 2. Exact minimization over all affine matrices

By quartic homogeneity normalize `tr C=2` for A!=0. Then

\[
C=\begin{pmatrix}1+x&y\\y&1-x\end{pmatrix},
\qquad x^2+y^2+d^2=1.
\]

Every point on this sphere arises from a real A, including both determinant signs and singular matrices. Put
`z0=(1,0,1)^T`, `t1=(1,0,-1)^T`, `t2=(0,1,0)^T`, and v=(x,y,d)^T. The right side of (3) is

\[
P_k(v)=v^TM_kv+2a_k^Tv+c_k,\qquad |v|=1,
\tag{4}
\]

where

\[
(M_k)_{ij}=\ell t_i^TR_kt_j\quad(i,j\le2),
\quad (M_k)_{i3}=(M_k)_{3i}=2\ell l_k^Tt_i,
\quad (M_k)_{33}=4(5k+1)\eta,
\]
\[
(a_k)_i=\ell t_i^TR_kz_0\quad(i\le2),
\quad (a_k)_3=2\ell l_k^Tz_0,
\quad c_k=\ell z_0^TR_kz_0.
\tag{5}
\]

For unnormalized A, multiply by `(tr(A^TA)/2)^2`; A=0 has zero gap.

The exact equality-constrained quadratic minimization theorem in `OUTER_AFFINE_CRITERION.md` applies without change:

\[
\boxed{P_k\ge0\text{ on }S^2
\iff\exists\tau\in\mathbb R:
\begin{pmatrix}M_k-\tau I_3&a_k\\a_k^T&c_k+\tau\end{pmatrix}\succeq0.}
\tag{6}
\]

For completeness, below the least eigenvalue solve the scalar secular equation
`|(M_k-tau I)^(-1)a_k|=1`; the minimizing point is the negative inverse image. If there is no solution, take tau equal to the least eigenvalue, use the pseudoinverse on its orthogonal complement, and fill the least eigenspace to unit norm. In both cases

\[
\min_{|v|=1}P_k(v)
=c_k+\tau-a_k^T(M_k-\tau I)^\dagger a_k,
\]

and the Schur-complement criterion gives (6). This includes the singular hard case and is necessary and sufficient, not an assumed sum-of-squares completeness principle.

For rational moments and rational k, strict negative signs have rational witnesses. Rational sphere points are dense; for a rational v=(x,y,d) with x!=-1 the rational matrix

\[
\widetilde A=\begin{pmatrix}1+x&y\\0&d\end{pmatrix}
\]

has Gram `(1+x)C` and determinant `(1+x)d`, so its gap is scaled by the positive factor `(1+x)^2`. Strict positivity has a rational tau with a positive-definite matrix in (6). These are finite rational certificates once the moments have been computed exactly, not a terminating universal decision algorithm.

Under normalization (3), the entries in (6) are polynomials of degree at most three in k. Exact cubic Bernstein control matrices may therefore certify a closed parameter interval for a fixed B and chosen rational tau. Dividing by ell reduces the determinant-one case to degree two; for variable determinant this would introduce a rational denominator in the final term.

## 3. Equivalence with the full original question

If original quasiconvexity holds, (6) holds for every mean-I compatible B. Conversely, suppose (6) holds for every such B. For any invertible A and periodic phi put

\[
B=I+D(A^{-1}\phi).
\]

Then AB=A+Dphi and the desired inequality follows. Singular A follow by taking invertible A_n converging to A with phi fixed: strong L4 convergence and quartic polynomial continuity pass the inequality to the limit. Thus the family of conditions (6), over every compatible mean-I B, is equivalent to the full question. Certifying selected B or a restricted class does not establish this universal condition.

No numerical computation, search, source retrieval, or oracle is used in this derivation. The determinant identity follows for smooth periodic psi by integration by parts and for W^(1,4) psi by strong gradient approximation and L2 convergence of determinants.
