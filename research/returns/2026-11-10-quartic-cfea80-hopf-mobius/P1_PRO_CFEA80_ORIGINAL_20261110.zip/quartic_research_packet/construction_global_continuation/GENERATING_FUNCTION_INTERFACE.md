# Exact compatible generating-function interface

This is a construction and verification interface for the original quartic. No negative original-energy witness and no full quasiconvexity proof were obtained. The numerical exploration described below is bounded and is not a universal positivity certificate.

## 1. A finite rational representation

Fix finitely many nonzero integer directions q and an integer N>=2. For every q choose rational values `v[q,0],...,v[q,N-1]` with sum zero. Define the one-periodic step function

\[
g_q(t)=v_{q,j}\quad\text{if }t\bmod1\in[j/N,(j+1)/N).
\]

There is a one-periodic C1 piecewise-quadratic function f_q with `f_q''=g_q`: integrate g_q once, subtract the mean of its primitive, integrate again, and choose an arbitrary additive constant. All coefficients and integration constants are rational. Put

\[
\psi(r,s)=\sum_q f_q(q_1r+q_2s).
\]

Its weak Hessian is

\[
D^2\psi=\sum_q g_q(q\cdot(r,s))\,q\otimes q.
\tag{1}
\]

The finitely many rational band lines partition the mixed-coordinate unit square into rational polygons. On each polygon the Hessian is a constant rational matrix. Write

\[
b=\psi_{rr},\qquad h=\psi_{rs},\qquad c=\psi_{ss},\qquad a=1+h.
\]

The strict twist condition a>0 is a finite collection of rational linear inequalities on the coefficients. It is checked on every polygon.

## 2. Actual compatible vector gradient

Define the two maps of mixed coordinates

\[
x=(r+\psi_s(r,s),s),\qquad y=(r,s+\psi_r(r,s)).
\]

For each fixed s, the first map has derivative a>0 in r and satisfies `x1(r+1,s)=x1(r,s)+1`. It is therefore globally invertible in r. Both maps commute with integer translations. Their composition `f(x)=y(r(x),s)` has `f(x)-x` periodic.

Since psi is C1 and piecewise quadratic, both mixed-coordinate maps are continuous piecewise affine. Their derivatives are

\[
D_{r,s}x=\begin{pmatrix}a&c\\0&1\end{pmatrix},
\qquad
D_{r,s}y=\begin{pmatrix}1&0\\b&a\end{pmatrix}.
\]

Thus the actual original-coordinate gradient is

\[
F=D_xf=\begin{pmatrix}1/a&-c/a\\b/a&a-bc/a\end{pmatrix},
\qquad \det F=1,
\qquad dx=a\,dr\,ds.
\tag{2}
\]

It is bounded and piecewise constant on the image polygons. Therefore `phi=f-x` is an admissible periodic W1,infinity potential. No incompatible matrix measure is substituted for a gradient.

For a mixed polygon of area w, its contribution to an original-coordinate integral is exactly `w a` times the value of the integrand at the rational matrix (2). The image of the mixed unit square need not literally be the original unit square; it is a fundamental domain of the same torus lift, which gives the same integral of every periodic integrand.

Compatibility also gives the exact checks

\[
\sum w(b,h,c)=(0,0,0),\qquad \sum w(bc-h^2)=0,
\]
\[
\sum wa=1,\qquad \sum waF=I.
\tag{3}
\]

The verifier checks all of these identities and determinant one on every cell using rational arithmetic.

## 3. Exact endpoint test and an admissible original parameter

For any field from (2), set `u=|F_col1|^2`, `v=|F_col2|^2`, and

\[
A_2=\int u^2-1,\quad A_1=4(\int u-1),\quad
A_0=\int(v^2+2uv-4v)+1.
\]

The original energy gap is exactly

\[
\int J_k(F)-J_k(I)=\frac{3k-1}{8(k+1)}
[A_2k^2+A_1k+A_0].
\tag{4}
\]

Because the mean of the first column is e1, `A2,A1>=0`. The polynomial in brackets is increasing for k>0. Its rational endpoint value is

\[
P_* = A_2/9+A_1/3+A_0.
\tag{5}
\]

A strictly negative P* would produce a full original counterexample: choose successive dyadic epsilons tending to zero, and check the rational polynomial at `k=1/3+epsilon` until it remains strictly negative. Continuity and P*<0 prove that this finite loop terminates. Every operation and resulting gap is rational. The potential constructed above is already admissible, so no smoothing or approximation error must be paid afterward.

Conversely, P*>=0 establishes the desired gap for this ONE field and all k>1/3. It says nothing about other coefficients, other means or all generating functions.

## 4. Implementation and bounded exploration

`generating_polygons.py` implements the rational polygon partition, Hessian assembly, strict twist checks, mean/determinant identities and exact polynomial (4). Polygon clipping uses rational halfplanes and the exact shoelace area formula. No quadrature is used by the verifier.

`generating_search.py` explores coefficient vectors using the actual compatible generating-function fields. Its floating objective is the endpoint reduced-energy gap divided by `integral R_{1/3}(F-I)`, with the full Jacobian factor a retained. The coefficients obey a finite box bound and the explicit linear constraints `0.05<=a<=11`. Analytic derivatives of (2) and the original quartic provide the objective gradient. The optimizer is a finite SLSQP calculation, not an oracle. Any floating negative would be rationalized and sent to the independent exact verifier before being claimed.

The seed construction projects prescribed three-state Hessian patterns into the finite ridge-Hessian coefficient space; targets are used only to choose coefficients. The functional is evaluated exclusively on the compatible fields (2).

Twelve initial runs used four directions with either four or eight bands, starting from deterministic projected profiles at two amplitude scales. Two further runs added four additional directions and then refined the band count. The final model used

\[
q\in\{(1,0),(0,1),(1,1),(1,-1),(1,2),(1,-2),(2,1),(2,-1)\},\quad N=8,
\]

with 56 independent coefficients and 2048 polygons. Across all 14 runs there were 738 reported optimization iterations and 939 logged objective evaluations, taking 2.60 seconds in this environment. Three tiny-amplitude initializations stopped unsuccessfully at their initial positive values; these are retained in the logs rather than described as optimized results.

Every returned floating endpoint gap was positive. The best normalized value was approximately 0.649228, far from a negative candidate. One nontrivial directional derivative check differed from the analytic derivative by about 3.7e-11. These floating signs carry no universal rigorous conclusion.

To check the exact interface on a nontrivial variable-a field, the final coefficient vector was rounded to denominator 256. The independent exact verifier processed its 2048 polygons in 1.02 seconds and found

\[
\min a=117/256>0,\qquad P_*\approx28.298983288>0,
\]

with an exact rational P* retained in `generating_positive_exact_result.json`. The mean and determinant checks (3) were exact. This particular rational field has positive original gap for every k>1/3 by (4), but no statement about all coefficients is inferred.

## 5. Remaining scope

The representation allows arbitrary finite sets of rational ridge directions and piecewise-constant second-derivative profiles. It provides actual compatible determinant-one maps and a finite exact certification path for any negative that might be found. Neither the bounded exploration nor the positive test field proves a general generating-function inequality. The original full global question remains unresolved.

## Subsequent all-affine extension

`OUTER_AFFINE_CRITERION.md` extends this interface to `F=A B` and proves a sharp necessary-and-sufficient four-by-four support criterion for every A. Exact all-A/all-k certificates are provided there for the rational field above and a second rational field obtained after a bounded outer-affine exploration. These later results use additional metric moments and are not consequences of the mean-I endpoint sign alone. The unrestricted generating-function family and the original full problem remain unresolved.
