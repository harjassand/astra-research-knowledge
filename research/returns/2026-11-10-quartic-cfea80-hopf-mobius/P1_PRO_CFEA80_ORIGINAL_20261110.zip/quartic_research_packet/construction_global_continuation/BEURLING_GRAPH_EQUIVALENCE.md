# Exact original-torus Beurling graph for the balanced Hopf form

This is an exact reformulation of the original quasiconvexity problem, including both directions of compatibility. It does not prove the resulting sharp integral inequality.

## 1. Wirtinger derivatives and the converse

Identify the real output plane with C. For a complex periodic W^(1,4) potential phi define

\[
p=\partial_z\phi=\tfrac12(\partial_1\phi-i\partial_2\phi),
\qquad q=\partial_{\bar z}\phi=\tfrac12(\partial_1\phi+i\partial_2\phi).
\]

Both have zero mean. On each nonzero original-torus frequency xi in Z^2,

\[
\widehat p(\xi)
=\frac{\xi_1-i\xi_2}{\xi_1+i\xi_2}\widehat q(\xi).
\tag{1}
\]

Let B be the multiplier in (1), with zero mode set to zero. Then p=Bq. It is the periodic Beurling multiplier in this convention.

The supplied planar L4 bound implies `||B||_(L4->L4)<=3` on the ORIGINAL torus. Here is a direct transfer. For a finite mean-zero trigonometric q, apply the plane operator to chi(x/R)q(x). At each of the finitely many nonzero frequencies, continuity of its symbol gives an o(1) L-infinity error and an o(R) L2 error from replacing the plane symbol by its value at that frequency. Interpolation gives an o(R^(1/2)) L4 error. Divide the plane bound by R^(1/2), pass to the limit using periodic averaging, and use density. The cutoff calculation is also written in `moment_global_continuation/mixed_weighted_minor_estimate.md`, Section 1.2. No changed lattice is identified with the unit torus.

Conversely, every mean-zero q in L4(T2;C) occurs as a bar-derivative. For finite trigonometric q set

\[
\widehat\phi(\xi)
=\frac{\widehat q(\xi)}{\pi i(\xi_1+i\xi_2)},
\quad \xi\ne0,\qquad\widehat\phi(0)=0.
\tag{2}
\]

Then `partial_1 phi=(B+I)q` and `partial_2 phi=i(B-I)q`. For general q use Fejer approximations q_N. The multiplier commutes with Fejer convolution, so q_N and Bq_N converge strongly in L4. Formula (2) and Poincare's inequality make the zero-mean potentials Cauchy in W^(1,4). Their limit has the required derivatives. Thus arbitrary mean-zero complex q gives a genuine compatible real vector gradient; no curl-preservation assumption about a pointwise constitutive inverse is involved.

## 2. Balanced variables and the original density

For a real matrix F represent its complex columns by p+q and i(p-q). Then

\[
u=|p+q|^2,\quad v=|p-q|^2,\quad j=|p|^2-|q|^2.
\]

Set n=k+1, ell=3k-1, and

\[
X=\frac{n p+(k-1)q}{2\sqrt{k}},\qquad Y=q.
\tag{3}
\]

This is invertible and real linear on the four matrix entries. Define

\[
H_1=|X|^2-|Y|^2,\quad H_2=2\operatorname{Re}(X\overline Y),
\quad H_3=2\operatorname{Im}(\overline X Y).
\]

The sign convention for H3 is immaterial because it only appears squared. The exact ORIGINAL-density identity is

\[
\frac{n^3}{2k^2(3k+5)}J_k(F)=\Phi_k(X,Y)=H^TM_kH,
\tag{4}
\]

\[
M_k=\begin{pmatrix}1&g_k&0\\g_k&\tau_k+\delta_k&0\\0&0&\tau_k\end{pmatrix},
\quad g_k=\frac2{\sqrt{k}(3k+5)},
\quad \delta_k=\frac{1-k}{k(3k+5)},
\quad \tau_k=\frac{n\ell}{2k(3k+5)}.
\tag{5}
\]

This is the s=0 specialization of the exact algebraic identity in `convex_generator/CONVEX_GENERATOR_CLASSIFICATION.md`; the prefactor in (4) is positive.

## 3. The exact integral formulation

Let X_A,Y_A be the images under (3) of the constant Wirtinger coordinates of A. For a compatible perturbation put h=partial_barz phi. Then

\[
Y=Y_A+h,\qquad X=X_A+T_kh,
\qquad T_k=a_kB+b_kI,
\]

\[
a_k=\frac{k+1}{2\sqrt{k}},\qquad b_k=\frac{k-1}{2\sqrt{k}},
\qquad a_k^2-b_k^2=1.
\tag{6}
\]

Therefore the full original question at this k is equivalent to

\[
\boxed{\int_{T^2}\Phi_k(X_0+T_kh,Y_0+h)
\ge\Phi_k(X_0,Y_0)}
\tag{7}
\]

for every pair of constant complex numbers X_0,Y_0 and every mean-zero complex h in L4. One direction follows from (1) and (3); the other uses (2) to build the potential and invertibility of (3) to realize all constants by A. Thus (7) neither omits compatible fields nor introduces arbitrary incompatible ones.

At k=1, T_k=B and

\[
J_1(p,q)=2\left(|p|^4+|q|^4-|p|^2|q|^2
 +\operatorname{Re}(p\overline q)(|p|^2-|q|^2)\right).
\tag{8}
\]

Equation (7) remains a phase-sensitive all-constant inequality even here. The supplied norm bound alone does not evaluate the mixed phase term or its translated cubic terms.

## 4. Scope of the convex-generator classification

When `V=J_k+sW_k` is convex, Jensen yields only

\[
\int J_k(A+D\phi)-J_k(A)
\ge-s\left[\int W_k(A+D\phi)-W_k(A)\right].
\]

But `W_k=4|q|^2|n p+(k-1)q|^2` is not a null Lagrangian and its gap has no supplied nonpositive sign. Ordinary convexity of V therefore supplies no completed minorant proof of (7). Similarly an orthogonal mixing of X,Y that diagonalizes the Hopf matrix changes (6); the new graph must be justified rather than declared compatible.

Every symbol and finite approximation above uses the original unit-torus frequencies. No incompatible source-coordinate substitution, new source retrieval, numerical estimate, or optimization oracle enters the reformulation.
