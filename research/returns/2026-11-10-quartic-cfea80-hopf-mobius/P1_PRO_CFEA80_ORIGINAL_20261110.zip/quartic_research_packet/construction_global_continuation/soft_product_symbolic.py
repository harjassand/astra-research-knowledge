import sympy as S, itertools, time, pathlib, pickle
start=time.perf_counter()
k,a,b,h=S.symbols('k a b h',real=True);ell=3*k-1;n=k+1;m=3*k+1
P,Q,R=S.symbols('P Q R',real=True)

def mul(x,y):
 z={}
 for i,ci in x.items():
  for j,cj in y.items():z[i+j]=S.expand(z.get(i+j,0)+ci*cj)
 return z
f={1:-S.I/2,-1:S.I/2,2:-S.I*a/2,-2:S.I*a/2}
fp={i:S.I*i*c for i,c in f.items()};fpp={i:-i*i*c for i,c in f.items()}
powers=[]
for pol in [fpp,fp,f]:
 pp=[{0:S.Integer(1)}]
 for z in range(4):pp.append(mul(pp[-1],pol))
 powers.append(pp)
cache={}
def moment(i,j,l):
 key=(i,j,l)
 if key not in cache:cache[key]=S.factor(mul(mul(powers[0][i],powers[1][j]),powers[2][l]).get(0,0))
 return cache[key]
def integrate(poly):
 ans=0
 for (i,j,l),co in S.Poly(S.expand(poly),P,Q,R).terms():
  ans+=co*moment(i,j,l)*moment(l,j,i).subs(a,b)*h**(j+2*l)
 return S.factor(ans)
x,y,z,w=S.symbols('x y z w');Fvars=[x,y,z,w]
u=x*x+z*z;v=y*y+w*w;j=x*w-y*z
J=ell*(k*u-v+2*j)**2/(8*n)+ell*u*v/4+j*j
sub={x:2*Q,y:2*R,z:-m*P,w:-m*Q}
c=integrate(J.subs(sub));bv=[integrate(S.diff(J,f).subs(sub)) for f in Fvars]
H=S.Matrix([[integrate(S.diff(J,f,g).subs(sub)) for g in Fvars] for f in Fvars])
print('b',bv,flush=True);print('H diagonal block',[[S.factor(H[i,j]) for j in [0,3]] for i in [0,3]],flush=True)
assert bv[1]==bv[2]==0
assert all(H[i,j]==0 for i,j in itertools.product([0,3],[1,2]))
D=S.factor(H[0,0]*H[3,3]-H[0,3]**2)
print('detH',D,flush=True)
num=S.factor(2*c*D-(bv[0]**2*H[3,3]-2*bv[0]*bv[3]*H[0,3]+bv[3]**2*H[0,0]))
print('num factor length',len(str(num)),'elapsed',time.perf_counter()-start,flush=True)
path=pathlib.Path(__file__).with_name('soft_product_symbolic.pkl');path.write_bytes(pickle.dumps(dict(k=k,a=a,b=b,h=h,c=c,bv=bv,H=H,D=D,num=num)))
print('saved',path,flush=True)
