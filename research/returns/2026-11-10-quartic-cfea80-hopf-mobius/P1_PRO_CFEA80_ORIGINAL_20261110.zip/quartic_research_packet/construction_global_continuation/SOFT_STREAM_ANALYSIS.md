# A separable soft-stream calculation

This is a targeted compatible calculation, not a full proof or a negative witness.

Put `eta=ell n/4`, `m=3k+1`, and choose a smooth periodic scalar psi. The vector potential

\[
\varphi=(2\psi_y,-m\psi_x)
\]

has gradient

\[
G=\begin{pmatrix}2Q&2R\\-mP&-mQ\end{pmatrix},
\qquad P=\psi_{xx},\ Q=\psi_{xy},\ R=\psi_{yy}.
\]

It satisfies the critical soft constraint `(m/2)G11+G22=0` exactly. At mean I,

\[
\tfrac12H_G[I,I]=\eta m^2\int P^2,
\qquad b_G:I=-\eta\int[8Q^3+2m^2QP^2].
\]

For a separable scalar potential `psi=f(x)g(y)`,

\[
\int QP^2=\left(\int f'(f'')^2\right)\left(\int g'g^2\right)=0,
\]

so the only cubic term is

\[
b_G:I=-8\eta\left(\int(f')^3\right)\left(\int(g')^3\right).
\]

This exposes a genuine interaction between two source directions; a single pure wave has no such cubic term.

## Exact two-harmonic moment calculation

Take `f(theta)=sin(theta)+alpha sin(2theta)` and similarly `g(zeta)=sin(zeta)+beta sin(2zeta)`. For positive integers N,M, choose

\[
\psi(x,y)=\frac{f(2\pi Nx)g(2\pi My)}{(2\pi N)^2},\qquad h=M/N.
\]

Then `P=f''g`, `Q=h f'g'`, `R=h^2fg''`, so all gradient Fourier coefficients are rational when alpha,beta,h,k are rational. Since `integral(f')^3=3alpha/2`,

\[
b_G:I=-18\eta\alpha\beta h^3.
\]

Exact Laurent integration gives zero off-diagonal entries of b and decouples the diagonal and off-diagonal blocks of H. The two nonzero entries are

\[
b_{11}=\frac98\alpha\beta h^3 k(81k^2+96k+31),
\]
\[
b_{22}=-\frac98\alpha\beta h^3(81k^3+108k^2+39k-4).
\]

Thus minimizing over ALL affine means reduces to a two-by-two diagonal mean block; the other block is nonnegative by the accepted Legendre-Hadamard argument and has zero linear term. The exact c,H,b expressions and Schur numerator `2c det Hdiag-bdiag^T adj(Hdiag)bdiag` are generated and retained by `soft_product_symbolic.py`.

The symbolic derivation completed in 7.69 seconds. Expressing the Schur numerator in `X=alpha^2,Y=beta^2,Z=h^2,t=3k-1` produced 1246 nonzero rational monomials, 109 with negative coefficients. This rules out only a direct coefficientwise-positivity proof of that displayed polynomial; it is not a sign determination.

A fixed deterministic grid evaluated 1764 combinations: k in `.334,.34,.5,1,2,5,20`; alpha and beta in `1/8,1/4,1/2,1,2,4`; h in `1/8,1/4,1/2,1,2,4,8`. The evaluation took 0.0034 seconds after symbolic preparation. Its largest floating moment ratio `b^T H^{-1}b/(2c)` was approximately 0.044485. No negative candidate appeared, and the class was not expanded further. These finite floating evaluations are exploratory and prove no universal sign.

The calculation identifies a cancellation and a finite algebraic subproblem. It does not reach the unrestricted endpoint or certify a negative original gap.
