# Quantitative original-energy inequality for radial matrix paths

This note concerns the ORIGINAL quartic J_k, for every real k>1/3. It proves a full-amplitude, all-mean result for a particular compatible class, not global quasiconvexity for arbitrary gradients.

The qualitative smooth radial-path argument was already recorded in `projection_global_continuation/principal_and_radial_calculations.md`, Section 3. The additions here are the exact quartic reserve, the W^(1,4) passage through a possible singular centre, and an explicit strict bound for radial spirals. No numerical search is used.

## 1. Rank-one increment reserve

For the accepted rank-one-convex homogeneous quartic J_k, every matrix F and rank-one matrix E satisfy

\[
J_k(F+E)-J_k(F)-DJ_k(F):E\ge\frac13J_k(E).
\tag{1}
\]

Indeed, along F+tE write the tangent-subtracted polynomial as
`alpha t^4+beta t^3+gamma t^2`, where alpha=J_k(E)>=0. Convexity says
`12 alpha t^2+6 beta t+2 gamma>=0` for all real t. If alpha>0, this implies
`gamma>=3 beta^2/(8 alpha)`, and

\[
\alpha+\beta+\gamma
\ge\frac\alpha3+\frac{3}{8\alpha}
       \left(\beta+\frac{4\alpha}{3}\right)^2
\ge\frac\alpha3.
\]

If alpha=0, convexity forces beta=0 and gamma>=0. Thus (1) holds, with its reserve used once below.

## 2. Annular identity

Let D_R be a disk centred at zero. Let C:(0,R]->R^(2x2) be locally absolutely continuous, with C(R)=A. Put

\[
f(x)=C(|x|)x,\qquad e=\frac{x}{|x|},\qquad
E(r,e)=r(C'(r)e)\otimes e.
\]

At almost every point of an annulus,

\[
Df=C(r)+E(r,e).
\tag{2}
\]

The increment E has rank at most one. Apply (1) and use the identity `average_(S1) e tensor e=I/2` to obtain

\[
\fint_{S^1}J_k(Df(r e))\,de
\ge J_k(C(r))+\frac r2\frac{d}{dr}J_k(C(r))
 +\frac13\fint_{S^1}J_k(E(r,e))\,de.
\tag{3}
\]

Multiplication by 2 pi r makes the first two terms the exact derivative of `pi r^2 J_k(C(r))`. Hence for 0<rho<R,

\[
\int_{D_R\setminus D_\rho}J_k(Df)
 -\pi R^2J_k(A)+\pi\rho^2J_k(C(\rho))
\ge\frac13\int_{D_R\setminus D_\rho}J_k(E).
\tag{4}
\]

This uses rank-one convexity and one-variable calculus, not a source change of variables or a claim that C(r) alone is a compatible matrix field.

## 3. The centre and W^(1,4) approximation

Assume f belongs to W^(1,4)(D_R;R^2). The tangential identity is `(Df)e_perp=C(r)e_perp`. For every real matrix C,

\[
\fint_{S^1}|Ce|^4\,de
=\frac{|C|^4+2\operatorname{tr}((C^TC)^2)}8
\ge\frac{|C|^4}{4}.
\tag{5}
\]

Thus `integral_0^R r |C(r)|^4 dr<infinity`. There is consequently a sequence rho_n decreasing to zero such that

\[
\rho_n^2|C(\rho_n)|^4\longrightarrow0.
\tag{6}
\]

Otherwise `r^2 |C(r)|^4` would have a positive lower bound near zero and its integral against dr/r would diverge. The quartic upper bound `J_k(C)<=M_k |C|^4` makes the inner boundary term in (4) tend to zero along this sequence. Also E=Df-C is in L4, so J_k(E) is integrable. Passing to the limit gives

\[
\boxed{\int_{D_R}J_k(Df)-|D_R|J_k(A)
\ge\frac13\int_{D_R}J_k\bigl(r(C'e)\otimes e\bigr).}
\tag{7}
\]

An explicit strong approximation is available. Replace C by the constant C(rho_n) on 0<r<rho_n and leave it unchanged outside. The resulting f_n is continuous across the inner circle, its core gradient is C(rho_n), and

\[
\int_{D_{\rho_n}}|Df_n|^4
=\pi\rho_n^2|C(\rho_n)|^4\longrightarrow0.
\]

Together with absolute continuity of the integral of |Df|^4, this proves strong gradient convergence in L4. The common outer trace gives strong W^(1,4) convergence by Poincare's inequality. Each truncated profile has its inner boundary term cancelled exactly by the constant-core energy. Smooth compact approximations of the zero-trace perturbation f-Ax preserve the limiting inequality, since

\[
|J_k(F)-J_k(G)|\le C_k(|F|+|G|)^3|F-G|
\]

and Holder's inequality make the energy continuous under strong L4 gradient convergence.

Conversely, local absolute continuity and integrability of the formal gradient (2) suffice for f to belong to W^(1,4): (5) first controls C and then f. Along (6), the integration-by-parts boundary term at the deleted centre is bounded by a constant times `rho_n^2 |C(rho_n)|`, which tends to zero. The formal gradient is therefore the distributional gradient. No centre regularity is being assumed for free.

Because C(R)=A, f-Ax has zero trace. Extend it by zero outside a disk contained in the unit torus. This is an admissible periodic W^(1,4) perturbation with mean gradient zero; the exterior energy is J_k(A). Therefore (7) also proves the torus inequality for this class. Translating the disk changes nothing.

## 4. Explicit radial spirals at every outer affine mean

For alpha>1/2 and real beta take

\[
C(r)=A\left(\frac rR\right)^{\alpha-1}
 R_{\beta\log(r/R)}.
\tag{8}
\]

Before multiplication by A, the complex map is `f(z)=z (|z|/R)^(alpha-1+i beta)`, with

\[
p=f_z=\frac{\alpha+1+i\beta}{2}
 \left(\frac rR\right)^{\alpha-1+i\beta},\qquad
q=f_{\bar z}=\frac{\alpha-1+i\beta}{2}
 \left(\frac rR\right)^{\alpha-1+i\beta}e^{2i\theta}.
\tag{9}
\]

The pre-composition Jacobian is `alpha (r/R)^(2alpha-2)` and is generally variable. For nonzero A the gradient belongs to L4 exactly when alpha>1/2. The affine boundary value is Ax, so the compact extension is compatible and its mean is A.

For a rank-one matrix a tensor b, the ORIGINAL formula gives

\[
J_k(a\otimes b)=\frac\ell{8n}|a|^4
  \left(k^2b_1^4+2b_1^2b_2^2+b_2^4\right)
\ge \nu_k |a\otimes b|^4,
\quad \nu_k=\frac{\ell\min(k^2,1)}{8n}>0.
\tag{10}
\]

Set eta=(alpha-1)^2+beta^2. The matrix `(alpha-1)I+beta R_(pi/2)` is sqrt(eta) times a rotation. Direct angular and radial integration therefore gives

\[
\int_{D_R}|r(C'e)\otimes e|^4
=\frac{\pi R^2\eta^2}{2\alpha-1}
  \frac{|A|^4+2\operatorname{tr}((A^TA)^2)}8.
\tag{11}
\]

Combining (7), (10), and (11),

\[
\boxed{\int_{D_R}J_k(Df)-\pi R^2J_k(A)
\ge\frac{\nu_k\pi R^2\eta^2}{3(2\alpha-1)}
  \frac{|A|^4+2\operatorname{tr}((A^TA)^2)}8.}
\tag{12}
\]

This is strictly positive for every nonzero A and every nonidentity spiral `(alpha,beta)!=(1,0)`. A constant linear core permits arbitrary regular radial paths, including power exponents outside alpha>1/2 on an annulus; its cost is accounted for exactly by (4). Such radial matrix paths cannot provide a negative witness.

## 5. Costs and scope

The proof uses finite polynomial identities, rank-one convexity, a completion of squares, and elementary integration. No sampling, optimization, real oracle, or unaccounted approximation is a proof step. Arbitrary angular dependence of a vector potential is not covered.
