"""Exact all-affine-mean support criterion for F=A B, det B=1, mean B=I.
No optimization oracle: the only candidate generator is a fixed-size spectral
calculation and bounded scalar bisection; every reported support is rational PSD.
"""
from generating_polygons import *
import numpy as np,time,itertools

def zero(n,m=None):return [[Q(0) for j in range(n if m is None else m)] for i in range(n)]
def dot(x,y):return sum(a*b for a,b in zip(x,y))
def mv(A,x):return [dot(row,x) for row in A]
def form(A,x,y):return dot(x,mv(A,y))
def madd(A,B,scale=Q(1)):return [[a+scale*b for a,b in zip(ar,br)] for ar,br in zip(A,B)]
def mscale(A,s):return [[s*a for a in row] for row in A]

def exact_cells(d):
 N=d['N'];dirs=d['directions'];v=list(map(Q,d['coefficients']));values=[]
 for i in range(len(dirs)):
  row=v[i*(N-1):(i+1)*(N-1)];values.append(row+[-sum(row)])
 cells,counts=partition(dirs,N);out=[];mean=[Q(0)]*4;total=Q(0);amin=None
 for poly,bands in cells:
  w=area(poly);b=h=c=Q(0)
  for (p,q),row,band in zip(dirs,values,bands):
   b+=p*p*row[band];h+=p*q*row[band];c+=q*q*row[band]
  a=1+h
  if a<=0:raise ValueError('Nonpositive twist')
  F=(1/a,-c/a,b/a,a-b*c/a);weight=w*a
  assert F[0]*F[3]-F[1]*F[2]==1
  out.append((weight,F));total+=weight
  for i in range(4):mean[i]+=weight*F[i]
  amin=a if amin is None else min(a,amin)
 assert total==1 and mean==[1,0,0,1]
 return out,counts,amin

def moments(d):
 cells,counts,amin=exact_cells(d)
 # Combining equal matrices is exact and lowers rational summation costs.
 atoms={}
 for w,F in cells:atoms[F]=atoms.get(F,Q(0))+w
 U=zero(3);V=zero(3);W=zero(3);l1=[Q(0)]*3;l2=[Q(0)]*3
 for F,w in atoms.items():
  a,b,c,dd=F;p=[a*a,2*a*c,c*c];q=[b*b,2*b*dd,dd*dd]
  for i in range(3):
   l1[i]+=w*p[i];l2[i]+=w*q[i]
   for j in range(3):
    U[i][j]+=w*p[i]*p[j];V[i][j]+=w*q[i]*q[j];W[i][j]+=w*(p[i]*q[j]+q[i]*p[j])/2
 U[0][0]-=1;V[2][2]-=1;W[0][2]-=Q(1,2);W[2][0]-=Q(1,2);l1[0]-=1;l2[2]-=1
 return dict(U=U,V=V,W=W,l1=l1,l2=l2,cell_counts=counts,atoms=len(atoms),amin=amin)

def sphere_coeff(data,k):
 k=Q(k);R=madd(madd(mscale(data['U'],k*k),data['W'],2),data['V']);l=[k*a-b for a,b in zip(data['l1'],data['l2'])]
 t0=[Q(1),Q(0),Q(1)];T=[[Q(1),Q(0),Q(-1)],[Q(0),Q(1),Q(0)]]
 M=zero(3);hh=[Q(0)]*3;cc=form(R,t0,t0)
 for i in range(2):
  hh[i]=form(R,T[i],t0)
  for j in range(2):M[i][j]=form(R,T[i],T[j])
  M[i][2]=M[2][i]=2*dot(l,T[i])
 hh[2]=2*dot(l,t0)
 return M,hh,cc

def support_matrix(data,k,tau):
 M,h,c=sphere_coeff(data,k);Z=zero(4)
 for i in range(3):
  for j in range(3):Z[i][j]=M[i][j]-(tau if i==j else 0)
  Z[i][3]=Z[3][i]=h[i]
 Z[3][3]=c+tau
 return Z

def pd_ldl(A):
 # Exact rational LDL; positive pivots certify strict positive definiteness.
 n=len(A);L=zero(n);D=[]
 for i in range(n):
  L[i][i]=Q(1);v=A[i][i]-sum(L[i][j]**2*D[j] for j in range(i))
  if v<=0:return False,D+[v]
  D.append(v)
  for r in range(i+1,n):L[r][i]=(A[r][i]-sum(L[r][j]*L[i][j]*D[j] for j in range(i)))/v
 return True,D

def secular_candidate(data,k,steps=90):
 M,h,c=sphere_coeff(data,k);M=np.array(M,dtype=float);h=np.array(h,dtype=float);c=float(c)
 e,U=np.linalg.eigh(M);g=U.T@h;scale=max(1.,np.linalg.norm(M),np.linalg.norm(h));tol=1e-12*scale
 lowmask=(e-e[0]<tol);gnorm=np.linalg.norm(g[lowmask]);v0=np.zeros(3);mask=~lowmask;v0[mask]=-g[mask]/(e[mask]-e[0]);n0=float(v0@v0)
 if gnorm<tol and n0<=1:
  lam=e[0];v=v0;v[np.flatnonzero(lowmask)[0]]=np.sqrt(max(0.,1-n0))
 else:
  width=max(1.,np.linalg.norm(h),np.linalg.norm(M));lo=e[0]-width
  def norm2(t):return float(np.sum((g/(e-t))**2))
  for j in range(32):
   if norm2(lo)<1:break
   width*=2;lo=e[0]-width
  hi=np.nextafter(e[0],-np.inf)
  for j in range(steps):
   mid=(lo+hi)/2
   if norm2(mid)>1:hi=mid
   else:lo=mid
  lam=(lo+hi)/2;v=-g/(e-lam);v/=np.linalg.norm(v)
 v=U@v;value=float(v@M@v+2*h@v+c)
 tau=Q(float(lam-value/4)).limit_denominator(10**9)
 return dict(value=value,v=v.tolist(),tau=tau,lagrange=float(lam))

def reduced_gap(data,k,A):
 k=Q(k);a,b,c,d=map(Q,A);t=[a*a+c*c,a*b+c*d,b*b+d*d];det=a*d-b*c
 R=madd(madd(mscale(data['U'],k*k),data['W'],2),data['V']);l=[k*x-y for x,y in zip(data['l1'],data['l2'])]
 return form(R,t,t)+4*det*dot(l,t)

def certify_negative(data,k,v):
 x,y,dd=v;aa=np.sqrt(max(0.,1+x))
 A=[aa,y/aa,0.,dd/aa] if aa>1e-10 else [0.,np.sqrt(2.),0.,0.]
 for pow in [16,24,32]:
  Aq=[Q(round(z*2**pow),2**pow) for z in A];kr=Q(k);gap=reduced_gap(data,kr,Aq)
  if gap<0:
   if kr==Q(1,3):
    eps=Q(1,2)
    for step in range(100):
     if reduced_gap(data,Q(1,3)+eps,Aq)<0:break
     eps/=2
    else:continue
    kr=Q(1,3)+eps;gap=reduced_gap(data,kr,Aq)
   original=(3*kr-1)*gap/(8*(kr+1))
   return dict(k=str(kr),A=[[str(Aq[0]),str(Aq[1])],[str(Aq[2]),str(Aq[3])]],reduced_gap=str(gap),original_gap=str(original),strict_negative=original<0)
 return None

def bernstein_cover(data,max_leaves=256,max_depth=12):
 # Candidate selection is numerical; every accepted interval has three exact PD matrices.
 pending=[(Q(1,3),Q(1),0)];leaves=[];checks=0;candidate_min=None
 while pending and checks<max_leaves:
  left,right,depth=pending.pop();mid=(left+right)/2;can=secular_candidate(data,mid);checks+=1
  if candidate_min is None or can['value']<candidate_min:candidate_min=can['value']
  if can['value']<0:
   neg=certify_negative(data,mid,can['v'])
   if neg:return dict(status='negative',witness=neg,checks=checks)
  tau=can['tau'];Z0=support_matrix(data,left,tau);Z2=support_matrix(data,right,tau);Zm=support_matrix(data,mid,tau)
  Z1=madd(mscale(Zm,2),madd(Z0,Z2),Q(-1,2))
  cert=[pd_ldl(z) for z in [Z0,Z1,Z2]]
  if all(x[0] for x in cert):
   leaves.append(dict(left=str(left),right=str(right),tau=str(tau),ldl_pivots=[[str(v) for v in x[1]] for x in cert]))
  elif depth<max_depth:
   pending.extend([(mid,right,depth+1),(left,mid,depth+1)])
  else:return dict(status='unresolved_depth',checks=checks,leaves=leaves,pending=[[str(left),str(right),depth]],candidate_min=candidate_min)
 if pending:return dict(status='unresolved_budget',checks=checks,leaves=leaves,pending=[[str(a),str(b),c] for a,b,c in pending],candidate_min=candidate_min)
 return dict(status='all_A_all_k_positive',checks=checks,leaves=leaves,candidate_min=candidate_min)

def serial(data):
 if isinstance(data,Q):return str(data)
 if isinstance(data,list):return [serial(x) for x in data]
 if isinstance(data,dict):return {k:serial(v) for k,v in data.items()}
 return data

if __name__=='__main__':
 # These are trusted internally computed exact certificates; retain a finite serialization cap.
 sys.set_int_max_str_digits(100000)
 start=time.perf_counter();path=pathlib.Path(sys.argv[1]);d=json.loads(path.read_text());m=moments(d)
 print(json.dumps(dict(stage='moments',seconds=time.perf_counter()-start,cells=m['cell_counts'][-1],atoms=m['atoms'],amin=str(m['amin']))),flush=True)
 for k in [Q(1,3),Q(17,50),Q(1,2),Q(1)]:
  ca=secular_candidate(m,k);print(json.dumps(dict(stage='candidate',k=str(k),value=ca['value'],tau=str(ca['tau']))),flush=True)
  if ca['value']<0:
   cert=certify_negative(m,k,ca['v'])
   if cert:print('NEGATIVE',json.dumps(cert),flush=True)
 result=bernstein_cover(m)
 base=path.with_name(path.stem+'_outer_mean')
 base.with_suffix('.moments.json').write_text(json.dumps(serial(m),indent=2)+'\n')
 base.with_suffix('.certificate.json').write_text(json.dumps(serial(result),indent=2)+'\n')
 print(json.dumps(dict(status=result['status'],checks=result.get('checks'),intervals=len(result.get('leaves',[])),candidate_min=result.get('candidate_min'),seconds=time.perf_counter()-start)),flush=True)
