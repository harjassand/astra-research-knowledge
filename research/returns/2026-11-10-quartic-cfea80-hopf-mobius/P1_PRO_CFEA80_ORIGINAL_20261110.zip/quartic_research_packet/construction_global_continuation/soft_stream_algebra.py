import sympy as S
k,P,Q,R=S.symbols('k P Q R');ell=3*k-1;n=k+1;m=3*k+1
A=S.Matrix([[2*Q,2*R],[-m*P,-m*Q]])
u=4*Q*Q+m*m*P*P;v=4*R*R+m*m*Q*Q;j=2*m*(P*R-Q*Q)
J=S.expand(ell*(k*u-v+2*j)**2/(8*n)+ell*u*v/4+j*j)
for powers,c in S.Poly(J,P,Q,R).terms(): print(powers,S.factor(c))
