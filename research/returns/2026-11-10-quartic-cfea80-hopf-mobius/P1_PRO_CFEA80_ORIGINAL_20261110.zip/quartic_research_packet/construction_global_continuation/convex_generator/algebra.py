import sympy as S
k,a,b,r=S.symbols('k a b r');ell=3*k-1;n=k+1
u=(a+4*b+4*r)/n**2;v=(a+4*k*k*b-4*k*r)/n**2;j=(a-4*k*b-2*(k-1)*r)/n**2
J=S.factor(ell*(k*u-v+2*j)**2/(8*n)+ell*u*v/4+j*j)
for e,c in S.Poly(J,a,b,r).terms():print(e,S.factor(c))
