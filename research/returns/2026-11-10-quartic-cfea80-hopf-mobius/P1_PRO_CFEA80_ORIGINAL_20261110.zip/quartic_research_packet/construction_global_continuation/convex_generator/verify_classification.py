"""Exact algebraic checks for convexity feasibility of J_k+sW.
The proof of the eigenvalue criterion is in CONVEX_GENERATOR_CLASSIFICATION.md.
"""
import sympy as S,json,time
from fractions import Fraction as Q
from pathlib import Path
start=time.perf_counter()
t,x1,x2,y1,y2,s=S.symbols('t x1 x2 y1 y2 s', real=True)
k=t*t;n=k+1;ell=3*k-1;D=3*k+5
# q=Y, n p+(k-1)q=2 sqrt(k) X. This is an invertible real coordinate change.
f11=2*(t*x1+y1)/n;f21=2*(t*x2+y2)/n
f12=-2*(t*x2-k*y2)/n;f22=2*(t*x1-k*y1)/n
u=f11*f11+f21*f21;v=f12*f12+f22*f22;j=f11*f22-f12*f21
J=ell*(k*u-v+2*j)**2/(8*n)+ell*u*v/4+j*j
W=(u+v-2*j)*(k*k*u+v+2*k*j)
H1=x1*x1+x2*x2-y1*y1-y2*y2;H2=2*(x1*y1+x2*y2);H3=2*(x1*y2-x2*y1)
g=2/(t*D);d0=(1-k)/(k*D);tau=n*(ell+4*s*n*n)/(2*k*D)
hopf=H1*H1+2*g*H1*H2+(tau+d0)*H2*H2+tau*H3*H3
assert S.factor((J+s*W)*n**3/(2*k*k*D)-hopf)==0
print('original quartic to Hopf form: exact zero',flush=True)
k=S.symbols('k',positive=True);n=k+1;ell=3*k-1;D=3*k+5;sstar=(9*k*k+25*k-2)/(8*n**3)
d0=(1-k)/(k*D);tau=n*(ell+4*sstar*n*n)/(2*k*D)
assert S.factor(tau+d0-S.Rational(5,4))==0
print('explicit s choice fixes block diagonal at5/4: exact zero',flush=True)
l=Q(13,20);r=Q(33,50)
for i in range(45):
 m=(l+r)/2
 if m*(3*m+5)**2<32:l=m
 else:r=m
q=Q(17,50);margin=32-q*(3*q+5)**2
out=dict(feasibility='k*(3*k+5)^2 >= 32',s_choice='(9*k^2+25*k-2)/(8*(k+1)^3)',threshold_lower=str(l),threshold_upper=str(r),threshold_width=str(r-l),k_17_50_obstruction_margin=str(margin),exact_checks=2,seconds=time.perf_counter()-start)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
