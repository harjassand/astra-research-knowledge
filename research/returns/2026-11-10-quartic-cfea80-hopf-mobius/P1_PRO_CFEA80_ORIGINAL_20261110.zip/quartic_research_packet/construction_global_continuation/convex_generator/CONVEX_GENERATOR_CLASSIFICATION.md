# Complete convexity feasibility for the proposed generator J_k+sW_k

Let

\[
W_k(F)=(u+v-2j)(k^2u+v+2kj),\qquad V_{k,s}=J_k+sW_k.
\]

Here J_k is the ORIGINAL quartic and k>1/3. This note classifies ordinary matrix convexity of this proposed generator family. It does not prove dissipation of J_k and does not give a negative quasiconvexity witness.

## Result

There exists a real s for which V_(k,s) is globally convex if and only if

\[
\boxed{k(3k+5)^2\ge32.}
\tag{1}
\]

The unique positive threshold k_* solves `9k^3+30k^2+25k-32=0` and satisfies

\[
k_*\approx0.657961495631632.
\]

For every k>=k_*, one explicit convex choice is

\[
\boxed{s_*(k)=\frac{9k^2+25k-2}{8(k+1)^3}.}
\tag{2}
\]

For `1/3<k<k_*`, **no real coefficient s**, positive or negative, makes the generator convex. In particular the family fails at k=17/50. For a general positive coefficient t in `t J_k+s W_k`, apply the same statement to the ratio s/t.

## 1. Exact reduction by an invertible real linear coordinate change

Represent the two columns of F by complex numbers `p+q` and `i(p-q)`. Then

\[
u=|p+q|^2,\quad v=|p-q|^2,\quad j=|p|^2-|q|^2,
\]

and exactly

\[
W_k=4|q|^2|n p+(k-1)q|^2,\qquad n=k+1.
\]

Set `w=n p+(k-1)q`. If `a=|w|^2`, `b=|q|^2`, `r=Re(w conjugate(q))`, direct expansion gives

\[
n^3J_k=\frac{3k+5}{8}a^2+2k^2(3k+5)b^2
-(3k+1)ab+2(a-4kb)r-2(k-1)r^2.
\tag{3}
\]

Now use the invertible linear coordinates

\[
w=2\sqrt{k}\,X,\qquad q=Y,
\]

where X,Y are real two-dimensional vectors, viewed as complex numbers. Define the three quadratic coordinates

\[
H_1=|X|^2-|Y|^2,\quad H_2=2X\cdot Y,\quad
H_3=2\det(X,Y).
\]

They satisfy

\[
H_1^2+H_2^2+H_3^2=(|X|^2+|Y|^2)^2.
\]

Put

\[
g=\frac{2}{\sqrt{k}(3k+5)},\qquad
\delta=\frac{1-k}{k(3k+5)},\qquad
\tau=\frac{n(\ell+4s n^2)}{2k(3k+5)}.
\tag{4}
\]

Equations (3)-(4) give the exact identity

\[
\boxed{\frac{n^3}{2k^2(3k+5)}V_{k,s}
=H^TMH,\qquad
M=\begin{pmatrix}1&g&0\\g&\tau+\delta&0\\0&0&\tau\end{pmatrix}.}
\tag{5}
\]

The factor is positive. Every coordinate change used here is invertible and real linear. Ordinary convexity is invariant under these changes; they are not being applied to compatible fields or to a period lattice.

## 2. Convexity criterion for a quadratic Hopf form

**Lemma.** For a symmetric real 3-by-3 matrix M, the quartic `H(X,Y)^T M H(X,Y)` is convex in the four real entries of X,Y if and only if

\[
\boxed{\lambda_{\max}(M)\le2\lambda_{\min}(M).}
\tag{6}
\]

This includes the identically zero form. A nonzero convex form of this type has positive least eigenvalue.

### Reduction to a diagonal M

Real orthogonal mixing of X,Y rotates `(H1,H2)` through twice the mixing angle and leaves H3 fixed. Multiplying Y by a complex unit rotates `(H2,H3)` and leaves H1 fixed. These orthogonal transformations of the four real variables generate all rotations of H, so M may be diagonalized without changing convexity. Axis permutations are included, with harmless sign changes of eigenvectors.

### Necessity

A convex homogeneous even quartic is nonnegative, so every eigenvalue of M is nonnegative (the Hopf coordinates attain every direction). At `X=e1,Y=0`, with diagonal M and a perturbation `Y=t e1`, the quartic is

\[
\lambda_1(1-t^2)^2+4\lambda_2t^2.
\]

Its second derivative at zero is `4(2lambda2-lambda1)`. Permuting the eigenvalue directions proves `lambda_max<=2lambda_min`. If the minimum eigenvalue is zero this forces all eigenvalues to be zero.

### Sufficiency

Normalize the smallest eigenvalue to one and order the others as `1<=b<=a<=2`. Then

\[
\operatorname{diag}(a,b,1)
=(2-a)\operatorname{diag}(1,1,1)
+(a-b)\operatorname{diag}(2,1,1)
+(b-1)\operatorname{diag}(2,2,1).
\tag{7}
\]

Every coefficient is nonnegative. The three quartics in (7) are convex:

\[
H_1^2+H_2^2+H_3^2=(|X|^2+|Y|^2)^2,
\]

\[
2H_1^2+H_2^2+H_3^2=2(|X|^4+|Y|^4),
\]

\[
2H_1^2+2H_2^2+H_3^2
=2\operatorname{tr}((Z^TZ)^2),\qquad Z=[X\ Y].
\]

For the last assertion, along `Z+tE`, put `C=Z^TZ`, `D=Z^TE+E^TZ`, `P=E^TE`. The second derivative of `tr((Z^TZ)^2)` is

\[
2\operatorname{tr}(D^2)+4\operatorname{tr}(CP)\ge0,
\]

because D is symmetric and C,P are positive semidefinite. Thus no external Schatten-norm theorem or assumed sum-of-squares completeness is needed. Positive combinations in (7) prove sufficiency.

## 3. Necessity of the threshold

Write `h=tau+delta`. The eigenvalues of the first 2-by-2 block in (5) are

\[
\lambda_\pm=\frac{1+h\pm\sqrt{(1-h)^2+4g^2}}2.
\]

Convexity requires `lambda_+<=2 lambda_-`, regardless of the third eigenvalue. This is equivalent to

\[
2h^2-5h+2+9g^2\le0.
\tag{8}
\]

The quadratic in h has its minimum at h=5/4, where its value is `9(g^2-1/8)`. Therefore (8) is impossible unless

\[
g^2\le1/8\quad\Longleftrightarrow\quad k(3k+5)^2\ge32.
\]

This is an obstruction for every real s, not a failed test of one chosen coefficient. It can already be detected on a two-real-dimensional restriction of the quartic after diagonalizing the first block.

At the supplied low parameter,

\[
\frac{17}{50}\left(3\frac{17}{50}+5\right)^2
=\frac{1540217}{125000},
\]

so its deficit from 32 is the exact positive rational

\[
\frac{2459783}{125000}.
\]

## 4. Sufficiency and explicit coefficient

Assume (1) and choose s as in (2). Direct algebra gives

\[
\tau+\delta=5/4.
\]

Since `g^2<=1/8`,

\[
3/4\le\lambda_-\le\lambda_+\le3/2.
\]

For every k>1/3,

\[
-1/8<\delta\le1/3.
\]

The upper bound follows from `(3k-1)(k+3)>=0`; for k>=1 the lower bound follows from `(k-1)/(k(3k+5))<1/(3k+5)<=1/8`, and for k<1 delta is positive. Hence the third eigenvalue obeys

\[
11/12\le\tau=5/4-\delta<11/8.
\]

All three eigenvalues therefore lie in `[3/4,3/2]`, proving (6) and global convexity. The inequalities are strict in the eigenvalue-ratio criterion above the threshold. Examples are `s_*(2/3)=63/125` and `s_*(1)=1/2`.

## 5. Exact feasibility test for an arbitrary coefficient

For a given k and s, calculate g,delta,tau from (4), and put h=tau+delta. The full convexity condition is

\[
\max(\lambda_+,\tau)\le2\min(\lambda_-,\tau).
\]

Equivalently, using the bounds on delta valid for k>1/3, it is the following four scalar rational inequalities:

\[
\tau\ge1/2,
\]
\[
2h^2-5h+2+9g^2\le0,
\]
\[
(2\tau-1)(\tau-\delta)\ge g^2,
\]
\[
(\tau+2\delta)(2-\tau)\ge4g^2.
\tag{9}
\]

They provide a sharp coefficient-feasibility test if the dissipation analysis needs choices other than (2). The threshold classification does not require any numerical search over s.

## 6. Verification, finite work and scope

`verify_classification.py` checks (5) directly against the original density under the displayed real linear coordinate transformation, and checks that (2) fixes h=5/4. These are exact symbolic rational identities after writing k=t^2, so the square root causes no numerical approximation. The threshold's decimal display was obtained by 45 exact rational bisection steps starting from `[13/20,33/50]`; the receipt records the rational lower/upper bounds and their width. No optimizer, source retrieval, installation, PDE oracle or new model was used.

This classification concerns convexity of the proposed generator only. It does not assert that its compatible gradient flow decreases J_k. The low-k obstruction does not disprove quasiconvexity, nor does it exclude other convex generators, nonlinear compatible operations or nonlocal arguments. In particular it prevents this two-dimensional generator family from supplying the requested all-k resolution.
