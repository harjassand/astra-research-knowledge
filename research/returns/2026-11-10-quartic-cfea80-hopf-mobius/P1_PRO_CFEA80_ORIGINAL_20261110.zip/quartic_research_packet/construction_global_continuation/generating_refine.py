from generating_search import *

def prolong(row,directions,N):
 oldN=row['N'];oldDirs=[tuple(q) for q in row['directions']];z=[]
 for q in directions:
  if tuple(q) in oldDirs:
   i=oldDirs.index(tuple(q));v=row['coefficients'][i*(oldN-1):(i+1)*(oldN-1)];v=v+[-sum(v)]
   assert N%oldN==0;v=np.repeat(v,N//oldN).tolist();z.extend(v[:-1])
  else:z.extend([0.]*(N-1))
 return np.array(z)

if __name__=='__main__':
 rows=[json.loads(s) for s in pathlib.Path(__file__).with_name('generating_search_results.jsonl').read_text().splitlines()]
 row=min(rows,key=lambda r:r['ratio'])
 dirs=[(1,0),(0,1),(1,1),(1,-1),(1,2),(1,-2),(2,1),(2,-1)]
 outpath=pathlib.Path(__file__).with_name('generating_refined_results.jsonl')
 with outpath.open('w') as f:
  for N in [4,8]:
   start=time.perf_counter();p=Problem(dirs,N);z=prolong(row,dirs,N);init=p.objective(z,True)
   # Implementation derivative check at the nontrivial first prolonged field.
   if N==4:
    v=np.arange(p.P,dtype=float)-p.P/2;v/=np.linalg.norm(v);eps=1e-6
    val,grad=p.objective(z)
    print('gradient_check',float((p.objective(z+eps*v)[0]-p.objective(z-eps*v)[0])/(2*eps)),float(grad@v),flush=True)
   con=LinearConstraint(p.aB,np.full(len(p.weights),-.95),np.full(len(p.weights),10.))
   opt=minimize(p.objective,z,jac=True,method='SLSQP',constraints=[con],bounds=[(-2.,2.)]*p.P,options={'maxiter':600,'ftol':1e-11,'disp':False})
   row=p.objective(opt.x,True);row.update(nit=int(opt.nit),success=bool(opt.success),message=str(opt.message),start_ratio=init['ratio'],seconds=time.perf_counter()-start)
   f.write(json.dumps(row)+'\n');f.flush()
   print(json.dumps({q:row[q] for q in ['N','ratio','endpoint_gap','amin','cell_counts','nit','success','evaluations','seconds']}),flush=True)
   if row['endpoint_gap']< -1e-9:
    d=dict(N=N,directions=dirs,coefficients=[str(Q(round(v*2**24),2**24)) for v in opt.x]);cert=exact_verify(d)
    pathlib.Path(__file__).with_name('generating_candidate.json').write_text(json.dumps(d,indent=2)+'\n')
    pathlib.Path(__file__).with_name('generating_candidate_certificate.json').write_text(json.dumps(cert,indent=2)+'\n')
    print('EXACT',json.dumps(cert),flush=True)
    if cert['endpoint_negative']:raise SystemExit
