import sympy as S,pickle,pathlib,time,json
start=time.perf_counter();p=pathlib.Path(__file__).with_name('soft_product_symbolic.pkl');d=pickle.loads(p.read_bytes())
k,a,b,h=[d[t] for t in ['k','a','b','h']];t,X,Y,Z=S.symbols('t X Y Z',nonnegative=True)
num,den=S.fraction(d['num']);pol=S.Poly(num,a,b,h,k)
terms={}
for (ea,eb,eh,ek),c in pol.terms():
 assert ea%2==eb%2==eh%2==0
 key=(ea//2,eb//2,eh//2)
 terms[key]=terms.get(key,0)+c*((t+1)/3)**ek
new=0
for (ex,ey,ez),co in terms.items():new+=S.expand(co)*X**ex*Y**ey*Z**ez
new=S.Poly(new,X,Y,Z,t)
neg=[(e,str(c)) for e,c in new.terms() if c<0];zero=sum(c==0 for e,c in new.terms())
print(json.dumps(dict(terms=len(new.terms()),negative=len(neg),first_negative=neg[:10],den=str(den),seconds=time.perf_counter()-start)),flush=True)
path=p.with_name('soft_product_coefficients.json');path.write_text(json.dumps(dict(variables=['X=a²','Y=b²','Z=h²','t=3k−1'],denominator=str(den),terms=[[list(e),str(c)] for e,c in new.terms()],negative_count=len(neg)),indent=2)+'\n')
