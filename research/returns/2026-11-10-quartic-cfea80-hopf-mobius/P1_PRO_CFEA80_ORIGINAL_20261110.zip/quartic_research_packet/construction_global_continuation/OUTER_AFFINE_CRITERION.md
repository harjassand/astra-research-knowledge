# Exact all-affine-mean criterion for determinant-one compatible fields

This is a sharp finite-dimensional criterion for the family of actual fields `F=A B(x)` associated with a fixed compatible `B=Df`, `det B=1`, `integral B=I`. It covers every real affine mean A for that field, including singular means. It does **not** establish the criterion for every compatible B and therefore does not resolve full global quasiconvexity.

The generating-function construction and its exact rational polygon integration are proved in `GENERATING_FUNCTION_INTERFACE.md`. Here that construction is used with arbitrary constant output matrix A: `A B=A+D[A(f-x)]` is still an admissible compatible field and has constant determinant `det A`.

## 1. Quadratic metric moments

Let the columns of B be b1,b2. For

\[
C=A^TA=\begin{pmatrix}c_1&c_2\\c_2&c_3\end{pmatrix},\quad
z=(c_1,c_2,c_3)^T,\quad d=\det A,
\]

put

\[
p=(b_{11}^2,2b_{11}b_{21},b_{21}^2)^T,\qquad
q=(b_{12}^2,2b_{12}b_{22},b_{22}^2)^T.
\]

Then the squared column lengths of AB are `u=p dot z`, `v=q dot z`; those of A are `u_A=c1`, `v_A=c3`. Write `e=(1,0,0)^T`, `f=(0,0,1)^T`, and define the exact moments

\[
U=\int pp^T-ee^T,\quad V=\int qq^T-ff^T,
\]
\[
W=\frac12\int(pq^T+qp^T)-\frac12(ef^T+fe^T),
\]
\[
l_1=\int p-e,\qquad l_2=\int q-f.
\]

For fixed k set

\[
R_k=k^2U+2W+V,\qquad l_k=kl_1-l_2.
\]

Expanding the original density, with its determinant retained exactly, gives

\[
\boxed{\frac{8(k+1)}{3k-1}
\left[\int J_k(AB)-J_k(A)\right]
=z^TR_kz+4d\,l_k^Tz.}
\tag{1}
\]

The determinant-squared part cancels because `det(AB)=det A` pointwise. Equation (1) is an identity for the original density, not a replacement by its convex companion.

All moments are finite for `B in L4`. For a rational polygon field they are exact finite rational sums.

## 2. The quotient by output rotations is a two-sphere

By quartic homogeneity, it suffices to consider nonzero A normalized by `|A|^2=tr C=2`. Write

\[
C=\begin{pmatrix}1+x&y\\y&1-x\end{pmatrix}.
\]

The determinant relation `det C=(det A)^2` says

\[
x^2+y^2+d^2=1.
\tag{2}
\]

Conversely every `(x,y,d)` on this unit sphere gives a positive semidefinite C and is realized by a real matrix A with the stated Gram matrix and determinant. Thus every source geometry and both determinant orientations are included.

Put

\[
z_0=(1,0,1)^T,\qquad t_1=(1,0,-1)^T,\quad t_2=(0,1,0)^T,
\]

so `z=z0+x t1+y t2`. Let `v=(x,y,d)^T`. Equation (1) becomes a quadratic polynomial on the sphere:

\[
P_k(v)=v^TM_kv+2h_k^Tv+c_k,\qquad |v|=1,
\tag{3}
\]

where

\[
(M_k)_{ij}=t_i^TR_kt_j\quad(i,j\le2),\qquad
(M_k)_{i3}=(M_k)_{3i}=2l_k^Tt_i,
\quad (M_k)_{33}=0,
\]
\[
(h_k)_i=t_i^TR_kz_0\quad(i\le2),\qquad
(h_k)_3=2l_k^Tz_0,\qquad c_k=z_0^TR_kz_0.
\tag{4}
\]

Every entry is a rational polynomial of degree at most two in k when the original field is rational.

For a general unnormalized A, multiply the normalized value by `(tr(A^TA)/2)^2`. A=0 has gap zero.

### A rational sphere witness needs no square root

For rational `(x,y,d)` on the sphere with `x!=-1`, the rational matrix

\[
\widetilde A=\begin{pmatrix}1+x&y\\0&d\end{pmatrix}
\]

satisfies `Atilde^T Atilde=(1+x)C` and `det Atilde=(1+x)d`. Its reduced gap is exactly `(1+x)^2 P_k(v)`, preserving a strict sign.

Rational points on this sphere are dense by the usual rational stereographic parametrization. Equivalently one can use rational upper-triangular matrices `[[1,s],[0,t]]`; their normalized sphere coordinates are rational functions of s,t. A strict negative on the sphere therefore admits rational matrix data and a directly checked rational negative gap. No real-number oracle is required.

## 3. Sharp support criterion: one scalar translation

**Theorem.** For a fixed B and fixed k, the original inequality holds for every real A if and only if there exists a real scalar tau such that

\[
\boxed{
\mathcal Z_k(\tau)=
\begin{pmatrix}
M_k-\tau I_3&h_k\\
h_k^T&c_k+\tau
\end{pmatrix}\succeq0.}
\tag{5}
\]

This is a necessary and sufficient criterion, not an imposed sufficient ansatz. It is the exact three-dimensional equality-constrained trust-region problem obtained from (3).

### Direct proof, including the hard case

For any tau, the polynomial represented by (5) is

\[
(v,1)^T\mathcal Z_k(\tau)(v,1)
=P_k(v)-\tau(|v|^2-1).
\]

Hence a positive semidefinite matrix (5) is sufficient on the sphere.

For necessity diagonalize the real symmetric M, with eigenvalues `mu_i`, and write h in the same orthonormal basis. For `tau<mu_min`, define

\[
s(\tau)=\sum_i\frac{h_i^2}{(\mu_i-\tau)^2}.
\]

It is continuous, nondecreasing, tends to zero as tau tends to minus infinity, and increases strictly unless h=0. If `s(tau)=1` for some tau below `mu_min`, put

\[
v_* =-(M-\tau I)^{-1}h.
\]

Then `|v_*|=1` and `(M-tau I)v_*=-h`. For every other unit vector v,

\[
P(v)-P(v_*)=(v-v_*)^T(M-\tau I)(v-v_*)\ge0.
\]

If no such tau exists, h is orthogonal to the least eigenspace and

\[
v_0=-(M-\mu_{\min}I)^\dagger h
\]

has norm at most one. Choose a vector in the least eigenspace of length `sqrt(1-|v0|^2)` and add it to v0. This gives a unit vector v* satisfying the same equation with `tau=mu_min`; the same difference identity proves global minimality. This also includes h=0.

In either case,

\[
\min_{|v|=1}P(v)
=c+\tau-h^T(M-\tau I)^\dagger h,
\tag{6}
\]

with `M-tau I>=0` and h in its range. If this minimum is nonnegative, the exact Schur-complement criterion makes (5) positive semidefinite. This proves necessity.

Thus (6), together with the secular equation or the stated hard case, gives an exact minimization formula. The mathematical statement uses no numerical optimization. At rational data, (5) is also a finite univariate semialgebraic feasibility problem: all principal minors are rational polynomials in tau.

If the minimum is strictly positive, tau may be chosen rational with (5) strictly positive definite. In the hard case move tau slightly below the least eigenvalue first; the positive Schur complement persists. Thus strict positive and strict negative outcomes both admit finite rational certificates.

## 4. Parameter reduction and exact interval certificates

For a fixed actual A, the reduced gap is

\[
P_A(k)=\alpha k^2+\beta k+\gamma,
\]

\[
\alpha=\int u^2-u_A^2\ge0,\qquad
\beta=4(\det A)(\int u-u_A),
\]

\[
\gamma=2(\int uv-u_Av_A)+(\int v^2-v_A^2)
-4(\det A)(\int v-v_A).
\]

The signs of alpha and `integral u-u_A` follow from `integral AB=A` and ordinary Jensen. If `det A>=0`, the reduced gap is increasing for positive k, so its worst parameter is the endpoint k=1/3. For negative orientation, the minimum over `[1/3,1]` is at an endpoint or at the scalar quadratic vertex `-beta/(2alpha)` when that point lies in the interval. If alpha=0, then `integral u=u_A`, hence beta=0 as well. At rational field and A data these tests are exact rational calculations. This is minimization of the reduced sign criterion; the positive prefactor in (1) need not have the same minimizing parameter.

The accepted constant-determinant theorem handles k>=1. To certify every mean for the entire remaining interval, choose a constant rational tau on a rational subinterval `[L,R]`. The matrix `Z_k(tau)` is quadratic in k. Its three Bernstein control matrices are

\[
Z_0=Z_L(\tau),\quad Z_2=Z_R(\tau),\quad
Z_1=2Z_{(L+R)/2}(\tau)-\tfrac12(Z_0+Z_2).
\tag{7}
\]

For `k=L+t(R-L)`,

\[
Z_k(\tau)=(1-t)^2Z_0+2t(1-t)Z_1+t^2Z_2.
\]

Therefore exact positive semidefiniteness of the three control matrices proves (5) for every real k in that subinterval. The completed certificates below use strictly positive exact rational LDL pivots, so no interval rounding error or numerical eigenvalue test is a proof step.

## 5. Actual generated fields with all-A, all-k certificates

Two rational fields were checked. Both are the genuine periodic generating-function maps described in the companion interface note; neither is the older 128-triangle finite-element field.

### First field

`generating_positive_exact_input.json` has 2048 polygons and minimum twist `117/256`. Its full arbitrary-A metric moments were computed exactly, combining equal matrices into 910 atoms. The extraction and automatic interval certification took 1.41 seconds.

The especially simple certificate is

\[
\tau=-7/2\qquad\text{on }[1/3,1].
\]

All three control matrices (7) have strictly positive exact rational LDL pivots. The complete moments and rational pivots are in

- `generating_positive_exact_input_outer_mean.moments.json`;
- `generating_positive_exact_input_outer_mean.simple_certificate.json`.

This proves nonnegative original gap for every real A and every k>1/3 for this fixed compatible field, using the accepted constant-determinant theorem beyond k=1.

### Second field, after exploring the new outer-affine freedom

A separate bounded deterministic exploration optimized generating coefficients and k, while eliminating A through (3). To prevent a nearly singular A from trivially annihilating the deformation, the exploratory objective was the reduced gap divided by `integral |A(B-I)|^4`. That denominator is itself a quadratic polynomial on the same sphere. A finite Dinkelbach iteration of trust-region solves supplied candidate minimizing means.

There were four existing generating-function seeds, each with at most 200 outer iterations. Every inner ratio calculation used at most 12 Dinkelbach updates and 70 scalar bisection steps per trust-region candidate, with a 32-step bracket cap. These are finite floating computations and are used only to generate candidates, not as positivity certificates.

The completed runs used 377 outer iterations, 434 objective evaluations and 3733 trust-region candidate solves, taking 7.40 seconds. No negative appeared. The best exploratory quotient was approximately 0.083764. The selected means had negative determinants and were nearly singular; all four k values moved to the lower endpoint. A nontrivial derivative check agreed with the analytic envelope gradient within about 2.5e-11.

The best field was rounded to rational generating coefficients with denominator 4096. Its exact input is `outer_affine_best_exact_input.json`. It has 2048 polygons, 1968 distinct matrix atoms and minimum twist

\[
a_{\min}=109/2048>0.
\]

The following simple supports certify every real A throughout the entire lower parameter interval:

\[
\tau=-62\quad\text{on }[1/3,2/3],\qquad
\tau=-130\quad\text{on }[2/3,1].
\]

All three exact Bernstein matrices on each interval have positive rational LDL pivots. For scale, the smallest pivots on these intervals are approximately 1.517 and 4.814 respectively; the positive signs are established by exact rationals, not these decimal displays. The certificate, with every rational pivot retained, is

- `outer_affine_best_exact_input_outer_mean.moments.json`;
- `outer_affine_best_exact_input_outer_mean.simple_certificate.json`.

Extraction and successful exact certification took 4.13 seconds. An earlier attempt completed the rational arithmetic but stopped while converting a large pivot to decimal text under Python's default digit limit; the replay used an explicit finite 100000-digit serialization cap. This was a serialization issue, not a sign or arithmetic failure. All actual retries and costs are recorded in the session.

The two certificate intervals, followed by the accepted k>=1 result, establish the desired original inequality for this SECOND fixed rational field for all A and all k>1/3. A=0 has gap zero. On the admissible lower interval 1/3<k<=1 the gap is strictly positive for nonzero A. At the excluded endpoint k=1/3 the original prefactor vanishes, so strict positivity is asserted there only for the reduced sign polynomial, not the original gap.

## 6. Reproduction, exactness and unresolved scope

`outer_mean_support.py` reconstructs the actual rational polygon map, computes the five moment tensors, forms (4), and checks rational LDL pivots for (7). Its automatic interval routine has an explicit cap of 256 checks and depth 12. Numeric secular-root calculations only suggest tau; the exact PSD certificate is the proof. A negative numeric candidate is converted to rational field/mean/parameter data and checked using (1) before any negative claim is allowed.

`outer_affine_search.py` contains the bounded four-seed experiment and its finite inner budgets. Its output is retained in `outer_affine_search_results.jsonl`. No installation, external optimization service, extra model, source retrieval or PDE oracle was used.

The criterion (5) is sharp for each fixed determinant-one mean-I compatible field B. The explicit certificates settle two actual fields, not all B, and do not cover arbitrary determinant fluctuations. No construction in this continuation has a negative original-energy gap. The full universal quasiconvexity question remains unresolved.
