from generating_polygons import *
import numpy as np
from scipy.optimize import minimize,LinearConstraint
import time

def rval(F):
 k=1/3;n=4/3
 a,b,c,d=F.T;u=a*a+c*c;v=b*b+d*d;j=a*d-b*c;q=k*u-v+2*j
 val=q*q/(8*n)+u*v/4
 dq=np.array([2*k*a+2*d,-2*b-2*c,2*k*c-2*b,-2*d+2*a]).T
 du=np.array([2*a,np.zeros_like(a),2*c,np.zeros_like(a)]).T
 dv=np.array([np.zeros_like(a),2*b,np.zeros_like(a),2*d]).T
 grad=q[:,None]*dq/(4*n)+(v[:,None]*du+u[:,None]*dv)/4
 return val,grad

class Problem:
 def __init__(self,directions,N):
  self.directions=directions;self.N=N;cells,self.counts=partition(directions,N);self.cells=cells
  self.weights=np.array([float(area(p)) for p,b in cells]);P=len(directions)*(N-1)
  self.B=np.zeros((len(cells),3,P));self.centres=np.array([[float(sum(p[j] for p in poly)/len(poly)) for j in [0,1]] for poly,band in cells])
  for ci,(poly,bands) in enumerate(cells):
   for di,((p,q),band) in enumerate(zip(directions,bands)):
    coeff=np.array([p*p,p*q,q*q]);start=di*(N-1)
    if band<N-1:self.B[ci,:,start+band]+=coeff
    else:self.B[ci,:,start:start+N-1]-=coeff[:,None]
  self.P=P;self.aB=self.B[:,1,:];self.neval=0
 def fields(self,z):
  H=np.einsum('ijp,p->ij',self.B,z);b,h,c=H.T;a=1+h
  F=np.array([1/a,-c/a,b/a,a-b*c/a]).T
  deriv=np.zeros((len(a),4,3))
  deriv[:,:,0]=np.array([np.zeros_like(a),np.zeros_like(a),1/a,-c/a]).T
  deriv[:,:,1]=np.array([-1/a**2,c/a**2,-b/a**2,1+b*c/a**2]).T
  deriv[:,:,2]=np.array([np.zeros_like(a),-1/a,np.zeros_like(a),-b/a]).T
  return H,a,F,deriv
 def objective(self,z,details=False):
  self.neval+=1;H,a,F,DF=self.fields(z)
  if np.min(a)<=0:
   return 1e6+1e6*np.sum(np.minimum(a,0)**2),2e6*self.aB.T@np.minimum(a,0)
  val,grad=rval(F);I=np.array([1.,0,0,1.]);cv,cg=rval(F-I)
  E=np.sum(self.weights*a*val)-5/12;C=np.sum(self.weights*a*cv)
  if C<1e-26:return 1e5,np.zeros(self.P)
  de=a[:,None]*np.einsum('ij,ijk->ik',grad,DF);de[:,1]+=val
  dc=a[:,None]*np.einsum('ij,ijk->ik',cg,DF);dc[:,1]+=cv
  DE=np.einsum('i,ij,ijp->p',self.weights,de,self.B);DC=np.einsum('i,ij,ijp->p',self.weights,dc,self.B)
  ratio=E/C;g=DE/C-E*DC/C**2
  if details:return dict(N=self.N,directions=self.directions,ratio=float(ratio),endpoint_gap=float(E),denominator=float(C),amin=float(min(a)),coefficients=z.tolist(),cell_counts=self.counts,evaluations=self.neval)
  return ratio,g
 def seed(self,pattern):
  # Project the Hessian pattern corresponding to the three-state determinant-one target.
  x,y=self.centres.T;rare=(abs(x-.5)<.06)&(abs(y-.5)<.06)
  scalars=[np.cos(2*np.pi*x),np.cos(2*np.pi*y),np.cos(2*np.pi*(x+y)),np.cos(2*np.pi*(x-y))]
  signs=np.where(scalars[pattern%4]>=0,1.,-1.);target=np.zeros((len(x),3))
  target[:,0]=signs*.004;target[:,1]=1/599;target[:,2]=signs*.0735
  target[rare]=[0.,-1/6,0.]
  W=np.sqrt(self.weights)[:,None,None]
  z=np.linalg.lstsq((self.B*W).reshape(-1,self.P),(target*np.sqrt(self.weights)[:,None]).ravel(),rcond=1e-11)[0]
  if np.linalg.norm(z)<1e-12:z[0]=.1
  # Start at two prescribed amplitude scales; feasibility enforced by scaling.
  z*=1 if pattern<4 else 4
  h=self.aB@z
  if min(h)<-.8:z*=.8/(-min(h))
  return z

def run(directions,N,pattern,steps=400):
 start=time.perf_counter();p=Problem(directions,N);z=p.seed(pattern)
 con=LinearConstraint(p.aB,np.full(len(p.weights),-.95),np.full(len(p.weights),10.))
 init=p.objective(z,True)
 res=minimize(p.objective,z,jac=True,method='SLSQP',constraints=[con],bounds=[(-2.,2.)]*p.P,options={'maxiter':steps,'ftol':1e-11,'disp':False})
 out=p.objective(res.x,True);out.update(pattern=pattern,nit=int(res.nit),success=bool(res.success),message=str(res.message),start_ratio=init['ratio'],seconds=time.perf_counter()-start)
 return out

if __name__=='__main__':
 outpath=pathlib.Path(__file__).with_name('generating_search_results.jsonl')
 with outpath.open('w') as out:
  for directions,N in [([(1,0),(0,1),(1,1),(1,-1)],4), ([(1,0),(0,1),(1,2),(1,-2)],4), ([(1,0),(0,1),(1,1),(1,-1)],8)]:
   for pattern in [0,2,4,6]:
    r=run(directions,N,pattern);out.write(json.dumps(r)+'\n');out.flush()
    print(json.dumps({q:r[q] for q in ['N','directions','pattern','ratio','endpoint_gap','amin','cell_counts','nit','success','evaluations','seconds']}),flush=True)
    if r['endpoint_gap']< -1e-9:
     d=dict(N=N,directions=directions,coefficients=[str(Q(round(z*2**24),2**24)) for z in r['coefficients']]);cert=exact_verify(d)
     pathlib.Path(__file__).with_name('generating_candidate.json').write_text(json.dumps(d,indent=2)+'\n')
     pathlib.Path(__file__).with_name('generating_candidate_certificate.json').write_text(json.dumps(cert,indent=2)+'\n')
     print('EXACT',json.dumps(cert),flush=True)
     if cert['endpoint_negative']:raise SystemExit
