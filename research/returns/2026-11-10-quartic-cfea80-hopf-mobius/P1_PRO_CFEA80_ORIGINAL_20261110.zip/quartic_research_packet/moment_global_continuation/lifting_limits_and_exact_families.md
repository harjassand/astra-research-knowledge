# Exact limits of three stronger lifting targets

These are obstructions to stronger certificates. None is a negative original-energy witness. Fix `k>1/3`, `ell=3k-1`, `n=k+1`, `m=3k+1`, and use the accepted strain S and correction `r_G=integral Dlambda(G) det G`.

## 1. A local pointwise inverse lift is impossible for every k

Let L_G send A to the four unweighted strains. Exact determinant expansion gives

\[
\det L_G=4n(mu+2j)(mv-2kj).
\]

At `G=diag(1,-m/2)`, `S(I,G)=0`, while

\[
DJ_k(G):I=-n\ell/4\ne0.
\]

Thus no pointwise vector z(G) can satisfy `S(.,G)^*z(G)=3DJ_k(G)` there. Compatibility can still permit a nonlocal integrated lift. These identities, including the kernel of `D2J(G)-det(G)D2lambda`, were checked exactly over the rational function field in k.

## 2. The vacant fourth component alone fails on a compatible field

In row-major coordinates, `L4(A,G)=A^T M4 G`, where

\[
M_4=\begin{pmatrix}0&1&-k&0\\-1&0&0&1\\k&0&0&1\\0&-1&-1&0\end{pmatrix}.
\]

Take

\[
\psi=\frac{\cos2\pi x+\cos2\pi y+\cos2\pi(x+y)}{(2\pi)^2},
\qquad G=D^2\psi=D(\nabla\psi).
\]

This is a genuine compatible periodic field. It has `b=c`, and exact moments

\[
\int(\det G)G=\begin{pmatrix}-1/2&-1/4\\-1/4&-1/2\end{pmatrix}.
\]

For `A=diag(2/n,(1-k)/n)`, exact symbolic contraction gives

\[
L_4(A,G)=b-c=0\quad\text{pointwise},\qquad
r_G:A=-\frac{3(5k+1)}{2m}\ne0.
\]

Therefore r_G is not in the range of the fourth-channel Gram matrix N. A correction using only that vacant channel cannot be global. Root independently identified this same compatible triad before the exact verification. Multichannel and nonlocal lifts remain open.

## 3. Determinant energy alone cannot bound the correction

For every positive integer N set

\[
\psi_N=\frac{\cos2\pi(x+Ny)+\cos2\pi(x+2Ny)+\cos2\pi(2x+3Ny)}{(2\pi)^2N^2},
\]

\[
\varphi_N=(\partial_2\psi_N,-\tfrac m2\partial_1\psi_N),\qquad G_N=D\varphi_N.
\]

These are smooth real mean-zero compatible fields. If U,V,W are the three displayed cosines, then

\[
\psi_{xx}=-N^{-2}(U+V+4W),\quad
\psi_{xy}=-N^{-1}(U+2V+6W),\quad
\psi_{yy}=-(U+4V+9W),
\]

and `det D2psi=N^(-2)(UV+UW+VW)`. Exact Laurent constant coefficients give

\[
r_{G_N}:I=-\frac{27n\ell}{16N^3},\qquad
H_{G_N}[I,I]=\frac{9n\ell m^2}{8N^4},\qquad
\int(\det G_N)^2=\frac{3m^2}{16N^4}.
\]

Dual Cauchy-Schwarz implies

\[
\frac{r_{G_N}^T H_{G_N}^\dagger r_{G_N}}{\int(\det G_N)^2}
\ge\frac{27n\ell}{2m^4}N^2\longrightarrow\infty.
\]

Hence no finite k-dependent bound `r^T H^dagger r <= C_k integral(det G)^2` is possible. The successful estimate in `mixed_weighted_minor_estimate.md` instead uses `||G||4^2 ||det G||2`.

All displayed formulas were checked as exact Laurent constant coefficients over Q(k,N). No search or floating approximation entered. The independent phase map `(x,y)->(x+Ny,x+2Ny)` is an integer torus covering, so normalized Haar integration gives the exact independent-phase moments.

## 4. Balanced exact target around the det-squared endpoint

Let K_comp be the supplied convex companion, so `J-lambda det/2=ell K_comp`. Then

\[
\left\|\frac32g_G\right\|_2^2=18c_G+9\ell\int K_{\rm comp}(G),
\]

\[
r_G-\frac12K_G^*g_G
=\frac32(r_G-b_G)
=-\frac32\int[DJ_k(G)-\det G\,D\lambda(G)].
\]

A lift `z=(3/2)g_G+w` would therefore prove the sharp bound if

\[
K_G^*w=\frac32(r_G-b_G),\qquad
\|w\|_2^2+3\langle g_G,w\rangle
\le-9\ell\int K_{\rm comp}(G).
\]

This identifies the required negative cross contribution; a norm-only estimate cannot provide it. No such w has been constructed, and the companion reserve has not been spent to assert the last inequality.

## 5. A concrete Fourier lift and why its norm is not sharp

For a nonaxis frequency `xi=(p,q)`, set

\[
t_1=0,\qquad t_2=\frac{9k}{m^2},\qquad
t_3=\frac{3\ell(kp^2-q^2)}{2m^2pq},\qquad
t_4=\frac{3\ell(kp^2+q^2)}{2m^2pq}.
\]

Exact solution of eight bilinear coefficient equations gives

\[
D\lambda(A)[a\otimes\xi]=\sum_{i=1}^4t_i(\xi)L_i(A,a\otimes\xi)
\quad\text{for every }A,a.
\]

On the source-e2 axis take `t1=3ell n/(4m^2)`, `t2=3(9k+1)/(4m^2)`, `t3=t4=0`. On the source-e1 axis change only the sign of t1. These also solve the coefficient equations exactly.

Let w_i be the four positive weights in the strain factorization and define

\[
\widehat{Z_{r,i}}(\xi)=\frac{t_i(\xi)}{\sqrt{w_i}}
\widehat{\det G}(\xi),\qquad \widehat Z_r(0)=0.
\]

For finite Fourier gradients, Parseval gives `K_G^*Z_r=r_G`. Thus `Z=g_G+Z_r` is a concrete quadratic bilinear Fourier lift of `3b_G`, using finite arithmetic on every fixed Fourier input.

Its norm is not uniformly bounded. Take

\[
p_N=(N,N),\quad q_N=(-N+1,N),
\]

\[
G_N=(e_1\otimes p_N/N)\cos(2\pi p_N\cdot x)
+(e_2\otimes q_N/N)\cos(2\pi q_N\cdot x).
\]

These smooth compatible gradients have uniformly bounded L4 norms. Their Jacobian has Fourier coefficient `(2-1/N)/4` at `p_N+q_N=(1,2N)`. There t3 and t4 grow linearly with N. Hence `||Z_r||2` grows at least linearly while c_G stays bounded. The bounded local term g_G cannot cancel the divergence.

The large output frequency here is absent from G itself and contributes nothing to `K_G^*Z_r`; projection or redistribution can remove that wasted norm. This therefore obstructs the displayed lift's norm, not the minimum-norm lift or all bilinear symbols.

Assigning an entire resonant triad to a single leg is also insufficient. For `k=1`, sources `(1,0),(0,1),(-1,-1)` and first two output vectors e1,e2, the four strain coefficients at the third leg face eight bilinear equations of coefficient rank 4 and augmented rank 5. A genuinely coupled multi-leg redistribution is necessary. No sharp coupled symbol or factorization has been obtained.
