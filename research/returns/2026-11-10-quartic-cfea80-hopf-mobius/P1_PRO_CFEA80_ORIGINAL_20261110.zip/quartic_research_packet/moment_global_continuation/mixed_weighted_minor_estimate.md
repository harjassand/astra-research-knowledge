# Mixed weighted-minor control and a uniform small-Jacobian theorem

This note concerns the ORIGINAL density. It proves a new nonsharp bound on the weighted-minor correction and a uniform positive neighborhood of the pointwise rank-one class. It does not prove the full sharp moment inequality.

Fix `k>1/3`, and write `ell=3k-1`, `n=k+1`, `m=3k+1`, and

\[
\lambda(F)=\frac{3\ell(k|F_{\cdot1}|^2-|F_{\cdot2}|^2)+24k\det F}{2m}.
\]

For a mean-zero compatible periodic `G in L4`, put

\[
r_G=\int D\lambda(G)\det G,\quad
M=\|G\|_4,\quad d_J=\|\det G\|_2.
\]

The accepted strain factorization gives a bilinear `S` with

\[
K_G A=S(A,G),\quad H_G=K_G^*K_G,\quad
g_G=S(G,G),\quad 3b_G=K_G^*g_G+r_G,
\]

\[
\|g_G\|_2^2=12c_G-2q_G,\qquad
q_G=\int\lambda(G)\det G.
\]

## 1. New mixed estimate

There is a finite constant `D_k`, depending only on k, such that

\[
\boxed{|r_G:F|\le D_k\|G\|_4\|\det G\|_2^{1/2}
\sqrt{H_G[F,F]}}
\tag{1}
\]

for every constant real matrix F. Equivalently,

\[
\boxed{r_G^T H_G^\dagger r_G
\le D_k^2\|G\|_4^2\|\det G\|_2.}
\tag{2}
\]

The range condition is included in (1). This is stronger than a coarse quartic bound on `r`, but no sharp value of `D_k` is claimed.

### 1.1 The critical background I

Write

\[
G=\begin{pmatrix}a&b\\c&d\end{pmatrix},\quad
s=\frac m2a+d,\quad \eta=\frac{\ell n}{4},\quad
q_I=\int(s^2+\eta c^2)=\frac12H_G[I,I].
\]

Because the Hessian of lambda is constant,

\[
r_G:I=\frac{3n}{m}\int s\det G
+\frac{3n\ell}{2m}\int a\det G.
\tag{3}
\]

The already proved compatible scalar interpolation and Fourier square completion give

\[
\|a\|_{8/3}^2\le C_k M\sqrt{q_I},\qquad
\|R_1a\|_2\le C_k\sqrt{q_I}.
\tag{4}
\]

Only the weighted product `integral a det G` needs a new estimate.

### 1.2 Angular decomposition

For `0<delta<=1`, let `P_delta` have Fourier multiplier

\[
p_\delta(\xi)=\frac{\delta^2\xi_2^2}{\xi_1^2+\delta^2\xi_2^2},
\]

with its zero mode set to zero. Let `a_lo=P_delta a` and `a_hi=a-a_lo`.

Compatibility gives `xi2 a_hat=xi1 b_hat`, hence exactly

\[
a_{\rm lo}=\delta M_\delta b,\qquad
m_\delta(\xi)=\frac{\delta\xi_1\xi_2}{\xi_1^2+\delta^2\xi_2^2}.
\]

The supplied sharp L4 Beurling-Ahlfors bound, with the cutoff argument below, gives

\[
\|M_\delta\|_{L^4\to L^4}\le\frac32
\quad\text{uniformly for }0<\delta\le1.
\tag{5}
\]

On the plane, the anisotropically conjugated Beurling operator has multiplier

\[
\mathcal B_\delta(\xi)=\frac{\xi_1-i\delta\xi_2}{\xi_1+i\delta\xi_2}.
\]

An invertible linear change in the plane conjugates this operator to the usual Beurling transform; its two L4 scaling factors cancel. Thus its L4 norm is at most the supplied sharp value 3. Since `m_delta` is minus one half of the imaginary part of this symbol, or equivalently one quarter of the difference between this operator and its complex-conjugate multiplier, the plane norm of M_delta is at most 3/2, uniformly in delta.

Here is the periodic passage, so no changed source lattice is assumed. For a finite mean-zero trigonometric polynomial f on the original unit torus, take a nonzero Schwartz cutoff chi and consider `chi(x/R) f(x)` on the plane. At each of its finitely many nonzero Fourier frequencies nu, continuity of m_delta at nu and Fourier inversion give

\[
M_\delta[\chi(\cdot/R)e^{i\nu\cdot x}]
-m_\delta(\nu)\chi(\cdot/R)e^{i\nu\cdot x}
=o(R^{1/2})\quad\text{in }L^4(\mathbb R^2).
\]

Explicitly, after changing Fourier variables to eta/R, the multiplier difference is `m_delta(nu+eta/R)-m_delta(nu)`. Dominated convergence against `|chi_hat|` gives an o(1) L-infinity bound, and against `|chi_hat|^2` gives an o(R) L2 bound. Interpolating these two elementary bounds gives the stated o(R^(1/2)) L4 error. Periodic averaging also gives

\[
R^{-2}\|\chi(\cdot/R)f\|_4^4
\longrightarrow\|\chi\|_{L^4(\mathbb R^2)}^4\|f\|_{L^4(\mathbb T^2)}^4,
\]

and the same holds for the finite torus multiplier output. Apply the plane norm bound, divide by R^(1/2), and pass to the limit. This proves (5) on finite polynomials; density proves it on L4. The approximation may depend on delta, but the final 3/2 bound does not. Only the original torus frequencies appear.

Alternatively the product-Marcinkiewicz hypotheses can be checked directly by writing `m_delta=f(t)`, `t=xi1/(delta xi2)`, `f(t)=t/(1+t^2)`: its symbol and weighted derivatives `t f'(t)` and `-t f'(t)-t^2 f''(t)` have uniform bounds. This alternative is not needed for the proof above.

Consequently,

\[
\|a_{\rm lo}\|_4\le C\delta M.
\tag{6}
\]

The complementary multiplier obeys the elementary pointwise estimate

\[
\frac{\xi_1^2}{\xi_1^2+\delta^2\xi_2^2}
\le\frac1\delta\frac{|\xi_1|}{|\xi|}.
\]

After squaring, this reduces to
`(1-delta^2)xi1^4+delta^2 xi1^2 xi2^2+delta^4 xi2^4>=0`. Parseval and (4) give

\[
\|a_{\rm hi}\|_2\le C_k\delta^{-1}\sqrt{q_I}.
\tag{7}
\]

### 1.3 Paying the weighted product

The high part satisfies

\[
\left|\int a_{\rm hi}\det G\right|
\le C_k\delta^{-1}d_J\sqrt{q_I}.
\]

For the low part use the exact identity

\[
\det G=as-\frac m2a^2-bc.
\]

The first and last products use Holder with exponents `(4,4,2)`. For the middle one,

\[
\int|a_{\rm lo}|a^2
\le\|a_{\rm lo}\|_4\|a\|_{8/3}^2
\le C_k\delta M^2\sqrt{q_I}.
\]

Therefore

\[
\left|\int a\det G\right|
\le C_k(\delta M^2+\delta^{-1}d_J)\sqrt{q_I}.
\tag{8}
\]

If `d_J=0`, the weighted product is zero. Otherwise choose

\[
\delta=\frac{\sqrt{d_J}}M\le\frac1{\sqrt2},
\]

using `|det G|<=|G|^2/2`. Equation (8) becomes

\[
\left|\int a\det G\right|
\le C_k M\sqrt{d_J}\sqrt{q_I}.
\]

Also `|integral s det G|<=d_J sqrt(q_I)<=M sqrt(d_J) sqrt(q_I)/sqrt(2)`. Equation (3) proves (1) at I.

### 1.4 The second critical orbit and general means

At `B_k=[[0,k],[1,0]]`, put `s_B=(m/2)b+kc`. Direct algebra gives

\[
r_G:B_k=-\frac{3n}{m}\int s_B\det G
-\frac{3n\ell}{2m}\int b\det G,
\]

\[
q_B=\int(s_B^2+\eta d^2)=\tfrac12H_G[B_k,B_k].
\]

Use the coordinate-swapped angular split of b and the identity

\[
\det G=ad-\frac1kbs_B+\frac{m}{2k}b^2.
\]

The accepted coordinate-swapped scalar interpolation pays the `b^3` term; the others contain the explicit energy factors d or s_B. This proves (1) at B_k on the original torus.

Near either critical orbit, use the accepted acoustic normal forms. For example, after output QR normalization `F=rho Q(I+D)`, `|D|=d_F`, and `V=Q^T G`,

\[
H_G[F,F]\ge c_k\rho^2[H_V[I,I]+d_F^2\|V\|_2^2].
\]

Left rotation invariance of lambda gives `r_(Q^T G)=Q^T r_G`. Thus `r_G:F=rho(r_V:I+r_V:D)`. The critical estimate pays the first term. The remainder satisfies

\[
|r_V:D|\le\|D^2\lambda\|d_F\|V\|_2 d_J
\le C_kd_F\|V\|_2 M\sqrt{d_J},
\]

which is paid by the transverse term in the same acoustic normal form. Combine the two contributions by ordinary two-dimensional Cauchy-Schwarz against `sqrt(H_V[I,I]+d_F^2||V||2^2)`. In the B_k neighborhood write `F=rho Q(I+D)B_k`; its perturbation is `r_V:D B_k`, bounded in the same way using `|D B_k|<=max(1,k)|D|`. Outside those two neighborhoods, compact normalized affine backgrounds are uniformly acoustically elliptic, so the elementary bound `|r_G:F|<=C|F| ||G||2 d_J` proves (1). Homogeneity covers all F.

The proof is uniform in Fourier support, amplitude, source orientation and concentration. For the final L4 passage choose compatible Fejer approximations G_N converging strongly to G in L4. Their determinants converge in L2 by the bilinear determinant estimate; the cubic r moments and quadratic H moments therefore converge as well. For each fixed F, pass to the limit in (1), without any continuity assertion for the pseudoinverse. This proves the claim for every stated W1,4 potential. No optimization or PDE oracle is involved.

## 2. A uniform small-Jacobian theorem for the original density

Set

\[
\mu_k=\frac{\ell\min(k^2,1)}{4(5k+1)},\qquad
\Lambda_k=\frac{3\ell\max(k,1)+12k}{2m}.
\]

The elementary pointwise bounds

\[
J_k(F)\ge\mu_k|F|^4,\qquad
|\lambda(F)|\le\Lambda_k|F|^2
\tag{9}
\]

give `c>=mu_k M^4` and `|q|<=Lambda_k M^2 d_J`.

For the first inequality, minimize
`[ell/(8n)](ku-v+2j)^2+j^2` over the scalar j. It is at least
`[ell/(4(5k+1))](ku-v)^2`. Adding `ell uv/4` gives

\[
J_k(F)\ge\frac\ell{4(5k+1)}(k^2u^2+v^2+muv)
\ge\mu_k(u+v)^2.
\]

Let

\[
z=g_G+K_GH_G^\dagger r_G.
\]

This z is a feasible lift, not an assertion about the least-norm lift: `K_G^*z=3b_G`. The triangle inequality first gives the global quantitative estimate

\[
\inf_A\Delta_G(A)\ge
c_G-\frac1{18}\left[\sqrt{12c_G-2q_G}+D_kM\sqrt{d_J}\right]^2
\]

\[
\ge c_G-\frac1{18}\left[\sqrt{12c_G+2\Lambda_kM^2d_J}
+D_kM\sqrt{d_J}\right]^2.
\tag{10a}
\]

For nonzero G put `rho=d_J/M^2`. Using `c_G>=mu_k M^4` gives

\[
\frac{\inf_A\Delta_G(A)}{c_G}\ge
1-\frac1{18}\left[
\sqrt{12+\frac{2\Lambda_k\rho}{\mu_k}}
+\frac{D_k}{\sqrt{\mu_k}}\sqrt\rho
\right]^2.
\tag{10b}
\]

This recovers the exact c_G/3 reserve at rho=0 and gives a uniform modulus for its loss. The right side has not been shown nonnegative for all admissible rho; it is not a full proof. The following simpler threshold uses the same single feasible lift and reserve. By (2), the exact norm of g, and weighted Young,

\[
\begin{aligned}
\|z\|_2^2
&\le\frac54\|g_G\|_2^2
+5\|K_GH_G^\dagger r_G\|_2^2\\
&\le15c_G+\left(\frac52\Lambda_k+5D_k^2\right)M^2d_J.
\end{aligned}
\]

Define

\[
\delta_k^{\rm Jac}
=\frac{\mu_k}{(5/2)\Lambda_k+5D_k^2}>0.
\]

If

\[
\boxed{\|\det G\|_2\le\delta_k^{\rm Jac}\|G\|_4^2,}
\tag{10}
\]

then `||z||2^2<=16c_G`. Since the minimum-norm lift has norm squared `9 b_G^T H_G^dagger b_G`,

\[
b_G^TH_G^\dagger b_G\le\frac{16}{9}c_G.
\]

Consequently the ORIGINAL all-mean energy gap satisfies

\[
\boxed{\int J_k(A+G)-J_k(A)\ge\frac19c_G
\quad\text{for every real }A.}
\tag{11}
\]

This criterion depends only on the relative Jacobian size. It is not restricted to one source direction, fixed output direction, finite Fourier bandwidth, small amplitude or bounded affine means.

## 3. Why this still does not close the full endpoint

Every compatible field has `integral det G=0`, but that does not force the L2 determinant in (10) to be small. Scaling one output row preserves compatibility and enters (10) near the rank-one endpoint. Although the energy along that row scaling is convex for each fixed mean, its derivative at the endpoint is a nonconstant weighted row-work term. Convexity therefore does not propagate the Jensen inequality from the endpoint to all row scales.

Likewise a direct-method minimizer argument for the original integral cannot assume weak lower semicontinuity: that property is the very quasiconvexity issue being investigated. A relaxed gradient Young measure can retain determinant fluctuations away from (10). No supplied estimate forces a negative extremizer, if one exists, into the small-Jacobian class or the one-direction neighborhood.

The sharp unresolved target remains `||z_min||2^2<=18c_G` without condition (10). The new estimate (2) pays a mixed correction but does not control its sharp cross term against the full available strain reserve for arbitrary determinant fluctuations.

## 4. Review and cost

The construction principal independently checked the angular multiplier identity, its uniform bounds, all Holder exponents, the optimizing delta, the transverse acoustic reserve, the explicit cutoff transfer, the coercivity and lambda constants, and the final feasible-lift allocation giving c/9. Root suggested the supplied Beurling norm plus the explicit cutoff passage above, which removes any need for a new multiplier-source dependency. The argument uses the accepted scalar interpolation and acoustic normal forms at their stated scopes. No numerical optimization, installation, external resource, or approximation algorithm is a proof step. The constants depend only on k; they are finite analytical constants, and no sharp numerical value of D_k is claimed.
