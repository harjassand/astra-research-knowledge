"""Finite exact checks for the new lifting calculations; no optimizer or sampling."""
import sympy as sp

k, N = sp.symbols('k N', positive=True)
a, b, c, d, A, B, C, D = sp.symbols('a b c d A B C D', real=True)
ell, n, m = 3*k-1, k+1, 3*k+1
eta = ell*n/4
gv, av = sp.Matrix([a,b,c,d]), sp.Matrix([A,B,C,D])
u, v, j = a*a+c*c, b*b+d*d, a*d-b*c
J = ell*(k*u-v+2*j)**2/(8*n)+ell*u*v/4+j*j
lam = (3*ell*(k*u-v)+24*k*j)/(2*m)
Hl = sp.hessian(lam, gv)
DJ = sp.Matrix([sp.diff(J,x) for x in gv])

def zero(expr):
    assert sp.factor(expr) == 0

sigma = m*a/2+d
sigmaB = m*b/2+k*c
zero((sp.Matrix([1,0,0,1]).T*Hl*gv)[0]
     -(3*n/m)*sigma-(3*n*ell/(2*m))*a)
zero((sp.Matrix([0,k,1,0]).T*Hl*gv)[0]
     +(3*n/m)*sigmaB+(3*n*ell/(2*m))*b)

def det(x,y):
    return x[0]*y[1]-x[1]*y[0]

x,y,h,l = sp.Matrix([A,C]),sp.Matrix([B,D]),sp.Matrix([a,c]),sp.Matrix([b,d])
d11,d12,d21,d22=x.dot(h),x.dot(l),y.dot(h),y.dot(l)
c11,c12,c21,c22=det(x,h),det(x,l),det(y,h),det(y,l)
Ls=sp.Matrix([
    c12+c21-3*k*d11-3*d22,
    ell*(k*d11-d22)+(5*k+1)*(c12-c21),
    d12+c22+k*c11+d21,
    d12+c22-k*c11-d21,
])
LM=Ls.jacobian(av)
zero(LM.det()-4*n*(m*u+2*j)*(m*v-2*k*j))
M4=sp.Matrix([[sp.diff(Ls[3],aa,gg) for gg in gv] for aa in av])
Az=sp.Matrix([2/n,0,0,(1-k)/n])
zero((Az.T*M4*gv)[0]-(b-c))
mom=sp.Matrix([-sp.Rational(1,2),-sp.Rational(1,4),-sp.Rational(1,4),-sp.Rational(1,2)])
zero((Az.T*Hl*mom)[0]+3*(5*k+1)/(2*m))

sub={a:1,b:0,c:0,d:-m/2}
localM=sp.hessian(J,gv)-j*Hl
for component in localM.subs(sub)*sp.Matrix([1,0,0,1]):
    zero(component)
zero((DJ[0]+DJ[3]).subs(sub)+n*ell/4)

z,w=sp.symbols('z w', nonzero=True)
U,V,W=(z+1/z)/2,(w+1/w)/2,(z*w+1/(z*w))/2
pxx=-(U+V+4*W)/N**2
pxy=-(U+2*V+6*W)/N
pyy=-(U+4*V+9*W)
aa,bb,cc,dd=pxy,pyy,-m*pxx/2,-m*pxy/2
jj=sp.expand(aa*dd-bb*cc)

def avg(expr):
    return sp.expand(expr).coeff(z,0).coeff(w,0)

rI=sp.factor(3*n*ell/(2*m)*avg(aa*jj))
HI=sp.factor(2*eta*avg(cc*cc))
j2=sp.factor(avg(jj*jj))
zero(rI+27*n*ell/(16*N**3))
zero(HI-9*n*ell*m*m/(8*N**4))
zero(j2-3*m*m/(16*N**4))
zero(rI*rI/(HI*j2)-27*N*N*n*ell/(2*m**4))

# Explicit quadratic Fourier correction: nonaxis and both source axes.
px,py,h1,h2=sp.symbols('px py h1 h2', nonzero=True)
rankone=sp.Matrix([h1*px,h1*py,h2*px,h2*py])
coeff=sp.Matrix([0,9*k/m**2,
    3*ell*(k*px**2-py**2)/(2*m**2*px*py),
    3*ell*(k*px**2+py**2)/(2*m**2*px*py)])
subwave=dict(zip(gv,rankone))
zero((av.T*Hl*rankone)[0]-(coeff.T*Ls.subs(subwave, simultaneous=True))[0])
kap,nu=3*ell*n/(4*m**2),3*(9*k+1)/(4*m**2)
for rankone,sgn in [(sp.Matrix([h1,0,h2,0]),-1),
                     (sp.Matrix([0,h1,0,h2]),1)]:
    subwave=dict(zip(gv,rankone))
    zero((av.T*Hl*rankone)[0]
         -(sgn*kap*Ls[0]+nu*Ls[1]).subs(subwave, simultaneous=True))

print('PASS: critical r identities, local strain range obstruction, fourth-channel')
print('range obstruction, anisotropic determinant-only obstruction, and explicit')
print('Fourier correction symbols are exact.')
