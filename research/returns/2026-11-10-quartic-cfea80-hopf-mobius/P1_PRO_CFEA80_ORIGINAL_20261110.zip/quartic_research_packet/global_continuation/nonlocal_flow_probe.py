"""Bounded diagnostic of nonlocal linear-flow dissipation on saved compatible fields.
This is not a quasiconvexity counterexample search. Floating results are candidates only.
"""
from pathlib import Path
import sys,json,time
import numpy as np
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'variational'))
from fourier_search import data

def probe(row,kind):
    nf=row['nfreq'];N=4*nf+1
    xx=np.arange(N)/N;x,y=np.meshgrid(xx,xx,indexing='ij')
    pts=np.array([x.ravel(),y.ravel()]).T
    G=np.zeros((len(pts),4));LG=G.copy();z=np.array(row['z'])
    for i,q0 in enumerate(row['modes']):
        q=np.array(q0);norm=np.linalg.norm(q);arg=2*np.pi*pts@q
        lam=norm if kind=='poisson' else np.abs(q).sum()
        for t,trig in enumerate((np.cos(arg),np.sin(arg))):
            for r in range(2):
                v=trig[:,None]*q[None,:]/norm*z[4*i+2*t+r]
                G[:,2*r:2*r+2]+=v;LG[:,2*r:2*r+2]+=lam*v
    def diss(A):
        _,dj=data(G+np.asarray(A),row['k'])
        return float(np.mean(np.sum(dj*LG,axis=1)))
    zero=np.zeros(4);c=diss(zero);b=np.zeros(4);H=np.zeros((4,4));plus=[]
    for i in range(4):
        e=np.eye(4)[i];p=diss(e);m=diss(-e)
        plus.append(p);b[i]=(p-m)/2;H[i,i]=p+m-2*c
    for i in range(4):
        for j in range(i+1,4):
            H[i,j]=H[j,i]=diss(np.eye(4)[i]+np.eye(4)[j])-plus[i]-plus[j]+c
    ev=np.linalg.eigvalsh(H)
    A=-np.linalg.pinv(H,rcond=1e-11)@b
    original=float(np.mean(data(G,row['k'])[0]))
    return dict(kind=kind,k=row['k'],nfreq=nf,mean=A.tolist(),
                dissipation=diss(A),normalized=diss(A)/original,eigen=ev.tolist(),
                original_gap=float(np.mean(data(G+A,row['k'])[0])-data(A[None,:],row['k'])[0][0]))

if __name__=='__main__':
    start=time.perf_counter();out=[]
    for source in ('search_results.jsonl','search_results_large.jsonl'):
        rows=[json.loads(x) for x in (ROOT/'variational'/source).read_text().splitlines()]
        for i,row in enumerate(rows):
            for kind in ('poisson','coordinate_poisson'):
                result=probe(row,kind);result.update(source=source,index=i)
                out.append(result)
    target=Path(__file__).with_name('nonlocal_flow_probe_results.json')
    target.write_text(json.dumps({'seconds':time.perf_counter()-start,'results':out},indent=2)+'\n')
    for kind in ('poisson','coordinate_poisson'):
        best=min((r for r in out if r['kind']==kind),key=lambda r:r['normalized'])
        print(json.dumps(best))
    print(json.dumps({'fields':len(out)//2,'generator_checks':len(out),'seconds':time.perf_counter()-start}))
