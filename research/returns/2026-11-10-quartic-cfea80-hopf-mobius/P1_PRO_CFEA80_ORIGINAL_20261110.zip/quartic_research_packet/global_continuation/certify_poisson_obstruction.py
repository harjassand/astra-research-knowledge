#!/usr/bin/env python3
"""Exact certificate for a Poisson-flow obstruction, NOT a QC negative.

The input is a rational Fourier potential in the format of exact_fourier_gap.py.
We use the generator with symbol |q|, i.e. |D|/(2*pi).  Rational interval
bounds for square roots certify the sign of integral DJ(A+G):|D|G/(2*pi).
The original quasiconvexity gap is also calculated exactly and separately.
"""
from pathlib import Path
from fractions import Fraction as Q
from math import isqrt
import json, sys, time

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'variational'))
from exact_fourier_gap import add, scale, mul, sq, const, density, ZERO, verify

def gradient_density(F, k):
    a,b,c,d = F
    u=add(sq(a),sq(c)); v=add(sq(b),sq(d))
    j=add(mul(a,d),scale(mul(b,c),-1))
    h=add(add(scale(u,k),scale(v,-1)),scale(j,2))
    du=[scale(a,2),{},scale(c,2),{}]
    dv=[{},scale(b,2),{},scale(d,2)]
    dj=[d,scale(c,-1),scale(b,-1),a]
    ell=3*k-1; n=k+1
    result=[]
    for i in range(4):
        dh=add(add(scale(du[i],k),scale(dv[i],-1)),scale(dj[i],2))
        term=scale(mul(h,dh),ell/(4*n))
        term=add(term,scale(add(mul(v,du[i]),mul(u,dv[i])),ell/4))
        result.append(add(term,scale(mul(j,dj[i]),2)))
    return result

def certificate(data):
    start=time.perf_counter()
    k=Q(data['k']); F=[const(Q(x)) for row in data['A'] for x in row]
    modes=[]
    for term in data['modes']:
        q=tuple(term['q']); minus=(-q[0],-q[1]); V=[]
        alpha=list(map(Q,term['alpha'])); beta=list(map(Q,term['beta']))
        for i in range(2):
            for j in range(2):
                z=(alpha[i]*q[j]/2,beta[i]*q[j]/2)
                V.append({q:z,minus:(z[0],-z[1])} if z!=ZERO else {})
        F=[add(f,v) for f,v in zip(F,V)]
        modes.append((q,V))
    dj=gradient_density(F,k)
    euler={}
    for x,y in zip(dj,F):
        euler=add(euler,mul(x,y))
    assert euler==scale(density([F[:2],F[2:]],k),4)
    radical={}; contributions=[]
    for q,V in modes:
        coefficient=Q(0)
        for x,y in zip(dj,V):
            z=mul(x,y).get((0,0),ZERO)
            assert z[1]==0
            coefficient+=z[0]
        norm2=q[0]**2+q[1]**2
        factor=1
        for t in range(isqrt(norm2),1,-1):
            if norm2%(t*t)==0:
                factor=t; norm2//=t*t; break
        radical[norm2]=radical.get(norm2,Q(0))+factor*coefficient
        contributions.append({'q':q,'coefficient':str(coefficient)})
    denominator=10**8; lower=Q(0); upper=Q(0); intervals=[]
    for rad,coefficient in sorted(radical.items()):
        floor=isqrt(rad*denominator**2)
        lo=Q(floor,denominator)
        hi=lo if floor*floor==rad*denominator**2 else Q(floor+1,denominator)
        lower+=coefficient*(lo if coefficient>=0 else hi)
        upper+=coefficient*(hi if coefficient>=0 else lo)
        intervals.append({'radicand':rad,'coefficient':str(coefficient),
                          'sqrt_lower':str(lo),'sqrt_upper':str(hi)})
    result={'purpose':'Poisson-flow obstruction; not a quasiconvexity counterexample',
            'generator_symbol':'sqrt(q1^2+q2^2)',
            'original_energy':verify(data),'radical_terms':intervals,
            'dissipation_lower':str(lower),'dissipation_upper':str(upper),
            'dissipation_upper_is_negative':upper<0,
            'energy_initially_increases':upper<0,
            'mode_contributions':contributions,
            'elapsed_seconds':time.perf_counter()-start,
            'arithmetic':'exact Fraction Laurent convolution and integer square-root enclosures'}
    assert Q(result['original_energy']['gap'])>0
    assert upper<0
    return result

if __name__=='__main__':
    source=Path(sys.argv[1])
    result=certificate(json.loads(source.read_text()))
    target=source.with_name(source.stem+'_certificate.json')
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({key:result[key] for key in
        ['original_energy','dissipation_lower','dissipation_upper',
         'energy_initially_increases','elapsed_seconds']},indent=2))
