# Bounded acoustic assessment of the nonlinear flow

At k=1, V=J+sigma W with `W=|F|^4-4(det F)^2`. This note records an exact algebraic reduction at sigma=3/8 and sigma=1/2. It does not prove global acoustic positivity or produce a negative single-wave witness.

For a compatible single-wave second jet, the entropy reduces to

\[
a^T\operatorname{sym}(Q_J(F,\xi)Q_V(F,\xi))a.
\]

A two-form pullback vanishes on such a jet because B1 and B2 are proportional. A negative value would therefore obstruct the corresponding flow certificate independently of the chosen closed form.

Write `A=Q_J` and `C=Q_W`. For 2-by-2 symmetric matrices, direct algebra gives

\[
\det\operatorname{sym}(A(A+\sigma C))
=\det A\det(A+\sigma C)-\frac{\sigma^2}{4}[A,C]_{12}^2.
\tag{1}
\]

Because J is rank-one convex and V is convex in the tested interval, both A and A+sigma C are positive semidefinite. Their product has nonnegative trace, so the determinant in (1) decides positive semidefiniteness of its symmetric part.

Constant left output rotation and homogeneity reduce the nondegenerate case to

\[
F=\begin{pmatrix}1&b\\0&d\end{pmatrix},\qquad \xi=(r,1).
\]

The exact entries of `2 Q_J` are

\[
\begin{aligned}
L_{11}={}&b^2r^2+3b^2-4bdr+4br+7d^2r^2+d^2
+6dr^2-2d+3r^2+1,\\
L_{12}={}&2b^2r-6bdr^2+2bd-2br^2-2b-2d^2r+8dr+2r,\\
L_{22}={}&7b^2r^2+b^2+4bdr-12br+d^2r^2+3d^2
+2dr^2-6d+r^2+7.
\end{aligned}
\]

For W, a compact exact formula is

\[
Q_W=4(1+b^2+d^2)(1+r^2)I
+8\binom{r+b}{d}\binom{r+b}{d}^{T}
-8\binom{dr}{1-br}\binom{dr}{1-br}^{T}.
\]

Substitution into (1) and exact symbolic factorization was performed for sigma=3/8 and 1/2. The returned polynomials did not factor into a manifest nonnegative expression; they are retained in `acoustic_det_3_8.txt` and `acoustic_det_1_2.txt`. No negative sign witness or SOS decomposition was extracted. The single symbolic calculation took 5.203 seconds and used no optimization or sampling.

The diagonal-background/source-axis restriction used for the exact DSOS obstruction is itself nonnegative:

\[
\operatorname{div}DJ\cdot\operatorname{div}DV
=\sigma(a^2-d^2)^2+(\tfrac14+\sigma)(a-d)^4\ge0.
\]

Thus the DSOS obstruction is a basis restriction, not an acoustic failure. The general single-wave question for these target sigma values remains undecided by this bounded calculation.
