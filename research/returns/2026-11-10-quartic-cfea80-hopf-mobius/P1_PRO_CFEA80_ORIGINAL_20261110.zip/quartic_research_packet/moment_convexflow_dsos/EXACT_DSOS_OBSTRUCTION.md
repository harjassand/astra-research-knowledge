# Exact obstruction to this DSOS monomial basis

This is not a failure of the proposed nonlinear entropy or of a general SOS/two-form certificate. It is an exact obstruction to diagonal dominance in the specified 60-monomial basis.

At k=1 let `V=J+sigma W`, with `W=(u+v)^2-4j^2`. Choose

\[
F=\operatorname{diag}(a,d),\qquad
\varphi_{1,22}=1,
\]

and set the other five second jets to zero. Then `B1=0`, so every two-form pullback vanishes, regardless of its coefficients or closedness. Direct differentiation gives

\[
\operatorname{div}DJ=(\tfrac12(a-d)^2,0),
\]

\[
\operatorname{div}DV=(\tfrac12(a-d)^2+4\sigma(a^2+d^2),0).
\]

The restricted entropy therefore is

\[
P(a,d)=(a-d)^2\left[(\tfrac14+2\sigma)(a^2+d^2)-\tfrac12ad\right].
\]

Its coefficients satisfy

\[
[a^4]P+\tfrac12[a^3d]P
=(\tfrac14+2\sigma)+\tfrac12(-1-4\sigma)
=-\tfrac14.
\tag{1}
\]

In the DSOS basis only the three monomials `a^2,ad,d^2` survive on this restriction. For a nonnegative combination of their squares and pairwise sum/difference squares, the linear coefficient functional

\[
\mathcal L(P)=[a^4]P+\tfrac12[a^3d]P
\]

is nonnegative on every allowed square: its value is 1 on `(a^2)^2`, 2 on `(a^2+ad)^2`, 0 on `(a^2-ad)^2`, 1 on `(a^2 +/- d^2)^2`, and 0 on the other surviving squares. All vanished monomials give zero or these same nonnegative values. This contradicts (1), independently of sigma.

## Exact matrix certificate

The LP preprocessing multiplied the entropy by 4. In its saved row ordering the two relevant rows are

- row725: `F0^4 * jet2^2`;
- row662: `F0^3 F3 * jet2^2`.

Take the integer dual vector with entries `y725=2`, `y662=1`, and all others zero. Exact integer multiplication against the retained coefficient matrix gives

\[
y^TA_{\rm squares}\ge0,\qquad
y^TA_{\rm forms}=0,\qquad
y^TA_{\sigma}=0,\qquad y^Tb=-2.
\]

The square-column pairings lie between 0 and 4. Thus the LP is exactly infeasible, including every `sigma in [1/4,3/4]`, and in fact independently of the sigma bound. The sparse rational certificate is saved in `exact_dsos_infeasibility.json`.

## Why this is not an acoustic obstruction

The very same restricted polynomial has the ordinary SOS identity

\[
P(a,d)=\sigma(a^2-d^2)^2+(\tfrac14+\sigma)(a-d)^4.
\]

It is nonnegative for all sigma in the tested interval. Its second square uses the three-term quadratic `a^2-2ad+d^2`, which the restricted pairwise DSOS cone does not accommodate. General SOS Gram matrices, another polynomial basis, or a different certificate remain outside this exclusion.

## Paid computation

Exactly one floating feasibility LP was run, with installed SciPy 1.17.0/HiGHS dual simplex, a 60-second and 10000-iteration cap, under an external 180-second whole-script cap. It included 735 exact polynomial equations, 3600 nonnegative square variables, 140 free closed-form variables, and one bounded sigma variable. Exact preprocessing took 0.244 seconds; the LP returned infeasible in 0.0197 seconds during presolve, with zero simplex iterations. The whole script took 0.264 seconds. The two-row integer certificate was then checked directly against the saved matrix without another optimization call.
