"""One bounded DSOS LP for k=1, V=J+sigma W, 1/4<=sigma<=3/4.

Exact polynomial preprocessing; one installed SciPy/HiGHS solve with a
60-second/10000-iteration cap; external whole-script cap 180 seconds.
"""
import json, time
from collections import defaultdict
from fractions import Fraction
from pathlib import Path
import numpy as np
import scipy
from scipy.optimize import linprog
from scipy.sparse import coo_matrix, save_npz
import sympy as sp

started=time.perf_counter();root=Path(__file__).resolve().parent
receipt={'task':'k=1,V=J+sigma W, degree4 closed two-form, DSOS',
 'solver':'scipy.optimize.linprog/highs-ds','scipy_version':scipy.__version__,
 'sympy_version':sp.__version__,'lp_time_limit_seconds':60,
 'lp_max_iterations':10000,'whole_script_external_limit_seconds':180,
 'sigma_bounds':['1/4','3/4'],'lp_calls':0}
def checkpoint():
 receipt['elapsed_seconds']=time.perf_counter()-started
 (root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def mons(total,n=4):
 if n==1: yield (total,)
 else:
  for first in range(total+1):
   for rest in mons(total-first,n-1):yield (first,)+rest

f=sp.symbols('f0:4')
u=f[0]**2+f[2]**2;v=f[1]**2+f[3]**2;j=f[0]*f[3]-f[1]*f[2]
J=(u-v+2*j)**2/8+u*v/2+j*j
W=(u+v)**2-4*j*j
HJ,HW=sp.hessian(J,f),sp.hessian(W,f)
B1=(0,1,3,4);B2=(1,2,4,5)
f2=list(mons(2));f4=list(mons(4))
mbasis=[(a,t) for a in f2 for t in range(6)]
rows=[(a,(s,t)) for a in f4 for s in range(6) for t in range(s,6)]
row_index={key:i for i,key in enumerate(rows)}
def div_coeff(H,row):
 d=defaultdict(lambda:sp.S.Zero)
 for i in range(4):
  for mon,coef in sp.Poly(H[2*row,i],*f).terms():d[(mon,B1[i])]+=coef
  for mon,coef in sp.Poly(H[2*row+1,i],*f).terms():d[(mon,B2[i])]+=coef
 return {key:val for key,val in d.items() if val}
E0,E1=defaultdict(lambda:sp.S.Zero),defaultdict(lambda:sp.S.Zero)
for row in range(2):
 a,b=div_coeff(HJ,row),div_coeff(HW,row)
 for (fa,sa),ca in a.items():
  for target,right in [(E0,a),(E1,b)]:
   for (fb,sb),cb in right.items():
    key=(tuple(x+y for x,y in zip(fa,fb)),tuple(sorted((sa,sb))))
    target[key]+=ca*cb
den=sp.ilcm(*[sp.denom(z) for z in list(E0.values())+list(E1.values())])
rhs=np.array([int(den*E0.get(key,0)) for key in rows],dtype=np.int64)
sigma_rhs=np.array([int(den*E1.get(key,0)) for key in rows],dtype=np.int64)

cols=[];square_labels=[]
def square_key(i,j):
 a,s=mbasis[i];b,t=mbasis[j]
 return (tuple(x+y for x,y in zip(a,b)),tuple(sorted((s,t))))
for i in range(60):
 cols.append({row_index[square_key(i,i)]:1});square_labels.append((i,))
for i in range(60):
 for jj in range(i+1,60):
  for sign in (1,-1):
   col=defaultdict(int)
   col[row_index[square_key(i,i)]]+=1
   col[row_index[square_key(jj,jj)]]+=1
   col[row_index[square_key(i,jj)]]+=2*sign
   cols.append(dict(col));square_labels.append((i,jj,sign))
nsquares=len(cols)

# Exact closed basis d(F^(beta-e_i)dF_i), total degree(beta)=6, omitting one
# supported anchor i per beta. The sole relation per beta is d(F^beta), so
# support-size minus one generators are independent. Total dimension 140.
forms=[]
for beta in mons(6):
 support=[i for i,x in enumerate(beta) if x];anchor=support[0]
 for i in support:
  if i==anchor:continue
  col=defaultdict(int)
  for jj in support:
   if jj==i:continue
   alpha=list(beta);alpha[i]-=1;alpha[jj]-=1;alpha=tuple(alpha)
   key1=(alpha,tuple(sorted((B1[jj],B2[i]))))
   key2=(alpha,tuple(sorted((B1[i],B2[jj]))))
   col[row_index[key1]]+=beta[jj]
   col[row_index[key2]]-=beta[jj]
  cols.append({r:-val for r,val in col.items() if val})
  forms.append((beta,i))
assert nsquares==3600 and len(forms)==140 and len(rows)==735
cols.append({r:-int(val) for r,val in enumerate(sigma_rhs) if val})

ii=[];jj=[];vv=[]
for col_index,col in enumerate(cols):
 for r,val in col.items():ii.append(r);jj.append(col_index);vv.append(val)
A=coo_matrix((np.array(vv,dtype=np.int64),(ii,jj)),shape=(735,len(cols))).tocsc()
save_npz(root/'integer_coefficient_matrix.npz',A)
np.save(root/'integer_entropy_rhs.npy',rhs)
np.save(root/'integer_sigma_entropy.npy',sigma_rhs)
(root/'basis.json').write_text(json.dumps({'F2_jet_monomials':mbasis,
 'square_labels':square_labels,'closed_form_primitives':forms,
 'entropy_denominator':int(den),'coefficient_rows':rows},separators=(',',':'))+'\n')
receipt.update({'stage':'exact preprocessing complete','monomials':60,
 'coefficient_equations':735,'nonnegative_square_variables':nsquares,
 'free_closed_form_variables':len(forms),'bounded_sigma_variables':1,
 'matrix_nonzeros':int(A.nnz),'entropy_denominator':int(den),
 'E0_nonzero_coefficients':int(np.count_nonzero(rhs)),
 'E1_nonzero_coefficients':int(np.count_nonzero(sigma_rhs)),
 'preprocessing_seconds':time.perf_counter()-started})
checkpoint();print(json.dumps(receipt),flush=True)

lp_started=time.perf_counter();receipt['lp_calls']=1
res=linprog(np.zeros(len(cols)),A_eq=A.astype(float),b_eq=rhs.astype(float),
 bounds=[(0,None)]*nsquares+[(None,None)]*len(forms)+[(0.25,0.75)],
 method='highs-ds',options={'time_limit':60.0,'maxiter':10000,'presolve':True,
 'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
receipt.update({'stage':'LP finished','lp_seconds':time.perf_counter()-lp_started,
 'status':int(res.status),'success':bool(res.success),'message':str(res.message),
 'iterations':int(res.nit),'certificate_verified':False})
checkpoint()
if res.success:
 np.save(root/'floating_solution.npy',res.x)
 receipt['sigma_floating']=float(res.x[-1])
 receipt['floating_max_coefficient_residual']=float(np.max(np.abs(A@res.x-rhs)))
 receipt['floating_min_square_weight']=float(np.min(res.x[:nsquares]))
 # One bounded-denominator rational reconstruction; no extra LP.
 rat=[Fraction(float(x)).limit_denominator(10**6) for x in res.x]
 residual=[-Fraction(int(x)) for x in rhs]
 for col,val in zip(cols,rat):
  if val:
   for r,coef in col.items():residual[r]+=coef*val
 good=(all(x==0 for x in residual) and all(x>=0 for x in rat[:nsquares])
       and Fraction(1,4)<=rat[-1]<=Fraction(3,4))
 receipt.update({'rational_denominator_limit':10**6,
  'rational_nonzero_residual_rows':sum(x!=0 for x in residual),
  'sigma_rational':str(rat[-1]),'certificate_verified':bool(good)})
 if good:
  (root/'exact_certificate.json').write_text(json.dumps(
   {'entropy_multiplier':int(den),'sigma':str(rat[-1]),
    'nonzero_coefficients':[[i,str(x)] for i,x in enumerate(rat) if x]},indent=2)+'\n')
receipt['stage']='completed';checkpoint();print(json.dumps(receipt,indent=2),flush=True)
