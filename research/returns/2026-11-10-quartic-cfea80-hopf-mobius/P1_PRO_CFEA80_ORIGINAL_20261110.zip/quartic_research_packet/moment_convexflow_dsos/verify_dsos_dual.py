"""Check the exact two-row dual against the retained integer LP, no optimizer."""
import json
from pathlib import Path
import numpy as np
from scipy.sparse import load_npz

root=Path(__file__).resolve().parent
basis=json.loads((root/'basis.json').read_text())
rows=[(tuple(a),tuple(j)) for a,j in basis['coefficient_rows']]
i=rows.index(((4,0,0,0),(2,2)))
j=rows.index(((3,0,0,1),(2,2)))
A=load_npz(root/'integer_coefficient_matrix.npz')
b=np.load(root/'integer_entropy_rhs.npy')
dualA=(2*A.getrow(i)+A.getrow(j)).toarray().ravel()
dualb=int(2*b[i]+b[j])
assert np.all(dualA[:3600]>=0)
assert np.all(dualA[3600:]==0)
assert dualb==-2
print('PASS: exact integer DSOS dual has nonnegative square pairings,')
print('zero closed-form and sigma pairings, and right-hand pairing -2.')
