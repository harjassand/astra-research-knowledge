# Independent hostile audit: noisy admission and protected processing

Initial report, 7 November 2026. Author of this report: independent hostile mathematical researcher. This report was written before reading another researcher's notes or exchanging mathematical conclusions. It is frozen by the accompanying SHA-256 receipt; follow-ups must be separate files.

## 1. Result and scientific status

The strongest useful repair I can prove is a **sparse-fault admission theorem for the accepted powered native memory**. It accepts arbitrary operations on a sparse set of DATA **and controller** sites, retains the actual bath and all its correlations, and derives the positive warm channel, its energy moment, and exponential admission-error bound. It requires a joint output fault instrument, rather than a system-only error estimate. It is a new derivation here, conditional on the already accepted N1388 native theorem, and is not a new passive mechanism or a completed physical encoder.

Two hidden composition errors are sharper than the old Gibbs-domination example:

1. An unknown **bare** input that experiences a fixed-rate error before redundancy has a nonvanishing, unavoidable input-error floor. For k independent bare inputs, that floor can approach one in global diamond distance. A claimed exponentially accurate end-to-end arbitrary-input device must specify a protected source, a weakening of its error target, or a physical improvement of that first interface. Known-state preparation does not solve this.
2. A reduced-system writer can have **zero diamond error**, and the same bath marginal, while two compatible gauge–bath correlations lead respectively to identity and a logical flip under the same subsequent joint HOLD. System-only writer accuracy cannot be composed with a correlated-bath storage result without a joint interface or a theorem uniform over the retained correlations.

Neither statement is a no-go for N1694 or N1388. The first concerns the target accuracy at an unprotected input boundary. The second defeats an insufficient proof interface.

**Breakthrough capability requested by the user: NOT ACHIEVED.** The native repair is mathematically consequential for admission, but full same-hardware noisy writing, protected operations/extraction, and favorable complete-resource comparison remain to be earned. Ordinary fault-tolerant I/O already supplies much of the relevant conceptual machinery and must be credited.

## 2. Governing sources and preserved acceptance

Source pin supplied for this round: `30712044febf7fccbe5ff5c0f93ada5ccf9dc3d5`; current upstream HEAD supplied: `d490a9d4429a8152902cebb32fd67c1e4c9285b2`.

I read the four supplied primary originals completely, together with the N1388/N1418/N1645/N1694/N1734 packets and the existing exact-H consumer dossier. The N1388 compiler bytes hash to `0af0dc529eb96a359f9f5d0f9f00972ec90f1817dc2cb4753d95f196bd3f4f18`, controller interface to `59c71b1c154457a0092b07610637eeb9a4f660c506f5277b43dbdd63d7b07155`. Their historical candidate headers do not negate the later exact-source whole acceptance recorded in N1388. This report carries that acceptance and checks the displayed moment/basin interface; it does not claim a fresh rederivation of the entire finite controller machine from unavailable underlying matrices.

N1388 supplies, at its stated hypotheses, a fixed-radius, fixed-decoder native memory with full-diamond error bounded by `min(2,C N T exp(-bN))`, and a separately earned positive warm-channel extension. It is a powered reset/monitor model with fixed grouped local dimensions and two-site interactions, bounded-body joint cb-norm noise and actual interval-CPTP joint dynamics. It is not a passive Gibbs device or an elementary-qubit geometric implementation.

N1694 supplies a separate exact three-body unary-clock Hamiltonian compiler, the stated all-occupation thermal majorants, accepted ideal complete **isolated** loading at its conditional analytic scope, and immediate/short-time noisy handoff under its sectorized Pauli-Davies contract. It does not supply the generic noisy long-HOLD basin or preparation of an inaccessible actual joint Gibbs bath. Its finite K versus 2^K auxiliary dimension, O(K^2) penalty edges, clock Pauli faults, cold inequalities and physical-time qualifications remain binding. N1645/N1734 visible statements do not supply their missing full models. N1418's accepted known-Bell-target buffer remains accepted at its actual common-gauge, source and ideal-output scope.

## 3. Exact obstruction A: the unprotected input bottleneck

Use half-diamond error `d(Phi,Psi)=||Phi-Psi||_diamond/2`. Let `Z_p(rho)=(1-p)rho+p Z rho Z`, `0<p<=1/2`. An arbitrary device begins with k bare qubits and fixed logical-independent ancillary/bath resources. Suppose its permitted fault model includes applying `Z_p` independently to those qubits before any redundancy-generating interaction. Everything after this location—including encoding, active correction, the memory, operations, recovery and reading—forms an arbitrary CPTP channel R from the noisy inputs back to k output qubits.

**Theorem A (PROVED).**

`d(R o Z_p^(tensor k), id_(2^k)) >= 1-(1-p)^k`.

For one input the lower bound is p, independent of memory size and all subsequent resources. Identity recovery attains the bound for this dephasing channel, so this is sharp.

**Proof.** Let d=2^k and `|Phi_d>` be maximally entangled. For each Pauli P let `f_P=F_e(R o Ad_P)`. Equivalently these are diagonal entries of the normalized positive Choi state of R in the orthonormal Bell basis, up to transpose/permutation. Therefore `f_P>=0` and `sum_(all 4^k Paulis) f_P=1`. The product dephasing law has probabilities `w_z=p^|z|(1-p)^(k-|z|)` on the Z strings; its largest probability is `(1-p)^k`. Consequently

`F_e(R o Z_p^(tensor k))=sum_z w_z f_(Z^z) <= (1-p)^k`.

Testing the output Choi state against `|Phi_d><Phi_d|` gives half trace distance at least `1-F_e`, and diamond distance dominates this input-specific distance. For R=id, the Choi error branches are orthogonal and the half-diamond distance equals `1-(1-p)^k`. QED.

**Interpretation.** A local-stochastic fault at the first input location is within a conventional noise model. The error is a genuine unknown logical change, not a correctable defect introduced after encoding. An honest target for one bare qubit is `O(p_input)+epsilon_internal(N,T)`, or preservation relative to a specified noisy-input channel. An asymptotically vanishing error requires source-provided redundancy/protection, heralded input replacement, or a separately implemented improving first interface. One cannot distill a single arbitrary unknown qubit by the known magic-state preparation argument. For k=Theta(N) bare inputs, a constant per-input floor is incompatible with an exponentially accurate global block channel.

This is established quantum-I/O territory, not a new impossibility claim. Christandl–Fawzi–Goswami's *Fault-tolerant quantum input/output*, arXiv:2408.05260v3, treats both endpoints explicitly; its Theorem 43 retains auxiliary channels and input/output stochastic errors. Its preparation-only Corollary 45 cannot be substituted for its quantum-input theorem. Exact import details are in Section 8.

## 4. Exact obstruction B: a perfect reduced writer can fail joint composition

Let L be a logical qubit, A an accessible clock/gauge qubit, B an inaccessible retained bath qubit. Put

`Omega_equal=(|00><00|+|11><11|)/2`,

`Omega_unequal=(|01><01|+|10><10|)/2`,

and `P_equal=(I+Z_A Z_B)/2`, `H=g X_L P_equal`, `t0=pi/(2g)`.

Both joint writer channels `W_+(rho)=rho tensor Omega_equal` and `W_-(rho)=rho tensor Omega_unequal` have exactly the same reduced system channel `rho -> rho tensor I_A/2` and the same bath marginal `I_B/2`. The logical subsystem initially decodes perfectly, including on reference-entangled inputs. Nevertheless, after exact HOLD under this SAME H and discarding A,B,

`Dec o Ad_(exp(-it0H)) o W_+ = Ad_X`,

`Dec o Ad_(exp(-it0H)) o W_- = id`.

The channel distance is one. A local X fault on A swaps the two resources without changing the reduced system writer at all; probability p of that fault gives logical error p after HOLD, despite zero reduced writer error and zero immediate logical error.

**Scope.** This three-qubit model is a counterexample to composing a system-only writer bound with a correlation-sensitive joint evolution. It is NOT claimed to satisfy the geometric, rare-boundary or particular thermal-memory hypotheses of N1694. It makes no assertion that that memory fails. The same counterexample also prohibits silently attaching a fresh independent bath after writing.

**Repair.** Prove a joint writer estimate retaining the actual bath, or prove future storage uniformly for every admitted logical-independent gauge–bath resource. The sparse-error theorem below uses the latter native-memory interface. A bound merely on the logical marginal is insufficient to recover the required gauge–bath state, although exact identity on the logical marginal does force that logical subsystem to decouple from its full complement after a specified exact decoder.

## 5. Constructive theorem: sparse DATA/controller faults enter the native warm basin

This is the most promising repair found independently. It avoids Gibbs domination completely and does not require clocks to be thermal.

### 5.1 Native input and exact added hypotheses

Fix a native family satisfying the accepted N1388 theorem. In its specified full forest frame let

`E=U+R sum_h B_h`, `V=exp(sE)`,

`P={r_can<r0 N, E<e_cut N}`.

The proof observable F obeys the accepted comparisons and killed drift

`F <= exp(gN) exp(sE)`,

`F >= exp(-q_t N) exp(s' E)`,

`d log x/dt <= -(lambda/s) log x +(rho+lambda*g/s)N`,

where `x=Tr(F rho_killed)`, `s'>0`, `nu=g+s*rho/lambda`. The fixed native parameters satisfy `nu+q_t<s'e_cut`. All constants are fixed independently of N,T. The native theorem extends to P-supported positive warm channels with identity canonical logical action and `log x(0)<=nu_w N+O(1)` when `max(nu_w,nu)+q_t<s'e_cut` with a fixed positive gap.

Let an ideal encoded/ready input, with a fixed logical-independent actual bath, be followed by a **positive joint fault instrument**

`W=sum_(S subset [m]) W_S`, `m<=aN`.

Each W_S is CP on system and retained bath and acts trivially on every system site outside S; its bath action may be arbitrary and correlated with all previous faults. External reference systems are inert. Assume the operator intensity bounds

`sum_(S superset A) W_S^*(I) <= q^|A| I` for every A.

State-independent local-stochastic fault flags with arbitrary supported channels imply this stronger reference-uniform form. A scalar support estimate for only one tested input does not. If physical faults are specified before the forest change of frame, first charge its bounded spread and incidence to obtain this contract; no noiseless clock release is granted.

Assume bounded energy incidence: the nonnegative commuting local terms of E affected by a system support S have summed operator norm at most `K |S|`, after any fixed forest spread. Thus applying any S-supported operator to the encoded/ready E=0 input has output energy at most `K|S|`. Also charge a data-error spread factor b, so the resulting data Pauli span has weight at most b|S|. This is a structural condition to check for the actual forest, not a consequence of a packet title.

Choose fixed alpha>0 so

`b alpha<r0`, `2 b alpha<delta_distance`, `K alpha<e_cut`,

and choose q small enough for the moment condition below. Use the common safe radius, not an independently optimized radius from either CSS sector.

### 5.2 Theorem B (PROVED conditional on the accepted native theorem)

Write `ell=ceil(alpha N)` and

`epsilon_adm <= binom(m,ell) q^ell <= (e m q/ell)^ell`.

If ell>m the bad channel is absent. Otherwise choose `e a q<alpha`, so `epsilon_adm<=exp(-c_adm N+O(1))` for a fixed positive c_adm. The normalized channel obtained by retaining histories `|S|<ell` is an actual positive P-supported warm channel with identity canonical logical action, including for arbitrary reference inputs and with the actual gauge–bath correlations retained. Its moment obeys

`log x_good(0) <= [g+a log(1+q(e^(sK)-1))]N +O(1)`.

Consequently, if

`max{nu, g+a log(1+q(e^(sK)-1))}+q_t < s'e_cut`

with a fixed positive gap, the native HOLD plus the specified fixed ideal decoder has half-diamond error

`d(Dec o HOLD_T o W o Enc_ready, id) <= epsilon_adm + C N T exp(-b' N)`.

A joint half-diamond writer approximation delta adds delta. A bare-input error epsilon_input adds epsilon_input rather than being silently suppressed. A normalized constant outside-basin mass adds its actual probability. All clock/controller faults are included in K, b, m and q.

### 5.3 Proof

**Energy support.** For any nonnegative commuting energy term e_Z disjoint from S, `e_Z A_S |psi_ready>=A_S e_Z |psi_ready>=0`. Only the incident terms remain; their total norm is at most K|S|. Thus the entire coherent Kraus image has `E<=K|S|`. Affected DATA errors expand in a Pauli span of weight at most b|S|. For |S|<ell, the strict chosen inequalities put every branch in P for sufficiently large N.

**Canonical logical identity and bath retention.** The union of any two errors in the retained span has weight below distance. Knill–Laflamme, using the specified canonical decoder, therefore gives `D E_j Enc = I_L tensor |e_j>` on the span, also when error coefficients are operators on the retained bath. Thus every retained CP branch has the form `rho_LR tensor sigma_(gauge,bath)` in that frame. The gauge–bath state and branch probability do not depend on the logical/reference input. This supplies exactly the positive warm logical action; it is not merely a fidelity test on a Bell pair. Full native frame and safe-radius compatibility remain assumptions.

**Bad-history mass.** If |S|>=ell, S contains at least one ell-element set A. Summing their operator intensity bounds gives the binomial bound. The resulting bad channel is positive and its complete trace norm equals its worst-case trace mass. No postselection renormalization is used to establish the support tails.

**Moment.** The inclusion bound gives for theta>=0

`E exp(theta|S|)=sum_A (exp(theta)-1)^|A| Pr(A subset S) <= (1+q(exp(theta)-1))^m`.

The same expansion holds as an operator-intensity inequality for the CP instrument. Combine the energy-support estimate with `F<=exp(gN)exp(sE)` and set theta=sK. Removing bad branches can only decrease this positive expectation. Normalizing the retained mass costs `-log(1-epsilon_adm)=O(1)` and in fact exponentially little. This proves the stated coefficient. The accepted killed moment law then bounds the energy boundary by `exp(-b'N)`, and the actual O(N) joint-generator budget gives the native Duhamel/fixed-decoder bound. Add the positive bad-history mass and writer approximation by channel contraction and the triangle inequality. QED.

**What is new and what is not.** The generating-function bound and error-span factorization are standard. Their checked combination provides a concrete physical-output sufficient condition for N1388's already accepted warm extension. It is not a noisy long-HOLD theorem for the passive unary Hamiltonian: that model does not supply this native Lyapunov drift or its powered resets. It also does not manufacture the required noisy encoder or extraction circuit.

## 6. A second repair: turning a signed small-weight approximation into a positive warm channel

General-noise fault-tolerant I/O can produce a low-weight **superoperator** approximation, not necessarily a CP subchannel. It must not simply be called the positive killed/warm map required by N1388. There is a useful elementary repair if the approximation is in a common correctable span and includes the retained bath.

**Lemma C (PROVED).** Let A be a CPTP joint writer. In a specified physical decoding isometry D, suppose an HP approximation satisfies

`||D A D^* - (id_L tensor tau)||_diamond <= epsilon`,

where the notation means conjugating the output by D, tau is a fixed Hermitian gauge–bath operator supported on a chosen warm gauge subspace G0, and epsilon<1. Then there exists a positive normalized tau_hat supported on G0 such that

`||D A D^* - (id_L tensor tau_hat)||_diamond <= 3 epsilon`.

**Proof.** Take any fixed logical input rho0 and let sigma be the gauge–bath marginal of the physical positive output. Contractivity gives `||sigma-tau||_1<=epsilon`. Let Q project onto G0. Then sigma0=Q sigma Q is positive and `||sigma0-tau||_1<=epsilon`. Also its missing mass `1-Tr sigma0=Tr((I-Q)sigma)<=epsilon`, since tau vanishes there. Normalize `tau_hat=sigma0/Tr sigma0`. Then `||tau_hat-tau||_1<=2epsilon`. The diamond norm of a map `id tensor (tau_hat-tau)` is that trace norm. Apply the triangle inequality. QED.

For an HP small-error-span approximation to an ideal encoder, the common decoder factors it exactly as `id_L tensor tau`; errors on at most alpha N sites imply `E<=K alpha N`, yielding `nu_w<=g+sK alpha`. Thus positivity can sometimes be repaired at constant error cost rather than by an unjustified CP truncation or a dimension-dependent Choi conversion. The approximation must be joint and its common-error-span/energy support must actually be shown. Standard reduced-channel theorems do not automatically include the actual bath required here.

## 7. Audit of the remaining interfaces

### 7.1 Gibbs order and nonstationary passive admission

Local stochasticity does not imply a useful Gibbs domination constant. The existing product-state example proves that even independent constant-rate faults can cost `exp(Theta(N))`; it is an interface obstruction, not a lifetime lower bound or failure theorem. Relative entropy typically changes by Theta(N), which likewise cannot be inserted into the existing rare-boundary entropy consumer with its crucial O(p_bad) entropy scale. Theorem B instead uses a real dynamical drift. That drift is not supplied by a static equilibrium contour bound.

The N1694 short Davies handoff cannot be iterated unless an actual operation restores the thermal/basin distribution. A hypothetical decoder is not such an operation. A positive, uniform spacetime witness or nonstationary Lyapunov theorem for its actual Hamiltonian and bath remains a substantive open problem. Its bad clock components cannot be replaced by absent checks: their changed signs and multi-check effects must be controlled.

### 7.2 Static Hamiltonian compiler versus actual dynamics

The unary compiler is exact in all number sectors, and that exactness is valuable. It does not identify its Davies dissipator with a native reset controller or with exact joint-Hamiltonian bath evolution. Equal equilibrium/free-energy data alone do not fix kinetic rates: multiplying any detailed-balance generator by an arbitrary positive scalar preserves its stationary state and changes all physical lifetimes inversely. Bath operator form, spectral rates, Lamb shift, clock-changing channels and lower/upper hazard bounds remain separate imports.

Likewise, a weak-coupling approximation has to be proved on the actual advertised size/time/error regime before being used for exponentially long storage. I did not verify the full theorem from Davies (1974); the retrieved alleged PDF was HTML and is marked unavailable in the source manifest. No theorem-number import or all-time approximation claim is made from it. The qualitative weak-coupling characterization is confirmed by its publisher abstract, [Davies (1974)](https://link.springer.com/article/10.1007/BF01608389).

### 7.3 Trace tests, Bell buffers and diamond interfaces

A trace bound on one Choi state is not automatically a dimension-free channel bound. For dimension d, the unitary `U=I-2|0><0|` has `d_diamond(Ad_U,id)=1`, while its normalized Choi half-trace distance is `2 sqrt(d-1)/d -> 0`. A global many-logical-qubit Choi test can therefore conceal a large worst-case error.

There is an important constructive exception: a **specified teleportation protocol** consuming an independent Bell resource epsilon-close in trace norm to the ideal resource is diamond-epsilon-close to ideal teleportation, because it uses the same physical CPTP operation with different fixed resource states. No dimension factor is needed for that resource-simulation argument. However, N1418 alone does not implement the required noisy Bell measurements, encoded receiving ports, fixed recovery, extraction or bath-compatible transfer. A known Bell target plus a supplied ideal decoder does not erase these costs or the bare-input bottleneck.

### 7.4 Operations and recovery

N1388's fixed common correctable span is stronger than an operation-dependent decoder convention. It permits a genuine operations programme: specify a physical gate that maps its full warm/error span to the intended logical gate, bounds energy amplification and fault spread, and retains a positive admission margin for subsequent correction. A transversal CSS CNOT between compatible blocks is a concrete candidate. It may double error spread and syndrome energy; this consumes real radius/moment margin. Busy controller/data entanglement must be handled in the actual native frame. Switching off controllers or implementing forest conjugation is a physical control assumption, not an analytical similarity map.

For many operations, reprove the moment/radius recurrence and any required cooling/service time; an exponential error budget cannot be inferred solely from correct action on the code space. Arbitrary universal operations require an earned non-Clifford gadget or a protected interface to an established FT computational code. No such complete same-hardware theorem has been established in this report. Physical quantum output also retains an O(p_output) endpoint floor if emitted on bare carriers; protected classical measurement outcomes admit a different fault-tolerant readout target.

### 7.5 Work, cooling and comparators

N1388 nominally has O(N) powered reset/monitor hardware at fixed nonzero rates throughout HOLD. Charge all physical site dimensions, auxiliary capacity, controller-clock precision, incoming reservoirs, time-integrated reset/service events, entropy export, and refrigeration. A count of reset attempts is not itself a computed heat cost; state-dependent entropy and energy exchanges are needed. Under a single bath at temperature T and degenerate reset memory without retained side information, erasing entropy Delta S costs at least k_B T Delta S in the reversible limit. That restricted thermodynamic lower bound is not a device power prediction.

N1694 must pay K clocks/check and O(K^2) penalty links, actual bath preparation/mixing, conditional sampling/loading, all fault-tolerant routing and final release, and its extremely demanding sufficient temperature/coupling point. The quoted energy improvement in another variant is not a same-factor lifetime/temperature gain.

The strongest comparator receives exactly the same control gates, clean/reset resources, cooling, routing, classical processing, switchability and source access. If a conventional FT architecture is used to earn WRITE or universal gates, that architecture can also keep correcting during HOLD. The native controller is already a continuously powered autonomous error-correction protocol. No passive-work advantage follows merely from omitting externally commanded gates. Conversely, explicit passive storage might save integrated active service work if its actual refrigeration and bath maintenance are lower; that requires a quantitative comparison, not a naming convention.

## 8. Primary literature checks and imports

These sources were inspected directly, not just searched by title. Literature downloads and hashes are in `../auditor/sources/MANIFEST.json`.

1. **Christandl, Fawzi, Goswami, arXiv:2408.05260v3 (2 December 2025), [Fault-tolerant quantum input/output](https://arxiv.org/html/2408.05260v3).** Theorem 43 applies to finite quantum I/O circuits under their circuit-level stochastic fault-tolerant scheme and gives size `|Phi| poly(k)`, complete error `4|Phi|(c delta)^k`, auxiliary input/output channels, and O(delta) endpoint stochastic errors. Corollary 45 is preparation-only. Definition 34's general-noise adversarial approximation is a weight-t superoperator and need not be CP. These are exactly relevant predecessors; they do not supply an arbitrary retained microscopic-bath writer theorem.
2. **Christandl, Fawzi, Goswami, arXiv:2602.16948v2 (29 September 2026), [Fault-tolerant interfaces for quantum LDPC codes](https://arxiv.org/html/2602.16948v2).** Theorem 44: a polynomial-size state-preparation circuit using O(x) space and x quantum outputs has a constant-qubit-overhead stochastic-noise realization, output local stochastic strength `(kappa_1 delta)^(kappa_2)`, and approximation epsilon(x)->0, under their threshold. It is a preparation theorem, not arbitrary unknown-state injection, and its theorem alone does not promise exponentially small epsilon at the desired constant-space cost. Independent circuit faults, gate access, geometry/routing and classical control must match. Definitions 7–8 make error-span correction with auxiliary systems explicit.
3. **Balasubramanian, Davydova, Lin, arXiv:2605.10943v1 (11 May 2026), [A passive self-correcting quantum memory in three dimensions](https://arxiv.org/html/2605.10943v1).** Theorem 1.1 is an informal thermal-encoding storage claim under their generalized thermal dynamics; Section 5.4/Theorem 5.13 bounds their decoder-unstable thermal syndromes. The encoding is explicitly thermal, not an experimentally robust arbitrary writer. Three dimensionality/passive storage alone cannot establish new priority here.
4. **Dünnweber, Styliaris, Trivedi, arXiv:2601.20818v3 (25 September 2026), [Quantum Memory and Autonomous Computation in Two Dimensions](https://arxiv.org/html/2601.20818v3).** Formal Theorem 1 requires a sufficiently correct hierarchical initial state and their local fault model. Section VI explicitly discusses encoded initialization and readout; the powered/dissipative scheme already has universal computation. A new autonomous processor theorem must outperform or extend a decisive interface/cost/noise contract, not merely repeat autonomy or low dimension.
5. **Zhao, Yuan, Han, Liu, arXiv:2609.39965v3 (2 November 2026), [Single-shot state preparation thresholds in quantum LDPC codes](https://arxiv.org/html/2609.39965v3).** Theorem 1 assumes bounded degrees/weights, logarithmic-or-larger distance, and independent local-stochastic readout/data noise. Its soundness branch gives residual local stochasticity; its confinement branch gives decoder-defined logical success without that residual guarantee. It concerns specified CSS-state preparation with ideal final recovery, not arbitrary bare unknown-state loading or direct native warm energy admission.

No primary-source historical-priority conclusion is claimed. No unverified recent check-in is promoted to an available theorem.

## 9. Decisive next operation and failed shortcuts preserved

The most useful next operation is to instantiate Theorem B on the **actual native forest and physical noisy encoder**, not to repeat its abstract warm assumption. Verify a numerical/structural K and b, give a joint positive fault instrument that includes every DATA/controller/clock endpoint and retains the future bath, compute q's allowed fixed-positive range from the native margin, and then implement one protected operation/extraction gadget with a closed energy/radius recurrence and a full resource bill. Existing FT I/O should be tried first and credited. It may close a native mathematical interface while revealing that the resulting cost is ordinary active fault tolerance.

For the genuinely passive unary direction, the decisive task remains its own nonstationary physical clock/bath basin theorem; neither Theorem B, known-state FT preparation, stationary Gibbs order nor bounded-time Davies support accumulation supplies it. A spacetime witness controlling fault-induced clock sign changes is the concrete constructive target.

Failed shortcuts retained: eliminating unwanted number sectors; treating a faulty clock as a deleted check; replacing a reduced writer by a joint writer; inferring CP positivity from a signed truncation; using a one-state trace test as a dimension-free channel theorem; suppressing the bare-input fault floor by more downstream encoding; iterating a handoff with no physical reset; transferring static Hamiltonian equivalence into physical Davies/exact-H lifetime; claiming practical or thermodynamic advantage without matched full costs. These invalidate the shortcuts, not the accepted memories.

## 10. Independent initial status ledger

| Claim | Status |
|---|---|
| N1388 exact-source native memory and earned warm extension | Earlier accepted capital, preserved at stated scope |
| N1694 ideal complete isolated thermal loading | Earlier accepted conditional analytic capital, preserved |
| Bare-input dephasing accuracy floor | PROVED; standard phenomenon, exact derivation supplied |
| Equal reduced writer/marginal bath but incompatible future logical channels | PROVED proof-interface counterexample |
| Positive sparse DATA/controller joint-fault admission into native warm basin | PROVED conditional on accepted native theorem and explicit structural/fault contract |
| Positive repair of a common-error-span HP joint approximation | PROVED elementary lemma |
| Generic noisy-writer-to-long-HOLD passive unary theorem | OPEN |
| Same actual microscopic-bath noisy native encoder plus operations/extraction | OPEN |
| Protected-source or endpoint-noise full processor using imported FT I/O | CONCRETE ROUTE; model/resource applicability must be closed |
| Favorable matched total-resource advantage or civilization-changing device capability | NOT ACHIEVED |

Memory used only for task scope and the previously stated full-cost/noisy-writer gate: `MEMORY.md:117-147`. All mathematical claims above were independently checked from this round's sources/derivations.
