# CFG import audit for quantum ports

7 November 2026. This records the primary imports behind [the constructive port closure](../challenges/quantum_ports_closure.md); it is not a claim that CFG proves the thermal-memory theorem.

Primary: Christandl, Fawzi and Goswami, *Fault-tolerant quantum input/output*, [arXiv:2408.05260v3](https://arxiv.org/html/2408.05260v3), dated 2 December 2025. The whole HTML was reacquired and its displayed theorem statements checked on 7 November 2026.

Cache HTML SHA256: 83f1b792aa4eaecf71ae6d8354716152d2e1fbd8ebb188e7c3cee5a45cf6b830.

The cache's plain-text line locations are:

| Location | Content checked | Import consequence |
| --- | --- | --- |
| Section 2.5, lines 324--348 | Gate-local independent noise, stochastic mixtures (44)--(45), noiseless classical elements | Staging satisfies this model only by explicit hybrid assumption; weak common B noise is not imported into it. |
| Definition 20, lines 351--376; Definition 22, lines 379--399 | Polynomial code lengths and gadgets/interfaces, exact good/bad stochastic scheme | Computational accuracy parameter is reindexed accuracy, not physical concatenation depth. |
| Lemma 40, lines 760--764, (128) | Entire encoded-input module, actual auxiliary channel, complete bound | One-sided encoded WRITE/READ have no bare endpoint floor. |
| Lemma 41, lines 765--774, (129)--(131) | Approximate supported input interface plus positive good/bad decomposition | Arbitrary correlated input is allowed; low-support bad branches are corrected jointly with memory errors. |
| Lemma 42, lines 775--779, (132) | Exact positive physical output-interface decomposition on the whole module | Output flags certify actual energy support/moments. |
| Theorem 43, lines 780--790, (133)--(135) | Both bare interfaces; retained auxiliaries; 4 size(Phi)(cp)^l complete error | Does not eliminate bare unknown input/output floors. |
| Definitions 47--48, lines 857--878, (147) | Test-circuit communication metric | Literal Theorem 53 conclusion is not automatically a decoded diamond claim on arbitrary gauges. |
| Definition 52 / Theorem 53, lines 975--983, (166) | Physical LS robustness parameter 3cp; test size enters accuracy choice | Applies to fixed complete storage channel; direct lemma proof gives stronger retained-auxiliary processing statement. |
| Appendix C.3, lines 1715--1775, Lemmas 70--71 | Explicit independent stochastic concatenated construction | The assumed computational scheme is supplied for that circuit model. |

The new deductions are: (i) an auxiliary-retaining support/moment certificate from the positive interfaces; (ii) the common-span promised local-descent decoder and its polynomial capped circuit; (iii) transfer through short memory/staging SWAPs using the service's actual same-bath finite-pulse argument; (iv) composition with the retained-auxiliary thermal service. None is attributed as a theorem already stated in CFG.

Applicability limits: the active processor is isolated from B outside links, has the specified stochastic noise and classical primitives, and is supplied enough parallel links for a short transfer. Already-encoded computational ports replace the raw endpoint contract. All staging workspace/time/control/reset/routing is paid. Generic common-bath noisy preparation, literal exact microscopic realization of the thermal GKLS reservoir, universality and full-cost advantage remain outside the theorem.
