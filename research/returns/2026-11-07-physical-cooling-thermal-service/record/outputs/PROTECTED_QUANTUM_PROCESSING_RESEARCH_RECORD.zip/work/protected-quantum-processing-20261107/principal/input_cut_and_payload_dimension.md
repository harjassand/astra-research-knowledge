# Input cuts, reference safety, and payload dimension

7 November 2026. Principal follow-up, still before reading peer reports. These are established information-theoretic obstructions used to specify an honest capability target, not claimed discoveries.

## 1. An unprotected input cut has an irreducible loading error

Suppose an unknown d-dimensional input, possibly maximally entangled with R, must cross a noise channel
D_p=(1-p)id+p Delta_d
before every accessible encoding/control/recovery operation. Delta_d replaces the input by I/d. The fixed initial apparatus and bath are independent of the input and R. Any deterministic remainder is a CPTP channel Gamma back to a d-dimensional output. Then

half ||Gamma D_p-id||_diamond >= p(1-1/d^2).

Indeed feed a normalized maximally entangled state. On the replacement branch the output is sigma tensor I_R/d, whose Bell overlap is exactly 1/d^2 for any sigma. The other branch has overlap at most one. Thus entanglement fidelity <=1-p+p/d^2; the Bell effect witnesses the stated trace-distance lower bound. Gamma=id attains it: the half-diamond distance between Delta_d and id is 1-1/d^2 (the upper bound follows, e.g., the unitary-error-basis decomposition with identity weight1/d^2). No later memory lifetime or larger code removes the early p floor.

A pre-announced protocol can therefore promise epsilon_load=O(p)+epsilon_internal and exponential STORAGE suppression, but not epsilon_total=exp(-cN) for one bare input at fixed p under this allowed cut noise. To get vanishing full-cycle error it must earn an encoded/redundant input port, a trusted first interface, a restricted input-noise model, or a physically justified fault rate that decreases. An initially encoded input is not free acquisition of arbitrary bare quantum data.

More generally, local-stochastic noise can put a specific harmful k-location cut fault in with probability p^k (all other histories fault free), while satisfying every support tail: any subset of those k locations has probability p^k<=p^{|subset|}. If that fault destroys the input before encoding, the full-cycle error has the corresponding floor. Exponentially small access error requires eliminating every bounded-size harmful cut, not just long-distance storage.

Heralding requires a separate accepted-subchannel analysis. Postselecting away a branch without a physical flag does not evade the deterministic claim.

## 2. A single averaged moment can cost the payload dimension

Let W be a CP writer and F>=0 an output observable. Put H=W*(F)>=0. From Tr H/d<=m one gets only ||H||<=d m. This is sharp, with H=d m |0><0|. Thus an averaged writer moment on the maximally mixed k-qubit logical input can hide a factor2^k in a uniform guarantee.

A polynomial/exponential lifetime argument for a constant-rate code must instead prove:
(a) a reference/input-uniform moment directly; or
(b) exact logical factorization/error-span symmetry that makes H scalar on the logical input; or
(c) a worst-case bound explicitly paying log d.

When faults act after an encoded/ready state, and supportwise energy bounds hold for the entire encoded subspace, the direct uniform proof in the principal initial note satisfies (a). It is not inferred from a Choi-state trace estimate.

## 3. Initial logical accuracy is not the thermal-gauge basin

Let W map L to L_out tensor G (G includes the inaccessible bath). If Tr_G W=id exactly, Stinespring uniqueness/no-information-without-disturbance forces W(rho)=rho tensor sigma_G for one sigma_G. Approximate identity admits an approximate constant complementary channel at square-root error by the established continuity of Stinespring dilation.

The key missing condition is therefore which sigma_G is produced, and whether the storage dynamics protects that whole gauge/bath class. Neither immediate logical correctness nor this factorization identifies sigma_G with the stationary thermal marginal. Two resources can have exactly the same logical channel at time zero and different later logical behavior.

A finite example is a logical qubit L with one gauge flag G and H=|1><1|_G tensor Z_L. Both writers rho ->rho tensor |0><0| and rho ->rho tensor |1><1| decode perfectly at time zero. The first stores exactly; the second applies e^{-itZ} and fails at time pi/2. This does not contradict an explicitly specified thermal or warm-basin theorem. It proves the need for its actual gauge condition.
