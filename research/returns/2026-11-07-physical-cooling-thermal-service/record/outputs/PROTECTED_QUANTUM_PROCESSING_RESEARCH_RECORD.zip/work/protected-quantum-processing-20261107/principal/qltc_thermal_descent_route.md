# Second principal route: turn local cocycle descent into a thermal processing basin

7 Nov 2026. This follows the frozen independent principal initial. It is a new constructive route, not yet a theorem accepted for the explicit code. It was developed before reading peer reports; peer summary messages have arrived. No initial report is rewritten.

## Target and departure

Replace the explicit three-body clock memory, retaining it at exact scope. Use an explicit bounded-incidence commuting CSS Hamiltonian on a good qLTC. Engineer a finite-temperature Davies reservoir containing the bounded-star Pauli correction catalog. Derive a nonstationary energy-basin theorem with no global Gibbs domination; interleave bounded-depth code-preserving gate bursts and constant cooling dwells. This is a Markovian open-system architecture, not the prior exact interacting microscopic Hamiltonian claim and not a three-dimensional/two-body realization. Cooling, bath modes, large fixed locality constants, control and communication are resources.

Sources read: Gay--Granha Jeronimo arXiv:2609.20780v1, especially Lemmas 6.1.3, 6.2.1, Proposition 6.2.2, Theorem 6.3.1, Lemma 6.4.1; Li--Li--Han--Liu arXiv:2609.26691v3 Theorem 1.1 (claims linearly many addressable transversal non-Clifford operations on related good qLTCs). Full code imports still need independent applicability checks. Cached HTML sources in ../sources/.

## A. Quantitative active-vertex refinement of the cocycle argument

For a closed degree-j cochain b with support A, let B be the vertices v for which some correction y supported above v strictly decreases |b+delta y|_block. Degrees, stalk dimensions and star sizes are fixed constants. If a face v contains a vertex outside B, every correction above v is also a correction above that good vertex; Lemma 6.1.3 holds there. At exceptional faces, insert a bounded additive slack. There are O(|B|) exceptional faces and each enters only O(1) upward stars.

Repeat the linear recursion in Proposition 6.2.2 with these additive slacks. Its conclusion should become

  |A| <= lambda L_j |A| + Q_j |A|^2/Z_j + C_j |B|,

with fixed explicit C_j. For |A| <= (1-lambda L_j) Z_j/(2 Q_j), obtain

  |B| >= (1-lambda L_j)|A|/(2 C_j).

This must be proved by tracking the actual recursion, not inferred from existence of one descent. Each active vertex supplies a bounded-support Pauli lowering integer syndrome-block energy by at least one. Apply in the two actual dual complexes, including binary/field coordinate conversions. The energy can count nonzero field/stalk syndrome blocks rather than individual bits; each block projector is still a bounded-body commuting Pauli function. Need verify that Li et al.'s gate codes inherit precisely these complexes and parameters, not just the headline qLTC property.

## B. Thermal Lyapunov law

Let U_N be integer block-syndrome energy, H_N=J U_N. Catalog all Pauli corrections supported on an allowed vertex star, including both CSS sectors. There are at most M N labels, fixed maximum energy change D, bounded incidence. Spectral components of each Pauli have support contained in its star and adjacent checks, hence fixed bounded body size.

Choose Davies rates r(delta), where delta is the change of U, with

  r(-d)>=gamma>0, r(d)<=Gamma exp(-beta J d), d=1,...,D,
  r(d)=exp(-beta J d) r(-d).

For V_s=exp(sU), the exact Heisenberg action is

  L_beta^* V_s = V_s sum_(h,delta) r(delta)(exp(s delta)-1) Pi_(h,delta).

Using A, throughout U<=u_cut N,

  L_beta^* V_s <= [-a_s U+b_s N] V_s,
  a_s=gamma kappa(1-exp(-s)),
  b_s<=M Gamma exp(-beta J)(exp(sD)-1).

Arbitrary sufficiently weak bounded-body joint perturbations add at most C_s eta N V_s, under a per-site sum of joint cb norms and actual CPTP interval propagation. This is the same local relative-observable estimate used by the native compiler, but no controller/pullback is needed here. Pointwise validity, CP killed compression and all coherent boundary terms still require proof.

For killed positive state sigma, x=Tr V_s sigma obeys

  (log x)' <= -(a_s/s) log x+(b_s+C_s eta)N.

Thus the moment coefficient contracts to nu_eq=s(b_s+C_s eta)/a_s. An initial moment coefficient nu_w<s u_cut yields a boundary tail exp[-(s u_cut-max(nu_w,nu_eq))N+O(1)]. Generic coherent comparison loses a square root in the exponent. Full error O(N T exp(-cN/2)), reference-uniform. This is a warm, non-Gibbs storage statement if A and the joint generator assumptions are verified.

## C. Static energy certificate and logical subsystem

The qLTC soundness/explicit syndrome repair supplies a correction of weight at most C U for every sufficiently small valid syndrome in each sector. If two low-energy canonical corrections and a bounded-support Pauli have total weight below distance, that physical edge has identity logical action. Therefore a low-energy spectral projector alone is a full logical basin; no unknown high-weight logical representative is silently assumed correct. Any writer must still have the correct intended logical action. Existence of low energy does not identify the logical input.

## D. Finite-duration gate service

An ideal code-preserving circuit of fixed depth and bounded gate body has bounded support spread B. It may be a non-Clifford circuit: an error supported on w sites becomes an operator on at most B w sites, and the whole low-weight operator span is correctable. For a pre-gate energy cutoff u_pre N, C bounds canonical correction weight; after the ideal gate the correction support is <=B C u_pre N. Short gate-interval noise with local strength lambda=eta_gate tau can be Dyson-expanded in the ideal frame. After fixed-depth light-cone enlargement, r insertions affect <=w' r DATA sites and the joint diamond tail is bounded by

  sum_(r>=alpha N/w') (eta' N tau)^r/r!.

For fixed small eta' tau, this is exp(-c_g N). A positive exact-logical surrogate must be derived, not assumed for the signed truncated superoperator; a common-correctable-span positivity repair is the likely route. All bath correlations are kept in the joint expansion, or a rigorously justified dilation continuity step is needed. The cooling generator remains physically present during gates and is counted in eta_gate; fast gate controls of fixed strength independent of N can make tau small. One must not simply remove the bath.

Post-gate low-energy ceiling u_post=D_check(B C u_pre+alpha) can be chosen below u_cut. The gate never needs a storage basin during its ideal partial path, only low-weight fault control and low-energy output.

A subsequent cooling dwell of constant time tau_c has moment coefficient

  nu_eq+(s u_post-nu_eq) exp(-a_s tau_c/s).

Choose it strictly below s u_pre. At each gate, project away the exponentially small pre-tail (charge the gentle-measurement square root), execute the good finite-interval map, then cool. Iterating M gates gives O((T N+M)exp(-cN)) error in the ideal decoded computation, after explicit port errors. This supplies a candidate sustained protected service, rather than only a storage theorem or an unproved Gibbs domination interface.

## E. Ports and honest limits

Bare unknown inputs have an unavoidable first-fault floor O(p) per unencoded input before redundancy. No downstream storage removes it; with Theta(N) bare inputs the global diamond floor can approach one. Use a verified noisy quantum I/O theorem, encode trusted quantum ports, or report the input floor. Known-state qLTC preparation with global soundness can supply local-stochastic residuals; confinement-only logical success does not automatically supply the energy basin.

Universal computation does not follow from a headline transversal CCZ theorem alone. Need compatible individually addressable Clifford/Hadamard/code-switch operations, noisy encoded ancillas, measurements and extraction, plus uniform basis conventions and costs. At minimum the service theorem could earn a repeatable non-Clifford gate family. No advantage over active or autonomous FT is established merely by this construction; compare O(N) reservoirs/cooling, fixed but huge local support, fast controls, geometry and schedule honestly.
