# Principal mathematical adjudication

7 November 2026. The principal initial report is frozen separately. This file records integration and independent checks after all three researchers froze initial reports.

## 1. Consequential route chosen after challenge

The original three-body thermal model remains unextended: neither its ideal isolated writer nor immediate logical recoverability yields the required nonstationary long-HOLD theorem. The accepted powered N1388 warm basin admits sparse release faults; all four independent investigations derived that transfer, which is useful but not the main frontier.

The strongest constructive route replaces the protection architecture. It augments the recent constant-rate, linear-distance non-Clifford gate codes by fixed product ancillas and changes the commuting stabilizer energy. The goal earned is a finite-temperature, nonstationary protected gate service in a specified engineered Markovian thermal model. It does not claim a microscopic finite-bath, three-dimensional or economical device.

## 2. Independent local normal-form check

I independently checked the key step from the actual GJ anchored arrays. Put total chain degree n=p-r and d=T+Delta. In horizontal cube normal form, Delta is a disjoint collection of identity contractible pairs and critical constant copies. T strictly lowers p. Gaussian elimination of those identity pairs cannot change their own pivots: every off-block Schur-complement path contains T and therefore strictly decreases p. Fixed height t bounds every path's length, intermediate degree and propagation. The vertical argument exchanges T and Delta; after local star elimination, off-block paths strictly increase the filtration. These are genuine coordinate bases, rather than a chainmap asserted to be invertible.

Equivalently, if d0 is the local fiber differential and delta the other one, choose a contraction h with h squared zero. The critical subspace is invariant under delta in BOTH presentations. Set h'=(I+h delta)^(-1)h, a_i'=h'd0 a_i and b_i'=d a_i'. These finite polynomials yield a paired basis plus the unchanged critical inclusion. Relative to the old local basis the change is I+Q, strictly triangular in p, so the inverse is a finite geometric sum. This proves bounded propagation of BOTH the change and its inverse.

At the physical chain degree, binary coordinate changes give a CSS linear Clifford. Adjacent contractible pairs produce |0> or |+> ancillas. Field-to-binary conversion must use trace-dual bases. GJ and Li interchange physical X/Z labels; the final construction uses Li Definition 2.1, H_Z=delta^k. The additional global Hadamard is essential when comparing the two cochain presentations.

Sparse-matrix CNOT synthesis with clean temporary work implements the abstract map on the intended work-zero subspace. It must not be mistaken for the same unitary tensor identity on arbitrary thermal work. The preferred Hamiltonian/gate construction never needs to execute this coordinate map: conjugate its Paulis algebraically to define bounded-support physical couplers, retain the original DATA coordinates for Li's gates. Thus this synthesis subtlety does not enter protection or gate correctness.

## 3. Independent two-sector energy check

On the exact original Li code plus the specified normal-form product ancillas, let UF be its cochain-block Z-syndrome energy plus original Z-ancilla defects. Pull back the corresponding K cochain Z energy and its Z-ancilla defects through the type-swapping CSS Clifford to obtain UK. UF generates the complete original Z stabilizer group; UK generates the complete original X group. Their common zero space is precisely the desired code plus product ancillas. Both energies commute.

An original X correction commutes UK exactly. A K X correction pulls back to an original Z Pauli and commutes UF exactly. Hence U=UF+UK needs no conservative unequal weighting. The active-vertex proof supplies linear density of downward moves in each sector. Their union supplies density kappa U at sufficiently low linear energy. Repeated strict descent repairs any sufficiently low-energy syndrome using at most U bounded-support moves, so a physical correction of weight at most C U exists. A low-energy projector alone is therefore a valid full logical basin in this augmented construction.

These statements use local filling/expansion, not GJ's sufficient Euler-characteristic RATE bound for every Li profile. Li's cup-product subrank supplies the rate of all three blocks separately.

## 4. Independent storage/pulse/composition check

The exact Davies action on exp(sU) is diagonal in the syndrome. Each improving hub contributes at least gamma(1-exp(-s)); positive steps are thermally suppressed. Hence drift (-aU+bN)exp(sU). The complete-norm perturbation bound factors unaffected commuting terms and is uniform over bath dimension/state. Spectral Jensen on subnormalized positive states gives logarithmic moment contraction, without operator Jensen or equilibrium initialization.

Positive killing uses the FULL physical CPTP generator and all complete-loss legs. The canonical correction identity makes the entire killed map id_L tensor K_GB. For arbitrary correlations, initial LR minus killed final LR is a positive partial-trace effect with trace equal to survival loss. Immediate reduced writer accuracy therefore adds directly: no bath replacement or KSW square-root writer loss is needed.

The pulse counts actual H, cooling and retained bath during ideal bounded-depth control. Its joint Duhamel tail is small at fixed integrated LOCAL strength despite an O(N) global norm. The signed low-order map factors on the whole promised module. Compression of the actual map, maximally mixed logical initialization and logical partial trace give a CP/TNI gauge map within delta of the signed one, and pulse error <=2delta. No reference-dimension factor appears.

Energy filters, killed dwells and pulse surrogates remain CP/TNI and are NEVER normalized. This avoids postselection bias for correlated logical/gauge states. Their moments obey the same scalar law; their final LR deficit is positive. Complete-contraction telescoping closes the service error.

I ran 100 exact GF(2) synthetic filtered-complex tests of the paired-basis identity, contraction, inverse and nilpotent filtration; all passed (checks/FILTERED_NORMAL_FORM_RESULTS.json). These supplement the analytic proof only. They do not establish code expansion, asymptotic locality, lifetime or novelty. The independent Davies/Walsh/Steane checks also supplement proofs only.

## 5. Import, review and scope

The Li selected-port condition is retained: selected binary 1-components carry the CCZ payload; unused binary and complementary logical coordinates start in computational zero. Its physical gate preserves the whole code, but literal selected-CCZ action is not asserted on arbitrary full logical input. Storage preserves the initialized complements. Transporting gates through duality does not earn an independent universal Hadamard.

Auditor's version-bound PASS covers principal/THERMAL_SERVICE_THEOREM.md hash bb4e12ae7cc82ed68f94d4b162f6c9a85e08671fd88b805a510ee47058666b40, through Section14. Its review checks actual primary Li charts, dual PRS assumptions and selected ports. No blocking gap remains at that structural model. It is an internal mathematical review, not external validation or priority.

Hong--Guo--Lucas already provides passive qLDPC Gibbs sampling. Bombin et al. already provides thermal protection, sudden-noise tolerance and transversal gates. CSS normal forms, nilpotent perturbation theory, Knill--Laflamme, Lyapunov estimates and quantum I/O are established machinery. The scoped construction derived here is the exact two-sector energy on the recent gate code and its uniform nonstationary repeated noisy-gate service. First priority is UNKNOWN.

The decisive open physical operation is an economical realization of this basin/service with a specified finite-bandwidth microscopic thermal environment and small interactions, or a nonstationary warm theorem for the separate original three-body model. Exact Markov cooling is a declared primitive, not an exponential-time weak-coupling theorem. No total-resource advantage, practical threshold or 95+ capability is established.


## 6. Restricted physical ports and final clarifications

The separate encoded-port closure and coherent decoder passed the final hostile review at their frozen versions. It uses CFG Lemmas40-42 directly, not a diamond upgrade of operational Theorem53. Both short SWAPs retain the actual old hardware/bath as auxiliary; isolated staging treats its correlations as references. Coherent recovery has waiting-inclusive size O(n^4), accuracy parameter ell=O(n), and polynomial paid ports. The final capture cutoff is chosen BEFORE beta/eta, with u_dec no larger than the core service post ceiling and nu_eq below both new capture and service pre thresholds. Extra dwell alone cannot overcome nu_eq.

The dossier consistency reviewer found no blocking A-E mismatch. I applied the suggested explicit naming of CFG's already-retained noiseless classical premise in Theorem E, and noted the existing gauging/magic-fountain baseline in the screened future connection. These clarify/limit scope; they add no theorem or physical capability. The exact final dossier hash is recorded separately from the reviewed earlier editorial hash. All frozen mathematical source/review files remain byte-identical.
