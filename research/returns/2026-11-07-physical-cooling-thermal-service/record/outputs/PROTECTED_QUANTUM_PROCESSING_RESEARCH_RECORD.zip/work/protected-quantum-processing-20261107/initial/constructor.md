# Independent constructor: a noisy entry theorem for powered native memory

7 November 2026, Brisbane. GPT-6.1 Sol, maximum reasoning. Independent initial report; no peer report or intermediate construction was read before freezing this file.

## Verdict

I obtain a constructive mathematical repair of the Gibbs-domination obstruction **for N1388's powered native memory**: admit a noisy writer by its extensive exponential energy moment and a correctable support, rather than by global Gibbs domination. A constant positive density of terminal faults can satisfy the required moment and produce exponentially small basin-entry failure. I also derive a coherent version that includes the entire always-on native apparatus and the actual retained bath during a short pulse.

This does not close N1694's passive thermal writer. An expensive hybrid protected processor is proposed below: FT staging, separate terminal release towers, exponential native HOLD, capture into FT staging, actual decoding, CNOT and reload/readout. It does not require repeated recovery during HOLD or bath switching. Its complete implementation remains a **candidate**, because actual terminal-tower/native-table constants have not been compiled. There is no practical or historical priority claim.

## Source boundary

Read: AGENTS.md, the workflow, four supplied Markdown originals, five supplied packet statements/contracts, the existing exact-H consumer's noisy-admission section, and the four mandatory external primary comparators.

Frozen load-bearing files:

- N1388 compiler SHA256 0af0dc529eb96a359f9f5d0f9f00972ec90f1817dc2cb4753d95f196bd3f4f18.
- N1388 interface SHA256 59c71b1c154457a0092b07610637eeb9a4f660c506f5277b43dbdd63d7b07155.
- N1694 thermal SHA256 20ebf769e83ca532a49d4273961222f9f453face47fea68f83be43a150be852f.
- N1694 limits SHA256 c763ec16339b3bbc109d2e06cc85773001652d7eccc3c87be977a80b12c552e9.

Source repository pin supplied by principal: 30712044febf7fccbe5ff5c0f93ada5ccf9dc3d5; reported later HEAD d490a9d4429a8152902cebb32fd67c1e4c9285b2.

I additionally inspected the preserved N1388 whole reviews and FIXED_PRODUCT_DECODER_SPAN.md in the source repository, rather than treating their packet assertions as a new reproof. The N1388 packet carries substantive completed whole PASS reviews of the SAME compiler/interface. Candidate headings in the originals are historical; the accepted scope stands.

Its precise capital is a constant-rate, linear-distance CSS/Tanner family, local unary energy U, actual controller-history flags B_h, confinement U>=h r in a common strict reduced-weight radius, positive active-hub density, energy-lowering idempotent local payload, and the SAME powered finite native controller with its resets/monitors/aborts. Full interval-CPTP joint dynamics, bounded-body pointwise per-site JOINT cb-norm noise, and CP/TNI killing remain required. Encoded/native-ready initialization or an independently earned warm channel is supplied. Ideal fixed native forest inversion and DATA recovery are still output resources.

The primary review explicitly budgets fixed forest cones of physical local operators. I use that support property. I do not assume that every forest inverse is already a constant-depth noisy physical circuit.

N1694's all-number-sector clocks and isolated ideal loader remain separate from actual interacting bath preparation. N1418 is a known Bell-target powered buffer; arbitrary unknown-input transfer is separate. N1645 and N1734 provide no additional available full theorem.

## 1. Accepted native energy basin, independently checked at the needed algebraic steps

Use combined N for a fixed number of blocks and

    E = U + R sum_h B_h.

The accepted positive observable F has, on the basin P,

    F <= exp(g N) exp(s E),
    F >= exp(-q_t N) exp(s' E),       s'=s-kappa_D/R>0.

For the CP/TNI killed state, x(t)=Tr F rho_P(t),

    log x(t) <= nu N + [log x(0)-nu N] exp(-lambda t/s),
    nu=g+s rho/lambda.

I checked the scalar spectral Jensen argument and flag-sensitive no-jump lower bound in the actual originals. The latter avoids a fixed extensive loss on every good controller site. The source/target confinement argument needs BOTH a weight cutoff and an energy cutoff:

    P={r<r_0 N, E<e_cut N}.

A warm input has exact intended logical action in P and

    log Tr F Gamma(I/d_L) <= nu_w N+O(1),
    max(nu_w,nu)+q_t < s' e_cut.                         (1)

Its acquired ideal-framed full-diamond retention bound is

    ||Dec S_t Gamma-id_L||_diamond
        <= C N(1+t)exp(-bN),                            (2)

for fixed b>0. Internally correlated auxiliary/bath states are allowed, but they must be independent of the unknown logical/reference input in this frame. This contracts a moment, not logical trace distance or arbitrary initial states.

## 2. A proved sparse-release admission theorem

Assume ideal encoded/ready initialization, E=0, with arbitrary unknown logical/reference input and fixed logical-independent auxiliary/bath state.

A real final release circuit has M<=cN fault locations. Its fault set F satisfies

    Pr(A subset F)<=p^|A|

for every location subset A. Each faulty location may be an arbitrary local CP operation retaining a common bath, and has a complete forward cone on at most b native cells. The native frame and local energy ranges imply on a fault history

    r_DATA<=b|F|,       E<=Kb|F|.                       (3)

Assume the entire operator span with this low support has the acquired canonical logical action. This follows from code distance for sufficiently small support, with the same frame/decoder convention, rather than from a Pauli-mixture claim.

Choose zeta>0 with strict margins

    b zeta<r_0,  Kb zeta<e_cut,  2b zeta<delta,

where d_N>=delta N, reserving any bounded source/target enlargement. Let m=floor(zeta N).

Then the bad release mass obeys

    delta_N<=inf_(z>1)
       exp{cN log[1+p(z-1)]-m log z}.                    (4)

The normalized good writer is exactly logical identity tensored with a positive auxiliary/bath state, and

    log Tr F Gamma_good(I/d_L)
       <=gN+cN log[1+p(exp(sKb)-1)]
               +log[1/(1-delta_N)].                    (5)

Consequently, if

    nu_w=g+c log[1+p(exp(sKb)-1)]

obeys (1), physical release followed by the actual native HOLD has half-diamond error

    <=delta_N+C N(1+t)exp(-b_1 N).                       (6)

For sufficiently small fixed p>0 both exponents are positive. This is a real nonstationary entrance theorem, with no Gibbs domination.

Proof: for z>=1 expand

    z^|F|=product_i[1+(z-1)1_(i in F)].

The inclusion bound gives E z^|F|<=[1+p(z-1)]^M; exponential Markov yields (4). On each low-support branch, equal-syndrome products differ by a stabilizer while different syndromes are orthogonal. The full coherent correctable error span therefore acts as id_L with arbitrary ancillary coefficients. This is linear in arbitrary logical/reference operators. Each good CP branch factors, including its probability. Equation (3), F's upper bound and the same generating function give (5). Normalize, apply the existing warm theorem and charge the bad mass. QED.

This is a theorem for the FINAL bounded-spread release after real FT preparation. Applying it to the complete polynomial-depth bare encoder or thermofield circuit would be false.

## 3. A proved coherent support-expansion version

Here coherent fault histories need not form a CP instrument.

Let an actual CPTP writer admit an absolutely convergent expansion

    Gamma=sum_(r>=0)Gamma_r,
    sum_r z^r||Gamma_r||_diamond<=exp[N a(z)]             (7)

for z>=1 in the used range. The norm retains the bath. Each term's left/right system error coefficients are supported on at most br cells, arbitrary bath coefficients are allowed, and its energy support is E<=Kbr. All r<=m terms lie in P's correctable neutral span.

Define delta_N=exp[N a(z)-m log z]. If delta_N<1 there is an exact P-supported normalized logically neutral CP warm writer Sigma with

    ||Gamma-Sigma||_diamond
        <=2 sqrt(delta_N)+4 delta_N,                    (8)
    log Tr F Sigma(I/d_L)
        <=[g+a(exp(sKb))]N+log[1/(1-delta_N)].           (9)

Proof: truncate at m to Gamma_le_m. It is logically neutral and P-supported but need not be positive. Its diamond distance from actual Gamma is at most delta_N. Hence the actual output's mass outside P is at most delta_N, uniformly with reference.

Let Gamma_P(X)=P Gamma(X)P. Gentle projection gives ||Gamma-Gamma_P||_diamond<=2sqrt(delta_N). In the canonical factorization write Gamma_le_m(X)=X tensor sigma_0, allowing nonpositive sigma_0. Put

    sigma=Tr_L Gamma_P(I_L/d_L).

It is positive, trace at least 1-delta_N, and ||sigma-sigma_0||_1<=delta_N by compression and partial trace. Thus ||Gamma_P-[X->X tensor sigma]||_diamond<=2delta_N. Normalizing costs at most delta_N. This proves the conservative (8). Since P commutes raw E, the positive compressed state's moment is at most the absolute weighted series at z=exp(sKb); F's upper bound proves (9). No signed term or truncated map is called a physical prepared state. QED.

### Actual bath and always-on apparatus during a pulse

For a bounded-depth parallel control circuit of total duration tau, retain the actual bath-only CPTP propagators. Treat the complete native Hamiltonian/controller/reset terms and allowed joint perturbations during this short pulse as disturbances. Suppose every term has system body at most q and

    integral sum_Z||L_Z(u)||_cb du<=A N tau.

Partial ideal control layers enlarge supports only by a fixed cone. Time-ordered Duhamel expansion, inserting bath-only CPTP propagators between terms, gives

    sum_r z^r||Gamma_r||_diamond<=exp[A N tau z].          (10)

Absorb q and cone growth into b, or count cells and use a(z)=A tau z^q. There is no inverse bath map, reduced-system Markov approximation, bath refresh or bound on the bath self-Hamiltonian. The full physical channel must be CPTP.

For m=zeta N a fixed z>1 gives exponent A tau z-zeta log z. Fixed short tau makes this negative and also makes the moment coefficient A tau exp(sKb) small. Required local control strength O(1/tau) is fixed independently of N. This differs from demanding globally no disturbance, which would require tau=O(1/N).

A fixed local calibration fault strength epsilon for cN terminal locations adds c log(1+epsilon z) to a(z). All clocks/controllers and their physical couplings are counted.

### Finite physical reset

For complete onsite reset D_i,

    exp[kappa tau_R(D_i-Id)]
      =D_i+r(Id-D_i),      r=exp(-kappa tau_R).

The product expansion has weighted norm at most (1+2rz)^(c_R N), starting from an arbitrary old controller/bath state. Untouched cells are reset and decoupled. Interleave native terms by Duhamel, charging every touched cell to their support. A conservative bound is

    a_reset(z)<=c_R log(1+2rz)+A_R tau_R z^q.             (11)

Choose fixed small r and short tau_R, paying fixed large kappa=log(1/r)/tau_R. This uses an actual powered reset reservoir, not an acquired thermal state.

## 4. A fully charged hybrid construction to challenge

### FT import and its exact restrictions

Aliferis-Gottesman-Preskill, quant-ph/0504218v3: Theorem 1 (pp.12-13) is an independent-stochastic circuit threshold; Theorem 6 (pp.52-53) allows local non-Markovian gate couplings through a common bath with arbitrary bath Hamiltonian. Sections 7-8 supply gadgets. Their pp.12-13 explicitly retain the O(p) unknown-bare-input and final-bare-output floors. Section 12 charges parallel gates and fresh/reset ancillas, and identifies ideal fast classical processing/nonlocal gates in their numerical example.

I do NOT use their numerical 2.73e-5 threshold for a different layout or noise model. Measurement-free nearest-neighbor gadgets are instead available in Aharonov-Ben-Or quant-ph/9906129v1, Theorems 4,5,15, explicitly checked as an import by 2601.20818v3 Lemma 4. Classical processing can be compiled into protected circuits rather than assumed flawless.

Staging must satisfy the selected theorem's fault-location norm model. N1388's more permissive arbitrary-moving-partner HOLD contract does not alone imply that FT preparation theorem. A shared-bath gate-local subclass supplies a legitimate explicit model.

### Write

Choose a constant number of unknown payload qubits and initialize unused logicals to known states. Binary symplectic elimination gives a Clifford encoder; conservative serial routing uses O(N^3) logical gates. Run it in concatenated FT staging with separate output blocks.

Descend through a SEPARATE decoding tower per native output. At the last level use finite recovery-then-unencoding; fault-free terminal recovery removes admitted first-level errors. Different towers share no final physical gadget.

With eta_(j+1)<=A eta_j^2,

    eta_j<=A^-1(A eta_0)^(2^j).

A tower uses a fixed number of level-j decoding locations per step. The sum of terminal strengths is C sum_j eta_j plus its last physical gadget, hence fixed O(eta_0). A faulty tower affects only its own native output register. This gives a sparse/weighted support interface rather than exponentially small error on every bare carrier.

The last statement is a specific GADGET OBLIGATION, not a threshold theorem with an ideal decoder appended. Actual tower location/cone constants for the grouped native dimensions have not been enumerated in this report.

Reset target controllers by (11), then parallel SWAP staging outputs into native DATA. The old target state becomes part of the discarded staging environment. Include all target/bath motion during release by (10). Use (4)-(9) for basin entry.

Parameter order: native code/controller proof margins; support constants; strict warm margin; target release strength and reset r; pulse durations; physical control/reset strengths; actual staging noise below its chosen threshold; then N. Rates are fixed before N and T.

### Input/reference guarantee

The unknown input may be entangled with an external reference but must initially be independent of the actual hardware bath. A compatible protected input can have exponentially small input error. A single unknown bare qubit at fixed p has an unavoidable O(p) first-encoding floor. For a constant number of payloads the total guarantee is

    epsilon_in+poly(N)(1+T)exp(-cN),

with epsilon_in=O(p) at a bare port or the declared protected input error. No exponentially accurate bare-input claim is made.

### HOLD

Run the SAME powered native apparatus for T up to exp(c'N), below (2)'s exponent. No staging system retains the payload and no external decoder/reset is performed during HOLD. Native powered resets and entropy export continue.

### Actual recovery, useful CNOT, and readout

At a chosen time, the native moment permits a proof projection to E<=alpha N, with alpha a small fixed value above the moment coefficient:

    Pr(E>alpha N)
       <=exp[-(s'alpha-q_t-max(nu,nu_w))N].

This is an exponentially cheap proof truncation, not a physical recurrent recovery.

Capture ALL DATA and controller registers by parallel SWAPs to staging and build separate FT encoding towers. The native apparatus continues during capture. Include its complete motion and bath by (10); tower faults affect the corresponding native register only. Fixed forest cones turn a sparse captured support into O(sparse support) DATA error.

Implement the acquired explicit native forest inverse inside FT staging. It needs polynomial circuit size, not constant physical depth. Missing actual forest tables would be a real implementation/source gap.

An efficient DATA decoder can use the supplied active-hub property: scan O(N) local hubs, choose an active hub, apply its table correction and repeat. Each accepted move lowers integer U by at least one; the basin source/target argument prevents logical crossing. At most O(N) moves give U=0, with a conservative O(N^2) table-evaluation circuit plus routing. An exponential minimum-weight search is unnecessary in this low-energy basin.

Small enough fixed capture noise and initial alpha preserve the common strict radius/energy margins. The entire coherent correctable span, with bath coefficients, recovers payload/reference. Execute this decoder fault-tolerantly to exponentially small internal error.

Recover two payloads into protected staging registers, perform their logical CNOT with an actual FT gadget, and optionally reload both native memories. This is a nontrivial entangling operation in a protected active representation, fully charged. It is not an autonomous native CNOT or passive phase gate.

Readout is an encoded quantum output in a compatible FT receiver, or an FT logical measurement returned as a protected classical packet. Decoding to one noisy bare qubit/bit adds its O(p_out) port floor. The CP-span identities preserve the joint reference/measurement instrument, not just a marginal probability.

A fixed number of capture/reload operations suffices for one gate between exponential HOLD periods. There is no short-interval active recovery hidden in the HOLD proof.

## 5. Resource bill and comparator

Let B be the complete physical space factor per concatenation level, L the maximal gadget location count, D its maximal depth, and A the actual noise-renormalization constant. All include ancillas, local dimensions and routing.

For delta_int=exp(-chi N), choose

    2^ell >=[chi N+O(log N)]/|log(A eta_0)|.

Then conservative costs are:

- Native HOLD: O(N) fixed-dimensional native/controller sites and bounded-degree couplings.
- Staging peak space: O(N B^ell)=O(N^(1+log_2 B)).
- Preparation/recovery locations: O(N^3 L^ell)=O(N^(3+log_2 L)).
- Staging depth: O(N^3 D^ell), times gate duration.
- Terminal pulses/resets: constant duration and constant local strength independent of N; possibly enormous.
- Native integrated reset/monitor service and coupling-time opportunities: O(NT) at fixed rates.
- All code tables, routing, source knowledge, program memory, reset entropy export and refrigeration remain charged.

This is graph-local grouped-site hardware. A finite-density Euclidean embedding of Tanner edges and simultaneous staging ports is additional work. Ideal dissipator resources do not supply a microscopic refrigerator, finite fuel inventory or work-per-reset figure. These remain unquantified and preclude a practical full-cycle claim.

The equally equipped active comparator can retain the input in staging throughout T or use the supplied scheduled Tanner memory with noisy local classical processing. At T=exp(cN), ordinary concatenated FT has ell=O(log N) and polynomial space. Good qLDPC active schemes may have better space scaling under their actual models. The powered native scheme has no proved total space, energy, threshold or full-cycle advantage.

## 6. Primary comparators and priority

- **3D passive:** Balasubramanian-Davydova-Lin, arXiv:2605.10943v1, Theorems 3.16,5.13 and Corollary 5.14: bounded-density 3D CSS thermal memory under Gibbs-stationary local Lindbladians. Section 1.4 explicitly leaves efficient initialization separate. Its thermal encoding is not the noisy powered interface here. https://arxiv.org/html/2605.10943v1

- **2D autonomous computing:** Duennweber-Styliaris-Trivedi, arXiv:2601.20818v3, Theorem 1: discrete-time self-simulating QCA under Definition 3 local fault-path noise. Section VI discusses initialization/readout. The continuous-time extension is an OUTLINE; the text expressly leaves its formal proof for future work. Universal autonomous computation is already prior art in the discrete scope. https://arxiv.org/html/2601.20818v3

- **Latest noisy preparation:** Zhao-Yuan-Han-Liu, arXiv:2609.39965v3, Theorem 1: linear soundness gives local-stochastic residuals; linear confinement gives decoder-defined logical correctness after ideal recovery without that residual guarantee. Its specified CSS-sector preparation channel/decoder convention does not automatically load arbitrary unknown native DATA/controller/bath states. https://arxiv.org/html/2609.39965v3

- **Generic simulation:** Cubitt-Montanaro-Piddock, DOI 10.1073/pnas.1804949115, full arXiv:1701.05182v4, Proposition 29: time-evolution error <=2epsilon t+4eta. Section 8.5/Theorem 32 need explicit local encoding and low-energy leakage control. A generic approximate gadget requires lifetime-scale accuracy and is not a substitute for this exact native model. https://arxiv.org/html/1701.05182v4

The existing exact-H consumer's inverse-rarity ideal-access storage and Bell/channel correlation criterion remain established prior programme capital, not new results here. Its harmless product-gauge heating obstruction remains valid. The present proof uses N1388's different powered Lyapunov basin. Historical novelty of the support-moment interface is UNKNOWN.

## 7. Failed repairs preserved

1. Global Gibbs domination can cost (b/a)^N even for harmless heating. Replaced by energy moments.
2. Short-time admission cannot be iterated passively without a real reset. Not used.
3. Faulty unary clocks can reverse a neighbor's preferred state; missing-check substitution is invalid.
4. Clean terminal clock/controller release is not assumed.
5. Isolated ideal preparation is not actual correlated-bath preparation.
6. Global no-disturbance pulse accuracy demands N-dependent strength; sparse basin admission permits fixed local strength in the powered model.
7. An ideal forest/decoder appended to a theorem is not noisy readout; capture and protected execution are explicitly charged.
8. A bare unknown input or one bare output cannot have arbitrarily small error at fixed physical noise.
9. Powered native correction is not a new passive phase; 2D autonomous universal computing remains a strong predecessor.
10. Generic approximate Hamiltonian simulation has t epsilon error and cannot supply exponential fixed-accuracy HOLD for free.

For N1694, an analogue of the actual nonstationary moment/basin inequality is still missing. The equilibrium bad-projector tail alone does not provide one, and N1388's powered correction drift cannot be transplanted into its passive Hamiltonian.

## 8. Status ledger and challenge target

| Claim | Status |
| --- | --- |
| Sparse terminal faults give exponential admission probability and small extensive energy moment | PROVED under explicit physical release hypotheses |
| Coherent support expansion gives positive reference-safe warm surrogate | PROVED |
| Bounded-time always-on controller/common-bath pulse gives weighted Duhamel bound | PROVED for bounded joint-norm physical dynamics |
| Finite powered onsite reset supplies sparse controller preparation | PROVED in the reset-generator model |
| N1388 warm entrance for such a release | PROVED conditional application of accepted N1388 |
| Complete staging/capture/CNOT/readout hardware | CONSTRUCTIVE CANDIDATE; actual gadget/table constants uncompiled |
| Exponentially accurate unknown bare input at fixed positive noise | FALSE without input-error allowance |
| N1694 passive noisy-write-to-long-HOLD | OPEN |
| Practical or total-resource advantage | NOT ACHIEVED |

First challenge the support-expansion-to-positive-warm-channel argument and the terminal-tower/capture fault accounting. If they survive, compile actual grouped-dimension gadgets/native forest tables. For the user's passive goal, the decisive missing operation remains a nonstationary defect/bath theorem for N1694; this powered alternate mechanism does not claim that success.

