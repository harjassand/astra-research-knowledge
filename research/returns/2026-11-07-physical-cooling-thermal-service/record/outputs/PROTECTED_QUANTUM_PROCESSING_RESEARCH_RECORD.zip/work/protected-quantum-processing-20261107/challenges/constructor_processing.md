# Constructor cross-challenge: finite-time joint gate service with cooling left on

7 November 2026. Follow-up after all independent initials were frozen. Initial constructor remains unchanged at SHA256 21d053255b8337a37f057f0c367d8a06043e9bfa1964c9929a31e69e4053be60.

Read after freeze: principal/qltc_thermal_descent_route.md; the auditor's initial; machinery's initial. This note resolves the finite-pulse positive-surrogate operation and repeatable service induction under precise code/cooling assumptions. It does not resolve the qLTC local-descent import, microscopic realization of an engineered Davies reservoir, or the actual quantum-I/O gadget catalogue.

## 1. Constructive conclusion and what is genuinely added

A finite-depth code-preserving gate can run for a fixed positive time with the complete cooling generator, storage Hamiltonian and actual common-bath perturbations still present. At fixed sufficiently short duration and fixed sufficiently accurate local controls:

- a low-order joint Duhamel series has a correctable operator span;
- its high-order remainder has exponentially small complete norm;
- compression of the ACTUAL CPTP channel gives a positive exact-logical surrogate retaining the same bath;
- a constant cooling dwell restores the pre-gate moment coefficient;
- this repeats for a growing number of gates, with total error proportional to total HOLD time and gate count.

This is a proved service implication. The logical operation is the actual ideal control circuit, not a target-dependent reader. It may be CNOT or a compatible non-Clifford fixed-depth gate. General passive qLDPC memory/Metropolis completion and finite-depth measurement-free QEC have predecessors, including Hong–Guo–Lucas arXiv:2403.10599 / Nat Commun 16,316(2025); those are not claimed new here.

The physical open-system model is a specified local engineered cooling generator plus actual retained perturbation bath. It does not take an inaccessible correlated Gibbs state as a free initialization. A microscopic implementation and thermodynamic bill for those engineered cooling rates remain material hardware assumptions.

## 2. Exact code and storage hypotheses

Let N count all physical DATA cells in a fixed number of code blocks. Local dimensions, body sizes and incidence bounds are fixed.

C_N is a commuting stabilizer code of distance at least delta N. Its integer syndrome-block energy is U_N, with H_N=J U_N and ground space C_N. There are at most c_U N nonnegative commuting local terms, each norm at most one and each cell incident on at most D checks. Hence an arbitrary operator supported on w cells, applied to a codeword, has energy support U_N<=D w. Field/stalk block projectors are allowed if this locality and integer-energy statement is verified for the actual code.

For every valid syndrome sigma with U_N(sigma)<=u_cut N, select a fixed canonical Pauli correction E_sigma with

    wt(E_sigma)<=C U_N(sigma).

C is fixed. This is a **syndrome-repair/soundness** hypothesis. Merely knowing that an existing small error has confinement does not supply it globally. A Tanner implementation can instead keep the native weight+energy basin and use its fixed canonical frame; that adaptation is discussed in Section 9.

Fix a logical basis and the corresponding canonical isometry

    W: L tensor G -> S,

with W(|psi> tensor |sigma>)=E_sigma Enc|psi>, extended over unused syndromes once. P_u denotes the projector U_N<=uN in this frame and acts as I_L tensor P_(G,u). Extend W with the identity on the actual bath B.

Assume the actual nominal cooling generator plus allowed joint perturbations has the following already-earned killed-basin theorem on P_(u_cut):

1. Full joint interval-CPTP physical propagators and CP/TNI killed compression exist.
2. Its killed channel is exact logical identity tensor a CP/TNI ancillary/bath map.
3. For V_s=exp(sU_N), x=Tr V_s rho_P,

       (log x)'<=-(a/s)log x+bN,

   or equivalently its moment coefficient contracts toward

       nu_eq=s b/a.

4. If a P_(u_cut)-supported positive input has x(0)<=exp(nu_0 N), the complete physical-versus-killed difference is bounded by

       C_H N t exp[-(s u_cut-max(nu_0,nu_eq))N/2+O(1)].

The factor 1/2 reserves the usual coherent gentle/Duhamel loss. No stationary Gibbs domination is assumed. This is the nonstationary storage theorem that principal must finish from actual local descent and the joint perturbation calculation.

The actual reservoir, bath correlations, and all terms used in storage are retained during every gate below.

## 3. Ideal gate and explicit scale choices

Let G_N be an actual code-preserving unitary circuit with depth d and bounded gate body k_g, with d,k_g fixed independently of N. It implements a specified logical U_L. Every suffix and partial gate interval has forward/inverse support spread at most B, fixed. A non-Clifford is allowed: arbitrary local errors expand in the entire operator basis on the enlarged support, not in single Paulis only.

Let q bound the physical system body of any background joint generator term. During the gate, use the full background generator:

- storage Hamiltonian J U_N;
- every intended cooling jump and anticommutator;
- any coherent Lamb shift included by the actual model;
- allowed system/bath perturbations;
- local control calibration errors.

Choose a post-gate ceiling u_post strictly satisfying

    0<u_post<u_cut,
    u_post(C+1/D)<delta/4.                                (3.1)

A conservative simultaneous choice is

    u_post=min[u_cut/4, delta/(16(C+1/D))].

Set

    u_pre=u_post/(4 D B C),
    alpha=u_post/(4 D B q).                              (3.2)

For r<=floor(alpha N), a pre-gate canonical Pauli has weight <=C u_pre N. After the ideal gate and r background insertions, each error coefficient has support at most

    w_post N := B C u_pre N+B q r
              <=u_post N/(2D).                         (3.3)

Thus its output energy is <=u_post N/2 and certainly lies in P_(u_post). Moreover

    wt(actual error)+wt(canonical correction)
       <=(1/D+C)u_post N<delta N/4,

so the selected post-gate canonical correction assigns the intended logical U_L. This checks the decoder convention rather than silently changing it at each gate.

Choose physical cooling/noise parameters so

    nu_eq<=s u_pre/4.                                    (3.4)

This is a genuine quantitative requirement on the actual local-descent constants, finite temperature and perturbation strength, not a result of the gate proof.

All inequalities have fixed positive slack. Increase N_0 for integer roundings.

## 4. Weighted joint Duhamel expansion, with no bath switching

During the pulse let K_ctrl(t) generate the ideal bounded-depth control circuit. Let T_B(t,s) be the actual bath-only CPTP propagator. It can contain arbitrary bath memory/self-dynamics and may be time dependent. The reference propagator is the ideal system control times T_B. These maps preserve system support; they are not inverted.

Write the remaining joint generator as sum_Z L_Z(t). Assume

    integral_0^tau sum_Z ||L_Z(t)||_(diamond/joint) dt
        <=mu N.                                         (4.1)

The Heisenberg cb norm and Schrödinger complete trace norm are dual here. Each L_Z is normal and has system support of at most q cells; its bath support and correlations can be arbitrary. Individual L_Z may be HP signed terms. Full physical propagation must be CPTP; the decomposition alone does not grant that.

The variation-of-constants expansion is

    Gamma_tau=sum_(r>=0) Gamma_r,

where r counts background insertions. Between insertions are ideal-control/bath-only CPTP propagators, complete norm one. Therefore

    ||Gamma_r||_diamond<= (mu N)^r/r!.                    (4.2)

After moving system error legs through only the ideal control suffixes, each coefficient has system support increased by at most Bq per insertion. Intervening bath-only maps preserve that system-support assertion. This argument retains the actual bath in every norm.

For m=floor(alpha N), if mu<alpha, the tail obeys

    delta_g:=||sum_(r>m)Gamma_r||_diamond
       <=sum_(r>=m+1)(mu N)^r/r!
       <=(e mu/alpha)^(alpha N)/(1-mu/alpha).             (4.3)

Choose

    mu<=alpha/(8e).                                      (4.4)

Then delta_g<=2 exp[-alpha N log 8].

A useful explicit budget is

    mu=A_bg tau+c_cal epsilon_cal+2c_loc p_gate,           (4.5)

where A_bg bounds all physical background joint norms per DATA cell, epsilon_cal is an integrated local calibration error, and independent stochastic faulty physical gate channels have probability p_gate at <=c_loc N locations. A fault channel minus its ideal channel has diamond norm at most two; expand it with the continuous insertions. The combined generating function is bounded by exp[mu N z], after absorbing their fixed spreads into Bq.

One may impose each of the three terms in (4.5) <=alpha/(24e). Thus tau and physical local control errors can both be fixed independently of N and the runtime. Reducing tau alone does NOT suppress a fixed fractional coherent calibration error proportional to the pulse strength. Such errors must be included in (4.5).

Peak local control strength is O(d/tau); with tau=O(alpha/A_bg), this is O(d A_bg/alpha), a fixed potentially huge ratio. No O(N) control strength is required.

The gate's ideal partial path can leave the storage basin. The proof never applies the storage theorem during that partial path; it uses bounded-support pulse errors and correctability only at the completed gate.

## 5. Positive exact-logical gate surrogate retaining the same bath

Here is the central constructive lemma.

Work in the fixed canonical frame. Let theta be ANY positive subnormalized state on G tensor B with support P_(u_pre), independent of unknown L/reference. Restrict the physical gate channel to this module. Let

    Q=P_(u_post).

By Section 3 every Gamma_r with r<=m has output support Q and, as a map on L with this ancillary input, satisfies

    Gamma_le_m(rho_L tensor theta)
       =U_L rho_L U_L^dagger tensor C_0(theta),            (5.1)

where C_0 is linear/HP but need not be CP. The error-span identity includes cross terms, code stabilizer phases, all initial syndrome coherences and arbitrary bath coefficients. It is valid on arbitrary logical/reference operators.

The actual map is CP. Define

    A_theta(rho)=Q Gamma_tau(rho tensor theta) Q,

and define the ancillary map, on the entire good G tensor B input algebra,

    C_g(theta)=Tr_L [
       Ad_(U_L^dagger tensor I) A_theta(I_L/d_L)
    ].                                                   (5.2)

Equivalently the U_L conjugation can be omitted under the partial trace. C_g is CP/TNI: append I_L/d_L, apply the actual CP/TNI compressed physical map, and trace L. No guessed density matrix or negative truncated series is used.

Define the positive surrogate on this module by

    S_g(rho_L tensor theta)
       =U_L rho_L U_L^dagger tensor C_g(theta).            (5.3)

It is a CP/TNI tensor-product map. It has exactly the intended logical action and output supported in Q. In particular, every output has raw moment <=exp(s u_post N) times its trace.

Because ||Gamma_tau-Gamma_le_m||_diamond<=delta_g:

- output mass outside Q is <=delta_g Tr theta;
- gentle compression costs <=2 sqrt(delta_g) Tr theta;
- compression is contractive;
- partial trace of (5.1) at maximally mixed L gives
  ||C_g(theta)-C_0(theta)||_1<=delta_g Tr theta.

Hence, uniformly over L/reference,

    ||Gamma_tau(rho tensor theta)-S_g(rho tensor theta)||_1
       <=[2sqrt(delta_g)+2delta_g] Tr theta.              (5.4)

The same bound holds completely when an independent reference is appended; no d_L factor appears. We only claim the module norm relevant to the logically independent good input, not an unrestricted diamond approximation on arbitrary initially L–B correlated states.

This resolves the coherent-CP objection. The signed low-order map supplies a neutral algebraic approximation. The physical compression supplies positivity.

**Same environment:** C_g is a map on the ACTUAL G tensor B, including its preexisting correlations. It is not a reset to a fresh bath. At successive stages C_g acts on the preceding stage's ancillary state. Dropped branches are accounted by the complete trace-norm bound. Approximate correlation independence is never silently replaced by exact independence without paying that bound.

Normalization is unnecessary for the service induction. Using CP/TNI maps avoids nonlinear, state-dependent renormalization and keeps the survival deficits explicit.

## 6. Constant cooling dwell and gate-service induction

Let the good post-gate ancillary state have trace <=1 and U<=u_post N. Therefore x(0)<=exp(s u_post N). Under the actual killed cooling theorem,

    log x(t)<=nu_eq N+
                  (s u_post-nu_eq)N exp(-a t/s).

Choose the fixed dwell

    tau_c=(s/a) log(4u_post/u_pre).                       (6.1)

Using (3.4),

    log x(tau_c)<=s u_pre N/2.                           (6.2)

Then the pre-gate energy tail after any longer dwell is

    Tr[1_(U>u_pre N)rho_good]
       <=exp(-s u_pre N/2),                             (6.3)

and compressing away that tail costs at most

    epsilon_pre=2 exp(-s u_pre N/4).                     (6.4)

This is a proof projection on the gauge. It acts as logical identity, is CP/TNI, and is NOT a physical decoder/reset.

Define the good service composition:

1. killed cooling for the actual dwell;
2. gauge compression P_(u_pre);
3. positive exact-logical gate surrogate (5.3).

All maps are CP/TNI and exactly logical-covariant with the desired U_L. Their ancillary maps compose on the same bath. The first input can instead be any already-admitted correct logical warm input; charge its initial input error and apply the first cooling dwell.

For M completed gate bursts, total cooling/HOLD duration T, and every dwell at least tau_c, telescope actual physical channels against these positive good maps. Complete contractivity gives a full-joint difference bounded by

    epsilon_joint
      <=epsilon_writer
        +C_H N T exp[-(s u_cut-s u_post)N/2+O(1)]
        +M[2 exp(-s u_pre N/4)
             +2sqrt(delta_g)+2delta_g].                  (6.5)

The physical gate channels themselves are used when telescoping future error propagation, so their complete norm is one. The good maps have norm at most one. There is no multiplication by an exponential condition number, gate count inside an exponent, or logical dimension.

The final good map is

    rho_LR -> U_total rho_LR U_total^dagger tensor theta_T

with theta_T positive and trace a_T<=1 independent of the logical/reference input. Since the physical channel is TP, 1-a_T<=epsilon_joint. Decode the ideal fixed canonical factor and discard G/B. The final half-diamond logical error is at most epsilon_joint, conservatively, because full trace error is <=epsilon_joint+(1-a_T)<=2epsilon_joint.

For any fixed error target the service permits T and M exponential in N below the minimum of its explicit positive exponents. It supplies repeatability, rather than one ideal gate on a stationary thermal input.

No actual error correction/reset is inserted after every short interval. The actual physical operations between bursts are the fixed thermal cooling dynamics.

## 7. What is needed to turn this into an explicit full construction

The operation theorem above is mathematically closed conditional on Section 2. It is not closed merely by saying “qLTC.”

The remaining code-specific operations are:

- prove the bounded-star active-descent density for the exact dual complexes, not only existence of one improving move;
- prove canonical low-syndrome repair with the chosen integer BLOCK energy and exact binary/field conversion;
- check that the desired gate-code family has these same properties, including the actual gate's logical basis and block normalization;
- prove the actual CP/TNI killed thermal dynamics and its reference-safe boundary estimate;
- specify the local finite-temperature reservoir rates and every local body/incidence constant;
- supply a noisy writer and physical final readout in a compatible noise/control model, with charged port floors.

CNOT between identical CSS blocks has an immediate fixed-depth ideal circuit and is sufficient to instantiate a nontrivial gate once the energy-basin assumptions close. Transversal CCZ/non-Clifford gates should be imported only after the actual family/dual-complex match is checked. Universal computation additionally needs its other compatible operations.

An actual arbitrary quantum-reference writer should use the quantum-I/O theorem, not known-state preparation only. A system-only writer estimate is insufficient for the auditor's retained-correlation counterexample. Either the I/O theorem must retain the bath or this admission theorem must apply uniformly to the actual logical-independent auxiliary/bath complement.

## 8. Quantum ports and full resource accounting

For k unknown bare input qubits at fixed physical p, the auditor's sharp dephasing obstruction gives a global error floor >=1-(1-p)^k. For a fixed number of bare payloads an honest end-to-end statement is

    epsilon_in+epsilon_out+epsilon_joint,

with epsilon_in/out=O(p) for one bare port. Protected quantum ports can instead have their declared arbitrarily small encoded-channel errors. Known-state preparation alone does not remove the floor for an unknown input.

The gate service itself uses:

- O(N) DATA cells and O(N) local cooling terms, with fixed but potentially large local dimensions/body sizes;
- O(N) physical control gates per burst, fixed depth d, duration tau;
- maximum local control strength O(d A_bg/alpha);
- fixed cooling dwell (6.1), independent of N and total service length;
- integrated cooling/reset/entropy-export opportunity budget O(NT);
- O(NM) local pulse count over M bursts;
- actual local calibration precision bounded as in (4.5);
- classical gate selection, synchronization, and communication hardware.

These are still graph-local constants. A bounded-density 2D/3D elementary-qubit realization is not inherited. Specified Davies/GKSL reservoirs do not supply a microscopic refrigerator, finite-fuel work budget or exponentially long approximation to an arbitrary interacting bath.

Active FT receives the same fast controls, cooling, reset, routing, classical control and ports. At T=exp(cN), ordinary concatenated FT can attain small error with O(log N) concatenation levels and polynomial total hardware. Strong qLDPC active memories can do better under their actual hypotheses. Existing autonomous 2D universal computation is also a stronger universality predecessor. The present service implication supplies no favorable total-cost comparison by itself.

## 9. Native Tanner adaptation and the reason I prefer the qLTC service

The native N1388 warm theorem can replace Section 2's raw thermal drift. Its F has

    F<=exp(gN)exp(sE),
    F>=exp(-q_tN)exp(s'E),

and moment contraction to nu. The pulse positivity lemma is unchanged once a physical ideal circuit maps a low-E native module into a low-E target native module with bounded support. Pre-tail exponents become s'e_pre-q_t-nu_pre, and post moments are <=exp[(g+s e_post)N].

The difficulty is actual native-frame access, not coherent positivity. The source's fixed forest cones suffice for capture/release admission; they do not automatically supply a bounded-depth dressed CNOT circuit with a low-E endpoint. A fixed native forest inverse is still an ideal output operation in the acquired theorem.

The charged capture/FT-decode/CNOT/reload route in the constructor initial avoids falsely granting that circuit, but it is an active gateway and its actual gadget constants remain uncompiled. Principal's direct qLTC finite-depth gate route is stronger if its code/descent imports close, because no native forest must be physically unwound for each burst.

## 10. Checks, status and challenge response

The constructor's finite Steane/reference checks in constructor/check_admission.py and constructor/admission_checks.json verify the low-order neutral span, positive compressed gauge state, trace/tail bounds and moment majorant in three coherent cases. They also verify three exact Bernoulli generating functions numerically. These do not establish any qLTC family, native controller threshold or physical device.

Status:

- finite-duration joint pulse -> exponentially close positive exact-logical low-energy CP/TNI surrogate: PROVED under the explicit complete-norm/body/spread assumptions;
- cooling left on and actual bath retained: INCLUDED;
- repeated gate/cooling induction with explicit constants and no hidden bath refresh: PROVED conditional on Section 2's nonstationary basin theorem;
- actual qLTC local-descent/soundness and non-Clifford family imports: NOT established by this note;
- physical quantum ports and full microscopic reservoir: separate charged interfaces;
- passive three-body N1694 full processor and practical advantage: NOT ACHIEVED.

