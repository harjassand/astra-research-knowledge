# Hostile audit: exact stable CSS duality and the two-sector energy

7 November 2026. Subject: `../machinery/dual_sector_local_energy.md`, including its unweighted simplification. Independently checked primary GJ arXiv:2609.20780v1 Sections 6–8; formulas extracted to `../auditor/qltc_S7_extract.txt` and `qltc_S8_extract.txt`. This follows the independent initial freeze.

## 1. Verdict

The stable local normal form survives at the stated compatible-cosheaf hypotheses. It is an EXACT invertible basis change, not just a chainmap. Bounded propagation and inverse, plus the supplied clean-work circuit, give a stable finite-depth CSS Clifford. The common zero space of the two commuting energies is exactly the original code with fixed product ancillas; no small-distance auxiliary logical mode is added. Both sector descents are bounded-support physical Paulis preserving the opposite energy. Unweighted `U=U_F+U_K` is correct.

This closes the raw-transpose-descent obstruction for a MODIFIED Hamiltonian/product-ancilla architecture when actual simultaneous primal/dual GJ hypotheses hold. It does not prove local descent of raw transpose syndrome weight, identify the old three-body model with the new one, or establish universal computing.

## 2. Exact normal form

Use actual anchored coordinates `A^{r,p}=sum_(f<=u)Fcal(u)^*`, total chain degree n=p-r and primary maps (7.2)–(7.3). Lemma 7.1.1 proves `Delta^2=T^2=0` and `Delta T=T Delta`; characteristic two gives d²=0 for d=T+Delta, including endpoints.

Horizontally, at fixed upper face u, Delta is the finite cube cochain map. Its critical degree-zero constants are preserved by T: at each lower upper-face v the resulting value is `sum_(u>v)R_(uv)^T z(u)`, independent of anchor, exactly the transpose boundary D^T. Thus the critical inclusion is an invariant SUBCOMPLEX, not merely a homology choice.

Vertically, at fixed anchor f, Theorem 7.2.1 gives exactness below p=t and top kernel Kcal(f) in actual dual coordinates. Lemma 7.1.2 proves Delta preserves that top-kernel inclusion and induces the actual Kcal differential.

Choose normalized contractions `h²=hi=ph=0`. Perturb by delta=T horizontally or delta=Delta vertically. The inverses in

`h'=(I+h delta)^(-1)h`, `p'=p(I+delta h)^(-1)`

are FINITE polynomials: h delta strictly lowers p horizontally and raises it vertically. Since delta preserves the critical range, h delta i=0 and i stays unchanged. The finite perturbation identities give

`d h'+h'd=I-i p'`, `p'i=I`, `p'h'=h'i=0`, `h'^2=0`.

For every old pair d0 a_i=b_i define `a_i'=h'b_i`, `b_i'=d a_i'`. They lie in ker p', d a_i'=b_i', d b_i'=0. With i(H), they form a basis because the change is I+Q in the finite p filtration. Horizontal corrections strictly LOWER p. Vertical corrections to a_i strictly RAISE p; b_i has p one less than a_i, so delta a_i is already above b_i and d0 of higher-p corrections stays above it. Consequently `Q^(t+1)=0`, inverse `I+Q+...+Q^t`. Each product uses at most t fixed local cones, preserving bounded range/row/column degree. This is the missing exact invertibility check.

## 3. CSS circuit, ancillas and binary coordinates

At physical degree k an invertible binary coordinate A_k is a CSS Clifford: X supports transform by A_k and Z by A_k^(-T). Adjacent-degree coordinate changes replace stabilizer generating bases only. A pair k->k-1 supplies |0>; a pair k+1->k supplies |+>. Other pairs do not occupy physical degree k.

Sparse A and A^-1 have the exact clean-work circuit

`|x>|0> -> |x>|Ax> -> |0>|Ax> -> |Ax>|0>`.

The last step is parallel SWAP, not erasure. Both additions are bounded-degree bipartite CNOT graphs, so fixed edge colorings give constant depth. This works on arbitrary superpositions. O(N) temporary work is charged and returned ideally; its faults must be counted if the circuit is used. The abstract memory Clifford contains no work-register factors in the pulled-back energy.

Let U_H,U_V map horizontal/vertical normal forms into the anchored code. Both are pure CSS linear Cliffords. Then `C=U_V^(-1)U_H H_all` maps the original cochain code with the CORRECT product ancillas to the Kcal code with its ancillas. ORIGINAL ancilla types are the horizontal pair assignment pulled through H_all; one cannot choose them afresh afterward. Both total memory dimensions equal the anchored degree-k dimension.

Field conversion uses primal/TRACE-DUAL bases. Actual equation (7.6) requires inverse-transpose dual stalk charts; substituting primal charts would be wrong. Proposition 8.1.1 needs no orthogonal/self-dual basis.

Type convention: GJ Proposition 8.1.1 labels delta^k as H_X, while Li Definition 2.1 equation (2.7) labels it H_Z. Use Li's physical convention to keep its cubic phase gates. GJ distance/soundness/locality imports are invariant under global X/Z swap. State that convention rather than silently relabeling the actual gate.

## 4. Energy and both descents

Let U_F be the original Fcal cochain Z-syndrome BLOCK energy plus original Z-ancilla defects. Pull target Kcal Z-syndrome block energy plus target Z-ancilla defects back by C to obtain U_K. Because C=P H_all with P pure CSS linear, U_K is purely ORIGINAL X-stabilizer functions. Thus all terms commute; U_F enforces the full original Z group, U_K the full original X group including ancillas. Their common zero space is exactly original code tensor fixed product ancillas.

An F X correction commutes U_K exactly. A K X correction pulls back to original Z and commutes U_F exactly, with bounded support. Hence D_K=0 and U=U_F+U_K suffices. Apply the proved active-vertex lemma to Fcal in syndrome degree k+1 and Kcal in t-k+1 (both<t for 2<=k<=t-2), adding single-site correction labels for violated product-Z ancillas. At small linear total energy, active count is >=min(kappa_F,kappa_K)U. All chosen moves lower integer U by >=1 and preserve its opposite sector.

Kcal's hypotheses are genuinely available from GJ Theorem8.2.1 assumption(2): weighted product expansion of BOTH actual local code tuples and actual-coordinate dual tuples over every field extension. Its proof uses Theorem7.2.1 to identify Kcal charts and Corollary6.3.2 for both cosheaves in all four required degrees. Those exact hypotheses must match a Li specialization.

## 5. Distance, repair, gate transfer and verdict boundary

Appending fixed product states preserves absolute distance. Size grows by a fixed factor, so relative distance remains positive. Any normalizer action on a product ancilla can be stripped by its stabilizer; it cannot create an auxiliary logical qubit.

At sufficiently small linear U, perform F descents then K descents. Opposite energy never rises and at most initial U moves suffice. Their fixed support L yields a physical Pauli syndrome correction of weight <=L U into the EXACT common code. This earns a GLOBAL low-energy correction bound and therefore an energy-only canonical basin at small cutoff. It does not identify the intended logical input from energy alone.

A verified fixed-depth/spread gate preserving the ORIGINAL code extends by identity on the product ancillas and preserves the new ground code. It need not preserve U during its partial path: joint finite-interval expansion, positive module repair and cooling dwell handle that. For Li cubic gates verify the actual three degree-two complexes, trace-dual coordinates and bounded-incidence cubic catalog; edge-color overlapping hyperedges for fixed depth. Omit the OPTIONAL repetition construction unless a new energy transfer is proved. Address-selection control needs the actual local error contract; one unprotected global bit cannot set O(N) strong gates reliably for free.

No algebraic blocker remains in exact stable duality, distance/ancillas, CSS types, both-sector descent or transfer of a compatible finite code-preserving gate. Matching Li's actual family to the simultaneous GJ hypotheses and gate-coordinate catalog remains essential. No universal gate set, addressed Hadamard, noiseless programme, Euclidean implementation or favorable full-cost comparison follows. The nominal exact Davies-form reservoir remains distinct from the retained weak common bath and from a derived exact microscopic bath.
