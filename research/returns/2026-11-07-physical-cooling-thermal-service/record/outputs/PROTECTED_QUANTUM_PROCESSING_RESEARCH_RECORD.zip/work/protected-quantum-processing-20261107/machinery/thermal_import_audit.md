# Primary-source import and novelty audit for thermal protected processing

7 November 2026. Follow-up after independent reports froze. Sources are pinned in `sources/`; no historical-firstness inference is made from absent search results.

## A. Imports that actually match the proposed construction

| Source | Exact part inspected | What is imported | What is not imported |
|---|---|---|---|
| Gay--Granha Jeronimo, arXiv:2609.20780v1 | Lemmas 6.1.3/6.2.1, Proposition 6.2.2, Theorem 6.3.1, Lemma 6.4.1; equations 7.1--7.6, Theorem 7.2.1, Lemma 7.3.1 | Actual full-star local filling, support recursion, local cochain descent, anchored double complex and local transpose exactness; fixed primal/dual product expansion and arithmetic degree bounds remain upstream premises | Raw physical transpose syndrome descent does not follow directly from its global anchored-array filling; it is supplied here only by a changed commuting energy and stable ancilla extension |
| Li--Li--Han--Liu, arXiv:2609.26691v3 | Equation 3.20; Proposition 3.3; equations 3.31--3.33; Section 3.4; equations 3.223--3.227 | Three actual degree-two GJ-type sheaf complexes on a six-direction cubical quotient, fixed PRS profiles and dual profiles, complete local charts; addressable CCZ family on a selected linear number of logical coordinates | Headline good-code soundness alone is not used to infer descent. Optional repetition encoding is omitted. Full logical Clifford/Hadamard/code switching, universal computation and noisy ports are not supplied by the CCZ theorem |
| N1388 exact accepted sources | Current packet and both exact-hash whole reviews | Existing two-sector local integer distance energy with active density and confinement for Tanner codes; direct fallback input to the thermal compiler | No new code, no direct non-Clifford gate on that Tanner family, no elementary-qubit/Euclidean locality or numerical threshold |

### A1. Why the Li codes match GJ locally

The physical code is explicitly `C^1(X,F_a)->C^2(X,F_a)->C^3(X,F_a)` in equation (3.33). Equation (3.20) gives its fixed PRS degree profiles on direction pairs {1,2}, {3,4}, {5,6}. Equations (3.31)--(3.32) define the actual transported top-array sheaf, not only an abstract code of equal parameters. Proposition 3.3 supplies simultaneous full-star tensor charts. Section 3.4 checks uniform product expansion for both these primal profiles and coordinate-dual profiles: coordinate permutations/Frobenius relabelings and nonzero scalings preserve the required inequalities, while the arithmetic degrees can meet the parallel-walk expansion thresholds simultaneously. GJ Theorem 7.2.1 then constructs the ACTUAL kernel cosheaf from inverse-transpose local charts.

Use Li Definition 2.1/equation (2.7)'s physical CSS orientation: delta^k is H_Z. GJ Proposition 8.1.1 swaps the labels; its distance/soundness conclusions are invariant under global H, but physical corrections/gates require one explicit orientation.

The original physical binary cubic gates already have bounded incidence, hence fixed depth by hyperedge coloring (Li Section 2.4). Repetition is only required to make the supports pairwise disjoint in one layer. Keeping the original circuits avoids an unjustified energy/descent transfer through repetition.

### A2. Safe gate coordinates

In the preferred presentation, the common ground of UF+UK is exactly original Li DATA code plus the product ancillas obtained from the H-swapped horizontal contractible-pair normal form. Original DATA gates tensor identity on those ancillas preserve it. No gate conjugation is needed. In total-complex or K physical coordinates, conjugate by the explicit bounded-spread Clifford; charge the O(N) temporary work and fixed-depth sparse linear circuits. Both claims use equality of complete stabilizer groups, not homology dimensions alone.

## B. Predecessors that set the novelty boundary

### B1. Passive qLDPC Gibbs sampling and measurement-free QEC

Hong, Guo and Lucas, *Quantum memory at nonzero temperature in a thermodynamically trivial system*, Nature Communications 16,316 (2025), DOI 10.1038/s41467-024-55570-7; arXiv:2403.10599v3. [Primary](https://www.nature.com/articles/s41467-024-55570-7).

Theorem B.8 proves an exp(alpha sqrt N) mixing-time lower bound for expander hypergraph-product codes. Its hitting-time proof explicitly uses a specially chosen Gibbs-weighted ensemble on a decodable set A, rather than every noisy decodable preparation. Appendices E.2--E.3 implement Gibbs sampling through finite-depth measurement-free gates/resets and account for sufficiently small incoherent Pauli errors, tuning rates back to a sampler. This precedes the generic proposal to Metropolis-complete a local decoder and call the result passive qLDPC storage. It also contains an explicit active-versus-passive circuit-depth comparison. It does not supply the current all-state exponential moment, generic bounded-body joint HP perturbations or the exact Li gate-code service.

### B2. Thermal memories with sudden noise and useful gates

Bombin, Chhajlany, Horodecki and Martin-Delgado, *Self-correcting quantum computers*, New Journal of Physics 15,055023 (2013), DOI 10.1088/1367-2630/15/5/055023; arXiv:0907.5228v2. [Primary](https://arxiv.org/html/0907.5228v2).

Section VI.5 proves a threshold for suddenly applied independent depolarizing noise against a low-temperature dressed-observable resource. Section VIII.3 explicitly proposes fast transversal gates on six-dimensional color codes, with an extra dimension for local CNOT, so thermal protection plus gates is established prior architecture. During the fast burst it neglects the protective Hamiltonian; the text also discusses switching it off and the coupling/temperature tradeoff. Its initialization discussion assumes a size-independent thermalization time. It is not the present constant-rate GJ code nor a uniform full-channel nonstationary burst/cooling theorem under the whole specified joint-noise generator.

### B3. Stronger autonomous-computation and active comparators

Dünnweber--Styliaris--Trivedi, arXiv:2601.20818v3, formal Theorem 1 in Supplement V.2, already gives fixed local 2D dissipative QCA universal computation with polylogarithmic overhead, given a sufficiently correct hierarchical initial state. Its continuous-time Section VII is explicitly an outline and excludes general faulty engineered nonunitary jumps. This is a stronger consequential comparator than storage-only autonomous correction.

Christandl--Fawzi--Goswami, arXiv:2408.05260v3 Theorem 43/53, supplies noisy quantum I/O and encoded interfaces with explicit endpoint noise/auxiliaries. Their arXiv:2602.16948v2 Theorem 44 gives constant-space known-state preparation up to LS output noise and a polynomially vanishing supplied global approximation. Belzig--Yamasaki arXiv:2602.09103 supplies constant-space-overhead quantum I/O/communication using concatenated Hamming codes. Conventional FT already supplies the full processing capability under compatible controls. No new device advantage follows from our existence theorem.

### B4. Storage alone has a simpler existing-style proof

For a Gibbs-preserving channel and any normalized state supported U<=u_pre N,

`rho<=exp(beta J u_pre N)exp(-beta H)`.

A boundary at U>=u_cut N therefore has probability <=`exp[(log2-beta J(u_cut-u_pre))N]` on N qubits. A sufficiently cold LINEAR barrier absorbs this exp(volume) order constant. Hence all-low-energy storage in a good linear-distance qLTC is much easier than N1694's sublinear-exponent noisy-write problem. The descent compiler's substantive additional function is re-cooling and a repeatable gate workload budget, plus declared non-Gibbs perturbation tolerance, rather than storage alone.

## C. Genuine new steps versus known machinery

1. **Known machinery:** finite-dimensional CSS stabilizer algebra, local Gaussian elimination, bounded-degree CNOT synthesis with temporary work, nilpotent perturbation/Schur-complement identities, Metropolis detailed balance, scalar exponential-moment/Jensen estimates, and threshold/I/O machinery. These should be credited rather than renamed a new protection principle.
2. **Derived here:** the explicit additive-slack active-vertex density from GJ's actual support recursion; a local stable normal form of its anchored double complex; and the exact two-sector commuting energy UF+UK on original gate DATA plus fixed product ancillas. These are explicit applicability derivations whose historical novelty is not established.
3. **Potential new scoped theorem after all checks:** a single fixed engineered Markovian thermal generator supporting noisy warm admission, exponentially long reference-safe storage, constant cooling dwells and repeatable addressed CCZ bursts on a constant-rate linear-distance code, under one complete bounded-body noise/control contract.
4. **Not earned by these steps:** universal computation on this particular thermal code, generic exact microscopic baths, three-dimensional locality, small interactions/body size, practical thresholds, economical refrigeration, experiment or a matched advantage.

## D. Zenodo search coverage

Live API records and first-page size-25 title queries for thermal/passive/self-correcting/cooling quantum works were saved in `sources/zenodo_*_followup.json`. They contain many unrelated multi-topic records. This is bounded discovery, not an exhaustive priority search. Exact Soryun IV record 23859937 remains a substantive non-Markovian common-recovery comparator under a fixed-domain uniform spatial norm-regularity envelope; it does not supply independent local-bath cooling. The new November thermal-annealing title and a dissipative-diffusion title were metadata-screened separately; no theorem judgment is inferred from metadata alone. No absence of a matching title proves firstness.
