# Independent machinery report: noisy admission, autonomous basins and gates

Frozen independent initial report, 7 November 2026, Australia/Brisbane. Written before reading or receiving the other researchers' scientific conclusions. No subagents spawned. Research only; no publication commissioned.

## 1. Main conclusion

There is a concrete positive transfer for the **powered native linear-radius memory N1388**: fixed-positive-rate local-stochastic physical release errors satisfy its assumed warm-basin interface. The support law supplies the extensive exponential moment, a separate support cutoff pays the outside-basin mass, and Knill–Laflamme supplies the intended logical action, including arbitrary reference entanglement. No Gibbs domination and no physical recovery before HOLD are required. Theorem M1 below proves the missing entry implication.

Known quantum-input/output fault tolerance can then supply noisy active gateways for WRITE, useful logical operations and extraction under one **specified stochastic Markovian control contract**. Intermediate gateways act on already encoded information and have no new bare-input floor. A genuinely bare unknown input/output has the unavoidable order-p endpoint floor proved below. This architecture uses powered autonomous correction during HOLD and active fault-tolerant computation during gateways. It is an applicability construction from established machinery, not a new passive memory or a proved full-cost advantage over active fault tolerance.

None of the inspected general bottleneck, localization or noisy-preparation theorems closes **N1694's separate passive three-body noisy-write-to-long-HOLD problem under its microscopic joint-bath contract**. Their exact failures of applicability are recorded below; no failure of the memory itself is inferred.

## 2. Governing capital and proof inspection

Supplied repository pin: `30712044febf7fccbe5ff5c0f93ada5ccf9dc3d5`; reported current HEAD `d490a9d4429a8152902cebb32fd67c1e4c9285b2`. The principal subsequently reports that all 17 refreshed science-source hashes are unchanged; this report's direct acquisitions remain tied to the original pin.

Read completely:

- N1388 global compiler, `0af0dc529eb96a359f9f5d0f9f00972ec90f1817dc2cb4753d95f196bd3f4f18`.
- N1388 controller interface, `59c71b1c154457a0092b07610637eeb9a4f660c506f5277b43dbdd63d7b07155`.
- N1694 three-body thermal construction, `20ebf769e83ca532a49d4273961222f9f453face47fea68f83be43a150be852f`.
- N1694 noisy-write limitations, `c763ec16339b3bbc109d2e06cc85773001652d7eccc3c87be977a80b12c552e9`.

I inspected the current N1388, N1694, N1418, N1645 and N1734 packets. The N1388 packet carries two completed substantive whole reviews of those exact compiler/interface hashes. Its historical candidate headers do not revoke that acceptance. I obtained the original reviews directly from the pinned repository and matched their SHA-256 values:

- [Independent review](../machinery/sources/N1388_INDEPENDENT_REVIEW.md): `a2c54371e2dd6d64d3bf9b25bcd2d2525f5bd0dfb83a8484d814a459e955563e`.
- [Controller review](../machinery/sources/N1388_COMPANION_CONTROLLER_REVIEW.md): `e765772361cf62ac329892f5df364352e757ca550a15e932b92ed9309af29a10`.

I independently checked the load-bearing moment, physical energy locality, basin, common-error-span and positive-killing arguments needed below. In particular, their generic joint-cb-norm full-versus-killed comparison uses the **square root of the boundary mass**. I retain that exponent loss. The separate exact-Hamiltonian dossier's improved rare-event consumer is not an import into this different native argument.

N1388 is powered grouped-site autonomous correction, N1694 is a distinct passive thermal construction, N1645's microscopic theorem is unavailable, and the newer two-body report has unsupplied hypotheses. They are not identified with one another.

## 3. Physical local-stochastic noise enters the accepted native basin

All channel errors use half-diamond norm. All constants are fixed independently of N and elapsed time.

### 3.1 Exact native interface used

Let N have the sources' combined DATA-size convention. There are M_N≤aN physical grouped sites, of fixed but possibly huge local dimension. In the full-Hilbert forest frame,

`E=U+R sum_h B_h`, `V=exp(sE)`.

U is the actual nonnegative integer local energy, not raw syndrome weight; B_h are actual history defects. These terms commute and have bounded physical incidence. On the common safe radius, `U≥h r`, where r is total sectorwise reduced DATA weight. The accepted basin is

`P={r<r_0 N, E<e_cut N}`, with `e_cut<h r_0/2`, `2r_0<delta_d`.

The accepted positive observable F satisfies

`exp(-qN) exp(s' E) ≤ F ≤ exp(gN) exp(sE)`, `s'>0`,

and on every positive P-supported killed state, with `x(t)=Tr F rho_P(t)`,

`log x(t) ≤ nu N+[log x(0)-nu N] exp(-lambda t/s)`.

The constants can be selected with

`L:=s'e_cut-q > max(nu,g)`

by a fixed positive margin. Full interval propagators are CPTP and the killed compression is CP/TNI. The original review Sections 6–8 explicitly checks that a bounded-support physical operator changes only a bounded amount of E, including its fixed forest cones. Its DATA Pauli expansion has bounded support. This is not inferred from a hypothetical noise-partner graph.

The killed channel acts as identity on the canonical logical subsystem, with a positive auxiliary map. Its entire DATA error span has weight at most `alpha_H N`, `alpha_H=e_cut/h`. One fixed ordinary recovery corrects that whole coherent span, including arbitrary controller/bath coefficients and reference operators.

### 3.2 Output noise contract

Let E_N be ideal encoded DATA plus native-ready controllers and a fixed logical-independent auxiliary/bath state. Its raw E is zero. Write the physical output noise as

`N_out=sum_{S subset [M_N]} N_S`,

where N_S are CP, act identically outside S, and for every physical subset T,

`||sum_{S superset T} N_S||_diamond ≤ p^|T|`.

Arbitrary retained-environment coefficients are allowed. This includes classical local-stochastic mixtures of support-S channels and the controlled output noise of the stochastic quantum-I/O theorem. It does not include arbitrary coherent noise specified only by one global diamond bound.

Fixed local incidence and forest cones imply constants K,b such that every branch of `N_S E_N` is supported on

`E≤K|S|`, `r≤b|S|`.

For energy, all unaffected commuting local terms remain zero and only O(|S|) bounded terms can change. For weight, expand finite system matrix legs after the fixed frame transformation; the environment remains in coefficients. The original review explicitly supplies the physical-to-forest finite-cone property used here.

Choose a fixed z>0 with `bz<r_0`, `Kz<e_cut`, `2bz<delta_d`, strictly. Keep branches `|S|≤zN` as a subnormalized good-history channel. Their range is P-supported. Their Kraus operators belong to one common correctable span, so the canonical logical action is identity, including all coherent cross terms and arbitrary external-reference entanglement. This is a Knill–Laflamme conclusion, not a Pauli-mixture claim.

### 3.3 Theorem and proof

**Theorem M1 (PROVED transfer).** Put

`nu_w(p)=g+a log[1+p(exp(sK)-1)]`.

For sufficiently small fixed p>0 satisfying `p<z/a` and `max(nu,nu_w(p))<L`, there are fixed positive c_0,c_1,C,N_0 such that, uniformly over the declared N_out and all reference-entangled inputs,

`d_diamond(Dec S_t N_out E_N,id)`

`≤ exp(-c_0N)+CNt exp(-c_1N)`,

for every N≥N_0 and t≥0, capped by 1. One may take any

`c_0<a D(z/a||p)`,

`c_1<[s'e_cut-q-max(nu,nu_w(p))]/2`,

after rounding and constant boundary factors. D denotes binary relative entropy in natural logarithms. This is a uniform estimate throughout an exponentially long horizon, not infinite lifetime at finite N.

**Proof.** For any normalized input let w_S be its N_S-branch trace. The CP support contract gives `sum_{S superset T}w_S≤p^|T|`. For theta≥0, expand the product:

`sum_S w_S exp(theta|S|)`

`=sum_T (exp(theta)-1)^|T| sum_{S superset T}w_S`

`≤[1+p(exp(theta)-1)]^M_N`.

Chernoff optimization bounds the discarded `|S|>zN` mass by `exp[-aN D(z/a||p)]`, with rounding absorbed into c_0. No local-stochastic law is asserted after conditioning and renormalizing.

On the good output, the raw upper comparison gives `F≤exp(gN+sK|S|)`, hence `x(0)≤exp[nu_w(p)N]`. The imported killed moment law gives `x(t)≤exp[max(nu,nu_w(p))N]` at every time. Every exiting source lies at `E≥e_cut N-K_edge`, so its mass is at most

`exp(s'K_edge) exp[-(L-max(nu,nu_w(p)))N]`.

The checked O(N) joint-cb-norm positive-killing/Duhamel comparison bounds the full-versus-killed channel error by CNt times the square root of this mass. The killed map has exactly the desired canonical logical action; its survival deficit and the separately discarded initial mass are added contractively. This proves the bound. No factor involving reference dimension appears. ∎

This supplies all three previously assumed warm-entry requirements: P-support of a good CP channel, intended logical action, and a fixed extensive moment gap. It prices outside-P mass from time zero; there is no unpriced burn-in, postselection or active recovery before HOLD.

### 3.4 Noisy terminal recovery input

Let W_read be another sufficiently weak physical LS channel. Choose z_R>0 with `alpha_H+bz_R<delta_d/2`. Except for `exp(-c_RN)` mass its support is at most z_RN. Multiplying its system matrix legs by the killed native Kraus span gives total DATA weight at most `(alpha_H+bz_R)N`. The same fixed decoder corrects the complete composite coherent span. Therefore

`d_diamond(Dec W_read S_t N_out E_N,id)`

`≤exp(-c_0N)+exp(-c_RN)+CNt exp(-c_1N)`.

This is a robust communication-channel sandwich. The native HOLD need not itself be an LS Pauli channel.

## 4. Compatible noisy gateways and useful operations

### 4.1 Verified primary import

Christandl–Fawzi–Goswami, *Fault-tolerant quantum input/output*, arXiv:2408.05260v3 (2 December 2025), IEEE TIT 72, 3098–3128 (2026), DOI `10.1109/TIT.2026.3672442`. [Primary](https://arxiv.org/html/2408.05260v3).

Theorem 43, equations (133)–(135), and Lemmas 41–42 compile an ideal quantum-I/O circuit Phi of size Gamma into size `Gamma poly(k)`, with full-diamond error `≤4Gamma(cp)^k`, under its independent circuit-level stochastic faults. Explicit input/output auxiliary systems are retained. Each output interface is `(1-epsilon)id tensor trace+epsilon Z`, `epsilon≤2cp`, so its fault choices give the needed support tails. Lemma 41 gives a good input-interface branch preserving the unknown input, with bad mass O(p). Corollary 45 gives the quantum-output-only LS preparation statement. Theorem 53 transfers a robust communication code between computationally encoded interfaces. These statements use diamond norms and cover arbitrary external-reference entanglement.

The source does not promise vanishing-error unencoded quantum endpoints at fixed p, or a geometrically local constant-density implementation of the entire compiler.

### 4.2 One common bath/control/noise model

A valid intersection of the imported models is:

1. The actual native grouped-site Hamiltonians, resolved resets/monitors, code tables and fixed rate choice of N1388.
2. A universal active gate/reset/measurement architecture with protected classical feedforward and charged routing. Native terms are switchable off on gateway registers; switching, idles and resets count as noisy locations.
3. Independent local stochastic circuit faults of sufficiently small fixed p during active circuits. During HOLD, bounded-rate memoryless local fault channels have incident generator norm below the native eta limit. Fresh local reservoir ancillas, or a trivial retained bath, realize this common Markovian stochastic subset.
4. Actual native grouped-site dimensions are retained. Replacing a fixed-dimensional site by a fixed number of qubits costs a fixed, potentially huge, factor.

This is a specified changed architecture with active gateways. It is not a derivation of a circuit-level fault model from an arbitrary exact interacting bath, a noiseless final release, or an exponentially long weak-coupling approximation. The native common-bath theorem remains valid at its original broader scope; full noisy-I/O composition is claimed only for this narrower intersection.

### 4.3 WRITE and READ

Compile the ideal encoder E_N, including DATA and every native controller. On the good input-interface branch the unknown input is unchanged; its auxiliary state is logical-independent, since an identity marginal has a constant complementary channel. For m bare input qubits, bad-input mass is at most Cmp. The output is LS with parameter at most Cp, including controller errors. Theorem M1 gives

`WRITE/HOLD error ≤Cmp+2Gamma_W(cp)^k+exp(-c_0N)+CNt exp(-c_1N)`.

For READ, compile the declared decoder, use Section 3.4 for its input noise, and retain its order-mp bare-output floor. If the endpoints are already computationally encoded, Theorem 53 and the robust sandwich replace the bare floors by arbitrarily accurate encoded interfaces.

### 4.4 Universal operations by a paid gateway

For a logical gate/channel G, use the ideal physical channel

`Phi_G=E_N o G o Dec_native`.

It decodes the native frame and DATA, acts on the logical input, and resets controllers/syndrome scratch to ready. Compile it using Theorem 43. Its input noise acts on an **already redundantly encoded native block**, so Section 3.4 corrects it jointly with native residuals, except for exponentially small mass. There is no new bare-input floor at each gate. Its output is again LS noise on E_N and hence restarts Theorem M1's basin.

The operation occurs actively inside the computational fault-tolerance architecture. It is not an unproved weak gate with the native memory generator unchanged. For G gateways and total native HOLD time T, telescoping yields

`error ≤Cmp+sum_j 2Gamma_j(cp)^k`

`        +C(G+1)exp(-c_A N)+CNT exp(-c_H N)`.

Raw endpoint noise contributes to Cmp; already encoded endpoints avoid it. All constants/exponents are fixed after choosing the model.

A promised-input polynomial DATA recovery can be obtained from the same finite local orbit-minimizing rules. Measure syndrome, scan O(N) finite tables for an active rule, apply it, repeat. Each accepted move lowers integer U by at least one, and active density ensures a move exists while U>0. Keep the incoming energy, including a small support of gateway faults, below `h r_safe N` by a fixed margin. Confinement and bounded per-move weight change prevent the first exit from r_safe, and each move has canonical logical identity. There are O(N) accepted moves, so a capped O(N^2)-location scan suffices. Outside the promise it can return any fixed output. This avoids an exponential minimum-weight oracle. The actual finite native frame inverse and its gate/routing catalogue remain explicitly charged access resources.

### 4.5 Complete resource boundary

Native HOLD uses O(N) fixed-dimensional sites, fixed powered drives/resets/monitors and possibly enormous constants. It continuously exports entropy. An ideal gateway of size Gamma needs `Gamma poly(k)` compiled locations, where

`k≥log(4Gamma/delta)/log(1/(cp))`

makes its internal error at most delta. For exponentially small delta, k=Theta(N+log Gamma); safe general overhead is polynomial in N, not a free constant-density terminal release. Actual grouped-site frame access, coupling controls, classical hardware, scratch, cooling, routing and duration are charged. The four supplied scalar/controller notes do not themselves give a numerical elementary-qubit threshold or Euclidean routing bill; that implementation catalogue should be pinned before making such a hardware claim.

A matched active comparator gets those same gates, routing, resets, switches and classical resources. It can remain in its computational code throughout HOLD. This transfer proves compatibility of autonomous intervals, not a full-cost or asymptotic exponent advantage.

## 5. Exact obstructions

### 5.1 Bare-input floor

**Theorem M2 (PROVED).** If the allowed first exposure of an unknown bare qubit includes `D_p=(1-p)id+p Tr(.)I/2` before redundancy, then for every subsequent channel R,

`d_diamond(R D_p,id)≥3p/4`.

**Proof.** Feed half a Bell pair. Entanglement fidelity is `(1-p)F_e(R)+p/4≤1-3p/4`; the replacement contribution equals p/4 because the untouched reference has marginal I/2. The Bell-projector test gives trace distance at least the missing fidelity. Identity R attains it: the four Bell weights are `1-3p/4,p/4,p/4,p/4`. ∎

The circuit-level stochastic model allows this at the first gate by choosing the faulty local channel to depolarize the input before the intended gate. Thus exponentially accurate bare-input-to-bare-output identity at fixed p is an impossible target for that class. Declare an endpoint floor, encoded endpoint, or separately supplied high-quality access service. This does not obstruct long storage of the state actually admitted.

### 5.2 Gates cannot hide in the uniformly harmless noise class

**Theorem M3 (PROVED).** If a memory theorem places every decoded evolution driven by controls/noise in class C within epsilon_N(t) of identity, then any alleged logical gate using only that class has target error at least

`d_diamond(id,G)-epsilon_N(t)`.

This is the triangle inequality. Logical X has distance 1 from identity. A useful fast gate must therefore use selected stronger controls, a changed code/program/dissipator, measurement/feedforward, or a paid gateway outside the universally protected class. Localization alone is not a universal gate construction.

## 6. Strongest existing geometric autonomous comparator

Dünnweber–Styliaris–Trivedi, *Quantum Memory and Autonomous Computation in Two Dimensions*, arXiv:2601.20818v3. [Primary](https://arxiv.org/html/2601.20818v3). Formal Theorem 1 in Supplement V.2, Definition 8/Lemma 9, supplies a fixed local 2D dissipative QCA with universal programmed computation and Definition 3 local fault-path noise. Cost is `O(N polylog(ND/delta))` cells and `O(D polylog(ND/delta))` runtime. It assumes a sufficiently correct hierarchical input: no initial damage at some level k_0 and correct decoded data/program there. Lemmas 10–11 and V.8 supply the reference-stable fault-path estimate. Continuous-time Section VII explicitly provides an outline, not the same fully formal theorem for faulty engineered nonunitary jumps.

A direct LS-preparation bridge exists for its **discrete-time** theorem. Let B=M^2 be the constant number of child cells and t=r+1 the number of marked children required to mark a parent. A marked level-l cell has a recursive witness with t^l distinct physical leaves, and at most

`A^[(t^l-1)/(t-1)]` witnesses, `A=binom(B,t)`.

Physical LS support of parameter p therefore gives

`Pr(given level-l cell marked)≤A^[(t^l-1)/(t-1)]p^(t^l)`.

Union over at most V cells gives `V(Cp)^(t^l)`, `C=A^(1/(t-1))`. The source's recursive initial-damage definition and leading-correction condition preserve data, structure and program on unmarked blocks, including coherent correctable errors. Thus l=O(log log(V/delta_init)) obtains the sufficiently correct initial-state condition except for delta_init. Add enough higher levels for the runtime threshold; the hierarchy remains doubly logarithmic. Quantum-I/O preparation adds its charged workspace and raw endpoint floors. This is a strong known comparator, not a substitute for the passive microscopic-bath theorem.

## 7. Exact primary-source checks and applicability failures

**3D passive memory.** Balasubramanian–Davydova–Lin, arXiv:2605.10943v1 (11 May 2026), [primary](https://arxiv.org/html/2605.10943v1). Theorem 1.1/formal Theorem 2.6 use a thermal logical encoder. Theorem 5.13 bounds unstable equilibrium syndromes by `2*2^(-2^(k-1))` at sufficiently low fixed temperature. Local embedding/density are separately established. Its lifetime proof does not admit the N1694 noisy-output class merely because that output is statically decodable. It is a substantive prior construction.

**Noisy preparation.** Zhao–Yuan–Han–Liu, arXiv:2609.39965v3 (2 November 2026), [primary](https://arxiv.org/html/2609.39965v3). Theorem 1(1) gives LS residual noise under linear soundness over a linear range, with `q_tilde=e(2sqrt(q))^min(rho,kappa)` and total parameter `p+q_tilde`. Theorem 1(2)'s weaker confinement premise gives logical robustness certified by final ideal recovery without an LS residual guarantee. This is CSS-sector state preparation, not unknown-input encoding, thermal-clock sampling or bath equilibration. Part (2) alone cannot feed Theorem M1's moment.

**Bottlenecks.** Rakovszky–Placke–Breuckmann–Khemani, arXiv:2412.09598v2 (16 October 2026), [primary](https://arxiv.org/html/2412.09598v2). Theorem 1 assumes a Kraus decomposition respecting `A->B1->B2->C` and a common stationary rho. It proves approximate stationarity of `rho_A=P_A rho P_A/Tr(P_A rho)` with bound `10||P_B rho||_1/Tr(P_A rho)`. Telescoping preserves that special start, not every A-supported state. Theorem 3's extensive-barrier application is slow mixing, not a generic arbitrary-reference noisy-writer basin.

**Localization.** Yu–Wei, arXiv:2510.14160v2 (19 June 2026), [primary](https://arxiv.org/html/2510.14160v2). Theorem 1 controls spreading by a total Hamiltonian-variation budget. Proposition III.1 gives long cluster localization of low-energy initial eigenstates below a linear barrier under budget lambda n; Proposition III.2 gives slow Gibbs-sampler mixing. A persistent fixed-rate bath can inject energy indefinitely and does not supply that variation budget. A bounded bath energy or other regularity premise is additional. Theorem M3 also blocks treating all admitted weak perturbations as nontrivial gates.

**Improved output-interface cost.** Christandl–Fawzi–Goswami, arXiv:2602.16948v2 (29 September 2026), [primary](https://arxiv.org/html/2602.16948v2). Theorem 25 gives decoding interfaces for its specified code family with constant overhead when enough blocks are supplied. Theorem 44 prepares a polynomial-size known state up to LS output noise `(kappa_1 p)^kappa_2` with O(x) qubits and global approximation epsilon(x)->0. Remark 43's supplied epsilon is polynomial in x. The full arbitrary-input constant-overhead encoding-interface analysis is explicitly left open. This does not justify exponentially small global error at O(N) preparation space or deleting bare-input floors.

## 8. Counterexample to the all-state bottleneck inference

Take five classical states `a0,a1,b1,b2,c`, stationary weights

`pi(a0)=pi(c)=(1-3epsilon)/2`,

`pi(a1)=pi(b1)=pi(b2)=epsilon`.

On the path `a0-a1-b1-b2-c`, set neighbour transitions `P_ij=(1/3)min(1,pi_j/pi_i)` and fill the diagonal. Detailed balance holds. Use `A={a0,a1}`, `B1={b1}`, `B2={b2}`, `C={c}`. The bottleneck theorem's Kraus adjacency holds, and its classical ratio is `4epsilon/(1-epsilon)`. Yet a1 reaches c in three steps with probability exactly 1/27. A writer outputting a0 with probability 1-p and a1 with probability p is initially perfectly decodable as A but has C mass p/27 after three steps independently of epsilon.

This disproves inference from initial decodability or A-support to projected-equilibrium metastability. It is **not a fixed-strength lattice Hamiltonian counterexample**: realizing the a0/a1 Gibbs ratio with a local energy requires a growing energy difference. It leaves the physical memory open. The pinned product-Gibbs domination obstruction is also distinct: it defeats a proof interface, not actual memory.

## 9. Recent Zenodo checks and priority boundary

Live primary API records and bounded discovery queries were saved under `machinery/sources/`. Broad searches were noisy and only the first 25 hits of each were inspected. No absence or priority inference is made.

[Soryun IV, 23859937](https://zenodo.org/records/23859937), created 1 November 2026, remains at its current DOI/files: PDF MD5 `b59ec0b9616439c74308565f2ab850fa`, source ZIP `4a85d07cefa3867aaf9d59282fb47d2a`. I read the pinned original nonabelian-field chapter. Its common encoder/recovery uses one uniform integrated operator-norm spatial continuity envelope on a fixed compact domain. That is meaningful non-Markovian common-recovery machinery. Independent microscopic bath coefficients at distinct nearby sites do not meet the envelope merely because each coupling is small. It does not import generic LS thermal-memory protection, and efficient physical decoding/preparation remains a separate bill.

The 5 November [23972523](https://zenodo.org/records/23972523) remains a short E8/golden-ratio text without the asserted basin proof; its API file checksum matches the older dossier. [20768851](https://zenodo.org/records/20768851) is a genuine two-ion/four-level autonomous-QEC experimental/simulation dataset, not an asymptotic universal-computation threshold. These are file-scope checks, not judgments of an author's entire programme. Website publication/creation fields can differ; no title establishes chronology.

## 10. Status and decisive follow-up

- **Established prior capital:** N1388 native drift/basin/fixed ideal decoder at exact reviewed hashes; N1694 ideal isolated loader at its scoped accepted hypotheses.
- **PROVED here:** LS release -> warm native basin, coherent/reference-safe correctability, output LS robustness; exact raw-input floor; gates-inside-noise-class obstruction; all-state bottleneck counterexample.
- **PROVED transfer under an explicit augmented control contract:** active noisy gateways, universal useful operations and long native autonomous intervals using the stochastic quantum-I/O theorem. Actual grouped-site gate access and routing are charged; no passive or microscopic bath upgrade is claimed.
- **OPEN implementation detail:** pin the actual native frame circuit, elementary grouped-site gate catalogue and routing bill before claiming a concrete efficient Euclidean device or numerical threshold. The promised DATA decoder has the finite-table energy-descent construction above.
- **NOT ACHIEVED:** constant-rate noisy admission for N1694's actual passive model; exact microscopic-bath full processor; favorable total-resource comparison; historical firstness or practical breakthrough.

The constructive next check is to challenge M1's physical-to-forest support and energy bound against the native circuit catalogue, then instantiate the gateway and its complete resource bill. For the passive route the decisive missing operation remains a nonstationary energy/cluster basin for that same writer and bath; stationary rare-event theorems do not provide it.

Supporting artifacts: [check script](../machinery/check_machinery_bounds.py), [results](../machinery/CHECK_RESULTS.json), [source manifest](../machinery/SOURCE_MANIFEST.json). The exact five-state chain, Bell floor and sample LS-mgf inequalities were checked; those checks supplement the proofs and do not simulate a protected device.
