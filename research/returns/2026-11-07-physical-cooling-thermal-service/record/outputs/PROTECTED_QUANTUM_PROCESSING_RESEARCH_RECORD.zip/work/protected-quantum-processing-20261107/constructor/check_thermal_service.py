"""Finite algebra/parameter checks for the structural thermal-service theorem.
No actual Tanner/Li constants, microscopic reservoir or device threshold are verified.
"""
import math,itertools,json
from pathlib import Path
import numpy as np
I=np.eye(2);X=np.array([[0.,1.],[1.,0.]]);Z=np.diag([1.,-1.])
def kron(xs):
    a=np.ones((1,1))
    for b in xs:a=np.kron(a,b)
    return a
# Exact Walsh formula with dependent commuting checks.
checks=[kron([Z,Z,I]),kron([I,Z,Z]),kron([Z,I,Z])]
sigmas=list(itertools.product([-1,1],repeat=3))
tab={s:min(sum(x==-1 for x in s),2) for s in sigmas}
direct=np.zeros((8,8));walsh=direct.copy()
for sig in sigmas:
    P=np.eye(8)
    for s,S in zip(sig,checks):P=P@(np.eye(8)+s*S)/2
    direct+=tab[sig]*P
for mask in itertools.product([0,1],repeat=3):
    coeff=sum(tab[sig]*math.prod(sig[j] for j,b in enumerate(mask) if b) for sig in sigmas)/8
    S=np.eye(8)
    for b,C in zip(mask,checks):
        if b:S=S@C
    walsh+=coeff*S
walsh_res=float(np.max(np.abs(walsh-direct)))
assert walsh_res<1e-13

# Exact finite Davies spectral formula on the classical complete-graph Ising energy.
n=4;dim=2**n;s=.25;beta=5.
configs=list(itertools.product([0,1],repeat=n))
energy=np.array([sum(x[i]!=x[j] for i in range(n) for j in range(i+1,n)) for x in configs])
U=np.diag(energy.astype(float));V=np.diag(np.exp(s*energy))
rho=np.diag(np.exp(-beta*energy));rho/=np.trace(rho)
Lstar=np.zeros_like(V);Lrho=np.zeros_like(V);formula=np.zeros_like(V)
active=[]
for x,e in zip(configs,energy):
    downs=0
    for i in range(n):
        y=list(x);y[i]^=1
        downs+=int(energy[configs.index(tuple(y))]<e)
    if e:active.append(downs/e)
kap=min(active)
for i in range(n):
    P=kron([X if j==i else I for j in range(n)])
    delta=np.diag(P@U@P)-energy
    for d in sorted(set(delta)):
        Pi=np.diag((delta==d).astype(float))
        A=P@Pi;rate=1. if d<=0 else math.exp(-beta*d)
        Lstar+=rate*(A.T@V@A-(A.T@A@V+V@A.T@A)/2)
        Lrho+=rate*(A@rho@A.T-(A.T@A@rho+rho@A.T@A)/2)
        formula+=rate*(math.exp(s*d)-1)*V@Pi
davies_res=float(np.max(np.abs(Lstar-formula)))
stationary_res=float(np.max(np.abs(Lrho)))
a=kap*(1-math.exp(-s));b=8*math.exp(-beta)*(math.exp(s*3)-1)
drift_margin=float(np.min(np.linalg.eigvalsh((-a*U+b*n*np.eye(dim))@V-Lstar)))
assert davies_res<1e-12 and stationary_res<1e-12 and drift_margin>=-1e-12

# Sufficient structural parameter choices; explicitly NOT actual code constants.
DE,B,q,C,delta,h,cr,r0=4.,2.,32.,2.,.1,.5,2.,.02
uc=.001
upost=min(uc/4,delta/(16*(C+1/DE)),DE*r0/(16*cr))
upre=upost/(4*DE*B*C);alpha=upost/(4*DE*B*q)
kappa=.1;gamma=Gamma=J=1.;M=64.;D=4.;M0=16.;cU=2.;ustar=1.;LS=.1
a=gamma*kappa*(1-math.exp(-s));Cs=math.expm1(s*DE*q)
betaJ=max(0.,math.log(16*M*Gamma*math.expm1(s*D)/(a*upre)))
eta=a*upre/(16*Cs)
bth=M*Gamma*math.exp(-betaJ)*math.expm1(s*D);btot=bth+Cs*eta
nueq=s*btot/a
AH=2*J*cU*ustar+2*M0*(2*D+1)*(Gamma+LS)+eta
tau=alpha/(48*math.e*AH)
cal=alpha/(48*math.e);stoch=alpha/(48*math.e)
mu=AH*tau+cal+stoch
dwell=(s/a)*math.log(4*upost/upre)
pre_after=nueq+(s*upost-nueq)*math.exp(-a*dwell/s)
wpost=B*C*upre+B*q*alpha
assert uc<h*r0/4
assert wpost*DE<=upost/2+1e-18
assert cr*wpost<r0 and wpost+C*upost<delta
assert nueq<=s*upre/4
assert mu<=alpha/(8*math.e)
assert pre_after<=s*upre/2
out={"scope":"Finite scalar/operator algebra and arbitrary sufficient parameter example only",
"walsh_dependent_check_residual":walsh_res,"davies_formula_residual":davies_res,
"gibbs_stationarity_residual":stationary_res,"finite_classical_descent_kappa":kap,
"finite_classical_drift_margin":drift_margin,
"illustrative_structural_parameters":{"u_c":uc,"u_post":upost,"u_pre":upre,"alpha":alpha,
"a":a,"betaJ":betaJ,"eta":eta,"nu_eq":nueq,"pulse_duration":tau,"pulse_mu":mu,
"cooling_dwell":dwell,"post_support_density":wpost,
"hold_exponent":s*(uc-upost)/2,"preclip_exponent":s*upre/4,"pulse_exponent":alpha*math.log(8)}}
Path(__file__).with_name("thermal_service_checks.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out,indent=2))

