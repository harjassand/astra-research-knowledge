# Quantitative active-vertex refinement of GJ Section 6

7 November 2026. Extension of arXiv:2609.20780v1 Lemma 6.1.3 and Proposition 6.2.2, derived after independent initials froze.

Fix a closed degree-j cochain b satisfying the actual local filling/walk-mixing hypotheses. Let A be its nonzero block support and B the vertices admitting a strictly weight-decreasing correction supported above that vertex. Put

`r_l=n_- kappa_{t-l,j-l}`,

`D_{j,l}=max_{v in X(l)} |X_{>=v}(j)|`,

`c_{j,l}=(j-l)! / product_{m=l}^j r_m`.

These are fixed constants. An l-face is exceptional iff every vertex of it is active. At any nonexceptional v choose an inactive vertex x of v. Every correction above v is also above x; therefore the exact local cominimality proof of Lemma 6.1.3 holds there. At exceptional v use the universally valid bound

`r_l |A intersect X_{>=v}(j)| <= |A intersect O_v(j)|+|A intersect N_v(j)|+r_l D_{j,l}`.

For fixed f in X(j), use Proposition 6.2.2's H_l,O_l,N_l, and let E_l(f) count exceptional l-faces of f. Then

`r_l H_l(f)<=O_l(f)+N_l(f)+r_l D_{j,l}E_l(f)`.

The same geometric identities `N_0=0`, `N_l<=(j-l+1)H_{l-1}` hold. Identical upward substitution yields

`1_A(f)<=sum_l c_{j,l}[O_l(f)+r_l D_{j,l}E_l(f)]`.

Multiply by 1_A(f) and sum. The O_l terms give the source bound `sum_l b_jl<1_A,W_jl 1_A>`. Every exceptional face contains an active vertex. Counting through one chosen active vertex and permitting overcounting gives

`sum_{f in A}E_l(f)<=D_{j,0} binom(j,l)|B|`,

because a j-cube contains binom(j,l) l-faces through a specified vertex, and each active vertex is in at most D_{j,0} j-faces. Hence, with

`C_j=sum_l c_{j,l}r_l D_{j,l}D_{j,0}binom(j,l)`,

we have

`|A|<=sum_l b_jl<1_A,W_jl 1_A>+C_j|B|`.

Lemma 5.3.1 and L_j=sum_l b_jl, Q_j=sum_l b_jl beta_jl now give

`(1-lambda L_j)|A|<=Q_j|A|²/Z_j+C_j|B|`.

For lambda L_j<1 and `0<|A|<=(1-lambda L_j)Z_j/(2Q_j)`, conclude

`|B|>=(1-lambda L_j)|A|/(2C_j)`.

This proves linear density of active vertices, not merely existence of one descent. Apply separately to Fcal and its actual kernel cosheaf Kcal, whose dual-code local charts are Theorem 7.2.1. Physical realization of the K descent is supplied separately by the stable dual-energy extension; original transpose syndrome weight has not been equated to K cochain weight. Use Li Eq(2.7)'s physical CSS orientation; GJ labels the two CSS sectors oppositely, an innocuous global-H swap that must be made explicit.
