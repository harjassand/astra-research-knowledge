# Independent principal investigation: a nonstationary protection budget

7 November 2026. Written before seeing any of the three researchers' reports. The question is a complete physically earned path from noisy input to long protected computation, not another equilibrium lifetime statement. No peer report or intermediate conjecture was read. This file will remain frozen.

## 1. Starting contracts inspected

The pinned three-body clock source retains all particle-number sectors; its actual Hamiltonian and polynomial-in-clock-weight energy scale are explicit. Its bath transfer and ideal isolated loader do not establish noisy long HOLD in the actual joint bath. The noisy-WRITE source proves that local-stochastic errors can require an exp(volume) global Gibbs-domination constant, while immediately decoding correctly. This is a failure of that interface, not a memory no-go.

The native powered-controller result is different. Its accepted source already proves a global exponential moment drift inside a common correctable basin and explicitly permits P-supported warm initial channels with a strict extensive moment margin. Merely stating that warm extension again would not be new.

The existing exact-H storage paper already has a reference-safe conditional correlation-to-channel theorem and p^{-1} thermal-boundary lifetime from an ideal logical overwrite of the interacting Gibbs resource. These are not newly earned noisy-entry statements.

## 2. Strongest candidate operation: processing with a sustained protection budget

The productive generalization may be from stationary storage to an open set of nonstationary writer and gate services, controlled by an extensive exponential moment rather than Gibbs order. This is a control/invariant-region mechanism, not intrinsically thermal.

Let physical Hilbert space be finite, R arbitrary, and P a correctable safe projection. Let F >= I be a positive observable commuting P. Let K_{t,s} be a CP/TNI killed evolution on P with physical CPTP evolution S_{t,s}. Assume the following actual pointwise drift for every positive subnormalized sigma on P:

x=Tr(F sigma),  (d/dt)log x <= -a log x + a nu N,  a>0.

A sufficient operator-side source is the accepted native nonlinear moment law, with a=lambda/s and nu=g+s rho/lambda. This is NOT assumed for the passive three-body Davies/exact-H model.

Let Q <= P be the outgoing source boundary and require F >= exp(bN)Q, b>nu. Let the full-versus-killed superoperator defect have reference-uniform bound

||(L_phys-L_kill) tensor id_R (sigma)||_1 <= C N [Tr(Q sigma)]^theta,

for all positive subnormalized reference states, theta in (0,1]. Classical jump exits can have theta=1; generic coherent cross terms require theta=1/2 unless stronger structure is proved. Keep the native theorem's actual whole-generator Duhamel bound instead of silently assuming its better exponent in other models.

If the writer has a reference-safe decomposition W=W_good+W_bad into CP maps, W_good maps into P with exactly the intended decoded logical identity, bad trace <=delta, and Tr F W_good(I/d) <= exp(nu_w N), arbitrary inputs are bounded by d times the maximally mixed input. This pays payload dimension d; for constant-rate payload log d=Theta(N), one needs a reference-uniform moment bound directly, not an uncharged Choi factor. A stronger sufficient writer assumption is sup_{rho_LR} Tr[(F tensor I)W_good(rho)]<=exp(nu_w N).

Then on the killed path,

log x(t) <= [nu+(nu_w-nu)e^{-at}]N,
Tr(Q sigma(t)) <= exp(-(b-max(nu,nu_w))N).

Integrating the full/killed difference and adding delta gives a long-HOLD channel error of order

delta + C N T exp[-theta(b-max(nu,nu_w))N].

This follows by the scalar differential inequality and Duhamel with CPTP trace-norm contraction. It is an elementary theorem once the physical drift, boundary defect and writer hypotheses are earned; the new value would be acquiring them for a useful preparation/gate architecture.

## 3. Exact noisy local writer admission to a linear-energy native basin

There is an actionable sufficient interface broader than Gibbs order. Suppose an encoded/ready input is supported in E=0, where E is a sum of commuting positive local terms with bounded incidence and local spectra. A fault set F in a bounded-depth release circuit has affected support at most B|F| and each affected register changes only O(1) terms. If each location may act by an arbitrary local CPTP fault, the output on that fault history lies in E<=K|F|. This is a SUPPORT statement, not a false norm commutator bound. Operators outside the support preserve every unaffected energy term that annihilated the input.

If location faults obey Pr[J subset F] <=p^{|J|} over G locations, then, for z>=1,

E z^{|F|} = E product_{j=1}^G [1+(z-1)1_{j in F}]
         <= [1+p(z-1)]^G.

Consequently Tr exp(sE) W_phys(rho) <= [1+p(e^{sK}-1)]^G, uniformly in the logical/reference input when branch faults are input-independent local CPTP maps. The initial controller factor can cost exp(gN). If G<=gamma N, the extensive coefficient is

nu_w <= g+gamma log[1+p(e^{sK}-1)].

A Chernoff bound also controls faults leaving a correctable global Pauli span: arbitrary local operators on w sites are linear combinations of Pauli errors of weight <=w; a code correcting that span corrects coherent local faults as well. A subnormalized good fault-history instrument avoids conditioning and invalid joint independence claims.

This closes an admission calculation for a SPECIFIED bounded-depth fault-tailed release from an encoded/ready resource. It does not supply the full noisy encoder, correlated memory-bath Gibbs resource, arbitrary coherent fault-path norm expansion, or physical controller reset. A generic G=poly(N) unprotected encoder gives an extensive coefficient that can grow with N, so the calculation is not a threshold theorem for that encoder.

For an active fault-tolerant factory with final bounded-spread release one must charge all blocks, routing, classical decoding and idle locations. Such a factory could be a legitimate upstream service, but the same service is available to the active FT comparator. Native powered correction itself consumes resets during HOLD. No passive cost gain follows.

## 4. Protected gates: a precise workload law

Suppose declared physical gate instruments J_j map their good branches inside P, implement intended logical channels under a fixed recovery, and obey

J_j^*(F) <= exp(w_j N) F

on the safe subspace, reference-uniformly, with bad mass delta_j. Let tau_j be subsequent correction dwell time. For moment coefficients y_j=N^{-1}log x_j, the exact recurrence is

y_{j+1} <= nu+e^{-a tau_j}(y_j+w_j-nu).

Thus the weighted sum of all preceding gate workloads, damped by intervening protection, rather than total gate count alone controls admission. A uniform cadence tau and workload w gives

limsup y_j <= nu+w/(exp(a tau)-1)

when measured after each dwell; just after a gate it is at most nu+w/(1-e^{-a tau}). If this remains a fixed amount below b, a union/Duhamel bound gives exponentially many safe gate periods before accumulated logical error becomes appreciable, with sum delta_j additionally charged.

This scalar invariant-region fact is known control/Lyapunov mathematics. The missing operation is an ACTUAL useful gate with such a workload at fixed admitted native constants. A generic transversal Clifford preserves the code space but can multiply the error energy, so a constant workload cannot be inferred simply from its logical correctness. A virtual recovery between gates does not reset the moment.

One repair: reserve a smaller pre-gate energy cutoff, bound the exponentially rare tail above it, and use bounded error-spread of the gate to bound its increased energy. This requires accounting for coherent discarded tails (usually square-root loss) and controller states. Another: continuously transport the physical generator and the safe energy in a moving code frame, with H_control=i dot U U*, L_t=Ad_U L_native Ad_U* plus transport. Exact covariance is algebraically sufficient, but conjugating native interactions may raise body size/degree and implementing all coefficients is a paid control service. Repeated logical gates can spread supports; resetting the code frame at endpoints requires an actual safe endpoint automorphism and a renewed moment estimate. None of these gate services is silently granted.

Universal processing additionally needs a non-Clifford resource/control service with the same interface. Ordinary distillation and FT simulation are established comparators, not breakthroughs.

## 5. Exact interacting-bath composition boundary

A general finite-bath Hamiltonian commutator cannot satisfy a strictly contracting positive operator Lyapunov drift globally: a finite unitary dynamics is recurrent, and trace of a commutator vanishes. A negative-drift certificate needs a reduced dissipative model, a killed/nonstationary state-restricted argument, or actual boundary/thermal source information. A Davies drift is not automatically valid under exact Hamiltonian dynamics for exponentially long physical times.

Preparing an isolated-memory marginal close to a Gibbs marginal does not prepare the correct joint memory-bath state. For any encoder acting only on S, an initially uncorrelated bath remains inaccessible except for existing interaction and elapsed physical evolution; creating a prescribed correlated joint Gibbs state is a distinct physical operation. The exact-H paper's supplied interacting equilibrium is not earned by the isolated loader.

A promising stronger attack is to establish a state-dependent local or cluster Lyapunov family for the all-sector clock model, with a physical thermal relaxation term that heals bad clock occupations and controls dangerous DATA clusters. Global entropy or Gibbs domination can be exponentially expensive in volume even when the relevant clusters remain small. A successful local certificate could be compatible with a noisy writer without reconstructing equilibrium in total-state distance.

## 6. Existing comparators and status

Primary sources consulted independently: 2605.10943v1 Theorem2.6 starts from a specified thermal logical encoding, and source preparation/processing remains separately relevant; 2601.20818v3 already gives autonomous 2D quantum computation with polylog overhead under local dissipative/noise contracts; 2609.39965v3 distinguishes ideal-recoverable preparation under confinement from local-stochastic residual control under stronger soundness; 2412.09598v2 Theorems1/2 bound special projected stationary states and do not by themselves give arbitrary-input noisy entry; 2510.14160v2 energy localization has static/time-dependent perturbation hypotheses and variation costs, not a generic thermal environment.

Status: the displayed scalar budget and local-stochastic moment calculations are PROVED elementary interfaces; applicability to a full writer/gate/thermal architecture is NOT ACHIEVED. Native warm contraction was inherited and is explicitly credited. A major breakthrough would require a new physical basin-entry/processing mechanism or a matched resource advantage, not these conditional formulas alone.
