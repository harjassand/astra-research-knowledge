# Hostile audit and constructive completion: thermal descent with repeatable gate service

7 November 2026. After freezing `../initial/auditor.md` (SHA-256 `0d2debc4f800d5a3d0dc3376fd358b233f965d61ac5f581f5091759ed46b3d7d`), I read the principal's `qltc_thermal_descent_route.md`, the other initials, the exact N1388 whole reviews and the primary qLTC Section 6. No initial report is rewritten.

## 1. Verdict

The scalar thermal drift, quantum CP killed comparison and repeatable gate/cooling mechanism can be proved at an explicit structural physical model. A simpler route uses the accepted Tanner commuting local energy/confinement/active-density interface and retains its radius-plus-energy basin; it does not need a new qLTC for storage or transversal CNOT.

I complete the principal's active-vertex refinement of qLTC Proposition 6.2.2 with an explicit constant below. This does not yet identify the addressable non-Clifford code with both required syndrome complexes.

The signed Dyson-to-positive step has a stronger short proof: its full module error is at most twice the signed tail for a CP/TNI gauge–bath map, or three times for a CPTP surrogate. Pre-gate filtering and generic coherent full/killed comparison still incur square-root losses.

This is a warm nonstationary thermal-basin and repeatable-gate theorem at explicit code/energy/descent/gate premises. It uses an engineered Davies-form Markovian reservoir plus a weak retained common-bath perturbation. It is not the earlier three-body exact-H microscopic-bath model, not automatically a Euclidean/two-body architecture, and not practical advantage or historical priority. Physical ports and the complete bill remain separate.

## 2. What accepted Tanner U authorizes

The accepted N1388 `GLOBAL_EXPONENTIAL_COMPILER.final.md` Section 1 gives a nonnegative integer local DATA energy with bounded commuting terms/read footprints, confinement and active density below a common linear radius, and bounded energy-lowering payload. `COMPANION_CONTROLLER_REVIEW.md` Section 1 specifies local integer distances/unary occupancies, not linear raw-check-bit weight; full raw syndrome labels the deterministic finite decision. `INDEPENDENT_REVIEW.md` Sections 1 and 5 retain the common radius and radius-plus-energy basin.

Thus one can define a NEW Hamiltonian `H=J U` from those actual local commuting DATA terms. One must not use the global F, activity congruence, proof pullback or analytical history weight R as a physical Hamiltonian.

A local distance term tabulated on a fixed raw-syndrome neighborhood R_h has the explicit operator formula

`u_h=sum_sigma u_h(sigma) product_(j in R_h)(I+sigma_j S_j)/2`.

Here S_j are the commuting checks in that neighborhood. Its finite Pauli expansion has bounded body size independent of n, although potentially enormous fixed support and term count. If actual unary occupancies already realize the energy, their projectors suffice instead. This does not assert equality with the ordinary linear check Hamiltonian.

SOURCE LIMIT: current notes/reviews carry an accepted structural code/energy interface, not every underlying local distance table or elementary-Pauli bill. A literal hardware claim requires those actual tables/coordinate maps and their expansion. The separate three-body unary compiler does not supply these new couplers for free.

## 3. Thermal memory theorem from local descent

### 3.1 Complete premises

Let a stabilizer/CSS family on n fixed-dimensional DATA cells have distance `d_n>=delta n` and a specified full canonical logical/syndrome frame. Assume:

1. `U=sum_v u_v` is nonnegative integer, commuting, bounded-incidence, bounded-body, raw-syndrome diagonal and zero on code states, with total scale O(n).
2. For canonical sectorwise reduced weight `r<r_dec n`, `U>=h r`. At least `kappa U` hubs have some bounded-support Pauli in a fixed finite local catalog decreasing U by at least one. Catalog/read/changed-energy incidence is bounded. CSS-sector corrections preserve the opposite sector.
3. Choose `r0<r_dec`, `2r0<delta`, `0<u_cut<h r0/2`, with strict fixed margins. Use the spectral basin `P={r_can<r0 n,U<u_cut n}`. Only global soundness could justify dropping its radius part.
4. Define `H=J U`. For each catalog Pauli P_a use exact Bohr components `A_(a,d)=P_a Pi_(a,d)` for change d of U, with at most M n labels, `|d|<=D`, and bounded full supports/incidence. Choose independent diagonal Davies-form channels with `r_a(-d)>=gamma>0`, `r_a(-d)<=Gamma`, `r_a(d)=exp(-beta J d)r_a(-d)` for d>0 and bounded r_a(0). The Lamb shift is a sum of local diagonal `A^*A` terms. Other cross-correlation/Lamb-shift contracts need checking.
5. Retain the actual common bath B and bath-only CPTP propagators. Add normal bounded-body joint HP perturbations N_Z with `N_Z^*(I)=0` and pointwise per-site sum of joint cb norms at most eta. The FULL joint interval evolution is CPTP and its P-compression is well-defined CP/TNI. For finite bounded generators it follows by repeated physical evolution/P-projection products; unbounded baths retain the actual domain/normality assumptions.
6. Initialization is a positive P-supported warm channel with the intended canonical logical action and a fixed logical-independent gauge–bath resource, with `Tr[exp(sU)rho_0]<=exp(nu_w n+O(1))`. References are arbitrary and inert.

### 3.2 Exact drift

Let `V_s=exp(sU)`. Energy-resolved components depend only on checks meeting their bounded Pauli support. Their exact action is

`L_beta^* V_s=V_s sum_(a,d)r_a(d)(exp(sd)-1)Pi_(a,d)`.

Every active hub supplies a downward term of size at least `gamma(1-exp(-s))`; discard additional negative terms by sign. Bound all positive terms by their fixed catalog count. On P,

`L_beta^*V_s <=[-a_s U+b_s n]V_s`,

`a_s=gamma kappa(1-exp(-s))`,

`b_s=M Gamma exp(-beta J)(exp(sD)-1)`.

Duplicate Pauli outputs at different hubs may remain distinct reservoir labels; their bounded incidence/count is charged. No unjustified distinctness is needed.

For a q-cell joint perturbation, factor the unaffected exponential. The affected factor lies between I and `exp(sK_q)I`. Bimodularity and the joint cb norm give

`+/-N_Z^* V_s<=C_s||N_Z^*||_cb V_s`.

Summing adds `C_s eta n V_s`, with no bath-dimension or Kraus coefficient-sum factor. Put `c_s=b_s+C_s eta`, `nu_eq=s c_s/a_s`.

### 3.3 Positive killing, coherent boundary and logical channel

Compress the FULL physical generator by `K_t(rho)=P L_t(P rho P)P`. For GKLS dynamics the compressed jumps are P A P and the extra loss is positive `P A^*(I-P)A P`. The corresponding evolution is CP/TNI. This is not compression of a signed similarity transform or individual HP terms. Since P commutes V_s, killing subtracts positive outgoing gains from the full compressed drift.

For subnormalized positive rho_P, x=Tr V_s rho_P, scalar spectral Jensen with mass <=1 gives `Tr U V_s rho_P>=x log x/s`, even with energy coherences. Hence

`log x(t)<=nu_eq n+[log x(0)-nu_eq n]exp(-a_s t/s)`.

Let K_edge bound the energy change of every local system leg, including complete-loss legs. For `C=P 1_(U<u_cut n-K_edge)`, every such leg A obeys A C=P A C. Source confinement gives `r_source<=U/h<r0 n/2`; a bounded Pauli increases the target minimum weight only by O(1), preventing a radius-only exit. Therefore

`p_boundary(t)<=exp(s K_edge)exp[-Delta_H n+O(1)]`,

`Delta_H=s u_cut-max(nu_w,nu_eq)>0`.

For general local joint HP maps, expand only finite SYSTEM legs. The full/compressed difference vanishes on C rho_P C. Gentle compression and the actual cb norm bound it by `4||L_Z^*||_cb sqrt(p_boundary)`. The total nominal norm is O(n); perturbations sum to O(eta n); bath-only terms have no boundary difference. Duhamel under the actual full CPTP propagators yields complete error

`C n T exp[-Delta_H n/2+O(1)]`.

For every retained local Pauli edge, source/target canonical corrections plus the bounded connecting Pauli have total weight below distance. Their zero-syndrome difference is a stabilizer, hence logical identity. This holds for all finite system legs, Hamiltonian/jump/loss terms and arbitrary bath coefficients. The killed map is `id_L tensor CP/TNI_aux`; its survival loss is controlled by the same comparison. One fixed decoder corrects the entire coherent span. No reference-dimension or Pauli-mixture assumption enters.

THERMAL WARM THEOREM: at the preceding premises and fixed `max(nu_w,nu_eq)<s u_cut` gap, HOLD preserves the intended arbitrary-reference logical channel for physical times exponential in n, with the displayed bound after a constant adjustment. Initial bad mass/writer error adds contractively. Low energy does not certify the intended input.

There is no detailed-balance incompatibility: take `r_a(-d)=gamma`, `r_a(d)=gamma exp(-beta J d)`. These exact paired rates define a Davies-form GKLS architecture. They do not prove an all-time microscopic weak-coupling approximation or a practical reservoir realization.

## 4. Completed qLTC active-vertex refinement

This verifies the principal's Section A. Primary source: Gay–Granha Jeronimo, *Asymptotically Good Quantum Locally Testable Codes*, arXiv:2609.20780v1, Section 6: Lemma 6.1.3, Lemma 6.2.1, Proposition 6.2.2, Theorem 6.3.1. Actual LaTeX formulas were extracted to `../auditor/qltc_section6_extract.txt`.

Fix a closed degree-k cochain x, support A, k<t. A vertex is active if some correction above it strictly decreases block weight. Let B be the active vertices and use the source's `r_l=n_- kappa_(t-l,k-l)`. Define fixed bounds

`S_l=max_(v in X(l))|X_(>=v)(k)|`,

`D_l=max_(v0 in X(0))#{v in X(l):v0<=v}`.

Call an l-face bad if ALL its vertices are active. If a face contains a nonactive vertex, every correction above that face is allowed above the nonactive vertex, so the exact local-minimality premise of Lemma 6.1.3 holds there. On a bad face the same inequality holds with slack `epsilon_v=r_l S_l`, since its left side is at most that number and its unmodified right side is nonnegative. Also `#bad_l<=D_l |B|`.

For a fixed k-face f, use the source's H_l,O_l,N_l and set `E_l(f)=sum_(v<=f,dim v=l,bad)epsilon_v`. The exact recursion is now

`r_l H_l<=O_l+N_l+E_l`, `N_0=0`,

`N_l<=(k-l+1)H_(l-1)`.

Substitution from l=0 upwards gives

`1_A(f)<=sum_(l=0)^k[(k-l)!/prod_(j=l)^k r_j][O_l(f)+E_l(f)]`.

Multiply by 1_A(f), sum and apply the unchanged walk bounds to O_l. The added terms obey `sum_(f in A)E_l(f)<=r_l S_l^2 D_l |B|`. Thus

`|A|<=lambda L_k |A|+Q_k |A|^2/Z_k+C_k |B|`,

`C_k=sum_(l=0)^k[(k-l)!/prod_(j=l)^k r_j]r_l S_l^2 D_l`.

Consequently, whenever `|A|<=(1-lambda L_k)Z_k/(2Q_k)`,

`|B|>=(1-lambda L_k)|A|/(2C_k)`.

All constants are tower-size independent under the source's fixed local geometry/coefficient hypotheses. This proves density, not just existence, of bounded-star descent.

APPLICATION GAP: identify BOTH actual syndrome complexes, including dual/transposed coefficients and the binary trace pairing. Fixed-width field/stalk block energy is a bounded-body commuting projector function, and each field correction becomes a bounded-support binary Pauli. But the addressable non-Clifford code must actually have the required two complexes/local-filling hypotheses; the qLTC headline alone does not prove it. Tanner/CNOT does not require this new import.

## 5. Strong positive surrogate for signed gate expansions

The constructor's positive CP/TNI construction survives the audit and has a shorter bound. Let `Gamma:L tensor G_pre -> L tensor G_post` be an actual joint CPTP gate channel, with G including the retained bath. On the FULL promised module suppose a signed HP approximation has

`Gamma0=U_L tensor C0`,

output support `Q=I_L tensor Q_post` and `||Gamma-Gamma0||_diamond<=delta_g`. C0 need not be positive or TP. Define

`C_g(theta)=Tr_L[Q Gamma(I_L/d_L tensor theta)Q]`.

This is CP/TNI and Q_post-supported. Compose Gamma-Gamma0 with maximally mixed logical initialization, Q-compression and Tr_L to get `||C_g-C0||_diamond<=delta_g`. The DIRECT triangle gives

`||Gamma-U_L tensor C_g||_diamond<=2delta_g`.

There is no need to first compare Gamma with Q Gamma Q, which would introduce an avoidable gentle square root. Its trace deficit has complete mass at most delta_g, since Gamma is TP and Gamma0 has no output outside Q. Add the CP map sending that positive deficit to a fixed Q_post gauge–bath state. The result C_hat is CPTP and

`||Gamma-U_L tensor C_hat||_diamond<=3delta_g`.

This is an analytical surrogate, not an extra physical bath-reset service. No input-dependent normalization occurs. The requirement is factorization on the entire promised logical/gauge module, including all syndrome coherences and bath coefficients. A one-state test does not establish it. The constructor confirmed this module identity in `constructor_processing_positive_repair.md` via each low-order system leg, with its explicit distance margin.

## 6. Gate/cooling recurrence with simultaneous fixed margins

Assume an ideal CODE-PRESERVING physical gate circuit has fixed depth/body. Let B_g be a charged Pauli-span spread bound in TOTAL SECTORWISE weight. For a general non-Clifford gate one may take twice its physical support spread, covering X/Z overlap; for CSS transversal CNOT the sharper sectorwise B_g<=2 holds. It need not preserve Pauli form. During actual duration tau keep the thermal Hamiltonian/reservoir/Lamb shift and joint perturbations present. In the ideal control frame assume `integral sum_Z ||L_Z(t)||_cb dt<=ell n tau`. Retain actual bath-only CPTP propagators between insertions; their self-Hamiltonian norm need not be bounded. After the finite control cone each insertion adds at most q_g TOTAL SECTORWISE Pauli weight; q_g includes the same possible factor of two. The JOINT time-ordered tail after m=ceil(theta n) satisfies

`delta_g<=sum_(r>=m)(ell n tau)^r/r!`

`        <=exp[-theta n log(theta/(e ell tau))+O(1)]`.

Choose `theta>e ell tau`. This may require large fixed peak control strength. The reservoir was counted, not removed. Calibration faults need their actual integrated norm. Arbitrary bath/control correlations are allowed only inside the joint support/norm contract.

Let K_E bound energy created per error-support cell on a code state. Choose fixed u_f,theta>0 so

`w_post=B_g u_f/h+q_g theta<r0`,

`2w_post<delta`, `u_post=K_E w_post<u_cut`.

First shrink u_f,theta relative to fixed code/circuit constants. Set `nu_star=s u_f/4`. Choose beta large and eta small so `nu_eq<=nu_star/2`; finally shorten tau for the gate tail. None of these choices depends on n,time or gate count.

At a service boundary the exact proof surrogate has P-support and moment coefficient <=nu_star. A proof-only gauge projection to `U<=u_f n` removes probability `p_f<=exp[-(s u_f-nu_star)n+O(1)]`. It commutes logicals; normalized channel change costs at most `2sqrt(p_f)+p_f` in full diamond. It is not a physical measurement/reset.

On that filtered module the canonical error span has weight <=u_f n/h. The ideal gate spreads it to <=B_g u_f n/h; <=theta n insertions add <=q_g theta n. The WHOLE retained signed map, including coherent left/right system legs and actual bath coefficients, lies in a common target correctable span of weight <=w_post n and energy <=u_post n. It factors on the full module as G_L tensor C0. Section 5 supplies a CPTP positive warm target surrogate at cost <=3delta_g and moment coefficient <=s u_post.

Choose a fixed cooling dwell tau_c with

`exp(-a_s tau_c/s)<=(nu_star/2)/(s u_post)`.

Its moment coefficient is at most nu_star. Normalizing the killed map costs O(1) in log moment, harmless to a fixed extensive gap. A stricter inequality reserves any desired slack. The dwell boundary exponent is at least `Delta_c=s(u_cut-u_post)>0`; its full/killed error is `C n tau_c exp[-Delta_c n/2+O(1)]`. The normalized killed surrogate is positive, has the target logical action and required moment. Thus induction closes. There is no unsafe burn-in: u_post is below the outer barrier BEFORE cooling.

For M gate bursts, total idle/dwell physical time T and initial earned writer error epsilon_W, telescoping through actual CPTP propagators gives

`error<=epsilon_W+C M exp(-c_gate n)+C n T exp(-c_hold n)`.

Choose c_gate below the minimum of `(s u_f-nu_star)/2` and `theta log(theta/(e ell tau))`; choose c_hold below `s(u_cut-u_post)/2` and the initial storage exponent. Polynomial prefactors may be retained or absorbed by a strictly smaller fixed exponent. All square-root losses have been accounted for.

Every exact proof surrogate factors logical from a positive gauge–bath resource, which may change after each gate/dwell and retain actual correlations. Estimates are uniform over it under the same incident-norm/physicality contract. The physical bath is not refreshed and no signed map is passed forward as a state.

A concrete operation is transversal CNOT between TWO IDENTICAL CSS blocks: it preserves the codes and B_g<=2. Express all constants in combined block size/minimum distance. This is an entangling logical operation, generally on corresponding logical block coordinates, not automatically selective universal computation. Addressed non-Clifford gates need their actual code/coordinate import; physical extraction needs its own noisy port.

## 7. A physical canonical projector, not a history-dependent cutoff

Fix one minimum SAME-SYNDROME Pauli E_sigma for every valid syndrome, with deterministic tie-breaking and phases. In CSS form choose sectorwise and let r_can be the sum of the sector weights; it upper-bounds physical weight. Fix the order of the X/Z factors. The full physical isometry is

`W(|psi>_L tensor |sigma>)=E_sigma Enc|psi>`.

Every syndrome space has the same logical multiplicity, so W is a full-space frame. Define

`P=sum_(sigma:r_can(sigma)<r0 n,U_sigma<u_cut n) Pi_sigma`.

It is a genuine physical syndrome projector and equals `I_L tensor P_gauge` in W. It includes ALL logical code states and does not depend on an unknown actual error's logical class. E_sigma is stabilizer-minimal as well, since otherwise it would not minimize over all representatives of that syndrome. Thus the accepted local confinement premise applies whenever its canonical weight is within the common radius.

For a physical q-supported Pauli A taking sigma to tau, one obtains a valid target representative by A E_sigma. Hence `r_can(tau)<=r_can(sigma)+2q` when X/Z supports are counted separately. The source confinement estimate `r_can(sigma)<=U_sigma/h<r0 n/2` prevents a radius-only exit for large n without assuming target confinement. For any retained sigma,tau, `E_tau^* A E_sigma` has zero syndrome and physical weight <=`2r0 n+q<d_n`, hence is a stabilizer (up to scalar phase). This proves the canonical logical identity for every local system leg and all off-diagonal syndrome operators. Complete-loss legs require their full support, possibly twice a jump's primitive support, in q and K_edge.

Defining P instead by minimum weight inside the unknown ACTUAL error/logical class would be invalid: it would be a history-dependent promise, not the physical projector needed for CP killing. The fixed same-syndrome convention resolves that concern.

## 8. Comparators, limits and final status

I checked Hong–Guo–Lucas, *Quantum memory at nonzero temperature in a thermodynamically trivial system*, [arXiv:2403.10599v3](https://arxiv.org/html/2403.10599v3), especially its qLDPC confinement/bottleneck memory and Appendix E. Gibbs-sampler measurement-free correction, bounded-body Pauli fault discussion and finite-depth implementation already exist there. Passive qLDPC storage or thermal correction alone is not a new priority claim. Its stationarity-restoring rate adjustment differs from the perturbation-uniform nonstationary Lyapunov theorem above; priority for that exact strengthening remains unestablished.

The 2D autonomous universal computer and 3D passive memory remain strong comparators at their exact scopes. This architecture pays all local energy/coupler tables, potentially huge fixed correction catalogs, reservoir spectral/rate engineering, low temperature, continuous cooling and fast finite gate controls. No Euclidean embedding or three-body realization is supplied. If conventional FT earns the ports, the active comparator receives the same controls and resources.

The theorem's nominal THERMAL reservoir is an exact specified Davies-form Markovian primitive. The separately RETAINED bath can have memory and arbitrary correlations under the joint weak local norm contract. Calling those two objects the same microscopic bath would silently strengthen the theorem. No exponential-time microscopic weak-coupling approximation is derived. The previous three-body exact-H model remains separate.

Bare input/output fault floors remain. Protected ports or an explicit endpoint-noise target are required. Analytical normalization/positive replacement is not additional physical recovery, bath reset or cooling work.

| Claim | Status |
|---|---|
| Detailed-balance completion of bounded local descent | PROVED structural construction |
| Warm coherent/reference-safe basin with CP killing | PROVED at stated code, physicality and joint norm premises |
| Quantitative qLTC active-vertex refinement | PROVED at exact Section 6 hypotheses |
| Signed gate tail to positive bath map | PROVED, <=2delta TNI / <=3delta TP |
| Repeated finite gates plus cooling dwells | PROVED at simultaneous fixed margins |
| Transversal CNOT on identical CSS blocks | Fits at code-interface level |
| Literal Tanner tables/elementary Pauli catalog | Structural interface accepted; not all tables pinned here |
| Both addressed non-Clifford syndrome complexes/coordinates | Not yet verified |
| Full noisy ports and complete resource bill | OPEN |
| Earlier three-body exact-H noisy-writing basin | Separate and OPEN |
| Practical advantage / experimental capability / historic priority | NOT ACHIEVED / UNKNOWN |

The complete STRUCTURAL compiler theorem does not require a numerical gadget catalog: its output is the exact finite local-distance Hamiltonian formula, explicit Davies jump/rate construction, warm moment law and gate/dwell parameter choices above. Literal hardware specialization and universal-code imports are further obligations. Next close one compatible protected noisy port and compare complete preparation/coupler/control/cooling/readout costs. Do not replace those operations with a stronger label for the theorem.
