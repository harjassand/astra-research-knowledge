# Exact HPL predecessor and screened complexity connections

7 November 2026. Primary files and hashes: ../sources/PRINCIPAL_LATE_PRIMARY_PINS.json.

## Verified import: Crainic's perturbation lemma

Marius Crainic, *On the perturbation lemma, and deformations*, arXiv:math/0403266v1 (16 March 2004), Section 2.4 Main Perturbation Lemma and Section 3.2 (special deformation retracts); definitions 2.1-2.2 and Remark2.3. The number is 2.4, NOT 2.3.

Hypotheses: complexes, quasi-isomorphic chain maps i,p with the specified homotopy; a differential perturbation delta such that (d0+delta)^2=0 and 1-delta h is invertible. Special retracts additionally have pi=1, hi=ph=h^2=0. Put A=(1-delta h)^(-1)delta. The resulting i1=i+hAi, p1=p+pAh, h1=h+hAh and perturbed critical differential dH+pAi give the perturbed homotopy data; a special retract remains special by3.2.

Applicability to our anchored arrays: finite Gaussian elimination on each local cube/star supplies an exact special contraction. Both actual critical inclusions are invariant under the other differential. All maps are linear over the fixed characteristic-two field; the proof is algebraic over that field. The finite p filtration makes h delta and delta h NILPOTENT of bounded degree, so the inverse is a finite polynomial, with no analytic smallness or N-dependent norm bound. Invariant critical range makes h delta i=0 and hence i1=i. In characteristic two, plus/minus signs agree, giving h'=(I+h delta)^(-1)h and p'=p(I+delta h)^(-1).

The homological perturbation identities are therefore established machinery. What is checked additionally is the paired-basis I+Q triangular normal form, its inverse locality, physical CSS/ancilla interpretation, and use of the two presentations to build a commuting two-sector descent energy. Do not claim invention of HPL, local Gaussian elimination or a generic homological algebra theorem.

## Eldar: thermal qLTC decoding is older machinery

Lior Eldar, *Robust Quantum Entanglement at (nearly) Room Temperature*, arXiv:1911.04461v3 (8 September2020); ITCS2021 version exists. I inspected the v3 primary introduction and its stated main result to identify its scope: qLTC thermal error control and shallow local decoding are used for a circuit-depth lower bound with nearly constant temperature and logarithmic locality. This is an important predecessor to using local testability, thermal distributions and decoding together. No nonstationary arbitrary-writer-to-long-HOLD or same-bath gate-service theorem is imported from it. Exact temperature scales differ among versions; this record does not substitute an abstract from another version for the pinned result.

## New connection screened, not promoted: NLTM and useful magic

Wei--Han--Li--Liu, *NLTM Hamiltonians from gauged sheaf quantum locally testable codes*, arXiv:2609.40220v1 (30 September2026). I read the abstract/introduction and criteria discussion, not every proof. Its low-energy logical/excitation decomposition is a relevant prior protected-algebra connection. The paper's claimed intrinsic NLTM means a circuit-depth obstruction for preparation from bounded-alphabet stabilizer inputs. It is not by itself a physical noisy writer, thermal equilibration theorem, efficient magic extractor, or a positive distillation-rate guarantee.

Possible larger opening: give an efficient fault-tolerant stabilizer-operation extraction service producing useful non-Clifford resources from a low-temperature protected non-Abelian phase, with bath/preparation/full-cycle costs. Decisive missing operation is the actual extractor plus its admissible noisy basin and rate. This dossier does not solve that operation or use NLTM as a black-box capability theorem. No score or priority is awarded to the connection.
