# Machinery challenge and constructive completion: thermal processing

7 November 2026. Follow-up after all independent initials froze. This report addresses the principal's `qltc_thermal_descent_route.md`; it does not rewrite any initial report.

## 1. Strongest constructive conclusion

The GJ cochain support recursion admits the requested **quantitative active-vertex refinement**. The raw transpose-sector descent is not in the source and must not be inferred from headline qLTC soundness. It can instead be repaired by a constant-factor CSS product-ancilla extension with a different commuting local syndrome energy. The anchored-array double complex has two exact bounded-propagation stabilizer normal forms; their type-swapped Clifford relation pulls K's cochain energy back into the original X stabilizer algebra. Together with original F cochain energy in the Z algebra, this gives `U=UF+UK`, with both sectors descending independently.

The common ground space in the preferred coordinates is **exactly original Li DATA code plus specified product ancillas**. Thus original addressed CCZ circuits act on DATA and identity on the added memory ancillas. Optional repetition for literal disjoint one-layer transversality is unnecessary; their original bounded-incidence cubic circuits already have constant depth.

The principal independently found the same filtered-pivot normal form. The hostile auditor checked the triangular algebra and ancilla/type bookkeeping and reports no remaining algebraic blocker at this scope, with the physical convention addendum below. This focused agreement is not a completed review of the whole thermal/noise/gate service.

## 2. Derivations and frozen version

- [Active-vertex proof](../machinery/active_vertex_refinement.md): explicit C_j and threshold, obtained by carrying additive exceptional-face slacks through Proposition 6.2.2.
- [Frozen dual-energy v1](../machinery/dual_sector_local_energy_v1.md): full local normal-form derivation, stabilizer equality, two-sector energy, gate-coordinate alternatives and bibliography. SHA-256 `e5b32ab3a0898a84ae9e6577ae952b95228b3fb0c7cfe7506b8b050ba5e8ae2d`.
- [CSS convention addendum](../machinery/DUAL_ENERGY_V1_CONVENTION_ADDENDUM.md): use Li Definition 2.1/equation 2.7's H_Z orientation; GJ labels the two CSS sectors oppositely. Original memory ancillas are the H-pullback of the horizontal normal-form contractible-pair states.
- [Thermal completion theorem](../machinery/thermal_completion_theorem.md): explicit local Bohr components, rates, moment drift, warm confinement and logical boundary argument.
- [Primary import and novelty audit](../machinery/thermal_import_audit.md): exact construction match and strongest prior thermal/active/autonomous comparators.

## 3. Quantitative cochain descent, with no missing density step

For degree-j closed cochain b with support A, let B be vertices admitting a strictly decreasing upward-star correction. Define `r_l=n_- kappa_{t-l,j-l}`, `D_{j,l}=max_v |X_{>=v}(j)|` and `c_{j,l}=(j-l)!/product_{m=l}^j r_m`. An l-face is exceptional iff all its vertices are active. At every other face, Lemma 6.1.3 applies unchanged by selecting an inactive vertex. At an exceptional face add slack r_l D_{j,l}.

The exact recursion yields

`|A|<=sum_l b_jl<1_A,W_jl 1_A>+C_j|B|`,

`C_j=sum_l c_{j,l}r_l D_{j,l}D_{j,0}binom(j,l)`.

Mixing therefore gives

`|B|>=(1-lambda L_j)|A|/(2C_j)`

for `0<|A|<=(1-lambda L_j)Z_j/(2Q_j)`. This is a proved local-density strengthening at fixed field/degree constants, not an assertion that one existing descent implies many.

## 4. The physical transpose repair

Use actual arrays `A^{r,p}` with total chain degree p-r and differential T+Delta. Horizontal Delta contracts each finite cube to the physical transpose chain C_*(F). Vertical T contracts each finite upward-star transpose complex to C^{t-*}(K). Both critical subspaces are invariant under the other differential. Finite perturbation series terminate because the remaining terms move strictly through the p filtration.

The exact basis construction `a_i'=h'd0a_i`, `b_i'=d a_i'`, with `h'=(I+h delta)^(-1)h`, is I+Q triangular in p after local initial block bases. Q is nilpotent in a bounded number of steps. Thus the basis change AND inverse are bounded-propagation, bounded-incidence matrices. In code degree k they are CSS Clifford coordinate changes; contractible pairs at adjacent degrees are product |0>/|+> qubits. Sparse-matrix CNOT synthesis with O(N) temporary |0> work realizes the coordinate map at constant depth if actual application is needed.

After the global H swap, choose C mapping original Q_k(F)+A_original to Q_{t-k}(K)+A_target. Define

`UF=original cochain syndrome block weight + original Z-ancilla defects`,

`UK=C^*[K cochain syndrome block weight + target Z-ancilla defects]C`.

UF is purely Z-type and UK purely X-type in ORIGINAL coordinates. They impose the complete original S_Z and S_X, respectively. Original X-star descents preserve UK exactly; pulled-back K X-star descents are original Z and preserve UF exactly. The conservative weighted energy initially considered in the note is unnecessary; its actual cross-energy bound is zero. Both active densities add to a linear density for U=UF+UK.

This changes the energy and adds a constant factor of product ancillas. It does not prove raw physical transpose syndrome weight decreases under the original star catalog.

## 5. What the thermal compiler then earns

For H=JU and the actual bounded-support Pauli catalog, choose paired rates `r(d)=exp(-beta Jd)r(-d)`, with every downward rate >=gamma and a fixed upper rate Gamma. Their Bohr components remain bounded-support because unaffected commuting energy factors cancel. The exact drift is

`L_beta^* exp(sU)<= [-a_s U+b_s N]exp(sU)`,

`a_s=gamma kappa(1-exp(-s))`,

`b_s=M Gamma exp(-beta J)(exp(sD)-1)`.

Weak fixed-body joint perturbations add C_s eta N to the source under the same actual CPTP and positive-killing hypotheses as the principal route. The moment contracts to `nu_eq=s(b_s+C_s eta)/a_s`. A reference-uniform warm CP writer with intended logical action, safe support and coefficient nu_w<s u_cut gives channel error

`writer_bad + C N T exp(-cN)`,

with `c<(s u_cut-max(nu_w,nu_eq))/2`. The generic coherent square-root loss is retained. This produces the nonstationary cooling service needed by the principal's gate workload recurrence, rather than merely a stationary mixing lower bound. The original DATA gate still needs the principal/auditor's finite-duration bath/noise and positive-surrogate proof; this report does not certify that separate step.

For direct fallback, the accepted native Tanner local distance U already has both-sector descent. The same thermal compiler applies at its actual confinement/radius scope and supports repeatable transversal CNOT as supplied by the code, without claiming a new code. The GJ dual-energy transfer is what adds compatible explicit non-Clifford DATA.

## 6. Priority and capability correction

Hong--Guo--Lucas (Nature Communications16,316,2025; 2403.10599) already supplies passive constant-rate qLDPC Gibbs sampling and finite-depth measurement-free QEC with sufficiently weak incoherent gate/reset faults. Its formal Theorem B.8 is HGP exp(alpha sqrt N) slow mixing with a specially weighted starting ensemble, but generic Metropolis completion is clearly prior machinery.

Bombin--Chhajlany--Horodecki--Martin-Delgado (NJP15,055023,2013;0907.5228v2), Sections VI.5 and VIII.3, already combines thermal memory with sudden noise tolerance and fast transversal useful gates on higher-dimensional color codes. The notion of thermal protected computation is therefore not new.

The strongest possible scoped new result here is the **uniform nonstationary warm-basin plus sustained gate/cooling service on the particular constant-rate linear-distance addressed-CCZ code, with one compatible engineered Markovian reservoir and full bounded-body noise/control accounting**. Its constituent local-energy and active-density transformations are explicit derivations, with no firstness established. Universal computation, generic microscopic exact baths, physical 3D locality, economical constants and matched advantage remain unproved. The 2D autonomous universal QCA and constant-overhead active FT are stronger existing capability comparators in their respective models.

Recent Zenodo API title queries and exact record checks were saved. Searches were noisy and bounded; they establish no absence or priority theorem. Soryun IV remains a meaningful but different fixed-domain spatial-regularity/non-Markovian common-recovery construction.

## 7. Required final scope

Keep four distinctions explicit in any consolidated theorem:

1. Engineered Davies/Metropolis GKLS dynamics are the actual mathematical model; no infinite-time validity of a microscopic weak-coupling derivation is claimed.
2. The added local commuting energy can have large fixed body size, incidence, field dimension and catalog size. No elementary two-/three-body or Euclidean geometry transfer is automatic.
3. The useful gate family is addressed CCZ on a selected linear payload with unused logical/field coordinates initialized as in Li's source. Clifford completion, noisy ports and universality remain additional interfaces.
4. Raw arbitrary inputs have an unavoidable endpoint floor at fixed first-exposure noise. Encoded ports can have exponentially small error; bare endpoints must retain their declared floor.
