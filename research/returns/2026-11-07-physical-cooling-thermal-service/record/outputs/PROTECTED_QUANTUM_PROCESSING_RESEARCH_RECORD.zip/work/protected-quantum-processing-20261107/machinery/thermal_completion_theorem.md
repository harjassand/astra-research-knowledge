# Thermal completion of an actual descending local Pauli catalog

7 November 2026. This is a compiler statement credited to established Gibbs-sampling ideas. Generic Metropolis completion or passive qLDPC storage is not claimed novel.

Assume commuting nonnegative INTEGER energies U_N on N qubits, with O(N) bounded-incidence, bounded-support Pauli-function terms. At most M N Hermitian Pauli labels P_h have bounded support/incidence and change U by at most D. In U<u_cut N, suppose at least kappa U labels strictly lower U. Suppose every sufficiently low valid syndrome has a canonical correction of weight <=C U, and code distance is delta N. Choose `2C u_cut<delta` strictly. These are actual code/catalog hypotheses.

Set H=J U. Let Pi_{h,d} project onto eigenvalue d of `P_h U P_h-U`, and set `P_{h,d}=P_h Pi_{h,d}`. Only energy terms intersecting P_h enter this difference, so each Bohr component has bounded support, despite its globally written spectral definition. Choose rates

`r(-d)>=gamma>0`, `r(d)=exp(-beta J d)r(-d)<=Gamma exp(-beta J d)`

for d=1,...,D. Use GKLS jumps sqrt(r(d)) P_{h,d}. Opposite components are adjoints. The rate relation makes exp(-beta H) stationary. This is an engineered Markovian model, not an exponentially long exact microscopic-bath approximation.

For V_s=exp(sU), direct multiplication gives

`L_beta^* V_s=V_s sum_{h,d}r(d)(exp(sd)-1)Pi_{h,d}`,

hence on the safe sublevel

`L_beta^*V_s<=[-a_s U+b_s N]V_s`,

`a_s=gamma kappa(1-exp(-s))`,

`b_s=M Gamma exp(-beta J)(exp(sD)-1)`.

The positive d projectors for a fixed h are orthogonal, so no extra D factor is needed. Zero-energy moves do not affect V_s.

Fixed-body joint HP perturbations with pointwise per-site SUM of cb norms <=eta contribute at most `C_s eta N V_s` by factoring unaffected commuting energy terms from each bounded patch. The complete joint process must have CPTP interval propagators and its P-compression must be CP/TNI. Signed HP pieces are not separately treated as physical generators.

For a positive killed subnormalized sigma on P=1_{U<u_cut N}, x=Tr V_s sigma obeys scalar spectral Jensen:

`Tr U V_s sigma >= x log x/s`.

Consequently

`(log x)'<=-(a_s/s)log x+(b_s+C_s eta)N`,

and its extensive coefficient contracts toward

`nu_eq=s(b_s+C_s eta)/a_s`.

An EARNED CP good warm writer, with correct canonical logical action, P-support and `x(0)<=exp(nu_w N)`, has a boundary tail

`exp(sD_edge) exp[-(s u_cut-max(nu_w,nu_eq))N]`

whenever `max(nu_w,nu_eq)<s u_cut` by a fixed margin. Generic coherent whole-generator comparison yields full-versus-killed half-diamond error `C N T exp(-cN)`, for any `c<(s u_cut-max(nu_w,nu_eq))/2`, plus separately priced writer bad mass. The half exponent is retained.

Both endpoint canonical corrections and a retained bounded-support Pauli have total weight below code distance; their zero-syndrome product is a stabilizer. Therefore every retained local matrix leg acts as logical identity in the canonical frame. This gives a reference-uniform channel theorem, not just a stationary observable estimate. Positive killing must use the FULL physical generator.

Physical LS preparations enter by the CP support-mgf argument of the independent machinery initial (F=V_s, g=q=0). The accepted native Tanner two-sector local distance energy directly supplies this compiler input at its existing confinement/radius scope. The GJ non-Clifford gate-code input follows from the active-vertex lemma and stable dual-energy extension at their audited algebraic scope.

A simpler STORAGE-ONLY all-low-energy result needs no descent: for rho supported U<=u_pre N, `rho<=exp(beta J u_pre N)exp(-beta H)`. Gibbs preservation gives boundary mass <=`exp[(log2-beta J(u_cut-u_pre))N]`. Sufficiently cold LINEAR barriers tolerate this exp(volume) order constant. This does not provide fast re-cooling, weak non-Gibbs perturbation robustness or repeatable gate service.
