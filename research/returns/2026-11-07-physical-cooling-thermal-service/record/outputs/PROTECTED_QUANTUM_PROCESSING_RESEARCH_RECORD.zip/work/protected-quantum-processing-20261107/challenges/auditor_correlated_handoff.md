# Strong correlated-state handoff: no writer decoupling is required

7 November 2026. Requested hostile check of the principal's stronger statewise handoff. This supersedes the NEED for a logical-independent writer surrogate in this new structural thermal theorem; the earlier independent report and KSW refinement remain frozen valid sufficient results.

## 1. Exact positive-loss lemma

Let L be the logical subsystem, A the syndrome/gauge, B the actual retained bath, and R any external reference. Let K be a CP/TNI map on AB and let rho_LABR be any positive subnormalized state, with arbitrary correlations among all four systems. Put

`rho_LR=Tr_AB rho`,

`sigma_LR=Tr_AB[(id_LR tensor K)rho]`,

`D=I_AB-K^*(I_AB)>=0`.

Then

`rho_LR-sigma_LR=Tr_AB[(I_LR tensor sqrt(D))rho(I_LR tensor sqrt(D))]>=0`.

Proof: pair both sides against an arbitrary LR observable O. The left pairing is `Tr[(O tensor (I-K*I))rho]`; cyclicity on AB gives the square-root sandwich pairing. Equality for every O proves the formula. Therefore

`||rho_LR-sigma_LR||_1=Tr rho-Tr[(id tensor K)rho]=ell`,

where ell is the trace/survival loss. This holds for entangled rho. It does not assert that the NORMALIZED postselected survivor has the same LR marginal.

## 2. Correlated-state storage theorem

Suppose P is the physical basin `I_L tensor P_AB` and the full killed propagator has EXACT action `id_L tensor K_T` on the entire promised module. Assume the actual full propagator Phi_T is CPTP and, for the admitted initial state rho, the full-versus-killed trace bound is

`||(Phi_T tensor id_R)(rho)-(id_LR tensor K_T)(rho)||_1<=epsilon_T`.

Because Phi_T preserves trace, ell<=epsilon_T. Partial trace, the positive-loss lemma and the triangle inequality imply

`(1/2)||Tr_AB Phi_T(rho)-rho_LR||_1<=epsilon_T`.

The thermal moment, boundary and Duhamel proofs in `auditor_thermal_processing.md` apply to ANY P-supported positive rho satisfying the same moment margin. They use its system/bath marginal and scalar spectral Jensen only; no logical/bath factorization enters. The canonical local-leg proof supplies the exact subsystem action on all logical/gauge operators, not merely on product inputs. Consequently the stated storage estimate holds with arbitrary initial logical/gauge/bath/reference correlations.

If the current actual state arises from a physically specified writer channel, there is no channel-assignment ambiguity: that writer supplies the actual correlated state for each reference input, and the statewise bound is uniform over it.

## 3. Writer composition without a KSW loss

Let W be an actual CPTP joint writer from input L0 to the memory and retained bath. In the specified canonical frame assume, uniformly over all input/reference states:

1. Immediate decoded half-diamond error is <=epsilon_IO.
2. Actual output is P-supported.
3. Actual output has `Tr V_s rho<=exp(nu_w n+O(1))` at the fixed warm margin.

Applying Section 2 to W(input), then adding immediate decoded error, gives

`d_diamond(Dec o Phi_T o W,id_L0)<=epsilon_IO+epsilon_T`.

No joint writer approximation, factorization, Stinespring continuity or square root of epsilon_IO is necessary. The physical gauge–bath state may depend on the logical input and reference through arbitrary correlations.

If actual writer output has outside-basin probability at most delta_P, use rho_P=P rho P, keeping it SUBNORMALIZED. Gentle projection gives `||rho-rho_P||_1<=2sqrt(delta_P)`. Its moment is no larger because P commutes V_s. Comparing both initial and final marginals to the projected process gives the conservative complete bound

`end_to_end_error<=epsilon_IO+epsilon_T+2sqrt(delta_P)`.

Thus the remaining square root is of physical ENERGY/BASIN leakage, not immediate logical accuracy. If a positive good-history instrument already isolates the bad output, its actual mass can instead be charged directly.

## 4. Gate and filter composition

For an intended unitary G_L, replace id_L by Ad_G in the lemma. A full-module surrogate `Ad_G tensor C_g` with C_g CP/TNI retains the actual auxiliary map and has a positive marginal loss. The 2delta_g pulse repair from `auditor_thermal_processing.md` therefore suffices; no need to normalize or complete C_g after every step.

For a sequence of fixed gates, the exact proof composition is the intended logical product tensored with a CP/TNI auxiliary product. Its final LR deficit is positive with trace equal to total survival loss, even for initially correlated states. Approximate each actual service interval by that product using CPTP/TNI complete contraction and telescope. Bound final survival deficit by the trace difference from the actual trace-preserving process.

The pre-service energy projection is itself `id_L tensor [Q(·)Q]`, CP/TNI. Its immediate LR loss is its probability, although bounding physical future effects of removed coherences may still need the gentle square root. All intermediate proof maps may remain subnormalized. This avoids normalization-induced logical bias on correlated inputs.

## 5. Scope

This is a genuine strengthening of the NEW structural thermal processing theorem. It relies on the exact logical subsystem property of its full killed dynamics and a state-uniform moment/boundary theorem. The old N1694 equilibrium/short-handoff results do not supply those uniform premises; no inference that its memory fails is made. Likewise the initial perfect-reduced-writer counterexample remains valid for a future channel without this uniform protected-subsystem contract.

Bare-input/output noise floors, actual basin entry and resources remain. The theorem can preserve the immediate decoded input faithfully for a long time; it cannot undo an unknown error already made before protection.

## 6. Strongest service proof: keep every auxiliary map CP/TNI

The principal's further simplification is valid and preferable. Keep the prefilter `Q(·)Q`, the 2delta_g gate surrogate C_g, and the killed dwell all SUBNORMALIZED CP/TNI. No normalization or TP completion is needed at any step. Thus no logical bias from correlated postselection is introduced into the proof.

All scalar estimates remain valid: prefilter commutes V_s and cannot increase its moment; gate output has `x<=exp(s u_post n)Tr rho<=exp(s u_post n)`; the dwell Jensen/drift law was proved for positive trace<=1. The same fixed extensive margins close the recurrence. Filtering cost uses absolute removed mass, not a conditional probability divided by survival.

The whole exact proof process is the intended logical product tensor one CP/TNI auxiliary product. Apply the positive-loss lemma ONCE at the end and bound its trace deficit by the complete trace-norm difference from the actual trace-preserving process. This proves sustained processing for arbitrary initial logical/gauge/bath/reference correlations admitted by the energy/moment hypotheses. It removes the need for any logical-independent reset, KSW writer lift, or normalized warm survivor in this stronger theorem.
