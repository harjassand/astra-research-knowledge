# Sharpened positive joint-pulse repair: 2 delta TNI, 3 delta TP

7 November 2026. Joint constructor/auditor cross-challenge. This strengthens Section 5 of constructor_processing.md. The earlier square-root bound was valid but unnecessarily weak. Initial independent files remain unchanged.

## Full promised module, not only one gauge state

Let V_in identify the entire promised pre-input subspace with L tensor G, with the actual retained bath included in G. The input support is the common good pre-energy/weight projector. For each syndrome basis state sigma the DATA embedding is E_sigma Enc, with wt(E_sigma)<=C u_pre N.

After a fixed-depth code-preserving gate G_phys and at most m local background insertions, each system operator leg has support at most

    w_post N = B C u_pre N+B q m.

Every resulting syndrome has energy <=D w_post N<=u_post N. Select the SAME post-canonical corrections E_eta, each with weight <=C u_post N. Require

    w_post+C u_post<delta.

For each Pauli coefficient P of any resulting operator leg, P Enc and E_eta Enc have the same syndrome. Their product has weight below distance and is therefore a stabilizer, up to scalar. Consequently the exact operator relation is

    V_out^dagger A_path G_phys V_in
       = U_L tensor a_path,

on the ENTIRE promised L tensor G module, with arbitrary bath matrix coefficients. It holds for off-diagonal sigma/sigma' inputs and arbitrary correlations with references. No choice of the logical input or gauge density matrix enters this relation.

Thus the truncated joint Duhamel superoperator is genuinely

    Gamma_0 = Ad_(U_L) tensor C_0

as a linear map on the full promised module, not merely a factorization of its output for one selected product input. C_0 is HP and may be nonpositive. The direct operator relation above is the essential condition. If one had verified only a single test state, the channel-level conclusion below would not follow.

## Positive repair

Suppose the actual joint channel Gamma is CPTP and

    ||Gamma-Gamma_0||_diamond<=delta.

Let Q be the output good-energy/weight projector. Gamma_0 is Q-supported and Q acts trivially on L. Define the physical compressed map

    A(X)=Q Gamma(X)Q.

On the actual ancillary/bath algebra define

    C(theta)=Tr_L [
       Ad_(U_L^dagger tensor I) A(I_L/d_L tensor theta)
    ].

Appending I_L/d_L, physical compression, conjugation and partial trace are all CP and complete-norm contractions. C is therefore CP/TNI and Q-supported. Since applying the same operations to Gamma_0 gives C_0,

    ||C-C_0||_diamond<=delta.

Directly, without a gentle projection comparison,

    ||Gamma-[Ad_(U_L) tensor C]||_diamond
       <=||Gamma-Gamma_0||_diamond
          +||Ad_(U_L) tensor (C_0-C)||_diamond
       <=2delta.                                         (A)

This is the complete diamond norm on the promised module. It retains the same G, including the same actual bath and its preexisting correlations. The tensor factor is a linear CP/TNI map on that bath, so it composes across the entire service.

The missing trace is at most delta. Indeed, the positive effect

    R=I-C^*(I)

satisfies ||R||<=delta because Gamma_0 is Q-supported and the actual outside-Q probability is at most delta for every I_L/d_L tensor theta input.

If a normalized CPTP warm surrogate is wanted, choose any fixed normal good-energy gauge/bath state tau_* and add

    D(theta)=Tr(R theta) tau_*.

D is CP, has complete norm ||R||<=delta, and C+D is CPTP. Hence

    ||Gamma-[Ad_(U_L) tensor (C+D)]||_diamond<=3delta.      (B)

This optional trace completion is a mathematical comparison on an already charged O(delta) branch, not an actual reset or replacement of the physical bath. The CP/TNI version (A) is preferable for service induction and needs no bath completion at all.

## Improved service exponent

With the explicit pulse budget in constructor_processing.md,

    delta_g<=2 exp[-alpha N log8],

so the TNI pulse error is at most

    4 exp[-alpha N log8],

rather than a square root of this tail.

Pre-energy clipping still has its gentle square root, and the generic coherent storage/killing comparison still has its boundary square root. The service bound becomes

    epsilon_joint
       <=epsilon_writer
         +C_H N T exp[-(s u_cut-s u_post)N/2+O(1)]
         +M[2 exp(-s u_pre N/4)+2delta_g].

A final half-diamond logical error is at most epsilon_joint after including the good-map survival deficit. All positive TNI ancillary maps compose on the same environment.

## DATA-only Tanner fallback

For the changed architecture H=J U built directly from the accepted Tanner DATA energy, there are no native controller clocks and no native forest inverse. An ordinary transversal CNOT between identical CSS blocks is therefore the actual fixed-depth ideal G_phys in this proof.

Retain the accepted common weight+energy basin, because confinement alone does not give globally small correction for every small syndrome. Within this basin confinement gives C=1/h. Choose u_post and w_post additionally below the inner weight-cutoff margins. Every gate-output error has an explicit low-weight representative by the support calculation, so it belongs to that basin and the fixed canonical convention is valid.

The elementary code/cooling model is changed from N1388's powered finite controller and from N1694's three-body clocks. Its bounded-body detailed-balance jump catalogue can use all accepted local hub Paulis and their reverses; both actual CSS sectors are already part of the accepted DATA input. This avoids an unverified transpose-complex local-descent import.

The service theorem does not claim a microscopic thermal reservoir construction, a three-body/3D realization, universal computation from CNOT alone, or an active-FT advantage.

## Primary predecessor checked after parent correction

Hong–Guo–Lucas, arXiv:2403.10599v3, Sections 3-4 and Appendices B,E, already treats constant-rate hypergraph-product LDPC thermal memories and a finite-depth measurement-free Gibbs-sampler implementation. Theorem B.8/Corollary B.9 use a bottleneck ensemble near a codeword; Appendix E.3 modifies rates for local Pauli errors to retain the target stationary law. This is substantive predecessor machinery, not a new “Metropolis completion” here.

The distinct operation being proved here is a joint nonstationary moment-basin gate service under actual finite pulses, retaining the common environment and charging repeated burst/cooling errors. Historical novelty of that precise synthesis still needs broader checking.

Primary: https://arxiv.org/html/2403.10599v3

