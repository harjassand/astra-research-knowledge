# Protected quantum processing: research record

Research date: 7 November 2026. This record accompanies [the consolidated dossier](../../outputs/PROTECTED_QUANTUM_PROCESSING_RESEARCH_DOSSIER.md) and [the theorem/status ledger](../../outputs/PROTECTED_QUANTUM_PROCESSING_THEOREM_LEDGER.json). It is a research return, not a publication release.

## Governing final proof and reviews

- [Consolidated thermal service](principal/THERMAL_SERVICE_THEOREM.md), SHA256 bb4e12ae7cc82ed68f94d4b162f6c9a85e08671fd88b805a510ee47058666b40.
- [Version-bound thermal service review](challenges/auditor_thermal_service_final_review.md).
- [Frozen stable local duality/energy](machinery/dual_sector_local_energy_v1.md) and [CSS convention addendum](machinery/DUAL_ENERGY_V1_CONVENTION_ADDENDUM.md).
- [Independent stable-duality check](challenges/auditor_stable_duality.md).
- [Correlated-state handoff and unnormalized composition](challenges/auditor_correlated_handoff.md).
- [Positive pulse repair](challenges/constructor_processing_positive_repair.md).
- [Version-bound port audit](challenges/auditor_quantum_ports_review.md).
- [Encoded-port closure](challenges/quantum_ports_closure.md), [coherent decoder addendum](challenges/quantum_ports_coherent_decoder_addendum.md), and [exact CFG imports](machinery/CFG_PORTS_IMPORT_AUDIT.md).
- [Principal adjudication](principal/ADJUDICATION.md) and [verified HPL predecessor/screened connections](principal/HPL_IMPORT_AND_CONNECTIONS.md).

- [Final dossier consistency review](challenges/FINAL_DOSSIER_CONSISTENCY_REVIEW.md).

## Independent initials, never retroactively rewritten

Exactly three GPT-6.1 Sol maximum-reasoning researchers and the principal wrote separately before exchanging reports:

- [principal](initial/principal.md): 863ad29f6951c2596189db9ad929793a6e5523e453203451346d0cdd7b31f0c3
- [machinery](initial/machinery.md): 6baa2223900dfd66a82e312709b09f3418483c0411a48ebbf638a5988de9f0bf
- [constructor](initial/constructor.md): 21d053255b8337a37f057f0c367d8a06043e9bfa1964c9929a31e69e4053be60
- [auditor](initial/auditor.md): 0d2debc4f800d5a3d0dc3376fd358b233f965d61ac5f581f5091759ed46b3d7d

The principal's later [thermal route](principal/qltc_thermal_descent_route.md) and the challenge files preserve the raw-transpose obstruction, its constructive repair, positive-map refinement and changing scope. Old initials are not governing final claims when explicitly corrected by later proofs.

- [Final targeted priority/obstruction screen](principal/FINAL_PRIORITY_SCREEN.md).

## Sources

Sources are cached under sources/ and each researcher's sources/ directory. Initial/current repository packets, all 17 refreshed original science files, primary arXiv HTML, exact Zenodo API records, source manifests and bounded discovery queries are retained. The source revision refreshed at intake was d490a9d4429a8152902cebb32fd67c1e4c9285b2; its science hashes matched the earlier pinned originals.

[Primary import/novelty audit](machinery/thermal_import_audit.md), [machinery challenge](challenges/machinery_thermal_processing.md), and the source manifests distinguish read theorems, applicability proofs, metadata-only screening and unread or failed retrievals. A metadata/title hit is not a cleared proof or priority result.

## Supporting checks

Run from the workspace root, using the paths below:

```
uv run --with numpy python work/protected-quantum-processing-20261107/checks/check_filtered_normal_form.py
uv run --with numpy python work/protected-quantum-processing-20261107/constructor/check_admission.py
uv run --with numpy python work/protected-quantum-processing-20261107/constructor/check_thermal_service.py
uv run --with numpy python work/protected-quantum-processing-20261107/auditor/checks/check_interfaces.py
uv run python work/protected-quantum-processing-20261107/machinery/check_machinery_bounds.py
```

These check exact/finite algebra and illustrative inequalities. They do not simulate the full device, prove asymptotic thresholds, validate microscopic baths or establish first priority. Final validation records actual hashes and results, rather than relying on historical checks.

## Non-transferable scopes

The new DATA Hamiltonian/engineered GKSL reservoir, old powered native controller, old three-body unary-clock model and exact-H Gibbs consumer remain separate. The new service does not prove universal native gates, finite-bandwidth bath realization, 3D small-body hardware, noisy bare-port accuracy or matched practical advantage. The restricted encoded-port model explicitly pays isolated stochastic active staging and retains its source computational scheme's classical primitives.
