#!/usr/bin/env python3
"""Finite checks for the independent audit, not proofs of asymptotic claims."""
import itertools
import json
import math
from pathlib import Path

import numpy as np

I = np.eye(2, dtype=complex)
X = np.array([[0, 1], [1, 0]], dtype=complex)
Z = np.diag([1, -1]).astype(complex)


def td(a, b):
    return np.linalg.svd(a - b, compute_uv=False).sum() / 2


phi = np.array([1, 0, 0, 1], dtype=complex) / math.sqrt(2)
bell = np.outer(phi, phi.conj())
omega_equal = np.diag([0.5, 0, 0, 0.5])
omega_unequal = np.diag([0, 0.5, 0.5, 0])
p_equal = np.diag([1, 0, 0, 1])
# At t=pi/(2g): identity on unequal gauge/bath, -i X on equal.
unitary = np.kron(I, np.eye(4) - p_equal) - 1j * np.kron(X, p_equal)


def logical_hold(rho, resource):
    out = unitary @ np.kron(rho, resource) @ unitary.conj().T
    return np.einsum("aibi->ab", out.reshape(2, 4, 2, 4))


rho = np.array([[0.3, 0.2j], [-0.2j, 0.7]])
assert np.linalg.norm(logical_hold(rho, omega_equal) - X @ rho @ X) < 1e-12
assert np.linalg.norm(logical_hold(rho, omega_unequal) - rho) < 1e-12
assert np.linalg.norm(np.kron(X, I) @ omega_equal @ np.kron(X, I) - omega_unequal) < 1e-12

results = {
    "hidden_bath_same_marginals": True,
    "hidden_bath_identity_vs_flip": True,
    "checks_are_not_proofs": True,
    "choi_counterexamples": [],
    "input_error_floors": [],
    "moment_identity": [],
}

for d in (2, 4, 16, 256):
    overlap = (d - 2) / d
    distance = math.sqrt(1 - overlap**2)
    formula = 2 * math.sqrt(d - 1) / d
    assert abs(distance - formula) < 1e-12
    results["choi_counterexamples"].append({"dimension": d, "choi_half_trace": formula, "channel_half_diamond": 1})

for k in (1, 2, 8, 64):
    p = 0.01
    results["input_error_floors"].append({"bare_inputs": k, "p": p, "half_diamond_floor": 1 - (1 - p)**k})

for m in (1, 4, 8):
    q, theta = 0.02, 1.3
    brute = sum(
        q**sum(bits) * (1-q)**(m-sum(bits)) * math.exp(theta*sum(bits))
        for bits in itertools.product((0, 1), repeat=m)
    )
    formula = (1 + q * (math.exp(theta)-1))**m
    assert abs(brute - formula) < 1e-11
    results["moment_identity"].append({"sites": m, "brute": brute, "formula": formula})

out = Path(__file__).with_name("INTERFACE_CHECKS.json")
out.write_text(json.dumps(results, indent=2) + "\n")
print(json.dumps({"status": "PASS", "output": str(out), "groups": 5}))
