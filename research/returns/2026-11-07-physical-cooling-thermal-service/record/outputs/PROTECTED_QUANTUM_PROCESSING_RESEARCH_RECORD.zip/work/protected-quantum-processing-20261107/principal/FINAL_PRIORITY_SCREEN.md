# Final targeted priority and obstruction screen

7 November 2026. This screen followed the formal construction; it does not modify the frozen theorem or reviews. Main-result firstness remains UNKNOWN.

Queries: exact kernel-cosheaf/Clifford terms; sheaf/thermal/quantum-code combinations; homological-perturbation/quantum-code terms; Gibbs/non-Clifford memory. These yielded no independently verified duplicate of the complete service, but were not exhaustive. Primary source files are pinned in ../sources/FINAL_PRIORITY_SCREEN_PINS.json.

## Closely related magic-fountain machinery

Zhu--Tan--Kobayashi--Hsin, *Sipser-Spielman meets Dijkgraaf-Witten: non-Abelian qLDPC codes via twisted sheaf gauge theory and almost-constant-overhead magic state fountain*, arXiv:2609.31541v2 (5 October2026). Its primary abstract and contents already present gauging measurements of logical symmetries and magic-fountain protocols (Sections X--XI). These are a mandatory baseline for any future proposal to extract non-Clifford resources from gauged sheaf codes. I have not audited this entire long paper or established that its protocol has the current noisy thermal basin/resource contract. It is not cleared as a priority competitor for every possible generalization.

The separate NLTM connection in HPL_IMPORT_AND_CONNECTIONS.md therefore should not be described as discovering magic extraction from non-Abelian codes. The missing prospective capability is an efficient noisy THERMAL acquisition/extraction service with all resource costs, beyond the existing algebraic gauging/fountain protocols.

## Clifford-only noisy-memory obstruction

Nelson--Rajakumar--Gullans, *Non-Clifford Gates are Required for Long-Term Memory*, arXiv:2510.08451v1 (9 October2025), statement1.1. Under constant-strength independent depolarization after every layer, any circuit containing only Clifford gates and arbitrary resets loses distinguishability of every input pair after depth O(gamma^(-1)log n log(n/epsilon)). Intermediate noiseless classical resources are excluded; the primary introduction explicitly explains that noisy majority/feedforward can require non-Clifford operations.

This is not a contradiction to the present theorem. The continuous Hamiltonian and conditional energy-resolved cooling are not the restricted Clifford-unitary/reset-only circuit primitive, and the paid CFG gateways retain their own classical assumptions. Coherent local truth-table decoding uses general finite reversible operations, not an asserted Clifford-only autonomous correction. The obstruction is a reason to account for nonlinear control/cooling resources, not to relabel them free stabilizer hardware.

No theorem from this screen is used as an unverified black-box input to A--E. It narrows novelty/physical claims and preserves a specific still-unread priority boundary for a future manuscript campaign.
