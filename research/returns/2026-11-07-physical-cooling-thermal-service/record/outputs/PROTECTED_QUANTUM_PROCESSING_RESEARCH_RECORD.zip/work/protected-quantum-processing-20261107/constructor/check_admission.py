"""Finite algebra checks for constructor's support-moment admission lemma.
These are not an audit of the native controller or a threshold demonstration.
"""
from pathlib import Path
import itertools,json,math
import numpy as np

I=np.eye(2,dtype=complex)
X=np.array([[0,1],[1,0]],complex)
Y=np.array([[0,-1j],[1j,0]],complex)
Z=np.diag([1,-1]).astype(complex)

def kron_all(xs):
    out=np.ones((1,1),complex)
    for x in xs: out=np.kron(out,x)
    return out

def one(P,i,n=7):
    xs=[I]*n;xs[i]=P;return kron_all(xs)

# Steane code from the row span of the 3x7 Hamming parity-check matrix.
H=np.array([[(j>>i)&1 for j in range(1,8)] for i in range(3)],int)
v0=np.zeros(128,complex)
for a in itertools.product([0,1],repeat=3):
    bits=(np.array(a)@H)%2
    idx=sum(int(x)<<(6-i) for i,x in enumerate(bits))
    v0[idx]=1/math.sqrt(8)
v1=kron_all([X]*7)@v0
V=np.column_stack([v0,v1])
errs=[np.eye(128,dtype=complex)]
for P in [X,Y,Z]:
    errs += [one(P,i) for i in range(7)]
W=np.column_stack([E@V for E in errs])
orth=np.linalg.norm(W.conj().T@W-np.eye(44))
assert orth<1e-12

# Output order is (physical S, reference R), then (syndrome, logical, reference).
phi=np.array([1,0,0,1],complex)/math.sqrt(2)
encphi=np.kron(V,I)@phi
rho0=np.outer(encphi,encphi.conj())
Wref=np.kron(W,I)
Pphys=W@W.conj().T
Pref=np.kron(Pphys,I)

stabs=[]
for row in H:
    for Q in [X,Z]:
        stabs.append(kron_all([Q if x else I for x in row]))
Eraw=sum((np.eye(128)-S)/2 for S in stabs)
evals,evecs=np.linalg.eigh(Eraw)
moment_op=(evecs*np.exp(.2*evals))@evecs.conj().T

def trnorm(A):
    return float(np.linalg.svd(A,compute_uv=False).sum())

cases=[]
for angle in [.002,.01,.03]:
    axes=[X,Y,Z,X,Y,Z,X]
    U=kron_all([math.cos(angle)*I-1j*math.sin(angle)*P for P in axes])
    out=np.kron(U,I)@encphi
    rho=np.outer(out,out.conj())
    low=rho0.copy()
    for i,Q in enumerate(axes):
        A=np.kron(one(Q,i),I)
        low += -1j*angle*(A@rho0-rho0@A)
    low_can=Wref.conj().T@low@Wref
    low4=low_can.reshape(22,2,2,22,2,2)
    # Partial trace output logical and input reference obtains syndrome state.
    siglow=np.einsum("aijbij->ab",low4)
    expected=np.einsum("ab,ij->aibj",siglow,np.outer(phi,phi.conj())).reshape(88,88)
    neutral_res=trnorm(low_can-expected)
    assert neutral_res<1e-11

    rhoP=Pref@rho@Pref
    can=Wref.conj().T@rhoP@Wref
    can4=can.reshape(22,2,2,22,2,2)
    sig=np.einsum("aijbij->ab",can4)
    success=float(np.trace(sig).real)
    eigmin=float(np.linalg.eigvalsh(sig).min())
    surrogate_can=np.einsum("ab,ij->aibj",sig/success,np.outer(phi,phi.conj())).reshape(88,88)
    surrogate=Wref@surrogate_can@Wref.conj().T
    surrogate_tni=surrogate*success
    # ||sum of local commutator generators||_diamond <= 2n|angle|.
    mu=14*angle
    delta=math.exp(mu)-1-mu
    tail_actual=trnorm(rho-low)
    physical_surrogate=trnorm(rho-surrogate)
    physical_surrogate_tni=trnorm(rho-surrogate_tni)
    assert tail_actual<=delta+1e-12
    assert physical_surrogate<=2*math.sqrt(delta)+4*delta+1e-12
    assert physical_surrogate_tni<=2*delta+1e-12
    assert physical_surrogate<=3*delta+1e-12
    assert 1-success<=delta+1e-12
    assert eigmin>=-1e-12
    avg=U@V@V.conj().T@U.conj().T/2
    moment=float(np.trace(moment_op@avg).real)
    bound=math.exp(mu*math.exp(.2*6))
    assert moment<=bound+1e-12
    cases.append(dict(angle=angle,neutral_residual=neutral_res,
                      actual_tail_trace_norm=tail_actual,series_bound=delta,
                      projection_failure=1-success,surrogate_trace_norm=physical_surrogate,
                      tni_surrogate_trace_norm=physical_surrogate_tni,
                      gauge_min_eigenvalue=eigmin,actual_energy_moment=moment,
                      weighted_series_moment_bound=bound))

# Every independent Bernoulli set saturates the elementary generating function.
mgf=[]
for n,p,z in [(8,.01,2),(12,.08,1.5),(16,.02,4)]:
    direct=sum(math.comb(n,k)*(p*z)**k*(1-p)**(n-k) for k in range(n+1))
    claimed=(1+p*(z-1))**n
    assert abs(direct-claimed)<1e-12
    mgf.append(dict(n=n,p=p,z=z,residual=abs(direct-claimed)))

result={"steane_error_isometry_residual":orth,
        "coherent_admission_cases":cases,"bernoulli_mgf_checks":mgf,
        "scope":"Finite Steane-code and generating-function algebra only. Not native-controller verification or physical threshold."}
outpath=Path(__file__).with_name("admission_checks.json")
outpath.write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))

