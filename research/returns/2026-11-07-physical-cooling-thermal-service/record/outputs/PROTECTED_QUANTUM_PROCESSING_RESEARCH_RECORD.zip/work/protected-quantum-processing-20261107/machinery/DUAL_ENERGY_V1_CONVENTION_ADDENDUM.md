# Convention addendum to frozen dual-energy v1

7 November 2026. The frozen file and its SHA-256 remain unchanged.

Use Li--Li--Han--Liu Definition 2.1/equation (2.7): for the cochain complex, delta^k is the physical H_Z and delta^{k-1}^T is H_X. GJ Proposition 8.1.1 labels these oppositely. Its parameter and local filling conclusions are invariant under a global Hadamard swap, but the physical UF/UK and Li DATA-gate conventions in this construction use Li's orientation.

The original memory ancillas A_original are the horizontal normal-form contractible-pair states AFTER pulling them back through H_all. With precisely that assignment, C=(pure CSS linear Clifford) H_all maps complete original S_X to complete target S_Z, and complete original S_Z to target S_X. Thus UK=0 imposes all original X stabilizers, UF=0 all original Z stabilizers, and the common ground is exactly original Li DATA code plus those product ancillas.

The hostile auditor independently checked the triangular normal-form proof and reported no remaining algebraic blocker at this scope. That focused audit does not certify the complete thermal/gate/noise composition, numerical thresholds, geometry, firstness or a device.
