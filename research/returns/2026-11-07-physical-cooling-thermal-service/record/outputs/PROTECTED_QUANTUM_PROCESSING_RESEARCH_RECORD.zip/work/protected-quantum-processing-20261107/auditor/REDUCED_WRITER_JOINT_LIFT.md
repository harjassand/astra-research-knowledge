# Post-freeze constructive refinement: a reduced writer can suffice for a bath-uniform native memory

7 November 2026. This is a new derivation after the independent initial report was frozen, and before receiving mathematical conclusions from peers. It refines the initial report's sufficient joint-instrument requirement. It does not alter the frozen report or its passive-bath counterexample.

## 1. Exact theorem

All spaces in the statement are finite-dimensional. An extension to normal infinite-dimensional bath channels requires the corresponding normal Stinespring continuity/representation argument and is not silently asserted here. Let L be the logical input, S the physical native memory, B the actual retained bath after writing. Let

`A: L -> S B`

be the actual joint CPTP writer, and `A_S=Tr_B A`. Suppose a positive CPTP reference writer

`W: L -> S`

has the following properties:

1. In the specified full native decoding frame `D:S -> L G`, `D W(rho) D^*=rho_L tensor tau_G` for a fixed normalized tau_G, including on arbitrary references.
2. Its gauge support lies in the admitted native basin P, and its system-only proof moment satisfies `Tr[F W(rho)]<=exp(nu_w N+O(1))` with the fixed extensive warm gap of N1388.
3. The physical HOLD theorem is uniform over **all** fixed logical-independent gauge–bath states extending tau_G, under the same actual joint interval-CPTP evolution and its admitted pointwise joint cb-norm noise budget.
4. `d_diamond(A_S,W)<=epsilon`, in half-diamond convention.

**Theorem D (PROVED using an established continuity theorem).** There exists a CPTP joint extension `W_tilde:L -> S B` of W such that

`d_diamond(A,W_tilde)<=sqrt(2 epsilon)`.

In the native decoding frame it factors exactly as

`D W_tilde(rho) D^*=rho_L tensor tau_(G B)`

for a fixed logical-independent tau_GB whose G marginal is tau_G. Consequently the actual native HOLD and specified decoder obey

`d_diamond(Dec o HOLD_T o A,id_L) <= sqrt(2epsilon)+C N T exp(-bN)`

at the accepted warm hypotheses, with no bath replacement or fresh-bath assumption. The same actual bath and future joint propagator are retained in the comparison. The bound can be capped at one.

The theorem is dimension-independent. It covers k growing logical qubits if its reduced diamond hypothesis and exact logical subsystem structure are actually established. It does not remove the bare-input noise floor: epsilon will retain that floor if W is intended to represent a perfect writer from bare inputs.

## 2. Proof and exact primary-source import

The primary import is Kretschmann–Schlingemann–Werner, *A Continuity Theorem for Stinespring's Dilation*, arXiv:0710.2495v1 (12 October 2007), **Theorem 1**, particularly inequalities (6) and (7), [primary HTML](https://arxiv.org/html/0710.2495v1#S2). The theorem applies to two completely positive maps from a C*-algebra into B(H), at least one nonzero, and supplies a common representation with Stinespring operators differing in operator norm by at most the square root of the cb-norm difference. Here we apply it to the Heisenberg duals of the finite-dimensional CPTP channels A_S and W; their cb-norm distance equals their Schrödinger diamond distance, at most 2epsilon. No energy-constrained norm, one-state trace estimate or unverified small-environment strengthening is used.

Thus choose common Stinespring isometries V_A,V_W with `||V_A-V_W||<=sqrt(2epsilon)`. We may retain the actual extension A on B: enlarge only the otherwise discarded dilation environment and use Stinespring uniqueness to transport the common dilation so V_A realizes the specified A after tracing that discarded environment. The environment can be enlarged arbitrarily; this does not claim that a prescribed small ancilla suffices. Use the same transported V_W and trace the same discarded environment to obtain W_tilde on S B. Its S marginal is exactly W. For isometries V_1,V_2, complete trace-norm duality and the triangle inequality give

`||Ad_(V_1)-Ad_(V_2)||_diamond <=2||V_1-V_2||`.

Partial trace contracts this norm. Dividing by two proves the stated joint half-diamond bound.

The logical identity factorization of the extension is exact. A minimal Stinespring isometry for the decoded channel `rho -> rho_L tensor tau_G` has the form `|psi> -> |psi>_L tensor |pur(tau)>_(G E)`. Every joint extension arises by a channel on its complementary E system. Therefore its full L G B output is `rho_L tensor tau_GB`. This is the elementary no-information-without-disturbance property of the identity channel, and it also proves reference uniformity.

Because F and P act on S alone, W_tilde inherits their support and moment unchanged. Hypothesis 3 makes the accepted native theorem apply to that particular fixed tau_GB. Apply it to W_tilde, compare with A through the same actual HOLD and decoder by CPTP contraction, and use the triangle inequality. QED.

## 3. How this strengthens the sparse-fault admission theorem

Theorem B of the frozen report can first be applied entirely on the **reduced physical system** S: a positive sparse-fault output channel from ideal encoded/native-ready input gives a positive warm channel W after excluding its exponentially rare large-support branches. If a reduced writer is delta-close to that residual-noise output, it is `epsilon<=delta+epsilon_adm` close to the normalized positive warm writer. Theorem D then turns this into a valid initial condition for the native theorem even when the actual writer left a correlated bath behind:

`error <= sqrt(2(delta+epsilon_adm)) + C N T exp(-bN)`.

The loss halves an exponential admission exponent, rather than destroying the threshold. No claim is made that the sparse errors have a joint physical flag decomposition on the actual bath. That stronger contract from the initial report is sufficient, but it is not necessary when the future theorem is uniformly valid over arbitrary logical-independent gauge–bath resources.

This creates an actionable route from existing reduced-channel FT I/O theorems to native long HOLD. Their own circuit-noise assumptions must still describe the actual writer, including idle locations and controls. A memory theorem allowing broad correlated HOLD faults does not automatically extend an imported writer threshold to arbitrary correlated WRITE faults. Theorem D closes the *handoff correlation* gap once the reduced writer estimate is earned; it does not earn that writer estimate under an inapplicable model.

## 4. What this does not do

The result does not repair the passive unary route merely by choosing some joint extension. That route's theorem is tied to the actual Gibbs gauge–bath resource, not to all extensions with the same S marginal. The counterexample in the frozen report remains valid for that weaker future contract.

Nor does this provide protected operations, physical extraction, implementation of the native grouped-site controller, microscopic reservoir engineering, or a favorable full-resource comparison. It is a synthesis of standard continuity/error-correction machinery with a strong earned native warm theorem, not a new passive protection mechanism or a historical-priority claim.
