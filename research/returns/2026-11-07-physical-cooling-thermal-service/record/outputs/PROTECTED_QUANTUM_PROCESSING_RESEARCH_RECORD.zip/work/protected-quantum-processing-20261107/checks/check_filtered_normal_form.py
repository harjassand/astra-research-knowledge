"""Exact GF(2) checks of the filtered perturbation basis; not a family proof."""
import json
from pathlib import Path
import numpy as np

def mul(a,b): return (a@b)%2

def inverse(a):
    n=len(a);v=np.concatenate([a.copy(),np.eye(n,dtype=np.int64)],axis=1)
    for j in range(n):
        p=next(i for i in range(j,n) if v[i,j]);v[[j,p]]=v[[p,j]]
        for i in range(n):
            if i!=j and v[i,j]:v[i]^=v[j]
    assert np.array_equal(v[:,:n],np.eye(n,dtype=np.int64))
    return v[:,n:]

def case(seed,t=4):
    rng=np.random.default_rng(seed)
    names=[('H0',0,0),('H1',1,1),('H2',2,3)]
    pairs=[]
    for p in range(1,t+1):
        for degree in range(1,p+1):
            a=len(names);names.append(('a',degree,p))
            b=len(names);names.append(('b',degree-1,p));pairs.append((a,b))
    n=len(names);eye=np.eye(n,dtype=np.int64)
    d0=np.zeros((n,n),dtype=np.int64);h=np.zeros_like(d0)
    for a,b in pairs:d0[b,a]=1;h[a,b]=1
    dh=np.zeros_like(d0);dh[0,1]=1
    deg=np.array([x[1] for x in names]);lev=np.array([x[2] for x in names])
    q=np.zeros_like(d0)
    for i in range(n):
        for j in range(3,n):
            if deg[i]==deg[j] and lev[i]<lev[j]:q[i,j]=rng.integers(2)
    s=(eye+q)%2;d=mul(s,mul((d0+dh)%2,inverse(s)));delta=(d+d0)%2
    assert not mul(d,d).any()
    r,c=np.nonzero(delta)
    assert all(lev[i]<lev[j] for i,j in zip(r,c))
    inc=eye[:,:3];proj=eye[:3,:]
    assert not mul((eye+mul(inc,proj))%2,mul(delta,inc)).any()
    hp=mul(inverse((eye+mul(h,delta))%2),h)
    pp=mul(proj,inverse((eye+mul(delta,h))%2))
    assert np.array_equal((mul(d,hp)+mul(hp,d))%2,(eye+mul(inc,pp))%2)
    basis=eye.copy()
    for a,b in pairs:
        basis[:,a]=mul(hp,d0[:,a]);basis[:,b]=mul(d,basis[:,a])
    reverse=inverse(basis)
    assert np.array_equal(mul(d,basis),mul(basis,(d0+dh)%2))
    corr=(basis+eye)%2;r,c=np.nonzero(corr)
    assert all(lev[i]<lev[j] for i,j in zip(r,c))
    power=eye.copy()
    for _ in range(t+1):power=mul(power,corr)
    assert not power.any()
    assert np.array_equal(mul(basis,reverse),eye)
    assert not mul(hp,hp).any();assert not mul(pp,hp).any()
    assert np.array_equal(mul(pp,inc),np.eye(3,dtype=np.int64))
    return dict(seed=seed,filtration_height=t,coordinates=n,all_exact_identities_pass=True)

if __name__=='__main__':
    result=dict(status='PASS',arithmetic='exact GF(2)',cases=[case(k,t) for t in [3,4,5,6] for k in range(25)],limitations='Finite algebra checks supplement the filtration proof; they do not establish code expansion, asymptotic locality, lifetime or novelty.')
    Path(__file__).with_name('FILTERED_NORMAL_FORM_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(status=result['status'],cases=len(result['cases']),arithmetic=result['arithmetic'])))
