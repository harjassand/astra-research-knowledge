"""Small exact checks of auxiliary inequalities; not a memory simulation or proof."""
from fractions import Fraction as Q
from math import exp
from pathlib import Path
import hashlib,json
base=Path(__file__).resolve().parents[1]
pins=json.loads((base/'sources/INITIAL_PINS.json').read_text())
checks={}
for f in pins['files']:
 got=hashlib.sha256((base/'sources'/f['name']).read_bytes()).hexdigest()
 assert got==f['sha256'],f['name']
checks['pinned_files_sha256']='PASS'
# Local-stochastic support mgf, for three correlated families and iid support.
mgfs=[]
for n in range(1,9):
 p=0.03; theta=0.8; bound=(1+p*(exp(theta)-1))**n
 iid=sum((p**(m.bit_count()))*((1-p)**(n-m.bit_count()))*exp(theta*m.bit_count()) for m in range(1<<n))
 full=1-p**n+p**n*exp(theta*n)
 singleton=1-n*p+n*p*exp(theta)
 assert abs(iid-bound)<1e-10
 assert full<=bound+1e-10 and singleton<=bound+1e-10
 mgfs.append({'n':n,'bound':bound,'iid':iid,'all_or_nothing':full,'singletons':singleton})
checks['support_mgf_finite_cases']=mgfs
# Reversible five-state chain with an exponentially small stationary bottleneck,
# yet a fast initially decodable exceptional A-state.
eps=Q(1,10000)
pi=[(1-3*eps)/2,eps,eps,eps,(1-3*eps)/2]
P=[[Q(0) for j in range(5)] for i in range(5)]
for i,j in [(0,1),(1,2),(2,3),(3,4)]:
 P[i][j]=min(Q(1),pi[j]/pi[i])/3
 P[j][i]=min(Q(1),pi[i]/pi[j])/3
for i in range(5):P[i][i]=1-sum(P[i])
assert sum(pi)==1 and all(sum(row)==1 for row in P)
assert all(pi[i]*P[i][j]==pi[j]*P[j][i] for i in range(5) for j in range(5))
def step(v):return [sum(v[i]*P[i][j] for i in range(5)) for j in range(5)]
v=[Q(0),Q(1),Q(0),Q(0),Q(0)]
for t in range(3):v=step(v)
assert v[4]==Q(1,27)
checks['bottleneck_counterexample']={'stationary_bottleneck_ratio':str((pi[2]+pi[3])/(pi[0]+pi[1])),'fast_A_to_C_in_3_steps':str(v[4]),'rate_upper_bound':str(max(max(row) for row in P)),'detailed_balance':'PASS','fixed_energy_locality_caveat':'This parameterized qudit example is not a bounded-strength lattice Hamiltonian construction.'}
# Bell diagonal depolarization: entanglement fidelity is 1-3p/4, three other
# Bell weights p/4, so half trace distance is exactly 3p/4.
p=Q(1,100)
weights=[1-3*p/4,p/4,p/4,p/4]
distance=(abs(weights[0]-1)+sum(weights[1:]))/2
assert sum(weights)==1 and distance==3*p/4
checks['bare_input_depolarizing_floor']={'p':str(p),'half_trace_distance_on_Bell_input':str(distance),'ratio_to_p':str(distance/p)}
(base/'machinery/CHECK_RESULTS.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({k:('PASS' if k!='bottleneck_counterexample' else v) for k,v in checks.items()},indent=2))
