from pathlib import Path
from html.parser import HTMLParser
import hashlib,json,shutil
class Parser(HTMLParser):
 def __init__(self):
  super().__init__(convert_charrefs=True); self.parts=[]; self.mathdepth=0; self.skip=0; self.article=False
 def handle_starttag(self,t,a):
  a=dict(a)
  if t=='article':self.article=True
  if not self.article:return
  if t in ['script','style','nav']:self.skip+=1
  if self.skip:return
  if t=='math':
   if not self.mathdepth:self.parts.append(' $'+a.get('alttext','')+'$ ')
   self.mathdepth+=1; return
  if self.mathdepth:self.mathdepth+=1;return
  if t in ['p','div','section','li','table','tr','h1','h2','h3','h4','h5','h6','figcaption','br']:self.parts.append('\n')
 def handle_endtag(self,t):
  if not self.article:return
  if self.skip:
   if t in ['script','style','nav']:self.skip-=1
   return
  if self.mathdepth:self.mathdepth-=1;return
  if t in ['p','div','section','li','table','tr','h1','h2','h3','h4','h5','h6','figcaption','br']:self.parts.append('\n')
  if t=='article':self.article=False
 def handle_data(self,s):
  if self.article and not self.mathdepth and not self.skip:self.parts.append(s)
base=Path(__file__).resolve().parent
src=Path('/Users/harjas/Documents/ChatGPT/coordination/work/astra-publication-queue-20261106/alternative-family-prior-sources-20261107')
dst=base/'sources'; manifest=[]
for aid in ['2605.10943v1','2601.20818v3','2609.39965v3','2412.09598v2','2510.14160v2']:
 p=src/('arxiv-'+aid+'.html'); q=dst/p.name;shutil.copyfile(p,q)
 parser=Parser(); parser.feed(q.read_text())
 text='\n'.join(' '.join(s.split()) for s in ''.join(parser.parts).splitlines() if s.strip())
 (dst/('arxiv-'+aid+'.txt')).write_text(text+'\n')
 manifest.append({'url':'https://arxiv.org/html/'+aid,'source_cache':str(p),'copy_sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'text_lines':text.count('\n')+1})
 print(aid,len(text),text[:250])
(dst/'CACHE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
