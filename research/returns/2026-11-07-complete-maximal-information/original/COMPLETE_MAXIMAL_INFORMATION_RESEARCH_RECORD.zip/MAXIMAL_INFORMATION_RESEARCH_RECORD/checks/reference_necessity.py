"""Rational EB channels agree on every unreferenced maximal profile but differ completely.
Analytic transpose argument + exact noncommutative path probe; not a sampling proof.
"""
import sympy as s,json
from pathlib import Path
I=s.I;a=4;r=4;t=s.Rational(1,16)
X=s.Matrix([[0,1],[1,0]]);Y=s.Matrix([[0,-I],[I,0]]);Z=s.diag(1,-1)
signs=[(1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)]
states=[s.eye(2)/2+(sx*X+sy*Y+sz*Z)/8 for sx,sy,sz in signs]
assert sum(states,s.zeros(2))==2*s.eye(2)
for q in states:assert q.det()==s.Rational(13,64)
Hs=[s.diag(*[v[i] for v in signs]) for i in range(3)]
edges=[]
for i in range(3):
 A=s.zeros(r);A[i,i+1]=A[i+1,i]=1;edges.append(A)
rho=(s.eye(a*r)-t*sum((s.kronecker_product(H,A) for H,A in zip(Hs,edges)),s.zeros(a*r)))/(a*r)
e0=s.eye(r)[:,0];en=s.eye(r)[:,3];P=(e0+I*en)*(e0+I*en).H/2
J=s.kronecker_product(s.eye(a),P);H=J-a*rho;assert s.trace(H)==0
apply=lambda A,states:sum((s.kronecker_product(q,A[i*r:(i+1)*r,i*r:(i+1)*r]) for i,q in enumerate(states)),s.zeros(2*r))
vals=[]
for ss in [states,[q.T for q in states]]:
 R=apply(rho,ss);B=apply(H,ss);vals.append(s.simplify(s.trace(B*R.inv()*B)))
assert vals[0]!=vals[1]
Ts=[sum((q*Hs[j][i,i]/2 for i,q in enumerate(states)),s.zeros(2)) for j in range(3)]
assert Ts==[X/4,Y/4,Z/4]
m=s.trace(Ts[0]*Ts[1]*Ts[2])/2;assert m==I/64
result={'description':'two full-Choi-rank rational entanglement-breaking 4-to-2 channels related by output transposition','choi_floor_lower_bound':'13/64 (each trace-one 2x2 output block has det13/64)','normalized_generators':['Pauli_X/4','Pauli_Y/4','Pauli_Z/4'],'ordered_xyz_moment':str(m),'transposed_ordered_moment':str(-m),'all_unreferenced_profiles_equal_by_analytic_transposition':True,'reference_dimension':r,'path_parameter':str(t),'rld_values':[str(x) for x in vals],'exact_complete_rld_difference':str(vals[0]-vals[1]),'traceless_tangent_verified':True}
Path('work/maximal-information/checks/reference_necessity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
