import sympy as s
import json
from pathlib import Path
I=s.I;a=2;r=3
K0=s.diag(1,s.Rational(3,5));K1=s.Matrix([[0,s.Rational(4,5)],[0,0]])
X=s.Matrix([[0,1],[1,0]]);Y=s.Matrix([[0,-I],[I,0]])
def E(A):return K0*A*K0.H+K1*A*K1.H
Omega=E(s.eye(2));Ominv=s.diag(5/s.sqrt(41),s.Rational(5,3))
T=lambda A:s.simplify(Ominv*E(A)*Ominv)
tau=lambda A:s.simplify(s.trace(Omega*A)/a)
moment=tau(T(X)*T(Y));assert moment==16*I/41
edges=[]
for j in range(2):
 A=s.zeros(r);A[j,j+1]=1;A[j+1,j]=1;edges.append(A)
Z=[s.kronecker_product(T(X),edges[0]),s.kronecker_product(T(Y),edges[1])]
coeff=Z[0]*Z[1]+Z[1]*Z[0]
M=s.zeros(r)
for j in range(r):
 for k in range(r): M[j,k]=s.simplify(sum(Omega[u,u]*coeff[u*r+j,u*r+k] for u in range(a))/a)
assert M[0,2]==moment and M[2,0]==s.conjugate(moment)
e0=s.eye(r)[:,0];e2=s.eye(r)[:,2];P=(e0+I*e2)*(e0+I*e2).H/2
assert s.trace(P*M)!=0
z=[s.Rational(1,10),-s.Rational(1,12)]
rho=(s.eye(a*r)-z[0]*s.kronecker_product(X,edges[0])-z[1]*s.kronecker_product(Y,edges[1]))/(a*r)
assert s.trace(rho)==1
J=s.kronecker_product(s.eye(a),P);H=J-a*rho;assert s.trace(H)==0
kraus=[s.kronecker_product(k,s.eye(r)) for k in [K0,K1]]
ER=lambda A:sum((k*A*k.H for k in kraus),s.zeros(a*r))
R=ER(rho);B=ER(J);BH=ER(H)
graw=s.simplify(s.trace(B*R.inv()*B));gshift=s.simplify(s.trace(BH*R.inv()*BH));assert graw-gshift==a*a
Q=s.eye(a*r)-z[0]*Z[0]-z[1]*Z[1];Qi=Q.inv();Rq=s.zeros(r)
for j in range(r):
 for k in range(r): Rq[j,k]=s.simplify(sum(Omega[u,u]*Qi[u*r+j,u*r+k] for u in range(a))/a)
assert s.simplify(graw-a*a*r*s.trace(P*Rq))==0
for n in range(1,a*r+1): assert rho[:n,:n].det()>0
result={'model':'rational amplitude-damping qubit channel with nontracial normalized-output state','ordered_xy_moment':str(moment),'complex_path_coefficient_verified':True,'imaginary_reference_test_detects_coefficient':str(s.trace(P*M)),'trace_restoration_shift':str(graw-gshift),'rld_raw':str(graw),'rld_traceless':str(gshift),'baseline_strictly_positive_exact':True,'rld_resolvent_scaling_verified':True,'source_fixture_certificate_replayed':False}
Path('work/maximal-information/checks/path_reference_exact.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
