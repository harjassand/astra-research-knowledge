import sympy as s,json
from pathlib import Path
I=s.I;a=2;r=4;eta=s.Rational(1,4);t=s.Rational(1,16)
X=s.Matrix([[0,1],[1,0]]);Y=s.Matrix([[0,-I],[I,0]]);Z=s.diag(1,-1)
E=lambda A:eta*A+(1-eta)*s.trace(A)*s.eye(2)/2
F=lambda A:E(A).T
choi=lambda C:s.BlockMatrix([[C(s.eye(2)[:,i]*s.eye(2)[j,:]) for j in range(2)] for i in range(2)]).as_explicit()
JE=choi(E);JF=choi(F)
assert JE.eigenvals()=={s.Rational(7,8):1,s.Rational(3,8):3}
assert JF.eigenvals()=={s.Rational(1,8):1,s.Rational(5,8):3}
edges=[]
for i in range(3):
 A=s.zeros(r);A[i,i+1]=A[i+1,i]=1;edges.append(A)
rho=(s.eye(a*r)-t*sum((s.kronecker_product(H,A) for H,A in zip([X,Y,Z],edges)),s.zeros(a*r)))/(a*r)
e0=s.eye(r)[:,0];en=s.eye(r)[:,3];P=(e0+I*en)*(e0+I*en).H/2
H=s.kronecker_product(s.eye(a),P)-a*rho;assert s.trace(H)==0
apply=lambda A,C:sum((s.kronecker_product(C(s.eye(2)[:,i]*s.eye(2)[j,:]),A[i*r:(i+1)*r,j*r:(j+1)*r]) for i in range(2) for j in range(2)),s.zeros(2*r))
vals=[]
for C in [E,F]:
 R=apply(rho,C);B=apply(H,C);vals.append(s.simplify(s.trace(B*R.inv()*B)))
assert vals[0]!=vals[1]
for n in range(1,a*r+1):assert rho[:n,:n].det()>0
result={'pair':'E(X)=X/4+3 Tr(X) I/8; F(X)=E(X)^T','input_dimension':2,'output_dimension':2,'choi_spectra_E':{str(k):v for k,v in JE.eigenvals().items()},'choi_spectra_F':{str(k):v for k,v in JF.eigenvals().items()},'common_choi_floor':'1/8','all_unreferenced_maximal_profiles_equal':'analytic transpose covariance and trace invariance','ordered_xyz_moments':['i/64','-i/64'],'reference_dimension':r,'path_parameter':str(t),'rld_values':[str(x) for x in vals],'exact_complete_rld_difference':str(vals[0]-vals[1]),'traceless_tangent':True,'baseline_positive_exact':True}
Path('work/maximal-information/checks/qubit_reference_necessity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
