"""Exact supplementary checks for the independent machinery report."""
from itertools import product
import json
from pathlib import Path
import sympy as s
Q = s.Rational
I2 = s.eye(2)
X = s.Matrix([[0, 1], [1, 0]])
Y = s.Matrix([[0, -s.I], [s.I, 0]])
Z = s.diag(1, -1)

def tr(m):
    return s.simplify(s.trace(m))

def apply_ref(preps, mat, r):
    out = s.zeros(preps[0].rows * r)
    for i in range(len(preps)):
        out += s.kronecker_product(preps[i], mat[i*r:(i+1)*r, i*r:(i+1)*r])
    return out

def moment(preps, word):
    omega = sum(preps, s.zeros(preps[0].rows))
    w = omega
    for i in word:
        w = w * omega.inv() * preps[i]
    return tr(w) / len(preps)

def physical_witness(preps, other):
    a = len(preps)
    found = None
    for n in range(1, 5):
        for word in product(range(a), repeat=n):
            delta = s.simplify(moment(preps, word) - moment(other, word))
            if delta != 0:
                found = word, delta
                break
        if found:
            break
    assert found is not None
    word, delta = found
    n, r = len(word), len(word) + 1
    d = s.re(delta) if s.re(delta) != 0 else s.im(delta)
    t = min(Q(1, 2*n), abs(d) / (8 * n**(n+1)))
    pencil = s.zeros(a*r)
    for j, i in enumerate(word):
        h, edge = s.zeros(a), s.zeros(r)
        h[i, i] = 1
        edge[j, j+1] = edge[j+1, j] = 1
        pencil += s.kronecker_product(h, edge)
    rho = (s.eye(a*r) - t*pencil)/(a*r)
    assert tr(rho) == 1
    assert all(rho[:k, :k].det() > 0 for k in range(1, a*r+1))
    e0, en = s.eye(r)[:, 0], s.eye(r)[:, n]
    projs = [e0*e0.T, en*en.T, (e0+en)*(e0+en).T/2,
             (e0+s.I*en)*(e0+s.I*en).conjugate().T/2]
    baseline_a, baseline_b = apply_ref(preps, rho, r), apply_ref(other, rho, r)
    gaps = []
    for p in projs:
        h = s.kronecker_product(s.eye(a), p) - a*rho
        assert tr(h) == 0
        ha, hb = apply_ref(preps, h, r), apply_ref(other, h, r)
        gaps.append(s.simplify(tr(ha * baseline_a.inv() * ha) - tr(hb * baseline_b.inv() * hb)))
    k = max(range(4), key=lambda k: abs(gaps[k]))
    g = gaps[k]
    assert abs(g) >= a*a*r*abs(d)*t**n/4
    h = s.kronecker_product(s.eye(a), projs[k]) - a*rho
    small = Q(1, 8*a*r)
    sigma = rho + small*h
    assert tr(sigma) == 1
    assert all(sigma[:j, :j].det() > 0 for j in range(1, a*r+1))
    def chi2(preps):
        er, es = apply_ref(preps, rho, r), apply_ref(preps, sigma, r)
        return tr((es-er)*er.inv()*(es-er))
    pair_gap = s.simplify(chi2(preps) - chi2(other))
    assert pair_gap == small**2*g
    assert abs(pair_gap) >= abs(d)*t**n/(256*r)
    return {"word": word, "moment_gap": str(delta), "path_parameter": str(t),
            "reference_dimension": r, "tangent_gaps": list(map(str, gaps)),
            "chosen_projector": k, "state_pair_chi2_gap": str(pair_gap),
            "proved_pair_gap_floor": str(abs(d)*t**n/(256*r)),
            "input_rho_floor": str(Q(1, 2*a*r)), "input_sigma_floor": str(Q(1, 4*a*r))}

def discontinuity_check():
    p, v = s.diag(1, 0), s.Matrix([Q(3, 5), Q(4, 5)])
    q = v*v.T
    rho0, rho1 = Q(3, 4)*p+Q(1, 4)*q, Q(1, 4)*p+Q(3, 4)*q
    assert rho0 == s.Matrix([[Q(21, 25), Q(3, 25)], [Q(3, 25), Q(4, 25)]])
    assert rho1 == s.Matrix([[Q(13, 25), Q(9, 25)], [Q(9, 25), Q(12, 25)]])
    assert rho0.det() == rho1.det() == Q(3, 25)
    assert set(rho0.eigenvals()) == {(5+s.sqrt(13))/10, (5-s.sqrt(13))/10}
    assert (rho0-Q(1, 8)*I2).is_positive_definite
    assert (rho1-Q(1, 8)*I2).is_positive_definite
    eps = s.symbols('eps', real=True)
    diff = (1-eps)*(rho0-rho1)+eps*Z
    assert diff == s.Matrix([[(8+17*eps)/25, -6*(1-eps)/25],
                            [-6*(1-eps)/25, -(8+17*eps)/25]])
    c0, c1 = (1-eps)*rho0+eps*s.diag(1, 0), (1-eps)*rho1+eps*s.diag(0, 1)
    diagonal_det = s.det(s.Matrix([[c0[0, 0], c1[0, 0]], [c0[1, 1], c1[1, 1]]]))
    assert s.simplify(diagonal_det-(8+17*eps)/25) == 0
    return {"base_choi_floor": "1/8", "uniform_choi_floor_eps_le_half": "1/16",
            "diagonal_superoperator_det": str(s.factor(diagonal_det)),
            "base_output_difference_trace_norm": "4/5",
            "canonical_output_difference_trace_norm": "1",
            "liminf_postprocessing_diamond_deficiency": "1/10"}

if __name__ == '__main__':
    preps = [(I2+Q(1, 2)*pauli)/2 for pauli in (X, Y, Z)]
    data = {"complex_ordered_moment_witness": physical_witness(preps, [rho.T for rho in preps]),
            "canonical_lift_discontinuity": discontinuity_check(), "status": "all_exact_checks_passed"}
    Path(__file__).with_suffix('.json').write_text(json.dumps(data, indent=2)+'\n')
    print(json.dumps(data, indent=2))
