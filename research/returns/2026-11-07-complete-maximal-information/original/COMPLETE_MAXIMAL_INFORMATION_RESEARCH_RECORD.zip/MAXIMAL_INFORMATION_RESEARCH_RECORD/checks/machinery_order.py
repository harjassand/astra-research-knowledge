"""Exact checks for complete RLD dominance without canonical processing."""
import json
from pathlib import Path
import sympy as s
Q=s.Rational
x,y,c=s.symbols('x y c', positive=True)

def coefficient(w):
    out=s.zeros(2)
    for row in w.tolist():
        v=s.Matrix(row)
        out += v*v.T/(row[0]*x+row[1]*y)
    return out

p=(1-c)/2
bsc=s.Matrix([[1-p,p],[p,1-p]])
trace=s.Matrix([[1,1]])
residual=coefficient(bsc)-coefficient(trace)
target=c*c/((x+y)*((1-p)*x+p*y)*(p*x+(1-p)*y))*s.Matrix([y,-x])*s.Matrix([[y,-x]])
assert residual.applyfunc(s.factor)==target.applyfunc(s.factor)

E=s.Matrix([[Q(3,10),Q(1,30)],[Q(2,3),Q(2,3)],[Q(1,30),Q(3,10)]])
F=s.Matrix([[Q(7,10),Q(3,10)],[Q(3,10),Q(7,10)]])
assert list(sum(E.col(i)) for i in range(2))==[1,1]
assert list(sum(F.col(i)) for i in range(2))==[1,1]
assert min(E)==Q(1,30)
assert min(F)==Q(3,10)
assert sum(abs(v) for v in E[:,0]-E[:,1])==Q(8,15)
assert sum(abs(v) for v in F[:,0]-F[:,1])==Q(4,5)
z=s.symbols('z', real=True)
alpha,ce,cf=Q(1,3),Q(4,5),Q(2,5)
num=s.factor(alpha*ce**2*(1-cf**2*z**2)-cf**2*(1-ce**2*z**2))
assert s.expand(num)==Q(4,75)+Q(128,1875)*z*z

rho0=s.Matrix([[Q(2,5),Q(1,10)+s.I/20],[Q(1,10)-s.I/20,Q(1,5)]])
rho1=s.Matrix([[Q(1,5),-s.I/30],[s.I/30,Q(1,5)]])
H0=s.Matrix([[Q(1,7),Q(1,11)+s.I/13],[Q(1,11)-s.I/13,-Q(1,5)]])
H1=s.Matrix([[Q(1,9),s.I/17],[-s.I/17,Q(1,6)]])
assert rho0.is_positive_definite and rho1.is_positive_definite
t=s.trace(H0+H1)
H0,H1=H0-t*rho0,H1-t*rho1
assert s.trace(H0+H1)==0

def reference_operator(w):
    out=s.zeros(2)
    for row in w.tolist():
        base=row[0]*rho0+row[1]*rho1
        tangent=row[0]*H0+row[1]*H1
        out += tangent*base.inv()*tangent
    return out.applyfunc(s.simplify)

D=(reference_operator(E)-reference_operator(F)).applyfunc(s.simplify)
assert D==D.conjugate().T
assert D[0,0]>0 and D.det()>0
data={"scalar_coefficient_identity":"verified",
      "comparison_numerator":str(num),"reference_operator_positive_definite":True,
      "reference_operator_eigenvalues_numeric":[float(s.re(v.evalf())) for v in D.eigenvals()],
      "E_choi_floor":"1/30","F_choi_floor":"3/10",
      "E_basis_output_distance":"8/15","F_basis_output_distance":"4/5",
      "processing_diamond_deficiency_floor":"2/15","status":"all_exact_checks_passed"}
Path(__file__).with_suffix('.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data,indent=2))
