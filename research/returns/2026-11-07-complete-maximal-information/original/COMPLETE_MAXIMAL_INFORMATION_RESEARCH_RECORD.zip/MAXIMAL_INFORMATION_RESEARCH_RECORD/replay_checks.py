#!/usr/bin/env python3
"""Replay finite supplementary certificates in an isolated temporary tree."""
import argparse, importlib.metadata, json
from pathlib import Path
import shutil, subprocess, sys, tempfile, time
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--output',type=Path)
p.add_argument('--numerical',action='store_true')
args=p.parse_args();root=Path(__file__).resolve().parent
scripts=['checks/path_reference_exact.py','checks/qubit_reference_necessity.py','checks/reference_necessity.py','checks/machinery_witness.py','checks/machinery_order.py','constructor/check_instability.py','constructor/pbt_budget.py','auditor/check_discontinuity.py']
if args.numerical:scripts.append('constructor/check_pbt_small.py')
report={'scope':'finite supplementary checks only; infinite theorems and historical priority are analytic','python':sys.version,'packages':{k:importlib.metadata.version(k) for k in ['sympy','numpy']},'checks':[]}
with tempfile.TemporaryDirectory(prefix='maximal-profile-replay-') as td:
 td=Path(td);dst=td/'work/maximal-information';dst.mkdir(parents=True)
 for dn in ['checks','constructor','auditor']:shutil.copytree(root/dn,dst/dn)
 for script in scripts:
  start=time.monotonic();r=subprocess.run([sys.executable,str(dst/script)],cwd=td,text=True,capture_output=True,timeout=180)
  report['checks'].append({'script':script,'exit_code':r.returncode,'elapsed_seconds':round(time.monotonic()-start,4),'kind':'numerical diagnostic' if 'small' in script else 'exact symbolic certificate or rational budget','stdout':r.stdout,'stderr':r.stderr})
report['status']='PASS' if all(c['exit_code']==0 for c in report['checks']) else 'FAIL'
if args.output:
 args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'checks':[{k:v for k,v in c.items() if k not in ['stdout','stderr']} for c in report['checks']]},indent=2))
sys.exit(0 if report['status']=='PASS' else 1)
