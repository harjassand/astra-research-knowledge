"""Exact checks for the independent auditor's full-Choi discontinuity example.

The mathematical proof is in ../initial/auditor.md.  SymPy is only a check.
Run with python3 from the workspace root; no tolerances enter these checks.
"""
import json
from pathlib import Path
import sympy as s

q = s.Rational
I = s.I
eps = s.symbols("eps", real=True)
P = s.Matrix([[1, 0], [0, 0]])
v = s.Matrix([q(3, 5), q(4, 5)])
Q = v * v.T
beta = q(1, 128)
alpha = 1 - 2 * beta
omega = P + Q
Z = alpha * (P - Q)
Y = s.Matrix([[0, -I], [I, 0]])
w0 = (1 - beta) * P + beta * Q
w1 = beta * P + (1 - beta) * Q
choi = w0.row_join(eps * Y / 2).col_join((eps * Y / 2).row_join(w1))

assert s.trace(w0) == s.trace(w1) == 1
assert s.trace(Y) == 0
assert w0 + w1 == omega
assert omega.det() == q(16, 25)
assert w0.det() == w1.det() == q(127, 25600)
raw_commutator = s.simplify(Z * omega.inv() * Y - Y * omega.inv() * Z)
assert raw_commutator != s.zeros(2)

# Four raw words span M_2 for every nonzero epsilon.  Congruence maps
# these words to words in the two normalized Hermitian generators.
raw_words = [omega, Z, eps * Y, Z * omega.inv() * (eps * Y)]
columns = s.Matrix.hstack(*[s.Matrix(list(w)) for w in raw_words])
word_determinant = s.factor(columns.det())
assert word_determinant != 0
assert s.factor(word_determinant / eps**2).is_number

# Uniform strict Choi positivity: omega_i >= det(omega_i) I since
# their two eigenvalues are positive and sum to one.  The offdiagonal
# perturbation has operator norm |epsilon|/2.
uniform_floor = q(127, 51200)
assert q(1, 1000) < q(127, 25600)
assert q(127, 25600) - q(1, 1000) / 2 > uniform_floor

# A coarse entirely integer certificate for the capacity separation.
# h_2(1/5) < 3/4 iff 5^20 < 2^47.
assert 5**20 < 2**47
# h_2(1/128) <= (7 + log_2(e))/128 < 9/128.
# Thus C(Gamma_0) > 119/128 and C(E_0) < 3/4.
assert q(119, 128) - q(3, 4) == q(23, 128)

result = {
    "status": "PASS_EXACT_ALGEBRA_ONLY",
    "beta": str(beta),
    "omega": [[str(x) for x in omega.row(i)] for i in range(2)],
    "choi_diagonal_block_determinant": str(w0.det()),
    "uniform_choi_floor_for_epsilon_1_over_1000j": str(uniform_floor),
    "raw_commutator": [[str(x) for x in raw_commutator.row(i)] for i in range(2)],
    "raw_word_span_determinant": str(word_determinant),
    "canonical_classical_capacity_gap_lower_bound": str(q(23, 128)),
    "limits": "No script certifies capacity continuity or the universal classification. See analytic proof.",
}
dest = Path(__file__).with_suffix(".json")
dest.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
