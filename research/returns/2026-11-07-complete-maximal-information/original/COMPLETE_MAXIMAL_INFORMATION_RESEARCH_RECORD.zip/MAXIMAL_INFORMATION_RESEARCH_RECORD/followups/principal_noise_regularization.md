# Resource-envelope regularization and finite-data obstruction

Continuation of the independent principal route. The algebra-generation and profile-classification steps are established in principal_finite_probe_and_stability.md; universal greatest-member property remains N1698 capital.

Let U be the open set of full-Choi-rank channels of fixed input a>=2/output b>=2. Let M be any real-valued resource continuous in diamond norm at fixed output dimension, invariant under isometries/padding and monotone under deterministic output processing. Set C_M(E)=M(Gamma_E), the attained class ceiling. For full-algebra E this equals M(E); for every E, C_M(E)>=M(E).

THEOREM R (complete proof). On U:
(i) C_M=M on an open dense full-measure subset.
(ii) C_M is upper semicontinuous.
(iii) M(E)=lim_(epsilon down0) inf{C_M(F):F in U, ||F-E||diamond<epsilon}.

Proof: (i) full algebra and genericity. For(ii), any E_n->E in U has a common positive lower bound lambda on Omega_n. Use the concrete greatest Gamma_n in M_b, with Omega_Gamma_n=E_(A_n)(Omega_n)>=lambda I. The compact channel space has a subsequential limit Gamma_* along any limsup resource sequence. Every fixed finite RLD probe is continuous on these floors; equality of the E_n and Gamma_n profiles gives equality for E and Gamma_* in the limit. Hence Gamma_* is in E's profile class. M(Gamma_*)<=C_M(E). Continuity gives limsup C_M(E_n)<=C_M(E). For(iii), C_M(F)>=M(F) and continuity give liminf >=M(E). Full-algebra F are dense, with C_M(F)=M(F), so inf over each neighbourhood <=M(E). Bounds squeeze the limit.

For M=ordinary Q, use Leung--Smith CMP292(2009), Corollary14: if ||E-F||diamond<=epsilon then |Q(E)-Q(F)|<=8epsilon log_2 b+4h_2(epsilon) (small epsilon). Thus the lower-noise envelope exactly recovers ordinary Q, without evaluating it. This is an identity/obstruction, NOT a capacity algorithm.

On the preserved full-rank antidegradable fixture E0 (qubit->8), C_Q(E0)>=117/128, but arbitrarily close rational full-algebra antidegradable E_t have C_Q(E_t)=Q(E_t)=0 exactly. This is a discontinuity caused by generated-algebra degeneracy, with a COMMON STRICT CHOI FLOOR, not the already-known exact-support discontinuity at a rank boundary.

FINITE-DATA COROLLARY. No channel-query procedure can, with success probability>=2/3 uniformly over this class, output an estimate of C_Q to additive error<117/256 while making finitely many channel uses almost surely at E0. This covers adaptive quantum experiments under standard memoryless oracle use, not just RLD-probe measurements.
Proof: under E0 the event of halting with an estimate in a high interval has probability>=2/3. The union of such events with at most n queries increases to it; choose finite n making the probability>1/2. For E_t sufficiently diamond-close, any n-query adaptive protocol's output-event probability changes by at most n||E_t-E0||diamond/2 (hybrid channel-discrimination bound). Its high-answer probability remains>1/3, incompatible with uniform>=2/3 accuracy when C_Q(E_t)=0 and the high and low error intervals are disjoint. The source of impossibility is discontinuity; do NOT call this ordinary quantum capacity noncomputability, and do NOT rule out pointwise asymptotic estimators or exact symbolic-input algorithms by this argument.

Type-2 corollary: C_Q cannot be computable from arbitrary channel Cauchy names on this fixed-dimensional full-rank domain, since such computable functions are continuous. This is a routine computable-analysis consequence, not a substitute for an undecidability theorem on rational Choi matrices.

Interpretation: exact profile upgrading is a singular structural privilege. A Choi eigenvalue promise alone does not make it noise-stable. The constructive repair is the full-algebra generation margin and finite-probe Holder bound, which forbids the degeneracy. These facts do not remove ordinary coding/physical-control costs or solve ordinary Q approximation.
