# Constructor: priority and direct-subsumption review

6 November 2026. This is a priority review after the independent construction and mathematical challenge phases. It does not alter the original initial report. The converse and the explicit free-group obstruction were checked separately in [constructor_converse_audit.md](constructor_converse_audit.md); the positive exact-class construction is in [constructor_challenge.md](constructor_challenge.md).

## 1. Verdict

**B is not a new amenability, hyperfiniteness, Følner, hypertrace, or general operational-injectivity theorem.** Those descriptions would materially overstate priority. Both information-theoretic characterizations of injectivity and an atomic-exact/injective-approximate physical-realization pattern are already published. O, the offline heralded-Choi plus port-based-teleportation compiler, is an application of standard PBT and should not be a separate discovery-paper claim.

The narrower B statement survives the direct-subsumption checks below: I did not find it literally stated in the inspected primary results, and the two closest operational theorems do not supply its exact-class restriction or its uniform quantifier. The possible contribution is the equivalence between an approximate maximum **inside one fixed tracial normalized-channel class** and injectivity, including reduction of the negative direction to fixed scalar binary tests of a finite generating input system. This is a specific operational reformulation and construction built on established operator-algebraic characterizations. **Historical priority of that residual bridge remains unproved.** The defensible present verdict is `NO DIRECT DUPLICATE IDENTIFIED IN THE INSPECTED CLOSEST SOURCES; RESIDUAL PRIORITY NOT CLEARED`, not a declaration of novelty based on unsuccessful searches.

If developed into a paper, B should be one focused contribution with the classical machinery credited at the theorem level. It should not be split into separate purported discoveries of the trichotomy, amenability characterization, Haar approximation, and free-group nonamenability. The physical and algorithmic limitations remain part of the statement.

## 2. Fix the exact mathematical novelty target

The following formulation avoids letting a change of terminology manufacture originality. Let M have separable predual and faithful normal tracial state tau. Fix a finite integer a and a UCP map T:M_a -> M such that tau(T(X))=Tr(X)/a and W*(T(M_a))=M. Let C(T,tau) consist of channels

    G(X)=Omega^(1/2) pi(T(X)) Omega^(1/2),

where pi is a faithful normal unital representation on a separable Hilbert space, Omega is faithful positive trace class with Tr Omega=a, and

    Tr(Omega pi(Z))=a tau(Z)  for every Z in M.

Physical postprocessings are normal CPTP maps between trace-class spaces; d(G,F)=inf_R ||F-RG||_diamond. A complete-profile interpretation additionally depends on the independently checked identification of that profile class with this labelled normal sandwich class. The class above is the concrete object being compared with predecessors.

The candidate B equivalence, with all these hypotheses, is:

1. M is injective.
2. There are G_k in C(T,tau) with sup_{F in C(T,tau)} d(G_k,F) -> 0.
3. There are G_k in C(T,tau) that asymptotically dominate each of a fixed countable family of pinched exact-class targets, one for each Hermitian input generator and each threshold in a dense set avoiding atoms of its spectral law.
4. For the same finite generator system, the corresponding binary trace-norm ceilings can be approached simultaneously, with the exact state restriction on all M maintained at every k.

The implications involving injectivity have been proved in the research notes. The general-center injectivity-to-hyperfiniteness import must retain its separable-predual hypothesis and its verified citation. No effective filtration, rate, finite-dimensional in-class output, preparation algorithm, or black-box recognition algorithm is claimed.

There is an exact greatest member precisely when M is a countable product of finite matrix blocks. The diffuse injective case therefore separates exact physical maxima from arbitrarily accurate in-class maxima. The free-group example has neither kind. This is an operational organization of familiar algebra types, not a new classification of von Neumann algebras.

## 3. Closest established algebraic core

### Brown: hypertraces and uniform amenable traces

Nathanial P. Brown, *Invariant Means and Finite Representation Theory of C*-algebras*, [arXiv:math/0304009v2](https://arxiv.org/html/math/0304009), Theorem 3.1.6, proves the amenable-trace finite-matrix approximation criterion. Its proof explicitly obtains positive trace-class almost-central densities by normal-state approximation and convexification. Definition 3.2.1 and Theorem 3.2.2 distinguish **uniform** amenability: norm convergence of the induced traces is equivalent to hyperfiniteness of the tracial GNS von Neumann algebra. Theorem 6.3.3, for a II_1 factor in standard form, includes the equivalence between hyperfiniteness, a hypertrace restricting to the prescribed normal trace, Følner projections, and injectivity. Thus the central-density/hypertrace/projection part of B's converse is established machinery. Brown's proof also records why correct restriction on all of M matters; mere amenability of a weakly dense C*-algebra's trace does not universally imply injectivity of its GNS algebra.

**Subsumption:** all the algebraic endpoints and most of the converse after centrality has been obtained are old. B's claimed new step cannot be the passage from a prescribed normal-trace hypertrace to injectivity. Its possible extra step is extracting that hypertrace from approximate postprocessing of the fixed finite input family while preserving the exact normalized class.

### Følner densities and prescribed traces

Fernando Lledó and Diego Martínez, *A note on commutation relations and finite dimensional approximations*, [arXiv:2111.15221v2](https://arxiv.org/html/2111.15221), Theorem 2.12, characterizes Følner C*-algebras using positive trace-class unit-trace densities with trace-norm commutators tending to zero in every faithful essential representation. Remark 2.13 allows finite-rank densities. Pere Ara and Fernando Lledó, *Amenable traces and Følner C*-algebras*, [arXiv:1206.1488](https://arxiv.org/html/1206.1488), Proposition 3.1(ii) and Theorem 3.2, produce Følner projections recovering a prescribed amenable trace for separable essential representations. Essentiality is explicit in the latter direction.

**Subsumption:** asymptotic trace-class centrality, its finite-rank variants, and its use in representing tracial laws are not new capabilities. These results do not state B's fixed exact normal-trace restriction at every stage, nor the existence of an approximate Blackwell maximum in that restricted class. Those missing clauses must actually be proved; calling a density sequence a channel does not supply them.

## 4. Closest information-theoretic injectivity result

Priyanga Ganesan, Li Gao, Satish K. Pandey and Sarah Plosker, *Quantum Majorization on Semifinite von Neumann Algebras*, J. Funct. Anal. 279 (2020), 108650, [arXiv:1909.10038](https://arxiv.org/html/1909.10038). Theorem 3.5 characterizes injectivity of semifinite M by equality of a vector-valued L_1 norm with an operator-space projective tensor norm when the other algebra is infinite dimensional; the authors identify the positive norm with conditional min-entropy and relate this to Haagerup's decomposability criterion. Theorem 3.13 characterizes exact postprocessing of CPTP maps into L_1(M), assuming M injective. Theorem 3.18 gives the cb-norm approximate postprocessing criterion, again assuming injective M, through projective-tensor norm tests on bipartite densities. Theorem 3.16 instead concerns approximation of bipartite states and additionally assumes infinite trace and matching other marginals. Remark 3.19 warns that the approximate tests cannot simply be restricted to separable inputs as in the exact case.

This paper decisively rules out describing B as the first information-theoretic characterization of injectivity.

### Actual interface-reduction check

There are two possible ways to try to obtain B from this paper. Neither alone delivers it.

**Use the physical output algebra B(H).** Put T=G and S=F in the channel-factorization theorem, padding separable outputs into a common infinite-dimensional Hilbert space when needed. The physical output algebra B(H) is injective for every pair, including pairs whose hidden normalized algebra is L(F_2). Theorem 3.18 then gives a complete test for the particular deficiency d(G,F). It does not choose one G from C(T,tau), impose the exact sandwich invariant on that choice, or control the tests uniformly over all F. Equality of maximal/RLD profiles is not equality of all conditional-min-entropy postprocessing monotones: if it were, all members of each finite profile class would already be mutually Blackwell equivalent. That is precisely the information loss the original profile mechanism permits. Consequently one cannot insert profile equality into their criterion and conclude B.

**Use the hidden algebra M as their output algebra.** The abstract channel into L_1(M) is a natural comparison object, but it is not itself the required trace-class B(H) realization. Their factorization result assumes its injectivity rather than deriving it from approximate domination by normal sandwich realizations. The norm equivalence in Theorem 3.5 has different variables and ancillary quantifiers; converting its witnesses into fixed finite-input pinched targets requires another argument. In particular, the physical source and target algebras in B remain type I even in the noninjective example. This prevents identifying the two theorems simply by substituting M for a physical output algebra.

**Verdict:** strong conceptual predecessor, not a literal direct subsumption of the checked exact-class theorem. Our new mathematical burden is the restricted-fiber maximum and its finite-generating-system converse, not general postprocessing duality or a new min-entropy criterion.

## 5. Closest exact/approximate physical-realization pattern

Kazuya Okamura and Masanao Ozawa, *Measurement theory in local quantum physics*, J. Math. Phys. 57 (2016), 015209, [arXiv:1501.00239v3](https://arxiv.org/html/1501.00239). Theorem IV.1 says CP instruments on atomic von Neumann algebras have the normal extension property (NEP). Theorem IV.3 approximates every instrument on an injective algebra ultraweakly by instruments with the NEP, which have measuring-process realizations. The discussion immediately after Theorem IV.4 explicitly states atomic iff every instrument admits a normal extension with range in M, and injective iff the corresponding approximate extension property holds. Proposition IV.2 attributes the normal-CP approximation characterization to Anantharaman-Delaroche, *Amenable correspondences and approximation properties for von Neumann algebras* (1995), Corollary 3.9. Their continuous commutative and II_1 examples also separate exact from approximate physical realization.

**Direct reduction check:** their approximating normal maps and instruments are not asserted to preserve the labelled normalized-channel class exactly. Composing a normal approximate projection with an abstract statistical family generally changes its normalized generators and moment law. Their quantifier is approximate realization of each instrument, not a single in-class source that dominates every exact-class realization with a uniform diamond bound. Finite-input norm conversion by compactness or convexification may itself be routine, so weak-versus-diamond language should not be sold as an independent breakthrough. The material additional restriction is preservation of the entire exact class while gaining uniform dominance.

**Verdict:** this is a mandatory comparator for any trichotomy narrative. The broad atomic-exact/injective-approximate pattern was already operational and physical. B may refine that pattern for a different, sharply restricted comparison problem; it must not claim to originate the pattern.

## 6. Statistical-experiment predecessors

### Guţă and Jenčová: canonical experiments and Le Cam convergence

Mădălin Guţă and Anna Jenčová, *Local asymptotic normality in quantum statistics*, Commun. Math. Phys. 276 (2007), 341–379, [arXiv:quant-ph/0606213v2](https://arxiv.org/html/quant-ph/0606213). Theorem 3.5 characterizes ordinary equivalence of minimal sufficient experiments by canonical states built using Connes cocycles. Theorem 3.16 identifies weak convergence with convergence in quantum Le Cam distance for finite parameter sets under uniform domination of canonical states and type-I-with-discrete-center minimal sufficient algebras. Its proof uses the atomic type-I predual's Kadec–Klee property. The theorem does not cover an arbitrary diffuse tracial normalized algebra and does not use maximal-profile equivalence.

**Verdict:** normal channels, canonical representations, deficiency, approximate equivalence, and the atomic/diffuse distinction are long-standing statistical machinery. Theorem 3.16 does not literally settle B: its equivalence class, hypotheses, and convergence problem differ.

### Jenčová: approximate comparison and binary recovery

Anna Jenčová, *A general theory of comparison of quantum channels (and beyond)*, IEEE Trans. Inf. Theory 67 (2021), 3945–3964, [arXiv:2002.04240v2](https://arxiv.org/html/2002.04240), gives general approximate simulability/randomization criteria through decision problems and guessing probabilities; the channel framework there is finite dimensional. Her *Recoverability of quantum channels via hypothesis testing*, Lett. Math. Phys. 114 (2024), 31, [publisher full text](https://link.springer.com/article/10.1007/s11005-024-01775-2), Theorem 4, proves that preservation of all binary Bayes errors, equivalently all ||rho-s sigma||_1, characterizes sufficiency for arbitrary trace-class state pairs.

**Verdict:** B's binary-test language must credit this existing connection between testing and recoverability. The checked theorem does not directly imply simultaneous normal-trace centrality for changing representations of a fixed noncommutative generating system. B's far/near spectral-cut argument supplies that extra bridge. A paper should explain this distinction instead of implying that binary testing was previously unrelated to reversibility.

### Kuramochi: ordinary minimal sufficiency

Yui Kuramochi, *Minimal sufficient statistical experiments on von Neumann algebras*, [arXiv:1701.03394](https://arxiv.org/html/1701.03394), Theorem 1, establishes existence and uniqueness up to isomorphism of minimal sufficient experiments under ordinary CP/Schwarz equivalence. This does not classify maxima in a coarser maximal-profile class. It precludes presenting the mere existence of canonical/minimal sufficient objects as new.

### Paterson and Torgersen: amenability already enters deficiency

Alan L. T. Paterson, *Amenability and Translation Experiments*, Canad. J. Math. 35 (1983), 49–58, [primary PDF](https://www.cambridge.org/core/services/aop-cambridge-core/content/view/AC1376E8EC59E0676EDF4D045F553763/S0008414X00022549a.pdf/amenability_and_translation_experiments.pdf), Theorem 1, proves that for an amenable locally compact group G and translation experiments generated by probability densities P,Q, their deficiency is inf_nu ||Q-P*nu||_1 over probability densities nu. This repairs and extends Torgersen's 1972 translation-experiment result. Thus amenability and operational statistical deficiency were connected well before modern quantum comparison results.

**Verdict:** this is a historical warning against an inflated general theme, not direct subsumption: these are classical translation experiments, not the restricted quantum channel class in §2, and Theorem 1 is not the injectivity equivalence claimed there.

## 7. Which parts, if any, remain a mathematical contribution?

The strongest residual claim is the following conjunction, rather than any isolated classical endpoint:

- A finite input generating system encodes the obstruction. Pointwise domination of a fixed countable pinched family already forces injectivity; no maximization over arbitrary auxiliary quantum games is needed for that direction.
- In the positive direction, Haar averaging Omega over finite-dimensional subalgebras preserves Tr(Omega Z)=a tau(Z) for **all** Z in M. Thus G_k stays in the exact class, even though an ordinary finite-dimensional approximation of T need not. Finite-block normal simulators give the uniform bound

      sup_F d(G_k,F) <= a sum_{i,j} ||T(E_ij)-E_k T(E_ij)||_(2,tau).

  The approximating G_k may still have infinite-dimensional physical output. The finite external envelope is not generally a member of the exact class.
- The negative direction is not merely a named free-group example: finite scalar testing deficits imply spectral-cut centrality, then a hypertrace with the exact normal restriction, then the established injectivity criterion. These steps must remain explicit.
- The input-3 L(F_2) Choi fixture and its finite set of 60 target obstructions make one failure concrete. This encodes known nonamenability and known paradoxical-set bounds. It is not a new nonamenability theorem or a finite Choi implementation of an infinite device.

These clauses are not in the inspected predecessor statements. They also explain exactly why simply citing Brown, Ganesan et al., or Okamura–Ozawa does not finish the proposed result. Nevertheless, a theorem can be a modest new operational corollary of powerful established theory. The paper should earn its scope by stating the restricted problem first, proving the bridge, and acknowledging that the algebraic classification is classical.

## 8. O is standard PBT application, not a separate novelty claim

The deterministic PBT processor, its universal product-port simulation of a general channel from many Choi copies, and the adaptive telescoping bound are already standard. The acquired [Pirandola et al. source](https://arxiv.org/html/1803.02834) is the load-bearing predecessor. Offline heralded acquisition of those copies, a negative-binomial/Chernoff budget, accepted-resource perturbation bounds, and fixed-dilation continuity are useful implementation accounting, but do not establish a new generic channel-simulation mechanism. In particular, polynomial expected source use under a fixed error contract does not mean a polynomial-size local processor or an exact compiler.

It is reasonable to retain O as an application or a technical appendix if it directly serves the profile work. It should not become a standalone paper asserting a newly discovered escape from online p^n success: standard Choi-resource PBT already supplies the escape once the resource-acquisition interface is specified.

## 9. Limits and disposition

The mathematical audit currently supports B at the tracial/separable/normal scopes. This priority review does **not** certify originality. The most important publication exclusions are now concrete: do not claim new Følner density approximation, a first operational injectivity characterization, a new atomic-versus-injective realization pattern, a new free-group obstruction, or a new PBT compiler. For the residual B bridge, the nearest inspected sources have been compared at their actual interfaces rather than dismissed because titles differ.

Recommended disposition: continue only one precise B research line if the principal judges that the restricted exact-class maximum is sufficiently consequential. Describe it as an operational classification for tracial normalized-channel classes, built on classical amenability and quantum comparison theory. Keep historical priority of that precise bridge open pending the team's combined audit. This note is a research priority assessment.

Local source evidence: HTML originals and compact mathematical text for Brown, Ara–Lledó, Lledó–Martínez, Ganesan et al., Guţă–Jenčová, Jenčová 2021 and Kuramochi are cached under `../constructor/priority/`. Okamura–Ozawa, Jenčová 2024 and the Paterson PDF were read through the primary-source browser tool; extra local downloads were stopped after disk-space errors. Only my own redundant generated text derivatives were removed, retaining original cached source bytes. The linked sources, theorem numbers and hypotheses above distinguish inspected results from unresolved historical coverage.
