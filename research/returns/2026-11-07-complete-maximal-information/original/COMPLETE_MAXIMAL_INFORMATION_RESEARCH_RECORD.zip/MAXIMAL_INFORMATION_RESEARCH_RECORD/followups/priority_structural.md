# Structural priority audit: Theorems B and T

6 November 2026. Existing-machinery researcher's dedicated priority search,
commissioned after the proofs were saved. No new agents used. The earlier
mathematical verification remains separate from this priority assessment.

## 1. Calibrated verdict

**No directly subsuming theorem for B's complete-profile fiber and its full
operational quantifiers was verified in the primary sources read. This is not
historical clearance.** There is substantial, close prior work, including an
explicit earlier atomic-versus-injective distinction formulated in terms of
exact and approximate physical realization of instruments.

The strongest operational match is **Okamura--Ozawa (2015), Theorem IV.4 and
the paragraph immediately following it**, grounded in **Anantharaman-Delaroche
(1995), Corollary 3.9**. The former already discusses exact normal extensions
at atomic algebras and approximate normal extensions at injective algebras,
and gives iff statements when the extensions must range in the original
algebra. Accordingly neither an atomic/injective trichotomy in itself nor a
first operational characterization of injectivity is a defensible novelty
claim here.

The remaining plausible contribution is narrower: **within one class defined
by equality of all referenced maximal/RLD profiles**, a finite-input channel
has an exact greatest density-operator-output representative iff its faithful
tracial invariant is atomic finite type I; the class admits a common
pointwise dominating sequence iff it admits uniform approximate greatest
members iff the invariant is injective. The source approximants themselves
stay in that same exact class. The Bayes pinching and Haar arguments establish
that particular dictionary. They use old norm geometry and amenability
machinery, rather than a new operator-algebraic classification.

T has an especially strong priority burden: normal-expectation atomicity,
Holevo's continuous-output warning, and Kuramochi's discrete-POVM/fully-quantum
realizability theorem already contain much of the category obstruction. T
should be described as a proved application/extension of those results to the
specified complete-profile class. B's **fixed fiber, common source and
uniform diamond** formulation was not located in the primary sources below,
but that residual claim still needs expert bibliographic checking before any
assertion of first publication.

## 2. Target tested, rather than a keyword substitute

The exact target is finite input M_a, arbitrary separable trace-class quantum
output, bounded normalized UCP map T, generated M=W*(T(M_a)), and faithful
normal **tracial** tau. Full complete-profile equality identifies the labelled
normal triple (M,T,tau). Members are

    G(X)=Omega_G^(1/2) pi_G(T(X)) Omega_G^(1/2),
    Tr(Omega_G pi_G(z))=a tau(z),

with faithful normal pi_G and faithful trace-class Omega_G. For
d(G,F)=inf_R ||F-RG||_diamond, R normal CPTP, B states

    (exists G_n in the EXACT class)(for every fixed F) d(G_n,F)->0
          iff M injective
          iff (for every epsilon>0)(exists G in the EXACT class)
                    sup_F d(G,F)<epsilon.

T's exact greatest existence is equivalent to M being a countable von Neumann
product of finite matrix factors. Finite input and separable output are
material; arbitrary nontracial invariants are excluded. A normal physical
converter is required, whereas the limiting conditional expectation proving
injectivity may be nonnormal.

An earlier result counts as direct subsumption only if its hypotheses and
objects produce these class members and converters with these quantifiers,
or if a short explicit reduction establishes them. Similar words such as
canonical, maximal, approximate or sufficient do not suffice.

## 3. Search record and citation trails

Search date: 6 November 2026. Web queries were issued in batches, then the
most relevant original papers were acquired and their theorem/proof passages
read. Exact phrases were mixed with broader searches because very narrow
phrases often returned no technical match.

| Search family | Representative exact queries used | Follow-up |
|---|---|---|
| Quantum experiments and amenability | `"quantum statistical experiments" "amenable"`; `"statistical experiments" "hyperfinite"`; `"injectivity" "statistical experiments"`; `"hypertrace" "statistical"` | Brown; Kuramochi; no identical B statement found |
| Order, envelopes, randomization | `quantum channel concatenation supremum greatest upper bound normal statistical experiment`; `"quantum" "deficiency" "injective"`; `"amenability" "randomization" quantum`; `"tracial" "Blackwell"` | Kuramochi directed completeness; Jencova comparison |
| Reverse and maximal experiments | `quantum statistical experiment maximal reverse experiment von Neumann algebra`; `"quantum statistical" "maximal experiment"`; `"quantum" "greatest" "reverse test"`; `"RLD" "minimal" "reverse estimation"` | Matsumoto/Hiai; the principal separately audited additional RLD papers |
| Normality and realization | `"normal injective" "atomic" von Neumann`; `"normal extension property" "injective" "atomic"`; `"quantum" "least disturbing" "continuous" "discrete" channel` | Okamura--Ozawa, its Anantharaman-Delaroche citation, Holevo and Kuramochi |
| Operational norm/amenability bridge | `"amenable trace" "trace class" "commutator"`; `"hypertrace" "Reiter"`; `"hypertrace" "discrimination"`; `"hypertrace" "absolute value"`; `"Bayes" "injective" "von Neumann"`; `"hyperfinite" "deficiency" quantum` | Connes/Brown normal-state and Folner characterizations; no exact Bayes-fiber statement located |
| Direct terminology checks | `"RLD" "amenable"`; `"maximal f-divergence" "hyperfinite"`; `"normal extension property" "greatest"`; `"hyperfinite" "maximal" "divergences"` | No technical source with the full target found; this is weak negative evidence only |
| Final comparison/coupling checks | `"quantum statistical experiments" "maximal" "approximation"`; `"quantum" "approximately greatest" channel`; `"quantum" "maximal experiment" "RLD"`; `"amenable trace" "coupling" normal` | Jencova comparison and finite-dimensional testing-region work; no new directly matching structural theorem |

Citation trails followed:

* Okamura--Ozawa IV.2 -> Anantharaman-Delaroche Cor3.9, then its Lemma3.7
  and correspondence formulation. The 2019 Bannon--Marrakchi--Ozawa appendix
  was checked for the later generalization of this correspondence machinery.
* Kuramochi 2018 directed completeness -> Kuramochi 2017 minimal sufficient
  experiments -> its Theorem5/Lemma6 -> Størmer1972 and Holevo2011/2012.
* Brown's amenable/uniform amenable trace criteria -> Connes' hypertrace and
  Folner results. Ara--Lledo's approximation formulation was also read.
* The existing Hiai/Matsumoto and Petz/Guta--Jencova source caches were
  revisited to compare pairwise reverse tests and ordinary sufficient models
  with the complete maximal-profile class.

The principal is handling Paterson's *Amenability and Translation Experiments*
and several further RLD/geodesic papers. They are not represented as read or
cleared by this report.

## 4. Strongest near match: normal instrument extension

[Okamura--Ozawa, *Measurement theory in local quantum physics*,
arXiv:1501.00239v3](https://arxiv.org/pdf/1501.00239v3), **Theorem III.4**
identifies their normal extension property (NEP) with extension of an instrument
from M to B(H), and with realization by a measuring process. **Theorems IV.1,
IV.3 and IV.4** respectively give NEP on atomic M and point-ultraweak
approximation by NEP instruments on injective M. Crucially, the **paragraph
immediately after IV.4, PDF/printed p17**, gives exact iff atomic and
approximate iff injective when all the extended instruments must range in M.
It treats general centers, without our finite-input or tracial restrictions.

### Actual implication test

Use a singleton outcome space and the identity instrument I(x,{*})=x. The
strong range-M exact extension condition becomes precisely a **normal
conditional expectation B(H)->M**. Its approximate counterpart becomes normal
UCP maps B(H)->M whose restrictions converge point-ultraweakly to id_M.
Conversely composing any instrument with these maps proves the all-instrument
condition. Thus this older result is already an operational reformulation of
normal expectation versus injectivity. It is not just a vague thematic match.

It does not directly give B, for three identifiable reasons:

1. Its approximands are instruments on M, not sources G inside a prescribed
   complete-profile class. It neither fixes all labelled normalized moments nor
   constructs a member whose normalized map is exactly T.
2. Its convergence is point-ultraweak. That is not a diamond estimate, and the
   approximant may depend on the instrument and finite tests. B supplies one
   class source for all target realizations, with a uniform operational error.
3. Its converse assumes approximate extensions into M. B assumes only physical
   simulation between different type-I-output realizations of a single
   finite-input profile. The passage from those simulations to a retraction is
   exactly what the fixed Bayes targets and deficit estimate establish.

The topology distinction is concrete. On L-infinity of the circle, the normal
states with densities 1+sin(nx) converge pointwise to normalized Lebesgue
integration, since every bounded function is integrable and its Fourier
coefficients vanish. Their predual norm distance from that state is always
2/pi. The normal UCP maps f->(integral f(1+sin(nx)))I therefore converge
point-ultraweakly but not in their corresponding predual norm. Convexification
can improve finite tests; it does not by itself preserve all exact profiles.

These differences do **not** prove novelty. Further lemmas might derive B from
the older extension theory. In particular, exact state restrictions and strong
finite-test convergence can sometimes be repaired by standard state-extension
and convexity arguments. The safe conclusion is that the exact B dictionary
still requires an explicit bridge, not that its ingredients are new.

## 5. The underlying CP extension and amenability results

[Anantharaman-Delaroche, *Amenable correspondences and approximation properties
for von Neumann algebras*, Pacific J. Math.171 (1995),309--341](https://msp.org/pjm/1995/171-2/pjm-v171-n2-p02-s.pdf),
**Corollary3.9, printedp331 / PDFp24**, equates a norm-one projection N->M
with normal subunital CP maps N->M approximating id_M point-ultraweakly,
provided a faithful normal semifinite weight on M has modular automorphisms
implemented by unitaries in N. A finite trace makes that condition automatic.
The preceding **Lemma3.7, printedp328 / PDFp21**, attributed to Connes,
already supplies normal states almost restricting to the trace and almost
commuting in predual norm with any prescribed finite subset of M.

This is a genuine replacement for much of the approximation machinery in B.
It does not prescribe the complete-profile class of the resulting finite-input
channels. The Haar proof additionally imposes the exact restriction tau and
retains T unchanged. B's necessity creates near-central states from
postprocessing deficits, rather than assuming them.

[Bannon--Marrakchi--Ozawa, *Full factors and co-amenable inclusions*,
arXiv:1903.05395v2](https://arxiv.org/pdf/1903.05395v2), **AppendixA,
CorollariesA.2--A.3**, identifies conditional expectations with weak containment
of the associated standard correspondences, beyond the earlier semifinite
case. This reinforces that the expectation/correspondence step is established
machinery. It contains no complete maximal-profile or same-class diamond
statement in the passages read.

[Brown, *Invariant Means and Finite Representation Theory of C*-algebras*,
arXiv:math/0304009v2](https://arxiv.org/pdf/math/0304009v2), **Theorem3.1.6**
equates amenable traces with asymptotically multiplicative matrix UCP
approximations and hypertrace/tensor formulations. **Definition3.2.1 and
Theorem3.2.2** strengthen trace convergence to norm in A*, obtaining exactly
hyperfiniteness of the GNS von Neumann algebra. **Theorem6.3.3(4)**, in its
II_1-factor setting, already permits a hypertrace central on a weakly dense
C*-subalgebra if it restricts to the normal trace on all M. Consequently the
generator-to-all-M extension in our proof is not a new amenability principle.

The restriction-to-all-M condition is important. Amenability of a trace merely
on a dense C*-algebra, without the correct normal extension, must not be
silently identified with injectivity of its weak closure. B's exact restriction
Tr(Omega_n pi_n(z))/a=tau(z) supplies that missing strength. Ara--Lledo,
[arXiv:1206.1488](https://arxiv.org/pdf/1206.1488), **Proposition3.1 and
Theorem4.3**, give further established Folner/matrix-UCP formulations; these do
not independently identify an RLD fiber.

Connes's general-center injectivity/hyperfiniteness import and representation
independence were already verified in the earlier report: IHES/P/76/132,
Theorem4.1, printedp43; *Noncommutative Geometry*, ChV section7,
Definition2p502 and Theorem6p504. Those are not contributions of B.

## 6. Does a standard Bayes criterion already contain the bridge?

For a precise baseline, [Jencova, *Comparison of quantum channels and statistical
experiments*, arXiv:1512.07016v2](https://arxiv.org/pdf/1512.07016v2),
**Theorem1**, characterizes diamond-norm postprocessing deficiency through
success probabilities of referenced output ensembles, for finite-dimensional
channels. The old randomization criteria thus characterize processing by
**all** decision problems, with reference systems in the complete quantum
version. They do not automatically determine a maximal-profile fiber, and the
finite-dimensional theorem is not itself an infinite-output extension.
Equality of the maximal
profiles is weaker than ordinary randomization equivalence; the saved
full-Choi order counterexample is one concrete warning against conflating
these interfaces.

The residual B proof can be isolated into the following operation. For each
generator b_i=T(H_i) and atom-free threshold t, pinching a fixed base density
produces a **fixed target in the same class** attaining

    ||F_(i,t)(H_i-tI)||_1=a tau(|b_i-tI|).

Approximation to that target forces delta_n down0. Helstrom decomposition and
Schatten Cauchy--Schwarz give F_n<=sqrt(u delta_n/2), and spectral truncation
gives

    ||[Omega_n,1_(t,infinity)(pi_n(b_i))]||_1
       <=2F_n/s+4a sqrt[tau(1_[t-s,t+s](b_i))].

That estimate converts the in-fiber operational assumption to the known
central-state criterion. The elementary inequality itself is ordinary
trace-norm/fidelity geometry. Spectral truncation, state-space compactness and
the expectation construction are also established techniques. What was not
found is the preceding **exact-profile fixed-target construction and its
use to make that particular processing hypothesis sufficient** for amenability.

Thus it would overstate the work to market this as new amenability machinery.
At most it is a new application/characterization of a specific class of quantum
experiments, unless an older profile/reverse-experiment paper contains the same
dictionary. The existing primary sources do not eliminate that remaining
priority risk. The countable fixed-target diagonal argument and resulting
finite obstruction are routine consequences once this dictionary is available.

## 7. Strong predecessors for T and the larger-category distinction

[Kuramochi, *Minimal sufficient statistical experiments on von Neumann
algebras*, arXiv:1701.03394v2](https://arxiv.org/pdf/1701.03394v2),
**Theorem5** proves that a POVM is postprocessing equivalent to a discrete
one iff its associated normal channel is concatenation equivalent to a channel
with fully quantum outcome B(H). **Lemma6** uses atomicity/normal expectation;
**Remark4** expressly credits Holevo's continuous-output observation.
This directly anticipates the discrete/diffuse normal-realizability obstruction
underlying the binary and commutative part of T.

[Holevo, *Information capacity of quantum observable*,
arXiv:1103.2615v3](https://arxiv.org/pdf/1103.2615v3), **section1,p2**,
explains why a diffuse classical output has no analogous diagonal
density-operator output and connects this to absence of a normal expectation
onto a diffuse diagonal algebra. It does not state a complete-profile-class
greatest theorem, but rules out novelty for the category warning itself.

Størmer, *On projection maps of von Neumann algebras*, Math.Scand.30
(1972),46--50, [primary PDF](https://journals.msp.org/mscand/article/download/2265/2264/2296),
**unnumbered theorem,p47**, establishes the normal-projection/atomic-center
obstruction in the type-I subalgebra setting. Its cached scanned proof was
read during the earlier challenge. A faithful normal tracial algebra whose
normal finite-dimensional representations separate points has countably many
finite matrix blocks by standard central-ideal decomposition. These are T's
old structural ingredients.

[Kuramochi, *Directed-completeness of quantum statistical experiments in the
randomization order*, arXiv:1805.04357v2](https://arxiv.org/pdf/1805.04357v2),
**Theorems3--4**, proves directed completeness in the larger von
Neumann-algebra randomization category. **Theorem5 and its discussion on
p27** exhibit a diffuse commutative bound missing from fully-quantum-output
channel classes. This is an especially relevant order-completion predecessor.
It does not assume a common maximal-profile fiber, prove that such a fiber
is directed, or give B's norm-uniform approximation criterion.

Hiai's [arXiv:1807.03118v1](https://arxiv.org/pdf/1807.03118v1), **Lemma6.1
and Theorem6.3**, supplies normal diffuse L-infinity spectral reverse tests
for maximal divergences. Matsumoto's
[arXiv:1311.4722v4](https://arxiv.org/pdf/1311.4722v4), **Theorems6.1 and6.9**,
supplies optimal finite reverse tests and scoped essential uniqueness. Those
are strong antecedents for the ideal spectral representative. They compare a
fixed pair and its reverse tests, not the entire referenced channel profile
with every realization. Neither their broader classical category nor their
finite hypotheses may be silently replaced by separable density-operator
output.

Guta--Jencova, [*Local asymptotic normality in quantum statistics*,
arXiv:quant-ph/0606213v2](https://arxiv.org/pdf/quant-ph/0606213v2),
**Corollary3.4 and Theorem3.5**, gives the canonical-state/Connes-cocycle
description of ordinary experiment equivalence. It is an important precursor
for faithful moment/GNS reconstruction. Its canonical generators are modular
cocycles for the specified state family, rather than the bounded normalized
output generators defining the maximal-profile fiber. Their identification
would require a proof; it is not an equality of terminology.

## 8. What can and cannot be claimed after this audit

| Proposed claim | Priority assessment |
|---|---|
| New injectivity/hyperfiniteness equivalence | Incorrect: Connes and established extensions |
| First exact/approximate operational realization trichotomy | Unsupported and strongly prefigured by Okamura--Ozawa |
| New normal-expectation atomicity or diffuse-output obstruction | Incorrect: Størmer, Holevo, Kuramochi and earlier operator-algebraic work |
| New central-state/Folner characterization or generator-to-hypertrace method | Incorrect as a broad claim: Connes, Brown and the correspondence literature |
| B's complete-profile fiber, exact in-fiber sources, common pointwise/uniform diamond equivalence | A proved statement here; no directly subsuming primary theorem verified; priority remains unresolved |
| T as application/extension to complete referenced maximal profiles | Defensible attribution framing; combined-statement priority unresolved |
| Computable/efficient canonicalizer or amenability decision procedure | Not proved and not earned by these sources |

Suggested accurate positioning: **An application of quantum-experiment
comparison and injective-von-Neumann-algebra theory to greatest
representatives of complete maximal-information profile classes.** Explain
the older normal-extension trichotomy first. Then identify the extra fixed
profile and uniform diamond quantifiers, and prove the Bayes/Haar bridges.
Avoid a novelty claim based only on unfamiliar terminology.

The audit narrows a possible contribution; it does not establish that a paper
would duplicate an existing theorem, and it does not certify that it would
not. The remaining high-value check is whether an existing maximal/reverse
experiment or Petz-dual realization theorem already contains this fixed-fiber
dictionary. The principal's parallel literature audit addresses additional
specific candidates. No corresponding content is invented here.

## 9. Acquired evidence

New primary PDFs and full extracted text are in
`../literature/machinery-priority-structural/`, with SHA-256 and page counts
in `SOURCE_MANIFEST.json`:

* Okamura--Ozawa1501.00239v3; Anantharaman-Delaroche1995;
* Brown math/0304009v2; Ara--Lledo1206.1488;
* Kuramochi1805.04357v2; Bannon--Marrakchi--Ozawa1903.05395v2;
* Holevo1103.2615v3.

The earlier machinery cache contains Kuramochi1701.03394v2, the Størmer
scan, Hiai1807.03118v1, Matsumoto1311.4722v4, Connes1976/1994,
Guta--Jencova and Jencova comparison papers. The audited B proof is in
`machinery_approximate_greatest_converse.md`. A source's failure to use a
searched keyword is not treated as a theorem about non-subsumption.
