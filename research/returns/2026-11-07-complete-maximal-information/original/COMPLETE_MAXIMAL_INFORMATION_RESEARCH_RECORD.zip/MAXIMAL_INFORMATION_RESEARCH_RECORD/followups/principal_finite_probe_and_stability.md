# Finite physical probes, effective robust rigidity, and unstable greatest lifts

Principal derivation; 6 November 2026. No other researchers' initial reports read at writing.

## 1. Setup

Fix a,b>=2 and a rational Hermitian basis I,H_1,...,H_(a²-1) of M_a with traceless H_i and ||H_i||<=1. Standard real/imaginary off-diagonal matrix units and diagonal differences suffice (not necessarily orthonormal). E:M_a->M_b is CPTP and Omega=E(I)>0. Set T(X)=Omega^(-1/2)E(X)Omega^(-1/2), tau(A)=Tr(Omega A)/a. Tau is faithful, not assumed tracial. Profile g_E(rho,H)=Tr(E_R(H) E_R(rho)^(-1) E_R(H)), for rho>0 trace1 and Hermitian traceless H. Tensor-factor conventions input A then untouched R; output B then R.

## 2. A fixed finite rational family detects complete profile equality

Put L=2b²-1, r=L+1=2b² and D=2br. For each word w=(i_1,...,i_n), 1<=n<=L, define A_j=|j-1><j|+|j><j-1| on C^r and
rho_w(z)=[I_(ar)-sum_j z_j H_(i_j) tensor A_j]/(ar).
Let G be ANY D+1 distinct rational numbers in [-1/(4L),1/(4L)]. Use every z in G^n. Then rho_w(z)>=3I/(4ar) and Tr rho=1.

Use the r² rank-one rational-complex projectors P consisting of |j><j| and the projectors onto (|j>+|k>)/sqrt2 and (|j>+i|k>)/sqrt2 for j<k. Their matrices have rational real/imaginary entries. For each probe set H_(w,z,P)=I_a tensor P - a rho_w(z), which has trace0. This is a fixed finite rational probe list independent of channel coefficients. A crude probe count is r² sum_(n=1)^L [(a²-1)(D+1)]^n, before deduplication.

THEOREM F: Two such channels E,F have equal complete RLD profiles iff g_E=g_F on this finite list. Thus complete maximal-perspective equality follows as well. This is a uniform finite-grid version of N1698's path/word machinery; do not claim finite word closure or rational interpolation as new machinery.

Proof (fully elementary). For any rho,H and t, g_E(rho,H+t rho)=g_E(rho,H)+2t TrH+t²; channel TP makes added terms independent of E. Hence for J=I_a tensor P (TrJ=a) the shifted tangent has g_E(rho,J-a rho)=g_E(rho,J)-a². Finite-list equality is therefore equivalent to equality of the same g at J.

Let Q_E(z)=I_(br)-sum_j z_j T(H_(i_j)) tensor A_j. Direct congruence and cyclic trace give
 g_E(rho_w(z),J)=a² r Tr_R[P (tau tensor id)(Q_E(z)^(-1))].
Indeed E_R(rho)=Ad_(Omega^(1/2) tensor I)(Q)/(ar), and E_R(J)=Omega tensor P. The projectors P span all Hermitian matrices over R and hence determine the Hermitian matrix (tau tensor id)(Q^-1), including complex off-diagonal entries.

For each fixed w,P, the scalar difference g_E(rho,J)-g_F(rho,J) is a rational function in z whose denominators are det E_R(rho) and det F_R(rho), each of total degree <=br, with nonzero denominators throughout the box. Numerators of the individual g terms have degree <=br-1 (the tangent J is independent of z). Their difference after clearing denominators has total degree <=2br-1 and degree in EACH variable <=D. Vanishing on G^n forces polynomial identity by repeated one-variable interpolation. Thus matrix resolvents agree throughout the small box. The coefficient of z_1...z_n in their (0,n) entries is the ordered moment tau[T(H_i1)...T(H_in)], since the unique length-n path from 0 to n follows these edges in this order. Resolvent power-series convergence follows from ||sum z T(H_i) tensor A_j||<=sum|z|<=1/4 (T unital positive is contractive on Hermitian inputs).

Close paired Hermitian generators (T_E(H_i),T_F(H_i)) in M_b directsum M_b. Its word span stabilizes by length 2b²-1 because the ambient dimension is 2b² and the identity supplies dimension1 at length0. All retained word moments agree, so the two faithful states agree on the paired algebra. If (0,Y) lies in it, the common state on (0,Y*Y) is zero, and faithfulness implies Y=0. Symmetrically for (X,0). The paired algebra is the graph of a labelled state-preserving *-isomorphism. Conversely such an isomorphism preserves the normalized two-output perspective by functional calculus, its faithful-state trace, and hence every complete RLD profile. This proves all assertions; it independently supplies the load-bearing finite-dimensional classification used here. No unknown detailed package is required for this derivation.

## 3. Effective Holder reconstruction under a generation margin

For words w of length <=b²-1 (including empty), let V_E have vectorized matrices w(T_E(H)) as columns and define F_E=V_E V_E*. Take rational lambda,kappa>0, and let K_(lambda,kappa) consist of CPTP E:M_a->M_b with Omega_E>=lambda I and F_E>=kappa I_(b²). This is a compact semialgebraic set: Omega^(-1/2) is represented by its unique positive inverse square root via polynomial equations, inequalities and auxiliary variables. Boundedness follows from channel Choi trace a and Omega>=lambda. The frame inequality exactly supplies a quantitative full-algebra promise.

Let f(E,F)=max over the finite rational probes |g_E-g_F|. Define
 d(E,F)=min_(U unitary bxb) ||J_F-(I_a tensor U)J_E(I_a tensor U*)||_F.
The unitary group is compact; d is continuous (even Lipschitz in J) and semialgebraic by quantifier elimination. f is continuous and semialgebraic on K², since probe outputs have a fixed spectral floor >=3lambda/(4ar). Theorem F and faithfulness yield f=0 => a labelled *-isomorphism M_b->M_b, hence inner unitary equivalence. Equality of tau on all M_b then gives Omega_F=U Omega_E U*, so F=Ad_U E and d=0.

Apply Basu--Mohammad-Nezhad (Forum Math Sigma12 e115,2024), Theorem2.2: for continuous semialgebraic f,g on a closed bounded semialgebraic A, f^-1(0) subset g^-1(0) implies |g|^q <= C|f| for a finite q and C. All hypotheses checked with A=K² and g=d. Therefore d(E,F)^q<=C f(E,F). After obtaining quantifier-free formulas of maximum degree d0 in n real channel-pair coordinates, their theorem supplies q<=(8d0)^(2(n+7)); this is NOT a useful polynomial bound because elimination degrees and probe count can be huge. For fixed rational a,b,lambda,kappa, enumerate q>=1 and dyadic C>0, and decide the universal inequality by real quantifier elimination. Existence guarantees termination and gives explicit computable q,C.

Since ||E-F||diamond<=||J_E-J_F||_1<=sqrt(ab)||J_E-J_F||_F for the UNNORMALIZED Choi convention, we obtain
 min_U ||F-Ad_U E||diamond <= sqrt(ab) [C f(E,F)]^(1/q).

Given probe estimates within delta, a feasible algebraic channel in K with estimates within delta exists if the true channel is in K and is found by semialgebraic sampling. Its probe distance to the true channel <=2delta; the displayed bound applies. This identifies the channel up to output unitary, not the physical output basis. It is a finite effective noisy-data theorem, not a polynomial-time tomography result. Estimating an RLD number requires repeated physical preparations/tomography or other explicitly supplied measurements; there is no direct divergence oracle for free.

The Holder step is an APPLICATION of established semialgebraic stability; Specht-type moment reconstruction is established. Candidate contribution is the explicit finite *physical* RLD probe interface and exact irreducibility-conditioned scope. Novelty not yet established.

## 4. Generic rigidity and a hard obstruction to stable canonicalization

At full Choi rank the full-algebra property is open, dense, and full measure in every fixed-dimensional TP affine channel set (a,b>=2). A direct proof is in initial/principal.md. Raw generators E(H_i) with star product X Omega^-1 Y have rational entries; a b²-word determinant detects generation. A single rational generating seed gives a nonzero numerator polynomial, hence a measure-zero exceptional algebraic set.

Take the preserved rational N1690 channel E0:M2->M8 with J>=1/1050625 I, Q(E0)=0 and an open CPTP antidegradable ball of radius9/10^9. N1698 supplies a same-profile greatest representative with Q>=117/128. For an explicitly chosen rational full-algebra seed E*, set E_t=(1-t)E0+t E*. The raw-word determinant nonzero at t=1 has only finitely many roots. Thus all sufficiently small positive rational t give full-algebra channels E_t in the antidegradable ball. Each E_t is itself greatest, so the capacity ceiling of its entire profile class is exactly0; at t=0 it is >=117/128. All share a strictly positive Choi floor. This sharpens the mere continuity argument in the initial note by using the already-preserved interior antidegradability certificate.

Any canonical-greatest selector in a fixed common output padding cannot be diamond-continuous at E0, since Q is continuous in fixed finite dimension (Leung--Smith2009, Corollary7 to verify number) and the capacities jump by a constant. The scalar class-maximum resource cannot have a continuous finite-noise estimator there. This does NOT imply Q itself is discontinuous or noncomputable: the optimized profile ceiling is the unstable quantity. The counterexample depends exactly on the acquired *report* of N1690's robust fixture, not on a newly acquired or rerun 128x128 certificate.

More generally any continuous output-processing monotone resource M has an upper-semicontinuous class ceiling on Omega>=lambda: choose concrete greatest lifts Gamma_E in M_b; their Omega=E_A(Omega_E)>=lambda I. Compactness and continuity of all finite RLD probes make any subsequential limit a member of the limiting profile class. Hence limsup M(Gamma_En)<=M(Gamma_E). This is a conditional consequence of the full N1698 greatest theorem, unlike Theorem F which was independently derived above. Exact canonicalization is generically ordinary channel equivalence, with potential upward resource jumps at nongeneric reducible strata.
