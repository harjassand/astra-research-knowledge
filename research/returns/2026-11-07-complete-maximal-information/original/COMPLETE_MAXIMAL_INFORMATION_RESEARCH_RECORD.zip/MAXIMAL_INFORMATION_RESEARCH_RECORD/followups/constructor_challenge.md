# Constructor challenge and completed operational repair

6 November 2026. This follows the preserved independent initial report. No new
agents were created. The primary operational result below is an application of
established standard product-port teleportation, not a new PBT theorem.

## 1. A complete offline simulation theorem

Let `Phi:M_a -> M_b` and `Psi:M_a -> M_c` be finite CPTP channels, `a>=2`.
Suppose a supplied physical CP trace-nonincreasing map `S:M_b -> M_c` satisfies

\[
 S\Phi=p\Psi,\qquad 0<p\le1. \tag{1}
\]

The identity is an identity of complete maps, not just matching scalar success
probabilities. The implementation is fixed and memoryless; fresh trials begin
with uncorrelated ancillary systems. Local operations, authenticated classical
herald feedback and forward port-index communication are available. Quantum
storage is ideal during preparation and online use. Unknown input and untouched
reference states may be arbitrary, but are initially independent of the resource
bank and its preparation apparatus. The target protocol's ordinary adaptive
interfaces do not acquire the simulator's port bookkeeping as extra data.

Write `chi_Psi=(id tensor Psi)(phi_a)` and `C_a=2a(a-1)`. For any positive
integers `n,M`, there is a protocol with these properties:

1. Before unknown data arrives, prepare `m=nM` copies of `chi_Psi`. Each copy
   costs `1/p` expected calls to `Phi`, so total expected source calls are `nM/p`.
2. After readiness, arbitrary `n`-slot adaptive use of `Psi`, on unknown and
   referenced inputs, is simulated by a deterministic online operation. Its
   final honest/reference full trace-norm error is at most
   \[
   n\delta_M\le C_a n/M, \tag{2}
   \]
   where `delta_M` is the standard `M`-port identity-channel error.
3. If the full online apparatus environment is retained, including resource
   purifications, discarded ports, measurements and public port transcripts,
   then there exists a fixed environment alignment to a dilation of the ideal
   target protocol, with joint trace distance at most
   \[
   u_{n,M}=\sqrt{1-(1-\delta_M/2)^n}
       \le\sqrt{C_a n/(2M)}. \tag{3}
   \]
   This alignment is a proof comparison, after sufficient environment padding.
   It neither gives the users access to Eve nor requires implementing an
   operation on her registers.
4. Therefore receiver full-norm accuracy `epsilon` requires `M>=C_a n/epsilon`;
   full-environment trace-distance accuracy `u` requires `M>=C_a n/(2u^2)`.
   Primitive source calls are respectively
   `O(a^2 n^2/(p epsilon))` and `O(a^2 n^2/(p u^2))` in expectation.

All quantities count actual source calls. Dependence on `1/p` is explicit; a
polynomial-in-`n` claim does not make `1/p` polynomial in source description
length. The result requires a supplied verified converter; it does not acquire
one from a noisy unknown device or evade the initial report's tomography
obstruction.

The comparator is exact online heralded block simulation with its `p^n`
acceptance. The present operation trades exactness for a prescribed finite
approximation and a much larger offline resource bank. It does not improve
the exact generic block theorem at the same contract.

### Proof: the resource bank and an actual processor

Prepare a maximally entangled `a x a` pair locally, keep one half, send the other
through `Phi`, and apply the success/failure instrument containing `S`. By (1),
the success probability is `p` and the normalized accepted state is exactly
`chi_Psi`. Failure occurs on a freshly prepared pair, never on the future data.
Independent trials give independent accepted states. Stopping after `m` successes
has negative-binomial expectation `m/p`.

This also accounts for the preparation environment. A purified implementation of
the normalized successful map is a Stinespring dilation of `Psi`, because (1)
holds on all inputs and its success effect on the source input is `p I`.
Accepted resources, failure records and stopping history may all be purified.
Their accepted honest marginal is `chi_Psi^tensor m`, independent of the stopping
history. The extra history is input-independent and can be retained in the
environment comparison. Input-independent heralding by itself would not prove
this conclusion; (1) is the needed channel identity.

For each target use, apply standard deterministic port-based teleportation to
the input and `M` independent resource states. The sender's POVM depends only on
`a,M`; Bob keeps the announced output port and discards the others. A finite
exact specification is the square-root measurement on the usual signal states

\[
 \sigma_i=\phi_{A_0A_i}\otimes I_{A_{\ne i}}/a^{M-1},\quad
 \Sigma=\sum_i\sigma_i,\quad
 \Pi_i=\Sigma^{+1/2}\sigma_i\Sigma^{+1/2}+P_{\ker\Sigma}/M.
\]

Here `Sigma^{+1/2}` means the square root of the Moore--Penrose inverse. The POVM
sums to identity. Its matrix size is `a^(M+1)`. Rational signal matrices have
exact algebraic square roots and inverses, so this is a finite constructive
processor, not a claim of a polynomial-size rational processor or practical
generic local compilation.

Because Bob's port selection commutes with applying `Psi` to every receiver
half before the measurement, the implemented receiver channel is exactly

\[
 \Psi_M=\Psi\circ\Gamma_M, \tag{4}
\]

where `Gamma_M` is standard PBT's approximate identity. Equation (4) holds for
non-covariant targets and arbitrary references. The target need not admit
ordinary one-Choi teleportation simulation. Standard PBT gives

\[
 \delta_M=\|\Gamma_M-id\|_\diamond
       =2[1-F_e(\Gamma_M)]\le C_a/M.
\]

The receiver error (2) follows by an `n`-term telescoping/contractivity argument
through the fixed adaptive interleavers. Interleavers can use all honest
quantum/classical records permitted by the original protocol. Extra simulator
communication is paid separately below.

### Full environment: why a square-root bound is enough

Standard `Gamma_M` is depolarizing. Its Weyl random-unitary representation has
identity-branch probability `w0=F_e(Gamma_M)=1-delta_M/2`. A valid dilation of
`Psi_M` applies the Weyl error, records its label coherently in a new environment,
then applies a Stinespring isometry of `Psi`.

In the purified `n`-slot protocol, the all-identity Weyl branch is exactly the
ideal target dilation multiplied by `w0^(n/2)`. This is true with adaptive
interleavers because each conditional Weyl branch is a scalar times an
isometry and its probability is independent of the slot input. The other error
patterns carry orthogonal environment labels. For every purified initial
input/reference state, the overlap with the ideal dilation padded by zero error
labels is `w0^(n/2)`. Pure-state trace distance is consequently
`sqrt(1-w0^n)`, proving (3); mixed states follow by purification and partial trace.

The actual PBT apparatus and this convenient Weyl dilation are dilations of the
same receiver channel (4). Stinespring uniqueness aligns them by a fixed
environment partial isometry, extendible after padding. It acts on the full
apparatus environment; no honest target-interface system is moved. This proves
a final joint-state comparison, not physical control of Eve. Discarding any
trusted portions of that environment can only improve the bound.

### Precise privacy consequence and limitation

In the fixed memoryless, passive-complement eavesdropper model with authenticated
public communication, apply the comparison to a target key protocol and retain
all source/preparation/port environments and public records on Eve's side.
Arbitrary later processing by Eve preserves the bound. The ideal comparison
includes a fixed Eve-side simulation/alignment and independent preparation
history. If the target final key state satisfies

\[
 D(\rho^{id}_{KE},\gamma_K\otimes\rho^{id}_E)\le s,
\]

then the actual simulated protocol satisfies the safe bound `s+2u_{n,M}` in
this same actual-marginal definition. One factor `u` compares the joint states,
and the other compares their Eve marginals. The honest output correctness
probabilities also change by at most the joint trace distance. A definition
allowing an arbitrary ideal Eve state can omit the second factor.

This is not a claim about an actively modified source device, correlated
non-memoryless noise, side-channel leakage from trusted input registers, or a
new universally composable simulator against arbitrary interactions during
resource preparation. The theorem's joint final-state comparison is the exact
security statement established here. The external unknown input/reference is
fresh relative to the resource bank; allowing initial adversarial correlations
with that bank would change the channel model.

## 2. Noisy resources and a finite confidence budget

Let the actual source/instrument be fixed memoryless CP operations with

\[
 \|\widetilde S\widetilde\Phi-p\Psi\|_\diamond\le\eta<p.
\]

For one offline Choi trial let `q` be its actual success probability and `omega`
its normalized successful state. Then

\[
 q\ge p-\eta=:p_-,\qquad
 \|\omega-\chi_\Psi\|_1\le e:=\min\{2,2\eta/(p-\eta)\}.
\]

Indeed the unnormalised states differ by at most `eta`, their traces differ by
at most `eta`, and normalization costs at most another `eta/q`. The accepted
state need not itself be a Choi state of a TP map; that is unnecessary. The
PBT processor with any independent density-operator program is CPTP.

Contractivity and a product-state telescoping bound give the safe receiver
full-norm error

\[
 \varepsilon_{rec}\le\min\{2,C_a n/M+nM e\}. \tag{5}
\]

For the environment comparison, purifications of `omega` and `chi_Psi` can be
chosen with root overlap at least `1-e/2` (the state case of the verified
Stinespring/Bures bound). Product purifications therefore differ in trace
distance by at most `sqrt(nM e)`. Uhlmann/Stinespring alignment is only on the
preparation environment, not the stored resource registers or the target input.
Running the same online apparatus and interleavers cannot increase that
distance. Together with (3),

\[
 u_{total}\le\min\{1,\sqrt{C_a n/(2M)}+\sqrt{nM e}\}. \tag{6}
\]

This uses independent trials and fixed memoryless implementation. Marginal
one-use error bounds without those assumptions would not justify the product
resource bank or (5)--(6).

An explicit conservative design achieving receiver error at most `epsilon` and
joint distance at most `u` chooses

\[
 M\ge\max\{2C_a n/\epsilon,\;2C_a n/u^2\},\qquad m=nM,
\]
\[
 \eta\le\min\left\{\frac{p\epsilon}{4m+\epsilon},
                    \frac{p u^2}{8m+u^2}\right\}. \tag{7}
\]

The two terms in each error budget receive half the allocation. In particular,
accuracy of the offline conversion is a paid requirement, not a uniform
noise-independent benefit.

### Fixed stopping cap

Given `0<zeta<1`, choose integer `L>=1` with `2^-L<=zeta`. Make at most

\[
 T=\left\lceil\frac{2m+8L}{p_-}\right\rceil \tag{8}
\]

fresh trials and keep the first `m` successes. With `X~Binomial(T,q)`, its mean
`mu>=2m+8L`. Thus `Pr[X<m]<=Pr[X<mu/2]<=exp(-mu/8)<=2^-L<=zeta`.
The uncapped mean is `m/q<=m/p_-`; a capped run uses at most `T` source calls.
Readiness is decided before accepting unknown data. On failure the experiment
never touches that data; it is not retried. Conditioning on readiness does not
alter the accepted product state, since the independent accepted state is
independent of success locations and stopping history.

If comparing to a target that never aborts, the preparation shortfall adds at
most `2zeta` to a full receiver norm bound, or `zeta` to joint trace distance.
If abort is part of the declared protocol, readiness has probability at least
`1-zeta` and the conditional bounds (5)--(6) apply. No zero-failure finite
preparation claim is made.

## 3. Resource ledger and interpretation

At most `T` backward herald bits suffice (one per trial), plus `n ceil(log2 M)`
forward port-index bits. Preparing all resources before input arrival stores
`m` Alice systems of dimension `a` and `m` Bob systems of dimension `c`, namely
`m log2 a` and `m log2 c` qubits up to register rounding. A trial also uses
its source/instrument ancillas; all actual environment registers are retained
for the security statement. The PBT sender measurement has dimension
`a^(M+1)`. Local synthesis, storage duration/decoherence and gate complexity
are not free experimental resources merely because source-call counting is
polynomial. Exact algebraic full-matrix construction may be enormous.

`../constructor/pbt_budget.py` is an exact rational budget compiler and
`pbt_budgets.json` its executed output. With `a=2,n=2,p=1/7`, receiver tolerance
`1/4`, joint distance tolerance `1/4` and shortfall `1/1000`, it returns
`M=64`, `m=128`, expected source cost `896`, cap `2352`, twelve forward bits,
and at most `2352` backward bits. The receiver bound is `1/8` and joint bound
`1/4`. The generic full POVM already has dimension `2^65`.

For `n=10`, both tolerances `1/100`, the same source has `M=200000`, two
million Choi resources, fourteen million expected source calls, cap `28000560`
and 180 forward bits. This deliberately exposes why a mathematical polynomial
source-use improvement is not a present practical advantage. The N1690 click
probability and noisy split-budget examples are also computed in that JSON.

Same-profile classes have the converter (1), so they admit this approximate,
paid, finite-block, assisted operational interconversion. Ordinary unassisted
capacity equality does not follow: feedback is used, and the source cost grows
with desired block length/accuracy. An exact generic finite-port simulation is
not supplied. Teleportation-covariant targets retain the stronger special exact
`n/p` source-use simulation already described in N1698.

## 4. Primary imports and priority

The standard PBT statements used are Pirandola--Laurenza--Lupo--Pereira,
[arXiv:1803.02834](https://arxiv.org/html/1803.02834), Lemma 1, Eq. (9), and
Lemma 2: product Choi resources, depolarizing identity simulation, its diamond
bound and adaptive peeling. The article was inspected and cached. The
offline heralded resource bank and explicit budgets are the present
application of those established operations. There is no claim to invent
channel-state simulation or PBT stretching.

The environment uniqueness/Bures comparison is Kretschmann--Schlingemann--Werner,
[arXiv:0710.2495v1](https://arxiv.org/html/0710.2495), Theorem 1, Eqs. (6)--(7),
with sufficiently padded common dilations. It permits choosing aligned
dilations; it does not assert arbitrary unaligned environments are close.
The sharper exact-resource estimate (3) is proved directly from the Weyl
identity branch, rather than asserted from receiver closeness alone.

Broader searches found older programmable-channel/PBT literature and recent
multiport/finite-memory work. No historical-priority clearance for this
particular combination is established. The proper description is a complete
operational application with explicit physical costs and scope.

Executed numerical interface checks in `check_pbt_small.py` use `a=2`,
`M=1,2,3` and a non-teleportation-covariant amplitude-damping target. They
check POVM completeness, the depolarizing form of `Gamma_M` and the complete
matrix-unit identity `Psi_M=Psi Gamma_M`, with errors below `8e-16`.
`pbt_small_checks.json` explicitly labels them numerical diagnostics, not a
proof of the cited general theorem or the large-budget processor.

## 5. Challenge of the tracial infinite-output criterion

I read `principal_tracial_greatest_criterion.md` and
`principal_infinite_binary_boundary.md`. I found no substantive counterexample
to the stated **tracial** theorem. The important steps survive independent
checking: projection pinching preserves the state on the algebra because the
state is tracial; simultaneous trace-norm saturation forces the trace-class
density to commute with every generator; its finite-dimensional positive
eigenspaces give separating normal finite-dimensional representations. The
central-kernel argument therefore forces a countable product of finite matrix
factors. Blockwise recovery in the converse is trace-norm contractive despite
unbounded individual inverse weights, so no global bounded inverse is needed.
The moment/C*-norm argument uses faithfulness, not a fictitious spectral floor
for a trace-class density on an infinite-dimensional space.

This check does not extend the statement to nontracial invariants. There,
pinching need not preserve the invariant state, and finite greatest channels
can already have densities that do not commute with their algebra. Nor is an
abstract `L1(M,tau)` output automatically a density-operator device on a
separable Hilbert space. These distinctions in the principal's statement are
necessary.

### Explicit binary epsilon-greatest repair

The binary diffuse obstruction has a constructive approximate replacement.
Let the common spectral-state measure be `mu` on `[0,1]`, with mean `1/2`.
Partition `[0,1]` into `N=ceil(1/epsilon)` intervals of length at most
`epsilon`, discard zero-mass cells, and set

\[
 w_j=\mu(I_j),\qquad \lambda_j=w_j^{-1}\int_{I_j}x\,d\mu(x).
\]

Define the finite classical channel `G_P` with output probabilities
`G_P(|0><0|)_j=2w_j lambda_j`,
`G_P(|1><1|)_j=2w_j(1-lambda_j)`, killing coherences. It is TP because the
conditional means preserve the first moment.

For **every** physical class member `F`, with normalized effect `A_F`, density
`Omega_F` and `P_j=1_(I_j)(A_F)`, define the preparation states

\[
 \sigma_j^F=\Omega_F^{1/2}P_j\Omega_F^{1/2}/(2w_j).
\]

The measure-prepare decoder `R_F` using these states satisfies

\[
 \|F-R_FG_P\|_\diamond\le\epsilon. \tag{9}
\]

Indeed, the two output-state errors are opposite and the channel kills input
coherences, so its diamond norm is precisely the trace norm of either error.
The latter is at most
`Tr Omega_F |A_F-sum_j lambda_j P_j|`
`=2 sum_j integral_(I_j)|x-lambda_j|dmu`.
A variable supported in an interval of length `h` has mean absolute deviation
from its mean at most `h/2` (for instance by the variance bound `h^2/4`). This
proves (9), uniformly over all class members and output dimensions.

There is even an epsilon-greatest member **inside the exact class**, though
its output is still infinite. For any one representation form
`Omega_P=sum_j P_j Omega P_j` and
`E_P(X)=Omega_P^(1/2) T(X) Omega_P^(1/2)`.
It has the identical exact profile, since `Omega_P` represents the same state
on the commutative algebra. Measuring its orthogonal blocks `P_j` gives
exactly `G_P`. Hence every `F` in the class is within epsilon of a
deterministic postprocessing of `E_P`. Thus exact nonexistence of a greatest
member coexists with a uniform finite classical epsilon-envelope and an
epsilon-greatest exact-class lift.

`G_P` itself need not have the exact profile: quantization changes `mu`.
Its `N` outcomes are an operational approximation, not a disguised exact
finite realization of a diffuse measure. The construction assumes access to
the cell masses/means and target spectral projections; it gives no acquisition
or efficient infinite-operator preparation claim. Sequentially replacing `n`
uses adds at most `n epsilon` in full trace norm.

This is the explicit commutative/binary case of the principal's subsequently
proposed hyperfinite-filtration repair. A supplied finite-dimensional
filtration and a convergence modulus are additional data in the general
noncommutative case. No converse equating approximate envelopes with
injectivity/hyperfiniteness is asserted. Approximation of classical
experiments by finite partitions is established statistical machinery; the
result here instantiates it at the exact profile-class/dilation boundary.

## 6. Checked routine finite-dimensional capacity-spectrum corollary

I also checked the principal's proposed shape statement. For `E~F`, the
flagged channel `(1-t)E directsum tF` has normalized generators
`T_E(X) directsum T_F(X)` for `0<t<1`. The generated algebra is the graph of
the labelled state-preserving star-isomorphism, and its state is
`(1-t)tau+t tau=tau`. Endpoints are compressed to their effective supports.
Thus the entire flagged line remains in the class.

The standard Bell dilation approaches a replacer inside every finite class:
for output dimension `b`, let `P_b=|phi_b><phi_b|`,
`S_u=uI_(b^2)+P_b`,
`kappa_u=[b^2 u^2+2u+1]/b`, and

\[
 F_u(Y)=\kappa_u^{-1}S_u(Y\otimes I_b)S_u.
\]

For `u>0`, `F_u` is TP because `Tr_aux S_u^2=kappa_u I_b`; invertible
congruence and the same partial trace show it preserves all complete maximal
profiles of arbitrary pairs. As `u->0`, `F_u(Y)->Tr(Y)P_b`. Therefore
`F_u Gamma~Gamma` and its capacity approaches zero by finite-dimensional
capacity continuity. The greatest representative supplies the attained
maximum `Q(Gamma)`.

Capacity is continuous along each fixed finite-dimensional padded flagged
line. The intermediate-value theorem gives every value between capacities
of any two members. Consequently the class spectrum is `{0}` if its greatest
capacity is zero, and otherwise either `[0,Q(Gamma)]` or `(0,Q(Gamma)]`.
Which alternative occurs is exactly the remaining zero-attainment question;
finite-broadcast criteria are sufficient in their accepted scope but should
not be silently promoted into a general zero-capacity characterization.
Rational parameters give dense values/closures, not a rational realization
of every real capacity, when the original class has rational descriptions
and the rational greatest-channel compiler is used as its base. No rational
representative is assumed for an arbitrary irrational profile class.
This is a routine consequence of existing profile,
Bell-dilution and capacity-continuity capital, not the main new mechanism.

The primary continuity import was checked directly: Leung--Smith,
[arXiv:0810.4931v2](https://arxiv.org/html/0810.4931), Corollary 14 assumes
finite common output dimension and diamond convergence, and proves continuity
of ordinary quantum capacity including rank-changing endpoints. A fixed
padded flagged output and the fixed `b^2` Bell-dilation output meet these
hypotheses. No infinite-output capacity continuity is imported.

## 7. Same-class epsilon-greatest lifts for a hyperfinite tracial filtration

This strengthens the principal's finite-dimensional envelope construction.
Assume the tracial infinite-output invariant `(M,T,tau)` and a supplied increasing
sequence of unital finite-dimensional subalgebras `M_k subset M`, with
tau-preserving normal expectations `E_k`, whose union is L2(tau)-dense. Fix any
one trace-class output representation `Omega` of `a tau` on `M`.

Average over the compact unitary group of `M_k`:

\[
 \Omega_k=\int_{U(M_k)}u\Omega u^*\,du,\qquad
 G_k(X)=\Omega_k^{1/2}T(X)\Omega_k^{1/2}. \tag{10}
\]

The integral is a trace-norm Bochner integral of a norm-continuous compact-group
orbit. It is positive, trace class, has trace `a`, is faithful, and commutes with
`M_k`. Faithfulness follows because the integrand's quadratic form is strictly
positive on every nonzero vector, including in a neighbourhood of the identity.
For every `Z in M`, traciality gives

\[
 \operatorname{Tr}\Omega_k Z
 =a\int\tau(u^*Zu)\,du=a\tau(Z).
\]

Consequently `G_k` is CPTP and has the **same exact complete profile** as the
original channel: its normalized map is still `T`, and its state on the full
generated algebra is still `tau`. This requires no approximation of that full
algebra or its ordered moments.

Write the finite algebra in its output representation as
`M_k=directsum_j(M_nj tensor I_Kj)`, with finite many blocks; the multiplicity
spaces `K_j` may be infinite. Its tracial weights are `p_j>0`. Commutation gives

\[
 \Omega_k=\bigoplus_j I_{n_j}\otimes\omega_j,\qquad
 \operatorname{Tr}\omega_j=a p_j/n_j.
\]

The normal CPTP block partial-trace map

\[
 S_k(Y)=\bigoplus_j\operatorname{Tr}_{K_j}(P_jYP_j)
\]

has finite-dimensional output `directsum_j C^nj`. It compresses `G_k` exactly
to the principal's finite envelope `Gamma_k`, whose normalized input is
`E_k T` and whose density on block `j` is `a p_j I_nj/n_j`.
Pairing with any `Y in M_k` proves the identity directly:

\[
 \operatorname{Tr}[S_kG_k(X)]Y
 =a\tau(T(X)Y)=a\tau(E_kT(X)Y)
 =\operatorname{Tr}\Gamma_k(X)Y.
\]

For any exact-class member `F`, the principal's finite-block decoder `R_k^F`
satisfies

\[
 R_k^F S_k G_k(X)
 =\Omega_F^{1/2}\pi_F(E_kT(X))\Omega_F^{1/2},
\]

where `pi_F` is the normal labelled state-preserving isomorphism. For `B in M`,
Schatten Cauchy--Schwarz and traciality give the uniform bound

\[
 \|\Omega_F^{1/2}\pi_F(B)\Omega_F^{1/2}\|_1
 \le\|\Omega_F^{1/2}\pi_F(B)\|_2\|\Omega_F^{1/2}\|_2
 =a\|B\|_{2,\tau}.
\]

For an arbitrary referenced input state, expand it in the `a x a` input matrix
units; each reference block has trace norm at most one. Triangle inequality
therefore yields

\[
 \|F-R_k^F S_kG_k\|_\diamond
 \le a\sum_{i,j=1}^a\|T(E_{ij})-E_kT(E_{ij})\|_{2,\tau}
 =:\varepsilon_k\longrightarrow0. \tag{11}
\]

The limit follows because `E_k` are the increasing L2 orthogonal projections
and the union is L2-dense. The bound is independent of the chosen class member
and its output dimension. Thus **for every epsilon>0 this exact profile class
contains an epsilon-greatest normal trace-class-output member**. Its finite
`Gamma_k` compression is an external approximate envelope. The envelope itself
can lose the exact profile; its lifted `G_k` retains it exactly.

The result covers the binary finite-partition lift as the commutative case.
It is consistent with no exact greatest member for diffuse hyperfinite algebras:
`k` depends on epsilon and no limiting trace-class density commuting with the
whole algebra is asserted. Output of `G_k` stays on the original separable,
potentially infinite Hilbert space. This is conditional on the supplied
hyperfinite filtration; no effective convergence rate, computable acquisition,
practical preparation or converse characterizing hyperfiniteness/injectivity
is claimed.
