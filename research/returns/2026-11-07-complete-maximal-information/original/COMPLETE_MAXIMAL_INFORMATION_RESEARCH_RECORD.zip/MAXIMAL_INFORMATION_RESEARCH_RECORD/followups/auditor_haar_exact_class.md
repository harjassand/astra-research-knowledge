# Audit addendum: approximate greatest members inside the exact class

6 November 2026. Independent check of the constructor's Haar-averaging repair.
No additional agents used. This extends the filtration audit in
`auditor_challenge.md`, Section 9. **Status: valid at the stated tracial,
supplied-hyperfinite-filtration scope.** No hidden faithfulness, normality or
trace-identity defect found.

## Statement with representations explicit

Let E:M_a→S_1(H) have faithful identity output Omega, bounded normalized
map T, generated von Neumann algebra M, and faithful normal tracial state
tau(A)=Tr(Omega A)/a. Let M_k be increasing finite-dimensional unital
subalgebras with L2(tau)-dense union and tau-preserving expectations E_k.

There exist channels E^(k) in the **same exact complete-profile class** and
normal CPTP maps D_(k,F) to every target class member F such that

\[
\|F-D_{k,F}E^{(k)}\|_\diamond\le\varepsilon_k,
\qquad
\varepsilon_k=a\sum_{i,j=1}^a
 \|T(E_{ij})-\mathbb E_kT(E_{ij})\|_{2,\tau}\longrightarrow0.
\]

The bound is uniform over F and its separable output dimension. The source
E^(k) may retain the infinite output H. No finite-dimensional exact-class
realization, effective rate, or ordinary-capacity conclusion is asserted.

## Haar averaging

The unitary group U(M_k) is compact. Its representation on H is operator-
norm continuous, so u↦u Omega u* is trace-norm continuous. Hence

\[
\Omega_k=\int_{U(M_k)}u\Omega u^*\,du
\]

is a well-defined Bochner integral in S_1(H), positive of trace a. It is
faithful: for every nonzero v, the continuous integrand
<u*v,Omega u*v> is strictly positive, and hence has positive Haar integral.
Haar invariance gives Omega_k in M_k'. For all A in M,

\[
\operatorname{Tr}(\Omega_kA)
=a\int\tau(u^*Au)du=a\tau(A).
\]

The last equality uses traciality on all M, not just on M_k. Thus

\[
E^{(k)}(X)=\Omega_k^{1/2}T(X)\Omega_k^{1/2}
\]

is CPTP and has exactly the original normalized map, generated algebra and
state. Its joint output is faithful Omega_k, so effective-support and
bounded-normalized-sandwich profile definitions apply without a bounded
inverse of Omega_k.

## The finite decoder and the trace identity

Decompose the concrete finite algebra as

\[
H=\bigoplus_j(\mathbb C^{n_j}\otimes K_j),\qquad
M_k=\bigoplus_j(M_{n_j}\otimes I_{K_j}).
\]

There are finitely many j, but the multiplicity spaces K_j may be infinite.
Commutation implies Omega_k=directsum_j I_(n_j) tensor omega_j, with
omega_j positive faithful trace class. Put

\[
h_j=\operatorname{Tr}\omega_j
=\frac{a\tau(P_j)}{n_j}>0.
\]

Define S_k:S_1(H)→S_1(directsum_j C^(n_j)) by block pinching followed by
partial trace over K_j. It is normal CPTP: its adjoint embeds bounded
block matrices as directsum_j A_j tensor I_(K_j), a normal unital
*-homomorphism. Infinite multiplicities cause no trace-preservation defect.

For a test A in M_k, cyclicity of the ordinary trace and [Omega_k,A]=0 give

\[
\operatorname{Tr}[E^{(k)}(X)A]
=\operatorname{Tr}[\Omega_kT(X)A]
=a\tau(T(X)A)
=a\tau(\mathbb E_kT(X)A).
\]

The final equality is the tau-preserving expectation's pairing property.
These identities for all finite block tests prove exactly

\[
S_kE^{(k)}(X)=\Lambda_k(X)
=\bigoplus_jh_j(\mathbb E_kT(X))_j.
\]

This is the key trace identity; unweighted partial trace of T(X) alone would
not be the correct formula in a general concrete representation.

## Target simulator and uniform error

For a target F let pi identify the normal invariant algebra and let Omega_F
be its identity output. The finite block simulator

\[
R_{k,F}(Y)=\sum_jh_j^{-1}\Omega_F^{1/2}
 \pi_j(Y_{jj})\Omega_F^{1/2}
\]

is normal CPTP: each block is CP and has output trace Tr Y_jj because
Tr(Omega_F pi_j(Y))=h_j Tr Y. Therefore D_(k,F)=R_(k,F)S_k is normal
CPTP on the **whole** source output space, and

\[
D_{k,F}E^{(k)}(X)
=\Omega_F^{1/2}\pi(\mathbb E_kT(X))\Omega_F^{1/2}.
\]

For B in M, Schatten Holder gives

\[
\|\Omega_F^{1/2}\pi(B)\Omega_F^{1/2}\|_1
\le\|\Omega_F^{1/2}\|_2\|\pi(B)\Omega_F^{1/2}\|_2
=a\|B\|_{2,\tau}.
\]

Expand an arbitrary referenced input in matrix units E_ij. Each reference
block has trace norm at most the whole input trace norm, so the triangle
inequality gives the stated diamond bound. It depends only on the fixed
invariant and filtration, not on F. L2-density makes all finitely many
matrix-unit errors tend to zero.

If a preceding theorem calls Gamma_k the *minimal canonical* channel for
E_kT, its generators may span a proper subalgebra of M_k. Compose its
deterministic converter to the full M_k lift Lambda_k before R_(k,F).
The present exact-class construction already decodes directly to Lambda_k
and needs no minimal-representation assertion.

## Scope and consistency

The strengthened conclusion is genuinely inside the exact class, unlike
the earlier finite external approximants. It is consistent with absence of
an exact greatest member for diffuse M: the faithful trace-class averages
Omega_k need not have a trace-norm-convergent subsequence, and no limiting
faithful compact density commuting with all M is supplied.

The construction assumes the filtration and expectations. Effective channel
descriptions, output dimensions and error moduli require additional supplied
data. It constructs new exact-class source channels from their descriptions;
it is not a deterministic black-box upgrade of an original device. General
nontracial infinite-output greatest existence remains open.
