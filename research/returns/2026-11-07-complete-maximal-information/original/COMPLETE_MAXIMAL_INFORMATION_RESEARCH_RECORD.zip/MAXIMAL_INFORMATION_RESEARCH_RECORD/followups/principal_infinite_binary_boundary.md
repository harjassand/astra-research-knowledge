# Binary profile classes on infinite quantum outputs: an exact greatest-existence criterion

Principal construction after reading the machinery researcher's independently suggested infinite-output boundary. This proof is newly written here; priority remains to be checked against Matsumoto/Hiai reverse tests. It is not a consequence assumed from the finite N1698 theorem.

## Theorem I (candidate complete proof, awaiting independent challenge)

Let E:M_2 -> T(H) be a normal Schrödinger channel on a separable Hilbert space that kills input off-diagonal matrix units. Write its outputs as rho_0,rho_1>=0, Tr rho_i=1, Omega=rho_0+rho_1, and compress to supp Omega so Omega is faithful trace class (Tr Omega=2). Since 0<=rho_0<=Omega, the densely defined congruence extends to a bounded positive contraction A with rho_0=Omega^(1/2) A Omega^(1/2), rho_1=Omega^(1/2)(I-A)Omega^(1/2). Define the probability measure mu(B)=Tr[Omega 1_B(A)]/2 on [0,1]. It has mean1/2.

Define complete maximal profiles via the bounded normalized functional calculus and faithful referenced input baselines; equivalently use maximal f perspectives on effective support, with finite values when specified. For RLD, its quadratic form can be defined by the bounded normalized sandwich, or by the trace of the closed positive quadratic form; these agree for the dominated finite-input outputs here. Both arguments are outputs of the same channel.

Then:
1. E's complete RLD/maximal profile equality class among all channels M2->trace-class on separable outputs consists exactly of binary measure-prepare channels with the same mu.
2. This class has a greatest member under normal deterministic quantum output processing iff mu is purely atomic (countably many atoms).
3. If mu=sum_j mu_j delta_(lambda_j), the greatest representative is the classical-output channel on ell2(J):
 Gamma(|0><0|)=diag(2mu_j lambda_j), Gamma(|1><1|)=diag(2mu_j(1-lambda_j)), Gamma(offdiagonal)=0.
 If mu has a diffuse component, no greatest separable trace-class-output channel exists, even though each binary Bayes decision problem separately has a maximizer in the class.

This preserves N1698's finite theorem: finite output forces finite atomic mu; the new obstruction is outside that scope. A classical nonatomic output algebra L-infinity(mu), in a generalized statistical-experiment category, DOES realize the ideal spectral reverse test; the no-go is for normal density-operator channels on separable Hilbert output, not all operator-algebraic experiments.

## Proof of profile classification

For a referenced input, the normalized output is
 T_E,R(X)=A tensor X_00+(I-A) tensor X_11.
Functional calculus in W*(A) tensor M_R and physical partial trace integrate the resulting matrix-valued function against 2mu. Equal mu therefore implies equality of every complete maximal perspective (and RLD).

Conversely if F has the same RLD profile, choose baseline I_2/2 and tangent sigma_x or sigma_y (reference1). E's quadratic form is zero, so F(sigma_x)=F(sigma_y)=0. Positivity of the RLD form forces this: its normalized bounded sandwich has faithful weight and is a positive square; zero faithful weight implies zero. Thus F also kills coherences. Put B=2A-I. Baseline rho_s=diag(s,1-s), tangent H=diag(1,-1), for s near1/2 gives
 g_E(rho_s,H)=2 int B(x)^2/[1/2+(s-1/2)B(x)] dmu(x)
 =4 sum_(n>=0) [-2(s-1/2)]^n int B(x)^(n+2) dmu(x).
Mass and first moment are already fixed (int1=1,intB=0). Equality of g in an interval identifies all moments of the probability measure on compact[-1,1]. Polynomial density in C([-1,1]) identifies mu. This is the classical compact moment argument; no infinite-reference cutoff or free-algebra compiler is imported.

## Proof of necessity of atomicity

For any prior t in(0,1),
 D_t(E)=||(1-t)rho_0-t rho_1||_1=||Omega^.5(A-tI)Omega^.5||_1
 <=Tr Omega |A-tI| =2 int |x-t| dmu(x).
This is trace-norm triangle inequality after splitting positive/negative parts of A-t.

Let P=1_(t,1](A) and Omega_t=P Omega P+(I-P)Omega(I-P). Omega_t is positive faithful trace class, has the same spectral-state measure on A, and its two outputs defined by the same A are trace-one states. Thus E_t lies in the same complete-profile class. Omega_t commutes with P, so the positive and negative congruenced parts have orthogonal supports and D_t(E_t)=2int|x-t|dmu. Each prior's upper bound is attained by a class member.

Suppose G were greatest in the class, with its own Omega_G,A_G realizing mu. Output processing contracts trace norm, so it must attain the upper bound for every t. Choose t not an atom of mu. Faithfulness implies 1_{t}(A_G)=0. Equality in ||X-Y||_1<=TrX+TrY for positive trace-class X,Y is equivalent to XY=0 (their supports are orthogonal); a proof follows by the Helstrom optimizing spectral projection and zero positive trace terms. Apply this to
 X=Omega_G^.5(A_G-t)_+Omega_G^.5,
 Y=Omega_G^.5(t-A_G)_+Omega_G^.5.
It gives (A_G-t)_+ Omega_G(t-A_G)_+=0, first by density of range Omega_G^.5, then by boundedness of the factors. Restrict to spectral subspaces at distance>=epsilon from t, invert the positive bounded-away-from-zero factors on those subspaces, and take epsilon down0. Therefore
 1_(t,1](A_G) Omega_G 1_[0,t)(A_G)=0.
There is no equality atom, hence Omega_G commutes with 1_(t,1](A_G).

The non-atoms contain a dense set (there are at most countably many atoms). Spectral strong limits give commutation with every spectral projection, hence with A_G. A positive faithful trace-class Omega_G has a countable orthogonal decomposition into finite-dimensional positive-eigenvalue spaces spanning H. A_G preserves each and can be diagonalized on each. Consequently A_G and Omega_G have a common countable eigenbasis and their spectral measure mu is purely atomic. Contradiction if mu has any diffuse component.

## Proof of sufficiency

Let mu be countably atomic, with weights mu_j>0 at distinct lambda_j. The displayed Gamma is CPTP and has normalized output diag(lambda_j) and measure mu. For any class member, let P_j=1_{lambda_j}(A). Faithfulness and full mu mass imply sum_j P_j=I strongly. Prepare the trace-one state
 sigma_j=Omega^.5 P_j Omega^.5/(2mu_j)
conditioned on classical output j. The normal measure-prepare channel R(Y)=sum_j <j|Y|j> sigma_j is CPTP (trace-norm convergence for positive inputs; linear extension). Its composition with Gamma has outputs rho_0,rho_1 and kills coherences. Thus Gamma dominates every member and is itself in the class.

## Explicit diffuse fixture

H=L2([1/4,3/4],nu), nu normalized Lebesgue measure. Let e_n(x)=exp(4pi i n(x-1/4)), n in Z, the Fourier ONB with |e_n(x)|=1. Set
 Omega=sum_(n in Z) (2/3)2^(-|n|)|e_n><e_n|,
 A=M_x.
Omega is positive, faithful, trace class, trace2. For bounded f,
 Tr Omega f(A)=sum c_n int f dnu=2int f dnu.
Thus mu=nu is diffuse with mean1/2. The states rho0=Omega^.5 A Omega^.5 and rho1=Omega^.5(I-A)Omega^.5 are faithful trace-one density operators; each is >=Omega/4 and <=3Omega/4. Their likelihoods are uniformly comparable even though no trace-class state can have an infinite-dimensional uniform eigenvalue floor. The binary channel has no greatest member within its complete profile class.

## Limitations and priority test

This is an existence/nonexistence theorem for fixed finite input and separable infinite quantum output. It does not give a physical laboratory channel or efficient preparation/sampling of the Fourier fixture. It does not disprove existence of a greatest generalized commutative experiment on L-infinity(mu); indeed the spectral reverse test supplies that larger-category object. Primary precedents Matsumoto optimal reverse tests and Hiai general-von-Neumann maximal divergences may absorb much of the characterization; exact title/theorem/priority checking still required. General noncommutative infinite-output greatest existence remains open here.
