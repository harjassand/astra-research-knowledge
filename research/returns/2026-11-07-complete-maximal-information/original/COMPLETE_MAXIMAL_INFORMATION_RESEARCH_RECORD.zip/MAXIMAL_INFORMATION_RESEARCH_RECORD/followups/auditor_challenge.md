# Hostile challenge audit

6 November 2026. Written after all initial reports were saved and the principal
explicitly started the challenge phase. The original `../initial/auditor.md`
is preserved. No additional agents were used.

## Adjudication

The principal's finite physical-probe theorem, effective Holder application,
generic rigidity, upper-semicontinuous resource ceiling and lower-noise
envelope survive mathematical audit. Leung--Smith classical continuity is
Corollary 13 and quantum continuity is Corollary 14. The infinite binary-output
atomicity criterion also survives; the tracial von Neumann generalization
survives subject to the normal-isomorphism argument supplied below.

The rational witness compiler needs single-letter breadth-first word closure
and a univariate grid for its polynomial bit-time claim. It does not supply a
physical divergence oracle. The fixed-stratum Lipschitz theorem below is a
map from channel Choi data to a concrete greatest lift; it is not a Lipschitz
inverse from noisy profile data to a minimal representation.

The no-least-member construction must be credited as an order corollary of
N1708's already-visible general-dimensional Bell filter and excluded pure-
replacer endpoint. The alternative GNS construction in my initial report is
an independent derivation of that existing shrinking mechanism, not a new
resource-spectrum result.

## 1. Explicit Lipschitz greatest lifts on conditioned word-span strata

Fix contractive Hermitian input generators and a fixed list W of k words of
length at most ell. Let V_E have columns vec(w(T_E(H))) for w in W. Suppose
E,F:M_a→M_b are CPTP, Omega>=lambda I for both, W spans their entire generated
algebras, and sigma_min(V_E),sigma_min(V_F)>=s>0. Thus the algebras have
dimension exactly k. These are structural promises, not conclusions from
arbitrary finite noisy data.

Write delta=||J_E-J_F||_F and define

\[
K_T=\sqrt a(\lambda^{-1}+a\lambda^{-2}),\quad
K_V=\ell\sqrt{kb}K_T,\quad K_\Pi=2K_V/s,
\]
\[
K_Z=\sqrt a+aK_\Pi,\qquad
K_C=K_Z/(2\lambda)+a/(2\lambda^{3/2}),
\]
\[
K_\Gamma=(a/\lambda)\sqrt{ab}+2\sqrt{a/\lambda}K_C.
\]

Then the concrete greatest lifts in the same b-dimensional output space obey

\[
\boxed{\|\Gamma_E-\Gamma_F\|_\diamond\le K_\Gamma\delta.}
\]

This covers proper algebras, which may move as subspaces. A fixed
non-coordinate output support can first be compressed; changing support is
outside this stated promise.

Proof. For A,B>=lambda I, the square-root difference X solves
A^(1/2)X+XB^(1/2)=A-B. Its integral solution gives
||A^(1/2)-B^(1/2)||<=||A-B||/(2sqrt(lambda)). The identity
A^(-1/2)-B^(-1/2)=A^(-1/2)(B^(1/2)-A^(1/2))B^(-1/2) gives constant
1/(2lambda^(3/2)) for inverse square roots. No commutation is used.

Choi contraction gives ||Delta Omega||_F<=sqrt(a)delta and
||Delta E(H_i)||<=sqrt(a)delta. Since Tr Omega=a and ||E(H_i)||<=a,
expanding the two inverse-square-root congruences yields
||Delta T(H_i)||<=K_T delta. UCP contractivity and telescoping words give
||V_E-V_F||<=||V_E-V_F||_F<=K_V delta.

The trace-preserving expectation Pi_E onto A_E is the Hilbert--Schmidt
projection V_E V_E^+. Directly,

\[
\Pi_E-\Pi_F=(I-\Pi_F)\Pi_E-\Pi_F(I-\Pi_E).
\]

For example (I-Pi_F)Pi_E=(I-Pi_F)(V_E-V_F)V_E^+, with norm at most
K_V delta/s; the other term has the same bound. Consequently
||Pi_E-Pi_F||_(2→2)<=K_Pi delta.

Set Z_E=Pi_E(Omega_E). Positivity/unitality imply lambda I<=Z_E<=aI,
and Hilbert--Schmidt contraction gives ||Z_E-Z_F||<=K_Z delta. For
C_E=Z_E^(1/2)Omega_E^(-1/2), the square-root bounds give
||C_E||<=sqrt(a/lambda), ||C_E-C_F||<=K_C delta. Finally
Gamma_E=Ad_(C_E) E and
||Ad_C-Ad_D||_diamond<=(||C||+||D||)||C-D||. Combine this with
||E-F||_diamond<=||J_E-J_F||_1<=sqrt(ab)delta to prove the bound.

The deterministic recovery maps R_E=Ad_(B_E) Pi_E,
B_E=Omega_E^(1/2)Z_E^(-1/2), are also Lipschitz. One explicit constant is

\[
\|R_E-R_F\|_\diamond\le
\left[2\sqrt{a/\lambda}K_B+(a/\lambda)b^2K_\Pi\right]\delta,
\quad K_B=\sqrt a/(2\lambda)+\sqrt aK_Z/(2\lambda^{3/2}).
\]

Here ||Pi_E-Pi_F||_diamond<=b²||Pi_E-Pi_F||_(2→2), by Choi
reshuffling and Frobenius/trace norm inequalities. For K_E=C_E*C_E,
the prescribed exact heralding choice p=1/Tr K_E satisfies

\[
\operatorname{Tr}K_E=\operatorname{Tr}(\Omega_E^{-1}Z_E)
\le a/\lambda,\qquad p\ge\lambda/a.
\]

This is a known-class probability bound, not a stable class-identification
claim. The theorem concerns Choi data. It does not prove a Lipschitz inverse
from approximate scalar profiles to minimal block matrix units, and does not
replace the principal's valid Holder theorem for that different problem.

## 2. Tracial infinite-output greatest-existence criterion

Let a finite-input trace-class-output channel have invariant (M,T,tau), where
M=W*(T(M_a)) and tau(A)=Tr(Omega A)/a is faithful normal and TRACIAL. Then
its complete-profile class has a greatest normal trace-class-output member
on a separable Hilbert space if and only if M is a countable von Neumann
direct sum of finite matrix factors. The direct sum here means the bounded
product algebra with normal summable state weights. This does not assert the
criterion for general nontracial invariants.

### Infinite moment classification

The finite path proof still obtains all ordered moments: normalized
generators are bounded, reference dimensions are finite, and faithful input
baselines give T_R(rho)>=lambda_min(rho) I. Equal moments determine norms,
not merely polynomial kernels. For every polynomial p,

\[
\|p\|=\lim_{n\to\infty}\tau((p^*p)^n)^{1/(2n)}.
\]

Faithfulness makes the spectral measure of every positive element have full
spectral support, proving this formula. Hence the generator correspondence
extends to a state-preserving C*-isomorphism. Its GNS isometry, defined on
polynomial vectors, intertwines the represented C*-algebras and their cyclic
vectors. Faithful normal states give faithful normal GNS representations of
their von Neumann algebras, so this isometry extends the isomorphism normally
to M_E and M_F. This supplies the missing normality step; an algebraic kernel
argument alone would be insufficient in infinite dimension.

### Necessity

In any representative let P be a spectral projection of a normalized
Hermitian input generator. Put Omega_P=P Omega P+(I-P)Omega(I-P). It is
faithful positive trace class. For every A in M, traciality gives

\[
\operatorname{Tr}(\Omega_P A)
=a\tau(PAP+(I-P)A(I-P))=a\tau(A).
\]

Thus changing Omega to Omega_P preserves the full invariant and TP. For a
generator B=T(H) and threshold t, use P=1_(t,infinity)(B). Its pinched
representative attains the triangle bound

\[
\|E_P(H-tI)\|_1=a\tau(|B-tI|).
\]

If G is greatest, output trace-norm contraction forces it to attain every
such bound. For non-atom thresholds, equality of the positive/negative
triangle bound gives
(B-t)_+ Omega_G (t-B)_+=0, by cancelling the dense-range outer
Omega_G^(1/2) factors. Cut off the spectra a positive distance from t,
invert the bounded-away-from-zero factors, and take strong limits. This
forces Omega_G to commute with 1_(t,infinity)(B). Non-atom thresholds are
dense, so it commutes with B and all generators. Hence Omega_G lies in M'.

The positive eigenspaces of faithful compact Omega_G are finite dimensional
and span the whole output Hilbert space. Restricting M to each gives a normal
finite-dimensional representation. Their kernels are weakly closed ideals,
so are central summands; the complementary finite-dimensional central
supports together cover 1 because the representations separate points.
Each such support is a finite sum of finite matrix factors. A countable
cover therefore makes M a countable atomic sum of finite factors. A diffuse
or type-II summand is impossible.

### Sufficiency and normal converter

Write M=directsum_j M_(n_j), tau=sum_j p_j tr_(n_j), all p_j>0 and
sum p_j=1. Define on H_0=directsum_j C^(n_j)

\[
\Gamma(X)=\bigoplus_j\frac{ap_j}{n_j}T_j(X).
\]

This is CP and TP, with faithful trace-class identity output
directsum_j (ap_j/n_j)I. For a target F, its normal representation pi has
central block projections summing strongly to I. After pinching a trace-class
input Y into its finite matrix blocks, set

\[
R_j(Y)=\frac{n_j}{ap_j}\Omega_F^{1/2}\pi_j(Y)\Omega_F^{1/2},
\qquad R(Y)=\sum_j R_j(Y_{jj}).
\]

Every R_j is CP and trace preserving, since
Tr Omega_F pi_j(Y)=a p_j Tr(Y)/n_j. The sum converges absolutely in trace
norm: block pinching is contractive and sum_j ||Y_jj||_1<=||Y||_1. Its
adjoint is a bounded block diagonal family of unital CP normal maps, hence
is normal, unital and CP. Thus R is an allowed normal CPTP converter. Strong
block summation sandwiched by the Hilbert--Schmidt Omega_F^(1/2) gives
R Gamma=F. No global unbounded inverse occurs.

The binary theorem is the commutative specialization: M=L^infinity(mu) is
atomic of this form precisely when mu is purely atomic. This is a valid
extension of the finite greatest theorem at a tracial infinite-output scope;
priority against normal reverse-test literature remains separately assessed.

## 3. Infinite binary theorem: domains, normality and diffuse necessity

For any channel F:M_2→S_1(H), compress to supp Omega_F. Positivity gives
-Omega<=F(H)<=Omega for every Hermitian contraction H. Douglas factorization,
or quadratic forms on the dense range of Omega^(1/2), gives a unique bounded
UCP T with F(X)=Omega^(1/2)T(X)Omega^(1/2). At matrix levels the same
domination proves complete positivity. An inverse Omega^(-1) is not bounded.

For finite referenced rho>0, T_R(rho)>=lambda_min(rho)I. Define RLD by the
finite bounded sandwich

\[
g_F(\rho,H)=\operatorname{Tr}[(\Omega\otimes I_R)
 T_R(H)T_R(\rho)^{-1}T_R(H)].
\]

The middle operator is positive bounded, so the trace is finite. Interpret
the formal unbounded-inverse expression by its closed positive quadratic
form; it agrees with this formula. For maximal perspectives put P=T_R(rho),
Q=T_R(sigma)>0 and W=(Omega^(1/2) tensor I)Q^(1/2). This bounded operator
is injective with dense range. In W=F_R(sigma)^(1/2)U its polar isometry U
is unitary on effective supports. The bounded relative likelihood is
U Q^(-1/2)P Q^(-1/2) U*, and hence

\[
P_f(F_R\rho,F_R\sigma)
=(\Omega^{1/2}\otimes I)Q^{1/2}
 f(Q^{-1/2}PQ^{-1/2})Q^{1/2}(\Omega^{1/2}\otimes I).
\]

This proves the needed congruence identity without multiplying unbounded
inverses illegally. Continuous f on the relevant compact positive spectra
gives a trace-class perspective.

If E kills input coherences and F has the same RLD profiles, use baseline
I_2/2 and tangents sigma_x and sigma_y. The scores of E vanish; faithfulness
forces T_F(sigma_x)=T_F(sigma_y)=0. Thus arbitrary class members also kill
coherences. With A=T(E_00), B=2A-I, the diagonal-baseline expansion is

\[
g(\operatorname{diag}(s,1-s),\operatorname{diag}(1,-1))
=4\sum_{n\ge0}[-2(s-1/2)]^n\int B^{n+2}d\mu.
\]

Mass one and mean B=0 supply the first two missing moments. Compact moment
determinacy identifies mu. In fact unreferenced RLD equality already
suffices in this binary subclass; references are not the new obstruction.

For positive trace-class X,Y, equality
||X-Y||_1=Tr X+Tr Y implies orthogonal supports. If Q is the positive
spectral projection of X-Y, the deficit equals
2[Tr((I-Q)X)+Tr(QY)]. Both nonnegative terms must vanish, giving
(I-Q)X=0, QY=0 and XY=0. Applying this to the positive/negative
congruences at each non-atom threshold, cancelling dense-range outer
Omega^(1/2) factors, and cutting off spectra away from the threshold gives
P_(t,1] Omega P_[0,t)=0. Faithfulness makes a mu-null atom projection zero.
Thus Omega commutes with every non-atom cut, and then all spectral cuts by
strong limits. Compactness and faithfulness of Omega imply a countable joint
eigenbasis with A, so any diffuse component of mu contradicts greatestness.
The pinched comparison Omega_t retains faithfulness, trace two, state
normalizations and mu, since spectral cuts commute with A.

For atomic mu, the principal's converter
R(Y)=sum_j Y_jj Omega^(1/2)P_jOmega^(1/2)/(2mu_j) converges absolutely in
trace norm because sum_j |Y_jj|<=||Y||_1. Its adjoint is
diag(Tr sigma_j B), unital CP and normal by monotone convergence of each
normal state. Hence it is an allowed normal CPTP map, including countably
many atoms and atoms at zero or one. The diffuse Fourier fixture is correctly
normalized: (2/3)[1+2sum_(n>=1)2^(-n)]=2, all coefficients are positive,
and |e_n(x)|²=1 gives uniform diffuse mu. A,I-A between I/4 and 3I/4 give
faithful trace-one output states uniformly comparable to Omega.

I find no substantive mathematical gap. The category restriction is crucial:
a generalized classical L^infinity(mu) experiment may realize the ideal
diffuse reverse test. The no-go is for faithful normal density-operator
realizations on separable Hilbert output. Historical priority remains to be
reconciled with that reverse-test literature.

## 4. Univariate witnesses and finite physical probes

Use contractive rational Hermitian generators H_i, L=2b²-1, r=L+1,
d=2br. For each word w=i_1...i_n, n<=L, define the reference-path matrix
K_w=sum_j H_(i_j) tensor (|j-1><j|+|j><j-1|). Its norm is at most two:
the absolute quadratic form is at most
2sum_j ||v_(j-1)|| ||v_j|| <=2sum_j ||v_j||². Thus
rho_w(t)=(I-tK_w)/(ar)>=3I/(4ar) for |t|<=1/8.

Take d+1 distinct rational t values there, and for each word use just the
four projectors onto e0,en,(e0+en)/sqrt2,(e0+i en)/sqrt2. Their matrices
are Gaussian-rational. Center I tensor P by subtracting a rho_w(t). Each
uncentered scalar RLD difference has numerator degree at most 2br-1<d.
Grid equality implies rational-function identity. The four tests determine
the (0,0),(n,n),real/imaginary (0,n) resolvent entries along that line.
The t^n coefficient in (0,n) is exactly the ordered moment: a length-n
nearest-neighbour path from0 to n must take every edge forward. This reduces
the principal's probe bound to

\[
4(d+1)\sum_{n=1}^L(a^2-1)^n.
\]

It is still a large physical-probe list, not polynomial tomography.

For a rational matrix-input inequality witness, breadth-first paired raw
words require at most N=r_E²+r_F² basis elements, lengths<=N-1. Append
one generator per step. Common generator/inverse denominators then grow only
linearly in word length; all entry and rank-test bit lengths are polynomial.
Arbitrary basis-word products could defeat this bound and are unnecessary.

At a differing word use r=n+1 and d=r(b+c). For non-coordinate supports
P_E, pad the inverse with (I-P_E) tensor I. Output states/tangents are
supported on P_E tensor I, so the padded expression equals the support
inverse exactly. Its determinant degree is at most br, and difference
numerator degree at most r(b+c)-1. Thus polynomially many univariate tests
find a nonzero value. A rational output floor is
mu_E=1/Tr(Omega_E^+)<=lambda_min(Omega_E|P_E), so grid inputs have
effective output floor 3mu_E/(4ar). No eigenbasis choice is hidden.

With H'=I tensor P-a rho, ||H'||<=a+1. Choose
s=1/[4ar(a+1)] and sigma=rho+sH'. Then sigma>=I/(2ar), both states are
faithful rational density matrices, and the maximal chi-square difference
is exactly s² times the nonzero RLD difference. Its signed rational value is
an exact margin with polynomial bit length; its magnitude can nevertheless
be exponentially small in that length. There is no physical divergence
oracle, cheap sample bound, or unknown-input recovery in this witness claim.

The principal's exact reference-necessity script was replayed independently:
g_E=49924/4159, g_F=48388/4031, difference=-2048/16764929. Transpose
covariance makes all unreferenced maximal perspectives agree, while ordered
XYZ moments change sign. Complex Hermitian reference tests are essential.

## 5. Holder, genericity and the resource envelope

The principal's K_(lambda,kappa) is compact: the channel set is bounded,
Omega>=lambda I is closed, and the word-frame inequality is continuous and
closed there. It is semialgebraic after introducing the unique positive
inverse square root and eliminating auxiliary variables. The finite-probe
function f and unitary-orbit distance d are continuous semialgebraic. Under
the full-algebra promise f=0 gives an inner labelled *-isomorphism; weighted
state equality on all M_b fixes Omega_F=U Omega_E U*, so d=0.

I inspected the primary published statement of
[Basu--Mohammad-Nezhad Theorem 2.2](https://www.cambridge.org/core/journals/forum-of-mathematics-sigma/article/improved-effective-lojasiewicz-inequality-and-applications/022BF859F5714FDA8050F6DC1992E48B).
Its hypotheses are closed bounded semialgebraic A, continuous semialgebraic
f,g, and f^(-1)(0) contained in g^(-1)(0). It supplies N<=(8d)^(2(n+7)),
with d>=2 bounding degrees in quantifier-free descriptions of A and the two
graphs. The principal's application meets them after elimination. No small
degree or practical runtime follows. Search for q,C must dovetail integer
q and dyadic C; an unbounded inner C-loop at a wrong q would not terminate.
Feasible-model sampling requires rational confidence-interval endpoints and
rational lambda,kappa. Confidence coverage and intersection with the promised
model class are distinct issues.

The generic raw-word minor argument is valid. On a convex rational line to
a generating seed, clearing det Omega denominators gives a nonzero polynomial
with finitely many roots. The source-dependent antidegradable ball gives
exact zero capacity nearby; continuity alone gives a limiting gap without
it. Upper-semicontinuity of a resource ceiling is valid when M is continuous
on the full fixed-dimensional channel space, including any boundary limit of
greatest lifts. The positive Omega floor persists for the concrete lifts. A
single convergent subsequence, followed by each fixed RLD test, puts the
limit in the limiting profile class; no supremum/limit exchange is needed.
Density and M<=C_M then prove the lower-noise envelope identity. These are
not ordinary-capacity discontinuity or rational-input noncomputability claims.

## 6. Finite-data impossibility without a held certificate

The initial auditor's qubit family has common Choi floor127/51200,
C_class(E_0)>119/128, and C_class(E_j)=C(E_j)→C(E_0)<3/4. Therefore for
every additive error alpha<23/256 no adaptive memoryless-channel query
procedure can be uniformly accurate with probability>=2/3 on this family
and stop after finitely many queries almost surely at E_0.

Let A be the halting event with answer in E_0's alpha-accurate interval.
At E_0 it has probability>=2/3. The bounded-query events A_N increase to A;
choose finite N with Pr_(E_0)(A_N)>1/2. For large j the accurate intervals
at E_0 and E_j are disjoint. N-query adaptive event probabilities differ
by at most N||E_j-E_0||_diamond/2; choose j so this is less than
Pr_(E_0)(A_N)-1/3. Then Pr_(E_j)(A_N)>1/3 although each answer is wrong,
a contradiction. Pad unused queries after truncated early stopping. This
covers references, coherent memory and arbitrary adaptive inputs.

This uses no held N1690 certificate. It does not exclude pointwise
asymptotic estimation without finite stopping, exact symbolic rational-input
algorithms, or conditioned strata. The constructor's locally acquired quantum
fixture gives a stronger independent operational version.

## 7. Constructor certificate and matching acquisition constants

Independently replayed `../constructor/check_instability.py`: all exact
checks pass. Analytically S=I/4+P has Tr_aux S²=7I/8. Its Choi
congruence gives floor1/224 and Omega=diag(25,1,1,1)/14. The core has
positive q on range(V)^perp and strict Schur determinant1554639/411041792.
Congruence by W followed by I_32/16384 gives a full positive extension;
both entire output marginals equal J_E0. With T T*=J_E0, the antidegrader
Choi congruence has output trace I and the purification identity gives actual
complement composition. No input-dimension factor is missing in the
unnormalized convention. The symmetric correction has both marginals
because Tr_C D=0, with norm<=||D||/2<=||F-E0||_diamond. Radius1/32768
leaves extension floor1/32768.

The endpoint's normalized floor143/448 times Omega's floor1/14 gives
143/6272. D0,B0 have weighted trace zero. The commutant polynomial's
quadratic imaginary part vanishes only at8/9, where q=1/81; the linear
root is nonreal. Excluding0,1 gives rank15 and hence full M_4.
P1P2P1=P1/4 implies the symmetric-extension singlet bound3/4.
Delta's optimum decoded fidelity29/32 follows because its replacer part
contributes exactly1/4 for every TP decoder. The gap gives deficiency5/16.
The entropy bound gives Q(Delta)>25/64. These claims survive audit.

For acquisition ||J_R-J_E0||<=2 and s=1/512 make E_- have floor1/1792.
N adaptive queries are a quantum map of N independent selector coins.
Their chi-square divergence is (1+(512t)²)^N-1. Total variation<=half
its square root proves the claimed lower bound.

There is a matching simple upper bound. Input |0><0| and measure the
first Bell-coordinate output projector. Its success probability is

\[
p_t=25/28-(75/6272)t.
\]

Put c=75/6272. Threshold the empirical frequency at p_0-ct/2.
Hoeffding bounds each hypothesis error by exp(-Nc²t²/2); hence

\[
N=\lceil2\ln3/(c^2t^2)\rceil
\]

achieves success>=2/3 for each hypothesis. Acquisition for the promised
pair is Theta(t^-2), even allowing adaptive quantum methods.

## 8. Offline PBT, complete environments and noise

The cached primary [Pirandola et al. manuscript](https://arxiv.org/html/1803.02834)
uses product maximally entangled pairs in Eq6 and product channel Choi
resources in Eq13. Lemma1 Eq9 gives delta_M<=2a(a-1)/M and Eq15 gives
adaptive n delta_M peeling. Exact heralding S Phi=p Psi therefore prepares
independent exact Choi resources before unknown input arrives. With
M=max{2,ceil(2a(a-1)n/epsilon)}, nM successes cost nM/p in expectation.
Feedback, port indices, all stored systems and large local measurements are
paid resources. M>=2 is automatic for epsilon<=1.

For fixed memoryless noisy preparation, each normalized resource has trace
norm error<=e=2eta/(p-eta). Tensor telescoping gives honest-output error
<=2a(a-1)n/M+nM e and expected source cost<=nM/(p-eta). The binomial
cap is valid: mean>=2m+8L gives lower-tail probability<=exp(-mean/8)
<=exp(-L)<=2^(-L). Abort occurs before accepting unknown input.

The stronger environment claim also passes audit with its existential scope.
Standard identity PBT is depolarizing with a Weyl dilation whose identity
branch has weight w0=Fe=1-delta_M/2. Purify all adaptive interleavings.
In the expansion over n Weyl-error labels the all-identity string has
amplitude sqrt(w0^n) and equals the exact target protocol dilation; every
other error string has an orthogonal environment flag. Thus the full pure
states have overlap sqrt(w0^n) and trace distance (half trace norm)

\[
\sqrt{1-w_0^n}\le\sqrt{n\delta_M/2}.
\]

Actual coherent PBT and offline-preparation apparatus dilate the same
simulator, so Stinespring uniqueness aligns them after environment padding
by a fixed input-independent isometry. This is an existential dilation
alignment, not an efficient environment controller. The target dilation is
fixed; extra PBT/herald transcripts are forgotten honest registers retained
in the full environment. An honest transcript deliberately added as a new
target output cannot silently be rotated away.

For noisy iid ports, fixed Uhlmann alignment gives joint resource-purification
distance<=sqrt(nM e), since squared fidelity of each resource is at least
1-e (or the estimate is trivial). Running the identical global protocol
preserves that bound. Therefore the full-environment distance is at most

\[
\sqrt{n\delta_M/2}+\sqrt{2nM\eta/(p-\eta)}.
\]

For exact resources, an environment error epsilon costs
O(a²n²/(p epsilon²)) expected primitive uses. This requires fixed memoryless
preparation and includes actual failed-attempt histories and discarded
resources. It is a finite-block approximate simulation theorem, not exact
universal finite-resource teleportation or positive unassisted rate.

## 9. Hyperfinite external approximants

Assume an explicit increasing finite-dimensional unital filtration M_k of
tracial M, with L2(tau)-dense union and tau-preserving expectations E_k.
The proposed approximate-greatest construction is valid. Set T_k=E_kT and
use the finite M_k lift. For every class member F the block converter gives

\[
R_{k,F}\Gamma_k(X)=\Omega_F^{1/2}\pi(E_kT(X))\Omega_F^{1/2}.
\]

If calling Gamma_k the *minimal canonical* channel, note T_k need not
generate all M_k. First compose that canonical channel's deterministic map
to the full M_k lift; then use the displayed block converter. Alternatively
call the full M_k lift the external approximant. The bound is unchanged.

Schatten Holder gives

\[
\|\Omega^{1/2}B\Omega^{1/2}\|_1
\le\|\Omega^{1/2}\|_2\|B\Omega^{1/2}\|_2
=a\|B\|_{2,\tau}.
\]

Entrywise tensor expansion and trace-norm contraction under block extraction
then give diamond error<=a sum_ij ||E_kT(Eij)-T(Eij)||2,tau,
and hence <=a³ maxerror, uniformly in F and its output dimension. L2-density
makes these finitely many errors tend to zero. Pointwise RLD convergence
uses bounded normalized tangents and the uniform inverse bound at each fixed
faithful input baseline; continuous functional calculus gives the analogous
fixed maximal-perspective convergence.

The approximants generally are outside the exact class. Dimensions and error
moduli must be supplied for an effective compiler; no uniform rate or
capacity conclusion follows. No converse to hyperfinite/injective
approximation is proved here.

## 10. Final dossier review

Reviewed `outputs/COMPLETE_MAXIMAL_INFORMATION_RESEARCH_DOSSIER.md` through
W,P,S,D,T and the diffuse fixture. No substantive mathematical defect found.
W's small-t tail bound is correct: endpoint component>=|d|t^n/2 implies one
of the four projector expectations>=|d|t^n/4. Its state-pair step1/(8ar)
has the stated positive spectral floor. The univariate interpolation proof
above independently confirms its polynomial bit complexity.

P's 2m+1 probe count is valid. Each inequivalent pair has a nonzero analytic
rational probe gap; its zero fiber has dimension<=d-1. With k independent
probes the incidence set has dimension<=2m+k(d-1), smaller than kd when
k>2m. Projection and closure remain lower-dimensional semialgebraic sets,
so a good open rational tuple exists inside the physical probe box. Complete
inequivalence is already semialgebraic by the finite explicit predicate.
Universal QE can therefore verify candidates and rational enumeration
terminates without a circular oracle. No efficient preprocessing follows.

The output category, tracial hypothesis, Choi conventions, exact/approximate
distinctions and inherited/new attribution are retained. General nontracial
infinite-output greatest existence remains open. Historical priority,
laboratory realization and practical advantage are not established.

The original auditor qubit discontinuity check, constructor certificate and
principal reference-necessity script have all been replayed with exact
arithmetic. Their finite outputs supplement the analytic proofs above.
