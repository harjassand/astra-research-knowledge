# Principal: approximate greatestness forces injectivity

6 November 2026. Constructed after the initial independent phase and Haar repair.

Assume finite input, separable trace-class outputs, and the faithful normal TRACIAL invariant (M,T,tau) of Theorem T. Define d(G,F)=inf_R ||F-RG||diamond, R normal CPTP. If G_k are exact-class members with sup_F d(G_k,F)->0, the following proves M injective. In fact pointwise d(G_k,F)->0 for every fixed F suffices: take fixed pinched representatives for each generator/threshold.

Write pi_k for the normal labelled representation and Omega_k=G_k(I), Tr Omega_k pi_k(Z)=a tau(Z). For selfadjoint X, pinching a fixed representative at the sign of T(X) gives an exact-class target F_X attaining a tau(|T(X)|). Thus the deficit a tau(|T(X)|)-||G_k(X)||1 tends to zero, by output trace-norm contraction and diamond approximation. Apply X=H_i-t I for every Hermitian input generator and every nonatom spectral threshold t.

Put C=pi_k(T(H_i))-t I, A=Omega_k^.5 C_+ Omega_k^.5, D=Omega_k^.5 C_- Omega_k^.5. Let s=Tr(A+D)=a tau(|T(H_i)-t I|), Delta=s-||A-D||1. For a Helstrom projection Q, e_A=Tr((I-Q)A), e_D=Tr(QD) satisfy e_A+e_D=Delta/2. Factoring x=Omega_k^.5 C_+^.5 and y=Omega_k^.5 C_-^.5, split x*y at Q and apply Schatten Cauchy--Schwarz:

    F_k:=||C_+^.5 Omega_k C_-^.5||1
       <=sqrt(Tr A e_D)+sqrt(Tr D e_A)<=sqrt(s Delta/2)->0.

For P_t=1_(t,infinity)(pi_k T(H_i)), split the offdiagonal block at t±h. Far cuts permit bounded inversion and contribute <=F_k/h. Each near-cut term contributes <=a sqrt(tau 1_[t-h,t+h](T(H_i))). Therefore

    ||[Omega_k,P_t]||1 <=2F_k/h+4a sqrt(tau 1_[t-h,t+h](T(H_i))).

Take k->infinity, then h->0. Dense nonatom cuts and step approximation give centrality for each generator. Products, adjoints, norm closure give it on A=C*(T(M_a)). Kaplansky L2-density plus ||[Omega_k,pi_k(Z-p)]||1<=2a||Z-p||2,tau extends it to every Z in M.

On H=directsum H_k, pi=directsum pi_k is faithful normal. States supported in block k with density Omega_k/a restrict exactly to tau and are asymptotically M-central. Any weak-star cluster phi on B(H) is a hypertrace restricting to the faithful normal tau.

For X>=0, psi_X(Y)=phi(X pi(Y)) is positive and <=||X||tau, by centrality. Hence it is normal with a bounded tracial Radon--Nikodym density P(X) in M, defined by tau(P(X)Y)=phi(X pi(Y)). Uniqueness gives unitality, identity on M, linearity and bimodularity. For [X_ij]>=0 and m_i in M,

    tau(sum m_i* P(X_ij)m_j)=sum phi(pi(m_i)* X_ij pi(m_j))>=0.

Density of m_i in L2(M,tau) proves CP. Thus P is a UCP projection onto pi(M), proving injectivity. P is generally NOT normal.

Conversely the supplied hyperfinite filtration and Haar construction give uniform approximate greatestness inside the exact class, by normal partial trace to each finite external lift. With an exact verified general-center injective-to-hyperfinite import, these statements give a full equivalence. No effective filtration/rate, finite-dimensional exact output, or black-box synthesis follows.

An explicit obstruction is M=L(F_2) on ell2(F_2): U,V left free shifts; input M_3, J_T=[[I/3,U/12,V/12],[U*/12,I/3,0],[V*/12,0,I/3]], positive floor 1/3-sqrt(2)/12. Omega=diag_g 3/(5*4^|g|) is faithful trace3 since sum_g 4^-|g|=5, and restricts to 3tau. Thus E=Omega^.5 T(.) Omega^.5 is CPTP and generates M. Noninjectivity follows from a hypothetical conditional expectation giving a left-invariant mean on diagonal ell-infinity(F_2), contradicted by the four first-letter sets. Representation independence is the standard UCP extension characterization. Consequently there is no approximate-greatest sequence for this explicit class. This applies known nonamenability, not a new proof of it.
