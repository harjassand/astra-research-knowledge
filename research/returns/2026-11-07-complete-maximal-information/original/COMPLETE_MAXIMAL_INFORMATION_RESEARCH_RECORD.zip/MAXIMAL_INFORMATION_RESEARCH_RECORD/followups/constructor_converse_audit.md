# Constructor: converse and free-group fixture check

6 November 2026. Independent challenge of
`principal_approximate_greatest_converse.md`. **Verdict: sound at the stated
faithful normal tracial, separable-output scope**, subject to the separately
verified general-center injectivity/hyperfiniteness import when asserting a
full equivalence. No new agents used. This file does not establish priority.

## 1. Converse chain and strongest quantifiers

The Helstrom estimate is correct. For `x=Omega^.5 C_+^.5`,
`y=Omega^.5 C_-^.5`, split `x*y` at a Helstrom projection `Q`. Schatten
Cauchy--Schwarz gives

\[
 \|x^*y\|_1\le\sqrt{\operatorname{Tr}A\ e_D}
                 +\sqrt{\operatorname{Tr}D\ e_A}
 \le\sqrt{s\Delta/2}.
\]

For cut `P_t`, the two far factors are invertible with inverse-square-root
norm at most `h^-1/2`, so their off-diagonal block is bounded by `F_k/h`.
The two remaining near blocks are each at most
`a sqrt(tau 1_[t-h,t+h])` by Hilbert--Schmidt factorization. Thus the printed
commutator bound and the order `k->infinity` followed by `h->0` are valid.
Nonatom thresholds remove the equality eigenspace, rather than assuming it
away. Uniform step approximation gives generator centrality, and products
and norm closure give the generated C*-algebra.

The L2 extension is also valid, uniformly over the different representations:
`||[Omega_k,pi_k(B)]||1<=2a||B||2,tau`. Direct-sum block states therefore have
asymptotically central restrictions and any weak-star subnet/ultrafilter
limit is a hypertrace. A weak-star convergent subsequence is not needed.

For `X>=0`, centrality rewrites
`phi(X pi(Y))=phi(pi(Y)^.5 X pi(Y)^.5)` for `Y>=0`, proving positivity and
domination by `||X||tau`. Domination by normal tau makes this functional
normal and its tracial Radon--Nikodym density bounded. Pairing proves the
map is linear, unital and fixes M. The printed matrix test on the dense
vectors `m_i in L2(M,tau)` proves complete positivity. The resulting UCP
projection generally is **not normal**, which is sufficient for injectivity.

Only **countably many fixed targets** are needed: choose a finite Hermitian
input basis and, for each generator, a countable dense set of nonatom
thresholds. Pointwise convergence of domination errors to these fixed
pinched targets suffices. Still more basically, simultaneous asymptotic
saturation of just their trace-norm/Bayes ceilings suffices; no common
decoder or uniform convergence rate is required.

By a diagonal argument, noninjectivity consequently gives a finite obstruction:
there are finitely many such fixed targets and a positive delta such that
every exact-class source has domination error at least delta for one target.
Otherwise select the k-th source to approximate the first k targets to 1/k,
contradicting the countable-target version. This finite obstruction can be
made explicit for the following fixture.

## 2. Input-three L(F2) fixture

Let U,V be the left shifts of the two free generators on `ell2(F2)`. The
operator-valued Choi matrix is

\[
 J_T=\begin{pmatrix}I/3&U/12&V/12\\U^*/12&I/3&0\\V^*/12&0&I/3\end{pmatrix}.
\]

Its off-diagonal row `[U,V]` has norm sqrt(2), giving positive floor
`(4-sqrt(2))/12`. Thus it defines a CP map `T:M3->B(ell2(F2))`, and
`T(I)=I`. There are `4*3^(n-1)` reduced words of length n>=1, so
`sum_g 4^-|g|=5`. Hence

\[
 \Omega=\operatorname{diag}_g\frac{3}{5\,4^{|g|}}
\]

is faithful trace class of trace three. Every diagonal coefficient of an
element of L(F2) is its canonical trace, so `Tr Omega Z=3 tau(Z)`.
Also `3 tau(T(Eij))=delta_ij`, proving TP of
`E(X)=Omega^.5 T(X)Omega^.5`. Its normalized generators recover U,V from
`12 T(E01),12 T(E02)`, so the generated von Neumann algebra is exactly L(F2).

The channel has a computable rational matrix-entry description, not a finite
rational Choi matrix. In the word basis,
`E(Eii)_gg=1/(5*4^|g|)` and
`E(E01)_gh=1/(20*2^(|g|+|h|))` when `g=u h`, zero otherwise; similarly for V.
The density tail is explicitly
`Tr[1_(|g|>L) Omega]=(12/5)(3/4)^L`.
The displayed positive floor is for the **bounded normalized Choi operator**;
the trace-class physical Choi operator has only the relative lower bound
`J_E>=((4-sqrt2)/12) I_3 tensor Omega`. There is no infinite-dimensional
absolute eigenvalue floor and no use of N1698's finite-matrix compiler.

## 3. Explicit 60-target gap (optional quantitative strengthening)

This uses the standard Arveson extension theorem: a UCP map from an operator
system in B(K) into B(H) extends to B(K). For any normal labelled
representation pi of L(F2) on H, extend pi to a UCP map
`Phi:B(ell2(F2))->B(H)`. Its group unitaries belong to its multiplicative
domain. For any density Omega of trace a define the mean

\[
 m(f)=\operatorname{Tr}[\Omega\Phi(M_f)]/a\quad(f\in\ell^\infty(F2)).
\]

Let W_s be the nonempty reduced words whose first letter is s. The exact
relations `u(F2 minus W_u^-1)=W_u` and the analogous V relation imply

\[
 d_u+d_v\ge1,\quad
 d_u=1-m(W_u)-m(W_{u^{-1}}),\quad
 d_v=1-m(W_v)-m(W_{v^{-1}}).
\]

Multiplicative-domain covariance and the Helstrom bound for an effect give
`d_u<=||[Omega,pi(U)]||1/(2a)`, and similarly for V. Thus in **every** such
representation,

\[
 \|[\Omega,\pi(U)]\|_1+\|[\Omega,\pi(V)]\|_1\ge2a. \tag{1}
\]

This is a quantitative form of the usual first-letter nonamenability argument;
it does not assume the projection or mean is normal.

Take four Hermitian input matrices
`H1=6(E01+E10)`, `H2=6i(E10-E01)`,
`H3=6(E02+E20)`, `H4=6i(E20-E02)`.
Their normalized images are respectively
`A1=Re U,A2=Im U,A3=Re V,A4=Im V`.
Use the fifteen thresholds `t_j=-1+j/8`, j=1,...,15, and h=1/2048.
Each A_i has the arcsine tau-law on [-1,1], because U,V have Haar spectral
measure under tau. These near-cut intervals lie in [-15/16,15/16], where
the density is at most `16/(pi sqrt31)<1`. Thus their mass is at most
`2h=1/1024`.

For any exact-class member G, let

\[
 \Delta_{ij}=a\tau|A_i-t_j|-\|G(H_i-t_j I)\|_1.
\]

If all sixty normalized deficits `Delta_ij/a` were at most `2^-34`, the
principal's cut bound would give
`||[Omega_G,pi(P_tj)]||1<=5a/32`.
The midpoint step function

\[
 B_i=-15I/16+(1/8)\sum_{j=1}^{15}1_{(t_j,\infty)}(A_i)
\]

approximates A_i in norm to 1/16. Consequently
`||[Omega_G,pi(A_i)]||1<=7a/16` (a deliberately conservative bound).
Summing the four generators yields a commutator sum at most `7a/4`,
contradicting (1). Therefore one of the sixty deficits exceeds `a*2^-34`.

For each cut define the fixed target F_ij by pinching the original Omega at
`P_tj(A_i)` and keeping the same normalized T. Traciality makes it an exact
class member and its selected Bayes trace norm is exactly the upper ceiling.
Since `||H_i-t_j I||1=12+|t_j|<13`, output trace-norm contraction implies

\[
 \max_{i,j}\inf_R\|F_{ij}-RG\|_\diamond
 >\frac{3}{13\cdot2^{34}}\quad\text{for every exact-class }G. \tag{2}
\]

Thus this explicit class has a positive uniform failure gap for an explicit
finite family of at most sixty targets. They have separable infinite outputs;
no finite-output realization, efficient apparatus, or physical demonstration
is inferred. This optional constant strengthens the qualitative converse but
does not establish historical priority. Work now turns to amenability and
statistical-experiment predecessors, as requested.
