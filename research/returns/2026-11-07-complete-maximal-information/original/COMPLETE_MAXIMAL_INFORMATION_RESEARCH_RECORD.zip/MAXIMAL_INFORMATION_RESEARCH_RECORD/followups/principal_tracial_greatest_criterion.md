# Tracial invariant: exact infinite-output greatest-realization criterion

Principal extension of the binary atomic criterion. This is a proof candidate under independent challenge. It uses no finite-dimensional compiler claim. The explicit diffuse binary example is already in principal_infinite_binary_boundary.md.

## Statement

Let E:M_a -> T(H) be a channel, with finite a>=2 and separable effective output H. Put Omega=E(I), faithful trace-class with TrOmega=a. Define bounded UCP normalized generators T(X) by E(X)=Omega^.5 T(X)Omega^.5. Let M=W*(T(M_a)) and tau(Z)=Tr(Omega Z)/a. Assume tau is TRACIAL on M (faithful normal already follows from Omega). Same complete profile means equality of the referenced maximal/RLD tests, with bounded-normalized-sandwich definitions at faithful input baselines. All comparison channels also have finite input a and separable trace-class output, and postprocessings are normal CPTP Schrödinger maps.

THEOREM TG. The class has a greatest member under deterministic output processing if and only if M is atomic finite type I:
 M is normally *-isomorphic to a finite or countable direct sum/product of finite matrix factors M_(n_j).
Here bounded algebra elements have uniformly bounded blocks (von Neumann direct product), while normal densities/output states live in the trace-norm direct sum. No type-I-infinite block is allowed. The criterion is intrinsic to the profile and does not require a uniform bound on n_j. If M is so atomic, tau=Σ p_j Tr_(n_j)/n_j, with p_j>0,sum p_j=1, and
 Gamma(X)=⊕_j (a p_j/n_j) T_j(X)
is a greatest channel on H0=⊕_j C^(n_j).

For commutative M this becomes precisely the binary theorem's purely-atomic-measure criterion. A diffuse component forbids a greatest trace-class quantum realization, although the generalized operator-algebraic experiment itself can still serve as the appropriate canonical object. This theorem does not address the general nontracial infinite-output case.

## Lemma: profiles classify the normal invariant triple

Physical path pencils from N1698 continue to work because every T(H_i) is bounded and UCP. For small t, I−tΣT(H_i)⊗edge_i>=I/2. The bounded normalized RLD form is
 g_E(rho,H)=Tr[(Omega⊗I) T_R(H) T_R(rho)^(-1) T_R(H)].
No inverse of compactOmega is used in this formula. Polar decomposition of (Omega^.5⊗I)T_R(rho)^.5 identifies it with the usual maximal perspective/closed-form quadratic on the effective output support.

Path-reference tests therefore determine all ordered tau-moments. Conversely moments determine the C*-norm: for a positive B in a C*-algebra with faithful state tau, ||B||=lim_n tau(B^n)^(1/n). To prove lower bound, pick any epsilon>0 and a continuous nonnegative function f supported in [||B||−epsilon,||B||] with f(B)nonzero; faithfulness gives tau(f(B))>0 and the resulting lower moment bound. The upper bound is immediate. Thus equal moments identify kernels AND norms of all evaluated *-polynomials, yielding a state-preserving C*-isomorphism. Its GNS unitary gives a normal *-isomorphism of the generated von Neumann algebras; the given faithful normal representations are normally isomorphic to that GNS realization. Hence the normal triple (M,T,tau) is determined. Conversely such an isomorphism preserves all inverses and continuous functional calculus used for finite referenced baselines, so it preserves the complete profiles.

## Necessity

Take any member G in the class and write its Omega,T,M,tau in its own output representation. Because the invariant state is tracial, for EVERY projection P in M the trace-class density
 Omega_P=P Omega P+(I-P)Omega(I-P)
is faithful and represents exactly the same state on M:
 Tr Omega_P Z=a tau(P Z P+(I-P)Z(I-P))=a tau(Z).
Define G_P(X)=Omega_P^.5 T(X)Omega_P^.5. It is CPTP (state restriction impliesTP), has the same normalized labelled algebra, and has exactly the same complete profiles.

For a selfadjoint input X, B=T(X), the profile determines
 u(X)=Tr Omega |B|=a tau(|B|).
Every member satisfies ||G(X)||_1<=u(X), by splitting B into positive and negative parts. Choose P=1_(0,infinity)(B). Omega_P commutes with this cut; the positive and negative output parts are then orthogonal, so ||G_P(X)||_1=u(X).

If G is greatest, it dominates G_P, and trace-norm contraction under the deterministic simulator forces ||G(X)||_1=u(X) for EVERY selfadjoint X. In particular take X=H_i−t I for each Hermitian basis generator and thresholds t with tau(1_{t}(T(H_i)))=0. Equality in the positive trace-class triangle inequality forces orthogonal positive and negative supports, hence
 (T(H_i)−t)_+ Omega (t−T(H_i))_+=0.
Bounded inverse on epsilon-truncated positive/negative spectral subspaces and a strong limit imply the cross-cut block ofOmega vanishes. Faithfulness removes the equality spectral subspace at these thresholds. Thus Omega commutes with a dense family of spectral cuts of every generator, hence allT(H_i) andM.

Omega has a countable orthogonal decomposition into finite-dimensional positive-eigenvalue spaces H_l spanning H (compactness and faithfulness). Every H_l reduces M because Omega commutesM. Restriction pi_l:M->B(H_l) is a normal finite-dimensional representation; their kernels intersect only at zero. The kernel of each normal representation is a central ideal M(1−z_l), and M z_l is finite-dimensional. The central supports z_l have supremum1. Decomposing their countable union into disjoint central pieces shows M is atomic with finite matrix factors. This conclusion concerns the von Neumann algebra, not a false assertion that its norm-closed C*-subalgebra must be an algebraic direct sum.

## Sufficiency

Suppose M=product_j M_(n_j), tau=Σ p_j tr_(n_j), p_j>0. The given Gamma has trace-one outputs: TrGamma(X)=a tau(T(X))=TrX, and positivity/complete positivity hold blockwise. Its normalized map is the multiplicity-oneT and its state is tau; thus it is in the same profile class.

For any class member F on H_F, let pi:M->W*(T_F(M_a)) be the normal labelled state-preserving isomorphism and Omega_F=F(I). For each finite block define
 R_j(Y)= [n_j/(a p_j)] Omega_F^.5 pi_j(Y) Omega_F^.5,
where pi_j(Y) is zero off the jth intrinsic central summand. Each R_j:M_(n_j)->T(H_F) is CP and trace preserving, since Tr Omega_F pi_j(Y)=(a p_j/n_j)TrY. Define
 R(Y)=Σ_j R_j(P_j Y P_j)
for Y in T(H0), with block pinching. Positive inputs have positive trace-norm-summable terms with total traceTrY; general inputs extend linearly as a contractive CPTP map. Its adjoint is the bounded block-diagonal normal UCP map whose jth block is R_j^*. Thus no unbounded global inverse or infinite norm Kraus matrix is assumed.

On Gamma(X), h_j=a p_j/n_j cancels in each term. Normality of pi and strong sum of central projectors imply
 R Gamma(X)=Omega_F^.5 pi(T(X)) Omega_F^.5=F(X),
with trace-norm convergence of these dominated series. Hence Gamma is greatest.

## Scope, consequences and open operation

This theorem would extend the finite greatest-member mechanism to a complete criterion for TRACIAL infinite-output invariants and exhibit diffuse obstructions. It subsumes atomic binary reverse tests and their failure to fit as a greatest normal density-operator output when diffuse. It does not claim that every invariant has tracialtau; the original finite theorem explicitly allows nontracial states. Nor does it claim practical synthesis, efficient tomography of infinitely many matrix blocks, an ordinary quantum-capacity evaluator, or a noncommutative general-infinite greatest theorem. The general nontracial infinite case is the decisive remaining operator-algebraic question.

Primary predecessors: faithful noncommutative moment/GNS reconstruction; Matsumoto spectral reverse tests; Hiai maximal divergences and diffuse L-infinity reverse tests; finite atomic normal conditional expectations. Newness of the criterion as a combined statement is not established by its proof.
