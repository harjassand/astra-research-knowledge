# Final focused priority reduction: the canonical ordinary experiment

6 November 2026. Requested final targeted check, using the existing caches and
small primary web passages; no new agents or large PDF downloads. This is an
addendum to `priority_structural.md`, not a new novelty claim.

**Verdict:** the abstract-experiment dictionary is valid. The exact
type-I-realization criterion is an established minimal-sufficiency/normal-
expectation consequence. The proposed published generic theorem asserting
Le Cam approximation by type-I experiments iff injectivity was **not verified**.
Guţă--Jenčová's actual convergence theorem does not state it and, under its
canonical-state domination hypothesis, cannot handle a diffuse limit. Nor
would the generic theorem alone automatically establish B's exact-profile
membership/common-source quantifiers. The missing reductions are identified
below. No historical clearance follows.

## 1. The ordinary canonical experiment is well defined

Retain the finite-input faithful normal tracial invariant (M,T,tau). The
predual channel

    K:M_a -> L1(M,tau),       K(X)=aT(X)

is CP and trace preserving because a tau(T(X))=Tr X. Its states are the
ordinary experiment psi_rho(z)=a tau(T(rho)z).

For each physical exact-profile realization F with representation pi and
density Omega, define on bounded densities

    R_Omega(aB)=Omega^(1/2)pi(B)Omega^(1/2).

This extends to a normal CPTP predual map L1(M,tau)->S_1(H_F). Here is a
direct proof, including the needed normality: for X>=0 in B(H_F), the
functional

    B -> Tr[Omega^(1/2)pi(B)Omega^(1/2)X]/a

is positive on M and at most ||X||tau(B) for B>=0. Its bounded tracial
Radon--Nikodym density defines R_Omega^*(X) in M. Matrix positivity gives CP;
R_Omega^*(I)=I. For an increasing bounded positive net X_alpha up to X,
monotone convergence of the trace pairing against every positive B gives
normality. The predual map therefore exists, and the displayed formula is
its action on bounded densities. Thus

    F=R_Omega K

exactly. No inverse of compact Omega or global bounded Radon--Nikodym
density for arbitrary L1 input is required.

One finite faithful subexperiment already has minimal sufficient algebra M.
Take a Hermitian traceless basis H_i with ||H_i||<=1, rho_0=I/a and
rho_i=I/a+epsilon H_i, 0<epsilon<1/a. Its densities relative to tau are

    h_0=I,       h_i=I+a epsilon T(H_i)>0.

The reference state is tau, whose modular group is trivial. Its Connes
cocycles are h_i^(it). Their generated von Neumann algebra contains each
h_i (equivalently log h_i) by bounded functional calculus, and hence is M.
Petz's cocycle sufficiency criterion therefore makes M the minimal ordinary
sufficient algebra. This application matches the faithful-state hypotheses
of Guţă--Jenčová, Corollary3.4/Theorem3.3, and the general minimal-sufficiency
framework of Kuramochi2017, Theorems1--3.

## 2. Exact type-I realization is already a standard consequence

Suppose the finite subexperiment of K were ordinary CP-equivalent to a
density-operator experiment on B(H). After effective-support compression its
mean state is faithful. Kuramochi2017, Theorems1 and3, constructs its minimal
sufficient subalgebra N as the range of a normal state-preserving conditional
expectation from B(H). Uniqueness identifies N normally with M.

The established normal-expectation criterion forces N to be atomic type I.
This criterion is explicitly recalled in Okamura--Ozawa2015, sectionIV,
paragraph preceding TheoremIV.1, and underlies Kuramochi2017's Theorem5.
Because M carries a faithful finite tracial state, its atomic factors are
finite matrix factors; separability makes their index set countable.
Conversely those blocks have the familiar multiplicity-one density-operator
realization. Thus the **ordinary-equivalent type-I realization** criterion
for K is already an application of established theorems.

To turn this into T, one must additionally show that a greatest member among
the particular physical R_Omega K realizes K itself. Greatestness among these
coarse-grainings is not ordinary equivalence by definition. The saved pinched
Bayes-envelope argument establishes the required bridge; an unproved
identification of the two orders would skip the load-bearing step.

## 3. Guţă--Jenčová's actual convergence theorem does not supply the generic iff

Primary source: [Guţă--Jenčová, *Local asymptotic normality in quantum
statistics*, quant-ph/0606213v2](https://arxiv.org/pdf/quant-ph/0606213v2),
**Definition3.10, Lemma3.15 and Theorem3.16, pp19,22--23**. Their strong
convergence is two-sided Le Cam deficiency. Theorem3.16 assumes finite Theta,
canonical states omega_n all dominated by B psi for one fixed canonical
experiment psi, and type-I/discrete-center minimal sufficient algebras for
the approximants. Under those assumptions it equates weak canonical-state
convergence and strong convergence. **Section7, question2, p37**, explicitly
identifies broader weak/strong convergence and finite-dimensional
approximation as further questions.

The domination is of the **canonical states**, not merely bounds such as
c tau<=psi_theta<=C tau within K. The hypotheses therefore cannot be checked
by the bounded likelihoods of our finite input states.

There is a more decisive obstruction to this proposed import. In their proof,
omega_n has a central support p_n in M_psi, and each p_n M_psi is atomic typeI.
Set p=sup_n p_n. The entire approximating family is supported on the atomic
central part p M_psi. Lemma3.15 turns the canonical convergence into weak
convergence of normal states on M_psi, so the limit is also supported on p.
Consequently its minimal sufficient algebra is atomic type I as well. The
theorem cannot supply a diffuse abelian or hyperfinite II_1 limit. It is not
the desired injective-versus-noninjective approximation theorem.

## 4. What the other verified sources do and do not give

Kuramochi2017's [minimal sufficient experiments paper](https://arxiv.org/pdf/1701.03394v2),
Theorems1--3 and5, concerns exact equivalence and quantum outcome realization.
Kuramochi2018's [directed-completeness paper](https://arxiv.org/pdf/1805.04357v2),
Theorems3--4 and Corollary1, constructs monotone order limits in the larger
von Neumann category. It does not identify Le Cam closure of all type-I
experiments or prove injectivity is necessary for approximating one finite
minimal experiment. In particular an exact-profile fiber has not been shown
to be a directed set, so the order-completeness theorem cannot simply be
applied to that fiber.

The injective **sufficient** direction is routine from an AFD filtration:
tau-preserving finite-algebra expectations give finite experiments K_n;
their inclusion lifts recover K with error controlled by finitely many
L2(tau) errors of the labelled densities. This already gives external finite
type-I approximants. It does not provide the converse for an arbitrary
sequence of approximately equivalent experiments.

Okamura--Ozawa/Anantharaman-Delaroche provides normal CP retractions
approximating id_M point-ultraweakly when M is injective, and the converse
when such retractions are supplied. An approximate reverse on finitely many
states is not such an approximate retraction on all of M by definition.
Minimal sufficiency is an exact uniqueness property; one needs an additional
stability argument to upgrade finite-state recovery to the required algebra
criterion. That upgrade was not verified as a theorem in these sources.

One directly relevant later primary result was checked without downloading a
large PDF: [Jenčová, *Recoverability of quantum channels via hypothesis
testing*, Lett.Math.Phys.114,31 (2024)](https://doi.org/10.1007/s11005-024-01775-2),
**Theorem5 and Remark3**. For density-operator pairs and an existing channel,
an additive uniform deficit epsilon in all norms ||rho-s sigma||_1 yields
a recovery channel fixing sigma, with rho-error bounded by
sqrt(2 epsilon D_Omega(rho||sigma)); bounded likelihood ratios make this
nontrivial. The theorem is on trace-class Hilbert-space states, and concerns
recovery through a specified channel, not approximation of an arbitrary
von Neumann experiment by type-I experiments. It is nevertheless a strong
predecessor for any broad claim that Bayes-deficit-to-recovery is new.

## 5. The two reductions that would be needed to absorb B

A hypothetical published result

    K has vanishing two-sided Le Cam distance to type-I experiments
                 iff its minimal sufficient M is injective

would be a serious near-subsumption, but not yet a literal proof of B.

* From arbitrary type-I approximants to B: their states need not have the
  exact normalized labelled generators T or all their moments. One must
  produce exact-class sources, for example by a proved Petz/Stinespring
  lifting and exact-state correction lemma. Such a lemma was not located or
  proved here. The saved Haar construction earns exact membership directly.
* From B's pointwise sequence to that generic theorem: every G_n is a
  coarse-graining of K, but pointwise dominance over every physical class
  target does not by definition supply a recovery G_n->K. One needs the
  fixed pinched Bayes targets, a suitable general-von-Neumann recoverability
  theorem, or another argument identifying K as the relevant operational
  envelope. The direct deficit-to-hypertrace proof already supplies the
  necessity without presuming such an envelope theorem.

Conversely, if two-sided Le Cam approximants to the **finite faithful basis
subexperiment** are supplied, their errors can be extended to the finite
input channel by linearity and a fixed finite-dimensional norm constant.
That step is routine; it is not the obstacle. The obstacles are injectivity
necessity for that generic approximation and exact-fiber realization.

## 6. Focused queries, evidence and final scope

Only this specific reduction was searched, using the cached papers and these
targeted phrases: `quantum statistical experiments injective approximation`;
`quantum experiments finite dimensional approximate sufficiency`;
`statistical experiments minimal sufficient hyperfinite`;
`Le Cam type I quantum experiments approximation`;
`quantum experiments strong convergence injective`;
`quantum experiments type I dominated`;
`quantum statistical experiments finite-dimensional approximation`;
`approximately sufficient injective quantum`.

The most pertinent returned successor was Jenčová2024; its published
Theorem5 and setting were read directly. No generic iff theorem matching
the proposed reduction was verified. The existing local PDF/text cache is
sufficient to reproduce the Guţă--Jenčová and Kuramochi checks; no additional
large downloads were made. A sparse search result is not a nonexistence proof.

**Final assessment:** no automatic collapse of B to the checked published
generic-experiment theorem, because that theorem was not found at the needed
scope. The exact ordinary realization part is known, and B still uses old
amenability and recovery machinery. Historical priority remains unresolved,
with the narrow residual claim stated in `priority_structural.md`.
