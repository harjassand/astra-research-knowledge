# Machinery challenge report

6 November 2026. Initial report was saved before reading the other researchers.
For this challenge I read `initial/auditor.md`, `initial/principal.md`,
`principal_finite_probe_and_stability.md`, `principal_noise_regularization.md`
and `principal_infinite_binary_boundary.md`. I did not alter the initial report.

## Findings

* Both polynomial witness arguments survive checking. The auditor's univariate
  degree/grid proof is the shortest complexity proof; my tail argument supplies
  a closed-form parameter and an explicit analytic margin. They are compatible.
* The principal's stability theorem has the right compactness, semialgebraic and
  generation-margin hypotheses. The published Łojasiewicz import is correct.
  A stronger positive interface uses **only `2a²(b²−1)+1` fixed rational faithful
  state pairs**, each with reference dimension `2b²`, instead of an exponentially
  large word/grid list. A terminating exact offline selection algorithm exists;
  its bit-size and runtime are not shown polynomial. This is an application of
  established generic-identification machinery, particularly Sontag 2002.
* **Complete RLD order does not become deterministic processing order after
  canonicalization.** A rational, full-Choi-rank classical-output counterexample
  has complete **reference-operator** RLD dominance but deterministic-processing
  diamond deficiency at least `2/15`. Both channels already are greatest members
  of their classes. The proof below includes arbitrary noncommuting references.
* The principal's binary infinite-output atomicity criterion is sound after the
  indicated normality/form-domain details. Hiai's spectral reverse test and
  Kuramochi's discrete-versus-fully-quantum realization theorem are major
  predecessors. The underlying atomicity obstruction is established; the exact
  bridge from “greatest member of the maximal-profile class” to that obstruction
  must be retained and credited as an application, with novelty unassessed.
* The proposed **tracial** infinite-algebra extension is also sound at its stated
  scope. Traciality is exactly what makes spectral pinching preserve the whole
  invariant. Removing it is not justified by this proof.

## 1. Challenge of the polynomial physical-witness constructions

### 1.1 Word closure and bits

The common safe closure procedure starts with the paired raw identity
`(Omega_E,Omega_F)` and appends one input-basis generator at a time, retaining
linearly independent **actual words**. Its dimension is at most
`N=rank(Omega_E)²+rank(Omega_F)²`; retained word lengths are at most `N−1`.
Arbitrary multiplication of already long words is not itself a polynomial-bit
argument. The auditor correctly isolates that implementation condition.

Exact range projectors and Moore–Penrose inverses are rational-complex. For
independent range columns `V`, use `P=V(V*V)^−1 V*` and invert the positive
matrix padded by `I−P`. Determinant bounds give polynomial entry bit lengths.
At most `N−1` generator multiplications and polynomially many exact rank tests
therefore have polynomial bit cost in the explicit rational Choi input. This
does not follow solely from an arithmetic-operation bound in quantum-automata
literature; the bit bound is the additional elementary rational-matrix argument.

[Li–Qiu, arXiv:quant-ph/0604085v2](https://arxiv.org/pdf/quant-ph/0604085v2),
Theorem 2, is a verified predecessor for basis-pruned closure and returning a
short separating word. It does not supply the present conversion to faithful
quantum input states, nor a free physical implementation of inverse matrices.

### 1.2 Degree/grid route

For a differing length-`n` word put every path variable equal to `t`. The
`(0,n)` resolvent entry has no term below degree `n`, and its degree-`n`
coefficient is the nonzero ordered-moment difference. At least one of the four
projector expectations onto `e_0,e_n,(e_0+e_n)/sqrt(2),
(e_0+i e_n)/sqrt(2)` is a nonzero rational function of `t`.

A rational interval with `|t| n<=1/2` makes every physical input faithful. For
fixed channels the support projectors are constants. Pad the output baseline
by `P_perp tensor I`, invert the full matrix, and note that every tangent
output is supported on `P tensor I`; the padding contributes zero to RLD.
The padded determinant has degree at most `br` for one channel and `cr` for
the other, with `r=n+1`. Centering the tangent from `I tensor P` changes the
two quadratic forms by the same constant. Thus after clearing the two positive
denominators, the difference numerator has degree at most `r(b+c)` (a safe
bound, not an optimal one). Evaluating the four tests at that many plus one
distinct rational points guarantees a nonzero value.

This establishes polynomially many polynomial-size exact evaluations. Each
nonzero rational value itself supplies a polynomial-encoding-length exact
margin. There is no numerical zero test and no multivariate PIT conjecture.

### 1.3 Tail route, faithful pair and orientation

My initial route is valid independently of that degree count. For a nonzero
real or imaginary component `d` of the word difference, choose

`t=min{1/(2n), |d|/(8 n^(n+1))}`.

The unwanted tail is at most `4 n^(n+1)t^(n+1)`, so it cannot cancel the
leading component `d t^n`. A projector test has absolute RLD gap at least
`a² r |d|t^n/4`. For its centered tangent `H'=I tensor P−a rho`, choose
`s=1/(8ar)` and `sigma=rho+sH'`. Then

`rho>=I/(2ar)`, `sigma>=I/(4ar)`, and

`Dhat_(x−1)^2(E_R(sigma)||E_R(rho))=s² g_E(rho,H')`.

The state-pair **orientation is `(sigma || rho)`**, with `rho` the baseline.
Its absolute gap is at least `|d|t^n/(256r)`. A negative gap establishes
inequivalence just as a positive one does; neither construction automatically
returns a violation of whichever directed order the caller specifies. The
general directed comparison problem is still N1690's separate evaluator.

Both methods can be retained: use the degree/grid route for a short terminating
compiler proof and the tail route when an explicit emitted gap is useful.

## 2. A polynomial number of fixed physical state pairs

### 2.1 The theorem

Fix `a,b>=2`, and let `C` be all CPTP maps `M_a -> M_b` with `Omega_E=E(I)>0`.
Choi rank need not be full. Put

\[
 m=a^2(b^2-1),\quad r=2b^2,\quad d=ar,\quad k=2m+1.
\]

**Compressed physical-probe theorem.** There exist `k` fixed pairs of
rational-complex faithful density matrices `(sigma_j,rho_j)` on
`C^a tensor C^r`, depending only on `a,b`, such that

\[
 E\sim_{\mathrm{complete\ maximal}} F
 \quad\Longleftrightarrow\quad
 \widehat D_{(x-1)^2}(E_R(\sigma_j)\Vert E_R(\rho_j))
 =\widehat D_{(x-1)^2}(F_R(\sigma_j)\Vert F_R(\rho_j))
 \quad(1\le j\le k).
\]

Both members of every pair have spectral floor at least `1/(2ar)`. Almost
every tuple from the explicitly described open physical-probe box below works;
the bad tuples lie in a lower-dimensional semialgebraic set. A deterministic
terminating rational-selection algorithm is given in §2.4. No polynomial bit
bound for the selected coefficients or for this offline algorithm is claimed.

For example `a=b=2` gives `k=25` state pairs with reference dimension eight.
These are nonlinear RLD/divergence **probes**, not twenty-five elementary POVM
outcomes. Their acquisition may require output tomography and repeated trials.

### 2.2 A fixed reference suffices to distinguish each inequivalent pair

The independent path/word proof gives an inequivalence witness at some
reference dimension `r_0<=2b²`. If `r_0<r`, form a faithful block-diagonal
baseline on the enlarged reference by placing a positive scalar multiple of
the witness baseline in the first block and a maximally mixed input in the
second. Put the original traceless tangent in the first block and zero in the
second. RLD direct-sum homogeneity preserves a nonzero difference, multiplied
by a known positive scalar. Thus every inequivalent pair is distinguishable
at the single fixed reference dimension `r`.

This bound comes from finite word closure and the independently verified
physical bridge. It does not import the huge N1690 free-positivity cutoff.

### 2.3 Incidence-dimension proof

Choose a rational Hermitian traceless basis `B_1,...,B_(d²−1)` with norm at most
one, and use the connected open rational box of probes

\[
 \rho(u)=I_d/d+\sum_\ell u_\ell B_\ell,\qquad
 H(v)=\sum_\ell v_\ell B_\ell,
\]
\[
 |u_\ell|<\frac1{4d(d^2-1)},\qquad
 |v_\ell|<\frac1{d^2-1}.
\]

Call this box `P`, of real dimension `p=2(d²−1)`. Every probe has
`rho>=3I/(4d)` and `||H||<1`. The response

`beta(E,u,v)=g_E(rho(u),H(v))`

is a rational real-valued function of the real channel/probe coordinates;
its denominator is nonzero on `C tensor P`. The channel parameter space is
semialgebraic and has dimension at most `m`: a Hermitian Choi matrix has
`a²b²` real coordinates and the TP constraint removes `a²` independent ones.

For each inequivalent `(E,F)`, the rational function `beta(E,.)−beta(F,.)`
is not identically zero on `P`. Otherwise its numerator polynomial would
vanish on an open box, hence identically in the affine probe variables, and
it would vanish for all faithful baselines and traceless tangents at reference
`r`, contradicting §2.2. Consequently its zero set in `P` has dimension at
most `p−1`.

The complete-profile equality relation is semialgebraic: use the finite list
of paired raw word traces of length at most `2b²−1` as in the initial reports
and clear the nonzero `det(Omega)` denominators. Let `I_k` be the semialgebraic
incidence set of inequivalent channel pairs and `k` probes that all give equal
responses. Fibers over `(E,F)` are products of `k` such zero sets. The
semialgebraic dimension-of-fibers inequality gives

\[
 \dim I_k\le2m+k(p-1).
\]

Its projection `Bad_k` to `P^k` has no larger dimension. At `k=2m+1`,

\[
 \dim Bad_k<kp=\dim P^k.
\]

Thus its semialgebraic closure has empty interior and measure zero. The
complement contains a nonempty open set of rational tuples. Every good tuple
separates all complete-profile inequivalence classes simultaneously. Ordinary
output unitary equivalence is not assumed or inferred at reducible channels.

Finally fix `s=1/(8d)` and replace each `(rho,H)` by
`(sigma=rho+sH,rho)`. Then `sigma>=5I/(8d)`, and the maximal quadratic
divergence is `s² beta`. This proves the physical state-pair statement.

### 2.4 Effective rational selection

Enumerate rational tuples in the probe box by increasing finite encoding
length. For each tuple decide by real quantifier elimination the formula

`for every E,F in C: (all k probe responses agree) implies (all raw word
traces of length <=2b²−1 agree)`.

Every part is a finite rational semialgebraic formula. Inverses are encoded
by polynomial equations or their positive determinants are cleared. The
faithful-probe output baselines are invertible because `Omega>0`. Good rational
tuples exist in a nonempty open set, so the enumeration terminates. This is an
algorithm specification with proved termination, not an executed QE compiler
or a polynomial-time construction.

An immediate simpler improvement of the principal's explicit enormous finite
family is also valid: set all path parameters `z_j=t`, and use `D+1` values
of `t` **per word**, rather than `(D+1)^n` multivariate samples. The first
possible `(0,n)` coefficient still isolates the ordered word. The compressed
theorem above reduces the **number of final probes** much further, at the
price of expensive offline selection.

### 2.5 Exact predecessor and novelty boundary

[Sontag, *For Differential Equations with r Parameters, 2r+1 Experiments Are
Enough for Identification*, J. Nonlinear Sci. 12 (2002), 553–583](https://www.sontaglab.org/FTPDIR/ident-experiments.pdf),
**Theorem 2**, states the corresponding generic `2r+1` result for an analytic
response on a parameter manifold and experiment manifold. Its proof bounds
the bad incidence set by `2r+q(p−1)`, exactly the mechanism used here. The
paper explicitly distinguishes the existence/count of experiments from
construction of practical identification algorithms.

Our channel set has semialgebraic boundary and need not itself be a manifold;
the direct semialgebraic proof above avoids silently assuming that hypothesis.
Equivalently one can stratify it and pad the parameter manifolds. The result
is therefore a **physical RLD interface/application of established generic
identification**, with an effective rational-selection argument. The general
`2m+1` mechanism and its sharpness are not new discoveries. No assertion is
made that this count is optimal for quantum channels.

## 3. Verification of the principal's robust theorem and envelope arguments

On `K_(lambda,kappa)` the full-algebra frame margin supplies what the global
counterexample lacks. The word-frame matrix is continuous for `Omega>=lambda I`
and uses finitely many words. Its lower bound makes `K` closed inside the
compact channel space. The unique positive inverse square root of `Omega`
has a semialgebraic graph, so `K` is semialgebraic. The condition may of course
be empty for inconsistent parameters; a reconstruction promise must include
existence of a true channel in `K`.

The response differences from either the principal's list or the compressed
list are continuous and semialgebraic on `K²`; every output baseline has a
uniform positive floor. If their maximum `f` is zero, complete-profile
classification gives a labelled *-isomorphism `M_b -> M_b`, hence an inner
unitary. The faithful state then identifies `Omega`, giving
`F=Ad_U E`. Thus `f^-1(0)` lies in the zero set of the continuous semialgebraic
unitary-orbit Frobenius distance `d`.

[Basu–Mohammad-Nezhad, *Improved effective Łojasiewicz inequality and
applications*, Forum Math. Sigma 12 (2024), e115](https://doi.org/10.1017/fms.2024.66),
**Theorem 2.2**, has exactly these closed/bounded semialgebraic-domain,
continuous semialgebraic-function and zero-set inclusion hypotheses. After
obtaining quantifier-free descriptions with degree at most `d_0>=2` in `n`
coordinates, its exponent bound is `(8d_0)^(2(n+7))`. The principal's use is
valid. Published **Remark 2.7** explicitly says the coefficient cannot be bounded
from degrees/dimensions alone. Computing a coefficient by enumerating rational
upper bounds and testing the universal inequality by QE is legitimate; calling
that coefficient dimension-only or uniformly well-conditioned would not be.

The conversion

`min_U ||F−Ad_U E||_diamond <= sqrt(ab) [C f(E,F)]^(1/q)`

is valid for the unnormalized Choi convention. The usual inequality
`||Phi||_diamond<=||J_Phi||_1` and trace/Frobenius norm comparison supply the
displayed dimension factor. Combining this with §2 gives a finite robust
identification theorem using a polynomial **number** of fixed faithful state
pairs. Coefficient precision, offline search, Hölder exponent and sample cost
remain separately accounted for. This is not an efficient tomography result.

For the unitary-identification antecedent,
[Jing, *Unitary and orthogonal equivalence of sets of matrices*,
arXiv:1504.06790v1](https://arxiv.org/pdf/1504.06790v1), **Theorem 2.2**, says that
two Hermitian-closed tuples are simultaneously unitarily similar iff ordinary
traces of all words agree. It is an exact primary Specht-type comparator.
Our `tau`-weighted moments are not ordinary traces; one needs the faithful
GNS/kernel argument and innerness on `M_b`. It would be inaccurate to claim
new matrix-tuple reconstruction in general, or to apply the ordinary-trace
statement without that bridge.

The noise-envelope theorem's upper semicontinuity proof is sound: concrete
greatest lifts can be kept in the fixed `M_b`, and their `Omega` floors are
preserved by the unital conditional expectations. A convergent subsequence
therefore preserves every finite physical response and lies in the limiting
profile class. Continuous monotone resources cannot exceed the limiting
greatest member. Dense full-algebra channels then give the stated lower-noise
envelope identity. This is an identity, not a resource-evaluation algorithm.

The finite-data impossibility proof also survives checking. Truncate an
almost-surely finite stopping experiment on the exceptional channel at a large
finite query count; a high-answer event still has probability greater than
one half. The adaptive hybrid estimate changes it by at most
`n ||E_t−E_0||_diamond/2`, so a sufficiently close low-ceiling channel violates
uniform `2/3` accuracy. This is an oracle/continuity obstruction at the ceiling,
not ordinary-capacity undecidability for exact rational matrices.

## 4. Complete RLD order is strictly weaker than canonical processing

### 4.1 Binary classical channels with arbitrary quantum references

Let a channel measure the computational basis of its qubit input and apply a
classical channel `W`, with row vectors `w_z=(W(z|0),W(z|1))`. For an arbitrary
faithful referenced input let `rho_0,rho_1>0` be its two diagonal reference
blocks and `H_0,H_1` the Hermitian diagonal tangent blocks. Off-diagonal input
blocks are discarded. Its reference-valued RLD operator is

\[
 Q_W=\sum_z(w_{z0}H_0+w_{z1}H_1)
       (w_{z0}\rho_0+w_{z1}\rho_1)^{-1}
       (w_{z0}H_0+w_{z1}H_1).
\]

No scalar-reference congruence invariance is assumed. Instead set
`S=rho_0+rho_1`, `A=S^−1/2 rho_0 S^−1/2`, and
`K_i=S^−1/2 H_i S^−1/2`. Then

\[
 Q_W=S^{1/2}\left[\sum_z(w_{z0}K_0+w_{z1}K_1)
    (w_{z0}A+w_{z1}(I-A))^{-1}
    (w_{z0}K_0+w_{z1}K_1)\right]S^{1/2}.
\]

Write `A=sum_j x_j P_j`, `y_j=1−x_j`. For a scalar baseline `(x,y)`, define

\[
 C_W(x,y)=\sum_z\frac{w_z^T w_z}{w_{z0}x+w_{z1}y}.
\]

The bracketed **operator difference** for `W,V` is

\[
 \sum_j\sum_{i,l=0}^1
   [C_W(x_j,y_j)-C_V(x_j,y_j)]_{il}\,K_iP_jK_l.
\]

If every real symmetric coefficient matrix is PSD, each summand is positive:
factor the coefficient matrix and write it as a sum of operators
`(sum_i c_i K_i) P_j (sum_l c_l K_l)`. Hence `Q_W−Q_V>=0`, and undoing the
whitening by the displayed congruence retains positivity. This proves the
comparison for all noncommuting reference blocks and tangents, stronger than
the scalar trace inequality needed for complete RLD order. Faithfulness gives
`0<x_j<1`; endpoints follow by ordinary support limits when needed.

### 4.2 Scalar coefficient identity

For a BSC with crossover `p`, put `c=1−2p`. Let `C_tr` be the coefficient
matrix of the one-output erasure/replacer channel. Direct algebra gives

\[
 C_{\mathrm{BSC}(p)}(x,y)-C_{\rm tr}(x,y)
 =\frac{c^2}{(x+y)((1-p)x+py)(px+(1-p)y)}
      \begin{pmatrix}y\\-x\end{pmatrix}
      \begin{pmatrix}y&-x\end{pmatrix}.
\]

For `x+y=1` and `z=x−y`, the scalar multiplier is
`4c²/(1−c²z²)`. Now let `W` be the flagged mixture of probability `alpha`
of `BSC(p_E)` and probability `1−alpha` of an erasure symbol. Let
`V=BSC(p_F)` with `0<=c_F<=c_E<=1`. Their coefficient difference is PSD
for every baseline iff

\[
 \boxed{\alpha c_E^2\ge c_F^2.}
\]

Indeed, after positive denominators are cleared its multiplier numerator is

`(alpha c_E²−c_F²)+c_E² c_F² z²(1−alpha)`.

Necessity is the uniform baseline `z=0`; sufficiency is termwise positivity.
The reference-operator argument above lifts this exact condition to complete
RLD order, without treating scalar RLD as invariant under nonunitary filters.

### 4.3 Full-Choi-rank counterexample

Choose `alpha=1/3`, `p_E=1/10`, `p_F=3/10`. The classical matrices, with
input columns, are

\[
 W=\begin{pmatrix}3/10&1/30\\2/3&2/3\\1/30&3/10\end{pmatrix},\qquad
 V=\begin{pmatrix}7/10&3/10\\3/10&7/10\end{pmatrix}.
\]

Define quantum channels by `E_W(X)=diag(W diag(X))` and similarly for `V`.
They are rational CPTP, their unnormalized Choi matrices are diagonal, and

`J_W>=I_6/30`, `J_V>=3I_4/10`.

Here `c_E=4/5`, `c_F=2/5`, so
`alpha c_E²=16/75>4/25=c_F²`. Consequently

\[
 Q_W(\rho,H)\succeq Q_V(\rho,H)
\]

for every finite untouched reference, faithful input and Hermitian tangent.
In particular `E_W` completely RLD-dominates `E_V`.

Both channels already are greatest representatives. Their normalized output
generators distinguish all three, respectively two, posterior labels, so the
generated algebras are `C³` and `C²`. Their `Omega` matrices are diagonal and
fixed by the conditional expectations onto those algebras; thus the greatest
lift is the original channel. Both are also multiplicity-one representations.

Yet the trace norms of the two basis-output differences are

\[
 \|E_W(|0\rangle\langle0|-|1\rangle\langle1|)\|_1=8/15,
 \qquad
 \|E_V(|0\rangle\langle0|-|1\rangle\langle1|)\|_1=4/5.
\]

No CPTP output map can increase that norm. More quantitatively, if
`||E_V−R E_W||_diamond<=epsilon`, the two individual state errors give

`4/5 <= 8/15+2epsilon`, hence

\[
 \boxed{\inf_{R\,\mathrm{CPTP}}\|E_V-R E_W\|_\diamond\ge2/15.}
\]

This is a decisive counterexample to the suggested general order collapse,
strictly inside full-Choi-rank channel sets. It does not affect equality-class
classification or the universal greatest member **within one class**.

Exact symbolic verification of the coefficient identity, Choi floors, trace
distances and a noncommuting complex reference example is in
`../checks/machinery_order.py` and `.json`. In that example the full reference
operator difference is exactly positive definite, not merely positive-trace.

### 4.4 Restricted positive order theorem and predecessors

Within the single BSC family `0<=p<=1/2`, complete RLD order **does** coincide
with deterministic processing: it holds from `p` to `q` iff `p<=q`. Necessity
comes from the maximally mixed baseline and `sigma_z` tangent, which give a
quadratic form proportional to `(1−2p)²`. Sufficiency is the bit-flip
postprocessing with crossover `(q−p)/(1−2p)`; the endpoint `p=1/2` is handled
separately. Within erasure channels, the complete order likewise coincides
with decreasing reveal probability, directly from
`g_BEC=alpha g_identity+(1−alpha)g_trace` and erasing additional labels.

The broad separation is established classical machinery. In particular
[Nair, *Capacity regions of two new classes of 2-receiver broadcast
channels*](https://staff.ie.cuhk.edu.hk/~cnair/pub/papers/BC/twoclass-full.pdf),
**Claim 4**, gives BEC/BSC less-noisy-but-not-degraded parameter ranges.
[Makur–Polyanskiy, arXiv:1609.06877](https://arxiv.org/pdf/1609.06877) establishes
classical less-noisy comparison through chi-square divergence in **Theorem 1**:
for two Markov kernels on the same source space, less-noisy comparison is
equivalent to chi-square comparison for every pair of input probability measures.
Our finite classical channels meet those hypotheses. The present
counterexample uses that mechanism plus the explicit binary reference-operator
lifting proof. It is not a new separation of the classical less-noisy and
degradation orders. The useful conclusion is that this known separation
survives precisely the complete physical RLD interface and canonicalization.

A terminology check matters here: the recent
[Hirche, arXiv:2610.03706](https://arxiv.org/pdf/2610.03706), §3.2 equation (3.13),
explicitly uses the **BKM** metric for its quantity called quantum chi-square.
Its complete-order results cannot be transferred to the present RLD form just
by identifying the names of the divergences.

## 5. Infinite binary-output boundary: proof challenge and prior work

The principal's theorem is valid for the stated category: normal channels from
`M_2` into trace-class operators on a separable Hilbert output, with complete
profiles defined through the dominated normalized sandwiches. Let
`Omega=rho_0+rho_1` be faithful on the compressed support and
`A=Omega^−1/2 rho_0 Omega^−1/2`, interpreted as a bounded positive contraction.

### 5.1 Details that make the proof rigorous

1. A bounded faithful normalized baseline `B_0>=cI` yields output
   `B=Omega^1/2 B_0 Omega^1/2`. The operator
   `C=Omega^1/2 B_0^1/2` is injective with dense range; its polar
   decomposition is `C=B^1/2 U` with `U` unitary. For another normalized
   positive bounded argument `D_0`, the output relative operator is unitarily
   equivalent to `B_0^−1/2 D_0 B_0^−1/2`. This supplies the perspective
   sandwich identity even though `Omega^−1/2` is unbounded. The finite-input,
   faithful-baseline dominance keeps every function evaluated on a compact
   positive spectral interval. No bounded inverse for `Omega` is assumed.
2. Equal complete profiles force any competing channel to kill input
   coherences: the zero `sigma_x,sigma_y` RLD tests at the maximally mixed
   input force their outputs to vanish by faithfulness of the weighted
   normalized positive form. Thus comparison with all trace-class channels
   really reduces to the binary measure-and-prepare family.
3. Equality of the scalar RLD function along diagonal faithful baselines
   identifies all moments of `2A−I`, starting at degree two; mass and first
   moment are fixed by TP. Compact moment determinacy identifies the measure
   `mu(B)=Tr(Omega 1_B(A))/2`. References are needed for the wider theory but
   not for this final binary moment-determinacy step.
4. Pinching `Omega` across an atom-free spectral cut preserves this measure
   and therefore the full complete profile. It also remains faithful trace
   class. The corresponding binary Bayes trace-norm bound is attained.
5. Equality in `||X−Y||_1<=Tr X+Tr Y` for positive trace-class operators is
   equivalent to orthogonal supports. Thus a greatest member attaining every
   cut bound has `(A−t)_+ Omega (t−A)_+=0`. Bounded inverse cutoffs at distance
   at least epsilon from `t`, followed by strong limits, give
   `P_(t,1] Omega P_[0,t)=0`. Use a dense countable set of atom-free `t`;
   faithfulness makes the equality-atom spectral projection zero. Hence
   `Omega` commutes with `A`.
6. A faithful compact positive `Omega` has finite-dimensional positive
   eigenspaces spanning the output. A commuting selfadjoint `A` diagonalizes
   on each. Therefore `mu` is countably atomic. Conversely, for atomic `mu`,
   the stated diagonal channel and conditional preparations are normal CPTP;
   the infinite positive sums converge in trace norm since their traces sum
   to the input trace.

The Fourier fixture is correct: the weights `(2/3)2^−|n|` sum to two, every
Fourier vector has constant modulus one, and `A=M_x` therefore gives uniform
`mu` on `[1/4,3/4]`. Its two density operators have trace one and are bounded
between `Omega/4` and `3Omega/4`, so they are faithful and uniformly relatively
comparable. This is a mathematical channel, without a claimed finite physical
preparation cost or laboratory implementation.

### 5.2 Substantial priority overlap

[Hiai, *Quantum f-divergences in von Neumann algebras II. Maximal
f-divergences*, arXiv:1807.03118v1](https://arxiv.org/pdf/1807.03118v1),
**Lemma 6.1** constructs the normal CP spectral reverse test on
`L_infinity([0,1],nu)` using the spectral measure of the bounded likelihood.
**Theorem 6.3** says it attains the maximal-divergence reverse-test minimum
and allows a standard Borel probability space on `[0,1]`. This is already the
ideal possibly diffuse classical experiment used here. The atomic construction
is its countable discrete specialization.

[Kuramochi, arXiv:1701.03394v2](https://arxiv.org/pdf/1701.03394v2),
**Lemma 6 and Theorem 5**, pp. 25–26, prove that a POVM is postprocessing
equivalent to a discrete POVM iff its channel is CP-concatenation equivalent
to one with a fully quantum outcome algebra `B(H)`. **Remark 4** explicitly
connects the absence of a continuous fully-quantum realization to the absence
of a normal conditional expectation onto a diffuse abelian subalgebra and
credits Holevo 2012 for that observation.

The operator-algebraic obstruction is even older. I acquired and visually
read the scanned primary
[Størmer, *On Projection Maps of von Neumann Algebras*, Math. Scand. 30
(1972), 46–50](https://doi.org/10.7146/math.scand.a-11062). Its unnumbered
**Theorem on p. 47** characterizes complete families of normal projection maps
from a type-I algebra `R` onto a subalgebra containing its center: the
subalgebra is type I and its center is totally atomic over the center of `R`.
A faithful normal conditional expectation is a complete family by itself.
For `R=B(H)` this yields the atomic-algebra obstruction. Cached page PNGs
document the primary visual inspection; no invented theorem number is used.

The exact inference “a greatest trace-class member must attain every Bayes
envelope, hence realize the spectral reverse experiment” is the applicability
bridge supplied by the principal's proof. Hiai's theorem by itself concerns
a reverse-test minimizer in a larger algebraic category; Kuramochi's theorem
by itself concerns ordinary concatenation equivalence. Neither should be
silently relabelled as the new profile-class greatest theorem. Conversely,
calling the diffuse/atomic normal-realization obstruction new would overstate
the contribution. Historical priority for the assembled criterion remains
unassessed.

## 6. The tracial infinite-algebra extension

The extension communicated by the principal and auditor is valid under these
explicit assumptions: finite-dimensional input; separable Hilbert trace-class
outputs; normalized generators forming a von Neumann algebra `M`; faithful
normal **tracial** restricted state `tau`; and the normal moment/GNS
classification used to transport `M,T,tau` between realizations.

The last classification needs a small infinite-dimensional supplement to the
finite polynomial-kernel proof. For faithful `tau`,

`||p|| = lim_n tau((p* p)^n)^(1/(2n))`.

Thus equal moments preserve operator norms and extend the labelled polynomial
map to a C*-isomorphism. The state-preserving GNS unitary then extends it to a
normal isomorphism of the generated von Neumann algebras. No finite word bound
or finite rational compiler is inferred in this step.

For a spectral cut `P` of a Hermitian generator, put
`Omega'=P Omega P+(I−P)Omega(I−P)`. For all `B in M`,

`Tr(Omega' B)/a = tau(PBP+(I−P)B(I−P)) = tau(B)`.

The second equality uses traciality essentially. The pinched channel is
therefore in the same full invariant class. A greatest member must attain the
trace-norm envelope for every shifted Hermitian input generator, exactly as
in the binary argument, forcing its faithful compact `Omega_G` to commute
with every generator and hence with `M`.

Its finite-dimensional positive-eigenvalue eigenspaces carry finite-dimensional
normal representations of `M` which jointly separate points. To see why this
forces atomic **finite** matrix blocks, each finite-dimensional normal
representation has a weakly closed ideal kernel, so is faithful on a central
summand which is finite-dimensional. Their central supports have supremum one.
Splitting these countably many finite-dimensional central summands yields

`M = product_j M_(n_j)` with countably many finite `n_j`.

Conversely write `tau(B)=sum_j p_j tr(B_j)/n_j`, with `p_j>0` and sum one.
On `directsum_j C^(n_j)` set `h_j=a p_j/n_j` and
`Gamma(X)=directsum_j h_j T_j(X)`. This is faithful trace class on the joint
support and CPTP. For another realization `(pi,Omega_F)`, first pinch any
trace-class `Y` to its diagonal blocks `Y_j`, then set

`R(Y)=sum_j h_j^−1 Omega_F^1/2 pi_j(Y_j) Omega_F^1/2`.

For positive `Y_j`, the `j`th term's trace is exactly `Tr Y_j`, by the state
restriction. Hence the positive sum converges in trace norm and defines a
bounded CP, TP normal map even though the displayed coefficients may grow.
Its composition with `Gamma` is `F`. This proves sufficiency with no hidden
bounded-inverse assumption on the sequence `h_j`.

The countable finite-matrix criterion is therefore a sound sharp theorem at
the tracial scope. Its algebraic necessity is closely aligned with the old
normal-expectation/atomicity theorems just discussed; the contribution is the
specific greatest-profile applicability bridge and converter construction.
General nontracial infinite-output existence is not settled. In particular,
the pinching identity above fails without traciality. Atomic type-I algebras
with infinite factors can carry faithful normal nontracial states, so one must
not extrapolate the word **finite** from the tracial theorem to that setting.

## 7. Deliverables and status

All new primary PDFs and text are in `../literature/machinery/`, with hashes
in `SOURCE_MANIFEST.json`. New exact order checks are in
`../checks/machinery_order.py` and `.json`; the earlier witness checks remain
unchanged. The original N1690/N1698 proof/compiler packages remain unacquired.

| Result | Challenge status | Limit |
|---|---|---|
| Polynomial physical witness | Confirmed by two distinct polynomial routes | Explicit matrices; inequivalence, not arbitrary directed-order failure |
| `2a²(b²−1)+1` fixed rational state-pair probes | Proof and terminating selection algorithm supplied | Offline selector not executed; no polynomial coefficient/runtime bound |
| Hölder rigidity on generation-margin compacta | Principal proof verified; compatible with compressed list | Established semialgebraic machinery; conditioning essential |
| Canonical-order collapse | Disproved by full-Choi counterexample with deficiency `>=2/15` | Does not challenge equality-class greatest theorem |
| Binary infinite-output greatest iff atomic | Independently checked | Normal trace-class category only; major reverse-test/expectation predecessors |
| Tracial infinite-output greatest iff countable finite blocks | Proof checked with normal-representation and convergence details | No nontracial extension claimed |
| Practical transmission advantage / capacity evaluation | Not established | No such conclusion from probe counts or algebraic existence |

## 8. Final hard-route audit: approximate greatestness iff injectivity

The principal's hypertrace converse and the constructor's exact-class Haar
repair now close a stronger theorem. Full independent proof and verified
imports are in [machinery_approximate_greatest_converse.md](machinery_approximate_greatest_converse.md).
At faithful normal **tracial**, finite-input, separable trace-class-output
scope, the following are equivalent: injectivity of the generated normal
invariant algebra; uniform approximate greatest members **inside the exact
class**; and a single sequence in that class pointwise asymptotically
dominating every fixed class target. The converse actually requires only
countably many fixed spectral-cut Bayes targets. A noninjective invariant
therefore has a finite fixed target list with a positive common simulation
obstruction; neither the list nor its margin is made effective.

The trace-norm deficit estimate is proved directly by a Helstrom projection
and Schatten Cauchy--Schwarz. Near-band truncation then earns spectral-cut
commutation, and the fixed trace state extends this to all of M via L2
density. A weak-* hypertrace on the direct-sum representation constructs a
norm-one CP projection. **That projection need not be normal.** This is why
diffuse injective invariants admit approximate greatest members while the
exact theorem still requires countable finite matrix blocks.

The exact general-center primary import is Connes, *On the Classification
of von Neumann Algebras and Their Automorphisms*, IHES/P/76/132 (1976),
Theorem4.1, printedp43/PDFp46. Its following paragraph explicitly explains
the passage beyond factors through direct integrals. Connes,
*Noncommutative Geometry* (1994), ChV section7 Theorem6,p504 independently
states the arbitrary-vNA equivalence; Definition17,p500 gives the increasing
finite-dimensional filtration. The representation-independence needed for
the free-group counterexample is explicit in the latter's ChV section7beta,
Definition2 and following paragraph,p502, and the former's printedp42/PDFp45.
Both sources and hashes are cached. Thus no unproved factor-to-center or
representation switch remains.

I also checked the dossier's explicit L(F2) realization and general
finitely-generated finite-tracial realization lemma. The star Choi floors,
trace-class state restrictions, group-word trace tail and invariant-mean
contradiction are sound. In the general lemma take m>=1 (a redundant zero
generator handles the scalar algebra). None of these checks assumes a
finite-generator theorem for all separable finite von Neumann algebras.

**Final status:** no concrete mathematical blocker found in dossier
Theorems W, P, S, T or B at their stated scopes. The Sontag selector remains
an unexecuted terminating construction without a polynomial complexity bound;
historical priority of the combined operational characterizations remains
unestablished. The established Connes, Størmer, Kuramochi, Hiai, Sontag,
Specht and semialgebraic machinery must retain explicit attribution.
