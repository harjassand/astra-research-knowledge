# Exact-class approximate greatest members characterize injectivity

6 November 2026. Existing-machinery researcher's challenge of the principal's
hypertrace converse, after the constructor's Haar-averaging repair. No additional
agents used. **Status: proved at the faithful normal tracial, finite-input,
separable-output scope below.** General-center injectivity/hyperfiniteness is
imported explicitly from Connes. Priority of this operational application remains
unestablished.

## 1. Statement and exact operational quantifiers

Let E:M_a -> S_1(H) be a channel, a finite, H separable. Compress to effective
support so Omega=E(I) is faithful positive trace class, Tr Omega=a. Write

    E(X)=Omega^(1/2) T(X) Omega^(1/2),
    M=W*(T(M_a)),       tau(x)=Tr(Omega x)/a.

T is bounded UCP. Assume tau is **tracial**; faithfulness and normality already
follow from Omega. The exact complete-profile class C consists of finite-input,
separable density-operator-output realizations of the same labelled normal
invariant (M,T,tau). The infinite-output moment/GNS reconstruction in dossier
Theorem T identifies this with equality of the specified complete RLD/maximal
profiles. Each G in C therefore has a faithful normal representation pi_G of M,
faithful Omega_G with Tr Omega_G=a, and

    G(X)=Omega_G^(1/2) pi_G(T(X)) Omega_G^(1/2),
    Tr(Omega_G pi_G(x))=a tau(x).

All processing is deterministic normal CPTP. Define the one-way deficiency

    d(F|G)=inf_R ||F-RG||_diamond.

The infimum need not be attained. These are equivalent:

1. M is injective.
2. There is an increasing sequence of finite-dimensional unital subalgebras
   N_n with L2(tau)-dense union.
3. For every epsilon>0 there is **G_epsilon in C** with
   sup_(F in C) d(F|G_epsilon)<=epsilon.
4. There is a sequence **G_n in C** such that, for each fixed F in C,
   d(F|G_n)->0. Uniformity in F is unnecessary for this implication.
5. Every finite collection of the spectral-cut Bayes tasks below can be jointly
   made arbitrarily close to its tracial envelope by one G in C.

Given a supplied filtration in (2) with tau-preserving expectations E_n, the
constructor's explicit sources satisfy the uniform bound

    sup_F d(F|G_n) <= epsilon_n
       :=a sum_(i,j=1)^a ||T(E_ij)-E_n T(E_ij)||_(2,tau) ->0.

G_n can retain an infinite output. No finite exact-class realization, computable
filtration, effective rate, dimension bound or efficient preparation is inferred.
The theorem does not apply to arbitrary nontracial invariants or to merely
external approximants outside C.

## 2. Exact general-center import and representation independence

Primary statements independently inspected:

* A. Connes, *On the Classification of von Neumann Algebras and Their
  Automorphisms*, IHES/P/76/132, February 1976,
  [author's archive PDF](https://repo-archives.ihes.fr/FONDS_IHES/I_Prepublications/CONNES/1976-1984/P_76_132/P_76_132_web.pdf),
  **Theorem 4.1, printed p43 / PDF p46**. For arbitrary von Neumann algebras
  on separable H, the theorem equates approximate finite dimensionality with
  property P, property E/injectivity and semidiscreteness. Approximate finite
  dimensionality is defined on printed p41 / PDF p44 using an increasing
  sequence of finite-dimensional *-algebras. Immediately after Theorem 4.1,
  Connes explicitly explains how the original factor proof extends to general
  centers using Choi--Effros direct-integral semidiscreteness and decomposability
  of injectivity. Thus no factor-only theorem is silently strengthened.
* A. Connes, *Noncommutative Geometry*, 1994,
  [author's monograph PDF](https://webhomes.maths.ed.ac.uk/~v1ranick/papers/connes.pdf),
  **Chapter V, section 7, Theorem 6, p504** gives the same equivalence for an
  arbitrary von Neumann algebra on separable H. **Definition 17, p500** defines
  hyperfiniteness by an increasing finite-dimensional sequence for separable
  predual. Property 4 on p502 explicitly handles factor direct integrals.

**Representation independence needed in the F2 obstruction:** Connes's
monograph **Chapter V, section 7 beta, Definition 2 and the following paragraph,
p502**, defines property E by a norm-one projection B(H)->M and states its
independence of the Hilbert space on which M acts; the following sentence
identifies it with injectivity using Arveson's extension theorem. The same
statement is in the 1976 survey, **printed p42 / PDF p45**. In particular,
injectivity established in a faithful normal direct-sum representation gives
a norm-one projection in any other faithful normal representation, including
the standard left-regular representation of L(F2). Tomiyama's theorem makes
this projection CP and bimodular. **Normality of the projection is not claimed.**

Both PDFs, extracted relevant pages and SHA-256s are cached in
`../literature/machinery/` and `SOURCE_MANIFEST.json`. Only the finite tracial
case is needed; later type-III_1 uniqueness results are irrelevant.

The given M acts on separable H, so the import's hypotheses are met. If its
finite-dimensional algebras are not unital in M, replace N_n by N_n+C I;
they remain finite-dimensional and increasing. Von Neumann generation gives
L2(tau) density by Kaplansky density and normality of the finite trace.
Conversely L2 density gives von Neumann generation. Tau-preserving expectations
onto the finite algebras are the finite trace pairing projections; their L2
extensions are orthogonal projections. This verifies (1)<->(2).

## 3. Fixed class targets attain each Bayes envelope

Choose a Hermitian traceless input basis H_1,...,H_d, d=a^2-1, with
||H_i||<=1. Put b_i=T(H_i). For each i choose a countable dense set D_i in
(-1,1) containing no atoms of the spectral distribution of b_i under tau.
There are at most countably many atoms, so this is possible. No computability
of these threshold sets is asserted.

Fix (i,t), and let

    x=H_i-tI,       b=b_i,
    P=1_(t,infinity)(b),       Q=I-P,
    u=a tau(|b-tI|).

Every G in C obeys, by splitting b-tI into positive and negative parts,

    ||G(x)||_1 <=Tr(Omega_G pi_G(|b-tI|))=u.             (3.1)

A **fixed target F_(i,t) in C**, independent of a proposed sequence G_n,
attains this upper bound. In the original representation set

    Omega_P=P Omega P+Q Omega Q,
    F_(i,t)(X)=Omega_P^(1/2) T(X) Omega_P^(1/2).

Omega_P is faithful positive trace class, trace a. Traciality gives, for z in M,

    Tr(Omega_P z)=a tau(PzP+QzQ)=a tau(z).

Thus F_(i,t) is CPTP with the same invariant and complete profiles. Since
Omega_P commutes with P, the two signed output parts on x are orthogonal:

    ||F_(i,t)(x)||_1=u.                                 (3.2)

Define delta_(i,t)(G)=u-||G(x)||_1>=0. Trace-norm contraction of any
CPTP R on Hermitian inputs gives

    delta_(i,t)(G)
       <=||(F_(i,t)-RG)(x)||_1
       <=||x||_1 ||F_(i,t)-RG||_diamond.

Taking the infimum,

    delta_(i,t)(G)<=||H_i-tI||_1 d(F_(i,t)|G)
                  <=2a d(F_(i,t)|G).                   (3.3)

Only approximation of each fixed target is needed. No limit is exchanged
with a supremum over an uncountable class.

## 4. Near equality forces spectral-cut commutation

The required fidelity bound has a self-contained proof, avoiding an unchecked
generalized Fuchs--van de Graaf import. For positive trace-class A,D, let
u=Tr(A+D), delta=u-||A-D||_1, and choose Hilbert--Schmidt factors A=XX*,
D=YY*. Let L be the positive spectral projection of A-D and K=I-L. Then

    Tr(AK)+Tr(DL)=delta/2.

The decomposition X*Y=X*LY+X*KY and Schatten Cauchy--Schwarz give

    ||X*Y||_1
      <=sqrt[Tr(AL)Tr(DL)]+sqrt[Tr(AK)Tr(DK)]
      <=sqrt[(u-delta/2)(delta/2)]
      <=sqrt(u delta/2).                               (4.1)

The middle inequality is scalar Cauchy--Schwarz, pairing the vectors
(sqrt Tr(AL),sqrt Tr(DK)) and (sqrt Tr(DL),sqrt Tr(AK)). It works directly
in infinite dimension.

For G_n write Omega_n=G_n(I), pi_n=pi_(G_n), and

    f_+=(b-tI)_+,       f_-=(tI-b)_+,
    X_n=Omega_n^(1/2) pi_n(f_+)^(1/2),
    Y_n=Omega_n^(1/2) pi_n(f_-)^(1/2).

Then X_nX_n*-Y_nY_n*=G_n(x), and (4.1) yields

    F_n:=||pi_n(f_+)^(1/2)Omega_n pi_n(f_-)^(1/2)||_1
       <=sqrt[u delta_(i,t)(G_n)/2].                    (4.2)

For s>0 define

    P_s=1_(t+s,infinity)(b),
    Q_s=1_(-infinity,t-s)(b),
    N_s=1_[t-s,t+s](b).

The inverse square roots of f_+,f_- on the respective far subspaces are
bounded by s^(-1/2). Multiplication by those bounded inverses gives

    ||pi_n(P_s)Omega_n pi_n(Q_s)||_1<=F_n/s.

For every projection N in M, Schatten Cauchy--Schwarz and the fixed state give

    ||pi_n(N)Omega_n||_1, ||Omega_n pi_n(N)||_1
       <=a sqrt[tau(N)].                               (4.3)

The cross block at P is its far block plus two near-band remainders.
Since Omega_n is selfadjoint, the trace norm of its commutator with P is
twice the trace norm of the cross block. Therefore

    ||[Omega_n,pi_n(P)]||_1
       <=2F_n/s+4a sqrt[tau(N_s)].                      (4.4)

If delta_(i,t)(G_n)->0, first take limsup in n at fixed s, then s down0.
The threshold has no spectral atom, so tau(N_s)->0. Hence

    ||[Omega_n,pi_n(1_(t,infinity)(b_i))]||_1 ->0.        (4.5)

No spectral gap assumption or inverse of compact Omega_n is used. The order
of these limits is essential; no uniform rate has been inferred.

## 5. From countably many cuts to all of M

Suppose all countably many deficits tend to zero. Approximate each b_i
uniformly by step functions with thresholds in D_i. Equation (4.5) and
Tr Omega_n=a give ||[Omega_n,pi_n(b_i)]||_1->0. The Leibniz identity
propagates this to every fixed labelled *-polynomial.

For any z in M, uniformly in n,

    ||Omega_n pi_n(z)||_1 <=a||z||_(2,tau),
    ||pi_n(z)Omega_n||_1 <=a||z||_(2,tau).               (5.1)

For example factor Omega_n into two Hilbert--Schmidt square roots and use
Tr(Omega_n pi_n(zz*))=a tau(zz*)=a tau(z*z). Traciality is used here.
The labelled polynomials are L2(tau)-dense, by Kaplansky density and normality
of tau. Apply (5.1) to the approximation error, uniformly in n, to conclude

    ||[Omega_n,pi_n(z)]||_1 ->0       for every z in M.    (5.2)

Thus approximation of the countable Bayes targets gives centrality for all M,
not just the original finite generator list.

## 6. Hypertrace and conditional expectation, with general center

Let K=directsum_n H_n, pi=directsum_n pi_n. This is a faithful normal
representation of M on separable K. Let phi_n be the normal state on B(K)
whose density is Omega_n/a in the nth block and zero elsewhere. Then
phi_n(pi(z))=tau(z). A subnet has a state-space weak-* cluster point phi in
B(K)*. This is sigma(B(K)*,B(K)), **not** convergence in the predual;
phi need not be normal. Equation (5.2) implies

    phi(pi(z)X)=phi(Xpi(z)),       phi(pi(z))=tau(z)       (6.1)

for every z in M and X in B(K).

Here is a direct expectation construction, rather than an application of a
factor-only hypertrace theorem. For X>=0 define ell_X(y)=phi(Xpi(y)).
If y>=0, centrality gives

    ell_X(y)=phi(pi(y)^(1/2)Xpi(y)^(1/2)),
    0<=ell_X(y)<=||X||tau(y).

Consequently ell_X is normal and has a bounded positive tracial density
P(X) in M, 0<=P(X)<=||X||I, satisfying

    tau(P(X)y)=phi(Xpi(y)).                             (6.2)

This is the bounded-density case of finite-trace Radon--Nikodym, or follows
by L2 Riesz representation and the displayed order bound. Additivity and
homogeneity extend P linearly. It is positive unital and P(pi(z))=z.
Equation (6.1), traciality and (6.2) give

    P(pi(v)Xpi(w))=vP(X)w.                             (6.3)

Thus pi P is a norm-one positive projection onto pi(M), sufficient for
injectivity by property E in section2's verified import. CP can be checked
directly: for [X_ij]>=0 and z_i in M,

    tau(sum_ij z_i*P(X_ij)z_j)
       =phi(sum_ij pi(z_i)*X_ij pi(z_j))>=0.

The faithful left regular representation on L2(M,tau) makes these tests
detect matrix positivity. Hence pi P is a conditional expectation in the
norm-one/CP sense.

**P need not be normal.** Normality would be an unjustified strengthening
and would incorrectly collapse this approximate theorem to the atomic exact
criterion. Normality of ell_X as a functional on M does not imply normality
of P as a map of X.

Sections3--6 prove (4)->(1). They also prove (5)->(1): enumerate the countable
tasks and choose G_n with deficits <1/n on the first n tasks.

## 7. Haar construction supplies the uniform positive direction

This is the constructor's repaired construction, independently verified in
`auditor_haar_exact_class.md`. Given (2), put

    Omega_n=integral_(U(N_n)) u Omega u* du,
    G_n(X)=Omega_n^(1/2)T(X)Omega_n^(1/2).

This is a trace-norm Bochner integral over a compact group. Omega_n is
faithful, Tr Omega_n=a, it commutes with N_n, and its restriction to M is
a tau. Thus G_n remains in C, even when M is diffuse.

Decompose H=directsum_j(C^(n_j) tensor K_j) for N_n. Then
Omega_n=directsum_j I_(n_j) tensor omega_j. Let
h_j=Tr omega_j=a tau(p_j)/n_j>0. Block pinching followed by partial trace
defines a normal CPTP decoder S_n with

    S_nG_n(X)=Lambda_n(X)=directsum_j h_j[E_nT(X)]_j.

For any F in C the finite block preparation maps

    R_(n,F)(Y)=sum_j h_j^(-1)
             Omega_F^(1/2)pi_F(Y_jj)Omega_F^(1/2)

are normal CPTP. The composition D_(n,F)=R_(n,F)S_n obeys

    D_(n,F)G_n(X)
       =Omega_F^(1/2)pi_F(E_nT(X))Omega_F^(1/2).

Schatten Holder and the fixed trace state bound each matrix-unit error by
a||T(E_ij)-E_nT(E_ij)||_(2,tau). Expanding arbitrary referenced inputs
into a^2 blocks proves section1's uniform diamond bound. L2 projection
convergence makes the bound vanish. Thus (2)->(3); (3)->(4) is immediate,
and (4)->(5) follows from (3.3). All equivalences follow.

## 8. Finite obstruction for noninjective invariants

If M is noninjective, finitely many of the fixed pinched targets
F_1,...,F_l in C and eta>0 satisfy

    for every G in C,       max_j d(F_j|G)>=eta.         (8.1)

Otherwise choose G_n making deficiencies to the first n countable Bayes
targets <1/n. Their deficits tend to zero, and sections4--6 make M injective.
Equivalently, failure of simultaneous Bayes-envelope approximation yields
a finite list and c>0 with max_j delta_j(G)>=c for every G; (3.3) gives
eta=c/(2a).

The list and margin are existential. No effective noninjectivity certificate,
universal numerical margin or procedure finding those tasks is supplied.
Nevertheless this is a finite operational obstruction, stronger than absence
of one exact greatest member.

For contrast, diffuse abelian M is injective and has uniform approximate
greatest members despite no exact greatest density-operator-output member.
The exact criterion is atomic finite type I; the approximate criterion is
injectivity/hyperfiniteness. The hyperfinite II_1 factor also separates them.

## 9. Dependency and scope accounting

Connes's equivalence, central hypertraces, finite trace expectations and
Schatten inequalities are established machinery. The additional proved bridge
is from exact-profile approximate greatestness through fixed pinched Bayes
tasks and (4.4) to a central hypertrace, combined with the constructor's Haar
direction. Historical novelty of that combined characterization is unverified.

The weak-* limit may be singular. There is no normal expectation conclusion,
so no conflict with Størmer-type normal-expectation atomicity in the exact
theorem. Representation independence is explicitly verified in section2.

Every G_n must belong to the same exact normal invariant class. External finite
envelopes do not satisfy that hypothesis; their converse remains unresolved by
this proof. Traciality is used in pinching, Haar averaging, two-sided L2 bounds
and the density pairing. No nontracial extension or ordinary-capacity algorithm
has been established. Effective compilation needs supplied representations,
filtration, expectations and a convergence modulus; none is free.
