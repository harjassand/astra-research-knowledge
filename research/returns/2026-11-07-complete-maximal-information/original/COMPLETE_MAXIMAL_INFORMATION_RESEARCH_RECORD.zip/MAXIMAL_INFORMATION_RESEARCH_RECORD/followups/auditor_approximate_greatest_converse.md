# Audit of the approximate-greatest converse

6 November 2026. Independent hostile check of the principal's proposed
converse after the Haar repair. No additional agents. **Status: the proposed
necessity of injectivity is valid under uniform epsilon-greatestness, and
also under the weaker common-sequence pointwise hypothesis in Section 5.** The
finite-separable injective/hyperfinite equivalence is a separately named,
primary-checked standard import in Section 3, not proved by the inequalities
below.

## Exact hypothesis

Let (M,T,tau) be a finite-input invariant, tau faithful normal TRACIAL,
with separable normal realizations. Suppose G_k are members of the SAME
exact complete-profile class, with errors epsilon_k→0, such that for EVERY
target member F there is a normal CPTP R_(k,F) satisfying
||F-R_(k,F)G_k||_diamond<=epsilon_k.

If approximate greatestness is instead defined by an infimum over converters
without attainment, use errors epsilon_k+1/k throughout. Nothing depends on
attaining an infimum in the infinite-output converter space.

The first proof below uses a comparison target depending on k, so uniformity
is sufficient for that version. The initial claim that pointwise domination
was insufficient was too strong and is corrected by fixed-base pinches in
Section 5. Write G_k(X)=Omega_k^(1/2) pi_k(T(X)) Omega_k^(1/2),
where pi_k is the normal labelled invariant isomorphism, Omega_k faithful
trace class of trace a, and Tr Omega_k pi_k(A)=a tau(A).

## 1. Small Bayes deficit forces almost-central density

Fix a Hermitian input generator H, B=T(H), and real threshold t. Pinch
Omega_k at 1_(t,infinity)(pi_k(B)). Traciality preserves its state on ALL
M, so this gives a target F_(k,t) in the exact class attaining the trace
norm upper bound at X=H-tI. Diamond approximation and TP contraction imply

\[
0\le\Delta_k(t):=a\tau|B-tI|-\|G_k(H-tI)\|_1
\le\varepsilon_k\|H-tI\|_1\longrightarrow0.
\]

Put C_+=(pi_k(B)-t)_+, C_-=(t-pi_k(B))_+ and
A=Omega_k^(1/2)C_+Omega_k^(1/2), D=Omega_k^(1/2)C_-Omega_k^(1/2).
If s=Tr A+Tr D=a tau|B-t|, generalized Fuchs--van de Graaf gives

\[
F_k(t):=\|C_+^{1/2}\Omega_k C_-^{1/2}\|_1
\le\tfrac12\sqrt{2s\Delta_k(t)-\Delta_k(t)^2}\longrightarrow0.
\]

This inequality can be proved elementarily. The displayed trace norm is
the fidelity of A,D by polar decomposition. Split sqrt(A)sqrt(D) at the
Helstrom projection Q of A-D and use Schatten Holder. Its norm is at most
sqrt(Tr QA Tr QD)+sqrt(Tr Qperp A Tr Qperp D), which is at most
half sqrt((Tr A+Tr D)^2-||A-D||_1²) by the scalar Cauchy--Schwarz
inequality. Thus no equality of Tr A and Tr D is assumed.

Let P_+^h=1_[t+h,infinity)(pi_k(B)), P_-^h=1_(-infinity,t-h](pi_k(B)).
Inverting C_+^(1/2),C_-^(1/2) on these cutoffs gives
||P_+^h Omega_k P_-^h||_1<=F_k(t)/h. Near-threshold terms obey
||P Omega_k Q||_1<=sqrt(Tr Omega_k P Tr Omega_k Q), and the near
projection has mass a tau(1_[t-h,t+h](B)), independently of k. Therefore

\[
\|[\Omega_k,\pi_k(1_{(t,\infty)}(B))]\|_1
\le2F_k(t)/h+4a\sqrt{\tau(1_{[t-h,t+h]}(B))}.
\]

For a non-atom t take k→infinity at fixed h, then h↓0. The commutator
therefore tends to zero. Such thresholds form a dense set. Uniform step
approximation of B by finitely many such spectral cuts gives
||[Omega_k,pi_k(B)]||_1→0. Products and adjoints then give the same
conclusion for all norm polynomials in the generators.

For arbitrary D in M, weighted Schatten Holder and traciality give

\[
\|[\Omega_k,\pi_k(D)]\|_1\le2a\|D\|_{2,\tau}.
\]

Kaplansky density supplies bounded polynomial approximants in L2(tau),
since M is generated as a von Neumann algebra by the labelled generators.
The bound extends asymptotic centrality from polynomials to EVERY A in M.

## 2. A central hypertrace and conditional expectation

Put K=directsum_k H_k and pi=directsum_k pi_k. This is a faithful normal
representation on a separable Hilbert space. Define states on B(K) by
phi_k(X)=Tr(Omega_k X_kk)/a. Each restricts to exactly tau on pi(M), and
for A in M,

\[
|\phi_k(X\pi(A))-\phi_k(\pi(A)X)|
\le a^{-1}\|X\|\|[\Omega_k,\pi_k(A)]\|_1\longrightarrow0.
\]

Take a weak-* cluster subnet of these states (sequential weak-* compactness
is not required). Its limit phi is pi(M)-central and phi(pi(A))=tau(A).
It may be singular on B(K); that is not a defect.

For X>=0 define f_X(A)=phi(X pi(A)). If A>=0, centrality gives

\[
f_X(A)=\phi(\pi(A)^{1/2}X\pi(A)^{1/2}),\qquad
0\le f_X(A)\le\|X\|\tau(A).
\]

Thus f_X is a normal positive functional on M, dominated by a bounded
multiple of its faithful finite trace. The tracial Radon--Nikodym density
P(X) is a bounded element of M with 0<=P(X)<=||X||I and

\[
\tau(P(X)A)=\phi(X\pi(A))\quad(A\in M).
\]

Extend linearly; uniqueness of the densities makes P well defined. It is
positive, unital and fixes M under the pi identification. For b,c,A in M,

\[
\tau(P(\pi(b)X\pi(c))A)
=\phi(X\pi(cAb))
=\tau(bP(X)cA),
\]

so P is M-bimodular. It is completely positive: for a positive matrix
[X_ij] and b_i in M, bimodularity and positivity give
sum b_i*P(X_ij)b_j=P(sum pi(b_i)*X_ij pi(b_j))>=0. Testing against the
faithful tracial GNS cyclic vector and using density of M-vectors proves
matrix positivity. Hence pi∘P is a unital CP projection B(K)→pi(M), i.e.
a conditional expectation. Normality in the B(K) argument is not claimed or
needed. Its existence proves that M is injective.

This completes the direct necessity proof. The expectation is a mathematical
certificate of injectivity, not one of the normal physical target converters.
There is no circular use of a hyperfinite filtration in this direction.

## 3. Consequence after the standard structural import

The Haar addendum proves sufficiency for a supplied increasing unital
finite-dimensional L2-dense filtration, with exact-class approximate sources.
For finite von Neumann algebras with separable predual, Connes' injective/
approximately-finite-dimensional theorem identifies existence of such a
filtration with injectivity. Consequently, with this established import
explicitly credited,

\[
\boxed{\text{uniform exact-class approximate greatest sequences exist}
\iff M\text{ is injective/hyperfinite}.}
\]

The separable-predual hypothesis holds: the original algebra is concretely
represented on separable output H, so its predual is a quotient of S_1(H).
For a finite tracial algebra an increasing weakly dense finite-dimensional
filtration is L2-dense, and the trace-preserving expectations exist.

Primary-source check: Connes' May1976
[On the cohomology of operator algebras](https://repo-archives.ihes.fr/FONDS_IHES/I_Prepublications/CONNES/1976-1984/P_76_142/P_76_142_web.pdf),
the proof of Theorem1, printed p.3, explicitly states that every injective
von Neumann algebra with separable predual is the weak closure of an
increasing sequence of finite-dimensional *-algebras, citing his earlier
classification result. Its introduction, pp.1--2, also identifies these
classes. This is a primary statement of the exact implication used here;
no theorem number from the earlier classification paper is invented.
The publisher identifies that predecessor as Connes, Annals104(1976),
73--115, DOI10.2307/1971057. The implication from a supplied filtration is
proved in the separate Haar addendum, so no other structural direction is
being silently imported.

This criterion is tracial and uniform over targets. It is neither a
nontracial classification nor an effective filtration/sampling theorem.
No quantitative converse modulus follows from the weak-* limit argument.

## 4. Audit of the explicit noninjective fixture

Let G=F_2 with free generators u,v, U=lambda(u), V=lambda(v), and canonical
faithful normal group trace tau on M=L(G). Specify the normalized CP map
from M_3 by

\[
J_T=\begin{pmatrix}I/3&U/12&V/12\\
U^*/12&I/3&0\\V^*/12&0&I/3\end{pmatrix}.
\]

The off-diagonal star block has norm sqrt2, since the row[U,V] times its
adjoint is2I. Hence J_T>=(1/3-sqrt2/12)I>0. Also T(I_3)=I. Its entries
generate L(F_2), since the two unitaries occur as matrix-unit images.

On ell2(G), let Omega have diagonal entries3/(5*4^|g|). There are
4*3^(n-1) reduced words of length n>=1, so sum_g4^(-|g|)=5 and
Tr Omega=3. It is faithful positive trace class. Every A in L(G) has
constant diagonal matrix coefficient tau(A), because the right regular
representation commutes with A and translates basis vectors. Thus
Tr Omega A=3tau(A). The channel E=Ad_(Omega^(1/2))T is CP and TP:
tau(T(Eii))=1/3 and tau(U)=tau(V)=0. Its effective output is faithful and
its normalized invariant is exactly(L(F_2),T,tau).

For completeness noninjectivity has an elementary invariant-mean proof.
If L(F_2) were injective, its left-regular inclusion would admit a UCP
expectation from B(ell2(G)). Injectivity is representation independent; this
follows by extending the isomorphism between faithful representations with
the standard Arveson CP extension theorem and composing expectations.
Compose such an expectation with tau and restrict to the diagonal algebra
ell-infinity(G). Bimodularity and the trace make a left-invariant mean.

An invariant mean assigns every singleton zero. Let A,Aminus,B,Bminus be
the four disjoint sets of nonempty reduced words whose first letters are
u,u^(-1),v,v^(-1). They partition G minus the identity. But
G=A disjointunion u Aminus and G=B disjointunion v Bminus. Invariance
therefore gives m(A)+m(Aminus)=1 and m(B)+m(Bminus)=1, while the four-set
partition gives their sum1, a contradiction. Thus M is noninjective.

The direct necessity proof consequently forbids a uniform approximate-
greatest sequence in this exact profile class. This conclusion does not
need the injective→hyperfinite import. The fixture is an explicitly defined
infinite-output mathematical channel, not a finite rational Choi matrix or
a claimed laboratory implementation.

## 5. Quantifier correction: one common pointwise sequence suffices

The principal's fixed-base repair is correct. Uniform convergence over F is
not needed for necessity. Assume instead that ONE sequence G_k in the exact
class satisfies

\[
\forall F\text{ in the class},\qquad
 d(G_k,F):=\inf_R\|F-RG_k\|_\diamond\longrightarrow0.
\]

Fix one base representative E, once and for all. For each Hermitian input
generator H_i and threshold t, pinch the BASE density Omega_E at the
spectral cut of T_E(H_i). The resulting fixed target F_(i,t) is in the
same class and attains the intrinsic norm a tau|T(H_i)-tI|. It does not
depend on k. With X=H_i-tI, trace-norm contraction gives

\[
0\le a\tau|T(H_i)-tI|-\|G_k(X)\|_1
\le [d(G_k,F_{i,t})+1/k]\,\|X\|_1\longrightarrow0.
\]

This is exactly the deficit convergence needed in Section 1. Choose only a
countable dense set of non-atom thresholds for each of the finitely many
generators. The same common sequence G_k supplies convergence for every
one of these fixed targets. All subsequent far/near-cut, polynomial/L2,
hypertrace and conditional-expectation arguments are unchanged. No rate
uniform in t or F is required.

Consequently the following EXISTENCE conditions are equivalent in the
stated tracial separable setting: a uniform approximate-greatest sequence;
a common sequence pointwise approaching every fixed class target; and
injectivity/hyperfiniteness of M. The given pointwise sequence is not claimed
to converge uniformly; the Haar construction supplies a possibly different
uniform sequence once hyperfiniteness is known.

This is entirely different from allowing a different source sequence for
each target, forall F exists(G_k^(F)). That condition is vacuous here: take
G_k^(F)=F. A common source sequence before the forall-target quantifier is
essential. This section supersedes the earlier overly strong warning about
uniformity and preserves the original sufficient proof at its actual scope.
