#!/usr/bin/env python3
"""Small numerical interface diagnostics; NOT a proof of the cited PBT bound."""
import itertools,json
from pathlib import Path
import numpy as np

def partial(x,dims,keep):
    d=list(dims);z=x.reshape(d+d)
    for k in reversed(range(len(d))):
        if k not in keep:
            z=np.trace(z,axis1=k,axis2=k+len(d));d.pop(k)
    return z.reshape(np.prod(d,dtype=int),np.prod(d,dtype=int))

def povm(a,m):
    d=a**(m+1);sig=[];tu=list(itertools.product(range(a),repeat=m+1))
    for port in range(1,m+1):
        z=np.zeros((d,d),complex)
        for ii,u in enumerate(tu):
            if u[0]!=u[port]:continue
            for jj,v in enumerate(tu):
                if v[0]!=v[port]:continue
                if any(u[k]!=v[k] for k in range(1,m+1) if k!=port):continue
                z[ii,jj]=a**(-m)
        sig.append(z)
    val,vec=np.linalg.eigh(sum(sig));good=val>1e-12
    inv=(vec[:,good]*(1/np.sqrt(val[good])))@vec[:,good].conj().T
    ker=np.eye(d)-vec[:,good]@vec[:,good].conj().T
    return [inv@z@inv+ker/m for z in sig]

def simulate(x,resource,m,pis,a=2,b=2):
    z=x
    for _ in range(m):z=np.kron(z,resource)
    ds=[a]+sum(([a,b] for _ in range(m)),[]);k=len(ds)
    order=[0]+[1+2*j for j in range(m)]+[2+2*j for j in range(m)]
    z=z.reshape(ds+ds).transpose(order+[k+j for j in order]).reshape(z.shape)
    ans=np.zeros((b,b),complex);newds=[a]*(m+1)+[b]*m
    for j,pi in enumerate(pis):
        ans+=partial(np.kron(pi,np.eye(b**m))@z,newds,[m+1+j])
    return ans

def choi(f):
    es=np.eye(2,dtype=complex)
    return np.block([[f(es[:,i:i+1]@es[j:j+1,:]) for j in range(2)] for i in range(2)])

def target(x):
    a=np.diag([1,3/5]);b=np.array([[0,4/5],[0,0]])
    return a@x@a.T+b@x@b.T

phi=np.array([1,0,0,1],complex)/np.sqrt(2)
chi=np.outer(phi,phi.conj());prog=choi(target)/2;out=[]
for m in [1,2,3]:
    pis=povm(2,m)
    gamma=lambda x:simulate(x,chi,m,pis)
    actual=lambda x:simulate(x,prog,m,pis)
    jg=choi(gamma);ja=choi(actual);jb=choi(lambda x:target(gamma(x)))
    fe=float(np.real(phi.conj()@(jg/2)@phi));xi=(1-fe)*4/3
    jd=choi(lambda x:(1-xi)*x+xi*np.trace(x)*np.eye(2)/2)
    row=dict(ports=m,povm_max_error=float(np.max(abs(sum(pis)-np.eye(2**(m+1))))),
      composition_max_error=float(np.max(abs(ja-jb))),
      depolarizing_max_error=float(np.max(abs(jg-jd))),identity_branch_weight=fe,
      diamond_error=2*(1-fe),cited_upper_bound=4/m,
      two_use_joint_distance_bound=float(np.sqrt(1-fe**2)))
    assert row['povm_max_error']<1e-12
    assert row['composition_max_error']<1e-12
    assert row['depolarizing_max_error']<1e-12
    assert row['diamond_error']<=4/m+1e-12
    out.append(row)
result=dict(status='NUMERICAL_INTERFACE_DIAGNOSTICS_PASSED_NOT_A_PROOF',
 target='non-teleportation-covariant amplitude damping, Kraus diag(1,3/5) and [[0,4/5],[0,0]]',
 checks=out)
Path(__file__).with_name('pbt_small_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
