#!/usr/bin/env python3
"""Exact finite resource budgets; full receiver norm and half joint norm."""
from fractions import Fraction as F
from math import ceil
from pathlib import Path
import json

def budget(a,n,p,receiver_error,environment_distance,shortfall):
    p,er,ee,zeta=map(F,(p,receiver_error,environment_distance,shortfall))
    assert a>=2 and n>=1 and 0<p<=1 and er>0 and ee>0 and 0<zeta<1
    c=2*a*(a-1)
    ports=max(1,ceil(F(c*n)/er),ceil(F(c*n,2)/(ee*ee)))
    m=n*ports; ell=1
    while F(1,2**ell)>zeta: ell+=1
    cap=ceil((2*m+8*ell)/p)
    mn=max(1,ceil(F(2*c*n)/er),ceil(F(2*c*n)/(ee*ee)))
    rn=n*mn
    eta=min(p*er/(4*rn+er),p*ee*ee/(8*rn+ee*ee))
    qm=p-eta
    return dict(input_dimension=a,target_uses=n,success_probability=str(p),
      ports_per_use=ports,choi_resources=m,expected_source_uses=str(F(m)/p),
      preparation_cap=cap,shortfall_bound=str(zeta),binary_log_budget=ell,
      receiver_full_trace_norm_bound=str(F(c*n,ports)),
      joint_trace_distance_squared_bound=str(F(c*n,2*ports)),
      forward_port_bits=n*(ports-1).bit_length(),backward_herald_bits_at_most=cap,
      stored_alice_systems=m,stored_bob_systems=m,
      alice_povm_hilbert_dimension=f'{a}^{ports+1}',
      noisy_split_budget=dict(ports_per_use=mn,choi_resources=rn,
        admissible_trial_diamond_error=str(eta),success_lower_bound=str(qm),
        expected_source_uses_upper_bound=str(F(rn)/qm),
        preparation_cap=ceil((2*rn+8*ell)/qm)))

if __name__=='__main__':
    cases=[budget(2,2,'1/7','1/4','1/4','1/1000'),
           budget(2,10,'1/7','1/100','1/100','1/1000'),
           budget(2,10,'3072/1050625','1/100','1/100','1/1000')]
    Path(__file__).with_name('pbt_budgets.json').write_text(json.dumps(cases,indent=2)+'\n')
    print(json.dumps(cases,indent=2))
