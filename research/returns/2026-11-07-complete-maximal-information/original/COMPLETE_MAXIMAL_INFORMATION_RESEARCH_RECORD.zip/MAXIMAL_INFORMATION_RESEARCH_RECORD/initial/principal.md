# Principal independent opening — 6 November 2026

Written before reading any of the three independent researchers' reports.
Sources inspected: acquired N1698 native prefix (structural formulas, path-reference moment argument, rational compiler and operational qualifications); N1690 complete native visible response. Source-level detailed proof/certificate packages remain unacquired. Current version/corrections refresh is underway. The broad N1690/N1698 theorems remain working capital, but any extension below uses only independently checked structural parts or an explicitly named classification dependency.

## Candidate opening: generic rigidity and singular instability

A complete profile can conceal large operational differences only when its normalized output algebra is proper. This suggests both a robust positive reconstruction theorem away from reducibility, and an unavoidable instability theorem at reducible full-rank channels.

### P1. Generic rigidity (proof complete modulo the stated N1698 classification where used)

Fix a>=2 and b>=2. In the open set of channels E:M_a -> M_b with strictly positive Choi matrix, the subset for which A_E=C*(Omega_E^{-1/2}E(M_a)Omega_E^{-1/2})=M_b is dense, open, and of full Lebesgue measure in the TP affine space. On this subset the canonical greatest representative equals E. If E has full normalized algebra and F has the same complete profiles, then F's minimal intrinsic algebra is M_b, and E dominates F by a deterministic CPTP output map. If F also has full normalized algebra (on its effective output), equality of profiles forces equal effective dimensions and F=Ad_U E for an output unitary U.

Proof of density: with Omega fixed, all small Hermitian changes to E on traceless Hermitian inputs are allowed subject only to Tr Omega Delta T(H)=0; Choi positivity is open. Choose two independent traceless Hermitian inputs. Hermitian pairs generating M_b are dense and open: make the first simple-spectrum, then make all off-diagonal entries of the second nonzero in its eigenbasis; spectral projections and P_i B P_j generate all matrix units. Subtract multiples of I to impose the weighted trace constraints, preserving generated algebra. Finite word span supplies openness. Full measure can be proved with rational raw words and a nonzero polynomial determinant: Omega^{-1} is rational in channel entries; raw products X star Y=X Omega^{-1}Y encode normalized products by similarity. One generating seed shows the polynomial is nonzero. In fact all non-generating pairs lie in its zero set, which has measure zero. Rigidity then follows from classification and Skolem-Noether: a labelled *-isomorphism M_b -> M_b is unitary, and equality of faithful states determines Omega.

An explicit rational full-algebra seed exists: choose E(I)=a I/b, two traceless Hermitian input basis elements H1,H2. Let D=diag(0,...,b-1) minus scalar I and B=all-ones minus I. Map these inputs to a sufficiently small rational multiple of D,B and all others to zero, extending linearly with completely depolarizing center. This is TP, Hermiticity-preserving, strictly CP for small coefficient, and its normalized image generates M_b.

### P2. Greatest-capacity envelope is discontinuous at a full-rank channel (conditional only on preserved fixture)

Let G(E)=sup{Q(F): F has the same complete maximal profiles as E}. N1698 gives an attained maximum Q(Gamma_E). For the full-Choi-rank N1690 low channel E0, G(E0)>=117/128, while Q(E0)=0. Choose rational full-algebra channels E_n -> E0 (possible by P1; convex line to a rational generating seed has only finitely many exceptional parameter roots). Then G(E_n)=Q(E_n)->Q(E0)=0 by standard finite-dimensional quantum-capacity continuity. All E_n and E0 can share a strictly positive Choi lower bound. Thus no continuous canonical greatest-channel selector in a fixed padded output space can exist near E0, nor any continuous uniform estimator for the greatest-capacity envelope, even with a fixed Choi floor. Exact equality testing is not robust black-box canonicalization.

The source fixture and canonical classification are explicit dependencies; this is not a proof of ordinary-capacity noncomputability. Continuity of finite-dimensional Q and generic irreducibility are established machinery / likely routine structural consequences, not a transformative result by themselves.

### P3. Positive repair to pursue

On a compact fixed-dimensional stratum, impose Omega>=lambda I and a quantitative finite-word spanning margin kappa>0. All moments of words up to a bounded length then determine the channel modulo output unitaries; compact semialgebraic inverse geometry should give a computable Holder modulus from moment error to diamond-distance modulo output unitary. Need construct precise finite invariant list, word-length sufficiency, semialgebraic description without square-root singularity, and exact Lojasiewicz import/applicability, or an explicit direct stability proof. This could turn complete-profile geometry into a finite robust calibration capability precisely where an algebra-generation margin is promised. It cannot hold uniformly without that margin, by P2. No claim yet about polynomial sample complexity, all-reference norm error, or effective ordinary capacity.

## Immediate independent proof checks

N1698 canonical recovery R(Y)=Omega^(1/2) Z^(-1/2) E_A(Y) Z^(-1/2) Omega^(1/2) has adjoint R*(I)=E_A(Z^(-1/2)Omega Z^(-1/2))=I, since Z in A and bimodularity. R Gamma=E follows because Gamma=Z^(1/2)T(.)Z^(1/2) is in A. These formulas are valid with nontracial tau. The path-reference RLD-to-moment extraction needs careful tracing/polarization and traceless tangent restoration; do not count its source sketch as independently fully verified yet.

## Scientific value and boundaries

The opening is a structural dichotomy between generic rigidity and singular hidden-resource inflation, with a possible robust finite certification theorem. It identifies the decisive missing operation rather than assuming a robust compiler from exact formulas. It does not establish efficient quantum communication or a capacity evaluator.
