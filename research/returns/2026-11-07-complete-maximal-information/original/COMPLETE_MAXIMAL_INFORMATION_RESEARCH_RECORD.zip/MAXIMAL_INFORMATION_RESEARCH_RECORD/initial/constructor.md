# Independent constructor: full-support instability of canonical channels

Initial report saved 6 November 2026 before reading another researcher's initial
report or receiving their constructions. All supporting files are in
`work/maximal-information/constructor/`. No unacquired Astra package is assumed.

## Strongest result obtained

I constructed an explicit rational line `E_t:M_2 -> M_4` whose Choi matrices have
a **common positive spectral floor** and whose identity output is **fixed**, but
whose greatest complete-maximal-profile representatives have a discontinuous
operational ceiling. At `t=0` the greatest representative is a useful depolarizing
qubit channel. For every sufficiently small `t>0`, the physical channel `E_t` is
already greatest in its own class and is antidegradable.

The exact compiler in N1698 is therefore statistically ill-posed even away from
all Choi-support and output-state-rank changes. I also prove an adaptive physical
acquisition lower bound `Omega(t^-2)` for distinguishing this canonical ceiling.
This separates polynomial symbolic computation from acquiring exact algebraic
structure from a physical device. It does not say physical capacity jumps: every
physical channel on the small segment has ordinary quantum capacity zero.

### Formal theorem, executed fixed fixture

Let `E ~ F` mean equality of N1698's complete RLD profiles: same input space,
all finite untouched references, faithful baselines, traceless Hermitian
tangents. Equivalently these are complete maximal-perspective profiles, with
both arguments passed through the same channel. For qubit-input channels put

\[
 f_*(E)=\sup_{F\sim E,\ D:F_{out}\to M_2\ CPTP}
 \langle\phi_2|({\rm id}\otimes DF)(\phi_2)|\phi_2\rangle,
 \qquad Q_*(E)=\sup_{F\sim E}Q(F).
\]

There is an explicit rational affine family `E_t:M_2 -> M_4` such that, for
every real `0<t<=1/65536`,

\[
 \|E_t-E_0\|_\diamond\le2t,\quad
 E_t(I_2)=\Omega=\operatorname{diag}(25,1,1,1)/14,\quad
 J_{E_t}\succeq I_8/448.
\]

Choi matrices here are unnormalised and input-first. Every `E_t`, including
`E_0`, is antidegradable and has `Q(E_t)=0`. Nevertheless:

1. `E_0` has exactly the profile of
   `Delta(X)=(7/8)X+(Tr X)I_2/16`. The latter is greatest in the class and its
   minimum output dimension is two.
2. For every `0<t<1`, the normalized output algebra of `E_t` is `M_4`.
   Consequently `E_t` itself is a minimum-dimensional greatest representative.
3. The class ceilings obey
   \[
   f_*(E_0)=29/32,\quad f_*(E_t)\le3/4,\qquad
   Q_*(E_0)\ge25/64,\quad Q_*(E_t)=0.
   \]
4. For deterministic output deficiency
   `delta(A,B)=inf_R ||B-RA||_diamond`,
   \[
   \delta(E_t,\Delta)\ge5/16,\qquad \delta(\Delta,E_t)\le2t.
   \]
   Hence **no selection** of greatest class representatives is continuous in
   mutual deterministic-simulation distance. This statement does not require
   comparing matrices of different output dimensions directly.
5. Any physical `N`-query procedure distinguishing `E_0` and `E_t` with average
   success at least `2/3`, allowing arbitrary ancillas and adaptive quantum
   operations, has
   \[
   N\ge\frac{\ln(13/9)}{\ln(1+(512t)^2)}.
   \]
   Thus for `t=2^-m`, `m>=16`, `N>2^(2m-20)`. A uniform additive estimate of
   `f_*` with error strictly below `5/64` and success at least `2/3` would give
   such a procedure.

The construction extends parametrically: for every positive rational `epsilon`
there is a rational `2 -> 4` fixture and a rational sequence `E_j -> E_0`, with
fixed `E_j(I)` and one common positive Choi floor, for which
`Q_*(E_0)>1-epsilon` and `Q_*(E_j)=0`. The floor may depend on `epsilon`; it
does not decrease along the sequence for a fixed fixture.

**Status:** proved below; exact fixed-fixture checks executed. Historical novelty
is not established. Instability of exact algebra decompositions is not itself new.

## 1. Source and dependency boundary

I read `AGENTS.md`, the research workflow, N1690's complete native response,
N1698's partial native and complete rendered responses, and the full N1698
capsule notices. Pins are in `../constructor/source-pins.json`. Important hashes:

- N1690 native: `15feec287a6412d8a524381a4a34b3649ad2e63df7a2c7399eb56f262f18c602`.
- N1698 prefix: `dc0d731dbf9067a953ff02475a5765c76a70771e8803852bd1404bb9fd4a8445`.
- N1698 complete rendered: `5c364abf615b56e212cd3a655dfc6819d9fb59e6d42deef11b4176644a8d27e6`.

The source's classification is capital at its exact scope. Section 2 independently
derives the interface needed here. The new seed's positivity/antidegradability
certificate is derived and checked locally; I do not assume N1690's held
128-dimensional certificate or any unpublished compiler implementation.

Later N1708 notices already report finite broadcasting, noisy-qubit capacity
spectra/dimension laws, all-dimensional saturation and finite-memory `1/k`
receivers. This report does not claim these phenomena as new. Its explicit seed
is an independently derived special case. The proposed new consequence is
canonical-ceiling instability **with fixed faithful Choi support and fixed
Omega**, stronger than a support-changing counterexample. No other researcher's
initial notes were read.

## 2. Independently checked profile-to-algebra interface

For `E:M_a -> M_b`, on its effective output define

\[
 \Omega_E=E(I),\quad T_E(X)=\Omega_E^{-1/2}E(X)\Omega_E^{-1/2},\quad
 A_E=C^*(T_E(M_a)),\quad \tau_E(Y)=\operatorname{Tr}(\Omega_EY)/a.
\]

The state `tau_E` is faithful, generally nontracial. For a word `i_1...i_l` in
a Hermitian input basis take an untouched reference path with `r=l+1` levels,
`Q_j=|j-1><j|+|j><j-1|`, and faithful states for small real `z`:

\[
 \rho(z)=\frac1{ar}[I-\sum_j z_jH_{i_j}\otimes Q_j].
\]

An auxiliary tangent can be made traceless by subtracting its trace times
`rho`. This loses no comparison information, since for every TP channel
`g_E(rho,H+c rho)=g_E(rho,H)+2c Tr H+c^2 Tr rho`; the added terms cancel.
Substituting `H=I_a tensor D`, arbitrary Hermitian `D`, gives

\[
 g_E(\rho(z),I_a\otimes D)
 =a^2r\operatorname{Tr}D^2(\tau_E\otimes id)
  [I-\sum_j z_jT_E(H_{i_j})\otimes Q_j]^{-1}.
\]

Hermitian squares span the Hermitian reference matrices. Thus physical profile
equality determines the whole weighted matrix-valued resolvent. Its `(0,l)`
coefficient of `z_1...z_l` is precisely the ordered moment
`tau_E(T_E(H_i1)...T_E(H_il))`, because the length-`l` path is unique.
Complex off-diagonal entries are accessible with Hermitian reference tests.

Equal ordered moments imply a state-preserving input-labelled star-isomorphism:
for every star-polynomial `p`, faithfulness says `tau(p*p)=0` iff `p=0` in the
representation. Equal moments therefore give identical polynomial kernels in
both directions. Conversely a labelled state-preserving star-isomorphism
preserves matrix-level functional calculus and all complete perspectives after
undoing output congruence. This checks the load-bearing N1698 interface without
a moment oracle or a hidden reference recovery operation.

In particular, if `A_E=M_b`, then `E` is itself greatest in its class. Any
equivalent `F`, after a unitary on its effective output, has

\[
 T_F(X)=T_E(X)\otimes I_m,\qquad\operatorname{Tr}_m\Omega_F=\Omega_E.
\]

The output map

\[
 R(Y)=\Omega_F^{1/2}
 (\Omega_E^{-1/2}Y\Omega_E^{-1/2}\otimes I_m)\Omega_F^{1/2}
\]

is CP, is TP by the displayed marginal identity, and satisfies `RE=F`.
Reset padding handles unused ambient support. Ordered star-isomorphism, not a
Jordan map or transpose, is essential. A faithful representation of `M_b`
also proves minimum output dimension `b`.

## 3. Rational interior antidegradable seed

Let `sigma_0=I,sigma_1=X,sigma_2=Y,sigma_3=Z`, `q=(5,1,1,1)`, and

\[
 [E_0(X)]_{jk}=\frac{q_jq_k}{28}
       \operatorname{Tr}[\sigma_j\Delta(X)\sigma_k]. \tag{3.1}
\]

For CP/TP and the profile identity, write in the Bell tensor representation
`P=|phi_2><phi_2|`, `S=I_4/4+P`, `kappa=7/8`. Up to the Bell-basis unitary,

\[
 E_0(X)=\kappa^{-1}S(\Delta(X)\otimes I_2)S. \tag{3.2}
\]

All entries of (3.1) are rational-complex. Equation (3.2) is CP and
`Tr_aux S^2=kappa I_2` proves TP. Since `J_Delta>=I_4/16` and `S>=I_4/4`,
`J_E0>=I_8/224`. Its identity output is `diag(25,1,1,1)/14`.

Invertible-congruence covariance of the maximal perspective and
`Tr_aux(S^2/kappa)=I_2` prove reference-valued perspective equality for every
finite untouched reference. Thus `E_0~Delta` directly. The normalized map is
left multiplication by `Delta(X)` on the Pauli matrix basis, so its algebra
is `M_2` with multiplicity two. Since `A_Delta=M_2`, Section 2 proves `Delta`
greatest in that class.

### Full-space symmetric extension certificate

Put `V=(X^T,Y^T,Z^T)^T`, so `V*V=3I_2`, and `nu=1/1024`. In output-first
order define the `8 x 8` matrix

\[
 H=\begin{pmatrix}aI_2&bV^*\\bV&qI_6+rVV^*\end{pmatrix},\qquad
 a=\frac{11271}{14336},\quad q=\frac{121}{28672},\quad
 r=\frac1{32},\quad b=\frac5{32}.
\]

It is positive definite: on `range(V)^perp` the lower block is `qI`; on its
range the strict Schur determinant is

\[
 a(q+3r)-3b^2=\frac{1554639}{411041792}>0.
\]

Let `W:C^4 -> C^4 tensor C^4` be rational with
`W|0>=|00>`, `W|j>=|0j>+|j0>`, `j=1,2,3`. After reordering `H` input-first,

\[
 B=(I_2\otimes W)H_{in}(I_2\otimes W)^*+\nu I_{32}/16. \tag{3.3}
\]

Both complete output marginals of `B` equal `J_E0`, the entire four-dimensional
outputs can be swapped, and `B>=I_32/16384`. These exact identities were
executed. The core first subtracts the maximally mixed replacer from the desired
marginal: its top coefficient is `11/14+nu/2`, bottom scalar coefficient
`1/224-nu/4`, while the last term restores both marginals. That padding earns
a **full-dimensional** positive margin; a thin single-excitation extension
alone would not prove an open neighbourhood.

The standard symmetric-extension/dilation argument now proves antidegradability
for the actual complement. It is constructive: choose eight independent
vectorised Kraus columns `T` with `TT*=J_E0` by exact algebraic Cholesky. Then

\[
 J_{\mathcal A}=(T^{-1}\otimes I_4)B(T^{-*}\otimes I_4)
\]

is positive, has output partial trace `I_8`, and the Choi purification identity
gives `A E_0^c=E_0` for that Kraus complement. This is not an assertion that
classical labels constitute the whole environment.

For any CPTP `F`, write `D=J_F-J_E0`, `Tr_C D=0`, and `tau=I_4/4`. The
symmetric correction

\[
 B_F=B+D_{RC_1}\otimes\tau_{C_2}+D_{RC_2}\otimes\tau_{C_1}
\]

has both marginals `J_F`. Its norm is at most `||D||/2 <= ||F-E_0||_diamond`
(input dimension two). Thus diamond distance at most `1/32768` preserves a
positive extension with floor at least `1/32768`. This supplies an explicitly
proved antidegradable ball without an SDP or a held certificate.

## 4. Fixed-Omega full-algebra perturbation

Keep `Omega=diag(25,1,1,1)/14`. Set

\[
 D_0=\operatorname{diag}(0,1,2,3)-\tfrac3{14}I_4,\qquad
 B_0=\mathbf1\mathbf1^T-I_4.
\]

Both have zero `Omega`-weighted trace. Define `R` on the Pauli basis by

\[
 R(I)=\Omega,\quad R(X)=\tfrac1{16}\Omega^{1/2}B_0\Omega^{1/2},\quad
 R(Z)=\tfrac1{16}\Omega^{1/2}D_0\Omega^{1/2},\quad R(Y)=0.
\]

All entries are rational, since `Omega^(1/2)=diag(5,1,1,1)/sqrt(14)` and
square roots occur in pairs. Weighted traces give TP. The normalized Choi
pencil has floor
`[1-(3+39/14)/16]/2=143/448`, hence `J_R>=143 I_8/6272`.
The normalized `Z` image has distinct diagonal entries; every off-diagonal
entry of the `X` image is nonzero. Their common commutant is scalar, so they
generate `M_4`.

Put `E_t=(1-t)E_0+tR`. Then `Omega` is fixed, `||E_t-E_0||_diamond<=2t`,
and `J_Et>=I/448` for `t<=1/2`. The ball above proves antidegradability for
`t<=1/65536`.

For the full algebra at **all** `0<t<1`, form commutator constraints for
`T_Et(X),T_Et(Z)` on an unknown `4 x 4` matrix. A specified `15 x 15` minor
(indices in `instability_checks.json`) is exactly

\[
 \frac{-1618261995-331887829i}{2^{48}}
 t^5(t-1)^7\left(t-\frac{182+28i}{173}\right)q(t),
\]
\[
 q(t)=t^2+\left(-\frac{46921}{23258}+\frac{441i}{11629}\right)t
                   +\frac{11809-392i}{11629}.
\]

For real `t`, `Im q(t)=0` only at `t=8/9`, where `q=1/81`. The linear root
is nonreal. This exact polynomial is nonzero throughout `(0,1)`, proving
scalar commutant and full `M_4`. The script proves the polynomial identity
and independently checks four small dyadic parameters.

More generally, full normalized algebra is open dense in any full-Choi-rank
CPTP slice with fixed faithful `Omega` and input dimension at least two:
small weighted-trace-zero Hermitian images around a replacer can generate the
full output algebra. Along a line toward that endpoint, a nonzero commutator
minor has degree at most `b^2-1`. There are finitely many exceptional points;
testing `b^2` distinct rational parameters in any small interval finds a full
algebra perturbation. This uses standard finite matrix-algebra genericity,
not a claimed novel generic-algebra theorem.

## 5. Operational discontinuity and acquisition proof

For two equal qubit-output marginals of a symmetric extension let
`P1=phi_RB1 tensor I_B2`, `P2=phi_RB2 tensor I_B1`. The identity
`P1 P2 P1=P1/4` gives `||P1+P2||=3/2`. Hence each singlet fraction is at most
`3/4`. The same deterministic decoder on both copies retains the extension.
This proves the antidegradable postprocessing ceiling. Antidegradability
persists under tensor powers and coding, so no positive ordinary quantum
rate is possible (for target dimension `d>=2`, the corresponding bound is
`(d+1)/(2d)<=3/4`).

The identity decoder for `Delta` gives `29/32`; no decoder improves it, because
the identity component contributes at most one and the replacer component
exactly `1/4`. Section 2 and the full-algebra calculation give the asserted
class ceilings. A singlet-fraction gap `5/32` forces full trace-norm gap at
least `5/16`, proving the deficiency lower bound. Conversely `Delta` simulates
`E_0` by (3.2) and approximates `E_t` within `2t`.

The maximally mixed-input coherent information of `Delta` is
`1-H(29/32,1/32,1/32,1/32)=0.4025452768...`. The coding theorem yields a
capacity lower bound. Using `-(1-x)log_2(1-x)<=x log_2 e` and `log_2 e<3/2`,
the entropy is less than `39/64`; hence `Q(Delta)>25/64`. No exact capacity
evaluation or coding-efficiency claim is made.

### Adaptive acquisition cost

Let `G=R-E_0`, `s=1/512`. Both `E_+=E_0+sG` and `E_-=E_0-sG` are CPTP.
Indeed `||J_G||<=2` since the positive Choi matrices each have trace two, so
`J_E- >=(1/224-1/256)I=I/1792`. For `|t|<=s`,

\[
 E_t=(\tfrac12+\tfrac{t}{2s})E_+
          +(\tfrac12-\tfrac{t}{2s})E_-.
\]

Every `N`-query adaptive experiment is therefore a fixed quantum operation
on `N` independent classical selector coins. Revealing the coins only helps
discrimination. Against the unbiased coin, the one-copy chi-square divergence
of bias `z=t/s` is `z^2`; for the product it is `(1+z^2)^N-1`.
Cauchy--Schwarz bounds total variation by half its square root. Success `2/3`
requires variation at least `1/3`, which proves
`N>=ln(13/9)/ln(1+(512t)^2)`. For `t=2^-m` the bound
`ln(1+x)<=x`, `ln(13/9)>1/4` gives `N>2^(2m-20)`.

Descriptions have `O(m)` bits at these fixed dimensions; physical acquisition
requires exponentially many uses in that bit length. This covers fully
adaptive quantum acquisition, not merely Choi tomography. It directly rules
out uniformly robust estimation of the canonical ceiling at error below
`5/64`, even with the stated fixed positive rank floors.

## 6. Arbitrarily near-unit capacity ceiling jump

The compact fixture is not a limiting bound. For rational `0<lambda<1`, take
`Delta_lambda(X)=lambda X+(1-lambda)Tr(X)I/2`, rational `u>0`,

\[
 S_u=uI+P,\quad\kappa_u=2u^2+u+1/2,\quad
 E_u=\kappa_u^{-1}\operatorname{Ad}_{S_u}(\Delta_\lambda(\cdot)\otimes I).
\]

In its Bell coordinates set
`p0=(1+u)^2/[(1+u)^2+3u^2]`, `p=u^2/[(1+u)^2+3u^2]`. The single-excitation
extension core has coefficients

\[
 a=p_0-3p,\quad b=\lambda\sqrt{p_0p},\quad q=p(1-\lambda),\quad r=p\lambda.
\]

The square root is rational: `(1+u)u/[(1+u)^2+3u^2]`. The core is strictly
positive whenever

\[
 (p_0-3p)(1+2\lambda)>3p_0\lambda^2.
\]

For every `lambda<1`, sufficiently small rational `u` works because
`1+2lambda-3lambda^2=(1-lambda)(1+3lambda)>0`. Subtract a sufficiently small
rational maximally mixed replacer in the core and restore its full product
extension as in (3.3). Strict positivity persists. Rational halving searches
find `u`, padding and a positive extension floor. The Choi floor is
`(1-lambda)u^2/(2 kappa_u)>0`.

The profile is exactly `Delta_lambda`. Generic rational fixed-`Omega`
perturbations remain inside this antidegradable ball and are themselves
greatest. As `lambda->1`, the canonical depolarizing coherent information
tends to one. This proves the `1-epsilon` ceiling-jump claim. No uniform floor
as `epsilon->0` is asserted. At `lambda=1` the strict Schur condition is
impossible, preserving N1708's unitary/noisy boundary.

## 7. Positive alternative: offline unknown-input simulation

A separate positive operation follows by applying established port-based
teleportation (PBT). It is an application of known machinery, not a new PBT
theorem. Suppose a supplied converter satisfies `S Phi=p Psi`, with `S` CP
trace-nonincreasing and `p>0`. N1698 supplies such converters for same-profile
pairs. Sending half of a freshly prepared local maximally entangled state
through `Phi` and applying `S` produces a successful exact Choi resource of
`Psi` with probability `p`. The future unknown input is not present.

Standard deterministic PBT on `M` independent Choi states simulates `Psi` with
diamond error at most `2a(a-1)/M`. For `n` adaptive uses the full trace-norm
error is at most `2a(a-1)n/M`. Thus take

\[
 M=\lceil2a(a-1)n/\varepsilon\rceil,\quad m=nM,\quad
 \mathbb E[\text{source uses}]=nM/p.
\]

This gives `O(a^2 n^2/(p epsilon))` expected primitive uses, all offline, for
arbitrary unknown inputs, references and adaptive target protocols, instead
of the destructive online all-success block's `n/p^n` repetitions. It needs
herald feedback, `n ceil(log_2 M)` forward port-index bits, and `nM` stored
Alice `a`-systems and Bob target-output systems if everything is prepared
before data arrival. Alice measures `M+1` qudits jointly per use. Polynomial
channel uses do not imply an efficient local circuit or practical advantage.

For `2^-L<=zeta`, a cap `T=ceil((2m+8L)/p)` gives shortfall probability at
most `zeta` by a binomial Chernoff bound. Preparation abort occurs before
accepting unknown data. Ideal memory/storage is an explicit assumption.
With a fixed memoryless implementation error
`||S_tilde Phi_tilde-p Psi||_diamond<=eta<p`, the safe error bound becomes

\[
 2a(a-1)n/M+2nM\eta/(p-\eta),
\]

and expected source cost is at most `nM/(p-eta)`. Thus noise is paid rather
than silently ignored. No unassisted positive asymptotic rate follows from an
overhead growing with `n`; private-security transfer needs additional dilation
analysis and is not claimed here.

For the explicit seed, `L(Y)=(kappa/2)Tr_aux(S^-1 Y S^-1)` satisfies
`L E_0=Delta` and `L*(I)=(kappa/2)S^-2<=7I`. Hence `p=1/7` is a physical
input-independent success probability. This particular depolarizing target
has ordinary-teleportation covariance, so offline exact Choi pairs give exact
unknown-input simulation at seven expected source uses and two forward bits
per target use, with herald feedback. This is the known teleportation-covariance
mechanism already used in N1698, for another explicit seed.

## 8. Primary literature and novelty accounting

Primary sources were inspected and cached in `../constructor/`:

- Hiai--Mosonyi, *Different quantum f-divergences and the reversibility of
  quantum operations*, Rev. Math. Phys. 29 (2017), 1750023,
  [arXiv:1604.03089](https://arxiv.org/abs/1604.03089), **Theorem 3.34 and
  Example 4.8**. The theorem assumes positive TP processing and support
  inclusion; maximal-divergence equality does not generally imply ordinary
  reversibility. The complete-channel interface here adds all untouched
  references, rather than claiming a new binary equality mechanism.
- Myhr--Luetkenhaus, *Spectrum conditions for symmetric extendible states*,
  [arXiv:0812.3667v1](https://arxiv.org/html/0812.3667), **Lemma 5**, statement
  and both dilation-proof directions. The extension must concern the whole
  output of the normalized Choi state. Our exact two complete marginals meet
  this hypothesis; normalization differs by the input dimension only.
- Devetak, *The private classical capacity and quantum capacity of a quantum
  channel*, [quant-ph/0304127v6](https://arxiv.org/html/quant-ph/0304127),
  **Theorem 5 and Proposition 7**. The finite-dimensional memoryless unassisted
  coding theorem gives `Q(N)>=I_c(rho,N)`. Used only for the depolarizing lower
  bound; no capacity computation or efficient code is imported.
- Pirandola--Laurenza--Lupo--Pereira, *Fundamental limits to quantum channel
  discrimination*, npj Quantum Inf. 5, 50 (2019),
  [arXiv:1803.02834](https://arxiv.org/html/1803.02834), **Lemma 1, Eq. (9),
  Lemma 2**. Inspected hypotheses: finite input dimension, standard product
  Choi resources, diamond error `2d(d-1)/M`, adaptive peeling `n delta_M`.
  Section 7 is their operation combined with paid source-Choi acquisition.
- Exact-decomposition instability already occurs in Koashi--Imoto and
  sufficient-experiment theory. K. Kuroiwa's 2021 Waterloo thesis,
  [*Quantum Blind Data Compression and Structure of Quantum Operations
  Approximately Preserving Quantum States*](https://uwspace.uwaterloo.ca/items/20aacac3-888e-4459-ae1c-249d191753eb),
  abstract/introduction, discusses that sensitivity explicitly. I inspected
  the primary text. It does not prove the particular maximal-profile ceiling
  counterexample above; generic exact-decomposition instability is credited.

Commutant tests, finite-dimensional star-algebra representation, Schur
complements, selector-coin simulation and chi-square product bounds are standard.
The potentially new combination is the **uniformly full-rank, fixed-Omega
operational discontinuity of greatest complete-profile channels**, with explicit
positive certificates and adaptive acquisition cost. Literature searching has
not cleared historical priority.

## 9. Checks, costs, failed routes and status

Executed `python3 work/maximal-information/constructor/check_instability.py`.
It checks TP, fixed `Omega`, both complete extension marginals, swapping the
whole outputs, strict rational Schur positivity, the exact commutant determinant
identity and its real-root exclusion, and four small dyadic perturbations.
`instability_checks.json` reports `EXACT_CHECKS_PASSED`. Gaussian-rational
domain arithmetic replaced slow generic symbolic rank/determinant routines;
no floating-point eigensolver or SDP tolerance enters the proof.

The fixed fixture uses one qubit input, two-qubit output, Choi rank eight and
an eight-dimensional minimal environment. Its joint-extension output dimension
is sixteen and Choi certificate dimension thirty-two. The channels and affine
line have explicit rational matrix descriptions. At `t=2^-m` symbolic input
length is `O(m)` while physical acquisition needs `Omega(4^m)` uses. New-device
synthesis still requires its full description and actual implementation.

Restricted/failed routes are retained:

1. A rank-collapse flag limit would be an easier instability but would not test
   uniform full-rank robustness. Fixed-Omega algebra inflation replaces it.
2. A thin single-excitation symmetric extension alone does not earn an open
   antidegradable ball. The subtract-and-restore full replacer repairs it.
3. Optimized PBT error `O(M^-2)` requires a correlated entangled resource and
   cannot be assigned cheap independent-Choi acquisition. The positive theorem
   uses the verified standard product-resource `O(M^-1)` bound.
4. Unknown input may be destroyed by online herald failure; only offline resource
   preparation removes this issue, with feedback and storage costs retained.
5. The extension fails at `lambda=1`; no unitary-profile broadcasting or
   zero-capacity representative is claimed.

| Claim | Status |
| --- | --- |
| Needed ordered-profile/algebra interface | Independently derived; agrees with N1698 capital |
| Rational `2 -> 4` interior antidegradable seed | Proved and exact-checked; general phenomenon already capital |
| Full-support fixed-Omega canonical-ceiling discontinuity | Proved; novelty not established |
| Arbitrarily near-unit ceiling jump in dimension four | Proved parametrically; compact fixture executed |
| Adaptive `Omega(t^-2)` acquisition cost | Proved from the explicit selector representation |
| Polynomial-use offline unknown-input simulation | Proved application of known PBT; practical efficiency unclaimed |
| Robust canonical extraction under only full-rank/fidelity-floor promises | Disproved |
| Stability with a quantitative algebra-separation promise | Open |
| Unrestricted ordinary capacity approximation | Unresolved, untouched |
| Historical priority, physical measurement, practical advantage | Not established |

The next constructive missing operation is an operationally tolerant substitute
for exact canonicalization. A certified singular-value gap in the commutator
map could identify an algebra stratum, but approximate algebra structure does
not automatically control ordered-moment faithfulness or operational ceilings.
That implication requires an actual theorem.
