# Independent initial mathematical audit

**Researcher:** hostile mathematical auditor. **Date:** 6 November 2026 (Brisbane).
This initial report was written without reading any other researcher's initial
report or exchanging mathematical conclusions with them. No additional agents
were used. The principal supplied source-location and current-scope updates only.

## 1. Finding and status

I find no counterexample to the central N1698 implication at its exact finite,
all-reference, faithful-baseline scope. I independently reconstruct below:

\[
\text{complete RLD equality}\iff
\text{ordered moments}\iff
(\mathcal A,T,\tau)\text{ isomorphism}\iff
\text{complete maximal-perspective equality}.
\]

The greatest representative, minimal output dimension, rational CP extensions,
and full-space deterministic converters also survive the audit. Nontraciality
is essential bookkeeping but is not an obstruction. There is a simple
univariate modification of the path witness that gives a polynomial-time
rational witness compiler as well as the equality test.

The strongest negative result obtained is a **full-Choi-rank discontinuity of
the greatest-channel construction**, with a rational qubit counterfamily and a
common positive Choi floor. Its generated algebra changes from commutative to
all of M_2 under an arbitrarily small perturbation. The maximum classical
capacity within the complete-profile class then drops by a fixed amount.
Thus exact classification is not stable under finite-precision tomography,
even away from Choi-rank changes. This does not contradict the source's
conditional implementation-error bound for a *specified* heralded converter.

A further general order result follows from an explicit faithful-state
construction: every profile class has representatives converging to a pure
replacer in a fixed finite output dimension. Consequently **a nonconstant
profile class has no least representative under deterministic output
processing**. These statements are independently derived here; priority is
not asserted, and they are not to be substituted for later source-reported
N1708 broadcasting/spectrum results.

Statuses in this report:

| Assertion | Audit status |
|---|---|
| N1698 structural classification and greatest/minimal lift | Independently proved below |
| Rational equality test, raw projection, CP extensions and factorization | Independently proved below |
| Polynomial rational inequality-witness construction | Independently proved with a univariate repair below |
| Full-Choi discontinuity and absence of a least class member | Proved below; novelty unassessed |
| General N1690 unequal-order evaluator and its particular quantitative cutoff | Preserved source-reported capital; full compiler/proof package unacquired, not independently re-established here |
| N1690 exact 128-dimensional symmetric-extension certificate and numerical rate fixtures | Preserved at supplied scope; certificate bytes unacquired, not replayed here |
| N1708 later all-dimensional broadcasting/saturation/sequential claims | Current source notices acknowledged; not a new proof or audit in this report |

## 2. Sources pinned and scope preserved

Read AGENTS.md and the independent-research stage of
`outputs/RESEARCH_TO_PUBLICATION_WORKFLOW.md`. Governing local texts:

* `../sources/N1690-COMPLETE_NATIVE_VISIBLE_RESPONSE.txt`, SHA256
  `15feec287a6412d8a524381a4a34b3649ad2e63df7a2c7399eb56f262f18c602`.
* `../sources/N1698-NATIVE_RESPONSE_PREFIX_PARTIAL.txt`, SHA256
  `dc0d731dbf9067a953ff02475a5765c76a70771e8803852bd1404bb9fd4a8445`.
* `../sources/N1698-COMPLETE_RENDERED_VISIBLE_RESPONSE.txt`, SHA256
  `5c364abf615b56e212cd3a655dfc6819d9fb59e6d42deef11b4176644a8d27e6`.
* Long-ID N1690 and N1698 record JSON, and refreshed N1690/N1698 capsules.
  N1698 capsule SHA256 at reading:
  `6c257c82c1157722420c03f3650d0686b7a69e89c995468f65e62ee7d7179e82`.
  Capsule input version supplied by the principal:
  `5e1ce8b083b48e1a5ba57d768f5e4dc802c87938e7ccd312dbe9b008ffb0a5b3`.

The N1698 complete rendered text states the classification at lines 166–220,
the concrete greatest lift at 224–602, minimum dimension at 604–741, path
extraction at 743–1029, and rational compiler at 1031–1624. Later notices extend
the surrounding research beyond the earlier full-Choi and qubit-only
broadcasting boundaries: the newest reported criterion is all-dimensional and
may return NO, has exact-support sensitivity, and has fixed-source rather than
uniform varying-dimension efficiency. The subsequent sequential/recovery
claims remain earlier reported capital. None is being claimed as rediscovered
or verified by the following N1698 audit.

The original PDF, code, certificates, circuit data and review packages were not
acquired. The visible response alone is not a substitute for those bytes. The
proofs below are fresh reconstructions of claims whose formulas are visible;
they do not certify execution of the historical compiler or its fixtures.

## 3. Support and normalization

Let E:M_a→M_b be CPTP, Ω=E(I_a), and P=supp Ω. Every E(X) is supported on P:
for positive X use 0≤X≤||X||I, then extend linearly. If ρ_AR>0, then
E_R(ρ)≥λ_min(ρ) Ω⊗I_R and hence its effective support is exactly P⊗I_R.
Compressing to P loses no physical output. On P set

\[
T(X)=\Omega^{-1/2}E(X)\Omega^{-1/2},\qquad
\mathcal A=C^*(T(M_a)),\qquad
\tau(A)=a^{-1}\operatorname{Tr}(\Omega A).
\]

T is UCP, τ is a faithful state, and a τ(T(X))=Tr X. Faithfulness uses Ω>0
on P, not commutation of Ω with A. In general τ(AB)≠τ(BA), and no proof below
makes that exchange.

For any positive baseline Q on A⊗M_R and tangent K, the RLD expression after
undoing the output congruence is

\[
g_E(\rho,H)=a(\tau\otimes\operatorname{Tr}_R)
 \big[T_R(H)T_R(\rho)^{-1}T_R(H)\big].
\]

This formula preserves product order. Writing it as a tracial moment would be
an error.

## 4. Complete RLD equality really exposes ordered moments

Choose rational Hermitian input generators H_i, including the identity if
desired. For a word w=i_1…i_n, put r=n+1 and

\[
A_j=|j-1\rangle\langle j|+|j\rangle\langle j-1|,\quad
Q(z)=I-\sum_{j=1}^n z_jT(H_{i_j})\otimes A_j,
\]
\[
\rho(z)=\frac{I-\sum_j z_jH_{i_j}\otimes A_j}{ar}.
\]

For small real z this is a faithful density matrix. Define
M_E(z)=(τ_E⊗id)(Q_E(z)^{-1}). For Hermitian reference D and H=I_a⊗D,
direct multiplication and the ordinary full trace give

\[
g_E(\rho(z),I\otimes D)=a^2r\operatorname{Tr}_R(M_E(z)D^2).
\]

This is legitimate despite τ being nontracial: the two copies of Ω adjacent
to D are moved only inside the *full ordinary matrix trace*, and D commutes
with physical-system matrices.

The tangent can be centered without loss. For t=Tr H=a Tr D, set H'=H−tρ.
For every CPTP E,

\[
g_E(\rho,H')=g_E(\rho,H)-t^2.
\]

The removed term is channel independent. Equality on traceless tangents
therefore determines Tr(M_E D²) for all Hermitian D. Since D may be any
rank-one projector, D²=D and these tests determine the whole Hermitian matrix
M_E, including complex off-diagonal entries. Merely using real D would not
suffice for the imaginary parts.

Expand Q(z)^{-1} by its convergent Neumann series near zero. In its (0,n)
entry the coefficient of z_1…z_n has exactly one path of length n, namely
0→1→…→n. It equals

\[
\tau_E\big(T_E(H_{i_1})\cdots T_E(H_{i_n})\big).
\]

This explicitly earns every *ordered* moment from physical baselines and
traceless tangents. No output-reference recovery, arbitrary matrix inverse
oracle, or cyclicity of τ is assumed. Reference dimension grows with word
length; the claim without references would be much weaker.

### Moments imply the labelled algebra isomorphism

Evaluate every noncommutative *-polynomial p in the two sets of Hermitian
generators. Equal ordered moments give

\[
\tau_E(p(T_E)^*p(T_E))=
\tau_F(p(T_F)^*p(T_F)).
\]

If p(T_E)=0, faithfulness forces p(T_F)=0, and conversely. Thus assignment of
labelled generators extends to a well-defined unital *-isomorphism θ:A_E→A_F
with θT_E=T_F and τ_Fθ=τ_E. This is a kernel argument in the free *-algebra;
finite dimensionality then removes completion issues.

Conversely such an isomorphism transports all amplified inverses, products
and continuous functional calculus. Invertible congruence covariance gives

\[
P_f(E_R\rho,E_R\sigma)
=(\Omega_E^{1/2}\otimes I)
 P_f(T_{E,R}\rho,T_{E,R}\sigma)
 (\Omega_E^{1/2}\otimes I).
\]

Taking the physical partial trace applies aτ_E⊗id_R to the middle term.
Consequently the full reference-valued maximal-perspective profiles agree
for every continuous f on the positive spectra, not only operator-convex f.
The reverse implication to RLD follows by f(x)=(x−1)² and arbitrarily small
faithful perturbations. The tensor-product invariant is
(A_E⊗A_F,T_E⊗T_F,τ_E⊗τ_F), so all-block equality follows too.

## 5. Greatest lift and minimum dimension

Let \(\mathbb E_A\) be the ordinary-trace conditional expectation onto A,
and Z=\(\mathbb E_A\)(Ω). Then Z∈A and Z>0 because Ω≥cI implies Z≥cI.
Define Γ_E(X)=Z^{1/2}T_E(X)Z^{1/2}. CP is immediate and

\[
\operatorname{Tr}\Gamma_E(X)
=\operatorname{Tr}ZT_E(X)=\operatorname{Tr}\Omega T_E(X)
=\operatorname{Tr}X.
\]

The normalized map is T_E, and Tr ZA=Tr ΩA for A∈A, so Γ_E has the same
invariant. The map

\[
R_E(Y)=\Omega^{1/2}Z^{-1/2}\mathbb E_A(Y)
 Z^{-1/2}\Omega^{1/2}
\]

is CP, has adjoint effect
\(\mathbb E_A(Z^{-1/2}\Omega Z^{-1/2})=I\), and satisfies R_EΓ_E=E.
The use of the expectation's bimodule property, rather than a false
commutation ΩZ=ZΩ, is crucial.

For a different representative F, one must insert the labelled isomorphism
and the representation transfer. The schematic source formula F=R_FΓ_E is
correct with that transfer included in R_F; using the literal displayed R_F
on a differently sized output space would be a type error.

More explicitly write A_0=⊕_j M_{n_j} and let h>0 represent aτ with the
ordinary trace on this minimal representation. Then

\[
\Gamma_0(X)=h^{1/2}T_0(X)h^{1/2}
\]

is CPTP. In any concrete faithful representation
π:A_0→B(H), put Z_π equal to the ordinary-trace density of aτ on π(A_0).
The map

\[
J_\pi(Y)=Z_\pi^{1/2}\pi(h^{-1/2}Yh^{-1/2})Z_\pi^{1/2}
\]

is a CPTP map from the full minimal matrix algebra (after block pinching Y
onto A_0), maps Γ_0 to the represented greatest lift, and can then be followed
by R_E. Hence Γ_0 dominates every class member. All faithful representations
contain each simple block at least once, so b≥∑_j n_j, attained by Γ_0.
The minimum-dimensional choice is unique up to a unitary implementing its
labelled state-preserving algebra isomorphism.

### Exact parameterization of all class members

Fix (A_0,T_0,τ). Every member is, up to output-unitary equivalence,

\[
E_{\pi,\Omega}(X)=\Omega^{1/2}\pi(T_0(X))\Omega^{1/2},
\]

where π is a faithful finite-dimensional unital representation and Ω>0
satisfies

\[
\operatorname{Tr}(\Omega\pi(A))=a\tau(A)\quad(A\in A_0).
\]

Conversely every such pair gives a CPTP member: the trace constraint gives
TP, normalization gives πT_0, and the generated algebra is π(A_0). This
parameterization is an exact finite-dimensional statement; no semiclassical
or tracial approximation is involved.

## 6. Rational polynomial compiler: what can be justified

For rational-complex Choi matrices, Ω and its support projector and
Moore–Penrose inverse are rational and computable by exact linear algebra.
Consider raw words under B⋆C=BΩ^+C, identity Ω. Congruence
B↦Ω^{-1/2}BΩ^{-1/2} identifies this algebra with A, including its *-operation.
Trace of a raw word is a times its τ-moment.

For a pair E,F use paired raw words. Their span has dimension at most
N=r_E²+r_F². Start with the identity pair and append *one generator at a
time*, retaining independent word evaluations. Once the span is unchanged
by all right multiplications it contains all words. A breadth-first basis
has length at most N−1. Traces agree on all words iff they agree on this
basis, proving the exact equality test.

Appending letters is an important implementation condition. Naively
multiplying arbitrary retained long words can create exponential word
lengths, so the phrase 'close under products' alone is not a complexity proof.
With right multiplication, all word entries, inverses, ranks and trace tests
have polynomial rational bit size and there are polynomially many operations
in the explicitly given Choi matrix size. This establishes polynomial bit
time for equality; it says nothing about succinct circuit inputs.

### A polynomial-time rational inequality witness

The source's unspecified multivariate grid can be replaced by a univariate
grid. Given a differing word of length n≤N−1, set every path variable z_j=t.
The (0,n) resolvent entry has leading coefficient t^n equal to the differing
ordered moment, since there is still exactly one length-n path. Its difference
is a nonzero rational function of one real t.

Use the four rank-one rational-complex reference projectors onto e_0, e_n,
(e_0+e_n)/√2, and (e_0+i e_n)/√2. Their projector matrices are rational even
though the displayed unit vectors use √2. At least one scalar resolvent
difference tested by these projectors is nonzero. Centering the corresponding
I_a⊗D tangent changes no channel difference.

Choose a rational t-interval in which
\(\|t\sum H_{i_j}\otimes A_j\|\le 1/2\). A rational row-sum norm bound
produces that interval and gives ρ_t≥I/(2ar). After padding unused output
supports by identities, the relevant determinants have degree at most br
and cr. A scalar difference numerator therefore has degree at most
d=r(b+c). Evaluate the four tests at d+1 distinct rational points inside the
interval. At least one value is nonzero. This is polynomially many exact
matrix inversions of polynomial dimension and bit length.

Finally choose a small positive rational s so that σ=ρ_t+sH'>0. Then ρ_t and
σ are faithful rational states and their maximal χ²-profile difference is
s² times the nonzero RLD difference. Both a positive spectral floor and an
exact rational nonzero margin are emitted. Thus no numerical zero test or
multivariate polynomial identity-testing conjecture is needed. The reference
dimension is n+1≤N.

### Raw conditional expectation and converters

For a raw basis B_j, the source's Gram matrix

\[
G_{ij}=\operatorname{Tr}(\Omega^+B_i^*\Omega^+B_j)
\]

is exactly the ordinary Hilbert–Schmidt Gram matrix of the normalized basis.
The rational projection it defines is therefore

\[
L_E=\operatorname{Ad}_{\Omega^{1/2}}\,
 \mathbb E_A\,\operatorname{Ad}_{\Omega^{-1/2}},\qquad
K_E=L_E^*(I)=\Omega^{-1/2}Z\Omega^{-1/2}.
\]

It is CP, fixes E, and K_E>0 on P. For a same-profile target F, replacing
each raw basis word by its target word gives the rational CP map

\[
L_{E\to F}(Y)=\Omega_F^{1/2}\theta\!left(
 \mathbb E_{A_E}(\Omega_E^{-1/2}Y\Omega_E^{-1/2})
\right)\Omega_F^{1/2}.
\]

Its effect is exactly K_E because θ preserves the weighted state. This is
an explicit CP extension, not an unjustified application of a generic linear
extension theorem or an assumption that trace preservation on the image
extends to the full space.

Rational positive semidefinite elimination gives K_E=V*DV with rational
entries and positive rational diagonal D. A positive rational n/m is a sum
of polynomially many rational squares: expand nm in binary, write each even
power of two as a square and each odd power as two equal squares, then divide
the square roots by m. Consequently C*C=K_E has a rectangular rational
solution of polynomial size without integer factorization. Γ_C=Ad_C E is
CPTP and isometrically equivalent on its support to Γ_E, since C and
Z^{1/2}Ω^{-1/2} have the same Gram matrix.

For P_C=CC^+, the source's deterministic full-space map

\[
R(Y)=L_{E\to F}(C^+YC^{+*})
 +\operatorname{Tr}[(I-P_C)Y]F(I_a/a)
\]

is CP and TP because its adjoint effect is
\(C^{+*}K_EC^++I-P_C=I\). Its composition with Γ_C is F. The reset term
is necessary whenever C is rectangular or has unused output space.

## 7. Hostile counterexample: discontinuous greatest channels with a common Choi floor

Let

\[
P=|0\rangle\langle0|,\quad
v=(3/5,4/5)^T,\quad Q=|v\rangle\langle v|,\quad
\beta=1/128,\quad\alpha=1-2\beta=63/64,
\]
\[
\omega_0=(1-\beta)P+\beta Q,\qquad
\omega_1=\beta P+(1-\beta)Q,\qquad
Y=\begin{pmatrix}0&-i\\i&0\end{pmatrix}.
\]

Define rational qubit channels by the input-first Choi matrices

\[
J_\epsilon=
\begin{pmatrix}
\omega_0&\epsilon Y/2\\
\epsilon Y/2&\omega_1
\end{pmatrix},\qquad \epsilon_j=1/(1000j),\quad j\ge1,
\]

and also ε=0. Trace preservation holds because the diagonal blocks have trace
one and Tr Y=0. The blocks have determinant 127/25600 and trace one, so
\(\omega_i\succeq(127/25600)I\). The off-diagonal perturbation has norm
|ε|/2. Consequently, for every j including the zero limit,

\[
J_{\epsilon_j}\succeq \frac{127}{51200}I_4.
\]

These are a uniformly interior family of CPTP channels. Their common Ω is

\[
\Omega=P+Q=\frac1{25}\begin{pmatrix}34&12\\12&16\end{pmatrix}>0.
\]

At ε=0, E_0 ignores input coherences and prepares ω_0 or ω_1. Let S have
columns |0⟩ and v. The matrix U=Ω^{-1/2}S is unitary. Therefore

\[
T_0(X)=U\operatorname{diag}
\big((1-\beta)X_{00}+\beta X_{11},
     \beta X_{00}+(1-\beta)X_{11}\big)U^*.
\]

Its algebra is C², its faithful state gives the two minimal projections
weight 1/2, and the greatest representative is the binary symmetric
measure-and-prepare channel with crossover β. Hence

\[
C(\Gamma[E_0])=1-h_2(1/128)>119/128.
\]

For ε≠0 the normalized images of σ_z and σ_x do not commute. In raw
coordinates their commutator is congruent to

\[
\alpha(P-Q)\Omega^{-1}Y-Y\Omega^{-1}\alpha(P-Q)
=\begin{pmatrix}-189i/64&-63i/32\\-63i/32&0\end{pmatrix}\ne0.
\]

Two noncommuting Hermitian 2×2 matrices generate M_2. More explicitly the
four raw words Ω, Z=α(P−Q), εY, ZΩ^{-1}εY have vectorization determinant
3969ε²/1600, so they span M_2 for every ε≠0. Thus A_{E_ε}=M_2 and its
conditional expectation is the identity. Its greatest representative is
**exactly E_ε itself**, up to the harmless choice of minimal coordinates.

Meanwhile C(E_0)<3/4. Indeed its cq output ensemble lies on the line segment
between ω_0 and ω_1. The maximum entropy of an average output is
h_2(1/5), because the two original pure vectors have overlap 3/5 and the
segment is symmetric. Additivity of the cq Holevo problem gives
C(E_0)≤h_2(1/5)<3/4. The final strict inequality follows entirely from the
integer inequality 5^20<2^47. For the other endpoint,
h_2(1/128)≤(7+log_2 e)/128<9/128.

The channels E_ε converge in diamond norm to E_0. Finite-output classical
capacity is continuous by Leung–Smith, Corollary 13. Thus

\[
\lim_{j\to\infty}C(\Gamma[E_{\epsilon_j}])
=C(E_0)<3/4,
\qquad C(\Gamma[E_0])>119/128.
\]

The class-maximum classical capacity jumps by more than 23/128 bits at a
channel having a uniform full-Choi-rank neighbourhood. This is stronger than
a discontinuity caused only by changing support rank. Full Choi rank and
bounded inverse Ω do not repair it: algebraic reducibility is another exact
singularity. In particular, an unrestricted approximate invariant or stable
canonicalization theorem cannot follow from N1698's exact formulas.

Check script: `../auditor/check_discontinuity.py`; exact JSON output:
`../auditor/check_discontinuity.json`. The script checks Choi trace conditions,
determinants, raw word rank and integer bounds, not the capacity-continuity
theorem or any infinite family by numerical sampling.

### Constructive stability repair

On a fixed word-span stratum, require quantitative lower bounds on the
nonzero singular values of a chosen normalized word matrix and on the
relevant Gram matrix, together with Ω≥μP and stable support. The conditional
expectation is then a matrix of rational functions of those word entries;
ordinary inverse perturbation bounds give local continuity with constants
depending on these conditioning parameters. Square-root continuity then
controls Γ and its specified converters. This is a viable conditional
robustness theorem, not a dimension-only statement. Uniform Choi and output
floors alone omit the word-span gap and are disproved by the example.

## 8. No least representative for any nonconstant profile

This is a constructive consequence of the parameterization, independent of
the N1708 finite-broadcast criterion.

Write A_0=⊕_j M_{n_j}, h=⊕_j h_j>0, Tr h=a. Represent it on
H=⊕_j(C^{n_j}⊗C^{n_j}) by π(A)=⊕_j(A_j⊗I). Put

\[
\psi=\bigoplus_j\operatorname{vec}(h_j^{1/2}),\quad
\Omega_0=|\psi\rangle\langle\psi|,\quad
Z=\bigoplus_j(h_j/n_j)\otimes I_{n_j},
\]
\[
\Omega_s=(1-s)\Omega_0+sZ,\qquad 0<s\le1.
\]

Here ||ψ||²=a, Z>0, and the ordinary-trace conditional expectation satisfies
\(\mathbb E_{\pi(A_0)}(\Omega_0)=Z\), by the partial-trace formula on each
block; off-block terms are pinched out. Therefore every

\[
E_s(X)=\Omega_s^{1/2}\pi(T_0(X))\Omega_s^{1/2}
\]

is a same-profile CPTP channel. As s↓0, continuity of finite-dimensional
matrix square roots gives diamond convergence to

\[
E_0(X)=\operatorname{Tr}(X)|\widehat\psi\rangle
 \langle\widehat\psi|,\qquad\widehat\psi=\psi/\sqrt a.
\]

Suppose a least class member L existed. Then for every s there would be
CPTP R_s with L=R_sE_s. For the trace-distance distinguishability
\(\Delta(E)=\max_{\rho,\sigma}\|E(\rho)-E(\sigma)\|_1\), contraction gives
Δ(L)≤Δ(E_s)→0. Thus L is constant. Its generated algebra is C and its profile
is the constant-channel profile, contradicting a nonconstant original class.
Conversely all constant channels are mutually deterministic postprocessings,
so the constant profile is the only exception.

This proves the absence of a deterministic minimum without any capacity
formula. Capacities continuous at a replacer additionally tend to zero along
this sequence, but their exact zero attainment and finite broadcasting require
the stronger, separately scoped N1708 results. Do not infer antidegradability
of E_s merely from its closeness to a pure replacer.

## 9. Heralding, environments, operational consequences and robustness

If L E=F and K=L*(I), choose rational p=1/Tr K. Since K≥0 and
Tr K E(ρ)=1, λ_max(K)≥1 and hence Tr K≥1. Thus 0<p≤1 and pK≤I. The
success map pL and the reset failure map with effect I−pK form a physical
instrument. It obeys (pL⊗id)E_R=pF_R for every input, including entangled
inputs. This is uniform success, not a state-dependent postselection claim.

The composition of Stinespring isometries for E and this successful operation,
divided by √p, is an isometry dilating F. By uniqueness of minimal
Stinespring dilation, its entire successful environment is related to a target
environment by an isometry (with unused dimensions handled on the support).
This is the necessary reason that secrecy transfers. Uniform success
probability alone would not establish it. Failure can destroy an unknown
input; arbitrary channel descriptions do not supply deterministic access to
Γ by applying the possibly expanding matrix C to an existing output.

For a fixed n-use adaptive target protocol, all-success probability is p^n.
Repeating a fixed good finite block from a freshly preparable initial state
gives the source's conservative fixed-block cost n/p^n. If one aborts at the
first failed use, the exact expected primitive-use count per accepted block
can be improved to

\[
\frac{1-p^n}{(1-p)p^n}\quad(p<1),
\]

with limit n at p=1. Neither expression permits retrying an unknown quantum
state. A linear n/p overhead for arbitrary unknown data needs additional
structure, such as the source fixture's exact teleportation simulation.

Mutual heralded conversion preserves PPT, separability and k-copy
distillability of normalized Choi states for each finite k: local CP maps
preserve the first two properties, and their positive success probabilities
can be inserted before a finite-copy distillation protocol. Both directions
are essential. Positive two-way entanglement/key capacity transfers by
selecting a sufficiently good finite target block, repeating it on fresh
inputs with positive all-success probability, then distilling. This does not
preserve numerical assisted capacities or any unassisted quantum rate.

For the specified noisy success operation G with
||G−pF||_diamond≤η<p, put e=η/p. A hybrid argument for n adaptive uses gives
the unnormalized difference bound
\((1+e)^n−1\) after dividing the branch by p^n, since the CP map G/p has
diamond norm at most 1+e. Each conditional success probability is at least
p−η, so acceptance is at least (p−η)^n.

For positive A and density B, with q=Tr A, normalization obeys
\(\frac12\|A/q-B\|_1\le\|A-B\|_1\): if q≤1, write the difference using
denominator 1 and the correction (1−q)A/q; if q≥1, use denominator q.
In each case the trace defect is bounded by ||A−B||_1. This verifies the
source's loose but valid conditioned-error bound
\(\min\{1,(1+\eta/p)^n-1\}\). The failure of global canonical stability
in Section 7 does not refute this conditional fixed-converter estimate.

Rational Choi/Kraus output provides a finite mathematical physical
realization and a complement. It does not by itself establish a low-depth
gate implementation, noise-tolerant compilation, experimental performance,
or transmission advantage. No such claim is needed for the structural
theorem.

## 10. Primary-source checks and exact imports

Downloaded primary PDFs and extracted text are in `../auditor/`.
The arguments in Sections 3–6 are self-contained finite matrix arguments;
no unverified theorem is being used to bridge their decisive steps.

1. **F. Hiai and M. Mosonyi, “Different quantum f-divergences and the
   reversibility of quantum operations,” arXiv:1604.03089**, inspected from the
   [author manuscript](https://real.mtak.hu/166018/1/1604.03089.pdf), PDF SHA256
   `739b8a50a8ff0b6fe3aa557c4ab5bb4c9e0f1bc2c16c6fc2621e312b7c2544d5`.
   Theorem 3.34 (printed pp.25–27) assumes positive ρ,σ with supp ρ≤supp σ and
   a positive trace-preserving map Φ. It equates preservation of one nonlinear
   maximal f-divergence, all maximal divergences, the quadratic expression,
   all perspective functions, and a multiplicative-domain condition when Φ
   is 2-positive. This applies to *preservation under a specified map*, not
   automatically to equality between two unrelated channel output families.
   N1698's path-to-labelled-algebra step is still needed. Example 4.8 and
   Section 4.2 explicitly separate maximal preservation from ordinary
   reversibility. Proposition 4.1 gives the explicit spectral-projection
   minimal reverse test, with its attribution to Matsumoto. The commutative
   binary specialization of the greatest lift agrees with that formula.

2. **M. Guţă and A. Jenčová, “Local asymptotic normality in quantum
   statistics,” arXiv:quant-ph/0606213**, inspected from the
   [author manuscript](https://www.maths.nottingham.ac.uk/plp/pmzmig/preprints/qlanw.pdf),
   PDF SHA256 `a151e08e606a76d549024694293685692ceb7c7848b6cb82766013a45bd5f88a`.
   Theorem 3.4 (printed p.18) identifies statistical equivalence of experiments
   with minimal sufficient algebras by equality of their canonical states on
   the free group of Connes cocycles. Its following remark stresses that
   single cocycle values are insufficient and ordered products are needed.
   This is a genuine conceptual antecedent, but the cocycle invariant and
   ordinary statistical equivalence are not N1698's normalized-generator
   maximal-profile invariant. Theorem 3.4 is not imported as a proof of N1698.

3. **D. Leung and G. Smith, “Continuity of quantum channel capacities,”
   arXiv:0810.4931**, inspected from the
   [primary manuscript](https://arxiv.org/pdf/0810.4931), PDF SHA256
   `cc0a891fa62f325c9c7370a6b3cec2426a01aaa7c05053286f0ea7be0b186b74`.
   Corollary 13 states, for same finite-dimensional output B and diamond
   distance at most ε,
   \(|C(N)-C(M)|\le8\epsilon\log d_B+4h_2(\epsilon)\).
   The hypotheses hold for the qubit family in Section 7. This is the sole
   external continuity import needed for the discontinuity-of-class-maximum
   conclusion. Corollary 14 analogously covers unassisted Q; it must not be
   casually promoted to a global two-way-assisted capacity continuity theorem.

Exact historical priority for the combined classification/compiler remains
unassessed. The foregoing primary checks prevent both renaming the standard
moment/GNS, conditional-expectation and transpose machinery as new and
silently importing ordinary reversibility from maximal equality.

## 11. Recommended consolidation and remaining decisive work

The strongest defensible general theorem is the exact finite-dimensional
classification plus explicit greatest/minimal lift and rational polynomial
equality/converter compiler, with the all-class parameterization stated
explicitly. The full profile is a labelled faithful-state algebra, not an
ordinary-capacity invariant. The supplied N1708 additions should be integrated
as earlier capital at their exact finite-k, all-dimensional and cost scopes,
not treated as work that this round newly commissions or has independently
verified.

Add the full-Choi discontinuity counterexample and no-least-member theorem
as exact boundaries. A meaningful robustness extension must freeze and
condition the word-span stratum; Choi positivity alone is insufficient. For
the implementation, use breadth-first appended words and the univariate
witness grid to make polynomial claims auditable. If historical executable
artifacts remain unavailable, label only their reported execution as such
while retaining the independent analytic proofs supplied here.
