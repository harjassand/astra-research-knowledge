# Independent initial report: existing machinery for complete maximal profiles

Researcher: existing-machinery branch. Date: 2026-11-06. This report was written
without reading any other researcher's initial notes or communicating a
construction to another researcher. No agents were spawned.

## 1. Main conclusions and status

1. The finite-dimensional classification and greatest lift in N1698 have a short
   independent proof from the visible formulas. The hard bridge is physical RLD
   tests to ordered moments. Once that bridge is supplied, the remaining steps
   are faithful-state GNS reasoning, finite C*-algebra representation theory, and
   the established Petz transpose construction. They should be presented with
   those precedents, rather than as a new recovery principle.
2. I obtain a **polynomial-bit physical witness compiler** for unequal complete
   profiles. It replaces the source's finite rational grid search by one small
   rational path parameter and four legitimate tangents. It returns faithful
   rational input states on a reference of dimension at most
   `rank(Omega_Phi)^2 + rank(Omega_Psi)^2`, a nonzero rational maximal quadratic
   divergence difference, and an explicit positive margin. The proof is in §4.
   This is a new derivation relative to the acquired source's explicit scope,
   not a claim of historical priority or of practical experimental efficiency.
3. There is a simple **discontinuity obstruction even with uniformly full-rank
   Choi matrices**. Arbitrarily close rational qubit channels can have canonical
   greatest channels separated by a fixed positive postprocessing deficiency.
   Full Choi rank, a Choi spectral floor, fixed input/output dimension and fixed
   effective support do not repair this. The obstruction is an exact generated-
   algebra rank change, not a Choi-support change. A complete example is in §5.
4. For genuinely approximate operational comparison, Jenčová's existing diamond-
   deficiency/randomization theorem is the strongest clean incumbent: complete
   guessing-game comparison already characterizes approximate simulability with
   a bounded ancilla. A robust theorem for maximal profiles has to add algebra
   conditioning or change its target; one cannot inherit recovery guarantees
   from standard-divergence sufficiency.
5. The all-dimensional broadcasting criterion, finite-memory normal form,
   `Theta(1/k)` recovery exponent and qutrit assisted protocol in later N1708
   notices are prior reported capital. They are not proposed as new results here.

The most defensible next mathematical route from this branch is to combine the
finite exact witness theorem with an explicit, promise-dependent stable-stratum
reconstruction theorem, while retaining the global discontinuity counterexample.
This is a concrete exact/approximate boundary. Its ultimate scientific strength
should be compared with the other independent routes before choosing the main
result of this research round.

## 2. Governing sources and acquisition boundary

I read the root `AGENTS.md`, the research stage of
`outputs/RESEARCH_TO_PUBLICATION_WORKFLOW.md`, both full long-ID record JSONs,
the complete N1690 native response, the N1698 native prefix, the full N1698
rendered response and both refreshed operation capsules. The principal supplied
the refreshed capsules during this independent phase. I read the later N1708
statement/contract and N1698 notices to avoid rediscovering their claimed scope.

Relevant source pins:

| File | SHA-256 |
|---|---|
| `N1690-COMPLETE_NATIVE_VISIBLE_RESPONSE.txt` | `15feec287a6412d8a524381a4a34b3649ad2e63df7a2c7399eb56f262f18c602` |
| `N1698-NATIVE_RESPONSE_PREFIX_PARTIAL.txt` | `dc0d731dbf9067a953ff02475a5765c76a70771e8803852bd1404bb9fd4a8445` |
| `N1698-COMPLETE_RENDERED_VISIBLE_RESPONSE.txt` | `5c364abf615b56e212cd3a655dfc6819d9fb59e6d42deef11b4176644a8d27e6` |
| `N1690-capsule.json` | `63e02916726690de2b23d05f4804b54747f16d39ed305dff143f1baac9e7a07d` |
| `N1698-capsule.json` | `6c257c82c1157722420c03f3650d0686b7a69e89c995468f65e62ee7d7179e82` |

N1690 content version is
`479176fd2d256f9289bf8ca8caf5ede3f93ec25fa38ccfe9ab5168ef8e0517f3`;
N1698 content version is
`0d547e9e0793babd2f72b38af3ca46476efad9794895951c2b232d3573e6e982`.
The refreshed capsules are bound to intake input version
`5e1ce8b083b48e1a5ba57d768f5e4dc802c87938e7ccd312dbe9b008ffb0a5b3`
and source revision beginning `99c8478` as communicated by the principal.

The original detailed PDF/proof/compiler/review packages remain unacquired. I do
not infer their contents or claim to have reproduced their exact code,
certificates, operational rate calculations or the N1690 general inequality
evaluator. Below, a statement is independently proved only when its proof is
actually supplied. In particular, the new witness theorem does not re-prove
Volčič positivity or N1690's general complete-order decidability theorem.

## 3. Primary-source imports and exact applicability

PDFs and extracted text are cached in `../literature/machinery/`; hashes and
page counts are in `SOURCE_MANIFEST.json`. All theorem numbers below were read
in full primary texts, not inferred from abstracts.

### 3.1 Maximal equality is not ordinary sufficiency

[Hiai–Mosonyi, *Different quantum f-divergences and the reversibility of quantum
operations*, arXiv:1604.03089v4](https://arxiv.org/pdf/1604.03089v4), Theorem 3.34,
assumes positive matrices `rho,sigma` with `supp rho <= supp sigma` and a positive
trace-preserving map `D`. Equality for any non-linear operator-convex maximal
f-divergence is equivalent to equality for the quadratic divergence, to
`D(rho sigma^-1 rho) = D(rho) D(sigma)^-1 D(rho)`, and to perspective preservation
for every scalar function on the relevant spectrum. For 2-positive `D`, it is
equivalent to `sigma^-1/2 rho sigma^-1/2` belonging to the multiplicative domain
of the normalized map `D_sigma`.

Applicability here: all displayed physical postprocessings are CP and TP; a
faithful input baseline has full joint output support. Thus the support
hypothesis holds after compression. This theorem explains why a normalized
output *-homomorphism preserves all maximal perspectives. It cannot be applied
directly to two unrelated channels without first constructing their relation.
Their §4.2 and Example 4.8 explicitly separate maximal equality from ordinary
reversibility. The source's capacity separation is therefore not a contradiction
of Petz sufficiency.

### 3.2 The canonical binary specialization is already a reverse test

[Matsumoto, *A new quantum version of f-divergence*,
arXiv:1311.4722v4](https://arxiv.org/pdf/1311.4722v4), Theorem 6.1 gives the
maximal-divergence reverse-test formula and attains it by the spectral reverse
test. Theorem 6.9 proves essential uniqueness of optimal reverse tests under
its additional integral-measure support condition (6.15); that extra condition
must not be dropped when citing this uniqueness theorem.

For two positive density matrices `rho,sigma`, put `Omega=rho+sigma` and
`A=Omega^-1/2 rho Omega^-1/2`. Then the normalized generators are `A` and `I-A`,
so their algebra is commutative. In the spectral basis of `A`, the greatest
channel's two outputs are distributions with weights
`p_j=lambda_j Tr(Omega P_j)` and
`q_j=(1-lambda_j) Tr(Omega P_j)`. The preparation map sends `j` to
`Omega^1/2 P_j Omega^1/2 / Tr(Omega P_j)`. This directly verifies that the binary
canonical lift is Matsumoto's minimal reverse test, with the reference chosen
as `rho+sigma`. It is a specialization of an established theorem.

### 3.3 Petz transpose supplies the displayed reconstruction

Hiai–Mosonyi equations (3.19)–(3.20), Theorem 3.18 and Remark 3.17(2) give the
Petz transpose formula and explain completion outside the relevant support.
For a trace-preserving conditional expectation `E_A`, a positive density
proportional to `Omega`, and `Z=E_A(Omega)`, that formula is exactly

`R(Y)=Omega^1/2 Z^-1/2 E_A(Y) Z^-1/2 Omega^1/2`.

Here `Z` is invertible on the joint support because `Omega >= omega I` there
for some `omega>0` and the expectation is unital positive. The formula is CP,
and its effect is `Z^-1/2 E_A(Omega) Z^-1/2=I`. Its use on the new lifted outputs
is valid. It does not assert that ordinary coarse graining of the original
outputs is reversible.

### 3.4 Canonical moments and minimal experiments have strong predecessors

[Guţă–Jenčová, *Local asymptotic normality in quantum statistics*,
arXiv:quant-ph/0606213v2](https://arxiv.org/pdf/quant-ph/0606213v2), Corollary 3.4
and Theorem 3.5 characterize equivalence of faithful quantum experiments by a
state-preserving isomorphism of their minimal sufficient algebras and by a
canonical state built from all ordered Connes-cocycle moments. Theorem 3.3
uses ordinary statistical sufficiency. These are not the N1698 normalized
generator moments, and their equivalence classes are different.

[Kuramochi, *Minimal sufficient statistical experiments on von Neumann
algebras*, arXiv:1701.03394v2](https://arxiv.org/pdf/1701.03394v2), Theorem 1 and
Corollary 2 prove existence and uniqueness up to isomorphism of a minimal
sufficient experiment/channel in the ordinary CP-concatenation class, including
general von Neumann algebras. This cannot identify the greatest member of the
larger maximal-profile class: §5 below already gives equal maximal profiles
with strictly different ordinary binary decision performance.

The applicable lesson is that faithful-state moment classification and
canonical algebraic representatives are established organizing machinery. The
new bridge, if any, has to be the particular family of physical tests and the
particular equivalence class they determine.

### 3.5 Finite closure and short separating words are old algorithmic machinery

[Li–Qiu, *A Polynomial-Time Algorithm for the Equivalence between Quantum
Sequential Machines*, arXiv:quant-ph/0604085v2](https://arxiv.org/pdf/quant-ph/0604085v2),
Theorem 2, gives a polynomial algorithm returning a distinguishing word for
inequivalent machines. Its proof retains a basis of reachable matrices and
expands children only for linearly independent basis words. The same finite
linear-closure operation applies to our direct-sum raw channel algebra. No
claim that the channel itself is a sequential machine is needed: the elementary
closure proof is supplied in §4.

[Volčič, *Matrix coefficient realization theory of noncommutative rational
functions*, arXiv:1505.07472](https://arxiv.org/pdf/1505.07472), Theorem 6.1,
gives a finite matrix-size identity test from realization dimension. Its
Example 4.3 also warns that matrix-coefficient minimal realizations need not
be pairwise similar. One must not import scalar realization uniqueness into
arbitrary matrix-coefficient realizations without its hypotheses. Here the
faithful state and *-algebra, rather than generic realization uniqueness,
provide the relevant uniqueness.

### 3.6 The operational approximate comparator is already complete

[Jenčová, *Comparison of quantum channels and statistical experiments*,
arXiv:1512.07016v2](https://arxiv.org/pdf/1512.07016v2), Theorem 1, uses
`delta(Phi,Psi)=inf_D ||Phi-D Psi||_diamond`. It characterizes
`delta(Phi,Psi)<=epsilon` by complete input-ensemble guessing inequalities
with additive term `(epsilon/2) P_succ(input ensemble)`. It suffices to use an
ancilla of dimension equal to the target output dimension and equiprobable
ensembles of its square cardinality.

This theorem applies directly to any pair of finite canonical channels, or to
any proposed approximate simulator. It gives a bounded-ancilla operational
test and an SDP-based alternative to noisy moment inversion. It does not
replace the N1698 classification: its data are decision profiles, not maximal
divergence profiles. Any claimed new general approximate-channel comparison
capability should be matched against this theorem.

### 3.7 Recent prior work must be kept separate from the whole-channel invariant

[Buscemi, *Quantum f-divergences from retrodictive tests: a unifying classical
variational principle*, arXiv:2610.29696](https://arxiv.org/pdf/2610.29696),
Theorem 3.1 fixes faithful `rho,sigma,gamma` and minimizes a coupled classical
f-divergence over preparation/retrodiction tests; Theorem 6.1 inserts a fixed
quantum channel. Both are spectral optimality statements with prescribed
states and reference. Neither theorem states whole-channel classification by
all normalized-output moments or a greatest member of that profile class.

[Okayasu, *Operator-valued maximal f-divergences for completely positive
maps*, arXiv:2609.00554v1](https://arxiv.org/pdf/2609.00554v1), Definition 3.1 and
Proposition 3.4 construct an operator-valued maximal divergence from a common
Stinespring–Radon–Nikodym realization. Theorems 4.3 and 4.4 respectively prove
monotonicity under unital CP precomposition and normal CP postcomposition;
Theorem 4.9 gives monotone convergence along increasing von Neumann
subalgebras. This is a strong existing route for generalized CP-map divergence
questions. Its arguments compare **two CP maps** through their common
dominating dilation; the present invariant compares both state arguments
after **one** channel. Equating these two interfaces without proof would be a
scope error. In particular it does not supply finite-dimensional greatest
representatives for arbitrary infinite-dimensional generated algebras.

## 4. Independent proof and polynomial physical-witness construction

All channels below are finite CPTP maps with a common input `M_a`. Write
`Omega_E=E(I)`, compress to its support, and put

\[
 T_E(X)=\Omega_E^{-1/2}E(X)\Omega_E^{-1/2},\qquad
 \tau_E(A)=a^{-1}\operatorname{Tr}(\Omega_E A).
\]

`T_E` is UCP and `tau_E` is a faithful state, possibly nontracial. Choose the
rational Hermitian norm-at-most-one input basis
`E_ii`, `E_ij+E_ji`, `i(E_ij-E_ji)`. The identity is used separately as the
empty word. All products retain their order.

### 4.1 Physical tests determine ordered moments

Fix a word `i_1...i_n`, `n>=1`, and put `r=n+1`. On the reference path let

\[
 F_j=|j-1\rangle\langle j|+|j\rangle\langle j-1|,
 \quad A=\sum_{j=1}^n H_{i_j}\otimes F_j,
 \quad \rho_t=(I-tA)/(ar).
\]

For `0<t<=1/(2n)`, `||A||<=n`, so `rho_t` is a faithful density matrix with
`rho_t >= I/(2ar)`. Its trace is one because every `F_j` has trace zero.
For each channel define

\[
 \Xi_E=\sum_j T_E(H_{i_j})\otimes F_j,\qquad
 M_E(t)=(\tau_E\otimes\mathrm{id})[(I-t\Xi_E)^{-1}].
\]

Contractivity of UCP maps gives `||Xi_E||<=n`. For any rank-one rational-complex
reference projection `P`, use the legitimate tangent

\[
 H_P=I_a\otimes P-a\rho_t.
\]

It is Hermitian and traceless. Direct multiplication, without assuming a trace
property of `tau_E`, gives

\[
 g_E(\rho_t,I_a\otimes P)=a^2r\operatorname{Tr}[P M_E(t)].
\]

Subtracting `a rho_t` changes this quadratic form only by channel-independent
terms. Thus equal complete physical RLD profiles determine all quadratic forms
of the Hermitian matrix `M_E(t)`, hence that whole matrix. Its `(0,n)` entry
has Taylor coefficient at order `n`

\[
 \tau_E(T_E(H_{i_1})\cdots T_E(H_{i_n})),
\]

because the path has exactly one walk of length `n` from `0` to `n`. Lower
orders vanish in this entry. This independently verifies the load-bearing
physical-to-moment bridge advertised in N1698.

If all these moments agree, a free *-polynomial `p` vanishing in one generated
algebra has zero expectation of `p* p` in both. Faithfulness forces it to vanish
in the other. The polynomial evaluation rule therefore induces a well-defined,
input-labelled, state-preserving *-isomorphism. Conversely that isomorphism
preserves functional calculus and the scalar maximal perspectives, by the
congruence identity and the state functional. This proves the claimed finite
classification without requiring the held proof package.

### 4.2 Short word with polynomial rational arithmetic

For rational-complex Choi matrices use raw products

\[
 B\star_E C=B\Omega_E^+C.
\]

The empty-word element is `Omega_E`; a nonempty raw word is
`E(H_i1) Omega_E^+ ... Omega_E^+ E(H_in)`. Its trace divided by `a` equals the
corresponding normalized ordered moment. Close paired raw words for `Phi,Psi`
under right multiplication by the paired generators, retaining a basis of
actual words. The ambient vector-space dimension is at most

\[
 N=\operatorname{rank}(\Omega_\Phi)^2+
   \operatorname{rank}(\Omega_\Psi)^2.
\]

Pruning dependent nodes is valid because right multiplication is linear. At
most `N` basis words are retained; every retained word has length at most
`N-1`. Test the linear functional `(Tr B-Tr C)/a` on this basis. If it vanishes,
all moments and profiles agree. If not, it returns a word of length
`1<=n<=N-1` and a nonzero rational-complex moment difference `delta`.

Support projectors and Moore–Penrose inverses of rational-complex positive
matrices have rational-complex entries and can be computed by exact rank and
linear-system operations. For example, obtain the range projector from
independent columns `V` as `V(V*V)^-1 V*`, then invert the matrix padded by the
orthogonal-complement projector. Determinant/linear-system bounds show their
bit lengths are polynomial in the explicit input size. Products of at most
`N-1` such rational matrices and polynomially many rank computations retain
polynomial bit complexity. This is an explicit-matrix assertion, not one about
succinct circuits.

### 4.3 One small parameter prevents cancellation

Choose a nonzero component `d` of `delta`, either its real or its imaginary
part. Since each normalized generator is a contraction and `tau_E` is a
state, `|delta|<=2`. Set

\[
 t=\min\left\{\frac1{2n},\frac{|d|}{8n^{n+1}}\right\}.
\]

It is a positive rational number with polynomial bit length. The selected
component of `(M_Phi(t)-M_Psi(t))_{0n}` equals `d t^n` plus a tail bounded by

\[
 2\sum_{m=n+1}^{\infty}(nt)^m
 \le 4n^{n+1}t^{n+1}
 \le \tfrac12|d|t^n.
\]

Hence this component is nonzero with magnitude at least `|d|t^n/2`. Unlike a
grid argument, this uses no search through all multivariate parameter choices.

Consider only these four rank-one reference projections:

\[
 P_0=|0\rangle\langle0|,\quad P_n=|n\rangle\langle n|,\quad
 P_+=\tfrac12(|0\rangle+|n\rangle)(\langle0|+\langle n|),
\]
\[
 P_i=\tfrac12(|0\rangle+i|n\rangle)(\langle0|-i\langle n|).
\]

The appropriate real or imaginary off-diagonal entry is a linear combination
of the corresponding projection expectations with coefficient absolute sum
two. Therefore at least one of the four physical tangent tests has absolute
RLD-profile difference at least

\[
 \frac{a^2r}{4}|d|t^n.
\]

Evaluate the four tests exactly and choose one with maximum absolute
difference. These are rational scalar computations on matrix sizes at most
`max(b_Phi,b_Psi) N`; support padding avoids irrational basis changes.

### 4.4 Faithful rational state pair and explicit exact gap

For that chosen projection set

\[
 s=\frac1{8ar},\qquad \sigma=\rho_t+sH_P.
\]

We have `||H_P||<=1+3/(2r)<2`, so
`sigma >= I/(4ar)`; it has trace one. For the nonaffine operator-convex
generator `f_2(x)=(x-1)^2`, its maximal divergence obeys exactly

\[
 \widehat D_{f_2}(E_R(\sigma)\Vert E_R(\rho_t))
 =s^2g_E(\rho_t,H_P).
\]

Consequently the returned state pair has absolute profile difference at least

\[
 \boxed{\frac{|d|t^n}{256r}>0.}
\]

All outputs, including this lower bound, have polynomial bit length. All
linear algebra and the four evaluations take deterministic polynomial bit
time. In particular this proves:

**Physical-witness theorem.** Given two explicit rational-complex CPTP Choi
matrices with common input, there is a deterministic polynomial-bit algorithm
that either certifies complete maximal/RLD-profile equality by finite closure,
or returns faithful rational states `rho,sigma` on `A tensor R`, with
`dim R<=N`, input spectral floors at least `1/(2aN)` and `1/(4aN)`, and an exact
nonzero rational maximal quadratic divergence gap bounded below by an emitted
positive rational number of polynomial encoding length.

This strengthens the acquired source's explicitly restricted witness-generation
scope; it does not claim polynomial experiments or polynomial sample complexity.
The gap may be `2^-poly(input size)`, and output inverse conditioning can be
similarly costly. It proves inequivalence, not failure of a specified direction
of the complete order. N1690's harder order evaluator remains a separate result.

### 4.5 Exact complex-moment verification

The supplementary script `../checks/machinery_witness.py` uses a qutrit
classical-input/qubit-output measure-and-prepare channel with preparation states
`(I+X/2)/2`, `(I+Y/2)/2`, `(I+Z/2)/2`, compared with their output transposes.
Both are CPTP. It finds the length-two moment difference `i/99` and chooses
`t=1/6336`, reference dimension three. The first three projection tests give
zero; the imaginary projection gives a nonzero exact gap. This is a useful
check that scalar real polarization alone would miss the required ordered
information. The resulting faithful state-pair divergence gap is

`-220796929/168484433275167185024`,

with the proved absolute lower bound `1/3052296732672`. The script verifies
the positive input states and exact RLD/quadratic-divergence relation. Results
are in `../checks/machinery_witness.json`. These checks supplement the proof.

## 5. An explicit obstruction to globally stable canonical recovery

Let `P=|0><0|`, `v=(3/5,4/5)^T`, `Q=|v><v|`, and define a rational qubit
measure-and-prepare channel

\[
 E_0(X)=X_{00}\rho_0+X_{11}\rho_1,
\quad \rho_0=\tfrac34P+\tfrac14Q,
\quad \rho_1=\tfrac14P+\tfrac34Q.
\]

Explicitly,

\[
 \rho_0=\begin{pmatrix}21/25&3/25\\3/25&4/25\end{pmatrix},\qquad
 \rho_1=\begin{pmatrix}13/25&9/25\\9/25&12/25\end{pmatrix}.
\]

Each has eigenvalues `(5+sqrt(13))/10` and `(5-sqrt(13))/10`; in particular
`J(E_0) >= I_4/8` in the unnormalized input-first Choi convention. Define

\[
 G_0(X)=\operatorname{diag}((3X_{00}+X_{11})/4,
                          (X_{00}+3X_{11})/4).
\]

With `S` having columns `|0>,v`, we have `E_0=Ad_S G_0`. The columns are
normalized and linearly independent. Every output of `G_0 tensor id` is
block-diagonal in this two-valued label; congruence covariance and the norm-one
columns preserve its reference-valued maximal perspectives. Thus `E_0` and
`G_0` have the same complete profiles. Equivalently their intrinsic algebra
is `C directsum C`, the restricted density is `I`, and `G_0` is a greatest
representative. This can be checked directly by the classification proof in §4.

For `0<epsilon<=1/2`, put

\[
 E_\epsilon=(1-\epsilon)E_0+\epsilon\,\mathrm{id}_{M_2}.
\]

These channels remain uniformly full-Choi-rank:
`J(E_epsilon)>=I_4/16`. Also
`||E_epsilon-E_0||_diamond<=2epsilon`. Nevertheless `E_epsilon` is invertible
as a linear map for every positive epsilon: it sends the off-diagonal units
to epsilon times themselves, and the determinant of the diagonal coefficients
of its two diagonal-unit images is `(8+17epsilon)/25>0`. Its image is all of
`M_2`, so its normalized generated algebra is `M_2`. The conditional
expectation in the N1698 lift is the identity; hence a greatest representative
of its class is **`E_epsilon` itself**.

Define the directed postprocessing diamond deficiency by

\[
 d_\to(E,F)=\inf_{R\,\mathrm{CPTP}}\|F-R E\|_\diamond.
\]

For the two input basis states,

\[
 \|G_0(|0\rangle\langle0|)-G_0(|1\rangle\langle1|)\|_1=1,
\quad \|\rho_0-\rho_1\|_1=4/5.
\]

If `||G_0-R E_epsilon||_diamond<=d`, trace-distance contractivity and the two
individual state errors give

\[
 1\le \|E_\epsilon(|0\rangle\langle0|-
                       |1\rangle\langle1|)\|_1+2d.
\]

The first term is at most `4/5+6epsilon/5`, so

\[
 \boxed{d_\to(E_\epsilon,G_0)\ge1/10-3\epsilon/5.}
\]

In particular the lower bound is `1/20` for `0<epsilon<=1/12`, and its liminf
is `1/10` as epsilon tends to zero. A different choice of greatest
representative cannot remove this: greatest representatives are mutually
postprocessing equivalent, so the bound descends to those equivalence classes.

**Discontinuity theorem.** The operation taking a finite channel to its
greatest complete-maximal-profile representative is not continuous in the
postprocessing diamond-deficiency topology, even for rational qubit channels
with a common full effective output support, a common Choi floor `1/16`,
and fixed input/output dimensions. Every fixed finite family of faithful
RLD-profile tests varies continuously along this example; finite-precision
values of such tests therefore cannot determine the exact canonical lift
uniformly to fixed operational accuracy.

This does not prove discontinuity for every possible uniform metric on the
entire unbounded profile. It is specifically a no-go for channel-norm or finite
physical-test inference of the exact greatest lift without algebra promises.
It is stronger than a mere discontinuity of the output-dimension count: both
canonical outputs here have dimension two. It is distinct from N1708's
Choi-support-sensitive broadcasting classifier.

The exact symbolic identities and positivity bounds are also checked by the
supplementary script. Instability of exact sufficient decompositions is an
older phenomenon: [Kuroiwa's 2021 thesis](https://hdl.handle.net/10012/17174)
discusses sensitivity of Koashi–Imoto decomposition under approximation. I do
not claim discovery of instability in general; the displayed theorem concerns
this particular maximal-profile greatest lift.

## 6. Constructive repairs and generalizations

### 6.1 All members are positive extensions of the intrinsic state

This is a useful normal form, but a direct consequence of the established
classification rather than an independent new discovery. Fix the invariant
`(A_0,T_0,tau_0)` with `A_0=directsum_j M_nj`, and let `h>0` represent
`a tau_0` under its multiplicity-one trace. Choose any faithful representation
`pi:A_0->M_b` and any `Omega>0` satisfying

`Tr(Omega pi(A))=Tr_0(h A)` for every `A in A_0`.

Then `E(X)=Omega^1/2 pi(T_0(X)) Omega^1/2` is CPTP and has exactly this
invariant. Every member arises this way on its effective support. If
`pi(A_0)=directsum_j(M_nj tensor I_mj)`, the restriction is a fixed collection
of partial traces of the diagonal blocks of `Omega`; off-diagonal blocks and
multiplicity degrees of freedom encode ordinary decision loss. This exposes
the profile class as a positive-extension geometry, not as ordinary statistical
equivalence.

The greatest multiplicity-one channel is
`G_0(X)=h^1/2 T_0(X) h^1/2`. Its dimension `sum_j n_j` is minimal because every
faithful representation contains every simple block at least once. A CPTP
simulator for an arbitrary member follows by applying the expectation onto
`A_0`, conjugating by `h^-1/2`, applying `pi`, and conjugating by `Omega^1/2`.
Its trace-preserving property is exactly the displayed restriction equation.

### 6.2 Stable algebra strata do admit continuous lifts

Suppose an explicit channel neighborhood has constant effective support and
constant raw generated-algebra dimension `k`. Choose `k` raw word matrices
that remain a basis there. Their Gram matrix in the normalized inner product
is invertible. The raw projection

`L_E(Y)=sum_j B_j [G_E^-1 v_E(Y)]_j`

and `K_E=L_E^*(I)` are rational functions of the channel entries on this
neighborhood. Thus they are analytic wherever the denominators remain
nonzero. Since `K_E>0`,

`G_E=Ad_(K_E^1/2) E`

is a continuous choice of a greatest representative (unitarily equivalent to
the source's normalized one). If the support floor, Gram floor and `K_E` floor
are explicitly bounded away from zero, all derivative bounds can be made
effective and give a computable local Lipschitz constant. The elementary
square-root estimate follows by solving the Sylvester equation; the channel
bound uses

`||Ad_A E-Ad_B F||_diamond <= ||A||^2||E-F||_diamond + (||A||+||B||)||A-B||`.

The missing decisive operation for a practical noisy theorem is earning these
algebra/Gram promises from obtainable data, rather than silently assuming
them. §5 proves that a Choi floor alone cannot earn them. An algorithm that is
only continuous on exact algebra strata is not yet robust tomography.

### 6.3 Infinite output algebras are a real new boundary, not a free corollary

For finite input and infinite-dimensional output, domination by `E(I)` can
still define bounded normalized generators on the effective support. Their
von Neumann algebra need not be finite-dimensional, type I or injective.
Moment/GNS classification can therefore remain meaningful, but the finite
trace-preserving conditional expectation, multiplicity-one matrix realization
and finite algebraic compiler used for the greatest member do not carry over
automatically. Okayasu's and Hiai's maximal-divergence theory provides the
right comparison machinery; it does not solve this physical greatest-channel
realization problem. A precise theorem identifying existence of greatest
trace-class channel realizations with an intrinsic algebraic property would
be a potentially stronger new question. It is **open in this report**.

## 7. Priority and resource accounting

| Claim | Status after this independent work | Important limit |
|---|---|---|
| Complete profiles determine faithful labelled algebra | Independently re-proved here from visible formulas | Earlier N1698 result, not new capital |
| Greatest lift and minimum algebraic output dimension | Independently checked using finite C*-algebras/Petz | Established ingredients; held compiler not replayed |
| Polynomial equality test | Independently justified by finite closure | Explicit matrices, not succinct circuits |
| Polynomial physical witness compiler and explicit rational gap | Proved here; exact complex example executed | No priority claim; no polynomial sample-complexity claim |
| Canonical lift discontinuity with uniform full Choi floor | Proved here; exact identities checked | Channel norm and finite-test topology, not every conceivable profile metric |
| Stable-stratum continuous reconstruction | Proved conditional on constant algebra dimension and basis conditioning | Does not establish those promises from noisy data |
| Complete-order inequality evaluator | Source-reported N1690; not replayed here | No practical general efficiency |
| All-dimensional broadcasting / finite-memory / `1/k` exponent | Later source-reported N1708 capital | No new proof-package acquisition or rediscovery |
| Infinite-dimensional greatest physical representative | Open | Moment invariance alone does not supply a physical lift |
| Ordinary-capacity approximation, hardware advantage | Not achieved here | No such inference from these results |

Classical arithmetic complexity and physical resources are separate. The
witness compiler needs the entire explicit rational Choi matrices. Input-state
dimension is `a r` with `r<=N`; its stated spectral floors are input floors,
not a claim of well-conditioned physical output tomography. Precision in the
emitted path parameter and gap can be exponentially small in ordinary numeric
scale while having polynomial binary descriptions. The proof offers a
termination/bit-complexity capability, not an experimental shortcut.

Literature searches found substantial priority conflicts with calling Petz
reconstruction, minimal reverse tests, faithful canonical moments or finite
word closure new. They did not establish historical priority for either the
N1698 combination or the two explicit extensions above. The search should be
continued around short physical witnesses and approximate sufficient
decompositions if either becomes the main manuscript claim.
