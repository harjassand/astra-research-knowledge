# Complete maximal-information profiles: supporting research record

6 November 2026. The authoritative consolidated result is [the dossier](../COMPLETE_MAXIMAL_INFORMATION_RESEARCH_DOSSIER.md). This is a research record, not a published paper or a priority certificate.

Three independent GPT-6.1 Sol maximum-reasoning researchers and the principal saved initial reports before mathematical exchange. `initial/` preserves those reports unchanged; `followups/` preserves challenges, repairs and the later historical-priority pass. Source-location and correction notices were shared before mathematical exchange. No additional subagents were used.

Theorems T and B concern finite input, separable trace-class output, the normal labelled invariant, and a faithful TRACIAL invariant state. T concerns exact greatest members; B concerns one common exact-class source at each approximation level. Infinite outputs are permitted. These assumptions cannot be dropped by citing the prior finite theorem.

## Read in this order

1. The dossier and `THEOREM_LEDGER.json` for current statements/status.
2. `followups/machinery_approximate_greatest_converse.md`, `auditor_approximate_greatest_converse.md`, `auditor_haar_exact_class.md` and the constructor challenge for the structural proof and its checks.
3. The `priority_*.md` reports for historical predecessors and narrowed novelty claims. Established injectivity, reverse-test and normal-extension results are not discoveries of this round.
4. The initial reports for independent routes and preserved tentative reasoning.
5. `sources/` for acquired governing returns and current notices. Native N1698 response is explicitly partial; the complete rendered response is a separate pinned source. Original historical proof/compiler packages remain unacquired. N1708 results are prior reported family capital.

## Corrections and boundaries

- Leung–Smith quantum-capacity continuity is Corollary14 (classical13); earlier Corollary7 references in working notes are superseded.
- The full finite-subalgebra lift Lambda_k can be larger than its generated canonical algebra. It is not automatically the minimum greatest representative.
- A common pointwise dominating sequence is sufficient in B; allowing a different source sequence per target is vacuous. The particular pointwise sequence is not asserted to converge uniformly.
- The weak-star hypertrace/expectation in the converse need not be normal. Physical converters remain normal.
- No full-rank Choi promise supplies the algebra-generation margin in S.
- PBT simulation pays communication, storage, local measurement size, heralded acquisition and noise. Its full-environment comparison uses a fixed existential alignment; active adversarial security is not asserted.
- No exact matrix script certifies the analytic infinite-output theorem or historical priority.

## Reproduction

Use Python3 with SymPy and NumPy. Run `python3 replay_checks.py --output /absolute/path/replay-validation.json`. It copies the check files into a fresh temporary tree before execution; it does not overwrite this record. Add `--numerical` to replay the small PBT numerical diagnostics. The final `VALIDATION.json` records the executed clean replay. No package installation, network, Astra account or quantum hardware is needed for these finite checks.

`retrieval/` scripts document read-only source acquisition using the installed Astra backend; they need that backend and its cache and are not portable science proofs. Primary PDFs and full extracted texts remain in the working cache. The `literature/` manifests preserve acquired filenames, URLs, versions and hashes rather than redistributing bulk papers. Original constructor source-pin paths refer to that working cache.

The record's `MANIFEST.json` hashes its payload files and the final dossier; it excludes itself and the surrounding ZIP. The ZIP is verified for CRC errors and payload equality after assembly. An archive hash identifies bytes, not mathematical verification.

## Final cache and priority notes

The final primary-source priority pass is in priority_finite.md, priority_structural.md, priority_constructor.md, priority_principal.md and addendumpriority_generic_experiment.md under followups/. It found substantial established overlap and did not clear historical priority for the residual bridge. The expanded Jones book is only partly inspected. No publication is authorized by this research round.

Disk space ran out during source caching. Only this round’s byte-identical caches were deduplicated, generated PDF page PNGs were removed with the original scan retained, and cached primary HTML files were losslessly compressed to .html.gz after decompression/hash verification. CACHE_COMPACTION_LOG.json records the exact paths. Decompress those working-cache files when reproducing source reads. No mathematical reports, governing source returns, published manuscript bytes or unrelated work were deleted.

An additional 28,966,844 bytes of regenerable page-preview PNGs from the earlier editorial render cache were removed after the storage error recurred. All three source PDFs and validation logs were retained; RENDER_CACHE_CLEANUP.json identifies the exact paths and source hashes.
