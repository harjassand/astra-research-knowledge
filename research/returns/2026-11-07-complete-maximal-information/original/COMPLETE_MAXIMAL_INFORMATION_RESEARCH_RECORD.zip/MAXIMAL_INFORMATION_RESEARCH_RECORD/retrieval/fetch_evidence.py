from pathlib import Path
import sys,json
sys.path.insert(0,'/Users/harjas/.codex/astra-research/backend')
from knowledge.mcp_adapter import ResearchAdapter
root='/Users/harjas/.codex/astra-research/corpus-cache/99c8478ff216d6d60a6690f65c36eb19dbc795b5'
a=ResearchAdapter(root,method='portable');dest=Path('work/maximal-information/sources')
seen=set()
for id in ['N1690','N1698']:
 c=json.loads((dest/(id+'-capsule.json')).read_text())
 print(id,'notices',len(c['notices']))
 for n in c['notices']: print(json.dumps(n))
 for k,e in enumerate(c['evidence']):
  cur=e['fetch_id']
  if cur in seen:continue
  seen.add(cur);pages=[];texts=[]
  while cur:
   f=a.fetch(cur);pages.append(f);texts.append(f['text']);cur=f['metadata'].get('next_id')
  (dest/(id+'-evidence-'+str(k)+'.json')).write_text(json.dumps(pages,indent=2))
  (dest/(id+'-evidence-'+str(k)+'-payload.json')).write_text(''.join(texts))
print('Fetched',len(seen),'distinct evidence routes')
