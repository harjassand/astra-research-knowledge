from pathlib import Path
import sys,json,hashlib,shutil
sys.path.insert(0,'/Users/harjas/.codex/astra-research/backend')
from knowledge.mcp_adapter import ResearchAdapter
root=Path('/Users/harjas/.codex/astra-research/corpus-cache/99c8478ff216d6d60a6690f65c36eb19dbc795b5')
a=ResearchAdapter(root,method='portable');d=Path('work/maximal-information/sources')
for ident in ['N1708']:
 pages=[];texts=[];cur=ident
 while cur:
  x=a.fetch(cur);pages.append(x);texts.append(x['text']);cur=x['metadata'].get('next_id')
 c=json.loads(''.join(texts));(d/(ident+'-capsule.json')).write_text(json.dumps(c,indent=2));(d/(ident+'-fetch-pages.json')).write_text(json.dumps(pages,indent=2))
 for e in c['evidence']:
  p=root/e['source']['path']
  if p.exists():
   assert hashlib.sha256(p.read_bytes()).hexdigest()==e['source']['sha256'];name=ident+'-'+p.name;shutil.copy2(p,d/name);print(name,p.stat().st_size)
 print(ident,'pages',len(pages),'statement',c['statement'][:2000])
