from pathlib import Path
import json,sys
sys.path.insert(0,'/Users/harjas/.codex/astra-research/backend')
from knowledge.published import PublishedAdapter
out=Path('work/maximal-information/sources')
ad=PublishedAdapter('/Users/harjas/.codex/astra-research/backend',method='portable',cache='/Users/harjas/.codex/astra-research/corpus-cache')
for ident in ['N1690','N1698']:
 pages=[];texts=[];cur=ident
 while cur:
  x=ad.fetch(cur);pages.append(x);texts.append(x['text']);cur=x['metadata'].get('next_id')
 (out/(ident+'-fetch-pages.json')).write_text(json.dumps(pages,indent=2))
 capsule=json.loads(''.join(texts));(out/(ident+'-capsule.json')).write_text(json.dumps(capsule,indent=2))
 print(ident,'pages',len(pages),'metadata',pages[0]['metadata'],flush=True)
search=ad.search('complete maximal information profiles canonical greatest channels approximate robustness composition')
(out/'search.json').write_text(json.dumps(search,indent=2));print('search',json.dumps(search)[:5000])
