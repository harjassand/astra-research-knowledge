# Narrow review of the prospective finite-cell Fourier acquisition

2026-11-09. Bound source: ACQUISITION.md, SHA 7f3c1cd42ca361625dafd22e2daabdcc6c7d5dfd666f6fbed819684b44f9e4d8. This is an analytic contract check, not instrument qualification, a statistical experiment or a numerical replay. The reviewer identified the common-law qualification, and the author explicitly added it while preserving the older text.

No concrete blocker was found at the narrowed stated scope.

The cell-average construction is essential. Jensen bounds the sampled average's second moment using the global L2 energy. Its expectation is exactly an integral against a piecewise-constant cosine approximation. The displayed pi/1024 spatial-weight error and 2^-16 coefficient error therefore remain valid for arbitrary L2 fields, without an unearned point-grid or derivative bound. Cauchy gives the stated cell range, and clipping followed by quantization has the stated deterministic error. These conclusions do not establish that a physical sensor can supply the required volume average or RMS accuracy.

After switch-off, the smooth cosine test has viscous derivative 4*pi^2*nu times the score. The quadratic contribution is bounded by (2*pi/a)||u||2^2, using the product of the second and third velocity components. Under the proved energy cap their sum is below .1. Thus the independent post-completion delay at most .01 costs at most .001. Early measurements and cell-correlated timing are correctly excluded.

The combined spatial, coefficient, sensor, rounding and timing bias is below .01 per arm. The Minkowski second-moment bound is below 3. Independent paired differences consequently have variance below 6. A group of 2400 pairs has Chebyshev failure probability below 1/4 at half-width .1. The nine-group median tail is exactly 12826/262144 < 1/20. The ideal interval's half-width is .12, not .1: the two-arm bias allowance is paid. The worst-case positive lower endpoint correctly charges both displacement of the implemented mean and the interval enlargement, leaving 39/400.

The revised source now requires a fixed field pair with independent readouts, or one common i.i.d. paired preparation/realization law, for a two-sided confidence interval about one ideal contrast. This resolves the earlier ambiguity: independence alone does not define such a contrast under changing laws. The separate one-sided uniform-benefit interpretation for independent observations with varying admissible laws is properly distinguished.

The counts of 21,600 pairs, 43,200 readouts, 950,400 selection bits, worst-case repeated evolution time, aggregate actuation and squared actuation are consistent. Preparation, reset, actual averaging hardware, calibration, unresolved input-tail control and independent sampling remain explicitly unacquired. No laboratory practicality or end-to-end execution is certified by this review.
