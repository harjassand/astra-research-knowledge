#!/usr/bin/env python3
"""Read-only SHA-256 verification of all packaged payloads."""
from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parent
m=json.loads((root/'MANIFEST.json').read_text())
for e in m['files']:
 p=root/e['path']
 assert p.is_file(),e['path']
 assert p.stat().st_size==e['bytes'],e['path']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==e['sha256'],e['path']
print('Verified',len(m['files']),'packaged payload hashes.')
