# Self-contained dependency map for the one scalar fiber

The new nonlinear theorem needs only the free scalar channel (m,k)=(1,1). It does not need the in-plane Leray–Jacobi reduction, Jost scattering, an enhanced-dissipation asymptotic, a nonlinear short-pulse theorem, or a general three-actuator composition. The complete historical linear packet is included to preserve provenance and failed bounds; this note isolates the actual dependency.

## Physical Fourier equation

On the exact vertical center U=e3 w(x1,x2), Leray projection is the identity and self-advection vanishes. In either transverse Fourier fiber k2=+/-1, write w as a sum of exp(2 pi i(n x1+k2 x2)). During the plateau the scalar generator, after fixed diagonal unitary phase/sign gauges, is

    A=-d diag(1+n^2)+c K,  n in Z,
    K_(n,n+1)=-1/2, K_(n+1,n)=1/2,
    d=4 pi^2/1000,
    |c|=256 pi theta |1+e2|.

The sine convention in PROOF.md and cosine convention in the historical source differ only by a static phase. The two conjugate real fibers have the same norm. Direct rational bounds 157/50<pi<22/7 and the stated calibration interval give

    197/5000 <= d <= 198/5000,
    801 <= |c| <= 807.

A fixed sign gauge makes c positive. The ramps have the same transverse fibers and physical L2 contraction, independent of the phase.

## Exact finite metric and infinite exterior

Let D be the integer matrix in linear_certificate/exact_saved/m1_k1_free_metric.json. Set S=D/2^40 on -32<=n<=32 and extend S by the identity outside this interval. The six saved congruences prove

    I<S<8I

and strict positivity, at each rectangle corner c in {801,807}, d in {197/5000,198/5000}, of

    H= -A_32^T S-S A_32-2S
       - alpha[(S-I)e_left e_left^T(S-I)
                +(S-I)e_right e_right^T(S-I)],
    alpha=807^2 / [8((197/5000)*1090-1)].

The interior formula is affine in c,d, so one fixed S covers the full physical rectangle. In the exterior, the residual -A^*S-SA-2S equals the positive diagonal 2[d(1+n^2)-1]. All exterior-to-exterior transport cancels. There are exactly two cut bonds. Their cross terms are c(S-I) times the boundary coefficient 1/2. Bounding the two exterior inverse diagonal entries by 1/[2((197/5000)*1090-1)] gives precisely the subtracted alpha term. Thus the full infinite operator satisfies

    A^*S+SA <= -2S.

This calculation is first valid on finitely supported sequences. Diagonal heat plus bounded skew K generates a strongly continuous semigroup. The finite-rank modification S-I preserves the diagonal generator domain, so the form estimate extends by the usual core/energy argument. It follows that

    ||exp(tA)|| <= sqrt(8) exp(-t).

The positive Taylor sum sum_{j=0}^32 8^j/j! exceeds 2048. Therefore sqrt(8) exp(-4)<1/16. No floating eigenvalue is needed for that implication.

## Why the saved positivity witnesses are decisive

For each of the six rational matrices H, a saved dyadic matrix B satisfies exact positive strict row diagonal dominance of B H B^T. It is therefore positive definite. This also forces B to be nonsingular, hence H is positive definite. The auxiliary floating eigensolver only proposed B; its eigenvalues are not premises of the proof.

The read-only script verify_one_channel.py reconstructs all six H matrices from the saved metric and rational constants, multiplies the saved integer congruences, and checks both strict dominance and agreement with the recorded exact margins. It uses Python's arbitrary-precision integers and fractions, with no numerical linear-algebra library, fit, solve, or PDE. Its scalar checks also recount the new theorem's basic rational margins.

The historical qualification checked 60 matrix gates across ten channels. The new theorem uses six of those gates. Historical failed high-sector storage attempts remain in linear_certificate/FLOAT_RESULT.json; they are not needed for this one-fiber argument, and are not silently promoted to successes.
