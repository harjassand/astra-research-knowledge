# A finite-parameter three-dimensional energy-space performance basin

2026-11-09. Author analytic construction. No new PDE propagation, spectral solve, parameter search, or saved-matrix rerun. This result concerns every Leray–Hopf solution. It does not prove regularity or uniqueness of general three-dimensional solutions during the intervention.

## 1. Governing equation, fixed command, and exact claim

Use normalized Lebesgue measure on the unit torus T^3, and the native equation

    partial_t u = nu Delta u - P div(u tensor u) + P[(b dot grad)u],
    div u = 0, mean u = 0, nu = 1/1000.

Here P is the orthogonal Leray projection. The prescribed drift is the FIRST block of the already certified linear command, not the whole three-block word:

    b(t,x) = f(t) theta (e2 + e) sin(2 pi x1 + phi),
    e dot e1 = 0, |e| <= 1/1024,
    theta in [1-1/1024, 1+1/1024].

The phase phi, gain theta, and transverse error e are arbitrary but static during this block. The scalar command rises from zero to 128 by the original quintic smoothstep in time 1/10, is constant for 4 units, and falls to zero by the reverse smoothstep in time 1/10. After T=21/5=4.2 it is zero. No feedback, identification, or intermediate pinching/reset is used.

Set

    a = 1/100,
    U0(x) = a e3 cos(2 pi x2),
    M = ||U0||2 = a/sqrt(2),
    B = {u0: real, mean-zero, divergence-free L2;
               ||u0-U0||2 <= M/5}.

For every u0 in B and every admitted calibration:

1. Every controlled Leray–Hopf solution satisfies

       ||u(T)||2 <= (21/64)||u0||2 < (1/3)||u0||2.

2. Every uncontrolled Leray–Hopf solution from the SAME u0 satisfies

       ||u_free(T)||2 > (1/2)||u0||2.

Thus a full three-dimensional L2 ball, with relative radius 20 percent and absolute radius 1/(500 sqrt(2)), has a strict matched on/off performance separation. The open interior is included; the estimates also cover its closed boundary. There is no restriction on perturbation Fourier support, H3 norm, or dependence on x3. Smooth perturbations are allowed but are not presumed to remain smooth.

The basin is not an exponentially small H3 neighborhood. It is also not a strong-solution basin or a proof of the earlier arbitrary-H3-ball stabilization target.

## 2. The exact scalar center and inherited linear certificate

Under the prescribed drift, U(t)=e3 w(t,x1,x2) is an exact globally smooth solution of the FULL native equation. Indeed U dot grad U is zero, the scalar is independent of x3, the calibrated vertical drift multiplies partial_3=0, and the scalar evolution is

    partial_t w = nu Delta_h w + b_h dot grad_h w.

This field remains divergence free, so Leray is the identity on its right-hand side. The scalar maximum principle yields

    ||w(t)||infinity <= a = 1/100                  (1)

for all time, independently of the drift amplitude, direction error, and static phase.

The initial scalar belongs to the two conjugate transverse fibers k2=+/-1, k3=0, hence m=|xi|^2=1 and dominant coordinate |k2|=1. The saved free-polarization certificate in CERTIFIED_LINEAR_THEOREM.md covers the full longitudinal fiber, not just its initial n=0 mode. It gives plateau operator norm at most 1/16 after four units. Both ramps preserve these fibers and are L2 contractions. Therefore

    ||U(T)||2 <= M/16.                            (2)

This uses only the two real conjugate copies of the already checked (m,k)=(1,1) free channel. It does not claim a full-space contraction for one actuator. Its untouched-axis linear operator norm still equals the no-driver norm.

For b=0 the corresponding exact center is

    U_free(t)=exp(-4 pi^2 nu t) U0.

Since 4 pi^2 nu < 1/25 and T=21/5, exp(-x)>1-x gives

    exp(-4 pi^2 nu T) > 1-21/125 = 104/125 > 4/5.  (3)

## 3. A drift-independent nonlinear relative-energy inequality

Let U=e3 w be the smooth scalar center under either the controlled or zero drift. Let u be any Leray–Hopf solution with the SAME prescribed drift and let z=u-U.

The standard weak–strong relative-energy identity, obtained by testing the weak equation against the smooth U and using the two energy relations, gives

 ||z(t)||2^2 + 2 nu integral_0^t ||grad z||2^2
 <= ||z(0)||2^2 - 2 integral_0^t integral z3 z_h dot grad_h w.   (4)

The prescribed transport cancels exactly in the cross energy because div b=0. No derivative of b occurs. Its Leray projection is harmless against divergence-free test fields. The perturbation self-advection also cancels. This argument works for the native transport form; it would not automatically apply to a different control containing (u dot grad)b.

Using div_h z_h = -partial_3 z3 and partial_3 w=0,

 -integral z3 z_h dot grad_h w
 = integral w z_h dot grad_h z3 - integral w z3 partial_3 z3
 = integral w z_h dot grad_h z3.                 (5)

The last term vanishes by periodic integration in x3. Mean-zero Poincare applies to the horizontal components on the full T^3:

    ||z_h||2 <= ||grad z_h||2/(2 pi).

Consequently, writing D=||grad z||2,

 |integral w z_h dot grad_h z3|
 <= [||w||infinity/(2 pi)] ||grad z_h||2 ||grad_h z3||2
 <= [||w||infinity/(4 pi)] D^2.                  (6)

This component structure is stronger than bounding the base by its large H3 norm or gradient. It uses the actual scalar maximum principle, not a maximum principle for a general Leray velocity.

In general, if ||w(0)||infinity <= 4 pi nu, (4)-(6) show that every perturbation has nonincreasing L2 distance from this center, regardless of perturbation amplitude. In our numerical normalization, pi>25/8 implies

    a/(4 pi nu) < 4/5.

Thus

 ||z(t)||2^2 + (2 nu/5) integral_0^t ||grad z||2^2
 <= ||z(0)||2^2.                                (7)

In particular ||z(t)||2 <= ||z(0)||2. The small relative radius of B is needed for a useful endpoint comparison, not to derive (7).

For completeness, the prescribed drift is smooth in space and bounded with sufficient time regularity. The usual divergence-free Galerkin construction gives global Leray–Hopf solutions with the unforced energy inequality, because prescribed transport is skew in L2. Smooth U is an admissible relative-energy test after time approximation. Inequality (7) initially holds at the standard energy times; weak continuity and lower semicontinuity extend its norm bound to every t. No uniqueness of u is inferred. The same reasoning applies independently to all uncontrolled Leray–Hopf solutions.

## 4. Endpoint and same-input no-control separation

For u0 in B, put r=||u0-U0||2 <= M/5. By (2) and (7),

    ||u(T)||2 <= M/16+r <= (21/80)M,
    ||u0||2 >= M-r >= (4/5)M.

Dividing gives 21/64 < 1/3.

For the SAME initial datum in the no-control experiment, (3) and (7) give

    ||u_free(T)||2 >= ||U_free(T)||2-r > (3/5)M,
    ||u0||2 <= M+r <= (6/5)M.

The ratio is therefore strictly greater than 1/2. This is a statement for every datum and every pair of admitted Leray–Hopf realizations, not merely a slow center or a worst-case datum somewhere in the ball.

An explicit genuinely three-dimensional smooth member is

 u0 = a e3 cos(2 pi x2)
      +(1/2000)[e1 cos(2 pi x3)+e2 sin(2 pi x1)+e3 sin(2 pi x2)].

It is divergence free, mean zero, depends on all three coordinates, and has relative perturbation norm sqrt(3)/20 < 1/10. Its nonlinear self-advection is not identically zero. An additional mean-zero, divergence-free manufacturing error of L2 norm at most M/10 keeps it in B. This is a conditional preparation specification, not a certified experimental input.

## 5. A directly measurable low-mode prediction

Define the normalized vertical Fourier score

    F(u)=(2/a) integral_T3 u3(x) cos(2 pi x2) dx.

The center initially has F(U0)=1. Its dual L2 norm gives |F(z)|<=||z||2/M. Therefore

    F(u_control(T)) <= 21/80,
    F(u_free(T)) > 3/5,
    F(u_free(T))-F(u_control(T)) > 27/80.          (8)

The controlled score can have either sign; the upper bound is enough. Unlike total terminal kinetic energy, (8) can be acquired by a single Fourier-weighted velocity measurement. A separate acquisition note pays finite-variance spatial sampling and makes its calibration assumptions explicit.

## 6. Physical cost, prior, and limitations

The command is one 4.2-unit block: nominal scalar peak 128, calibrated vector peak below 129, nominal slew at most 2400, scalar area 524.8, and integrated squared command at most 68812.8. It uses one fixed spatial frequency p=e1. These are nondimensional mathematical quantities, not watts, seconds, monetary cost, or demonstrated hardware performance. The actuator is much stronger than the initial fluid amplitude 0.01.

The underlying nonlinear energy method is established Reynolds–Orr methodology. Global energy-space stability of symmetric Navier–Stokes flows under general three-dimensional Leray–Hopf perturbations is established prior; see Bardos, Lopes Filho, Niu, Nussenzveig Lopes, and Titi, arXiv:1201.2742v2, Theorem 3.1 and its relative-energy argument (3.7). Their stated theorem is unforced and in its declared geometry; our prescribed skew drift and component bound are derived above, not imported as an unexamined corollary. The inherited spectral operation is independently certified but is not a nonlinear regularity theorem.

Primary sources checked:
- https://arxiv.org/html/1201.2742v2
- https://people.math.wisc.edu/~fwaleffe/GFD2011lectures/GFD3.pdf

This is a finite-time performance law for all energy-admissible solutions of the stated model. It does not select a unique physical solution, exclude singularities, prove a global strong basin, or make a generic turbulence claim. The exact initial mean, divergence constraint, full L2 preparation error, controller calibration, viscosity, spatial periodicity, and readout error contract must be supplied or separately qualified. No experimental calibration is acquired here.
