# Exact read-only package replay

One pre-frozen standard-library replay completed successfully on 2026-11-09:

- Six pre-existing free-channel matrix gates passed.
- Each saved exact diagonal-dominance margin was reproduced.
- Ten rational scalar reserves passed, including the plateau exponential, nonlinear ratios, readout bias/variance and confidence margin.
- Whole-child elapsed time: 0.568801124998572 seconds.
- Peak resident memory: 12,288 KiB. Return code: 0.
- The declared cap was 20 seconds, with one computational thread.

The source and all scientific inputs were frozen beforehand. No metric or congruence was generated, changed or fitted. No nonlinear or linear PDE was propagated. No parameter was retuned. The replay's stdout, stderr, receipt and input freeze are included.

This run verifies the read-only packaging aid against the existing exact witnesses. It is not an independent mathematical audit, a new scientific dataset, or an experiment. The historical floating screen and exact 60-gate producing pass have separate receipts and scopes in linear_certificate/.
