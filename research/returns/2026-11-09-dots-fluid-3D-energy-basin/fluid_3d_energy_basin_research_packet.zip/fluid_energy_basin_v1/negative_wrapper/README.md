# Preserved negative nonlinear gate

The generic identity-plus-finite-rank cubic energy wrapper could not enlarge the stronger no-control admission at the tested viscosity. Its saved diagonals force a lower bound C_F>56. Together with the untouched-axis decay ceiling, that particular sufficient wrapper reaches only H3 radius below 267/1400, whereas the explicit no-control baseline already admits radius 0.256. This is not a no-go for the physical controller or a different nonlinear argument.

The proof, all 650 exact diagonal values and scalar results, and the historical execution receipt are preserved here unchanged. The full rational metrics are in ../linear_certificate/exact_saved/. This appendix is not needed for the new energy-stable basin theorem; it documents why an earlier generic wrapper was abandoned. It was not rerun for this archive. The main read-only verification entry point checks the exact channel used by the positive theorem, not this separate historical wrapper.
