# A saved-metric discriminator for the generic cubic-energy wrapper

2026-11-09. New source-only proposal, not a nonlinear admission theorem. No saved metric is changed. The fixed linear theorem, failed high-sector screen and actual-dissipative controller remain separate.

## 1. The exact operation under test

On one fixed plateau write the physical storage as P=I+F, with F supported on the retained nominal-dominant transverse fibers and longitudinal modes |n|<=32. Both real physical polarizations are included. The retained pairs and multiplicities are

    (m,k)=(1,1),(2,1),(4,2),(5,2),(8,2),
    multiplicities=2,4,2,4,4.

These are the 16 integer transverse vectors (k2,k3) with 0<k2^2+k3^2<=8 and |k2|>=|k3|. The same geometry applies after relabeling coordinates at another stage. In the native polarization the saved rational metric S has energy G_n=m+n^2, and the physical metric is G^(-1/2) S G^(-1/2). In the free polarization G=I. Static sign/phase gauges preserve diagonal entries.

For every smooth real divergence-free u, the identity part of the nonlinear storage derivative cancels. With N(u)=P_Leray div(u tensor u),

    |<Fu,N(u)>|=|<grad(Fu),u tensor u>|
                <=C_F ||u||2^3,
    C_F=||grad F||_(L2_sigma -> Linfinity_Frobenius).

A full-space pointwise linear inequality V'<=-2lambda V plus this generic bound yields decay under the sufficient condition C_F E0<lambda, where E0 is the supplied invariant L2 bound. This is the PARTICULAR wrapper under test. It does not exploit phase-sensitive cubic cancellation, a restricted H3 shape, a time-dependent whole-word metric, higher-order Lyapunov terms, or a nonlinear background. None of those alternatives is ruled out here.

## 2. Exact lower bound on this norm, from saved diagonals only

Let T_x be the map from divergence-free Fourier coefficients to the nine physical components of grad(Fu)(x). On the real Hilbert space, its rank is at most nine. Thus

    C_F^2 >= sup_x ||T_x||HS^2/9
           >= integral_T3 ||T_x||HS^2 dx/9.

The real sine/cosine basis for opposite Fourier pairs has the same Hilbert--Schmidt trace as the complex Fourier representation; it does not add or remove a factor two. Parseval gives

    integral ||T_x||HS^2 dx
       =(2pi)^2 sum_(output k,input l) |k|^2 ||F_kl||F^2.

Suppose the proposed exact check proves EVERY retained diagonal in EACH polarization satisfies F_nn>=1/32. Retain only diagonal blocks in the nonnegative sum. Since

    sum_(retained physical k) |k|^2
      =16*sum_(n=-32)^32 n^2+65*(2+8+8+20+32)
      =370630,

both polarizations give

    C_F^2 >= (2pi)^2 *741260/(9*32^2) >56^2.       (1)

The final strict inequality follows using 2pi>157/25 and exact rational arithmetic. The condition F_nn>=1/32 becomes an INTEGER test on the already saved metric numerator Snum with scale2^40:

    32*(Snum_nn-scale*G_n)>=scale*G_n.

This is not a new spectral solve, floating positivity test, or rounded estimate of F. If any diagonal fails, the proposed uniform lower-bound gate fails and all results are retained. No weaker threshold is substituted afterward.

## 3. Why this specific wrapper cannot improve the prior basin

Every one-stage storage is the identity on the untouched longitudinal axis. Its k=(1,0,0) mode evolves by pure heat, so any full-space pointwise decay constant necessarily obeys

    lambda<=4pi^2 nu<.04  at nu=1/1000.

For the entire H3 ball of radius K, the exact largest allowed energy is

    E0=K/(1+4pi^2)^(3/2).

This maximum is attained by a real divergence-free first harmonic; it cannot be replaced by a smaller uniform number without changing the input class. Since (1+4pi^2)^(3/2)<267, (1) implies that the generic sufficient condition can hold uniformly only if

    K < (.04*267)/56 =267/1400 <.191.              (2)

The conclusion concerns the generic condition, not the true nonlinear dynamics. It is stronger than merely reporting a loose upper bound on C_F: the norm in that chosen condition is itself bounded BELOW.

A strictly stronger established zero-driver sufficient basin is available by a sharper elementary lattice bound. Cauchy gives

    Fminus1(u)<=||u||H3 sqrt(sum_(k!=0)
       1/[(2pi|k|)^2*(1+(2pi|k|)^2)^3]).

Separate the exact first max-norm shell and bound the remaining shells by26r^2 points. Since 2pi>25/4,

    sum <=(4/25)^8*[6+12/16+8/81
                         +26*(1/64+1/160)] <1/512^2.  (3)

The tail uses sum_(r>=2)r^-6<=2^-6+integral_2^infinity x^-6 dx. Thus Fminus1<=K/512. Applying the SAME already supplied Fourier-critical continuation with q=K/(512nu)<=1/2 admits b=0 for K<=256nu. At the fixed viscosity this is K<=.256, which strictly contains (2). Its global H3 and terminal bounds are paid by the earlier NO_CONTROL_AND_COST proof with the new q; no unforced arbitrary-data regularity is claimed.

If the saved diagonal gate passes, this closes the particular generic cubic-energy wrapper as a competitive route at this benchmark, even before the separate strong-continuation gap. It is not a no-go for finite-rank storage with sharper nonlinear information, for the certified linear schedule, or for the audited actual-dissipative controller.

## 4. Constructive matrix-specific upper operation, not run

A future sharper norm computation has a finite access contract. In the native polarization, an absolute-column upper bound is

    C_fiber^2 <=(2pi)^2 sum_l
       (sum_n |S_nl-G_n delta_nl|)^2/G_l.

This follows because the physical output derivative magnitude cancels sqrt(G_n) in G^(-1/2) S G^(-1/2). The free case replaces the inner term by sum_n sqrt(m+n^2)|F_nl|. Sum these bounds over physical fibers and polarizations. All square roots and pi can be enclosed rationally, with all conversion/work costs counted. This is a universal phase bound, not assumed tight. No such upper-norm computation is executed or needed for the proposed lower-bound gate.

## 5. Prior, scope and authorship

Goulart--Chernyshenko, arXiv:1101.1043v2, Sections4--5 (directly read at https://arxiv.org/html/1101.1043v2), already formulate finite resolved variables coupled to uncertain tail energy and use rigorous nonlinear norm bounds in Lyapunov/SOS conditions. Huang et al., https://pmc.ncbi.nlm.nih.gov/articles/PMC4685881/, supply a worked fluid-stability application. The broad methodology is therefore prior, not a novelty claim. The exact saved-diagonal stop criterion is a model-specific comparison of the current wrapper with a mandatory stronger baseline.

The fellow fluid constructor suggested the Hilbert--Schmidt lower-bound discriminator and sharper first-shell comparison; the present author checked the real/complex normalization, output dimension, physical weights and scope before proposing a run. This is not an independent audit of the saved linear certificate. The exact metric files are read as inputs; no eigenproblem, Lyapunov solve, PDE or giant synthesis is part of this gate. No new control success is asserted.
