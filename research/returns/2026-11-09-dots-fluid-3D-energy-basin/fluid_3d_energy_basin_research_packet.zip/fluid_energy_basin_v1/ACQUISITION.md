# Prospective finite-bit Fourier readout and honest implementation costs

2026-11-09. This is an analytic acquisition contract for PROOF.md, not an experiment or a completed device calibration. It measures a low Fourier coefficient rather than assuming access to the entire terminal velocity field.

## 1. Ideal observable and finite partition

For a=1/100, the ideal score is F(u)=(2/a) integral u3 cos(2 pi x2). The proved contrast is

    Delta = F(u_free(T))-F(u_control(T)) > 27/80,
    T=21/5.

Each state has ||u||2 <= ||u0||2 <= (6/5)M. A formally uniform point sample would have finite second moment, but replacing it by a finite grid of point values is NOT valid for arbitrary L2 fields. The following instrument avoids that aliasing gap.

Partition T^3 into 64 by 1024 by 64 equal rectangular cells. Choose one cell uniformly with 22 random bits. The instrument returns the VOLUME AVERAGE of u3 over that cell, not an unqualified point value. Let y be its x2 center. Multiply the average by (2/a) c_y, where c_y is a rational approximation to cos(2 pi y) with error at most 2^-16.

The expectation is the integral against a piecewise-constant approximation of the cosine. Since the cosine varies by at most pi/1024 inside a cell,

 |E Y - F(u)| <= (2/a)||u||2 (pi/1024 + 2^-16)
              < 6/1024 + 2/65536.                         (1)

This bias is volume- and high-frequency-uniform. It requires the specified cell averaging; 43,200 arbitrary point readings cannot certify the same result without further smoothness or distribution assumptions.

Jensen's inequality gives the ideal finite-cell score's second moment at most

    (1+2^-16)^2 * 2*(6/5)^2
    = (1+2^-16)^2 * 72/25.                               (2)

No output L-infinity or derivative bound is used. A finite range is nevertheless available for cell averages: cell volume is 2^-22, so their magnitude is at most 2^11 ||u||2 < 32. Thus clipping readout to [-32,32] does not increase error relative to the true cell average. Quantizing the clipped velocity with step 2^-20 needs at most 27 signed bits and adds error at most 2^-21.

The 1024 cosine coefficients can be prepared once by rational Taylor arithmetic, with pi bracketed to sufficient precision, and rounded to a 16-bit dyadic grid. This is a fixed finite preprocessing problem. No transcendental oracle, output-dependent fitting, or giant controller synthesis is required. A direct certified cosine polynomial on [-pi,pi] suffices; coefficient preparation has not been executed in this packet.

## 2. Explicit, unacquired instrument and timing contract

Assume:

- The preparation belongs to the proved ball, including mean zero and divergence freedom. The input can be a declared finite Fourier profile plus a separately certified total L2 manufacturing error. Finite low-mode calibration alone does not bound an unknown unresolved tail.
- Each measured cell average has root-mean-square raw velocity error at most 1/100000 before the clipping/rounding above. This includes systematic offset and random sensor error. It must be qualified in the actual spatial averaging geometry and velocity range; it is not inferred here.
- Cells are sampled independently and uniformly. For the two-sided confidence interval below, use either a fixed pair of controlled/uncontrolled fields with independent readouts, or a common independent and identically distributed paired preparation/realization law. Independence alone with an arbitrarily changing law is insufficient to define one common contrast. A noninvasive fixed-field imaging protocol may supply conditional independence.
- Readout occurs at a common time in [T,T+1/100], or at an independently sampled delay in that interval. The delay must be independent of the cell index and the field. The command is already off. Early readout or uncertain actuator completion is not covered.
- Actual viscosity, command, and static calibration satisfy the governing proof. No arbitrary time-dependent phase, spatial leakage, or boundary error is silently admitted.

After T, testing the weak equation against the smooth Fourier mode shows that F is absolutely continuous and

 |F'(t)| <= 4 pi^2 nu |F(t)| + (2 pi/a)||u(t)||2^2
          < 1/10.

Thus the allowed post-completion delay costs at most 1/1000 in mean score. Combining this with (1), sensor error multiplied by 2/a, and dyadic rounding gives a total systematic mean bias below 1/100 per arm. Conservatively the observed score has second moment below 3: its L2 sampling norm is at most the square root of (2), plus the normalized sensor and rounding errors, which is less than 171/100.

These are paid mathematical implications of an explicit instrument contract. The actual instrument qualification, initial-profile manufacture, cell geometry, coordinate registration, and independent snapshot or reset capability are NOT acquired or costed as free. Without them, the physical acquisition is pending rather than validated.

## 3. A simple variance-only confidence ledger

Use independent paired observations D=Y_free-Y_control. The variance is below 6. For each of nine groups, take 2400 such pairs and form its arithmetic mean. Chebyshev gives probability at most 1/4 that a group mean differs from its expectation by more than 1/10. Take the median of the nine group means.

With independent groups, its failure probability is at most

    sum_{k=5}^9 binom(9,k)(1/4)^k(3/4)^(9-k)
    = 12826/262144 < 1/20.                                (3)

The statistical half-width is 1/10. The two instrument-bias allowances add 1/50, so an interval for the IDEAL contrast must have half-width 3/25, not merely 1/10. Under the proved alternative, the worst-case lower confidence endpoint is strictly greater than

    27/80 - 2*(1/50) - 2*(1/10) = 39/400.                 (4)

Both the shift of the implemented mean and its inclusion in the ideal confidence interval are charged. This is standard median-of-means statistics, not a new estimation principle. A valid null interpretation still requires the stated preparation, energy, and instrument variance contracts. If the preparation or realization law changes between runs but every run stays within the theorem, the uniform per-group positive-gap bound still supports a one-sided benefit test; it must not be reported as a two-sided confidence interval for one fixed ideal contrast.

Counts:
- 21,600 paired observations;
- 43,200 cell-averaged velocity readouts;
- 950,400 independent random bits for cell selection;
- fixed-width coefficient/velocity products and rational group means; no fitted root or trajectory reconstruction.

If each readout needs a fresh physical run, the maximum total evolution wait is 43,200*(4.2+0.01)=181,872 native time units, plus all preparation/reset/readout overhead. Only half the runs use the actuator. Their aggregate nominal scalar action is 11,335,680 and aggregate integrated squared command is at most 1,486,356,480 in the model's units.

A truly noninvasive simultaneous spatial snapshot could reduce the number of repeated evolutions, but that hardware is not assumed. The finite-variance result does not establish seconds of wall time, energy consumption, sensor resolution feasibility, or a ready laboratory protocol.
