"""One frozen floating finite-matrix feasibility screen, not a certificate."""
from pathlib import Path
import json,time
import numpy as np
from scipy.linalg import solve_continuous_lyapunov,eigvalsh

ROOT=Path(__file__).resolve().parent
N=32;rate=1.0;duration=4.0
pairs=[(1,1),(2,1),(4,2),(5,2),(8,2),(9,3),(10,3),(13,3),(16,4),(17,4)]
dlo,dhi=.0394,.0396;dmid=.0395
out=[]
start=time.monotonic()
for m,k in pairs:
 for pol in ['free','native_in_plane']:
    n=np.arange(-N,N+1,dtype=float);g=m+n*n
    edges=n[:-1]
    a=np.full(2*N,.5) if pol=='free' else (m+edges*(edges+1))/(2*np.sqrt((m+edges**2)*(m+(edges+1)**2)))
    K=np.diag(-a,1)+np.diag(a,-1)
    D=dmid*g
    Amid=-np.diag(D)+(804*k)*K
    row={'m':m,'k':k,'polarization':pol,'N':N,'lambda':rate,'duration':duration,
         'c_interval':[801*k,807*k],'d_interval':[dlo,dhi]}
    try:
        P=solve_continuous_lyapunov((Amid+rate*np.eye(2*N+1)).T,-2*np.diag(D))
        P=(P+P.T)/2
        vals=eigvalsh(P,check_finite=True)
        row['metric_eigenvalue_min']=float(vals[0]);row['metric_eigenvalue_max']=float(vals[-1])
        row['lyapunov_center_residual_max']=float(np.max(np.abs((Amid+rate*np.eye(2*N+1)).T@P+P@(Amid+rate*np.eye(2*N+1))+2*np.diag(D))))
        gout=m+(N+1)**2
        boundary=.5 if pol=='free' else (m+N*(N+1))/(2*np.sqrt((m+N*N)*gout))
        C=np.zeros((2*N+1,2));C[0,0]=boundary;C[-1,1]=boundary
        B=(P-np.eye(2*N+1))@C
        tail=(807*k)**2/(2*(dlo*gout-rate))*(B@B.T)
        corners=[]
        for c in [801*k,807*k]:
         for d in [dlo,dhi]:
            A=-np.diag(d*g)+c*K
            R=-A.T@P-P@A-2*rate*P-tail
            R=(R+R.T)/2
            corners.append({'c':c,'d':d,'schur_residual_min_eigenvalue':float(eigvalsh(R,subset_by_index=[0,0])[0])})
        row['corners']=corners
        margin=min(x['schur_residual_min_eigenvalue'] for x in corners)
        row['minimum_schur_margin']=margin
        row['primary_floating_gate']=bool(vals[0]>1+1e-8 and vals[-1]<8-1e-8 and margin>1e-8)
        row['fallback_floating_gate']=bool(vals[0]>1+1e-8 and vals[-1]<32-1e-8 and margin>1e-8)
        row['floating_norm_bound_if_certified']=float(np.sqrt(max(1,vals[-1]))*np.exp(-rate*duration)) if vals[0]>=1 and margin>=0 else None
        # Save complete candidate matrices for a separately authorized exact pass.
        np.savez(ROOT/f'candidate_m{m}_k{k}_{pol}.npz',P=P,skew=K,g=g)
    except Exception as exc:
        row['error']=repr(exc)
        row['primary_floating_gate']=False;row['fallback_floating_gate']=False
    out.append(row)
result={'scope':'FLOATING feasibility screen only; not an exact positivity or nonlinear/PDE certificate.',
        'fixed_parameters':{'nu':'1/1000','nominal_amplitude':128,'duration':duration,'cutoff':N,'lambda':rate,'pairs':pairs},
        'cases':out,'all_primary':all(x['primary_floating_gate'] for x in out),
        'all_fallback':all(x['fallback_floating_gate'] for x in out),
        'kernel_wall_seconds':time.monotonic()-start}
(ROOT/'FLOAT_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'all_primary':result['all_primary'],'all_fallback':result['all_fallback'],'cases':[{key:r.get(key) for key in ['m','k','polarization','metric_eigenvalue_min','metric_eigenvalue_max','minimum_schur_margin','primary_floating_gate','fallback_floating_gate','error']} for r in out]}))
