# Post-screen analytic repair: use both common-axis stages

2026-11-09. This is a separate author-derived composition lemma. It does not alter the frozen screen, whose all-sector primary and fallback gates both failed. The ten low-sector floating candidates have not yet received exact positivity certification.

## 1. Preserve the actual failure

At the frozen N=32, lambda=1, viscosity 1/1000, nominal amplitude 128 and plateau time 4, all ten cases with m<=8 passed the floating Schur-storage gate. All ten cases with m>=9 failed that gate. The largest metric eigenvalue was below 1.734, but the worst corrected Schur residual was approximately -74.154. These failed tail estimates remain part of the record. No cutoff, rate, physical amplitude or duration was changed.

## 2. Conditional exact low-sector input

Suppose, using the saved matrices or another separately declared certificate, that all four calibration corners in INFINITE_TAIL_INTERFACE.md are certified for only

    (m,k)=(1,1),(2,1),(4,2),(5,2),(8,2),

both native polarizations, with I<=P<=8I and lambda=1. Then the corresponding actual infinite-line plateau operators have L2 norm at most 1/16 after time 4. This is the still-unpaid exact input, not a conclusion from floating arithmetic.

Let T1,T2,T3 be the actual LINEAR viscous shear blocks, respectively with nominal (p,a) equal to (e1,e2), (e1,e3), (e2,e1). Each contains a four-unit plateau at amplitude128 and two optional 0.1-unit ramps with the same fixed spatial calibration and phase. Ramps may be any nonnegative scalar shape at most128, since their sole use below is sector-preserving L2 contraction. The original static error/gain radius 1/1024 and arbitrary independent static phases are admitted.

## 3. First two blocks

Let E be the k=(n,0,0), n!=0 axis and Q its orthogonal complement. Both T1 and T2 preserve every transverse xi=(k2,k3) and E. In a fiber with m=|xi|^2, the energy inequality gives

    ||Tj|xi|| <= exp(-4*d*m),  d>=197/5000,

even if that fiber is weak or resonant for the actual direction. Extra ramp time only strengthens this displayed bound.

For m>=9, their product therefore has norm at most

    exp[-8*(197/5000)*9] = exp(-1773/625) < 1/16.

The last inequality can be checked by a finite rational Taylor lower sum for exp(1773/625); it is not a fitted threshold.

For 0<m<9, choose the nominally dominant coordinate. The assigned block has speed in [801k,807k] and is one of the five low-sector cases above, so it contracts by1/16. The other block is contractive on that SAME invariant fiber. It follows that

    ||T2 T1 Q|| <= 1/16.                                    (3.1)

Thus no storage certificate for any of the ten failed high-m cases is necessary for this whole-word conclusion.

## 4. Remaining axis and third block

On E the first two blocks are exactly ordinary heat. For |n|>=3 they already contract by exp(-1773/625)<1/16. The third block preserves its transverse coordinates (k1,k3), so it cannot mix the low-axis input |n|<=2 with these high-axis inputs. On n=+/-1,+/-2, the third block's m is1 or4, again inside the saved low-sector set, and its plateau contracts by1/16. This orthogonality gives

    ||T3 T2 T1 E|| <= 1/16.                                 (4.1)

On Q, T3 is contractive. The final E and Q images need not be orthogonal, so we use the safe triangle/Cauchy estimate, not a false invariant-axis claim:

    ||T3 T2 T1 f|| <= (||Ef||+||Qf||)/16
                   <= sqrt(2)/16 ||f||.                     (4.2)

This is a conditional, all-mode, all-polarization LINEAR operator-norm result with no high-frequency input restriction or neglected return path.

## 5. Concrete linear command and honest limits

A C2 command uses the quintic ramp r(s)=10s^3-15s^4+6s^5 on each 0.1-unit ramp, then a four-unit constant plateau. Three blocks take12.6 dimensionless time units. Nominal scalar peak is128, scalar slew at most2400, total absolute scalar area is1574.4, and integral of its square is at most206438.4. Static spatial gain/direction errors multiply the corresponding spatial norm bounds. These are dimensionless mathematical actuator values; no apparatus calibration or physical unit conversion is asserted.

The no-driver linear semigroup has exact mean-zero L2 norm exp[-4*pi^2*(1/1000)*12.6], which is greater than1/2. Hence, IF the low-sector exact input is earned, (4.2) beats the actual unforced full-space linear baseline by a substantial factor at these fixed parameters. It does not merely improve a generic polynomial exponent.

The native nonlinear Navier-Stokes equation is a different claim. The current forward native interface requires a shortness budget far below these block durations when nu=.001 and K>=1; it therefore does NOT admit this schedule. L2 contraction alone cannot prove global strong continuation in3D. Any later nonlinear use must separately certify lifespan, nonlinear error and a strong/critical endpoint. This packet does not claim those operations, fixed-tolerance practical control, or a fluid experiment.

## 6. Next paid step

If separately authorized, round only the ten saved low-sector metrics to dyadic rational weighted-coordinate witnesses, and check the exact rational metric inequalities and four Schur corners with finite positive-definiteness certificates. Preserve every failure, no parameter/cutoff/rate retuning. Success would earn the concrete linear result above; it would not upgrade its nonlinear scope.
