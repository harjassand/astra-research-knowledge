# Finite-parameter, calibrated, infinite-mode linear viscous-shear certificate

2026-11-09. Author-constructed analytic/computer-assisted certificate. The exact arithmetic run is not a proof-assistant validation, independent end-to-end audit, nonlinear Navier–Stokes controller, PDE simulation, or device experiment. The inherited native Leray-to-Jacobi reduction remains an analytic dependency.

## The quantified statement

On the unit three-torus, consider the mean-zero divergence-free LINEAR equation

    u_t = (1/1000) Delta u + P[(b(t,x) dot grad)u].

Use three consecutive prescribed blocks with nominal spatial pairs

    (p1,a1)=(e1,e2), (p2,a2)=(e1,e3), (p3,a3)=(e2,e1).

In block j, the implemented spatial field is theta_j(a_j+e_j) cos(2pi p_j dot x+phi_j), where the independent errors are static over that block,

    |theta_j-1|<=1/1024, e_j dot p_j=0, |e_j|<=1/1024,

and phi_j is arbitrary. Multiply it by the scalar command consisting of a0.1-unit quintic ramp from0 to128, a4-unit constant plateau, then a0.1-unit reverse ramp. All spatial frequencies and plateau/ramp durations in this theorem are exact. No spatial leakage, time-dependent direction error or nonlinear self-advection is silently included.

For every mean-zero divergence-free initial datum in L2, the time12.6 solution satisfies

    ||u(12.6)||2 <= sqrt(2)/16 ||u(0)||2.                    (T)

The actual mean-zero no-driver linear semigroup at the same viscosity and time has norm exp[-4pi^2*.001*12.6]>1/2. Thus (T) is a full-space finite-parameter improvement over a paid baseline, not a claim based on a few initial vectors or finite-cutoff eigenvalues.

## Exact low-sector certificate

The native Fourier reduction and calibration bounds are detailed in the unchanged INFINITE_TAIL_INTERFACE.md. The five retained pairs are

    (m,k)=(1,1),(2,1),(4,2),(5,2),(8,2),

and both free and native in-plane polarizations are included. The speed/damping rectangle is c in[801k,807k], d in[197/5000,99/2500]. It contains every physical value admitted above using157/50<pi<22/7 and the static calibration bounds. Signs and phases are unitary gauges.

At longitudinal cutoff N=32, the exact pass rounded the ALREADY SAVED floating matrices to rational metrics S with denominator2^40. This is merely the definition of the new rational witness; no rounding-error premise is needed. Free-polarization energy weight is G=I. Native in-plane energy weight is G_n=m+n^2 and the rational skew generator has adjacent coefficients

    K_(n,n+1)=-(m+n(n+1))/(2G_n),
    K_(n+1,n)=+(m+n(n+1))/(2G_(n+1)).

The pass verified G<S<8G and, at all four rectangle corners, strict positivity of

    -A_N^T S-S A_N-2S
    -c_max^2/[2(d_min q_out-1)G_out]
          (S-G) K_LH K_LH^T (S-G),                          (1)

where q_out=m+33^2, the two boundary columns K_LH use the INTERIOR row denominators, and G_out=q_out for the native polarization or1 for the free polarization.

There are60 exact matrix gates:2 metric comparisons plus4 corners for each of10 cases. Every one passed. For each target symmetric rational matrix H, an auxiliary floating diagonalization proposed a dyadic matrix B with denominator2^48. The decisive computation then formed B H B^T in exact integer arithmetic and checked all65 strict row diagonal-dominance inequalities. Positive diagonal dominance proves positive definiteness of the congruence. It also implies B is nonsingular, so H is positive definite. No floating eigenvalue, condition number or factorization is trusted as evidence of positivity.

The exact witness metrics and all60 congruence matrices are saved under exact_saved/. The input/source freeze is EXACT_FREEZE.json, SHA a11c18dacdc10b96b6473c0c19480a1fb7c8f23edd1160909478a0f7ef3d8ee6. The executed checker is qualify_saved_exact.py, SHA50c83962c4312bedcd53632c2876024703cb739c096a6b97b39a25b868a41895. A verifier may reconstruct every rational H from the saved metric and declared integers; no future floating solve or physical oracle is required.

## Why this controls the infinite Fourier tail

Extend S by the natural diagonal energy metric G outside |n|<=32. The exact exterior dissipation residual is2(dq_n-1)G_n, positive beyond the cutoff. Internal exterior skew transport cancels. The only interior/exterior couplings are the two boundary bonds. Taking their exact Schur complement gives (1). Bounding the exterior inverse by the displayed d_min value and c^2 by c_max^2 is conservative. The finite part is affine in c,d, so four corners cover the entire rectangle with the SAME metric. The weighted inequality therefore holds on the full infinite line, not merely the truncated matrix.

Standard closure of the diagonal dissipative generator plus bounded skew Jacobi perturbation then gives

    ||exp(tA)||2 <= sqrt(8) exp(-t)

in the physical orthonormal energy representation. The exact positive Taylor sum confirms exp(8)>2048; hence each retained active plateau contracts by1/16 after time4. The ramps preserve the same transverse sector and contract L2, so they cannot undo this bound.

## Why the failed high-sector screen is not hidden

The original frozen floating screen sought a separate storage bound for every m<18. It FAILED in all ten m>=9 cases. Those failures, including negative infinite-tail margins, are unchanged in FLOAT_RESULT.json and the original report/manifest.

The separate TWO_STAGE_HEAT_REPAIR.md proves that these cases are unnecessary for the whole-word theorem. The first TWO blocks preserve the same transverse sector and together dissipate every m>=9 by ordinary heat:

    exp[-8*(197/5000)*9]=exp(-1773/625)<1/16.

That final inequality was also checked by an exact positive Taylor sum. For m<=8, one nominally dominant-coordinate block has the certified active speed; the other is contractive. Thus the off-axis input is reduced by1/16 before block3.

On the original k1 axis the first two blocks are exactly heat, so |k1|>=3 is already reduced by1/16. The third block needs the low-sector storage only for k1=+/-1,+/-2. It preserves (k1,k3), making these low-axis and high-axis outputs orthogonal. Its full axis norm is therefore at most1/16. The final axis and original off-axis images may overlap, so their contributions are combined by triangle/Cauchy, producing sqrt(2)/16 rather than an unearned1/16.

## Resources and limits

The single exact child completed in3.727289329 seconds, peak50,288 KiB, return code0. The preceding single floating feasibility child cost0.829608051 seconds, peak49,104 KiB. These are selected operation costs, not total research time. No physical trajectory, full nonlinear synthesis or PDE propagation was run.

Nominal scalar peak is128; each ramp's scalar slew is at most2400. Total time is12.6, total scalar absolute area1574.4, and integrated squared scalar command at most206438.4. The calibrated spatial-vector peak is at most129, not exactly128. These are dimensionless mathematical values, not verified hardware specifications.

The present native nonlinear shortness interface does not admit these multi-unit plateaus at nu=.001,K>=1. L2 contraction is not a3D strong-continuation theorem. The remaining operation is a paid nonlinear/critical-norm bridge at these actual parameter values. Neither the earlier giant-resource nonlinear controller nor this concrete linear certificate supplies that bridge automatically.

The method is compared with standard quadratic hypocoercivity, exact Schur tails, robust-corner positivity, and Goulart–Chernyshenko's finite-mode/uncertain-tail nonlinear Lyapunov framework. See PRIOR_AND_NONLINEAR_BOUNDARY.md. No general enhanced-dissipation or external novelty claim is made.
