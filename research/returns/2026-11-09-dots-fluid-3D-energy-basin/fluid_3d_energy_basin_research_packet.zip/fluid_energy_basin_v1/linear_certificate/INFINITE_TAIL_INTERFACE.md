# A finite-matrix storage certificate for the actual infinite viscous shear

2026-11-09. Analytic construction interface, not yet an executed or verified certificate. This targets the actual native LINEAR viscous Leray shear. It does not remove the nonlinear Navier-Stokes transfer obligation.

## 1. Concrete finite-parameter target

Fix viscosity nu=1/1000, nominal shear amplitude128 and plateau duration4 on the unit torus. Keep the original independent STATIC spatial calibration radius1/1024 and arbitrary phases. For the first two same-p shears use the known dominant-coordinate partition: assign a transverse sector xi=(k2,k3) to pulse1 when |k2|>=|k3| and to pulse2 otherwise. Put m=|xi|^2 and k equal to the dominant absolute integer coordinate.

The calibrated vector satisfies |v-a|<=2rho+rho^2<1/500. Since sqrt(m)<=sqrt(2)k<(3/2)k, its speed differs from the nominal dominant coordinate by less than3k/1000. The elementary 157/50<pi<22/7 therefore implies

    |c|=2pi*128*|v.xi| in [801k,807k],
    d=4pi^2nu in [197/5000,99/2500]=[.0394,.0396].           (1.1)

The third shear on the original k1 axis satisfies the same speed box. The sign of c and the static phase are removed by diagonal unitary/reflection gauges; they do not change viscosity or norms.

Both native Fourier polarizations have generators

    A=-d diag(m+n^2)+i c J_m, n in Z,

where the free polarization has a_n=1/2 and the in-plane polarization has

    a_n=(m+n(n+1))/(2sqrt((m+n^2)(m+(n+1)^2))).

The J_m coefficients and energy normalization are the inherited exact native Leray reduction, not a passive-scalar substitution. Multiplication by i^n transforms the imaginary symmetric coupling into a REAL skew coupling with upper entry -a_n and lower entry a_n.

For m>=18, pure transverse heat already gives norm<=exp[-(.0394)*18*4]<1/16. The last strict scalar inequality can be paid by a rational Taylor lower bound on the exponential. Thus a 1/16 target needs only

    (m,k)=(1,1),(2,1),(4,2),(5,2),(8,2),
          (9,3),(10,3),(13,3),(16,4),(17,4).                (1.2)

These are all sums k^2+l^2<18 with0<=l<=k. The target primary gate is a uniform L2 norm<=1/16 at time4 for all these sectors and BOTH polarizations. A declared weaker fallback is1/8, not an unreported retuning.

## 2. Exact infinite-tail storage condition

In the orthonormal polarization representation, cut at |n|<=N. Let A_N(c,d) be the finite tridiagonal compression, and choose one Hermitian positive P_N, independent of c,d inside a declared box. Extend it to the entire line by

    P=P_N direct-sum I_outside.

For rate lambda>0 define

    R_N(c,d)= -A_N(c,d)^* P_N-P_N A_N(c,d)-2lambda P_N.

The high-frequency residual is EXACTLY2[d(m+n^2)-lambda] times identity: its internal skew coupling cancels because the exterior metric is identity. Only the two cut bonds remain. Let C be the matrix with boundary columns a_(-N-1)e_-N and a_N e_N; signs do not affect their outer-product sum. Let g_out=m+(N+1)^2. If d_low*g_out>lambda and every corner(c,d) of the rectangle obeys

 R_N(c,d) >= c_high^2/[2(d_low*g_out-lambda)]
                   *(P_N-I) C C^* (P_N-I),                 (2.1)

then -A^*P-PA>=2lambda P on the FULL infinite Fourier line. This is the exact two-column Schur complement, not an unpriced cutoff or neglected returning wave.

Indeed, the full residual's off-diagonal block is the signed/skew equivalent of c(P_N-I)C, and its outer block is positive diagonal. Only its two boundary diagonal inverse entries enter the Schur complement. Replacing c^2 by c_high^2 and d by d_low is safe. R_N is affine in c,d, so checking all four corners proves the condition throughout the box with the same P_N. No monotonicity of a nonnormal semigroup in c is assumed.

If I<=P_N<=M I, the full metric satisfies I<=P<=max(1,M)I. Then

    ||exp(tA)||L2->L2 <=sqrt(max(1,M))*exp(-lambda t).       (2.2)

This follows from the energy inequality on finite-support vectors and closure: J_m is bounded self-adjoint and the diagonal dissipative generator is closed. It is an operator-norm statement for arbitrary longitudinal initial data, not an eigenvalue-only screen.

At lambda=1,t=4, M<=8 suffices for1/16, and M<=32 suffices for1/8. Both reduce to the exact scalar inequality exp(8)>2048. All signs/phases are restored by the unitary gauges.

## 3. Rational version without square-root coefficient oracles

For the in-plane polarization use the unnormalized streamfunction coordinates with energy G_n=m+n^2. The skew generator has rational upper coefficient

    K_(n,n+1)=-(m+n(n+1))/(2G_n),
    K_(n+1,n)=+(m+n(n+1))/(2G_(n+1)).

It obeys K^T G+G K=0. Choose a rational finite metric S_N and extend by G_outside. The finite residual is

    -A_N^T S_N-S_N A_N-2lambda S_N,

and the boundary columns become (S_N-G_N)K_LH. The exterior diagonal is2[dG_n-lambda]G_n. This gives a completely rational Schur condition for rational speed/damping boxes, rate and S_N, with metric comparisons G_N<=S_N<=M G_N. The free polarization uses G=I. A rounded numerical candidate can thus be checked by exact rational positivity; a floating check is NOT that certificate.

## 4. Declared feasibility screen, not yet a theorem conclusion

The first bounded screen fixes N=32,lambda=1 and every pair(1.2), both polarizations. At c_mid=804k,d_mid=.0395 it constructs P_N from

    (A_N+I)^T P_N+P_N(A_N+I)=-2D_N,
    D_N=d_mid diag(m+n^2).

If A_N+I is stable, this choice equals I plus a positive integral. Stability and positivity must nevertheless be checked rather than presumed. The screen checks all four corner Schur residuals and the metric gates in floating arithmetic, preserving every outcome. It performs no physical parameter, cutoff or rate retuning. A positive floating margin is only permission to attempt a separately paid exact-rational pass.

## 5. What a successful certificate would and would not buy

The existing common-p three-stage LINEAR composition would give global L2 contraction at most sqrt(2)/16 (or the fallback sqrt(2)/8). Smooth on/off ramps preserving one spatial shear are also L2 contractions in each fiber, so they cannot undo an operator contraction earned during its constant plateau. This supplies a way to use legal C2 envelopes without pretending the ramps are instantaneous or unforced heat; their durations/amplitude/slew still require an explicit controller ledger.

The total native linear time with three4-unit plateaus and two0.1-unit ramps per plateau is12.6. The no-driver linear baseline has exact full mean-zero L2 norm exp(-4pi^2nu*12.6), about0.61; that comparison is linear only.

The actual nonlinear equation is NOT linear, and L2 decay alone is not a strong continuation theorem in3D. A finite-rank storage defect may improve the nonlinear energy pairing, but a paid critical/strong-solution transfer remains essential. The amplitude128 and dimensionless time4 are a declared mathematical test, not a claim that a real actuator or fluid apparatus meets these scales.

## 6. Prior and novelty boundary

This uses standard quadratic Lyapunov/storage inequalities, robust affine-corner checking and a Schur complement. The exact native Jacobi reduction is inherited Astra capital. Scalar enhanced-dissipation theory (including Bedrossian--Coti Zelati arXiv1510.08098) and abstract mixing-to-dissipation work (Coti Zelati--Delgadino--Elgindi arXiv1806.03258) are stronger primary method baselines than eigenvalue fitting, but cannot be silently applied as a calibrated nonlinear native-velocity theorem.

The potential useful increment is a fully paid finite-parameter infinite-mode certificate for these native polarizations, replacing enormous generic scattering constants at the declared test. Neither a new general enhanced-dissipation theorem nor practical nonlinear control is claimed.
