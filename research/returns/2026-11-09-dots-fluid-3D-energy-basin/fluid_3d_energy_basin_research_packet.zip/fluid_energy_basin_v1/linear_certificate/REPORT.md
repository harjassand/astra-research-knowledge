# Frozen floating sector screen: report

The single predeclared screen completed once. Its original primary AND fallback all-sector gates failed. Ten of twenty cases passed, exactly the m<=8 cases. No retuning or second run was performed.

Whole-child wall time: 0.829608051 seconds. Peak RSS: 49104 KiB. Return code: 0. All candidate matrices, stdout, stderr, the freeze and receipts are preserved. These are floating feasibility diagnostics, not exact positivity, PDE propagation, nonlinear control or hardware validation.

The separate TWO_STAGE_HEAT_REPAIR.md explains why the FAILED high-m storage cases can be bypassed analytically in the full three-block linear word: both first stages dissipate them by ordinary transverse heat. It preserves the original failure and explicitly leaves exact rational certification of the ten passing low-sector matrices unpaid.

Strong prior is standard hypocoercive quadratic storage, Schur-complement tail certification and calibrated affine corners, applied to the inherited exact native Leray Jacobi representation. No novelty claim is made.
