# Separate robustness corollaries of the common finite storage metric

2026-11-09. These author-derived corollaries are separate from the sealed CERTIFIED_LINEAR_THEOREM.md. They concern only the same linear equation. The independent reviewer confirmed the pointwise-storage argument analytically in collaboration; no numerical rerun or new positivity assertion is used.

## 1. Gain/direction variation with fixed spatial phase

The same rational metric S works at every point of each speed/damping rectangle. Consequently the low-sector estimate also holds when c=c(t) is measurable in that rectangle: the differential storage inequality holds almost everywhere and integrates directly. Commutation of distinct generators is unnecessary.

For the physical driver, keep each coordinate p and phase phi FIXED during its plateau, but allow the gain theta(t) and transverse error e(t) to vary within the original1/1024 bounds. The Fourier polarizations depend only on p,xi,n, not on this transverse vector. It changes only the scalar c(t). In an assigned dominant-coordinate fiber the sign cannot cross zero, so a single fixed sign/phase gauge suffices for the entire interval. Thus the same full-space linear contraction follows. Smooth error functions may be used if the classical time-regularity formulation requires them.

This does NOT admit phase drift, off-frequency leakage or a changing p. Nor does a bound on error amplitude provide an actuator-slew bound. A time-dependent physical direction's derivative must be separately budgeted for any hardware-resource statement. Viscosity remains fixed at.001 in this physical corollary; the abstract rectangle statement is broader.

## 2. A concrete duration-error variant

With the original STATIC spatial calibration, specify three sequential blocks whose nominal plateau is4.5 and nominal ramp lengths are.1. Suppose each actual plateau duration lies in[4.05,4.95] and each actual ramp duration in[.09,.11], with quintic ramps stretched to their actual lengths. No overlap, unbudgeted idle/start delay or phase variation is admitted. The command is zero after block3.

Every plateau is at least4, so the exact certificate remains valid. The total actual active time is at most3*(4.95+.22)=15.51. Observe at the common time16, including any remaining zero-driver heat interval. The full L2 contraction is still at mostsqrt(2)/16. The common-time no-driver norm is exp(-4pi^2*.001*16)>1/2. For an elementary strict comparison, the exponent is less than2/3 and exp(2/3)<2 follows from exp(1)<11/4 and121/16<8.

Nominal scalar peak remains128. Actual scalar slew is at most128*(15/8)/.09=8000/3; static vector calibration multiplies this by less than(1025/1024)^2. Actual scalar area is at most3*128*(4.95+.11)=1943.04 and integrated squared scalar command at most128^2*15.51. These remain dimensionless mathematical values, not acquired apparatus tolerances.

This is bounded relative duration uncertainty under a sequential-clock contract, not an arbitrary fixed-absolute-timestamp error. The native nonlinear admission gap is unchanged.
