# Prior and the remaining nonlinear operation

2026-11-09. Separate source note; the frozen screen and repair are unchanged.

Goulart and Chernyshenko, *Global Stability Analysis of Fluid Flows using Sum-of-Squares*, arXiv:1101.1043v2, especially Sections4–5, is a direct primary baseline: unresolved Navier–Stokes modes are treated as uncertain forcing with a tail-energy variable and rigorous norm bounds, then included in a Lyapunov/SOS condition. Primary text read at https://arxiv.org/html/1101.1043v2 . This already establishes the broad finite-resolved/paid-tail Lyapunov strategy. Our two-port linear Schur reduction is a particularly simple model-specific instance, not a new general stability methodology.

The relevant enhanced-dissipation comparators remain Bedrossian–Coti Zelati arXiv:1510.08098 and Coti Zelati–Delgadino–Elgindi arXiv:1806.03258. Their scalar/abstract or linearized-flow results are not an automatic nonlinear calibrated native-transport controller.

For the controlled equation u_t=nu Delta u+P(b dot grad u)-P(u dot grad u), an exact linear storage metric is insufficient. If the physical storage operator is I plus a finite-rank smooth operator F, the nonlinear energy defect is

    <F u, P(u dot grad u)> = -<grad(Fu), u tensor u>,

because the identity part cancels by incompressibility. A bound ||grad(Fu)||infinity<=C_F||u||2 would therefore give a cubic energy defect. This is a possible computable interface, but not yet a strong-solution/critical-norm admission theorem. For a three-block schedule one must also pay metric changes and weak/resonant sectors; no common global storage was silently constructed here.

The current independent forward native lemma has a shortness condition bounded by nu/(2^20 K^2), among other stricter terms. At nu=.001,K>=1 this does not admit the present multi-unit plateaus. Thus, even a successful exact linear qualification would leave a substantial, explicitly identified nonlinear gap. It would replace the astronomical generic spectral constant for a fixed physical test, but would not make the original all-H3-ball controller practical.

A credible next discriminator is a separately frozen nonlinear storage or strong-norm enclosure using these finite witnesses, compared against the mandatory no-control basin. It should stop if the proved nonlinear basin lies entirely inside the already-known zero-driver basin. No such run or theorem is claimed here.
