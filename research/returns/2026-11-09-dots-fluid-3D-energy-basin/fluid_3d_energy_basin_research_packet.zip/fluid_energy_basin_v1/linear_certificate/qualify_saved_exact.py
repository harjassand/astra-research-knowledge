"""One exact rational saved-witness pass. No new Lyapunov/physical solve or tuning.
Floating eigh supplies dyadic congruence coordinates ONLY. All pass gates are exact.
"""
from pathlib import Path
from fractions import Fraction as F
from math import lcm,factorial
import hashlib,json,time
import numpy as np
from scipy.linalg import eigh
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'exact_saved';OUT.mkdir(exist_ok=True)
N=32;SIZE=65;SB=40;QB=48;SCALE=1<<SB
PAIRS=[(1,1),(2,1),(4,2),(5,2),(8,2)]
start=time.monotonic();results=[]
def native(v):return int(v)
def rows(a):return [[int(x) for x in r] for r in a]
def positivity(H,den,name):
    assert den>0
    assert np.array_equal(H,H.T)
    # Eigenvectors are merely untrusted proposals for a rational congruence.
    hf=np.array([[float(int(x))/float(den) for x in r] for r in H])
    vals,U=eigh(hf,check_finite=True)
    B=np.array([[int(round(float(x)*(1<<QB))) for x in r] for r in U.T],dtype=object)
    C=(B@H)@B.T
    assert np.array_equal(C,C.T)
    margins=[int(C[i,i])-sum(abs(int(C[i,j])) for j in range(SIZE) if j!=i) for i in range(SIZE)]
    ok=min(margins)>0
    witness={'name':name,'scope':'Exact integer congruence and strict diagonal dominance; auxiliary eigenvectors are not trusted.',
             'congruence_bits':QB,'congruence_numerator':rows(B),
             'matrix_positive_denominator':str(den),'minimum_diagonal_dominance_numerator':str(min(margins)),
             'positive':ok,'auxiliary_float_min_eigenvalue':float(vals[0])}
    (OUT/(name+'.json')).write_text(json.dumps(witness,separators=(',',':'))+'\n')
    return {'name':name,'positive':ok,'minimum_dd_numerator':str(min(margins)),
            'auxiliary_float_min_eigenvalue':float(vals[0])}
for m,k in PAIRS:
 for pol in ['free','native_in_plane']:
    tag=f'm{m}_k{k}_{pol}';case={'m':m,'k':k,'polarization':pol,'checks':[]}
    try:
        path=ROOT/f'candidate_{tag}.npz'
        with np.load(path) as z:P=z['P'].copy()
        q=np.array([m+n*n for n in range(-N,N+1)],dtype=object)
        w=q if pol=='native_in_plane' else np.ones(SIZE,dtype=object)
        rootw=np.sqrt(np.array(w,dtype=float))
        Sf=(rootw[:,None]*P)*rootw[None,:]
        D=np.array([[int(round(float(x)*SCALE)) for x in r] for r in Sf],dtype=object)
        # Symmetry is enforced exactly, without changing diagonal values.
        for i in range(SIZE):
         for j in range(i):D[i,j]=D[j,i]
        G=np.diag(w)
        metric={'m':m,'k':k,'polarization':pol,'N':N,'metric_bits':SB,'metric_numerator':rows(D),
                'source_npz_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
        (OUT/(tag+'_metric.json')).write_text(json.dumps(metric,separators=(',',':'))+'\n')
        case['checks'].append(positivity(D-SCALE*G,SCALE,tag+'_lower'))
        case['checks'].append(positivity(8*SCALE*G-D,SCALE,tag+'_upper'))
        KL=lcm(*(2*int(x) for x in w))
        KI=np.zeros((SIZE,SIZE),dtype=object)
        for i,n in enumerate(range(-N,N)):
            numer=m+n*(n+1) if pol=='native_in_plane' else 1
            KI[i,i+1]=-numer*(KL//(2*int(w[i])))
            KI[i+1,i]=numer*(KL//(2*int(w[i+1])))
        assert np.array_equal(KI.T@G+G@KI,np.zeros((SIZE,SIZE),dtype=object))
        AD=5000*KL
        qout=m+(N+1)**2;wout=qout if pol=='native_in_plane' else 1
        bnum=m+N*(N+1) if pol=='native_in_plane' else 1
        kb=F(bnum,2*int(w[-1]))
        tail=F((807*k)**2)*kb*kb/(2*(F(197,5000)*qout-1)*wout)
        assert tail>0
        V=D-SCALE*G
        outer=np.outer(V[:,0],V[:,0])+np.outer(V[:,-1],V[:,-1])
        for c in [801*k,807*k]:
         for dn in [197,198]:
            AI=-dn*KL*np.diag(q)+c*5000*KI
            RN=-(AI.T@D+D@AI)-2*AD*D
            H=RN*tail.denominator*SCALE-outer*tail.numerator*AD
            den=AD*tail.denominator*SCALE*SCALE
            case['checks'].append(positivity(H,den,tag+f'_c{c}_d{dn}'))
        case['passed']=all(x['positive'] for x in case['checks'])
    except Exception as e:
        case['error']=repr(e);case['passed']=False
    results.append(case)
    (OUT/'PARTIAL.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps({'case':tag,'passed':case['passed'],'error':case.get('error')}),flush=True)
# Fully exact sufficient exponential comparisons.
def esum(x,n):return sum((x**j/F(factorial(j)) for j in range(n+1)),F())
scalar={'exp8_gt2048':esum(F(8),32)>2048,'exp1773over625_gt16':esum(F(1773,625),20)>16}
result={'scope':'Exact saved-witness qualification only. No new Lyapunov or physical solve, cutoff/rate/parameter change, PDE propagation or nonlinear admission.',
        'fixed_parameters':{'N':N,'lambda':1,'metric_bits':SB,'congruence_bits':QB,'pairs':PAIRS},
        'cases':results,'scalar':scalar,'all_pass':all(x['passed'] for x in results) and all(scalar.values()),
        'kernel_wall_seconds':time.monotonic()-start}
(OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'all_pass':result['all_pass'],'cases':len(results),'exact_matrix_checks':sum(len(x['checks']) for x in results),'scalar':scalar}),flush=True)
