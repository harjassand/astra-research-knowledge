# Independent analytic and source challenge of the finite-parameter linear certificate

2026-11-09. Scope: independently inspect the native polarization reduction, uncertainty coverage, infinite-tail Schur condition, exact checker construction, whole-word heat repair and no-driver comparison. This review did not rerun the60 integer congruence gates, perform a new floating solve, propagate a PDE, or test a nonlinear controller. It verified the110 file hashes in the existing exact manifest and inspected saved integer-witness structure. The existing execution receipt supplies the reported gate outcomes.

## Verdict

No concrete analytic obstruction or source/statement mismatch was found. The stated all-calibration, infinite-mode LINEAR bound `sqrt(2)/16` at time12.6 follows from the archived positive exact gates through the displayed argument. The high-sector screen failures are genuinely bypassed by a valid two-block heat estimate, not silently deleted or relabeled as successes. The bound is meaningfully smaller than the actual full-space no-driver linear norm at the same viscosity and time.

This is not an independent replay of all saved numerical certificates, a proof-assistant check, a nonlinear Navier–Stokes admission, or an apparatus claim. A source review plus the producing run's receipt should not be described as a second execution.

## Bound source state

- Governing theorem `CERTIFIED_LINEAR_THEOREM.md`: SHA256 `9a6ea7ee366e19e9b9e744d5628d5748acc426d023453ab23df4c6e5060dcd2a`.
- `INFINITE_TAIL_INTERFACE.md`: `9e659d090830f438511bfa06066e97c12cbba17c3615ed390b3716d9399ac30c`.
- `TWO_STAGE_HEAT_REPAIR.md`: `892ff8cab3a0f7aa208ea8ad2ff4f18550dcd2a96f6cd1d735c78ff1e2f30692`.
- Exact checker `qualify_saved_exact.py`: `50c83962c4312bedcd53632c2876024703cb739c096a6b97b39a25b868a41895`.
- `EXACT_FREEZE.json`: `a11c18dacdc10b96b6473c0c19480a1fb7c8f23edd1160909478a0f7ef3d8ee6`.
- `exact_saved/RESULT.json`: `6c97d89819e6e090bb7d3dc380f4b78cc975d5031ca3db2ebcbdb1fa72570eca`.
- `EXACT_MANIFEST.json`: `bb71748584e5c4d4f5ad2fb652790942790ef8821bb6a79f8fa9a1a331b512aa`. All110 listed file digests matched during this review.

No governing file was changed by this review.

## 1. Actual native polarizations and calibration

For one coordinate shear, fixing the transverse integer frequency xi gives `(v.grad)=2pi i(v.xi)`. The direction v therefore enters the longitudinal generator only through the scalar speed. Leray projection between neighboring frequencies has a fixed free polarization perpendicular to the plane spanned by p and xi, and an in-plane polarization. The latter has neighboring unit-vector overlap

    [m+n(n+1)] / sqrt[(m+n^2)(m+(n+1)^2)],  m=|xi|^2.

The cosine supplies the factor1/2. Thus the two displayed Jacobi channels are the actual native velocity reduction, not a replacement by a passive scalar. The polarizations depend on p,xi,n, not on the calibrated transverse v. The zero-transverse-frequency fiber is handled separately as ordinary heat.

With rho=1/1024, `v=theta(a+e)` satisfies

    |v-a| <= rho+(1+rho)rho = 2rho+rho^2 < 1/500.

For a nominally dominant coordinate k, `sqrt(m)<=sqrt(2)k<3k/2`; hence `.997k<|v.xi|<1.003k`. The elementary pi enclosure gives

    256*(157/50)*(997/1000) > 801,
    256*(22/7)*(1003/1000) < 807.

The speed rectangle therefore contains every admitted active physical speed. Similarly `197/5000 < 4pi^2/1000 < 99/2500`. Signs are removable by a fixed alternating diagonal gauge; static phases by a fixed diagonal phase gauge. Both commute with viscosity and preserve the physical norm. Independent phase and calibration choices in different blocks cause no problem because the intermediate composition uses physical L2 bounds, not a common metric across different blocks.

The frozen theorem assumes fixed phase and direction within each block, exact spatial frequencies and exact times. It does not cover phase drift, off-frequency leakage or nonlinear self-advection.

## 2. Weighted rational coordinates and the infinite tail

Writing physical orthonormal in-plane coordinates as `z_n=sqrt(G_n) psi_n`, with `G_n=m+n^2`, converts the skew coupling to

    K_(n,n+1) = -[m+n(n+1)]/(2G_n),
    K_(n+1,n) = +[m+n(n+1)]/(2G_(n+1)).

Thus `K^T G+G K=0`. The checker correctly uses the INTERIOR weight in the boundary coefficient from outside to inside. At either cut bond its absolute coefficient is

    kb=[m+N(N+1)]/[2(m+N^2)]

for the native in-plane channel, or1/2 for the free channel. The two cut bonds have the same absolute coefficient by reflection.

Extend the finite metric S by G outside. In the residual `-A^T S-SA-2S`, the exterior block is exactly the positive diagonal `2(dq_n-1)G_n`. All internal exterior skew terms cancel. The cross-block term is `-c(S-G)K_LH`; there are precisely two boundary columns. Eliminating the exterior therefore gives the finite subtraction

    c^2 kb^2/[2(dq_out-1)G_out]
       *[(S-G)e_left e_left^T(S-G)
          +(S-G)e_right e_right^T(S-G)].

There is no truncated-tail approximation in this expression. Replacing its scalar by the c_max,d_min value is conservative. The remaining finite residual is affine in c,d, and the same S is used at all four corners. Hence corner positivity covers the full rectangle without any assumption that nonnormal semigroup decay is monotone in c.

In physical orthonormal coordinates, the metric is identity plus a finite-rank bounded perturbation, and the generator is the closed diagonal dissipative operator plus bounded skew Jacobi coupling in each retained sector. The energy inequality extends from its core. Thus the infinite-line implication is justified at the stated linear scope.

## 3. Exact source construction and certificate meaning

I checked the integer scaling in the source. With `L=2^40`, `S=D/L`, `A=AI/AD`, `V=D-LG`, and the positive rational tail coefficient `tailnum/tailden`, the desired matrix is

    RN/(AD L) - tailnum*outer/(tailden L^2),
    RN=-(AI^T D+D AI)-2AD D,
    outer=V_left V_left^T+V_right V_right^T.

The saved checker constructs exactly the numerator

    H=RN*tailden*L-outer*tailnum*AD

over the positive denominator `AD*tailden*L^2`. Its `dn=197,198` over5000 gives the declared damping endpoints. Its rational K coefficients satisfy the exact G-skew check. Lower and upper metric gates are exactly `D-LG>0` and `8LG-D>0`.

The decisive array products have object-integer entries. Floating diagonalization is used only to propose the saved integer matrix B; rounding a candidate does not itself certify anything, but the subsequent exact multiplication does. The check `C_ii>sum_(j!=i)|C_ij|` for symmetric `C=BHB^T` gives positive definiteness by Gershgorin. It also forces B to have full rank, so an additional determinant test is unnecessary. Therefore H is positive definite.

The saved metric defines a rational witness in its own right. Its validity does not depend on the accuracy of the earlier floating Lyapunov solve, square roots or rounding. Saved metric and congruence matrices inspected here had the declared65-by65 integer structure. The manifest binds all remaining witnesses and the source. This review did not independently recompute all60 products; the archived producing run reports60 successes and two exact scalar successes.

## 4. Whole-word composition and failed-sector repair

The first two blocks preserve the same transverse frequency xi relative to p=e1. In every fiber their physical energy supplies a norm factor at most `exp(-4dm)` per plateau, regardless of whether the actual transport speed is active, weak or resonant. Therefore for m>=9 the pair contributes

    exp[-8*(197/5000)*9] = exp(-1773/625) < 1/16.

The exact positive Taylor lower-sum check in the saved source is a valid way to prove the last inequality. It uses no floating exponential.

The only nonzero sums of two squares below9 are1,2,4,5,8. A nominally dominant-coordinate block is certified for each, and its partner remains contractive in that same invariant fiber. No commutation between the two different calibrated generators is required. Hence the original off-axis input Q is reduced by1/16 after the first two blocks.

On the original p=e1 axis E, those two blocks are exactly heat. Modes with |n|>=3 already satisfy the same1/16 bound. The third block preserves its own transverse coordinates `(k1,k3)`, so its outputs from original axis modes |n|<=2 are orthogonal to those from |n|>=3. The low-axis modes have third-block parameters m=1 or4 and are certified. Thus the full original axis contribution is at most1/16.

The third block is contractive on the off-axis image. Final axis and off-axis images need not be orthogonal. The proof correctly uses

    ||T3 T2 T1 f|| <= (||Ef||+||Qf||)/16
                      <= sqrt(2)||f||/16.

The failing individual-storage cases with m>=9 remain failures. The two-block heat estimate makes those individual conditions unnecessary for this particular whole-word theorem. This is a valid analytic repair, not an unreported physical parameter change.

## 5. Scalar exponential gates, legal command and baseline

Metric comparison `G<S<8G` gives norm at most `sqrt(8)exp(-4)` over the plateau. Its being below1/16 is equivalent to `exp(8)>2048`, exactly the first scalar gate. The source computes positive finite Taylor lower sums for both exponential gates with rational arithmetic. Positive omitted terms justify the direction of each comparison.

The quintic ramp has `r'=30s^2(1-s)^2`, maximum15/8, and r,r',r'' match the neighboring zero/constant segments. Consequently the three-block command is globally C2, nominal scalar peak128, slew at most `1280*(15/8)=2400`, and total time `3*(4+1/10+1/10)=63/5`. The ramp symmetry gives total scalar area `3*128*(4+1/10)=1574.4`. Bounding the full command by128 yields the stated squared-area upper bound `128^2*(63/5)=206438.4`. Finally `128|v|<=128(1+1/1024)^2<129`. These are dimensionless command values, not spatial W3 norms or hardware measurements.

The exact unforced mean-zero linear norm is `exp(-d*63/5)`, attained on a divergence-free |k|=1 Fourier mode. A simple exact proof of the claimed lower baseline is

    d*(63/5) < (99/2500)*(63/5) = 6237/12500 < 1/2,
    exp(1/2) < sum_(j>=0)(1/2)^j = 2.

Thus the no-driver norm is strictly greater than1/2, whereas the certified controlled upper bound is `sqrt(2)/16`. The comparison is full-space linear operator norm against full-space linear operator norm, not selected test vectors against an unmatched baseline.

## 6. Remaining boundary

The proof does not establish a nonlinear strong-solution interval, pay the nonlinear storage defect, or enter a critical continuation basin. The previous short-pulse theorem does not admit these multi-unit plateaus at the stated viscosity and incoming K>=1. That is a substantive remaining operation, not a minor implementation detail.

The method uses established Lyapunov/storage and exact Schur-complement ideas, with the inherited native Leray reduction. The useful supported increment is the saved finite-parameter all-mode LINEAR certificate under the stated static calibration and explicit baseline. Broad novelty, practical control and nonlinear stabilization should not be inferred.

An optional pointwise-storage extension was discussed separately with the author: with fixed p and phase, a common S would allow scalar speed/damping varying measurably within the same rectangle, since polarizations do not depend on v. This observation is not included in the frozen theorem or its certification scope, and supplies no actuator-slew or phase-drift allowance.
