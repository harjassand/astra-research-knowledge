# One fixed actuator: a certified three-dimensional energy-space performance basin

## Result in one paragraph

For the native controlled Navier–Stokes model on the unit three-torus at viscosity 0.001, one prescribed shear pulse of duration 4.2 and nominal peak 128 reduces the L2 velocity norm by a factor below 1/3 for **every Leray–Hopf solution** from a specified full three-dimensional L2 ball. Every no-control solution from the same initial ball retains more than half its initial norm at the same time. The ball has relative radius 20 percent around 0.01 e3 cos(2 pi x2), admits arbitrary three-dimensional perturbations, and is independent of the unknown allowed static calibration.

This is a complete, narrow quantitative performance certificate, not a proof of general three-dimensional regularity. It is packaged because the exact infinite-mode linear witness, nonlinear energy argument, same-input baseline, and independent source review form one auditable result. No novelty or laboratory feasibility is claimed.

## Read first: what is NOT claimed

- No uniqueness, absence of singularities, or global strong-solution theorem for arbitrary data in the ball.
- No solution of a full H3-ball stabilization problem.
- No nonlinear simulation, PDE trajectory computation, hardware run, or acquired laboratory calibration.
- No empirical validation of the prescribed transport model, periodic geometry, viscosity, preparation error, or readout contract.
- No new general Reynolds–Orr energy-stability principle. The contribution is the explicit composition and finite-parameter certificate.

The theorem bounds every energy-admissible realization despite possible nonuniqueness. If a claim requires a uniquely selected smooth physical trajectory throughout the intervention, that stronger requirement remains open here.

## The model and scope

The equation is

    u_t = 0.001 Delta u - P div(u tensor u) + P[(b dot grad)u].

The controller is prescribed TRANSPORT. A model also containing (u dot grad)b is different and is not covered. The initial field is real, mean-zero, divergence free, and within L2 distance 1/(500 sqrt(2)) of the fixed center. Control gain and transverse-direction errors are static and bounded by 1/1024; phase is arbitrary and static. The full exact contract is in PROOF.md.

The same theorem gives a low Fourier-score contrast greater than 27/80. ACQUISITION.md describes a prospective finite-bit, finite-variance volume-average readout. Its 43,200 observations are conditional on explicit unacquired preparation and sensor contracts; they are not completed experiment counts. Grid point samples alone are insufficient for arbitrary L2 fields.

## Reading order

1. PROOF.md: governing nonlinear theorem and all weak-solution quantifiers.
2. FREE_FIBER_CERTIFICATE.md: direct scalar Fourier reduction and exact infinite-tail certificate actually used.
3. reviews/NONLINEAR_REVIEW.md: coordinated independent analytical challenge, with limitations.
4. ACQUISITION.md: observable, error budgets, statistics, and physical costs.
5. reviews/LINEAR_REVIEW.md: source challenge of the inherited exact linear certificate.
6. reviews/ACQUISITION_REVIEW.md: narrow analytical check of the prospective instrument and statistical contract.
7. negative_wrapper/: a preserved failed generic nonlinear route, with all 650 diagonal values and its exact receipt.

The older complete linear packet is under linear_certificate/. It contains exact integer metrics and congruences, original source and execution receipts, and the failed higher-sector floating bounds. The broader historical three-actuator theorem is not being relabeled as a one-actuator full-space contraction. Only one free scalar channel is required for the new result.

## Verification

The new read-only entry point is:

    python3 verify_one_channel.py

It requires only the Python standard library. It reconstructs the six saved rational matrices needed by the new theorem, checks their integer congruence certificates, and recounts scalar reserves. It does not solve an optimization problem, fit parameters, perform a PDE calculation, or modify files. Exact operations and the separately recorded replay status are described in REPLAY_STATUS.md.

To check the delivered file integrity:

    python3 verify_manifest.py

The historical script linear_certificate/qualify_saved_exact.py is a PRODUCING script. It uses NumPy/SciPy to propose congruence coordinates and writes output files. It is included for provenance but is not required to verify this packet. If exploring that historical process, work on a copy; do not confuse regenerated witnesses with the frozen delivered ones.

## Honest resource summary

One actuator block: duration 4.2, nominal scalar peak 128, calibrated vector peak below 129, nominal slew at most 2400, scalar action 524.8, integrated squared command at most 68812.8. All are nondimensional quantities of the model. The actuator peak is about 12,800 times the initial center amplitude. The packet does not convert these values to seconds, power, cost, or feasible hardware tolerances.

Historical producing operations: one floating screen, including failures, and one exact saved-witness pass. Their receipts are preserved. The new analytic nonlinear theorem required no nonlinear propagation. The standalone read-only replay is separately labeled and is not an independent mathematical audit.

## Primary context

Energy-space stability of symmetric viscous flows and Reynolds–Orr energy estimates are established prior. The packet derives the extra prescribed-skew-drift cancellation and amplitude-only bound explicitly rather than importing an unforced theorem outside its scope.

- Bardos et al., “Stability of two-dimensional viscous incompressible flows under three-dimensional perturbations and inviscid symmetry breaking,” arXiv:1201.2742v2: https://arxiv.org/html/1201.2742v2
- Waleffe, GFD 2011 lecture on nonlinear shear-flow stability: https://people.math.wisc.edu/~fwaleffe/GFD2011lectures/GFD3.pdf

The reviews are coordinated analytical checks, not blind discovery, external expert certification, proof-assistant verification, or independent PDE experiments. Source hashes and delivery-copy editorial changes are recorded in SOURCE_MAP.json. All scientific witness bytes are retained unchanged.
