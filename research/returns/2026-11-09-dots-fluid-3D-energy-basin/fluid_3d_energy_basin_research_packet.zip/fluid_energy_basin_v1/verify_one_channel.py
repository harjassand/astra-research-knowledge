#!/usr/bin/env python3
"""Read-only exact verification of the ONE free channel used by PROOF.md.
Python standard library only. No eigensolver, matrix fitting, PDE, or data writes.
The other historical channels are included for provenance, not needed here.
"""
from pathlib import Path
from fractions import Fraction as F
from math import factorial, comb
import hashlib, json, time
ROOT=Path(__file__).resolve().parent
R=ROOT/'linear_certificate'/'exact_saved'
N=32; n=65; scale=1<<40; AD=10000

def transpose(a): return [list(x) for x in zip(*a)]
def mul(a,b):
    bt=transpose(b)
    return [[sum(x*y for x,y in zip(row,col)) for col in bt] for row in a]
def eye(): return [[int(i==j) for j in range(n)] for i in range(n)]
def sym(a): return a==transpose(a)
def gate(H,den,name):
    rec=json.loads((R/(name+'.json')).read_text())
    assert den>0 and sym(H)
    assert int(rec['matrix_positive_denominator'])==den
    B=rec['congruence_numerator']
    assert len(B)==n and all(len(row)==n for row in B)
    assert all(type(x) is int for row in B for x in row)
    C=mul(mul(B,H),transpose(B))
    assert sym(C)
    margin=min(C[i][i]-sum(abs(C[i][j]) for j in range(n) if j!=i) for i in range(n))
    assert margin>0
    assert margin==int(rec['minimum_diagonal_dominance_numerator'])
    return {'gate':name,'positive':True,'saved_margin_reproduced':True}

start=time.monotonic()
rec=json.loads((R/'m1_k1_free_metric.json').read_text())
assert (rec['m'],rec['k'],rec['polarization'],rec['N'],rec['metric_bits'])==(1,1,'free',32,40)
D=rec['metric_numerator']; I=eye()
assert len(D)==n and all(len(row)==n for row in D) and sym(D)
assert all(type(x) is int for row in D for x in row)
V=[[D[i][j]-scale*I[i][j] for j in range(n)] for i in range(n)]
checks=[gate(V,scale,'m1_k1_free_lower'),gate([[8*scale*I[i][j]-D[i][j] for j in range(n)] for i in range(n)],scale,'m1_k1_free_upper')]
q=[1+j*j for j in range(-N,N+1)]
qout=1+(N+1)**2
penalty=F(807**2,8)/(F(197,5000)*qout-1)
outer=[[V[i][0]*V[j][0]+V[i][-1]*V[j][-1] for j in range(n)] for i in range(n)]
for c in [801,807]:
 for dn in [197,198]:
    AI=[[-dn*2*q[i] if i==j else 0 for j in range(n)] for i in range(n)]
    for i in range(n-1):AI[i][i+1]=-c*5000;AI[i+1][i]=c*5000
    atd=mul(transpose(AI),D); da=mul(D,AI)
    RN=[[-atd[i][j]-da[i][j]-2*AD*D[i][j] for j in range(n)] for i in range(n)]
    H=[[RN[i][j]*penalty.denominator*scale-outer[i][j]*penalty.numerator*AD for j in range(n)] for i in range(n)]
    den=AD*penalty.denominator*scale*scale
    checks.append(gate(H,den,f'm1_k1_free_c{c}_d{dn}'))

scalar={
 'exp8_gt2048':sum((F(8)**j/F(factorial(j)) for j in range(33)),F())>2048,
 'controlled_ratio':F(21,64)<F(1,3),
 'free_heat_lower':1-F(1,25)*F(21,5)>F(4,5),
 'relative_dissipation':F(1,100)/(4*F(25,8)*F(1,1000))==F(4,5),
 'cell_score_bias':F(6,1024)+F(2,65536)+(1+F(1,65536))*(F(1,500)+F(200,2**21))+F(1,1000)<F(1,100),
 'cell_score_second_moment':(1+F(1,65536))**2*F(72,25)<F(17,10)**2,
 'instrument_second_moment':F(171,100)**2<3,
 'median_failure':sum((F(comb(9,j)*3**(9-j),4**9) for j in range(5,10)),F())==F(12826,262144)<F(1,20),
 'ideal_ci_margin':F(27,80)-2*F(1,50)-2*F(1,10)==F(39,400),
 'readout_time_lipschitz':F(1,25)*F(6,5)+F(36,25)*F(22,7)*F(1,100)<F(1,10),
}
assert all(scalar.values())
print(json.dumps({'scope':'Read-only exact replay of six saved free-channel congruences and explicit scalar reserves. No new witness, fit, PDE or experiment.','matrix_gates':checks,'scalar_gates':scalar,'all_pass':True,'wall_seconds':time.monotonic()-start},indent=2))
