#!/usr/bin/env python3
"""Verify this archive's file hashes. This does not check any theorem."""
import hashlib
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = root / "MANIFEST.sha256"
failures = []
count = 0
for line in manifest.read_text(encoding="utf-8").splitlines():
    if not line:
        continue
    digest, relative = line.split("  ", 1)
    path = root / relative
    if path.resolve().parent != root and root not in path.resolve().parents:
        failures.append(relative + ": invalid path")
        continue
    if not path.is_file():
        failures.append(relative + ": missing")
        continue
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != digest:
        failures.append(relative + ": hash mismatch")
    count += 1
if failures:
    raise SystemExit("\n".join(failures))
print(f"Verified {count} file hashes. No mathematical or sampling test was run.")
