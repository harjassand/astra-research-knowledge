from pathlib import Path
import subprocess,sys,json,ast
root=Path(__file__).resolve().parent
print('CHECK: complete original-source dependency package',flush=True)
subprocess.run([sys.executable,str(root/'prior_dependency/run_checks.py')],cwd=root/'prior_dependency',check=True)
checks=[
 'ising_physical_contour_20261113/check.py',
 'ising_right_only_bootstrap_20261113/check.py',
 'ising_right_only_bootstrap_20261113/collar_test.py',
 'ising_physical_phase_boundary_20261113/check.py',
 'ising_physical_phase_boundary_20261113/pinned_closure.py',
 'ising_physical_phase_boundary_20261113/integration.py',
 'n1722_actual_wall_collar_20261113/mincut_check.py',
 'n1722_actual_wall_collar_20261113/short_conditional_scalar.py',
 'n1722_actual_wall_collar_20261113/new_sector_baseline.py',
]
for name in checks:
 p=root/'research_notes'/name
 print('\nCHECK:',name,flush=True)
 r=subprocess.run([sys.executable,str(p)],cwd=root,check=True,capture_output=True,text=True)
 print(r.stdout,end='',flush=True)
 try:data=json.loads(r.stdout)
 except json.JSONDecodeError:data=ast.literal_eval(r.stdout)
 p.with_suffix('.json').write_text(json.dumps(data,indent=2)+'\n')
print('\nCHECK: headline and dependency linkage',flush=True)
subprocess.run([sys.executable,str(root/'crosscheck.py')],cwd=root,check=True)
print('\nAll checks passed. Reviewed major partial, not the full exit theorem.',flush=True)
