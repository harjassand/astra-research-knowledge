from fractions import Fraction as Q
from math import isqrt
from pathlib import Path
import json
def exp_lower(x,N=100):
 t=s=Q(1)
 for k in range(1,N+1):t*=x/k;s+=t
 return s
def exp_upper(x,N=60):
 t=s=Q(1)
 for k in range(1,N+1):t*=x/k;s+=t
 nxt=t*x/(N+1)
 return s+nxt/(1-x/(N+2))
assert exp_lower(Q(7,2))>33
assert exp_upper(Q(239,100))<11
assert Q(9,4)**2>5 # b_theta4 >7/2, hence q<1/11.
rows=[]
for R,r in [(80,5),(200,5),(1000,6),(10000,7)]:
 n=64*R*R;u=Q(110*n,11**(2*r));assert u<1
 H=isqrt(80*R*R)+1
 assert (H-1)**2<=80*R*R<H*H
 pref=Q(110*n)/(1-u)
 lp=next(j for j in range(1,100)if exp_lower(Q(j))>pref)
 exponent=Q(239*H,100)-lp
 rows.append(dict(R=R,r=r,u_upper_exact=str(u),physical_basin_normalizer_ratio_upper_exact=str(1/(1-u)),merger_perimeter_threshold=H,log_prefactor_upper=lp,negative_exponent_exact=str(exponent),negative_exponent_floor=exponent.numerator//exponent.denominator,status='Conditional on merger-cluster geometry and injection proof'))
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
