from collections import deque,defaultdict
from pathlib import Path
import random,json
NN=[(1,0),(-1,0),(0,1),(0,-1)];AUG=NN+[(1,1),(-1,-1)];KING=NN+[(1,1),(-1,-1),(1,-1),(-1,1)]
def components(S,steps):
 unseen=set(S);out=[]
 while unseen:
  a=next(iter(unseen));C={a};todo=[a];unseen.remove(a)
  while todo:
   x,y=todo.pop()
   for dx,dy in steps:
    z=x+dx,y+dy
    if z in unseen:unseen.remove(z);C.add(z);todo.append(z)
  out.append(C)
 return out
def fill(C,N,steps):
 box={(x,y)for x in range(-1,N+1)for y in range(-1,N+1)}
 ext={(-1,-1)};todo=[(-1,-1)]
 while todo:
  x,y=todo.pop()
  for dx,dy in steps:
   z=x+dx,y+dy
   if z in box and z not in C and z not in ext:ext.add(z);todo.append(z)
 return box-ext
P=lambda C:sum((x+dx,y+dy)not in C for x,y in C for dx,dy in NN)
def disks(S,N):return[fill(C,N,KING)for C in components(S,NN)]
rng=random.Random(112);tests=[]
for bits in range(512):tests.append((3,{(i//3,i%3)for i in range(9)if bits>>i&1},5))
for _ in range(6000):tests.append((4,{(x,y)for x in range(4)for y in range(4)if rng.random()<.55},9))
ring={(x,y)for x in range(5)for y in range(5)if x in [0,4]or y in [0,4]};tests.append((5,ring|{(2,2)},25))
valid=witnesses=nested=aug_area_bad=0
for N,S,cap in tests:
 ds=disks(S,N)
 if any(len(D)>cap for D in ds):continue
 valid+=1
 outer=[D for D in ds if not any(D<E for E in ds)]
 for K in components(S,AUG):
  if max(x for x,y in K)-min(x for x,y in K)<2 and max(y for x,y in K)-min(y for x,y in K)<2:continue
  selected=[]
  for D in outer:
   if D&K:selected.append(D)
  U=set().union(*selected)
  assert K<=U
  assert len(components(U,KING))==1
  assert sum(len(D)for D in selected)==len(U)
  assert P(U)==sum(P(D)for D in selected)
  new=S^U
  assert all(len(D)<=cap for D in disks(new,N))
  assert (new^U)==S
  assert P(U)>=4
  FK=fill(K,N,AUG);FU=fill(U,N,AUG)
  assert FK<=FU
  assert P(U)**2>=16*len(FU)
  if len(FK)>cap:aug_area_bad+=1
  # Weighted joint flip changes only outer physical edges; magnetization term retained.
  assert P(new)-P(S)==-P(U)
  witnesses+=1
  nested+=int(any(D<E for D in ds for E in ds))
out=dict(tested_states=len(tests),valid_physical_small_states=valid,ancestor_cluster_witnesses=witnesses,nested_witness_cases=nested,original_augmented_area_bad_witnesses=aug_area_bad,all_flip_images_preserve_physical_basin=True,all_synthetic_augmented_hulls_cover_original=True,all_perimeter_isoperim_bounds=True,scope='Planar padded tests, not torus/winding proof; 512 exhaustive3x3,6000 seeded4x4,one explicitnested5x5')
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
