"""Independent finite directed-Euler diagnostic; not a replacement for ancestor-fill proof."""
import random,collections,json
from pathlib import Path
rng=random.Random(913);count=0
for L in [5,6,8]:
 def nn(i):
  y,x=divmod(i,L);return [y*L+(x+1)%L,y*L+(x-1)%L,((y+1)%L)*L+x,((y-1)%L)*L+x]
 for rep in range(1000):
  plus={i for i in range(L*L) if rng.random()<.22};left=set(plus);comps=[]
  while left:
   todo=[left.pop()];C=set(todo)
   while todo:
    for j in nn(todo.pop()):
     if j in left:left.remove(j);C.add(j);todo.append(j)
   comps.append(C)
  # Restrict small components to avoid an unimplemented filled-hole step.
  if any(len(C)>4 for C in comps) or not comps:continue
  # Choose an original SW-NE augmented plus component, union its NN constituents.
  i=min(plus);U={i};todo=[i]
  while todo:
   v=todo.pop();y,x=divmod(v,L)
   for j in nn(v)+[((y+1)%L)*L+(x+1)%L,((y-1)%L)*L+(x-1)%L]:
    if j in plus and j not in U:U.add(j);todo.append(j)
  edges=[];constraints={}
  for i in U:
   y,x=divmod(i,L)
   sides=[((x,y),((x+1)%L,y),((y-1)%L)*L+x),(((x+1)%L,y),((x+1)%L,(y+1)%L),y*L+(x+1)%L),(((x+1)%L,(y+1)%L),(x,(y+1)%L),((y+1)%L)*L+x),((x,(y+1)%L),(x,y),y*L+(x-1)%L)]
   for a,b,j in sides:
    if j not in U:edges.append((a,b));constraints[i]=True;constraints[j]=False
  out=collections.defaultdict(list);degree=collections.Counter()
  for a,b in edges:out[a].append(b);degree[a]+=1;degree[b]-=1
  assert not any(degree.values());stack=[min(out)];trail=[]
  while stack:
   v=stack[-1]
   if out[v]:stack.append(out[v].pop())
   else:trail.append(stack.pop())
  trail=trail[::-1];assert len(trail)==len(edges)+1 and trail[0]==trail[-1]
  assert len(set(edges))==len(edges)
  assert all(trail[k]!=trail[k+2] for k in range(len(trail)-2))
  # Decode all spins from edge parity and one oriented boundary seed.
  boundary=set()
  for i in U:
   for j in nn(i):
    if j not in U:boundary.add(tuple(sorted((i,j))))
  labels={next(iter(constraints)):constraints[next(iter(constraints))]};todo=list(labels)
  while todo:
   v=todo.pop()
   for j in nn(v):
    b=labels[v]^(tuple(sorted((v,j))) in boundary)
    if j in labels:assert labels[j]==b
    else:labels[j]=b;todo.append(j)
  assert {i for i,b in labels.items() if b}==U
  count+=1
p=Path(__file__).with_suffix('.json');p.write_text(json.dumps({'directed_euler_cases':count,'scope':'Small-component diagonal merger diagnostic; no nested/fill theorem implied.'},indent=2)+'\n');print(p.read_text())
