from itertools import product
from pathlib import Path
import json
steps=((1,0),(-1,0),(0,1),(0,-1))
rows=[]
for p in (4,6):
 count=0
 for ds in product(steps,repeat=p):
  v=(0,0);edges=set();ok=True
  for d in ds:
   w=(v[0]+d[0],v[1]+d[1]);e=tuple(sorted((v,w)))
   if e in edges:ok=False;break
   edges.add(e);v=w
  if ok and v==(0,0):count+=1
 assert count=={4:8,6:24}[p]
 rows.append(dict(length=p,rooted_oriented_closed_edge_simple_walks=count,unoriented_loops_per_site=count//(2*p)))
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows)
