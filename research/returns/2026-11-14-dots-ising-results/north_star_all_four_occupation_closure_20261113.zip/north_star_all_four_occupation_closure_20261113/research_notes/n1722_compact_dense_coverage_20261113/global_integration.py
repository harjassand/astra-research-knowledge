from pathlib import Path
from fractions import Fraction as F
import json
root=Path(__file__).resolve().parent
ref=json.loads((root/'refined.json').read_text())
old=json.loads((root.parent/'north_compute_20261113/ising_short_anchor_join/solid_critical.json').read_text())
new=json.loads((root.parent/'north_compute_20261113/ising_paired_anchor/check.json').read_text())['rows']
rows=[]
for r,o,p in zip(ref,old,new):
 R=r['R'];assert R==o['R']==p['R']
 a=F(r['A35_exact']);ex=8*R-a-1
 winding=ex.numerator//ex.denominator
 anchor=max(o['negative_exponent_floor'],p['negative_exponent_floor'])
 branches=dict(anchor=anchor,no_anchor_essential=winding,no_anchor_minus_sea=r['minussea_exp_floor'],no_anchor_plus_background=r['plusbackground_exp_floor'])
 rows.append(dict(R=R,branches=branches,all_topology_outside_F_negative_exponent=min(branches.values())-2))
assert [r['all_topology_outside_F_negative_exponent'] for r in rows]==[513,1519,4421,33294]
assert F(1)+2+F(2)**2/2>4 # e²>4 by positive Taylor partial sum.
out={'scope':'Four-branch global union; original source, no capacity acquisition or uniform growing-R claim. Independent integration reviews passed; finite scope only.', 'rows':rows}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
