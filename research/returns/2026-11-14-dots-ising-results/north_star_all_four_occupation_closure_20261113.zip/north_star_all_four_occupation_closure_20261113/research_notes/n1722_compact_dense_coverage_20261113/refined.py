from pathlib import Path
from fractions import Fraction as F
from math import factorial,ceil,log
import json

def elo(x,N=300):return sum((F(x)**j/factorial(j) for j in range(N)),F(0))
def eup(x,N=300):
 x=F(x);return elo(x,N)+(x**N/factorial(N))/(1-x/F(N+1))
assert elo(4)>54 and elo(F(7,2))>33
assert eup(F(289,100))<18
assert F(1414,1000)**2<2
rows=[]
for R in (80,200,1000,10000):
 n=64*R*R;lg=ceil(log(220*n));assert elo(lg)>220*n
 a4=F(n,54**4)+F(2*n,54**6)+F(100*n,17*18**7)
 a35=F(n,33**4)+F(2*n,33**6)+F(100*n,10*11**7)
 minus=F(289,100)*F(89*R,10)-a4-lg
 plus=8*F(1414,1000)*R-a35-1 # log2<1
 rows.append(dict(R=R,minussea_exp_floor=minus.numerator//minus.denominator,plusbackground_exp_floor=plus.numerator//plus.denominator,A4_exact=str(a4),A35_exact=str(a35)))
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
