from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json
z=F(9,10);cases=0
for eps in (F(1,10),F(1,100)):
 t=eps*eps
 for h in range(7):
  sums={};zs={}
  for xs in product((0,1),repeat=h):
   for ys in product((0,1),repeat=h):
    d1=sum(xs);d2=sum(ys)
    if d1>d2:continue
    flip=lambda seq:sum(a!=b for a,b in zip((0,)+seq,seq+(1,)))
    f1=flip(xs);f2=flip(ys);assert f1%2==f2%2==1
    b1=(f1-1)//2;b2=(f2-1)//2
    n01=sum(a==0 and b==1 for a,b in zip(xs,ys));n10=sum(a==1 and b==0 for a,b in zip(xs,ys))
    delta=d2-d1;assert n01-n10==delta
    direct=t**(b1+b2+n10)
    transfer=eps**(f1+f2)*z**n01*(t/z)**n10
    assert direct==transfer/t/z**delta
    key=d1,d2;sums[key]=sums.get(key,F(0))+direct;zs[key]=zs.get(key,F(0))+transfer
    cases+=1
  for (d1,d2),v in sums.items():assert v<=t**-1*z**-(d2-d1)*(1+20*t)**h
out={'exact_source_pair_identities':cases,'heights':list(range(7)),'epsilons':['1/10','1/100'],'scope':'Independent finite identity/preimage check; analytical witness applies at actual epsilon=e^-8.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
