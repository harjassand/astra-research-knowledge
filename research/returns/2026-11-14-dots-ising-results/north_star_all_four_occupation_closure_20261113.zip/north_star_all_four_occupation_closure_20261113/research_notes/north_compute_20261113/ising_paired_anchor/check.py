from fractions import Fraction as F
from pathlib import Path
from math import factorial,ceil,log
import json

def elo(x,N=500):return sum((F(x)**j/factorial(j)for j in range(N)),F(0))
assert elo(8)>2980
u=F(999,1000);eps=F(1,2980);t=eps*eps;z=F(9,10)
assert 2*eps+u+t/u < 1-F(1,4000)
# Exact transfer witness at the upper epsilon; algebra covers all smaller epsilon.
assert t<=z/20
assert F(1,10)+z*t+t/z<=1+20*t
assert t*t/z<=20*t
# e^(-2 theta_eff) = (10/9)e^-8 <1/2682.
assert F(10,9)*eps==F(1,2682)
rows=[]
for R,cap in[(80,1548),(200,4136),(1000,21502),(10000,217281)]:
 L=8*R;n=L*L;m=2*R+1;h=L-1
 pref=F(1600000*n**3*m)*(1+F(R,8))
 lp=ceil(log(pref));assert elo(lp)>pref
 logQ_no_pref=16*R+F(20*R*h,8880400)+F(h,2980)+F(2*h,9)+F(5*R,12)+F(2*m,2681)
 cost=lp+16+F(L,999)+F(n,6553710000)+logQ_no_pref
 exp=F(cap)-cost
 rows.append(dict(R=R,L=L,m=m,log_prefactor_upper=lp,log_Q_without_pref_exact=str(logQ_no_pref),total_log_multiplier_exact=str(cost),negative_exponent_floor=exp.numerator//exp.denominator,nonvacuous=exp>0))
out=dict(scope='Independently reviewed paired-column partition and axial tilted full-line join; exact rational constants',rows=rows)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
