from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json
E=F(1,10);t=E*E;z=F(9,10);states=list(product([0,1],repeat=2))
K=[[E**sum(a!=b for a,b in zip(s,v))for v in states]for s in states];D=[F(1),z,t/z,F(1)]
rows=[]
for h in range(1,8):
 groups={};total=F(0)
 for word in product(states,repeat=h):
  counts=[sum(s[i]for s in word)for i in[0,1]]
  flips=sum(sum(a!=b for a,b in zip(s,v))for s,v in zip([(0,0)]+list(word),list(word)+[(1,1)]))
  n10=sum(s==(1,0)for s in word);delta=counts[1]-counts[0]
  exact=t**((flips-2)//2+n10)*z**delta
  total+=exact
  if delta>=0:groups[tuple(counts)]=groups.get(tuple(counts),F(0))+exact/z**delta
 vec=[F(1),F(0),F(0),F(0)]
 for _ in range(h):vec=[sum(vec[i]*K[i][j]for i in range(4))*D[j]for j in range(4)]
 Z=sum(vec[i]*K[i][3]for i in range(4))
 assert total==Z/t
 for (d1,d2),v in groups.items():assert v<=t**-1*z**(-(d2-d1))*(1+20*t)**h
 rows.append(dict(h=h,words=4**h,groups=len(groups),exact_transfer_identity=True,all_fixed_count_bounds=True))
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
