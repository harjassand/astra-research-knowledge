from fractions import Fraction as F
from pathlib import Path
from math import factorial,log,ceil
import json

def elo(x,N=400):return sum((F(x)**j/factorial(j)for j in range(N)),F(0))
assert elo(8)>2980 and elo(3)>17
rows=[]
for R,cap in[(80,1548),(200,4136),(1000,21502),(10000,217281)]:
 L=8*R;n=L*L;m=2*R+1;k=0
 assert m==2*R+1
 pref=F(404*n**3*m*(k+1))*(1+F(R,8))
 logpref=ceil(log(pref));assert elo(logpref)>pref
 cost=F(logpref+16+20*k)+F(7*L,5)+F(n,2397570000)+F(m*(L-1),2980)+F(5*R,12)+F(2*m,2979)
 exponent=F(cap)-cost
 rows.append(dict(R=R,m=m,k=k,log_prefactor_upper=logpref,cost_exact=str(cost),negative_exponent_floor=exponent.numerator//exponent.denominator,nonvacuous=exponent>0))
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
