from itertools import product
from math import comb
from pathlib import Path
import json
cc=walk=0
for h in range(1,9):
 counts={}
 for s in product([0,1],repeat=h):
  k=sum(s);blocks=sum(s[i] and (i==0 or not s[i-1]) for i in range(h));b=blocks-int(bool(s[-1]));counts[k,b]=counts.get((k,b),0)+1
 for k in range(h+1):
  for b in range(h+1):
   expected=comb(k,b)*comb(h-k,b) if b<=min(k,h-k) else 0
   assert counts.get((k,b),0)==expected;cc+=1
for length in range(1,7):
 for rest in product(range(4),repeat=length):
  z=(0,)+rest;b=tuple(min(z[i:]) for i in range(len(z)));e=tuple(x-y for x,y in zip(z,b));down=lambda x:sum(max(a-c,0) for a,c in zip(x,x[1:]))
  assert all(a<=c for a,c in zip(b,b[1:])) and e[0]==e[-1]==0
  assert down(e)==down(z) and sum(z)==sum(b)+sum(e);walk+=1
out={'column_count_identities':cc,'future_minimum_walks':walk,'all_exact':True,'scope':'Combinatorial identities only; general inequalities proved analytically.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
