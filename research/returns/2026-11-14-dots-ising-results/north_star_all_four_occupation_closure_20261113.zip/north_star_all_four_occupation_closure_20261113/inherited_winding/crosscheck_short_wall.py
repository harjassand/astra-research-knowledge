from pathlib import Path
from fractions import Fraction as F
import json
root=Path(__file__).resolve().parent;p=root/'research_notes/n1722_actual_wall_collar_20261113'
a=json.loads((p/'short_conditional_scalar.json').read_text())['rows']
b=json.loads((p/'new_sector_baseline.json').read_text())['finite_instances']
c=json.loads((root/'prior_dependency/00_previous_high_mass_dependency/04_optimized_capacity/check.json').read_text())['rows']
expected={80:94,200:567,1000:3858,10000:41368}
for x in a:
 R=x['R'];assert x['negative_exponent_floor']==expected[R] and x['nonvacuous']
 z=next(d for d in b if d['R']==R);assert z['short_wall_p']<=x['p_max']
 assert z['V']<z['L']**2//2 and F(z['log_weight_over_allminus_exact'])>=-32
 assert z['minimum_plus_winding_length_lower']>z['L']+F(R,2)
 assert z['translation_orbit_count']==z['L']**2
 assert F(z['translation_orbit_mass_over_ZA_lower_exact'])>({80:F(22,1000),200:F(14,100)}.get(R,1))
 cap=next(d for d in c if d['R']==R and d['cutoff_area_over_R2']=='64/25');assert cap['r']=={80:5,200:5,1000:6,10000:7}[R]
assert json.loads((p/'mincut_check.json').read_text())['mincut_checks']==150
print('Fresh original capacity/r, four occupation exponents, new-sector translation masses and mincut diagnostics cross-checked.')
