from pathlib import Path
import hashlib
p=Path(__file__).resolve().parent
expected={}
for line in (p/'SHA256SUMS.txt').read_text().splitlines():
 h,name=line.split('  ',1);expected[name]=h
actual={str(f.relative_to(p)) for f in p.rglob('*') if f.is_file() and f.name!='SHA256SUMS.txt'}
# Nested dependency manifests are themselves covered by the top-level manifest.
actual|={str(f.relative_to(p)) for f in p.rglob('SHA256SUMS.txt') if f!=p/'SHA256SUMS.txt'}
assert actual==set(expected),(actual-set(expected),set(expected)-actual)
for name,h in expected.items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==h,name
print(f'All {len(expected)} file hashes match the top-level manifest.')
