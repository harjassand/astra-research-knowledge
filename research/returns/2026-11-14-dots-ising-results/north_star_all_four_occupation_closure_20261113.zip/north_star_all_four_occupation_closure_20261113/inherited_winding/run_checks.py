from pathlib import Path
import subprocess,sys,json
root=Path(__file__).resolve().parent
subprocess.run([sys.executable,str(root/'run_axis_dependency.py')],cwd=root,check=True)
checks=['north_compute_20261113/ising_shadow_envelope/check.py','north_compute_20261113/ising_shadow_envelope/order_check.py','ising_intermediate_diagonal_20261113/closure_probe.py','ising_diagonal_nonbacktracking_tail_20261113/check.py','ising_intermediate_diagonal_20261113/paid_scalar.py','ising_intermediate_diagonal_20261113/union_receipt.py']
for name in checks:
 print('\nCHECK:',name,flush=True)
 r=subprocess.run([sys.executable,str(root/'research_notes'/name)],cwd=root,check=True,capture_output=True,text=True)
 print(r.stdout,end='',flush=True)
subprocess.run([sys.executable,str(root/'crosscheck.py')],cwd=root,check=True)
print('All original-source, axis, diagonal and winding-union checks passed. Zero-essential-wall sector remains open.')
