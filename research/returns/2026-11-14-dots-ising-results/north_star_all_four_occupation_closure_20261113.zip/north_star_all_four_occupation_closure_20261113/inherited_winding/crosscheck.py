from pathlib import Path
import json
from fractions import Fraction as F
root=Path(__file__).resolve().parent/'research_notes'
diag=json.loads((root/'ising_intermediate_diagonal_20261113/union_receipt.json').read_text())['rows']
assert [r['union']for r in diag]==[47,440,3196,34695]
axis=json.loads((root/'n1722_axis_nonbacktracking_tail_20261113/sector_receipt.json').read_text())
print('Diagonal branches freshly linked; original axis receipt retained:',axis)
# Delivered axis+global topology union gives138/4356; add diagonal branch, pay2<e.
rows=[]
for R,a,d in [(1000,138,3196),(10000,4356,34695)]:
 assert next(r['union']for r in diag if r['R']==R)==d
 ar=next(r for r in axis['rows'] if r['R']==R)
 assert ar['sector_negative_exponent']==a
 assert min(list(ar['branches'].values())+[ar['global_tail_extra_branch']])-2==a
 rows.append(dict(R=R,axis_and_other_winding=a,exactly_two_diagonal=d,all_nonzero_essential_union=min(a,d)-1))
assert F(2)<F(1)+F(1)+F(1,2) # exact Taylor lower bound e>2.5>2
out=dict(scope='All nonzero-essential-wall configurations at the two large original instances; no zero-essential-wall or full exit theorem.',rows=rows)
(root/'winding_union_receipt.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
