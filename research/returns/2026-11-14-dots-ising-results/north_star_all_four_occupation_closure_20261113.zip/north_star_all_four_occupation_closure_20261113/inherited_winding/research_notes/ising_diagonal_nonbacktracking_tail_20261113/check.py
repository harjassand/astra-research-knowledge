from fractions import Fraction as F
from pathlib import Path
import math,json
rho=F(13,3);v=F(2);w=[v,v,1/v,1/v];opp=[2,3,0,1]
h=[rho-w[opp[i]]for i in range(4)]
assert min(h)>0
assert rho*rho-2*(v+1/v)*rho+3==F(1,9)
for i in range(4):assert sum(w[j]*h[j]for j in range(4)if j!=opp[i])<=rho*h[i]
assert sum(w[i]*h[i]for i in range(4))/min(h)<=2*rho

def elo(x,N=400):
 t=s=F(1)
 for k in range(1,N+1):t*=x/k;s+=t
 return s
def eup(x,N=400):
 t=s=F(1)
 for k in range(1,N+1):t*=x/k;s+=t
 r=x/F(N+1)
 return s+t*r/(1-r)
assert elo(F(1467,1000))>rho
assert eup(F(693,1000))<v
assert elo(F(8))>2700
assert rho/F(2700)<F(1,600)
q=F(1,900);Acoef=100*q**4/(1-q)
# Exact weighted-walk dynamic check, summing all four first directions.
a=w[:];diagnostics=[]
for m in range(1,41):
 assert sum(a)<=2*rho**m
 diagnostics.append(dict(m=m,ratio_upper=float(sum(a)/(2*rho**m))))
 a=[w[j]*sum(a[i]for i in range(4)if j!=opp[i])for j in range(4)]
rows=[]
for R in [80,200,1000,10000]:
 L=8*R;n=L*L;threshold=9*L//2
 assert F(threshold)==F(9,2)*L
 pref=320000*n*n*(threshold+2)
 logpref=math.ceil(math.log(pref));assert elo(F(logpref))>pref
 exponent=F(341,2000)*L-F(logpref)-Acoef*n
 rows.append(dict(R=R,L=L,total_winding_perimeter_threshold=threshold,log_prefactor_upper=logpref,negative_exponent_exact=str(exponent),negative_exponent_floor=exponent.numerator//exponent.denominator))
out=dict(rational_tilt={'v':str(v),'rho':str(rho),'matrix_slack':str(F(1,9))},weighted_walk_checks=diagnostics,rows=rows,scope='Exactly two actual DIAGONAL winding walls, total physical length at least4.5L; arbitrary contractible walls; original non-target field cap. Direct Gibbs-mass and occupation baseline, not transport.')
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
