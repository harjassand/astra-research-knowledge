from fractions import Fraction as F
import json
def elo(x,N=220):
 t=s=F(1)
 for j in range(1,N+1):t*=x/j;s+=t
 return s
assert elo(F(11,8),40)>F(15,4)
# Exact AM-GM coefficient condition: (5/4)(53/4)>16.
assert F(5*53,16)>16
short=sum((F(3)**p/elo(F(2*p+12)-F(p*p,160)) for p in range(4,81)),F(0))
long=F(4,5)**81/(1-F(4,5))
S=12*80000*(short+long)
assert S<F(2,5)
print(json.dumps({'theta':4,'R_range':[80,10000],'L_max':80000,'coverage_exponent':12,'root_count_prefactor':12,'joint_long_perimeter_cost':'11/8','long_tilted_q_upper':'4/5','short_tilted_activity_display':float(12*80000*short),'long_tilted_activity_display':float(12*80000*long),'total_display':float(S),'certified_total_upper':'2/5','all_comparisons_exact_rational':True},indent=2))
