from fractions import Fraction as F
import json
def elo(x,N=220):
 t=s=F(1)
 for j in range(1,N+1): t*=x/j; s+=t
 return s
alpha=F(4,3)
assert F(8,5)*F(68,5)>16*alpha
assert elo(F(6,5),40)>F(300,91)
assert elo(F(9,5),40)>6
assert elo(F(39,5),80)>2400
assert elo(F(17,3),80)>288
short=sum((F(3)**p/elo(F(2*p+12)-F(p*p,2000)) for p in range(4,81)),F(0))
mid=F(1,2)**81/(1-F(1,2))/elo(F(12),100)
long=F(91,100)**401/(1-F(91,100))
S=12*80000*(short+mid+long)
assert S<F(2,5)
pressure_density=100*(F(1,800)**4/(1-F(1,800))+F(1,96)**401/(1-F(1,96)))
assert pressure_density*80000**2<2
print(json.dumps({'R_range':[1000,10000],'area_cutoff':'4R^2/3','kappa':12,'joint_residual':'6/5','kernel_upper':'2/5','kernel_display':float(S),'pressure_formula':'100*(800^-4/(1-1/800)+96^-401/(1-1/96))','pressure_at_R10000_upper':2,'all_exact':True},indent=2))
