import json
count=0
for L in range(3,17):
 for start in range(L):
  for c in range(1,L+1):
   R=[(start+i)%L for i in range(c)]
   for a in range(L):
    for w in range(1,L+1):
     H={(a+i)%L for i in range(w)}
     if R[0] not in H: continue
     left=[x for x in R if x not in H]
     assert len(R)-len(left)<=w
     assert all((left[i]+1)%L==left[i+1] for i in range(len(left)-1))
     assert not(set(left)&H)
     count+=1
print(json.dumps({'cases':count,'all_pass':True}))
