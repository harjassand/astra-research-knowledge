from pathlib import Path
import json,random
base=Path('research_notes/ising_physical_phase_boundary_20261113/pinned_closure.py').read_text().split('count=0;')[0]
L=8;ns={};exec(base.replace('L=4;vertices=',f'L={L};vertices='),ns)
V=ns['vertices'];phasecycles=ns['phasecycles'];N4={v:[((v[0]+dx)%L,(v[1]+dy)%L)for dx,dy in((1,0),(-1,0),(0,1),(0,-1))]for v in V}
dirs=[(dx,dy)for dx in[-1,0,1]for dy in[-1,0,1]if dx or dy]
def comps(A):
 left=set(A);out=[]
 while left:
  v=min(left);seen={v};lift={v:v};queue=[v];wind=False
  for u in queue:
   for dx,dy in dirs:
    z=((u[0]+dx)%L,(u[1]+dy)%L)
    if z not in A:continue
    zz=(lift[u][0]+dx,lift[u][1]+dy)
    if z in seen:
     if lift[z]!=zz:wind=True
    else:seen.add(z);lift[z]=zz;queue.append(z)
  left-=seen;out.append((seen,wind))
 return out
rng=random.Random(771034);cases=births=stalls=0;first=None
for trial in range(800):
 jumps=[0]*L
 for _ in range(L):jumps[rng.randrange(L)]+=1
 a=[0]
 for j in jumps:a.append(a[-1]+j)
 S={(x%L,y)for y in range(L)for x in range(a[y],a[y+1]+1)}
 for v in rng.sample(V,rng.randrange(1,7)):S.symmetric_difference_update([v])
 if len(S)>=L*L//2:continue
 for es,w,plaq in phasecycles(S):
  p=sum(u[0]==v[0]or u[1]==v[1]for u,v in es)
  if abs(w[0])!=1 or abs(w[1])!=1 or not(2*L<p<2.5*L):continue
  D={v for e in es for v in e if v in S};pins={((x+dx)%L,(y+dy)%L)for x,y in plaq for dx,dy in((0,0),(1,0),(1,1),(0,1))}
  essential=[c for c,wind in comps(set(V)-D)if wind]
  assert len(essential)==1
  M=set(essential[0]);K=set(D);blocked=M&pins
  while len(K)<L*L//2:
   eligible=[v for v in sorted(M-blocked)if sum(z in K for z in N4[v])>=2]
   chosen=next((v for v in eligible if len(comps(M-{v}))==1),None)
   if chosen is None:
    stalls+=1
    if first is None:first=dict(source=sorted(S),D=sorted(D),pins=sorted(pins),K=sorted(K),M=sorted(M),p=p,w=w)
    break
   M.remove(chosen);K.add(chosen);births+=1
  cases+=1
out=dict(L=L,seed=771034,cases=cases,births=births,stalls=stalls,first=first,scope='Actual adaptive walls; initial bounded pockets frozen; reference startsD; every accepted birth preserves8-connectivity of essential minus component')
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
