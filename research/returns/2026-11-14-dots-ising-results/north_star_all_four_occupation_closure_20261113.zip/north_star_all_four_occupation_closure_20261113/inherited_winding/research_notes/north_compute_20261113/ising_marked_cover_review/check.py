from itertools import combinations
from pathlib import Path
import json
L=5
arcs=[]
for length in range(1,L):
 for start in range(L):arcs.append(tuple((start+i)%L for i in range(length)))
arcs.append(tuple(range(L)))
checks=0;steps=0
for target in arcs:
 for size in range(1,4):
  for family in combinations(arcs,size):
   sets=[set(a) for a in family]
   if not set(target)<=set().union(*sets):continue
   I=list(target);used=set();removed=0
   while I:
    j=next(j for j,S in enumerate(sets) if I[0] in S)
    assert j not in used;used.add(j)
    old=I[:];I=[x for x in I if x not in sets[j]]
    p=len(old)-len(I);assert 1<=p<=len(family[j]);removed+=p
    if I:
     lo=old.index(I[0]);hi=old.index(I[-1]);assert I==old[lo:hi+1]
    steps+=1
   assert removed==len(target);checks+=1
# Explicit failed naive scan, with every contour charged once under repaired peeling.
L2=10;target=list(range(8));A={6,7,8,9,0,1};B={2,3,4,5}
naive=['A','B','A'];remaining=[x for x in target if x not in A]
assert remaining==[2,3,4,5] and all(x in B for x in remaining)
out=dict(L=L,covered_families_tested=checks,peeling_steps=steps,all_peeling_invariants_pass=True,naive_counterexample={'L':L2,'target':target,'A':sorted(A),'B':sorted(B),'naive_labels':naive,'repaired_labels':['A','B']})
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
