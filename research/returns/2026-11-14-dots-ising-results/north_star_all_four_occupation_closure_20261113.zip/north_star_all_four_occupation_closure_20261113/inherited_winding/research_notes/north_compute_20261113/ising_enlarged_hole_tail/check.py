from fractions import Fraction as F
from math import factorial,isqrt
import json
from pathlib import Path

def log_unit(x,N=80):
 t=(x-1)/(x+1)
 s=2*sum((t**(2*j+1)/F(2*j+1) for j in range(N)),F(0))
 rem=2*t**(2*N+1)/(F(2*N+1)*(1-t*t))
 return s,s+rem

def logs(x):
 x=F(x); k=0
 while x>=2:x/=2;k+=1
 while x<1:x*=2;k-=1
 lo,hi=log_unit(x); l2,h2=log_unit(F(2))
 return (lo+k*l2,hi+k*h2) if k>=0 else (lo+k*h2,hi+k*l2)

assert sum((F(8)**j/factorial(j) for j in range(40)),F(0))>2980
q=F(3,2980)
results=[]
for R in [80,200,1000,10000]:
 L=8*R;n=L*L;P=4*L-16
 H=isqrt((64*R*R)//3)+1
 assert 3*(H-1)**2<=64*R*R<3*H*H
 pressure=100*n*q**4/(1-q)
 upper=logs(320000)[1]+logs(100)[1]+3*logs(n)[1]+logs(P+2)[1]+32*L+pressure-2*L*logs(F(3,2))[0]+P*(logs(F(13,4))[1]-8)+H*(logs(3)[1]-8)+q/(1-q)
 ceil= -((-upper.numerator)//upper.denominator)
 results.append(dict(R=R,L=L,n=n,H=H,log_upper_float=float(upper),certified_log_upper_integer=ceil,nontrivial=upper<0,pressure_upper=float(pressure)))
out={'scope':'Conditional on inherited global-field/nonbacktracking two-axis-wall bound; includes all displayed prefactors. Not marked-cover verification.','q_upper':'3/2980','log_method':'80-term rational atanh series with rational geometric remainder; exp8>2980 exact Taylor partial sum','results':results}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
