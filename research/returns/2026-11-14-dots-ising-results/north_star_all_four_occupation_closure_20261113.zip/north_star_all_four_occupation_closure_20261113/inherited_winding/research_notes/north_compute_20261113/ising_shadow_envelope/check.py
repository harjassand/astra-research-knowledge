from pathlib import Path
import random,json
rng=random.Random(928174)
cases=0;max_slack=None
for L in range(2,13):
 for _ in range(500):
  W=rng.randrange(L);S=rng.randrange(L)
  steps=[(1,0)]*(L+W)+[(-1,0)]*W+[(0,1)]*(L+S)+[(0,-1)]*S
  rng.shuffle(steps);walk=[(0,0)];bad=set()
  for dx,dy in steps:
   x,y=walk[-1]
   if dx==-1:bad.add((x-1)%L)
   walk.append((x+dx,y+dy))
  assert walk[-1]==(L,L)
  verts={(x+k*L,y+k*L)for x,y in walk for k in range(-5,6)}
  def U(j):return max(y for x,y in verts if x<=j)
  def V(j):return min(y for x,y in verts if x>=j+1)
  gaps=[U(j)-V(j)for j in range(L)]
  assert all(0<=g<= (L+S if j in bad else S)for j,g in enumerate(gaps))
  assert sum(gaps)<=L*(W+S)
  pins={(x+dx,y+dy)for x,y in verts for dx in[-1,0,1]for dy in[-1,0,1]}
  hull=sum(max(0,max(y for x,y in pins if x<=j)-min(y for x,y in pins if x>=j)+1)for j in range(L))
  assert hull<=L*(W+S)+6*L
  cases+=1
out=dict(cases=cases,all_pass=True,seed=928174,scope='General periodic walk envelope, including nonsimple/backtracking words; not Ising single-strip pin embedding')
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
