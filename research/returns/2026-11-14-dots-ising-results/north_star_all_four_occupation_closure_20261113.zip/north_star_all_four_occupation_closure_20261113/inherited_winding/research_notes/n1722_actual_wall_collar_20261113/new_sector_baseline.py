from pathlib import Path
from fractions import Fraction as F
import json
src=Path('research_notes/ising_physical_phase_boundary_20261113/check.py').read_text();exec(src[:src.index('count=0;maxratio=0')])
def pars(L):
 a=L//3;b=L//6;c=5*L//6
 if L%6==0:c-=1
 return a,b,c
small=[]
for L in [24,32,40,48,64,80]:
 vertices=[(x,y)for x in range(L)for y in range(L)]
 a,b,c=pars(L)
 def ab(y):return (a if y>=L//2 else 0,b if L//8<=y<3*L//8 else c)
 S={(x,y)for x,y in vertices if ab(y)[0]<=x<ab(y)[1]}
 E=[((x,y),((x+dx)%L,(y+dy)%L))for x,y in vertices for dx,dy in[(1,0),(0,1)]]
 volume=len(S);per=sum((u in S)!=(v in S)for u,v in E)
 expectedP=2*L+2*a+2*(c-b);expectedV=L*b//4+3*L*c//4-L*a//2
 assert(per,volume)==(expectedP,expectedV)
 assert volume<L*L/2
 assert all(not all((x,y)in S for x in range(L))for y in range(L))
 assert all(not all((x,y)in S for y in range(L))for x in range(L))
 walls=[]
 for es,w in phasecycles(S):
  p=sum(u[0]==v[0]or u[1]==v[1]for u,v in es)
  walls.append(dict(homology=w,p=p))
 assert len(walls)==2 and sorted(z['p']for z in walls)==sorted([L+2*a,L+2*(c-b)])
 assert L+2*a<=2*L-8
 small.append(dict(L=L,P=per,V=volume,walls=walls,minimum_plus_winding_length_lower=L+2*(a-b+1)))
def eupper(x,N=200):
 t=s=F(1)
 for k in range(1,N+1):t*=x/k;s+=t
 ratio=x/F(N+1)
 return s+t*ratio/(1-ratio)
assert eupper(F(16))<9000000
assert eupper(F(1))<3
root=Path(__file__).resolve().parents[2]
prior_pressure=json.loads((root/'prior_dependency/00_previous_high_mass_dependency/05_four_corner_family/check.json').read_text())
rows=[]
for R in [80,200,1000,10000]:
 L=8*R;n=L*L;a,b,c=pars(L);V=L*b//4+3*L*c//4-L*a//2;P=2*L+2*a+2*(c-b)
 logw=2*F(4,R)*V-8*P
 S0=6*n*F(1,450)**4/(1-F(1,450))
 assert F(next(d for d in prior_pressure if d['R']==R)['core_pressure_upper'])<=S0
 assert S0<1 and logw>=-32 and V<n//2 and L+2*a<=2*L-8
 assert 2*(a-b+1)>F(R,2)
 orbit_lower=F(n,18000000)*(1-S0) if logw==-16 else F(n,6)
 rows.append(dict(translation_orbit_count=n,translation_orbit_mass_over_ZA_lower_exact=str(orbit_lower),R=R,L=L,V=V,P=P,log_weight_over_allminus_exact=str(logw),short_wall_p=L+2*a,other_wall_p=L+2*(c-b),minimum_plus_winding_length_lower=L+2*(a-b+1),core_pressure_S0=str(S0),mass_over_ZA_lower='exp(-34)'))
out=dict(small_actual_adaptive_wall_checks=small,finite_instances=rows,claim='Explicit non-target configurations in new short-wall family, without full lines/diagonal winding or prior short low-roughness plus seeds. Weight lower, not occupation lower.')
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
