from fractions import Fraction as F
from pathlib import Path
import json,math

def elo(x):
 t=s=F(1)
 for k in range(1,400):t*=x/k;s+=t
 return s
assert elo(F(8))>2700
assert elo(F(1099,1000))>3
q=F(1,900);pressure=100*q**4/(1-q)
assert 100/(1-q)<101
# b<1 for every L>=640, since 101 L^2 2^-L decreases.
assert 101*640**2 < 2**640
assert F(641,640)**2 < 2
root=Path(__file__).resolve().parents[2]
capacity=json.loads((root/'prior_dependency/00_previous_high_mass_dependency/04_optimized_capacity/check.json').read_text())['rows']
expected={80:1548,200:4136,1000:21502,10000:217281}
rows=[]
for R in [80,200,1000,10000]:
 row=next(d for d in capacity if d['R']==R and d['cutoff_area_over_R2']=='64/25')
 exact=-F(row['log_capacity_over_ZA_upper']);cap=exact.numerator//exact.denominator
 assert cap==expected[R]
 L=8*R;n=L*L;p=2*L-8
 k=math.ceil(math.log(101*n));assert elo(F(k))>101*n
 # >=3-loop remainder <= exp[3k+17-1.1L]<1.
 assert 3*k+17 < F(11,10)*L
 pref=808*n*n*L
 ell=math.ceil(math.log(pref));assert elo(F(ell))>pref
 mult=ell+16+F(1099,1000)*p+pressure*n
 neg=cap-mult
 rows.append(dict(R=R,p_max=p,conditional_multiplier_log_upper=str(mult),conditional_negative_exponent=str(neg),negative_exponent_floor=neg.numerator//neg.denominator,nonvacuous=neg>0))
out=dict(scope='Reviewed p<=2L-8 actual-wall finite-volume theorem; depends on explicitly documented path, connected essential pin reduction, mincut gap and label counting. Not a full exit theorem.',rows=rows)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
