# Integration diagnostic: actual adaptive wall -> deterministic reference schedule -> retained label.
from pathlib import Path
from random import Random
from collections import deque
import json
src=Path('research_notes/ising_physical_phase_boundary_20261113/check.py').read_text().split('count=0;maxratio=0')[0].replace('L=4;','L=12;')
exec(src)
# Need local triangulation/pin plaquettes for each wall; crossed edge endpoints determine visited plaquettes conservatively.
def pinplaquettes(es):
 # Any plaquette containing a crossed physical edge could be visited; use exact triangles by rebuilding original rule below.
 return None
def cycles_pins(S):
 inc={};cent={}
 for x,y in vertices:
  a=(x,y);b=((x+1)%L,y);c=((x+1)%L,(y+1)%L);d=(x,(y+1)%L)
  alt=a in S and c in S and not all(v in S for v in(a,b,c,d))
  ts=[(a,b,d),(b,c,d)] if alt else[(a,b,c),(a,d,c)];off=[(1,1),(2,2)]if alt else[(2,1),(1,2)]
  for t,vs in enumerate(ts):
   tid=x,y,t;cent[tid]=(3*x+off[t][0],3*y+off[t][1])
   for u,v in zip(vs,vs[1:]+vs[:1]):inc.setdefault(key(u,v),[]).append(tid)
 adj={}
 for e,(a,b) in inc.items():
  if(e[0]in S)!=(e[1]in S):adj.setdefault(a,[]).append((b,e));adj.setdefault(b,[]).append((a,e))
 todo=set(adj);out=[]
 while todo:
  v=st=next(iter(todo));prev=None;es=[];ps=set();dx=dy=0
  while True:
   todo.discard(v);ps.add(v[:2]);w,e=next((w,e)for w,e in adj[v]if w!=prev);es.append(e)
   wrap=lambda z:(z+3*L//2)%(3*L)-3*L//2
   dx+=wrap(cent[w][0]-cent[v][0]);dy+=wrap(cent[w][1]-cent[v][1]);prev,v=v,w
   if v==st:break
  pins={((x+a)%L,(y+b)%L)for x,y in ps for a,b in[(0,0),(1,0),(0,1),(1,1)]}
  out.append((es,(dx//(3*L),dy//(3*L)),pins))
 return out
Xmin=-L;Xmax=2*L
U={(x,y)for x in range(Xmin,Xmax+1)for y in range(L)}
def ns(v,diag=False):
 x,y=v
 return {(x+a,(y+b)%L)for a in[-1,0,1]for b in[-1,0,1]if(a or b)and(diag or abs(a)+abs(b)==1)and Xmin<=x+a<=Xmax}
def component(start,allowed):
 todo=[start];seen={start}
 for v in todo:
  for z in ns(v,True)&allowed-seen:seen.add(z);todo.append(z)
 return seen
mincut_checks=0;max_gap=0
vid={v:i for i,v in enumerate(vertices)}
def flow_cut(Dp,F):
 n=len(vertices);source=n;sink=n+1;adj=[{}for _ in range(n+2)]
 def add(u,v,c):adj[u][v]=adj[u].get(v,0)+c;adj[v].setdefault(u,0)
 for u,v in E:add(vid[u],vid[v],1);add(vid[v],vid[u],1)
 for v in vertices:
  if v in Dp:add(source,vid[v],1000)
  elif v not in F:add(vid[v],sink,1000)
 total=0
 while True:
  parent={source:None};q=[source]
  for u in q:
   for v,c in adj[u].items():
    if c and v not in parent:parent[v]=u;q.append(v)
   if sink in parent:break
  if sink not in parent:return total
  v=sink;c=1000
  while v!=source:u=parent[v];c=min(c,adj[u][v]);v=u
  v=sink
  while v!=source:u=parent[v];adj[u][v]-=c;adj[v][u]+=c;v=u
  total+=c
def cutcheck(Dp,F,allowed):
 global mincut_checks,max_gap
 z=Dp|F;val=flow_cut(Dp,F)
 pref=sum((u in z)!=(v in z)for u,v in E);gap=pref-val
 assert gap<=allowed,(gap,allowed)
 mincut_checks+=1;max_gap=max(max_gap,gap)
rng=Random(987);cases=adds=actualadds=0
for sample in range(12):
 lo=rng.randrange(L);length=rng.randrange(1,L);amp=rng.choice([1,2])
 profile=[3+(amp if (y-lo)%L<length else 0)for y in range(L)]
 S={(x,y)for y in range(L)for x in range(profile[y],profile[y]+4)}
 for v in vertices:
  if rng.random()<.015:
   if v in S:S.remove(v)
   else:S.add(v)
 for es,w,pins in cycles_pins(S):
  if w[0]!=0 or abs(w[1])!=1:continue
  p=sum(u[0]==v[0]or u[1]==v[1]for u,v in es)
  if p>2*L-8:continue
  D={v for e in es for v in e if v in S};C={v for e in es for v in e if v not in S}
  if not(1<min(x for x,y in D)<=max(x for x,y in D)<L-2):continue
  if sum(x for x,y in C)/len(C)>=sum(x for x,y in D)/len(D):continue
  assert connwind(D)
  K=set(D);R=component((Xmax,0),U-K);xm=max(x for x,y in D)
  schedule=[]
  while not all((xm,y)in K for y in range(L)):
   candidates=sorted(v for v in R if v[0]<=xm and len(ns(v)&K)>=2)
   chosen=None
   for v in candidates:
    rem=R-{v}
    if len(component((Xmax,0),rem))==len(rem):chosen=v;break
   assert chosen is not None
   assert chosen not in pins
   K.add(chosen);R.remove(chosen);schedule.append(chosen)
  bootstrap_length=len(schedule)
  for x in range(xm+1,xm+L//2):
   for y in range(L):
    v=x,y
    assert (x%L,y)not in pins
    schedule.append(v);K.add(v)
  initial_R=component((Xmax,0),U-D)
  initial_left=component((Xmin,0),U-D)
  holes=U-D-initial_R-initial_left
  Dp=set(D)|{(x%L,y)for x,y in holes}
  F=set()
  for j,(x,y)in enumerate(schedule):
   F.add((x%L,y))
   if j%4==0 or j+1==bootstrap_length:cutcheck(Dp,F,0 if j<bootstrap_length else 2)
  cur=set(S);target=frozenset(e for e in es if e[0][0]==e[1][0]or e[0][1]==e[1][1])
  for x,y in schedule:
   if len(cur)>=L*L//2:break
   v=x%L,y
   if v not in cur:cur.add(v);actualadds+=1
   assert all((u in cur)==(u in S)for u in pins)
   found=[frozenset(e for e in ee if e[0][0]==e[1][0]or e[0][1]==e[1][1])for ee,ww,pp in cycles_pins(cur)]
   assert target in found
   adds+=1
  assert len(cur)>=L*L//2
  cases+=1
out={'mincut_checks':mincut_checks,'max_gap':max_gap,'actual_wall_cases':cases,'all_prefix_gap_bounds_pass':True}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
