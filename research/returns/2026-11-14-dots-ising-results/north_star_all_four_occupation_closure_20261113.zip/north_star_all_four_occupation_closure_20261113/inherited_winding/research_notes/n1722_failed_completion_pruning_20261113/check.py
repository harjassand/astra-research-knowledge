from fractions import Fraction as F
from pathlib import Path
import json
# Exact positive Taylor lower verifies e6>390 and hence3e^-6<1/130.
t=s=F(1)
for k in range(1,60):t*=F(6,k);s+=t
assert s>390
# e^(11/10)>3 gives log3<11/10.
t=s=F(1)
for k in range(1,40):t*=F(11,10*k);s+=t
assert s>3
def logceil(x):
 for j in range(1,200):
  t=s=F(1)
  for k in range(1,400):t*=F(j,k);s+=t
  if s>x:return j
 raise RuntimeError
out=[]
for R in [80,200,1000,10000]:
 L=8*R;n=L*L;Q=49*L//10
 pref=2*(100*n)**2*(Q+1)**2
 lp=logceil(pref)
 pressure=F(100*n,130**3*129)
 exponent=F(501*L,100)-512-lp-pressure
 assert exponent>0
 out.append(dict(R=R,L=L,padding=4,wind_perimeter_cutoff=Q,contractible_filled_area_limit=R*R,log_prefactor_upper=lp,contractible_pressure_upper_exact=str(pressure),negative_exponent_exact=str(exponent),negative_exponent_floor=exponent.numerator//exponent.denominator,scope='Two axial walls; erased phase has no full column; both conservative clean completions fail; all contractible filled areas<=R²'))
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
