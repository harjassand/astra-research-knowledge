from fractions import Fraction as F
from pathlib import Path
import json
base=json.loads(Path(__file__).with_name('check.json').read_text());out=[]
for x in base:
 R=x['R'];L=x['L'];Q=x['wind_perimeter_cutoff']
 assert F(5*L,2)-F(Q,2)-8>0
 exponent=F(8*L,5)-F(552,5)-x['log_prefactor_upper']-F(x['contractible_pressure_upper_exact'])
 assert exponent>0
 out.append(dict(R=R,negative_exponent_exact=str(exponent),negative_exponent_floor=exponent.numerator//exponent.denominator,scope='Marked-hole12 cover independently checked; two long axial walls; no actual full column; both conservative completion guarantees fail; all contractibleA<=R²',contractible_pressure_upper_exact=x['contractible_pressure_upper_exact'],log_prefactor_upper=x['log_prefactor_upper']))
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
