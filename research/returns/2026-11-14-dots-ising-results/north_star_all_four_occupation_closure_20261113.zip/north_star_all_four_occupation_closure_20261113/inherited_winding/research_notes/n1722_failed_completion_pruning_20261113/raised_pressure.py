from fractions import Fraction as Q
from pathlib import Path
import json
def lower_exp(x,N=200):
 t=s=Q(1)
 for j in range(1,N):t*=x/j;s+=t
 return s
assert lower_exp(Q(39,5))>2400
assert lower_exp(Q(28,5))>270
assert Q(544,25)>16*Q(4,3)
rows=[]
for R in [1000,10000]:
 n=64*R*R
 pressure=Q(100*n,800**3*799)+100*n*Q(1,90)**401/(1-Q(1,90))
 assert pressure<2
 rows.append(dict(R=R,pressure_upper_exact=str(pressure),certified_pressure_upper=2,area_cutoff_coefficient='4/3',short_perimeter_max=400,long_tilt_cost='6/5'))
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2));print(json.dumps([{k:v for k,v in x.items() if k!='pressure_upper_exact'}for x in rows],indent=2))
