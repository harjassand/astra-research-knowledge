import collections,json,math
L=9;Pmax=9
# Fixed SW-NE diagonal: dual trivalent vertices (cellx,celly,triangle).
def neigh(v):
 x,y,t=v
 if t==0:return [((x,(y-1)%L,1),1),(((x+1)%L,y,1),1),((x,y,1),0)]
 return [((x,(y+1)%L,0),1),(((x-1)%L,y,0),1),((x,y,0),0)]
start=(0,0,0);first=neigh(start)[0][0]
counts=collections.Counter();sigs={};collision=0
# Every nonbacktracking physical-to-physical transition has exactly3 choices.
for x in range(L):
 for y in range(L):
  for t in range(2):
   v=(x,y,t)
   for prev,c in neigh(v):
    if not c:continue
    possible=[]
    for w,d in neigh(v):
     if w==prev:continue
     if d:possible.append((w,))
     else:
      for z,e in neigh(w):
       if z!=v:possible.append((w,z))
    assert len(possible)==3
    assert len({z[-1] for z in possible})==3

def dfs(v,seen,physical,path,p):
 global collision
 for w,c in neigh(v):
  q=p+c
  if q>Pmax:continue
  if w==start:
   if len(path)<3:continue
   sig=physical+(((v,w),) if c else ())
   old=sigs.get(sig)
   full=path+(w,)
   if old is not None and old!=full:collision+=1
   sigs[sig]=full;counts[q]+=1
  elif w not in seen:
   dfs(w,seen|{w},physical+(((v,w),) if c else ()),path+(w,),q)
dfs(first,{start,first},((start,first),),(start,first),1)
assert collision==0
assert all(c<=3**(p-1) for p,c in counts.items())
res={'L':L,'max_physical_perimeter':Pmax,'fixed_first_directed_edge_loopcounts':dict(sorted(counts.items())),'signature_collisions':collision,'local_choices_verified':3,'theta4_old_mass_area_threshold':(4-2*math.log(4)/4)**2,'theta4_new_mass_area_threshold':(4-2*math.log(3)/4)**2}
json.dump(res,open('research_notes/ising_physical_contour_20261113/check.json','w'),indent=2);print(res)
