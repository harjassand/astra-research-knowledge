from fractions import Fraction as F
from pathlib import Path
import json

def elo(x):
 t=s=F(1)
 for j in range(1,200):t*=x/j;s+=t
 return s
assert elo(F(8))>2700
assert elo(F(5,4))>F(10,3)
assert F(81,80)**2*F(9,10)**8<1
assert F(64*10000**2,6553710000)<1
rows=[]
for R in [80,200,1000,10000]:
 L=8*R;n=L*L
 bulk=F(n,6553710000)
 tilted=1000*n*F(9,10)**L
 assert bulk<1 and tilted<1
 rows.append(dict(R=R,L=L,bulk_pressure_upper=str(bulk),tilted_winding_pressure_less_than_one=True,occupation_and_mass_exp_negative=14*R-3))
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
