from pathlib import Path
import random,json
rng=random.Random(64113)
base=Path('research_notes/ising_physical_phase_boundary_20261113/pinned_closure.py').read_text().split('count=0;')[0]
results=[]
for size in (8,12,16,24):
 ns={};exec(base.replace('L=4;vertices=',f'L={size};vertices='),ns)
 L=size;vertices=ns['vertices'];phasecycles=ns['phasecycles']
 cases=jams=0;first=None;byexcess={}
 for trial in range(300):
  inc=[0]*L
  for _ in range(L):inc[rng.randrange(L)]+=1
  starts=[0]
  for d in inc[:-1]:starts.append(starts[-1]+d)
  width=rng.randrange(2,max(3,L//3))
  S={((starts[y]+j)%L,y) for y in range(L) for j in range(inc[y]+width)}
  for _ in range(rng.randrange(1,max(2,L//3))):
   v=rng.choice(vertices)
   if v in S:S.remove(v)
   else:S.add(v)
  if len(S)>=L*L//2:continue
  for es,w,plaquettes in phasecycles(S):
   p=sum(u[0]==v[0] or u[1]==v[1] for u,v in es)
   if abs(w[0])!=1 or abs(w[1])!=1 or not(2*L<p<5*L/2):continue
   D={v for e in es for v in e if v in S}
   pins={((x+dx)%L,(y+dy)%L) for x,y in plaquettes for dx,dy in((0,0),(1,0),(1,1),(0,1))}
   K=set(D);blocked=pins-D
   while len(K)<L*L//2:
    good=[(x,y) for x,y in set(vertices)-K-blocked if sum(((x+dx)%L,(y+dy)%L) in K for dx,dy in((1,0),(-1,0),(0,1),(0,-1)))>=2]
    if not good:break
    K.add(min(good))
   cases+=1;byexcess[p-2*L]=byexcess.get(p-2*L,0)+1
   if len(K)<L*L//2:
    jams+=1
    if first is None:first=dict(source=sorted(S),D=sorted(D),blocked=sorted(blocked),closure=sorted(K),p=p,w=w)
 results.append(dict(L=L,cases=cases,jams=jams,byexcess=byexcess,first=first))
Path(__file__).with_suffix('.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps([{k:v for k,v in x.items() if k!='first'} for x in results],indent=2))
