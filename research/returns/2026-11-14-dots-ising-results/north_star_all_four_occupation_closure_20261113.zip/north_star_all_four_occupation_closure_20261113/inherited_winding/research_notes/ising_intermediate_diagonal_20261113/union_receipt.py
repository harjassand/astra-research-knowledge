from pathlib import Path
import json
root=Path(__file__).resolve().parent
paid=json.loads((root/'paid_scalar.json').read_text())['rows']
tail=json.loads((root.parent/'n1722_winding_wall_tail_20261113/check.json').read_text())
assert [r['R'] for r in paid]==[r['R'] for r in tail]
rows=[]
for a,b in zip(paid,tail):
 rows.append(dict(R=a['R'],transport=a['conditional_exponent_floor'],tail=b['occupation_and_mass_exp_negative'],union=min(a['conditional_exponent_floor'],b['occupation_and_mass_exp_negative'])-1))
assert [r['union'] for r in rows]==[47,440,3196,34695]
out=dict(scope='Exactly two actual diagonal walls; total perimeter>=5L uses adaptive global tail, otherwise at least one p<2.5L uses native retained-wall construction. Original source/clock; arbitrary contractible defects. Requires independently reviewed CONSTRUCTION and PAID_PARTITION.',rows=rows)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
