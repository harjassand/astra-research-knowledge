from fractions import Fraction as F
from pathlib import Path
import json,math

def elo(x,N=500):
 t=s=F(1)
 for k in range(1,N+1):t*=x/k;s+=t
 return s
assert elo(F(1467,1000))>F(13,3)
# exp(.693)<2 from Taylor upper remainder.
x=F(693,1000);N=100;t=s=F(1)
for k in range(1,N+1):t*=x/k;s+=t
assert s+t*x/(N+1)/(1-x/(N+2))<2
capacity=json.loads((Path(__file__).resolve().parents[2]/'prior_dependency/00_previous_high_mass_dependency/04_optimized_capacity/check.json').read_text())['rows']
caprows={r['R']:r for r in capacity if r['cutoff_area_over_R2']=='64/25'}
rows=[]
for R,cap in [(80,1548),(200,4136),(1000,21502),(10000,217281)]:
 assert F(caprows[R]['log_capacity_over_ZA_upper'])<=-cap
 assert caprows[R]['r']=={80:5,200:5,1000:6,10000:7}[R]
 L=8*R;n=L*L
 def ceil_log(v):
  k=math.ceil(math.log(v));assert elo(F(k))>v;return k
 A=F(n,6553710000)
 # Bound with p<=5L/2 and gap0. Three or more other diagonal loops:
 three=3*ceil_log(201*n)+F(20)*L-6*(F(8)-F(1467,1000))*L-6*F(693,1000)*L
 assert three<0
 pref=804*n*n*L
 cost=ceil_log(pref)+A+(F(5,2)*F(1467,1000)-2*F(693,1000))*L
 exponent=cap-cost
 rows.append(dict(R=R,three_loop_log_upper=str(three),conditional_exponent_floor=exponent.numerator//exponent.denominator))
out=dict(scope='Paid scalar for independently reviewed construction: actual diagonal p<2.5L, native majority closure with single pin band, frozen initial pockets, essential-minus hole-first order, m<=p and pinned mincut gap0. Geometry proofs and reviews are separate dependencies; this script certifies constants only.',rows=rows)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
