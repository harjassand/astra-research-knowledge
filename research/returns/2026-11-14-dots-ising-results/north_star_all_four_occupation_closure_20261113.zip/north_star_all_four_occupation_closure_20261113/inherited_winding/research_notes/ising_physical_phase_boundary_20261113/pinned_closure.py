from itertools import product
import json
L=4;vertices=[(x,y) for x in range(L) for y in range(L)]
key=lambda a,b:tuple(sorted((a,b)))
def phasecycles(S):
 inc={};cent={}
 for x,y in vertices:
  a=(x,y);b=((x+1)%L,y);c=((x+1)%L,(y+1)%L);d=(x,(y+1)%L)
  alt=a in S and c in S and not all(v in S for v in(a,b,c,d))
  ts=[(a,b,d),(b,c,d)] if alt else[(a,b,c),(a,d,c)]
  offsets=[(1,1),(2,2)] if alt else[(2,1),(1,2)]
  for t,vs in enumerate(ts):
   z=(x,y,t);cent[z]=(3*x+offsets[t][0],3*y+offsets[t][1])
   for u,v in zip(vs,vs[1:]+vs[:1]):inc.setdefault(key(u,v),[]).append(z)
 adj={}
 for e,(a,b) in inc.items():
  if(e[0]in S)!=(e[1]in S):adj.setdefault(a,[]).append((b,e));adj.setdefault(b,[]).append((a,e))
 todo=set(adj);out=[]
 while todo:
  v=st=next(iter(todo));prev=None;es=[];dx=dy=0
  while True:
   todo.discard(v);n,e=next((n,e)for n,e in adj[v]if n!=prev);es.append(e)
   wrap=lambda z:(z+3*L//2)%(3*L)-3*L//2
   dx+=wrap(cent[n][0]-cent[v][0]);dy+=wrap(cent[n][1]-cent[v][1]);prev,v=v,n
   if v==st:break
  assert dx%(3*L)==dy%(3*L)==0
  out.append((es,(dx//(3*L),dy//(3*L)),{(tri[0],tri[1]) for e in es for tri in inc[e]}))
 return out
E=[((x,y),((x+dx)%L,(y+dy)%L)) for x,y in vertices for dx,dy in[(1,0),(0,1)]]
def connwind(D):
 start=next(iter(D));pot={start:(0,0)};todo=[start];wind=False
 for x,y in todo:
  for dx,dy in[(1,0),(-1,0),(0,1),(0,-1)]:
   v=((x+dx)%L,(y+dy)%L)
   if v not in D:continue
   p=pot[x,y];new=p[0]+dx,p[1]+dy
   if v in pot:
    if pot[v]!=new:wind=True
   else:pot[v]=new;todo.append(v)
 return len(pot)==len(D) and wind
count=0;maxratio=0;jams=0;first=None;tested=0
for bits in product((0,1),repeat=L*L):
 S={v for v,b in zip(vertices,bits)if b}
 for es,w,plaquettes in phasecycles(S):
  if w==(0,0):continue
  D={v for e in es for v in e if v in S}
  assert connwind(D)
  p=sum(u[0]==v[0] or u[1]==v[1] for u,v in es)
  PD=sum((u in D)!=(v in D)for u,v in E)
  assert PD<=2*p
  maxratio=max(maxratio,PD/p);count+=1
  if abs(w[0])+abs(w[1])!=1 or p>L+2:continue
  tested+=1
  pins={((x+dx)%L,(y+dy)%L) for x,y in plaquettes for dx,dy in[(0,0),(1,0),(0,1),(1,1)]}
  K=pins&S;C=pins-S
  while True:
   good=[(x,y) for x,y in set(vertices)-K-C if sum(((x+dx)%L,(y+dy)%L) in K for dx,dy in[(1,0),(-1,0),(0,1),(0,-1)])>=2]
   if not good:break
   K.add(min(good))
  hasline=any(all((x,y) in K for y in range(L))for x in range(L)) or any(all((x,y) in K for x in range(L))for y in range(L))
  if not hasline:
   jams+=1
   if first is None:first={'S':sorted(S),'D':sorted(D),'C':sorted(C),'p':p,'w':w}
print(json.dumps({'wallcases':count,'axial_short_cases':tested,'jams':jams,'first':first},indent=2))
