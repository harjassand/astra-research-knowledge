from itertools import product
from collections import deque
import json
L=4;X=7;V={(x,y) for x in range(X) for y in range(L)};cand=[(x,y) for x in range(2,5) for y in range(L)]
def neigh(v,diag=False):
 x,y=v
 ds=[(a,b) for a in(-1,0,1) for b in(-1,0,1) if(a or b) and(diag or abs(a)+abs(b)==1)]
 return [((x+a),(y+b)%L,b) for a,b in ds if 0<=x+a<X]
def connwind(D):
 if not D:return False
 root=next(iter(D));pot={root:0};todo=[root];wind=False
 for v in todo:
  for x,y,dy in neigh(v):
   w=(x,y)
   if w not in D:continue
   value=pot[v]+dy
   if w in pot:
    if pot[w]!=value:wind=True
   else:pot[w]=value;todo.append(w)
 return len(pot)==len(D) and wind
count=adds=0
for bits in product((0,1),repeat=len(cand)):
 D={v for v,b in zip(cand,bits) if b}
 if not connwind(D):continue
 left={(0,y) for y in range(L)};q=deque(left)
 while q:
  v=q.popleft()
  for x,y,_ in neigh(v,True):
   w=x,y
   if w not in D and w not in left:left.add(w);q.append(w)
 assert all((X-1,y) not in left for y in range(L))
 K=set(D);xm=max(x for x,y in D)
 initialwall={(v,(x,y)) for v in left for x,y,_ in neigh(v) if (x,y) in K}
 while True:
  good=[v for v in V-K-left if v[0]<=xm and sum((x,y) in K for x,y,_ in neigh(v))>=2]
  if not good:break
  v=min(good);K.add(v);adds+=1
 assert all((xm,y) in K for y in range(L))
 finalwall={(v,(x,y)) for v in left for x,y,_ in neigh(v) if (x,y) in K}
 assert initialwall==finalwall
 count+=1
print(json.dumps({'cylinder_period':L,'all_subsets_checked':2**len(cand),'connected_winding_seeds':count,'native_additions':adds,'fixed_left_wall':True,'rightmost_column_complete':True},indent=2))
