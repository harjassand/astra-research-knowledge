from random import Random
import json
L=8;V={(x,y) for x in range(L) for y in range(L)}
key=lambda a,b:tuple(sorted((a,b)))
inc={}
for x,y in V:
 a=(x,y);b=((x+1)%L,y);c=((x+1)%L,(y+1)%L);d=(x,(y+1)%L)
 for t,vs in enumerate([(a,b,c),(a,d,c)]):
  for u,v in zip(vs,vs[1:]+vs[:1]):inc.setdefault(key(u,v),[]).append((x,y,t))
def cycles(S):
 adj={}
 for e,(a,b) in inc.items():
  if(e[0]in S)!=(e[1]in S):adj.setdefault(a,[]).append((b,e));adj.setdefault(b,[]).append((a,e))
 todo=set(adj);out=[]
 while todo:
  st=next(iter(todo));v=st;prev=None;es=[];dx=dy=0
  while True:
   todo.discard(v);n,e=next((n,e)for n,e in adj[v]if n!=prev);es.append(e)
   center=lambda t:(3*t[0]+(2 if t[2]==0 else 1),3*t[1]+(1 if t[2]==0 else 2))
   a,b=center(v),center(n)
   wrap=lambda z:(z+3*L//2)%(3*L)-3*L//2
   dx+=wrap(b[0]-a[0]);dy+=wrap(b[1]-a[1]);prev,v=v,n
   if v==st:break
  out.append((es,(dx//(3*L),dy//(3*L))))
 return out
phys=lambda e:e[0][0]==e[1][0] or e[0][1]==e[1][1]
E=[e for e in inc if phys(e)]
P=lambda D:sum((u in D)!=(v in D) for u,v in E)
rng=Random(123);maxratio=0;counter=None;num=0
for k in range(5000):
 S={v for v in V if rng.random()<.5}
 for es,wind in cycles(S):
  if wind==(0,0):continue
  p=sum(phys(e)for e in es)
  bytri={}
  for e in es:
   for tri in inc[e]:bytri.setdefault(tri,[]).append(e)
  curvature=0
  for tri,ee in bytri.items():
   assert len(ee)==2
   vertices=set(ee[0]+ee[1]);assert len(vertices)==3
   sign=1 if sum(v in S for v in vertices)==2 else -1
   curvature+=sign*(2 if all(phys(e) for e in ee) else 1)
  assert curvature==0, (wind,curvature)
  D={v for e in es for v in e if v in S}
  pd=P(D);num+=1
  maxratio=max(maxratio,pd/p)
  if pd>2*p:
   counter={'p':p,'PD':pd,'winding':wind,'S':sorted(S),'D':sorted(D)};break
 if counter:break
print(json.dumps({'tested_wall_cycles':num,'max_ratio':maxratio,'counterexample':counter},indent=2))
