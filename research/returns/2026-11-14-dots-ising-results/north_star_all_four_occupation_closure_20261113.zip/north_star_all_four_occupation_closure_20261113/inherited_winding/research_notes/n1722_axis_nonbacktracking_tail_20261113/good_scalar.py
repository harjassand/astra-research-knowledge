from fractions import Fraction as F
from pathlib import Path
import math,json

def elo(x,N=400):
 t=s=F(1)
 for k in range(1,N+1):t*=x/k;s+=t
 return s
def eup(x,N=400):
 t=s=F(1)
 for k in range(1,N+1):t*=x/k;s+=t
 r=x/F(N+1);return s+t*r/(1-r)
assert elo(F(1179,1000))>F(13,4)
assert eup(F(405,1000))<F(3,2)
assert elo(F(8))>2700
assert 200/(1-F(1,800))<201
Acoef=100*F(1,900)**4/(1-F(1,900))
root=Path(__file__).resolve().parents[2]
capacity=json.loads((root/'prior_dependency/00_previous_high_mass_dependency/04_optimized_capacity/check.json').read_text())['rows']
expected={80:1548,200:4136,1000:21502,10000:217281}
rows=[]
for R in [80,200,1000,10000]:
 row=next(d for d in capacity if d['R']==R and d['cutoff_area_over_R2']=='64/25')
 exact=-F(row['log_capacity_over_ZA_upper']);cap=exact.numerator//exact.denominator
 assert cap==expected[R]
 L=8*R;n=L*L;p=13*L//5+8
 assert F(13,5)*L==p-8
 # b_NB<1 and at least-three-loop remainder<1.
 assert 201*n<2**L
 k=math.ceil(math.log(201*n));assert elo(F(k))>201*n
 assert 3*k+81 < F(439,500)*L
 pref=1608*n*n*L
 ell=math.ceil(math.log(pref));assert elo(F(ell))>pref
 mult=F(ell+16)+F(1179,1000)*p-F(405,1000)*L+Acoef*n
 neg=F(cap)-mult
 rows.append(dict(R=R,L=L,p_upper=p,negative_exponent_exact=str(neg),negative_exponent_floor=neg.numerator//neg.denominator,nonvacuous=neg>0))
out=dict(scope='Reviewed original-source GOOD class with paid canonical area-admissible path, p<=2.6L+8. First two finite constants remain vacuous.',rows=rows)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
