from pathlib import Path
from fractions import Fraction as F
from math import factorial
import json
base=Path('research_notes');here=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
full=read(Path('prior_dependency/01_full_plus_line/full_line_scalar.json'))
short=read(base/'n1722_actual_wall_collar_20261113/short_conditional_scalar.json')['rows']
tail=read(here/'check.json')['rows'];good=read(here/'good_scalar.json')['rows']
failed=read(base/'n1722_failed_completion_pruning_20261113/combined.json')
globaltail=read(base/'n1722_winding_wall_tail_20261113/check.json')
large=read(base/'north_compute_20261113/ising_enlarged_hole_tail/check.json')['results']
raised=read(base/'n1722_failed_completion_pruning_20261113/raised_pressure.json')
enlarged=read(base/'ising_marked_hole_cover_20261113/enlarged_certificate.json')
assert enlarged['area_cutoff']=='4R^2/3' and enlarged['kernel_upper']=='2/5'
assert enlarged['pressure_at_R10000_upper']==2
assert sum(F(2)**k/factorial(k)for k in range(7))>7
rows=[]
for R in [80,200,1000,10000]:
 get=lambda arr,key:next(d[key]for d in arr if d['R']==R)
 branches={
 'full_line':get(full,'occupation_negative_exponent_floor'),
 'short_actual_wall':get(short,'negative_exponent_floor'),
 'two_axis_NB_tail':get(tail,'negative_exponent_floor'),
 'area_success_GOOD':get(good,'negative_exponent_floor'),
 'both_failure_thermal':get(failed,'negative_exponent_floor'),
 'large_contractible_hole':-get(large,'certified_log_upper_integer'),
 }
 m=min(branches.values());nonvacuous=m>2
 extra=get(globaltail,'occupation_and_mass_exp_negative')
 if nonvacuous:
  assert R in [1000,10000] and extra>=m
  rp=F(get(raised,'pressure_upper_exact'))
  assert rp<2<=F(get(failed,'contractible_pressure_upper_exact'))
 rows.append(dict(R=R,branches=branches,global_tail_extra_branch=extra,full_sector_nonvacuous=nonvacuous,sector_negative_exponent=(m-2 if nonvacuous else None)))
out=dict(scope='Reviewed original-source unrestricted-contractible-defect two-axis sector atR1000/10000; six branches, optional seventhglobaltail. No full-exit claim.',rows=rows)
here.joinpath('sector_receipt.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
