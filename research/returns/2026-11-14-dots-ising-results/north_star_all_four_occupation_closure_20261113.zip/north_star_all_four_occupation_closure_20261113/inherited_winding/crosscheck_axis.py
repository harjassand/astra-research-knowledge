from pathlib import Path
from fractions import Fraction as F
import json
root=Path(__file__).resolve().parent;b=root/'research_notes'
read=lambda p:json.loads(p.read_text())
x=read(b/'n1722_axis_nonbacktracking_tail_20261113/sector_receipt.json')['rows']
for d in x:
 assert len(d['branches'])==6
 if d['R'] in [80,200]:assert not d['full_sector_nonvacuous'] and d['sector_negative_exponent'] is None
 else:assert d['full_sector_nonvacuous'] and d['sector_negative_exponent']=={1000:138,10000:4356}[d['R']]
e=read(b/'ising_marked_hole_cover_20261113/enlarged_certificate.json')
assert e['area_cutoff']=='4R^2/3' and e['kernel_upper']=='2/5' and e['all_exact']
c=read(b/'north_compute_20261113/ising_marked_cover_review/check.json')
assert c['covered_families_tested']==24766 and c['peeling_steps']==38113 and c['all_peeling_invariants_pass']
assert read(b/'ising_marked_hole_cover_20261113/cyclic_cover_check.json')['all_pass']
large=read(b/'north_compute_20261113/ising_enlarged_hole_tail/check.json')['results']
for R,e in [(1000,-457),(10000,-6265)]:assert next(d for d in large if d['R']==R)['certified_log_upper_integer']==e
print('Six fresh original-source branches, raised cutoff/kernel/pressure, corrected cyclic extraction, exact large-hole complement and two headline bounds cross-checked.')
