from pathlib import Path
from fractions import Fraction as F
import json
root=Path(__file__).resolve().parent;notes=root/'research_notes'
load=lambda p:json.loads(p.read_text())
cap=load(root/'inherited_winding/prior_dependency/00_previous_high_mass_dependency/04_optimized_capacity/check.json')['rows']
actual={r['R']:(-F(r['log_capacity_over_ZA_upper'])).numerator//(-F(r['log_capacity_over_ZA_upper'])).denominator for r in cap if r['cutoff_area_over_R2']=='64/25'}
assert actual=={80:1548,200:4136,1000:21502,10000:217281}
old=load(notes/'north_compute_20261113/ising_short_anchor_join/solid_critical.json')
new=load(notes/'north_compute_20261113/ising_paired_anchor/check.json')['rows']
for a,b in zip(old,new):
 assert a['R']==b['R'];R=a['R']
 for v,k in ((a,'cost_exact'),(b,'total_log_multiplier_exact')):
  slack=F(actual[R])-F(v[k]);assert slack.numerator//slack.denominator==v['negative_exponent_floor']
union=load(notes/'n1722_compact_dense_coverage_20261113/global_integration.json')['rows']
basin=load(notes/'n1722_no_essential_source_20261113/scalar.json')
assert [r['all_topology_outside_F_negative_exponent']for r in union]==[513,1519,4421,33294]
rows=[]
for r,b in zip(union,basin):
 assert r['R']==b['R'];u=F(b['u_upper_exact']);assert 0<u<F(11,1000)
 rows.append(dict(**r,r=b['r'],u_upper_exact=str(u),F_minus_A_occupation_over_ZA_upper_exact=str(u/(1-u))))
out=dict(scope='Complete finite exterior occupation at all four original tuples. Original A/kappa/C; F is comparison downset, NOT M5; optional merger tail unused.',rows=rows,N_over_ZA_lower='1-C/(kappa ZA)',N_over_ZA_upper='1-C/(kappa ZA)+u_R/(1-u_R)+exp(-E_R)',limitations=['No rare-capacity acquisition algorithm','No uniform growing-R theorem','No physical or engineering breakthrough claimed'])
(root/'closure_receipt.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
