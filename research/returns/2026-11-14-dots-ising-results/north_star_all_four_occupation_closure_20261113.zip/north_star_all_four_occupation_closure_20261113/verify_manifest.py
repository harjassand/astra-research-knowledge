from pathlib import Path
import hashlib
root=Path(__file__).resolve().parent
expected={}
for line in (root/'SHA256SUMS.txt').read_text().splitlines():
 h,name=line.split('  ',1);expected[name]=h
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt'}
# Nested inherited manifests are themselves included in the top manifest.
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p!=root/'SHA256SUMS.txt'}
assert actual==set(expected),(actual-set(expected),set(expected)-actual)
for name,h in expected.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h,name
print('All',len(expected),'file hashes match the complete manifest.')
