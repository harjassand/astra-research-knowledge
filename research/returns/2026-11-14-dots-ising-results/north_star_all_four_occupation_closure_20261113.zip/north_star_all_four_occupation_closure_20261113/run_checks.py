from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
subprocess.run([sys.executable,str(root/'inherited_winding/run_checks.py')],cwd=root,check=True)
checks=['n1722_no_essential_source_20261113/check.py','n1722_no_essential_source_20261113/scalar.py','n1722_merger_encoding_review_20261113/check.py','n1722_open_anchor_partition_20261113/combinatorics.py','north_compute_20261113/ising_short_anchor_join/solid_critical.py','n1722_compact_dense_coverage_20261113/short_loops.py','n1722_compact_dense_coverage_20261113/refined.py','north_compute_20261113/ising_paired_anchor/pair_check.py','north_compute_20261113/ising_paired_anchor/bridge_pair_check.py','north_compute_20261113/ising_paired_anchor/check.py','n1722_compact_dense_coverage_20261113/global_integration.py']
for name in checks:
 print('CHECK:',name,flush=True)
 subprocess.run([sys.executable,str(root/'research_notes'/name)],cwd=root,check=True)
subprocess.run([sys.executable,str(root/'closure.py')],cwd=root,check=True)
print('All four-instance finite occupation closure checks passed. Capacity acquisition and uniform growing-R theorem remain open.')
