from pathlib import Path
from fractions import Fraction as F
import json
root=Path(__file__).resolve().parent
notes=root/'research_notes'
load=lambda p:json.loads(p.read_text())
cap=load(root/'inherited_winding/prior_dependency/00_previous_high_mass_dependency/04_optimized_capacity/check.json')['rows']
actual={r['R']:(-F(r['log_capacity_over_ZA_upper'])).numerator//(-F(r['log_capacity_over_ZA_upper'])).denominator for r in cap if r['cutoff_area_over_R2']=='64/25'}
assert actual=={80:1548,200:4136,1000:21502,10000:217281}
anchor=load(notes/'north_compute_20261113/ising_short_anchor_join/solid_critical.json')
comp=load(notes/'n1722_compact_dense_coverage_20261113/refined.json')
basin=load(notes/'n1722_no_essential_source_20261113/scalar.json')
wind=load(root/'inherited_winding/research_notes/winding_union_receipt.json')['rows']
rows=[]
for a,b in zip(anchor,comp):
 assert a['R']==b['R'];R=a['R']
 assert F(a['cost_exact'])+a['negative_exponent_floor']<=actual[R]
 branches={'native_solid_anchor':a['negative_exponent_floor'],'no_anchor_minus_sea':b['minussea_exp_floor'],'no_anchor_plus_background':b['plusbackground_exp_floor']}
 rows.append(dict(R=R,branches=branches,zero_essential_outside_F_negative_exponent=min(branches.values())-2 if a['nonvacuous'] else None))
assert [r['zero_essential_outside_F_negative_exponent'] for r in rows]==[513,1519,4421,None]
w=next(r['all_nonzero_essential_union'] for r in wind if r['R']==1000);assert w==137
combined=min(w,rows[2]['zero_essential_outside_F_negative_exponent'])-1;assert combined==136
u=F(next(r['u_upper_exact'] for r in basin if r['R']==1000));assert 0<u<F(11,1000)
out=dict(scope='Original A/kappa/C and actual voltage; F is comparison downset, NOT original M5. No optional F\\M5 tail used.',zero_essential_rows=rows,R1000_all_topology_outside_F_negative_exponent=combined,R1000_u_exact=str(u),R1000_F_minus_A_occupation_over_ZA_upper_exact=str(u/(1-u)),N_over_ZA_lower='1-C/(kappa ZA)',N_over_ZA_upper='1-C/(kappa ZA)+u/(1-u)+exp(-136)',limitations=['No rare-capacity acquisition algorithm','No uniform growing-R theorem','R10000 native-anchor branch vacuous','R80/R200 no complete winding union asserted'])
(root/'closure_receipt.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
