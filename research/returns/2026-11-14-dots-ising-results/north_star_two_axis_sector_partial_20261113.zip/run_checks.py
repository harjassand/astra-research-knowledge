from pathlib import Path
import subprocess,sys,json,ast
root=Path(__file__).resolve().parent
print('CHECK: complete original-source and reviewed short-wall dependency',flush=True)
subprocess.run([sys.executable,str(root/'run_short_wall_dependency.py')],cwd=root,check=True)
checks=[
 'n1722_axis_nonbacktracking_tail_20261113/check.py',
 'n1722_winding_wall_tail_20261113/check.py',
 'ising_marked_hole_cover_20261113/certificate.py',
 'ising_marked_hole_cover_20261113/cyclic_cover_check.py',
 'north_compute_20261113/ising_marked_cover_review/check.py',
 'ising_marked_hole_cover_20261113/enlarged_certificate.py',
 'n1722_failed_completion_pruning_20261113/check.py',
 'n1722_failed_completion_pruning_20261113/combined.py',
 'n1722_failed_completion_pruning_20261113/raised_pressure.py',
 'north_compute_20261113/ising_enlarged_hole_tail/check.py',
 'n1722_axis_nonbacktracking_tail_20261113/good_scalar.py',
 'n1722_axis_nonbacktracking_tail_20261113/sector_receipt.py',
]
for name in checks:
 p=root/'research_notes'/name;print('\nCHECK:',name,flush=True)
 r=subprocess.run([sys.executable,str(p)],cwd=root,check=True,capture_output=True,text=True)
 print(r.stdout,end='',flush=True)
 try:data=json.loads(r.stdout)
 except json.JSONDecodeError:data=ast.literal_eval(r.stdout)
 # raised_pressure.py writes a full exact receipt but intentionally prints an abbreviated display.
 if not name.endswith('/raised_pressure.py'):p.with_suffix('.json').write_text(json.dumps(data,indent=2)+'\n')
print('\nCHECK: unrestricted sector and corrected-cover linkage',flush=True)
subprocess.run([sys.executable,str(root/'crosscheck.py')],cwd=root,check=True)
print('\nAll checks passed. Unrestricted-defect two-axis major partial, not the full exit theorem.',flush=True)
