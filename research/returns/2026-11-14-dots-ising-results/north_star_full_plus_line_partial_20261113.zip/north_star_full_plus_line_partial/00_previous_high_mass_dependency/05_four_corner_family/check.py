"""Exact scalar certificates. Requires only Python3 standard library."""
from fractions import Fraction as F
from math import factorial
from pathlib import Path
import json
assert sum(F(7,10)**j/factorial(j) for j in range(5))>2
assert sum(F(6)**j/factorial(j) for j in range(16))>400
assert sum(F(313,40)**j/factorial(j) for j in range(32))>2000
# pi<22/7 (classical bound) implies pi²<10; no floating arithmetic used.
assert F(22,7)**2<10
capfile=Path(__file__).resolve().parents[1]/'n1722_optimized_cut_capacity_20261113'/'check.json'
if not capfile.exists():capfile=Path(__file__).resolve().parents[1]/'04_optimized_capacity'/'check.json'
cap=json.loads(capfile.read_text())
def clog2(n):return (n-1).bit_length()
rows=[]
for d in cap['rows']:
 if d['cutoff_area_over_R2']!='64/25':continue
 R=d['R'];r=d['r'];n=d['n']
 assert 8-F(2*(r+2),R)>=F(313,40)
 u1=6*n*F(1,100)**(2*r)/(1-F(1,100))
 # q<.01 is deliberately loose; only need alpha<1/2.
 alpha=6*n*F(1,100)**(4*R)/(1-F(1,100))
 assert u1<F(1,2) and alpha<F(1,2)
 logK=F(7,10)*clog2(8*n**3)+16+F(10,3)*R
 logC=F(d['log_capacity_over_ZA_upper'])
 logN=(logK+logC)/2
 S0=6*n*F(1,500)**4/(1-F(1,500));assert S0<1
 # exp(-S)>=1-S, so no transcendental evaluation needed for lower bound.
 masslower=F(n,2)*(1-S0)
 denominator=3 if R<=1000 else 6
 assert masslower>F(n,denominator)
 rows.append(dict(R=R,r=r,n=n,capacity_log_upper=str(logC),aggregate_energy_log_upper=str(logK),occupation_log_upper=str(logN),occupation_certificate='N_G/Z_A <= exp(-%d)'%((-logN.numerator)//logN.denominator),non_target_Gibbs_mass_lower='Z_(G minus B)/Z_A >= n/%d'%denominator,core_pressure_upper=str(S0)))
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
