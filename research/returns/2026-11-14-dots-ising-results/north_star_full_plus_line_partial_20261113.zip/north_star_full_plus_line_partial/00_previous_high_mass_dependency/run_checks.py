from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
scripts=[
'01_inherited_source_and_prior/run_checks.py',
'02_thermal_prefix_flow/check.py',
'03_interior_hole_reduction/check_density_dependency.py',
'04_optimized_capacity/check.py',
'05_four_corner_family/check.py',
'06_independent_four_corner_checks/check.py',
'06_independent_four_corner_checks/independent_scalar.py',
'07_independent_flow_algebra/check.py',
'09_core_image_winding_annulus/check.py',
'crosscheck_capacity.py']
for f in scripts:
 print('\nCHECK:',f,flush=True)
 subprocess.run([sys.executable,str(root/f)],cwd=root,check=True)
print('\nAll supplied checks passed. This is not an independent audit of the inherited source theorem.')
