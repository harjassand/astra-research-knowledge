from fractions import Fraction as F
from collections import defaultdict
import json
L=4;n=16;D={r*L+c for r in range(2) for c in range(2)}
neigh=lambda i:{((i//L+a)%L)*L+(i%L+b)%L for a,b in [(1,0),(-1,0),(0,1),(0,-1)]}
collar=set().union(*(neigh(i) for i in D))-D;free=set(range(n))-D-collar
edges=set(tuple(sorted((i,j))) for i in range(n) for j in neigh(i))
def w(x):return F(2)**(sum(((x>>i)&1)==((x>>j)&1) for i,j in edges)+x.bit_count())
def target(x):return x.bit_count()>=8
source=[]
for m in range(1<<len(free)):
 x=sum(1<<i for i in D)
 for j,i in enumerate(sorted(free)):
  if m>>j&1:x|=1<<i
 source.append(x)
Z=sum(map(w,source),F(0));order=[]
for a in [2,3]:
 order += [r*L+a for r in range(a)]
 order += [a*L+c for c in range(a+1)]
assert set(order)==set(range(n))-D
flow=defaultdict(F);preimages=defaultdict(set)
for x in source:
 z=x
 if target(z):continue
 for k,i in enumerate(order):
  y=z^(1<<i);e=tuple(sorted((z,y)));flow[e]+=w(x)/Z*(1 if z<y else -1);preimages[e].add(x);z=y
  if target(z):break
 assert target(z)
div=defaultdict(F);energy=F(0)
for (x,y),f in flow.items():
 div[x]+=f;div[y]-=f;energy+=f*f*(1/w(x)+1/w(y))
for x,val in div.items():
 if not target(x):assert val==(w(x)/Z if x in source else 0)
assert max(map(len,preimages.values()))<=2
moments=[];mask=0
for k in range(len(order)+1):
 moments.append(sum((w(x)*w(x)/w(x^mask) for x in source),F(0))/Z)
 if k<len(order):mask^=1<<order[k]
upper=sum((moments[k]+moments[k+1] for k in range(len(order))),F(0))/Z
assert energy<=upper
print(json.dumps(dict(source_states=len(source),source_states_already_in_B=sum(map(target,source)),free_thermal_bits=len(free),native_path_edges=len(flow),maximum_edge_preimages=max(map(len,preimages.values())),physical_flow_energy=str(energy),paid_full_prefix_upper=str(upper),exact_divergence_and_energy_checks=True,note='Finite algebra diagnostic with e^(2theta)=e^(2phi)=2. It does not satisfy the large-R supercritical geometry assumptions.'),indent=2))
