from fractions import Fraction as Q
from collections import defaultdict
from itertools import product
from pathlib import Path
import json
L=8;n=L*L;edges=[(r*L+c,r*L+(c+1)%L)for r in range(L)for c in range(L)]+[(r*L+c,((r+1)%L)*L+c)for r in range(L)for c in range(L)]
def weight(x):
 P=sum(((x>>i)^(x>>j))&1 for i,j in edges); k=x.bit_count()-P
 return Q(2**k)if k>=0 else Q(1,2**(-k))
def voltage(x):return max(Q(0),Q(n-2*x.bit_count(),n))
def add(f,x,y,a):
 e=tuple(sorted((x,y)));f[e]+=a if x<y else-a
Ds=[{(r+a)*L+c+b for a in range(3)for b in range(3)}for r,c in[(2,2),(2,3),(3,2)]]
free=[0,7,56,63];Fs=[];src=defaultdict(Q);preimages=defaultdict(set);energy=[]
for d,D in enumerate(Ds):
 center=sorted(D)[4];f=defaultdict(Q);order=sorted(set(range(n))-D)
 for bits in product([0,1],repeat=5):
  x=sum(1<<i for i in D if i!=center)+bits[0]*(1<<center)+sum(b*(1<<i)for b,i in zip(bits[1:],free));a=weight(x);src[x]+=a;y=x
  for i in order:
   if y.bit_count()>=n//2:break
   z=y^(1<<i);e=tuple(sorted((y,z)));preimages[d,e].add(x&sum(1<<v for v in D));add(f,y,z,a);y=z
  assert y.bit_count()>=n//2
 E=sum(a*a*(1/weight(e[0])+1/weight(e[1]))for e,a in f.items());energy.append(E);Fs.append(f)
f=defaultdict(Q)
for F in Fs:
 for e,a in F.items():f[e]+=a
div=defaultdict(Q)
for (x,y),a in f.items():div[x]+=a;div[y]-=a
assert all(a==src.get(x,Q(0))for x,a in div.items()if x.bit_count()<n//2)
assert all(div[x]==a for x,a in src.items())
assert max(map(len,preimages.values()))==1
E=sum(a*a*(1/weight(x)+1/weight(y))for (x,y),a in f.items());assert E<=len(Ds)*sum(energy)
N=sum(a*voltage(x)for x,a in src.items());pair=sum(a*(voltage(x)-voltage(y))for(x,y),a in f.items());assert N==pair
Ev=sum((voltage(x)-voltage(y))**2/(1/weight(x)+1/weight(y))for x,y in f);assert N*N<=E*Ev
out=dict(sources=len(src),contour_labels=len(Ds),aggregate_used_edges=len(f),interior_labels_per_fixed_contour_edge=max(map(len,preimages.values())),exact_divergence=True,exact_integration_by_parts=True,exact_Cauchy=True,exact_aggregate_energy_bound=True,scope='Dyadic Ising algebra diagnostic, not theta4 large-R geometric/MGF test; arbitrary sorted paths and test voltage, not actual harmonic voltage.')
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
