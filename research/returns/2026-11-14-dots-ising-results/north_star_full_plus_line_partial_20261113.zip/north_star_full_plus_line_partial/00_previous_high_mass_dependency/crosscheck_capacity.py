from pathlib import Path
from fractions import Fraction
import json,re
p=Path(__file__).resolve().parent
caps=json.loads((p/'04_optimized_capacity/check.json').read_text())['rows']
ann=json.loads((p/'09_core_image_winding_annulus/check.json').read_text())['cases']
for a in ann:
 c=next(x for x in caps if x['R']==a['R'] and x['r']==a['r'] and x['cutoff_area_over_R2']=='64/25')
 claimed=int(re.fullmatch(r'exp\(-([0-9]+)\)',a['capacity_upper']).group(1))
 assert Fraction(c['log_capacity_over_ZA_upper'])<=-claimed
print('Annulus capacity exponents checked against freshly regenerated optimized-capacity certificates for all four R/r pairs.')
