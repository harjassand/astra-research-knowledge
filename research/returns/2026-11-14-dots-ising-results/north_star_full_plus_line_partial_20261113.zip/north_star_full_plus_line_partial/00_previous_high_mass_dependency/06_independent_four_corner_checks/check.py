from pathlib import Path
from itertools import product
import json
R=2;W=4*R
parts=[p for p in product(range(R+1),repeat=R) if all(p[i]>=p[i+1] for i in range(R-1))]
box={(x,y) for x in range(W) for y in range(W)}
def transform(x,y,c):return (x if c%2==0 else W-1-x,y if c//2==0 else W-1-y)
def perimeter(S):return sum((x+dx,y+dy) not in S for x,y in S for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)])
def connected(S):
 seen={next(iter(S))};stack=list(seen)
 while stack:
  x,y=stack.pop()
  for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]:
   z=(x+dx,y+dy)
   if z in S and z not in seen:seen.add(z);stack.append(z)
 return len(seen)==len(S)
seen=set();areas={};edges=0
order=[transform(x,y,c) for c in range(4) for x,y in sorted(product(range(R),repeat=2),key=lambda z:(-sum(z),z))]
for ps in product(parts,repeat=4):
 missing={transform(x,y,c) for c,p in enumerate(ps) for y,width in enumerate(p) for x in range(width)}
 S=box-missing;sig=frozenset(S);assert sig not in seen;seen.add(sig)
 assert connected(S) and perimeter(S)==16*R
 assert min(x for x,y in S)==min(y for x,y in S)==0
 assert max(x for x,y in S)==max(y for x,y in S)==W-1
 assert 12*R*R<=len(S)<=16*R*R
 areas[len(S)]=areas.get(len(S),0)+1
 for z in order:
  if z in S:continue
  x,y=z;assert sum((x+dx,y+dy) in S for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)])==2
  old=perimeter(S);S.add(z);assert perimeter(S)==old;edges+=1
 assert S==box
res={'R':R,'partitions_per_corner':len(parts),'shapes_checked':len(seen),'single_site_fill_steps_checked':edges,'area_histogram':areas,'scope':'Solid geometry only. Does not establish full thermal XOR-shell moment or source coverage.'}
json.dump(res,open(Path(__file__).with_suffix('.json'),'w'),indent=2);print(res)
