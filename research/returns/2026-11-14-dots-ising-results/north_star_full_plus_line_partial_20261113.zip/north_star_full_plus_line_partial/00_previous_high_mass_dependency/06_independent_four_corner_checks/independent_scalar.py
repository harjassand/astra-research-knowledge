from pathlib import Path
from fractions import Fraction as F
import json
# Rational log upper from atanh series, range reduction; no imported scripts/receipts.
def log_piece_upper(z,N=36):
 s=sum((2*z**(2*j+1)/F(2*j+1) for j in range(N)),F(0))
 return s+2*z**(2*N+1)/(F(2*N+1)*(1-z*z))
def log_upper(x):
 x=F(x);m=x.numerator.bit_length()-x.denominator.bit_length()
 while x/F(2)**m<1:m-=1
 while x/F(2)**m>=2:m+=1
 assert m>=0
 y=x/F(2)**m
 return m*log_piece_upper(F(1,3))+log_piece_upper((y-1)/(y+1))
def exp_lower(x,N=40):
 t=F(1);s=t
 for j in range(1,N+1):t=t*x/j;s+=t
 return s
rows=[]
for R,r,claim in [(80,5,612),(200,5,1703),(1000,6,9047),(10000,7,91930)]:
 n=64*R*R;theta=4;phi=F(4,R)
 k0=8-phi*F(r+2,2)
 assert exp_lower(k0)>2000 # qcore=4exp(-k0)<1/500
 S=6*n*F(1,500)**4/(1-F(1,500))
 denom=3 if R<=1000 else 6
 assert F(n,2)*(1-S)>F(n,denom)
 assert exp_lower(F(4))>50
 u4=6*n*F(2,25)**(2*r)/(1-F(2,25));assert u4<F(1,2)
 assert exp_lower(F(6))>400
 u1=6*n*F(1,100)**(2*r)/(1-F(1,100));alpha=6*n*F(1,100)**(4*R)/(1-F(1,100))
 assert u1<F(1,2) and alpha<F(1,2)
 barrier=(F(24,5)-F(7,5)-F(1,R))*(F(32,5)*R-4)
 targetbar=phi*n*(F(1,2)-F(1,500000))-phi
 assert targetbar>barrier
 # 3 numerator terms, denominator<=2, Tbar includes8; C<=48n(6nR)^8 exp(-barrier).
 logC=log_upper(48*n)+8*log_upper(6*n*R)-barrier
 logK=log_upper(8*n**3)+16+F(22,7)**2*R/3
 logN=(logC+logK)/2
 assert logN < -claim
 rows.append(dict(R=R,r=r,claimed_negative_log=claim,independent_logC_upper_float_display=float(logC),independent_logK_upper_float_display=float(logK),independent_logN_upper_float_display=float(logN),core_pressure_exact=str(S),non_target_mass_lower=f'n/{denom}',all_comparisons_exact_rational=True))
json.dump(rows,open(Path(__file__).with_suffix('.json'),'w'),indent=2);print(rows)
