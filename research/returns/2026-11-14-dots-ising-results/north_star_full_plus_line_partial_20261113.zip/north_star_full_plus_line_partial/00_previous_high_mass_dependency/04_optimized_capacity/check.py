from pathlib import Path
from fractions import Fraction as F
from math import factorial
import json
# Analytic exponential replacements proved with finite Taylor lower sums.
assert sum(F(4)**k/factorial(k) for k in range(12))>F(160,3) #4e^-4<3/40
assert sum(F(7)**k/factorial(k) for k in range(15))>640 #4e^-7.25<1/160
assert sum(F(2)**k/factorial(k) for k in range(8))>F(80,11) #4e^-2<11/20
assert sum(F(7,10)**k/factorial(k) for k in range(6))>2 #log2<.7 andlog4<1.4

def tail(q,m):
 a=2*m+3
 return q**m*(F(a*a)/(1-q)+4*a*q/(1-q)**2+4*q*(1+q)/(1-q)**3)
rho=8*(tail(F(1,160),4)+tail(F(11,20),80))
assert rho<F(1,500000)
def logup(N):return F(7,10)*(N-1).bit_length()
rows=[]
for R,r in [(80,5),(200,5),(1000,6),(10000,7)]:
 n=64*R*R;phi=F(4,R)
 assert r+2<=F(R,3)
 u=6*n*F(3,40)**(2*r)/(1-F(3,40));assert u<F(1,2)
 for s in [F(2),F(8,5)]:
  coefficient=8-2*s-F(7,5)-F(1,R)
  cutoff=4*s*R-4
  ls=logup(16*n*(6*n*R)**8)-coefficient*cutoff
  lt=logup(2*n)-phi*(F(1,2)-F(1,500000))*n+phi
  lsource=logup(2)-phi*(F(1,2)-F(1,500000))*n #κ<=1 for upper only
  lc=F(7,5)+max(ls,lt,lsource)
  rows.append({'R':R,'r':r,'n':n,'cutoff_area_over_R2':str(s*s),'u_upper':float(u),'log_structural_upper':str(ls),'log_target_upper':str(lt),'log_soft_source_overlap_upper_with_kappa_dropped':str(lsource),'log_capacity_over_ZA_upper':str(lc),'certificate':'C_kappa/Z_A <= exp(-%d)'%((-lc.numerator)//lc.denominator)})
print(json.dumps({'rho_bound':float(rho),'arithmetic':'exact rational','rows':rows},indent=2));open(Path(__file__).with_suffix('.json'),'w').write(json.dumps({'rho_bound':float(rho),'arithmetic':'exact rational','rows':rows},indent=2))
