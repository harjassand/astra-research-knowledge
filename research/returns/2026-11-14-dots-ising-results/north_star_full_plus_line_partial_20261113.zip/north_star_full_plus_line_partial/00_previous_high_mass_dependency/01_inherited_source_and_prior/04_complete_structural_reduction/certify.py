"""Exact rational scalar certificates for two-family actual-current bounds.
This checks finite formulas/constants, not the underlying geometric theorem.
"""
from fractions import Fraction as F
from math import factorial,isqrt
from pathlib import Path
import json
assert sum(F(7,10)**k/factorial(k) for k in range(5))>2
assert sum(F(6)**k/factorial(k) for k in range(16))>400
q=F(1,100)
rho=8*q**4*(121/(1-q)+44*q/(1-q)**2+4*q*(1+q)/(1-q)**3)
assert rho<F(1,100000)
sqrt5_upper=F(223607,100000);assert sqrt5_upper**2>5
z=4*(2-sqrt5_upper/2)
assert sum(z**k/factorial(k) for k in range(18))>F(2000,59)
# Endpoint comparison c2>=c1, using theta>=4, sqrt5>=20/9, log4<7/5.
assert F(20,9)**2<5
assert (32-F(28,5))*F(20,9)-64+F(28,5)==F(4,15)>0
q5=F(59,500);a=F(49999,50000)
def clog2(x):
 k=0
 while 2**k<x:k+=1
 return k
def ceil(x):return -((-x.numerator)//x.denominator)
rows=[]
for R in [40,80,200,1000,10000]:
 theta=F(4);phi=theta/R;L=8*R;n=L*L;K=5*R*R;M=10*R;eps=F(1,100)
 r=1
 while 6*n*q5**(2*r)/(1-q5)>F(1,100):r+=1
 u=6*n*q5**(2*r)/(1-q5)
 assert 3*(r+2)<=R and 4*r<L and u<F(1,2)
 Gamma=8*theta*R/a+8*theta
 # Actual source clock kappa=eps/(64D0), D0 from the authorized core interface.
 # kappa^-1 <=pref exp(Ek), by log2<.7 and1+exp(10theta)<=2exp(10theta).
 pref=F(256*384,1)/eps*(r+2)**8*(n+1)*(F(7,10)+6*theta)
 Ek=10*theta+(F(28,5)+88*theta)*(r+2)
 logkinv_upper=F(7,10)*clog2(pref)+Ek
 loggrowth_upper=F(7,10)*clog2(2*n)+ceil(Gamma)
 logres_upper=F(7,10)+max(logkinv_upper,loggrowth_upper)
 B=9*R+3
 # Two disjoint macroscopic predecessor components.
 double_upper=F(7,10)*(clog2(36*n**3*B**2)+1)+logres_upper-(12*theta-F(56,5))*R
 # Collective pure-merger witness: <=8 disjoint precursor domains, each<=3R², total>=K.
 d=(90*theta-116)/35
 collective_upper=F(7,10)*(clog2(7*n*(126*n)**8)+1)+logres_upper-d*K/R
 # Refined pure-merger family: largest<=4R² and all otherprecursors<=R².
 slo=2*theta-F(29,20)
 area_energy_lower=(4*slo-2*theta)*K/R-8*slo*R
 area_merger_upper=F(7,10)*(clog2(7*n*(126*n)**8)+1)+logres_upper-area_energy_lower
 # Newly enclosed gap, with disjoint old domains total <= (9/2) R².
 assert R>=10 and F(7,10)**2<=F(1,2)-F(1,R*R)
 jump_energy=slo*(F(526,45)*R-4)-9*theta*R
 jump_upper=F(7,10)*(clog2(8*n*(126*n)**8)+1)+logres_upper-jump_energy
 # One large precursor whose thermal holes occupy at least a quarter of filled area.
 porous_upper=F(7,10)*(clog2(6*n*n*B)+1)+logres_upper-(12*theta-F(56,5))*R
 # Complete largest-old-area <=4 R² split at T=19/4.
 assert F(559,250)**2<5
 assert F(499,1000)**2 <= F(1,4)-F(1,R*R)
 lowS_energy=slo*(F(547,50)*R-4)-F(19,2)*theta*R
 highS_energy=(11*slo-F(19,2)*theta)*R
 common_pref=F(7,10)*(clog2(8*n*(126*n)**8)+1)+logres_upper
 lowS_upper=common_pref-lowS_energy
 highS_upper=common_pref-highS_energy
 # Sum of the two branches and two-macro current bound.
 all_small_upper=F(7,5)+max(lowS_upper,highS_upper,double_upper)
 # All newly winding exits; q=4 exp(-2theta), 1/(1-q)<2.
 winding_upper=F(7,10)*(clog2(6*n*n)+2)+logres_upper+10*theta*R-(2*theta-F(7,5))*(2*L-4)
 # The already derived sparse violating-component family, same source clock.
 sparse_upper=F(7,10)*(clog2(n*M*M)+6*(M-1)+1)+logres_upper+2*phi*M-8*theta*(isqrt(K+1)+isqrt(K+1-M))
 def certificate(x):
  return f'exp(-{(-x.numerator)//x.denominator})' if x<0 else '1 (nontrivial bound not certified)'
 rows.append(dict(all_precursors_at_most_4R2_upper=certificate(all_small_upper),all_precursors_log_upper=str(all_small_upper),winding_current_upper=certificate(winding_upper),winding_log_upper=str(winding_upper),lowS_log_upper=str(lowS_upper),highS_log_upper=str(highS_upper),hole_jump_log_fraction_upper_exact=str(jump_upper),hole_jump_fraction_upper=certificate(jump_upper),porous_log_fraction_upper_exact=str(porous_upper),porous_fraction_upper=certificate(porous_upper),R=R,L=L,n=n,r=r,epsilon=str(eps),clock='kappa=epsilon/(64D0), D0=2gamma0^-1[n(log2+6theta)+log2]',log_kappa_inverse_upper_exact=str(logkinv_upper),log_resistance_factor_upper_exact=str(logres_upper),two_macro_log_fraction_upper_exact=str(double_upper),two_macro_fraction_upper=certificate(double_upper),collective_merger_log_fraction_upper_exact=str(collective_upper),collective_merger_fraction_upper=certificate(collective_upper),area_cut_merger_log_fraction_upper_exact=str(area_merger_upper),area_cut_merger_fraction_upper=certificate(area_merger_upper),sparse_log_fraction_upper_exact=str(sparse_upper),sparse_fraction_upper=certificate(sparse_upper)))
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
