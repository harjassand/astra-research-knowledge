"""Exhaustive small fixed-triangulation diagnostics, not an asymptotic proof.
Interior 3x3, padded 5x5 planar graph; diagonal (1,1) in every square.
Tests the separator/laminar/hull statements for every state and minus-site addition.
"""
from collections import deque
from pathlib import Path
import json
V={(i,j) for i in range(5) for j in range(5)}
I=sorted((i,j) for i in range(1,4) for j in range(1,4))
steps=[(1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,-1)]
adj={v:{(v[0]+a,v[1]+b) for a,b in steps}&V for v in V}
bound={v for v in V if 0 in v or 4 in v}
def comps(A):
 A=set(A);out=[]
 while A:
  todo=[A.pop()];c=set(todo)
  while todo:
   for w in adj[todo.pop()]&A:A.remove(w);c.add(w);todo.append(w)
  out.append(c)
 return out
def fill(C):
 reachable=V-set(C);todo=list(bound&reachable);seen=set(todo)
 while todo:
  for w in adj[todo.pop()]&reachable-seen:seen.add(w);todo.append(w)
 return V-seen
count=inside=outside=closures=0
for mask in range(512):
 A={I[i] for i in range(9) if mask>>i&1};cs=comps(A);ds=[fill(c) for c in cs]
 for i,d in enumerate(ds):
  for e in ds[:i]: assert not(d&e) or d<=e or e<=d
 for z in set(I)-A:
  count+=1;newc=next(c for c in comps(A|{z}) if z in c);newd=fill(newc)
  enclosing=[d for d in ds if z in d]
  if enclosing:
   inside+=1
   for d in enclosing:assert newd<=d
  else:
   outside+=1;indices=[i for i,c in enumerate(cs) if c&adj[z]]
   joined=[ds[i] for i in indices]
   for i,d in enumerate(joined):
    for e in joined[:i]:assert not(d&e)
   W={z}.union(*joined)
   assert fill(W)==newd
   if newd!=W:closures+=1
result={'states':512,'minus_site_additions':count,'inside_old_fill':inside,'outside_all_old_fills':outside,'new_nonempty_hull_gaps':closures,'all_assertions_passed':True,'scope':'finite planar triangulated graph diagnostic; no native dynamics or asymptotic verification'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2));print(result)
