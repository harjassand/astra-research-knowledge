from pathlib import Path
import subprocess,sys
root=Path(__file__).parent
scripts=[
'01_thermal_capacity/thermal_capacity_flow_test.py',
'01_thermal_capacity/rational_sparse_certificate.py',
'01_thermal_capacity/sparse_current_thermal_normalization.py',
'02_merger_bounds/certify.py',
'03_gap_and_porosity/certify.py',
'04_complete_structural_reduction/certify.py',
'04_complete_structural_reduction/topology_test.py']
for name in scripts:
 print('\nCHECK:',name,flush=True)
 subprocess.run([sys.executable,str(root/name)],check=True,cwd=root)
print('\nAll supplied checks completed successfully. This is not an independent theorem audit.')
