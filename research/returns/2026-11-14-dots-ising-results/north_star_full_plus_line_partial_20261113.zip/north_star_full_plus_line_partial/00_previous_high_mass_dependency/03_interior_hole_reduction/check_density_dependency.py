"""Exact independent regeneration of the inherited companion-density ceiling."""
from fractions import Fraction as F
import json

def tail(x,m):
 a=2*m+3
 return x**m*(F(a*a)/(1-x)+4*a*x/(1-x)**2+4*x*(1+x)/(1-x)**3)
rho=8*(tail(F(1,160),4)+tail(F(11,20),80))
assert rho<F(1,500000)
print(json.dumps({'rho_decimal_diagnostic':float(rho),'rho_below_one_over_500000':True,'proof_arithmetic':'exact rational infinite-series evaluation','scope':'Validates rational series arithmetic, not the contour counting or Boltzmann bounds replacing exponentials.'},indent=2))
