from pathlib import Path
from fractions import Fraction as F
import json,math
# Exact anchored contour series: 8 sum_(p>=4) (2p+3)^2 q^p
q=F(1,300)
rho=8*q**4*(F(121)/(1-q)+F(44)*q/(1-q)**2+F(4)*q*(1+q)/(1-q)**3)
assert rho<F(1,8000000)
def lowerexp(x,terms=300):
 t=s=F(1)
 for j in range(1,terms+1):t*=x/j;s+=t
 return s
assert lowerexp(F(22,3))>1200 # 4 exp(-22/3)<1/300
out={'rho_exact':str(rho),'rho_bound':'1/8000000','cases':[]}
for R,r,cap,pref in [(80,5,1548,30),(200,5,4136,32),(1000,6,21502,35),(10000,7,217281,40)]:
 L=8*R;n=L*L
 assert r+2<=F(R,3)
 assert lowerexp(F(pref-16))>2*n
 occ=(cap-pref)//2
 mass=1-F(36*L+6,8000000)
 out['cases'].append(dict(R=R,L=L,r=r,capacity_upper=f'exp(-{cap})',occupation_upper=f'exp(-{occ})',non_target_mass_lower=str(mass),mass_lower_float=float(mass),prefactor_log_upper=pref))
print(json.dumps(out,indent=2));Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
# Independent exhaustive geometry check for every prefix on small tori.
geom=[]
for L,w in [(8,2),(12,4),(16,4),(16,6)]:
 D={(c,j) for c in range(w) for j in range(L)}
 Fset=set(); maxex=-10**9
 for c in range(w,L):
  for j in range(L):
   Fset.add((c,j));P=contacts=0
   for a,b in Fset:
    for z in [((a-1)%L,b),((a+1)%L,b),(a,(b-1)%L),(a,(b+1)%L)]:
     if z not in Fset:P+=1
     if z in D:contacts+=1
   maxex=max(maxex,P-2*contacts)
   assert P-2*contacts<=2
 geom.append(dict(L=L,width=w,prefixes=L*(L-w),maximum_boundary_excess=maxex))
open(__file__.replace('check.py','geometry.json'),'w').write(json.dumps(geom,indent=2)+'\n')
assert lowerexp(F(8))>1280
assert lowerexp(F(10))>16000
