from itertools import product
from fractions import Fraction as Q
import json
L=4;Fsites=[(x,y) for x in [1,2] for y in range(L)];base={(0,y) for y in range(L)}
E=[((x,y),((x+dx)%L,(y+dy)%L)) for x in range(L) for y in range(L) for dx,dy in [(1,0),(0,1)]]
P=lambda s:sum((a in s)!=(b in s) for a,b in E)
checks=0;fibers=0
for k in range(len(Fsites)+1):
 F=set(Fsites[:k]);ref=base|F
 assert P(ref)-L<=L+2
 groups={}
 for bits in product([0,1],repeat=len(Fsites)):
  s=base|{v for v,b in zip(Fsites,bits) if b};z=s|F
  # Right cylinder has at least one winding interface, hence >=L physical wall edges.
  assert P(s)-L>=L
  key=frozenset(z)
  ratio=Q(16)**(P(z)-P(s))*Q(2,3)**len(F-s)
  # Replace unknown future corridor spins by minus, keeping initial F assignment.
  ss=base|(s&F)
  raised=Q(16)**(P(ref)-P(ss))*Q(2,3)**len(F-s)
  assert ratio<=raised
  groups[key]=groups.get(key,Q(0))+ratio;checks+=1
 fibers+=len(groups)
print(json.dumps({'full_binary_pattern_prefix_checks':checks,'endpoint_fibers':fibers,'boundary_monotonicity':True,'right_wall_length_ge_L':True,'reference_wall_length_le_L_plus_2':True},indent=2))
