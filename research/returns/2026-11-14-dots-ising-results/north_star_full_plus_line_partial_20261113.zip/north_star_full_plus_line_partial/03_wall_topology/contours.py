from itertools import product
import json
L=4
V=lambda x,y:(x%L,y%L)
key=lambda a,b:tuple(sorted((a,b)))
tri={};inc={};centers={}
for x in range(L):
 for y in range(L):
  for t,vs in enumerate([(V(x,y),V(x+1,y),V(x+1,y+1)),(V(x,y),V(x,y+1),V(x+1,y+1))]):
   tid=(x,y,t);tri[tid]=vs;centers[tid]=(3*x+(2 if t==0 else 1),3*y+(1 if t==0 else 2))
   for a,b in zip(vs,vs[1:]+vs[:1]):inc.setdefault(key(a,b),[]).append(tid)
assert all(len(ts)==2 for ts in inc.values())
def physical(e):
 a,b=e;return a[0]==b[0] or a[1]==b[1]
def left(e):
 a,b=e;return a[1]==b[1] and {a[0],b[0]}=={0,L-1}
def cycles(plus):
 adj={}
 for e,(a,b) in inc.items():
  if (e[0] in plus)!=(e[1] in plus):adj.setdefault(a,[]).append((b,e));adj.setdefault(b,[]).append((a,e))
 assert all(len(v)==2 for v in adj.values())
 unseen=set(adj);out=[]
 while unseen:
  start=next(iter(unseen));cur=start;prev=None;dx=dy=0;edges=[]
  while True:
   unseen.discard(cur)
   nxt,e=next((v,e) for v,e in adj[cur] if v!=prev)
   a=centers[cur];b=centers[nxt]
   step=lambda d:(d+3*L//2)%(3*L)-3*L//2
   dx+=step(b[0]-a[0]);dy+=step(b[1]-a[1]);edges.append(e)
   prev,cur=cur,nxt
   if cur==start:break
  assert dx%(3*L)==0 and dy%(3*L)==0
  pe=[e for e in edges if physical(e)]
  out.append({'physical':len(pe),'winding':(dx//(3*L),dy//(3*L)),'fixed_left':bool(pe) and all(left(e) for e in pe)})
 return out
base={(0,y) for y in range(L)};sites=[(x,y) for x in [1,2] for y in range(L)];counts={};maxloops=0
for bits in product([0,1],repeat=len(sites)):
 plus=base|{v for v,b in zip(sites,bits) if b};cs=cycles(plus)
 fixed=[c for c in cs if c['fixed_left']]
 assert len(fixed)==1 and fixed[0]['physical']==L and abs(fixed[0]['winding'][1])==1
 other=[c for c in cs if not c['fixed_left']]
 assert any(c['winding']!=(0,0) and c['physical']>=L for c in other)
 assert all(c['physical']>=4 for c in other)
 maxloops=max(maxloops,len(cs));counts[len(cs)]=counts.get(len(cs),0)+1
print(json.dumps({'L':L,'binary_patterns':2**len(sites),'fixed_SW_NE_triangulation':True,'unique_fixed_interface':True,'remaining_winding_interface':True,'loop_count_histogram':counts,'max_loops':maxloops},indent=2))
