from fractions import Fraction as F
import json
n=3;states=range(1<<n)
w={x:F(2)**sum(((x>>i)&1)==((x>>((i+1)%n))&1) for i in range(n))*F(3,2)**x.bit_count() for x in states}
g={(x,x|(1<<i)):w[x]*w[x|(1<<i)]/(w[x]+w[x|(1<<i)]) for x in states for i in range(n) if not(x>>i&1)}

def solve(A,b):
 for k in range(len(b)):
  j=next(j for j in range(k,len(b)) if A[j][k]);A[k],A[j]=A[j],A[k];b[k],b[j]=b[j],b[k]
  d=A[k][k];A[k]=[x/d for x in A[k]];b[k]/=d
  for j in range(len(b)):
   if j==k:continue
   d=A[j][k];A[j]=[a-d*c for a,c in zip(A[j],A[k])];b[j]-=d*b[k]
 return b
out=[]
for asize,bsize in [(0,2),(1,2),(1,1),(2,2)]:
 Aset={x for x in states if x.bit_count()<=asize};B={x for x in states if x.bit_count()>=bsize};U=sorted(set(states)-B);kappa=F(2,7)
 matrix=[[F(0) for _ in U] for _ in U];rhs=[F(0) for _ in U]
 for j,x in enumerate(U):
  if x in Aset:matrix[j][j]+=kappa*w[x];rhs[j]+=kappa*w[x]
  for i in range(n):
   y=x^(1<<i);c=g[tuple(sorted((x,y)))];matrix[j][j]+=c
   if y in U:matrix[j][U.index(y)]-=c
 v={x:F(0) for x in B};v.update(zip(U,solve(matrix,rhs)))
 C=sum((kappa*w[x]*(1-v[x]) for x in Aset),F(0));flux=[F(0)]*n
 for (x,y),c in g.items():
  assert v[x]>=v[y];i=(x^y).bit_length()-1;flux[i]+=c*(v[x]-v[y])
 assert all(f<=C for f in flux)
 load={e:F(0) for e in g}
 for x in U:
  z=x
  for i in range(n):
   if z in B:break
   if not(z>>i&1):y=z|(1<<i);load[(z,y)]+=w[x];z=y
  assert z in B
 coeff=[F(0)]*n
 for e,c in g.items():i=(e[0]^e[1]).bit_length()-1;coeff[i]=max(coeff[i],load[e]/c)
 N=sum((w[x]*v[x] for x in U),F(0));identity=sum(((v[x]-v[y])*load[(x,y)] for x,y in g),F(0))
 assert N==identity and N<=C*sum(coeff)
 out.append({'source_max_plus':asize,'target_min_plus':bsize,'source_target_overlap':len(Aset&B),'capacity':str(C),'coordinate_fluxes':list(map(str,flux)),'occupation':str(N),'linear_capacity_upper':str(C*sum(coeff)),'exact_checks_passed':True})
print(json.dumps(out,indent=2))
