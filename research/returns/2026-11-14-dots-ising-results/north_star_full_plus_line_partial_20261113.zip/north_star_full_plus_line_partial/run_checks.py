from pathlib import Path
import subprocess,sys,json
root=Path(__file__).resolve().parent
print('CHECK: complete previous dependency package',flush=True)
subprocess.run([sys.executable,str(root/'00_previous_high_mass_dependency/run_checks.py')],cwd=root,check=True)
for name in ['02_monotone_current/check.py','03_wall_topology/check.py','03_wall_topology/contours.py','04_independent_review_and_gap/diagonal_gap.py','01_full_plus_line/full_line_scalar.py']:
 print('\nCHECK:',name,flush=True)
 result=subprocess.run([sys.executable,str(root/name)],cwd=root,check=True,capture_output=True,text=True)
 print(result.stdout,end='',flush=True)
 data=json.loads(result.stdout)
 (root/name).with_suffix('.json').write_text(json.dumps(data,indent=2)+'\n')
print('\nCHECK: dependency linkage',flush=True)
subprocess.run([sys.executable,str(root/'crosscheck_dependencies.py')],cwd=root,check=True)
print('\nAll supplied checks passed. Scope: finite diagnostics and certificates, not full residence or an independent reconstruction of the inherited archive.')
