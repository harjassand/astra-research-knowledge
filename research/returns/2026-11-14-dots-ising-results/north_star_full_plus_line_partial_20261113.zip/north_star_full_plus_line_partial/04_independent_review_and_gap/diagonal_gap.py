from pathlib import Path
import json
from fractions import Fraction
rows=[]
for R in [1,2,3,5]:
 L=8*R;w=4*R-1
 plus={(x,y) for x in range(L) for y in range(L) if (x-y)%L<w}
 P=sum(((x,y) in plus)!=(((x+dx)%L,(y+dy)%L) in plus) for x in range(L) for y in range(L) for dx,dy in [(1,0),(0,1)])
 assert len(plus)==w*L and P==4*L
 assert all(sum((x,y) in plus for x in range(L))==w for y in range(L))
 assert all(sum((x,y) in plus for y in range(L))==w for x in range(L))
 # Physical nearest-neighbor winding staircase: (j,j)->(j+1,j)->(j+1,j+1), j modL.
 loop=[]
 for j in range(L):loop.extend([(j,j),((j+1)%L,j)])
 assert all(z in plus for z in loop)
 assert len(set(loop))==2*L
 logratio=-8*P+Fraction(8*len(plus),R)
 assert logratio==-64
 rows.append(dict(R=R,L=L,plus_count=len(plus),physical_perimeter=P,full_plus_rows=0,full_plus_columns=0,winding_staircase_length=len(loop),log_weight_ratio_to_all_minus=-64))
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
