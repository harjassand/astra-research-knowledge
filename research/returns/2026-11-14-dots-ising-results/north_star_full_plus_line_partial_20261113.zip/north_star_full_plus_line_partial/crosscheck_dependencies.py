from pathlib import Path
from fractions import Fraction as F
import json
p=Path(__file__).resolve().parent
rows=json.loads((p/'01_full_plus_line/full_line_scalar.json').read_text())
pressure=json.loads((p/'00_previous_high_mass_dependency/05_four_corner_family/check.json').read_text())
ann=json.loads((p/'00_previous_high_mass_dependency/09_core_image_winding_annulus/check.json').read_text())['cases']
expected={80:596,200:1836,1000:10234,10000:105199}
for d in rows:
 R=d['R'];assert d['occupation_negative_exponent_floor']==expected[R]
 a=next(x for x in ann if x['R']==R);assert a['r']==d['r']
 assert F(a['non_target_mass_lower'])>0
 s=F(next(x for x in pressure if x['R']==R)['core_pressure_upper'])
 assert s<(F(1,100) if R<=1000 else 1)
 assert d['occupation_negative_exponent_floor']>66
print('Fresh capacity, original r, annular same-set mass, local pressure and all four headline exponents cross-checked.')
