from fractions import Fraction as F
from pathlib import Path
import json,math

def elo(x):
 t=s=F(1)
 for k in range(1,400):t*=x/k;s+=t
 return s
assert elo(F(8))>2800
assert elo(F(7,5))>4
q=F(1,700)
assert 100/(1-q)<101
assert 100*q**4/(1-q)==F(1,2397570000)
rows=[]
cap_path=Path(__file__).resolve().parents[1]/'00_previous_high_mass_dependency/04_optimized_capacity/check.json'
caps=json.loads(cap_path.read_text())['rows']
for R,expected_cap in [(80,1548),(200,4136),(1000,21502),(10000,217281)]:
 c=next(d for d in caps if d['R']==R and d['cutoff_area_over_R2']=='64/25')
 logC=F(c['log_capacity_over_ZA_upper']);cap=(-logC.numerator)//logC.denominator
 assert cap==expected_cap and c['n']==64*R*R
 L=8*R;n=L*L;pref=404*n*n*L
 k=math.ceil(math.log(pref));assert elo(F(k))>pref
 total=F(k+16)+F(7,5)*L+F(n,2397570000)
 remain=F(cap)-total
 rows.append(dict(R=R,r=c['r'],L=L,capacity_negative_exponent=cap,log_prefactor_upper=k,log_total_multiplier_upper_exact=str(total),occupation_negative_exponent_exact=str(remain),occupation_negative_exponent_floor=remain.numerator//remain.denominator))
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
