"""Complete global cut upper from directed magnetic moments and directed positive convolution.
Software arithmetic contract: C++ IEEE upward arithmetic, correctly-rounded Decimal exp/ln.
"""
from decimal import Decimal as D,localcontext,ROUND_CEILING,ROUND_FLOOR,getcontext
from fractions import Fraction as F
from pathlib import Path
from math import factorial
import subprocess,json,sys
getcontext().prec=110;getcontext().rounding=ROUND_CEILING
root=Path(__file__).parent;R=int(sys.argv[1]) if len(sys.argv)>1 else 200;s=F(sys.argv[2]) if len(sys.argv)>2 else F(79,40)
M=19*R//2;n=64*R*R;phi=F(4,R);r_core={80:5,200:5,1000:6}[R]
folder=root/f'cert_r{R}'
def dd(f,up=True):
 f=F(f)
 with localcontext() as c:
  c.rounding=ROUND_CEILING if up else ROUND_FLOOR
  return D(f.numerator)/D(f.denominator)
def lnhi(f):return dd(f).ln().next_plus()
def lnlo(f):return dd(f,False).ln().next_minus()
def hexfrac(h):
 a,e=h.split('p');a=a.removeprefix('0x');u,v=(a.split('.')+[''])[:2]
 return F(int(u+v,16),16**len(v))*F(2)**int(e)
def lse(vals):
 m=max(vals);return m+sum((v-m).exp().next_plus() for v in vals).ln().next_plus()
def exp_lo(x,N):return sum(F(x)**j/factorial(j) for j in range(N+1))
inputs=[]
for p in sorted(folder.glob('moment_*.txt')):
 num,den=map(int,p.stem.split('_')[1:]);rr=F(num,den)
 assert rr>=1 and 2*(rr-1)<=2*phi
 z={}
 for line in p.read_text().splitlines():
  if not line or line.startswith('#'):continue
  per,h,e=line.split();z[int(per)]=lnhi(hexfrac(h))+D(int(e))*lnhi(2)
 assert M in z
 inputs.append((rr,z,p.name))
assert len(inputs)>=3
V=(s*s*R*R).numerator//(s*s*R*R).denominator;S0=(4*s*R-4).__ceil__()
la={}
for p in range(4,M+1,2):
 Vp=min(V,p*p//16)
 la[p]=lnhi(n)-8*p+dd(2*phi*Vp)+min(z[p]-D(2*Vp)*lnlo(rr) for rr,z,_ in inputs)-lnlo(p)
J=int(max(la[p]+4*p for p in la).to_integral_value(rounding=ROUND_CEILING))
weights=['0']*(M+1)
for p in la:weights[p]=str((la[p]+4*p-J).exp().next_plus())
q4=1/exp_lo(4,48);q4str=str(dd(q4))
inp=f'{M} {S0} {q4str}\n'+'\n'.join(weights)+'\n'
(folder/f'marked_convolution_s{s.numerator}_{s.denominator}.input').write_text(inp)
out=subprocess.check_output([__import__('os').environ['N1722_CONVOLUTION'],'marked'],input=inp,text=True)
(folder/f'marked_convolution_s{s.numerator}_{s.denominator}.output').write_text(out)
terms=[]
for line in out.splitlines():
 j,h=line.split();h=hexfrac(h);assert h>0
 terms.append(D(int(j)*J-4*S0)+lnhi(h)+lnhi(3)-lnlo(factorial(int(j))))
logshort=lse(terms)
# Complete tail, not omitted. Actual area cap plus physical3-branch trace count.
a_s=F(4)*(2-s/2)
q_s=(dd(-a_s)).exp().next_plus()*4
assert q_s<1
with localcontext() as c:c.rounding=ROUND_FLOOR;den_s=1-q_s
logall=lnhi(6*n)+4*q_s.ln().next_plus()-den_s.ln().next_minus()
qt=F(3)/exp_lo(8,72)
logtail=lnhi(36)+lnhi(F(4*n,3))+dd(2*phi*V)+(M+1)*lnhi(qt)-lnlo(1-qt)+7*max(D(0),logall)
u=F(6*n)*F(3,40)**(2*r_core)/(1-F(3,40));assert u<F(1,2)
structural=lse([logshort,lnhi(n)+logtail])
target=lnhi(n)-dd(phi*n*(F(1,2)-F(1,500000)),False)+dd(phi)
source=-dd(phi*n*(F(1,2)-F(1,500000)),False) # originalkappa<=1 upperonly
logU=lse([structural,target,source])-lnlo(1-u)
result={'scope':'Complete root/order-unbiased, boundary-marked original soft-cut capacity upper; directed hardware DP/convolution plus outward Decimal scalar receipt. Validity depends on documented contour injection and inherited cut lemmas; not actual energy-edge proposal or full W/C.','R':R,'r':r_core,'s':str(s),'area_cap':V,'perimeter_threshold':S0,'M':M,'rational_tilt_inputs':[name for _,_,name in inputs],'convolution_shift_J':J,'log_marked_structural_short_upper':str(logshort),'log_tuple_tail_upper':str(logtail),'log_capacity_over_ZA_upper':str(logU),'trial_energy_has_same_upper':True,'integer_certificate':f'W_cut/Z_A <= exp(-{int((-logU).to_integral_value(rounding=ROUND_FLOOR))}), hence C_kappa/Z_A has the same upper'}
print(json.dumps(result,indent=2));(folder/f'certificate_marked_s{s.numerator}_{s.denominator}.json').write_text(json.dumps(result,indent=2)+'\n')
