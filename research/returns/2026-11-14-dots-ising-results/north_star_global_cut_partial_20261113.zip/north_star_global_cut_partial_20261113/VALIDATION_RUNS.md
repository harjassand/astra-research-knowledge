# Executed validation before freezing

The default disposable-copy runner passed, including exact independent proposal checks, all small arithmetic comparisons, complete scalar/convolution regeneration and exact k100 matched-cut coefficient regeneration. A separate full run regenerated all three perimeter-1900 magnetic recurrences and then the complete marked bound; it passed. The inherited thermal core finite-flow diagnostic was also rerun successfully.

The full recurrence rerun reported no underflow or overflow in any activity. Its first two CPU times were 112.712 and 124.999 seconds; runtime is not an algorithmic guarantee. These runs validate the documented software contract, not formal compiler verification. The optional matched-cut and original-clock additions were checked in the later default run; no claim that they were in the earlier full-run copy is made.

Independent archive extraction/manifest verification is requested separately after this freeze. Mathematical reviews already included are scoped in the dependency ledger.
