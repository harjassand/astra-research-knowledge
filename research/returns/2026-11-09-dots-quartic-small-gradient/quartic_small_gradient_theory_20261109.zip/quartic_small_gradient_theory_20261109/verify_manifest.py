#!/usr/bin/env python3
"""Verify delivered bytes only; this does not verify mathematical claims."""
from pathlib import Path
import hashlib, sys
root=Path(__file__).resolve().parent
bad=[]
count=0
for line in (root/"MANIFEST.sha256").read_text().splitlines():
    digest, name=line.split("  ",1)
    p=root/name
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:
        bad.append(name)
    count+=1
if bad:
    print("FAILED:", *bad, sep="\n")
    sys.exit(1)
print(f"PASS: {count} files match MANIFEST.sha256. Integrity only; not a proof check.")
