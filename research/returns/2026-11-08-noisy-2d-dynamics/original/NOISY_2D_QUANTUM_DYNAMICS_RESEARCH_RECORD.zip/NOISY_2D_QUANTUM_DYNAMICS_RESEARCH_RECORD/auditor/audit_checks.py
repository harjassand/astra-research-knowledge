"""Independent finite checks; these supplement, and do not prove, the lemmas.

Run with python3.  No external state/oracle, no scipy, no inherited audit code.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import math
import numpy as np

HERE = Path(__file__).resolve().parent
rng = np.random.default_rng(20261108)
I = np.eye(2, dtype=complex)
X = np.array([[0, 1], [1, 0]], dtype=complex)
Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
Z = np.diag([1, -1]).astype(complex)
pauli = [I, X, Y, Z]
pb = [np.kron(a, b) for a in pauli for b in pauli]

def expm(a):
    scale = max(0, int(math.ceil(math.log2(max(1., np.linalg.norm(a, np.inf))))))
    b = a / (2**scale)
    term = np.eye(len(a), dtype=complex)
    total = term.copy()
    for k in range(1, 200):
        term = term @ b / k
        total += term
        if np.linalg.norm(term, np.inf) < 1e-18:
            break
    else:
        raise RuntimeError('Taylor series failed')
    for _ in range(scale):
        total = total @ total
    return total

def e_site(a, site):
    # Pauli expansion makes the normalization of replacement transparent.
    out = np.zeros_like(a)
    for j, p in enumerate(pb):
        if (j // 4 if site == 0 else j % 4) == 0:
            out += np.trace(p.conj().T @ a) * p / 4
    return out

def linear_matrix(fn, dim):
    cols = []
    for k in range(dim**2):
        basis = np.zeros((dim, dim), dtype=complex)
        basis.reshape(-1)[k] = 1
        cols.append(fn(basis).reshape(-1))
    return np.array(cols).T

def partial_first(a):
    return np.trace(a.reshape(2, 2, 2, 2), axis1=1, axis2=3)

report = {'seed': 20261108, 'status': 'finite diagnostics only'}

# The exact product witness: ||A||_{2,tau}=1, ||D_s A||_inf=(1+r^2)^(m/2).
spikes = []
for m in [10, 100, 1000, 10000]:
    gamma_s = .3
    log_ratio = m / 2 * math.log1p(math.exp(-2*gamma_s))
    spikes.append({'m': m, 'gamma_s': gamma_s,
                   'log_norm_ratio': log_ratio,
                   'necessary_gamma_s_for_C2': -.5 * math.log(math.expm1(2*math.log(2)/m))})
report['constant_buffer_obstruction'] = spikes

# Check the truncation identity against arbitrary unrelated reference matrices.
identity_residual = 0.
worst_slack = -float('inf')
for _ in range(200):
    phi = rng.normal(size=(7, 6)) + 1j*rng.normal(size=(7, 6))
    phi /= max(1., np.linalg.norm(phi))
    psi = rng.normal(size=(7, 6)) + 1j*rng.normal(size=(7, 6))
    psi /= np.linalg.norm(psi)
    rank = int(rng.integers(1, 6))
    u, sv, vh = np.linalg.svd(phi, full_matrices=False)
    kept = (u[:, :rank] * sv[:rank]) @ vh[:rank]
    residual = phi-kept
    old = np.linalg.norm(phi-psi)**2
    new = np.linalg.norm(kept-psi)**2
    rhs = old-np.linalg.norm(residual)**2+2*np.vdot(residual, psi).real
    identity_residual = max(identity_residual, abs(new-rhs))
    bstar = np.linalg.svd(psi, compute_uv=False).sum()
    worst_slack = max(worst_slack, new-old-2*bstar/math.sqrt(rank+1))
assert identity_residual < 1e-12 and worst_slack < 1e-12
report['truncation_200_cases'] = {'max_identity_residual': identity_residual,
                                 'max_inequality_violation': max(0., worst_slack)}

# Actual two-site rational-Cayley/Euler coefficient maps, not an undamped proxy.
lp_max_ratio = 0.
for gamma in [.01, .1, 1., 10.]:
    d, j, h = 3, 1., .01
    exponent = 2/(1+min(1., gamma/(2*d*j)))
    v = h*j
    u = ((1-v*v/4)*np.eye(4)-1j*v*np.kron(Z, Z))/(1+v*v/4)
    def block(a):
        out = u.conj().T @ a @ u
        for site in [0, 1]:
            out = (1-gamma*h/d)*out+(gamma*h/d)*e_site(out, site)
        return out
    transfer = np.array([[np.trace(p.conj().T @ block(q)).real/4 for q in pb] for p in pb])
    for _ in range(100):
        coeff = rng.normal(size=16)
        ratio = np.linalg.norm(transfer @ coeff, ord=exponent)/np.linalg.norm(coeff, ord=exponent)
        lp_max_ratio = max(lp_max_ratio, ratio)
assert lp_max_ratio <= 1+1e-12
report['sparse_block_400_cases'] = {'max_lp_ratio': lp_max_ratio}

h = np.kron(X, X)+.4*np.kron(Z, I)+.3*np.kron(I, X)
hyper_ratio = 0.
floor_ratio = float('inf')
floor_examples = []
for gamma in [.1, 1., 3.]:
    def gen(a):
        return -1j*(h@a-a@h)+gamma*(e_site(a, 0)+e_site(a, 1)-2*a)
    def adj(a):
        return 1j*(h@a-a@h)+gamma*(e_site(a, 0)+e_site(a, 1)-2*a)
    s = 1/gamma
    heis = expm(linear_matrix(adj, 4)*s)
    constant = 2**(2/(1+math.exp(2*gamma*s)))
    for _ in range(20):
        a = rng.normal(size=(4, 4))+1j*rng.normal(size=(4, 4))
        a = (a+a.conj().T)/2
        output = (heis @ a.reshape(-1)).reshape(4, 4)
        ratio = np.linalg.norm(output, ord=2)/(np.linalg.norm(a)/2)/constant
        hyper_ratio = max(hyper_ratio, ratio)
    for t in [.01, .1, .5, 2.]:
        channel = expm(linear_matrix(gen, 4)*t)
        # w=1,d=2,J=1 -> tau=1/16 and floor=(1-exp(-gamma*Delta))/4.
        duration = min(t, 1/16)
        bound = (1-math.exp(-gamma*duration))/4
        actual_min = 1.
        for _ in range(20):
            ket = rng.normal(size=4)+1j*rng.normal(size=4)
            ket /= np.linalg.norm(ket)
            rho = np.outer(ket, ket.conj())
            output = (channel @ rho.reshape(-1)).reshape(4, 4)
            eig = np.linalg.eigvalsh(partial_first(output)).min()
            actual_min = min(actual_min, float(eig))
            floor_ratio = min(floor_ratio, float(eig)/bound)
        floor_examples.append({'gamma': gamma, 'T': t, 'lower_bound': bound,
                               'minimum_observed_eigenvalue': actual_min})
assert hyper_ratio <= 1+1e-10 and floor_ratio >= 1-1e-10
report['hypercontractive_60_cases'] = {'max_ratio_to_bound': hyper_ratio}
report['local_doeblin_240_cases'] = {'minimum_ratio_to_bound': floor_ratio, 'cases': floor_examples}

# The early buffer must be on the input side for a non-autonomous extension.
ux = math.cos(1)*I-1j*math.sin(1)*X
uz = math.cos(1)*I-1j*math.sin(1)*Z
ket = np.array([1., 0.], dtype=complex)
correct = uz@ux@ket
reversed_order = ux@uz@ket
gamma = .1
f_correct = math.exp(-2*gamma)*np.vdot(correct, X@correct).real
f_wrong = math.exp(-2*gamma)*np.vdot(reversed_order, X@reversed_order).real
assert abs(f_correct-math.exp(-2*gamma)*math.sin(2)**2) < 1e-12
assert abs(f_wrong) < 1e-12
report['time_ordering_counterexample'] = {'first': 'H=X for time 1', 'second': 'H=Z for time 1',
                                         'initial': '|0>', 'observable': 'X', 'gamma': gamma,
                                         'correct': float(f_correct), 'wrong_order': float(f_wrong)}

# A one-site reset explicitly defeats the uniform-mixing endpoint.
report['nonunital_reset_counterexample'] = [
    {'gamma': 1, 'reset_rate': kappa, 'stationary_Z': kappa/(1+kappa)}
    for kappa in [.1, 1, 10]]

report['script_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
(HERE/'AUDIT_CHECKS.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
