"""Finite algebra/tail checks for the biased-reset construction, not a proof."""
from pathlib import Path
import json,math,hashlib
import numpy as np

rng=np.random.default_rng(202611082)
I=np.eye(2,dtype=complex)
X=np.array([[0,1],[1,0]],dtype=complex)
Y=np.array([[0,-1j],[1j,0]],dtype=complex)
Z=np.diag([1,-1]).astype(complex)
report={}
for p in [.1,.3,.5,.7,.9]:
    q=1-p;mu=min(p,q);z=2*p-1
    fs=[I,X/math.sqrt(2*math.sqrt(p*q)),Y/math.sqrt(2*math.sqrt(p*q)),
        (Z-z*I)/(2*math.sqrt(p*q))]
    sig=np.diag([p,q]);root=np.diag(np.sqrt([p,q]))
    basis=[np.kron(a,b) for a in fs for b in fs]
    ss=np.kron(sig,sig);rr=np.kron(root,root)
    gram=np.array([[np.trace(a.conj().T@rr@b@rr) for b in basis]for a in basis])
    gram_error=float(np.max(np.abs(gram-np.eye(16))))
    h=.45*(np.kron(X,X)+np.kron(Y,Y))+.3*np.kron(Z,Z)+.2*np.kron(Z,I)-.1*np.kron(I,Z)
    assert np.linalg.norm(h,2)<=2
    comm=float(np.linalg.norm(h@ss-ss@h))
    coh=np.array([[np.trace(a.conj().T@rr@(1j*(h@b-b@h))@rr).real for b in basis]for a in basis])
    skew=float(np.linalg.norm(coh+coh.T,2))
    step=.03;gamma=1.;jbound=2.;k=2;d=1;ck=8
    u=(np.eye(4)-.5j*step*h)@np.linalg.inv(np.eye(4)+.5j*step*h)
    transfer=np.array([[np.trace(a.conj().T@rr@(u.conj().T@b@u)@rr).real for b in basis]for a in basis])
    invariance=float(np.linalg.norm(u@ss@u.conj().T-ss))
    isometry=float(np.linalg.norm(transfer.T@transfer-np.eye(16),2))
    weights=np.array([int(i//4!=0)+int(i%4!=0) for i in range(16)])
    damp=np.diag((1-gamma*step/d)**weights)
    block=damp@transfer
    pc=2/(1+min(1,gamma/(ck*d*jbound)))
    maxratio=0.
    for _ in range(100):
        v=rng.normal(size=16)
        maxratio=max(maxratio,float(np.linalg.norm(block@v,pc)/np.linalg.norm(v,pc)))
    theta=min(1/(2*k),gamma/(16*d*k*ck*jbound))
    tilt=np.diag(np.exp(theta*weights));untilt=np.diag(np.exp(-theta*weights))
    tiltednorm=float(np.linalg.norm((tilt@block@untilt)[1:,1:],2))
    assert max(gram_error,comm,skew,invariance,isometry)<1e-12
    assert maxratio<=1+1e-12 and tiltednorm<=1+1e-12
    assert max(np.linalg.norm(f,2)for f in fs)<=mu**-.5+1e-12
    report[str(p)]={'gram_error':gram_error,'reference_commutator':comm,'skew_residual':skew,
                    'cayley_reference_error':invariance,'weighted_isometry_error':isometry,
                    'pc':pc,'max_coefficient_p_ratio':maxratio,'tilted_active_norm':tiltednorm}

# Reset dilation keeps the old quantum register rather than measuring it.
ket=rng.normal(size=4)+1j*rng.normal(size=4);ket/=np.linalg.norm(ket)
rho=np.outer(ket,ket.conj());p=.7;sig=np.diag([p,1-p])
swap=np.zeros((8,8),dtype=complex)
for a in range(2):
 for b in range(2):
  for c in range(2):swap[4*c+2*b+a,4*a+2*b+c]=1
out=np.zeros((4,4),dtype=complex)
cut_residual=0.
for bit,prob in [(0,p),(1,1-p)]:
 anc=np.zeros(2);anc[bit]=1
 psi=np.kron(ket,anc);swapped=swap@psi
 full=np.outer(swapped,swapped.conj()).reshape(2,2,2,2,2,2)
 out+=prob*np.trace(full,axis1=2,axis2=5).reshape(4,4)
 def nuclear(v):return np.linalg.svd(v.reshape(2,2,2).transpose(0,2,1).reshape(4,2),compute_uv=False).sum()
 cut_residual=max(cut_residual,abs(nuclear(psi)-nuclear(swapped)))
rest=np.trace(rho.reshape(2,2,2,2),axis1=0,axis2=2)
target=np.kron(sig,rest)
reset_error=float(np.linalg.norm(out-target))
assert reset_error<1e-12 and cut_residual<1e-12
report['reset_dilation']={'channel_error':reset_error,'onsite_swap_cut_nuclear_residual':cut_residual}

# Hermitian contraction parity overlap; no involution premise.
max_parity=0.
for _ in range(50):
    angle=float(rng.uniform(-1,1))
    pauli=np.kron(np.kron(X,X),I)
    u=math.cos(angle)*np.eye(8)-1j*math.sin(angle)*pauli
    a=.2*I+.3*Z;b=-.1*I+.4*X;c=.3*I+.2*Y
    even=np.kron(np.kron(a,I),c);odd=np.kron(np.kron(I,b),I)
    qe=u.conj().T@even@u;qo=u.conj().T@odd@u
    psi=rng.normal(size=8)+1j*rng.normal(size=8);psi/=np.linalg.norm(psi)
    max_parity=max(max_parity,abs(np.vdot(qe@psi,qo@psi)-np.vdot(psi,(qe@qo)@psi)))
assert max_parity<1e-12
report['contraction_parity_50_cases']={'max_identity_residual':float(max_parity)}

# A row cap uniform in the number of tiny Bernoulli time steps.
tails=[]
for mean in [1.,10.]:
 for ntrials in [100,1000,10000]:
    prob=mean/ntrials;failure=1e-6
    cap=math.ceil(2*mean+math.log(1/failure))
    logs=[math.lgamma(ntrials+1)-math.lgamma(i+1)-math.lgamma(ntrials-i+1)
          +i*math.log(prob)+(ntrials-i)*math.log1p(-prob)
          for i in range(cap,ntrials+1)]
    largest=max(logs);tail=math.exp(largest)*sum(math.exp(x-largest)for x in logs)
    mgf_bound=math.exp((math.e-1)*mean-cap)
    assert tail<=mgf_bound*(1+1e-10)and mgf_bound<=failure
    tails.append({'trials':ntrials,'mean':mean,'cap':cap,'tail':tail,'mgf_bound':mgf_bound})
report['row_cap_six_cases']=tails
report['scope']='finite diagnostics only'
report['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
outpath=Path(__file__).with_name('BIASED_RESET_CHECKS.json');outpath.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS finite diagnostics','output':str(outpath),'script_sha256':report['script_sha256']},indent=2))
