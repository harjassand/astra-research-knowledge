# Final hostile audit: biased global readouts, conservation twirl and dressing

Auditor, 8 November 2026. No additional agent used; no frozen report changed.

Reviewed snapshots (copies in `reviewed/`):

- `principal/BIASED_GLOBAL_READOUT_CLOSURE.md`, SHA256
  `9f8ae0f5fc319b150fbaccbcf07d221fafb0e730673ce7cf80ad7f0180adde38`.
- `principal/CONSERVATION_TWIRL_AND_DRESSING.md`, SHA256
  `6648e4f44cc6ea4819292c84d7a31a46b95fc41fda68cfdd67787ba485b88f6f`.
- Component audit: `BIASED_RESET_REVIEW.md`, SHA256
  `e2c0bc9704c4859988cae0b6f20f429fd7bf68af967a002a8f4e0d068b4c0480`.

**Verdict: PASS at the exact stated scopes.** Physical-support smoothing supplies
the missing operation, the all-support Hermitian-product costs close, global
conservation suffices by a constructive local twirl, and the limited dressing
corollaries are valid. No central mathematical gap was found. These are
substantive mathematical checks, not worst-case execution, practical performance
or priority verification. No relative probability or full-output sampler follows.

## 1. Moving-weight estimate and its input-side dual

Use the component construction's KMS-orthonormal Hermitian product basis and
weight W. Reserve half the reset noise, allocate gamma/(2d) at each block site,
and choose a fixed rational

    theta<=min(1/(2k),gamma/(32 d k C_k J)), C_k=2^(k+1),
    alpha(u)=min(gamma u/2,theta).

The local coefficient commutator is skew in KMS two-norm, and conjugating it
by exp(alpha W) creates a symmetric part bounded by
`C_k J sinh(k alpha)`. The half-noise damping absorbs this. Differentiating
`exp(alpha(v)W) S_(length v) X` adds `(alpha'-gamma/2)W<=0`. Consequently

    ||exp(alpha(u)W) S||_(2sigma->2sigma)<=1.           (A1)

This works for arbitrary bounded time order. The corner at t0=2theta/gamma
is handled by continuity.

Reset is a KMS orthogonal projection, hence self-adjoint there. A reference-
commuting Hamiltonian has KMS adjoint -H. The adjoint of a WHOLE interval
reverses chronology as well. Apply (A1) to that reversed, sign-reversed allowed
schedule and take adjoints. This proves

    ||S exp(alpha(u)W)||<=1,
    ||S X||_(2,sigma)<=||exp(-alpha(u)W)X||_(2,sigma).   (A2)

The second line follows by inserting Y=exp(-alpha W)X in the first. It does
not require X to have homogeneous weighted degree. The needed estimates are
on the exact propagator; no exponential-sized matrix is computed algorithmically.

## 2. Ordinary physical Bloch support: the new suppression is correct

Let A=n_x X+n_y Y+n_z Z, |n|=1, be an ORDINARY traceless Hermitian unitary.
Write z=2p-1, a=Tr(sigma A)=z n_z, and B=A-aI, orthogonal to I in KMS
two-norm. Schatten Holder gives `||A||_(2,sigma)<=||A||inf=1`. Therefore

    ||exp(-alpha W_i) A||_(2,sigma)^2
       =exp(-2alpha)||A||_(2,sigma)^2+(1-exp(-2alpha))a^2
       <=z^2+(1-z^2)exp(-2alpha).

For 0<=alpha<=1/2, `1-exp(-2alpha)>=alpha`; this follows from concavity
and the nonnegative endpoint values of `1-exp(-2alpha)-alpha`. Also
`1-z^2=4mu(1-mu)>=2mu`. Thus the last expression is at most
`1-2mu alpha<=exp(-2mu alpha)`. Both the label semigroup and weighted norm
tensorize. For a product P of r ordinary Bloch unitaries, identity elsewhere,
(A2) now proves

    ||S P||_(2,sigma^m)<=exp(-mu alpha(u) r).           (A3)

The nonzero weighted identity components are included in this inequality.
They are not silently removed. Faithfulness bounds them, which is the actual
new operation. The result is compatible with the nonzero stationary product
mean. The sigma-centered bounded-mixture shortcut remains false: for
O=|0><0| and p>1/2, `|Tr(sigma O)|+||O-Tr(sigma O)I||=2p>1`.

## 3. Support-sensitive HC and exact chronology

Put lambda=mu theta. From the audited primary weighted-HC import,
`c_sigma>=mu` is a safe rate. A fully rational choice is

    b=max(1,ceil(log_2(4m/(mu lambda r)))), s=b/(mu gamma).

Then q=1+exp(b)>=4m/(mu lambda r), and log(mu^-1)<=mu^-1 implies
`mu^(-m/q)<=exp(lambda r/4)`. Therefore
`s=O_mu,theta((1+log(m/r))/gamma)` suffices.

For T>=s+t0, use the actual Heisenberg decomposition

    Phi_(0,T)P=Phi_(0,s)(Phi_(s,T)P).

Apply (A3) on the LATER interval [s,T], with alpha=theta; apply the early
weighted 2-to-q-to-infinity bound afterward. The restricted operator norm is
at most exp(-3lambda r/4). This uses no commuting of drive intervals or
replacement by a correlated source at time T-s.

Ordinary local Lindblad truncation around the physical support pays operator
error eta and retains

    m<=min(n,C r[1+JT+log((r+1)/eta)]^2).

Any conservative on-site gamma term in the LR constants is absorbed in the
fixed rate-ratio constant C. Disconnected supports use their actual occupied
coordinates, not a huge enclosing rectangle. Together these prove the
principal's suppression inequality (3), independent of the initial source.

## 4. All branches have polynomial bit costs

Define `Q=2+B+n+ceil(1/epsilon)+ceil(log(2/delta))`, with binary T and all
drive/rate/source/readout data in B. The all-input entropy cutoff to sigma^n
is applied FIRST. Its answer for a general product is
`product_i Tr(sigma O_i)`, not necessarily zero. In every other branch
`JT=O_mu,g(log Q)`. For a homogeneous-product call at accuracy xi, take
L=ceil(log_2 Q) with the actual xi and confidence request included. Localize
at eta=xi/100; then m/r<=C L^2 and gamma(s+t0)=O_mu,g(log L).

* **Large support, sufficiently late:** for
  `r>=C lambda^-1 log(100/xi)` and T>=s+t0, zero is within xi using the
  localization/suppression bound. The nonzero stationary mean is already
  bounded by that same operator estimate.
* **Early/direct global buffer:** if T<s+t0, m may be n. Choose factorial
  parameter Lambda=O(log Q) and strip margin O(Lambda/log Lambda). Its row
  reset mean is O(b_strip gamma T)=O(L), and a cap of
  `O(b_strip gamma T+log(m/xi))=O(L)` fails with per-sample probability
  xi/100. A row, INCLUDING all retained reset registers, has dimension
  `4^O(b_strip)2^O(L)=Q^O(1)`. Crossing nuclear growth is
  `exp(O_k(b_strip JT))=exp(O(L))`. Gate/compression counts are polynomial
  in m<=n, inverse accuracy and dimensionless action, so their logarithms
  are O(L). The constructive MPS cap and arithmetic remain polynomial.
* **Small support, later:** otherwise r=O_mu,theta(log(1/xi)). The expansion
  has at most 4^r F-basis terms. Weighted two-norm<=1 bounds coefficient
  one-norm by 2^r, and initial tilted norm by exp(theta r). All are
  polynomial. The localized volume is O(L^3). The audited sparse engine
  admits these polynomial initial budgets, retaining polynomially many
  coefficients of weight O(log Q). Their nonunitary factor norms and
  weighted coefficient one-sum are explicitly paid. The early HC buffer
  lasts O_mu(log m)/gamma=O_mu(log L)/gamma and closes as in the direct case.

This correctly reopens the estimates instead of substituting growing r into
an old fixed-support complexity exponent. Exponents may be huge functions
of mu and J/gamma; they do not grow with r,n or confidence. In particular,
the global short buffer does not require its volume to be polylogarithmic.

The cap failure must remain an accuracy bias xi/100 per sample, not a demand
that all repeated histories obey the cap with probability 1-delta. The latter
would exponentiate confidence digits in row dimension. The reviewed
construction uses the correct bias rule. The eta-scaled dyadic rounding rule
from the component audit remains necessary. All finite categorical choices,
purifications, algebraic local matrices, gate updates, SVD errors and overlap
ratios are paid. Schedule intervals contribute polynomial overhead, never
inverse-minimum-interval cost. Binary-time numerical polynomiality follows
because S0T is bounded in the nontrivial branch and rational entries retain
only their paid input heights; this does not shorten physical experiments.

## 5. Ordinary bounded mixture and confidence

Every O_i has its ORDINARY decomposition

    O_i=a_i^0 I+beta_i A_i, beta_i>=0, |a_i^0|+beta_i<=1.

Choose identity, ordinary A_i or zero with these bounded probabilities and
track identity signs. Each nonzero sample is precisely a product covered by
(A3), without a sigma-centered one-norm penalty. Approximate beta downward
and each Bloch axis by an exactly rational unit vector in a bounded
stereographic chart. Tracelessness and unitarity then hold exactly; one-site
errors O(epsilon/n) telescope to a paid total error.

A bounded outer average with O(epsilon^-2 log(1/delta)) samples, clipped
inner answers, and conditional inner failure budgets summing to delta/2
proves the confidence claim. A charged classical input mixture can share the
same outer sample. There is no exponential coefficient expansion at global
readout level and no inverse-rare-outcome denominator claim.

## 6. Global conservation is enough: local twirl PASS

For common biased sigma, p unequal to 1/2, sigma^n has distinct eigenvalues
on the different eigenspaces of total excitation Q=sum_i |1><1|_i. Thus
`[H,sigma^n]=0` iff `[H,Q]=0`. Let T be averaging over exp(i phi Q).
On a local block H_b, conjugation by the outside factor cancels; consequently
T(H_b) equals the local charge twirl, obtained by deleting matrix entries
between distinct local excitation numbers. This is rational, Hermitian,
support preserving and norm contractive. Incidence/range and J bounds do
not increase. By linearity,

    sum_b T(H_b)=T(H)=H

whenever the total H conserves charge. Hence per-block conservation is an
efficiently constructible representation, not a stronger physical assumption.
At p=1/2 the reference is uniform and no charge condition is needed.

Every block has fixed dimension 2^k, so this preprocessing costs polynomial
bits and operations for the explicit schedule. The global conservation
promise can also be checked without a 2^n matrix: expand the local differences
H_b-T(H_b) into their fixed-size Pauli dictionaries, merge labels and check
exact rational cancellation. No conservation oracle is required.

## 7. Fixed-depth dressing: PASS at the stated limited readouts

For an explicitly known fixed-depth bounded-range circuit V, conjugate the
ENTIRE generator, including every reset map. The physical reference is then
V sigma^n V^dagger, and the source becomes V^dagger rho_product V. This is
a paid constant-depth prepared input in the undressed frame. A fixed-local
physical observable becomes a constant-support observable. Its preparation
cone and O(b depth(V)) crossing action fit the audited buffer construction.
Gate entries/evaluation costs must be explicitly supplied. This is numerical
unitary covariance, not free physical control or reservoir engineering.

If V is Clifford, a physical global Pauli maps to a signed global Pauli.
A product-Pauli-basis projector maps to a product of commuting factors
`(I+/- S_i)/2`. Sample each factor as I or +/-S_i at probability one half;
their product is another computable signed Hermitian Pauli. Thus a bounded
outer mixture transfers these projectors without a 2^n expansion. The same
argument covers bounded one-axis Pauli factors. Arbitrary axes after a general
dressing have no such automatically bounded Pauli/LCU norm in this proof.

V sigma^n V^dagger is Gibbs for the stated commuting local reference
Hamiltonian when sigma is its one-spin thermal factor. It is generally not
Gibbs for VHV^dagger. The qualification prevents promotion to a generic Gibbs
solver. No implementation or microscopic-bath cost is acquired here.

The earlier paid source transfer also works: classical generators of products,
optionally followed by a 2D circuit of depth O(log log Q_bin), add an exact
preparation cone, O(ell) strip margin and O(b ell) crossing action. Reset
registers occur only in the noisy region, not in a passive preparation shell.
High-support suppression itself is source independent. The depth bound must
use Q_bin rather than an enormous numeric T if absolute rates vary.

## 8. Diagnostics and final scope

`biased_global_checks.py`, SHA256
`436fca201cf3bb6c432f366b0dca7606a817e8cc1bb6245a657f5bcf7f49bf3f`,
and `BIASED_GLOBAL_CHECKS.json` independently check 36 bias/rate/time settings,
both moving contractions and 576 ordinary physical-support products, including
their nonzero weighted identity components and mu=0.01. All pass at numerical
precision. The proof above, rather than finite cases, establishes uniformity.

The combined checked result is all-time additive global Hermitian-product
prediction for 2D faithful biased resets and globally charge-conserving local
Hamiltonians, with the stated explicit descriptions and optional paid source
and limited dressing transfers. It excludes arbitrary work drives, mu=0,
uniform weak-noise degree, generic Gibbs(H), arbitrary correlated source
access, rare relative probabilities and full-output TV sampling. Those
boundaries are preserved, not inferred away by this closure.
