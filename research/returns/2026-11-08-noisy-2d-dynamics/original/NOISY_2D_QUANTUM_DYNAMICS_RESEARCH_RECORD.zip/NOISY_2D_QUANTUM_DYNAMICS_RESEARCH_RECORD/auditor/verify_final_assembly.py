"""Verify assembly integrity; mathematical review remains FINAL_DOSSIER_REVIEW.md."""
from pathlib import Path
import hashlib,json,re

base=Path(__file__).resolve().parents[1]
doc=base/'principal/DOSSIER_DRAFT.md'
raw=doc.read_bytes();text=raw.decode()
manifest=base/'principal/DOSSIER_COMPONENT_PINS.json'
ledger_path=base/'principal/THEOREM_LEDGER.json'
pins=json.loads(manifest.read_text());ledger=json.loads(ledger_path.read_text())
format_path=base/'principal/FORMAT_DELTA.json'
format_changes=json.loads(format_path.read_text())['changes']
format_counts=[0 for _ in format_changes]
headers=list(re.finditer(r'^## Proof component (\d+):[^\n]+\n\nSource:[^\n]+\n\n',text,re.M))
rows=[]
for i,(pin,header)in enumerate(zip(pins,headers)):
    data=(base/pin['path']).read_bytes();body=data.decode();selection='entire source'
    if pin['path']=='initial/constructor.md':
        body=body[body.index('## 3. Formal sampling theorem'):body.index('## 7. Primary-source comparison')]
        selection='Sections 3 through 6'
    expected=re.sub(r'^(#+)(?= )',r'##\1',body,flags=re.M).strip()
    for j,change in enumerate(format_changes):
        format_counts[j]+=expected.count(change['before'])
        expected=expected.replace(change['before'],change['after'])
    end=headers[i+1].start()if i+1<len(headers)else text.index('## Existing machinery, exact predecessors and novelty audit')
    assembled=text[header.end():end].strip()
    rows.append({'component':i+1,'path':pin['path'],'selection':selection,
                 'pin_matches':hashlib.sha256(data).hexdigest()==pin['sha256'],
                 'body_matches_modulo_heading_level':assembled==expected})

reviews=[]
pattern=r'^- (?:\[([^\]]+)\]\([^\n]+?\)|`([^`]+)`) — SHA256 `([a-f0-9]{64})`'
for linked,code,sha in re.findall(pattern,text,re.M):
    rel=linked or code
    reviews.append({'path':rel,'pin_matches':hashlib.sha256((base/rel).read_bytes()).hexdigest()==sha})

prefix=text[:text.index('## Review files')].encode()
extra=base/'constructor/BIASED_GLOBAL_REVIEW.md'
report={'scope':'assembly integrity only; analytic conclusions are in FINAL_DOSSIER_REVIEW.md',
        'dossier':{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),
                   'prefix_before_review_index_bytes':len(prefix),
                   'prefix_before_review_index_sha256':hashlib.sha256(prefix).hexdigest()},
        'component_manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),
        'format_delta_sha256':hashlib.sha256(format_path.read_bytes()).hexdigest(),
        'format_counts':format_counts,
        'ledger_sha256':hashlib.sha256(ledger_path.read_bytes()).hexdigest(),
        'ledger_entries':len(ledger['entries']),'components':rows,'review_file_pins':reviews,
        'pending_constructor_global_review_sha256':hashlib.sha256(extra.read_bytes()).hexdigest(),
        'all_components_pass':len(rows)==len(pins)==len(headers)==13 and all(x['pin_matches']and x['body_matches_modulo_heading_level']for x in rows),
        'all_review_pins_pass':len(reviews)>=10 and all(x['pin_matches']for x in reviews),
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
assert report['all_components_pass']and report['all_review_pins_pass']and report['ledger_entries']==34
assert format_counts==[x['count']for x in format_changes]
(base/'auditor/FINAL_ASSEMBLY_CHECKS.json').write_text(json.dumps(report,indent=2)+'\n')
(base/'auditor/reviewed'/('DOSSIER_DRAFT_'+hashlib.sha256(raw).hexdigest()[:12]+'.md')).write_bytes(raw)
print(json.dumps({k:v for k,v in report.items()if k not in ['components','review_file_pins']},indent=2))
