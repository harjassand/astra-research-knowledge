# Positive composition: nonlocal syndrome sampling and encoded-algebra tomography

Auditor, 8 November 2026. These are proved linear-algebra consequences of the
audited all-support product-readout theorem, including its explicitly bounded
prepared/generated-input and driven extensions. They do not use the biased
reset local-observable theorem as a global-readout premise.

Let Q be the complete binary resource including n, input descriptions,
inverse target error and confidence digits. Let r<=C log_2 Q for a fixed C.

## Nonlocal parity/syndrome distribution

Supply an explicit binary r by n matrix F. On a computational-basis output
x, define the r parity bits y=Fx mod 2. For every s in {0,1}^r,

    mu_s=E[(-1)^(s dot y)]=Tr(rho_T Z_(F^T s)).

The physical observable is an arbitrary global Pauli product, so each moment
has a polynomial additive evaluator. Set mu_0=1 exactly. Estimate the other
2^r-1 moments to eta=epsilon/(32*2^r), with total failure probability at most
epsilon/4 for an unconditional TV sampler (or a separately requested delta
for a high-confidence explicit distribution table). Walsh inversion gives

    p_tilde(y)=2^-r sum_s (-1)^(s dot y) mu_hat_s.

It is rational and sums to one. On the valid estimation event,
`||p_tilde-p||_1<=2^r eta<=epsilon/32`. Clip negative entries and normalize.
For a trace-one real table, the negative mass is at most half its l1 distance
from the true probability table; clipping/normalizing changes it in l1 by
twice that negative mass. Thus the normalized table has l1 error at most
epsilon/16. Finite-bit sampling adds a separately paid TV error, say
epsilon/8. The bad estimation event contributes at most epsilon/4 to the
unconditional TV distance. This gives a bounded-work TV sampler with total
error below epsilon. The number of moments, their inverse precision, table
size, Walsh arithmetic and all confidence digits are polynomial in Q.

These syndrome bits can be supported across the entire lattice; they need
not be outcomes on a spatially small subsystem. There is no claim of an
n-bit sampler when r is linear in n. A rare syndrome outcome still need not
have a relative-error estimate. For a promise p(event)>=p0, a conditional
version pays inverse p0 by requesting proportionally smaller absolute error.

## A logarithmic quantum register defined by global Pauli generators

More generally, supply physical Pauli strings X_j,Z_j for j=1,...,r obeying
the canonical logical commutation relations: X_j anticommutes with Z_j,
all other pairs commute, and every generator is Hermitian and squares to I.
Their products define a unital *-embedding of the r-qubit matrix algebra into
the n-qubit physical algebra. The physical state restricts to a legitimate
r-qubit density matrix rho_logical, without constructing a decoding circuit.
Every logical Pauli is a readily computed signed physical Pauli string.

Estimate its 4^r moments to eta=epsilon/(32*2^r), setting identity exactly.
The reconstructed trace-one Hermitian matrix obeys

    ||rho_tilde-rho_logical||_2<=2^(r/2)eta,
    ||rho_tilde-rho_logical||_1<=2^r eta.

Remove negative eigenvalues and normalize. As for the probability table, this
changes trace norm by at most the original trace error; a certified approximate
eigendecomposition is performed at polynomial dimension 2^r with paid normwise
error. Hence a physical r-qubit density matrix within trace error epsilon is
computable with high confidence in polynomial bit work. This permits any
subsequent explicitly specified bounded readout on that small matrix.

This is tomography of the supplied Pauli operator algebra. It is not a claim
that an error-correcting recovery channel has been performed or predicted:
an error-corrected observable can be a syndrome-dependent sum outside this
single algebra. Arbitrary unacquired correlated sources remain excluded, and
the rare-probability obstructions in AMBITION_REVIEW.md remain intact.
