# Whole-block Cayley buffer simplification

Auditor, 8 November 2026. A separate strengthening of the reviewed buffer
implementation; `BIASED_RESET_REVIEW.md` remains unchanged at its reported hash.

For a k-qubit Hermitian block H of norm at most J, set

    U_h=(I-i hH/2)(I+i hH/2)^(-1).

Then `U_h-I=-i hH(I+i hH/2)^(-1)`, so `||U_h-I||<=|h|J`.
In the normalized physical Pauli expansion, Cauchy--Schwarz gives

    ||coeff(U_h-I)||_1<=2^k||U_h-I||_(2,tau)<=2^k J|h|.

Thus the sum of absolute Pauli coefficients of U_h is at most
`1+2^k J|h|<=exp(2^k J|h|)`. Across every spatial bipartition each Pauli
summand is a product unitary. Nuclear/operator matrix triangle inequalities
therefore give

    N_cut(U_h psi)<=exp(2^k J|h|) N_cut(psi).

Gates wholly on one side preserve the nuclear norm exactly. Summing only the
crossing block actions yields the same `exp(O_k(b_strip Jt))` buffer bound.
The Pauli expansion of a single block has at most 4^k terms, hence an MPO of
bond at most 4^k; applying it increases an MPS bond by only that fixed factor.
Its physical entries are rational and the expansion is performed once per
fixed-size gate, not expanded over a full Trotter layer.

For locality, U_h equals exp(-ih H_eff), where

    H_eff=(2/h) arctan(hH/2), ||H_eff||<=J.

The effective Hamiltonian is supported on the same block. No evaluation of
arctan is needed; this is a proof-only representation. Disjoint-support
colors therefore realize a piecewise bounded local Hamiltonian with total
duration at most the fixed color count times t. The factorial LR proof applies.
On-site reset SWAP toggling changes only which internal registers the block
acts on and leaves spatial support and norm unchanged.

If H commutes with its product reference then U_h and H_eff do too. Hence one
may use whole reference-preserving Cayley blocks in BOTH the sparse engine
and the reset-register buffer. The buffer need not first split the Hamiltonian
into physical Pauli rotations or lose exact finite-step reference preservation.
The split-Pauli buffer in the reviewed construction is nevertheless valid
because its channel error is separately paid. This is a simpler alternative,
not a correction to a false theorem.
