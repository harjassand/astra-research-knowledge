# Hostile challenge review and constructive conditional-probability attack

Auditor, 8 November 2026. Exchange began only after all four independent initials
were frozen. No new agent was used and no frozen initial was changed.

## Exact reviewed versions

| File under work/noisy-2d-extension-20261108 | SHA256 |
|---|---|
| initial/machinery.md | e0100982b66df8da37d46f2edd48d861f5c463c2b5e620f869399a024e80aa46 |
| initial/constructor.md | 4c6e17df225552c056d9e04ba146b33f307bea982ec7b149e3dc33372580281f |
| principal/LOCAL_ROBUST_PREDICTION.md | 6731ddc64fb4d14f1d8d8c7ca42a3385b983f6b7cb7abf16a73ae85a65d4192e |
| principal/GLOBAL_LEARNED_REUSE.md | eb44aa6c23b73c981929865839709ec10b2d7f0ca7e47327c3f50402b2b48c93 |
| initial/auditor.md | 9d927c7ff40e96b8cdd6d5599fb18d13d40e289b20af87896aebafa8f0f6e86f |

`reviewed/REVIEW_INPUTS.json` pins the reviewed files. The mutable principal
files were copied to `reviewed/` with hash suffixes. Earlier principal hashes
fd7c8dab... and 60b5c48b... were also read; the above versions add the correct
explicit inverse-rate physical-acquisition-time qualification.

**Verdict:** PASS at the exact mathematical scopes below. No central gap was
found in the global product-readout theorem, its combination with the prepared
and efficiently mixed inputs, the driven local stability/binary-horizon claims,
the extensive global perturbation bound, or the bounded-cut TV sampler.
This means substantive mathematical inspection at those scopes, not historical
priority, physical validation or execution of the general algorithms. Minor
conventions to make explicit are listed in Section 6.

## 1. Machinery's all-support product-readout theorem

### 1.1 Varying Pauli-weight smoothing: PASS

Let W multiply Pauli P by its weight and S_alpha=exp(alpha W). A Pauli
Hamiltonian term couples anticommuting partners by a real skew two-by-two block
with off-diagonal magnitude 2|h|. The two weights differ by at most k. Thus
the Hermitian part after conjugating by S_alpha has norm at most
`2|h| sinh(k alpha)`. Both partners have a nonidentity factor in the local term
support. Allocating replacement gamma/(2d) on each supported site gives local
damping at least gamma/(2d); the remaining half-noise allocation is
nonnegative. With the stated

    theta=min(1/(2k),gamma/(16kdJ)),
    alpha(t)=min(gamma t/2,theta),

one has `2J sinh(k alpha)<=4Jk alpha<=gamma/(4d)`. Therefore
`S_alpha G_half S_alpha^-1` is dissipative in normalized HS, including all
active blocks and the untouched/commuting sectors. Differentiating
`S_alpha(t) exp(tG)X` adds `(alpha'-gamma/2)W`, also nonpositive. The corner at
t0 is harmless by continuity. This proves the first contraction.

The second contraction is NOT inferred from the first by reversing S. Instead,
`G_H^dagger=G_-H`; apply the proved inequality to -H, then take Hilbert-space
adjoints to obtain contraction of `exp(tG_H)S_alpha`. This exactly yields
`||exp(tG)X||2<=exp(-alpha r)||X||2` for homogeneous weight r. In the driven
case the adjoint also reverses the schedule; the reversed sign/schedule remains
in the same bounded local class. No ensemble statement is used.

### 1.2 Support-sensitive hypercontractivity: PASS

For the stated integer b and `s=b/(2gamma)`, set `q=1+exp(b)`. Since
`exp(b)>=2^b`, `q>=8m/(theta r)`. King's correctly normalized interleaving gives

    ||Phi_s Y||inf <= 2^(m/q)||Y||2
                    <= exp(theta r/4)||Y||2.

Combine with the homogeneous-weight estimate for duration T-s when
`T>=t0+s`; the resulting `exp(-3theta r/4)` bound is valid. The localization
prefactors are at most polynomial in r (the original constants have an r^2
factor), so `R=O((J+gamma)T+log((r+1)/eta))` and `m<=C r R^2` follow with
fixed locality constants. This gives a bound on the operator norm, hence is
independent of the source state, including any allowed correlations.

### 1.3 Cost closure in both nonsuppressed branches: PASS

After global entropy cutoff, `(J+gamma)T=O(log Q)`. The support localization
satisfies `m/r<=C log^2 Q`; hence the support-sensitive buffer s is
`O(log log Q)/gamma`.

For the **direct buffer**, m can be n. This does not break the construction:
the rational channel step and gate counts are polynomial in m, inverse
accuracy, and the dimensionless action. Their logarithms are O(log Q).
Choose Lambda=O(log Q), with Lambda also bounding log(m^2/xi). Then

    JT=O(log Lambda), b=O(Lambda/log Lambda),
    log q_row=O(b), log B*=O(bJT)=O(Lambda),
    log D=O(log M_c+log B*+log(1/xi))=O(log Q).

Thus each tensor dimension, number of operations, bit precision and sample
count is polynomial. It is not necessary that the volume itself be
polylogarithmic. Empty coordinate intervals can be skipped using integer
quotients/coordinate sorting, while retaining the geometric parity of the
unskipped infinite tiling; their numeric lengths do not become site counts.

In the **low-weight branch**, `r=O_theta(log(1/xi))`. Expanding the local axes
costs at most 3^r terms, and their Pauli one-norm is at most `(sqrt(3))^r`.
Both are polynomial at fixed theta. Initial one-norm, localized m=O(log^3 Q),
update count, retained coefficient count and inverse buffer accuracy therefore
remain polynomial. This argument correctly reopens the constructive estimates;
it does not substitute a growing r into the original gratuitously huge
fixed-support exponent D_kappa. The final HS buffer has duration O(log log Q)
and closes as above. All exponents can depend on gamma/J and locality, but not
on r,n or confidence.

### 1.4 Arbitrary product Hermitian contractions and exact axes: PASS

For `O_i=a_i I+beta_i A_i`, the contraction premise gives
`|a_i|+beta_i<=1`. Thus the identity/axis/zero mixture has bounded signed
weight; no exponential coefficient one-norm is being hidden. Approximate beta
downward and the Bloch axis by an exactly rational unit vector. A
stereographic chart with `1+/- n_z>=1` has bounded coordinates; rounding them
to rational precision nu gives an exactly normalized rational axis at O(nu)
error. If beta<=nu, discard it. Otherwise computing the direction costs only
an additional O(log(1/nu)) bits. The approximated one-site operator remains a
contraction, so product error is at most the sum of local norm errors.

For direct buffers even a product of Hermitian contractions works: exact
conjugated factors commute and are Hermitian contractions, the parity overlap
identity holds, all telescoping factors have norm at most one, and on-site
insertions contract the row-cut nuclear norm. Unitary-only assertions are not
needed there. A bounded outer average, inner confidence union bound, and paid
finite-bit distribution error give the stated confidence dependence.

## 2. Strongest same-2D combination: prepared inputs, mixtures and drives

**PASS, with the following precise combined statement.** Fix a,k,d,g and a
preparation-depth constant c. Here Q is the complete binary resource
`2+B+n+ceil(1/epsilon)+ceil(log(2/delta))`; B includes binary T and the complete
source-generator/preparation/schedule descriptions. Permit an explicitly paid finite-bit classical
generator which emits a rational product source and a bounded-range 2D circuit
W of depth at most `c log(2+log Q)` (W may instead be fixed and separately
supplied). Every emitted description has polynomial length and uniformly
polynomial bit/evaluation cost. The initial state is the expectation of

    W (tensor_i rho_i) W^dagger.

Permit a supplied finite rational open-loop Hamiltonian schedule with fixed
instantaneous locality and J/gamma bounds, and an arbitrary supplied tensor
product of one-qubit Hermitian contractions. Then additive specified-mean
prediction has randomized polynomial bit work. All actual source-generation,
gate-entry evaluation, schedule, precision, random bits and confidence digits
are included. Arbitrary quantum circuit inputs, source-copy oracles and
adaptive quantum-feedback controls are not included.

Proof of compatibility: the high-weight operator-norm suppression is already
source independent. In a remaining direct buffer, use the composite history
`U W`. Localize `U^dagger P_j U` on an inner strip C_j with width margin b_U;
W's exact backward cone adds O(ell) to the surrounding strip B_j. The localized
operator is

    V_j=W_Bj^dagger U_Cj^dagger P_j U_Cj W_Bj,
    b=b_U+O(ell).

The extra truncation is exact, and V_j are Hermitian unitaries disjoint within
each parity. A fixed-arity crossing preparation gate has constant Pauli
expansion one-norm. The row-cut reference estimate becomes

    log B*=O(b(Jt+ell)).

Here `ell=O(log log Q)`, `Jt=O(log log Q)` and
`b=O(log Q/log log Q+ell)`, so log B*=O(log Q). This is valid when the buffer
volume is n as well as when it is localized.

In the low-weight sparse branch, localize noisy dynamics to S and keep the
exact W preparation cone S+ as a passive representation shell. Its volume is
`O(r(R+ell)^2)=O(log^3 Q)`. Sparse propagation and smoothing still act only on
S; their operator-norm error is valid against its correlated source. Apply the
same composite-buffer construction on S+. No noise-free physical ancilla was
added. The generated input mixture and bounded readout mixture may be sampled
jointly in one outer estimator; each exact signed conditional mean is bounded
by one, so ordinary Hoeffding plus summed inner failures suffices.

**Binary-horizon strengthening:** omit numeric 1+T from Q and instead put its
binary description in B. First apply the global entropy cutoff; the equilibrium
answer for a general product is `tau(O)=product_i Tr(O_i)/2`. In the remaining
branch, `gamma T=O(log(n/epsilon))` and `JT=O_g(log Q)`. All channel counts use
these dimensionless actions. Rational factors involving an enormous T still
have only its paid binary height. Repeating the preceding cost argument with
this Q proves polynomial numerical bit work in the binary horizon. The input
preparation-depth cap must be defined using this Q: allowing depth
O(log log T) for an exponentially large numeric T at an exponentially small
absolute gamma could permit depth O(log B), for which the current proof does
not guarantee polynomial work in B. At fixed absolute physical rates the
nontrivial-time cutoff removes that distinction. This does
not speed up a physical acquisition experiment of duration proportional to
1/gamma.

## 3. Principal local relaxation, robustness and binary time

**PASS for Sections 2--6 of LOCAL_ROBUST_PREDICTION.** The entropy proof via
convexity and quantum Shearer is valid for arbitrary correlated sources and
bounded time-dependent H. Applying the restricted-volume trace-distance bound
to every source density matrix proves an operator-norm local relaxation bound;
no computable representation of the arbitrary density matrix is required in
that analytic step. The chosen R(x) makes the locality error at most exp(-2x),
and its volume is polynomial in x. The stated A bounds the entropy prefactor.

For local perturbations, B_z annihilates every observable supported outside its
support, by locality and B_z(I)=0. Near terms are bounded by
`eta N0 A(1+x)^3 exp(-x/2)`. Summing distant shells gives the displayed
`eta B(1+x) exp(-2x)`: use `K exp(vx-R/(2a))<=exp(-2x)`,
`sum rho^j<=3a`, and `sum j rho^j<=9a^2`. The integrals are exactly 158 and
3/4, so `K_stab=158N0A+B` is conservative. Duhamel correctly places the
reference future next to B_z and the perturbed physical propagator outside.
Only the latter's operator-norm contractivity is used; perturbed unitality or
mixing is not assumed. The result is a floor O(eta/gamma), not arbitrary
precision simulation of a genuinely nonunital process.

The product-source telescope is valid and pays each local difference with
`||Phi O-E_i Phi O||`; the near/far estimates give K_prep as stated. It cannot
be applied to arbitrary correlated errors known only by one-site marginals.

For the classical drive extension, the input-side early buffer has the correct
chronology. The per-segment step rule has total
`O(M+S0T+S0^2T^2/eta_s)`; tiny intervals do not force inverse-smallest-step
cost. Local relaxation permits an epsilon-only time cutoff and localized volume
independent of n before running the numerical dynamics. Input reading/indexing
and all schedule bits remain charged. Binary-horizon numerical polynomiality
therefore follows at the exact fixed-local scope.

## 4. Principal global learned-reuse bound

**PASS at the extensive, all-time scope.** For every global Hermitian
contraction O, the all-input entropy bound gives

    ||Phi_(s,t)O-tau(O)I|| <= f(gamma(t-s)),
    f(x)=min(2,sqrt(2n log 2) exp(-x/2)).

With M discrepancy maps of norm eta annihilating identity, Duhamel gives
`M eta/gamma` times the integral of f. Split at `x0=2log(2n)`: the first
piece is at most `4log(2n)` and the tail is
`2sqrt(2n log2)/(2n)<=2`. Thus the claimed `[4log(2n)+4]` is safe. The bound
is uniform over time and allowed drives, and independent of the source state;
it has an extensive M dependence. With Hamiltonian coefficient errors alpha,
sum discrepancy is at most `2Mpar alpha`, so choosing
`alpha=O(gamma epsilon/[Mpar log(2n)])` pays a global product readout's model
error by the stated polynomial acquisition protocol. It does not acquire a
full many-body state or prove a TV sampler.

The reviewed current versions now explicitly charge physical acquisition time
with its 1/gamma scaling when absolute rates are variable binary inputs. This
is necessary: polynomial bit work for an enormous simulated horizon is not a
claim that the actual experiment runs in that many bit operations.

The local volume-independent constants cannot be silently reused for global
preparation or readout uncertainty. At T=0 take the all-zero product projector,
rho=|0><0|^tensor n and independently perturbed one-site states
`sigma_i=(1-zeta/2)|0><0|+(zeta/2)|1><1|`. Each one-site trace error is zeta,
but the global mean changes by `1-(1-zeta/2)^n`. Similarly replacing each
readout factor I by `(1-nu)I` changes its product mean by `1-(1-nu)^n`.
The extensive global generator bound above is the one actually proved; I do
not claim it is optimal or that every special product-readout generator error
necessarily has this volume dependence.

## 5. Constructor bounded-cut TV theorem

**PASS at its supplied-cut architecture and TTN-input scope.** A crossing Pauli
rotation has an operator TTN of bond two on its Steiner subtree, independent
of the subtree's length. Applied to a bond-D TTN it uses intermediate bond at
most 2D. The input Schmidt nuclear norm is at most sqrt(D0), and the certificate
gives integrated crossing action at most cJT at every tree edge. On-site
random-unitary noise preserves each cut norm. Thus
`B*<=sqrt(D0)exp(cJT)` uniformly over histories and intermediate times.

Canonical tree sweeps compress an actual edge Schmidt decomposition without
increasing other bonds. The original constructive truncation inequality applies
to every edge, giving polynomial cap from the paid O(nG) compressions. Gap-free
normwise diagonalization and singular-value thresholds suffice; no inverse
tiny Schmidt value is requested. Initial rational TTN contractions, finite
channel factors, conditional probabilities and rounded categorical choices
all have polynomial bit height at the paid bond dimensions.

Uniform vector error per history implies trace-distance/TV error, and averaging
histories preserves it. Exact rational TTN sampling and local rational POVM
effects need no rare-outcome denominator lower bound: the actual rational
conditional ratio is computed, rather than approximated from absolute oracle
estimates. The entropy cutoff keeps JT=O_g(log(n/epsilon)); hence exp(cJT) is
polynomial at fixed c,g. A generic 2D grid does not have the supplied bounded
cut certificate. This theorem cannot be relabelled a generic 2D sampler.

## 6. Minor statement conventions and implementation boundary

No mathematical blocker was found. For a clean consolidated theorem:

1. A perturbation's assigned lattice center should lie in its support, or its
   support should explicitly lie in the stated bounded-radius ball around
   that center. Diameter alone with an arbitrarily assigned distant label
   would not justify shell counting.
2. Perturbation infinity norms are norms after tensoring by the identity on
   the complement, or a completely bounded norm bound is supplied. The local
   finite-dimensional extension factor can alternatively be explicitly paid.
3. Equilibrium traces use actual supplied support size, or identity padding.
4. For polynomial acquisition counts choose the short experimental t equal to
   the displayed rational minimum, or within a fixed factor of it; merely
   allowing arbitrarily smaller t would not itself imply a polynomial shot
   count. The explicit minimum is always available and repairs the wording.
5. General numerical algorithms and certified SVD/TTN implementations are
   mathematically costed, not executed at their worst-case resource bounds.

## 7. Decisive rare-conditioning attack: a true obstruction for mixed inputs

**New proved reduction:** uniform arbitrary rare-conditional/log-marginal
prediction cannot accompany the efficient-generative-mixture input extension
unless NP is contained in BPP. This does NOT obstruct full TV sampling.

Given a Boolean formula f on n bits, sample n independent uniform bits z and
an independent uniform bit b. Output a computational-basis product state on
registers z, A=b and F, where

    F=1 iff (b=0 and z=0^n) or (b=1 and f(z)=1).

This is an explicit polynomial-time finite-bit generator of a separable
classical input mixture. Use W=I, H=0, gamma=J=1 as declared class bounds, and
place the registers on an ordinary 2D region. If N is the number of satisfying
assignments, initially

    p=Pr(F=1)=(1+N)/2^(n+1)>0,
    a=Pr(A=1,F=1)=N/2^(n+1),
    Pr(A=1|F=1)=N/(1+N).

Thus SAT gives conditional probability at least 1/2, while UNSAT gives zero.
The postselection and readout are each a single physical bit; the rarity is in
the supplied correlated source, not in an uncharged quantum experiment.

The obstruction also survives strictly positive replacement time with a binary
description: choose `T=2^(-4(n+2))`. At H=0 each measured computational bit flips
independently with `q=(1-exp(-T))/2<=2^(-4n-9)`. Coupling the A,F pair before
and after noise gives TV at most 2q. Since `p>=2^(-n-1)` and p is positive,
the conditional changes by at most `8q/p<=2^(-3n-5)<=1/32`. Hence a uniform
conditional estimator of accuracy 1/16 distinguishes the cases by threshold
1/4 with bounded error, putting SAT in BPP.

Likewise a relative estimate of accuracy 1/10, or an additive estimate of
log Pr(F=1) of accuracy 1/10,
distinguishes UNSAT's probability near `2^(-n-1)` from SAT's probability at
least nearly `2^(-n)`. The small q perturbation cannot bridge that factor-two
gap. Therefore an all-input/all-horizon log-marginal theorem cannot be the
missing universal operation for the combined mixed-source class.

In contrast, the full distribution of this H=0 family is easy to sample:
run the given generator and add independent known bit flips, with finite-bit
approximation charged. A TV sampler need not resolve the rare F=1 branch.
This explicitly separates full TV sampling from relative rare marginals and
prevents incorrectly turning the conditional hardness into a sampling lower
bound. It also leaves the original product-input full-sampling problem open.

## 8. Constructive composition attempt toward an original-2D TV sampler

The local replacement probability floor proved in the independent initial
does help fixed-local instruments after a constant time. It does not compose
into global prefix control. After i observed output bits, the relevant event
has support i and may have probability 2^-i even when every one-bit marginal
and every actual one-bit conditional is 1/2. The exact uniform product output
already gives that example within the original model. Substituting
epsilon*p_prefix into the additive global product evaluator gives exponential
cost; the probability floor applies before conditioning, not to an arbitrary
posterior source. The SAT reduction shows a real stronger obstruction once
generative classical correlations are admitted.

A constructive route still worth attacking for the ORIGINAL product-source
class is a continuous physical-time connected-polymer representation with
direct log-marginal or positive generative control. A cardinality-O(log Q)
connected physical cluster could in principle have its weight evaluated by
the new global product evaluator without building an enormous enclosing box.
However, no exact factorization/connected-weight bound has been proved here.
Factorial LR tails give approximate locality, whereas the discrete sampler's
polymer factorization uses exact finite-depth causal separation. Moreover the
new exponential Pauli-weight smoothing saturates at theta=O(gamma/J), which
alone need not beat the number of connected geometric clusters. Neither
operation currently proves Kotecky--Preiss convergence uniformly in time step.

This is a specific missing operation, not a generic call for more work:
derive exact or certified summable continuous-time connected activities whose
absolute weighted sums satisfy a polymer convergence criterion and whose
finite-bit evaluation cost remains polynomial after a size truncation. Any
relative/log-marginal version must retain its product-source and time regime;
the SAT example prevents promoting it to arbitrary efficient input mixtures.
No failed construction is being called a hardness theorem. The all-ratio,
all-time full TV sampler for arbitrary 2D product-input dynamics remains
**OPEN in this review**.

## 9. Finite diagnostics and completion scope

`post_exchange_checks.py` (SHA256
`1a7d9c7edd3ee8bfb54d4c99b8a42484bc682481c5c99cf11fc51b402da428a4`)
and `POST_EXCHANGE_CHECKS.json` independently check 20 interacting three-qubit
weighted-smoothing cases, both left and right contractions and all homogeneous
weight sectors; 18 explicit SAT-flag/noisy-conditional cases through 80 latent
bits; and five exact global stability-integral comparisons. All pass. These
are diagnostics for signs, normalization and rare-denominator algebra. The
uniform results rest on the proofs above, not those finite cases.

Review completion: substantive PASS for the five stated construction/robustness
claims at their actual scopes; proved combined theorem and new rare-conditional
obstruction; a concrete continuous-time connected-activity operation remains
open. Frozen initials and unrelated/published work were preserved.
