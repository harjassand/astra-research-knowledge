# Audit of the original-class rare-probability reductions

Auditor, 8 November 2026. Reviewed `initial/ambitious.md`, SHA256
`313fbcf6e47519842f82cbd7e4a7cefaaee8d0e211306bf247599b0bebc711b5`.
This review was performed after the reset construction review. No frozen
report was modified and no new agent was used.

**PASS for Theorems A and B at their exact three-/four-body, tiny-positive-time,
logarithmic/relative-probability scopes.** No central gap was found. Their
full-TV sampler remains open. The CP counterexample to the printed TC Lemma 3
ingredient is also valid; the correction to comparator wording is substantive.

## 1. Three-body commuting construction

Starting from |0><0|, a matrix-unit word reaching |1><1| must flip every one
of the 2n ket/bra coordinates an odd number of times. Each Hamiltonian
multiplication flips three coordinates on exactly one side; a Pauli noise
conjugation flips at most two. For n=3m no word of length below 2m can
contribute. At length exactly 2m all factors must be Hamiltonian and every
coordinate flips once. Ket and bra terms therefore form exact tilings, with
no noise or identity factor present. The leading coefficient is precisely
q_R^2: the m! orderings of a disjoint ket tiling and the corresponding bra
orders/interleavings cancel the exponential denominators. The phases cancel
between the two sides. The density-matrix word proof does not commute noise
through the Hamiltonian.

The norm bound C>=2M+2gamma n is conservative. For t<=1 the tail after degree
r is at most `exp(C)t^(r+1)`; factor t^(r+1) out of the entire norm-majorized
series, not C^(r+1) out of a single term. With `t=2^(-2C-20)`, the scaled
remainder is at most 2^-20 because exp(C)2^-2C<1. C is O_gamma(n), so t has
O_gamma(n) bits and r log t has magnitude O_gamma(n^2). The specified log
gap and its threshold are computable with polynomial bit work.

Strict positivity is correctly established by exactly one X jump per site
and no other Pauli jumps. That event has positive probability
`exp(-3gamma nt/4)(gamma t/4)^n`. All those X jumps commute with this H,
and the residual diagonal return amplitude is at least 1-Mt. Thus the hard
no-tiling instance has no zero-log convention. The same event bounds log
probability below by a polynomial-magnitude negative quantity.

I inspected the cached primary Moore--Robson text. Section 3 and the completion
of Section 3.2 prove NP-completeness for rotated right trominoes on finite
square-lattice regions; holes are allowed. The paper explicitly does not claim
the counting theorem for that single tile. Section 2 does explicitly supply
the parsimonious circuit/SAT reduction for right tromino plus square tetromino.
These are the exact imports used. A cell-to-qubit placement is range one in
the maximum metric; four unit squares per site and three containing trominoes
per square give incidence at most twelve. Filling a bounding rectangle leaves
the arbitrary-marginal reduction intact. No two-body or fixed-lower-time
obstruction follows.

An accurate randomized log evaluator gives SAT in BPP via this reduction.
After amplification, SAT self-reduction and final witness verification give
an RP algorithm, hence NP=RP. This consequence is correctly conditional.

## 2. Mixed-tile count and one-Y phase

For `P_S=Y_first product X_others`, one has `P_S|0^S>=i|1^S>`. The factor
-i from ket evolution cancels this i for every tile. Disjoint coverings
therefore all have positive phase even when their numbers of tiles differ.
The bra has the conjugate positive coefficient. Overlapping tiles cannot
contribute at the minimum degree because they would flip a coordinate twice.

With time tau^3 and four-body coupling tau, three-body and noise factors
have degree three, and four-body factors have degree four. A noise factor
flips strictly fewer coordinates than its degree. Thus degree 2n consists
exactly of two covers and has coefficient Z_R^2. Noncommuting overlaps cannot
introduce a lower or competing same-degree term. The majorant
`exp(||A|| z^3+||B|| z^4)` bounds the sum of all operator coefficient norms
at z=1 by exp(C), proving the asserted remainder without coefficient
extraction. The bit length of tau, T and the tiny four-body coefficients is
polynomial. The stated relative/log evaluator with requested accuracy gives
the claimed multiplicative count approximation after a paid square root and
reliable zero separation. No #P theorem for trominoes alone is being imported.

The noncommuting positivity argument also survives: one X per site produces
a sign-toggled Hamiltonian of norm at most M3+tau M4. Its propagator is within
that norm times T of identity, uniformly in the jump times, so the target
amplitude on this positive-probability event cannot vanish.

Both reductions are exponentially close in TV to the deterministic initial
output. They obstruct accurate rare probabilities, not full-output TV sampling.
They are strictly stronger scope evidence than my separate SAT-flag construction,
which uses the enlarged efficiently mixed input class. No two-body, positive
minimum-time or generic TV hardness conclusion is justified by either.

## 3. TC Lemma 3 CP assertion: objection confirmed

Primary inspected source: Trivedi--Cirac arXiv:2110.10638v2, cached auditor PDF
SHA256 `2ec7bb5bc99a0e5c771a2481d4ffd9446f74c42d0ac4e41e718bc2125e3a92b7`.
The printed Lemma 3 proof on PDF page 8 explicitly asserts that a first-order
map Id+integral L is CPTP for a sufficiently small interval, and that choosing
a finite g makes Id+L/g completely positive for an arbitrary local Lindbladian.

For L=-i[Z,.], its normalized Choi matrix on the orthonormal span of
|Omega> and (Z tensor I)|Omega> is

    [[1,i/g],[-i/g,0]], determinant=-1/g^2<0.

Consequently the asserted CP ingredient is false for every finite g. Also,
an O(h^2)-accurate decomposition of coherent evolution as an identity event
plus a CPTP event of probability gh at fixed g would force the non-CP
Id+L/g as the limit of CPTP maps, contradicting closedness. The construction
does not become valid by treating this first-order error as harmless.

For a weight-at-least-two Pauli Hamiltonian with only one-site replacement
noise, compression onto |Omega>,(P tensor I)|Omega> has no dissipative P-P
diagonal but has a nonzero Hamiltonian off-diagonal. Its determinant remains
negative. This confirms the stronger specific shortcut obstruction too.

This invalidates that proof step, not the high-noise theorem's conclusion.
In this campaign its high-noise sampler should be called the **published
claimed comparator with a verified objection to this proof ingredient**, until
a repaired primary proof is checked. My initial/table references to it as a
proved high-noise sampler did not inspect this step; this follow-up explicitly
corrects that scientific accounting without rewriting the frozen independent
record. None of the positive 2D, bounded-cut or biased-reset constructions
reviewed here uses the false fixed-rate coherent-event decomposition.
