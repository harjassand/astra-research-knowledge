# Hostile audit: faithful biased resets with reference-preserving blocks

Auditor, 8 November 2026. No new agent used. Reviewed principal construction
snapshot SHA256 `c47e2030027deb4ec8d38e628120d9afc483725f3dbd58143e50c2c0f7d587ac`,
stored as `reviewed/BIASED_RESET_CONSTRUCTION_c47e2030027d.md`. The earlier
`00119aad...` draft was also read. The reviewed version adds the essential
weighted-HS rounding budget eta and makes the history cap a per-sample bias
budget independent of Monte Carlo confidence. Later source edits are covered
only insofar as they implement the explicit details proved here.

**Verdict: PASS at the stated fixed-local, fixed-faithfulness, per-block
reference-preserving scope, with the quantitative choices below.** The reset
register buffer is a valid positive construction and does not assume that a
biased reset is mixed unitary on the target system. No fatal mathematical gap
was found. This is a derived and inspected algorithmic theorem, not an executed
general implementation, physical controller result or historical-priority claim.

## 1. Precise scope and conserved reference

The assumptions are substantive: sigma=diag(p,1-p) is known rational and
faithful, with mu=min(p,1-p)>0 fixed (or bounded below by a declared fixed
positive constant); every rational bounded-support Hamiltonian block in every
explicit schedule segment commutes with its own tensor-product reference.
The support/range/incidence, J/gamma, and observable support w are fixed.
Sources are specified rational one-qubit products. The target observable is
Hermitian of norm at most one, with fixed support. T is a rational binary input.
Only the finite explicitly supplied drive is an algorithmic input; no time
oracle, unknown bath, measurement feedback or acquired pure reset is included.

For p unequal to 1/2, sigma^tensor k has distinct eigenvalues for distinct total
excitation numbers. Thus commuting with sigma^tensor k means preserving total
excitation number on the block, allowing exchange and diagonal interactions.
At p=1/2 the restriction becomes vacuous and the model returns to replacement
by the maximally mixed state. The invariant reference is sigma^tensor n and is
not generally a Gibbs state for the interacting Hamiltonian.

The Hamiltonian derivative of D(rho||sigma^tensor n) vanishes. For a reset at i,

    D(rho)-D(R_i rho)=S(rho_-i)-S(rho)-Tr(rho_i log sigma).

Summing and applying quantum Shearer gives at least D(rho). Convexity therefore
proves `D(rho_t||sigma^tensor n)<=n log(mu^-1) exp(-gamma t)` for every source,
including correlated ones in this analytic estimate. Pinsker gives the stated
all-input trace bound. It justifies a global reference cutoff before numerical
work. In the remaining branch JT=O_mu,g(log(n/epsilon)); ordinary local
Lindblad truncation then leaves O_mu,g(log^2(n/epsilon)) sites. Restriction
retains only whole allowed blocks and all resets, preserving the same product
reference. No source-state representation is inferred from the entropy bound.

## 2. Exact weighted hypercontractive import: PASS

Primary source inspected: Dong--Gao--Ou--Yao--Zhou,
[arXiv:2606.17729v1](https://arxiv.org/html/2606.17729v1), Theorem 1.1.
Its full-rank generalized-depolarizing channel is the Heisenberg reset
semigroup `Delta_(sigma,e^-t)(A)=e^-t A+(1-e^-t)Tr(sigma A)I`. Its norm is

    ||A||_(sigma,q)=||sigma^(1/(2q)) A sigma^(1/(2q))||_q.

For every tensor power, every operator A, and finite 1<p<=q, the theorem gives
contraction at

    t=(3 log 2)/(8 a_sigma) log((q-1)/(p-1)),
    a_sigma=(1-2mu)/log((1-mu)/mu).

This is exactly the candidate's norm, generator convention and constant. Its
limit at mu=1/2 is a_sigma=1/2. The paper expressly credits the earlier exact
qubit tensorization to Beigi--Datta--Rouze, *Quantum reverse hypercontractivity:
its tensorization and application to strong converses*, CMP 376 (2020). No
claim that this weighted HC theorem was invented here is warranted.

The cached PDF `sources/literature/auditor/DGOYZ_2606.17729v1.pdf` has SHA256
`b4d8b5306ffa4d6f438d82276c3b0e5baaee0767239bdc449fe35515f6596578`, 30 pages.

If U commutes with sigma^tensor m, it is an isometry at EVERY weighted
exponent, since the weighted sandwich is conjugated by the same U. Interleave
with reset hypercontractivity at varying exponents; the Lie-product limit
then yields actual driven-channel 2-to-q contraction with
`q-1<=exp(c_sigma gamma s)`, `c_sigma=8a_sigma/(3log2)`.

The operator-norm conversion is correct:

    ||A||inf <= mu^(-m/q)||A||_(sigma^m,q).

It follows by multiplying the weighted sandwich on both sides by
sigma^(-1/(2q)) and using Schatten q to operator norm. There is no unproved
replacement of the weighted norm by a tracial one.

An especially simple **finite rational implementation** avoids evaluating the
HC logarithmic constant. Since log x<=x-1, a_sigma>=mu, including its limit.
Hence c_sigma>=mu. Choose

    b=ceil(log_2(2m/mu)),  s=b/(mu gamma).

With q=1+exp(b)>=2m/mu one has
`mu^(-m/q)<=exp(mu log(mu^-1)/2)<2`. Thus s is a rational duration computed by
integer comparisons, and is O_mu(log(2m)/gamma). This conservative choice is
enough for all cost bounds. The early buffer is kept on the input side of the
drive; no channels are commuted.

## 3. Weighted basis, whole-block Cayley and sparse propagation: PASS

Put q0=1-p and z=2p-1. The displayed basis obeys

    Tr(F_i sigma^(1/2) F_j sigma^(1/2))=delta_ij,
    Tr(sigma F_j)=0 for j>0.

Indeed X and Y have squared weighted norm 2sqrt(pq0); the diagonal variance
of Z is 4pq0. Products tensorize, and the Heisenberg reset kills each
nonidentity basis element, so the noise is exactly -gamma W on coefficients.

A reference-commuting block conjugation is orthogonal on the real Hermitian
coefficient space and fixes F0. Its commutator generator A is real skew and
has 2-to-2 norm at most 2J. In local dimension N=4^k,

    max_column sum |A_ij| <= sqrt(N)||A||2 <=2^(k+1)J.

Thus one may take `C_k=2^(k+1)`. On the local nonidentity sector, allocate
gamma/d reset to every incident block site; Euler damping is at most
exp(-gamma h/d). The coefficient interpolation bound is

    exp(h[C_k J(2/p_c-1)-gamma/d]).

For instance take
`p_c=2/(1+min(1,gamma/(C_k d J)))<2`. Identity and its orthogonal complement
are disjoint invariant coefficient sets; outside labels simply tensor through.
Each update creates at most 4^k branches per retained coefficient.

For an entire block use

    U_h=(I-i h H_b/2)(I+i h H_b/2)^(-1).

It is an exactly rational unitary and commutes with the reference exactly.
Its effective Hermitian logarithm is `(2/h) arctan(hH_b/2)`, still supported
on the block, reference commuting, and of norm at most J. Hence all preceding
bounds apply at the same constants. It is not necessary to compute that
logarithm. Splitting H_b into individual noncommuting physical Pauli pieces
at THIS stage would invalidate the metric isometry and is correctly excluded.

For the tilted coefficient norm, A_ij couples weights differing by at most k.
The symmetric part of `S_theta A S_theta^-1` has entries
`A_ij sinh(theta(w_i-w_j))`, so its operator norm is bounded by its maximum
absolute row sum, at most `C_k J sinh(k theta)`. This uses the same
fixed-dimensional row bound, not an n-dependent coefficient count. Taking

    theta<=min(1/(2k),gamma/(16 d k C_k J))

leaves ample damping slack. The Cayley effective logarithm has the same bound.
Each complete damped block contracts both the coefficient p_c norm and tilted
two-norm; deleting coefficients decreases both.

For clarity, finite precision can be made completely noncircular. Let Q_up be
the paid number of block updates after assigning continuous/discrete error,
and let doubled initial budgets M0',Mtheta' be fixed. Choose a dyadic threshold
tau with

    tau^(1-p_c/2) (M0')^(p_c/2)<=eta/(100 Q_up).

This tau is inverse polynomial because p_c is fixed below two. Predeclare

    K_pre=4^k ceil((M0'/tau)^2)+4^w.

It bounds the unpruned number of branches as well as retained coefficients.
Choose per-coordinate absolute rounding error, with fixed local arithmetic
constants absorbed, at most

    nu=eta exp(-theta m)/(100 Q_up K_pre).

Rounding adds at most eta/100 in ordinary coefficient two-norm and at most
eta/100 in the tilted two-norm over the entire run; it also preserves the
doubled coefficient-p budget. Pruning contributes its separately paid HS
error. `log(1/nu)=O(theta m+log Q_up+log K_pre+log(1/eta))`, polynomial in
the retained polylogarithmic volume and input bits. A dyadic lower value for
exp(-theta m) can be obtained by a conservative integer exponent, so no exact
real oracle is needed. The local basis/algebraic map entries have fixed degree
and fixed-size supports; approximate them with certified absolute errors and
include those errors in nu. Initial fixed-support basis conversion is paid as
well. No exponentially growing exact algebraic field is maintained.

The inclusion of eta in the reviewed version's rounding rule is important:
bounded norm budgets alone would not guarantee arbitrarily small weighted-HS
approximation error. The reviewed version now pays both.

## 4. Norms of retained products and final functional accuracy: PASS

The nonidentity basis matrices are NOT unitaries. Explicitly,

    ||F1||=||F2||=(4pq0)^(-1/4),
    ||F3||=sqrt(max(p,q0)/min(p,q0)),

all at most mu^(-1/2). Choose any fixed known rational
`C0>=mu^(-1/2)` (or a strictly larger bound for a rounding margin).
Every retained coefficient has

    exp(theta r)|b|<=Mtheta', |b|>=tau,
    r<=theta^-1 log(Mtheta'/tau)=O(log Q).

Consequently C0^r is polynomial and so is the exactly computable weighted
one-norm `S_C=sum_j |b_j| C0^(r_j)`. Buffer calls estimate
`tensor(F_label/C0)` to accuracy proportional to epsilon/max(1,S_C), then
multiply by b_j C0^r_j. This pays every nonunitary factor explicitly.
Algebraic on-site contraction matrices can be approximated to the requisite
absolute error with a certified norm margin; product telescoping costs at
most the sum of one-site errors. All ideal-basis error is interpreted in the
weighted metric and then passed through the actual early HC buffer. The
buffer arithmetic is not assumed to preserve the reference exactly.

## 5. Reset-register trajectory, parity identity and locality: PASS

For one sampled reset, prepare an independent basis ancilla a with probabilities
p,q0, swap it with the physical register, and retain the old register. Tracing
the old register realizes `sigma tensor Tr_i(rho)` even if the old physical
qubit was entangled with the rest. Retaining it as an environment coordinate
therefore gives an exact unitary dilation of the Euler channel. Repeated
events keep all old registers; dropping them without tracing would be wrong.
The initial product mixed source is purified locally as before. The sampled
pure thermal basis states are numerical ensemble coordinates, not actual
access to pure bath outcomes or physical controls in the target dynamics.

All ancillas can equivalently be regarded as appended in advance in product
states. Their site labels never change. Each SWAP is unitary wholly on one
spatial site and preserves every spatial-cut Schmidt norm. In the toggling
frame Hamiltonian terms act on different internal registers but on the same
bounded set of spatial sites. Their norm and count do not grow with reset
count. A bounded k-qubit block has physical Pauli coefficient one-norm at most
2^k J. Only in this directly paid buffer may these physical Pauli pieces be
used individually. After local swaps each such piece is still a tensor product
of local register Paulis; there is no 4^(number of old registers) expansion.

Factorial spatial LR is dimension independent and remains valid after grouping
all internal registers at one spatial site. Unbounded on-site SWAP pulses are
removed exactly by the toggling frame. The remaining piecewise Hamiltonian has
the same spatial bounded-range/degree/norm parameters up to fixed k factors.
Its linked integrals have their ordinary factorial simplex volume, independent
of pulse or reset count. This justifies strip truncation using the same local
history coins in each restriction.

For a product Hermitian contraction O, `Q_j=U^dagger O_j U` commute and are
Hermitian contractions. Thus

    <(product_even Q_j)psi,(product_odd Q_j)psi>
      =<psi,U^dagger O U psi>.

No involution premise is required. Localized factors remain contractions and
are disjoint within one parity; telescoping and vector norms are controlled.
On-site contraction insertions multiply the row coefficient matrix on one side
by an operator of norm at most one, so they cannot increase Schmidt nuclear
norm. The symmetrized overlap estimator remains bounded by one.

## 6. Uniform row caps, bit costs and confidence: PASS with the stated bias cap

Let R_count<=C m be the number of nonempty strip-row occurrences, including
both parities. A row has at most C b_strip sites. Its reset count X is a sum
of independent Bernoulli variables, because reset probabilities gamma h are
state independent. Its mean lambda is at most C b_strip gamma s regardless
of Trotter step count. The elementary mgf bound

    E exp(X)<=exp((e-1)lambda)

proves, for `L=log(R_count/delta_hist)`,

    Pr[X>=ceil(2lambda+L)]<=exp(-L).

An integer binary upper bound for L gives a wholly rational deterministic cap.
A union bound over rows is valid even when rows overlap. This proves the
simultaneous cap failure probability delta_hist. Finite-bit approximations to
the coins contribute their own small TV bias and are paid separately.

The choice `delta_hist=xi/100`, depending on normalized buffer ACCURACY rather
than confidence, is essential. On a bad history return zero; since the exact
normalized history mean is bounded by one, this changes the expectation by at
most delta_hist. It is not necessary that all repeated histories satisfy the
cap, and there is no rejection loop. Requiring that with probability 1-delta
would instead put log(1/delta) in a Hilbert-space exponent and generally spoil
confidence-digit complexity. The reviewed version avoids that mistake.

Here m is polylogarithmic and `gamma s=O_mu(log log Q)`. Factorial strip width
is `b_strip=O_mu,g(log Q/log log Q)`, while `log(1/xi)=O(log Q)` because S_C is
polynomial. Therefore lambda and cap are O_mu,g(log Q). A strip-row dimension,
including physical, initial-purifying and ALL old reset registers, is

    4^O(b_strip) 2^cap = Q^O_mu,g(1).

Across a row cut, on-site swaps/ancilla additions contribute no nuclear growth.
Crossing coherent rotations have total angle O_k(b_strip J s), so
`B*=exp(O_k(b_strip J s))` is polynomial. The constructive repeated MPS
truncation lemma then gives polynomial bonds. Gate and numerical-work counts
are polynomial, including the complete schedule and fixed-size Pauli block
expansions. Tiny switching intervals cost no inverse-smallest-step factor.
MPS precision, input purifications, algebraic contractions, rational thermal
coins, and bounded finite-bit overlap samples are all paid. Repetitions cost
`O(xi^-2 log(K/delta))`; confidence enters through digits, not delta^-1.

This closes the full algorithm: reference cutoff; local restriction; exact
reference-preserving weighted sparse propagation; early HC conversion; weighted
functional sum; and explicitly constructed reset-register buffers. Physical
time and numerical bit work remain distinct resources if absolute rates vary.

## 7. Boundaries, comparisons and diagnostics

The commutation, full-rank and product-reference assumptions cannot be dropped
by this proof. Arbitrary biased resets with arbitrary Hamiltonians have a
different low-noise computational boundary; Trivedi--Cirac's biased channel in
its Hamiltonian hardness theorem supplies cooling absent from this
reference-preserving class. A product stationary state is not a general
interacting Gibbs ensemble. The pure-reset limit mu=0 invalidates the weighted
basis and HC bounds. No arbitrary global product-readout, relative probability,
full sampler, learned reservoir or unrestricted work-control theorem was checked
or obtained here.

`biased_reset_checks.py` (SHA256
`a31ee10fa396cb3e04507b5bc1a64c72a8d544be74a143170fde9401d4da39a4`)
and `BIASED_RESET_CHECKS.json` check: five faithful biases; weighted Gram
normalization; exchange-block skewness; rational whole-block Cayley reference
invariance/isometry; 500 coefficient-p test vectors; tilted contraction;
an entangled-input reset/SWAP dilation; on-site swap nuclear invariance;
50 nonunitary parity identities; and six Bernoulli tail caps over varying step
counts. All pass at numerical precision. These tests diagnose the algebra and
tail constants; the uniform theorem rests on the arguments above.
