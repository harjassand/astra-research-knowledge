# Global conservation is enough

For common biased sigma=diag(p,1-p), p!=1/2, put Q=sum_i |1><1|_i.
[H,sigma^n]=0 iff [H,Q]=0, since different excitation sectors have distinct
reference eigenvalues. Twirl EACH supplied local block by exp(i phi Q_b).
Equivalently set its matrix entries between different local excitation sectors
to zero. This keeps rationality, support, degree and norm bounds. Linearity
and global conservation imply sum_b Twirl(H_b)=Twirl(H)=H exactly. Every new
block preserves its local reference. Hence per-block conservation is an
efficiently constructible representation, not a stronger physical assumption.
At p=1/2 no conservation is needed and the unital theorem applies.

Known fixed-depth local conjugation V transfers the local-readout theorem to
the interacting reference V sigma^n V^dagger. Physical product input becomes
constant-depth prepared input V^dagger rho V; exact preparation cones and the
extra O(b depth(V)) crossing action fit the reset-register proof. If V is
Clifford, physical global Pauli products and product-Pauli-basis projectors
also transfer, using bounded mixtures. Arbitrary global axes after a general
dressing require separately paid LCU norm. This compatibility needs review.

The dressed reference is Gibbs for the commuting local Hamiltonian
H_ref=omega sum_i V Z_i V^dagger when sigma is its one-spin thermal factor;
it is generally NOT Gibbs for the actual interacting VHV^dagger. This is a
routine unitary-covariance corollary, not a generic Gibbs algorithm or a free
physical preparation/control mechanism. Conjugated reset channels are specified
Markov maps; microscopic bath/implementation costs remain separate.
