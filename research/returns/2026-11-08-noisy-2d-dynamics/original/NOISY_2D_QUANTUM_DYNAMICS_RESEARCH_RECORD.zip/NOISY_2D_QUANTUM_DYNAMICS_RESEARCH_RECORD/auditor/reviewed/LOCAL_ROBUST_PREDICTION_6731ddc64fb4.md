# Local relaxation, controlled reuse, and a learned quantum predictor

Principal derivation. This follows the frozen independent report
`initial/principal.md`; later reviews and corrections will be recorded separately.
The original prediction theorem is capital at its exact product-input, 2D,
replacement-noise, additive-local-mean scope. This file does not claim priority
for rapid-mixing stability or local generator learning.

## 1. Physical and numerical class

A finite subset of the square lattice carries qubits. A supplied dictionary of
nonidentity Hermitian Pauli strings has support size at most k, diameter at most
a >= 1, and at most d strings incident on any site. The unknown drift is
H_0=sum_P h_P P, |h_P|<=J_0. Known, prescribed coherent controls H_c(t) are
piecewise constant with rational switching times and coefficients. Their full
description is paid. The total Hamiltonian has fixed bounds a,k,d,J throughout.
The noise is gamma sum_i(E_i-Id), gamma>0 rational or supplied by a paid certified
evaluation algorithm. There are no measurements, resets, cooling steps, fresh
physical ancillas, or control dependent on unobserved quantum measurement records
in a permitted prediction query. The state supplied for a query is a rational
product state; its actual independent local preparation may have declared error.
The readout has at most w sites and operator norm <=1.

First establish analytic estimates for arbitrary measurable bounded controls;
only the finite rational description is an algorithmic claim. A class parameter
is g=J/gamma. Every constant below is independent of lattice volume, horizon,
number of switches, source state, and the particular allowed drive.

Write Phi_{s,t} for the Heisenberg propagator, tau for normalized trace, and u=t-s.
Assume the usual local truncation estimate, verified from the original linked
interaction argument or Barthel--Kliesch Theorem 2:

    ||Phi_{s,t}(O)-Phi^R_{s,t}(O)|| <= K exp(Vu-R/(2a)),       (1)

where Phi^R keeps terms inside the radius-R union of balls around supp(O).
K>=1 and V>0 are explicit fixed-locality constants; enlarging them is harmless.
Their time-dependent applicability uses time-ordered integrals and the uniform
local-strength bound, not time translation invariance. Terms on the boundary
are discarded, all replacement noise on retained sites remains, and tau(O)
is unchanged. The site count is <=w(2R+1)^2. Constants from the original report
are one conservative choice; a verified larger choice from the general local
Lindblad bound is equally valid.

## 2. Entropy contraction without a Hamiltonian restriction

For an m-qubit density matrix let D(rho)=m log 2-S(rho). Convexity of relative
entropy gives the upper directional derivative

    dD(rho)[E_i rho-rho] <= D(E_i rho)-D(rho).

Furthermore D(E_i rho)=D(rho_{-i} || I/2^(m-1)). Quantum Shearer, obtained by
repeated strong subadditivity, says sum_i S(rho_{-i}) >= (m-1)S(rho).
Consequently

    sum_i [D(rho)-D(E_i rho)] >= D(rho).

The Hamiltonian directional derivative is zero. At variable Hamiltonian and
constant replacement rate, dD/dt<=-gamma D. Boundary density matrices follow by
regularization or integration of the finite-dimensional completely positive
evolution. Hence, for every initial density matrix, correlated or not,

    ||rho_u-I/2^m||_1 <= sqrt(2m log 2) exp(-gamma u/2).       (2)

Only (2), not a computable representation of that arbitrary correlated state,
is used below.

## 3. Volume-independent local relaxation

Set x=gamma u, v=V/gamma, and choose integers

    r0 >= 2a(log K+1)+a+3,
    r1 >= 2a(v+2)+2,
    R(x)=ceil(r0+r1 x).

The logarithm can be upper bounded by an integer binary logarithm. Equation (1)
is at most exp(-2x). Equation (2), applied to the restricted evolution for
every reduced source density matrix, implies an OPERATOR norm bound. Thus

    ||Phi_{s,t}(O)-tau(O) I||
      <= exp(-2x)+sqrt(2w log 2)(2R(x)+1) exp(-x/2)
      <= A(1+x) exp(-x/2),                                  (3)

where, for example,

    A=1+2w[2(r0+r1+1)+1]

is valid. One may replace the right side by its minimum with 2. This bound
holds for every finite volume and every s,t, including arbitrary unknown
initial states. It is local relaxation, not global trace-distance mixing.

An integer X_e=O(log(A/epsilon)+1) with A(1+X_e)exp(-X_e/2)<=epsilon exists
and can be found by integer doubling plus certified scalar evaluation. For
gamma T>=X_e, return tau(O). For all other times, (1) localizes a query to
O_g(log^2(2/epsilon)) sites, independent of total system size. The input still
has to be read or accessed through a paid index. Infinite time does not replace
finite time or require reading exponentially many digits of T.

## 4. Uniform perturbation theorem, including nonunital errors

Let G'_t=G_t+sum_z B_{z,t}. Assign each perturbation support a lattice center z;
it has diameter <=a_e and at most q perturbation terms have any one center.
Assume B_z(I)=0 and ||B_z||_(infty->infty)<=eta, uniformly in t. A completely
bounded norm bound is sufficient. The total G'_t must generate physical CPTP
Schrodinger evolution. Its terms need not separately be Lindblad; G'_t need
not preserve the maximally mixed state. Both comparisons use the same initial
source and same control. This theorem is an explicit version of the established
local rapid-mixing stability mechanism, extended here by its proof to bounded
nonautonomous reference drives.

For distance r(z,supp O)<=R(x)+a_e+1, there are at most

    N0(1+x)^2 terms,
    N0=q w [2(r0+r1+a_e+2)+1]^2.

Since B_z(I)=0, (3) bounds their total contribution to
sum_z ||B_z Phi_{t-u,t}(O)|| by eta N0 A(1+x)^3 exp(-x/2).

For a far term, truncate the reference observable to a neighborhood disjoint
from its support. B_z annihilates that truncated observable. By (1) its
contribution is bounded by eta K exp(vx-(r-a_e-1)/(2a)). Square-lattice shells
have <=16w(r+1) centers, before multiplying by q. The geometric series and
(1-exp(-1/(2a)))^-1<=3a imply a far contribution at most

    eta B(1+x) exp(-2x),
    B=16wq[3a(r0+r1+a_e+4)+9a^2].

The harmless extra units cover noninteger radii and choice of support center.
Increase B if a different lattice metric convention is used. Define

    K_stab=158 N0 A+B.                                      (4)

Indeed integral_0^infty (1+x)^3 exp(-x/2) dx=158 and
integral_0^infty (1+x)exp(-2x) dx=3/4. Duhamel, with perturbed evolution on
the outside and reference future evolution next to B_z, gives

    ||Phi'_{s,t}(O)-Phi_{s,t}(O)||
       <= int_0^u sum_z ||B_{z,t-r} Phi_{t-r,t}(O)|| dr
       <= K_stab eta/gamma.                                (5)

All outer propagators are contractions because the total perturbed evolution
is physical. No perturbed mixing assumption, smallness assumption, or global
sum of perturbation norms is needed. For large eta the bound is simply vacuous.
This is NOT an arbitrary-precision simulation of the nonunital system: (5)
provides an accuracy floor. Global sampling and decoded macroscopic information
are not controlled by a fixed-local O estimate.

## 5. Independent product-preparation error

For two product sources with max_i ||rho_i-sigma_i||_1<=zeta, telescope one
site at a time. Each single-site difference annihilates identity, so the same
near/far argument, now for ||Phi(O)-E_i Phi(O)||<=2 times the relevant bound,
applies without a time integral. For q=1,a_e=0 define N0,B as above and

    K_prep=2(216 N0 A+B).

The elementary maxima sup_(x>=0)(1+x)^3exp(-x/2)<=216 and
sup_(x>=0)(1+x)exp(-2x)<=1 give

    |Tr[(rho-sigma) Phi_{0,T}(O)]|<=K_prep zeta,              (6)

uniformly in n,T and allowed controls. This says nothing comparable about
arbitrary correlated preparation errors known only through one-site marginals.

## 6. Nonautonomous extension of the original classical algorithm

This uses the checked original buffer construction and is not a new replacement
for it. The altered logical order is essential.

At gamma T<X_e localize to m=O_g(log^2(2/epsilon)) sites. Let
s=ceil(log_2(2m))/(2gamma). If T<s, compute the whole short buffer. Otherwise:

1. Propagate O backward through the LATER interval [s,T], using sequential
   complete noisy Pauli blocks, exact rational Cayley rotations, positive Euler
   replacement maps, merging and coefficient truncation. Local coefficient-p
   contractivity is independent of the signs and time order of coefficients.
   Obtain B0 with normalized HS error eta_s.
2. Apply the EARLY-interval channel Phi_{0,s} to that error. King's Corollary 2,
   interleaved with changing Hamiltonian Schatten-norm isometries, gives
   ||Phi_{0,s}(error)||_infty<=2 eta_s. No channels are commuted.
3. Evaluate the weighted early-buffer Pauli functionals on the supplied product
   input by the original parity-strip construction. Its trajectories already
   have piecewise time-dependent sign-toggled Hamiltonians. Factorial locality
   and accumulated cross-cut angle bounds depend on physical duration and
   local strength, rather than number of switches.

Partition numerical steps at supplied switch times. If interval lengths are
Delta_j and the restricted generator-norm budget is S0, choose

    r_j=max(1,ceil(C S0^2 Delta_j T/eta_s),ceil(S0 Delta_j)).

The sum is <=number_intervals+C S0^2 T^2/eta_s+S0T up to constant factors.
Tiny intervals do not cause inverse-minimum-step cost. Forward and reversed
strip evolutions use the actual supplied chronology. Sampling, tensor
truncation, approximate SVD, dyadic arithmetic and all sparse coefficients
retain the original paid error budgets with an extra polynomial factor in
the control description length.

It follows that at fixed local parameters and g there is a randomized classical
predictor with work poly_g(B_query,1/epsilon,log(1/delta)), where B_query includes
the binary description of T and every control switch and rational product input.
After paid indexing, the many-body computation touches only the stated local
neighborhood. A conservative envelope may enlarge the original exponent
D_kappa=2^80 kappa^40 to 2^100(2+kappa)^60. This is not a useful practical bound.
No claim of polynomiality at g growing with input length is made. The stronger
binary-horizon statement uses (3) before any numerical dynamics is run.

## 7. A completely specified noisy local acquisition protocol

Here gamma and the dictionary are known. Learning them is not needed for the
claim; a known bounded-range dictionary can include zero unknown coefficients.
Let Mpar be its number of distinct nonidentity strings, no duplicate terms.

For each P choose a one-site Q anticommuting with P and put R=i P Q, including
its sign. Then i[P,Q]=2R, and Pauli orthogonality gives

    tau(R GQ)=2h_P,   tau(RQ)=0.                            (7)

On supp(R), prepare independent noisy local eigenstates
(I+sigma_i p_i R_i)/2, with uniform known signs sigma_i and known p_i>=p0>0.
Outside supp(R), prepare I/2, for example by a uniform mixture of the same
symmetric noisy opposite-eigenstate preparations. All physical preparations
are independent products. Their average is I/2 at every site. Signed averaging
multiplied by the product of signs yields (product p_i)R/2^n. A binary noisy
measurement of Q has calibrated conditional mean b_Q+c_Q <Q>, c_Q>=c0>0.
For each shot, weight (Y-b_Q)/c_Q by product sigma_i and divide by product p_i.
This gives a bounded score |Z|<=A_acc=2/(c0 p0^k), and

    E Z(t)=tau(R Phi_{0,t}(Q)).

The sign of R is included in the score. This protocol requires no entangled
probe, inverse dynamics, source-copy oracle, or future target experiment.
The drift is constant during acquisition and controls are off.

Let Gamma=2dJ_0+2gamma, C2=k Gamma^2. Each term in GQ has support <=k, and
local generator norms give ||G^2 Q||<=C2. The Taylor remainder is bounded by
C2 t^2/2, since e^(tG) is an operator-norm contraction. Therefore

    |E Z(t)/(2t)-h_P|<=C2 t/4.                              (8)

Choose target coefficient error alpha, a rational
t<=min(1/(4Gamma),alpha/(4C2)), and

    M>=8 A_acc^2/(t^2 alpha^2) log(2 Mpar/delta_acq)           (9)

independent shots per coefficient. Hoeffding and a union bound give simultaneous
coefficient accuracy alpha with ample budget slack. Round to rational precision
<=alpha/8 and clip to [-J_0,J_0]; clipping cannot worsen error to a true coefficient
in that interval. This is a deliberately suboptimal alpha^-4 learner. The stronger
alpha^-2, up to logarithms, learning machinery of Mobus--Bergamaschi--Franca--Rouze
Theorem 4.5 is credited separately, not claimed invented here.

Operational calibration error: if the corrected mean E Z has an independently
warranted systematic error <=beta, it contributes beta/(2t). If evolution-time
error is <=Delta_t, the additional contribution is <=Gamma Delta_t/(2t).
For example beta<=alpha t/8 and Gamma Delta_t<=alpha t/8 fit the error budget.
Calibration is an explicit paid input: include C_cal(beta,delta_cal), the number
and cost of trusted calibration experiments, and required timing precision.
With exact known primitive noise parameters C_cal is zero by the access contract;
with unknown SPAM no unconditional identifiability is asserted. Repetition does
not remove an unknown fixed bias, and the theorem reports its floor if larger.

Nshots=Mpar M. At most n local preparations, one evolution of duration t, and
one single-site readout are used per shot. A conservative sequential account is
n Nshots local preparation operations, Nshots readouts, and source-evolution time
Nshots t, plus paid calibration/reset/repetition infrastructure. Streaming the
scores requires O(Mpar log M + Mpar log(1/alpha)) bits beyond the input and
calibration descriptions; rational arithmetic and preprocessing are polynomial
in these quantities and supplied bit lengths. No wall-clock or energy advantage
over a better experimental protocol is inferred.

When absolute rates are variable binary inputs while only J/gamma is fixed,
the physical acquisition durations above retain their actual 1/gamma scaling.
Polynomial numerical work in rate bits does not make that physical time
polynomial in the bit length of gamma. Operation counts, arithmetic work,
physical duration, reset strength and ancilla supply are distinct resources.

## 8. Reusable intervention service and complete uncertainty statement

The retained predictive object is the rational local drift table, dictionary,
gamma, coefficient uncertainty, calibration record, local bounds, and a paid
spatial index. It is not an acquired full many-body density matrix. Acquisition
at target alpha is done once. Every future query supplies a new product source,
bounded known coherent drive, local O, time T and numerical precision/confidence.

On the simultaneous coefficient-validity event, a Hamiltonian difference is a
sum of local maps ||i[(h_P-hhat_P)P,.]||<=2alpha. Use (5) with eta=2alpha and
q equal to the actual dictionary term-density bound. If the actual process has
an additional declared local-generator discrepancy b_miss, use eta=2alpha+b_miss.
If independent future source errors are <=zeta per site and readout mean has
certified discrepancy b_read, then, with per-query numerical failure delta_j,

    |fhat_j-f_actual,j|
      <= epsilon_num,j
         + K_stab(2alpha+b_miss)/gamma
         + K_prep zeta+b_read.                             (10)

The calibration event contributes its own failure probability. This event is
simultaneous over ALL allowed future controls: no uncountable union bound is
used. Numerical failures may be allocated delta_j=6 delta_service/(pi^2 j^2),
so all countably many queries hold simultaneously with failure <=delta_service,
even when a researcher chooses each next query using earlier numerical answers.
The physical process must retain its declared generator/control/noise contract;
unknown non-Markovian memory is not acquired for free.

Choosing alpha=O_g(gamma epsilon), and making the other declared floors fit the
requested budget, gives polynomial acquisition operation counts and arithmetic,
polynomial storage and classical evaluation at every fixed positive noise ratio,
with physical acquisition durations explicitly charged above, and error independent
of n,T apart from paid explicit descriptions and acquisition of n coefficients.
It predicts unperformed experiments within this class and recomputes no full
many-body state. The original all-ratio worst-input predictor supplies the
enabling operation; experimental learning and stability are established tools.

## 9. Obstruction and novelty accounting

The reference steady state is maximally mixed: this is not a general predictor
for low-temperature interacting matter or sustained cooled processing. Generic
correlated inputs can carry the answer to a hard computation in a single local
marginal already at T=0. Arbitrary quantum-measurement feedback, fresh pure
ancillas, and resets can replenish entropy and invalidate the decay argument.
The perturbation theorem permits imperfect cooling only above an explicit
fixed uncertainty floor; it does not prove arbitrary-accuracy cooling simulation.
Full output sampling, relative rare-event probabilities, and the zero-noise
limit remain separate operations. Polynomial costs here are astronomical; no
experimental demonstration, practical dominance, or first-priority claim follows.

Primary comparators checked or to be checked at exact versions in source records:
King1210.8412v1 Theorem1/Corollary2; Angrisani et al2609.40174v2
LemmaS15/CorollaryS16/TheoremS20 and actual operational quantifiers;
Lucia et al1409.7809v2 Theorem1 (autonomous stability predecessor);
Barthel--Kliesch1111.4210 (time-dependent locality);
Mobus et al2606.23652v1 Theorem4.5 and Theorem8.2/Corollary8.3
(learning and local verification; generic learned many-body evaluation still paid).
