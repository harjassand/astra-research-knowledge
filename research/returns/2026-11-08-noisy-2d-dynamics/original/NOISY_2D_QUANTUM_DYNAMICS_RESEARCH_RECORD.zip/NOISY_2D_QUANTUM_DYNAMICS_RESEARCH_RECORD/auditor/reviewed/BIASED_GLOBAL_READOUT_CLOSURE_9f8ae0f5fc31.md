# Biased-reference GLOBAL Hermitian product readouts

Principal new closure for independent review. Keep all full-rank sigma,
per-local-block reference conservation, bounded 2D schedule, rate and explicit
input conditions of BIASED_RESET_CONSTRUCTION.md, but allow ANY global product
of Hermitian one-qubit contractions. Claim: all-time randomized polynomial
bit-work additive prediction, with class dependence on mu>0 and J/gamma. This
is NOT relative-probability evaluation or full-output sampling.

## Crucial operation

Reserve gamma/2, allocate gamma/(2d) to block sites, and use the reviewed tilted
KMS coefficient estimate. With theta<=1/2 fixed small enough and
alpha(u)=min(gamma u/2,theta), the moving-weight proof gives

    ||exp(alpha W)S||_(2,sigma->2,sigma)<=1.

The KMS adjoint reverses Hamiltonian sign and chronology; biased reset is
self-adjoint. Consequently ||S exp(alpha W)||<=1 and

    ||S X||_(2,sigma)<=||exp(-alpha W)X||_(2,sigma).        (1)

An ORDINARY traceless Hermitian Bloch unitary A_i need not be sigma-centered.
Write A_i=a_i I+B_i orthogonally in weighted two-norm, a_i=Tr(sigma A_i),
and z=2p-1. Then |a_i|<=|z| and ||A_i||_(2,sigma)^2<=1. Therefore

    ||exp(-alpha W_i)A_i||_(2,sigma)^2
       =a_i^2+exp(-2alpha)||B_i||_(2,sigma)^2
       <=z^2+(1-z^2)exp(-2alpha).

For alpha<=1/2, 1-exp(-2alpha)>=alpha and 1-z^2=4mu(1-mu)>=2mu. Thus this
square is <=exp(-2mu alpha), and tensorization with (1) gives

    ||S P||_(2,sigma^m)<=exp(-mu alpha(u) r)              (2)

for a product of r ordinary traceless Hermitian Bloch unitaries. The weighted
identity components do not vanish; faithfulness already bounds their size.
This is precisely the operation missing from the earlier local-only theorem.

## Support-sensitive HC and constructive branches

Put t0=2theta/gamma and lambda=mu theta. Localize P with error eta to
m<=min(n,C r[1+JT+log((r+1)/eta)]^2). In the EARLY interval take weighted
HC exponent q>=max(2,4m log(mu^-1)/(lambda r)). It can be reached by a rational
s=O_mu,theta((1+log(m/r))/gamma) using the checked conservative HC rate.
Then mu^(-m/q)<=exp(lambda r/4). For T>=s+t0, apply (2) to the later interval:

    ||Phi_(0,T)P||infty<=eta+exp(-3lambda r/4).           (3)

Let Q=2+B+n+epsilon^-1+confidence digits, L=ceil log2 Q. First use the biased
global entropy cutoff gamma T>=C_mu L and return the known sigma^n mean.
Otherwise JT=O(L), m/r<=C L^2, and s+t0=O_mu,g(log L)/gamma.

1. Large r>=C/lambda log1/epsilon with T>=s+t0: return zero by (3).
2. T<s+t0: use the GLOBAL reset-register short buffer, m possibly n.
   Width b=O(L/log L), row reset cap O(b gamma T+log(m/xi))=O(L), row dimension
   exp(O(L)), crossing nuclear exponent O(bJT)=O(L). All costs are polynomial.
3. Otherwise r=O_mu,theta(log1/epsilon). Expand P in at most 4^r F-basis terms.
   Initial weighted two-norm<=1, coefficient one-norm<=2^r, and tilted norm
   <=exp(theta r), all polynomial in Q. Now m=O(L^3). The reviewed sparse
   engine retains polynomial coefficients with weights r_j=O(log Q); product
   factor norms C_mu^(r_j) are paid. The usual early weighted-HC buffer lasts
   O_mu(log m)/gamma=O_mu(log L)/gamma and is polynomial by the reset-register
   lemma. No growing support appears in a hidden class exponent.

Use the ORDINARY decomposition O_i=a_i I+b_i A_i, |a_i|+b_i<=1, to sample a
bounded signed mixture of the products above. The original finite-bit rational
axes approximation, clipping, Hoeffding and internal confidence budgets apply.
Do NOT presume |Tr(sigma O_i)|+||O_i-Tr(sigma O_i)I||<=1; that shortcut is false.

This yields all-support Hermitian products in the conserving biased-reset class,
assuming the two reviewed component constructors. It does not cover arbitrary
complex products without a paid LCU norm, mu->0 uniformly, arbitrary work drives,
Gibbs(H), arbitrary correlated sources, rare relative accuracy or a full sampler.
The fourth researcher's dual-rail tiling obstruction is compatible with this
additive theorem. Prepared-source transfers need their separate paid description
and loglog Q_bin depth cap. Historical novelty remains unestablished.
