# Acquired global product-readout predictions at all horizons

This composition uses the machinery researcher's independently frozen global
product-readout construction, the checked noisy acquisition protocol, and the
following elementary global perturbation estimate. Local volume-independent
uncertainty is a different, stronger stability property; it is not asserted for
global readouts.

## Global all-time perturbation bound

Let the reference be an n-qubit generator with arbitrary bounded prescribed
time-dependent Hamiltonian and all-site replacement floor gamma>0. Its normalized
trace is stationary. Entropy contraction and Pinsker, uniformly over every input,
give for any Hermitian O with ||O||<=1

    ||Phi_(s,t)(O)-tau(O)I||
       <= min(2,sqrt(2n log 2) exp(-gamma(t-s)/2)).            (1)

Suppose the actual physical Heisenberg generator differs by M local terms
B_(j,t), each annihilating identity, ||B_(j,t)||<=eta. The actual total generator
is CPTP in the Schrodinger picture; it need not be unital there. Duhamel with
the reference future evolution next to the perturbation gives

    sup_(s<=t) ||Phi'_(s,t)(O)-Phi_(s,t)(O)||
       <= (M eta/gamma) [4 log(2n)+4].                       (2)

For the scalar integral, split x=gamma(t-s) at x0=2log(2n). Its initial portion
is at most 2x0, and its exponential tail is at most
2 sqrt(2n log 2)/(2n)<=2. Equation (2) uses a larger round bound. Completely
bounded local errors suffice for the norm premise. M=O(n) for bounded incidence.
This is all-time GLOBAL stability with an extensive cost, not a time/volume-
independent global estimate or a TV sampler.

## Reusable predictive object and full error

Acquire the unknown drift coefficients at simultaneous accuracy alpha, storing
the rational table, dictionary, calibrated noise rate and uncertainty record.
For Mpar Hamiltonian terms, the difference maps have norm at most 2alpha. An
additional physical-model discrepancy consisting of Mmiss local terms of
strength at most b_miss is paid separately. Future query j supplies a product
source, a new bounded coherent schedule, a global product of Hermitian
one-qubit contractions, time T_j, and numerical error/confidence. On the single
valid-acquisition event, the global readout theorem computes fhat_j with

    |fhat_j-f_actual,j|
       <= epsilon_num,j
          +[4log(2n)+4](2Mpar alpha+Mmiss b_miss)/gamma
          +b_source+b_read.                                (3)

Here b_source is an actual global trace-distance source mismatch, bounded by
sum_i zeta_i for independently inaccurate product preparations. b_read bounds
the norm error of the full readout; independent local readout-factor errors may
be summed by telescoping. Source/readout errors need not be unreasonably small:
for inverse-polynomial total precision, inverse-polynomial local precision
suffices. Arbitrary unknown correlated source error is not controlled by a list
of one-site marginal errors.

Choose alpha=O(gamma epsilon/[Mpar log(2n)]) and fit the declared other floors
to epsilon. The elementary alpha^-4 acquisition protocol has polynomial operation
counts and arithmetic in n, epsilon^-1, fixed rate ratios, calibrated contrast
factors and confidence digits. Physical acquisition time retains its explicitly
charged inverse-rate dependence, including 1/gamma. The stronger
existing local-learning machinery can improve its sample exponent under its
own access assumptions. Finite-rate reset preparation is supplied separately
in PAID_ACQUISITION_PREPARATION.md, with polynomially growing strength and
explicit thermal-ancilla flux. It is not a fixed-control-budget theorem.

The drift table has O(n) coefficients and polynomial bit memory. The subsequent
same-2D global-product evaluator has polynomial bit work at every fixed positive
noise ratio, including the actual proposed control/input descriptions. No future
target experiment is performed. The simulator evaluates sparse observable
propagation and short buffers rather than a full 2^n-state vector. Numerical
failure budgets may be summable over adaptively chosen queries; coefficient
validity is simultaneous over all controls within the uniform bounds.

This is a complete acquired-model prediction capability at its promised
Markovian, product-source, coherent-control, replacement-noise scope. Its enabling
new operation is the global product-readout extension. Local learning, ordinary
statistical confidence, entropy mixing and perturbation composition are credited
as established techniques. Neither practical superiority, full output sampling,
generic quantum-state acquisition nor a low-temperature cooled service follows.
