"""Finite diagnostics for challenge review; not proofs or a full simulator."""
from pathlib import Path
import math
import json
import hashlib
import itertools
import numpy as np

def expm(a):
    scale=max(0,int(math.ceil(math.log2(max(1.,np.linalg.norm(a,np.inf))))))
    b=a/(2**scale)
    total=np.eye(len(a),dtype=complex);term=total.copy()
    for k in range(1,200):
        term=term@b/k;total+=term
        if np.linalg.norm(term,np.inf)<1e-18:break
    else:raise RuntimeError('exponential failed')
    for _ in range(scale):total=total@total
    return total

I=np.eye(2,dtype=complex)
X=np.array([[0,1],[1,0]],dtype=complex)
Y=np.array([[0,-1j],[1j,0]],dtype=complex)
Z=np.diag([1,-1]).astype(complex)
one=[I,X,Y,Z]
labels=list(itertools.product(range(4),repeat=3))
paulis=[np.kron(np.kron(one[a],one[b]),one[c]) for a,b,c in labels]
weights=np.array([sum(x!=0 for x in label) for label in labels])
terms=[((1,1,0),.7),((3,0,0),.4),((0,3,1),-.8),((0,0,2),.3)]
ham=sum(c*paulis[labels.index(p)] for p,c in terms)
coherent=np.array([[np.trace(p.conj().T@(1j*(ham@q-q@ham))).real/8
                    for q in paulis] for p in paulis])
tests=[]
for gamma in [.05,.2,1.,10.]:
    theta=min(1/4,gamma/64) # k=2,d=2,J=1
    generator=coherent-gamma*np.diag(weights)
    for t in [.001,.02,.1,1.,8.]:
        alpha=min(gamma*t/2,theta)
        semigroup=expm(generator*t)
        smoothing=np.diag(np.exp(alpha*weights))
        left=float(np.linalg.norm((smoothing@semigroup)[1:,1:],2))
        right=float(np.linalg.norm((semigroup@smoothing)[1:,1:],2))
        max_homogeneous=0.
        for r in [1,2,3]:
            idx=np.flatnonzero(weights==r)
            ratio=float(np.linalg.norm(semigroup[:,idx],2))*math.exp(alpha*r)
            max_homogeneous=max(max_homogeneous,ratio)
        assert max(left,right,max_homogeneous)<=1+1e-10
        tests.append({'gamma':gamma,'T':t,'theta':theta,'left_traceless_norm':left,
                      'right_traceless_norm':right,'max_homogeneous_ratio':max_homogeneous})

# Exact marginal algebra following independent computational-basis bit flips.
rare=[]
for n in [1,2,5,10,30,80]:
    t=2.**(-4*(n+2))
    q=-math.expm1(-t)/2
    p0=2.**(-n-1)
    unsat_p=q+(1-2*q)*p0
    for count in [0,1,2**(n-1)]:
        p=(1+count)*p0;a=count*p0
        p_after=q+(1-2*q)*p
        conditional_after=q+(1-2*q)*(q/2+(1-2*q)*a)/p_after
        conditional_before=count/(1+count)
        bound=8*q/p
        assert abs(conditional_after-conditional_before)<=bound+1e-14
        assert bound<=1/32
        if count==0:assert conditional_after<1/4-1/16
        else:
            assert conditional_after>1/4+1/16
            assert math.log(p_after/unsat_p)>.6
        rare.append({'latent_bits':n,'solutions':count,'T':t,'noise_flip_probability':q,
                     'conditional_after':conditional_after,'proved_error_bound':bound,
                     'log_ratio_to_unsat_marginal':math.log(p_after/unsat_p)})

integrals=[]
for n in [1,2,10,100,1000000]:
    c=math.sqrt(2*n*math.log(2))
    integral=2*c if c<=2 else 4*math.log(c/2)+4
    bound=4*math.log(2*n)+4
    assert integral<=bound
    integrals.append({'n':n,'exact_integral':integral,'reviewed_bound':bound})

report={'scope':'finite diagnostics only','weighted_smoothing':tests,
        'rare_conditional_reduction':rare,'global_stability_integral':integrals,
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
path=Path(__file__).with_name('POST_EXCHANGE_CHECKS.json')
path.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS finite diagnostics','weighted_cases':len(tests),
                  'conditional_cases':len(rare),'integral_cases':len(integrals),
                  'output':str(path),'script_sha256':report['script_sha256']},indent=2))
