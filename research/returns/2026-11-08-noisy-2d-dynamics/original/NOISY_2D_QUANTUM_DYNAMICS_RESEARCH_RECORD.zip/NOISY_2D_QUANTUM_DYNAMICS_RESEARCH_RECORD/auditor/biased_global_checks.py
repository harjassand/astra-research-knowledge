"""Finite weighted moving-smoothing checks for ordinary physical supports."""
from pathlib import Path
import numpy as np
import math,json,hashlib

def expm(a):
 s=max(0,int(math.ceil(math.log2(max(1.,np.linalg.norm(a,np.inf))))))
 b=a/2**s;out=np.eye(len(a),dtype=complex);term=out.copy()
 for k in range(1,200):
  term=term@b/k;out+=term
  if np.linalg.norm(term,np.inf)<1e-18:break
 else:raise RuntimeError('exponential failed')
 for _ in range(s):out=out@out
 return out

rng=np.random.default_rng(202611083)
I=np.eye(2,dtype=complex);X=np.array([[0,1],[1,0]],dtype=complex)
Y=np.array([[0,-1j],[1j,0]],dtype=complex);Z=np.diag([1,-1]).astype(complex)
weights=np.array([int(i//4!=0)+int(i%4!=0)for i in range(16)])
ham=.45*(np.kron(X,X)+np.kron(Y,Y))+.3*np.kron(Z,Z)+.2*np.kron(Z,I)-.1*np.kron(I,Z)
rows=[]
for p in [.01,.1,.3,.5,.9,.99]:
 q=1-p;mu=min(p,q);z=2*p-1
 f=[I,X/math.sqrt(2*math.sqrt(p*q)),Y/math.sqrt(2*math.sqrt(p*q)),(Z-z*I)/(2*math.sqrt(p*q))]
 basis=[np.kron(a,b)for a in f for b in f]
 root=np.diag(np.sqrt([p,q]));rr=np.kron(root,root)
 coh=np.array([[np.trace(a.conj().T@rr@(1j*(ham@b-b@ham))@rr).real for b in basis]for a in basis])
 for gamma in [.1,1.]:
  theta=min(.25,gamma/(16*1*2*8*2))
  gen=coh-gamma*np.diag(weights)
  for t in [.001,.05,1.]:
   alpha=min(gamma*t/2,theta);channel=expm(gen*t)
   tilt=np.diag(np.exp(alpha*weights));damp=np.diag(np.exp(-alpha*weights))
   left=float(np.linalg.norm(tilt@channel,2));right=float(np.linalg.norm(channel@tilt,2))
   assert max(left,right)<=1+1e-11
   max_input_ratio=0.;max_physical_ratio=0.;max_single_ratio=0.
   for j in range(8):
    axes=[]
    for site in range(2):
     v=np.array([0.,0.,1.])if j==0 else rng.normal(size=3)
     v/=np.linalg.norm(v);axes.append(v[0]*X+v[1]*Y+v[2]*Z)
     weighted=axes[-1]
     av=float(np.trace(np.diag([p,q])@weighted).real)
     norm2=float(np.trace(weighted@root@weighted@root).real)
     dsq=av*av+math.exp(-2*alpha)*(norm2-av*av)
     ratio=dsq/math.exp(-2*mu*alpha)
     max_single_ratio=max(max_single_ratio,ratio)
     assert ratio<=1+1e-12
    for r in [1,2]:
     prod=np.kron(axes[0],I if r==1 else axes[1])
     coeff=np.array([np.trace(a.conj().T@rr@prod@rr)for a in basis])
     output_norm=float(np.linalg.norm(channel@coeff))
     damp_norm=float(np.linalg.norm(damp@coeff))
     max_input_ratio=max(max_input_ratio,output_norm/damp_norm)
     max_physical_ratio=max(max_physical_ratio,damp_norm/math.exp(-mu*alpha*r))
     assert output_norm<=damp_norm+1e-11
     assert damp_norm<=math.exp(-mu*alpha*r)+1e-11
   rows.append({'p':p,'gamma':gamma,'T':t,'alpha':alpha,
                'moving_left_norm':left,'moving_right_norm':right,
                'max_input_smoothing_ratio':max_input_ratio,
                'max_physical_support_ratio':max_physical_ratio,
                'max_one_site_squared_ratio':max_single_ratio})
report={'scope':'finite diagnostics only','cases':rows,
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
out=Path(__file__).with_name('BIASED_GLOBAL_CHECKS.json');out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS finite diagnostics','parameter_cases':len(rows),
                  'physical_product_cases':len(rows)*16,'output':str(out),
                  'script_sha256':report['script_sha256']},indent=2))
