"""Finite synthetic checks. These do not verify the uniform complexity theorem."""
import itertools, json, math
from pathlib import Path
import numpy as np

I=np.eye(2,dtype=complex)
P=[I,np.array([[0,1],[1,0]],complex),np.array([[0,-1j],[1j,0]],complex),np.diag([1,-1])]
def kron(xs):
    z=np.ones((1,1),complex)
    for x in xs:z=np.kron(z,x)
    return z
def setup(n):
    words=list(itertools.product(range(4),repeat=n))
    basis=np.array([kron([P[j] for j in w]) for w in words])
    return words,basis
def coefficients(a,basis):return np.einsum('bij,ji->b',basis,a).real/len(a)
def generator(n,terms,gamma,eta=0):
    words,basis=setup(n);h=sum(c*basis[words.index(w)] for c,w in terms)
    columns=[]
    jump=kron([np.array([[0,1],[0,0]],complex)]+[I]*(n-1))
    jj=jump.conj().T@jump
    for w,a in zip(words,basis):
        out=1j*(h@a-a@h)-gamma*sum(j!=0 for j in w)*a
        out+=eta*(jump.conj().T@a@jump-(jj@a+a@jj)/2)
        columns.append(coefficients(out,basis))
    return np.array(columns).T,words,basis
def expm(a):
    # Scaling and a convergent Taylor series; sufficient for the small fixtures.
    s=max(0,int(math.ceil(math.log2(max(1,np.linalg.norm(a,ord=1))))))
    b=a/(2**s);v=np.eye(len(a));z=v.copy()
    for j in range(1,100):
        z=z@b/j;v=v+z
        if np.linalg.norm(z,ord=1)<1e-16:break
    for j in range(s):v=v@v
    return v
def run():
    rng=np.random.default_rng(20261108)
    terms=[(.31,(1,3,0)),(-.27,(0,2,1)),(.19,(3,0,0)),(.13,(0,0,2))]
    g,words,basis=generator(3,terms,.7)
    dim=8
    isolation=[]
    for h,w in terms:
        p=basis[words.index(w)];i=next(j for j,x in enumerate(w) if x)
        qi=next(x for x in range(1,4) if x!=w[i]);qw=[0]*3;qw[i]=qi
        q=basis[words.index(tuple(qw))];r=1j*p@q
        # Signed noisy-product averaging and readout deconvolution.
        ri=coefficients(r,basis);ind=int(np.argmax(np.abs(ri)));rw=words[ind];sgn=ri[ind]
        support=[j for j,x in enumerate(rw) if x];polar=[.71,.83,.76]
        gp=(g[:,words.index(tuple(qw))][:,None,None]*basis).sum(axis=0)
        lhs=np.trace(r@gp).real/dim
        avg=0.
        for sig in itertools.product([-1,1],repeat=len(support)):
            assigns=dict(zip(support,sig));rho=kron([(I+assigns[j]*polar[j]*P[rw[j]])/2 if j in assigns else I/2 for j in range(3)])
            ideal=np.trace(rho@gp).real;b=.07;c=.68
            noisy=b+c*ideal
            avg+=sgn*np.prod(sig)*(noisy-b)/c/np.prod([polar[j] for j in support])/2**len(support)
        assert abs(lhs-2*h)<1e-12 and abs(avg-lhs)<1e-12
        finite=[]
        for t in [.1,.05,.025,.0125]:
            evolved=sum(x*a for x,a in zip(expm(t*g)[:,words.index(tuple(qw))],basis))
            est=np.trace(r@evolved).real/dim/(2*t)
            finite.append({'t':t,'estimate':est,'error':abs(est-h)})
        isolation.append({'coefficient':h,'exact_isolation':lhs,'noisy_score_derivative':avg,'finite_difference':finite})
    g2,_,_=generator(3,[(-.44,(2,0,3)),(.12,(0,1,0))],.7)
    t1=.17;t2=.29
    o=np.zeros(64);o[words.index((3,0,0))]=1
    correct=expm(t1*g)@expm(t2*g2)@o
    wrong=expm(t2*g2)@expm(t1*g)@o
    chronology_error=float(np.linalg.norm(correct-wrong))
    assert chronology_error>1e-4
    s=3/(2*.7)
    early=expm((s/2)*g)@expm((s/2)*g2)
    smooth=[]
    for _ in range(12):
        x=rng.normal(size=64);y=early@x
        a=sum(c*b for c,b in zip(y,basis))
        ratio=float(np.max(np.abs(np.linalg.eigvalsh(a)))/np.linalg.norm(x))
        assert ratio<=2+1e-11;smooth.append(ratio)
    # Exact one-site stationary bias from a small amplitude damping perturbation.
    gamma=.7;floor=[]
    for eta in [.001,.01,.1]:
        gg,ww,bb=generator(1,[(0.,(3,))],gamma,eta)
        z=np.zeros(4);z[ww.index((3,))]=1
        val=float((expm(100*gg)@z)[0]);expected=eta/(gamma+eta)
        assert abs(val-expected)<1e-12
        floor.append({'eta':eta,'late_local_Z':val,'exact_bias':expected})
    assert sum(math.comb(3,k)*math.factorial(k)*2**(k+1) for k in range(4))==158
    return {'status':'PASS','physical_experiments':0,'scope':'finite floating-point algebra fixtures only','signed_noisy_acquisition':isolation,'time_ordering_wrong_order_HS_error':chronology_error,'nonautonomous_smoothing_ratios':smooth,'nonunital_uncertainty_floor':floor,'stability_kernel_integral':158}
if __name__=='__main__':
    out=run();p=Path(__file__).with_suffix('.json');p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':out['status'],'report':str(p),'max_smoothing_ratio':max(out['nonautonomous_smoothing_ratios']),'wrong_order_error':out['time_ordering_wrong_order_HS_error']}))
