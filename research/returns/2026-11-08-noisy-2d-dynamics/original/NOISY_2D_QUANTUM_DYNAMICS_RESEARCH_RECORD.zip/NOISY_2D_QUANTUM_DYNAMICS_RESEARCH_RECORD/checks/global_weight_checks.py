"""Small synthetic checks of time-varying exponential Pauli-weight smoothing."""
import json, math
from pathlib import Path
import numpy as np
from principal_checks import generator,expm

def run():
    records=[]
    terms=[(.31,(1,3,0)),(-.27,(0,2,1)),(.19,(3,0,0)),(.13,(0,0,2))]
    n=3;k=2;d=3;J=.4;gamma=.7
    g,words,basis=generator(n,terms,gamma)
    g2,_,_=generator(n,[(-.33,(2,0,3)),(.22,(0,1,0))],gamma)
    w=np.array([sum(x!=0 for x in word) for word in words])
    theta=min(1/(2*k),gamma/(16*k*d*J))
    for t in [.0001,.001,.01,.1,1.,3.,10.]:
        alpha=min(gamma*t/2,theta);weight=np.diag(np.exp(alpha*w))
        for schedule in ['static','switched']:
            u=expm(t*g) if schedule=='static' else expm(.37*t*g)@expm(.63*t*g2)
            left=float(np.linalg.svd(weight@u,compute_uv=False)[0])
            right=float(np.linalg.svd(u@weight,compute_uv=False)[0])
            worst=0.
            for j in range(1,len(words)):
                worst=max(worst,float(np.linalg.norm(u[:,j])*math.exp(alpha*w[j])))
            assert left<=1+2e-11 and right<=1+2e-11 and worst<=1+2e-11
            records.append({'time':t,'schedule':schedule,'weighted_forward_norm':left,'weighted_dual_norm':right,'largest_homogeneous_ratio':worst})
    # A local Hermitian contraction has a bounded identity/traceless mixture.
    rng=np.random.default_rng(1138);max_mix=0.
    for _ in range(80):
        a=float(rng.uniform(-1,1));v=rng.normal(size=3);v=v/np.linalg.norm(v)*rng.uniform(0,1-abs(a))
        o=a*np.eye(2,dtype=complex)
        local=[np.array([[0,1],[1,0]],complex),np.array([[0,-1j],[1j,0]],complex),np.diag([1,-1])]
        o+=sum(x*p for x,p in zip(v,local))
        beta=float(np.linalg.norm(v));axis=sum(x*p for x,p in zip(v/beta,local))
        assert abs(a)+beta<=1+1e-12
        assert np.linalg.norm(o-(a*np.eye(2)+beta*axis))<1e-12
        assert np.linalg.norm(axis@axis-np.eye(2))<1e-12
        max_mix=max(max_mix,abs(a)+beta)
    return {'status':'PASS','physical_experiments':0,'scope':'finite floating-point fixtures only','theta':theta,'weight_cases':records,'hermitian_mixture_cases':80,'largest_mixture_mass':max_mix}
if __name__=='__main__':
    result=run();p=Path(__file__).with_suffix('.json');p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'cases':len(result['weight_cases']),'theta':result['theta']}))
