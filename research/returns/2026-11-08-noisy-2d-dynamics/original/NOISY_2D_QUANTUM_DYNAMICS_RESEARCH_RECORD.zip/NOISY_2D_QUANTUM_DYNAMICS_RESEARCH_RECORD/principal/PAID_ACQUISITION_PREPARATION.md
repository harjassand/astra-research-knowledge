# Finite-rate reset implementation of the acquisition input contract

This appendix specifies one paid realization of the noisy product preparation
used in LOCAL_ROBUST_PREDICTION.md. It does not assume the unknown drift can be
turned off. It is an additional acquisition control, not an allowed operation
in the later replacement-only prediction dynamics. It supplies no fixed-hardware
or total-cost advantage.

## Reset primitive and physical meaning

For each local setting sigma choose a known full-rank qubit state
sigma_i=(I+s_i p_i R_i)/2, p_i>=p0>0. The preparation mechanism applies the
replacement map R_i(X)=sigma_i tensor Tr_i X at Poisson rate kappa. A reset is
a swap with a fresh ancilla in state sigma_i, followed by discarding the old
qubit. The ancilla state can be a fixed-temperature Gibbs qubit with fixed
energy gap, rotated into the selected axis. A numerical guarantee for its
polarization/rotation/measurement errors is part of the calibrated primitive;
it is not inferred from a bath label or unknown hardware.

The source remains subject to its unknown H_0 and replacement noise during
preparation. Let Gamma=2dJ_0+2gamma and n be the number of sites. The diamond
norm of their total generator is <=n Gamma. In comparison, the reset-only
generator kappa sum_i(R_i-Id) has the exact product sigma= tensor_i sigma_i
as fixed point. It is within trace distance 2n exp(-kappa tau) of sigma at
time tau from every initial state: couple to the event that each site was
reset at least once. This argument remains valid for correlated initial states.

CPTP Duhamel gives a second error <=n Gamma tau from the always-on unknown
drift/noise. Therefore the actual prepared state satisfies

    ||rho_prepared-sigma||_1
       <=2n exp(-kappa tau)+n Gamma tau.                    (1)

No microscopic state or unknown Hamiltonian needs to be solved to obtain (1).

## Explicit finite choices and costs

For a target preparation trace error b in (0,1), take an integer

    L>=ceil(log_2(16n/b)),
    tau=b/(4n Gamma),
    kappa=L/tau=4n Gamma L/b.

Then (1) is <b/2. Gamma=0 is a trivial direct-reset case and may use any
declared positive upper bound instead. All times/rates are rational. The reset
strength is finite but grows polynomially in n and b^-1. The physical model
must actually provide that strength; a fixed maximum rate does not warrant it.

There are n L expected swaps and fresh thermal ancillas per preparation.
An explicit Poisson tail gives a finite high-confidence cap of
O(nL+log(1/delta_prep)) reset events; truncating runs at such a cap costs the
declared failure probability or corresponding trace-error budget. The apparatus
must provide instantaneous event rate n kappa, source duration tau, axis control,
and ancilla preparation/delivery at its declared per-ancilla time/energy/work.
These are paid resources. A Poisson Lindblad reset is the model of that mechanism,
not a proof of a particular reservoir's all-time Markovian approximation.

For signed acquisition scores bounded by A_acc, an initial trace error b changes
the mean score by at most A_acc b. Choose

    b<=alpha t/(16 A_acc)

to fit the coefficient-learning bias allocation, where t=O(alpha/Gamma^2)
is the subsequent interrogation time. Thus b^-1 and kappa are polynomial in
the requested inverse coefficient accuracy, and physical precision need not
be exponentially small in n. Known fixed component errors in each reset alter
the calibrated target sigma_i or add a declared floor; repetition does not remove
unknown systematic errors.

This is one conservative way to pay an experimental input interface. It is much
less economical than ideal simultaneous product preparation or stronger existing
learning protocols. If only a fixed reset rate or an uncharacterized bath is
available, the correct result is the operational preparation-bias floor in the
main learning theorem, not arbitrary-accuracy acquisition. The later predictor
does not simulate unknown cooling interventions at arbitrary accuracy.
