from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
ROWS=[
('C0','ESTABLISHED_CAPITAL','Original static2D specified-product fixed-local additive predictor','sources/original/Case_B_second_final/RESEARCH_REPORT.txt'),
('G1','PROVED','Moving exponential Pauli-weight smoothing and Hamiltonian-sign duality','machinery/FINAL_GLOBAL_READOUT_THEOREM.md'),
('G2','PROVED_USING_PINNED_CAPITAL','All-time unital GLOBAL Hermitian product-readout prediction','machinery/FINAL_GLOBAL_READOUT_THEOREM.md'),
('G3','PROVED','Explicit drives and binary-horizon numerical complexity','machinery/FINAL_GLOBAL_READOUT_THEOREM.md'),
('G4','PROVED','Uniform floor-rate and correlated Pauli jump extension, with paid rates/action','machinery/FINAL_GLOBAL_READOUT_THEOREM.md'),
('G5','PROVED','Paid generative mixtures and loglog Q_bin prepared sources','machinery/FINAL_GLOBAL_READOUT_THEOREM.md'),
('B1','PROVED_USING_PINNED_CAPITAL','Biased full-rank reference-preserving2D local predictor','principal/BIASED_RESET_CONSTRUCTION.md'),
('B2','PROVED','SWAP-and-KEEP positive reset buffer with accuracy-based row cap','principal/BIASED_RESET_CONSTRUCTION.md'),
('B3','PROVED_USING_PINNED_CAPITAL','Biased common-reference GLOBAL Hermitian product-readout prediction','principal/BIASED_GLOBAL_READOUT_CLOSURE.md'),
('B4','PROVED','Constructive local pinching from global charge conservation','principal/CONSERVATION_TWIRL_AND_DRESSING.md'),
('B5','PROVED_ROUTINE_CONSEQUENCE','Known fixed-depth dressed references, local and Clifford Pauli readout scopes','principal/CONSERVATION_TWIRL_AND_DRESSING.md'),
('T1','PROVED_SUPPORTING_COMPOSITION','All-time full-TV sampler on supplied bounded-cut architectures; TTN input','initial/constructor.md'),
('T2','PROVED_SUPPORTING_COMPOSITION','Faithful biased-reset bounded-cut full-TV sampler','ambitious/SAMPLING_FRONTIER.md'),
('M1','PROVED_KNOWN_MACHINERY_CONSEQUENCE','Log-time relative operator-order mixing, arbitrary input/geometry','constructor/RELATIVE_MIXING_AND_SAMPLING_OBSTRUCTION.md'),
('M2','PROVED_KNOWN_MACHINERY_CONSEQUENCE','Faithful-reference late relative operator-order certificate','ambitious/SAMPLING_FRONTIER.md'),
('A1','PROVED_AT_EXPLICIT_ACCESS_CONTRACT','Noisy local drift acquisition and paid finite-rate preparation','principal/LOCAL_ROBUST_PREDICTION.md'),
('A2','PROVED_KNOWN_MACHINERY_APPLICATION','Volume/time-uniform driven LOCAL perturbation stability','principal/LOCAL_ROBUST_PREDICTION.md'),
('A3','PROVED','GLOBAL all-time error with extensive M log n factor','principal/GLOBAL_LEARNED_REUSE.md'),
('A4','PROVED_COMPOSITION','Reusable learned coherent-intervention predictor with calibration floors and physical costs','principal/GLOBAL_LEARNED_REUSE.md'),
('S1','PROVED_CONSEQUENCE','TV sampling logarithmically many arbitrary global syndrome bits','auditor/NONLOCAL_READOUT_COMPOSITION.md'),
('S2','PROVED_CONSEQUENCE','Trace-norm tomography of a logarithmic global logical-Pauli algebra','auditor/NONLOCAL_READOUT_COMPOSITION.md'),
('P1','PROVED','Fixed-local probability floor; conditioning with inverse-promise cost','initial/auditor.md'),
('H1','PROVED_REDUCTION_CONDITIONAL_CONSEQUENCE','Original-class all-positive-time log/relative evaluator implies NP=RP','ambitious/FINAL_RELATIVE_OBSTRUCTION.md'),
('H2','PROVED_COUNT_EMBEDDING','Mixed tile one-Y phase and degree-balanced count approximation','ambitious/FINAL_RELATIVE_OBSTRUCTION.md'),
('H3','PROVED_REDUCTION_CONDITIONAL_CONSEQUENCE','Faithful conserving biased-reset dual-rail relative obstruction','ambitious/FINAL_RELATIVE_OBSTRUCTION.md'),
('O1','DISPROVED_IMPLICATION','Generic constant buffer converts normalized HS to pointwise error','initial/auditor.md'),
('O2','CONDITIONAL_HARDNESS','Arbitrary circuit-described input local prediction implies BQP=BPP','initial/auditor.md'),
('O3','DISPROVED_IMPLICATION','Individual exponential Fourier decay suffices for relative/TV truncation','constructor/RELATIVE_MIXING_AND_SAMPLING_OBSTRUCTION.md'),
('O4','DISPROVED_IMPLICATION','All bounded-product mean access at inverse-poly precision determines general TV law','constructor/RELATIVE_MIXING_AND_SAMPLING_OBSTRUCTION.md'),
('O5','DISPROVED_PROOF_INGREDIENT','Finite-g Euler-Poisson CPTP assertion for arbitrary local Hamiltonian generator','ambitious/SAMPLING_FRONTIER.md'),
('F1','OPEN_NOT_ACHIEVED','Generic original2D intermediate-time full-output TV sampler','ambitious/SAMPLING_FRONTIER.md'),
('F2','OPEN','Relative/log output probabilities with a positive constant lower-time promise','ambitious/FINAL_RELATIVE_OBSTRUCTION.md'),
('F3','OPEN','Arbitrary-accuracy nonunital dynamics beyond known-reference conservation','machinery/CROSS_REVIEW.md'),
('F4','OPEN_NOT_ACHIEVED','General acquired reusable predictor for arbitrary driven interacting matter','principal/DOSSIER_CLOSING.md'),
]
def build():
    out={'project':'Noisy2D quantum dynamics generalization','research_return':'COMPLETE_AT_REPORTED_SCOPES','broad_general_sampler':'OPEN_NOT_ACHIEVED','historical_priority':'UNKNOWN','practical_advantage':'NOT_ESTABLISHED','physical_experiments':0,'full_worst_case_implementation':False,'entries':[{'id':i,'status':s,'claim':c,'proof':p} for i,s,c,p in ROWS]}
    p=ROOT/'principal/THEOREM_LEDGER.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'path':str(p),'entries':len(ROWS)}))
if __name__=='__main__':build()
