## Existing machinery, exact predecessors and novelty audit

| Operation | Verified primary predecessor | Added operation and exact distinction |
|---|---|---|
| Sparse coefficient propagation | Angrisani et al2609.40174v2 LemmaS6, LemmaS15/CorS16, weighted CorS12/ThmS20 | Source operational averages retain their quantifiers; moving-weight differentiation/duality and pointwise buffers are proved here. |
| Tracial HC | King1210.8412v1 Thm1/Cor2 | Normalized Schatten convention; varying-exponent Hamiltonian interleaving is explicitly proved. |
| Faithful HC | Dong et al2606.17729v1 Thm1.1; earlier BDR1804.10100v2 Thm21/25 | All-operator symmetric weighted norms; coherent invariance checked, not assumed for arbitrary drives. |
| Time-dependent locality | Barthel--Kliesch1111.4210v2 Thm1/2 | Bounded range/strength/degree and shell hypotheses hold; size independence alone is not inverse-accuracy polynomiality. |
| Factorial buffer locality | HHKL1801.03922v4 Lemma5, AppendixC.4(48)--(49) | Accumulated physical action controls strips; reset permutations keep spatial locality. |
| Overlap architecture | BGM1909.11485v1 Thm5 | Existing shallow-circuit product-readout idea; continuous action and reset-register dimensions are actually paid. |
| TTN operations | Shi--Duan--Vidal quant-ph/0511070v2 Thm1--4 and LOCC sampling; Seitz et al2206.01000v3 Sections2.2/3.2 | Supporting full-TV theorem composes cut action, constructive vector error and entropy cutoff. No firstness claimed. |
| Acquired generator | Mobus et al2606.23652v1 Thm4.5, Thm8.2/Cor8.3 | Learning and local verification are established. This dossier pays efficient evaluation and controlled reuse. The simple alpha^-4 learner is suboptimal. |
| Local stability | Lucia et al1409.7809v2 Thm1 | Known rapid-mixing mechanism; explicit nonautonomous near/far proof supplied. Global uncertainty pays an extensive factor. |
| Strong discrete sampler | Nelson et al2610.00548v2 Thm2.3/Prop2.2, AppendixA | Fixed per-layer p and strict cones. Substitution p~gamma h is nonuniform as h vanishes. |
| Noisy MPO comparator | Shao et al2606.00474v1 Thm1/Prop1, AppendixD.3 | Late relative-HS plus purity CAN imply trace bounds. Fixed-error/existence, cheap construction, positivity and h-uniformity remain separate. |
| Nonunital simulation | Martinez et al2501.13050v1 Thm1; Angrisani et al2501.13101v2 Thm1 | Strong parameter/circuit-average results do not cover each deterministic conserving continuous H(t). |
| Tiling reduction | Moore--Robson math/0003039v1 Sections2,3/3.1 | Right-tromino NP; mixed-tile parsimonious #SAT. No #P claim for right trominoes alone. |

Exact hypotheses, applicability proofs, source hashes and proof checks are in
the embedded constructions and supporting primary-source reviews. Targeted
Zenodo searches inspected records19206525,20109357,17594402,23418780,23414157,
21455333 and related metadata. These are frame/TTN software or numerical/support
artifacts, not imported uniform theorems. Limited searches or metadata reads
are not a clearance of every recent work. Historical firstness remains UNKNOWN.

### A verified source-proof objection at its exact scope

Trivedi--Cirac PRL129260405 remains a relevant published HIGH-noise TV-sampling
statement. This campaign independently found a false CP assertion in the
printed uniformization proof, arXivv2 Lemma3 and the published supplement's
Lemma3: Id+L/g need not be CPTP for any finite g. For H=Z the normalized Choi
compression is [[1,i/g],[-i/g,0]], determinant -1/g^2. For a weight>=2 Pauli H,
only single-site replacement noise leaves the corresponding lower diagonal
zero. The exact Schur-range characterization and valid first-order Kraus repair
are in SAMPLING_FRONTIER.md. A repair retaining coherent no-jump drift does not
restore the same rare-horizontal-edge argument automatically.

This is NOT a disproof of the high-noise theorem conclusion. No complete repaired
proof was cleared here. Earlier comparator wording calling that proof independently
verified is superseded by this precise objection and the final reviews. None of
the positive results here uses that assertion: they use genuine Cayley unitary
channels and actual reset events. All existing theorem statements remain at
their exact working scopes; the objection is separately preserved.

## Remaining decisive problems and constructive attacks

1. **Generic intermediate-time 2D full-TV sampling.** Construct a positive
   representation or connected expansion controlling global error before
   conditioning. Individual weight decay and all-product additive access are
   provably insufficient. No target-class TV hardness follows from the rare
   tiling reduction or from failure of this representation.
2. **Continuous connected activities.** Replace strict circuit cones by soft
   factorial tails and prove computable Kotecky--Preiss bounds uniform in the
   fine time step. A relative theorem beyond a constant physical threshold
   remains a different target from the all-positive-time relative evaluator
   obstructed by the reduction. The T>=constant regime is not settled by tiny T.
3. **Arbitrary weak nonunital violation of the conserved reference.** Stability
   supplies an uncertainty floor; arbitrary accuracy needs constructible
   connected response/renewal control. Generic cooling/fault-tolerance results
   alter resources and do not prove hardness at arbitrarily tiny bias for one
   fixed noise ratio. Reference preservation here is substantive.
4. **Unknown interacting stationary references and macroscopic interventions.**
   Their acquisition, sufficient histories and evaluation must be constructed.
   A formal Gibbs or memory functional can still hide the many-body problem.
   Known finite-depth dressed references do not solve that general operation.
5. **Recovery and extensive decoding.** Logarithmically many nonlocal syndrome
   bits or a logarithmic logical Pauli algebra are earned. Arbitrary syndrome-
   conditioned recovery and n-bit output laws are not. The noisy-code example
   gives a precise finite-precision predictive-sufficiency obstruction.
6. **Useful resource regimes and 3D.** No matched practical superiority is
   demonstrated. The current 2D overlap proof pays boundary action; 3D needs
   another representation/contraction. A failed separator bound is not hardness.

Preserved failures/repairs include RMS-to-pointwise substitution, wrong buffer
chronology, treating biased reset as mixed unitary, discarding old registers,
independently resampling the inverse/parity history, treating weighted factors
as norm1, an invalid sigma-centered bounded mixture, rounding without HS budget,
making the row cap depend on confidence rather than accuracy, rare-prefix
division, and the false finite-rate Euler CP shortcut. The supporting record
retains each correction. A short-time local-relative Taylor idea remains a
candidate only; no unreviewed theorem is promoted from it.

## Independence, validation and completion accounting

Exactly three initial GPT-6.1 Sol max researchers plus the principal each wrote
and froze an initial construction before receiving another researcher's ideas.
The principal read two completed initials after its own freeze while the third
researcher was still writing, and sent that researcher no constructions before
its freeze. This was individual initial independence, not a simultaneous sealed
group freeze. The user subsequently
authorized one additional ambitious researcher, also Sol max, which froze its
own initial before exchange. Original initials remain immutable; hashes and
exposure timing are recorded. No additional agents were created.

Completed internal mathematical reviews are accepted at their actual scopes;
they are not relabeled unreviewed. They are distinct from priority, hardware,
full implementation or journal review. Reviewed component hashes/snapshots and
final assembly checks are retained. All central claims have analytic proofs;
finite floating/exact-rational checks supplement them.

Execution records include original truncation/strip audits; independent weight,
HC, TTN, reset/SWAP, cap and code-law checks; exact rational/Gaussian-integer
tiling/dual-rail coefficients; and exact Choi tests. Principal reruns have tied
script/output hashes. No full worst-case predictor was executed. No physical
experiments, paper publication, website/Zenodo release, third-party communication
or completed Capital integration is claimed by this return.
