from pathlib import Path
import hashlib,json,shutil,subprocess,time,sys
ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT/'verification-rerun'
CASES=[('checks/principal_checks.py',[]),('checks/global_weight_checks.py',['checks/principal_checks.py']),('checks/original_audit_rerun.py',[]),('constructor/audit_biased_reset.py',[]),('auditor/biased_global_checks.py',[]),('constructor/audit_ambitious_independent.py',[]),('ambitious/audit_dualrail.py',['ambitious/audit_rare_event.py'])]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    DEST.mkdir(exist_ok=True);rows=[]
    for index,(name,deps) in enumerate(CASES):
        sub=DEST/str(index);sub.mkdir(exist_ok=True)
        for f in [name]+deps:shutil.copyfile(ROOT/f,sub/Path(f).name)
        target=sub/Path(name).name;start=time.monotonic()
        try:
            run=subprocess.run([sys.executable,str(target)],cwd=ROOT,capture_output=True,text=True,timeout=150)
            (sub/'stdout.txt').write_text(run.stdout);(sub/'stderr.txt').write_text(run.stderr)
            row={'script':name,'sha256':sha(target),'exit_code':run.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':sha(sub/'stdout.txt'),'stderr_sha256':sha(sub/'stderr.txt'),'reports':[]}
            for p in sub.glob('*.json'):
                json.loads(p.read_text());row['reports'].append({'path':str(p.relative_to(ROOT)),'sha256':sha(p)})
        except Exception as error:row={'script':name,'sha256':sha(target),'error':repr(error),'exit_code':None}
        rows.append(row);(DEST/'RERUN_REPORT.json').write_text(json.dumps({'scope':'finite fixtures only, not uniform proof','physical_experiments':0,'runs':rows,'all_exits_zero':all(x['exit_code']==0 for x in rows)},indent=2)+'\n')
        print(json.dumps({'script':name,'exit_code':row['exit_code'],'seconds':row.get('elapsed_seconds'),'error':row.get('error')}),flush=True)
    if not all(x['exit_code']==0 for x in rows):raise SystemExit(1)
if __name__=='__main__':main()
