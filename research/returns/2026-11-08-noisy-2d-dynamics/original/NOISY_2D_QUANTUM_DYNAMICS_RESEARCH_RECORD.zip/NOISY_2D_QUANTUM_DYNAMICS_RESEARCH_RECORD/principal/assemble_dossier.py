from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parents[1]
RECORD='NOISY_2D_QUANTUM_DYNAMICS_RESEARCH_RECORD'
COMPONENTS=[
('Faithful-reference local constructor and positive buffer','principal/BIASED_RESET_CONSTRUCTION.md',None,None),
('Global biased-readout closure','principal/BIASED_GLOBAL_READOUT_CLOSURE.md',None,None),
('Global conservation and known dressing','principal/CONSERVATION_TWIRL_AND_DRESSING.md',None,None),
('Simpler whole-block buffer','auditor/BIASED_RESET_BUFFER_SIMPLIFICATION.md',None,None),
('Unital global theorem and quantitative cost closure','machinery/FINAL_GLOBAL_READOUT_THEOREM.md',None,None),
('Full-output sampler on bounded interaction cuts','initial/constructor.md','## 3. Formal sampling theorem','## 7. Primary-source comparison'),
('Biased sampling, late relative certificates and source repair','ambitious/SAMPLING_FRONTIER.md',None,None),
('Acquired local prediction and complete uncertainty','principal/LOCAL_ROBUST_PREDICTION.md',None,None),
('Finite-rate physical acquisition preparation','principal/PAID_ACQUISITION_PREPARATION.md',None,None),
('Global learned reuse with extensive uncertainty','principal/GLOBAL_LEARNED_REUSE.md',None,None),
('Relative mixing and all-product oracle insufficiency','constructor/RELATIVE_MIXING_AND_SAMPLING_OBSTRUCTION.md',None,None),
('Nonlocal syndrome laws and logical algebras','auditor/NONLOCAL_READOUT_COMPOSITION.md',None,None),
('Rare-output hardness and biased dual-rail extension','ambitious/FINAL_RELATIVE_OBSTRUCTION.md',None,None),
]
def build():
    parts=[(ROOT/'principal/DOSSIER_HEADER.md').read_text(),f'\n[Supporting record index]({RECORD}/INDEX.md) · [Theorem ledger](NOISY_2D_QUANTUM_DYNAMICS_THEOREM_LEDGER.json).\n'];pins=[]
    for i,(title,path,start,end) in enumerate(COMPONENTS,1):
        raw=(ROOT/path).read_bytes();content=raw.decode();sha=hashlib.sha256(raw).hexdigest()
        if start:content=content[content.index(start):]
        if end:content=content[:content.index(end)]
        content=re.sub(r'^(#{1,6}) ',lambda m:'#'*min(6,len(m[1])+2)+' ',content,flags=re.M)
        parts.append(f'\n## Proof component {i}: {title}\n\nSource: [{path}]({RECORD}/{path}), SHA256 `{sha}`.\n\n'+content)
        pins.append({'title':title,'path':path,'sha256':sha})
    parts.append((ROOT/'principal/DOSSIER_CLOSING.md').read_text())
    parts.append('\n## Review files\n\n')
    for folder in ['machinery','constructor','auditor']:
        for path in sorted((ROOT/folder).glob('*REVIEW.md')):
            if path.name=='FINAL_DOSSIER_REVIEW.md':continue
            raw=path.read_bytes();rel=path.relative_to(ROOT).as_posix();parts.append(f'- [{rel}]({RECORD}/{rel}) — SHA256 `{hashlib.sha256(raw).hexdigest()}`.\n')
    parts.append(f'\n[Final assembly review]({RECORD}/auditor/FINAL_DOSSIER_REVIEW.md).\n')
    content='\n'.join(parts)
    rules=[('V_[v,u](A)','V_{[v,u]}(A)'),('+[4log(2n)+4](2Mpar alpha+Mmiss b_miss)/gamma','+[4log(2n)+4] * (2Mpar alpha+Mmiss b_miss)/gamma'),('sum_[P=X,Y,Z](Ad_[P_i]-Id)','sum_{P=X,Y,Z}(Ad_[P_i]-Id)')]
    changes=[]
    for before,after in rules:
        count=content.count(before)
        if count!=1:raise ValueError((before,count))
        content=content.replace(before,after);changes.append({'before':before,'after':after,'count':count})
    (ROOT/'principal/FORMAT_DELTA.json').write_text(json.dumps({'scope':'three notation-only replacements; pinned proof component bytes unchanged','changes':changes},indent=2)+'\n')
    out=ROOT/'principal/DOSSIER_DRAFT.md';out.write_text(content)
    (ROOT/'principal/DOSSIER_COMPONENT_PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
    print(json.dumps({'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'components':len(pins)}))
if __name__=='__main__':build()
