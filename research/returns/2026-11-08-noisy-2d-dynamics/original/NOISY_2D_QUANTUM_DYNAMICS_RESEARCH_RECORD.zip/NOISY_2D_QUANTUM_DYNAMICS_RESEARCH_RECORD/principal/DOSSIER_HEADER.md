# Noisy 2D quantum dynamics: global prediction, faithful resets, and the sampling frontier

Research dossier, 8 November 2026. No manuscript or public release commissioned.

## Strongest result actually achieved

The fixed-local theorem extends to **arbitrary global products of one-qubit
Hermitian contractions, at all times and every fixed positive noise ratio**.
A second construction extends that capability to **full-rank biased resets
with a known faithful product reference preserved by the coherent dynamics**.
This is arbitrary-accuracy nonunital prediction in that class, beyond a
perturbation floor. The class does not include arbitrary cooling or generic
interacting thermal matter.

The new operations are moving coefficient-weight smoothing with Hamiltonian-sign
duality, support-sensitive hypercontractivity, and a positive buffer that KEEPS
discarded reset registers. A concentration bound pays all added registers and
retains polynomial tensor dimensions. Their proofs and finite resource contracts
are included below, together with independent mathematical reviews.

Supporting results earn full-output TV sampling on **supplied bounded-cut
architectures**, acquisition of a local drift and reusable intervention prediction,
late-time relative mixing, and joint laws of logarithmically many nonlocal
syndromes. Geometry, source, precision and control costs remain explicit.

The strongest obstructions are (i) an original-class rare-probability reduction
which rules out a uniform all-positive-time log/relative evaluator unless NP=RP,
and (ii) a positive noisy-code family whose every bounded-product mean is
exponentially close to uniform while its TV distance from uniform tends to one.
Neither proves hardness of the unresolved generic 2D full-TV sampler.

**Generic intermediate-time 2D full-output sampling remains OPEN.** General
acquired prediction of arbitrary interacting driven matter, arbitrary recovery,
and affordable protected quantum processing remain NOT_ACHIEVED. Polynomial
degrees here can be enormous; no practical superiority, hardware demonstration
or historical first-priority claim is made. Physical experiments:0.

## Governing capital and central formal theorem

The unchanged original proof is `Case_B_second_final/RESEARCH_REPORT.txt`,
SHA256 `32b605ec5ccdc6897af1a24b1be951e0e3ad787a0b4fbff679541d1980ca841b`.
Its original ZIP hash is `d593fd3abe3165e61b38275b95c4a50d1e4ef6b49c1f9774823432aafd7e9283`.
Repository snapshot: `6f26484e44ff347429415f1765892fe34e8c6cc3`,
`research/returns/2026-11-07-p1-final-own-depth-case-b`. The full proof was
independently inspected before extension. Gibbs uniqueness and the separate
thermal-memory results are not load-bearing dependencies here.

**Theorem G.** Fix local range a, block size k, incidence d, g>=J/gamma>0,
and faithful floor nu0>0. Supply n square-lattice qubits, a finite rational
piecewise local Hamiltonian schedule H(t)=sum_b H_b(t) with the fixed bounds,
rational gamma>0 and sigma=diag(p,1-p), min(p,1-p)>=nu0. For biased sigma assume
[H(t),sigma^n]=0. Local charge pinching constructs a reference-preserving block
decomposition without increasing norms, range or incidence. At sigma=I/2 there
is no charge-conservation restriction. The evolution is exactly

    L_t(rho)=-i[H(t),rho]+gamma sum_i(sigma_i tensor Tr_i rho-rho).

For specified rational product input, O=tensor_i O_i with ANY Hermitian
one-qubit contractions, rational T>=0, error epsilon and failure delta, there
is a finite-work classical randomized predictor satisfying

    Pr[|fhat-Tr(O rho_T)|<=epsilon]>=1-delta.

BIT work is polynomial in complete input length B,n,epsilon^-1,log(1/delta),
with degree/prefactor depending on a,k,d,g,nu0. Binary T is part of B; a mixing
test removes large numeric horizons before dynamics. Rate-digit evaluation,
every control segment, numerical precision and randomness are paid. Neither
vanishing noise nor pure-reset limits have a uniform polynomial degree.

This includes global parity and ADDITIVE probabilities of arbitrary partial
product projectors. It does not include relative rare probabilities, a full
n-bit sampler, arbitrary complex products without a paid LCU norm, arbitrary
circuit-described sources, or Gibbs(H). The invariant reference is sigma^n,
generally not Gibbs for the full interacting H.

Prepared inputs of explicit depth c[1+log(2+log Q_bin)] and efficiently generated
classical mixtures can be included with their proved causal-cone/action and
generative costs. Q_bin uses binary input length, not numeric T. Additional
variable-rate/correlated-Pauli noise is a separate UNITAL extension, not an
automatic extension preserving a biased reference.

## Proof and dependency structure

The following complete component proofs are embedded with their exact hashes.
The weighted local constructor establishes sparse propagation and the reset-
register buffer. The next proof supplies physical-support damping, global
branches and bounded Hermitian mixtures. The unital proof records explicit
coefficient, gate, rank and bit bounds. Further sections give sampler/service
theorems and exact obstructions. Supporting source/version/review records are
included in the archive. A passing finite script or polished artifact is not
used in place of a central proof or priority check.
Components retain their original research-stage wording. References within them
to a candidate or ongoing review are historical; the final ledger and completed
reviews give the current status at exactly the scopes they checked.
