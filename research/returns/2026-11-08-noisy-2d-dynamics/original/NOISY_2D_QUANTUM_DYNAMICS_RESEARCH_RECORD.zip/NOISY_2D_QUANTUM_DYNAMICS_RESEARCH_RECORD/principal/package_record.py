from pathlib import Path
import hashlib,json,re,shutil,zipfile,datetime
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parents[1]/'outputs'
BASE='NOISY_2D_QUANTUM_DYNAMICS'
RECORD=OUT/(BASE+'_RESEARCH_RECORD')
DOS=OUT/(BASE+'_RESEARCH_DOSSIER.md')
LED=OUT/(BASE+'_THEOREM_LEDGER.json')
ZIP=OUT/(BASE+'_RESEARCH_RECORD.zip')
VAL=OUT/(BASE+'_VALIDATION.json')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check_initials():
    data=json.loads((ROOT/'initial/FROZEN_MANIFEST.json').read_text())
    for x in data['frozen_reports']:
        assert sha(ROOT/'initial'/(x['role']+'.md'))==x['sha256']
    extra=json.loads((ROOT/'initial/INDEPENDENCE_ACCOUNT.json').read_text())['fourth_initial']
    assert sha(ROOT/extra['path'])==extra['sha256']
def main():
    if any(p.exists() for p in [RECORD,DOS,LED,ZIP,VAL]):raise RuntimeError('Final output already exists; refuse unreviewed overwrite.')
    review=ROOT/'auditor/FINAL_DOSSIER_REVIEW.md'
    assert review.exists(),'Final assembly review is required before packaging.'
    finalhash=sha(ROOT/'principal/DOSSIER_DRAFT.md')
    assert finalhash in review.read_text(),'Final review must name actual final dossier hash.'
    check_initials()
    sourcepin=json.loads((ROOT/'sources/SOURCE_PIN.json').read_text())
    assert sha(ROOT/'sources/Case_B_second_final_2026-11-07.zip')==sourcepin['source_zip_sha256']
    for x in sourcepin['files']:
        p=Path(x['path']);assert p.is_relative_to(ROOT)
        assert sha(p)==x['sha256'] and p.stat().st_size==x['bytes']
    pins=json.loads((ROOT/'principal/DOSSIER_COMPONENT_PINS.json').read_text())
    for x in pins:assert sha(ROOT/x['path'])==x['sha256']
    rerun=json.loads((ROOT/'verification-rerun/RERUN_REPORT.json').read_text());assert rerun['all_exits_zero']
    for x in rerun['runs']:
        assert sha(ROOT/x['script'])==x['sha256']
        for report in x['reports']:assert sha(ROOT/report['path'])==report['sha256']
    ledger=json.loads((ROOT/'principal/THEOREM_LEDGER.json').read_text())
    ids=[x['id'] for x in ledger['entries']];assert len(ids)==len(set(ids))
    assert ledger['physical_experiments']==0 and ledger['broad_general_sampler']=='OPEN_NOT_ACHIEVED'
    for x in ledger['entries']:assert (ROOT/x['proof']).exists()
    OUT.mkdir(exist_ok=True);RECORD.mkdir()
    for folder in ['initial','sources','principal','machinery','constructor','auditor','ambitious','checks','verification-rerun']:
        shutil.copytree(ROOT/folder,RECORD/folder,ignore=shutil.ignore_patterns('__pycache__','.DS_Store'))
    shutil.copyfile(ROOT/'principal/DOSSIER_DRAFT.md',DOS)
    shutil.copyfile(ROOT/'principal/THEOREM_LEDGER.json',LED)
    intro=['# Supporting research record','',f'Dossier: [{DOS.name}](../{DOS.name})',f'Ledger: [{LED.name}](../{LED.name})','',
           'The archive preserves original proof/source bytes, five frozen initial reports, independent mathematical challenges, exact source/import checks and finite synthetic diagnostics. It is a research record, not a publication or hardware validation.','',
           '## Key proofs','']
    for x in pins:intro.append(f'- [{x["title"]}]({x["path"]}) — SHA256 `{x["sha256"]}`.')
    intro+=['','## Reviews','']
    for folder in ['machinery','constructor','auditor']:
        for p in sorted((RECORD/folder).glob('*REVIEW.md')):
            rel=p.relative_to(RECORD).as_posix();intro.append(f'- [{rel}]({rel}).')
    intro+=['','## Validation','', '[Finite reruns](verification-rerun/RERUN_REPORT.json), [component pins](principal/DOSSIER_COMPONENT_PINS.json), [initial independence](initial/INDEPENDENCE_ACCOUNT.json), and [source pin](sources/SOURCE_PIN.json).','']
    (RECORD/'INDEX.md').write_text('\n'.join(intro))
    files=[]
    for p in sorted(RECORD.rglob('*')):
        if p.is_file():files.append({'path':p.relative_to(RECORD).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
    (RECORD/'MANIFEST.json').write_text(json.dumps({'scope':'Supporting files only; manifest does not hash itself.','files':files},indent=2)+'\n')
    # Resolve every Markdown file link in the actual final dossier; no math-link exceptions.
    local=[]
    for target in re.findall(r'\[[^\]\n]+\]\(([^)\n]+)\)',DOS.read_text()):
        if target.startswith(('http:','https:','mailto:','codex:','#')):continue
        target=target.split('#')[0];assert (OUT/target).exists(),target;local.append(target)
    zipped={}
    with zipfile.ZipFile(ZIP,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in [DOS,LED]+[x for x in sorted(RECORD.rglob('*')) if x.is_file()]:
            name=p.relative_to(OUT).as_posix();z.write(p,name);zipped[name]=sha(p)
    with zipfile.ZipFile(ZIP) as z:
        assert z.testzip() is None
        assert set(z.namelist())==set(zipped)
        for name,h in zipped.items():assert hashlib.sha256(z.read(name)).hexdigest()==h
    for x in files:assert sha(RECORD/x['path'])==x['sha256']
    validation={'date_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_artifact_checks_pass':True,'mathematical_status':'Analytic proofs with completed scoped internal reviews; artifact checks are not mathematical proof.','physical_experiments':0,'broad_sampler':'OPEN_NOT_ACHIEVED','historical_priority':'UNKNOWN','full_worst_case_implementation':False,'initial_reports_verified':5,'component_pins_verified':len(pins),'finite_reruns':len(rerun['runs']),'local_dossier_links_verified':len(local),'copied_support_files':len(files),'zip_members':len(zipped),'zip_crc_and_all_member_hashes_verified':True,'deliverables':[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in [DOS,LED,ZIP]],'assembly_review':{'path':str(RECORD/'auditor/FINAL_DOSSIER_REVIEW.md'),'sha256':sha(RECORD/'auditor/FINAL_DOSSIER_REVIEW.md')},'record_manifest_sha256':sha(RECORD/'MANIFEST.json')}
    VAL.write_text(json.dumps(validation,indent=2)+'\n');print(json.dumps(validation,indent=2))
if __name__=='__main__':main()
