# Local relative prediction: constructive candidate and acquisition boundary

Global rare-event hardness does not itself forbid relative fixed-local numerical
prediction for an exactly supplied PRODUCT source. Above a fixed physical time,
the auditor's local probability floor pays conditioning. At tiny T, a local
Taylor expansion through r=w+O(log(1/epsilon)) may pay error epsilon*T^w without
work polynomial in T^-1: rooted interaction animals and Pauli words number
exp(O(r)), and product-source word means are exactly computable. Compute T^r
using its binary input length. Verify the exact Wild--Alhambra short-time import,
derivative/enumeration bounds, and many-piece chronological recurrence before
promoting this candidate. No theorem or novelty is claimed here.

There is no automatic learned-relative-service consequence. A w-body coupling
h can cause a rare transition of order h^2 T^2 against reset-only probability
of order T^w. For w>=3, uncertainty alpha in h near zero can require
alpha=O(T^((w-2)/2)), exponentially precise physical acquisition at binary-small
T. Efficient generative-mixture sources can also make the leading Taylor
coefficient a rare SAT count. Exact model evaluation, acquired precision and
sampling remain distinct operations.
