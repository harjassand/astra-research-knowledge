"""Exact rational leading-order check for number-conserving biased-reset embedding."""
from fractions import Fraction
from math import factorial
from pathlib import Path
import json
from audit_rare_event import placements,covers,rot,add

def run(region,p,gamma,extra=1):
    pts=sorted(region); ids={v:i for i,v in enumerate(pts)}; n=len(pts); N=2*n
    assert n%3==0
    masks=[]
    for size,tile in placements(pts):
        if size==3: masks.append(sum(1<<ids[v] for v in tile))
    z=covers(n,masks)
    physical_masks=[sum(3<<(2*i) for i in range(n) if mask>>i&1) for mask in masks]
    initial=sum(1<<(2*i) for i in range(n)); target=sum(2<<(2*i) for i in range(n))
    p=Fraction(p); d=p.denominator; num=p.numerator
    degree=2*n//3; maxdegree=degree+extra
    cur={(initial,initial):(1,0)}; coefficients=[]; peak=0
    for ell in range(maxdegree+1):
        v=cur.get((target,target),(0,0)); assert v[1]==0
        coefficients.append(Fraction(v[0],d**ell*factorial(ell)))
        if ell==maxdegree: break
        nxt={}
        for (a,b),v in cur.items():
            for logical,physical in zip(masks,physical_masks):
                valid_a=all(((a>>(2*i))&3) in [1,2] for i in range(n) if logical>>i&1)
                valid_b=all(((b>>(2*i))&3) in [1,2] for i in range(n) if logical>>i&1)
                if valid_a: add(nxt,(a^physical,b),rot(v,3),d)
                if valid_b: add(nxt,(a,b^physical),rot(v,1),d)
            diag=0
            for i in range(N):
                bit=1<<i
                if (a^b)&bit: diag-=gamma*d
                else:
                    flip_prob_num=num if a&bit else d-num
                    add(nxt,(a^bit,b^bit),v,gamma*flip_prob_num)
                    diag-=gamma*flip_prob_num
            add(nxt,(a,b),v,diag)
        cur=nxt; peak=max(peak,len(cur))
    assert all(v==0 for v in coefficients[:degree])
    assert coefficients[degree]==z*z
    return {'logical_sites':n,'physical_sites':N,'p_zero':str(p),'gamma':gamma,'tilings':z,'leading_degree':degree,'leading_coefficient':str(coefficients[degree]),'coefficients':[str(v) for v in coefficients],'peak_sparse_matrix_units':peak}

if __name__=='__main__':
    cases=[]
    for p,g in [(Fraction(1,3),1),(Fraction(4,5),7)]:
        cases.append(run([(1,0),(0,1),(1,1)],p,g,extra=2))
        cases.append(run([(x,y) for x in range(2) for y in range(3)],p,g,extra=0))
        cases.append(run([(x,0) for x in range(3)],p,g,extra=2))
    obj={'status':'PASS','scope':'Exact finite Taylor checks of the biased-reset dual-rail theorem; no full sampler implementation.', 'cases':cases}
    Path(__file__).with_name('AUDIT_DUALRAIL.json').write_text(json.dumps(obj,indent=2)+'\n')
    print(json.dumps(obj,indent=2))
