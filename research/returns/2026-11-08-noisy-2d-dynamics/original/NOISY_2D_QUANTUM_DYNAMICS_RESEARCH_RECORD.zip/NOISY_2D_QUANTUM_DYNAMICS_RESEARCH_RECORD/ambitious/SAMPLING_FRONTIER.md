# Sampling frontier: earned positive regimes, exact obstructions, and the missing 2D operation

8 November 2026. Post-exchange synthesis and derivation. The independently frozen `initial/ambitious.md` is unchanged. Read the dedicated `FINAL_RELATIVE_OBSTRUCTION.md` for complete rare-event proofs. This file confronts the team readout/sampling results, proves two positive transfers for a common faithful product reference, and records a constructive primary-source audit of the Trivedi--Cirac identity/CPTP-event step.

## 1. Capability map

| Model and task | Strongest operation earned | Exact remaining boundary |
| --- | --- | --- |
| Original arbitrary bounded-local 2D Hamiltonian, product input, every-site unital replacement | All-time additive prediction of every global Hermitian product contraction; team `machinery/FINAL_GLOBAL_READOUT_THEOREM.md` | A scalar additive operation, including tiny probabilities only at additive accuracy |
| Original noise with a supplied constant-cut interaction tree and locally purified TTN input | All-time full-output TV sampler; constructor's frozen report | Generic square-lattice separators do not satisfy the cut promise |
| Original unital noise, arbitrary input and Hamiltonian geometry | Relative operator-order certificate and positive reference sampler after gamma T>=log(4n/eta); constructor's `RELATIVE_MIXING_AND_SAMPLING_OBSTRUCTION.md` | Does not cover earlier times |
| Faithful biased resets, common product reference conserved by H | Principal's all-time fixed-local additive predictor | Whole-block conservation and faithful reference are substantive |
| Same common-reference biased resets on certified bounded-cut architectures | **All-time full-output TV sampler proved by the transfer in Section 3 below** | No arbitrary-2D architecture conclusion; no all-time relative error claimed |
| Same common-reference biased resets, arbitrary geometry and correlated input | **Log-time relative operator mixing and reference sampling proved in Section 2 below** | This is an established-HC consequence, not a new constant-time dequantization theorem |
| Original 2D class, arbitrary positive rational times, relative/log probabilities | Explicit NP=RP consequence if a uniform polynomial evaluator exists | Actual rare-event reduction; not TV hardness or a positive-lower-time result |
| Faithful biased common-reference class, arbitrary positive times, relative/log probabilities | The same obstruction via number-conserving six-body dual-rail blocks | Not TV hardness; static product-input model retained |
| Original generic 2D class, full-output TV at every fixed positive gamma/J and all times | **OPEN / NOT_ACHIEVED** | A positive generative or normalized connected-activity operation is missing |

The two new positive rows combine established mechanisms and preserve credit: the constructor supplied the tree sampler and relative-mixing architecture; the principal supplied the faithful-reference structure and reset-register dilation; generalized weighted hypercontractivity is imported from primary literature. No first-priority, practical runtime, physical advantage or complete implementation claim is made.

## 2. A relative operator mixing theorem for the faithful biased reference

### 2.1 Formal statement

Let sigma=diag(p,1-p), 0<p<1, mu=min(p,1-p)>0, and Sigma=sigma^(tensor n). Consider

    d rho/dt=-i[H(t),rho]+gamma sum_i(R_i^sigma(rho)-rho),
    R_i^sigma(rho)=sigma_i tensor Tr_i(rho),
    [H(t),Sigma]=0.

The initial density matrix may be arbitrary and correlated. This bound needs neither spatial locality nor per-block conservation; global commutation on every time interval suffices. In algorithmic use the rate, reference and a finite piecewise rational Hamiltonian schedule are explicitly supplied, with their bits charged.

Define

    a_sigma=(1-2mu)/log(mu^-1-1), a_sigma=1/2 at mu=1/2,
    c_sigma=8 a_sigma/(3 log 2)>0,
    C_mu=mu^-1 sqrt(mu^-2-1)<mu^-2.

For gamma T>=(2/c_sigma)log n,

    ||Sigma^-1/2 rho_T Sigma^-1/2-I||_infty
      <= C_mu n^(2/c_sigma) exp(-gamma T).               (1)

In particular the condition

    gamma T >= (2/c_sigma)log n+log(mu^-2/eta),
    0<eta<=1/2,

implies simultaneously

    (1-eta)Sigma <= rho_T <= (1+eta)Sigma.               (2)

This is a full operator-order assertion. Consequently every positive measurement effect M satisfies

    (1-eta)Tr(M Sigma)<=Tr(M rho_T)<=(1+eta)Tr(M Sigma).  (3)

It earns actual log marginals and relative reference sampling, not just additive expectation values. At the maximally mixed point the constructor's sharper King constant gives its better 4n exp(-gamma T) bound; the conservative weighted constant here is chosen to match the verified import and cover all biases.

### 2.2 Exact import and actual-channel applicability

Dong--Gao--Ou--Yao--Zhou, arXiv:2606.17729v1, Theorem 1.1, applies to every operator on tensor powers of a fixed faithful reference and supplies

    ||Delta_[sigma,exp(-gamma s)]^(tensor n)(A)||_(q,Sigma)
       <=||A||_(p,Sigma)

when q-1<=exp(c_sigma gamma s)(p-1). The weighted norm is

    ||A||_(p,Sigma)=||Sigma^(1/(2p)) A Sigma^(1/(2p))||_p.

The paper credits Beigi--Datta--Rouze for the earlier exact qubit tensorization; this credit is retained. The primary statement and norm convention were checked directly at [arXiv:2606.17729v1, Theorem 1.1](https://arxiv.org/html/2606.17729v1). This is the only non-elementary import in this section.

Conjugation by a unitary commuting with Sigma is an isometry at every displayed exponent. Interleaving the actual Hamiltonian evolution with the reset semigroup, allowing the exponent to grow at rate c_sigma gamma, and taking the product limit proves the same hypercontractive bound on every actual chronological interval. No reset is commuted through H. Sign reversal of H makes no difference to this applicability.

### 2.3 Relative density and the three-interval proof

Put Q_t=Sigma^-1/2 rho_t Sigma^-1/2. Direct calculation, using [H,Sigma]=0, gives

    d Q/dt=-i[H(t),Q]+gamma sum_i(F_i(Q)-Q),
    F_i(Q)=I_i tensor Tr_i(sigma_i Q).

Thus Q evolves under a unital generalized-depolarizing channel with the same reference and the opposite Hamiltonian sign from the usual Heisenberg convention. It is positive and Tr(Sigma Q)=1. The F_i are weighted-L2 orthogonal conditional expectations. Their tensor-product eigenbasis has eigenvalue -gamma r on a product containing r reference-mean-zero factors. The Hamiltonian is skew-adjoint for the weighted L2 inner product. Therefore every reference-mean-zero A obeys

    ||V_[v,u](A)||_(2,Sigma)<=exp[-gamma(v-u)]||A||_(2,Sigma). (4)

For n>=1 choose the first and last interval lengths

    s=log n/(c_sigma gamma),

with s=0 for n=1. Let p_in=1+1/n and q_out=n+1. Since rho_0 is positive of trace one,

    ||Q_0||_(p_in,Sigma)
      =||Sigma^[-(p_in-1)/(2p_in)] rho_0
                     Sigma^[-(p_in-1)/(2p_in)]||_(p_in)
      <=mu^[-n(p_in-1)/p_in] ||rho_0||_(p_in)
      <=mu^[-n/(n+1)]<mu^-1.

Here ordinary Schatten ideal inequalities and ||rho_0||_p<=1 suffice; no input representation or additional entropy theorem is needed. Initial weighted HC maps p_in to 2 in time s. Since Q_s has weighted mean one,

    ||Q_s-I||_(2,Sigma)^2=||Q_s||_(2,Sigma)^2-1<mu^-2-1.

On the middle interval of length T-2s apply (4). On the last interval apply 2-to-q_out HC. Finally

    ||A||_infty<=mu^(-n/q_out)||A||_(q_out,Sigma)<mu^-1||A||_(q_out,Sigma).

Combining gives (1), including arbitrary time ordering and arbitrary-rank correlated input. Congruence by Sigma^1/2 then proves (2)--(3).

### 2.4 Finite-bit log computation and sampling

No exact logarithm is needed for the cutoff. One can use a positive rational c0<=c_sigma. For example **c0=mu works**: log x<=x-1 with x=(1-mu)/mu gives a_sigma>=mu, and 8/(3 log 2)>1. Hence the sufficient rational test

    gamma T >= (2/mu) ceil(log_2 n)
                    +ceil(log_2(mu^-2/eta))              (5)

certifies (2). Integer comparisons produce the ceilings; all scalar input bits are paid. Sharper certified c0 is optional.

For computational outcomes, the reference probability is

    P_Sigma(x_S)=product_[i in S] sigma_[x_i,x_i].

Return sum_i log sigma_[x_i,x_i], computed with certified scalar error, as the log-marginal approximation. Equation (3) bounds the dynamical log discrepancy by -log(1-eta)<=2eta, regardless of how small that marginal is. Log conditionals follow by subtracting two log marginals; reference nonzero probabilities are guaranteed by mu>0.

Sample the product reference law. With exact reference coins its pointwise error relative to P_rho is at most eta/(1-eta), and its TV error is at most eta/2, directly from (3); no factor n from sequential conditionals is introduced. Bounded random-bit sampling is also paid: approximate each rational local coin multiplicatively to O(eta/n). Since p,1-p>=mu, O(log(n/(eta mu))) bits per coin suffice. The resulting full product law incurs a further exp(O(eta)) pointwise factor. A prescribed product POVM is treated by its rational reference weights Tr(M_i,x sigma). If a positive weight is tiny, its binary rational height is part of the input, so multiplicative rounding needs only its paid bit length plus log(n/eta); zero effects have zero weight under both states and can be omitted.

This theorem is a rigorous stronger end branch for the faithful-reference model. Its logarithmic time is natural for approximation by the reference: already at H=0 a product of biased one-site residuals can retain an O(n exp(-gamma T)) pointwise likelihood ratio. It is not the sought constant-physical-time polymer theorem and does not resolve earlier TV sampling.

## 3. All-time full TV sampling with faithful biased resets on bounded cuts

### 3.1 The earned transfer

Fix local block size k, incidence d, constant cut bound c, initial local purification dimension r0, a faithful rational sigma and a ratio upper bound g>=J/gamma. Supply:

- n physical qubits and a labelled binary leaf tree with O(n) nodes;
- an explicit piecewise rational Hamiltonian schedule H(t)=sum_b H_b(t), with support size <=k, norm <=J, site incidence <=d, and at most c active blocks crossing any tree-edge partition;
- a rational normalized locally purified TTN input of maximum virtual bond D0 on the same tree;
- a positive rational rate gamma and final time T, and a terminal product POVM with bounded local outcome count and rational effects.

Assume [H(t),sigma^(tensor n)]=0 on every segment. The principal's stronger per-block conservation promise is sufficient, but not needed for this transfer: only the exact entropy/mixing argument uses conservation, whereas the numerical trajectory approximation is directly charged in trace norm.

**Theorem C.** The complete terminal distribution has a bounded-work randomized classical sampler of TV error epsilon, with work polynomial in complete input bits B, n, number of schedule segments, D0 and 1/epsilon at each fixed set of these class parameters. Before the entropy cutoff, a more informative work bound has the form

    poly(B,n,M,D0,1/epsilon,2^K) exp(O(2^k cJT)),
    K=O(gamma T+log(n/epsilon)).                         (6)

At the only simulated times gamma T=O_mu(log(n/epsilon)), this is polynomial. This proves a genuine all-time nonunital full-output sampling operation on the restricted architecture. It does not promote generic 2D product-readout prediction into a sampler.

### 3.2 Mixing branch with no hidden reservoir resource

For Sigma=sigma^(tensor n), Hamiltonian evolution contributes zero to the derivative of D(rho||Sigma). Convexity of relative entropy bounds the ith reset contribution by

    gamma[D(R_i^sigma rho||Sigma)-D(rho||Sigma)].

The entropy chain rule/strong subadditivity gives

    sum_i S(rho_-i)>=(n-1)S(rho).

Using D(R_i^sigma rho||Sigma)=D(rho_-i||Sigma_-i), it follows that the sum of the reset entropy drops is at least D(rho||Sigma). Consequently

    D(rho_T||Sigma)<=n log(mu^-1) exp(-gamma T),
    ||rho_T-Sigma||_1<=sqrt(2n log(mu^-1)) exp(-gamma T/2). (7)

This holds for arbitrary correlated input, including the supplied TTN. With

    L=ceil(log_2(64(n+1)/(mu epsilon))),

the rational test gamma T>=4L makes the trace error much smaller than epsilon/100; use log(mu^-1)<=mu^-1 and e^-L<=2^-L. Sample the known product reference on this branch. Otherwise gamma T<4L and JT<4gL. Faithfulness and conservation are real mathematical resources; an arbitrary cooling bath or nonconserving driven H does not satisfy (7).

### 3.3 Paid finite reference and actual reset dilation

Expand each fixed-size rational H_b into at most 4^k Pauli terms. Its Pauli coefficient one-norm is at most 2^k||H_b||<=2^k J. A first-order colored/rational Cayley approximation, interleaved with the positive Euler reset

    (1-gamma h)Id+gamma h R_i^sigma,

has global diamond error <=epsilon/100 with polynomially many steps. The constructor's segmentwise choice r_j=max(1,ceil(A_j),ceil(C A_tot A_j/epsilon)), with A_j the paid local diamond-norm action on segment j, yields total steps O(M+A_tot+A_tot^2/epsilon). Here A_tot<=C_k n(dJ+gamma)T, so only polynomial physical action enters before the cutoff. No inverse minimum segment length is charged.

Sample an Euler reset event with probability gamma h. Conditional on such an event, sample a bit a from p,1-p, introduce |a> at the same spatial leaf, SWAP it with the physical qubit and **keep the old register** as a passive coordinate. Tracing that register gives exactly R_i^sigma; keeping it makes the trajectory unitary. Initial correlations are supplied by the known TTN purification. This is a numerical representation of the stipulated physical noise, not a physical supply of clean qubits or a bath-outcome oracle.

### 3.4 Deterministic leaf-dimension cap

The reset count S_i at a physical site is a sum of independent Bernoulli variables with mean lambda_i=gamma T. Its count, not the number of time steps, controls the retained-register dimension. Since

    E exp(S_i)<=exp[(e-1)lambda_i],

Markov's inequality gives

    Pr[S_i>=2lambda_i+u]<=exp(-u),

because e-1<2. Choose

    K=ceil(2gamma T)+ceil(log_2(100n/epsilon)).            (8)

The probability that any site exceeds K is at most epsilon/100. Stop and return a fixed output on such a history. This incurs TV error at most the exceptional probability and has bounded work; there is no rejection/termination assumption. At most K reset registers need ever be allocated at each leaf. Its local Hilbert dimension is at most

    q_leaf<=2 r0 2^K=poly_mu(n/epsilon)

in the simulated branch. Preallocating K local slots makes this dimension bound deterministic. Local SWAPs and bit preparations cost no spatial crossing action.

### 3.5 Crossing action, constructive TTN and output sampling

Across any supplied tree cut, the initial purification has Schmidt nuclear norm <=sqrt(D0). A crossing Pauli rotation grows this norm by at most exp(|theta|), and all on-leaf reset SWAPs preserve it. Pauli expansion of the at-most-c crossing blocks therefore gives, at every intermediate point and for every capped history,

    N_e(psi_exact)<=B_star=sqrt(D0)exp(2^k cJT).           (9)

After at most M_c=100n(G+1) paid tree-edge compressions, the original nuclear/operator-duality estimate gives vector error at most zeta using

    D>=ceil((16 M_c B_star/zeta^2)^2).

The constructor's compatible-tree canonicalization and gap-free approximate SVD implementation apply with local dimension q_leaf included in every dense matrix cost. All gates, tensor entries, norms, sweeps and rounding bits are polynomially paid. Set zeta=epsilon/100. Normalize the nonzero approximate trajectory vector; its norm differs from one by at most zeta, so the resulting trajectory density matrix differs from the exact one by trace norm O(zeta). The full terminal product-POVM law can then be sampled by exact rational TTN contractions and finite-bit categorical choices, whose summed TV error is separately <=epsilon/100.

Average the trace/measurement error over the digitally sampled histories and include the explicit exceptional-count and channel-reference errors. All total errors are below epsilon with the displayed slack. This proves Theorem C. The actual sampler produces one TTN history per sample; it does not output an exponentially large density matrix or enumerate all noise histories.

This is a transfer of the principal's reset-register representation into the constructor's paid tree algorithm. Ordinary unital histories needed no growing register dimension; equation (8) is the additional operation making this nonunital extension finite and polynomial. A practical implementation at these worst-case bounds has not been performed.

## 4. The conservation condition does not remove relative early-time hardness

`FINAL_RELATIVE_OBSTRUCTION.md`, Section 8, supplies a complete static counterpressure at every fixed bias 0<p<1 and gamma>0. Encode each logical bit in the physical product pair |10>,|01>, with exchange F_i=(XX+YY)/2, and use H=sum_tromino product_i F_i. Every six-body block commutes with the faithful product reference; all blocks commute with each other. The target rare probability again has leading coefficient q_tilings^2 at T^(2n/3), and biased resets enter only at higher order. The same polynomial-bit dyadic time gives an NP=RP consequence for an all-time relative/log evaluator.

Thus faithful conservation supports the positive theorems above but cannot justify a uniform relative evaluator at all arbitrarily short times. This is compatible with both Theorem C's TV task and the logarithmic-time relative branch. Six exact cases of the encoded leading coefficient passed at p=1/3,4/5 and gamma=1,7, with up to twelve physical qubits (`AUDIT_DUALRAIL.json`).

## 5. The remaining generic 2D TV operation

The all-support product-readout theorem is materially stronger than the original fixed-local mean theorem. It still supplies a single bounded mean per call. The constructor's noisy-linear-code construction demonstrates why inverse-polynomial additive answers for every product contraction do not by themselves determine a general law in TV: all such means may be exponentially indistinguishable while the laws are nearly disjoint. That is an oracle/interface obstruction, not a target-class hardness construction.

The original parity-strip estimator is a bounded overlap estimator between two efficiently represented states with different strip orders. Its normalization is appropriate for a scalar inner product. It has not become a positive sequential distribution or a trace-norm global state representation. The bounded-cut theorem can retain the entire state because each cut has only constant crossing action; generic square-lattice cuts can have extensive boundaries. The biased reset registers resolve nonunital noise representation but do not remove this spatial obstruction.

The strongest circuit comparator remains Nelson et al., arXiv:2610.00548v2, Theorem 2.3 and Proposition 2.2: fixed-strength noisy geometric circuit layers above a p-dependent depth have an FPTAS for arbitrary log marginals and relative sampling. Its critical physical-time threshold and degree diverge under p proportional to gamma h as h->0. A direct Trotter import is therefore unearned.

A viable continuous repair must bound **connected activities and their relative normalization** uniformly in the fine time step, or provide an independently positive global sampler whose total error is controlled before conditioning. Factorial spatial tails may be inserted as additional interaction activities, but an absolute tail estimate cannot simply be divided by an exponentially small prefix mass. Theorem A proves that a purported zero-free/log expansion valid down to every positive T in the full original class would encounter an actual complexity obstruction. A later-time constant-physical-threshold result remains possible; a TV-only early-time completion would be a different required operation.

No theorem here closes that generic 2D interval.

## 6. Trivedi--Cirac: exact published source check and constructive repair boundary

### 6.1 What was actually checked

Published primary: R. Trivedi and J. I. Cirac, *Transitions in Computational Complexity of Continuous-Time Local Open Quantum Dynamics*, Phys. Rev. Lett. 129, 260405 (22 December 2022), DOI [10.1103/PhysRevLett.129.260405](https://doi.org/10.1103/PhysRevLett.129.260405). The article's Theorem 1 is the high-noise TV sampling claim; its Hamiltonian low-noise hardness uses biased/nonunital channels. The arXiv version has the earlier title *Simulability transitions in continuous-time dynamics of local open quantum systems*.

The published [main PDF](https://journals.aps.org/prl/pdf/10.1103/PhysRevLett.129.260405), pp. 2--3, repeats the identity-versus-other-channel rare-horizontal-event step. The journal's actual linked [supplement_final.pdf](https://journals.aps.org/prl/supplemental/10.1103/PhysRevLett.129.260405/supplement_final.pdf), Problem 1, pp. 3--4, admits arbitrary bounded local Lindbladians and product input; Lemma 3 on p. 4 asserts a fixed-rate identity/CPTP decomposition using Id+L/g. The published supplement retains the CP assertion found on p. 8 of arXiv:2110.10638v2. No assumption there excludes a purely Hamiltonian local term. These pages were read through the web PDF tool; direct local retrieval returned HTTP403, so a local hash of the published PDFs is not claimed. The arXiv primary bytes remain pinned locally.

### 6.2 Exact failed ingredient

For the one-qubit generator L=-i[Z,.], the Choi matrix of Id+L/g compressed to the orthonormal vectors |Omega> and (Z tensor I)|Omega> is

    [[1, i/g],[-i/g,0]],

whose determinant is -1/g^2. It is not positive for any finite g>0. If

    exp(hL)=(1-gh)Id+gh Phi_h+O(h^2)

with Phi_h CPTP and g fixed, rearrangement forces Phi_h->Id+L/g. Closedness of the CPTP cone contradicts this Choi matrix. Thus allowing an h-dependent event channel does not rescue the stated first-order approximation.

For a multi-site Pauli P of weight at least two, adding arbitrary one-site replacement noise leaves the P-P Choi diagonal zero and the I-P off-diagonal nonzero. The same negative determinant persists. This is why one cannot repair this particular finite-event-rate shortcut by silently allocating more of the original single-site noise.

These exact counterexamples invalidate the displayed proof ingredient. They are **not counterexamples to the high-noise sampling conclusion**. A different valid representation could establish that conclusion.

### 6.3 A necessary-and-sufficient finite-rate condition

There is a precise constructive replacement for the false general assertion. For a finite-dimensional Lindblad generator, write its normalized Choi operator relative to |Omega> plus its orthogonal complement as

    J_L=[[a,b^dagger],[b,C]].

For a Lindblad generator C>=0 (conditional complete positivity). Then

    Id+L/g is CPTP for some finite g>0

if and only if

    b belongs to Range(C).                              (10)

Indeed multiplication of its Choi operator by positive g gives

    [[g+a,b^dagger],[b,C]],

and the generalized Schur complement criterion is exactly

    C>=0, b in Range(C), g+a>=b^dagger C^+ b.             (11)

Trace preservation is automatic. When (10) holds, choose g exceeding the final scalar bound; this gives the genuine Poisson generator L=g(Phi-Id), Phi CPTP. To recover the source's **uniform** algorithmic hypothesis, one must additionally bound that g by a constant multiple of the declared local interaction strength and pay computation of Phi. A finite g with an arbitrarily tiny positive eigenvalue of C is not a uniform O(J) rate.

Pure Hamiltonian drift has C=0,b!=0 and fails (10). A multi-site Hamiltonian plus only one-site Pauli dissipators also fails: the Hamiltonian vector lies outside the one-site dissipative jump span. Full-support dissipative noise with a quantitative lower Choi bound can satisfy (10), but imposing it changes the physical model. For example -ih[P,.]+kappa(Ad_P-Id) admits the condition g>=kappa+h^2/kappa for kappa>0. This is an illustrative valid subclass, not an added control or an import into the original single-site-only experiment.

### 6.4 A CPTP short-time repair which retains the unpaid coherent drift

Ordinary first-order CPTP discretization is always available. For

    L=-i[H,.]+sum_alpha(V_alpha . V_alpha^dagger
                         -(1/2){V_alpha^dagger V_alpha,.}),
    Q=sum_alpha V_alpha^dagger V_alpha,

choose h||Q||<=1 and Kraus operators

    K0=exp(-ihH)sqrt(I-hQ), K_alpha=sqrt(h)V_alpha.

Their squared norms sum exactly to I, and their channel is Id+hL+O(h^2). Fixed local dimension makes the matrix arithmetic and its precision payable. For the original Pauli Hamiltonian plus reset, the team's rational Cayley/Euler split is simpler and already supplies a valid CPTP reference.

This repair does **not** produce the needed rare-horizontal-event percolation: the no-jump K0 generally carries a coherent entangling drift at every time step. Replacing it by identity would return to the invalid assertion. Therefore the following accounting is retained: valid finite CPTP discretization achieved; the printed fixed-rate ingredient disproved; no completed replacement proof of the source's general high-noise percolation theorem supplied here; no claim that the high-noise conclusion is false.

## 7. Final scope and artifacts

The strongest additional positive operation from this follow-up is the common-reference nonunital **all-time bounded-cut TV sampler**, plus the faithful-reference **relative logarithmic-time end branch**. The strongest negative operation is an actual finite-bit NP reduction for uniform rare probabilities, including the new number-conserving biased-reset encoding. Generic 2D all-time TV sampling remains open.

Supporting new objects are `FINAL_RELATIVE_OBSTRUCTION.md`, `audit_dualrail.py`, `AUDIT_DUALRAIL.json`, and the current source/result manifest. Earlier exact Taylor and Choi checks remain preserved. All algorithmic theorems are mathematical derivations; no implementation at the huge general bounds or practical benchmark has been performed. The initial independent report, Gibbs artifacts, other researchers' files and published manuscript bytes remain unchanged.
