# Relative and logarithmic probabilities: an explicit original-class obstruction

8 November 2026. Post-exchange formalization of the independently frozen `initial/ambitious.md` (SHA256 `313fbcf6e47519842f82cbd7e4a7cefaaee8d0e211306bf247599b0bebc711b5`). The initial bytes are unchanged. Sections 1--7 formalize that initial result; Section 8 is a new post-exchange extension confronting the principal's faithful biased-reset model. Complete derivations are given here. Independent team review and historical priority remain separate questions.

## 1. Statement with the exact complexity consequence

Fix any positive rational replacement rate gamma, set the interaction upper bound J=1, and fix the physical class parameters k=3, maximum-metric interaction range a=1 and site incidence d=12. The physical system consists of explicitly listed square-lattice qubits, a static rational Pauli Hamiltonian and the generator

    L(rho)=-i[H,rho]+gamma sum_i(E_i(rho)-rho),
    E_i(rho)=I_i/2 tensor Tr_i(rho).

There are no additional physical channels, clean ancillas, controls, intermediate measurements or feedback. The supplied initial state is |0^n><0^n|, an exactly rational one-qubit product. Every physical qubit has the stated positive noise rate, including boundary qubits.

**Theorem A.** A randomized algorithm which, on every such input and every positive rational T, estimates the logarithm of a specified full computational-basis output probability to additive error 1/4 with success probability at least 3/4, in time polynomial in the complete binary input, implies NP=RP. The same implication holds for a fixed-relative-error probability evaluator (for example relative error at most 1/2), an arbitrary-marginal log evaluator, or a log-conditional evaluator with requested additive accuracy O(1/n) and polynomial dependence on inverse accuracy.

All probabilities queried in the reduction are strictly positive; the magnitude of their logarithms is O_gamma(n^2). The evolution times are exponentially small numerically but have O_gamma(n) binary digits. The conclusion applies at **every fixed positive rational gamma/J**. It is a conditional complexity obstruction, not an unconditional lower bound on arbitrary algorithms.

Theorem A says nothing about a uniform total-variation sampler, a time promise T>=T_min>0 independent of size, or a Hamiltonian class restricted to exclusively two-body terms. In fact the very same hard-probability instances are exponentially close in TV to their deterministic initial output. These scope distinctions are proved below, not left as qualifications to an unsupported hardness claim.

## 2. Exact primary combinatorial import

Primary source: Cristopher Moore and John Michael Robson, *Hard Tiling Problems with Simple Tiles*, arXiv:math/0003039v1, 6 March 2000; subsequently Discrete & Computational Geometry 26 (2001), 573--590, DOI [10.1007/s00454-001-0047-6](https://doi.org/10.1007/s00454-001-0047-6).

The needed statements are unnumbered results of their Sections 2, 3 and 3.1, rather than fictitious numbered theorems:

- **Section 3/3.1, PDF pp. 6--11:** tiling an explicit finite region of the square lattice by right trominoes, with rotations allowed, is NP-complete. General regions, including holes, are admitted. Their finite gadgets and grid embedding give polynomial-size instances. The final paragraph of Section 3.1 completes the planar cubic monotone 1-in-3-SAT reduction.
- **Section 2, PDF pp. 2--3:** allowing both the right tromino and the 2x2 square tetromino gives a parsimonious SAT reduction. This separate counting statement is used only in Section 7 below.

The source explicitly does not prove #P-completeness for right trominoes alone. That stronger import is not made here. A right tromino consists of three cells of a unit 2x2 square, with one corner missing; its four rotations are precisely the four possible missing corners. Reflection adds no new shape for this tile.

The pinned primary PDF is `../sources/literature/ambitious/MooreRobson_math0003039v1.pdf`, SHA256 `2c503a199e2268022c2f7df0bdb654f33fc6174eb5b33dfa6e9a597888d215b0`. Its extracted text is retained beside it. The geometry and both counting qualifications were checked against the actual construction, not inferred from an abstract.

## 3. The physical Hamiltonian and its geometry

Let R be such a finite region, represented by n lattice cells, with n=3m. Instances with n not divisible by three can be rejected before calling the evaluator, without changing NP-hardness of the residual decision problem. Let T_3(R) consist of all right-tromino placements wholly contained in R, and let q_R be the number of tilings. Define

    H_R=sum_[S in T_3(R)] X_S,
    X_S=product_[i in S] X_i,
    rho_0=|0^n><0^n|.

There are at most four unit 2x2 squares containing a site and three tromino placements in each such square containing it. Thus each site occurs in at most twelve Hamiltonian terms. Every term is a Hermitian Pauli of weight three, maximum-metric diameter one and rational coefficient exactly one. All Hamiltonian terms commute. If M is the number of terms, incidence counting gives 3M<=12n, so M<=4n. Enumeration of all placements costs polynomial time and must include unit-square anchors absent from R; missing lower-left corners are legitimate placements.

A qubit sits at the coordinate of each lattice cell. Holes of the input region therefore translate directly into an allowed finite lattice region. If an implementation insists on a full rectangular array, fill a polynomial-size bounding rectangle with decoupled noisy qubits and include only the Hamiltonian terms on the original cells. Query the all-one outcome on R and the all-zero outcome on the fillers. The filler probability has constant Taylor coefficient one, so the leading-order proof is unchanged; use the full physical site count N in the norm/time bound below. Moore--Robson's polynomial grid construction keeps N polynomial. Thus no physical control that turns noise off on filler sites is needed.

## 4. Exact leading-order coefficient in the actual Lindbladian

Use the precise replacement convention

    gamma(E_i-Id)=(gamma/4) sum_[P=X,Y,Z](Ad_[P_i]-Id).

For a computational matrix unit |a><b|, one Hamiltonian left multiplication by X_S flips three ket coordinates, and a right multiplication flips three bra coordinates. A noise conjugation by X or Y flips at most two coordinates, one on each side at the same physical site; a Z conjugation and a negative identity term flip none. Complex phases do not affect this support count.

There are 2n ket/bra coordinates that differ between |0><0| and |1><1|. Each must be flipped an odd number of times. For a word in L_R of length ell to contribute to the final matrix entry, its total number of coordinate flips must be at least 2n. Since every elementary factor flips at most three coordinates, no word of length less than

    r=2n/3=2m

can contribute. At length r every factor must flip three coordinates; hence every factor is Hamiltonian, no coordinate is flipped twice, and exactly m factors act on each side. The m ket factors form a tromino tiling, as do the m bra factors. This also proves that every noise contribution vanishes at this leading order, without commuting noise through H.

One may compute the coefficient in the purely Hamiltonian channel after this exclusion. Each tiling has m! orderings of its disjoint terms, canceled by the exponential denominator. All tilings have the same phase:

    <1^n|exp(-it H_R)|0^n>=(-i)^m q_R t^m+O(t^(m+1)).

It follows exactly that

    p_R(t)=<1^n|exp(t L_R)(rho_0)|1^n>
          =q_R^2 t^r+R_R(t),                              (1)

and that all Taylor coefficients below degree r vanish. The derivation uses finite matrix units and the density-matrix generator; it does not use a rare-conditioning heuristic, a postselection hardness theorem from another geometry, or an inaccessible-state oracle.

## 5. Full remainder, bit length and positivity

### 5.1 Explicit separation

For trace norm induced on all matrices,

    ||L_R||_(1->1)<=2M+2gamma n.

The commutator bound is 2||H_R||<=2M, and every CPTP replacement has induced trace norm one, so ||E_i-Id||<=2. Choose the integer

    C=max(1,ceil(2M+2gamma n)),
    T_R=2^-(2C+20).                                      (2)

For 0<t<=1, ||rho_0||_1=1 and the norm of the final effect is one. Hence the entire Taylor remainder after degree r satisfies

    |R_R(t)|<=sum_[ell>=r+1] C^ell t^ell/ell!
             <=e^C t^(r+1).

Because e/4<1, (2) gives

    |R_R(T_R)|<=2^-20 T_R^r.                             (3)

Thus

    q_R=0  => p_R(T_R)<=2^-20 T_R^r,
    q_R>=1 => p_R(T_R)>=(1-2^-20)T_R^r.                  (4)

A 1/4-additive log estimate, compared against r log T_R-1, distinguishes the two alternatives with a large constant margin. Computing that threshold to error 1/16 uses ordinary certified arithmetic for log 2. A relative-probability estimate with error at most 1/2 also separates the two intervals directly.

The confidence 3/4 gives a BPP decision algorithm for the NP-complete tiling problem. Reduce SAT to that problem. Amplify each SAT decision call to failure at most 1/(100v) for a formula with v variables, use the decisions to choose a variable assignment one bit at a time, and verify the resulting assignment. An unsatisfiable formula is never accepted after verification; a satisfiable formula yields a witness with probability at least 0.99 by the union bound. Therefore SAT belongs to RP and NP=RP. In the deterministic case SAT belongs to P.

### 5.2 Complete finite input costs

For fixed gamma, C=O_gamma(n). The positive dyadic time is supplied as numerator one and an explicit denominator with 2C+21 bits. It therefore costs O_gamma(n) bits, not exp(n) bits. Its r-th power has O_gamma(n^2) bits. Hamiltonian coefficients are exactly one; all O(n) terms and all lattice coordinates are explicitly listed. Moore--Robson's reduction size and coordinate magnitudes are polynomial in the originating formula size.

No cost is declared polynomial in numeric 1/T. Such a cost could be exponential on these inputs. The original and proposed strengthened contracts are polynomial in complete binary input and numeric 1+T; the latter is bounded here. The reduction respects that contract exactly.

### 5.3 Strictly positive probabilities and polynomial-size logarithms

In the exact random-unitary unraveling, each of X,Y,Z has rate gamma/4. Consider histories with exactly one X jump at each site and no Y/Z or additional X jumps. Their total probability is

    w=e^(-3gamma nT_R/4)(gamma T_R/4)^n>0.

All these X jumps commute with H_R. On such a history, the target probability equals

    |<0^n|exp(-iT_R H_R)|0^n>|^2 >=(1-MT_R)^2>0.

Therefore

    p_R(T_R)>=w(1-MT_R)^2>0.                            (5)

In particular logarithms are well defined even when q_R=0. Equation (5) also bounds -log p_R by O_gamma(n^2), so the output magnitude/representation does not hide an unbounded real-number task. No zero-probability convention contributes to the hardness.

### 5.4 Conditional evaluators

Along the all-one string, every prefix probability is positive by (5). The chain rule gives

    log p_R(1^n)=sum_i log p_R(x_i=1 | x_1=...=x_(i-1)=1).

Requesting each log conditional to additive error 1/(8n), with per-call failure at most 1/(100n), computes the full log probability to error at most 1/8. Precision inverse and confidence digits are polynomial. Thus a uniformly polynomial log-conditional operation would also give the stated collapse. This concerns logarithms or relative conditional accuracy; an arbitrary fixed additive accuracy for raw conditional probabilities is a different contract.

## 6. What this proves, and what it leaves open

On exactly the instances above,

    TV(P_T_R,delta_[0^n])
      <=(1/2)||exp(T_R L_R)(rho_0)-rho_0||_1
      <=(1/2)(exp(C T_R)-1),                            (6)

which is exponentially small. A sampler returning 0^n is adequate at every inverse-polynomial TV tolerance on this hard family. A rare event cannot be amplified by a polynomial number of physical samples here. Thus this is explicitly **not** a generic noisy-2D TV sampling hardness theorem or a physical advantage demonstration.

The team's `machinery/FINAL_GLOBAL_READOUT_THEOREM.md` includes an additive probability of every product projector, including this target event. It does not contradict (4): a relative estimate would require additive tolerance comparable to T_R^r, whose inverse is exp(O_gamma(n^2)); that work is outside its polynomial-accuracy regime. The stronger mean theorem genuinely earns global parity/product readouts while leaving this probability task separate.

The constructor's bounded-cut TTN sampler has an additional architectural certificate absent from the arbitrary 2D family used here. Its `constructor/RELATIVE_MIXING_AND_SAMPLING_OBSTRUCTION.md` gives relative operator mixing only after gamma T>=log(4n/eta), far outside T_R. Neither theorem claims the uniform rare-event evaluator ruled out here.

There is no obstruction here for exclusively two-body interactions, a strictly positive lower-time promise, constant/intermediate-time TV sampling, or a physical-time polymer method above a noise-dependent threshold. Those remain substantive targets.

## 7. Optional stronger counting encoding: mixed tiles with aligned phases

This independent initial construction strengthens the encoded combinatorial object without changing the preceding scope limitations.

Let Z_R count tilings by the right tromino and the 2x2 square tetromino. Moore--Robson Section 2 is parsimonious from SAT. For each tile S choose one distinguished site y(S), and put

    P_S=Y_[y(S)] product_[i in S\{y(S)}] X_i,
    H_R(tau)=sum_[S in T_3] P_S+tau sum_[S in T_4] P_S,
    T=tau^3, 0<tau<=1.                                  (7)

All data are rational. Each physical site is in at most sixteen blocks (twelve trominoes and four squares), support size is at most four, range is one, and every coefficient is bounded by J=1. Let C>=max(1,2M_3+2M_4+2gamma n).

Write the exponent as tau^3 A+tau^4 B, with the noise in A. A three/four-site Hamiltonian factor has tau-degree three/four and flips three/four ket/bra coordinates. A noise factor has degree three and flips at most two. To reach |1><1| requires total degree at least 2n; equality excludes every noise factor and every repeated coordinate flip. Each side is an exact cover.

For a cover with m tiles, its unitary phase (-i)^m cancels the i^m from P_S|0^S>=i|1^S>. Its m! orderings cancel the exponential denominator, including when distinct covers have different m. Every cover has tau-degree n since its tile areas sum to n. Consequently

    p_R(tau)=Z_R^2 tau^(2n)+R_R(tau),
    |R_R(tau)|<=e^C tau^(2n+1).                          (8)

For the last bound, the sum of norms of all power-series coefficients of exp(tau^3A+tau^4B) is bounded by exp(||A||+||B||)<=e^C; evaluate the positive majorant at tau=1 and factor tau^(2n+1) from the tail.

For a requested 0<epsilon<=1/2, choose

    tau=2^-(2C+20+ceil(log_2(1/epsilon))).

The scaled probability differs from Z_R^2 by at most 2^-20 epsilon. A log evaluation accurate to epsilon/8 then gives a reliable zero test (separate scaled probability below 1/2 from at least 1-2^-20 epsilon), and, for Z_R>=1, exponentiating half the estimated scaled logarithm approximates Z_R multiplicatively. This is an approximation-preserving reduction from #SAT counting, not an assertion that a constant-accuracy answer recovers a #SAT count exactly. Every coefficient/time bit, logarithm, square root/exponentiation precision and output bit is polynomially charged. Strict positivity follows by the one-X-jump-per-site event: in the toggling frame all Hamiltonians have the same norm, so the target amplitude is at least 1-||H_R(tau)||T>0.

## 8. Post-exchange extension: the common biased reference does not remove the obstruction

Fix rational sigma=diag(p,1-p), 0<p<1, and any fixed rational gamma>0. The physical reset is exactly

    R_i^sigma(rho)=sigma_i tensor Tr_i(rho),
    L=-i[H,.]+gamma sum_i(R_i^sigma-Id).

For each logical cell i of a tromino region introduce a physical nearest-neighbor pair (i,a),(i,b), embedded at (2x,y),(2x+1,y). Define the exchange

    F_i=(X_[i,a]X_[i,b]+Y_[i,a]Y_[i,b])/2
       =|10><01|+|01><10|.

It has norm one, acts as logical X on span{|10>,|01>}, vanishes on |00>,|11>, and commutes with sigma tensor sigma. Set

    K_S=product_[i in S] F_i,
    H_R=sum_[S in T_3(R)] K_S,
    rho_0=|10>^n<10|^n,
    target=|01>^n.                                      (9)

Each WHOLE block K_S is rational, Hermitian, norm one, support size six and range at most three. Every physical site belongs to at most twelve blocks. All K_S commute, and every block commutes with the corresponding product sigma. Thus (9) satisfies the principal's conservation condition for every bias p, using physically unentangled product input. Individual Pauli summands need not preserve sigma; the permitted whole blocks do. Expanding K_S yields eight weight-six Pauli terms with rational coefficients 1/8 and bounded incidence, so this is also an original-form local Pauli Hamiltonian in the unital case.

There are N=2n physical sites and 2N=4n differing ket/bra coordinates between the initial and target matrix units. A nonzero K_S multiplication flips six coordinates on one side. A one-site biased reset either kills the matrix unit or changes at most two coordinates. Therefore, with r=2n/3, all coefficients below r vanish, and every length-r contributing word is Hamiltonian and forms an encoded tiling on each side. The action inside the encoded subspace is exactly the previous commuting-X construction. Hence

    p_R(T)=q_R^2 T^r+R_R(T),
    |R_R(T)|<=e^C T^(r+1), C>=max(1,2M+2gamma N).        (10)

Choosing T=2^-(2C+20) gives the identical separation and O_gamma(N)-bit time. This proves the same NP=RP consequence for a uniform all-time relative/log evaluator in the common-reference biased-reset class (at support bound six and range three).

For strict positivity, unravel resets as rate-gamma Poisson events whose prepared value is sampled from p,1-p. The event of exactly one reset per physical site, each preparing its target bit, has probability at least

    exp(-gamma NT)(gamma T)^N mu^N>0,
    mu=min(p,1-p).

Without H this history ends in the exact target product regardless of the input. Keeping all its reset times and values fixed, contractive telescoping of the intervening unitary channels changes the final state by trace norm at most 2MT. Therefore its target probability is at least 1-2MT>0. This yields an explicit positive lower bound and again polynomially bounded logarithm magnitude. This unraveling is a proof representation of the stipulated reset, not access to physical bath outcomes.

The encoded model also has an all-time additive local prediction result under the principal's proposed theorem. The relative obstruction is compatible with it. At exponentially short T the entire distribution remains close to the initial product, so no biased-reset TV hardness or constant-time obstruction is obtained.

## 9. Checks and status

- `audit_rare_event.py` / `AUDIT_RARE_EVENT.json`: twelve exact Gaussian-integer/rational Taylor checks, including absent-anchor boundary placements, gamma=1 and 7, and mixed-tile phase alignment. The initial ten cases were unchanged when the anchor enumerator was strengthened.
- `audit_dualrail.py` / `AUDIT_DUALRAIL.json`: six exact biased-reset cases, p=1/3 or 4/5 and gamma=1 or 7, with six and twelve physical qubits. The encoded leading coefficients are 1, 4 or 0 according to the exact cover count.

The proofs, not these finite checks, establish the reductions. The new post-exchange encoded extension and the initial reductions remain available for independent principal/hostile review. No initial report, manuscript or published file was edited, and no release or hardware operation was performed.
