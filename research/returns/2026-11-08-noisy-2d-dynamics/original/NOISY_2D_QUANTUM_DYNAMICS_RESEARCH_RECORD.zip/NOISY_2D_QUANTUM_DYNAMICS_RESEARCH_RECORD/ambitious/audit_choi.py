"""Exact Choi check of the finite-rate CPTP identity-mixture shortcut."""
import sympy as sp
from pathlib import Path
import json

g, gamma = sp.symbols('g gamma',positive=True)
K=sp.Matrix([[1,sp.I/g],[-sp.I/g,0]])
assert sp.simplify(K.det())==-1/g**2
K2=sp.Matrix([[1-3*gamma/(2*g),sp.I/g],[-sp.I/g,0]])
assert sp.simplify(K2.det())==-1/g**2
out={'status':'PASS','single_qubit_pure_H_Z':{'choi_compression':str(K),'determinant':str(K.det())},'two_qubit_H_ZZ_plus_each_site_replacement_noise':{'choi_compression':str(K2),'determinant':str(K2.det())},'scope':'Exact obstruction to fixed-g identity-plus-CPTP-event first-order representation. Not a counterexample to high-noise classical simulability.'}
Path(__file__).with_name('AUDIT_CHOI.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
