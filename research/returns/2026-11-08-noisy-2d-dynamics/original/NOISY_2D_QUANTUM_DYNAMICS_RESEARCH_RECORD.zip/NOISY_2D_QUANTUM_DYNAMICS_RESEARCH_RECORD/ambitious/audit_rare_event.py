"""Finite exact Taylor audits; these supplement, and do not prove, the reduction."""
from fractions import Fraction
from math import factorial
from pathlib import Path
import json, hashlib


def placements(region):
    reg=set(region); out=[]
    anchors={(x-dx,y-dy) for x,y in reg for dx in [0,1] for dy in [0,1]}
    for x,y in sorted(anchors):
        cell={(x,y),(x+1,y),(x,y+1),(x+1,y+1)}
        if cell<=reg: out.append((4,tuple(sorted(cell))))
        for missing in cell:
            tile=cell-{missing}
            if tile<=reg: out.append((3,tuple(sorted(tile))))
    return sorted(set(out))


def covers(n,masks):
    full=(1<<n)-1
    def rec(used):
        if used==full: return 1
        bit=((~used)&full)&-((~used)&full)
        return sum(rec(used|m) for m in masks if m&bit and not m&used)
    return rec(0)


def rot(v,q):
    a,b=v; q%=4
    return [(a,b),(-b,a),(-a,-b),(b,-a)][q]


def add(dst,k,v,scale=1):
    if not (v[0] or v[1]): return
    a,b=dst.get(k,(0,0)); w=(a+scale*v[0],b+scale*v[1])
    if w==(0,0): dst.pop(k,None)
    else: dst[k]=w


def audit(region,weighted,one_y,gamma,max_extra=2):
    pts=sorted(region); ids={p:i for i,p in enumerate(pts)}; n=len(pts)
    terms=[]
    for size,tile in placements(pts):
        if not weighted and size!=3: continue
        mask=sum(1<<ids[p] for p in tile)
        ymask=(1<<ids[tile[0]]) if one_y else 0
        degree=size if weighted else 1
        terms.append((mask,ymask,degree))
    masks=[t[0] for t in terms]
    z=covers(n,masks)
    target_degree=2*n if weighted else 2*(n//3)
    maxdeg=target_degree+max_extra
    full=(1<<n)-1
    cur={(0,0,0):(1,0)}
    coeffs={d:Fraction(0) for d in range(maxdeg+1)}
    peak=len(cur)
    for ell in range(maxdeg+1):
        denominator=(4**ell)*factorial(ell)
        for (degree,a,b),v in cur.items():
            if a==full and b==full:
                assert v[1]==0
                coeffs[degree]+=Fraction(v[0],denominator)
        if ell==maxdeg: break
        nxt={}
        for (degree,a,b),v in cur.items():
            for mask,ymask,shift in terms:
                if degree+shift>maxdeg: continue
                ya=(a&ymask).bit_count()%2
                yb=(b&ymask).bit_count()%2
                ynum=ymask.bit_count()
                add(nxt,(degree+shift,a^mask,b),rot(v,ynum+2*ya-1),4)
                add(nxt,(degree+shift,a,b^mask),rot(v,1-ynum-2*yb),4)
            noise_shift=3 if weighted else 1
            if degree+noise_shift<=maxdeg:
                diag=0
                for i in range(n):
                    bit=1<<i
                    same=not ((a^b)&bit)
                    if same: add(nxt,(degree+noise_shift,a^bit,b^bit),v,2*gamma)
                    diag-=2*gamma if same else 4*gamma
                add(nxt,(degree+noise_shift,a,b),v,diag)
        cur=nxt; peak=max(peak,len(cur))
        if not cur: break
    assert all(v==0 for d,v in coeffs.items() if d<target_degree), (n,coeffs)
    assert coeffs[target_degree]==z*z, (n,z,coeffs)
    return {'n':n,'weighted_3_4':weighted,'one_Y_per_term':one_y,'gamma':gamma,
            'terms':len(terms),'cover_count':z,'leading_degree':target_degree,
            'leading_coefficient':str(coeffs[target_degree]),
            'nonzero_coefficients':{str(d):str(v) for d,v in coeffs.items() if v},
            'peak_sparse_coefficients':peak}

if __name__=='__main__':
    cases=[]
    rectangle=lambda a,b:[(x,y) for x in range(a) for y in range(b)]
    for g in [1,7]:
        cases.append(audit(rectangle(2,3),False,False,g))
        cases.append(audit([(x,0) for x in range(6)],False,False,g))
        cases.append(audit(rectangle(2,2),True,True,g))
        cases.append(audit([(1,0),(0,1),(1,1)],False,False,g))
        cases.append(audit(rectangle(2,3),True,True,g))
        cases.append(audit([p for p in rectangle(2,4) if p!=(1,3)],True,True,g))
    report={'status':'PASS','scope':'Exact rational finite Taylor coefficients only; not a proof of complexity hardness.', 'cases':cases}
    path=Path(__file__).with_name('AUDIT_RARE_EVENT.json'); path.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
