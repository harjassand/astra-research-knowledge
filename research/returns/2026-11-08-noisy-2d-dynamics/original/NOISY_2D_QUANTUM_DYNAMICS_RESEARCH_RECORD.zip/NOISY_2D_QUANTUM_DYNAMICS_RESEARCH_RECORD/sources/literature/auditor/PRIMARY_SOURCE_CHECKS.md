# Primary-source applicability checks

Auditor, 8 November 2026. Read independently before the initial report was frozen,
except the additional notebook cell inspection explicitly marked below. PDF
bytes and hashes are pinned in `CACHE_MANIFEST.json`; extracted text is from
pypdf and equations were cross-checked against the primary arXiv renderings.
These notes paraphrase imports narrowly. No claim of complete priority search.

| Primary source | Exact relevant result and assumptions | Use / missing operation |
|---|---|---|
| King, arXiv:1210.8412v1 | Corollary 2, (17): tensor products of qubit depolarization contract normalized Schatten p to q for 1<p<=q iff exp(-t)<=sqrt((p-1)/(q-1)). Theorem 1 more generally concerns tensor products of self-adjoint unital qubit semigroups with normalized positive generators. | The replacement generator has depolarizing parameter exp(-gamma t). Interleaving with Hamiltonian Schatten isometries yields the buffer bound by a separate derivation; no randomness assumption. |
| Haah--Hastings--Kothari--Low, arXiv:1801.03922v4 | Lemma 5, (4), and Appendix C.4 (48),(49): strictly local Hamiltonian truncation error controlled by support size times (2 zeta_0 t)^ell/ell!, with zeta_0=max_x sum_{Z containing x}|Z| ||h_Z||; ell is distance in a metric scaled to range one. | Original term bounds give zeta_0<=kdJ. The time-ordered proof extends to uniformly bounded piecewise pulse Hamiltonians; the claim is proved by linked simplex integrals, not by silently extending a static statement. |
| Bravyi--Gosset--Movassagh, arXiv:1909.11485v1 | Theorem 5: n qubits on a 2D grid, nearest-neighbor two-qubit depth-d circuit, product Hermitian observable with each local norm<=1; randomized additive delta mean estimation in n delta^-2 2^O(d^2) time with success at least 2/3. | Supplies parity-strip/overlap architecture. The growing Trotter depth cannot be charged by this theorem. The governing report's accumulated-angle Schmidt bound and constructive compression supply that missing operation. |
| Angrisani--Puig--Teng--Holmes, arXiv:2609.40174v2 | Lemma S15 (S112)--(S114), Corollary S16: local active-sector coefficient l_p contraction when 2J(2/p-1)<=gamma. Lemma S6 (S41),(S42): threshold l2 error and retained-count bounds from l_p. Section S10.8 averages fixed-input error over a Pauli-invariant Hamiltonian ensemble, with input chosen independently of its realization. | The coefficient mechanism applies after the report's noise-rate allocation. The report derives its rational finite-step analogue. No averaged operational bound is imported as a pointwise statement. |
| Nelson--Rajakumar--Yin--Zhang--Gullans, arXiv:2610.00548v2 | Formal Theorem 2.3: circuits in Definition 2.1 on a fixed-D lattice, unital local layers, every-site depolarizing noise p per layer, depth d beyond O((D/p)log(D/p)+3^D/p). Deterministic additive approximation of log arbitrary marginal probabilities, hence relative sampling via Proposition 2.2. | A full sampling comparator at fixed p. Trotter p=O(gamma h) makes its critical physical time grow like log(1/h)/gamma. It does not directly yield a uniform continuous-time theorem. |
| Coudron--Gullans--Nelson--Rajakumar--Tan, arXiv:2610.02146v1 | Theorem 1.1: deterministic polynomial additive estimation of a specified output probability for every fixed circuit depth and bounded fan-in, arbitrary connectivity. Section 1.2 obtains magnitude of a product-operator mean from a squared-overlap probability and expressly leaves its general sign/phase unresolved. | Does not replace the signed global-Pauli buffer, nor provide sampling or a growing-depth theorem. Appendix A retains explicit depth/degree dependence; fixed depth cannot be silently exchanged for O(log log n) physical duration. |
| Trivedi--Cirac, arXiv:2110.10638v2 | Theorem 1: for sufficiently strong entanglement-breaking noise compared with local interaction strength, polynomial continuous-time total-variation sampling. Theorem 2: Hamiltonian low-noise hardness for the biased entanglement-breaking channels in (4), where the measurement effect P has minimum eigenvalue >1/2. Theorem 3: a separate purely dissipative construction with multiplicative simulation hardness. | High-noise sampler is a real incumbent. Low-noise conclusions do not transfer to depolarizing replacement by I/2; the biased channel provides cooling entropy. |
| Gonzalez-Garcia--Cirac--Trivedi, arXiv:2407.16068v2 | Section 6 and Theorem 3 give a worst-case failure of a Pauli-path truncation method for suitable constant noise below its threshold. The paper explicitly says the constructed circuit is itself trivially classically simulable. Its positive Theorems 1 and 2 have gate/noise/geometric assumptions. | A method failure is not a complexity obstruction. This is consistent with preserving the governing sparse+buffer result rather than declaring impossibility from a truncation counterexample. |
| Kashyap--Styliaris--Mouradian--Cirac--Trivedi, arXiv:2404.11081v2 | The described 2D Lindbladian constructions include dissipative ancilla reset and a noise-reduction limit. The analogue simulator is a Hamiltonian coupled to continuously ground-state-reset ancillae; general local Lindbladian simulation, stability, and advantage are the actual tasks. | No imported obstruction for the fixed-rate, unital-only model. A cold bath or reset is an added capability and must be costed. |

Primary URLs:

- https://arxiv.org/pdf/1210.8412v1
- https://arxiv.org/pdf/1801.03922v4
- https://arxiv.org/pdf/1909.11485v1
- https://arxiv.org/html/2609.40174v2
- https://arxiv.org/html/2610.00548v2
- https://arxiv.org/html/2610.02146v1
- https://arxiv.org/pdf/2110.10638v2
- https://arxiv.org/pdf/2407.16068v2
- https://arxiv.org/html/2404.11081v2

## Relevant recent Zenodo discovery

The public API was searched for `"noisy quantum"`, `"depolarization" AND
"simulation"`, and `"Harjas Sandhu" AND "quantum"`, sorting most recent.
The exact returned discovery metadata are in `ZENODO_DISCOVERY.json`.
Two plausibly relevant October 2026 records were inspected through their
primary metadata:

- [23418780](https://zenodo.org/records/23418780), George Stavisskii,
  *Noise structuring in fixed-depth Trotter simulation: stationary channels and
  observable-level depolarization: numerical support*, 16 October 2026.
  The single deposited notebook was additionally downloaded and its cells
  inspected **after initial freeze**. SHA256 and URL are in
  `ZENODO_23418780_DOWNLOAD.json`. It implements spin-chain/Trotter and
  zero-noise-extrapolation numerical experiments. Its code applies discrete
  noise after compiled CNOTs, with optional noise on physical one-qubit gates
  and noiseless virtual Z rotations. This is a different numerical channel
  model, not a uniform signed continuous-time prediction or sampling theorem.
  No theorem or numerical advantage is imported from it.
- [23414157](https://zenodo.org/records/23414157), anonymous artifact,
  *Live Noise Fingerprints as an Empirical Semantics for Noisy Quantum Channels*,
  16 October 2026. Its primary metadata describe channel fingerprints,
  classical-shadow measurements, small-system SDPs, and simulated evaluation.
  Its files were not imported or executed. It supplies no premise used here.

These checks establish only the actual scopes of found records. They do not
establish that no relevant Zenodo preprint exists elsewhere, nor that any
theorem in this investigation has priority.
