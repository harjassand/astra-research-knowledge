# Independent ambitious investigation: full-output sampling and logarithmic probabilities

Researcher: fourth independently commissioned GPT-6.1 Sol researcher, maximum reasoning. Date: 8 November 2026, Australia/Brisbane. Initial report: frozen before receiving other researchers' constructions. No further subagent was used.

## Result and status

**A uniform polynomial-bit logarithmic-marginal evaluator for the entire original class is obstructed by an explicit NP-hardness reduction, at every fixed positive rational replacement-noise rate.** The obstruction already uses commuting three-body Pauli-X interactions on elementary L-trominoes of the square lattice, rational product input, and a positive dyadic time with only O(n) bits. It does not require zero probabilities, extra physical controls, noiseless registers, a reset bath, or a conditioning oracle.

A strengthened four-body construction gives an approximation-preserving encoding of #SAT counts in strictly positive noisy probabilities. Its additional operation is a one-Y phase choice that aligns coverings with different tile counts, together with a degree-balanced coupling/time substitution. Complete proofs are below. These are mathematical reductions, independently derived here and checked on finite exact Taylor coefficients; they have not yet received an independent team audit. Historical novelty is not asserted.

**An efficient full-output total-variation sampler at every fixed positive noise-to-interaction ratio remains OPEN / NOT_ACHIEVED.** The hard rare-probability examples below are themselves exponentially close in total variation to the deterministic initial output, so this reduction specifically does not obstruct the sampler. The direct discrete-circuit import still fails in the continuous limit. A physical-time cluster-expansion route remains a candidate with a precise missing lemma.

A separate source check finds that the printed proof of Lemma 3 of Trivedi--Cirac, arXiv:2110.10638v2, uses a completely-positivity assertion contradicted by a one-qubit Hamiltonian. This is an explicit objection to that proof step, not a proof that their high-noise conclusion is false. Do not silently import that lemma as verified machinery.

## Governing source and independence

Read: root `AGENTS.md`, `outputs/RESEARCH_TO_PUBLICATION_WORKFLOW.md`, and the original `sources/original/Case_B_second_final/{RESEARCH_REPORT.txt,ENDPOINT.json,SOURCE_SCOPE.json}`. Original report SHA256:

`32b605ec5ccdc6897af1a24b1be951e0e3ad787a0b4fbff679541d1980ca841b`.

No machinery/constructor/auditor/principal/other initial or follow-up files were read before this report was written. Public primary literature was independently retrieved into `sources/literature/ambitious/`. The Astra retrieval connector was unavailable. No hardware experiment, public release, outreach, additional worker, or new physical control occurred.

The inherited result is additive prediction of a fixed-local observable for a specified rational product input, with polynomial bit cost at each fixed gamma/J>0. It excludes full-distribution sampling and relative probabilities. I inspected its full report, including the Schmidt-nuclear-norm truncation and bounded mixture-overlap steps. The reductions below use its physical/input contract but do not depend on its algorithm or require promoting its claim to a different norm.

Throughout, the physical generator is exactly

\[
\mathcal L(\rho)=-i[H,\rho]+\gamma\sum_i(E_i(\rho)-\rho),\qquad
E_i(\rho)=\tfrac{I_i}{2}\otimes\operatorname{Tr}_i\rho .
\]

The equivalent Pauli-conjugation jump rate is gamma/4 for each X,Y,Z on each site. The output is a computational-basis measurement of every physical qubit.

## 1. A genuine obstruction to uniform log-marginal computation

### Theorem A: commuting three-body subfamily

Fix any positive rational gamma. Set the declared interaction bound J=1. Given an explicit finite square-lattice region R with n sites, let T_3(R) be all elementary right-tromino placements contained in R; these are the three vertices of a unit square after deleting one corner. Put

\[
H_R=\sum_{S\in\mathcal T_3(R)}X_S,
\qquad \rho_0=|0^n\rangle\langle0^n|.
\]

Every term has support size three, maximum-metric diameter one, and coefficient one; every site is in at most twelve terms. All terms commute. All sites, including boundary sites, have the original replacement noise at rate gamma.

There is a polynomial-time computable positive dyadic T_R, of binary length O_gamma(n), such that any algorithm which computes

\[
\log p_R(T_R),\qquad
p_R(t)=\langle1^n|e^{t\mathcal L_R}(\rho_0)|1^n\rangle,
\]

to additive error 1/4, with success probability at least 3/4, in polynomial complete-input bit complexity, decides an NP-complete tiling problem in randomized polynomial time. Consequently such a uniform log evaluator implies NP is contained in BPP. Standard SAT self-reduction and final witness verification strengthen this to NP=RP. A deterministic evaluator implies P=NP.

The same consequence holds for a constant-relative-error evaluator for this single full-output probability, for arbitrary-marginal log evaluation, or for log-conditional evaluation accurate to O(1/n), by the chain rule and a union bound. This is a computational obstruction conditional on the stated complexity separation, not an unconditional lower bound on all algorithms.

### Primary combinatorial import

Moore and Robson, *Hard Tiling Problems with Simple Tiles*, arXiv:math/0003039v1, Section 3 and the end of Section 3.1 (PDF pp. 6--11), prove that deciding a tiling of an explicit finite region of the square lattice by rotated right trominoes is NP-complete. Holes are allowed. Their construction has polynomial size. The paper does **not** establish #P-completeness for right trominoes alone; I do not import that stronger assertion. Their separate Section 2 does establish a parsimonious SAT reduction for right trominoes together with square tetrominoes, used only in Theorem B below.

The import's hypotheses match exactly: a lattice cell is represented by one qubit at its lattice coordinate; every permitted rotated tromino is an allowed range-one three-body interaction. At most four unit squares contain a given site, and three right trominoes in each such square contain it, proving the bound twelve. If n is not divisible by three the tiling answer is immediately no; the hard residual instances have n=3m.

### Proof: the leading coefficient counts exact covers

Let q_R be the number of tromino tilings, n=3m, and r=2m. Expand the Lindbladian into elementary left and right Hamiltonian multiplications and one-site Pauli conjugations/identity terms:

\[
\mathcal L_R=-i\sum_S(X_S\cdot-\cdot X_S)
+\frac\gamma4\sum_{i,P\in\{X,Y,Z\}}(P_i\cdot P_i-\mathrm{id}).
\]

Follow a matrix unit |a><b| starting at |0><0|. To contribute to the final matrix entry |1><1|, every one of the 2n ket/bra site coordinates must be flipped an odd number of times. An elementary Hamiltonian multiplication flips three coordinates on one side. An elementary noise operation flips at most two coordinates, one on each side. A word of length less than 2n/3 cannot cover all 2n coordinates. At length r=2n/3, every factor must be Hamiltonian, each coordinate must be flipped exactly once, and the m ket-side factors and m bra-side factors each form a tromino tiling. This proves both the vanishing of lower coefficients and the absence of noise from the leading coefficient.

Equivalently, the leading unitary transition amplitude is

\[
\langle1^n|e^{-itH_R}|0^n\rangle=(-i)^m q_Rt^m+O(t^{m+1}).
\]

Each tiling has m! orders, canceled by the exponential's m! denominator; disjoint Pauli terms commute. All tilings have the same phase. Therefore

\[
 p_R(t)=q_R^2t^r+\mathcal R_R(t).
\tag{A1}
\]

This argument uses actual words in the density-matrix generator. It does not assume independent noise after the Hamiltonian or commute depolarization through it.

### A polynomial-bit separation

Let M=|T_3(R)|<=4n and choose an integer

\[
 C\ge\max(1,2M+2\gamma n).
\]

The trace-norm induced operator bound is ||L_R||_{1->1}<=2M+2gamma n<=C. For 0<t<=1, the entire Taylor tail after degree r obeys

\[
 |\mathcal R_R(t)|
 \le \sum_{\ell\ge r+1}\frac{C^\ell t^\ell}{\ell!}
 \le e^Ct^{r+1}.
\]

Choose the explicit dyadic

\[
 T_R=2^{-(2C+20)}.
\tag{A2}
\]

Since e/4<1,

\[
 |\mathcal R_R(T_R)|\le 2^{-20}T_R^r.
\tag{A3}
\]

Thus an untileable instance satisfies p_R<=2^-20 T_R^r, while a tileable instance satisfies p_R>=(1-2^-20)T_R^r. Computing log p_R to error 1/4 and comparing with r log T_R-1 distinguishes these cases with a wide constant margin. The threshold can be computed to, say, 1/16 with polynomial ordinary bit arithmetic; only log 2 is needed. All n qubits, O(n) terms, coordinate bits, and O(n)-bit time denominator are explicitly charged. The small numerical time does not hide an inverse-time oracle: the original contract is polynomial in complete bits and numeric 1+T, not in 1/T.

### Positivity, including no-tiling instances

These probabilities are strictly positive. In the exact Pauli-jump unraveling, consider exactly one X jump at every site and no other jumps. Its probability is

\[
 e^{-3\gamma nT_R/4}(\gamma T_R/4)^n>0.
\]

For the commuting-X Hamiltonian these jumps commute with H_R. Their conditional probability of the target outcome is |<0|exp(-iT_RH_R)|0>|^2 >=(1-MT_R)^2>0. Thus no zero-probability/logarithm convention is exploited. Their logarithms have polynomially bounded magnitude in the complete input bits.

### Why this does not obstruct total-variation sampling

For this very same family,

\[
 \operatorname{TV}(P_{T_R},\delta_{0^n})
 \le\tfrac12\|e^{T_RL_R}(\rho_0)-\rho_0\|_1
 \le\tfrac12(e^{CT_R}-1).
\]

This is exponentially small. Returning 0^n is already a sampler of the requested inverse-polynomial total-variation accuracy on these instances. The hardness lies in the explicitly encoded rare event and the demanded **relative/logarithmic** accuracy. It supplies no hardness result for the full-output TV task.

### Scope boundary

Theorem A covers three-body-or-more original classes and arbitrarily small positive rational times. It does not establish an obstruction for the exclusively two-body subfamily, for a promise T>=T_min>0 independent of n, or for additive local observables. Those questions remain separate. Filling unused sites of a polynomial-size bounding rectangle with decoupled noisy qubits preserves the arbitrary-marginal obstruction, so holes need not be a physical device feature if full rectangular lattices are required.

## 2. A stronger count encoding without cancellation between differently sized tiles

### Theorem B: mixed tiles and a one-Y phase

Let R be an instance of the Moore--Robson right-tromino/square-tetromino tiling problem and Z_R its number of tilings. Their Section 2 gives a polynomial parsimonious reduction from SAT, so Z_R is a #SAT count for the produced region. For each tile S, fix its lexicographically first site y(S) and define the Hermitian Pauli

\[
 P_S=Y_{y(S)}\prod_{i\in S\setminus\{y(S)\}}X_i.
\]

For a positive rational tau<=1 set

\[
 H_R(\tau)=\sum_{S\in T_3(R)}P_S
       +\tau\sum_{S\in T_4(R)}P_S,
 \qquad T=\tau^3.
\tag{B1}
\]

This remains an original-model static rational Pauli Hamiltonian. It has k=4, range one, degree at most sixteen, and coefficients of magnitude at most J=1. It can be noncommuting; disjoint tiles commute. The input is again |0^n>, all n sites have the original replacement noise at the fixed rate gamma, and the target is 1^n.

There is an explicit C=O_gamma(n), computable from the term count, such that

\[
 \left|p_R(\tau)-Z_R^2\tau^{2n}\right|
 \le e^C\tau^{2n+1}.
\tag{B2}
\]

Choosing tau=2^-(2C+20+ceil(log_2(1/epsilon))) makes the scaled probability approximate Z_R^2 to additive at most 2^-20 epsilon. A uniformly polynomial-bit log/relative evaluator with inverse-polynomial accuracy therefore gives an approximation-preserving randomized algorithm for #SAT, including a reliable zero test. This is stronger accounting of the encoded count; it does not turn the result into TV sampling hardness or establish a new historical priority.

### Proof of (B2)

Write

\[
 T\mathcal L_R(\tau)=\tau^3A+\tau^4B,
\]

where A contains the three-site Hamiltonian commutators and all the replacement noise, and B contains the four-site Hamiltonian commutators. We can take

\[
 \|A\|_{1\to1}\le 2M_3+2\gamma n,
 \quad\|B\|_{1\to1}\le 2M_4,
 \quad C\ge\max(1,2M_3+2M_4+2\gamma n).
\]

Consider the power series in tau of exp(tau^3 A+tau^4 B). A three-site Hamiltonian multiplication has degree three and flips three ket/bra coordinates. A four-site Hamiltonian multiplication has degree four and flips four. A noise factor has degree three and flips at most two. Hence total degree less than 2n cannot reach |1><1|; at degree 2n, no noise occurs and the Hamiltonian factors on each side form an exact tile cover.

The apparent phase problem from variable tile counts is paid, not omitted. On an all-zero tile, P_S|0^S>=i|1^S>. For every disjoint cover with m tiles, the factor (-i)^m from unitary evolution cancels i^m from the one-Y matrix elements. Each ordered cover therefore contributes positively; its m! orderings cancel the exponential denominator even when covers have different m. Also each three/four-site tile contributes tau^3/tau^4 respectively, so every cover has exactly degree n. The ket transition amplitude has coefficient Z_R at tau^n, and the bra coefficient is its conjugate. The leading noisy probability coefficient is Z_R^2 at degree 2n.

For the remainder, the sum of norms of all power-series coefficients is bounded by exp(||A||+||B||)<=e^C, using the majorant exp(||A||z^3+||B||z^4) at z=1. Thus the total tail of degrees at least 2n+1 at 0<tau<=1 is at most e^C tau^(2n+1), proving (B2). This bound avoids any uncharged differentiation or coefficient-extraction oracle.

The total binary description has polynomial length: O(n) tile terms, O(n+log(1/epsilon)) bits for tau and its dependent coefficients, and three times that exponent for T. A #SAT zero is distinguished from a positive count by the same constant log gap as in Theorem A. For Z_R>=1, taking the positive square root of the scaled estimate approximates Z_R multiplicatively with the requested precision. Exponentiation of polynomial-magnitude logarithms and rounding cost polynomial bit work. The physical no-jump/Pauli-jump representation again proves p_R>0: with exactly one X jump per site, the toggling-frame Hamiltonian has norm at most M_3+tau M_4, and its total evolution differs from identity by at most that norm times T, so this history has positive target probability.

## 3. Continuous full-TV sampler: routes tested and the missing operation

### 3.1 The fixed-p circuit theorem is not a continuous-time theorem

Nelson--Rajakumar--Yin--Zhang--Gullans, arXiv:2610.00548v2, Theorem 2.3, assumes nearest-neighbor two-qubit unital circuit layers, an all-zero product input, and every-site depolarization of fixed strength p after every layer. It gives deterministic log-marginal error epsilon above a critical depth

\[
 d_{crit}=O((D/p)\log(D/p)+3^D/p).
\]

Proposition 2.2 converts log error epsilon into pointwise sampling factors exp(+-2n epsilon). This is the strongest comparator, and it is explicitly stronger than a TV sampler.

For a colored Trotter step h, d is proportional to T/h but p is proportional to gamma h. The sufficient physical-time threshold consequently grows like gamma^-1 log(1/h), and its polynomial exponent also diverges. Neither a fixed finite T nor uniform polynomial bit cost survives h->0. In addition, trace-norm Trotter accuracy alone does not certify relative errors on the rare events of Sections 1--2. This is a rigorous non-applicability diagnosis, not a counterexample to their fixed-p theorem.

### 3.2 A physical-time polymer route was attempted, not completed

Their polymer factorization uses strict disjoint backward light cones of separated spatial blocks. Continuous evolution has factorially small tails, rather than strict light cones. A successful continuous analogue would need an absolutely convergent, computable decomposition into local connected contributions whose activities satisfy a Kotecky--Preiss bound with constants depending on physical gamma/J, not on a Trotter layer count.

The attractive scale is a constant physical block time followed by a noise/hypercontractive buffer. One would retain a physical-time decay of Pauli weight and a physical-time locality penalty. The decisive unpaid operation is to turn the residual long weak connections into **multiplicative/logarithmic** errors uniform over all partial output strings, or into a direct positive sampler with total error controlled before conditioning. Ordinary additive Lieb--Robinson error is insufficient: a normalized probability can be exponentially small. Theorem A also proves that no repair can produce a uniform log evaluator down to arbitrarily small T in the full original class unless the displayed complexity collapse occurs.

I did not prove a continuous zero-free cluster expansion or a positive patching sampler. A possible revised target is a relative sampler only after a positive physical mixing threshold T_c(gamma/J), together with a different TV-only method below T_c. The early-time method remains missing; a result for the late-time interval alone would not complete the all-T TV question.

### 3.3 A finite-rate CPTP Poissonization shortcut is impossible as stated

A tempting shortcut is to replace a small coherent channel by identity with probability 1-gh and a CPTP event with probability gh, with g independent of h. For H=Z, suppose

\[
 e^{-ih[Z,\cdot]}=(1-gh)\mathrm{id}+gh\Phi_h+O(h^2)
\]

in any fixed finite-dimensional operator norm, with every Phi_h CPTP. Rearranging and taking h->0 forces Phi_h->id-i[Z,.]/g. The CPTP cone is closed. However, its normalized Choi matrix restricted to the orthonormal vectors |Omega> and (Z tensor I)|Omega> is

\[
 \begin{pmatrix}1&i/g\\-i/g&0\end{pmatrix},
\]

with determinant -1/g^2. It is not positive. Therefore no such fixed-rate representation exists. This does not rule out ordinary quantum jump unravelings, which keep the coherent Hamiltonian drift rather than dropping almost all coherent gates.

The printed proof of Trivedi--Cirac arXiv:2110.10638v2, Lemma 3 (PDF p. 8), asserts precisely the false ingredient that id+g^-1 L can be made CPTP for an arbitrary local Lindbladian by choosing finite g. Their Theorem 1 is a claimed high-noise TV sampler, and their low-noise Hamiltonian hardness uses nonunital noise; neither supplies the original all-positive-gamma result. The one-qubit calculation invalidates the cited CP assertion. This report does not claim to have disproved the high-noise theorem itself; a different construction or a repaired primary proof could establish it.

Even adding arbitrary one-site replacement noise does not repair the fixed-event-rate shortcut for a Hamiltonian Pauli P of weight at least two. In the vectorized-I/vectorized-P Choi compression of id+L/g, the P-P diagonal is zero (the dissipative jump span contains only weight-one Paulis), while the off-diagonal is the nonzero Hamiltonian coefficient divided by g. Its determinant is negative. Thus this particular shortcut remains blocked even at high noise.

## 4. Import checks, novelty boundary, and source accounting

- **Moore--Robson:** primary PDF read through the actual tiling constructions and size/counting qualifications; Section 3 supplies NP-completeness for rotated right trominoes on regions with holes, Section 2 supplies the parsimonious mixed-tile count reduction. Those are the only imported hardness facts.
- **Nelson et al.:** primary HTML read, including Theorem 2.3, Proposition 2.2, Section 5's strict-light-cone weight argument, and the stated noise/depth assumptions. It is a fixed-p discrete comparator, not a continuous import.
- **Trivedi--Cirac:** primary HTML and PDF read, including Theorem 1, the Hamiltonian/nonunital low-noise distinction, and Lemma 3's CP assertion. The explicit challenge is recorded above, rather than hiding a source issue.
- **Fujii--Tamate:** arXiv:1406.6932v3, Theorem 1/Corollary 1 and their proofs inspected. Their protected noisy relative-sampling obstruction uses a 3D cluster-state construction and discrete noise hypotheses. I do not import it into this 2D continuous static model.
- **Haferkamp et al., arXiv:1908.08069v2:** inspected as a primary predecessor for short-time 2D Hamiltonian output-probability hardness. Its noiseless architectures and exact average-case claims do not by themselves establish fixed-rate continuous-noise hardness here.
- **Wild--Alhambra, arXiv:2210.11490v2:** inspected as a short-time cluster-expansion comparator for local means and Loschmidt amplitudes. Overlap with the same product input has a nonzero constant term; it does not give the cross-state rare-event log evaluator ruled out above.

Targeted web searches included continuous-time depolarization sampling/cluster expansion, noisy commuting-circuit relative hardness, exact-cover Hamiltonian amplitudes, short-time Taylor complexity, and tromino quantum Hamiltonians. Public Zenodo API searches and returned metadata are retained in `sources/literature/ambitious/ZENODO_SEARCH*.json`. The searches are a scoped novelty check, not a proof of priority or exhaustive absence. No identified earlier source was used for the specific leading-noisy-coefficient reduction, but this does not establish that the reduction is historically new.

The mathematical ingredients are elementary power-series accounting, an established NP/#SAT tiling reduction, and exact Pauli phases. Credit the tiling literature directly. The strongest new operation in this report is the combination that makes a finite-bit rare-probability obstruction survive the original every-site continuous depolarization, particularly the mixed-tile phase/degree balancing. No practical quantum advantage follows: the hard probabilities are extraordinarily small and the entire output law is close to trivial on these chosen instances.

## 5. Exact executed checks and remaining challenges

Supporting script: `ambitious/audit_rare_event.py`. Output: `ambitious/AUDIT_RARE_EVENT.json`. It uses integer Gaussian coefficients and exact rational factorial denominators, not floating-point extrapolation.

Ten cases at gamma=1 and 7 passed:

- A 2x3 rectangle has two right-tromino tilings; the commuting-X noisy probability starts at degree four with coefficient four, independently of gamma.
- A length-six line has no allowed tromino and no coefficient through degree four; its first recorded noise-only coefficient is gamma^6/64 at degree six.
- Mixed three/four-body one-Y cases with four, six, and seven sites have leading tau-degree 2n and coefficient Z_R^2; no lower coefficient occurs. The seven-site shape has one mixed cover and leading coefficient one at degree fourteen.

These finite audits check signs, jump-rate convention, absence of lower-degree noise, and the proposed leading coefficients. The general reduction is proved above; the scripts do not establish NP-completeness or uniform complexity lower bounds.

Remaining independent challenge targets:

1. Recheck the matrix-unit flip-count argument against arbitrary noise terms and the exact gamma/4 convention.
2. Recheck the mixed-size one-Y phase alignment and polynomial-bit remainder uniformly in the finite region.
3. Confirm the precise Moore--Robson region/rotation/counting scopes from the pinned primary PDF.
4. Test whether an exclusively two-body analogue or a positive lower-time promise admits a stronger obstruction; none is claimed here.
5. Attack the all-T TV sampler directly. Neither rare conditioning, failed truncation, the discrete threshold mismatch, nor the CP shortcut obstruction is a generic hardness proof for that target.

| Claim | Status | Scope |
| --- | --- | --- |
| Original local additive prediction | Retained capital | Original exact contract; not promoted to global probability |
| Theorem A leading coefficient and bit separation | Proved here, pending independent team audit | Commuting 3-body range-one 2D Hamiltonians, fixed gamma>0, exponentially short positive times |
| NP obstruction to uniform log/relative evaluator | Conditional complexity consequence of proved reduction | NP not contained in BPP, or equivalently no asserted collapse |
| Theorem B mixed-tile count encoding | Proved here, pending independent team audit | 3/4-body one-Y terms with rational tiny four-body coefficient |
| Fixed-rate identity/CPTP coherent-event shortcut | Disproved by exact Choi counterexample | Specific finite-rate representation, including TC Lemma 3 ingredient |
| Uniform full-output TV sampler at every positive gamma/J | Open / NOT_ACHIEVED | Original general 2D continuous-time physical class |
| Continuous physical-time polymer zero-free/positive sampler | Candidate with decisive missing lemma | No theorem or resource bound earned |

## References and local primary cache

1. C. Moore and J. M. Robson, *Hard Tiling Problems with Simple Tiles*, arXiv:math/0003039v1 (2000); Discrete & Computational Geometry 26, 573--590 (2001), DOI [10.1007/s00454-001-0047-6](https://doi.org/10.1007/s00454-001-0047-6). [Primary preprint](https://arxiv.org/pdf/math/0003039v1); cached `sources/literature/ambitious/MooreRobson_math0003039v1.pdf` and `.txt`.
2. J. Nelson, J. Rajakumar, C. Yin, Y. F. Zhang, M. J. Gullans, *A polynomial-time classical sampler for noisy quantum circuits from statistical mechanics*, [arXiv:2610.00548v2](https://arxiv.org/html/2610.00548v2). Cached `NR2610.00548v2.html/.txt`.
3. R. Trivedi and J. I. Cirac, *Simulability transitions in continuous-time dynamics of local open quantum systems*, [arXiv:2110.10638v2](https://arxiv.org/pdf/2110.10638v2). Cached `TC2110.10638v2.pdf/.html/.txt` and `_pdf.txt`.
4. K. Fujii and S. Tamate, *Computational quantum-classical boundary of noisy commuting quantum circuits*, [arXiv:1406.6932v3](https://arxiv.org/html/1406.6932v3). Cached `FT1406.6932v3.html`.
5. J. Haferkamp et al., *Closing gaps of a quantum advantage with short-time Hamiltonian dynamics*, [arXiv:1908.08069v2](https://arxiv.org/html/1908.08069v2). Cached `HH1908.08069v2.html`.
6. D. S. Wild and A. M. Alhambra, *Classical simulation of short-time quantum dynamics*, [arXiv:2210.11490v2](https://arxiv.org/html/2210.11490v2). Cached `WA2210.11490v2.html`.
