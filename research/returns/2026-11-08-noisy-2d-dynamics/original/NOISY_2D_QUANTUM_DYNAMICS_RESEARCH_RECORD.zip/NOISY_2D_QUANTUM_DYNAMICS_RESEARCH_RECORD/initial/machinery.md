# Independent initial report: global product readouts under noisy 2D dynamics

Date: 8 November 2026. Researcher: existing-machinery investigator, one of the three independently commissioned GPT-6.1 Sol researchers. This report was written without reading the principal's or the other researchers' notes and before exchanging constructions. No subagents were spawned.

## Main result and status

The strongest completed route here extends the fixed-support observable theorem to **arbitrary tensor products of one-qubit Hermitian contractions**, including global parity strings and arbitrary partial computational-basis outcome projectors, at every physical time. Work stays randomized polynomial for every fixed positive replacement-noise-to-interaction ratio. This does not yield relative probabilities or full-distribution sampling.

The additional operation is a Pauli-weight smoothing estimate: reserve half the depolarization, increase the exponential weight parameter with physical time, then dualize with the Hamiltonian sign reversed. A support-sensitive hypercontractive estimate converts it to high-weight operator-norm suppression. Remaining low-weight inputs have logarithmic support; revisiting the original estimates shows their evaluation still costs polynomial work.

Status: the smoothing lemma and its suppression consequence are proved below. The algorithm is proved **using the original constructive short-buffer lemma and sparse propagation as inspected mathematical capital**, with their required quantitative extensions explained. It is ready for hostile mathematical checking. Historical priority is unestablished. No general implementation, practical speedup or sampling theorem is claimed.

## 1. Pinned capital and dependency check

Governing report: ../sources/original/Case_B_second_final/RESEARCH_REPORT.txt, SHA256 32b605ec5ccdc6897af1a24b1be951e0e3ad787a0b4fbff679541d1980ca841b, matching the supplied pin. Repository revision: 6f26484e44ff347429415f1765892fe34e8c6cc3, research/returns/2026-11-07-p1-final-own-depth-case-b. SOURCE_SCOPE.json and ENDPOINT.json were also read.

I inspected all 720 lines. The load-bearing operations are entropy contraction, Section 3 spatial operator-norm localization, Section 4 Pauli-p sparse rational propagation, Section 5 constructive Schmidt-nuclear-norm truncation, and Sections 6–8 parity-strip/overlap buffers. In particular:

- The sparse engine uses the initial coefficient p-norm or one-norm, not constant support intrinsically.
- The buffer's quantitative premise is physical time t=O(log Lambda), with Lambda=O(log(m/xi)). It does not require m to be polylogarithmic. The same proof can therefore evaluate a global product observable on m up to n sites at times O(log log(n/xi)).
- The weighted-2 and Pauli-p active-sector estimates match Angrisani–Puig–Teng–Holmes, arXiv:2609.40174v2, Corollaries S12 and S16, Proposition S17 and Theorem S20. A replacement rate must first be allocated across incident Hamiltonian terms. Their average-input operational claims are not used as pointwise guarantees.
- The original nuclear-norm estimate, truncation identity and bounded symmetrized overlap estimator were checked directly. No existence-only low-entanglement assertion replaces its constructive compression.

## 2. Precise theorem

Fix range a, Pauli term size k, term incidence d, and positive gamma/J. Let H=sum_a h_a P_a be an explicitly listed rational Pauli Hamiltonian on a finite square-lattice region, with each term supported on at most k sites, diameter at most a, |h_a|<=J, and at most d terms incident at any site. Take J>0 and d>=1; H=0 is directly computable. The periodic-square strip convention of the original can also be used.

Use replacement rate gamma>0 in

    L(rho)=-i[H,rho]+gamma sum_i(E_i(rho)-rho),
    E_i(rho)=I_i/2 tensor Tr_i rho,
    G=i[H,.]+gamma sum_i(E_i-Id).

Inputs are a supplied rational one-qubit product state rho_0, rational T>=0, and an explicitly supplied product

    O=tensor_i O_i,  O_i=O_i^dagger,  ||O_i||_infty<=1,

with rational 2-by-2 O_i. There is no support-size bound. For 0<epsilon<=1/2 and 0<delta<1, a randomized classical algorithm returns rational fhat with

    Pr[|fhat-Tr(rho_0 exp(TG)O)|<=epsilon]>=1-delta.

Bit work is polynomial in full input bits B, explicit n, numeric 1+T, 1/epsilon and log(1/delta). Degree and prefactor depend only on a,k,d,J/gamma. Rational gamma, or the original certified-evaluation rate contract with its actual precision cost, is required. The degree is not uniform as gamma/J tends to zero. Product initial state and full positive replacement noise remain essential to the stated evaluator.

A supplied polynomial-length linear combination of product observables is a routine corollary with cost polynomial in its coefficient one-norm and inverse target accuracy.

## 3. New Pauli-weight smoothing lemma

Use normalized Hilbert–Schmidt norm. On Pauli coefficients define W P=|P|P and S_alpha=exp(alpha W). Set rational constants

    theta=min(1/(2k), gamma/(16 k d J)),
    alpha(t)=min(gamma t/2,theta),  t0=2theta/gamma.

For all X and t>=0,

    ||S_alpha(t) exp(tG)X||_2 <= ||X||_2,                 (3.1)
    ||exp(tG) S_alpha(t)X||_2 <= ||X||_2.                 (3.2)

Consequently a homogeneous weight-r X with ||X||_2<=1 satisfies

    ||exp(tG)X||_2 <= exp(-alpha(t) r).                  (3.3)

Geometry is not used in this lemma.

### Proof

Let G_half=i[H,.]-(gamma/2)W. Allocate replacement rate gamma/(2d) on each site of each Hamiltonian term. The allocated rate at any site is at most gamma/2; unused noise remains nonnegative.

Each Pauli Hamiltonian term couples anticommuting Pauli partners by a real skew-symmetric 2-by-2 rotation with off-diagonal magnitude 2|h_a|. Their weights differ by at most k. After conjugation by S_alpha, the symmetric-part norm on each pair is at most 2|h_a|sinh(k alpha). Each active partner has nonidentity on at least one site of the term, giving allocated damping at least gamma/(2d). For 0<=alpha<=theta,

    2J sinh(k alpha) <= 4Jk alpha <= gamma/(4d).

Here k alpha<=1/2. Thus S_alpha G_half S_alpha^{-1} has nonpositive Hermitian part after summing the damped blocks and residual noise. This is the F1 Corollary S12 estimate with the correct replacement-rate allocation, and the above two-by-two argument verifies it directly.

For b(t)=S_alpha(t)exp(tG)X, away from t0,

    b'(t)=[S_alpha G_half S_alpha^{-1}
           +(alpha'(t)-gamma/2)W] b(t).

Both Hermitian parts are nonpositive because alpha'(t)<=gamma/2. Hence ||b(t)||_2 is nonincreasing. Continuity at t0 proves (3.1).

The Hilbert–Schmidt adjoint of G_H is G_{-H}. Apply (3.1) with -H and take adjoints to prove (3.2). For a weight-r X, S_alpha X=exp(alpha r)X; inserting exp(-alpha r)X into (3.2) gives (3.3).

This duality is essential: fixed weighted-norm contractivity by itself does not imply (3.3). The proof also works for bounded piecewise rational time-dependent Hamiltonians, using the sign-reversed reversed schedule on dualizing. That transfer is not needed for the static theorem.

## 4. Support-sensitive hypercontractivity and suppression

In an m-site restricted system let P be a traceless Hermitian unitary at each of r sites and identity elsewhere. It has homogeneous Pauli weight r and HS norm one, including when its local axes are arbitrary Bloch directions.

King's Corollary 2 gives depolarizing p-to-q hypercontractivity. Interleaving with Hamiltonian Schatten-norm isometries through the Lie-product limit yields

    ||exp(sG)Y||_{q,tau}<=||Y||_{2,tau}
    if q>=2 and q-1<=exp(2gamma s).

Choose

    b=max(1,ceil(log_2(8m/(theta r)))),  s=b/(2gamma),
    q=1+exp(b).

Then q>=8m/(theta r), and

    ||exp(sG)Y||_infty <=2^{m/q}||Y||_2
                           <=exp(theta r/4)||Y||_2.     (4.1)

If T>=t0+s, apply (3.3) to exp((T-s)G)P and (4.1) afterward:

    ||exp(TG)P||_infty <=exp(-3theta r/4).              (4.2)

Using the original m-to-constant conversion instead would cost O(log m) time and miss this operation.

For the full system localize to the union A of radius-R balls around supp P with operator-norm error eta. Retaining explicit support-size prefactors in the original bounded-range estimate allows

    R<=C[1+(J+gamma)T+log((r+1)/eta)],
    m=|A|<=min(n,C r R^2),                              (4.3)

where C depends only on a,k,d. The original polynomial r prefactors change only C and log(r+1). For the actual restricted H, (4.2) gives

    ||exp(TG_full)P||_infty<=eta+exp(-3theta r/4)         (4.4)

whenever T>=t0+s for the computed m. This bound is independent of initial state; the evaluator of nonsuppressed cases still requires product input.

## 5. Algorithm for homogeneous product P and complete asymptotics

Request subroutine error xi and confidence beta. Let Q=2+B+n+ceil(1/xi)+ceil(1+T)+ceil(log(2/beta)), and L=ceil(log_2 Q). All asymptotic constants below depend only on a,k,d,J/gamma.

1. If r=0 return one. If gamma T exceeds the original O(log(n/xi)) entropy cutoff, return zero because P is traceless. Thus in every remaining branch (J+gamma)T=O(L).
2. Localize with eta=xi/100. Then R=O(L) and m/r<=C L^2. Compute s as in Section 4 by integer comparisons. Therefore s<=C(1+log L)/gamma.
3. If T>=t0+s and r>=r_star=ceil((4/theta)log(100/xi)), return zero using (4.4). A dyadic upper bound for the logarithm suffices to choose parameters rationally.
4. If T<t0+s, evaluate the short buffer directly on A. Now T=O(log L), though m may be n. In original Sections 6–8 choose Lambda at least L with Lambda=O(L); then JT=O(log Lambda), factorial strip width is O(Lambda/log Lambda), and accumulated crossing-angle exponent is O(Lambda). Row dimension and Schmidt cutoff are exp(O(Lambda))=Q^{O(1)}. Gate count, m and sample count are polynomial. This pays the direct-buffer branch with no n-site dense matrix.
5. Otherwise r<r_star=O(log(1/xi)), so m=O(L^3). Run the original sparse-HS-plus-buffer construction with support and initial coefficient norms kept explicit. At most 3^r Pauli terms represent P, and its Pauli-1 norm is at most (sqrt(3))^r. Both are polynomial in 1/xi for fixed theta. Original Section 4 then has polynomial coefficient cutoff, retained count K, coefficient one-norm S and inverse buffer accuracy. Its final hypercontractive buffer has duration O(log m)=O(log L), so the same strip cost closes.

Step 5 does not substitute r into the original enormous displayed envelope D_kappa, which unnecessarily declares support a class parameter. The constructive estimates depend on support through polynomial prefactors, O(r) in log M0, and the polylogarithmic localized volume; no exponential in a power of r is needed.

For Step 4, the buffer's product P need not be a standard Pauli. Toggling-frame noise kicks map it to another product of local Hermitian unitaries. The parity products commute; their overlap identity and localized norm-one telescoping remain true. Their on-site insertions cause no cross-cut nuclear-norm growth. The original MPS/importance estimator is unchanged. More generally, the direct buffer also admits Hermitian contraction products, since each such insertion contracts vector and nuclear norms.

Spatially disconnected supports do not require an enclosing rectangle. Empty strips and rows can be skipped in their actual coordinates; there are at most m nonempty ones, each strip row has O(width) occupied sites. Thus the method handles r growing to n without a hidden enumeration of the empty lattice between components.

Shrink each error allowance by a fixed factor to make total error at most xi. All branches have fixed finite work bounds and finite digital sampling; confidence costs log(1/beta).

## 6. Product contractions without exponential coefficient cost

Every one-qubit Hermitian contraction has the form

    O_i=a_i I+beta_i A_i, beta_i>=0,
    A_i=n_i dot sigma, |n_i|=1, |a_i|+beta_i<=1.

Independently choose identity with probability |a_i|, A_i with probability beta_i, and a zero contribution otherwise. Track signs of chosen a_i. The resulting random homogeneous product P and sign sigma satisfy

    O=E[sigma P], |sigma|<=1.                           (6.1)

This is a bounded mixture, not an exponentially costly Pauli expansion. Each nonzero P is handled by Section 5.

Numerical access remains rational. Approximate beta_i downward by nonnegative dyadic beta_i' with error nu. Tiny beta_i can be replaced by zero. Approximate n_i by an exactly rational unit Bloch vector using rational stereographic coordinates in a chart whose denominator is at least one. Certified square roots and O(log(1/nu)) bits suffice. Then O_i'=a_i I+beta_i' A_i' has norm at most one and differs from O_i by C nu. Take nu<=epsilon/(100Cn), so product telescoping pays at most epsilon/100. Probabilities and the local Hermitian unitary A_i' are now rational. Exact unit-vector parametrization avoids weakening the homogeneous-weight lemma through an unproved numerical normalization.

Draw M=O(epsilon^{-2}log(1/delta)) independent outer samples from (6.1). Estimate every nonzero product mean with error epsilon/10 and internal failure probability delta/(2M), clipping outputs to [-1,1]. Conditional union bounds control all inner failures by delta/2. Hoeffding for the exact signed means controls the outer error by epsilon/3 with probability 1-delta/2. Product approximation, finite-random-bit total variation and rounding fit in the remaining budget. This proves the theorem and charges all extra outer sampling.

## 7. Verified sources, applicability and priority constraints

Primary statements below were opened and read. Local HTML/text caches are in ../sources/literature/machinery/; SOURCE_MANIFEST.json records pins. Source-derived summaries here are deliberately scoped; derivations in Sections 3–6 are supplied independently.

- **Angrisani–Puig–Teng–Holmes, arXiv:2609.40174v2, 5 November 2026.** Corollaries S12 and S16, Proposition S17, Theorem S20 supply weighted-2 and Pauli-p contractivity. Local damping is allocated over incident terms before applying it. Their average-input operational conclusions are not imported as worst-case conclusions. The varying-weight smoothing/duality is derived here, not falsely quoted as their theorem. https://arxiv.org/html/2609.40174v2
- **King, arXiv:1210.8412, Theorem 1 and Corollary 2, equations (13),(17).** For tensor qubit depolarization in normalized Schatten norms, p-to-q norm is one when exp(-gamma s)<=sqrt((p-1)/(q-1)). The p=2 and finite q convention here matches exactly. Hamiltonian interleaving follows from norm isometries, not from an asserted Hamiltonian theorem in King. https://arxiv.org/html/1210.8412
- **Bravyi–Gosset–Movassagh, arXiv:1909.11485v1, Theorem 5, Section 6.** Arbitrary one-qubit Hermitian contraction products on 2D nearest-neighbour depth-d circuits admit an additive estimator in n xi^{-2}2^{O(d^2)} time. This is the key global-product/overlap predecessor. Fine-step depth diverges, so that depth bound is not a continuous-time theorem. The original accumulated-angle construction pays this transfer. https://arxiv.org/html/1909.11485
- **Haah–Hastings–Kothari–Low, arXiv:1801.03922v4, Appendix C.4, (48),(49).** These give bounded-range factorial commutator and localization tails. Distances are measured in interaction-range units; local interaction sums are bounded. Piecewise bounded toggling-frame Hamiltonians satisfy the same time-ordered linked-integral proof. The original histories meet these hypotheses. https://arxiv.org/html/1801.03922v4
- **Nelson–Rajakumar–Yin–Zhang–Gullans, arXiv:2610.00548v2, Theorem 2.3, Proposition 2.2, Lemma 5.3.** This is the strongest sampler comparator: nearest-neighbour unital circuit layers in fixed D with fixed per-layer depolarization p permit polynomial log-marginal computation and sampling above depth O(D p^{-1}log(D/p)+3^D p^{-1}). Exact finite-depth lightcones provide polymer factorization and intermediate minimum-weight control. For step h, p~gamma h and depth~T/h; direct refinement requires gamma T>=c log(1/h), failing at fixed T. This constrains novelty but does not supply a continuous sampler. https://arxiv.org/html/2610.00548v2
- **Schuster–Yin–Gao–Yao, arXiv:2407.12768v2, Theorem 1 and Appendix B.** The polynomial uniform-noise expectation guarantee is RMS over a low-average input ensemble. It does not imply the specified-product-input theorem. Its sampling consequences carry extra anticoncentration assumptions. https://arxiv.org/html/2407.12768v2
- **Trivedi–Cirac, arXiv:2110.10638v2, Theorem 1, formal repeated statement in Section II.** Full sampling is proved for bounded-range local Lindbladians only above a dimension/range-dependent noise-to-strength threshold. That is a stronger output task in a narrower high-noise regime. Low-noise constructions involving damping/dephasing/fresh auxiliaries do not refute replacement-only all-site depolarization. https://arxiv.org/html/2110.10638v2
- **Denzler–Carrasco–Eisert–Guaita, arXiv:2601.05131v1**, with Zenodo dataset **10.5281/zenodo.19206525**, published 24 March 2026. This was the nearest relevant recent Zenodo work found in targeted searches. The primary paper develops frame/quasiprobability simulation with one-norm costs, and the dataset supplies frame-comparison code. The read statements do not provide the continuous-time specified-input all-rate theorem. Search absence is not a proof of priority. https://arxiv.org/html/2601.05131v1 ; https://zenodo.org/records/19206525

Targeted searches covered continuous-time polymer/depolarization, global/tensor-product observable prediction, local unital generators, frame simulation and recent Zenodo deposits. This is a bounded literature audit, not an exhaustive historical exclusion. The global-product theorem must be credited as combining established sparse propagation, weighted-norm contraction, hypercontractivity and the BGM overlap architecture with the original physical-time buffer. The additional closure here is Sections 3–6.

## 8. Obstruction tests and scope boundaries

- H=0 gives exact weight-r decay exp(-gamma r T), consistent with the conservative bounds. At T=0 a global parity may have expectation one; no high-weight-zero branch is used without T>=t0+s.
- Near-identity extensive products such as O_i=(1-c/n)I+(c/n)Z have a bounded mixture with typically O(1) nonidentity factors. Their order-one signals are retained.
- Additive estimates of prefix probabilities lose all information on exponentially small prefixes. Sequential conditioning is therefore not a full sampler. A continuous-time relative/log-marginal cluster expansion with soft causal tails is the decisive missing sampling operation. Finer Trotterization or naming the polymer method does not provide it.
- Weight smoothing is dimension-independent, but the short global buffer still needs 2D strips. No all-dimensional polynomial algorithm is obtained.
- No reset/cooling/nonunital generator/noiseless register/adaptive controller is present. Shtanko–Sharma, arXiv:2411.04819, PRX Quantum 6, 030347, Theorem 1, shows why the nonunital distinction is substantive; its noise-assisted fault-tolerance theorem is not an obstruction for the present replacement-only model. https://arxiv.org/abs/2411.04819
- Suppression (4.4) is input independent; evaluation of remaining terms still uses supplied product-state structure. No arbitrary correlated-input theorem is obtained.
- Arbitrary bounded-observable matrices of dimension 2^n are not an efficient input representation. Only the stated product or explicitly paid linear-combination interface is covered.
- No practical runtime, hardware advantage or physical validation is established. The inherited polynomial degrees remain enormous.

## 9. Executed diagnostic and resource accounting

../machinery/weight_smoothing_check.py is a NumPy-only executable, with a JSON output. A three-qubit five-term noncommuting Pauli Hamiltonian and gamma=0.7 checks five times for both S_alpha exp(tG) and exp(tG)S_alpha, and checks the tilted half-noise generator's Hermitian part at three alpha values and both H signs. The displayed maximum smoothing norm is 1 (the identity sector), and maximum tilted eigenvalue is 0. This finite sign/algebra diagnostic does not prove the general theorem. An initial inline SciPy version failed because SciPy is absent; the retained executable needs only NumPy.

The cost includes explicit input scan, observable-factor approximation, local restriction, exact sparse rational propagation, digital histories, strip/MPS construction, certified compression, rational overlap contractions, inner bounded sampling and outer product-mixture sampling. No physical state-preparation oracle, physical ancilla, exact-real oracle, eigenvalue-gap oracle or uncharged rejection loop is introduced.

## 10. Next decisive challenge

The hostile auditor should attack the varying-weight differentiation and Hamiltonian-sign duality, the support-sensitive 2-to-q-to-infinity conversion, and the polynomial bounds for logarithmic-support inputs and m up to n short buffers. If these survive, the strongest defensible endpoint from this route is **all-time global product-readout prediction at every fixed positive noise ratio**. Full-distribution sampling remains open here.
