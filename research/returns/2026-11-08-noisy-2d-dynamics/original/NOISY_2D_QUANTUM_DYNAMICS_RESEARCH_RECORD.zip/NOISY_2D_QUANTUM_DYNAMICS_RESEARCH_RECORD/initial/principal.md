# Principal independent initial construction — 8 November 2026

Written before reading any of the three researchers' independent reports or receiving their constructions. Governing original: RESEARCH_REPORT.txt SHA25632b605ec5ccdc6897af1a24b1be951e0e3ad787a0b4fbff679541d1980ca841b; full report independently read. This initial is immutable; later corrections belong in principal/.

## Target and statuses

Target: acquire an unknown bounded-local 2D Hamiltonian from noisy local experiments once, then answer previously unperformed, externally specified bounded coherent-drive/product-preparation/local-readout interventions at all future times, with polynomial bit work and a model-uncertainty bound independent of volume and horizon. The computational mechanism is inherited plus a nonautonomous extension, not claimed a wholly new learning or stability principle. Local learning and rapidly mixing dissipative stability already have strong predecessors.

Candidate theorem chain:
1. PROOF GIVEN HERE at abstract-locality level: depolarization plus arbitrary bounded time-dependent local Hamiltonian implies volume-uniform decay of each local Heisenberg observable to its normalized trace.
2. PROOF OUTLINE: this yields time/volume-uniform local perturbation stability, even against nonunital local Lindblad perturbations, with a fixed nonzero uncertainty floor proportional to residual local generator error.
3. PROPOSED pending full inherited-proof checking: original polynomial predictor extends to rational piecewise-constant bounded coherent drives (control input length paid), spatially varying replacement rates bounded below, and constant-depth supplied locally prepared initial entanglement.
4. CONSTRUCTIVE candidate: local signed-product finite-difference acquisition plus 2–3 gives a reusable learned prediction service. This is a scientifically meaningful end-to-end composition, without a practical-cost superiority claim.

## 1. Volume-independent local mixing

Let a,k,d,w fixed, local Hamiltonian coefficients bounded J, independent replacement rate at least gamma>0 at every site. The Hamiltonian may depend measurably on time with the same bounds. Write Phi_{s,t} for the Heisenberg propagator and tau for normalized trace. Retain an operator-locality bound on a radius-R neighborhood of supp(O):
||Phi_{s,t}(O)-Phi^R_{s,t}(O)|| <= C0 exp(V(t-s)-R/(2a)),
with C0,V computable from local parameters, independently of n and of the number of time switches. Restricted time-dependent Hamiltonians preserve tau.

For u=t-s choose R=ceil(2a((V+gamma)u+c0)), c0 large enough to absorb C0. At most Cw(1+R)^2 sites remain. For EVERY initial state on that region, including entangled states, tensorized depolarizing relative-entropy contraction interleaved with Hamiltonian entropy isometries gives
D(rho_u||I/2^m)<=m log2 exp(-gamma u).
Consequently
||Phi^R_{s,t}(O)-tau(O)I|| <= sqrt(2m log2) exp(-gamma u/2).
This is an operator-norm bound because the expectation estimate is uniform over all density matrices. Thus
||Phi_{s,t}(O)-tau(O)I|| <= F(u):=min(2,C_g(1+gamma u)exp(-gamma u/2))
after increasing explicit C_g, uniformly in n,s,t. This gives a useful horizon u_epsilon=O_g(gamma^-1 log(2/epsilon)), independent of n. At later times every local outcome mean is within epsilon of tau(O), regardless of source. This is a local statement, not global trace mixing, output sampling, or recovery of encoded information.

## 2. Uniform local generator-error bound

Let actual Heisenberg generator G'_t=G_t+sum_Z E_{Z,t}, each term supported in fixed diameter, E_Z(I)=0, ||E_Z||_{infty->infty}<=eta, bounded term density. Only total G'_t must be Lindblad; no unitality of G'_t is assumed. Duhamel and complete positivity/unitality of the perturbed Heisenberg propagator give
||Phi'_{s,t}(O)-Phi_{s,t}(O)|| <= int_0^(t-s) sum_Z ||E_Z Phi_{t-u,t}(O)|| du.
For near terms within R(u) use E_Z(I)=0 and local mixing F(u). There are O_g((1+gamma u)^2) such terms, giving eta C_g(1+gamma u)^3 exp(-gamma u/2). For far terms use locality relative to neighborhoods disjoint from Z; their shell sum is eta C_g(1+gamma u)exp(-gamma u). The integrable sum gives
sup_{n,s,t} ||Phi'_{s,t}(O)-Phi_{s,t}(O)|| <= K_g eta/gamma.
K_g is computable from the stated locality constants and fixed support/density. This matches the known rapid-mixing stability mechanism (Cubitt–Lucia–Michalakis–Perez-Garcia1303.4744; Lucia et al1409.7809); the planned contribution is explicit driven-class applicability and composition with the new predictor. It does not simulate an arbitrary fixed nonunital perturbation to precision below K_g eta/gamma.

## 3. Driven predictor check needed

Sparse Pauli-p contraction is blockwise and survives arbitrary prescribed piecewise constant Hamiltonian coefficients. Noise allocation uses the uniform maximum degree and minimum gamma. Hypercontractivity survives nonautonomous Hamiltonian interleaving. Correct orientation: compress the later interval's backward observable in HS; apply the actual EARLY-interval propagator to the compression error for smoothing. That early buffer is evaluated on the supplied product input. It is not valid simply to commute the buffer through changing Hamiltonians.

Factorial locality and the physical-time Schmidt-angle bound are uniform for bounded time-dependent local Pauli coefficients; all additional interval endpoints and bit costs are paid. A tiny switch interval does not incur a 1/min_interval cost, since choose per-interval step counts max(1,ceil(C S0^2 dt_i T/eta)) and sum <= number_intervals+C S0^2 T^2/eta. The original report's unitary-history toggling already produces time-dependent sign Hamiltonians. Use the volume-independent cutoff above, then simulate only a neighborhood of radius O_g(log(1/epsilon)). Sparse propagation and continuous-time buffer mechanism should give query cost polynomial(1/epsilon,local/control input bits,log1/delta), with enormous fixed-g degree. Preindexing is paid O(n) preprocessing/memory. No extra bath, reset, measurement feedback or noiseless register is supplied.

Constant-depth local input circuits can be prepended to the strip-vector construction, increasing their physical boundary-entanglement budget by O(b*depth). This deserves explicit check, not automatic promotion. General input circuits are BQP-hard already at T=0 and cannot be added freely.

## 4. Explicit noisy acquisition (simple, suboptimal)

Unknown H=sum_P h_P P in a supplied finite-range dictionary of O(n) terms, known J,d,k, known or independently estimated gamma>=gamma0. For each nonidentity P choose a one-site Pauli Q anticommuting with P; R=i P Q (a signed Hermitian Pauli). Then tau(R GQ)=2h_P, while tau(RQ)=0. Prepare product eigenstates on supp(R) with independently uniform signs sigma, others maximally mixed; weight the Q outcome by product sigma. Expected weighted mean at time t is tau(R exp(tG)Q). Thus divide by 2t to estimate h_P. No entangled input is required. To estimate gamma choose R=Q; tau(QGQ)=-gamma; use [1-weighted_mean(t)]/t.

Let Lambda=2dJ+2gamma and C2=k Lambda^2; locality gives ||G^2 Q||<=C2. Exact short-time remainder is <=C2 t^2/2 by contractivity. Choose t=O(alpha/C2). Bounded samples and Hoeffding give M=O(C2^2 alpha^-4 log(n/delta)) shots per coefficient for accuracy alpha. O(n) coefficients, O(n) paid product preparation/readouts per shot if performed globally; all costs polynomial. Randomized parallel settings could improve cost, but not needed for validity.

Noisy access: calibrated independent local preparations rho_(i,sigma)=(I+sigma p_i R_i)/2, p_i>=p0>0, and calibrated binary readout E[Y|idealQ]=b+c Q with c>=c0>0. Signed averaging produces (product p_i) R; subtract b/divide c and product p_i. The sample range is bounded by A=2/(c0 p0^k), so multiply M by A^2. Baseline for the gamma estimator is handled with its known p. Calibration uncertainty beta creates a bias O(A beta/t), not removable by repetition; require beta=O(alpha t/A) or report its floor. Timing uncertainty Delta t similarly requires O(alpha t/Lambda). Precision bits and number of calibration experiments must be paid, not assumed free. With arbitrary unknown SPAM the model is not identifiable; no claim there.

On the event all coefficients learned, the local generator error is <=C_d alpha plus declared model-misspecification error. Stability gives all-time/volume prediction uncertainty K_g(C_d alpha+b_miss)/gamma, plus Monte Carlo evaluation epsilon and controlled preparation/readout mismatch. The event is simultaneous over all future bounded drives, not a union bound over an uncountable control set: coefficient validity and uniform stability establish it. Each adaptive subsequent numerical query has its own fresh Monte Carlo failure allowance, or use delta_j summable for an entire countable service.

## Existing sources found (exact imports still to inspect)

1303.4744 and1409.7809 dissipative stability are obvious predecessors;2108.04842 high-temperature/short-time Hamiltonian learning;2606.23652 Robust Structure Learning of k-local Lindbladians (product prep/Pauli readout, stronger sample rates and misspecification). No novelty claimed for coefficient learning, generic stability, or their routine composition. The original uniform worst-input 2D predictor remains the enabling nonstandard premise. Need compare to full learning-to-simulation literature and noise/cooling hardness. Need source-level checking of inherited factorial tail, hypercontractive convention, and constructive MPS precision. No assertion of a practical speedup or general finite-temperature material law.
