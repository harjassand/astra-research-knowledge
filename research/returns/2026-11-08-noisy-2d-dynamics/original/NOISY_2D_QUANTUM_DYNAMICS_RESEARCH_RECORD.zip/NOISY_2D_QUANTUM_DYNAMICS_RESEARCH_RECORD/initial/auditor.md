# Independent initial hostile audit

2026-11-08 (Australia/Brisbane). Written before result exchange. No other
researcher's report or proposed construction was read; no additional agent was
used. Governing report: `sources/original/Case_B_second_final/RESEARCH_REPORT.txt`,
SHA256 `32b605ec5ccdc6897af1a24b1be951e0e3ad787a0b4fbff679541d1980ca841b`.
The exact original scope and numerical representation contract are retained.

## Initial verdict and strongest findings

I found no fatal error in the load-bearing argument for specified rational
product-input, fixed-local additive prediction under static bounded local 2D
Pauli Hamiltonians and every fixed positive all-site replacement-noise ratio.
The huge polynomial degree, practical nonimplementation, and separation from
full sampling are real limitations, not mathematical failures.

The strongest genuine obstruction found is that accepting arbitrary efficient
quantum circuit descriptions of correlated inputs makes even H=0 and constant
positive-time local prediction BQP-hard. A second explicit obstruction proves
that a generic HS-to-worst-case conversion needs a logarithmic-in-region-size
buffer. Neither establishes hardness of the original task or its full-sampling
extension. Constructive repairs below admit efficiently generated classical
correlations, double-logarithmic-depth prepared quantum inputs, explicit
time-dependent Hamiltonian schedules, and paid fixed-local conditioning. A
local replacement-noise probability floor makes the latter uniformly efficient
after a constant physical time for fixed-local projective outcomes.

## 1. Load-bearing proof inspection

**Hypercontractivity: checked.** King's Corollary 2, equation (17), in
[arXiv:1210.8412v1](https://arxiv.org/pdf/1210.8412v1) concerns normalized
Schatten norms and tensor-product qubit depolarization. A noise interval h maps
p to q with norm one when `q-1 <= exp(2 gamma h)(p-1)`. In a Lie product use
`p_j=1+exp(2 gamma j s/r)`, starting at two; arbitrary Hamiltonian conjugations
are isometries at each exponent. The product limit gives

    ||Phi_s^* X||_{q,tau} <= ||X||_{2,tau},
    q=1+exp(2 gamma s).

Since `||A||inf<=2^(m/q)||A||q,tau`, the report's choice of s gives its bound
by two. No randomness of H or of the supplied input is used.

**Sparse Pauli-p: checked independently of operational average-case claims.**
[Angrisani--Puig--Teng--Holmes, v2](https://arxiv.org/html/2609.40174v2), Lemma
S15 (S112)--(S114), Corollary S16, and coefficient-pruning Lemma S6 concern the
Pauli coefficient norm. A local Cayley conjugation has l1 growth at most
`exp(2Jh)` and is an l2 isometry. Interpolation gives
`exp(2Jh(2/p-1))`; the allocated Euler noise damps every local nonidentity
sector by at least `exp(-gamma h/d)`. Thus the report's p works. The identity
and traceless local sectors are invariant disjoint coefficient sets.
`deg(i)<=d` makes residual noise nonnegative. Per-block merging/truncation
avoids an exponential simultaneous-color expansion. Common rational
denominators add their bit lengths over the paid block count. The buffer,
rather than an ensemble guarantee, pays the specified-input functional.

**Parity overlap: checked.** The exact `Q_j=U^dagger P_j U` commute and square
to identity, so the overlap of their two parity products equals the target
Pauli mean. Localized `V_j` remain Hermitian unitaries and have disjoint
supports within each parity. Opposite-parity localized operators need not
commute; telescoping the two vectors controls the overlap without asserting
that they do. The architectural predecessor is
[BGM, Theorem 5](https://arxiv.org/pdf/1909.11485v1), whose theorem itself is
for nearest-neighbor depth-d 2D circuits with runtime `n delta^-2 2^O(d^2)`.
The report supplies the extra physical-time/MPS operation rather than applying
that finite-depth cost unchanged to vanishing-step Trotter circuits.

**Factorial locality: applicable after a small derivation.**
[HHKL v4](https://arxiv.org/pdf/1801.03922v4), Lemma 5 and Appendix C.4
(48),(49), use strictly local interactions and
`zeta_0=max_x sum_{Z containing x}|Z| ||h_Z||`. Rescale distance by the fixed
range; `zeta_0<=kdJ`. In the toggling/colored circuit the physical duration is
at most `chi t`, and the same linked time-ordered integrals have volume
`t^q/q!`. Signs and arbitrarily many pulses preserve the uniform bound. A
larger fixed-range constant is harmless. For `t=O(log Lambda)`, a buffer
radius `O(Lambda/log Lambda)` gives exponentially small error and boundary
angle `O(Lambda)`. Ordinary exponential locality alone does not close this
particular cost bound.

**Constructive MPS truncation: checked.** A crossing Pauli rotation expands
into two product unitaries, multiplying reference Schmidt nuclear norm by at
most `exp(|theta|)`. Summed crossing angle is `O(bJt)`, not the number of gates.
For `phi'=phi-r`, discarded and retained pieces are orthogonal and
`||r||op<=||phi||F/sqrt(D+1)`. Nuclear/operator duality therefore proves

    ||phi'-psi||^2 <= ||phi-psi||^2+2B*/sqrt(D+1).

Here B* bounds the exact reference, so existence of a favorable MPS is not
being confused with a constructive repeated-truncation procedure. Unitary
updates preserve error; compression decreases the approximate norm. Summing
the increment gives the claimed polynomial-rank procedure once B* is
polynomial. Normwise approximate QR/SVD is sufficient without a Schmidt gap;
small singular values can be discarded with paid norm error instead of
inverted. The report's finite-bit description is consistent with this. A
future implementation should explicitly certify each normwise compression and
normalization budget; the existing finite diagnostics are not that full
implementation.

**Bounded estimator and finite randomness: checked.** For the two rational
MPS vectors a,b, sample `p_x=(|a_x|^2+|b_x|^2)/z`, with
`z=||a||^2+||b||^2<=2`, and return
`Z_x=z conjugate(a_x)b_x/(|a_x|^2+|b_x|^2)`. Its mean is `<a,b>` and
`|Z_x|<=z/2<=1`. Each MPS is sampled/contracted separately; differing orders
do not require a combined 2D contraction. Exact rational amplitude arithmetic
and paid finite categorical-bit precision avoid hidden relative-amplitude
or almost-sure-termination assumptions. Digital histories are not physical
access to a noise record.

**Minor clarification:** the equilibrium branch must use
`2^(-|supp O|) Tr(O on that support)`, or explicitly pad O to exactly w sites.
Using a class upper bound w with an unpadded smaller supplied support would
misnormalize the answer. This is a routine clarification.

## 2. Proved norm obstruction: constant buffers are insufficient generically

Take H=0, `r=exp(-gamma s)`, and

    A_m = tensor_i (I+rZ)/sqrt(1+r^2).

Then `||A_m||2,tau=1`, while

    ||D_s^(tensor m) A_m||inf=(1+r^2)^(m/2).

Consequently a generic bound by a fixed C requires

    gamma s >= -1/2 log(C^(2/m)-1)
             = 1/2 log m - 1/2 log(2 log C)+o(1).

The logarithmic-in-m buffer order is necessary for that norm conversion.
This does not rule out a different algorithm exploiting the actual evolved
observable's structure. The simpler projector `|0^m><0^m|`, with normalized
HS norm `2^(-m/2)` but product-input expectation one, also directly forbids
dimension-free conversion before smoothing.

## 3. Conditional hardness and repaired correlated-input theorems

**Conditional hardness.** Let an initial state be specified by any polynomial
quantum circuit C, `rho_C=C|0><0|C^dagger`. At H=0 and any fixed `t0>0`,

    Tr[Z_1 Phi_t0(rho_C)] = exp(-gamma t0) Tr[Z_1 rho_C].

The constant nonzero attenuation preserves the BQP gap. A polynomial
randomized classical predictor at sufficiently small constant error would
imply BQP=BPP. This can use algebraic gates or a rational approximately
universal gate set with its compilation/evaluation costs charged. It is a
barrier to arbitrary succinct quantum input, not to an explicitly supplied
full density matrix measured in that matrix's input size. Unknown input
without any representation/data is already information-theoretically
unspecified: |0> and |1> give different answers at H=0.

**Repair A, proved consequence:** accept
`rho_0=E_lambda tensor_i rho_i(lambda)` when an explicit polynomial-time
finite-bit classical algorithm samples lambda and rational local density
matrices. Charge this algorithm and precision. Sample
`O(epsilon^-2 log(2/delta))` instances, run the original predictor on each to
error epsilon/4 with summable inner failure probabilities, and average clipped
outputs. Linearity, Hoeffding and a union bound give the claimed prediction.
This permits long-range classical correlations with an acquired efficient
generative representation; not every succinct separable-state description.

**Repair B, proved mechanism extension:** accept
`rho_0=W(tensor_i rho_i)W^dagger`, where W is an explicit bounded-range
bounded-arity 2D unitary circuit of depth
`ell<=c log(2+log Q)` for a fixed c and complete original resource Q. Its
gate entries are rational or certified polynomially evaluable algebraic
numbers; their actual cost and gate count are charged.

First localize the noisy Heisenberg observable to an inner S with
`O(log^2 Q)` sites. Its input expectation needs only W's exact preparation
causal cone S+, enlarged by O(ell), still of this size. Noise and sparse
propagation act only on S; the shell represents the specified initial reduced
state, not an additional noiseless physical resource. The operator-norm
smoothing error is valid against that correlated reduced state.

For a buffer history the coherent mean becomes
`<psi|W^dagger U_S^dagger P U_S W|psi>`. First localize each conjugated P_j
onto C_j with margin b_U, then conjugate by W restricted to a larger B_j
with extra margin O(ell). This latter truncation is exact. The operators

    V_j=W_Bj^dagger U_Cj^dagger P_j U_Cj W_Bj

are Hermitian unitaries, disjoint within a parity if central widths are at
least `2b`, `b=b_U+O(ell)`. A crossing fixed-arity unitary has constant Pauli
expansion l1 norm. Preparation and inverse preparation therefore add
`O(b ell)` to log B*. Hence

    log B*=O(b(Jt+ell)),
    b=O(Lambda/log Lambda+ell), Jt+ell=O(log Lambda),

so `log B*=O(Lambda)` and the original polynomial cost closes. Classical
mixtures from Repair A may precede W as well. The same finite-arithmetic
implementation obligation as the original remains. This does not prove a
sharp larger-depth threshold or historical novelty.

## 4. Proved extension to explicit time-dependent Hamiltonian schedules

H(t) may be a finite supplied list of rational intervals and rational local
Pauli Hamiltonians, with uniform instantaneous a,k,d,J bounds. The complete
schedule length and bits count in B. The same fixed-ratio polynomial
predictor works for product inputs, also the repaired input classes above.

For a state propagator Phi_(b,a), the short buffer must be on the input side:

    Phi_(T,0)^* O = Phi_(s,0)^* (Phi_(T,s)^* O).

Sparsify the later adjoint, then apply the early buffer to its HS error.
Schatten isometries, entropy contraction, per-block Pauli-p contraction and
factorial locality are time-local facts. Dividing the product-formula error
among all listed segments increases the step count polynomially in their
number. Coloring and nuclear growth charge integrated physical angles, not
switch count. This is an explicit open-loop Hamiltonian schedule, not general
adaptive feedback or a reset interface.

The ordering matters: initial |0>, O=X, H=X for time one then H=Z for time one
give `exp(-2gamma) sin^2(2)`; reversing the two intervals gives zero.

## 5. Proved fixed-local conditioning repair and probability floor

Let a fixed-support Kraus operator K obey `||K||<=1`, and A be a fixed-support
Hermitian unit-norm observable. The union support is fixed. If

    p=Tr(K^dagger K rho_T)>=p0>0,
    a=Tr(K^dagger A K rho_T), |a|<=p,

then the selected conditional mean is a/p. Predict the two ordinary local
means to `eta=epsilon p0/8`, split failure probabilities, divide and clip.
On the good event the denominator is at least p0/2, and ratio error is at
most `4eta/p0`. The resource is polynomial in p0^-1. Generic additive data
cannot avoid this dependence: two joint laws may differ on mass p only but
give opposite conditional means there. This is not a dynamical hardness proof.

There is an automatic local probability floor for the given replacement
noise. For a set A of w sites and J>0 put

    Delta=min(T, 1/(2^(w+2)wdJ)),
    c_A=2^(-w-1)(1-exp(-gamma Delta))^w.

For every initial state, including one entangled with the complement, and
bounded time-dependent Hamiltonians in the class,

    rho_A(T) >= c_A I_A       (T>0).

For J=0 set Delta=T. To prove this, unravel replacement as independent
Poisson applications of E_i at rate gamma. In the last Delta interval, event
F that every site of A is replaced has probability
`(1-exp(-gamma Delta))^w`. Compare, conditional on the same history, with
evolution suppressing only Hamiltonian terms touching A during that interval.
The comparison finishes with `rho_A=I/2^w` on F. There are at most wd such
terms. Telescoping between replacement maps gives trace-distance change at
most `2wdJ Delta`, uniformly for every fixed history; CPTP replacements
contract Hermitian trace distance. Conditional averaging preserves the bound.
Thus the actual conditional reduced state on F is at least
`(2^-w-2wdJ Delta)I >=2^(-w-1)I`. The complementary event contributes a
positive state, proving the displayed inequality.

A rank-one projective local outcome therefore has probability at least c_A.
For `T>=1/(2^(w+2)wdJ)`, this is a constant depending only on the fixed physical
class and w, so the conditional estimator has uniform polynomial resources.
The unravelling in this proof does not supply a controller a replacement flag
or pure reset. The inequality is for an unconditional local marginal; it does
not survive arbitrary rare conditioning on the rest of the lattice by this
argument, and does not supply a full sampler.

## 6. Explicit non-unital and monitored-controller barriers

Add one-qubit pure reset at rate kappa to H=0 replacement. Its Bloch
coordinate obeys `z'=kappa-(gamma+kappa)z`, with stationary
`z=kappa/(gamma+kappa)>0`. This disproves a naive extension of the uniform
mixing endpoint to arbitrary reset/cooling generators. It is not by itself a
hardness result. In [Trivedi--Cirac v2](https://arxiv.org/html/2110.10638v2),
Theorem 2's Hamiltonian low-noise hardness uses the biased non-unital
entanglement-breaking channel in their equation (4); it does not cover
replacement by I/2. Their Theorem 3 has different dissipative and
multiplicative-simulation hypotheses. Theorem 1 is a genuine high-noise
continuous-time total-variation sampler and is the relevant sampling incumbent.

If a different model supplies the exact environmental X/Y/Z jump record and
instantaneous inverse Pauli pulses, a random-unitary dilation with jump rates
gamma/4 can be corrected trajectory by trajectory. Arbitrary coherent
Hamiltonian controls plus that ideal feedback recover noiseless computation.
Monitoring, record acquisition, latency and pulse strength are added resources;
they are not internally sampled digital histories. Finite bounded-speed
feedback is a different problem and not settled by this idealized example.

## 7. Geometry, global sampling, literature and status

The 2D proof pays `exp(O(bJt))` at row cuts. The analogous 3D slab has an
additional transverse direction, and the currently proved nuclear bound need
not be polynomial. That is a limitation of this construction, not a theorem
against 3D prediction.

[Coudron et al. 2610.02146v1](https://arxiv.org/html/2610.02146), Theorem 1.1,
removes connectivity restrictions for fixed-depth additive output-probability
estimation. Section 1.2 explicitly obtains only the magnitude of a general
product-operator mean by squaring, leaving its sign/phase unresolved. It is
not a signed growing-physical-time buffer theorem.

[Nelson et al. 2610.00548v2](https://arxiv.org/html/2610.00548v2), Theorem 1.1,
does provide a fixed-strength discrete noisy-circuit sampler beyond depth
`O(p^-1 log p^-1)`. Trotter step h here has `p=O(gamma h)`; substitution
requires physical time `Omega(gamma^-1 log(1/h))`, divergent as h shrinks.
A continuous-time polymer theorem would be a decisive missing operation,
not a consequence already supplied by that theorem. Full sampling for every
fixed positive gamma/J remains **open in this audit**. No counterexample was
found. Generic local marginals alone do not identify a global distribution
(even/odd parity laws illustrate this logical point without being claimed as
outputs of the frozen model).

Primary PDFs and SHA256s are in `sources/literature/auditor/CACHE_MANIFEST.json`.
Primary recent Zenodo API searches are retained in `ZENODO_DISCOVERY.json` and
record metadata for 23418780 and 23414157. The former is an October 2026
fixed-depth Trotter/noise-structuring numerical-support notebook; the latter is
an empirical channel-fingerprint artifact. Their metadata supply no uniform
continuous-time signed prediction/sampling theorem, and neither is imported.
This limited search is not a proof of priority or absence of other work.

Independent diagnostics: `auditor/audit_checks.py`, script SHA256
`fa493e34a6d79201a1bfdf1154634132a7a839722b3f89750b01c43cbdf032d6`;
results in `auditor/AUDIT_CHECKS.json`. Checked 200 truncation cases (maximum
identity residual 3.11e-15), 400 actual Cayley/Euler Pauli-p block cases,
60 interacting two-site hypercontractive cases, 240 local-floor examples,
and the time-order counterexample. These supplement the proofs and do not
verify the uniform algorithm or establish novelty.

| Claim | Initial status |
|---|---|
| Original scoped operation | Capital preserved; load-bearing route independently inspected; no fatal gap found |
| Constant-time generic HS-to-worst-case buffer | Disproved by explicit product witness |
| Arbitrary circuit-described correlated input | BQP-hard conditional on BQP != BPP |
| Efficient generative mixtures of product inputs | Proved consequence with actual sampling cost charged |
| Double-logarithmic-depth 2D prepared inputs | Proved mechanism extension; same finite implementation scope as original |
| Explicit time-dependent open-loop H schedules | Proved mechanism extension with input-side time ordering |
| Fixed-local outcome conditioning with p>=p0 | Proved, polynomial in p0^-1 |
| Local reduced-state probability floor | Proved elementary lemma; not global conditioning |
| Uniform-to-maximally-mixed extension with pure resets | Disproved explicitly |
| All-ratio continuous-time full sampling, arbitrary 3D prediction | Open in this audit; failed transfer is not hardness |

Strongest recommended constructive attack: a continuous-time, physical-angle
polymer representation that controls *all conditional output marginals* with
paid finite-bit local weights. It must handle actual sign/phase, long-range
conditioning and the vanishing-step limit. The norm witness proves that simply
shortening the existing generic buffer cannot achieve that operation.
