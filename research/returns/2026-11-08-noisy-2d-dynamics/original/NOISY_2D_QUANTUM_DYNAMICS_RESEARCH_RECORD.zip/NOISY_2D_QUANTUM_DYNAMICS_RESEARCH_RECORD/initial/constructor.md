# Independent constructor: whole-output sampling from bounded interaction cuts

Initial report, 8 November 2026. This report is written before seeing any other
researcher's construction or conclusions. No subagents were used. Its initial
bytes are to be frozen before result exchange; subsequent repairs belong in
separate files. This is research, not a manuscript or a release.

## 1. Strongest completed capability and honest scope

**Derived theorem:** on an explicitly certified family of interaction graphs
with bounded cuts in a supplied binary leaf tree, continuous local replacement
depolarization at every fixed positive rate permits a polynomial bit-time
classical **sampler for the entire final computational-basis distribution at
every time**. The initial state can be an arbitrary correlated state supplied
as a normalized locally purified tree tensor network (TTN) on that tree. The
Hamiltonian may be piecewise time dependent. The same algorithm permits
specified terminal product measurements.

This is stronger than local-mean prediction as an output task and more general
in its initial state and controls. It changes the interaction architecture:
bounded-degree trees, chains and fixed-width ladders qualify; generic square
lattices do not. It is therefore **not** a full-output sampler for the original
arbitrary 2D class. The mechanism is simpler than sparse-HS smoothing: follow
random-unitary noise histories as TTNs until global entropy mixing takes over.
The cost depends on accumulated crossing angle, not the discretization depth.

I also derive a strict enlargement of the original 2D observable contract:
Pauli strings supported on any fixed power of a logarithm, and trace-norm
tomography of any logarithmic-sized subsystem, remain polynomial. This secondary
result uses the actual original 2D construction and is useful for nonlocal string
order and small-subsystem entanglement questions. It is a uniformity extension
of that construction, not a new simulation mechanism.

**Scientific status:** the complete mathematical arguments and finite bit-cost
contracts appear below. The whole general sampler is not implemented. Numerical
diagnostics check finite ingredients only. Historical novelty is **unverified**;
TTN evolution, sampling and entropy mixing are established machinery. This
report does not claim a foundational breakthrough or practical speed.

## 2. Governing capital and proof audit

Governing file:

`sources/original/Case_B_second_final/RESEARCH_REPORT.txt`

SHA256:

`32b605ec5ccdc6897af1a24b1be951e0e3ad787a0b4fbff679541d1980ca841b`.

The repository snapshot stated in the commission is
`6f26484e44ff347429415f1765892fe34e8c6cc3`, path
`research/returns/2026-11-07-p1-final-own-depth-case-b`.
I read the complete 720-line report, `ENDPOINT.json` and `SOURCE_SCOPE.json`.

The original established result is retained at its exact scope: additive
specified-product-input, fixed-local mean prediction, arbitrary bounded local
static 2D Pauli Hamiltonian, independent replacement depolarization, fixed
positive gamma/J, polynomial bit work with a rate-dependent degree. It does not
give a sampler, correlated-input theorem or vanishing-noise polynomial.

Load-bearing original premises used here were independently checked:

1. **Nuclear growth, original Section 5, equation (5.1).** The coefficient matrix
   across a bipartition transforms under a crossing Pauli rotation as a sum of
   two left/right unitary transforms. Its nuclear norm grows by at most
   `|cos theta|+|sin theta| <= exp(|theta|)`. This applies to any bipartition,
   not only an MPS row cut, and to an entangled initial vector with its initial
   nuclear norm included. On-site Pauli noise histories preserve every cut norm.
2. **Constructive truncation, original (5.2).** For the discarded Schmidt part
   `r` of a vector `phi` of norm at most one,
   `||phi-r-psi||^2 = ||phi-psi||^2-||r||^2+2 Re<r,psi>`.
   Nuclear/operator duality bounds the last term by
   `2 N(psi)/sqrt(D+1)`. This argument is not tied to a line. Compatible tree
   cuts permit the same sequence of local TTN Schmidt compressions.
3. **Noise convention, original (6.1).** An Euler replacement channel is the
   rational random-unitary mixture with probabilities
   `(1-3 gamma h/4, gamma h/4, gamma h/4, gamma h/4)` for `I,X,Y,Z`.
   The replacement rate is gamma, not the each-Pauli jump rate gamma/4.
4. **Global entropy mixing, original (3.2).** I give a self-contained entropy
   proof below, valid also for arbitrary correlated inputs and time-dependent H.
5. **2D extension only:** I additionally checked the sparse Pauli-p update and
   factorial-strip cost dependencies in original Sections 3--9. I do not use its
   oversized fixed-w envelope with w growing. Section 8 below redoes the
   relevant dependence explicitly.

The bounded-cut sampling theorem requires neither the original sparse-HS
propagation nor hypercontractivity nor the parity-strip overlap estimator.

## 3. Formal sampling theorem

Fix the local support bound k, term-incidence bound d, local purification
dimension r0, cut bound c and positive ratio upper bound `g >= J/gamma`.
These are class parameters. A finite instance consists of:

* n physical qubits, rational gamma>0 and a rational final time T>=0;
* a binary tree with n labelled leaves and O(n) nodes, all internal degrees at
  most three; deleting any edge e partitions the leaves into `A_e,B_e`;
* a rational piecewise-constant Hamiltonian schedule
  `H(t)=sum_a h_a(t) P_a`, with explicitly listed rational breakpoints and
  coefficients, `|h_a(t)|<=J`, each Pauli term supported on at most k sites,
  and each site incident on at most d active terms;
* the **cut certificate** that, in every time segment and for every tree edge,
  at most c active Hamiltonian terms intersect both `A_e` and `B_e`;
* a rational TTN vector `|Psi_0>` on that tree, with one leaf coordinate
  `C^2 tensor C^{r0}` per physical site, norm one, and maximum virtual bond
  dimension D0. Its physical input is
  `rho_0=Tr_purifying |Psi_0><Psi_0|`.

The rational data are explicit. The norm-one input is a promise which can also
be checked by exact rational TTN contraction. Normalization of a nonzero
supplied vector can instead be done with certified arithmetic and charged
precision; no state-preparation oracle is used. The TTN may be entangled and
need not arise from short-time local preparation.

The physical evolution is exactly

`d rho/dt = -i[H(t),rho] + gamma sum_i (E_i(rho)-rho)`,

`E_i(rho)= I_i/2 tensor Tr_i rho`.

For any rational `0<epsilon<=1/2`, there is a bounded-work classical randomized
algorithm producing x in `{0,1}^n` whose distribution q satisfies

`TV(q, x -> <x|rho_T|x>) <= epsilon`.

Its bit work per sample is polynomial in the complete input length B, n,
D0, the number of schedule segments and epsilon^-1, for every fixed choice of
the class parameters. Numeric T does not have to be paid past its logarithmic
mixing cutoff; only its binary representation and input schedule are scanned.
More informatively, before that cutoff its work has the form

`poly(B,n,M,D0,epsilon^-1) * exp(O(c J T))`.

All constants in this expression depend only on k,d,r0 and the choice of a
standard dense-matrix arithmetic implementation. Consequently the exponent
in the polynomial is `O(1+c J/gamma)` up to universal algorithmic constants.
The theorem does not have a noise-uniform polynomial degree.

A supplied terminal product POVM with a bounded number of outcomes per site
and rational positive effects summing to identity is also allowed. The
maximally mixed branch is sampled from `Tr(M_{i,x})/2`, and in the trajectory
branch the joint physical/purifying TTN distribution is contracted. Conditional outcome weights are
exact rational contractions with the previously chosen local effects; no
minimum-probability promise or local square-root oracle is required.

The strongest unqualified output is total-variation sampling, **not** pointwise
relative error, rare-event probabilities or an explicit density matrix close
in trace norm. Independent repeated samples support additive prediction of
every specified efficiently computable bounded classical function of the
terminal outcomes, including full parity.

## 4. Proof: global mixing, paid discretization and crossing action

### 4.1 A self-contained global mixing bound

Let `tau=I/2^n` and `D(rho||tau)=n log 2-S(rho)`. Hamiltonian evolution,
including time-dependent H, has zero entropy derivative. By convexity of
relative entropy, a replacement term satisfies

`Tr[(E_i rho-rho) log rho] <= D(E_i rho||tau)-D(rho||tau)`.

Now

`D(rho||tau)-D(E_i rho||tau)
 = log 2+S(rho_{-i})-S(rho)`.

Strong subadditivity gives the entropy form of Shearer's inequality
`sum_i S(rho_{-i}) >= (n-1)S(rho)`. For completeness, order the sites.
Expand each `S(rho_{-i})` by the entropy chain rule, and use that deleting a
conditioning site can only increase conditional entropy, an immediate form
of strong subadditivity. Each chain-rule term of `S(rho)` appears n-1 times.
Thus

`d D(rho_t||tau)/dt <= -gamma D(rho_t||tau)`.

The full-rank calculation extends to singular inputs by continuity, so

`D(rho_t||tau) <= n log 2 exp(-gamma t)`,

`||rho_t-tau||_1 <= sqrt(2 n log 2) exp(-gamma t/2)`.

Set the integer

`L=ceil(log_2(16(n+1)/epsilon))`.

It is found by integer comparisons, not an exact-real logarithm oracle.
If `gamma T >= 2L`, then the trace distance bound is less than epsilon/16:
use `exp(-L)<=2^-L` and `sqrt(2 n log 2)<=n+1`. Sampling tau therefore
already has TV error less than epsilon/32. This applies to correlated rho_0.

In the remaining branch,

`gamma T<2L`, hence `J T<2gL`.

### 4.2 Rational channels and a finite uniform noise history

In schedule segment j of duration t_j, let

`S_j = 2 sum_a |h_{a,j}|+2 gamma n`,

`Lambda=sum_j S_j t_j`.

If T=0, sample the input TTN directly. Otherwise gamma>0 makes Lambda>0.
Take

`r_j = max(1, ceil(S_j t_j), ceil(10^6 Lambda S_j t_j/epsilon))`.

Divide segment j into r_j equal rational steps. Replace each Pauli unitary
by the rational Cayley rotation

`U_x=((1-x^2/4)I-i x P)/(1+x^2/4)`, `x=h_{a,j} t_j/r_j`,

and the noise by `(1-gamma h)Id+gamma h E_i`. All are CPTP, and gamma h<=1.
First-order channel telescoping gives an error at most

`40 sum_j (S_j t_j)^2/r_j < epsilon/1000`

in diamond norm. This follows directly by expanding exact local exponentials
to second order, using their diamond norm contraction, bounding the sum of
second-order cross terms by `(S_j h)^2`, and using the Cayley third-order and
Euler second-order remainders when `S_j h<=1`. The displayed factor 40 is
slack. The r_j choice pays the error since

`sum_j (S_j t_j)^2/r_j <= epsilon/(10^6 Lambda) sum_j S_j t_j`.

The total number of time steps is

`R=sum_j r_j <= 2M+2 Lambda+10^6 Lambda^2/epsilon`.

Here M is the number of nonempty schedule segments after cutting at T.
Moreover

`Lambda <= 2 n(dJ+gamma)T <= 4 n(dg+1)L`.

Thus R and the number G of elementary gates/noise choices are polynomial in
n,M,epsilon^-1 at fixed g,d. Exponentially large numeric J or gamma does
not escape the bound: only the paid dimensionless actions occur; their binary
representations are included in B.

Each Euler noise factor is sampled by its rational `I,X,Y,Z` mixture. A fixed
noise history is a unitary circuit on the physical qubits, acting on the
supplied purification. Purifying coordinates are passive representation
coordinates, not a physical reset supply.

### 4.3 The exact nuclear norm is uniformly bounded on every tree edge

For a unit vector psi, write `N_e(psi)` for the sum of Schmidt coefficients
across `A_e,B_e`, putting each purifying coordinate on its physical site's
side. Initially `N_e(Psi_0)<=sqrt(D0)` by Cauchy--Schwarz.

A crossing rotation changes this norm by at most `exp(|theta|)`, as audited
in Section 2. Its Cayley angle has magnitude
`2|arctan(x/2)|<=|x|`. A noncrossing unitary, in particular any one-site Pauli
noise kick, preserves `N_e` exactly. Therefore, for every history and every
intermediate point,

`N_e(psi_exact) <= sqrt(D0) exp(A_e(T))`,

`A_e(T)=sum_j t_j sum_{a crossing e}|h_{a,j}| <= c J T`.

This is the decisive estimate. There is no factor from the number of Trotter
layers or from the length of a path through the tree. Define

`B_star=2^[ceil(ceil(log_2 D0)/2)+1+ceil(2cJT)]`,

or any larger integer power of two, so that
`B_star>=sqrt(D0)exp(cJT)`. All needed bounds can be chosen by rational
integer arithmetic. In the nontrivial branch,

`B_star <= 4 sqrt(2D0) 2^(4cgL+1)`.

It is polynomial in D0,n,epsilon^-1 for fixed c,g.

## 5. Constructing and sampling the compressed tree states

### 5.1 Algorithmic truncation, not an existential ansatz

Applying a Pauli rotation has operator Schmidt rank at most two across each
cut. It has a TTN operator representation of bond at most two on the Steiner
subtree joining its support, and bond one elsewhere. Thus it can be applied
to a TTN of bond D using intermediate bond at most 2D. One-site noise kicks
change only the corresponding leaf tensor.

After each gate, perform a canonical sweep through every tree edge and compress
there. A TTN has exact Schmidt decompositions across its edges: isometric
subtrees reduce the relevant SVD to a local matrix. Replacing the central
Schmidt matrix by a lower-rank approximation changes no other virtual bond.
This is established TTN machinery, credited to Shi--Duan--Vidal and Seitz et al.
It can also be seen directly by contracting all isometric subtrees to the two
sides of the edge. The operations act on at most cubic-size local tensors in D,
not on a `2^n` coefficient matrix.

Let `M_c=100 n(G+1)` bound the number of Schmidt compressions and sweeps, and
put `zeta=epsilon/100`. Choose the target bond cap

`D = ceil((128 M_c B_star/zeta^2)^2)`.

With exact arithmetic, truncating to the largest D Schmidt values increases
the squared error relative to the corresponding exact history vector by at
most `2 B_star/sqrt(D+1)`. All unitary updates preserve the vector error, and
all compressions decrease the approximate norm. Summing the error increments
gives a final vector error less than zeta/2. There is ample slack for finite
arithmetic, discussed next. D is at least D0.

### 5.2 Finite precision and the absence of an eigenvalue-gap assumption

Input rational contractions have polynomial bit length in B and the number
of contracted TTN nodes: multiplication on an acyclic graph does not create
exponentially long rational numbers. Canonicalization and compression are
done with certified dyadic arithmetic.

There is a small but useful refinement to the usual informal appeal to an
approximate SVD. No gap-free procedure is required to approximate one uniquely
specified exact top-D subspace. Near a tied singular value that requirement
would be inappropriate. It is enough to construct an orthogonal compression
with discarded operator norm at most `2/sqrt(D)` and rank at most `2D`, up
to a paid normwise error nu. Such a compression is obtained by diagonalizing
the local Gram matrix to residual smaller than a chosen multiple of `1/D`
and retaining all directions above the threshold. Since its Frobenius norm
is at most one plus rounding slack, the retained rank is at most a constant
times D. The nuclear/operator-duality proof of Section 2 then applies with
twice the constant. We may use bond cap 4D to absorb these harmless choices.

For each local operation choose normwise arithmetic error

`nu <= zeta^2/[10^5 (M_c+G+1)]`.

Rescale the approximate state by a certified upper bound on its norm whenever
needed, so its norm stays at most one. If both reference and approximation
have norms at most one, a normwise perturbation nu changes their squared
distance by at most `4nu+nu^2`. Summing these increments together with the
compression increments keeps the final vector error below zeta.

Gap-free approximate Hermitian diagonalization, for example Jacobi rotations
until the off-diagonal Frobenius residual is small enough, has polynomial work
in local matrix dimension and log(1/nu). Thresholds may retain ambiguous small
singular directions; they are not inverted. An initial rational TTN can be
canonicalized by the same bottom-up QR/SVD procedure with its actual input
height charged. Large but rational local tensor entries contribute their
binary height, and nearly null directions are discarded with a paid normwise
error. No inverse minimum Schmidt coefficient is part of the contract.

Every local matrix has dimension polynomial in D and `2r0`. A deliberately
loose bit-work envelope per history is

`poly(B,G,n,log(1/nu)) * (1+D0+D)^C`

for a universal constant C, using dense-matrix arithmetic. This is sufficient
for a uniform polynomial. The report makes no claim that this pessimistic
compression rule is useful in practice.

### 5.3 TV error and bounded random-bit sampling

For each history, let psi be the exact unit history vector and phi its
subnormalized rational TTN approximation with `||phi-psi||<=zeta`.
Normalizing phi changes it by at most zeta in vector norm. Hence the trace
norm distance of the two pure density operators is at most `4zeta`.
Partial trace and the final measurement contract trace distance, so the
conditional output distributions differ in TV by at most `2zeta`.
This estimate is uniform in the noise history. Averaging histories preserves it.

A rational TTN permits exact rational norm contractions and conditional
computational-basis probabilities. One can sample the joint physical and
purifying leaf indices sequentially and discard the purifying results. The
normalization scalar cancels in the conditional ratios; extremely small
nonzero probabilities do not require an inverse-probability accuracy promise.
Their numerators and denominators are rationals of polynomial bit height.

Use finitely many bits for each categorical choice. With at most N_cat
choices, round each rational conditional to a dyadic distribution within
TV `epsilon/(100 N_cat)`. This uses
`O(log(N_cat/epsilon))` bits per choice and adds at most epsilon/100 to
the output TV by sequential coupling. Apply the same convention to the
Euler noise choices. N_cat is polynomial and fixed before the run.

The channel discretization, TTN approximation and both finite-bit sampling
errors together are less than epsilon. All branches have bounded work. There
is no additional Monte Carlo failure probability: TV is a statement about
the sampler's output law. For a subsequent additive prediction with confidence
1-delta, ordinary independent repetitions add the familiar
`O(epsilon^-2 log(1/delta))` factor.

This completes the theorem.

## 6. Interaction classes, a more general action theorem and hard boundaries

The proof actually gives a **crossing-action theorem without noise**: given a
normalized TTN input and any explicit Pauli circuit or piecewise Hamiltonian,
whole-output sampling has cost polynomial in its explicit circuit size (or,
for a Hamiltonian schedule, also its total numeric generator action Lambda),
desired inverse error and `sqrt(D0) exp(max_e A_e)`. Noise is used only to cap the nontrivial
physical time at `O(gamma^-1 log(n/epsilon))` while contributing no crossing
action in its random-unitary representation.

The cut certificate is efficiently verified from the supplied data: compute
the leaf partition at each tree edge and count the active terms crossing it
in every schedule segment. No treewidth-search oracle is assumed.

Examples with constant c:

* A chain with bounded-range bounded-incidence interactions: use its usual
  MPS cuts or a corresponding binary leaf tree. c depends only on range and
  incidence, not n.
* A fixed-width ladder or cylinder: row ordering gives constant crossing
  count when width is a class parameter.
* A bounded-degree physical tree with finite interaction range: attach a leaf
  for each physical site and split a higher-degree branching tensor into
  binary nodes. A virtual cut separates unions of a bounded number of physical
  branches. Crossing terms touch a bounded-radius neighborhood of the branch
  separator, so their number is bounded by a constant depending only on
  physical degree, interaction range and d. One can simply scan and verify
  the resulting certificate rather than relying on this description.

General square-lattice regions fail the constant-cut hypothesis. A binary
leaf tree has a balanced edge cut, and a full L by L grid has edge boundary
Omega(L) for a balanced vertex partition. Thus the supplied-certificate proof
only offers `exp(O(L JT))` there. This is a limitation of this construction,
not a hardness proof.

The dependence on crossing action is not artificial: r disjoint XX rotations
of angle pi/4 across a specified cut turn a product state into r Bell pairs
and give Schmidt nuclear norm `2^(r/2)`. A different tree may group those
pairs and solve that particular model easily, so this example does **not**
prove an obstruction for every decomposition of every 2D state.

Other boundaries:

* A generic succinct correlated-state circuit cannot replace the supplied TTN.
  At T=0 this would ask for general quantum-circuit output sampling. The TTN
  input is a substantive tractability condition, not arbitrary-state access.
* General nonunital Lindblad noise is not covered. It need not mix to tau or
  admit unitary trajectories with bounded crossing action. Resets supply fresh
  purity, and known fault-tolerant hardness results must not be contradicted
  by silently adding them.
* Arbitrary fast Hamiltonian variation is not a free oracle. The theorem uses
  an explicit finite rational schedule and pays its complete length.
* A polynomial degree independent of J/gamma has not been obtained. The proof
  visibly contains `exp(cJT)` up to the global mixing time.
* A global state-vector approximation on bounded cuts earns a TV sampler;
  original normalized-HS operator compression alone does not. In particular,
  the original 2D local-mean theorem cannot be iterated on exponentially rare
  conditionals to obtain the absent full sampler.

## 7. Primary-source comparison and novelty audit

All URLs below were opened as primary sources during this independent turn;
cached source files and a hash manifest are under
`sources/literature/constructor/`. Search results were discovery aids only.

1. **Shi--Duan--Vidal, quant-ph/0511070v2, PRA 74, 022320 (2006).**
   [Primary text](https://arxiv.org/html/quant-ph/0511070v2).
   The TTN canonical form and edge Schmidt decompositions are given in the
   main text, followed by the one-/two-qubit gate update rules and tree-graph
   time-evolving block decimation. These are algorithmic constructions rather
   than a theorem numbered as a noise-induced sampling result. I import only
   efficient contractions, local gate updates and edge compressions. Their
   hypotheses hold because the supplied representation is an actual acyclic
   degree-three TTN and its bonds are explicitly capped by Section 5.
2. **Seitz--Medina--Cruz--Huang--Mendl, arXiv:2206.01000v3,
   Quantum 7, 964 (2023).**
   [Sections 2.2 and 3.2](https://arxiv.org/html/2206.01000v3).
   Gate application and orthonormalization are analyzed as polynomial in the
   TTN size and bond dimensions. I use that algorithmic operation, not a
   claim that low bond dimension follows from noise in their paper.
3. **Bravyi--Gosset--Movassagh, arXiv:1909.11485, Theorem 5.**
   [Primary PDF](https://arxiv.org/pdf/1909.11485).
   Its 2D nearest-neighbor depth-d mean-value algorithm has cost
   `n delta^-2 2^O(d^2)` for a product of Hermitian one-site contractions.
   The original report extends the architecture using physical-time nuclear
   growth. It does not itself give a full-distribution sampler; I do not
   relabel its mean-value result as one.
4. **Trivedi--Cirac, arXiv:2110.10638v2, PRL 129, 260405 (2022).**
   [Primary text](https://arxiv.org/html/2110.10638v2).
   The high-noise classical sampling result and low-noise computational
   encodings concern locally interacting continuous-time open systems with
   specified entanglement-breaking noise. It is the relevant continuous-time
   sampler comparator. The present bounded-cut result removes a high-noise
   threshold within its restricted interaction class and unital noise model;
   it does not supersede its general-dimensional high-noise theorem or its
   nonunital hardness encodings.
5. **Shao--Zhao--Cheng--Liu, arXiv:2606.00474v1 (30 May 2026).**
   [Primary text](https://arxiv.org/html/2606.00474v1), main Section III and
   Appendix D.3, especially the whole-trajectory 1D MPO discussion. This is
   a strong related predecessor: it claims polynomial bond dimensions across
   the full noisy 1D circuit trajectory at controlled Hilbert--Schmidt error.
   Those claims cannot be ignored in a novelty comparison. I do not import
   its MPO statements as a trace-norm sampler theorem; a normalized-HS bound
   by itself does not pay arbitrary global measurement error. The construction
   here instead controls pure trajectory vector error, hence TV, and its
   continuous-time finite-step dependence is explicitly paid. No novelty over
   its entire work is asserted without a closer theorem-by-theorem audit.
6. **Nelson--Rajakumar--Yin--Zhang--Gullans, arXiv:2610.00548v2.**
   [Theorem 2.3](https://arxiv.org/html/2610.00548v2) gives an FPTAS for arbitrary
   output log-marginals of D-dimensional local unital circuits once
   `d>O((D/p)log(D/p)+3^D/p)`, with per-layer depolarization p. Proposition
   2.2 converts those log-marginals to relative-error and TV sampling.
   This is strictly stronger in output error than the present sampler and
   covers spatial dimensions beyond two in its discrete model. It is not a
   direct continuous-time black box: setting `p=gamma h` makes both its
   threshold physical time and its polynomial degree depend on the shrinking
   step h. The present theorem's bounds remain uniform in h but require
   bounded interaction cuts. A physical-time continuous version of their
   polymer method is a much more consequential unresolved operation.
7. **Angrisani--Puig--Teng--Holmes, arXiv:2609.40174v2.**
   [Primary text](https://arxiv.org/html/2609.40174v2), S5 and S8.
   These are the sparse Pauli-norm predecessors used by the original report
   and by the uniform 2D consequence below. Their random-input/random-
   Hamiltonian operational quantifiers are not changed here.
8. **Relevant Zenodo search.** I inspected the primary records
   [Quantum TEA qtealeaves 1.12.5, 10.5281/zenodo.20109357](https://zenodo.org/records/20109357)
   and [TUSQ, 10.5281/zenodo.17594402](https://zenodo.org/records/17594402).
   The former is a current TTN implementation release, the latter a noisy
   simulation performance poster. Neither record as inspected supplies the
   above uniform continuous-time bounded-cut TV theorem. They show that TTN
   sampling and trajectory reuse are active existing methods. This limited
   search does not establish priority or exhaustive absence of predecessors.

The candidate contribution is the explicit combination

`bounded interaction cuts + accumulated Pauli angle
 + constructive global TTN vector control + all-input entropy cutoff`,

with a full finite-bit/TV contract and correlated TTN inputs. Most ingredients
are established. A manuscript novelty claim would need a targeted search on
noise-induced continuous-time tree samplers, including textbook corollaries
of earlier tensor-network approximation theorems. The safe scientific claim
is the theorem derived here, not historical firstness.

## 8. A strict extension which retains arbitrary 2D interactions

This section is separate from the sampling theorem. It retains the original
2D Pauli Hamiltonian and product input and uses its actual proof.

### 8.1 Polylogarithmic Pauli strings

Fix any positive constant b. Let Q denote complete input size plus n and
epsilon^-1, and let P be a Pauli string with

`|supp(P)| <= [log(2+Q)]^b`.

The specified mean `Tr[rho_0 exp(TG)P]` has a randomized polynomial bit-time
additive-epsilon predictor for every fixed positive gamma/J, with confidence
digits paid as in the original theorem. The support may be disconnected and
may be a string or loop; it need not have bounded diameter.

**Uniform proof.** Retain the original global entropy cutoff, which does not
depend on support. In the nontrivial branch `JT=O(log Q)`. The operator LR
truncation around the w occupied sites needs
`R=O(JT+log(w/epsilon))=O(log Q)`, with constants depending only on a,k,d,g.
Thus its retained site count is

`m <= O(w R^2)=O(log^(b+2) Q)`.

The sparse engine starts from one Pauli, so its initial Pauli-p norm is one,
**not** `4^w`. Its rational update count is polynomial in m, JT and epsilon^-1;
the fixed-p threshold produces `K=Q^O(1)` terms. The coefficient l1 sum obeys
`S<=sqrt(K)(1+eta)`, so buffer accuracy xi is inverse polynomial in Q.

The smoothing duration is `s=O(log m/gamma)=O(log log Q/gamma)`, and the
factorial-strip parameter Lambda is `O(log(m/xi))=O(log Q)`. The original
construction therefore uses `b_strip=O(log Q/log log Q)`, and its crossing
nuclear norm has log bound

`O(b_strip J s)=O(log Q)`.

Row dimensions and the constructive MPS bonds are polynomial in Q, as are
the number of components, buffer calls and repetitions. There may be up to w
disconnected restricted components; evaluate their buffer expectations with
accuracy xi/w and telescope their products, each factor having magnitude
at most one. log w only changes logarithmic budgets. No large empty lattice
rectangle is inserted. This pays every growth in w without putting w inside
the exponent of the original oversized fixed-w complexity envelope.

This is a proved uniformity consequence of the original machinery. It does
not prove efficient global parity for arbitrary n-site support.

### 8.2 Logarithmic-subsystem tomography in trace norm

For any chosen subsystem S of q<=C log(2+Q) qubits, use 4^q calls from the
previous result to estimate all Pauli coefficients of its reduced state.
If each coefficient has error at most alpha, the reconstructed Hermitian
matrix `rho_tilde=2^-q sum_P rhat_P P` obeys

`||rho_tilde-rho_S||_2 <= 2^(q/2) alpha`,

`||rho_tilde-rho_S||_1 <= 2^q alpha`.

Set `alpha=epsilon/(8*2^q)` and allocate confidence delta/4^q per call.
Both the number of calls and alpha^-1 are polynomial in Q. Set the identity
coefficient to one exactly. If a physical density matrix is requested,
diagonalize rho_tilde, remove negative eigenvalues and renormalize. Since
rho_S is positive of trace one, this changes the trace-norm error by at most
a universal factor (for instance four), so the displayed allocation leaves
total error <=epsilon. Finite eigendecomposition is paid at dimension 2^q,
again polynomial. A certified approximate projection can use extra slack.

This supplies the complete reduced density matrix in trace norm, and hence
additive prediction of arbitrary bounded observables or product measurement
sampling on the chosen logarithmic-sized subsystem. It does not supply
arbitrary efficiently computable entanglement measures, nor an efficient
global state representation. Novelty is the same modest uniformity extension
as above, not a separate mechanism.

## 9. Executed tests, failures and remaining decisive operation

The independent script `constructor/audit_constructor.py` and output
`constructor/AUDIT_CONSTRUCTOR.json` carry the exact finite diagnostic scope.
They check 60 random small-angle Pauli rotations with on-site Pauli kicks on
an eight-qubit branching compatible cut tree, sequential dense Schmidt
compressions, 36 correlated-state entropy derivatives, four Cayley/Euler
channel discretizations and four explicit crossing-Bell examples.

Observed maxima:

* nuclear bound ratio `1.0000000000000002`, a roundoff-level endpoint;
* truncation inequality residual `-1.1547005383792517`;
* entropy derivative plus D `-0.6481671909773781`;
* channel trace error decreases from `0.00374598375` at 8 steps to
  `0.000468091008` at 64 steps, all below the deliberately loose proved bound;
* Bell nuclear norms agree with `2^(r/2)` through four crossing pairs.

These tests do not implement the certified TTN arithmetic, prove uniformity
or establish a practical runtime. A first run found scipy unavailable; the
diagnostic now uses a small-matrix scaling/Taylor exponential implemented in
the script, with no environment installation or dependency change.

Rejected routes are retained explicitly:

1. **Iterating local additive predictions to sample the 2D output:** fails
   because conditional events can have exponentially small probabilities and
   conditioning destroys the product-input contract.
2. **Using generic unital local dissipators in the trajectory proof:** not
   established. Multiqubit unital channels need not be mixed unitary; standard
   Stinespring steps have square-root-step couplings, so summing their absolute
   crossing angles is not a continuous-time bound. An operator-MPO HS bound
   would not automatically pay trace-norm output error.
3. **Whole-trajectory TTN sampling for the generic 2D class:** the bounded-cut
   nuclear estimate grows exponentially in the boundary length. The original
   parity-overlap representation avoids that for a scalar mean, but has not
   been converted into a positive globally sampleable state representation.
4. **Correlated input given only by a succinct general circuit:** unsupported
   already at T=0. Input representation is part of the computational claim.

The most consequential remaining operation is a **physical-time polymer or
positive generative representation for arbitrary 2D noisy dynamics** which is
stable as a rational time step tends to zero. Closing that would potentially
promote local prediction to full TV or relative sampling in the original 2D
class. This report does not claim that operation.

## 10. Claim ledger and handoff

| Claim | Status | Evidence or exact boundary |
|---|---|---|
| Original arbitrary static 2D product-input fixed-local mean theorem | Retained established capital | Pinned original report; scope unchanged |
| Accumulated crossing-action TTN simulation and TV sampling | Proved here | Sections 3--5; finite bit contract included |
| All-time full-output TV sampling with replacement noise on certified bounded-cut architectures | Proved here | Entropy cutoff plus previous row |
| Arbitrary correlated supplied locally purified TTN input on the same tree | Proved here | Initial cut nuclear norm <=sqrt(D0); physical entropy bound input independent |
| Explicit piecewise Hamiltonian drives in that sampling theorem | Proved here | Paid schedule and segmentwise CPTP approximation |
| Fixed-power-polylog Pauli support in the original 2D predictor | Proved uniformity extension | Section 8.1, without growing-w fixed-class envelope |
| Trace-norm tomography of a logarithmic-sized output subsystem | Proved consequence | Section 8.2 |
| Generic 2D full-output sampler at every positive gamma/J | Open | No positive representation/sampling operation supplied |
| Generic local nonunital noise or arbitrary circuit input | Not obtained | Section 9 obstructions |
| Polynomial degree uniform as gamma/J ->0 | Not obtained | Explicit crossing-action exponential |
| Historical firstness or foundational novelty | Unverified | Existing TTN and noisy MPO predecessors need targeted audit |
| Practical advantage or physical controller capability | Not demonstrated | No full implementation or matched performance study |

Supporting files are confined to `constructor/` and
`sources/literature/constructor/`; the initial report itself is this file.
No published artifact, Gibbs work, other researcher's initial notes or held
external archive was modified or inspected. No publication or communication
to third parties was performed.
