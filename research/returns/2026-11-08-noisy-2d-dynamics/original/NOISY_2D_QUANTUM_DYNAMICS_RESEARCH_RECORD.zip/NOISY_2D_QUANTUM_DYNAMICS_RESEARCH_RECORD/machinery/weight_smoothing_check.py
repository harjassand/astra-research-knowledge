"""Finite diagnostic for the time-dependent Pauli-weight smoothing lemma.

The report contains the proof. This small test checks signs, adjoints, and
constants; it cannot certify the uniform theorem.
"""
import itertools
import json
from pathlib import Path

import numpy as np


def matrix_exp(a):
    scale = max(0, int(np.ceil(np.log2(max(1, np.linalg.norm(a, ord=np.inf))))))
    a = a / (2**scale)
    result = np.eye(len(a), dtype=complex)
    term = result.copy()
    for j in range(1, 200):
        term = term @ a / j
        result += term
        if np.linalg.norm(term, ord=np.inf) < 1e-17:
            break
    for _ in range(scale):
        result = result @ result
    return result


def main():
    single = [np.eye(2), np.array([[0, 1], [1, 0]]),
              np.array([[0, -1j], [1j, 0]]), np.diag([1, -1])]
    n = 3
    labels = list(itertools.product(range(4), repeat=n))
    paulis = []
    for label in labels:
        p = np.array([[1]], complex)
        for index in label:
            p = np.kron(p, single[index])
        paulis.append(p)
    weights = np.array([sum(j != 0 for j in x) for x in labels])
    terms = [((1, 1, 0), .61), ((0, 2, 2), -.43),
             ((3, 0, 0), .22), ((0, 3, 0), -.19), ((0, 0, 1), .17)]
    h = sum(c * paulis[labels.index(label)] for label, c in terms)
    gamma, k, degree, strength = .7, 2, 3, .61
    theta = min(1 / (2 * k), gamma / (16 * k * degree * strength))
    t0 = 2 * theta / gamma
    coherent = np.array([
        [np.trace(a.conj().T @ (1j * (h @ b - b @ h))) / 2**n
         for b in paulis] for a in paulis])
    generator = coherent - np.diag(gamma * weights)
    rows = []
    for time in [t0 / 3, t0, 2 * t0, .3, .9]:
        alpha = min(gamma * time / 2, theta)
        channel = matrix_exp(time * generator)
        weight_map = np.diag(np.exp(alpha * weights))
        rows.append({
            "t": float(time), "alpha": float(alpha),
            "weighted_smoothing_norm": float(np.linalg.svd(weight_map @ channel, compute_uv=False)[0]),
            "dual_smoothing_norm": float(np.linalg.svd(channel @ weight_map, compute_uv=False)[0]),
            "max_homogeneous_bound_ratio": max(
                float(np.linalg.norm(channel[:, j])) / np.exp(-alpha * weights[j])
                for j in range(1, len(weights))),
        })
    tilted = []
    for alpha in [0, theta / 2, theta]:
        weight_map = np.diag(np.exp(alpha * weights))
        inverse = np.diag(np.exp(-alpha * weights))
        for sign in [1, -1]:
            a = weight_map @ (sign * coherent - np.diag(gamma * weights / 2)) @ inverse
            tilted.append({"alpha": float(alpha), "hamiltonian_sign": sign,
                           "max_hermitian_eigenvalue": float(np.linalg.eigvalsh((a + a.conj().T) / 2)[-1])})
    result = {"scope": "Finite diagnostic only; the report supplies the general proof.",
              "parameters": {"n": n, "gamma": gamma, "k": k, "d": degree,
                             "J": strength, "theta": theta, "t0": t0},
              "smoothing": rows, "tilted_generator": tilted}
    assert all(row["weighted_smoothing_norm"] <= 1 + 1e-10 for row in rows)
    assert all(row["dual_smoothing_norm"] <= 1 + 1e-10 for row in rows)
    assert all(row["max_hermitian_eigenvalue"] <= 1e-10 for row in tilted)
    output = Path(__file__).with_suffix(".json")
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(f"PASS: {len(rows)} smoothing and {len(tilted)} tilted-generator checks; {output}")


if __name__ == "__main__":
    main()
