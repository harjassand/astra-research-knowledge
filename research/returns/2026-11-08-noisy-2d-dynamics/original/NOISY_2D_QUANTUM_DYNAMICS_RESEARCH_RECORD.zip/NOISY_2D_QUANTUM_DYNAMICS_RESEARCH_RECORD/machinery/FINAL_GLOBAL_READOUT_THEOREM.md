# All-time global Hermitian product readouts: final formal theorem and cost closure

8 November 2026. This expands and checks the frozen independent report initial/machinery.md (SHA256 e0100982b66df8da37d46f2edd48d861f5c463c2b5e620f869399a024e80aa46). Its bytes are unchanged. Subsequent team exchange was authorized before this file was written. The proof uses the pinned original 2D predictor's inspected constructive MPS/strip machinery; it does not claim implementation at its worst-case bounds or historical priority.

## 1. Input contract and conclusion

Fix a,k,d and g>=J/gamma0, where gamma0>0. There are n explicitly listed qubits on a finite square-lattice region. The input contains a finite piecewise-constant schedule on [0,T], rational breakpoints, and rational Pauli coefficients. At every time, H(t)=sum_a h_a(t)P_a has term support size <=k, range <=a, |h_a(t)|<=J, and at most d active terms at each site. The full number M of segments and their bits are paid. Arbitrarily short segments are permitted; no reciprocal minimum segment length enters the cost.

The base generator is

    L_t(rho)=-i[H(t),rho]+gamma0 sum_i(E_i(rho)-rho),
    E_i(rho)=I_i/2 tensor Tr_i rho.

The initial input is a rational one-qubit product density matrix, and

    O=tensor_i O_i, O_i=O_i^dagger, ||O_i||_infty<=1,

with rational two-by-two factors and no support bound. Given rational 0<epsilon<=1/2 and 0<delta<1, a finite-work randomized classical algorithm returns rational fhat with

    Pr[|fhat-Tr(O rho_T)|<=epsilon]>=1-delta.

Work is polynomial in explicit n, complete binary input length B, 1/epsilon and log(1/delta), with degree/prefactor depending only on a,k,d,g. Binary T is included in B; one can therefore also state the weaker requested polynomial bound in numeric 1+T. Large horizons are discarded by mixing before numerical evolution. A polynomially evaluable rate in place of rational gamma0 is permitted only with its actual certified digit-acquisition cost charged.

The output is an additive mean. It includes global Pauli parities and additive probabilities of arbitrary product projectors. It is not a total-variation sampler, a relative-probability oracle, or an arbitrary correlated-input predictor.

## 2. Chronology convention

Let E_{t,s} be the Schrödinger propagator from s to t, and Phi_{s,t}=E_{t,s}^* its Heisenberg dual. Then

    Phi_{s,t}=Phi_{s,u} Phi_{u,t}.

Whenever the proof uses a short hypercontractive buffer, that buffer is the EARLY interval [0,s]. Sparse propagation acts on the LATER observable Phi_{s,T}O. No channels from different time intervals are commuted. Norm estimates hold for every schedule ordering because their local inequalities are uniform in the instantaneous coefficients. On taking Hilbert–Schmidt adjoints one reverses the schedule and the Hamiltonian sign.

## 3. Pauli smoothing, with proof

Use normalized Hilbert–Schmidt norm and Pauli weight operator W(P)=|P|P. Set

    theta=min(1/(2k),gamma0/(16kdJ)),
    alpha(u)=min(gamma0 u/2,theta), t0=2theta/gamma0.

For any interval of duration u and its actual chronological propagator S,

    ||exp(alpha(u)W) S||_{2->2}<=1,
    ||S exp(alpha(u)W)||_{2->2}<=1.                     (3.1)

Consequently, if X is supported in homogeneous Pauli weight r,

    ||S X||_2<=exp(-alpha(u)r)||X||_2.                 (3.2)

Proof: reserve half the replacement rate. Allocate gamma0/(2d) per incident Hamiltonian term on each site of that term. On an anticommuting Pauli pair a coherent term has skew entries of magnitude 2|h_a|. Conjugation by exp(alpha W) gives Hermitian-part norm at most 2|h_a|sinh(k alpha), while its allocated active-sector damping is at least gamma0/(2d). Because k alpha<=1/2 and 2J sinh(k alpha)<=4Jk alpha<=gamma0/(4d), the tilted half-noise generator has nonpositive Hermitian part. Unallocated noise is dissipative.

For b(u)=exp(alpha(u)W)X(u), the remaining half-noise contributes (alpha'(u)-gamma0/2)W to b's generator. This is nonpositive. Thus its squared norm decreases, including across segment boundaries and the corner alpha=theta. This proves the first bound. The reverse-sign reversed schedule has the same bound, and adjoint duality proves the second. Applying it to exp(-alpha r)X proves (3.2).

This is a moving-weight use of the two-by-two estimate in Angrisani et al2609.40174v2 Corollary S12, with rate allocation made explicit. Merely citing fixed weighted-norm contractivity would not prove (3.2).

## 4. A product with r nonidentity traceless factors

First handle P that is a local traceless Hermitian unitary at r sites and identity elsewhere. Its Pauli expansion is homogeneous of weight r and HS norm one.

Localize the full evolution to A, the union of radius-R balls around its support, with operator-norm error eta. An explicit larger version of the original exponential locality bound gives constants C_loc,v_loc depending only on a,k,d such that

    R<=C_loc[1+JT+log((r+1)/eta)],
    m=|A|<=min(n,C_loc r[1+JT+log((r+1)/eta)]^2).       (4.1)

Replacement is sampled as one-site Pauli kicks. Conditional on any noise history, its toggling-frame Hamiltonian has the same local strengths and incidence. Hence the usual linked-interaction locality bound depends on J, not on the number or rate of on-site kicks. Averaging preserves it. This also supplies (4.1) for the noise extensions in Section 9.

On m sites, real-channel hypercontractivity gives

    ||Phi_{0,s}Y||_{q,tau}<=||Y||_{2,tau}
    when q-1<=exp(2gamma0 s).

King1210.8412 Corollary2 supplies the depolarizing inequality. Interleaving with Hamiltonian conjugations, which are Schatten isometries at each exponent, and taking the product limit proves the actual-channel statement.

Choose

    b=max(1,ceil(log_2(8m/(theta r)))), s=b/(2gamma0).

Taking q=1+exp(b), normalized Schatten comparison gives

    ||Phi_{0,s}Y||_infty<=2^{m/q}||Y||_2
                           <=exp(theta r/4)||Y||_2.

If T>=s+t0, apply (3.2) to the LATER interval [s,T]. Therefore

    ||Phi_{0,T}^{A}P||_infty<=exp(-3theta r/4),
    ||Phi_{0,T}P||_infty<=eta+exp(-3theta r/4).         (4.2)

This estimate holds against any input state. Product input is required only to compute the other cases.

## 5. Quantitative rational propagation lemma

Here all dependence on growing support is visible. On m retained sites let X be a rational Hermitian observable with ||X||_2<=1 and initial Pauli coefficient one-norm at most M0. Let its explicit expansion have U terms. The support size is not a class constant.

For schedule segment j, of length Delta_j, let

    S_j=2 sum_a |h_{a,j}|+2 gamma0 m,
    A_j=S_j Delta_j, A_tot=sum_j A_j.

For target channel/HS error eta, choose

    r_j=max(1,ceil(A_j),ceil(10^6 A_tot A_j/eta)),
    R_num=sum_j r_j<=2M+2A_tot+10^6 A_tot^2/eta.         (5.1)

Use exact rational Cayley Pauli rotations and positive Euler replacement maps. The first-order channel error is at most 40 sum_j A_j^2/r_j<eta/100. Empty or zero-action intervals may be skipped. This follows by local second-order remainder bounds and contractive telescoping. All actual rationals, however short their time segments, have paid bit length. No step count proportional to 1/min Delta_j appears.

Allocate replacement gamma0/d per Hamiltonian term support and leave the nonnegative residual on every site. Put

    p=2/(1+min(1,gamma0/(2dJ)))<2,
    beta=ceil(4+4dJ/gamma0),
    Q_up<=C(kd+1)m R_num,
    ell=ceil(log_2(64 Q_up M0^2/eta)), tau_cut=2^(-beta ell).

Process a complete damped Hamiltonian block before pruning coefficients below tau_cut. Each Pauli has at most two branches. Every block contracts Pauli-p coefficient norm; pruning decreases it. The same proof as the original yields total pruning HS error <=eta/4 and

    K<=(M0/tau_cut)^p
      <=M0^2 [128 Q_up M0^2/eta]^(2beta),              (5.2)
    sum_j |b_j|<=sqrt(K)(1+eta).                       (5.3)

The initial U and the displayed K are charged. Updates merge exact rationals with common branch denominators. Coefficient bit height is bounded by

    C[B+Q_up(B+log R_num+log(K+2))],

up to harmless input-index factors. Thus arithmetic work is polynomial in these displayed parameters. Neither constant support nor a spectral-gap assumption is hidden in this lemma.

## 6. Quantitative global short-buffer lemma

For any fixed c, the original constructive strip proof evaluates a supplied Hermitian product contraction on m up to n sites, on product input, whenever

    JT<=c[1+log L],
    L>=max(64,log_2(100m^2/xi),log_2(2+B)),             (6.1)

with xi its target additive error. Time segments are explicit and paid. It suffices that c be a class constant.

Here are the actual cost parameters. Use (5.1), with eta=xi/100, for a rational channel reference; let G_num be its elementary gate count and take M_c=100(G_num+1)(m+1)^3. Color each segment's local terms with at most chi=kd+1 colors. All its noise histories are product Pauli kicks. Removing these to a toggling frame gives total colored physical duration at most chi T, independent of step and switch count.

Set A_fac>=max(64,2kd chi c) large enough to bound the linked-tail argument z<=A_fac(1+log L). Choose

    q=ceil(64(1+A_fac)^2 L/floor(log_2 L)),
    b_strip=a(q+2).

The linked-integral estimate bounds every strip truncation by support_prefactor z^q/q!, whose sum is <=xi/100; the polynomial support prefactor is absorbed by the chosen L. Thus

    b_strip<=C_fac L/log L,
    q_row<=4^[8(b_strip+a)],
    B_star<=exp(128ad(b_strip+a)J chi T),
    D=ceil((128 M_c B_star/(xi/100)^2)^2).             (6.2)

The harmless factor chi can be omitted with a more parallel accounting; retaining it is conservative. Equations (6.1)–(6.2) give log q_row=O(L), log B_star=O(L), and log D=O(L+log M_c+log(1/xi)), with constants depending only on physical class and c.

A uniform local dense-arithmetic polynomial in B,m,G_num,q_row,D and log(1/xi) constructs the two rational MPSs. One can use thresholded gap-free SVD compression with constant-factor rank slack, rather than requesting continuity of an arbitrarily selected top-D singular subspace at degeneracy. The nuclear/operator-duality truncation proof needs only a bounded discarded operator norm and a retained rank bound. Every compression/norm-rounding budget is paid as in the original and the constructor's numerical refinement.

The symmetrized overlap mixture has sample magnitude <=1, including when the two MPS site orders differ. It needs O(xi^-2 log(1/delta_b)) independent repetitions; all histories and categorical choices have finite paid random bits. Consequently the entire buffer cost is a fixed polynomial in the displayed algebraic parameters. In particular it is polynomial in B,m,M,xi^-1,log(1/delta_b) when L=O(log Q) and JT=O(log log Q). This is the quantitative statement used below; there is no growing-support parameter in a class exponent.

For Hermitian contraction factors, Q_j=U^dagger P_j U commute and are Hermitian contractions. Put their even and odd products on the two sides of an overlap. Localized products remain contractions, so vector telescoping and truncation work. On-site insertions cause no cross-cut nuclear growth. Thus global support and contraction rather than unitary factors do not add a cost beyond (6.2).

## 7. Branching algorithm and polynomial closure

For a homogeneous product P, target error xi and confidence beta, set

    Q=2+B+n+ceil(1/xi)+ceil(log(2/beta)), L0=ceil(log_2 Q).

If r=0 return one. If gamma0 T>=4L0, return zero by the original entropy estimate; P is traceless. Otherwise JT<=4g L0. Localize with eta=xi/100. Equation (4.1) gives m/r<=C(1+L0)^2, so the s of Section4 obeys gamma0 s<=C+log_2(1+L0).

- If T>=s+t0 and r>=ceil((4/theta)log(100/xi)), return zero using (4.2).
- If T<s+t0, apply the GLOBAL short-buffer lemma on m sites. Here JT<=C_g(1+log L0). Taking L=Theta_class(L0) in Section6 yields polynomial work even when m=n.
- Otherwise r=O_theta(log(1/xi)). Expand P into at most U=3^r terms with M0<=3^(r/2). The localized region has m=O_theta(L0^3). In the early interval take s0=ceil(log_2(2m))/(2gamma0). If T<s0 use the buffer directly. Otherwise propagate the LATER interval [s0,T] with Section5 to HS error eta=xi/100. Its action A_tot<=C m(J+gamma0)T=O_class(L0^4), and Q_up is polynomial in M,L0,xi^-1. Moreover

      U<=[C/xi]^(4log(3)/theta+1),
      M0<=[C/xi]^(2log(3)/theta+1).

  Thus (5.2)–(5.3) give K and coefficient one-norm polynomial in M,L0,xi^-1. The EARLY channel maps the HS error to at most twice its norm. Each remaining Pauli buffer is requested at accuracy xi/[C max(1,sum|b_j|)], whose inverse is still polynomial. Its duration is O(log m)/gamma0=O_class(log L0), and its logarithmic precision parameter in Section6 is O_class(log Q+log M). All costs stay polynomial.

This closes the dependency chain without treating r as a hidden constant or applying the original gross D_kappa envelope with a growing w.

## 8. Arbitrary Hermitian product contractions and complex LCU boundary

Write O_i=a_i I+b_i A_i with b_i>=0, A_i a traceless Hermitian unitary, and |a_i|+b_i<=1. Independently choose I with probability |a_i|, A_i with probability b_i, or a zero contribution; retain the signs of a_i. This is a bounded mixture with expectation O. Use Section7 for M_out=O(epsilon^-2 log(1/delta)) independent samples, internal accuracy epsilon/10, and failure delta/(2M_out). Clip inner values to [-1,1]; Hoeffding and the conditional union bound prove the theorem.

For rational inputs, approximate b_i downward and A_i by an exactly rational unit Bloch vector via a well-conditioned stereographic chart. Taking local norm error O(epsilon/n) pays O(epsilon) total error by product telescoping. Certified square roots and logarithmic dyadic precision suffice. All mixture probabilities and all matrices passed to Section7 can therefore be rational; no real-number oracle is introduced.

The inequality |a_i|+b_i<=1 is specific to Hermitian contractions. The theorem DOES NOT include arbitrary complex product contractions. Such a product is allowed only with a separately paid tensor-product Pauli/identity LCU whose coefficient one-norm Lambda_O is supplied or computed. Sampling its normalized absolute coefficients costs O(Lambda_O^2 epsilon^-2) repetitions, with errors divided by Lambda_O.

For example, exp(i theta sum_i Z_i/n) has such an LCU with Lambda_O<=exp(|theta|); frequencies |theta|=O(log(1/epsilon)) remain polynomially paid. The different normalization exp(i theta sum_i Z_i/sqrt(n)) can have LCU one-norm exp(O(|theta|sqrt(n))); no polynomial conclusion for it follows. A short-buffer overlap may accommodate some complex factors with adjoints on one side, but that does not repair the missing bounded global mixture at later times.

## 9. Variable replacement rates and correlated Pauli jumps

The same theorem holds for the explicitly piecewise rational generator

    L_t=-i[H(t),.]+sum_i gamma_i(t)(E_i-Id)
                     +sum_b lambda_b(t)(Ad_{P_b}-Id),

where gamma_i>=gamma0>0 and lambda_b>=0. P_b are explicitly listed Hermitian Pauli strings; their supports may be correlated or extensive because every Ad_{P_b} is a tensor product of one-site Pauli conjugations. Arbitrary multiqubit unital Lindblad operators are not admitted.

A simple uniform numerical contract fixes gamma_max/gamma0 and a bound lambda_site/gamma0 on sum_{b:i in supp P_b}lambda_b in every segment. Full jump lists, supports, rates and segment bits are paid. Then the extra action is polynomial under the same mixing cutoff. Alternatively the displayed propagation bounds may be used with their actual additional numerical action, but this is not a claim that arbitrarily large encoded rates cost only their bit length.

Proof changes: reserve gamma0/2; all extra noise is diagonal nonpositive in Pauli coefficients, so both coefficient-p and tilted weighted-2 estimates improve. Each extra map is a unital Schatten contraction, preserving hypercontractivity and entropy contraction. Histories remain product Pauli kicks and contribute ZERO nuclear crossing action. Counts in (5.1) use

    S_j=2sum_a|h_a|+2sum_i gamma_i+2sum_b lambda_b,

and include the number of listed jump maps in Q_up and G_num. The rates' finite representation and every elementary sample are charged.

An important localization convention: retain each Pauli jump with P_b replaced by its restriction P_b|A and the SAME rate. Do not discard a correlated jump merely because its full support crosses the region boundary. Its restricted action on local observables is exactly this map. Jumps whose restriction is identity may be omitted. The trajectory locality estimate (4.1) remains independent of these kick rates because they do not spread support and only change signs of local Pauli Hamiltonian coefficients.

## 10. Compatible prepared-input extension

The theorem also permits input W_p rho_product W_p^dagger where W_p is an explicitly listed bounded-range bounded-arity local unitary circuit of depth

    ell_p<=c_p[1+log(2+log Q)],

for fixed c_p, with rational or paid certified algebraic entries. The full circuit count/bits are charged. Efficiently generated classical mixtures of these descriptions are allowed with the generator's actual work and output precision charged.

This uses the auditor's repaired construction. Localize the noisy observable first; include its preparation causal cone. For each strip localize the noisy history with margin b_U, and conjugate exactly by the preparation circuit on a margin enlarged by O(ell_p). The parity vectors now act on the original product purification. Their strip width is b=b_U+O(ell_p), and

    log B_star=O(b(JT_buffer+ell_p)).

Since b_U=O(L/log L), JT_buffer=O(log L), and ell_p=O(log L), this is O(L). Preparation contributes at most O(b ell_p) crossing gates, each of constant local operator Schmidt one-norm. The full product-readout argument remains valid because high-weight suppression is input independent; only the nonsuppressed buffer changes as just described. No arbitrary circuit-described correlated input is covered.

## 11. Status and dependencies

The new mathematical closure is moving Pauli-weight smoothing, support-sensitive hypercontractivity, and explicit all-support branching. The inherited physical-time strip constructor, sparse coefficient propagation, King hypercontractivity and BGM overlap architecture retain their proper credit. Schedule, classical-mixture, prepared-input and Pauli-noise transfers are stated at their exact paid representation scopes. The theorem is internally derived and subject to the ongoing three-researcher cross-audit; no historical first-priority, practical capability or full-output sampling is inferred.
