# Independent review of biased-reset fixed-reference prediction

8 November2026. Reviewed principal/BIASED_RESET_CONSTRUCTION.md after the initial reports and earlier follow-ups. This is a substantive new construction, not a retrospective modification of an initial report. A version with corrected rounding and accuracy-based history cap was read; its exact checked hash is recorded in BIASED_RESET_REVIEW_PINS.json. No extra agents were used.

## Verdict

The proposed fixed-local prediction theorem closes at the stated scope, using the previously inspected constructive MPS/strip lemma. The weighted hypercontractivity import is applicable to the actual error operators, the displayed basis is KMS orthonormal, reference-preserving whole blocks supply the required skew-adjoint and coefficient estimates, and sampled reset-SWAP trajectories with RETAINED local registers give a positive, polynomial-cost short buffer. I found no fatal gap after the two numerical-budget repairs now present in the principal file.

The substantive conditions are fixed positive gamma/J, a uniform faithful-state floor mu>=nu0>0, a supplied product input and fixed-local readout, and EVERY local Hamiltonian block commuting with its local product reference. This is an arbitrary-accuracy nonunital theorem inside that common-reference class. It is not arbitrary cooling of arbitrary H, a generic interacting Gibbs-state algorithm, pure resets, a global sampler, or a global-product-readout theorem. Historical priority remains unestablished.

## 1. Exact weighted hypercontractivity import

Dong–Gao–Ou–Yao–Zhou2606.17729v1 Theorem1.1 is stated for a full-rank density matrix sigma and EVERY operator A on n qudits, with

    Delta_sigma,e^-t(A)=e^-t A+(1-e^-t)Tr(sigma A)I,
    ||A||_(sigma,q)=||sigma^(1/(2q)) A sigma^(1/(2q))||_q,
    t=(3 ln2)/(8 a_sigma) ln((q-1)/(p-1)),
    a_sigma=(1-2mu)/ln(mu^-1-1).

Thus the Heisenberg biased-reset semigroup is exactly its generalized depolarizing semigroup, with physical time multiplied by gamma. Tensor reference and ordinary, UNNORMALIZED Schatten norms are correct: the weights already normalize ||I||_(sigma,q)=1. No extra factor 2^-m belongs in this norm. At q=2 its inner product is Tr(X†sigma^(1/2)Y sigma^(1/2)); this is KMS, not the generally different GNS form Tr(sigma X†Y).

The stated 'every operator' matters because the sparse-propagation error is not positive. The import does not require the Hamiltonian-added generator itself to be reversible/PODS. Instead, apply depolarizing hypercontractivity to the tensor noise factors and use norm isometries for each reference-preserving Hamiltonian conjugation. Per-block conservation makes U commute with every power of sigma^m, so this is an isometry at EVERY varying weighted exponent. Interleaving and the chronological product limit therefore give actual-channel 2-to-q contractivity for q-1<=exp(c_sigma gamma s), c_sigma=8a_sigma/(3ln2). The short buffer belongs on the EARLY input-side interval.

The norm comparison is also correct. Writing A=sigma^(-1/(2q)) B sigma^(-1/(2q)) yields

    ||A||_infty<=lambda_min(sigma^m)^(-1/q)||B||_q
               =mu^(-m/q)||A||_(sigma^m,q).

There is a fully rational conservative schedule. By the mean-value theorem, a_sigma>=mu>=nu0, including the limit a_sigma=1/2 at mu=1/2. Hence c_sigma>=nu0. Let b=ceil(log2(4m/nu0)) and s=b/(nu0 gamma). Then q=1+exp(nu0 gamma s)>=4m/nu0, and

    mu^(-m/q)<=exp(nu0 ln(1/nu0)/4)<2.

Integer power comparisons compute b. No oracle for digits of a_sigma or its logarithm is needed. At fixed nu0 the duration is O(log(2m))/gamma.

### Earlier exact-qubit credit

Beigi–Datta–Rouze1804.10100v2 Theorem21 proves exact tensorization of alpha2 for the qubit generalized depolarizing generator; Theorem25 computes alpha2=(1-2mu)/log(mu^-1-1). These are established predecessors and should be credited even though Dong's slightly weaker constant is used. BDR Theorem11 as written gives its forward inequality for X>0; one should not quote that statement alone as an all-error-operator bound without a positive-input reduction. Dong Theorem1.1 explicitly supplies the required every-operator version. Its broader general PODS theorem is not needed here.

## 2. KMS basis and block estimates

Let u=sqrt(p(1-p)), z=2p-1. The proposed basis is

    F0=I, F1=X/sqrt(2u), F2=Y/sqrt(2u),
    F3=(Z-zI)/(2u).

It is orthonormal for the KMS inner product. Indeed, X and Y each have squared KMS norm 2u; the centered Z variance is 1-z²=4u²; all cross terms vanish. Nonidentity factors satisfy Tr(sigma Fj)=0. Tensor products are orthonormal and the adjoint reset maps every nonidentity local factor to zero. Therefore reset damping is exactly -gamma W, where W counts nonidentity F factors. This would be false in the uncentered ordinary Pauli basis for biased noise.

For each block [H_b,sigma^supp(b)]=0, conjugation is KMS unitary and its coefficient generator is real skew-adjoint in this Hermitian basis. Its two-norm is <=2J: conjugating the KMS Hilbert space to ordinary HS space by A->sigma^(1/4)A sigma^(1/4) leaves the commutator unchanged. On at most 4^k coefficients, its one-norm generator bound is <=2^(k+1)J by norm equivalence. This bound is independent of the ambient system size and of the selected basis condition number. Nonidentity local coefficient space is invariant, orthogonal to the fixed identity coefficient.

Allocate gamma/d replacement on every site in each incident block. Active strings receive damping at least gamma/d; inactive strings are fixed. Interpolation between coefficient-l1 growth and coefficient-l2 isometry, followed by that damping, gives a fixed coefficient p_c<2. Local branch count is at most 4^k. Residual nonnegative reset rates restore the full original rate at each site.

A matrix Cayley update for the WHOLE block is essential. It is rational and exactly commutes with the reference. Its effective logarithmic Hamiltonian 2 arctan(hH_b/2)/h is Hermitian, commutes with the reference and has norm<=J. Thus the same active-sector estimates hold at finite step. Decomposing XX+YY into individually reference-breaking XX and YY rotations in this sparse engine would invalidate this reasoning; their sum conserves number but the individual terms do not.

For the tilted coefficient norm, local generator entries connect weights differing by <=k. After conjugating by exp(theta W), the Hermitian part has entries proportional to sinh(theta(weight difference)). A row/column bound C'_k J sinh(k theta), with for example a deliberately large C'_k from the fixed dimension 4^k, is valid. The proposed fixed theta leaves strict damping slack. Pruning lowers both coefficient p_c norm and tilted two-norm.

Initial fixed-support O has constant budgets M0<=2^w and Mtheta<=exp(theta w), up to paid arithmetic slack, since ||O||_(sigma,2)<=||O||_infty. Retaining coefficients |b|>=tau then implies

    r<=theta^-1 log(2Mtheta/tau).

Thus r=O(log Q), not an assumed constant. A useful explicit norm bound is

    C_mu=sqrt((1-mu)/mu)>=max_j ||Fj||_infty.

It equals1 at the unbiased point. Consequently retained products have norm <=C_mu^r, and both their normalization and sum_j |b_j|C_mu^(r_j) are polynomial at fixed mu and gamma/J. The latter weighted one-norm must set the buffer's error budget, as the principal construction now requires.

## 3. Rounding and the finite-input claim

Basis entries are computable algebraic numbers of bounded local degree, not generally rationals. The principal now correctly uses certified dyadic coefficient updates and the stronger budget

    Q_up Kmax nu<=min(eta,M0,Mtheta)exp(-theta m)/100.

This controls accumulated HS error as well as constant p/tilted-norm slack. The earlier condition with eta absent would only control norm budgets and was insufficient for arbitrarily small target error. No remaining correction is needed on that point.

Take Kmax and pruning threshold in advance from doubled norm budgets. Rounding every retained coefficient by <=nu costs weighted l2 error <=sqrt(Kmax)exp(theta m)nu and l_p error <=Kmax nu, both covered by the displayed stronger budget. This avoids circular rank promises. Approximating the transition matrices themselves to that output tolerance also charges their bounded local norms and current coefficient one-norm. It needs only additional logarithms of already polynomial quantities.

The required precision has O(m+log(1/eta)+log Q_up+log Kmax+B) bits, with fixed physical constants. Local-basis-to-physical-factor errors and algebraic coefficient/output errors need separate budgets; the principal explicitly adds the O(m log C_mu) cost. Whole-block rational Cayley inverses have fixed dimension, so input arithmetic remains polynomial. There is no exact-rational-closure claim or minimum coefficient/spectral-gap oracle.

## 4. Reset-SWAP-and-KEEP buffer: exact operation

A nonunital reset is not mixed unitary on the physical qubit. Its Euler factor is the convex mixture (1-gamma h)Id+gamma h R_sigma. Conditional on a reset, draw a fresh basis ancilla |a> with probabilities p and1-p, SWAP with the physical register, and KEEP the old register at the SAME spatial site. Trace all old registers only at the end. This exactly realizes the physical reset after averaging. Initial purification coordinates and all sampled ancillas start in a product vector for each fixed digital history.

Keeping old registers makes the full reference trajectory unitary. A local SWAP is on one side of every spatial cut and exactly preserves the Schmidt nuclear norm. In a frame of these local permutations, H_b acts on different internal registers but on the same spatial set, with unchanged norm. Each term still acts on <=k qubits and has a Pauli coefficient one-norm <=2^k J. This Pauli decomposition is used only in the directly error-paid BUFFER channel, where reference invariance of every finite approximation is unnecessary.

Factorial spatial locality is dimension independent. Group all internal registers at their fixed spatial site; local permutations cannot spread an observable to another site. The toggled Hamiltonian still has bounded spatial range and incidence, so the linked time integrals and spatial crossing count do not depend on how many old registers have accumulated. Across a strip-row cut, log B_star=O_k(ad b_strip JT_buffer) as claimed. Forward and reversed trajectories have the same paid constant-factor action.

The normalized retained F product is Hermitian and a product contraction. Its conjugated strip factors commute before localization. The two parity vector overlap equals the product mean even though factors are not involutions. Localized factors are contractions with disjoint supports within each parity, so all telescoping and nuclear-norm bounds remain valid.

Both parity vectors MUST use the same sampled reset/thermal history and common labels for every retained ancilla. Independent histories on the two sides would not give the desired overlap. One first samples a full spatial history on the retained region, then restricts that history consistently to the different strips; this is the natural unitary-trajectory construction in the principal file.

## 5. Row-count cap and confidence accounting

A strip-row segment has O(b_strip) physical sites. Its reset count is a sum of independent Bernoulli variables over those sites and all numerical steps, with mean <=C b_strip gamma s. Chernoff bounds depend on this mean, not on the number of infinitesimal steps. There are at most C m nonempty strip-row segments across the two parities (each physical site lies in only constantly many enlarged strips). A union bound therefore permits cap

    C'[b_strip gamma s+log(Cm/eta_hist)].

The count is monotone in time, so bounding its final value bounds intermediate dimensions too. At s=O(log log Q)/gamma and b_strip=O(log Q/log log Q), this is O(log Q). A row including physical, purification and every old qubit then has dimension 2^{O(b_strip+cap)}=Q^{O(1)}. Total gate count is polynomial; histories can be checked before large tensors are built.

Set a normalized buffer's eta_hist=xi/100, independent of requested confidence delta. Return bounded zero on histories exceeding the cap; their contribution to expectation bias is <=eta_hist. There is no rejection loop and no need for every Monte Carlo repetition to obey the cap. Hoeffding alone handles confidence digits. Choosing the cap failure probability proportional to an exponentially small requested delta instead would incorrectly make row dimension depend polynomially on delta^-1. This distinction is now explicit in the principal file.

The original constructive Schmidt truncation and bounded symmetrized overlap sampler therefore apply, with polynomial row dimensions/ranks and paid dyadic precision. Multiplying the normalized answer by C_mu^r is charged in the accuracy and outer coefficient one-norm. This is the missing positive buffer operation; it does not assume a nonexistent mixed-unitary biased channel or sum divergent sqrt(h) dilation angles.

## 6. Conservation, invariant state and nonunital boundary

For biased p!=1/2, sigma^tensor k is proportional to exp(c sum_i Z_i), with distinct eigenvalues for different total excitations. Therefore commuting with that reference is equivalent to excitation-number conservation on EACH block. Exchange XX+YY, diagonal interactions and their noncommuting sums are permitted; generic work-driving gates are not. At p=1/2 conservation is vacuous and the model returns to the unital case.

The invariant state is sigma^n, regardless of allowed interactions. It is generally NOT exp(-beta H)/Z. Calling this a Gibbs-state algorithm for the interacting H would be false. The specified local resets are known Markovian channels, not a learned unknown reservoir or an automatically valid Davies approximation. Pure reset mu=0 is excluded; constants and exponents may diverge as mu->0, and similarly as gamma/J->0. No model-uniform polynomial across either limit is established.

Relative entropy contraction follows correctly from reference conservation, convexity and quantum Shearer. D(R_i^sigma rho||sigma^n)=D(rho_-i||sigma^(n-1)); the local energy terms cancel in the sum. D initially is <=n log(mu^-1), so the long-horizon branch is paid before dense dynamics. Local truncation retains whole conserving blocks and all resets; it does not create a different boundary bath. This preserves the reference needed by the weighted sparse stage.

The construction does not contradict nonunital fault-tolerance/refrigerator results: their unrestricted gates can use bath polarization as a resource, whereas every permitted block here preserves the common product reference and cannot perform that operation. Local reset histories are internally simulated, not observed in the target experiment.

## 7. Exact comparator and novelty audit

- Dong et al2606.17729v1 Theorem1.1 is the direct all-operator hypercontractivity import, with the exact convention verified in Section1. The generalized-depolarizing statement is enough; no general claim about arbitrary KMS-symmetric generators is imported. https://arxiv.org/html/2606.17729v1
- Beigi–Datta–Rouze1804.10100v2 Theorems21 and25 already prove the qubit tensorization/constant underpinning this weighted relaxation theory. Entropy contraction, weighted norms and hypercontractivity must not be renamed new mechanisms. https://arxiv.org/html/1804.10100v2
- Angrisani et al2609.40174v2 provides the sparse coefficient architecture for Pauli-diagonal noise. The reference-centered KMS coefficient construction here changes the basis/model; its hypotheses are verified above rather than pretending biased reset is Pauli-diagonal in ordinary Paulis. https://arxiv.org/html/2609.40174v2
- Martinez et al2501.13050v1 Theorem1 is a strong nonunital Pauli-backpropagation predecessor. Its Delta metric is L2 averaged over rotation parameters, explicitly equation(14); algorithmic Monte Carlo confidence does not convert that parameter-average error into a worst-case specified-angle guarantee. It therefore does not already prove this continuous-time specified-input/common-reference theorem. https://arxiv.org/html/2501.13050v1
- Angrisani–Mele–Rudolph–Cerezo–Holmes2501.13101v2 Theorem1 permits arbitrary local nonunital noise but independently sampled layers invariant under local unitary1-designs. Its probability is over circuit randomness. It is a different and broader noise class with a substantial ensemble restriction; it does not cover each deterministic conserving H(t) here. https://arxiv.org/html/2501.13101v2
- Trivedi–Cirac2110.10638v2 Theorem1 already gives stronger total-variation sampling under sufficiently HIGH entanglement-breaking-noise rate, including biased replacement. Its interaction class is broader, but its threshold does not give the all-fixed-positive-ratio prediction claim. https://arxiv.org/html/2110.10638v2
- Shtanko–Sharma2411.04819 Theorem1 warns against a general arbitrary-gate nonunital easiness theorem. It does not impose this per-block reference conservation. https://arxiv.org/abs/2411.04819

Primary searches checked generalized depolarization with classical simulation, biased resets with deterministic conserving Hamiltonians, product invariant references and nonunital Pauli propagation. No exact incumbent with all the present deterministic continuous-time quantifiers was located. This bounded literature check is not proof of first priority. Existing noise unravellings, Stinespring dilations, weighted coefficient interpolation, hypercontractivity and the original BGM-derived strip constructor retain credit. The added closure is their KMS sparse integration with the reset-register row-count buffer and paid nonunitary basis norms.

## 8. Formal review accounting and conclusion

Checks are analytic: exact primary theorem statements/conventions, explicit Gram calculations, generator norm comparisons, rate allocation, local algebraic representation, tensor trajectory identity, factorial spatial locality, nuclear growth and Chernoff dimension control. No new numerical diagnostic was needed to replace these proofs; no full implementation was run. The reference-scope and no-full-sampling limits are substantive, not generic caveats.

With the corrected rounding budget and accuracy-based history cap retained, this review accepts the biased-reset fixed-reference local-prediction theorem as a complete extension of the inspected original construction. Its nonunital scope is strictly stronger than merely reporting a perturbation floor, while remaining narrower than arbitrary cooling dynamics. Earlier global-Hermitian-product and bounded-cut sampler results remain separate claims.
