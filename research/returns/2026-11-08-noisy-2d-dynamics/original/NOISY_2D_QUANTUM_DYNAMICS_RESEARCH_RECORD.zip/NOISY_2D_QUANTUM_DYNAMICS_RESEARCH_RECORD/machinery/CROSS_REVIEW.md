# Cross-review: learned local service, stability and sampling frontier

8 November2026. Reviewed after all four initials were frozen and exchange authorized: initial/constructor.md, initial/auditor.md, principal/LOCAL_ROBUST_PREDICTION.md, principal/PAID_ACQUISITION_PREPARATION.md and the named primary-source versions. Frozen initial bytes are unchanged. My formal global-readout result is FINAL_GLOBAL_READOUT_THEOREM.md.

## 1. Principal local relaxation and stability: verdict

Sections2–5 check at their stated fixed-local scope, conditional on the explicitly stated locality estimate with valid fixed constants. They prove neither volume-independent global trace mixing nor arbitrary-accuracy nonunital simulation.

Entropy signs and normalization are correct: the Hamiltonian derivative of D(rho||I/2^m) vanishes; convexity and quantum Shearer give D'<=-gamma D. Pinsker gives sqrt(2m log2)exp(-gamma t/2). Regularization covers singular sources. Time-dependent H does not change the argument.

R(x)=ceil(r0+r1 x) makes the locality error <=exp(-2x). Restricted entropy mixing holds for every reduced source, so duality genuinely gives operator-norm local relaxation. The displayed A is conservative for w>=1. The local long-time cutoff and O(log^2(1/epsilon)) retained volume follow, with paid input scanning/indexing as stated.

B_z(I)=0 is the Heisenberg trace-preserving condition and allows Schrödinger nonunital errors. Support-disjoint observables are annihilated by B_z, justifying the near/far split. Near counts contribute (1+x)^2 and relaxation contributes (1+x)exp(-x/2); the integral is exactly158. In the far sum, r0 absorbs the locality prefactor K; the geometric shells remain summable uniformly in volume. Duhamel correctly has the PERTURBED evolution outside and the REFERENCE future observable next to B_z. Only physicality of the total perturbed evolution is needed for the outer contraction. K_stab eta/gamma is therefore valid and can be vacuous when eta is large.

The product-preparation bound also checks: telescope sources, subtract E_i Phi(O) for each single-site difference, and sum the same near/far estimates without integrating time. The maxima216 and1 are loose upper bounds. This requires independent product preparation, not knowledge of one-site marginals of a correlated error.

The schedule implementation correctly sparsifies the later interval and smooths with the early interval. No inverse shortest switch length enters. My formal theorem makes support and action dependencies explicit instead of relying on a fixed-support giant envelope.

## 2. Acquisition and reusable service: checked identities and refinements

For dictionary P choose one-site Q anticommuting with it and R=iPQ, including sign. R is Hermitian, has support within P, and i[P,Q]=2R. With no duplicate dictionary strings,

    tau(RGQ)=2h_P, tau(RQ)=0.

Replacement contributes only Q and does not contaminate that coefficient. Signed independent noisy eigenstate averaging yields (product p_i)R/2^n, and affine measurement correction is unbiased with score bound 2/(c0 p0^k). Unknown SPAM is not removed by repetition; known or paid calibration is required.

The Taylor constant is correct: coefficient one-norm of GQ is <=Gamma, each resulting Pauli has support<=k, and coefficient one-norm of G²Q is <=k Gamma². Semigroup contraction bounds the integral Taylor remainder by k Gamma² t²/2. The displayed Hoeffding count has ample slack.

Two formal refinements are useful:

- Specify t=min(1/(4Gamma),alpha/(4C2)), or a rational within a fixed factor below it. Merely saying any t<=the bound permits unnecessarily tiny times and does not itself upper-bound shot cost polynomially.
- Keep the learned drift clipped to its permitted coefficient intervals. Then known controls plus learned drift have a certified total local-strength/degree bound. Uniform stability constants can use the learned unital dynamics as reference. The simultaneous coefficient event then controls all permitted future controls and sources; summable numerical failure budgets also cover adaptive classical query selection.

With these specifications, the complete uncertainty statement is justified under the declared experimental contract. It is an accuracy-floor service for local model discrepancy, not an arbitrary-accuracy nonunital simulator.

### Paid acquisition preparation

PAID_ACQUISITION_PREPARATION.md checks. Under reset-only evolution, the event every site has reset removes all initial correlations; union coupling gives trace error <=2n exp(-kappa tau). CPTP Duhamel against the always-on drift/noise gives n Gamma tau. The rational choices tau=b/(4n Gamma), kappa=L/tau and L>=ceil(log2(16n/b)) give at most b/8+b/4=3b/8<b/2.

Expected fresh-ancilla swaps are nL; a Poisson tail gives a finite high-confidence cap O(nL+log(1/delta_prep)). Crucially, kappa scales as n Gamma log(n/b)/b and the total instantaneous rate is n kappa. These growing controls, independent calibrated ancillas, rotations and delivery costs must remain part of the acquisition contract. This is not fixed-hardware product preparation, a proof that a named thermal bath realizes Markovian resets, or a permission to add cooling to future prediction queries. Outside the probe support the required I/2 state can be supplied directly or by independently randomizing the known opposite noisy preparations.

## 3. Exact learning and stability predecessors

**Möbus–Bergamaschi–França–Rouzé, Robust Structure Learning of k-local Lindbladians,2606.23652v1:** checked Theorem4.5, supplied-support refinement, Assumption8.1, Theorem8.2 and Corollary8.3. Theorem4.5 fixes locality and weighted strength and learns h/G entrywise to eps_chi with sample complexity tilde-O_k(eps_chi^-2 n^{2k}log(1/delta)). Supplied influential support satisfying Cor3.8 gives tilde-O_k(D_Omega² eps_chi^-2 log(|Omega|/delta)). Theorem8.2 already learns valid buffered interior generators predicting a fixed local mean; Cor8.3 shares data for all constant-local marginals. They do not pay a generally polynomial classical evaluation of a two-dimensional m=Theta(log²(1/eps)) model. That evaluation is the original predictor's distinct operation here. https://arxiv.org/html/2606.23652v1

**Lucia–Cubitt–Michalakis–Pérez-García, Rapid mixing renders quantum dissipative systems stable,1409.7809v2 Theorem1:** a local rapidly mixing autonomous Liouvillian with unique fixed point has local-observable/correlation stability <=C_X eps uniformly in time/size under local cb-norm perturbations. Its presented setting is translation-invariant nearest-neighbour periodic lattices, with generalizations discussed. Principal Section4 supplies a direct explicit nonautonomous application of this established mechanism. The source theorem itself should not be quoted as a theorem about arbitrary controls. https://arxiv.org/html/1409.7809v2

Thus the service combines the original all-rate specified-input numerical evaluator, paid finite model acquisition and uniform error transport. Local learning, learned-local prediction and rapid-mixing stability are prior capital, not discoveries of this campaign.

## 4. Tensor-network comparison: HS, trace and construction

**Shao–Zhao–Cheng–Liu2606.00474v1:** checked Theorem1, Proposition1/AppendixD.3 Proposition4, equations(5),(6), and AppendixF. Proposition1 fixes per-layer depolarization lambda, a one-dimensional circuit, a prescribed cut and FIXED relative HS error, obtaining ||rho_l-rhohat_l||_2²<=eps||rho_l||_2² with polynomial bond across that cut. Entropy-to-rank exponents contain inverse error; polynomial for fixed eps is not uniform poly(n,1/eps). Equation(255) chooses a BEST HS MPO approximation, so existence of that optimizer must not be silently promoted to an efficient global optimization algorithm. The prescribed-cut and average higher-dimensional boundary-bond statements alone do not construct and contract an efficient global2D sampler.

Do not dismiss this result merely as HS incapable of trace control. At its late crossover, equation(243) gives ||rho_l||_2²<=A2^-n. Relative HS then implies

    ||rho_l-rhohat_l||_1<=2^(n/2)||rho_l-rhohat_l||_2
                         <=sqrt(A eps).

This late-time implication is valid. Remaining limitations are inverse-error rank/cost, compatible constructive compression across all cuts, physicality or a paid sampling conversion, and fixed-lambda discretization. Before that crossover, fixed absolute HS error has no dimension-free trace consequence.

For continuous step h, lambda=1-exp(-gamma h), and L_star=O(lambda^-1 log n) makes the exact early-circuit bond exponent diverge as h->0. This is not a physical-angle continuous-time transfer. Higher-dimensional average PEPO boundary bonds do not imply polynomial contraction. The constructor's bounded-cut TV sampler therefore uses a distinct constructive route with paid trace error. https://arxiv.org/html/2606.00474v1

**Wei et al2603.20400v1** is another relevant incumbent: its 1D Ising Lindbladian MPO/trace-error and sampling conclusions are explicitly empirical/conjectural. Its title does not supply a worst-case continuous-time TV theorem. https://arxiv.org/html/2603.20400v1

## 5. Unchanged2D continuous-time full sampling: precise frontier

The strongest verified general continuous-time sampler remains Trivedi–Cirac2110.10638v2 Theorem1 above its high entanglement-breaking-noise threshold. Nelson et al2610.00548v2 Theorem2.3 gives a stronger low-noise DISCRETE circuit log-marginal FPTAS/sampler after constant rate-dependent depth. Its exact finite-cone hypotheses disappear under infinitesimal time discretization. Substituting p~gamma h requires physical gamma T>=c log(1/h), divergent at fixed T.

Our all-support product theorem remains additive. Exponentially small prefix probabilities cannot be conditioned on at polynomial inverse accuracy. Its weight-smoothing lemma is also insufficient for the NR polymer argument: a block operator contains exponentially many Pauli terms, and a fixed theta suppression does not overcome its full block-volume norm. NR's middle contraction phase uses persistent minimum intermediate weight proportional to the number of separated active blocks. Soft cones do not give that exact invariant.

A decisive replacement must provide a physical-time soft-cone polymer model with a Kotecky–Preiss bound and paid relative/log-marginal accuracy; or a continuous minimum-weight/leakage bound exponentially small in the NUMBER of active blocks; or another positivity-preserving conditional interface with a finite-bit TV proof. A uniform additive locality error is insufficient for this operation.

A concrete constructive attack is a connected-cumulant expansion of the output diagonal law. It needs a tree-summable multi-point coefficient estimate whose amplitude decreases with gamma T and whose spatial tails are factorial. Pairwise locality and local relaxation do not prove it: partition counting can introduce factorial growth and destroy convergence. No such many-body estimate was proved here. This is an exact applicability gap, not a hardness theorem for replacement-only sampling.

## 6. Weak nonunital perturbations

The toy reset equation z'=kappa-(gamma+kappa)z disproves uniform-to-maximally-mixed convergence, not classical simulability. The principal's perturbation inequality only supplies accuracy above K_stab eta/gamma.

One possible arbitrary-accuracy route is a convergent local response expansion around the unital reference. A naive localized Duhamel sum costs exp(O(eta mT)), with m=O(log²(1/eps)) and T=O(log(1/eps)), which is too large at fixed eta. A real improvement must control and sample connected perturbation histories by a volume-independent subcritical branching norm, and compute signed multitime responses with paid precision. The first-order stability inequality alone does neither. This operation was not completed.

Shtanko–Sharma2411.04819 Theorem1 proves universal noisy local computation with nonunital resources when total noise is below a threshold DEPENDING on fixed-point polarization. It does not prove hardness for arbitrarily tiny nonunital perturbation at a FIXED gamma/J; the admissible noise threshold changes as polarization vanishes. It constrains a prospective theorem but leaves the sufficiently weak perturbation/fixed-ratio regime open. No arbitrary-accuracy algorithm for that regime is claimed.

## 7. Recent Zenodo and source records

Exact-identifier Zenodo searches for2606.00474,2603.20400,2606.23652 and2610.00548 returned no extra matching primary theorem. The nearest primary frame-simulation deposit located is record19206525 (24March2026), linked to Denzler et al2601.05131v1. The auditor's retained primary API search located23418780 and23414157, describing a fixed-depth numerical notebook and channel-fingerprint artifact; their metadata supply no uniform continuous-time worst-case TV theorem. These deposits are not imported as proof, and this bounded search does not establish absence or priority.

Primary HTML/text caches for2606.23652v1,1409.7809v2 and2606.00474v1 are in sources/literature/machinery/. SOURCE_MANIFEST.json records their hashes. The governing report and frozen machinery initial hashes remain unchanged. The only finite execution in this branch is the retained weight-smoothing diagnostic. General algorithms are costed mathematical constructions, not worst-case implementations.

## 8. Verdict

The principal's calibrated local learned service composes correctly at its declared scope; exact time choice and growing-strength reset preparation should remain explicit. Its learning/stability mechanisms have strong predecessors. This branch's strongest unchanged2D extension is all-time global HERMITIAN product-readout prediction, with explicit schedule, rate-floor, correlated-Pauli and shallow-preparation scopes. The constructor obtains a stronger output task on a changed bounded-cut architecture. General2D all-rate continuous-time full sampling and arbitrary-accuracy weak-nonunital prediction remain open with concrete missing operations.
