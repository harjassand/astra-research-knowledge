# Biased resets preserving a faithful product reference

Principal follow-up, 8 November 2026. NEW claim for independent review. It does
not settle arbitrary weak cooling of arbitrary Hamiltonians.

Fix a,k,d,w,J/gamma and rational sigma=diag(p,1-p), mu=min(p,1-p)>0. Supply a
finite rational piecewise 2D Hamiltonian H(t)=sum_b H_b(t), each Hermitian block
having support <=k, range <=a, norm <=J, incidence <=d, and
[H_b(t),sigma^(tensor supp b)]=0 for EVERY block and segment. The generator is

    L_t(rho)=-i[H(t),rho]+gamma sum_i(R_i^sigma(rho)-rho),
    R_i^sigma(rho)=sigma_i tensor Tr_i rho.

Claim: specified rational product inputs and fixed-local Hermitian ||O||<=1 admit
randomized polynomial bit-work additive prediction at every fixed gamma/J>0 and
fixed mu>0; binary T, complete controls, inverse accuracy and confidence digits
are paid. No arbitrary global product-readout extension is claimed here.

For equal biased qubits the block restriction is excitation-number conservation.
Strong spin-exchange and diagonal interactions are permitted. The invariant
state is PRODUCT sigma^n, not generally the Gibbs state of the full interacting
H. This is a common-reference local-reset model, not an arbitrary Davies bath,
work-driving Hamiltonian, pure reset, or physically acquired unknown reservoir.

## Mixing and imported weighted hypercontractivity

The Hamiltonian contribution to dD(rho||sigma^n)/dt vanishes. Convexity and
quantum Shearer give sum_i[D(rho||sigma^n)-D(R_i^sigma rho||sigma^n)]>=D(rho||sigma^n).
Thus D(rho_t||sigma^n)<=n log(mu^-1)exp(-gamma t), and Pinsker gives the trace
bound sqrt(2n log(mu^-1))exp(-gamma t/2). After gamma T>=C_mu log(n/epsilon)
return the known reference mean. Otherwise JT=O(log(n/epsilon)); ordinary local
Lindblad truncation retains m=O(log^2(n/epsilon)) sites. Restricted blocks keep
the same faithful reference and resets.

Use ||A||_(q,sigma^m)=||(sigma^m)^(1/(2q)) A (sigma^m)^(1/(2q))||_q.
Exact import: Dong--Gao--Ou--Yao--Zhou2606.17729v1 Theorem1.1 gives tensorized
generalized-depolarizing p-to-q hypercontractivity at
t=[3log2/(8a_sigma)]log((q-1)/(p-1)), a_sigma=(1-2mu)/log(mu^-1-1), with its
positive limit at mu=1/2. Their earlier exact-qubit credit to Beigi--Datta--Rouze
must be retained. This applies to all operators, not just PSD ones.

Block conjugations commute with sigma and are isometries at EVERY weighted
exponent. Interleaving therefore proves actual-channel 2-to-q contractivity
for q-1<=exp(c_sigma gamma s), c_sigma=8a_sigma/(3log2). Since
||A||infty<=mu^(-m/q)||A||_(q,sigma^m), choose q>=C_mu m and
s=O_mu(log(2m)/gamma). Weighted-HS error is then converted to at most twice
that error. The early buffer acts on a later observable approximation; it is
not commuted through the drive. Its duration is O(log log(n/epsilon))/gamma.

## Weighted sparse engine, including the norm of retained basis products

Put z=2p-1. A Hermitian orthonormal basis for symmetric weighted two-norm is
F0=I; F1=X/(2sqrt(p(1-p)))^(1/2); F2=Y/(2sqrt(p(1-p)))^(1/2);
F3=(Z-zI)/(2sqrt(p(1-p))). Nonidentity Fj have zero sigma expectation.
Products are orthonormal, and reset acts as -gamma W, W counting nonidentity.
A commuting Hamiltonian block is skew-adjoint in this Hilbert metric, fixes
identity and preserves its orthogonal complement. Its two-norm is <=2J; local
coefficient dimension 4^k gives one-norm growth <=exp(C_k Jt), C_k fixed.
Allocate gamma/d to each incident block site. Active-sector damping and
interpolation give a fixed coefficient p_c<2 and sparse pruning with <=4^k
branches per input basis element.

Use a rational matrix Cayley unitary for each WHOLE commuting block, followed
by positive Euler resets. This preserves the reference exactly; its near-identity
logarithm has norm O(Jh), giving the same estimates with larger fixed C_k.
Local rational inverses have fixed dimension. Individual physical Pauli terms
need not preserve sigma and are NOT used separately in this sparse engine.

Also track exp(theta W) coefficient two-norm. A local skew matrix connects
weights differing by <=k, and its tilted symmetric-part row sum is bounded by
C'_k J sinh(k theta). Choosing theta<=min(1/(2k),gamma/[16d k C'_k J]) makes
allocated damping absorb it. Pruning decreases both norms. The initial fixed-
support O has constant budgets M0,Mtheta. Every retained |b|>=tau obeys
exp(theta r)|b|<=2Mtheta, hence r<=theta^-1 log(2Mtheta/tau)=O(log Q).

Fj are NOT unitaries. Their operator norms are bounded by C_mu, so the retained
product norms C_mu^r are polynomial and must be paid in buffer accuracy and
estimator bounds. The sum sum_j |b_j|C_mu^(r_j) is polynomial.

Basis entries are fixed-degree computable algebraic numbers. Use certified
dyadic updates, not claimed exact rational closure. With a predeclared polynomial
Kmax, per-update rounding nu satisfying Q_up Kmax nu<=min(eta,M0,Mtheta)
exp(-theta m)/100 keeps both budgets within a constant factor. This needs
O(m+log Q_up+log Kmax+input bits) precision bits. Choose pruning and Kmax with
the doubled budgets in advance, avoiding a circular norm/rank promise.
Here eta is the allocated weighted-HS error. Also pay the finite precision in
the algebraic basis transformation, e.g. through an extra O(m log C_mu) bits,
so its represented weighted-HS error fits eta as well.

## Construct the nonunital buffer by retaining local reset registers

A biased reset is NOT random unitary on the physical qubit. In its Euler mixture
sample a reset event with probability gamma h. At each event sample an ancilla
|a> with probabilities p,1-p, SWAP it with the physical qubit, and KEEP the old
register as a coordinate at that same spatial site. Averaging gives the biased
replacement EXACTLY. These sampled pure ancillas are an INTERNAL numerical
ensemble, not physical access to bath outcomes or pure ancillas in the target
experiment. Initial product inputs use their usual local purifications.
Draw ONE shared reset history, thermal-bit list and register labeling per outer
sample for both parity states. Reverse the same finite strip unitary exactly
for U_B^dagger; never draw fresh thermal bits or reset events for that inverse.

Each enlarged trajectory is unitary. Local SWAPs have zero spatial crossing
action. In their toggling frame H_b acts on different internal registers but
keeps its spatial support, norm and a fixed-size Pauli expansion. Only in the
BUFFER reference, decompose H_b into physical Pauli terms, with coefficient
one-norm <=2^k J. Finite-step reference invariance is not needed there: its
channel/operator error is directly paid. The sparse engine above used whole
commuting blocks. Factorial spatial locality is independent of the number of
internal registers and local swaps.

Normalize each retained Fj product by its paid norm C_mu^r. It is now a
Hermitian product contraction. For a unitary trajectory U the Q_j=U^dagger
O_j U commute; the overlap <Q_even psi,Q_odd psi> equals their product mean.
The Q_j need not square to identity. Localized parity factors remain contractions
on disjoint same-parity strips. On-site insertions contract vector norms and
cross-cut Schmidt nuclear norms.

Each nonempty strip row has <=C b_strip spatial sites. Its reset count is a sum
of independent Bernoulli variables with mean <=C b_strip gamma s. A Chernoff
bound, uniform in time-step count, implies that simultaneously over <=C m
nonempty rows, with failure <=delta_hist, each count is at most

    C'[b_strip gamma s+log(Cm/delta_hist)].                 (4)

Choose a deterministic cap using (4), and return zero on numerical histories
exceeding it. Normalized mean bias is <=delta_hist. There is no rejection loop.
Set delta_hist=xi/100, where xi is the normalized buffer accuracy, independent
of Monte Carlo confidence delta. The cap is a bias budget for each sample, not
a union-bound demand that all repeated histories avoid it. Thus row dimension
depends polynomially on inverse accuracy and only indirectly logarithmically
on confidence through repetition counts, preserving confidence-digit complexity.
At s=O_mu(log log Q)/gamma and factorial width b_strip=O(log Q/log log Q),
the cap is O_mu,g(log Q). A row's Hilbert dimension including ALL kept ancillas
is therefore 2^O(b_strip+cap)=Q^O(1).

The exact-reference Schmidt nuclear norm obeys Bstar<=exp(C_k b_strip J s),
again polynomial. The original iterative MPS truncation lemma, finite-bit
canonicalization and bounded symmetrized overlap sampler apply with polynomial
row dimensions, ranks, gate counts and precision. Divide delta_hist and buffer
errors by the polynomial retained weighted one-norm and C_mu^r factors. All
coins are finite rational Bernoulli/thermal choices; all schedule lengths,
random bits, input purifications and arithmetic are charged.

This supplies the missing positive-buffer representation rather than assuming
mixed-unitary biased noise or using a divergent sum of sqrt(h) couplings.

## Limits and independent challenges

Check exact weighted HC, basis normalization, skew/tilted block inequalities,
predeclared rounding budgets, contraction parity identity, internal-register
locality and Bernoulli cap bias before accepting the theorem. The general
algorithm has not been run. New candidate bridge: weighted sparse propagation
plus the reset-register buffer. Existing generalized hypercontractivity,
coefficient interpolation, entropy decay and the original strip proof retain
credit. No practical advantage, pure reset, unknown bath acquisition, arbitrary
work controls, generic interacting Gibbs solver, or original2D full sampler
follows. A common faithful reference and per-block conservation are substantive.
