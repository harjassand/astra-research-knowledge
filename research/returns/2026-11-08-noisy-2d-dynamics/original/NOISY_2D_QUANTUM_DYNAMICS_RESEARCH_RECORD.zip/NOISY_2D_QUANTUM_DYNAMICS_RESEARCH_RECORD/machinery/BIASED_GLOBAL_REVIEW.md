# Review: global Hermitian readouts under faithful biased resets

8 November2026. Independent mathematical review of principal/BIASED_GLOBAL_READOUT_CLOSURE.md, using the corrected component construction reviewed in BIASED_RESET_REVIEW.md. Current source snapshots and hashes are recorded in BIASED_GLOBAL_REVIEW_PINS.json. No earlier initial or result file is edited by this review.

## 1. Verdict and precise scope

The new global closure is valid. It upgrades the earlier fixed-local biased-reset result to arbitrary global tensor products of one-qubit Hermitian contractions. It reuses the reviewed weighted sparse engine and reset-SWAP-register short-buffer constructor, but the support-sensitive smoothing step is genuinely additional: ordinary traceless Bloch factors are not centered in the biased reference, and their identity components must be bounded rather than dropped.

The accepted contract is: fixed interaction range, support size and instantaneous block incidence; a supplied finite rational piecewise schedule of Hermitian local blocks with norm<=J; EACH block commuting with the corresponding restriction of sigma^n; fixed positive gamma/J; known rational sigma=diag(p,1-p) with mu=min(p,1-p)>=fixed nu0>0; supplied rational product input; arbitrary global Hermitian product contraction readout; additive epsilon error with confidence1-delta in randomized polynomial bit work, including all input/schedule bits, explicit n, epsilon^-1 and confidence digits. No degree is uniform as gamma/J or mu tends to zero.

The theorem gives neither relative rare probabilities nor whole-output sampling. It does not concern arbitrary nonunital perturbations, unrestricted work drives, unknown baths, pure resets, arbitrary succinct correlated inputs, or Gibbs states of the interacting H. Arbitrary complex product contractions require a separately paid LCU norm and are not covered silently.

## 2. Exact two-sided moving-weight smoothing

Let the coefficient Hilbert space be L2(sigma^m) in the tensor KMS-orthonormal F basis of BIASED_RESET_REVIEW.md, and W count nonidentity F factors. Write S for the actual Heisenberg propagator over any interval of duration u with its real schedule order. Let theta<=1/2 satisfy the reviewed tilted coefficient-dissipation inequality, and alpha(u)=min(gamma u/2,theta).

Reserve half the reset noise. The instantaneous coefficient generator of every reference-conserving Hamiltonian block is real skew-adjoint, and the reset generator is -gamma W. The half-noise tilted estimate makes the Hermitian part of exp(alpha W)G_half exp(-alpha W) nonpositive. The derivative term alpha'W is absorbed by the reserved half-noise. The variable-H proof holds segmentwise and joins continuously, giving

    ||exp(alpha W)S||_(2,sigma->2,sigma)<=1.

A biased reset is KMS self-adjoint: its local Heisenberg map A->Tr(sigma A)I is the orthogonal projection onto I. The KMS adjoint of a conserving Hamiltonian commutator reverses H's sign. Taking the adjoint of the reversed-sign reversed schedule gives

    ||S exp(alpha W)||_(2,sigma->2,sigma)<=1.

Hence for EVERY X,

    ||SX||_(2,sigma)<=||exp(-alpha W)X||_(2,sigma).       (1)

No homogeneous F-weight assumption is required for (1). The sign-reversed schedule remains admissible and preserves exactly the same reference. This is the correct extension of the earlier unital duality, not a Hilbert–Schmidt adjoint taken in the wrong metric.

## 3. Ordinary traceless factors: the identity component is controlled

For A=n_x X+n_y Y+n_z Z with a real unit Bloch vector, put z=2p-1 and a=Tr(sigma A)=z n_z. Direct KMS calculation gives

    ||A||_(2,sigma)^2=n_z^2+2sqrt(p(1-p))(n_x^2+n_y^2)<=1,
    |a|<=|z|.

Decompose A=aI+B orthogonally in KMS L2. The identity component is generally NONZERO. Because exp(-alpha W_i) fixes aI and multiplies B by exp(-alpha),

    ||exp(-alpha W_i)A||_(2,sigma)^2
       =a²+exp(-2alpha)(||A||_(2,sigma)^2-a²)
       <=z²+(1-z²)exp(-2alpha).

For 0<=alpha<=1/2, 1-exp(-2alpha)>=alpha. Also 1-z²=4mu(1-mu)>=2mu. Therefore

    z²+(1-z²)exp(-2alpha)
       <=1-2mu alpha<=exp(-2mu alpha).                  (2)

Tensor norms are multiplicative, W=sum_i W_i, and identity factors have weighted norm1. Thus a product P of r ORDINARY traceless Bloch unitaries satisfies, by (1)–(2),

    ||SP||_(2,sigma^m)<=exp(-mu alpha(u)r).              (3)

The factor mu is necessary for this proof and cannot be silently replaced by the unital coefficient-weight estimate. The limit alpha=0 gives no damping, as required at T=0. At long times the reference mean is nonzero but bounded by |z|^r, consistent with (3).

This verifies the principal's pivotal inequality exactly. It does not rely on the false sigma-centered bounded-mixture shortcut.

## 4. Support-sensitive weighted hypercontractivity

The primary weighted HC import is Dong et al2606.17729v1 Theorem1.1 for EVERY operator, with the KMS sandwich norm; source pins and older exact-qubit Beigi–Datta–Rouze credit are in BIASED_RESET_REVIEW.md. The arbitrary-error-operator convention is unchanged.

Let lambda=mu theta and t0=2theta/gamma. Localize P with norm error eta to m sites. In the EARLY interval choose q>=max(2,4m log(mu^-1)/(lambda r)). Weighted norm comparison then gives

    ||Phi_(0,s)Y||_infty<=mu^(-m/q)||Y||_(2,sigma)
                          <=exp(lambda r/4)||Y||_(2,sigma).

If T>=s+t0, apply (3) to the LATER interval [s,T], where alpha=theta. Therefore

    ||Phi_(0,T)P||_infty<=eta+exp(-3lambda r/4).         (4)

Nothing is commuted through a nonautonomous drive. Sparse approximation and damping act on the later observable; actual early-channel HC acts afterward in the Heisenberg composition.

A rational schedule avoids special-function input. For known rational nu0<=mu choose

    b=max(1,ceil(log2(8m/(nu0² theta r)))),
    s=b/(nu0 gamma), q=1+exp(b).

The conservative HC exponent nu0 is valid because a_sigma>=mu>=nu0. The resulting q is at least8m/(nu0² theta r), and m log(mu^-1)/q<=lambda r/4. Consequently gamma s=O_(nu0,theta)(1+log(m/r)). Integer comparisons with powers of2 suffice to choose b. This also provides an entirely rational implementation of the principal's q-selection instruction.

Spatial locality can be derived either from bounded local Lindbladian estimates or from the finite reset-SWAP dilation grouped by spatial site. In the latter frame, local swaps do not spread support, and the Hamiltonian acts on different internal registers with unchanged spatial range, norm and incidence. The linked-interaction tail is dimension independent. Its constants survive the finite-step limit, so

    m<=min(n,C r[1+JT+log((r+1)/eta)]²)

is legitimate with physical-class constants. The cap used for computation is not needed to establish that analytic bound.

## 5. Cost closure: all three branches

Put L=ceil(log2 Q), where Q pays complete binary input, explicit n, epsilon^-1 and confidence digits. First use the biased entropy cutoff gamma T>=C_nu0 L, returning the known reference mean. In all remaining cases JT=O_g,nu0(L). With eta a fixed fraction of the subroutine error, localization gives m/r<=C L² and therefore s+t0=O_(nu0,g)(1+log L)/gamma.

**Large support and enough time.** If r>=C/(mu theta)log(1/epsilon) and T>=s+t0, return zero. Equation(4), including locality error, justifies it. Replacing mu by the known floor nu0 only enlarges this threshold conservatively.

**Early physical time, arbitrary support.** If T<s+t0, run the GLOBAL reset-register short buffer on m possibly equal to n. Its factorial width is b_strip=O(L/log L); gamma T=O(log L), so the per-row reset mean and deterministic accuracy-based cap are O(L). A row's dimension is exp(O(L)), and spatial crossing action is O(b_strip JT)=O(L). The constructive rank and finite-precision parameters are polynomial. Global physical support does not enter an undisclosed exponent.

**Remaining low physical support.** Now r=O_(mu,theta)(log(1/epsilon)). Expansion into the F basis has at most4^r terms, coefficient one-norm<=2^r, and tilted two-norm<=exp(theta r). These follow from orthonormality, weighted norm<=1 and maximum F-weight<=r. All three quantities are polynomial in Q. The retained region has m=O(L³).

The reviewed coefficient-p sparse engine consequently keeps polynomially many coefficients; its initial budgets may now be polynomial rather than constant, which changes only powers of Q. The tilted bound yields retained F weights r_j=O(log Q), so their physical operator norms C_mu^(r_j) and the sum_j |b_j|C_mu^(r_j) are also polynomial. Pruning thresholds, Kmax and dyadic precision use the doubled POLYNOMIAL budgets before evolution. The corrected min(eta,M0,Mtheta)rounding condition still has polynomial bit length because m=O(L³).

The EARLY weighted HC buffer now has duration O_mu(log m)/gamma=O_mu(log L)/gamma. Each retained F-product buffer is normalized by its paid C_mu^(r_j), with accuracy divided by the polynomial weighted coefficient one-norm. Hence log inverse buffer accuracy is O_class(log Q); the reset-register row cap and MPS dimensions are still polynomial. This is the quantitative replacement for treating growing support as a fixed parameter in an enormous opaque D_kappa.

Use eta_hist=xi/100 for each NORMALIZED buffer accuracy xi, independent of desired confidence. A capped history returns bounded zero and contributes a paid bias. Both parity vectors share the same sampled history and ancilla labels. Finite-bit errors are budgeted separately. Repetitions add only log(1/delta) for confidence. These conventions are inherited from the corrected component theorem and are essential here too.

## 6. Observable mixture and compatible prepared sources

For an arbitrary Hermitian contraction O_i use its ORDINARY Bloch decomposition O_i=a_i I+b_i A_i, with b_i>=0, A_i an ordinary traceless Hermitian unitary and |a_i|+b_i<=1. Sampling identity/Bloch/zero choices therefore gives a bounded signed mixture. This decomposition is independent of sigma. The false inequality |Tr(sigma O_i)|+||O_i-Tr(sigma O_i)I||<=1 is never needed.

The existing rational-axis stereographic approximation with local norm error O(epsilon/n), clipping, conditional inner failure budgets and outer Hoeffding sampling apply unchanged. Coefficient values in the biased basis remain algebraic and use the reviewed paid precision, not claimed rational closure.

The separately reviewed source-preparation extension is compatible: an explicit local circuit of depth O(log log Q_bin) can precede the product source. Moving-weight/HC error estimates are operator-norm statements independent of source. Only the short buffer incorporates the preparation cone and additional O(b_strip ell_p) crossing cost. The preparation is not commuted through the physical reset dynamics and need not preserve sigma. Circuit description, precision and actual generating cost are paid. Arbitrary polynomial-depth circuit-described input remains excluded.

## 7. Predecessors and priority

No newly located exact predecessor subsumes all of these simultaneous quantifiers. This is a bounded primary-source audit, not proof of first priority.

- Dong–Gao–Ou–Yao–Zhou2606.17729v1 Theorem1.1 supplies tensor weighted HC; Beigi–Datta–Rouze1804.10100v2 Theorems21/25 supply the prior exact-qubit tensorization and constant. Neither is a classical many-body evaluator. Their credit remains explicit.
- Angrisani et al2609.40174v2 supplies sparse-Pauli machinery for its stated Pauli-diagonal models. The centered KMS basis and whole-block conservation checks are added applicability operations here, not a claim that their ordinary Pauli assumptions already cover biased reset.
- Martinez et al2501.13050v1 Theorem1 measures error in an L2 average over rotation angles, equation(14). Angrisani–Mele–Rudolph–Cerezo–Holmes2501.13101v2 Theorem1 has probability over locally1-design-invariant random circuit layers. These strong nonunital simulation predecessors do not give a pointwise deterministic conserving-Hamiltonian guarantee. Exact versions and theorem checks are retained in BIASED_RESET_REVIEW.md.
- BGM1909.11485 Theorem5 supplies the Hermitian product-readout/overlap architecture. The original physical-angle strip construction, not its fine-step circuit-depth cost, is used in the continuous-time algorithm. Reset-SWAP dilations themselves are standard; the retained-register Chernoff cap is the operation that pays their row dimensions.
- General nonunital fault-tolerance constructions do not preserve this faithful product reference blockwise. They do not contradict the present common-reference theorem. The dual-rail tiling relative-probability obstruction in ambitious/FINAL_RELATIVE_OBSTRUCTION.md is also compatible: the new evaluator is additive and cannot resolve its exponentially rare events at polynomial inverse accuracy.

The strongest defensible mechanism description is therefore: common-reference KMS coefficient propagation, physical-support damping despite biased identity components, and a positive reset-register short buffer. It is substantively beyond the earlier first-order nonunital perturbation floor, while leaving arbitrary cooling and relative/full-distribution tasks separate.

## 8. Trivedi–Cirac benchmark: published statement versus uncleared proof

The following wording supersedes any earlier shorthand in this branch suggesting that the high-noise sampler's complete proof had been independently cleared:

> Trivedi–Cirac, arXiv:2110.10638v2 / Phys.Rev.Lett.129,260405(2022), states a polynomial total-variation sampler above a sufficiently high entanglement-breaking-noise threshold. Its printed proof uses a fixed-rate identity/CPTP-event decomposition in Lemma3. We have identified a false complete-positivity assertion in that ingredient and have not completed a replacement proof of the full high-noise theorem. This is an unresolved source-proof issue, not a counterexample to the theorem's conclusion. The present algorithms do not use the disputed ingredient.

I independently read arXivv2 Lemma3, especially the paragraphs between equations(7) and(8): it asserts that Id+integral L is CPTP at sufficiently small positive time and that choosing finite g makes Id+L/g CP. For L=-ih[P,.], h!=0 and P a traceless Hermitian Pauli, use the normalized Choi vector |Omega> and |v>=(P tensor I)|Omega>. They are orthonormal. The compression of J(Id+L/g) is

    [[1, i h/g],[-i h/g,0]], determinant=-h²/g²<0.

Thus no finite g makes that map CP. The same witness disproves the 'sufficiently small Euler step' assertion. An h-dependent CPTP event map cannot fix a first-order mixture with fixed g: taking the small-time limit would force the event map to approach the non-CP Id+L/g, contradicting closedness of the CPTP cone.

For a multi-site P of weight>=2, adding arbitrary independent one-site replacement noise only adds Choi components along |Omega> and one-site Pauli vectors. It adds nothing to the v-v diagonal or the nonzero I-v cross entry. The negative determinant persists. Merely reallocating original one-site replacement noise does not repair this finite-event-rate argument for coherent multi-site interactions.

The fourth researcher's direct journal access, recorded in ambitious/PRIMARY_ACCESS_ADDITIONS.json and ambitious/SAMPLING_FRONTIER.md Section6, reports the same assertion in the published supplement's Lemma3 on page4. Its actual linked URL is https://journals.aps.org/prl/supplemental/10.1103/PhysRevLett.129.260405/supplement_final.pdf . That published PDF was checked by that researcher; this review independently checks the arXiv primary step and the exact Choi obstruction, and does not invent a local published-PDF hash after direct retrieval returned403.

Our Cayley/Euler construction uses an actual unitary coherent map at EVERY numerical step. Only the genuine reset channel is sampled as a rare positive event, with its old registers retained. It never writes a general Hamiltonian drift as a fixed-rate identity/CPTP event. Thus the objection affects benchmark proof-clearance wording, not either the biased local/global theorem or earlier unital construction.

## 9. Status

This review accepts the global Hermitian biased-reset closure at the exact common-reference finite-input scope, using the already inspected constructive sparse/buffer lemmas and the corrected numerical budgets. Checks above are analytic; no new finite diagnostic or general implementation was used as a substitute for proof. The core mathematical claims, practical capability, historical priority, relative evaluation and full-output sampling remain distinct. The specific unresolved TC source step is pinned rather than hidden or treated as a refutation of its published theorem statement.
