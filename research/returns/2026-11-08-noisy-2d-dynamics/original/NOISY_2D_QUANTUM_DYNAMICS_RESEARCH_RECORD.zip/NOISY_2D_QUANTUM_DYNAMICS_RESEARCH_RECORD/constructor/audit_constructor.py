#!/usr/bin/env python3
"""Finite diagnostics, not a proof of the uniform theorem."""
import itertools, json, math, pathlib
import numpy as np
def expm(A):
    scaling=max(0,int(math.ceil(math.log2(max(1.,float(np.linalg.norm(A,1)))))))
    B=A/(2**scaling)
    out=np.eye(A.shape[0],dtype=complex);term=out.copy()
    for j in range(1,100):
        term=term@B/j;out+=term
        if np.linalg.norm(term,1)<1e-16: break
    for j in range(scaling): out=out@out
    return out
rng=np.random.default_rng(20261108)
I=np.eye(2,dtype=complex)
X=np.array([[0,1],[1,0]],complex)
Y=np.array([[0,-1j],[1j,0]],complex)
Z=np.diag([1.,-1.]).astype(complex)
paulis=[I,X,Y,Z]
def kronall(xs):
 out=np.ones((1,1),complex)
 for x in xs: out=np.kron(out,x)
 return out
def fullp(n, inds): return kronall([paulis[inds.get(i,0)] for i in range(n)])
def cutmat(v,A,n):
 axes=list(A)+[i for i in range(n) if i not in A]
 return v.reshape([2]*n).transpose(axes).reshape(2**len(A),-1)
def frommat(M,A,n):
 axes=list(A)+[i for i in range(n) if i not in A]
 return M.reshape([2]*n).transpose(np.argsort(axes)).reshape(-1)
def snorm(v,A,n): return np.linalg.svd(cutmat(v,A,n),compute_uv=False).sum()
def truncate(v,A,n,D):
 U,s,Vh=np.linalg.svd(cutmat(v,A,n),full_matrices=False)
 return frommat((U[:,:D]*s[:D])@Vh[:D],A,n)
def entropy(rho):
 ev=np.maximum(np.linalg.eigvalsh(rho),1e-300)
 return float(-np.sum(ev*np.log(ev)))
# A genuinely branching compatible cut tree; all one-site leaves included.
n=8
cuts=[(i,) for i in range(n)]+[(0,1),(2,3),(4,5),(6,7),(0,1,2,3)]
psi=np.zeros(2**n,complex);psi[0]=1
phi=psi.copy()
actions=np.zeros(len(cuts))
max_ratio=0.; max_lemma_residual=-1e99
history=[]
D=2
for step in range(60):
 support=sorted(rng.choice(n,size=int(rng.integers(1,4)),replace=False))
 inds={int(i):int(rng.integers(1,4)) for i in support}
 P=fullp(n,inds); theta=float(rng.uniform(-.17,.17))
 U=math.cos(theta)*np.eye(2**n)-1j*math.sin(theta)*P
 psi=U@psi;phi=U@phi
 for j,A in enumerate(cuts):
  if any(i in A for i in support) and any(i not in A for i in support): actions[j]+=abs(theta)
  B=math.exp(actions[j]); N=snorm(psi,A,n)
  max_ratio=max(max_ratio,float(N/B))
 # Physical on-site Pauli jumps, including simultaneous correlated ones.
 jump=fullp(n,{int(i):int(rng.integers(1,4)) for i in rng.choice(n,size=2,replace=False)})
 psi=jump@psi;phi=jump@phi
 for j,A in enumerate(cuts):
  prev=np.linalg.norm(phi-psi)**2
  phi1=truncate(phi,A,n,D)
  new=np.linalg.norm(phi1-psi)**2
  bound=prev+2*math.exp(actions[j])/math.sqrt(D+1)
  max_lemma_residual=max(max_lemma_residual,float(new-bound))
  phi=phi1
 if step in [0,9,29,59]: history.append({'step':step+1,'state_error':float(np.linalg.norm(phi-psi)), 'max_cut_action':float(actions.max()), 'norm_approx':float(np.linalg.norm(phi))})
# Certify the entropy differential inequality numerically on arbitrary correlated states.
max_entropy_residual=-1e99
entropy_rows=[]
for n in [2,3,4]:
 ps=[fullp(n,{i:p}) for i in range(n) for p in [1,2,3]]
 for trial in range(12):
  R=rng.normal(size=(2**n,2**n))+1j*rng.normal(size=(2**n,2**n))
  rho=R@R.conj().T;rho/=np.trace(rho)
  ev,V=np.linalg.eigh(rho);logrho=(V*np.log(ev))@V.conj().T
  derivative=0.
  for i in range(n):
   Ei=(rho+sum(ps[3*i+p]@rho@ps[3*i+p] for p in range(3)))/4
   derivative+=float(np.trace((Ei-rho)@logrho).real)
  rel=n*math.log(2)-entropy(rho)
  max_entropy_residual=max(max_entropy_residual,derivative+rel)
  entropy_rows.append({'n':n,'relative_entropy':rel,'derivative_at_gamma_1':derivative})
# Actual channel discretization check with arbitrary correlated initial input.
n=3
terms=[(.63,fullp(n,{0:1,1:2})),(-.27,fullp(n,{1:3,2:1})),(.19,fullp(n,{2:2}))]
gamma=.31;t=.4
H=sum(h*P for h,P in terms);dim=2**n
identity=np.eye(dim)
L=-1j*(np.kron(identity,H)-np.kron(H.T,identity))
for i in range(n):
 for p in [1,2,3]:
  P=fullp(n,{i:p});L+=gamma/4*(np.kron(P.conj(),P)-np.eye(dim*dim))
R=rng.normal(size=(dim,dim))+1j*rng.normal(size=(dim,dim));rho=R@R.conj().T;rho/=np.trace(rho)
exact=(expm(t*L)@rho.reshape(-1,order='F')).reshape((dim,dim),order='F')
S=2*sum(abs(h) for h,_ in terms)+2*gamma*n
channel_rows=[]
for steps in [8,16,32,64]:
 dt=t/steps;state=rho.copy()
 for s in range(steps):
  for h,P in terms:
   x=dt*h;U=((1-x*x/4)*identity-1j*x*P)/(1+x*x/4)
   state=U@state@U.conj().T
  for i in range(n):
   state=(1-3*gamma*dt/4)*state+sum((gamma*dt/4)*fullp(n,{i:p})@state@fullp(n,{i:p}) for p in [1,2,3])
 err=float(np.linalg.svd(state-exact,compute_uv=False).sum())
 channel_rows.append({'steps':steps,'trace_error':err,'coarse_bound_40S2t2_over_steps':40*S*S*t*t/steps})
# Crossing nuclear growth is real, even at fixed physical time.
bell=[]
for pairs in [1,2,3,4]:
 n=2*pairs;v=np.zeros(2**n,complex);v[0]=1
 for i in range(pairs):
  P=fullp(n,{i:1,i+pairs:1});v=(v-1j*P@v)/math.sqrt(2)
 N=snorm(v,tuple(range(pairs)),n)
 bell.append({'pairs':pairs,'nuclear_norm':float(N),'exact_2power':2**(pairs/2)})
report={'scope':'finite floating-point diagnostics only; not uniform theorem verification', 'seed':20261108, 'max_nuclear_bound_ratio':max_ratio,'max_truncation_lemma_residual':max_lemma_residual,'trajectory_rows':history,'max_entropy_derivative_plus_D':max_entropy_residual,'entropy_trials':len(entropy_rows),'channel_rows':channel_rows,'crossing_bell_rows':bell}
assert max_ratio<=1+1e-10
assert max_lemma_residual<=1e-10
assert max_entropy_residual<=1e-10
assert all(x['trace_error']<=x['coarse_bound_40S2t2_over_steps'] for x in channel_rows)
assert all(abs(x['nuclear_norm']-x['exact_2power'])<1e-9 for x in bell)
out=pathlib.Path(__file__).with_name('AUDIT_CONSTRUCTOR.json');out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
