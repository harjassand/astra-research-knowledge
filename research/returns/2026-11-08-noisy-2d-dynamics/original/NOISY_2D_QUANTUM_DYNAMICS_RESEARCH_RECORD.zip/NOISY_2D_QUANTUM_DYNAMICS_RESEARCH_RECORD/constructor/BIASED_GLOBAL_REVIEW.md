# Independent review: global product readouts with biased reference

8 November 2026. Reviewed
`principal/BIASED_GLOBAL_READOUT_CLOSURE.md`, SHA256
`9f8ae0f5fc319b150fbaccbcf07d221fafb0e730673ce7cf80ad7f0180adde38`,
together with the reset-register construction previously reviewed at SHA256
`081033fb1dc3d8856babe010c849fc02090c189455e1e62b6a99838d988295ed`.
Frozen initial reports are unchanged. No additional researcher was used.

## Verdict

**The proposed global closure survives independent review.** The physical-
support estimate is correct even though ordinary Bloch factors are not
sigma-centered. Weighted two-sided smoothing, support-sensitive HC, the
global retained-register short buffer and the low-physical-support sparse
branch fit together with polynomial finite bit costs.

The completed scalar theorem allows **any tensor product of one-qubit
Hermitian contractions**, with supplied rational product source, known
faithful sigma, all-site biased replacement, conserving bounded local blocks
and explicit prescribed rational drives. The polynomial degree depends on
mu>0 and J/gamma. No relative probabilities, global sampler, arbitrary
correlated source or arbitrary work-driving Hamiltonian follows.

The bounded-cut biased TV theorem remains a separate result on a restricted
interaction architecture. Its positive global-state approximation is not
supplied by this global scalar argument.

## 1. The physical-support inequality is sound

Use the symmetric weighted HS inner product

`<A,B>_sigma=Tr[sigma^(1/2) A^dagger sigma^(1/2) B]`.

For an ordinary traceless Bloch unitary `A=n_x X+n_y Y+n_z Z`, with unit
real n, write `A=a I+B`, where `a=Tr(sigma A)=z n_z`, `z=2p-1` and
`Tr(sigma B)=0`. Thus `|a|<=|z|`. Moreover

`||A||_(2,sigma)^2=n_z^2+2sqrt(p(1-p))(n_x^2+n_y^2)<=1`.

The last inequality also follows directly from Schatten Holder and
`||A||_infty=1`. Identity and B are orthogonal in the weighted metric.
Because W annihilates identity and is one on its one-site complement,

`||exp(-alpha W)A||_(2,sigma)^2
 =a^2+exp(-2alpha)(||A||_(2,sigma)^2-a^2)`

`<=exp(-2alpha)+(1-exp(-2alpha))z^2`.

This is the correct joint use of `||A||<=1` and `a^2<=z^2`; it does not
incorrectly assert `||B||^2<=1-z^2` for each individual A.

For `0<=alpha<=1/2`, `1-exp(-2alpha)>=alpha`, and
`1-z^2=4mu(1-mu)>=2mu`. Therefore

`||exp(-alpha W)A||_(2,sigma)^2
 <=1-2mu alpha<=exp(-2mu alpha)`.

The weighted norm tensorizes exactly, as does exp(-alpha W). A product P
of r occupied ordinary Bloch unitaries consequently obeys

`||exp(-alpha W)P||_(2,sigma^m)<=exp(-mu alpha r)`.       (1)

The weighted identity component does remain. Faithfulness makes its size
strictly smaller than one per physically traceless occupied factor, which is
precisely what pays (1). At long times the physical mean tends to
`Tr(sigma^m P)` rather than zero, but this reference value is consistent with
the loose exponential envelope. No centeredness is assumed silently.

## 2. Moving weight and KMS dual orientation

In the orthonormal F basis the exact generator is `K_t-gamma W`, where K_t
is skew-adjoint because each block commutes with its local reference.
Reserve gamma/2 and allocate gamma/(2d) to each incident block site. The
reviewed tilted coefficient bound ensures the half-noise generator's
Hermitian part stays nonpositive for `0<=alpha<=theta`, after the tilt.

For `alpha(u)=min(gamma u/2,theta)`, differentiation adds
`(alpha'-gamma/2)W`, also nonpositive. Thus for the actual interval map S,

`||exp(alpha W) S||_(2,sigma->2,sigma)<=1`.

The KMS adjoint of reset is itself; the adjoint of a conserving block
commutator reverses its Hamiltonian sign. For a varying schedule the adjoint
also reverses chronology. Applying the previous estimate to that **sign-
reversed, time-reversed schedule**, then taking its adjoint, gives

`||S exp(alpha W)||<=1`.

Insert `exp(-alpha W)X` to obtain

`||S X||_(2,sigma)<=||exp(-alpha W)X||_(2,sigma)`.

Combining with (1) yields the claimed
`||S P||_(2,sigma)<=exp(-mu alpha r)`. This adjoint argument is valid for
the actual conserving drive; it does not commute the weights or the
Hamiltonian through a noise channel.

## 3. Weighted HC and support-sensitive times

The earlier independently checked primary import is Dong--Gao--Ou--Yao--Zhou,
[arXiv:2606.17729v1, Theorem 1.1](https://arxiv.org/html/2606.17729v1), for
every operator and faithful tensor reference. Conserving conjugations are
isometries at every weighted Schatten exponent. Interleaving therefore gives
the actual-channel HC estimate for prescribed drives. This applies to the
**physical** channel before its enlarged reset-register representation; the
kept bath coordinates are not being treated as extra HC input sites.

Let `lambda=mu theta`, `t0=2theta/gamma`. If the later interval has length
at least t0, its weighted two-norm bound is exp(-lambda r). An early HC
buffer reaching

`q>=max(2,4m ln(1/mu)/(lambda r))`

has `mu^(-m/q)<=exp(lambda r/4)`. Therefore the exact restricted propagator
maps P to operator norm at most `exp(-3lambda r/4)`.

A completely rational time choice is available. Set

`A_mu=ceil(log_2(1/mu))`,
`b=max(1,ceil(log_2(8 A_mu m/(lambda r))))`,
`s=b/(2mu gamma)`.

The inequality `a_sigma>=mu`, proved from `ln x<=x-1`, implies the imported
HC rate is at least 2mu. In the proof use `q=1+exp(b)`; it need not be
evaluated by the algorithm. It is larger than the required exponent. At fixed
mu,theta,

`gamma s=O(1+log(m/r))`.

Chronology is correct: `Phi_(0,T)=Phi_(0,s) Phi_(s,T)`. Apply smoothing to
the **later** map and HC to the **early** map. For a varying drive no
semigroup or commutation assumption is used.

An operator-norm LR truncation around the r occupied sites has error eta and
volume at most

`m<=min(n,C r[1+(J+gamma)T+log((r+1)/eta)]^2)`.

Using the conservative original LR constants may require the displayed
`J+gamma` in place of J; at fixed gamma/J this changes only class constants.
The truncated system retains whole conserving blocks and its biased resets,
so all preceding weighted estimates continue to apply. Adding the LR error
gives the stated suppression `eta+exp(-3lambda r/4)`.

## 4. The early global reset buffer really is polynomial

First use the faithful-reference entropy cutoff at
`gamma T=O_mu(log(n/xi))`, returning the known reference mean thereafter.
In the nontrivial branch `JT+gamma T=O_mu,g(L)` for
`L=ceil(log_2 Q)`, with Q including complete input bits, n, xi^-1 and
confidence digits. Then `m/r<=C L^2` and `s+t0=O_mu,g(log L)/gamma`.

If `T<s+t0`, m can equal n. This does not introduce an exponential state
vector. Set the original factorial parameter Lambda to O(L). Its strip width
is `b_strip=O(L/log L)`. On this branch,

`log B_star=O(b_strip J T)=O(L)`.

The Hamiltonian has whole k-qubit blocks; their buffer Pauli expansion costs
one-norm at most `2^k J` per block, a fixed factor. On-site physical Bloch
unitaries do not add crossing action, even with r=n. Grouped rows contain
all local input purifiers and all kept reset registers.

The reset mean per row is `O(b_strip gamma T)=O(L)`. A cap at

`ceil(3mu_row)+ceil(log_2(Cm/eta_hist))`

with `eta_hist=xi/100` is O(L). Hence the row dimension is `exp(O(L))`,
including every old register, and the constructive MPS bond is polynomial.
There are only polynomially many rows, gates, labels and categorical choices.
Same-history/reversal rules and the bounded overlap sampler were independently
checked in `BIASED_RESET_CONSTRUCTION_REVIEW.md`.

This argument uses neither global TTN state approximation nor a fixed local
Hilbert dimension after dilation. It uses the two differently ordered parity
MPSs and their scalar overlap. It therefore pays m=n without proving a 2D
positive global-state sampler.

## 5. Low-r branch and all finite coefficient costs

For `T>=s+t0` and `r>=C lambda^-1 log(1/xi)`, take eta=xi/100 and return
zero using the proved suppression. Use a dyadic upper bound on the logarithm
to keep all parameter choices rational. In the remaining branch,

`r=O_mu,theta(log(1/xi))`, `m=O_mu,g(L^3)`.

Expand P in its at most 4^r F-basis products. Orthonormality and weighted
two-norm <=1 give coefficient one-norm <=2^r. Its initial tilted-two-norm
is <=exp(theta r). These initial budgets are **polynomial**, not constant,
and must be used as such in threshold and rank choices. Their logarithms
are O(L), so this creates no hidden growing-support exponent.

The conserving whole-block sparse engine has fixed coefficient p<2, fixed
branching 4^k and predeclared polynomial cutoff count. All retained weights
are O(log Q), even with these polynomial initial budgets. Thus

`W_ret=sum_j |b_j| C_mu^(r_j)=Q^O_mu,g(1)`.

Normalize those F products by C_mu^(r_j) and use inverse-polynomial normalized
buffer accuracy `xi/[C max(1,W_ret)]`. The early weighted HC buffer has
duration `O_mu(log m)/gamma=O_mu(log L)/gamma`, so Section 4's reset-register
construction closes it.

Basis coefficients are computable algebraic values, not exact rational
closure. Their dyadic precision includes the paid transform conditioning
`O(m log C_mu)`, the tilted factor `O(theta m)`, update count and target
weighted-HS error. Since m=O(L^3), these are polynomially many precision bits.
Whole-block rational matrix Cayley updates conserve the reference exactly;
individual nonconserving Pauli steps are used only in the directly error-paid
buffer. Finite switches add their explicit number to the step count, without
inverse-minimum-step cost.

## 6. Ordinary mixture, confidence and source assumptions

For a supplied one-qubit Hermitian contraction, use its ordinary Bloch
decomposition

`O_i=c_i I+beta_i A_i`, `|c_i|+beta_i<=1`.

Independent identity/axis/zero choices form a bounded signed mixture of the
products reviewed above. This does not expand a global observable into 4^n
terms. It is essential to use this **ordinary** decomposition: the analogous
one-norm bound for a sigma-centered decomposition is false.

Approximate beta downward, discard axes of tiny beta with paid local error,
and approximate the remaining unit axes by exact rational stereographic
coordinates. Every represented A_i then remains an ordinary traceless
Hermitian unitary, as required by Section 1. Choose local operator error
O(epsilon/n); product telescoping pays the total. The computation of axes
with beta above this threshold needs only polynomial precision bits.

Use `O(epsilon^-2 log(1/delta))` outer mixture samples; each scalar call is
clipped to [-1,1] and receives inverse-polynomial accuracy and confidence
delta divided by the number of calls. Hoeffding and conditional union bounds
pay all failures. In each inner reset buffer, the count cap is an accuracy
bias budget, not a confidence event unioned over every repetition. Thermal
coins, MPS choices and ordinary mixture coins have bounded finite random-bit
costs and a paid sum of TV errors.

Thus the final guarantee is pointwise for the supplied rational product
source and every permitted finite rational drive. It is polynomial in the
complete bits, n, epsilon^-1 and confidence digits at fixed faithful mu and
J/gamma. It does not depend on an input ensemble. Prepared correlated sources
require their own separately checked transfer; they are not included for free
by this review.

## 7. Separate diagnostics and final ledger

New files `audit_biased_global.py` and `AUDIT_BIASED_GLOBAL.json` leave the
existing biased-reset fixtures unchanged. On two sites with p=0.3 they check:

* 480 physical Bloch-factor inequalities across r=1,2 and six alpha values;
* two-sided tilted smoothing at six times for a genuinely noncommuting
  two-segment conserving drive (schedule commutator norm 1.4);
* physical-support suppression through that actual channel;
* half-noise tilted Hermitian parts for both Hamiltonian signs.

All bounds pass to roundoff. Smoothing norm is one on identity; active-sector
norms are strictly below one. These finite tests supplement the analytic
proof and do not establish uniformity or practical runtime.

| Claim | Independent review |
|---|---|
| Physical traceless Bloch factors acquire exponential weighted suppression | Pass |
| KMS adjoint reverses sign and chronology with the required orientation | Pass |
| Support-sensitive weighted HC and localization | Pass, with conservative J+gamma LR option |
| Early extensive-support reset-register buffer | Pass, polynomial row storage and crossing action |
| Low-r weighted sparse costs with growing initial budgets | Pass |
| Bounded ordinary Hermitian-product mixture and finite bits | Pass |
| All-support additive Hermitian-product prediction in conserving biased class | Supported / mathematically closed by these components |
| Relative probabilities or generic 2D full sampling | Not obtained |
| mu->0 uniform degree or generic nonunital controls | Not obtained |
| Bounded-cut biased TV sampler | Separate theorem; not a scalar-to-sampler corollary |
| Historical novelty or practical advantage | Not established |
