#!/usr/bin/env python3
"""Independent Pauli-basis density-series and variable-cover-count phase checks."""
from fractions import Fraction
from math import factorial
from collections import defaultdict
import itertools,json,pathlib
P=['I','X','Y','Z']
# Pauli product phase as integer powers of i.
mul={('I',a):(0,a) for a in P};mul.update({(a,'I'):(0,a) for a in P})
for a in ['X','Y','Z']:mul[a,a]=(0,'I')
for a,b,c in [('X','Y','Z'),('Y','Z','X'),('Z','X','Y')]:mul[a,b]=(1,c);mul[b,a]=(3,c)
def comm(Pa,Q):
 phase=0;rs=[];anti=0
 for a,b in zip(Pa,Q):
  u,c=mul[a,b];phase=(phase+u)%4;rs.append(c)
  anti+=(a!='I' and b!='I' and a!=b)
 if anti%2==0:return None
 assert phase in [1,3]
 return ''.join(rs),2 if phase==1 else -2 # -i[P,Q]
def tiles(region):
 reg=set(region);out=set()
 for x,y in reg:
  for dx,dy in itertools.product([0,1],repeat=2):
   cell={(x-dx,y-dy),(x-dx+1,y-dy),(x-dx,y-dy+1),(x-dx+1,y-dy+1)}
   if cell<=reg:out.add(tuple(sorted(cell)))
   for miss in cell:
    if cell-{miss}<=reg:out.add(tuple(sorted(cell-{miss})))
 return sorted(out)
def cover_counts(region):
 pts=sorted(region);idx={p:i for i,p in enumerate(pts)};tt=tiles(region);masks=[sum(1<<idx[p] for p in t) for t in tt];full=(1<<len(pts))-1
 def rec(used,count):
  if used==full:return {count:1}
  out=defaultdict(int);bit=((~used)&full)&-((~used)&full)
  for mask in masks:
   if mask&bit and not mask&used:
    for k,v in rec(used|mask,count+1).items():out[k]+=v
  return out
 return rec(0,0)
def density_series(region,gamma,weighted=False):
 pts=sorted(region);n=len(pts);idx={p:i for i,p in enumerate(pts)}
 terms=[]
 for t in tiles(region):
  if not weighted and len(t)!=3:continue
  word=['I']*n
  for p in t:word[idx[p]]='X'
  if weighted:word[idx[t[0]]]='Y'
  terms.append((len(t) if weighted else 1,''.join(word)))
 degree=2*n if weighted else 2*(n//3);maxdeg=degree
 cur={}
 for z in itertools.product('IZ',repeat=n):cur[0,''.join(z)]=Fraction(1,2**n)
 coeff=defaultdict(Fraction)
 for ell in range(maxdeg+1):
  for (deg,Q),v in cur.items():
   if set(Q)<={'I','Z'}:coeff[deg]+=((-1)**Q.count('Z'))*v/factorial(ell)
  nxt=defaultdict(Fraction)
  for (deg,Q),v in cur.items():
   nd=deg+(3 if weighted else 1)
   if nd<=maxdeg:nxt[nd,Q]-=gamma*sum(q!='I' for q in Q)*v
   for shift,H in terms:
    if deg+shift>maxdeg:continue
    co=comm(H,Q)
    if co:
     R,f=co;nxt[deg+shift,R]+=f*v
  cur={k:v for k,v in nxt.items() if v}
  if not cur:break
 z=sum(cover_counts(region).values()) if weighted else None
 if not weighted:
  # Count only right-tromino covers.
  tt=[t for t in tiles(region) if len(t)==3];full=(1<<n)-1;masks=[sum(1<<idx[p] for p in t) for t in tt]
  def rec(used):
   if used==full:return 1
   bit=((~used)&full)&-((~used)&full)
   return sum(rec(used|m) for m in masks if m&bit and not m&used)
  z=rec(0)
 assert all(not v for d,v in coeff.items() if d<degree)
 assert coeff[degree]==z*z
 return {'n':n,'gamma':gamma,'weighted':weighted,'cover_count':z,'target_degree':degree,'coefficient':str(coeff[degree]),'lower_nonzero_count':sum(bool(v) for d,v in coeff.items() if d<degree)}
def variable_phase(region):
 pts=sorted(region);n=len(pts);idx={p:i for i,p in enumerate(pts)};full=(1<<n)-1
 tt=[(len(t),sum(1<<idx[p] for p in t),1<<idx[t[0]]) for t in tiles(region)]
 # Coefficients of exp(-i sum tau^|tile| P_tile) in the ket computational basis.
 # For one Y per tile, -i P acts by the real sign (-1)^old_bit_at_Y.
 cur={(0,0):1};aligned=defaultdict(Fraction);counts=cover_counts(region)
 for ell in range(n//3+1):
  for (deg,bits),v in cur.items():
   if bits==full:aligned[deg]+=Fraction(v,factorial(ell))
  nxt=defaultdict(int)
  for (deg,bits),v in cur.items():
   for size,mask,ymask in tt:
    if deg+size<=n:nxt[deg+size,bits^mask]+=(-v if bits&ymask else v)
  cur={k:v for k,v in nxt.items() if v}
 assert all(v==0 for d,v in aligned.items() if d<n)
 assert aligned[n]==sum(counts.values())
 assert len(counts)>=2
 unaligned=sum(count*((-1j)**number) for number,count in counts.items())
 return {'n':n,'cover_counts_by_tile_number':counts,'aligned_tau_n_amplitude_coefficient':str(aligned[n]),'aligned_probability_leading':str(aligned[n]**2),'all_X_amplitude_real':unaligned.real,'all_X_amplitude_imag':unaligned.imag,'all_X_probability_leading':abs(unaligned)**2}
rows=[]
for gamma in [1,7]:
 rows.append(density_series([(0,0),(0,1),(1,0)],gamma))
 rows.append(density_series([(x,y) for x in range(2) for y in range(3)],gamma))
 rows.append(density_series([(x,0) for x in range(6)],gamma))
 rows.append(density_series([(x,y) for x in range(2) for y in range(2)],gamma,True))
phase=variable_phase([(x,y) for x in range(2) for y in range(6)])
out={'scope':'independent exact finite diagnostics; no complexity theorem inferred from tests','density_Pauli_series':rows,'different_tile_counts_phase_fixture':phase}
pathlib.Path(__file__).with_name('AUDIT_AMBITIOUS_INDEPENDENT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
