#!/usr/bin/env python3
"""Finite diagnostics for the relative-mixing bound and noisy-code example."""
import json, math, pathlib
import numpy as np
rng=np.random.default_rng(11082026)
def expm(A):
 scaling=max(0,int(math.ceil(math.log2(max(1.,float(np.linalg.norm(A,1)))))))
 B=A/(2**scaling);out=np.eye(len(A),dtype=complex);term=out.copy()
 for j in range(1,150):
  term=term@B/j;out+=term
  if np.linalg.norm(term,1)<1e-16:break
 for j in range(scaling):out=out@out
 return out
I=np.eye(2,dtype=complex);X=np.array([[0,1],[1,0]],complex);Y=np.array([[0,-1j],[1j,0]],complex);Z=np.diag([1.,-1.]).astype(complex)
Ps=[I,X,Y,Z]
def kronall(seq):
 out=np.ones((1,1),complex)
 for A in seq:out=np.kron(out,A)
 return out
def full(n,inds):return kronall([Ps[inds.get(i,0)] for i in range(n)])
def liou(n,H,gamma):
 dim=2**n;Id=np.eye(dim);L=-1j*(np.kron(Id,H)-np.kron(H.T,Id))
 for i in range(n):
  for p in [1,2,3]:
   P=full(n,{i:p});L+=gamma/4*(np.kron(P.conj(),P)-np.eye(dim*dim))
 return L
n=3;dim=2**n;gamma=.7
H0=.7*full(n,{0:1,1:2})+.4*full(n,{1:3,2:1})-.2*full(n,{0:2,2:3})
H1=-.9*full(n,{0:3,1:1,2:2})+.3*full(n,{2:3})+.2*full(n,{0:1,2:1})
A=rng.normal(size=(dim,dim))+1j*rng.normal(size=(dim,dim));rho=A@A.conj().T;rho/=np.trace(rho)
L0=liou(n,H0,gamma);L1=liou(n,H1,gamma)
rows=[]
for T in [math.log(n)/gamma,4.,6.,8.]:
 # A genuinely driven schedule: H0 for the first .37T and H1 thereafter.
 evolved=(expm(.63*T*L1)@expm(.37*T*L0)@rho.reshape(-1,order='F')).reshape((dim,dim),order='F')
 op=float(np.linalg.norm(dim*evolved-np.eye(dim),2));bound=4*n*math.exp(-gamma*T)
 rows.append({'T':T,'gammaT':gamma*T,'relative_operator_error':op,'bound_4n_exp':bound,'ratio':op/bound})
 assert op<=bound+1e-10
# Positive noisy-code distribution with all weight-one and weight-two coefficients zero.
n=16;m=5;kappa=.9;q=(1-kappa)/2
columns=rng.choice(np.arange(1,2**m,dtype=np.uint32),size=n,replace=False)
code=[]
for u in range(2**m):
 word=0
 for j,col in enumerate(columns):word|=((int(u&int(col)).bit_count()&1)<<j)
 code.append(word)
assert len(set(code))==2**m
xs=np.arange(2**n,dtype=np.uint32);prob=np.zeros(2**n)
for c in code:
 wt=np.bitwise_count(xs^c)
 prob+=(q**wt)*((1-q)**(n-wt))/len(code)
assert abs(prob.sum()-1)<1e-12
fourier=prob.copy();size=1
while size<len(fourier):
 for off in range(0,len(fourier),2*size):
  left=fourier[off:off+size].copy();right=fourier[off+size:off+2*size].copy()
  fourier[off:off+size]=left+right;fourier[off+size:off+2*size]=left-right
 size*=2
weights=np.bitwise_count(xs)
in_dual=np.ones(len(xs),dtype=bool)
for c in code:in_dual&=(np.bitwise_count(xs&c)%2)==0
expected=in_dual*(kappa**weights)
residual=float(np.max(np.abs(fourier-expected)))
low=float(np.max(np.abs(fourier[(weights>0)&(weights<=2)])))
tv=.5*float(np.abs(prob-2**(-n)).sum())
assert residual<1e-12
assert low<1e-12
assert tv>.5
out={'scope':'small finite numerical diagnostics only; asymptotic arguments are proofs in the linked report','relative_mixing_rows':rows,'noisy_code':{'n':n,'m':m,'kappa':kappa,'dual_minimum_nonzero_weight':int(weights[in_dual&(weights>0)].min()),'max_fourier_formula_residual':residual,'max_degree_1_2_coefficient':low,'TV_from_uniform_and_degree_2_truncation':tv}}
path=pathlib.Path(__file__).with_name('AUDIT_RELATIVE.json');path.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
