#!/usr/bin/env python3
"""Separate diagnostics for physical-support smoothing in the biased model."""
import json,math,pathlib
import numpy as np
rng=np.random.default_rng(2026110822)
I=np.eye(2,dtype=complex);X=np.array([[0,1],[1,0]],complex);Y=np.array([[0,-1j],[1j,0]],complex);Z=np.diag([1.,-1.]).astype(complex)
p=.3;mu=min(p,1-p);gamma=.6;k=2
sig=np.diag([p,1-p]);z=2*p-1
F=[I,X/math.sqrt(2*math.sqrt(p*(1-p))),Y/math.sqrt(2*math.sqrt(p*(1-p))),(Z-z*I)/(2*math.sqrt(p*(1-p)))]
FF=[np.kron(a,b) for a in F for b in F]
Sigma=np.kron(sig,sig);Sighalf=np.diag(np.sqrt(np.diag(Sigma)))
wt=np.array([(i!=0)+(j!=0) for i in range(4) for j in range(4)],dtype=float)
H0=.35*(np.kron(X,X)+np.kron(Y,Y))+.2*np.kron(Z,Z)+.1*(np.kron(Z,I)+np.kron(I,Z))
H1=.2*(np.kron(X,X)+np.kron(Y,Y))+.25*(np.kron(Z,I)-np.kron(I,Z))+.3*np.kron(Z,Z)
def coefficients(A):return np.array([np.trace(Sighalf@f.conj().T@Sighalf@A) for f in FF])
def skew(H):return np.array([[np.trace(Sighalf@a.conj().T@Sighalf@(1j*(H@b-b@H))) for b in FF] for a in FF])
def expm(A):
 scaling=max(0,int(math.ceil(math.log2(max(1.,float(np.linalg.norm(A,1)))))))
 B=A/(2**scaling);out=np.eye(len(A),dtype=complex);term=out.copy()
 for j in range(1,150):
  term=term@B/j;out+=term
  if np.linalg.norm(term,1)<1e-16:break
 for j in range(scaling):out=out@out
 return out
K0=skew(H0);K1=skew(H1);crow=max(np.abs(K0).sum(axis=1).max(),np.abs(K1).sum(axis=1).max())
theta=min(.25,gamma/(16*k*crow))
G0=K0-gamma*np.diag(wt);G1=K1-gamma*np.diag(wt)
max_physical_ratio=0.;physical_trials=0
products=[]
for r in [1,2]:
 for j in range(40):
  vecs=rng.normal(size=(r,3));vecs/=np.linalg.norm(vecs,axis=1)[:,None]
  A=[u[0]*X+u[1]*Y+u[2]*Z for u in vecs]
  P=np.kron(A[0],A[1] if r==2 else I);c=coefficients(P);products.append((r,c))
  for alpha in [0.,theta/2,theta,.03,.2,.5]:
   val=float(np.linalg.norm(np.exp(-alpha*wt)*c));bound=math.exp(-mu*alpha*r)
   max_physical_ratio=max(max_physical_ratio,val/bound);physical_trials+=1
   assert val<=bound+1e-12
smoothing=[];max_dynamic_ratio=0.
for duration in [.005,.02,.05,.2,1.,2.]:
 alpha=min(gamma*duration/2,theta);D=np.diag(np.exp(alpha*wt))
 S=expm(.6*duration*G1)@expm(.4*duration*G0)
 left=float(np.linalg.norm(D@S,2));right=float(np.linalg.norm(S@D,2))
 # Remove identity for a nontrivial strict-contraction check.
 active_left=float(np.linalg.norm((D@S)[1:,1:],2));active_right=float(np.linalg.norm((S@D)[1:,1:],2))
 assert left<=1+1e-11 and right<=1+1e-11
 for r,c in products:
  ratio=float(np.linalg.norm(S@c))/math.exp(-mu*alpha*r)
  max_dynamic_ratio=max(max_dynamic_ratio,ratio)
  assert ratio<=1+1e-11
 smoothing.append({'duration':duration,'alpha':alpha,'left_smoothing_norm':left,'right_smoothing_norm':right,'active_left_norm':active_left,'active_right_norm':active_right})
tilt=[]
for K in [K0,K1,-K0,-K1]:
 for alpha in [0.,theta/2,theta]:
  D=np.diag(np.exp(alpha*wt));A=D@(K-gamma/2*np.diag(wt))@np.linalg.inv(D)
  value=float(np.linalg.eigvalsh((A+A.conj().T)/2).max());tilt.append(value)
  assert value<=1e-12
out={'scope':'finite diagnostics only; no general proof from sampling','p':p,'mu':mu,'theta':float(theta),'physical_support_trials':physical_trials,'max_physical_support_bound_ratio':max_physical_ratio,'max_actual_channel_support_bound_ratio':max_dynamic_ratio,'two_sided_driven_smoothing':smoothing,'max_half_noise_tilted_Hermitian_eigenvalue':max(tilt),'Hamiltonian_schedule_noncommutator_norm':float(np.linalg.norm(K0@K1-K1@K0,2))}
pathlib.Path(__file__).with_name('AUDIT_BIASED_GLOBAL.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
