# Biased reset registers: independent construction and audit

8 November 2026. Reviewed principal file
`principal/BIASED_RESET_CONSTRUCTION.md`, SHA256
`081033fb1dc3d8856babe010c849fc02090c189455e1e62b6a99838d988295ed`.
This includes the shared-history, inverse, accuracy-cap and basis-rounding
repairs. The initial constructor report is unchanged. No new researcher used.

## Verdict and exact scope

**The retained-register buffer closes at full finite-bit cost.** It represents
known biased replacement by genuinely unitary enlarged histories, and the
required storage is polynomial after a uniform count cap. Together with the
weighted premises audited below, it supports the proposed all-time fixed-local
2D predictor for a **common faithful product reference and conserving local
Hamiltonian blocks**.

**The bounded-cut full-output TV sampler extends too**, including arbitrary
correlated supplied locally purified TTN inputs on the same tree. Its proof
needs only common-reference entropy decay and the trajectory construction, not
weighted HC or sparse propagation. Generic 2D full sampling remains open.

The short-time buffer alone does not need reference conservation. Conservation
is used for the all-time cutoff and for the 2D weighted sparse/smoothing stage.
No arbitrary-Hamiltonian nonunital all-time theorem, pure-reset all-time 2D
theorem, interacting-Gibbs solver, physical bath monitoring or practical speed
claim follows.

## 1. Exact dilation, including an entangled discarded state

For a physical site S, fresh qubit A and arbitrary external system R,

`Tr_A[SWAP_SA (rho_SR tensor sigma_A) SWAP_SA^dagger]
 = sigma_S tensor Tr_S rho_SR`.

Sample the known ensemble `sigma=p|0><0|+(1-p)|1><1|`, append its pure label
register, SWAP, and **keep the old state in A**. That old state may be entangled
with R. Tracing it at the end is equivalent to tracing immediately because it
never participates in a later physical interaction. The physical slot S keeps
evolving. The thermal label's weight is independent of rho.

An Euler factor has alternatives with rational probabilities

`1-gamma h`, `gamma h p`, `gamma h(1-p)`.

They exactly average to `(1-gamma h)Id+gamma h R_sigma`. Every complete
history is therefore unitary on physical qubits, their input purifiers and
the sampled fresh registers. All those fresh registers may equivalently be
preallocated. No mixed-unitary assertion about the physical reset is used.

Every register is labelled by its spatial site and reset index. Both parity
vectors must use the **same history, thermal bits and coordinate labels**;
`U_B^dagger` is the exact reverse of that same strip circuit, including swaps.
No event or thermal bit is resampled during reversal. The final observable is
identity on the old registers and input purifiers. These rules are now present
in the pinned principal file.

## 2. Spatial locality and nuclear growth remain dimension independent

Group every register at a site into one local space. SWAP is inside that
space, so it preserves Schmidt coefficients across every spatial cut. In a
toggling frame the Hamiltonian acts on different internal slots but retains
the same spatial support, norm, range and instantaneous block incidence.

A k-qubit block of norm <=J has Pauli coefficient one-norm <=`2^k J` by
Cauchy--Schwarz. Within the **buffer reference** it may be decomposed into
these physical Pauli terms; their failure to conserve sigma is harmless
because the full channel error is explicitly paid. In the sparse stage the
whole conserving block must instead be used.

Factorial LR estimates count paths of spatial supports and bound commutator
norms. These constants do not depend on the dimension of a grouped site. A
colored Pauli approximation has coherent duration `C_(k,d)s` independently
of the fine-step count. Thus the original factorial tail and strip width
remain valid in the enlarged trajectory.

Across a strip row cut, accumulated crossing angle is at most
`C_(a,k,d) b J s`, where b is strip width. Consequently

`N(psi_exact)<=B_star=exp(C_(a,k,d)bJs)`.

Reset count does not appear in this exponent. On-site insertions and swaps
have zero crossing cost.

## 3. Parity overlap for contractions rather than unitaries

Let a retained basis product F have r occupied factors. Choose a computable
integer `C_mu>=max_j ||F_j||` and normalize it by `C_mu^r`, scaling only
occupied factors. The resulting observable is a product of Hermitian
one-site contractions A_i.

For one enlarged U, set `Q_j=U^dagger A_(central strip j)U`. These are
commuting Hermitian contractions. Therefore

`<product_even Q_j psi, product_odd Q_j psi>
 =<psi, product_all Q_j psi>`.

The identity requires Hermiticity and commutation, not `Q_j^2=I`.
Localized factors `V_j=U_(B_j)^dagger A_j U_(B_j)` retain every on-site
reset in B_j and only interactions contained there. Same-parity B_j are
spatially disjoint, including all their old registers. Each V_j is a
contraction; product telescoping pays the sum of its LR errors. Opposite-
parity V_j need not commute.

Each parity vector is a product of strip vectors, with a known MPS order.
The orders can differ, but all register-coordinate labels are shared and
can be reordered digitally. The symmetrized overlap estimator remains bounded
by one when approximate vectors have norms at most one.

## 4. Explicit count cap and its bias budget

For one nonempty strip row R, the reset count is Poisson-binomial with

`mu_R=E N_R<=|R|gamma s<=C b gamma s`.

Independent Euler choices give `E exp(N_R)<=exp((e-1)mu_R)`, independently
of how finely time was partitioned. If N_row is the number of nonempty rows
over all enlarged strips and both parities, choose

`K_R=ceil(3mu_R)+ceil(log_2(4N_row/eta_hist))`.

Then `Pr[N_R>K_R]<=eta_hist/(4N_row)` by exponential Markov inequality,
using `e-1<2` and `exp(-ceil(log_2 x))<=1/x`. Every site is in only a
constant number of enlarged strips, so `N_row<=C m`. A union bound controls
all caps.

Output scalar zero on a failed history, without rejection. Its normalized
functional has magnitude <=1, so the mean bias is at most the failed mass.
Use `eta_hist=xi/100`, where xi is normalized buffer accuracy. This is a
**bias allocation**, not a confidence allocation and not a demand that every
Monte Carlo repetition avoids failure.

With `s=O_mu(log log Q)/gamma` and `b=O(log Q/log log Q)`,

`K_R=O_mu(log Q)`, `q_row<=2^[C b+K_R]=Q^O_mu(1)`.

The exponent includes all physical qubits, initial local purifiers and kept
old registers in that row. Count monotonicity permits immediate abort on
overflow. No large register allocation occurs on a failed history.

## 5. Finite bits, MPS construction and errors

Partition at actual rational switches. A rational colored Pauli Cayley/Euler
reference with gamma h<=1 reaches channel error xi/100 with a polynomial
total number of steps. Use the segmentwise error allocation already proved
for the original construction, which depends on the total physical generator
action and the number of intervals, never inverse minimum interval length.

Sample ideal rational thermal/event coins to fixed dyadic precision with
total TV error <=xi/1000. This changes a bounded mean by at most twice that
amount and also pays any change in cap probability. Thermals are sampled
pure bits; no square-root probability amplitudes are needed. Input local
purifications and F_j insertions have their own certified dyadic error budget.

Retained histories have polynomial row dimension and
`log B_star=O(bJs)=O(log Q)`. The original constructive Schmidt truncation
lemma therefore produces the two strip MPSs at polynomial bond and vector
accuracy xi/100. Local swaps are exact permutations within a grouped row;
on-site contractions do not amplify vector error. Certified norm caps keep
the approximate vectors subnormalized. Gap-free residual-operator-norm
compression, described in the initial constructor report, avoids any inverse
Schmidt-gap condition. Every SVD matrix has polynomial dimension.

Rational dyadic MPS norm and amplitude contractions have polynomial bit
height. Approximate categorical choices with a paid sum of TV errors. The
bounded overlap average needs `O(xi^-2 log(1/beta))` repetitions for confidence
1-beta. Failed histories contribute zero samples; conditioning on successful
caps would change the target and is not used. All branches have fixed
polynomial work.

Finally let `W_ret=sum_j |b_j| C_mu^(r_j)`, polynomial by the weighted weight
pruning. Normalize buffer errors by
`xi=epsilon/[C max(1,W_ret)]`. Cap and all other buffer biases use this xi.
The original spare constant budgets complete the total epsilon guarantee.

## 6. Weighted premises independently checked

The printed symmetric weighted HS basis is correctly normalized. X,Y have
squared norm `2sqrt(p(1-p))`; centered Z has squared norm `4p(1-p)`.
Reset is exactly minus gamma times occupied weight. A commuting block is
skew in this metric, with induced two-norm <=2J and coefficient one-norm
generator bound <=`2^(k+1)J`. Allocating gamma/d over incident supports
preserves an active-sector damping margin. Identity is fixed and its local
orthogonal complement is invariant. Coefficient-p interpolation therefore
has a fixed p<2, with <=4^k branches per input coefficient.

The local tilted skew entries are bounded by a constant times
`J sinh(k theta)`, since coupled weights differ by at most k. The chosen
theta lets damping absorb their row sum. Pruning decreases both tracked
norms. Predeclared doubled budgets and the repaired rounding allocation
including weighted-HS error eta control finite arithmetic. The resulting
retained weight bound is logarithmic. Exponential smallness of nu in m
requires only O(m+log Q) precision bits. The algebraic basis transform's
conditioning is paid by the additional O(m log C_mu) bits now present.

I independently opened the primary [Dong--Gao--Ou--Yao--Zhou,
arXiv:2606.17729v1](https://arxiv.org/html/2606.17729v1), Theorem 1.1 and
Lemma 3.2. The theorem explicitly covers **every operator**, tensor powers
and full-rank sigma, with time
`[3 ln2/(8a_sigma)]ln[(q-1)/(p-1)]`. This is its generalized depolarizing
application, not an unrestricted import of broader PODS statements. The
principal's convention `c_sigma=8a_sigma/(3ln2)` is correct. Retain the
source's earlier exact-qubit credit to Beigi--Datta--Rouze.

A useful fully rational algorithmic choice avoids evaluating c_sigma:

`a_sigma=(1-2mu)/ln((1-mu)/mu)>=mu`, by `ln x<=x-1`,

so `c_sigma>=2mu`. Put

`A_mu=ceil(log_2(1/mu))`,
`b=ceil(log_2(2 A_mu m))`, `s=b/(2mu gamma)`.

In the proof choose `q=1+exp(b)`. HC applies and
`mu^(-m/q)<=sqrt(2)<2`. Neither exp(b) nor an exact real rate constant is
evaluated by the algorithm. All supplied s values are rational and retain
the required `O_mu(log m)/gamma` duration.

No mathematical gap was found in these premises at the stated scope. The
general finite-bit algorithm has not been run.

## 7. Full-output biased-reset TV theorem on bounded supplied cuts

Use the initial constructor theorem's degree-three leaf tree and constant
crossing-block bound c. Supply a finite rational schedule of k-site blocks
of norm <=J and incidence <=d, each conserving the common product reference
on its support. Every site has replacement rate gamma into the same known
full-rank rational sigma. Supply any normalized locally purified rational
TTN input on this tree, with maximum bond D0 and fixed initial local
purification dimension r0.

**Theorem.** At fixed k,d,c,J/gamma and mu>0, the entire computational-basis
output has a TV-epsilon classical sampler with polynomial bit work in n,
complete input bits, schedule length, D0 and epsilon^-1. Supplied terminal
product POVMs are also permitted. This theorem changes the architecture;
it is not a generic 2D sampler.

**Proof.** Convexity plus quantum Shearer gives

`D(rho_t||sigma^n)<=n ln(1/mu) exp(-gamma t)`.

Reference commutation makes the Hamiltonian derivative zero. This holds for
arbitrary correlated rho_0. Let

`A_mu=ceil(log_2(1/mu))`,
`L=ceil(log_2(32(n+1)(A_mu+1)/epsilon))`.

For `gamma T>=2L`, Pinsker bounds trace distance to sigma^n by epsilon/16;
sample this known product law. Otherwise `gamma T<2L` and `JT<2(J/gamma)L`.
Construct a rational Pauli/Euler reference with diamond error epsilon/100.
The exact-channel conservation is used for mixing; the finite approximant
may break it because ordinary channel error is directly paid.

At each leaf the reset count has mean <=gamma T. Cap it by

`K_leaf=ceil(3gamma T)+ceil(log_2(400n/epsilon))`.

Failure anywhere has probability <epsilon/100. On failed histories output a
fixed physical bitstring or the reference law, with TV cost at most that
mass and no rejection. Retained leaf dimensions satisfy

`q_leaf<=2r0 2^(K_leaf)=poly_mu(n,epsilon^-1)`.

For every tree edge the crossing angle is <=`2^k cJT`; hence

`N(psi_exact)<=sqrt(D0) exp(2^k cJT)`.

All local swaps preserve the edge Schmidt coefficients. The original
constructive TTN compression lemma, with polynomial leaf dimensions and
nuclear bound, supplies uniform vector error epsilon/100. Its normalization
gives O(epsilon) conditional TV error. Sample physical plus old/purifying
coordinates from the rational TTN and discard the latter. Finite coin errors,
cap mass and channel approximation fit the remaining budget. Tighten fixed
fractions as necessary.

The work before cutoff has envelope

`poly(B,n,M,D0,epsilon^-1,q_leaf) exp(O(2^k cJT))`.

This is polynomial at the fixed declared parameters. It is not noise-uniform.
Weighted HC is not needed for this theorem. Without reference compatibility,
the same trajectory algorithm still works on bounded cuts through a supplied
logarithmic physical horizon, but no all-time cutoff was proved.

**Uniform rational-faithfulness refinement, only for this TV theorem.** If
the same sigma is supplied as an explicit full-rank rational qubit state,
its complete input height bounds `A_mu<=B+1`. Consequently
`L=O(log(n(B+1)/epsilon))`. Leaf register dimensions and the crossing nuclear
bound are polynomial in full input bits, with degree depending on k,c,J/gamma
and not mu. Thermal sampling uses the rational p directly, never inverse p;
no weighted basis or weighted HC enters this sampler. Thus fixed mu is
unnecessary **for the bounded-cut TV theorem** when its rational description
is fully charged. This does not remove the faithful-reference dependence of
the arbitrary-2D weighted predictor and does not include a rank-deficient
reference under the stated entropy argument.

## 8. Executed independent fixtures and ledger

`audit_biased_reset.py` and `AUDIT_BIASED_RESET.json` check a p=0.3 reference
and a conserving XX+YY+ZZ block. Results:

* weighted Gram residual 2.23e-16; weighted skew residual 1.05e-16;
* Hamiltonian/weight commutator norm 1.4, so this is an actual noncommuting
  Hamiltonian-plus-reset test, not a tensor-noise-only fixture;
* 100 actual-channel weighted HC tests at q=2.5,3,4,8, including non-Hermitian
  inputs, all ratios <=1 to roundoff (identity attains one);
* complete nine-branch retained-SWAP Euler mixture on an entangled input,
  error 1.35e-16; spatial nuclear norm change under local swaps zero;
* crossing-angle bound ratio <=0.939;
* an 80-trial unequal-Bernoulli cap tail 1.48e-18 below its 3.58e-4 bound.

These are finite diagnostics, not a full general algorithm execution.

| Claim | Status |
|---|---|
| Exact retained-register biased replacement and contraction parity identity | Proved |
| Dimension-independent locality and zero reset crossing action | Proved |
| Polynomial reset storage with a uniform finite cap and paid bias | Proved |
| Proposed common-reference fixed-local 2D predictor | Supported by checked weighted premises and this completed buffer |
| Bounded-cut full-output TV sampler with faithful biased reset | Proved extension, Section 7 |
| Same bounded-cut TV theorem with rational full-rank sigma varying in the input | Proved refinement; A_mu paid through input height B |
| Generic nonunital all-time 2D or generic 2D full sampler | Not obtained |
| Historical novelty or practical advantage | Unverified / not demonstrated |
