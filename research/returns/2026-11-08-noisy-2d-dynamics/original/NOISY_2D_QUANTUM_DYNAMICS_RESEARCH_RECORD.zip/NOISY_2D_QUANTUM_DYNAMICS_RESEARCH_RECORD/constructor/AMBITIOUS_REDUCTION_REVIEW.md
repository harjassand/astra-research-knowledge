# Independent hostile review of the rare-relative-probability reduction

8 November 2026. Reviewed `initial/ambitious.md`, SHA256
`313fbcf6e47519842f82cbd7e4a7cefaaee8d0e211306bf247599b0bebc711b5`.
Primary Moore--Robson PDF inspected through its cached text, including Sections
2, 3 and 3.2; PDF SHA256
`2c503a199e2268022c2f7df0bdb654f33fc6174eb5b33dfa6e9a597888d215b0`.
No initial report was changed and no additional researcher was used.

## Verdict

**The leading-coefficient reduction and exponentially short-time separation
are correct at the stated scope.** I found no lower-degree noise contribution,
factorial error, phase cancellation or unpaid inverse-time cost. The mixed-
tile one-Y construction correctly aligns covers with different tile counts.
The imported counting scope is also correctly separated from the tromino-only
decision theorem.

Thus uniform polynomial-bit log/constant-relative evaluation over **all
positive rational times** in the original bounded-local 2D class would have
the stated randomized NP consequence. The four-body mixed-tile family also
encodes the parsimonious SAT count to the stated approximation precision.

This is **not full-output TV hardness**, not an exclusively two-body result,
and not a result under a fixed positive lower-time promise. These limits are
essential. The physical rare events cost exponentially many ordinary shots;
the reduction is not a demonstrated quantum advantage.

## 1. Independent leading-order accounting for Theorem A

Represent a density matrix unit as `|a><b|`, with 2n binary ket/bra coordinates.
To end at `|1^n><1^n|`, all 2n coordinates must be flipped an odd number of
times. A left or right X-tromino multiplication flips exactly three. A
single-site Pauli conjugation flips at most two; an identity/diagonal action
flips zero. The alternative direct reset representation gives the same bound.

If n=3m, every word shorter than r=2m fails. A word of length r must use
only Hamiltonian factors and flip each coordinate exactly once. It therefore
contains m disjoint tiles covering the ket and m disjoint tiles covering the
bra. Neither an X/Y noise event nor any negative identity contribution can
occur at that leading order. This uses replacement jump coefficient gamma/4
for each X,Y,Z; it does not assume a noise layer commuting through H.

For each ordered pair of covers, all r! interleavings of the distinct left/
right tile factors occur in L^r. Their contribution is one after dividing
by r!. Equivalently, on each side m! orderings cancel m!, and the two phases
`(-i)^m` and `(+i)^m` cancel. Consequently the leading coefficient is exactly
the squared integer cover count q_R^2. Overlapping tiles cannot enter it:
they would spend a coordinate flip twice and leave another unflipped.

All X terms commute, as claimed, even when their spatial supports overlap.
Every site belongs to at most 4 unit squares and 3 of their L-trominoes,
giving incidence at most 12. Counting support incidences also gives
`M<=4n`. The construction is k=3, maximum-metric range one and J=1.

## 2. Exponentially small time and the complete bit separation

For arbitrary complex trace-class matrices, each Pauli commutator has induced
trace-norm bound <=2, and each replacement difference has bound <=2. Therefore
an integer `C>=max(1,2M+2gamma n)` is valid. For `0<t<=1`,

`sum_[ell>=r+1] C^ell t^ell/ell! <=e^C t^(r+1)`.

This apparently weak bound is enough. At
`T=2^-(2C+20)`,

`e^C T =2^-20 (e/4)^C <2^-20`.

The relative leading-scale remainder is therefore less than 2^-20. No
factor C^r or r! was lost; it is bounded inside the full exponential sum.

If untileable, `p(T)<=2^-20 T^r`; if tileable,
`p(T)>=(1-2^-20)T^r`. Comparing a log estimate with `r log T-1` leaves
far more than a 1/4 margin on both sides. Computing this threshold requires
only certified log 2 at polynomial precision: `r log T` is an integer of
O(n^2) magnitude times log 2. The logarithm's output length is polynomial.

At every fixed rational gamma>0, C=O_gamma(n), so the dyadic time has O_gamma(n)
binary denominator bits. The original complexity contract charges complete
bits and numeric 1+T, **not 1/T**. It would be incorrect to exclude the instance
because a physically tiny time is difficult to use experimentally; it is a
valid finite input for the asserted uniform log evaluator.

Strict positivity is also valid. Exactly one X jump per site and no other
jumps has probability
`exp(-3gamma nT/4)(gamma T/4)^n>0`. These jumps commute with the X Hamiltonian,
so the conditional target amplitude is `<0|exp(-iTH)|0>` and is at least
`1-MT` in magnitude. This is positive at the chosen T. Its lower bound also
shows `-log p(T)=O_gamma(n^2)`; no exponentially long output numeral is hidden.

Amplification supplies a randomized NP decision algorithm. SAT self-reduction,
polynomially amplified calls and final witness verification turn it into RP:
unsatisfiable instances are never accepted after verification, while satisfiable
ones yield a witness with bounded success probability. Thus the report's
`NP subset BPP` and strengthened `NP=RP` implications are sound. No complexity
separation is asserted proved.

## 3. Mixed tile sizes: the phase and degree repair is real

For a tile S, exactly one Y gives
`P_S|0^S>=i|1^S>`. A disjoint m-tile ket cover therefore has phase
`(-i)^m i^m=1`; the bra has the same real positive phase. This holds for
each cover separately, even if two covers have different numbers of tiles.
It would fail for all-X mixed-size tiles.

The substitution `T=tau^3` and four-body coefficient tau makes a three-site
Hamiltonian operation have degree three and a four-site operation degree
four. Both degrees equal their number of flipped ket/bra coordinates. Noise
has degree three but flips at most two. Thus no degree below 2n reaches the
target; at degree 2n only disjoint covers on both sides occur. Every cover
has ket degree n regardless of tile count, and its ordered factors cancel
the appropriate exponential factorial. The resulting probability coefficient
is exactly Z_R^2.

For `T L(tau)=tau^3 A+tau^4 B`, the coefficientwise norm majorant is
`exp(||A|| z^3+||B|| z^4)`. Its sum at z=1 is at most e^C. Hence all terms
of degree >=2n+1 sum in magnitude to at most `e^C tau^(2n+1)` on [0,1].
The supplied dyadic tau pays the remainder uniformly. Noncommuting overlapping
terms cause no problem: they cannot occur at the leading degree, and the norm
majorant covers them at all later degrees.

The same one-X-per-site event proves positivity here in a toggling frame.
Its Hamiltonian is sign-conjugated but has norm <=M3+tau M4 throughout, so
its propagator differs from identity by at most `(M3+tau M4)T`. Commutation
of X jumps with the one-Y Hamiltonian is neither true nor needed.

The primary Moore--Robson Section 2 explicitly describes the Boolean circuit
reduction as parsimonious, after unique-tiling AND/NOT gates, fanout and
polynomially separated wire routing. Section 3 proves tromino-only decision
hardness; Section 3.2 explicitly leaves its counting question unsupported.
The report imports exactly the correct distinction. Its source is
[Moore--Robson, math/0003039v1](https://arxiv.org/pdf/math/0003039v1).

For Z_R>=1, a relative probability estimate plus the paid absolute contamination
of the scaled count gives a relative estimate of Z_R^2, and its positive square
root gives the requested relative count. Z_R=0 is detected by the constant
gap. Counts have polynomial bit height because the number of candidate tiles
is O(n). This validates the approximation-preserving accounting, without an
exact coefficient-extraction or differentiation oracle.

## 4. A constructive rectangle-padding refinement

If a strict physical class demands a full rectangular square-lattice region,
the full-output probability obstruction can also be retained, not only its
arbitrary-marginal version. Use the polynomial-size bounding rectangle of the
Moore--Robson constructed region. Leave extra sites uncoupled, initialize them
in |0>, and request outcome 0 there and 1 on the active region. The complete
probability is

`p_rect(T)=p_R(T) [(1+exp(-gamma T))/2]^(N_extra)`.

This known factor has a polynomial-bit computable logarithm. Subtracting it
from a log estimate preserves the gap with a slightly tighter error budget.
Alternatively include all padded sites in C: their target has constant
coefficient one, so the original leading active-region coefficient and tail
proof are unchanged. Time remains polynomial-bit and every padded site has
the original replacement noise. This refinement uses the produced tiling
family's polynomial coordinate extent; it does not pad an arbitrary huge
succinct bounding box for free.

The target need not be the all-one string after padding. The original full
computational-outcome problem permits a specified explicit bitstring, so this
does not change its task interface.

## 5. TV and quantifier boundaries survive the hostile review

`TV(P_T,delta_0)<= (exp(CT)-1)/2` tends to zero exponentially on these
instances. A fixed initial output is already a valid inverse-polynomial TV
sampler. No amplification in the reduction promotes rare-event relative
hardness to TV hardness. Prefix conditioning inherits the obstruction only
if enough log-conditional accuracy is supplied to sum to a constant error.

The reduction uses:

* fixed positive gamma/J with gamma rational and J=1;
* k=3 for decision and k=4 for the mixed-count construction;
* times whose values shrink exponentially while their descriptions stay short;
* global rare output events, not additive fixed-local means.

It does not address two-body-only classes, a fixed positive minimum-time
promise, the common-reference biased-reset conserving class, or all-time
TV sampling. In particular the Hamiltonians flip excitation number and
cannot be imported into the proposed conserving biased model unchanged.

## 6. Independent exact fixtures

`audit_ambitious_independent.py` and
`AUDIT_AMBITIOUS_INDEPENDENT.json` use a **Pauli-basis density-series**
implementation distinct from the original report's matrix-unit walk.
Exact Fraction arithmetic at gamma=1 and 7 verifies single L-tile, 2x3
rectangle, untileable six-site line, and mixed 2x2 examples. All lower
coefficients vanish and all displayed leading coefficients equal squared
cover counts.

A separate 12-site 2x6 fixture addresses a case absent from the small original
examples: it has four covers using four trominoes and one using three square
tetrominoes. Exact weighted ket-series enumeration gives one-Y leading
amplitude **5** and probability coefficient **25**. With all-X terms the
amplitude is **4+i** and probability coefficient **17**. This independently
tests the genuinely necessary variable-tile-count phase alignment.

These fixtures supplement the proof. They do not establish the NP import,
uniform lower bounds or historical priority. The original claimed CP shortcut
obstruction is separate from the reviewed leading-order reduction; no high-
noise sampler theorem was imported to justify the latter.

| Claim | Independent review |
|---|---|
| Theorem A leading q_R^2 coefficient, including continuous noise | Pass |
| Exponentially short-time tail and polynomial binary description | Pass |
| Strict positivity and finite logarithm output | Pass |
| Theorem B one-Y phase / degree-balanced Z_R^2 encoding | Pass |
| Moore--Robson decision versus parsimonious count scopes | Pass |
| Full rectangular-grid padding with specified full target string | Proved refinement, Section 4 |
| Original-class full-output TV hardness | Not obtained; reduction explicitly does not supply it |
| Two-body-only or positive-minimum-time relative hardness | Open here |
| Historical firstness or practical quantum advantage | Not established |
