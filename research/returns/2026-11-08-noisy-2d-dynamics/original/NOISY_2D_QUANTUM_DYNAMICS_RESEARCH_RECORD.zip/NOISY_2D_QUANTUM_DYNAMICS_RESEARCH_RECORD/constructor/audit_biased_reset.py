#!/usr/bin/env python3
"""Small finite reset-register checks. Not a uniform algorithm implementation."""
import itertools,json,math,pathlib
import numpy as np
rng=np.random.default_rng(2026110811)
I=np.eye(2,dtype=complex);X=np.array([[0,1],[1,0]],complex);Y=np.array([[0,-1j],[1j,0]],complex);Z=np.diag([1.,-1.]).astype(complex)
def kronall(xs):
 out=np.ones((1,1),complex)
 for x in xs:out=np.kron(out,x)
 return out
def gate(v,U,inds,n):
 inds=list(inds);axes=inds+[i for i in range(n) if i not in inds]
 mat=v.reshape([2]*n).transpose(axes).reshape(2**len(inds),-1)
 out=(U@mat).reshape([2]*n).transpose(np.argsort(axes)).reshape(-1)
 return out
def swap(v,i,j,n):
 axes=list(range(n));axes[i],axes[j]=axes[j],axes[i]
 return v.reshape([2]*n).transpose(axes).reshape(-1)
def reduced(v,inds,n):
 axes=list(inds)+[i for i in range(n) if i not in inds]
 mat=v.reshape([2]*n).transpose(axes).reshape(2**len(inds),-1)
 return mat@mat.conj().T
def nuclear(v,inds,n):
 axes=list(inds)+[i for i in range(n) if i not in inds]
 return np.linalg.svd(v.reshape([2]*n).transpose(axes).reshape(2**len(inds),-1),compute_uv=False).sum()
def reset(rho,i,sigma):
 # Explicit index contraction to replace physical site i.
 n=int(round(math.log2(len(rho))));others=[j for j in range(n) if j!=i]
 resh=rho.reshape([2]*(2*n));red=np.trace(resh,axis1=i,axis2=n+i)
 out=np.zeros_like(rho)
 for a in itertools.product(range(2),repeat=n):
  for b in itertools.product(range(2),repeat=n):
   ar=tuple(a[j] for j in others);br=tuple(b[j] for j in others)
   out[int(''.join(map(str,a)),2),int(''.join(map(str,b)),2)]=sigma[a[i],b[i]]*red[ar+br]
 return out
p=.3;sig=np.diag([p,1-p]);z=2*p-1
F=[I,X/math.sqrt(2*math.sqrt(p*(1-p))),Y/math.sqrt(2*math.sqrt(p*(1-p))),(Z-z*I)/(2*math.sqrt(p*(1-p)))]
shalf=np.diag(np.sqrt([p,1-p]));gram=np.array([[np.trace(shalf@a.conj().T@shalf@b) for b in F] for a in F])
H=.35*np.kron(X,X)+.35*np.kron(Y,Y)+.2*np.kron(Z,Z)+.1*(np.kron(Z,I)+np.kron(I,Z))
h=.07;gamma=.6
Id=np.eye(4);U=(Id-1j*h*H/2)@np.linalg.inv(Id+1j*h*H/2)
comm=float(np.linalg.norm(H@np.kron(sig,sig)-np.kron(sig,sig)@H,2))
# physical sites 0,1, old purification coordinates 2,3, preallocated reset registers 4,5.
base=np.zeros(16,complex);base[0]=1/math.sqrt(2);base[12]=1/math.sqrt(2)
rho0=reduced(base,[0,1],4)
rho=U@rho0@U.conj().T
for site in [0,1]:rho=(1-gamma*h)*rho+gamma*h*reset(rho,site,sig)
mixture=np.zeros((4,4),complex);max_swap_change=0.;max_cross_ratio=0.
for choices in itertools.product([-1,0,1],repeat=2):
 probability=1.;bits=[]
 for a in choices:
  probability*=1-gamma*h if a==-1 else gamma*h*(p if a==0 else 1-p)
  bits.append(0 if a==-1 else a)
 anc=np.zeros(4);anc[2*bits[0]+bits[1]]=1
 v=np.kron(base,anc)
 # Local-register nuclear norm is invariant under each SWAP.
 init=nuclear(v,[0,2,4],6)
 v=gate(v,U,[0,1],6)
 max_cross_ratio=max(max_cross_ratio,float(nuclear(v,[0,2,4],6)/(init*math.exp(.9*h))))
 for site,a in enumerate(choices):
  if a!=-1:
   before=nuclear(v,[0,2,4],6);v=swap(v,site,4+site,6)
   max_swap_change=max(max_swap_change,abs(float(nuclear(v,[0,2,4],6)-before)))
 mixture+=probability*reduced(v,[0,1],6)
reset_error=float(np.linalg.norm(mixture-rho,2))
# Weighted actual-channel checks; H does not commute with the reset generator.
def expm(A):
 scaling=max(0,int(math.ceil(math.log2(max(1.,float(np.linalg.norm(A,1)))))))
 B=A/(2**scaling);out=np.eye(len(A),dtype=complex);term=out.copy()
 for j in range(1,150):
  term=term@B/j;out+=term
  if np.linalg.norm(term,1)<1e-16:break
 for j in range(scaling):out=out@out
 return out
FF=[np.kron(a,b) for a in F for b in F]
Sigma=np.kron(sig,sig);Sighalf=np.diag(np.sqrt(np.diag(Sigma)))
K=np.array([[np.trace(Sighalf@a.conj().T@Sighalf@(1j*(H@b-b@H))) for b in FF] for a in FF])
wt=np.array([(i!=0)+(j!=0) for i in range(4) for j in range(4)],dtype=float)
G=K-gamma*np.diag(wt)
skew_error=float(np.linalg.norm(K+K.conj().T,2))
noise_comm=float(np.linalg.norm(K@np.diag(wt)-np.diag(wt)@K,2))
theta=min(1/4,gamma/(16*1*2*16))
D=np.diag(np.exp(theta*wt));tilt=D@G@np.linalg.inv(D)
max_tilt=float(np.linalg.eigvalsh((tilt+tilt.conj().T)/2).max())
def normq(A,qexp):
 sandwich=np.diag(np.diag(Sigma)**(1/(2*qexp)))
 sv=np.linalg.svd(sandwich@A@sandwich,compute_uv=False)
 return float(np.sum(sv**qexp)**(1/qexp))
mu=min(p,1-p);alpha=(1-2*mu)/math.log((1-mu)/mu);csigma=8*alpha/(3*math.log(2))
hc_rows=[]
for qexp in [2.5,3.,4.,8.]:
 duration=math.log(qexp-1)/(csigma*gamma)
 propagator=expm(duration*G);maxratio=0.
 for j in range(25):
  A=np.eye(4,dtype=complex) if j==0 else rng.normal(size=(4,4))+1j*rng.normal(size=(4,4))
  if j%2:A=(A+A.conj().T)/2
  coeff=np.array([np.trace(Sighalf@f.conj().T@Sighalf@A) for f in FF])
  evol=sum(c*f for c,f in zip(propagator@coeff,FF))
  maxratio=max(maxratio,normq(evol,qexp)/normq(A,2.))
 hc_rows.append({'q':qexp,'duration':duration,'trials':25,'max_weighted_norm_ratio':maxratio})
 assert maxratio<=1+1e-11
assert skew_error<1e-12
assert noise_comm>.01
assert max_tilt<1e-12
# An explicit Poisson-binomial tail with varying Euler intervals.
probs=np.linspace(.01,.19,80);mean=float(probs.sum());Nrows=7;eta=.01
cap=math.ceil(3*mean)+math.ceil(math.log2(4*Nrows/eta))
weights=np.array([1.])
for prob in probs:weights=np.convolve(weights,[1-prob,prob])
tail=float(weights[cap+1:].sum()) if cap+1<len(weights) else 0.
bound=eta/(4*Nrows)
assert comm<1e-12
assert np.max(np.abs(gram-np.eye(4)))<1e-12
assert reset_error<1e-12
assert max_swap_change<1e-12
assert max_cross_ratio<=1+1e-12
assert tail<=bound
out={'scope':'small finite numerical checks only','sigma_p':p,'weighted_gram_residual':float(np.max(np.abs(gram-np.eye(4)))),'common_reference_commutator_norm':comm,'exact_reset_register_mixture_error':reset_error,'max_local_swap_nuclear_change':max_swap_change,'max_crossing_angle_bound_ratio':max_cross_ratio,'weighted_skew_residual':skew_error,'Hamiltonian_weight_commutator_norm':noise_comm,'max_tilted_generator_eigenvalue':max_tilt,'actual_channel_HC_checks':hc_rows,'poisson_binomial_cap':{'trials':len(probs),'mean':mean,'cap':cap,'actual_tail':tail,'claimed_upper_bound':bound}}
pathlib.Path(__file__).with_name('AUDIT_BIASED_RESET.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
