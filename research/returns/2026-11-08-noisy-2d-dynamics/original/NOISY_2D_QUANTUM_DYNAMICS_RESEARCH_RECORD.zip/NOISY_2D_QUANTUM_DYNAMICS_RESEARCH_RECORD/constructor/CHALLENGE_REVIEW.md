# Constructor's post-exchange challenge review

8 November 2026. The initial constructor report remains unchanged at SHA256
`4c6e17df225552c056d9e04ba146b33f307bea982ec7b149e3dc33372580281f`.
This review follows authorized exchange and examines `initial/machinery.md` and
`principal/LOCAL_ROBUST_PREDICTION.md`. It is not an independent initial return.

## Verdict on the global product-readout theorem

The mathematical core survives my independent check. I found no counterexample
to the varying-weight smoothing, its dual orientation, support-sensitive
hypercontractivity, early global-buffer branch, or rational-axis mixture. The
new theorem strictly subsumes my initial polylog-support scalar extension. The
proper combined scalar endpoint is **all-support tensor products of one-qubit
Hermitian contractions**, with the input and noise restrictions preserved.

This remains additive prediction. In particular an additive prefix-probability
oracle does not pay full sampling, and no exponential rare-event denominator
can be suppressed in the resource account.

### 1. Tilted active-block estimate

For an anticommuting Pauli partner pair under a k-site Pauli term, both partners
are nonidentity on at least one site of that term. If either were identity on
all its sites, anticommutation would be impossible. Allocate gamma/(2d)
replacement damping on each incident support site. Thus both partner diagonal
entries have damping at least gamma/(2d).

Conjugating a skew pair of magnitude 2h by `exp(alpha W)` produces a Hermitian
off-diagonal magnitude `2|h sinh(alpha Delta_w)|`, with `|Delta_w|<=k`.
For `k alpha<=1/2`, `sinh(k alpha)<=2k alpha`. The chosen
`alpha<=gamma/(16kdJ)` therefore leaves a strictly negative active-sector
margin. The unused half-noise supports the derivative of alpha. There is no
missing factor of four between replacement and Pauli-jump rates.

### 2. Varying weight and duality

The derivative is

`d/dt [S_alpha(t) U_H(t)X]
 = [S_alpha G_half S_alpha^-1 +(alpha'-gamma/2)W]
    S_alpha U_H(t)X`.

Here S_alpha commutes with W, and alpha' is at most gamma/2. The norm is
nonincreasing, including across the corner at t0 by continuity.

For a static Hamiltonian, `G_H^*=G_-H` in normalized HS norm. Taking the
adjoint of `||S_alpha exp(tG_-H)||_(2->2)<=1` gives exactly
`||exp(tG_H)S_alpha||_(2->2)<=1`, not an incorrectly commuted weighted norm.
This earns suppression of a homogeneous initial weight-r input.

For a time-dependent schedule the same result requires the **sign-reversed,
time-reversed schedule**. If `U_H(T,0)` is the ordered linear propagator,
its adjoint is generated in forward auxiliary time by `G_H(T-u)^*`.
The source explicitly states this orientation. The scalar extension to
prescribed drives can therefore be combined with the principal's correctly
ordered early/later channel split; no static commutation identity is needed.

### 3. Arbitrary axes are genuinely homogeneous weight

A tensor product of occupied traceless one-qubit Hermitian unitaries has
every Pauli component at the same weight r and normalized HS norm one.
There is no ordinary-Pauli-only assumption in the smoothing lemma. Local
noise kicks reflect the Bloch axes, maintaining both properties. After
moving those kicks to a toggling frame, the final inserted observable remains
a product of one-site Hermitian unitaries, so the parity factors commute and
have norm one. On-site insertions do not increase any Schmidt nuclear norm.

The decomposition `O_i=a_i I+beta_i A_i` obeys
`|a_i|+beta_i<=1` exactly for a Hermitian contraction. Consequently the
identity/axis/zero mixture has total variation mass at most one at each site
and supplies a bounded estimator; it does not secretly have a 2^n one-norm.
When beta is below the requested local tolerance, dropping it pays that
tolerance. Otherwise division by beta costs only the supplied finite precision.
An exactly rational Bloch axis follows from a bounded stereographic chart;
downward-rounded beta maintains the contraction and probability promises.

### 4. Hypercontractivity and the early m=n buffer

King's Corollary 2, equation (17), was independently opened:
<https://arxiv.org/html/1210.8412>. It gives the normalized p-to-q bound when
`exp(-gamma s)<=sqrt((p-1)/(q-1))`. Unit conjugation is an isometry at every
Schatten exponent, so interleaving with an evolving exponent and passing to
the product limit is valid. This also handles the prescribed driven case.

The `2^(m/q)` conversion to operator norm is correct. With
`q>=8m/(theta r)` its cost is at most `exp(theta r/4)`, leaving suppression
`exp(-3theta r/4)` after the earlier smoothing interval.

The apparent trap is m=n in the early direct-buffer branch. It is paid:
localization has `m/r<=C log^2 Q`, so the support-sensitive buffer cutoff is
`O(log log Q)` even when r and m are extensive. The original physical-time
parity-strip construction permits any m up to n at that duration. With
`Lambda=O(log Q)`, strip width is `O(Lambda/log Lambda)`, and

`log(row dimension)=O(Lambda/log Lambda)`,

`log(nuclear bound)=O(strip width * JT)=O(Lambda)`.

The row count, gate count and number of noise choices are polynomial in n.
The full untruncated coefficient matrix is not built. Thus m=n does not
introduce a 2^n operation. It would be wrong to use a global **state** TTN
here: the two scalar parity vectors have different favorable orders, exactly
as in BGM, and their overlap is sampled rather than contracted as a 2D grid.

### 5. Remaining low-weight branch and costs

When r is below its threshold, r is O(log(1/xi)) with a constant depending
on theta. Expanding arbitrary axes costs at most 3^r terms and a coefficient
one-norm at most 3^(r/2), both polynomial in 1/xi at fixed gamma/J. The
localized volume is O(log^3 Q), sparse propagation has polynomial retained
count and denominator height, and its short buffer has duration O(log log Q).
The original fixed-w oversized envelope must not be invoked with growing w;
the machinery report avoids that error and uses the constructive dependence.

The outer product mixture's number of samples is polynomial, inner numerical
failure budgets are divided by their total count, and finite categorical
draws can be coupled with the charged sum of TV errors. Neither exponentially
small amplitudes nor small beta create an uncharged precision oracle.

I regard the global scalar theorem as mathematically supported by these
arguments, conditional only in the same sense as all extensions on the
checked original finite-bit buffer implementation. No new gap was found.

## Verdict on my bounded-cut TV sampler

Its vector/trace/TV proof survives comparison with the global scalar method:
they solve different tasks. The scalar method has no positive final-state
representation, whereas uniform per-history **global vector error** does
control all final measurements. The bounded-cut assumption is what pays that
global approximation. It is not available for a generic 2D grid.

However its **novelty and research priority should be downgraded**. The theorem
is a transparent combination of established TTN manipulation, the original
crossing-angle truncation lemma and entropy mixing. It is useful supporting
capital, not a plausible centerpiece displacing the all-support 2D theorem.
The 1D discrete analogue follows directly from exact logarithmic-depth MPS
simulation plus noise mixing; the continuous-angle and supplied-cut versions
are natural extensions of that same argument.

### Exact predecessor refinements after the initial freeze

1. Shi--Duan--Vidal, quant-ph/0511070v2, has explicit numbered statements:
   Theorem 1 gives TTN canonical form in `O(n chi^4)` basic operations;
   Theorem 2 gives two-qudit reduction in `O(m d^2 chi^4)`;
   Theorems 3 and 4 give relocation and gate updates. The following text
   explicitly gives adaptive generalized local measurement sampling and
   Suzuki--Trotter tree TEBD. These are stronger exact credits than the initial
   report's nonspecific reference to algorithmic constructions. The source is
   <https://arxiv.org/html/quant-ph/0511070v2>.
2. Seitz et al., arXiv:2206.01000v3, Sections 2.2 and 3.2, is a modern
   implementation and cost analysis of these known tree operations:
   <https://arxiv.org/html/2206.01000v3>.
3. Shao et al., arXiv:2606.00474v1, Proposition 1 and repeated Proposition 4
   in Appendix D.3, promises relative **HS squared** error and polynomial bond
   dimension across a prescribed 1D cut. Its proof first evolves exactly to
   logarithmic circuit depth, then compresses. Its purity bound (241) is
   approximately `2^-n`; in that near-uniform regime relative HS bounds can
   indeed imply trace bounds after multiplying by `sqrt(2^n)`. I therefore
   do not dismiss all trace-norm consequences of this predecessor. One must
   still inspect positivity, simultaneous cuts and the sampling construction
   rather than cite a single-cut existence statement as a full sampler.
   <https://arxiv.org/html/2606.00474v1>.
4. Nelson et al.'s Theorem 2.3 and Proposition 2.2 remain the strongest
   all-dimensional discrete sampler comparator. They supply actual log-
   marginals and relative sampling, beyond the TV contract of my theorem.

The initial theorem is retained with explicit scope, but a firstness claim is
unwarranted. A full historical trace-norm tree-sampling audit remains open.

## Continuous-time 2D sampling attack

The scalar theorem supplies every prefix probability additively, including
arbitrary local measurement axes. It does not provide its logarithm. Even
H=0 and a maximally mixed output has a length-i prefix of mass 2^-i, so
relative or conditional use of a uniform additive oracle would require
exponential inverse accuracy. The obstacle is a real resource obligation,
not evidence of hardness of sampling that particular distribution.

I am pursuing two sharply separated objects in
`RELATIVE_MIXING_AND_SAMPLING_OBSTRUCTION.md`:

* an explicit **operator-order relative mixing certificate** that does earn
  all-outcome relative probabilities and a positive sampler in the genuine
  logarithmic-time regime, even for arbitrary correlated input and no locality;
* a quantitative check of whether exponential Fourier-weight suppression alone
  pays relative marginals or cluster expansion. It does not: even granting
  multiplicative envelopes on each Pauli coefficient leaves an exponentially
  large sum of absolute contributions to a long prefix. A soft-locality
  connected-polymer estimate is still a distinct missing operation.

The first is an established-hypercontractivity consequence, not a novel
constant-time sampler. The second isolates what the stronger scalar theorem
still has to acquire before the Nelson-style sampling route can be promoted.
