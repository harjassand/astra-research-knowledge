"""Build the constructive-exchange dossier; original proofs live beside this file."""
from pathlib import Path
import hashlib, html, json, sys, re
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak, Image, Table, TableStyle
)
from PIL import Image as PILImage
from matplotlib.mathtext import math_to_image
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["mathtext.fontset"] = "dejavuserif"
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
OUT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT.parent / "deliverables"
OUT.mkdir(exist_ok=True)
TMP = ROOT / "equations"
TMP.mkdir(exist_ok=True)
FIG = ROOT / "figures"
FIG.mkdir(exist_ok=True)
FONT = Path("/usr/share/fonts/truetype/dejavu")
for name, filename in (
    ("DSerif", "DejaVuSerif.ttf"), ("DSerif-Bold", "DejaVuSerif-Bold.ttf"),
    ("DSans", "DejaVuSans.ttf"), ("DSans-Bold", "DejaVuSans-Bold.ttf"),
):
    pdfmetrics.registerFont(TTFont(name, str(FONT / filename)))
for family in ("DSerif", "DSans"):
    pdfmetrics.registerFontFamily(
        family, normal=family, bold=family+"-Bold",
        italic=family, boldItalic=family+"-Bold"
    )
INK = colors.HexColor("#172D3D")
TEAL = colors.HexColor("#247A82")
MUTED = colors.HexColor("#586973")
PALE = colors.HexColor("#EDF4F5")
WIDTH = A4[0] - 96
styles = {
    "body": ParagraphStyle("body", fontName="DSerif", fontSize=9.5,
                           leading=14.1, spaceAfter=8, textColor=INK),
    "small": ParagraphStyle("small", fontName="DSerif", fontSize=8.3,
                            leading=11.8, spaceAfter=6, textColor=INK),
    "caption": ParagraphStyle("caption", fontName="DSans", fontSize=8.1,
                              leading=11.4, spaceAfter=8, textColor=MUTED),
    "h1": ParagraphStyle("h1", fontName="DSans-Bold", fontSize=18.5,
                         leading=24, spaceAfter=14, textColor=INK),
    "h2": ParagraphStyle("h2", fontName="DSans-Bold", fontSize=11.7,
                         leading=15.7, spaceBefore=8, spaceAfter=7, textColor=TEAL),
    "title": ParagraphStyle("title", fontName="DSans-Bold", fontSize=27,
                            leading=33, spaceAfter=18, textColor=INK),
    "label": ParagraphStyle("label", fontName="DSans-Bold", fontSize=9,
                            leading=13, spaceAfter=12, textColor=TEAL),
    "table": ParagraphStyle("table", fontName="DSerif", fontSize=8.15,
                            leading=11.6, spaceAfter=0, textColor=INK),
}
story, plain = [], []
def p(text, style="body"):
    story.append(Paragraph(text, styles[style]))
    plain.append(text)
def h(text):
    p(text, "h2")
def page(title):
    if story:
        story.append(PageBreak())
    p(title, "h1")
def eq(tex, fontsize=13):
    tex = " ".join(tex.split())
    tex = re.sub(r"\\mathbb\s+([A-Za-z])", r"\\mathbb{\1}", tex)
    tex = re.sub(r"\\(mathcal|overline)\s+([A-Za-z])", r"\\\1{\2}", tex)
    tex = re.sub(r"\\sqrt([0-9])", r"\\sqrt{\1}", tex)
    tex = tex.replace(r"\mathbf1", r"\mathbf{1}")
    tex = re.sub(r"\\frac([0-9])([0-9])", r"\\frac{\1}{\2}", tex)
    tex = re.sub(r"\}([0-9])", r"}{\1}", tex)
    key = hashlib.sha256((str(fontsize)+tex).encode()).hexdigest()[:15]
    f = TMP / (key + ".png")
    if not f.exists():
        math_to_image("$" + tex + "$", str(f), dpi=240,
                      format="png", color="#172D3D")
    with PILImage.open(f) as im:
        w, ht = im.size
    width = min(WIDTH, w * fontsize / 10 * 72 / 240)
    image = Image(str(f), width=width, height=ht*width/w)
    image.hAlign = "CENTER"
    story.extend([Spacer(1, 3), image, Spacer(1, 10)])
    plain.append("MATH: " + tex)
def table(rows, widths):
    data = [[Paragraph(c, styles["table"]) for c in row] for row in rows]
    t = Table(data, colWidths=widths, hAlign="LEFT", repeatRows=1)
    t.setStyle(TableStyle([
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("BACKGROUND", (0,0), (-1,0), PALE),
        ("LINEBELOW", (0,0), (-1,0), .7, TEAL),
        ("LINEBELOW", (0,1), (-1,-1), .3, colors.HexColor("#D8E0E4")),
        ("LEFTPADDING", (0,0), (-1,-1), 7),
        ("RIGHTPADDING", (0,0), (-1,-1), 7),
        ("TOPPADDING", (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
    ]))
    story.extend([t, Spacer(1, 9)])
    plain.extend(" | ".join(row) for row in rows)
def link(url, label):
    return '<link href="%s" color="#247A82">%s</link>' % (
        html.escape(url, quote=True), html.escape(label)
    )

p("ASTRA RESEARCH / CONSTRUCTIVE SCIENTIFIC EXCHANGE", "label")
p("A reusable thermal<br/>quantum register", "title")
p("Actual-coordinate sampler boundary, complete operating interface,<br/>and a finite active intervention companion", "h2")
p("5 November 2026 · Research result and executable proof package", "caption")
h("The selected consequence")
p("Within the accepted BDL random-embedding Hamiltonian and Pauli-Davies bath contract, initialize one thermal background before unknown quantum inputs arrive, then write, hold, read and replace logical states throughout an adaptive campaign. The guarantee includes entangled references and the complete retained record. Initialization error is charged once; the storage term depends on total passive exposure.")
eq(r"""\epsilon_{\rm campaign}\leq\epsilon_{\rm init}+\sum_j\epsilon_{{\rm ctrl},j}+C\Gamma NT\,e^{-cN^\eta}""")
h("What this exchange establishes")
p("The physical BDL check matroid has a linear packing of Fano-dual minors. This excludes the regular and logarithmic-defect regular-cover premises of the named general samplers. A separate physical-relation packing makes the recent complete-codeword quantum-decoding route exponentially unsuccessful. These are precise method boundaries, not hardness of Gibbs preparation: the accepted history compiler still constructs the loader.")
p("That loader extends to a reusable register and, with coherent Markov-chain annealing, a canonical thermofield double preparer. A central-sector projection theorem supplies a second preparation route when a relative decoder is unnecessary. Separately, a finite meter and feedback pulse implement P2’s reset-and-mark operation in its calibrated harmonic hidden-force family without learning the hidden force.")
table([
    ["<b>Completed here</b>", "<b>Not supplied by these results</b>"],
    ["Actual-coordinate obstruction; whole-campaign register theorem; explicit calibration; coherent thermal preparation; central projection; finite harmonic reset and useful arm.",
     "A fabricated memory, a constant-control-noise threshold, arbitrary noncommuting fabrication robustness, generic nonlinear reset optimality, or the missing positive burst-recovery recurrence."]
], [WIDTH/2, WIDTH/2])
p("The package retains exact issued sources, complete proofs, independent algebraic verifiers and the previous research package unchanged. Primary source attribution is listed at the end; inherited results are explicitly distinguished from deductions made in this exchange.", "caption")

page("1. The full question and the achieved answer")
p("<b>Question.</b> Can the protected thermal state in the actual three-dimensional BDL family be made an efficiently accessible, reusable quantum register, with a reference-preserving guarantee for a complete adaptive experiment and with acquisition, controls, useful output and reuse included?")
p("<b>Answer under the declared contract: yes.</b> The accepted P1 compiler supplies the classical syndrome law and protected frame. This exchange resolves the named sampler-comparison gate and proves that one background supports a complete campaign. It also constructs the previously explicit coefficient-access step. This is a mathematical operating capability conditional on the Hamiltonian, bath and control access, not a claim that those physical premises have been manufactured.")
h("Why the whole campaign is the right object")
p("A useful memory must return an unknown state, permit the next state to be written, and survive choices made from earlier outputs. A collection of separate one-hold estimates can charge preparation repeatedly and can fail to control information in the record. The new theorem compares the entire experiment with an ideal logical experiment on the same autonomous syndrome trajectory. It remains valid when a classical controller observes syndromes and chooses holding intervals adaptively.")
p("The theorem is broader than a single BDL block. It applies to any stabilizer memory with syndrome-autonomous Pauli jump rates and a computable protected frame. BDL supplies stretched-exponential suppression of its stationary logical-jump flux. A bank of blocks follows by summing exposure and control budgets. This is the substantive deduction from the general theorem.")
h("Inherited physical premises")
table([
    ["<b>Premise</b>", "<b>What it supplies</b>"],
    ["Known commuting stabilizers, positive bounded coefficients, bounded local support and overlap", "A physical Gibbs law on the actual check coordinates; calibrated weights can be acquired by the operation in §12."],
    ["BDL random embedding and accepted history compiler [A1, B1]", "A valid local design, protected decoder frame, full valid-syndrome sampler and unstable-syndrome probability at sufficiently low fixed temperature."],
    ["Energy-resolved one-site Pauli Davies bath, detailed balance, rate cap Γ", "Autonomous classical syndrome jumps and a stationary Gibbs law. The semigroup itself is the holding model."],
    ["Paid state preparation, Clifford control, syndrome metrology, isolation and routing", "An executable write/read interface. Requested control accuracy must be obtained at its actual resource cost."]
], [169, WIDTH-169])
p("No physical identification between this quantum memory, the classical spatial-burst model, and P2’s Langevin apparatus is assumed. General noncommuting fabrication errors and a microscopic finite-bath approximation valid over exponential time are outside the supplied contract.", "caption")

page("2. The actual physical matroid is extensively nonregular")
h("Theorem 1: an extensive minor and cover-defect boundary")
p("Fix any allowed odd refinement parameter ℓ ≥ 5. At every sufficiently large even construction depth, the physical Z-check matroid M<sub>Z</sub> of the BDL random-embedding family has a minor")
eq(r"""\bigoplus_{i=1}^{r_N}F_7^*,\qquad r_N\geq a_\ell N,\qquad a_\ell>0.""")
p("Here F<sub>7</sub> is the binary Fano matroid. Both the physical relation space and its dual syndrome space therefore have regular-cover defect at least a<sub>ℓ</sub>N. The refinement is fixed before N grows; its constants may be extremely severe.")
h("The physical-coordinate bridge")
p("For an old Z-check matrix h<sub>Z</sub> with m rows and n qubit columns, put A = h<sub>Z</sub><super>T</super>. The physical ground elements of M(A) are the actual Hamiltonian checks. Introduce only as an algebraic intermediate the augmented matroid N(A) = M([I<sub>m</sub> | A<super>T</super>]). Its identity columns are not new physical interactions.")
p("In the actual RX replacement, rows are x-local edges and q-local vertices; columns are x-local faces, q-local edges and old-Z point copies. Its boundary blocks are D<sub>X</sub>, G<sub>1</sub>, D<sub>Q</sub> and P, as in the source construction [B1]. Contract the x-face check columns. Vanishing H<sub>1</sub>(Y<sub>x</sub>) makes quotienting by im D<sub>X</sub> faithfully represented by vertex boundary d<sub>X</sub>. The identities d<sub>X</sub>G<sub>1</sub> = G<sub>0</sub>D<sub>Q</sub> and G<sub>0</sub>P = 0 remove the redundant top block.")
p("Contract the upper and lower subdivided stars in each Y<sub>q</sub>, leaving one bridge per old qubit. The remaining physical minor is the Lawrence double with block rows [A, 0, I<sub>n</sub>] and [0, A, I<sub>n</sub>]. Its dependencies are exactly")
eq(r"""(u,\ u+r,\ Au),\qquad u\in\mathbb F_2^m,\quad r\in\ker A.""")
p("A dual representation restricted to the upper-check and bridge columns is [I<sub>m</sub> | A<super>T</super>]. Thus N(A)<super>*</super> is a minor of the physical RX matroid. This proof allows redundant old checks; no independent-check simplification changes the Hamiltonian.")
h("What makes this stronger than a local diagnostic")
p("One forbidden minor proves nonregularity only. The next page transports a fixed local certificate through the exact replacements and packs linearly many disjoint copies. That extensive packing excludes logarithmic-defect covers, including both primal and dual alternatives in Code Swendsen–Wang.")
p("Full proof: sampler_route/sampler_obstruction.md. Exact physical contraction verifier: verify_lawrence_minor.py. It checks a redundant 19-check, rank-18 input; the retained physical Lawrence minor has 72 columns and rank 52.", "caption")

page("3. A small certificate controls every large depth")
h("A 53-element Fano certificate")
p("Take two adjacent Tanner squares (x₀,q₀,z,q₁) and (x₁,q₁,z,q₂), with h<sub>X</sub> rows (1,1,0), (0,1,1), and h<sub>Z</sub> = (1,1,1). The unsubdivided RX block at ℓ = 3 has 16 X checks, 34 qubits and 19 Z checks. Label the 19 augmented identity columns 0–18 and the qubit columns 19–52.")
table([
    ["<b>Certificate item</b>", "<b>Exact data</b>"],
    ["Contract", "13, 19, 29, 26, 52, 22, 44, 10, 32, 6, 17, 33, 24, 21, 36, 50"],
    ["Retain in order", "2, 4, 25, 14, 51, 7, 37"],
    ["Three quotient-row supports", "{2,3,5,8,9,12,16,18}; {4,7,11}; {7,14}"],
    ["Verification", "Contraction rank 16; quotient rank 3; retained images 1,2,3,4,5,6,7 in binary."]
], [132, WIDTH-132])
p("The contracted span is exactly the kernel of the displayed quotient. Its seven retained images are all nonzero vectors of F₂³, which is F<sub>7</sub>. The supplied verifier constructs the cells and performs exact binary elimination; it does not depend on the discovery software.")
h("Transport through refinement and the other sector")
p("For every odd ℓ ≥ 3, contracting qubit columns along dual spanning trees merges the subdivided x-faces and boundary strips. Contract internal q-arm vertices, retain one identity per merged check coordinate, and remove parallel boundary columns. This gives exactly the ℓ = 3 augmented block.")
p("Closed vertex-disjoint Tanner strips extract as a literal direct sum: contract unwanted identity columns, then delete unwanted qubit columns. No off-diagonal coupling remains. Under RZ, contracting internal Y<sub>z</sub> trees preserves the old augmented Z matroid as a minor. The physical Z matroid itself undergoes a series extension, since its relations are constant on each connected Y<sub>z</sub> vertex block.")
p("The resulting four-step chain takes disjoint strips through RX, RZ, RX, RZ to disjoint physical F<sub>7</sub><super>*</super> minors. Previous RZ square layers supply Θ(N) candidate strips. Bounded incidence gives a bounded-degree conflict graph, so greedy packing retains Ω(N) disjoint copies. Each replacement has fixed size ratio at fixed ℓ.")
h("The quantitative cover lemma")
p("For cycle spaces C ⊆ D, deletion intersects and contraction projects; both preserve inclusion and cannot increase dim(D/C). Regularity survives both. On a minor ⊕ C<sub>i</sub> of r disjoint Fano or Fano-dual blocks, each regular restriction D ∩ F₂<sup>Eᵢ</sup> strictly contains C<sub>i</sub>. Choose one extra vector per block. Disjoint supports make these r vectors independent modulo C, so dim(D/C) ≥ r. Duality proves the syndrome-space statement.")
p("Independent subdivision checks use a separately built grid/cylinder model at ℓ = 3, 5, 7, 9. They verify contraction ranks 16, 38, 68, 106 and the same seven images; the symbolic contraction proves all odd refinements.", "caption")

page("4. The strongest named Gibbs-sampler comparison")
p("A full quantum Gibbs sampler is a valid loading source. Run it before the unknown input arrives, measure its stabilizers, retain a classical syndrome and use the accepted loader. Logical randomization inside the auxiliary sampler is harmless at that stage. Its initialization error is paid once. The comparison below grants exactly that access.")
table([
    ["<b>Method</b>", "<b>Relevant premise</b>", "<b>Result on actual BDL coordinates</b>"],
    ["Regular-matroid FPRAS [B3]", "The physical matroid is regular, or a suitable regular construction is supplied.", "The exact regular premise fails by Theorem 1."],
    ["Code Swendsen–Wang [B2]", "A Δ-graphic or Δ-cographic cover, Δ = O(log N); theorem cost contains 2<super>O(Δ)</super>.", "Both cover defects are Ω(N). The published polynomial guarantee does not apply."],
    ["Regular cover plus rejection", "A constructive regular syndrome cover of codimension q = O(log N).", "Such a cover is impossible. This strengthened generic shortcut is excluded."],
    ["QD-HDQI [B4]", "Efficient complete relation-code decoding with inverse-polynomial success and the applicable sign guarantee.", "Physical local relations force exponentially small complete-decoding success; see §5."],
    ["Relative decoding [B5]", "A canonical source TFD, matched Pauli algebra and a certified quotient decoder/radius.", "No BDL-specific source/decoder is supplied by naming the physical-error decoder. A projection bypass exists when central-sector probability is large; see §7."],
    ["Accepted P1 history compiler [A1]", "The accepted low-activity history hypotheses for the actual family.", "Applicable. It supplies the full valid-syndrome loader."]
], [112, 177, WIDTH-289])
h("Why a logarithmic regular cover really would have sufficed")
p("For linear syndrome spaces L ⊆ R, codimension q, and positive zero-preferred weights w(s) = ∏ exp(−λᵢsᵢ), every binary Fourier coefficient of w is nonnegative. The character average of the q homogeneous constraints gives π<sub>R</sub>(L) ≥ 2<super>−q</super>. Thus rejection would need at most 2<sup>q+1</sup> expected approximate proposals if proposal TV error δ ≤ 2<sup>−q−1</sup>. Its conditional error is at most 2<sup>q</sup>δ.")
p("Set δ = ε·2<sup>−q</sup> and cap attempts at ⌈2<sup>q+1</sup> log(1/ζ)⌉. Total sampling/abort error is at most ε + ζ. For logarithmic q, even inverse-accuracy polynomial samplers remain polynomial. Our obstruction rules out precisely that sufficient route.")
p("<b>Scope.</b> No theorem here says actual CSW is torpid, that every high-codimension cover has tiny acceptance, or that every possible reduction to an enlarged regular system fails. The accepted efficient history sampler itself disproves a universal preparation-hardness interpretation.", "caption")

page("5. The recent quantum-decoding route has a real obstruction")
p("The full primary text of QD-HDQI [B4] defines the code to decode as C = ker B, where B contains the actual indexed Hamiltonian Pauli labels. It is not the code’s physical-error decoder. For P1’s projector convention Jᵢ(I−Sᵢ)/2, its pure-state channel overlap is")
eq(r"""t_i=\tanh(\beta J_i/2),\qquad p_i=\frac{1-\operatorname{sech}(\beta J_i/2)}2.""")
p("The codeword prior is uniform over the complete relation code. Algorithm 2 succeeds with probability exactly 1−p<sub>fail</sub>; Theorem 3.1 needs its reciprocal polynomial. Theorem 4.1 separately averages its error over all Hamiltonian signs, which is not automatically a guarantee for the fixed frustration-free BDL sector.")
h("Theorem 2: disjoint physical relations force exponential failure")
p("The actual final BDL check code contains L ≥ b<sub>ℓ</sub>N disjoint nonzero relation vectors, each of weight at most a constant w<sub>ℓ</sub>. In RX, an old qubit with two Z neighbors gives a cycle e in its two-star graph Y<sub>q</sub>. Every adjacent Y<sub>x</sub> fills that cycle, so (f,e,0) is a physical check dependency. Previous RZ grids supply a positive density of such qubits; bounded overlap permits a linear disjoint packing. Final RZ repeats the coefficients across fixed-size check blocks and preserves disjointness.")
p("Reveal the complementary codeword coordinate to a decoder. This can only help. It leaves L independent unbiased bits encoded in disjoint binary pure-state blocks. For block j, the two states have overlap at least t<sub>*</sub><sup>wℓ</sup>, where t<sub>*</sub> = tanh(βJ<sub>min</sub>/2). Helstrom discrimination gives its optimal success. The optimum probability of getting every independent bit right multiplies, including for collective measurements, by the tensor-product dual witness for the discrimination SDP.")
eq(r"""P_{\rm succ}\leq\left(\frac{1+\sqrt{1-t_*^{2w_\ell}}}{2}\right)^L
 \leq \exp\left(-\frac{L\,t_*^{2w_\ell}}4\right)""",12)
p("At every fixed positive βJ<sub>min</sub>, this is exponentially small in N. Even quadratic amplitude amplification leaves exponential cost for this operation. The USD/classical rejection variant independently obeys")
eq(r"""P_{\rm accept}\leq(1-t_*^{w_\ell})^L.""")
h("The sign issue is separate")
p("In the positive frustration-free sector, the normalized high-temperature expansion contains all combinations of those disjoint relations, giving Z′<sub>β</sub> ≥ (1+t<sub>*</sub><sup>wℓ</sup>)<sup>L</sup>. It is exponentially far from the near-one quantity controlled by the all-sign average. Pauli conjugation preserves relation frustration and cannot turn that average into a fixed-sector result.")
p("This obstruction targets complete codeword decoding, not Gibbs preparation. Even disjoint constant-size redundant stabilizer blocks can have hard full-codeword recovery while their Gibbs state is easy to prepare. The accepted history route avoids the unnecessary recovery task.", "caption")

page("6. The loader and its useful endpoint")
h("The accepted compiler supplies the full thermal syndrome")
p("Accept the P1 history compiler and its actual-family instantiation [A1]. Valid syndromes correspond bijectively to histories with bounded-degree local constraints. Nonzero connected components have additive energy at least a times their size. With κ the fixed connected-object counting factor and x = κe<sup>−βa</sup> satisfying the accepted low-activity condition, a cutoff L has excluded probability at most Mx<sup>L+1</sup>/(1−x).")
p("Choose L = O(log(M/ε<sub>alg</sub>)), enumerate K = poly(N,1/ε<sub>alg</sub>) retained polymers, and run the explicit random-scan heat bath. Its contraction factor is at most 1−3/(4K), so O(K log(M/ε<sub>alg</sub>)) steps suffice. The complete constant-size base validity relation remains included. There is no excluded-syndrome preparation floor.")
h("An arbitrary unknown input arrives only after preparation")
p("Let V₀ encode the ground logical subsystem, F<sub>s</sub> be the computed correction frame and V<sub>s</sub> = F<sub>s</sub><sup>†</sup>V₀. Sample s before the input arrives. When the unknown state ρ, possibly entangled with a remote reference, arrives, prepare the required ancillas, apply V₀ and then F<sub>s</sub><sup>†</sup>.")
eq(r"""\mathcal E_p(\rho)=\sum_s p(s)V_s\rho V_s^\dagger,\qquad
\frac12\|\mathcal E_p-\mathcal E_\pi\|_\diamond=\operatorname{TV}(p,\pi)""",12)
p("This is an exact orthogonal-sector identity. Any full Gibbs sampler can replace the classical source by stabilizer measurement before input arrival. Initialization does not demand exponentially precise sampling merely because the later hold is exponentially long.")
h("Read, compute, and replace while keeping the background")
p("At an access time, isolate the holding bath or include its effects in the access error. Measure the commuting checks to obtain s; on the stipulated block-diagonal state this does not disturb the logical/reference state. Apply F<sub>s</sub> and the inverse Clifford encoder. The logical state is now on designated ports.")
p("Apply the requested logical instrument or swap the old state into an output port and a new unknown state into the logical port. Re-encode and apply F<sub>s</sub><sup>†</sup>. Every ideal branch returns exactly the same syndrome s. The original Gibbs background is retained. New thermal sampling and whole-device thermal reset are unnecessary after each use.")
p("Known stabilizer encoders and inverse encoders have polynomial gate descriptions; actual local routing, protected ports, ancilla preparation, measurement, decoder evaluation, isolation and reset are charged. An arbitrary logical computation is allowed only with its own implementation cost. This construction does not turn logical gates into passive operations.", "caption")

page("7. A decoder can sometimes be replaced by central projection")
p("The full relative-decoding paper [B5] requires matched indexed magnitudes, equal anticommutation matrices, K<sub>A</sub> ⊆ K<sub>B</sub>, and consistent relation phases. It takes a canonical source thermofield double (TFD). Its degree certificate must fit below the certified relative-decoding radius. The supplied chain example has a fixed inverse-temperature window.")
p("A necessary relation test is elementary but useful: if d<sub>A→B</sub> &gt; w, then every target relation of weight at most w lies in K<sub>A</sub>. Thus a large-radius BDL source must absorb the explicit local relations above. We have not assumed that these generate every BDL relation, and have not excluded all possible relative sources.")
h("Theorem 3: exact central-sector transduction")
p("Under the algebraic compatibility premises, let q = dim K<sub>B</sub> − dim K<sub>A</sub>. The missing relations become q independent central source Paulis. Their joint required eigenspace has projector P. In that sector, polynomial symplectic elimination gives a Clifford identification of the source’s indexed Pauli algebra with the target, up to idle factors.")
eq(r"""p_\beta=\frac{\operatorname{Tr}(P e^{-\beta H_A})}
 {\operatorname{Tr}(e^{-\beta H_A})}.""")
p("Project the physical half of the canonical source TFD by P. Because P commutes with H<sub>A</sub>, this also selects the conjugate reference sector. Apply the Clifford and its complex conjugate, remove fixed sector registers, and add/remove idle Bell pairs. Conditioned on success, the output is exactly the canonical target TFD for every β.")
p("Expected independent-trial cost is 1/p<sub>β</sub>. Coherent source preparation, its inverse and reflections permit amplitude amplification with query cost O(p<sub>β</sub><sup>−1/2</sup>). A source error δ can amplify by O(δ/p<sub>β</sub>) on conditioning; a certified p₀ ≤ p<sub>β</sub> permits source accuracy O(p₀ε) and a finite trial cap O(p₀<sup>−1</sup>log(1/ε)).")
h("Two constructive success bounds")
p("For a positive commuting source and a frustration-free homogeneous target sector, Fourier positivity gives p<sub>β</sub> ≥ 2<sup>−q</sup> at every temperature. Thus q = O(log N) can remove the need for a relative-distance decoder. For a noncommuting source, a unitary sector flip changing the Hamiltonian by operator norm at most Δ gives p ≥ (1+e<sup>βΔ</sup>)<sup>−1</sup> by eigenvalue comparison of the two restricted blocks.")
p("The projection method is a compatible alternative, not a general lower bound or a free sampler. It pays for source preparation, conditioning, algebraic compression, reference storage and all controls. The next page gives an explicit target family where it extends the sufficient temperature window.", "caption")

page("8. An explicit noncommuting target at every fixed temperature")
p("Place constant-size cells (q<sub>v</sub>,c<sub>v</sub>) on the vertices of an L × L grid. Let P be the row-snake Hamiltonian path and T the column-snake path. The source Hamiltonian, viewed along P, is a nearest-neighbor chain:")
eq(r"""H_A=\sum_v(a_vX_{q_v}+b_vZ_{q_v}+d_vZ_{c_v}
 +e_vZ_{c_v}Z_{q_v})+\sum_{(u,v)\in P}f_{uv}Z_{q_u}Z_{q_v}""",11)
p("All coefficients are supplied, bounded in magnitude by J₀; the X and Z terms make the Hamiltonian noncommuting. The c-qubit Z observables are central. The one-dimensional canonical-TFD theorem [B7] applies at every fixed finite inverse temperature after grouping each pair into a constant-size cell.")
h("Local target and exact operation")
p("Put a target qubit R<sub>e</sub> at each edge midpoint of T and define B<sub>v</sub> = ∏<sub>e∋v</sub>Z<sub>Rₑ</sub>. Replace every Z<sub>cᵥ</sub> by B<sub>v</sub>, keeping the q terms and row-path interactions. Each B<sub>v</sub> has weight at most two, so interactions have weight at most three, bounded degree and bounded geometric range. With all terms present the interaction graph contains a square-grid minor.")
p("The only new relation is ∏<sub>v</sub>B<sub>v</sub> = I. Measure the source central parity ∏<sub>v</sub>Z<sub>cᵥ</sub> and retain +1. If F is the edge-vertex incidence matrix of the tree T, even c strings have a unique representation c = F<super>T</super>r. Prefix-parity CNOTs implement this change of variables on the physical and reference copies, leaving one fixed parity bit to remove.")
h("All fixed temperatures, with its actual cost")
p("A single X<sub>cᵥ</sub> flips global parity and changes only d<sub>v</sub>Z<sub>cᵥ</sub> and e<sub>v</sub>Z<sub>cᵥ</sub>Z<sub>qᵥ</sub>. Its energy-change norm is at most 4J₀. Therefore")
eq(r"""p_+\geq(1+e^{4\beta J_0})^{-1}.""")
p("For every fixed finite β, this is a constant independent of system size. Source error O(p₀ε), finite repeated trials, O(N) parity/compression gates per copy, reference qubits, ancilla reset and local routing give polynomial total preparation cost. There is no efficiency assertion uniform in β growing with N.")
p("This bypasses a degree-versus-distance temperature restriction for this compatible source–target construction. It does not establish generic two-dimensional Gibbs sampling or passive storage. Its thermodynamics remains a one-dimensional source restricted to one global parity sector, despite the genuinely two-dimensional interaction layout.")
p("The independent four-cell check constructs both Hamiltonians and the exact isometry. Algebraic residuals are zero; conditioned-source and direct-target Gibbs states differ by less than 7 × 10<sup>−16</sup> at β = 0, 0.2, 1, 3, 8. These checks support the implementation; the general result is the preceding algebraic proof.", "caption")

page("9. The whole-campaign reusable-register theorem")
h("Theorem 4: stationary logical flux controls all uses")
p("In the protected frame V<sub>s</sub>, let an energy-resolved elementary Pauli jump a have syndrome rate q<sub>a</sub>(s), next syndrome s+d<sub>a</sub>, and logical Pauli ℓ<sub>a</sub>(s) = V<sub>s+dₐ</sub><sup>†</sup>P<sub>a</sub>V<sub>s</sub>. The jump rate depends only on s, and the no-jump evolution is scalar on the logical subsystem. Define")
eq(r"""b(s)=\sum_a q_a(s)\,\mathbf1\{\ell_a(s)\not\propto I\},
 \qquad \lambda_L=\sum_s\pi(s)b(s)""",12)
p("Initialize once with a classical syndrome p satisfying TV(p,π) ≤ ε<sub>init</sub>. The joint memory/reference state is block diagonal in syndrome; arbitrary logical/reference entanglement conditional on that classical syndrome is permitted.")
p("Allow syndrome-preserving logical instruments, classical adaptation to all retained records, and passive holding intervals whose accumulated duration is at most T on every branch. Isolate the bath during active operations, or charge its implementation effects. Let the accumulated uniform control error be bounded by ∑ ε<sub>ctrl,j</sub> on every branch.")
eq(r"""\operatorname{dist}(\text{actual campaign},\text{ideal campaign})
 \leq\epsilon_{\rm init}+T\lambda_L+\sum_j\epsilon_{{\rm ctrl},j}""",12)
p("Distance is trace distance of the complete output state and retained classical record, uniformly over compatible strategies and arbitrary logical references. The ideal experiment has the same syndrome trajectory and logical instruments; passive holding acts as the logical identity.")
h("Proof without stationarity at an adaptive stopping time")
p("Fix a stationary autonomous labeled syndrome trajectory in accumulated passive time on the deterministic interval [0,T]. Ideal active instruments preserve s and pause that trajectory. Any compatible classically timed experiment traverses a stopped prefix, even when its choices depend on syndrome reports or logical outcomes.")
p("Couple actual and ideal experiments to the same trajectory and instrument realizations. Until the first nonidentity logical jump they agree, including references and records. A bad jump in the campaign is contained in a bad jump anywhere in [0,T]. Stationarity at deterministic intrinsic times gives E N<sub>bad</sub>(T) = Tλ<sub>L</sub>. Markov’s inequality bounds the probability of any such jump. Couple p to π once; then apply a control-channel hybrid. This proves the theorem.")
p("The ideal does not supply independent fresh syndrome reports. The result is unconditional on the retained record; rare postselection requires its usual acceptance-probability correction. Coherent quantum control of bath exposure and a TFD coherent across syndrome sectors are different interfaces.", "caption")

page("10. BDL consequence, deployment and reuse")
p("Stable syndromes have b(s) = 0. With O(N) elementary jump channels of rate at most Γ and the accepted unstable-syndrome estimate,")
eq(r"""\lambda_L\leq C\Gamma N e^{-cN^\eta}.""")
p("Thus the complete campaign has stretched-exponentially long passive exposure at fixed storage error. Repeated accesses do not multiply ε<sub>init</sub>; they add their actual control error and execution costs. For a bank of blocks, sum CΓN<sub>b</sub>T<sub>b</sub>e<sup>−cNᵦη</sup> and the initialization/control budgets.")
h("Concrete mission specification")
p("Choose target failure ε, total passive exposure T, and a finite access plan or uniform branchwise control budget. Allocate ε among calibrated initial sampling, controls and passive storage. Choose N so CΓNT e<sup>−cNη</sup> fits the storage allocation. Asymptotically a suitable power of log(T/ε) suffices, allowing the additional log N factor. This is a size law for a fixed source family, not a small practical prefactor.")
p("Acquire the valid design and calibrated thermal coefficients before the input arrives. Compile the sampler, frame, encoder and access circuits. Load once. At each use, measure s, decode to a protected port, perform the requested logical operation, and restore the same s. Release the final unknown state to the specified output interface. Reset/dispose of access ancillas and records using the declared resources.")
h("Precision is paid at the active interface")
p("If the mission uses Q imperfect primitive control locations, a sufficient composable allocation is per-location error O(ε<sub>ctrl</sub>/Q). Let t<sub>g</sub>(δ), E<sub>g</sub>(δ), and analogous preparation, readout and reset functions denote actual costs of attaining accuracy δ. The bill uses those functions, plus routing and isolation. Merely writing down δ does not prove a constant-rate fault-tolerant implementation.")
p("An arbitrary number of active calls is therefore not free, and an exponential number of accurate calls need not have polynomial total cost. The benefit is long passive gaps with polynomial-size endpoint circuits under the supplied accuracy primitives.")
h("Holding still consumes physical resources")
eq(r"""V_{\rm spacetime}\ \gtrsim\ NT,\qquad
E_{\rm hold}=\int_0^{T_{\rm wall}}P_{\rm maintenance}(t)\,dt.""")
p("A bath-connected device occupies space and maintenance resources throughout the hold. Refrigerator power, clock and record protection, active delays and protected output-port storage remain in the bill. The source’s random-embedding constants are extremely large; no engineering-scale device or optimized energy budget is claimed.")
p("The memory theorem assumes the specified Markov semigroup for the duration. A new noncommuting Hamiltonian residual can accumulate coherently and is not converted into a harmless coefficient-calibration error. Those are material remaining hardware questions, not omitted terms in the proved interface.", "caption")

page("11. Coherent preparation of the canonical thermal state")
h("Theorem 5: the accepted polymer compiler supplies a true TFD")
p("A classical sampler is not automatically an amplitude-preparation circuit. Here the sampler is explicit enough to construct one. Choose the polymer cutoff with omitted probability τ = O(ε²), enumerate K retained polymers, and scale their activities by u ∈ (0,1]:")
eq(r"""\pi_u(\Gamma)=Z_u^{-1}u^{|\Gamma|}\prod_{\gamma\in\Gamma}w_\gamma.""")
p("The same influence bound applies at every u ≤ 1. The random-scan heat bath is reversible, positive and has spectral gap at least 3/(4K). Its at most K+1 transitions and their probabilities are explicitly computable from compatibility and uw<sub>γ</sub>/(1+uw<sub>γ</sub>), so the coherent transition isometry has polynomial cost.")
h("An explicit annealing path")
p("Take u₀K ≤ cε². Since Z<sub>u₀</sub> ≤ exp(u₀K), the empty configuration is O(ε) close to the first stationary amplitude state. Put θ = log u and R = log(1/u₀). If every configuration uses at most M polymers,")
eq(r"""\left\|\partial_\theta|\sqrt{\pi_{e^\theta}}\rangle\right\|
 =\frac12\sqrt{\operatorname{Var}(|\Gamma|)}\leq M/4.""")
p("Use S = O(M²R²/ε²) equal logarithmic steps. Ideal successive stationary projections fail with total probability at most M²R²/(16S). Quantum-walk phase filtering [B6] implements them with phase gap Ω(K<sup>−1/2</sup>) and per-step error O(ε/S). The standard data/zero-ancilla subspace is orthogonal to unwanted zero-phase modes. All filtering and reversible arithmetic costs are polynomial.")
h("Canonical, not merely an arbitrary purification")
p("Reversibly map compatible polymers to their unique history and syndrome, producing ∑√π(s)|s〉. Prepare a logical Bell pair, apply V<sub>s</sub> to one physical copy and V<sub>s</sub><sup>*</sup> to the other, and uncompute the syndrome register from the physical stabilizer eigenvalues. The result is")
eq(r"""|\operatorname{TFD}_H\rangle=
 \sum_s\sqrt{\pi(s)}\,2^{-k/2}\sum_{j=1}^{2^k}
 |v_{s,j}\rangle|\overline{v_{s,j}}\rangle.""",12)
p("A basis change within a sector cancels under U ⊗ U*. Removing probability mass τ costs √τ in pure-state trace distance, which is why the cutoff error was squared. Enumeration, transition synthesis, quantum filtering, both physical copies, routing and control precision are all paid.")
p("This supplies the canonical source object required by relative transduction at the accepted low-temperature condition. It is a preparation theorem. The reusable-register trajectory proof requires a classical syndrome block decomposition and is not asserted for this coherent TFD as a passive initial state.", "caption")

page("12. Acquire the thermal weights by local Ramsey experiments")
p("Coefficient access need not mean a rare-lifetime experiment. Suppose the commuting nonidentity Pauli terms are known, distinct after combining exact duplicates, with bounded overlap d and fixed positive coefficient bounds. The same bath-isolated control used for writing permits the following explicit calibration.")
h("Local gap and character inversion")
p("Prepare a known ground state ψ₀ with the Clifford encoder, and a Pauli translate Rψ₀. Write R<sup>†</sup>S<sub>a</sub>R = χ<sub>a</sub>(R)S<sub>a</sub>. A one-site probe P anticommutes with at most d checks B(P), and")
eq(r"""\Delta_P(R)=\sum_{a\in B(P)}J_a\chi_a(R),\qquad
J_a=\mathbb E_R[\chi_a(R)\Delta_P(R)].""",12)
p("The second identity follows from orthogonality of distinct Pauli characters. Uniform Pauli frames induce a uniform distribution on attainable local sign patterns, even when stabilizer relations forbid independent signs. Gaussian elimination enumerates at most 2<sup>d</sup> patterns and supplies a representative R for each.")
p("Prepare an ancilla in |+〉, controlled-apply P, evolve naturally under H for time τ, and controlled-apply P again. The data returns to Rψ₀ while the ancilla gains relative phase exp(−iτΔ). No controlled-H primitive is assumed. Choose τ ≤ π/(4dJ<sub>max</sub>). Measuring Pauli Y has mean −sin(τΔ).")
eq(r"""\widehat\Delta=-\tau^{-1}\arcsin
 \left(\operatorname{clip}_{[-1/\sqrt2,\,1/\sqrt2]}\overline Y\right).""",12)
h("A conservative, fully specified statistical bill")
p("With M<sub>set</sub> ≤ m2<sup>d</sup> settings, n ≥ 4(τδ<sub>J</sub>)<sup>−2</sup> log(2M<sub>set</sub>/α) shots per setting estimate every coefficient within δ<sub>J</sub> with failure probability at most α, apart from separately bounded timing/control bias. At fixed degree and thermal range, δ<sub>J</sub> = O(ε<sub>cal</sub>/m) gives O(m³ε<sub>cal</sub><sup>−2</sup>log(m/α)) total shots.")
p("Every shot pays actual state preparation, routing, interrogation, metrology and reset. This is an explicit polynomial route if those precision primitives have the stated polynomial cost; it is not an optimal Hamiltonian-learning claim.")
h("Temperature and uncertainty")
p("The accepted TV bound is ¼∑|βJ<sub>a</sub>−β̂Ĵ<sub>a</sub>|. A calibrated thermometer must therefore supply β to the allocated precision. A known two-level probe has the usual inverse-square sample cost on a bounded nondegenerate temperature range, but its actual same-bath access, relaxation, sample independence and reset are extra paid parameters. An upper rate cap Γ does not imply a fast thermometer.")
p("Calibration does not establish a commuting-Pauli or Davies model from finite data. It acquires parameters inside that model. Its sampling discrepancy and failure probability enter ε<sub>init</sub> once; continuously injected model drift does not.", "caption")

page("13. Full execution bill and information conventions")
table([
    ["<b>Stage</b>", "<b>What the result actually requires and charges</b>"],
    ["Design and acquisition", "Known physical Pauli supports and valid random embedding; classical construction/certification; coefficient shots and thermometer cost; confidence and model validity. No absolute rare-lifetime, complete-generator or marked-event-law acquisition is required."],
    ["Initial preparation", "Product ancillas, accepted polymer enumeration and heat-bath simulation, protected frame, stabilizer encoder, physical routing, fresh randomness, thermal-weight uncertainty and abort probability."],
    ["Unknown-input access", "The input arrives after thermal sampling. Paid swap/encoder controls and protected ports preserve arbitrary logical references; no copy of the unknown state is assumed."],
    ["Holding", "The specified stationary Pauli-Davies dynamics, N physical degrees of freedom, total passive time T, maintenance/refrigeration, and isolation interfaces."],
    ["Access and useful work", "Syndrome measurement, decoder computation, inverse encoder, requested logical instrument, re-encoding, reset, finite latency and accumulated implementation errors."],
    ["Reuse", "The same syndrome is restored. The thermal sample is retained; access ancillas and external records still need preparation, protection and disposal."],
    ["Coherent TFD option", "A second physical copy, coherent transition arithmetic, phase filtering, quantum controls and the stricter square-root truncation budget. This is separate from the classical-syndrome memory use."],
    ["Failure and uncertainty", "Keep abort in the output record. A rare postselected output can amplify error. Actual control and metrology bias must satisfy the stated accumulated budget."]
], [122, WIDTH-122])
h("The same-information comparison")
p("Any method with the same calibrated Hamiltonian and control access may use these cancellations, frames, thermal sources and reset operations. The result does not attribute a decision-versus-prediction advantage to a method’s name. It removes unnecessary tasks: resolving an absolute lifetime, reconstructing hidden modes, decoding every relation-code bit, reinitializing the thermal background after every use, or implementing a relative decoder when a central sector can be selected directly.")
p("The named comparator bounds have been tested on their actual input objects. Failure of their sufficient hypotheses is not failure of all algorithms. Conversely, calling a sampler or a decoder “general” does not make its temperature, sign, success-probability or source-purification conditions disappear.")
p("The scientific claim is a conditional operating theorem with an explicit route and bill. Turning it into hardware would require a platform that earns the local Hamiltonian, long-time bath model, reliable active interface and maintenance resources. This report does not assign those unbuilt components an invented numerical cost.", "caption")

page("14. P2: construct the finite meter that reset needs")
p("P2’s whole-campaign entropy/waiting construction is accepted [A2]. Its quadratic sufficient waiting is not optimality over active controls. The following operation is valid for its calibrated harmonic hidden-force family and supplies a concrete bypass.")
p("Write S = (x,p), B = e<sub>p</sub>, A with rows (0,1/M) and (−k,−γ), k/M = λν, ν = γ−λ, 0 &lt; λ ≤ γ/2. The source obeys")
eq(r"""dS=(AS+BfZ+Bu)\,dt+B\sqrt{2\gamma\sigma^2}\,dW.""")
p("The joint initial law of (x₀,p₀,Z,R) may be arbitrary; Z is an unknown conserved force sector and R an old classical reference. Fresh bath and pointer variables are independent. M,k,γ,σ and the control transfer are supplied or acquired with charged calibration.")
h("The endpoint-independent finite meter")
p("Let φ be the degree-13 Hermite polynomial with derivatives 0,1,2 zero at 0; φ‴(0)=1, φ⁽⁴⁾(0)=0, φ⁽⁵⁾(0)=λ²+ν², φ⁽⁶⁾(0)=0; all derivatives 0 through 6 vanish at H. Put D = d/dt and")
eq(r"""h=D(D+\lambda)(D+\nu)\phi,\qquad
g=M D(D^2-\lambda^2)(D^2-\nu^2)\phi.""",12)
p("Then g and g′ vanish at both endpoints, and ∫g(t)e<sup>at</sup>dt = Ma for a = 0, ±λ, ±ν. In the repeated-root case the confluent identity is included. Integration by parts gives")
eq(r"""\int_0^H g(t)x_{\rm free}(t)\,dt
 =p_0+\sqrt{2\gamma\sigma^2}\int_0^Hh(s)\,dW_s.""",12)
p("Initial position and constant force cancel. The same moments make the Gaussian error orthogonal to both components of final source noise, hence independent of the entire loaded endpoint. This independence, stronger than an MSE estimate, is what makes reset compose.")
p("A finite-mass canonical pointer with H<sub>int</sub>(t)=−Gg(t)xP, followed by a detached quadrature rotation, yields Y = p₀ + E with E Gaussian, variance v = 2γσ²∫h² + v<sub>Q</sub>/G². E is independent of old state/reference, pointer momentum and the full endpoint innovation. The physical pointer backaction remains in the declared loaded channel.")
p("Uniformly as the slow rate vanishes or the two rates coalesce, ∫h²=O(H), ||g||∞=O(M/H²), ||g′||∞=O(M/H³). The coefficients depend polynomially on γ and k/M, avoiding ill-conditioned eigenvalue estimation. Short duration is purchased with large pulse capacity.", "caption")

page("15. Exact reset and the sharp arm boundary")
h("Theorem 6: reset while preserving the hidden/reference marginal")
p("Assume v &lt; σ². Prepare a fresh ξ ∼ N(0,τ²), τ² = σ²−v, independent of all old variables. Apply the finite endpoint displacement e<sup>AT</sup>B(ξ−Y). Then")
eq(r"""S_T=e^{AT}(x_0,\zeta)^T+F_TZ+N_T,\qquad
\zeta=\xi-E\sim N(0,\sigma^2).""",12)
p("The replacement ζ is independent of (x₀,p₀,Z,R) and the declared loaded endpoint noise N<sub>T</sub>. This is exactly K<sub>T</sub>C: replace initial momentum, retain the initial position/hidden/reference marginal, then apply a fixed finite loaded channel. It is not an instantaneous cost-free swap or an unloaded trajectory assertion.")
h("A useful arm can be produced exactly")
p("For the target arm a(ζ) = [1+ηsin(ζ/σ)]/2, generate A with probability")
eq(r"""b(\xi)=\frac12\left[1+\eta e^{v/(2\tau^2)}
 \sin\!\left(\frac{\sigma\xi}{\tau^2}\right)\right].""",13)
p("Since ξ conditional on ζ is Gaussian with mean τ²ζ/σ² and variance vτ²/σ², direct integration gives E[b(ξ)|ζ] = a(ζ). The full joint law of final source, hidden sector, old reference and arm is exactly the required one.")
eq(r"""v\leq\frac{2\log(1/\eta)}{1+2\log(1/\eta)}\,\sigma^2.""")
p("This condition is necessary and sufficient for arm postprocessing in the declared meter-plus-feedforward interface, even if the postprocessor may use both Y and ξ. Fix p₀ and ζ. Then Y = ξ+(p₀−ζ). For every translation d, b<sub>d</sub>(q)=b(q+d,q) must have the same prescribed Gaussian convolution. Injectivity forces the displayed corrected sine. If its amplitude exceeds one, no randomized postprocessing of those two records can implement it. Additional instruments are a different interface.")
h("Finite mechanical feedforward, rather than a free displacement")
p("After the meter is detached and rotated, choose a force window L with w(s)=sin²(πs/L). The weighted controllability Gramian W<sub>w</sub> = ∫w(s)e<sup>A(L−s)</sup>BB<sup>T</sup>e<sup>Aᵀ(L−s)</sup>ds is positive. The smooth force")
eq(r"""u(s)=w(s)B^Te^{A^T(L-s)}W_w^{-1}e^{AT}B\,(\xi-Y)""",12)
p("has exactly the desired endpoint effect and vanishes smoothly at switching. A harmonic rotation converts the meter quadrature into an actuator momentum; finite xP couplings to two conserved actuator momenta implement ξ−Y without a free perfect ADC. Fine controller records are isolated and reset/discarded before reuse.", "caption")

page("16. The intervention remains useful and its costs are visible")
p("The meter backaction simplifies to −GM e<sup>AT</sup>ABP, with explicit finite covariance. Fresh later bath noise preserves its independence from E. The two arms are equiprobable, and their final momentum contrast is")
eq(r"""\mathbb E[p_T|1]-\mathbb E[p_T|0]
 =2\eta\sigma e^{-1/2}[e^{AT}]_{pp}.""",12)
p("For T &lt; 2/γ, [e<sup>AT</sup>]<sub>pp</sub> ≥ e<sup>−γT/2</sup>(1−γT/2) &gt; 0 throughout the overdamped family. A fixed finite operation therefore retains an observable arm response even when the hidden relaxation time diverges.")
table([
    ["<b>Normalized operating choice</b>", "<b>Fast</b>", "<b>Lower force</b>"],
    ["Meter / rotation / force duration", ".05 / .05 / .10", ".20 / .05 / .50"],
    ["Total duration", ".20", ".75"],
    ["Meter error variance v", ".18972", ".45901"],
    ["Corrected sine amplitude", ".56210", ".76420"],
    ["Useful momentum contrast", ".49489", ".26981"],
    ["Feedforward action coefficient", "561.62", "38.05"],
    ["Meter force action", ".01592", ".02489"]
], [WIDTH*.52, WIDTH*.24, WIDTH*.24])
p("Here M=γ=σ=1, λ=.2, η=.5, G=1, v<sub>Q</sub>=.1; pointer momentum variances are 10<sup>−10</sup> and 10<sup>−8</sup>. These normalized classical examples are not quantum-valid hardware specifications without a compatible physical action scale.")
sys.path.insert(0, str(ROOT / "intervention_route"))
from finite_reset import pulse
import mpmath as mp
profile = pulse(mp.mpf(1), mp.mpf(1), mp.mpf(".2"), mp.mpf(".2"))
t = np.linspace(0, .2, 601)
hv = np.array([float(profile["h_at"](mp.mpf(float(z)))) for z in t])
gv = np.array([float(profile["g"](mp.mpf(float(z)))) for z in t])
fig, ax = plt.subplots(1, 2, figsize=(7.1, 2.05), constrained_layout=True)
for a, y, title, ylabel in (
    (ax[0], hv, "Finite adjoint meter", "h(t)"),
    (ax[1], gv, "Paid source coupling", "g(t)"),
):
    a.plot(t, y, color="#247A82", linewidth=1.7)
    a.axhline(0, color="#A6B3BA", linewidth=.6)
    a.set(title=title, xlabel="Time (normalized)", ylabel=ylabel)
    a.grid(alpha=.15)
    a.tick_params(labelsize=8)
    a.spines[["top", "right"]].set_visible(False)
fig.savefig(FIG / "finite_window_pulses.png", dpi=220)
fig.savefig(FIG / "finite_window_pulses.svg")
plt.close(fig)
story.append(Image(str(FIG / "finite_window_pulses.png"), width=WIDTH, height=WIDTH*2.05/7.1))
p("The lower-force pulse above still reaches |g| about 6.58 × 10³ and sampled slew about 4.42 × 10⁵ in normalized units. Cancellation of the unknown force is an exact signed-pulse effect, not an assertion of negligible control effort.", "caption")

page("17. What the active bypass does and does not settle")
h("Full resource ledger")
p("Expected feedforward force action is κ<sub>f</sub>(E p₀²+σ²), where κ<sub>f</sub>=∫f². It is not automatically mechanical work. Actual work is ∫up/M; switching, pointer traps, preparation, reset and refrigerator costs must be added. P2’s soft hidden-mode fixture still has position range of order λ<sup>−1/2</sup>; this operation removes its waiting bottleneck, not its displacement/range requirement.")
p("The exact linear model has unbounded Gaussian variables. Finite saturation/apertures produce a real bounded instrument agreeing with it until exit; the output TV discrepancy is bounded by the exit probability. Gaussian fixtures permit logarithmic tail budgets, while moment-only initial laws require larger caps. Pointer travel, transient energy, peak force and slew are all priced.")
p("Fresh Gaussian pointer/actuator preparation uses the accepted finite harmonic reset [A3]. At bounded apparatus moments, serial resetting to O(ε/n) accuracy costs O(log(n/ε)) contact time per use. Ideal calibrated kernels compose exactly, so fixed meter noise does not produce the previous nv marking term. Finite reset, clipping, probability-computation and calibration errors still require campaign budgets.")
p("A quantum pointer must satisfy v<sub>Q</sub>v<sub>P</sub> ≥ ℏ²/4. This is a classical operation with a declared classical phase-space regime; it is not a claim that arbitrary classical precision passes through a quantum floor. Unknown plant acquisition, calibration drift, or growing source moments can change the total scaling.")
h("Strong existing method and the actual increment")
p("Milburn and Shrapnel [B8] already give Gaussian measurement-and-feedback intervention machinery with conditional displacement, discarded records, entropy and work. Those ideas are not claimed as new. The construction here supplies the missing finite-window endpoint-independent meter and the exact reset-plus-soft-arm channel with the retained hidden/reference state.")
p("An equally informed predictor can compile this controller and predict its arm contrast. The result is an active bypass of P2’s passive-waiting bottleneck in this specified harmonic interface, not a method-exclusive prediction/decision separation. Its independent-clock lower example and hidden-force inference bound remain valid within their original information restrictions.")
h("Why the quantum register remains the selected target")
p("The quantum result returns arbitrary unknown reference-entangled information and supports an entire adaptive register campaign. The harmonic companion is a completed useful operation, but its calibrated linear, constant-force interface is narrower. The burst lower theorem applies broadly to its own fault law, yet its crucial positive local recovery operation remains unproved. Neither fact supplies a physical bridge that invalidates BDL’s stated bath theorem.")
p("This exchange therefore selects on achieved operational consequence: construct the register, retain the finite reset as a separate result, and retain the burst impossibility and failed recurrence at their actual scopes.", "caption")

page("18. Preservation and sharp scientific boundaries")
table([
    ["<b>Result family</b>", "<b>Scope preserved</b>"],
    ["Direct acquired prevention", "Reliable interacting Gibbs systems and reciprocal kinetic interventions with the same unknown invariant law; common scale cancellation; local correction and measurement bounds; all-safe-start mean theorem and finite warm-up; grouped-wait assay; independent constructions. Near-linear versus quadratic evidence separation is relative to an absolute-forecast requirement; an equally informed direct capacity method shares the cancellation."],
    ["Productive control and repair", "All-depth feedback changes the failure law and optimizes useful work for an observed skip-free damage process with justified uniform transition envelopes. The finite-source repair companion retains its separate resource and shared-support limits."],
    ["First-event machinery", "Complete acquired first-event construction, fitted-model and experiment-fed paths, static weights and operating coins, confidence/preparation costs and independent results remain unchanged in the nested archive."],
    ["Burst recoverability", "Complete-cone erasure lower bound for finite-speed classical influence under the declared spatial reset bursts. Finite local flux can coexist with inevitable information loss. The positive multiscale recurrence remains unproved; the Toom interaction counterexample remains a useful failure."],
    ["P1 thermal machinery", "Accepted history compiler and source-conditional loader; random-embedding family; fixed positive commuting coefficient variation; specified bath. No transfer to the separate explicit embedding, arbitrary coherent fabrication error or constant-noise gates."],
    ["P2 preparation and streams", "Finite-energy loaded-LTI private-timing prediction; separate nonlinear/local thermal constructions; whole-campaign entropy and waiting upper bound. The active harmonic operation changes access explicitly rather than contradicting those accepted theorems."]
], [126, WIDTH-126])
h("The burst theorem, unchanged")
eq(r"""\operatorname{TV}(P_0^T,P_1^T)\leq e^{-\Lambda(T)},\qquad
\Lambda(T)=\lambda 2^d\int_0^T\mathbb E(R-r_0-vt)_+^d\,dt.""",12)
p("If E R<sup>d</sup> is finite but E R<sup>d+1</sup> is infinite, every finite-speed controller with a finite input-dependent seed eventually loses distinguishability under this reset model. The conjectured positive recurrence p<sub>next</sub> ≤ Cp² + DλL<sup>d+1−α</sup> is not established. No statement in the present package promotes it to a result or applies it to the Pauli-Davies memory bath.")
p("The previous burst research ZIP is embedded unchanged and already contains the productive-control, direct-prevention and first-event packages. Preservation is by byte identity; predecessor manifests have not been re-audited in this exchange.", "caption")

page("19. Verification and reproducibility")
p("The mathematical proofs, exact certificates and independent checks are included as editable text and Python. Finite examples check algebra and implementation; they do not replace the family proofs or constitute experimental validation.")
table([
    ["<b>Check</b>", "<b>Observed result</b>"],
    ["Local augmented Fano minor", "Exact rank-16 contraction; rank-3 quotient; seven nonzero images 1–7."],
    ["Physical RX Lawrence bridge", "Redundant old checks accepted; physical contraction matches the exact Lawrence row space."],
    ["Independent refinement construction", "Separately built ℓ = 3, 5, 7, 9 grids/cylinders all give the same certified Fano quotient."],
    ["Regular-cover inequality", "1,026 exact rational subspace/weight cases satisfy the acceptance bound."],
    ["Adaptive passive clock", "All 256 state-dependent stopping policies in a four-step stationary toy satisfy the deterministic-horizon bound."],
    ["Reusable-register interface", "Five-qubit example: stationarity residual 4.2 × 10<sup>−17</sup>; killed-process failure below flux bound; split holding agrees; Ramsey coefficient inversion error 1.4 × 10<sup>−14</sup>."],
    ["Central projection", "Four-cell exact intertwining; Gibbs discrepancies below 7 × 10<sup>−16</sup> across five temperatures."],
    ["Finite harmonic reset", "65-digit moment, endpoint-independence, critical-damping, feedforward and arm-integral checks; residuals below 2 × 10<sup>−54</sup>."]
], [153, WIDTH-153])
h("Reproduction")
p("Run python verify_all.py from the package root. The verifier uses only the bundled source files and common Python scientific libraries: NumPy, SciPy and mpmath. Exact binary/rational certificates do not require the matroid discovery library. The report builder additionally uses ReportLab, matplotlib and Pillow.")
p("The package contains proof notes under sampler_route, decoding_route and intervention_route; reusable_register_opening.md; calibration_operation.md and its independent audit; numerical JSON outputs; exact issued Astra sources; the figure in PNG/SVG; this report and its builder; a source index and a SHA-256 manifest. Third-party full-paper text dumps and discovery binaries are excluded.")
h("Status interpretation")
p("“Completed” means the operation or theorem is derived with its hypotheses, proof and supplied checks in this dossier. It does not mean independent publication review, physical fabrication or experimental validation. Inherited Astra mathematics is used at the scopes expressly accepted in the issued question.")
p("The new outcomes are constructive: the sampler gate is settled for the published guarantees; the whole-campaign register operation is proved; canonical coherent preparation and central projection are supplied; and a finite active reset gives a real alternative to passive waiting. Remaining physical robustness questions are stated rather than silently delegated to the word “efficient.”", "caption")

page("20. Governing and primary sources")
p("The opening sources are pinned to commit e9bd2054d8e396d82dc89d59b9851f1827fc55ef; the accepted pointer companions [A3] were fetched at 3629d4ca14f495fb6999d2cd9bdd89a2be8c34ba. Exact issued returns and governing files are preserved. Missing portions of a captured native transcript are not reconstructed.", "small")
base = "https://github.com/harjassand/astra-research-knowledge/blob/e9bd2054d8e396d82dc89d59b9851f1827fc55ef/research/returns/"
refs = [
    ("A1", "P1 original return; selection brief and exact CSW comparator",
     base+"2026-11-05-p1-thermal-memory-opening/package/selection_brief.tex",
     "Accepted history compiler, loading theorem, physical contract and original comparator challenge. Adjacent exact original-return and comparator files are included."),
    ("A2", "P2 intervention-stream opening",
     base+"2026-11-05-p2-intervention-stream-opening/README.md",
     "Whole-campaign entropy/waiting construction and hard-family/access conditions. Exact original return and hard-families file are included."),
    ("A3", "P2 accepted local thermal-trial and finite pointer construction",
     "https://github.com/harjassand/astra-research-knowledge/blob/3629d4ca14f495fb6999d2cd9bdd89a2be8c34ba/research/returns/2026-11-05-p2-local-thermal-trials/package/thermal/FINITE_POINTER_REALIZATION.md",
     "The accepted finite pointer and reset files used by the harmonic companion are included as governing sources."),
    ("B1", "BDL: A passive self-correcting quantum memory in three dimensions",
     "https://arxiv.org/html/2605.10943v1",
     "Actual RX/RZ cell construction, §3.2; random embedding and passive-memory input. The exact physical coordinates, not the separate intuitive variant, enter the new proofs."),
    ("B2", "Hangleiter, Ju, Vazirani: Code Swendsen–Wang Dynamics",
     "https://arxiv.org/html/2510.08446v4",
     "Definition 10, Theorem 16 and Corollary 17: primal/dual Δ-graphic sufficient conditions and their defect dependence."),
    ("B3", "Goldberg and Jerrum: ferromagnetic Ising model on a regular matroid",
     "https://arxiv.org/abs/1010.6231",
     "Regular-matroid FPRAS using decomposition. SICOMP 42(3), 1132–1157 (2013)."),
    ("B4", "Piveteau, Quek, Franco Garrido: Gibbs state preparation through quantum decoding",
     "https://arxiv.org/pdf/2610.03566",
     "Full primary PDF read: Definitions 2.1–2.2, equations 38/44/59/77/120, Algorithm 2 and Theorems 3.1/4.1/5.1–5.2."),
    ("B5", "Shang, Wang, Stilck França: Quantum Gibbs State Preparation via Relative Decoding",
     "https://arxiv.org/pdf/2610.06667v2",
     "Complete versioned PDF read: algebraic compatibility, canonical source TFD, Theorem 6.1, §8 and Proposition B.7. HTML conversion ended early."),
    ("B6", "Somma, Boixo, Barnum, Knill: Quantum Simulations of Classical Annealing Processes",
     "https://arxiv.org/abs/0804.1571",
     "Quantum-walk stationary-state preparation and annealing; PRL 101, 130504 (2008)."),
    ("B7", "Bergamaschi and Chen: Fast Mixing of Quantum Spin Chains at All Temperatures",
     "https://arxiv.org/html/2510.08533v2",
     "Canonical TFD preparation for a bounded local one-dimensional source at fixed finite temperature, Corollary I.1."),
    ("B8", "Milburn and Shrapnel: Classical and Quantum Causal Interventions",
     "https://arxiv.org/abs/1809.03191",
     "Gaussian measurement and feedback interventions and their thermodynamic accounting; Entropy 20(9), 687 (2018), DOI 10.3390/e20090687."),
]
for tag, title, url, detail in refs:
    p("<b>["+tag+"]</b> "+link(url,title)+". "+html.escape(detail), "small")
p("All new proofs and deductions are attributed to this exchange; use of an existing algorithmic ingredient is identified where it enters. No novelty claim is based solely on an abstract or on absence of a search result.", "caption")

def footer(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(colors.HexColor("#D8E0E4"))
    canvas.line(48, 39, A4[0]-48, 39)
    canvas.setFont("DSans", 7.4)
    canvas.setFillColor(MUTED)
    canvas.drawString(48, 26, "ASTRA · Reusable thermal register · 5 November 2026")
    canvas.drawRightString(A4[0]-48, 26, str(doc.page))
    canvas.restoreState()
target = OUT / "Astra_Thermal_Register_Exchange.pdf"
doc = SimpleDocTemplate(
    str(target), pagesize=A4, rightMargin=48, leftMargin=48,
    topMargin=43, bottomMargin=52,
    title="A reusable thermal quantum register",
    author="Astra research",
)
doc.build(story, onFirstPage=footer, onLaterPages=footer)
(ROOT / "report_text.txt").write_text("\n\n".join(plain)+"\n")
print(target)
