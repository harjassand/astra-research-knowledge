"""Build the question-selection dossier using ReportLab and math figures."""
from pathlib import Path
import hashlib, html
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Image, Table, TableStyle
from PIL import Image as PILImage
from matplotlib.mathtext import math_to_image
import matplotlib
matplotlib.rcParams["mathtext.fontset"]="dejavuserif"
ROOT=Path(__file__).resolve().parent
OUT=ROOT.parent/"deliverables"
OUT.mkdir(exist_ok=True)
TMP=ROOT/"equations"
TMP.mkdir(exist_ok=True)
FONT=Path("/usr/share/fonts/truetype/dejavu")
for name,filename in (("DSerif","DejaVuSerif.ttf"),("DSerif-Bold","DejaVuSerif-Bold.ttf"),("DSans","DejaVuSans.ttf"),("DSans-Bold","DejaVuSans-Bold.ttf")):
    pdfmetrics.registerFont(TTFont(name,str(FONT/filename)))
for family in ("DSerif","DSans"):
    pdfmetrics.registerFontFamily(family,normal=family,bold=family+"-Bold",italic=family,boldItalic=family+"-Bold")
INK=colors.HexColor("#172D3D"); TEAL=colors.HexColor("#247A82"); MUTED=colors.HexColor("#586973"); PALE=colors.HexColor("#EDF4F5")
WIDTH=A4[0]-96
styles={
"body":ParagraphStyle("body",fontName="DSerif",fontSize=9.5,leading=14.25,spaceAfter=8,textColor=INK),
"small":ParagraphStyle("small",fontName="DSerif",fontSize=8.25,leading=11.6,spaceAfter=6,textColor=INK),
"caption":ParagraphStyle("caption",fontName="DSans",fontSize=8.1,leading=11.4,spaceAfter=8,textColor=MUTED),
"h1":ParagraphStyle("h1",fontName="DSans-Bold",fontSize=19.5,leading=25,spaceAfter=15,textColor=INK),
"h2":ParagraphStyle("h2",fontName="DSans-Bold",fontSize=12,leading=16,spaceBefore=9,spaceAfter=7,textColor=TEAL),
"title":ParagraphStyle("title",fontName="DSans-Bold",fontSize=28,leading=34,spaceAfter=20,textColor=INK),
"label":ParagraphStyle("label",fontName="DSans-Bold",fontSize=9,leading=13,spaceAfter=12,textColor=TEAL),
"table":ParagraphStyle("table",fontName="DSerif",fontSize=8.3,leading=11.8,spaceAfter=0,textColor=INK)}
story=[]; plain=[]
def p(text,style="body"):
    story.append(Paragraph(text,styles[style])); plain.append(text)
def h(text):p(text,"h2")
def page(title):
    if story:story.append(PageBreak())
    p(title,"h1")
def eq(tex,fontsize=14):
    key=hashlib.sha256((str(fontsize)+tex).encode()).hexdigest()[:15]
    f=TMP/(key+".png")
    if not f.exists():math_to_image("$"+tex+"$",str(f),dpi=240,format="png",color="#172D3D")
    with PILImage.open(f) as im:w,ht=im.size
    width=min(WIDTH,w*fontsize/10*72/240)
    image=Image(str(f),width=width,height=ht*width/w); image.hAlign="CENTER"
    story.extend([Spacer(1,4),image,Spacer(1,11)]); plain.append("MATH: "+tex)
def table(rows,widths):
    data=[[Paragraph(c,styles["table"]) for c in row] for row in rows]
    t=Table(data,colWidths=widths,hAlign="LEFT")
    t.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP"),("BACKGROUND",(0,0),(-1,0),PALE),("LINEBELOW",(0,0),(-1,0),.7,TEAL),("LINEBELOW",(0,1),(-1,-1),.3,colors.HexColor("#D8E0E4")),("LEFTPADDING",(0,0),(-1,-1),7),("RIGHTPADDING",(0,0),(-1,-1),7),("TOPPADDING",(0,0),(-1,-1),7),("BOTTOMPADDING",(0,0),(-1,-1),7)]))
    story.extend([t,Spacer(1,10)]); plain.extend(" | ".join(row) for row in rows)

p("ASTRA RESEARCH / INDEPENDENT QUESTION SELECTION","label")
p("The recoverability boundary<br/>under spatial burst damage","title")
p("5 November 2026 · Foundational question and constructive opening","caption")
h("The selected full question")
p("For a locally operated information system exposed to spatial Poisson bursts with radius tail Pr(R &gt; r) = r<super>-α</super>, is <b>α &gt; d + 1</b> the sharp low-intensity condition for recovering an initially finite unknown input at every finite requested time? Can a local operation attain it while including commissioning, corruptible control and decoding state, finite readout, hardware and execution costs?")
p("The first concrete construction target is a two-dimensional memory, where the proposed boundary is <b>α = 3</b>. A fixed nontrivial recovery advantage, such as binary error at most 1/4 uniformly in the requested horizon, is sufficient for the foundational question. Arbitrarily accurate terminal measurements and an infallible infinite stream of answers are not built into that target.")
h("Why resolving it would matter")
p("A complete resolution would distinguish environments in which local redundancy and repair can preserve information from environments in which <b>every finite-speed controller eventually forgets</b>, even though the average local damage rate is finite. The positive side must supply useful recovery; the negative side applies to any computation that must later distinguish its initial inputs. This is a conditional foundation for reliable information processing, not a claimed deployed apparatus or a universal-computation theorem.")
table([["<b>Established opening</b>","<b>Missing central operation</b>"],["Exact whole-cone erasure bound; finite-flux impossibility; seed, spread and fixed-device resource ceilings; local isolated-error repair.","An actual finite-seed, locally decoded recovery architecture under unflagged burst corruption, attaining the boundary or identifying a sharper one."]],[WIDTH/2,WIDTH/2])
p("Selection was made from independent internal derivations and public primary research, without consulting other Pro researchers' new tournament proposals. All completed Astra predecessors are preserved at their original scopes.","caption")

page("1. The operation and its exact contract")
h("Unknown information and complete support")
p("At the end of commissioning, the unknown binary input B has equal prior probabilities. All jointly input-dependent accessible state is confined to C₀ = [−r₀,r₀]<super>d</super>. This includes backups, keys, controller records, retained outputs and any external record available for recovery. Everything outside has a joint law independent of B. No further input copy is supplied after commissioning.")
p("The lower theorem allows unlimited initially blank substrate and an ideal final decoder. For the positive target, each finite requested horizon T must have finite, fully charged hardware and a local readout. A uniform family of horizon-dependent layouts is allowed; the finite input-dependent seed is fixed independently of T. Requiring autonomous fabrication, translation invariance or a single homogeneous infinite automaton would add demands not needed for this question.")
h("Local control and faults")
p("In the core model, every input-dependent influence propagates at speed at most v. Finite-range, bounded-depth local circuit layers give an exact such contract. Immutable local gate laws and a bounded-rate input-independent schedule are declared premises; every mutable register used for data, clocks, addressing, control or decoding is exposed to the declared faults. A physical implementation must earn the schedule and gate-law abstraction and include their resource costs.")
p("Burst centers form a homogeneous Poisson process of intensity λ dz dt in d-dimensional space. Independent marks R ≥ 1 define a cube z + [−R,R]<super>d</super>. Assume E[R<super>d</super>] is finite. For the lower bound a burst resets every accessible mutable degree of freedom in the cube to an input-independent state, leaving no recoverable input-dependent diagnostic outside. This reset is one admissible fault within the harder arbitrary-corruption class for the positive construction. A known reversible flip is not an erasure.")
h("Useful output and accuracy")
p("At a requested finite time the device must return an estimate through a specified finite local decoding and metrology procedure. Query delay, faults during collection, output storage and energy count. The total target is, for example, Pr(B̂<sub>T</sub> ≠ B) ≤ 1/4 for every finite T, including preparation and readout errors. Evaluate the lower bound at the actual delivery time if readout adds delay. A surviving copy at an unknown inaccessible location is insufficient.")
p("This is register corruption with intact supplied update laws. It is not a model of destroyed processors, arbitrary permanent geometric barriers, unrestricted fault timing, or damage generated by a specified physical material. Those classes require new reductions. Perfect erasure flags would also be an extra capability.","caption")

page("2. A universal causal erasure theorem")
p("All possible input dependence at time t is inside C<sub>t</sub> = [−(r₀ + vt), r₀ + vt]<super>d</super>. A radius-R burst covers that cube precisely when its center is in a cube of volume [2(R − r₀ − vt)<sub>+</sub>]<super>d</super>. Poisson thinning therefore gives the following exact mean number of complete-cover events by time T:")
eq(r"\Lambda(T)=\lambda 2^d\int_0^T\mathbb{E}(R-r_0-vt)_+^d\,dt")
eq(r"\Lambda(T)=\frac{\lambda 2^d}{v(d+1)}\mathbb{E}\left[(R-r_0)_+^{d+1}-(R-r_0-vT)_+^{d+1}\right]",12)
p("The second expression is the expectation of a nonnegative difference. It remains valid when both separate higher moments are infinite. Finite E[R<super>d</super>] makes the finite-T integral finite.")
h("Theorem and proof")
eq(r"\operatorname{TV}(P_0^T,P_1^T)\leq e^{-\Lambda(T)},\qquad P_e(T)\geq\frac{1-e^{-\Lambda(T)}}{2}")
p("Here P<sub>b</sub><super>T</super> is the law of all accessible state under input b, and P<sub>e</sub> is optimal uniform-prior binary decoding error. Couple the two input worlds with the same outside initial state, private randomness, burst field and future control randomness. Until a complete-cover reset, all differences remain within C<sub>t</sub>. That reset removes every difference; outside the cube the worlds were already equal. They remain equal thereafter. The chance of no such reset is exp(−Λ(T)), so the coupling inequality bounds total variation. The binary testing identity gives the error bound. Adaptive control, redundant coding and a global decoder cannot defeat coalescence.")
p("The same independent reset event gives I(B; X<sub>T</sub>) ≤ exp(−Λ(T)) H(B): reveal whether a complete-cover reset occurred. Conditional on one, the state carries no input information; conditional on none, it carries at most H(B).")
eq(r"\Lambda(\infty)=\frac{\lambda 2^d}{v(d+1)}\mathbb{E}(R-r_0)_+^{d+1}")
p("Thus finite E[R<super>d</super>] together with infinite E[R<super>d+1</super>] forces eventual forgetting for every finite seed. The first complete-cone erasure occurs almost surely at a finite time. Finite E[R<super>d+1</super>] removes this obstruction only; it is not a recovery theorem.")

page("3. What the bound forces quantitatively")
p("Use the exact Pareto law Pr(R &gt; r) = r<super>−α</super> for r ≥ 1, with α &gt; d and r₀ ≥ 1. Define the constant below without absorbing the factor 2<super>d</super>:")
eq(r"C_{d,\alpha}=\frac{\Gamma(d+1)\Gamma(\alpha-d)}{\Gamma(\alpha)},\qquad\mathbb{E}(R-a)_+^d=C_{d,\alpha}a^{d-\alpha}")
eq(r"\Lambda(T)=\frac{\lambda 2^d C_{d,\alpha}}{v(d+1-\alpha)}\left[(r_0+vT)^{d+1-\alpha}-r_0^{d+1-\alpha}\right]",12)
p("The last display applies when α ≠ d + 1. At the critical exponent, it becomes λ2<super>d</super>C<sub>d,α</sub> log(1 + vT/r₀)/v. For d &lt; α &lt; d + 1, distinguishability decays at least as a stretched exponential; at equality, at least as a power. Above d + 1, the cumulative complete-cone hazard is finite.")
h("A paid initial spatial extent")
eq(r"\Lambda(\infty)=\frac{\lambda 2^d C_{d,\alpha}}{v(\alpha-d-1)}r_0^{-(\alpha-d-1)}\quad(\alpha>d+1)")
eq(r"r_0\geq\left[\frac{\lambda 2^d C_{d,\alpha}}{v(\alpha-d-1)[-\log(1-2\delta)]}\right]^{1/(\alpha-d-1)}",13)
p("The final inequality is necessary for error at most δ &lt; 1/2 at every horizon. It prices the supplied seed's spatial extent, not automatically its number of cells. Sparse records can be far apart. If the initial input starts in one bare cell, preparing a bigger seed does not erase its earlier exposure: an early-loss floor remains.")
h("A fixed device cannot hide the tail")
p("For an autonomous device whose entire accessible state stays within a cube of half-side L, full-cover resets have constant rate h<sub>L</sub> = λ2<super>d</super>C<sub>d,α</sub>L<super>d−α</super>. Therefore its recoverability horizon at error δ obeys:")
eq(r"T_\delta\leq\frac{-\log(1-2\delta)}{\lambda2^dC_{d,\alpha}}L^{\alpha-d}")
p("Even perfect repair cannot produce exponential endurance in extent against this fixed positive heavy-tail law. For a filled constant-density cube the ceiling is polynomial in hardware volume. That volume translation requires the shape/density premise; it is not valid for arbitrary sparse geometry.","caption")

page("4. The same local hit rate can hide different limits")
im=Image(str(ROOT/"figures/cone_erasure_bound.png"),width=WIDTH,height=WIDTH*3.9/10)
story.extend([im,Spacer(1,8)])
p("Figure 1. Exact analytic lower bounds for d = 2, v = r₀ = 1. All three environments have point-hit rate λ2<super>d</super>E[R<super>d</super>] = 0.03; λ is adjusted accordingly. The curves are unavoidable error bounds, not recovery performance. The α = 4 curve's small finite limit certifies no achievable success rate.","caption")
h("Finite disturbance flux is an insufficient specification")
p("A point is hit at rate λ2<super>d</super>E[R<super>d</super>]. In two dimensions, α = 5/2 gives finite average damaged area per unit spacetime volume but infinite third radius moment. Every finite-seed local architecture eventually loses its original input, even with unlimited space in which to replicate it. An α = 4 law can be scaled to the same point-hit rate but has finite complete-cone hazard. A converse would turn this distinction into a sharp recoverability classification.")
p("If a declared physical model assigns deposited energy e per unit damaged volume, the average disturbance-power density is eλ2<super>d</super>E[R<super>d</super>]. This makes the example a finite-mean-power obstruction within that additional model. No universal energy-per-erasure law or hard pathwise power bound is asserted. The burst process itself still needs a physical justification for any platform claim.")
h("The minimum rate of spreading information")
p("For a general deterministic support radius a(t), the same proof replaces r₀ + vt by a(t). With a(t) proportional to t<super>γ</super>, the Pareto hazard is proportional to the integral of t<super>−γ(α−d)</super>. Avoiding divergent complete-cover hazard requires:")
eq(r"\gamma(\alpha-d)>1")
p("Finite propagation permits γ ≤ 1, which recovers α &gt; d + 1. This is a necessary support-growth law, not an attaining architecture. Under a filled-region design, volume grows as a(t)<super>d</super>, and bounded power per active cell charges its time integral. Unbounded-time operation has unbounded total resources; every finite mission has a finite bill.")

page("5. The constructive opening: repair a damaged region")
p("An existing local mechanism gives the right isolated-event timescale. On the square lattice use the north-east-center majority rule:")
eq(r"x_{t+1}(z)=\operatorname{maj}\{x_t(z),x_t(z+e_1),x_t(z+e_2)\}")
p("On an otherwise correct uniform background, any finite error set inside an a by b rectangle disappears within a + b − 1 synchronous rounds and never leaves the rectangle. By monotonicity it suffices to start with the full rectangle erroneous. At round t its surviving sites satisfy the following inequality within the rectangle:")
eq(r"(a-1-x)+(b-1-y)\geq t")
p("Induction under majority proves the formula, so no sites remain at t = a + b − 1. Complement symmetry treats either stored bit. This earns an O(R) isolated-corruption repair time with constant local state and finite-range updates. Toom stability and modern contour machinery are established antecedents [1], not discoveries claimed here.")
h("A decisive failure of the naive composition")
p("Let the initial erroneous sets be A = {(1,0)} and B = {(0,1)}. Either singleton disappears in one round. Their union produces an error at (0,0), which disappears only in the following round. A diagonal of m + 1 singleton errors generates successive diagonals and survives m + 1 rounds. Independently drawn one-round repair regions therefore fail to contain the collective evolution.")
eq(r"F(A)=F(B)=\varnothing,\qquad F(A\cup B)=\{(0,0)\}")
p("This is the obstacle an independent-Boolean-grain reduction misses: separate corruption regions can cooperate to sustain an error. A valid comparison must control mergers and the resulting semantics, not just the volume of isolated repair cones.")
h("Why the local rule is not already the complete operation")
p("Toom's rule also erodes a finite island of the desired bit in the opposite blank background. An infinite correctly prepared phase cannot be substituted for a finite commissioned input. Nor does the eroder explain how fallible control state identifies authentic data, grows the encoding, collects a readout, or handles faults during those operations. The full question allows input-independent fixed circuit geometry, so autonomous self-assembly is not an extra gate; finite-seed encoding and local decoding remain essential.")

page("6. A quantitative target for the missing operation")
h("The large-burst term is derived")
p("Consider a spacetime block with spatial cube [−L,L]<super>d</super> and duration L/v. A burst of radius R ≥ L intersects the cube for a center volume [2(R + L)]<super>d</super>. Under the Pareto law its expected count is exactly:")
eq(r"\mu_L=\frac{\lambda2^d\alpha}{v}L^{d+1-\alpha}\sum_{j=0}^d\binom{d}{j}\frac{1}{\alpha-j}",13)
p("Thus the chance of such an event is at most μ<sub>L</sub>. This accounts for centers outside the device and explains the d + 1 exponent: spatial footprint contributes d dimensions and a local repair period contributes one more. It is a counting result, not yet a decoder error bound.")
h("The recurrence that must be earned")
p("At scales L<sub>k+1</sub> = B L<sub>k</sub>, build a finite local encoding/repair/readout gadget whose bad large block requires either a large physical burst or two separated bad smaller blocks. The desired estimate is:")
eq(r"p_{k+1}\leq C p_k^2+D\lambda L_{k+1}^{d+1-\alpha}")
p("For β = α − d − 1 &gt; 0, the algebra closes at p<sub>k</sub> ≤ AλL<sub>k</sub><super>−β</super> when the base scale and λ meet explicit smallness conditions. For example, with A = 2D, the quadratic term closes if λL₀<super>−β</super> ≤ 1/(4CDB<super>β</super>) and the base estimate holds. The premise is the actual two-subblock implication, including a valid joint-probability bound; writing a square does not establish independence.")
h("What that construction would buy")
p("A fixed block of extent L used for time T would have approximately T/L macroscopic repair periods. The large-burst contribution would then scale as λT L<super>d−α</super>, matching the universal fixed-device ceiling. Growing through geometric scales would cost a summable total of order λr₀<super>−β</super>, matching the seed-extent exponent. These are conditional deductions from a proved gadget recurrence, not established upper bounds for any present architecture.")
p("Naively truncating radii and feeding the result into an ordinary local-stochastic threshold loses the fixed-intensity goal. Dependence coloring uses K = O(R<sub>*</sub><super>d</super>) classes. Even using the known finite moment to bound a site's one-step fault probability by p = O(λE[R<super>d</super>]), the effective support bound is p<super>1/K</super>. This black-box route can demand exponentially small λ as the cutoff grows. The needed operation must exploit sparse large clusters directly.","caption")

page("7. The strongest existing methods and the remaining gap")
table([
["<b>Primary machinery</b>","<b>What it already earns</b>","<b>What is not supplied for this question</b>"],
["Toom contours [1]","Stability of suitable local automata under weak local noise; modern extensions include intrinsic random update rules.","A single unbounded burst gives polynomially likely large fault sets. The required local-stochastic support bound and finite-seed operation do not follow."],
["Gács self-organization [2]","Reliable asynchronous local computation and a hierarchy built over time; consult the corrected 2024 version.","Reliable organization itself is established. A transfer to this unbounded spatial-burst law still needs a proof."],
["Modern 2D memories [12]","Alternative local repair rules and robust memory phases, with analytical and numerical results.","The local-update noise model and initially encoded magnetization do not supply this finite-seed marked-burst recovery operation."],
["Poisson hail [3,4]","Small-intensity workload stability under d+1+ε moment conditions, then sharper spatial/temporal moment regions.","Workload tightness does not encode, preserve or decode an unknown bit. Footprint-wide max updates are not a supplied causal local decoder."],
["Vacant Boolean percolation [5]","A vacant phase at low intensity for finite dimension-th radius moment.","Undirected offline connectivity is not a causal, online, fallible recovery operation. Interacting repair regions also require a valid reduction."],
["Disaster contact processes [6]","Disaster geometry changes survival even when simple per-site death-rate comparisons agree.","Population survival or flagged copying is weaker than recovery under unflagged corruption of data and control state."]
],[106,188,WIDTH-294])
h("Why Poisson hail is the most important comparison")
p("With nominal repair time proportional to radius, the strict Pareto regime α &gt; d + 1 already falls within known workload-stability machinery [3,4]. A new moment calculation alone would fall short. The central scientific contribution would be a valid bridge from corrupted local information dynamics to a tractable process, or a new obstruction showing why that bridge is impossible. The exact finite-(d + 1)-moment endpoint with logarithmic corrections is not settled by merely citing a strict higher-moment theorem.")
p("The search identifies these close antecedents and the contract mismatch. It does not establish historical novelty or prove that no existing decoder theorem can be adapted. A primary result already providing the same finite-seed, local, corruptible-controller and readout operation would replace the proposed construction task.","caption")

page("8. Full resource and uncertainty accounting")
table([
["<b>Resource</b>","<b>Obligation in a completed operation</b>"],
["Acquisition","Supply or earn λ, the tail envelope, burst support and fault meaning. Estimate finite-horizon risk if the infinite-tail class is not justified."],
["Commissioning","Specify writer reliability, availability, duration, initial seed extent and preparation error. Withdraw external input copies; count every surviving record."],
["Hardware and control","Charge the entire finite-horizon layout, bounded local state, gates, clock distribution, control registers, repair work and any material replacement. The model leaves immutable gate laws intact."],
["Useful operation","Preserve an unknown input and produce a specified estimate. Mere time to first catastrophe, low repair backlog, or a surviving inaccessible copy is insufficient."],
["Metrology and readout","Implement finite local collection and decoding. Count waiting exposure, detector uncertainty, output storage and the final interface's error floor."],
["Computation and energy","Give actual local-operation counts and latency. Per-cell power bounds imply a charged integral of active hardware, not finite total energy for infinite operation."],
["Deployment and reuse","State how a finite mission is installed and powered, and how later queries use retained information. Reinjecting the answer or using a protected external backup changes the contract."]
],[105,WIDTH-105])
h("A precise acquisition limit")
p("Let F₀ have a bounded radius and let G have finite d-th but infinite (d + 1)-st moment. For F<sub>ε</sub> = (1 − ε)F₀ + εG, n independent radius samples can be coupled to the F₀ samples with mismatch probability at most nε. Their moment classification nevertheless differs for every ε &gt; 0. No uniformly valid finite-sample certificate can distinguish the two classes over unrestricted laws. A structural tail envelope is substantive information, not something a short ordinary trace earns.")
p("For a filled expanding region with extent r₀ + vt and operating power density p, cumulative operating energy is proportional to p[(r₀ + vT)<super>d+1</super> − r₀<super>d+1</super>]/[v(d + 1)]. This is a design cost under a declared local-power convention, not a universal thermodynamic lower bound. Sparse alternatives need their own geometry, transport and readout analysis.","caption")

page("9. The precise question to take into the exchange")
p("<b>Question.</b> Fix the spatial burst law and local register-corruption contract. For the exact Pareto family α &gt; d, does there exist, for all sufficiently small fixed λ &gt; 0, a uniform family of finite local operations with a finite input-dependent seed independent of horizon, and finite charged preparation, hardware, control and readout, that returns an unknown bit with total error at most 1/4 at every finite requested horizon, <b>if and only if α &gt; d + 1</b>? If the proposed boundary fails, what sharper obstruction and attaining operation replace it?")
p("The first implementation target is d = 2. The lower theorem is already general in d. A specified family of local schedules and layouts is allowed; all mutable decoding and control state is corruptible. Reliable immutable local laws remain an explicit abstraction. The finite-horizon family must bound local state, degree, hardware density, update rate and construction complexity, and state its hardware, local work, query delay and preparation bill. Unbounded initial encoding or a protected answer source cannot be hidden in its design.")
h("The central operation that must actually be overcome")
p("Build a local block gadget that preserves the input's meaning while repairing arbitrary corrupted data and metadata, and prove the two-separated-bad-subblocks condition under the actual marked burst field. Connect those gadgets to a finite input seed and an output interface. The semantic guarantee must survive interactions such as the Toom diagonal example. Hail stability, an infinite prepared phase, an offline surviving path or an ideal global decoder is insufficient by itself.")
h("What would settle or displace the question")
p("A positive resolution would provide the explicit operation and the reduction or direct analysis establishing its uniform finite-horizon guarantee. A negative resolution would identify a stronger architecture-independent information-loss mechanism above α = d + 1 and then construct an operation attaining the replacement boundary. A known primary theorem at the same input, fault and readout contract would settle the question by a proved translation, not by renaming its objects.")
p("This selection should be revised if retaining one bit with charged local readout still buys no substantive conclusion beyond an already available operation, or if a simpler acceptable physical interface removes the supposed obstacle. Requiring autonomous self-fabrication, universal computation, arbitrary precision at a single noisy terminal, or a hard global power bound is not used to manufacture difficulty. Those are distinct extensions.")
h("What success does and does not imply")
p("The successful theorem would classify scalable recoverability under the supplied heavy-tail law and give a concrete reliability architecture. The no-go side constrains every later input-dependent decision or computation. A one-bit recovery construction does not by itself imply universal reliable computation, positive information density, an economical device or a measured environmental law. Those further bridges would have to earn their own operational consequences.")

page("10. Independent alternatives, tested and retained")
h("Continued-operation response acquisition")
p("The independent LTI route uses fresh private signs to obtain Y<sub>kj</sub> = s<sub>k</sub>a<sub>j</sub> + z<sub>kj</sub>, with predictable nuisance. A dissipation inequality bounds Σz<sub>kj</sub><super>2</super> by Q<sub>M</sub> = A + BM, including initial storage, ongoing influx and probe/operating inputs. The derived finite response estimate has radius:")
eq(r"\eta+\frac{\sqrt{2Q_M\log(2L/\delta)}}{M}")
p("This useful conditional companion needs no equilibration, but its central cancellation is already within semiparametric system identification [7]. A passive delayed-return construction also shows why finite acquisition cannot certify unrestricted future response. It therefore does not displace the selected question. P2's exact loaded-LTI/private-timing predictive preparation remains separate; continuing power influx and arbitrary future response are new premises/tasks, not automatic consequences [11].")
h("Private reassignment and causal control")
p("Another independent route derived (m)<sub>k</sub>/(N)<sub>k</sub> ≤ (m/N)<super>k</super> for a private random permutation of a fixed physical fault set. Smith's private coding work already develops this scrambling mechanism [8]. Local geometry can still block required communication. The notes retain exact wall and causal transport checks.")
p("Strong modern quantum fault-tolerance results already tolerate global adversarial faults [9]. They do not automatically supply this classical local burst operation: [9] explicitly uses free noiseless classical computation, while a recent local quantum compiler leaves additional classical waiting-time fault tolerance unresolved [10]. No bridge from these quantum classes is assumed.")
h("Preserved Astra machinery")
p("The completed productive-control package is included byte for byte. Its all-depth certificate optimizes useful work and changes the failure law under observed skip-free dynamics and justified transition envelopes. Its repair companion retains the separate finite-source, resource and shared-support contract. The earlier direct acquired-prevention result, same-access absolute-forecast lower bound, all-safe-start mean theorem, finite operating warm-up, grouped-wait assay, independent constructions and first-event machinery remain intact.")
p("The earlier direct/capacity cancellation is not relabeled as an advantage over an equally informed direct method. No interacting-Gibbs, skip-free, finite-source-repair, LTI or burst-process physical reduction is assumed. All independent opening notes and checks are retained, including the routes rejected during selection.","caption")

page("11. Verification, provenance and primary references")
h("Verification performed")
p("The root checker independently compares five excess-moment, cumulative-hazard and large-burst-footprint formulas against numerical quadrature, and checks the exact two-singleton Toom interaction. The independent fault-tolerance checker verifies 121 rectangular erosion cases, 24 diagonal interactions and 12 Pareto parameter cases. The independent reassignment checker verifies 380 exact support calculations and its geometric/transport examples. These check arithmetic and finite examples; they neither prove the missing recurrence nor validate a physical apparatus.","small")
p("The preserved predecessor archive has SHA-256 a94aefd585ce5a61e3e19dabf79fe27c61480ea302062bb78a2621c3992d9a62. It contains the full direct-prevention archive and its earlier preservation receipts. The new package carries a separate manifest and preservation receipt. Original predecessor files were not edited.","small")
h("Primary references")
refs=[
("1","J. M. Swart, R. Szabó and C. Toninelli (2026). Peierls Bounds from Toom Contours. Journal of Theoretical Probability 39, article 45.","https://doi.org/10.1007/s10959-026-01508-2"),
("2","P. Gács. Reliable Cellular Automata with Self-Organization. Journal version 2001; corrected and strengthened author version, 2024.","https://arxiv.org/abs/math/0003117v2"),
("3","S. Foss, T. Konstantopoulos and T. Mountford (2018; online 2016). Power Law Condition for Stability of Poisson Hail. J. Theor. Probab. 31, 684-704.","https://doi.org/10.1007/s10959-016-0723-3"),
("4","T. Mountford and Z. Wang (2024). Stable Systems with Power Law Conditions for Poisson Hail. Advances in Applied Probability 56, 315-353.","https://arxiv.org/abs/2102.07406"),
("5","M. D. Penrose (2018). Non-triviality of the vacancy phase transition for the Boolean model. Electronic Communications in Probability 23, paper 49.","https://arxiv.org/abs/1706.02197"),
("6","N. Lanchier (2011). Contact Process with Destruction of Cubes and Hyperplanes: Forest Fires Versus Tornadoes. J. Applied Probability 48, 352-365.","https://doi.org/10.1239/jap/1308662632"),
("7","M. Simchowitz, R. Boczar and B. Recht (2019). Learning Linear Dynamical Systems with Semi-Parametric Least Squares. COLT, PMLR 99, 2714-2802.","https://proceedings.mlr.press/v99/simchowitz19a.html"),
("8","A. Smith (2006 preprint; SODA 2007). Scrambling Adversarial Errors Using Few Random Bits, Optimal Information Reconciliation, and Better Private Codes.","https://eprint.iacr.org/2006/020"),
("9","N. P. Breuckmann, L. Golowich and U. Vazirani (2026). Fault-Tolerant Quantum Computation with Adversarial Errors, arXiv:2608.16857v2.","https://arxiv.org/html/2608.16857v2"),
("10","S. H. Choe and R. König (2025). How to Fault-Tolerantly Realize Any Quantum Circuit with Local Operations. PRX Quantum 6, 010357.","https://doi.org/10.1103/PRXQuantum.6.010357"),
("11","P2, predictive_preparation.md. Exact supplied commit c11d35bd2e07116e214b4388302595cfedbd770e; blob 6b7f2cc68e03b3849459e667fb5809dd6e41d738. Stored unchanged in the predecessor package.","https://github.com/harjassand/astra-research-knowledge/blob/c11d35bd2e07116e214b4388302595cfedbd770e/research/returns/2026-11-05-p2-predictive-preparation/package/predictive_preparation.md"),
("12","E. Pajouheshgar, A. Bhardwaj, N. Selub and E. Lake (2026). Exploring the Landscape of Nonequilibrium Memories with Neural Cellular Automata. Physical Review Letters 136, 037102.","https://arxiv.org/html/2508.15726v2")]
for n,desc,url in refs:p(f'[{n}] {desc} <link href="{html.escape(url,quote=True)}" color="#247A82">Primary source</link>.',"small")

def footer(canvas,doc):
    canvas.saveState(); w,height=A4
    canvas.setStrokeColor(colors.HexColor("#D8E0E4"));canvas.setLineWidth(.5)
    canvas.line(48,height-36,w-48,height-36)
    canvas.setFont("DSans",7.3);canvas.setFillColor(MUTED)
    canvas.drawString(48,height-27,"ASTRA / RECOVERABILITY UNDER SPATIAL BURSTS")
    canvas.drawString(48,25,"QUESTION-SELECTION OPENING · RECOVERY CONVERSE UNPROVED")
    canvas.drawRightString(w-48,25,str(doc.page));canvas.restoreState()
doc=SimpleDocTemplate(str(OUT/"Astra_Burst_Recoverability_Question.pdf"),pagesize=A4,rightMargin=48,leftMargin=48,topMargin=52,bottomMargin=44,title="The recoverability boundary under spatial burst damage",author="Astra research - question selection",pageCompression=1)
doc.build(story,onFirstPage=footer,onLaterPages=footer)
(ROOT/"report_text.txt").write_text("\n\n".join(plain)+"\n")
print(OUT/"Astra_Burst_Recoverability_Question.pdf")
