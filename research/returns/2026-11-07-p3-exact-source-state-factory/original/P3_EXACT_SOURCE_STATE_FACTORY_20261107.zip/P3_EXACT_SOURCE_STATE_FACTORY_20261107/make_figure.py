"""Standalone scientific figure from theorem formulae and executed diagnostics."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Polygon
ROOT=Path(__file__).resolve().parent
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":10,
                     "axes.spines.top":False,"axes.spines.right":False})
fig,axs=plt.subplots(1,3,figsize=(14.7,4.6),layout="constrained")
ax=axs[0]
t=np.linspace(0,2*np.pi,400)
ax.plot(np.cos(t),np.sin(t),color="#64748b",lw=1.5,label="Physical Bloch disk")
ax.add_patch(Polygon([(1,0),(0,1),(-1,0),(0,-1)],fill=False,
                     edgecolor="#176b87",lw=1.5,label="Six-state palette, z=0"))
ax.add_patch(Rectangle((-.25,-.25),.5,.5,facecolor="#83d6b7",edgecolor="#157058",
                       alpha=.8,label="Declared source region"))
ax.scatter([1,0,-1,0],[0,1,0,-1],c="#176b87",s=22)
ax.set(xlim=(-1.1,1.1),ylim=(-1.1,1.1),xlabel=r"$r_x$",ylabel=r"$r_y$",
       title="A. Exact transpose on a declared interior")
ax.set_aspect("equal")
ax.legend(loc="upper center",bbox_to_anchor=(.5,-.17),fontsize=8,frameon=False)
ax=axs[1]
r=np.linspace(0,.32,300)
H=2166/(1-3*r)**2
ax.semilogy(r,H,color="#176b87",lw=2,label="Proved expected-copy upper bound")
rec=json.loads((ROOT/"SYNTHETIC_RECORD.json").read_text())
means=[z["mean_raw_source_queries"] for z in rec]
ax.scatter([.25]*len(means),means,c="#b25a21",s=30,label="Capped synthetic means (five sources)")
ax.annotate("1 fallback in 12,000 runs\n100,000-query diagnostic cap",
            xy=(.25,min(means)),xytext=(.02,500),fontsize=9,
            arrowprops={"arrowstyle":"-","color":"#b25a21"})
ax.set(xlabel=r"Declared bound $|r_j|\leq r_0$",
       ylabel="Fresh source queries / output",
       title="B. Source cost is paid",ylim=(200,2e6))
ax.grid(alpha=.15)
ax.legend(loc="upper center",bbox_to_anchor=(.5,-.17),fontsize=8,frameon=False)
ax=axs[2]
r=np.logspace(-4,-.55,300)
for k,c in [(2,"#176b87"),(4,"#157058"),(8,"#b25a21")]:
    ro=np.tanh(k*np.arctanh(r))
    ratio=np.log1p(-ro*ro)/np.log1p(-r*r)
    ax.semilogx(r,ratio,c=c,lw=1.8,label=f"Cooling power k={k}; limit {k*k}")
    ax.axhline(k*k,c=c,lw=.7,ls="--",alpha=.6)
ax.set(xlabel="Input Bloch magnitude near zero",
       ylabel="Necessary expected copies",
       title="C. Information bound for exact cooling")
ax.grid(alpha=.15)
ax.legend(loc="upper center",bbox_to_anchor=(.5,-.17),fontsize=8,frameon=False)
fig.suptitle("Exact source-to-state processing: possibility, implementation cost and limits",
             fontsize=15,weight="bold")
fig.savefig(ROOT/"SOURCE_STATE_FACTORY.png",dpi=190,bbox_inches="tight")
fig.savefig(ROOT/"SOURCE_STATE_FACTORY.svg",bbox_inches="tight")
