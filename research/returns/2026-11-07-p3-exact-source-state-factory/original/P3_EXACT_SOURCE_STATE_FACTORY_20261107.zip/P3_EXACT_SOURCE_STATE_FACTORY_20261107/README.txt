P3 EXACT SOURCE-TO-STATE FACTORY — 7 NOVEMBER 2026

Read P3_EXACT_SOURCE_STATE_FACTORY_20261107_RETURN.txt for the complete theorem,
proofs, access conditions, costs, limits, and source credits.

This is new research for the selected source-to-state question. It preserves
the larger unfinished programme of economical repeatable many-body physical-state
control. No physical execution or general economical state-control capability
is claimed.

FILES
state_factory.py
  New rational-arithmetic orchestration of the established Huber scalar factory.
  Unknown Pauli source probabilities are supplied ONLY through bit callables.
  Exact ideal mode and bounded mode with unconditional fallback are distinct.
exact_algebra.py
  Q(sqrt(2),i) matrix arithmetic and the exact two-qubit entangled-target audit.
run_audits.py
  125 exact state identities, the exact entangled-target certificate,
  seeded synthetic diagnostics, and exact rational cutoff certificates.
make_figure.py
  Standalone scientific figure from the formulas and executed record.
JSON files
  Exact certificates and separately labelled binary64/synthetic diagnostics.
SOURCE_ACCESS_NOTES.txt
  All inherited notes, verbatim, with new source-use notes prepended.

REPRODUCE
  python run_audits.py
  python make_figure.py

No installation is required in the supplied workspace. The core scalar emitter
uses the Python standard library. Diagnostics and plots use already available
NumPy and Matplotlib. A physical run would replace each synthetic source callable
and the pseudorandom fair-bit generator with independently warranted interfaces.

EXAMPLE
  from fractions import Fraction
  from state_factory import Runtime, factory_labels, deadline_parameters
  plan = deadline_parameters(1, Fraction(1,4), Fraction(1,100))
  runtime = Runtime(physical_fair_bit, plan["limits"])
  result = factory_labels([[measure_X_fresh, measure_Y_fresh, measure_Z_fresh]],
                          Fraction(1,4), runtime)

Each measurement callable consumes a fresh copy of the same unknown source.
Read the report before interpreting result["labels"] or a timeout: the physical
output includes paid reset and preparation, and all labels/timing records are
internal. Returning a success label is not an exact conditional-output guarantee
for the bounded version.

The general finite-dimensional classification is proved and constructively
specified in the report; this executable specializes to the declared qubit cube.
