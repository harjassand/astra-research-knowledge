"""Mathematical audits and seeded synthetic diagnostics. No physical experiment."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json, math, random, time
import numpy as np
from state_factory import (Runtime,Limits,factory_labels,source_mean_bound,
                           deadline_parameters,rational_fixture_source,gate_tape)
from exact_algebra import (I,PAULIS,state,palette,weights,add,scale,transpose,
                           equal,target_fixture)

ROOT=Path(__file__).resolve().parent

def run():
    started=time.time()
    vals=[F(-1,4),F(-1,8),F(0),F(1,8),F(1,4)]
    count=0
    for r in product(vals,repeat=3):
        ws=weights(r)
        assert sum(ws.values())==1 and min(ws.values())>=F(1,24)
        mixed=[[0,0],[0,0]]
        for (axis,s),w in ws.items():
            mixed=add(mixed,scale(palette(axis,s),w))
        assert equal(mixed,transpose(state(r)))
        for j in range(3):
            signed=(1,-1,1)[j]*r[j]
            p=(1+signed)/2
            inner=F(3,2)*(1-p)
            g=1-inner
            q=2*g
            assert q==(1+3*signed)/2
            assert 0<=inner<=1-F(1,16)
            assert 0<=q<=1-F(1,8)
        count+=1
    two=target_fixture()
    U=np.array([[q.complex() for q in row] for row in two.pop("U")])
    target=np.array([[q.complex() for q in row] for row in two.pop("target")])
    pt=target.reshape(2,2,2,2).transpose(0,3,2,1).reshape(4,4)
    two["partial_transpose_eigenvalues_binary64"]=np.linalg.eigvalsh(pt).tolist()
    two["negativity_binary64"]=float(-min(np.linalg.eigvalsh(pt)))
    two["unitarity_residual_binary64"]=float(np.linalg.norm(U.conj().T@U-np.eye(4)))
    rational={"grid_state_identities":count,"all_grid_checks_passed":True,
              "minimum_palette_probability":"1/24",
              "exact_expected_source_upper_bound":str(source_mean_bound(F(1,4))),
              "two_qubit":two}
    (ROOT/"EXACT_AUDIT.json").write_text(json.dumps(rational,indent=2))

    profiles=[("maximally_mixed",(0,0,0)),("x_edge",(F(1,4),0,0)),
              ("y_edge",(0,F(1,4),0)),("three_axis_corner",(F(1,4),)*3),
              ("asymmetric",(-F(1,4),F(1,8),-F(1,8)))]
    records=[]
    samples=2400
    for k,(name,r) in enumerate(profiles):
        sources=[rational_fixture_source((1+F(x))/2,401+k*13+j) for j,x in enumerate(r)]
        fair=random.Random(90210+31*k)
        labels={(j,s):0 for j in range(3) for s in (-1,1)}
        total_queries=0; max_queries=0;total_bits=0;max_stage=0;max_integer_bits=0;fail=0
        first_tape=None
        for t in range(samples):
            runtime=Runtime(lambda:fair.getrandbits(1),Limits(100000,128,128))
            result=factory_labels([sources],F(1,4),runtime)
            c=result["counts"]
            total_queries+=c["source_queries"]
            total_bits+=c["fair_bits"]
            max_queries=max(max_queries,c["source_queries"])
            max_stage=max(max_stage,c["maximum_stage"])
            max_integer_bits=max(max_integer_bits,c["maximum_integer_bits"])
            if result["fallback"]:
                fail+=1
            else:
                labels[tuple(result["labels"][0])]+=1
                if first_tape is None:first_tape=gate_tape(result)
        completed=samples-fail
        empirical=[(labels[(j,1)]-labels[(j,-1)])/samples for j in range(3)]
        expected=[float(F(x)*s) for x,s in zip(r,(1,-1,1))]
        # Reporting bound only; source is pseudorandom and no experimental inference is asserted.
        hoeffding=math.sqrt(2*math.log(6/0.001)/samples)
        record={"profile":name,"input_bloch":[str(F(x)) for x in r],
                "target_bloch":expected,"runs":samples,"fallbacks":fail,
                "palette_counts":{f"{j}:{s}":v for (j,s),v in labels.items()},
                "empirical_bloch":empirical,
                "max_coordinate_deviation":max(abs(x-y) for x,y in zip(empirical,expected)),
                "iid_99_9_percent_coordinate_band_reference":hoeffding,
                "mean_raw_source_queries":total_queries/samples,
                "maximum_raw_source_queries":max_queries,
                "mean_auxiliary_fair_bits":total_bits/samples,
                "maximum_stage":max_stage,"maximum_rational_integer_bits":max_integer_bits,
                "first_logical_preparation_tape":first_tape,
                "status":"seeded synthetic capped diagnostic; not a proof or physical observation"}
        records.append(record)
        print(json.dumps({key:record[key] for key in
              ["profile","runs","fallbacks","mean_raw_source_queries",
               "maximum_raw_source_queries","max_coordinate_deviation"]}),flush=True)
    (ROOT/"SYNTHETIC_RECORD.json").write_text(json.dumps(records,indent=2))

    plans=[]
    for n in (1,2,1000,1000000):
        plan=deadline_parameters(n,F(1,4),F(1,100))
        plan.pop("limits")
        assert F(plan["tail_bound"])<=F(1,100)
        plans.append(plan)
    (ROOT/"DEADLINE_CERTIFICATES.json").write_text(json.dumps(plans,indent=2))

    # Information bound for exact spectral cooling at the maximally mixed qubit.
    data=[]
    for power in (2,4,8):
        for h in (0.1,0.03,0.01,0.003,0.001):
            inp=-.5*math.log1p(-h*h)  # input Bloch r=h
            out_r=math.tanh(power*math.atanh(h))
            out=-.5*math.log1p(-out_r*out_r)
            data.append({"power":power,"input_bloch":h,
                         "relative_entropy_ratio":out/inp,
                         "limiting_copy_lower_bound":power**2})
    (ROOT/"INFORMATION_BOUND_DIAGNOSTICS.json").write_text(json.dumps(data,indent=2))
    summary={"exact_state_identities":count,"exact_entangled_two_qubit_identity":True,
             "exact_negative_partial_transpose_determinant":True,
             "synthetic_runs":samples*len(profiles),
             "synthetic_fallbacks":sum(r["fallbacks"] for r in records),
             "deadline_certificates":len(plans),
             "elapsed_seconds":time.time()-started}
    (ROOT/"AUDIT_SUMMARY.json").write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary),flush=True)
if __name__=="__main__":
    run()
