"""Exact source-to-state factory; new implementation for the present return.

Published scalar primitive: Huber, arXiv:1308.1562v2, Algorithm 1.
No unknown probability is read by the factory. A source is a callable returning
independent physical measurement bits. The included rational source is a
SEEDED SYNTHETIC fixture, not physical data or a physical RNG.

Exactness: ideal source + fair bits + rational integer arithmetic, no cutoff.
Bounded mode: unconditional fallback; its error is bounded in the report.
"""
from fractions import Fraction as F
from dataclasses import dataclass, asdict
import math
import random

class Timeout(Exception):
    pass

@dataclass
class Counters:
    source_queries: int = 0
    auxiliary_coins: int = 0
    fair_bits: int = 0
    linear_iterations: int = 0
    geometric_draws: int = 0
    stage_coins: int = 0
    maximum_stage: int = 0
    maximum_integer_bits: int = 0

@dataclass
class Limits:
    source_queries: int | None = None
    geometric_length: int | None = None
    bits_per_coin: int | None = None

class Runtime:
    def __init__(self, fair_bit, limits=None):
        self.fair_bit = fair_bit
        self.limits = limits or Limits()
        self.counts = Counters()

    def bernoulli(self, probability):
        """Exact rational Bernoulli using a growing dyadic interval for U."""
        probability = F(probability)
        if not 0 <= probability <= 1:
            raise ValueError("Known rational probability outside [0,1]")
        self.counts.auxiliary_coins += 1
        a,b = probability.numerator,probability.denominator
        self.counts.maximum_integer_bits = max(
            self.counts.maximum_integer_bits,a.bit_length(),b.bit_length())
        if a == 0:
            return 0
        if a == b:
            return 1
        prefix,den = 0,1
        j = 0
        while True:
            if self.limits.bits_per_coin is not None and j >= self.limits.bits_per_coin:
                raise Timeout("fair-bit cutoff")
            bit = self.fair_bit()
            if bit not in (0,1):
                raise ValueError("fair source must return one bit")
            prefix = 2*prefix+bit
            den *= 2
            j += 1
            self.counts.fair_bits += 1
            # U lies in [prefix/den,(prefix+1)/den).
            if (prefix+1)*b <= a*den:
                return 1
            if prefix*b >= a*den:
                return 0

    def query(self, source):
        if (self.limits.source_queries is not None
                and self.counts.source_queries >= self.limits.source_queries):
            raise Timeout("source-query cutoff")
        self.counts.source_queries += 1
        bit = source()
        if bit not in (0,1):
            raise ValueError("source must return one bit")
        return bit

    def geometric(self,q):
        self.counts.geometric_draws += 1
        g = 1
        while True:
            if self.bernoulli(q):
                return g
            if self.limits.geometric_length is not None and g >= self.limits.geometric_length:
                raise Timeout("geometric cutoff")
            g += 1

    def linear(self,C,eps,coin):
        """Huber's Cp factory. Promise: C>1, 0<eps<=.644, Cp<=1-eps."""
        C,eps = F(C),F(eps)
        if C <= 1 or not 0 < eps <= F(161,250):
            raise ValueError("Unsupported scalar-primitive parameters")
        k = F(23,5)/eps  # 2.3/(gamma*eps), gamma=1/2.
        i,stage = 1,0
        while True:
            while True:
                B = coin()
                self.counts.linear_iterations += 1
                i -= 1
                if not B:
                    i += self.geometric((C-1)/C)
                if i == 0 or i >= k:
                    break
            if i == 0:
                return 1
            self.counts.stage_coins += 1
            factor = 1+eps/2
            R = self.bernoulli((1/factor)**i)
            if R == 0:
                return 0
            C *= factor
            eps /= 2
            k *= 2
            stage += 1
            self.counts.maximum_stage=max(self.counts.maximum_stage,stage)

def exact_centered_triple(source, radius, runtime):
    """From p=(1+r)/2, |r|<=radius<1/3, produce (1+3r)/2."""
    radius=F(radius)
    if not 0 <= radius < F(1,3):
        raise ValueError("radius must lie in [0,1/3)")
    slack = 1-3*radius
    eps_inner,eps_outer = slack/4,slack/2

    def inner_complement():
        def one_minus_p():
            return 1-runtime.query(source)
        return 1-runtime.linear(F(3,2),eps_inner,one_minus_p)

    return runtime.linear(F(2),eps_outer,inner_complement)

def one_label(sources,radius,runtime,signs=(1,-1,1)):
    """One of six Pauli eigenstates. sources[j] measures +Pauli_j on a fresh copy."""
    if runtime.bernoulli(F(1,3)):
        axis=0
    elif runtime.bernoulli(F(1,2)):
        axis=1
    else:
        axis=2
    # T in the declared computational frame is diag(1,-1,1) on Bloch vectors.
    original=sources[axis]
    signed=original if signs[axis] == 1 else lambda: 1-original()
    bit=exact_centered_triple(signed,radius,runtime)
    return (axis,1 if bit else -1)

def factory_labels(source_families,radius,runtime,signs=(1,-1,1)):
    """All classical sampling precedes quantum synthesis.

    Returns labels for the complete output or an unconditional maximally-mixed
    fallback request. A success flag is internal; no exact conditional-output
    claim is made after a cutoff.
    """
    labels=[]
    try:
        for source in source_families:
            labels.append(one_label(source,radius,runtime,signs))
        return {"fallback":False,"labels":labels,"counts":asdict(runtime.counts)}
    except Timeout as exc:
        return {"fallback":True,"labels":None,"reason":str(exc),
                "counts":asdict(runtime.counts)}

def ceil_fraction(x):
    x=F(x)
    return -(-x.numerator//x.denominator)

def source_mean_bound(radius):
    radius=F(radius)
    if not 0 <= radius < F(1,3):
        raise ValueError("radius outside promise")
    return F(2166)/(1-3*radius)**2

def deadline_parameters(number_outputs,radius,error):
    """All arithmetic and returned tail bounds are exact rational."""
    error=F(error)
    if number_outputs < 1 or not 0 < error < 1:
        raise ValueError("positive output count and error in (0,1) required")
    H=number_outputs*source_mean_bound(radius)
    Q=ceil_fraction(3*H/error)
    g=0
    tail_geo=F(1)
    while 2*Q*tail_geo > error/3:
        g+=1
        tail_geo*=F(2,3)
    K=2*number_outputs+2*Q*(g+1)
    b=0
    tail_bits=F(1)
    while K*tail_bits > error/3:
        b+=1
        tail_bits/=2
    total=H/Q+2*Q*tail_geo+K*tail_bits
    return {"number_outputs":number_outputs,"radius":str(F(radius)),
            "requested_error":str(error),"mean_source_bound":str(H),
            "Q":Q,"g":g,"K":K,"b":b,"tail_bound":str(total),
            "tail_bound_float":float(total),
            "limits":Limits(Q,g,b)}

def gate_tape(result):
    """Known logical H,S,X preparations. Hardware and noise remain separate."""
    if result["fallback"]:
        return {"interface":"reset/fresh fair bits/conditional X",
                "operation":"prepare the maximally mixed whole output",
                "classical_record":"internal timeout flag; discard before delivery"}
    tape=[]
    for wire,(axis,sign) in enumerate(result["labels"]):
        tape.append(("RESET0",wire))
        if sign == -1:
            tape.append(("X",wire))
        if axis in (0,1):
            tape.append(("H",wire))
        if axis == 1:
            tape.append(("S",wire))
    return {"interface":"labelled ideal logical gates",
            "operations":tape,
            "classical_record":"labels are internal; erase/reset at paid cost"}

def rational_fixture_source(p,seed):
    """Synthetic iid model with hidden p; no parameter is supplied to the factory."""
    p=F(p); rng=random.Random(seed)
    def source():
        return int(rng.randrange(p.denominator)<p.numerator)
    return source
