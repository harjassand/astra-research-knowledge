"""Exact Q(sqrt(2),i) audit of finite-alphabet two-qubit target construction."""
from fractions import Fraction as F
from itertools import permutations

class Q:
    # a+b*sqrt(2)+i*(c+d*sqrt(2))
    def __init__(self,a=0,b=0,c=0,d=0):
        self.v=tuple(F(x) for x in (a,b,c,d))
    @staticmethod
    def co(x):
        return x if isinstance(x,Q) else Q(x)
    def __add__(self,x):
        x=Q.co(x);return Q(*(a+b for a,b in zip(self.v,x.v)))
    __radd__=__add__
    def __neg__(self):return Q(*(-x for x in self.v))
    def __sub__(self,x):return self+-Q.co(x)
    def __rsub__(self,x):return Q.co(x)+-self
    def __mul__(self,x):
        x=Q.co(x)
        a,b,c,d=self.v; e,f,g,h=x.v
        return Q(a*e+2*b*f-c*g-2*d*h,
                 a*f+b*e-c*h-d*g,
                 a*g+2*b*h+c*e+2*d*f,
                 a*h+b*g+c*f+d*e)
    __rmul__=__mul__
    def conj(self):a,b,c,d=self.v;return Q(a,b,-c,-d)
    def __eq__(self,x):return self.v == Q.co(x).v
    def complex(self):
        a,b,c,d=map(float,self.v)
        return complex(a+b*2**.5,c+d*2**.5)
    def serial(self):return [str(x) for x in self.v]
    def real_interval(self):
        a,b,c,d=self.v
        assert c==d==0
        lo,hi=F(14142135623730950488,10**19),F(14142135623730950489,10**19)
        assert lo*lo<2<hi*hi
        return (a+b*lo,a+b*hi) if b>=0 else (a+b*hi,a+b*lo)

def mat(rows):return [[Q.co(x) for x in row] for row in rows]
def add(A,B):return [[x+y for x,y in zip(a,b)] for a,b in zip(A,B)]
def scale(A,c):return [[c*x for x in row] for row in A]
def mm(A,B):return [[sum((A[i][k]*B[k][j] for k in range(len(B))),Q())
                     for j in range(len(B[0]))] for i in range(len(A))]
def adj(A):return [[A[j][i].conj() for j in range(len(A))] for i in range(len(A[0]))]
def transpose(A):return [list(row) for row in zip(*A)]
def kron(A,B):return [[A[i][j]*B[k][l] for j in range(len(A[0]))
                      for l in range(len(B[0]))] for i in range(len(A)) for k in range(len(B))]
def identity(n):return mat([[int(i==j) for j in range(n)] for i in range(n)])
def equal(A,B):return all(x==y for a,b in zip(A,B) for x,y in zip(a,b))
def trace(A):return sum((A[i][i] for i in range(len(A))),Q())
def det(A):
    ans=Q()
    for p in permutations(range(len(A))):
        inv=sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))
        t=Q((-1)**inv)
        for i,j in enumerate(p):t=t*A[i][j]
        ans=ans+t
    return ans
def partial_transpose_2(A):
    return [[A[2*(i//2)+(j%2)][2*(j//2)+(i%2)] for j in range(4)] for i in range(4)]

I=identity(2)
X=mat([[0,1],[1,0]])
Y=mat([[0,Q(c=-1)],[Q(c=1),0]])
Z=mat([[1,0],[0,-1]])
PAULIS=[X,Y,Z]
H=scale(add(X,Z),Q(b=F(1,2)))
S=mat([[1,0],[0,Q(c=1)]])
T=mat([[1,0],[0,Q(b=F(1,2),d=F(1,2))]])
CNOT=mat([[1,0,0,0],[0,1,0,0],[0,0,0,1],[0,0,1,0]])

def state(bloch):
    A=I
    for r,P in zip(bloch,PAULIS):A=add(A,scale(P,r))
    return scale(A,F(1,2))
def palette(axis,sign):return scale(add(I,scale(PAULIS[axis],sign)),F(1,2))
def weights(r):
    return {(j,s):F(1,6)+F(s*((1,-1,1)[j]),2)*r[j] for j in range(3) for s in (-1,1)}

def target_fixture():
    # Vdag = S H Tdag H Sdag T, six exactly specified alphabet gates.
    Vdag=mm(mm(mm(mm(mm(S,H),adj(T)),H),adj(S)),T)
    U=mm(mm(CNOT,kron(H,I)),kron(Vdag,Vdag))
    assert equal(mm(adj(U),U),identity(4))
    r=(F(1,4),)*3
    source=state(r)
    target=mm(mm(U,kron(transpose(source),transpose(source))),adj(U))
    mixture=mat([[0]*4 for _ in range(4)])
    ws=weights(r)
    for (a,s),wa in ws.items():
        for (b,t),wb in ws.items():
            component=mm(mm(U,kron(palette(a,s),palette(b,t))),adj(U))
            mixture=add(mixture,scale(component,wa*wb))
    assert equal(mixture,target)
    assert trace(target)==1
    determinant=det(partial_transpose_2(target))
    lo,hi=determinant.real_interval()
    assert hi<0
    return {"exact_unitarity":True,"exact_36_term_state_identity":True,
            "partial_transpose_determinant_Q_sqrt2_i":determinant.serial(),
            "determinant_interval":[str(lo),str(hi)],
            "determinant_negative":True,
            "gate_count_U":14,
            "U":U,"target":target}
