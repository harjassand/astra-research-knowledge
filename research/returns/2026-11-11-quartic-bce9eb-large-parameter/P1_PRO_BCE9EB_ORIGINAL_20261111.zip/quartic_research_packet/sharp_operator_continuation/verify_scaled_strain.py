"""Fixed exact identities for the k -> infinity normalized family.

No search or optimizer.  Seven rational-polynomial identities are checked.
External execution is capped at 30 seconds.
"""
import json
import time
from pathlib import Path

import sympy as sp

started = time.perf_counter()
ep, s, h, u, v, p, q = sp.symbols("ep s h u v p q", real=True)
a, b, c, d = sp.symbols("a b c d", real=True)
m0 = 3 + ep**2
a0 = 3 - ep**2
rho = h - ep
DD = -rho * u + s * v
EE = s * u + rho * v
TT = m0 * p * u + 2 * ep * q * v
VV = (1 + ep**2) * p * v
al = 2 * ep / m0
be = 1 + 6 / m0
Ct = q * EE + al * p * DD
Tt = TT - be * ep * p * DD
Vt = VV + ep * p * EE

L1 = -3 * (p*u + q*(s*u+h*v)) + ep*(q*v+p*(s*v-h*u))
L2 = a0*(p*u-q*(s*u+h*v)) + ep*(5+ep**2)*(q*v-p*(s*v-h*u))
L3 = p*v+q*(s*v-h*u)+ep*(q*u+p*(s*u+h*v))
L4 = -p*v+q*(s*v-h*u)+ep*(q*u-p*(s*u+h*v))
w1 = a0/(4*m0)
w2 = 3/(4*(1+ep**2)*m0)
w3 = 3*a0/(4*m0)
w4 = a0**2/(4*(1+ep**2)*m0)
gamma = a0/(2*(1+ep**2))
delta = 2*ep**2/m0
Ssq = w1*L1**2+w2*L2**2+w3*L3**2+w4*L4**2
normal = Tt**2/2+3*gamma*Ct**2+gamma*((q*DD)**2+Vt**2+2*delta*q*DD*Vt)

checks = {}
def check(name, expr):
    numerator = sp.cancel(expr).as_numer_denom()[0]
    poly = sp.Poly(numerator, ep,s,h,u,v,p,q,a,b,c,d)
    checks[name] = {"zero": bool(poly.is_zero), "terms": len(poly.terms())}
    if not poly.is_zero:
        raise AssertionError((name, poly.as_expr()))

check("L1_reconstruction", L1+Tt+3*Ct)
check("L2_reconstruction", L2-(1+ep**2)*Tt+a0*Ct)
check("L3_reconstruction", L3-q*DD-Vt)
check("L4_reconstruction", L4-q*DD+Vt)
check("four_square_normal_form", Ssq-normal)

# Independent direct Hessian contraction of the normalized original density.
x1,x2,y1,y2,z = sp.symbols("x1 x2 y1 y2 z", real=True)
uv = x1*x1+x2*x2
vv = y1*y1+y2*y2
jj = x1*y2-x2*y1
alpha = a0/(8*(1+ep**2))
f = alpha*(uv-vv+2*ep*jj)**2+a0*uv*vv/4+ep**2*jj**2
fz = f.subs({x1:1+z*u*p,x2:z*v*p,y1:s+z*u*q,y2:h+z*v*q})
check("original_acoustic_hessian", sp.diff(fz,z,2).subs(z,0)-normal)

lam = 3*a0*ep*(a*a+c*c-b*b-d*d)/(2*m0)+12*ep**2*(a*d-b*c)/m0
lam_critical = sp.diff(lam,a)+ep*sp.diff(lam,d)
ss = m0*a/2+ep*d
C1 = 3*(1+ep**2)/m0
C2 = 3*(1+ep**2)*a0/(2*m0)
check("lambda_critical_pairing", lam_critical-ep*(C1*ss+C2*a))

receipt = {
    "operation":"seven fixed exact rational-polynomial identities; no optimizer/search",
    "checks":checks,
    "elapsed_seconds":time.perf_counter()-started,
    "external_cap_seconds":30,
    "sympy_version":sp.__version__,
}
Path(__file__).with_name("scaled_strain_verification_receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt,indent=2))
