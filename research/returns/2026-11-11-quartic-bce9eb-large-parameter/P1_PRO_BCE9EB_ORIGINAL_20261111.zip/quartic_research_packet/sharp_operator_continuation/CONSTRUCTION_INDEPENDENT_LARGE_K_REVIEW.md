# Independent construction-role review of the large-k theorem

Reviewed: `LARGE_K_GLOBAL_QUASICONVEXITY.md`, including the exact normal form, uniform acoustic estimate, mixed-minor argument, reserve allocation, and transfer to the original density. The existing seven-identity verifier and its receipt were read. No search, external source retrieval, additional numerical experiment, or rerun of that verifier was used for this review.

## Conclusion and verified scope

No mathematical error was found. Subject to the explicitly accepted scalar interpolation inequality with finite constant C0 and the accepted strain/lifting identities, the argument proves

\[
\int_{T^2}J_k(A+D\phi)-J_k(A)
\ge\frac19\int_{T^2}J_k(D\phi)
\]

for every real `k>=780(41+12C0)^2`, every real affine mean A, and every periodic vector potential in W^(1,4). There is no restriction on amplitude, frequency, orientation, or determinant fluctuations. The result leaves `1/3<k<780(41+12C0)^2` unresolved.

## 1. Exact factorization (8)

I independently expanded the four linear strain reconstructions. Writing rho=h-epsilon, the first two unweighted forms reduce to

\[
L_1=-T-3qE_0+\varepsilon pD,
\]
\[
L_2=(1+\varepsilon^2)T-(3-\varepsilon^2)qE_0
       -\varepsilon(5+\varepsilon^2)pD.
\]

The identities

\[
\beta\varepsilon-3\alpha=\varepsilon,
\qquad
(1+\varepsilon^2)\beta\varepsilon
 +(3-\varepsilon^2)\alpha=\varepsilon(5+\varepsilon^2)
\]

give the stated representations by T-tilde and C. The remaining forms are exactly `qD+V-tilde` and `qD-V-tilde`.

With the displayed weights, the first pair has T-tilde squared coefficient 1/2, C squared coefficient 3 gamma, and zero mixed coefficient. For the second pair, the sum of weights is gamma and their difference is gamma delta. This gives precisely

\[
\tfrac12\widetilde T^2+3\gamma C^2
 +\gamma[(qD)^2+\widetilde V^2+2\delta(qD)\widetilde V].
\]

The existing verifier also compares this expression with a directly differentiated Hessian of (4), rather than checking only the strain reconstructions. Its original-density substitution and variable ordering are consistent.

## 2. Uniform estimate (11)

The perturbation of the four-vector has squared norm

\[
(\beta^2\varepsilon^2+\alpha^2)p^2D^2
 +\varepsilon^2p^2E_0^2.
\]

Because beta<=3 and alpha<=2 epsilon/3, its D coefficient is at most `(85/9)epsilon^2<10epsilon^2`; `D^2+E0^2=d_F^2|e|^2`. This proves (9).

From `pu=(T-2epsilon qv)/(3+epsilon^2)` and `pv=V0/(1+epsilon^2)`,

\[
d_F^2p^2|e|^2
\le d_F^2(2T^2/9+V_0^2)
 +(8/9)\varepsilon^2d_F^2q^2v^2
\le4|N|^2.
\]

Here d_F<=2 is valid for every normalized triangular background, including negative h; closeness to the critical orbit is not assumed. Thus the perturbation norm is at most `sqrt(40)epsilon |N|`. For epsilon<=1/16 it is less than |N|/2, yielding the lower bound |N|^2/16 for the acoustic form.

The critical acoustic form is at most `(3/2)|N|^2`, and the full transverse expression is at most `5|N|^2`. Their sum is at most `(13/2)|N|^2`. Therefore the stated constant is exactly `1/[16(13/2)]=1/104`.

The passage to (12) is valid by quartic polarization and Parseval on the actual torus frequencies. Complex Fourier amplitudes can be separated into their real and imaginary rank-one parts. No bound on the least nonzero Fourier angle or on a second moment enters.

## 3. Normalization and symmetry covariance

Choosing the longer column, applying a constant left SO(2) rotation, and dividing the background by that column length covers every nonzero F. The second triangular entry h may have either sign. The inequality being proved is homogeneous of degree one in the background on both sides, so the normalization is harmless. F=0 is immediate.

There is one covariance detail worth making explicit. For the column-swap permutation P,

\[
f_\varepsilon(FP)=f_\varepsilon(F),\qquad
\lambda_\varepsilon(FP)=-\lambda_\varepsilon(F).
\]

For the compatible transformed field `G'(y)=G(Py)P`,

\[
D\lambda_\varepsilon(GP)=-D\lambda_\varepsilon(G)P,
\qquad \det(GP)=-\det G.
\]

The two signs cancel in the cubic moment, giving `r_(G')=r_G P`. The Hessian moment transforms covariantly as well. Source permutation is an integer, measure-preserving permutation of the original torus, so compatibility and all required norms are retained. Thus the use of the swap in the proof is correct even though lambda itself is odd under the swap.

For the right scaling D=diag(epsilon,1), the strain identities transform by

\[
S_\varepsilon(F,G)=S(FD,GD),\qquad
\lambda_\varepsilon(F)=\det(D)\lambda(FD).
\]

The quartic identity for g, the mixed identity `3b=K* g+r`, and the quadratic identity for H then follow by the ordinary chain rule and `det(GD)=det(D)detG`. One does not need to claim that GD is itself a compatible field on the original torus. The integrated quadratic identity only uses the determinant null-Lagrangian identity for the original compatible G.

## 4. Remaining estimates and the one reserve

Scalar minimization in j gives the displayed coercivity bound (6), with coefficient at least 1/12 for epsilon<=1. The lambda and Dlambda bounds follow from `|u-v|<=|F|^2`, `|j|<=|F|^2/2`, and `|cof F|=|F|`.

The anisotropic interpolation step retains exactly C0: for rational epsilon=P/Q, applying the isotropic inequality to f(Qx,Py) gives two factors of Q on each side, while the integer covering preserves normalized torus norms. Finite Fourier continuity and strong approximation justify the irrational case. The low/high multiplier identity and all Holder exponents in the critical mixed estimate are consistent. In particular the epsilon from the low piece cancels the apparent 1/epsilon in the determinant decomposition, leaving the final mixed constant proportional to epsilon.

The all-background bound follows from the critical bound and (12), with the stated D0. It yields the range condition before any pseudoinverse is used. The Fejer limit is taken in the dual inequality for each fixed background, so no unsupported continuity of a pseudoinverse is required.

In (22), the sole strain reserve is allocated by `||g+w||^2<=(5/4)||g||^2+5||w||^2`. Using `M^2 d_J<=6c` gives exactly `15+(105/2)epsilon+30D0^2 epsilon^2`. The proposed K* equals 60 D0^2. Since C0>=1, it also implies epsilon<=1/105 and epsilon<=1/16. Therefore the final bound 16c, and hence the c/9 reserve, follow with no duplicate use of the convex resource.

## 5. Return to the ORIGINAL density

The direction of the source transformation is correct. If `psi(y)=phi(D^(-1)y)` and `B=A D^(-1)`, then

\[
(B+D_y\psi(y))D=A+D_x\phi(D^{-1}y).
\]

Both the energy gap and the reserve acquire the same positive Jacobian factor det D. The normalized torus theorem first gives a compact-support theorem by zero extension and cube rescaling; the source map is applied there. The final fixed-width cutoff of a smooth periodic test has only O(N) boundary cost on a cube of area N^2. Strong W^(1,4) approximation and quartic growth complete the original unit-torus statement. No irrational lattice substitution is present.

This review used only the specified local proof, existing accepted mathematical capital, and direct algebraic reasoning. It made no new source-access attempt or additional search.
