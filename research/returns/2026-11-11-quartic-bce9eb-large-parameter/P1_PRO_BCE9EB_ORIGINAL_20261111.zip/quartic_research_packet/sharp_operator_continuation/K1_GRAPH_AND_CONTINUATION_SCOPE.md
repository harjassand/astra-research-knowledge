# Exact k=1 graph and the remaining continuation problem

## 1. The shifted-Beurling form

Start from the supplied diagonalized graph

\[
P(U,V)=\lambda_+(|U|^2-|V|^2)^2
+4\lambda_-\operatorname{Re}(U\overline V)^2
+\operatorname{Im}(U\overline V)^2,
\qquad \lambda_\pm=\frac{5\pm\sqrt{13}}8,
\]

\[
U=U_0+S_tv,\qquad V=V_0+v,
\quad S_t=(B+tI)(I-tB)^{-1},
\quad t=\tan\theta,\quad\tan4\theta=\frac23.
\]

Set

\[
\chi=\frac{2t}{1-t^2}=\frac{\sqrt{13}-3}{2},\qquad
R=\frac{1+t^2}{1-t^2}=\sqrt{1+\chi^2}.
\]

Then \(\chi^2+3\chi=1\), \(R^2=2-3\chi\), and

\[
S_t=\chi I+R B_\kappa,\qquad
B_\kappa=(B-tI)(I-tB)^{-1},\qquad
\kappa=\frac{1+t}{1-t}.
\tag{1}
\]

For the convention \(B(p,q)=(p-iq)/(p+iq)\),

\[
B_\kappa(p,q)=
\frac{(1-t)p-i(1+t)q}{(1-t)p+i(1+t)q}.
\]

This is an anisotropic Beurling multiplier, with modulus one in L2. Consequently, for the mean-zero fluctuations \(u=S_t v\),

\[
\int\bigl(|u|^2-|v|^2-2\chi\operatorname{Re}(u\overline v)\bigr)=0.
\tag{2}
\]

The supplied Beurling estimate, with the paid anisotropic transfer, gives
\(\|S_t\|_{4\to4}\le\chi+3R\). This estimate is not the desired quasiconvexity inequality.

The polynomial simplifies to

\[
P(U,V)=\left(1+\frac\chi4\right)(|U|^4+|V|^4)
-(1+\chi)|U|^2|V|^2
-\frac\chi2\operatorname{Re}(U^2\overline V^{\,2}).
\tag{3}
\]

For completeness, straightening \(U=\chi V+R A\) gives

\[
\begin{aligned}
\frac{P(\chi V+RA,V)}{R^2}
={}&\frac{5-\chi}{4}|A|^4
+\frac{5(1-\chi)}4|V|^4
-\frac{1+3\chi}{2}|A|^2|V|^2\\
&+\chi^2[\operatorname{Re}(A\overline V)]^2\\
&+R[(1+\chi)|A|^2-(1-\chi)|V|^2]
\operatorname{Re}(A\overline V).
\end{aligned}
\tag{4}
\]

The term with coefficient \(\chi^2\) is essential. An earlier informal message omitted it; the displayed formula is the corrected identity. A direct derivation sets \(X=|U|^2-|V|^2\), \(Y=2\operatorname{Re}(U\overline V)\), \(Z=2\operatorname{Im}(U\overline V)\), and \(d=X-\chi Y=R^2(|A|^2-|V|^2)\). Then

\[
P=\left(1+\frac\chi4\right)d^2
+\frac{1+\chi}{2}dY+\frac{R^2}{4}Y^2+\frac14Z^2.
\]

The two final coefficients differ. Expanding this expression yields (4).

For fluctuations \(A=B_\kappa v\). Arbitrary affine means remain arbitrary after this invertible change of the two complex variables. Equations (2)-(4) leave a phase-sensitive mixed fourth moment, and the all-mean cubic bound remains unpaid.

Specifically, write the exact polarized gap as
\(C+L(a,b)+Q(a,b)\), where \(C=\int P(u,v)\), L is the cubic term linear in the complex mean \((a,b)\), and Q is the quadratic mean contribution. The accepted local theorem supplies \(Q\ge0\) and the kernel range condition. The remaining sharp assertion is

\[
|L(a,b)|^2\le4C\,Q(a,b)
\quad\text{for every compatible }(u,v)\text{ and every mean }(a,b).
\tag{5}
\]

The graph rewrite has not proved (5), and no compatible negative witness was obtained here. No part of the separate large-k theorem uses the optional k=1 straightening formula (4).

## 2. Parameter continuity does not propagate the affirmative interval

Define the original family's normalized optimized reserve by

\[
\mathcal R(k)=\inf_{G=D\phi\ne0,\,A}
\frac{\int J_k(A+G)-J_k(A)}{\int J_k(G)}.
\]

For each fixed admissible test \((A,G)\), this quotient is continuous in \(k>1/3\) and its denominator is positive. Therefore \(\mathcal R\) is upper semicontinuous as an infimum of continuous functions. Also, the set of quasiconvex parameters is relatively closed: it is the intersection of the closed nonnegative-inequality sets for all tests. Equivalently, any strict negative witness persists on an open parameter interval.

These facts do not propagate a positive reserve from the large-k interval. Upper semicontinuity does not assert openness of \(\{\mathcal R>0\}\). The mean Hessian can degenerate, and gradients can concentrate. The range condition and a uniform nonsharp cubic estimate do not alone make the pseudoinverse functional continuous: the abstract example

\[
H_\delta=\operatorname{diag}(\delta^2,1),\qquad b_\delta=(\delta,0)
\]

has the range property and
\(|b_\delta:F|\le\sqrt{F:H_\delta F}\), but
\(b_\delta^T H_\delta^\dagger b_\delta=1\) for \(\delta>0\), whereas its value at the limit is zero. This only illustrates a missing finite-dimensional inference; it is not an asserted compatible-gradient example.

Even a proved continuity of \(\mathcal R\) would still permit it to reach zero at an intermediate parameter. A valid continuation theorem would need an additional result, such as a paid compactness/equality classification yielding a positive uniform reserve whenever quasiconvexity holds. No such theorem was established here.

The exact transformed-parameter rigidity already recorded in quartic_research_packet/family_geometry.txt also prevents ordinary finite positive transformed-family propagation. It was not used as a substitute for the missing nonlinear bridge.

The separate LARGE_K_GLOBAL_QUASICONVEXITY.md establishes a genuine affirmative interval and the uniform asymptotic limit \(\mathcal R(k)\to1/3\). It does not settle the remaining range \(1/3<k<K_*\).
