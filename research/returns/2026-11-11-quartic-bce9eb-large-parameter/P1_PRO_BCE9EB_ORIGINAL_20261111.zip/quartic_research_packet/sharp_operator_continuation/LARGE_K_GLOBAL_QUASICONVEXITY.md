# A full large-parameter interval for the original quartic

## Statement and scope

For definiteness, let C0 be the maximum of 1 and the supremum of

\[
\frac{\|\partial_1 f\|_{8/3}^{2}}
{\|\nabla f\|_4\|R_1\partial_1 f\|_2}
\]

over smooth real periodic scalar potentials with nonzero denominator. The already established scalar interpolation theorem proves that this precisely defined universal constant is finite. Thus

\[
\|\partial_1 f\|_{8/3}^{2}
\le C_0\|\nabla f\|_4\|R_1\partial_1 f\|_2
\tag{1}
\]

for real periodic scalar potentials. Define the finite constants

\[
D_0=\sqrt{13}(41+12C_0),\qquad
K_*=780(41+12C_0)^2.
\tag{2}
\]

Then, for **every real `k >= K_*`**, every real constant matrix A, and every real periodic vector potential in `W^(1,4)(T²)`, the ORIGINAL density satisfies the stronger inequality

\[
\boxed{\int_{\mathbb T^2}J_k(A+D\phi)-J_k(A)
\ge\frac19\int_{\mathbb T^2}J_k(D\phi).}
\tag{3}
\]

The dependence of the endpoint on the accepted interpolation constant is explicit. No numerical value of C0 is assumed or computed here, and defining this constant does not invoke an optimization oracle: only its already proved finiteness is used. This is an analytic existence of a finite large-k interval, not a resolution of the full range `k>1/3`.

The proof uses the accepted exact strain identity and the same feasible-lift reserve used in the small-Jacobian theorem, once. It establishes a new uniform estimate at the parameter endpoint k=infinity. It does not infer uniformity from coefficient convergence alone.

## 1. Normalize the large-parameter endpoint

Put

\[
\varepsilon=k^{-1/2},\qquad
f_\varepsilon(F)=J_k(F\operatorname{diag}(\varepsilon,1)),
\qquad 0<\varepsilon\le1.
\]

For `u=|F_col1|²`, `v=|F_col2|²`, and `j=det F`, direct substitution gives

\[
f_\varepsilon(F)=
\frac{3-\varepsilon^2}{8(1+\varepsilon^2)}
(u-v+2\varepsilon j)^2
+\frac{3-\varepsilon^2}{4}uv+\varepsilon^2j^2.
\tag{4}
\]

Its corresponding multiplier is

\[
\lambda_\varepsilon(F)=
\frac{3(3-\varepsilon^2)\varepsilon}{2(3+\varepsilon^2)}(u-v)
+\frac{12\varepsilon^2}{3+\varepsilon^2}j.
\tag{5}
\]

The exact lower bound from scalar minimization in j, before the coarse Euclidean simplification, transforms into

\[
f_\varepsilon(F)\ge
\frac{3-\varepsilon^2}{4(5+\varepsilon^2)}
[u^2+v^2+(3+\varepsilon^2)uv]
\ge\frac1{12}|F|^4.
\tag{6}
\]

The elementary coefficient bounds needed below are

\[
|\lambda_\varepsilon(F)|\le\frac72\varepsilon|F|^2,
\qquad
|D\lambda_\varepsilon(G):E|\le7\varepsilon|G||E|.
\tag{7}
\]

All these bounds hold for `0<epsilon<=1`. The normalized density is left-SO(2) invariant and invariant under swapping its two columns: the swap reverses both j and u-v. The multiplier lambda_epsilon changes sign under that swap. Consequently its pairing with det F is invariant, as is the integrated pairing `r_G:F` under the simultaneous transformation `F -> FP`, `G(x) -> G(Px)P`, where P swaps the source coordinates. Differentiating `lambda_epsilon(XP)=-lambda_epsilon(X)` gives this covariance exactly; the two sign changes cancel.

For a compatible mean-zero G define

\[
c=\int f_\varepsilon(G),\quad
b=\int Df_\varepsilon(G),\quad
H=\int D^2f_\varepsilon(G),\quad
r=\int D\lambda_\varepsilon(G)\det G.
\]

Also set `M=||G||4`, `d_J=||det G||2`. In particular `d_J<=M²/2` and `c>=M⁴/12`.

## 2. Uniform acoustic lower bound

### 2.1 Exact four-square form

By homogeneity, a constant left rotation, and if needed a simultaneous swap of the source coordinates and source columns, an arbitrary nonzero background reduces to

\[
F=\begin{pmatrix}1&s\\0&h\end{pmatrix},
\qquad s^2+h^2\le1.
\]

The source swap is the integer coordinate permutation of the original torus; no irrational change of lattice is needed in this reduction.

Write

\[
F_\varepsilon=\operatorname{diag}(1,\varepsilon),\quad
\rho=h-\varepsilon,\quad d_F^2=s^2+\rho^2,
\quad m_0=3+\varepsilon^2,\quad a_0=3-\varepsilon^2.
\]

For a rank-one test `E=(u,v)^T tensor (p,q)`, define

\[
D=-\rho u+sv,\qquad E_0=su+\rho v,
\]

\[
T=m_0pu+2\varepsilon qv,\qquad V_0=(1+\varepsilon^2)pv,
\]

\[
\alpha=\frac{2\varepsilon}{m_0},\qquad
\beta=1+\frac6{m_0},
\]

\[
\widetilde T=T-\beta\varepsilon pD,\qquad
C=qE_0+\alpha pD,\qquad
\widetilde V=V_0+\varepsilon pE_0.
\]

Finally put

\[
\gamma=\frac{3-\varepsilon^2}{2(1+\varepsilon^2)},\qquad
\delta=\frac{2\varepsilon^2}{3+\varepsilon^2}.
\]

The exact acoustic identity is

\[
\boxed{
D^2f_\varepsilon(F)[E,E]
=\tfrac12\widetilde T^2+3\gamma C^2
+\gamma[(qD)^2+\widetilde V^2+2\delta(qD)\widetilde V].}
\tag{8}
\]

This follows from the accepted strain identity after the stated right scaling. For completeness, its four rescaled linear strain forms are

\[
\begin{aligned}
L_1&=-3[pu+q(su+hv)]+\varepsilon[qv+p(sv-hu)],\\
L_2&=(3-\varepsilon^2)[pu-q(su+hv)]
+\varepsilon(5+\varepsilon^2)[qv-p(sv-hu)],\\
L_3&=pv+q(sv-hu)+\varepsilon[qu+p(su+hv)],\\
L_4&=-pv+q(sv-hu)+\varepsilon[qu-p(su+hv)].
\end{aligned}
\]

Their weights are

\[
\frac{a_0}{4m_0},\quad
\frac3{4(1+\varepsilon^2)m_0},\quad
\frac{3a_0}{4m_0},\quad
\frac{a_0^2}{4(1+\varepsilon^2)m_0}.
\]

The identities

\[
L_1=-\widetilde T-3C,\quad
L_2=(1+\varepsilon^2)\widetilde T-a_0C,\quad
L_3=qD+\widetilde V,\quad L_4=qD-\widetilde V
\]

give (8) by exact substitution. The two mixed terms from the first pair cancel.

### 2.2 A lower bound uniform as epsilon tends to zero

For `epsilon<=1`, `gamma>=1/2` and `delta<=1/2`, so (8) is at least one quarter of

\[
|\mathcal M|^2=\widetilde T^2+\widetilde V^2+C^2+(qD)^2.
\]

Compare this to

\[
|\mathcal N|^2=T^2+V_0^2+(qE_0)^2+(qD)^2
=T^2+V_0^2+d_F^2q^2(u^2+v^2).
\]

Since `beta<=3`, `alpha<=2epsilon/3`, and `D²+E0²=d_F²(u²+v²)`,

\[
|\mathcal M-\mathcal N|^2
\le10\varepsilon^2d_F^2p^2(u^2+v^2).
\tag{9}
\]

Here the two four-vectors are ordered compatibly as `(T,V0,qE0,qD)` and their tilded counterparts. The relation

\[
pu=\frac{T-2\varepsilon qv}{3+\varepsilon^2}
\]

shows

\[
d_F^2p^2(u^2+v^2)
\le d_F^2\left(\frac29T^2+V_0^2\right)
+\frac89\varepsilon^2d_F^2q^2v^2
\le4|\mathcal N|^2,
\tag{10}
\]

because `d_F<=1+epsilon<=2`. If `epsilon<=1/16`, then `sqrt(40)epsilon<1/2`, so (8)-(10) imply

\[
D^2f_\varepsilon(F)[E,E]\ge\frac1{16}|\mathcal N|^2.
\]

At the critical background,

\[
D^2f_\varepsilon(F_\varepsilon)[E,E]
=\tfrac12T^2+\gamma V_0^2\le\tfrac32|\mathcal N|^2.
\]

Also `d_F²(p²+q²)(u²+v²)<=5|N|²`. Consequently

\[
\boxed{
D^2f_\varepsilon(F)[e\otimes\xi,e\otimes\xi]
\ge\frac1{104}\left[
D^2f_\varepsilon(F_\varepsilon)[e\otimes\xi,e\otimes\xi]
+d_F^2|\xi|^2|e|^2\right].}
\tag{11}
\]

This is uniform for `0<epsilon<=1/16` and every normalized background above. Summing (11) on the actual Fourier frequencies of a compatible gradient gives

\[
H[F,F]\ge\frac1{104}
\left(H[F_\varepsilon,F_\varepsilon]+d_F^2\|G\|_2^2\right).
\tag{12}
\]

The estimates apply to real and imaginary parts of complex Fourier amplitudes separately. No frequency cutoff, minimum angular separation, or lower second-moment bound is used.

## 3. Uniform mixed-minor estimate at the critical background

Write

\[
G=\begin{pmatrix}a&b\\c_1&d\end{pmatrix},\quad
A_\varepsilon=\frac{3+\varepsilon^2}{2},\quad
B_\varepsilon=\frac{(3-\varepsilon^2)(1+\varepsilon^2)}4,
\quad s_\varepsilon=A_\varepsilon a+\varepsilon d.
\]

Then

\[
q_\varepsilon=\int(s_\varepsilon^2+B_\varepsilon c_1^2)
=\tfrac12H[F_\varepsilon,F_\varepsilon],
\tag{13}
\]

and direct differentiation of (5) gives

\[
r:F_\varepsilon=\varepsilon\left[
C_1\int s_\varepsilon j+C_2\int a j\right],
\tag{14}
\]

\[
C_1=\frac{3(1+\varepsilon^2)}{3+\varepsilon^2}\le\frac32,
\qquad
C_2=\frac{3(1+\varepsilon^2)(3-\varepsilon^2)}{2(3+\varepsilon^2)}\le2.
\]

For Fourier frequency `(p,q)`, compatibility is `q c1=p d`. Minimizing the summand in (13) over c1 yields

\[
q_\varepsilon\ge\frac{27}{16}\|R_{1,\varepsilon}a\|_2^2,
\qquad
\widehat R_{1,\varepsilon}(p,q)=\frac{p}{\sqrt{p^2+\varepsilon^2q^2}}.
\tag{15}
\]

In particular `||R_{1,epsilon}a||2<=sqrt(qepsilon)` and `||c1||2<=2sqrt(qepsilon)`.

### 3.1 Anisotropic interpolation on the original torus

The accepted interpolation (1) has the exact anisotropic version

\[
\|a\|_{8/3}^{2}
\le C_0\|(a,\varepsilon b)\|_4
\|R_{1,\varepsilon}a\|_2.
\tag{16}
\]

For rational `epsilon=P/Q>0`, apply (1) to `h(x,y)=f(Qx,Py)`. The integer covering preserves normalized torus norms, while both derivative factors acquire Q and the multiplier becomes precisely R1,epsilon. Divide by Q². For irrational epsilon first approximate epsilon by rationals on a finite Fourier potential, then pass to general potentials by strong Sobolev approximation. Thus (16) has exactly the same constant and does not assert a changed source lattice.

For the same reason, the supplied L4 Beurling bound transfers to every anisotropic multiplier

\[
M_t(p,q)=\frac{tpq}{p^2+t^2q^2},\qquad
\|M_t\|_{4\to4}\le\frac32,
\tag{17}
\]

uniformly in `t>0`. For rational t use the integer covering; then use finite Fourier approximation for real t. Algebraically M_t is minus one half of the imaginary part of the anisotropic Beurling symbol. This is the same paid Beurling resource used in the earlier mixed-minor proof.

### 3.2 Low and high angular pieces

For `0<delta<=1`, let

\[
P_\delta(p,q)=\frac{\delta^2\varepsilon^2q^2}{p^2+\delta^2\varepsilon^2q^2},
\qquad a_L=P_\delta a,\quad a_H=(I-P_\delta)a.
\]

The first-row gradient compatibility gives the exact multiplier identity

\[
a_L=\delta\varepsilon M_{\delta\varepsilon}b,
\]

so `||aL||4<=(3/2)delta epsilon M`. Pointwise multiplier comparison also gives

\[
\|a_H\|_2\le\delta^{-1}\|R_{1,\varepsilon}a\|_2.
\]

Use the algebraic identity

\[
j=\frac{a s_\varepsilon-A_\varepsilon a^2}{\varepsilon}-bc_1.
\]

Hölder with exponents `(4,4,2)` for the first and third terms, and `(4,4/3)` followed by (16) for the a² term, gives

\[
\left|\int a_Lj\right|
\le(5+3C_0)\delta M^2\sqrt{q_\varepsilon}.
\]

The high piece gives

\[
\left|\int a_Hj\right|
\le\delta^{-1}d_J\sqrt{q_\varepsilon}.
\]

If `d_J>0`, choose `delta=sqrt(d_J)/M<=1/sqrt(2)`. If `d_J=0` the conclusion is immediate. Therefore

\[
\left|\int aj\right|
\le(6+3C_0)M\sqrt{d_J}\sqrt{q_\varepsilon}.
\tag{18}
\]

Together with (14), `|int s_epsilon j|<=d_J sqrt(qepsilon)`, and `sqrt(d_J)<=M/sqrt2`, this proves

\[
|r:F_\varepsilon|
\le\frac{27/2+6C_0}{\sqrt2}\,
\varepsilon M\sqrt{d_J}\sqrt{H[F_\varepsilon,F_\varepsilon]}.
\tag{19}
\]

## 4. All-background mixed estimate with a vanishing constant

For a normalized background as in Section 2, `|F-F_epsilon|=d_F`. From (7),

\[
|r:(F-F_\varepsilon)|\le7\varepsilon d_F\|G\|_2d_J.
\]

Combine this with (12), (19), and `d_J<=M sqrt(d_J)/sqrt2`. The exact combined constant is

\[
\sqrt{104}\left(\frac{27/2+6C_0}{\sqrt2}+\frac7{\sqrt2}\right)
=\sqrt{13}(41+12C_0)=D_0.
\]

Undoing the constant left rotation, source permutation, and scalar normalization gives, for every constant real F,

\[
\boxed{|r:F|\le D_0\varepsilon M\sqrt{d_J}\sqrt{H[F,F]}}
\quad(0<\varepsilon\le1/16).
\tag{20}
\]

This directly implies `r in range H` and

\[
r^TH^\dagger r\le D_0^2\varepsilon^2M^2d_J.
\tag{21}
\]

It is the needed parameter-uniform improvement over the fixed-k mixed estimate.

All estimates were first stated for finite Fourier potentials. For a general `W^(1,4)` potential, compatible Fejer approximations converge strongly in L4 at gradient level. Determinants converge in L2, cubic r moments converge, and quadratic H moments converge. Pass to (20) for every fixed F; no continuity of a pseudoinverse is assumed. The range and dual norm statements then follow in finite-dimensional linear algebra.

## 5. Spend the single strain reserve

The covariance of the accepted pointwise strain identities is explicit. With
\(D=\operatorname{diag}(\varepsilon,1)\), define

\[
S_\varepsilon(F,G)=S_k(FD,GD),\qquad
\lambda_\varepsilon(F)=\det(D)\lambda_k(FD).
\]

Then

\[
D^2f_\varepsilon(F)[G,G]
-2\lambda_\varepsilon(F)\det G
=|S_\varepsilon(F,G)|^2.
\]

This is a pointwise algebraic identity; it does not assume that GD is a compatible gradient on the original torus. Compatibility enters only after integration, through
\(\int\det(GD)=\det(D)\int\det G=0\). Thus the coordinate change introduces no unproved curl-preservation step.

Use the accepted strain notation `K_G A=S(A,G)`, `g=S(G,G)`. The exact identities, preserved by the source-column scaling, are

\[
H=K_G^*K_G,\qquad
3b=K_G^*g+r,\qquad
\|g\|_2^2=12c-2q,
\quad q=\int\lambda_\varepsilon(G)\det G.
\]

The vector

\[
z=g+K_GH^\dagger r
\]

is a feasible lift: `K_G^*z=3b`. Weighted Young and (7), (21) give

\[
\begin{aligned}
\|z\|_2^2
&\le\tfrac54\|g\|_2^2+5r^TH^\dagger r\\
&\le15c+\left(\tfrac{35}{4}\varepsilon+5D_0^2\varepsilon^2\right)M^2d_J\\
&\le\left(15+\tfrac{105}{2}\varepsilon+30D_0^2\varepsilon^2\right)c.
\end{aligned}
\tag{22}
\]

Here the last line uses `d_J<=M²/2` and `M⁴<=12c`. If

\[
\varepsilon\le\min\{1/105,\,1/(\sqrt{60}D_0)\},
\]

the last two terms in parentheses sum to at most one. The value K_* in (2) ensures these inequalities and `epsilon<=1/16` because C0>=1. Hence `||z||²<=16c`, so the least-norm lift gives

\[
b^TH^\dagger b\le\frac{16}{9}c,
\quad
\inf_A\left[\int f_\varepsilon(A+G)-f_\varepsilon(A)\right]
=c-\tfrac12b^TH^\dagger b\ge\frac19c.
\tag{23}
\]

There is no second use of the convex companion reserve in this argument.

An alternative use of the same feasible lift, by the triangle inequality before Young, gives the useful asymptotic estimate

\[
\boxed{
\frac{\inf_A[\int f_\varepsilon(A+G)-f_\varepsilon(A)]}{c}
\ge 1-\frac1{18}
\left[\sqrt{12+42\varepsilon}+\sqrt6D_0\varepsilon\right]^2
}\quad(0<\varepsilon\le1/16).
\tag{24}
\]

Indeed `||g||²<=(12+42epsilon)c` and `||K H†r||²<=6D0²epsilon²c`. The lower bound tends to 1/3 as epsilon tends to zero, uniformly over all means, frequencies, amplitudes and concentration profiles. It is an alternative estimate, not an additional reserve. This does not assert an exact c/3 reserve at any finite k.

## 6. Return to the original density and the unit torus

The normalized inequality (23) first implies its compactly supported form. Given a compactly supported potential on a bounded set, extend it by zero inside a larger cube and periodize on that cube. Rescale the cube to the unit torus, scaling the potential by the reciprocal side length so its gradient values remain unchanged. The outside region contributes zero to both the energy gap and the right-hand reserve.

Quasiconvexity and the quantitative reserve then transfer through the invertible source map. Put `T=diag(epsilon,1)`. For a compactly supported original potential phi on Omega, let

\[
\psi(y)=\phi(T^{-1}y),\qquad B=AT^{-1},\qquad y\in T\Omega.
\]

Then

\[
f_\varepsilon(B+D\psi(y))=J_k(A+D\phi(T^{-1}y)),
\quad
f_\varepsilon(D\psi(y))=J_k(D\phi(T^{-1}y)).
\]

The Jacobian factor det T multiplies both sides, so (23) gives the corresponding compact-support inequality for the ORIGINAL J_k.

To return to periodic tests, first take a smooth periodic phi and cut off its periodic extension on a cube of integer side length N. Use a cutoff equal to one away from a boundary layer of fixed width, with uniformly bounded derivative. The boundary layer has area O(N), and its energy is O(N) since phi and Dphi are bounded. The interior contributes N² times the torus integral up to O(N). Divide the compact-support inequality by N² and let N tend to infinity. Finally use strong periodic `W^(1,4)` approximation. Quartic growth gives L1 convergence of all energy terms by Hölder. This proves (3) exactly on the stated unit torus for every real k in the interval, including irrational k.

## 7. The optimal normalized reserve tends to one third

For the original family define

\[
\mathcal R(k)=\inf_{A,\,G=D\phi\ne0}
\frac{\int J_k(A+G)-J_k(A)}{\int J_k(G)}.
\]

The lower estimate (24), transferred as in Section 6, gives

\[
\mathcal R(k)\ge
1-\frac1{18}\left[
\sqrt{12+\frac{42}{\sqrt{k}}}
+\frac{\sqrt6D_0}{\sqrt{k}}\right]^2
\qquad(k\ge256).
\tag{25}
\]

There is also an exact universal upper bound. Fix a nonzero rank-one matrix
\(E=a\otimes e_1\), and for \(0<p<1\) take the periodic scalar function

\[
g_p(x_1)=
\begin{cases}
1,&0<x_1<p,\\
-p/(1-p),&p<x_1<1.
\end{cases}
\]

Its mean is zero. Its periodic antiderivative produces a compatible vector potential in \(W^{1,\infty}\) with gradient \(G_p=E g_p(x_1)\). Write \(m_i=\int g_p^i\). Along the admissible affine means \(A=\alpha E\),

\[
\frac{\Delta_{G_p}(\alpha E)}{J_k(E)}
=m_4+4\alpha m_3+6\alpha^2m_2.
\]

The minimizing scalar is \(\alpha=-m_3/(3m_2)\), and direct two-value integration gives

\[
\frac{\min_\alpha\Delta_{G_p}(\alpha E)}{\int J_k(G_p)}
=1-\frac23\frac{m_3^2}{m_2m_4}
=1-\frac23\frac{(1-2p)^2}{1-3p+3p^2}
\longrightarrow\frac13
\quad(p\downarrow0).
\tag{26}
\]

Thus \(\mathcal R(k)\le1/3\) for every \(k>1/3\). Combining this with (25) proves the exact asymptotic conclusion

\[
\boxed{\lim_{k\to\infty}\mathcal R(k)=\frac13.}
\tag{27}
\]

This uses an explicit compatible piecewise-linear potential and exact moments, with no sampling or search. It does not assert an exact one-third reserve at finite k.

## 8. Verification and resource receipt

The proof is analytic; no variational or optimization oracle is used. A single fixed symbolic check verified seven exact rational-polynomial identities: the four strain reconstructions, the four-square normal form, its equality with a direct Hessian contraction of the ORIGINAL normalized density, and the critical lambda pairing. The script `verify_scaled_strain.py` used installed SymPy 1.14.0, completed its checks in 1.8194098319982004 seconds (reported process wall time, including startup, 2.5420327670000002 seconds), and had an externally imposed 30-second cap. Every identity had zero numerator exactly. The receipt is `scaled_strain_verification_receipt.json`.

No approximation is used to assert a sign in the theorem. Rational approximations in the anisotropic multiplier step are controlled strong limits of finite Fourier expressions, followed by bounded-operator density, as specified above.

The root coordinator reviewed the displayed estimates, constants, and source transfer. The construction principal independently checked the four strain reconstructions and weights, the bounds through the factor 1/104, the normalized coercivity and multiplier estimates, and the transfer back to the original density. Neither review found a discrepancy. Their reviews are not additional premises in the proof.

The unresolved full endpoint is the remaining interval `1/3<k<K_*`. This theorem gives neither a negative witness there nor an affirmative proof there.
