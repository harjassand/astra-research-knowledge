"""Exact independent-mean moments of the stored compatible ridge potentials.

This module defines the verifier only; importing it runs no search. Moments
are normalized by 8(k+1), and all operations below are rational arithmetic.
"""
from ridge_composition import *

HU=[[Q(2) if i==j and i in (0,2) else Z for j in range(4)] for i in range(4)]
HV=[[Q(2) if i==j and i in (1,3) else Z for j in range(4)] for i in range(4)]
HJ=[[Q(1) if (i,j) in [(0,3),(3,0)] else Q(-1) if (i,j) in [(1,2),(2,1)] else Z for j in range(4)] for i in range(4)]

def atom_moments(G,k):
    a,b,c,d=G; k=Q(k); n=k+1; ell=3*k-1
    u=a*a+c*c; v=b*b+d*d; j=a*d-b*c; s=k*u-v+2*j
    du=[2*a,Z,2*c,Z]; dv=[Z,2*b,Z,2*d]; dj=[d,-c,-b,a]
    ds=[k*du[i]-dv[i]+2*dj[i] for i in range(4)]
    hs=[[k*HU[i][j]-HV[i][j]+2*HJ[i][j] for j in range(4)] for i in range(4)]
    alpha=ell; beta=2*n*ell; gamma=8*n
    value=alpha*s*s+beta*u*v+gamma*j*j
    grad=[2*alpha*s*ds[i]+beta*(v*du[i]+u*dv[i])+2*gamma*j*dj[i] for i in range(4)]
    hess=[[2*alpha*(ds[i]*ds[jj]+s*hs[i][jj])
            +beta*(v*HU[i][jj]+u*HV[i][jj]+du[i]*dv[jj]+dv[i]*du[jj])
            +2*gamma*(dj[i]*dj[jj]+j*HJ[i][jj]) for jj in range(4)] for i in range(4)]
    return value,grad,hess

def independent_moments(atoms,k,L=None):
    L=[[O,Z],[Z,O]] if L is None else L
    c=Z; b=[Z]*4; H=zero(4); mg=[Z]*4
    for F,w in atoms.items():
        G=[[F[0]-1,F[1]],[F[2],F[3]-1]]; G=mm(L,G); gf=[t for row in G for t in row]
        cc,bb,HH=atom_moments(gf,k)
        c+=w*cc
        for i in range(4):
            b[i]+=w*bb[i]; mg[i]+=w*gf[i]
            for j in range(4): H[i][j]+=w*HH[i][j]
    assert mg==[0,0,0,0]
    return c,b,H

def solve_pd(H,b):
    N=len(b); L=zero(N); D=[]
    for i in range(N):
        L[i][i]=O
        pivot=H[i][i]-sum(L[i][j]**2*D[j] for j in range(i))
        if pivot<=0: return None,D+[pivot]
        D.append(pivot)
        for r in range(i+1,N):
            L[r][i]=(H[r][i]-sum(L[r][j]*L[i][j]*D[j] for j in range(i)))/pivot
    y=[]
    for i in range(N):y.append(b[i]-sum(L[i][j]*y[j] for j in range(i)))
    z=[y[i]/D[i] for i in range(N)]; x=[Z]*N
    for i in range(N-1,-1,-1):x[i]=z[i]-sum(L[j][i]*x[j] for j in range(i+1,N))
    assert matvec(H,x)==b
    return x,D

def exact_independent_minimum(atoms,k,L=None):
    c,b,H=independent_moments(atoms,k,L); x,pivots=solve_pd(H,b)
    if x is None: return dict(status='not_positive_definite_in_exact_LDL',c=c,b=b,H=H,pivots=pivots)
    value=(c-dot(b,x)/2)/(8*(k+1)); A=[[-x[0],-x[1]],[-x[2],-x[3]]]
    ratio=dot(b,x)/(2*c) if c else Z
    return dict(status='exact_PD_minimum',minimum_gap=value,A=A,moment_ratio=ratio,
                c=c,b=b,H=H,pivots=pivots)

def direct_independent_gap(atoms,k,A,L=None):
    L=[[O,Z],[Z,O]] if L is None else L
    val=Z
    for F,w in atoms.items():
        G=mm(L,[[F[0]-1,F[1]],[F[2],F[3]-1]])
        FF=[[A[i][j]+G[i][j] for j in range(2)] for i in range(2)]
        val+=w*J(FF,k)
    return val-J(A,k)
