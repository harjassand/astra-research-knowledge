# A finite compatible interface with variable Jacobian

The construction consists of periodic rational piecewise-affine maps, composed in their target variables. It is distinct from the previously checked determinant-one four-shear fields and the two all-A/all-k-certified generating-function fields. No negative claim is made by the construction alone.

## Maps, inverses, compatibility

For 0<p<1 let h_p be the continuous one-periodic triangular function with values h_p(0)=h_p(1)=0 and h_p(p)=1. For an integer vector q, rational output vector a and rational phase theta, set

\[
T(z)=z+a h_p(q\cdot z+\theta).
\]

It commutes with every integer translation, is globally Lipschitz, and is continuous at its knots. On each affine branch its derivative is `I+h'_p a tensor q`. Thus any finite composition f of these maps satisfies f(x+m)=f(x)+m for m in Z^2. In particular B=Df=I+D(f-x) is an actual periodic compatible gradient of a Lipschitz potential, with mean I. There is no relaxation to an arbitrary matrix measure.

Write c=q dot a. If -p<c<1-p then T is a homeomorphism, its determinant is strictly positive on both branches, and its exact inverse is

\[
T^{-1}(z)=z-a h_{p+c}(q\cdot z+\theta).
\]

Indeed the scalar coordinate w=q dot z+theta transforms by w -> w+c h_p(w); its breakpoint p maps to p+c and its two positive slopes invert. The transverse change is then exactly reversed. The finite candidates below use this inverse to form commutators of two compressible ridge homeomorphisms, sometimes followed by a fifth ridge. Their Jacobian generally varies. No invertibility claim is needed to establish compatibility, but the displayed parameter choices do satisfy it.

For every constant real A, the field AB=A+D[A(f-x)] is compatible with affine mean A. All outer affine means are examined using the exact variable-Jacobian sphere criterion in `construction_global_continuation/VARIABLE_JACOBIAN_OUTER_AFFINE_CRITERION.md`.

## Exact integration

Each original unit-square cell carries an exact rational affine map f(x)=Mx+t. At the next stage, knot strips of q dot (Mx+t)+theta cut the cell by rational half-planes. On each retained polygon the composition is updated by

\[
M_{new}=M+s\,a\otimes(q^TM),\qquad
t_{new}=t+a[s(q\cdot t+\theta-j)+b],
\]

where j is the period integer and s,b are the triangular branch coefficients. Shoelace areas and all matrix entries remain rational. The cuts form a partition up to boundaries of measure zero. Exact checks verify total area 1, mean matrix I, and mean determinant 1.

All required moments are exact rational sums of quartic matrix polynomials. In particular the determinant weights and determinant-variance term in the outer-affine criterion are retained. For a rational outer matrix A, the original energy gap is computed exactly from these moments. If a negative sign is obtained, a separate direct weighted sum of the ORIGINAL J_k(AB) is required to match it exactly.

## Fixed finite budget, chosen before computation

The script `ridge_search.py` contains exactly 48 deterministic parameter choices: eight explicit direction/knot/shear patterns, three pairs of compression ratios, and two shear signs. Every composition has four or five stages. The rare compressed knot may be as small as p/8. No random input, adaptive coefficient optimizer, new model, or external resource is used.

Hard caps are 20,000 retained polygons per stage, 200,000 band tests per candidate, 4,096 bits per rational vertex coordinate, and five stages. A 180-second wall cap is checked between candidates. Reaching any cap is recorded, not treated as a sign result.

For each completed field, candidate means are generated at the four rational values k=17/50, 1/2, 1, 2. Each three-dimensional equality-constrained quadratic solve uses at most 32 bracket expansions and 90 scalar bisections after a floating 3-by-3 spectral decomposition. These calculations suggest means only; floating nonnegative values are not positivity certificates.

Each candidate mean is converted to an explicit rational triangular A by rounding at 24 binary digits. Its original gap is then evaluated exactly. For fixed rational A the polynomial `8(k+1) gap` has degree at most three in k. The derivative supplies at most two further floating stationary candidates in (1/3,16], each rounded to an explicit rational and checked exactly. This bounded step exploits parameter dependence without an optimization oracle or a claimed global minimization in k. At most 576 exact original-gap checks can therefore occur: 48 fields times 4 means times 3 parameter values.

Every completed or capped candidate, its input, cell counts, timing, and checked signs is retained in the output receipts. A nonnegative checked value is evidence only about that exact candidate and parameter; it does not prove the all-A/all-k criterion or full quasiconvexity.

## Completed receipt

The fixed budget finished in 1.8002 seconds of measured search time. All 48 candidates completed; none hit a cap. Their final subdivisions contained 3,019 polygons in total, at most 147 for one candidate. There were 9,316 band tests. The maximum observed rational vertex size was 37 bits.

There were 192 floating sphere solves, 192 bracket checks, and 17,280 bisections. All 192 explicit rational outer means had a strictly positive exact original gap at their tested parameter. The bounded cubic derivative step produced no stationary candidate in (1/3,16], so there were no additional parameter checks. No compatible negative was obtained.

Every field had positive determinant variance; the smallest and largest cell Jacobians across the retained inputs were 1/45 and 45. Thus these were genuinely variable-Jacobian constructions, not re-encodings of the prior area-preserving fields.

The smallest floating sphere value was approximately 1.723780919e-6 at k=17/50 for candidate 16. Its rational outer mean was

\[
A=\begin{pmatrix}
4189293/2097152&289777/4194304\\
0&-249/16777216
\end{pmatrix},
\]

with determinant `-1043133957/35184372088832`, approximately -2.97e-5. Its exact original gap was

\[
\frac{383417286012795610102139788145605919884195052119}
{55740128864536623735671571927499815239775336529920000}>0,
\]

approximately 6.878658048e-6. This differs from the trace-normalized sphere value by the prescribed quartic scale. The small value arises at an almost singular mean and is not a certified approach to a negative gap.

Two exact inverse-composition checks and three comparisons of the moment formula with a separate direct original-energy sum were run before the search. They took 0.0181 seconds; their receipt is `interface_verification.json`. The complete search receipt is `ridge_search_summary.json`, and every input and checked value is retained in `ridge_search_results.jsonl`.

The means checked here belong to the family A B. For a fixed stored potential psi=f-x, the more general translation family A0+Dpsi permits A0 independent of the multiplier in A B; it was not tested by this declared budget. This distinction is explicit because positivity of the checked outer-affine family would not imply positivity of the translated family for that fixed psi.

A separately approved, separately recorded 192-system exact post-processing subsequently addressed this independent-mean freedom at the same four parameters. Its proof and receipt are in `INDEPENDENT_MEAN_POSTPROCESS.md`. Every minimum in that finite post-processing was strictly positive; this is an exact all-mean statement for the tested potential and parameter, not an inference from the floating sphere candidates.
