"""Exact compatible periodic ridge compositions and original-energy moments.

Only rational arithmetic is used for geometry, moments, and checked energy gaps.
The small floating spectral solve below is a bounded candidate generator.
"""
from fractions import Fraction as Q
from pathlib import Path
import sys, math
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'construction_continuation'))
from exact_shear_polygons import clip, area, J

Z=Q(0); O=Q(1)

def dot(a,b): return sum(x*y for x,y in zip(a,b))
def matvec(a,b): return [dot(r,b) for r in a]
def form(a,x,y): return dot(x,matvec(a,y))
def zero(n): return [[Z for _ in range(n)] for _ in range(n)]
def mm(a,b): return [[sum(a[i][t]*b[t][j] for t in range(2)) for j in range(2)] for i in range(2)]

def ridge(q,c,H,p,phase=Z):
    q=tuple(map(Q,q)); c=Q(c); H=Q(H); p=Q(p); phase=Q(phase)
    den=dot(q,q); perp=(-q[1],q[0])
    a=tuple((c*q[i]+H*perp[i])/den for i in range(2))
    assert dot(q,a)==c and 0<p<1
    return dict(q=q,a=a,p=p,phase=phase)

def inverse(step):
    c=dot(step['q'],step['a']); pp=step['p']+c
    assert 0<pp<1
    return dict(q=step['q'],a=tuple(-v for v in step['a']),p=pp,phase=step['phase'])

class CapExceeded(Exception): pass

def compose(steps, maxcells=20000, maxbands=200000, maxbits=4096):
    assert len(steps)<=5
    cells=[([(Z,Z),(O,Z),(O,O),(Z,O)],((O,Z),(Z,O)),(Z,Z))]
    counts=[]; bandtests=0
    for st in steps:
        q,a,p,phase=(st[s] for s in ['q','a','p','phase']); new=[]
        for poly,M,t in cells:
            row=tuple(sum(q[i]*M[i][j] for i in range(2)) for j in range(2))
            shift=dot(q,t)+phase
            vals=[dot(row,xy)+shift for xy in poly]; low=min(vals); high=max(vals)
            if low==high:
                ii=low.numerator//low.denominator; u=low-ii
                h=u/p if u<=p else (1-u)/(1-p)
                new.append((poly,M,tuple(t[i]+a[i]*h for i in range(2))))
                continue
            for integer in range(low.numerator//low.denominator,high.numerator//high.denominator+1):
                for left,right,s,intercept in [(Q(integer),Q(integer)+p,1/p,Z),(Q(integer)+p,Q(integer+1),-1/(1-p),1/(1-p))]:
                    bandtests+=1
                    if bandtests>maxbands: raise CapExceeded('band-test cap')
                    if right<=low or left>=high: continue
                    part=clip(clip(poly,row,left-shift,True),row,right-shift,False)
                    if len(part)<3 or area(part)==0: continue
                    N=tuple(tuple(M[i][j]+a[i]*s*row[j] for j in range(2)) for i in range(2))
                    T=tuple(t[i]+a[i]*(s*(shift-integer)+intercept) for i in range(2))
                    new.append((part,N,T))
                    if len(new)>maxcells: raise CapExceeded('polygon cap')
                    if any(v.numerator.bit_length()>maxbits or v.denominator.bit_length()>maxbits for xy in part for v in xy):
                        raise CapExceeded('rational-coordinate bit cap')
        cells=new; counts.append(len(cells))
    return cells,dict(cell_counts=counts,bandtests=bandtests)

def moments(cells):
    atoms={}; total=Z; mean=[Z]*4; jmean=Z; minj=None; maxj=None; bits=0
    for poly,M,t in cells:
        w=area(poly); F=tuple(v for row in M for v in row)
        atoms[F]=atoms.get(F,Z)+w
        total+=w
        for i in range(4): mean[i]+=w*F[i]
        j=F[0]*F[3]-F[1]*F[2]; jmean+=w*j
        minj=j if minj is None else min(minj,j); maxj=j if maxj is None else max(maxj,j)
        bits=max(bits,*(v.numerator.bit_length() for xy in poly for v in xy),*(v.denominator.bit_length() for xy in poly for v in xy))
    assert total==1 and mean==[1,0,0,1] and jmean==1
    U=zero(3); V=zero(3); W=zero(3); l1=[Z]*3; l2=[Z]*3; eta=-O
    for (a,b,c,d),weight in atoms.items():
        p=[a*a,2*a*c,c*c]; q=[b*b,2*b*d,d*d]; h=a*d-b*c
        eta+=weight*h*h
        for i in range(3):
            l1[i]+=weight*h*p[i]; l2[i]+=weight*h*q[i]
            for j in range(3):
                U[i][j]+=weight*p[i]*p[j]
                V[i][j]+=weight*q[i]*q[j]
                W[i][j]+=weight*(p[i]*q[j]+q[i]*p[j])/2
    U[0][0]-=1; V[2][2]-=1; W[0][2]-=Q(1,2); W[2][0]-=Q(1,2)
    l1[0]-=1; l2[2]-=1
    assert eta>=0
    return dict(U=U,V=V,W=W,l1=l1,l2=l2,eta=eta,atoms=atoms,
                jacobian_min=minj,jacobian_max=maxj,coordinate_max_bits=bits)

def sphere(data,k):
    k=Q(k); ell=3*k-1
    R=[[k*k*data['U'][i][j]+2*data['W'][i][j]+data['V'][i][j] for j in range(3)] for i in range(3)]
    l=[k*x-y for x,y in zip(data['l1'],data['l2'])]
    t0=[O,Z,O]; T=[[O,Z,-O],[Z,O,Z]]; M=zero(3); h=[Z]*3; c=ell*form(R,t0,t0)
    for i in range(2):
        h[i]=ell*form(R,T[i],t0)
        for j in range(2): M[i][j]=ell*form(R,T[i],T[j])
        M[i][2]=M[2][i]=2*ell*dot(l,T[i])
    h[2]=2*ell*dot(l,t0); M[2][2]=4*(5*k+1)*data['eta']
    return M,h,c

def bounded_sphere_candidate(M,h,c,steps=90):
    M=np.array(M,float); h=np.array(h,float); c=float(c)
    e,U=np.linalg.eigh(M); g=U.T@h
    scale=max(1.,np.linalg.norm(M),np.linalg.norm(h)); tol=1e-13*scale
    low=e-e[0]<tol; other=~low; v=np.zeros(3); v[other]=-g[other]/(e[other]-e[0]); n0=float(v@v)
    bracketsteps=0; bisections=0
    if np.linalg.norm(g[low])<tol and n0<=1:
        lam=e[0]; v[np.flatnonzero(low)[0]]=math.sqrt(max(0.,1-n0))
    else:
        width=max(1.,np.linalg.norm(h),np.linalg.norm(M)); lo=e[0]-width
        for j in range(32):
            bracketsteps+=1
            if np.sum((g/(e-lo))**2)<1: break
            width*=2; lo=e[0]-width
        else: raise CapExceeded('secular bracket cap')
        hi=np.nextafter(e[0],-np.inf)
        for j in range(steps):
            mid=(lo+hi)/2; bisections+=1
            if np.sum((g/(e-mid))**2)>1: hi=mid
            else: lo=mid
        lam=(lo+hi)/2; v=-g/(e-lam); v/=np.linalg.norm(v)
    v=U@v
    return dict(v=v.tolist(),value=float(v@M@v+2*h@v+c),lagrange=float(lam),
                bracketsteps=bracketsteps,bisections=bisections)

def rational_affine(v,bits=24):
    x,y,d=[Q(round(float(t)*2**bits),2**bits) for t in v]
    return [[1+x,y],[Z,d]] if x>=0 else [[d,Z],[y,1-x]]

def gap_polynomial(data,A):
    a,b=A[0]; c,d=A[1]; z=[a*a+c*c,a*b+c*d,b*b+d*d]; jj=a*d-b*c
    r2=form(data['U'],z,z)
    r1=4*jj*dot(data['l1'],z)
    r0=form(data['V'],z,z)+2*form(data['W'],z,z)-4*jj*dot(data['l2'],z)
    # 8(k+1) gap: low-to-high powers of k.
    return [-r0+4*data['eta']*jj*jj,3*r0-r1+20*data['eta']*jj*jj,3*r1-r2,3*r2]

def pvalue(co,k):
    out=Z
    for c in reversed(co):out=out*k+c
    return out

def exact_gap(data,k,A): return pvalue(gap_polynomial(data,A),Q(k))/(8*(Q(k)+1))

def direct_gap(data,k,A):
    return sum(w*J(mm(A,[list(F[:2]),list(F[2:])]),k) for F,w in data['atoms'].items())-J(A,k)

def stationary_candidates(co):
    # At most two floating roots of the derivative, then explicit rationals.
    c0,c1,c2,c3=map(float,co); roots=[]
    if c3:
        disc=4*c2*c2-12*c3*c1
        if disc>=0:
            sd=math.sqrt(disc)
            roots=[(-2*c2-sd)/(6*c3),(-2*c2+sd)/(6*c3)]
    elif c2: roots=[-c1/(2*c2)]
    rounded=[Q(round(r*2**24),2**24) for r in roots if math.isfinite(r) and Q(1,3)<r<=Q(16)]
    return [r for r in rounded if Q(1,3)<r<=Q(16)]

def serial(x):
    if isinstance(x,Q): return str(x)
    if isinstance(x,dict): return {str(k):serial(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [serial(v) for v in x]
    return x
