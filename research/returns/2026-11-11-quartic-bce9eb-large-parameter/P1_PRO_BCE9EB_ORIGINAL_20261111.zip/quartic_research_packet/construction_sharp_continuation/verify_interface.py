from ridge_search import *

start=time.perf_counter(); receipts=[]
for q,c,H,p,phase in [((1,0),Q(-3,16),Q(1,3),Q(1,4),Q(2,5)),
                       ((1,-1),Q(1,8),Q(-2,7),Q(1,3),Q(1,6))]:
    t=ridge(q,c,H,p,phase)
    cells,stats=compose([t,inverse(t)])
    assert sum(area(poly) for poly,M,b in cells)==1
    assert all(M==((1,0),(0,1)) and b==(0,0) for poly,M,b in cells)
    receipts.append(dict(kind='exact_inverse',cells=len(cells),bandtests=stats['bandtests']))
inp=next(inputs()); cells,stats=compose(inp['steps']); m=moments(cells)
A=[[Q(2,3),Q(-1,5)],[Q(4,7),Q(9,8)]]
for k in [Q(17,50),Q(1),Q(2)]:
    a=exact_gap(m,k,A); b=direct_gap(m,k,A); assert a==b
    receipts.append(dict(kind='moment_vs_direct_original_gap',k=k,gap=a))
receipt=dict(checks=receipts,seconds=time.perf_counter()-start)
(BASE/'interface_verification.json').write_text(json.dumps(serial(receipt),indent=2)+'\n')
print(json.dumps(serial(receipt)),flush=True)
