"""Fixed 48-candidate compressible-ridge composition investigation.
Floating minima are candidates only. Every recorded original gap at a rational
outer matrix is evaluated exactly; any negative also receives direct checking.
"""
from ridge_composition import *
import json,time,itertools

BASE=Path(__file__).resolve().parent
KS=[Q(17,50),Q(1,2),Q(1),Q(2)]

def inputs():
    psets=[(Q(1,2),Q(1,2)),(Q(1,8),Q(1,2)),(Q(1,2),Q(1,8)),(Q(1,8),Q(1,8)),
           (Q(1,32),Q(1,8)),(Q(1,8),Q(1,32)),(Q(1,32),Q(1,32)),(Q(1,8),Q(1,8))]
    rhos=[(Q(1,2),Q(1,2)),(Q(1,8),Q(1,2)),(Q(1,2),Q(1,8))]
    for pattern,(p1,p2) in enumerate(psets):
        q1,q2=((1,0),(0,1)) if pattern<4 else (((1,0),(1,1)) if pattern<6 else ((1,1),(1,-1)))
        slope=Q(1) if pattern%3==0 else (Q(4) if pattern%3==1 else Q(16))
        for ri,(rho1,rho2) in enumerate(rhos):
            for sign in [-1,1]:
                t1=ridge(q1,p1*(rho1-1),slope*p1,p1,Q(pattern%3,8))
                t2=ridge(q2,p2*(rho2-1),sign*p2/(2*slope),p2,Q((3*pattern+ri)%7,8))
                steps=[t1,t2,inverse(t1),inverse(t2)]
                if pattern%2:
                    q3=tuple(q1[j]+q2[j] for j in range(2))
                    steps.append(ridge(q3,Q(-1,16),Q(sign,16),Q(1,4),Q(1,3)))
                yield dict(pattern=pattern,rho_index=ri,sign=sign,steps=steps)

def run():
    start=time.perf_counter(); rows=[]; best=None; negative=None
    totals=dict(candidates=0,completed=0,cap_exceeded=0,polygons=0,bandtests=0,
                sphere_calls=0,bisections=0,bracketsteps=0,exact_gaps=0,stationary_checks=0)
    with (BASE/'ridge_search_results.jsonl').open('w') as out:
        for index,inp in enumerate(inputs()):
            if time.perf_counter()-start>180:
                totals['termination']='180-second between-candidate wall cap'; break
            t=time.perf_counter(); totals['candidates']+=1
            row=dict(index=index,input=inp)
            try:
                cells,stats=compose(inp['steps'])
                m=moments(cells)
                totals['polygons']+=len(cells); totals['bandtests']+=stats['bandtests']
                row.update(stats,atoms=len(m['atoms']),eta=m['eta'],jacobian_min=m['jacobian_min'],
                           jacobian_max=m['jacobian_max'],coordinate_max_bits=m['coordinate_max_bits'])
                values=[]
                for k in KS:
                    can=bounded_sphere_candidate(*sphere(m,k)); totals['sphere_calls']+=1
                    totals['bisections']+=can['bisections']; totals['bracketsteps']+=can['bracketsteps']
                    A=rational_affine(can['v']); co=gap_polynomial(m,A); gap=exact_gap(m,k,A); totals['exact_gaps']+=1
                    sub=dict(k=k,candidate=can,rational_A=A,exact_original_gap=gap,original_gap_float=float(gap),k_polynomial=co)
                    checked=[(k,gap)]
                    for kk in stationary_candidates(co):
                        gg=exact_gap(m,kk,A); totals['exact_gaps']+=1; totals['stationary_checks']+=1
                        checked.append((kk,gg))
                    sub['stationary_checks']=checked[1:]
                    for kk,gg in checked:
                        if gg<0:
                            direct=direct_gap(m,kk,A)
                            assert direct==gg
                            negative=dict(index=index,input=inp,k=kk,A=A,gap=gg,independent_direct_gap=direct,
                                          stats=stats,eta=m['eta'])
                            (BASE/'ridge_negative_certificate.json').write_text(json.dumps(serial(negative),indent=2)+'\n')
                            break
                    values.append(sub)
                    score=can['value']/(8*(float(k)+1))
                    if best is None or score<best['score']:
                        best=dict(index=index,k=str(k),score=score,input=inp,mean=sub,eta=m['eta'],stats=stats)
                    if negative: break
                row['values']=values; row['status']='exact_negative' if negative else 'no_negative_at_checked_points'
                totals['completed']+=1
            except CapExceeded as e:
                totals['cap_exceeded']+=1; row['status']='cap_exceeded'; row['reason']=str(e)
            row['seconds']=time.perf_counter()-t
            out.write(json.dumps(serial(row))+'\n'); out.flush(); rows.append(row)
            if index%4==3 or negative:
                print(json.dumps(dict(completed=totals['completed'],index=index,seconds=time.perf_counter()-start,
                                      best=best['score'] if best else None,negative=negative is not None)),flush=True)
            if negative:
                totals['termination']='exact negative certificate'; break
        else: totals['termination']='48-candidate budget exhausted'
    totals['seconds']=time.perf_counter()-start
    summary=dict(budget=dict(candidates=48,stages=5,polygons_per_stage=20000,bandtests_per_candidate=200000,
                            coordinate_bits=4096,sphere_means_per_field=4,bracketsteps=32,bisections=90,
                            stationary_parameters_per_mean=2,stationary_parameter_cap=16,
                            rational_rounding_bits=24,between_candidate_wall_seconds=180),
                 totals=totals,best=best,negative=negative)
    (BASE/'ridge_search_summary.json').write_text(json.dumps(serial(summary),indent=2)+'\n')
    print(json.dumps(serial(totals)),flush=True)

if __name__=='__main__': run()
