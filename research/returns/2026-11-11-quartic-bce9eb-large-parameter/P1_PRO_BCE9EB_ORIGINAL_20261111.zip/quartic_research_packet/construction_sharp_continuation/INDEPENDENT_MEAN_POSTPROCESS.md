# Exact independent-mean checks for the compressible ridge fields

## Outcome and scope

The separate approved post-processing budget comprised the same 48 compatible piecewise-affine potentials from `ridge_search_results.jsonl`, at the four exact parameters

\[
k\in\{17/50,\ 1/2,\ 1,\ 2\}.
\]

All 192 cases have a positive-definite exact moment Hessian and a strictly positive exact minimized ORIGINAL energy gap. Thus, for each of these fixed potentials and each of these four parameters, the inequality holds for **every independent real affine mean**. Quartic homogeneity also gives it for every real scalar amplitude of that potential. This does not prove the inequality at every k or for arbitrary compatible potentials, and no negative witness was obtained.

The earlier outer-affine test used fields A B, where B=Df has mean I. Here the potential is fixed as psi=f-x, G=Dpsi=B-I, and the mean A_0 is varied independently in A_0+G. The latter freedom was not included in the earlier outer-affine budget.

## Exact formulas and certification

For fixed k, let P_k=8(k+1)J_k. Define exact moments

\[
\widetilde c=\int P_k(G),\qquad
\widetilde b=\int DP_k(G),\qquad
\widetilde H=\int D^2P_k(G).
\]

The accepted quartic polarization identity gives

\[
8(k+1)\left[\int J_k(A_0+G)-J_k(A_0)\right]
=\widetilde c+\widetilde b:A_0
 +\tfrac12 A_0:\widetilde H A_0.
\tag{1}
\]

All entries are rational sums over the exact polygons. With positive-definite H, rational LDL factorization solves Hx=b exactly. The minimizing affine matrix is A_0=-x, and

\[
\boxed{\Delta_{\min}
=\frac{\widetilde c-\tfrac12\widetilde b^T
                 \widetilde H^{-1}\widetilde b}{8(k+1)}.}
\tag{2}
\]

Positive rational LDL pivots certify positive definiteness; the displayed rational numerator certifies the sign of the complete minimum. There is no floating mean, numerical pseudoinverse, optimization oracle, or rounding margin in this step. The solver also verifies the exact residual Hx=b.

For reproducibility, the derivative formulas are implemented directly. Write u=|G_col1|^2, v=|G_col2|^2, j=det G and s=ku-v+2j. Then

\[
P_k=\alpha s^2+\beta uv+\gamma j^2,
\quad\alpha=3k-1,\quad
\beta=2(k+1)(3k-1),\quad\gamma=8(k+1).
\]

Writing gradients as column vectors and using the constant Hessians of u,v,j,

\[
DP_k=2\alpha s\,Ds+\beta(vDu+uDv)+2\gamma jDj,
\]
\[
D^2P_k=2\alpha(Ds\otimes Ds+sD^2s)
 +\beta(vD^2u+uD^2v+Du\otimes Dv+Dv\otimes Du)
 +2\gamma(Dj\otimes Dj+jD^2j).
\tag{3}
\]

The independent direct evaluator computes the original sum `sum area J_k(A_0+G)-J_k(A_0)` without using (1). This matched (2) at all four minimizing means of the first field. Any negative case would also have required this direct equality check; none occurred.

For a real amplitude t, G is replaced by tG and the three moments scale as t^4, t^3, t^2 respectively. Hence for every A_0,

\[
\int J_k(A_0+tG)-J_k(A_0)\ge t^4\Delta_{\min}.
\tag{4}
\]

This extends each fixed-parameter certificate to all scalar amplitudes, including signs, with equality at zero amplitude. It does not imply arbitrary independent output-matrix transformations of the potential.

## Largest moment ratio and exact positive margin

The largest ratio among the 192 exact systems was

\[
\frac{\widetilde b^T\widetilde H^{-1}\widetilde b}
     {2\widetilde c}
=\frac{15538074773549925282751355091280400256}
       {18343147158355913407236029235507090589}
\approx0.8470779108628486.
\tag{5}
\]

It occurs at k=17/50 for candidate 1, a four-map compressible commutator with 19 polygons. Define

\[
T_1(z)=z+(-1/4,1/2)h_{1/2}(z_1),\qquad
T_2(z)=z+(-1/4,-1/4)h_{1/2}(z_2),
\]

and take

\[
f=T_2^{-1}\circ T_1^{-1}\circ T_2\circ T_1,\qquad\psi=f-x.
\]

The inverse triangular knots are 1/4, as proved by the exact inverse formula in the interface note. Every map is a degree-one periodic lift and a Lipschitz homeomorphism. The displayed composition is an actual compatible vector map, not an arbitrary distribution of matrices.

Its exact all-mean minimum is

\[
\Delta_{\min}
=\frac{2805072384805988124484674144226690333}
       {4750520038952153618009817261973440000}
\approx0.5904769081712404>0.
\tag{6}
\]

The value c=integral J_k(G) is approximately 3.8612924496581966. Since (5) exceeds 2/3, this small polygon field also violates a universal c/3 lower reserve, while satisfying the original nonnegative-gap statement at this parameter. The distinction is exact. An earlier different field had already disproved that stronger reserve, so this is a simpler additional example, not a new obstruction to quasiconvexity.

The exact minimizing rational matrix, full c,b,H data, and pivots for this case are stored in `independent_mean_summary.json`. Every other case, its minimizing matrix, exact positive value, moment ratio, and LDL pivots is retained in `independent_mean_results.jsonl`.

## Actual finite costs and termination

The declared cap was 48 existing fields times four parameters, or 192 exact 4-by-4 systems, with no new field coefficients or geometric search. A 180-second wall cap was checked between fields. The same previously declared geometry caps were retained during exact reconstruction.

All 48 fields and all 192 systems completed. All 192 had positive rational LDL pivots and positive minima. Exact reconstruction used 3,019 final polygons and 9,316 band tests in total. Four independent direct energy sums were compared with their calculated minima. The measured successful post-processing time was 4.5444 seconds. A missing closing list-comprehension bracket was corrected after an initial import-only syntax failure; no geometry or mathematical candidate ran during that failed invocation.

Execution stopped when the 192-system budget was exhausted. No optimizer, install, source retrieval, extra agent, native query, or external resource was used. All inherited source/access holds remain in force.
