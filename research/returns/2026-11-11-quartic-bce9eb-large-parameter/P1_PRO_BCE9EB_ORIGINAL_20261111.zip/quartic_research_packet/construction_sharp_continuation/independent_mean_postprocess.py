"""Separate finite post-processing: 48 existing fields x four exact parameters.
No new geometry inputs, floating candidates, or optimizer are used.
"""
from independent_mean_support import *
import json,time

BASE=Path(__file__).resolve().parent
KS=[Q(17,50),Q(1,2),Q(1),Q(2)]

def parse_steps(steps):
    return [dict(q=tuple(map(Q,s['q'])),a=tuple(map(Q,s['a'])),p=Q(s['p']),phase=Q(s['phase'])) for s in steps]

def run():
    sys.set_int_max_str_digits(100000)
    start=time.perf_counter(); inputs=[json.loads(s) for s in (BASE/'ridge_search_results.jsonl').read_text().splitlines()]
    assert len(inputs)<=48
    totals=dict(fields=0,systems=0,PD=0,not_PD=0,exact_negative=0,direct_cross_checks=0,bandtests=0,polygons=0)
    best=None; negative=None
    with (BASE/'independent_mean_results.jsonl').open('w') as out:
        for inp in inputs:
            if time.perf_counter()-start>180:
                totals['termination']='180-second between-field cap'; break
            if inp['status']=='cap_exceeded':continue
            cells,stats=compose(parse_steps(inp['input']['steps'])); m=moments(cells)
            totals['fields']+=1; totals['polygons']+=len(cells); totals['bandtests']+=stats['bandtests']
            for k in KS:
                result=exact_independent_minimum(m['atoms'],k); totals['systems']+=1
                record=dict(index=inp['index'],k=k,status=result['status'],pivots=result['pivots'])
                if result['status']=='exact_PD_minimum':
                    totals['PD']+=1
                    record.update(A=result['A'],minimum_gap=result['minimum_gap'],moment_ratio=result['moment_ratio'])
                    if inp['index']==0 or result['minimum_gap']<0:
                        direct=direct_independent_gap(m['atoms'],k,result['A']); totals['direct_cross_checks']+=1
                        assert direct==result['minimum_gap']; record['direct_check']=direct
                    if best is None or result['moment_ratio']>best['result']['moment_ratio']:
                        best=dict(index=inp['index'],k=k,input=inp['input'],result=result,stats=stats)
                    if result['minimum_gap']<0:
                        totals['exact_negative']+=1
                        negative=dict(index=inp['index'],k=k,input=inp['input'],result=result,stats=stats)
                        (BASE/'independent_mean_negative_certificate.json').write_text(json.dumps(serial(negative),indent=2)+'\n')
                else:totals['not_PD']+=1
                out.write(json.dumps(serial(record))+'\n'); out.flush()
                if negative:break
            if totals['fields']%8==0 or negative:
                print(json.dumps(dict(fields=totals['fields'],systems=totals['systems'],seconds=time.perf_counter()-start,
                                      largest_ratio=float(best['result']['moment_ratio']) if best else None,
                                      negative=negative is not None)),flush=True)
            if negative:
                totals['termination']='exact negative';break
        else:totals['termination']='stored-field budget exhausted'
    totals['seconds']=time.perf_counter()-start
    summary=dict(budget=dict(fields=48,parameters=[str(k) for k in KS],exact_systems=192,
                            between_field_wall_seconds=180,geometry_caps='same as ridge_composition.py'),
                 totals=totals,best=best,negative=negative)
    (BASE/'independent_mean_summary.json').write_text(json.dumps(serial(summary),indent=2)+'\n')
    print(json.dumps(serial(totals)),flush=True)

if __name__=='__main__':run()
