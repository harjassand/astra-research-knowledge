# A quasiconvex block from two compatible scalar projections

## Proven scope

The result below is a full-vector-gradient quasiconvexity theorem for a
specified finite block. It uses the accepted scalar projection entropy and
contact statements separately on the two row potentials. No compatibility
claim for a pointwise matrix inverse or coupled vector projection is used.

This block has not been shown to be a minorant touching the original J_k.
No representation of J_k and no bridge covering its remaining parameter
range is asserted. No infinite-scale integral is asserted here.

## 1. Data and definition

Let K1,K2 be compact convex subsets of R^2 with nonempty interiors. They need
not contain zero. Let g1,g2:R^2->R be differentiable convex functions, and
let c0 be any real constant. Write the rows of a matrix Z as z1,z2, and set

\[
K=K_1\times K_2\subset\mathbb R^{2\times2},
\qquad g(Z)=g_1(z_1)+g_2(z_2).
\]

The boundary here is the full four-dimensional boundary

\[
\partial K=(\partial K_1\times K_2)\cup(K_1\times\partial K_2).
\]

Define

\[
E(F)=\sup_{Z\in\partial K}
\left[c_0\det Z+Dg(Z):(F-Z)\right],
\tag{1}
\]

and

\[
f(F)=
\begin{cases}
\max\{E(F),c_0\det F\},&F\in K,\\
E(F),&F\notin K.
\end{cases}
\tag{2}
\]

### Theorem

The function f is globally Lipschitz and quasiconvex. In particular, for every
constant real matrix A and every real periodic vector potential
phi in W^(1,4)(T^2;R^2),

\[
\int_{\mathbb T^2}f(A+D\phi)\,dx\ge f(A).
\tag{3}
\]

The ordinary compactly supported formulation is equivalent, with the
approximation described in Section 6. Since f is globally Lipschitz, the
periodic inequality also extends by density to W^(1,1) potentials.

## 2. Continuity and growth

A finite differentiable convex function on R^2 has continuous derivative.
Thus Dg is continuous and bounded on the compact set K. Put

\[
M=\max_{Z\in\partial K}|Dg(Z)|,
\qquad R=\max_{Z\in K}|Z|.
\]

Equation (1) is a supremum of affine functions with slopes of norm at most
M. Hence E is finite, convex, and globally M-Lipschitz.

At F in boundary K one may choose Z=F in (1), giving

\[
E(F)\ge c_0\det F.
\tag{4}
\]

Therefore the two definitions in (2) agree continuously at the boundary.
Inside K, the determinant is R-Lipschitz, since K is convex and
|cof F|=|F| in dimension two. Consequently f is
L=max(M,|c0|R)-Lipschitz inside K and M-Lipschitz outside K. Any line segment
meets the convex set K in an interval; splitting the segment at its entry
and exit points and using (4) proves the same global L-Lipschitz bound.
In particular,

\[
|f(F)|\le |f(0)|+L|F|.
\tag{5}
\]

No sign condition on c0 or homogeneity condition on g_i is needed.

## 3. The accepted scalar ingredients and the compatible product projection

For row i, write the affine-periodic scalar input as

\[
v_i(x)=A_i\cdot x+\phi_i(x).
\]

When A_i belongs to K_i, project its periodic part in L2 onto the set of
affine-periodic scalar w_i with the same affine mean A_i and Dw_i in K_i
almost everywhere. Fixing the periodic part's mean removes the irrelevant
additive constant. This set is nonempty because the affine map is feasible.
It is convex and closed in L2: bounded gradients and the fixed mean give
compactness, and the pointwise convex constraint passes to weak gradient
limits. Thus the Hilbert projection exists and is unique.

The two accepted scalar conclusions used are

\[
\int Dg_i(Dw_i)\cdot(Dv_i-Dw_i)\,dx\ge0,
\tag{6}
\]

and, almost everywhere,

\[
Dw_i=Dv_i\quad\hbox{or}\quad Dw_i\in\partial K_i.
\tag{7}
\]

Now set w=(w1,w2), Z=Dw, and F=Dv=A+Dphi. This is a genuine compatible
vector gradient with affine mean A. Adding (6) for the two rows gives

\[
\int Dg(Z):(F-Z)\,dx\ge0.
\tag{8}
\]

If Z is not in boundary K, both rows are in the interiors of their sets.
Then (7) forces both rows to agree with F. Hence the product contact
statement is

\[
Z=F\quad\hbox{or}\quad Z\in\partial K
\qquad\text{almost everywhere}.
\tag{9}
\]

This is obtained from two scalar contacts. It is not an assumed contact
theorem for a coupled vector projection.

## 4. Exact determinant pairing

Write w=Ax+chi with periodic chi. The projected row gradients are bounded,
so chi belongs to W^(1,infinity). The two-dimensional determinant expansion
is

\[
\det Dw=\det A+\operatorname{cof}A:D\chi+\det D\chi.
\]

The linear term integrates to zero. Periodic integration by parts gives
integral det Dchi=0 for smooth chi; convolution and strong W^(1,2)
convergence give the same identity for the projected Lipschitz map.
Therefore

\[
\int_{\mathbb T^2}\det Z\,dx=\det A.
\tag{10}
\]

Both rows in (10) are projected compatible rows. No mixed original/projected
row determinant is silently discarded.

## 5. Proof of the all-mean inequality

There are two cases.

**Case 1: f(A)=E(A).** This includes every mean outside K, every boundary
mean by (4), and all interior means where E is the active branch. Since
f>=E everywhere and E is convex,

\[
\int f(A+D\phi)\ge\int E(A+D\phi)\ge E(A)=f(A).
\]

**Case 2: f(A)=c0 det A>E(A).** Then A is in the interior of K, so both
scalar projections in Section 3 are feasible. Pointwise contact gives

\[
f(F)\ge c_0\det Z+Dg(Z):(F-Z).
\tag{11}
\]

Indeed, if Z is on boundary K, (11) follows by choosing this Z in (1) and
using f>=E. Otherwise Z=F, and the interior determinant branch in (2)
gives (11), with zero tangent term.

Integrating (11), then applying (8) and (10), yields

\[
\int f(A+D\phi)\ge c_0\det A=f(A).
\]

Ties between the two branches were already covered by Case 1. This proves
the theorem for every affine mean, amplitude, and compatible vector
gradient in the stated class.

## 6. Approximation and compactly supported tests

The projection argument can first be applied to smooth periodic inputs.
For periodic W^(1,4) phi, take smooth periodic convolution approximations
phi_N converging strongly in W^(1,4). By global Lipschitz continuity,

\[
\left|\int f(A+D\phi_N)-\int f(A+D\phi)\right|
\le L\|D\phi_N-D\phi\|_{L^1}\longrightarrow0.
\]

Thus no stronger regularity or amplitude bound is hidden in (3). The same
argument gives the W^(1,1) extension.

For a compactly supported test in an arbitrary bounded domain, extend it
by zero to a containing square. Rescale the square to the unit torus,
apply (3), and subtract the constant exterior contribution. Zero-trace
W^(1,4) tests follow by their standard strong smooth approximation and the
same Lipschitz estimate.

Conversely, starting with the compact-support inequality, take a smooth
periodic phi, tile it on a square of side N, and multiply by a cutoff equal
to one outside a boundary strip of fixed width and zero near the square's
boundary. The cutoff gradient, phi, and Dphi are bounded independently of
N. By (5), the strip contributes O(N), while the tiled interior has area
N^2+O(N). Divide the compact-support inequality by N^2 and let N tend to
infinity. Finally use periodic convolution for W^(1,4) inputs. This proves
the usual equivalence of the two formulations for this block.

## 7. Relation to the original quartic task

The theorem gives a paid simultaneous two-input projection operation.
The scalar entropy resource for row one and the scalar entropy resource
for row two are used once each; the full projected determinant is paired
exactly. The construction does not spend the constitutive companion's
reserve a second time.

No parameters K_i,g_i,c0 have been found for which this finite block or a
proved combination gives an original-J_k touching minorant. The accepted
finite-block touching obstruction at I remains in force. This note makes
no infinite-scale claim: for the present product-row envelope,

\[
E(0)=\sup_{Z\in\partial K}[c_0\det Z-Dg(Z):Z],
\]

so endpoint cancellation would require a separate argument for chosen
data. It is not automatic from the finite theorem.

No new external source was retrieved in this branch. The new reported hold
at https://dspace.uevora.pt/rdpc/handle/10174/3201 remains in force; no retry,
mirror, or alternate recovery was attempted.
