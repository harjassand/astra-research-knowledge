CURRENT LARGE-PARAMETER CONTINUATION — FULL LOWER RANGE UNRESOLVED

Read LARGE_PARAMETER_CONTINUATION_RESULTS.txt first. This continuation proves
the original all-mean, all-gradient inequality with c_G/9 reserve for every
k>=780(41+12C0)^2, where C0 is the precisely defined finite universal scalar
interpolation constant. It also proves that the optimal universal relative
reserve tends to 1/3 as k tends to infinity. No decimal value of C0 is assumed.
The complete analytic proof, exact seven-identity check, and independent
review are in sharp_operator_continuation/. All source changes and periodic
approximation passages are included.

The lower interval 1/3<k<780(41+12C0)^2 remains unresolved by this work. No
compatible negative original-energy witness is asserted. The bounded new
ridge-composition search and exact all-mean checks for 48 fixed potentials at
four parameters are in construction_sharp_continuation/. These positive
fixed-field checks are not substituted for a universal theorem.

projection_sharp_continuation/ records a complete two-row compatible
projection-block theorem, including contact, both work terms, determinant
pairing, global Lipschitz continuity and approximation. No representation or
touching minorant for the original J_k was obtained from that block.

The records below preserve the earlier stages and their accepted capital.

PREVIOUS NONLINEAR AND GLOBAL-MEAN CONTINUATION — ENDPOINT UNRESOLVED

Read NONLINEAR_AND_GLOBAL_MEAN_CONTINUATION.txt first. This continuation records
an exact convex-generator feasibility classification, a sharp outer-affine
support criterion including variable Jacobians, all-mean/all-parameter
certificates for two actual polygon fields, exact coupled-lift and DSOS
exclusions, paid nonlinear pressure calculations, and a quantitative radial
reserve with its W1,4 centre passage. No full original-density proof or
compatible negative original gap is asserted. The earlier qualitative smooth
radial telescoping argument remains credited as prior work.

New detailed notes are in construction_global_continuation/,
projection_global_continuation/, moment_coupled_lift/, and
moment_convexflow_dsos/. Every computational exclusion has its restricted
scope stated; failed certificates are not quasiconvexity counterexamples.
The records below preserve the earlier stages and their accepted capital.

PREVIOUS GLOBAL CONTINUATION — ORIGINAL FULL ENDPOINT STILL UNRESOLVED

Start with GLOBAL_CONTINUATION_RESULTS.txt for the new mixed weighted-minor
estimate, uniform small-Jacobian theorem, exact Poisson-flow obstruction,
compatible generating-function interface, and paid principal/radial work.
The three global-continuation directories contain proofs, exact verifiers,
source receipts and bounded exploratory logs. The original density is used
throughout. No compatible negative gap or full positive proof is asserted.

ORIGINAL QUARTIC GLOBAL QUASICONVEXITY — RESEARCH RETURN
10 November 2026, Australia/Brisbane

STATUS

The full question is unresolved by this work. No proof of the universal
inequality and no admissible negative quasiconvexity witness is asserted.
The exact heat-flow example below is a counterexample to a proposed proof
method, not to the requested inequality. No historical novelty claim is made.

LATEST CONTINUATION

Read CONTINUATION_RESULTS.txt first for the continuation following the expanded
accepted capital. It establishes a nonsharp uniform all-background cubic bound,
a relative L4 neighborhood of every one-direction compatible field with a radius
depending only on k, and an exact four-square translated-Hessian identity.
The neighborhood is uniform in source direction, frequency, concentration,
amplitude and affine mean. It still does not include every compatible field.
The previous heat/support obstructions below are retained as earlier capital,
not presented as the latest result. Complete new proofs and verifiers are in
continuation/. No negative original-energy witness has been obtained.

The original density is used throughout:

  ell=3k-1, n=k+1, m=3k+1, k>1/3,
  u=|F_col1|^2, v=|F_col2|^2, j=det F,
  J_k(F)=ell(ku-v+2j)^2/(8n)+ell uv/4+j^2.

The outstanding assertion is

  integral_T2 J_k(A+Dphi) >= J_k(A)

for every admissible real k, every real 2x2 A, and every real periodic
phi in W^{1,4}(T2;R2), on the unit torus. The supplied adapted-Hessian,
constitutive-companion, singular-background, and local results remain accepted
at their stated scopes. None is relabelled as the full endpoint here.

WHAT WAS ESTABLISHED

1. An explicit smooth compatible field makes J_k-energy increase under every
   constant positive-definite spatial heat flow at k=17/50. Consequently no
   exact-two-form certificate of the proposed heat-dissipation type exists
   there, even allowing arbitrary smooth exact forms. The same obstruction
   holds on the interval 1/3<k<=17/50.

2. Every J_k is nonpolyconvex. More precisely, it has no local affine support
   in (F,det F) at F=I. Subtracting any positive multiple of det(F)^2 also
   destroys rank-one convexity. These are algebraic obstructions to certain
   proofs; they are not negative quasiconvexity results.

3. All affine means can be eliminated exactly. The full question is equivalent
   to positivity of a specified 5x5 moment matrix for every compatible gradient.
   Singular integrated Hessians are included without an inverse assumption.

4. If any strict counterexample exists, one exists at rational k and rational A
   with a finite rational trigonometric potential. Its energy gap is a rational
   constant Fourier coefficient and can be certified exactly. A complete
   negative semidecision is therefore available, with no positive termination
   claim. The packet supplies exact verification and exact mean minimization.

5. A generalized scalar projection inequality and homogeneous quasiconvex
   scale integrals were derived. No representation or touching minorant for
   the original J_k was obtained. Their precise limits are documented.

6. Further continuation rules out universal entropy monotonicity under fixed
   constant-coefficient strongly parabolic systems at k=17/50, including
   coupling of the two output components. This is a stronger limitation of
   linear evolution proofs, not a quasiconvexity counterexample.

7. A restricted positive theorem holds for every constant-determinant
   compatible field when k>=1. It does not cover the full parameter range or
   arbitrary determinant fluctuations.

THE HEAT OBSTRUCTION

Put theta=2*pi*x, eta=2*pi*y, k=17/50, A=0, and

  phi=(1/(2*pi)) *
       ( cos(theta)+cos(eta),
         (cos(2theta)+cos(2eta))/5 + cos(theta)cos(eta) ).

This is a smooth periodic vector potential. Its gradient is compatible by
construction. For normalized ordinary heat flow

  partial_s phi=(2*pi)^(-2) Delta phi,

the exact original energy E(s)=integral J_k(Dphi_s) satisfies

  E(0)  = 504146101/53600000000 > 0,
  E'(0) = 142704373/6700000000  > 0.

A transparent moment calculation uses

  psi=(a(cos theta+cos eta),
       (p/4)(cos 2theta+cos 2eta)+q cos theta cos eta),
  phi=psi/(2*pi),

at (a,p,q)=(1,4/5,1), with a'=-a, p'=-4p, q'=-2q. If
U=integral u^2=integral v^2, V=integral uv, D=integral j^2, then

            value             normalized heat derivative
  U         44009/40000       -36343/5000
  V         22281/40000       -18687/5000
  D         1/200              1/20

The cross moments integral uj and integral vj are zero. The energy is exactly

  E=ell(k^2+1)U/(8n)+ell V/(4n)+(5k+1)D/(2n).

For the stronger anisotropic statement, the first-variation matrix in the
theta,eta coordinates is

  M = diag(188732971/13400000000, 3867031/536000000) > 0.

For every constant symmetric positive-definite spatial matrix C,

  integral sum_ij C_ij D^2J_k(F)[partial_xi F,partial_xj F]
       = -(2*pi)^2 trace(C M) < 0.

Every exact two-form omega on matrix space has zero integrated pullback by
F:T2->R^4. Adding such a pullback therefore cannot make this dissipation
nonnegative for all compatible jets. This is a proof of impossibility of the
specified certificate, not an unsuccessful numerical search for coefficients.

Since A=0 and J_k is nonnegative pointwise, this field is not a negative
quasiconvexity witness. An energy can increase during a particular evolution
while remaining above its affine reference value. See heat_obstruction.txt
for the general-k first-variation formulas and the interval argument.

NO LOCAL DETERMINANT-AFFINE SUPPORT

If an affine support in (F,det F) touched J_k at I, differentiability would
force its inequality to have the form

  J_k(I+E)-J_k(I)-DJ_k(I):E-lambda det E >= 0.

The unique lambda for which its quadratic term can be nonnegative is

  lambda=3n/2.

For this value the quadratic term is

  ((m E11+2 E22)^2 + ell n E21^2)/4.

Set D0=diag(2,-m). The exact remainder is

  J_k(I+tD0)-J_k(I)-t DJ_k(I):D0-(3n/2)det(tD0)
      = -2n ell t^3 + J_k(D0)t^4,

where

  J_k(D0)=n(243k^3+405k^2+129k-1)/8 > 0.

Thus it is negative whenever 0<t<2n ell/J_k(D0), including arbitrarily small
t. No different multiplier repairs it, because every other multiplier already
fails the quadratic test. This is a local support obstruction for every k.

For completeness, a finite-valued polyconvex function on all 2x2 matrices
does admit an affine support in (F,det F): any convex representing function
is finite on the determinant graph, whose convex hull is all R^5, hence is
finite and has a subgradient at every point. This explains the implication
from the support calculation to nonpolyconvexity without assuming a smooth
convex representing function.

For a separate exact boundary property, put

  E_epsilon=[[epsilon,1],[-m epsilon^2/2,-m epsilon/2]].

This matrix has rank one, and at I

  D^2J_k[E_epsilon,E_epsilon]=ell n m^2 epsilon^4/8,
  D^2(det^2)[E_epsilon,E_epsilon]=ell^2 epsilon^2/2.

Consequently J_k-delta det^2 is not rank-one convex for any delta>0. One
cannot first set aside a positive det^2 reserve and ask a rank-one-convex
remainder to carry the rest. The accepted convex companion has not been
substituted for J_k or spent a second time.

Additional exact geometry in family_geometry.txt classifies every nonzero
Legendre-Hadamard zero pair, proves J_k(F B_k)=k^2 J_k(F) for
B_k=[[0,k],[1,0]], and proves a restricted parameter-rigidity theorem:
if J_k-c J_h(LFR) is C^2 rank-one convex with c>0 and L,R invertible, then h=k.
The rigidity theorem is not asserted for arbitrary nonlinear, nonlocal, or
singular limiting representations.

THE EXACT REMAINING MOMENT INEQUALITY

For a fixed compatible G=Dphi, write matrices in row-major coordinates and set

  c_G=integral J_k(G),
  b_G=integral DJ_k(G),
  H_G=integral D^2J_k(G).

Quartic polarization and integral G=0 give

  integral J_k(A+G)-J_k(A)=c_G+b_G:A+(1/2)A:H_G A.

Therefore the all-A assertion for this one G is equivalent to

  M_G=[[2c_G,b_G^T],[b_G,H_G]] >= 0.

Indeed the energy gap is (1/2)(1,A)^T M_G(1,A). Conversely, positivity for
every A gives positivity on every vector (t,X) with t nonzero by homogeneity;
continuity supplies t=0. This argument covers singular matrices directly.

The accepted Legendre-Hadamard property implies H_G>=0. Equivalently, the
remaining conditions can be written

  b_G in range H_G,
  b_G^T H_G^dagger b_G <= 2c_G.

These are an exact reformulation, not an established estimate. The field G
still ranges over all compatible vector gradients, all amplitudes, and all
frequencies. The small size of M_G does not make that quantifier finite.

RATIONAL WITNESSES AND COMPACT SUPPORT

Any strict violation can be approximated, while preserving its negative
margin, by rational k>1/3, rational A, and a finite potential

  phi=(1/(2*pi))*sum_q [alpha_q sin(2*pi*q.x)
                        +beta_q cos(2*pi*q.x)],

with integer q and rational vectors alpha_q,beta_q. Periodic convolution,
finite Fourier approximation, and rational coefficient approximation converge
strongly in W^{1,4}. Polynomial fourth-order growth gives continuity of the
integral. The notes give explicit constants for this step.

The factor 1/(2*pi) disappears from Dphi. Its Fourier coefficients are Gaussian
rationals, and the energy gap is the exact constant coefficient of a finite
Laurent polynomial. The finite checks use no real-number oracle, numerical
quadrature, approximate value of pi, optimization oracle, or PDE solver.

Enumerating rational k and these potentials, and minimizing over A by rational
linear algebra, is a complete negative semidecision: it halts if a strict
counterexample exists. No bound on the search depth and no termination in the
positive case is proved or asserted. The packet implements each finite check;
it does not pretend to have completed the infinite enumeration.

The periodic and usual compact-support formulations are equivalent here.
A smooth compactly supported map extends by zero to a periodic one. In the
other direction, start with a smooth periodic gap -delta, tile it over an
N-by-N square, and cut off only a boundary strip of fixed width. The negative
interior contribution has order N^2; the explicitly bounded boundary cost has
order N. Rescaling and mollifying then produce a smooth compactly supported
negative witness with a paid margin. mean_and_fourier_reduction.txt gives
explicit rational choices of N and of the mollifier radius, retaining a gap
less than -delta/4. Thus no incompatible arbitrary matrix-field test is used.

PROJECTION WORK AND LITERATURE SCOPE

The supplied Agazzi et al. paper was successfully read at its exact URL:

  https://arxiv.org/html/2609.28311v2

Its Theorem 1, Corollary 2, and scalar projection argument give the stated
Burkholder and Beurling-Ahlfors results. Those results do not by themselves
identify the present J_k, and they have not been presented as new here.

projection_notes.txt proves a useful extension of the scalar work inequality:
if w is the L2 projection of an affine-periodic scalar v onto gradients in a
compact convex K, then for every differentiable convex g,

  integral Dg(Dw).(Dv-Dw) >= 0.

The proof uses variational resolvents with proved existence, scalar comparison,
preservation of directional increment bounds, and convergence. It assumes no
PDE oracle. This produces quasiconvex projection blocks and infinite-scale
homogeneous quartic functions. The finite-block representations are excluded
by the local support calculation above, and no infinite-scale representation
of J_k was obtained. This is useful auxiliary mathematics, not closure of the
original question and not a claim of historical novelty.

The continuation examined constant-determinant maps more directly. The exact
restricted k>=1 proof is in constant_determinant_result.txt. For lower k a
three-matrix measure with determinant one and barycenter I violates matrix
Jensen, excluding matched projection-block representations with convex
extensions on determinant slices. No gradient realization of that measure
was established; it is not a compatible counterexample.

The further mixed-coordinate reduction in mixed_coordinate_reduction.txt
assumes det Df=1, mean I, and the genuine global twist condition partial_2 f_2>0.
For a periodic scalar h, it produces P=h_ss, Q=1+h_st>0, R=h_tt and

  F=Q^(-1)[[Q^2-PR,R],[-P,1]],  dx1 dx2=Q ds dt.

The weight Q is retained. The resulting scalar-Hessian inequality is written
explicitly, but is not proved. One natural closed two-form correction fails
an exact compatible-jet test. Neither the twist restriction nor arbitrary
determinant variation is removed by this representation.

The stronger obstruction to constant target-coupled entropy systems is in
constant_system_obstruction.txt. Symmetry averaging reduces a hypothetical
universal generator to a partial_xx+c partial_yy+2b R90 partial_xy. The exact
acoustic degeneracy at I forces b=0, while the already verified heat example
contradicts every remaining a,c>0. This statement is about a single constant
generator universal over all means; it does not exclude mean-dependent or
nonlinear procedures, nonlocal multipliers, or direct endpoint inequalities.

Source-access restrictions were retained. The exact Bruno-Pasqualotto HTML
and exact Pedregal HTML failed on their first opens and were not retried via
other versions or routes. Pedregal's Section 7 therefore remains unread here;
no diagnosis of its proof or claim of a general Morrey theorem is made.
One additional Ball PDF failed a size limit on its first open and was also
left held. SOURCE_ACCESS.txt records these outcomes. No protected researcher,
held archive, native Astra retrieval, new account, external model, installation,
or additional hardware was used.

HOW TO REPRODUCE THE FINITE CALCULATIONS

The following scripts use only the Python standard library:

  python verify_results.py
  python exact_fourier_gap.py examples/heat_obstruction.json
  python exact_mean_gap.py examples/shear_with_cubic_moment.json

verify_results.py checks the exact heat energy, every entry of its first-
variation matrix, an independent moment formula for its trace, and a singular
integrated-Hessian example with a nonzero cubic moment. The latter returns
rank(H)=3, b=(0,1/4,1/4,0), a minimizing A=[[0,-3/13],[0,0]], and positive
gap 2485/22464. These are implementation checks, not positivity evidence for
the universal assertion.

Input uses rational strings, not binary floating-point coefficients. The
potential is always built from actual sine/cosine vector modes. The exact
mean minimizer checks every principal minor of H, handles a failed range
condition, and verifies its returned affine mean by full Fourier evaluation.

verify_family_symbolic.py uses the already available SymPy library for optional
symbolic checks of the all-k identities. The mathematical identities and their
proofs are also written out in family_geometry.txt; they do not depend on an
unreported numerical positivity test.

verify_continuation_symbolic.py checks the additional acoustic identity and
the failed mixed-coordinate two-form candidate. fixed_det_projection_obstruction.py
checks the separate finite matrix measure using Fraction arithmetic; its
output explicitly disclaims a compatible-gradient realization. Exploratory
numerical scripts and their bounded output records are in exploratory/ and
carry no rigorous sign conclusion.

No negative quasiconvexity witness is contained in this packet. The required
new step is still a proof of M_G>=0 for every compatible G, or an exact
compatible field for which it fails.
