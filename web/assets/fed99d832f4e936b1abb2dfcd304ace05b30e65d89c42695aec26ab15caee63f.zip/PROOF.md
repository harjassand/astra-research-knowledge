# A cubic spectral criterion for sampling lossy Gaussian optical networks

**Research date:** 7 October 2026.  
**Status:** candidate theorem with a written derivation, exact finite diagnostics, and a floating-point prototype. No external review, formal proof, certified floating-point implementation, or historical-priority clearance is claimed.

## Abstract

We give a covariance-based error certificate for the centered Gaussian reset sampler of Lim [L26]. Applied to bounded, not necessarily equal, input squeezing and an arbitrary passive vacuum-loss network with transmission matrix T, the certificate bounds total-variation error by a constant times Tr[(T* T)^3]. Loss may be interleaved with mode mixing. The new algebraic step is a passive Schur-complement identity under the fractional-linear no-click flow. It produces a matrix-valued shift without assuming that the shift and covariance commute. A trace Lyapunov argument then controls both accumulated reset error and rare large-covariance trajectories. For independent equally squeezed modes, the cubic spectral scale is necessary for vanishing worst-case error of this particular reset sampler. It is not a lower bound on all classical simulation algorithms.

The sampler, its optical trajectory representation, the original uniform-loss cubic exponent, the stopping-time strategy, and the single-mode sharpness coefficients are inherited from [L26]. The proposed contribution is the matrix-shift extension, its application to general passive loss, the sum-of-cubes bound, and the resulting covariance-only certificate. The Schur-complement identities use standard matrix algebra; no historical priority is claimed for those identities in isolation.

## 1. Main statement

Let N input modes be squeezed vacua with magnitudes 0 <= r_j <= r_max < infinity. All other inputs and all loss environments are vacuum. Squeezing phases are absorbed into the columns of the transmission matrix. Let

\[
T:\mathbb C^N\longrightarrow\mathbb C^M,\qquad T^*T\preceq I,
\]

be the known input-to-output complex amplitude map of the entire passive circuit, including loss wherever it occurs. Let P_T be the joint photon-number distribution at its M outputs, and let Q_T be the **ideal real-arithmetic** distribution of the centered reset algorithm in Section 2, initialized at the exact output covariance. Write

\[
\nu_j=s_j(T)^2,\quad \eta_*=\max_j\nu_j,\quad
S_3(T)=\operatorname{Tr}[(T^*T)^3]=\sum_j\nu_j^3.
\]

The nu_j are power transmissions, not amplitude singular values.

**Theorem 1 (candidate).** There is a constant depending only on r_max such that

\[
\operatorname{TV}(P_T,Q_T)
\le \min\{1,C(r_{\max})S_3(T)\}.
\tag{1}
\]

One conservative choice is

\[
p=\sinh^2r_{\max}+\sinh r_{\max}\cosh r_{\max},\qquad
C(r_{\max})=\max\left\{1000,\frac{10368}{25}p^2\left(p+\frac{10}{9}\right)\right\}.
\tag{2}
\]

This includes rectangular and rank-deficient T, unequal squeezing, arbitrary phases, and photon collisions. It does not include heralded/postselected states, active operations interleaved with the loss network, arbitrary non-Gaussian inputs, or a claim of efficient acquisition of T. Vacuum columns may be deleted; retaining them only weakens (1).

The expected number of reset events is at most the true initial mean photon number

\[
E_0=\operatorname{Tr}[T\operatorname{diag}(\sinh^2r_j)T^*].
\tag{3}
\]

The algorithm has polynomial expected arithmetic cost, with scalar survival inversion charged explicitly. A later, proof-level rational-input compilation corollary is supplied separately in `BIT_COMPILER.md`: it gives a stopped finite-bit sampler with additive numerical error and a larger conservative constant. The floating-point prototype is not certified by that corollary.

### A state-dependent certificate

All matrices below are real quadrature matrices; the vacuum covariance is I/2. Fix an orthogonal complex structure J and the passive projection

\[
\mathcal P(A)=\tfrac12(A+JAJ^T).
\]

For a centered Gaussian covariance Sigma_0=I/2+K_0, put R=mathcal P(K_0), X=K_0-R. Assume R is strictly positive on a complex-linear active support; omit unused vacuum directions. Define

\[
D=XR^{-1}X-R.
\tag{4}
\]

**Theorem 2 (candidate covariance certificate).** If D <= I/10, set

\[
B=\left[D(I-D)^{-1}\right]_+,
\qquad \Phi_0=\operatorname{Tr}[(K_0+B)K_0^2].
\]

Then the same sampler satisfies

\[
\operatorname{TV}(P_{K_0},Q_{K_0})
\le \min\{1,(5184/25)\Phi_0\}.
\tag{5}
\]

The positive part is a canonical choice, not an assertion of a least positive upper bound in the Loewner order. The certificate can be uninformative on some easily simulable states, including strong classical thermal states. It is not a characterization of optimal classical simulability.

## 2. The inherited centered reset process

The photon-counting unraveling and covariance reset are those of [L26, Supplement SII A]. Let Pi_i select the q_i,p_i quadratures of output i. Between detections,

\[
\dot K=-K-K^2,\qquad
F_t(K)=vK[I+(1-v)K]^{-1},\quad v=e^{-t}.
\tag{6}
\]

The survival probability for no detection over duration t is

\[
S_K(t)=\det[I+(1-e^{-t})K]^{-1/2}.
\tag{7}
\]

At a detection in mode i, the rate and reset are

\[
\lambda_i=\tfrac12\operatorname{Tr}(\Pi_iK),\qquad
\Delta_i=K\Pi_iK/\lambda_i,\qquad K\longmapsto K+\Delta_i.
\tag{8}
\]

The increment is positive semidefinite and has rank at most two. A zero-rate mode is not chosen; physicality implies K Pi_i=0 in that case, so its contribution is defined as zero. The identities give

\[
\sum_i\lambda_i\Delta_i=K^2.
\tag{9}
\]

To sample, terminate with probability det(I+K)^(-1/2). Otherwise draw the next time by inversion of (7), choose the mode proportionally to its rate at that time, and apply (8). The algorithm has no photon-number cutoff. The Gaussian reset preserves the first two moments of the exact centered photon-subtracted state, but not that state itself.

Every state used by this sampler is physical: no-click evolution preserves Gaussian physicality, and adding Delta corresponds to additive Gaussian displacement noise. The flow in (6) is operator monotone on its physical domain. Therefore every trajectory satisfies

\[
K_t\succeq F_t(K_0).
\tag{10}
\]

## 3. The passive Schur-complement flow

This is the decisive extension beyond a scalar shift.

**Lemma 3.** Suppose R>0, JRJ^T=R, JXJ^T=-X, and D=XR^(-1)X-R has largest eigenvalue strictly below one. Put K=R+X and

\[
H_u=K(I+uK)^{-1},\quad R_u=\mathcal P(H_u),\quad X_u=H_u-R_u,
\qquad 0\le u\le1.
\]

Then R_u>0 and

\[
X_uR_u^{-1}X_u-R_u=D(I-uD)^{-1}.
\tag{11}
\]

**Proof.** The matrix D is passive. If d=max{0,lambda_max(D)}, the block matrix

\[
\begin{pmatrix}R&X\\X&R+dI\end{pmatrix}\succeq0
\]

follows by taking the Schur complement in R. Testing it on (z,z) and (z,-z) gives R +/- X >= -dI/2. Thus I+uK and I+u(R-X) are positive definite.

For an invertible passive A and odd X for which the indicated inverses exist, block inversion gives

\[
\tfrac12[(A+X)^{-1}+(A-X)^{-1}]
=(A-XA^{-1}X)^{-1}.
\tag{12}
\]

For u>0, apply this to A=I+uR and uX. The strict Schur inequality I-uD>0 implies

\[
R-uX(I+uR)^{-1}X>0.
\]

Consequently the passive part of (I+uK)^(-1) is strictly below I, and R_u=[I-mathcal P((I+uK)^(-1))]/u is strictly positive. The case u=0 is immediate.

First assume K and D are invertible. Equation (12) with A=R gives

\[
\mathcal P(K^{-1})=(R-XR^{-1}X)^{-1}=-D^{-1}.
\]

Since H_u^(-1)=K^(-1)+uI, a second application to H_u yields

\[
-[X_uR_u^{-1}X_u-R_u]^{-1}=-D^{-1}+uI,
\]

which is (11). The exceptional singular cases follow by continuity: the non-invertible loci are algebraic, the strict inequalities persist under small perturbations, R_u stays positive, and I-uD stays invertible. This continuity argument does not insert an inverse of D into the final formula. QED.

The identity is compatible with noncommuting R and X. It is a matrix Schur-complement calculation, not a simultaneous diagonalization argument.

## 4. A matrix-valued trajectory certificate

Let B>0 be passive and suppose

\[
B\succeq D(I-uD)^{-1}\quad(0\le u\le1).
\tag{13}
\]

Set B_t=e^(-t)B and Y_t=K_t+B_t.

**Lemma 4.** On every trajectory, Y_t>0 on the active support, and for every nonzero-rate detector

\[
\operatorname{Tr}(Y_t^{-1}\Delta_i)\le2,
\qquad 0\preceq\Delta_i\preceq2Y_t.
\tag{14}
\]

**Proof.** For the no-click baseline H_u, let A=R_u+B. By (11) and (13), B >= X_u R_u^(-1) X_u-R_u. The block Schur complement equivalently gives

\[
R_u\succeq X_u(R_u+B)^{-1}X_u.
\]

Therefore A-X_u A^(-1)X_u >= B>0. Both A +/- X_u are positive definite, and (12) implies

\[
\mathcal P[(H_u+B)^{-1}]\preceq B^{-1}.
\]

Because B commutes with J, the matrix

\[
\Gamma_u=-B+B(H_u+B)^{-1}B
\]

has nonpositive passive part. Each Pi_i is passive, so Tr(Pi_i Gamma_u)<=0.

Now write v=e^(-t) and u=1-v. Equation (10) gives Y_t >= v(H_u+B)>0. The following identity is valid without commutation:

\[
K_tY_t^{-1}K_t
=K_t-B_t+B_tY_t^{-1}B_t.
\tag{15}
\]

Inverse monotonicity, (15), and the preceding bound give

\[
\operatorname{Tr}(\Pi_iK_tY_t^{-1}K_t)
\le \operatorname{Tr}(\Pi_iK_t)+v\operatorname{Tr}(\Pi_i\Gamma_u)
\le2\lambda_i.
\]

Divide by lambda_i. The positive matrix Y_t^(-1/2) Delta_i Y_t^(-1/2) has trace at most two, hence operator norm at most two. This proves (14). QED.

Semidefinite B is handled by B+epsilon I, followed by epsilon decreasing to zero on the fixed finite active support. The sampler is unchanged by this regularization: B is only an analytical certificate. In the bounds below one can first use a slightly enlarged norm bound and then pass to the limit, rather than claim the regularized B still obeys an exact boundary norm constraint.

Since f_u(x)=x/(1-ux) is increasing in u for every x<1, a sufficient choice in Theorem 2 is B=[f_1(D)]_+. Its norm is at most 1/9 when D<=I/10.

## 5. How arbitrary optical loss supplies the certificate

Let L be the realification of T and C=LL^T. Delete exactly vacuum input columns first. On ran(L), C and R below are positive definite. Define diagonal input matrices

\[
N_0=\operatorname{diag}(n_j,n_j),\quad
M_0=\operatorname{diag}(m_j,-m_j),\quad
n_j=\sinh^2r_j,\quad m_j=\sinh r_j\cosh r_j.
\]

The paired notation means all q entries followed by all p entries. The output perturbation is

\[
R=LN_0L^T,\quad X=LM_0L^T,\quad K_0=R+X.
\tag{16}
\]

The vacuum environment ensures that the vacuum part remains I/2, even when loss and passive mixing are interleaved [G12, BO20]. This also follows immediately from a_out=T a_in+T_env e and T T*+T_env T_env*=I.

A weighted projection inequality gives

\[
L^T(LN_0L^T)^{-1}L\preceq N_0^{-1}.
\]

Indeed, conjugating by N_0^(1/2) makes the left side an orthogonal projector. Since m_j^2/n_j=n_j+1,

\[
XR^{-1}X
\preceq LM_0N_0^{-1}M_0L^T=R+C,
\qquad D\preceq C.
\tag{17}
\]

No lower bound on the nonzero squeezing magnitudes is used in this inequality.

Suppose eta_*<=1/10. The function f_u(A)=A(I-uA)^(-1) is operator monotone for A<u^(-1)I. Equations (17) and (11) imply

\[
D(I-uD)^{-1}\preceq C(I-uC)^{-1}\preceq C(I-C)^{-1}.
\]

Thus we can use the passive matrix

\[
B=C(I-C)^{-1},\qquad 0\preceq B\preceq\frac{C}{1-\eta_*},
\quad \|B\|\le1/9.
\tag{18}
\]

This B generally does **not** commute with K_0 or a later K_t. Importantly, we do not infer [f_1(D)]_+ <= f_1(C) from D<=C: taking positive parts is not operator monotone. We choose (18) directly instead.

The nonzero eigenvalues of C are the nu_j, each repeated twice. This is where the complete transmission spectrum enters the error estimate.

When L is injective on the nonvacuum input space, the weighted projection above is the identity and (17) is an equality: **D=C**. Thus the attenuation Gram matrix can algebraically be reconstructed from the exact output covariance under pure-input, vacuum-environment, and injectivity assumptions, without first identifying the input squeezing magnitudes. This observation does not supply a finite-sample calibration protocol: estimating R^(-1) can be ill-conditioned, and the calibration prior art has not been cleared. For non-injective maps only D<=C is asserted.

## 6. Noncommuting trace Lyapunov control

Let

\[
\Phi_t=\operatorname{Tr}(Y_tK_t^2)\ge0.
\tag{19}
\]

Positivity uses the trace of a product of two positive matrices, not commutation. Between jumps, dot Y=-Y-K^2. Expanding (19) under the flow and a jump, and using (9), cancels every term linear in the jump increments. The exact generator is

\[
\mathcal G\Phi
=-3\Phi+\sum_i\lambda_i\{
\operatorname{Tr}[(Y+2K)\Delta_i^2]+\operatorname{Tr}\Delta_i^3\}.
\tag{20}
\]

This extends the scalar-shift potential calculation in [L26] to a noncommuting matrix shift. Since K<=Y and 0<=Delta<=2Y,

\[
\operatorname{Tr}[(Y+2K)\Delta^2]+\operatorname{Tr}\Delta^3
\le5\operatorname{Tr}(Y\Delta^2)
\le10\operatorname{Tr}(Y^2\Delta).
\]

For the last inequality, write Delta=2A and Y=A+E with A,E>=0. The difference Tr(Y^2 A)-Tr(Y A^2) equals Tr(A^2E)+Tr(E^2A), which is nonnegative. This avoids the invalid step of squaring a Loewner inequality. Consequently

\[
\mathcal G\Phi\le-3\Phi+10\operatorname{Tr}(Y^2K^2)
\le(-3+10\|Y\|)\Phi.
\tag{21}
\]

Let a=1/4 and tau=inf{t: ||Y_t||>=a}. Before tau, the drift is at most -Phi/2. At a crossing, take a unit eigenvector w of Y with eigenvalue y>=a. Since ||B_t||<=1/9,

\[
\Phi_\tau\ge y\langle w,K^2w\rangle
\ge y\langle w,Kw\rangle^2
\ge a(a-1/9)^2=25/5184.
\tag{22}
\]

Here <w,Kw>=y-<w,B_t w> >= y-1/9 is nonnegative. No joint eigenbasis for B_t and K_t is assumed.

Between jumps, Y decreases in Loewner order; a crossing jump has Y_new<=3Y_old by (14). Thus overshoots are bounded. Stopped localization and Dynkin's formula give

\[
\frac{25}{5184}\Pr(\tau<\infty)
+\frac12\mathbb E\int_0^\tau\Phi_t\,dt\le\Phi_0.
\tag{23}
\]

If tau=0, (22) already makes the final error bound trivial.

## 7. Local trace error and the full record

For a centered Gaussian state rho with covariance Sigma, its exact photon-subtracted state in detector i and the reset Gaussian obey [L26, SII C]

\[
\rho_i^-=(I+\mathcal D_{\Delta_i})\rho,\qquad
\rho_{G,i}=e^{\mathcal D_{\Delta_i}}\rho,
\]

where mathcal D_Delta is the additive-displacement noise generator. A dimension-free, deliberately conservative bound can be reconstructed as follows.

For a centered Gaussian quadrature Q of variance v, expand the fourth commutator and apply Schatten Cauchy--Schwarz to each Q^a rho Q^b. Gaussian moments give

\[
\|\operatorname{ad}_Q^4\rho\|_1\le C_4v^2,
\qquad C_4=2\sqrt{105}+8\sqrt{15}+18<70.
\tag{24}
\]

The five binomial terms give respectively sqrt(105), 4sqrt(15), 18, 4sqrt(15), sqrt(105), times v^2. Wick's rule for commuting displacement derivations gives

\[
\mathcal D_\Delta^2\rho=\tfrac1{12}\mathbb E_{z\sim N(0,\Delta)}
\operatorname{ad}_{Q_z}^4\rho.
\]

The symplectic rotation relating z to Q_z preserves Euclidean norm. If ||Sigma||<=V, then Var(Q_z)<=V||z||^2 and E||z||^4<=(3)(Tr Delta)^2. Taylor's integral remainder and trace-norm contraction of the Gaussian noise semigroup therefore imply

\[
e_i:=\tfrac12\|\rho_i^- -\rho_{G,i}\|_1
\le\frac{C_4}{16}V^2(\operatorname{Tr}\Delta_i)^2.
\tag{25}
\]

Finite Fock projections justify the derivatives; the displayed finite Gaussian moments permit their removal. Equivalently, the stronger established local bound in [L26, Eq. S14] can be used. Equation (25) is included to avoid reliance on the sharp numerical constant of that bound.

Before tau, K<=Y<aI, hence ||Sigma||<=3/4. Also rank Delta<=2 and Delta<=2Y, so

\[
(\operatorname{Tr}\Delta)^2\le2\operatorname{Tr}\Delta^2
\le4\operatorname{Tr}(Y\Delta).
\]

After multiplying by rates and summing with (9),

\[
\sum_i\lambda_i e_i\le\frac{9C_4}{64}\Phi.
\tag{26}
\]

The physical energy E=Tr K/2 is nonnegative and has generator mathcal G E=-E. Localization makes e^t E_t a nonnegative supermartingale. Therefore the expected total number of detections is at most E_0, the probability of a detection after time t is at most E_0 e^(-t), and the process is nonexplosive and terminates almost surely.

For completeness, the record comparison uses candidate-prefix/exact-suffix hybrids, as in [L26, SII D]. Two adjacent hybrids have the same candidate history and next-click probabilities; they differ only by one replacement, whose effect on any later event is at most e_i by trace-distance contraction. First impose a finite time and click cap with an unfinished outcome, sum the hybrid errors, then remove the caps using termination. The same argument stopped at tau, followed by a coupling to the unstopped sampler, gives

\[
\operatorname{TV}(P,Q)
\le\Pr(\tau<\infty)+\mathbb E\int_0^\tau\sum_i\lambda_i e_i\,dt.
\tag{27}
\]

The exact suffix is a comparison device, not an operation performed by the algorithm. Since 9C_4/32 < 5184/25, combining (23), (26), and (27) proves (5).

## 8. Bounding the initial spectral budget

For the optical input (16), let p=max_j(n_j+m_j)<=p(r_max). Polar decomposition of L gives

\[
K_0=C^{1/2}A_0C^{1/2},\qquad \|A_0\|\le p.
\]

Schatten Holder inequalities yield

\[
\operatorname{Tr}|K_0|^3\le p^3\operatorname{Tr}C^3,
\qquad
\operatorname{Tr}(CK_0^2)\le p^2\operatorname{Tr}C^3.
\tag{28}
\]

For the second inequality, use ||C^(1/2) A_0 C||_2 <= ||C^(1/2)||_6 ||A_0||_infinity ||C||_3. This argument does not square a matrix-order bound.

Equation (18) and positivity of K_0^2 give

\[
\begin{split}
\Phi_0
&=\operatorname{Tr}K_0^3+\operatorname{Tr}(BK_0^2)\\
&\le p^2\left(p+\frac1{1-\eta_*}\right)\operatorname{Tr}C^3\\
&\le2p^2\left(p+\frac{10}{9}\right)S_3(T).
\end{split}
\tag{29}
\]

Together with (5), this is (1) for eta_*<=1/10. If eta_*>1/10, then S_3(T)>1/1000 and the constant 1000 gives the trivial bound one. At T=0 or when every r_j=0, the sampler returns vacuum exactly. Deleting zero-squeezing columns can only decrease Tr[(T T*)^3], by positive-matrix eigenvalue monotonicity. This completes the candidate proof of Theorem 1.

## 9. Sharpness for this sampler, not a hardness theorem

Fix r>0 and take independent modes with T=diag(sqrt(nu_j)). The exact distribution and centered sampler both factorize. For one weakly transmitted mode, [L26, SIII B] gives

\[
p_\nu(3)=A_r\nu^3+O_r(\nu^4),\qquad
q_\nu(3)=B_r\nu^3+O_r(\nu^4),
\]

where, with n=sinh^2r and m=sinh r cosh r,

\[
A_r=n^3+\tfrac32nm^2,\qquad
B_r-A_r=2n^3+2n^2+n/3>0.
\tag{30}
\]

The proposed heterogeneous conclusion is an immediate product consequence of these inherited coefficients. Coarse-grain each mode to the event of exactly three counts. Its binary root-affinity has deficit

\[
\tfrac12(\sqrt{B_r}-\sqrt{A_r})^2\nu^3+O_r(\nu^4).
\]

For nu<=nu_0(r), it is at least c(r)nu^3. Affinity tensorizes, and TV is at least one minus affinity. Hence

\[
\operatorname{TV}(P_{\rm diag},Q_{\rm diag})
\ge1-\exp[-c(r)\sum_j\nu_j^3].
\tag{31}
\]

This proves worst-case necessity of S_3 tending to zero for this reset rule in the weak-transmission, fixed-r subclass. Other algorithms may do better. In particular, [L26, SIV] already has a different pair sampler reaching the N^(3/4) mean-count regime under its fully occupied, equally squeezed, uniform-loss assumptions. Equation (31) does not contradict or improve that algorithm.

## 10. Consequences and costs

For source losses followed by a lossless interferometer, T=U diag(sqrt(eta_j)), so (1) becomes C sum eta_j^3. The explicitly stated heterogeneous bound in [L26, SIII A, Eq. S33] is instead C eta_max sum eta_j^2. Our bound is no larger at the level of its spectral functional and can differ asymptotically, although the conservative constants should not be compared as optimized constants.

For example, take eta_1=N^(-1/10), eta_2=...=eta_N=N^(-2/5). Then

\[
\sum_j\eta_j^3\asymp N^{-1/5}\longrightarrow0,
\quad
\eta_{\max}\sum_j\eta_j^2\asymp N^{1/10}\longrightarrow\infty.
\]

Thus the new criterion proves convergence in a family where that source bound becomes uninformative. At fixed common r, the mean count is asymptotic to n N^(3/5). This is an asymptotic example, not a benchmark of a particular device.

For uniform loss, S_3=N eta^3: there is **no improvement** of the general N^(2/3) uniform-loss mean-count exponent. Holder also gives sum nu_j <= N^(2/3) S_3^(1/3).

The algorithm can store an orthonormal basis of the active complex rank d<=min(M,N) and a 2d-dimensional supported covariance. A conservative expected arithmetic count after polynomial preprocessing is

\[
O\big((1+E_0)[d^3+Md^2+d b_{\rm inv}]\big),
\]

with O(Md+d^2) storage. Here b_inv is the number of scalar survival evaluations charged per inversion; an ideal exact inversion may instead be treated as a primitive. This is the ideal arithmetic contract. `BIT_COMPILER.md` separately specifies a buffered, count-capped rational-input compiler with polynomial bit cost and an additive epsilon error. It does not treat arbitrary unacquired real parameters as finite inputs, and its worst-case precision schedule is impractical. The provided dense floating-point implementation is less optimized and has no certified numerical TV guarantee. If a separate numerical analysis proves TV(Q_float,Q_ideal)<=epsilon_num, then the final bound adds epsilon_num. Calibration error in the supplied optical model is another separate cost.

The practical output of this run is therefore a broader **analytical certificate, a proof-level rational-input compilation, and an executable floating prototype**, not a claim that a named experiment has lost quantum advantage.

## References and reading scope

**[L26]** Youngrong Lim, *Classical Simulation of Lossy Gaussian Boson Sampling beyond Square-Root Regime*, arXiv:2610.06526v1, submitted 5 October 2026. Main text and Supplements SII--SV inspected; PDF pages 8--13 (one-based) visually inspected for the decisive formulas. https://arxiv.org/abs/2610.06526 ; https://arxiv.org/html/2610.06526v1 . This is a recent preprint, not an externally validated dependency in this run.

**[G12]** C. Weedbrook et al., *Gaussian quantum information*, Reviews of Modern Physics **84**, 621 (2012), doi:10.1103/RevModPhys.84.621; arXiv:1110.3234. Standard Gaussian state/channel framework, not the proposed spectral result.

**[BO20]** D. J. Brod and M. Oszmaniec, *Classical simulation of linear optics subject to nonuniform losses*, Quantum **4**, 267 (2020), doi:10.22331/q-2020-05-14-267. Primary publication page inspected for neighboring prior art. Its full proof was not re-audited in this run.

See SOURCES_AND_PRIOR_ART.md for the exact repository retrieval scope, priority limitations, and source availability. Mathematical novelty and correctness remain open to independent review.
