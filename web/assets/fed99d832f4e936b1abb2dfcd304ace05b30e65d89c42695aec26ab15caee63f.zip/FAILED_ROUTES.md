# Failed routes, boundary tests, and next technical gates

This file records mathematical obstructions and unresolved interfaces, not a private reasoning transcript. No route is labeled impossible beyond the stated contract.

## 1. Higher-order centered Gaussian resets

Lim 2610.06526v1, Supplement SIII C, gives a local obstruction. The exact centered photon-subtracted characteristic function is (1-a) exp(-b), where a=z^T Delta z/2 and b=z^T Sigma z/2. Any positive mixture of **centered** Gaussians with the matched covariance has characteristic function at least exp(-a-b) by Jensen. Their difference is second order in a. Thus merely mixing centered covariance resets cannot cancel the leading local error within that matched-moment class.

This does NOT exclude displaced Gaussian mixtures, signed representations with controlled sampling overhead, non-Gaussian retained cores, other adaptive algorithms, or better final-record error arising without a local trace-distance improvement. The source's separate pair sampler already exceeds the centered sampler's uniform exponent on its special full-occupancy class.

## 2. A tempting input-loss factorization fails complete positivity

A possible route to a higher-order local approximation was to peel off weak input attenuation from a phase-sensitive output-loss channel. The exact channel identity fails in general.

Let Phi=L_eta composed with S_r, where 0<eta<1, r != 0, S=diag(exp(r),exp(-r)), and the vacuum covariance is I/2. Its Gaussian channel matrices are X=sqrt(eta) S and Y=(1-eta)I/2. Suppose Phi=Psi composed with L_tau with 0<tau<1 and Psi any Gaussian channel. Necessarily

X'=sqrt(eta/tau) S,
2Y'=(1-eta)I-a SS^T,
a=eta(1/tau-1)>0.

A one-mode Gaussian completely positive channel requires det(2Y') >= (1-det X')^2, as well as Y'>=0. Direct algebra gives

 det(2Y')-(1-det X')^2
 = -2a(1-eta)(cosh(2r)-1) < 0.

Thus no such factorization exists. This is an exact algebraic obstruction for equality of channels on all inputs. It is NOT a lower bound on approximating a particular photon-subtracted state by another Gaussian mixture. Standard Gaussian channel conditions are reviewed in Weedbrook et al., RMP84,621 (2012); Gaussian channel decompositions have extensive prior art, including Ivan--Sabapathy--Simon PRA84,042311 (2011). No novelty is claimed for this channel obstruction.

## 3. Positive part is not operator monotone

The main proof must not infer [f(D)]_+ <= f(C) merely from D<=C. For example,

 D = [[-1,1],[1,0]],  C = diag(1/10,1)

satisfies C-D>=0, while the first diagonal entry of D_+ is (3sqrt(5)-5)/10 > 1/10. Hence D_+ is not <= C. The optical proof avoids this error by choosing B=C(I-C)^(-1) directly and applying operator monotonicity only to the fractional-linear resolvent f_u.

Likewise Delta<=2Y does not justify squaring that inequality. The proof uses explicit trace identities instead. K and B are generally noncommuting.

## 4. Other high-upside directions screened

The repository entry points and selected cards were used to screen nonsofic hyperbolic groups, endotactic permanence and controlled molecular jumps, compact-experiment quantum classicality, hard-energy detection, and Gaussian spectral memory. These were not all re-proved. The group construction retains un-emitted astronomical acquisition costs and separate unitary/linear transfer obstructions. Molecular finite-horizon safety does not give all-time permanence or unrestricted spatial diffusion. Compact quantum classicality has a real growing-complexity boundary. These are preserved as prior capital, not relabeled as results of this run.

Positive-kernel heralding was considered at the core-summary level only. It does not justify arbitrary phase cancellation or remove a fixed-cardinality matching interface. The present lossy-counting theorem does not depend on that conditional program or on OA113.

## 5. What the new result enables, and what remains missing

The matrix Schur flow extends the proof to unequal squeezing and arbitrary passive vacuum loss, then to a covariance-only sufficient certificate. A further identity is D=LL^T when the occupied input map L is injective; this follows because the weighted projection in the proof is then the identity. It is an algebraic loss-reconstruction observation under pure input, vacuum-environment, and injectivity assumptions. Its calibration prior art and finite-sample stability are not cleared.

The next substantially stronger sampling result would require a positive, efficient mechanism beyond centered resets. Three concrete gates remain:

* A displaced or non-Gaussian replacement with better local accuracy and a trajectory certificate that survives negative covariance increments. Lim's displaced variant has a negative rank-one covariance update, so the monotone baseline used here is unavailable. Its small-displacement region can create order-one conditional errors.
* Extension of the source's pair/amplifier construction to arbitrary partial occupancy, mode-dependent losses, or general complex contraction T. Uniform amplifier noise is central to its output-count kernel and cannot just be moved through an arbitrary lossy network.
* A finite-dimensional exact bosonic core coupled to a weak Gaussian bath. Retaining a few bright modes is attractive, but cross-covariances couple the bright and weak parts; conditioning gives polynomial-times-Gaussian states rather than the centered Gaussian interface proved here. No complete hybrid error theorem or compiler for that non-Gaussian-core extension has been derived. The later BIT_COMPILER.md supplies a rational-input compiler only for the centered-reset theorem already established here.

The spectral criterion does not itself remove these gates. A run continuing from this state should attack an actual positive representation or monotonicity replacement, not repeat the cubic centered-reset proof.

## 6. Arithmetic cost versus finite-bit implementation

BIT_COMPILER.md closes a proof-level finite-input gap for rational centered-reset instances by a buffered stopping/coupling construction. It does not certify the floating prototype or give a practical precision schedule. It also does not apply to arbitrary noncomputable real input, promise cheap model acquisition, or turn discrete auxiliary times into a TV approximation of continuous times. The count-output law is the object compared. Only exact arithmetic primitives were executed; the complete worst-case high-precision sampler was not.
