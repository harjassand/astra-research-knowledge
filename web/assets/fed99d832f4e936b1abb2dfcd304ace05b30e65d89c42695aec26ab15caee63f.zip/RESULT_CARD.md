# Candidate card: spectral passive-loss Gaussian sampling

**Suggested temporary ID:** SPECTRAL-LOSS-20261007. No repository N-number is assigned; the repository was not modified.

**Status:** internally derived candidate; full written proof and local code supplied. Exact and numerical diagnostics replayed during this run. No independent external review, formal verification, certified float TV bound, or historical-priority clearance.

**Main statement.** Known arbitrary passive vacuum-loss map T:C^N->C^M, T*T<=I; independent squeezed inputs 0<=r_j<=r_max, phases unrestricted. Lim's ideal centered Gaussian reset sampler Q initialized at the exact output covariance satisfies

 TV(P_T,Q) <= min{1,C(r_max) Tr[(T*T)^3]}.

Power transmissions nu_j=s_j(T)^2; the functional is sum nu_j^3, NOT sum s_j^3. One conservative C=max{1000,(10368/25)p^2(p+10/9)}, p=sinh^2(r_max)+sinh(r_max)cosh(r_max). Includes rectangular/rank-deficient maps, unequal squeezing, loss interleaved with passive mixing, collisions. Mean initial photon number E0=Tr[T diag(sinh^2 r_j)T*]. Expected reset count<=E0, not equality.

**More general certificate.** For centered Gaussian K0=Sigma0-I/2, passive R=P(K0)>0 on active support, odd X=K0-R, D=XR^-1X-R<=I/10. B=[D(I-D)^-1]_+ gives TV<=min{1,(5184/25)Tr[(K0+B)K0^2]}. No claim this is a necessary criterion for optimal simulation.

**Mechanism.** For H_u=K0(I+uK0)^-1, decompose H_u=R_u+X_u. Exact identity

 X_u R_u^-1 X_u-R_u=D(I-uD)^-1.

For optical L=realification(T), C=LL^T, weighted projection gives D<=C. Choose B=C(I-C)^-1, B_t=e^-t B, Y=K+B_t. Passive paired inverse/Schur bound gives Delta_i<=2Y and sum_i lambda_i Delta_i=K^2 on every path, without [K,B]=0. Phi=Tr(YK^2)>=0 has G Phi<=(-3+10||Y||)Phi. Stop at ||Y||=1/4; threshold budget>=25/5184. Local Gaussian reset error and rare-exit cost yield TV<=(5184/25)Phi0. Schatten Holder gives Phi0<=2p^2(p+10/9)sum nu_i^3.

**Strict gain over closest source bound.** Lim SIII A gives eta_max sum eta_i^2 for nonuniform input loss. Our sum eta_i^3 tends to zero for eta1=N^-1/10, eta2...etaN=N^-2/5, while that source functional diverges as N^1/10. Uniform loss still gives N eta^3; no new general photon-count exponent beyond N^(2/3).

**Sharpness scope.** For diagonal T and fixed common r>0, source one-mode three-count coefficients tensorize to TV>=1-exp(-c_r sum nu_i^3) for sufficiently small max nu_i. This is a worst-case lower bound for the centered-reset algorithm ONLY, not a classical hardness theorem. Source pair sampler already reaches a different N^(3/4) regime for its fully occupied equally squeezed uniform-loss subclass.

**Dependencies and novelty boundary.** Lim arXiv2610.06526v1 supplies reset algorithm, uniform cubic result, local photon identity, stopping/hybrid pattern, single-mode coefficients. Standard Gaussian/channel/Schur/Schatten techniques are prior art. Claimed extension is the noncommuting matrix certificate and full passive spectral consequence. No unverified OpenAI family theorem is a dependency. Astra N31/N35 are conceptual research-capital links, not premises of this proof.

**Costs.** Supplied T and squeezings/covariance; acquisition/calibration excluded. Active rank d: polynomial preprocessing; expected arithmetic O((1+E0)(d^3+Md^2+d*b_inv)), memory O(Md+d^2). Ideal scalar inversion is charged. BIT_COMPILER.md separately gives a candidate rational-input stopped sampler with polynomial bit cost and TV<=min{1,(10125/16)Phi0+epsilon}, hence C_bit=max{1000,(10125/8)p^2(p+10/9)} times S3 plus epsilon. Its explicit precision schedule is impractical; the full high-precision engine is not emitted or executed. Exact arithmetic primitives are supplied. The float sampler is not a certified TV implementation. No postselection, active network gates, arbitrary non-Gaussian inputs, or experiment-level quantum-advantage conclusion.

**Replays.** 294+268=562 exact assertions/principal-minor checks; 450 random fixtures / 2450 trajectory states (250-fixture extension includes 224 rectangular and 151 rank-deficient fixtures); 6000-record floating sampler smoke test; 1265 exact compiler-primitive assertions. Finite checks do not prove quantified claims. See JSON logs.

**Evidence.** PROOF.md; BIT_COMPILER.md; compiler_primitives.py; test_compiler_primitives.py; verify_exact.py; verify_schur_flow.py; verify_random.py; verify_general_random.py; sampler.py; test_sampler.py; corresponding JSON files; FAILED_ROUTES.md; SOURCES_AND_PRIOR_ART.md.

**Review priorities.** Schur flow at singular K,D and support restriction; passive detector resolvent bound; noncommuting trace generator; Gaussian trace-error derivatives and stopped localization; finite-bit root/state coupling and stopping buffers; comprehensive prior art.
