# Astra research handoff: spectral passive-loss Gaussian sampling

**Date:** 7 October 2026  
**Status:** internally derived candidate; no external validation or novelty clearance.  
**Repository:** not modified.

The strongest result is a candidate extension of a newly released Gaussian boson-sampling simulation theorem. For a known arbitrary passive vacuum-loss map T and bounded unequal input squeezing, the ideal centered Gaussian reset sampler has total-variation error at most

\[
\min\{1,C(r_{\max})\operatorname{Tr}[(T^*T)^3]\}.
\]

The trace is the sum of cubed power transmissions, or the sixth powers of amplitude singular values. Loss may be interleaved with mode mixing. The proof replaces a worst-mode scalar shift with a passive matrix certificate; it does not assume that covariance and shift commute. A covariance-only sufficient certificate is also supplied.

The closest source is Youngrong Lim, arXiv:2610.06526v1 (5 October 2026). The centered algorithm and uniform-loss cubic exponent are inherited. The new claimed step is the matrix Schur-flow certificate and its broader spectral consequence. The result improves an explicit heterogeneous-loss guarantee, but it does not improve the general uniform-loss N^(2/3) photon-count exponent or establish a revolutionary complexity breakthrough.

## Read in this order

`RESULT_CARD.md` is the compact result/dependency record. `PROOF.md` contains the main derivation. `BIT_COMPILER.md` contains the later rational-input finite-bit corollary, explicit algorithm, and implementation limits. `RESEARCH_STATE.txt` is the resumable frontier. `SOURCES_AND_PRIOR_ART.md` and `FAILED_ROUTES.md` preserve provenance and restrictions.

## Reproduce the finite diagnostics

Python, NumPy, and SymPy are required. The versions used in this run are recorded in `environment.json`.

```bash
python verify_exact.py
python verify_schur_flow.py
python verify_random.py
python verify_general_random.py
python test_sampler.py
python test_compiler_primitives.py
```

These scripts write the corresponding JSON logs. They test 562 exact assertions/principal minors, 450 random fixtures containing 2450 trajectory states, a 6000-record sampler smoke test, and 1265 exact compiler-primitive assertions. They are finite diagnostics, not a formal proof.

`sampler.py` is a dense floating-point implementation of the inherited centered sampler. It supports general supplied transfer matrices and unequal squeezings, but has **no certified numerical total-variation bound**. Its resource guard raises rather than silently returning a truncated sample. It is a prototype, not an optimized photonic simulation library or an experimental quantum-advantage benchmark.

`compiler_primitives.py` implements exact dyadic physical rounding, rational determinant/PSD tests, certified inverse-square-root intervals, and the conservative proof precision schedule. The complete high-precision sampler is specified in the corollary but is not emitted or executed. The two-mode example schedule requires 216696 bits; it is a complexity proof, not an implementation recommendation.

`check_scalar.py` preserves an earlier scalar-functional certificate calculation. The final proof uses the more general Schur-complement identity instead.

`MANIFEST.json` records file sizes and SHA-256 checksums. Source manuscripts are referenced, not copied into this archive. No scripts contact external services or modify the user's repository.
