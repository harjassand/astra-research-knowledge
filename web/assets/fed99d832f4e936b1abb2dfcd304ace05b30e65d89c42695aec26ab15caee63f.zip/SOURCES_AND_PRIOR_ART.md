# Sources, provenance, and prior-art boundaries

## Repository retrieval

The run began with the user's repository through the connected GitHub tool, not with reconstructed memories of its content:

- `00_START_HERE.txt` (default-branch content read through GitHub).
- `01_CORE.txt` (default-branch content read through GitHub).
- `web/llms.txt`, the topics directory metadata, and `web/R-reports.txt`.
- N06: `web/pages/d-8c89d4227f58cd23.html` (nonsofic hyperbolic candidate, card only).
- N33: `web/pages/d-ff0b5728e1a460e9.html` (endotactic permanence, card only).
- R general classicality proof: `web/pages/d-fc53e2ac7ba8887c.html` (full displayed criterion proof).
- N32: `web/pages/d-f4f42c8b112b360e.html` (hard-support-energy detection, summary/card).
- N31: `web/pages/d-1773ffd945512496.html` (weak Gaussian spectral memory; only its supplied summary is available in that card).
- N35: `web/pages/d-aa7ee06fc167b319.html` (controlled molecular-jump safety; card, not the complete linked proof).

Base: https://github.com/harjassand/astra-research-knowledge . These retrieval depths matter: the full repository and all prior packages were NOT re-audited. The repository's website is read-only; no GitHub file was changed by this run.

N31 reinforced the value of spectral rather than worst-mode resource accounting; N35 preserved the distinction between a pathwise certificate and uncontrolled all-time conclusions. These are conceptual research-capital links, **not mathematical premises** of the present theorem. The Lyapunov/stopped-hybrid method actually used here is already in the closest external source, Lim, and must be attributed there rather than to a novel cross-field invention.

## Closest external source

Youngrong Lim, *Classical Simulation of Lossy Gaussian Boson Sampling beyond Square-Root Regime*, arXiv:2610.06526v1, 5 October 2026.

https://arxiv.org/abs/2610.06526
https://arxiv.org/html/2610.06526v1
https://arxiv.org/pdf/2610.06526

The main text and relevant supplementary sections were inspected in parsed HTML/PDF form. PDF pages 8--13 (one-based) were additionally rendered and visually inspected for the decisive covariance, local-error, generator, cost, heterogeneous-bound, and sharpness formulas. Sections SIV and SV were read further for the pair construction and displaced-reset boundary. The PDF was not saved to this archive; attempted runtime network access did not provide its bytes. Do not claim a local PDF hash or a replay of the source's numerical code.

Inherited: optical no-click trajectory; centered covariance reset; original uniform cubic bound; local photon-subtraction identity; stopped-prefix/exact-suffix comparison; cubic potential strategy; single-mode three-count coefficients and original uniform sharpness; separate special-case pair algorithm and centered-mixture obstruction.

Proposed extension: noncommuting passive matrix shift; Schur-complement fractional-linear flow; sum of cubic power transmissions for arbitrary passive vacuum-loss networks; unequal squeezing without a lower squeezing bound; more general covariance-only certificate. The later BIT_COMPILER.md is a proposed rational-input finite-bit corollary, extending the source arithmetic-operation contract by a buffered stopping/coupling construction. Its priority and quantitative proof remain unreviewed; it is not a certification of the floating software. The heterogeneous sharpness consequence is a straightforward product extension of the source's single-mode calculation, not a separate new single-mode result.

No independently evaluated correctness or journal acceptance of this October 2026 preprint is assumed. The proof supplied here reconstructs the mathematical interfaces it needs, but still requires outside review.

## Established framework and neighboring work

C. Weedbrook et al., *Gaussian quantum information*, Reviews of Modern Physics 84, 621 (2012), doi:10.1103/RevModPhys.84.621, arXiv:1110.3234. Standard Gaussian covariance/channel framework.
https://link.aps.org/doi/10.1103/RevModPhys.84.621

D. J. Brod and M. Oszmaniec, *Classical simulation of linear optics subject to nonuniform losses*, Quantum 4, 267 (2020), doi:10.22331/q-2020-05-14-267. Primary publication page inspected for neighboring nonuniform-loss literature; complete proof not re-audited.
https://quantum-journal.org/papers/q-2020-05-14-267/

J. S. Ivan, K. K. Sabapathy, and R. Simon, *Operator-sum representation for bosonic Gaussian channels*, Physical Review A 84, 042311 (2011), doi:10.1103/PhysRevA.84.042311. Primary abstract inspected for established decomposition/extremality background to the failed input-loss factorization route.
https://link.aps.org/doi/10.1103/PhysRevA.84.042311

C. S. Hamilton et al., *Gaussian Boson Sampling*, Physical Review Letters 119, 170501 (2017), doi:10.1103/PhysRevLett.119.170501. Primary source for the original sampling setting and photon-count/hafnian relationship; not a claim that noisy instances remain hard in the regime proved here.
https://link.aps.org/doi/10.1103/PhysRevLett.119.170501

D. A. Kopylov, T. Meier, and P. R. Sharapova, *Theory of Multimode Squeezed Light Generation in Lossy Media*, Quantum 9, 1621 (2025), doi:10.22331/q-2025-02-04-1621. Primary abstract surfaced during neighboring-prior-art search. It concerns generation in lossy media, not a read-and-verified proof of the present simulation criterion.
https://quantum-journal.org/papers/q-2025-02-04-1621/

## OpenAI frontier release

The official 6 October 2026 announcement and its link to the public mathematical release were checked:
https://openai.com/index/sharing-ai-progress-in-mathematics/
https://github.com/openai/math

The repository core records a particular 722-manuscript / 372-family snapshot. This run did not audit that complete corpus or certify its headline claims. None of those frontier theorems is a dependency of the final spectral-loss proof. The successful route came from a separate newly available physics preprint rather than from forcing a transfer from a preferred OpenAI result family.

## Limits of the prior-art search

Searches covered the exact closest paper, nonuniform-loss simulation, spectral transmission/cubic error, centered resets, Gaussian Schur complements, Gaussian channel factorization, and neighboring loss-calibration literature. Several broad keyword searches returned weak or irrelevant results and do not count as useful coverage. No matching full matrix-shift spectral theorem was established as prior art in the material actually read, but the search is insufficient for a novelty certificate. A specialist literature review is still required.

In particular, Schur complements, fractional-linear matrix identities, Gaussian trajectories, Schatten inequalities, and stopped Lyapunov arguments are established techniques. The supplied result must be compared as a proposed new **combination and strengthened scope**, not marketed as invention of those techniques. The D=LL^T observation under injectivity also needs calibration-prior-art clearance before any novelty claim.
