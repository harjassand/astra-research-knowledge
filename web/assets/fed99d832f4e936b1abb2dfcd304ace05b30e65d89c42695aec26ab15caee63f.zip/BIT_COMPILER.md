# A finite-bit compilation corollary

**Status:** candidate constructive corollary, derived after the main spectral proof. This is a proof-level compiler with an explicit, deliberately conservative precision schedule. It is not a claim that `sampler.py` is numerically certified. Only rational building blocks are separately implemented/tested; a full run at the theorem's worst-case precision schedule has not been executed.

## Statement and input contract

Let K_0 and B be rational real symmetric 2M-by-2M matrices. Assume Sigma_0=I/2+K_0 is a physical centered Gaussian covariance, B>=0 is passive with ||B||<=1/9, and the ideal centered reset process satisfies the matrix certificate in PROOF.md:

  Y_t=K_t+exp(-t)B>=0,  Delta_i<=2Y_t,
  sum_i lambda_i Delta_i=K_t^2.

The optical construction with rational complex T and rational n_j,m_j satisfying m_j^2=n_j(n_j+1), with bounded squeezing and eta_max<=1/10, supplies such rational K_0 and B=C(I-C)^(-1). The input may instead be any rational covariance and rational certificate satisfying the displayed promise. Exact arbitrary noncomputable real parameters are not a finite Turing input. Efficiently computable real/algebraic input models require a separate certified acquisition/approximation interface; that is not silently assumed here.

**Theorem (candidate finite-bit corollary).** For rational 0<epsilon<1/2, there is an explicitly specified randomized algorithm using a polynomial number of bit operations and random bits in M, E_0+1, epsilon^(-1), and the rational input bit length, whose output count law Q_bit satisfies

\[
\operatorname{TV}(P_{K_0},Q_{\rm bit})
\le \min\left\{1,\frac{10125}{16}\Phi_0+\epsilon\right\},
\qquad \Phi_0=\operatorname{Tr}[(K_0+B)K_0^2],\quad E_0=\tfrac12\operatorname{Tr}K_0.
\tag{B1}
\]

The algorithm is a slightly modified, stopped, finite-precision version of the centered sampler. It need not reproduce the source sampler on the exceptional records where it deliberately aborts. It returns the counts already collected rather than postselecting or retrying the whole record.

For the rational optical input class, the main proof therefore gives

\[
\operatorname{TV}(P_T,Q_{\rm bit})\le
\min\{1,C_{\rm bit}(r_{\max})S_3(T)+\epsilon\},
\quad
C_{\rm bit}(r_{\max})=\max\left\{1000,\frac{10125}{8}p^2(p+10/9)\right\}.
\tag{B2}
\]

At fixed r_max, E_0<=N sinh^2(r_max), so this is a polynomial-time approximate count sampler in the usual finite-input sense on the promised low-error regime. It is not an efficient compiler for inaccessible real-number oracles, nor a practical runtime bound for the very conservative schedule below.

## 1. A buffer separates numerical stopping from the proof boundary

Use an analytical threshold a_-=1/5 and a numerical threshold a_+=1/4. Let tau_- be the first time the **ideal** Y has norm at least a_-. The same noncommuting drift calculation as in PROOF.md gives, before this time,

\[
\mathcal G\Phi\le-\Phi,\qquad
\Phi_{\tau_-}\ge\frac15\left(\frac15-\frac19\right)^2
=\frac{16}{10125}.
\]

Consequently

\[
\frac{16}{10125}\Pr(\tau_-<\infty)
+\mathbb E\int_0^{\tau_-}\Phi_t\,dt\le\Phi_0.
\tag{B3}
\]

Before tau_-, ||Sigma||<=7/10. The fourth-commutator estimate in PROOF.md gives a local error rate at most

\[
A_-\Phi,\qquad A_-=(49/400)C_4<9<10125/16.
\tag{B4}
\]

Numerical states will stop at the larger threshold a_+. On paths that never reach a_-, a sufficiently small covariance and clock error cannot trigger that larger threshold. This removes the need for a regularity assumption about how closely a path approaches an exact stopping boundary.

The comparison concerns final **discrete count records**. Finite-bit auxiliary times have a discrete law and cannot be close in total variation to continuous ideal times. We couple close internal states/times and identical output labels, not identical real-valued trajectories.

## 2. Exceptional events that may be discarded

Put d=2M and

\[
J=\left\lceil\frac{100(E_0+1)}{\epsilon}\right\rceil.
\]

The ideal process has expected count at most E_0, so the probability of at least J detections is below epsilon/100. The compiled algorithm returns after at most J detections.

Choose an integer

\[
k=\left\lceil\log_2\frac{100J(M+1)}{\epsilon}\right\rceil,
\quad v_{\min}=2^{-k},\quad
\gamma=\min\left\{\frac{v_{\min}}{100},
\frac{\epsilon}{100MJ(k+1)}\right\}.
\tag{B5}
\]

On a path before tau_-, E<=M. Given a state at the start of a waiting interval, the probability that its next detection lies after duration t is at most E exp(-t). Therefore the probability, in any of the first J intervals, that the next detection has v=exp(-t)<2v_min is at most

  2MJ v_min <= epsilon/50.

On the complementary event every such waiting interval has duration at most k, so the total time through J events is at most Jk. The compensator bounds the probability of a detection in a mode whose instantaneous ideal rate is less than 2gamma by

\[
\mathbb E\int_0^{Jk}\sum_{i:\lambda_i<2\gamma}\lambda_i\,dt
\le2M\gamma Jk\le\epsilon/50.
\tag{B6}
\]

All these statements can be stopped at tau_-; no bound on the process after that stopping time is used. The numerical sampler may terminate on long waits, low-rate selected modes, or count-cap events, as their total discrepancy is charged by these bounds. No universal positive lower bound on occupations is assumed.

## 3. An explicit precision schedule

Let

\[
L=2^{4d+100}(d+1)^{10}\gamma^{-10}v_{\min}^{-4},
\qquad
\delta_* = \frac{\epsilon}{10^4 J L^2}.
\tag{B7}
\]

Choose an integer precision b with

\[
2^{-b}\le \frac{\delta_*}{(4L)^{J+2}},
\tag{B8}
\]

and enlarge b by ceil(log_2(4d)) for the initial matrix rounding. Exact rational `ceil_log2` operations can choose this integer; no floating logarithm is required. These constants are intentionally excessive. The important fact is

  log L = O(M + log(M+1) + log(1/gamma) + log(1/v_min)),
  b = O(J log L + log(J/epsilon) + log d),

which is polynomial in the input/accuracy parameters.

The simulator keeps a rational covariance perturbation Khat and a dyadic scalar qhat approximating exp(-total elapsed time). The supplied B is retained exactly. Its numerical stopping matrix is Yhat=Khat+qhat B.

After a rational covariance update, round each symmetric entry to the nearest multiple of 2^(-b), then add d*2^(-b) I. The entrywise rounding error has operator norm at most d*2^(-b)/2. The added diagonal therefore makes the change positive semidefinite and has total operator-norm error at most 2d*2^(-b). Physicality is preserved by this operation. Round qhat to the same grid and clip it to [0,1].

## 4. Explicit algorithm

Start with zero output counts, qhat=1, and the physically rounded K_0. At each of at most J iterations:

1. Return the current counts unless both a_+ I-Yhat and a_+ I+Yhat are positive semidefinite. These are exact rational positive-semidefiniteness tests. They ensure ||Yhat||<=a_+. Because qhat B>=0, Khat<=a_+ I; physicality gives Khat>=-I/2.

2. Draw a b-bit dyadic uniform value Uhat in [0,1). Evaluate p_vac=det(I+Khat)^(-1/2) to absolute error 2^(-b). Return the counts when Uhat is below the chosen bracket representative. A terminal decision affected by this evaluation error is included in the comparison bounds below.

3. Otherwise solve S_Khat(v)=Uhat, with S_Khat(v)=det[I+(1-v)Khat]^(-1/2), by monotone bisection on [0,1]. At a midpoint compute a certified interval of width at most 2^(-b). If this interval contains Uhat, accept the midpoint; otherwise retain the correct half. After b+ceil(log_2((M+1)/v_min))+8 iterations, accept the bracket midpoint. Return the counts if the computed v is less than v_min.

4. Apply the rational flow F_v(Khat)=v Khat[I+(1-v)Khat]^(-1), update qhat by v*qhat, and perform the stated physical/dyadic rounding. Compute the exact rational rates lambda_hat_i=Tr(Pi_i Khat)/2. Draw a mode from their rational categorical probabilities with b-bit quantile sampling. This changes a categorical law by at most M*2^(-b). If all rates vanish, return; if the selected rate is less than gamma, return.

5. Otherwise apply the rational reset Khat <- Khat+Khat Pi_i Khat/lambda_hat_i, increment the selected count, and round physically. Continue.

This algorithm has bounded loops. It neither performs exact quantum suffix readout nor uses it as an oracle. Its early-return records are kept in the output distribution; there is no global rejection/postselection normalization.

## 5. Stability on the retained records

We spell out why exponentially small numerical tolerances cost only polynomially many bits here.

Consider an ideal record before tau_- with at most J detections, v>=2v_min on every retained waiting interval, and selected rates at least 2gamma. Couple each b-bit uniform to an ideal uniform by quantization. At the start of a step let

  delta=max{||K-Khat||, |q-qhat|}.

The following elementary bounds apply while delta and 2^(-b) are at most delta_*. All intermediate constants are dominated by L in (B7).

**Survival evaluation and decisions.** On the physical numerical domain -I/2<=Khat<=I/4, the matrix I+(1-v)Khat is at least I/2. Its determinant gives S_Khat(v)>=2^(-M). The log-determinant identity yields, for close K and Khat,

  sup_v |S_K(v)-S_Khat(v)| <= 2d delta.

Thus a terminal decision affected by a CDF perturbation has probability O(d delta+2^(-b)). Bisection branch decisions are not coupled individually: only the final CDF residual and root displacement are compared, so no union bound over bisection branches is needed. Conditional on an ideal selected rate >=2gamma, the survival derivative near its root is bounded below: since

\[
\frac{dS_K(v)}{dv}=S_K(v)\,E(F_v(K))/v,
\]

it is at least 2^(-M)gamma in a small root neighborhood. Indeed, each individual rate changes by at most 4|dv| there, so the selected rate stays at least gamma for |dv|<=gamma/4. The tolerances in (B7)--(B8) ensure that the CDF residual is smaller than the change across this neighborhood. Hence

\[
|v-vhat|\le\frac{2^{M+3}(d+1)}{\gamma}
(\delta+2^{-b}).
\tag{B9}
\]

The finite bisection has CDF residual at most a constant times 2^(-b): its width contribution is bounded using 0<=S'(v)<=M globally on the stated physical domain. Indeed, S<=1 and each eigenvalue kappa of Khat satisfies |kappa/[1+(1-v)kappa]|<=1; the trace derivative is therefore at most d/2=M. Accepting an uncertainty interval gives the same type of residual bound. The very small tolerances also ensure |v-vhat|<v_min, so an ideal retained wait cannot spuriously hit the numerical time cutoff.

**Flow and mode probabilities.** Resolvent differentiation gives

  ||F_v(K)-F_v(Khat)|| <= 4||K-Khat||,
  ||dF_v(K)/dv|| <= 4

on the stated domain. The covariance discrepancy after a flow is therefore at most a constant times 2^M(d+1)(delta+2^(-b))/gamma, plus the physical rounding error. Each rate changes by at most that operator-norm discrepancy. If the ideal total rate is at least 2gamma, the total-variation distance of the two categorical mode laws is at most M/gamma times that discrepancy. The extra b-bit categorical error is at most M*2^(-b). Couple the labels maximally; the probability of a different label is bounded by these quantities. On equal retained labels, the numerical selected rate exceeds gamma.

**Reset and clock.** For ||K||,||Khat||<=1 and both selected rates at least gamma, direct expansion of K Pi K/lambda gives a Lipschitz bound at most 8/gamma^2 for the full reset map (using gamma<1). The scalar clock update has error at most its previous error plus |v-vhat|+2^(-b). Combining these estimates and matrix rounding yields the deliberately loose recursion

\[
\delta_{\rm next}\le L(\delta+2^{-b}),
\tag{B10}
\]

and a per-step probability of a different discrete terminal/label decision at most L(delta+2^(-b)). Equation (B7) dominates the displayed inverse-gradient, rate-normalization, flow, reset, and rounding constants. The small-neighborhood requirements also follow from delta<=delta_* because L contains substantially higher powers of every inverse margin.

Starting from the rounded input, (B8) ensures delta<=delta_* through J successful coupled steps. The total numerical decision-error probability is below epsilon/100. The stopping matrices differ by at most delta+||B||delta<2delta, much smaller than a_+-a_-=1/20. Thus the numerical threshold cannot stop a path that stays below the analytical threshold. Physicality of the rounded covariance is maintained even on a failed coupling; the algorithm remains defined and bounded there.

This argument permits severe amplification of roundoff along a rare conditioned sequence. It compensates by allowing b to grow polynomially with the number of retained events. It does not assert a dimension-independent or practical precision bound.

## 6. Record comparison and polynomial bit cost

Define the ideal hybrid that uses centered resets until tau_- and exact physical readout afterward. Its distance to the target is at most A_- E integral_0^tau_- Phi. Couple its candidate prefix to the compiled algorithm as above. Unless tau_- occurs or one of the count/time/rate/numerical exceptional events happens, the two final count records agree. The exceptional events other than tau_- have total probability below epsilon. Therefore

\[
\operatorname{TV}(P,Q_{\rm bit})
\le A_-\mathbb E\int_0^{\tau_-}\Phi_tdt
+\Pr(\tau_-<\infty)+\epsilon.
\]

Equation (B3) proves (B1). This comparison only concerns counts, never the total-variation distance between continuous and quantized auxiliary times.

All loops have at most J iterations and a polynomial number of bisection iterations in each. Rational matrix additions, products, inversion, determinant, and semidefinite tests have polynomial bit cost in dimension and input precision. They may be carried out by fraction-free elimination or exact rational Schur elimination; all intermediate numerator/denominator sizes are bounded by minors, and Hadamard bounds make their lengths polynomial. Rounding after each update prevents recursive rational-expression growth across J resets.

For a positive rational determinant a/c, an interval for its inverse square root of dyadic width 2^(-b) is obtained by the integer square root of floor(c*2^(2b)/a). This requires no transcendental oracle. The finite uniforms require O(Jb) random bits. Every output count is at most J. Hence the bit-operation and random-bit counts are polynomial in the stated parameters. The source's exact real survival-inversion primitive has been replaced by explicit bounded finite arithmetic, at the price of the additive epsilon and the conservative larger optical constant.

For eta_max>1/10, return vacuum; C_bit S3>=1 makes the theorem's bound trivial. The rational optical construction supplies B in polynomial bit time. Combining (B1) with the initial spectral budget in PROOF.md proves (B2).

## Implementation and validation boundary

`compiler_primitives.py` supplies exact dyadic physical rounding, rational PSD/determinant tests, determinant square-root brackets, and the explicit parameter calculation. `test_compiler_primitives.py` checks these building blocks at small finite precisions. The full theorem-schedule sampler is specified above but is not emitted as a complete runnable high-precision engine or benchmarked. Its deliberately huge precision schedule is not a recommendation for implementation. The floating `sampler.py` remains an uncertified prototype of the ideal centered process.

The closest source [Lim, arXiv:2610.06526v1, SII F] explicitly restricts its runtime statement to arithmetic operations. This corollary is a new derivation in this run; priority and all quantitative coupling details remain subject to independent review. A practical numerical certificate would require far sharper stability analysis than the generic buffered compilation used here.
