# Theorem-amplification research record

Read `capacity_controlled_broadcasting.md` for the exact statement, complete proof, source attribution, and scope exclusions.

The principal result is a dimension-free implication from bounded Holevo capacity and vanishing two-receiver broadcasting error to one uniform entanglement-breaking reconstruction. The record includes an explicit error bound and an averaged-channel corollary. Historical novelty and historic-scale significance are not established. No external peer review or proof-assistant certification occurred.

## Reproduce the finite diagnostics

```sh
python -m pip install numpy scipy
python verify.py --output diagnostics_replayed.json
```

The recorded environment used Python with NumPy 2.3.5 and SciPy 1.17.0. The fixed seed is 20261009. The supplied `diagnostics.json` is the output actually obtained in this research run, not a prediction of a future run.

These are 9,480 finite floating-point checks with a declared tolerance, not rigorous interval certificates or a proof of the universal theorem. The analytical proof is in the note. In particular, the program does not optimize the smoother, establish EB error optima, or certify historical novelty.

## Files

- `capacity_controlled_broadcasting.md`: statement, full analytical proof, consequences, source references, and novelty boundary.
- `verify.py`: newly written finite diagnostics.
- `diagnostics.json`: actually executed diagnostic results.
- `provenance.json`: exact revisions, proof-source paths, and verification scope.
- `SHA256SUMS.txt`: content hashes for this package.

No remote repository or persistent user library was modified. Missing older sandbox scripts were not replayed.
