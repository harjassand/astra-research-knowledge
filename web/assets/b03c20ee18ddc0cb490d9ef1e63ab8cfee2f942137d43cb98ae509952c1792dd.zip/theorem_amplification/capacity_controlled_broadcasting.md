# Capacity-controlled classical reconstruction from approximate broadcasting

**Research derivation — 9 October 2026**  
**Status:** complete analytical argument supplied below; no external expert review or proof-assistant certification. Historical priority is not established.

## Abstract

For a family \(\mathcal E\) of density matrices on an arbitrary finite-dimensional Hilbert space, let \(b(\mathcal E)\) be its optimal worst-case two-receiver marginal broadcasting error and let \(e(\mathcal E)\) be its optimal worst-case reconstruction error through one measure-and-prepare channel. Errors are half the trace norm. If the Holevo capacity of the family, maximized over all finitely supported priors, is at most \(C\) nats, then

\[
 b(\mathcal E)\le e(\mathcal E)
 \le \min\left\{1,\;200\sqrt{\frac{C+\log 2}{\log(1/b(\mathcal E))}}\right\}
 \qquad (0<b(\mathcal E)<1).
 \tag{T}
\]

For \(b(\mathcal E)=0\), the conclusion is \(e(\mathcal E)=0\). Neither dimension nor the number of states appears in the bound. Consequently, uniformly bounded Holevo capacity and vanishing marginal broadcasting error force uniform reconstruction by a single classical measurement-and-preparation device. The conclusion also holds for growing capacities satisfying \(C_n=o(\log(1/b_n))\).

The proof amplifies an archived broadcast-tree covariance comparison by completing its passage through arbitrary finite tracial algebras, nontracial references, and a channel-stable entropy smoothing. The tree construction, flagged centralization, and smoothing mechanism were already present separately in the accessed research archive. They are reconstructed here, not asserted as inventions of this run. The explicit capacity-to-error theorem is the resulting complete consequence. Resolving a historically recognized major conjecture, or a historic-scale novelty claim, is not established by this record.

## 0. Provenance and verification boundary

Accessed revisions:

- Astra research knowledge: `f9344902ef1f94fb8d07540363741894bfbdc0ae`.
- OpenAI mathematics: `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`.

Astra navigation began with `00_START_HERE.txt`. The full tree proof is available at `web/pages/d-8e0604d9d97a15ac.html`. Its historical source path under `updates/AY/package/` returned a missing-file response, but the complete rendered proof was retrieved. Its linked old sandbox programs were not available and were not replayed.

The pinned N93 card lists the bounded-Holevo broadcasting-to-reconstruction implication as unresolved. The source material used here comprises:

1. The N330 common-comparator card and its full tree/covariance/regression proof [A1].
2. The fixed-sandwich/Petz/flagged-centralization proof [A2].
3. The compatible-smoothing audit, including the stronger transport bound [A3].
4. The detailed-balance audit and N46/N93 scope records [A4–A6].

These sources were labeled internally derived or source-derived and not externally certified. The arguments needed below are included in full rather than treating that label, a reported audit, or an unavailable script as a proof. OpenAI's repository was pinned and its verification description inspected, but **no theorem from that repository is a premise** of (T). In particular, this proof does not rely on the reported KMS entropy/root-energy comparison.

The standard inputs are the quantum substate theorem [P1], data processing for root fidelity and sandwiched Rényi divergence of order two, joint concavity of affinity [P3], finite-dimensional convex minimax, and standard trace-norm/square-root inequalities. The Petz recovery inequality used below is established prior work [P2] and is also derived here from a Hilbert-space contraction. None of these standard inputs is claimed as new.

## 1. Definitions and statement

Write

\[
 T(\rho,\omega)=\tfrac12\|\rho-\omega\|_1,
 \quad f(\rho,\omega)=\|\sqrt\rho\sqrt\omega\|_1,
 \quad a(\rho,\omega)=\operatorname{Tr}(\sqrt\rho\sqrt\omega).
\]

Thus \(f\) is root fidelity, not squared fidelity. It is used with positive subnormalized second arguments as well. All logarithms are natural.

For a nonempty family \(\mathcal E\subset\mathcal D(H)\), define

\[
 b(\mathcal E)=\inf_{\mathcal B}
 \sup_{\rho\in\mathcal E}\max_{j=1,2}T(\mathcal B_j(\rho),\rho),
 \tag{1.1}
\]

where \(\mathcal B:B(H)\to B(H\otimes H)\) is completely positive and trace preserving (CPTP), and \(\mathcal B_j\) denotes its marginal. The two outputs may be correlated.

Define

\[
 e(\mathcal E)=\inf_{\Lambda\,\mathrm{EB}}
 \sup_{\rho\in\mathcal E}T(\Lambda(\rho),\rho),
 \tag{1.2}
\]

where an entanglement-breaking (EB) channel is a full-domain channel

\[
 \Lambda(X)=\sum_y\operatorname{Tr}(E_yX)\omega_y,
 \quad E_y\ge0,\quad\sum_y E_y=I,
 \quad\omega_y\in\mathcal D(H).
 \tag{1.3}
\]

The same finite POVM and preparations must work for every member of \(\mathcal E\).

Its Holevo capacity is

\[
 \chi(\mathcal E)=\sup_{\{p_x,\rho_x\}\subset\mathcal E}
 \left[S\!\left(\sum_xp_x\rho_x\right)-\sum_xp_xS(\rho_x)\right],
 \tag{1.4}
\]

where the supremum is over all finite ensembles. This is a supremum over priors, not the Holevo information for one selected prior.

**Theorem 1.** If \(\chi(\mathcal E)\le C\), inequality (T) holds.

Closure does not change these quantities. In each fixed finite dimension, the channel sets in (1.1) and (1.2) are compact, including the EB set through its separable Choi matrices. The suprema over states are uniformly continuous in the channel. Infima can therefore be attained; alternatively every argument can be applied to a broadcasting error strictly above the infimum and then passed to a limit.

The inequality \(b\le e\) is immediate: replace each preparation \(\omega_y\) in (1.3) by \(\omega_y\otimes\omega_y\).

## 2. The broadcast-tree comparison on arbitrary finite tracial algebras

Let \(\mathcal A\) be a finite-dimensional C*-algebra with a faithful normalized trace \(\tau\). On its real Hermitian space, use \(\langle A,B\rangle_\tau=\tau(AB)\). Suppose \(\Phi:\mathcal A\to\mathcal A\) is unital completely positive (UCP), \(\tau\)-preserving and self-adjoint on this Hilbert space. Suppose it has a joint UCP extension

\[
 J:\mathcal A\otimes\mathcal A\longrightarrow\mathcal A,
 \quad J(A\otimes I)=J(I\otimes A)=\Phi(A).
 \tag{2.1}
\]

All superoperator orders in this section are Hilbert-space quadratic-form orders, **not completely positive orders**.

**Lemma 2.** There is one finite POVM \((E_y)\) in \(\mathcal A\) whose canonical map

\[
 \Psi(A)=\sum_y\frac{\tau(E_yA)}{\tau(E_y)}E_y
 \tag{2.2}
\]

satisfies

\[
 0\preceq\Psi\preceq I,
 \qquad \Psi\succeq(2\Phi^2-I)_+,
 \qquad I-\Psi\preceq4(I-\Phi).
 \tag{2.3}
\]

**Proof.** Schwarz and trace preservation make \(\Phi\) an \(L^2(\tau)\) contraction. Choose traceless orthonormal Hermitian eigenvectors \(A_1,\ldots,A_m\) spanning all eigenvalues \(\lambda_i\) with \(|\lambda_i|>1/\sqrt2\). The complement of the identity is invariant. If \(m=0\), use \(\Psi(A)=\tau(A)I\).

Symmetrize \(J\) under interchange of its two arguments. Put

\[
 K_{ij}=\tau J(A_i\otimes A_j).
\]

The functional \(\tau\circ J\) is a state with both marginals \(\tau\). For \(A(v)=\sum_i v_iA_i\), positivity of
\((A(v)\otimes I-I\otimes A(v))^2\) gives \(K\preceq I_m\). This uses the actual joint state and makes no independence assumption.

For spectral decompositions \(A_i=\sum_a aP_{i,a}\), start with effects \(E_{i,a}^{(0)}=P_{i,a}/m\) and estimators
\(z_j^{(0)}(i,a)=ma\mathbf1_{i=j}\). Their operator moments and reference covariance are

\[
 \sum_yz_i^{(0)}(y)E_y^{(0)}=A_i,
 \quad C_{0,ij}=\sum_y\tau(E_y^{(0)})z_i^{(0)}(y)z_j^{(0)}(y)=m\delta_{ij}.
\]

Iterate

\[
 E_{y,z}^{(n+1)}=J(E_y^{(n)}\otimes E_z^{(n)}),
 \quad z_i^{(n+1)}(y,z)=\frac{z_i^{(n)}(y)+z_i^{(n)}(z)}{2\lambda_i}.
 \tag{2.4}
\]

These are finite POVMs. Their first moments remain exactly \(A_i\), by (2.1) and \(\Phi(A_i)=\lambda_iA_i\). Writing \(D=\operatorname{diag}(\lambda_i)\), direct expansion of all four second-moment terms gives the full matrix identity

\[
 C_{n+1}=\tfrac12D^{-1}(C_n+K)D^{-1}.
 \tag{2.5}
\]

In particular, off-diagonal covariance terms have not been dropped. Define

\[
 \mathcal L(M)=\tfrac12D^{-1}MD^{-1},
 \qquad H=(2D^2-I_m)^{-1}.
\]

The map \(\mathcal L\) preserves positive order even when eigenvalues have mixed signs. Since \(H=\mathcal L(H+I_m)\) and \(K\preceq I_m\),

\[
 C_n\preceq H+\mathcal L^n(C_0-H)=H+o(1)I_m.
 \tag{2.6}
\]

The convergence follows entrywise from \(|2\lambda_i\lambda_j|>1\).

For the canonical map \(\Psi_n\) associated to the depth-\(n\) POVM, let

\[
 p_y=\tau(E_y^{(n)}),\quad
 u_A(y)=\frac{\tau(E_y^{(n)}A)}{p_y},\quad
 \beta_i=\tau(AA_i).
\]

For **every** traceless Hermitian \(A\), including vectors outside the selected eigenspaces, exact first moments give \(\mathbb E[u_Az_i]=\beta_i\). Therefore ordinary regression gives

\[
 \tau(A\Psi_n(A))=\mathbb E[u_A^2]
 \ge2v^{\mathsf T}\beta-v^{\mathsf T}C_nv
 \quad(v\in\mathbb R^m).
 \tag{2.7}
\]

Canonical maps (2.2) form a compact set on the original fixed algebra: the positive elements \(e\) with \(\tau(e)=1\) form a compact set, and the first and second moments of probability distributions on this set form a compact finite-dimensional convex hull. The first-moment constraint is \(\sum p_y e_y=I\). Carathéodory's theorem supplies finite support for any limiting moments.

Choose a convergent subsequence of \(\Psi_n\). In (2.7), set \(v=H^{-1}\beta\) and use (2.6). The limit \(\Psi\) satisfies

\[
 \tau(A\Psi(A))\ge\sum_i(2\lambda_i^2-1)\tau(AA_i)^2.
\]

The identity is fixed, and trace preservation kills its cross terms. This proves full-space domination by \((2\Phi^2-I)_+\). Also
\(\tau(A\Psi(A))\le\tau(A^2)\) follows from Schwarz for each positive functional \(\tau(E_y\,\cdot)/\tau(E_y)\), and positivity and self-adjointness are immediate from (2.2). Finally,

\[
 1-(2t^2-1)_+\le2(1-t^2)\le4(1-t),\qquad -1\le t\le1,
\]

proves the last inequality in (2.3). ∎

This is the archived proof [A1] extended explicitly to arbitrary faithful finite traces. No dimension or block-weight constant is introduced. The spectral positive part is not declared to be a physical channel; (2.2) constructs a separate physical comparator.

If \(\tau(A)=\operatorname{Tr}(\sigma A)\) with \(\sigma\) central in \(\mathcal A\), the physical map corresponding to (2.2) is

\[
 \Lambda(\rho)=\sum_y\operatorname{Tr}(E_y\rho)
 \frac{\sigma E_y}{\tau(E_y)}.
 \tag{2.8}
\]

It is EB and fixes \(\sigma\). Positivity of the prepared states uses centrality. Precomposing with block pinching extends it to all ambient matrices.

**Corollary 3.** For likelihood states \(\rho_H=\sigma(I+H)\), where \(H=H^*\), \(\tau(H)=0\), \(\|H\|_\infty\le\theta\), suppose the physical channel corresponding to \(\Phi\) has full trace residual at most \(r\) on all these states. Then one EB map reconstructs the whole family with error at most

\[
 e\le\sqrt{\theta r}.
 \tag{2.9}
\]

Indeed, \((I-\Psi)^2\preceq I-\Psi\) and (2.3) imply

\[
 \|(I-\Psi)H\|_{1,\tau}^2
 \le\|(I-\Psi)H\|_{2,\tau}^2
 \le4\tau(H(I-\Phi)H)
 \le4\theta\|(I-\Phi)H\|_{1,\tau}.
\]

Taking half the full trace norm gives (2.9).

## 3. A dimension-free two-state estimate

**Lemma 4.** If a pair \(\{\rho,\sigma\}\) has broadcasting error at most \(b\in(0,1]\), then

\[
 e(\{\rho,\sigma\})\le q(b):=
 \inf_{L\ge0}\left\{Lb+\sqrt{\frac{\log2}{2\,2^L}}\right\}
 \le3\sqrt b,
 \tag{3.1}
\]

and

\[
 f(\rho,\sigma)-a(\rho,\sigma)\le5b^{1/4}.
 \tag{3.2}
\]

**Proof.** Symmetrize the broadcaster, giving a common marginal \(U\). Its depth-\(L\) binary iteration has \(N=2^L\) leaves, each with marginal \(U^L\) and trace-distance error at most \(Lb\) on both states.

Fix a binary prior. Measure the leaves successively, choosing, at each history, a Helstrom test for the two conditional states of the next leaf. If the posterior probabilities are \(p,1-p\), their conditional trace distance is \(t\), and \(I_y\) is the classical information gained by this test, classical Pinsker gives

\[
 I_y\ge2p(1-p)t^2.
\]

The posterior-average trace distance from the two conditional states to their posterior barycenter is \(a_y=2p(1-p)t\). Thus \(a_y^2\le I_y/2\). The sum of all average information increments is at most \(\log2\), so some step has increment at most \(\log2/N\).

Measure only the preceding leaves and prepare the posterior barycenter for this next, unmeasured leaf. This is an EB channel on the original input, with prior-average error relative to that leaf at most \(\sqrt{\log2/(2N)}\). Nonselective measurement of earlier leaves preserves the next leaf's marginal. Its prior-average error relative to the input pair is therefore at most the expression in (3.1). Convex minimax over binary priors and the compact convex EB set supplies one channel with the same worst-case pair bound. Convexity of trace distance, not an unjustified affine identity, is sufficient for this minimax step.

Taking \(L=\lceil\log_2(1/b)\rceil\) yields \(q(b)\le3\sqrt b\).

For any EB factorization \(\Lambda=P M\), affinity is monotone under preparation, equals root fidelity for classical distributions, and root fidelity is monotone under measurement. Hence

\[
 a(\Lambda\rho,\Lambda\sigma)\ge a(M\rho,M\sigma)
 =f(M\rho,M\sigma)\ge f(\rho,\sigma).
\]

Here the affinity inequality also follows directly from joint concavity and homogeneity of \(\operatorname{Tr}\sqrt A\sqrt B\), applied to the prepared-state summands [P3]. The Powers–Størmer inequality and Cauchy–Schwarz give

\[
 |a(\alpha,\beta)-a(\alpha',\beta')|
 \le\sqrt{\|\alpha-\alpha'\|_1}+\sqrt{\|\beta-\beta'\|_1}.
\]

Applying this to the pair-reconstructing channel proves
\(f-a\le2\sqrt{2q(b)}\le5b^{1/4}\). ∎

This lemma is not a claim that pairwise gaps imply a common measurement for arbitrarily many states. Its sole subsequent use is to compare each state to one shared reference.

## 4. Finite flagged reduction of a nontracial reference

Assume a family contains a faithful state \(\sigma\) and obeys

\[
 \tfrac12\sigma\le\rho\le\tfrac32\sigma
 \quad\text{for every }\rho\in\mathcal E.
 \tag{4.1}
\]

Suppose one common marginal \(U\) of a broadcaster has error at most \(b\in(0,1]\) on this family. Put \(S=\sqrt\sigma\) and \(\kappa=\sqrt{3/2}\). Define the positive canonical likelihood

\[
 X_\rho=S^{-1}(S\rho S)^{1/2}S^{-1}.
\]

It satisfies \(X_\rho\sigma X_\rho=\rho\) and \(0\le X_\rho\le\kappa I\).

Here is the needed noncommutative estimate. Write \(Q=\sqrt\rho\), take the polar decomposition \(SQ=W P\), and extend \(W\) to a unitary. Then

\[
 X_\rho S=QW^*,\quad P=(Q\sigma Q)^{1/2}\ge\rho/\kappa.
\]

For \(K_0=2I-W-W^*\ge0\),

\[
 \operatorname{Tr}(PK_0)=2(f(\rho,\sigma)-a(\rho,\sigma)),
\]

so

\[
 \|X_\rho S-Q\|_2^2
 =\operatorname{Tr}(\rho K_0)
 \le2\kappa(f-a).
\]

Taking adjoints and using Lemma 4 gives the simultaneous bound

\[
 \sup_{\rho\in\mathcal E}\|[X_\rho,S]\|_2
 \le2\sqrt{2\kappa\sup_\rho(f-a)}
 \le8b^{1/8}=:\xi.
 \tag{4.2}
\]

Fix \(t\in(0,1]\). For a uniform shift \(u\in[0,t)\), divide the logarithms of the eigenvalues \(s_a>0\) of \(S\) into intervals \([u+kt,u+(k+1)t)\). Let \(D_u\) be the corresponding block pinching. The probability that indices \(a,c\) are separated is

\[
 p_{ac}=\min\{1,|\log(s_a/s_c)|/t\}
 \le\frac{3|s_a-s_c|}{t(s_a+s_c)}.
 \tag{4.3}
\]

For a Hermitian \(A\), symmetry in \(a,c\) and Cauchy–Schwarz give

\[
 \begin{aligned}
 \mathbb E_u\|(A-D_uA)S\|_2^2
 &=\tfrac12\sum_{a,c}p_{ac}|A_{ac}|^2(s_a^2+s_c^2)\\
 &\le\frac3{2t}
 \left(\sum_{a,c}|A_{ac}|^2(s_a-s_c)^2\right)^{1/2}
 \left(\sum_{a,c}|A_{ac}|^2(s_a+s_c)^2\right)^{1/2}\\
 &\le\frac{3\|A\|_\infty}{t}\|[A,S]\|_2.
 \end{aligned}
 \tag{4.4}
\]

The last line uses \(\sum|A_{ac}|^2(s_a+s_c)^2\le4\operatorname{Tr}(S^2A^2)\le4\|A\|_\infty^2\), not any comparison of condition numbers.

Set \(Y_{\rho,u}=D_uX_\rho\). Since \(D_u(X_\rho S)=Y_{\rho,u}S\), its Hilbert–Schmidt norm is at most \(\|X_\rho S\|_2=1\). The matrix-amplitude inequality gives

\[
 \|\rho-Y_{\rho,u}\sigma Y_{\rho,u}\|_1
 \le2\|(X_\rho-Y_{\rho,u})S\|_2.
\]

The comparison state on the left is fixed by \(D_u\). Pinching contraction and (4.4) therefore imply

\[
 \mathbb E_u\|D_u\rho-\rho\|_1\le4\sqrt{3\kappa\xi/t}.
 \tag{4.5}
\]

Crucially, this is an average for every \(\rho\) with the **same distribution of shifts**. We neither select a separate shift for each state nor use a union bound.

Replace each eigenvalue \(s_a\) by the lower endpoint of its bin and normalize the resulting diagonal matrix in Hilbert–Schmidt norm. Denote it by \(S'_u\) and put \(\sigma'_u=(S'_u)^2\). Then

\[
 e^{-t}S\le S'_u\le e^tS.
\]

The diagonal operator \(A_u=e^{-t}S'_uS^{-1}\) satisfies \(e^{-2t}I\le A_u\le I\). Define a genuinely linear channel

\[
 C_u(Z)=A_uD_u(Z)A_u+
 \operatorname{Tr}[(I-A_u^2)Z]\,\sigma'_u.
 \tag{4.6}
\]

It is CPTP because the first term has trace \(\operatorname{Tr}(A_u^2Z)\) and the second supplies the remainder. Moreover,

\[
 C_u(\sigma)=\sigma'_u,
 \qquad \tfrac12\sigma'_u\le C_u(\rho)\le\tfrac32\sigma'_u,
 \tag{4.7}
\]

and its outputs are block diagonal and commute with \(\sigma'_u\). Directly,

\[
 \|C_u(\rho)-D_u(\rho)\|_1
 \le2(1-e^{-2t})+(1-e^{-4t})\le8t.
 \tag{4.8}
\]

There is no continuous classical register in the construction. Bin assignments change only at the finitely many residues \(\log(s_a)\bmod t\). Between consecutive breakpoints the common factor \(e^u\) cancels in the normalization defining \(S'_u\). Thus \(C_u\) is constant on each of at most \(d+1\) intervals. Keep the interval probabilities \(p_\ell\) and define finite CPTP maps

\[
 \mathrm{Enc}(Z)=\bigoplus_\ell p_\ell C_{u_\ell}(Z),
 \qquad \mathrm{Dec}(W)=\sum_\ell V_\ell^*WV_\ell,
 \tag{4.9}
\]

where \(V_\ell\) embeds the original space into its \(\ell\)-th copy. All encoded states and \(\sigma_F=\mathrm{Enc}(\sigma)\) lie in a finite direct sum \(\mathcal A\) of full matrix blocks; \(\sigma_F\) is faithful and central in \(\mathcal A\). The functional \(\tau(A)=\operatorname{Tr}(\sigma_FA)\) is consequently a faithful normalized trace.

For every original state,

\[
 \|\mathrm{Dec}\,\mathrm{Enc}(\rho)-\rho\|_1
 \le\epsilon:=4\sqrt{3\kappa\xi/t}+8t.
 \tag{4.10}
\]

An encoded broadcaster is
\((\mathrm{Enc}\otimes\mathrm{Enc})\mathcal B\,\mathrm{Dec}\). Its marginal full trace errors on the encoded family, including \(\sigma_F\), are at most \(2b+\epsilon\). Pinching its input into \(\mathcal A\) changes no promised input. Thus it is a physical CP map between the required finite algebras.

Conversely, an EB reconstruction on the encoded family yields the EB channel \(\mathrm{Dec}\Lambda_F\mathrm{Enc}\) on the original input and costs at most an additional \(\epsilon/2\) in trace distance.

With \(t=b^{1/24}\), (4.2) and (4.10) give the convenient bounds

\[
 \epsilon\le30b^{1/24},
 \qquad h:=2b+\epsilon\le32b^{1/24}.
 \tag{4.11}
\]

This reproduces the essential flagged centralization mechanism of [A2] and verifies its exact interface with Lemma 2.

## 5. Petz correction and a universal sandwich theorem

For a density matrix \(\sigma\), write

\[
 \Gamma_\sigma(X)=\sigma^{1/2}X\sigma^{1/2},\quad
 G_\sigma(X)=\sigma^{1/4}X\sigma^{1/4},\quad
 Q_\sigma(X)=\|G_\sigma^{-1}(X)\|_2^2.
 \tag{5.1}
\]

All inverses for singular matrices are restricted to their support. For Hermitian \(X\), trace duality and Schatten Hölder give

\[
 \|X\|_1^2\le Q_\sigma(X).
 \tag{5.2}
\]

Indeed, for the sign unitary \(W\) of \(X\), \(\|\sigma^{1/4}W\sigma^{1/4}\|_2\le1\), which proves (5.2) by Hilbert–Schmidt Cauchy–Schwarz.

Let \(U\) be any CPTP map, \(\nu=U\sigma\), and \(P=\operatorname{supp}\nu\). Faithfulness of \(\sigma\) ensures all outputs of \(U\) are supported on \(P\). The completed Petz map

\[
 R(Y)=\Gamma_\sigma U^*(\nu^{-1/2}PYP\nu^{-1/2})
 +\operatorname{Tr}[(I-P)Y]\sigma
 \tag{5.3}
\]

is CPTP and satisfies \(R\nu=\sigma\).

Data processing for sandwiched Rényi divergence of order two gives \(Q_\nu(UX)\le Q_\sigma(X)\). It holds first for positive \(X\). For Hermitian \(X\), apply it to \(X+c\sigma\ge0\) and cancel the common cross terms \(2c\operatorname{Tr}X+c^2\); then split real and imaginary parts. Consequently

\[
 V=G_\nu^{-1}UG_\sigma
\]

is a Hilbert-space contraction. The implementation of \(S=RU\) is

\[
 G_\sigma^{-1}SG_\sigma=V^*V=:K,
 \qquad 0\preceq K\preceq I.
\]

Since \((I-K)^2\preceq I-K\),

\[
 \|\rho-S\rho\|_1^2
 \le Q_\sigma(\rho-S\rho)
 \le Q_\sigma(\rho)-Q_\nu(U\rho).
 \tag{5.4}
\]

This is the established Petz/chi-square recovery inequality [P2], not a new recovery theorem.

For a \(\theta\)-sandwich \(\rho=\Gamma_\sigma(I+H)\), \(\|H\|_\infty\le\theta\), put

\[
 d_r=\|U\rho-\rho\|_1,\quad d_s=\|\nu-\sigma\|_1,
 \quad p=\rho-\sigma,\quad q=U\rho-\nu,\quad p'=\Gamma_\nu(H).
\]

Square-root continuity gives

\[
 \|p'-p\|_1\le2\theta\sqrt{d_s},
 \quad |Q_\nu(p')-Q_\sigma(p)|\le2\theta^2\sqrt{d_s}.
\]

Both \(q\) and \(p'\) lie between \(-\theta\nu\) and \(\theta\nu\). Expanding their quadratic difference gives

\[
 |Q_\nu(q)-Q_\nu(p')|
 \le2\theta\|q-p'\|_1
 \le2\theta(d_r+d_s+2\theta\sqrt{d_s}).
\]

The trace-zero cross terms with the references cancel, so

\[
 0\le Q_\sigma(\rho)-Q_\nu(U\rho)
 \le2\theta(d_r+d_s)+6\theta^2\sqrt{d_s}.
 \tag{5.5}
\]

Apply this to the encoded family of Section 4, with \(\theta=1/2\) and \(d_r,d_s\le h\). Apply the same \(R\) to both broadcaster outputs. This gives an exactly \(\sigma_F\)-preserving self-compatible channel \(S\), with uniform full trace residual at most

\[
 r\le\sqrt{2h+\tfrac32\sqrt h}\le4h^{1/4},\qquad h\le32.
 \tag{5.6}
\]

Its Heisenberg map \(\Phi=S^*\) is positive and self-adjoint for the KMS inner product. More precisely, \(\Gamma_{\sigma_F}^{-1}S\Gamma_{\sigma_F}=S^*\). Since \(\sigma_F\) is central in \(\mathcal A\), this is exactly the tracial \(L^2(\tau)\) inner product, with no spectral-comparison factor. The Petz formula stays inside \(\mathcal A\); applying it on both outputs preserves self-compatibility. Thus every hypothesis of Lemma 2 holds.

Corollary 3, followed by decoding, proves:

**Theorem 5 (uniform sandwich reconstruction).** For every finite-dimensional family satisfying (4.1) and containing \(\sigma\),

\[
 e(\mathcal E)\le20\,b(\mathcal E)^{1/192}.
 \tag{5.7}
\]

Indeed, by (4.11), (5.6), and (2.9),

\[
 e\le\epsilon/2+\sqrt{r/2}
 \le15b^{1/24}+\sqrt2\,32^{1/8}b^{1/192}
 \le20b^{1/192}.
\]

No reversibility, unitality, spectral gap, dimension bound, or family-size bound was imposed on the original broadcaster. Those exact structures were constructed only on the encoded problem.

## 6. The entropy radius and the common reference

The standard Holevo-radius identity [P4] supplies a reference, but it is useful to record why the reference can be chosen in the convex hull of the family. In fixed finite dimension, the convex hull of

\[
 \{(\rho,S(\rho)):\rho\in\overline{\mathcal E}\}
\]

is compact. Maximizing \(S(\sigma)-h\) over pairs \((\sigma,h)\) in this convex hull gives a capacity-achieving finite ensemble by Carathéodory. Its mean is \(\sigma\).

If some state in the family has support outside \(\sigma\), adding it with infinitesimal weight gives an infinite positive directional derivative of the ensemble Holevo information, contradicting maximality. On the common support, the directional derivative obtained by adding \(\rho\) equals

\[
 D(\rho\|\sigma)-\chi(\mathcal E).
\]

It is nonpositive. Hence

\[
 \sup_{\rho\in\mathcal E}D(\rho\|\sigma)\le C,
 \qquad \sigma\in\operatorname{conv}\overline{\mathcal E}.
 \tag{6.1}
\]

A broadcaster with error at most \(b\) on the original family also has error at most \(b\) on \(\sigma\), by convexity of trace distance. We may add \(\sigma\) to the family without changing its broadcasting error or losing (6.1).

Compress to the common support. On outputs this is achieved by the CPTP map

\[
 Z\longmapsto PZP+\operatorname{Tr}[(I-P)Z]\sigma.
\]

It fixes the promised inputs and cannot increase their errors. The reference is now faithful. No lower bound on its least eigenvalue is assumed.

## 7. A smoother that preserves approximate channel invariance

Ordinary approximation by a dominated state would add a fixed smoothing error to the broadcasting error. That would not suffice when the mixing cost later grows exponentially. Instead use the channel-stable smoothing from [A3], whose needed estimates are proved here.

Fix \(0<\eta\le1/16\), and set

\[
 M=\frac1{1-\eta}\exp\!\left(\frac{C+\log2}{\eta}\right),
 \qquad \lambda=\eta/M.
 \tag{7.1}
\]

The quantum substate theorem [P1, Theorem 1], together with its bound of observational divergence by relative entropy plus one bit, supplies for each \(\rho\) a normalized \(\rho_0\le M\sigma\) with \(f(\rho,\rho_0)^2\ge1-\eta\). The conversion in (7.1) uses natural logarithms and squared fidelity exactly as in that source.

For any \(\rho,\sigma\), define \(G(\rho,\sigma)\) as the unique minimizer over

\[
 \mathcal K_\sigma=\{v:0\le v\le M\sigma,\ \operatorname{Tr}v\le1\}
\]

of

\[
 J_{\rho,\sigma}(v)=-f(\rho,v)+\lambda Q_\sigma(v).
 \tag{7.2}
\]

The feasible set is compact and convex. Root fidelity is concave in \(v\), while \(Q_\sigma\) is a positive definite quadratic on the reference support. Uniqueness follows, and the exact quadratic identity gives

\[
 J_{\rho,\sigma}(v)-J_{\rho,\sigma}(G)
 \ge\lambda Q_\sigma(v-G)
 \ge\lambda\|v-G\|_1^2.
 \tag{7.3}
\]

For completeness, apply convexity along \((1-t)G+tv\), use minimality at \(G\), divide by \(t\), and let \(t\downarrow0\); no differentiability at a boundary is needed.

For a feasible \(v\), \(Q_\sigma(v)\le M\operatorname{Tr}v\le M\). To see this without squaring an operator inequality, put \(Y=\sigma^{-1/4}v\sigma^{-1/4}\), so \(0\le Y\le M\sqrt\sigma\), and use \(\operatorname{Tr}[Y(M\sqrt\sigma-Y)]\ge0\).

Comparing the minimizer to \(\rho_0\) therefore gives

\[
 f(\rho,G)\ge\sqrt{1-\eta}-\eta\ge1-2\eta.
\]

Writing \(t_\rho=\operatorname{Tr}G\) and \(\widehat\rho=G/t_\rho\), we obtain

\[
 t_\rho\ge(1-2\eta)^2>\tfrac12,
 \quad \widehat\rho\le2M\sigma,
 \quad T(\widehat\rho,\rho)\le2\sqrt\eta.
 \tag{7.4}
\]

The reference is fixed by this smoother: \(G(\sigma,\sigma)=\sigma\). Indeed, for \(t=\operatorname{Tr}v\le1\), \(f(\sigma,v)\le\sqrt t\) and \(Q_\sigma(v)\ge t^2\). The scalar function \(-\sqrt t+\lambda t^2\) is decreasing on \([0,1]\) when \(\lambda\le1/4\), and \(v=\sigma\) attains its minimum.

### 7.1 Transport between nearby references

Let \(U\) be CPTP, \(\nu=U\sigma\),

\[
 d_r=\|U\rho-\rho\|_1,\qquad d_s=\|\nu-\sigma\|_1.
\]

For \(v\in\mathcal K_\sigma\), write \(v=\sqrt\sigma A\sqrt\sigma\) with \(0\le A\le MI\). Define

\[
 v'=\sqrt\nu A\sqrt\nu,
 \qquad \widetilde v=v'/\max\{1,\operatorname{Tr}v'\}.
\]

Then \(\widetilde v\in\mathcal K_\nu\), including when the supports differ, and

\[
 \|\widetilde v-v\|_1\le2M\sqrt{d_s}+Md_s.
 \tag{7.5}
\]

The first term follows by expanding the two square-root factors. The clipping cost is at most \(Md_s\), because
\(|\operatorname{Tr}v'-\operatorname{Tr}v|=|\operatorname{Tr}[A(\nu-\sigma)]|\le Md_s\).

The identity

\[
 Q_\sigma(v)=\operatorname{Tr}(A\sqrt\sigma A\sqrt\sigma)
\]

and its \(\nu\) counterpart give

\[
 Q_\nu(\widetilde v)-Q_\sigma(v)\le2M^2\sqrt{d_s}.
 \tag{7.6}
\]

The identity remains valid for singular \(\nu\), and clipping only decreases \(Q\).

For root fidelity, use amplitudes rather than a generic fourth-root continuity bound:

\[
 f(\rho,\sqrt\sigma A\sqrt\sigma)=\|\sqrt\rho\sqrt\sigma A^{1/2}\|_1.
\]

Changing \(\sigma\) to \(\nu\) costs at most \(\sqrt{Md_s}\). Clipping costs at most \(Md_s/2\), since \(\sqrt s-1\le(s-1)/2\) for \(s\ge1\). Changing \(\rho\) to \(U\rho\) after clipping costs at most \(\sqrt{d_r}\). Combining these facts gives

\[
 J_{U\rho,\nu}(\widetilde v)
 \le J_{\rho,\sigma}(v)+\zeta,
 \quad
 \zeta=\sqrt{d_r}+(\sqrt M+2\lambda M^2)\sqrt{d_s}+(M/2)d_s.
 \tag{7.7}
\]

The same construction in reverse shows that the two minimum objective values differ by at most \(\zeta\).

### 7.2 Approximate invariance of the smoother

By data processing, \(UG\in\mathcal K_\nu\) and

\[
 J_{U\rho,\nu}(UG)\le J_{\rho,\sigma}(G).
\]

Let \(G'=G(U\rho,\nu)\). The minimum-value comparison and (7.3) imply

\[
 \|UG-G'\|_1\le\sqrt{\zeta/\lambda}.
\]

Transporting \(G\) as above gives \(\widetilde G\) with objective at most \(2\zeta\) above the new minimum. Hence
\(\|\widetilde G-G'\|_1\le\sqrt{2\zeta/\lambda}\). Together with (7.5), this proves

\[
 \|UG-G\|_1
 \le(1+\sqrt2)\sqrt{\zeta/\lambda}+2M\sqrt{d_s}+Md_s.
 \tag{7.8}
\]

If \(d_r,d_s\le2b\), define

\[
 \begin{aligned}
 \zeta_b&=(1+\sqrt M+2\lambda M^2)\sqrt{2b}+Mb,\\
 R_b&=(1+\sqrt2)\sqrt{\zeta_b/\lambda}+2M\sqrt{2b}+2Mb.
 \end{aligned}
 \tag{7.9}
\]

Normalization in (7.4) then gives

\[
 T(U\widehat\rho,\widehat\rho)\le R_b.
 \tag{7.10}
\]

At fixed \(M,\lambda\), this tends to zero with \(b\); no fixed smoothing error has been added to the channel residual. These estimates are uniform over the entire state family, all dimensions and all reference spectra.

The smoother is a state-dependent mathematical map used to define an auxiliary family. It is **not** asserted to be a physical preprocessing channel. Section 8 transfers the single physical reconstruction channel back by linearity and trace contraction.

## 8. Closing the bounded-capacity implication

Take the common reference from Section 6, and the normalized smoothed states from Section 7. Put

\[
 \alpha=\frac1{4M},\qquad
 \omega_\rho=(1-\alpha)\sigma+\alpha\widehat\rho,
 \qquad \mathcal F=\{\sigma\}\cup\{\omega_\rho:\rho\in\mathcal E\}.
 \tag{8.1}
\]

The auxiliary family satisfies

\[
 \tfrac12\sigma\le\omega_\rho\le\tfrac32\sigma.
\]

The same broadcaster as before has half-trace error at most

\[
 s=(1-\alpha)b+\alpha R_b
 \tag{8.2}
\]

on \(\mathcal F\). This also bounds its error on the included reference: (7.9) gives \(R_b\ge b\) for \(b\le1\). If necessary one can replace \(s\) by \(\min\{s,1\}\); using the larger value below only weakens the bound.

Theorem 5 yields one EB channel \(\Lambda\) with error at most \(20s^{1/192}\) on every state in \(\mathcal F\). Linearity, applied to
\(\widehat\rho=(\omega_\rho-(1-\alpha)\sigma)/\alpha\), gives

\[
 T(\Lambda\widehat\rho,\widehat\rho)
 \le\frac{2-\alpha}{\alpha}\,20s^{1/192}
 =(8M-1)20s^{1/192}.
\]

Finally, trace contraction and (7.4) imply

\[
 \boxed{
 e(\mathcal E)\le4\sqrt\eta+(8M-1)20s^{1/192}.
 }
 \tag{8.3}
\]

Every quantity on the right depends only on \(C,b,\eta\). This already proves the qualitative bounded-capacity theorem by first making \(\eta\) small and then letting \(b\) tend to zero. There is no dependence on a net size, number of labels, reference condition number, or matrix dimension. Nor is there a state-dependent channel in the conclusion: \(\Lambda\) is the same map throughout the last two displays.

## 9. Quantitative choice of parameters

We now derive (T), keeping deliberately loose constants.

For \(\eta\le1/16\), (7.1) gives \(M\ge2^{1/\eta}\), and hence \(\sqrt M\ge1/\eta\). Therefore

\[
 1+\sqrt M+2\eta M\le4\eta M.
\]

Using \(\lambda=\eta/M\) in (7.9), then (8.2), gives

\[
 s\le\tfrac32b+
 \frac{1+\sqrt2}{2}(2b)^{1/4}+
 \frac{1+\sqrt2}{4}\sqrt{b/\eta}+\tfrac12\sqrt{2b}.
\]

If \(b\le\eta^2\), each term is bounded by its displayed coefficient times \(b^{1/4}\), and the coefficients sum to less than 5. Thus

\[
 s\le5b^{1/4}.
\]

Since \(20\cdot5^{1/192}<21\), (8.3) becomes

\[
 e(\mathcal E)\le4\sqrt\eta+168M b^{1/768}.
 \tag{9.1}
\]

Write \(K_C=C+\log2\) and \(L=\log(1/b)\). If \(L\ge24576K_C\), choose

\[
 \eta=1536K_C/L\le1/16.
\]

The inequality \(b\le\eta^2\) holds: \(L^2e^{-L}\le4/e^2<(1536\log2)^2\). Also

\[
 M\le2e^{L/1536}.
\]

Substituting in (9.1) yields

\[
 e(\mathcal E)\le4\sqrt{1536K_C/L}+336e^{-L/1536}.
 \tag{9.2}
\]

For \(L\ge24576K_C\) the second term is at most \(\sqrt{K_C/L}\). Indeed, \(\sqrt L e^{-L/1536}\) is decreasing in this range, \(K_C\ge\log2\), and at the endpoint

\[
 336\sqrt{24576}\,e^{-16K_C}
 \le\frac{336\sqrt{24576}}{65536}<1.
\]

Thus

\[
 e(\mathcal E)\le(4\sqrt{1536}+1)\sqrt{K_C/L}<200\sqrt{K_C/L}.
\]

If \(L\le40000K_C\), the claimed upper bound of 1 is already trivial. If \(L>40000K_C\), the preceding estimate applies. This proves exactly

\[
 e(\mathcal E)\le\min\{1,200\sqrt{K_C/L}\}.
\]

At \(b=0\), apply the estimate for every positive error bound tending to zero and use compactness of the EB set, or just take its infimum, to obtain \(e=0\). This completes the proof of Theorem 1. ∎

## 10. Consequences proved from the theorem

### 10.1 Bounded-capacity robust no-broadcasting

For arbitrary finite-dimensional families \(\mathcal E_n\) with \(\sup_n\chi(\mathcal E_n)<\infty\),

\[
 b(\mathcal E_n)\longrightarrow0
 \quad\Longleftrightarrow\quad
 e(\mathcal E_n)\longrightarrow0.
 \tag{10.1}
\]

The dimensions and family sizes may grow without restriction. The backward implication requires no capacity assumption; it is simply \(b\le e\).

More generally, if \(b_n\to0\) and \(C_n=o(\log(1/b_n))\), the same conclusion follows.

### 10.2 A necessary information cost for persistent failure of reconstruction

If \(e(\mathcal E)\ge\varepsilon>0\) and \(0<b(\mathcal E)<1\), then

\[
 \boxed{
 \chi(\mathcal E)\ge
 \frac{\varepsilon^2}{40000}\log\frac1{b(\mathcal E)}-\log2.
 }
 \tag{10.2}
\]

Equivalently,

\[
 b(\mathcal E)\ge
 \exp\!\left[-\frac{40000(\chi(\mathcal E)+\log2)}{\varepsilon^2}\right].
\]

Thus a vanishing-broadcast-error sequence that remains a fixed distance from every common classical reconstruction must have logarithmically diverging Holevo capacity. This is a proved consequence, not an assertion that the constant or logarithmic tradeoff is sharp.

### 10.3 Cesàro classicalization of arbitrary self-compatible channels

Let \(N:B(H)\to B(H)\) be any self-compatible CPTP channel, without unitality, normality, reversibility, or a spectral-gap assumption. Suppose the Holevo capacity of its output family \(N(\mathcal D(H))\) is at most \(C\). Put

\[
 A_n=\frac1n\sum_{k=1}^{n}N^k,\qquad n\ge2.
\]

There is an EB channel \(\Xi_n\) such that

\[
 \boxed{
 \sup_{\rho\in\mathcal D(H)}T(\Xi_n(\rho),A_n(\rho))
 \le\min\left\{1,200\sqrt{\frac{C+\log2}{\log n}}\right\}.
 }
 \tag{10.3}
\]

**Proof.** Each \(A_n(\rho)\) belongs to the range of \(N\), because
\(A_n=N\circ(n^{-1}\sum_{k=0}^{n-1}N^k)\). Its range therefore has Holevo capacity at most \(C\). The broadcaster for \(N\), restricted to this family, has error at most \(1/n\), since

\[
 N A_n(\rho)-A_n(\rho)=\frac{N^{n+1}(\rho)-N(\rho)}n.
\]

Apply Theorem 1 to the family \(A_n(\mathcal D(H))\), producing a common EB reconstruction \(\Lambda_n\), and take \(\Xi_n=\Lambda_n\circ A_n\). ∎

This is a statewise trace-norm assertion about the averaged channel, not a diamond-norm assertion and not a statement that a finite power of \(N\) is exactly EB.

### 10.4 Arbitrarily many marginal receivers

Given the resulting EB map \(\Lambda(\rho)=\sum_y\operatorname{Tr}(E_y\rho)\omega_y\), prepare \(\omega_y^{\otimes r}\) for any finite \(r\). Every marginal has reconstruction error at most \(e\), independent of \(r\). The joint output is generally correlated after averaging over \(y\), so this is not independent cloning.

## 11. What was amplified, and what is not claimed

**Amplified mechanism.** The full-space common-measurement comparison in [A1] is the decisive source theorem. It converts small simultaneous Dirichlet energy into one actual EB reconstruction. In isolation its original statement concerns a reversible bistochastic channel on a full matrix algebra.

**Connecting work in this record.** The proof establishes the exact weighted finite-algebra interface, reconstructs and joins the finite flagged nontracial reduction and channel-stable smoothing, supplies a direct two-state gap argument, and carries the exponential smoothing costs through a quantitative parameter choice. The final result removes reversibility, unitality, fixed dimension, bounded family size, and a supplied spectral reference from the original experiment-level statement.

**Attribution limit.** The tree recursion, flagged log binning, Petz correction, and variational smoothing are not new inventions of this run: their source arguments are in the pinned archive, and Petz recovery and substate domination are established literature. The contribution claimed here is the complete operational implication and quantified tradeoff, not renaming those tools. The last step is an amplification of their combined strength. It should not be portrayed as an independently invented mathematical mechanism of historic significance.

**Specific obstruction eliminated.** The pinned N93 record leaves open whether bounded Holevo capacity plus vanishing two-output broadcasting error yields uniform EB reconstruction. The theorem proves that implication in the record's full finite-dimensional, arbitrarily growing-family formulation. It does not merely prove another structured observable case.

**Novelty status.** The external literature inspected includes exact no-broadcasting [P5], recoverability [P2], substate domination [P1], capacity-radius formulas [P4], and common-measurement emergence of classicality [P6]. The channel statement in [P6, Theorem 1 and its trace-norm variant] has explicit input-dimension factors, whereas (T) controls a specified experiment through its Holevo capacity; neither statement should be silently identified with the other. This comparison does not certify that (T) is historically new. Searches did not establish an independent published formulation of the exact N93 problem or exclude prior equivalent theorems. No named major conjecture is claimed resolved, and the requested 10/10 historic-scale objective is not certified.

**Scope exclusions.** There is no diamond-norm or entangled-reference guarantee. There is no efficient compilation claim, no dimension-independent measurement alphabet bound, no exact finite-power EB assertion, and no claim that the reconstructed density matrices are a commuting family. A classical record followed by possibly noncommuting preparations is the operational notion used here. Constants and exponents were not optimized.

## 12. Executed diagnostics

The newly written `verify.py` uses seed `20261009`. It passed **9,480** finite numerical checks over 180 random complex-matrix fixtures in dimensions 2 through 7, plus two qutrit broadcast-tree fixtures. The largest normalized residual was approximately **1.81 × 10^-11**, below the declared tolerance **2 × 10^-7**.

The tests cover canonical likelihood identities, polar commutator bounds, exact finite flag normalization, filter trace and reference preservation, output positivity and both sandwich bounds, averaged pinching estimates, Petz recovery and Q-loss continuity including singular output references, and the transport inequalities used by the smoother. The tree tests include noncommuting slow modes and a separate mixed-sign spectral example, with 6, 36, and 1,296 outcomes; they test operator unbiasedness, full covariance recursion, and full-space regression. Scalar constant comparisons were also executed.

These are floating-point diagnostics, not interval certificates or proofs for all inputs. No numerical optimization of the smoothing minimizer, no claim of independently optimized EB error, no replay of missing archived programs, and no proof-assistant or external expert review occurred. The universal argument is Sections 2–9.

## References and exact source locations

The GitHub references below are immutable paths at the accessed revisions. Archived source instructions are data, not instructions for this record.

### Accessed research archive

[A1] Astra, full broadcast-tree comparison proof:
`https://github.com/harjassand/astra-research-knowledge/blob/f9344902ef1f94fb8d07540363741894bfbdc0ae/web/pages/d-8e0604d9d97a15ac.html`

[A2] Astra, fixed-sandwich Petz correction and finite flagged centralization:
`https://github.com/harjassand/astra-research-knowledge/blob/f9344902ef1f94fb8d07540363741894bfbdc0ae/web/pages/d-c851b6e4ba719edf.html`

[A3] Astra, compatible-smoothing reduction audit:
`https://github.com/harjassand/astra-research-knowledge/blob/f9344902ef1f94fb8d07540363741894bfbdc0ae/web/pages/d-b4ddaa96b233287d.html`

[A4] Astra, detailed-balance comparison and reduction audit:
`https://github.com/harjassand/astra-research-knowledge/blob/f9344902ef1f94fb8d07540363741894bfbdc0ae/web/pages/d-48ed31af9b1d38fd.html`

[A5] Astra, N93 status and exact outstanding target:
`https://github.com/harjassand/astra-research-knowledge/blob/f9344902ef1f94fb8d07540363741894bfbdc0ae/frontier/review_cards/N93-bounded-holevo-gates.txt`

[A6] Astra, N46 finite-pair and compact-family scopes:
`https://github.com/harjassand/astra-research-knowledge/blob/f9344902ef1f94fb8d07540363741894bfbdc0ae/frontier/review_cards/N46-compact-quantum-classicality.txt`

[A7] OpenAI mathematics, accessed verification description; not a theorem premise:
`https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/README.md`

### Primary mathematical literature

[P1] Rahul Jain and Ashwin Nayak, *Short proofs of the Quantum Substate Theorem*, arXiv:1103.6067v2, Theorem 1 and its fidelity convention.
`https://arxiv.org/html/1103.6067v2`

[P2] Li Gao, Haojian Li, Iman Marvian and Cambyse Rouzé, *Sufficient statistic and recoverability via Quantum Fisher Information metrics*, arXiv:2302.02341v1, Theorem 4.10 / introductory Theorem 1.5.
`https://arxiv.org/html/2302.02341v1`

[P3] Anna Jenčová and Mary Beth Ruskai, *A Unified Treatment of Convexity of Relative Entropy and Related Trace Functions, with Conditions for Equality*, arXiv:0903.2895. Used for the established Lieb trace-concavity/affinity background, not as a new theorem in this record.
`https://arxiv.org/abs/0903.2895`

[P4] Milán Mosonyi and Fumio Hiai, *On the quantum Rényi relative entropies and related capacity formulas*, arXiv:0912.1286v4, including the discussion of the established Holevo-radius identity and its original attribution to Ohya, Petz and Watanabe.
`https://arxiv.org/html/0912.1286v4`

[P5] H. Barnum, C. M. Caves, C. A. Fuchs, R. Jozsa and B. Schumacher, *Noncommuting mixed states cannot be broadcast*, arXiv:quant-ph/9511010; Physical Review Letters 76 (1996), 2818–2821. Historical comparison only; the quantitative proof above does not use an unproved robustness extension of this theorem.
`https://arxiv.org/abs/quant-ph/9511010`

[P6] Xiao-Liang Qi and Daniel Ranard, *Emergent classicality in general multipartite states and channels*, arXiv:2001.01507v3, Theorem 1 and its trace-norm variant. Prior-art comparison; not a premise of (T).
`https://arxiv.org/html/2001.01507v3`
