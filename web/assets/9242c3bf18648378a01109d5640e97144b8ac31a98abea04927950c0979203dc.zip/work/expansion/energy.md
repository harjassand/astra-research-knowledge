# Energy-constrained zero-false-alarm sensing: exact exponent and physical boundaries

Status: internally derived mathematical statements below; finite floating checks are supporting illustrations, not interval certificates or external validation. Novelty is unresolved. The closest standard mechanisms are spectral typicality / quantum asymptotic equipartition, one-sided channel testing, and coding per unit cost.

## Decision

The useful outward application is **one-sided channel detection against a vacuum replacer**, with expected signal energy, unrestricted finite parallel blocklength, and no false alarms. It has an exact computable energy exponent, including a strict input-entanglement gain for an explicitly realizable detector with classical outputs. This application is tractable and sharper than a general claim about “quantum metrology.”

Three decisive boundaries prevent turning it into a broad physical claim:

1. If the channel is time-translation covariant with respect to the physical input energy and the output vacuum is stationary, the survival effect commutes with energy. The noncommuting gain is then absent.
2. Any faithful/full-support background makes exact-zero-false-alarm detection trivial. An arbitrarily small dark-count or thermal admixture changes the task discontinuously.
3. If feedback can stop illumination after a click and cost is charged only in expectation under the alternative, miss probability can approach zero at bounded expected energy. The logarithmic reliability cost law then fails.

Thus the strongest honest position is a finite-dimensional coherent-control sensing theorem with explicit accounting restrictions, not an autonomous thermodynamic advantage or a general quantum-illumination result.

## 1. Exact static theorem

Let the single-cell input space be finite dimensional. Let

\[
0<E\le I,\qquad H\ge0,\qquad \ker H=\mathbb C|0\rangle,
\qquad E|0\rangle=|0\rangle.
\]

Write \(A=-\log E\), \(H_+=H|_{0^\perp}\), and

\[
\alpha=\lambda_{\max}(H_+^{-1/2}A_+H_+^{-1/2}).
\]

Assume \(\alpha>0\); \(\alpha=0\) is the trivial detector. For \(m\) cells set \(H_m=\sum_iH_i\), \(A_m=\sum_iA_i\). Define

\[
s_*(Q)=\inf_{m\ge1,\,\rho_m:\,\operatorname{Tr}H_m\rho_m\le Q}
\operatorname{Tr}E^{\otimes m}\rho_m.
\]

The infimum allows all finite \(m\), arbitrary entanglement among signal cells, and mixed states. Then

\[
s_*(Q)\ge e^{-\alpha Q},\qquad
\lim_{Q\to\infty}\frac{-\log s_*(Q)}Q=\alpha.
\tag{1}
\]

Equivalently, the least expected signal energy for miss probability at most \(\eta\) obeys
\(Q_*(\eta)\sim\alpha^{-1}\log(1/\eta)\).

**Converse.** Since \(A\le\alpha H\), the spectral measure of \(A_m\) in \(\rho_m\) and ordinary scalar Jensen give

\[
-\log\operatorname{Tr}e^{-A_m}\rho_m
\le\operatorname{Tr}A_m\rho_m
\le\alpha\operatorname{Tr}H_m\rho_m.
\]

This uses no false operator inequality \(e^{-A}\ge e^{-\alpha H}\); exponentiation is not operator monotone for noncommuting matrices.

**Direct construction.** Choose a normalized active vector \(\psi\) maximizing
\(a/h=\langle A\rangle_\psi/\langle H\rangle_\psi=\alpha\).
Let \(R=\lambda_{\max}A-\lambda_{\min}A\),
\(\delta_m=R\sqrt{\log m/m}\), and let

\[
P_m=\mathbf1\{A_m\ge m(a-\delta_m)\},\qquad
\phi_m=\frac{P_m\psi^{\otimes m}}{\|P_m\psi^{\otimes m}\|}.
\]

The product spectral distribution of \(A_m\) satisfies Hoeffding, so
\(1-\langle P_m\rangle_{\psi^{\otimes m}}\le m^{-2}\).
Consequently

\[
\|\phi_m\phi_m^*-\psi^{\otimes m}(\psi^*)^{\otimes m}\|_1\le2/m,
\]

\[
\langle H_m\rangle_{\phi_m}\le mh+2\|H\|,
\qquad
\langle E^{\otimes m}\rangle_{\phi_m}
\le\exp[-ma+R\sqrt{m\log m}].
\tag{2}
\]

Choosing \(m=\lfloor(Q-2\|H\|)/h\rfloor\) gives
\(-\log s_*(Q)\ge\alpha Q-O(\sqrt{Q\log Q})\).
This proves (1) for all large budgets, rather than only along a subsequence. The finite remainder in (2) is not asserted optimal.

The projection is a state definition; an implementation must prepare the normalized state without discarding an uncharged failure branch. In the qutrit example below it is a supplied Dicke superposition and has standard deterministic preparation routes.

## 2. Operational meaning and idlers

Let \(\Phi:A\to B\) be any channel with a pure vacuum output
\(\Phi(|0\rangle\langle0|)=P_v\), and let the null channel be the vacuum replacer
\(\Xi(\rho)=P_v\operatorname{Tr}\rho\). Set \(E=\Phi^*(P_v)\).

For a parallel input \(\rho_{A^mR}\), the null output is
\(P_v^{\otimes m}\otimes\rho_R\). A detection effect \(M\) with exactly zero false-alarm probability must annihilate the support of this state. The alternative output lies in \(B^m\otimes\operatorname{supp}\rho_R\). Therefore the optimal zero-false-alarm effect on the relevant support is

\[
M=(I-P_v^{\otimes m})\otimes I_R.
\]

Its miss probability is exactly

\[
\operatorname{Tr}(P_v^{\otimes m}\otimes I_R)
(\Phi^{\otimes m}\otimes\operatorname{id})(\rho)
=\operatorname{Tr}E^{\otimes m}\rho_{A^m}.
\]

Hence (1) is the exact optimum zero-false-alarm channel-detection exponent per expected signal energy. Retained idlers cannot improve this particular criterion: even when their energy is uncharged, the zero-false-alarm support condition reduces the optimum to the signal marginal. This does not imply that idlers are useless for general asymmetric or symmetric detection.

## 3. Fully separable comparator and exact strict-gap criterion

The best product-pulse exponent is

\[
\beta=\max_{\psi\in0^\perp,\,\|\psi\|=1}
\frac{-\log\langle\psi|E|\psi\rangle}
{\langle\psi|H|\psi\rangle}.
\]

Vacuum admixture cannot raise this ratio, by convexity of \(-\log\), and the same inequality bounds every single-site mixed state. For every fully separable \(m\)-cell state,

\[
\operatorname{Tr}E^{\otimes m}\rho_m
\ge e^{-\beta\operatorname{Tr}H_m\rho_m}.
\tag{3}
\]

For a product state this follows by adding the single-site inequalities. For a convex mixture of products it follows by Jensen again. Thus classical correlations among pulses do not evade this comparator. Repeating a maximizing pulse gives the asymptotic separable exponent \(\beta\).

Always \(\beta\le\alpha\). For \(\alpha>0\), equality holds iff an active maximizing vector is both an eigenvector of \(A\) and a vector in \(\ker(\alpha H-A)\). Such a vector is automatically a common eigenvector of \(A,H\), with eigenvalue ratio \(\alpha\). The necessity is the equality case of the two inequalities in the converse; sufficiency is direct. Compactness and \(H_+>0\) turn absence of such a vector into a strict gap.

Noncommutation alone is therefore insufficient. The top generalized eigenspace must fail to contain a common eigenvector attaining the top ratio.

## 4. Minimal explicit sensor with classical outputs

Use a qutrit: one vacuum level and two active levels. On the active space take

\[
H_+=\begin{pmatrix}1&0\\0&4\end{pmatrix},\qquad
A_+=\begin{pmatrix}2&1\\1&2\end{pmatrix},\qquad E=1\oplus e^{-A_+}.
\]

Then

\[
\alpha=\frac{5+\sqrt{13}}4=2.151387818\ldots,
\quad
\psi_\alpha=\frac{(1,r)}{\sqrt{1+r^2}},
\quad r=\alpha-2.
\]

This top generalized eigenvector is unique up to phase and is not an \(A\)-eigenvector, proving \(\beta<\alpha\) without numerical optimization. For a product pulse the optimal relative phase is zero, and

\[
\beta=\max_{0\le\theta\le\pi/2}
\frac{2-\log[\cosh1-\sinh1\sin(2\theta)]}
{1+3\sin^2\theta}.
\]

The accompanying floating scan plus local optimization gives
\(\beta\approx1.714958504\), so the asymptotic exponent gain is about 25.45% and the energy needed at very small error is about 20.29% smaller. Those percentages are numerical illustrations; strict advantage is established by the exact equality criterion.

Realize the effect by the measure-and-prepare channel

\[
\Phi_t(\rho)=\operatorname{Tr}(e^{-tA}\rho)P_v
+\operatorname{Tr}[(I-e^{-tA})\rho]P_c,
\quad t>0,\quad P_vP_c=0.
\tag{4}
\]

Its outputs are classical orthogonal flags; the receiver simply declares presence if any cell clicks. The advantage comes from signal preparation, even though neither quantum receiver memory nor a collective output measurement is needed. This is a legitimate finite-dimensional CPTP detector, not a claim that an ordinary autonomous optical attenuator realizes it at no additional resource cost.

The projected probes can be written explicitly. Let \(u,v\) be the coordinates of \(\psi_\alpha\) in the \(A_+\)-eigenbasis of eigenvalues 1 and 3. With \(p=v^2\) and cutoff \(k_0\),

\[
|\phi_m\rangle=Z^{-1/2}\sum_{k=k_0}^{m}
\sqrt{\binom mk}\,u^{m-k}v^k|D_k^m\rangle,
\qquad Z=\Pr\{\operatorname{Bin}(m,p)\ge k_0\}.
\]

Here \(p=0.647996006\ldots\), \(a=2.295992012\ldots\), and \(h=1.067214378\ldots\). The exact finite formulas are

\[
s_m=Z^{-1}\sum_{k=k_0}^m\binom mk(1-p)^{m-k}p^k e^{-m-2k},
\]

\[
Q_m=\frac52m-3\sum_{k=0}^{m-1}c_kc_{k+1}\sqrt{(k+1)(m-k)},
\]

where \(c_k\) are the normalized displayed Dicke coefficients, zero below \(k_0\). These formulas avoid constructing the \(2^m\)-dimensional active state.

For the illustrative cutoff \(k_0=\lceil m(p-\tfrac14m^{-1/4})\rceil\), the finite checks give:

| Cells | Energy per cell | \(-\log s_m/Q_m\) |
|---:|---:|---:|
| 16 | 1.21592266 | 1.82510973 |
| 64 | 1.09899912 | 1.97661758 |
| 256 | 1.07244439 | 2.04296319 |
| 1024 | 1.06755408 | 2.07621418 |
| 65536 | 1.06721438 | 2.12270973 |

The finite values, including the comparison to the numerically optimized \(\beta\), are floating checks, not certified error bars. The analytic asymptotic strict gap does not depend on them.

## 5. Many-body concentration makes the probes tractable

For active dimension \(d\), the spectral projection commutes with permutations, so \(\phi_m\) is in \(\operatorname{Sym}^m(\mathbb C^d)\), of dimension \(\binom{m+d-1}{d-1}\). Across any bipartition its Schmidt rank is at most

\[
\min\left\{\binom{k+d-1}{d-1},\binom{m-k+d-1}{d-1}\right\}.
\]

It therefore has an exact MPS representation with polynomial bond dimension for fixed \(d\), and cut entanglement entropy at most \((d-1)\log(m+1)+O_d(1)\). The exponent gain does not require volume-law cut entanglement. For the qutrit's two active levels, it is an explicitly supplied superposition of only \(m+1\) Dicke states.

Dicke and arbitrary symmetric-state preparation already have deterministic polynomial-size constructions; this is not a new preparation method. [Bärtschi–Eidenbenz](https://arxiv.org/abs/1904.07358), [Raveh–Nepomechie](https://arxiv.org/abs/2408.04729).

An approximation with trace error \(\epsilon\) can change the miss probability by \(\epsilon\). To preserve an exponentially small target miss probability, preparation errors must also be exponentially small in energy. Polynomial description size and logarithmic cut entanglement alone do not establish experimental feasibility or free preparation cost.

## 6. Robust unknown detector strength: a solved composite instance

In (4), let the unknown fixed strength satisfy \(t\in[t_0,t_1]\), \(t_0>0\), with known \(A,H\). Because the matrices are all functions of the same \(A\),

\[
e^{-tA}\le e^{-t_0A}.
\]

Tensor products preserve this positive order. The same probe sequence optimized for \(t_0\) works for every admissible \(t\); the worst channel is actually in the uncertainty set. Consequently the exact minimax energy exponent is

\[
\alpha_{\mathrm{robust}}=t_0\alpha(A,H),
\]

and the fully separable minimax exponent is \(\beta_{t_0}\). No estimation of \(t\) is needed. The same conclusion holds for any alternative set admitting an attained Loewner-largest survival effect \(\bar E\): its exact exponent is \(\alpha(\bar E,H)\).

This does **not** solve an arbitrary composite family of noncommuting survival effects. Separate spectral typicality for different \(-\log E_j\) does not by itself produce a single state with all required exponentially small survivals.

## 7. Thermodynamic covariance obstruction

Suppose \(H\) is the physical input Hamiltonian, \(H_B\) the output Hamiltonian, and

\[
\Phi(e^{-itH}\rho e^{itH})=e^{-itH_B}\Phi(\rho)e^{itH_B},
\qquad [P_v,H_B]=0.
\]

The adjoint covariance equation yields
\(e^{itH}\Phi^*(P_v)e^{-itH}=\Phi^*(P_v)\) for all \(t\), hence
\([E,H]=0\). Joint eigenvectors then give \(\alpha=\beta\), with no input-entanglement exponent gain.

This is a direct proof from the covariance definition, not an imported theorem. Time-translation covariance and coherence accounting are standard in quantum thermodynamics; see [Gour](https://arxiv.org/abs/2205.13612). A noncommuting detector relative to bare input energy needs a noncovariant control/reference somewhere in its implementation. If that drive, reference, or preparation is charged, the expected signal-energy optimum above is no longer a complete thermodynamic resource accounting.

For a fixed-frequency pure-loss optical channel, \(E=(1-\eta)^N\) and \(H=N\), so \(\alpha=-\log(1-\eta)\); number-state pulses already attain it. This familiar passive model gives no new noncommuting gain. PPM and communication per unit cost are established ideas; see [Ding–Pavlichin–Wilde](https://arxiv.org/abs/1705.08878).

## 8. Thermal background and feedback obstructions

**Faithful null.** Replace the null output vacuum by any full-support state \(\sigma_0\). For any finite parallel block and any retained idler, the null support is \(B^m\otimes\operatorname{supp}\rho_R\), which contains the alternative support. A positive detection effect with \(\operatorname{Tr}[(\sigma_0^{\otimes m}\otimes\rho_R)M]=0\) must vanish on that entire support. Detection probability is zero and miss probability is one. In particular, a nonzero dark-count probability in the two-flag sensor destroys exact-zero-false-alarm detectability.

Allowing a positive false-alarm tolerance instead gives a different hypothesis-testing problem. Existing noisy-background quantum illumination results use different asymmetry/error constraints and resource interfaces; this theorem does not improve them. [De Palma–Borregaard](https://arxiv.org/abs/1802.02158).

**Stop-on-click.** A fixed probe with energy \(h\) and no-click probability \(e<1\) is sent until a click or a horizon \(k\). Under the alternative,

\[
\Pr(\text{miss})=e^k,\qquad
\mathbb E_{\mathrm{alt}}[\text{energy}]
=h\frac{1-e^k}{1-e}\le\frac h{1-e}.
\]

Thus finite horizons make miss arbitrarily small at uniformly bounded alternative-expected energy. Under the vacuum null, all \(k\) probes are sent and the energy is \(kh\). A worst-hypothesis expected-energy constraint or an explicitly charged null prior changes this accounting; the original static law cannot be transferred to risk-sensitive adaptive control without fixing which probability law pays for cost.

## 9. Weak-signal metrology does not acquire a new scaling

For \(E_t=e^{-tA}\), the entangled reliability exponent is exactly \(t\alpha\). Uniform expansion on the active space gives

\[
-\log\langle e^{-tA}\rangle_\psi
=t\langle A\rangle_\psi-\tfrac12t^2\operatorname{Var}_\psi A+O(t^3),
\qquad
\lim_{t\downarrow0}\beta_t/t=\alpha.
\]

When the top generalized eigenvector is simple,

\[
\beta_t=t\alpha-
\frac{t^2\operatorname{Var}_{\psi_\alpha}A}{2h}+O(t^3).
\]

For the qutrit, the second-order coefficient is about 0.4275. The finite-strength gain is real, but products already achieve the same leading \(1/t\) energy required for a fixed miss target. There is no new weak-signal exponent scaling.

There is also an elementary Fisher-information bound for (4). An arbitrary entangled input induces a parameter-independent probability distribution on the product \(A\)-eigenlabels \(a_1,\ldots,a_m\). Conditioned on those labels, the flags are independent Bernoulli variables with no-click probabilities \(e^{-ta_i}\). Revealing the hidden labels can only increase available information, so every measurement has classical Fisher information at most

\[
\sum_i\mathbb E\frac{a_i^2}{e^{ta_i}-1}
\le\frac1t\operatorname{Tr}A_m\rho
\le\frac{\alpha Q}{t}.
\]

This argument also permits idlers: conditioned on a revealed eigenlabel, their state is independent of \(t\), so they cannot exceed the revealed-label experiment. Product probes \(\psi_\alpha\) attain the leading coefficient \(\alpha Q/t\) as \(t\downarrow0\). The reliability advantage does not establish an entanglement gain in the leading weak-coupling Fisher information.

## 10. What remains unproved or uncharged

- Priority of the exact optimized cost-normalized formula and the strict classical-output detector example has not been settled. Smooth-entropy / spectral-typicality precedents need comparison beyond abstracts; see [Datta–Mosonyi–Hsieh–Brandão](https://arxiv.org/abs/1106.3089).
- Hard peak-energy support, constrained state preparation, clock/reference costs, and correlated noise are not covered by (1). In particular, the gentle comparison of expected energy in (2) does not prove a hard energy-support bound.
- The robust statement solves an ordered survival family, not arbitrary uncertainty in noncommuting effects.
- Numerical product optima and finite block comparisons below have no rigorous interval certificate. The exact asymptotic gap has a separate analytic proof.
- If \(E\) has a zero eigenvalue at positive cost, exact detection can occur at finite energy and the finite \(\alpha\) law does not apply. If a zero-cost input already changes the null output, there can be free detection and the common-vacuum interface fails.

## Reproduction

Files: `work/expansion/energy_probe.py`, `work/expansion/energy_probe.json`.

Command used successfully:

```
/Users/harjas/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 work/expansion/energy_probe.py
```

Requires numpy only. The script performs a dense one-dimensional product-pulse scan, refines each local maximum, evaluates exact-formula symmetric blocks in floating arithmetic, and checks the generalized eigenvector identity and the converse/cutoff inequalities numerically. It does not execute a quantum circuit, certify intervals, or prove asymptotics.
