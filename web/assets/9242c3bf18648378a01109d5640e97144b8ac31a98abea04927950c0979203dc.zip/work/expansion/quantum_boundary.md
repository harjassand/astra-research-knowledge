# Expansion from pure coherent compression into quantum boundaries

Status: analytic theorem candidates with a complete finite-spin cutoff proof and a complete shrinking-temperature cutoff proof. The arbitrary-hybrid pure converse is imported from `pure_quantum_lower`; its exact interface was checked with that worker. The finite-spin moment identity was independently checked by `quantum_statistics`. These are scoped mathematical derivations, not an external correctness or novelty certificate.

The useful extension is **uniform memory at a rank-changing boundary, at arbitrary target precision**. A LAN approximation with error of order `1/n` cannot resolve compression at error much smaller than `1/n`. The exact Schur calculation below does. A related Gaussian theorem shows that the same optimal pure quantum-memory exponent survives an unknown thermal component that vanishes only polynomially in the precision logarithm.

## 1. Legal interface and the imported pure mechanism

An encoder is a blind physical CPTP instrument with classical output `x` and a quantum state in a space of dimension `Q_x`. A decoder may use `x`. The classical output is dephased and can have arbitrarily many values. Set

\[
Q=\sup_x Q_x.
\]

There is no parameter oracle, input-dependent external side channel, or preshared encoder-decoder entanglement. Independent public randomness is allowed. The decoded state averages all instrument outcomes; the error is

\[
\sup_\theta T(\mathcal D\mathcal E(\rho_\theta),\rho_\theta),
\qquad T(\rho,\sigma)=\tfrac12\|\rho-\sigma\|_1.
\]

If classical information is charged, its direct-sum algebra dimension is

\[
D=\sum_x Q_x.
\]

Thus a bound on `Q` is stronger than a quantum-only cutoff upper bound, but it is not a bound on total `D`.

Write

\[
L=\log(1/\varepsilon),\qquad
h(\varepsilon)=\frac{L}{\log(e+L)}.
\]

Constants below depend on fixed radii, fixed mode count, and the stated noise envelope, never on `n` or `epsilon`.

Imported pure converse: for a pure ensemble `psi_theta` whose pairwise overlaps have magnitude at least `c>0`, average reconstruction error at most `epsilon` implies

\[
F_e(\bar\rho,\mathcal D\mathcal E)
\geq 1-\frac{2\sqrt\varepsilon+\varepsilon}{c}.
\]

Recovery through branches of dimension at most `Q` leaves the purification with Schmidt number at most `Q`. Consequently

\[
F_e\leq\sum_{j=1}^{Q}\lambda_j(\bar\rho).
\]

For the small torus `z_a=r exp(i theta_a)`, with `q r^2` sufficiently small, the local pure qudit average has eigenvalues

\[
p_n(m)=\frac{(n)_{|m|}}{n^{|m|}}
\frac{r^{2|m|}}{m!}(1+qr^2/n)^{-n},\qquad |m|\leq n.
\]

For every `|m|<=K<=n`,

\[
p_n(m)\geq e^{-qr^2}\frac{(r^2/e)^K}{K!}.
\]

The inequality `(n)_k/n^k >= exp(-k)` follows by comparing the decreasing logarithm sum to its integral. There are `binom(K+q,q)` such modes. With `K` a small constant multiple of `min(n,h(epsilon))`, their minimum mass dominates `sqrt(epsilon)`. This forces

\[
Q\gtrsim (1+\min\{n,h(\varepsilon)\})^q.
\]

For bounded oscillator coherent states, use independent Poisson spectra instead, with no finite-`n` saturation. This converse permits unlimited measurement-generated classical information.

## 2. Exact finite-copy theorem at a rank-changing qubit boundary

Fix `R>0` and `Lambda>=0`. For `n>=max(1,ceil(4 Lambda))`, define

\[
U_{n,z}=\frac1{\sqrt{1+|z|^2/n}}
\begin{pmatrix}1&-\bar z/\sqrt n\\z/\sqrt n&1\end{pmatrix},
\]

\[
\sigma_{n,\lambda,z}=
\left[U_{n,z}
\begin{pmatrix}1-\lambda/n&0\\0&\lambda/n\end{pmatrix}
U_{n,z}^*\right]^{\otimes n},
\quad 0\leq\lambda\leq\Lambda,\quad |z|\leq R.
\]

The fiducial basis, `n`, `R`, and `Lambda` are known; `lambda,z` are not. This includes pure states at `lambda=0` and rank-two states for `lambda>0`.

**Theorem candidate.** For sufficiently small `epsilon`, uniformly over all allowed `n`, the least possible maximum quantum branch dimension satisfies

\[
Q_{n,\varepsilon}\asymp
1+\min\{n,h(\varepsilon)\}.
\tag{B1}
\]

This allows arbitrary free classical information, and has no requirement such as `epsilon >> 1/n`. The upper bound has an explicit CPTP encoder/decoder. The lower bound is the `lambda=0` restriction plus the imported pure converse.

### 2.1 Exact Schur structure

Schur-Weyl decomposition writes the input, up to one known unitary, as

\[
\sigma_{n,\lambda,z}
=\bigoplus_{k=0}^{\lfloor n/2\rfloor}
p_{n,\lambda}(k)
\left[U_{t,z}\tau_{t,\lambda}U_{t,z}^*
\otimes\frac{I_{m_{n,k}}}{m_{n,k}}\right],
\quad t=n-2k,
\]

where `U_{t,z}` is `U_{n,z}^{tensor t}` on the symmetric `t`-qubit subspace, and

\[
p=\lambda/n,\quad r=\frac p{1-p},\quad
\tau_{t,\lambda}
=\frac{1-r}{1-r^{t+1}}
\sum_{\ell=0}^{t}r^\ell|D_{t,\ell}\rangle\langle D_{t,\ell}|.
\tag{B2}
\]

At `r=0`, the formula is its literal vacuum limit. At `t=0`, the block is one-dimensional. Here `D_{t,ell}` is the Dicke state with `ell` ones, and

\[
m_{n,k}=\binom nk-\binom n{k-1}.
\]

The encoder nondestructively reads `k`, discards the maximally mixed multiplicity factor, and retains the spin state. The decoder can exactly regenerate the multiplicity factor and perform the inverse Schur unitary.

This decomposition and the thermal spin-block formula are established ingredients in qubit compression; the new calculation being assessed is the uniform joint `(n,epsilon)` cutoff below. [Yang, Chiribella and Hayashi, 2016](https://arxiv.org/html/1606.02893v3)

### 2.2 Exact factorial moments of the rotated thermal spin block

Let `N` count ones in the known fiducial Dicke basis and set

\[
a=\frac{|z|^2}{n+|z|^2}.
\]

For integers `1<=K<=t`, the exact identity is

\[
\mathbb E[(N)_K]
=\sum_{j=0}^{K}\binom Kj^2
a^{K-j}(1-a)^j
\mathbb E_\ell[(\ell)_j(t-\ell)_{K-j}].
\tag{B3}
\]

Derivation, including the interference issue:

1. `(N)_K` is the sum of the products of one-site number projectors over all ordered tuples of `K` distinct sites. Permutation symmetry makes its expectation `(t)_K` times a `K`-site projector expectation.
2. The `K`-site reduced state of `D_{t,ell}` is

   \[
   \sum_j\frac{\binom\ell j\binom{t-\ell}{K-j}}{\binom tK}
   |D_{K,j}\rangle\langle D_{K,j}|.
   \]

   It is diagonal in these occupation sectors because tracing the other `t-K` sites kills terms with unequal remaining excitation counts.
3. The rotated one-site projector is rank one. Its `K`-fold overlap with `D_{K,j}` is

   \[
   \binom Kj a^{K-j}(1-a)^j.
   \]

4. Multiplying these expressions and converting binomial coefficients to falling factorials gives (B3). The square on `binom(K,j)` is essential: it retains the symmetric-state enhancement. For example `t=2,ell=1,K=2,a=1/2` gives `E[(N)_2]=1`, rather than the independent-particle answer.

Since `p<=1/4`,

\[
\frac r{1-r}=\frac p{1-2p}\leq\frac{2\Lambda}{n},
\qquad
\frac1{1-r^{t+1}}\leq\frac1{1-r}\leq\frac32.
\]

The truncated geometric distribution therefore obeys

\[
\mathbb E[(\ell)_j]
\leq\frac{j!}{1-r^{t+1}}\left(\frac r{1-r}\right)^j
\leq\frac32j!\left(\frac{2\Lambda}{n}\right)^j.
\tag{B4}
\]

For the other factor,

\[
(t-\ell)_{K-j}a^{K-j}\leq(ta)^{K-j}\leq R^{2(K-j)}.
\]

Use `j! binom(K,j)=(K)_j<=K^j` and `K<=t<=n` in (B3). The binomial theorem then yields

\[
\boxed{\mathbb E[(N)_K]\leq\frac32(R^2+2\Lambda)^K.}
\tag{B5}
\]

Thus, with `A=R^2+2 Lambda`,

\[
\boxed{\Pr(N\geq K)\leq\frac32\frac{A^K}{K!}.}
\tag{B6}
\]

When `K>t`, the tail is zero. When `t=0`, it is zero for every positive `K`. The formula is valid for `n=1` whenever the stated domain imposes `Lambda<=1/4`.

### 2.3 A physical cutoff and its reconstruction error

For each classical `k`, retain

\[
\Pi_{t,K}=\sum_{m=0}^{\min(t,K-1)}|D_{t,m}\rangle\langle D_{t,m}|.
\]

The CPTP cutoff replaces the discarded trace by the known vacuum:

\[
\mathcal P_{t,K}(\rho)=\Pi_{t,K}\rho\Pi_{t,K}
+\operatorname{Tr}[(I-\Pi_{t,K})\rho]|D_{t,0}\rangle\langle D_{t,0}|.
\]

It can be encoded into a quantum space of dimension `min(K,t+1)`. The decoder uses the recorded `k` to restore the corresponding spin space. By the gentle projection bound and the triangle inequality,

\[
T(\mathcal P_{t,K}(\rho),\rho)
\leq2\sqrt{\operatorname{Tr}[(I-\Pi_{t,K})\rho]}.
\]

The Schur block average obeys the same uniform bound, so (B6) gives

\[
\varepsilon_{\rm cutoff}\leq
2\sqrt{\frac32\frac{A^K}{K!}}.
\tag{B7}
\]

Choose `K` to make (B7) at most `epsilon`, or retain the whole spin space if this requires `K>n`. Stirling's formula gives `K=O(1+h(epsilon))`, proving the upper bound in (B1), with saturation at `n+1`.

For the lower bound, restrict to `lambda=0`. The input is precisely

\[
\left(\frac{|0\rangle+(z/\sqrt n)|1\rangle}{\sqrt{1+|z|^2/n}}\right)^{\otimes n}.
\]

A sufficiently small circle inside `|z|<=R` has uniformly nonzero pairwise overlaps, and its average has `n+1` binomial eigenvalues. Section 1 forces `Q` of order `1+min(n,h(epsilon))` even after arbitrary classical measurements.

### 2.4 Exact charged-total-memory upper bound

The known-basis Schur joint distribution of `k,ell` is

\[
\Pr(k,\ell)=m_{n,k}(1-p)^{n-k-\ell}p^{k+\ell}.
\]

Its sum `X=k+ell` is exactly `Bin(n,p)`: for any `X`, the multiplicities telescope to `binom(n,X)`. In particular

\[
\Pr(k\geq J)\leq\Pr(X\geq J)
\leq\frac{\Lambda^J}{J!}.
\tag{B8}
\]

Store only `k<J`, and send all other sectors to an overflow label with a fixed output. This adds trace error at most the discarded mass. Combining (B7) and (B8),

\[
\varepsilon\leq\frac{\Lambda^J}{J!}
+2\sqrt{\frac32\frac{A^K}{K!}}.
\tag{B9}
\]

With `J,K=O(1+h(epsilon))`, and full-register saturation when necessary,

\[
D\lesssim(1+\min\{n,h(\varepsilon)\})^2.
\tag{B10}
\]

This is an upper bound only. A matching total-`D` converse cannot be inferred from the pure endpoint: that endpoint forces only one factor. `quantum_statistics` is independently investigating the second factor using the variable Poisson/spectral coordinate.

### 2.5 Beyond a bounded number of rare defects

The quantum-memory result has a wider purity envelope. Replace the eigenvalue `lambda/n` by an unknown `p` in `[0,b(epsilon)]`, with `b<=1/4`, while keeping the same known-fiducial local rotation. In (B4), use `r/(1-r)<=2b` without the `1/n` bound. The same exact calculation gives

\[
\mathbb E[(N)_K]\leq\frac32(R^2+2Kb)^K,
\quad
\Pr(N\geq K)\leq\frac32[eR^2/K+2eb]^K.
\tag{B10a}
\]

For any fixed `a>0,B<infinity`, if `b(epsilon)<=B h(epsilon)^(-a)`, choose `K=C h(epsilon)` as in Section 4, or retain the full spin if this exceeds its dimension. The pure endpoint gives the matching converse, so

\[
Q_{n,\varepsilon}\asymp1+\min\{n,h(\varepsilon)\}.
\tag{B10b}
\]

This holds even when `n b(epsilon)` grows without bound: the large spectral-defect coordinate is carried classically. The charged-total bound (B10) is not asserted for this wider envelope; its bounded-mean defect cutoff was specific to `n p<=Lambda`.

## 3. Several independent boundary modes

Take a fixed number `q` of independent qubit boundary experiments of Section 2, each with `n` copies, independent bounded `lambda_a,z_a`, and all noise-zero endpoints allowed. Record the vector of Schur defects classically. Conditional on this vector the retained spin states are products.

Falling factorials of the total known-basis excitation satisfy

\[
\mathbb E[(N_1+\cdots+N_q)_K]
\leq(3/2)^q\left(\sum_a(R_a^2+2\Lambda_a)\right)^K.
\]

The proof expands the total falling factorial multinomially and uses (B5) in each coordinate. Any index exceeding that coordinate's spin length contributes zero. A total-excitation cutoff has dimension at most `binom(K+q-1,q)`, and the full-spin product has dimension at most `(n+1)^q`.

Restricting to all `lambda_a=0` gives a `q`-torus pure ensemble with product binomial eigenvalues. The same Schmidt-number argument proves

\[
Q_{n,\varepsilon}^{(q)}\asymp
(1+\min\{n,h(\varepsilon)\})^q.
\tag{B11}
\]

This is an exact product-sensor theorem. It is not a statement about every rank-deficient `d`-dimensional state family. The same two cutoffs give a charged-total upper bound of order `(1+min(n,h))^(2q)`.

## 4. Uniform low-temperature Gaussian robustness

Let `q` be fixed and `R>0`. Consider the family

\[
\rho_{\alpha,\nu}=\bigotimes_{a=1}^{q}
D_{\alpha_a}\tau_{\nu_a}D_{\alpha_a}^*,
\qquad \|\alpha\|\leq R,\quad 0\leq\nu_a\leq b(\varepsilon),
\]

where `tau_nu` is the thermal state of mean occupation `nu`, i.e. its geometric parameter is `beta=nu/(1+nu)`. All parameters are unknown to one fixed blind encoder/decoder. Thermal states admit a positive Gaussian mixture of coherent states, as used in displaced-thermal compression. [Yang, Bai, Chiribella and Hayashi, 2018](https://arxiv.org/html/1701.03372v4)

For one mode, Gaussian mixing and the Poisson factorial moments of a coherent state give the exact identity

\[
\mathbb E[(N)_K]=\mathbb E|\alpha+G|^{2K}
=\sum_{j=0}^{K}\binom Kj^2j!\nu^j|\alpha|^{2(K-j)},
\quad G\sim\mathcal{CN}(0,\nu).
\]

Using `(K)_j<=K^j`,

\[
\mathbb E[(N)_K]\leq(|\alpha|^2+K\nu)^K.
\]

Expand total-mode factorial moments multinomially and bound each coordinate index by `K`:

\[
\boxed{\mathbb E[(N_{\rm total})_K]
\leq(R^2+K\sum_a\nu_a)^K.}
\tag{B12}
\]

Hence

\[
\Pr(N_{\rm total}\geq K)
\leq\frac{(R^2+Kq b)^K}{K!}
\leq[eR^2/K+eqb]^K.
\tag{B13}
\]

**Theorem candidate.** Fix any `a>0` and `B<infinity`. If

\[
b(\varepsilon)\leq B h(\varepsilon)^{-a},
\tag{B14}
\]

then the optimal arbitrary-hybrid quantum branch dimension satisfies

\[
\boxed{Q_\varepsilon\asymp(1+h(\varepsilon))^q.}
\tag{B15}
\]

Indeed, choose `K=C h(epsilon)` with `C>2/min(a,1)` enlarged as necessary. The logarithm of (B13) is at most

\[
-C\min\{a,1\}\,h\log h+O_{q,R,B,C}(h),
\]

which is below `-2 log(1/epsilon)` for sufficiently small error, because `h log h ~ L`. The physical Fock cutoff therefore attains trace error `epsilon` with quantum dimension `binom(K+q-1,q)=O(h^q)`. The temperature-zero subfamily gives the matching arbitrary-hybrid lower bound.

This is stronger than the elementary perturbation transfer, which would require noise to be small on the scale of the requested reconstruction error to preserve the same lower bound. Here the envelope can be enormously larger than `epsilon`.

**Load-bearing limitation:** the allowed family contains the pure endpoint. This proof does not show the same lower bound for a fixed strictly positive temperature, or for an unknown-temperature interval that excludes zero. It also does not prove a sharp transition outside (B14). Equation (B13) remains a valid upper bound outside that regime.

## 5. What extends, and what remains a gap

- **Independent classical times pure experiment.** For `gamma_u tensor |alpha><alpha|`, with independently variable `u,alpha` and an already classical first factor, unlimited classical memory gives exactly the pure factor's quantum-memory requirement. Store the classical observation; for the lower bound fix `u` and discard the classical output. This also applies to a classical Poisson coordinate times bounded coherent modes. It fails as stated if a classical input supplies the coherent parameter itself.
- **LAN transfer.** Bidirectional channels with uniform error `delta_n` transfer a converse at effective error `epsilon+2 delta_n`, and an upper bound only when there is room for the channel errors. They cannot establish the requested all-precision law. The exact spin argument supplies that missing step in the qubit boundary.
- **Higher rank.** Fixed-rank unitary LAN can have coherent support-kernel modes and positive-temperature internal modes. A lower bound from a pure factor is useful, but cannot determine the full mixed-mode optimum. Arbitrary rank-changing qudit models can also retain quantum information in rare internal marks; neither the qubit product theorem nor a classical Poisson replacement settles that model. Tsang's quantum Poisson formalism is pertinent prior work, rather than a new object here. [Tsang, 2021](https://quantum-journal.org/papers/q-2021-08-19-527/)
- **Reference frames.** The qubit theorem applies to a known fiducial axis and unknown rotations of order `1/sqrt(n)`. It gives faithful storage of local orientation information at finite precision. The global unknown-frame problem needs an explicitly charged localization step and cannot be claimed from this theorem.
- **Learning and downstream decisions.** Any POVM chosen after decoding inherits at most the trace-distance error in its output law. This makes the memory an approximate statistical experiment for future decisions. It supplies no theorem about efficient acquisition, accelerated learning, or computational runtime.
- **Fixed thermal temperature.** The elementary perturbation transfer has `delta=1-product_a(1-beta_a)`. It gives only the pure converse at `epsilon+2delta`, which stops improving when the temperature is fixed. A mixed-state quantitative irreducibility/recovery theorem would be needed to resolve the precision-dependent optimum there.

## 6. Primary literature check and priority boundary

1. [Acharya and Guţă, *Minimax estimation of qubit states with Bures risk* (2017)](https://arxiv.org/html/1708.04941v2), Sections 3 and 5: explicit Schur blocks for near-pure qubits, the binomial coordinate, spin LAN, and the Poisson scaling `n lambda -> mu`. These ingredients predate this run. The target here is a uniform finite-copy hybrid-memory law for arbitrarily small reconstruction error, rather than an estimation risk.
2. [Yang, Chiribella and Hayashi, *Optimal Compression for Identically Prepared Qubit States* (2016)](https://arxiv.org/html/1606.02893v3): global known-spectrum and full-model compression, hybrid use of the Schur label, and cloning-based modulation of spin length. The examined statements do not give (B1)'s joint precision/local-boundary law. This limited check is not proof that the law is absent elsewhere.
3. [Yang, Bai, Chiribella and Hayashi, *Compression for quantum population coding* (2018)](https://arxiv.org/html/1701.03372v4): asymptotically faithful compression of nondegenerate finite-dimensional models and displaced thermal states, with a quantum/classical tradeoff and photon cutoff. Its main stated error is polynomial in copy count. Positive-temperature compression and a cutoff protocol are established prior art; the point assessed in (B14)-(B15) is the sharp pure exponent uniformly over a precision-dependent shrinking temperature envelope.
4. [Namiki, *Schmidt-number benchmarks for continuous-variable quantum devices* (2016)](https://arxiv.org/abs/1511.03321): finite coherence-dimension bounds from coherent-state fidelity benchmarks. Schmidt-number benchmarking is prior art. The compact worst-case, all-precision rank-changing theorem must be distinguished from those Gaussian-prior benchmarks.
5. [Tsang, *Poisson Quantum Information* (2021)](https://quantum-journal.org/papers/q-2021-08-19-527/): rare quantum objects and quantum Poisson information. This blocks a novelty claim for introducing quantum Poisson boundary experiments themselves.
6. [Barnum, Hayden, Jozsa and Winter, *On the reversible extraction of classical information from a quantum source* (2001)](https://arxiv.org/html/quant-ph/0011072v2): irreducible pure sources cannot replace quantum information by arbitrarily large free classical storage in the asymptotic source-coding setting. The nonorthogonal Stinespring information-disturbance mechanism is therefore established prior art; the assessed novelty is a sharp finite-precision law for these bounded local and mixed-boundary experiments.

No located primary result was identified as an exact statement of (B1), (B11), or (B14)-(B15). This was a bounded screen, not a comprehensive priority clearance. The most defensible next target is to assemble the exact finite-spin theorem and its pure converse as one formally audited result, with the charged-total lower bound separately proved or explicitly left open.

## 7. Checks performed

`quantum_statistics` independently verified the reduced-Dicke-state derivation of (B3), the two bounds entering (B5), the `t=0` case, and the `n=1` domain edge. `pure_quantum_lower` confirmed that the noise-zero restrictions in both theorems fit its arbitrary-hybrid lower interface, and checked the exponent in (B13)-(B15).

The package-free diagnostic `quantum_boundary_check.py` builds the finite rotated Dicke amplitudes directly and compares them with (B3), (B5), and (B6). Across 1,638 moment/tail comparisons with `t<=12`, including `t=0,n=1`, all checks passed. The largest relative moment discrepancy was approximately `3.6e-15`; normalization discrepancy was approximately `3.0e-15`. These finite diagnostics do not prove the uniform theorem; the analytic argument above is the evidence for that claim.
