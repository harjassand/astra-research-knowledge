# Constructive noncommuting energy exponent: finite qutrit witnesses

**Result.** For the supplied qutrit effect and mean-cost observable

\[
E=\operatorname{diag}(1,e^{-1},e^{-4}),\qquad
H=0\oplus\begin{pmatrix}1&1/2\\1/2&1\end{pmatrix},
\]

the exponent

\[
\alpha=\frac{10+2\sqrt{13}}3
\]

is attained asymptotically by an explicit family of pure states. Each state
has a polynomial classical description, a preparation circuit with
\(O(n\log n)\) exact reversible gates and \(O(\log n)\) clean ancillas,
plus \(n\) single-qubit rotations in the excited subspace. Approximate
rotation synthesis at inverse-polynomial accuracy preserves the exponent
bound because the final spectral-support restriction is exact. A finite
universal gate set gives an unconditional \(O(n\log^{3.97}n)\) synthesis
bound through Solovay–Kitaev.

For every state of entanglement depth at most \(k\), including mixtures
over different partitions and vacuum occupation patterns,

\[
\frac{-\log\operatorname{Tr}(E^{\otimes N}\rho)}
{\operatorname{Tr}(H_N\rho)}
\leq\alpha-\frac{c}{k^2},\qquad
c=0.0529573641543205\ldots>0,
\tag{1}
\]

when its mean cost is positive. Thus no fixed finite entanglement depth
reaches \(\alpha\). Achieving \(\alpha-\varepsilon\) requires
\(k\geq\sqrt{c/\varepsilon}\); this is a loose necessary bound, while the
construction supplies the sufficient bound
\(k=O(\varepsilon^{-2}\log(1/\varepsilon))\). These bounds do not identify
the optimal dependence of depth on accuracy.

This is a construction for a **known, supplied pair \((E,H)\)** under a
mean-input-cost model. It does not establish efficient acquisition of an
unknown channel, impose a hard spectral-energy cutoff, or remove the
channel-use cost of a pulse-position code.

## 1. Exact local algebra and the upper bound

Let \(L=-\log E=\operatorname{diag}(0,1,4)\), and define

\[
\begin{aligned}
t&=\frac{3+\sqrt{13}}4, &
p&=\frac{t^2}{1+t^2}=\frac{23+6\sqrt{13}}{61},\\
w&=\sqrt{1-p}\,|1\rangle-\sqrt p\,|2\rangle, &
s&=\sqrt{p(1-p)}=\frac{9+5\sqrt{13}}{61},\\
h&=\langle w,Hw\rangle=1-s=\frac{52-5\sqrt{13}}{61}, &
\ell&=\langle w,Lw\rangle=1+3p=\frac{130+18\sqrt{13}}{61}.
\end{aligned}
\]

Numerically,

\[
p=0.7316935680784251\ldots,\quad
h=0.5569220266013124\ldots,\quad
\ell=3.1950807042352753\ldots.
\]

The excited-block generalized eigenvalue equation is

\[
\det\begin{pmatrix}1-\lambda&-\lambda/2\\
-\lambda/2&4-\lambda\end{pmatrix}
=4-5\lambda+\tfrac34\lambda^2=0.
\]

Its larger root is \(\alpha\), and
\((L-\alpha H)w=0\). Hence \(L\leq\alpha H\) and \(\ell=\alpha h\).
For \(H_n=\sum_iH_i\), \(L_n=\sum_iL_i\), and any density matrix \(\rho\),
scalar Jensen applied to its spectral distribution under \(L_n\) gives

\[
-\log\operatorname{Tr}(E^{\otimes n}\rho)
=-\log\operatorname{Tr}(e^{-L_n}\rho)
\leq\operatorname{Tr}(L_n\rho)
\leq\alpha\operatorname{Tr}(H_n\rho).
\tag{2}
\]

No commutation of \(\rho,L_n,H_n\) is needed for this argument.

## 2. The finite state and its exact overlap and cost

On \(n\) excited two-level systems, let \(|D^n_j\rangle\) be the normalized
uniform sum of strings with exactly \(j\) copies of \(|2\rangle\) and
\(n-j\) copies of \(|1\rangle\). Write

\[
B_{n,p}(j)=\binom njp^j(1-p)^{n-j}.
\]

Then

\[
w^{\otimes n}=\sum_{j=0}^n(-1)^j\sqrt{B_{n,p}(j)}\,|D^n_j\rangle,
\qquad L_n|D^n_j\rangle=(n+3j)|D^n_j\rangle.
\]

Choose integers \(0\leq a\leq b\leq n\), define

\[
\eta_n=\sum_{j=a}^bB_{n,p}(j)>0,\qquad
\psi_n=\frac1{\sqrt{\eta_n}}
\sum_{j=a}^b(-1)^j\sqrt{B_{n,p}(j)}\,|D^n_j\rangle.
\tag{3}
\]

This is the normalized coherent interval projection of \(w^{\otimes n}\).
It is described by at most \(n+1\) amplitudes rather than \(2^n\) amplitudes.
Its vacuum/failure overlap is exactly

\[
A_n=\langle\psi_n,E^{\otimes n}\psi_n\rangle
=\frac{e^{-n}}{\eta_n}\sum_{j=a}^bB_{n,p}(j)e^{-3j}.
\tag{4}
\]

For evaluation one can also use a binomial tilt:

\[
A_n=\big[e^{-1}(1-p+pe^{-3})\big]^n
\frac{\Pr\{\operatorname{Bin}(n,p')\in[a,b]\}}{\eta_n},
\qquad p'=\frac{pe^{-3}}{1-p+pe^{-3}}.
\]

The cost requires the adjacent-type coherences. On this symmetric basis,

\[
\langle D^n_{j+1},H_nD^n_j\rangle
=\frac12\sqrt{(n-j)(j+1)}.
\]

Consequently,

\[
Q_n=\langle\psi_n,H_n\psi_n\rangle
=n-\frac1{\eta_n}\sum_{j=a}^{b-1}
\sqrt{B_{n,p}(j)B_{n,p}(j+1)(n-j)(j+1)}.
\tag{5}
\]

The summand equals \(nsB_{n-1,p}(j)\). If

\[
\gamma_n=\Pr\{\operatorname{Bin}(n-1,p)\in[a,b-1]\},
\]

with the usual empty-range convention, the exact cost becomes

\[
Q_n=n\left(1-s\frac{\gamma_n}{\eta_n}\right).
\tag{6}
\]

In particular,

\[
\eta_n-\gamma_n
=(1-p)B_{n-1,p}(b)+pB_{n-1,p}(a-1),
\tag{7}
\]

where the binomial mass is zero outside its support. Therefore

\[
Q_n=nh+\frac{ns}{\eta_n}
\big[(1-p)B_{n-1,p}(b)+pB_{n-1,p}(a-1)\big].
\tag{8}
\]

Projection increases this particular state's cost only by explicit
boundary masses. This exact formula is substantially sharper than the
general trace-distance bound for the cost.

**Coherence is essential.** Measuring the full count \(j\), then accepting
the desired interval, produces a mixture of Dicke types. It removes every
off-diagonal term in (5), giving cost \(n\). The resulting limiting ratio
is \(\ell\), which is strictly smaller than \(\alpha=\ell/h\). The
preparation must measure only an interval-membership bit and then erase
the coherent counter.

## 3. Explicit finite-size convergence and success probability

For \(n\geq2\), choose

\[
\tau_n=\sqrt{2n\log n},\qquad
a=\max(0,\lceil np-\tau_n\rceil),\quad
b=\min(n,\lfloor np+\tau_n\rfloor).
\tag{9}
\]

Hoeffding's elementary binomial bound gives

\[
\delta_n:=1-\eta_n\leq2e^{-2\tau_n^2/n}=2n^{-4}.
\tag{10}
\]

The retained spectral support has
\(L_n\geq n\ell-3\tau_n\), so

\[
A_n\leq e^{-n\ell+3\tau_n}.
\tag{11}
\]

Set \(M=\max\{p/(1-p),(1-p)/p\}\), \(C=sM\). The lower excluded tail
contains the mass \((1-p)B_{n-1,p}(a-1)\); the upper excluded tail
contains the mass \(pB_{n-1,p}(b)\). Thus (7) implies

\[
\eta_n-\gamma_n\leq M\delta_n,\qquad
\frac{Q_n}{n}\leq h+C\frac{\delta_n}{1-\delta_n}.
\tag{12}
\]

Whenever the numerator below is positive, the actual witness ratio
\(R_n=-\log A_n/Q_n\) satisfies

\[
R_n\geq
\frac{\ell-3\sqrt{2\log n/n}}
{h+C\,2n^{-4}/(1-2n^{-4})}
=\alpha-O\!\left(\sqrt{\frac{\log n}{n}}\right).
\tag{13}
\]

For smaller \(n\), (4) and (6) remain exact and can be evaluated directly;
one may replace a negative bound in (13) by zero. A one-sided interval
\([a,n]\) also works, with a one-sided failure bound and only one boundary
mass. The supplied implementation supports both choices.

To attain \(R_n\geq\alpha-\varepsilon\), solving the displayed explicit
inequality suffices. In asymptotic terms,
\(n=O(\varepsilon^{-2}\log(1/\varepsilon))\) is sufficient. This is a
proved cost for this high-probability preparation family, not an optimal
finite-block convergence law.

## 4. A reversible preparation circuit with charged costs

Encode \(|1\rangle,|2\rangle\) as the computational states of one qubit
inside the excited qutrit subspace. All data operations preserve that
subspace. The circuit is:

1. Prepare \(w\) independently on each of \(n\) data systems.
2. Compute \(j=\sum_i1[\text{data}_i=|2\rangle]\) coherently into a
   \(m=\lceil\log_2(n+1)\rceil\)-bit counter.
3. Reversibly compute the predicate \(a\leq j\leq b\) into one accept bit,
   clearing comparator scratch bits.
4. Measure only the accept bit. Its success probability is \(\eta_n\).
5. On success, reverse the counter circuit. The counter and all scratch
   bits return to zero, while the data are exactly in state (3).

The program `energy_constructive.py` generates an explicit X/CNOT/Toffoli
sequence for this procedure, including every counter and comparator gate.
The threshold comparator computes the carry-out of adding the constant
\(2^m-a\) or \(2^m-(b+1)\), copies that carry to a flag, and reverses its
carry computation. Only the two threshold flags enter the final
membership Toffoli; both flags are then uncomputed.

An explicit controlled increment uses \(2(m-1)\) Toffoli gates,
\(m\) CNOT gates, and \(2(m-1)\) X gates, with \(m-1\) reusable carry
bits. Counting and reversing the count doubles those numbers for each
of \(n\) sites. The two reversible comparators and their reversal add
\(O(m)\) gates. A common scratch register suffices for both counting and
comparison. The implementation uses \(2m+3\) clean ancillary qubits in
total, including counter, scratch, two threshold flags, and the accept
bit. Thus one trial uses:

\[
n\text{ local rotations},\quad O(n\log n)\text{ reversible gates},
\quad 2\lceil\log_2(n+1)\rceil+3\text{ clean ancillas}.
\tag{14}
\]

Repeating failed trials gives expected trial count
\(1/\eta_n\leq1/(1-2n^{-4})\). A fixed preparation budget of \(t\) trials
fails with probability at most \((2n^{-4})^t\). These trial costs are
separate from the model's mean channel-input cost \(Q_n\). The circuit
does not interpret physical control-gate or scratch-ancilla energy as
part of \(H_n\); such an enlarged cost model would require specifying
those observables.

## 5. Finite amplitude accuracy without exponentially precise synthesis

A generic additive trace-distance approximation does **not** automatically
preserve an exponentially small overlap. The useful robustness here is
the exact spectral-support restriction. The following explicit version
uses only inverse-polynomial rotation precision.

For \(n\geq8\), compile the encoded rotation to operator-norm error
\(\zeta=n^{-2}\), retaining exact encoded-subspace preservation. Its
output is some known

\[
\widetilde w=u|1\rangle+v|2\rangle,
\quad \widetilde p=|v|^2,
\quad \widetilde c=\operatorname{Re}(u^*v).
\]

The bounds
\(|\widetilde p-p|\leq2\zeta\) and
\(|1+\widetilde c-h|\leq3\zeta\) follow from the state error and
\(\|H\|=3/2\). Compute a rational \(p_0\) with
\(|p_0-\widetilde p|\leq\rho=n^{-2}\), and choose

\[
a=\max(0,\lceil n(p_0-\rho)-\tau_n\rceil),\quad
b=\min(n,\lfloor n(p_0+\rho)+\tau_n\rfloor).
\tag{15}
\]

This interval contains the whole \(\tau_n\)-window about
\(n\widetilde p\), so its rejected probability is still at most
\(2n^{-4}\). Every retained string has

\[
L_n\geq n\ell-3\tau_n-6n\zeta-6n\rho.
\tag{16}
\]

No lower-tail spectral leakage is introduced by the approximate rotation.
The binomial identities (6)–(8) remain valid with \(p\) replaced by
\(\widetilde p\) and the energy term \(-s\) replaced by
\(\widetilde c\):

\[
\widetilde Q_n=n\left(1+\widetilde c\frac{\widetilde\gamma_n}
{\widetilde\eta_n}\right).
\]

For \(n\geq8\), \(\widetilde p\in[1/5,4/5]\),
\(|\widetilde c|\leq1/2\), and the boundary bound gives

\[
\frac{\widetilde Q_n}{n}
\leq h+3n^{-2}+\frac{4n^{-4}}{1-2n^{-4}}.
\]

Combining this with (16), the physically synthesized state obeys

\[
\widetilde R_n\geq
\frac{\ell-3\sqrt{2\log n/n}-12n^{-2}}
{h+3n^{-2}+4n^{-4}/(1-2n^{-4})}.
\tag{17}
\]

Again use zero if the numerator is negative. The convergence rate is
unchanged. Only \(O(\log n)\) bits of amplitude/angle precision are needed.
The exact reversible circuit uses a finite gate set. For the approximate
rotation, an inverse-closed universal single-qubit set and the
[Dawson–Nielsen Solovay–Kitaev construction](https://arxiv.org/abs/quant-ph/0505030)
give \(O(\log^{3.97}(1/\zeta))\) gates per compiled rotation and an efficient
classical compilation algorithm. Reusing one compiled rotation at all
sites yields the unconditional gate bound

\[
O(n\log n+n\log^{3.97}n).
\tag{18}
\]

This citation supplies the general synthesis theorem; the present
binomial construction and robustness bound are derived above. The
implementation below simulates exact target amplitudes and the exact
reversible projector. It does not claim to implement a universal
rotation compiler or run a hardware experiment.

## 6. Quantitative entanglement-depth obstruction

Define

\[
v_0=\operatorname{Var}_w(L)=9p(1-p),\qquad
\mu=2\alpha-5=\frac{5+4\sqrt{13}}3.
\]

On the excited two-dimensional local space,
\(\alpha H-L\) has eigenvalues \(0,\mu\) and one-dimensional kernel
\(\mathbf Cw\). On \(j\) entirely excited systems put

\[
X=L_j,\quad A=\alpha H_j-X,\quad q=\operatorname{Tr}(H_j\rho),
\quad x=\operatorname{Tr}(X\rho),\quad
g=\operatorname{Tr}(A\rho)\geq0.
\]

Here \(q\leq3j/2\), the spectrum of \(X\) lies in \([j,4j]\), and \(A\)
has unique zero vector \(w^{\otimes j}\) and gap \(\mu\). Define the
Jensen defect

\[
J=x+\log\operatorname{Tr}(e^{-X}\rho)\geq0.
\]

The exponent deficit in unnormalized cost units is exactly

\[
\alpha q+\log\operatorname{Tr}(e^{-X}\rho)=g+J.
\tag{19}
\]

**Case 1: appreciable generalized-eigenvalue slack.** If
\(g\geq\mu v_0/(144j)\), then division by \(q\leq3j/2\) gives a ratio
deficit at least \(\mu v_0/(216j^2)\).

**Case 2: small slack forces nonzero spectral variance.** Purify \(\rho\)
as \(|\Psi\rangle\), and project its data component onto
\(w^{\otimes j}\):

\[
W=(|w^{\otimes j}\rangle\langle w^{\otimes j}|\otimes I)|\Psi\rangle,
\qquad \sigma=1-\|W\|^2\leq g/\mu.
\]

The norm \(\|X-x\|\leq3j\). Since the variance of \(X\) in
\(w^{\otimes j}\) is \(jv_0\), the triangle inequality gives

\[
\sqrt{\operatorname{Var}_\rho(X)}
=\|(X-x)\Psi\|
\geq\sqrt{1-\sigma}\sqrt{jv_0}-3j\sqrt\sigma.
\]

When \(g<\mu v_0/(144j)\), one has
\(\sigma<v_0/(144j)\leq1/64\), because \(v_0\leq9/4\). Hence
\(\sqrt{1-\sigma}\geq3/4\) and
\(3j\sqrt\sigma\leq\sqrt{jv_0}/4\). Consequently,

\[
\operatorname{Var}_\rho(X)\geq jv_0/4.
\tag{20}
\]

For any real \(y\leq B\), Taylor's integral remainder gives

\[
e^{-y}\geq1-y+c_By^2,\qquad
c_B=\int_0^1(1-t)e^{-tB}\,dt
=\frac{B-1+e^{-B}}{B^2}.
\]

Apply this to the centered spectral variable \(Y=X-x\), with
\(B=3j\). Here \(c_B\geq2/(9j)\), \(\operatorname{Tr}(Y\rho)=0\), and
(20) yields

\[
J=\log\operatorname{Tr}(e^{-Y}\rho)
\geq\log(1+v_0/18).
\]

Dividing by \(q\leq3j/2\) gives a deficit of at least
\(\frac2{3j}\log(1+v_0/18)\), and therefore of at least
\(\frac2{3j^2}\log(1+v_0/18)\).

Both cases prove, for every mixed or pure all-excited block,

\[
-\log\operatorname{Tr}(e^{-L_j}\rho)
\leq\left(\alpha-\frac{c}{j^2}\right)
\operatorname{Tr}(H_j\rho),
\quad
c=\min\left\{\frac{\mu v_0}{216},
\frac23\log(1+v_0/18)\right\}.
\tag{21}
\]

Numerical evaluation gives \(c=0.052957364154320515\ldots\).

**Vacuum sectors.** Both \(E^{\otimes j}\) and \(H_j\) are block diagonal
under each site's vacuum-versus-excited split. Dephasing those occupation
patterns leaves the overlap and mean cost unchanged. Every nonempty
pattern contains some \(r\leq j\) all-excited sites, to which (21) applies
with at least the gap \(c/j^2\). The empty pattern has overlap one and
cost zero. If components obey \(a_t\geq e^{-\beta q_t}\), then their
mixture obeys

\[
\sum_t\lambda_ta_t\geq\sum_t\lambda_te^{-\beta q_t}
\geq e^{-\beta\sum_t\lambda_tq_t}.
\tag{22}
\]

Thus (21) holds for an arbitrary qutrit block of size at most \(j\).

**Depth \(k\).** A product over blocks of size at most \(k\) has a
multiplicative overlap and additive cost, so it obeys the common exponent
bound \(\alpha-c/k^2\). A \(k\)-producible state is a mixture of such
products, possibly with different partitions; (22) proves exactly the
same bound for that mixture. This establishes (1) and the necessary
depth \(k\geq\sqrt{c/\varepsilon}\).

This proof was independently checked by the `energy_exponent_audit`
agent, including the mixed-state purification, centered exponential
remainder, vacuum-sector reduction, and mixture step. This internal
check is not external peer review.

The constructed state is supported in the permutation-symmetric
subspace. Whenever a nontrivial truncation retains more than one type,
it is not a product \(u^{\otimes n}\). A symmetric pure state that
factorizes across any nontrivial partition must have pure one-site
marginals: a cross-partition two-site marginal equals
\(\rho_1\otimes\rho_1\), while its antisymmetric weight is zero, forcing
\(\operatorname{Tr}(\rho_1^2)=1\). It is therefore fully product.
Consequently the nontrivially truncated pure witnesses have entanglement
depth exactly \(n\). Small windows equal to the entire type range give
the original product state instead.

## 7. Implemented witness, circuit checks, and numerical values

Files in this directory:

- `energy_constructive.py`: standard-library implementation of binomial
  witnesses, log-domain overlap evaluation, exact counter/comparator
  circuit generation, and verification fixtures.
- `energy_constructive_results.json`: constants, the finite-size table,
  all validation results, and 80-digit Decimal reference computations.
- `energy_constructive_witness_n256.json`: 106 explicit symmetric Dicke
  coefficients, including their alternating signs, for \(n=256\).
- `energy_constructive_projector_n16.json`: an explicit generated
  reversible circuit, with register assignment and gate counts.

Run from the workspace root:

```sh
python3 work/deep/energy_constructive.py
```

The run checked 7,930 computational-basis counter/comparator cases,
including nontrivial arbitrary thresholds, and 20 full-vector fixtures
on \(n\leq10\) excited systems. The maximum cost and log-overlap
discrepancies were each \(1.78\times10^{-15}\). The \(n=16,64,128\)
formulas also matched independent 80-digit Decimal evaluations. These
are numerical and circuit-action checks; the formulas and asymptotic
bounds are proved above.

Selected two-sided-window evaluations:

| \(n\) | Retained type coefficients | \(R_n\) | \(\alpha-R_n\) |
|---:|---:|---:|---:|
| 256 | 106 | 4.826826874510 | 0.910207 |
| 1,024 | 238 | 5.177850873274 | 0.559183 |
| 4,096 | 523 | 5.413388213942 | 0.323646 |
| 16,384 | 1,127 | 5.557714605742 | 0.179320 |
| 65,536 | 2,411 | 5.639645797384 | 0.0973884 |
| 262,144 | 5,115 | 5.684964251871 | 0.0520699 |

The polynomial-size formula has been evaluated at these finite sizes.
It was not prepared on quantum hardware. Floating-point table entries
are not certified enclosures and should not replace the exact formulas.

For the binary measure-and-prepare erasure interface used in the parent
analysis, putting this active block in one of \(N\) otherwise-vacuum
positions gives mean input cost \(Q_n\), channel length \(Nn\), and exact
uniform-decoding error \((1-1/N)A_n\). The exponential position count
remains a charged bandwidth/channel-use cost when that resource is part
of the comparison.
