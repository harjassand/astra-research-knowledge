# Pure local qudit compression: direct dimension lower bound

Date: 2026-10-07. Status: internally derived proof, independently checked against a separate finite-grid proof by the quantum-statistics worker. No external correctness or priority claim. This result uses the exact finite-copy experiment and does not depend on an unverified Gaussian approximation. A later primary-source check found that the charged-total-dimension result follows from an established one-shot visible-compression converse. The stronger interface proved here concerns quantum branch dimension with unlimited classical outcomes; related Schmidt-number benchmark mechanisms are also established prior art, and novelty of the precise rate remains unestablished.

## Result and exact interface

Fix $q=d-1\ge1$ and $R>0$. The input is the unknown physical state

\[
 |\Phi_{n,z}\rangle
 =\left(\frac{|0\rangle+n^{-1/2}\sum_{a=1}^{q}z_a|a\rangle}
 {\sqrt{1+\|z\|^2/n}}\right)^{\otimes n},
 \qquad z\in\mathbb C^q,\quad\|z\|\le R.
\]

The encoder is a fixed CPTP map or quantum instrument, not a parameter-dependent preparation map. The decoder is a fixed channel, conditioned on the encoder's classical outcomes and any shared seed. There is no oracle revealing $z$, no input-dependent decoder side register outside the encoder, and no preshared encoder-decoder entanglement. The known inputs are $n,q,R$, the reference basis, and the model family. Channel computation is unrestricted; only retained memory dimension is optimized.

Write $Q$ for the largest quantum Hilbert-space dimension in any classical branch. Arbitrarily many classical measurement outcomes are permitted for the lower bound, even without charging them. In the originally requested charged hybrid interface, total dimension is $D=\sum_\ell\dim\mathcal M_\ell$, so $D\ge Q$. Independent public seeds are allowed.

The classical label register is dephased: coherence across distinct labels is quantum information and belongs to the quantum dimension. The branch bound does not declare a coherent direct sum to be free classical storage. The reconstruction criterion is

\[
 \sup_{\|z\|\le R}
 T\bigl(\Lambda_n(\Phi_{n,z}),\Phi_{n,z}\bigr)\le\epsilon,
 \qquad T(\rho,\sigma)=\tfrac12\|\rho-\sigma\|_1.
\]

For sufficiently small $\epsilon$ (depending only on $q,R$), uniformly over every integer $n\ge1$, the optimal total dimension and the optimal quantum branch dimension obey

\[
 \boxed{\quad
 D_{\min}(n,\epsilon),\ Q_{\min}(n,\epsilon)
 =\Theta_{q,R}\!\left[
 \left(1+\min\left\{n,
 \frac{\log(1/\epsilon)}{\log\log(1/\epsilon)}\right\}\right)^q
 \right].\quad}
\]

Here the $Q_{\min}$ optimization may use unlimited uncharged classical measurement memory. A quantum-only encoder attains the upper bound, so the distinction does not affect this order. Thus the suggested $\Theta$ law is correct, and the sufficient regime is already $n\ge C_{q,R}\log(1/\epsilon)/\log\log(1/\epsilon)$. A condition such as $n\gg[\log(1/\epsilon)/\log\log(1/\epsilon)]^2$, needed by a naive Poisson approximation, is unnecessary. Constants are not asymptotically sharp: the proof below gives cutoffs roughly $\frac12L/\log L$ and $2L/\log L$, where $L=\log(1/\epsilon)$.

## Lemma 1: approximate pure-state preservation implies entanglement fidelity

Let $\{|\psi_x\rangle,\mu(dx)\}$ be any pure-state ensemble in a finite-dimensional Hilbert space and put

\[
 \rho=\int |\psi_x\rangle\langle\psi_x|\,\mu(dx).
\]

Assume every pair satisfies

\[
 |\langle\psi_x|\psi_y\rangle|\ge c>0.
\]

For a channel $\Lambda$, define the average pure-state infidelity

\[
 \bar e=\int\left[1-\langle\psi_x|
 \Lambda(\psi_x)|\psi_x\rangle\right]\mu(dx).
\]

Then

\[
 \boxed{F_e(\rho,\Lambda)\ge
 1-\frac{2\sqrt{\bar e}+\bar e}{c}.}
 \tag{1}
\]

In particular, an average trace-distance error at most $\epsilon$ implies $\bar e\le\epsilon$. Uniform error is stronger than what this lemma needs.

**Proof.** Let $V:\mathcal H\to\mathcal H\otimes\mathcal E$ be a Stinespring isometry. Define

\[
 |e_x\rangle=(\langle\psi_x|\otimes I)V|\psi_x\rangle,
 \qquad
 |r_x\rangle=V|\psi_x\rangle-|\psi_x\rangle|e_x\rangle.
\]

Then $r_x$ is orthogonal to $\{|\psi_x\rangle\}\otimes\mathcal E$, and

\[
 \|e_x\|^2=1-e_x^{\rm err},\qquad
 \|r_x\|^2=e_x^{\rm err},\qquad
 e_x^{\rm err}=1-\langle\psi_x|\Lambda(\psi_x)|\psi_x\rangle.
\]

The isometry identity, with $s_{xy}=\langle\psi_x|\psi_y\rangle$, gives

\[
 s_{xy}(1-\langle e_x|e_y\rangle)
 =\langle\psi_x e_x|r_y\rangle
 +\langle r_x|\psi_y e_y\rangle+\langle r_x|r_y\rangle.
\]

Consequently,

\[
 |1-\langle e_x|e_y\rangle|
 \le\frac{\sqrt{e_x^{\rm err}}+\sqrt{e_y^{\rm err}}
 +\sqrt{e_x^{\rm err}e_y^{\rm err}}}{c}.
\]

Integrate twice and use Jensen/Cauchy-Schwarz:

\[
 \left\|\int e_x\,\mu(dx)\right\|^2
 \ge1-\frac{2\sqrt{\bar e}+\bar e}{c}.
\]

For a Kraus representation $V=\sum_j K_j\otimes|j\rangle$,

\[
 \int |e_x\rangle\mu(dx)=\sum_j\operatorname{Tr}(\rho K_j)|j\rangle,
\]

whose squared norm is exactly $F_e(\rho,\Lambda)$. Finally, measuring the projector $\psi_x$ shows $e_x^{\rm err}\le T(\Lambda(\psi_x),\psi_x)$. This proves (1).

Independent shared randomness causes no problem. Apply the lemma to the averaged physical channel. The reconstruction error is still at most $\epsilon$. Alternatively, average branchwise (1) and use Jensen on the branch errors.

## Lemma 2: quantum bottleneck bounds the Schmidt number

Let $\rho$ have decreasing eigenvalues $p_1\ge p_2\ge\cdots$, and let

\[
 |\Psi_\rho\rangle=\sum_i\sqrt{p_i}|i\rangle_R|i\rangle_A
\]

be a purification. If an encoder transmits a quantum register of dimension at most $Q$ in each classical branch, followed by any decoder, then

\[
 \boxed{F_e(\rho,\Lambda)\le\sum_{i=1}^{Q}p_i.}
 \tag{2}
\]

**Proof.** In each classical branch, the reference-memory state lives on $R\otimes\mathbb C^{Q_\ell}$, $Q_\ell\le Q$, and therefore has a decomposition into pure states of Schmidt rank at most $Q$. A local decoder channel preserves this property: applying a decoder Kraus operator cannot increase the Schmidt rank of a pure vector. Mixing classical outcomes and independent seeds preserves Schmidt number at most $Q$. This applies even to an unbounded classical outcome alphabet, by integration and closure in the finite-dimensional recovered output space.

For every normalized pure vector $\chi$ of Schmidt rank at most $Q$,

\[
 |\langle\Psi_\rho|\chi\rangle|^2\le\sum_{i=1}^{Q}p_i.
\]

To see this directly, regard the two vectors as coefficient matrices. The target matrix has singular values $\sqrt{p_i}$; maximize its Hilbert-Schmidt inner product with a Frobenius-unit matrix of rank at most $Q$. Truncated singular-value decomposition and Cauchy-Schwarz give $\sqrt{\sum_{i\le Q}p_i}$. Apply the squared bound to every pure component of the recovered reference-output state. Its overlap with $\Psi_\rho$ is $F_e$, proving (2).

The result is not valid in this form with preshared entanglement. It also does not address a visible encoder supplied with the classical parameter $z$. Both change the physical channel interface.

For the weaker bound on charged total dimension, visible encoding is already covered by the known one-shot source-coding converse discussed below.

## Exact Fourier torus and its spectrum

Set

\[
 S=\min\{R^2,1/4\},\qquad r=\sqrt{S/q}>0,
 \qquad z_a(\theta)=r e^{i\theta_a},
 \qquad\theta\in[0,2\pi)^q.
\]

This torus lies inside the legal ball. Let $m=(m_1,\ldots,m_q)\in\mathbb N_0^q$, $k=|m|=\sum_a m_a$, and $m!=\prod_a m_a!$. The normalized symmetric occupation vector with $m_a$ copies in level $a\ge1$ and $n-k$ vacuum copies is $|m;n\rangle$. The source state expands exactly as

\[
 |\Phi_{n,\theta}\rangle
 =\sum_{|m|\le n}\sqrt{p_n(m)}e^{i m\cdot\theta}|m;n\rangle,
\]

where

\[
 \boxed{p_n(m)=
 \frac{(n)_{|m|}}{n^{|m|}}\,
 \frac{r^{2|m|}}{m!}\,
 (1+S/n)^{-n}.}
 \tag{3}
\]

Here $(n)_k=n(n-1)\cdots(n-k+1)$. Haar averaging over the torus kills every off-diagonal Fourier character, so (3) is the complete nonzero spectrum of the average state $\rho_n$. No Gram conditioning or discretization is needed.

All pairwise overlaps are bounded away from zero, uniformly over $n$:

\[
 |\langle\Phi_{n,\theta}|\Phi_{n,\varphi}\rangle|
 =\left|\frac{1+(r^2/n)\sum_a e^{i(\varphi_a-\theta_a)}}{1+S/n}\right|^n
 \ge\frac{(1-S/n)^n}{(1+S/n)^n}
 \ge (1-S)e^{-S}=:c_0>1/2.
 \tag{4}
\]

The last step uses Bernoulli's inequality and $(1+S/n)^n\le e^S$.

Combining (1)-(4), every admissible protocol must satisfy the exact spectral condition

\[
 \boxed{
 1-\sum_{i=1}^{Q}p_{n,(i)}
 \le b_\epsilon:=\frac{2\sqrt\epsilon+\epsilon}{c_0},
 }
 \tag{5}
\]

where $p_{n,(i)}$ denotes the decreasing rearrangement of (3).

## Turning the spectrum into the lower dimension bound

For every $k\le n$,

\[
 \frac{(n)_k}{n^k}\ge e^{-k}.
 \tag{6}
\]

Indeed, $\log(1-t)$ is decreasing, so its left Riemann sum dominates its integral:

\[
 \sum_{j=0}^{k-1}\log(1-j/n)
 \ge n\int_0^{k/n}\log(1-t)\,dt
 =-k-(n-k)\log(1-k/n)\ge-k.
\]

For $k=n$, interpret the final term by its limit. There is no singular summand, because $j\le n-1$.

Let $a=r^2/e\in(0,1)$. For every $|m|\le K\le n$, (3), (6), $m!\le |m|!\le K!$, and $(1+S/n)^{-n}\ge e^{-S}$ give

\[
 p_n(m)\ge e^{-S}\frac{a^K}{K!}.
 \tag{7}
\]

There are exactly $N_K=\binom{K+q}{q}$ such occupations. If

\[
 e^{-S}a^K/K!>b_\epsilon,\qquad K\le n,
 \tag{8}
\]

then $Q<N_K$ is impossible: among the $N_K$ eigenvalues certified by (7), at least one is omitted from the top $Q$, causing the tail in (5) to exceed $b_\epsilon$. Thus

\[
 \boxed{Q\ge\binom{K+q}{q}\quad\text{whenever (8) holds}.}
 \tag{9}
\]

With $L=\log(1/\epsilon)\to\infty$, Stirling gives

\[
 -\log(e^{-S}a^K/K!)=K\log K+O_{q,R}(K).
\]

Since $-\log b_\epsilon=\frac12L+O_{q,R}(1)$, one can take

\[
 K=\min\{n,\lfloor cL/\log L\rfloor\}
\]

for any fixed $c\in(0,1/2)$, for all sufficiently small $\epsilon$. If $n$ is smaller, the same bound holds because $a^K/K!$ is decreasing in $K$. Consequently,

\[
 Q\ge c_{q,R}'\bigl(1+\min\{n,L/\log L\}\bigr)^q.
 \tag{10}
\]

The $+1$ simply includes the trivial $Q\ge1$ and avoids small-cutoff bookkeeping.

## Matching direct upper bound

Let $P_K$ project onto the symmetric occupations with $|m|\le\min\{K,n\}$. Its dimension is

\[
 \operatorname{rank}P_K=\binom{\min\{K,n\}+q}{q}.
\]

Compress this subspace isometrically. Replace the discarded component by the retained vacuum vector. This is a CPTP map on the entire input Hilbert space, not postselection, and needs only the retained subspace dimension. An extra failure flag is unnecessary.

For an input with $s=\|z\|^2\le R^2$, the total excitation count $B$ has the exact distribution

\[
 B\sim\operatorname{Bin}\!\left(n,\frac{s}{n+s}\right),
 \qquad\mathbb E B\le R^2.
\]

The discarded weight is $t=P(B>K)$. For $j=K+1\le n$, its factorial-moment bound is

\[
 t\le\frac{\mathbb E(B)_j}{j!}
 \le\frac{(R^2)^j}{j!}
 \le\left(\frac{eR^2}{j}\right)^j.
 \tag{11}
\]

For $K\ge n$, the discarded weight is zero. The decoded state is

\[
 P_K\Phi_{n,z}P_K+t|0;n\rangle\langle0;n|.
\]

The pure-state gentle-projection calculation gives trace distance at most $\sqrt t+t/2\le2\sqrt t$. Thus the sufficient explicit cutoff condition is

\[
 \frac{(R^2)^{K+1}}{(K+1)!}\le\epsilon^2/4.
 \tag{12}
\]

By Stirling, a suitable $K$ is $(2+o(1))L/\log L$. Choosing the smaller of this cutoff and $n$ proves

\[
 D,Q\le C_{q,R}\bigl(1+\min\{n,L/\log L\}\bigr)^q.
 \tag{13}
\]

Together (10) and (13) prove the stated order.

## Coherent-state and near-pure corollaries

The same proof applies directly to $q$-mode coherent states $|z\rangle$ with $\|z\|\le R$. On the phase torus the averaged spectrum is

\[
 p_\infty(m)=e^{-S}r^{2|m|}/m!,
\]

and pairwise overlaps have modulus at least $e^{-2S}$. The total photon count is Poisson, whose factorial moments give the same cutoff bound. Therefore both total hybrid dimension and quantum branch dimension are $\Theta_{q,R}((L/\log L)^q)$, even with unlimited measured classical side information. The Stinespring integrals also work in separable Fock space because their vector integrands have norm at most one. The Schmidt-number overlap bound extends to the trace-norm closed convex hull of the rank-$Q$ pure vectors by continuity.

A rigorous perturbation transfer is also available. If an actual state family $\sigma_z$ satisfies

\[
 \sup_z T(\sigma_z,\Phi_{n,z})\le\delta
\]

and a channel reconstructs $\sigma_z$ within $\epsilon$, contractivity and the triangle inequality imply reconstruction of the pure family within $\epsilon+2\delta$. Substitute that effective error into (9)-(10). For $q$ independent displaced thermal modes with fixed occupancies $\beta_a$, distance to the corresponding coherent pure state is exactly $1-\prod_a(1-\beta_a)$. This transfer becomes informative at growing precision when the thermal contamination tends to zero. It does not establish the $\epsilon\to0$ memory law at fixed positive temperature.

## Audits, exclusions, and novelty boundary

1. The average-state entropy alone is inadequate: for fixed $R$, the phase-average entropy remains bounded, while arbitrarily small reconstruction error needs growing dimension. The relevant resource is its eigenvalue tail after pure-state reversibility, not ordinary fixed-error Holevo information.
2. A rank argument on the decoded average state is invalid: a decoder of a small register can output a full-rank state. The correct intermediate object is Schmidt number of the recovered purification.
3. Nonzero pairwise overlaps are essential in Lemma 1. An orthogonal ensemble can be preserved by a classical measurement while destroying its purification.
4. Unlimited classical outcomes generated by the encoder are allowed. Free revelation of $z$, input-correlated external registers, visible state-preparation encoders, and preshared entanglement are excluded. Those interfaces require a separate theorem.
5. The proof is dimension-only. It supplies no local algorithmic runtime, gate-precision, laboratory, or decoder-preparation guarantee beyond the existence of the explicit subspace projection channel.
6. The $\Theta$ order is internally established by the displayed argument. The leading dimension constant and exact minimax error are unresolved. Cross-worker agreement is an audit signal, not external validation.

Finite diagnostic: work/deep/pure_quantum_lower_check.py wrote work/deep/pure_quantum_lower_check.json. It checks 144 exact multinomial spectra over $q=1,2,3$, $n=1,\ldots,12$, and four radii; normalization error was at most $2.3\times10^{-16}$, and the falling-factorial, eigenvalue, pair-overlap and binomial-tail bounds all held. Random-channel checks verified the environment-vector identity for entanglement fidelity to $9\times10^{-16}$, the trace-distance-to-infidelity bound, and the rank-$Q$/spectral-tail bottleneck inequality for $Q=1,2,4$. These are finite algebra and implementation checks only. The first diagnostic run failed because its fixed $s=0.001$ sample exceeded the smallest legal radius squared; the sample was restricted to the ball, and the formulas were unchanged.

Primary-source context checked live:

- [Yang, Bai, Chiribella, Hayashi, *Compression for quantum population coding*](https://arxiv.org/html/1701.03372), especially Section V and Theorem 2. They already prove that arbitrarily large classical memory cannot give faithful compression for families with quantum parameters. Their main rates concern increasing-copy global families; the present derivation focuses on precision in a fixed bounded local pure family.
- [Leditzky and Datta, *Second order asymptotics of visible mixed quantum source coding via universal codes*](https://arxiv.org/html/1407.6616), Lemma 5.2, states Hayashi's one-shot converse: the average pure-state fidelity of any visible code of compressed dimension $D$ is at most the sum of the largest $D$ eigenvalues of the source average. This yields the charged-total-$D$ law directly from (3) and (7), with the tail threshold $\epsilon$ instead of $b_\epsilon$. It covers arbitrary decoders and even encoders told the source label. It does not bound quantum branch dimension when classical outcomes are uncharged.
- [Hayashi, *Exponents of quantum fixed-length pure state source coding*](https://arxiv.org/abs/quant-ph/0202002): original source for that one-shot visible-compression converse.
- [Namiki, *Schmidt-number benchmarks for continuous-variable quantum devices*](https://arxiv.org/html/1511.03321), Eqs. (3), (9), (18), and (21), already uses the maximum-Kraus-rank/Schmidt-number channel interface for coherent-state fidelity and permits continuous classical instrument outcomes. Its prior is an unbounded Gaussian. The simplified optimal matrix formula in Eq. (20) is conjectural and is not used here.
- [Yang, Chiribella, Hayashi, *Optimal compression for identically prepared qubit states*](https://arxiv.org/abs/1606.02893): global identically prepared qubit compression is an existing theory, not a new target here.
- [Baghali Khanian, Winter, *General Mixed State Quantum Data Compression with and without Entanglement Assistance*](https://arxiv.org/abs/1912.08506): assistance changes the source-coding interface and needs explicit treatment.

The charged-total-$D$ law is therefore a routine specialization of existing visible source-coding machinery plus the exact occupation spectrum. Neither that converse mechanism nor the broader coherent-state/Schmidt-number mechanism is new. Bounded search has not determined whether the precise quantum-branch rate is already stated or follows from optimized Gaussian benchmarks or prior reversible classical-information extraction theorems. A possible contribution is at most the short explicit bounded-set precision proof, including finite-$n$ saturation, under unlimited classical outcomes. Treat this as a completed useful endpoint calculation, not evidence of a frontier breakthrough. The pure-quantum-novelty worker is assessing [Barnum, Hayden, Jozsa, Winter, *On the reversible extraction of classical information from a quantum source*](https://arxiv.org/abs/quant-ph/0011072) and related one-shot hybrid results.

Source snapshot paths consulted for scope: `work/RESEARCH_BRIEF.txt`, `work/astra-research-knowledge/00_START_HERE.txt`, `work/astra-research-knowledge/01_CORE.txt`. Existing tracial Gaussian claims were treated only as scope guidance and were not used in this proof.
