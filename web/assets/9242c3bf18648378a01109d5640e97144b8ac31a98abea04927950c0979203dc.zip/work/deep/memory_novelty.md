# Statistical experiment compression: primary-source and novelty audit

Audit date: 7 October 2026. Status: bounded primary-source audit completed; exact priority of the fixed-experiment matching theorem remains unconfirmed. The report does not provide external correctness or novelty clearance.

## Conclusion

The proposed general converse is a useful combination of established ideas, rather than evidence of a new information principle. The closest sources are more specific than the old N07 prior-art note indicates:

1. Hayashi–Tan already compress observations and reconstruct their **entire distribution**, rather than reproduce the realized data, under a blind-encoder interface.
2. Esposito–Vandenbroucque–Gastpar give Bayesian lower bounds combining small-ball probabilities with maximal leakage.
3. Farokhi gives the quantum prepare-and-measure formula for maximal leakage. An elementary POVM trace bound makes its leakage factor at most the memory dimension.
4. The positive hat encoder/decoder belongs to the established Durrmeyer-sampling family.

The possible contribution is therefore a precise **fixed-experiment, uniform-TV, dimension-versus-error theorem** and its worked examples. No checked source was found that states the complete N07 Gaussian result, including arbitrary bounded mean sets, affine-span dimension even for finite parameter sets, continuous decoder outputs, and arbitrary quantum/hybrid memory with free independent classical seeds. That is a search result, not a novelty claim.

The suggested regular-posterior generalization needs a correction: regular posterior geometry supplies the **lower bound**. A matching upper bound needs separate assumptions permitting a positive finite-rank reconstruction with uniform approximation error. Posterior dimension alone does not imply a universal squared-error exponent. The moving-endpoint uniform family below has an explicitly proved first-order rate.

## Interface audited

Read the current `ASTRA_BRIEF.txt`, `01_CORE.txt`, N07 card, and extracted N07 prior-art report. Their internal-review labels are retained.

For one classical observation $X\sim P_\theta$, let an encoder prepare a density matrix $\rho_x$ in a finite algebra

\[
\mathcal A=\bigoplus_j M_{d_j},\qquad D=\sum_j d_j.
\]

The decoder is a POVM and produces a fresh classical observation $Y$. Both encoder and decoder are independent of the unknown parameter. An independent shared classical seed is allowed with dimension at most $D$ for every seed. There is no retained input-dependent side register or entanglement assistance. The fidelity criterion is

\[
e_D=\inf_{E,R}\sup_{\theta\in\Theta}
\operatorname{TV}(RE P_\theta,P_\theta),
\quad \operatorname{TV}(P,Q)=\tfrac12\|P-Q\|_1.
\]

This is law reconstruction/approximate sufficiency. It differs from distortion of the realized sample, estimating the parameter, visible encoding that knows the parameter, and fidelity of one prescribed decision problem. Continuous independent decoder randomness is legal; its numerical implementation and precision are not charged by this mathematical model.

## Closest primary sources and their actual scope

| Source and locator | Established result relevant here | Difference from the candidate |
|---|---|---|
| [Jenčová, *Comparison of quantum binary experiments* (2012), Theorem 1 p. 2 and Corollary 1 pp. 5–6](https://arxiv.org/pdf/1110.4792) | The finite classical randomization criterion identifies deficiency with a parameter-independent Markov kernel satisfying uniform $\ell_1$ error $2\varepsilon$. The abelian-target corollary extends the comparison to a quantum source. | Supplies the decision-theoretic interpretation, not a rate in memory dimension. The inspected theorem uses finite parameter and observation sets; our continuous-output risk inequality is derived directly below. |
| [Strasser, *Towards a statistical theory of optimal quantization* (2000), Section 5, Definition 6, Lemma 1, Theorem 8, pp. 11–14](https://www.math4tune.com/publications/Strasser%202000,%20quantization%20Bock,%20article.pdf) | Finite experiment complexity is characterized by finite support of its standard likelihood/posterior measure. Reductions are quantizations in convex order; convex integrals describe Bayes decision performance. | The posterior-experiment viewpoint and finite-complexity optimization are already present. No uniform-TV $D^{-2/r}$ theorem or quantum-memory converse was located in the inspected section. |
| [Pötzelberger, *MSP-Partitions and Unbiased Quantizations: A Review of Results* (2002), Sections 2–3, pp. 203–205](https://www.ajs.or.at/index.php/ajs/article/download/vol31,%20no2&3%20-%208/426) | Unbiased quantization connects finite partitions to reductions of experiments. The high-resolution point density for a smooth convex distortion contains the familiar $d+2$ exponent and Hessian determinant. | Supports the established quadratic quantization geometry, not the complete uniform-TV reconstruction problem. The publication year is 2002; later upload/crawl dates are not its priority date. |
| [Hayashi–Tan, *Minimum Rates of Approximate Sufficient Statistics* (IEEE TIT 64(2), 875–888, 2018), Definitions 1–3, Eqs. (6)–(7), Theorem 1 Eq. (20), pp. 3–4](https://arxiv.org/pdf/1612.02542) | A blind encoder observes $X^n$, retains a finite alphabet, and decodes a distribution approximating $P_z^n$. Under regularity and LAN assumptions the leading memory is $(d/2)\log n$, with a strong converse for variational distance. | The criterion averages error over a prior on a positive-volume parameter set. It is an $n\to\infty$ regular-iid theorem, not the fixed-experiment $D\to\infty$ uniform-TV rate. Finite affine-spanning parameter sets and arbitrary quantum-memory dimension are not its stated setting. Its variational distance is full $\ell_1$, so factors of two must be translated. |
| [Yang–Bai–Chiribella–Hayashi, *Compression for quantum population coding*, Theorem 1 pp. 2–3; Eqs. (51)–(53) p. 9](https://arxiv.org/pdf/1701.03372) | Uniform trace-distance compression of regular $n$-copy parametric quantum families has leading total memory $(f/2)\log n$. Classical Gaussian modes are discretized and regenerated by uniform sampling in cells. | A closer **uniform quantum/hybrid reconstruction** antecedent. Its limit, parameter assumptions, and reported error exponents differ from N07. Its Gaussian discretization is first order; the paper does not state the fixed bounded-mean $D^{-2/s}$ result. |
| [Esposito–Vandenbroucque–Gastpar, *Lower Bounds on the Bayesian Risk via Information Measures* (JMLR 25, 2024), Corollary 6 Eq. (21), Theorem 8 Eq. (26), pp. 9–10](https://jmlr.org/papers/volume25/23-0361/23-0361.pdf) | For arbitrary losses, a small-ball probability $L_W(t)$ and maximal leakage $\mathcal L(W\!\to\!A)$ give $R_B\ge\sup_t t[1-e^{\mathcal L}L_W(t)]$. Its event inequality also applies to general probability spaces. | This is very close to the proposed dimension/small-ball converse. The new application would be converting law reconstruction into excess Bayes risk of a posterior statistic or regret, then bounding leakage by $\log D$. |
| [Farokhi, *Maximal Information Leakage from Quantum Encoding of Classical Data* (PRA 109, 022608, 2024), Theorem 1 Eq. (3) p. 4 and Proposition 2 p. 5](https://arxiv.org/pdf/2307.12529) | For finite classical input and finite-outcome POVMs, quantum maximal leakage is the supremum of $\log\sum_y\max_x\operatorname{tr}(\rho_xF_y)$. | The printed dimension bound is the looser $2\log d$. The sharp $\log d$ trace bound below follows immediately from the formula, but is not attributed to the paper's Proposition 2. |
| [Xiao–Zhao–Zhu–Farokhi, *Maximal quantum leakage: operational interpretation and quantum channel analysis* (17 July 2026 preprint), Theorem 1, Eq. (14), pp. 2–3](https://arxiv.org/pdf/2607.15853) | For finite inputs, maximal quantum leakage equals $\log(NP_{\rm guess})$, with equal-prior minimum-error state discrimination. | Makes the operational ancestry explicit. Its Proposition 1 still uses a loose $2n\log d$ bound. This recent preprint does not provide the experiment reconstruction theorem. |
| [Costarelli–Piconi–Vinti, *The multivariate Durrmeyer-sampling type operators in functional spaces* (2022), Eq. (6), p. 130](https://drna.padovauniversitypress.it/system/files/papers/COSTARELLI_et_al.pdf) | A semi-discrete operator integrates against one translated kernel and reconstructs with another translated kernel. With two nonnegative normalized tent kernels it has the same encoder/decoder form as N07, after periodization. | The kernel family is established. The Gaussian companding, uniform density regularity, finite-memory accounting, and matching quantum lower bound are additional steps. |
| [Costarelli–Piconi–Vinti, *Quantitative estimates for Durrmeyer-sampling series in Orlicz spaces* (2023), Theorem 4.1, pp. 11–12](https://d-nb.info/1280113626/34) | Gives $L^p$ estimates in a first-order modulus of smoothness for this family. | The inspected theorem is not the specific second-order $W^{2,1}$ bound used by N07. It still rules out describing the operator itself as a new construction. |
| [Varshney–Varshney, *Quantization of Prior Probabilities for Hypothesis Testing* (2008), Section IV Eqs. (15), (17)–(19), pp. 6–7](https://arxiv.org/pdf/0805.4338) | A locally quadratic Bayes-risk distortion yields the familiar scalar $K^{-2}$ high-rate behavior. | Quantizes a supplied prior for hypothesis testing. It does not preserve a whole observation experiment in uniform TV. |
| [Jain–Shi–Wei–Zhang, *Correlation/Communication complexity of generating bipartite states* (2012), Theorem 2, p. 3](https://arxiv.org/pdf/1203.1153) | Classical distributions can have substantially different positive-semidefinite and nonnegative factorization complexities, corresponding to quantum and classical generation resources. | Prevents a blanket claim that quantum memory never helps with classical statistical compression. Matching orders in a specified smooth family say nothing about optimal constants or arbitrary experiments. |

### A source error that must not be propagated

[Farokhi, *Optimal Universal Quantum Encoding for Statistical Inference*, arXiv:2404.08172v1, p. 2](https://arxiv.org/pdf/2404.08172) defines $Q$ as a logarithmic leakage but prints a success-probability upper bound $Q\,p_{\max}$, instead of the multiplicative leakage $e^Qp_{\max}$ (or $2^Qp_{\max}$, according to log base). The PDF page was rendered and visually checked. For dimension one, all states are identical, $Q=0$, and guessing the most likely class still succeeds with probability $p_{\max}>0$; this directly contradicts the printed inequality. Cite this paper only as conceptual context. The earlier quantum leakage formula plus a direct trace derivation is adequate and avoids silently repairing a published statement.

## The general converse, with its dependencies exposed

The following is a direct derivation under the stated resource model. It is not claimed to be a previously unknown theorem.

Choose a prior $\pi$, a loss $0\le\ell_\theta(a)\le L$, and a measurable Bayes action $a_*(x)$ for the original experiment. Let $\mu$ be the mixture law of $X$, and define conditional regret

\[
r(x,a)=\mathbb E[\ell_\theta(a)\mid X=x]
-\mathbb E[\ell_\theta(a_*(x))\mid X=x]\ge0.
\]

Use $A=a_*(Y)$, extending the rule measurably outside the support if necessary. Uniform-TV error at most $e$ gives

\[
\mathbb E\,r(X,A)\le L e. \tag{1}
\]

Indeed, evaluate the same bounded rule on the reconstructed $Y\mid\theta$ and on a genuine draw from $P_\theta$, then integrate over the prior. The Markov property $\theta\to X\to A$ identifies their Bayes-risk difference with the expected conditional regret. This only requires the forward bounded-risk consequence of TV; no general quantum randomization equivalence is assumed.

Let $M$ be the decoder POVM after applying the action rule. Its scalar trace measure $\nu(B)=\operatorname{Tr}M(B)$ has total mass $D$. In finite dimension there is a positive matrix density $F(a)$ with $M(da)=F(a)\nu(da)$ and $\operatorname{Tr}F(a)=1$ almost everywhere. Since $0\le\rho_x\le I$,

\[
\operatorname{tr}(\rho_xF(a))\le1.
\]

Consequently, for any measurable $C$ and $t>0$,

\[
\Pr\{X\in C,r(X,A)<t\}
\le D Q_C(t),
\quad Q_C(t)=\sup_a\mu\{x\in C:r(x,a)<t\}. \tag{2}
\]

The same proof applies to a direct-sum algebra because its identity has trace $\sum_jd_j$. Conditional on an independent classical seed it holds with $D_s\le D$; averaging preserves (2). This establishes the continuous-input/output and shared-seed version without extrapolating the discrete quantum leakage theorem.

Combining (1) and (2), writing $m_C=\mu(C)>0$, gives

\[
e_D\ge\frac1L\sup_{t>0}
t\,[m_C-DQ_C(t)]_+. \tag{3}
\]

This is the localized event/small-ball mechanism of the cited Bayesian leakage bounds, composed with the established decision-theoretic consequence of approximate sufficiency. Localization handles an otherwise difficult global posterior density. A new name for (3) would obscure those antecedents.

If $Q_C(t)\le Kt^\beta$ for sufficiently small $t$, (3) gives $e_D\gtrsim D^{-1/\beta}$. More specifically, if

\[
r(x,a)\ge c\|T(x)-a\|^p,
\quad \sup_a\mu\{x\in C:\|T(x)-a\|<h\}\le Kh^r,
\]

then $e_D\gtrsim D^{-p/r}$. Both the small-ball dimension $r$ **and the order $p$ of Bayes regret** matter.

### What the regular case establishes

For a bounded squared loss, the exact posterior mean identity gives $r(x,a)=\|m(x)-a\|^2$. An $r$-dimensional posterior law with bounded density on a positive-mass local chart supplies the $h^r$ small-ball estimate. The lower bound $D^{-2/r}$ follows.

For N07's finite affine-spanning Gaussian prior, $m(x)$ is a gradient of log-sum-exp and its Jacobian is the positive definite posterior covariance. On a compact region this provides the required local geometry. The observation's posterior statistic can have positive-dimensional continuous support even when the **parameter** takes only finitely many values. Finite parameter cardinality therefore does not give a finite sufficient observation alphabet.

A matching upper needs more. One sufficient route is a parameter-independent coordinate change/reference measure making the target densities uniformly $W^{2,1}$, followed by a positive finite-rank Markov approximation that reproduces affine terms. This is an extra reconstruction hypothesis, not a consequence of posterior rank. The known Durrmeyer family gives a natural operator template; one must verify its positivity, both normalizations, periodic boundary behavior, second-order cancellation, and rank budget for the particular family.

## Explicit nonregular example: moving uniform endpoint

This internally derived example is complete as an elementary argument, but its publication priority has not been established. Let

\[
P_\theta=\operatorname{Unif}[0,\theta],\qquad\theta\in[1,2].
\]

Under the same arbitrary quantum/hybrid/shared-seed resource model,

\[
\frac1{256D}\le e_D\le\frac1{2D},\qquad D\ge1. \tag{4}
\]

For the lower bound choose prior density $\pi(\theta)=2\theta/3$. The mixture density is

\[
q(x)=\frac23(2-\max\{1,x\}),\qquad 0\le x\le2,
\]

and the posterior is uniform on $[\max\{1,x\},2]$. For actions $a\in[1,2]$, use the bounded loss

\[
\ell_\theta(a)=2-a+2\mathbf1\{a>\theta\}\in[0,3].
\]

Its Bayes action is $a_*(x)=\max\{1,x\}$ on the support. On $C=[1,3/2]$, the regret is

\[
r(x,a)=
\begin{cases}
x-a,&a\le x,\\
\left(\dfrac2{2-x}-1\right)(a-x),&a>x,
\end{cases}
\]

so $r(x,a)\ge|a-x|$. Here $\mu(C)=1/4$ and $q\le2/3$, hence

\[
\sup_a\mu\{x\in C:|a-x|<h\}\le\frac43h.
\]

Taking $h=3/(32D)$ in (2) gives success probability at most $1/8$ inside $C$; therefore $\mathbb E r\ge h/8=3/(256D)$. Equation (1) with $L=3$ proves the lower bound in (4).

For the upper bound partition $[0,2]$ into $D$ equal cells of width $h=2/D$, store the cell containing $X$, and regenerate uniformly within that cell. Every full cell below $\theta$ is exact. If the endpoint leaves length $u\in[0,h]$ of the boundary cell inside the support, the total variation error is

\[
\frac{u(h-u)}{\theta h}\le\frac h{4\theta}\le\frac1{2D}.
\]

This example distinguishes posterior dimension from local Bayes-regret order: its one-dimensional posterior chart supports **linear**, not quadratic, regret for a bounded decision problem. It should be presented as a worked nonregular theorem/counterexample to an unqualified universal $D^{-2/r}$ statement, not a general theory of all support singularities.

## What can responsibly be claimed

| Proposed claim | Assessment |
|---|---|
| Reconstructing the whole law is a new notion of compression | False as a novelty claim; approximate sufficiency and parametric population coding already use it. |
| A novel dimension/small-ball information principle | Unsupported; the published leakage/Bayes-risk architecture is very close, and the quantum trace step is elementary. |
| A new positive hat reconstruction kernel | Unsupported; it is a Durrmeyer-sampling specialization. |
| Regular posterior dimension by itself implies $e_D\asymp D^{-2/r}$ | Overstated; the converse and upper approximation require separate hypotheses. |
| Fixed bounded Gaussian mean experiment has order $D^{-2/s}$, uniformly in the stated resource model | Possible scoped contribution; exact prior match not located, correctness/priority still subject to independent review. The affine-span/finite-parameter formulation and second-order tail-free upper are the meaningful specifics. |
| Moving-endpoint uniform family has order $D^{-1}$ even with quantum memory | A complete internal elementary derivation is supplied above. Exact prior match not located; the machinery is largely established, so novelty should remain unconfirmed. |
| Quantum and classical optimal constants are equal | Not established by matching exponents/orders. |
| Quantum cannot advantageously compress any classical statistical experiment | Not established and contrary to known positive-semidefinite/nonnegative factorization separations. |

For a future manuscript, state the exact fixed-experiment theorem first; explain its relationship to approximate sufficiency and parametric population coding; acknowledge the small-ball/leakage and positive approximation ingredients; and distinguish the affine-span Gaussian theorem from the moving-endpoint example. Do not advertise a broad quantum no-advantage theorem.

## Search limits and reproducibility

Searched primary sources under Le Cam deficiency/randomization, Blackwell comparison, experiment quantization/finite complexity, approximate sufficient statistics, classical data encoded into quantum memory, maximal leakage, high-rate decision quantization, and positive sampling/spline approximation. Also used exact model/rate searches for Gaussian mean and moving-endpoint uniform reconstruction. No exact matching published statement was located in this bounded search.

Relevant mathematical statements were inspected in the full-text sources linked in the main table. Relevant downloaded PDFs and page-separated extraction are in `work/deep/memory_sources/`; retrieval metadata is in `retrieval.json` and `retrieval_additional.json`. Farokhi's 2024 inference page was additionally rendered and viewed. The table's statements identify the passages actually used rather than upgrading an abstract to a theorem.

Unresolved access/coverage: Le Cam's 1964 original paper was not inspected in full; Torgersen's complete deficiency chapter was not accessible in the available preview; the full Gupta–Hero 2003 detection quantization manuscript was not retrieved reliably. Older integral Schoenberg-spline and Durrmeyer/Voronovskaja sources were identified but not read in full. Thus the exact second-order positive operator may have a still closer old antecedent. These gaps, plus the limits of keyword search, prevent novelty clearance. Later sources discussing approximation in **variation of functions** or $W_1$ reconstruction must not be mistaken for statistical total variation.
