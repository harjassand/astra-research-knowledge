# Pure-reference reliability per mean input cost: novelty audit

Audit date: 7 October 2026. Status: exact finite-dimensional internal derivations; primary-literature search does **not** establish priority. The generic regularization mechanism is established smooth-entropy technology. The exact cost-constrained statement and explicit separable-versus-entangled examples were not located verbatim in the searched primary sources.

## Assessment

The proposed formula is mathematically plausible and independently derivable in a few lines plus typical projection. It should be presented as an exact operational corollary for minimum vacuum mass under an additive **mean** input-cost constraint, with an explicit finite entanglement advantage. It should not be sold as a new general regularization principle, quantum capacity formula, or unrestricted coding reliability theorem.

The strongest novelty downgrader is Datta's 2009 smooth-min-relative-entropy framework, strengthened by Nuradha–Wilde's 2024 fidelity-smoothing asymptotics. The channel-capacity-per-unit-cost literature is operationally adjacent but uses the opposite relative-entropy direction. A strict advantage requires a noncommuting cost/detection effect; it disappears under the usual time-translation covariance assumptions with invariant vacuum projection.

## Interface and exact candidate

Finite-dimensional memoryless CPTP channel \(\Phi:A\to B\), known pure reference \(\Phi(|0\rangle\langle0|)=|v\rangle\langle v|\), and known \(H\ge0\) with \(\ker H=\mathbb C|0\rangle\). Put

\[
 E=\Phi^*(|v\rangle\langle v|)>0,\qquad L=-\log E,
 \quad H_m=\sum_{i=1}^mH^{(i)},\quad L_m=\sum_{i=1}^mL^{(i)}.
\]

All logarithms here are natural. Positivity and \(\langle0|E|0\rangle=1\) imply \(E=1\oplus E_+\), and \(L=0\oplus L_+\). Assume \(\alpha>0\), where

\[
 \alpha=\|H_+^{-1/2}L_+H_+^{-1/2}\|.
\]

Define \(a_*(Q)=\inf_{m<\infty,\tau:\operatorname{Tr}H_m\tau\le Q}\operatorname{Tr}(E^{\otimes m}\tau)\). Then

\[
 \lim_{Q\to\infty}\frac{-\log a_*(Q)}Q=\alpha.
\]

The converse is scalar spectral Jensen, not operator monotonicity of the exponential:

\[
 \operatorname{Tr}(e^{-L_m}\tau)
 \ge e^{-\operatorname{Tr}L_m\tau}
 \ge e^{-\alpha\operatorname{Tr}H_m\tau}.
\]

For achievability, choose a unit vector \(w\perp0\) maximizing \(\ell/h=\alpha\), where \(\ell=\langle w|L|w\rangle\), \(h=\langle w|H|w\rangle>0\). Project \(w^{\otimes r}\) onto the spectral interval \([r(\ell-\delta_r),r(\ell+\delta_r)]\) of \(L_r\), normalize, and choose \(\delta_r\to0\), \(r\delta_r^2\to\infty\). Scalar iid concentration makes the removed mass vanish. Since \(\|H_r\|=r\|H\|\), its cost is \(rh+o(r)\), while its vacuum mass is at most \(e^{-r(\ell-\delta_r)}\). A choice \(\delta_r=O(\sqrt{\log r/r})\) makes the cost perturbation negligible and provides an explicit sublinear exponent loss. Rounding \(r\) down by a sublinear reserve meets every sufficiently large mean-cost budget. This proves the candidate without a channel-capacity theorem.

Supplied information: \(\Phi,H,E\), spectral representation, state preparation and collective projection capabilities. Charged quantity: mean input cost \(\operatorname{Tr}H_m\tau\) only. Channel uses, circuit size, coherence/reference supply, failed preparation attempts, and detector work are not charged by this model. There is no hard spectral-support cost bound here.

## Closest primary precedents and precise differences

1. **Datta (2009), Definitions 2/4, Lemma 12, Theorem 3.** Defines \(D_{\min}(\rho\|\sigma)=-\log\operatorname{Tr}(\Pi_\rho\sigma)\) for positive \(\sigma\), gives its zero-Type-I-error interpretation, and relates state-smoothed min-relative entropy to spectral divergence rates. For pure input \(w\), \(D_{\min}(w\|E)=-\log\langle w|E|w\rangle\), whereas \(D(w\|E)=\langle w|L|w\rangle\). The candidate's typical projection is the standard way to remove the gap between these quantities. [Primary manuscript](https://arxiv.org/html/0803.2770), especially Eqs. (9), (67)–(70).

2. **Nuradha–Wilde (2024), Theorem 4 and Proposition 3.** For a state \(\rho\) and positive operator \(\sigma\), smooth fidelity-min-relative entropy has first-order term \(D(\rho\|\sigma)\), a relative-entropy-variance second order, and a moderate-deviation expansion when the smoothing error tends to zero. Set \(\rho=w\), \(\sigma=E\). This is a direct precedent for replacing product \(-\log\langle E\rangle\) by \(\langle-\log E\rangle\) after a small collective perturbation. Their smoothing does not itself impose an input Hamiltonian budget; bounded-cost continuity supplies that extra step. [Primary manuscript](https://arxiv.org/html/2305.05859), Eqs. (1)–(5), (147), (164). Careful: their \(D_{\min}^{\varepsilon}\) denotes hypothesis-testing smoothing, unlike Datta's state-ball definition; \(D_{\min,F}^{\varepsilon}\) is the useful state-smoothing precedent.

3. **Ding–Pavlichin–Wilde (2019), Theorem 5, Section III-A, Discussion.** Capacity per unit cost with a zero-cost state uses \(\sup_w D(\Phi(w)\|\Phi(0))/\langle H\rangle_w\) in the stated additive-Holevo setting; nonadditive extensions are regularized. Their PPM pulses and additive cost observable are established. When \(\Phi(0)\) is pure, the forward divergence is infinite for any output with support outside the vacuum ray. This does not compute the candidate's finite reverse, zero-false-positive miss exponent. Their PPM test places the active output as null and permits fixed positive Type I error. [Primary manuscript](https://arxiv.org/html/1705.08878), Eqs. (37), (58)–(63), (200).

4. **Jarzyna (2017), Section III.** Classical-to-quantum capacity per unit cost and zero-cost symbols use output relative entropy divided by classical symbol cost. The discussion explicitly notes infinite capacity per cost when supports only partially overlap and support projection suffices. This explains why pure-reference capacity is a different question. It does not contain the noncommuting quantum cost observable or optimize entangled input pulses. [Primary manuscript](https://arxiv.org/html/1704.06696), Eq. (15) and following discussion.

5. **Wang–Wilde (2019), channel asymmetric distinguishability, Theorem 1.** One-shot exact channel-box distillation is channel min-relative entropy, defined by optimizing over an input entangled with a reference. It provides the standard operational vocabulary for the candidate, not the specific cost-normalized \(\alpha\). [Primary manuscript](https://arxiv.org/html/1907.06306), Eqs. (31), (32), (37). Their separate [state resource theory](https://arxiv.org/html/1905.11629) identifies min-relative entropy as exact one-shot distinguishability and relative entropy as the asymptotic rate.

6. **Berta–Hirche–Kaur–Wilde (2020), Sections III.6/IV.6/VII.3.** Develops energy-constrained adaptive channel discrimination, generalized/amortized divergences, and an energy-constrained amortization collapse for \(D(\mathcal N\|\mathcal R)\) when the second channel is a replacer. That is a Stein task with an allowed positive false-alarm tolerance and the forward channel order. It is not the reversed replacer-first exact-zero-error task here. [Primary manuscript](https://arxiv.org/html/1808.01498), Eqs. (40), (118), (272), Lemma 38.

7. **Wilde–Guha–Tan–Lloyd (2012).** Collective vacuum-or-not measurements and optical sequential decoding were explicitly proposed as capacity-achieving receiver components. Hence the binary receiver and PPM architecture are not new. The candidate's contribution, if publishable, is the input-cost optimization, not inventing vacuum projection. [Primary manuscript](https://arxiv.org/pdf/1202.0518).

8. **Li–Yang (2025), Theorems 2/3.** Resolves a general classical-quantum reliability lower bound and determines the high-rate reliability function. The input is a classical alphabet, codeword outputs are tensor products, and reliability is per blocklength at fixed rate. The candidate allows quantum input entanglement, has unrestricted finite blocklength, and normalizes a one-sided vacuum miss probability by mean cost. [Primary manuscript](https://arxiv.org/html/2407.12403), Eqs. (13)–(16).

9. **Molina–Watrous (2012), quantum hedging.** Correlated quantum responses to independent interactive tests can guarantee that at least one test passes. This is a conceptual precedent for collective suppression of all-failure outcomes, but a different feasible strategy set and task. Here without cost constraints the minimum eigenvalue of \(E^{\otimes m}\) is multiplicative; the noncommuting additive cost produces the advantage. [Primary manuscript](https://arxiv.org/html/1104.1140).

## Internal structural results

For every separable \(m\)-use input, including arbitrary classical mixtures of nonidentical product inputs,

\[
 \operatorname{Tr}E^{\otimes m}\tau\ge e^{-\beta\operatorname{Tr}H_m\tau},
 \quad
 \beta=\max_{w\perp0}\frac{-\log\langle w|E|w\rangle}{\langle w|H|w\rangle}.
\]

The restriction \(w\perp0\) loses nothing: mixing vacuum amplitude with an excited unit vector replaces the numerator by \(-\log(1-p+p e)\); convexity and its zero value at \(p=0\) show that dividing by \(p\) is maximized at \(p=1\). Convexity of \(-\log\) extends the one-copy bound to mixed inputs; scalar Jensen over mixture components proves the block-separable bound. Repeated product pulses attain \(\beta\) asymptotically.

**Equality criterion.** \(\beta=\alpha\) exactly when some positive-cost \(E\)-eigenvector lies in \(\ker(\alpha H-L)\). Proof: \(-\log\langle E\rangle\le\langle L\rangle\le\alpha\langle H\rangle\), and equality in strict scalar Jensen requires a single \(L\) eigenvalue on the vector's spectral support. Compactness on the excited unit sphere supplies a maximizer. Consequently \([E,H]\ne0\) alone does not guarantee a gap, and input dimension at least three is necessary under the unique-zero-ray assumption.

**Two-use sufficiency lemma.** If a \(\beta\)-maximizing \(w\) is not an \(E\)-eigenvector, choose \(z\perp w\) with \(a=\langle z|E|w\rangle\ne0\). Phase-align \(\chi_t\propto w\otimes w-tz\otimes z\). The additive cost has zero first derivative at \(t=0\), whereas the vacuum probability has derivative \(-2|a|^2\). Thus its exponent per cost increases immediately. Two uses already beat the separable optimum in this case. This is an elementary internal derivation, not a priority claim.

**Ancillary reference distinction.** For parallel discrimination of the pure-output replacer \(\mathcal R_v\) as null against \(\Phi\), zero false positives imply a miss probability \(\operatorname{Tr}(E^{\otimes m}\tau_A)\) even with a free retained reference. The null output is \(P_v^{\otimes m}\otimes\tau_R\); its support projector is \(P_v^{\otimes m}\otimes\Pi_{\tau_R}\), and the alternative's reference support is contained in \(\Pi_{\tau_R}\). A reference therefore cannot lower this one-sided overlap at fixed input marginal. This does not prove an entanglement-assisted communication reliability statement, nor adaptive discrimination optimality.

## Exact two-use witness

The matrices below were supplied by `energy_exponent_audit`; the two-use construction and proof were derived here and independently checked by that agent. Let \(b=\log(8/3)\),

\[
 E=1\oplus\operatorname{diag}(1/2,1/4),\qquad
 H=0\oplus
 \begin{pmatrix}b-1/12&-1/4\\-1/4&b+7/12\end{pmatrix}.
\]

The positive eigenvalues of \(H\) are \(b-1/6\) and \(b+2/3\). For a pure excited vector with first-coordinate population \(p\), its smallest attainable cost is

\[
 h(p)=b+(7-8p)/12-\tfrac12\sqrt{p(1-p)},\qquad e(p)=(1+p)/4.
\]

The function \(h(p)+\log e(p)\) is strictly convex, since its second derivative is
\(1/[8(p(1-p))^{3/2}]-1/(1+p)^2>0\). Its value and derivative vanish at \(p=1/2\). Therefore \(\beta=1\) exactly.

Let \(a=(|1\rangle+|2\rangle)/\sqrt2\), \(z=(|1\rangle-|2\rangle)/\sqrt2\), and

\[
 \chi=\frac{a\otimes a-(z\otimes z)/9}{\sqrt{82/81}}.
\]

Direct algebra gives

\[
 q=\langle\chi|E^{\otimes2}|\chi\rangle=45/328,
 \qquad Q=\langle\chi|H_2|\chi\rangle=2b+1/82,
\]

and

\[
 -\log q-Q=\log(41/40)-1/82>1/82>0.
\]

Hence the two-use ratio is approximately \(1.00633151844\), while every separable block ratio is at most one. The regularized optimum is

\[
 \alpha=\frac{\log2\,[3b+5/12+\sqrt{(b-3/4)^2+1/2}]}{2(b^2+b/2-1/9)}
 \approx1.06013159818.
\]

A concrete CPTP realization is \(\Phi(\rho)=\operatorname{Tr}(E\rho)P_v+\operatorname{Tr}((I-E)\rho)P_u\), with \(u\perp v\). It has classical output and pure zero-cost reference. In a PPM code with \(N\) pulse positions, vacuum detection plus uniform guessing gives exact error \((1-1/N)q\) for this channel. The example is thus a physically valid finite quantum-input advantage under the declared mean-cost resource model.

## Scope failures and next question

- **Full coding reliability:** minimum vacuum mass is not automatically minimum decoding error. Coherent vacuum/nonvacuum output blocks can interfere. The inherited source's Cauchy–Schwarz converse has a message-count correction, requiring an appropriate growing-message regime before matching exponents. Fixed-message optimal coding can behave differently.
- **Hard energy constraint:** the projection onto \(L_m\)-typical space need not preserve support inside \(\{H_m\le Q\}\) when \([H,L]\ne0\). No hard-budget theorem has been proved.
- **Symmetry:** if \(\Phi\) is covariant under input time translations generated by \(H\), and \(P_v\) is invariant under the corresponding output evolution, then covariance of the adjoint gives \(e^{itH}Ee^{-itH}=E\). Thus \([E,H]=0\), and the equality criterion gives \(\alpha=\beta\). The strict effect concerns channels/costs with this symmetry broken.
- **Infinite dimensions:** the present cost-continuity argument uses bounded \(H\). Bosonic extensions require an additional tail/energy argument; they are not obtained by merely replacing matrices with unbounded operators.

Ranked next targets: (1) a short exact theorem with the separable optimum, equality criterion, two-use witness, and full primary-source attribution; moderate value, low mathematical risk, uncertain publication novelty; (2) the hard-energy-support problem for noncommuting \(H,E\), which could produce a less routine theorem; (3) a driven-channel realization with the coherence/preparation resources included in the cost, which decides whether the abstract input-cost advantage survives a useful physical resource account. For a frontier campaign, do not let the straightforward mean-cost result displace harder candidates solely because its proof closes cleanly.

Read-only local source path: `work/astra-research-knowledge/cards/P-q-excitation.txt`; its general pure-reference statement assumes \(H=I-P_0\), excludes unequal excited energies, and explicitly says the PPM/capacity-per-cost mechanism is standard. Read `work/RESEARCH_BRIEF.txt`, `work/astra-research-knowledge/00_START_HERE.txt`, and relevant `01_CORE.txt` entries. No source repository files were modified. Search covered primary literature on capacity per unit cost, exact/asymmetric testing, channel divergences, receiver vacuum projections, reliability, and quantum hedging. Absence of a verbatim formula in this search is weak negative priority evidence, not a novelty proof.
