# Independent audit of the anisotropic critical Gibbs experiment

Date: 2026-10-07. Auditor: `critical_gibbs_audit`.

## Verdict and scope

The candidate in `work/scouts/gibbs_criticality.md`, Sections 2–3, passes this independent mathematical audit for a fixed bounded parameter set. The three decisive steps—noncommuting symbol comparison, uniformly tilted critical radial tails, and full-state reverse recovery—can all be completed by the explicit arguments below. The reverse map is a parameter-independent state-preparation channel, not a parameter estimator.

This certifies the qualitative uniform equivalence in the stated collective spin-half model. It does not certify historical priority, a local-lattice critical model, gate-efficient implementation, preservation of an external purification, or a sharp joint finite-size/memory law. The scout's finite numerical checks were not used as proof. I do not independently certify the scout's subsequently proposed explicit Robbins-remainder constants.

Throughout, `T(rho,sigma)=||rho-sigma||_1/2`, classical TV is half the L1 distance, and logarithms are natural. Fix public constants `M,B<infinity` and

```text
Theta = {(A,b): A=A^T is real, ||A||op<=M, |b|<=B}.
J_i = (1/2) sum_{a=1}^N sigma_i^(a),
Q_A(J) = sum_{i,l} A_il (J_i J_l+J_l J_i)/2,
K_N(A,b) = 2J^2/N + Q_A(J)/N^(3/2) + b.J/N^(3/4),
rho_N(A,b) = exp(K_N(A,b))/Tr exp(K_N(A,b)).
```

The limiting experiment is one observation with Lebesgue density

```text
p_(A,b)(x) = Z_(A,b)^(-1)
             exp[-(4/3)|x|^4 + x^T A x + b.x],  x in R^3.
```

There are fixed parameter-independent channels `T_N,S_N` such that

```text
sup_Theta TV(T_N rho_N(A,b), p_(A,b)) -> 0,
sup_Theta T(S_N p_(A,b), rho_N(A,b)) -> 0.
```

## 1. The Jensen generator-defect lemma is correct

Let `Bcal` be unital CPTP, `K=K*`, and `tau=e^K/Z`. Operator concavity of log gives

```text
log Bcal(e^K) >= Bcal(log e^K) = Bcal(K).
```

Since `Bcal(tau)=Bcal(e^K)/Z`,

```text
D(tau || Bcal(tau))
 = Tr tau [K-log Bcal(e^K)]
 <= Tr tau [K-Bcal(K)]
 <= ||K-Bcal(K)||op.
```

Unitality ensures `Bcal(tau)` remains strictly positive. Trace preservation makes it a density matrix. There is no commutation assumption, no exponentiation of an operator inequality, and no missing normalizer. Quantum Pinsker then gives

```text
T(tau,Bcal(tau)) <= sqrt(Tr tau[K-Bcal(K)]/2)
                <= sqrt(||K-Bcal(K)||op/2).
```

The expectation on the right is automatically nonnegative because it dominates relative entropy. The proposed lemma is therefore valid exactly as needed.

## 2. Exact coherent identities, with an elementary derivation

Let `mu` be normalized area measure on `S^2`, `d_j=2j+1`, and `P_(j,u)=|j,u><j,u|` the spin-j coherent projector. Define

```text
Q_j(f) = d_j int f(u) P_(j,u) dmu(u),
B_j(X) = Q_j(u -> <j,u|X|j,u>).
```

The resolution of identity makes these unital/trace-preserving in the appropriate sense. Set

```text
T_il(J)=(J_i J_l+J_l J_i)/2,
R_il(J)=T_il(J)-delta_il j(j+1)I/3.
```

The exact identities are

```text
Q_j(u_i) = J_i/(j+1),
Q_j(u_i u_l-delta_il/3)
    = 2 R_il(J)/[(j+1)(2j+3)],
<J_i>_u = j u_i,
<T_il(J)>_u = j(j-1/2)u_i u_l+(j/2)delta_il.
```

For a direct check, diagonalize `J_3` and put `t=(1+u_3)/2`. The measure `d_j |<j,m|j,u>|^2 dmu(u)` has a beta density with parameters `j+m+1,j-m+1`. Its first two u_3 moments are

```text
E u_3 = m/(j+1),
E u_3^2 = 1/(2j+3)+2m^2/[(j+1)(2j+3)].
```

Rotation covariance gives the displayed tensor identities. The coherent lower moments also follow by writing a coherent spin-j vector as a symmetric product of `2j` spin-half vectors.

Consequently

```text
B_j(J_i) = lambda_1 J_i,  lambda_1=j/(j+1),
B_j(R_il) = lambda_2 R_il,
lambda_2=j(2j-1)/[(j+1)(2j+3)].
```

The rank-two operator is zero for `j=0,1/2`; the formulas remain valid. A rank-two *function* may still be retained in an upper symbol in these sectors, because its quantization is zero.

## 3. Explicit whole-system channels and full-state recovery

Use a fixed Schur transform

```text
H_N = direct_sum_j (V_j tensor C^(m_N(j))),
j=j_min,j_min+1,...,N/2,
j_min=0 for even N, 1/2 for odd N.
```

Every collective Gibbs state has identity on each multiplicity space. Let

```text
s_N=N^(3/4), k_j=j+1/2, r_j=k_j/s_N,
L=N+1,
m_N(j)=(2j+1)/L * binom(L,N/2-j).
```

To specify the radial jitter exactly, use cells centered at `r_j`: for the first sector take

```text
I_0=[0,(k_min+1/2)/s_N),
```

and for subsequent sectors take

```text
I_j=[(k_j-1/2)/s_N,(k_j+1/2)/s_N).
```

All cells have width `1/s_N`, except the first odd-N cell, which has width `3/(2s_N)`. Their union is `[0,R_N)`, where `R_N=(N+2)/(2s_N)`.

`T_N` measures sector j and the coherent POVM `d_j P_(j,u)dmu(u)` in that sector, traces out multiplicity, draws radius r uniformly in `I_j`, and outputs `x=ru`.

`S_N` maps an input x to its public radial cell (clamping `|x|>=R_N` to `j=N/2`), sets `u=x/|x|`, and prepares

```text
P_(j,u) tensor I_(m_N(j))/m_N(j)
```

before undoing the Schur transform. At `x=0` choose any fixed direction. These are well-defined parameter-independent CPTP/cq channels. Their exact composition is the sector coherent measure-and-prepare channel `B_N` with multiplicity reset.

Crucially, `B_N` is unital on the *entire* N-spin matrix algebra: on input identity, the sector/direction measurement density is `d_j m_N(j)`, and preparation gives

```text
d_j int P_(j,u)dmu(u) tensor I_(m_N(j))
 = I_(V_j) tensor I_(m_N(j)).
```

Let `A_0=A-(tr A)I/3`. Since central sector functions and the scalar quadratic part are fixed,

```text
K_N-B_N K_N
 = direct_sum_j [
    (1-lambda_2)Q_(A_0)(J)/N^(3/2)
   +(1-lambda_1)b.J/N^(3/4)] tensor I_mult.
```

Diagonalizing the real symmetric `A_0`, positivity of the operators `J_i^2` and `sum J_i^2=j(j+1)I` give

```text
||Q_(A_0)(J)||op <= ||A_0||op j(j+1),
1-lambda_2 = 3(2j+1)/[(j+1)(2j+3)] <= 3/(j+1),
(1-lambda_1)||b.J||op <= |b|.
```

Thus, globally and without discarding any sectors,

```text
||K_N-B_N K_N||op
 <= (3/2)||A_0||op N^(-1/2) + B N^(-3/4).
```

Section 1 gives uniform `T(rho_N,B_N rho_N)=O(N^(-1/4))`. This already supplies the quantum half of recovery. The uniformly bounded first radial moment below also gives

```text
D(rho_N||B_N rho_N)
 <= 3||A_0||op E_rho[j]/N^(3/2)+B/N^(3/4)
 = O(N^(-3/4)),
```

and hence the optional stronger recovery bound `O(N^(-3/8))`. No radial convergence rate is required for either recovery argument.

## 4. Noncommuting anisotropy: exact scalar symbol comparison

Within sector j write

```text
H_j=Q_A(J)/N^(3/2)+b.J/s_N,
R_j(u)=<j,u|exp(H_j)|j,u>.
```

The unnormalized encoded sector/direction density is `a_N(j) R_j(u)`, where

```text
a_N(j)=d_j m_N(j) exp[2j(j+1)/N].
```

Put `a=tr A/3`. The lower and upper symbols are exactly

```text
h_j^-(u)=a j(j+1)/N^(3/2)
          +j(j-1/2)u^T A_0 u/N^(3/2)+j b.u/s_N,
h_j^+(u)=a j(j+1)/N^(3/2)
          +(j+1)(j+3/2)u^T A_0 u/N^(3/2)+(j+1)b.u/s_N.
```

The identities in Section 2 imply `h_j^-=<H_j>_u` and `H_j=Q_j(h_j^+)`. Their difference obeys

```text
|h_j^+-h_j^-|
 <= delta_j:=3(j+1/2)||A_0||op/N^(3/2)+B/s_N,
delta_*:=max_j delta_j=O(N^(-1/2)).
```

The necessary exponential inequalities are entirely scalar:

1. Jensen for the spectral measure of `H_j` in a coherent vector gives `R_j(u)>=exp(h_j^-(u))` pointwise.
2. For each eigenvector psi of `H_j` with eigenvalue h, the function `d_j|<psi|j,u>|^2` is a probability density, so `h=int h_j^+(u)d_j|<psi|j,u>|^2dmu`. Scalar Jensen and summation over an eigenbasis give

```text
Tr exp(H_j)/d_j <= int exp(h_j^+(u))dmu(u)
                <= exp(delta_j) int exp(h_j^-(u))dmu(u).
```

No operator monotonicity of exp is invoked. Multiplying by `a_N(j)` and summing shows that the unnormalized encoded density dominates `a_N(j)e^(h_j^-)`, with total mass at most `e^(delta_*)` times its mass. The normalized distributions therefore differ in TV by at most `1-e^(-delta_*)`.

Now set `h(r,u)=r^2 u^T A u+r b.u`. The alternate form of the lower symbol is

```text
h_j^- = j^2 u^T A u/N^(3/2)
         +(j/2)(tr A-u^T A u)/N^(3/2)+j b.u/s_N.
```

Because `|tr A-u^T A u|<=2M` and `k_j=j+1/2`,

```text
sup_(j,u,Theta) |h_j^-(u)-h(r_j,u)|
 <= M(N+1/4)/N^(3/2)+B/(2s_N)=O(N^(-1/2)).
```

Uniformly bounded log-density perturbations give another `O(N^(-1/2))` TV bound after normalization. Therefore the actual encoded law is uniformly `O(N^(-1/2))` from the radially jittered discrete experiment with weights

```text
a_N(j) exp[h(r_j,u)] dmu(u).
```

This closes the noncommuting-symbol step globally, including small spin sectors. Compact coherent concentration offers an alternative proof, but is unnecessary here.

## 5. Critical radial law and uniform tail control

With `k=k_j,L=N+1`, the exact scalar weight is

```text
a_N(j)= (4k^2/L) binom(L,L/2-k)
          exp[2k^2/N-1/(2N)].
```

On every fixed interval `0<=r=k/N^(3/4)<=R`, Stirling and the binomial entropy expansion give uniformly

```text
binom(L,L/2-k)
 = 2^L sqrt(2/(pi L))
   exp[-2k^2/L-(4/3)k^4/L^3
        +O_R(k^2/L^2+k^6/L^5+1/L)].
```

The displayed error is `O_R(N^(-1/2))` on this scaling. The exponent after adding the Gibbs term is

```text
2k^2/[N(N+1)] -(4/3)k^4/(N+1)^3 -1/(2N),
```

so the quadratic part vanishes while the quartic part converges to `-(4/3)r^4`. The prefactor consequently gives

```text
a_N(j)/2^N
 = c_0 r_j^2 exp[-(4/3)r_j^4] (1+o_R(1)),
c_0=8sqrt(2/pi),
```

uniformly on compact scaled radii, including the first sector (whose radius is positive and tends to zero).

Here is a sufficient global tail proof. Let

```text
I(z)=((1+z)log(1+z)+(1-z)log(1-z))/2.
```

Its even-power series has nonnegative coefficients, hence `I(z)>=z^2/2+z^4/12` for `|z|<=1`. In the interior zone `k<=L/4`, uniformly bounded Stirling prefactors give

```text
binom(L,L/2-k)
 <= C 2^L L^(-1/2) exp[-2k^2/L-(4/3)k^4/L^3].
```

Since `2k^2/(NL)<=L/(2N)<=1` and `(N/L)^3>=1/8`, this implies

```text
a_N(j)/2^N <= C r_j^2 exp[-r_j^4/6].
```

Tilting multiplies this envelope by at most `exp[M r_j^2+B r_j]`. The envelope is integrable with every polynomial radial moment. Its Riemann-sum tails vanish uniformly as the tail threshold grows.

In the exterior zone `k>L/4`, the crude binomial entropy bound (without a Stirling prefactor) gives

```text
a_N(j)/2^N <= 2L exp[1-L/192].
```

Indeed `k^4/L^3>L/256` and `4k^2/L<=L`. The additional tilt is at most `exp[O_M(sqrt(N))+O_B(N^(1/4))]`. Summing at most N sectors makes this exterior contribution exponentially small, even after any fixed polynomial moment factor and after division by `N^(3/4)`.

For normalization, sectors with `1<=r_j<=2` have uniformly positive compact-asymptotic weights, their tilts are bounded below, and there are order `N^(3/4)` such sectors. Thus the tilted discrete normalizer divided by `2^N N^(3/4)` stays uniformly bounded below. The tail envelopes bound it above. They also imply uniform `E j=O(N^(3/4))` for the tilted lower-symbol law and the actual Gibbs sector law, the latter by the integrated symbol bounds of Section 4.

To conclude TV rather than weak convergence, consider the jittered density with respect to `dr dmu(u)` after dividing the unnormalized weights by `2^N N^(3/4)`. On ordinary cells this is exactly

```text
[a_N(j)/2^N] exp[h(r_j,u)].
```

Compact asymptotics and vanishing cell width give uniform convergence on every compact annulus to

```text
c_0 r^2 exp[-(4/3)r^4+r^2 u^T A u+r b.u].
```

The origin contributes uniformly `O(epsilon^3)` on `r<=epsilon`; the first odd-N cell's exceptional width contributes `O(N^(-9/4))`. The uniform tail envelopes control large radii. These three regions give uniform unnormalized L1 convergence, uniform normalizer convergence, and finally uniform TV convergence. Under `x=ru`, Lebesgue measure is `dx=4pi r^2 dr dmu(u)`, so the normalized limit is exactly `p_(A,b)(x)`.

## 6. Completing bidirectional equivalence

Let `alpha_N=sup_Theta TV(T_N rho_N,p_(A,b))`, proved to tend to zero in Sections 4–5, and `beta_N=sup_Theta T(rho_N,B_N rho_N)`, proved to tend to zero in Section 3. Contractivity gives

```text
T(S_N p_(A,b),rho_N)
 <= T(S_N p_(A,b),S_N T_N rho_N)
       +T(B_N rho_N,rho_N)
 <= alpha_N+beta_N.
```

All maps use N, the public spin decomposition, radial cells, and coherent projectors only. They never use A, b, a tilted sector distribution, or an estimator of them. The output includes the full multiplicity state. The proof thus establishes the intended whole-density statistical equivalence, not merely a magnetization distribution or an asymptotic moment identity.

## 7. Corrections and limits to preserve in the assembled report

- Specify parity and origin cells; a bare instruction to jitter and round is incomplete at the origin and beyond the largest sector. The construction above resolves both.
- Specify natural-log entropy and `T=||.||_1/2`; the Pinsker factors then match the scout.
- The rank-two function in an upper symbol need not be zero when rank-two operators are absent. Either retain it (its quantization vanishes) or state an exceptional-sector symbol. Do not conflate these two objects.
- The elementary eigenbasis/Jensen proof supplies exactly the integrated upper bound needed. It avoids any stronger pointwise upper-symbol exponential claim, which is not asserted here.
- The coherent channel is unital on the full system only after accounting for multiplicity reset correctly. The explicit calculation above verifies that property.
- The scalar part of A changes radial weights. It is preserved by the coherent channel and appears as `x^T A x` in the limit; it must not be discarded as an irrelevant within-sector scalar.
- Bounded M and B are essential for uniformity. The present proof does not cover parameter bounds growing with N.
- The classical result holds for each finite fixed bounded parameter set. It is not a theorem about arbitrary unknown microscopic Gibbs Hamiltonians or spatial critical universality.
- If compression claims are transferred, retain additive thermodynamic remainders. This audit did not inspect the sharp finite-memory proof or establish a complete joint N,D rate.

## 8. Final report transcription check

I read Section 3 of `outputs/research_report.tex`. Its generator coefficient, quartic coefficient, entropy direction, conservative recovery rate, compact-parameter uniformity, and external-reference exclusion agree with the proof above. There is no mathematical transcription defect in the critical-experiment statement. I sent the main agent two concrete presentation repairs: define `F_j=Q_A(J)/N^(3/2)+b.J/N^(3/4)` before use, and replace the statement that composition is exact "before jitter" by the stronger and relevant identity `S_N T_N=B_N` with matched radial cells. Calling `F_j` a nonscalar generator is imprecise because the scalar part of A remains included and carries radial information. The report's memory proposition was checked for faithful outline-level transcription, but its full independent proof is outside this audit's assigned certification.

Memory use was limited to preserving the earlier Gaussian audit's distinction between finite checks, internal proof, and external/priority validation (`MEMORY.md:82,96–97`, prior rollout `01a1121a-4750-72f0-8f5c-b501038890d3`). No remembered mathematical assertion supplies a step of this proof.
