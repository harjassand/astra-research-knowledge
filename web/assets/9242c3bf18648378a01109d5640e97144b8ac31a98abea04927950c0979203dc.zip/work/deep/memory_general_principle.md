# Posterior-regret geometry and finite-dimensional reconstruction

Independent derivation, 7 October 2026. Scientific status: internally derived
theorems below, with proofs supplied; external review and historical priority
remain unresolved. This note is independent of the quantum-to-Gaussian bridge.
It recovers the pure Gaussian memory rate in card N07 and gives a sharper
classification that distinguishes smooth likelihoods from moving supports.

## 1. Resource model and the exact trace inequality

Let `Theta ~ pi`, `X | Theta=theta ~ P_theta`, and let `mu` be the marginal law
of `X`. Observation, parameter, and output spaces are standard Borel. A public
seed `R` is independent of `(Theta,X)`. At each seed value, the encoder maps
`x` to a density operator `rho_{x,r}` on

\[
 \mathcal A_r=\bigoplus_j M_{d_j(r)},\qquad
 D_r=\sum_j d_j(r)\le D.
\]

The decoder performs an arbitrary POVM, with any additional independent
randomness absorbed into that POVM, and outputs a fresh observation `Y`.
Every input-dependent classical register is included in the direct sum.
There is no retained observation, input-dependent public seed, feedback, or
entanglement assistance. The memory cost is `log_2 D`, not the number of real
parameters describing a density matrix. Pure classical memory with `D` labels
is included.

**Lemma 1 (localized trace bound).** For every measurable `B` in the input
space and every measurable family of sets `A_a` indexed by decoder actions,

\[
 \Pr\{X\in B,\ X\in A_{a(Y,R)}\}
 \le D\sup_a\mu(B\cap A_a).
 \tag{1}
\]

In particular, if `f:X -> Z` is a measurable map to a metric space and the
decoder estimates `f(X)` by any `a(Y,R) in Z`, then

\[
 \Pr\{X\in B,\ d(f(X),a(Y,R))\le t\}
 \le D\,\beta_B(t),\quad
 \beta_B(t)=\sup_{z\in Z}\mu\{X\in B:d(f(X),z)\le t\}.
 \tag{2}
\]

*Proof.* Fix `r` and let `M_r` be its decoder POVM. Define the finite measure
`nu_r(E)=Tr M_r(E)`, of total mass `D_r`. The matrix-valued Radon--Nikodym
derivative `m_r(y)` satisfies `m_r(y)>=0` and `Tr m_r(y)=1` almost everywhere.
Since `0<=rho_{x,r}<=I`,

\[
 \operatorname{Tr}(\rho_{x,r}M_r(dy))
 \le\operatorname{Tr}M_r(dy)=\nu_r(dy).
\]

Integration gives

\[
 \begin{split}
 \Pr\{X\in B\cap A_{a(Y,r)}\mid R=r\}
 &\le \int\nu_r(dy)\,
       \mu(B\cap A_{a(y,r)})\\
 &\le D_r\sup_a\mu(B\cap A_a).
 \end{split}
\]

The input law conditional on `R=r` is `mu`; this is the exact point where
independence of the seed is used. Average over `r`. The direct sum is simply
a block diagonal realization on a Hilbert space of dimension `D_r`. ∎

The lemma does not need differential entropy, injectivity of `f`, an iid
source, or an information inequality. The estimate may use the seed even if
the final reconstruction criterion only compares the seed-averaged law of
`Y` with the original experiment.

For `alpha>0`, layer-cake integration yields the stronger distortion bound

\[
 \mathbb E\big[\mathbf1_Bd(f(X),a(Y,R))^\alpha\big]
 \ge \alpha\int_0^\infty
       t^{\alpha-1}\big[\mu(B)-D\beta_B(t)\big]_+\,dt.
 \tag{3}
\]

This is a finite-`D` inequality, not merely an asymptotic exponent statement.

## 2. Exact reconstruction converse through bounded Bayes regret

The decoder output space is now the original observation space. Write
`Q_theta` for the seed-averaged output law. Set

\[
 e=\sup_\theta\|Q_\theta-P_\theta\|_{\rm TV},\qquad
 e_\pi=\int\|Q_\theta-P_\theta\|_{\rm TV}\,\pi(d\theta).
\]

The convention is `TV(P,Q)=sup_A|P(A)-Q(A)|`, so a loss in `[0,L]` changes its
expectation by at most `L TV(P,Q)`.

Let `ell(theta,a) in [0,L]` be a measurable decision loss, and let `b(x)` be a
fixed measurable Bayes rule under `pi`. Denote the posterior by `pi_x` and
define its regret

\[
 \Gamma(x,a)=\int\ell(\theta,a)\pi_x(d\theta)
             -\int\ell(\theta,b(x))\pi_x(d\theta)\ge0.
\]

For a measurable localized input set `B`, put `M=mu(B)` and

\[
 V_B(u)=\sup_a\mu\{x\in B:\Gamma(x,a)\le u\}.
\]

**Theorem 2 (regret-volume converse).** Every permitted code satisfies

\[
 L e\ \ge L e_\pi\ \ge
 \mathbb E\Gamma(X,b(Y))\ \ge
 \int_0^\infty[M-D V_B(u)]_+\,du.
 \tag{4}
\]

*Proof.* Conditional on `X`, the posterior of `Theta` is still `pi_X` after
conditioning also on the encoded state, seed, and decoder output. Thus

\[
 \mathbb E\Gamma(X,b(Y))
 =\mathbb E\ell(\Theta,b(Y))-
  \mathbb E\ell(\Theta,b(X)).
 \tag{5}
\]

The right side is at most `L e_pi`, because `b` is a fixed rule applied to the
original or reconstructed observation. Apply Lemma 1 to the sublevel sets of
`Gamma`, and integrate the tail probability. ∎

The rule `b(Y)` in (5) is deliberately seed-independent. Marginal
reconstruction TV does not control a loss selected using `(Y,R)` without a
stronger joint reconstruction condition. Lemma 1 itself allows arbitrary
seed-dependent estimates, so the geometric converse loses no power from
free shared randomness.

If

\[
 V_B(u)\le C u^Q,\qquad 0\le u\le u_0,\quad Q>0,
\]

then for `D >= M/(C u_0^Q)`,

\[
 e\ge \frac{Q}{L(Q+1)}
          M^{1+1/Q}(CD)^{-1/Q}.
 \tag{6}
\]

Indeed, integrate `M-DCu^Q` up to `(M/(DC))^{1/Q}`. The exponent `Q` is the
mass dimension of posterior regret. Unlike a chosen metric dimension, it
does not change when one rewrites a distance by a snowflake transformation.

**Corollary 3 (metric and calibration form).** Suppose on `B`, for every
action `a`,

\[
 \Gamma(x,a)\ge c\,d(f(x),\zeta(a))^\alpha,
\]

and `beta_B(t)<=C t^s` for `0<t<=t_0`, where `s,alpha,c>0`. Then for
`D>=M/(C t_0^s)`,

\[
 e\ge \frac cL\frac{s}{s+\alpha}
          M^{1+\alpha/s}(CD)^{-\alpha/s}.
 \tag{7}
\]

For all `D>=1`, a convenient valid bound is

\[
 e\ge\frac{cM}{2L}
 \left[\min\left(t_0,
             \left(\frac{M}{2CD}\right)^{1/s}\right)\right]^\alpha.
 \tag{8}
\]

The ratio `s/alpha` equals the regret-volume exponent `Q`. The metric
statement can be localized to one positive-mass regular chart even when the
full posterior law has atoms, tails, singular strata, or bad conditioning.
One can choose the prior on a finite or continuous subset of the parameter
family; uniform error over the full family controls the risk of every such
prior.

## 3. Useful bounded posterior scores, including continuum priors

### 3.1 Hilbert features

Let `H` be a separable Hilbert space and `phi:Theta -> H` satisfy
`||phi(theta)||<=B`. Restrict actions to the closed convex hull of the feature
range. The squared loss

\[
 \ell(\theta,a)=\|\phi(\theta)-a\|^2\in[0,4B^2]
\]

has Bayes rule

\[
 f(x)=\mathbb E[\phi(\Theta)\mid X=x],
\]

and exact regret

\[
 \Gamma(x,a)=\|f(x)-a\|^2.
 \tag{9}
\]

This works for arbitrary continuum priors. A bounded characteristic kernel
gives a posterior kernel-mean embedding and a bounded score of this form.
Integrated Brier scores, for example features
`phi(theta)(t)=1_{theta<=t}` in `L^2(nu)` for a finite measure `nu`, provide
another continuum construction. A selected smooth kernel can make a sharp
support boundary appear smooth: injectivity of the posterior embedding alone
does not guarantee the strongest available converse.

For a finite prior on `m` hypotheses, the ordinary Brier loss

\[
 \ell(i,a)=\sum_{j=1}^m(\mathbf1_{j=i}-a_j)^2\in[0,2],
 \qquad a\in\Delta_{m-1},
\]

has posterior vector `w(x)` as its Bayes rule, and regret
`||w(x)-a||_2^2`. Thus `E||w(X)-w(Y)||^2<=2e_pi` exactly.

### 3.2 A continuum density-Brier score

The formal point-mass feature for a continuous parameter is not in `L^2`.
One cannot use an unbounded density score and still charge its risk
difference by TV. There is, however, a direct bounded score when the relevant
posterior densities are uniformly bounded.

Suppose `pi_x(dtheta)=q_x(theta)pi(dtheta)`, with jointly measurable versions
satisfying `0<=q_x<=G` and `int q_x dpi=1` for every relevant observation
(extend a safe version on null observations). Then

\[
 \ell(\theta,y)=\|q_y\|_{L^2(\pi)}^2-2q_y(\theta)+2G
              \in[0,3G]
\]

has `y=x` as a Bayes action and exact regret

\[
 \Gamma(x,y)=\|q_x-q_y\|_{L^2(\pi)}^2.
 \tag{10}
\]

More generally one may use concrete bounded densities as actions, including
convex combinations of posterior densities. Jointly measurable concrete
versions avoid the ambiguity of evaluating an `L^2` equivalence class at a
single parameter value. The boundedness assumption is substantial: it is
not an automatic property of continuum posteriors.

Equation (10) detects moving posterior supports. Their density distance can
be a square-root snowflake of ordinary observation distance, which changes
the memory exponent even though the observation dimension is unchanged.

## 4. A constructive classical upper from second differences

The following upper is an explicit stochastic encoder and decoder, and
fits the allowed public-seed resource model. It is stronger than replacing a
continuous observation by a finite atomic output, which would have TV one.

Consider a family of densities `p_theta` on the `k`-torus with Haar measure.
Assume for each coordinate and some `0<beta_i<=2`,

\[
 \sup_\theta\|
  p_\theta(\cdot+h e_i)+p_\theta(\cdot-h e_i)-2p_\theta
  \|_1\le C_i|h|^{\beta_i},\qquad |h|\le\tfrac12.
 \tag{11}
\]

Let `J_i` be integer grid sizes, `h_i=1/J_i`, and
`N=prod_i J_i`. Publicly choose a uniformly random shift of the product grid.
The encoder sends the label of the shifted cell containing `X`. The decoder
samples `Y` uniformly in that cell. Every seed uses exactly `N` classical
labels; it does not retain a point or a cell-dependent density description.

Averaging the shift gives convolution with the tensor product of triangular
kernels

\[
 k_h(t)=h^{-1}(1-|t|/h)_+,
\]

periodized on the torus. This follows because two points at displacement
`t` lie in one shifted interval with probability `(1-|t|/h)_+`, and the
decoder density within the interval is `1/h`.

For one coordinate, symmetry gives

\[
 T_h p-p=\frac12\int k_h(t)
  [p(\cdot+t)+p(\cdot-t)-2p],dt.
\]

Since `int k_h(t)|t|^beta dt=2h^beta/[(beta+1)(beta+2)]`, (11) and the
`L^1` contraction of convolution imply, for all `J_i>=2`,

\[
 \sup_\theta\|Q_\theta-P_\theta\|_{\rm TV}
 \le \sum_i
 \frac{C_i}{2(\beta_i+1)(\beta_i+2)}J_i^{-\beta_i}.
 \tag{12}
\]

The telescoping product estimate does not require a product density or any
mixed partial derivatives. Put

\[
 Q=\sum_i\frac1{\beta_i},\qquad
 J_i=\left\lfloor D^{1/(Q\beta_i)}\right\rfloor.
\]

Then `prod_i J_i<=D` and, after increasing the fixed constant for bounded
`D`,

\[
 e_D^{\rm classical}\le C D^{-1/Q}.
 \tag{13}
\]

For `beta_i=2`, condition (11) follows from a uniform integrable second
derivative in coordinate `i`. For `beta_i=1`, it follows from a uniform
coordinatewise BV bound, since the second difference is at most twice the
first difference. These are checkable analytic sufficient conditions, not
an assumed reconstruction result.

The same upper applies after a known invertible companding transform. It
also applies to a sufficient coordinate `T(X)` when the omitted observation
can be regenerated by a parameter-independent conditional kernel. These
conditions must be proved for the particular experiment; posterior small
balls by themselves supply no achievability theorem.

The continuous public shift is free only because the resource model permits
arbitrary independent shared classical seeds. For the smooth `beta=2` case,
fixed positive encode/decode hat partitions provide an alternative without
public shifts. Neither version by itself is a finite-bit runtime theorem.

## 5. A sharp classification theorem for bounded location experiments

Here the lower and upper fit together with explicit, verifiable conditions.

**Theorem 4 (anisotropic posterior classification).** On `T^k`, consider

\[
 P_\theta(dx)=g(x-\theta)dx,\qquad \theta\in\mathbb T^k,
\]

where `g>=0`, `int g=1`, and `||g||_infty=G<infinity`. Suppose (11) holds
for `g` with exponents `beta_i`, and there is `c>0` such that

\[
 \|g(\cdot-x)-g(\cdot-y)\|_2^2
 \ge c\sum_i d_{\mathbb T}(x_i,y_i)^{\beta_i}
 \quad\text{for all }x,y.
 \tag{14}
\]

Set `Q=sum_i 1/beta_i`. For all integer `D>=1`,

\[
 e_D^{\rm quantum/hybrid/public\ seed}
       =\Theta_g(D^{-1/Q}).
 \tag{15}
\]

The upper is attained by a classical memory. Equality here means the
exponent and dimension order, not equality of classical and quantum optimal
constants.

*Lower proof.* Use Haar prior on `Theta`. Then `X` is Haar and its posterior
density is `q_x(theta)=g(x-theta)`, bounded by `G`. The density-Brier score
has range `[0,3G]` and regret `||q_x-q_y||_2^2`. For an arbitrary center
`a in L^2`, let

\[
 A=\{x:\|q_x-a\|_2\le t\}.
\]

If nonempty, fix `x_0 in A`. Every `x in A` satisfies
`||q_x-q_{x_0}||_2^2<=4t^2`. Equation (14) places `A` in a product rectangle
with coordinate radii `(4t^2/c)^{1/beta_i}`. Consequently

\[
 \sup_a |A|\le C_{\rm ball} t^{2Q},\qquad
 C_{\rm ball}=2^k(4/c)^Q.
 \tag{16}
\]

This bound is valid even when a coordinate radius exceeds half the circle:
the corresponding factor on the right is then at least one. Apply (7) with
`M=1`, `alpha=2`, `s=2Q`, `L=3G`, and calibration constant one. In particular,

\[
 e_D\ge
 \frac{Q}{3G(Q+1)}C_{\rm ball}^{-1/Q}D^{-1/Q}.
 \tag{17}
\]

The upper is (13). ∎

The global bound (14) can be weakened to local separation plus a finite
number of symmetry copies, with a changed small-ball constant. A coordinate
that is statistically ancillary must be removed; smoothness alone never
certifies its contribution to `Q`.

### 5.1 Explicit mixed smooth/support family

Choose `r` coordinates with densities

\[
 g_i(t)=1+a_i\cos(2\pi t),\qquad 0<a_i<1,
\]

and `t` further coordinates with densities

\[
 g_i(u)=b_i^{-1}\mathbf1_{[0,b_i]}(u),\qquad 0<b_i<1.
\]

Let `g` be their product, and let the full translation vector be unknown.
There are `k=r+t` coordinates. Smooth coordinates have `beta_i=2`; moving
support coordinates have `beta_i=1`. Therefore

\[
 \boxed{\quad e_D=\Theta\big(D^{-2/(r+2t)}\big),\qquad
 \log_2D_{\rm opt}(\epsilon)
 =\left(\frac r2+t\right)\log_2(1/\epsilon)+O(1).\quad}
 \tag{18}
\]

Every fixed amplitude and interval width is known to encoder and decoder;
only the translation vector is unknown. Constants depend on these fixed
choices.

Here are the needed analytic facts, so (18) is not an appeal to an unnamed
regularity result. For a smooth coordinate,

\[
 \|\tau_h g_i-g_i\|_2^2
 =a_i^2[1-\cos(2\pi h)]\asymp a_i^2d_\mathbb T(h,0)^2,
\]

and `||g_i''||_1=8 pi a_i`, so its second `L^1` modulus has order two. For
an interval coordinate, writing `u=d_T(h,0)<=1/2`,

\[
 \|\tau_hg_i-g_i\|_2^2
 =\frac{2}{b_i^2}\min(u,b_i,1-b_i)
 \asymp_{b_i} u.
 \tag{19}
\]

Its torus total variation is `2/b_i`, giving
`||Delta_h^2 g_i||_1<=4|h|/b_i`. Thus the posterior density metric of that
coordinate is comparable to `u^{1/2}`: its metric small-ball dimension is
two, although its observation coordinate has dimension one.

For the product, put `c_i=||g_i||_2^2` and
`w_i(h)=||tau_hg_i-g_i||_2^2`. Nonnegativity of `g_i` gives
`0<=w_i/(2c_i)<=1`, and

\[
 \|\tau_hg-g\|_2^2
 =2\left(\prod_i c_i\right)
  \left[1-\prod_i\left(1-\frac{w_i(h_i)}{2c_i}\right)\right]
 \ge\frac{\prod_i c_i}{k}\sum_i\frac{w_i(h_i)}{c_i}.
 \tag{20}
\]

This proves (14). Coordinate second differences factor in `L^1`, because
the other factors have integral one, proving (11).

Important special cases:

* One smooth circular location coordinate: `e_D=Theta(D^{-2})`.
* One translated uniform interval: `e_D=Theta(D^{-1})`.
* A translated `k`-dimensional uniform box: `e_D=Theta(D^{-1/k})`.
* `r` smooth and `t` support-boundary coordinates: (18).

Thus observation dimension or parameter dimension alone is not the
classification. The posterior regret volume, including its anisotropic
snowflake geometry, determines the exponent in these families.

### 5.2 Finite hypotheses can change this geometry completely

A translated uniform interval restricted to `m` fixed parameter values has
an exact common partition with at most `2m` positive-length cells, formed by
the support endpoints. Every likelihood is constant on each cell. Encoding
the cell label and decoding uniformly in that cell reconstructs every law
exactly. Its posterior has finitely many values.

In contrast, a Gaussian family on only `s+1` affinely independent means has a
continuously varying `s`-dimensional posterior, and still needs unbounded
memory for vanishing error. Finite hypothesis count does not determine
finite sufficient-observation alphabet size. It can produce finite exact
memory for piecewise constant likelihoods and fail to do so for Gaussian
likelihoods.

## 6. Independent recovery of the bounded Gaussian rate

Let the means lie in a fixed bounded nonempty set with affine dimension
`s>=1`; covariance is fixed and positive definite. Whiten and remove known
ancillary coordinates, giving `P_theta=N(theta,I_s)`.

Select `s+1` affinely independent means and a positive finite prior. The
posterior mean `m(x)=E[Theta|X=x]` satisfies

\[
 Dm(x)=\operatorname{Cov}(\Theta\mid X=x)>0.
\]

On a fixed compact convex cube `B`, the smallest eigenvalue is bounded below
by `v>0`. Hence

\[
 \|m(x)-m(x')\|\ge v\|x-x'\|\quad(x,x'\in B),
\]

by integrating the monotonicity inequality along the segment. The mixture
density is bounded on `B`, so any posterior ball of radius `t` intersects
`B` in mass at most `C t^s`: pick one point of the intersection, use the
triangle inequality, and pull back a Euclidean ball of radius `2t/v`.
The bounded squared loss on the convex hull of the selected means has exact
regret `||m(X)-a||^2`. Corollary 3 gives `e_D>=c D^{-2/s}`.

For a constructive upper, use the broad reference density

\[
 g(x)=N(0,4),\qquad u=\Phi(x/2).
\]

In one coordinate the transformed target density is

\[
 q_\theta(u)=r_\theta(x),\qquad
 r_\theta(x)=\frac{p_\theta(x)}{g(x)}
 =2\exp[-3x^2/8+\theta x-\theta^2/2].
\]

Writing `a(x)=theta-3x/4`, one has

\[
 q_\theta'(u)=\frac{r_\theta'(x)}{g(x)},\qquad
 \|q_\theta''\|_{L^1(0,1)}
 =\int_\mathbb R
   \left|\left(\frac{r_\theta'(x)}{g(x)}\right)'\right|dx,
\]

and

\[
 \left(\frac{r_\theta'}g\right)'
 =\frac{r_\theta}g
   \left[-\frac34+
      \left(\theta-\frac{3x}4\right)
      \left(\theta-\frac x2\right)\right].
 \tag{21}
\]

The factor `r_theta/g` has a Gaussian tail `exp[-x^2/4+theta x]`, up to a
bounded-mean constant. Thus the integral in (21) is uniformly finite for
bounded `theta`. Both `q_theta` and `q_theta'` vanish at the endpoints, so
the transformed density extends periodically in `W^{2,1}`. In `s`
coordinates the density factors; coordinate second-derivative norms are
uniformly bounded since every other factor integrates to one.

Apply the dithered-grid upper with all `beta_i=2`, and transform the sampled
output back by `x=2Phi^{-1}(u)`. The transform preserves TV and gives
`e_D<=C D^{-2/s}`, without a tail truncation or tail logarithm. Therefore

\[
 e_D=\Theta_\Theta(D^{-2/s}).
\]

The covariance, mean set, and affine geometry are fixed before `D` varies.
Nearly colliding means can make the lower constant arbitrarily small.
Affine dimension zero is a known single law, reconstructible with one label.
The construction is a measurable continuous-output channel. A deterministic
finite-bit real output would be atomic and is a different TV interface.

## 7. What the theorem does and does not classify

1. The converse is universal for the declared dimension bottleneck. It
   covers pure classical, pure quantum, hybrid, stochastic, and independent
   public-seed encoders, and only counts the dimension through the trace of
   the decoder identity.
2. One positive-mass posterior chart suffices. Global differential entropy,
   a full-dimensional parameter interior, or a continuum prior is not
   necessary. Different priors and bounded scores can expose different
   obstructions; one should use the strongest justified regret-volume bound.
3. Matching upper bounds require a positive finite-label reconstruction
   operator and actual likelihood regularity. An ordinary distortion
   quantizer or a posterior metric dimension by itself is insufficient.
4. Smooth and moving-support directions combine additively in the regret
   volume exponent `Q`; each smooth direction contributes `1/2`, while each
   uniform moving-support direction contributes `1`. The quantum memory
   cannot improve their dimension exponent, although it may improve a
   constant.
5. A bounded characteristic-kernel posterior embedding need not give a sharp
   bound for a discontinuous likelihood. The continuum density-Brier score
   captures that example precisely because the posterior densities are
   uniformly bounded.
6. If the parameter family, prior, amplitudes, or posterior conditioning vary
   with `D`, constants must be tracked. Fixed-experiment exponents do not
   automatically settle simultaneous signal/precision limits.
7. Ancillary or symmetry directions must be quotiented or handled by a
   finite number of symmetry charts. The ambient observation dimension is
   not always the statistically relevant dimension.

## 8. Position relative to existing machinery

The broad mechanism is established: posterior/likelihood quantization and
bounded decision-risk comparison are part of classical comparison of
experiments. A bounded primary-source check confirmed that
[Strasser, *Towards a statistical theory of optimal quantization*](https://www.math4tune.com/publications/Strasser%202000,%20quantization%20Bock,%20article.pdf)
reduces finite statistical-experiment reductions to quantization of standard
likelihood measures and compares their convex Bayes utilities. This note
does not claim that viewpoint, or a general dimension-versus-distortion
exponent, as new.

The reusable technical output here is the exact localized trace/regret
integral (4), its metric/calibration version with constants, the explicit
positive dithered reconstruction upper, and a fully worked anisotropic
classification with moving supports. The bounded search did not establish
historical novelty of this combination. N07's original report likewise
records unresolved priority. No literature absence is being treated as a
proof of novelty.

No finite diagnostic is necessary for the theorem: the main bounds are exact
integral inequalities and explicit analytic computations. The assertions
above remain mathematical claims open to independent proof audit.

## 9. Tapered moving endpoints: why one must optimize the score at scale

This addendum independently audits the stronger mechanism proposed by the
`statistical_geometry` worker. It is a concrete new technical application of
Theorem 2, and prevents overinterpreting a fixed Hilbert posterior metric as
a universal classification.

Fix `beta>=0`, and consider the experiment

\[
 p_\theta(x)=\frac{\beta+1}{\theta^{\beta+1}}
              (\theta-x)^\beta\mathbf1_{[0,\theta]}(x),
 \qquad \theta\in[1,2].
 \tag{22}
\]

For `beta=0`, use the usual value one on the interior of the support; choices
at the endpoints are irrelevant. Under the same memory interface,

\[
 \boxed{\quad e_D=\Theta_\beta
       \left(D^{-\min(\beta+1,2)}\right).\quad}
 \tag{23}
\]

This is not an upper inferred from ordinary distortion quantization. The
output is genuinely continuous, with an explicit positive reconstruction
kernel described below.

### 9.1 A uniformly bounded hinge score

For any posterior density `q` relative to a probability prior `pi`, let

\[
 \phi_\lambda(z)=(z-\lambda)_+,\qquad
 g_\lambda(z)=\mathbf1_{\{z>\lambda\}},
\]

and define the action score

\[
 S_\lambda(\theta,q)=
 \lambda\,\pi\{q>\lambda\}-\mathbf1_{\{q(\theta)>\lambda\}}.
 \tag{24}
\]

Its range is `[-1,lambda]`. Adding one gives a loss in `[0,1+lambda]`,
regardless of how large `q` becomes. Under a true posterior density `f`, its
excess risk relative to action `f` is exactly

\[
 \mathcal D_\lambda(f,q)=
 \int[\phi_\lambda(f)-\phi_\lambda(q)
             -g_\lambda(q)(f-q)]\,d\pi\ge0.
 \tag{25}
\]

This follows by writing the score as
`int(q g_lambda(q)-phi_lambda(q))dpi-g_lambda(q(theta))`; the first
integrand is `lambda 1_{q>lambda}`. Convexity of the hinge proves propriety.
The score is not strictly proper, but strict propriety is unnecessary for
the separation calculation. Its bounded range is the feature that allows
TV to charge the regret of a singular posterior boundary.

### 9.2 Tapered lower for `0<=beta<=1`

Use the fixed prior

\[
 \pi=\tfrac12\operatorname{Unif}[1,2]+\tfrac12\delta_2.
\]

Let `p(x)` be the predictive density and `f_x(theta)=p_theta(x)/p(x)` for
`0<=x<2`. One has

\[
 p(x)\le\beta+1,\qquad
 p(x)\ge\tfrac12p_2(x),\qquad
 0\le f_x\le2^{\beta+2}.
\]

At `x=2`, use `f_2=2` on the prior atom and zero on its continuous component.
This is a normalized posterior-density version. Clamp every decoder output
to `A=clip(Y,0,2)` and use action `f_A`. The Bayes action on an original
observation is `f_X`; therefore this is a fixed measurable rule on original
and reconstructed observations, as required by Theorem 2.

Put `C=[5/4,7/4]` and `M=Pr(X in C)>0`. On the continuous part of the prior,
for `theta>=a`,

\[
 f_a(\theta)\ge c_1(\theta-a)^\beta,\qquad
 c_1=2^{-(\beta+1)}.
 \tag{26}
\]

Choose `0<h<=1/8` and

\[
 \lambda=\frac{c_1}{2}(h/2)^\beta
        =2^{-(2\beta+2)}h^\beta\le\frac14.
 \tag{27}
\]

If `x in C` and `a>=x+h`, take the parameter strip
`[x+h/2,x+3h/4]`. It lies in `[1,2)`, has prior mass `h/8`, and satisfies
`f_a=0` and `f_x>=2lambda`. The hinge Bregman integrand is then
`f_x-lambda>=lambda`. If `a<=x-h`, take the strip
`[x-h/2,x-h/4]`. It likewise has prior mass `h/8`, and now `f_x=0` and
`f_a>=2lambda`; the integrand is exactly `lambda`. These arguments include
the clamped actions `a=0` and `a=2`; for the latter, its continuous
posterior density is zero. Hence

\[
 \mathcal D_\lambda(f_x,f_a)\ge\lambda h/8
 \quad(x\in C,\ |x-a|\ge h).
 \tag{28}
\]

Lemma 1, applied to the ordinary observation coordinate rather than a fixed
Hilbert posterior metric, gives

\[
 \Pr\{X\in C,\ |X-A|\le h\}
       \le2(\beta+1)Dh.
\]

Set

\[
 h=\frac{M}{4(\beta+1)D}\le\frac1{8D},
\]

where the last inequality uses `M<=(beta+1)/2`. The bad event in (28) has
probability at least `M/2`. The bounded score therefore yields the explicit
bound

\[
 e_D\ge\frac{M\lambda h}{16(1+\lambda)}
       \ge\frac{M\lambda h}{20}
       =\frac{M}{20\,2^{2\beta+2}}
          \left(\frac{M}{4(\beta+1)D}\right)^{\beta+1}.
 \tag{29}
\]

No loss-range constant grows with `D`. The score may depend on `D` through
`lambda`; (5) is valid separately for every such fixed score. This is a
legitimate converse against all codes of the prescribed dimension.

### 9.3 Quadratic lower for `beta>1`

Use the binary prior on endpoints `theta=1,2` and restrict observations to
`[1/4,3/4]`. Both densities are positive there, and their likelihood ratio is

\[
 R(x)=2^{\beta+1}\left(\frac{1-x}{2-x}\right)^\beta,
 \qquad
 (\log R)'(x)=-\frac{\beta}{(1-x)(2-x)}\ne0.
\]

The scalar posterior weight has derivative bounded away from zero on that
fixed compact interval. Its Brier regret is quadratic, and its posterior
small-ball mass has order one. Corollary 3 gives `e_D>=c_beta D^{-2}`. This
also works for every `beta>0`, but is weaker than (29) when `beta<1`.

### 9.4 Constructive upper by reflection and triangular smoothing

Randomly sign the input, producing `Z=+X` or `-X` with equal probabilities.
On the circle `[-2,2]` of period four, the signed input has density

\[
 F_\theta(z)=\frac{\beta+1}{2\theta^{\beta+1}}
                  (\theta-|z|)_+^\beta.
 \tag{30}
\]

A uniformly shifted grid of `D` cells, encoding the containing cell and
decoding uniformly inside it, smooths this density by a triangular kernel
of width `4/D`. Output the absolute value of the decoded signed observation.
Random signing is fresh encoder randomness; the grid shift is independent
public randomness. The code uses exactly `D` labels at every seed.

For `0<beta<1`, uniformly over `theta in [1,2]`,

\[
 \|\Delta_h^2F_\theta\|_1\le C_\beta |h|^{\beta+1}.
 \tag{31}
\]

Here is a direct proof of its order. In strips of width `O(h)` around the
moving endpoints `+theta` and `-theta`, every relevant value is `O(h^beta)`,
so the integrated contribution is `O(h^{beta+1})`. Away from those strips
and the origin, Taylor's formula bounds the second difference by a local
average of `h^2 |F_theta''|`. Its integral is bounded by

\[
 C_\beta h^2\int_h^2 u^{\beta-2}\,du
       \le C_\beta h^{\beta+1}.
\]

The reflection cusp at zero is uniformly Lipschitz because `theta>=1`.
Its strip has width `O(h)`, giving contribution `O(h^2)`, which is smaller
than `h^{beta+1}`. At `theta=2`, the moving cusps meet the periodic seam;
the same endpoint-strip argument applies. All normalization factors are
bounded uniformly for `theta in [1,2]`.

For `beta=0`, the moving support jump gives second modulus `O(h)`. For
`beta=1`, the reflected density is piecewise linear with second derivative
a finite measure of uniformly bounded total variation, giving `O(h^2)`.
For `beta>1`, its ordinary second derivative is integrable away from zero
and the reflection derivative jump is a finite measure, again giving
`O(h^2)` uniformly. Thus the positive triangular smoothing upper is

\[
 e_D\le C_\beta D^{-\min(\beta+1,2)}.
 \tag{32}
\]

Taking absolute values is a Markov map and contracts TV, while the absolute
value of the original signed law is exactly `P_theta`. This proves the
original experiment's upper, including its fixed left boundary. Naively
zero-extending `p_theta` at `x=0` would introduce a jump and only prove an
`O(D^{-1})` upper; the reflection step removes that artifact.

The other worker's fixed-interval hat construction gives the same upper
without public grid shifts: its endpoint cells contribute `O(h^2)` at the
fixed boundary, while the moving endpoint strip contributes
`O(h^{beta+1})`. The reflected dither proof above is the independent upper
audited in this note.

### 9.5 Consequence for the general principle

For `0<beta<1`, ordinary density-Brier geometry has posterior squared
translation behavior of order `h^{min(2beta+1,2)}` (with a logarithm at
`beta=1/2`). Its converse can therefore be weaker than the sharp
`D^{-(beta+1)}` law. A bounded, scale-dependent hinge score captures the
boundary information that a fixed squared metric underweights.

Theorem 2 remains the appropriate general statement: optimize bounded
posterior regret at the desired resolution, then combine its localized
sublevel volume with a positive reconstruction upper. Theorem 4 is an exact
classification under its stated paired analytic conditions, rather than a
claim that every statistical experiment has a sharp rate given by one
preselected Hilbert metric.
