# Bounded pure-state quantum compression: primary prior-art audit

Audit date: 7 October 2026. Scope: a single unknown coherent state in a full fixed-radius ball of `C^m`, or the whole local pure iid qudit state with `m=d-1`. Initially the resource is an arbitrary hybrid algebra `⊕_j M_{d_j}`, with **total dimension `D=Σ_j d_j`**. The later refinement charges **`Q=max_j d_j` with unlimited free dephased classical labels**. Reconstruction is worst-case trace distance. No external quantum side information or entanglement assistance. The local center, basis, radius, copy count and error target are supplied; the unknown amplitude is acquired only from the quantum input.

**Verdict:** the proposed `D = Θ((log(1/ε)/log log(1/ε))^m)` is mathematically credible under this interface, but its upper construction, unrestricted dimension converse, and classical obstruction are established mechanisms. The complete Θ law is an elementary synthesis of primary results, not a cleared frontier novelty. The stronger unlimited-classical `Q` statement is also credible and admits a direct proof, but its Stinespring and Schmidt-number mechanisms are explicit prior art. At most the fixed-radius quantitative synthesis and exact finite-copy uniform formulation remain uncleared. I did not find a paper explicitly advertising this ε→0 formula; that absence is weaker than novelty. Direct finite-copy arguments give symmetric-space saturation without a LAN error floor.

## Decisive primary results

1. **Hayashi (2002), _Exponents of quantum fixed-length pure-state source coding_, PRA 66, 032321.** [Latest arXiv v6](https://arxiv.org/html/quant-ph/0202002v6), Section V, proof of Lemma 4, Eqs. (30)–(32) and the subsequent inequality. For a pure-state ensemble with average `ρ`, an arbitrary **visible** encoder into a `D`-dimensional system and arbitrary CPTP decoder has average squared fidelity at most `Σ_{i≤D} λ_i(ρ)`. The proof uses a Stinespring dilation and Nielsen–Kempe majorization for a separable state. This is stronger than a unitary-decoder rank argument and stronger than the older loose `F<6Σ_{i≤D}λ_i` bound. Blind codes are a subset of visible codes. [Leditzky–Datta (2016), Lemma 5.2](https://arxiv.org/html/1407.6616v5#S5), restates exactly this spectral bound. I checked the original proof, not only the restatement.

2. **Yang (2025), _Compression of quantum shallow-circuit states_, PRL 134, 010603.** [arXiv v3](https://arxiv.org/html/2404.11177v3), Appendix D.1, Lemma 8, Eqs. (72)–(75). It explicitly gives an amplitude-independent channel for bounded coherent-state compression, the trace-distance estimate `√(2 Poistail(|α|²,K))`, and the Chernoff estimate `(e|α|²/K)^K`. Its displayed lemma chooses cutoff proportional to the amplitude bound squared, because that paper studies growing amplitudes. Holding the amplitude bound fixed and optimizing the **already displayed** inequality gives `K=O(log(1/ε)/log log(1/ε))`. Thus the candidate upper is a different asymptotic reading of a known channel and bound. The text accidentally calls the cutoff dimension a number of qubits in its proof; its lemma and the Hilbert-space span make the intended dimension clear.

3. **Yang–Bai–Chiribella–Hayashi (2018), _Compression for quantum population coding_, IEEE TIT 64, 4766–4783.** [arXiv](https://arxiv.org/html/1701.03372), Theorem 1; Section III; Lemma 2, Eq. (28); Section V. Already treats blind, worst-case trace reconstruction, hybrid memory, displaced thermal states including coherent states (`β=0`), photon-number truncation, and the need for quantum memory in noncommuting iid models. Its global asymptotic statement is total `(f/2) log n` memory at leading order. Its finite-dimensional theorem assumes full rank and nondegenerate spectrum; do not invoke that theorem as a pure-boundary LAN theorem. Its optical part does include pure coherent states. Its global `log n` converse is not the sought local ε converse.

4. **Fuchs–Sasaki (2003), _Squeezing quantum information through a classical channel_.** [arXiv v3](https://arxiv.org/html/quant-ph/0302092v3), Section 4.1, Eqs. (71)–(73). For two equiprobable pure states with overlap amplitude `x`, optimal measure-and-prepare average squared fidelity is `(1+√(1-x²+x⁴))/2<1` whenever `0<x<1`. This directly supplies a quantitative positive trace reconstruction floor from a two-state subset. **Hammerer–Wolf–Polzik–Cirac (2005)** [coherent-state storage benchmark](https://arxiv.org/pdf/quant-ph/0409109), Eq. (2), gives the familiar tight average benchmark `(1+λ)/(2+λ)` for a Gaussian prior. That prior is unbounded; its numerical constant cannot simply be asserted for a bounded ball. The two-state result avoids that mismatch.

5. **Barnum–Hayden–Jozsa–Winter (2003), _On the reversible extraction of classical information from a quantum source_.** [arXiv v2](https://arxiv.org/html/quant-ph/0011072), Theorem 1; Lemma 3; Appendix B, Eqs. (30)–(36). Blind compression of an irreducible pure iid source cannot replace its Schumacher quantum rate by free classical storage. Crucially for the present one-shot argument, Eq. (35) is the same pairwise Stinespring residual identity used to transfer small pure-state disturbance to nearly common environment vectors. Its stated conclusion is an information-disturbance/entropy bound, not a bounded-ball ε rank law. [Hayden–Jozsa–Winter (2002)](https://arxiv.org/html/quant-ph/0204038) develops the visible asymptotic quantum/classical tradeoff; visible free classical labels trivialize the `Q`-only problem.

6. **Namiki (2016), _Schmidt-number benchmarks for continuous-variable quantum devices_, PRA 93, 052336.** [arXiv v2](https://arxiv.org/html/1511.03321v2), Eqs. (3), (9), (18), (20), (21). Explicitly studies coherent storage against arbitrary `k`-partially-entanglement-breaking channels, equivalently a Kraus representation with rank at most k. Eq. (9) relaxes the output to all Schmidt-rank-k states; Eq. (18) gives a rigorous matrix optimization. Eq. (21) exhibits continuous-outcome rank-k instruments. This is the exact broad quantum-dimension/free-classical mechanism now used here. Its prior is unbounded Gaussian, its error is average fidelity, and the simplified finite-submatrix optimum Eq. (20) is a conjecture in general. Do not treat that conjecture as a rigorous bounded-ball converse.

## Technical attempt: the claimed scale follows from the known converse

Write `T(ρ,σ)=||ρ-σ||_1/2` and `L=log(1/ε)`. Fix an integer `m≥1` and `R>0`; constants below may depend on both. Define coherent vectors by

`|z> = exp(-||z||²/2) Σ_{k∈N^m} z^k/√(k!) |k>`, `||z||≤R`.

**Upper.** Project onto total occupation `|k|≤K`, retain that vector in a `binom(K+m,m)`-dimensional memory, and replace the discarded probability by the vacuum. This is a CPTP compression map, not normalized postselection. Decoding is the inclusion of the retained space. If `p` is the retained probability then reconstruction squared fidelity is at least `p²`, hence trace error is at most `√(2(1-p))`. Total occupation is Poisson with mean `||z||²≤R²`, so

`1-p ≤ (eR²/(K+1))^(K+1)` for `K+1>R²`.

Choosing `K=O(L/log L)` therefore gives worst-case trace error at most ε and `D=O((L/log L)^m)`. All retained input-dependent registers are inside this dimension; no classical estimate is retained.

**Lower, with a finite ensemble to avoid any infinite-dimensional extension assumption.** Put `r=R/√m`. For any positive integer `K`, take the product grid

`z_j = r exp(2πi a_j/(K+1))`, `a_j∈{0,…,K}`, independently and uniformly.

Every input lies on the radius-R sphere. Set `Q=K+1` and `M=Q^m`. Averaging phases splits Fock space into mutually orthogonal residue classes modulo Q. The average state has exactly M nonzero eigenvalues

`w_a = exp(-R²) Σ_{k≡a (mod Q)} r^(2|k|)/k!`, `a∈{0,…,K}^m`.

Each is at least the term indexed by `k=a`, and therefore

`w_a ≥ p_min := exp(-R²) min{1,r²}^(mK)/(K!)^m`.

The finite grid's input vectors span an M-dimensional space. One may project the decoder output back into that span, replacing outside mass by a fixed vector; this cannot reduce fidelity to any input. Hayashi's finite-dimensional spectral converse now applies verbatim, even if the encoder is given the exact grid label. If the total memory dimension is `D<M`,

`average F ≤ Σ_{i≤D}λ_i ≤ 1-(M-D)p_min`.

Worst-case trace error ≤ε implies `F≥1-ε` on every input, by testing the input projector. Thus

`ε ≥ (M-D) exp(-R²) min{1,r²}^(mK)/(K!)^m`.  (**)

Choose `K=ceil((2D)^(1/m))-1`, so `M≥2D` and `K=Θ(D^(1/m))`. Taking logarithms in (**) gives

`L ≤ C_{m,R}(1+D^(1/m) log(D+1))`.

Consequently `D=Ω((L/log L)^m)` as ε→0. This lower allows arbitrary CPTP decoding, arbitrary visible encoding, and arbitrary hybrid block allocations, because `⊕_j M_{d_j}` embeds in an ordinary Hilbert space of dimension `Σ_j d_j`. A bound that only uses the largest quantum block while ignoring the classical label would be a different interface.

This is an internally derived corollary of an established theorem. The derivation identifies why the **unrestricted** Θ converse is no longer a missing new lemma. It is a novelty falsification attempt, not a claim to have discovered a new coding theorem.

## Direct finite-copy law, including extremely small ε

For `z∈C^m`, `||z||≤R`, consider

`|ψ_{n,z}> = (|0>+Σ_{j=1}^m z_j|j>/√n)/√(1+||z||²/n)` and the whole input `|ψ_{n,z}>^⊗n`.

Its exact symmetric occupation amplitudes have squared values

`p_{n,k}(z) = (n)_{|k|}/n^{|k|} · ∏ |z_j|^(2k_j)/k_j! · (1+||z||²/n)^(-n)`, `|k|≤n`.

Here `(n)_s=n(n-1)…(n-s+1)`. Total excitation is `Bin(n,||z||²/(n+||z||²))`, of mean at most R². A Chernoff bound gives the same cutoff upper as above, while retaining all `|k|≤n` gives exact compression of dimension `binom(n+m,m)`. Therefore

`D_n(ε) ≤ C_{m,R} [1+min{n,L/log L}]^m`.

For the lower, use the same finite phase grid with `|z_j|=r`. Its average eigenvalues are sums of `p_{n,k}` over occupation residue classes. If `mK≤n/2`, then `(n)_s/n^s≥2^{-s}` for `s≤mK`, and `(1+R²/n)^(-n)≥exp(-R²)`. Each of the M grid eigenvalues is therefore at least

`exp(-R²) min{1,r²/2}^(mK)/(K!)^m`.

The previous spectral argument applies. Either `K=ceil((2D)^(1/m))-1` fits below `n/(2m)` and forces `D≥c(L/log L)^m`, or that cutoff does not fit and already forces `D≥c n^m`. Up to fixed constants and the harmless +1 needed for small n, this proves the internally derived uniform law

`D_n(ε) = Θ_{m,R}([1+min{n,L/log L}]^m)` for sufficiently small ε.

There is **no additive LAN remainder** in this argument. A formulation asserting the unsaturated `(L/log L)^m` law for every finite n and arbitrarily small ε is false: exact symmetric-space compression caps D. This saturation proof is an elementary use of the same known spectral converse; the search did not clear priority for this particular concise formulation.

## Stronger quantum-branch law with unlimited classical outcomes

An independent internal derivation is recorded in `work/deep/pure_quantum_lower.md`. I read both load-bearing lemmas and checked their link to prior art. Here `Q` is the largest retained coherent quantum branch. Classical outcomes are fully dephased, may be continuous, and are not charged. Coherence across labels must be included in Q. Independent public randomness is allowed; preshared entanglement and a visible parameter oracle are excluded.

Hayashi's visible converse does **not** establish this statement: its memory dimension includes all labels. Instead choose a small product phase torus inside the ball, with `S=Σ|z_j|²≤1/4`. All pairwise input overlaps then have magnitude at least a constant `c>0`, uniformly in n. For a general channel with average pure-state infidelity `ē`, the Stinespring identity gives

`F_e(ρ,Λ) ≥ 1-(2√ē+ē)/c`,

where ρ is the phase-averaged input state. The averaging step avoids a factor depending on the number of ensemble states. In the notation of Barnum et al., take unnormalized `e_i=√(1-e_i^err) β_i` in their explicit Eq. (35), bound the three residual terms, and integrate twice. Thus this is a clean weighted/continuous corollary of an established identity, not a cleared new information-disturbance mechanism.

Every Q-dimensional instrument branch has Schmidt number at most Q relative to an untouched reference; decoding and mixing classical outcomes preserve that property. The standard pure-target fidelity witness consequently gives

`F_e(ρ,Λ) ≤ Σ_{i≤Q} λ_i(ρ)`.

The known k-PEB/Schmidt framework covers exactly this interface, including Namiki's coherent-memory benchmarks. Here the Haar phase average has independent Poisson occupation eigenvalues in the coherent limit and the exact multinomial occupation eigenvalues `p_{n,k}` above at finite n. For `|k|≤K≤n`, `(n)_{|k|}/n^{|k|}≥exp(-|k|)` supplies an explicit eigenvalue lower bound `exp(-S)(r²/e)^K/K!`. There are `binom(K+m,m)` such occupations. With `ē≤ε` and `K≈c' min{n,L/log L}`, omitting any one of them contradicts the spectral tail inequality, for any fixed `c'<1/2` and sufficiently small ε. The same quantum-only cutoff attains the upper. Therefore the checked internal proof yields

`Q_n(ε)=Θ_{m,R}([1+min{n,L/log L}]^m)`

even with unlimited uncharged classical outcomes. The coherent full-ball specialization gives `Q(ε)=Θ((L/log L)^m)`.

This strengthening is useful and prevents a free-classical loophole in a total-D result. It should be described as an explicit local precision/saturation theorem using known nonorthogonal decoupling and Schmidt-number ideas. Neither the free-classical interface, the qualitative irreducibility obstruction, nor the Schmidt converse is new. The search did not find the exact bounded-family formula, but that does not establish high-impact novelty. A rigorous reduction from Namiki's Gaussian-prior Eq. (18) to this bounded-ball order might further demote even the formula to a direct published corollary. Such a reduction was **not** completed here; relying on its conjectural Eq. (20) would be invalid.

## Established surrounding work and interface distinctions

| Primary work | What is already supplied | Why it does not independently state the candidate local precision law |
|---|---|---|
| [Plesch–Bužek, _Efficient compression of quantum information_ (2010)](https://arxiv.org/html/0907.1764v2) | Exact symmetric qubit compression into `ceil(log_2(n+1))` qubits; explicit quadratic gate count. | Global pure qubit family and zero error. The local law above uses low-excitation truncation; its finite-n cap is precisely the same symmetric-space mechanism. |
| [Butucea–Guţă–Nussbaum (2018)](https://arxiv.org/html/1705.03445v2), Theorem 4.1 and Section 7 | Strong local equivalence of pure iid states to coherent Fock states; the occupation-basis isometry is explicitly `|(n-|k|),k>→|k>`. | Establishes the pure-state bridge, even in infinite dimension. Neither the bridge nor the symmetric-to-Fock map is novel here. Exact finite-n expansion is preferable for arbitrarily tiny ε. |
| [da Silva–Guha–Dutton (2013), laser-pulse discrimination](https://arxiv.org/html/1208.5758v2) | Coherent compression of a **known finite alphabet**, with a small register retaining the relevant quantum information, followed by an arbitrary optimized measurement. | A K-letter coherent alphabet spans at most K dimensions and can be encoded exactly in that many dimensions. A blanket lower for every bounded coherent family is therefore false. |
| [Romero–Olson–Aspuru-Guzik (2017), quantum autoencoders](https://arxiv.org/html/1612.02806v2) | Trained unitary compression for a specified pure ensemble, with an average reconstruction/trash objective. | Numerical training examples do not certify a worst-case continuum guarantee or an unrestricted dimension converse. |
| [Ma et al., autoencoder compression rates](https://arxiv.org/html/2005.11149v3), Theorem 5 / Corollary 6 | Optimal pure-reference trash fidelity is the sum of the leading latent-dimension eigenvalues. | Restricted autoencoder objective. The older Hayashi result is the stronger decoder-independent converse needed here. |
| [Hayashi–Tan (2018), approximate sufficient statistics](https://arxiv.org/abs/1612.02542) | Classical parametric distribution compression with leading `(f/2)log n` memory. | Reconstructs a classical experiment/distribution; it does not turn a single unknown coherent state into its supplied parameter or eliminate the EB obstruction. |
| [Kato, _Exact and local compression of quantum bipartite states_](https://arxiv.org/html/2309.07434v2) | Exact compression characterized through quantum sufficiency / Koashi–Imoto structure. | Exact correlation preservation, not this finite-ε pure-family law. |
| [Datta–Renes–Renner–Wilde, one-shot lossy compression](https://arxiv.org/abs/1304.2336) | Smooth-information bounds for entanglement-assisted rate distortion. | Entanglement assistance and distortion observables change the interface. Do not import its costs as an unassisted family-reconstruction converse. |
| [Cope–Uola, _Quantifying the high-dimensionality of quantum devices_ (2022/2023)](https://arxiv.org/html/2207.05722v4) | Channel/measurement compression dimension tied to maximum Kraus rank and unlimited classical storage. | Establishes the broad operational dimension concept; does not state the coherent local precision tail law. |
| [Bluhm–Rauber–Wolf (2018), compression relative to measurements](https://arxiv.org/html/1708.04898), Theorem 5.1 | Unlimited-classical exact compression dimension is stable for sufficiently small errors in finite dimension. | Its guarantee preserves specified effects on all input states. The present family guarantee is restricted to near-vacuum inputs; no quantitative uniform ε,n law follows from the quoted stability statement. |
| [Yang–Chiribella–Hayashi, _Quantum Stopwatch_](https://arxiv.org/html/1703.05876v3), Supplementary Notes 1–2 | Frequency projection and trace-error bounds for pure and mixed spin states, using retained Schur labels. | Global phase family, frequency width growing with n, and asymptotic error estimates. This is close methodological prior art for the mixed-boundary extension, not the exact local joint law. |

The full-ball lower requires genuine amplitude variation: a full positive-radius ball, or at least a contained product phase torus, suffices. Boundedness alone does not. A **mean energy bound on arbitrary states** also does not imply the superexponential Poisson tail; the pure coherent structure is essential. Dimension D and qubit count `ceil(log_2 D)` must remain distinct.

## Classical floor and the visible/blind boundary

For the coherent pair `|0>,|t>` with `0<t≤R`, overlap `x=exp(-t²/2)`. Fuchs–Sasaki gives

`sup F_avg(EB) = [1+√(1-exp(-t²)+exp(-2t²))]/2`.

Thus worst-case trace error of any classical measure-and-prepare protocol is at least

`[1-√(1-exp(-t²)+exp(-2t²))]/2 > 0`,

independently of its number of classical outcomes. For the local finite-copy pair `z=0` and `z=(t,0,…,0)`, substitute `x_n=(1+t²/n)^(-n/2)`. These overlaps stay in a compact subinterval of `(0,1)` for fixed t, so there is a positive floor uniform in n.

This statement is about **blind** classical compression of the quantum input. A visible encoder supplied with z can quantize that label increasingly finely and prepare increasingly accurate states; it has no positive classical floor as memory grows. The use of a visible encoder in the dimension lower is only a stronger converse relaxation and does not convert the classical obstruction into a visible one.

## Ranking and strongest remaining questions

1. **Demote the bare pure Θ law as a frontier leader.** Total D follows from a 2002 converse plus standard tails. The unlimited-classical Q refinement is more substantive, but its two load-bearing mechanisms are explicit 2003/2016 prior art; at most the concise fixed-radius precision formula and uniform finite-n synthesis remain possible incremental novelty. Cite these components and do not present a new general converse mechanism.
2. **Potential genuine next target: bounded displaced thermal families at fixed `0<β<1`.** The old population-coding paper supplies a growing-n protocol and a classical obstruction, but the pure-ensemble spectral argument does not directly establish a sharp fixed-radius ε law for mixed inputs. A geometric photon-tail upper alone is not a matching lower. First fatal test: can a decoder prepare the known thermal background and use a substantially smaller memory to retain only its displacement information? A proof must cover arbitrary channels, not only photon truncation or energy-conserving decoders. Expected value: moderate, substantially better than re-proving the pure Θ statement; novelty still needs a focused search.
3. **Smaller, clean next target: the exact trace-error asymptotic constant.** The present upper needs tail `O(ε²)` whereas the spectral lower only forces an infidelity tail `O(ε)`. They match Θ dimension but leave a factor in the leading `-log e_D` exponent. Determine whether arbitrary nonisometric decoders can improve that constant over subspace truncation. Do not call a Θ proof “sharp” in this stronger sense. Expected value: technically tractable but likely incremental.

An outward worker also proposed the exact finite-n near-pure mixed qubit family with small eigenvalue `λ/n`, `λ∈[0,Λ]`, and bounded `z/√n` rotations. Its claimed uniform factorial-moment upper works at `ε≪1/n`; the pure endpoint supplies the Q lower. That **mixed-boundary finite-error upper** is a more credible new component than the pure law. Existing population coding, global qubit compression, and frequency projection are the necessary primary comparators. I did not find an exact stated joint ε,n local-boundary result in this pass, but did not independently complete a novelty search or proof audit of the worker's proposed mixed theorem; it remains provisional.

Primary search included the original converse proof, coherent cutoff proof, binary EB proof, pure LAN occupation construction, optical finite-alphabet compression, exact sufficiency, and autoencoder bounds. No finite numerical test or agent agreement is used as theorem or novelty evidence.

## Reproducible source handles

Eleven key primary HTML files are saved under `work/deep/pure_quantum_prior_art/`, with URL, access date, byte counts and SHA-256 in `manifest.json` and `hybrid_q_manifest.json`:

- `hayashi_2002_v6.html`: Section V, proof of Lemma 4, Eqs. (30)–(32).
- `leditzky_datta_2016_v5.html`: Section 5, Lemma 5.2.
- `yang_shallow_2025_v3.html`: Appendix D.1, Lemma 8, Eqs. (72)–(75).
- `fuchs_sasaki_2003_v3.html`: Section 4.1, Eqs. (71)–(73).
- `butucea_guta_nussbaum_2018_v2.html`: Theorem 4.1; Section 7, occupation isometry.
- `yang_population_2018.html`: Theorem 1; Section III; Lemma 2; Section V.
- `barnum_hayden_jozsa_winter_2003.html`: Theorem 1; Lemma 3; Appendix B, Eqs. (30)–(36).
- `namiki_2016_v2.html`: Eqs. (3), (9), (18), (20), (21).
- `cope_uola_2022_v4.html`: operational Kraus-rank compression dimension.
- `bluhm_rauber_wolf_2018.html`: Theorem 5.1 and finite-classical-label reduction.
- `yang_stopwatch_2019_v3.html`: Supplementary Notes 1–2, frequency-projection error.

Source archive integrity is a provenance check, not proof validation. The earlier memory note was used only to preserve the provisional status of prior local Gaussian work (`MEMORY.md`, lines 44–48 and 81–88); all decisive prior-art facts above were refreshed from primary sources this turn. No source snapshot or other agent's report was edited.
