# Independent hostile audit of the approximate-permutation rank bridge

Audit date: 2026-10-07. Scope: the load-bearing trace/rank, fixed-prime reduction, Cartesian factorization, interpolation and defect budget only. Incidence acquisition, link geometry, nontriviality of the rectangle words, novelty, and the full group theorem are outside this audit.

**Finding: no fatal flaw found in this rank bridge.** I reconstructed the universal inequality directly from its hypotheses, rather than treating earlier audit reports or agreement as evidence. At the exact stated finite interface it gives

    Delta <= r^2 (S_inc delta + N lambda/8),

where delta bounds each triangle's normalized Hamming defect and lambda bounds each nondegenerate rectangle's fixed-point fraction. The error tolerance is uniform in the permutation degree D, including q dividing D. This finding certifies neither the inputs supplied by the geometric construction nor the existence/novelty of the resulting group.

## Sources actually read

- `work/astra-research-knowledge/00_START_HERE.txt`, `01_CORE.txt`, `AGENTS.md`, and `cards/N06-nonsofic-hyperbolic.txt`.
- Full supplied text of `web/pages/d-5f4f3b352980d250.html`, especially its rank argument and finite-set conversion. The extracted Markdown in `work/scouts/groups_sources/d-5f4f3b352980d250.md` was checked byte-for-byte against the HTML's decoded `<pre>` contents.
- Full supplied text of `web/pages/d-62bae00c7f29762c.html`, with the same byte check against `work/scouts/groups_sources/d-62bae00c7f29762c.md`; quantitative proof at Markdown lines 31-81.
- All local `work/scouts/groups_sources/construction.tex`, especially the original rank-reduction lemma, exact Cartesian factorization, and line/tensor certificate. Its SHA256 is `9ddffe7f11b0b0133f03cf60dd93947b8d47b911f3f0930c8e55512cba8d930e`, matching the value recorded in the supplied report. This match establishes provenance/integrity, not mathematical correctness.
- Live primary-source verification of [Arzhantseva-Paunescu, Definition 2.2](https://arxiv.org/html/1410.2626v2#S2): the cited definition uses direct separation from the identity, exactly as needed for the factor-eight conversion.

No source check script was imported, no Lean kernel was replayed, and no prior audit verdict was used as a premise. No relevant memory-registry entry was found.

## 1. Exact finite interface

Fix r >= 2, a prime q > r, N labels, a finite point set P of size m, exceptional E, incidence sets I(z), and two Cartesian blocks partitioning each regular I(z). For block b, the map i -> (alpha_b(i), beta_b(i)) is a bijection onto Z/s_b x Z/t_b. The rank factorization only needs this bijection; s_b,t_b >= r is a geometric/wiring condition, not needed for the sum factorization itself.

Assume scalar matrices H(z) over F_q have rank at most one and obey, separately for every i,

    sum_{z : i in I(z)} H(z) = -E_ii.

Assign arbitrary permutations X_iuv, L_buj, R_bvk of the SAME D-point set, D > 0. No exact representation is assumed. For every triangle require

    d_H(X_iuv, L_b,u,alpha(i)+v^(-1) R_b,v,beta(i)+u) <= delta.

For every u != u' and v != v', require at most lambda D fixed points for

    X_iuv X_iu'v^(-1) X_iu'v' X_iuv'^(-1).

Set S_inc = sum_{z not in E} |I(z)| and Delta = Nr/4 - 2m - r|E|. All finite data, including q and r, are fixed before D is chosen.

## 2. Trace moments: no hidden exact-action assumption

Let P(X) be the ordinary integer permutation matrix with column-vector convention. Its transpose is its inverse and P(XY) = P(X)P(Y). Put Y_i = (P(X_iuv))_(u,v), of size rD x rD, and T_i = Y_i Y_i^T.

The first moment is exactly tr(T_i) = r^2 D. The (u,u') block of T_i is sum_v P(X_iuv)P(X_iu'v)^T. Consequently the second moment is EXACTLY

    tr(T_i^2) = sum_{u,u',v,v'}
      tr(P(X_iuv X_iu'v^(-1) X_iu'v' X_iuv'^(-1))).

This identity applies to arbitrary assigned permutations. When u = u' or v = v', the product is the identity by literal cancellation; their union has 2r^3-r^2 terms. Every remaining trace counts fixed points of the stated rectangle, so

    tr(T_i^2) <= [2r^3-r^2 + r^2(r-1)^2 lambda] D.

T_i is a real positive semidefinite matrix. Cauchy-Schwarz on its nonzero eigenvalues gives rank_R(Y_i) >= tr(T_i)^2/tr(T_i^2), hence

    rank_R(Y_i) >= r^2 D / [2r-1+(r-1)^2 lambda].

Attempts to find a missing sign, reversed rectangle order, degeneracy term, D factor, or dependence on a homomorphism failed. In particular the trace is taken over R, where D stays a positive number, rather than over F_q where q could divide it.

## 3. Reduction modulo q: the minor argument is valid

Let d = rank_R(Y_i). A nonzero d x d integer minor B exists. Each row of Y_i has exactly r ones in disjoint column blocks, so every row of B has norm at most sqrt(r). Hadamard yields 1 <= |det B| <= r^(d/2).

Let d' = rank_Fq(B). Choose a subset of d' original rows that spans the reduced row space. For each remaining row, subtract an integer lift of its F_q linear combination of those selected rows. These operations preserve the determinant, do not change the selected rows, and make d-d' rows entrywise divisible by q. Therefore

    q^(d-d') divides det B, and q^(d-d') <= r^(d/2).

Since q > r, d' >= d/2. Finally rank_Fq(Y_i) >= d'. This proves

    rank_Fq(Y_i) >= D alpha(lambda),
    alpha(lambda) = r^2 / [2(2r-1+(r-1)^2 lambda)].

There is no division by D, no use of a modular trace to estimate rank, and no requirement q not dividing D. The row operations need not preserve the original norm bound: Hadamard was applied to the original minor BEFORE those operations. The proof also gives the stronger factor 1 - log(r)/(2 log(q)); the half-rank bound is deliberately conservative.

## 4. Each approximate triangle costs only its moved columns

For two permutations p,p', P(p)-P(p') is zero on every column j where p(j)=p'(j). Its rank over ANY field is at most the number of differing columns, namely D d_H(p,p'). This is an integer support estimate; small Hilbert-Schmidt distance for arbitrary unitaries would not imply it.

For each triangle, the integer matrix difference

    P(X_iuv) - P(L_b,u,alpha(i)+v)^(-1) P(R_b,v,beta(i)+u)

thus has F_q rank at most delta D. Embedding that difference in its (u,v) block of an rD x rD zero matrix preserves its rank. Summing all r^2|I_b| embedded errors costs at most r^2|I_b| delta D by rank subadditivity. Different triangles may have entirely different error supports; the bound does not assume a common good subset of points and does not secretly repair the action.

The modeled block sum factors as a block column C_b times a block row A_b:

    (C_b)_u = sum_j P(L_buj)^(-1),
    (A_b)_v = sum_k P(R_bvk).

For fixed u,v, i runs through every (alpha,beta) pair once. The shifts alpha+v and beta+u are bijections of the two cyclic coordinates. Consequently the (u,v) modeled sum is (sum_j P(L_buj)^(-1))(sum_k P(R_bvk)), with the original factor order unchanged. The full matrix has inner dimension D and rank at most D; the two regular blocks cost at most 2D.

Writing Z(z) = sum_{i in I(z)} Y_i gives

    rank_Fq Z(z) <= 2D + r^2 |I(z)| delta D    (z not in E),
    rank_Fq Z(z) <= rD                        (z in E).

No commutativity of the permutations/matrices was used. For exceptional points all remaining incidences are retained and the ambient-rank bound applies. Counting 2m+r|E| rather than the sharper 2m+(r-2)|E| is conservative.

## 5. Interpolation stays exact when the permutations have errors

The original construction uses N distinct marked points a_i in S^h and the product Lagrange polynomials f_i, which equal one at a_i and zero at every other retained mark. Their total degree is at most h(|S|-1), and H(z)=f(z)f(z)^T has rank at most one with H(a_i)=E_ii.

On any affine line, each entry has degree at most 2h(|S|-1). The strict requirement is

    2h(|S|-1) < q-1.

For the source's h=20 and |S|=floor(q/100), this holds for its large q. Replacing h by 5 also satisfies this degree test, but that observation says nothing about the modified incidence acquisition. For degree k < q-1 the finite-field line sum is zero: the constant contribution is q=0 in F_q, while sum_t t^k=0 for 1 <= k < q-1. Hence puncturing only the label's OWN mark gives

    sum_{z in ell_i minus {a_i}} H(z) = -E_ii.

Other marks on that line remain in the sum. Deleting other labels does not alter this identity for a surviving label. Prematurely puncturing all marked points, or using degree q-1, would invalidate this step; neither modification is present in the supplied proof.

The tensor identity is then a distributive identity for arbitrary matrices Y_i:

    sum_z H(z) tensor Z(z)
      = sum_i [sum_{z : i in I(z)} H(z)] tensor Y_i
      = - directsum_i Y_i.

No group equation, approximate relation, or positivity of H(z) is needed here. Tensor rank over a field is multiplicative, so each summand's rank is at most rank(Z(z)).

## 6. Defect accounting with separate errors

Taking ranks in the tensor identity and using the foregoing lower and upper bounds yields, as an inequality between ordinary nonnegative real numbers,

    N D alpha(lambda)
      <= [2m+r|E|]D + r^2 S_inc delta D.

Cancel D > 0 in this numerical inequality; this cancellation is not an operation inside F_q. To linearize the lower bound, write a=2r-1 and b=(r-1)^2. Then

    alpha(0) = r^2/(2a) >= r/4,
    alpha(0)-alpha(lambda)
      = r^2 b lambda/[2a(a+b lambda)]
      <= r^2 lambda/8,

because 4(r-1)^2 <= (2r-1)^2. Therefore the claimed inequality follows exactly:

    Delta <= r^2 (S_inc delta + N lambda/8).

If delta=lambda=epsilon and Delta>0, choosing

    epsilon <= min(1/2, Delta/[2r^2(S_inc+N/8)])

would force Delta <= Delta/2, a contradiction. The minimum with 1/2 is harmless; it also makes the intended defect interpretation immediate.

For the original explicitly budgeted data, N <= cm, S_inc <= N(q-1), cr=100, and Delta >= 15m/4 imply that delta,lambda <= 1/(100rq) are impossible: their right side is strictly at most cmr/100 = m, while the left side is at least 15m/4. These checks depend on the stated incidence bounds and do not verify them here.

## 7. The finite-set sofic transfer does not lose an unbounded word factor

Use normalized bi-invariant Hamming distance. Given a finite-set almost-homomorphism phi with multiplication error eta, include identity, all edges and required inverse elements, and every rectangle prefix. If identity is not normalized exactly, multiplicativity on 1*1 gives d_H(phi(1),id) < eta by invariance. Multiplicativity on g*g^(-1)=1 then gives d_H(phi(g^(-1)),phi(g)^(-1)) < 2eta.

The relation L X=R directly yields triangle defect < eta after left multiplication by phi(L)^(-1). For a rectangle, replacing two inverse images costs < 4eta, and three prefix multiplications cost < 3eta. Its evaluation is within 7eta of phi(w). The cited [Definition 2.2](https://arxiv.org/html/1410.2626v2#S2), independently opened during this audit, supplies d_H(phi(w),id)>1-eta for nonidentity w. Therefore the evaluated rectangle has fixed-point fraction < 8eta, and eta smaller than the fixed epsilon threshold divided by eight suffices for the obstruction.

For a hypothetical substitution of pairwise separation d_H(phi(g),phi(h))>1-eta without exact identity normalization, the same elementary bookkeeping would give a conservative 9eta bound. This does NOT identify an error in the supplied argument: its actual cited definition has direct nonidentity-vs-id separation, and factor eight is correct. Even that alternative convention would be accommodated merely by decreasing eta.

This part depends critically on every listed rectangle being nonidentity in the actual group. That is a geometric input, not proved by the rank argument. Merely having a non-residually-finite group, or exact finite quotients failing, would not supply the conclusion. The robust inequality does.

## 8. Independent finite falsification checks

I wrote and executed `work/deep/nonsofic_rank_checks.py` from scratch using exact Fraction elimination and modular elimination, with results saved in `work/deep/nonsofic_rank_checks.json`. It verifies the decoded HTML/Markdown equality before the mathematics and imports no earlier audit script. It passed:

- 2,084 arrays: all r=2,D=2 arrays, all r=2,D=3 arrays, all r=3,D=2 arrays, and seeded samples at (r,D)=(3,3),(3,5),(4,5).
- 3,460 modular-rank checks, including q=D=3 with r=2, and q=D=5 with r=3 or 4. The checks expand permutation words independently of the matrix second moment, compare exact rational ranks, and check the prime-field lower bound.
- 144 independently built Cartesian blocks, with cyclic shifts, noncommuting permutations, zero errors and independently changed triangle permutations. The script checks the stronger exact error-support sum rather than only a maximum-defect bound.
- 126 punctured-line interpolation identities and 24 full tensor identities on arbitrary random matrices at (q,h,|S|)=(7,2,2) and (11,2,3).
- 25 rational alpha inequalities, including r=10^42, and two explicit negative controls: degree q-1 has nonzero line sum; 3I_2 loses all rank mod 3 when the row-budget/prime condition is omitted.

These fixtures test conventions and catch transcription errors. They do not certify the universal claim by enumeration; the reconstruction in sections 1-7 is the mathematical argument. In particular, no finite fixture acquired incidence data with the positive global rank gap or verified a group rectangle's geometric nontriviality.

## Decision and remaining load-bearing inputs

Retain the approximate-permutation rank bridge at its exact finite interface. I found no missing D dependence, no invalid modular cancellation, no overlooked r^2 incidence factor, no wrong moment orientation, and no loss of exactness in the interpolation identity. The separate-error form stated in N06 is correct.

The whole group claim still rests on the existence of the finite incidence/wiring data with Delta>0 and on the nonidentity of every rectangle. The final group claim must be assessed using those audits, not upgraded from this scoped pass. This audit makes no novelty, external-review, practical-acquisition, unitary, linear-sofic, property-(T), or direct-finiteness claim.
