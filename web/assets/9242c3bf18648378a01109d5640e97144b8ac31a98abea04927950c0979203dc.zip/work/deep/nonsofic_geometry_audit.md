# Independent hostile audit of the nonsofic triangle-complex template

Date: 7 October 2026. Auditor: `nonsofic_geometry_audit`. Scope: the local N06 claim, sources `d-29830c52d5b677da` and `d-5f4f3b352980d250`, and the actual `construction.tex`. Prior audit verdicts were treated as claims to reconstruct, not as supporting lemmas. This is an ordinary mathematical audit; no formal kernel or enormous incidence table was executed.

## Verdict

**No fatal flaw found in the base template.** I reconstructed the incidence alteration, cell attachments, link immersions, same-label link-distance argument, CAT(-1) replacement, robust rank inequality, and finite-set sofic reduction. At the explicit input contract below these steps fit together without a missing stability hypothesis, characteristic restriction on the permutation degree, or limit interchange.

The logical conclusion at that contract is a torsion-free nonsofic word-hyperbolic group with a finite two-dimensional classifying complex. The source's random marked-line construction meets the contract by its stated asymptotic argument; I independently rederived that argument. Its displayed explicit parameters also pass the arithmetic and prime checks described below. **No presentation or incidence table at those astronomical parameters has been emitted, and no external review, formal replay, or priority certification is established by this audit.**

The h=5 LUW transfer is a different input-construction claim. The findings here certify the reusable triangle/interpolation template, not the correctness of that new affine embedding or its incidence counts.

## Exact input contract

Fix all of the following before choosing any permutation dimension D:

1. An integer r >= 2 and a prime q > r.
2. A finite point set P of cardinality m; a finite label set I of cardinality N; incidence sets I(z) for z in P; an exceptional set E.
3. A **simple** bipartite incidence graph on P disjoint union I with girth at least 14. An incidence must be represented by one graph edge, not a multiplicity.
4. At every z outside E, a disjoint partition of I(z) into two blocks I_b, separately indexed at different points, together with a bijection

   i -> (alpha_b(i), beta_b(i)) in Z/s_b x Z/t_b, where s_b,t_b >= r.

5. Scalar matrices H(z) in M_N(F_q), of rank at most one, obeying the **exact** identities

   sum over z with i in I(z) of H(z) = -E_ii for every i in I.

6. The positive numerical gap

   Delta = Nr/4 - 2m - r|E| > 0.

Write S_reg = sum over z outside E of |I(z)|. It is enough that S_reg is finite for an error threshold to exist. S_reg <= N(q-1) is an additional marked-affine-line fact used in the source's explicit threshold.

The geometry uses items 3-4. The robust permutation obstruction uses items 1, 4-6. The contract also forces a nonempty regular set: substitute scalar Y_i=1 into the certificate to obtain -I_N=sum_z |I(z)|H(z), hence N<=m. If E=P, then Delta<=rm/4-2m-rm<0, contrary to item 6. This separates the conditions a new incidence design must prove: girth alone, or an average-degree claim alone, does not suffice.

## Cell attachments and compatible geometry

Use the three **distinct** vertices O,V,W and the following distinct oriented edges:

- x_iuv : V -> W, i in I, u,v in {0,...,r-1};
- L_buj : O -> V, j in Z/s_b;
- R_bvk : O -> W, k in Z/t_b.

Attach, for each b, i in I_b and u,v, a triangle with oriented boundary

L_(b,u,alpha_b(i)+v) x_iuv R_(b,v,beta_b(i)+u)^(-1).

Each boundary is an embedded three-edge circuit: its three vertices and its three side types are distinct. In particular, no triangle identifies two of its own vertices or sides. Each index denotes a single edge; indexing b separately at different points is essential to this assertion and to the links below. A nonempty regular set supplies L and R edges, so the complex is connected. For the source's data E=o(m), and for the explicit data |E| <= m/(2r), the regular set is nonempty.

Give every triangle the same hyperbolic shape, with angles

O: 27pi/50; V: 9pi/50; W: 9pi/50.

All angles are positive and their sum is 9pi/10 < pi, so that hyperbolic triangle exists. Equal V and W angles give equal L and R lengths; all x edges receive the common third side length. Consequently every full-side identification is isometric. Unused x edges receive the same x length. There is no source requirement to keep the original Euclidean lengths when changing the metric; the topological complex and fundamental group are retained.

If the chosen definition of a polyhedral complex requires intersections to be individual faces, take a compatible geodesic barycentric subdivision. The original finite regular cell complex has embedded closed cells, and the subdivision uses cells as distinct barycentric vertices, so parallel original edges do not become the same edge. Links at original vertices retain their angular metric; a new face-interior vertex has link length 2pi, and an edge-interior vertex has two tangent directions joined by one pi-path per incident face. Thus the extra vertices satisfy the non-strict 2pi link condition. Finite subdivision leaves finitely many shapes.

## O link: no parallel edges and no two-edge cycles

For a fixed block b, its L-directions and R-directions form the two vertex classes of a complete bipartite link graph. Fix directions L_buj and R_bvk. A corner joining them must have

alpha_b(i) = j-v, beta_b(i) = k-u.

The coordinate map is a bijection, so there is exactly one i giving that pair. Thus there is exactly one corner edge between the two directions. Directions belonging to distinct blocks are distinct; no corner joins different blocks. The O link is a disjoint union of simple complete bipartite graphs. Every nonempty cyclically reduced closed walk has at least four edges and angular length at least

4 * 27pi/50 = 108pi/50 = 54pi/25 > 2pi.

The common-three-vertices feature of the complex does not create any omitted parallel corner edges at O.

## V and W link maps really are immersions

At V the link has x_iuv-directions and L_buj-directions. Map an x direction to i and an L direction to p(b), the incidence point of the block. Map each corner to the incidence edge i--p(b).

At x_iuv, two corner edges could have the same projected incidence edge only if they use blocks at the same point z containing i. The partition at z places i in exactly one block, and u,v specify exactly one corner there. Thus there is no collision.

At L_buj, u,b,j are fixed. Prescribing the projected label i forces

v = j-alpha_b(i) mod s_b.

The allowed v are 0,...,r-1. Since s_b >= r, there is at most one allowed v. There is again no collision. This is local injectivity on *oriented incident edges*, which is the condition required for a graph immersion; injectivity on vertices is not required.

At W the proof is the same with R_bvk and

u = k-beta_b(i) mod t_b,

using t_b >= r.

An immersion takes an internally reduced path to an internally reduced path. It also preserves reduction at a closing seam for a cyclically reduced loop, because the two incident oriented edges at the seam remain distinct. Hence every nonempty cyclically reduced V/W link walk has a nonempty cyclically reduced image in the incidence graph. It has at least 14 edges. Its angular length is therefore at least

14 * 9pi/50 = 126pi/50 = 63pi/25 > 2pi.

This proof does not presume that a reduced image is itself a simple cycle: any nonempty reduced closed walk in a simple graph contains a simple cycle no longer than the walk.

## The rectangle-turn argument survives the closing seam

Take any reduced link path between **distinct** x directions bearing the same label i. Its projected endpoints are both i. The image is a positive closed walk, reduced at every internal vertex. Reduction at its closing seam is not automatic, and is not needed.

Choose a shortest positive interval of this walk whose endpoints are equal. Its internal vertices are all distinct. A one-edge interval would be a graph loop, which the bipartite incidence graph does not have. A two-edge interval would be traversal of an edge followed by its reverse; its middle vertex is internal to the original path, contradicting internal reduction. Thus the interval is a simple cycle of length at least 14. The entire path has at least 14 corner edges. A shortest path in a finite metric link is reduced, so the link distance between the two directions is at least 126pi/50, or the directions are disconnected and their distance is infinite.

The four-edge path

x_iuv x_iu'v^(-1) x_iu'v' x_iuv'^(-1), with u != u' and v != v',

is closed. Its turns at W compare two x directions differing in u; its turns at V compare two x directions differing in v. All have the same i and are distinct. Every turn has link distance greater than pi. Interiors of its edges are geodesic. It is consequently a positive-length closed local geodesic.

The fact that the base rectangle visits V and W twice is harmless: local geodesicity is a local condition, not an assertion that the base loop embeds.

## CAT(-1), torsion-freeness, and hyperbolicity

The preceding inequalities establish the 2pi link condition, including the additional subdivision vertices. The classical finite-shape link theorem gives a locally CAT(-1) metric. Its complete simply connected universal cover is CAT(-1).

The finite complex has positive edge lengths and finitely many shapes and incidences. Its cover is complete and locally finite; together with the CAT geodesic metric this gives a proper space. Deck transformations act freely, properly and cocompactly by isometries. A CAT(-1) space is Gromov hyperbolic, and the proper cocompact action transfers this to the finitely generated fundamental group. A finite-order isometry of the complete CAT(0) cover has a fixed point, while a nonidentity deck transformation cannot have a fixed point; therefore the group is torsion-free. The cover is contractible, making the base a finite two-dimensional K(G,1).

A nullhomotopic rectangle would lift to a positive-length closed local geodesic in this CAT(-1) cover. A local geodesic in a CAT(0) space is a geodesic, and a positive-length geodesic cannot have equal endpoints. Thus every nondegenerate rectangle is a nonidentity group element.

I checked Bridson-Haefliger II.5.2, II.5.4 and II.5.6 against the original pages 206-207, as both extracted text and rendered page images. II.4.13, page 201, also explicitly supplies the local-geodesic nontriviality and torsion-free consequences. I did not adopt the source's long independent Euclidean thinness proof. The separate CAT(-1) metric makes that proof unnecessary for this template.

Primary references: [Bridson-Haefliger original text](https://webhomes.maths.ed.ac.uk/~v1ranick/papers/bridsonhaefligerx.pdf), [Bridson's author exposition](https://people.maths.ox.ac.uk/bridson/papers/bridsonicm.pdf). The first web extraction failed in this audit; the supplied local copy was read and its decisive pages were rendered to `work/deep/nonsofic_geometry_assets/BH-229.png` and `BH-230.png`. These are printed pages 206 and 207.

## The rank obstruction: a direct reconstruction

Assign arbitrary D-point permutations to every edge, for an arbitrary positive integer D. Assume triangle defects are at most delta and every nondegenerate evaluated rectangle has fixed fraction at most lambda. These assignments need not be a homomorphism.

Let Y_i be the r-by-r block matrix of D-by-D permutation matrices X_iuv. Direct expansion gives

tr(Y_i Y_i^T) = r^2 D,

tr((Y_i Y_i^T)^2) <= [2r^3-r^2 + r^2(r-1)^2 lambda] D.

The degenerate choices u=u' or v=v' give identity for arbitrary assignments; there are 2r^3-r^2 of them. Each other trace is precisely the number of fixed points of the specified rectangle. Cauchy-Schwarz on the nonzero eigenvalues gives

rank_R Y_i >= r^2 D / [2r-1+(r-1)^2 lambda].

Every row has exactly r entries equal to one, in disjoint block columns. If d is its real rank, a nonzero d-by-d minor has an integer determinant of absolute value <= r^(d/2). If the minor has rank d' modulo q, choose d' original rows spanning the row space modulo q, and subtract integer lifts of their combinations from the other rows. These determinant-preserving operations make d-d' rows divisible by q. Thus q^(d-d') divides the nonzero determinant and q^(d-d') <= r^(d/2). Since q>r,

rank_Fq Y_i >= alpha(lambda) D,

alpha(lambda) = r^2 / [2(2r-1+(r-1)^2 lambda)]
              >= r/4 - r^2 lambda/8.

The last inequality follows by comparing alpha(lambda) to alpha(0): (r-1)^2/(2r-1)^2 <= 1/4. This is a numerical dimension argument. It never divides by D in F_q, so q dividing D causes no failure.

For any two permutations A,B, their matrix difference has nonzero columns only at moved arguments of A^(-1)B. Hence its rank over every field is at most D d_H(A,B). Triangle Hamming defect therefore bounds the rank of

X_iuv - L_(b,u,alpha+v)^(-1) R_(b,v,beta+u)

by delta D. At each regular point, the exact ideal sums over a Cartesian block factor as a block column (sum_j L_buj^(-1))_u times a block row (sum_k R_bvk)_v, with inner dimension D. This uses bijectivity of (alpha,beta), and preserves matrix factor order. It does not use commutativity of the assigned matrices. The r^2 |I(z)| errors are embedded separately, so for Z(z)=sum_(i in I(z)) Y_i,

rank_Fq Z(z) <= 2D + r^2 |I(z)| delta D for z outside E,

rank_Fq Z(z) <= rD for z in E.

The exact input certificate, applied to these arbitrary matrices, gives

-direct_sum_i Y_i = sum_z H(z) tensor Z(z).

Both sides have dimension NrD by NrD. Rank subadditivity and tensor-product rank imply

N alpha(lambda) D <= [2m+r|E|+r^2 S_reg delta] D.

Cancellation of the positive *numerical* D gives the uniform obstruction

**Delta <= r^2 (S_reg delta + N lambda/8).**

If delta,lambda are both at most

epsilon_* = min(1/2, Delta/[2r^2(S_reg+N/8)]),

the right side is at most Delta/2. No such assignment exists for any D. All source parameters and epsilon_* are chosen before D.

## Soficity really supplies this interface

Choose one finite subset F of G containing identity, all edge-loop elements, the inverses used in rectangles, all triangle products Lx=R, and the prefixes of all rectangles. The graph-to-group assignment is legitimate: choose paths from O to V,W, and turn each edge e into the based loop p_initial e p_terminal^(-1). A triangle supplies g_L g_x = g_R. A rectangular word reduces, after cancelling the chosen connecting paths, to a conjugate of the four-edge rectangle. Thus geometry gives exactly the group equalities and nonidentity elements used by the algebra.

Under the finite-set definition of soficity, for any eta>0 there are D and a map phi:F->Sym(D) with every required multiplication error <eta and every nonidentity listed element moving fraction >1-eta. [Arzhantseva-Paunescu, Definition 2.2](https://arxiv.org/html/1410.2626v2#S2) was checked directly.

Assign X=phi(g_x), L=phi(g_L), R=phi(g_R). Then

d_H(LX,R) < eta,

so every triangle defect is <eta. This uses the two-factor equality Lx=R and does not require a three-factor relator estimate.

Even if phi(1) is not required to be identity, the approximate equality 1*1=1 gives

d_H(phi(1),id) < eta.

The equality a*a^(-1)=1 then gives

d_H(phi(a)^(-1),phi(a^(-1))) < 2eta.

Each rectangle has two inverse substitutions, costing <4eta, and three prefix multiplications, costing <3eta. Its evaluation in the assigned edge permutations is within <7eta of phi(w). Since w!=1, phi(w) has fixed fraction <eta. The evaluated rectangle has fixed fraction <8eta. Choose eta<epsilon_*/8. This yields the forbidden simultaneous interface for a single D.

No exact normalization of tree-edge images is needed. If edges representing identity are assigned phi(1), the same estimates already cover them. No permutation stability theorem, repair to an exact action, or limit through the fixed finite presentation is used.

The same proof applies to any map G->H into a sofic group whose image leaves every rectangle nonidentity. If each of the finitely many rectangles survives under some such map, take the finite product of those maps. Finite products of sofic groups are sofic, and each rectangle survives in its own coordinate. This contradicts the obstruction. Therefore there is a fixed nonidentity rectangle killed by every map into every sofic group. The argument does not identify which one.

## Marked-affine-line source gate, independently checked

For h=20, c=100^(-20), fixed r with cr>=100, set P=F_q^h and choose one independent uniform projective direction through every mark in S^h, where |S|=floor(q/100). Labels are distinct marks even when the geometric lines coincide.

For each fixed z, every mark other than z has exactly one direction producing an incidence at z, out of J=(q^h-1)/(q-1) possible directions. These are independent events. Thus the degree is binomial with mean asymptotic to cq uniformly in z. Its lower-tail Chebyshev estimate is O(1/q), with fixed c,r. Markov gives at most m q^(-1/2) initially bad points with probability tending to one.

For a simple cycle of length 2s, 2<=s<=6, choose the s distinct point vertices and the s distinct label marks. Consecutive point vertices determine a line, giving at most q candidate marks on each prescribed line. For tuples of **distinct** marks the s direction events are independent and have probability J^(-s). Tuples with repeated marks are not simple label cycles and are omitted. The number of valid tuples is at most m^s q^s, so the expected cycle count is at most q^(2s). Coincident geometric lines do not undermine independence: it is the mark-indexed random directions that are independent.

There are O(q^12) expected short cycles; at most q^13 with probability tending to one. Removing all their labels discards at most 6q^13 labels. Include every point on their full lines in E, together with the initially bad points. Outside E no remaining degree changes. Therefore |E| <= m q^(-1/2)+6q^14=o(m), and N=(c+o(1))m. Because cr>=100, eventually Nr/4>2m+r|E|. Deleting labels cannot create short cycles.

For degree d>=4r^2, let n2 be the unique representative in {r,...,2r-1} congruent to d modulo r. Then d=r n1+(r+1)n2, with

n1 = [d-(r+1)n2]/r >= (2r^2-r+1)/r >= r.

So the source's two-block factorization is valid, including the minimal-degree boundary. Choose the block dimensions r by n1 and (r+1) by n2. Both moduli in each block are at least r.

The product Lagrange polynomials at surviving distinct marks have degree at most h(|S|-1). H(z)=f(z)f(z)^T has rank <=1 and H(a_i)=E_ii. Each entry restricts to degree <=2h(|S|-1)<q-1 on any affine line. Its full-line sum is zero in F_q, including the constant term because q=0 there. Removing **only that label's own mark** gives -E_ii. Other marks on the line remain in the sum. This is exactly item 5 of the input contract.

## Explicit constants and effectivity

I independently ran the 519 Lucas-Lehmer iterations for q=2^521-1 and obtained final residue zero. With h=20, c=100^(-20), r=100^21=10^42, exact integer/rational arithmetic checked:

- q>r and q>=64r^2/c;
- M0=floor(q/100)^20 >= cm/2;
- (M0-1)/J >= cq/8;
- 128r/(cq)+120r/q^7 < 1/2;
- the angle sum is 9pi/10, O cycle bound is 54pi/25, and V/W cycle bound is 63pi/25.

Here the exponent 521 is prime by trial division. The Lucas-Lehmer primality criterion is the classical additional number-theory fact behind this explicit q. The base proof can instead select any sufficiently large prime and does not depend on this chosen prime or primality calculation.

The fixed-parameter probability bounds are also consistent. The bad-point count B has expectation <=32m/(cq), and the short-cycle count C has expectation <=5q^12. Accept B<=m/(4r), C<=m/(24rq). Markov bounds rejection by 128r/(cq)+120r/q^7. Removing <=6C labels gives

|E|<=m/(2r), N>=cm/4,

Delta >= (cr/16-5/2)m = 15m/4.

Thus a Las Vegas sampler accepts with probability >1/2 each trial and halts almost surely with expected fewer than two trials. This is not a claim of halting on every random bit stream; a deterministic finite enumeration of all direction tuples also terminates because an accepted tuple exists and the predicates are decidable. Both algorithms are astronomically costly. The finite incidence data were not materialized here.

The source's common tolerance 1/(100rq) is justified: N<=cm, S_reg+N/8<=cmq and cr=100, so r^2(S_reg+N/8)/(100rq)<=m, while Delta>=15m/4. It also lies below epsilon_* because epsilon_*>=15/(800rq).

## Conditions a new h=5 incidence construction must not silently weaken

- Verify graph simplicity and **girth at least 14**, including all field-characteristic restrictions in the imported graph theorem. A claim only excluding 4,6,8,10-cycles is insufficient for the displayed angles.
- Prove degree >=4r^2 at each point retained as regular, or provide a different complete partition and charge the exceptional points in the same Delta.
- If labels are curves rather than affine lines, product-Lagrange total degree alone does not imply the power-sum certificate. The restricted polynomial degree and sum must be proved in the curve parameter.
- An embedding, coordinate change, or mark selection must preserve **distinct marks** and the scalar isolation H(a_i)=E_ii. An arbitrary deletion of point incidences destroys the punctured-line identity.
- A new graph with a different number of point vertices changes m, hence the 2m rank term. It must be recounted, rather than taking the source's old gap as a formal token.
- Every label may belong to at most one Cartesian block at a fixed regular point. Multiple incidence edges or overlapping blocks break the V/W immersion argument even if a coarse underlying graph has large girth.
- Keep q and r fixed before sofic accuracy and D. The small positive threshold can depend on the acquired design, but cannot depend on D.

## Source and verification record

- Read `00_START_HERE.txt`, `01_CORE.txt`, N06, both requested Markdown sources, and all of local `construction.tex`.
- Local construction SHA256: `9ddffe7f11b0b0133f03cf60dd93947b8d47b911f3f0930c8e55512cba8d930e`, matching the source audit's recorded hash. The pinned [primary construction](https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/a-torsion-free-hyperbolic-group-that-is-not-residually-finite-September-23-2026/build/sections/construction.tex) was independently opened and its mathematical content matched the local file. This is provenance, not correctness evidence.
- Directly read the sofic finite-set definition in the primary Arzhantseva-Paunescu paper.
- Checked the original Bridson-Haefliger printed pages 201, 206, 207; visually inspected 206-207 after rendering.
- Recomputed the explicit prime and rational parameter/angle checks above.
- Did not replay Lean, acquire independent external review, emit incidence/presentation tables, inspect all sentences of the long Euclidean proof, or certify prior art.
- No relevant memory entry was used; the quick memory search returned no match.

**Base status:** the base geometry and robust permutation template withstand this pass. Any final claim should retain the distinction between a written internally reconstructed construction, actual parameter/data emission, formal replay, and external validation. I found no mathematical defect to report as fatal.

## Additional requested audit: the h=5 D(5,q) moved-grid replacement

After completing the base audit, root requested an independent audit of `work/scouts/groups_approximation.md`. The following is a direct reconstruction of the replacement, not acceptance of that worker's verdict. **No fatal flaw was found in this replacement either.**

### The precise weaker geometric contract

The input-contract girth 14 above belongs to the original choice of angles. The link proofs themselves transfer to any incidence girth g. Choose common angles alpha at O and beta at V,W satisfying

4alpha > 2pi, g beta > 2pi, alpha+2beta < pi.

Such angles exist whenever g>8. In particular, a bipartite graph with no 4-,6-,8-cycles has girth at least 10 and permits

alpha=21pi/40, beta=9pi/40.

Then the angle sum is 39pi/40, O cycles have length at least 21pi/10, and V/W cycles and same-label turn paths have length at least 9pi/4. All required inequalities are strict. There is no need for the replacement to preserve girth 14. Conversely, retaining the old 9pi/50 small angles at girth 10 would fail the link condition, so changing the angles is a real and necessary part of the replacement.

### D(5,q) is represented by actual affine lines

The replacement's point coordinates (t,y,z,w,v) and label coordinates [a,b,c,d,e] satisfy

b-y=at, c-z=bt, d-w=ay, e-v=az.

These agree with the first five coordinates (p1,p11,p12,p21,p22) and (l1,l11,l12,l21,l22) in the primary LUW definition. The fourth relation is l22-p22=l1 p12. I directly checked this truncation in the local original PDF and the [primary paper](https://arxiv.org/pdf/math/9501231), section 2, equations (2.1)-(2.2), Proposition 2.1. Its graph theorem applies to prime powers; the present rank argument separately uses a **prime** q>r.

For fixed [a,b,c,d,e], the points of its label are exactly

(t, b-at, c-bt, d-ab+a^2t, e-ac+abt), t in F_q.

This is a full affine line, with normalized direction (1,-a,-b,a^2,ab). The first coordinate parametrization is injective. Distinct labels give distinct geometric lines: the normalized direction recovers a,b, and the point at t=0 then recovers c,d,e. At a fixed point, specifying a uniquely determines its incident label b=y+at, c=z+bt, d=w+ay, e=v+az. The incidence graph is therefore simple and q-regular on both sides, with q^5 vertices on each side.

### Independent no-4/6/8-cycle proof, including characteristic two

For a simple cycle with s labels, denote their parameters by a_j,b_j and the first-coordinate changes along them by tau_j. Each tau_j is nonzero, because distinct points on one label have distinct t. Adjacent a_j are distinct, including across the seam: at their common point there is a unique label with a prescribed a.

Closure in all five affine coordinates gives

sum tau_j = sum a_j tau_j = sum a_j^2 tau_j
          = sum b_j tau_j = sum a_j b_j tau_j = 0.

A 4-cycle would give two distinct affine lines through two distinct points, which is impossible. Equivalently the first two closure equations for two distinct a-values already contradict nonzero tau.

For s=3, the a-values are pairwise distinct, so the first three equations have an invertible three-by-three Vandermonde matrix; every tau would vanish.

For s=4 there are only the following cases:

- Three distinct a-values: group tau at each a. The first three equations and the three-value Vandermonde matrix make every grouped sum zero. The two singleton groups then have tau=0, impossible.
- Four distinct a-values: the last two equations place the vector b=(b_j) in the kernel of the two independent rows (tau_j) and (a_j tau_j). That kernel has dimension two. The vectors 1 and a are independent members of the kernel by the first three equations, so b_j=A+B a_j for constants A,B.
- Two distinct a-values: cyclic adjacency forces them to alternate. The first two closure equations make opposite tau values negatives. The last two equations then force b at opposite positions to be equal. The two resulting b-values are again of the form A+B a_j.

In each of the final two cases, adjacent labels have different a and intersect only at a point whose first coordinate solves

b_(j+1)-b_j = (a_(j+1)-a_j)t,

hence t=B. Both endpoints of every cycle label thus have the same first coordinate B, contradicting tau_j!=0. All operations divide only by differences of distinct field elements. The proof does not use characteristic unequal to two or an integer parity identity. Thus it establishes girth at least 10 in every field, independently of the imported LUW proposition.

### The perfect matching and the q-1 mark sets

Match each point to its unique incident label with a=t. Conversely, a label's matched point is the unique point on it with t=a. These two prescriptions are inverse, giving a perfect matching of the entire q^5-by-q^5 incidence graph.

For a fixed point x, its q neighboring labels have q **distinct** matched points because the matching is a bijection. Exactly one of these matched points is x, namely that of the label with a=t(x). Let A_x be the other q-1 matched points. It is a fixed subset of P independent of the subsequent affine grid movement.

Select marks B=U(S^5), and retain exactly their matched labels, each punctured at its own matched point. A neighbor of x is then retained and unpunctured at x exactly when its matched point belongs to B and differs from x. Consequently the degree identity is literally

d_x = |A_x intersect U(S^5)|, with |A_x|=q-1.

This is not an approximation and does not require any random directions or independence of label selection. In particular, the point x itself is removed whether or not it belongs to the moved grid, so the common mean uses q-1 rather than q or q-rho.

### Moved-grid covariance, exceptional points, and interpolation

Take U uniformly in the affine group AGL(5,q). This group is transitive on ordered pairs of distinct points: translate the first point and use an invertible linear map to send the nonzero difference vector to any desired nonzero difference. For N=|S|^5 and m=q^5, writing rho=N/m gives

P(a in B)=rho,

P(a,a' in B)=N(N-1)/[m(m-1)] for a!=a'.

The covariance of two distinct membership indicators is -rho(1-rho)/(m-1). Summing these indicators over A_x gives

mu=(q-1)rho,

Var(d_x)=(q-1)rho(1-rho) [1-(q-2)/(m-1)] <= mu.

Only pairwise covariance enters. Dependence between degrees at different x does not affect linearity of expectation or the later Markov bound.

If mu>=8r^2 and E={x:d_x<4r^2}, Chebyshev gives P(x in E)<=4/mu, hence E|E|<=4m/mu. Markov yields P(|E|>m/(2r))<=8r/mu. The selected punctured graph is a subgraph of D(5,q), so it retains girth at least 10 without any cycle enumeration or deletion.

For S={0,...,floor(q/10)-1}, construct the product Lagrange polynomials in the five coordinates of U^(-1)(X). Those coordinates are affine linear. Each f_i has total degree at most 5(|S|-1), isolates its own mark among B, and its product with f_j has degree at most 10(|S|-1)<q-1 on every affine line. The characteristic-q full-line sum is zero, and puncturing at the mark gives -E_ii. The polynomial argument does not require U to be an automorphism of D(5,q); U moves the grid, while the original graph's labels remain affine lines. This distinction is handled correctly in the replacement.

Therefore the replacement supplies exactly the required rank-one certificate, partition input and curvature input.

### Fixed h=5 numerical budget, checked independently

With q=2^61-1, r=1,200,000 and c0=1/100000, I recomputed the 59 Lucas-Lehmer iterations and obtained final residue zero. The exponent 61 is prime. Exact rational arithmetic independently checked

q>r, q>=16r^2/c0,

N=floor(q/10)^5 >= 0.9 c0 m,

mu=(q-1)N/m >= c0 q/2 >=8r^2,

8r/mu <=1/r.

Hence an admissible U exists with probability at least 1-1/r, obeying |E|<=m/(2r). The gap is

Delta >= (0.9 c0 r/4 - 5/2)m = m/5.

The equality uses c0 r=12. The 2m term correctly counts all q^5 point vertices, not just the moved grid marks. I also recomputed the size ledger: m has 92 decimal digits, N 87, the punctured-incidence count N(q-1) 106, and its triangle-count upper bound N(q-1)r^2 118.

A common explicit sofic rejection threshold is available at these parameters. Since N<=c0m and S_reg+N/8<=Nq, defects delta,lambda<=1/(100rq) would force

Delta <= r^2 (S_reg+N/8)/(100rq)
       <= c0 r m/100 = 3m/25 < m/5 <= Delta,

which is impossible. Thus finite-set sofic accuracy eta<1/(800rq) suffices. This adds no dependence on D.

### Status of the new input construction

The universal coordinate, matching, covariance, interpolation, angle, and rank arguments withstand this independent pass. The new route avoids the original cycle-deletion acquisition cost and lowers the field and point-count parameters substantially.

It still has no actually acquired admissible affine map with a verified exceptional-set ledger in this run, no emitted Cartesian blocks or presentation, no formal proof replay, and no independent external certification. An admissible U has only 30 field coefficients, but the presently stated acceptance test scans an astronomical incidence/point ledger. A definition such as the first admissible U in a finite enumeration is effective, but does not make its numerical coefficients or the complete presentation available on this machine.

**Combined final status:** neither the original base template nor the h=5 moved-grid replacement was falsified in this pass. The new argument is supported by a complete ordinary written deduction at its explicit interfaces, and remains internally audited rather than formally or externally certified. No priority conclusion was examined here.
