# Independent endpoint-memory audit

## Verdict and scope

The proposed minimax order is correct under the stated interface. There is no fatal flaw in the posterior-loss/POVM-volume argument. With total retained cq dimension at most `D` for every independent public seed, no entanglement assistance, and a parameter-independent encoder observing only one sample,

\[
 P_\theta=\operatorname{Unif}[0,\theta],\qquad 1\leq\theta\leq2,
 \qquad
 e_D:=\inf_{E,R}\sup_{\theta\in[1,2]}
       \operatorname{TV}(RE P_\theta,P_\theta)
\]

satisfies, for every positive integer `D`,

\[
 \boxed{\frac{(1-\log2)^2}{8\log2}\,\frac1D
        \ \leq\ e_D\ \leq\ \frac{\log2}{2}\,\frac1D.}
\]

The constants are approximately `0.01698028` and `0.34657359`; they are not claimed optimal. The proposed loss with coefficient `1/4` already proves the lower constant `(1-log 2)^2/(16 log 2) = 0.00849014`. A balanced coefficient `1/2` doubles it. For `D>=2`, an explicit sharper classical upper is

\[
 e_D\leq\tanh\!\left(\frac{\log2}{4(D-1)}\right),
\]

and `e_1=1/4` exactly.

The only required correction to the informal argument is to set the decoded action to `A=clamp(Y,1,2)`: arbitrary decoder outputs need not lie in `[0,2]`. The loss must always be evaluated at an action in `[1,2]`.

This is an internal, complete elementary proof of the stated order, not an externally reviewed or novelty-certified result. I read only the research brief, repository entry/core instructions, and `cards/N07-gaussian-memory.txt`, and no other worker solution before this derivation. The mathematical proof below does not import the unreviewed Gaussian theorem.

## 1. Exact posterior and the proposed Bayes loss

Use the uniform prior on `theta in [1,2]`, only as a lower-bound device. Write

\[
 t(x)=\max(1,x),\quad 0\leq x\leq2,
 \qquad p_X(x)=\log\frac{2}{t(x)}.
\]

Outside `[0,2]`, `p_X=0`. For almost every `x`, the posterior density is

\[
 \pi(d\theta\mid x)
 =\frac{\mathbf1_{[t(x),2]}(\theta)}
        {\theta\log(2/t(x))}\,d\theta.
\]

The point `x=2` has zero probability and can be assigned the degenerate posterior at `2`.

For `0<c<1`, consider

\[
 L_c(\theta,a)=\mathbf1\{a>\theta\}+c(2-a),\qquad a\in[1,2].
\]

Let `t=t(x)` and `r_x(a)=E[L_c(theta,a)|X=x]`. If `a<=t`,

\[
 r_x(a)-r_x(t)=c(t-a).
\]

If `a>=t`,

\[
 r_x(a)-r_x(t)
 =\frac{\log(a/t)}{\log(2/t)}-c(a-t).
\]

Concavity of `log` gives the chord bound

\[
 \frac{\log(a/t)}{\log(2/t)}
 \geq\frac{a-t}{2-t}\geq a-t,
 \qquad t\geq1.
\]

Consequently,

\[
 r_x(a)-r_x(t)\geq\min(c,1-c)|a-t|.
\]

Thus `t(x)` is the unique Bayes action (up to null sets), and the parent's proposed `c=1/4` gives exactly the requested lower estimate

\[
 r_x(a)-r_x(t(x))\geq\tfrac14|a-t(x)|.
\]

Taking `c=1/2` instead gives the stronger coefficient `1/2`.

## 2. TV error controls excess Bayes risk, with constant 1

Let `Q_theta` be the decoded marginal law of `Y`, and assume

\[
 \sup_\theta\operatorname{TV}(Q_\theta,P_\theta)\leq e,
 \qquad \operatorname{TV}(P,Q)=\sup_B|P(B)-Q(B)|.
\]

Define the action `a(y)=min(2,max(1,y))`. Under the original experiment, `a(X)=t(X)` almost surely. Because the encoder is parameter independent and the public seed is independent of `(theta,X)`, the decoded action `A=a(Y)` is conditionally independent of `theta` given `X`. Therefore

\[
 R_Q-R_*=
 \mathbb E[r_X(A)-r_X(t(X))]
 \geq\min(c,1-c)\mathbb E|A-t(X)|.
\]

Here `R_Q` is the risk of the fixed rule `a(Y)` under the decoded experiment, and `R_*` is the Bayes risk under the original experiment. No claim that `a(Y)` is optimal for the decoded experiment is needed.

The range `[0,1+c]` gives the safe but loose bound `(1+c)e`. In fact, for every fixed `theta<2`, the oscillation of `a -> L_c(theta,a)` on `[1,2]` is exactly `1`: the minimum is `c(2-theta)` at `a=theta`, and the supremum is `1+c(2-theta)` as `a` decreases to `theta` from above. At `theta=2`, its oscillation is `c<=1`. Thus

\[
 |\mathbb E_{Q_\theta}L_c(\theta,a(Y))
  -\mathbb E_{P_\theta}L_c(\theta,a(X))|
 \leq e
\]

for each `theta`, by subtracting the fixed-theta minimum before the standard bounded-function TV estimate. After prior averaging,

\[
 \boxed{\min(c,1-c)\,\mathbb E|A-t(X)|\leq R_Q-R_*\leq e.}
\]

This argument needs only marginal reconstruction TV. It does not assume seedwise reconstruction accuracy.

## 3. Hybrid/quantum memory lower bound

Condition on an arbitrary independent public seed `u`. The complete input-dependent memory is a normalized state `rho_{x,u}` on

\[
 \mathcal A_u=\bigoplus_j M_{d_j(u)},\qquad
 \sum_jd_j(u)\leq D.
\]

View this algebra inside the block-diagonal matrices on a Hilbert space of dimension at most `D`. Since `rho_{x,u}` is positive with trace `1`,

\[
 0\leq\rho_{x,u}\leq I_u.
\]

Push the decoder's POVM on `Y` forward by the clipping map to obtain an action POVM `M_u(da)`, `a in [1,2]`. Its scalar trace measure

\[
 \mu_u(da)=\operatorname{Tr} M_u(da)
\]

has total mass `mu_u([1,2])=Tr(I_u)<=D`. For any `h>=0`, Tonelli and `rho<=I` imply

\[
\begin{aligned}
 &\Pr\{X\in[1,2],\ |A-X|\leq h\mid U=u\}\\
 &\quad=\int_1^2p_X(x)
       \int\mathbf1\{|a-x|\leq h\}
        \operatorname{Tr}[\rho_{x,u}M_u(da)]\,dx\\
 &\quad\leq\int\mu_u(da)
          \int_{[1,2]\cap[a-h,a+h]}p_X(x)\,dx\\
 &\quad\leq2h(\log2)D.
\end{aligned}
\]

The seed conditioning leaves `p_X` unchanged because the seed is independent of the observation. The bound has the same constant for every seed, so it remains valid after averaging arbitrary discrete or continuous seed laws.

The prior mass of the interval on which `t(X)=X` is

\[
 m=\Pr\{X\in[1,2]\}=\int_1^2\log(2/x)\,dx=1-\log2>0.
\]

Hence

\[
 \Pr\{|A-t(X)|>h\}\geq m-2h(\log2)D.
\]

Integrating this tail estimate up to `h=m/(2(log 2)D)` yields

\[
 \boxed{\mathbb E|A-t(X)|\geq
              \frac{(1-\log2)^2}{4(\log2)D}.}
\]

Together with Section 2, this proves

\[
 e\geq\min(c,1-c)
       \frac{(1-\log2)^2}{4(\log2)D}.
\]

Set `c=1/4` for the original proposed proof, or `c=1/2` for the stated stronger constant. Since this holds for every legal channel, it holds for `e_D` after taking the infimum.

Encoder private randomness is absorbed into `rho_{x,u}`; decoder private randomness is absorbed into the POVM. Classical block labels are charged because their block dimensions sum to `D`. Arbitrary nonorthogonal continuum state families are already allowed. No entropy bound, finite input alphabet, smooth likelihood, or seedwise TV condition is used.

## 4. Explicit classical upper with geometric bins

For `D>=2`, let `N=D-1`. Use one classical label for `[0,1]` and `N` labels for the intervals

\[
 [b_{j-1},b_j],\qquad b_j=2^{j/N},\quad j=1,\ldots,N.
\]

The encoder stores the interval containing `X`. The decoder draws uniformly from that interval. Boundary conventions have no distributional effect. This needs `D` one-dimensional blocks, so total hybrid dimension is `D`; it observes no parameter and uses no retained uncharged data.

If `theta in [a,b]` is in a geometric bin, every completed bin reconstructs its density `1/theta` exactly. Only the terminal bin differs. Writing `r=theta-a` and `w=b-a`, the exact TV discrepancy is

\[
 \operatorname{TV}(Q_\theta,P_\theta)
 =\frac{r(w-r)}{\theta w}
 =\frac{(\theta-a)(b-\theta)}{\theta(b-a)}.
\]

This quantity is maximized at `theta=sqrt(ab)`, where it equals

\[
 \frac{\sqrt b-\sqrt a}{\sqrt b+\sqrt a}
 =\tanh\!\left(\frac{\log(b/a)}4\right).
\]

All bins have ratio `b/a=2^{1/N}`, so the supremum is exactly

\[
 \tanh\!\left(\frac{\log2}{4(D-1)}\right)
 \leq\frac{\log2}{4(D-1)}\leq\frac{\log2}{2D}.
\]

An even simpler partition into `D` equal bins of `[0,2]` gives `e_D<=1/(2D)`.

For `D=1`, the decoded law cannot depend on `X`, even with independent public seeds. The triangle inequality and `TV(P_1,P_2)=1/2` imply `e_1>=1/4`. Equality is attained by

\[
 Q=\tfrac12P_1+\tfrac12P_2,
 \qquad q(y)=\tfrac34\mathbf1_{[0,1]}(y)
                   +\tfrac14\mathbf1_{(1,2]}(y).
\]

For `1<=theta<=4/3`, `TV(Q,P_theta)=(2-theta)/4<=1/4`. For `4/3<=theta<=2`, it is `5/4-1/theta-theta/4`, an increasing function with maximum `1/4` at `theta=2`. This also verifies the all-`D` upper constant above.

## 5. Essential assumptions and novelty limits

- The parameter set must contain the continuum `[1,2]` for this proof. A finite endpoint family has a finite exact classical sufficient alphabet: split at its endpoints and resample uniformly within intervals. In particular, the two endpoints `theta=1,2` alone are exactly reconstructible with `D=2`. The N07 assertion that finitely many spanning Gaussian means suffice cannot be imported here.
- The encoder must be parameter independent. If it is given `theta`, the posterior Markov argument fails and the operational problem changes.
- All retained input-dependent classical and quantum registers must be counted. An uncharged real-valued retained `X` would trivialize reconstruction.
- The public seed must be independent and cannot be modified to carry input-dependent information. Only the decoded marginal TV is needed, so averaging potentially poor seedwise protocols does not evade the converse.
- No shared entanglement assistance is allowed. The trace proof must cover the entire input-dependent decoder-side quantum system if that interface is enlarged.
- The bin/resample construction is a measurable statistical channel, not a finite precision runtime or hardware preparation claim. Such costs require a separate interface.
- The exponent reflects a nonsmooth support boundary and a linear-regret decision problem. The proof shares the general posterior-loss plus trace-volume mechanism stated in N07, but neither Gaussian correctness nor a literature priority claim is needed for this derivation.

**Strongest next question:** establish the sharp asymptotic constant, and determine whether arbitrary quantum memory or public randomness improves that constant over deterministic classical endpoint bins. The proved order alone does not show equality of optimal constants. A literature check of nonregular experiment quantization/statistical randomization should precede any novelty claim.

**Source consulted:** `work/astra-research-knowledge/cards/N07-gaussian-memory.txt` (source-derived, unreviewed claim; mechanism only), plus the repository's required entry/core instructions and `work/RESEARCH_BRIEF.txt`. No external literature assertions are used in the proof above.
