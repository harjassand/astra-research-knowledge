# Independent audit: parallel vacuum detection per expected input cost

Status: the finite-dimensional vacuum-detection theorem is proved below. The typical-projection construction attains the claimed asymptotic coefficient under expected input cost. All separable probes, including correlated classical mixtures of unequal product states, have the smaller single-cell coefficient. An exact qutrit example has separable coefficient exactly 1, a strict two-cell entangled advantage, and regularized coefficient approximately 1.06013159818. The maximum possible gain grows as the condition number of the positive-cost restriction. A generic fixed-message communication-error interpretation is false; the operational qualifications are stated explicitly.

This audit was derived independently before coordination with the information/thermodynamics worker. No historical-novelty claim is made. Algebra and proof are self-contained; no external theorem is needed for the main exponent result.

## 1. Exact interface and basic operator facts

Let the single-cell input Hilbert space be finite dimensional. Let H >= 0 have unique kernel span{|0>}, and let a known memoryless CPTP channel satisfy

    Phi(|0><0|) = |v><v|.

Put E = Phi*(|v><v|) and assume E > 0. Because the adjoint of a trace-preserving positive map is unital and positive,

    0 < E <= I,    <0|E|0> = 1.

Positivity of I-E implies (I-E)|0> = 0. Thus E|0> = |0>, and E preserves the excited subspace |0>^perp. H does too. Define

    L = -log E >= 0,
    alpha = lambda_max(H_+^(-1/2) L_+ H_+^(-1/2)).

The suffix + denotes restriction to |0>^perp, not the positive part of an arbitrary matrix. Finite dimension and a unique zero-cost ray make H_+ invertible; E > 0 makes L bounded. Equivalently,

    alpha = max_{w: <w|H|w> > 0} <w|L|w>/<w|H|w>,
    L <= alpha H.

One can choose the maximizing unit vector w in the excited subspace. If L = 0, then E = I, alpha = beta = 0, and no probe can decrease the no-click probability below 1. The nontrivial statements below assume L != 0, hence alpha > 0.

For r parallel cells define

    H^(r) = sum_i H_i,    L^(r) = sum_i L_i,
    Q(rho) = Tr rho H^(r),
    p0(rho) = Tr rho E^(tensor r) = Tr rho exp(-L^(r)).

The charged quantity is expected input cost of the prepared probe. It is not a hard spectral-energy constraint and does not automatically include preparation work, driving references, resets, timing, or receiver work.

If the null experiment outputs the pure state |v>^(tensor r), p0 is precisely the minimum miss probability at zero false-alarm probability. A rejection effect T with zero null expectation must annihilate the null vector. The largest admissible rejection effect is I-|v>^(tensor r)<v|^(tensor r), so the corresponding miss effect is the null projector.

## 2. Universal entangled-probe bound: proved

For any r-cell density operator, including arbitrary entanglement,

    p0(rho) >= exp(-alpha Q(rho)).

Proof: apply scalar Jensen to the spectral distribution of L^(r) in rho:

    Tr rho exp(-L^(r))
      >= exp(-Tr rho L^(r))
      >= exp(-alpha Tr rho H^(r)).

The second step uses L^(r) <= alpha H^(r), obtained by summing local positive inequalities. No operator monotonicity of exp is used. Indeed, inferring exp(-L) >= exp(-alpha H) directly from L <= alpha H would be invalid for noncommuting matrices; that inference is unnecessary here.

The bound is statewise and therefore applies to a maximum per-codeword expected cost budget. It also gives an average no-click-mass bound under average expected cost, by another scalar Jensen.

## 3. Spectral-typical achievability: proved under expected cost

Choose a maximizing excited unit vector w, and write

    h = <w|H|w> > 0,    ell = <w|L|w> = alpha h.

Let delta_r -> 0 with r delta_r^2 -> infinity. For example delta_r proportional to r^(-1/4) works. Let P_r be the spectral projector of L^(r) onto

    [r(ell-delta_r), r(ell+delta_r)].

Put psi_r = w^(tensor r), eta_r = <psi_r|P_r|psi_r>, and

    chi_r = P_r psi_r / sqrt(eta_r).

The spectral distribution of L^(r) in psi_r is the sum of r iid bounded random variables, each having the spectral distribution of L in w. Thus eta_r -> 1. A concrete Hoeffding bound is

    1-eta_r <= 2 exp(-2 r delta_r^2/||L||^2).

The pure-state trace-norm distance is

    || |chi_r><chi_r| - |psi_r><psi_r| ||_1
      = 2 sqrt(1-eta_r).

Consequently

    |Q(chi_r)-rh| <= 2r ||H|| sqrt(1-eta_r) = o(r).

This cost estimate is valid even when H and L do not commute. On the range of P_r,

    exp(-L^(r)) <= exp(-r(ell-delta_r)) I,

so

    p0(chi_r) <= exp(-r(ell-delta_r)).

Together with the universal lower bound,

    (-log p0(chi_r))/Q(chi_r) -> ell/h = alpha.

Therefore the supremum of -log(p0)/Q over all finite parallel blocks is exactly alpha. This does not assert that a finite block attains the supremum. Repeating any fixed block whose ratio exceeds alpha-epsilon establishes the leading small-miss cost law

    inf{Q: p0 <= epsilon} / log(1/epsilon) -> 1/alpha

as epsilon -> 0. Similarly, if C(Q) is the infimum no-click probability over all block lengths with expected cost at most Q, then

    -log C(Q)/Q -> alpha    as Q -> infinity.

The construction is a valid normalized pure state. It is generally entangled when filtering a superposition of distinct local L eigenvalues. Entanglement is not required when a maximizing w is already an L eigenvector.

### What the construction does not prove

It does not establish the same coefficient with a hard support constraint rho supported on {H^(r) <= Q}. L-typical projection preserves expected H cost; it need not preserve a hard H spectral budget. Applying a subsequent H projection can change an exponentially small p0 by a much larger additive amount, so trace-distance closeness alone does not repair that gap.

Nor does the construction show exact saturation at each fixed finite Q. For example, for the commuting qubit pair

    H = diag(0,1),    E = diag(1,exp(-a)),    a > 0,

the exact optimum at expected cost Q = k+t, k a nonnegative integer and 0 <= t < 1, allowing arbitrary vacuum padding, is

    C(Q) = (1-t)exp(-ak) + t exp(-a(k+1)).

This follows from the lower convex envelope of exp(-a n) on integer excitation number n. In particular, for 0 < Q < 1,

    C(Q) = 1-Q+Q exp(-a) > exp(-aQ).

The exponent theorem is an asymptotic large-cost theorem. With the hard spectral budget Q < 1 in this example, only the vacuum is allowed and C(Q)=1.

## 4. Product states and arbitrary separable mixtures: proved

Define

    beta = max_{unit w: <w|H|w> > 0}
             [-log <w|E|w>]/<w|H|w>.

Vacuum admixture cannot improve the maximum. If a pure state has excited weight t and normalized excited component z, let e=<z|E|z> and h=<z|H|z>. Its mass and cost are 1-t+te and th. Convexity of -log gives

    -log(1-t+te) <= t(-log e).

Thus beta is attained on the compact unit sphere in the excited subspace, where H cost is bounded below by h_min > 0.

Every single-cell mixed state sigma satisfies

    Tr sigma E >= exp(-beta Tr sigma H).

To see this, decompose sigma into pure states and apply Jensen to exp(-beta q). For a product rho = tensor_i sigma_i, multiplication gives

    Tr rho E^(tensor r) >= exp(-beta sum_i Tr sigma_i H).

For a general separable state rho = sum_j lambda_j tensor_i sigma_(ij), a second Jensen yields

    p0(rho) >= sum_j lambda_j exp(-beta Q_j)
             >= exp(-beta sum_j lambda_j Q_j)
             = exp(-beta Q(rho)).

This covers unequal product factors, mixed local inputs, correlated classical randomization, unequal branch costs, and vacuum padding. Repeating a beta-maximizing single-cell state attains ratio beta exactly. Hence the best coefficient for all separable blocks is beta, not merely for identical pure product pulses.

Jensen also proves beta <= alpha. The exact equality criterion is:

    beta = alpha
      iff an excited E eigenvector lies in ker(alpha H-L).

For alpha>0, equality in the first Jensen requires the maximizing vector to lie in one L eigenspace; equality in the Rayleigh quotient requires it to lie in ker(alpha H-L). Such a vector is also an H eigenvector. Commuting H and E are sufficient for equality. Noncommutation alone is not sufficient for a strict advantage: in dimension 4, for instance, put

    H = 0 direct-sum 1 direct-sum [[1,1/2],[1/2,1]],
    E = diag(1,exp(-10),exp(-1),exp(-2)).

The last two coordinates do not commute, but the common |1> eigenvector has ratio 10, larger than the other block's generalized ratio 2+(2/3)sqrt(3), so alpha=beta=10. A qubit input cannot have a noncommuting H/E pair under the stated unique-vacuum assumptions: its excited subspace is one dimensional. A strict example therefore requires at least input dimension 3.

### Finite block size and entanglement depth

Let beta_r be the unrestricted r-cell ratio supremum. It is attained away from the unique global vacuum, beta_r is nondecreasing by padding, and beta_r -> alpha. If beta < alpha, then beta_r < alpha for every finite r.

Proof of the last statement: equality at finite r would require support in one eigenspace of L^(r), together with zero expectation of A^(r), where A=alpha H-L >= 0. Every local marginal would then be supported in ker A. A global state supported in one L^(r) eigenspace has each local marginal commuting with L: partial trace of its commutator with sum_i L_i gives the local commutator. A positive-cost marginal therefore supplies an L eigenvector in ker A, implying beta=alpha, a contradiction.

For k-producible probes (products of entangled blocks of size at most k, and arbitrary mixtures of such products), the coefficient is at most beta_k < alpha when beta<alpha. Increasing entanglement depth is necessary to approach alpha. The constructive companion additionally proves a quantitative gap alpha-beta_k >= c/k^2 for its explicit E_+=diag(exp(-1),exp(-4)), H_+=[[1,1/2],[1/2,1]] witness; its constant and inequalities were independently checked in this audit.

For completeness, its exact constants and checked derivation are as follows. On the excited two-dimensional cell put

    alpha_* = (10+2sqrt(13))/3,
    p = (23+6sqrt(13))/61,
    v = 9p(1-p),
    mu = (5+4sqrt(13))/3,
    c = min{mu v/216, (2/3)log(1+v/18)}
      = 0.0529573641543205... .

Here p is the weight-four spectral population of the maximizing w, v is its local L variance, and mu is the nonzero eigenvalue of A=alpha_* H-L. For any k-producible probe,

    -log(p0)/Q <= alpha_* - c/k^2.

Thus reaching alpha_* within epsilon requires k >= sqrt(c/epsilon).

To verify the quantitative estimate, first take an all-excited block of j cells, X=L^(j), and d=Tr rho A^(j). A^(j) has gap mu and unique ground vector w^(tensor j). Purify rho to Psi and let W be its projection onto that ground ray times the ancillary space. If s=1-||W||^2, then s<=d/mu. With x=Tr rho X and spectrum X contained in [j,4j],

    sqrt(Var_rho X)
      >= sqrt(1-s)sqrt(jv) - 3j sqrt(s).

If d<mu v/(144j), then s<1/64 and the right side is at least sqrt(jv)/2. Hence Var_rho X>=jv/4. For Y=X-x, the scalar curvature bound

    exp(-Y) >= 1-Y+c_B Y^2,
    B=3j,
    c_B=(B-1+exp(-B))/B^2 >= 2/(9j)

gives the Jensen gap J=x+log Tr rho exp(-X) >= log(1+v/18). If instead d>=mu v/(144j), then d itself supplies the needed gap. Since

    alpha_* Q+log(p0)=d+J,    Q<=3j/2,

the ratio gap is at least c/j^2. The small-d case first gives a stronger term proportional to 1/j; weakening to 1/j^2 is valid for j>=1. Dephase only the vacuum/excited pattern, which preserves both H^(j) cost and E^(tensor j) mass. Each nonvacuum pattern has at most k excited cells, so the uniform c/k^2 bound extends by Jensen to arbitrary blocks of size k, products of these blocks, and arbitrary k-producible mixtures. This argument does not impose a hard H spectral budget.

## 5. Exact qutrit witness, including a finite two-cell gain

Let b=log(8/3), and set

    E = diag(1,1/2,1/4),
    H = 0 direct-sum [[b-1/12,-1/4],[-1/4,b+7/12]].

The excited H eigenvalues are b-1/6 and b+2/3, both positive. For excited first-coordinate population t, the least energy over relative phase is

    h(t) = b+7/12 -(2/3)t -(1/2)sqrt(t(1-t)),

and its -log no-click mass is

    n(t) = log(4/(1+t)).

At t=1/2, h=n=b and h'=n'=-2/3. For 0<t<1,

    (h-n)'' = 1/[8(t(1-t))^(3/2)] - 1/(1+t)^2 >= 0.

Thus h(t)>=n(t), with equality at the equal positive superposition. Other relative phases only increase H cost. Vacuum admixture cannot improve the ratio. Therefore

    beta = 1    exactly.

The generalized eigenvalue is

    alpha = log(2) * [3b+5/12+sqrt((b-3/4)^2+1/2)]
                      / [2(b^2+b/2-1/9)]
          = 1.06013159817787... .

Already the equal superposition has L/H ratio (3/2)log(2)/b > 1: equivalently, 2sqrt(2)>8/3. A maximizing w has excited amplitudes approximately

    w = (0.716122320350789, 0.697974800616328),
    <H> = 0.972357467660123,
    <L> = 1.030826876190713.

An exact amplitude ratio is

    w_2/w_1 = 4[alpha(b-1/12)-log(2)]/alpha.

The following finite two-use state, supplied after the independent main derivation by the novelty worker and checked algebraically here, already beats every separable block:

    chi = (4|11>+5|12>+5|21>+4|22>)/sqrt(82).

Its exact values are

    p0 = 45/328,
    Q = 2b+1/82,
    -log p0-Q = log(41/40)-1/82 > 0.

For a direct proof of positivity, log(1+x)>x/(1+x) gives log(41/40)>1/41>1/82. The ratio is approximately 1.00633151844. This is a finite entanglement witness, not an asymptotic numerical suggestion.

More generally, if a beta-maximizing vector w is not an E eigenvector, choose unit z perpendicular to w with a=<z|E|w> != 0, and align the phase of

    chi_t = (w tensor w - t z tensor z)/sqrt(1+t^2)

so the E^(tensor 2) cross term is negative. Then p0'(0)=-2|a|^2, while Q'(0)=0 because H_1+H_2 has zero cross matrix element between ww and zz. The exponent/cost derivative at zero is |a|^2/(<E>^2 <H>)>0. This proves a two-use gain in that case. It does not prove that every strict alpha>beta pair has a two-use gain, because beta may be maximized by a common eigenvector in a different direct-sum block.

Every E in the examples has a physical channel realization with orthogonal outputs:

    Phi_E(rho) = Tr(E rho)|v><v| + Tr((I-E)rho)|c><c|,
    <v|c> = 0.

This is a CPTP binary measure-and-prepare channel, maps the input vacuum to |v>, and has exactly the specified pulled-back vacuum effect. Although this channel has classical outputs, entangled input coherences can lower the charged noncommuting H expectation; fully separable inputs cannot duplicate that cost benefit.

## 6. Condition-number comparison: sharp order, proved

Let kappa=h_max/h_min be the condition number of H_+. For every nontrivial admissible pair,

    1 <= alpha/beta <= kappa.

Indeed, alpha <= ||L||/h_min. An L-maximizing eigenvector has product numerator ||L||, so beta >= ||L||/h_max. These two inequalities prove the bound. Uniformly bounded cost conditioning excludes arbitrarily large gain.

A qutrit family attains this order. For kappa>=1, set

    c0 = (2-sqrt(3))/4,
    eta = 1/kappa,
    M = c0 log(4) kappa,
    E = diag(1,1,exp(-M)),
    H = 0 direct-sum [[(1+eta)/2,(1-eta)/2],
                     [(1-eta)/2,(1+eta)/2]].

H_+ has eigenvalues eta and 1. Since L_+=M|2><2|,

    alpha = M(1+eta)/(2eta) = M(kappa+1)/2.

For lossy-coordinate population s, the minimum pure-state cost and numerator are

    h(s) = (1+eta)/2 -(1-eta)sqrt(s(1-s)),
    n(s) = -log(1-s+s exp(-M)).

If s<=3/4, n(s)<=log(4) and h(s)>=eta. If s>3/4, h(s)>=c0 and n(s)<=M. Vacuum admixture cannot improve. Hence

    beta <= max{log(4)/eta, M/c0} = log(4) kappa,
    alpha/beta >= c0(kappa+1)/2
                = [(2-sqrt(3))/8](kappa+1).

Consequently the supremum gain over this class is Theta(kappa), already for three input levels. Both the increasingly small positive cost eigenvalue 1/kappa and the effect dynamic range exp(M)=exp(c0 log(4) kappa) belong in the resource account.

The initially proposed unbounded family eta=M^(-2) also passes. Its alpha=M(1+eta)/(2eta). For M>=1/(c0 log(4)), beta<=log(4)M^2, hence alpha/beta>=M/(2log(4)). The kappa-parametrized version above is the stronger normalized scaling statement.

## 7. PPM and communication-error regimes

### Direct PPM achievability

Place an r-cell pulse in one of N disjoint r-cell blocks and use input vacuum in every inactive block. Every codeword has pulse cost Q, while total physical word length is Nr cells. Test each block against |v>^(tensor r). Inactive blocks never click, and an active block clicks with probability 1-p0. A click identifies the message exactly. If no block clicks, guess a message; for equiprobable messages and identical pulses,

    P_error = (1-1/N)p0

for this receiver. Thus entangled pulses achieve an error exponent at least alpha. Unrestricted physical cell count is essential to the arbitrary-N interpretation and is not hidden in the input-energy charge.

### Exact converse for the orthogonal-output realization

For Phi_E with v perpendicular to c, every output is classical in the v/c product basis. All codeword distributions share the all-vacuum atom. With maximum per-message expected cost Q, every such atom has probability at least exp(-alpha Q). Any decoder therefore has average error at least

    (1-1/N) exp(-alpha Q).

Entangled PPM attains alpha, so this is the optimal fixed-N communication reliability coefficient, for arbitrary parallel codewords, under maximum per-message expected input cost. For separable codewords, the same statement holds with beta. In particular the qutrit witnesses are operational communication examples, not merely formal input-effect calculations.

### Why a generic fixed-N quantum-output converse is false

Take qubit H=diag(0,1). Measure the input in its computational basis, prepare v for zero, and prepare

    u = sqrt(p)v + sqrt(1-p)v_perp,    0<p<1,

for one. This channel is entanglement breaking but does not have orthogonal prepared outputs. Its E=diag(1,p)>0 and alpha=-log p. With a pulse |1>^(tensor r), vacuum mass is p^r and cost is r. Binary PPM output states are pure and have inner-product amplitude p^r. Their optimal Helstrom error is

    [1-sqrt(1-p^(2r))]/2 ~ p^(2r)/4.

The optimal decoding exponent is 2alpha, despite the exact vacuum-mass exponent alpha. Entanglement breaking by itself is insufficient for the classical common-atom converse; orthogonal classical outputs are required for that particular argument.

### General common-overlap bound and a large-message converse

Let tau_m be arbitrary quantum codeword outputs on a common output space, let V be the global vacuum vector, and suppose a_m=<V|tau_m|V> >= eta. For a decoder POVM {D_m}, put t_m=<V|D_m|V>, s_m=Tr(tau_m D_m), and epsilon_m=1-s_m. Cauchy applied to the two-outcome measurement gives

    sqrt(a_m) <= sqrt(s_m t_m)+sqrt(epsilon_m(1-t_m)).

One can prove this directly by writing tau_m^(1/2)V as the sum with D_m and I-D_m and bounding the corresponding operator norms by Hilbert-Schmidt norms. Averaging and applying Cauchy again yields

    sqrt(eta) <= sqrt((1-P_error)/N)
                 + sqrt(P_error(1-1/N)).

Therefore

    P_error >= [sqrt(eta(1-1/N))-sqrt((1-eta)/N)]_+^2
            >= [sqrt(eta)-1/sqrt(N)]_+^2.

The first displayed lower bound is tight among unrestricted quantum state ensembles with common-reference overlap at least eta. An explicit attaining construction when eta>=1/N uses an orthonormal basis {phi_m}, V=N^(-1/2)sum_m phi_m, z_m=sqrt(N/(N-1))(phi_m-V/sqrt(N)), and tau_m the pure state sqrt(eta)V+sqrt(1-eta)z_m. Measuring in the phi basis attains the bound; the Gram off-diagonal is (N eta-1)/(N-1). When eta<=1/N, N orthogonal states can each have overlap eta with a common external vector, so no positive common-overlap-only lower bound is possible.

Substituting eta=exp(-alpha Q) gives a general quantum decoding-error converse with coefficient alpha whenever

    N exp(-alpha Q) -> infinity.

More generally a fixed lower bound N exp(-alpha Q)>1 by a factor separated from 1 suffices for the coefficient. Entangled PPM supplies the matching upper bound. For separable words use beta. This regime distinguishes arbitrary quantum outputs from the fixed-N orthogonal-output result. The threshold involves N times vacuum mass, not N times its square.

Under average codeword cost Q rather than a maximum cost, the same large-N inequality survives: average sqrt(a_m) >= average exp(-alpha q_m/2) >= exp(-alpha Q/2), which is the quantity used in the averaged proof.

### Fixed-N average-message cost is different

For the orthogonal-output realization, if average codeword cost is at most Q, the optimal fixed-N coefficient is alpha N/(N-1), not alpha. For the all-vacuum atom let a_m>=exp(-alpha q_m). Its contribution to average error is (sum a_m-max a_m)/N. Remove the largest atom and apply Jensen to the remaining N-1 costs, whose sum is at most NQ, to obtain

    P_error >= (N-1)/N exp(-alpha NQ/(N-1)).

Achieve this asymptotically by using one cost-free all-vacuum message and N-1 distinct PPM pulses each of cost NQ/(N-1), guessing the cost-free message on erasure. The same conclusion holds with beta for separable inputs. At large N this distinction disappears; at fixed N it must be stated.

## 8. Further boundaries of the proved model

* Time-translation covariance matters. If Phi is covariant with respect to input Hamiltonian H and the output reference projector is invariant under output time evolution, then E commutes with H. A common eigenvector reaches alpha already as a product pulse; alpha=beta. The noncommuting advantage thus uses a channel/reference outside that autonomous covariant interface.
* A full-rank null output eliminates nonzero zero-false-alarm rejection effects. The pure reference assumption is load-bearing. A small but nonzero false-alarm tolerance defines a different hypothesis-testing problem.
* Adaptive stopping changes the cost law. Repeating a pulse of cost h and miss p until a click or k trials has miss p^k but alternative-only expected cost at most h/(1-p). Null cost is kh. The parallel exponent theorem cannot be transferred to that asymmetric adaptive expectation convention.
* Infinite dimension is not covered by the proof as stated. Strict positivity need not bound -log E; unique kernel need not give H_+ a spectral gap; lambda_max may be a nonattained supremum; and bounded-H trace-norm control may fail. Additional domain, integrability, approximation, and cost-tail hypotheses would be required.
* The theorem is for supplied, known H, Phi, E, and w. It does not establish calibration/acquisition complexity or a local computational runtime. The explicit diagonal-qutrit preparation is separately constructive, but general spectral projectors require their own implementation account.

## 9. Cross-check of the main report

Section 2 of outputs/research_report.tex was checked for transcription, scope, and mathematics. The main universal bound, typical projection, all-separable comparison, exact qutrit witness, condition-number theorem, covariance statement, adaptive stopping counterexample, and constructive Hoeffding window are correct. The coherent-output counterexample's initially omitted H=diag(0,1) was reported to the root worker and its correction was verified. The window width sqrt(2r log r) for Bernoulli type count has tail at most 2r^(-4); this matches the constructive statement.
