# Logic and algorithms scout: exactification, uniformity, and counting

Date: 7 October 2026. Status: two elementary internal derivations, one decisive generic-transfer obstruction. No externally reviewed new theorem or general derandomization result.

The main finding is that N16's exact success-mass decoder is a computational assumption of its own. Unique verification, a success floor of one half, and a public polynomial dyadic denominator do not acquire that decoder. I reconstructed N16's arithmetic and coherent implementation; I then derived a fixed-gate oracle obstruction to deleting the decoder, and a modest positive extension removing uniqueness when a coprime auxiliary mass is available. The strongest positive research direction is a **structured, output-conditioned mass service**, with an equally informed direct solver as the comparator. A generic verification-only route should be rejected.

## Source scope and primary literature

Read source paths:

- `work/astra-research-knowledge/00_START_HERE.txt` and `01_CORE.txt`.
- `work/astra-research-knowledge/cards/N16-dyadic-exactification.txt`.
- `work/astra-research-knowledge/web/assets/a9bcb8de3fb3c0ab8036a1d6415500656e8a73f044be1e53bc8999d0063677d4.md`, the complete source section headed “Exactification from a uniquely verified output and its decoded success mass.” The equivalent page is `web/pages/d-810c4f24dd8b5912.html`.
- `web/pages/d-e5a1430b148e5070.html`, the matching N16 portion of the supplied synthesis.
- `cards/W-logic-gate14.txt`, `W-logic-prior14.txt`, and `W-metric-prior.txt`, to retain the corpus's uniformity, witness-bound and bit-height distinctions.

The source's OA279 factoring controller, order trial, and primality argument were not audited. Neither its global factoring headline nor other extraordinary release headlines are adopted here.

Primary literature refreshed:

1. [Brassard, Høyer, Mosca and Tapp, Quantum Amplitude Amplification and Estimation](https://arxiv.org/abs/quant-ph/0005055): exact amplification when the success probability is known is established. Their known-probability construction uses a probability-dependent rotation; finite-gate exact synthesis requires a separate argument.
2. [Jordan, Kobayashi, Nagaj and Nishimura, Achieving Perfect Completeness in Classical-Witness Quantum Merlin–Arthur Proof Systems](https://arxiv.org/pdf/1111.5306): inspected the model, proof of Theorem 5, and the additive adjustment/reversal construction, especially pp. 2–6. Their probability description is supplied in Merlin's classical witness. Hadamard/Toffoli/NOT suffice; conditional subroutines can be run unconditionally while irrelevant outcomes are ignored. This is substantial prior art for N16's adjustment mechanism. It does not provide a cheap decoder from a newly generated solution.
3. [Beals, Buhrman, Cleve, Mosca and de Wolf, Quantum Lower Bounds by Polynomials](https://arxiv.org/pdf/quant-ph/9802049): inspected the polynomial representation and symmetrization setup. Output probabilities have multilinear degree at most twice the oracle query count; exact parity needs N/2 queries. The paper explicitly distinguishes black-box lower bounds from circuit-description lower bounds.
4. [Bennett, Bernstein, Brassard and Vazirani, Strengths and Weaknesses of Quantum Computing](https://arxiv.org/abs/quant-ph/9701001): primary source for the unstructured-search lower bound used below.
5. [Yoder, Low and Chuang, Fixed-Point Quantum Search with an Optimal Number of Queries](https://arxiv.org/abs/1409.3305): a known success lower bound supports controlled nonzero error, rather than a finite-cost universal zero-error guarantee.
6. [Guţoiu, Tănăsescu and Popescu, Simple Exact Quantum Search, 2024](https://link.springer.com/article/10.1007/s11128-024-04548-x): inspected its input model and initial-state formulas. The number of solutions M is explicitly given; the modification depends on M/N. Its exact-search headline does not eliminate the counting service.
7. [Mosca and Zalka, Exact Quantum Fourier Transforms and Discrete Logarithm Algorithms](https://aqis-conf.org/archives/eqis03/program/papers/O08-Mosca.pdf): the inspected uniformization mechanism averages success probabilities over shifts and makes the probability independent of the unknown eigenlabel. This is a genuine older mechanism to test for structured mass acquisition; obtaining an exactly implementable average and all gate costs remains necessary.

Historical novelty of the two deductions below is UNKNOWN. Their ingredients are elementary and established; I would present them as audit lemmas unless a focused prior-art check establishes more.

## 1. Exact mass can be #P-hard despite a trivial unique output

**Internal derivation; unconditional reduction, not an unconditional time lower bound in the circuit-description model.**

Given a Boolean circuit C on m bits, prepare a fair bit b and a uniform m-bit string r using m+1 uncontrolled Hadamards. Reversibly evaluate C(r). Output the unique accepted word `0^W` exactly when `b=0` or `C(r)=1`; otherwise output `10^(W-1)`. Retain all seed, branch and calculation registers. The verifier accepts exactly `0^W` and costs O(W), with W=m+1 if desired. Then

\[
p_C=\frac12+\frac{\#\mathrm{SAT}(C)}{2^{m+1}}
    =\frac{2^m+\#\mathrm{SAT}(C)}{2^{m+1}}.
\]

The circuit and its inverse have size polynomial in |C|+m, success is at least one half, and the actual dyadic denominator exponent is publicly m+1. The exact numerator has only O(m) bits. Nevertheless a uniform classical polynomial-time decoder for p_C, even when supplied the already verified word `0^W`, would compute #SAT(C) in polynomial time. Thus this decoder is #P-hard to acquire; a generic polynomial algorithm for it would imply FP=#P.

This example **does not** prove that producing an exact correct output is hard: the output here is trivial and can be printed directly. It isolates the extra cost of the mass service without conflating it with output difficulty.

There is also an unconditional oracle version. Replace C by an unknown truth table z on N=2^m entries. Any exact quantum algorithm computing p_z computes |z| and therefore parity. The parity probability's unique multilinear polynomial has degree N, while a q-query output probability has degree at most 2q. Hence q>=N/2. Verification still has a constant trivial output and success remains at least one half. O(log N) probability bits can therefore cost Omega(N) oracle queries to acquire.

**Fatal test for a proposed learning/inference transfer:** specify and implement the exact decoder, including its information source. “The successful output is efficiently verified,” “the denominator is short,” or “we estimated p accurately” is insufficient. The counterexample passes all three corresponding easy checks except exact decoding.

## 2. Unique verified output does not rescue generic worst-case exactification

**Internal theorem in an explicitly oracle-relative model.** This addresses actual output production, rather than only the mass calculation in section 1.

Let N=2^m be even and let y be one unknown nonzero label among M possibilities. An unknown subset S of [N] satisfies |S|>=N/2. Supply two reversible oracles:

\[
F_{S,y}:|i,w\rangle\mapsto|i,w\oplus y\,1_S(i)\rangle,
\]
\[
V_y:|w,c\rangle\mapsto|w,c\oplus 1_{w=y}\rangle.
\]

Here `y 1_S(i)` means the word y when i belongs to S and the all-zero word otherwise. V_y recognizes exactly one correct word. The preparation A applies H to the m seed bits and then queries F once, retaining the seed. It produces y with dyadic probability p=|S|/N>=1/2, with known denominator exponent m. A inverse is supplied by reversing these operations. All nonoracle gates can be Hadamard and reversible classical gates.

**Claim.** Any procedure that outputs y with probability exactly one on every admitted (S,y), with fixed worst-case query bounds q_F and q_V, satisfies

\[
q_F\ge N/4\quad\text{or}\quad q_V=\Omega(\sqrt M).
\]

More precisely, the polynomial argument gives `2 q_F >= N/2+1` unless the verifier-search lower bound applies. Thus total cost is Omega(min{N,sqrt M}).

**Proof.** Fix y and regard membership bits z_i=1_S(i) as Boolean variables. Each F-oracle matrix entry is affine in z_i: on seed i it is `(1-z_i) I + z_i X_y`. The probability of any output event after q_F calls is therefore a real multilinear polynomial of degree at most 2q_F. Calls to V_y and arbitrary interleaved operations do not increase its degree in z. Let e_y(z) be the probability of failing to output y. Symmetrize over all z of Hamming weight t. The result E_y(t) is a univariate polynomial of degree at most 2q_F; explicitly, averaging a monomial of degree k gives `(t)_k/(N)_k`.

Exactness gives E_y(t)=0 at each integer t=N/2,...,N: N/2+1 distinct roots. If `2q_F<N/2+1`, E_y is identically zero, including at t=0. This holds for every y. At t=0 all F oracles are the identity and supply no information about y. The same procedure must then find the unique marked label y using only q_V calls to V_y. The unstructured unique-search lower bound gives q_V=Omega(sqrt M). This proves the claim. Intermediate measurements or classical randomization can be deferred or included in the polynomial probability argument; the fixed worst-case resource cap is essential. □

Choosing M=N^2 makes the exact worst-case lower bound Omega(N), exponential in m. In contrast, preparation, measurement and verification followed by restart have at most two trials in expectation. Each trial uses one F query and one V query, so expected query cost is at most four. This is a separation between bounded worst-case exactness and Las Vegas expected time, not between correctness and error.

**Supplied/acquired boundary.** N, M, the denominator exponent, coherent A/A inverse and the verifier oracle are supplied. y, S, |S| and the exact mass are acquired. This is not a lower bound against exploiting a succinct classical description of F or V, and is not an ordinary BQP-versus-EQP separation. It is a decisive obstruction to a universal black-box compiler omitting N16's mass decoder. It even allows the procedure more oracle access than merely receiving samples.

**Next audit:** independently check the probability-polynomial argument and root count, then search prior exact/zero-error query-complexity literature for this hidden-label formulation. The generic inference “unique verification plus p>=1/2 implies cheap exactification” is already refuted at this interface, regardless of novelty.

## 3. Positive extension: uniqueness can be replaced by a coprime auxiliary mass

**Internal proof; removes one interface restriction but retains the hard mass service.**

Suppose A and B are supplied coherent preparations whose selected outputs can be verified by the same polynomial-time verifier. Every flagged output is valid, but there may be many valid outputs. Their verified success masses have a public common dyadic denominator

\[
p=a/2^D\ge1/2,\qquad q=b/2^D>0,
\]

where D is polynomially bounded. A total decoder on **every valid output** returns the same true pair (a,b) in polynomial time. It need not be correct on invalid outputs, but its resource cap is fixed there as well. Assume `gcd(a,b)` is a power of two. Then a polynomial-size finite-gate circuit outputs a valid word with certainty.

To see this, put d=gcd(a,b), r=D+1 and T=2^(D+r-1). Let a'=a/d and b'=b/d. Since d is a power of two it divides T. The Euclidean algorithm computes an inverse of a' modulo b' (with residue zero when b'=1). Choose k to be the largest nonnegative integer at most floor(T/a) satisfying

\[
a'k\equiv T/d\pmod{b'},
\]

and set ell=(T-ak)/b. These values exist: floor(T/a)>=2^D>=b'. Also

\[
0\le k\le 2^r,\qquad 0\le\ell<a/d\le2^D\le2^r.
\]

For the bound on ell, the maximality of k gives `T-ak < a b'`. The probability identity is

\[
\frac12\frac a{2^D}\frac k{2^r}
+\frac12\frac b{2^D}\frac\ell{2^r}
=\frac{ak+b\ell}{2^{D+r+1}}=\frac14.
\]

Prepare both A and B unconditionally, retain both outputs/work registers, select one using a fair branch bit, verify it, and run the decoder and appropriate dyadic threshold coin only in the success logic. All arithmetic has O(D) bits, Euclidean algorithm/division/comparisons have polynomial bit cost, and each threshold coin needs r Hadamards. Invalid outputs are unflagged. A total fixed resource cap allows the decoder to be made reversible coherently. No controlled-A assumption or repeated rejection is needed.

Let U be the resulting retained preparation, psi=U|0>, and g=Pi psi. Since ||g||^2=1/4,

\[
(2|\psi\rangle\langle\psi|-I)(I-2\Pi)\psi=2g.
\]

This uses two forward U preparations and one U inverse. Each flagged output is valid, so the final measured output is valid with probability one. All retained registers participate in the zero-state reflection.

For this **specific two-branch independent dyadic-thinning architecture**, an odd divisor of gcd(a,b) is a genuine obstruction: after clearing all powers-of-two denominators, the left numerator remains divisible by that odd divisor whereas the target numerator is a power of two. This is not an impossibility theorem for arbitrary quantum exactification.

One application replaces N16's unique uniform guess by a uniform W-bit guess accepted on K words. If a decoder supplies the exact K as well as p, use common D>=W and b=K 2^(D-W). In particular K a power of two makes the gcd condition automatic. Non-power-of-two K can also work when the odd parts of the two numerators are coprime. This broadens the interface but does not acquire K or p; generic exact K is another counting obligation.

Diagnostics: `work/scouts/logic_algorithms_checks.py` checks all D=1,...,8, `2^(D-1)<=a<=2^D`, `1<=b<=2^D` satisfying the power-of-two gcd condition. All 36,001 admissible pairs passed; 8,199 odd-gcd pairs were excluded. Exact fractions checked every coefficient bound and the quarter-mass identity. Results: `work/scouts/logic_algorithms_check_results.json`. The proof establishes the all-width assertion; the finite check does not establish novelty, acquired mass services or a physical runtime.

## 4. Ranked next targets and decision

1. **Structured output-conditioned mass acquisition.** Highest upside, presently OPEN. Look for a concrete sampler whose successfully verified output reveals a group order, orbit count, exact cardinality, or tractable factorization of its accepted path count. Mosca–Zalka style uniformization is a serious prior mechanism. Require an explicit decoder, exact gate denominator, full bit cost, and comparison against direct solution acquisition with the same information. Fatal test: a hidden #SAT numerator or an unknown partition function enters the decoder. Expected value is medium only with a named concrete application; a generic theorem is blocked by sections 1–2.
2. **Many-output coprime completion.** Completed positive internal lemma in section 3. Confidence high; likely historical novelty low or unknown. Useful if an existing application has known K or another auxiliary mass and fails only N16's uniqueness requirement. Fatal test: the auxiliary count is supplied without charge, or decoder outputs vary across verified words. Expected value low to medium until such an application is identified.
3. **Rate-free existence/finite-certificate search.** Low priority for this wave. The repository's unique Diophantine-witness barrier already shows that uniqueness does not impose a recursive coordinate bound for a nonrecursive RE set. Conversely, effective two-sided semidecision certificates can make a real computable without supplying a convergence rate: enumerate valid rational brackets until their width is below the requested tolerance. This is established computable-analysis logic, not a new precision-time theorem. Any claimed polynomial consequence needs a certificate size/search bound. I did not read the full family-235 threshold proof and do not adopt it.

No generic bottleneck-removing positive theorem survived. The new scoped positive result removes uniqueness under explicit exact-count/coprimality premises; the more consequential result is a proof-level reason to stop treating verification alone as a mass-acquisition or bounded-time exactness service. The strongest next technical question is: **which nontrivial natural task has a genuinely cheap output-conditioned exact mass decoder, while an equally informed direct solver still lacks a cheap exact procedure?**
