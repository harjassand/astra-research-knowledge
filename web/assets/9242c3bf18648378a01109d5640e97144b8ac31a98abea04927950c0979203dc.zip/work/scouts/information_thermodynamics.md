# Information theory / thermodynamics scout — 7 October 2026

**Best candidate:** an exact regularization theorem for a positive overlap operator under a noncommuting expected input cost, and an operational separation between entangled and all separable encoders for a qutrit measurement channel. The elementary smoothing mechanism is closely related to established smooth min-divergence AEP results; novelty is therefore in the exact cost formula, comparator, explicit finite witness, and coding application, if those are not already known. No priority or external verification claim is made.

## Source/interface audit

Read `work/astra-research-knowledge/00_START_HERE.txt`, `01_CORE.txt`, `cards/P-q-noise.txt`, `cards/P-q-excitation.txt`, and `cards/N15-flux-entropy-obstructions.txt`. The pure-reference excitation card assumes unit cost on the whole excited subspace and explicitly excludes unequal excitation energies. Its finite-error converse is useful below. The GAD capacity card relies on the extraordinary OA276 population-sensitive entropy lemma; no result below relies on it. N15's conditional photon-number counterexample is consistent with the already established sharp conditional qEPI, so that counterexample is not the strongest available structural observation.

Primary literature refreshed:

- [Ding–Pavlichin–Wilde, Quantum Channel Capacities Per Unit Cost](https://arxiv.org/html/1705.08878), especially zero-cost-state PPM and blocklength-cost duality. This is an information/cost capacity theorem, not the error/cost exponent below.
- [Jarzyna, Classical capacity per unit cost for quantum channels](https://arxiv.org/html/1704.06696). Ordinary capacity/cost uses a forward output relative entropy; it is infinite when the zero-cost output is pure and an active output leaves its support.
- [Datta, Min- and Max- Relative Entropies](https://arxiv.org/abs/0803.2770), and [Nuradha–Wilde, Fidelity-Based Smooth Min-Relative Entropy](https://arxiv.org/html/2305.05859). Strong novelty downgrader: smoothing the pure-state overlap divergence to the Umegaki divergence is established. The typical projection below is a direct elementary instance of this mechanism.
- [De Palma–Trevisan, The conditional Entropy Power Inequality](https://arxiv.org/html/1706.00440), Theorems 6.1 and 7.1 and their proofs. The exact sharp conditional entropy scale is already determined.
- [Cheng–Berta, Superadditivity for Entanglement-Assisted Communication, July 2026](https://arxiv.org/abs/2607.15151). Relevant warning that capacity additivity does not imply reliability additivity. Their stated EA setting and correlated separable input marginals differ from the unassisted, all-separable comparator here; its full proof still needs a precise comparison.
- [Pirandola, Energy-constrained two-way pure-loss capacities, 5 October 2026](https://arxiv.org/html/2610.06832v1), and [Havas–Lin–Rosnes, Spectrum-Based Converse for Quantum State Discrimination, 5 October 2026](https://arxiv.org/html/2610.06840v1). These are very recent primary preprints. I inspected the interfaces and selected proof passages, not complete proofs. The first concerns adaptive two-way entanglement/private tasks and unconditional mean photon constraints; it does not directly settle this finite-message unassisted problem. The second treats output spectra and includes amplitude-damping binary codes; it does not visibly contain the noncommuting-cost theorem below.

## Target 1: exact overlap exponent with noncommuting cost

### Legal interface

Finite-dimensional input space, supplied Hermitian operators

\[
H\geq0,\quad \ker H=\operatorname{span}\{|0\rangle\},\qquad
0<E\leq I,\quad E|0\rangle=|0\rangle.
\]

The active block is the orthogonal complement of the zero-cost ray. Put

\[
L=-\log E,\quad H_m=\sum_{j=1}^mH_j,\quad L_m=\sum_{j=1}^mL_j,
\quad
\alpha=\lambda_{\max}(H_+^{-1/2}L_+H_+^{-1/2}).
\]

Assume \(\alpha>0\). Costs are expected input costs \(\operatorname{Tr}H_m\tau\); the number of cells is unrestricted but finite for every code. All correlated/entangled input registers pass through the channel. No noiseless retained register, receiver entanglement, or feedback is supplied. This is not a hard spectral energy cutoff.

### Internally proved operator theorem

\[
\boxed{\sup_{m\geq1,\,\tau:\operatorname{Tr}H_m\tau>0}
\frac{-\log\operatorname{Tr}(E^{\otimes m}\tau)}{
\operatorname{Tr}H_m\tau}=\alpha.}
\]

The supremum includes arbitrary mixed entangled states. Under the restriction that \(\tau\) is separable across cells, the exact answer is instead

\[
\boxed{\beta=\max_{\|w\|=1,\,w\perp0}
\frac{-\log\langle w|E|w\rangle}{\langle w|H|w\rangle}.}
\]

**Converse.** Since \(L\leq\alpha H\), ordinary scalar Jensen in an eigenbasis of \(L_m\) gives

\[
\operatorname{Tr}(E^{\otimes m}\tau)
=\operatorname{Tr}(e^{-L_m}\tau)
\geq e^{-\operatorname{Tr}L_m\tau}
\geq e^{-\alpha\operatorname{Tr}H_m\tau}.
\]

No operator monotonicity of the exponential is invoked. For one-cell pure states, vacuum admixture cannot improve the ratio: if the active weight is \(t\), then \(-\log(1-t+tb)\leq t(-\log b)\), while the cost is \(th\). Refining mixed states into pure states and applying convexity of \(-\log\) proves the same one-cell bound for all mixed states. Multiply for product states, then apply Jensen to a separable mixture. This proves the \(\beta\) upper bound for **every separable encoding**, including correlated mixtures and shared randomness. A maximizing one-cell state attains it.

**Achievability.** Let \(w\) maximize the generalized Rayleigh quotient, \(h=\langle H\rangle_w>0\), \(\ell=\langle L\rangle_w=\alpha h\). Let \(R\) be the spectral range of \(L\) on the support of \(w\); take \(R=\|L\|\) if convenient. Define

\[
\Pi_r=\mathbf 1\{|L_r-r\ell|\leq r\delta\},\qquad
|\psi_r\rangle=\frac{\Pi_r|w\rangle^{\otimes r}}
{\|\Pi_r|w\rangle^{\otimes r}\|}.
\]

Measuring \(L\) in \(w^{\otimes r}\) yields iid bounded variables. Hoeffding gives discarded probability

\[
u_r\leq2e^{-2r\delta^2/R^2}.
\]

The pure-state trace distance to \(w^{\otimes r}\) is at most \(\sqrt{u_r}\). Since \(0\leq H_r\leq r\|H\|I\),

\[
q_r:=\langle\psi_r|H_r|\psi_r\rangle
\leq r(h+\|H\|\sqrt{u_r}),\qquad
a_r:=\langle\psi_r|E^{\otimes r}|\psi_r\rangle
\leq e^{-r(\ell-\delta)}.
\]

Choose \(\delta_r=R\sqrt{2\log r/r}\): then \(u_r\leq2r^{-4}\),

\[
q_r\leq rh+\sqrt2\|H\|/r,\qquad
-\log a_r\geq r\ell-R\sqrt{2r\log r}.
\]

Thus the ratio tends to \(\alpha\). The \(R=0\) case is just a repeated eigenstate and needs no projection. The state is a supplied-model construction; this is not a tomography or channel acquisition protocol. Exact spectral projection is a mathematical preparation specification. Finite-precision preparation is a separate charged problem: an additive trace error must be much smaller than the desired exponentially small vacuum probability if it is treated only by contractivity.

### Exact equality/gap criterion

Jensen yields \(\beta\leq\alpha\). Equality holds exactly when a vector that maximizes the generalized Rayleigh quotient is also an eigenvector of \(L\) (and hence of \(H\)). If \([E,H]=0\), equality follows by simultaneous diagonalization. A strict gap requires active dimension at least two, hence input dimension at least three. Noncommutation alone is not sufficient if a different common eigenvector attains the top quotient.

### Channel realization and actual decoding theorem

For any supplied CPTP channel \(\Phi\) with \(\Phi(|0\rangle\langle0|)=|v\rangle\langle v|\), let
\(E=\Phi^*(|v\rangle\langle v|)\). Positivity implies \(E=1\oplus E_+\). When \(E>0\), the preceding theorem applies.

A pulse-position code puts \(\psi_r\) in one of \(N\) blocks and vacuum in all other blocks. It uses exactly \(m=Nr\) cells and maximum per-word expected cost \(q_r\). Local tests \(\{|v\rangle\langle v|,I-|v\rangle\langle v|\}\) have zero false positives. Any click identifies the active block; a uniform guess when all cells are vacuum gives exactly

\[
P_e=(1-1/N)a_r.
\]

For an arbitrary pure-reference channel and arbitrary entangled code, the rank-one reference argument in `P-q-excitation` gives

\[
P_e\geq e^{-\alpha Q}-2\sqrt{(1-e^{-\alpha Q})/N}-1/N.
\]

Consequently the optimal required average or maximum cost obeys
\(Q^*(N,\eta)\sim\log(1/\eta)/\alpha\) when
\(\eta\to0\) and \(\eta\sqrt N\to\infty\). The finite lower bound is
\(Q\geq\alpha^{-1}\log(1/A_N)\),
\(A_N=\eta+2\sqrt{(1-\eta)/N}-1/N\), in the range \(\eta<1-1/N\).
For fixed \(N\), coherent output coding can have a different optimal error exponent; the overlap theorem alone must not be called its optimal decoding reliability.

The following **entanglement-breaking binary measurement channel** removes that caveat:

\[
\Phi_E(\tau)=\operatorname{Tr}(E\tau)|v\rangle\langle v|
+\operatorname{Tr}((I-E)\tau)|c\rangle\langle c|,
\quad \langle v|c\rangle=0.
\]

Every block output is classical. If every codeword has expected cost at most \(Q\), its common all-vacuum atom has probability at least \(e^{-\alpha Q}\). Summing decoding errors on that atom gives the stronger converse

\[
P_e\geq(1-1/N)e^{-\alpha Q},\qquad
P_{e,\mathrm{sep}}\geq(1-1/N)e^{-\beta Q}.
\]

The pulse construction and repeated maximizing separable pulse attain their respective exponents. Hence for **every fixed \(N\geq2\)** under maximum per-word expected input cost,

\[
\lim_{Q\to\infty}-Q^{-1}\log P^*_{e,\mathrm{all}}(Q,N)=\alpha,
\quad
\lim_{Q\to\infty}-Q^{-1}\log P^*_{e,\mathrm{sep}}(Q,N)=\beta.
\]

This proves an actual unassisted decoding advantage even though the channel destroys entanglement. Capacity additivity is not contradicted. Under average rather than maximum per-word cost at fixed \(N\), one free guess label changes the exponent; do not reuse this statement there.

### Explicit two-use witness, exact inequalities

An independent internal audit supplied this particularly short witness; the algebra is recorded here so agreement is not the evidence. Let \(b=\log(8/3)\),

\[
E=1\oplus\operatorname{diag}(1/2,1/4),\qquad
H=0\oplus\begin{pmatrix}b-1/12&-1/4\\-1/4&b+7/12\end{pmatrix}.
\]

The active cost matrix is positive. Every one-cell state has \(-\log\langle E\rangle\leq\langle H\rangle\), and the active state \((|1\rangle+|2\rangle)/\sqrt2\) attains equality, so \(\beta=1\). To verify the global inequality, minimize the cost over the relative phase, let \(t=2|w_2|^2-1\), and write

\[
-\log\langle E\rangle=b-\log(1-t/3),\qquad
\langle H\rangle=b+t/3+(1-\sqrt{1-t^2})/4.
\]

For \(|t|\leq1\), the logarithmic series gives
\(-\log(1-t/3)-t/3\leq t^2/12\), whereas
\((1-\sqrt{1-t^2})/4\geq t^2/8\). This proves the comparator, including mixed and separable block encodings as above.

Take the normalized entangled two-cell state

\[
|\chi\rangle=(4|11\rangle+5|12\rangle+5|21\rangle+4|22\rangle)/\sqrt{82}.
\]

Its coefficient matrix has determinant \(-9/82\neq0\). Direct calculation yields

\[
\langle E\otimes E\rangle_\chi=45/328,\qquad
\langle H_2\rangle_\chi=2b+1/82,
\]

and

\[
-\log(45/328)-(2b+1/82)
=\log(41/40)-1/82>1/82>0.
\]

Repeating this two-cell pulse already gives a strictly better exponent than **every separable code** for \(\Phi_E\). The ratio is about 1.00633; the full regularized optimum is about 1.06013. Those decimals are illustrative, not used in the proof. For \(N\) messages and \(r\) repeated copies, cells are \(2Nr\), maximum word cost is \(r(2b+1/82)\), and error is exactly \((1-1/N)(45/328)^r\).

### Parametric unbounded advantage (root-supplied extension, direct proof)

Let \(M\geq1\), \(\zeta=M^{-2}\), and

\[
E_+=\operatorname{diag}(1,e^{-M}),\qquad
H_+=\begin{pmatrix}a&d\\d&a\end{pmatrix},
\quad a=(1+\zeta)/2,\ d=(1-\zeta)/2.
\]

The cost eigenvalues are \(\zeta,1\). Here
\(\alpha=M(1+\zeta)/(2\zeta)\).
For lossy population \(s\), phase minimization gives
\(h=a-(1-\zeta)\sqrt{s(1-s)}\).
If \(s\leq3/4\), then \(-\log(1-s+se^{-M})\leq\log4\) and \(h\geq\zeta\).
If \(s>3/4\), then the numerator is at most \(M\) and
\(h\geq c_0=(2-\sqrt3)/4\).
Therefore

\[
\beta\leq\max(M^2\log4,M/c_0),\quad
\frac\alpha\beta\geq\frac{M}{2\log4}
\quad\text{when }M\geq(c_0\log4)^{-1}.
\]

The ratio is unbounded, but the family has a diverging cost condition number. Rescaling \(H\) by \(1/\zeta\) fixes its minimum active eigenvalue at one and changes the largest to \(M^2\); the ratio remains unchanged. This is not an advantage uniform over a bounded energy spectrum or a fixed engineering interface.

**Sharp condition-number order.** There is also a universal restriction
\[
\frac\alpha\beta\leq\kappa(H_+)=h_{\max}/h_{\min}.
\]
Indeed \(\alpha\leq\|L\|/h_{\min}\), whereas an eigenvector of \(L\) at \(\|L\|\) gives \(\beta\geq\|L\|/h_{\max}\). This dependence is attained within a universal constant: change the preceding family to \(M=K\), \(\zeta=1/K\). Then
\[
\alpha=K(K+1)/2,\qquad
\beta\leq K/c_0,\qquad
\alpha/\beta\geq c_0(K+1)/2,
\]
while \(\kappa(H_+)=K\). Thus the worst possible multiplicative gap is \(\Theta(\kappa(H_+))\), up to universal constants, in this finite-dimensional expected-cost model. Scaling \(H\) by \(K\) makes its active eigenvalues \(1,K\), the entangled exponent \((K+1)/2\), and the separable exponent at most \(1/c_0\). This version states explicitly which physical spectrum parameter pays for the growing advantage.

### Costs, acquisition, fatal tests

1. **Preparation work and symmetry resources:** the theorem charges final expected input \(H\), not entangling gates, external drives, asymmetry, cooling all \(Nr\) vacuum cells, bath free energy, readout, or latency. At finite temperature, free-energy preparation relative to a Gibbs state generally charges the many pure vacuum cells too; this can remove the appealing total-energy conclusion. Do not call the result a total thermodynamic work advantage.
2. **Time covariance is decisive:** if \(\Phi\) is time-covariant under \(H\) and the pure output reference projector is invariant under output time evolution, then \(E=\Phi^*(P_v)\) commutes with \(H\). Thus \(\alpha=\beta\). Ordinary stationary, energy-covariant damping channels do not exhibit this noncommuting-cost advantage. A driver or differently interpreted cost is necessary.
3. **Hard cost budget:** gentle closeness preserves expectation, not support in a spectral cutoff of \(H_m\). No hard-budget or finite-temperature stationary extension has been established.
4. **Blocklength:** the generic construction uses \(Nr\) cells and a model-dependent spectral filter. The exact two-use witness repeated \(r\) times uses only entanglement within pairs and \(2Nr\) cells; it already proves a finite-block operational gap. Local tests suffice for the receiver.
5. **Calibration and accuracy:** \(H,E,w\) are supplied. Channel tomography, calibration precision and robust spectral certification are not free. At target error \(\eta\), a simple additive channel/preparation error treatment requires accuracy substantially below \(\eta/m\); relative or multiplicative stability may permit a better accounting but is unproved here.
6. **Novelty test:** search must distinguish standard AEP/Stein overlap smoothing, established error exponents, quantum illumination with a retained idler, and EA superadditivity from the unassisted maximum-cost all-separable separation. The broad entanglement-breaking reliability story is not new; the exact formula/separation may or may not be.

**Best next question:** Is the exact unassisted maximum-cost decoding separation (especially the elementary two-use witness and unbounded family) already contained in energy-constrained quantum sphere-packing/reliability literature? If not, can a concrete driven device realize it while the extra work/asymmetry costs are included and equally available to separable controls? The first is a short high-value novelty audit; the second is the load-bearing physical application, not an automatic corollary.

## Target 2: classify admissible conditional entropy transforms

For continuous increasing \(f\), consider a universal beam-splitter law
\(f(S(C|M)/n)\geq\lambda f(S(A|M)/n)+(1-\lambda)f(S(B|M)/n)\)
for finite-energy inputs conditionally independent given quantum memory, at every \(0<\lambda<1\). Put \(F(x)=f(\log x)\).

The conditional qEPI implies this law whenever \(F\) is concave: apply monotonicity of \(f\) to the qEPI, then Jensen to \(F\). Conversely, the explicit Gaussian asymptotic extremizers in De Palma–Trevisan Theorem 7.1 force \(F\) to satisfy Jensen concavity. Thus **concavity of \(f\circ\log\) is necessary and sufficient**. The same statement can be restricted to a positive entropy interval.

For photon-number interpolation \(f=g^{-1}\), \(g(u)=(u+1)\log(u+1)-u\log u\), one has

\[
f''(s)-f'(s)
=\frac{1/[u(u+1)]-[\log(1+1/u)]^2}
{[\log(1+1/u)]^3}>0,\quad u=g^{-1}(s)>0.
\]

The strict sign follows from \(\operatorname{arctanh}x<x/\sqrt{1-x^2}\) with \(x=(2u+1)^{-1}\). Consequently \(F''>0\) on \(x>1\), contradicting the required concavity whenever the two positive input conditional entropies differ. Finite Gaussian violations exist by continuity of the established asymptotic construction. This structurally explains N15 but is a routine consequence of a 2017 sharp theorem; rank below Target 1.

## Target 3: latest capacity/simulation work

The October 2026 sector-simulation preprint is worth a focused audit if the campaign wants energy-constrained adaptive converses. Its sector labels, coherent intersector pinching, and replica argument carry the actual energy accounting. It is not presently a new construction from this scout and is not promoted based on its abstract. Expected value below the completed finite-message theorem unless a specific thermal-loss extension or proof gap is isolated.

## Ranking and status

1. **Operator exponent + explicit unassisted all-separable separation:** internally derived rigorous candidate, strongest reusable result; standard smoothing mechanism, novelty unresolved; physical work advantage unproved and covariance blocks stationary damping.
2. **Conditional entropy-transform classification:** internally derived from a proved older sharp theorem, useful no-go and screening tool, low novelty upside.
3. **Energy-preserving channel simulation:** current primary literature lead, no new technical result here and full audit outstanding.
