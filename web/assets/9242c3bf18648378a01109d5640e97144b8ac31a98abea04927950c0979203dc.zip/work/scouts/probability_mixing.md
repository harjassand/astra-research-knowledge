# Probability and mixing scout — 7 October 2026

**Recommendation:** pursue a uniform normalized-covariance theorem for **two overlapping delocalized negative Ising spikes**, starting from the exact product-tilt identity below. It has an explicit load-bearing missing lemma and a polynomial-time Glauber consequence. A newer ASL–Jarzynski mechanism supplies a separate sampling route through the entire SK replica-symmetric regime; a fixed-strength finite-rank negative-spike extension is already reachable by rejection, but polynomially growing spike strength is blocked by accuracy amplification. Do not spend a depth wave trying to upgrade L07 to entropy without strengthening its premise: that upgrade is false. Two analytic counterexamples are proved below.

Status distinctions: published/preprint theorem statements remain literature, not locally certified theorems. Algebra and the two counterexamples below were independently derived here. The overlapping-spike covariance bound is conjectural. Small enumerations are diagnostics only. No repository source was edited, no external messages were sent, and no subagents were used.

## Source refresh and reading depth

* L07: `work/astra-research-knowledge/cards/L07-additive-replica.txt`; full proof page `web/pages/d-c3ada6f1b85f88c5.html`, original path `literature/notes/metric_acquisition/cycle19/ADDITIVE_PAIR_REPLICATION_LEMMA.md`; gate `web/pages/d-dd74515129edeb69.html`. Full finite-state energy proof read. The last/penultimate ANOVA allocation is valid. It does not acquire a new model's pair comparison or its base sampler.
* Mikulincer–Sohn, **Fast mixing in Ising models with a negative spectral outlier via Gaussian approximation**, [arXiv:2512.22803v2, 7 April 2026](https://arxiv.org/html/2512.22803v2). Sections 1–3 and exact scalar-normal-approximation interface read; the entire iterative Stein proof was not reconstructed. Theorem 9 gives a uniform-in-field covariance/correlation approximation for `exp[-(beta/n)(u·x)^2+h·x]`, `||u||inf<=1`, `beta<=n^(1-epsilon)`. Theorem 1 adds PSD `J`, `||J||op<1/2`, and obtains asymptotic discrete Glauber entropy contraction `(1-o(1))(1-2||J||op)/n`. The authors explicitly identify multiple negative outliers as a further target.
* Caputo–Chen–Parisi, **Factorizations of relative entropy using stochastic localization**, [arXiv:2503.19419v1](https://arxiv.org/html/2503.19419v1), journal [DOI](https://doi.org/10.1016/j.spa.2026.105049). Exact Theorems 2.2, 2.6–2.9 and covariance/localization proof interfaces read. Strong approximate Shearer controls every weighted block cover, independently of graph degree; at tree uniqueness its constant is polynomial in the inverse margin, at criticality the general upper bound is `O(n^(1+2/(Delta-2)))`. Improving this to `O(sqrt n)` is explicitly open. Their tensorization can import arbitrary components, but demands their covariance/Shearer certificates under every external field.
* Gu–Shi–Tian, **Functional Stochastic Localization**, [arXiv:2602.03999v1, 3 February 2026](https://arxiv.org/html/2602.03999v1). Main sampler and Appendix C read. Their functional-Poincare theorem gives chi-square contraction `(1+alpha/tau)^(-2k)` for an exactly implemented non-Euclidean proximal sampler. KL contraction is conditional on Assumption 2; they report numerical failures of that sufficient condition. The exact smooth analytic failure is below.
* Lee–Sandhu–Shi, **Potential Hessian Ascent IV: Sampling the SK model at beta<1**, [arXiv:2609.30590v1, 24 September 2026](https://arxiv.org/html/2609.30590v1). Sections 2, 3.1–3.2, exact Lemma 3.16, algorithm, and terminal sampler interface read; no full proof certification. It upgrades earlier [PHA III, arXiv:2605.03718](https://arxiv.org/abs/2605.03718) using local TAP regularity and Jarzynski path rejection. Its theorem is for fixed `beta<1`, high probability over GOE disorder, polynomial time, and `o_n(1)` TV error; it is not a generic arbitrary-accuracy FPRAS.
* Additional primary breadth: [parallel Ising samplers via localization, 2505.05185](https://arxiv.org/abs/2505.05185); [critical sparse Erdos–Renyi Ising polynomial mixing, 2510.07254](https://arxiv.org/abs/2510.07254); [group averaging of an Ising star, 2609.15023](https://arxiv.org/html/2609.15023v1). These were read at theorem/interface depth or less. Group averaging needs an acquired symmetry and fast quotient dynamics; it does not eliminate symmetry-breaking barriers in arbitrary models. The broad BQD claim [2505.19438](https://arxiv.org/html/2505.19438v1) only proves favorable **late** strong-field posterior mixing; its earliest posterior-mean acquisition remains the sampling problem. No generic BQD sampler follows from that observation.

Local readable extractions: `work/probability_sources/{negative_outlier,entropy,functional,group_star,SK_IV}_read.txt`.

## 1. Original exact obstruction: L07 does not imply uniform entropy contraction

Take any bounded-degree expander family `G_N` on `N` vertices, with its uniform law `mu`. Edge-color with `d+1` colors and let `s_j` swap the endpoints of each edge of color `j`, fixing unmatched vertices. Every `s_j` is an involutive permutation. Let `R=(d+1)^(-1) sum_j s_j`; its Poincare gap `gamma` is bounded below uniformly in `N`. Define the reversible pair update

`K(x,y)=(s_j x,s_j y)` with a shared uniform color `j`.

For every additive observable `a(x)+b(y)`, independence and permutation invariance make the cross term vanish **for each color**:

`E_K(a+b)=E_R(a)+E_R(b)>=gamma Var_mu(a)`.

Thus L07 holds with constant `C=1/gamma`, although the pair kernel preserves equality `x=y` and has zero full gap. Use one tier, fixed `q>=16C`, and the L07 lazy scan with `M=q^2+q`. Its replicated full gap is at least `3/(8M)`, uniformly in `N`.

An upper slot is touched with probability `p=q/(2M)=1/[2(q+1)]`. For the density `f=N 1{x=v}`, one step has entropy

`Ent(Pf)=log N-H(((1-p)I+pR)(v,.))`.

The row has at most `d+1` outcomes, so the discrete entropy contraction constant is at most `log(d+1)/log N`. The loss persists for the continuous-time modified log-Sobolev inequality: choose `a>log d`, `rho(x)=exp[-a dist(v,x)]/Z`, and `f=N rho` depending on the upper slot. The bounded shell growth gives `H(rho)=O_d(1)`, while every allowed move changes `log f` by at most `a`. Therefore

`E_P(f,log f)<=p a`, `Ent(f)=log N-O_d(1)`.

The continuous entropy dissipation constant is also `O(1/log N)`. Hence neither a constant MLSI nor alphabet-independent entropy contraction follows from L07's additive spectral premise. This is a complete analytic counterexample, not a finite test. Its abstract phenomenon is familiar for expanders; its role here is to close this precise replication interface.

## 2. Original exact obstruction: the functional KL sufficient condition fails for a smooth strongly convex potential

Let `g>0` and take the normalized density proportional to

`exp[-phi(y)]`, `phi(y)=y^2/2+g y^4/4`.

Additive normalization constants do not affect convexity. Write `psi(t)=log E exp(tY)` for its log-Laplace transform, and `nu(dt) proportional exp[-psi(t)]dt`. Both `nu` and its second moment are finite: the quartic Laplace asymptotic gives `psi(t)>=c_g |t|^(4/3)` for sufficiently large `|t|`.

Under the `t`-tilted `Y` law, integration by parts gives

`psi'(t)=E_t Y=t-g E_t Y^3`.

For `t>0`, evenness of the untilted density gives `E_t Y^3>0` by pairing positive and negative `y`. Thus `psi'(t)<t` strictly. Consequently the likelihood ratio of `nu` to a standard Gaussian,

`R(t) proportional exp[t^2/2-psi(t)]`,

is strictly increasing in `|t|`. Strict positive covariance of the two increasing functions `R(|G|)` and `G^2` under `G~N(0,1)` implies `Var_nu(T)>1`. But

`(phi-phi^(sharp sharp))''(0)=1-Var_nu(T)<0`.

Appendix C Assumption 2, at `alpha=1`, `V=psi`, requires the left side to be nonnegative. It therefore fails for **every** `g>0`, despite `phi''>=1`, smoothness, and Gaussian-or-faster base tails. This proves failure of the sufficient condition, not failure of KL mixing itself. A replacement with controlled curvature loss or a different entropic argument is required.

## 3. Positive target: overlapping finite-rank negative Ising interactions

Let `A` be a supplied `r x n` real matrix, columns `a_i`, and define

`mu_A,h(x) proportional exp[-||Ax||^2+h·x]`, `x in {+-1}^n`.

Set `eta^2=max_i ||a_i||^2`. For fixed `r`, target the exact inequality

`sup_h ||Cor(mu_A,h)||op <=1+C_(r,epsilon) eta^2 log(2+||A||op^2)^C_(r,epsilon)`

under `eta^2<=n^(-epsilon)`. **This is a conjecture**, extending the cited scalar estimate. The consequent error is `o(1/log n)`, so coordinate localization would give `(1-o(1))/n` Glauber entropy contraction. Adding any supplied PSD interaction `J`, `||J||op<1/2`, would then preserve a rate asymptotic to `(1-2||J||op)/n` by the generic Hubbard–Stratonovich/localization comparison.

### Exact reduction derived here

There is a unique `m in R^r` satisfying

`m=sum_i a_i tanh(h_i-2 a_i^T m)`.

It minimizes the strongly convex function `||m||^2+sum_i log cosh(h_i-2a_i^T m)`; its Hessian is `2I+4 A D A^T` with `D_ii=sech^2(h_i-2a_i^T m)`.

Let independent spins `xi_i` have means `t_i=tanh(h_i-2a_i^T m)`, and `Z=A(xi-t)`. Completing the square gives the **exact** identity

`d mu_A,h / d Law(xi) = exp[-||Z||^2] / E exp[-||Z||^2]`.

The Gaussian replacement predicts

`Sigma_G=D-2D A^T(I+2 A D A^T)^(-1) A D`,

and normalized leading matrix

`I-2 W^T(I+2WW^T)^(-1)W <= I`, `W=A sqrt(D)`.

These algebraic statements are proved. Replacing the tilted Bernoulli moments by Gaussian ones at the precision needed for **normalized correlation**, uniformly under fields that nearly freeze some coordinates or make `ADA^T` degenerate, is not proved. Ordinary multivariate Berry–Esseen is too coarse near the largest spike strengths. The source's iterative scalar Stein argument is the genuinely useful mechanism to generalize.

An easy multi-spike subclass is already reachable: disjoint-support spikes yield a product of rank-one tilted systems. Their uniform covariance bound is the maximum component bound, and single-site entropy factorization tensorizes; adding PSD `J` uses the same generic comparison. This is a direct corollary, with little novelty. The first meaningful new case has two overlapping row directions and at least three non-collinear column directions.

Diagnostic `work/probability_sources/rank_two_probe.py` enumerates 18 systems at `n=12,16`, circle-spaced columns, `eta=.15,.3,.6`, and zero/random/near-pinned fields. It verifies the exact tilt identity to floating-point error and finds normalized Gaussian error divided by `eta^2` between roughly `.34` and `1.97`. These selected finite cases do not establish the conjecture; near-pinned covariances also suffer cancellation. Saved raw results: `rank_two_probe.json`.

**Fatal tests / next question:** first treat rank two with arbitrary external fields and possibly singular two-dimensional covariance. Seek a uniform quadratic-tilted cavity-moment estimate preserving the small marginal-variance factors; abandon any argument that requires a field-independent lower covariance eigenvalue. Compare against equally informed direct Glauber, polarized-walk and rejection samplers. Supplied `A,J,h` and their rational bounds are legal inputs; means, covariance, or partition functions are not supplied oracles. A Glauber update costs `O(r)` using a maintained `Ax`, plus costs for `J` (dense `O(n)` per update or its actual representation).

## Ranked next work

1. **Rank-two normalized covariance theorem:** high scientific value; missing estimate precisely isolated; original complete-square reduction supplies a starting point. Moderate-to-low chance of a full proof in one wave, good chance of a decisive special case or obstruction.
2. **ASL–Jarzynski transfer for finite-rank negative spikes:** newest mechanism and strong sampling consequence, but its surviving-path and rejection accuracy budget must be rebuilt; fixed-strength application below is immediate and incremental. Do not interpret a finite-temperature sampling algorithm as a Glauber mixing theorem.
3. **Functional KL without Assumption 2 / critical Shearer `sqrt n`:** important exact inequalities, but current sufficient-condition route is falsified and the critical covariance bottleneck is substantial. Lower expected value for the first depth wave.

## 4. Exact ASL–Jarzynski interface and reachable application

For transfer, PHA IV section 2.2 requires a computable surrogate with inverse Hessian `Qhat` and true covariance `Q_t`, satisfying along ideal SL paths:

* `E ||Hhat(m_t) Q_t-I||F^2 <= epsilon_cov(t)^2`, bounded for fixed `T`.
* Probability `1-o(1)` that the entire path has an `l2` neighborhood of radius `rho sqrt n` inside the certified safe set.
* On the safe set, `C^-1 D^-1 <=Qhat<=c^-1 D^-1`, `D_ii=(1-m_i^2)^-1`.
* Bounded drift error; Lipschitz `Qhat` in Frobenius norm, correction drift, and JE integrand `(Tr Qhat+||m||^2)/2`.
* An acquired terminal conditional sampler (small Hamming wedges here), and an acquired partition-ratio estimator.

This demands pathwise survival and tail/accuracy control as well as covariance approximation. A positive Hessian at selected points is insufficient. The above is a compact interface extraction; the exact seven rejection conditions are in `SK_IV_read.txt`, Lemma 3.16.

The crucial accounting, read directly from that lemma, is

`L=exp[(3/epsilon)(1+(1/2) integral_0^T drift_error(t)^2 dt)]`,

with simulation count

`O(C1^2 L^2 log(1/epsilon)/c3^2)`

and final TV error

`6epsilon + delta + delta' +768(C1 L/c3)^2 deltahat`.

`C1,c3` control upper/lower log-weight tails; `delta,delta',deltahat` are ideal/auxiliary/algorithmic survival failures. Approximate path, weight, and partition-ratio errors must be of order `epsilon/[384(C1 L/c3)^2]`. Thus merely proving `O(1)` path KL is insufficient for arbitrary prescribed accuracy with polynomial `1/epsilon` cost. The paper obtains some `epsilon_n->0` slowly enough to retain polynomial cost and suppress amplified failures. Its theorem does not provide a polynomially tiny error oracle for free.

### Reachable theorem: fixed bounded-trace negative perturbations throughout SK replica symmetry

This is an independent corollary **conditional on the literature's PHA IV sampler theorem**, not a new proof of that theorem.

Let `G~GOE(n)`, fixed `0<beta<1`, and let `M_n>=0` be deterministic, independent of `G`, with supplied representation and `Tr M_n<=B`, where `B` is fixed in `n`. Define

`nu_G,M(x) proportional exp[(beta/2)x^T G x-x^T M_n x]`.

For every fixed `delta>0`, with probability at least `1-2delta` over `G` (and sufficiently large `n`), rejection from the PHA IV sampler with acceptance `exp[-x^T M_n x]` produces `o_n(1)` TV error in polynomial time in `n`. The expected number of baseline calls is at most `2 exp(B/delta)` eventually. This covers fixed-rank spikes of arbitrary fixed strengths and arbitrary deterministic directions, including overlapping directions; it does not establish Glauber mixing.

**Proof.** Gauge invariance of GOE gives exactly

`E_G E_muG[XX^T]=I`.

For `i!=j`, conjugating `G` by the diagonal sign flip at coordinate `i` reverses `E_muG XiXj`, while preserving the disorder law; diagonal entries are one. Therefore

`E_G E_muG[X^T M_n X]=Tr M_n<=B`.

Markov's inequality yields an event of probability at least `1-delta` on which this conditional mean is at most `B/delta`. Jensen then gives the **ideal acceptance lower bound**

`alpha_G=E_muG exp[-X^T M_n X]>=exp(-B/delta)`.

If the baseline law has TV error `e_n`, bounded-weight tilting has TV error at most `2e_n/(alpha_G-e_n)` whenever `e_n<alpha_G`. Its acceptance probability is at least `alpha_G-e_n`. Since the acceptance floor is constant in `n`, the imported `e_n=o(1)` remains `o(1)`. Combine this disorder event with the baseline's `1-delta` event. Finite-bit acceptance error and each baseline-call cost must still be charged.

**Value and limits.** This is an immediately reachable sampling extension beyond the generic spectral-width regime, but rejection/tensorization novelty is low. Runtime is exponential in `B/delta`; a large fixed constant can be practically prohibitive. If `B=B_n` grows, the same calculation only supplies `alpha>=exp(-B_n/delta)` and the necessary requirement `e_n exp(B_n/delta)->0`. PHA IV's asymptotic error statement alone does not verify this.

A stronger random-spike normalization route has an exact useful identity. For independent Gaussian rows of `U` with covariance `(lambda/n)I`, and any base law on spins, let `Z_U=E_mu exp[-||UX||^2]`, `R=X·Y/n` for independent base replicas. Then

`E_U Z_U=(1+2lambda)^(-r/2)`,

`E_U Z_U^2=(1+2lambda)^(-r) E_mu⊗mu[(1-tau^2 R^2)^(-r/2)]`,

`tau=2lambda/(1+2lambda)`.

Both formulas follow by two-dimensional Gaussian integration for each row. With acquired strong replica-overlap tails, they could certify polynomial acceptance even for polynomial spike strength. **Remaining gate:** the existing baseline sampler's approximation error must be smaller than this acceptance mass, or the JE rejection analysis must absorb the tilt while preserving its own tail/survival bounds. The normalization identity does not acquire either guarantee.

### Consequence for ranking

The fully reachable fixed-trace theorem is less novel than the rank-two Glauber target. For a depth wave, use PHA IV as a competent comparator and possible alternative, while focusing proof effort on the uniform normalized rank-two quadratic-tilt inequality. The quantum transverse-field outlier extension is more speculative: [Vuong, 2610.02079, 1 October 2026](https://arxiv.org/abs/2610.02079) supplies a fresh spectral-width sampling threshold, but noncommuting Gibbs reweighting cannot be implemented by the classical bounded-weight rejection argument above. Only metadata/abstract of that paper were read here.
