# Noncommutative realization and acquisition scout

7 October 2026. Scope: weighted word automata / proper rational series, black-box noncommutative identity testing, and partially observed bilinear identification. Source status is preserved: L01 is an internally reconstructed candidate, not an externally certified theorem. No source repository files were changed.

**Decision.** A new general realization claim is not justified. Exact Hankel realization and randomized output-only reconstruction are old. L01's useful distinction is deterministic universal probing with explicit dimensions. I reconstructed and executed a substantially smaller randomized comparator, and proved an adaptive noisy-probe lower bound that identifies a genuine acquisition obstruction even for 0/1, perfectly realizable systems. The noisy bound has an important excitation restriction; it is not a general HMM or bounded-norm impossibility theorem.

## 1. Exact source and prior-art audit

Read these exact source pages after `00_START_HERE.txt` and `01_CORE.txt`:

- `work/astra-research-knowledge/cards/L01-cyclic-grid.txt`.
- `work/astra-research-knowledge/web/pages/d-5ead2192abc32c99.html`, original path `literature/notes/frontier_crossfield/cycle19/CYCLIC_GRID_ACQUISITION_ADDENDUM.md`.
- `work/astra-research-knowledge/web/pages/d-48c2ee67f4f77da6.html`, original path `literature/notes/frontier_crossfield/cycle19/RELEASE116_TRUNCATION_BASELINE_CORRECTION.md`.
- `work/astra-research-knowledge/web/pages/d-daae0ce9b7b6e2ee.html`, original path `literature/notes/root_cycle19/CYCLIC_SCALAR_GRID_HITTING.md`.
- `work/astra-research-knowledge/web/pages/d-7a16721d57edc620.html`, original path `updates/L/package/work/acquisition_attack.md`.

L01 grants known alphabet size n and a valid hidden realization bound m, and an exact oracle returning **all entries** of f(X) for rational jointly nilpotent tuples. It does not grant passive target samples, noisy time-domain experiments, a syntactic inverse-gate domain extension, or a positive minimal model. Its residual construction is sound once its detector is sound: all residual combinations share the original transitions, so m, rather than 2m, is the right detector bound. The Volterra proof's load-bearing imported ingredient is finite-word hyperlogarithm faithfulness. I checked the subsequent covariant-row, numerator-degree, scalar-grid and Cauchy-moment logic from the full supplied note, but did not independently certify the release116 prerequisite or its historical priority.

The source's own correction is decisive: bounded-length unrolling and a nilpotent length marker already turn the released acyclic detector into a polynomial deterministic cyclic detector at O(n m^5) dimension. L01 is therefore a compactness / accounting improvement within that strong oracle interface, not first polynomial cyclic learnability.

The relevant primary literature is as follows; inspection depths are explicit.

| Primary source | What was inspected and what it actually supplies |
|---|---|
| [Beimel et al., JACM 2000](https://doi.org/10.1145/337244.337257), [author publication record](https://cris.bgu.ac.il/en/publications/learning-functions-represented-as-multiplicity-automata-3/) | The old exact-learning interface is membership **and equivalence** queries. The rank/minimal-state relation and residual construction are prior. The author's old manuscript link was unavailable; I do not count its original proof as newly reread. |
| [Bisht, Bshouty, Mazzawi, COLT 2006](https://doi.org/10.1007/11776420_16) | Publisher theorem-description/metadata only: optimizes membership, equivalence and field-operation charges. Not an oracle-acquisition or numerical guarantee. |
| [Arvind, Mukhopadhyay, Srinivasan, 2008 manuscript](https://arxiv.org/pdf/0801.0514) | Section 3, Corollary 3.2 and Theorem 3.5: matrix evaluation extracts a selected coefficient; that version's deterministic ABP reconstruction also reads **intermediate gates**. It must not be cited as output-only reconstruction. |
| [Arvind, author column, Section 5 / Theorem 5.1](https://www.imsc.res.in/~arvind/columns/column104.pdf) | Read the proof on PDF pp. 10–12. It explicitly derives randomized output-only ABP reconstruction by simulating coefficient and equivalence/counterexample queries. Reference [6] points to the 2010 journal version of the 2008 work. Thus polynomial randomized output-only capability predates L01. |
| [Forbes–Shpilka](https://www.cs.tau.ac.il/~shpilka/publications/ForbesShpilka12.pdf) | Primary abstract/main construction description inspected: deterministic quasipolynomial hitting for noncommutative ABPs; not a stable noisy learner. |
| [Arvind–Chatterjee–Mukhopadhyay, current paper](https://arxiv.org/html/2309.15647v4), [June 2026 journal publication](https://epubs.siam.org/doi/10.1137/24M1689508) | Theorem 2, Corollary 3, Fact 1, and Section 5.1 inspected. Quasipolynomial deterministic rational-formula hitting; division-algebra evaluation handles inverse domains. This is broader syntactic rational access than L01's proper-series nilpotent access. The source also documents prior randomized polynomial black-box RIT. |
| [Petreczky 2011](https://www.numdam.org/item/10.1051/cocv/2010015.pdf) | Theorem 2.6 / displayed realization section inspected; PDF downloaded to `work/noncommutative_sources/petreczky2011.pdf`. Finite Hankel rank is the old realization criterion, not a cheap way to acquire coefficients. |
| [Balle–Mohri 2012](https://cs.nyu.edu/~mohri/pub/swa.pdf) | Section 3.2 spectral equations, Section 4 and Lemma 4 inspected. Singular values and spectral gaps enter perturbation bounds; matrix completion does not make an unknown good basis free. |
| [Sattar–Jedra–Fazel–Dean 2025](https://arxiv.org/html/2501.07652v1) | Sections 2.2, 3, Proposition 2 and Section 6 inspected. Partially observed identification uses input-dependent uniform stability and history features with exponential length dependence. Its stated open direction is carefully designed inputs that avoid that expansion. |
| [Chatzikiriakos et al., 2026 publication / current manuscript](https://arxiv.org/html/2409.18010v3), [publication](https://doi.org/10.1016/j.automatica.2026.112908) | Equations (1)–(4), Assumption 2, Theorems 8–9 inspected. Its efficient controlled regression receives full state pairs x,x+, with independent excited starts. It does not solve the partially observed output-only bottleneck. |

No source above was fully audited. Recent search results were checked against their actual interfaces, rather than counted as equivalent learning theorems.

## 2. Reconstructed randomized exact comparator, with proof and execution

**Claim R (internal derivation of an old-style randomized mechanism; no novelty claim).** Over a characteristic-zero field, a proper series with hidden state bound m and true residual rank r≤m can be learned from the same exact full-output oracle with probability at least 1−δ using

\[
Q\le m(1+n r),\qquad D_{\max}\le m+r\le2m,
\]

feature length m², and nominal full-response payload at most

\[
m(1+nr)(m+r)^2=O(nm^4).
\]

The statement is for each fixed target. It is not a deterministic universal hitting family chosen independently of every possible target.

**Probe construction.** Choose m independent upper-bidiagonal tuples X^(j) of dimension m. Each edge X_i^(j)[t,t+1] is an independent integer from a set S with

\[
|S|\ge \max(2,m(m-1)/\delta).
\]

For any residual g, concatenate the m first rows g(X^(j))[0,0:m] into Φ(g). These queries are jointly strictly triangular, so their legality needs no convergence promise.

**Injectivity proof.** Let V be the true r-dimensional residual space. The span of B_s v for |s|<m contains every observable suffix direction: once a word-span equality occurs it is invariant under every B_i, and its dimension cannot strictly increase m times. Consequently there exist r suffix words s_1,...,s_r of lengths <m and a basis g_1,...,g_r of V with invertible H[a,b]=g_a(s_b).

Select from probe j=b the output column |s_b|. The corresponding r×r feature minor is a polynomial in the random edges, of total degree at most Σ_b |s_b|≤r(m−1). This polynomial is nonzero: set the edges of probe b to select exactly the letters of s_b, obtaining the invertible H. Schwartz–Zippel therefore bounds failure by r(m−1)/|S|≤δ. On the complementary event Φ is injective on **all of V**, including adaptively chosen residual combinations; no adaptive union bound is needed.

**Acquisition.** Breadth-first add a prefix p only when Φ(f_p) is outside the current span, then inspect its n children. There are at most r accepted prefixes and 1+nr inspected prefixes. A length-k prefix is extracted by prepending k unit letter edges to a suffix probe. The source-to-suffix first-row block is exactly f_p(X^(j)), and its dimension is m+k. Accepted prefixes have length at most r−1 and inspected children length at most r. Span coordinates give transition rows, and the suffix diagonal gives each residual's constant coefficient. Φ-injectivity makes these the true residual relations, hence the realization is minimal and correct at **every word length**.

Simple dense coordinate processing costs O(n r³ m²) field operations. Returned matrix entries, query descriptions, response heights and actual oracle execution are additional charges. Exact rational processing is polynomial in total encoded input/response length; no bound in m alone covers arbitrary hidden heights. The implemented Monte Carlo learner does not have a legal exact all-word certificate when its random bank fails.

**Conditional Las Vegas repair using L01.** After learning h of rank r'≤m, compare f−h using L01 at the unrelated-comparison bound m+r'≤2m. At most m+r' additional full-output calls, each of dimension 2n(m+r')≤4nm, certify equality; h(X) is evaluated locally. Restart the small random learner if rejected. Each attempt succeeds with probability at least 1−δ, so expected attempts are at most 1/(1−δ). This gives universal exact output with expected polynomial work **conditional on L01's detector being correct**. The small-probe learner's payload is O(nm^4), and verification adds O(n²m³). This composition was derived here but not executed with the actual detector; historical priority is unchecked. It is not a deterministic algorithm.

**Executed evidence.** `work/noncommutative_learning_check.py` and `.json` use only the Python standard library. The learner sees only n,m and the callable matrix-output oracle; hidden models are consulted afterward for an independent reachable-space all-word equality certificate and exact reachable/observable Hankel-rank certificate. PASS: eight fixtures × three seeds = 24 checks, including delayed coefficients, generic cycles, hidden unreachable modes, nonzero representations of the zero series, positive stochastic input, R=AB−B(I+A)^−1A(I+B), and rev(R).

For either five-state rank-four alias, seed 0 used 45 calls, maximum dimension 8, and 2,105 returned entries. The source's L01 full-width fixture reports 45 calls / dimension 80 / 154,000 entries, and its batched fixture reports 205 / 32 / 160,400. This demonstrates a scoped payload comparator on an exactly matched algebraic function; it is not a controlled timing study or proof of historical novelty. All diagnostics together took about 1.05 s here; no cross-run timing advantage is inferred.

## 3. Adaptive noisy acquisition obstruction, with exact excitation boundary

This result does **not** depend on L01 or release116.

**Claim N (internal proof, novelty uncleared).** Fix n≥2, d≥1, E>0, σ>0, and m=d+1. The target is either zero or f_w=x_{w_1}...x_{w_d} for one unknown w∈[n]^d. The latter has minimal rank d+1, a 0/1 acyclic realization with unit boundary vectors, and coefficient norm one. A learner chooses real matrix tuples adaptively, possibly randomly, each of dimension D_j and satisfying

\[
\sum_{i=1}^{n} X_i^* X_i\preceq E I.
\]

It receives every real matrix-output entry with independent Gaussian noise of variance σ². Assume finitely many queries and expected total dimension under the zero target at most C. Any universal zero-versus-nonzero test with both error probabilities at most δ<1/2 must satisfy

\[
\boxed{C\ge 2\sigma^2 (n/E)^d\,
\mathrm{kl}(1-\delta,\delta)},\qquad
\mathrm{kl}(1-\delta,\delta)=(1-2\delta)\log\frac{1-\delta}{\delta}.
\]

Allowing only jointly nilpotent queries, as L01 does, cannot weaken this lower bound. Charging all returned entries is at least as expensive as charging total dimension.

**Proof.** Define A_k=Σ_{|w|=k}X_w*X_w. Then A_0=I and A_{k+1}=Σ_i X_i* A_k X_i≼E^(k+1)I. Hence

\[
\sum_{|w|=d}\|X_w\|_F^2=\operatorname{tr}A_d\le D E^d.
\]

Let P_0 and P_w denote full adaptive transcripts, including the learner's random seed. The Gaussian conditional likelihood and chain rule give, in the direction that exposes only the **zero-target** query history,

\[
\mathrm{KL}(P_0\|P_w)
=\mathbb E_0\sum_j\frac{\|X_w^{(j)}\|_F^2}{2\sigma^2}.
\]

Summing over the n^d words bounds the sum of these divergences by C E^d/(2σ²), despite adaptivity. Data processing through the test decision gives KL(P_0||P_w)≥kl(1−δ,δ) for every w. Rearrangement proves the claim.

For deterministic probes and adversarial Frobenius error at most η per full response, the same energy sum along the all-zero transcript yields the necessary bound C≥η²(n/E)^d: if C is smaller, one word has total response energy below η², and all its responses can be erased. Gaussian Claim N is stronger because it directly covers randomized adaptive strategies and ordinary statistical noise.

**Acquisition rather than existence of good coordinates.** For each hidden word, take all its prefixes p_k=w[1:k] and complementary suffixes s_l=w[l+1:d]. The finite Hankel block H[k,l]=f_w(p_k s_l) is exactly I_(d+1): lengths force k=l, and then the concatenation is w. Thus a perfectly conditioned minimal Hankel basis exists. The obstacle is finding that target-dependent basis under the legal observations. Small hidden size and an existing good basis do not supply cheap discovery.

**Ordinary controlled-system interpretation.** Reset a length-d hidden chain, apply scalar control vectors a_t∈R^n, and observe only its terminal output

\[
y=\prod_{t=1}^d a_{t,w_t}+Z,\quad Z\sim N(0,\sigma^2).
\]

If Σ_i a_(t,i)²≤E, the same argument gives an episode lower bound Ω(σ²(n/E)^d). Earlier scalar outputs are zero. This is a partially observed acyclic bilinear plant, not a supplied matrix table. Even throughout the full box |a_(t,i)|≤1 it is uniformly stable: every transition product of length m vanishes, shorter products have norm at most one, and κ=2, ρ=1−1/(2m) suffice. Thus the E=1 obstruction does not require an unstable plant or exponentially encoded coefficients; its inverse stability gap is only 2m.

**Minimal repair and positive theorem on the same class.** Permit per-time energy E=n with 0/1 control components. Set all components to one, except set component i at time t to zero. The terminal mean is zero exactly when w_t=i, and otherwise one. For each time, testing at most n−1 symbols recovers w. With

\[
R=\max\{1,\lceil8\sigma^2\log(2d(n-1)/\delta)\rceil\}
\]

independent reset repetitions per test, Gaussian tails and a union bound give exact mask/word recovery with probability ≥1−δ using at most d(n−1)R episodes and d²(n−1)R control steps. One additional all-ones test distinguishes the zero target if that target is admitted. The returned chain then evaluates every word exactly. Direct coordinate blocking and thresholding is the competent comparator; calling the same operation adaptive feature learning establishes no advantage.

PASS: nine exact rational matrix energy/recursion checks and 20 Gaussian noisy word-recovery fixtures in the script. The noisy fixtures used n=2,3, d=4,8,16, σ=1 and δ=.01, with 19,794 reset episodes / 268,904 controlled steps actually charged. Finite recoveries are not the confidence proof; the proof is the Gaussian calculation above.

**Fatal scope checks.** Individual bounds ||X_i||≤1 alone allow E=n and do not imply this exponential lower bound. For fixed alphabet size, the positive protocol increases input energy by only a constant factor, so the result must not be advertised as inherent to all practical bounded controls. With polynomial C and E<n, the necessary absolute noise is exponentially small, but the number of accuracy bits is only O(d log(n/E)); a cheap bit-precision oracle is not ruled out. Fixed-noise averaging to that accuracy costs exponentially many samples. The target loss is uniform reconstruction / worst-case controlled prediction; a distribution-weighted loss may legitimately ignore the rare informative word. Finally, a passive **sampling** oracle for the point-mass word distribution reveals w in one sample; this is not a passive-HMM hardness result.

## 4. Ranked targets and next decisive questions

1. **Excitation-aware partially observed acquisition (highest object-level value).** Complete a literature/novelty audit of Claim N and its scalar controlled-chain specialization, then determine the weakest lawful excitation service that extends the positive coordinate-blocking construction beyond a monomial to a genuinely compact cyclic class. Its expected value is a precise impossibility/repair theorem for oracle acquisition, not a claim of general efficient discovery. Fatal test: if the intended real interface permits all-symbol unit controls, E=1 cannot be imposed after the fact. Also state whether the target is uniform model recovery or on-distribution prediction.
2. **Small-probe Las Vegas realization (highest immediate implementation value).** Implement the conditional L01 verification step around Claim R, charge response bits and exact arithmetic, and compare against the existing deterministic full-width / batched implementations. The first question is whether the explicit detector prerequisite survives independent proof review. This can improve a real symbolic-oracle workload, but it leaves noisy physical acquisition untouched and does not create a new polynomial-learning capability.
3. **Finite-bit rational reconstruction (low novelty, useful boundary).** If hidden entries have known rational height H and queried entries height P, a common denominator bound for a D-dimensional strictly triangular response is
   \[
   B=(D+1)H(nm^2+2m)+(D-1)PnD^2.
   \]
   Each response denominator is ≤2^B: multiply all hidden denominators into q and all query denominators into r, then use q^(D+1)r^(D−1) for every path of length <D. Absolute accuracy <2^(−2B−2) uniquely identifies each rational by continued-fraction reconstruction; reconstruct every entry before invoking exact learning. This is a routine finite-bit lift, not a noise-stability breakthrough. It gives polynomial accuracy-bit cost, but fixed-variance physical sampling may require exponentially many repetitions. Without H, no fixed accuracy can uniformly distinguish an arbitrarily tiny nonzero rational coefficient.

The strongest next technical question is therefore: **for a specified useful partially observed class, can lawful input design acquire a bounded, well-conditioned predictive basis with polynomial reset/symbol/sample costs, while preserving the actual input budget and prediction loss?** The answer cannot be inferred from finite Hankel rank, an existing good basis, exact algebraic hitting, full-state regressions, or a small numerical fixture.

## Memory guidance actually used

`MEMORY.md:1402-1432` and `MEMORY.md:1477-1490` were used only to preserve the access/norm/output distinction and avoid conflating a supplied Hankel/operator approximation with autonomous recurrence acquisition. Mathematical and current-source claims above were checked afresh or proved explicitly. Associated prior rollout IDs: `01a0d658-1639-7293-bf40-c1fc58ed0943`, `01a0d455-dbc1-7271-8085-0e775ae0b4ec`.
