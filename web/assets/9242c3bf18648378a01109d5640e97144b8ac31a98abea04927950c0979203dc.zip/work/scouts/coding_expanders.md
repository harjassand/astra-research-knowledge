# Coding and expander scout — 7 October 2026

## Finding and status

The best next target is the **local-code acquisition and compatibility bridge**, not another Ramanujan graph construction. Recent primary manuscripts make much stronger qLTC claims than the repository's graph card, but their load-bearing property is higher-order **product expansion**, together with compatible coefficient representations. Spectral expansion, ordinary tensor robustness, code distance, and quantum local testability are distinct requirements.

This scout proves two transfer obstructions and one positive certification lemma below. It does **not** certify a new asymptotically good qLTC, construct the missing lossless cubical geometry, or settle priority. The elementary representation-theory ingredients and finite-rank techniques are standard or closely related to existing work; novelty is the precise transfer diagnosis within this campaign, not an asserted new literature theorem.

## Primary literature refresh and actual read depth

- [Gay–Jeronimo, arXiv:2609.20780v1, 17 September 2026](https://arxiv.org/html/2609.20780v1): claims explicit binary CSS qLTCs with constant rate, relative distance, soundness, and locality. I read the interface and selected proofs in §§4, 10–13, not the whole proof. The critical claimed bridge is universal product expansion for Reed–Solomon codes on unequal norm-one grids, followed by equivariant endpoint representations on arithmetic cubical quotients. The expansion constant is chosen before increasing local degrees to meet the spectral threshold. Full-star compatibility and modular coefficient representations are substantive inputs. This scout has not independently verified the curve-incidence/interpolation machinery or arithmetic tower. Local copy: `work/scouts/coding_expanders_sources/2609.20780v1.{html,txt}`.
- [Chen–Huang–Liu–Tang, arXiv:2609.28028, 23 September 2026](https://arxiv.org/abs/2609.28028): abstract/interface scope only; independently claims a uniform norm-one RS product-expansion theorem and polynomial-time good binary qLTCs. No proof certification here.
- [Bafna–Li–Nguyen, ECCC TR26-204, 22 September 2026](https://eccc.weizmann.ac.il/report/2026/204/): primary abstract explicitly makes the good-qLTC construction **conditional on an RS product-expansion conjecture**. A concurrent-work paragraph in another manuscript groups it with unconditional constructions; the primary qualification controls.
- [Cohen–Leigh–Reiner–Ta-Shma–Tzalik, arXiv:2610.00525v1, 30 September 2026](https://arxiv.org/html/2610.00525v1): selected definitions and introduction read. Its level complex uses vertices grouped by Boolean-cube levels, not cubical faces with nontrivial local codes. Suitable imbalanced two-sided lossless directional graphs give small-set coboundary expansion and good qLTCs. The requisite geometry is explicitly not constructed, nor known even probabilistically. A tempting arithmetic Ramanujan-bigraph realization is reported to fail losslessness through an algebraic-subgroup orbit; that counterexample proof is deferred by the authors and was not reconstructed here. Local copy: `work/scouts/coding_expanders_sources/2610.00525v1.{html,txt}`.
- [Chattopadhyay–Ringach–Spooner, arXiv:2610.02512v1, 1 October 2026](https://arxiv.org/html/2610.02512v1): §§1, 5 and the determinant transfer in §6.4 read, not the entire trace-moment proof. Claims two-sided product expansion for random codes over a prime of size `O_D(2^(n^D) n^D log n)`, with characteristic growing with local length. Real Rademacher witnesses lead to integer determinant polynomials; one prime avoids all witness values, then Schwartz–Zippel handles all closed supports. The paper proposes symmetry-compatible codes as future work, not an established corollary. Local HTML: `work/scouts/coding_expanders_sources/2610.02512v1.html`.
- [Kalachev–Panteleev, 2025](https://arxiv.org/html/2501.01411v2): theorem/interface refresh. Random tuples over sufficiently large characteristic-two extension fields have higher-order product expansion. This does not itself provide the prescribed geometric symmetry.
- [Kalachev, 2023/2026](https://arxiv.org/abs/2308.02889): theorem/interface refresh. Robust/agreement testability and product expansion separate for three factors. A proof requiring the latter cannot substitute the former.
- [Hsieh–Lubotzky–Mohanty–Reiner–Zhang, 2025](https://arxiv.org/abs/2504.15087): abstract/interface refresh. Explicit constant-degree two-sided lossless vertex expanders, also with constant imbalance and free group actions, are available. Their existence does not supply four compatible directional graphs and square completion.
- [Asherov–Dinur, 2024](https://www.mdpi.com/1099-4300/26/4/348): interface refresh. Ramanujan bigraphs plus a finite gadget give unique-neighbor expansion; unique-neighbor and lossless expansion are not interchangeable.

Repository paths actually consulted: `00_START_HERE.txt`, `01_CORE.txt`, `AGENTS.md`, `cards/P-graph.txt`, `cards/P-pcp.txt`, `cards/W-frontier-combin2.txt`, `indexes/families.json`, `indexes/coverage_original.json`, and `web/pages/d-44521b6434c983e9.html`, all under `work/astra-research-knowledge/`. The latter supplies the OA177/OA178 catalogue interfaces. OA177 was not proof-audited; no released claim is assumed true below. The memory registry search returned no relevant hits.

## Three targets, ranked

| Rank | Target | Next observation that changes the decision | Cost and expected value |
|---|---|---|---|
| 1 | Audit and acquire useful constants for the uniform norm-one RS product-expansion bridge | Reconstruct the supported-decomposition/closure implication and decisive curve-incidence bound; find a counterexample support or an exact certificate at an admissible local tuple | High value: this is load-bearing for major recent claims and may permit much better locality. Full proof audit is substantial; brute-force certificates are exponential in local grid size. |
| 2 | Symmetry-compatible product expansion via a modular or smaller-symmetry random family | Exhibit a parametrized compatible family and a closed-support minor nonzero in characteristic two; alternatively find a representation obstruction | High upside, medium near-term tractability. The direct nonmodular SL2 transfer is already killed below. Random codes without compatibility are an inadequate comparator. |
| 3 | Imbalanced two-sided lossless square/cubical geometry | Produce one construction with square completion and expansion for **all** relevant small sets, excluding fibre/subgroup witnesses | Potentially major, but lowest bounded-wave expected value: geometry acquisition remains open and two natural constructions fail below. One-dimensional expansion certificates do not cover it. |

For rank 1, even the written conservative constants deserve separate cost accounting. For `t=4, K=8, h=10, epsilon=1/(2*1025)`, direct evaluation of the displayed recurrences gives `c_t=30465`, `P_t=3066234015062189312`, `log10(theta)=-112.353...`, and `log10(rho)=-487.519...`. These are an algebraic evaluation of the source's sufficient bound, not the optimal expansion constant or a correctness check. A better local-code certificate could matter enormously, but finding one and satisfying the subsequent spectral threshold are both charged tasks.

## Proved transfer obstruction A: nonmodular projective symmetry

**Claim.** Let `q=2^r`, `G=SL2(F_q)`, and let `B` be its upper-triangular Borel subgroup. Over an algebraically closed coefficient field `K` with `char(K)` not dividing `|G|`, consider

`M_chi = Ind_B^G chi`,

where `chi` is a character of the diagonal torus, inflated trivially over the unipotent subgroup. This is the `(q+1)`-coordinate monomial representation on the projective line. If `chi` is nontrivial, `M_chi` is irreducible. If `chi` is trivial, its invariant subspaces have dimensions only `0,1,q,q+1`.

**Proof.** The action on ordered projective-line pairs has two orbits: diagonal and off-diagonal. An equivariant endomorphism matrix is determined by one scalar on the diagonal and at most one on the off-diagonal orbit. At the ordered pair `(infinity,0)`, the common stabilizer is the diagonal torus. Its two fibre characters are `chi` and `chi^(-1)`. A nonzero off-diagonal matrix entry can therefore exist exactly when `chi=chi^(-1)`. Since the torus has odd order `q-1`, this occurs only for the trivial character. Thus a nontrivial `chi` has a one-dimensional endomorphism algebra. Maschke semisimplicity makes that module irreducible: over an algebraically closed field the endomorphism dimension is the sum of squared constituent multiplicities. For trivial `chi`, the endomorphism dimension is two. The all-ones vector splits off because `q+1` is invertible in `K`; its complementary augmentation module is irreducible. This yields precisely the stated dimensions. Extension to algebraic closure also excludes intermediate invariant dimensions over any smaller coefficient field. ∎

The underlying principal-series facts are standard; see [Paul Garrett's finite GL2/SL2 notes](https://www-users.cse.umn.edu/~garrett/m/repns/notes_2014-15/04_finite_GL2.pdf). The orbital proof above handles the stated nonmodular coefficient fields directly.

**Consequence.** For any fixed rate interval inside `(0,1)`, sufficiently large `q` admits no such invariant code in that interval. Therefore a large-prime random-code theorem cannot be directly imposed on this complete projective symmetry, even allowing the scalar twists used in compatible local charts. For four equal local lengths `n=q+1`, the prime selected in the Rademacher proof satisfies `p>2D s (2^D-1)n^D log(n+1)` with at least one closed support, hence exceeds `|SL2(F_q)|`; the nonmodular hypothesis is enforced by that construction. The characteristic-two representations escape Maschke semisimplicity. This proves failure of the direct transfer, not failure for smaller automorphism groups, higher-dimensional edge stalks, or modular constructions.

## Proved transfer obstruction B: literal commuting directions

**Claim.** Suppose at least three directional permutation groups `H_1,H_2,H_3` act transitively on the same `N`-point set and commute pairwise. They must all equal one regular abelian group.

**Proof.** The centralizer of a transitive permutation group is semiregular: an element fixing one point fixes every point. Therefore transitive `H_2 <= C(H_1)` is regular. The centralizer of a regular group is regular of order `N`; transitive `H_1 <= C(H_2)` must be its entire centralizer, hence also regular. Now `H_3` is contained in both regular groups `C(H_1)=H_2` and `C(H_2)=H_1`. Transitivity forces `H_3=H_1=H_2`; pairwise commutation then says this common group is abelian. ∎

A Cayley graph on an abelian group of order `N` with a symmetric generating multiset of fixed size `d` has normalized spectral gap `O_d(N^(-2/d))`. To see this, put the `N` characters' generator phases in the `d`-torus. Partition into `B^d<N` boxes. Two characters lie in one box, so their nontrivial quotient has each generator phase of magnitude at most `1/B`. Its normalized adjacency eigenvalue is at least `1-2*pi^2/B^2`; take `B` of order `N^(1/d)`.

Thus the construction with one common fibre, literal cross-direction commutation, and connected bounded-degree directions cannot yield an expander family. Actual square-completion geometry must allow nontrivial transport of edge labels; this claim does not rule out arithmetic quotients of products of trees.

A separate Cartesian-product attempt also fails. For products of growing biregular graphs, choose an entire direction-`i` fibre with all other coordinates fixed. Its relative size tends to zero but its neighborhood has only `1/D_i'` of the maximum `D_i |S|`. Hence losslessness with `epsilon<1-1/D_i'` fails. Product completion by itself does not solve acquisition.

## Proved positive transfer: finite certificates for universal expansion

Fix explicit local code generator matrices `C_i <= F^(Omega_i)`. Let `N=product n_i`, and let `L=sum_i N/n_i` be the number of axis-parallel lines. Embed each line-code space in `F^N`, let `A` be their sum, and for a line subset `T` let `U_T` be their sum with cost

`c(T)=sum_{line ell in T} length(ell)`.

Write `V_S=A intersect F^S` for a grid support `S`.

**Certificate theorem.** The tuple has product expansion at least `rho` over **every field extension** iff

`for every S, there exists T with c(T)<=|S|/rho and V_S subset U_T`.       (RC)

All spaces in RC are computed over the supplied base field.

**Necessity.** Take an `F`-basis `v_1,...,v_a` of `V_S` and its generic vector `x=sum_j t_j v_j` over `F(t_1,...,t_a)`. Universal expansion supplies one allowed line set `T` containing `x` in its span. Any `F`-linear functional annihilating `U_T` also annihilates `x`; independence of the indeterminates forces it to annihilate each `v_j`. Thus `V_S subset U_T`.

**Sufficiency.** For an extension-field array `x` with support `S`, scalar extension preserves the intersection defining `V_S`. RC places the whole space in `U_T`. Choose a base-field linear section of the surjective sum-of-line-spaces map onto `U_T`. Apply it after extension to decompose `x`; at most the selected lines are used. Cost is at most `|S|/rho`. The same section applied to vector-valued entries proves **collective** expansion without changing `rho`. ∎

**Finite extension reduction.** Over `F_q`, it suffices to check ordinary expansion over one extension `F_(q^m)` with `q^m>2^L`. If RC fails at `S`, its admissible `U_T intersect V_S` are at most `2^L` proper subspaces. Each contains at most `(q^m)^(dim V_S-1)` vectors, so their union cannot cover `V_S` over that extension. An uncovered vector violates ordinary expansion. This charges an extension degree `m<=floor(L log_q 2)+1`, rather than assuming an infinite-field oracle.

**Acquisition cost.** Exhaustive search costs `O(2^(N+L) poly(N,L))` base-field operations using rank inclusion tests. A certificate selects one `T` per support; its verification costs `O(2^N poly(N,L))`. This is useful for fixed local tuples and very small prototypes; it is not an efficient algorithm when local lengths grow. No symmetry compatibility, spectral input, or homological rate follows merely from RC.

**Subtuple reduction.** If the full tuple is `rho`-product-expanding and all omitted codes are proper, each retained subtuple has the same constant. Choose for each omitted code a nonzero annihilating functional and a coordinate vector on which it is one. Embed a retained array on those coordinates, apply full-tuple expansion, and contract the omitted factors. Their directional terms vanish; the retained line counts cannot increase. This also holds universally. Consequently all mixed dual full tuples suffice to certify all nonempty mixed subtuples, provided the factors and duals are proper. The remaining symmetry requirement still has to be acquired.

## Exact finite acquisition and its limits

An explicit test tuple is `d` copies of `span_F2(1,1)`. Its universal product-expansion constant is exactly `1/d`; the dual tuple is identical.

Identify grid points with the Boolean `d`-cube. Line-code generators are edge incidence vectors, so `A` is the sum-zero hyperplane. For each support `S`, choose its coordinatewise majority vertex. Shortest paths from that vertex to every point of `S` have total length at most `d|S|/2`. A spanning tree of their union generates the sum-zero subspace on `S`, with line cost at most `d|S|`; RC proves `rho=1/d`. Two opposite corners require a path of at least `d` edges in any decomposition, so no larger constant is possible.

`coding_expanders_rank_certificate.py` exhaustively checks RC for all **65,536** supports of the `d=4`, 16-point tuple, using exact binary rank operations and integer cost inequalities. It completed with `PASS`; `coding_expanders_rank_check.json` records the result. The analytical argument proves universality; the finite run checks the concrete certificate implementation. This tuple does not acquire an arithmetic qLTC family or its required rate/spectral conditions.

## Expansion/code gates retained

- A bounded-degree simplicial complex with `Z^i=B^i` has zero degree-`i` CSS logical dimension. Its boundary code also contains nonzero bounded-weight coboundaries whenever the preceding map is nonzero. Coboundary expansion alone is not a good classical or quantum code.
- Removing bounded-weight stabilizer generators from a trivial code creates bounded-weight candidate logicals; if removal creates new logical dimension, a removed independent generator is a logical of that bounded weight. This cannot create linear quantum distance.
- If a CSS code's combined X/Z Tanner graph has girth at least six, no X and Z row share two coordinates. Commutation then forbids sharing even one coordinate. The X and Z supports separate; positive logical dimension leaves a non-stabilizer singleton of one Pauli type. Quantum distance is one. High girth of a different auxiliary graph is compatible with good codes, but its Tanner interpretation cannot be assumed.
- None of the code results gives a quantum-PCP hardness reduction. Soundness refers to the appropriate code-distance observable and normalized check energy, not trace distance or QMA hardness.

**Strongest next question:** in the symmetry-compatible characteristic-two local-code family, can closed-support exactness be certified through a substantially smaller set of orbit/closure representatives, with a proved uniform implication for all supports? The rank criterion supplies an exact acceptance condition; the missing ingredient is a justified compression of its exponentially many supports. That is a concrete acquisition bottleneck where a new result would improve both rigor and usable parameters.
