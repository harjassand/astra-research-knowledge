# Quantum PCP / commuting games / operator-algebra scout

7 October 2026. Status: **one internally proved sharp restricted obstruction, one internally proved conditional repetition refinement, no quantum PCP breakthrough**. No source repository files were modified. No theorem prover or external review was run. Finite diagnostics have a separate scope.

## Decision and ranked targets

1. **Prune positive local syndrome gadgets with a sharp linear barrier.** The result below permits arbitrary nonlinear local tests, arbitrary auxiliary dimension and noncommuting auxiliary operators. A normalized positive tester that touches at most `r` of `t` independent syndrome bits cannot reject every singleton above `r/t`. This is stronger within this architecture than the source's signed-polynomial degree bound `Omega(sqrt(t))`. Mathematical novelty is uncertain and likely modest: the mechanism is a coverage/variational argument. Its useful contribution is an exact interface that blocks proposed nonlinear auxiliary repairs before implementation.
2. **Refine the commuting repetition rate by discarding rare bad components.** Conditional on the inherited threshold theorem, the new corollary replaces its worst component gap by a gap quantile, paying only the discarded question mass in the threshold. It can remove an exponentially slow component of negligible mass. The coarsening proof does not identify commuting and finite tensor strategies. The inherited theorem itself remains internally audited, unreviewed source material.
3. **Audit a common coherent encoding for actual five-qubit seeds.** This retains the highest mathematical upside and the largest unresolved burden. The new obstruction and the exact Pauli norm calculation below indicate which shortcuts fail. They do not construct the required common `V,C,B`.

Best next technical question: can a *single* encoding coherently mix syndrome sectors for overlapping five-qubit Clifford projectors while giving both a constant normalized invalid-space penalty and positive polynomial-row logical tests? A first decisive object is an explicit symbolic family for two incompatible five-qubit stabilizer bases, with row and coefficient algorithms valid for every amplification depth. Term-specific encodings or a two-qubit positive control do not answer it. Expected value of another generic degree/small-bias gadget search is low unless it exposes a mechanism leaving the theorem's fixed syndrome-sector model.

## Exact inherited interface

The hard amplified terms have the form

\[
h_j=I-\bigotimes_{i=1}^{t_j}(I-\Pi_{ji}),\qquad
H=\sum_j w_jh_j,\quad w_j\ge0,\quad\sum_jw_j=1.
\]

The actual local seeds include five-qubit Clifford **projectors**. A reflection `I-2 Pi` is generally not Clifford. The desired sparse reduction must acquire one common efficiently described isometry `V`, with `P=VV*`, and positive contractions `C,B` satisfying

\[
\ker C=\operatorname{ran}V,\quad C\ge\gamma(I-P),\quad
\alpha H\le V^*BV\le\beta H,
\]

for constants independent of size/depth. Every auxiliary state, invalid label, row enumeration, entry calculation, coefficient bit height, precision and normalization must be covered. The source's compression inequality removes `[B,P]=0` as a requirement, but supplies neither sparse operator.

Exact local paths read:

- `work/astra-research-knowledge/00_START_HERE.txt`, `01_CORE.txt`.
- `cards/P-pcp.txt`, `cards/P-pcp-obstructions.txt`, `cards/P-pcp-refinements.txt`.
- `cards/L02-commuting-repetition.txt`, `cards/N11-repetition-pcp-audit.txt`.
- `web/pages/d-c1f0aa3b0a5c8570.html`: exact archived `updates/L/package/work/pcp_bridge.md`; full note read.
- `web/pages/d-2815b2aba17e044e.html`: `literature/notes/frontier_check_repetition/cycle19/COMMUTING_THRESHOLD_EXTENSION.md`; operator transport, theorem interface and anchoring sections read. The full repetition combinatorics was not independently re-proved here.
- `web/pages/d-172e78a7a4f7f7e7.html`: exact archived `updates/L/package/work/repetition_attack.md`; erasure/correlation and source-interface sections read.
- `web/pages/d-b79c9e9230a45b5d.html`: `updates/L/package/work/repetition_adversary.md`; retrieved, not adopted as validation.

## Result A: sharp positive local syndrome bound

### Statement

Let `x in {0,1}^t`, and let all operators act on the same auxiliary Hilbert space, which may be infinite-dimensional. Suppose

\[
K_x=\sum_a w_aE_{a,x|S_a},\qquad
w_a\ge0,\quad\sum_aw_a=1,\quad
0\le E_{a,z}\le I,\quad |S_a|\le r\le t.
\]

The effects may be arbitrary nonlinear functions of their selected syndrome bits and need not commute. Suppose

\[
\inf\operatorname{spec}K_0\le\eta,\qquad
K_x\ge cI\quad\text{for every }x\ne0,
\]

where `0<=eta<=1`. Then

\[
\boxed{c\le\eta+\frac rt(1-\eta).}
\tag{A}
\]

In particular exact completeness implies `c<=r/t`. A constant normalized gap forces `r=Omega(t)`, regardless of auxiliary size or noncommutation. Countably many summands are allowed when the nonnegative norm budgets are summable.

### Proof

Choose a unit vector `z` with `f(0)=<z,K_0 z><=eta+zeta`. For each term put `f_a(x)=w_a<z,E_{a,x|S_a}z>`, so `0<=f_a<=w_a`. At the singleton `e_i`, a term is unchanged whenever `i notin S_a`. Therefore

\[
\sum_{i=1}^t f_a(e_i)
\le(t-|S_a|)f_a(0)+|S_a|w_a.
\]

Summing over `a` and using `|S_a|<=r` gives

\[
tc\le\sum_i f(e_i)
\le tf(0)+\sum_a|S_a|(w_a-f_a(0))
\le(t-r)f(0)+r.
\]

Let `zeta` tend to zero. This proves (A), including a continuous spectrum at zero. The same vector is a legal trial vector in every singleton block; changing each block's preferred auxiliary state cannot evade an all-state lower bound.

### Sharpness, budgets and precision

Choose an `r`-subset `S` uniformly, and set

\[
E_{S,x|S}=\left[\eta+(1-\eta)\mathbf1\{S\cap\operatorname{supp}x\ne\varnothing\}\right]I.
\]

The zero energy is `eta`; every singleton has energy `eta+(1-eta)r/t`, and every other nonzero string has at least that energy. Thus the bound is exact.

More precisely the proof bounds the available singleton gap by

\[
\frac1t\sum_a|S_a|(w_a-f_a(0)).
\]

An `x`-independent positive auxiliary enforcer consumes normalization but contributes no singleton detection in this trial vector. With exact completeness and total positive term norm budget `L`, the analogous bound is `c<=(1/t)sum_a |S_a|w_a<=rL/t`.

If a physical family is uniformly within operator norm `epsilon` of the normalized positive family, then the same proof gives, when `eta+epsilon<=1`,

\[
c\le\eta+\frac rt(1-\eta)+(2-r/t)\epsilon.
\]

Per-entry accuracy is insufficient without a row-sum or other uniform operator error certificate.

### What this falsifies and what it leaves open

It falsifies the proposal that positive *constant-support* nonlinear syndrome gadgets can fix the normalized OR gap merely by enlarging or making the auxiliary Hamiltonian noncommuting. This strengthens the archived affine case: an arbitrary function of `r` bits is permitted, rather than only an affine dependence.

It is **not** a lower bound for all positive sparse matrices. The total positive term norm budget is a premise, distinct from only `||K_x||<=1`. Nor does it cover a common encoding/enforcer that couples syndrome sectors, or an encoding whose physical identification of the auxiliary space changes with `x`. Globally positive signed polynomial constructions from the source lie outside the positive local decomposition premise. The required sparse PCP interface allows these escapes.

For a single amplified clause with disjoint nontrivial seeds, all independent syndrome strings really exist. For an entire code or verifier, legal singleton syndromes must be established rather than assumed. A distance or Hamming soundness claim alone does not supply them.

## Result B: trimmed component spectral repetition

### Conditional theorem

Assume the archived commuting threshold theorem:

\[
\Pr[W_k\ge\lceil(v+\delta)k\rceil]
\le\exp\!\left[-\frac{\sigma\delta^3k}{2048(1+\log d)}\right],
\tag{T}
\]

for a finite two-player game of commuting value `v`, answer product `d`, independent repeated questions and arbitrary joint commuting measurements. Here `sigma` is the minimum resampling gap over non-singleton support components, with the singleton convention from the source.

Write the question support components as `j`, with masses `p_j` and component commuting values `v_j`. Let `B` be any set of components to discard, and put

\[
p_B=\sum_{j\in B}p_j,\qquad
e_B=\sum_{j\in B}p_j(1-v_j),\qquad
\sigma_{\bar B}=\min_{j\notin B}\sigma_j.
\]

If `e_B<delta<1-v`, then

\[
\boxed{
\Pr[W_k\ge\lceil(v+\delta)k\rceil]
\le\exp\!\left[-\frac{\sigma_{\bar B}(\delta-e_B)^3k}
{2048(1+\log d)}\right].}
\tag{B}
\]

The immediately usable value-free corollary is obtained from `e_B<=p_B`: if `p_B<delta`, replace `e_B` by `p_B`. Optimizing this certificate over subsets gives a mass-versus-gap tradeoff instead of a mandatory worst-component rate.

### Proof, including the commuting simulation

Each local question identifies its support component: components cannot share a local question. Replace every discarded component by a single new question pair `(bottom,bottom)`, whose predicate always accepts. Retain all other component questions and predicates. The resulting game has the same answer alphabets, component gap `sigma_barB`, and value

\[
v'=\sum_{j\notin B}p_jv_j+p_B=v+e_B.
\]

The value decomposition is valid in the commuting model. Restricting any strategy to a component gives the upper bound. Conversely, a finite tensor product of near-optimal *commuting* component representations and their vector states achieves the weighted sum arbitrarily closely. This uses tensor products of commuting representations to combine strategies, not an identification with spatial strategies.

For the repeated-strategy comparison, prepare shared classical randomness before receiving questions: for each coordinate, sample a full question pair from the original law conditioned on `B`. When the coarse questions at that coordinate are `(bottom,bottom)`, Alice substitutes the stored Alice question and Bob substitutes the stored Bob question into their original joint measurement. On retained coordinates they use the supplied question. The seed is independent of retained questions, so the substituted full question law is exactly the original iid law. All original cross-input commutators were zero, so controlled substitution preserves cross commutation for every coarse input pair. One may implement the shared seed by a finite classical ancilla; no finite-dimensional assumption is placed on the original representation.

The coarse predicate accepts every discarded coordinate, so its win count dominates the original win count pointwise under this coupling. Apply (T) to the coarse game at the threshold

\[
v'+(\delta-e_B)=v+\delta.
\]

This proves (B), including the ceiling and strategies that do not attain their supremal value.

### Consequence and acquisition cost

Take retained components of gap at least `1/4` and a discarded component of mass `p_B=0.001` and gap `2^{-n}`. At threshold excess `delta=0.1`, (B) certifies the constant factor `(1/4)(0.099)^3`, while (T) using the untrimmed minimum gives only `2^{-n}(0.1)^3`. This is a genuine quantitative improvement *conditional on (T)*.

An explicit question table permits support components, masses and transition matrices to be computed in time polynomial in its table size. A succinct sampler does not provide those objects for free. The sharper `e_B` formula additionally presumes supplied component values or certified bounds; arbitrary commuting game values are not efficiently acquired. The mass-only formula avoids that particular debt. The construction proves a tail estimate, not a PCP Hamiltonian reduction or a gap-acquisition algorithm.

No historical novelty claim is made; a bounded search did not locate this precise trimmed-component statement. Because the proof is a direct coarse-graining corollary, its expected value is quantitative and architectural rather than foundational.

## Additional exact calculations and failed transfers

**Erasure optimization.** For symmetric independent erasure with survival `q`, the source already derives maximal correlation `q rho` and resampling gap at least `(1-q rho)/2`. The retained one-game soundness gap is `q^2 epsilon`. Thus its cubic all-wins exponent has coefficient `q^6(1-q rho)/2`. In the worst case `rho=1`, this is maximized at `q=6/7`, with coefficient `23328/823543`, a factor `7.25156` above half erasure. The archived three-bit wrapper `q=7/8` achieves `99.0232%` of that optimum. This confirms the wrapper was already nearly optimal; parameter tuning offers little additional value there. For known `rho`, the optimizer is `min(1,6/(7 rho))`. These are elementary deductions, conditional on the same repetition theorem.

**Exact five-qubit Pauli normalization.** For a rank-one stabilizer projector on `k` qubits, set `a=1-2^{-k}`, `b=2-2^{1-k}`. Pauli expansion uniqueness and tensor multiplication give

\[
\left\|I-\bigotimes_{i=1}^t(I-\Pi_i)\right\|_{\mathcal P,1}
=1+b^t-2a^t.
\]

For `k=5`, this is `1+(31/16)^t-2(31/32)^t`, despite operator norm one. It decisively rejects a black-box single-Pauli sampling transfer with constant normalization. It does not reject sparse matrices: with computational-basis seeds this operator is diagonal. It also does not reject jointly measuring commuting seed stabilizers and applying classical AND/OR, as in streaming or interactive protocols. Cancellations between averaged clauses require a separate argument.

## Bounded primary-literature refresh

The entries below are literature statements, separate from Results A/B. Read depth is explicit.

- [Bergamaschi–Metger–Vidick–Zhang, *Derandomised tensor product gap amplification for quantum Hamiltonians*, arXiv:2510.01333v1](https://arxiv.org/html/2510.01333v1), October 2025. Read Definitions 1.6/1.9 and applications, not the complete soundness proof. The amplification gives polynomially many structured tensor terms and trades locality for a constant energy promise gap; it leaves sparse matrix conversion open. Its discussion also warns that the earlier claimed QMA games PCP was invalidated.
- [Natarajan–Nirkhe, *The status of the quantum PCP conjecture (games version)*, arXiv:2403.13084v1](https://arxiv.org/html/2403.13084v1), March 2024. Read §1 and §4. The independently important flaw is **energy normalization by Pauli coefficient 1-norm**, which tensor amplification can enlarge exponentially. This is additional to the earlier low-degree-test proof gap. Efficient honest provers and succinct questions/answers are essential; `MIP*=RE` alone does not settle this conjecture.
- [Sun–Vidick, *Quantum Interactive Oracle Proofs*, arXiv:2601.12874v1](https://arxiv.org/html/2601.12874v1), January 2026. Read model, Theorems 1.5/1.7, open questions and Clifford-Hamiltonian overview. One protocol has polynomial communication and constant incoming queries but polynomial trusted private quantum computation/EPR preparation. The strong protocol has constant total quantum operations but exponential communication. The authors explicitly leave qIOP-to-qPCP compilation open. Neither is the required positive sparse encoding.
- [Alrabiah–Arunachalam–Grewal–Wright, *No low-degree tests for quantum states*, arXiv:2608.00265v1](https://arxiv.org/html/2608.00265v1), July/August 2026. Read Theorem 3.2, Theorem 3.16 and the degree-two discussion. Copy-only phase-state testing can require a superpolynomial number of copies; even degree two needs `Omega(m)`. This is not a contradiction to interactive Pauli low-degree tests: those grant correlated questions and measurement access that independent state copies do not supply.
- [*Long-horizon autoformalization of a core theorem underlying MIP*=RE*, arXiv:2609.19814v1](https://arxiv.org/html/2609.19814v1), September 2026. Read introduction/scope only; no Lean build or statement audit performed. The reported formalization covers quantum soundness of the classical low individual-degree test under corrected assumptions. It does not supply the missing PCP sparsification or validate the unrelated new repetition manuscript.
- [Pinned release 277 Lean scope](https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/lean/docs/277.md) and [§6 consequences](https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Threshold-parallel-repetition-for-finite-dimensional-entangled-games-September-25-2026/build/sections/06-consequences.tex), retrieved live. The declared formal scope has a thirteenth-power finite-dimensional entangled bound and excludes the separate distribution-dependent cubic bound. The manuscript consequences use a fifth-power rate. No build was run; the commuting extension is still the local unreviewed candidate, not a consequence of the finite-dimensional scope declaration.

## Verification and next falsifiable work

`work/scouts/pcp_operator_checks.py` produced `work/scouts/pcp_operator_checks.json`: 45 exact rational sharpness cases, 420 two-dimensional noncommuting auxiliary fixtures, 15 exact Pauli coefficient cases, and rational erasure optimization checks. These diagnose implementation and constants. They do not certify the inherited threshold theorem or establish priority. Results A and B rest on the written proofs, with B's explicit dependency on (T).

The next worthwhile proof task is a common coherent encoding that exposes where it leaves Result A's architecture. Require explicit overlapping actual five-qubit projectors, symbolic arbitrary-depth clauses, positive `C,B`, all-state protection, constant norm/gap, and polynomial row/bit algorithms. An attempted construction that presents only compressed expectations on valid vectors, only a syndrome-local convex sum, or an uncharged Pauli coefficient expansion fails a precise gate recorded here.
