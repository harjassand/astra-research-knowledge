# Optimization scout: a stable isotropic moment compiler for a promised quartic class

Date: 7 October 2026. Status: the theorem and estimates below are an original derivation in this run, **internally proved, pending a separate proof audit**. Historical novelty is UNKNOWN. Six small numerical transcription checks are recorded below; no matched runtime benchmark, external review, or general hidden-convexity algorithm is claimed. The conclusion has a supplied-metric boundary.

## Main signal and ranking

1. **Highest-value scoped result:** a degree-four SDP converts a noisy, coupled, orthogonally hidden biquadratic quartic into the uniform fourth moment of *all* hidden axes. It avoids coordinate deflation and determinant factorization. An explicit quadratic-growth inequality gives linear dependence on coefficient noise. The strongest matched competitor is standard degree-four SOS with an isotropic/high-entropy constraint followed by established orthogonal-tensor rounding; this construction may be a short consequence of that prior.
2. **Next consequential question:** can the same coefficient-only input acquire an aligned metric without assuming it or paying an exponential/noise-sensitive canonical construction cost? The present theorem does not answer this. Source snapshot work already has generic coefficient-only detectors, a ternary theorem, and route-specific metric obstructions; those need separate audit.
3. **Lower priority:** implement total-cost versions of recent higher-order monotone-VI acceleration. Recent claimed oracle exponents are attractive, but exact complete jets, public domain operations, and Taylor-model computation must all be charged. No new advance is supplied here.

This is a tractable research result rather than a foundational breakthrough. Its useful next action is hostile proof/prior-art review and a small, equally informed numerical comparison.

## 1. Exact interface

First state the normalized problem. The observed input is the fully symmetric coefficient tensor \(\widehat T\) of a homogeneous quartic in \(\mathbb R^n\). There is an unknown orthogonal frame \(U=(u_1,\ldots,u_n)\) and unknown real symmetric matrix \(G\) such that the true quartic is

\[
 f(x)=((U^Tx)^{\circ2})^T G((U^Tx)^{\circ2})
      =T[x,x,x,x].
\]

The promise is

\[
 w_{ij}:=G_{ii}+G_{jj}-2G_{ij}\ge\gamma>0\qquad(i\ne j),
 \qquad \|\widehat T-T\|_F\le\sigma.
\]

Positive definiteness of \(G\) is sufficient for positive pairwise contrasts but is not necessary. No signs of \(G_{ij}\), separability, eigenvalue separation of \(G\), or separation between its diagonal entries are required. The supplied information is the coefficient tensor, a noise bound, and (if a prescribed accuracy is required) a lower bound \(\gamma\). The frame and \(G\) are acquired; they are not provided to the optimizer or the rounding procedure. A finite precision coefficient table has \(\binom{n+3}{4}=\Theta(n^4)\) independent entries in the dense model. Acquiring those entries is outside the SDP and must be charged.

For a nonorthogonal rational representation \(f(x)=((Lx)^{\circ2})^TQ((Lx)^{\circ2})\), this result applies when an **aligned SPD metric** \(M=L^TBL\), positive diagonal \(B\), is supplied or already legally acquired. Whiten with \(z=M^{1/2}x\); \(B^{1/2}LM^{-1/2}\) is orthogonal and \(G_{ij}=Q_{ij}/(B_{ii}B_{jj})\). Transforming a noisy fourth tensor can multiply its error by \(\|M^{-1/2}\|^4\), and mapping approximate rays back adds the usual metric conditioning. Those costs cannot be omitted. The broad source theorem's missing-metric question remains missing here.

## 2. The coefficient-only SDP

For a fully symmetric fourth tensor \(Y\), let \(\mathcal C_Y\) be its catalecticant on the Euclidean space of symmetric matrices:

\[
 \langle A,\mathcal C_Y B\rangle
    =\sum_{i,j,k,l}Y_{ijkl}A_{ij}B_{kl}.
\]

Use an orthonormal basis of \(\mathrm{Sym}_n\), consisting of \(E_{ii}\) and \((E_{ij}+E_{ji})/\sqrt2\). The SDP is

\[
 \max_Y\ \langle\widehat T,Y\rangle
 \quad\text{subject to}\quad
 Y\text{ fully symmetric},\quad
 \mathcal C_Y\succeq0,\quad
 \sum_kY_{ijkk}=\frac{\delta_{ij}}n.
 \tag{S}
\]

It has a PSD block of dimension \(N=n(n+1)/2\), \(\Theta(n^4)\) fourth-moment variables, and polynomially many explicit linear constraints. It is only a degree-four pseudomoment relaxation: a general feasible \(Y\) need not come from a measure. The proof below uses PSD and the constraints directly, so it does not assume a moment representation.

The true hidden-axis moment

\[
 Y_*:=\frac1n\sum_{i=1}^n u_i^{\otimes4}
 \tag{1}
\]

is feasible. The isotropic sphere moment is a known strictly feasible point:

\[
 (Y_{\rm sph})_{ijkl}
 =\frac{\delta_{ij}\delta_{kl}+\delta_{ik}\delta_{jl}+\delta_{il}\delta_{jk}}
        {n(n+2)}.
 \tag{2}
\]

Its catalecticant acts as \(A\mapsto(\operatorname{tr}(A)I+2A)/(n(n+2))\). Its smallest eigenvalue is \(2/[n(n+2)]\). Thus, in the affine constraint space, an explicit Frobenius ball of radius \(1/[n(n+2)]\) around this rational point is feasible. Every feasible catalecticant has trace one and therefore Frobenius norm at most one. These facts supply both a polynomial interior radius and a bounded outer radius for weak SDP optimization. This is not an appeal to an uncharged exact optimum oracle.

## 3. Exact optimum and uniqueness: proof

All constraints and norms are orthogonally invariant. Analyze them in the unknown hidden frame; that frame is a proof device, not an algorithm input. Put

\[
 c_{ij}=Y_{iijj}=Y_{ijij}\ge0\quad(i\ne j).
\]

Nonnegativity follows by evaluating the PSD catalecticant on the symmetric off-diagonal matrix. The contraction constraint gives

\[
 Y_{iiii}=\frac1n-\sum_{j\ne i}c_{ij}.
\]

Consequently the observed quartic objective without noise satisfies the exact identity

\[
 \langle T,Y\rangle
 =\frac1n\sum_iG_{ii}-\sum_{i<j}w_{ij}c_{ij}.
 \tag{3}
\]

Already under merely nonnegative contrasts \(w_{ij}\ge0\), the optimum is \(\sum_iG_{ii}/n\), attained by (1), and the exact optimal face is described by \(w_{ij}c_{ij}=0\) for every pair. Under strictly positive contrasts, every optimizer has \(c_{ij}=0\) for every pair. Each catalecticant row indexed by \(x_ix_j\), \(i\ne j\), then has zero diagonal and is identically zero by PSD. Full tensor symmetry now kills every tensor entry involving more than one distinct coordinate: any such entry can be partitioned with one mixed pair as a catalecticant row. The contraction fixes the surviving entries to \(Y_{iiii}=1/n\). Hence (1) is the **unique optimizer**, including when all \(G_{ii}\) and many other observable spectra coincide. Conversely, if any contrast is zero while all others are nonnegative, rotate that coordinate pair and take its uniform axis moment together with the remaining axes. Equation (3) gives a different optimizer for a nontrivial rotation. Thus strict positivity is also necessary for uniqueness of this SDP within the nonnegative-contrast class; a zero contrast does not by itself imply that every other conceivable acquisition method fails.

This is the acquisition step: the uniform axis tensor is inferred from the coupled quartic rather than supplied as a teacher tensor. Convexity recognition outside the promise is not implied.

## 4. Quantitative quadratic growth: proof

Write \(C=\mathcal C_Y\), \(C_*=\mathcal C_{Y_*}\). Let \(P\) project onto diagonal symmetric matrices in the hidden frame and \(Q=I-P\). Define

\[
 s=\operatorname{tr}(QC)=2\sum_{i<j}c_{ij}\in[0,1].
\]

On the diagonal block, \(PCP-C_*\) is minus the graph Laplacian with edge weights \(c_{ij}\). Its Frobenius norm is at most its Laplacian trace \(s\). The PSD block \(QCQ\) also has Frobenius norm at most its trace \(s\). For the cross block, PSD implies

\[
 \|PCQ\|_F^2\le\operatorname{tr}(PCP)\operatorname{tr}(QCQ)=(1-s)s.
\]

For example, factor \(C=VV^T\) and use \(\|V_PV_Q^T\|_F\le\|V_P\|_F\|V_Q\|_F\). Combining the three blocks yields

\[
 \|Y-Y_*\|_F^2=\|C-C_*\|_F^2
 \le 2s^2+2(1-s)s=2s.
\]

The equality of tensor and catalecticant Frobenius norms holds because the tensor is pair-symmetric and annihilates antisymmetric matrix coordinates. If \(t=\langle T,Y_*\rangle-\langle T,Y\rangle\), equation (3) gives \(t\ge\gamma s/2\). Therefore

\[
 \boxed{\|Y-Y_*\|_F^2\le\frac{4t}{\gamma}.}
 \tag{4}
\]

No actual probability distribution, eigenvalue gap, or axis information was assumed to obtain this estimate.

## 5. Linear noise stability: proof

Let \(\widehat Y\) be feasible and within \(\delta\) of the optimum of (S). Put \(r=\|\widehat Y-Y_*\|_F\) and \(E=\widehat T-T\). Optimality comparison against the feasible \(Y_*\) gives

\[
 t\le\delta+\langle E,\widehat Y-Y_*\rangle
       \le\delta+\sigma r.
\]

Together with (4),

\[
 r^2\le\frac4\gamma(\delta+\sigma r),
\]

so

\[
 \boxed{r\le\frac{2\sigma}{\gamma}
       +2\sqrt{\frac{\sigma^2}{\gamma^2}+\frac\delta\gamma}
       \le\frac{4\sigma}{\gamma}+2\sqrt{\frac\delta\gamma}.}
 \tag{5}
\]

The optimizer need not satisfy the hidden promise. Noise is an arbitrary additive fully symmetric fourth tensor in Frobenius norm. A table-entry norm or value-oracle noise guarantee must be converted into this norm, with its dimension and whitening costs, before (5) can be invoked.

## 6. Rounding all axes and charged computation

Sample a standard Gaussian \(A\) in \(\mathrm{Sym}_n\) (diagonal variance one and off-diagonal variance one-half), independent of \(\widehat Y\), and form \(B=\widehat Y:A\). The true contraction is

\[
 B_*:=Y_*:A=\frac1n\sum_i (u_i^TAu_i)u_iu_i^T.
\]

Its eigenvectors are all axes. Orthogonal Gaussian invariance makes \(u_i^TAu_i\) independent standard normals, so equal eigenvalues occur with probability zero. The standard random-contraction/eigendecomposition rounding is established prior, not a new mechanism.

For a conservative explicit error estimate, let \(0<\eta<1/4\). A union bound and the density of a \(N(0,2)\) difference give, except with probability at most \(\eta\), a gap at least \(\eta/n^3\) between the eigenvalues of \(B_*\). Also Gaussian isotropy gives

\[
 \mathbb E_A\| (\widehat Y-Y_*):A\|_F^2=r^2,
\]

so Markov gives a perturbation at most \(r/\sqrt\eta\), except with probability at most \(\eta\). If \(r/\sqrt\eta\le\eta/(4n^3)\), an elementary symmetric-matrix eigenspace perturbation bound gives, after matching signs and permutation,

\[
 \max_i\sin\angle(\widehat u_i,u_i)
 \le \frac{2n^3}{\eta^{3/2}}\,r.
 \tag{6}
\]

This deliberately loose \(n^3\) rounding factor is not claimed optimal. Finite random bits and finite eigensolver precision require an additional chosen perturbation allowance; exact Gaussian samples and exact eigendecomposition are only the clean mathematical description. Their discretization must be charged for an implementation claim. Dense contraction reads \(\Theta(n^4)\) tensor entries; the final eigensolve is polynomial in \(n\) and precision. Once exact axes are obtained, the unknown coupling entries are \(G_{ii}=T[u_i,u_i,u_i,u_i]\) and \(G_{ij}=3T[u_i,u_i,u_j,u_j]\) for \(i\ne j\), with the factor three following from the fully symmetric tensor convention. A dense four-mode tensor basis change costs \(O(n^5)\) arithmetic operations. With approximate axes, use the same formulas on \(\widehat T\); each coupling error is at most \(3\sigma+12\|T\|_F e\), where \(e\) is the largest matched Euclidean axis error. The unknown norm can be bounded by the supplied data as \(\|T\|_F\le\|\widehat T\|_F+\sigma\). This charges the tensor scale as well as its acquisition noise.

For a rational input, implement the Turing-model SDP in the **unnormalized rational basis** \(E_{ii},E_{ij}+E_{ji}\), rather than placing \(\sqrt2\) in rational SDP coefficients. Its matrix is \(C_{\rm rat}=DC D\), with \(D\)'s entries one or \(\sqrt2\); the actual matrix coefficients are rational multiples of the entries of \(Y\). It has trace at most two and Frobenius norm at most two, the rational sphere point has minimum eigenvalue at least \(2/[n(n+2)]\), and an outer radius four and inner radius \(1/[n(n+2)]\) are valid. Fully symmetric tensor constraints become explicit rational equalities on this matrix. Thus [de Klerk–Vallentin, Theorem 1.1](https://arxiv.org/pdf/1507.03549), whose hypotheses and statement were read, provides a rational feasible \(\delta\)-optimal output with polynomial bit complexity in \(n\), the rational input length, and \(\log(1/\delta)\). This charges approximate optimization rather than assuming an exact SDP optimum oracle. The six small runs below give only floating-point transcription evidence. Unknown \(\gamma\) does not prevent running the optimization, but converting its objective accuracy to a specified frame accuracy requires a justified lower bound. Formula (6) also needs fresh independent rounding randomness.

## 7. Necessary failure boundaries

**Zero contrasts:** if \(G=\mathbf1\mathbf1^T\), then \(f(x)=\|x\|^4\). Every orthogonal frame represents the same polynomial, every feasible tensor in (S) is optimal, and frame acquisition is unidentifiable.

**Negative contrasts:** already in dimension two, take \(G=\left[\begin{smallmatrix}1&2\\2&1\end{smallmatrix}\right]\), so \(w_{12}=-2\). The feasible isotropic moment obtained from the two diagonal directions \((e_1\pm e_2)/\sqrt2\) has objective \(3/2\), whereas the coordinate-axis moment has objective one. Thus this SDP intentionally selects a different frame outside its contrast promise. An out-of-promise success is not a hidden-convexity certificate.

**No uniform stability without a gap:** for an orthogonal frame \(U\), put

\[
 f_{U,a}(x)=\|x\|^4+a\sum_i(u_i^Tx)^4,\qquad a>0.
\]

This has \(G=\mathbf1\mathbf1^T+aI\succ0\) and \(\gamma=2a\). Rotate just one coordinate pair by angle \(\theta\) to obtain \(V\). Direct tensor inner products give

\[
 \|T_{U,a}-T_{V,a}\|_F=\sqrt2 a|\sin(2\theta)|.
 \tag{7}
\]

For small \(\theta\), midpoint observations are compatible with both frames under noise of order \(\gamma|\theta|\). Therefore any uniformly accurate acquisition procedure must incur axis uncertainty \(\Omega(\sigma/\gamma)\). Taking a fixed nontrivial rotation and \(a\to0\) disproves uniform stability from strict convexity alone. The rational orthogonal rotation with cosine \(3/5\), sine \(4/5\) provides the same obstruction under the source's rational-frame interface. This is an information obstruction, not a failure of exact coefficient acquisition.

**Missing metric:** (S) constrains the second moment using the known Euclidean metric. Replacing that metric with an arbitrary input-coordinate identity does not make the hidden frame orthogonal. The theorem cannot be applied to unknown general \(L\) without acquiring the aligned metric and bounding its numerical error/conditioning.

## 8. Equally informed baselines and literature refresh

All baselines must receive the same coefficient table, supplied metric, noise model, bit precision, and contrast-margin information. Comparisons against a learner denied coefficients or a spectral method handed \(U\) are invalid.

- [Voss–Belkin–Rademacher, Hidden Convexity of Spectral Clustering](https://arxiv.org/abs/1403.0667): establishes sphere/simplex hidden-basis recovery using admissible separable contrasts. Abstract and supplied source's theorem scope checked. Our coupled quartic SDP should not be called the discovery of hidden convexity.
- [Ma–Shi–Steurer, Polynomial-Time Tensor Decompositions with Sum-of-Squares](https://arxiv.org/abs/1610.01980), [primary author PDF](https://www.dsteurer.org/paper/polytensor.pdf): §§1.1, 1.3 and selected §2.1 statements read. Theorem 1.8 already extracts certifiably unique polynomial solutions; high-entropy moment constraints and spectral rounding are established methods. Their fourth-tensor result also gives linear relative perturbation guarantees under a condition parameter. No exact match for (S) or its coupled-input estimate was located at this read depth. The construction may be a short standard consequence; novelty remains UNKNOWN.
- [Potechin–Steurer, Exact Tensor Completion with Sum-of-Squares](https://arxiv.org/abs/1702.06237): establishes polynomial-time SOS recovery of incoherent orthogonal third-order tensors from partial observations. Its supplied tensor-completion interface differs from acquiring an axis moment from a coupled quartic. Abstract read; complete proof not reconstructed here.
- [Schramm–Steurer, Fast and Robust Tensor Decomposition](https://arxiv.org/abs/1706.08672): established fast spectral competitors match SOS robustness in important decomposition models. Our elementary Gaussian rounding is not an innovation over that literature. Abstract read; applying their sharper rounding theorem would require matching its perturbation norm and rank regime.
- [Zhang et al., Matching Higher-Order Oracle Complexity for Smooth MVIs](https://arxiv.org/html/2609.13462v1): claims \(\widetilde\Theta_p((L_pD^p/\varepsilon)^{2/(3p-1)})\) high-dimensional exact-full-jet complexity for tangent residuals. I read the interface, computation exclusion, and the second-difference-energy proof in §§6–7. The displayed energy argument is internally coherent. The whole acceleration hierarchy/lower bound has **not** been independently audited. Exact Taylor-model VI computation is treated as internal work; the paper does not establish polynomial arithmetic complexity. Its claim must not become an unconditional practical speedup.
- [Zhou, Optimal Oracle Complexity for Finite-Sum Monotone Inclusions](https://arxiv.org/html/2610.05038v1): claims \(O(n+\sqrt nLR/\varepsilon)\) expected component/resolvent evaluations under mean-square Lipschitz continuity, with a matching lower bound for randomized linear-span algorithms. Interface, introduction, and centered-estimate mechanism read; proof not fully audited. Stored difference estimates remove repeated full-sum overhead under that access model. It does not provide a general noisy black-box optimization theorem.
- [Zhou, Sharp First-Order Lower Bounds for Higher-Order Smooth Nonconvex Optimization](https://arxiv.org/html/2606.05438v1): claims deterministic matching \(\Omega(\varepsilon^{-7/4})\) and \(\Omega(\varepsilon^{-5/3})\) bounds in higher-smoothness regimes using block-chain revelation. Introduction and access scope read; construction proof not reconstructed. Randomized/unrestricted extensions cannot be inferred from its deterministic claim.
- [Henrion–Safey El Din, Univariate Moment-SOS Convergence](https://arxiv.org/abs/2609.20544): claims a fixed-instance \(O(r^{-2})\) univariate rate with description degeneracies in constants. Abstract read; full HTML fetch failed. This is not a variable-dimensional polynomial global-optimization algorithm.

Recent optimization manuscripts above are **source-reported claims**, not accepted on the strength of release/AI-review labels. Established older SOS, SDP, and tensor-rounding machinery is the competent retaining baseline.

## 9. Relevant source paths actually inspected

- `work/astra-research-knowledge/00_START_HERE.txt`, `01_CORE.txt`, and `AGENTS.md`.
- `web/pages/d-568bd70a84f4b496.html`: `literature/notes/root_cycle8/HIDDEN_CONVEX_POLYNOMIAL_ACQUISITION.md`. Exact rational coefficients, accessible metric, homogeneous degree charged numerically; extactic/formal-flow acquisition and exact acceptance. The quartic pair-contrast extension is explicit.
- `web/pages/d-a1e7695127862d0d.html`: supplied independent gate of that theorem. Gate agreement is not external certification.
- `web/pages/d-d2f207cd250edcaf.html`: inverse-catalecticant metric construction, route-specific counting cost, and rational natural-selector obstruction. It does not prove hardness of every metric/frame acquirer.
- `web/pages/d-2083f1bb9cd6aca5.html` and `d-7686b09b777b182f.html`: ternary Hessian-field nonvanishing and gate; its projective-plane argument does not transfer automatically to arbitrary dimension.
- `web/pages/d-e225a9d5afab1238.html`, `d-5e4db16f90ed3976.html`, `d-cb1dfd19e189b2af.html`: matrix-Krylov detector, conditional curvature-attractor coverage, and a failed lowest-axis-coefficient proof route. None supplied the isotropic-moment proof above.

## 10. Executed transcription checks

Code: `work/scouts/optimization_sdp_check.py`. Results: `work/scouts/optimization_sdp_check.json`. Command: `uv run work/scouts/optimization_sdp_check.py`; CVXPY + CLARABEL. Six fixed small cases were run after the final script edit. The optimizer receives only the observed tensor. Hidden axes and coupling matrices occur only in fixture construction and retrospective assessment. The rounding function receives the optimized moment; axes occur only in the retrospective matching calculation.

| Fixture | n | Margin | Moment error | Max axis sine error |
|---|---:|---:|---:|---:|
| Coupled PD | 3 | 4 | 1.30e-11 | 2.58e-8 |
| Near radial, repeated diagonal | 4 | 0.1 | 2.05e-11 | Below floating resolution |
| Indefinite G, positive contrasts | 3 | 1 | 1.99e-11 | Below floating resolution |
| Arbitrary tensor noise, sigma=1e-4 | 4 | 0.2 | 1.20e-4 | 1.59e-4 |
| Negative-contrast control | 2 | -2 | 0.7071 | 0.7071 |
| Zero-contrast control | 3 | 0 | 0.3651 | 0.7568 |

All four promised cases satisfy the growth/noise inequalities with the recorded numerical allowance. Negative and zero contrasts show the predicted failure. The negative-contrast control optimizes to approximately 1.5 rather than the coordinate-axis value one. Raw PSD residuals as low as -7.19e-12 were corrected by a numerical affine projection and an inward sphere-moment mix; resulting minimum eigenvalues are positive at about 1e-12 or larger and contraction residuals at most 5.56e-17. A numerical dual upper estimate explicitly charges stationarity error; it is not an exact rational certificate.

The final six-case body took 0.0693 seconds and peak process RSS was 114,950,144 bytes on this macOS host. This excludes first-time package acquisition/import startup. The first dependency setup downloaded about 26.3 MiB of reported numpy/scipy/cvxpy archives and installed 16 packages. These small dimensions and solver statuses validate transcription only; they do not prove (3)–(6), compare asymptotic costs, or demonstrate scaling on a 16-GB computer. No extactic or equally informed SOS competitor was timed, so no speed advantage is claimed.

## 11. Strongest next technical questions and fatal tests

1. Reconstruct (3)–(5) with the exact tensor/catalecticant norm convention. Fatal failures would be loss of full fourth-tensor symmetry, a false PSD cross-block estimate, or silently assuming actual moment representability. The proof explicitly addresses all three.
2. Check Ma–Shi–Steurer and relevant orthotropic/eigentensor/SOS papers for the exact isotropic coupled-quartic program. A matching prior theorem would reclassify this as a useful baseline compiler, not a new result.
3. Extend the small coefficient-only prototype to general supplied \(M\) and exact rational residual verification, then compare the same input with the source's extactic implementation and ordinary quartic SDP. Repeated diagonal entries, near-radial contrasts, negative-contrast controls, and arbitrary additive tensor noise are already in the small transcription suite. A faster fixture is not an asymptotic result.
4. Acquire coefficients economically from permitted value/gradient observations. A dense table costs \(\Theta(n^4)\) entries; sparse or oracle access does not make it free. Any interpolation/sampling campaign must state its precision, noise amplification, queries, and output norm before claiming total-cost savings.

Expected value: high for a concise, checkable scoped theorem and robust baseline; moderate for new mathematical novelty; low as evidence for an unrestricted local-intelligence breakthrough. The load-bearing expansion to unknown nonorthogonal coordinates is still aligned-metric acquisition.

Memory use was only a quick check that earlier hidden-convex acquisition work and equal-access costs were provisional; current repository/source inspection supplied the working facts. Memory registry handle: `MEMORY.md:197-207`.
