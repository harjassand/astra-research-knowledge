# Rounding/discrepancy scout — 7 October 2026

## Decision

**Best near-term target: an acquired, exact rational small-defect rounder with an explicit sparse law, first for cubes and partition bases.** I derived and executed this narrower mechanism. It removes N14's supplied signing oracle and its unexecuted ellipsoid extraction, at the cost of replacing `log(R/µ)` by `log R`. It does **not** validate P-round's general polytope construction or constitute a foundational discrepancy breakthrough. Binary coarsening, conditional expectations and cardinality rounding have substantial prior art; priority of this exact composition is unestablished.

**Higher-upside next step:** obtain the entropy-sensitive balanced signing bound by a certified finite-bit engine and plug it into this compiler. That would acquire the sharp N14 interface without relying on an exhaustive signing oracle. For unrestricted matroids, a genuinely new local exchange/rounding mechanism remains necessary; arbitrary exchanges do not provide the simultaneous exchange directions used below.

A quantitative negative-dependence obstruction is also proved below. It rules out a tempting cheap acquisition route, while leaving hard rounding itself easy on the example.

## Source/interface audit

Read source snapshot `work/astra-research-knowledge/00_START_HERE.txt`, `01_CORE.txt`, `AGENTS.md`, `cards/P-round.txt`, `cards/N14-small-mass-rounding.txt`, `cards/W-rounding-spectral.txt`, and the decisive N14 derivation in `web/pages/d-16707e68180fb066.html` (section 1). The report wrapper is `web/pages/d-e5a1430b148e5070.html`; prior exact handoff is `web/pages/d-8f0b200475145312.html`. These are internal/source-derived records, not independent proof certificates.

- **P-round:** claims a dimension-independent hard feature radius `O(k(P))`, exact prescribed means and at most `n+1` rational atoms for Boolean polytopes, conditional on exact strong optimization for every rational objective. Its claimed finite-bit construction is extremely elaborate: minimal-face acquisition, cost-slice endpoints, spectral barriers, negative-curvature directions, rational repair, and favorable-response hull extraction. The longest-edge midpoint lower bound and face dimension ratio are easy to reconstruct; they do not establish that full upper-bound trajectory. The memory record reports that the earlier fixtures did not execute it (`MEMORY.md:207-216`), which agrees with the currently supplied card's explicit implementation gap.
- **N14:** the stochastic dyadic cube construction is sound relative to a certified classical signing routine. Its supplied checker used exhaustive balanced signings. Sparse support was asserted through Carathéodory/favorable-oracle extraction, rather than executed with a general ellipsoid engine. Its four-atom stable-support counterexample is a separate obstruction, not a disproof of cube rounding.
- **Acquisition boundary:** in the construction below, rational `A` and `p` are inputs, not learned features. Cube geometry and partition blocks are explicit. No optimization, signing, separation, Gibbs-preparation or teacher oracle remains. Acquiring or estimating the actual feature matrix is a separate charged task. In P-round, arbitrary strong optimization can hide a difficult combinatorial optimization problem; an oracle-polynomial claim is not an affordable acquisition theorem. Matroid independence permits known rank/SFM machinery, but the entire exact face/barrier composition still requires implementation and audit.

## Live primary refresh

1. [Lovett–Meka, Constructive Algorithms for Discrepancy Minimization by Walking on the Edges](https://arxiv.org/html/1203.5747v2): inspected the partial-coloring theorem/interface. This is the established entropy-sensitive signing foundation; an approximate partial-coloring result is not itself an executed exact rational full-signing engine.
2. [Doerr–Friedrich–Klein–Osbild, Unbiased Matrix Rounding](https://arxiv.org/html/cs/0604068): read Theorem 3 and binary-coarsening/randomization sections. Unbiased bitwise rounding and randomized truncation are old mechanisms. Their matrix prefix constraints differ from arbitrary supplied feature rows; this is still decisive prior art against treating dyadic unbiasedness as new.
3. [Doerr, Roundings Respecting Hard Constraints](https://doi.org/10.1007/s00224-006-1318-7): primary abstract establishes disjoint cardinality constraints and randomized/derandomized rounding as prior work. Full proof was not reconstructed here. A claim of first partition-base extension would be premature.
4. [Bansal, On a Generalization of Iterated and Randomized Rounding](https://arxiv.org/html/1811.01597v3): inspected Theorem 1.2, the sub-isotropic covariance construction and update interface. It combines exact expectations, iterated-rounding guarantees and Bernstein-type concentration given dimension slack. Concentration permits rare bad outputs; it does not directly supply a law whose every supported atom meets the specific Euclidean-column hard bound.
5. [Bansal–Nagarajan, Approximation-Friendly Discrepancy Rounding](https://arxiv.org/html/1512.02254v2): inspected the matroid oracle and Theorem 5. It provides prior matroid-feasible discrepancy rounding via independence access, so matroid feasibility alone is not new.
6. [Li, Fast Spectral Signing for Vector Balancing](https://arxiv.org/html/2609.30044v1) and [Akbas–Sra, Tighter Bounds on Komlós Discrepancy](https://arxiv.org/html/2609.27172v2): live September manuscripts claim constants below 99 and 37.54, respectively. Li also claims polynomial rational bit complexity. The Perron-gap lemma and stated field-operation interface were inspected; neither entire proof was independently rebuilt here. Do not certify Komlós or import these constants as established from abstract/source agreement. My new implementation does not use either result.
7. [Anari–Haqi–Ma, On Rounding on the Hypersimplex](https://arxiv.org/abs/2606.00996) versus its [first-version HTML](https://arxiv.org/html/2606.00996v1): the current abstract says the spectral bound is conjectural; v1 HTML states a theorem via Hodge–Riemann. This version distinction matters.
8. [Cesari–Colomboni, Sharp Normalized Covariance Bounds and Constant-Stretch Correlated Sampling on the Hypersimplex](https://arxiv.org/html/2607.13990v2): July v2 identifies the old proof gap and claims `C ⪰ D-vvᵀ/Σv`, hence stretch 6/12. I inspected its inertia reduction, not every Schur identity. This update shifts the target to auditing/acquiring the sampler. Prescribed marginals still do not supply inverse external weights or a finite-bit exact sampler.

The broad 312-page [Ercan convex-order manuscript](https://arxiv.org/abs/2609.38228) claims additional hard constraints and convex-order laws. I checked its live scope but did not treat the extraordinary omnibus claims as foundations. P-round already records the distinction between strongly base-orderable exchanges, general matroids, Gaussian convex order and outcome-wise hard feature bounds.

## Original construction A: explicit sparse cube law without signing oracle

**Theorem, internally derived; not externally reviewed.** Let rational `A∈[-1,1]^{R×n}`, `R≥1`, and rational `p∈[0,1]^n` be supplied. Set

`µ=Σ_j min(p_j,1-p_j)`, `r=ceil(log₂(2R))`.

A deterministic rational algorithm outputs a finite law with at most `dim F_cube(p)+1≤n+1` positive atoms `z∈{0,1}^n`, freezes every prescribed 0/1 coordinate, and has

`E Z=p`,

`||A(z-p)||∞≤1+µ≤2` if `µ≤1`,

`||A(z-p)||∞<1+12 sqrt(rµ)` if `µ>1`.

Thus `2+12 sqrt(rµ)` is a uniform bound. No row/column normalization beyond `|a_ij|≤1` is assumed. There is no approximation of the mean.

### 1. An elementary acquired balanced signing

For an active set of `s` coordinates, pair coordinates arbitrarily. If `s` is odd add one dummy zero column. A pair `(a,b)` receives opposite signs, so each original signing has total sign sum 0 for even `s` and absolute sum 1 for odd `s`.

Write the row's paired difference coefficients as `d_t=a_it-a_iu`, and `Y_i=Σ_t d_t η_t` for independent fair signs `η_t`. Since `|a_ij|≤1`,

`Σ_t d_t²≤2s`.

Coefficient comparison between `Π cosh(d_t z)` and `exp(z² Σd_t²/2)` gives

`E Y_i^{2r}≤(2r-1)!! (Σd_t²)^r≤(4rs)^r`.

Consequently

`E Σ_i Y_i^{2r}≤R(4rs)^r<(8rs)^r`.

Fix each `η_t` to the choice with the smaller conditional value of the polynomial `Σ_i Y_i^{2r}`. Conditional expectations never increase. The final result therefore satisfies

`|Y_i|<sqrt(8rs)` for every row.

All expectations are exact rational polynomials. They can be evaluated with suffix moment arrays through degree `2r`; odd suffix moments vanish. This costs `O(R s r²)` field operations and has polynomial bit complexity because the degree is `O(log R)`. No floating-point normal approximation, exponentials, eigenvectors, or signing search is used. The bound is weaker than Spencer's `sqrt(s log(R/s))`, which is exactly the remaining sharpness gap.

### 2. One shared uniform gives a small initialization law

Center around the nearest Boolean vertex: `b_j=1[p_j>1/2]`, `t_j=min(p_j,1-p_j)`, replace `A` by `A diag(1-2b)`. This reduces to `t∈[0,1/2]^n` with total mass `µ`.

For `µ≤1`, use zero with weight `1-µ` and `e_j` with weight `t_j`.

Otherwise set `J=ceil(log₂ n)`, `g=2^-J`, `l_j=g floor(t_j/g)`, and `α_j=(t_j-l_j)/g`. Take

`q_j(U)=l_j+g 1[U<α_j]`, one shared `U∼Unif[0,1]`.

Sorting the `n` rational thresholds gives at most `n+1` rational atoms. Their mean is exactly `t`; every atom has `||A(q-t)||∞≤ng≤1` and mass at most `µ+1`. Independent initialization is unnecessary.

### 3. Coarsen, branch and compress

At level `h=J,...,1`, the odd dyadic numerators form `S_h`. Use the acquired balanced signing and branch each current atom into its two fair orientations:

`q'_j=q_j±2^-h ξ_j` for `j∈S_h`.

Both outputs stay in the cube and lie on the next grid. Their average is the parent atom. Their total mass changes by at most `2^-h`, so throughout every retained trajectory mass is below `µ+2<3µ`. Also `s_h≤2^h(µ+2)` because each active coordinate is at least `2^-h`.

The cumulative row error is therefore less than

`1+sqrt(24rµ) Σ_{h≥1}2^-h/2 = 1+sqrt(24)(1+sqrt(2)) sqrt(rµ) < 1+12 sqrt(rµ)`.

After each level, merge duplicate atoms and find an exact affine dependence among the at most `2(n+1)` current atoms. Move the weights along that dependence until one becomes zero; repeat until the columns `[1;q]` are independent. This preserves the current pooled mean exactly and retains only existing atoms. Therefore the hard error/face/mass certificates survive. At the next level there are again at most `n+1` atoms. This is the point that removes the general ellipsoid extractor: compression happens before an exponential trajectory tree is ever formed.

### Costs and bit heights

There are at most `(n+1)J` signing calls. A straightforward implementation costs

`O(R n² J r²+n⁴ J)` rational field operations,

including repeated Gaussian elimination for compression. Faster exact dependence updates are possible but unneeded for this claim. Reading/retaining `A` costs `Θ(Rn)` entries.

At grid level `h`, integer dependence coefficients can be chosen as minors of `[1;2^h q]`, with `O(n(h+log n))` bits. Each deletion multiplies a common weight denominator by at most one such integer. At most `O(nJ)` deletions therefore give polynomial intermediate bit heights, rather than an unchecked growing-denominator recurrence. The initial common denominator has at most the total input bits of `p`. At the Boolean endpoint, affine independence and Cramer's rule bound reduced weight denominators by `Q exp(O(n log n))`, for `Q` a common denominator of `p`.

**Sharp-N14 option:** replace the moment engine with a certified Spencer/Lovett–Meka engine on pair-difference columns. Opposite signs within pairs automatically enforce the mass balance. The same sparse compiler then gives the sharper `C[1+sqrt(µ log(8R/µ))]` without any ellipsoid. This option is conditional until the signing engine is acquired. The elementary option matches the sharper order whenever `µ≤R^{1-ε}` for fixed `ε>0`, with an `ε^-1/2` factor.

## Original construction B: partition bases and arbitrary near-vertex defect

**Theorem, internally derived; not externally reviewed.** Additionally supply disjoint blocks `B_a` and integer quotas `k_a`, with `Σ_{j∈B_a}p_j=k_a`. There is a deterministic rational law with the same support/mean/face guarantees, every atom satisfying every block quota, and hard bound

`||A(z-p)||∞≤2+µ<3` when `µ<1`,

`||A(z-p)||∞<1+20 sqrt(rµ)` when `µ≥1`.

The operation/bit bounds above still apply. This is a partition-matroid base result, not an unrestricted matroid result.

**Initialization.** At mesh `g`, in each block the sum of fractional parts of `p_j/g` is an integer. Systematic sampling with one common uniform and cumulative fractional-part intervals rounds these parts to 0/1 while preserving their block sum exactly. Across all blocks, there are at most `n+1` breakpoints/atoms. Each coordinate changes by less than `g`, so feature error is at most 1 and defect relative to the fixed nearest vertex `b` is at most `µ+1`.

**Coarsening directions.** Every block has an even number of odd dyadic numerators. Pair active coordinates of the same baseline type first. Each same-type exchange `e_i-e_j` preserves both its quota and total defect. At most one mixed-type pair remains per block. Orient each as `(baseline 0)−(baseline 1)`, then pair these exchanges across blocks and use their difference. Each such four-coordinate direction preserves every quota and total defect. At most one mixed exchange remains unpaired, with defect derivative ±2.

The directions have disjoint supports, coefficients ±1, and each row's total squared direction coefficient is at most `4s`. The same even-moment procedure now gives row increment `<sqrt(16rs)`. Fair orientation preserves the mean; total defect changes by at most `2·2^-h`. Thus defect stays below `µ+3≤4µ`, active size satisfies `s_h≤2^h·4µ`, and summing gives `1+8(1+sqrt(2))sqrt(rµ)<1+20sqrt(rµ)`.

If `µ<1`, the nearest vertex `b` already satisfies every quota: its integer quota error has absolute value less than 1. Pair the deficit mass on baseline-1 coordinates with surplus mass on baseline-0 coordinates within each block by a rational transportation flow. Use the one-exchange vertices with those weights and `b` with weight `1-µ/2`. This is an exact-mean law; each atom changes at most two coordinates and has error at most `2+µ`.

**Why this does not silently extend to a general matroid.** Arbitrary pairings within active coordinates are feasible in partition bases. General matroid base exchange gives individual exchanges; it does not guarantee that every simultaneous subset/orientation of a family of exchanges remains a base. P-round's K4 complementary-exchange Hall failure is a valid gate here.

## Original obstruction: stable/negative-cylinder sampling can be exponentially wasteful

Consider a partition matroid whose blocks are disjoint pairs, exactly one element chosen from every pair, all prescribed coordinate means `1/2`. Let a law satisfy the upper negative-cylinder inequality

`Pr(all coordinates in T are 1)≤Π_{j∈T} E Z_j`.

For each complete pair choice, the all-ones event selecting its one chosen coordinate from every pair identifies exactly that output. Its probability is at most `2^-r`. There are `2^r` possible outputs and these upper bounds sum to one. Hence **every** such law must be the uniform independent product over pair choices. The same argument with arbitrary pair marginals forces their corresponding product law. Strongly Rayleigh/negatively associated laws have this upper-cylinder property.

Now divide the pairs into `q` feature blocks of an even number `t=2l` of pairs. In feature block `a`, put column `+e_a` on each left element and `−e_a` on each right element. Columns have Euclidean norm 1 and actual polytope edges change only two coordinates. The feature row error is a sum of `t` independent fair signs under the forced product law.

For a desired hard radius `B`, choose `l≥4(B+1)²`. There are at most `floor(B)+1≤B+1` central parity-compatible values. The elementary bound `binom(2l,l)/4^l≤1/sqrt(l+1)` gives

`Pr(|row error|≤B)<1/2`.

Feature blocks are independent, so the product law assigns at most `2^-q` probability to the all-rows hard-good event `G`. Any law supported on `G` is therefore at TV distance at least `1−2^-q` from it; rejection sampling from it takes expected at least `2^q` draws.

Meanwhile choose a fixed perfectly balanced alternating pattern in every feature block and its global complement, each with probability `1/2`. This **two-atom** law has all means `1/2` and zero feature error. Thus the example is an obstruction to acquiring a hard rounder from a stable/negative-cylinder reference by rejection, not to rounding, exact means, short edges, or arbitrary MCMC. It strengthens the prior disjoint-pair negative-correlation observation by quantifying TV and sampling cost.

## Optional spectral acquisition consequence (conditional on the July theorem)

Let `ν_p` be the rejective/maximum-entropy fixed-cardinality law with interior prescribed marginals `p`. The July bound implies, on the zero-sum tangent space,

`δᵀ C_p^† δ≤Σ δ_j²/[p_j(1-p_j)]`.

The Hessian of the convex negative maximum-entropy function in marginal coordinates is `C_p^†`. The Hessian of the sum of Bernoulli negative entropies is the diagonal matrix on the right. Integrating the Hessian inequality along a segment yields the independently derived consequence

`KL(ν_p || ν_q)≤Σ_j KL(Ber(p_j)||Ber(q_j))`.

Rational external weights give rational marginals/conditional probabilities by elementary-symmetric dynamic programming. The inequality certifies output-distribution error for approximate inversion, not exact means or hard atom bounds. The July theorem remains an unaudited dependency.

## Executed evidence and limits

Files:

- `work/scouts/rounding_sparse_compiler.py`
- `work/scouts/rounding_sparse_compiler_checks.json`
- `work/scouts/rounding_partition_compiler.py`
- `work/scouts/rounding_partition_compiler_checks.json`
- `work/scouts/rounding_covariance_probe.py` (exploratory numerical spectral probe only)

Run `python3 work/scouts/rounding_sparse_compiler.py` and `python3 work/scouts/rounding_partition_compiler.py` from the root cwd.

The cube implementation passed **625 exact rational grid laws** and five additional fixtures. The partition implementation passed **343 exact rational pair-base laws** and six additional fixtures, including a 9-coordinate instance with a five-element block. Tests independently recompute normalization, positivity, binary feasibility, each coordinate mean, forced-face coordinates, quota sums, the actual row error, and signing squared bounds. Non-dyadic cases exercised both real coarsening and affine dependence deletion. Largest current fixture is only 12 coordinates; timings of about one second are fixture timings, not a scalable benchmark. Exact arithmetic avoids numerical bias but this Python implementation has not been optimized or independently audited.

The finite tests support execution/algebra, not the general moment proof, asymptotic correctness, broad practical scaling, external validation or novelty. No repository source was edited; no general P-round trajectory was executed.

## Ranked next questions and fatal tests

| Rank | Target | Why / current result | Fatal test or remaining debt |
|---|---|---|---|
| 1 | Certify and benchmark entropy-sensitive finite-bit signing inside the sparse compiler | Highest tractability; acquired moment engine and sparse law already work, cube/partition scope explicit | Compare against full Doerr/Pusher–Chooser prior; execute fresh Fourier/quantized-feature families with rational interval bounds, charge input acquisition and all signing/compression costs. If existing certified software already gives the same full interface, this is implementation rather than new mathematics. |
| 2 | Independently implement/audit the general-matroid constant Euclidean-column rounder | Large theorem/application upside if P-round is correct; current card gives the exact missing composition | First genuine rational spectral trajectory must hit a non-coordinate face, retain exact cost slice, and survive cumulative repair. Fixtures that only check geometric dimensions fail the gate. Direct practical relevance is doubtful with the card's tiny global step. |
| 3 | Acquire a rational/lazy maximum-entropy sampler with certified parameter inversion and output TV | July covariance update supplies a promising sensitivity interface; KL certificate derived | Preserve exact versus approximate means, rational versus irrational external weights, finite random-bit cost. Do not impose arbitrary hard features via negative-cylinder rejection: the explicit exponential example kills that route. |

**Strongest next technical question:** Can a finite-bit Spencer/Lovett–Meka implementation return certified balanced full signings with `C sqrt(s log(8R/s))` at affordable measured cost on acquired rational Fourier matrices, and can the sparse compiler preserve that advantage versus direct cardinality rounding plus existing discrepancy solvers? That is concrete, falsifiable and materially narrower than asking another agent to reconstruct all of P-round. Expected value is moderate implementation/acquisition progress; this branch should not outrank a genuinely new theorem elsewhere in the campaign merely because it now has runnable code.
