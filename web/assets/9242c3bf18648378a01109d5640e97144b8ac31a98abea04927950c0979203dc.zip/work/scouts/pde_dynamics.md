# PDE and dynamics scout, 7 October 2026

The best candidate from this scout is **quantitative local anisotropic rigidity relative to a Euclidean reference, with a finite boundary-measurement certificate**. A complete analytic derivation is recorded below. It uses a classical Carleman primitive, and was prompted by a September 2026 primary paper rather than the repository's extraordinary PDE headlines. Status: internally derived theorem candidate, **not independently certified and not a priority claim**. The exact time-modulated Couette calculation is a second, safer target. Nonlinear blowup spectral certification ranks third because the unresolved spectral/high-frequency gate is substantially deeper.

## 1. Source scope and frontier refresh

Repository files actually read: `00_START_HERE.txt`, `01_CORE.txt`, `AGENTS.md`, `topics/analysis.txt`, `cards/W-frontier-dynamics.txt`, `cards/W-frontier-analysis.txt`, `cards/W-pde-gate9.txt`, `cards/W-pde-spectrum9.txt`, `cards/W-pde-transport9.txt`, `cards/W-charges-design9.txt`, and the PDE title/assessment records in `indexes/families.json`, all below `work/astra-research-knowledge/`. None of the released RVM, Boltzmann, inverse metric/connection, elasticity, or forced-computation headline proofs was adopted. The source snapshot itself distinguishes conditional extensions, finite algebra checks, and unknown headline proofs.

Primary literature checked live:

- [Yi-Hsuan Lin, anisotropic Calderon rigidity near Euclidean geometry, arXiv:2609.17261v1](https://arxiv.org/html/2609.17261v1), 15 September 2026. Technical Sections 2–4 and the metric theorem/interface were read. The result is rigidity at one Euclidean reference; its principal-part argument only operates on a perturbation-dependent finite frequency range. This is a new preprint, not an externally certified result in this report.
- [Munoz-Thon–Stefanov, local rigidity of conformally Euclidean metrics, arXiv:2609.13400v4](https://arxiv.org/html/2609.13400v4), revised **6 October 2026**. Original v1 Euclidean mechanism and exact v4 theorem/interface were inspected. V4 admits every fixed smooth conformally Euclidean reference, with a harmonic-embedding gauge and compactness argument; no small conformal-factor assumption remains. Its general-background proof does not provide an explicit local threshold. No advertised quantitative noise theorem was found, but an absence claim beyond the inspected material is not made. V1 titles/search snippets are stale for the present frontier.
- [Krupchyk–Uhlmann, bounded magnetic potential, 2014](https://sites.math.washington.edu/~gunther/publications/magneticbounded.pdf). PDF pages 3–5 were downloaded, rendered and inspected, including Propositions 2.1–2.2. The two-derivative Carleman estimate in semiclassical orders -1 and +1 is the established primitive used below. Local copy: `work/scouts/pde_sources/KU2014.pdf`, rendered pages `KU2014-03.png` through `KU2014-05.png`.
- [Benthaus–Nobili, time-modulated enhanced dissipation, arXiv:2501.16905v2](https://arxiv.org/html/2501.16905v2), 3 September 2025. The setup, Theorems 1–2 and their functional/energy interfaces were read. The modulation is nonnegative. Activation and acceleration estimates impose additional bounds; arbitrary sign-changing modulation is outside their theorem.
- [Coble–He, time-dependent shear enhanced dissipation and Taylor dispersion, arXiv:2309.15738v1](https://arxiv.org/html/2309.15738v1), 27 September 2023. The monotone/nondegenerate profile interfaces were inspected. Spatial nondegeneracy and temporal behavior cannot be replaced by an unqualified instantaneous stirring norm.
- [Daude–Kamran–Nicoleau, anisotropic Painleve–Liouville stability, arXiv:2602.13703](https://arxiv.org/abs/2602.13703), February 2026. Abstract/interface only: logarithmic stability for a separable conformal-product class. This is a comparator, not a theorem used in the derivation.
- [Cao-Labora–Gomez-Serrano–Shi–Staffilani, nonradial defocusing NLS implosion, arXiv:2410.04532v1](https://arxiv.org/html/2410.04532v1), 6 October 2024. Introduction, Madelung mechanism, exact main theorem and profile repulsivity conditions were read. The displayed concrete theorem is the cubic equation in dimension eight, and the initial-data set has finite codimension. Smooth nonradial construction does not automatically mean an open basin of nonlinear stability.
- [Merle–Raphael–Rodnianski–Szeftel, energy-supercritical defocusing NLS blowup, arXiv:1912.11005](https://arxiv.org/abs/1912.11005). Older established mechanism: compression through hydrodynamic profiles rather than a focusing soliton. Only the interface was refreshed here.
- [Zexing Li, slightly mass-supercritical NLS low-energy mode stability, arXiv:2507.11248](https://arxiv.org/abs/2507.11248), July 2025. Abstract only; explicitly a low-energy spectral result for the focusing sign. No full asymptotic-stability theorem was inferred.

Exact downloaded primary source snapshots are `work/scouts/pde_sources/Lin_2609.17261v1.html`, `MunozThon_Stefanov_2609.13400v4.html`, and `Benthaus_Nobili_2501.16905v2.html`; URLs, byte sizes and SHA-256 hashes are recorded in `work/scouts/pde_sources/retrieval_ledger.json`. No source code was executed.

These sources support a mechanism-based ranking. The conservation laws in supercritical NLS do not control the scale-critical high norm. Exact local conservation in kinetic weak solutions likewise would not, by itself, imply uniqueness. The frontier worth pursuing is a quantitative acquisition/stability gate, rather than another unconstrained singularity headline.

## 2. Candidate theorem: noisy anisotropic rigidity in a supplied gauge

Let n >= 3, let Omega be a fixed smooth bounded domain, and let K compactly contained in Omega be fixed. Let

    A = I + H,
    H in C_c^infinity(K; Sym_n(R)),
    div H = 0,
    s = n/2 + 1,
    M = ||H||_{H^s(R^n)} <= m_0.

Here `div H = 0` is columnwise distributional divergence. The positive threshold m_0 depends on the fixed geometry. All these promises, especially the gauge and support collar, are supplied. Define

    X = ||H||_2,  delta = ||H||_infinity,
    epsilon = ||Lambda_A - Lambda_I||_{H^{1/2} -> H^{-1/2}}.

**Internally derived conclusion:** for sufficiently small m_0 and epsilon,

    X <= C [log(1/epsilon)]^{-s}.

At epsilon = 0 the conclusion is H = 0. Constants are uniform within this supplied class. This is distance to the fixed reference I. It is not a pairwise inverse theorem for two unknown anisotropic conductivities, a noisy metric gauge theorem, or an unrestricted Calderon solution. No optimality of the logarithmic exponent is asserted.

### 2.1 Boundary residual replaces exact exterior vanishing

For a complex null vector zeta, let u solve the A-Dirichlet problem with boundary value exp(zeta dot x), and set

    w = u - exp(zeta dot x) in H_0^1(Omega),
    r = exp(-zeta dot x) w.

Extend w and r by zero into R^n, and choose a larger bounded open set O with closure(Omega) compactly contained in O. The extensions lie in H^1(R^n) and have compact support in O even though, with noisy data, they need not vanish in an interior boundary collar.

Put B = Lambda_A - Lambda_I and q_zeta = B[exp(zeta dot x)]. Weak integration by parts gives, globally,

    -div(A grad w) = div(H grad exp(zeta dot x))
                     + q_zeta delta_{boundary Omega}.

Because div H = 0 and zeta dot zeta = 0, conjugation gives

    (P_zeta + Q_H,zeta) r = zeta^T H zeta
                         + exp(-zeta dot x) q_zeta delta_{boundary Omega},

    P_zeta = -Delta - 2 zeta dot grad,
    Q_H,zeta r = -div(H grad r) - 2 H zeta dot grad r
                 - (zeta^T H zeta) r.

This equality explicitly retains the conormal jump. Dropping it would illegitimately reuse the noiseless compact-corrector proof.

### 2.2 Charge the boundary source in the correct norm

Write rho = |zeta| and h = sqrt(2)/rho for large rho. Define

    ||v||_{H_h^1}^2 = ||v||_2^2 + h^2 ||grad v||_2^2.

The classical free Carleman estimate, after bounded imaginary modulation, is

    h ||r||_{H_h^1} <= C ||P_{zeta_0,h} r||_{H_h^{-1}},

where zeta_0 = h zeta has orthogonal unit real and imaginary parts. KU2014 Proposition 2.1 at Sobolev order -1, with fixed convexification and its bounded removal, supplies this estimate. Uniformity over directions follows by rotations of a ball containing O. Extension from smooth compactly supported functions to H^1 compactly supported functions uses approximation inside O.

The principal perturbation satisfies

    ||Q_{H,zeta_0,h} r||_{H_h^{-1}} <= C delta ||r||_{H_h^1}.

This follows directly by testing the divergence term and the two lower-order terms against H_h^1 functions; no derivative of H is charged or hidden in this bound.

B annihilates constants. The trace/extension estimate gives

    ||exp(zeta dot x)-1||_{H^{1/2}(boundary Omega)}
       <= C rho exp(C rho),
    ||q_zeta||_{H^{-1/2}} <= C epsilon rho exp(C rho).

For a global test psi,

    ||exp(-zeta dot x) psi||_{H^{1/2}(boundary Omega)}
       <= C (1+rho) exp(C rho) h^{-1} ||psi||_{H_h^1}.

Consequently the boundary source belongs to H_h^{-1}, with the explicit safe bound

    ||exp(-zeta dot x) q_zeta delta_boundary||_{H_h^{-1}}
       <= C epsilon rho(1+rho) h^{-1} exp(C rho).

After multiplying the conjugated equation by h^2, Carleman absorption is legal whenever delta <= c h, equivalently rho <= c/delta. Polynomial rho factors can be absorbed into a changed exponential constant. Thus for large legal rho,

    ||(grad+zeta)r||_2 <= C rho^2 [X + epsilon exp(C rho)].

For bounded rho, a direct coercive energy estimate for w gives

    ||(grad+zeta)r||_2 <= C rho X.

The latter estimate does not require small DN error. All supports and constants are fixed by Omega and K, not by the unknown tensor.

### 2.3 Mixed identity and low-frequency cancellation

For nonzero real xi, take a real unit theta perpendicular to xi and set

    zeta = |xi|/2 (theta + i xi/|xi|),
    eta  = |xi|/2 (-theta + i xi/|xi|).

Both vectors are null and zeta + eta = i xi. Pair the actual A-harmonic u with the explicit Euclidean harmonic exp(eta dot x). The mixed DN identity is

    zeta^T H_hat(-xi) eta
       + integral exp(i xi dot x) (H(grad+zeta)r) dot eta
      = <B exp(zeta dot x), exp(eta dot x)>.

Since B is symmetric and annihilates constants, BOTH boundary exponentials can be replaced by their differences from 1 in the data pairing. Its magnitude is at most

    C epsilon |xi|^2 exp(C |xi|).

This cancels the |xi|^{-2} factor used to recover the Fourier tensor. There is no unjustified singular noise bound at xi = 0.

div H = 0 implies H_hat(xi) xi = 0, so

    zeta^T H_hat(-xi) eta
        = -|xi|^2/4 theta^T H_hat(-xi) theta.

Real transverse polarization recovers the symmetric tensor. Cauchy–Schwarz and the corrector estimate yield

    |H_hat(xi)| <= C(1+|xi|) X^2 + C epsilon exp(C |xi|)

for |xi| <= c/delta, provided X <= 1. The inequality extends to xi = 0 by continuity.

### 2.4 Self-consistent frequency radius yields a logarithm

For 1 <= R <= c/delta, Fourier splitting gives

    X <= C_0 R^s X^2 + C_1 M R^{-s}
         + C_2 epsilon exp(C_3 R).

The R^{n/2} polynomial from integrating the noise is absorbed in exp(C_3 R). If X > 0 choose R = kappa X^{-1/s}, where kappa is a fixed sufficiently small positive constant. Sobolev interpolation gives

    delta <= C X^{1/s} M^{1-1/s},
    R delta <= C kappa M^{1-1/s}.

Small M makes R legal; also X <= M makes R >= 1 after reducing m_0. Choose kappa so C_0 kappa^s <= 1/4, and then m_0 so C_1 m_0 kappa^{-s} <= 1/4. Absorbing these terms yields

    X/2 <= C_2 epsilon exp(C_3 kappa X^{-1/s}).

Let L = log(1/epsilon). If X >= (2 C_3 kappa/L)^s, then the exponential on the right is at most epsilon^{-1/2}. The resulting X <= 2 C_2 sqrt(epsilon) contradicts that polynomial lower bound for sufficiently large L. Hence X <= C L^{-s}. This is a universal analytic argument, not a finite numerical diagnostic.

## 3. Finite boundary acquisition on a ball

This extension removes the infinite-oracle interpretation of the DN error **in one explicit geometry**. Suppose Omega is the unit ball and supp H is contained in the concentric ball of known radius r_0 < 1. The fixed support distance is necessary a priori information. Take real L^2-normalized spherical harmonics Y_{ell,m}, and use the mean-free energy trace norm

    ||f||_E^2 = sum_{ell>=1,m} ell |f_{ell,m}|^2.

This is equivalent to H^{1/2} modulo constants. For the Euclidean harmonic extension v_f,

    ||grad v_f||_{L^2(B_{r_0})}^2
       = sum_{ell>=1,m} ell r_0^{2 ell+n-2} |f_{ell,m}|^2.

The actual A-harmonic extension obeys

    ||grad u_A,f||_{L^2(K)}
       <= (1-delta)^{-1} ||grad v_f||_{L^2(K)}.

Indeed w = u_A,f-v_f has zero trace; testing its equation against w gives ||grad w|| <= delta/(1-delta) ||grad v_f||_K. The mixed identity therefore gives

    |<B f,g>| <= delta/(1-delta)
       ||grad v_f||_{B_{r_0}} ||grad v_g||_{B_{r_0}}.

Let P_L retain harmonic degrees 1 through L and let T be B expressed between energy-normalized input/output coordinates. Each degree > L costs at least r_0^L in the interior. Thus

    ||T - P_L T P_L|| <= 2 delta/(1-delta) r_0^L.

This tail estimate does not acquire an unknown singular-vector basis: the spherical basis and projection are fixed and known.

Use the supplied upper bound delta <= delta_0 < 1. The number of retained real modes is

    d_L = binomial(L+n-1,n-1) + binomial(L+n-2,n-1) - 1
        = Theta_n(L^{n-1}).

Measure each matrix entry

    T_ij = <B [Y_i/sqrt(ell_i)], Y_j/sqrt(ell_j)>

to absolute error at most q. If the measured matrix is T_tilde, then

    ||T|| <= ||T_tilde||_2 + d_L q
             + 2 delta_0/(1-delta_0) r_0^L =: epsilon_cert.

Apply the preceding theorem with the equivalent trace norm to conclude

    ||H||_2 <= C [log(1/epsilon_cert)]^{-s}.

**Charged costs:** d_L prescribed boundary excitations; d_L^2 scalar response coefficients if full output acquisition is counted; degree-L boundary resolution; d_L-dimensional matrix norm computation; certified absolute coefficient precision q; support radius r_0 and the supplied gauge/regularity promises. There is no free infinite DN map, no uncharged basis acquisition, and no statistical guarantee for uncertified measurement noise.

If the measured responses are sufficiently close to the Euclidean responses, a sufficient design for certifying target tensor norm tau uses L = O(tau^{-1/s}), coefficient precision exponential in -C L divided by d_L, and O(L^{2n-2}) measured entries. These are asymptotic sufficient costs, not an optimal lower bound or a practical laboratory runtime. Numerical values of the Carleman constants, m_0, and the final C have not been acquired; a usable numerical threshold requires that additional task. A classical retaining control with the same spherical measurements can implement the same certificate. No intelligence or computation advantage over that control is asserted.

## 4. Independent fallback: exact temporal shear certificate

Consider

    partial_t f + a(t) y partial_x f = nu(t) Delta f

on T_x times R_y, restricted to nonzero horizontal Fourier modes. Assume a is integrable and nu >= 0 integrable on the finite interval; put

    A(t)=integral_0^t a(s) ds,
    M_0=integral_0^T nu(s) ds,
    A_bar_nu=M_0^{-1} integral_0^T nu(s) A(s) ds.

For M_0 > 0, Fourier characteristics and completion of the square give the EXACT kth-mode L^2 operator norm

    ||S_k(T,0)|| = exp[-k^2 Gamma_T],
    Gamma_T = M_0 + integral_0^T nu(s)(A(s)-A_bar_nu)^2 ds.

The norm is an essential supremum in the continuous vertical Fourier variable; narrow L^2 packets attain it arbitrarily closely. When M_0=0 the evolution is unitary. Thus diffusion-weighted variance of the accumulated signed displacement, rather than integral |a| or integral a^2, is the exact scalar certificate.

Example: a(t)=cos(t), nu(t)=nu, and T an integer number of 2 pi periods. Then A(t)=sin(t), its mean is zero, and

    Gamma_T = (3/2) nu T.

The dissipation time remains Theta(nu^{-1}) although the absolute stirring budget grows proportionally to T. In contrast a(t)=1 gives Gamma_T = nu(T+T^3/12), the Couette enhanced-dissipation scale nu^{-1/3}. This decisively falsifies a sign-blind transfer of temporal activation estimates. It does not challenge Benthaus–Nobili's nonnegative-modulation theorem.

For a general smooth periodic spatial profile v(y), bounded primitive A likewise gives a simple obstruction. With smooth datum phi and a fixed horizontal mode k, the inviscid solution is exp(-ik A(t)v(y)) phi(y). If |A(t)| <= C_A, its Laplacian has uniformly bounded L^2 norm. Contractive Duhamel comparison implies ||f_nu(t)-f_0(t)||_2 <= C nu t, so some smooth data retain a fixed norm up to c/nu. This prevents a uniform enhanced-dissipation claim for such signed schedules. Novelty of this elementary obstruction is not claimed.

## 5. Ranked next targets and fatal tests

1. **Known-support noisy anisotropic rigidity and acquisition certificate.** Highest expected value: the new boundary-residual derivation is explicit, uses an established primitive, and produces a measurement-cost statement. First ask another reader to reconstruct the global boundary distribution, its semiclassical trace norm, and the constant-annihilation cancellation. If any of these fails, the candidate collapses. Next search the local-rigidity/stability literature for the same quantitative deduction and scrutinize sharper trace losses, including the latest Munoz-Thon–Stefanov v4 proof. Its arbitrary conformal-background extension is a deeper nearby alternative; the compactness-based gauge makes a quantitative version harder than the present supplied class. A full noisy metric theorem needs stable boundary gauge recovery and support reduction; those are not supplied here. Pairwise comparison of unknown A_1 and A_2 introduces two unknown correctors and does not inherit the quadratic-in-difference estimate automatically.
2. **Temporal-variance hypocoercivity for general shears.** Very tractable exact linear control, moderate upside. Seek a window criterion expressed in the primitive variance that admits sign changes and distinguishes persistent mixing from undone stirring. Fatal test: bounded primitive or a reversal schedule must reproduce the O(nu^{-1}) obstruction. For nonaffine v, the conjugated covariant-gradient operators do not commute, so averaging their quadratic forms is not a proof of decay of the evolving state. A nonlinear perturbation theorem would also need a fully charged shear regularity norm and control of echo/mean-mode interactions.
3. **Auditable mode certificates for nonlinear blowup profiles.** Potential impact is high, but this scout found no short route beyond the known profile/repulsivity and low-energy spectral mechanisms. Focus on an explicitly stated spectral window or unstable-mode count, rather than stability of an entire singularity mechanism. Fatal test: finite-codimension existence cannot be upgraded to an open stable basin, and a low-energy spectrum theorem cannot replace high angular/radiative control. Reject as the immediate leader until a concrete unresolved lemma admits a bounded certificate.

Scientific PDE simulations, formal kernel builds, and new numerical spectral experiments: zero. No source-repository modifications, publication, contact, or paid computation. The new claims here are analytic derivations; historical priority and independent proof audit remain open.
