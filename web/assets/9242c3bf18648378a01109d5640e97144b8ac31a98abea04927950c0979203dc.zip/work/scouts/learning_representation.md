# Learning and representation acquisition scout — 7 October 2026

**Verdict.** The fidelity obstruction for learning arbitrary low probability-rank laws from arbitrary-prefix conditional samples has already been removed by primary literature. Passive acquisition remains obstructed. A new, fully explicit counterexample below rules out transferring the newer low-logit-rank query methods from a teacher that is only accurate on actual trajectories. It works for a four-state source, including a strictly positive version. This is a scoped negative result and an interface correction, not a new universal learner.

## Primary literature refresh and scope

1. **Liu–Moitra, STOC 2025, [Model Stealing for Any Low-Rank Language Model](https://arxiv.org/html/2411.07536).** Definitions 1.1–1.2 and Theorem 1.3 permit chosen-prefix conditional *samples*, not exact source probabilities. Any rank-S length-T law is learned in poly(S, alphabet size, T, 1/epsilon) resources, without fidelity; deployment is an efficient sampler with no more source queries. The mechanism is implicit barycentric spanners and KL projection during change of basis. Lemma 4.6 estimates and caches token probabilities to implement a consistent nearby density oracle. Algorithms 5–6 maintain polynomial stored arrays and coefficients; convex optimization is charged at deployment. I read these interfaces, the density construction, the projection argument, and the algorithm; I did not independently certify every supporting lemma or its finite-bit implementation. An HTML sign error in Algorithm 6's displayed definition of c conflicts with Assumption 7.1; this should be checked against the PDF before implementing.

2. **Golowich–Liu–Shetty, December 2025, [Provably Learning from Modern Language Models via Low Logit Rank](https://arxiv.org/html/2512.09892).** Definitions 4.2–4.3 specify bounded factorization and average logit approximation under independently spliced marginals. Theorem 5.14 uses a logit oracle and learns an approximate model; its sufficient error dependence contains T^31 d^9.5 inside a ninth root. Section 6 explicitly contrasts required rank decay d^-9.5 with measured decay around d^-0.1. Problem 6.2 asks for conditional-sample learning without exponential logit-magnitude dependence. I read the exact error, query, and factor-norm interfaces and the proof's Markov/union-bound step. The theorem's strong splicing promise is substantially stronger than low predictive loss on real source paths.

3. **Mahajan–Kakade–Krishnamurthy–Zhang, COLT 2023, [Learning Hidden Markov Models Using Conditional Samples](https://proceedings.mlr.press/v195/mahajan23a/mahajan23a.pdf).** Theorems 1–2 distinguish exact conditional probabilities from conditional samples plus fidelity. Section 3 located fidelity in operator estimation/error propagation; Proposition 17 gives noisy parity high fidelity. Its Open Problem 1 is the older problem addressed by item 1, so it is not a fresh campaign target.

4. **Han–Jiang–Wu, [Prediction from Compression for Models with Infinite Memory](https://arxiv.org/abs/2404.15454)** is the referenced 2024 paper behind the updated [next-symbol tutorial](https://yanjunhan2021.github.io/paper/BITS.pdf), Theorem IV.5. That tutorial reports cryptographic prediction barriers for large state or output alphabets. I used it only to identify the distinction between statistical rate and computational acquisition; no new theorem here relies on those numerical rates.

These are primary research sources. No broad general-HMM or foundation-model result follows from a conditional-query theorem unless that query service is actually supplied or acquired with all costs counted.

## New technical attempt: low-risk teacher can have exponentially complex spliced logits

The proposed shortcut being tested was: if a teacher Q has very small KL(P||Q) and P has few HMM states, use Q's queried logits as the low-rank oracle for P. This shortcut is false.

**Construction.** Fix k >= 1 and T = 4k+2. The four-state source P emits independent fair bits U_i, each twice:

    U_1,U_1,U_2,U_2,...,U_(2k+1),U_(2k+1).

Two phases times two bit values give a time-homogeneous four-state state-emitting HMM. At an odd position draw a fresh bit; at the following even position copy it. For a positive teacher Q, draw odd bits fairly, and at even positions copy the preceding bit with probability 1-gamma, flip with probability gamma. Change just one additional Q rule: at position 4k+1, if the earlier boundary pair at positions (2k-1,2k) was (0,1), set

    Q(X_(4k+1)=1 | history) = (1 + a chi_(x dot z))/2,
    a = 1/2,
    x=(X_1,X_3,...,X_(2k-3)),
    z=(X_(2k+1),X_(2k+3),...,X_(4k-3)),
    chi_(x dot z)=(-1)^(sum_i x_i z_i).

Otherwise retain the fair rule. Every Q conditional is a positive rational from {1/2,1/4,3/4,gamma,1-gamma}. Q is explicitly evaluable in O(k) operations at the special position, with O(k) stored history bits. No computationally hard teacher is being hidden in the construction.

**Actual-path loss is arbitrarily small.** The special rule is never entered under P. On P's support,

    Q(w) = P(w)(1-gamma)^(2k+1),
    KL(P||Q) = (2k+1) log(1/(1-gamma)),
    TV(P,Q) = 1-(1-gamma)^(2k+1).

For 0 < zeta <= 1 and gamma = zeta/(4k+2), the KL divergence is at most zeta. The trained teacher is therefore an excellent complete-trajectory predictor, not merely a weak one-step fit.

**Spliced logit rank is exponential.** Cut at t=2k-1. Let rows be ordinary source prefixes

    h_x=(x_1,x_1,...,x_(k-1),x_(k-1),0),

and columns be ordinary source marginal suffix blocks

    f_z=(1,z_1,z_1,...,z_(k-1),z_(k-1),0,0).

Each row and each suffix separately occurs in the source. Their concatenation crosses the chosen boundary with the inconsistent pair (0,1). For the next-token column labelled 1, Q's mean-centered binary logit is

    L_Q(1 | h_x f_z) = L (-1)^(x dot z),  L=(log 3)/2.

As x,z range over {0,1}^(k-1), this is L times the N-by-N Walsh matrix, N=2^(k-1). Orthogonality gives H H^T=N I, hence its rank is N. Consequently Q's logit matrix has rank at least 2^(k-1), although the source has four hidden states and KL(P||Q) can be arbitrarily small.

This bad rectangle has probability 1/8 under independent source prefix/suffix marginals. It is not an exponentially rare collection of queried rows or columns. Its *joint concatenation* is rare or impossible under the source.

**Robustness against bounded low-rank approximations.** Let A have rank r on that submatrix, with entries bounded by K in absolute value. Eckart–Young and Walsh orthogonality give

    ||LH-A||_F^2 >= L^2 N(N-r).

Since every entrywise discrepancy is at most L+K,

    average_(x,z) |LH[x,z]-A[x,z]|
        >= L^2/(L+K) (1-r/N).

Including the rectangle probability and a uniform choice of binary next-token column gives average spliced logit error at least

    L^2/[16(L+K)] (1-r/N).

For K=L and r=o(N), this is a constant. For polynomially bounded K it is inverse polynomial, despite arbitrarily small actual-path teacher KL. This is not a claim about unbounded approximations with exponentially large entries.

**Strictly positive source variant.** Let the even source bit copy with probability 1-delta and flip with probability delta, retaining fair odd bits. This is still four-state and assigns positive probability to every word. The same teacher and Walsh submatrix work. Chain rule now gives exactly

    KL(P_delta||Q_gamma)
      = (2k+1) KL(Ber(delta)||Ber(gamma))
        + (delta/2) KL(Ber(1/2)||Ber(3/4)).

Taking delta=gamma^2 and gamma -> 0 makes this arbitrarily small. The splicing rectangle has mass (1-delta)^(2k-1)/8, bounded below by a constant in this regime. Thus the failure is not an artifact of undefined zero-probability conditionals. The query/source density ratio must pay at least order 1/delta at the inconsistent boundary.

**Verification.** `work/scouts/learning_representation_check.py` uses exact rational probabilities. It verifies the normalization, exact joint-TV and KL formulas for k=1,2,3, the positive-source chain-rule formula, and Walsh rank/orthogonality for k=1,...,6. It ran successfully and printed `ALL_FIXTURES_PASSED`. Those checks corroborate the fixtures; the derivation above establishes the all-k result. Historical novelty has not been established.

## Two additional precise boundary calculations

**Adaptive bounded SQ acquisition cannot discover arbitrary dense parity.** For P_s(A,B)=2^(-(d+1))[1+theta chi_s(A)(-1)^B], a bounded query phi has response difference from the uniform null

    Delta_s=theta E_A[chi_s(A) psi(A)],
    psi(A)=(phi(A,0)-phi(A,1))/2,  |psi|<=1.

Parseval gives sum_s Delta_s^2 <= theta^2. A tolerance-tau oracle can answer with the null value for all but at most theta^2/tau^2 masks at each query. Fixing the null transcript also fixes every adaptive query. After q queries at least 2^d-q theta^2/tau^2 masks remain compatible. Distinct P_s,P_t have TV=theta/2, so a single output accurate to less than theta/4 can cover at most one mask. For a uniform unknown mask, even a randomized learner has success at most

    (q theta^2/tau^2 + 1)/2^d

against a valid tolerance oracle. This is an unconditional SQ-interface obstruction, not an unconditional barrier for raw-example algorithms. Arbitrary bounded feature gradients/moments do not acquire the missing dense feature merely because its eventual Hankel margin is large. This is the classical Fourier/SQ mechanism written with explicit accounting, not a novelty claim.

**Joint-TV learning does transfer to prediction on actual paths, without a horizon factor.** Let P,Q be any finite trajectory laws with TV(P,Q)=epsilon, and let D_t be the TV distance between their entire-future conditionals along a P trajectory (define Q conditionals arbitrarily at Q-null histories). Then

    E_P[max_t D_t^2] <= 16 epsilon.

Proof: use R=(P+Q)/2 and posterior pi_t=P(h_t)/(P(h_t)+Q(h_t)). Under R, pi_t is a martingale, and Y_t=E_R[|pi_T-1/2| | h_t] is nonnegative with E_R Y_0=epsilon/2. Conditional Bayes algebra gives D_t <= min(1,8Y_t): when Y_t<1/4, pi_t lies in [1/4,3/4] and

    D_t = E_R[|pi_T-pi_t| | h_t]/[2 pi_t(1-pi_t)]
        <= Y_t/[pi_t(1-pi_t)] <= (16/3)Y_t;

when Y_t>=1/4 the trivial bound suffices. Doob's maximal inequality and P<=2R give P(max D_t>u)<=min(1,8epsilon/u). Integrating 2u times this tail over [0,1] proves the displayed bound. This applies to adaptively selected cuts and simultaneous bounded future readouts. It does not transfer to independently spliced/counterfactual histories, acquire any source query service, or bound a sum of errors over all timesteps. The constant is deliberately conservative; novelty is not claimed.

## Ranked targets and the strongest next question

| Rank | Target | Expected value and fatal test |
|---|---|---|
| 1 | Fully charge a finite-bit implementation of conditional-sample barycentric/KL acquisition; add actual-path future prediction via deterministic prefix replay | High chance of a valid scoped construction because the key theorem exists. Remove an unnecessary conditioning-margin assumption. Fatal test: the source must truly supply repeated conditional completions at chosen histories; passive reset samples do not do so. This is literature implementation/transfer, not a new foundation of passive learning. |
| 2 | Improve average-misspecification dependence for low logit rank by tracking aggregate weighted errors rather than forcing every one of O(N^2 T^2) potential spliced entries to be accurate | High scientific upside, uncertain tractability. The exact point to replace is Theorem 5.14's Eq. (35), followed by its rank-dependent coefficient bounds. Fatal tests: a bounded Walsh rectangle and an adversarially aligned basis error. A generic low-KL teacher promise is already falsified above. |
| 3 | Teacher acquisition under a verifiable bound on the density ratio of query prefixes to actual source prefixes | Narrower, technically tractable. If a query law nu_t satisfies dnu_t/dP_t <= K, chain rule and Pinsker give E_nu TV(P(.|h),Q(.|h))^2 <= K KL(P||Q)/2. If both token laws have probabilities >= beta, mean-centered logit error has expectation <= sqrt(2K KL(P||Q))/beta. Fatal test: neither K nor beta may be free latent information; the pair-copy family forces K to diverge. |

The strongest next technical question is: **Can the low-logit-rank acquisition algorithm operate with a distribution-weighted teacher error certificate under exactly its chosen splice laws, while replacing the uniform Eq. (35) certificate by an aggregate one?** That asks for a real mechanism and exposes all supplied information. Without such a certificate, general teacher-driven representation acquisition is blocked by the explicit four-state example.

The strongest competent comparators get the same conditional/logit queries, all raw observations, and the same deployment compute. Existing direct parity recovery and the published query learner therefore count as controls; learned features cannot be credited with outperforming either merely by changing notation.

## Exact local provenance

Read-only repository entry: `work/astra-research-knowledge/00_START_HERE.txt`, `01_CORE.txt`, `topics/acquisition.txt`, `cards/P-learning.txt`, `cards/N13-passive-parity-boundary.txt`.

Decisive prior acquisition record: `work/astra-research-knowledge/web/pages/d-7a16721d57edc620.html`, original path `updates/L/package/work/acquisition_attack.md`. This supplies the passive LPN/evaluable-prefix reduction and repeated-readout escape. A local text extraction was saved at `work/learning_acquisition_source.txt`. Its source explicitly does not settle arbitrary HMM acquisition or generator-only hardness. The pair-copy/spliced-Walsh construction above is a separate attempt made in this scout.

Memory lookup was used only to recover prior scopes: `MEMORY.md:389-413` (joint-synthesis shortcuts and actual-path transfer), `MEMORY.md:477-508` (product-input/additive subclass). Current primary interfaces and the new calculations were verified independently here. No repository source was modified, and no external publication or message was sent.
