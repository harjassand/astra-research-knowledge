# Geometry/topology scout — 7 October 2026

The best independent target is **bounded-aspect graphically local Euclidean embedding**, Question 3.8 of Jain–Tu (August 2026). I obtained a complete elementary constructive lemma giving an exact, graph-size-independent realization for a nontrivial range of edge aspect ratios. For subcubic graphs this range is `[1,sqrt(2)]`, with dimension at most 17. This is partial progress on the stated question, not its resolution. Historical novelty is UNKNOWN: the proof combines standard diagonal dominance with strong edge coloring, and a thorough prior audit remains necessary.

A separate primary-source audit found decisive counterexamples to the central second-variation lemma and noisy reconstruction lemma in Mirzaie (December 2025). These are useful rejection fixtures, not a new general reconstruction theorem. Sun–Wang–Zhang's recent local-homology theorem provides a stronger quantitative-topology target, but its passage from bounded torsion exponent to bounded local fundamental-group order remains substantially harder. I read the supplied L05 proof and did not prioritize it over these independent targets.

## 1. Exact edge realization from diagonal dominance

**Primary target.** Jain–Tu, *On graphically local versions of metric embeddings*, [arXiv:2608.15779v1](https://arxiv.org/html/2608.15779v1), Definition 1.1, Theorem 3.2, Corollary 3.6, Question 3.8. The recent lower bounds use maximum degree three but increasing aspect ratio. Their open question asks whether fixed degree and fixed aspect ratio permit a dimension bound independent of vertex count. Treewidth-bounded realizations are already in the paper. Read depth: the main reduction and the bounded-treewidth construction, not merely its abstract.

**Internally proved lemma.** Let `G=(V,E)` be a finite simple graph of maximum degree `Delta >= 2`, with supplied positive edge lengths `ell_e in [a,b]`. If

\[
 (b/a)^2\leq (\Delta+1)/(\Delta-1),
\]

then there is a map

\[
 f:V\longrightarrow\mathbb R^{2\Delta^2-\Delta+2}
 \quad\text{with}\quad
 \|f(u)-f(v)\|=\ell_{uv}\quad(uv\in E).
\]

The graph lengths need not come from a metric or a Euclidean configuration. No distances on nonedges are requested or promised. The map can identify nonadjacent vertices, as permitted by the source interface. Degree one is immediate; degree two already has stronger exact results in the source.

**Proof.** Put

\[
 c=(a^2+b^2)/4,\qquad q_e=c-\ell_e^2/2.
\]

Then `|q_e| <= (b^2-a^2)/4` and

\[
 \sum_{e\ni v}|q_e|\leq\Delta(b^2-a^2)/4\leq c.
\]

Strongly edge-color `G`: edges of one color form an induced matching. A greedy coloring uses at most `2 Delta(Delta-1)+1` colors, since each edge conflicts with at most `2 Delta(Delta-1)` edges at line-graph distance at most two. Properly vertex-color `G` using at most `Delta+1` other coordinate labels.

For each edge `e=uv`, in its edge-color coordinate assign amplitudes `sgn(q_e) sqrt(|q_e|)` at one endpoint and `sqrt(|q_e|)` at the other. Set other entries initially to zero. No vertex receives two assignments in this coordinate. In the coordinate of its vertex color, assign at `v`

\[
 \sqrt{c-\sum_{e\ni v}|q_e|}.
\]

This radicand is nonnegative. Every vertex has squared norm `c`. For adjacent vertices `u,v`, the private coordinates differ. Their only shared nonzero edge-color coordinate is the color of `uv`: if an edge at `u` and a different edge at `v` shared a color, the two edges would be at line-graph distance at most two. Therefore

\[
 \langle f(u),f(v)\rangle=q_{uv},\qquad
 \|f(u)-f(v)\|^2=2c-2q_{uv}=\ell_{uv}^2.
\]

The dimension is at most `2 Delta(Delta-1)+1+Delta+1`. This proves the claim for every finite graph, independently of finite tests. Zero radicands and signs cause no singularity in the exact construction.

In particular, for every Euclidean metric whose global aspect ratio is at most `sqrt(2)` and every degree-three constraint graph, Question 3.8 has an exact realization in `R^17`, for every approximation tolerance. More generally the applicable hypothesis concerns only the edge lengths, which is weaker than bounding the entire metric's aspect ratio. The result does **not** establish the question at aspect ratio two or at arbitrary fixed aspect ratio.

**More flexible acquired certificate.** For arbitrary supplied edge lengths, search for squared radii `r_v >= 0` and numbers `t_e >= 0` satisfying the linear inequalities

\[
 t_{uv}\geq\tfrac12(r_u+r_v-\ell_{uv}^2),\qquad
 t_{uv}\geq-\tfrac12(r_u+r_v-\ell_{uv}^2),\qquad
 r_v\geq\sum_{e\ni v}t_e.
\]

If feasible, replace `c` by `r_v` in the norm construction and set `q_uv=(r_u+r_v-ell_uv^2)/2`. The same coloring proof gives the same dimension bound and exact edge lengths. Thus a sparse LP is a sufficient certificate even outside the universal ratio regime. Feasibility is not necessary; rejection is `UNKNOWN`, not nonrealizability. A weighted diagonal-dominance version is also immediate after fixing positive vertex weights, but choosing those weights is an additional acquisition problem.

**Costs and control.** Input is the graph and exactly `|E|` edge lengths, not a full distance oracle or an original embedding. Greedy color construction can be implemented in `O(|V| Delta^3)` combinatorial work; there are `Delta+1` nonzero coordinates per vertex. With rational squared lengths the exact output is a list of square roots of explicit rational radicands, not generally a rational embedding. For relative edge error `epsilon`, rounding each coordinate to absolute error `epsilon a/(4 sqrt(m))` gives the promised edge accuracy by the triangle inequality, with `O(log(b/a)+log(m/epsilon))` precision bits per coordinate in addition to input precision. No optimizer is needed in the universal regime. The optional radius certificate adds the cost of a sparse LP.

The equally informed elementary baseline is the uncompressed diagonal-dominant Gram decomposition, using one coordinate per edge plus one per vertex. Both have sparse `O(|V| Delta)` descriptions. The new deduction is a common ambient dimension independent of `|V|`; I do not claim an asymptotic runtime or total-storage advantage over that sparse baseline. At exactly equal lengths, proper vertex coloring already gives a smaller dimension, so that special case is not the contribution.

**Finite diagnostic.** `work/scouts/topology_geometry_check.py` independently enumerated every labelled simple graph on 2–6 vertices with maximum degree at most three: 12,905 graphs, three deterministic squared-length patterns each, 38,715 instances, 221,355 exact rational edge checks. Boundary cases included 12,825 instances with zero private-coordinate residual. The largest observed dimension was 13; the proved upper bound remains 17. Runtime was 2.34 seconds. Results are in `work/scouts/topology_geometry_checks.json`. A frozen failure control replaces strong edge coloring with ordinary edge coloring on `C4`; a target squared length one becomes one-half, as expected. This specifically tests why induced matchings are necessary. Finite enumeration certifies only these inputs.

**Novelty audit and strongest next question.** The source explicitly highlights only global aspect ratio one as an immediate positive special case. A primary search located Laurent–Varvitsiotis's [Gram-dimension framework](https://arxiv.org/abs/1112.5960), where arbitrary positive-semidefinite completion data are studied, and Frankl–Kupavskii's [unit-distance graph realization result](https://doi.org/10.1016/j.jcta.2019.105146). Neither search establishes that the present near-equilateral lemma is new. Its proof is simple enough that folklore overlap is plausible. The genuinely important next lemma is: **Does every Euclidean edge system on a subcubic graph with all original point distances in `[1,2]` admit a `(1+epsilon)` edge realization in dimension `f(epsilon)`?** First try to extend the sparse radius certificate by adding a bounded number of locally colored factors; alternatively construct a bounded-aspect forcing gadget that avoids the source reduction's very short replica edges. A failure of the radius LP alone is not a negative answer. Expected value: highest of this scout's targets, because it isolates a recent named open question and has an executable positive foothold.

## 2. Reconstruction audit: three decisive elementary failures

**Primary source.** Mirzaie, *On topology estimation of submanifolds in Riemannian manifolds by random points*, [arXiv:2512.23225v1](https://arxiv.org/html/2512.23225v1), Lemmas 2.1, 3.3, 4.2 and Theorem 3.1. Read depth: the full short manuscript. Its claims cannot be adopted as general reconstruction inputs in their displayed interfaces. This audit is independent mathematical reasoning; no author was contacted.

**Lemma 2.1 is false at cut points.** On the flat square two-torus `N=R^2/(2Z)^2`, take `q=(0,0)`, `p=(1,0)`, and `gamma(t)=(1+t,0)` for `|t|<1/4`. This is a unit-speed geodesic and

\[
 d(q,\gamma(t))=1-|t|\leq d(q,p)=1.
\]

Thus the displayed hypothesis of Lemma 2.1 holds. Every sectional curvature is zero, so its asserted curvature integral is zero and cannot be at least one. There are two minimizing routes at `p`; the claimed perpendicularity fails. Independently, the proof assumes that the length of an arbitrary constructed variation is maximized whenever the minimizing distance is maximized. That implication is invalid even before a curvature calculation. A corrected second-variation proof needs a smooth minimizing-geodesic family and its Jacobi field, not that arbitrary comparison variation.

**Lemma 4.2 is false even in the Euclidean plane.** Let `M=S^1` of radius one, so its reach is one. Set `epsilon=1/10`. Choose finitely many points on the circle that are `epsilon/2`-dense, and add `z=(7/5,0)`. Every sample point lies in the open half-reach tube. Coverage holds, and ambient sectional curvature is zero. But `d(z,M)=2/5`, so the ball of radius `1/10` about `z` is disjoint from every ball of that radius centered on `M`. The union is disconnected whereas `M` is connected. No deformation retraction onto `M` exists. This failure directly rejects the noisy reconstruction conclusion, independently of Lemma 2.1.

**Lemma 3.3 lacks necessary size parameters.** Upper scalar curvature alone cannot give a uniform sample bound depending only on confidence, that curvature bound and resolution. A flat torus of side length `L` has scalar curvature zero. For fixed `epsilon` and fewer than `Vol(M)/Vol(B_epsilon)` sample points, no arrangement can be `epsilon`-dense: the volumes of its `epsilon`-balls are insufficient. Letting `L` grow disproves any claimed uniform cardinality bound at fixed dimension. The underlying distribution and normalization must also be supplied. A valid generic coupon-collector upper bound uses a covering number `N(epsilon/2)` and a lower mass `mu_min` for the covering balls: `l >= mu_min^-1 log(N/(1-p))`. Neither parameter follows from an upper scalar bound alone.

The local argument in Theorem 3.1 also assumes, without proof, that nearest projection stays within each convex sample ball. For `M=S^1`, `x=(1,0)`, `y=(1/4,sqrt(3)/4)`, and ball radius `9/10`, one has `|y-x|=sqrt(3)/2<9/10`, but `|pi(y)-x|=1>9/10`. This refutes that local proof step; it does not, by itself, refute every possible global contraction of that particular union.

**Correct prior and bottleneck.** Attali et al., [*Tight bounds for the learning of homotopy…*](https://arxiv.org/html/2206.10485v4), already distinguish the two one-sided Hausdorff errors and use a cut-locus-aware Riemannian reach. In the Euclidean noiseless manifold setting the sharp sampling constant is `2-sqrt(2)` times the reach; their Section 6 identifies Rips reconstruction and broader lower-curvature metric settings as further questions. I independently recovered this same constant by controlling overlap of normal-fiber intervals, then found that it is established prior. It is not an original improvement.

Expected value: the counterexamples are immediately useful to prevent invalid transfers; pursuing a general scalar-curvature-only sampling theorem has negative value. The viable frontier is a sharp, certifiable Rips/local-filling reconstruction theorem with noisy distance access and explicitly acquired regularity. This is a deeper project and has not been solved here.

## 3. Quantitative local topology and L05 comparison

Sun–Wang–Zhang, [*On the local topology of non-collapsed Ricci bounded limit spaces*](https://arxiv.org/html/2505.02630v1), Theorems 1.1–1.2, Lemmas 3.5–3.6, Discussion Conjecture 1, prove a uniform torsion-exponent bound for the image of local integral first homology of the regular locus, with two-sided Ricci and noncollapse hypotheses. They distinguish this from a uniform order bound for local fundamental groups. Their effective regular sets and geometric loop decomposition are promising mechanisms; their constants are obtained through compactness and need not be executable. I read those exact statements and the relevant transfer/decomposition proof, but have not independently certified the entire paper.

An elementary scoped consequence is that the same local `H1` map vanishes over every field whose characteristic does not divide the bounded integral exponent. Tensor the map through its integral image and use the universal coefficient theorem in degree one. This does not yield vanishing over exceptional characteristics, a bound on the image order, a finite-query test, or a fundamental-group bound: `(Z/p)^r` has exponent `p` and unbounded order. The load-bearing next step is uniform generation/decomposition control as the effective regularity radius tends to zero. Expected value: high mathematical consequence but substantially lower short-run tractability than Target 1.

**L05 reviewed rather than adopted as leader.** Exact supplied source: `work/astra-research-knowledge/web/pages/d-dd1f8940a4c292b5.html`, originally `literature/notes/frontier_geometry1/cycle19/FINITE_RANK_ENDPOINT_OBSTRUCTION.md`; routing card `cards/L05-finite-global-rank.txt`. The sharp-dip proof's ground-state identity and loss of derivative-energy control explain the rank/exhaustion noncommutation. This does not verify its width manuscript or establish priority. No competing finite-rank claim was inferred from the current literature.

A routine extension of its rank repair is worth retaining. If `lambda_4 >= lambda > 0` and the negative scalar part obeys the acquired quadratic-form bound

\[
 \int R_-\varphi^2\leq\beta Q_4(\varphi)+\gamma\|\varphi\|^2
 \quad(\beta,\gamma\geq0),
\]

then, for `k >= beta`,

\[
 \lambda_{4k/(k+1)}\geq
 \frac{(k-\beta)\lambda-\gamma}{k+1}.
\]

Indeed `Q_a=(a/4)Q_4+(1-a/4)int R phi^2` and the bound apply directly. Thus integer `k > beta+gamma/lambda` permits the same finite torus stabilization consequence under the positive-supersolution interface. This allows an unbounded pointwise negative scalar part when it is form-controlled. It is standard form perturbation, with no novelty claim; obtaining such a global certificate is the real acquisition cost. The L05 sharp-dip sequence cannot obey this bound with finite constants. Expected value: useful assumption repair, not a high-upside new research leader.

## Provenance and remaining gates

Source snapshots are in `work/scouts/topology_geometry_sources/`: `2608.15779v1.{html,txt}`, `2505.02630v1.{html,txt}`, `2512.23225v1.{html,txt}`, `2206.10485v4.{html,txt}`, with URLs and byte counts in `metadata.json`. Browsing used primary arXiv manuscripts and primary publisher/author sources for the cited older mechanisms. No publication, push, paid compute, contact, or source-repository mutation occurred.

Highest-priority gates: independent algebraic audit of the compressed Gram construction; targeted historical search for near-equilateral bounded-degree edge realizations; then either a genuine aspect-ratio-two upper bound or a forcing gadget with bounded aspect ratio. The 17-dimensional lemma and reconstruction counterexamples are complete within their stated elementary interfaces. Novelty and the full open problem remain unresolved.
