# Nonequilibrium physics scout — 7 October 2026

**Outcome.** The best short technical follow-up is an identifiability theorem for hidden dissipation in Gaussian systems, with physical time reversal and observation bandwidth made explicit. I derived an exact observable entropy-production formula for two probes of one hidden OU driver, and a zero-dissipation equilibrium realization with the same three-coordinate dimension and the same entire observed path law at coalescence. A second exact obstruction shows that fully observed OU trajectories on a regular grid can conceal arbitrarily large dissipation. Neither is presented as a new field-level breakthrough: the underlying Gaussian reversibility, system aliasing, and resolvent mechanisms have substantial prior art.

**Ranking:** (1) equilibrium completion and controlled-response identifiability; (2) finite-data thermodynamic inference with Poisson timing and charged conditioning; (3) thermodynamic error bounds for metastable reductions. Generic quantum hydrodynamic limits are higher upside but currently much less tractable: a positive transport lower bound is not a hydrodynamic limit, and a crucial absence-of-extra-charges premise remains unacquired.

## Repository intake and primary literature

Read `work/astra-research-knowledge/00_START_HERE.txt`, `01_CORE.txt`, `AGENTS.md`, `cards/W-frontier-dynamics.txt`, and `cards/P-gaussian-physics.txt`. The last card concerns labelled covariance spectra and ordered modular commutators; it does not supply a trajectory-to-dissipation acquisition theorem. No repository frontier claim is needed for the constructions below. The memory registry search returned no relevant hit.

Primary sources refreshed (read depth is deliberately stated):

| Source | Exact reusable mechanism or scope boundary | Read depth |
|---|---|---|
| [Da Costa–Pavliotis, 2023; arXiv:2212.05125v3](https://arxiv.org/html/2212.05125v3) | Stationary diffusion EPR is a path KL rate; the irreversible drift must lie in the noise range for the finite quadratic formula. Physical momentum reversal is a separate choice. | Theorems 4.1–4.4, Section 5.1 and Appendix A.4 formulas/proof inspected. |
| [Lucente et al., 2022; arXiv:2205.08961](https://arxiv.org/abs/2205.08961) | A scalar stationary Gaussian record is reversible. Response experiments or model/parameter information can add information absent from passive data. | Primary abstract and published-source metadata; not a full proof reread. |
| [Seara–Machta–Murrell, 2021; arXiv:1911.10696v3](https://arxiv.org/html/1911.10696v3) | Gaussian path KL rate uses the difference between forward and reversed spectral inverses; imaginary cross-spectral structure carries irreversibility. | Section II, Appendix A derivation. |
| [Ferrante–Masiero–Pavon, 2012; arXiv:1103.5602v1](https://arxiv.org/html/1103.5602v1) | Gaussian spectral relative entropy equals time-domain rate under stated nondeterminism/boundedness or coercivity premises. | Theorems II.2 and III.1/proof inspected. |
| [Yue–Thunberg–Gonçalves, 2016; arXiv:1605.06973](https://arxiv.org/abs/1605.06973) | Matrix-exponential inversion has system aliases; prior frequency/norm/sparsity restrictions can remove or bound them. | Primary abstract; HTML contains only a PDF pointer. No novelty claimed for system aliasing. |
| [Bauer–Seifert–van der Meer, 2025; arXiv:2412.15642v2](https://arxiv.org/html/2412.15642v2) | Finite-state positivity bounds imaginary eigenvalues by escape rates; determinant and diagonal propagator entries supply an operational uniqueness certificate. | Sections 2–3.2 proof read; full-data propagator premise is explicit. |
| [Gingrich et al., June 2026; arXiv:2606.23619v1](https://arxiv.org/html/2606.23619v1) | Noise induces memory; exponential photon intervals replace an exponential propagator by a resolvent. Inversion still needs a known invertible observation map and adequate conditioning. | Sections II and IV, including Eqs. 34–35. |
| [Bi–Calhoun, 2026; arXiv:2604.03775v1](https://arxiv.org/html/2604.03775v1) | Positive cross residual against an independent-channel null is model-dependent detectability. The manuscript itself notes an equilibrium feedback example with nonzero cross residual. | Theorems 1–3, Sections VI–X and Appendices C–E inspected. |
| [Macieszczak, 2021; arXiv:2104.05095](https://arxiv.org/html/2104.05095v1) | Operational approximate stationarity and spectral metastability have quantitative, conditional relations; bare eigenvalue separation is not the full operational certificate. | Setup and contents plus selected operational/spectral discussion; not all appendix proofs. |
| [Ampelogiannis–Doyon, 2025; arXiv:2501.07749v2](https://arxiv.org/html/2501.07749v2) | Quadratically extensive charges and flux curvature yield a positive Onsager lower bound under strong conservation/local balance and a transport-chaoticity premise. | Setup, Theorems 1–2 and Section 4 proof read. |
| [Bettmann et al., Dec. 2025; arXiv:2512.05074v1](https://arxiv.org/html/2512.05074v1) | Slow-driving thermodynamic metric equals QFI times an integral relaxation time. Its inverse-gap scaling requires overlap with the slow mode; Gaussian soft-mode argument assumes nonzero noise projection and a controlled spectral expansion. | Main scaling argument, Appendices B and C.8–C.9 inspected. |
| [Ayala–Renger, 2025; arXiv:2512.20412](https://arxiv.org/abs/2512.20412), [Funaki–Gu–Wang, updated 2026; arXiv:2404.12234](https://arxiv.org/abs/2404.12234) | Hydrodynamics can retain flux/collision information discarded by density alone; quantitative nongradient homogenization is an alternative to claiming diffusion from a gap or finite simulation. | Abstract screening only; no theorem adopted. |

Local primary HTML snapshots: `work/scouts/nonequilibrium_sources/{2212.05125v3,2412.15642v2,2606.23619v1,2501.07749v2,2512.05074v1,2604.03775v1,2104.05095v1,2608.11059v1,1911.10696v3,1103.5602v1}.html`. Readability copies exist for the first five; `1605.06973v1.html` is the source's PDF-pointer page. The August 2026 SPDE paper [Duan–Zhang–Zimmer](https://arxiv.org/html/2608.11059v1) was also screened at its assumptions and Theorem 2.12: a reversible Gaussian reference, bounded noise-range drift/density derivatives, and a strong stationary realization are load-bearing, not generic SPDE hypotheses.

## 1. Exact Gaussian observation obstruction and equilibrium completion

### Legal interface

Passive, stationary, continuously observed two-dimensional record `X=(X1,X2)`. Observed coordinates are even under physical time reversal. A latent linear Gaussian realization may be fitted, but latent parity, latent bath physics and one-way forcing geometry are **not** acquired from the record. All rates/noises below are strictly positive, and `u1*u2 != 0`. For the positive full-system EPR formula, additionally supply that every variable in the one-way model is even, with the stated independent baths.

Consider

`dXi = -γi Xi dt + λ ui F dt + sqrt(2 Di) dWi`,

`dF = -γf F dt + sqrt(2 Df) dWf`.

The full model has EPR `Σfull = λ² Df Σi ui²/[Di(γi+γf)]`, a known/model-derived formula also reproduced by the 2026 preprint. Its observed spectral density, using a harmless common factor 2 convention, has

`Sii = 2[Di + λ² ui² Df/(γf²+ν²)]/(γi²+ν²)`,

`S12 = 2 λ² u1 u2 Df/[(γ1+iν)(γ2-iν)(γf²+ν²)]`.

**Internally derived exact observable rate.** Put `a=γ1`, `b=γ2`, `c=γf`, and `d=sqrt(c²+λ² Df(u1²/D1+u2²/D2))`. The Gaussian spectral KL rate is

`ΣX = λ⁴ u1² u2² Df² (a-b)² (a+b+c+d)`

`      / [D1 D2 (a+b)(c+d)(a+c)(b+c)(a+d)(b+d)]`.

Derivation: for `S=[[A,C],[C*,B]]`,

`tr[(Sᵀ)^(-1) S]-2 = 4(Im C)²/det S`.

The rank-one common signal makes its quartic determinant terms cancel. Substitution into the standard Gaussian path/spectral relative-entropy identity reduces the integral to

`(1/π)∫ ν²/[(ν²+a²)(ν²+b²)(ν²+c²)(ν²+d²)] dν`

`= (a+b+c+d)/[(a+b)(c+d)(a+c)(b+c)(a+d)(b+d)]`.

The integral follows by partial fractions in `(ν²+c²)(ν²+d²)` and the three-pole identity `∫ν²/[(ν²+a²)(ν²+b²)(ν²+c²)]dν = π/[(a+b)(a+c)(b+c)]`. Coincident-pole cases follow continuously. The stable rational spectra are positive, and the irreversibility integrand is integrable at high frequency. Identification with path-space rate uses the established Gaussian entropy-rate mechanism, rather than a novel entropy-rate theorem.

**Decisive consequence:** `γ1=γ2` implies `ΣX=0` exactly, at every coupling strength, even though `Σfull>0` and the independent-channel cross-detectability residual is positive. More strongly, `S(ν)` is then real symmetric: every finite-dimensional observed Gaussian law is exactly time-reversal invariant. This conclusion requires neither a spectral KL limiting argument nor finite tests.

### Same-dimension zero-dissipation realization at total coalescence

Set `γ1=γ2=γf=γ`. Whiten observed coordinates by `diag(D1^(-1/2),D2^(-1/2))`, then rotate the vector `w=(u1/sqrt(D1),u2/sqrt(D2))` onto coordinate 1. The resulting observed `q1,q2` have spectra

`S1(ν)=2/(γ²+ν²)+2 L² Df/(γ²+ν²)²`,

`S2(ν)=2/(γ²+ν²)`, `S12(ν)=0`, where `L=λ||w||`.

Let `r=L² Df/γ² > 0`, `α=2γ/(2+r)`, `β=2γ(1+r)/(2+r)`, `k=(γ-α)²`, `Cq=1/α`, and `T=k/α`. Use a hidden **odd** variable `p` and dynamics

`dq1=(-α q1+p)dt+sqrt(2)dBq`,

`dp=(-k q1-β p)dt+sqrt(2βT)dBp`,

plus independent `dq2=-γ q2 dt+sqrt(2)dB2`.

This is a harmonic equilibrium OU process with Hamiltonian `(k q1²+p²)/2`, common bath temperature `T`, and diagonal mobilities `(α/k,β)`. Its covariance is `diag(Cq,T)`; the Lyapunov equation holds. With `E=diag(1,-1)`,

`C Aᵀ C^(-1) = E A E`, `E D E=D`, `E C E=C`.

Thus physical momentum-reversed detailed balance holds and stationary physical EPR is zero. Its drift trace is `-2γ` and determinant `γ²`; its observed q1 spectrum is

`2[ν²+β²+βT]/(γ²+ν²)² = 2[ν²+γ²(1+r)]/(γ²+ν²)² = S1(ν)`.

Undoing the whitening/rotation reproduces the original observed X path law exactly. Both realizations have three state coordinates; both preserve the observed diffusion matrix. The latent diffusion, latent parity and physical realization differ. Excluding odd latent variables or supplying the one-way bath model would exclude this comparator; those are extra inputs that must be declared.

An even simpler four-coordinate completion uses an ordinary equilibrium damped oscillator with poles `γ,γf`, plus two independent reversible OU noises. It works whenever the two observed rates coincide, without requiring total coalescence.

**Status and novelty.** Exact internal derivations, no external review or priority claim. The 2026 preprint explicitly restricts its EPR bridge to the one-way model and even reports a reversible feedback example with nonzero detectability. My construction therefore blocks a tempting **data-only extension**, rather than refuting its restricted algebraic theorem. Its discussion language about certification must retain that supplied model premise.

**Highest-value next question.** Characterize when a positive rational observed spectrum admits a zero-physical-EPR latent OU realization, given a fixed state dimension and fixed allowed parity signature. Then identify the minimum controlled response experiment that excludes those equilibrium completions. This could turn a model-dependent correlation detector into an honest acquisition theorem. Fatal test: permit the coalescent completion above in the model class and try to certify positive dissipation from any passive observed statistic; it must fail.

Costs: spectral acquisition needs independent trajectories or mixing/time-length analysis; exact spectra are not supplied by finite samples. Minimal realization search also charges numerical conditioning, latent dimension, parity assumptions and response interventions. Matched control is the equilibrium completion with exactly the same observed law, not independent white/OU channels alone.

## 2. Temporal aliasing, finite confidence impossibility, resolvent repair

### Exact obstruction, including known physical noise

Use fully observed even coordinates,

`dX=(-a I+ω J)X dt+sqrt(2ac)dW`, `J=[[0,-1],[1,0]]`, `a,c>0` known.

Its stationary covariance is `cI`; current velocity is `ωJx`; continuous EPR is `Σ=2ω²/a`. At interval h,

`Xnext = exp(-ah)R(ωh)X + N(0,c(1-exp(-2ah))I)`.

For **every** integer k, `ωk=2πk/h` gives the same complete h-grid experiment as `ω=0`, with unbounded true EPR. No increase of trajectory length, statistical estimator quality or memory order recovers it. The sampled forward/reversed KL rate is

`Σh=4 sin²(ωh)/[h(exp(2ah)-1)]`.

For any finite predetermined schedule with gaps `Δi>0`, the exact KL divergence to the equilibrium sampled record is

`D(Pω || P0)=Σi 4 exp(-2aΔi) sin²(ωΔi/2)/(1-exp(-2aΔi))`.

Simultaneous Diophantine approximation supplies an unbounded sequence of frequencies with all phases arbitrarily close to multiples of `2π`, hence `TV(Pωk,P0)→0` while `Σωk→∞`. Therefore no statistic U that is finite almost surely under equilibrium can have uniformly valid upper coverage `Pω[Σω≤U]≥1-δ` for all ω, for any `δ<1`. Proof: upper coverage along that sequence is at most `P0[U≥Σωk]+TV(Pωk,P0)→0`. This statement covers any finite number of independent repetitions at fixed predetermined times; it does **not** claim an adaptive/randomized-schedule impossibility theorem.

Why the finite-state operational certificate does not transfer: OU drift trace/determinant remains fixed while the skew rotation is unbounded. Finite-state generator positivity ties imaginary eigenvalues to escape rates; the OU skew component has no analogous positivity bound.

### Exact resolvent mechanism and a charged finite-data construction

Assume independent stationary pairs `(X0,XT)` can be acquired with independently selected `T~Exp(ρ)`. Independence/reset access is supplied, not free. Define `z=(X1+iX2)/sqrt(2c)` and observe `Y=zT*conj(z0)`, discarding interval labels. Then

`m=E[Y]=ρ/(ρ+a-iω)`, `E|Y|²≤2`,

`Σ=(2/a)[ρ²/|m|²-(ρ+a)²]`.

This is injective at exact population precision and removes discrete aliasing. The general semigroup identity is `M=ρ(ρI-A)^(-1)`, `A=ρ(I-M^(-1))`. I independently corrected its sign/scaling before transfer: the retrieved 2026 HTML Eqs. 34–35 display expressions failing the zero-generator test (`M` must be I at A=0), so those displayed equations must not be copied literally.

For n independent pairs, take an odd number `k≥(32/9)log(2/δ)` of equal groups, each with `mgroup=floor(n/k)`. Coordinatewise medians of group means give `|mhat-m|≤η=4sqrt(2/mgroup)` with probability at least `1-δ`: each coordinate group's bad probability is at most 1/8 by its variance bound, and Hoeffding plus a union bound controls the medians. This is an explicit conservative construction, not a minimax claim.

Set `L=(|mhat|-η)+`, `U=|mhat|+η`. The EPR interval is

`lower=max(0,(2/a)[ρ²/U²-(ρ+a)²])`,

`upper=(2/a)[ρ²/L²-(ρ+a)²]` if L>0, and `+∞` otherwise.

For `|ω|≥ρ+a`, relative-accuracy ε requires a sufficient pair count

`n=O(((ρ+a)²+ω²)/(ρ² ε²) * log(1/δ))`.

The interval remains infinite until the resolvent signal separates from its noise floor. This charges the conditioning lost when `|ω|/ρ` is large. Expected observed evolution time is n/ρ, plus resetting/stationarization cost. Labeled-time maximum likelihood and matched full-data estimators may improve this bound; no optimality or all-diffusion extension is established. Unknown finite ω permits a confidence-union doubling protocol, but no uniform finite observation budget without a frequency bound.

**Next question:** for arbitrary well-conditioned multivariate OU with known observation noise and accessible reset/independence, derive minimax EPR confidence radii for Poisson observation and compare matched labeled timing, unlabeled resolvent, and a known-bandwidth regular grid. Fatal tests are high rotation, nearly singular diffusion, and the same m signal approaching zero.

## 3. Metastable closeness does not control housekeeping dissipation

An original decisive counterexample to a possible uniform transfer is the three-state cyclic CTMC with clockwise rate `ε` and counterclockwise rate `ε exp(-1/ε²)` on every edge. Its stationary law is exactly uniform. Its stationary EPR is

`Σε=(ε-ε exp(-1/ε²))*log(exp(1/ε²)) ~ 1/ε`.

Yet, on any fixed time horizon t, every state remains unchanged except with probability at most `t ε(1+exp(-1/ε²))`. Its full path experiment is that close in TV to the frozen process. Its two nonzero relaxation rates are O(ε), so it also has an arbitrarily long apparent plateau. All reverse rates are positive at each ε; infinity is not manufactured by deleting reverse edges.

Thus no dimension-independent entropy-production error modulus follows solely from semigroup/trajectory TV error, approximate stationarity or a slow spectral manifold. Rare events can carry unbounded affinities. The frozen limiting process is reducible, so this does not disprove a theorem imposing a uniform irreducibility gap or affinity floor. A finite quantum realization uses diagonal classical jump operators `sqrt(kij)|j><i|`; the relevant quantity is trajectory/housekeeping EPR with a supplied jump-reversal instrument. Spohn nonadiabatic EPR relative to the stationary state is a different quantity and is zero at stationarity.

A useful next technical target is an entropy-production-preserving metastable reduction with bounded transition affinities and an explicitly charged observation instrument. It ranks below targets 1–2 because straightforward continuity on a fixed positive-rate simplex is routine; a worthwhile theorem must handle system size and scale separation without silently imposing a minimum rate that fails in metastability.

## Remaining hydrodynamic/open-quantum gates

The 2025 open-spin-chain result's flux-curvature mechanism is worth retaining: projecting current off the conserved charge and pairing with quadratic charge fluctuations gives `(χ j''(s))²/(8 vLR)` as a positive transport lower bound. The current's projection onto **all** extensive charges is part of the interface. The paper explicitly says proving generic chaoticity/absence of additional extensive charges is out of reach. Its rigorously defined coefficient is a normal-diffusion contribution minus an irreversibility contribution; Gaussian profile convergence is phenomenological discussion, not the theorem. Therefore extending that calculation alone into a quantum hydrodynamic limit would misstate the result.

Likewise, critical slow-driving entropy-production scaling needs both dynamical and score overlap control. A closing gap with constant stationary state produces no score/QFI and no driving entropy. Complex slow modes can have oscillatory integrals, and nonnormal/defective limits need uniform projection control. These are fatal tests for a general theorem based only on the gap, but I have not proved a counterexample to the explicitly restricted critical Gaussian claim in the December 2025 paper.

## Evidence, status and recommendation

`work/scouts/nonequilibrium_derivations.py` and `.json` contain eight symbolic identities and three quadrature fixtures. All identities passed; quadrature discrepancies are at floating-input precision. These checks corroborate algebra and are not theorem or novelty certification. No simulations are offered as proof of a general physics result.

**Recommend a focused depth wave on target 1:** classify reversible latent Gaussian realizations under a fixed parity budget, starting from the exact three-coordinate completion above. It has a small auditable interface and a decisive matched comparator. A minimal response-based repair would be more consequential than another passive correlation estimator. Target 2 is a viable secondary project if novelty review finds finite-data Poisson-timing EPR guarantees absent. Do not spend the next wave trying to infer a general quantum hydrodynamic theorem from current lower bounds or a spectral gap.
