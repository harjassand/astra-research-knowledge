# Extremal/additive combinatorics scout — 7 October 2026

## Result and allocation recommendation

**No unrestricted sunflower breakthrough.** The strongest new technical work in this pass is a sharp, weighted, anchor-dependent forbidden-list selection lemma, transferred from the rank sieve in the October sum-product preprint. It yields simultaneous coprimality at loss `(t+1)^m`, improving sequential application of the one-shift sieve, whose loss is `2^(tm)`. The proof is complete below. This is a reusable transfer, not a claimed new global theorem: its polynomial/rank ingredients are classical and priority of the exact weighted formulation remains uncertain.

The sunflower branch produced a sharp matroid corollary, immediately located in existing cocircuit-counting machinery, plus a decisive obstruction to its extension by cheap exchange covers. A proposed sharper entropy bound was also falsified exactly. These are useful eliminations, not resolutions.

**Ranked next targets:**

1. **Simultaneous coprime additive factors in the new ideal-smooth construction.** A tractable local gate is closed: multiple forbidden residues can be sieved with the sharp product loss. The next consequential gate is whether the arithmetic/volume rate still has positive margin after replacing only the sieve loss by `sum beta_j log(t_j+1)`. This requires a new numerical/arithmetic audit; the `1.95835` exponent is not inherited automatically. Moderate expected value: concrete mechanism and short proof, but novelty is mainly in a specific application, and the source's full arithmetic theorem remains unaudited here.
2. **Weighted spread plus adaptive trace complexity.** The newly posted bounded-VC proof has a transparent, usable collision certificate. Extend it only to a specified class with a certified low trace entropy after every core/link extraction. A generic assertion that sunflower-free families have bounded VC dimension is false. High upside for a genuinely new class; low probability of solving unrestricted sunflowers without a new structural input.
3. **Matroid-like exchange coverage.** The sharp restricted theorem is already an immediate consequence of known base-counting results. Any unrestricted proof through subexponentially many fixed-anchor exchange patches is ruled out by even-parity transversals. Low expected value unless a different, explicitly stated closure property is supplied.

## Primary-literature refresh and reading scope

| Primary source | Current information obtained | Reading depth / limitation |
|---|---|---|
| [Alweiss–Lovett–Wu–Zhang, 1908.08483v3](https://arxiv.org/html/1908.08483v3) | Spread measures, weighted links, robust sunflowers; Section 3 gives the logarithmic robust barrier. | Definitions, reduction interface, and complete lower-bound construction. |
| [Bell–Chueluecha–Warnke, 2009.09327](https://arxiv.org/abs/2009.09327) and [Rao, 2509.14790](https://arxiv.org/html/2509.14790v1) | General sunflower bound remains `(C r log w)^w`; Rao gives an elementary robust proof. | Verified primary statements; not a complete new proof audit of the general bound. |
| [Balogh–Bernshteyn–Delcourt–Ferber–Pham, 2408.04165v2](https://arxiv.org/abs/2408.04165v2) | Bound `(C r (log d+log* w))^w`; sharp `(r−1)^w` when VC dimension is 1. | Statements and published primary exposition. |
| [Ge–Wang–Xu–Zhao, 2609.18995v1](https://arxiv.org/html/2609.18995v1) | Bounded-VC sunflower bound `(50 d r)^w`. | Complete core proof, including entropy, squared marginals, Caro–Wei matching, and core extraction. The preprint's arXiv metadata displays a July submission with a September identifier; retain exact pinned ID rather than infer chronology from search timestamps. |
| [Kupavskii–Zakharov, 2203.13379](https://arxiv.org/abs/2203.13379) | Spread approximation separates structured kernels from spread remainders and solves particular forbidden-intersection regimes. | Primary statements; does not supply a constant-width universal kernel cover. |
| [Campos–Samotij, 2408.06617](https://arxiv.org/abs/2408.06617) | Improved uniformity dependence for containers, with a stated second-moment barrier. | Primary abstract/introduction. No attempt here to turn container count into a sunflower rank bound. |
| [Cavalar–Fabris–Mukhopadhyay–Srinivasan–Yehudayoff, ECCC TR26-220](https://eccc.weizmann.ac.il/report/2026/220/) | Recent robust-sunflower derandomization for linear-wise independence and some locally independent, approximately identical marginals. | Abstract/interface only; detailed constants and moment proof not audited. Generic limited-independence transfer is already occupied. |
| [Arunachalam–Castro-Silva–Dutt–Gur, 2509.02338](https://arxiv.org/abs/2509.02338), [2604.04547v1](https://arxiv.org/html/2604.04547v1) | Algorithmic characteristic-2 PFR acquires a subspace basis with membership queries plus uniform samples. | Theorem 1.2 and exact oracle/cost discussion. The displayed polynomial-in-`n` statement suppresses exponential dependence on doubling `K`; no arbitrary unknown-set acquisition follows. |
| [Douthitt–Oxley, 2022](https://www.math.lsu.edu/~oxley/degree_result4.pdf) | Product-of-fundamental-cocircuit bound on the number of matroid bases. | Exact Theorem 1.1; resolves novelty of the matroid branch. |
| [Zhang–Zeng–Wang, 2610.05725v1](https://arxiv.org/html/2610.05725v1) | Claims real sum-product upper exponent `1.95835`; uses ideal-smooth fibres and a rank-two residue sieve. | Independently reconstructed Lemmas 6.1–6.4 and the rate interface in Proposition 6.5; arithmetic tower and numerical certification not replayed. |
| [Bloom–Sawin–Schildkraut–Zhelezov, 2605.28781v1](https://arxiv.org/html/2605.28781v1), [Roche-Newton–Schildkraut–Warren, 2606.24583v2](https://arxiv.org/html/2606.24583v2) | Growing-degree number fields change the real expander landscape; mixed expression `AA+A+A` has subquadratic examples. | Construction interfaces; the second paper's full short construction and explicit `A(A+A)` limitation were read. Not a proof of the entire first manuscript. |

Source snapshot inspected: `work/astra-research-knowledge/00_START_HERE.txt`, `01_CORE.txt`, `cards/W-frontier-combin1.txt`, `W-frontier-combin2.txt`, `W-frontier-combin3.txt`, and `L07-additive-replica.txt`. Their released progression, expectation-threshold, and influence claims retain the repository's internal/unreviewed status. None is used as an established theorem in the arguments below.

Local primary HTML/math snapshots: `work/combinatorics/2609.18995v1.{html,txt}`, `2604.04547v1.{html,txt}`, `2610.05725v1.{html,txt}`, `2606.24583v2.{html,txt}`. The `.txt` extraction retains MathML `alttext`. Files are source material, not independent verification.

## Exact sunflower barriers

Write `q` for a spread probability: `Pr(T subset A) <= q^|T|`. For disjoint blocks `X_1,...,X_w` of size `kappa`, the full transversal family is `1/kappa`-spread. A Bernoulli-`p` subset contains a member exactly when it meets every block, with probability

`(1-(1-p)^kappa)^w`.

For fixed `p,kappa`, this tends to zero. Thus **constant spread cannot imply robust random containment uniformly in width**. This family nevertheless has `kappa` disjoint members. The obstruction is to the robust mechanism, not to a constant-base sunflower theorem. ALWZ's extra coding step makes a large family with no robust sunflower at any eligible core.

The bounded-VC proof avoids robust containment: its load-bearing inequality is `sum_x mu_x^2 < 49 d q`. Without trace complexity one only gets `sum_x mu_x^2 <= w q`; the width returns immediately. Also, even-parity binary transversals have VC dimension `w−1` and are 3-sunflower-free, so bounded VC cannot be inferred universally from sunflower exclusion.

**Original attempted sharpening, falsified.** A natural proposed improvement `sum mu_x^2 <= d q` is false. Take the complete `b`-ary rooted tree of depth `h`, exclude the root from the ground set, and let sets be root-to-leaf paths. Uniform leaf measure is `q=1/b`-spread: a prescribed chain has probability `b^(-depth of its deepest node) <= q^|T|`, while a non-chain has probability zero. The support has VC dimension 1. Yet

`sum_x mu_x^2 = sum_{j=1}^h b^j b^(-2j) = q(1-q^h)/(1-q)`.

At `q=1/2`, the ratio to `d q` approaches 2. Products of these trees give the same obstruction in every VC dimension. A possible sharper bound `d q/(1-q)` survives this example, but **is not proved here**; improving 49 alone is not a route to the unrestricted conjecture.

**Weighted transfer, proved but routine.** The Ge et al. entropy and dyadic calculation applies verbatim to any rational probability measure on nonempty sets whose support has VC dimension `d` and is `q`-spread; uniformity was not used in those calculations. Replicate sets according to integer weights, make duplicate copies adjacent in the intersection graph, and apply Caro–Wei. This yields

`matching number >= 1 / (49 d q)`.

The entropy calculation already permits real weights. For the graph step, approximate only the weights, use replication to obtain `matching number >= 1/sum mu_x^2`, and pass to the limit; the approximants need not preserve spread. This is useful when a legal weighted spread certificate is supplied. It does not supply that certificate: checking all links can require `N 2^w` explicit subset incidences, and an oracle to an unknown family is not an acquired sampler or certificate.

## Sharp exchange theorem and fatal extension test

Let `F` be a family of `w`-sets, and fix `B in F`. For each `b in B`, define

`D_b = {b} union {x outside B : B−b+x in F}`.

Assume every `A in F` has a perfect matching from the slots `B` to its elements, with the slot `b` matched inside `D_b`. If `F` has no `r`-sunflower then `|D_b| <= r−1`: otherwise the replacements with common core `B−b` give such a sunflower. Choose one matching per `A`. Its tuple identifies `A` by its unordered entries, so

`|F| <= product_{b in B}|D_b| <= (r−1)^w`.

For the full base family of a rank-`w` matroid, the matching assumption follows from Hall. If `S subset B`, every element of a base `A` outside `cl(B−S)` can replace some member of `S`. Since `rank cl(B−S)=w−|S|`, at least `|S|` members of `A` lie outside that closure. This verifies Hall. Partition matroids with `r−1` choices in each part attain equality. The product inequality is established prior art via Douthitt–Oxley; the sunflower corollary is immediate.

Now take binary even-parity words of length `w`, viewed as transversal sets. Any clean triple over a binary alphabet must have all three words equal, so the family is 3-sunflower-free. Flipping a single coordinate leaves the family. Consequently each `D_b` is the singleton `{b}`, and every fixed-anchor exchange-Hall patch contains only its anchor. A cover needs `2^(w−1)` patches. **Subexponential exchange coverage is impossible**, even in an elementary sunflower-free family. Allowing an unknown exponential number of patches is circular unless acquired by additional structure.

## Main proved transfer: weighted rooted list avoidance

Let `I` be a finite indexed collection of objects with coordinate maps `a -> a_j in Sigma_j`, `1 <= j <= m`; the coordinate encoding need not be injective. For every anchor `a in I`, suppose a supplied list `F_j(a) subset Sigma_j` has size at most `t_j`, and **does not contain `a_j`**. Lists may depend on the entire anchor. Give target objects arbitrary nonnegative weights `z_b`, with total `W`.

Set `D=product_j(t_j+1)`. Then at most `D` actual anchors have avoidance sets covering all targets. In particular, some anchor `a` satisfies

`sum_{b : b_j notin F_j(a) for all j} z_b >= W/D`.

**Proof.** Inject the finite symbols occurring in coordinates or lists into rational labels `lambda_j`. Define

`K(a,b)= product_j product_{c in F_j(a)} (lambda_j(b_j)−lambda_j(c))`.

The diagonal is nonzero by the omitted-self assumption. Each row is the evaluation of a polynomial with coordinate degree at most `t_j`. Therefore its row space has dimension at most `D`, with basis features `product_j lambda_j(b_j)^e_j`, `0 <= e_j <= t_j`. Choose a basis consisting of actual rows. Their nonzero column supports cover every column, since a column vanishing on every basis row would vanish on every row, contradicting its diagonal. Summing target weights over those supports gives at least `W`. One row retains at least `W/D`. Moreover, a matrix entry is nonzero exactly when all lists are avoided. ∎

The loss is **sharp**: let `I=product_j [t_j+1]`, and let each forbidden list contain every local symbol except the anchor's own. Every anchor retains exactly itself. Uniform weights give `W/D=1`.

If only a total list budget `sum_j |F_j(a)| <= T` is supplied, the same proof uses total-degree monomials and gives `D=binom(m+T,m)`. This connects to multipartite two-family/private-certificate arguments; it does not prove that such short lists can isolate words in an arbitrary sunflower-free family. [Alon's multipartite two-families theorem is explicit prior machinery in this primary paper](https://www.math.tau.ac.il/~asafico/saturation.pdf).

**Costs and inputs.** All objects, coordinates, lists, and weights are supplied. An actual anchor can be found by scanning all `N` rows and `N` targets, in `O(N^2 m)` list lookups after preprocessing. Number-field residue reduction and exact rational-weight arithmetic are additional charged costs. No exponential-size tensor needs to be built for this scan, but no sublinear black-box acquisition advantage has been proved. The row-basis argument also provides a cover, whose computation requires ordinary exact linear algebra.

## Different-target transfer from the October sum-product mechanism

Let `B` be a finite collection of algebraic integers and `p_1,...,p_m` distinct prime ideals. For each ideal supply a finite set `C_j` of **nonzero** residue shifts, of cardinality at most `t_j`. Set

`F_j(a)={a mod p_j − c : c in C_j}`.

The omitted-self condition holds. Hence there are `b_0 in B` and `B' subset B`, with `|B'| >= |B|/product_j(t_j+1)`, such that

`b−b_0+c notin p_j` for every `b in B'`, every `c in C_j`, and every ideal `p_j`.

This simultaneously makes several translated additive factors coprime to all selected ideals. For `t` distinct nonzero shifts at every ideal the loss is `(t+1)^m`, compared with `2^(tm)` from applying one-shift selections successively. It accommodates different residue characteristics without requiring a common finite field; rational labels are merely a proof device. CRT full-residue examples with `t_j=|O_L/p_j|−1` show sharpness.

In the October construction, this changes the **additive selection cost** to `sum beta_j log(t_j+1)`. The multiplicative doubling cost still uses `sum beta_j log 2`. Those two terms must be kept separate. A `t`-shift sieve applied to the additive factor `P` does not establish small products for `HP+1`: the shift after multiplication depends on `h`. The June mixed-expander proof also uses an inversion-symmetric unit set and a uniform conjugate bound on `G^3`; October's one-sided valuation truncation does not supply these properties. Thus neither the new numerical exponent nor an `A(A+A)` counterexample follows from this lemma alone.

The strongest next mathematical question is to find an actual application in which only simultaneous coprimality of the factors is missing, and then recompute the positive-rate inequality with the distinct sieve and doubling debts. This is narrower and more testable than asserting that the ideal-smooth method transfers to every polynomial expander.

## Evidence, status, and prior workspace safeguards

`work/combinatorics/check_transfers.py` ran successfully. `FINITE_CHECKS.json` records 90 weighted cases with globally anchor-dependent lists, modular rank checks, sharp full-cube cases of sizes 16 and 27, and even-parity exchange obstructions through width 6. These check conventions and implementations only; the general claims rely on the proofs above.

The prior local sunflower handoff `/Users/harjas/Documents/Codex/2026-07-15/current-task-statement-a-set-family/SUNFLOWER_PROGRESS_HANDOFF.md` was reopened. Its balanced weighted-neighborhood certificate, private-certificate and free-skew packing routes remain missing structural lemmas. The earlier parity-block single-root entropy obstruction was used as a safeguard against recycling a failed route, not as a current external theorem. This pass does not modify the source repository, prior research, or memory.
