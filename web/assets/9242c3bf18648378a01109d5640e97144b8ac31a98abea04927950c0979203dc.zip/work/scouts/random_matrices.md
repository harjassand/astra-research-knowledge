# Random matrices scout — 7 October 2026

## Verdict and ranked targets

**No established major breakthrough in this scout.** There is a complete short candidate proof of a useful deterministic truncation bound, an exact source-uniform inverse-gap identity, and a decisive obstruction to interpreting cusp universality as whole-experiment compression. The first proof merits an independent audit and priority search; the second is already implied by recent primary literature. Neither depends on the repository's unreviewed quantum Gaussian bridge.

1. **Audit and clear priority for the signed/rectangular spectral truncation bound in Section A.** It removes the largest-singular-value logarithms in the inspected 2025 indefinite-matrix bound, and extends to arbitrary perturbation size. This is a tractable mathematical result with practical uses in noisy/quantized low-rank approximation. Its likely upside is a clean perturbation theorem/proof simplification, not a foundational intelligence result. Fatal tests: simultaneous positive/negative retained bands; multiplicities inside bands; an omitted band containing both signs; rectangular dilation; older Wedin/Stewart/TSVD results. The written proof survives these interface checks; novelty remains uncertain.
2. **Determine the simultaneous signal/precision memory law for one Gaussian sphere observation.** Exact interface: one observed `X ~ N(Ru,I_3)`, known `R >= 1`, unknown `u in S^2`, all input-dependent retained data through an algebra of total dimension `D`, decoder produces a fresh `Y`, risk `sup_u TV(Law(Y),N(Ru,I_3))`. Fixed-error high-signal orbit volume and fixed-signal high-precision ambient dimension are distinct limits. The supplied N07/N08 result explicitly leaves their joint limit open. Start here before arbitrary qudit partial collisions. This is more ambitious, but not solved below; the load-bearing question is the positive decoder's treatment of radial fluctuations. Fatal test: a claimed two-dimensional sufficient observation must reproduce the radius/direction correlation in Section C.
3. **Growing-dimension Gaussian bridge with explicit source-uniform constants.** The inverse-gap identity in Section B supplies dimension-explicit eigenvalue regularity without fixed-d HCIZ constants. It could support a growing-d version of the Schur/Gamma bridge, but it does not supply the angular classicalization bound, high-dimensional Gamma expansion, or reverse-channel error. Run only after determining a legal scaling regime and checking high-dimensional Schur–Weyl/Wishart prior art. Expected value is lower than target 1 for a short proof wave.

Do **not** allocate a depth wave to the February 2025 “spectral-norm utility” open problem as stated: Tran–Vishnoi–Vu resolved its PSD version later in 2025. Do **not** allocate one to another fixed-d `n^-1/2` jitter refinement: it is already in the supplied inherited package.

## Source and interface intake

Read `work/astra-research-knowledge/00_START_HERE.txt`, `01_CORE.txt`, `topics/quantum.txt`, and these exact cards:

- `cards/P-q-d-gauss.txt`: candidate fixed-d tracial bridge, coarse original rate, exact Schur/HCIZ and reverse-channel dependencies.
- `cards/N07-gaussian-memory.txt`: fixed bounded Gaussian mean set, one actual sample, arbitrary quantum/hybrid memory, affine observation dimension, constants not uniform for varying mean geometry.
- `cards/N08-block-critical-gaussian.txt`: inherited `O_d(delta+n^-1/2)` refinement; known block algebra only; simultaneous signal/precision and unrestricted partial collisions remain open.

Opened the full supplied texts at `web/pages/d-c4a9e95fccd25a09.html` (inherited `gaussian_rate_refinement.md`), `web/pages/d-900a3c8187ffc0aa.html` (`quantum_collision.md`), and `web/pages/d-7bf3825bbd159ebb.html` (`critical_gaussian_audit.md`). Extraction copies are local scout scratch files with those source IDs. These remain internal candidate proofs, not external correctness or priority clearance.

Primary refresh:

- [Mangoubi–Vishnoi, 2025](https://arxiv.org/abs/2502.07657), Lemma 4.2 and Section 9.1: coupled Dyson processes preserve componentwise ordering of adjacent gaps for beta at least 1. Theorem 2.4 gives source-uniform small-gap bounds. Remark 5.3 states the then-open stronger spectral-norm utility problem. Proof route read, not the whole 97-page paper audited.
- [Tran–Vishnoi–Vu, 2025](https://arxiv.org/html/2510.25670v1), Theorems 2.1 and 4.1 and corresponding proof sections: PSD spectral-norm truncation error has scale `||E|| sigma_k/gap_k` under `4||E|| <= gap_k`; the indefinite extension includes logarithms involving the largest singular value. This closes the earlier PSD open problem. No novelty claim for reproducing their PSD scaling.
- [Graczyk–Sawyer, 2021](https://arxiv.org/pdf/2111.13529), estimate (1.1), recursive proof in Section 2: type-A W-invariant Dunkl/orbital kernels have two-sided root-product estimates, uniform in the arguments for fixed root system/multiplicity. These are appropriate collision tools; they are not growing-rank constants supplied for free.
- [Erdős–Henheik–Riabov, 2025 publication](https://arxiv.org/html/2410.06813v2), Assumptions 2.1–2.5 and Theorem 2.13: correlated Hermitian cusp universality with bounded expectation, all moments, quantitative cumulant decay, fullness, and bounded MDE solution in an admissible interval. The result compares fixed-order correlation functions against smooth tests. It is not an assertion of Le Cam/TV equivalence of whole experiments.
- [Bleher–Kuijlaars, 2006/2007](https://arxiv.org/pdf/math-ph/0602064), double scaling around the two-source critical value `a=1`: the `a=1+O(N^-1/2)` and eigenvalue `N^-3/4` scales are the correct Pearcey setting for the counterexample below.
- [Vu–Chunikhina–Raich, 2021](https://arxiv.org/abs/2009.07542), older TSVD first-order expansion and arbitrary-magnitude remainder analysis around exactly rank-r matrices. This is a priority lead that still needs theorem-by-theorem comparison with Section A.

The September 2026 [Yamaguchi–Tajima paper](https://arxiv.org/abs/2609.11926) and October 2026 [Hayden–Maloney–Wang–Yang paper](https://arxiv.org/html/2610.06742v1) were refreshed for scope: fixed-reference degenerate unitary QLAN and fixed separated-spectrum memory do not automatically give unrestricted moving-collision experiments. Their proofs/formal certificates were not validated in this scout.

## A. Candidate internally proved result: signed and rectangular truncation

Let `A` be any real or complex `m x n` matrix, let `1 <= k < min(m,n)`, and write its singular values in decreasing order. Assume

`g = sigma_k(A) - sigma_(k+1)(A) > 0`.

Let `A_k` denote its truncated SVD, and let `(A+E)_k` be any truncated SVD if a tie occurs at the perturbed boundary. The following candidate bound holds for **every** perturbation `E`, without a smallness assumption:

`||(A+E)_k - A_k||op <= 8 [sigma_k(A)/g] ||E||op`.             (A1)

The constant 8 is conservative; no optimal-constant claim. This is a written analytical proof, internally checked, not externally reviewed. It is independent of any oracle, unknown-spectrum acquisition, quantum LAN, or distributional assumption. The singular gap is a supplied condition in the theorem; an implementation must acquire or certify it if it uses the numerical bound. The code still performs a standard SVD; no faster algorithm is supplied.

### Hermitian proof, including both signs

First let `A` be Hermitian and truncate its `k` largest *absolute* eigenvalues. Set `s = sigma_(k+1)(A)` and `eta = ||E||op`. When `eta < g/4`, along `A_t=A+tE`, the retained positive band `R+`, retained negative band `R-`, and omitted middle band `O` remain separated. Weyl gives

`||A_t|O|| <= s+eta`, and each separation from `O` is at least `g-2eta >= g/2`.

The truncation `F(A_t)` is analytic along this path even when eigenvalues repeat *inside* a band. In the decomposition `R=R+ directsum R-` versus `O`, its Fréchet derivative in a Hermitian direction `H` has blocks

`DF(A_t)[H] = [[H_RR, K],[K*,0]]`.

This retained-retained block is exactly `H_RR`, **including** the positive-negative cross block: the scalar function is the identity on both retained bands. This is the cancellation that prevents a dependence on the largest eigenvalue.

For either retained sign, the off-diagonal entries are

`K_(ij) = [x_i/(x_i-y_j)] H_(ij)`.

Let `X_+` solve `A_R+ X_+ - X_+ A_O = H_R+O` and similarly for `X_-`. Each is an ordered-spectrum Sylvester equation. Its Laplace-integral solution gives

`||X_±||op <= ||H_R±O||op/(g-2eta)`.

Since `K_±=H_R±O+X_± A_O`,

`||K_±||op <= [1+(s+eta)/(g-2eta)] ||H||op`.

Stacking the two retained signs costs at most `sqrt(2)`, hence

`||DF(A_t)[H]||op <= {1+sqrt(2)[1+(s+eta)/(g-2eta)]}||H||op`

`<= 4 (1+s/g)||H||op`.

Integrating with `H=E` proves a stronger constant-4 local bound. Empty positive/negative bands cause no issue; simply omit that Sylvester equation. Internal multiplicity causes no issue because the spectral function is affine on each separated band.

If `eta >= g/4`, no derivative argument is needed. For any Hermitian or rectangular `B=A+E`,

`||B_k-A_k|| <= ||B-A|| + ||B-B_k|| + ||A-A_k||`

`<= 2eta+2s <= 8(1+s/g)eta`.

Here `||B-B_k||=sigma_(k+1)(B)<=s+eta`; this remains valid for any perturbed boundary tie. Since `1+s/g=sigma_k/g`, this establishes (A1) for Hermitian matrices.

### Rectangular extension

Use the Hermitian dilation

`H(A) = [[0,A],[A*,0]]`.

It has eigenvalues `+sigma_i(A), -sigma_i(A)` and possibly zeros, norm `||H(A)||=||A||`, and its truncation retaining the `2k` largest absolute eigenvalues is exactly `H(A_k)`. The external absolute spectral gap is still `g`. Applying the Hermitian result to `H(A)` and `H(E)` proves (A1).

### Sharper signed local statement

For Hermitian `A`, let `g_band` be the minimum of its positive and negative retained-to-omitted *signed* boundary gaps (omit a missing side). Then `g_band >= g`. Under `eta <= g/4`, the same argument yields

`||(A+E)_k-A_k|| <= 4 eta [1+s/g_band]`.                     (A2)

This avoids the `log(sigma_1/boundary_gap)` terms in the inspected Theorem 4.1 of Tran–Vishnoi–Vu. It does not dominate every spectrum-adaptive refinement in that paper: the comparison must preserve whether the boundary is an absolute singular gap or a signed eigenvalue gap. This scout has not established that (A1)/(A2) are absent from older SVD perturbation theory.

### Sharp-scale lower example and diagnostic

Take `A=diag(1+g,1)` and `E=t [[0,1],[1,0]]`, with `t/g -> 0`. The off-diagonal entry of the rank-one truncation changes by `(1+g)t/g + o(t/g)`, so the factor `sigma_k/g` is necessary up to a universal constant. A zero boundary gap permits discontinuous truncation. These show why an unrestricted gap-free bound of order `||E||` would be false for this metric.

`work/scouts/random_matrices_check.py` tested 1,500 complex rectangular cases, wide retained spectra, narrow boundary gaps, and both small/large perturbations. Maximum ratio to `(sigma_k/g)||E||` was about 1.0893; all were below 8. The 2x2 necessity ratios approached 1. `random_matrices_check.json` retains the summary. These are failure-finding diagnostics only; (A1) rests on the analytic proof.

**Best next action:** independent reconstruction of the derivative and dilation proof plus priority comparison with Wedin, Stewart, the 2021 TSVD paper, and Theorem 4.1. If known, retain as a short reusable lemma and close the novelty branch. If genuinely missing, formulate an exact proposition around eliminating the signed logarithm, not around solving PSD privacy utility already settled in 2025.

## B. Exact inverse-gap identity: useful mechanism, prior-art overlap

Let `X=A+sigma G`, where `A` is any deterministic Hermitian source and `G` is HS-isotropic GUE with density proportional to `exp(-Tr G^2/2)`. Write ordered eigenvalues `x_1>...>x_d`, `R=d(d-1)/2`, and

`S(x)=sum_(i<j) 1/(x_i-x_j)^2`.

Then the sharp source-uniform bound is

`E S(X) <= d(d-1)/(4 sigma^2)`,                              (B1)

with equality at scalar `A`. It holds also after removing the scalar trace coordinate, since gaps and all derivatives below are trace-translation invariant. With conventional variance-`1/d` GUE noise, replace `sigma^2` by `1/d`.

Independent short derivation: the eigenvalue density is

`p_A(x) proportional to Delta(x)^2 exp(-||x||^2/(2 sigma^2)) I_A(x)`,

where `I_A(x)=integral exp[Tr(A U diag(x) U*)/sigma^2] dU`. Put `v=grad log Delta` and `h=grad log I_A`. Vandermonde identities give

`div v=-2S`, `||v||^2=2S`, and `x.v=R`.

Integrating `div(p_A v)` gives the exact identity

`2 E S = R/sigma^2 - E sum_(i<j) (h_i-h_j)/(x_i-x_j)`.

`log I_A` is convex (log moment-generating function) and symmetric (Haar permutation invariance), so its gradient is ordered with the coordinates: every summand on the right is nonnegative. Boundary flux vanishes because `p_A v` vanishes linearly at a collision; Gaussian tails control infinity. Polynomial approximation/cutoff justifies the integration. At scalar `A`, the added gradient is scalar and every summand vanishes.

This is **not cleared as a new theorem**: the stronger pathwise gap comparison in Mangoubi–Vishnoi, Lemma 4.2, already implies (B1) after evaluating the central GUE moment. The direct HCIZ proof supplies exact constants without integrating a high-probability gap tail with residual probability.

A deterministic-perturbation consequence: for a fixed Hermitian `H` independent of the Gaussian noise, ordered rank-one eigenprojectors satisfy

`E sum_i ||P_i(A+sigma G+H)-P_i(A+sigma G)||HS^2`

`<= [d(d-1)/sigma^2] ||H||op^2`.

Along the affine path, their derivative has squared energy `4 sum_(i<j)|H_ij|^2/(x_i-x_j)^2`; integrate and use (B1). Gaussian genericity excludes an exact collision on the one-dimensional deterministic path almost surely. This does not authorize the same estimate for a perturbation selected after observing the noise. Neither gap regularity nor this estimate alone proves a channel/compression equivalence.

## C. Joint signal/precision: exact sphere disintegration and missing step

For the target-2 Gaussian sphere experiment, write `r=||X||` and `v=X/r`. The radius has a public noncentral-chi law `q_R`, independent of `u`, but conditionally

`v | r,u ~ vMF(u,kappa=Rr)`.

In dimension 3 its normalized density relative to uniform sphere measure is

`f_(Rr)(v|u) = [Rr/sinh(Rr)] exp(Rr u.v)`.

Thus the radius is ancillary **marginally**, but carries information through its correlation with directional concentration. Replacing it by an independent freshly sampled radius does not reproduce the joint experiment exactly. At `r=R+O(1)`, the directional scale changes at relative order `1/R`; a naive two-dimensional orbit counting argument overlooks this precision issue.

An attractive but currently **unproved** route is a positive radial/angular quantizer with uniform approximation bounds and an arbitrary-quantum converse. Simple local metric/curvature heuristics can suggest different transition scales (`R epsilon` versus `R^2 epsilon`), because preserving a public radial marginal constrains which first moments a positive decoder can cancel. Do not state either heuristic as a theorem. A stationary finite-state positive radial kernel cannot reproduce a nonconstant linear radial function exactly: if `E[r'|r]=r` and `r,r'` have the same finite second moment, Jensen forces `r'=r` almost surely. This blocks a casual “barycentric interpolation costs only radial curvature” proof.

Expected value: a genuine sharp law here would clarify when fixed-spectrum storage follows orbit dimension and when finite-error precision follows the full observation dimension. It could subsequently transfer to qubits only above the independently certified quantum Gaussian remainder; unrestricted qudit partial-collision Fock/block factorization would still remain a separate step.

## D. Cusp universality is not whole-spectrum experiment compression

Let `N` be even, `D=diag(+1,...,+1,-1,...,-1)` with equal multiplicities, and

`H_N(a)=aD+N^(-1/2)G_N`,

where `G_N` is HS-isotropic GUE. This is the classical two-source cusp model at `a=1`. The full-spectrum statistic `T=Tr H_N(a)^2` has exact moments

`E_a T=N(1+a^2)`, `Var_a T=4a^2+2`.

Proof: expand `T=N a^2 + (2a/sqrt(N)) Tr(DG_N) + Tr(G_N^2)/N`. The linear term has variance `4a^2`; the quadratic term is a scaled chi-square in `N^2` real Gaussian coordinates with variance 2; their covariance vanishes by odd Gaussian moments.

For fixed `c>0`, set `a_±=1±c/sqrt(N)`. Their mean separation is `4c sqrt(N)`. The test at the midpoint has total error at most

`[Var_(a+) T+Var_(a-) T]/(4c^2 N)=O_c(N^-1)`.

Therefore the TV distance between their **whole-spectrum** laws tends to 1. Any proposed equivalence to a fixed-window Pearcey observation with overlapping laws at the two finite limiting parameters would contradict data processing. The current local universality theorem itself makes no such claim; this falsifies an attempted transfer, not the theorem. An observation of the entire limiting point process on an unbounded line is a different interface and is not ruled out by this argument.

The obstruction already uses only eigenvalues, so keeping an unknown eigenbasis cannot repair the proposed compression. To build a Pearcey statistical experiment, explicitly restrict observation to a cusp window, or account for the independent bulk information and its costs. Correlation-function universality and full likelihood/TV convergence are separate proof requirements.

## Provenance and costs

All technical work here is local algebra, standard SVD/gap computations, and bounded primary-source retrieval. No external computation, training, empirical scientific data acquisition, publication, push, or external messages. No supplied unknown parameter was treated as an acquired observation. The truncation lemma concerns stability of a matrix already available to an algorithm; it does not acquire a useful low-rank representation, data oracle, or gap certificate. Classical continuous-output experiments do not by themselves furnish finite-bit sampler/runtime costs.

Memory was used only to locate the earlier candidate bridge and preserve its provisional status, then the current repository/source pages were reopened. Relevant memory pointers: `MEMORY.md:85-97` and `rollout_summaries/2026-10-06T16-44-34-0JR9-uniform_gaussian_equivalence_spectral_collisions.md:20-39`; prior rollout ID `01a1121a-4750-72f0-8f5c-b501038890d3`.
