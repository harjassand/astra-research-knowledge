# Number theory scout — 7 October 2026

The strongest completed findings are two decisive boundary results: an advertised rank-two lattice test in a 2025 effective-height preprint is false, and the unrestricted coprimality sieve in a 5 October 2026 sum-product preprint cannot improve its exponential base. Neither finding validates or invalidates the complete parent theorems. The most promising new target is a coprimality estimate that uses the geometry of the actual lattice-point set. Exact automorphism-kernel certificates offer a smaller, more practical target.

No extraordinary release theorem was adopted as established mathematics. No source files were modified. All calculations below are original local arithmetic; the finite fixtures are subordinate to the displayed universal arguments.

## Sources refreshed and actual reading scope

* Garcia-Fritz–Pasten, [Effective Mordell for curves with enough automorphisms](https://arxiv.org/html/2503.10443v2), March 2025: read the precise main/gap statements, the closing Arakelov inequality in §5.1, §5.2's orbit argument, and the practical height conversion in §6.1. The reusable input is the explicit gap inequality for distinct points. The complete Arakelov dependency chain was not independently rebuilt.
* Prakash, [Effective height bounds from Mordell–Weil lattice symmetries](https://arxiv.org/html/2509.22672v1), September 2025: read the complete short HTML paper, including §3's proofs, §3.1's Bravais test, and the displayed genus-two example. Its averaged inequality has an elementary valid derivation from the supplied gap inequality. The Bravais recognition rules have the flaw proved below.
* Fujimori, [Rational points of a curve which has a nontrivial automorphism](https://www.numdam.org/item/ASNSP_1997_4_24_3_551_0.pdf), 1997: downloaded the primary PDF after browser retrieval timed out. Read the introduction and the representation/equivariance material on printed pp.554–557; visually inspected printed pp.552 and 557 because extraction loses equations. The old mechanism already puts the canonical curve image near automorphism-dependent quadrics. A new symmetry-to-height principle should therefore not be claimed. Local copy: `work/scouts/number_theory_data/fujimori_1997.pdf`.
* Bloom–Sawin–Schildkraut–Zhelezov, [The sum-product conjecture is false for real numbers](https://arxiv.org/html/2605.28781v1), May 2026: read exact quantifiers, bounded-root-discriminant/unit-lattice construction interfaces, and the degree restriction. The fields' degrees grow with set size; this is not an integer or fixed-degree counterexample.
* Roche-Newton–Schildkraut–Warren, [More sum-product type counterexamples: products with shifts and AA+A](https://arxiv.org/html/2606.24583v2), June 2026: read the short construction and its real/integer boundary. This already covers several tempting shifted-product consequences, so they are not new scout targets.
* Zhang–Zeng–Wang, [Ideal-smooth sets and an explicit upper bound for the real sum-product exponent](https://arxiv.org/html/2610.05725v1), 5 October 2026: refreshed the claimed exponent 1.95835 and read the tower setup, §6.2's simultaneous fibre construction, the complete §6.3 residue-sieve proof, injectivity, and the rate criterion. Independently reconstructed Lemma 6.3 only. The tower, outer-parallel-body analysis, and numerical exponent are unvalidated here.
* Calderbank–Frankl–Graham–Li–Shepp, [The Sperner capacity of linear and nonlinear codes for the cyclic triangle](https://mathweb.ucsd.edu/~ronspubs/93_04_sperner.pdf), 1993: the primary abstract and theorem description identify the exact old antichain/capacity mechanism relevant to the sieve obstruction. The antichain is old mathematics; its transfer to the recent sieve interface is the scout's derivation.
* Li, [Every natural number is a sum of distinct semiprime unit fractions](https://arxiv.org/html/2606.15159v2), June 2026: read the central-block/onset mechanism, the rational threshold recurrence, and §9's gap-free-floor conjecture. Its universal proof and claimed Lean closure were not audited. In particular the displayed upper recurrence adds positive errors and does not itself prove that the true floor tends to zero. I did not adopt the claimed resolution as a new proven input.

The supplied L09/L10 capital was read at proof level where relevant:

* `work/astra-research-knowledge/web/assets/9ea87c3a41b7a2521cec70f583c0f46ec7dcd118789ed3d9f55c7f42fcad9915.md`, the complete optimized Egyptian construction (source path `literature/notes/frontier_number3/cycle19/025_OPTIMIZED_CONSTRUCTION.md`).
* `work/astra-research-knowledge/web/pages/d-4cc7cf32a6472951.html`, exact height constants (source path `literature/notes/logic_gate14/cycle19/EXPLICIT_CONSTANT_ACQUISITION.md`).

L10 gives a fixed-curve finite certificate conditional on rank/torsion/canonical-height premises. It does not supply a general rank acquisition method or validate the single-fold Diophantine composition. L09 gives short certificates; its supply search and repeat normalization are separate acquisition debts.

## Completed result 1: a false Bravais test, a repair, and a spectral limitation

The preprint classifies a reduced rank-two Gram matrix as oblique, with orthogonal group order two, when its off-diagonal entry is nonzero, its diagonal entries differ, and their normalized correlation is not ±1/2. Take

\[
Q=\begin{pmatrix}2&1\\1&3\end{pmatrix},\qquad
A=\begin{pmatrix}-1&-1\\0&1\end{pmatrix}.
\]

This is positive definite and Gauss reduced: \(2|Q_{12}|\le Q_{11}\le Q_{22}\). All three of the paper's oblique tests hold; the correlation is \(1/\sqrt6\). Nevertheless

\[
A^\top QA=Q,\qquad A^2=I,
\]

so \(\{I,-I,A,-A\}\) is a four-element orthogonal group. Exact bounded enumeration finds precisely these four matrices. Thus the practical rule can falsely infer a nontrivial kernel from a four-element curve automorphism group. This is a counterexample to the lattice recognition implication. I have not constructed a Jacobian with this exact canonical-height Gram matrix, so it is not a counterexample to the independent kernel-height theorem or to the paper's specific curve.

For a genuinely Gauss-reduced matrix \(Q=\left(\begin{smallmatrix}a&b\\b&c\end{smallmatrix}\right)\), \(a\le c\), \(2|b|\le a\), the correct symmetry walls are \(b=0\), \(a=c\), and \(2|b|=a\). Off these walls the order is two; a single nonspecial wall gives four; square and hexagonal cases give eight and twelve. The missing \(2|b|=a<c\) case is the fixture above. Equal diagonals with \(0<2|b|<a\) are also absent from the displayed recognition table. Ordinary LLL reduction should not be silently identified with exact Gauss reduction.

A safe finite certificate does not require this classification: enumerate integer column vectors of the prescribed norms and inner product. Since \(\lambda_{\min}(Q)\ge\det Q/\operatorname{tr}Q\), their Euclidean lengths have an explicit finite bound. With certified intervals for a real height Gram matrix, retain every integer matrix that the intervals fail to exclude; this gives an upper bound on the true orthogonal group. Close symmetry walls can prevent a useful conclusion, but cannot produce a false kernel. The naive enumeration is finite, not claimed polynomial in Gram bit length or conditioning.

There is also a sharp limitation of the averaged criterion in the headline \((g,r)=(2,2)\) regime. Let the automorphism action on the integral rank-two lattice be faithful. Every nonidentity integral orthogonal matrix has trace at most one: a reflection has trace zero; an orientation-preserving matrix has integer trace in \([-2,2]\), and trace two forces the identity. Therefore any probability average of the symmetrized nonidentity actions has trace at most one and

\[
\lambda_{\min}(S_\mu)\le\tfrac12\operatorname{tr}(S_\mu)\le\tfrac12.
\]

The genus-two criterion requires a strict value above one half. **Consequently it cannot give any faithful rank-two genus-two case.** A nontrivial kernel immediately gives the value one. Thus existence of a successful spectral average in this regime is equivalent to existence of a kernel, under the supplied integral action interface. This is a universal proof, not a finite scan. It also shows why this spectral method does not dominate Garcia-Fritz–Pasten's cardinality method: faithful dihedral actions of orders eight or twelve can satisfy that older orbit-angle criterion while every such average fails the strict spectral threshold.

Useful certificate refinement: supply a certified rank upper bound r, r independent rational Jacobian points, and exact torsion certificates for \(\sigma_*P_i-P_i\). They span the real Mordell–Weil space, so saturation or a complete integral basis is unnecessary to certify \(\sigma_*=I\) there. If \(\sigma\) moves a curve point P, the gap inequality directly gives

\[
\widehat h(j(P))\le M(X)/(2g-2).
\]

Only the support of the chosen automorphism must move P; a trivial stabilizer under the entire kernel is unnecessary. Common fixed points can be solved separately as a finite algebraic locus. The displayed decimal height zero in a source table is not itself an exact torsion certificate.

## Completed result 2: the new coprimality sieve's base is optimal

Lemma 6.3 of the 5 October preprint says that, for arbitrary finite B and m selected prime ideals, some anchor \(a\in B\) retains at least \(2^{-m}|B|\) elements satisfying

\[
b-a+X\notin\mathfrak p_j\quad(1\le j\le m),
\]

where X is nonzero in every residue field. Its rank-two local feature and tensor-rank proof reconstruct correctly. A tempting improvement at odd primes is false.

Choose any m distinct rational primes, all odd, and set X=1. By CRT realize every binary word of Hamming weight \(\lfloor m/2\rfloor\) as an integer with residues 0 or 1 at those primes; let B contain exactly those representatives. For different words a,b of the same weight, some coordinate has a=1 and b=0. At that prime \(b-a+1=0\). The anchor itself is always admissible, and every other element is excluded. Thus every anchor retains exactly

\[
1/\binom m{\lfloor m/2\rfloor}=\Theta(\sqrt m\,2^{-m})
\]

of B. No universal improvement \((2-\eta)^{-m}\), with fixed \(\eta>0\), is possible. This extends verbatim to distinct prime ideals through ideal CRT. The equal-weight antichain obstruction is consistent with the old base-two Sperner-capacity theorem; the present application does not claim priority for that theorem.

Small exact fixture: primes \(3,5,7,11\), X=1, and

\[
B=\{441,540,561,595,616,715\}\pmod {1155}.
\]

Every anchor retains only itself. Retention is \(1/6\), already below the plausible odd-prime bound \((2/3)^4=16/81\). An enumeration verifies every row with integer modular arithmetic.

This is an obstruction at the **arbitrary B** interface. In the actual sum-product construction B consists of all algebraic-integer lattice points in a translated Minkowski box. It does not rule out improvements that exploit that extra structure. The method's common translates, class-group index, and primitive residue constraints must remain charged; no equidistribution is supplied for free.

## Ranked next targets and fatal tests

1. **Geometry-aware coprimality sieve for the actual ideal-smooth construction.** Highest potential payoff: remove a positive fraction of the \(m\log2\) entropy cost in the explicit exponent calculation. Target an anchor estimate for complete lattice-point sections of the specified translated boxes, using certified discrepancy or a dual-lattice condition. Compare against the current rank-two sieve with the same field, box, prime ideals, and acquisition costs. Fatal test: show the needed box class can concentrate on antichain-like CRT patterns, or show that certifying discrepancy costs a comparable exponential factor. The universal abstract improvement is already dead. Expected value is medium: the numerical objective is concrete and fresh, but a new geometry input is genuinely load-bearing.
2. **A complete exact automorphism-kernel frontend to effective Mordell.** Most tractable target: acquire one rank certificate, a full-rank independent subgroup, exact torsion differences, automorphism formulas, and the explicit Arakelov upper constant; emit a verified finite search bound including the fixed locus. It avoids erroneous Bravais recognition and saturation. Strong comparator is existing Magma/Sage group and height routines with equally supplied rank information. Fatal tests are failure to certify rank, an unproved zero-height claim, or an impractically large M(X). Mathematical novelty is likely modest; the useful deliverable is an auditable arithmetic certificate pipeline. No actual curve pipeline was completed in this scout.
3. **L09 supply acquisition rather than further existential coefficient tuning.** Vinogradov's positive triple count alone permits rejection sampling prime triples in expected polynomial time in \(\log u\): sample two integers in \([1,u]\), set the third to their positive remainder, and test primality. The remaining problem is acquiring small-primorial divisor residues and a zero-sum triple of products. The supplied Fourier proof gives existence, with a margin as small as \(1/p^2\); it does not give a polynomial-time witness finder or a uniform sampler on distinct residue images. Exhaustive divisor enumeration and generic sampling remain exponential in bit length. A meaningful next result must address this structured modular search and Takenouchi cleanup. Faster prime-triple search alone does not remove the bottleneck. Expected value is lower until a genuine algorithmic lemma appears.

The semiprime gap-free-floor conjecture remains an alternative with major payoff, but the checked recurrence only propagates a positive floor and contains no mechanism forcing it to zero. It ranks below the concrete geometric sieve target rather than becoming a default frontier merely because the 2026 paper advertises formal verification.

## Executable evidence and status

Run `python3 work/scouts/number_theory_checks.py`. It independently enumerates the rank-two fixture's full orthogonal group and all six CRT anchor rows. Output: `work/scouts/number_theory_data/exact_checks.json`. All assertions passed. These checks verify the displayed finite arithmetic only.

Internally proved here: the Bravais counterexample, the faithful rank-two genus-two trace obstruction, the full-rank subgroup kernel certificate implication, and the CRT transfer of the old antichain obstruction. Established older mechanisms: automorphism-equivariant canonical geometry and Sperner-capacity/antichain arguments. Unvalidated source claims: the newest full real sum-product exponent, the semiprime universal proof/formalization, and the release's complete Egyptian/single-fold frontier theorems. Open: the geometry-aware sieve and all proposed acquisition pipelines.
