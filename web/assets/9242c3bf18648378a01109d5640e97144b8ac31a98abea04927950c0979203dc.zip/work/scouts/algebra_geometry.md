# Algebraic geometry scout — 7 October 2026

## Result and allocation recommendation

Two technical results survived this pass. Neither is a broad new reconstruction theorem, and neither acquires the global invariant assumed in L06.

1. **Positive, internally proved:** the exponent-one local intersection can be decided with **O(p²) base-field arithmetic and O(p) coefficient storage**, rather than the source note's O(p³) power scan. Its nonzero witness has **at most p nonzero p-basis monomials**, and can be emitted with O(p) additional base arithmetic after obtaining the affine power coefficients. The same derivative test gives a finite decoder of an unknown field isomorphism from a **promised geometric quotient-map oracle**, with at most two evaluations per field generator. This is the strongest positive target here.
2. **Negative, internally proved:** even for the fully explicit field F_p(x,y), exact symbol-zero access plus an evaluation oracle for an F_p-linear bijection cannot finitely certify global symbol compatibility. An explicit, single-divisor valuation transvection evades any finite transcript and violates a specific Steinberg pair. There is also a sharp total-query-degree bound against a bounded family of these maps. This decisively blocks converting the structural theorem into black-box compatibility testing without an additional representation promise.
3. **Bridge, lower priority:** if L06 is correct, its relative invariant determines the associated restricted Lie algebra of derivations, hence the generic height-one foliation data. Extending this to higher inseparable height needs compatible intermediate-field data; rank-one floors and model acquisition are substantial gates. The modern differential-operator correspondence supplies an alternative representation, not an acquired one.

Expected value: finish and adversarially audit the framed decoder before spending on higher-height reconstruction. The valuation obstruction should accompany every proposed invariant-only acquisition interface. Novelty of the local computation and the explicit obstruction remains uncertain; both may be elementary consequences that have not been packaged this way.

## Primary literature refresh and source scope

- [Cadoret–Pirutka, Reconstructing function fields from Milnor K-theory](https://arxiv.org/html/1808.04944), Theorem 4, proof strategy §1.3, and differential/intersection argument §3.4 (especially Lemmas 22, 24, 25). Their invariant uses F*/k* with algebraic dependence, for finitely generated regular extensions over perfect constants. It is not the relative mod-characteristic binary predicate here. The differential computation and common-power ambiguity substantially predate L06. Relevant sections were read; the entire paper was not re-audited.
- [Topaz, Algebraic dependence and Milnor K-theory](https://arxiv.org/html/2211.14665), introduction, §2.1, Theorem 5.3 and its proof. Rational Milnor K-theory recovers sufficiently large fields up to purely inseparable extension; rationalization itself loses the inseparable information. This separates that mechanism from L06's proposed height-one reconstruction. Read depth: selected interfaces/proofs, not the complete local valuation theory.
- [Grabowski, Power Towers: Purely Inseparable Galois Theory and Foliations in Positive Characteristic](https://arxiv.org/html/2510.06058v1), §3.2 and Theorem 4.15 with its proof. Power towers correspond to compatible sequences of restricted Lie algebras and to subalgebras of differential operators. The proof explicitly uses joint annihilators and Jacobson–Bourbaki. This is a recent route to higher-height inseparable geometry, but it starts with an ambient field/operator representation. Selected theorem and proof read; no whole-paper correctness endorsement.

Exact local sources loaded:

- `work/astra-research-knowledge/00_START_HERE.txt`, `01_CORE.txt`.
- `work/astra-research-knowledge/cards/L06-relative-field.txt`.
- `work/astra-research-knowledge/web/pages/d-678b7b5ff62040cd.html`: original path `literature/notes/frontier_number1/cycle19/RELATIVE_RECONSTRUCTION.md`. Full handwritten note read, local lemma and differential arguments rederived.
- `work/astra-research-knowledge/web/pages/d-7db6f722ce69ecfc.html`: original path `literature/notes/root_cycle19/RELATIVE_FIELD_RECONSTRUCTION_GATE.md`. Internal gate, not external validation.
- `work/astra-research-knowledge/web/pages/d-58d56a1cdeca284c.html`: original path `literature/sources/frontier_number1/cycle19/lean-doc-009.md`. The formalization scope is injectivity for the different characteristic-not-ell Bogomolov–Pop correspondence. It does not certify the mod-characteristic relative theorem or the results below.

The new released manuscript is known here through the supplied reconstructed note and its provenance; I did not independently retrieve its original full manuscript. The effective decoder below is independently valid under its explicit **geometric promise**, so its algebraic proof need not assume that every predicate-preserving map is geometric. Substituting the latter promise depends on L06's structural theorem, whose infinite-dimensional projective lifting was not formalized in this pass.

## 1. Derivative decision test and sparse witness

Let B be a characteristic-p field and let X,Y be p-independent over B, with X^p=A and Y^p=B_0 in B*. Work in B(X,Y). Let U∈B(X)* and V∈B(Y)* be nonmonomial: neither is a B* multiple of a power of its coordinate. Put

    P = X B(Y/X),       Q = U B(V/U).

Let D_X(X^i)=iX^i, and define D_Y similarly. For a univariate input U, compute

    E = U − D_X U,
    Q_U = E D_X U,
    M_U = (D_X U)² − U D_X² U.

Both E and D_X U are nonzero by the nonmonomial assumption. Hence Q_U≠0. Pick any nonzero coefficient q_i of Q_U, set m_U=(M_U)_i/q_i in B, and check all coefficients of

    M_U = m_U Q_U.

Accept the local exponent only when m_U belongs to F_p*; then return n_U=p−m_U in {1,…,p−1}. Prime-field membership/integer identification can use p comparisons/additions, with no unstated discrete-log oracle. Apply the same operation to V.

**Claim.** P∩Q≠0 iff both tests return the same exponent n. In that case dim_B(P∩Q)=1.

**Proof of the univariate test.** Set a_U=U/(D_XU)−1=E/(D_XU). Direct differentiation gives

    (D_X a_U)/a_U = M_U/Q_U.

Thus the test is exactly the assertion that a_U is an Euler eigenvector of nonzero eigenvalue m_U. In the p-monomial basis, this is equivalent to a_U=hX^m for h∈B*. Put n=p−m. The logarithmic derivatives of U^n and X^n+hX^p coincide; their quotient is in ker D_X=B. Therefore

    U^n=a+bX^n,       a,b∈B*.

Conversely, this affine-power identity gives a_U=a/(bX^n), of eigenvalue −n. Thus the unique exponent is extracted without testing every power.

**Why intersection forces the common exponent.** If Z∈P∩Q is nonzero, put q_X=D_XZ/Z and q_Y=D_YZ/Z. The two Euler operators associated with (X,Y) and (U,V) give

    q_X+q_Y=1,
    a_U q_X+a_V q_Y=0.

The operator D_X+D_Y kills both q's, since it gives Z eigenvalue 1. Therefore it kills a_U/a_V. It follows that

    D_Xa_U/a_U = D_Ya_V/a_V ∈ B(X)∩B(Y)=B.

The two nonconstant Euler eigenvectors have the same nonzero eigenvalue. This proves necessity. The equations also uniquely fix both q's, so any two nonzero intersection elements have quotient in the common derivative kernel B. This proves the dimension assertion.

**Explicit witness and sparse output.** If U^n=a+bX^n and V^n=c+dY^n, let r∈{1,…,p−1} satisfy nr≡1 mod p. Then

    Z=(bcX^n−adY^n)^r=(cU^n−aV^n)^r

is in both subspaces. For 0≤j≤r, its p-basis coefficient at

    (X exponent, Y exponent) = (nj mod p, n(r−j) mod p)

is

    binom(r,j) (bc)^j (−ad)^(r−j)
      · A^floor(nj/p) · B_0^floor(n(r−j)/p).

These r+1 positions are distinct, and all their coefficients are nonzero. Therefore the witness has exactly r+1≤p terms, rather than needing p² dense coefficient slots. Consecutive coefficients are generated by the binomial recurrence and at most one increment/decrement of each floor, using O(1) base operations per term after O(log p) initialization. Inverses used here are of nonzero base-field quantities.

**Costs and comparator.** Derivatives cost O(p); each reduced univariate product costs O(p²) with classical multiplication, and the decision needs only a constant number. Storage is O(p). With a supplied faster multiplication routine costing M(p), the bound is O(M(p)+p) base operations. If an explicit witness is required, obtaining U^n,V^n by binary powering costs O(p² log p), followed by O(p) sparse emission. This compares against the source's equally informed O(p³) incremental scan. No coordinates, p-basis, coefficient-field operations, or relative-degree verification have been acquired from symbol queries. Base arithmetic is not a bit-complexity bound.

## 2. A finite decoder under a geometric promise

Supply exponent-one pairs K/H and L/C, source addition/membership, target L/C coordinates and arithmetic, and an oracle returning a representative of

    Θ([f]) = r[α(f)],

where r∈F_p* and α:K→L is an unknown field isomorphism carrying H onto C. This global promise is essential. If instead one supplies global, two-sided predicate preservation, obtaining the promise uses L06.

Choose x∉H. Query Θ([x]) and Θ([x+1]), giving representatives X,U. They lie in the same degree-p subfield C(X). In its X-coordinate the previous test returns n=r^−1. No second independent variable or global scan is required for this extraction.

If only full L/C p-basis coordinates are supplied, a univariate coordinate-conversion oracle is unnecessary: choose an Euler derivative D_j with D_jX≠0 and use Δ=(X/(D_jX))D_j. On C(X), Δ is the Euler derivation for X. The M/Q calculation then runs in L. It costs a constant number of L multiplications/inversions and O(N) coefficient work, N=[L:C], with that input size explicitly charged.

Power the two output representatives by n. They satisfy

    U^n = c+dX^n,       c,d∈C*.

Then **α(x)=(d/c)X^n**. This removes the arbitrary C* factors in the representatives.

For any f∉H, two more evaluations at f and f+1 give F,G. Solve

    G^n=c_f+d_fF^n;

then α(f)=(d_f/c_f)F^n. For f∈H, one evaluation at x+f gives G, and solving

    G^n=c_f+d_fα(x)

gives α(f)=c_f/d_f. This also handles f=0. All solves are two-dimensional over C, and their coefficients are unique. With full L/C coordinates, choose a nonconstant coefficient of the first vector to determine d, then c from the constant coordinate, and verify all residual coordinates.

Thus an explicit finite list of g generators of K over F_p is decoded using at most 2+2g map evaluations (reuse of anchor calls reduces this). These generator images determine α on all of K. Existence, well-definedness, and bijectivity are supplied through the promise; checking the returned generator images on presentation relations only verifies those relations. It does not establish the oracle's global promise.

Arithmetic: O(g log p) L multiplications for powers, O(gN) coefficient arithmetic for affine solves, plus the initial scalar extraction. If a supplied L multiplication costs A_L(N), this is O(g A_L(N) log p+gN), with source arithmetic/membership, query input construction, oracle evaluation, coefficient heights, and generator presentation costs additional. For infinite-generation fields, a finite list determines only the decoded subfield. This is a computational consequence, not a general field-isomorphism algorithm from finite invariant observations.

## 3. Valuation transvections: finite compatibility testing fails

Here the ambient field and all arithmetic can already be supplied. Let

    K=F_p(x,y), H=K^p, V=K*/K*^p.

Let N be pure-symbol vanishing in the degree-two Steinberg quotient. For k≥1, the polynomial a_k=y+x^k is irreducible, and the a_k are distinct. Its prime-divisor valuation gives a linear functional λ_k([f])=v_{a_k}(f) mod p. Define

    T_k([f])=[f]+λ_k([f])[x].

Because λ_k([x])=0, T_k is an F_p-linear bijection, with inverse subtracting the same term. It fixes the coordinate frame [x],[x+1],[y],[y+1]. Every finite collection of rational functions has finite divisor support, so some a_k is absent from every queried input; then T_k agrees with the identity oracle on the whole finite transcript.

Nevertheless N([a_k],[a_k+1]) holds by the Steinberg relation for −a_k. The image pair is ([a_kx],[a_k+1]). The alternating logarithmic-Euler pairing, which kills all Steinberg tensors, gives

    β([a_kx],[a_k+1]) = β([x],[a_k+1]) = y/(a_k+1) ≠ 0.

Thus that image symbol is nonzero. This witness uses only the elementary descended derivative pairing; Bloch–Gabber–Kato injectivity and L06's global theorem are unnecessary.

**Deterministic consequence.** In an evaluation-oracle model, any tester that finitely accepts the identity has an indistinguishable, non-compatible linear bijection. The N oracle is the same known-field relation in both runs, so additional exact N queries do not fix this. A supplied bounded description or globally geometric promise would change the model.

**Randomized consequence.** Suppose the identity run makes finitely many queries almost surely. Let E_k be the event that a_k occurs in their divisor supports. On each run only finitely many E_k occur, so Pr(E_k)→0. Couple the identity and T_k runs until the first affected query. Their acceptance probabilities differ by at most Pr(E_k). Hence no tester has a uniform positive completeness/soundness gap over all these maps. This is an adversarial oracle statement, not an average-case assertion about natural reconstruction maps.

**Sharp charged degree statement.** Restrict the bad maps to k∈{1,…,D}. For each rational query f=P/Q in reduced form, charge deg P+deg Q. If a tester's total identity-path degree is less than

    1+2+…+D = D(D+1)/2,

one a_k cannot occur in its queried divisor supports, so exact certification still fails. Conversely, the single query at ∏_{k=1}^D(y+x^k) distinguishes identity from every T_k and has exactly that degree. This is an algebraic query-degree bound, not a CPU/bit lower bound: a factored representation can be short, and constructing/querying it must be charged in the chosen computational model.

## 4. Foliation bridge and why higher height is not ready

If L06 reconstructs (K,H), it automatically reconstructs Der_H(K), its K-module structure, bracket, and restricted operation D↦D^p, by conjugation through α. For a finite p-basis, the derivative kernel recovers H. Combined with the classical Jacobson correspondence, this gives **generic height-one foliation data** from the symbol invariant. A chosen normal model, saturated sheaf, singular locus, and canonical divisor are not recovered merely by naming this bridge.

Grabowski's power towers offer a higher-height target: a purely inseparable subfield W is approximated by W K^{p^i}, and differential operators recover the compatible tower. Attempting to apply L06 separately to adjacent floors does not currently solve this. Rank-one floors can have a degenerate binary invariant, and the separate multiplicative quotients kill their overlaps, so independent reconstructed maps need not come with the gluing data. Providing the compatible tower or operator algebra simply supplies the load-bearing representation. This route is parked pending a precise invariant that acquires that compatibility.

## Diagnostics, retained corrections, and next fatal tests

Executed script: `work/scouts/algebra_geometry_check.py`; exact output: `work/scouts/algebra_geometry_check.json`. Coefficient field is F_p(A,B) with indeterminate A,B; no specialization to a perfect finite coefficient field was used.

- p=2: exhaustive 1 admissible constant-coefficient pair; rank and sparse witness pass.
- p=3: exhaustive 400 admissible constant-coefficient pairs; 16 nonzero intersections; direct intersection ranks, fast exponent, all-power scan, and sparse witness agree.
- p=5,7: respectively 54 and 56 univariate checks, including nonconstant coefficient patterns and all inverse-power affine patterns; fast test agrees with the exhaustive power scan.
- Additional promised-decoder fixtures exercise every nonzero scalar at p=3,5, arbitrary C* output representative factors, nonbase elements, and base elements. Their scope is the identity underlying field map, not an arbitrary global map.

The final complete diagnostic run took 12.73 seconds and decoded 42 element/scalar fixtures. This runtime measures the finite script only.

Two initial diagnostic failures were implementation/fixture errors and were corrected: SymPy fraction equality can retain constant units in numerator/denominator, so field equality now tests zero difference; the initial hidden-scalar fixture incorrectly powered U while holding X fixed, and was replaced by the correct pattern U=(a+bX^n)^r with nr≡1 mod p. Neither failure was discarded as evidence against an incorrectly stated fixture. Finite diagnostics support implementation only; the claims above rest on the written derivations.

Next decisive checks, in order:

1. Adversarially verify the scalar decoder for genuinely nontrivial field isomorphisms and imperfect **relative** bases, with every p-basis conversion and coefficient operation charged. Check exact priority for the derivative certificate/sparse witness before claiming novelty. Expected value: a small constructive effective-algebra note with a precise oracle interface.
2. Formalize the valuation-transvection oracle obstruction, including the randomized coupling and degree accounting. It is short and independent of the extraordinary released claim. Expected value: a reusable acquisition gate; it rules out a specific unjustified implication, not effective reconstruction with a promised bounded model.
3. Only after those gates, seek a higher-height invariant that includes compatible ambient embeddings while retaining a smaller input than the field/operator presentation. The missing gluing/rank-one mechanism is the main technical question; no proof is claimed here.
