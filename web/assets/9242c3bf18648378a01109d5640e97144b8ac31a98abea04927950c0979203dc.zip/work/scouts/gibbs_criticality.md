# Gibbs criticality scout — 7 October 2026

**Recommendation:** develop and independently audit a non-Gaussian, whole-experiment theorem for a critical mean-field quantum ferromagnet with unknown quadratic anisotropy and field. The concrete proposed limit is a single quartic random vector in three dimensions. Its finite-memory reconstruction law is `Theta(D^(-2/3))`, including quantum memories. This would extend the supplied ordered, invariant-background sphere experiment in a mathematically meaningful direction. It is a scoped theorem candidate, not a local-lattice criticality result or a claim of historical novelty.

I reconstructed an exact Gibbs-channel relative-entropy bound that removes the exact commutation requirement from the repository's generator-defect method. I then derived the critical spin-sector law, operational channels, and a general non-Gaussian memory converse. No external released theorem is required for the proposed mean-field construction. The independent audit at `work/deep/critical_gibbs_audit.md` certifies the qualitative operational equivalence. The finite-memory proof and the explicit public finite-N remainder written here are separate internal derivations; agreement is not external validation or a priority certificate.

## 1. Sources inspected and what they actually supply

Repository inputs, read-only:

- `work/astra-research-knowledge/00_START_HERE.txt`, `01_CORE.txt`.
- `cards/N02-correlated-sphere.txt`, `N09-unknown-field-gibbs.txt`, `N10-critical-gibbs.txt`, `N01-qudit-gibbs.txt`.
- `web/pages/d-c46ace73dc509919.html`: complete supplied `package/work/unknown_field.md`.
- `web/pages/d-e37111b337db4335.html`: complete supplied internal audit.
- `web/pages/d-b07499d16d55e302.html`: supplied compact account of the extraordinary Heisenberg magnetization claim. I did not validate its spatial comparison theorem.

N02's ordered sphere and N10's `1/D` law require a known invariant background and concentration of `j/V` at a positive radius. They do not describe the thermal critical point, where the spin radius itself fluctuates on a submacroscopic scale. N09's worst-case `3/2` storage exponent uses an engineered nonlocal Hamiltonian; it does not establish that cost for local Heisenberg models. The report correctly identifies tilted sector confinement/Fisher control and physical preparation as separate missing inputs.

Primary refresh:

1. [Aschieri–Ruba–Solovej, SU(2)-equivariant quantum channels: semiclassical analysis (2024)](https://link.springer.com/article/10.1007/s00220-024-05178-1), especially Theorem 1 and Lemma 12, equations (3.11)–(3.12). This supplies exact coherent-channel eigenvalues and quantified semiclassical approximations. Coherent quantization and the eigenvalue formula are established prior art; they are not original here.
2. [Björnberg–Fröhlich–Ueltschi, Quantum Spins and Random Loops on the Complete Graph (2020)](https://link.springer.com/article/10.1007/s00220-019-03634-x), Sections 2.3 and 7. This establishes thermodynamic phase behavior/critical exponents for complete-graph quantum models using total-spin decomposition. Its pressure/characteristic-function results are not automatically bidirectional full-density statistical equivalence or finite-memory converse theorems.
3. [Kirkpatrick–Nawaz, Asymptotics of mean-field O(N) models (2016)](https://arxiv.org/html/1602.03257v2), Theorem 10 and Section 6. This is a **classical** spherical-spin model and explicitly corrects the Heisenberg critical distribution in the earlier [Kirkpatrick–Meckes paper](https://arxiv.org/html/1204.3062v2). Its squared-radius density has power `(d-2)/2`, consistent with a d-dimensional quartic-vector law. It supports the old criticality mechanism, not the full quantum recovery statement below.
4. [Lewin–Nam–Rougerie, Derivation of nonlinear Gibbs measures from many-body quantum mechanics](https://arxiv.org/abs/1410.0335): primary precedent for quantum-to-nonlinear-Gibbs limits through coherent states and relative entropy. Its many-body bosonic interface differs from the finite-memory, whole-state experiment here.
5. [Drago–Pettinari–van de Ven, Classical and Quantum KMS States on Spin Lattice Systems (2025)](https://link.springer.com/article/10.1007/s00220-025-05325-2): weak-star semiclassical KMS limits and high-temperature uniqueness. These do not certify uniform trace-distance recovery of a growing finite-system experiment.
6. A genuinely recent preparation lead: [Pilatowsky-Cameo–Styliaris–Bakshi–Malz, One-dimensional quantum Gibbs states in constant circuit depth, submitted 28 September 2026](https://arxiv.org/abs/2609.35973). Its abstract claims an exact bounded-block product mixture and efficient classical preprocessing at fixed temperature. I verified the primary abstract, not the proof. This should be audited separately; a known-state preparation result does not by itself solve compression of an unknown Hamiltonian family.
7. [Fannes–Kossakowski–Verbeure, Critical fluctuations for quantum mean-field models (1991)](https://link.springer.com/article/10.1007/BF01053756): the primary abstract already describes a Ginzburg–Landau approximation to local Gibbs states and explicit abnormal critical fluctuation distributions for spin-half models. This is a decisive ancestor, not a peripheral citation. The publisher full-text/PDF routes returned subscription previews; I have not inspected its norm of approximation, exact models, anisotropy assumptions, or parameter uniformity. Those overlap questions remain unresolved.
8. [Davies, Classical approximations to Gibbs states (1979)](https://www.cambridge.org/core/journals/mathematical-proceedings-of-the-cambridge-philosophical-society/article/abs/classical-approximations-to-gibbs-states/9DF95ABEDDE793101C19AE20797ACF08): the primary abstract explicitly gives coherent-state mixtures asymptotically exact in trace norm for a one-particle Gibbs state. Thus trace-norm classicalization is itself old. Only the abstract was accessible here; its one-particle semiclassical limit differs from this growing spin-half system.
9. [Garoni–Perez–Zhou, The Rate of Convergence of the Critical Mean-Field O(N) Magnetization Via Multivariate Nonnormal Stein's Method, 26 May 2026](https://link.springer.com/article/10.1007/s10955-026-03625-y), Theorem 1.2. The full primary text establishes `O(n^(-1/2))` Wasserstein convergence of the **classical**, zero-field isotropic critical magnetization to a quartic density. This strengthens old weak-limit results; it does not supply TV convergence, noncommuting Gibbs parameters, or a full quantum preparation channel.
10. [van de Ven, Gibbs states and the classical limit (2024)](https://arxiv.org/html/2211.01755v4), Propositions 4.10–4.11, and [Keller–van de Ven, Large deviations in mean-field quantum spin systems (2024 preprint)](https://arxiv.org/html/2410.08538v1): inspected statements concern weak convergence/free energy and macroscopic large deviations. [Werner, The classical limit of quantum theory (1995)](https://arxiv.org/abs/quant-ph/9504016) supplies positive comparison maps and norm approximation of observables, with Gibbs approximation among the historical motivations. These are substantial method precedents. None of the inspected statements establishes the specific unknown critical anisotropy experiment or its memory converse.

### 1.1 What can and cannot be claimed as new

| Component | Prior evidence | Current priority status |
|---|---|---|
| Quartic nonnormal fluctuations at a mean-field critical point | Classical Curie–Weiss/O(d), quantum mean-field Fannes–Kossakowski–Verbeure | Old mechanism; do not advertise as a new universality class. |
| Spin coherent measure/prepare and tensor-rank eigenvalues | Berezin/Lieb tradition; exact modern SU(2) channel analysis | Established machinery. |
| Trace-norm coherent Gibbs approximation | Davies 1979; nonlinear Gibbs limits in other many-body models | Old in isolation. |
| Uniform CPTP equivalence of the entire critical spin-half family with unknown noncommuting A,b | Constructed here; closest 1991 full text unavailable | Internally proved, direct historical overlap not cleared. |
| Sharp `D^(-2/3)` error against arbitrary quantum/hybrid archives of the quartic experiment | Explicit positive upper and posterior-volume converse below | Candidate contribution; a targeted statistical-compression priority search is still required. |

The safest contribution description is **an operational critical-experiment theorem and its sharp memory consequence**, with an explicit anisotropy family and public finite-size error certificate. A broad search returning no exact match is not evidence of novelty. Even if the 1991 approximation covers the zero-field limit in strong norm, the bounded noncommuting A,b uniformity and arbitrary-quantum memory theorem must be compared separately.

## 2. Original exact bridge: no symmetry/commutation requirement

Let `B` be a unital trace-preserving completely positive map on a finite matrix algebra, `K=K*`, and `tau=exp(K)/Z`. Operator concavity of log gives

```text
log B(exp K) >= B(K).
D(tau || B(tau))
  = Tr tau [K - log B(exp K)]
  <= Tr tau [K - B(K)].                         (1)
```

Consequently,

```text
T(tau, B(tau)) <= sqrt(Tr tau [K-B(K)] / 2)
               <= sqrt(||K-B(K)|| / 2).          (2)
```

Here `T=||.||_1/2`, entropy uses natural logarithms, and the expectation in (1) is necessarily nonnegative. This is an elementary deduction from operator Jensen and quantum Pinsker; no priority is claimed. Unlike the stronger linear minorant in N01, it does not need `[B(exp K),K]=0`. Exponentiation of a noncommuting operator inequality is never used.

For a spin-j coherent channel

```text
B_j(X) = (2j+1) int_S2 <u|X|u> |u><u| dmu(u),
```

the exact eigenvalues on tensor ranks 1 and 2 are

```text
lambda_1 = j/(j+1),
lambda_2 = j(2j-1)/[(j+1)(2j+3)].                (3)
```

Rank 0 is preserved. Write `A_0=A-(tr A)I/3` and

```text
Q_A(J) = sum_ab A_ab (J_a J_b + J_b J_a)/2.
```

Then `Q_A0` has rank 2 and

```text
||Q_A0|| <= ||A_0||op j(j+1),
(1-lambda_2)||Q_A0|| <= 3 ||A_0||op j.           (4)
```

For `j=0,1/2` the absent rank-2 component is zero. These identities are a useful reusable route for collective Gibbs families whose Hamiltonians are not rotationally invariant. Large scalar functions of `J^2` cause no defect.

## 3. A concrete critical quantum experiment

Take N spin-half sites and `J=sum_i sigma_i/2`. Public data are N, the spin decomposition, and fixed bounds `||A||op<=A_*`, `||b||<=B_*`. The unknown parameters are a real symmetric 3-by-3 matrix A and vector b. One full density matrix is supplied:

```text
rho_(N,A,b) = exp[ 2 J^2/N
                   + Q_A(J)/N^(3/2)
                   + b.J/N^(3/4) ] / Z_(N,A,b).  (5)
```

The scalar part of A includes an unknown temperature displacement in the critical window `beta_N=2+lambda/sqrt(N)`. Its traceless part is an unknown anisotropy tensor. The quadratic term and linear term need not commute. All-to-all interaction and permutation symmetry remain explicit assumptions. This is neither an arbitrary unknown local Hamiltonian nor a supplied arbitrary invariant reference.

**Operational statement, independently audited in qualitative form:** fixed parameter-independent channels, one in each direction, approximate (5) uniformly by a single observation

```text
X in R^3,
p_(A,b)(x) = Z_(A,b)^(-1)
             exp[-4|x|^4/3 + x^T A x + b.x].     (6)
```

The error tends to zero in full trace distance/TV. The reverse channel prepares the entire N-spin mixed density, including its multiplicity state, rather than only matching magnetization moments.

### 3.1 Critical sector calculation

For even N, the spin-j multiplicity is

```text
m_N(j) = (2j+1)/(N+1) binom(N+1, N/2-j).
```

At A=b=0 the sector mass is proportional to

```text
(2j+1) m_N(j) exp[2j(j+1)/N].                   (7)
```

Set `k=j+1/2`, `L=N+1`. The combinatorial factor equals

```text
4k^2/L * binom(L,L/2-k).
```

The entropy expansion gives

```text
log binom(L,L/2-k)
 = L log2 - .5 log(pi L/2)
   - 2k^2/L - (4/3)k^4/L^3
   + O(k^2/L^2 + k^6/L^5 + 1/L).              (8)
```

The Gibbs quadratic term cancels the leading `-2k^2/L`; the residual quadratic term is `2k^2/[N(N+1)]`. Therefore `k/N^(3/4)` has limiting density proportional to

```text
r^2 exp[-4r^4/3],  r>=0.                       (9)
```

For a rigorous qualitative TV limit, use compact-uniform Stirling, radial-cell jitter of width `N^(-3/4)`, and the elementary entropy inequality

```text
I(z) >= z^2/2 + z^4/12, |z|<=1,
```

to control tails. For `k<=L/4` the Stirling prefactor is uniformly bounded; beyond this range its extra polynomial cost is dominated by an exponential in N. Tilting by bounded A,b only multiplies the radial bound by `exp[C(r^2+r)]`, so all needed moments are uniformly integrable. The same derivation works on the odd-N half-integer lattice.

Finite sanity check, **not proof**: TV between the exact zero-field sector law and the normalized quartic grid law was `0.05125, 0.02388, 0.01147, 0.00563, 0.00279` for `N=64,256,1024,4096,16384`. The values of `sqrt(N)*TV` decreased from `0.410` to `0.357`. This supports the coefficient and Weyl shift, not a certified convergence rate. Exact check output is `work/scouts/gibbs_criticality_checks.json`; its script is adjacent.

### 3.2 Whole-state classicalization and parameter-independent channels

Schur decomposition gives a spin Gibbs factor tensor a maximally mixed multiplicity state. On each spin sector the scalar `2j(j+1)/N` is preserved by B_j. Equations (1)–(4) yield the uniform global bound

```text
D(rho || B rho)
 <= (3/2)||A_0||op N^(-1/2) + B_* N^(-3/4).
T(rho, B rho) = O(N^(-1/4)).                    (10)
```

The entropy expectation also gives `O(N^(-3/8))` trace error after using the uniform tilted moment `E j=O(N^(3/4))` derived from the quartic tails. The conservative global bound (10) is already enough to establish vanishing error.

The encoder measures j and its coherent direction u. Its unnormalized joint density is the known critical sector weight times `<u|exp(F_j)|u>`, where F_j contains only the A,b terms. Its lower symbol is

```text
g_j(u) = [j^2 u^T A u + (j/2)(tr A-u^T A u)]/N^(3/2)
         + (j/N^(3/4)) b.u.                    (11)
```

Put `a=tr A/3`. An exact upper symbol is

```text
h_j^+(u) = a j(j+1)/N^(3/2)
           +(j+1)(j+3/2) u^T A_0 u/N^(3/2)
           +(j+1)b.u/N^(3/4).
```

Its coherent quantization is F_j. The difference from (11) is at most

```text
3(j+1/2)||A_0||op/N^(3/2) + B_*/N^(3/4).
```

Scalar Jensen supplies `<u|exp(F_j)|u> >= exp(g_j(u))`. For the integrated upper bound, diagonalize F_j. For each normalized eigenvector psi, `(2j+1)|<psi|j,u>|^2 dmu(u)` is a probability measure, and its expectation of `h_j^+` is the eigenvalue. Scalar Jensen followed by summation gives

```text
Tr exp(F_j)/(2j+1) <= int exp(h_j^+) dmu
                   <= exp(delta_j) int exp(g_j) dmu.
```

This remains valid at `j=0,1/2`: the rank-two *function* in the upper symbol need not vanish, but its quantization does. Pointwise lower domination and the integrated mass bound give TV at most `1-exp(-max_j delta_j)` after normalization. Thus the actual encoded distribution is within `O(N^(-1/2))` TV of the discrete classical density proportional to

```text
q_N^0(j) exp[(j/N^(3/4))^2 u^T A u
                     + (j/N^(3/4)) b.u].       (12)
```

Radial jitter turns (12) into (6) in uniform TV. The reverse channel rounds the radius to a sector, prepares its coherent spin state at the supplied direction, attaches the public maximally mixed multiplicity, and undoes the decomposition. Comparing it with `B rho` plus (10) completes the proposed bidirectional limit.

No decoder step uses the unknown A,b or the actual tilted sector law. The mean-field formula supplies the public family; this is not acquisition of a Hamiltonian from data. The next section defines an explicit computable additive remainder; no unproved joint N,D power law is needed.

### 3.3 Exact cells and a public finite-N error certificate

Write `M=A_*`, `B=B_*`, `s=N^(3/4)`, `Delta=1/s`, `k_j=j+1/2`, and `r_j=k_j/s`. The allowed spins are `j_min,j_min+1,...,N/2`, with `j_min=0` for even N and `1/2` for odd N. Use the cells

```text
I_(j_min) = [0,(k_(j_min)+1/2)/s),
I_j = [(k_j-1/2)/s,(k_j+1/2)/s) for j>j_min.
R_N = (N+2)/(2s).
```

Their union is `[0,R_N)`; the first odd-N cell has width `3Delta/2`, and all other cells have width Delta. The forward channel draws r uniformly in its measured sector's cell and outputs x=ru. The reverse rounds to these same cells and clamps `r>=R_N` to `j=N/2`. Its preparation is `P_(j,u) tensor I_mult/m_N(j)` followed by the inverse Schur transform. At x=0 fix any direction. Thus reverse-after-forward is exactly B_N. Multiplicity reset does not break unitality: applied to identity, the measurement density is `(2j+1)m_N(j)`, and the prepared block integrates to `I_(V_j) tensor I_mult`.

Define entirely public probability densities on radial Lebesgue measure:

```text
a_N(j) = (2j+1)m_N(j) exp[2j(j+1)/N],
q_N^0(j) = a_N(j)/sum_l a_N(l),
w_N(r) = q_N^0(j)/|I_j| for r in I_j; 0 for r>=R_N,
w_0(r) = c_r r^2 exp[-4r^4/3], r>=0,
c_r = 4(4/3)^(3/4)/Gamma(3/4).
```

The multiplicity formula in Section 3.1 holds for both parities because `N/2-j` is always an integer. The following are finite, explicit one-dimensional integrals and a finite binomial sum, involving M,B,N only:

```text
V_N = int_0^infty exp[Mr^2+Br] |w_N(r)-w_0(r)| dr,
eta_N(r) = Delta [M(2r+Delta)+B],
U_N = int_0^infty w_N(r) exp[Mr^2+Br]
                         (exp[eta_N(r)]-1) dr,
z_N = sum_j q_N^0(j) exp[-M r_j^2-B r_j],
z_0 = int_0^infty w_0(r) exp[-Mr^2-Br] dr,
gamma_N = min{1,(V_N+U_N)/min(z_N,z_0)}.          (13a)
```

Every point in I_j obeys `|r-r_j|<=Delta`, including the exceptional odd-N first cell. For `f(r,u)=r^2 u^T A u+r b.u`, this gives `|f(r_j,u)-f(r,u)|<=eta_N(r)`. Consequently the L1 difference of the two *unnormalized* tilted densities `w_N(r)e^(f(r_j,u))` and `w_0(r)e^(f(r,u))` is at most `V_N+U_N`. Their normalizers are at least z_N,z_0; normalizing gives the TV bound gamma_N in (13a). The compact Stirling limit and quartic tilted-tail proof in the independent audit show `V_N,U_N -> 0`, `z_N -> z_0>0`, hence `gamma_N -> 0`. No rate of these integrals is asserted.

Because `||A_0||op<=4M/3`, conservative global symbol and generator constants are

```text
delta_N = 2M(N+1)/N^(3/2)+B Delta,
kappa_N = M(N+1/4)/N^(3/2)+(B/2)Delta,
sigma_N = (1-exp[-delta_N])+(1-exp[-2kappa_N]),
beta_N = sqrt[M N^(-1/2)+(B/2)Delta],
alpha_N = min{1,sigma_N+gamma_N}.                (13b)
```

Here delta_N bounds upper-minus-lower symbols, and kappa_N bounds the lower symbol minus `f(r_j,u)`; changing a log density by at most kappa_N costs at most `1-e^(-2kappa_N)` in normalized TV. The generator estimate gives beta_N directly by Pinsker. These quantities certify

```text
sup_Theta TV(T_N rho_(N,A,b),p_(A,b)) <= alpha_N,
sup_Theta T(S_N p_(A,b),rho_(N,A,b)) <= alpha_N+beta_N.  (13c)
```

All constants and finite-size remainders in (13a)–(13c) are now defined explicitly and independently of the unknown parameters and archive dimension. The radial certificate can be evaluated to any declared numerical quadrature precision; an ordinary floating-point evaluation alone is not a certified enclosure. The audit proves its vanishing qualitatively and does not certify additional Robbins-rate constants.

## 4. Original non-Gaussian memory law

For one observation from (6), define e_D as the infimum uniform TV reconstruction error through a memory of total dimension D. Arbitrary quantum/hybrid memories and independent shared classical seeds are allowed; every input-dependent retained register is charged. The matching lower bound below requires `B_*>0`; a single known state has zero reconstruction error and cannot obey a positive lower law.

### 4.1 Positive classical upper: O(D^(-2/3)), without a tail logarithm

Map `y_i=tanh(x_i)`. The transformed densities on `[-1,1]^3` extend by zero to smooth functions at the boundary: the quartic exponential beats every inverse power of the boundary distance. On a fixed compact A,b set, their C^2 norms are uniformly bounded.

Use tensor-product piecewise-linear nonnegative hats `phi_k` on a uniform grid of mesh h, with `sum_k phi_k=1`. On input y retain label k with probability `phi_k(y)`. Decode k by sampling the fixed density `phi_k/int phi_k`. The resulting operator is

```text
K_h p = sum_k [int p phi_k / int phi_k] phi_k.
```

Interior hats have zero first moment about their node; C^2-flatness at the boundary controls the boundary hats. Therefore `||K_h p-p||_1<=C h^2` uniformly, while `D=O(h^(-3))`. Every decoder is parameter independent. This proves `e_D<=C D^(-2/3)` with no truncation/tail factor.

An explicit constant is available. Let H bound the operator norm of the Hessians of the transformed densities. For mesh `h=2/m`, each normalized hat has coordinate second moment `h^2/6`; the difference between its average and the nodal density is at most `Hh^2/4`. Multilinear interpolation costs at most `3Hh^2/8`. Integrating over the cube of volume 8 gives TV at most `5Hh^2/2=10H/m^2`. Taking `m=floor(D^(1/3))-1` for `D>=64`, and using one fixed reconstruction for smaller D, gives

```text
e_D <= C_* D^(-2/3),  C_*=max{16,40H}.          (14a)
```

H itself can be made a public one-dimensional bound. Put

```text
Z_- = 4pi int_0^infty r^2 exp[-4r^4/3-Mr^2-Br] dr,
P(r) = (16/3)r^3+2Mr+B+2,
H = (3/Z_-) sup_(r>=0) exp[-4r^4/3+Mr^2+(B+2sqrt(3)+4)r]
                          [P(r)^2+16r^2+2M+2+2P(r)].
```

To verify this, differentiate the log of the transformed density in x coordinates: its first derivatives are bounded by P(r), its second derivative entries by `16r^2+2M+2`, and `d/dy_i=cosh(x_i)^2 d/dx_i`. The displayed exponential dominates the Jacobian and derivative factors. Quartic decay makes H finite and makes the transformed density and its first two derivatives vanish on every boundary face. No unknown parameter enters this constant.

### 4.2 Quantum lower: Omega(D^(-2/3))

Restrict to A=0 and b in the nondegenerate cube `[-a,a]^3`, where `a=B_*/sqrt(3)>0`, contained in the declared field ball. Choose a prior with density proportional to `Z_(0,b)` on that cube. Its posterior mean given X=x factorizes:

```text
m_i(x) = a coth(a x_i) - 1/x_i,
m_i(0)=0.                                     (13)
```

Each coordinate is strictly increasing from -a to a, and `m_i'(x_i)` is comparable to `1/(1+x_i^2)`. The predictive density of X is proportional to

```text
exp[-4|x|^4/3] product_i [sinh(a x_i)/(a x_i)].
```

Consequently Y=m(X) has a globally bounded Lebesgue density L: the inverse-Jacobian grows only polynomially while the predictive tail decays quartically.

Any reconstruction kernel with uniform TV error e obeys

```text
E ||m(X)-m(X')||^2 <= 18 a^2 e.                (14)
```

To see this, compare the original and reconstructed joint laws of b,X using the bounded test `b.m(X)`, compare the two predictive laws using `||m(X)||^2`, and use `E[b|X]=m(X)`. Expanding squared distance gives (14).

If the memory encoding of x is omega_x and the decoder POVM is M(dx'), then `omega_x<=I` and `int Tr M=D` imply

```text
Pr(||m(X)-m(X')||<=r) <= D L (4pi/3) r^3.     (15)
```

Taking the RHS to be 1/2 forces squared distortion at least `c D^(-2/3)`. With (14), `e>=c' D^(-2/3)`. Conditioning on an independent common seed leaves (15) valid. There is no classical-memory restriction. This is unassisted storage: a free pre-shared entangled decoder system is outside the interface, and any input-dependent persistent register must be charged.

The constants can be specified without an unspecified density supremum. Define

```text
c_a = min{a^2 exp(-2)/3, 1-sinh(1)^(-2)},
Q_0 = pi (3/4)^(3/4) Gamma(3/4),
L_* = [Q_0 c_a^3]^(-1)
      sup_(r>=0) (1+r^2)^3 exp[-4r^4/3+sqrt(3)a r].
```

For `|at|<=1`, the posterior on `[-a,a]` has density at least `exp(-2)/(2a)`, so its variance `m_i'(t)` is at least `a^2 exp(-2)/3`. For `|at|>=1`, monotonicity of `s/sinh(s)` gives `m_i'(t)>= [1-sinh(1)^(-2)]/t^2`. Thus `m_i'(t)>=c_a/(1+t^2)` everywhere. The predictive normalizer is at least Q_0, and `sinh(at)/(at)<=exp(a|t|)`. Dividing by the Jacobian of m yields an induced density bounded by L_*. With `v_3=4pi/3`, set `r=(2DL_*v_3)^(-1/3)` in (15); the squared distortion is at least `r^2/2`. Hence

```text
e_D >= c_* D^(-2/3),
c_* = (1/(36a^2)) [2L_* v_3]^(-2/3)>0.         (15a)
```

For completeness, (14) uses two bounded tests only. Uniform reconstruction TV at most e gives joint prior/output TV at most e and predictive TV at most e. Comparing `b.m(X')` with `b.m(X)` costs at most `6a^2e`; comparing `|m(X')|^2` with `|m(X)|^2` costs at most `6a^2e`. Conditional independence of b and the archive output given X gives `E[b.m(X')]=E[m(X).m(X')]`. Expanding squared distance gives the stated factor 18. The volume argument integrates the predictive density over the preimage under m of a ball and uses `omega_x<=I`, then `int Tr M=D`; it does not assume classical labels.

This posterior-map proof is reusable for non-Gaussian full-dimensional exponential families whenever the pushed-forward predictive density is bounded. It is not tied to a Gaussian integration-by-parts identity.

### 4.3 Finite-system transfer and honest scope

Compose a quantum archive with the two operational channels above. The limiting lower and upper transfer to

```text
c D^(-2/3) - a'_N <= e*_(N,D)
                   <= C D^(-2/3) + a_N,
a_N,a'_N -> 0 independently of D.             (16)
```

Do not drop the remainders in a joint precision/size limit. Parameter dimension is nine, but observed critical macrostate dimension is three, so there is no nine-dimensional precision penalty. Contrast with the ordered, positive-radius N10 experiment: its observation lives on a two-dimensional sphere and has `1/D` precision. Critical radial fluctuations genuinely change the observation space.

Using the explicit constants and channels in Sections 3.3–4.2 makes (16) concrete:

```text
max{0,c_* D^(-2/3)-R_N^archive} <= e*_(N,D)
        <= min{1,C_* D^(-2/3)+R_N^archive},
R_N^archive = 2alpha_N+beta_N -> 0.             (16a)
```

The upper archive is `T_N -> positive-hat archive -> S_N`; the lower composes `S_N -> any N-spin archive -> T_N`. Trace/TV contractivity charges exactly one forward and one reverse experiment error in either direction. `(16a)` applies at every fixed finite N,D with the declared public bound, and explains precisely when the limiting precision exponent is informative. It does not assert that `R_N^archive=O(N^(-1/2))`, or a sharp simultaneous rate.

## 5. Ranked next targets, strongest controls, and fatal tests

1. **Anisotropic quartic critical experiment plus (16a): highest expected value here.** It has explicit combinatorics, fixed positive channels, a noncommuting unknown parameter family, and a memory converse stronger than classical quantization alone. An equally informed classical control is the explicit quartic observation and positive-hat archive, not estimation of A,b. The Jensen bridge, upper symbol, and uniform radial TV have now passed the independent audit. The decisive remaining proof audit is the arbitrary-quantum posterior converse and positive-hat constants; the decisive priority task is direct comparison with the 1991 full text and statistical-experiment compression literature. Historical novelty could still reduce the operational part to a clean application of known approximation machinery.
2. **General critical/coexistence support-dimension law: promising companion.** For an invariant model with `j/a_N` converging to a nondegenerate continuous radius law and field `b/a_N`, the exact coherent construction should yield the tilted radius-direction experiment. Smooth continuous radial support gives a three-dimensional observation and usually `D^(-2/3)`; finitely many positive radii give a finite disjoint union of spheres and `1/D` with an additional finite phase label. Unknown phase weights do not themselves create a continuous radial precision dimension. Atomic/singular/fractal radius laws and support near zero need separate analysis; do not assert a universal exponent from weak convergence alone.
3. **Local 3D Heisenberg unknown-field compression: high impact, currently low tractability.** The missing ingredient remains valid tilted-sector Fisher/confinement control, and near the thermal critical point even a rigorously identified finite-size magnetization law. The supplied spontaneous-magnetization claim is not a substitute. The complete-graph quartic derivation cannot acquire local universality or a local preparation algorithm.

Fatal scope tests:

- If A or b bounds grow with N, the symbol and moment constants must be charged again; the present compact-parameter theorem does not cover that window.
- Unknown microscopic background parameters can carry extensive information. A vanishing uniform field alone does not justify low memory for an arbitrary unknown Hamiltonian.
- The squared-commutator/semiclassical argument must reconstruct the full density, not only low moments or a weak-star state.
- A single quantum input does not reveal its unknown parameters. The encoder implements an observation kernel; it does not fit A,b and then regenerate a state from an estimate.
- This is density reconstruction without an external purifying reference. Coherent measure/prepare cannot preserve arbitrary input entanglement.
- Schur measurement, coherent POVM discretization, sampling, and full-state preparation have not received a gate/bit-cost compiler here. Memory dimension is not end-to-end efficient simulation cost. The classical limiting upper uses O(D) public hat data; evaluation and sampling costs still need a concrete implementation. The N-spin output itself requires at least N physical cells/time to emit.

**Status ledger:** primary coherent eigenvalues, nonnormal criticality, and trace-norm coherent Gibbs approximation are established literature. Equations (1)–(13c) are the reconstructed construction, with qualitative whole-state equivalence independently audited; (13a)–(13b) supply explicit public finite-N error certificates without an asserted convergence rate. Equations (14a)–(16a) are internal finite-memory derivations with constants and no numerical evidence as a proof input; the audit did not inspect them. The numeric sector check is finite evidence only. Local critical universality, a sharp joint N,D rate, efficient preparation, and historical priority remain unresolved, with the unavailable 1991 full text the most consequential priority gap.

Memory was used only to preserve the prior Gaussian-audit caution and the user's boundary against treating finite checks as proof (`MEMORY.md:82-97`, prior rollout `01a1121a-4750-72f0-8f5c-b501038890d3`). No memory-derived mathematical assertion was treated as current verification.
