# Tensor complexity scout — 7 October 2026

**Verdict.** No algorithm for arbitrary requested masks at `D=N^(1/4)`, `|W|<=N^(15/8)` was obtained. The strongest new deductions are a precise extension of the kernel-library obstruction to invertible mixed encodings, a correction to the multi-kernel quantifier in N12, and a band-packing obstruction to a particular recursive bootstrap. The highest-upside remaining mechanism is **overcomplete mixed input encodings with a sparse output decoder**, or a mask-dependent rewrite that never materializes the complete input transforms. These are concrete targets, not established algorithms.

## Interface and evidence read

Dense integer `X:N x D`, `Y:D x N`; arbitrary supplied output list `W`; no sparsity promise on `XY`. Polynomially bounded entries are necessary for an `N`-only bit bound. Reading `X,Y`, reading `W`, acquiring a circuit, all transforms, arithmetic, coefficient representations, and output decoding are charged. The desired saving must exceed merely avoiding unused writes: individual dot products cost `N^(17/8)`, while the full thin product costs `N^(2+o(1))` arithmetic operations and writes `N^2` entries.

Exact repository evidence read:

- `work/astra-research-knowledge/cards/L03-all-field-nine-fourths.txt`
- `work/astra-research-knowledge/cards/L04-block-cover-obstruction.txt`
- `work/astra-research-knowledge/cards/N12-selective-tensor-barrier.txt`
- `work/astra-research-knowledge/web/pages/d-2dd80b9b6fe74acf.html` — `FIELD_DESCENT.md`.
- `work/astra-research-knowledge/web/pages/d-c8c44a330cd66a5b.html` — root descent proof.
- `work/astra-research-knowledge/web/pages/d-d2ebdc4e16ec4b31.html` — complete selective-output audit.
- `work/astra-research-knowledge/web/pages/d-1e7a99ec32d38c30.html` — complete L selective note.

These were treated as internal mathematical records. No source script, Lean build, or rank-kernel acquisition was replayed. Primary release TeX was independently fetched to `work/tensor_sources/nine_fourths.tex`; the decisive separator, determinant filtration, tripling, growth, detecting-character appendix, and recursive-algorithm scope were inspected. This is scoped manual scrutiny, not certification of the extraordinary source theorem.

## Primary-literature refresh

1. [Alman–Vassilevska Williams, arXiv:2610.06783v1](https://arxiv.org/html/2610.06783v1), 5 October 2026. Live source confirms the requested-output integer theorem and its general `D<=N^epsilon`, `epsilon<ln(4)/(5 ln(10))` regime. Sections 2.2–2.4 and 4.4 were read for the ten-term identity, output incidence, shared encodings, and tile/encoding exponents. Their method supplies real output-local arithmetic, but its present aspect ratio does not reach `1/4`. Claimed 3SUM/APSP consequences are source results, not independently re-proved here. Do not say those hypotheses remain universally unrefuted without addressing this new preprint.

2. [Graia, arXiv:2608.18496v1](https://arxiv.org/html/2608.18496v1), 19 August 2026. Read model, main theorem, and nested recovery. Its optimum is stated in terms of **sparse rectangular multiplication exponents**, including the unresolved sparse-by-skinny endpoint relevant here. It is not a black-box acquisition of the desired circuit. The ambient dimension and dense output endpoint prevent the alleged free rescaling by square root of input nonzeros.

3. [Bennett–Gajulapalli–Golovnev–Warton, arXiv:2508.10250](https://arxiv.org/abs/2508.10250), plus [Abboud–Bringmann–Fischer–Künnemann, arXiv:2309.06317](https://arxiv.org/abs/2309.06317). Their support-recovery interfaces concern a sparse **actual product**, not sparse requests in an otherwise dense product. Transposition is useful only after a suitable source computation is supplied/acquired.

4. [Vrana, *Partial and weighted matrix multiplication*, arXiv:2408.15728v1](https://arxiv.org/html/2408.15728v1). Its tensor-power/support-rank reductions are important prior, but do not provide a cheaply decoded one-shot algorithm for arbitrary masks. This prevents relabeling a spectral or support-rank statement as a requested-coordinate algorithm.

5. [Li–Qiao–Wigderson–Wigderson–Zhang, *Connections between graphs and matrix spaces*, arXiv:2206.04815](https://arxiv.org/pdf/2206.04815), particularly Proposition 6.2 and Section 6.1. The determinant-to-permutation argument below has direct prior in graphical matrix-space embeddings. Its application to the N12 library model is useful; it should not be claimed as a new general matrix-space theorem.

6. The [pinned OpenAI 9/4 manuscript](https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Matrix-Multiplication-Nine-Fourths-October-2-2026/build/paper.tex) exists. It states complex arithmetic and chooses an existential fixed exact rank kernel after proving an exponent. It does not specify competitive finite size, selected-output access, or bit complexity. L03's all-fixed-field transfer is an internal corollary with additional finite-field gates; it is not the manuscript's theorem statement.

## Audit of L03, L04, N12

**L03.** The local descent argument preserves formal integer valuations in characteristic two and correctly descends a *whole powered expression once*. Repeating an extension penalty at each tensor factor would lose the result. The inspected polynomial filtration uses monomial pivots of coefficient one; no characteristic-zero representation-theory decomposition is necessary for that step. The remaining claim is conditional on the complete released proof and the detecting-character framework. No finite selective kernel or practical integer circuit follows.

There is a simple improvement to the descent overhead. The repository uses `k^3` copies for an extension of degree `k`; `k^2` suffice. If the leg maps are `U_X=sum_a e_a X_a`, `U_Y=sum_b e_b Y_b`, and `U_Z`, with coefficients of the source tensor in `F`, choose `ell:E->F`, `ell(1)=1`. Then

`ell(A(U_X,U_Y,U_Z)) = sum_(a,b) A(X_a,Y_b, ell(e_a e_b U_Z))`.

The last expression is an `F`-linear third-leg substitution. This identity works coefficientwise for Laurent degenerations. It preserves all zero lower coefficients and the `F`-defined leading tensor. It reduces the finite separator copy bound from `O(M log^3 M)` to `O(M log^2 M)` over a fixed finite field; asymptotic exponents are unchanged. This is elementary scalar simulation, with no priority claim.

**L04.** The displayed Bernoulli rectangle bound and the cover-cost derivation reconstruct correctly within independently charged complete blocks. The proof counts each requested `(i,j,k)` as covered and charges a block at least `max{|R||C|, |R||K|, |K||C|}`. It does not constrain cross-block cancellations, shared mixed transforms, or a general arithmetic circuit. Its `Omega(N^2)` conclusion should remain qualified by that model.

**N12.** The spectral optimization is a bound on `asymptotic rank(T_(W,D))` for each **fixed** finite tensor, whose limit is tensor-power depth. It is not a rank estimate uniform in a varying arbitrary mask. The Cartesian-power family consequence still requires an acquired finite exact witness. The complete-array certificate gives `c>15/2`, `E(c)>6`, whereas the target requires `E<4`; this only rejects that certificate. The output incidence functional is a sound early gate for unchanged-kernel leaf pruning, not a bound on all mask-dependent rewrites.

There is a model ambiguity in N12's kernel-library theorem: its displayed count

`K_N (N+1)^(O(C/D)) binom(C,m)`

counts **one selected source kernel**. If the strategy may select and evaluate several different kernels, the proof needs a total cost bound and a kernel-selection entropy term. With total charge `C`, each nonempty coordinate-copy kernel costs at least order `D`, so at most `O(C/D)` can be used. A safe corrected count adds

`O((C/D) log K_N + (C/D) log C)`

to its logarithm. Thus polynomial-size libraries are still ruled out at `C=N^(2-eta)`, but the original broad assumption `log K_N=o(m log N)` alone does not justify the multi-kernel version. This is a quantifier/proof-model correction, not a refutation of the intended one-kernel obstruction.

## Original attempt 1: mixing inputs does not automatically escape the graph library

Let `S_W=span{E_ij:(i,j) in W}` and similarly `S_H`, over any field. Consider a source graph kernel with `N` row vertices and `N` column vertices. It computes its whole `H`-masked thin product. Permit **arbitrary mask-dependent invertible** row and column maps, applied identically at every middle coordinate, and arbitrary output linear combinations. These are substantially more general than coordinate permutations.

The condition for the target bilinear outputs is

`S_W subseteq A^T S_H B`, with `A,B in GL_N(F)`.

**Lemma.** There are permutations `f,g` with `(f(i),g(j)) in H` for every `(i,j) in W`.

**Proof.** Put `P=A^(-T)` and `Q=B^(-T)`. For every target edge, membership forces

`P E_ij Q^T = (P e_i)(Q e_j)^T in S_H`.

An outer product has exactly the Cartesian product of its two support sets as support. Therefore every pair of nonzero coordinates in these two vectors must be an edge of `H`. Nonzero determinant expansions of `P,Q` supply permutations `f,g` such that `P_(f(i),i)` and `Q_(g(j),j)` are nonzero for all indices. The desired edges follow. Conversely an embedding by two permutations is itself an allowed invertible specialization. This proves exact equivalence. No positivity, genericity, or real-field argument is used.

If `W` has no isolated vertices and the source has at most `N` vertices on each side, input flattening ranks force those maps to be square and invertible. Thus singular maps cannot evade the lemma in that equal-or-smaller source model.

Consequently a single fully evaluated source with `h<=C` edges can handle at most `(N!)^2 binom(h,m)` masks of size `m`, even though arbitrary mixing coefficients are allowed. A library handles at most `K_N (N!)^2 binom(C,m)`. Comparing with `binom(N^2,m)` gives the same contradiction at `m=N^(15/8)`, `C=O(N^(2-eta))`, and `log K_N=o(m log N)`, since the permutation entropy `O(N log N)` is negligible. A multi-kernel extension also holds for polynomial libraries **when every kernel has all `N` vertices nonisolated on each side** and uses invertible maps: each evaluation then costs at least order `ND`, so sequence and permutation entropy total `O((C/D) log N)=o(m log N)`. That extra assumption should not be omitted for the mixed-input multi-kernel version.

**What this resolves.** “Use arbitrary linear mixing” is not itself a mechanism if it means only invertible row/column changes before a fixed graph kernel. Such changes do not increase its combinatorial mask coverage at all. The actual escape must use extra source coordinates, mix the middle coordinate with outer coordinates, rewrite the kernel using dependencies, or generate a genuinely mask-specific circuit. This argument is related to established graphical matrix-space embedding facts above; the scoped compiler obstruction is a deduction, not a priority claim.

## Original attempt 2: a recursive band bootstrap has an aspect-ratio ceiling

A tempting plan is to split `D` into small inner chunks `d`, encode those with the ten-term primitive, and use the same requested-output method recursively for the residual inner length. Write `d=N^delta`. With `L=cm`, `d=4^m`, a band has side `d^(F(c)+o(1))`, where

`F(c) = ((c-1) ln 3 + (c ln c-(c-1)ln(c-1))/2)/ln 4`.

The residual outer side is `Q=N/d^F`, while its inner dimension is `D/d`. Even granting all transforms and leaf bookkeeping for free, a residual primitive with admissible aspect ratio `epsilon_0` requires

`epsilon-delta <= epsilon_0 (1-F delta)`.

Put `w=F delta`, with `0<=w<=1` because the band must fit. This says

`epsilon <= w/F + (1-w) epsilon_0 <= max{1/F,epsilon_0}`.

The primary conservative certificate uses `c>10`, hence `F(c)>F(10)=5 ln10/ln4=1/epsilon_*`, so self-bootstrapping cannot increase `epsilon_*`. Even allowing the repository's refined same-density tail certificate `c>15/2`, `F(c)>6.21333...`, giving a ceiling below `0.161`, still below `1/4`. The strict `F>4` needed for that rejection already follows from `3^13>4^8`, without numerical logarithm certification. Repeating stages gives a convex combination of the same admissible slopes and does not change this ceiling.

**Scope.** This rejects the stated band-packing bootstrap when every stage retains that certificate. It does not exclude compositions in which intermediate requested masks have stronger structure/density, a different primitive, a different tiling, or a fused computation that never exposes these bands. It is useful because it rejects an apparently promising route before a large acquisition experiment.

## Ranked targets and fatal tests

1. **Overcomplete mixed embedding into an explicitly acquired Cartesian graph kernel.** Highest upside, uncertain feasibility. Seek a graph `H` with `U,V>N`, an already acquired selective circuit, and maps/decoder satisfying `S_W subseteq A^T S_H B`. Allowing extra coordinates defeats the inversion proof above; a cheap dependency rewrite can defeat the source's full-evaluation model. The necessary output is a uniform algorithm acquiring/applying both encoders and the decoder in less than `N^2` time, not an existential tensor restriction. Start with exact small graph restriction systems; charge every coefficient and test unseen masks. Fatal tests: source output size exceeds budget, encoders require dense `N x U` descriptions, decoder is dense, or all discovered restrictions reduce to coordinate aliases. Existing spectral witnesses are unavailable, so first acquire one fixed seed rather than optimizing an exponent on paper.

2. **Projected Kronecker-transform compiler with structural zero and alias merging.** High upside and the most executable next experiment. The existing work tests output-leaf incidence; add the actual left/right transform dependency closures. For each requested leaf, traverse the primitive encoder DAG backwards, retaining only nodes with a structurally nonzero formal input, and merge equal formal linear forms caused by reused inputs. Count the union of these nodes across row/column bands, together with products and decoding. This directly attacks the full `10^L` arrays. A demonstration at one finite size is only a fixture: the deliverable must be a uniform closure bound for all legal masks and an exact circuit family. Fatal test: random legal masks saturate the encoder closure, or the tile still exceeds the target ambient side. Neither L04 nor the invertible-mixing lemma constrains a genuinely rewritten DAG.

3. **Explicit sparse-decoder bilinear identity acquisition.** Medium upside, tractable rejection. For a kernel `q x d` by `d x q` with `d=q^(1/4)`, acquire exact final output maps, then evaluate N12's

`Psi(1/8)=min_(0<=a<=1) [log_q(sum_l s_l^a)-a/8]`.

Require `Psi<2` and a compatible input-transform closure before recursion. Searching solely for low rank, or inspecting the Fourier map before coefficient extraction, is insufficient. Fatal tests: `r>=q^(17/8)`, geometric-mean output support at least `q^(1/8)`, or cheap leaf pruning but expensive transforms. Current output-local identities and partially weighted tensor prior must be included as equally informed baselines.

**Strongest next technical question:** can an overcomplete graph tensor with a known cheap Cartesian-power circuit encode arbitrary masks through mixed maps whose descriptions, applications, and output decoding each cost `O(|W| polylog N + ND polylog N)`? The inversion lemma isolates why square changes of basis cannot do this. A positive construction would genuinely cross the present barrier; a negative result must preserve the overcomplete/decoder/circuit-rewrite distinctions.

Expected value: prefer the projected-transform fixture and small overcomplete restrictions over another complete-array parameter scan. The 9/4 release changes arithmetic bounds but does not acquire any of these missing interfaces. No new 3SUM/APSP exponent or arbitrary-mask theorem is claimed in this scout.
