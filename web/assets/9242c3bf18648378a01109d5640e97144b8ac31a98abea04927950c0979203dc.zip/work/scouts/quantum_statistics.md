# Quantum statistical experiments: rank-boundary Poisson–coherent experiment

7 October 2026. Scout: `quantum_statistics`. Source repository was read only.

## Executive assessment

The best new target in this branch is **compression of a bounded Poisson observation together with an unknown coherent state**. I obtain a written matching order law

\[
 D_{\rm opt}(\varepsilon)
 =\Theta_{\Lambda,R}\left[
 \left(\frac{\log(1/\varepsilon)}{\log\log(1/\varepsilon)}\right)^2\right],
 \tag{A}
\]

when **all classical and quantum retained dimensions are counted**. The maximal quantum branch dimension has only the first power, even if classical storage is free. The nonroutine step is showing that reconstruction for two unknown Poisson intensities forces preservation of low count labels; one may then apply the established visible pure-source spectral converse to a count × coherent ensemble. This is an internally derived theorem candidate with a complete argument below; priority and independent correctness review remain open.

There is a direct finite-copy quantum interface for (A). An unknown qubit with eigenvalue `lambda/n`, and unknown direction within `1/sqrt(n)` of a supplied pure reference, is uniformly equivalent in trace norm to

\[
 \operatorname{Pois}(\lambda)\otimes |z\rangle\langle z|,
 \qquad 0\le\lambda\le\Lambda,\quad |z|\le R,
 \tag{B}
\]

with bidirectional error `C_(Lambda,R)/n`. I give fixed channels and an elementary proof, including exact reverse composition. Existing work already recognizes near-pure Poisson behavior and spin Gaussian limits; the proposed increment is the explicit whole-experiment comparison and its uniform rate. This should not be advertised as discovering the two limit components.

The pure-state critical law is **not a major new theorem**: the photon cutoff and Hayashi visible-source converse already imply the polylogarithmic dimension order. Its exact finite-n saturation is useful to retain, but parent novelty review appropriately downgraded it. An independent expansion worker has derived an exact factorial excitation tail for the rare-mixed family, proving its required quantum dimension even below the comparison remainder. My audit of that factorial identity passed; see coordination notes below.

## 1. Existing frontier and primary-source refresh

Read exact local sources:

- `work/astra-research-knowledge/00_START_HERE.txt` and `01_CORE.txt`.
- `cards/N07-gaussian-memory.txt`, `cards/N08-block-critical-gaussian.txt`, `cards/P-q-d-gauss.txt`, `cards/P-q-d-mem.txt`.
- `web/pages/d-900a3c8187ffc0aa.html`: supplied `updates/L/package/work/quantum_collision.md`, especially the known block-algebra theorem and its explicitly missing unrestricted factorization.
- `web/pages/d-7bf3825bbd159ebb.html`: `critical_gaussian_audit.md`.
- `web/pages/d-c4a9e95fccd25a09.html`: inherited `gaussian_rate_refinement.md`.
- `web/pages/d-4fac7348c6e10e91.html`: `gaussian_memory_prior.md`.

N08 covers a public block algebra around a full-rank reference. It does not supply the unrestricted classical degenerate-block × interblock Fock factorization. Its iid precision statements inherit the unverified tracial comparison and require precision above its remainder. My rank-boundary construction below uses exact qubit Schur identities instead.

Primary literature and proof interfaces:

1. [Kahn–Guţă, finite-dimensional QLAN](https://arxiv.org/html/0804.3876): full-rank generic spectrum; independent classical normal coordinates and thermal oscillator modes. It does not directly justify a reference with an eigenvalue `lambda/n` or arbitrary moving collisions.
2. [Lahiry–Nussbaum, low-rank QLAN, Theorem 3.3](https://arxiv.org/html/2111.03279v2): fixed rank gives classical normal, thermal, and pure shifted components. The positive reference eigenvalues remain separated; the new rare eigenvalue changes rank and scale.
3. [Yang et al., population coding](https://arxiv.org/html/1701.03372v8), particularly Sections IV–V: blind compression through QLAN, photon cutoff, and necessity of quantum memory. Its leading many-copy cost does not give the present prescribed critical-precision order.
4. [Yang, shallow-circuit compression](https://arxiv.org/html/2404.11177v3), Appendix D.1, Lemma 8 and equations (72)–(75): bounded coherent-state compression by Fock cutoff with a Poisson factorial tail. Thus the pure upper is established machinery; growing dimension is already an active prior-art direction.
5. [Leditzky–Datta, Lemma 5.2, attributed to Hayashi](https://arxiv.org/html/1407.6616v5): any visible encoding into dimension D has average pure-state fidelity at most the top-D eigenmass of the ensemble average. The lemma permits arbitrary decoding CPTP maps. It is stronger than the bespoke Gram/Stinespring lower initially attempted here.
6. [Acharya–Guţă, near-pure qubit estimation](https://arxiv.org/html/1708.04941), Sections 3 and 5: which-block labels approximate binomial observations, block states admit spin-to-oscillator LAN, and the `n lambda -> mu` range has Poisson estimation behavior. This is close prior art for (B), although the inspected text gives estimation results and a coarser LAN rate, not the exact `C/n` whole-experiment statement below.
7. [Tsang, Poisson Quantum Information](https://arxiv.org/html/2103.08532v5): rare orthogonal vacuum/object sectors have a Poisson limit. A coherently rotated vacuum is outside that elementary orthogonal-sector model; the known-frame Schur construction separates it here.
8. [Yamaguchi–Tajima, 19 September 2026 revision](https://arxiv.org/abs/2609.11926): reported strong QLAN for unitary models with arbitrary rank and degeneracy. The reference spectrum is fixed, and the unitary model cannot itself acquire the unknown rare eigenvalue. The full manuscript was opened but its 116-page proof was not audited in this scout.
9. [Hayden–Maloney–Wang–Yang, 5 October 2026](https://arxiv.org/html/2610.06742v1), Theorem 1 and Proposition 4: fixed rank, distinct positive spectrum, global orbit compression. The theorem explicitly excludes uniform moving eigenvalues. The inspected irreducible-orbit converse does not directly cover a local reducible phase torus. Its reported Lean certificate was not replayed.
10. [Fujiwara, May 2026 qLAN foundations](https://link.springer.com/article/10.1007/s41884-026-00207-5): likelihood-ratio geometry and asymptotic representation. Weak qLAN/measurement limit statements must not be promoted to bidirectional trace-norm channels without their extra hypotheses.

Bounded primary searches did not locate the exact product-memory law (A). That is not novelty clearance.

## 2. Exact qubit rank-boundary experiment and uniform comparison

Fix finite `Lambda,R`; assume `n >= max(4 Lambda,4)`. Define

\[
 \psi_{n,z}=\frac{|0\rangle+(z/\sqrt n)|1\rangle}
 {\sqrt{1+|z|^2/n}},\qquad
 U_{n,z}=\frac1{\sqrt{1+|z|^2/n}}
 \begin{pmatrix}1&-\bar z/\sqrt n\\ z/\sqrt n&1\end{pmatrix},
\]

\[
 \rho_{n,\lambda,z}
 =U_{n,z}\operatorname{diag}(1-\lambda/n,\lambda/n)U_{n,z}^*.
 \tag{2.1}
\]

The encoder receives `rho^(tensor n)`, not `lambda,z`. The supplied information is the fiducial basis, n, and the declared bounded envelope. Loss is half trace norm of the reconstructed averaged density, not purification loss or record-conditioned risk. No pre-shared entanglement or extra retained side register is free.

**Candidate theorem with written proof.** There are quantum channels `T_n,S_n`, depending only on n and the supplied basis, with

\[
 \sup_{\lambda,z}T\big(T_n(\rho_{n,\lambda,z}^{\otimes n}),
 \operatorname{Pois}(\lambda)\otimes|z\rangle\langle z|\big)
 \le C_{\Lambda,R}/n,
 \tag{2.2}
\]

and the same error in the reverse direction. Moreover `S_n T_n(rho^(tensor n)) = rho^(tensor n)` exactly throughout this family.

### 2.1 Schur decomposition and exact Poisson-label coupling

Write `q=lambda/n`, `p=1-q`, `r=q/p`. The Schur sector is labeled by deficit `k=n/2-j`, with `0<=k<=floor(n/2)` and symmetric spin length `t=n-2k`. Its multiplicity is

\[
 m_{n,k}=\binom nk-\binom n{k-1}.
\]

Conditional on k, the irrep density at z=0 is the truncated geometric state

\[
 \tau_t(r)=\frac{1-r}{1-r^{t+1}}
 \sum_{\ell=0}^{t}r^\ell|t,\ell\rangle\langle t,\ell|.
 \tag{2.3}
\]

The sector probability is

\[
 w_{n,\lambda}(k)
 =m_{n,k}p^{n-k}q^k\frac{1-r^{t+1}}{1-r}.
 \tag{2.4}
\]

At z=0, the *joint* law of k and the irrep excitation ell is

\[
 \Pr(k,\ell)=m_{n,k}p^{n-k-\ell}q^{k+\ell}.
\]

Thus `K=k+ell` is exactly `Bin(n,q)`: at fixed K the multiplicities telescope to `binom(n,K)`. Since the truncated geometric law satisfies `Pr(ell>0|k)<=r`, this coupling gives

\[
 \operatorname{TV}(w_{n,\lambda},\operatorname{Bin}(n,q))\le r,
 \quad \mathbb E k\le\lambda,
 \quad
 \operatorname{TV}(w_{n,\lambda},\operatorname{Pois}(\lambda))
 \le r+\lambda^2/n.
 \tag{2.5}
\]

For the final bound, couple n Bernoulli(q) variables to n Poisson(q) variables: their one-coordinate TV is `q(1-exp(-q))<=q^2`. Rotation leaves the sector distribution unchanged. Equation (2.5) covers lambda=0 exactly and introduces no inaccessible conditional resampling law.

The rotated irrep is `U_(n,z)^(tensor t) tau_t U*`. Its trace distance from the pure spin `psi_(n,z)^(tensor t)` is at most r, since (2.3) assigns its highest-weight vacuum probability at least `1-r`.

### 2.2 Spin-to-Fock error of order `(1+k)/n`

Let `V_t|t,ell>=|ell>` be the fixed Dicke-to-Fock isometry. For `a=|z|^2`, the amplitude ratio of `V_t psi_(n,z)^(tensor t)` to the coherent vector `|z>` is

\[
 f_{t,n}(\ell)=e^{a/2}(1+a/n)^{-t/2}
 \sqrt{(t)_\ell/n^\ell},\qquad 0\le\ell\le t,
 \tag{2.6}
\]

and zero beyond t. All coefficients have the same phase `z^ell`; the squared vector distance is exactly `E_(L~Pois(a)) (f(L)-1)^2`.

If `k<=n/4` and `ell<=n/4`, then `2k+ell<=3n/4` and

\[
 \log f=\frac a2-\frac{n-2k}{2}\log(1+a/n)
 +\frac12\sum_{h=0}^{\ell-1}\log\left(1-\frac{2k+h}{n}\right).
\]

Use `log(1+x) >= x-x^2/2` and `|log(1-u)|<=4u` for `0<=u<=3/4`. This yields

\[
 |\log f|\le\frac{C_R}{n}
 \big[(1+k)(1+\ell)+\ell^2\big].
 \tag{2.7}
\]

Always `0<=f<=exp(a/2)`, so the same bound controls `|f-1|` up to a fixed R-dependent factor. Poisson fourth moments are bounded uniformly for `a<=R^2`. On `L>n/4`, the bounded ratio and the fourth-moment tail give contribution `O_R(n^-4)` to the squared norm. Consequently

\[
 T\big(V_t\psi_{n,z}^{\otimes t}V_t^*,|z\rangle\langle z|\big)
 \le C_R(1+k)/n,\qquad k\le n/4.
 \tag{2.8}
\]

No pointwise comparison of merely the first two moments is used. The entire amplitude tail is controlled. The exceptional sector mass is at most `Pr(k>n/4)<=4 Lambda/n` by (2.5), so averaging (2.8) costs `C_(Lambda,R)/n`.

### 2.3 Channels and exact reverse composition

`T_n` applies the Schur transform, measures k, discards the known maximally mixed multiplicity, and embeds the irrep by `V_t`. Its output is the complete count-plus-Fock state. Combining (2.5), the geometric pure-state error r, and (2.8) proves (2.2).

`S_n` reads k. For valid k it maps a Fock density omega to

\[
 V_t^*P_t\omega P_tV_t+
 \operatorname{Tr}[(I-P_t)\omega]|t,0\rangle\langle t,0|,
 \qquad P_t=\sum_{\ell=0}^t|\ell\rangle\langle\ell|,
\]

regenerates the maximally mixed multiplicity, and applies inverse Schur. Invalid k gives a fixed density. On every encoder output this exactly recovers k and the full irrep state; hence `S_n T_n = identity` on the iid family. Contractivity proves the reverse comparison with the same forward error. The decoder never uses lambda,z, never resamples from their unknown distribution, and never estimates then prepares their product state.

This comparison is a continuous/infinite-dimensional experiment equivalence, not a finite archive or a completed gate-cost theorem. Known Schur-transform algorithms make implementation plausible but are not a compiled circuit in this report.

## 3. Sharp counted memory for the Poisson × coherent experiment

Let

\[
 \omega_{\lambda,z}=\sum_{k\ge0}p_\lambda(k)|k\rangle\langle k|
 \otimes|z\rangle\langle z|,
 \quad p_\lambda(k)=e^{-\lambda}\lambda^k/k!.
\]

The unknown intensity set contains two distinct positive values `lambda_1<lambda_2`; the z set contains a fixed disk of positive radius. Two intensity hypotheses and a fixed positive-radius phase circle already suffice for the lower. Encoder sees one complete state omega; parameters are unavailable. Hybrid algebra dimension is `D=sum_j d_j`; all input-dependent labels count. Independent shared classical seeds are permitted with dimension bound D at every seed; entanglement assistance is excluded.

Define `H(eps)=log(1/eps)/loglog(1/eps)` for sufficiently small eps. Then the proposed theorem is

\[
 D_{\rm opt}(\varepsilon)=\Theta(H(\varepsilon)^2).
 \tag{3.1}
\]

If instead arbitrarily large classical labels are free and only the maximum quantum branch dimension Q is charged, `Q_opt=Theta(H(eps))`. The free-classical qualification strengthens the Q converse, not the counted D theorem.

### 3.1 Upper bound

Keep count `k<=K`, mapping its tail to a fixed symbol; keep Fock excitations `ell<=L`, mapping their tail to vacuum. Poisson count-tail TV is at most `Lambda^(K+1)/(K+1)!`. Coherent trace error is at most `sqrt(2 R^(2(L+1))/(L+1)!)`. Taking `K,L=O_(Lambda,R)(H(eps))` gives total error eps and dimension `(K+2)(L+1)=O(H^2)`. Every retained label is counted. Q has only the L+1 quantum levels.

### 3.2 Unknown intensity forces low-count preservation

For a fixed z, postmeasure only the output count J of a reconstruction channel C. Conditional on the input count k, this is a stochastic kernel `K_z(J|k)` because the coherent input at that k is fixed. Give intensities lambda_1,lambda_2 equal prior and let I indicate the first intensity. Their input posterior is

\[
 m(k)=\Pr(I=1|k)=\frac1{1+A b^k},\quad
 A=e^{-(\lambda_2-\lambda_1)},\quad b=\lambda_2/\lambda_1>1.
\]

Uniform trace error eps gives joint TV at most eps between `(I,J)` and `(I,k)` under this prior. The quadratic Bayes identity gives **exactly**

\[
 \mathbb E(m(k)-m(J))^2
 =\mathbb E(I-m(J))^2-\mathbb E(I-m(k))^2
 \le\varepsilon.
 \tag{3.2}
\]

The identity uses `I -> k -> J`; it does not assume that the memory is classical. The loss is in [0,1], so TV bounds the risk change by eps.

For `0<=k<=K` and any integer `J!=k`, monotonicity gives

\[
 |m(k)-m(J)|\ge c b^{-K}.
\]

Indeed the adjacent gap is
`A b^k(b-1)/[(1+A b^k)(1+A b^(k+1))] >= c b^(-k)`.
The prior count mass satisfies

\[
 \bar p(k)\ge p_{\lambda_1}(k)/2
 \ge q_K:=\frac{e^{-\lambda_1}\min(1,\lambda_1)^K}{2K!}.
\]

Hence for each k<=K, uniformly in z,

\[
 \Pr(J\ne k|k,z)\le C\varepsilon b^{2K}/q_K
 \le C\varepsilon\exp(C K\log(K+1)).
 \tag{3.3}
\]

This is the supplied-versus-acquired boundary: a known intensity could be regenerated and would not cost this label factor. The lower requires two unknown intensity values.

### 3.3 Conditional coherent fidelity and the spectral converse

The target quantum marginal is pure `|z><z|`. Testing the output against that projector gives

\[
 \sum_k p_{\lambda_1}(k)
 \left[1-\langle z|\operatorname{Tr}_{\rm count}
 C(|k\rangle\langle k|\otimes|z\rangle\langle z|)|z\rangle\right]
 \le\varepsilon.
\]

Each summand is nonnegative. Together with (3.3), this implies, for each k<=K, fidelity at least `1-delta_K` to the **joint pure target** `|k> tensor |z>`, where

\[
 \delta_K\le C\varepsilon\exp(C K\log(K+1)).
 \tag{3.4}
\]

Now take z on a discrete L-point phase torus `z_j=a exp(2 pi i j/L)`, with fixed `0<a<=min(R,1/2)`, and k uniform on `0,...,K`. All these are pure inputs to the same code C. Their mean state has `(K+1)L` nonzero eigenvalues. For the coherent phase torus, discrete Fourier diagonalization gives eigenvalues

\[
 u_j=\sum_{\ell\equiv j\pmod L}e^{-a^2}a^{2\ell}/\ell!,
 \quad 0\le j<L.
\]

In particular

\[
 u_j\ge u_*:=e^{-a^2}a^{2(L-1)}/(L-1)!.
\]

The joint ensemble mean has every eigenvalue at least `u_* /(K+1)`. If `D <= (K+1)L/2`, its omitted eigenmass is at least `L u_* /2`. By the **established** Hayashi visible compression converse, the average infidelity is at least that mass. This contradicts (3.4) once

\[
 C\varepsilon\exp(C K\log(K+1))<L u_*/2.
 \tag{3.5}
\]

Choose `K=L=floor(c H(eps))`, with c sufficiently small depending only on the fixed intensity pair and radius. Taking logarithms verifies (3.5): both factorial penalties cost `O(c log(1/eps))`, while eps contributes `-log(1/eps)`. Thus `D >= c' H(eps)^2`, proving (3.1).

The source lemma is stated in finite dimension; its application here is finite dimensional because the finitely many coherent vectors span an L-dimensional space. Projecting decoder outputs to the joint target span and replacing the orthogonal remainder by a fixed state can only increase all target fidelities. A shared seed does not weaken the bound: apply the visible converse at each seed to the same ensemble and average.

### 3.4 Quantum branch cost and finite-copy transfer

For Q, discard the count after reconstruction and fix one known intensity in the input family. Its initial count state is an independent known ancilla. This yields a coherent-state reconstruction channel through branches of quantum dimension at most Q. The robust pure-state/Stinespring argument of `pure_quantum_lower`, or standard spectral source arguments in their appropriate blind interface, forces `Q=Omega(H(eps))` even if the measured count record and other classical labels are unlimited. The upper above matches.

For the finite-copy rare-mixed family, the comparison in Section 2 gives

\[
 e_{\rm Pois\times coh}\le e_{\rm iid}+2C_{\Lambda,R}/n,
 \qquad
 e_{\rm iid}\le e_{\rm Pois\times coh}+2C_{\Lambda,R}/n,
\]

using the same finite memory. Therefore (3.1) transfers for prescribed eps_n with `n eps_n -> infinity`. No total-D assertion below the bridge remainder follows from this transfer.

### 3.5 General hybrid Poisson–coherent law

The proof scales to a Cartesian product of a independent bounded Poisson intensities and b coherent modes, with each intensity allowed at least two fixed distinct positive hypotheses and each mode containing a fixed positive-radius phase circle. For fixed a,b and fixed envelopes,

\[
 D_{\rm opt}(\varepsilon)=\Theta(H(\varepsilon)^{a+b}),
 \qquad Q_{\rm opt}(\varepsilon)=\Theta(H(\varepsilon)^b)
 \quad\text{with free classical labels}.
 \tag{3.6}
\]

For the D lower, give intensity hypotheses a product prior. The vector of a binary posteriors satisfies `E||m(K)-m(J)||^2<=a eps`; each component follows (3.2). A low count vector in `[0,K]^a` has prior mass at least `exp(-C a K log(K+1))`, and any changed coordinate incurs squared posterior gap at least `exp(-C K)`. Thus each such vector must be preserved to error `delta<=C eps exp(C a K log(K+1))`. Testing the b-mode pure marginal then gives fidelity at least `1-delta` on the same code's joint pure count-vector/coherent inputs.

Use a product discrete L-point coherent phase torus. Its mean has `L^b` eigenvalues at least `u_*^b`; the joint uniform low-count mean has `(K+1)^a L^b` eigenvalues at least `u_*^b/(K+1)^a`. The visible spectral converse forces `D>=((K+1)^a L^b)/2` once `delta<(L u_*)^b/2`. Again `K=L=floor(c H(eps))` works. The upper independently truncates the a Poisson coordinates and b coherent modes. For b=0 this proves that arbitrary quantum memory cannot improve the order of the classical bounded Poisson archive. Known intensities can be discarded and independently regenerated, removing their a factor. This theorem is a compositional statement for the declared product experiment; it does not itself prove that an arbitrary rank-deficient quantum iid model has those product factors.

## 4. Pure boundary law and independently coordinated exact extension

For fixed `d`, put `q=d-1`, `psi_(n,z)=(|0>+z/sqrt(n))/sqrt(1+||z||^2/n)` with `||z||<=R`. The total excitation cutoff L has dimension `binom(L+q,q)` and tail

\[
 \Pr(N\ge L+1)\le R^{2(L+1)}/(L+1)!.
\]

Together with established pure-source converse machinery this yields the uniform finite-n order

\[
 D_{\rm pure,opt}(n,\varepsilon)
 =\Theta_{d,R}\big[(1+\min\{n,H(\varepsilon)\})^{d-1}\big].
\]

The same Q order persists with free classical storage, as independently derived by `pure_quantum_lower`. This is an order statement, not an optimal constant or an exact minimum dimension. A finite supplied list of pure states can be compressed exactly into its finite span; the continuum hypothesis in this pure law matters, unlike N07's finite affine-spanning Gaussian hypothesis.

`expansion_quantum_boundary` supplied a stronger *exact* quantum cutoff for (2.1), without any eps>>1/n restriction. For a rotated spin-t Dicke state with excitation ell, public-frame excitation N, and `a=|z|^2/(n+|z|^2)`,

\[
 \mathbb E(N)_K=
 \sum_{j=0}^K\binom Kj^2a^{K-j}(1-a)^j
 \mathbb E[(\ell)_j(t-\ell)_{K-j}].
\]

The reduced K-site Dicke density is diagonal with hypergeometric weights. Testing the coherent rank-one projector gives its extra `binom(K,j)` factor, so there is no missing offdiagonal term. Truncated-geometric factorial moments obey
`E(ell)_j <= C j! (2 Lambda/n)^j`. Since `K<=n`,
`binom(K,j) j! = (K)_j <= K^j` gives

\[
 \Pr(N\ge K)\le C(R^2+2\Lambda)^K/K!.
\]

Thus an exact Schur-label-plus-excitation archive has quantum branch `Q=O(1+min(n,H(eps)))`; the pure endpoint provides its matching quantum lower. The exact coupling `k+ell~Bin(n,lambda/n)` also gives the label tail `Pr(k>=K)<=Lambda^K/K!`. Keeping both low labels and low public-frame excitation therefore gives exact finite-n total dimension `D=O((1+min(n,H(eps)))^2)` with no comparison remainder. My independent audit checked the combinatorial identity, t=0, K>t, the two-qubit ell=1 interference case, and n=1 under the declared `n>=4 Lambda` premise. The worker is writing the full proof. This does **not** by itself prove the sharp all-precision counted total-D law: the product converse below 1/n remains a separate question.

## 5. Ranked next targets and fatal tests

1. **Highest value: Poisson × coherent counted-memory theorem (Section 3) and exact rare-mixed transfer.** Complete the independent audit of posterior label recovery and the use of the finite visible spectral converse. Then compare against one-shot hybrid source coding and quantum statistical deficiency literature. The expected useful increment is that unknown contamination adds a full logarithmic-cutoff dimension factor although it adds only a classical observation. Fatal counterexample would be a blind code for two Poisson intensities with D=o(H^2), or a flaw in (3.2)–(3.4).
2. **Exact finite-n counted dimension at the rank-changing qubit boundary.** The quantum factor is settled internally by the coordinated factorial-tail proof. Extend the posterior argument from Poisson labels to the exact Schur laws and show a near-pure conditional block can be converted to the joint pure ensemble at accuracy below its thermal mixing weight. The latter is the load-bearing difficulty; subtracting the r=O(1/n) thermal remainder is illegal at eps<<1/n. This is a specific, potentially tractable missing lemma, not a proved result.
3. **General partially degenerate reference or growing dimension.** Seek a compatible strong factorization with public degenerate block algebra and interblock thermal/pure modes. Recent unitary QLAN and existing low-rank LAN are useful inputs, but neither supplies unrestricted moving-spectrum factorization. Constants and mode counts must be explicit before d grows. This is higher upside but lower immediate expected value than the boundary qubit theorem.

No unrestricted partial-collision QLAN theorem was established here. No purification-preserving archive, independent postselected-record guarantee, circuit compiler, or general growing-dimension theorem follows from these calculations.

## Verification scope

The report contains analytic derivations, not a numerical proof. Source manuscripts and exact interfaces were read where noted. The independent factorial identity audit is scoped algebraic agreement, not external validation. No source repository files were modified; no publication, push, or external messaging occurred.

`work/scouts/quantum_statistics_checks.py` was run successfully; saved diagnostics are `quantum_statistics_checks.json`. Over n=8,16,32,64,128 and bounded intensities, Schur probability normalization differed from one by at most `1.2e-15`, and the exact `k+ell` binomial coupling had L1 residual below `3.3e-14`. The displayed pure spin/coherent distances showed the expected `1/n` behavior for k=0,1,2. These are convention and finite-identity checks, not asymptotic or minimax proof.
