# Group approximation scout — 7 October 2026

**Strongest result:** I reconstructed N06's permutation obstruction and found no defect in that step. An original replacement of its incidence acquisition uses the old Lazebnik–Ustimenko–Woldar graph D(5,q), an explicit perfect matching, and a randomly moved interpolation grid. It reduces the ambient dimension from 20 to 5 and permits the fixed prime q = 2^61−1 and array size r = 1,200,000. The point count has 92 decimal digits, rather than N06's 3,137. This remains an internally derived candidate, with no emitted presentation, formal-kernel replay, or external mathematical review. The main scientific increment is the reusable grid-selection lemma, not another claim that nonsofic groups exist.

## Source and literature audit

Read source paths:

- work/astra-research-knowledge/00_START_HERE.txt and 01_CORE.txt.
- work/astra-research-knowledge/cards/N06-nonsofic-hyperbolic.txt.
- work/astra-research-knowledge/cards/W-frontier-groups.txt.
- work/astra-research-knowledge/web/pages/d-29830c52d5b677da.html.
- work/astra-research-knowledge/web/pages/d-5f4f3b352980d250.html.
- work/astra-research-knowledge/web/pages/d-62bae00c7f29762c.html.

I also fetched the pinned primary construction into work/scouts/groups_sources/construction.tex, and its advertised Lean scope into formal_scope252.md. The primary [construction](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/a-torsion-free-hyperbolic-group-that-is-not-residually-finite-September-23-2026/build/sections/construction.tex) supplies the triangle wiring and characteristic-q interpolation template. The [Lean scope](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/lean/docs/252.md) advertises torsion-free hyperbolic non-residual-finiteness, not the approximate-permutation extension. I did not execute it.

Current primary context:

1. [Kun–Thom, v3, August 2026](https://arxiv.org/html/2608.06222v3), Theorem A, obtains nonsofic generalized wreath products and doubles from an infranormal nonnormal subgroup when both groups have property (T). Their hyperbolic application concerns a **nonsofic p.m.p. action of a hyperbolic group**, which does not establish that group is nonsofic. These are distinct interfaces.
2. [Fournier-Facio, v2, August 2026](https://arxiv.org/html/2608.02025v2), Theorem 1.3, already gives a finitely presented torsion-free nonsofic group, using the earlier property-(T) criterion. Torsion-free nonsoficity alone is not a new target.
3. [Chapman–Peled, September 2025](https://arxiv.org/html/2509.21566v1), Theorem 1.1, offers a conditional hyperbolic route: for p = n^(−1+η), 0<η<1/2, an a.a.s. permutation cocycle expansion bound h_1 = ω(n^−3 p^−1) would imply nonsofic hyperbolic groups. Their paper does not discharge that assumption. N06's support/rank route does not need such correction-to-an-exact-action.
4. [Alekseev–Thom, Remarks on approximability and stability](https://arxiv.org/html/2512.15494v1), Corollary B, provides a residually finite hyperbolic group that is not flexibly P-stable. Hyperbolicity cannot simply be invoked as permutation stability. Their [August 2026 centralizer paper](https://arxiv.org/html/2608.05362v1) requires property (T) **and an ergodic centralizer in a sofic embedding** to deduce LEF; none of those extra hypotheses has been acquired here.
5. [Mallahi-Karai–Mohammadi Yekta, v2](https://arxiv.org/html/2112.10111v2) shows that a torsion-free group linear-sofic in characteristic zero can have separation approaching normalized rank one. This does not repair N06's block-rank argument: the local scalar counterexample below has full rectangle rank separation already.
6. [Bachner, February 2026](https://arxiv.org/html/2602.05039v1), Theorems 1.1–1.2, proves uniqueness/weak-stability results for amenable algebras with no zero divisors; the group-algebra consequence requires torsion-free amenability and the no-zero-divisors hypothesis. It provides no hyperbolic-group rank-stability shortcut.

These papers were used for scope and mechanism checks, not as external certification of the released hyperbolic construction. I did not fully re-audit the separate first-nonsofic-group proof in Ten Advances.

## Reusable obstruction, including average errors

Fix finite incidence/wiring data, r≥2, prime q>r, N labels and m points, exceptional set E. Set S_inc = sum of regular-point degrees and

\[
\Delta=Nr/4-2m-r|E|>0.
\]

Let Y_i be the r-by-r block array of D-dimensional permutation matrices X_iuv. For each triangle t let δ_t be its actual Hamming defect. Let λ_i be the average fixed-point fraction over all r²(r−1)² nondegenerate rectangles of label i. Then **every** assignment, in **every** positive dimension D, satisfies

\[
\boxed{\Delta\le \sum_t\delta_t+\frac{r^2}{8}\sum_i\lambda_i.}
\tag{1}
\]

This uses three independent facts:

- Real trace expansion gives rank_R(Y_i) ≥ r²D/[2r−1+(r−1)²λ_i].
- An integer minor with row norm ≤sqrt(r) has determinant absolute value ≤r^(d/2). If its rank modulo q is d', q^(d−d') divides that determinant. Hence rank_Fq(Y_i) ≥ half its real rank. No condition on q dividing D occurs.
- A permutation difference has rank at most its support size over every field. Each failed triangle therefore costs at most Dδ_t in the Cartesian factorization. Rank-one scalar interpolation weights then bound the aggregate rank by D(2m+r|E|+sum δ_t).

The elementary lower bound

\[
\frac{r^2}{2[2r-1+(r-1)^2\lambda]}
\ge r/4-r^2\lambda/8
\]

proves (1) without a maximum-error assumption. Its difference multiplied by the positive denominator 8[2r−1+(r−1)²λ] is

\[
2r+(3r^2-2r)\lambda+r^2(r-1)^2\lambda^2\ge0.
\]

Writing barδ for the mean over T=r²S_inc triangles, and barλ for the mean over all rectangles, yields

\[
\Delta\le T\bar\delta+(Nr^2/8)\bar\lambda.
\]

Thus a finite local-law test can choose a uniform triangle with probability T/(T+Nr²/8), otherwise a uniform rectangle, and a uniform model point. It rejects a triangle when its word moves the point, and a rectangle when its word fixes it. Its rejection probability is at least

\[
\Delta/(T+Nr^2/8)>0.
\]

Each evaluation uses at most four permutation queries. This is a useful averaged certificate, not a practical acquired tester: its test distribution and generator set still depend on the compiled astronomical presentation. Novelty of this routine averaging extension is unverified.

## Original attempt: replace random-line alteration by D(5,q)

The primary [LUW 1995 paper](https://arxiv.org/pdf/math/9501231), §2, Proposition 2.1, gives a q-regular bipartite D(5,q), with q^5 vertices on each side and girth at least 10. The explicit equations, rather than merely that theorem's abstract, are decisive. A local copy is work/scouts/groups_sources/LUW1995.pdf. The older [full construction paper](https://bpb-us-w2.wpmucdn.com/sites.udel.edu/dist/3/7714/files/2022/02/Fv22new.pdf) supplies the girth argument; [Gupta–Taranchuk](https://arxiv.org/html/2207.04629v2) confirms the D(5,q) specialization. I additionally reconstructed the short-cycle exclusion below.

Take P=F_q^5. Points are (t,y,z,w,v), line labels [a,b,c,d,e], with incidences

\[
b-y=at,\quad c-z=bt,\quad d-w=ay,\quad e-v=az.
\tag{2}
\]

For a fixed line, its points are

\[
(t,\ b-at,\ c-bt,\ d-ab+a^2t,\ e-ac+abt),
\tag{3}
\]

an actual affine line with direction (1,−a,−b,a²,ab). Distinct labels give distinct geometric lines. For a fixed point and first line coordinate a there is exactly one incident label.

**Explicit perfect matching:** match a point to the incident label with a=t. Conversely every label has a unique incident point with t=a. This is a bijection between all points and all line labels.

**Independent girth derivation:** in a simple cycle of 2s edges, let a_j,b_j be the successive line parameters, and let τ_j≠0 be the change in point first-coordinate along line j. Adjacent a_j are distinct, since an incident line with specified a is unique. Closure in the five coordinates gives

\[
\sum\tau_j=\sum a_j\tau_j=\sum a_j^2\tau_j
=\sum b_j\tau_j=\sum a_jb_j\tau_j=0.
\]

Two distinct affine lines cannot give a 4-cycle. For s=3, the three a_j are distinct and Vandermonde invertibility contradicts nonzero τ_j. For s=4 with three distinct a-values, group the repeated value in the first three equations; the two singleton coefficients must vanish. With four distinct a-values the last two equations force b_j=A+B a_j: their two-dimensional kernel has basis 1,a. With two a-values alternating, the same equations force equal b-values at opposite positions, again giving b_j=A+B a_j. Every adjacent-line intersection then has t=B, so both endpoints on each line coincide. Thus no 6- or 8-cycle exists, in any characteristic.

### Grid-selection lemma

Let S={0,...,floor(q/10)−1}. Put m=q^5, N=|S|^5, and choose an affine bijection U of F_q^5 uniformly. Select all marks in B=U(S^5). Assign each mark its matching line from (2), keep those N labels, and puncture each at its own mark.

At any point x, the q incident labels have q different matching marks; one is x itself. After puncturing, its retained degree is the number of marks in B among a fixed set A_x of exactly q−1 distinct points.

The affine group is 2-transitive on P. With ρ=N/m, for distinct a,a',

\[
\Pr(a\in B)=\rho,\qquad
\Pr(a,a'\in B)=\frac{N(N-1)}{m(m-1)}.
\]

Their membership covariance is −ρ(1−ρ)/(m−1). Therefore the degree d_x has

\[
\mu=(q-1)\rho,\qquad
\operatorname{Var}(d_x)\le\mu.
\tag{4}
\]

This proof does not assume independent selection of labels or uniform random line directions. It applies to any regular affine-line incidence graph with a fixed perfect matching.

Let E={x:d_x<4r²}. For μ≥8r², Chebyshev and then Markov give

\[
\mathbb E|E|\le4m/\mu,\qquad
\Pr(|E|>m/(2r))\le8r/\mu.
\tag{5}
\]

All retained punctured incidences already have girth at least 10, since they form a subgraph of D(5,q). No cycle enumeration or deletion is required.

Interpolation survives the moved grid: use ordinary product Lagrange polynomials in the coordinates U^−1(X). Each f_i has total degree ≤5(|S|−1), so entries of H=f f^T have line degree ≤10(|S|−1)<q−1. The characteristic-q sum over each full affine line vanishes, while deleting its mark leaves −E_ii. This supplies exactly the rank-one certificate required by (1).

### Fixed numerical instance

Set

\[
c_0=10^{-5},\quad r=1{,}200{,}000,\quad
q=2^{61}-1=2{,}305{,}843{,}009{,}213{,}693{,}951.
\]

Then q≥16r²/c_0, N≥0.9c_0m, and μ≥c_0q/2≥8r². Equations (4)–(5) give an admissible affine map with probability at least 1−1/r, satisfying |E|≤m/(2r). Hence

\[
\Delta\ge (0.9c_0r/4-2-1/2)m=m/5.
\]

The exact constants, including the 59-step Lucas–Lehmer residue for q, are recorded in groups_sources/groups_checks.json. The acceptance statement concerns a mathematically specified finite search; no actual admissible affine map was acquired.

### Geometry and resulting candidate

Use the source's two Cartesian blocks at each regular point and its cyclic shifted triangle wiring, unchanged. Give every triangle angles

\[
(21\pi/40,\ 9\pi/40,\ 9\pi/40)
\]

at O,V,W. The sum is 39π/40<π. At O the simple complete-bipartite link has cycles of at least four edges, of length at least 2.1π. At V,W the wiring gives a locally injective projection to the punctured incidence graph: fixing a label determines the shifted array coordinate uniquely, and a label belongs to one block at a given point. Link cycles have at least ten edges, of length at least 2.25π. A path between distinct same-label x-directions projects to an internally reduced closed walk and contains a cycle, so every rectangle turn has link distance at least 2.25π.

The standard CAT(−1) link criterion therefore makes the universal cover CAT(−1); finite shapes and a finite base complex give a proper cocompact action. It is contractible, deck torsion is impossible, and the rectangle paths are nontrivial closed local geodesics. The internal conclusion is a torsion-free nonsofic hyperbolic group with a finite two-dimensional classifying complex. This reconstructs the algebra and geometry for the replacement rather than adopting OA252's global theorem. A strict cell-intersection convention can be handled by subdivision without changing the metric.

The imported classical geometric facts are the usual link criterion, CAT Cartan–Hadamard, fixed-point theorem for finite isometry groups, and geometric-action characterization of hyperbolicity; N06's full source audit identifies Bridson–Haefliger II.4.13, II.5.2, II.5.4, II.5.6. No new proof of those standard results is claimed.

## Acquisition, costs, and bounded checks

Supplied in this derivation: the elementary coordinate construction, fixed matching, prime, rank/interpolation template, and standard geometric facts. Acquired in this run: source texts, the complete symbolic probability budget, coordinate fixtures, and exact numerical bounds. **Not acquired:** an admissible affine map with a checked E ledger; incidence tables; Cartesian bijections; edge/triangle lists; an emitted presentation; a common-kernel word; formal proof certification.

An admissible affine map has only 30 field coefficients, but checking its complete degree ledger by direct enumeration is astronomical. One can sample U, enumerate N marks and their q points in O(Nq) fixed-dimensional field operations, and accept if |E|≤m/(2r); the expected number of trials is ≤1/(1−1/r). This costs before construction or testing. Indexing every point can alternatively evaluate each of its q candidate marks, in O(mq) operations and less table storage. No polynomial-in-log(m) acquisition bound follows.

Exact size ledger: m has 92 digits, N has 87, N(q−1) has 106, N r² has 99, and the triangle upper bound N(q−1)r² has 118. Field elements require 61 bits rather than N06's 521. This is a substantial mathematical reduction while remaining physically unmaterialized.

work/scouts/groups_sources/groups_checks.py ran successfully. It checked all coordinate incidences, the bijective matching, affine collinearity and absence of cycles ≤8 at q=3 and q=5; verified the fixed prime by Lucas–Lehmer; and checked all numerical probability/rank-budget inequalities exactly. Those finite graphs are transcription fixtures, not proof of the universal girth argument, the group theorem, or an acquired large instance.

## Decisive failed transfers

**Normalized HS or operator norm to rank:** exp(it)I_D approaches I_D in either norm while its difference has rank D for every nonzero sufficiently small t. Consequently the triangle rank-error charge fails for general unitary microstates. Finite-field power-sum cancellation has no automatic characteristic-zero lift.

**Rectangle rank separation to block-array rank:** over C take X_uv=(a_u+b_v)I_D, with distinct positive a_u,b_v. Every rectangle ratio differs from one, because the cross-product difference is (a_u−a_u')(b_v'−b_v)≠0. Thus rank(I−rectangle)=D, yet rank((X_uv))=2D for r≥2. This kills the replacement lower-rank lemma even at full separation. It is a local counterexample, not a hyperlinear or linear-sofic model of the whole group.

**Exact linear kernel to approximate obstruction:** exact finite-dimensional representations do not control finite-relator microstates without a metric-specific stability theorem. Supremum-over-all-pairs Ulam assumptions cannot be silently substituted for a finite-presentation approximation.

No nonhyperlinearity, failure of linear soficity, property-(T) conclusion, or group-ring/surjunctivity counterexample is established here.

## Ranked targets and next decisive question

1. **High value, tractable:** independently audit/formalize the D(5,q) + moved-grid transfer, especially the matching-preimage degree identity and local-link injection. These are short lemmas with exact interfaces. A failure of either is fatal; passing them improves the constructive geometric candidate without trusting the extraordinary released global theorem. The presentation-size reduction is an internal increment; priority remains unverified.
2. **Moderate value:** retain the averaged-defect certificate as a general template for finite subgroup/local-law tests. The derivation is complete; acquiring the huge distribution remains outside practical reach. Do not relabel it an efficient sampler acquisition algorithm.
3. **Low value with present tools:** extending the certificate to general unitary/rank microstates. Two explicit failures above remove the obvious routes. It requires a genuinely different characteristic-zero/numerical-rank mechanism, not another norm inequality.

**Strongest next technical question:** can one specify and certify an admissible affine map U using a short symbolic degree-count argument, rather than scanning q^5 points or Nq incidences? The random-map existence proof has almost-unit success probability but does not acquire such a certificate. A compact certification method would change the constructive status; simply naming an unchecked random matrix would not.

Memory lookup matched unrelated HMM uses of “N06”; no relevant memory result was used.
