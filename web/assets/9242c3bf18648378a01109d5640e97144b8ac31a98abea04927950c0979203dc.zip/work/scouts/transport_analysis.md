# Transport / log-concavity scout — 7 October 2026

## Outcome and recommendation

The useful new deduction is an **unbounded-source extension of L08**, conditional on L08's compact-source potential endpoint. For a full-dimensional log-concave source with Gaussian tails and arbitrary targets in a fixed bounded set, it gives

\[
 \|T_\mu-T_\nu\|_{L^2(\rho)}
 \le C_{\rho,L} W_2(\mu,\nu)^{1/3}
               [\log(c/W_2(\mu,\nu))]^{1/6}.
\]

Exponential tails instead give a logarithmic power \(1/3\). An independently derived three-atom construction proves that the power \(1/3\) cannot be improved for a fixed standard Gaussian in dimension at least two. The logarithmic loss is **not** shown necessary.

This is a reusable conditional extension, not an independently certified new theorem: its sole frontier dependency is the compact L08 potential bound. The local source approximation, restriction of optimal maps, tail accounting, and the Gaussian lower bound are derived below. They do not acquire a numerical transport solver, density oracle, tail certificate, sample complexity, or target representation.

Ranked targets:

1. **Remove the logarithm for a fixed Gaussian source.** Try to prove a direct Gaussian centered-potential bound \(\operatorname{Var}_{\gamma_d}(u_\mu-u_\nu)\le C_d W_2(\mu,\nu)^2\), or find a counterexample. Together with the existing interpolation this would give an exact sharp one-third Gaussian map modulus. A dimension-free potential constant is a stronger secondary question. High expected value, but presently a conjecture.
2. **Audit and package the conditional noncompact extension below.** Moderate expected value: the deduction is short and complete once compact L08 is accepted. The log factors may be an artifact; the power is sharp. Existing live results use a different input metric or stronger target regularity, so exact novelty remains unresolved.
3. **Use directional target widths or project onto a known target affine span.** Technically complete, practical dimension savings, low mathematical novelty. Do not promote this straightforward consequence to a frontier discovery.

Do not spend a new wave trying to remove concentration dependence using KLS/Poincaré alone: the exact counterexample in Section 4 rules that route out, even for strongly log-concave Gaussians.

## 1. Sources inspected and current literature boundary

Read the repository's `00_START_HERE.txt`, `01_CORE.txt`, `AGENTS.md`, `cards/L08-logconcave-transport.txt`, and the complete extracted notes:

- `web/pages/d-9127feafb551695a.html` — `literature/notes/pde_spectrum9/cycle19/GENERAL_LOG_CONCAVE_STABILITY_AND_OBSTRUCTION.md`.
- `web/pages/d-deb894867c82e084.html` — `literature/notes/frontier_check_transport/cycle19/INDEPENDENT_LOGCONCAVE_GATE.md`.

Writable text extractions are in `work/transport_analysis/`. The source claims its weighted midpoint derivative argument and general-density limit were internally gated. I did not rebuild Lean, replay the original release, or independently certify that entire midpoint proof. The unweighted original sharpness formula was read through the complete gate, then adapted independently to Gaussian sources below.

Primary literature refreshed live:

- [Delalande–Mérigot, arXiv:2103.05934v2](https://arxiv.org/html/2103.05934v2), especially Section 4: compact, convex, density-bounded source; \(W_1^{1/2}\) potential and \(W_1^{1/6}\) map estimates. Their convex gradient interpolation is older machinery, not an innovation of this report.
- [Letrouit–Mérigot, arXiv:2411.04908v3, 16 July 2026](https://arxiv.org/html/2411.04908v3), Theorems 2.1 and 1.4: compact log-concave variance inequality; noncompact strongly log-concave/log-bounded sources. For a standard Gaussian and compact arbitrary targets, the stated map exponent in their \(W_1\) bound is \(1/9\). Proof/assumption paragraphs around these theorems were inspected; the whole paper was not audited.
- [Caja-Lopez–Delgadino–Kitagawa, arXiv:2605.24232v1](https://arxiv.org/html/2605.24232v1), Theorem 1.1 and its divergence-form linearization: Lipschitz \(L^2\) map stability for nondegenerate Hölder source and target densities on sufficiently smooth uniformly convex domains. Atomic targets are excluded. This regular endpoint is already claimed in the literature and does not answer our arbitrary-target question.
- [Yuanlong Ruan, arXiv:2610.07577v1, 6 October 2026](https://arxiv.org/html/2610.07577v1), structural estimate (1.6), Theorem 7, Appendix B.1/Theorem 14: arbitrary feasible-plan objective-gap conditioning and common-source stability. For a Gaussian density envelope and bounded targets, Theorem 14 gives \(W_1^{1/4}\log^{1/8}\) map stability. This preprint is one day old and not proof-certified here. The introductory power law has an \(m-1\)/\(m-2\) inconsistency; Theorem 7 and its explicit scaling use \(m-2\). That looks like an exposition error, not a demonstrated fatal theorem gap.
- [Bizeul–Klartag–Lehec, arXiv:2610.05474v1, 4 October 2026](https://arxiv.org/html/2610.05474v1) and [Song–Zhang, arXiv:2610.01447v2, revised 4 October](https://arxiv.org/abs/2610.01447v2) now claim a universal KLS/Poincaré bound. BKL's inspected criterion requires dimension-uniform bounds on **all Hilbert–Schmidt Taylor tensors of tilt averages**; the key new suspension/cumulant argument was not fully audited. Treat these as recent primary proof candidates, not a basis for claiming concentration-free transport stability.

The \(W_2^{1/3}\) bound here and Ruan's \(W_1^{1/4}\) bound do **not** uniformly dominate one another. \(W_1\le W_2\) and \(W_2^2\le 2L W_1\); for site perturbations of equal masses, \(W_1\) and \(W_2\) can be comparable, whereas mass perturbations can separate them. One can retain the minimum of the two available bounds. Relative to the inspected LM Gaussian \(W_1^{1/9}\) estimate, conversion of ours gives \(W_1^{1/6}\log^{1/6}\), conditional on L08. No priority claim follows from this limited search.

## 2. Complete conditional extension: source restriction plus tail accounting

Assume the compact L08 primitive: for every full-dimensional compactly supported log-concave probability \(\sigma\) in \(B_R\), its centered Brenier potentials satisfy

\[
 \operatorname{Var}_\sigma(u_\alpha-u_\beta)
 \le c_0^2 R^2 W_2(\alpha,\beta)^2,
 \qquad c_0=2+\sqrt5,
 \tag{C}
\]

for arbitrary target laws in a common compact set. The argument below works with any valid universal constant in (C).

Let \(\rho=f dx\) be full-dimensional log-concave, with finite second moment, and let \(\mu,\nu\subset B_L\). Take global convex \(L\)-Lipschitz Brenier potentials \(u,v\) (restricted duals provide such extensions); let \(F=u-v\), \(w=W_2(\mu,\nu)\), and

\[
 q_R=\rho(B_R^c),\qquad
 \tau(R)=\int_{|x|>R}|x|^2d\rho(x).
\]

Choose \(R\) with \(\rho(B_R)>0\). Define \(\rho_R=\rho|_{B_R}/(1-q_R)\), and the restricted output laws \(\mu_R=(\nabla u)_\#\rho_R\), \(\nu_R=(\nabla v)_\#\rho_R\). A convex gradient remains optimal for its restricted input/output laws. Moreover \(\rho_R\) is log-concave with convex compact support, so (C) applies. It is crucial to change the output laws too; restricting the source while retaining \(\mu,\nu\) would be unjustified.

The mixture identities \(\mu=(1-q_R)\mu_R+q_R\mu_{\mathrm{out}}\) and its \(\nu\) analogue give

\[
 W_2(\mu_R,\mu)\le2L\sqrt{q_R},\quad
 W_2(\nu_R,\nu)\le2L\sqrt{q_R},\quad
 W_2(\mu_R,\nu_R)\le w+4L\sqrt{q_R}.
\]

Let \(a_R=\int Fd\rho_R\). Because \(F\) is \(2L\)-Lipschitz, \(|a_R-F(0)|\le2LR\). Hence

\[
 \int_{B_R^c}|F-a_R|^2d\rho
 \le8L^2[\tau(R)+R^2q_R]\le16L^2\tau(R).
\]

Since variance minimizes the squared distance to a constant,

\[
 \begin{aligned}
 \delta^2:=\operatorname{Var}_\rho(F)
 &\le (1-q_R)\operatorname{Var}_{\rho_R}(F)
           +16L^2\tau(R)\\
 &\le c_0^2R^2(w+4L\sqrt{q_R})^2+16L^2\tau(R)\\
 &\le 2c_0^2R^2w^2+(32c_0^2+16)L^2\tau(R).
 \end{aligned}
 \tag{1}
\]

No source-change stability theorem, target minimum mass, or uniform finite perturbation step is used.

For the interpolation step define

\[
 M_j=\int_{e_j^\perp}\sup_t f(\xi+te_j)d\xi,
 \qquad M=\sum_jM_j<\infty.
\]

For Gaussian/exponential density envelopes these quantities are finite directly. Integrable full-dimensional log-concave densities have compact convex nondegenerate positive superlevel sets. Apply the compact convex interpolation to each superlevel set and integrate in its level. Tonelli/layer cake gives, with \(F\) centered,

\[
 \|\nabla F\|_\rho^2
 \le12d h^{-2}\delta^2+28L^2Mh,\qquad h>0.
 \tag{2}
\]

Thus, putting

\[
 A_{d,L,M}=\frac{\sqrt3}{2^{1/3}}(12d)^{1/6}(28L^2M)^{1/3},
\]

\[
 \boxed{\ \|T_\mu-T_\nu\|_\rho
 \le A_{d,L,M}\inf_R
 [2c_0^2R^2w^2+(32c_0^2+16)L^2\tau(R)]^{1/6}.\ }
 \tag{3}
\]

This explicit tail envelope is the reusable result. If a supplied certificate says \(\tau(R)\le A e^{-bR^\alpha}\), \(\alpha=1\) or \(2\), then choose \(R\asymp[\log(c/w)]^{1/\alpha}\), giving

\[
 \delta\lesssim_{\rho,L}w\log(c/w)^{1/\alpha},\qquad
 \|T_\mu-T_\nu\|_\rho\lesssim_{\rho,L}
 w^{1/3}\log(c/w)^{1/(3\alpha)}.
\]

The scale \(c\), constants, and enclosing centers must be supplied/derived explicitly for an application. General log-concavity alone does not make them dimension-free. Finite moments without an exponential tail certificate give (3), not automatically these logarithmic rates.

## 3. Independent sharp lower power for a fixed standard Gaussian

Take \(\rho=\gamma_2\) and independent standard normals \(X_1,Z\). Let \(q(t)=2\Phi(t)-1\) for \(t\ge0\), \(p_a=q(a)\), and define

\[
 u_a(x)=\max\{-x_1,x_1,a\},\qquad
 v_a(x)=\max\{-x_1,x_1,b_a+(a/2)x_2\}.
\]

Choose the unique real \(b_a\) satisfying

\[
 \mathbb E q([b_a+(a/2)Z]_+)=q(a).
 \tag{4}
\]

The left side is continuous, strictly increasing from zero to one. By symmetry in \(x_1\), the target laws have identical masses:

\[
 \mu_a=\tfrac{1-p_a}{2}\delta_{-e_1}+p_a\delta_0
                  +\tfrac{1-p_a}{2}\delta_{e_1},
\]
\[
 \nu_a=\tfrac{1-p_a}{2}\delta_{-e_1}+p_a\delta_{(a/2)e_2}
                  +\tfrac{1-p_a}{2}\delta_{e_1}.
\]

They are the pushforwards by the displayed convex gradients, hence those gradients are their optimal maps. Every target coupling pays the vertical squared cost \((a^2/4)p_a\); matching equal horizontal coordinates realizes zero horizontal cost. Therefore

\[
 W_2(\mu_a,\nu_a)^2=(a^2/4)p_a\sim[\phi(0)/2]a^3.
 \tag{5}
\]

Write \(c_a=b_a/a\). Dominated convergence in (4) gives \(c_a\to c_*\), where

\[
 \mathbb E[c_*+Z/2]_+=1.
\]

For detail: small-\(a\) solutions lie between 0 and 2; \(q(at)/a\le2\phi(0)t\); each convergent subsequence must solve the displayed strictly increasing limiting equation. Thus all subsequences have the same limit.

Let \(C_u=\{|X_1|\le a\}\), \(C_v=\{|X_1|\le[b_a+(a/2)Z]_+\}\). Conditional intervals are nested, so

\[
 \rho(C_u\triangle C_v)=\mathbb E|q(a)-q(a[c_a+Z/2]_+)|
 \sim k_*a,
\]

where

\[
 k_*=2\phi(0)\mathbb E|1-[c_*+Z/2]_+|>0.
\]

The exact map discrepancy is

\[
 \|\nabla u_a-\nabla v_a\|_\rho^2
 =\rho(C_u\triangle C_v)+(a^2/4)p_a\sim k_*a.
 \tag{6}
\]

Consequently the ratio of the map norm to \(W_2^\beta\) diverges for every \(\beta>1/3\). This proof is independent of L08. It adapts the release's supplied square example, so its mechanism is inherited and Gaussian generalization priority is unknown. Extra independent coordinates extend it to \(\gamma_d\), \(d\ge2\). No finite diagnostic is needed for the conclusion.

## 4. Decisive failure of concentration-free improvements

For \(n\ge1\) let \(\rho_n=N(0,\operatorname{diag}(n^{-2},1))\),

\[
 \mu=\tfrac12(\delta_{-e_1}+\delta_{e_1}),\quad
 \nu_n=\tfrac12(\delta_{-(e_1+n^{-1}e_2)}+
                         \delta_{e_1+n^{-1}e_2}).
\]

The optimal maps are \(e_1\operatorname{sgn}X_1\) and \((e_1+n^{-1}e_2)\operatorname{sgn}(X_1+X_2/n)\). Standardizing gives signs of \(Z_1\) and \(Z_1+Z_2\); their disagreement probability is exactly \(1/4\), by rotational symmetry and the angle \(\pi/4\). Hence

\[
 W_2(\mu,\nu_n)=1/n,\qquad
 \|T_\mu-T_{\nu_n}\|_{\rho_n}^2=1+n^{-2}.
 \tag{7}
\]

Nevertheless every source has Gaussian Poincaré constant exactly 1, covariance operator norm 1, a common centered linear subgaussian certificate, and potential Hessian at least the identity. Uniform Gaussian tail control also holds. Its directional concentration is

\[
 M_{\rho_n}=(n+1)/\sqrt{2\pi}.
\]

A \(w^{1/3}\) coefficient must therefore grow at least like \(M^{1/3}\) along this family. A universal Poincaré theorem cannot supply the missing control. Potential differences remain \(O(1/n)\) in \(L^2\), so this example does not refute the Gaussian potential conjecture in target 1.

## 5. Directional and affine dimension reductions

Let \(\ell_j\) be half the width of the common target container in coordinate \(j\), after a common target translation. The one-dimensional fiber proof behind (2) only needs slope bounds in that coordinate. Choosing each difference-quotient length \(h_j\) separately gives

\[
 \|\nabla F\|_\rho^2\le
 \sum_j\{12h_j^{-2}\delta^2+28\ell_j^2M_jh_j\}
 \le C\delta^{2/3}\sum_{j:\ell_j>0}(\ell_j^2M_j)^{2/3}.
 \tag{8}
\]

For \(\rho=N(0,\Sigma)\), \(M_j=\sqrt{(\Sigma^{-1})_{jj}}/\sqrt{2\pi}\), obtained by integrating the maximum conditional Gaussian density over the remaining coordinates. Eigenvectors minimize \(\sum_jM_j\) by concavity of square root and the Schur–Horn ordering. Optimizing (8) with target widths need not have the same optimizer.

If all targets lie in a supplied \(s\)-dimensional affine subspace, project the source onto it; orthogonal cost is independent of the target and the projected source stays log-concave. L08 and (3) then use \(s\) and the projected density's concentration. This is a known elementary reduction; discovering the subspace or producing its certificate is a separate acquisition problem.

## Fatal tests and next decision

Before upgrading (3), externally audit the compact weighted midpoint derivative/cell calculus in L08. This report does not close that dependency. Verify any candidate Gaussian log-removal bound on rare cells: Gaussian boundary centroids diverge as cell mass tends to zero, so simply replacing the radius in L08's separate moment bound by a covariance/Poincaré constant is false. A direct potential argument must preserve cancellation between moving-site linear terms and cell intercepts.

The strongest next technical question is therefore: **Does a fixed Gaussian admit a linear \(W_2\) bound for centered potentials with arbitrary bounded, possibly atomic targets?** Proving it removes the only logarithmic loss in (3); a counterexample identifies a genuine noncompact obstruction. The useful endpoint is sharp by (5)–(6), and the concentration-free alternative is already ruled out by (7).
