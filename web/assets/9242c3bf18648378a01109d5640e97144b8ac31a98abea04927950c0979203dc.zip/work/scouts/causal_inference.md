# Causal-inference scout — 7 October 2026

**Recommendation:** advance one restricted active-acquisition theorem: unknown linear latent coordinates and their DAG can be recovered from **2K+3 covariance environments**, despite arbitrary hidden confounding and full-rank measurement noise, provided unknown deterministic clamp targets strongly separate the coordinates and independent additive-noise profiles can be paired while the nuisance law remains fixed. A complete population proof and a deterministic robustness module are below. This is a potentially useful composition of older covariance-shift identification and recent latent support-lattice identification. Novelty is **not established**; the probe services are strong and supplied. It does not solve general representation acquisition.

## Ranking and literature boundary

| Rank | Target | What was achieved here | Upside / main risk |
|---|---|---|---|
| 1 | Noisy, confounded latent model acquisition through paired covariance contrasts and unknown clamps | Complete population algebraic proof; explicit support-subspace perturbation bound; 50 confounded numerical reconstructions | Removes noiseless measurements and causal sufficiency from a useful linear acquisition interface. It may be an immediate corollary in prior noisy ICA/CRL literature; legal paired probes remain supplied. |
| 2 | Sharp robust experimental-design theorem with sensor/background drift | Exact population indistinguishability construction; derived necessary error floor proportional to drift / excitation | Turns qualitative identifiability into a useful stop/continue certificate. A minimax upper bound with sharp dependence on conditioning and design is still open here. |
| 3 | Task-functional proximal compression instead of full latent recovery | Prior-art screen and elementary operator derivation | High application value, but the central nullspace/adjoint-range result is already established. Do not relabel it as a new acquisition theorem. |

Primary sources, current as searched on 7 October 2026:

- [BACKSHIFT, Rothenhäusler et al., NeurIPS 2015](https://papers.neurips.cc/paper/5682-backshift-learning-causal-cyclic-graphs-from-unknown-shift-interventions.pdf), especially model equations and joint diagonalization / identifiability sections. Fixed latent confounding cancels in covariance differences under independent additive shifts. This is the direct older baseline for the graph-recovery half, rather than a new mechanism introduced here. Model and identifying interface read; the entire cyclic proof was not re-audited.
- [Causal Dantzig, Rothenhäusler, Bühlmann and Meinshausen, Annals of Statistics 2019](https://people.math.ethz.ch/~peterbu/Files/Manuscripts/CausalDantzig.pdf), Sections 2–3. Inner-product invariance avoids full graph search, accommodates hidden confounders under its additive-intervention assumptions, and includes nonidentification/prediction guarantees. An equally informed comparator must include this direct moment-solving route. Relevant interface read, not a full proof audit.
- [Lee, Jin and Aragam, *Beyond identifiability*, arXiv:2603.25796v1, 26 March 2026](https://arxiv.org/html/2603.25796v1), Sections 2–4, equations (2)–(9), Lemma 3.1, Theorems 4.5–4.7. Their linear model has noiseless observations, independent latent structural noises, deterministic zero clamps, two noise regimes, and strongly separating unknown targets. Support subspaces recover the decoder; distinct noise-variance ratios permit generalized eigenvectors. This is the closest recent baseline. Main model and derivation read; the advertised finite-sample rates were not accepted as a black box.
- [Sethuraman and Fekri, RECLAIM, arXiv:2603.20585v1, 21 March 2026](https://arxiv.org/html/2603.20585v1), Section 2.2 and Section 3.3. Its linear measurement matrix is **known** and its measurement errors are independent Gaussian coordinates. Its population score result assumes exact maximization. It is relevant measurement-noise prior art, but those interfaces differ from unknown dense mixing and arbitrary dense nuisance covariance below. Model and noise-identification sections read.
- [Varıcı et al., JMLR 2025](https://jmlr.org/papers/v26/24-0194.html). Score-based causal representation identifiability supplies important stronger nonlinear and stochastic-intervention comparators. Only the theorem/interface overview was screened; its 90-page proof was not audited here.
- [Zhang, Li, Miao and Tchetgen Tchetgen, *Proximal Causal Inference without Uniqueness Assumptions*](https://arxiv.org/html/2303.10134), Proposition 2.3 and Lemma 2.4. The proof explicitly distinguishes functional identification from regular root-n estimation using the nullspace and adjoint range. Relevant proof read.
- [Koltchinskii and Lounici, covariance-operator concentration](https://arxiv.org/abs/1405.2468), published Bernoulli 2017. Gaussian covariance error is controlled by total covariance scale and effective rank. Full sensor noise can make that rank ambient; a latent-rank sample claim would be incorrect. Concentration interface read, not the full proof.

No primary result in this search establishes the exact composite theorem below with unknown B, unknown strongly separating clamp targets, arbitrary correlated backgrounds, and arbitrary full-rank measurement covariance. That is a search finding, **not a novelty certificate**.

## Internally derived population theorem

For d≥2, use A_ij for the coefficient on Z_j in the equation for Z_i, so G=I−A. A is an unknown DAG matrix. B∈R^(p×d) is unknown and has full column rank. Observations are X=BZ+ε. Finite second moments suffice.

For each clamp setting k=1,…,K, an unknown target set I_k fixes those latent coordinates to deterministic constants. After centering, Z_i=0 for i∈I_k. Write S_k=I_k^c, B_S=B[:,S], and G_S=I−A[S,S]. The remaining model is

\[
 Z_S^{k\ell}=G_S^{-1}(h_S^k+\xi_S^{k\ell}),\qquad X^{k\ell}=B_S Z_S^{k\ell}+\varepsilon^k.
\]

The pair (h^k,ε^k) has an arbitrary joint law, fixed across profile labels ℓ within setting k. Its components may be correlated, so both hidden confounding and correlated sensor noise are allowed. Its law may change arbitrarily across different k. The injected ξ is independent of that pair and has diagonal covariance D_kℓ. Its strength and coordinate labels need not be known. These are **additive structural-noise probes**, not passive observations.

The supplied probe conditions are:

1. For every j≠i, some clamp setting keeps j and clamps i, and some keeps i and clamps j. This is strong separation; target labels are unknown to the learner.
2. Two profiles ℓ=0,1 are available for each k. Every entry of E_k=D_k1−D_k0 on S_k is nonzero. Mixed signs are allowed.
3. There is an unclamped baseline k=0 with three profiles ℓ=0,1,2. Set E_1=D_01−D_00 and E_2=D_02−D_00. Require E_1≻0 and pairwise distinct ratios (E_2)_ii/(E_1)_ii. Other nonsingular definite contrast conventions also work.
4. A, B, clamp constants, and the nuisance law stay fixed across the paired profiles in a setting. The nuisance need not be small.

**Conclusion:** B's column lines and every I_k are identifiable up to a common permutation. B itself is identifiable up to coordinate scaling and permutation. A is identifiable up to the same coordinate gauge; its DAG is identifiable up to permutation. There is an explicit population reconstruction requiring 2K+3 covariance matrices. If K≤c log₂d with fixed c, the simple enumeration algorithm below is polynomial in d and p.

**Proof, step 1 — nuisance cancellation.** Let Σ_kℓ=Cov(X^kℓ). Every covariance and cross-covariance involving (h^k,ε^k) is fixed across ℓ. Independence of ξ cancels mixed terms. Therefore

\[
 C_k:=\Sigma_{k1}-\Sigma_{k0}
 =B_{S_k}G_{S_k}^{-1}E_kG_{S_k}^{-T}B_{S_k}^T.
\]

G_S is invertible because A is a DAG, and E_k is nonsingular. Thus **col(C_k)=span{b_j:j∈S_k}**. Positive semidefiniteness of C_k is unnecessary. Full-rank measurement noise no longer hides the support subspace.

**Step 2 — acquire the latent column lines without target labels.** Set U_k=col(C_k). Full column rank of B implies

\[
 \bigcap_{k\in T}U_k=\operatorname{span}\{b_j:j\in\bigcap_{k\in T}S_k\}.
\]

For each j, take the settings in which j is kept. Strong separation guarantees their support intersection is {j}. Hence the one-dimensional intersections among all nonempty T⊆[K] are exactly the d distinct lines span(b_j), with duplicates discarded. Enumerate those intersections, recover normalized representatives, then recover S_k by line containment in U_k. No target labels or B columns were supplied.

**Step 3 — acquire the DAG.** Choose the recovered B gauge and apply its pseudoinverse to the two baseline contrasts. In the true gauge they are

\[
 V_1=G^{-1}E_1G^{-T},\qquad V_2=G^{-1}E_2G^{-T}.
\]

The generalized eigenvectors solving V_2 t=λV_1 t are the columns of G^T, each up to a nonzero scalar, and up to eigenvector ordering. Distinct ratios guarantee one-dimensional eigenspaces. Transpose these columns into candidate rows of G. A DAG permits exactly one row permutation having a nonzero diagonal: a different successful matching would contain a permutation cycle, and the corresponding off-diagonal entries of G would form a directed cycle in A. Normalize that unique diagonal to one. This reconstructs G and A. A monomial change of the recovered B gauge only permutes and rescales the latent coordinates. ∎

This argument does **not** identify the separate sensor and confounder laws or reconstruct Z exactly for each noisy X. Even in one dimension with known Z∼N(0,v), ε∼N(0,w), Var(Z|X)=vw/(v+w)>0. Model identifiability and individual-state recovery must remain separate.

## Internally derived robustness module

Normalize B's columns and put κ=σ_max(B)/σ_min(B). Suppose the minimum nonzero singular value of every C_k is at least γ>0 and estimated contrasts satisfy ||Ĉ_k−C_k||≤η<γ/4. Recover U_k by retaining eigenvectors of the symmetric Ĉ_k with |λ|≥γ/2. The rank is correct, and the projector error obeys

\[
 \|\widehat P_k-P_k\|\le\frac{\eta}{\gamma-\eta}\le\frac{2\eta}{\gamma}.
\]

Indeed, multiplying the estimated eigenvector equation by I−P_k gives (I−P_k)ŨΛ=(I−P_k)(Ĉ_k−C_k)Ũ. Invert the retained Λ; equal dimensions identify the projector norm with the largest sine angle.

For any nonempty T define a **sum**, rather than an ordered product, of complementary projectors:

\[
 H_T=\sum_{k\in T}(I-P_k).
\]

Its kernel is ∩U_k, and every positive eigenvalue is at least κ^(−2). To see the gap, write v=Ba+v_perp. The distance to B's coordinate subspace indexed by S_k is at least σ_min(B)||a[I_k]||, and distances to their intersection are at most σ_max(B)||a[outside intersection]||. Summing the squared distances counts every excluded coordinate at least once; the orthogonal component contributes |T|||v_perp||². Thus

\[
 v^T H_Tv\ge\kappa^{-2}\operatorname{dist}(v,\ker H_T)^2.
\]

The estimated H differs by at most 2|T|η/γ. If that is ≤1/(4κ²), thresholding at 1/(2κ²) recovers the intersection dimension, and its projector error is at most

\[
 e_T\le 4|T|\kappa^2\eta/\gamma.
\]

Distinct normalized B column lines are separated in projector norm by at least 1/κ. Consequently the sufficient condition

\[
 \eta<\frac{\gamma}{32K\kappa^3}
\]

allows the one-dimensional intersections to be clustered at distance 1/(2κ), with correct target membership. This is a conservative, explicit deterministic bound, not a sharp minimax rate. η can include sample error, soft-clamp leakage, and between-profile nuisance drift, if their contrast error is actually bounded. The graph stage additionally needs a quantified variance-ratio eigengap, minimum nonzero edge size, and stable diagonal normalization; those costs cannot be dropped just because ratios are qualitatively distinct.

For centered Gaussian observations, let L=max||Σ_kℓ|| and r=max tr(Σ_kℓ)/||Σ_kℓ||. A usual simultaneous covariance bound gives contrast error of order

\[
 \eta\lesssim L\left[\sqrt{\frac{r+\log(M/\alpha)}{n}}+
 \frac{r+\log(M/\alpha)}{n}\right],\qquad M=2K+3.
\]

Combining this with the module supplies a sufficient sample budget for decoder/target acquisition. This uses **total physical covariance**, including nuisance; r may equal p. It does not establish a complete finite-sample graph theorem.

## Decisive failure tests and lower-bound attempts

**Only additive noise interventions are insufficient when B is unknown.** Let C be any full-rank mixing matrix. For any DAG A, set B=C(I−A). Then under every independent structural-noise profile,

\[
 X=B(I-A)^{-1}\nu=C\nu.
\]

All profile laws are identical for every choice of A. Unlimited noise-profile samples identify source-noise response coordinates at most; they cannot separate the causal-coordinate mixing from its DAG. The deterministic-clamp service above does real identification work. An equally informed ICA/joint-diagonalization retaining baseline makes this obstruction immediate.

**Profile-varying sensor drift gives a population ambiguity floor.** In d=p=2, compare B=I and B'=R_θ with an empty DAG. Give both the same strongly separating clamp sets. If a signal covariance is S_kℓ in model 1, use sensor noise covariance

\[
 \Omega'_{k\ell}=\tau I+S_{k\ell}-R_\theta S_{k\ell}R_\theta^T
\]

in model 2. For τ sufficiently large this is positive definite. Both models give exactly the same centered Gaussian observed law in every setting, although their latent column lines differ by |sin θ|. Noise shifts of size γ imply nuisance drift O(γ|sin θ|). The triangle inequality therefore gives worst-case representation error at least c min{1,ρ/γ} when between-profile covariance drift up to ρ is allowed. No number of samples removes this error. This is an internally derived obstruction; the constant-accurate lower-bound family can be chosen with distinct baseline noise ratios.

**Weak excitation forces sample cost even without drift.** For two such rotated Gaussian models with fixed sensor noise τI and excitation of order γ, per-sample KL is O(γ² sin²θ/τ²). Across N observations, choosing sin θ≈min{1,τ/(γ√N)} keeps the experiments statistically close. A two-point testing argument yields the corresponding necessary representation-error scale. This is a standard local statistical mechanism, not claimed as novel. It falsifies any rate independent of excitation strength or sensor variance.

**Stochastic hard interventions are not automatically clamps.** If targeted latent coordinates retain nonzero variance, col(C_k) need not be span(B_Sk). A thresholded version requires a genuine leakage bound. Merely calling an intervention “hard” supplies no support rank deficiency. Other score-based CRL theorems may handle that setting; this proof does not.

## Execution evidence and resource account

Owned files:

- `work/scouts/causal_inference_check.py`
- `work/scouts/causal_inference_check.json`
- this report, `work/scouts/causal_inference.md`

Run: `python3 work/scouts/causal_inference_check.py` (NumPy and standard library; no installed dependency or paid service). Two populations of 50 seeded instances, d=2,…,6 and p=d+2, were reconstructed:

1. Two-regime independent-noise DAGs with dense invariant sensor covariance and mixed-sign contrast increments. Maximum decoder error 1.44e−14, sensor-covariance error 4.92e−14, DAG coefficient error 1.43e−11. In this narrower globally invariant-noise model, clamped latent rows also reconstruct the projected sensor covariance row by row.
2. Three-profile DAGs with dense latent confounder covariance and dense sensor covariance, each varying across clamp settings while fixed within a profile triple. Maximum decoder error 2.86e−14 and DAG coefficient error 2.74e−12.

The numerical three-profile drift counterexample has latent rotation 0.4 radians, maximum sensor covariance drift 0.012462, positive sensor eigenvalues ≥0.987538, distinct baseline contrast ratios 0.272727 and 0.055556, and **exactly zero** difference in every observed covariance. Gaussianity makes covariance equality equality of the complete observed laws.

These are finite diagnostics, not proof certification or scientific replication. The first diagnostic failed because its generator accidentally permitted a negative noise variance; the generator was corrected to impose positive profile variances before rerunning. No theorem was changed to fit the outcomes.

Population algorithm costs: M=2K+3 experimental covariance environments; n samples per environment; covariance formation O(Mnp²) arithmetic; covariance storage O(Mp²); a conservative subspace-enumeration implementation O(2^K Kp³). Samples can be streamed. Full graph acquisition includes generalized eigenvalue work and unique row matching. The diagnostic uses small exhaustive row permutations; that is replaceable by bipartite matching and is not a claimed scalable implementation.

Supplied: linear measurement family/full-column-rank promise, DAG promise, deterministic clamp capability, unknown but strongly separating target family, profile pairing, independent diagonal excitation, nuisance invariance within pairs, numerical conditioning or precision budget. Acquired: B column lines, target membership, a coordinate-gauge causal matrix/DAG. Not acquired: arbitrary useful latent interventions from observations, counterfactual individual states, a complete nonlinear model, separate nuisance laws, or an optimal archived-law decoder.

Comparator: recover the same covariance matrices and run existing joint diagonalization/support-subspace methods with exactly the same profiles and clamp data. Any benefit is an expanded provable noise/confounding interface and potentially improved certificates, not a claim of beating direct algebraic solvers or retained covariance data.

## Strongest next question and expected value

The strongest next theorem is an **honest finite-sample certificate for a requested causal functional**, with total error decomposed into sample covariance noise, imperfect clamp leakage, between-profile drift, decoder conditioning, and variance-ratio separation. Can it attain the necessary drift/excitation floor while requiring less than complete DAG recovery, and can the pairing/invariance promise itself be tested with held-out profiles? Testing invariance cannot prove arbitrary unseen-profile invariance; the legal experiment class must be explicit.

Expected value: medium-high for a short mathematical depth wave, because the population construction is complete, has a concrete measurement-noise gap against the closest recent baseline, and admits an immediate adversarial audit. Stop or downgrade if the exact theorem is already in noisy ICA/CRL, if obtaining legal independent excitation is the real application bottleneck, or if the intended significance requires unknown nonlinear representations or arbitrary interventions. Success would establish a useful restricted active acquisition result, not the archive campaign's universal acquisition objective.

The proximal alternative should stay as a comparator. For a linear inverse problem Th=m, the scalar ⟨ℓ,h⟩ is identified iff ℓ⊥ker(T); if ℓ=T* q, it equals ⟨q,m⟩ without reconstructing h. Identifiability corresponds to closure of the adjoint range, whereas stable/regular estimation needs stronger range control. The cited proximal paper already proves the central distinction. The new burden would be acquiring useful q and certifying approximation/conditioning with the same data and costs as the baseline, rather than declaring compressed causal knowledge from bridge existence.

## Local provenance and status

Read-only archive entry points used: `work/astra-research-knowledge/00_START_HERE.txt`, `01_CORE.txt`, `AGENTS.md`; relevant mechanisms in `mechanisms/TRANSFER_MAP.txt`; scope checks from `cards/P-learning.txt`, `cards/W-frontier-probability-bridge.txt`, `cards/P-gaussian-physics.txt`. No released mathematics claim was used as a premise of the new derivation. Memory `MEMORY.md:2578–2581` reinforced the supplied/acquired and matched-comparator accounting only; all mathematical mechanisms above were checked or derived in this run.

Status labels: older literature mechanisms **established within their published interfaces**; March 2026 sources **primary preprints, model/interface inspected**; main theorem, perturbation module, and counterexamples **internally derived, unreviewed**; numerical results **executed finite diagnostics**; exact novelty and sharp full graph finite-sample theorem **open**.
