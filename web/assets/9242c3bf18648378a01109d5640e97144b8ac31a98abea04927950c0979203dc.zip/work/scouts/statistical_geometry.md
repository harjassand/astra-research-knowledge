# Statistical experiment compression: smooth coordinates, support edges, and posterior geometry

Date: 7 October 2026. Scout: statistical_geometry. Source repository read only.

**Status.** The elementary endpoint and mixed-product bounds below are internally derived candidate results with complete proofs in this note. They are independent of the repository's quantum Gaussian comparison bridge. They have not been externally reviewed or given novelty clearance. The general posterior converse combines established decision-theoretic and quantization machinery; describing that machinery itself as new would be incorrect.

## Main finding and ranking

The N07 Gaussian exponent is not a universal dimension-only law. For one observation from `Uniform[0,theta]`, `theta in [1,2]`, the optimal uniform-TV reconstruction error through dimension `D` is

    e_D = Theta(D^-1),

including arbitrary quantum/hybrid memory and free independent public classical randomness. More generally, for the product experiment

    X ~ N(mu,I_s), mu in a fixed bounded affine-spanning set,
    Z_j ~ Uniform[0,theta_j], theta_j in [1,2], j=1,...,r,

with all observations independent conditional on the unknown parameters,

    e_D = Theta(D^(-2/(s+2r))).

Thus the precision cost is

    log_2 D_opt(epsilon) = (s/2+r) log_2(1/epsilon)+O(1).

The Gaussian coordinates contribute one unit of posterior metric dimension each; a hard support edge contributes two. The further derivation in section 9 covers densities vanishing as `(theta-x)^beta` at the edge and gives the continuous range `e_D=Theta(D^(-min(beta+1,2)))`. The sharp general invariant must involve bounded decision regrets, because a fixed squared posterior metric can be weaker. Classical codes attain these orders, so quantum memories cannot improve the proved exponents in the stated interface. Constants, and the existence of a quantum constant-factor advantage, remain open.

Ranked targets:

1. **Local decision regret and anisotropic reconstruction.** Highest immediate value: the mixed law above is an exact non-Gaussian extension, and the endpoint proof decisively rejects a naive universal `D^(-2/observation_dimension)` assertion. The further tapered-edge derivation in section 9 gives the continuous range `D^(-min(beta+1,2))` and shows that one fixed Brier posterior metric can miss the sharp rate. Package a general regret-volume converse plus sharp smooth/edge examples. The strongest next question is an experiment-level positive approximation theorem matching the full family of bounded decision regrets.
2. **Smooth curved experiments beyond Gaussian location.** A one-dimensional smooth parameter curve can have `e_D=Theta(D^(-2/r))` for arbitrarily large fixed `r`, even in a bounded periodic density family. This proves that parameter Fisher rank and parameter manifold dimension are insufficient predictors of the fixed-experiment precision exponent. Tractable, but likely largely a synthesis of existing machinery.
3. **Exact endpoint constants and quantum advantage.** For the scalar endpoint family, geometric bins give a clean explicit upper. Determine the optimal leading constant under deterministic classical, public-randomized classical, and quantum memories. This is a sharper quantum/classical comparison than merely matching exponents, but historical prior-art risk and technical difficulty are greater.

## 1. Exact interface

The encoder receives one supplied classical observation, never the unknown parameter. All input-dependent retained information passes through

    A = direct_sum_j M_(d_j), D = sum_j d_j.

The decoder performs an arbitrary POVM and outputs a fresh classical observation. An input-independent shared classical seed is free, with memory dimension at most `D` for every seed. No retained input-dependent side registers, entangled receiver reference, feedback, or second communication channel are included. Encoder/decoder private randomization is allowed. TV means half the L1 distance.

For an experiment `E={P_theta}`, define

    e_D(E)=inf_(encoder,decoder) sup_theta TV(RE P_theta,P_theta).

For classical memory this is the best reverse Le Cam deficiency among `D`-outcome garblings of `E`; their forward deficiency is zero. The quantum extension is the same operational self-reconstruction problem with the bottleneck algebra above. The encoder cannot be replaced by a supplied parameter estimate or a code designed after learning `theta`.

Supplied information: the full model family, its fixed parameter domain, covariance/grid/coordinate transformations, and target memory dimension. No model acquisition theorem is claimed. The cost proved is retained dimension (or its logarithm), not finite-bit running time, model discovery, preparation complexity, or purification fidelity.

## 2. A general posterior Hilbert-space converse

Let `pi` be any prior on the parameter space. Write `p(x)` for its predictive density relative to an observation measure `lambda`, and let

    f_x(theta)=d pi(theta|X=x)/d pi(theta).

Suppose the posterior densities, with a measurable extension to possible decoder outputs, satisfy

    0 <= f_y(theta) <= K, integral f_y d pi = 1.

Regard `f_y` as an element of `H=L^2(pi)`. The quadratic proper score

    S(theta,f_y)=||f_y||_H^2-2 f_y(theta)

lies in `[-2K,K]`: `||f_y||^2 <= K integral f_y = K`. Under the actual channel coupling `Theta -> X -> memory -> Y`, including an independent seed,

    E[S(Theta,f_Y)-S(Theta,f_X)]
      = E||f_Y-f_X||_H^2.                         (2.1)

This follows by conditioning on `(X,Y,seed)` and using `E[f_Y(Theta)|X,Y,seed]=<f_X,f_Y>`. If every reconstructed row has TV error at most `e`, the bounded-score comparison gives

    E||f_Y-f_X||_H^2 <= 3K e.                     (2.2)

Crucially, `f_Y` is evaluation of the ORIGINAL posterior map at the decoded observation. It need not be the posterior for the altered experiment generated by `Y`.

Let `C` be a measurable source region of mass `M=P(X in C)>0`, with `p(x)<=p_max` on `C`. Suppose posterior small balls satisfy, uniformly over possible output targets,

    lambda{x in C: ||f_x-f_y||_H <= h} <= A h^kappa.  (2.3)

At each seed, encoder states satisfy `omega_x<=I`, and the decoder POVM has total trace at most `D`. Tonelli and positivity therefore give

    P(X in C, ||f_X-f_Y||<=h | seed)
      <= p_max integral Tr F(dy)
           lambda{x in C: ||f_x-f_y||<=h}
      <= p_max A D h^kappa.                      (2.4)

The seed does not change `p`, `M`, or the bound; average over an arbitrary seed distribution. With `h=(M/(2 p_max A D))^(1/kappa)`, at least `M/2` mass in `C` has posterior displacement greater than `h`. Consequently

    e >= [M/(6K)] [M/(2p_max A)]^(2/kappa) D^(-2/kappa). (2.5)

This is a trace-`D` converse, not a rank-`D^2` argument. Continuous decoder outcomes, mixed states, hybrid branches, and arbitrary independent public seeds cause no change.

A useful sufficient condition on a coordinate chart is

    ||f_x-f_x'||^2 >= c sum_i |x_i-x_i'|^(alpha_i).

Posterior balls then have volume `O(h^kappa)`, where `kappa=sum_i 2/alpha_i`; a triangle inequality handles targets outside the chart. This produces a lower exponent `2/kappa = 1/(sum_i 1/alpha_i)`. A matching TV upper remains a SEPARATE positive reconstruction problem. Posterior lower geometry alone does not prove one.

Smooth immersed posterior maps have `alpha_i=2`. Hard moving supports can have `alpha_i=1`, even though the geometric observation coordinate is a real interval.

## 3. Sharp scalar endpoint theorem, with atoms audited

**Claim.** For `P_theta=Uniform[0,theta]`, `theta in [1,2]`, there are fixed positive constants `c,C` such that, for all integer `D>=1`,

    c/D <= e_D <= C/D.                            (3.1)

### 3.1 Bounded continuum posterior and its snowflake metric

Use the prior

    pi = (1/2) Uniform[1,2] + (1/2) delta_2.

The atom is an analytical converse device, not input supplied to the encoder. It anchors the predictive density away from zero near the largest endpoint. For `0<=x<=2`, set `t(x)=max(1,x)`. Then

    p(x)=1/4+(1/2) log(2/t(x)),
    f_x(theta)=1{theta>=t(x)}/[theta p(x)]          (3.2)

relative to `pi`. At `theta=2`, the atom's posterior-density value is `1/[2p(x)]`; the atom must not be silently dropped from the L2 integral. Since `p>=1/4` and `theta>=1`, all posterior densities are bounded by `K=4`.

Extend to arbitrary real decoder outputs using `t(y)=min(2,max(1,y))` and `f_y=f_(t(y))`. At `t=2`, the continuous posterior part vanishes and the atom's density is exactly 2, giving a normalized posterior. At `x<=1`, the entire posterior is constant: this region is one posterior atom. It contributes no positive-dimensional lower geometry and is never used for the small-ball region.

For `1<=t<=u<=2`, on the continuous-prior interval `[t,u)`, `f_u=0` while `f_t>=1/2` because `theta<=2` and `p(t)<=1`. Therefore

    ||f_t-f_u||^2 >= |t-u|/8.                     (3.3)

The squared Hilbert distance is actually comparable to `|t-u|` on the whole interval. For an exact expression, put `A(v)=1/(2v)-1/8`. Then

    ||f_t-f_u||^2
      = (1/2)(1/t-1/u)/p(t)^2
        + A(u) [1/p(t)-1/p(u)]^2.                 (3.4)

Both terms are nonnegative; the second includes the overlap and the atom. The derivative of `1/p` is bounded on `[1,2]`, so (3.4) also yields `||f_t-f_u||^2 <= 32|t-u|`. Thus the posterior's Hilbert metric is a square-root snowflake of the endpoint interval; its metric dimension is 2.

### 3.2 Explicit quantum/hybrid lower bound

By (2.1)-(2.2),

    E||f_X-f_Y||^2 <= 12e.                        (3.5)

Take `C=[5/4,7/4]`. Its predictive mass is at least `M=1/8`; on `C`, `p(x)<=1`. If `||f_x-f_y||<=h`, (3.3) implies `|x-t(y)|<=8h^2`, so its preimage in `C` has length at most `16h^2`. Thus, by the trace argument,

    P(X in C, ||f_X-f_Y||<=h) <=16D h^2.

Choose `h^2=M/(32D)`. At least `M/2` source probability in `C` has squared posterior distance exceeding `h^2`. Hence

    12e >= E||f_X-f_Y||^2 >= M^2/(64D),
    e >= 1/(49152D).                              (3.6)

The numerical constant is deliberately loose. This proves the desired exponent against the entire allowed memory class and for every `D`, without a Gaussian bridge or a finite-test inference.

### 3.3 Positive upper, including a sharper geometric grid

Store one symbol for `x in [0,1]` and one for each of `N` bins partitioning `[1,2]`; decode by sampling uniformly from the stored interval. Full bins are reproduced exactly for every `theta`. Only the bin containing the unknown support endpoint is partially filled.

For a bin `[l,u]` containing `theta`, its exact TV contribution is

    ((theta-l)(u-theta))/[(u-l)theta].             (3.7)

Uniform bins of width `1/N` therefore give `e<=1/(4N)` with `D=N+1`. All coordinates/grid boundaries can be rational in this order-optimal construction.

For geometric bins with `u/l=2^(1/N)`, maximizing (3.7) gives `theta=sqrt(lu)` and

    e <= tanh[(log 2)/(4N)]                       (3.8)

uniformly in `theta`. This is an upper for this particular positive code, not an asserted optimal constant. `D=1` is covered by a fixed output distribution and error at most 1.

### 3.4 A separate elementary linear-regret proof

The anchored-prior proof is not the only route. Under the purely continuous uniform prior on `[1,2]`, the posterior support begins at `t(X)=max(1,X)` and its continuous density is at least `1/(2log2)`. For actions `a in [1,2]`, the bounded loss

    L(theta,a)=1{a>theta}+(2-a)/4

has unique posterior Bayes action `a=t(X)` and conditional regret at least `|a-t(X)|/4`. Its range is `[0,5/4]`. TV preservation thus gives `E|t(Y)-t(X)|<=5e`; a central interval plus the POVM trace bound yields `Omega(1/D)`. This proof directly shows the hard support's linear decision penalty. It agrees with the Hilbert posterior proof and does not rely on applying differential entropy to a source with an atom.

Finite collections of endpoint hypotheses behave differently: partition at the finitely many distinct endpoints and uniformly resample within each cell. Their densities are constant per cell, so an exact finite classical memory exists. The continuum assumption in (3.1) is substantive, whereas N07's smooth Gaussian lower already follows from finitely many affinely independent hypotheses.

## 4. Endpoint boxes and mixed regular/nonregular products

For `r` independent endpoint observations, use the product anchored prior. It is often cleaner to sum the `r` marginal proper scores rather than use the full joint posterior density; the score range is then at most `12r`. The exact regret identity gives

    E sum_j ||f_(X_j)-f_(Y_j)||^2 <=12r e,

and the right-hand geometry is bounded below by `(1/8)sum_j|t(X_j)-t(Y_j)|`. On `C=[5/4,7/4]^r`, a posterior-radius-`h` preimage has volume `O_r(h^(2r))`. The trace cap yields

    e_D = Omega_r(D^(-1/r)).

Use `N+1` bins in each coordinate and tensor their decoders. There are `(N+1)^r` symbols; product-TV telescoping gives error at most `r/(4N)`. Taking the largest appropriate `N` proves

    e_D = Theta_r(D^(-1/r)).                      (4.1)

For the Gaussian/endpoint product, choose a finite affine-spanning Gaussian prior and the independent anchored endpoint priors. Sum Gaussian posterior-mean squared loss with the endpoint scores. Their bounded-loss comparison bounds

    E[ ||m_G(X)-m_G(Y)||^2
         + sum_j ||f_(Z_j)-f_(W_j)||^2 ] <= C e.  (4.2)

On a compact Gaussian source cube, its finite-prior posterior mean has a uniformly positive definite Jacobian (the conditional covariance of the prior means). Its small balls have volume `O(h^s)`. Each endpoint coordinate contributes `O(h^2)`. Hence (4.2)'s radius-`h` preimages have volume `O(h^(s+2r))`, and the same trace argument gives

    e_D >= c D^(-2/(s+2r)).                       (4.3)

For the upper, the N07 broad-reference positive-hat Gaussian construction, re-read at the source proof below, costs `O(epsilon^(-s/2))` classical symbols for error `epsilon`. Endpoint boxes cost `O(epsilon^-r)`. Their product code costs `O(epsilon^(-(s/2+r)))` symbols with total error at most a constant times `epsilon`. This matches (4.3). For a budget formulation, balance Gaussian and endpoint submemory dimensions at powers `s/(s+2r)` and `2r/(s+2r)` of total `D`.

The mixed theorem allows `s=0` or `r=0`, excluding `s+r=0`. Constants depend on the fixed Gaussian affine configuration and fixed coordinate counts. No uniform statement is claimed if those quantities collapse or grow with `D`. Marginal-law reconstruction is not preservation jointly with an external record.

## 5. Smooth non-Gaussian curved family: Fisher rank can mislead

On the known torus `T^r`, let

    p_t(x)=1+a sum_(j=1)^r t^j sin(2pi x_j),
    t in [0,1], 0<a<=1/(2r).                      (5.1)

This is a normalized periodic density bounded below by `1/2`. The parameter is a smooth one-dimensional curve; its ordinary scalar-parameter Fisher matrix has rank one wherever the score is nonzero. Nevertheless

    e_D = Theta(D^(-2/r)).                        (5.2)

For the lower, choose `r+1` distinct values of `t`, including zero, with positive prior weights. The vectors `(t,...,t^r)` affinely span `R^r` by the Vandermonde determinant. Posterior likelihood ratios therefore recover the vector of `sin(2pi x_j)` by a fixed invertible linear map. On `[-1/8,1/8]^r`, each sine has derivative bounded away from zero; the posterior map is bi-Lipschitz there. The finite posterior is bounded, and the general lemma with `kappa=r` gives the lower.

For the upper, tensor the positive periodic hats from N07 directly on the torus. The Markov operator cancels the first moment and satisfies

    ||R_h p-p||_1 <= (8/3) h^2 sum_j ||partial_jj p||_1.

The densities in (5.1) have uniformly bounded second derivatives, so `J^r` classical symbols give error `O(J^-2)`. This is a self-contained non-Gaussian use of the positive construction, with no tail compactification and no quantum comparison premise.

The fixed-experiment compression exponent concerns the observation's posterior statistic. It is not determined by the dimension of the parameter curve or by a single local Fisher tangent. Singular parameterizations, e.g. replacing `t` by `t^3`, do not themselves change an experiment's memory law if its set of source laws is unchanged. Genuine support changes, finite-alphabet sufficiency, or changes of the posterior measure do.

## 6. Primary literature and novelty boundary

The bounded live literature search covered finite statistical-experiment reduction/deficiency, posterior quantization, high-resolution Fisher loss, and 2024-2026 quantum/stochastic compression. Opened sources and decisive scopes:

- [Helmut Strasser, Towards a statistical theory of optimal quantization (2000), author manuscript](https://www.math4tune.com/publications/Strasser%202000,%20quantization%20Bock,%20article.pdf), sections 4-5 and Theorems 7-8: finite experiment reductions are quantizations of standard likelihood/posterior measures, evaluated through convex Bayes utilities. This makes the posterior-quantization viewpoint established. No endpoint quantum dimension rate was identified in the inspected theorem statements.
- [Klaus Poetzlberger, MSP-Partitions and Unbiased Quantizations: A Review of Results (Austrian Journal of Statistics 31, 2002)](https://www.ajs.or.at/index.php/ajs/article/download/vol31,%20no2&3%20-%208/426), section 3, Theorem 2: finite experiment quantizations and finite subfields/majorization are developed explicitly. This is a characterization, not the specific sharp TV memory law proved here.
- [Aolin Xu and Maxim Raginsky, Information-Theoretic Lower Bounds on Bayes Risk in Decentralized Estimation (2016)](https://arxiv.org/abs/1607.00550), PDF pages 5-7 and 11-12: Bayes-risk converses based on arbitrary distortion, small balls and information; absolute-error Shannon-type bounds already have the one-dimensional rate exponent needed by the tailored endpoint proof. Small-ball methods are not new here.
- [Farias and Brossier, Optimal Scalar Quantization for Parameter Estimation (2013)](https://arxiv.org/abs/1310.6945), introduction and asymptotic analysis: high-resolution scalar Fisher loss, score sensitivity, and unknown-parameter adaptive quantizer design. Its estimation/Fisher criterion differs from one-observation uniform-TV reconstruction through a quantum bottleneck.
- [Barnes, Han and Ozgur, A Geometric Characterization of Fisher Information from Quantized Samples (2018), author-university PDF](https://web.stanford.edu/~aozgur/FisherAllerton.pdf), introduction and stated geometric characterization: conditional score means control Fisher information after quantization, with applications to distributed estimation. This supports distinguishing local score geometry from full posterior geometry; it does not make the parameter-rank heuristic valid for our fixed experiment.
- [Yang, Florido-Llinas, Gu and Elliott, Dimension reduction in quantum sampling of stochastic processes (28 February 2025)](https://www.nature.com/articles/s41534-025-00978-2), framework and Theorem 1: known recurrent q-sample/MPS representations are truncated under fidelity-divergence-rate error. It is an important nearby quantum advantage but a different interface, target and metric; it does not contradict these no-exponent-advantage results.
- [Moussa et al., Information-Preserving and Model-Aware Voronoi Dequantization of Weighted Discrete Laws (September 2026 preprint)](https://www.preprints.org/manuscript/202609.0234), Theorem 3.2 and discussion: supplied finite laws with partition-respecting dequantization are exactly Blackwell equivalent. This confirms why finite endpoint grids can be exactly decoded; it starts from finite discrete weights and does not settle unknown continuous endpoint compression.

The 2025 stochastic-process identifiability paper [arXiv:2509.03004](https://arxiv.org/abs/2509.03004) was opened for scope, but its abstract concerns exact generative-process minimality; it was not used as a proof ingredient. Search dates and crawler timestamps were not treated as paper publication dates.

**Novelty assessment:** no exact primary antecedent for the arbitrary-quantum endpoint or mixed-product TV law was located in this bounded search. This is not historical clearance. The result is plausibly a short synthesis of classical decision quantization and a dimension-trace converse; a standalone breakthrough claim would be premature. A stronger contribution would be a broad necessary-and-sufficient compression theorem, sharp constants/quantum separation, or a consequential transfer to a source experiment with genuinely nonregular sufficient statistics.

## 7. Source paths and scrutiny of N07

Read:

- `work/astra-research-knowledge/00_START_HERE.txt`
- `work/astra-research-knowledge/01_CORE.txt`
- `work/astra-research-knowledge/cards/N07-gaussian-memory.txt`
- `work/astra-research-knowledge/cards/N08-block-critical-gaussian.txt`
- `work/astra-research-knowledge/web/pages/d-7bf3825bbd159ebb.html` (exact supplied `updates/L/package/work/critical_gaussian_audit.md`)
- `work/astra-research-knowledge/web/pages/d-4fac7348c6e10e91.html` (exact supplied `updates/L/package/work/gaussian_memory_prior.md`)

The N07 finite-prior posterior-risk identity, covariance Jacobian, seed-conditioned POVM trace argument, and positive periodic-hat construction were re-read, not accepted solely from the card. Their transfer does not require the separately inherited quantum Gaussian bridge. The scope of N08's iid transfer remains conditional on that bridge and limited above its additive error remainder. Neither new endpoint result resolves that bridge.

Prior memory was used only to locate the candidate-status/audit conventions; all mathematical claims here were checked from the current source/proofs or derived above. Relevant memory registry: `MEMORY.md:44-97`, prior rollout id `01a1121a-4750-72f0-8f5c-b501038890d3`.

## 8. Fatal tests and strongest next question

Fatal tests for this route:

1. Uncharged input-dependent records or entanglement assistance invalidate the trace-`D` cap. Public classical seeds are harmless only because they are independent and each seed's dimension is charged.
2. Dropping the `theta=2` atom from the anchored posterior loses normalization and boundedness near `x=2`. Treating the `x<=1` posterior atom as a continuous chart is incorrect; the converse uses an explicit interior region.
3. A finite parameter grid does not retain the endpoint continuum lower. Conversely, a small parameter manifold does not imply a small observation posterior dimension in smooth curved families.
4. A posterior lower bound alone does not imply a TV upper. Cusp densities or fractal posterior maps may have different positive approximation obstructions. The general classification remains incomplete.
5. Fisher loss, Wasserstein reconstruction, atom-valued source quantization, and uniform-TV experiment reconstruction are different criteria. An atomic output gives TV one against a non-atomic source unless the decoder supplies fresh continuous randomness.

**Strongest next technical question:** characterize when an experiment admits a positive finite-dimensional self-reconstruction kernel with error comparable to its LOCAL BOUNDED DECISION regret-volume complexity, uniformly over every source law. Section 9 resolves the previously suggested tapered-support test: for `0<beta<1/2`, the Brier posterior geometry gives a weaker converse than a bounded scale-dependent hinge score. Thus a classification based solely on a fixed squared posterior Hilbert metric is not justified.

Expected value: high for a scoped theorem/counterexample package, moderate for a major foundational result. The immediate exact law is useful and reviewable; novelty and a universal classification remain unresolved.

Scoped numerical diagnostics were executed with `work/scouts/statistical_geometry_checks.py`; exact saved outputs are in `work/scouts/statistical_geometry_checks.json`. They check the finite-interval hat normalizer, hinge Bregman orientation, and the specified code at `beta=0,1/4,3/4,1,2`, knot counts 16 through 256. All tested hinge regrets exceed the analytic strip lower (minimum ratio about 3.94); source/decoded quadrature masses agree to numerical precision. Observed final doubling slopes were about 1.02, 1.28, 1.74, 2.00, 1.99. These are finite diagnostics of formulas/constructions, not a proof of the exponents or a scientific validation upgrade.

## 9. Tapered support edges: a continuum of sharp precision exponents

This section was derived after the initial report. Status remains internally derived / external correctness and historical priority unresolved. A separate agent has been given the construction for independent scrutiny; agreement is not proof.

**Candidate theorem.** Fix `beta>=0` and consider one draw from

    q_theta(x)=(beta+1)(theta-x)^beta/theta^(beta+1),
    0<=x<=theta, theta in [1,2].                   (9.1)

For `beta=0`, use the usual uniform density, with endpoint point values assigned arbitrarily. In the entire memory interface of section 1,

    e_D = Theta_beta(D^(-q)), q=min(beta+1,2).     (9.2)

The endpoints do not jump when `beta>0`; nevertheless, every `0<beta<1` still has a slower precision rate than a regular smooth experiment. This is a quantitative support singularity effect, not a bad parameterization or a Fisher-rank effect.

### 9.1 A bounded anchored posterior

Use `pi=(1/2)Uniform[1,2]+(1/2)delta_2` as before, with predictive density `p_beta(x)`. For `0<=x<2`,

    f_x(theta)=q_theta(x)/p_beta(x).

The predictive density obeys `p_beta(x)<=beta+1` and `p_beta(x)>=q_2(x)/2`. Whenever `x<=theta<=2`,

    q_theta(x)/q_2(x)
      =[2/theta]^(beta+1)[(theta-x)/(2-x)]^beta
      <=2^(beta+1).

Hence `0<=f_x<=K_beta=2^(beta+2)`. Extend decoder outputs by `y'=min(2,max(0,y))`. At `y'=2`, assign posterior density 2 on the atom and 0 on the continuous part. This is the limiting normalized posterior. For positive `beta`, observations below 1 no longer give a constant posterior, so the uniform case's `max(1,y)` reduction MUST NOT be reused.

Take `C=[5/4,7/4]`. On this region,

    P(X in C) >= M_beta=(beta+1)2^(-(3beta+3))>0.  (9.3)

This lower bound follows using only the prior atom's half-weight, the interval's length `1/2`, and `2-x>=1/4`. When `theta>=y'`, we also have the useful pointwise lower bound

    f_(y')(theta) >= 2^(-(beta+1))(theta-y')^beta.  (9.4)

Indeed `theta^(beta+1)<=2^(beta+1)` and `p_beta(y')<=beta+1`.

### 9.2 A scale-dependent hinge proper score

For a scale `0<h<=1/8`, set

    lambda_h = 2^(-(beta+2))(h/2)^beta <=1/4,
    phi_h(z)=(z-lambda_h)_+,
    g_h(z)=1{z>lambda_h}.

For a posterior-density action `a`, define the score

    S_h(theta,a)
      = integral [a g_h(a)-phi_h(a)] d pi - g_h(a(theta))
      = lambda_h pi{a>lambda_h}-1{a(theta)>lambda_h}. (9.5)

It lies in `[-1,lambda_h]`, uniformly in `h` and the memory dimension. Convexity makes the original posterior a Bayes action, and direct conditioning gives the exact nonnegative regret identity

    E[S_h(Theta,f_Y)-S_h(Theta,f_X)]
      = E integral B_(phi_h)(f_X(theta),f_Y(theta)) d pi(theta),

where `B_phi(u,v)=phi(u)-phi(v)-g(v)(u-v)`. Consequently rowwise TV preservation bounds this expected regret by

    (1+lambda_h)e <=(5/4)e.                       (9.6)

The score may depend on the chosen resolution `h`; its bounded range does not. This is permitted because each lower bound may choose its own bounded decision problem. It is precisely why one fixed quadratic score can miss the optimal rate.

Fix source `x in C`. If `y'>=x+h`, use the parameter strip

    I=[x+h/2,x+3h/4].

Its prior mass is `h/8`. There `f_y=0` while (9.4) gives `f_x>=2lambda_h`, so the pointwise Bregman regret is `f_x-lambda_h>=lambda_h`.

If `y'<=x-h`, use instead

    I=[x-h/2,x-h/4].

There `f_x=0` while `f_y>=2lambda_h`, so the pointwise regret is exactly `lambda_h`. These strips are contained in the continuous parameter interval `[1,2]`; the central chart and `h<=1/8` guarantee this. Thus either direction of displacement gives

    integral B_(phi_h)(f_x,f_y) d pi
      >=lambda_h h/8 when |x-y'|>=h.              (9.7)

The decoder's arbitrary output outside the physical support causes no escape: its clipped posterior action still lies on the correct side and (9.7) applies.

### 9.3 Quantum/hybrid converse and the saturation at exponent 2

The coordinate small-ball event obeys, at each seed and hence after averaging,

    P(X in C, |X-y'|<=h) <=2(beta+1)D h.           (9.8)

This again follows from `omega_x<=I` and `Tr F(total)<=D`; it does not use the rank of a reconstructed density family. Choose

    h=M_beta/[4(beta+1)D] <=1/32.

At least `M_beta/2` mass in `C` then has coordinate displacement larger than `h`. Combining (9.6)-(9.7) gives an explicit positive constant

    e >=(M_beta/20) lambda_h h
      = c_beta D^(-(beta+1)).                    (9.9)

For `0<=beta<=1`, this is the claimed exponent. For `beta>1`, a binary prior on `theta=1,2` gives the stronger quadratic converse. On `x in [1/4,3/4]`, both densities are positive and the likelihood ratio is

    q_1(x)/q_2(x)=2^(beta+1)[(1-x)/(2-x)]^beta.

It has a nonzero derivative for every fixed `beta>0`. The bounded binary posterior map is therefore bi-Lipschitz on this compact interval; section 2 gives `Omega(D^-2)`. Combining this with (9.9) gives the lower with exponent `min(beta+1,2)`.

### 9.4 Positive finite-interval hats give the matching upper

Partition `[0,2]` with `N+1` equally spaced knots and `h=2/N`. Let `a_k` be the ordinary piecewise-linear hat functions, including half-hats at the two endpoints. They satisfy `sum a_k=1`; their masses are `w_k=h` in the interior and `w_0=w_N=h/2`. Encode label `k` with probability `a_k(x)` and decode with density `a_k(y)/w_k`. The resulting kernel

    K_h(x,y)=sum_k a_k(x)a_k(y)/w_k

is positive, symmetric and Markov in both variables, has support `|x-y|<=2h`, and cancels the first displacement moment for `y in [h,2-h]`. It uses exactly `D=N+1` classical symbols. The endpoint half-hats are essential: periodically extending (9.1) across `x=0` would introduce a false jump and only certify an `O(h)` bound.

For `0<beta<1`, split the L1 error into three parts, uniformly over `theta in [1,2]`:

1. Within distance `3h` of the moving support endpoint, both source and decoded density are `O_beta(h^beta)` by locality. The region has length `O(h)`, so its contribution is `O_beta(h^(beta+1))`.
2. On `y in [h,theta-3h]`, first-moment cancellation and Taylor's formula give a pointwise bound by `C_beta h^2(theta-y-2h)^(beta-2)`. Integrating up to distance `h` from the singularity gives `O_beta(h^(beta+1))`.
3. At the fixed boundary `y<h`, the density is uniformly Lipschitz because `theta>=1`. Locality gives error `O_beta(h)` on a region of length `h`, hence `O_beta(h^2)`. At the right boundary, the density and output are zero or are already in the moving-edge region.

Points more than `2h` to the right of `theta` have exactly zero source and output density. For `h` bounded away from zero, the trivial TV bound one supplies the remaining small memory dimensions. Consequently

    sup_theta TV(R_h q_theta,q_theta)=O_beta(h^(beta+1)),
    0<beta<1.                                    (9.10)

For `beta=0`, the same edge-strip argument or exact interval-bin code gives `O(h)`. For `beta=1`, the density is piecewise affine and only the edge/boundary regions contribute `O(h^2)`. For `beta>1`, the second derivative inside the support is integrable with uniformly bounded L1 norm, giving `O_beta(h^2)` by the same kernel/Taylor argument; the edge strip is `O(h^(beta+1))` and thus smaller. This proves the matching upper in (9.2).

### 9.5 Why a fixed Brier metric is incomplete

For `0<beta<1/2`, the continuum posterior's squared L2 displacement near an interior endpoint is of order

    ||f_x-f_(x+h)||^2 ~ h^(2beta+1).

The disappearing parameter strip contributes this power, and integration of the overlapping density derivatives has the same order. Its quadratic-score converse is only `Omega(D^(-(2beta+1)))`, while the bounded hinge construction and positive hats match at the strictly slower error rate `D^(-(beta+1))`. A posterior Hilbert dimension is a useful converse tool, but the full TV deficiency sees scale-dependent bounded decision problems beyond that one score. At `beta=1/2` the quadratic metric has a logarithmic borderline; it still does not determine the sharp `D^-3/2` rate.

This is a decisive limitation of the proposed fixed-Hilbert classification, not a counterexample to the general regret-volume trace theorem. The viable broader principle is local bounded Bayes-regret volume paired with positive L1 reconstruction regularity.

### 9.6 Anisotropic product extension

For finitely many independent tapered endpoints with fixed exponents `beta_j`, let `q_j=min(beta_j+1,2)`, and include `s` Gaussian coordinates if desired. The same proof gives the candidate exact law

    a=s/2+sum_j 1/q_j,
    e_D=Theta(D^(-1/a)),
    log_2 D_opt(epsilon)=a log_2(1/epsilon)+O(1).   (9.11)

For the lower choose coordinate scales `h_j ~ epsilon^(1/q_j)`, Gaussian posterior radius `~sqrt(epsilon)`, and sum the appropriate bounded scores (hinges for `beta_j<=1`, quadratic finite-prior scores for `beta_j>1`). Outside the resulting source-centered rectangle/ellipsoid at least one conditional regret is `Omega(epsilon)`. The trace cap bounds its near-reconstruction probability by `C D epsilon^a`. Choose `epsilon~D^-1/a`. The product positive codes cost `O(epsilon^-a)` and have total TV error `O(epsilon)`, proving the upper. Constants are fixed-family constants; growing dimension, varying taper exponents, or collapsing parameter domains need a new analysis.
