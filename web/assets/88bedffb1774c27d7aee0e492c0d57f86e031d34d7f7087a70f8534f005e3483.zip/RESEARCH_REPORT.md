# A quartic resource law for lossy two-fermion inputs
## Gaussian completion, optimal concentration, and classical simulation

**Research checkpoint, 7 October 2026.** AI-assisted derivation; not externally reviewed or formally certified. Mathematical proofs, executable floating-point prototypes, exact identities, numerical checks, and unresolved interfaces are distinguished below. Priority remains unresolved. The main theorems do **not** depend on the new OpenAI mathematical manuscripts or the Chen–Liu counting theorem. A downstream error-correction corollary explicitly imports Tang et al., Theorem 2 [S6]. No claim of a field-breaking discovery is made solely on the strength of this checkpoint.

Astra prior state was read at commit `89bd24d151f8ff240958cc75ad454e415a991dc2`, beginning with `00_START_HERE.txt` and `01_CORE.txt`. The existing parity-counting and positive-kernel results motivated the search but are not premises of the results below. The repository was not modified. This folder is the new resumable state.

## 1. Principal results and the access model

Let \(\mathcal C_G\) be the convex hull of pure fermionic Gaussian states, allowing both parity sectors. Use trace distance \(T(\rho,\sigma)=\frac12\|\rho-\sigma\|_1\). A state in \(\mathcal C_G\) need not itself be Gaussian: the classical label of its Gaussian component is retained by the simulator. Fermionic Gaussian operations include quadratic unitaries, Gaussian ancillary states, Gaussian loss, occupation measurements, classical feedforward, and discarding modes. Each fine-grained branch preserves the Gaussian class; coarse-graining preserves its convex hull [S3–S5].

The input consists of independent blocks, each initially containing exactly two fermions in an explicitly described state. Each mode of block \(i\) undergoes independent vacuum loss with **particle survival probability** \(\eta_i\), not survival amplitude. The environment and its loss record are discarded. Subsequent processing is an explicitly supplied polynomial-size Gaussian protocol. Uniform loss after a passive interferometer can be moved to the inputs. This commutation does not hold for arbitrary active Gaussian dynamics.

The main results obtained in this run are:

**Theorem A, arbitrary two-fermion completion.** Every pure two-fermion block has an explicit, polynomial-description convex-Gaussian approximant \(\sigma_i\) satisfying
\[
T(\rho_i,\sigma_i)=\delta_i\le
\frac{\eta_i^4}{2(1-\eta_i)^2},\qquad 0\le\eta_i<1.
\]
An exact root formula for \(\delta_i\) is given below. The total state error is exactly \(1-\prod_i(1-\delta_i)\) for these sector-faithful completions. Consequently, the full output distribution of any such Gaussian protocol can be sampled to total-variation error at most \(\sum_i\delta_i+\zeta\), where \(\zeta\) is a separately charged arithmetic/simulation error.

For equal transmissions, a sufficient full-sampling regime is \(n\eta^4=O(\epsilon)\) at fixed \(\eta\le\eta_0<1\). The expected number of survivors is \(2n\eta\), so the regime includes \(O(\epsilon^{1/4}n^{3/4})\) survivors. No sparsity or weak-mixing property of the interferometer is assumed. The dense covariance implementation has \(O(M^3)\) arithmetic work and \(O(M^2)\) memory per final-occupation sample, after input acquisition. General adaptive protocols additionally charge their gate count and classical controller.

**Theorem B, sharp local geometry.** For
\[
|\phi\rangle=(|1100\rangle+|0011\rangle)/\sqrt2,
\quad a=(1-\eta)^2,\quad b=\eta^2,
\]
the exact distance of its lossy state to \(\mathcal C_G\) is
\[
d_G(\rho_\eta)=
\begin{cases}
(\sqrt{a+b}-\sqrt a)^2,&b\le3a,\\
(b-a)/2,&b\ge3a.
\end{cases}\tag{1}
\]
Both the standard and generalized convex-Gaussian robustness are exactly
\[
R_G(\rho_\eta)=
\begin{cases}
b^2/(4a),&b\le2a,\\
b-a,&b\ge2a.
\end{cases}\tag{2}
\]
The expressions at \(\eta=0,1\) are interpreted continuously. Thus both quantities are asymptotic to \(\eta^4/4\) as \(\eta\to0\). This establishes a sharp *single-block Gaussian resource exponent*, not an optimal threshold for every possible classical simulation algorithm.

**Theorem C, optimal Gaussian concentration.** Let \(0<\eta\le q\le\sqrt2/(1+\sqrt2)\). There is a four-mode Gaussian filtering protocol converting \(\rho_\eta\) exactly to \(\rho_q\) with success probability
\[
p_* =\frac{\eta^4(1-q)^2}{q^4(1-\eta)^2}
=\frac{R_G(\rho_\eta)}{R_G(\rho_q)}.\tag{3}
\]
No trace-nonincreasing operation that preserves \(\mathcal C_G\) on each branch can have greater one-copy success probability. The protocol's failure branches are convex-Gaussian. For fixed target quality \(q>0\), the required number of independent attempts scales as \(\Theta(\eta^{-4})\). Even collective Gaussian processing of many inputs cannot improve that exponent for constant success probability and fixed target quality.

**Theorem D, signed estimation.** For standard magic blocks, bounded efficiently computable functions of the output can be estimated with exact-arithmetic sampling cost
\[
O\!\left(\Gamma^2\epsilon^{-2}\log(2/\alpha)\right),
\qquad \Gamma=\prod_i(1+2R_G(\rho_{\eta_i})).\tag{4}
\]
This is polynomial when \(\sum_i\eta_i^4=O(\log M)\), for transmissions bounded away from one, including inverse-polynomial additive accuracy. This larger logarithmic regime is an **estimation theorem**, not a full-distribution sampling theorem.

## 2. What is inherited and what appears to change

Gaussian-state propagation and occupation sampling are established tools [S3–S5]. Four-mode convex-Gaussian geometry, antiunitary concurrence, Gaussian extent, and quasiprobability simulation are also established [S3,S4,S7]. Neither the term “magic” nor the idea of a Gaussian decomposition is a contribution here.

Heo, Park, and Oh [S1], Theorem 5, give polynomial-time sampling for standard particle-loss magic inputs when transmission is \(O(\sqrt{\log M/n})\), with inverse-polynomial or larger total-variation tolerance. Their explicit loss decomposition has a quadratic-transmission exponent. Their dephasing theorem has a fourth-order parameter, but it concerns **dephasing**, not particle survival. The comparison in this checkpoint is with their particle-loss theorem, not their dephasing result. Their discussion explicitly leaves improved input ensembles open.

The present positive-mixture construction instead pays fourth order in particle survival for *full-distribution error*, and covers arbitrary explicitly described two-fermion blocks. At fixed tolerance, the survivor exponent changes from the square-root/logarithmic sufficient regime in [S1] to three quarters. Accuracy regimes must not be conflated: our positive-mixture error grows as \(n\eta^4\); it is not an arbitrary-accuracy sampler at fixed parameters. Equation (4) separately supplies inverse-polynomial-accuracy estimation in a fourth-order logarithmic regime.

The September paper on exact free-fermion dynamics with magic inputs [S2] supplied an important representation prompt: particle-loss structure can be treated at the source rather than inside an exponentially large many-body state. Its exact instrument method does not itself give the completion theorem proved here. The April paper [S9] includes arbitrary canonical two-fermion blocks, but its reported additive simulation interfaces are not this loss-dependent full-distribution theorem.

The candidate new content is the normalized positive completion, its exact local distance and robustness witnesses, the optimal concentration protocol, and their combined algorithmic/resource consequences. The elementary ingredients overlap strongly with known Gaussian and convex-resource techniques; a specialist priority audit may identify previously published versions or consequences. This report does not certify novelty.

## 3. Loss of a canonical two-form

Any normalized pure two-fermion state has a passive canonical decomposition
\[
|\psi\rangle=\sum_{j=1}^r s_j p_j^\dagger|0\rangle,
\quad p_j^\dagger=a_{2j-1}^\dagger a_{2j}^\dagger,
\quad \sum_j|s_j|^2=1.\tag{5}
\]
The orbital transformation is a finite antisymmetric-matrix/Youla decomposition. A general two-form on \(m\) modes has only \(\binom m2\) coefficients; no exponentially sized input description is assumed. The delivered prototype acquires this decomposition numerically and reports reconstruction error.

Let \(P_\psi=|\psi\rangle\langle\psi|\), \(P_0=|0\rangle\langle0|\), and let \(P_j\) denote the one-particle projector in orbital \(j\). Independent unobserved loss gives
\[
\rho_\eta=aP_0+B_1+bP_\psi,
\quad B_1=\eta(1-\eta)\sum_j|s_j|^2(P_{2j-1}+P_{2j}),\tag{6}
\]
where \(a=(1-\eta)^2\), \(b=\eta^2\). Equation (6) follows directly by tracing the environment in the fermionic beam-splitter loss isometry. In a noncanonical basis, the one-particle block is \(\eta(1-\eta)AA^\dagger\), with \(A\) the normalized skew matrix. Fermionic signs must be retained; ordinary tensor-product qubit amplitude damping is not silently substituted for physical fermionic loss.

## 4. Normalized Gaussian completion

Put \(w_j=|s_j|^2\) and \(P(x)=\prod_j(1+xw_j)\). There is a unique \(x\ge0\) satisfying
\[
P(x)=1+b/a,\qquad a>0.\tag{7}
\]
For \(\theta_\ell=2\pi\ell/(r+1)\), define the normalized pure Gaussian states
\[
|G_\ell(x)\rangle=P(x)^{-1/2}
\prod_{j=1}^r(1+\sqrt{x}\,s_j e^{i\theta_\ell}p_j^\dagger)|0\rangle.
\tag{8}
\]
There are \(r+1\) phases, not exponentially many components. Expanding by pair number \(k\in\{0,\ldots,r\}\), the finite phase average cancels every cross term with different pair numbers because \(|k-k'|<r+1\). The two-fermion ray is preserved.

Define
\[
\sigma_\eta=B_1+\frac{a+b}{r+1}\sum_{\ell=0}^rP_{G_\ell(x)}.\tag{9}
\]
The coefficient \((a+b)/P(x)=a\) makes the vacuum weight exactly \(a\). The two-fermion block is \(axP_\psi\), and the sectors of four or more fermions have a positive total remainder \(R_{\ge4}\). Hence
\[
\sigma_\eta=\rho_\eta-\delta P_\psi+R_{\ge4},
\quad \delta=b-ax=\operatorname{Tr}R_{\ge4}.\tag{10}
\]
The negative and positive differences have orthogonal particle-number supports, proving \(T(\rho_\eta,\sigma_\eta)=\delta\). Every component of (9) is Gaussian: the one-particle terms are Slater determinants and (8) is a BCS product.

Since \(P(x)\ge1+x\) and \(P(x)\le e^x\),
\[
\log(1+b/a)\le x\le b/a.
\]
Thus
\[
0\le\delta\le b-a\log(1+b/a)\le b^2/(2a),\tag{11}
\]
where the last inequality follows by integrating \(t/(1+t)\le t\). More precisely, with \(e_2=\sum_{j<k}w_jw_k\),
\[
\delta=e_2 b^2/a+O(b^3/a^2),\qquad
 e_2=(1-\sum_jw_j^2)/2.\tag{12}
\]
For rank one, \(x=b/a\) and the approximation is exact: a lossy Slater determinant is already Gaussian.

**Why the power is four.** Deleting the entire coherent two-particle sector costs order \(b=\eta^2\). Instead, the construction incorporates that sector into a Gaussian pairing state. The missing higher sector then has weight quadratic in \(b\), namely order \(\eta^4\). The Gaussian mixture is allowed to have a small artificial four-particle tail; insisting on exactly the original particle-number support would destroy this mechanism.

### Mixed inputs and low-sector extension

For an explicitly supplied mixed two-particle input, diagonalize its \(\binom m2\)-dimensional density matrix and apply (9) to each eigenvector. Loss and convex mixing are linear, and the error bound (11) persists. This is a polynomial acquisition statement, not access to an arbitrary many-body state oracle.

More generally, for any block-diagonal state \(aP_0+B_1+D_2\) supported on zero, one, and two particles, with \(a>0\) and \(b=\operatorname{Tr}D_2\), allocate vacuum weight proportionally to the eigenvalues of \(D_2\). Applying the same construction gives a convex-Gaussian state with trace error at most \(b-a\log(1+b/a)\). These mixed extensions are proved here but not separately implemented in the delivered sampler.

## 5. Tensorization, loss certificates, and the full sampler

For the completion (10), let \(Q\) be the projector onto the original support. Then \(Q\sigma Q\le\rho\), and \(\operatorname{Tr}Q\sigma=1-\delta\). Outside that support, \(\rho\) vanishes and \(\sigma\) has mass \(\delta\). Tensoring therefore yields
\[
T(\otimes_i\rho_i,\otimes_i\sigma_i)
=1-\prod_i(1-\delta_i).\tag{13}
\]
This exact identity concerns the sector-faithful construction, including the low-transmission branch of (1). The globally closest high-transmission four-mode construction in Section 6 redistributes vacuum weight too; for that construction the same product expression is an upper bound from commuting-state couplings, not an asserted equality.

A complete adaptive Gaussian protocol, including its entire classical transcript, is a channel. Trace distance contracts, and applying the output measurement gives the total-variation bound. Simulate (9) by drawing a Gaussian label independently for each block, combining covariances, and running standard Gaussian propagation and conditional occupation sampling [S3–S5]. The classical mixture has exponentially many joint labels, but drawing a label and processing one covariance matrix is polynomial. No explicit expansion of all labels is performed.

For nonuniform passive loss, an acquired sufficient certificate is available. Let the device transfer matrix be \(T\). Supply block scalars \(\eta_i>0\) with
\[
T^\dagger T\preceq D^2,\qquad D=\bigoplus_i\sqrt{\eta_i}I_i.
\tag{14}
\]
Then \(S=TD^{-1}\) is a contraction and the vacuum-loss channel factors as \(\mathcal L_T=\mathcal L_S\circ\mathcal L_D\). Apply the block completion to \(\mathcal L_D\), then simulate \(S\). Checking (14) is finite matrix computation; for rational squared parameters it is an exact PSD feasibility check with charged precision. No claim that uniform attenuation can be commuted through arbitrary active circuits is made. Zero blocks can be removed when the corresponding columns of \(T\) vanish.

### Numerical and bit costs

The root in (7) is monotone and can be found by bisection using log-products. Its binary magnitude is controlled by the input bit length, including \(\log(1/a)\); a small vacuum weight is not a free number. Phase discretization uses only \(r+1\) labels. Orbital decompositions, covariance formation, and Gaussian propagation are explicit finite-matrix operations.

For a fully finite-bit algorithm, one may compile each sampled Gaussian component into polynomially many Gaussian rotations, approximating the prepared component to trace error \(\zeta_0\). State preparation through a polynomial rotation circuit controls error without an inverse spectral-gap promise for the orbital basis. Nearly degenerate orbitals need not be distinguished beyond the requested state accuracy. Tiny discarded singular components must be included in the state-error budget.

The covariance measurement recursion divides by conditional probabilities. It is not valid to claim uniform stability in fixed precision. A conservative finite-bit repair omits branches with conditional probability below \(\kappa\), paying at most \(L\kappa\) over \(L\) measurements. On retained branches denominators are at least \(\kappa\). Iterated rational update sensitivity grows at worst exponentially in \(L\log(1/\kappa)\), which requires only polynomially many *precision bits*, not an exponential number of bits. Allocating \(\kappa=O(\zeta/L)\), guard margins, and a polynomial bit budget gives a finite-bit route with separately charged \(\zeta\). A fully optimized interval compiler is not supplied.

The code is deliberately labeled a **floating-point prototype**. Its reported state bounds are numerical evaluations of symbolic bounds, not outward-rounded software certificates. An adversarial small-transmission diagnostic exposed covariance overshoot at a rare terminal branch; this is retained in the failure ledger, not hidden by calling the implementation certified.

## 6. Sharp four-mode distance

For the balanced state, \(\rho_\eta=aP_0+B_1+bP_\phi\). Write \(P_4=|1111\rangle\langle1111|\) and let \(\Pi_2\) project onto the six-dimensional two-particle sector.

For any \(t>0\), define
\[
W_t=P_\phi-\tfrac12\Pi_2-tP_0-\frac1{4t}P_4.\tag{15}
\]
We claim that \(\operatorname{Tr}(W_t\sigma)\le0\) for every \(\sigma\in\mathcal C_G\).

To prove this, write the amplitudes of an even pure Gaussian as \(c_0,c_{ij},c_4\). The four-mode Gaussian Plücker relation is
\[
c_0c_4=c_{12}c_{34}-c_{13}c_{24}+c_{14}c_{23}.\tag{16}
\]
It holds on the dense vacuum chart by expansion of the Gaussian exponential, and extends to all Gaussian states by continuity. Directly,
\[
\langle P_\phi-\tfrac12\Pi_2\rangle
=\operatorname{Re}(\bar c_{12}c_{34})
-\tfrac12(|c_{13}|^2+|c_{14}|^2+|c_{23}|^2+|c_{24}|^2)
\le |c_0c_4|.
\]
The last inequality uses (16), the triangle inequality, and \(2|uv|\le|u|^2+|v|^2\). Finally,
\[
|c_0c_4|-t|c_0|^2-|c_4|^2/(4t)\le0.
\]
Odd Gaussian states give zero expectation because (15) has support only on even sectors. Convexity proves the claim.

For \(0<t\le1/2\), the maximum eigenvalue of \(W_t\) is \(1/2\), the minimum is \(-1/(4t)\), and
\[
T(\rho_\eta,\sigma)\ge
\frac{b/2-at}{1/2+1/(4t)}.\tag{17}
\]
This follows from the spectral-range trace-distance inequality and \(\operatorname{Tr}W_t\sigma\le0\).

When \(b\le3a\), set \(t=(\sqrt{1+b/a}-1)/2\). Equation (17) equals the first branch of (1). The normalized completion has exactly that error: its coefficients satisfy \(b-\delta=2\sqrt{a\delta}\). When \(b\ge3a\), choose \(t=1/2\). A three-phase BCS mixture with unchanged one-particle terms and even weights
\[
\text{vacuum}: (a+b)/4,\quad
P_\phi:(a+b)/2,\quad
P_4:(a+b)/4
\]
is convex-Gaussian and has distance \((b-a)/2\). This matches (17), proving both branches globally over all \(\mathcal C_G\), not just the chosen ansatz.

## 7. Exact robustness and a signed Gaussian compiler

Define generalized robustness by
\[
R_{\rm gen}(\rho)=\inf\{s\ge0:(\rho+s\tau)/(1+s)\in\mathcal C_G,\ \tau\text{ any state}\}.
\]
Standard robustness restricts \(\tau\in\mathcal C_G\). The lower bound below applies to the generalized quantity; the upper bound uses Gaussian noise, so the two agree.

For \(t\le1/2\), \(4tW_t\succeq-I\). If \((\rho+s\tau)/(1+s)\) is free, then
\[
s\ge\operatorname{Tr}(4tW_t\rho_\eta)=2bt-4at^2.
\]
Optimization at \(t=\min\{b/(4a),1/2\}\) gives (2).

For \(b\le2a\), put \(R=b^2/(4a)\). Adding \(RP_4\) gives a Gaussian phase average: its even weights are \(a,b,R\), with \(b=2\sqrt{aR}\). The odd one-particle terms remain unchanged. For \(b\ge2a\), add
\[
(b/2-a)P_0+(b/2)P_4.
\]
Its trace is \(R=b-a\), and the resulting even weights are \(b/2,b,b/2\), again an explicit three-phase BCS average. The added noise is a Gaussian mixture in both cases. Thus
\[
\rho_\eta=(1+R)\sigma_+-R\tau,
\quad \sigma_+,\tau\in\mathcal C_G,
\quad \rho_\eta\preceq(1+R)\sigma_+.\tag{18}
\]

For independent blocks, select positive/negative components with probabilities proportional to their absolute coefficients. The absolute signed mass is \(\Gamma=\prod_i(1+2R_i)\). Run the Gaussian output sampler and return \(Y=\Gamma\,s\,f(X)\), where \(s\in\{-1,1\}\) is the product sign and \(|f|\le1\). Then \(\mathbb EY\) is the target expectation and \(|Y|\le\Gamma\). Hoeffding's inequality proves (4). This method is implemented in `code/gaussian_robustness.py` and checked against complete small-system output laws.

**Do not convert (4) into full sampling without a new argument.** Signed samples do not directly become positive samples of the target distribution. Estimating rare conditional output probabilities to the relative accuracy needed for naive sequential sampling could reintroduce exponential cost.

### Rank-two, unbalanced extension

For \(\eta<1\), the robustness calculation extends to \(|\psi\rangle=s_1|1100\rangle+s_2|0011\rangle\), with endpoint values defined continuously. Put \(B=b|s_1s_2|\). Then
\[
R_{\rm gen}(\rho_\eta)=R_{\rm std}(\rho_\eta)=
\begin{cases}B^2/a,&B\le a,\\2B-a,&B\ge a.\end{cases}\tag{19}
\]
Gauge the relative phase away. Replace the first part of (15) by
\(\frac12(|1100\rangle\langle0011|+\mathrm{h.c.})\) minus half the projector onto the other four two-particle basis states. The same Plücker proof and spectral bounds apply, and its target expectation is \(B-at\). Optimize \(4Bt-4at^2\). For the upper bound add \((B^2/a)P_4\) in the first regime; in the second add \((B-a)P_0+BP_4\). The preserved two-particle ray and the relation between vacuum/full weights again give a BCS phase average. This extension is a written derivation; the delivered robustness compiler and its dedicated numerical checks specialize to balanced inputs.

## 8. Optimal Gaussian concentration and the matching resource law

Take \(0<\eta\le q\) and set
\[
s=\frac{\eta(1-q)}{q(1-\eta)}\le1.
\]
On each of the four modes apply the successful Kraus operator
\[
K_s=\sqrt{s}|0\rangle\langle0|+|1\rangle\langle1|.
\]
It is a Gaussian filter. One realization mixes the mode with an occupied Gaussian ancillary mode on a beam splitter and conditions on the ancilla remaining occupied. The other outcome has Kraus operator proportional to \(|0\rangle\langle0|\). Both outcomes are Gaussian operations. Each attempt uses at most four occupied Gaussian ancillary modes and four measurements; their preparation, hardware, and energy are not asserted to be free in a physical cost model. "Free" here means free of non-Gaussian resources. Repetition charges these ancillary and measurement costs along with the raw input attempts.

All four successes produce \(K=s^{(4-\hat N)/2}\). Therefore the vacuum, one-particle, and two-particle weights in (6) are multiplied by \(s^4,s^3,s^2\), respectively. Direct substitution gives
\[
K\rho_\eta K^\dagger=p_*\rho_q,
\quad p_* =s^2[\eta+(1-\eta)s]^2
=\frac{\eta^4(1-q)^2}{q^4(1-\eta)^2}.\tag{20}
\]

Robustness is nonincreasing on average under free-preserving instruments. In the present setting this needs no imported resource theorem: apply a successful branch \(\Omega\) to a decomposition \(\rho+R\tau=(1+R)\sigma\). If its success on \(\rho\) is \(p\), normalizing gives a feasible target robustness at most \(R\operatorname{Tr}\Omega(\tau)/p\le R/p\). Thus \(pR(\rho_q)\le R(\rho_\eta)\). For \(\eta\le q\le\sqrt2/(1+\sqrt2)\), both robustness values use the first branch of (2), and (20) saturates the bound. This proves one-copy optimality even among the larger class of free-preserving operations.

If any mode filter first fails, that mode is projected empty. This removes one of the two terms of \(|\phi\rangle\), so the remaining density operator is diagonal in the occupation basis: a mixture of Slater determinants. Earlier successful diagonal filters do not change this fact. All failure branches are therefore free.

For example, concentrating \(\eta=0.1\) to \(q=0.5\) succeeds with probability \(1/2025\), giving exactly 2025 expected independent attempts. This is a formula and a finite-dimensional checked identity, not an experimental implementation.

The scaling is also optimal against collective use of many inputs. From (18),
\[
\rho_\eta^{\otimes n}\preceq(1+R_\eta)^n\sigma_+^{\otimes n},
\]
so \(R_{\rm gen}(\rho_\eta^{\otimes n})\le(1+R_\eta)^n-1\). A protocol producing \(\rho_q\) with success probability \(p\) must satisfy
\[
pR_q\le(1+R_\eta)^n-1,
\quad n\ge\frac{\log(1+pR_q)}{\log(1+R_\eta)}.\tag{21}
\]
At fixed \(p,q>0\), this is \(\Omega(\eta^{-4})\). Repeated independent filtering attains the same order for constant success probability. An output within trace distance \(\epsilon\) of \(\rho_q\) replaces \(R_q\) in this bound by \(\max\{R_q-2\epsilon,0\}\), using the bounded witness above. Thus the exponent is not an artifact of insisting on exact equality.

This is concentration to a fixed *mixed* non-Gaussian resource. It is not an assertion of perfect magic-state distillation, an achieved asymptotic distillation rate, or fault tolerance.

## 9. Consequence for fermionic code preparation

This section imports only the stated external code-fidelity bound, not its entire proof. Tang et al. [S6], Theorem 2 at zero non-Gaussian gates, implies that a code on \(m\) modes with \(k>0\) logical qubits and Majorana distance \(d_F\ge3\) has
\[
F_G(\mathcal C)\le
[1-H_2^{-1}(k/m)]^{\lfloor(d_F-1)/2\rfloor},\tag{22}
\]
where \(H_2^{-1}\) is the inverse binary entropy on \([0,1/2]\). This bounds the overlap of every codeword with every pure Gaussian state, hence also with every Gaussian mixture.

Suppose the only non-Gaussian inputs are our lossy standard blocks. Gaussian processing succeeds with probability \(p\) and produces a normalized state having fidelity at least \(1-\epsilon\) with a specified pure codeword. Tensor domination (18), positivity of the successful map, and (22) imply
\[
p(1-\epsilon)\le\left[\prod_i(1+R_i)\right]F_G(\mathcal C).
\]
Therefore
\[
\sum_i\log(1+R_i)\ge
\left\lfloor\frac{d_F-1}{2}\right\rfloor
\left[-\log(1-H_2^{-1}(k/m))\right]
+\log[p(1-\epsilon)].\tag{23}
\]
At constant code rate \(k/m\), constant success and fidelity, and small uniform transmission, (23) gives
\[
n=\Omega(d_F/\eta^4).\tag{24}
\]
This is a resource lower bound for the specified input-loss/Gaussian-processing architecture. It does not apply to arbitrary noisy quantum hardware, arbitrary additional non-Gaussian gates, or a device supplied with a loss record. It does not assert that the bound is achievable for code preparation. Its inherited mathematical dependency is [S6], explicitly distinguished from the self-contained concentration theorem.

## 10. Fundamental boundaries and failed escalations

### Loss flags change the problem

The quartic law concerns an unobserved environment. With an explicit classical flag revealing whether the original magic pair is intact, the flagged intact sector has weight \(\eta^2\) and pure magic distance \(1/2\). Comparing to flag-conditional Gaussian mixtures gives exact distance \(\eta^2/2\), not fourth order. Discarding the environment is therefore substantive, not a bookkeeping convenience. Postselecting an exponentially rare event is likewise not covered by the full-transcript TV bound without a success-probability charge.

### Universal quartic extension to three fermions is false

Consider \(|\chi\rangle=(|111000\rangle+|000111\rangle)/\sqrt2\). Its one-particle density matrix is \(I_6/2\). Every pure odd Gaussian state has a fully occupied natural orbital \(v\); its three-particle component lies in the subspace \(n_v=1\). Hence
\[
|\langle\chi|G\rangle|^2\le\tfrac12\langle G|\Pi_3|G\rangle.
\]
Even Gaussian states contribute zero. Thus \(W_\chi=P_\chi-\Pi_3/2\) has nonpositive expectation on \(\mathcal C_G\). Its spectral range is one, whereas uniform loss gives expectation \(\eta^3/2\). Consequently
\[
d_G(\mathcal L_\eta(P_\chi))\ge\eta^3/2.\tag{25}
\]
This is a rigorous obstruction to a dimension-uniform quartic theorem for arbitrary few-fermion blocks.

For a block with exactly \(K\) initial fermions, a generic low-sector approximation instead gives a cubic upper bound when \(K\eta\) is small. Move the probability of three or more survivors to the vacuum, costing at most that tail, and apply Section 4 to the zero/one/two sectors. If \(p_j=\binom Kj\eta^j(1-\eta)^{K-j}\), the bound is
\[
\sum_{j\ge3}p_j +\frac{p_2^2}{2(p_0+\sum_{j\ge3}p_j)}.
\]
For fixed \(K\), this is \(O(\eta^3)\), matching the order of (25) for some three-fermion inputs. Acquiring the low-order reduced density matrices must be charged; no arbitrary many-body oracle is assumed.

### Other retained obstructions

A local quartic lower bound is not a global sampling hardness theorem. Correlated Gaussian approximants or entirely different classical algorithms may do better. Signed estimation cannot be promoted to positive sampling by treating signed weights as probabilities. Fixed-precision conditioning may fail on tiny branches. Loss cannot be commuted through arbitrary active Gaussian evolution. The new theorem does not solve the determinant-weighted microscopic parity sampler, KLS, nonhyperlinear hyperbolic constructions, or the bounded-Holevo broadcasting conjecture in Astra's prior state.

A separate tentative transverse-field extension of Astra's positive-kernel route was explored: a one-site positive factor gives the multi-affine polynomial \(r+x+y+rxy\), whose direct log-Hessian test is compatible with \(r^2\le2\). The complete counting reduction, acquired support, and uniform bit implementation were not completed, so this remains a candidate interface, not a theorem used here.

## 11. Executed checks and implementation status

All reported executions below were performed in this run. There were no independent research subagents or external proof reviewers. Separate algebraic and dense-Fock checks are not independent researchers and not formal certification.

`checks/check_all.py` verifies 28 exact rational completion identities, two symbolic sharp-distance identities, 12 Gaussian engine instances, 15 arbitrary complex two-form/loss instances, 160 Gaussian witness tests, an eight-mode globally interfering full 256-outcome distribution, the three-fermion obstruction, and an actual 128-mode sampler execution. The two-block test gave state distance 0.00271622208442 and output TV 0.00262108025101; dense Fock and covariance output probabilities agreed to about 1.1e-16. The 128-mode execution used 32 magic blocks at transmission 0.08 and produced 12 samples with symbolic state-error bound numerically evaluated as 0.000385616705269. This is not a performance comparison against other simulators.

`checks/check_robustness.py` verifies 11 transmissions, two exact symbolic optimization identities, both robustness branches, 72 signed two-block Gaussian components and all 256 output probabilities, and an actual 12,000-draw signed estimator. It returned 0.1227247578 for a probability exactly 0.1225; the 95% Hoeffding radius was 0.02523577. Dense outcome enumeration at transmission 0.001 initially exposed terminal covariance overshoot. The repaired *diagnostic* reports its discarded branch mass (maximum about 2.51e-13) and terminal clipping contribution (about 2.04e-14 summed over all those diagnostics). The sampler itself is still not interval certified.

`checks/check_concentration.py` verifies 20 input/target transmission pairs, 80 first-failure Gaussian branches, and four exact symbolic identities. The maximum density identity error was about 6.94e-18, and the probability/robustness ratio disagreement about 2.17e-19.

The test programs use dense exponential Fock matrices only for small-system independent checks. The delivered sampling and signed-estimation programs do not construct them. Floating-point results validate implementation consistency, not the universal mathematical statements.

## 12. Status at the new checkpoint

The principal completion, witness, robustness, concentration, and tensor/resource arguments are written derivations with exact elementary identities and computational checks. They do not inherit the unaudited coefficient-counting premise that limited several prior Astra routes. The error-correction consequence explicitly retains its external theorem dependency. Novelty, expert correctness review, and an interval-certified engine remain unresolved.

The strongest complete operational conclusion is a matching fourth-order resource law: unobserved loss makes two-fermion magic fourth-order close to Gaussian mixtures; fourth-order Gaussian filtering recovers a fixed-quality resource; and neither one-copy free-preserving filtering nor collective processing can improve the corresponding inverse-fourth-power concentration exponent. This yields a full-output sampler, a wider signed-estimation regime, and a loss-dependent code-preparation obstruction. It is stronger than a proposed mechanism or a numerical observation, but its historical significance is not certified here.

## References and provenance

[S1] J. Heo, S. Park, C. Oh. *Classical simulation of quantum circuits with noisy magic inputs*. arXiv:2601.10111v2, 19 January 2026. Particle-loss Theorems 4–5 and decomposition discussion. https://arxiv.org/html/2601.10111v2

[S2] J. Heo, O. Reardon-Smith, M. Oszmaniec, Z. Zimborás, C. Oh. *Fast classical simulation algorithms for free-fermion dynamics with magic input states*. arXiv:2609.40187v1, 30 September 2026. Particle-loss instrument framework and exact algorithms. https://arxiv.org/html/2609.40187v1

[S3] M. Oszmaniec, J. Gutt, M. Kuś. *Classical simulation of fermionic linear optics augmented with noisy ancillas*. arXiv:1406.1577v1, 2014. Convex-Gaussian four-mode geometry and simulation. https://arxiv.org/html/1406.1577v1

[S4] B. Dias, R. König. *Classical simulation of non-Gaussian fermionic circuits*. arXiv:2307.12912v3, 2024; Quantum 8, 1350. Gaussian propagation/measurement, extent and two-factor multiplicativity. https://arxiv.org/html/2307.12912v3

[S5] S. Bravyi. *Lagrangian representation for fermionic linear optics*. arXiv:quant-ph/0404180. https://arxiv.org/abs/quant-ph/0404180 ; S. Bravyi, R. König. *Classical simulation of dissipative fermionic linear optics*. arXiv:1112.2184. https://arxiv.org/abs/1112.2184

[S6] Y. Tang, I. Roth, P. Faist, Z.-W. Liu, J. Eisert, Z. Liu. *Fermionic quantum error correction is never free*. arXiv:2609.15059v1, 14 September 2026. Theorem 2, zero-doping specialization only is the load-bearing import for (22). https://arxiv.org/html/2609.15059v1

[S7] B. Dias, J. L. Bosse, J. R. Seddon. *Optimal and improved gate decompositions for accelerated classical simulation of near-Gaussian fermionic circuits*. arXiv:2603.18869v2, 30 September 2026. General Gaussian decomposition/quasiprobability prior-art context, not a premise of the new formulas. https://arxiv.org/html/2603.18869v2

[S8] J. Cudby, S. Strelchuk. *Gaussian decomposition of magic states for matchgate computations*. arXiv:2307.12654v3. Opened for multiplicativity priority follow-up; not a premise and not fully audited in this run. https://arxiv.org/html/2307.12654v3

[S9] C. Oh, M. Oszmaniec, O. Reardon-Smith, Z. Zimborás. *Classical simulation of free-fermionic dynamics and quantum chemistry with magic input*. arXiv:2604.26813v1. Arbitrary paired-block and additive simulation context. https://arxiv.org/html/2604.26813v1

[S10] Chen–Liu, *An FPRAS for Counting Common Bases of Two Matroids*, arXiv:2610.06724v1. Reviewed as an input to the inherited Astra counting routes; **not a premise** of the quartic resource results. https://arxiv.org/html/2610.06724v1

[R] Astra Research Knowledge, commit `89bd24d151f8ff240958cc75ad454e415a991dc2`. Selective read ledger in `sources/SOURCE_LEDGER.md`. https://github.com/harjassand/astra-research-knowledge
