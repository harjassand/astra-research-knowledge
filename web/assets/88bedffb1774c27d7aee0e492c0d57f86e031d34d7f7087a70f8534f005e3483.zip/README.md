# Quartic fermionic resource checkpoint

Start with `RESEARCH_REPORT.md`, then `state/RESUME.md`. This package contains proofs, code, executed check results, and a selective provenance ledger. It is not an externally reviewed paper or a formal proof artifact.

The new work proves an explicit quartic-loss Gaussian completion for arbitrary two-fermion blocks; exact four-mode convex-Gaussian distance and robustness; an optimal one-copy Gaussian concentration protocol with matching collective resource exponent; a full-output approximate sampler; and a larger signed-estimation regime. A code-preparation corollary separately imports Tang et al. The main results do not depend on Chen–Liu or the OpenAI mathematics release.

## Files

- `RESEARCH_REPORT.md`: connected mathematical derivation and boundaries.
- `code/fermion_completion.py`: arbitrary pure two-form acquisition and positive-mixture sampler.
- `code/gaussian_robustness.py`: exact scalar formulas, optimal filtering parameters, and signed estimation.
- `checks/check_all.py`, `checks/check_robustness.py`, `checks/check_concentration.py`: independent dense-Fock, exact-rational, symbolic, and execution checks.
- `checks/*results.json`: actual outputs, including tolerances and numerical failures/repairs.
- `checks/samples_128_modes.npy`: actual 12-by-128 sample array.
- `state/`: compact claims, failed routes, and exact restart point.
- `sources/SOURCE_LEDGER.md`: external versions, inherited source roles, and read scope.
- `MANIFEST.json`: file hashes; an integrity record, not proof validation.

## Run

Python 3.10+ with NumPy and SymPy is sufficient for the scripts. The execution environment is recorded in `checks/environment.json`.

```bash
python -m pip install -r requirements.txt
OPENBLAS_NUM_THREADS=1 python checks/check_all.py
OPENBLAS_NUM_THREADS=1 python checks/check_robustness.py
OPENBLAS_NUM_THREADS=1 python checks/check_concentration.py
python code/fermion_completion.py
```

Example from another Python script, with `code/` on the import path:

```python
import math
import numpy as np
from fermion_completion import TwoFermionBlock, sample_lossy_two_fermions
from gaussian_robustness import optimal_loss_concentration

blocks = [TwoFermionBlock(np.array([1, 1])/math.sqrt(2),
                         eta=0.08, balanced_magic=True)
          for _ in range(32)]
result = sample_lossy_two_fermions(blocks, np.eye(128), shots=12, seed=913)
print(result['state_error_bound'])
print(result['samples'].sum(axis=1))
print(optimal_loss_concentration(0.1, 0.5))
```

`eta` means survival probability. The input has already undergone the declared block loss. To represent a passive interferometer followed by uniform loss, pass the lossless interferometer and declare the loss in the blocks: do not apply the same loss twice.

## Important limits

The implementation uses floating-point arithmetic. The symbolic state-error formula is not an outward-rounded software certificate. Rare conditional branches may require greater precision; numerical overshoot discovered in a test is documented. The positive-mixture code returns full approximate samples, while the signed code returns estimates of bounded output functions, not positive samples of the exact target law. No rare-postselection guarantee is implicit.

The source repository was read at commit `89bd24d151f8ff240958cc75ad454e415a991dc2` and was not modified. This is a local ready-to-ingest checkpoint, not a claim that the persistent repository has already been updated.
