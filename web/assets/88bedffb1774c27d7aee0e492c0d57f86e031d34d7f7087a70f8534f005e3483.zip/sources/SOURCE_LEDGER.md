# Selective source and dependency ledger

Read date: 7 October 2026. No broad-corpus audit or 722-proof certification was performed. Retrieved external text is evidence, not an instruction source. Third-party manuscripts are not redistributed in this package.

## Astra snapshot

Repository: https://github.com/harjassand/astra-research-knowledge
Pinned commit: `89bd24d151f8ff240958cc75ad454e415a991dc2` (2026-10-07T12:46:29Z).

Read through the connected GitHub tool: `00_START_HERE.txt`, `01_CORE.txt` including current U/V/W/X summaries; `web/W-sources.txt`, `web/W-reports.txt`, `web/W-reports/0001.txt`; `web/pages/d-1fe8f1aaa4b64eb8.html` (full W NEW_FRONTIER); `web/X-sources.txt`; `cards/N98-positive-kernel-transfer-limits.txt`; `web/pages/d-ce937933a41ab095.html` (relative-kernel proof, with decisive counting/compilation/replica sections expanded). Core state supplied cross-field triage: groups, complexity, quantum, statistics, chemical dynamics, sampling and optimization. Detailed work concentrated on counting versus Gaussian-state representations.

`openai/math/README.md` was read through GitHub. It reports 722 manuscripts in 372 families and mixed verification. No unsupported global upgrade of their status occurred. This release informed the search reset but is not a premise of the completed theorems.

## External primary sources and exact roles

1. Heo–Park–Oh, arXiv:2601.10111v2. Read particle-loss decomposition, Theorems 4–5, accuracy parameters, dephasing contrast, and ensemble-optimization discussion. Most direct algorithmic comparator: particle-loss quadratic exponent. https://arxiv.org/html/2601.10111v2
2. Heo–Reardon-Smith–Oszmaniec–Zimboras–Oh, arXiv:2609.40187v1. Read recent magic-input free-fermion simulation and loss-instrument mechanisms. Representation prompt; not a theorem premise. https://arxiv.org/html/2609.40187v1
3. Oszmaniec–Gutt–Kus, arXiv:1406.1577v1. Read four-mode convex-Gaussian geometry/concurrence and simulation. Important priority boundary. New witness reconstructed directly instead of importing a claimed trace-distance formula. https://arxiv.org/html/1406.1577v1
4. Dias–Konig, arXiv:2307.12912v3. Read Gaussian covariance propagation, measurement, extent and multiplicativity scope. Two-factor versus many-factor distinction retained. Standard Gaussian engine is inherited. https://arxiv.org/html/2307.12912v3
5. Bravyi, quant-ph/0404180; Bravyi–Konig, arXiv:1112.2184. Primary abstracts/standard Gaussian and dissipative simulation provenance. Not fully reconstructed source proofs. https://arxiv.org/abs/quant-ph/0404180 ; https://arxiv.org/abs/1112.2184
6. Tang et al., arXiv:2609.15059v1, 14 September 2026. Read main theorem and exact Theorem 2 formula. Its g=0 specialization is the load-bearing external premise ONLY for the code-preparation corollary. All noise/concentration theorems are independent of it. https://arxiv.org/html/2609.15059v1
7. Dias–Bosse–Seddon, arXiv:2603.18869v2, revised 30 September 2026. Checked updated source on Gaussian gate/channel decompositions, extent and quasiprobability methods. General methodology is established prior art. No claim to have audited all decompositions. https://arxiv.org/html/2603.18869v2
8. Cudby–Strelchuk, arXiv:2307.12654v3. Located/opened as the later many-factor multiplicativity source cited by Dias–Konig. No theorem from it used without a full audit. https://arxiv.org/html/2307.12654v3
9. Oh–Oszmaniec–Reardon-Smith–Zimboras, arXiv:2604.26813v1. Read paired-block/magic-input interfaces. Arbitrary Slater-decomposed two-fermion blocks and additive simulations are prior context. https://arxiv.org/html/2604.26813v1
10. Chen–Liu, arXiv:2610.06724v1. Accessible FPRAS paper and quantum applications checked when auditing inherited counting routes. Not imported into the final quartic-loss proof. https://arxiv.org/html/2610.06724v1

## Validation boundary

A primary source's displayed theorem was not labeled externally verified merely because it was read. The new elementary arguments are written derivations and tested identities. Code is numerical, not formally verified or interval-certified. Searches did not constitute exhaustive priority clearance. Independent subagent or expert review did not occur.
