# Resume from the quartic fermionic resource frontier

Date: 7 October 2026. Prior Astra commit: `89bd24d151f8ff240958cc75ad454e415a991dc2`.

## Do not rediscover these results

The main new mechanism is **normalized Gaussian completion** of a lossy two-form, not another counting reduction. All loss is unobserved; eta is survival probability. Read Sections 3–8 of `../RESEARCH_REPORT.md` before transferring claims.

For a canonical pure two-form sum s_j pair_j, weights w_j=|s_j|^2, a=(1-eta)^2, b=eta^2, solve product(1+x w_j)=1+b/a. A uniform r+1-phase BCS mixture with total weight a+b, plus the original one-particle sector, preserves vacuum and reduces the two-particle ray by delta=b-a*x while adding delta only to >=4 sectors. Thus exact trace error delta <= b^2/(2a). Product sector-faithful errors equal 1-product(1-delta_i). This gives full Gaussian-protocol output sampling, no inverse output-probability requirement, with a separate arithmetic budget.

For balanced four-mode magic, closest convex-Gaussian trace distance is (sqrt(a+b)-sqrt(a))^2 for b<=3a, and (b-a)/2 otherwise. A Pluecker witness W_t=P_phi-Pi_2/2-tP0-P4/(4t) proves global optimality. High-branch product-error expression is an upper bound, not necessarily equality.

Generalized AND standard Gaussian robustness equal b^2/(4a) for b<=2a, b-a otherwise. Upper bounds add Gaussian vacuum/full noise; lower bounds use 4tW_t>=-I. The exact signed decomposition has absolute mass 1+2R. Tensor signed estimators cost Gamma^2, Gamma=product(1+2R_i), so bounded-function estimation is polynomial for sum eta_i^4=O(log M). This DOES NOT give a full positive sampler in that logarithmic regime.

Gaussian concentration is COMPLETE, not merely a suggestion. Per-mode successful K=diag(sqrt(s),1), s=eta(1-q)/(q(1-eta)). Four successes give rho_q with p=eta^4(1-q)^2/[q^4(1-eta)^2]. For eta<=q<=sqrt(2)/(1+sqrt(2)), p=R_eta/R_q and is optimal among all free-preserving stochastic maps. All first-failure branches are Gaussian mixtures. Collective lower bound n>=log(1+p R_q)/log(1+R_eta), hence Theta(eta^-4) inputs for fixed-quality, constant-success concentration; independent filtering attains the exponent.

Rank-two unbalanced extension: B=b|s1*s2|; robustness B^2/a when B<=a, 2B-a otherwise. Written proof completed, dedicated compiler/checks remain balanced-only.

## Highest-consequence completed transfer

Tensor domination rho_input <= product(1+R_i) sigma_free plus Tang et al. arXiv:2609.15059v1 Theorem 2 at g=0 gives code preparation:
sum log(1+R_i) >= floor((dF-1)/2)*[-log(1-H2^-1(k/m))] + log[p(1-epsilon)].
For fixed rate/success/fidelity and small eta: n=Omega(dF/eta^4). External code theorem is a stated dependency, not independently fully certified here. Main resource/concentration/sampling results need neither that theorem nor OpenAI/Chen–Liu.

## Exact barriers already earned

1. No universal quartic extension to arbitrary three-fermion blocks: chi=(111000+000111)/sqrt2 and W=P_chi-Pi3/2 give distance >=eta^3/2. Odd pure Gaussian has a fully occupied natural orbital; chi has 1RDM I/2.
2. An intact/loss flag restores quadratic resource distance eta^2/2. Unobserved loss is essential.
3. Signed estimates are not positive samples; rare-prefix normalization remains a gate.
4. Local Gaussian-distance optimality is NOT global classical hardness or an optimal survivor threshold.
5. Arbitrary active dynamics do not commute with uniform loss. Positive certificate for a passive transfer T is T*T <= blockdiag(eta_i I), followed by contraction T D^-1.
6. Fixed double precision is not uniformly safe; see failure ledger.
7. The determinant-parity microscopic sampler, KLS, general broadcasting, and the transverse-field LC counting extension remain open. Do not silently mark them solved.

## Checks actually performed

Three scripts and three JSON results are supplied. Main full-output comparison: all 256 outcomes after generic global 8-mode mixing; 128-mode/32-block sampler run produced 12 samples. Robustness: 11 transmissions, exact signed density identities and 72-component two-block contraction, 12,000-draw Monte Carlo. Concentration: 20 parameter pairs, 80 failure branches, four symbolic identities. Exact-rational/symbolic checks and numerical tests are distinct. No independent subagents, outside mathematicians, or proof assistant certified this run.

## Next decisive gates, not inferred achievements

Check priority specifically for normalized vacuum/pair Gaussian completion, exact loss robustness and optimal local filtering; known four-mode concurrence and two-qubit-style convex geometry may contain earlier special cases. Obtain specialist proof review of the global witness and Gaussian loss conventions. Build an interval/high-precision implementation with a certified cumulative error budget. Investigate collective positive sampling beyond sum eta^4=O(epsilon) without converting signed probabilities illegally. Code-preparation achievability is not established. Generic-rank exact robustness is not supplied.

The persistent GitHub repository is unchanged. Preserve this folder or ingest its cards explicitly; do not claim a commit occurred.
