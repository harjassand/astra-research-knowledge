# Failed routes, limits, and repaired claims

These are research capital, not instructions to weaken the positive theorems.

## Numerical failure actually observed

The first robustness full-outcome test at eta=0.001 failed with `ArithmeticError: Unphysical covariance; numerical failure.` At a terminal branch of cumulative probability 7.1503692546e-8, the covariance entry was 1.000000003458609. Division during earlier conditioning amplified a small floating error; the exact density identities were correct. Merely discarding branches below cumulative 1e-11 did not prevent this terminal overshoot.

The dense diagnostic now avoids unnecessary terminal conditioning, clips the final Born probability, and reports all discarded/clipped mass. Max discarded diagnostic mass was about 2.5100e-13; total terminal clipping mass across all those diagnostics about 2.0365e-14. These quantities are numerical diagnostics, not rigorous intervals. The actual sampler also avoids the unnecessary final Schur update. Nonterminal loss of physicality still raises rather than silently proceeding. A uniform interval certificate is not delivered.

## Mathematical overextensions rejected

- Keeping exact input particle-number support would disallow the positive Gaussian completion's artificial >=4 tail and lose the quartic saving. The target is trace/output approximation, not exact support preservation.
- For high-transmission optimal magic approximants, vacuum mass is increased. The exact product-distance identity for sector-faithful completions is not automatically valid; use its commuting-coupling upper bound.
- Signed Gaussian decompositions yield bounded-functional estimates with Gamma^2 overhead. They do not, without further work, yield full positive samples at n eta^4=O(log M).
- Two-factor Gaussian fidelity multiplicativity does not inductively establish arbitrary multi-block fidelity. Later multiplicativity literature was located, but no multi-output magic-distillation rate was claimed from it.
- One-copy optimal concentration is to a fixed mixed resource rho_q. Perfect pure magic distillation and fault-tolerant achievability are not proved.
- Standard robustness tensor submultiplicativity was not assumed. Collective bounds use generalized robustness through explicit PSD domination.
- Loss after a passive interferometer commutes to inputs; loss after active Gaussian dynamics generally does not. Use an input-loss model or the supplied passive contraction certificate.
- Access to a loss/intact flag changes the resource scaling to quadratic. Full-environment or heralded variants are not covered.
- Arbitrary three-fermion inputs have a cubic lower-bound example, ruling out a universal quartic generalization.
- Efficiently given two-form coefficients/low-order density matrices are an acquisition premise. No exponential many-body input oracle is hidden.

## Prior Astra routes inspected but not closed

Determinant-weighted parity: aggregate stable-polynomial/exchange identities and support recognition do not acquire microscopic conditional sampling or polynomial annealing energy. Covariant loss alone does not commute with the hard projection or supply its unknown norms.

Positive-kernel spin route: Chen–Liu's source already includes six-vertex and quantum-model applications; those cannot be relabeled new. One-site transverse-field polynomial r+x+y+rxy has a promising log-Hessian condition r^2<=2, but the full counting/support/bit reduction was not completed.

Bounded-Holevo broadcasting: no dimension-free simultaneous EB lift was proved. Pairwise commutator/gap bounds and measured de Finetti substitutes are insufficient under the retained prior counterexamples.

KLS/chemical/group routes: retained inherited obstructions were not removed. No claim of a general barrier to scientific progress follows from these route-specific failures.
