---
title: "Relative imaginary-time kernels and replica access for easy-plane spin systems"
author: "Astra research checkpoint: AI-assisted derivation"
date: "7 October 2026"
fontsize: 11pt
geometry: margin=25mm
colorlinks: true
---

## Status and principal claim

This is a conditional research derivation, not an externally reviewed paper or a claim of established priority. Its algorithmic conclusions import the homogeneous log-concave coefficient FPRAS in Chen and Liu, arXiv:2610.06724v1, Theorem 5.1 and its every-execution rational implementation in Remark A.4. The counting theorem has not been independently certified in full, and neither its FPRAS nor the reversible quantum compiler has been implemented in this run. The included code tests finite identities and small numerical instances, not the full algorithms.

The principal new candidate contribution is an explicit passage from positive local imaginary-time dynamics to **entrywise relative approximation**, and from there to coherent state access and relative replica contraction. Relative accuracy matters: a small trace-distance perturbation alone does not protect an exponentially small purity or the normalization of a rare conditioned state.

The main spin family, in a specified computational basis, is

$$
 H=\frac12\sum_{e=uv}\bigl[d_e Z_uZ_v-f_e(X_uX_v+Y_uY_v)\bigr]
       +\sum_i h_iZ_i,\qquad f_e\geq |d_e|,
 \tag{1}
$$

with rational coefficients on an arbitrary finite graph. Zero edges can be deleted. The longitudinal fields $h_i$ may have either sign. The inequalities are edgewise; no bounded-degree, geometric-locality, high-temperature, area-law, or physical-mixing promise is made.

Set

$$
 V=\sum_e(f_e+\max(d_e,0))+2\sum_i|h_i|.
 \tag{2}
$$

**Conditional theorem.** For the input (1), rational $\beta>0$, accuracy $0<\epsilon<1/2$, and failure probability $0<\delta<1/2$, there are algorithms with the following guarantees, assuming the imported coefficient FPRAS.

* A randomized classical compiler produces a quantum circuit preparing an $\epsilon$-approximation in trace distance to the canonical purification of $\rho_\beta=e^{-\beta H}/\operatorname{Tr}e^{-\beta H}$. Its compilation time and circuit size are polynomial in the input bit length, $n$, $1+\beta V$, $\epsilon^{-1}$, and $\log\delta^{-1}$. Compiler success probability is at least $1-\delta$.
* For every specified subsystem $S$ and integer $q\geq2$, a classical randomized algorithm approximates $\operatorname{Tr}[(\operatorname{Tr}_{S^c}\rho_\beta)^q]$ to relative error $\epsilon$ with probability at least $1-\delta$, in time polynomial in the same parameters and in the **numerical value** of $q$. No inverse-purity factor occurs. Consequently the integer-order subsystem Renyi entropy is accessible to additive error.
* Pinning any specified collection of computational-basis coordinates of the purification, or making such a diagonal herald on its physical register, does not introduce an inverse-success-probability factor. Zero success is detected exactly. This is not a claim about arbitrary projectors or arbitrary postselection predicates.

The theorem prepares a compact quantum circuit, not a classical table of exponentially many amplitudes. The imaginary-time local factors used in its proof are a **classical tensor-network description**; the algorithm does not apply them physically with postselection.

Two further results below give relative replica access to sector ground states and, more strongly, to the normalized global ground-space projector. The latter requires only a supplied gap above the ground space; neither its dimension nor its particle-number sector must be known. These results charge inverse gap but not inverse basis-state overlap.

## 1. What is inherited

Chen and Liu's coefficient theorem takes two homogeneous, nonnegative, multi-affine, log-concave polynomials $f,g$ in $M$ variables whose degrees sum to $M$. With explicit coefficient-value programs, positive initializing supports, and bounds on the ratio of largest to smallest positive coefficients, it approximates

$$
 [x_1\cdots x_M]f(x)g(x)
 \tag{3}
$$

to relative error $\eta$. The stated arithmetic/oracle bound is

$$
 O\!\left(M^{10}B^2\eta^{-2}\log^2(2B/\eta)\right),
 \qquad B=M+\log(R_fR_g).
 \tag{4}
$$

The base success probability is at least $3/4$. Median amplification adds a logarithmic failure-probability factor. The finite-bit argument must supply a time bound on **every execution**, including erroneous random tapes. An expected-time-only oracle would not justify a uniform coherent circuit.

The source's Corollaries C.16 and C.17 already give the six-vertex counting interface and EPR/bipartite Quantum Max-Cut partition-function and energy algorithms. Those are not discoveries of this checkpoint. Astra N63 already supplies the weighted-prefix compiler argument for projected Slater determinants; Section 5 reconstructs that general mechanism for the new count instances. Neither recursive amplitude preparation nor the replica identity itself is claimed as new.

The source proof is a substantial external dependency. This note checks the input/output interface and constructs a reduction to it, rather than replacing its full proof.

## 2. A positive product formula with relative entrywise error

The central analytic lemma does not depend on Chen--Liu.

**Lemma 1 (positive word approximation).** Let $A_1,\ldots,A_s$ be entrywise nonnegative finite matrices, $A=\sum_jA_j$, and $V\geq\sum_j\|A_j\|_2$. Fix $\tau>0$ and assume that every nonzero entry of $K=e^{\tau A}$ is at least $\lambda$, where $0<\lambda\leq1$ is known. Given $0<\alpha\leq1/2$, choose an integer $B_0\geq0$ with $2^{-B_0}\leq\lambda$, and let

$$
 k_0\geq\max\left\{1,\lceil6\tau V\rceil,
 B_0+\left\lceil\log_2\frac{64}{\alpha}\right\rceil\right\},
 \qquad
 m\geq\max\left\{2k_0,\left\lceil\frac{8k_0^2}{\alpha}\right\rceil\right\}.
 \tag{5}
$$

For any fixed ordering of the factors define

$$
 C_m=\left[\prod_{j=1}^s\left(I+\frac{\tau A_j}{m}\right)\right]^m.
 \tag{6}
$$

Then its support agrees exactly with that of $K$, and

$$
 (1-\alpha)K_{xy}\leq(C_m)_{xy}\leq(1+\alpha)K_{xy}
 \quad\text{for all }x,y.
 \tag{7}
$$

In particular, the number of factors is polynomial in $s,\tau V,\log\lambda^{-1},\alpha^{-1}$, rather than in $\lambda^{-1}$. The statement is about an implicit product description, not an algorithm that writes out all entries.

**Proof.** Expand in words $w=j_1\cdots j_k$ in the noncommuting letters $A_j$. Every word has coefficient $\tau^k/k!$ in $e^{\tau A}$. Its coefficient in (6) is $(\tau/m)^kN_m(w)$, where $N_m(w)$ is the number of embeddings into $m$ repetitions of the fixed ordered list of letters.

For $k\leq m$, assigning the letters to distinct sweeps yields

$$
 N_m(w)\geq {m\choose k}.
$$

For an upper bound, assign each letter a weakly increasing sweep number. The ordering constraint inside a sweep can only eliminate assignments, so for all $k$,

$$
 N_m(w)\leq {m+k-1\choose k}.
$$

Thus, for $k\leq k_0$ and $m\geq2k_0$, the coefficient ratio lies between

$$
 \prod_{j=0}^{k-1}\left(1-\frac jm\right)
 \quad\text{and}\quad
 \prod_{j=0}^{k-1}\left(1+\frac jm\right).
$$

Using $\log(1-u)\geq-2u$ for $0\leq u\leq1/2$ and $\log(1+u)\leq u$, these are bounded by

$$
 e^{-k_0^2/m}\leq\frac{\text{product coefficient}}{\text{exponential coefficient}}
 \leq e^{k_0^2/(2m)}.
 \tag{8}
$$

All matrix words are entrywise nonnegative, so (8) compares the truncated matrix series entrywise, with no cancellation.

It remains to bound both tails. Put $T=\tau V$. The norm of the exponential tail is at most $\sum_{k>k_0}T^k/k!$. The product tail obeys the same bound: replacing each factor by the scalar polynomial $1+\tau\|A_j\|z/m$, its coefficients majorize the norms of the corresponding matrix contributions, while

$$
 \prod_j(1+\tau\|A_j\|z/m)^m
 \preceq \exp(Tz)
$$

coefficientwise. This uses $1+uz\preceq e^{uz}$ for $u\geq0$.

For $k_0\geq6T$, Stirling's elementary lower bound $k!\geq(k/e)^k$, $e<3$, and the geometric ratio bound $T/(k_0+2)\leq1/6$ imply

$$
 \sum_{k>k_0}\frac{T^k}{k!}\leq2^{-k_0}
 \leq\frac{\alpha\lambda}{64}.
 \tag{9}
$$

Let $P$ be the degree-$k_0$ truncation of $K$. For $K_{xy}>0$, (8)--(9) give

$$
 e^{-\alpha/8}\left(1-\frac{\alpha}{64}\right)K_{xy}
 \leq(C_m)_{xy}
 \leq\left(e^{\alpha/16}+\frac{\alpha}{64}\right)K_{xy}.
$$

These bounds imply (7) for $\alpha\leq1/2$. A zero entry of $K$ receives no positive contribution from any word and is therefore zero in $C_m$. Conversely, the lower bound is positive for every positive entry of $K$. This proves the support assertion. $\square$

The useful representation change is from a noncommutative operator-error bound to a comparison of **positive path weights**. Small entries are protected because the tail cutoff grows only with their logarithmic lower bound.

## 3. Acquiring the lower bound for the spin family

Write $d_+=\max(d,0)$ and $d_-=\max(-d,0)$. For every edge define

$$
 A_e=\begin{pmatrix}
 d_-&0&0&0\\
 0&d_+&f&0\\
 0&f&d_+&0\\
 0&0&0&d_-
 \end{pmatrix},
 \qquad A_i=|h_i|I-h_iZ_i.
 \tag{10}
$$

All entries are nonnegative. Moreover,

$$
 A:=\sum_e A_e+\sum_i A_i=cI-H,
 \quad c=\frac12\sum_e|d_e|+\sum_i|h_i|,
 \quad\sum_e\|A_e\|+\sum_i\|A_i\|\leq V.
 \tag{11}
$$

The bound on $\|A_e\|$ follows from $f\geq|d|$: its eigenvalues are $d_-,d_-,d_++f,d_+-f$.

In the computational basis, an off-diagonal transition swaps $01$ with $10$ along a positive-$f$ edge. Therefore $e^{\tau A}_{xy}>0$ exactly when $x$ and $y$ contain the same number of ones in each connected component of the positive-edge graph.

**Lemma 2 (short paths).** Any two such configurations can be connected by at most $D=n^2$ allowed swaps.

**Proof.** Choose a spanning tree of each component. Fix a leaf. If its bit is already correct, remove it. Otherwise a vertex with the desired bit exists in the remaining tree because the remaining particle counts agree. Choose the nearest such vertex. All intermediate bits are opposite to the desired bit, so consecutive swaps transport it to the leaf. Freeze and remove that leaf. At most $r-1$ swaps are used when $r$ vertices remain; summing gives at most $n(n-1)/2$, hence the stated conservative bound. $\square$

If there is at least one positive edge, let $f_{\min}$ be the smallest positive $f_e$ and put

$$
 b=\min\{1,\tau f_{\min}\},\qquad
 \lambda=\frac{b^D}{D!}.
 \tag{12}
$$

A path of length $\ell\leq D$ contributes at least $(\tau f_{\min})^\ell/\ell!\geq\lambda$ to the exponential. Diagonal entries are at least one. Thus (12) is an acquired lower bound for all nonzero entries, including with arbitrary longitudinal fields. Its rational encoding length is polynomial. In particular,

$$
 \log\lambda^{-1}=O\!\left(n^2[\log n+\log_+(1/(\tau f_{\min}))]\right).
 \tag{13}
$$

When there are no positive edges, $A$ is diagonal and one can use $\lambda=1$; the Gibbs state is a product state. Isolated spins can likewise be treated separately.

Equations (5), (12) and (13) make the relative-kernel construction polynomial in input length and $1+\tau V$. Extremely small binary-encoded couplings enter logarithmically, not through $1/f_{\min}$.

## 4. Why all required contractions are countable

An edge factor in (6), with $t=\tau/m$, is

$$
 F_e=I+tA_e=
 \begin{pmatrix}
 a&0&0&0\\
 0&b&c&0\\
 0&c&b&0\\
 0&0&0&a
 \end{pmatrix},
 \quad a=1+td_-,\ b=1+td_+,\ c=tf.
 \tag{14}
$$

Complementing the input incidence bits converts this matrix into the homogeneous polynomial

$$
 q_e(x)=a(x_1x_2+x_3x_4)
       +b(x_1x_3+x_2x_4)
       +c(x_1x_4+x_2x_3),
 \tag{15}
$$

up to a harmless ordering of its four ports. A connected wire then selects one of its two incidence variables.

The four Hessian eigenvalues, with this labeling, are

$$
 a+b+c,\quad a-b-c,\quad -a+b-c,\quad -a-b+c.
 \tag{16}
$$

For a nonnegative homogeneous quadratic, having at most one positive Hessian eigenvalue implies log-concavity on the positive orthant. One direct proof uses the reverse Cauchy--Schwarz inequality for a quadratic form of signature $(1,*)$ on its positive cone, applied to the Hessian of $\log q$.

The triangle inequalities are explicit here:

$$
 a+c-b=t(f-d)\geq0,\quad b+c-a=t(f+d)\geq0,
 \quad a+b-c=2-t(f-|d|)\geq0.
 \tag{17}
$$

The final inequality follows from our choice of $m$, which gives $tf\leq1/6$. Thus (15) is log-concave, including the cone boundary $f=|d|$.

A field factor $I+tA_i$ is diagonal and gives a positive homogeneous linear polynomial in its two incidence variables. These factors need not be spin-flip symmetric. Reversing their ports still gives a positive linear polynomial. This verifies the extension to either sign of longitudinal field rather than assuming it.

For a closed network, let $M$ be its number of incidences and set

$$
 f(x)=\prod_{v}q_v(x_{\text{ports of }v}),
 \qquad g(x)=\prod_{e=\{u,v\}}(x_{u,e}+x_{v,e}).
 \tag{18}
$$

Each degree-four vertex contributes degree two; each field vertex contributes degree one. Hence $\deg f=\deg g=M/2$. The variables in distinct factors of $f$ are disjoint, so $\log f$ is a sum of concave functions. The coefficient (3) is exactly the contraction: $f$ chooses incoming incidences and $g$ supplies their complementary incidence on each wire.

The argument also permits a wire joining distinct ports of the same vertex. Although the source's six-vertex corollary is stated for loopless multigraphs, the direct coefficient representation (18) uses distinct incidence variables and does not require looplessness.

**Pins and acquired support.** Fixing a wire direction replaces its factor in $g$ by the corresponding single complementary variable. This preserves homogeneity and log-concavity. For these positive local weights, support feasibility is an incidence assignment problem: each free wire supplies one incoming end, every edge vertex demands two incoming ends, and every field vertex demands one. Fixed directions reduce these demands. A capacitated bipartite matching/max-flow test, with distinct ports retained, decides feasibility exactly and returns a witness. Thus no rare-support oracle is assumed.

**Bit bounds.** Coefficient evaluation for $f$ multiplies one small rational lookup per vertex. Evaluation for $g$ is a membership test. If $r_v$ is the ratio of largest to smallest positive local weight, $R_f\leq\prod_v r_v$ and $R_g=1$. Their logarithms are polynomial in the network's encoding length. Pinned instances do not increase these bounds. A feasible orientation supplies initializing supports. All oracle and range data required by (4) are therefore acquired.

**Doubling and replicas.** The squared norm of an open network is obtained by gluing it to a transposed copy. Its prefix squared norms are the same closed contraction with selected boundary wires pinned. A transpose reverses the gate order and ports; it does not change the admissible local classes. Replica permutations only rewire the boundary edges and likewise preserve all local classes. This verifies closure under the actual operations used below, not merely closure of an ordinary partition function.

## 5. Coherent compilation without an exponentially good random tape

Take $\tau=\beta/2$ and let $C$ denote the rational product in Lemma 1. Its desired coherent state is

$$
 |\phi_C\rangle=\frac{\operatorname{vec}C}{\|C\|_F}.
 \tag{19}
$$

There are $r=2n$ boundary bits. Every prefix probability is a ratio of two doubled-network counts. An exact support test handles zero branches. The local nonunitary factors are not physical gates of the output preparation circuit.

For completeness, reconstruct the Astra N63 shared-tape argument. Suppose each of the two child counts is relatively accurate to $\eta$ except with probability $\zeta$, on every fixed feasible prefix. Choose one padded random tape per depth, shared across all prefixes at that depth. Normalize nonnegative child estimates, force exactly empty children to zero, and choose a known feasible branch if erroneous estimates give zero total. At infeasible prefixes choose a fixed sentinel rotation, so the program is total.

Write $p(h)$ for a true prefix mass. If a prefix is bad when either count fails, define

$$
 B_d=\sum_{|h|=d}p(h)\mathbf1_{\{h\text{ bad}\}},\qquad B=\sum_d B_d.
$$

Linearity of expectation gives $\mathbb EB\leq2r\zeta$. There is no union bound over exponentially many prefixes. On a good prefix the squared distance between the two conditional square-root vectors is at most $16\eta^2$; on a bad prefix it is at most two.

Use the unitary hybrid with the **true** prefix state at the changed layer. It gives

$$
 \|\phi_{\rm tape}-\phi_C\|_2\leq4r\eta+\sqrt{2rB}.
$$

Markov's inequality implies, with tape probability at least $1-\delta$,

$$
 \|\phi_{\rm tape}-\phi_C\|_2
 \leq4r\eta+2r\sqrt{\zeta/\delta}.
 \tag{20}
$$

Choose $\eta=\epsilon/(32r)$ and $\zeta=\delta\epsilon^2/(256r^2)$, so (20) is at most $\epsilon/4$. Use kernel accuracy $\alpha=\epsilon/64$ and allocate at most $\epsilon/4$ additional vector error to finite-precision arithmetic and rotation synthesis. The normalized-kernel vector error is at most $2\alpha/(1-\alpha)<\epsilon/16$. The total is therefore less than $\epsilon$.

Fixing the padded tapes gives finite deterministic programs on prefixes. Reversible simulation computes a conditional rational, performs a controlled rotation, and uncomputes the workspace. The history, arithmetic precision, gate synthesis, and amplification costs are polynomial. Compiler success is not assumed to be efficiently recognizable.

Finally, if (7) holds, every nonzero normalized amplitude of (19) differs multiplicatively from that of $\operatorname{vec}e^{\beta A/2}/\sqrt{\operatorname{Tr}e^{\beta A}}$ by a factor between $(1-\alpha)/(1+\alpha)$ and its reciprocal. This bounds vector and pure-state trace distance by $O(\alpha)$, without a dimension factor. The physical marginal is $CC^{\mathsf T}/\operatorname{Tr}CC^{\mathsf T}$, approaching $\rho_\beta$.

The same argument survives any nonzero coordinate pinning: both unnormalized amplitude vectors retain the same relative inequality before renormalization. This is the source of the probability-free herald guarantee.

## 6. Relative Renyi moments of the true thermal state

Let $D_C=CC^{\mathsf T}$, $Z_C=\operatorname{Tr}D_C$, and let $U_S$ cyclically permute the $q$ replicas on subsystem $S$ while acting trivially on $S^c$. The replica identity is

$$
 M_q(\rho_{C,S})=
 \operatorname{Tr}(\rho_{C,S}^{q})
 =\frac{\operatorname{Tr}[D_C^{\otimes q}U_S]}{Z_C^q}.
 \tag{21}
$$

The numerator is a positive contraction of $2q$ copies of the product network. It can be exponentially small relative to $Z_C^q$, but this is irrelevant to the relative-counting guarantee. The counting interface remains the same after replica rewiring.

The transfer from the rational product to the **true** Gibbs state is the substantive precision issue. For $\alpha\leq1/2$, (7) implies $e^{-2\alpha}K\leq C\leq e^{2\alpha}K$ entrywise. Products and sums of nonnegative entries preserve these inequalities. Therefore

$$
 e^{-8\alpha}\rho_\beta\leq\rho_C\leq e^{8\alpha}\rho_\beta
 \quad\text{entrywise}.
 \tag{22}
$$

Taking partial traces preserves entrywise bounds. Every monomial in the trace of a $q$th power has degree $q$, so

$$
 e^{-8q\alpha}M_q(\rho_{\beta,S})
 \leq M_q(\rho_{C,S})
 \leq e^{8q\alpha}M_q(\rho_{\beta,S}).
 \tag{23}
$$

Choose $\alpha=\epsilon/(100q)$. Estimate the numerator of (21) to relative accuracy, for example, $\epsilon/20$ and $Z_C$ to relative accuracy $\epsilon/(20q)$, with the allocated failure probabilities. The combined logarithmic errors give the claimed relative-$\epsilon$ estimate. The constants have slack for finite-bit logarithms and amplification.

For $S_q=\log M_q/(1-q)$, an $\epsilon$-relative moment estimate gives entropy error at most $2\epsilon/(q-1)$ for $\epsilon\leq1/2$. Choosing the moment budget accordingly yields any requested additive entropy accuracy. No $M_q^{-1}$ is hidden in this conversion.

This is not a claim that conventional swap-observable measurement has favorable variance. It is a different classical computation of the same scalar through relative counting. Nor is it a claim that the subsystem's exponentially large density matrix is output explicitly.

## 7. Following the consequence to ground states

### 7.1 Componentwise access inside a specified sector

Assume the positive-edge graph is connected, and fix a particle-number sector $1\leq k\leq n-1$. The sector restriction of $A$ is symmetric, nonnegative and irreducible. Let its top eigenvalue be $\Lambda$, its positive normalized eigenvector be $v$, and suppose an explicit rational $\Delta>0$ lower-bounds the gap to the next eigenvalue. This is a supplied promise, not a gap-recognition algorithm.

**Lemma 3 (acquired overlap bound).** With $D=n^2$ and $f_{\min}$ as above,

$$
 v_x\geq\mu:=2^{-n/2}(f_{\min}/V)^D
 \quad\text{for every configuration in the sector}.
 \tag{24}
$$

**Proof.** Choose $y$ of maximum amplitude, so $v_y\geq2^{-n/2}$. Along an allowed swap $x\leftrightarrow z$, the eigenvector equation gives $\Lambda v_x\geq f_{\min}v_z$. Use $\Lambda\leq V$, the short-path lemma, and $f_{\min}/V\leq1$. $\square$

For any explicit basis string $s$ of weight $k$, spectral decomposition and Cauchy--Schwarz give

$$
 \left|e^{-t\Lambda}(e^{tA})_{xs}-v_xv_s\right|
 \leq e^{-t\Delta}.
 \tag{25}
$$

Consequently, if

$$
 t\geq\frac{n\log2+2D\log(V/f_{\min})+\log(1/\alpha)}{\Delta},
 \tag{26}
$$

the whole column $(e^{tA})_{\cdot s}$ is componentwise relatively $\alpha$-close to the unknown scalar multiple $e^{t\Lambda}v_s v$. Neither $\Lambda$ nor $v_s$ must be computed. A rational time satisfying (26) can be obtained by replacing the logarithms by simple integer upper bounds from bit lengths.

Apply Lemma 1 at this time, pin the input column to $s$, and normalize by the doubled-network count. This supplies coherent preparation and classical Born sampling of the sector ground state. The runtime is polynomial in input length, $n$, $1+tV$, inverse accuracy and log failure. In particular it has polynomial dependence on $V/\Delta$ and logarithmic dependence on $V/f_{\min}$; there is no inverse-overlap factor.

For relative ground-state Renyi moments, use $\alpha=\epsilon/(100q)$ in both (26) and Lemma 1. Before normalization the column-to-ground-vector ratio has logarithmic error at most $4\alpha$; after normalization at most $8\alpha$. The pure-state replica numerator has degree $2q$ in the amplitudes and is a nonnegative sum. Its distortion is therefore at most $e^{\pm16q\alpha}$. The same contraction and denominator estimates used in Section 6 complete a relative FPRAS for the sector ground state's $q$th subsystem moment.

Thus a polynomial gap promise, rather than a nonvanishing product overlap promise, suffices for this componentwise sector result. This particular column construction does not identify the global-ground sector. The different argument in Section 7.2 removes that requirement for global ground-space replica access. Empty/full sectors are one-dimensional and trivial. Disconnected graphs can be treated componentwise for specified component charges.

Without any gap promise, thermal preparation still produces low-energy states: Gibbs entropy gives $\operatorname{Tr}(H\rho_\beta)-E_0\leq n\log2/\beta$. This is a routine consequence, not a first ground-energy/preparation claim.

### 7.2 Global ground-space replicas without identifying a sector

Let $P_0$ be the projector onto the global ground space and define
$\rho_0=P_0/\operatorname{Tr}P_0$. Suppose a rational $\Delta>0$ lower-bounds
the energy difference from that space to the first excited level. The rank of
$P_0$, its energy, and its particle-number sectors need not be supplied. If the
whole Hilbert space is the ground space, the conclusion is trivial.

Write $N=2^n$ and $d_S=2^{|S|}$. The Gibbs weight outside the ground space gives

$$
 T(\rho_\beta,\rho_0)\leq N e^{-\beta\Delta}.
 \tag{26a}
$$

This remains valid for arbitrary ground degeneracy: if its rank is $g$, the
excited-to-ground weight ratio is at most $(N-g)e^{-\beta\Delta}/g$.
For any density matrices $\sigma,\omega$ and integer $q\geq2$, telescoping
matrix powers and the trace-norm inequality imply

$$
 |\operatorname{Tr}\sigma^q-\operatorname{Tr}\omega^q|
 \leq q\|\sigma-\omega\|_1.
$$

Partial trace contracts trace distance, and every density matrix on $d_S$
dimensions obeys $\operatorname{Tr}\omega^q\geq d_S^{1-q}$. Consequently

$$
 \left|\frac{\operatorname{Tr}(\rho_{\beta,S}^q)}
 {\operatorname{Tr}(\rho_{0,S}^q)}-1\right|
 \leq 2qN d_S^{q-1}e^{-\beta\Delta}.
 \tag{26b}
$$

Choose a rational inverse temperature satisfying

$$
 \beta\Delta\geq n\log2+(q-1)|S|\log2+\log(8q/\epsilon).
 \tag{26c}
$$

The true thermal moment is then relatively $\epsilon/4$-close to the desired
ground-space moment. Estimate that thermal moment by Section 6 to relative
error $\epsilon/4$. The two relative errors compose to less than $\epsilon$.
This proves a conditional relative FPRAS for
$\operatorname{Tr}[(\operatorname{Tr}_{S^c}\rho_0)^q]$ with time polynomial in
input length, $n$, numerical $q$, $V/\Delta$, $\epsilon^{-1}$, and log failure.
No sector-identification, ground-degeneracy, product-overlap, or inverse-purity
oracle is used. For a unique ground state this is its subsystem Renyi
entanglement entropy; for a degenerate ground space it is the subsystem Renyi
entropy of the normalized ground-space mixture, not a selected pure state.

There is no conflict with the trace-distance obstruction below. Here the
**physical inverse temperature** makes the state error exponentially small in
polynomial time scale, while the counting accuracy stays at polynomial
relative precision. Calling an ordinary state compiler at exponentially small
requested error would instead be too costly and is not this algorithm.

## 8. Exact obstructions to stronger automatic claims

### 8.1 Trace-distance error does not protect purity

Let $\omega=I_d/d$ and $\sigma=(1-u)I_d/d+u|0\rangle\langle0|$. Then

$$
 T(\omega,\sigma)=u(1-1/d),\qquad
 \frac{\operatorname{Tr}\sigma^2}{\operatorname{Tr}\omega^2}
 =1+u^2(d-1).
 \tag{27}
$$

Taking $u=d^{-1/4}$ makes trace distance vanish while the purity ratio diverges like $\sqrt d$. This invalidates the attempted shortcut from an ordinary state-approximation guarantee to relative replica accuracy. Lemma 1, not ordinary Trotter convergence, repairs this step.

### 8.2 Integer replicas do not automatically give von Neumann entropy

In a common sufficiently large ambient dimension, consider a spectrum

$$
 \left(\frac12,\underbrace{\frac{1}{2R},\ldots,\frac{1}{2R}}_{R\text{ entries}},0,\ldots\right).
$$

Its integer moments and von Neumann entropy are

$$
 M_q(R)=2^{-q}(1+R^{1-q}),\qquad S_1(R)=\log2+\tfrac12\log R.
 \tag{28}
$$

Replacing $R$ by $R^2$ changes every moment with integer $q\geq2$ by relative error at most $1/R$, but changes $S_1$ by $\tfrac12\log R$. With $R=2^n$, polynomial-relative-precision replica access cannot distinguish a linear entropy difference. This is a rigorous obstruction to a **black-box moment-to-entropy inference**, not a hardness theorem for the Hamiltonian family (1). A structural theorem about its entanglement spectrum could still bypass it.

### 8.3 The local cone boundary is real for this representation

For $d>f$ the Hessian eigenvalue $-a+b-c=t(d-f)$ is positive in addition to $a+b+c$. For $d<-f$, $a-b-c=t(-d-f)$ is positive. Thus the log-concavity premise fails at every positive step size outside $|d|\leq f$. Shrinking the time step does not repair it. Positive external-variable scalings act by Hessian congruence and do not remove this extra positive direction. This is a precise obstruction to the present local reduction, not a claim of computational hardness outside the cone.

General complex phases, transverse fields, arbitrary measurements, general tensor networks, arbitrary postselection predicates, and analytic continuation in replica number have not been acquired by this argument.

## 9. Prior-art boundary and significance

The bibliographic audit changed the proposed claims. Hastings, Gonzalez, Kallin and Melko (2010) already developed the swap-replica estimator and a ratio improvement for Monte Carlo Renyi calculations; neither replica rewiring nor Renyi estimation itself is new here. Bravyi and Gosset (2017) already give classical partition-function algorithms for a two-axis ferromagnetic family. Wong, Bravyi, Gosset and Liu (February 2026) give a Lee--Yang tensor framework and a quasipolynomial state-preparation result under a strict radius promise. Bravyi, Gosset, Liu and Wong (July 2026) already give polynomial-time quantum low-energy preparation for Suzuki--Fisher systems, including bipartite Heisenberg examples. Wei (September 2026, v2) gives deterministic classical ground-energy and stable product-query algorithms with fixed positive-field and bounded-degree hypotheses. Chen--Liu (October 2026) already resolves the specified EPR/bipartite energy and partition-function counting problems.

Accordingly, this note does **not** claim the first efficient ground-state preparation algorithm, the first six-vertex FPRAS, or the first EPR energy algorithm. Its candidate increment is the combination of the entrywise-relative compiler, acquired short-path bounds, doubled/pinned/replica closure, the full rational easy-plane longitudinal-field interface, and relative thermal/sector-ground/global-ground-space Renyi access without inverse rare-event or inverse-purity costs. Novelty of that combined statement has not been cleared by external experts or an exhaustive literature search.

The main scientific opportunity is a uniform computational interface to interacting spin states and their replica observables on arbitrary graphs. The polynomial degrees inherited from (4), followed by large product networks and reversible simulation, are severe. This is a complexity-theoretic capability, not a practical large-lattice implementation or a demonstrated hardware advantage.

## 10. What was actually checked

The companion script `checks/check_mechanisms.py` was run in this checkpoint. It checks 7,362 exact word-embedding inequalities, 154 exact rational scalar-tail coefficient inequalities, 45 local-cone fixtures and two outside-cone counterexamples, 99 exact pinned/doubled/replica contraction identities, 12 small spin-kernel relative comparisons, three sector Perron-vector diagnostics, 63 small global-ground-space moment-transfer diagnostics (including degeneracies), and exact examples of the entropy obstructions. The replica fixtures include nontrivial positive one-site diagonal fields. The kernel and Perron tests use floating-point linear algebra and are diagnostics only; the enumerations and stated rational identities use exact integer/Fraction arithmetic.

No independent subagents were available or run. These are different checks within one derivation, not independent human or model proof audits. No full corpus proof certification, general FPRAS execution, large-system experiment, or formal proof-kernel verification was performed.

\small

## References and retrieval scope

1. X. Chen and K. Liu, *An FPRAS for Counting Common Bases of Two Matroids*, arXiv:2610.06724v1. Theorem 5.1, rational implementation Remark A.4, Sections C.6--C.7, and supporting interfaces consulted. Several decisive PDF pages were visually checked; the entire source proof was not independently certified. <https://arxiv.org/abs/2610.06724>
2. Astra Research Knowledge, `00_START_HERE.txt`, `01_CORE.txt`, N63 projected-Slater preparation and its proof, N57 finite-bit PEPS scope; selected source directories. N63 is inherited internal research, not external validation. <https://github.com/harjassand/astra-research-knowledge>
3. B. Wong, S. Bravyi, D. Gosset and Y. Liu, *Lee-Yang tensors and Hamiltonian complexity*, arXiv:2602.03605v1. State-preparation theorem and XXZ/six-vertex discussion consulted. <https://arxiv.org/abs/2602.03605>
4. S. Bravyi and D. Gosset, *Polynomial-time classical simulation of quantum ferromagnets*, arXiv:1612.05602v1; Phys. Rev. Lett. 119, 100503 (2017). Algorithm and positive-gate/partition-function representation consulted. <https://arxiv.org/abs/1612.05602>
5. S. Bravyi, D. Gosset, Y. Liu and B. Wong, *Efficient quantum algorithm for Heisenberg spin systems*, arXiv:2607.14401v1. Model scope, Theorem 1 and Corollaries 1--2 consulted. <https://arxiv.org/abs/2607.14401>
6. D. Wei, *Generators of stability-preserving semigroups, spectral gaps, and classical ground-state computation*, arXiv:2609.26802v2. Sections 6.1--6.6 and stated parameter/measurement restrictions consulted. <https://arxiv.org/abs/2609.26802>

7. M. B. Hastings, I. Gonzalez, A. B. Kallin and R. G. Melko, *Measuring Renyi Entanglement Entropy with Quantum Monte Carlo*, arXiv:1001.2335v2; Phys. Rev. Lett. 104, 157201 (2010). Abstract and stated swap/ratio-estimator contribution consulted; not a complete audit of its convergence guarantees. <https://arxiv.org/abs/1001.2335>

