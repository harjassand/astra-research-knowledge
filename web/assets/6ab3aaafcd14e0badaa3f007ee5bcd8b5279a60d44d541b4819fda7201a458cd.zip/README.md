# Astra positive-kernel / replica-access checkpoint

Start with `state/RESUME.md`. The mathematical note is available as `relative_kernels_and_replica_access.pdf` and as `proofs/relative_kernels_and_replica_access.md`.

Status: conditional on Chen--Liu (arXiv:2610.06724v1), unreviewed, novelty unresolved. No general FPRAS or quantum compiler implementation. No independent subagents or formal proof verification.

Run diagnostics with:
```sh
python checks/check_mechanisms.py
```
Requires Python, NumPy and SciPy. All exact checks use the standard-library Fraction/integer types. Numerical checks are labeled separately.

The checkpoint preserves the main proofs, acquired interfaces, counterexamples, prior-art corrections, alternative state-only route, source scope, machine-readable result cards, and executed check outputs. It was created locally; the GitHub repository was not modified.

OpenAI's mathematics catalogue was used as frontier context through its public repository overview; no OpenAI result family is a load-bearing premise of Lemma 1 or this particular spin-system reduction. The selected route emerged from the broader repository audit and current counting literature.

Recompile the PDF (Pandoc and XeLaTeX required):
```sh
pandoc proofs/relative_kernels_and_replica_access.md --pdf-engine=xelatex -H proofs/header.tex -o relative_kernels_and_replica_access.pdf
```

The final extension in Section 7.2 removes sector identification for global
ground-space replica moments, while retaining a supplied global gap. The
normalized ground-space mixture is the target when the ground is degenerate.
