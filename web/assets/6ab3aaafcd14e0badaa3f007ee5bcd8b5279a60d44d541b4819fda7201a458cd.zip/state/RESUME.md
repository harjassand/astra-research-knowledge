# Resumable research state: positive kernels / replica access
Date: 2026-10-07. Local checkpoint, not a GitHub commit.

## Start here
Read `proofs/relative_kernels_and_replica_access.md` (same content as the PDF), then `RESULT_CARDS.json`, `FAILED_ROUTES.md`, and `checks/results.json`.
The strongest current candidate is **conditional relative replica access for thermal states, gapped-sector ground states, and normalized global ground-space projectors of easy-plane XXZ systems**, obtained via a new positive-word entrywise-relative product bound. Do not describe it as certified, priority-cleared, practical hardware, or first ground-state preparation.

## Load-bearing imported capital
Chen--Liu arXiv:2610.06724v1 Theorem 5.1 + Remark A.4: homogeneous multiaffine nonnegative log-concave complementary-degree coefficient FPRAS, rational oracles, support witnesses, coefficient ranges, every-execution time cap. Base cost O(M^10 B^2 eta^-2 log^2(2B/eta)); amplify logarithmically. Entire theorem not independently certified or implemented here.
Astra N63: weighted-prefix randomized coherent compiler, not exponentially good tapes. Source proof partially retrieved far enough to read this lemma and acquired interfaces. N57 checked to exclude a misleading PEPS/acquisition overlap.

## Main acquired physical interface
H = (1/2) sum_e [d_e ZZ - f_e(XX+YY)] + sum_i h_i Z,
f_e >= |d_e|, all rational, arbitrary graph and signed longitudinal fields.
A=cI-H=sum nonnegative local A_j,
c=sum |d_e|/2+sum|h_i|,
V=sum(f_e+max(d_e,0))+2sum|h_i| bounds sum local norms.
Edge A has outer diagonal d_-; middle diagonal d_+; exchange f.
Identity-plus-step gate weights a=1+t d_-, b=1+t d_+, c=tf satisfy linear triangles at sufficiently small t. Field gate gives a positive linear two-port polynomial.
Bipartite antiferromagnetic XXZ is mapped by Z on one sublattice. Isotropic bipartite Heisenberg and zero-field EPR (the latter after uniform local Clifford change) are covered. Do not claim arbitrary EPR-basis fields are covered.

## New analytic mechanism
For nonnegative A=sum A_j, kernel K=e^(tau A), lower bound lambda on all nonzero entries:
C=[product_j(I+tau A_j/m)]^m satisfies (1-alpha)K <= C <= (1+alpha)K ENTRYWISE.
Choose B0 with 2^-B0 <=lambda, k0>=max(1,ceil(6 tau V), B0+ceil log2(64/alpha)), m>=max(2k0,ceil(8k0^2/alpha)).
Proof: coefficient of each length-k word has embedding count between binom(m,k) and binom(m+k-1,k); truncated ratio exp(+-k0^2/m); both tails bounded coefficientwise by exp(tau V z), hence <=2^-k0.
No inverse-lambda cost, only logarithm. Generic lemma does NOT make arbitrary positive matrices efficiently countable.
For XXZ, support is equal particle counts per connected component; exclusion path length D=n^2. lambda=min(1,tau f_min)^D/D! is acquired and has polynomial bit length. If no edges, diagonal case lambda=1.

## Counting and coherent interfaces
Closed doubled/pinned/replica networks = [all incidence variables] f*g.
f=product local degree-two six-vertex and degree-one field polynomials; g=product one-per-wire linear sums. Degrees each M/2. Closed wires with two ports at one node allowed by direct coefficient representation despite source corollary's loopless wording.
Pins replace a wire factor in g by a monomial. Exact support via capacitated incidence matching/max-flow. Coefficient queries explicit rational lookup/products; log ranges polynomial. All acquired.
Transpose reverses circuits/ports; remains same local classes. Replica permutations only rewire boundary wires.
Coherent compiler uses one padded random tape per depth, weighted true-prefix bad mass. Error <=4r eta+2r sqrt(zeta/delta). r<=2n. Counts finite-bit and every-execution capped. Compiler success not efficiently recognized. No free coherent oracle and no physical nonunitary postselection.

## Consequences
Thermal canonical purification: normalize vec C with tau=beta/2. Runtime polynomial in input length,n,1+beta V,1/epsilon,log1/delta. Basis pins/diagonal heralds no inverse event probability.
Integer replica moment: numerator Tr[(CC^T)^tensor q U_S], denominator (Tr CC^T)^q. True Gibbs moment distortion <=exp(+-8q alpha). Choose alpha=epsilon/(100q); count denominator to O(epsilon/q). Arbitrary subsystem size, runtime polynomial numerical q, no inverse purity. Additive integer-order Renyi entropy follows. NOT subsystem von Neumann entropy.
Sector ground state: connected positive-edge graph, specified particle-number sector, supplied gap lower bound Delta. Positive v_x>=mu=2^(-n/2)(f_min/V)^(n^2). Column e^(tA)|s> relative to unknown scalar*v at error alpha once t>=[n ln2+2n^2 ln(V/f_min)+ln1/alpha]/Delta. Exact v_s or Lambda not needed. Apply entrywise product, column pin, doubling/replicas. Quantum preparation + classical relative Renyi/Born access; inverse gap charged, inverse overlap not charged. This COLUMN route requires the correct sector; the stronger GLOBAL-REPLICA route PK7 below does not.

## Verification and priority
One derivation; no independent subagents/humans/formal kernel. `checks/check_mechanisms.py` executed. Exact: 7362 word bounds,154 scalar coefficient bounds,45 cone cases+2 failures,99 contraction/pin/replica identities, counterexample spectra. Numerical:12 kernel fixtures,3 PF sector fixtures,63 global ground-space transfer fixtures. Tests are not FPRAS implementation or proof certification.
Prior art located: Bravyi--Gosset 2017; Wong et al Feb2026 (LY state prep); Bravyi et al July2026 (quantum low-energy prep already); Wei Sep2026 v2 (fixed-positive-field bounded-degree deterministic state queries); Chen--Liu Oct2026 (count/partition/energy already). No novelty clearance.

## Highest-priority decisive audit
Reconstruct the imported FPRAS theorem fully, especially rational worst-case runtime and log-concavity-only hypotheses; independently audit incidence encoding with signed-field gates, replica rewiring and all pins; seek specialist review of the combined relative-Renyi claim. The elementary word lemma, sector bound, and global gap-to-replica transfer have complete arguments in the proof note.
Do not restart by repeating the ordinary trace-distance Trotter approach: it cannot protect tiny moments. A further leap to von Neumann entropy needs more than polynomial-precision integer replicas; explicit indistinguishable-moment spectra are saved. A leap outside |d|<=f needs a different representation, not smaller steps: the Hessian has two positive eigenvalues for every t>0.

## Coverage honesty
Repository core was used as a cross-field map. Deep new work concentrated on counting, positive tensor networks, quantum spin kernels and entropy after that audit. This was not a fresh proof-level investigation of every requested field, not a full ingestion/certification of all OpenAI manuscripts, and not a parallel-agent campaign. No OpenAI result-family theorem is load-bearing for this selected result.


## Stronger final consequence: global ground-space replica access (PK7)

Sector identification is needed for the specified-column componentwise route,
but NOT for replica moments of the normalized global ground-space mixture.
For P0 the global ground projector, rho0=P0/rank(P0), a supplied gap Delta above
that space gives T(rho_beta,rho0)<=2^n exp(-beta Delta), regardless of unknown
ground degeneracy. For subsystem dimension dS=2^|S| and integer q>=2,
relative moment error <=2q*2^n*dS^(q-1)*exp(-beta Delta), since moment >=dS^(1-q)
and |Tr sigma^q-Tr omega^q|<=q||sigma-omega||1. Choose
beta Delta >=n ln2+(q-1)|S|ln2+ln(8q/eps); count true thermal moment to relative
eps/4. Final error <eps, cost poly(n,q,V/Delta,inputbits,1/eps,log failure),
without knowing E0, ground rank, sector, overlap or purity. Unique-ground case
gives pure-state entanglement Renyi; degenerate case gives normalized
projector mixture, NOT an arbitrary selected ground state. Exponentially small
state error comes from beta, not an exponentially accurate counting call.

Additional prior art: Hastings/Gonzalez/Kallin/Melko arXiv:1001.2335v2 (2010)
already introduced swap-replica and ratio estimators for Monte Carlo Renyi.
Do not claim first replica estimator or first Renyi method. Abstract inspected;
its full convergence scope has not been audited. 63 small numerical transfer
tests include degenerate global ground spaces; not an algorithm implementation.
