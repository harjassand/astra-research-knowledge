# Failed routes, boundaries, and retained alternatives

1. **Coherent history sampling is not coherent boundary preparation.** A history distribution with weights w yields amplitudes sqrt(w) on history registers. The boundary amplitude needed here is a sum of path weights. Discarding or coherently erasing histories is not free. Remedy: count squared boundary amplitudes by a doubled network and compile its prefix masses.

2. **Trace-distance/norm Trotter error is insufficient for relative replicas or rare conditioning.** Exact counterexample: omega=I_d/d, sigma=(1-u)omega+u|0><0|. Trace distance u(1-1/d), purity ratio 1+u^2(d-1). Taking u=d^-1/4 defeats the intended inference. Remedy: the new entrywise multiplicative product formula.

3. **An exponentially good random tape at every prefix is unnecessary and unaffordable.** Use true-prefix-weighted bad mass and a unitary hybrid (inherited N63). Still requires every-execution finite-bit time bounds, explicit oracles and total fallback logic; expected runtime alone is insufficient.

4. **Generic phase/sign transfer is not acquired.** Positive word comparison uses no cancellation. Arbitrary complex phases and transverse fields need new interfaces. No generic sign-problem solution or postselected BQP simulation follows.

5. **Smaller time steps do not cross the easy-plane boundary.** For d>f, -a+b-c=t(d-f)>0; for d<-f, a-b-c=t(-d-f)>0, in addition to the positive Perron Hessian eigenvalue. Positive variable scalings preserve inertia. This blocks the current local log-concave representation for every positive t, not every conceivable algorithm.

6. **Integer replicas do not automatically give S1.** Spectrum (1/2,1/(2R) repeated R) has M_q=2^-q(1+R^(1-q)), S1=ln2+0.5lnR. R vs R^2 differs by <=1/R relatively at every integer q>=2 but by 0.5lnR in S1. This is an interface obstruction, not XXZ-family hardness. Analytic continuation, partial-transpose absolute values and complete entanglement spectra remain unacquired.

7. **A ground gap is still a supplied promise.** The componentwise column route fixes a sector; its basis-overlap lower bound is acquired, but its gap is not. The later global thermal-to-replica corollary PK7 removes sector identification and handles unknown degeneracy for the specific target P0/rank(P0). It still requires a supplied global gap and does not select an arbitrary pure state from a degenerate ground space.

8. **Prior-art correction.** Efficient quantum low-energy preparation was already established by Bravyi--Gosset--Liu--Wong July2026 for a broad related family. Remove any first-preparation claim. Chen--Liu already supplies EPR energy/partition counts. The 2010 Hastings et al. swap/ratio method also rules out a first-replica-estimator claim. Strongest candidate is the precise worst-case relative-kernel + conditioned/coherent/replica interfaces and gap-conditioned relative ground-space entropies.

9. **State-only alternative retained.** For Hermitian X,Y, canonical purified Gibbs vectors psi_X=vec(e^(X/2))/sqrt Tr e^X obey ||psi_X-psi_Y||<=||X-Y||/2. Proof: differentiate along the segment; D exp(X/2)[V]=(1/2) integral e^((1-s)X/2)V e^(sX/2) ds. Schatten Holder bounds its Frobenius norm by ||V|| sqrt Z/2; normalization projects out a parallel component. Integrate. This can combine with ordinary symmetric log-product estimates for a simpler trace-distance-only algorithm, but not relative rare observables.

10. **Optional faster EPR-only positive product.** For A=sum p_e R_e with positive projectors R_e, sum p=1, use palindromic factors I+H_j+H_j^2/2, H_j=t p_e R_e/2, list then reverse. Degree <=2 agrees with e^(tA); norm error <=e^t t^3/3. The palindrome is FF^T>=I, as is e^(tA), so integral-resolvent log Lipschitz gives ||log B-tA||<=e^t t^3/3. The factors remain I+sR and countable. This may reduce the state-only slice count. It is not used in the main relative-kernel theorem; do not apply its PSD-factor argument to general indefinite XXZ local A_e.
