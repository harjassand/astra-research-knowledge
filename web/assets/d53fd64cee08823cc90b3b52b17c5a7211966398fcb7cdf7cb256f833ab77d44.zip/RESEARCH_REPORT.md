# Relative access to rare ground-state structure

## Outcome

This run does not establish a field-breaking discovery. It develops a candidate conditional algorithmic interface that goes beyond thermal-state preparation: coherent access to a selected pure ground vector, classical relative estimation of rare ground-state events and fidelities, and relative entanglement-moment access even after rare computational-basis conditioning. It also identifies precise failures of two attempts to extend that interface to the broader EPR* family.

The model is H=.5 sum[d ZZ-f(XX+YY)]+sum hZ-sum gX on an arbitrary graph, with rational f>=|d|, g>=0 and arbitrary h. The target is psi0=P0|+>/||P0|+>||. This remains a specific PURE vector when the ground space is degenerate. It is not a request for an arbitrary ground vector.

The algorithmic premise is Chen–Liu, arXiv:2610.06724v1, Theorem1.6 and its finite-bit implementation. This is a major external mathematical dependency, not an acquired implementation in this checkpoint. Its full proof was not independently certified. The target-ground guarantees also need a supplied gap above the entire ground space, except when an applicable proved gap bound can be imported.

## The mechanism and the additional step

Astra X already supplies positive-word relative approximation and coherent/replica counting mechanisms. The present construction uses a positive boundary vector instead of an individual kernel entry: e^{tau A}1 has every coordinate at least one, for A=cI-H entrywise nonnegative. A truncated-word tail only needs to be controlled against this boundary floor. The resulting relative-vector product is polynomial in tau V, n and inverse relative accuracy.

The nonhomogeneous transverse factor c+u+v+cuv is admitted for c<=1. This uses the counting theorem's nonhomogeneous interface. Norm and replica contractions remain in the allowed class only after the bra incidence variables are complemented; then internal wires are positive linear polynomials. The coefficient programs, positive supports and coefficient-range bit lengths are explicitly accounted for.

A further Perron-vector argument handles rare ground events. Every configuration component has diameter at most D=2n^2. If r is the smallest positive exchange/flip coefficient and V bounds the positive generator norm, every nonzero selected-ground amplitude is at least

    gamma = 2^-n min(1,r/V)^D.

The logarithm of gamma^-1 is polynomially bounded by the input description, although gamma itself can be exponentially small. With a supplied gap Delta, cooling to amplitude error O(epsilon gamma) costs tau Delta=O(n+log1/gamma+log1/epsilon). Crucially, the finite-time vector is then approximated RELATIVELY, so the circuit and counting accuracy do not scale as gamma^-1.

A basis cylinder event has ground probability zero or at least gamma^2. A threshold distinguishes these cases with high probability; a positive probability can be estimated relatively, and the conditioned pure state can be compiled without inverse-success-probability cost. For two admitted selected ground states, a nonzero overlap is at least gamma_H gamma_K. The same argument protects the relative fidelity. Integer-replica contractions remain positive after pinning and therefore yield relative Renyi moments and min-entropy/maximum-Schmidt-weight access.

These are model-aware classical counting and circuit-compilation algorithms, not a physical operation that makes arbitrary quantum postselection free.

## What does and does not change

Ground-state probabilities, fidelities and subsystem purities may be exponentially small. Protecting them relatively is stronger than merely preparing a nearby density matrix or estimating an energy additively. The candidate construction avoids an inverse-small-quantity factor by paying logarithmically for cooling and using positive relative contractions.

The result is still complexity-theoretic. The counting bound has a high polynomial degree and the product network can be very large. There is no implemented general FPRAS, no tested large-scale quantum compiler and no practical runtime benchmark. Inverse spectral gap remains a real resource.

An important priority correction occurred during the run: Bravyi–Gosset–Liu–Wong, arXiv:2607.14401v1, already proves the sharp 2 min field gap and quantum low-energy preparation for the larger Suzuki–Fisher family. Hadamard rotation puts our positive-field model in that class, so Delta=2 min g is an available imported certificate when all g>0. The gap theorem and quantum low-energy capability are not new discoveries here. Earlier Bravyi–Gosset1612.05602 and the October Chen–Liu EPR applications also require credit. Priority for the narrower combined relative interfaces remains unresolved.

## Stronger target and obstruction

For EPR*, the stoquastic local gates lie on the critical eight-vertex surface b=a+c+d. Their local polynomial has pair-creation terms and fails log-concavity at arbitrarily small step size. An exact positive three-connection representation exists, but one connection carries a bit-flip parity constraint. Three such signed swaps around a triangle have trace0, while erasing the constraints gives trace4. Thus counting two spin assignments per ordinary loop is wrong.

An independent on-site-basis argument uses the unique weak singular axis of the interaction. A reduction to the number-conserving easy-plane cone requires local +/-Y charges that alternate along every edge, so an odd cycle forbids that reduction. These obstructions do not exclude ancillas, other gadgets, nonlocal transformations or other algorithms. General EPR* and Astra W's microscopic determinant-parity sampler remain unresolved.

## Structural results and validation

The local log-concavity cone is classified explicitly for real-symmetric two-qubit generators with nonnegative off-diagonals: no pair creation; single-flip rates independent of the neighbor; and a sharp bound on the mixed diagonal difference by twice the exchange rate. Stable amplitudes are preserved, but squared amplitudes need not inherit any dimension-independent fractional-log-concavity parameter. An explicit constant-gap complete-bipartite ground-state family forces that parameter to be O(1/n). This prevents confusing a physical spectral gap with a particular classical Born-law curvature condition.

Three diagnostic programs were run and replayed. They include symbolic identities, exact rational network/prefix checks, exact coefficient-profile and eigenvector examples, dense finite Hamiltonians, and 100-digit rare-event/fidelity cases. These are checks, not independent proofs. No independent workers or formal proof assistant were used.

For the complete derivations, limitations and source routes, read the four proof notes, `state/RESULT_CARDS.json`, `state/FAILED_ROUTES.md`, and `sources/PROVENANCE.json`. No changes were committed to GitHub.
