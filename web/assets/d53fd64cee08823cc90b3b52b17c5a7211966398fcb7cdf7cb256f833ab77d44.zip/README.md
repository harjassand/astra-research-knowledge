# Astra research checkpoint — positive-boundary ground-state access

**8 October 2026. No established field-breaking result or resolved priority claim.**

This checkpoint develops candidate conditional algorithms for a specified easy-plane stoquastic spin family, and proves scoped structural statements and counterexamples in accompanying notes. Its most extended interface is classical relative access to very small ground-state event probabilities, pure-state fidelities and integer-replica entanglement quantities, together with coherent preparation after a specified rare computational-basis event.

The polynomial-time conclusions import **Chen–Liu, arXiv:2610.06724v1, Theorem 1.6 and its finite-bit implementation**. This run did not independently certify that full proof or implement the FPRAS. A supplied gap above the whole ground space is required for exact-ground-target approximation. When every transverse field is positive, a gap bound is available from **Bravyi–Gosset–Liu–Wong, arXiv:2607.14401v1**; that is prior work, not an Astra gap discovery.

## Read in this order

1. `state/RESUME.md` gives the compact state, strongest formulas, dependencies and remaining obstruction.
2. `proofs/positive_boundary_ground_states.md` gives the base construction, acquired count programs and weighted-prefix compiler.
3. `proofs/rare_ground_events_and_fidelity.md` adds the logarithmic nonzero-amplitude floor, rare ground conditioning, relative fidelity, and conditioned entanglement access.
4. `proofs/local_cone_and_stability.md` classifies the local complemented-polynomial interface and gives exact stable-amplitude/Born-law examples.
5. `proofs/epr_star_obstructions.md` records the stronger attempted target and exact failed transfers.

`state/RESULT_CARDS.json` contains scoped machine-readable results. `state/FAILED_ROUTES.md` preserves failures and prior-art corrections. `sources/PROVENANCE.json` records selected primary sources and repository routes, not a claim that every source proof was certified. Third-party manuscripts are not bundled.

## What was executed

Three scripts test symbolic identities, exact rational finite networks, dense small Hamiltonians, and high-precision rare-event examples. From this directory:

```bash
python checks/check_results.py
python checks/check_stability_and_energy.py
python checks/check_rare_ground.py
```

The scripts overwrite only their own result JSON files. They require Python 3, numpy, scipy, sympy and mpmath. See `sources/EXECUTION_ENVIRONMENT.json` for the versions actually used. They do not access the network.

These are finite diagnostics, not a general sampler, a numerical-performance benchmark, proof-assistant verification, or independent peer review. No independent subagent workers were run. No repository changes were committed. This directory and its ZIP are the preserved research state.

## Claims not made

The run does not solve general EPR*, the determinant-parity sampler in Astra W, general stoquastic ground-state simulation, arbitrary postselection, the von Neumann entropy problem, or a broad complexity-class separation. Quantum low-energy preparation alone already follows from the July Suzuki–Fisher work for a larger family. The new candidate package must be assessed for correctness and priority at its narrower relative-counting and pure-state interfaces.
