# Positive-boundary compilation of interacting spin ground states

**Research checkpoint, 8 October 2026.** These are internally derived candidate theorems, not independently reviewed results. The analytic statements below do not depend on the new counting literature. The polynomial-time algorithmic conclusions are **conditional on Chen–Liu, arXiv:2610.06724v1, Theorem 1.6 and its finite-bit implementation**. That substantial proof has not been independently certified here. Neither its general FPRAS nor a reversible quantum implementation has been run.

The starting capital is Astra package X, especially N95–N98 and its proof `relative_kernels_and_replica_access.md`. Its positive-word argument and weighted-prefix compilation method are inherited. The changes developed here are a positive-boundary relative-vector argument, nonhomogeneous transverse-field factors, gap-free pure low-energy preparation, and selection of a **pure** ground vector, including when the ground space is degenerate. Integer-replica access is followed through to the largest Schmidt coefficient.

## 1. Model and precise outputs

On an arbitrary finite graph with n qubits, consider the rational Hamiltonian

\[
H=\frac12\sum_{e=uv}\{d_e Z_uZ_v-f_e(X_uX_v+Y_uY_v)\}
  +\sum_i h_i Z_i-\sum_i g_i X_i,
\qquad f_e\ge |d_e|,\quad g_i\ge0.
\tag{1}
\]

The longitudinal fields h_i may have either sign. Zero edges are omitted. No geometric, bounded-degree, high-temperature, physical-mixing, or area-law promise is made. Define

\[
V=\sum_e(f_e+\max(d_e,0))+2\sum_i|h_i|+\sum_i g_i.
\tag{2}
\]

Let |+> denote the n-qubit uniform product state. Let P_0 be the orthogonal projector onto the entire lowest eigenspace of H. The selected target is

\[
|\psi_0\rangle=\frac{P_0|+\rangle}{\|P_0|+\rangle\|}.
\tag{3}
\]

This is not P_0/Tr(P_0), not a ground vector chosen by the user, and not a claim about every state in a degenerate ground space.

**Conditional theorem.** Under the stated counting input:

1. For rational tau>0, a randomized classical compiler produces a quantum circuit approximating
   \[
   |\psi_\tau\rangle=\frac{e^{-\tau H}|+\rangle}{\|e^{-\tau H}|+\rangle\|}
   \]
   to trace distance epsilon, with compiler probability at least 1-delta. The compilation time and circuit size are polynomial in the input bit length, n, 1+tau V, epsilon^{-1}, and log(delta^{-1}).
2. For an energy tolerance xi>0, a circuit for a pure state of energy at most E_0+xi is obtained in time polynomial in the input size, n, 1+V/xi, and log(delta^{-1}), **without a spectral-gap promise**. The lowest energy itself is also estimable classically to additive error xi with those polynomial dependencies.
3. If a rational lower bound Delta>0 on the gap **above the entire ground space** is supplied, the compiler prepares an epsilon-approximation to (3), in time polynomial in the input size, n, 1+V/Delta, epsilon^{-1}, and log(delta^{-1}). It does not receive the ground energy, ground-space dimension, particle-number sector, a basis state in the ground support, or an overlap oracle.
4. For a specified subsystem S and integer q>=2, the selected-ground-state moment
   \[
   M_q(S)=\operatorname{Tr}\left[(\operatorname{Tr}_{S^c}|\psi_0\rangle\langle\psi_0|)^q\right]
   \]
   has a classical relative-error approximation with polynomial dependence also on the **numerical value of q**. There is no inverse-M_q factor. This conclusion retains the supplied-gap assumption.
5. The largest eigenvalue of the reduced density matrix, equivalently the squared largest Schmidt coefficient, can be estimated to relative error epsilon. Its negative logarithm (min-entropy) can be estimated to additive error epsilon, with polynomial resources and no supplied entanglement-spectrum gap.

A subsequent primary-source check found that Bravyi–Gosset–Liu–Wong, arXiv:2607.14401v1, already gives quantum adiabatic low-energy preparation for a larger Suzuki–Fisher family. Quantum low-energy preparation alone is therefore not claimed as a new capability. That paper also supplies the gap 2 min_i g_i when all g_i>0; see the rare-events companion note.

Polynomial does not mean numerically practical. The inherited counting bound has a high power of the number of tensor-incidence variables, and the construction uses many Trotter factors. These are complexity-theoretic capabilities, not a demonstrated large-device simulator.

All results are for the basis specified in (1). General sign patterns, arbitrary XYZ interactions and arbitrary projectors are not included. The companion note `rare_ground_events_and_fidelity.md` subsequently acquires a nonzero-amplitude floor and extends the result to rare computational-basis cylinder conditioning, relative ground-state fidelities, and conditioned replica access.

## 2. Acquired positive generators and their local polynomials

For d_+=max(d,0), d_-=max(-d,0), set

\[
A_e=\begin{pmatrix}
d_-&0&0&0\\0&d_+&f&0\\0&f&d_+&0\\0&0&0&d_-
\end{pmatrix},\quad A_i^z=|h_i|I-h_iZ_i,\quad A_i^x=g_iX_i.
\tag{4}
\]

They are entrywise nonnegative. With c=(1/2)sum_e|d_e|+sum_i|h_i|,

\[
A:=\sum_j A_j=cI-H,\qquad \sum_j\|A_j\|_2\le V.
\tag{5}
\]

The scalar c does not affect the normalized vector. For t sufficiently small, each Euler factor is nonnegative and its input-complemented coefficient polynomial is log-concave.

For an edge factor the polynomial, after one fixed port permutation, is

\[
q_e=a(x_1x_2+x_3x_4)+b(x_1x_3+x_2x_4)+c'(x_1x_4+x_2x_3),
\tag{6}
\]

where a=1+td_-, b=1+td_+, c'=tf. Its Hessian eigenvalues are

\[
a+b+c',\quad a-b-c',\quad -a+b-c',\quad -a-b+c'.
\]

The triangle inequalities hold when f>=|d| and tf<=a+b. Thus its Hessian has at most one positive eigenvalue, and this nonnegative homogeneous quadratic is log-concave. In fact it is real stable; an elementary proof is given in the companion note.

For a transverse field let u,v be its output and complemented-input variables. Its polynomial is

\[
q_x(u,v)=tg+u+v+tg\,uv.
\tag{7}
\]

It is nonhomogeneous. This is why Theorem 1.6 of Chen–Liu, rather than only their homogeneous Theorem 5.1, matters.

Here is an explicit local test. For a nonzero polynomial Q=a+bu+cv+duv with nonnegative coefficients,

\[
Q\text{ is log-concave on }\mathbb R_{>0}^2\quad\Longleftrightarrow\quad ad\le2bc.
\tag{8}
\]

Indeed, putting M=Q Hess(Q)-grad(Q)grad(Q)^T gives

\[
M_{11}=-(b+dv)^2,\quad M_{22}=-(c+du)^2,\quad M_{12}=ad-bc,
\]

and

\[
\det M=(2bc-ad+bdu+cdv+d^2uv)(ad+bdu+cdv+d^2uv).
\]

The condition is sufficient term by term and necessary by approaching u=v=0. For (7), it suffices that tg<=1; its stronger real-stability test is 1-(tg)^2>=0.

The longitudinal factor is a positive linear polynomial. A free positive terminal is 1+x. Internal wires are represented by x+y after input complementation. Products on disjoint incidence-variable sets remain log-concave.

## 3. Relative vector approximation without a smallest-entry bound

The following strengthens the useful input side of the inherited positive-word argument.

**Lemma 1.** Let A_1,...,A_s be N-by-N entrywise nonnegative matrices and V>=sum_j||A_j||_2. Put

\[
v=e^{\tau A}\mathbf1_N,\qquad
\widetilde v=C_m\mathbf1_N,\qquad
C_m=\left[\prod_{j=1}^s\left(I+\frac{\tau A_j}{m}\right)\right]^m.
\tag{9}
\]

For 0<alpha<=1/2 choose integers

\[
k_0\ge\max\left\{1,\lceil6\tau V\rceil,
\left\lceil\frac{\log_2N}{2}\right\rceil+
\left\lceil\log_2\frac{64}{\alpha}\right\rceil\right\},
\quad
m\ge\max\left\{2k_0,\left\lceil\frac{8k_0^2}{\alpha}\right\rceil\right\}.
\tag{10}
\]

Then

\[
(1-\alpha)v_x\le\widetilde v_x\le(1+\alpha)v_x\quad\text{for every }x.
\tag{11}
\]

**Proof.** Expand in words in the noncommuting A_j. For a word of length k<=k_0, the ratio of its coefficient in C_m to its coefficient tau^k/k! in the exponential lies between

\[
\prod_{r=0}^{k-1}(1-r/m)\quad\hbox{and}\quad
\prod_{r=0}^{k-1}(1+r/m).
\]

Assigning its letters to distinct sweeps gives the lower bound; assigning weakly increasing sweep numbers gives the upper bound. Therefore the ratios lie between exp(-k_0^2/m) and exp(k_0^2/(2m)). Nonnegativity permits entrywise comparison of the truncated sums.

For T=tau V, the norm of each omitted matrix tail is at most sum_{k>k_0}T^k/k!. The product tail has this same majorant because the scalar coefficient polynomial product_j(1+tau||A_j||z/m)^m is coefficientwise at most exp(Tz). With k_0>=6T, the tail is at most 2^{-k_0}.

Multiplication by 1_N contributes at most sqrt(N) in this norm estimate. Thus each vector-tail coordinate is at most alpha/64. Crucially, v_x>=1 for every x because the identity term is present and all other terms are nonnegative. Absolute tail control of alpha/64 is consequently relative control of at most alpha/64. Combining the truncated-word ratios with the tails proves (11). □

For N=2^n the only dimensional cost in the cutoff is n/2. No graph diameter, minimum nonzero edge, support path, or lower bound on a nonzero matrix entry is needed. This is not an assertion that all matrix entries are relatively approximated by this shorter cutoff; the result is specifically for the positive-boundary vector.

For the spin implementation increase m, if necessary, to at least ceil(tau V). Then all local factors satisfy the conditions in Section 2. The number of factors and their rational bit lengths are polynomial in the displayed parameters.

Normalization changes the bound by only a constant: (11) implies

\[
\left\|\frac{\widetilde v}{\|\widetilde v\|_2}-\frac{v}{\|v\|_2}\right\|_2
\le\frac{2\alpha}{1-\alpha}.
\tag{12}
\]

## 4. Counting the required contractions: orientation and acquisition

Assign a separate variable to every tensor incidence. A gate coefficient is indexed by its output bit and the complement of its input bit. If a physical wire joins an output b to an input a, the gate exponents on its two incidences are b and 1-a. Multiplying by the wire polynomial x+y and extracting one copy of each incidence variable retains exactly b=a.

Let f be the product of gate/terminal polynomials and g the product of wire polynomials. Both are multiaffine and log-concave on their respective incidence variables; variables absent from a factor cause no problem. The desired scalar contraction is

\[
\left[\prod_{v\in\mathrm{incidences}}x_v\right]f(x)g(x).
\tag{13}
\]

For doubled norms and replicas one must orient the bra copies correctly. **A direct output-output equality polynomial 1+xy is not log-concave and must not be inserted.** Complement all incidence bits of each bra copy. Our edge polynomials (6) are invariant under full complement; (7) is also invariant; a longitudinal linear factor merely exchanges its coefficients, and 1+x remains unchanged. Consequently each connection from a ket to a complemented bra is again the admissible x+y wire. In the replica formula every final physical output is paired between a ket and a bra. This supplies the needed orientation for all replica wirings, not just the ordinary norm.

Fixing a physical bit is local coefficient extraction: specialize its incidence variable to zero for exponent zero, or differentiate and then set to zero for exponent one. The polynomials here have degree at most four, so their coefficient tables can simply be enumerated. Each nonzero pinned factor retains log-concavity. Initial positive supports for f and g are obtained by choosing any positive monomial separately in each disjoint local factor. Local inconsistencies are detected exactly. For the positive-boundary finite-time vectors every output prefix actually has positive weight, since an identity history starting at that output is present.

A coefficient query to f is a product of explicitly stored local rational entries, or zero. A query to g is equally explicit. If the sum of local rational encoding lengths is L_net, then log(R_f R_g)=O(L_net). Thus the input is an **acquired** polynomial-time coefficient program and an acquired range bound, not an assumed amplitude or partition-function oracle.

Chen–Liu Theorem 1.6 supplies a relative FPRAS for (13). Its displayed operation/oracle bound is soft-O(M^11 B^2 eta^{-2}), with M the number of incidence variables and B=M+log(R_f R_g). Rational arithmetic and coefficient-query bit costs must also be charged. We import their finite-bit argument, including an every-execution bound needed below, rather than claiming to have implemented it.

## 5. Uniform quantum compilation without an exponential union bound

For a prefix a define

\[
w(a)=\sum_z\widetilde v_{az}^{\,2}.
\tag{14}
\]

Section 4 counts it using two network copies, fixing the prefix and pairing the remaining outputs. At each depth, compute estimates of w(a0),w(a1), rotate a fresh qubit with estimated probability w(a0)/(w(a0)+w(a1)), and uncompute the work registers. Count estimates are clipped to a prescribed finite nonnegative range; a zero estimated denominator uses a fixed fallback rotation. Consequently even erroneous random tapes define a bounded, reversible computation.

Only O(n) random tapes need be chosen, one for each of the two count programs at each depth. Each tape is reused coherently across all prefixes at that depth. It would be wrong to require one tape to succeed on every one of exponentially many prefixes.

Here is the weighted argument. Let p(a)=w(a)/w(empty) be the ideal prefix law and B_j the total p-mass of prefixes at depth j for which at least one of the two estimates is inaccurate. If a count program has failure probability at most delta_0 on each fixed input, then

\[
\mathbb E\sum_jB_j\le2n\delta_0.
\]

For relative count accuracy eta, the vector error in the j-th controlled rotation on the ideal prefix state is at most C eta+2 sqrt(B_j), with a universal constant C. A telescoping hybrid and Cauchy–Schwarz give

\[
\|\text{compiled state}-\text{ideal state}\|_2
\le Cn\eta+2\sqrt{n\sum_jB_j}
   +\text{rotation-rounding error}.
\tag{15}
\]

For example take eta=epsilon/(128n), delta_0=delta epsilon^2/(4096n^2), and bound the sum of rotation-rounding errors by epsilon/8. Markov's inequality controls the weighted bad-prefix term with probability at least 1-delta; constants can be further reduced without changing the complexity. Take alpha=epsilon/128 in (10) to pay the vector approximation error as well. This is the inherited weighted-prefix principle reconstructed for the acquired nonhomogeneous count instances.

The compiled circuit has a succinct reversible count program, not an exponentially long list of prefix angles. No nonunitary Trotter factor is physically applied with postselection.

## 6. Pure ground-space selection and the overlap bound

Since H is real stoquastic, e^{-tH} is entrywise nonnegative. Its normalized long-time limit shows that P_0 is entrywise nonnegative. If r=rank(P_0),

\[
p_0:=\langle+|P_0|+\rangle
 =2^{-n}\sum_{x,y}(P_0)_{xy}
 \ge2^{-n}\operatorname{Tr}P_0
 =r2^{-n}\ge2^{-n}.
\tag{16}
\]

Hence (3) is well defined. Let the gap above the ground space be at least Delta. In an eigenbasis, the squared excited norm in the unnormalized cooled state is at most exp(-2tau Delta), whereas the squared ground norm is p_0. The pure-state trace distance therefore satisfies

\[
T(\psi_\tau,\psi_0)\le\frac{e^{-\tau\Delta}}{\sqrt{p_0}}
\le2^{n/2}e^{-\tau\Delta}.
\tag{17}
\]

Taking tau >= ((n/2)ln2+ln(8/epsilon))/Delta suffices for the cooling contribution. A rational conservative choice is

\[
\tau=\frac{n+\lceil\log_2(32/\epsilon)\rceil}{\Delta}.
\tag{18}
\]

Compilation in Section 5 then proves item 3 of the theorem. The initial overlap can be exponentially small; its logarithm, not its inverse, enters the imaginary time. This avoids the need to know a sector or supply a good initial state. It does not remove the numerical inverse-gap cost.

## 7. Gap-free energy approximation

The following elementary bound applies to any finite real stoquastic H; the restricted form (1) is needed for the efficient counting implementation.

Let p_j be the spectral weights of |+>, let E_j-E_0=lambda_j>=0, and put

\[
Z_\tau=\sum_jp_j e^{-2\tau\lambda_j},\qquad
q_j=\frac{p_j e^{-2\tau\lambda_j}}{Z_\tau}.
\]

Then

\[
0\le D(q\|p)=-2\tau\sum_jq_j\lambda_j-\log Z_\tau.
\]

Since Z_tau>=p_0>=2^{-n},

\[
\langle\psi_\tau|H|\psi_\tau\rangle-E_0
\le\frac{n\ln2}{2\tau}.
\tag{19}
\]

For xi>0 take tau=n/xi (the n=0 case is trivial). The cooling error is below xi/2. Because H=cI-A and ||A||<=V, changing a normalized state by trace distance zeta changes its energy by at most 2V zeta. Compiling with zeta<=min(1/8,xi/[8(V+xi)]) pays less than the remaining budget. Thus pure low-energy preparation requires no gap promise.

There is also a classical additive-energy estimator. Every one- or two-site matrix element of the reduced state is a contraction of one ket and one complemented bra with the relevant output bits fixed. Sum at most 4^k such contractions for a k-site term (k<=2 here), with its known signed matrix coefficients. Each normalized nonnegative contraction is bounded by one, so relative accuracy eta yields additive O(eta) accuracy; charge the sum of absolute local coefficients when choosing eta. The global norm is counted in the same way. This estimates the energy of psi_tau classically, and (19) converts it into an additive estimate of E_0. It does not claim relative accuracy for a signed energy close to zero.

## 8. Relative ground-state replica access

Let rho_tau,S be the reduction of |psi_tau><psi_tau|. The integer moment is a cyclic contraction of q density matrices, hence of 2q positive wavefunction networks. Section 4 gives a relative FPRAS for the numerator; the normalizer is the q-th power of the squared vector norm.

Entrywise relative wavefunction error alpha multiplies every term of the numerator by a factor between (1-alpha)^{2q} and (1+alpha)^{2q}. The same argument applies to the denominator. Thus alpha=O(epsilon/q), along with relative numerator/normalizer count accuracy O(epsilon/q), suffices. There is no cancellation and no inverse-moment factor.

Passing to the ground vector requires a stronger cooling time than preparation in constant trace distance. For density matrices rho,sigma,

\[
|\operatorname{Tr}\rho^q-\operatorname{Tr}\sigma^q|
\le q\|\rho-\sigma\|_1.
\tag{20}
\]

This follows by telescoping rho^q-sigma^q and bounding the operator norms of all other factors by one. If S has dimension d_S, then M_q(S)>=d_S^{1-q}>=2^{-n(q-1)}. Equations (17) and (20) show that it is sufficient to take

\[
\tau\ge\frac{nq\ln2+\ln(64q/\epsilon)}{\Delta}.
\tag{21}
\]

A rational upper bound replaces ln by the integer base-two bounds used in (18). Although the required *physical-state* cooling accuracy is exponentially small in nq, the time in (21) is only linear in nq, and the relative-vector discretization is still alpha=O(epsilon/q). One must not instead require the Trotter circuit to have an exponentially tiny operator-norm error: that would discard the useful positivity interface.

For Rényi entropy S_q=-log M_q/(q-1), relative moment accuracy gives additive entropy accuracy. No assertion about von Neumann entropy follows from this argument; the integer-moment information obstruction in Astra N98 remains in force.

## 9. Largest Schmidt coefficient and min-entropy

Write lambda_* = ||rho_0,S|| and d=d_S. For every integer q>=2,

\[
\lambda_*^q\le M_q\le d\lambda_*^q,
\quad
\frac{-\log M_q}{q}\le-\log\lambda_*
\le\frac{-\log M_q+\log d}{q}.
\tag{22}
\]

Choose q>=max(2,ceil(4(n ln2+1)/epsilon)) and estimate M_q with, for example, relative accuracy 1/8. Taking logarithms of the resulting interval gives an additive-epsilon estimate of -log(lambda_*), and therefore a relative-O(epsilon) estimate of lambda_*. Constants can be tightened to obtain a specified relative tolerance. No separation between the largest and second-largest Schmidt coefficients is needed.

This is an operational continuation of integer replica access, not a new moment identity. It estimates the best squared overlap with a product state across the specified bipartition. It does not produce all Schmidt vectors or resolve the full entanglement spectrum.

## 10. Verification and exclusions

`checks/check_results.py` verifies the local polynomial identities, the general two-qubit infinitesimal Hessian, an exact three-qubit positive-boundary network and every one of its 15 prefix norms, 18 relative-vector numerical fixtures, and cooling examples including degeneracy. `checks/check_stability_and_energy.py` adds 60 dense stoquastic gap-free-energy fixtures and exact structural counterexamples. Neither is the full counting algorithm.

The load-bearing imported result is Chen–Liu's counting theorem and its every-execution bit implementation. The proof above reconstructs the reduction, not that theorem. The stability-preserver literature is used separately in the companion structural note. Historical priority for the combined theorem remains unresolved; existing ferromagnetic, six-vertex, EPR, imaginary-time, and quantum-sampling results substantially overlap its ingredients.

Do not infer an algorithm for arbitrary stoquastic Hamiltonians, general EPR*, arbitrary rare ground-state conditioning, general quantum postselection, von Neumann entropy, or physical rapid mixing. Do not silently replace the selected vector (3) by an arbitrary ground state. Do not interpret an inverse-gap polynomial as a gap-acquisition procedure or a claim of efficient performance when Delta is exponentially small.
