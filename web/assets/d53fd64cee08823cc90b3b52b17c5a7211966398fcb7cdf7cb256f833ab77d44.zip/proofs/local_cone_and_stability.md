# The infinitesimal log-concavity cone, stable amplitudes, and Born-law obstructions

**8 October 2026. Internally derived, externally unreviewed.** These statements do not use Chen–Liu's new FPRAS. They use the established algebraic-symbol stability-preserver theorem of Borcea and Brändén (2009), its polarization/limit closure properties, and elementary calculations reconstructed below. Historical priority for the specific classification and applications is not established.

## 1. An exact two-qubit generator classification

Let A be a real symmetric 4-by-4 matrix, indexed by 00,01,10,11, with nonnegative off-diagonal entries. Write

\[
\begin{aligned}
p&=A_{00,11}, &f&=A_{01,10},\\
g_0&=A_{00,10}, &g_1&=A_{01,11},\\
h_0&=A_{00,01}, &h_1&=A_{10,11},
\end{aligned}
\]

and let a_00,a_01,a_10,a_11 be its diagonal entries. Set

\[
D=a_{00}-a_{01}-a_{10}+a_{11}.
\]

For a matrix R define its input-complemented symbol

\[
Q_R(u_1,u_2,v_1,v_2)
 =\sum_{x,y\in\{0,1\}^2}R_{x,y}
      u_1^{x_1}u_2^{x_2}v_1^{1-y_1}v_2^{1-y_2}.
\tag{1}
\]

**Theorem 1 (necessary infinitesimal cone).** Suppose R_t=I+tA+o(t) coefficientwise as t decreases to zero, R_t has nonnegative entries, and Q_{R_t} is log-concave on the positive orthant for every sufficiently small t>0. Then

\[
p=0,\qquad g_0=g_1,\qquad h_0=h_1,\qquad |D|\le2f.
\tag{2}
\]

Conversely, every A satisfying (2) admits a first-order realization by a finite product of near-identity, real-stable nonnegative local factors. More strongly, Q_{e^{tA}} is real stable, and hence log-concave, for every t>=0. Thus (2) exactly classifies real symmetric nonnegative-off-diagonal two-qubit generators whose exponential symbols are log-concave near t=0.

This is a statement about a specified polynomial representation and specified infinitesimal gates. It is **not** an all-algorithm classification, a hardness theorem, or a result excluding ancillas, nonunitary gauges, finite non-identity gates, signed representations, nonlocal encodings, or large matching gadgets.

### Proof of necessity

At the identity,

\[
Q_I=(u_1+v_1)(u_2+v_2).
\]

Fix s_1,s_2>0, and use coordinates u_i=(s_i+z_i)/2, v_i=(s_i-z_i)/2 with |z_i|<s_i. The identity symbol is the constant s_1s_2 on this affine fiber. Consequently log-concavity of Q_{R_t}, divided by t and passed to the coefficientwise limit, implies

\[
\operatorname{Hess}_{z_1,z_2}Q_A\preceq0
\quad\text{on every such fiber}.
\tag{3}
\]

Here

\[
\begin{aligned}
Q_A={}&a_{00}v_1v_2+a_{01}v_1u_2+a_{10}u_1v_2+a_{11}u_1u_2\\
&+p(1+u_1u_2v_1v_2)+f(u_1v_1+u_2v_2)\\
&+(1+u_1v_1)(g_0v_2+g_1u_2)
 +(1+u_2v_2)(h_0v_1+h_1u_1).
\end{aligned}
\tag{4}
\]

The fiber Hessian F has entries

\[
\begin{aligned}
F_{11}&=-p(s_2^2-z_2^2)/8-f/2-(g_0v_2+g_1u_2)/2,\\
F_{22}&=-p(s_1^2-z_1^2)/8-f/2-(h_0v_1+h_1u_1)/2,\\
F_{12}&=D/4+pz_1z_2/4-(g_1-g_0)z_1/4-(h_1-h_0)z_2/4.
\end{aligned}
\tag{5}
\]

This identity is verified symbolically for all ten independent matrix parameters in the supplied checker.

If p>0, take s_1=s_2=R and z_1=z_2=rR with 1/sqrt(3)<r<1. The leading R^2 part of F has an eigenvalue pR^2(3r^2-1)/8>0. The remaining terms are O(R). This contradicts (3), so p=0.

If g_1 differs from g_0, keep s_2 fixed and z_2=0, and take s_1=R,z_1=rR with 0<r<1. The product F_11 F_22 is O(R), whereas F_12^2 has a positive R^2 leading term. Hence det F<0 for large R, again a contradiction. Thus g_0=g_1. Interchanging the qubits gives h_0=h_1.

Finally take s_1,s_2 to zero with z_1=z_2=0. The limiting Hessian has diagonal -f/2 and off-diagonal D/4. Negative semidefiniteness is exactly |D|<=2f. All limiting operations are taken after the t-to-zero implication at each fixed positive point; no uniform-in-R differentiability is assumed. □

### Proof of sufficiency and semigroup closure

With (2), the generator has the Pauli form

\[
A=\lambda I+rZ_1+sZ_2+cZ_1Z_2
  +gX_1+hX_2+\frac f2(X_1X_2+Y_1Y_2),
\quad g,h\ge0,\quad |c|\le f/2.
\tag{6}
\]

After a scalar shift this is the positive-generator decomposition of the companion ground-state note, with d=-2c and f>=|d|. Separate the independent longitudinal, transverse, and edge factors. Their sufficiently small Euler symbols are real stable and nonnegative. Borcea–Brändén's algebraic-symbol theorem implies that they preserve real stability. Their products do so, and the Trotter limit e^{tA} does so by Hurwitz closure. Applying this operator to the identity symbol gives the real stability of its full symbol. Nonnegative real-stable polynomials are log-concave on the positive orthant. Scalar factors do not affect these properties.

The sufficiency assertion is deliberately about a product or an exponential. It does **not** assert that the single unsplit Euler gate I+tA has a log-concave symbol for every A in (2). For example, multiple independent longitudinal terms can require second-order corrections to their unsplit Euler gate.

## 2. Why the local edge polynomial is real stable

A nonnegative homogeneous quadratic q with at most one positive Hessian eigenvalue is real stable. To see this directly, write q(z)=B(z,z) for a real symmetric bilinear form. For y in the positive orthant, q(y)>0 unless q is identically zero. If q(x+iy)=0, then B(x,y)=0 and q(x)=q(y)>0. But a form with at most one positive direction is nonpositive on the B-orthogonal complement of a positive vector y, a contradiction.

The edge polynomials in the ground-state note satisfy the required Hessian signature by the triangle inequalities. A one-qubit transverse symbol c+u+v+cuv is real stable for 0<=c<=1; its Rayleigh difference is 1-c^2. Longitudinal linear factors and the positive terminal 1+x are real stable.

For clarity, the Borcea–Brändén theorem being used is the following sufficient direction: a linear operator T on multiaffine polynomials preserves stability if

\[
G_T(z,w)=T\left[\prod_i(z_i+w_i)\right]
\]

is stable. In the coefficient basis this is precisely (1). Acting on only a subset of qubits adds independent identity-symbol factors for all other variables, so the result applies in an arbitrarily large surrounding system.

## 3. Stable selected ground-state amplitudes

For a nonnegative vector v define its amplitude polynomial

\[
p_v(z)=\sum_{x\in\{0,1\}^n}v_x z^x.
\]

**Theorem 2.** For the Hamiltonian (1) of the companion ground-state note, p_{e^{-tau H}|+>} is real stable for every tau>=0. The selected ground vector P_0|+>/||P_0|+>|| also has a real-stable amplitude polynomial.

**Proof.** The initial polynomial is proportional to product_i(1+z_i), which is stable. Each sufficiently fine local Euler factor preserves stability by Section 2. Trotter convergence yields the finite-time vector. Normalization is a positive scalar and the finite-time vector never vanishes. Sending tau to infinity, its normalized limit is the selected vector, which is nonzero by the overlap bound in the companion note. Hurwitz closure gives stability at both limits. □

When transverse fields vanish, the same argument can start from the elementary symmetric polynomial e_k. The normalized imaginary-time limit is then a stable nonnegative lowest-energy vector **within that fixed particle-number sector**. That sector need not contain a global ground state.

This is an amplitude statement, not a Born-probability statement. Squaring the amplitudes can destroy strong Rayleighness and even every dimension-independent fractional-log-concavity bound, as shown below.

Nor does it cover every vector in a degenerate ground space. The ferromagnetic Heisenberg chain is an immediate counterexample: both a uniform product vector and a GHZ vector are ground states, whereas 1+z_1...z_n is not real stable for n>=2. The algorithmic target is the selected vector, not an arbitrary superposition in that eigenspace.

## 4. A sharp interference bound for separated configurations

Let A and B be disjoint sets of size k, and let p be a nonnegative real-stable homogeneous polynomial of degree k on A union B. Write its coefficients as v_S and let a=v_A,b=v_B.

**Theorem 3.** The normalized pure state with amplitudes v obeys

\[
\frac{2v_Av_B}{\sum_Sv_S^2}\le\frac2{k+1}.
\tag{7}
\]

The constant is attained. In particular, if a=b, its fidelity with (|A>+|B>)/sqrt(2) is at most 2/(k+1).

**Proof.** Identifying all A variables with s and all B variables with t gives a stable binary homogeneous polynomial

\[
P(s,t)=\sum_{j=0}^k C_j s^j t^{k-j},\qquad C_k=a,\ C_0=b.
\]

For a,b>0 its univariate roots are real and nonpositive. Newton's inequalities give

\[
C_j\ge\binom kj a^{j/k}b^{1-j/k}.
\]

There are binom(k,j)^2 monomials having j indices in A. Cauchy–Schwarz on each profile therefore implies

\[
\sum_Sv_S^2\ge\sum_{j=0}^k a^{2j/k}b^{2-2j/k}
\ge(k+1)ab.
\tag{8}
\]

The final step is arithmetic–geometric mean; its k+1 terms have geometric mean ab. This proves (7). If an endpoint vanishes the bound is trivial. □

An extremizer is

\[
p_k(z_A,z_B)=\sum_{j=0}^k\frac{e_j(z_A)e_{k-j}(z_B)}{\binom kj}.
\tag{9}
\]

It is the separate polarization of (s+t)^k and hence is real stable. Each profile contributes exactly one to the squared coefficient norm, so the norm squared is k+1 and both endpoint coefficients equal one.

The unqualified assertion that *all* these states have cat fidelity at most 2/(k+1) is false: a single basis state has fidelity 1/2, exceeding 2/(k+1) for k>=4. This proposed strengthening was rejected during the run and is retained in the failure ledger.

The correct sharp maximum of the cat fidelity, with no endpoint-balance assumption, is 1 for k=1, 2/3 for k=2, and 1/2 for k>=3. For k=2, (8) gives denominator at least a^2+ab+b^2. For k>=3, the two distinct interior terms with j=1 and j=k-1 already sum to at least 2ab, so the denominator is at least (a+b)^2. These prove the upper bounds; (9) attains the first two, while a basis vector attains 1/2 for every k>=3.

## 5. Vacuum–full GHZ exclusion for stable positive amplitudes

A related statement applies without homogeneity. If p_v is real stable with nonnegative coefficients on n>=2 variables, then

\[
\left|\left\langle\frac{|0^n\rangle+|1^n\rangle}{\sqrt2}\middle|\frac{v}{\|v\|_2}\right\rangle\right|^2\le\frac12.
\tag{10}
\]

Let a=v_empty and b=v_[n]. If either is zero the inequality is immediate. Otherwise diagonalize all variables: p_v(t,...,t)=sum_j C_j t^j. It is real-rooted with nonnegative coefficients, so Newton's inequalities and Cauchy–Schwarz over all binom(n,j) coefficients give

\[
\|v\|_2^2\ge\sum_{j=0}^n\binom nj a^{2-2j/n}b^{2j/n}
=(a^{2/n}+b^{2/n})^n\ge(a+b)^2.
\]

This proves (10). The basis is part of the statement: local bit flips or arbitrary local unitary changes cannot be silently applied. For the selected ground state, a compiled trace error epsilon increases the tested projector probability by at most epsilon. The result does not exclude a GHZ vector elsewhere in a degenerate ground space.

## 6. Squaring stable amplitudes can lose essentially all uniform fractional log-concavity

For the extremizer (9), let pi_S=v_S^2/(k+1). The random variable J=|S intersection A| is uniform on {0,...,k}; thus

\[
\operatorname{Var}_\pi J=\frac{k(k+2)}{12}.
\tag{11}
\]

Let m_i=E[X_i]=1/2 and take the contrast vector u_i=1 on A and -1 on B. Then u dot X=2J-k and

\[
\frac{u^T\operatorname{Cov}_\pi(X)u}{u^T\operatorname{diag}(m)u}
=\frac{k+2}{3}.
\tag{12}
\]

For a generating polynomial G of pi, alpha-fractional log-concavity means that log G(x_1^alpha,...,x_n^alpha) is concave on the positive orthant. Its Hessian at x=1 is

\[
\alpha^2\operatorname{Cov}_\pi(X)-\alpha\operatorname{diag}(m).
\]

Therefore (12) forces

\[
\alpha\le\frac3{k+2}.
\tag{13}
\]

This is a necessary upper bound, not an assertion of the exact global threshold. Conversely every homogeneous nonnegative degree-k polynomial is 1/k-fractionally log-concave: each monomial after that substitution is a concave geometric mean, their sum is positive and concave, and log preserves concavity. Consequently this family has its best fractional-log-concavity parameter of order 1/k. Squaring has removed essentially all improvement over this general degree-only guarantee.

This does not establish slow mixing, approximation hardness, or a small physical gap. It specifically invalidates a proposed transfer of a **dimension-independent** log-concavity/spectral-independence bound from amplitudes to Born weights. Exponentiated strongly Rayleigh distributions and their loss of strong Rayleighness were already studied by Mariet, Sra and Jegelka (NeurIPS 2018); the quantitative family here is a reconstructed witness, not a claim to have introduced that phenomenon.

## 7. The counterexample is an actual interacting ground state

The vector (9) is the nonnegative ground vector of

\[
H_{K_{k,k}}=\frac12\sum_{i\in A,j\in B}(Z_iZ_j-X_iX_j-Y_iY_j).
\tag{14}
\]

This is a familiar complete-bipartite spin singlet after a Marshall sign change, not a newly discovered solvable model. Conjugating every B qubit by Z gives

\[
H'=2\mathbf S_A\cdot\mathbf S_B
=\mathbf S_{\rm tot}^2-\mathbf S_A^2-\mathbf S_B^2.
\]

With maximal spins s_A=s_B=k/2 and total spin zero, its energy is -k(k+2)/2. No smaller energy is possible because S_tot^2>=0 and each subsystem spin is at most k/2. The unique singlet between the two maximal-spin representations has, after the sign change, precisely the positive coefficients in (9).

Its spectral gap is 2: inside the maximal-spin pair the next total spin is one. Reducing either subsystem spin lowers the magnitude of the minimum negative energy by at least 2(s+1)>=2, using the minimum-energy formula -2b(a+1) for a>=b and a,b<=s. Thus the Born-law counterexample even occurs in a constant-gap family. It cannot be used as evidence of a small quantum gap.

The checker verifies the coefficient norm, all profile masses, and the covariance identity exactly for k=1,...,7. It verifies the rational eigenvector equation in the k-particle sector for k=1,...,4 (sector dimensions 2,6,20,70). These computations supplement the formulas; they do not establish priority or replace the all-k proofs.
