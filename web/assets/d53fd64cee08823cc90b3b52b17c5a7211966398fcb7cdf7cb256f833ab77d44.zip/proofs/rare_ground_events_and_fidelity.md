# Rare ground-state events and relative ground-state fidelity

Research checkpoint, 8 October 2026. Candidate proofs, not independent certification or an established priority claim. The polynomial-time counting/compilation conclusions below retain Chen–Liu arXiv:2610.06724v1, Theorem 1.6 and its finite-bit implementation as an external premise. The analytic amplitude and cooling bounds do not use that theorem. This note extends `positive_boundary_ground_states.md` beyond its initial exclusion of rare ground-state conditioning.

## 1. The interface that must be paid for

A trace-distance approximation to a ground state cannot automatically be conditioned on an exponentially unlikely event. Requesting inverse-event-probability trace accuracy from a generic state preparation algorithm would be exponentially costly. The approach here is different: acquire a logarithmic lower bound on every *nonzero* ground amplitude; make imaginary-time cooling correspondingly longer; approximate the resulting positive vector **entrywise relatively** with a product network. The product-network accuracy remains polynomial, rather than exponentially small.

Use the Hamiltonian, positive generators and rational norm bound V from the companion note:

\[
 H=\tfrac12\sum_{uv}[d_{uv}Z_uZ_v-f_{uv}(X_uX_v+Y_uY_v)]
       +\sum_i h_iZ_i-\sum_i g_iX_i,
 \qquad f_{uv}\geq |d_{uv}|,\quad g_i\geq0,
\]

\[
 A=cI-H\geq0\quad\hbox{entrywise},\qquad \|A\|\leq V.
\]

Let P_0 project onto the whole ground space, and write

\[
 \psi_0=P_0|+\rangle/\|P_0|+\rangle\|.
\]

All coordinates are real and nonnegative. Let r be the smallest strictly positive number among the exchange rates f_{uv} and flip rates g_i, when that set is nonempty. Put

\[
 D=2n^2,\qquad
 \gamma=2^{-n}\min(1,r/V)^D.
 \tag{1}
\]

When there are no off-diagonal rates, put gamma=2^{-n}. This is an explicitly computable rational number. Its binary description and log(gamma^{-1}) are polynomial in n and the rational input length. There is no assumption that gamma is inverse polynomial.

## 2. Configuration diameter and the Perron amplitude floor

**Lemma 1.** Every connected component of the configuration graph of A has diameter at most 2n^2.

**Proof.** Decompose the physical graph into connected components of positive exchange edges. In a component containing no positive flip rate, configurations are connected exactly when their particle counts agree. The spanning-tree leaf-fixing argument in Astra X connects them in at most m(m-1)/2 exchanges, where m is the number of sites in that component.

In a physical component containing a site with positive flip rate, any configuration can be emptied. If the flip site is occupied, flip it. Otherwise choose an occupied vertex nearest to it. All intermediate sites are empty, so a sequence of at most m-1 allowed exchanges brings that particle to the flip site, where it is removed. Repeat at most m times. Thus emptying costs at most m^2 moves; reversing this procedure constructs any target configuration. The total is at most 2m^2. Summing over physical components is at most 2n^2. Isolated sites satisfy the same bound. □

**Lemma 2 (acquired nonzero-amplitude bound).** For every configuration x,

\[
 \psi_0(x)=0\quad\hbox{or}\quad \psi_0(x)\geq\gamma.
 \tag{2}
\]

**Proof.** Within each irreducible configuration block, the top eigenvector of the nonnegative symmetric matrix A is a unique normalized positive vector u. A block contributes to P_0 exactly when its top eigenvalue is the global top eigenvalue lambda. For any edge x,y in such a block,

\[
 \lambda u(x)=\sum_z A_{xz}u(z)\geq r u(y),\qquad
 u(x)\geq(r/V)u(y).
\]

For a block with more than one configuration lambda>0. Traveling to a coordinate at which u is largest and using Lemma 1 gives

\[
 u(x)\geq\min(1,r/V)^D/\sqrt{m},
\]

where m is the block size. A singleton block has u(x)=1 and satisfies the same conservative bound. In P_0|+>, the coefficient of u is \(\langle u|+\rangle=2^{-n/2}\|u\|_1\geq2^{-n/2}\). The subsequent normalization divides by a number at most one. Since m<=2^n, every positive selected-ground coordinate is at least the number (1). If all blocks are singletons, the same argument gives the stated diagonal-case bound. □

No ground sector, support configuration, ground-space dimension, or ground energy was acquired to prove this floor. Positivity of the selected projection, the polynomial configuration diameter, and an explicitly bounded rate ratio do the work.

## 3. Cooling at logarithmic rare-event cost

Assume a rational lower bound Delta>0 on the gap above the entire ground space is supplied. The companion note proves

\[
 T(\psi_\tau,\psi_0)\leq2^{n/2}e^{-\tau\Delta},\qquad
 \psi_\tau=e^{-\tau H}|+\rangle/\|e^{-\tau H}|+\rangle\|.
\]

Since the vectors have nonnegative overlap,

\[
 \|\psi_\tau-\psi_0\|_2\leq\sqrt2\,2^{n/2}e^{-\tau\Delta}.
 \tag{3}
\]

Choose a rational tau large enough to make the right side at most epsilon gamma/128. For example, using ln(2)<1 and upper integral binary-log bounds, it suffices to take

\[
 \tau\Delta\geq n+1+\left\lceil\log_2\frac{128}{\epsilon\gamma}\right\rceil.
 \tag{4}
\]

The dependence on the rare-amplitude floor is log(gamma^{-1}), not gamma^{-1}.

Let E be a specified computational-basis cylinder event: a subset of coordinates is fixed to specified zero/one values. Write P_E for its diagonal projector and p_0(E)=||P_E psi_0||^2. Lemma 2 gives

\[
 p_0(E)=0\quad\hbox{or}\quad p_0(E)\geq\gamma^2.
 \tag{5}
\]

If p_0(E)=0, (3)–(4) give p_tau(E)<=epsilon^2 gamma^2/128^2. If p_0(E)>0, then

\[
 |\sqrt{p_\tau(E)}-\sqrt{p_0(E)}|
 \leq\|\psi_\tau-\psi_0\|_2
 \leq\epsilon\gamma/128
 \leq\epsilon\sqrt{p_0(E)}/128.
 \tag{6}
\]

Thus p_tau(E) is a relative O(epsilon) approximation in the positive case, while a known threshold, say gamma^2/4, separates the zero and positive cases by a constant factor.

Now construct the product-network vector tilde-v with

\[
 (1-\alpha)e^{\tau A}{\bf1}\leq\widetilde v
       \leq(1+\alpha)e^{\tau A}{\bf1}
\]

entrywise, using alpha=epsilon/1024. This takes polynomially many factors by the relative-vector lemma. The probability of E for the normalized tilde-v differs multiplicatively from p_tau(E) by at most

\[
 \left(\frac{1+\alpha}{1-\alpha}\right)^2
\]

and its reciprocal. This remains true no matter how small p_tau(E) is. The squared norm restricted to E and the unrestricted squared norm are positive log-concave tensor contractions. Constant-relative counting is enough to decide which side of the zero threshold applies; O(epsilon)-relative counting yields the probability estimate in the positive case.

**Conditional theorem 1 (ground event counting and conditioning).** Under the counting premise and the supplied global-gap promise, there is a randomized polynomial-time algorithm which, with probability at least 1-delta, correctly reports that p_0(E)=0 or returns a relative-epsilon estimate of p_0(E). If it is positive, a randomized classical compiler produces a quantum circuit preparing

\[
 \psi_{0,E}=P_E\psi_0/\sqrt{p_0(E)}
\]

to trace error epsilon. The costs are polynomial in the input size, n, V/Delta, epsilon^{-1}, log(delta^{-1}), and log(gamma^{-1}). There is no inverse-event-probability factor.

**Compiler justification.** All completion amplitudes of the finite-time positive-boundary vector are positive. Pin the event's terminals and use the weighted-prefix compiler on the remaining bits. The relative vector bound persists after pinning and normalization; it does not require unconditioned trace accuracy of order epsilon gamma. For cooling, normalization of the restricted true vectors gives

\[
 \|\psi_{\tau,E}-\psi_{0,E}\|_2
 \leq\frac{2\|\psi_\tau-\psi_0\|_2}{\sqrt{p_0(E)}}
 \leq\epsilon/64.
\]

The companion note allocates the remaining error to entrywise approximation, counting and reversible rotations. The every-execution finite-bit premise remains necessary. □

The zero decision is randomized under a promised spectral gap and acquired amplitude floor; it is **not** deterministic exact zero detection by a finite-time tensor network. Every consistent cylinder event has positive finite-time weight, even when its ground-state weight vanishes.

## 4. Relative ground-state fidelity

Consider two Hamiltonians H and K in the admitted class, expressed in the same basis. Let psi_0 and phi_0 be their selected ground vectors, with acquired positive amplitude floors gamma_H, gamma_K and supplied gap bounds Delta_H, Delta_K. Define

\[
 G=\langle\psi_0,\phi_0\rangle,\qquad F=G^2.
\]

Because the coordinates are nonnegative, either their ground supports are disjoint, so G=0, or

\[
 G\geq\gamma_H\gamma_K=:\gamma_*.
 \tag{7}
\]

Cool each state until its Euclidean error is at most epsilon gamma_*/256. This again costs logarithmically in gamma_*^{-1}. The finite-time overlap differs additively by at most twice that error. It therefore separates zero from positive overlap at a known threshold and approximates a positive G relatively. Its numerator is the positive contraction between the two product networks; normalization uses their two squared norms. A relative vector approximation perturbs the numerator and both norms multiplicatively, independently of G.

**Conditional theorem 2.** A classical randomized algorithm either correctly reports F=0 or estimates the selected-ground-state fidelity F to relative error epsilon, with probability at least 1-delta. The runtime is polynomial in the two input lengths, n, the two inverse-gap resource ratios, epsilon^{-1}, log(delta^{-1}), and log(gamma_H^{-1}gamma_K^{-1}). No inverse-fidelity term occurs. It also yields an additive estimate of -log(F) when F>0.

This is not a result for arbitrary phases, a user-chosen ground vector, local-unitary-optimized fidelity, or general quantum-state overlaps. The absence of cancellation and the acquired logarithmic floor are essential.

## 5. Relative entanglement after a rare ground event

The same pinning can be used in the integer-replica construction. For q>=2 and any subsystem of the unpinned qubits, its q-th reduced-state moment is at least 2^{-n(q-1)}. To protect this moment through cooling, request the stronger Euclidean cooling error

\[
 \|\psi_\tau-\psi_0\|_2
 \leq\frac{\epsilon\gamma}{1024q\,2^{n(q-1)}}.
 \tag{8}
\]

The needed imaginary time is still polynomial: tau Delta = O(nq+log(gamma^{-1})+log(q/epsilon)). The normalized conditional vector error is at most twice (8) divided by gamma; the moment perturbation is bounded by q times the trace-norm perturbation of the reduced density matrices.

Choose the entrywise product accuracy O(epsilon/q), and count the pinned 2q-replica network relatively. The numerator and denominator are positive contractions, so this second error is relative without an inverse moment or event-probability factor. Thus the conditional ground state's integer Renyi moments, integer Renyi entropies, largest reduced eigenvalue and min-entropy inherit the companion theorem's polynomial interfaces. The passage from high integer moments to the largest eigenvalue charges the numerical value q=O(n/epsilon), not log(q).

This does not provide the von Neumann entropy, the whole Schmidt spectrum, or conditioning on arbitrary predicates/projectors.

## 6. Acquiring the gap when every transverse field is positive

A further premise can be discharged in a concrete subfamily, using **prior work**, not a new gap theorem here. Bravyi, Gosset, Liu and Wong, arXiv:2607.14401v1, Theorem 1, prove a sharp gap bound 2 min_i mu_i^z for Suzuki–Fisher Hamiltonians, including arbitrary transverse one-site fields.

Conjugate our H by a Hadamard on every qubit. It becomes

\[
 H'=\tfrac12\sum_{uv}[d_{uv}X_uX_v-f_{uv}(Z_uZ_v+Y_uY_v)]
       +\sum_i h_iX_i-\sum_i g_iZ_i.
\]

In their convention its couplings satisfy

\[
 J^z=f/2,\quad J^{yy}=f/2,\quad J^{xx}=-d/2,
 \quad\mu_i^z=g_i,\quad\mu_i^x=-h_i,
\]

so J^z>=max(|J^{xx}|,|J^{yy}|). Therefore

\[
 \Delta\geq2\min_i g_i>0.
 \tag{9}
\]

For this subfamily the target is the unique ground state, every cylinder event is positive, and every same-basis ground overlap between two such systems is positive. The algorithms can use (9) without asking for a gap bound. Their costs still charge the **numerical reciprocal** of min g_i. Arbitrarily tiny positive fields do not become free.

This July result also already gives quantum adiabatic low-energy preparation for a *larger* Suzuki–Fisher family. Thus quantum low-energy preparation by itself is not a new complexity capability of this checkpoint. The counting-dependent additions being investigated are classical relative access to amplitudes/events, fidelities and replica contractions, including very small positive quantities. Full priority clearance of those combined consequences is unresolved.

## 7. What was actually checked

`checks/check_rare_ground.py` records dense small-system tests of the Perron floor, zero-versus-positive threshold, conditional cooling, and overlapping/disjoint-support fidelities. Finite tests do not establish the general theorems; the general arguments are above. No Chen–Liu implementation, high-precision large-system compiler, formal proof assistant or independent reviewer was used.
