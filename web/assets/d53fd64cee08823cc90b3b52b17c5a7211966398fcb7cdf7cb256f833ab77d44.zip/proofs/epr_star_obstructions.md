# The stronger EPR* target: exact route obstructions

Research checkpoint, 8 October 2026. These are scoped algebraic obstructions, not a hardness theorem and not a proof that EPR* lacks an efficient algorithm. They document the stronger target pursued after the admitted spin compiler.

## 1. Target and the failed local extension

Marwaha–Sud, arXiv:2604.13026v1, identifies the positive-weight EPR* family as a remaining interface in the classification of fixed symmetric two-qubit interactions. Up to its scalar term, its interaction is

\[
 K_s=\tfrac12(XX+sYY-ZZ),\qquad -1\leq s\leq1.
\]

A common one-qubit rotation gives the stoquastic interaction

\[
 K'_s=\tfrac12(-XX+sYY+ZZ).
\]

Set A=(1/2)I-K'_s. Its matrix is

\[
 A=\begin{pmatrix}
 0&0&0&v\\0&1&u&0\\0&u&1&0\\v&0&0&0
 \end{pmatrix},\qquad
 u=(1-s)/2,\quad v=(1+s)/2.
\]

For a positive Euler step t, F=I+tA has eight-vertex weights

\[
 a=1,\quad b=1+t,\quad c=tu,\quad d=tv,
 \qquad b=a+c+d.
\]

With reversed complemented input ports, its polynomial is

\[
 h=d(1+x_1x_2x_3x_4)
   +a(x_1x_2+x_3x_4)
   +b(x_1x_3+x_2x_4)
   +c(x_1x_4+x_2x_3).
 \tag{1}
\]

For d>0 this is not log-concave: at the origin it has positive constant term and zero gradient, while its quadratic Hessian is a nonzero nonnegative matrix with a positive eigenvalue. The same positive eigenvalue persists at nearby strictly positive points. Making t smaller does not remove this obstruction. More generally, the companion local-cone theorem rules out every differentiable nonnegative local approximation I+tA+o(t) with a log-concave complemented symbol: it forces A_{00,11}=0, whereas here A_{00,11}=v>0.

The exact gate e^{-tK'_s} has weights

\[
 a=e^{-t/2}\cosh(t(1+s)/2),\quad d=e^{-t/2}\sinh(t(1+s)/2),
\]
\[
 b=e^{t/2}\cosh(t(1-s)/2),\quad c=e^{t/2}\sinh(t(1-s)/2).
\]

They again satisfy b-c=a+d. Thus switching to the exact local exponential does not move this family away from the critical surface b=a+c+d.

## 2. Positive three-connection representation and the frustrated loop

Equation (1) has the exact nonnegative decomposition

\[
 h=a(x_1+x_4)(x_2+x_3)
   +c(x_1+x_2)(x_3+x_4)
   +d(1+x_1x_3)(1+x_2x_4).
 \tag{2}
\]

In matrix form this reads

\[
 F=aI+2c|\psi^+\rangle\langle\psi^+|+d\,(X\otimes X)\mathrm{SWAP},
 \qquad |\psi^+\rangle=(|01\rangle+|10\rangle)/\sqrt2.
 \tag{3}
\]

All entries are nonnegative. This initially suggests a loop expansion in which each connected loop simply receives two spin assignments. That last assertion is false: the third connection carries a bit-flip constraint, and a closed loop may be frustrated.

Let U_{ij}=(X_iX_j)SWAP_{ij} on three qubits. A direct exact permutation calculation gives

\[
 \operatorname{Tr}(U_{12}U_{02}U_{01})=0,
\]

whereas removing the bit flips gives

\[
 \operatorname{Tr}(SWAP_{12}SWAP_{02}SWAP_{01})=4.
\]

The latter permutation has two unconstrained spin loops, but the former word has no consistent spin assignment. The exact 8-by-8 permutation matrix and both traces are saved in `checks/results.json`. Consequently a counting reduction that keeps only the number of loops and drops the parity constraints is incorrect.

This does not rule out a representation that retains and efficiently samples the constraints, a different positive gadget, a cluster update, or another approximation-preserving reduction. No lower bound on all such algorithms is claimed.

## 3. Why an on-site basis change does not fix an odd cycle

Consider |s|<1. The coupling matrix of K_s is diag(1,s,-1), up to the factor 1/2. It has a unique weak singular axis, the Y-axis. Every admitted two-body easy-plane term has two equal larger singular values and a possible smaller longitudinal singular value. Therefore any on-site unitary transformation of the entire EPR* Hamiltonian into such a number-conserving easy-plane form would pull the common local Z charge back to

\[
 Q_i=\sigma_iY_i,\qquad\sigma_i\in\{-1,1\}.
\]

For each edge, the exact commutator is

\[
 [K_s,\sigma_iY_i+\sigma_jY_j]
   =i(\sigma_i+\sigma_j)(Z_iX_j+X_iZ_j).
 \tag{4}
\]

It vanishes exactly when sigma_i=-sigma_j. Distinct edge supports cannot cancel these two-site Pauli terms. Hence such an on-site reduction requires a two-coloring of the physical graph. An odd cycle forbids it.

Conversely, on a bipartite graph choose the local charge signs by the bipartition. A rotation sending the weak Y-axis to Z, a pi rotation on one side to reverse that charge, and a further bipartite sign choice for the transverse axes map the interaction to

\[
 \tfrac12[-XX-YY-sZZ],
\]

which satisfies the admitted cone. Thus, within this on-site number-conserving reduction, bipartiteness is the exact obstruction. The degenerate singular-value endpoints s=+-1 require separate treatment and are excluded from this argument.

In particular, this does not assert EPR* hardness at s=0: prior Bravyi–Gosset methods handle that interaction by a different route. Nor does it obstruct adding ancillas, enlarging tensors, changing nonlocally, using a different counting representation, or using algorithms that do not preserve local log-concavity.

## 4. Connection to the repository's determinant-parity obstruction

Astra W already contains an all-size square-root exchange inequality but leaves the microscopic determinant-parity counting/comparison step open. Its explicit non-windability and failed common-cut sewing examples rule out particular matching-overlay routes. Those results are not an all-algorithm hardness theorem. The present EPR* calculations expose a related but distinct interface: local positive connections are available, but the globally consistent parity information cannot simply be erased.

The strongest unclosed target of this run is an **acquired positive counting/sampling representation for the frustrated critical eight-vertex family**, or another polynomial algorithm avoiding it. Neither an exchange inequality, the positivity of (2), nor a physical spectral-gap theorem supplies that classical algorithm.

## 5. Prior-art adjustment from July 2026

The preliminary idea of proving the field-induced gap 2 min g for the admitted spin family was withdrawn as a novelty candidate after locating Bravyi–Gosset–Liu–Wong, arXiv:2607.14401v1. Their theorem already proves it for the larger Suzuki–Fisher class, with arbitrary transverse one-site fields. Rayudu–Takahashi, arXiv:2607.10765v1, independently proves a related h/4 gap bound for its stated uniform-field class by a different imaginary-time correlation argument.

The July theorem is useful as an imported gap certificate in the rare-ground-event note. It is not counted as an Astra discovery, and its quantum adiabatic preparation consequence must not be relabeled as a new consequence of the October counting reduction.
