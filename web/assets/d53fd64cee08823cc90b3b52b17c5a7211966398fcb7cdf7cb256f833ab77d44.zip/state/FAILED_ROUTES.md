# Failed routes, rejected claims, and boundaries

1. **Field-induced gap as a new discovery:** rejected for priority. BGLW 2607.14401 already gives sharp 2 min field, including arbitrary transverse fields. RT2607.10765 gives a related uniform-field result. Imported as an input instead.
2. **Quantum low-energy preparation as a new capability:** too broad. July Suzuki–Fisher algorithms already cover a larger class. The narrower candidate additions concern classical relative access, rare conditioning and fidelity/replica quantities.
3. **EPR/EPR-bipartite ground energy as new:** inherited Chen–Liu C17; not an Astra discovery.
4. **All transverse-field simulation as new:** false priority framing. Bravyi–Gosset1612.05602 already covers XY/Ising ferromagnets. The full simultaneous XX,YY,ZZ,X,Z interface must be compared separately.
5. **Ignore bra incidence orientation:** creates a 1+xy equality wire, which is not log-concave. Full bra complementation repairs the admitted class; do not claim arbitrary tensors enjoy this closure.
6. **Sample square-root path weights and erase histories:** path amplitudes are SUMS before squaring; a history sampler does not produce the required coherent boundary state. Use doubled prefix norm contractions.
7. **Uniformly certify exponentially many prefix counts:** exponential union bound/table is not the compiler. Use ideal-prefix-weighted bad mass and bounded-time reversible programs.
8. **Ordinary trace accuracy protects rare events/purity:** false. The later extension uses acquired gamma and longer cooling, followed by RELATIVE positive-vector approximation, not exponentially precise circuit synthesis.
9. **Finite-time network gives exact ground support:** false. It is strictly positive. Zero/positive ground support is separated probabilistically by the promised gap plus the Perron amplitude floor.
10. **Inverse gap disappears:** false. Zero-field exact-ground-target theorems retain a supplied positive gap. Positive fields charge numerical 1/min g. Low-energy guarantees are gap-free but do not identify a true ground vector without further control.
11. **Stable amplitudes imply dimension-independent fractional log-concavity of Born probabilities:** false. Polarized (s+t)^k example forces alpha<=3/(k+2), despite an actual constant physical gap2.
12. **Every degenerate ground vector is stable:** false. Ferromagnetic Heisenberg admits GHZ ground vectors; the positive-boundary selected vector is the stated target.
13. **Unbalanced disjoint-cat fidelity <=2/(k+1):** false. k4 basis state has fidelity1/2>2/5. Retain the sharp coherence inequality, balanced statement, and corrected piecewise fidelity envelope.
14. **EPR* exact or smaller Euler gates become locally log-concave:** false for pair creation, by the tangent cone and direct positive Hessian at the origin.
15. **Positive EPR* connection expansion means 2 per loop:** false. Signed-swap triangle trace0 versus plain-swap trace4. Retain parity constraints.
16. **General on-site basis cure of EPR* odd cycles:** blocked within number-conserving easy-plane target by unique weak singular axis and alternating local charges. Not a no-go for gadgets/ancillas/other algorithms; s=0 has known alternative methods.
17. **Square-root exchange/aggregate capacity solves W sampler:** not shown. The microscopic energy/congestion/computable sampling gate remains separate, as repository N86 records.
18. **Integer moments determine von Neumann entropy with polynomial accuracy:** inherited counterexample remains. No S1 claim, no entire Schmidt spectrum, no arbitrary projector/predicate, no sign-cancellation or general-state fidelity claim.
19. **New KLS proof reports certify a universal cross-field tool:** not established in this run. The reports prompted a frontier refresh; no KLS proof certification or consequential transfer was completed.
20. **Exact small tests certify full algorithm or novelty:** false. The tests are reproducible diagnostics only, and no independent subagents or external referees were used.
