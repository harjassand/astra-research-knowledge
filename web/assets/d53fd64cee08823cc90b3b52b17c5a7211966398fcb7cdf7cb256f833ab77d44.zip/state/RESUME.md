# Compact resumable research state

Date: 8 October 2026. Scope: internally derived candidate results, not independently reviewed. No field-breaking discovery established. Algorithms conditional on Chen–Liu 2610.06724v1 Thm1.6 + finite-bit argument. Do not silently replace this theorem by a free oracle, or confuse finite tests with its implementation.

## Strongest current interface

H=.5 sum[d ZZ-f(XX+YY)]+sum hZ-sum gX, on arbitrary finite graphs; rational f>=|d|, g>=0, h arbitrary. A=cI-H is entrywise nonnegative. V=sum(f+max(d,0))+2sum|h|+sum g bounds sum local generator norms.

Target psi0=P0|+>/||P0|+>|| is PURE, even with a degenerate ground space. It is not the projector mixture and not any ground vector the user chooses. P0>=0 entrywise, and <+|P0|+>>=rank(P0)/2^n>=2^-n.

For tau>0, use a positive Euler product C applied to the ALL-ONES vector. A vector-specific word cutoff k0=O(tau V+n+log1/alpha), m=O(k0^2/alpha), yields entrywise relative (1+-alpha) approximation to e^{tau A}1. Minimum finite-time entries and particle-sector acquisition are unnecessary. Every amplitude is positive. This is a refinement of inherited Astra X's positive-word mechanism, not an unrelated discovery.

Admitted local symbols: the triangle six-vertex quadratic, the nonhomogeneous transverse-field symbol tg+u+v+tg uv (tg<=1), positive longitudinal linear factors, and terminals 1+x. Complement every BRA incidence when sewing norm/replica networks; then all internal wires are linear x+y. Forgetting bra orientation incorrectly introduces a non-log-concave 1+xy wire.

Coefficient-value programs, positive individual supports, log coefficient ranges and every-execution finite bit bounds are charged. Weighted bad-prefix mass, not union bounding exponentially many prefixes, supports a randomized classical compiler with reversible count programs.

## Pure low-energy and entanglement consequences

Gap-free: <psi_tau|H|psi_tau>-E0 <= n ln2/(2tau), by D(q||p)>=0 for the reweighted spectral distribution of |+>. tau=n/xi and polynomial trace accuracy give a pure state of energy <=E0+xi, and classical local-energy estimation through nonnegative matrix-element contractions. Quantum preparation alone is ALREADY covered by July 2607.14401 for a larger class.

Given a gap Delta above the ENTIRE ground space: T(psi_tau,psi0)<=2^(n/2)e^-tauDelta. tau Delta=O(n+log1/epsilon) suffices for ground-vector preparation. A 2q-copy positive contraction and tau Delta=O(nq+log(q/epsilon)) yield relative integer-q reduced-state moments with no inverse-purity cost; charge NUMERICAL q. Min-entropy follows from lambda_max^q<=M_q<=d lambda_max^q using q=O(n/epsilon). Do not infer S1 or the whole Schmidt spectrum.

## Later extension: rare ground events and ground-state fidelities

r=min positive f or g. Every configuration component has diameter <=D=2n^2: with a flip site, empty via nearest-particle exchanges and flips, then reconstruct; without flips, use conserved-particle leaf fixing.

Acquire gamma=2^-n min(1,r/V)^D (gamma=2^-n if there are no off-diagonal rates). Every nonzero selected-ground amplitude is at least gamma. Proof: Perron eigenvector ratios along edges >=r/V, one maximum coordinate >=1/sqrt(block size), overlap of each normalized Perron vector with |+> >=2^-n/2. Normalize P0|+> by a number <=1.

For a specified basis cylinder E, p0(E) is ZERO or >=gamma^2. Cool to Euclidean error <=epsilon gamma/128; this needs tau Delta=O(n+log1/gamma+log1/epsilon), NOT gamma^-1. Relative vector approximation alpha=O(epsilon) protects the finite-time rare event. Count its weight relatively, separate zero at threshold gamma^2/4, and compile the conditioned vector. Zero detection is randomized under the gap promise, NOT exact detection by the positive finite-time network.

Two selected ground vectors have overlap G zero or >=gamma_H gamma_K. Cool to error O(epsilon gamma_H gamma_K), evaluate their positive cross-network contraction and norms relatively, distinguish zero, estimate F=G^2 relatively. No inverse-fidelity cost. Requires same admitted basis/no phases.

Conditioned integer Renyi moments: strengthen cooling error to epsilon gamma/[1024 q 2^{n(q-1)}]; needed time stays polynomial in nq+log1/gamma. Largest conditional reduced eigenvalue/min-entropy follow. No arbitrary predicate or arbitrary projector.

When ALL g_i>0, acquire Delta=2 min g_i by the PRIOR BGLW theorem 2607.14401v1: Hadamard rotates the model into Suzuki–Fisher with Jz=Jyy=f/2,Jxx=-d/2,mu_z=g,mu_x=-h. This bound and the quantum adiabatic consequence are not new. Numerical 1/min g is charged. With any g_i=0 the minimum-field formula gives no positive certificate; keep the supplied gap unless another proved bound is available.

## Unconditional local structure and counterexamples

For a real symmetric two-qubit generator A with nonnegative off-diagonals, any near-identity nonnegative local symbol that is log-concave requires: pair creation A00,11=0; flip rates independent of the neighboring bit; |A00,00-A01,01-A10,10+A11,11|<=2 A01,10. Conversely this cone generates real-stability-preserving semigroups. This is a statement about that local representation, not all algorithms/gadgets.

Stable initial amplitude polynomial product(1+z) stays real stable under admitted evolution; the selected ground limit does too. NOT every vector in a degenerate ground space: ferromagnetic-Heisenberg GHZ is a counterexample.

p_k=sum_j e_j(A)e_{k-j}(B)/binom(k,j) on two disjoint k-site sets is real stable. Its squared coefficients have profile J uniform 0..k, hence alpha-fractional log-concavity requires alpha<=3/(k+2). This family is an actual unique ground state of .5 sum_cross(ZZ-XX-YY) on Kkk, with exact global gap2. Thus poor Born-law fractional log-concavity does not imply a small physical spectral gap.

Stable fixed-charge amplitudes obey 2v_Av_B/||v||^2<=2/(k+1), sharp. Balanced-cat fidelity has the same bound; the tempting UNBALANCED version is false (k4 basis state). Correct general cat-fidelity envelope: k1=1,k2=2/3,k>=3=1/2. General positive stable amplitude states have vacuum/full GHZ fidelity <=1/2 for n>=2, in this basis.

## Strongest unclosed target and exact obstruction

EPR* K_s=.5(XX+sYY-ZZ), |s|<1, would extend a consequential local-Hamiltonian complexity classification. Stoquastic gates lie on critical eight-vertex b=a+c+d. Their local symbol has positive constant and positive quadratic curvature, so local LC fails at every small step. It has a positive 3-connection decomposition, but the XX*SWAP connection carries parity constraints. Three signed swaps around a triangle have trace0; unflipped swaps trace4. Dropping constraints and counting two assignments per loop is wrong.

Any ON-SITE unitary reduction into the number-conserving easy-plane cone needs local charge signs +/-Y that alternate along every edge: commutator i(sigma_i+sigma_j)(ZiXj+XiZj). For |s|<1, the weak singular axis is unique, so this requires bipartiteness. Ancillas/nonlocal/gadget/other counting representations are not ruled out.

Astra W's general microscopic parity sampler/energy comparison remains unclosed. Exchange, aggregate capacity, positivity, physical gap, or support acquisition do not by themselves acquire that sampler.

## Execution and resume priorities

Read four proof notes and all three check outputs before transferring. No independent workers, Lean proof, general FPRAS, high-precision compiler or GitHub write occurred. Novelty of combined consequences is unresolved; source route/finite-bit/full proof audit and actual implementation remain substantial work.

A continuation should not re-prove the July field gap or present old EPR counting/XY simulation as new. The substantive unresolved escalation is a positive, ACQUIRED, precision-charged algorithm for frustrated critical eight-vertex/EPR* instances, or a different route around that exact obstruction. The current rare-ground-event theorem should first receive an independent mathematical and prior-art audit, especially the bra sewing and weighted-prefix finite-bit interfaces.
