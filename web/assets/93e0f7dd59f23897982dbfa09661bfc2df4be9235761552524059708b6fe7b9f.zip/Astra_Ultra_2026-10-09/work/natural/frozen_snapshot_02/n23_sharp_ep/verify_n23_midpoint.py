"""Reproduce a finite 4-cycle midpoint-factorization check (stdlib only)."""
import math


def mm(A, B):
    n, m, k = len(A), len(B), len(B[0])
    return [[sum(A[i][j] * B[j][l] for j in range(m)) for l in range(k)] for i in range(n)]


def exp_generator(Q, time):
    """Uniformization for a row-generator; the omitted Poisson tail is tiny."""
    n = len(Q)
    rate = max(-Q[i][i] for i in range(n))
    x = rate * time
    R = [[(1.0 if i == j else 0.0) + Q[i][j] / rate for j in range(n)] for i in range(n)]
    power = [[1.0 if i == j else 0.0 for j in range(n)] for i in range(n)]
    weight = math.exp(-x)
    cumulative = weight
    P = [[weight * power[i][j] for j in range(n)] for i in range(n)]
    order = 0
    while 1.0 - cumulative > 1e-15:
        order += 1
        power = mm(power, R)
        weight *= x / order
        cumulative += weight
        for i in range(n):
            for j in range(n):
                P[i][j] += weight * power[i][j]
        if order > 10000:
            raise RuntimeError("uniformization failed to converge")
    return P


def generator(clockwise, counterclockwise):
    Q = [[0.0] * 4 for _ in range(4)]
    for i in range(4):
        Q[i][(i + 1) % 4] = clockwise
        Q[i][(i - 1) % 4] = counterclockwise
        Q[i][i] = -(clockwise + counterclockwise)
    return Q


def bernoulli_jeffreys(u, v):
    if u == v:
        return 0.0
    return (u - v) * (math.log(u / (1 - u)) - math.log(v / (1 - v)))


# Set t=1, J t=pi, S t=4>pi. Then Js=pi/2 at s=t/2.
t = 1.0
J = math.pi / t
S = 4.0 / t
a = (S + J) / 2
b = (S - J) / 2
s = t / 2
Q = generator(a, b)
Qstar = generator(b, a)
Ps = exp_generator(Q, s)
Pstars = exp_generator(Qstar, s)
Pt = exp_generator(Q, t)
observed = {0, 1}

def obs_probability(P, i):
    return sum(P[i][j] for j in observed)

U = [obs_probability(Pstars, i) for i in range(4)]
V = [obs_probability(Ps, i) for i in range(4)]
midpoint_cost = sum(bernoulli_jeffreys(U[i], V[i]) for i in range(4)) / 4
p11 = sum(Pt[i][j] for i in observed for j in observed) / 4
p = 0.5
covariance = p11 - p * p
delta = 0.25 * math.exp(-S * t)
relaxation = 8 * math.sqrt(delta) * math.atanh(2 * math.sqrt(delta))
epr_t = 2 * (J * t) * math.atanh(J / S)

assert max(abs(U[i] + V[i] - 1.0) for i in range(4)) < 2e-13
assert max(abs(abs(U[i] - V[i]) - math.exp(-S * s)) for i in range(4)) < 2e-13
assert abs(covariance + delta) < 2e-13
assert abs(midpoint_cost - relaxation) < 2e-12
assert 0 < b < a

print(f"t={t:g}, a={a:.12g}, b={b:.12g}, S={S:.12g}, J={J:.12g}")
print(f"U={['%.12g' % x for x in U]}")
print(f"V={['%.12g' % x for x in V]}")
print(f"covariance={covariance:.12g}; delta={delta:.12g}")
print(f"midpoint Jeffreys={midpoint_cost:.12g}; K relaxation={relaxation:.12g}")
print(f"actual EPR*t={epr_t:.12g}; strict gap={epr_t-midpoint_cost:.12g}")
