# Sources, dependencies, and prior-art boundary

Access date: 7 October 2026. The research used primary sources for the complexity interfaces. A bounded search is not a novelty certificate. Full third-party papers are not copied into this package.

## Established mathematical dependencies

**Scott Aaronson, arXiv:quant-ph/0412187 (2004), Quantum Computing, Postselection, and Probabilistic Polynomial-Time.** The PostBQP=PP theorem, the conditional acceptance gap, and the finite-gate formulation are inherited. The abstract and parsed PDF text including Definition 1, Proposition 2, and Theorem 4 were read. The H/Toffoli denominator observation in the proof supplies a known exponential probability lower bound. Web PDF screenshot attempts failed; no visual verification of PDF figures is claimed. Our construction does not require the figure.

**Scott Aaronson, arXiv:1109.1674 (2011), A Linear-Optical Proof that the Permanent is #P-Hard.** Theorem 3 and the accompanying KLM reconstruction are inherited, including dual rails, deferred photon heralds and controlled-sign success amplitude 1/4. The relevant parsed text on PDF pages 7–8 was read. The nonlinear-sign and two-photon Hadamard algebra was separately replayed symbolically. Screenshot requests failed. The paper itself already explains how postselection yields optical complexity consequences; that broad observation is not a discovery here.

## Closely related prior art, not new premises

**C. N. Gagatsos et al., arXiv:1403.6054; Physical Review A 89, 062311 (2014).** Noiseless amplification/attenuation is established prior art. Abstract and bibliographic information were checked. Lemma 2 is derived directly from the loss Kraus formula and does not rely on an unread technical lemma from this source.

**C. S. Hamilton et al., arXiv:1612.01199, Gaussian Boson Sampling.** Standard Gaussian photon-counting framework; abstract/model context inspected. No claim to have introduced Gaussian inputs or squeezed-pair heralding.

**D. Grier, D. J. Brod, J. M. Arrazola, M. B. de Andrade Alonso, N. Quesada, arXiv:2110.06964, The Complexity of Bipartite Gaussian Boson Sampling (2021).** Bipartite Gaussian/permanent programming and conditional/average-case hardness are prior art. Abstract checked; HTML retrieval attempt failed. The present proof derives its particular bipartite state directly from squeezed pairs and a passive unitary. It does not claim a new bipartite GBS encoding, nor does it require this paper's average-case assumptions.

**B. Go, C. Oh, H. Jeong, arXiv:2511.07853v1 (2025), Sufficient conditions for hardness of lossy Gaussian boson sampling.** Abstract/model and theorem discussion were screened. That work studies different loss/hardness regimes and assumptions. Our exponentially rare fixed-herald result is not a replacement for unconditional lossy-GBS hardness or experimental advantage.

**T.-Y. Yang et al., arXiv:2205.02586 (2022), Post-selection in noisy Gaussian boson sampling: part is better than whole.** Abstract screened in the prior-art search. Photon-loss mitigation by postselection is not novel. No full technical comparison or novelty clearance was obtained.

**Y. Lim, arXiv:2610.06526v1 (5 October 2026), Classical Simulation of Lossy Gaussian Boson Sampling beyond Square-Root Regime.** Inherited source of the previous run's centered-reset algorithm. The supplied previous research proof/status was read, and current source retrieval was attempted; access was intermittent. The new complexity theorem does not depend on Lim's claims or the previous candidate simulation theorem.

## Prior research capital actually used

The supplied `RESEARCH_STATE.txt` and first portion of `PROOF.md` from `astra_spectral_loss_research_20261007.zip` were read through Files. The specific quantities S3, the passive Schur quantity D, and Phi guided the counterexample family. Their values are calculated directly here; prior source-reported checks were not relabelled as new checks.

The Astra repository `01_CORE.txt` and `web/S-reports.txt` were refreshed through the connected GitHub tool. The entry-point instructions had been read in the preceding investigation. Relevant records were the positive-kernel herald limitation (N42–45), all-phase herald-energy scope (N64), projected-Slater acquisition boundary (N63), and the unresolved mixed bounded-Holevo interface (N69). These were scientific routing information, not validated theorem premises. The new group/detection/one-query results were screened for opportunity but not rederived or advertised as new.

The final observed repository main ref was `4e87286828313f5a66711e9f2d2c165dd92fcb86`. Earlier reads used main; the final ref is not asserted to identify every earlier response in the presence of possible concurrent changes.

The Chen–Liu arXiv:2610.06724 import mentioned in S was not independently validated: primary retrieval attempts were incomplete. No result in this package relies on it. No OpenAI mathematical result-family theorem is used as a premise of HO1, and no full release audit was performed.

## Proposed deduction versus established machinery

The complete restricted-family composition is the proposed deduction: explicit loss-sector filtering plus polynomial-bit source acquisition, high-loss constant-gap two-mode readout, vanishing higher spectral moments, and bounded conditional mean. Its correctness still needs external review. Its historical novelty is not established; substantial components, and the basic postselection-hardness strategy itself, are long-established.

The proof does not treat agreement among internal calculations, numerical residuals, citations, or archive hashes as certification. `VERIFICATION.json` contains only tests actually executed in this continuation.
