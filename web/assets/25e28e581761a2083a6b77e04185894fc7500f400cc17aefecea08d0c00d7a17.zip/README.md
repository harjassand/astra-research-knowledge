# Astra research continuation: rare-herald obstruction

This package preserves a proposed complexity-theoretic obstruction to extending the earlier weak-loss simulation result into a general arbitrary-phase conditional sampler without inverse herald-success costs.

Start with `RESULT_CARD.md`, then `PROOF.md`. `RESEARCH_STATE.txt` is the compact resumable state. `BREADTH_AND_FAILURES.md` records the selected route and distinguishes it from branches that were only screened. `SOURCES_AND_PRIOR_ART.md` records established dependencies and read depth.

The main implication is: an efficient constant-error classical conditional sampler of the specified type would give PP=BPP, even on uniformly highly lossy, exponentially weak Gaussian inputs, and even for a two-mode conditional output of bounded expected energy. A quantum conditional sampler would give PP=BQP. Neither complexity separation is proved.

Run the finite diagnostics with:

```sh
python tests/verify_obstruction.py
```

They require Python 3.10 or later, NumPy and SymPy. Their output is `VERIFICATION.json`. No quantum simulator package, GPU, network access, or external credentials are required. The code is a diagnostic suite, not a general Gaussian compiler, conditional sampler, or PP solver.

`PROVENANCE.json` records source handles and hashes of the preceding supplied research capital. `MANIFEST.json` records hashes of the files in this package. Hashes check artifact identity, not mathematical validity. No font files or full third-party manuscripts are included.

The GitHub repository was read but not modified. All claims retain candidate/internal status pending external correctness and prior-art review.
