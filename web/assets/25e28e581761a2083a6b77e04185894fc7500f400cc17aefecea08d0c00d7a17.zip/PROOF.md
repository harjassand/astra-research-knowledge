# Rare conditional photonic computation inside a vanishing loss certificate

Research date: 7 October 2026.

**Status.** A self-contained reduction candidate, using established PostBQP = PP and postselected linear-optical universality. The new loss/filter, finite-input, energy, and spectral interfaces have been derived here and tested on finite fixtures. No external proof review, formal verification, historical priority clearance, or complete universal compiler execution is claimed. This is a complexity-theoretic obstruction to a specific proposed extension, not a separation of complexity classes.

## 1. The problem and the obstruction

The previous research state obtained a candidate *unconditional* simulation bound controlled by

\[
S_3(T)=\operatorname{Tr}[(T^*T)^3].
\]

A potentially much more consequential extension would combine such small-loss certificates with probability-free heralding: given a Gaussian optical experiment and a specified photon herald, sample the conditional output without paying an inverse herald-probability cost, even when its amplitudes have arbitrary phases. This note tests that extension rather than improving the unconditional cubic bound.

A pure, centered, d-mode Gaussian state is specified by a complex symmetric matrix B with operator norm below one:

\[
|\psi_B\rangle=\det(I-BB^*)^{1/4}
 \exp\!\left(\frac12 a^* B(a^*)^T\right)|0\rangle.
\tag{1}
\]

The norm and all energies use the standard convention that a photon has unit excitation energy. Apply pure vacuum loss of power transmission eta to every mode. Fix herald modes H, a specified pattern k in {0,1}^H, and two other detector modes Z. Other modes may be ignored. Let P(B,eta,H,k;Z) be the conditional two-mode count law, provided the herald has positive probability. The input description is a symmetric rational-complex B, rational eta, and the finite sets and pattern. No real-number oracle or exact conditional probability is supplied.

**Theorem 1 (candidate reduction).** Suppose one randomized classical algorithm, on all such inputs in the family constructed below, outputs a sample with total-variation distance at most 1/100 from P, in time polynomial in the input bit length. Then PP = BPP. The implication still applies to a runtime polynomial in 1/eta, the herald photon count, the numerical input/output energies, or a supplied polynomial-bit logarithmic bound on inverse herald probability: all those quantities are polynomially bounded on the constructed family.

The family can simultaneously satisfy, for an integer R tending to infinity:

\[
d=\Theta(R),\qquad \eta=1/R,\qquad
S_p(T)\le d/R^p=O(R^{1-p})\quad(p>1),
\tag{2}
\]

and

\[
\|B\|\le g=2^{-\ell},\quad \ell\ge R,\qquad
E_{\rm in}\le2dg^2,\quad E_{\rm out}\le2d\eta g^2.
\tag{3}
\]

In particular S_3=O(d^{-2}) and the unconditional count law is exponentially close to the point mass at the all-vacuum record. Nevertheless, the conditional counts of just two modes retain a constant-gap PP decision problem. The conditional expected photon number in *all unheralded modes* is bounded by eta(h+1/100), where h=|k|=O(R). Hence even conditional output energy is O(1).

This is an implication, not the assertion that PP differs from BPP. Its usual impossibility interpretation assumes PP != BPP. It says nothing adverse about unconditional weak-light sampling, which is explicitly easy on these examples. It uses no average-case permanent or hafnian conjecture and no anti-concentration assumption.

A quantum polynomial-time conditional sampler instead gives PP = BQP by exactly the same reduction. That variant is not a claim that PP and BQP have been separated.

## 2. Exact filtering of a lossy photon herald

For density operators use trace distance T(rho,sigma)=||rho-sigma||_1/2. Let rho be any normalized state on H and its complement S. Write

\[
\rho_{n,n}=\langle n|\rho|n\rangle_H,\qquad
p_0=\operatorname{Tr}\rho_{k,k}>0,\qquad h=|k|.
\]

No Gaussianity, separability, finite Fock support, or faithfulness is assumed. Let F_g=g^{N_H}, with 0<g<=1/2, and normalize the filtered state by Z_g=Tr(F_g rho F_g). Apply pure loss eta>0 on H and any trace-preserving quantum channel Lambda on S.

**Lemma 2 (loss-robust filtering).** Conditional on observing k after loss, the retained state has trace distance at most

\[
\frac{2g^2}{p_0}
\tag{4}
\]

from Lambda(rho_{k,k}/p_0). The bound is independent of eta.

**Proof.** A single-mode loss Kraus operator for l lost photons sends

\[
|n\rangle\longmapsto
\sqrt{\binom nl}\,(1-\eta)^{l/2}\eta^{(n-l)/2}|n-l\rangle.
\]

Consequently the unnormalized post-herald state, before applying Lambda, is

\[
\frac{\eta^h g^{2h}}{Z_g}
\left[\rho_{k,k}+
\sum_{l\ne0}
 ((1-\eta)g^2)^{|l|}
 \prod_{i\in H}\binom{k_i+l_i}{k_i}\,
 \rho_{k+l,k+l}\right].
\tag{5}
\]

Off-diagonal blocks do not enter: for each loss Kraus index, the observed k fixes the original occupation to k+l on both sides. The bad terms are positive operators, not signed approximations.

For k_i in {0,1}, binom(k_i+l_i,k_i)<=2^{l_i}. Put a=2(1-eta)g^2<=1/2. Every nonzero coefficient in the sum is at most a^{|l|}<=2g^2. The included diagonal block traces sum to at most one, so the bad trace b is at most 2g^2. After normalization the retained state is a mixture with ideal weight p_0/(p_0+b). Its distance from the ideal state is at most b/(p_0+b)<=2g^2/p_0; Lambda cannot increase that distance. Positive partial sums justify the formula and bound for countable Fock support. QED.

The herald success probability has the explicit lower bound

\[
p_{\rm new}\ge \eta^h g^{2h}p_0/Z_g
              \ge \eta^h g^{2h}p_0,
\tag{6}
\]

since Z_g<=1. This is not a lower bound on the efficiency of a physical experiment: its value will be extremely small.

The dependence on p_0 in (4) is real. For a target one-photon branch with probability p_0 and an orthogonal two-photon contaminant with probability 1-p_0, the exact bad posterior weight is

\[
\frac{2(1-\eta)g^2(1-p_0)}{p_0+2(1-\eta)g^2(1-p_0)}.
\tag{7}
\]

Thus an input-independent constant g cannot protect arbitrarily rare target branches by this argument. The compiler below uses a *known lower bound* on p_0, not its unknown exact value.

The elementary generalization to a target with max_i(k_i+1)=K uses binom(k_i+l_i,k_i)<=K^{l_i}. When Kg^2<=1 the same argument gives Kg^2/p_0. The binary case suffices for the reduction.

## 3. The inherited computational encoding

We use the established theorem PostBQP = PP [A05]. For a language in PP, a polynomial-time classical compiler produces a polynomial-size quantum circuit, a postselection event of probability at least 2^{-q_post}, and a decision bit whose conditional probability p_x satisfies

\[
p_x\ge2/3\quad\text{on YES inputs},\qquad
p_x\le1/3\quad\text{on NO inputs}.
\tag{8}
\]

The circuit is taken over a fixed algebraic gate set. A polynomial, known q_post is part of the standard construction; arbitrary real gates with uncharged precision are not allowed. In an H/Toffoli realization, a circuit containing m_H Hadamards has basis amplitudes that are integers divided by 2^{m_H/2}; thus every nonzero terminal event has probability at least 2^{-m_H}. This supplies a computable lower bound without evaluating the event.

Choose R to be the smallest power of four at least the original circuit size, q_post, and 100, increasing the lower bound by their sum if necessary. Before the optical loss, coherently copy the computational-basis decision bit to R dual-rail readout qubits with CNOT gates and clean ancillas. This uses O(R) gates. It is a copy of a basis value, not a cloning transformation on arbitrary unknown quantum states.

Postselected linear optics implements each one-qubit gate exactly and each controlled-sign gate with a known success amplitude 1/4, using only constant-size optical gadgets [A11, Theorem 3 and its proof]. All the successful auxiliary photon patterns contain only zeroes and ones. Modes measured for success are never used again, so those measurements may be deferred to the end.

For clarity, one inherited nonlinear-sign primitive can be checked without trusting numerical gate synthesis. Its target/one-photon-ancilla submatrix is the contraction

\[
A=\begin{pmatrix}
1-\sqrt2&2^{-1/4}\\
2^{-1/4}&1/2
\end{pmatrix}.
\tag{9}
\]

Its eigenvalues are 1 and 1/2-sqrt(2), so a passive unitary dilation with vacuum ancillas exists. Conditioning the ancilla back to one photon and the dilation modes to vacuum gives target occupations 0,1,2 the amplitudes 1/2,1/2,-1/2. Two such primitives conjugated by the two-mode Hadamard implement the controlled sign with amplitude 1/4. These gadgets and universality are prior art, not the new contribution here. Our symbolic tests replay their low-photon algebra, not universal computation on all inputs.

### Compressing the readout into two detector modes

Apply a balanced R-mode interferometer separately to the two sets of readout rails. Its first row is the constant vector 1/sqrt(R). The normalized Walsh-Hadamard matrix is one exact rational choice because R is a power of four. Postselect every output except the first port of each interferometer to vacuum.

For an occupied rail set initially in |1,...,1>, the amplitude of |R,0,...,0> is

\[
\alpha_R=\frac{\sqrt{R!}}{R^{R/2}},\qquad
b_R=|\alpha_R|^2=\frac{R!}{R^R}\ge R^{-R}.
\tag{10}
\]

For the empty rail set the transformation and vacuum herald succeed with amplitude one. Consequently both logical branches receive the same amplitude alpha_R. The readout now lies in the span of |R,0> and |0,R>, with decision weight p_x unchanged. Additional data registers may remain entangled with these branches; they can be ignored. This construction only adds zero-photon conditions to H and does not require high-occupation herald entries.

Let n be the number of single-photon inputs to this linear-optical construction and Gamma its number of controlled-sign gates. Both are O(R), and its number of modes is O(R). This includes the ancillas and the fan-out cost; no readout protection is free.

## 4. Replacing all single-photon inputs by Gaussian sources

Replace each single photon by one arm of a two-mode squeezed vacuum with pair amplitude t=1/2; retain every idler as a herald mode with target occupation one. The probability of that idler occupation is

\[
(1-t^2)t^2=3/16\ge2^{-3}.
\]

Let U denote the full passive signal interferometer, including the deferred KLM gadgets and the readout bunchers, and P the isometric injection of the n occupied inputs into its signal modes. The complete pre-herald state is the centered pure Gaussian with

\[
B_0=\begin{pmatrix}
0&tUP\\
tP^TU^T&0
\end{pmatrix},\qquad \|B_0\|=1/2.
\tag{11}
\]

All idlers belong to H. H also contains the gate-success monitors, the original quantum postselection rails, and the vacuum buncher monitors. The full target k is binary. Let h=|k|. The desired no-loss herald has probability

\[
p_0\ge(3/16)^n16^{-\Gamma}2^{-q_{\rm post}}R^{-R}
    \ge2^{-q}=:p_*,
\tag{12}
\]

where one explicit known integer is

\[
q=3n+4\Gamma+q_{\rm post}+R\lceil\log_2R\rceil=O(R\log R).
\tag{13}
\]

There are d=Theta(R) modes and h<=d=O(R). The exact success probability is not evaluated.

Applying the mathematical filter F_g on H changes (11) to the Gaussian matrix

\[
B_g=G_gB_0G_g,
\tag{14}
\]

where G_g is diagonal, g on H and one on its complement. This follows directly from F_g a_i^* F_g^{-1}=g a_i^* for a herald mode. The normalized filtered Gaussian can be specified and prepared as a Gaussian state directly; the algorithmic input does **not** obtain a physical filter for free and does not condition a physical attenuation experiment to construct its source.

Every nonzero block of B_0 joins an idler to a signal mode. Since every idler is filtered, ||B_g||<=g/2. This is why the construction can be made globally weak; filtering arbitrary subsets of arbitrary Gaussian states would not imply that estimate.

## 5. A finite rational compiler without hidden real precision

A direct approximation of B_g at the very end would need an error budget tied to the much smaller final herald probability. It is better to approximate the *unfiltered* source first and then perform (14) exactly in rational arithmetic.

**Lemma 3 (conservative Gaussian continuity).** For complex symmetric matrices B,C with norms at most 5/8,

\[
T(\psi_B,\psi_C)\le16\,2^d\|B-C\|.
\tag{15}
\]

**Proof.** Let F(B)=exp(a^*B(a^*)^T/2)|0>. The Fock vector is holomorphic on the symmetric matrix unit ball and

\[
\|F(B)\|=\det(I-BB^*)^{-1/4}\ge1.
\]

Along the line from B to C, a complex circle of radius 1/8 in any unit-operator-norm symmetric direction stays in the ball of radius 3/4. On that circle ||F||<=(16/7)^{d/4}<=2^d. The Banach-valued Cauchy estimate bounds the directional derivative by 8*2^d. Integrating along the line and normalizing, using the lower norm bound one, gives a vector distance at most 16*2^d||B-C||. Pure-state trace distance is at most that vector distance. QED.

Round B_0 to a symmetric complex dyadic matrix B_0', preserving its idler/signal zero blocks. Round each real and imaginary part within 2^{-b}. Then

\[
\|B_0'-B_0\|\le2d2^{-b}.
\]

Choose

\[
b\ge\max\left\{
 d+q+\lceil\log_2(12800d)\rceil,
 \lceil\log_2(16d)\rceil
\right\}.
\tag{16}
\]

Thus ||B_0'||<=5/8 and the source states differ in trace distance by at most p_*/400. A quantum instrument recording the herald flag cannot increase trace distance. Its success probabilities differ by at most p_*/400, so p_0'>=p_*/2. Normalizing the two success blocks gives conditional trace distance at most 2(p_*/400)/p_0<=1/200. This uses the *pre-filter* herald p_0, not the final success probability.

Take

\[
\ell\ge\max\{R,\lceil(q+10)/2\rceil,2\},\qquad g=2^{-\ell},
\tag{17}
\]

and form the rational matrix

\[
B'=G_gB_0'G_g
\tag{18}
\]

exactly. Its norm is at most (5/8)g<=g. Each nonzero entry receives a factor g or g^2, so its bit length is O(b+ell). The source matrices in (11) have fixed algebraic gate entries and polynomial-size products, and can be approximated to (16) in polynomial bit time. The final description has polynomial size. There is no implementation here of this full general-purpose compiler; this paragraph is the proof-level resource argument.

Apply Lemma 2 to the state defined by B_0'. With eta=1/R it gives loss-induced herald contamination at most

\[
\frac{2g^2}{p_0'}\le\frac{4g^2}{p_*}\le1/256<1/100.
\tag{19}
\]

Together with source rounding, the two-mode conditional output law for the exactly specified rational B' is within 1/100+1/200 of the ideal lossy readout law. Channel contraction handles the ignored data registers and all signal loss.

The final herald probability is positive with the explicit lower bound

\[
w_*=(1/R)^h g^{2h}2^{-q-1}.
\tag{20}
\]

Its logarithmic inverse obeys

\[
\log_2(1/w_*)=h\log_2R+2\ell h+q+1=O(R^2\log R).
\tag{21}
\]

The gain is exponentially small in a polynomial parameter, but it needs only polynomially many bits. The original arbitrary-real construction and this rational approximation are not silently identified: the conditional error budgets in (15)--(19) provide the bridge.

## 6. Why fixed sampling accuracy is sufficient despite nearly complete loss

On the ideal no-loss herald branch, the two chosen readout modes carry R photons entirely in rail zero or entirely in rail one. After uniform loss eta=1/R their count law is

\[
P(0,0)=(1-1/R)^R,
\]

and, for j>=1,

\[
P(j,0)=(1-p_x)\binom Rj R^{-j}(1-1/R)^{R-j},
\]

\[
P(0,j)=p_x\binom Rj R^{-j}(1-1/R)^{R-j}.
\tag{22}
\]

Coherences between |R,0> and |0,R> do not affect these count probabilities. The ideal two-mode mean is exactly one.

The classical decoder reports the occupied rail if any photon is present, and otherwise produces a fair random bit. On invalid patterns it may use any fixed rule. Its success-readout probability is

\[
a_R=1-(1-1/R)^R\ge1-e^{-1}.
\]

Therefore its probability of output one is

\[
\frac12+a_R(p_x-\tfrac12).
\tag{23}
\]

By (8), the YES/NO gap from 1/2 is at least (1-e^{-1})/6>0.105. Source rounding, filtering contamination, and an additional conditional sampling error of 1/100 cost less than 3/100 in total. The remaining decision gap exceeds 3/40. Independent repeated calls and majority vote give bounded-error classical decision with polynomial resources. This puts every PP language in BPP. The reverse containment BPP subset PP is immediate from their acceptance definitions, yielding PP=BPP.

The output is a single classical bit, so the reduction would already work against an algorithm that approximates just this bounded conditional decision statistic. It does not depend on approximating every small probability separately. Replacing the hypothetical classical sampler by a uniform quantum polynomial-time sampler gives PP subset BQP and hence PP=BQP, using BQP subset PP from [A05].

## 7. Weakness, spectral moments, and conditional energy

Any B' in (18) is a valid pure Gaussian input. Its Takagi singular values beta_j=tanh(r_j) satisfy beta_j<=g. Mean input and output energies are

\[
E_{\rm in}=\sum_j\frac{\beta_j^2}{1-\beta_j^2}
\le2dg^2,\qquad E_{\rm out}=\eta E_{\rm in}.
\tag{24}
\]

Its squeezed-input/passive-preparation realization has a lossless passive matrix V followed by uniform loss. Thus T=sqrt(eta)V on occupied input columns; for every fixed p>1,

\[
S_p(T)\le d\eta^p=d/R^p\longrightarrow0.
\tag{25}
\]

In particular the cubic loss certificate vanishes as O(R^{-2}). Independently of any candidate Gaussian-reset theorem,

\[
\operatorname{TV}(P_{\rm unconditional},\delta_{\rm vacuum})
=\Pr(N_{\rm out}>0)\le E_{\rm out}\le2(d/R)2^{-2\ell}.
\tag{26}
\]

The unconditional model is not a hard boson-sampling instance at fixed additive accuracy.

### The prior Schur/Lyapunov certificate also vanishes

On each occupied input mode put n_j=beta_j^2/(1-beta_j^2), m_j=beta_j/(1-beta_j^2). In quadrature coordinates K_0=Sigma_0-I/2 has eigenvalues eta(n_j+m_j) and eta(n_j-m_j). The prior passive Schur quantity is exactly D=eta I on active modes. Take the analytical shift B_sh=eta/(1-eta) I. For eta<=1/10, g<=1/4,

\[
Y_0=K_0+B_{\rm sh}\succeq0,\quad
\|Y_0\|\le2\eta,\quad
\operatorname{Tr}K_0^2\le(32/9)d\eta^2g^2.
\]

Consequently

\[
\Phi_0=\operatorname{Tr}(Y_0K_0^2)\le8d\eta^3g^2.
\tag{27}
\]

These are direct matrix estimates. The complexity reduction does not assume the previous reset theorem is true; it only demonstrates that its concrete certificate can be extremely small on the present inputs.

### Conditional energy remains bounded, including rounded inputs

The preserved zero blocks in B_0' imply that every creation pair contains exactly one idler and one signal photon. Hence every Fock component satisfies N_idler=N_signal. All idlers are in H. Conditional on the *pre-loss* herald occupation k+l, the number of photons in S=H^c is at most h+|l|.

In (5), the coefficient for l is at most a^{|l|}, where a=2(1-eta)g^2<=1/2. For each integer L>=1, L a^L<=a. Summing block traces therefore bounds the extra photon moment by 2g^2, and

\[
\mathbb E[N_S\mid\text{observed }k]
\le\eta\left(h+\frac{2g^2}{p_0'}\right)
\le\eta(h+1/100).
\tag{28}
\]

This argument bounds an unbounded observable directly; it does not infer an energy bound from a small trace-distance error. It survives the rational compiler because the bipartite zero blocks were preserved. Since h=O(R), the bound is O(1), and it also holds for the two chosen detector modes.

At any fixed tail tolerance, Markov's inequality reduces the two-mode count law to a number of possible records bounded independently of R. For example, a cutoff K>=100 eta(h+1/100) loses at most 1/100 of the probability and leaves at most (K+1)(K+2)/2 count pairs. The obstruction is thus **not a necessary explosion of output Fock dimension**. Even a bounded-alphabet approximation requires acquiring a phase-sensitive conditional weight.

In the ideal readout law (22), the only instance-dependent parameter is p_x; all the binomial factors are elementary. Once p_x is supplied, sampling is easy. The hard task is computing or sampling that parameter from the Gaussian experiment's succinct description. This is a concrete acquisition-versus-representation distinction.

## 8. Exact scope of the obstruction

The theorem rules out the proposed universal polynomial-time, constant-error, arbitrary-phase herald sampler *if* PP != BPP. It also blocks deriving such a sampler solely from vanishing S_p for p>1, small Phi_0, small unconditional energy, or a bounded conditional Fock cutoff. None of those certificates controls access to the rare phase-sensitive conditional weights.

It does not prove a lower bound proportional to 1/p_new, classify the optimal runtime dependence on herald probability, or exclude successful algorithms on structural subclasses. In particular a positive-kernel counting algorithm is not contradicted: its sign/phase restriction is substantive. The construction supplies no efficient physically successful postselection; its herald probability is extremely small. Pure vacuum loss, exact photon-number monitoring, and highly accurate source parameters are model assumptions. Dark counts, finite calibration error, arbitrary thermal noise, and laboratory advantage are not covered.

The result does not refute the repository's approximate-broadcasting or bounded-Holevo conjectures. Those are statements about reconstructing an already supplied state. Preparing or computing a state from an implicit, rare-event description is a different resource interface. The final count law here already belongs to a simple one-parameter classical family, yet acquiring that parameter would solve PP problems.

The general upper-simulation question without postselection, stronger positive representations, and non-Gaussian-core algorithms remain open in this investigation. The present endpoint is a precise barrier to the highest-consequence transfer actually pursued, not a barrier to all possible scientific progress.

## 9. Proof provenance and checks

Inherited: PostBQP=PP; postselected KLM universality, deferred success measurements, single-photon dual rails and the nonlinear-sign primitive; squeezed-pair heralding; Gaussian Bargmann parametrization; the noiseless attenuation operation; elementary loss Kraus operators and bosonic bunching. The novelty of those ingredients is not claimed.

Derived here: the exact positive-block contamination bound and its use with a known source-probability lower bound; joint composition with uniform inverse-size loss, constant-gap two-mode readout, vanishing all higher spectral moments, exponentially small unconditional energy and a bounded conditional-energy budget; structured rational rounding before the filter; the explicit comparison with the prior Schur/Lyapunov certificate. The full composition's priority has not been established by the bounded search.

The executable diagnostics verify finite instances of the Kraus formula, contamination and excess-energy bounds, inherited optical primitives, readout/bunching algebra, and resource inequalities. They do not run a general PP compiler or validate a universal quantifier. See VERIFICATION.json, tests/verify_obstruction.py, and SOURCES_AND_PRIOR_ART.md.

## References

[A05] Scott Aaronson, *Quantum Computing, Postselection, and Probabilistic Polynomial-Time*, arXiv:quant-ph/0412187 (2004); Proceedings of the Royal Society A (2005). Established PostBQP=PP theorem.

[A11] Scott Aaronson, *A Linear-Optical Proof that the Permanent is #P-Hard*, arXiv:1109.1674 (2011), especially Theorem 3 and its proof on PDF pages 7--8. This is the primary detailed KLM reconstruction used here.

[G14] C. N. Gagatsos, J. Fiurasek, A. Zavatta, M. Bellini and N. J. Cerf, *Heralded noiseless amplification and attenuation of non-Gaussian states of light*, Physical Review A 89, 062311 (2014), arXiv:1403.6054. Prior art for noiseless attenuation; its full technical proof is not a dependency of Lemma 2.

[H17] C. S. Hamilton et al., *Gaussian Boson Sampling*, arXiv:1612.01199. Background Gaussian photon-counting framework.

[GB21] D. Grier et al., *The Complexity of Bipartite Gaussian Boson Sampling*, arXiv:2110.06964. Existing bipartite Gaussian/permanent complexity machinery; the present note does not claim to introduce that encoding.

[L26] Youngrong Lim, *Classical Simulation of Lossy Gaussian Boson Sampling beyond Square-Root Regime*, arXiv:2610.06526v1, 5 October 2026. Source of the previous run's inherited centered-reset algorithm. Neither that algorithm nor the previous candidate error theorem is a premise of Theorem 1.

[ASTRA] Astra Research Knowledge, core plus Q/R/S updates, and the supplied spectral-loss proof package, accessed 7 October 2026. The source records retain candidate and conditional statuses.
