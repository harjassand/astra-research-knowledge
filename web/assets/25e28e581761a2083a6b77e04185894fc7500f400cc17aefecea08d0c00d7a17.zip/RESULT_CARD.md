# HO1 — Rare conditional computation defeats weak-loss certificates

**Status:** explicit reduction candidate; finite algebra/Kraus diagnostics executed; no external review or historical novelty certification. This is a route-specific complexity obstruction, not a proved complexity separation or a claimed revolutionary positive theorem.

**Question attacked:** Can the unconditional cubic spectral-loss simulation mechanism be combined with probability-free heralding and extended from positive Gaussian kernels to arbitrary phases, producing a uniform polynomial-time conditional sampler?

**Result:** A classical polynomial-time sampler at fixed TV error 1/100 for arbitrary-phase Gaussian photon counts conditioned on a specified binary photon herald would imply PP=BPP. This implication holds even for rational-complex, pure centered Gaussian inputs with uniform power transmission eta=1/R, d=Theta(R) modes, all higher transmission moments S_p<=d/R^p->0 for p>1, exponentially small unconditional mean photon energy, and bounded conditional output mean. Only TWO retained detector counts are needed to recover the PP decision. A quantum polynomial-time conditional sampler instead implies PP=BQP.

**Main mechanisms:** exact positive loss-sector decomposition after g^{N_H}; contamination <=2g^2/p0 independent of eta; postselected KLM inherited source; replace every single photon by one leg of a squeezed pair; copy the computational-basis bit R times and bunch each rail set to one mode, then herald all other buncher ports to vacuum; uniform eta=1/R leaves a constant readout probability >=1-e^-1; structured dyadic rounding BEFORE filtering preserves phase information with polynomial input bits; all idlers remain in H, yielding a direct conditional-energy bound.

**Spectral connection:** Uniform loss gives D=eta I for the old active-support Schur quantity. For beta_j=tanh r_j<=g<=1/4, the prior Phi certificate obeys Phi0<=8d eta^3 g^2. The reduction does not assume the old reset theorem is true. The unconditional law is independently within E_out of the vacuum point mass.

**Precisely inherited:** PostBQP=PP; KLM postselected universality and nonlinear-sign primitive; bipartite Gaussian encoding, noiseless attenuation, Gaussian parametrization, bosonic bunching. These are not new discoveries.

**Costs and promises:** Known Gaussian description and herald, pure vacuum loss, ideal photon-number measurement. q is a known source-probability lower-bound exponent, not the exact probability. g=2^-ell with ell=O(R log R); source and final matrix entries have O(R log R) bits; full description polynomial. Final herald success has lower bound 2^-O(R^2 log R) and is extremely rare. No physical efficient postselection or dark-count/calibration robustness. No inverse-herald runtime lower bound is proved; only a uniform polynomial sampler would cause the displayed collapse.

**Why finite output dimension does not rescue the route:** Conditional mean is O(1) even on the rational inputs. At fixed error the two-mode output can be truncated to a size-independent finite alphabet. The only instance-dependent parameter in the ideal output mixture is the hard conditional decision weight. The acquisition of that weight, not the existence of a small representation, is the obstruction.

**Limits:** No unconditional GBS hardness claim; no average-case or experimental quantum-advantage result; no statement about arbitrary thermal noise; no refutation of abstract quantum-classicality/low-Holevo reconstruction results. The positive-kernel subclass is not contradicted. PP!=BPP and PP!=BQP are not proved. Novelty of the complete restricted-family composition remains open.

**Executed:** tests/verify_obstruction.py; 1,596 assertions, comprising 1,396 exact/symbolic/integer checks and 200 floating-point Kraus/trace-distance checks. No general PostBQP compiler, PP benchmark, optical experiment, proof kernel, external reviewer, or repository write.

**Proof and restart:** PROOF.md is the current full statement. RESEARCH_STATE.txt contains the resumable compact state. SOURCES_AND_PRIOR_ART.md records read depth and external dependencies. BREADTH_AND_FAILURES.md distinguishes screened branches from genuine obstructions.
