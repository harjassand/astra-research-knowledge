# Exploration, selection, and failed transfers

The investigation refreshed the current repository core and the seven S result summaries rather than re-ingesting the entire archive. The previous spectral-loss proof and state were read from the supplied files. It was not a new audit of 722 manuscripts or all the repository's underlying proofs.

## Branches screened but not claimed solved or obstructed

**Hard-support detection (N62).** The newest record already contains an exact tensor variational law and a sharp level-count gain. The present investigation did not derive a comparably consequential adaptive or thermodynamic extension. Those remain separate questions; there is no new no-go claim for them here.

**Partition-projected Slater states (N63).** The reported FPRAS-driven acquisition route suggested searching for a much wider paired/amplitude-sensitive preparation principle. The specific Chen–Liu import was not independently validated; primary retrieval attempts were incomplete. The present theorem does not use it. An arbitrary-phase Gaussian conditional compiler encounters the PP obstruction instead of following from positive counting.

**Property(T) nonsofic constructions (N65).** New group and quotient consequences already existed in S. They were not relabelled as discoveries of this run. No new group-theoretic theorem was proved.

**Bounded-Holevo classicality (N69).** The general mixed-state conjecture remains unresolved here. Bounded information capacity does not itself supply a polynomial-time procedure to prepare a state from an implicit conditional description. The final two-detector hard family illustrates this acquisition boundary, but is not a counterexample to the abstract reconstruction conjecture.

**General Gaussian herald-energy bounds (N64), positive-kernel herald sampling (N42), and spectral loss.** This was the strongest concrete transfer: combine probability-free energy bounds and weak-light simulation with efficient rare conditioning, then remove the phase restriction. A successful unrestricted conditional compiler would have consequences far beyond a better simulation exponent. The proof in this package identifies its complexity obstruction.

## Route revisions that materially strengthened the result

1. **Naive conditioning of a good unconditional approximation fails.** If two distributions differ only on an event of probability p, their unconditional TV can be p while their conditional TV is one. This standard fact alone is not a complexity lower bound. The full PP reduction is stronger and is the relevant endpoint.

2. **Postselected ideal universality alone does not settle high-loss conditional sampling.** Herald detectors can receive extra photons and lose some, creating false success. The exact positive loss-sector formula and g^{N_H} filtering control this contamination. Its p0 dependence cannot be suppressed without changing the algorithmic input structure.

3. **One readout photon gives only an O(eta) decision gap.** A conditional sampler with fixed TV error could then erase all the information at eta->0. The basis-bit fan-out uses R=1/eta photons before loss. This is charged O(R) circuit work. It restores a constant readout gap.

4. **Many readout modes are unnecessary.** Balanced bunching and vacuum heralds convert the R copied rail bits into two readout modes. This leaves the same decision weight and the same constant survival probability, while adding only an explicitly charged rare success event. The final marginal has two detectors and bounded mean photon energy.

5. **Rounding the final Gaussian at arbitrary absolute precision hides a conditioning cost.** Round the unfiltered Gaussian source with a known p0 lower bound instead, preserve its bipartite zero structure, and multiply by the dyadic filter exactly. Source precision is O(R log R) bits per entry, even though the final inverse herald-probability logarithm is O(R^2 log R).

6. **Small trace distance does not control an unbounded energy observable.** The conditional energy estimate is proved directly from the bipartite photon-number identity and the weighted loss-sector first moment. It is not transferred from the ideal readout by trace distance.

## Precise barrier and surviving possibilities

The new obstruction concerns a *uniform*, probability-free, arbitrary-phase conditional sampling/preparation algorithm. It does not rule out a positive kernel subclass, a nonnegligible success promise, restricted phase complexity with explicit runtime dependence, or a method supplied with conditional weights by a separately charged procedure. It also does not restrict stronger unconditional simulation algorithms.

No result here proves PP != BPP, PP != BQP, or a lower bound proportional to inverse herald probability. The implication to a complexity-class collapse is the theorem; the usual computational impossibility interpretation is conditional.

The strongest conceptual conclusion is that vanishing spectral/nonclassicality certificates and a small output representation cannot by themselves acquire the phase-sensitive weights of an exponentially rare event. The next useful positive theorem must change that interface, not merely optimize the old covariance or cutoff constants.
