CERTIFIED DICKE / AXIAL GIBBS COMPILERS — REPLAY GUIDE
C03_S01, fixed130 continuation, 8 October2026 Brisbane.

These programs acquire finite product-ensemble descriptions for explicitly
KNOWN input states. Every accepted output has a rational posterior accuracy
certificate. They do not execute a quantum device. Imported separability and
polynomial-bit theoretical results are listed in PROOF.txt; the implemented
pipeline is high-precision numerical quadrature plus exact final verification.

TESTED ENVIRONMENT
Python3.14.3; mpmath1.3.0; SymPy1.14.0; NumPy2.5.3; macOS arm64.
Run Python without -O/-OO: the module rejects modes disabling assertions.
All BLAS/thread environment variables are set to1 inside the programs.
No SciPy backend is assumed or installed. Only the scaling optimizer uses
NumPy. POSIX signal timers enforce the scaling CLI's hard generation deadline.

PORTABLE ARCHIVE
Unzip certified_gibbs_compilers.zip into an empty directory and run commands
from the extracted root. It includes the work-relative directory hierarchy,
all owned current source files, frozen historical evidence, and the explicitly
imported c01_s03 helper
at work/cycle6/c01_s03/axial_compiler/axial_acquisition.py. Source imports are
relative to the scripts' own paths; there are no hardcoded host import paths.
The imported helper's hash/attribution is recorded in SOURCES.json. Frozen
historical snapshots retain original provenance path strings; the current
runnable compiler imports use relative paths. Copies of the original scaling
receipts also live under frozen_scaling/ so replay-generated LP diagnostics
cannot replace the retained originals.
Install the listed packages into your own Python environment if needed:
 python3 -m pip install -r requirements.txt
No package installation was performed during this trial.

TESTED COMMANDS

Symmetric Dicke-Gaussian compiler: n<=64,0<=delta<=1,rational field.
 python3 work/cycle6/c03_s01/implementation/dicke_compiler.py --n 32 --delta 1 --h 1/3 --epsilon 1e-20 --samples 4 --output dicke.json

Small whole-Gibbs compiler: N1/2/3,0<=alpha<=16,delta<=1,|h|<=8,
accuracy1e-80<=epsilon<1. Uses the direct K0/KN two-sector formula.
 python3 work/cycle6/c03_s01/implementation/whole_gibbs_compiler.py --n 3 --alpha 3 --delta 1 --h 1/3 --epsilon 1e-12 --samples 4 --output whole_small.json

Frozen N<=16 filtered-column compiler:0<=alpha<=16,delta<=1,|h|<=2,
epsilon>=1e-12. Bounded exact simplex on a rounded filtered-sector table;
15s optimizer subprocess cap and30s compilation cap. Final cert independent.
 python3 work/cycle6/c03_s01/implementation/filtered_sector_compiler.py --n 16 --alpha 3 --delta 1 --h 1/3 --epsilon 1e-6 --output whole16.json

Scaling compiler: N<=64,0<=alpha<=16,delta<=1,|h|<=2,epsilon>=1e-12.
For N>16 its optimizer is bounded NumPy nonnegative least squares; acceptance
still uses exact posterior bounds. The current CLI has a HARD60s POSIX alarm
and a15s optimizer subprocess cap; it may return TIMEOUT or REJECTED on other
inputs/machines. A failure is not an output approximation certificate.
 python3 work/cycle6/c03_s01/implementation/filtered_sector_scaling.py --n 32 --alpha 3 --delta 1 --h 1/3 --epsilon 1e-8 --output whole32.json
 python3 work/cycle6/c03_s01/implementation/filtered_sector_scaling.py --n 64 --alpha 3 --delta 1 --h 1/3 --epsilon 1e-8 --output whole64.json

The successful N32/N64 receipts were produced before the timing-only CLI
repair. N64 compilation took50.562s, but a redundant immediate recheck brought
LP-input-to-final-export elapsed to at least68.46s, EXCEEDING the prospective
60s overall probe budget. This is preserved as SCALING_BUDGET_OVERRUN_04.json.
The exact state-accuracy certificate passed; this is NOT a successful60s
end-to-end benchmark. The current default omits that duplicate recheck and
enforces the hard cap. It has not been rerun at N64 just to improve timing.
Explicit verification of an already saved N64 model is separate charged work.
Use --recheck if you want a second full check during generation; it is charged
within the same deadline and can cause a timeout.

VERIFY A SAVED OUTPUT WITHOUT RECOMPILING
Add the implementation directory to sys.path in Python, load the JSON model,
then call dicke_compiler.verify_model, whole_gibbs_compiler.verify_whole_model,
filtered_sector_compiler.verify_filtered or filtered_sector_scaling.verify_filtered
for the corresponding format. Verification uses exact arithmetic and no
optimizer/eigensolver. The scaling model's format differs from the frozen
N<=16 model, so use the matching module. A caller verifies once after loading,
then may draw labels with sample_product/sample_whole_gibbs/sample_filtered.
Changing a verified model afterwards invalidates that verification.

QUANTUM OUTPUT CONTRACT
Trace distance is half trace norm. Each label gives exact rational PSD trace-one
local2x2 density matrices. Their tensor-product mixture has the stored total
target trace-distance upper bound. This implies at most that TV error for any
fixed common measurement. Displayed angles are floating diagnostics only.
The default label sampler uses a fixed finite fair-bit budget, including
quantified near-uniform phase/subset choices. Seeded examples use Python PRNG;
the exact sampling law assumes independent uniform bits. No physical apparatus
or amplitude-to-device conversion is included.

EVIDENCE
half_domain/MANIFEST.json preserves the original70-case delta<=1/2 receipt:
n2,3,8,15,16,31,32 ×delta0,.25,.5 ×h0,1/3,-2/5 plus n0/1/64 and field cases.
delta1_checks.json adds12 cases throughn64 and16 corrupted-model rejection
controls. n2,delta2,h0 has a strictly negative ordinary-moment determinant
and a Bell-population witness excluding separability.
finite_alpha_checks.json / finite_alpha_delta1_checks.json preserve24 N2/N3
whole-state cases with exact matrix certificates. whole_api_checks.json tests
the reusable direct small backend, JSON roundtrip,72 counted draws and3
corrupted models. filtered_first/MANIFEST.json freezes N8/N16 extension.
scaling_N32.json / scaling_N64.json contain the larger full-space outputs.
Each larger label is a product of N local matrices, without a dense2^N matrix.

Preserved rejections: FAILURE_01.json(trig-tail guard), SCHEMA_FAILURE_02.json
(independent phase-modulus verifier counterexample), SCALING_FAILURE_03.json
(first error-sum serialization rejection), SCALING_BUDGET_OVERRUN_04.json
(N64 total runtime cap miss), and scaling_N2_cli_timeout.json(hard-cap control).
The old INITIAL and phased-parity result are separate and unchanged.
The completed independent extension review checks all four larger posteriors
and745 actual block bridges; its owned sampler replay checks every positive
branch,38448 local PSD matrices and640 consumed fair bits per draw. Audit
receipts are included at their work-relative paths, as recorded in SOURCES.json.

No universal success/time guarantee is claimed for mpmath, SymPy simplex,
NumPy active-set fitting or these bounded prototypes. Theoretical polynomial-
bit rational Jacobi construction was not implemented. External specialist
validation, historical priority, backend token/energy accounting and quantum
hardware execution remain UNKNOWN or absent as recorded in RESULTS.json.

PORTABLE SMOKE CHECK
Four small CLIs were run from a clean extracted stage archive; all exact JSON
verifiers and20 local PSD checks passed. PORTABLE_REPLAY.json records source
hashes and commands; no N32/N64 probe was repeated. The final archive adds
only the freeze documentation/manifests to those same tested compiler sources.
To repeat this packaging check from a fresh extraction directory:
 python3 work/cycle6/c03_s01/implementation/portable_replay_check.py --archive certified_gibbs_compilers.zip --extract-root replay_check --receipt replay_check.json
