# A mode-count-independent classical reconstruction under a thermal information radius

Status: direct, complete Gaussian measure-and-prepare construction. The ingredients are established Gaussian-channel facts. This is a scoped consequence and a useful boundary to the unrestricted-displacement obstruction N53; historical novelty is not claimed. It does not settle bounded-Holevo-capacity sufficiency for arbitrary experiments.

## Interface

Let m be any positive finite integer. The Hilbert space is the m-mode bosonic Fock space. Let N_i>0 be supplied known thermal occupations, put

    theta_N = sum_{k>=0} N^k/(N+1)^(k+1) |k><k|,
    Theta = tensor_{i=1}^m theta_(N_i),
    rho_alpha = D(alpha) Theta D(alpha)^*,  alpha in A subset C^m.

The center and occupations are known to the reconstruction channel; the unknown displacement is not. Channels are normal CPTP maps on the entire trace class. Their outcomes may be continuous. Trace distance is T=||rho-sigma||_1/2; relative entropy uses natural logarithms.

Write beta_i=ln(1+1/N_i) and lambda_i=sqrt(N_i/(N_i+1)). Then there is one explicit entanglement-breaking channel Lambda, independent of alpha, with

    Lambda(rho_alpha)=rho_(lambda alpha),

where (lambda alpha)_i=lambda_i alpha_i. In particular Lambda(Theta)=Theta exactly, with no additive covariance or mode-count error.

Consequently

    e_EB(A) <= sup_{alpha in A}
                  sqrt[ (1/2) sum_i beta_i (1-lambda_i)^2 |alpha_i|^2 ].       (1)

If the supplied experiment has relative-entropy radius C about Theta,

    sup_{alpha in A} D(rho_alpha || Theta)
       = sup_{alpha in A} sum_i beta_i |alpha_i|^2 <= C,

then

    e_EB(A) <= min{1, sqrt(C/2) max_i(1-lambda_i)}.                            (2)

For a sequence with arbitrary growing mode counts, C_n bounded, and min_i N_(n,i)->infinity, this gives e_EB->0, independent of sum_i(N_i+1)^(-2). More generally (1) tends to zero whenever the weighted contracted displacement radius tends to zero, even without a common temperature floor.

## Exact construction

On each mode perform the coherent-state POVM d^2z |z><z|/pi, then prepare the coherent state |lambda_i z>. Take the tensor product of these one-mode channels. This is a normal measure-and-prepare CPTP channel on every input trace-class operator; it is not defined only on the promised displacement family.

On a displaced thermal input, the heterodyne outcome has circular complex Gaussian law

    z_i ~ CN(alpha_i, N_i+1),

independently across modes. Scaling by lambda_i gives a coherent-state mixing distribution with mean lambda_i alpha_i and variance

    lambda_i^2 (N_i+1) = N_i.

The positive coherent-state Gaussian mixture of variance N_i is precisely theta_(N_i), displaced by its mean. Thus the output thermal covariance equals the input covariance exactly. This proves the channel identity, including at the reference alpha=0.

The channel uses m simultaneous or sequential heterodyne measurements, continuous classical outcomes, and coherent-state preparation. Equation (2) bounds reconstruction error, not the number of retained classical bits. Finite precision/outcome quantization and finite energy cutoffs require separate approximation costs.

## Relative entropy calculation

For one mode log(theta_N)=-ln(N+1) I-beta a^dagger a. Displacement preserves von Neumann entropy and raises the mean occupation by |alpha|^2. Therefore

    D(D(alpha)theta_N D(alpha)^* || theta_N)=beta |alpha|^2.

Unitary displacement invariance and tensor additivity imply, for any alpha,gamma,

    D(rho_alpha || rho_gamma)=sum_i beta_i |alpha_i-gamma_i|^2.

Apply quantum Pinsker T(rho,sigma)<=sqrt(D(rho||sigma)/2) with gamma=lambda alpha to get (1). The inequality between weighted radii gives (2). No dimension-continuity estimate or compactness argument appears.

An alternative exact root-fidelity expression for these equal-covariance states is

    F(rho_alpha,rho_gamma)
      = exp[-(1/2) sum_i |alpha_i-gamma_i|^2/(2N_i+1)].

Fuchs-van de Graaf consequently gives another bound

    e_EB(A) <= sup_alpha sqrt[1-exp(-sum_i
                             (1-lambda_i)^2 |alpha_i|^2/(2N_i+1))].           (3)

Equations (1)-(2) do not rely on importing this fidelity formula. If occupations equal N, and R^2=sup sum_i |alpha_i|^2/(2N+1), then (3) gives e_EB<=sqrt(1-exp(-(1-lambda)^2 R^2))<= (1-lambda)R. Since 1-lambda=1/(2N)+O(N^-2), bounded R gives O(R/N) error uniformly in m.

## Why this changes the N53 boundary

The supplied N53 benchmark for unrestricted independent displacements has e_EB equal to the TV distance of the product geometric photon laws with means N_i and N_i+1, and its collective threshold is sum_i(N_i+1)^(-2). The present channel contracts the displacement and is therefore not admissible at small risk uniformly over all alpha in C^m: its displacement error is unbounded as the mean moves away from the supplied center. On a bounded information-energy radius, contraction bias is uniformly controlled and the covariance penalty disappears.

For a concrete separation, set equal N->infinity and m=N^3. The unrestricted benchmark has e_EB->1, since m/(N+1)^2->infinity. Yet every displacement family with sum_i |alpha_i|^2 ln(1+1/N)<=C has e_EB<=sqrt(C/2)/(2N)+O(N^-2)->0. This is an exact Gaussian statement; there is no iid/LAN transfer or growing-dimension sample threshold claimed.

## Relation to Holevo capacity and limits

For every prior supported on A, Donald's identity gives chi<=average_alpha D(rho_alpha||Theta)<=C. Thus the radius assumption implies bounded Holevo capacity. Its converse fails even for a two-element family: the Holevo capacity is at most ln 2 regardless of how far apart its two displacements lie, while its radius about a specified center can be arbitrarily large. Consequently (2) is not a proof that bounded Holevo capacity alone replaces trace covering in N46.

The reference state, occupations, and displacement coordinate system are supplied. No acquisition procedure is inferred. The temperature-floor condition is sufficient, not necessary; directions with zero displacement cause no error even if their temperatures stay finite. Pure occupations N_i=0 can be accommodated by lambda_i=0 and the direct coherent-state fidelity bound, but the faithful relative-entropy radius is infinite on any nonzero displacement in those modes, so they are excluded from (1)-(2).

## Primary sources and novelty boundary

1. A. S. Holevo, *Entanglement-breaking channels in infinite dimensions*, arXiv:0802.0235, https://arxiv.org/pdf/0802.0235 . Theorem 2 gives the Gaussian EB characterization; Section 6, case C, equation (36), states the one-mode attenuator/amplifier condition. Under covariance preservation it gives lambda^2<=N/(N+1), exactly the displayed coherent-prepare channel's maximal gain among phase-insensitive covariance-preserving Gaussian EB channels. The general Gaussian EB criterion and this one-mode gain bound are prior art.
2. M. Guta, P. Bowles, G. Adesso, *Quantum teleportation benchmarks for independent and identically-distributed spin states and displaced thermal states*, arXiv:1004.1843, https://arxiv.org/pdf/1004.1843 . Section IV, before Lemma IV.2 (PDF p.6), gives the thermal heterodyne law and coherent-state preparation. Theorem IV.1 is the unrestricted-displacement one-mode trace-norm benchmark. The present construction scales its outcome before preparation and controls the resulting bias on a radius-constrained family.
3. L. Banchi, S. L. Braunstein, S. Pirandola, *Quantum fidelity for arbitrary Gaussian states*, arXiv:1507.01941, https://arxiv.org/pdf/1507.01941 . Equations (8)-(9) provide the optional equal-covariance displacement fidelity used in (3).

The exact construction and proof above are independent of the supplied internal proof of N53. A bounded primary-source check verified the underlying mechanism, not historical priority of this particular bound. Treat it as a defensible scoped corollary and interface correction; the sharp dyadic receiver theorem is the stronger new deduction from this branch.
