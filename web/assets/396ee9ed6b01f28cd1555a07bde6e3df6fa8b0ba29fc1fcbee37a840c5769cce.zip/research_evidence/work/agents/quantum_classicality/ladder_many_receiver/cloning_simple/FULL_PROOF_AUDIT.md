# Independent audit of the consolidated many-receiver proof

Audited: `../PROOF.md`, including its strengthened uniform envelope, on 2026-10-07.

Verdict: no material error found. The lower bound follows for arbitrary correlated or entangled outputs by decoding one copy, restricting the input channel to each symmetric sector, and applying the universal cloning ceiling to the Haar and receiver averaged fidelity. The explicit rotation/permutation average correctly justifies that ceiling from Keyl–Werner's worst effect-test theorem. A bound on an arbitrary designated output alone would be false, but the proof consistently averages the outputs.

The geometric sum and threshold cardinality are correct for all integer K, including K=1, K equal to a power of two, and K greater than the largest copy count m. The improved envelope q >= alpha-1/L is valid: for 1<K<=2^L, u=ceil(log2 K)-log2 K lies in [0,1), and the convex secant bound 2^u<=1+u gives L(alpha-q)<=1. For K>=2^L the direct geometric formula gives the same bound.

The binary-tree upper bound follows by contractivity even though only the original ladder inputs have the one-step guarantee. Telescoping compares consecutive iterates through contractivity. Capping by the universal trace-distance bound 1 handles arbitrary tree depths.

The weighted exact (m+1)-design reproduces each sector's fidelity functional, which depends only on the moment of degree n_j+1. The faithful perturbation lower loss is 2 eta, independent of K, and the direct final-channel mixture upper loss is at most eta, also independent of K. Hence the threshold equivalence persists for eta_L->0.

The distance convention is consistently half the trace norm. The asymptotic necessity is correctly scoped to d_L/m_L->infinity; slowly growing or fixed d is not covered by the claimed threshold. No exact finite-L optimality or historical-priority claim is made.
