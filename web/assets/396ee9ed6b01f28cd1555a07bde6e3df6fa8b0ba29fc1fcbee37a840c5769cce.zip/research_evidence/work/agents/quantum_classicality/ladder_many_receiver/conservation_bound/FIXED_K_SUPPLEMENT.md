# Successful-copy conservation and a sharper fixed-receiver lower bound

This is an elementary supplement to `../PROOF.md`. It does not replace that
proof's lower bound, which is uniform in the receiver count. The present
dimension correction grows exponentially with K. Its useful consequence is
sharpness of the coefficient for each fixed dyadic receiver count.

Use the notation of the parent proof: n_j=2^j, m=2^(L-1),
H=direct_sum_j Sym^(n_j)(C^d), and
rho_psi=L^(-1) direct_sum_j P_psi^tensor n_j. All channels have their full
matrix-algebra domains; output coherences, correlations and entanglement are
allowed. Put

    D_n = binomial(d+n-1,n),
    fbar = (1/L) sum_(i=0)^(L-1) (n_i+1)/(d+n_i)
         <= (2m-1+L)/(Ld).

## 1. A Haar instrument bound

Let E be a completely positive, trace-nonincreasing map from Sym^n(C^d) to
(C^d)^tensor R. Let J_E be its unnormalized Choi matrix, using any fixed
orthonormal basis of Sym^n(C^d). Its average branch probability is

    p_E = integral Tr E(P_psi^tensor n) dmu(psi) = Tr J_E / D_n.

The Haar moment identity and the elementary pointwise inequality
P_barpsi^tensor n <= I_input give

    Omega_(n,R)
       := integral P_barpsi^tensor n tensor P_psi^tensor R dmu(psi)
       <= I_input tensor integral P_psi^tensor R dmu(psi)
       = I_input tensor Pi_sym^R / D_R
       <= I_input tensor I_output / D_R.

Consequently

    integral Tr[P_psi^tensor R E(P_psi^tensor n)] dmu(psi)
       = Tr[J_E Omega_(n,R)]
       <= Tr J_E / D_R
       = p_E D_n/D_R.                                      (A)

This is only a linear Choi pairing and the symmetric Haar moment; no
universal cloning optimality theorem is imported. An output supported on a
tensor product of separately symmetric groups can be included in the ordinary
R-fold tensor product before applying (A). Tracing out untested outputs
preserves both positivity and the Choi trace of the branch.

## 2. Conservation with arbitrary output flags

Let C:Sym^n(C^d)->H^tensor K be CPTP, where 1<=n<=m. Measure all K output
sector flags f=(j_1,...,j_K). This produces CP branches E_f with average
probabilities p_f summing to one. Within branch f, jointly measure the
commuting local two-outcome projectors P_psi^tensor n_(j_a). Let X_a be the
indicator of success and put

    Z = sum_(a=1)^K n_(j_a) X_a.

For a nonempty subset S of receivers, set R_(f,S)=sum_(a in S) n_(j_a).
Whenever R_(f,S)>n, (A) bounds the average joint-success probability in this
branch by

    p_f D_n/D_(R_(f,S)) <= p_f D_n/D_(n+1)
                        = p_f (n+1)/(d+n).

If Z>n, the set of successful receivers itself is such an overloaded subset.
A union bound over nonempty subsets and then a sum over flags therefore give

    Pr_Haar(Z>n) <= (2^K-1)(n+1)/(d+n).                    (B)

Since 0<=Z<=Km, this implies

    integral sum_(a,j) n_j Tr[Q_(a,j,psi) C(P_psi^tensor n)] dmu(psi)
       = E_Haar Z
       <= n + Km(2^K-1)(n+1)/(d+n),                       (C)

where Q_(a,j,psi) is the embedded correct-state projector for sector j at
receiver a. Thus the expected number of correctly retained physical copies
is at most the input number, with the stated finite-d correction. There is
no count of output flag configurations in this error term.

## 3. Dyadic knapsack lower bound

Fix a ladder broadcasting channel B with worst marginal trace error epsilon.
For each j let q_j be its correct sector-j score, averaged over Haar psi and
over the K receivers. Restrict B to each input sector, apply (C), and average
over the uniform input flag. This gives

    sum_j n_j q_j <= B_budget,
    B_budget := (2m-1)/(KL) + m(2^K-1) fbar.                (D)

Measuring the L mutually orthogonal correct-state projectors and their
complement gives target probabilities (1/L,...,1/L,0). Thus for each psi and
receiver its trace distance is at least

    1 - sum_j min(1/L, correct_score_j).

Average this inequality. Concavity of x->min(1/L,x) implies, with
x_j=min(1/L,q_j),

    sum_j x_j >= 1-epsilon,
    0<=x_j<=1/L,
    sum_j n_j x_j <= B_budget.                            (E)

For any threshold c>0,

    sum_j x_j
       <= B_budget/c + (1/L) sum_(j:n_j<c) (1-n_j/c),

because the coefficient 1-n_j/c is nonpositive above the threshold and
x_j<=1/L below it. Taking c=2^s, for 0<=s<=L-1, gives the explicit bound

    b_K(E_(L,d))
       >= [L-s+1-2^(-s)-(2m-1)/(K 2^s)]/L
          - [m/2^s](2^K-1) fbar.                         (F)

The maximum of these lower bounds and zero is valid. This is a relaxation
bound, not an assertion of exact finite-L optimality or of achievability for
nondyadic K.

## 4. Sharp fixed dyadic receiver count

For K=2^r with 1<=r<=L, choose s=L-r in (F). The result is

    b_K(E_(L,d))
       >= [r-(K-1)/(2m)]/L - (K/2)(2^K-1) fbar
       >= (1/L) [r-(K-1)/(2m)
                  -(K/2)(2^K-1)(2m-1+L)/d].              (G)

Together with the parent proof's r/L upper bound, (G) proves, for every
fixed K=2^r and every sequence L->infinity with d/m->infinity,

    L b_K(E_(L,d)) -> r.

The exponentially growing constant in (G) prevents a uniform growing-K
claim from this argument. The parent proof already supplies that stronger
uniform receiver-growth theorem by a different estimate.

For a general fixed K>=2, setting s=L-ceil(log_2 K) in (F) gives the limiting
lower coefficient

    liminf L b_K >= r+2-2^(r+1)/K,
    r=floor(log_2 K).

At powers of two this expression equals log_2 K. For other K it is a lower
bound only; its matching achievability has not been proved here.

## 5. Scope of variants

Adding a common faithful perturbation of trace size eta loses at most 2eta
in (F) and (G), by the same contractivity argument as in the parent proof.
To retain the fixed-K limit of L b_K, require L eta->0.

The parent proof's exact design of order m+1 does not automatically preserve
this supplement. The joint-success Haar functionals in (A) can have moment
order n+R up to (K+1)m. A finite exact design of order (K+1)m suffices for
all displayed instrument bounds. No efficient acquisition of that design
is claimed.

## Parent-proof audit

The lower-bound summation, unrestricted-output twirling reduction, uniform
envelope, and finite-design/faithful extensions in `../PROOF.md` were checked.
No issue was found. That proof's imported single-clone formula applies after
rotation and permutation twirling without an output symmetric-support
assumption; the present supplement avoids that ingredient for its narrower
fixed-K refinement.
