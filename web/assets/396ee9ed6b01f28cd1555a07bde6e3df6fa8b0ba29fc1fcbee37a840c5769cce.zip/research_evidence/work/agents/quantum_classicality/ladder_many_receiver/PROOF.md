# Sharp receiver-growth threshold for the dyadic copy ladder

Status: complete deduction from the established universal single-clone cloning theorem. This settles the growing-receiver question for the displayed experiment, up to a uniform additive `O(1/L + m/d)` error. It does not assert exact finite-L optimality of the binary splitting channel, or historical novelty of the consequence.

Distances are `T(rho,sigma)=||rho-sigma||_1/2`. For an experiment E on H and an integer K>=1 define

    b_K(E) = inf_(B CPTP H->H^tensor K) sup_(rho in E; a=1,...,K)
                 T(B_a(rho),rho).

All channels are defined on the entire input algebra. Correlated and entangled outputs are allowed.

Let L,d>=2, put n_j=2^j for j=0,...,L-1, m=2^(L-1), and

    H = direct_sum_j Sym^(n_j)(C^d),
    rho_psi = (1/L) direct_sum_j (|psi><psi|)^tensor n_j,
    E_(L,d) = {rho_psi : ||psi||=1}.

For K>=1 set

    t = min(L,ceil(log_2 K)),
    q_(L,K) = [t-(2^t-1)/K]/L,
    c_(L,d) = (d-1)/(d+m),
    alpha_(L,K) = min(log_2 K/L,1).

For K=1 these expressions use t=0 and q=alpha=0.

## Theorem

For every integer K>=1,

    b_K(E_(L,d))
       >= (1/L) sum_(j : 2^j<K) [(d-1)/(d+2^j)](1-2^j/K)
       >= c_(L,d) q_(L,K),                                      (1)

and the binary splitting construction gives

    b_K(E_(L,d)) <= min(ceil(log_2 K)/L,1).                       (2)

In particular, uniformly over all K>=1,

    alpha_(L,K) - 1/L - (m+1)/(d+m)
       <= b_K(E_(L,d)) <= min(alpha_(L,K)+1/L,1),                (3)

so

    |b_K(E_(L,d)) - min(log_2 K/L,1)|
       <= 1/L + (m+1)/(d+m).                                   (4)

Consequently, for any sequence L->infinity, d_L/m_L->infinity, and arbitrary positive integers K_L,

    b_(K_L)(E_(L,d_L)) = min(log_2 K_L/L,1)+o(1),

with the o(1) uniform in K_L. Thus

    b_(K_L)(E_(L,d_L))->0  iff  log K_L=o(L).

If log_2 K_L/L->gamma in [0,infinity], the optimal error tends to min(gamma,1). If log_2 K_L/L->infinity, it tends to 1. For the original choice d_L=L m_L, the uniform error in (4) is O(1/L).

## Proof of the cloning ingredient

For any CPTP map C:Sym^N(C^d)->(C^d)^tensor K, define its Haar-average and receiver-average single-copy score

    Fbar(C) = integral (1/K) sum_a <psi|C_a(psi^tensor N)|psi> dmu(psi).

When N<K, the universal-cloning theorem implies

    Fbar(C) <= F_(N,K,d)
       := N/K + [(K-N)/K](N+1)/(N+d)
        = 1 - [(d-1)/(N+d)](1-N/K).                            (5)

There is no support restriction on C's output. Here is the reduction needed to apply the cited worst-case theorem to this average score. Average C over common U(d) rotations of its input and all outputs, then average over output permutations. Both operations preserve Fbar(C). For the resulting channel, every output marginal on psi^tensor N is the same and, by the stabilizer of psi, has the form

    f |psi><psi| + [(1-f)/(d-1)](I-|psi><psi|),

where f is independent of psi and a and equals Fbar(C). Its trace distance from |psi><psi| is exactly 1-f. Keyl and Werner's Theorem 1 says this marginal trace distance is at least

    [(d-1)/d] [1 - N(K+d)/(K(N+d))]
      = [(d-1)/(N+d)](1-N/K).

This proves (5). For N>=K, use the trivial upper bound Fbar(C)<=1 (and exact deletion shows it is achievable).

## Proof of (1)

Define the CPTP decoder R:H->C^d by measuring the direct-sum sector and tracing out all but one ordinary tensor factor within the measured symmetric block. The canonical symmetric-subspace inclusion makes the decoder well-defined on every block. It satisfies

    R(rho_psi)=|psi><psi|.

Fix any broadcasting channel B with worst marginal error epsilon. Put

    A = R^tensor K composed with B : H->(C^d)^tensor K.

For all psi and all a, contractivity and the two-outcome projector test give

    epsilon >= T(B_a(rho_psi),rho_psi)
               >= T(A_a(rho_psi),|psi><psi|)
               >= 1-<psi|A_a(rho_psi)|psi>.

Let I_j embed sector j and put C_j(X)=A(I_j X I_j^*). This is a CPTP channel on Sym^(n_j)(C^d). Linearity on the supplied block diagonal states yields

    A(rho_psi) = (1/L) sum_j C_j(psi^tensor n_j).

After averaging over psi and receivers,

    1-epsilon <= (1/L) sum_j Fbar(C_j)
               <= (1/L) [sum_(j:n_j<K) F_(n_j,K,d)
                          + number{j:n_j>=K}].

Subtracting from 1 gives the first inequality of (1). Since n_j<=m and every summand is nonnegative, replace (d-1)/(d+n_j) by c_(L,d). The indices with 2^j<K are exactly j=0,...,t-1, and their geometric sum is 2^t-1. This gives the second inequality. Taking the infimum over B completes the lower bound.

## Upper bound and uniform envelope

Iterate the two-receiver splitting channel from the base copy-ladder proof along a depth-r binary tree, r=ceil(log_2 K), and discard surplus leaves. A marginal composition has error at most r/L by trace-distance contractivity and the known per-step error on rho_psi. Every trace distance is at most 1, so (2) follows. K=1 uses the identity channel.

To obtain a lower envelope valid for all K, first suppose 1<K<=2^L. Then t=ceil(log_2 K)<=L and u=t-log_2 K belongs to [0,1). Hence

    L(alpha-q) = 2^u-u-1/K <= 1,

using the convex-function secant bound 2^u<=1+u for 0<=u<=1. If K>=2^L, then t=L, alpha=1, and

    L(alpha-q)=(2^L-1)/K<=1.

K=1 is immediate. Therefore q>=alpha-1/L. Also 0<=q<=1, and

    c q >= q-(1-c) >= alpha-1/L-(m+1)/(d+m).

Together with ceil(log_2 K)<=log_2 K+1 this proves (3) and (4). In particular the bound explicitly covers the regime K>=m; there is no assumption that the receiver count is smaller than the largest copy number.

## Finite and faithful variants

The same finite exact moment design of order m+1 used in the base proof preserves this lower bound with no discretization loss. Indeed, each Haar-average fidelity term is a linear functional of the (n_j+1)-st moment of psi, and n_j+1<=m+1. The finite weighted design witness therefore reproduces every Fbar(C_j). It follows that the finite subexperiment has the first lower bound in (1), while (2) holds on every subset. No efficient design construction is claimed.

For the common faithful perturbation

    rho_tilde_psi=(1-eta)rho_psi+eta nu,  nu=I_H/dim(H),

any B obeys

    T(B_a(rho_psi),rho_psi)
       <= T(B_a(rho_tilde_psi),rho_tilde_psi)+2eta.

Thus the first lower bound in (1) loses at most 2eta. For the fixed K-receiver binary channel from (2), convexity directly gives

    T(B_a(rho_tilde_psi),rho_tilde_psi)
       <= (1-eta) min(ceil(log_2 K)/L,1)+eta.

This direct mixture estimate is uniform in K and avoids an accumulated r eta term. Therefore all stated receiver-growth limits persist for eta_L->0. Adding a finite net would instead lose the usual twice-the-net-radius term; the exact moment design avoids it.

## Primary source and scope

M. Keyl and R. F. Werner, *Optimal Cloning of Pure States, Judging Single Clones*, arXiv:quant-ph/9807010: https://arxiv.org/pdf/quant-ph/9807010 . Section II, p. 2 explicitly permits the full tensor-product output without an imposed symmetric-subspace restriction. Theorem 1 on p. 3 gives the optimal single-clone trace error; the displayed shrinking factor immediately before it yields (5). Section III.A, pp. 3-4 supplies the rotation and output-permutation symmetrization. The unrestricted-output aspect is needed here because the ladder broadcasting channel's decoded output can be arbitrarily correlated or entangled.

The contribution proved in this note is the application and summation over the supplied dyadic input flags. The universal cloning theorem itself is imported. A historical-priority review of the assembled ladder consequence has not been performed.

## Separate fixed-receiver refinement

The independently derived `conservation_bound/FIXED_K_SUPPLEMENT.md`, together with the matching channel verified in `NONDYADIC_ADDENDUM.md`, gives the stronger fixed-receiver law

    L b_K -> phi(K)=floor(log_2 K)+2-2^(floor(log_2 K)+1)/K

for every fixed integer K when d/m->infinity. At powers of two this equals log_2 K; in particular b_2=(1+o(1))/L. The successful-copy conservation estimate has an exponentially growing K-dependent dimension correction, so it is not used for the uniform growing-K theorem above. Its finite-design extension needs moments through (K+1)m, rather than merely m+1.
