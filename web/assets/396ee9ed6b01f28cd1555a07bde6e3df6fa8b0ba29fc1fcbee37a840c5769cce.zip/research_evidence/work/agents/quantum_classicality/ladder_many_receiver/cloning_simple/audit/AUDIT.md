# Independent audit verdict

**PASS**, for integer K >= 1 and normalized trace distance D(rho,sigma) = (1/2)||rho-sigma||_1. The sharp leading lower bound is valid. The receiver-average formulation is essential.

For an arbitrary broadcaster B, let C_j = R^{tensor K} B E_j, where E_j includes sector Sym^{N_j}(C^d), N_j=2^j. Each C_j is CPTP. Define

F_j = integral dpsi (1/K) sum_k tr[psi C_{j,k}(psi^{tensor N_j})].

Trace-distance contraction under R, followed by the test effect psi, gives delta(B) >= (1/L) sum_j (1-F_j). This does not require B to preserve sectors or to produce independent outputs.

## Cloning theorem

Unitary twirling and output-permutation averaging preserve F_j. The resulting channel has identical, covariant marginals, of the form F_j psi + (1-F_j)(I-psi)/(d-1). Its single-clone normalized trace error is exactly 1-F_j. Keyl-Werner Theorem 1 applies to the full output space (C^d)^{tensor K}, with symmetric input Sym^{N_j}(C^d); it does not require output support on the symmetric subspace. Therefore, for N_j<K,

1-F_j >= [(d-1)/(d+N_j)](1-N_j/K).

For N_j>=K use 1-F_j>=0. Summing proves the proposed lower bound.

Source: https://arxiv.org/html/quant-ph/9807010v1, Theorem 1 and Sections II--III.1.

**Caveat:** the displayed fidelity bound is false for an arbitrary individually designated clone of an asymmetric channel. Such a channel can preserve one actual input copy exactly. It applies to the site-averaged fidelity, or to every clone after output-permutation averaging. The max-marginal broadcast objective permits this repair.

**Convention:** the theorem's operational test error is half the standard trace norm. Using the full trace norm doubles both the quoted lower bound and the upper bound.

## Finite weighted design

An exact weighted complex projective (m+1)-design suffices. For each sector, tr[psi C_{j,k}(psi^{tensor N_j})] has degree (N_j+1,N_j+1) in the vector coordinates and their conjugates. Since N_j<=m, design moment equality reproduces its Haar average exactly. Equivalently, take lower moments by partial trace and apply partial transpose to the input factors in the Choi formula. This argument applies to arbitrary channels fixed before taking the parameter average, including channels optimized for the finite design.

A finite positive weighted design exists by Caratheodory: the Haar moment lies in the convex hull of psi^{tensor (m+1)} in the real affine space of trace-one Hermitian operators on Sym^{m+1}(C^d). At most dim(Sym^{m+1}(C^d))^2 atoms suffice; discard zero weights. No unitary-design assumption or equal-weight assumption is needed.

## Uniform asymptotic

t=min(L,ceil(log_2 K)) counts exactly the sectors with 2^j<K. Thus the geometric sum and q=(d-1)/(d+m) are correct. For d=Lm and m=2^{L-1}, 1-q=(m+1)/[(L+1)m]<=1/L because m>=L.

Together with the stated upper bound, this gives uniformly in K

min(log_2 K/L,1) - 2/L <= b_K <= min(log_2 K/L,1) + 1/L.

For the lower estimate when K<=2^L, write h=t-log_2 K in [0,1), use (2^t-1)/K <= 2^h and 2^h-h<=1. For K>2^L, use (2^L-1)/K<1. Hence the claimed uniform O(1/L) statement is justified with an absolute constant.

No unresolved mathematical gap found in this lower-bound route. This audit does not assert novelty or external validation.
