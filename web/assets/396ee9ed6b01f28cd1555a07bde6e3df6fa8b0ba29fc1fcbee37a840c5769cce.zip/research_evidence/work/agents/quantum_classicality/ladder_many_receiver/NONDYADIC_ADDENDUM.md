# Matching achievability for every fixed receiver count

Status: verified deduction. The channel construction was proposed by the parent quantum_classicality agent; this addendum checks its full-domain CPTP implementation, exact marginal flag laws and trace error, and combines it with the successful-copy conservation lower bound. Exact rational checks of all displayed finite-L flag formulas passed for L=2,...,10 and every integer 1<=K<=2^(L-1), 1022 cases. Those checks support only the algebra; the complete channel and asymptotic proof are below.

Use the definitions of `PROOF.md`: n_j=2^j, m=2^(L-1), H=direct_sum_(j=0)^(L-1) Sym^(n_j)(C^d), rho_psi=L^(-1) direct_sum_j P_psi^tensor n_j, and T=half the trace norm. Assume L,d>=2.

For an integer 1<=K<=m put

    r=floor(log_2 K),
    a=2^(r+1)-K,
    b=2K-2^(r+1),
    p=a/K,
    phi(K)=r+2-2^(r+1)/K=r+1-p.

Then a,b are nonnegative integers, a+b=K, 2a+b=2^(r+1), and 0<p<=1. In particular phi(1)=0 and phi(2^r)=r.

## 1. A full-domain K-receiver channel

Fix any state omega in the bottom sector C^d, embedded in H. Measure/dephase the input sector j. Define a trace-preserving channel on each measured block as follows, and finally average uniformly over all K! receiver permutations.

For a low block j<=r, n_j<=K. Include Sym^(n_j)(C^d) isometrically in (C^d)^tensor n_j, send its n_j factors to n_j bottom-sector receiver slots, and prepare omega in the other K-n_j bottom-sector slots. Thus before the final permutation this is an isometric inclusion followed by tensoring a fixed state. It is CPTP on every density matrix in the input block, even when that density matrix is not a pure tensor power. The final permutation distributes the n_j retained physical factors over a uniformly chosen size-n_j receiver subset.

For a high block j>=r+1, partition its 2^j ordinary tensor factors into a groups of size

    N_big=2^(j-r)

and b groups of size

    N_small=2^(j-r-1).

This uses exactly all factors, since

    a N_big+b N_small=(2a+b)2^(j-r-1)=2^j.

The canonical tensor grouping restricts to an isometry

    V_j:Sym^(2^j)(C^d)
       ->[Sym^(N_big)(C^d)]^tensor a
            tensor [Sym^(N_small)(C^d)]^tensor b.

Every totally symmetric tensor is separately symmetric in each chosen group, so the displayed codomain is valid for all input vectors. Both group sizes are dyadic and fit existing sectors of H. Send one group to each receiver. This block channel is the isometry V_j followed by output embeddings and permutation averaging, hence CPTP. On a supplied pure tensor power it produces the corresponding pure tensor power in every group exactly.

Writing these block channels as B_j, the full map is

    B(X)=sum_j B_j(P_j X P_j),

with the natural identifications of the input blocks. Every summand is completely positive, and

    Tr B(X)=sum_j Tr(P_j X P_j)=Tr X.

Thus B is CPTP on the entire input matrix algebra, including off-experiment and off-diagonal inputs. Its receiver marginals are identical by permutation averaging. Correlations between receivers are unrestricted.

## 2. Exact marginal laws when K<m

In this regime r<=L-2. Put ell_star=L-r-1>=1. A high input block j places a receiver in sector j-r with probability p=a/K and in sector j-r-1 with probability 1-p=b/K. Every such output carries the exact corresponding psi tensor power.

The marginal has the following correct pure-state weights:

    bottom sector 0:                 (2-1/K)/L,
    sectors ell=1,...,ell_star-1:    1/L each,
    boundary sector ell_star:       p/L,
    sectors ell=ell_star+1,...,L-1:  0.

Additionally there is bottom-sector replacement weight

    w=[r+1-2^(r+1)/K+1/K]/L.

Here is the complete flag arithmetic. The low input blocks j=0,...,r contribute

    sum_(j=0)^r 2^j/(KL)=(2^(r+1)-1)/(KL)

to the true bottom psi weight, and

    sum_(j=0)^r (1-2^j/K)/L=w

to omega. The high input block j=r+1 also contributes b/(KL) to the true bottom psi weight, yielding

    [(2^(r+1)-1)+b]/(KL)=(2-1/K)/L.

For every interior ell>=1, input j=ell+r contributes p/L and input j=ell+r+1 contributes (1-p)/L, summing to 1/L. At ell=ell_star only the first of these inputs exists. Higher output sectors do not occur. Empty interior sums, including when ell_star=1, are understood to be zero.

Subtract the target rho_psi. In the bottom block the difference is

    [(1-1/K)/L] P_psi+w omega,

which is positive semidefinite because both coefficients are nonnegative. Interior blocks have zero difference. The boundary block has the negative difference

    -[(1-p)/L] P_psi^tensor 2^ell_star,

and the r higher blocks each have negative difference -P_psi^tensor 2^ell/L. The positive and negative parts occupy orthogonal sectors. Their traces are both

    [r+1-p]/L=phi(K)/L.

Therefore the displayed channel has EXACT worst marginal trace error

    T(B_a(rho_psi),rho_psi)=phi(K)/L                        (1)

for every receiver a and every psi. This does not depend on overlaps between omega and psi. In particular it proves

    b_K(E_(L,d))<=phi(K)/L,  1<=K<m.                       (2)

## 3. The endpoint K=m

Now r=L-1, so all input sectors are low and no high branch exists. The marginal is supported entirely in the bottom sector, with true psi weight

    (2m-1)/(mL)=(2-1/K)/L

and replacement weight

    w=(L-2+1/K)/L.

The bottom difference from rho_psi is positive, with trace (L-1)/L. Every other target sector is missing, giving the same total negative trace. Therefore (1) also holds at K=m, because phi(m)=r=L-1. K=1 likewise gives phi(1)=0 and the supplied states are reproduced exactly.

Consequently (2) is valid for every 1<=K<=m.

## 4. Matching lower bound from successful-copy conservation

The audited supplement `conservation_bound/FIXED_K_SUPPLEMENT.md`, equation (F), establishes for every threshold s=0,...,L-1

    b_K>= [L-s+1-2^(-s)-(2m-1)/(K 2^s)]/L
             -(m/2^s)(2^K-1) fbar,
    fbar=(1/L)sum_(j=0)^(L-1)(2^j+1)/(d+2^j)
         <=(2m-1+L)/(Ld).

For 1<=K<=m choose s=L-r-1, so 2^s=m/2^r. Direct substitution gives

    b_K >= phi(K)/L
             -[(2^r/m)(1-1/K)]/L
             -2^r(2^K-1) fbar.                          (3)

Combining with the new upper bound yields the fully explicit bracket

    phi(K)-[2^r/m](1-1/K)
       -2^r(2^K-1)(2m-1+L)/d
       <= L b_K(E_(L,d)) <= phi(K).                       (4)

The lower bound may be replaced by zero when its displayed expression is negative. The exponentially growing K dependence limits (4) to the regime where its finite-d correction is small. The original main proof remains the stronger uniform growing-K statement.

For each FIXED integer K>=1, let L->infinity with d_L/m_L->infinity. Then eventually K<=m_L, both lower error terms in (4) vanish, and

    L b_K(E_(L,d_L)) -> phi(K)
       =floor(log_2 K)+2-2^(floor(log_2 K)+1)/K.            (5)

This proves the matching fixed-receiver law for nondyadic K as well as powers of two. Examples: phi(1)=0, phi(2)=1, phi(3)=5/3, phi(4)=2, phi(5)=12/5, phi(6)=8/3, and phi(8)=3. No exact finite-L optimality is asserted; the exact equality is for the error of the displayed channel, and (5) is the optimal asymptotic coefficient.

## 5. Finite faithful versions and evidence limits

The upper construction works on every subset of the experiment. The successful-copy lower bound uses joint moments through order (K+1)m; a finite weighted exact design of that order suffices for (3)-(5). The main theorem's lower bound still needs only order m+1 and is uniform in K.

For each fixed K, a common faithful perturbation of trace size eta_L with L eta_L->0 retains (5): the lower error changes by at most 2 eta_L, and applying the constructed final channel directly gives upper error at most

    (1-eta_L)phi(K)/L+eta_L.

If one wants a SINGLE finite faithful sequence retaining (5) for every fixed K simultaneously, choose exact designs of order (L+1)m. For each fixed K this is eventually at least (K+1)m, and it also preserves the main theorem's m+1 moments for arbitrary growing receiver counts. This is a finite existence statement and makes no claim of efficient design acquisition, modest cardinality, or channel computation cost.

The construction uses only tensor-factor grouping, deletion and replacement channels. The lower bound imports the elementary Haar moment/copy-conservation argument already proved in the cited local supplement. Historical novelty or priority has not been assessed.
