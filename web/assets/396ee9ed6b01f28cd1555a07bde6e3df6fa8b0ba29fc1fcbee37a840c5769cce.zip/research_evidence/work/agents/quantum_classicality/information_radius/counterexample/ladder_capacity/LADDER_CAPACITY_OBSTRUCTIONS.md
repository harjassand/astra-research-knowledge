# Bounded-capacity modifications of the dyadic copy ladder

Status: internal derivation, not externally reviewed. No bounded-Holevo counterexample was obtained. The statements below exclude several direct modifications of the known ladder. Logs are natural and trace distance is one half of trace norm.

## 1. Weighted full-Haar ladder: the shift error forces capacity divergence

Let

    rho_psi = direct_sum_j p_j |psi><psi|^(tensor 2^j),
    R_j = binom(d + 2^j - 1, 2^j),
    C = sum_j p_j log R_j.

For the entire pure-state parameter space in C^d, C is exactly the Holevo capacity: each input has entropy H(p), every ensemble average has entropy at most H(p)+sum p_j log R_j, and the Haar prior reaches this maximum.

For d >= 2, R_j >= 2^j+1 and R_j >= d, so

    C >= log d,       C >= (log 2) E[j].

Write the zero-extended one-step shift variation as

    delta = 1/2 [p_0 + p_(L-1) + sum_(j=0)^(L-2) |p_j-p_(j+1)|].

Then max p_j <= delta. Filling the earliest indices up to the cap delta minimizes E[j], and gives

    E[j] >= 1/(2 delta) - 1/2.

Thus

    C >= (log 2) [1/(2 delta) - 1/2].

For the split-and-shift broadcaster, replace the bottom block by the maximally mixed state in the top block. Its actual marginal trace error is

    b_shift = delta - min{p_0/R_(L-1), p_(L-1)}.

The term subtracted is the overlap of the replacement with the target top-block pure state. Since p_0 <= delta and R_(L-1) >= d,

    b_shift >= (1-1/d) delta >= delta/2,
    C >= (log 2) [1/(4 b_shift) - 1/2].

Therefore arbitrary reweighting cannot keep capacity bounded while this specified broadcaster has error tending to zero. This statement concerns the recipe, not an arbitrary optimized broadcaster.

The familiar first-copy witness satisfies

    sum p_j (d-1)/(2^j+d) <= delta [log_2 d + 2].

This bounds that lower-bound witness; it is not an upper bound on reconstruction of the complete ladder.

### 1b. The full weighted ladder also excludes every optimized broadcaster

This strengthening uses the already checked two-state broadcasting-to-gap bound from `R/work/agents/broadcast_quantitative/EXPLICIT_PAIR_BOUND.md`, rather than an infinite-dimensional compactness argument.

Choose psi=e_1 and phi=(e_1+e_2)/sqrt(2), and t=1/sqrt(2). Their intrinsic gap is

    Delta = sum_j p_j [t^(2^j) - t^(2^(j+1))].

If C<=K, set J=floor(2K/log 2). Markov's inequality gives sum_(j<=J) p_j > 1/2. Therefore

    Delta >= g_K := 1/2 min_(0<=j<=J) [t^(2^j)-t^(2^(j+1))] > 0.

The existing pair bound says for every integer ell>=0,

    Delta <= 2 sqrt(2 [ell b_2 + sqrt(log 2/(2*2^ell))]).

Hence optimized b_2 cannot tend to zero while K remains bounded. Explicitly, with

    ell_K = ceil(log_2 [128 log 2 / g_K^4]),

one gets

    b_2 >= g_K^2 / (16 ell_K) > 0.

For feasible d>=2, K>=log 2 and J>=2; the minimum defining g_K is attained at j=J. The numerical bound is extremely small but dimension uniform. This argument needs the full pure parameter family to contain the chosen pair; arbitrary restrictions are handled separately below.

## 2. Fixed-state noise dilution cannot preserve an obstruction

For any experiment E={rho_x}, fixed density operator tau, and 0 <= alpha <= 1, put

    rho'_x = alpha rho_x + (1-alpha) tau.

For every prior on X, introduce an independent binary flag Z identifying which component was used. Then

    I(X:BZ) = alpha I(X:B)_original,
    I(X:BZ) - I(X:B) = I(X:Z|B) <= h(alpha).

Consequently the capacities satisfy

    C(E') >= alpha C(E) - h(alpha).

The constant preparation channel tau has worst trace error at most alpha, so e_EB(E') <= alpha. If C(E) diverges and C(E') remains bounded, alpha must tend to zero, and the EB obstruction vanishes. The argument permits arbitrary fixed tau, not only maximally mixed noise.

## 3. Sector-dependent noise on the full-Haar ladder also collapses

Consider

    rho_psi = direct_sum_j p_j [alpha_j psi^(tensor 2^j) + (1-alpha_j) tau_j],

where each tau_j is parameter independent. The Haar prior and the preceding binary-flag argument give

    C >= sum p_j alpha_j log R_j - sum p_j h(alpha_j)
      >= (log 2) sum p_j alpha_j j - log 2.

If C <= K, then sum p_j alpha_j j <= A := (K+log 2)/(log 2). A constant channel preparing tau_bar = direct_sum p_j tau_j has error at most s = sum p_j alpha_j. For any integer J >= 1,

    s <= sum_(j<J) p_j + A/J.

For the uniform ladder, s <= J/L + A/J, hence s <= 2 sqrt(A/L)+O(1/L). For a profile with max p_j <= delta, s <= J delta + A/J, hence s = O(sqrt(A delta)). Thus bounded capacity and spreading ladder mass force a vanishing distance from one fixed state. This excludes this entire class of sector-dependent dilutions, regardless of the noise spectra.

## 4. Arbitrary parameter restrictions of the uniform pure ladder

This is the more robust obstruction. Let S_L be any set of unit vectors in C^(d_L); its size, geometry and dimension may vary with L. Define

    rho_psi = (1/L) direct_sum_(j=0)^(L-1) psi^(tensor 2^j),   psi in S_L.

If the Holevo capacities of these experiments are bounded by K, then their worst-case EB reconstruction errors tend to zero. The proof gives an explicit EB channel, without assuming a covering-number bound for the original parameter set.

### 4a. Every level below the top fraction has bounded pure-state capacity

Let C_j be the Holevo capacity of the pure family {psi^(tensor 2^j): psi in S_L}. For any prior, its Holevo information is nondecreasing in j by partial trace. Choosing a prior approaching C_j gives

    C(ladder) >= [(L-j)/L] C_j.

Therefore for j <= (1-eta)L,

    C_j <= K/eta.

### 4b. A pure family of capacity K_0 has a uniformly small effective subspace

For a pure family in finite dimension, choose sigma maximizing entropy over the closed convex hull of the family. Its entropy is the pure-family Holevo capacity. Its support contains every promised vector: otherwise mixing in such a vector with weight s gives a positive s log(1/s) entropy gain, contradicting maximality. On that support sigma is strictly positive. The directional derivative of entropy toward each member |v><v| is therefore finite and equals <v|-log sigma|v>-S(sigma). Maximality gives

    <v| -log sigma |v> <= S(sigma) <= K_0.

For any 0<a<1, let Q be the spectral projection of sigma for eigenvalues at least exp(-K_0/a). Then

    rank Q <= exp(K_0/a),    <v|(I-Q)|v> <= a.

This follows from Markov's inequality for -log sigma. It is a uniform pure-state energy truncation. It does not claim the corresponding statement for arbitrary mixed families.

### 4c. Enough independent copies permit uniform EB estimation

Given k copies of |v>, measure Q on each. The number M of successful projections is binomial(k,p), p=<v|Q|v> >= 1-a. Each successful state is the same pure |u>=Qv/sqrt(p), in D=rank Q dimensions. Universal covariant pure-state estimation from M copies has mean fidelity (M+1)/(M+D). The triangle inequality and Jensen's inequality give

    expected trace distance to |v><v|
       <= sqrt(a) + sqrt(E[(D-1)/(M+D)])
       <= sqrt(a) + sqrt(D/[(k+1)(1-a)]).

The last step uses (D-1)/(M+D) <= D/(M+1) and

    E[1/(M+1)] = [1-(1-p)^(k+1)]/[(k+1)p].

This formula includes M=0; prepare a Haar-random state in Q then. The whole map is measure and prepare.

The covariant fidelity identity can be verified directly: the POVM density on M copies is dim Sym^M(C^D) |u><u|^tensor M du. Integrating one additional squared overlap gives dim Sym^M / dim Sym^(M+1) = (M+1)/(M+D).

### 4d. Apply estimation after shifting down enough levels

Fix 0<eta<1 and estimation tolerance 0<epsilon<1. Let J=floor((1-eta)L). For every output level j<=J, choose the effective subspace above with K_0=K/eta and a=epsilon^2/4. Choose k=2^r so that

    k+1 >= 4 exp[4K/(eta epsilon^2)] / [(1-epsilon^2/4) epsilon^2].

For example it suffices to take the explicit integer

    r = ceil([4K/(eta epsilon^2)
              + log(4/[(1-epsilon^2/4) epsilon^2])]/log 2).

Then the EB estimator in 4c has error at most epsilon, uniformly over the parameters and over all j<=J. Input level j+r contains exactly k independent copies of the pure output state psi^(tensor 2^j): regroup the 2^(j+r) underlying copies into k groups of 2^j. The natural inclusion of the symmetric input subspace into these grouped tensor factors is an isometry. Its measurement can therefore prepare an approximation in output block j.

For sufficiently large L, J+r < L. Map each input block j+r, 0<=j<=J, to output block j by this estimator. Map the remaining input blocks bijectively to the remaining output blocks and prepare arbitrary fixed states there. This preserves the uniform output flag distribution exactly. The total error is at most

    e_EB <= epsilon + (L-J-1)/L <= epsilon + eta.

The exact sufficient condition is eta L > r. Since eta and epsilon can be arbitrarily small and r is independent of L for fixed K,eta,epsilon, e_EB tends to zero. With eta and epsilon of the same order and r=O(K/(eta epsilon^2)+log(1/epsilon)), this yields a bound of order ((K+1)/L)^(1/4), up to an absolute constant and small-L clipping.

Hence restricting to subspaces, finite designs, thin parameter sets, or coalescing pure vectors cannot salvage the uniform pure-copy ladder under a capacity bound. This proof is uniform in the ambient dimension and parameter-set cardinality.

This is an existence and information-theoretic construction. Acquiring the entropy-maximizing centers, their spectral subspaces and their covariant POVMs is not asserted efficient. All k copies used by an estimator are physically contained in the supplied input sector; there is no free copying oracle or extra specimen acquisition. Covariant integrations may be replaced by finite exact moment designs in the relevant finite dimension when a finite-outcome formulation is desired.

### 4e. Weighted restricted pure ladders with small shift variation

The same proof handles an arbitrary pure parameter restriction with arbitrary weights when the zero-extended variation delta from section 1 tends to zero. Write T_j=sum_(i>=j) p_i. Monotonicity now gives C_j <= K/T_j. For fixed eta>0, choose J=max{j:T_j>=eta}; then every j<=J has pure capacity at most K/eta, while sum_(j>J) p_j < eta.

Use the same r-level estimator as in 4d. On an input block i>=r, map to output j=i-r, estimate if j<=J, and prepare an arbitrary state otherwise. On the bottom r input blocks prepare an arbitrary state in the top output block. Let q be this output flag law. If delta_r is the zero-extended r-step shift variation, then

    TV(p,q) <= delta_r <= r delta.

The first inequality is contraction under assigning the negative-index mass of the shifted distribution to the top block. The bottom r mass is at most r max p_j <= r delta. The mass of other unestimated inputs is at most sum_(i>J) p_i < eta. Comparing first to the ideal pure ladder with flag law q and then to the target flag law p gives

    e_EB <= epsilon + eta + 2 r delta.

Here r depends only on K,eta,epsilon. Thus uniformly bounded capacity and delta->0 imply vanishing EB error for every weighted restricted pure copy ladder using this shift mechanism. The exact uniform-flag routing in 4d gives its slightly sharper bound.

## Scope and remaining gap

These arguments do not establish that bounded Holevo capacity alone suffices for every arbitrary mixed-state experiment with small two-marginal broadcasting error. In particular, mixtures of restricted pure ladders with arbitrary coherent, level-dependent noise need additional compatibility analysis unless they fit section 2 or 3. The known full-Haar ladder, all its reweightings (even with optimized broadcasters), full-Haar sector noise, arbitrary pure parameter restrictions of the uniform ladder, and weighted pure restrictions with vanishing shift variation do not supply the requested counterexample.
