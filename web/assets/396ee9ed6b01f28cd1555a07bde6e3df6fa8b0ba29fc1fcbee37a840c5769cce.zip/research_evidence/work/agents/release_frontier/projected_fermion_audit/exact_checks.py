"""Exact diagnostic fixtures; these do not validate the imported FPRAS proof."""
from itertools import combinations
from fractions import Fraction
import json
import sympy as sp


def sign(S):
    return (-1) ** sum(i - k for k, i in enumerate(sorted(S)))


def wedge_multiply(state, orbital):
    out = {}
    for modes, coefficient in state.items():
        for mode, entry in enumerate(orbital):
            if not entry or mode in modes:
                continue
            inversions = sum(existing > mode for existing in modes)
            key = tuple(sorted((*modes, mode)))
            out[key] = sp.expand(out.get(key, 0) + coefficient * entry * (-1) ** inversions)
    return out


fixtures = {}
# Orbitals use the site-ordered mode convention: up=2*i, down=2*i+1.
n, r = 4, 2
U = sp.Matrix([[1, 2], [2, -1], [1 + sp.I, 1], [3, sp.I]])
V = sp.Matrix([[2, 1], [1, sp.I], [1 - sp.I, 2], [-1, 1]])
wedge = {(): sp.Integer(1)}
for k in range(r):
    wedge = wedge_multiply(wedge, [U[i // 2, k] if i % 2 == 0 else 0 for i in range(2 * n)])
for k in range(n - r):
    wedge = wedge_multiply(wedge, [V[i // 2, k] if i % 2 else 0 for i in range(2 * n)])
checked = 0
Z = 0
for St in combinations(range(n), r):
    S = set(St)
    Sc = sorted(set(range(n)) - S)
    amplitude = sign(S) * U[list(St), :].det() * V[Sc, :].det()
    modes = tuple(2 * i if i in S else 2 * i + 1 for i in range(n))
    assert sp.simplify(wedge.get(modes, 0) - amplitude) == 0
    Z += sp.expand(amplitude * sp.conjugate(amplitude))
    checked += 1
x = sp.symbols('x0:4', real=True)
fU = sp.expand((U.conjugate().T * sp.diag(*x) * U).det())
fV = sp.expand((V.conjugate().T * sp.diag(*x) * V).det())
coefficient = sp.Poly(sp.expand(fU * fV), *x).coeff_monomial(sp.prod(x))
assert coefficient == Z
fixtures['fermion_sign_and_norm'] = {'configurations_checked': checked, 'exact_Z': str(Z)}

# Full rank in each sector does not guarantee a nonzero projection.
Uzero = sp.Matrix([1, 0])
Vzero = sp.Matrix([1, 0])
Zzero = sum(abs(Uzero[i]) ** 2 * abs(Vzero[1 - i]) ** 2 for i in range(2))
assert Uzero.rank() == Vzero.rank() == 1 and Zzero == 0
fixtures['zero_projection'] = {'U': ['1', '0'], 'V': ['1', '0'], 'Z': '0'}

# Small TV perturbation makes the unbounded local-estimator mean arbitrarily wrong.
eta, tau = Fraction(1, 1000), Fraction(1, 100)
p = [eta ** 2 / (1 + eta ** 2), 1 / (1 + eta ** 2)]
q = [p[0] + tau, p[1] - tau]
local = [1 / eta, eta]  # a=(eta,-1), O=-X, operator norm one.
target = sum(pi * ei for pi, ei in zip(p, local))
wrong = sum(qi * ei for qi, ei in zip(q, local))
second_moment = sum(pi * ei ** 2 for pi, ei in zip(p, local))
assert second_moment == 1
fixtures['TV_does_not_control_unclipped_mean'] = {
    'eta': str(eta), 'TV': str(tau), 'exact_target': str(target),
    'perturbed_mean': str(wrong), 'bias': str(wrong - target), 'p_second_moment': '1'
}

# Identical occupation laws can encode orthogonal pure states.
a_minus, a_plus = sp.Matrix([1, -1]), sp.Matrix([-1, -1])
assert (a_minus.conjugate().T * a_plus)[0] == 0
fixtures['sampling_loses_phase'] = {
    'U': ['1', '1'], 'V_minus_state': ['1', '1'], 'V_plus_state': ['1', '-1'],
    'occupation_laws': ['1/2', '1/2'], 'unnormalized_overlap': '0'
}

# A generic spin-mixed Slater determinant: partition-matroid coefficient identity.
A = sp.Matrix([[1, 1 + sp.I], [2, 1], [sp.I, 2], [1, -1]])
y = sp.symbols('y0:4', real=True)
fA = sp.expand((A.conjugate().T * sp.diag(*y) * A).det())
partition = (y[0] + y[1]) * (y[2] + y[3])
matroid_coefficient = sp.Poly(sp.expand(fA * partition), *y).coeff_monomial(sp.prod(y))
projected_norm = sum(sp.expand(A[[i, j], :].det() * sp.conjugate(A[[i, j], :].det()))
                     for i in [0, 1] for j in [2, 3])
assert matroid_coefficient == projected_norm
fixtures['spin_mixed_partition_identity'] = {'exact_Z': str(projected_norm)}

# Arbitrarily rare successful Gutzwiller projection with integer orbitals.
projection_examples = []
for m in range(1, 5):
    B = sp.zeros(2 * m, m)
    for j in range(m):
        B[2 * j, j] = B[2 * j + 1, j] = 1
    norm = sum(abs(B[list(S), :].det()) ** 2 *
               abs(B[sorted(set(range(2 * m)) - set(S)), :].det()) ** 2
               for S in combinations(range(2 * m), m))
    unprojected_norm = (B.T * B).det() ** 2
    assert norm / unprojected_norm == sp.Rational(1, 2 ** m)
    projection_examples.append({'n': 2 * m, 'Z': str(norm), 'success': str(norm / unprojected_norm)})
fixtures['exponentially_rare_projection'] = projection_examples

print(json.dumps(fixtures, indent=2))
