# Independent audit: sharp excited-dimension bound

Audited `SHARP DIMENSION BOUND FOR HARD ENTANGLEMENT GAIN` and `SHARPNESS OF THE DIMENSION BOUND` in `work/agents/hard_energy/REPORT.txt`.

Verdict: both proofs are sound under the stated finite-dimensional full-rank pure-null contract. No load-bearing gap found. The equality value `m` is a supremum for `m>1`, not an attained maximum at a nontrivial fixed model.

## Stronger bound by the number of distinct positive energy levels

The later sharpening is also sound. Let `k` be the number of distinct positive levels, with blocks `H_j=h_j I`. For the prefix ending at level `h_j`, the preceding triangular argument gives

`A_prefix≤||B_prefix||² I≤exp(eta h_j)I`.

Hence its diagonal energy block obeys `K_jj=A_jj-I≤(exp(eta h_j)-1)I`. Positive semidefinite block pinching gives

`K≤k ⊕_j K_jj≤k(exp(eta H_+)-I)≤exp(k eta H_+)-I`.

For completeness, the pinching inequality follows by writing a PSD matrix as `K=V†V`, decomposing the input into `k` block components, and applying `||Σ_j V x_j||²≤k Σ_j||V x_j||²`.

Thus the stronger bound is

`1≤s_H/eta_H≤min{k,kappa(H_+)}`.

For `k>1`, `eta>0`, and every positive `h_j`, the scalar difference `exp(k eta h_j)-1-k(exp(eta h_j)-1)` is strictly positive. Therefore the upper ratio is strictly less than `k` for each nontrivial fixed model. If `k=1`, `H_+=hI`, then both the hard and separable exponents equal `[-log lambda_min(E_+)]/h`, so the ratio is exactly one.

The supremum `k` is sharp for any prescribed positive level degeneracies: choose one unit vector from each level and apply the earlier `k`-dimensional rank-one family on their span; set `E=I` on its orthogonal complement. The extra directions add only identity blocks and do not alter any cutoff minimum or threshold.

## Upper bound

Write the energy-ordered upper Cholesky factor as `E_+=T†T`, its inverse as `B`, and `A=B†B`. Since `T†T≤I`, all singular values of `T` are at most one, hence `TT†≤I` and `A=(TT†)^-1≥I`.

For any leading `i×i` compression, upper triangularity gives exactly

`E_i=T_i†T_i`, `B_i=T_i^-1`, `A_i=B_i†B_i`.

In particular, `A_ii≤||B_i||²=1/lambda_min(E_i)`. If `h_i` is degenerate, `E_i` may be a proper compression of `E_{h_i}`; min-max gives `lambda_min(E_i)≥lambda_min(E_{h_i})`, the direction needed. Thus

`A_ii≤1/lambda_min(E_{h_i})≤exp(eta_H h_i)`.

For `eta=eta_H>0`, put `K=A-I≥0`, `D=exp(m eta H_+)-I>0`. Then

`||D^-1/2 K D^-1/2||≤Tr(D^-1/2 K D^-1/2)`

` =Σ_i K_ii/(exp(m eta h_i)-1)`

` ≤Σ_i (exp(eta h_i)-1)/(exp(m eta h_i)-1)`

` ≤m(1/m)=1`.

The last step is the geometric-sum identity `exp(mx)-1=(exp(x)-1)Σ_{ell=0}^{m-1}exp(ell x)`, whose sum is at least `m`. Therefore `K≤D`, i.e. `A≤exp(m eta H_+)`, proving `s_H≤m eta_H`.

For `m>1` and every `h_i>0`, `x_i=eta h_i>0`, so each geometric sum is strictly greater than `m`. The trace is then strictly less than one, giving `exp(m eta H_+)-A>0`; continuity of the threshold implies

`s_H<m eta_H`.

For `m=1`, all effects commute with energy and the ratio is exactly one. If `eta_H=0`, contraction and the full cutoff force `E=I`, so the ratio is undefined; the source correctly assumes `eta_H>0`.

The other upper bound follows from the already established scalar Jensen bound:

`s_H≤alpha≤||-log E_+||/h_min`,

and the allowed full separable cutoff gives `eta_H≥||-log E_+||/h_max`. Thus `s_H/eta_H≤kappa(H_+)`. The lower bound one follows because arbitrary probes include separable probes.

## Sharpness family

Set `h_j=R^(j-1)`, `h_0=0`, and `v_j²=(h_j-h_{j-1})/h_m`. Telescoping gives `||v||²=1`. For `c_tau=1-exp(-tau)`,

`E_+=I-c_tau vv†`.

The leading cutoff at `h_j` is `I_j-c_tau v_[j]v_[j]†`, with squared vector norm `h_j/h_m`; its minimum eigenvalue is exactly

`1-c_tau h_j/h_m`.

The function `x↦[-log(1-c_tau x)]/x` is increasing on `(0,1]`, for example from its positive power series `Σ_{k≥1} c_tau^k x^(k-1)/k`. Hence the full cutoff is maximizing and

`eta_H=tau/h_m` exactly.

For fixed `R,m`, expand `E(tau)=I-tau V+O(tau²)`, `V=vv†`. The upper Cholesky factor is analytic near identity and has `T(tau)=I+tau U+O(tau²)`, where `U+U†=-V`. Consequently

`TT†=I-tau V+O(tau²)`, `A(tau)=I+tau V+O(tau²)`.

For fixed `t`,

`exp(t tau H_+)-A(tau)=tau(tH_+-V)+O(tau²)`.

If `t>lambda=lambda_max(H_+^-1/2 V H_+^-1/2)`, the first-order matrix is positive definite; if `0≤t<lambda`, it has a negative direction. These strict signs persist for all sufficiently small positive `tau`, proving `s_H(tau)/tau→lambda`. Rank one gives

`lambda=Σ_j v_j²/h_j=[m-(m-1)/R]/h_m`.

Therefore

`lim_{tau↓0}s_H/eta_H=m-(m-1)/R`.

Taking `R→∞` afterward establishes that the supremum at fixed input dimension `d=m+1` is `m=d-1`. For any prescribed error below `m`, choose `R` first and then sufficiently small `tau`; no interchange of limits is required. Meanwhile the effect eigenvalue ratio is `exp(tau)→1`, so sharpness needs no diverging effect dynamic range. Its energy condition number is `R^(m-1)`, consistent with the separate fixed-condition-number bound.

## Numerical corroboration

Using direct Cholesky and eigenvalue bisection, ratios at `tau=.001` were:

| m | R | ratio | small-tau limit |
|---|---|---|---|
| 2 | 10 | 1.8991904392 | 1.9 |
| 3 | 10 | 2.7983001205 | 2.8 |
| 4 | 10 | 3.6974018365 | 3.7 |
| 3 | 100 | 2.9780314577 | 2.98 |

The algebraic proof above establishes the result; these finite checks only corroborate it. Publication priority remains unverified.
