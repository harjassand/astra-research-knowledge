# Independent audit of the fixed-use / fixed-budget curve

Audited source: `work/root/triangular_tensor_tradeoff.txt`.

Verdict: the formula and proof are sound under the source's finite-dimensional assumptions. No load-bearing gap was found. One wording error should be corrected: upper energy-ordered triangular factors preserve cumulative lower-energy spectral subspaces, not each individual eigenspace/spectral subspace of `H`. The latter statement is false for a noncommuting example, but the proof uses only the correct cumulative invariance.

Let `C_s=e^{-sH/2} A e^{-sH/2}`, `phi(s)=log||C_s||`, and

`F_n(c)=log||B^⊗n P_{n,c}||²`, `P_{n,c}=1_[0,nc](H^(n))`.

Then for every fixed `c≥0`,

`g(c)=lim_n F_n(c)/n=inf_{s≥0}[phi(s)+s c]`.

For each fixed `c>0`, the stronger estimate holds:

`n g(c)-O(log n)≤F_n(c)≤n g(c)`.

At `c=0`, `F_n(0)=g(0)=0` exactly.

## Convexity and the dual optimum

The analytic function `z↦B exp(-zH/2)` is bounded on any closed vertical strip. On a vertical line `Re z=s`, its norm is constant since the imaginary factor is unitary on the right. Hadamard three-lines therefore proves the log-convexity of `||B exp(-sH/2)||`, and thus the convexity of `phi`.

The vacuum block has norm one, so `phi(s)≥0`. Since the positive-energy block decays exponentially in norm, `phi(s)=0` for all `s≥s_*`, where `s_*` is the exact Cholesky threshold. For `c>0`, the infimum can therefore be minimized on compact `[0,s_*]`.

If `lambda=exp(phi(s))` and `W` is the top eigenspace of `C_s`, then

`P_W C_s' P_W=-lambda P_W H P_W`.

Thus the left and right derivatives of `phi` are `-h_max(W)` and `-h_min(W)`, respectively, and

`∂phi(s)=[-h_max(W),-h_min(W)]`.

At an interior minimizer `s>0`, dual optimality says `c∈[h_min(W),h_max(W)]`. The numerical range of the Hermitian compression `P_W H P_W` is exactly this interval, so there is a unit top eigenvector `w` with `<w,Hw>=c`. At the constrained endpoint `s=0`, optimality says `c≥h_min(W)`, and one can choose a top vector with mean energy `h≤c`.

The point `s=s_*` is an ordinary interior point of the original domain `[0,∞)` whenever `s_*>0`. Its top eigenspace includes the vacuum; therefore `h_min(W)=0`, and the numerical-range argument handles the entire initial linear segment. If `s_*=0`, then `E=I`, and all rates vanish.

## Exact-type lower bound replacing CLT

Fix a minimizing `s` and a top vector `w` chosen as above. In an energy basis, let `p_j=|w_j|²` and restrict to occupied indices. Let `j_0` be an occupied index of smallest energy. For `j≠j_0`, choose `k_j=floor(np_j)`; put the remaining counts at `j_0`. Then

`q_n=Σ_j k_j h_j≤n h`, `q_n=n h-O(1)`.

Normalize the type projection,

`eta_n=Pi_k w^⊗n/sqrt(p_type,n)`,

`p_type,n=n! ∏_j p_j^(k_j)/k_j!`.

It is an exact-energy vector with energy `q_n`, and Stirling gives `-log p_type,n=O(log n)`.

Because `C_s≥lambda |w><w|`, tensor order gives `C_s^⊗n≥lambda^n|w^⊗n><w^⊗n|`. Hence

`||B^⊗n eta_n||²=e^{s q_n}<eta_n,C_s^⊗n eta_n>`

`                        ≥exp[n phi(s)+s q_n] p_type,n`.

The vector is legal since `q_n≤n h≤n c`. At `s>0`, `h=c`, so this is at least `exp[n g(c)-O(log n)]`. At `s=0`, the `s q_n` term vanishes and `g(c)=phi(0)`, yielding the same conclusion. This proves the actual full-sequence limit and logarithmic remainder with no CLT, lattice assumption, or soft cutoff.

The upper bound is exactly the source's tensor-order argument.

## Endpoint / degeneracy checks

- `c=0`: only the vacuum block is legal, so the rate is exactly zero; the dual infimum is `inf phi=0`.
- `c≥h_max(H)`: the cutoff is the whole space and `F_n=n log||A||`; the dual minimum occurs at `s=0`.
- The plateau actually starts as soon as `c≥h_min(W_0)`, where `W_0` is the top eigenspace of `A`; it can start before the highest physical energy.
- The initial linear segment is `g(c)=s_*c` for `0≤c≤h_max(W_{s_*})`. The vacuum supplies the zero-energy endpoint, and mixing within the top eigenspace supplies every intervening mean.
- Energy degeneracies permit arbitrary orthonormal bases inside each energy block. Any two upper block triangular factors of the same Gram matrix differ by a left block diagonal unitary commuting with `H`; therefore the weighted norm, `phi`, and the derived curve are basis independent.
- Top eigenvalue degeneracy is handled by the compression numerical range, not by assuming a differentiable top eigenvalue.
- Nonlattice energy eigenvalues cause no difficulty because an occupation type always has exactly one total energy. Rounded occupations give a constant, not linear, energy error.

## Supporting primary sources

These support standard ingredients, not the newly reconstructed operational theorem:

1. Bourin and Lee, *Matrix inequalities from a two variables functional*, arXiv:1511.06977v3, Theorem 1.2, proves joint log-convexity of a more general unitarily invariant norm functional. Set their first positive matrix to `I`, their `Z` to this `B`, their second positive matrix to `exp(-H/2)`, their `p=1`, and `alpha=1` to recover log-convexity of `||B exp(-sH/2)||`. <https://arxiv.org/html/1511.06977v3>

2. Csiszár and Shields, *Information Theory and Statistics: A Tutorial*, author-hosted PDF, Lemma 2.3, bounds a type probability above and below by its relative-entropy exponential rate with a polynomial factor. It supplies an alternative to the elementary Stirling estimate. <https://www.renyi.hu/~csiszar/Publications/Information_Theory_and_Statistics%3A_A_Tutorial.pdf>

3. Csiszár, *The Method of Types*, IEEE Transactions on Information Theory 44(6), 2505–2523 (1998), Lemmas II.1–II.2, gives polynomial type counts and type probability bounds. DOI: <https://doi.org/10.1109/18.720546>. University-hosted text was retrieved by search at <https://iest2.ie.cuhk.edu.hk/~whyeung/post/manuscript/06_SAEP/method%20of%20types.pdf>.

No matching prior operational statement was located in targeted searches. That negative search result is not evidence of novelty.
