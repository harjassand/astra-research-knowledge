# Exact hard-energy exponent: independent audit

Assume finite dimension, `H=0 ⊕ H_+` with `H_+>0`, and `E=1 ⊕ E_+` with `0<E_+≤I`. Let

`P_{n,Q}=1_{(-∞,Q]}(H^(n))`, `H^(n)=Σ_i H_i`, and

`p(Q)=inf_{n≥1} λ_min(P_{n,Q} E^⊗n P_{n,Q}|ran P_{n,Q})`.

The hard-energy asymptotic exponent exists and is

`lim_{Q→∞} [-log p(Q)]/Q = s_ch`,

where, in an eigenbasis of `H_+` ordered by increasing energy, take the upper Cholesky factor `E_+=R†R`, set `B=R^{-1}`, and define

`s_ch=inf{s≥0: B†B≤exp(sH_+)}`

`     =inf{s≥0: ||B exp(-sH_+/2)||≤1}`

`     =inf{s≥0: RR†≥exp(-sH_+)}`.

This is a self-contained derivation, independently checked by three agents; it is not a literature novelty claim.

## Finite-cutoff factorization

Upper triangular matrices in increasing energy order can only lower energy. Therefore `R^⊗n` and `B^⊗n` preserve every `ran P_{n,Q}`. On this subspace, the restricted map `R_{n,Q}` is invertible with inverse `B_{n,Q}`. Consequently

`P_{n,Q}E^⊗n P_{n,Q}|ran P_{n,Q}=R_{n,Q}†R_{n,Q}`,

and

`λ_min(P_{n,Q}E^⊗n P_{n,Q}|ran P_{n,Q})=||B^⊗n P_{n,Q}||^{-2}`.

The vacuum block is `1` throughout. This formula remains valid for arbitrary `n` and arbitrary real energy eigenvalues; integral energies are not needed.

## Converse

At any `s` with `B†B≤exp(sH_+)`, tensor order gives `(B†B)^⊗n≤exp(sH^(n))`. Thus

`||B^⊗nP_{n,Q}||²≤exp(sQ)`.

Taking `s=s_ch` yields `p(Q)≥exp(-s_ch Q)` for every `Q`.

## Achievability by an energy-typical vector

For `E_+≠I`, `s_ch>0`. Since `H_+>0`, the function `||B exp(-sH_+/2)||` is continuous, strictly decreasing whenever nonzero, and crosses `1` exactly once. At the threshold

`C=exp(-s_ch H_+/2) B†B exp(-s_ch H_+/2)`

is a positive contraction with a unit eigenvector `w` of eigenvalue `1`. Let `h=<w,H_+w>>0`. For fixed `δ∈(0,h)`, form

`Π_n=1_[n(h-δ),n(h+δ)](H_+^(n))`,

`ψ_n=Π_n w^⊗n/||Π_n w^⊗n||`.

Ordinary iid energy measurement concentration implies `||ψ_n-w^⊗n||→0`. Since `C^⊗n` is a contraction and fixes `w^⊗n`,

`d_n=<ψ_n,C^⊗nψ_n>→1`.

Define the normalized legal probe

`χ_n=B^⊗n exp(-s_ch H_+^(n)/2) ψ_n /sqrt(d_n)`.

Every factor preceding `ψ_n` preserves the lower energy cutoff, so `χ_n` has support in `H_+^(n)≤n(h+δ)`. Its miss expectation is exactly

`<χ_n,E_+^⊗nχ_n>=<ψ_n,exp(-s_ch H_+^(n))ψ_n>/d_n`

`                         ≤exp[-s_ch n(h-δ)]/d_n`.

For arbitrary large `Q`, choose `n=floor[Q/(h+δ)]`. Then

`liminf_{Q→∞}[-log p(Q)]/Q≥s_ch(h-δ)/(h+δ)`.

Let `δ↓0`. If `E_+=I`, `p(Q)=1` and the same theorem holds with `s_ch=0`.

The concentration occurs in `H`, and the contracted quantity is `C^⊗n`, whose norm is at most one. Thus this proof does not use an illegal `(-log E)` typical projection or rely on exponentially small errors controlling `E^⊗n`.

## Stronger explicit type construction: logarithmic remainder

The exact asymptotic statement can be strengthened to

`s_ch Q-O(log Q)≤-log p(Q)≤s_ch Q`.

In the energy basis, write `w=Σ_j c_j|j>` and `p_j=|c_j|²`; restrict to occupied indices `p_j>0`. Choose the occupied index `j_0` with smallest energy. Set `k_j=floor(np_j)` for `j≠j_0` and `k_{j_0}=n-Σ_{j≠j_0}k_j`. Its type energy satisfies

`q_n=Σ_j k_jh_j=nh-Σ_{j≠j_0}(np_j-floor(np_j))(h_j-h_{j_0})`,

so `nh-O(1)≤q_n≤nh`. Let `Π_k` project onto this occupation type and put

`η_n=Π_k w^⊗n/sqrt(p_type,n)`,

`p_type,n=n! ∏_j p_j^(k_j)/k_j!`.

This is an exact-energy normalized Dicke vector (up to an irrelevant phase). Stirling's formula gives `-log p_type,n=O(log n)` because every occupied `p_j` is fixed and `k_j=np_j+O(1)`.

Since `C` is positive with eigenvalue `1` on `w`, one has `C≥|w><w|` and hence `C^⊗n≥|w^⊗n><w^⊗n|`. Therefore

`||B^⊗nη_n||²=e^(s_ch q_n)<η_n,C^⊗nη_n>`

`                   ≥e^(s_ch q_n) p_type,n`.

The normalized legal probe `χ_n=B^⊗nη_n/||B^⊗nη_n||` has cutoff at most `q_n`, and its miss expectation is exactly `||B^⊗nη_n||^-2`, at most `e^(-s_ch q_n)/p_type,n`. Choosing `n=floor(Q/h)` yields `q_n≤Q` and `Q-q_n=O(1)`, proving the stated logarithmic remainder. No limiting typical window or exponentially small tail estimate is required.

## Independent polynomial-shell achievability

For `s<s_ch`, put `c_s=||B exp(-sH_+/2)||>1`. Decompose the tensor input into distinct exact energy shells `Π_q`. There are at most `L_n=binom(n+d-1,d-1)` shells, regardless of rational relations among energy eigenvalues, and all `q∈[nh_min,nh_max]`. Then

`c_s^n=||B^⊗n exp(-sH_+^(n)/2)||`

`     ≤Σ_q exp(-sq/2)||B^⊗n Π_q||`

`     ≤L_n max_q exp(-sq/2)||B^⊗nΠ_q||`.

At some shell `q_n`,

`||B^⊗nP_{n,q_n}||²≥c_s^(2n) exp(sq_n)/L_n²`.

Hence the legal block at that shell has exponent at least

`s+2log(c_s)/h_max-o(1)`.

Taking `s↑s_ch` proves the threshold lower bound along a sequence. The energy-typical construction above gives the full arbitrary-`Q` limit directly.

## Degeneracy and basis independence

Use blocks corresponding to distinct eigenvalues of `H`. Any upper Cholesky factor is upper block triangular in this decomposition. If `R_1†R_1=R_2†R_2=E`, then `U=R_2R_1^{-1}` is unitary and upper block triangular. An upper block triangular unitary is block diagonal, so `[U,H]=0`. With `B_j=R_j^{-1}`, one has `B_2=B_1U†` and `B_2†B_2=U(B_1†B_1)U†`. The threshold is therefore unchanged. A change of energy eigenbasis is handled by unitary conjugation first, followed by this argument.

## N32 exact comparison

For `H_+=diag(1,2)` and `E_+=[[1/2,sqrt(2)/4],[sqrt(2)/4,3/4]]`,

`R=[[1/sqrt(2),1/2],[0,1/sqrt(2)]]`,

`B†B=[[2,-sqrt(2)],[-sqrt(2),3]]`.

Writing `x=exp(s)`, `exp(sH_+)-B†B` is positive semidefinite exactly when `x≥(1+sqrt(17))/2` for `s≥0`. Its determinant factors as

`(x-2)(x²-3)-2=(x-1)(x²-x-4)`.

Thus

`s_ch=log((1+sqrt(17))/2)=0.9406136421072088`.

The ordinary logarithmic bound is

`alpha=λ_max[H_+^{-1/2}(-logE_+)H_+^{-1/2}]=(5/3)log2=1.1552453009332426`.

The proposed order bound using `E_+` itself is

`s_order=inf{s:E_+≥exp(-sH_+)}=log(1+sqrt5)=1.1743590056195488`.

Therefore the exact hard exponent is strictly smaller than both `alpha` and `s_order`, and strictly exceeds the stated separable exponent `log2`.

## Primary source for the standard factorization convention

LAPACK's official Cholesky documentation gives `A=U^H U` for the upper factor in the complex Hermitian case, and its source implements the routine: <https://www.netlib.org/lapack/explore-html/d2/d09/group__potrf.html>. This source supports only the standard factorization convention, not the derived hard-energy theorem. Searches for energy-constrained discrimination and asymptotic tensor compression did not locate a matching previously published formula.
