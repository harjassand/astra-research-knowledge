# ACKN source check

Primary: Anderson, Cappelletti, Kim, Nguyen, *Tier structure of strongly endotactic reaction networks*, arXiv:1808.05328v2 (2019 preprint; 2020 journal DOI).

- https://arxiv.org/pdf/1808.05328v2
- https://arxiv.org/abs/1808.05328
- https://doi.org/10.1016/j.spa.2020.07.012

Example 3.1, printed pp.6–7 (PDF indices5–6), establishes strong endotacticity and every state's transience for all strictly positive rate constants for

\[
\varnothing\to2A+B\to4A+4B\to A.
\]

Section2.4, equation(2.3), printed p.5, defines the count process on nonnegative integer states with

\[
\lambda_{y\to y'}(x)=\kappa_{y\to y'}1_{\{x\ge y\}}x!/(x-y)!.
\]

There is no volume parameter or denominator \(y!\). Definitions3.1–3.2 maximize over source complexes only. Example3.1's escape proof uses positive probability of infinitely repeating the three reactions; each cycle adds one A. It does not claim almost-sure drift.

Caveat: the reachability paragraph prints \(4A+4B\to0\); this is a typo relative to the stated network and subsequent probability product, which use \(\to A\).

Independent fixed-volume inference: with conventional volume scaling \(\kappa_y V^{1-|y|}(x)_y\), every finite \(V>0\) produces positive effective constants. Here they are \(\kappa_1V,\kappa_2/V^2,\kappa_3/V^7\), so the all-positive-constants transience result applies.

Independent typo repair: choose immigration count \(j\) so \(a+2j\ge b+j=4m\). Then \(m\) actual third-reaction firings leave \(B=0\), \(A=a+2j-3m\ge m\); all are enabled.
