# Two-factor mixed GHC over higher-degree real-multiplication fields

Status: internal proof-level conditional consequence. It imports the pinned family032 exact KS/exterior-return and mixed ordinary-HC statements, whose proofs and priority are not externally certified here. The extension is a scoped representation/carrier result, not a resolution of unrestricted mixed GHC.

## The exact theorem

Let E be a totally real number field of degree e≤4. Let S1,S2 be projective complex K3 surfaces and put Vi=T(Si)(1). Assume

1. End_Hdg(T(Si))=E, with specified common E-identifications, and dim_E Vi=3;
2. Hg(V1⊕V2)=Res_(E/Q) SO(V1,q1) × Res_(E/Q) SO(V2,q2);
3. the even Clifford quaternion algebras C_E^+(Vi,qi) have the same E-Brauer class D.

Conditional on algebraic exterior returns for every projective K3 and ordinary rational HC on all mixed K3 products, GHC holds on every S1^a×S2^b, for arbitrary a,b and every rational sub-Hodge structure in every degree.

The genuinely additional degree cases compared with the R common-quaternion report are e=3 and e=4. The number of independent original factors is two. We do not claim the arbitrary-number-of-factors theorem over these larger fields.

## Active-place alignment is forced, not tacit

For a rank-three RM K3 module, the E-form has signature (2,1) at the unique embedding active on the (2,0) line and is negative definite at all other embeddings. Its even Clifford quaternion algebra is split at the active embedding and Hamiltonian at each inactive embedding. Equality of the E-Brauer classes therefore forces the same singleton real split place, denoted σ0, for both surfaces. This uses the specified common E-identifications.

## A single auxiliary K3

Use U=D, of E-dimension four, with the two original spin groups acting by left and right multiplication. Its invariant E-form is qU=a(-Nrd_D). Choose a∈E* positive at every inactive embedding and with the active sign making its period plane positive. Weak approximation gives these signs.

At σ0, the two original spin circles have weights ±1/2 in normalized cocharacter units. Their tensor therefore has weights 1,0,0,-1, so U has a single holomorphic line after untwisting. At every other embedding both circles are trivial. The real signatures of qU are (2,2) at σ0 and (0,4) elsewhere. Thus its trace form has rational dimension 4e and signature (2,4e−2), with K3-type Hodge structure.

The independent original joint group acts on U through the finite central quotient of Res_(E/Q)(SL1(D)×SL1(D)). It follows that U is rationally simple, its endomorphism field is E, and it has no rational (1,1) part. Over every embedding σ its complex representation is spin(V1,σ)⊗spin(V2,σ).

Here is the rational lattice step. Let Λ_Q be the rational K3 lattice, of dimension22 and signature(3,19). Seek a complement C of dimension22−4e≥6 and signature(1,21−4e). Prescribe its determinant so det(U⊥C)=det Λ_Q. At every finite place prescribe its Hasse invariant by

    ε_v(C)=ε_v(Λ_Q) ε_v(U) (det U,det C)_v.

In dimension at least six every prescribed determinant/Hasse pair over a nonarchimedean local field is realizable. The required real signature gives the matching determinant sign and Hasse invariant. Hilbert reciprocity for the determinants, together with the product relations for Λ_Q and U, gives the global product relation for these prescribed invariants. The local classification and Hasse–Minkowski theorem therefore supply C and an isometry U⊥C≅Λ_Q.

Intersect the rational U-subspace with the integral K3 lattice. This is a primitive even integral lattice. The period lies in its complexification; C has a positive rational vector, which can be multiplied to be integral. The K3 period theorem gives a projective marked K3 S12. Since U has no rational (1,1) vector, T(S12)_Q is exactly U with its specified Hodge structure. No integral prescribed-isometry theorem is needed: the integral lattice is acquired by intersection inside Λ.

## Exterior carriers can select either label at every embedding

At any embedding σ,

    wedge²_E Uσ = V1,σ ⊕ V2,σ.

This is the identity wedge²(A⊗B)=(Sym² A⊗wedge² B)⊕(wedge² A⊗Sym² B) for two-dimensional spin modules.

If a set of t embeddings is labelled independently by either 1 or 2, the decomposition of wedge_Q^(2t) U contains the complex representation

    tensor_(labelled σ) V_label(σ),σ.

Use wedge² Uσ at each labelled embedding and wedge⁰ at each blank embedding. Crucially, one full rational exterior power supplies all these embedding slots while spending one return. Its exterior degree may be up to 2e.

## Exact carrier count for arbitrary mixed powers

Let H be a rationally simple sub-Hodge structure of H^(2d)(X,Q), X=S1^a×S2^b, with Hodge coniveau≥p. The algebraic Künneth projectors put H(d) in the tensor category of V1,V2, with Tate slots suppressed. Choose a complex irreducible constituent; write k_i,σ≥0 for its SO3 highest weights in vector units. Put

    Lσ=k_1,σ+k_2,σ,       c=max_σ Lσ.

The normalized Hodge cocharacter is active at σ0 in both original factors. Its extremal values on a constituent are ±Lσ0. Absolute Galois acts transitively on the embeddings of E and transports both factor labels simultaneously, because their E-actions are rational with the fixed common identification. Rationality of H therefore makes a constituent with extremal values ±Lσ occur for every σ. Thus H(d) has level exactly2c, and c≤d−p.

At each embedding σ, make a list of k_1,σ tokens labelled1 and k_2,σ tokens labelled2, padded to length c by blanks. For column j, let t_j be the number of its nonblank embedding slots. Choose the carrier wedge_Q^(2t_j) U. Every column is nonempty, because an embedding attaining c has no blanks. The selected complex summand of that carrier supplies exactly its tokens. The product over the c columns contains the chosen Cartan constituent of H(d).

Adjoining S12 gives a connected Hodge group G′ mapping onto the original product with finite central kernel. The selected carrier constituent has the original even spin parities, and hence the same G′ representation as the original constituent. Taking the full rational carriers, rather than asserting rationality of their selected complex projectors, gives

    Hom_G′(tensor_j wedge^(2t_j) U,H(d)) ⊗_Q C ≠0.

Scalar extension of invariants yields a nonzero rational Hodge map. It is onto because H is rationally simple. If c=0, ordinary HC treats the Tate substructure directly.

## Algebraic transport and support codimension

Write k_j=2t_j, s=sum_j k_j, and Y=S12^s. The rational surjection extends by zero on a Hodge complement to a map H^(2s)(Y)(s)→H^(2d)(X)(d). It corresponds to a Hodge class of codimension s+d on the actual mixed K3 product Y×X. The imported mixed ordinary HC algebraizes it.

For each j, the imported exterior return is from an abelian square Z_j, of dimension n_j, with cycle codimension n_j+k_j−1. Their product is a return from Z=product Z_j, N=dim Z, of codimension N+s−c. Compose with the codimension-(s+d) transport on Y×X, using dimY=2s. The resulting cycle on Z×X has codimension

    (N+s−c)+(s+d)−2s = N+d−c.

Its support projects to a subset of X of codimension at least d−c≥p. The image contains H. Semisimplicity and a finite union of supports treat arbitrary rational sub-Hodge structures; odd cohomology vanishes. This proves the stated conditional GHC.

## Sharp boundaries of this proof

* e=5: U has rank20; the remaining complement has rank2. Arbitrary prescribed local invariants cannot be realized in rank2. The same proof works if the trace norm form is explicitly shown to embed into Λ_Q with positive complement; no automatic degree-five assertion is made.
* e≥6: a faithful two-factor crossed constituent is absent from the tensor category of EVERY single actual K3, even with common D. Zarhin and centroids would force RM rank4 over E, of rational dimension≥24, exceeding the projective K3 transcendental bound21.
* Three independent factor labels over e≥3: a Galois orbit of pairwise-distinct embedding triples gives a rationally simple, faithful three-group constituent of level2 and coniveau2 in H6. Zarhin's classification proves that NO single auxiliary K3 tensor category can carry it, even with common D. This is a theorem about all one-K3 replacements, beyond the failure of the particular U12. The above all-powers positive theorem is for two original factors.
* Distinct quaternion classes: the separate brauer/ONE_K3_CARRIER_OBSTRUCTION.md shows that every off-diagonal orbit constituent over ANY common totally real E of degree≥2 is absent from the tensor category of every single K3. This is stronger than the same-character Tits multiplicity objection. The missing algebraic abelian crossed-spin return remains open.

## Exact imported sources and priority

Pinned commit: adc7f1241b42e322a6451854ab7e4b4c146bf78a.

* Exterior return: https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Algebraic-Kuga-Satake-correspondences-and-Hodge-conjectures-on-a-K3-quadratic-locus-September-30-2026/build/paper.tex ; ghc:prop:exterior-coniveau, lines631–674.
* Mixed ordinary HC: https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/The-rational-Hodge-conjecture-for-products-of-K3-surfaces-October-4-2026/build/manuscript/introduction.tex ; thm:main, with the tensor-group proof in mixed.tex.
* Exact all-K3 KS: https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Algebraicity-of-Kuga-Satake-Correspondences-for-K3-Surfaces-October-3-2026/build/manuscript.tex .
* Classical RM group/signature/existence background: Bert van Geemen, https://arxiv.org/pdf/math/0609839 , Theorem2.8, Lemma3.2, §§5.8,6.4. The cubic rank-three structures and their KS/Mumford factors are existing constructions.
* Modern RM existence: Bayer-Fluckiger–van Geemen–Schütt, https://arxiv.org/html/2401.04072v4 . Their general existence theorem for m[E:Q]≤21 supplies context, not the mixed-coniveau conclusion here.
* Rational quadratic classification: Milne, https://www.jmilne.org/math/CourseNotes/CFTc.pdf , ChapterVIII local classification and Hasse–Minkowski.
* K3 period/projectivity: https://www.math.uni-bonn.de/people/huybrech/K3Global.pdf ; period theorem and positive integral(1,1)-class criterion.

Abdulali https://arxiv.org/html/math/0410024 gives prior ordinary-to-general domination mechanisms for specified type-III abelian varieties; it was checked as a boundary comparison. No exhaustive novelty search or priority clearance has been completed. The carrier packing is an extension of the already recorded R mechanism and should be presented as an incremental conditional consequence.
