# Mixed Hodge attack: optimal K3 tensor generators, obstructions, conditional GHC

Status: completed scoped internal derivations and classification audit. The exact generator theorem and obstructions use established classical inputs, with NO new HC/KS release premise. The positive GHC conclusion remains conditional on the pinned family032 release premises. No external validation of the derivations, imported manuscript correctness, or novelty/priority clearance is asserted.

## Strongest positive outcome: exact auxiliary-K3 tensor-generator count

Let S_1,...,S_m be ANY finite independent list of rank-three RM K3s over one specified totally real E, of degree e<=4, with a common active embedding. Let m_D count original labels with each even-Clifford E-Brauer class D. For ANY faithful rational Hodge target H in their tensor category, the smallest number of actual projective K3 tensor generators is exactly

    r_min(H) = sum_D ceil(m_D/2).

No HC or KS manuscript is used. Every auxiliary K3 has at most two rational simple derived slots by Zarhin. A two-slot source covering two original labels must be rank-four RM with square discriminant; its two Clifford components have the same quaternion class. Centroids and the common unique split place force that pair to have the same specified D. The joint auxiliary group is subdirect, so diagonal links cannot increase this capacity. Assigning original target ideals to auxiliary slots gives the bin-count lower bound.

For the matching upper bound, pair labels within each D-class. Each pair admits the classical norm-form auxiliary U_ij=D of E-rank4, with K3-type Hodge circle and wedge²_E U_ij=V_i⊕V_j. Its rational rank is4e<=16, and a rational K3 complement has rank22-4e>=6. Standard local quadratic-form classification plus Hasse–Minkowski supplies the embedding; primitive integral intersection, the K3 period theorem, and a positive complementary class supply an actual projective K3. These established local/global quadratic and period theorems are explicitly imported, not replaced by numerical tests. Pair auxiliaries and original leftover surfaces attain the lower bound.

Detailed theorem, lower and upper proofs, active spin-circle descent, and scope: `brauer/OPTIMAL_K3_TENSOR_GENERATOR_COUNT.md`. It counts Hodge tensor generators, not algebraic correspondences, geometric coniveau, or an algorithm.

At e=5 the same lower bound holds but the rank2 K3 complement needs an embedding certificate; without one the automatic upper bound is m. At e=6/7 the exact count is m, since any paired source would have forced transcendental rank4e>21. The degree-five boundary remains unresolved here.

## Decisive negative theorem

For two independent rank-three RM K3 transcendental modules over the same totally real E of degree e>=2, active at the same embedding, with distinct even-Clifford quaternion classes D1,D2, EVERY rational crossed summand H_O indexed by a Galois orbit of ordered distinct embedding pairs belongs to the tensor category of **no single K3 transcendental module**, of any rank and any endomorphism field. In particular every Hom_Hdg(wedge^k T(S)(k),H_O)=0 after the corresponding weight-zero normalization. For actual projective K3s, 2<=e<=7. The quadratic case is retained as its first instance.

The proof is stronger than the reported Tits-index/h^(2,0)-multiplicity check. The etale algebra E⊗E supplies rational primitive orbit idempotents; multiplicity-one irreducible summands and Galois transitivity prove simplicity. Orbit projections hit every embedding, giving faithfulness, and distinctness gives exact level2/coniveau1 in H4. A proposed single-K3 carrier would force a quotient Hg(T(S))→G1×G2. Zarhin's classification leaves only square-discriminant RM rank4, whose two adjoint factors arise from the SAME quaternion norm form. Centroids force its field to be E. The two identifications differ by alpha∈Aut(E); equality of the unique split real place forces sigma0∘alpha=sigma0, hence alpha=id by injectivity. Thus D1=D2, a contradiction.

Detailed proof: `brauer/ONE_K3_CARRIER_OBSTRUCTION.md`.

The obstruction is unconditional within its Hodge-group interface. It does not disprove GHC or exclude a carrier on an arbitrary abelian/smooth projective variety. It rules out the entire advertised one-K3 exterior-return repair class, including a larger-rank, CM, or larger-end-field substitute.

## Several labels: a stronger common-class obstruction

For m independent rank-three RM K3s over common E, 3<=m<=e, choose a Galois orbit of ordered PAIRWISE DISTINCT embedding m-tuples. Its rational simple constituent H_O is faithful for the entire m-group product but still has exact normalized level2. In H^(2m) it has exact Hodge coniveau m-1. No single K3 can carry H_O, even if every D_i agrees, because a K3 Hodge group's derived Lie algebra has at most two rational simple ideals.

More quantitatively, any tensor category of r auxiliary K3s containing H_O must have r>=ceil(m/2). The joint Hodge Lie algebra is subdirect in the auxiliary groups; diagonal links can only merge simple ideals. For e=6/7 the necessary rank4-E two-ideal auxiliary exceeds rank21, so r>=m, and the original m K3s achieve equality. Detailed orbit descent, simplicity, faithfulness, level, and subdirect-count proof: `brauer/MULTI_FACTOR_CARRIER_LOWER_BOUND.md`.

The exterior-return framework supplies only generic support N^(m-c) from c returns, while these level-two terms require N^(m-1). Since c>=2 in the three-or-more-label case, or the two-label distinct-D case, the generic count misses that target. This is a carrier/support-accounting obstruction, not a lower bound on actual geometric coniveau or a refutation of GHC.

## Positive conditional theorem beyond the recorded quadratic-field case

For **two** independent rank-three RM K3s over a common totally real E of degree e=3 or4, with common even-Clifford D, all mixed powers satisfy GHC conditional on exact exterior returns for all K3s and ordinary HC on mixed K3 products.

The auxiliary U=D has E-rank4, rational rank4e≤16, h^(2,0)=1, and trace signature(2,4e−2). A complement of rational rank22−4e≥6, with prescribed determinant/local Hasse invariants, embeds U in the K3 lattice; period realization produces an actual S12.

At every embedding, wedge²_E Uσ=V1,σ⊕V2,σ. A full exterior power of U can choose **either** original label independently at every embedding. For a simple mixed tensor with highest weights k_i,σ, its exact half-level is c=maxσ(k_1,σ+k_2,σ). Pack c columns of tokens, with one label or blank per embedding. Each column fits in one exterior power wedge^(2t)U. This yields c returns, and algebraizing the rational quotient on actual K3 products gives support codimension d−c, exactly the GHC requirement.

Detailed proof: `TWO_FACTOR_HIGHER_RM_GHC.md`.

This is an incremental extension of the R pairing mechanism, not a high-ceiling resolution. At degree5 the rank2 complement has a genuine local-invariant embedding gate; the proof extends only with an explicit K3-lattice embedding. The multi-label theorem above proves that extending this positive theorem to three labels needs a different return mechanism, not a replacement single K3.

## The remaining distinct-class gate

The primary release's `auxiliary.tex` proves algebraicity of a degree-four quadratic metric tensor P on certain crossed abelian spin realizations. Its `mixed.tex` final conclusion is tensor-group equality restricted to the original Vi. Neither statement as written supplies the algebraic comparison between a crossed End realization and the original cross H.

The smallest sufficient missing object is an actual cycle

    R ∈ CH^(dim B+1)(B×S1×S2)_Q

for some smooth projective/abelian B, whose action from H²(B) contains the cross summand of H⁴(S1×S2). Its cycle support would give divisor coniveau automatically. Equivalently one can algebraize the period-compatible crossed-spin shuffle plus the rational projected return. A Hodge isomorphism of tensor products of H¹ spaces is not an abelian homomorphism, and the standalone P metric does not close this transport gap.

No crossed-spin algebraicity proof was obtained. The new obstruction makes clear that changing the single auxiliary K3 cannot close it.

## Primary provenance and prior-art status

All release sources were retrieved at commit `adc7f1241b42e322a6451854ab7e4b4c146bf78a`; exact byte hashes are in `sources/SOURCE_HASHES.json`. The detailed positive proof gives their primary URLs and theorem labels. The exact exterior return is `paper.tex` lines631–674, `ghc:prop:exterior-coniveau`; the restricted tensor-group goal is `mixed.tex`, `eq:mixed-group-goal`; the standalone abelian metric is `auxiliary.tex`, `prop:auxiliary-spin`.

Classical primary inputs checked: van Geemen https://arxiv.org/pdf/math/0609839 , Theorem2.8 and cubic rank-three §§5.8/6.4; Moonen https://arxiv.org/pdf/1504.05406 , §2.1 and §6.4(iii), restating both Zarhin branches; Bayer-Fluckiger–van Geemen–Schütt https://arxiv.org/html/2401.04072v4 for modern RM existence; Abdulali https://arxiv.org/html/math/0410024 for type-III domination comparisons. Zarhin's original classification is J. Reine Angew. Math.341(1983), Theorems2.2.1/2.3.1, https://eudml.org/doc/152536 .

The representation obstruction was independently checked by the delegated branch. The theorem proof was checked by exact representation/codimension accounting; no finite numerical fixture is called proof. External specialist review and a dedicated priority audit remain outstanding.
