# Positive reduction audit for fixed-cardinality squared hafnians

Status: exact identities and positive gadget barriers established; no general approximation-preserving reduction established or ruled out.

Let B be a real symmetric, entrywise nonnegative, zero-diagonal n by n matrix and let

    Z_k(B) = sum_{S subset [n], |S|=2k} haf(B_S)^2.

All graph weights below are nonnegative. Complex B requires separate treatment: the ordinary positive graph identity uses real nonnegative hafnians.

## 1. The doubled-graph identity is exact

On two labelled copies of [n], place B edges inside each copy, and give each vertical identity edge weight t. Every perfect matching chooses a set T of vertical edges; the remaining identical set S=[n] minus T must be perfectly matched independently within both layers. Hence

    haf([[B,tI],[tI,B]])
      = sum_{S even} haf(B_S)^2 t^(n-|S|)
      = sum_k Z_k(B)t^(n-2k).

Thus Z_k is exactly the count of weighted perfect matchings with n-2k prescribed-color (vertical) edges. An algorithm for unconstrained weighted #PM estimates the full polynomial at t>0. The coefficient extraction step is additional work.

The fixed-cardinality support test is easy in this special case: Z_k(B)>0 iff the positive-support graph of B has a matching of size k. If such a matching exists, take its 2k covered vertices, and use the same matching in both copies; conversely any nonzero summand has such a matching. This differs from general red/blue Exact Matching.

## 2. Positive evaluation alone is not coefficient extraction

For an arbitrary nonnegative polynomial P(t)=sum_j a_j t^j, an interior coefficient cannot be represented universally as a nonzero nonnegative linear combination of evaluations P(t_i) with t_i>0: the resulting coefficient of every monomial t^j is sum_i c_i t_i^j>0. This statement rules out only subtraction-free linear extraction from finitely many positive evaluations. It does not rule out adaptive algorithms, signed interpolation with a valid condition bound, or distribution-specific rejection sampling.

Ordinary interpolation is exact with exact #PM queries, but multiplicative approximation errors can be magnified by subtraction. A quantitative stability or lower-bound-on-sector-probability theorem is needed to turn this identity into an AP reduction. No such theorem was established in this audit.

## 3. Cardinality on independent single terminals is expressible

Do not claim that exact Hamming weight by itself is impossible for positive PM gadgets. Take n terminal vertices and r internal vertices, with the complete bipartite graph K_(r,n). Deleting a terminal set U leaves a perfect matching iff n-|U|=r; then it has r! perfect matchings. This realizes an exact-cardinality signature, with constant multiplicity.

The issue for squared hafnians is duplication: a selected label must be deleted simultaneously from BOTH B layers. Copying a two-terminal edge-use bit to two further counter terminals requires the four-terminal equality support {0000,1111}; the natural global selector requires exact cardinality of WHOLE terminal pairs. These are substantially different signatures.

## 4. A four-terminal positive gadget barrier

For a graph H with terminal set T, let f(U)=weighted PM count of H-U, where U is a subset of terminals. Nonzero support satisfies symmetric exchange. Given positive matching witnesses for f(A),f(B) and a terminal a in A symmetric-difference B, superpose the two matchings and follow the unique alternating path from a to another terminal b in A symmetric-difference B. Toggling this path gives witnesses for f(A symmetric-difference {a,b}) and f(B symmetric-difference {a,b}). Positivity preserves their nonzero weight.

In particular a four-terminal signature with f(empty)>0 and f(T)>0 necessarily has a nonzero two-terminal state. Therefore the exact all-or-none equality signature on four ports cannot be implemented by any nonnegative weighted perfect-matching gadget, regardless of graph size or nonplanarity. Signed/complex matchgates can use cancellation and lie outside this assertion.

This obstructs the standard local edge-replacement/counter-signal gadget. It is not a proof that all possible AP reductions fail.

## 5. Global whole-pair selector

For n pairs {i_top,i_bottom}, consider a signature supported exactly on deletion sets U=S_top union S_bottom with the SAME S and |S|=q, for interior 0<q<n. This support fails symmetric exchange: choose two q-subsets exchanging one label p for r and fix terminal p_top in their symmetric difference. Flipping any other differing terminal either changes q, leaves partial pairs, or both. Consequently no positive PM graph has this exact terminal signature.

For the physically relevant even q, the external B layers themselves discard deletion states of odd size in either layer. This requires a stronger parity-filtered barrier, rather than the raw support statement. The companion proof in gadget_barrier/POSITIVE_SELECTOR_BARRIER.md supplies the strengthened statement for 2<=q<=n-2: even after allowing all odd-odd leakage, a nonnegative PM graph cannot have precisely the desired paired q-subsets as its even-even terminal support. The proof superposes two witnesses that swap TWO labels each, obtaining four terminal paths; one same-layer path immediately yields forbidden even-even leakage, while four cross-layer paths force either nonpaired leakage or a paired state of size q-2.

This also excludes a universal aggregate identity P_H(B)=c Z_k(B) for one fixed B-independent positive gadget H glued directly to two B copies, when 2<=2k<=n-2. Indeed its expansion is sum_X f(X) haf(B_{X_top})haf(B_{X_bottom}). Every target monomial has vertex degree zero or two and total edge degree 2k. Unequal layer vertex sets create degree one at a vertex, while a paired state of wrong size creates a different total degree. Positivity prevents cancellation of these forbidden monomials. Each paired 2k-set must occur to supply its target monomials, so the parity-filtered support condition is necessary even though the two layers use identical B. For even n this covers every nontrivial even occupation cardinality below full occupation; the odd-n boundary 2k=n-1 is not covered. The result still does not rule out a nonlocal re-encoding of the whole input or a distribution-specific approximation argument.

## 6. Literature checked and limitations

* Mulmuley, Vazirani, and Vazirani, *Matching is as Easy as Matrix Inversion* (1987): Exact Matching is handled by randomized isolation and extraction of a Tutte/Pfaffian coefficient. This is not a positive PM counting gadget. Author-hosted paper: https://people.eecs.berkeley.edu/~vazirani/pubs/matching.pdf (Section 6, Theorem 4).
* Colin McQuillan, *Approximating Holant problems by winding* (arXiv:1301.2880): Proposition 5 makes positive matching-circuit expressibility an AP reduction to #PerfMatch; the paper studies the restrictions on such expressibility and distinguishes positive matching circuits from signed planar matchgates. https://arxiv.org/pdf/1301.2880 (Section 1.3; Proposition 5; Section 7).
* Bhatnagar, Randall, Vazirani, Vigoda, *Random Bichromatic Matchings* (Algorithmica 2008): their general-graph result approximates a soft penalized partition function over ALL matchings, with runtime polynomial in inverse activities. Exact-sector sampling/counting is established in special settings such as the torus, and perfect-matching counting in dense graphs has a separate statement. This does not give a general exact-sector AP reduction from ordinary #PM. Paper text: https://citeseerx.ist.psu.edu/document?doi=6431287e5542eb3d7a584bae735843ac0bfeca3b&repid=rep1&type=pdf . Author publication page confirming bibliographic record: https://sites.cs.ucsb.edu/~vigoda/publication.html .
* El Maalouly, *Exact Matching: Algorithms and Related Problems* (STACS 2023), https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.STACS.2023.29 , and Murakami/Yamaguchi (2025), https://www.jstage.jst.go.jp/article/transinf/E108.D/3/E108.D_2024FCP0009/_article/-char/en , document specialized deterministic algorithms and the historical derandomization issue.
* A 2026 preprint, Yuefeng Du, *Bipartite Exact Matching in P*, https://arxiv.org/abs/2604.01571 , claims a bipartite deterministic algorithm. This audit has not proof-validated that claim. It prevents presenting a blanket present-day assertion that bipartite Exact Matching is certainly still unresolved.

A deterministic support-preserving many-one positive reduction from general colored Exact Matching to ordinary PM would imply a deterministic polynomial algorithm for general Exact Matching, because positivity/zero of the transformed PM count is decidable by ordinary matching. This is a consequence, not a lower bound or impossibility theorem; randomized AP reductions need not have this consequence. The specialized doubled graph already has an easy support decision, so this complexity observation is weaker than the explicit paired-selector barrier there.

## Conclusion

Known positive #PM expressibility does not finish fixed-cardinality squared-hafnian sampling. The full partition function is a positive doubled-graph #PM count, but the natural local copier and universal whole-pair exact selector cannot be positive PM gadgets. A valid fixed-cardinality theorem therefore needs an additional nonlocal AP reduction, stable coefficient algorithm, or proved polynomial sector-mass bound. None was established here, and no general impossibility claim is warranted.
