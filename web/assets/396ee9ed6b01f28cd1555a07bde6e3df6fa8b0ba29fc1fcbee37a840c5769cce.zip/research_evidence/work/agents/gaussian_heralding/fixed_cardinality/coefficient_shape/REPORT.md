# Squared hafnian coefficient shape: exact obstruction and partial bound

Let B be a symmetric matrix with nonnegative off-diagonal entries on N vertices, h(S)=haf(B_S), h(empty)=1, m=floor(N/2), and

    a_k = sum_{|S|=2k} h(S)^2,   Z(t)=sum_{k=0}^m a_k t^k.

The fugacity in this report is any positive real t. No physical spectral bound is assumed.

## 1. Ordinary log-concavity and Hurwitz stability both fail

For the unweighted complete graph K_N,

    a_k = C(N,2k) ((2k-1)!!)^2
        = N!/(N-2k)! * C(2k,k)/4^k.

For K_12 the exact coefficients are

    [1, 66, 4455, 207900, 5457375, 58939650, 108056025].

Thus a_1^2=4356<4455=a_0 a_2. This is an explicit unweighted counterexample to ordinary log-concavity.

The same Z is not Hurwitz stable. For its descending coefficients

    [108056025, 58939650, 5457375, 207900, 4455, 66, 1],

the leading minors of the standard Hurwitz matrix are exactly

    [58939650,
     299190924821250,
     47145987199578960000,
     121726727059966514640000,
     -808578408339264245760000,
     -808578408339264245760000].

The negative fifth minor violates the necessary Routh-Hurwitz condition. Floating root checks also find the pair 0.000783787261691032 +/- 0.01896609 i, but the negative exact determinant is the certificate.

## 2. A rigorous normalized submultiplicativity theorem

Define

    d_k=C(2k,k)/4^k,   b_k=a_k/d_k.

For every ordered partition j=k_1+...+k_r into nonnegative integers,

    b_j <= product_i b_{k_i}.

Proof. For |S|=2j sum over ordered partitions S=T_1 disjoint-union ... disjoint-union T_r with |T_i|=2k_i. Every perfect matching of S can assign its j edges to these bins in M=j!/(product_i k_i!) ways, so

    sum_partition product_i h(T_i) = M h(S).

There are Q=(2j)!/(product_i (2k_i)!) such vertex partitions. Cauchy-Schwarz gives

    h(S)^2 <= Q/M^2 * sum_partition product_i h(T_i)^2.

Sum over S, then relax the disjointness requirement on the T_i, using their nonnegative squared weights:

    a_j <= Q/M^2 * product_i a_{k_i}.

The prefactor is exactly

    Q/M^2 = C(2j,j)/(product_i C(2k_i,k_i))
          = d_j/(product_i d_{k_i}).

This proves the theorem. The Cauchy step holds even for complex entries after taking absolute values; the hafnian partition identity remains exact. The squared coefficients use |haf|^2 in that extension.

## 3. Consequence: no exponentially deep initial envelope valley

Fix t>0 and w_l=a_l t^l. Suppose w_0=w_j=1 and all w_l<=1. Then, for every 0<=k<=j,

    w_k >= d_k.

For 1<=k<=j write j=qk+r with q>=1 and 0<=r<k. The theorem implies

    1/d_j <= (w_k/d_k)^q (w_r/d_r)
           <= (w_k/d_k)^q / d_r.

Hence w_k>=d_k (d_r/d_j)^(1/q)>=d_k, since d_l decreases with l. Since Z(t)<=m+1,

    Pr_t(K=k) >= d_k/(m+1) >= 1/[2 sqrt(k) (m+1)]   (k>=1).

The last inequality follows by induction from d_1=1/2 and

    d_{k+1}/d_k=(2k+1)/(2k+2) >= sqrt(k/(k+1)).

Such a t always exists when at least one a_l>0: set t=min_{l>=1:a_l>0} a_l^(-1/l), and take any minimizer j. Therefore all cardinalities at or before the first positive endpoint of the upper coefficient envelope have inverse-polynomial probability under one fugacity.

This theorem does **not** handle envelope intervals whose left endpoint i is positive. It does **not** establish inverse-polynomial anti-concentration at arbitrary k.

## 4. Arbitrary targets on graphs of low cycle rank

Let G be the support graph of B, and let g=|E|-|V|+number_of_components be its binary cycle-space dimension. Define the ordinary matching coefficient

    mu_k=sum_{M:|M|=k} product_{e in M} B_e^2.

Then, for every k,

    mu_k <= a_k <= 2^g mu_k.

Proof. On any induced support S with a perfect matching M_0, the map M -> M symmetric-difference M_0 is injective and lands in the binary cycle space of G. Therefore the number of perfect matchings on S is at most 2^g. For w_M=product_{e in M}B_e, nonnegative cross terms and Cauchy-Schwarz give

    sum_M w_M^2 <= (sum_M w_M)^2 <= 2^g sum_M w_M^2.

Sum over |S|=2k. This proves the comparison.

The weighted Heilmann-Lieb theorem says the ordinary coefficients mu_k are log-concave and have contiguous positive support from zero to the maximum matching size. For any feasible k, choose a positive t making mu_k t^k a mode. Then

    Pr_{a,t}(K=k) >= mu_k t^k / [2^g sum_l mu_l t^l]
                  >= 1/[2^g(m+1)].

Thus every feasible target has inverse-polynomial mass when g=O(log N). In particular, forests, bounded-cycle-rank graphs, and a single long cycle cannot yield the sought exponential obstruction. This theorem also does not settle arbitrary graphs with g growing linearly or quadratically in N.

## 5. Status of the stronger conjecture

The stronger statement that b_k=a_k/d_k is log-concave remains unproved here. It would settle the unrestricted fugacity anti-concentration route, since d_k has only a polynomial distortion after geometric rescaling. No explicit exponentially deep interior valley was found. These absences are not proofs.

The exact checker check_shape.py exhausts all 32768 labeled unweighted graphs on six vertices and sampled 20000 integer-weight graphs each on eight and ten vertices, and 2000 integer-weight graphs on twelve vertices. No ordinary log-concavity violations appeared in those sparse/dominant-weight samples; K_12 gives the deliberate counterexample. Its results are in check_shape_results.json. These finite checks provide no universal theorem.

## 6. Literature checks and limits

Primary source https://homepages.inf.ed.ac.uk/hguo/papers/BS-simulation.pdf constructs a weighted prism graph and proves polynomial sampling for the unrestricted nonnegative graph GBS law. It bounds the prism's ordinary near-perfect/perfect matching ratio, then uses ordinary matching-size log-concavity on that prism. That is distinct from log-concavity of the colored-cardinality coefficients a_k. No fixed colored count FPRAS is inferred here.

Primary source https://www.tandfonline.com/doi/full/10.1080/03081087.2024.2436061 (New inequalities for permanents and hafnians and some generalizations, Theorem 2.3) proves subadditive hafnian norm inequalities, consistent with the elementary partition proof above. The searched source did not provide the stronger log-concavity theorem required here.

Conclusion: ordinary log-concavity and Hurwitz-stability escape routes are rigorously false; normalized submultiplicativity, initial-envelope anti-concentration, and anti-concentration for low cycle rank are proved; unrestricted fixed-cardinality anti-concentration for arbitrary interior targets remains unresolved in this analysis.
