# Fixed-cardinality positive GBS: established reductions and obstructions

Date: 2026-10-07. Scope: real symmetric, entrywise nonnegative rational matrix B; collision-free pure-state law on subsets S of prescribed even size q=2k, with weight haf(B_S)^2. The ordinary finite-bit general-graph perfect-matching FPRAS is an explicit imported assumption. No general fixed-cardinality FPRAS was proved.

## Result

There is a rigorous obstruction to the natural positive selector reduction: for 2<=q<=n-2, **no fixed B-independent nonnegative matching terminal gadget glued directly to two copies of B can universally have partition function c sum_{|S|=q} haf(B_S)^2**, for a fixed positive c. The obstruction persists even if odd-cardinality leakage states are allowed, since these cannot be used by the external loop-free B layers. The complete proof is in `colored_reduction/gadget_barrier/POSITIVE_SELECTOR_BARRIER.md`.

This is a restriction on a precise family of graph gadgets, not an impossibility of all approximation-preserving reductions. Adaptive reductions, B-dependent encodings, nonlocal constructions, signed interpolation, and a specialized Markov chain remain outside it. For odd n, the boundary q=n-1 is not covered by this proof.

Two further claims are established below: deterministic support testing with pins, and an AP sampler under a polynomial induced-perfect-matching-multiplicity promise. A coefficient audit defeats ordinary logconcavity and Hurwitz-stability arguments already on K12, but does not exhibit an exponential valley.

## Exact doubled-graph identity

With copies of B on the two layers and vertical edges of weight x,

    haf([[B,xI],[xI,B]]) = sum_{S even} haf(B_S)^2 x^(n-|S|).

Every vertical edge removes one vertex from each horizontal layer; the occupied sets of the two horizontal perfect matchings are therefore equal. Exact cardinality q requires precisely n-q vertical edges. Relative estimates of the positive polynomial at x>0 do not automatically yield relative estimates of an interior coefficient. In particular, any nonzero positive linear combination of positive-point evaluations has positive coefficients on every monomial, so cannot be an exact interior-coefficient functional.

## Deterministic support testing, including pins

Let F be forbidden vertices and H required occupied vertices. Delete F first and let N be the number of allowed original vertices. Reject immediately if H intersects F, q is odd, |H|>q, or q>N. Build an augmented graph by adding N-q labelled dummy vertices. Each dummy is adjacent to every allowed original vertex outside H; there are no dummy-dummy edges. Original-original edges are the positive support of B.

An ordinary perfect matching in this augmented graph uses exactly N-q original-dummy edges. Its remaining original-original edges form a k-edge matching covering H. Conversely any k-edge matching covering H extends to a perfect matching by pairing the unmatched original vertices with the dummy vertices. Thus ordinary deterministic perfect-matching existence decides

    sum_{|S|=q, H subset S, S disjoint F} haf(B_S)^2 > 0.

There is no need for the general colored Exact Matching algorithm at this support interface. The distinction matters: giving original edges weight B_e makes the augmented weighted PM count equal to

    (N-q)! sum_{|S|=q, H subset S, S disjoint F} haf(B_S),

which has one hafnian, not its square. The standard dummy-node cardinality reduction is recorded explicitly in Alimohammadi–Anari–Shiragur–Vuong, [arXiv:2102.02708](https://arxiv.org/html/2102.02708), Section 1.1. The pin modification and application to the squared-hafnian support are immediate consequences of the displayed bijection.

## AP sampler with bounded induced matching multiplicity

For S define h_S=sum_M w(M)=haf(B_S), and d_S=sum_M w(M)^2=haf((B elementwise-squared)_S), where M ranges over perfect matchings of B_S. Suppose an explicitly supplied R bounds the number r_S of positive-support perfect matchings for every relevant S. Positivity and Cauchy–Schwarz give

    d_S <= h_S^2 <= r_S d_S <= R d_S.

First sample a size-k matching covering H in G-F with edge weights B_e^2. The dummy reduction above and ordinary weighted PM approximate sampling implement this step. Its occupied set S has probability proportional to d_S. Then accept S with probability

    h_S^2 / (R d_S).

The exact rejection distribution has weights h_S^2 and acceptance probability at least 1/R. Both h_S and d_S are ordinary weighted PM partition functions on induced graphs, so the imported FPRAS estimates their ratio to any polynomial relative precision. This is a positive randomized oracle composition; no colored-count extraction is used.

For completeness, an approximate finite-bit implementation can allow T=O(R log(1/epsilon)) trials, estimate each ratio within multiplicative error eta=O(epsilon), use the acceptance probability estimate divided by (1+eta)R, and set each oracle failure/TV error to O(epsilon/T). On simultaneous oracle success, each accepted weight is within 1+O(eta) of its desired value. Acceptance remains at least a constant/R, the truncation failure is O(epsilon), and the union of oracle failures contributes O(epsilon). Standard rational Bernoulli implementation to error O(epsilon/T) suffices. Thus cost is poly(N,L,R,epsilon^-1). This assumes the imported weighted PM FPRAS/FPAUS, or the finite-bit positive weight gadget reduction used by the parent research note.

This promise has concrete sufficient conditions:

* If the positive-support graph has no even cycle, every induced graph has at most one perfect matching: two distinct perfect matchings would have an even alternating cycle. Then R=1 and the direct dummy graph with squared weights already implements the target law.
* If the support graph has cycle rank c=|E|-|V|+number_of_components, then R<=2^c. Fix a perfect matching M0 of an induced subgraph; M maps injectively to M symmetric-difference M0, which belongs to the binary cycle space. Its dimension is at most c. Hence c=O(log N) permits polynomial cost.
* General graphs can have exponentially or superexponentially many induced perfect matchings, so this does not remove the full fixed-cardinality obstruction.

## Positive selector barrier in brief

For a matching gadget H with terminals T, define f(X)=PM(H-X). Superposing matching witnesses for f(X)>0 and f(Y)>0 gives disjoint alternating paths whose endpoint set is X symmetric-difference Y. Switching ownership on any collection of these paths produces two further supported terminal states and preserves the product of the matching weights.

For four terminals, f(empty)>0 and f(T)>0 force positive two-terminal leakage. More quantitatively, for any fixed terminal a,

    f(empty) f(T) <= sum_{b in T minus {a}} f({a,b}) f(T minus {a,b}).

Hence an equality gadget with both desired weights >=1-epsilon and every leakage weight <=epsilon must have epsilon>=1/(1+sqrt(3)). This rules out arbitrarily accurate local equality under that normalization.

For the global selector, let terminals be physical pairs {a_i,b_i}, one endpoint in each B layer. Choose two permitted q-pair states differing by exchanging two pairs. Their superposition has four terminal paths. A same-layer path immediately produces unwanted even-even partial-pair leakage. If all four paths connect the layers, switching any two preserves even parity. Requiring all such states to remain unions of q complete pairs forces each individual path endpoint pair to be a physical pair. Switching the two removed pairs then produces a permitted-parity state with q-2 pairs, a contradiction. Nonnegative polynomial coefficients prevent this unwanted accessible state from cancelling when the gadget is glued to B disjoint-union B. This completes the fixed-selector obstruction.

## Coefficient-shape failures and unresolved route

Write a_j=sum_{|S|=2j} haf(B_S)^2. For K12,

    (a_0,...,a_6)=(1,66,4455,207900,5457375,58939650,108056025).

Because 66^2=4356<4455, ordinary logconcavity fails. For the polynomial sum a_j t^j, the fifth Hurwitz leading determinant is exactly -808578408339264245760000; thus Hurwitz stability fails as well. These are exact counterexamples, invariant under scaling B to make its spectral norm less than one.

They defeat two natural proposed shortcuts. They do **not** demonstrate an exponentially rare target size under every fugacity. The companion coefficient report proves that, with d_j=binomial(2j,j)/4^j and b_j=a_j/d_j, every ordered integer partition j=sum_i k_i satisfies b_j<=product_i b_{k_i}. The proof expands a hafnian over ordered partitions of its matching edges, applies Cauchy–Schwarz, then drops disjointness using nonnegative squared weights. In consequence, if w_j=a_j t^j and a positive t makes w_0=w_J=1 while every w_j<=1, then w_k>=d_k for 0<=k<=J and Pr_t(K=k)>=1/[2 sqrt(k)(floor(n/2)+1)] for k>=1. Taking t=min_{j>=1:a_j>0} a_j^(-1/j) supplies such a first positive anchor J. This controls the initial coefficient-envelope interval only. A general polynomial target-sector-mass theorem between arbitrary positive anchors remains unproved.

## Literature correction affecting the parent premise

[Anand–Chen–Cryan–Freifeld–Goldberg–Guo–Zhang, *Simulating Gaussian Boson Sampling on Graphs in Polynomial Time*](https://homepages.inf.ed.ac.uk/hguo/papers/BS-simulation.pdf), Theorem 1.1, already gives a polynomial classical sampler for the **variable-size unweighted graph law on all graphs**, via the same prism/doubled graph and a weighted near-perfect/perfect ratio bound. Its stated runtime is O(cbar |E| n^4 log^2(n c/epsilon)), with cbar=max(1,c), and the paper permits any c>0. It is stronger than citing only the earlier dense-graph result. It does not provide fixed-size conditioning, arbitrary rational edge weights, or arbitrary inclusion/exclusion pins in that theorem. No publication date or external proof-validation claim is made here.

For context, [Bhatnagar–Randall–Vazirani–Vigoda, *Random Bichromatic Matchings*](https://randall.math.gatech.edu/r-rb.pdf) studies a soft cardinality penalty over all matchings; its exact-sector results need additional graph conditions. [McQuillan, *Approximating Holant Problems by Winding*](https://arxiv.org/pdf/1301.2880), Section 1.3 and Proposition 5, is a relevant primary framework for positive matching-circuit expressibility. Neither supplies the missing general fixed-cardinality AP reduction.

## Verification status

The proofs above are self-contained candidate mathematical arguments, not external validation. `verify_reductions.py` passed 1,065,472 induced-support multiplicity checks on all 33,856 labelled unweighted graphs with 4, 5, or 6 vertices, and 747 pinned dummy-graph identity checks across 250 weighted instances. `verification_results.json` preserves the totals. The companion `coefficient_shape/verify_certificates.py` passed the exact K12 arithmetic certificates; the gadget report is a proof rather than a finite search. No general FPRAS was implemented, no publishing occurred, and no theorem is inferred from finite diagnostics.
