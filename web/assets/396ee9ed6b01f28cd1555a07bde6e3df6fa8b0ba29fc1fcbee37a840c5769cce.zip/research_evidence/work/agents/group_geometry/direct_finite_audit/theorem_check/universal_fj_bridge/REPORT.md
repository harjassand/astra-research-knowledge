# Universal regular-coefficient K0 bridge audit

Status: no unconditional group-specific bridge in characteristic p was established in this audit. The survey makes the implication claim, but its cited 2025 book retains an additional finiteness hypothesis in its actual theorem. Do not promote this discrepancy into either a proof of the implication or a proof that it is false.

## Primary-source comparison

1. Wolfgang Lück, *Survey on the Farrell-Jones Conjecture*, arXiv:2507.11337, printed p.4, Conjectures 2.2 and 2.3: Conj.2.2 quantifies over regular rings R and says K0(R) -> K0(RG) is bijective for torsionfree G. Conj.2.3 concerns trivial scalar idempotents for every field. The survey states that 2.3 follows from 2.2 and points to book [69], Chapter2, for further information. No proof of that particular implication is provided there. Source: https://arxiv.org/pdf/2507.11337

2. Lück, *Isomorphism Conjectures in K- and L-Theory* (Springer, 2025), Chapter2, author-hosted PDF, printed pp.53–54, Theorem2.81: rational K0(R) -> K0(RG) isomorphism and trivial idempotents in R imply trivial idempotents in RG only under one of (i) RG stably finite; (ii) R a field of characteristic zero; (iii) R a skewfield and G sofic. Printed p.54, Remark2.83 retains soficity in the prime-characteristic case, even after obtaining an integral K0 isomorphism from Conj.2.72 and the p-group condition on finite subgroups. Printed p.53, Remark2.80 identifies stable finiteness with [P]=0 => P=0 for finitely generated projectives. Source: https://him-lueck.uni-bonn.de/data/ic_projective%20class_group.pdf

3. Bartels–Lück–Reich, *On the Farrell-Jones Conjecture and its applications*, arXiv:math/0703548: printed p.8, Theorem0.12 has the same three alternatives. Printed pp.28–29, Remark5.2 and Lemma5.4 locate the decisive proof step: the augmentation and K0 hypothesis give a projective summand with zero class, and stable finiteness eliminates it. Source: https://arxiv.org/pdf/math/0703548

## Exact algebraic gap

Let A=kG. If i_*:K0(k)->K0(A) is an isomorphism, its inverse is augmentation ε_*. For an idempotent e, [eA]=ε(e)[A]. Replacing e by 1-e reduces to ε(e)=0, so [eA]=0. The Grothendieck-group relation yields eA ⊕ A^n ≅ A^n after adding a complement to a finitely generated projective stabilizer. This does not itself make eA zero. Stable finiteness is exactly what forbids absorption of a nonzero projective summand.

Likewise, if XY=I in M_n(A), E=I-YX is idempotent and its projective module already has zero K0 class because A^n ≅ A^n ⊕ im(E). Thus ordinary K0 detection cannot alone rule out a failed one-sided inverse.

Quantifying over all regular coefficient rings is stronger than the single-field premise of these theorems. The inspected sources do not supply an argument exploiting that stronger quantifier. Accordingly, the correct audit conclusion is "unconditional characteristic-p bridge not verified," rather than claiming a logical nonimplication for group rings.

An attempted mixed-characteristic lift also needs care: a lift modulo p can land in the p-adic completion of W(k)G with growing group support, rather than in the finite-support group ring W(k)G covered by the coefficient hypothesis. No finite-support lifting theorem was established here.

Downloaded source: projective.pdf; extracted plain text: projective.txt, in this directory. Mathematical glyphs in the extracted publisher PDF are malformed, but the prose hypotheses and theorem/remark numbering are legible.
