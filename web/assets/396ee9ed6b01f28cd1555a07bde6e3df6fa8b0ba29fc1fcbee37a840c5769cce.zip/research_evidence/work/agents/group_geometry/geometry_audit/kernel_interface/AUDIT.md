# Common-kernel interface audit

Scope: independently reconstruct the finite-product quantifiers, the N06 explicit word, and the extension to injective maps into sofic or ordinary finite-dimensional linear targets. Sources read: hyperbolic_sofic.txt, nonsofic_geometry_audit.txt, N06.txt, and the connected-core/explicit-word sections of geometry_audit/frontier_algebra.txt. The incidence/rank/curvature inputs are assumed here, rather than independently recertified. No fatal defect was found in this interface.

## Exact quantifiers

Let C be a class closed under finite direct products, and let S={h_1,...,h_M} be a nonempty finite set of nonidentity elements of H. Suppose

    for every K in C and every homomorphism f:H -> K,
    some h_j is in ker(f).

Then there is one index j_0 such that h_j0 is in the kernel of every homomorphism from H to every member of C. If the conclusion failed, for each j choose K_j in C and f_j:H -> K_j with f_j(h_j) != 1. The product map f=(f_1,...,f_M) has target product_j K_j in C and preserves every h_j, contradicting the premise. This is exactly the quantifier strengthening claimed for the finite rectangle family. It identifies no particular rectangle and supplies no procedure to find j_0.

Finite-product closure of sofic groups can be reconstructed directly: take sufficiently accurate permutation models of the coordinate finite sets and let each product tuple act on the Cartesian product of the finite permutation sets. Multiplication error is at most the sum of coordinate errors. A nonidentity tuple has a nonidentity coordinate, and the product permutation's fixed fraction is no greater than that coordinate's fixed fraction. Thus the common-sofic-kernel claim needs no quotient closure or stability theorem.

## Core splitting and the explicit word

The stated splitting replaces O by O_b (one per Cartesian block), V by V_u (u in [r]), and W by W_v (v in [r]). Every triangle attaches because its L edge has endpoint V_u, its R edge has endpoint W_v, and x_iuv joins V_u to W_v. For N>0 the x edges connect all V_u,W_v; every O_b has L/R edges into that connected component. Hence the split complex is connected. Reidentifying these vertices adds

    (B-1)+(r-1)+(r-1) = B+2r-3

free generators, so G = H * F_(B+2r-3). For r>=2 this gives a free generator t. The rectangle's nonidentity status transfers to the split core by the free-factor embedding. The triangle and rectangle interface likewise transfers using the usual based-edge loops.

The full core source gives an explicit original-edge choice: fix b_0; take the core spanning tree consisting of all L_(b_0,u,0), all R_(b_0,v,0), and L_(b,1,0) for b!=b_0. After collapsing only L_(b_0,1,0) and R_(b_0,1,0) in the original complex, t=L_(b_0,2,0)^(-1) is a free generator. For a rectangle w_j starting at V_u, the actual based word is h_j=L_(b_0,u,0) w_j L_(b_0,u,0)^(-1), of original-edge length at most six. It lies in the embedded core factor H. This distinction corrects the shorter four-letter length available in the collapsed-core alphabet; the original-edge bound below uses six.

Let u_j=t^j h_j t^(-j), W_1=u_1, W_j=[W_(j-1),u_j]. In H*<t>, the conjugate subgroups H_j=t^j H t^(-j) freely generate their free product: a reduced product of nonidentity elements from consecutively distinct H_j expands to an H*<t> normal form with nonzero intervening t powers. Inductively, W_(j-1) is a nonidentity element of *_(k<j) H_k, whereas u_j is a nonidentity element of the new factor H_j. Their commutator is a reduced four-syllable word in (*_(k<j) H_k)*H_j, so W_j != 1.

For every k<=j, W_j belongs to the normal closure of h_k in G: killing h_k kills W_k, and all later commutators stay identity. Thus W_M belongs to the intersection of the normal closures of every h_j. Any map G -> K in the target class restricts to a map on H killing some h_j, hence kills W_M. This proof of W_M being a common kernel word uses the weaker 'some rectangle per map' premise directly; it does not need to locate the common rectangle supplied by the finite-product argument.

For the supplied original-edge formula, |h_j|<=6 and |t|=1. Unreduced lengths satisfy L_1<=8 and L_j<=2L_(j-1)+4j+12. Therefore

    L_j <= 16*2^j - 4j - 20 <= 16*2^j.

A straight-line representation with shared powers p_j=p_(j-1)t and inverse references has O(M) productions. This is a formula conditional on the acquired finite presentation/list of rectangles. It is not an emitted numerical presentation or word in this run. Without power sharing, building each t^j separately can cost O(M^2).

## Exact target extension and boundaries

Every homomorphism G -> S to a sofic group kills the common rectangle (or the explicit W_M), so no such homomorphism is injective. Every homomorphism G -> GL_n(F), for a field F and finite n, has finitely generated image. Malcev's theorem makes that image residually finite, hence sofic. Consequently the same common-sofic-kernel element is killed by every ordinary finite-dimensional linear representation over every field; in particular no faithful such representation exists. Factoring through the image avoids any unnecessary countability assumption on GL_n(F).

This does NOT establish failure of linear soficity, whose rank-metric ultraproduct targets form a larger class. Nor does it exclude faithful infinite-dimensional linear actions: every group has a faithful left-regular action on the free vector space with basis G. 'Linear target' must mean GL_n(F) with finite n here. A generic claim about approximate assignments or arbitrary set maps is also unsupported: the kernel argument concerns genuine homomorphisms.

## Primary sources checked for imported target facts

- Pestov, *Hyperlinear and sofic groups: a brief guide*, Theorem 3.5 and Example 4.2: https://arxiv.org/html/0804.3968v8 . The finite-product fact above was reconstructed from the finite-set definition rather than accepted from a cited sentence.
- Nica, *Linear groups - Malcev's theorem and Selberg's lemma*, introductory Malcev theorem and proof in section 3: https://arxiv.org/pdf/1306.2385v1 . The theorem permits every field.
- Arzhantseva--Paunescu, *Linear sofic groups and algebras*: https://arxiv.org/abs/1212.6780 . Its target notion is different from ordinary finite-dimensional linearity; nonsoficity does not reverse the stated implication from sofic to linear sofic.

The memory quick pass located only prior workflow context; no memory-derived mathematical premise was used. Ordinary written reconstruction and these imported facts support the interface verdict; they do not independently certify the incidence construction or external novelty.
