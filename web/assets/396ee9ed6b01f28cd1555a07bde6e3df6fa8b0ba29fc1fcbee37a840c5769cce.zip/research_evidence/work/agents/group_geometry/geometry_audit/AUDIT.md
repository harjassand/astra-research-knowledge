# Independent geometry, incidence, and target-interface audit

Date: 2026-10-07. Scope: N06, N27, the complete supplied `hyperbolic_sofic`, `groups_approximation`, and `nonsofic_geometry_audit` texts; pinned OA252 `construction.tex`; the proposed deterministic spectral refinement; and the simplex interpolation replacement.

**Verdict:** no fatal geometry, incidence, finite-sofic-interface, or common-kernel defect found. This is an ordinary written reconstruction, not formal replay, external review, or materialization of the astronomical presentation. The new deterministic spectral argument genuinely eliminates the previously unacquired affine-map choice, conditional on the explicitly imported Gupta–Taranchuk spectral theorem. The simplex interpolation formula also passes the denominator and wrap checks.

## 1. Incidence and link inputs

The LUW coordinate labels are actual affine lines:

`(t,b-at,c-bt,d-ab+a^2 t,e-ac+ab t)`.

Distinct labels give distinct lines: their normalized direction recovers `a,b`, and their `t=0` intercept then recovers `c,d,e`. A point and a prescribed `a` determine a unique incident label. The graph is simple and q-regular. Matching a point to the line with `a=t` is bijective; each line has exactly one point with `t=a`. Accordingly every point's other neighboring labels have q-1 distinct matched marks.

The short-cycle argument survives characteristic two. For a putative cycle with s=2,3,4 labels, its nonzero line increments tau satisfy the five closure equations against `1,a,a^2,b,ab`. Adjacent a-values differ. For s=3, Vandermonde forces every increment to vanish. For s=4: three a-values force the singleton increments to vanish; four distinct values make the kernel of the independent rows tau and a*tau exactly span{1,a}, so b=A+B*a; and alternating two values force equal b-values at opposite positions, also giving b=A+B*a. Every intersection then has first coordinate B, contradicting a nonzero increment on each line. No excluded integer-parity operation is hidden in this reasoning.

At a fixed regular point each label belongs to one Cartesian block. At an x-direction this prevents two link edges projecting to the same incidence. At an L-direction, fixing its label fixes the shifted v modulo s_b, and s_b>=r makes the allowed v unique. The W proof uses t_b>=r. Thus the link map is a genuine immersion, including its oriented edge germs.

At O each block link is simple complete bipartite: an L/R pair determines one coordinate pair and hence one label. No omitted parallel corners occur. Every reduced O cycle has at least four corners.

A same-label link path projects to a positive incidence closed walk reduced at all internal vertices. Its seam may reverse, but a shortest positive subwalk with repeated endpoints is a simple cycle: length one would be a loop, and length two an internal reversal. This establishes the stated same-label distance even without cyclic reduction at the projected seam.

For h=5, the required hyperbolic triangle angles are alpha=21pi/40 and beta=9pi/40. They satisfy alpha+2beta=39pi/40<pi, 4alpha=2.1pi>2pi, and 10beta=2.25pi>2pi. The old beta=9pi/50 would give only 1.8pi at girth ten and would not suffice; N27 explicitly changes it. Rectangle turns compare distinct same-label directions and therefore exceed pi. The standard link and local-geodesic criteria yield locally CAT(-1), contractible CAT(-1) cover, torsion-free hyperbolic fundamental group, and nonidentity rectangles. [Bridson–Haefliger original text](https://webhomes.maths.ed.ac.uk/~v1ranick/papers/bridsonhaefligerx.pdf).

## 2. Finite-set sofic and common-kernel interface

The finite set includes identity, edge-loop elements, needed inverse elements, triangle products, and rectangle prefixes. Approximate `L*x=R` gives triangle error <eta. Approximate `1*1=1` gives distance(phi(1),id)<eta, and `a*a^-1=1` gives inverse-substitution error <2eta. Two inverse substitutions and three prefix multiplications give rectangle evaluation distance <7eta from phi(w). Nonidentity-word separation adds eta, giving evaluated fixed-point fraction <8eta. These errors are independent of the model dimension. This is exactly the interface furnished by [Arzhantseva–Paunescu, Definition 2.2](https://arxiv.org/html/1410.2626v2#S2).

There is no quantifier reversal error in the common-kernel conclusion. If every word in the finite rectangle set survived some homomorphism to some sofic target, the finite product of those maps would preserve all words. Finite products are sofic: use Cartesian products of finite permutation models, sum their multiplication-error budgets, and observe that a nonidentity coordinate bounds the product fixed-point fraction. The rank obstruction rules out the product map. Therefore one fixed nonidentity rectangle is killed by every sofic-target homomorphism.

The connected-core free-product splitting and explicit common word also pass. The core has B+2r vertices and is connected through its complete bipartite X graph. Identifying its O, V, and W vertex families adds B+2r-3 free generators. Inside H*<t>, the factors t^j H t^-j freely generate their free product. Thus W1=u1 and Wj=[W(j-1),uj] are nonidentity by reduced normal forms, and W_M lies in every normal closure of h_j. All sofic-target maps kill it. The source's |h_j|<=6 gives expanded-length recurrence L1<=8, Lj<=2L(j-1)+4j+12, hence L_M<=16*2^M-4M-20. An O(M)-node SLP is valid with shared powers and inverses. Details are independently checked in `kernel_interface/AUDIT.md`.

This rules out injective homomorphisms into sofic groups and ordinary finite-dimensional linear groups over commutative fields. A finitely generated linear image is residually finite, so a common finite residual element is killed by every such representation. The same follows from its soficity. It does not rule out rank-metric linear-sofic targets or infinite-dimensional linear targets; every group has a faithful regular infinite-dimensional linear action.

## 3. Explicit failure of the naive linear-sofic transfer

For r>=5 and any D, set X_uv=(a_u+b_v)I_D over C, with distinct positive a_u,b_v. All blocks are invertible, every nondegenerate rectangle has rank(I-W)=D, but the block-array rank is exactly 2D. Indeed its scalar coefficient array is a*1^T+1*b^T, whereas the rectangle cross-product difference is (a_u-a_u')*(b_v'-b_v), which is nonzero. This falsifies any attempted lower bound rank(Y)>=rD/2 from full rectangle rank separation. It is a local counterexample to the replacement lemma, not a whole-group linear-sofic approximation. Likewise exp(it)I_D makes arbitrarily small unitary norm error while its difference has full rank; triangle norm defects cannot be charged as permutation support errors.

## 4. Deterministic spectral certificate: passes

The [Gupta–Taranchuk primary paper](https://arxiv.org/html/2207.04629v2) states that D(k,q) is connected for k<=5 and odd q (introduction) and proves Theorem 1.4: the second adjacency eigenvalue of CD(5,q) is <=2sqrt(q). Hence for our fixed odd q, CD(5,q)=D(5,q), and its incidence matrix M has simple top singular value q and every other singular value <=2sqrt(q). The bipartite adjacency spectrum is the positive and negative singular-value pairing. There is no additional q-eigenspace on which centering fails.

The source graph equations exactly match ours under point coordinates `(t,-y,-z,w,v)` and label coordinates `(a,b,c,-d,-e)`.

Let P be the matching permutation from marks to labels. For any mark subset B, put chi=1_B, rho=|B|/m, and x=chi-rho*1. Then P preserves the constant vector and its orthogonal complement, ||x||^2=N(1-rho), and the punctured degree vector is

`d=(MP-I)chi`, with mean `mu=(q-1)rho`.

Consequently

`||d-mu*1|| <= (2sqrt(q)+1)*sqrt(N(1-rho))`.

Each d_z<4r^2 contributes more than (mu-4r^2)^2 to the squared deviation. Thus

`|E|/m <= (2sqrt(q)+1)^2*rho*(1-rho)/(mu-4r^2)^2`.

This holds for every B, not only randomly moved grids. U=identity is therefore certified for B=S^5. At q=2^61-1 and r=1,200,000, exact rational arithmetic with the integer square-root upper bound gives |E|/m<3.082279392e-13, while the required bound is 4.166666667e-7. It gives Delta/m>0.9999996301, versus the old lower bound 0.2. Script `spectral_budget.py` also reproduces the 59 Lucas–Lehmer steps. The theorem is an imported published spectral statement; this audit checks its exact interface rather than reconstructing all its character-sum proof.

The exceptional set can now be specified without selecting or scanning an unknown affine map. At x=(t,y,z,w,v), the matched point of the incident label with coordinate a is

`(a, y+a(t-a), z+(y+at)(t-a), w+a^2(a-t), v+a(y+at)(a-t))`.

The a=t term is x and is punctured. For B=S^5, d_x is exactly the number of a in S, a!=t, for which the other four displayed coordinates belong to S. This is a completely deterministic finite predicate for E. Emitting all blocks/edges/triangles remains astronomical.

## 5. Simplex replacement: interpolation passes

Let s=floor((q-2)/2), B={a in Z_{≥0}^5: |a|<=s}, and N=binom(s+5,5). All its coordinates are <q, so they represent distinct field points. Define

`f_a(X)=binom(s-sum X, s-|a|) * product_j binom(X_j,a_j)`.

Here every binomial is its falling-factorial polynomial divided by its factorial. Those factorials are invertible because all degrees are <=s<q. The total degree is exactly <=s.

For b in B use six integer barycentric counts n0=s-|b|, n_j=b_j, k0=s-|a|, k_j=a_j. Both vectors have nonnegative entries <=s and total s. If b!=a, equal totals force some n_j<k_j, hence one binomial factor is zero; if b=a every factor is one. Thus f_a(b)=delta_ab. No field-wrap issue occurs because these evaluated counts are all ordinary integers between zero and s<q.

For odd q, 2s=q-3<q-1. Therefore every entry of H=f*f^T restricts to affine-line degree <q-1 and has full-line sum zero in characteristic q. Puncturing at each matching mark gives the exact rank-one isolation certificate. N is the dimension of degree-<=s polynomials in five variables, so it saturates that precise interpolation dimension bound. This does not claim optimality over arbitrary other certificate classes. Its asymptotic density is 1/3840, about 26 times the old 10^-5 grid density. The spectral bound above applies to this subset without modification.

## 6. New parameter and stronger rank-reduction checks

The supplied complete-factorization prime certificates and rational budgets in `../spectral_certificate.py` were reread and rerun. The conservative simplex instance q=17592186044423, r=32768 passes: |E|/m<=2.234594e-7<1/(2r), Delta/m>0.126011>1/8, and the common tolerance 1/(100rq) charges at most 0.085334m. Its ambient point count has 67 digits and its triangle upper bound has 85 digits.

The optional stronger factor is valid. The integer-minor argument gives d' >= d*(1-log(r)/(2log(q))). If q>r^3, then d'>=5d/6. For any such fixed theta, the permutation rank lower bound is

`rank_Fq(Y)/D >= theta*r^2/(2r-1+(r-1)^2*lambda)`.

At lambda=0 this is at least theta*r/2. Its loss from lambda=0 is at most theta*r^2*lambda/4, because `(r-1)^2/(2r-1)^2<=1/4`. Thus the correctly generalized obstruction is

`Delta_theta=N*theta*r/2-2m-r|E| <= r^2*(S_reg*delta + theta*N*lambda/4)`.

For q=8796093022237, r=19000, theta=5/6, q>r^3 is true. The exact script gives Delta_theta/m>0.0613891 and the common tolerance charge <0.049480m. Its ambient point count has 65 digits and its triangle upper bound has 83 digits. No slope factor is missing: theta*r^2/4 is exactly the required rectangle-loss coefficient. The script uses this coefficient correctly.

The primality certificates have complete factorizations of q-1 and witness 5, check primality of every factor by trial division, verify 5^(q-1)=1 modulo q, and check gcd(5^((q-1)/p)-1,q)=1 for every prime p dividing q-1. This is the full Lucas/Pocklington criterion and is sufficient for the stated q values.

## Verification limits

The supplied candidate-source files, exact pinned construction, and primary sofic/spectral interfaces were freshly read. Arithmetic was rerun. No incidence table, Cartesian block ledger, full presentation, or enormous W_M expression was materialized, and no Lean proof was executed. No statement of novelty, nonhyperlinearity, failure of linear soficity, property(T), or a group-ring counterexample follows from this audit. The prior memory pass supplied only the instruction to preserve this validation scope; no mathematical lemma was taken from memory.
