# Information-controlled quantum broadcasting

Read `information_controlled_broadcasting.md` for the complete theorem and analytic proof. It includes the tracial comparator, exact reference correction, flagged spectral reduction, compatible smoothing, and explicit constant calculation.

The main bound uses the **capacity of the whole family**, the supremum over all finite priors, not the Holevo information of a single prescribed ensemble. It concerns one uniform measure-and-prepare reconstruction channel.

`check_lemmas.py` runs reproducible NumPy diagnostics for selected matrix lemmas; `diagnostic_results.json` records the executed results. Run `python check_lemmas.py`. These floating-point checks do not certify the universal theorem.

`provenance.json` records accessed revisions, attribution, and verification limits. No external review, proof-assistant certification, repository modification, or publication occurred. Historical priority and historic-scale significance remain unestablished.
