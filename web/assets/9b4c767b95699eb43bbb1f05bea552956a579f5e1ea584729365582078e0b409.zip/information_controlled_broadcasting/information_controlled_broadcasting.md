# Information-controlled stability of quantum broadcasting

**Research note — 9 October 2026.**

This note gives an analytic argument, not a proof-assistant certificate or an externally reviewed paper. Historical priority and historic-scale significance are not established. The source attribution and verification scope are recorded at the end.

## 1. Statement

Let \(\mathcal E\) be a nonempty family of density matrices on a finite-dimensional complex Hilbert space \(H\). Put
\[
T(\rho,\sigma)=\frac12\|\rho-\sigma\|_1.
\]
Define its **two-output broadcasting error** and **classical reconstruction error** by
\[
\begin{aligned}
b(\mathcal E)
&=\inf_{\mathcal B\text{ CPTP}}
  \max_{i=1,2}\sup_{\rho\in\mathcal E}
  T(\mathcal B_i(\rho),\rho),\\
e(\mathcal E)
&=\inf_{\Lambda\text{ EB}}\sup_{\rho\in\mathcal E}
  T(\Lambda(\rho),\rho).
\end{aligned}
\tag{1}
\]
Here \(\mathcal B:M(H)\to M(H\otimes H)\), \(\mathcal B_i\) are its two marginal channels, and EB means a completely positive trace-preserving measure-and-prepare channel. The two broadcast outputs need not be independent. Each channel is defined on the full input matrix algebra and is independent of the unknown member of \(\mathcal E\).

The relevant information bound is the **Holevo capacity of the family**, not the Holevo information of one prescribed prior:
\[
C(\mathcal E)=\sup_{\substack{m<\infty,\ p_j\ge0,\ \sum_jp_j=1\\
                         \rho_j\in\mathcal E}}
\left[S\!\left(\sum_jp_j\rho_j\right)-\sum_jp_jS(\rho_j)\right].
\tag{2}
\]
All logarithms and entropies are natural.

### Theorem 1 — Information-controlled stability

For every finite-dimensional family \(\mathcal E\), writing \(b=b(\mathcal E)\) and \(C=C(\mathcal E)\),
\[
\boxed{
 e(\mathcal E)\le
 \min\left\{1,\ 256\sqrt{\frac{C+1}{\log(1/b)}}\right\}
 \qquad (0<b<1).
}
\tag{3}
\]
If \(b=0\), then \(e(\mathcal E)=0\). Conversely,
\[
 b(\mathcal E)\le e(\mathcal E).
\tag{4}
\]
The constant is deliberately loose; no optimality is asserted.

In particular, for an arbitrary sequence of finite-dimensional experiments, with no bounds on dimension or number of states,
\[
\sup_n C(\mathcal E_n)<\infty
\quad\Longrightarrow\quad
\left[b(\mathcal E_n)\to0\iff e(\mathcal E_n)\to0\right].
\tag{5}
\]
The stronger sufficient condition
\[
 b_n\to0,\qquad C(\mathcal E_n)=o\!\left(\log(1/b_n)\right)
\tag{6}
\]
also implies \(e(\mathcal E_n)\to0\).

Equivalently, a family whose classical reconstruction error is at least \(\varepsilon>0\) satisfies
\[
\boxed{
 b(\mathcal E)\ge
 \exp\!\left[-\frac{65536\,[C(\mathcal E)+1]}{\varepsilon^2}\right].
}
\tag{7}
\]
Thus nonvanishing nonclassical reconstruction error forces an information cost for increasingly accurate broadcasting.

The proof below uses the standard quantum substate theorem, data processing for the sandwiched Rényi divergence at order two, elementary finite-dimensional channel theory, and explicitly reconstructed arguments from the cited Astra records. No new theorem claimed in the OpenAI mathematics release is a premise.

## 2. A common comparator on any finite tracial algebra

A finite tracial algebra here means a finite direct sum of full matrix algebras \(\mathcal A\), equipped with a faithful trace \(\tau\) satisfying \(\tau(1)=1\). Its real Hermitian space has inner product \(\langle A,B\rangle_\tau=\tau(AB)\). Adjoint symbols in this section refer to this inner product. A channel on relative densities is CP and \(\tau\)-preserving. It is self-compatible if a CP, \(\tau\otimes\tau\)-preserving map has both \(\tau\)-marginals equal to it.

All superoperator inequalities in this section are **Hilbert-space quadratic-form inequalities**, not completely positive order.

### Lemma 2 — Nonreversible tracial comparison

If \(L:\mathcal A\to\mathcal A\) is CP, unital, \(\tau\)-preserving and self-compatible, there is a finite POVM \((E_y)\) in \(\mathcal A\) such that
\[
\Psi(A)=\sum_y\frac{\tau(E_yA)}{\tau(E_y)}E_y
\tag{8}
\]
satisfies
\[
0\preceq\Psi\preceq I,
\qquad
I-\Psi\preceq8\left(I-\frac{L+L^\dagger}{2}\right).
\tag{9}
\]
Zero effects are omitted. The same POVM works on the entire Hermitian space.

**Proof.** We first prove the reversible comparison used in the argument. Suppose \(P\) is also self-adjoint. Unitality, trace preservation and the Schwarz inequality imply that \(P\) is an \(L^2(\tau)\) contraction. Select an orthonormal basis \(A_1,\ldots,A_m\) of its traceless eigenspaces with
\[
P A_i=\lambda_i A_i,
\qquad |\lambda_i|>1/\sqrt2.
\]
If \(m=0\), use \(\Psi(A)=\tau(A)1\). Assume henceforth that \(m>0\).

Symmetrize a broadcaster \(\mathcal B\) for \(P\), and write \(\zeta=\mathcal B(1)\). Its two reference marginals equal \(1\). The real symmetric matrix
\[
T_{ij}=(\tau\otimes\tau)\bigl[\zeta(A_i\otimes A_j)\bigr]
\]
satisfies \(T\preceq I_m\), because for \(A(v)=\sum_i v_iA_i\),
\[
0\le(\tau\otimes\tau)\bigl[\zeta(A(v)\otimes1-1\otimes A(v))^2\bigr]
 =2\|v\|^2-2v^{\mathsf T}Tv.
\tag{10}
\]

Start with randomized spectral measurements. If \(A_i=\sum_a aP_{i,a}\), put
\[
 E^{(0)}_{i,a}=P_{i,a}/m,
 \qquad z_j^{(0)}(i,a)=ma\,1_{i=j}.
\]
Then \(\sum_y z_i^{(0)}(y)E_y^{(0)}=A_i\) and the reference second-moment matrix is \(C_0=mI_m\). Recursively define
\[
\begin{aligned}
E^{(n+1)}_{y,z}&=\mathcal B^\dagger(E_y^{(n)}\otimes E_z^{(n)}),\\
z_i^{(n+1)}(y,z)&=\frac{z_i^{(n)}(y)+z_i^{(n)}(z)}{2\lambda_i}.
\end{aligned}
\tag{11}
\]
These are finite POVMs. Their operator first moments remain \(A_i\), since
\(\mathcal B^\dagger(A_i\otimes1)=P^\dagger(A_i)=\lambda_iA_i\), and similarly in the other output.

Let \(D=\operatorname{diag}(\lambda_i)\). Expanding the estimator products, using the reference marginals for the two same-output terms and exact first moments for the two cross-output terms, gives the full matrix identity
\[
 C_{n+1}=\frac12D^{-1}(C_n+T)D^{-1}.
\tag{12}
\]
In particular, output correlations have not been discarded. Set
\[
\mathcal L(M)=\tfrac12D^{-1}MD^{-1},
\qquad H=(2D^2-I_m)^{-1}.
\]
The congruence \(\mathcal L\) preserves order, including for mixed signs of the eigenvalues, and \(H=\mathcal L(H+I_m)\). Consequently
\[
 C_n\preceq H+\mathcal L^n(C_0-H)=H+o(1)I_m.
\tag{13}
\]
The last equality follows because every \(2|\lambda_i\lambda_j|>1\).

For each POVM form its canonical map \(\Psi_n\) as in (8). For any traceless Hermitian \(A\), put
\[
p_y=\tau(E_y^{(n)}),\quad
u_A(y)=\frac{\tau(E_y^{(n)}A)}{p_y},\quad
\beta_i=\tau(AA_i).
\]
Exact first moments imply \(\mathbb E[\nu_Az_i^{(n)}]=\beta_i\). Thus ordinary scalar regression gives, for every real vector \(v\),
\[
 \tau(A\Psi_n(A))\ge 2v^{\mathsf T}\beta-v^{\mathsf T}C_nv.
\tag{14}
\]
This holds for every \(A\) with the same map \(\Psi_n\), not only for \(A\) in the selected eigenspaces.

Canonical maps form a compact set on the fixed algebra. Indeed, they are first and second moments of probability measures on the compact state-density space \(\{D\ge0:\tau(D)=1\}\), with barycenter \(1\). These moments lie in a compact finite-dimensional convex hull. Carathéodory's theorem supplies a finite ensemble for every limit. Take a convergent subsequence \(\Psi_n\to\Psi\) in (14), and choose \(v=H^{-1}\beta\). It follows that
\[
 \tau(A\Psi(A))\ge
 \sum_i(2\lambda_i^2-1)\tau(AA_i)^2.
\]
Identity is fixed and trace preservation removes its cross terms. We have therefore proved
\[
 \Psi\succeq(2P^2-I)_+,
 \qquad I-\Psi\preceq2(I-P^2)\preceq4(I-P).
\tag{15}
\]
The spectral positive part in this formula is not claimed to be a physical channel.

For the original, possibly nonreversible \(L\), its tracial adjoint \(L^\dagger\) is again CP, unital and \(\tau\)-preserving. The map \(P=L^\dagger L\) is self-adjoint and self-compatible: postprocess both outputs of a broadcaster for \(L\) by \(L^\dagger\). Apply (15), then use
\[
 I-L^\dagger L\preceq2\left(I-\frac{L+L^\dagger}{2}\right),
\]
which is exactly \((I-L)^\dagger(I-L)\succeq0\). This proves (9). Finally the map (8) is unital, trace-preserving, self-adjoint and positive on \(L^2(\tau)\). Its contraction property gives \(\Psi\preceq I\). \(\square\)

## 3. Exact correction of an approximately preserved reference

### Lemma 3 — Reference correction

Let \(\nu,\omega\) be density matrices in a finite matrix algebra or direct sum thereof, with \(\omega\) faithful, and let \(\delta=T(\nu,\omega)\). There is an explicitly specified CPTP map \(R\) with \(R(\nu)=\omega\) such that, for every state \(\theta\le K\nu\),
\[
 T(R(\theta),\theta)\le\sqrt{K\delta}+\frac{K\delta}{2}.
\tag{16}
\]

**Proof.** Set
\[
 C_0=\nu+(\omega-\nu)_+,\quad
 A=\omega^{1/2}C_0^{-1/2},\quad
 D_0=\omega-A\nu A^*,\quad p=\operatorname{Tr}D_0.
\tag{17}
\]
Then \(C_0\ge\nu,\omega\), \(\operatorname{Tr}C_0=1+\delta\), \(A^*A\le I\), and
\[
D_0=A(C_0-\nu)A^*\ge0,\qquad 0\le p\le\delta.
\]
For \(p>0\) define
\[
 R(X)=AXA^*+\operatorname{Tr}[(I-A^*A)X]\,D_0/p.
\tag{18}
\]
For \(p=0\), replace \(D_0/p\) by any fixed density matrix, for example \(\omega\). This retains trace preservation on all inputs, including inputs outside the support of \(\nu\). Both formulas are CPTP and satisfy \(R(\nu)=\omega\).

The square-root trace inequality gives
\[
\begin{aligned}
\|(A-I)\nu^{1/2}\|_2^2
&\le\|(A-I)C_0^{1/2}\|_2^2\\
&=\|\omega^{1/2}-C_0^{1/2}\|_2^2
\le\operatorname{Tr}(C_0-\omega)=\delta.
\end{aligned}
\tag{19}
\]
Consequently \(\|(A-I)\theta^{1/2}\|_2^2\le K\delta\). Expanding \(A\theta A^*-\theta\) and applying Schatten Hölder gives trace norm at most \(2\sqrt{K\delta}\). The replacement part in (18) has trace at most \(Kp\le K\delta\). Taking half the sum proves (16). \(\square\)

The correction uses only \(\nu\) and \(\omega\); it is not chosen separately for different \(\theta\).

## 4. A dimension-free two-state estimate

Write
\[
f(\rho,\sigma)=\|\sqrt\rho\sqrt\sigma\|_1,
\qquad a(\rho,\sigma)=\operatorname{Tr}(\sqrt\rho\sqrt\sigma),
\qquad \Delta=f-a.
\]
Here \(f\) is root fidelity. Both \(f\) and \(a\) increase under CPTP maps. Affinity monotonicity follows from Lieb's joint concavity and a unitary twirl proof of monotonicity under partial trace. We also use
\[
\|\sqrt X-\sqrt Y\|_2^2\le\|X-Y\|_1
\tag{20}
\]
for positive matrices, and \(T(\rho,\sigma)\le\sqrt{1-f(\rho,\sigma)^2}\) for states.

Define, for \(0\le b\le1\),
\[
 h(b)=\min\left\{1,\inf_{\ell\in\mathbb Z_{\ge0}}
       \left[\ell b+\sqrt{2\log2}\,2^{-\ell/2}\right]\right\},
\qquad
 \gamma(b)=\min\{1,2\sqrt{2h(b)}\}.
\tag{21}
\]
Thus \(h(0)=\gamma(0)=0\).

### Lemma 4 — Broadcasting controls pair affinity gaps

If a broadcaster has marginal error at most \(b\) on \(\rho\) and \(\sigma\), then
\[
 \Delta(\rho,\sigma)\le\gamma(b).
\tag{22}
\]
For \(0<b\le1\),
\[
 h(b)\le3b\log(e/b),\qquad
 \gamma(b)\le2\sqrt6\,[b\log(e/b)]^{1/2}.
\tag{23}
\]

**Proof.** Symmetrize the broadcaster and iterate it in a binary tree of depth \(\ell\). Its \(k=2^\ell\) leaf marginals differ from the respective input by at most \(\ell b\), by trace contraction and telescoping.

Give the two inputs equal prior probability and call their label \(X\). Sequentially measure the leaves. Conditional on each previous classical history, let \(p_0,p_1\) and \(\theta_0,\theta_1\) be the label probabilities and the states at the next leaf. Put \(\bar\theta=p_0\theta_0+p_1\theta_1\) and
\[
 v=\sum_xp_xT(\theta_x,\bar\theta)
  =2p_0p_1T(\theta_0,\theta_1).
\]
Choose a binary Helstrom measurement distinguishing \(\theta_0\) and \(\theta_1\). For its outcome \(Y\), classical Pinsker and Jensen give
\(I(X:Y\mid\text{history})\ge2v^2\).
The classical information chain rule bounds the sum of these conditional informations by \(H(X)=\log2\). Therefore the average of \(v\), over a uniformly chosen leaf and the corresponding histories, is at most \(\sqrt{\log2/(2k)}\).

For each chosen leaf, simulate the earlier measurements and prepare its conditional mean state instead of retaining its quantum state. This is an EB channel. Averaging the chosen leaf gives average two-state reconstruction error, relative to the tree leaf marginals, at most \(\sqrt{\log2/(2k)}\). The worst of the two input errors is at most twice this. Including the tree error proves an EB pair error of at most
\(\ell b+\sqrt{2\log2/k}\).

If \(\Lambda=P\circ M\) is this measurement-and-preparation channel, data processing and equality of affinity and root fidelity for classical distributions give
\[
 a(\Lambda\rho,\Lambda\sigma)
 \ge a(M\rho,M\sigma)=f(M\rho,M\sigma)\ge f(\rho,\sigma).
\]
If its error on each state is at most \(q\), (20) and Hilbert-space Cauchy–Schwarz yield
\[
 |a(\Lambda\rho,\Lambda\sigma)-a(\rho,\sigma)|\le2\sqrt{2q}.
\]
Taking the infimum in \(\ell\) proves (22). In (23), take
\(\ell=\lceil2\log_2(1/b)\rceil\); the endpoint \(b=1\) is harmless. \(\square\)

## 5. Uniform reconstruction for dominated families

### Lemma 5 — The dominated-family bound

Suppose \(\sigma\) is faithful, \(\sigma\in\mathcal F\), and every \(\rho\in\mathcal F\) satisfies \(\rho\le K\sigma\), where \(K\ge1\). If one broadcaster has error at most \(b\) on \(\mathcal F\), then
\[
\boxed{
 e(\mathcal F)\le g_K(b):=
 \min\{1,32K^{33/32}[b\log(e/b)]^{1/32}\}.
}
\tag{24}
\]
Set \(g_K(0)=0\). No commutation, unitality, reversibility or lower domination is assumed.

**Proof.** We first obtain a common spectral pinching with a retained classical flag. For each \(\rho\), let
\[
 X=\sigma^{-1/2}(\sigma^{1/2}\rho\sigma^{1/2})^{1/2}\sigma^{-1/2}.
\]
Then
\[
 X\sigma X=\rho,\qquad 0\le X\le\sqrt K I.
\]
Choose a unitary polar extension \(U\) with \(X\sqrt\sigma=\sqrt\rho U\), and put \(P=\sqrt\sigma X\sqrt\sigma\). Then \(P=\sqrt\sigma\sqrt\rho U\ge0\),
\[
 U^*\rho U=\sqrt\sigma X^2\sqrt\sigma\le\sqrt K P,
\qquad \operatorname{Tr}P=f(\rho,\sigma).
\]
Using the positive matrix \(2I-U-U^*\),
\[
\begin{aligned}
\|X\sqrt\sigma-\sqrt\rho\|_2^2
 &=\operatorname{Tr}[U^*\rho U(2I-U-U^*)]\\
 &\le2\sqrt K\,\Delta(\rho,\sigma).
\end{aligned}
\tag{25}
\]
Thus
\[
 \|[X,\sqrt\sigma]\|_2^2\le8\sqrt K\,\gamma(b)=:c.
\tag{26}
\]

Fix \(0<t\le1\). For \(r\) uniform in \([0,t)\), pinch in the spectral blocks of \(\sigma\) whose logarithms fall in the intervals \([r+jt,r+(j+1)t)\). Denote the pinching by \(\Pi_r\). If \(s_i,s_j\) are eigenvalues of \(\sigma\), the probability they are separated is
\[
 p_{ij}=\min\{1,|\log s_i-\log s_j|/t\}
 \le\frac5t\frac{|\sqrt{s_i}-\sqrt{s_j}|}{\sqrt{s_i}+\sqrt{s_j}}.
\tag{27}
\]
Indeed, the fraction is \(\tanh(|\log s_i-\log s_j|/4)\), and \(\tanh(u/4)\ge u/5\) for \(0\le u\le1\).

Set \(w_{ij}=(s_i+s_j)|X_{ij}|^2/2\). These weights sum to \(\operatorname{Tr}(\sigma X^2)=1\). Weighted Cauchy–Schwarz and (26) show
\[
 \mathbb E_r\|(X-\Pi_rX)\sqrt\sigma\|_2^2\le\frac{5\sqrt c}{t}.
\tag{28}
\]
For clarity, the squared ratio on the right side of (27), weighted by \(w_{ij}\), sums to at most \(\|[X,\sqrt\sigma]\|_2^2/2\).

By Schwarz for pinching, \(\operatorname{Tr}(\sigma(\Pi_rX)^2)\le1\). The positive matrix \((\Pi_rX)\sigma(\Pi_rX)\) is block diagonal. Factoring a difference of products and then pinching gives
\[
 T(\rho,\Pi_r\rho)\le2\|(X-\Pi_rX)\sqrt\sigma\|_2.
\]
Consequently
\[
 \mathbb E_rT(\rho,\Pi_r\rho)\le
 a:=\min\{1,2\sqrt5\,c^{1/4}t^{-1/2}\}.
\tag{29}
\]
This bound is uniform in \(\rho\); no single shift is being selected separately for each state.

There are only finitely many distinct pinchings as \(r\) varies, since the spectrum is finite. Let their probabilities be \(w_r\), omit zero probabilities, and **retain the shift as a classical flag**:
\[
 \mathcal E_0(\rho)=\bigoplus_r w_r\Pi_r(\rho).
\]
Regard its output as the algebra of the individual pinching blocks. Let \(\mathcal D_0\) sum and embed these blocks into the original space. These are CPTP maps, and
\[
 T(\mathcal D_0\mathcal E_0\rho,\rho)\le a,
 \qquad \mathcal D_0\mathcal E_0\sigma=\sigma.
\tag{30}
\]
Flatten the reference \(\mathcal E_0\sigma\) within each block by replacing its eigenvalues by their arithmetic mean. The resulting density matrix \(\omega\) is faithful and central in the output algebra. Moreover
\[
 e^{-t}\omega\le\mathcal E_0\sigma\le e^t\omega,
 \qquad T(\mathcal E_0\sigma,\omega)\le e^t-1.
\tag{31}
\]
Put \(S_\rho=\mathcal E_0\rho\) and \(K'=Ke^t\). Then \(S_\rho\le K'\omega\).

Let \(\Phi\) be the symmetrized broadcast marginal and define
\(F=\mathcal E_0\Phi\mathcal D_0\). It is self-compatible, using
\((\mathcal E_0\otimes\mathcal E_0)\mathcal B\mathcal D_0\). Let \(\nu=F\omega\). Equations (30)–(31) give
\[
 \delta:=T(\nu,\omega)\le b+2(e^t-1),
 \qquad T(FS_\rho,S_\rho)\le a+b.
\tag{32}
\]
Because \(FS_\rho\le K'\nu\), Lemma 3 supplies a **single** correction \(R\), independent of \(\rho\), such that \(G=RF\) is self-compatible, \(G\omega=\omega\), and
\[
 T(GS_\rho,S_\rho)\le
 q:=a+b+\sqrt{K'\delta}+K'\delta/2.
\tag{33}
\]
Applying the same correction to both broadcast outputs witnesses self-compatibility.

Centrality of \(\omega\) makes \(\tau(A)=\operatorname{Tr}(\omega A)\) a faithful trace. On relative densities define
\[
 L(A)=\omega^{-1}G(\omega A).
\tag{34}
\]
It is CP, unital and \(\tau\)-preserving. It is also self-compatible. If \(\mathcal B_G\) is a physical broadcaster for \(G\), use
\[
 \mathcal B_L(A)=(\omega^{-1}\otimes\omega^{-1})\mathcal B_G(\omega A).
\]
Its marginals with respect to \(\tau\) are precisely \(L\). These central multiplications are CP; no non-CP weighted adjoint is being introduced.

Apply Lemma 2 to obtain \(\Psi\). It corresponds to the physical EB channel
\[
 \Lambda_\omega(\theta)=
 \sum_y\operatorname{Tr}(E_y\theta)\frac{\omega E_y}{\tau(E_y)}.
\tag{35}
\]
Write \(S_\rho=\omega A_\rho\), so \(0\le A_\rho\le K'I\). Since \(0\preceq I-\Psi\preceq I\),
\[
\begin{aligned}
 T(\Lambda_\omega S_\rho,S_\rho)
 &\le\tfrac12\|(I-\Psi)A_\rho\|_{2,\tau}\\
 &\le\tfrac12\sqrt{\tau[A_\rho(I-\Psi)A_\rho]}\\
 &\le\tfrac12\sqrt{8K'\|GS_\rho-S_\rho\|_1}
 \le2\sqrt{K'q}.
\end{aligned}
\tag{36}
\]
In the third line we used
\(\tau[A_\rho(I-L)A_\rho]=\operatorname{Tr}[A_\rho(S_\rho-GS_\rho)]\).
The EB channel \(\mathcal D_0\Lambda_\omega\mathcal E_0\) therefore has uniform error at most
\[
 a+2\sqrt{K'q}.
\tag{37}
\]
All operations in this channel depend only on the whole family, its reference and its broadcaster. The state-specific likelihood \(X\) was used only in the estimates.

We finish with loose numerical bounds to make the modulus explicit. Put \(B=b\log(e/b)\) and \(u=c+b\). For \(0<u\le1\), choose \(t=u^{1/4}\). Using \(e<3\),
\[
 a\le2\sqrt5\,u^{1/8},\quad
 \delta\le5u^{1/4},\quad K'\le3K,\quad q\le17K u^{1/8}.
\]
Hence (37) is at most \(20K u^{1/16}\). From (23),
\[
 u\le(16\sqrt6+1)\sqrt K\,\sqrt B\le41\sqrt K\,\sqrt B.
\]
Thus (37) is at most \(32K^{33/32}B^{1/32}\); the elementary inequality \(20\,41^{1/16}<32\) suffices. If \(u>1\), this latter bound exceeds one, so the trivial bound applies. When \(b=0\), (26) gives \(c=0\); let \(t\downarrow0\) in (32)–(37). This proves (24), including the zero-error case by compactness of the finite-dimensional EB channel set. \(\square\)

## 6. Compatible smoothing at bounded Holevo capacity

This section supplies the transition from an entropy bound to the operator domination used in Lemma 5. Smoothing is an auxiliary mathematical construction of a nearby experiment, not an operation applied to an unknown input.

### Lemma 6 — A reference in the convex hull

There is a state \(\sigma\) in the finite convex hull of the closure of \(\mathcal E\) such that
\[
 \sup_{\rho\in\mathcal E}D(\rho\|\sigma)\le C(\mathcal E).
\tag{38}
\]
It is faithful on the joint support of the family. Any marginal channel with error at most \(b\) on \(\mathcal E\) has error at most \(b\) on \(\sigma\).

**Proof.** Closing the family changes none of the quantities. The convex hull of the compact set \(\{(\rho,S(\rho)):\rho\in\overline{\mathcal E}\}\) is compact and finite-dimensional. Maximizing \(S(\bar\rho)-s\) on it gives a maximizing finite ensemble, by Carathéodory. Let its mean be \(\sigma\). If some family state has support outside \(\sigma\), adding it with weight \(\varepsilon\) has entropy derivative \(+\infty\), contradicting maximality. On the resulting common support, differentiating after adding any \(\rho\) with infinitesimal weight gives
\[
 D(\rho\|\sigma)-C(\mathcal E)\le0.
\]
The error statement follows from convexity of trace distance and channel linearity. \(\square\)

Compression to this support causes no loss: use \(X\mapsto PXP+\operatorname{Tr}[(I-P)X]\sigma\), and apply it to each broadcaster output. At the end, precompose the reconstructed EB channel with this compression to obtain a channel on the original full algebra.

### Lemma 7 — Smoothing that preserves approximate invariance

Fix \(0<\eta<1/8\), suppose (38) holds with upper bound \(C\), and set
\[
 M=\frac{1}{1-\eta}\exp\!\left(\frac{C+\log2}{\eta}\right),
 \qquad \lambda=\frac\eta M.
\tag{39}
\]
There are states \(\widehat\rho\), including \(\widehat\sigma=\sigma\), such that
\[
 \widehat\rho\le2M\sigma,
 \qquad T(\rho,\widehat\rho)\le2\sqrt\eta.
\tag{40}
\]
If a CPTP map \(T_0\) has error at most \(b\) on both \(\rho\) and \(\sigma\), then its error on \(\widehat\rho\) is at most
\[
 v(b)=(1+\sqrt2)\sqrt{\xi(b)/\lambda}+4M\sqrt{2b},
\quad
 \xi(b)=\sqrt{2b}+2\sqrt M(2b)^{1/4}+2\lambda M^2\sqrt{2b}.
\tag{41}
\]
In particular, for \(0\le b\le1/2\),
\[
 v(b)\le8M\eta^{-1/2}b^{1/8}.
\tag{42}
\]
The bound is uniform in dimension, the number of states, and the spectrum of the reference.

**Proof.** For positive \(x\) supported on \(\sigma\), define
\[
 Q_\sigma(x)=\|\sigma^{-1/4}x\sigma^{-1/4}\|_2^2.
\]
On the compact convex set
\(K_\sigma=\{x:0\le x\le M\sigma,\ \operatorname{Tr}x\le1\}\), minimize
\[
 J_{\rho,\sigma}(x)=-f(\rho,x)+\lambda Q_\sigma(x).
\tag{43}
\]
The minimizer \(G(\rho,\sigma)\) is unique. Indeed, root fidelity is concave and the quadratic form is positive definite. Schatten Hölder gives
\[
 Q_\sigma(z)\ge\|z\|_1^2
\tag{44}
\]
for Hermitian \(z\) on the support. The exact quadratic identity implies the strong-convexity estimate
\[
 J_{\rho,\sigma}(x)-J_{\rho,\sigma}(G)
 \ge\lambda Q_\sigma(x-G)\ge\lambda\|x-G\|_1^2.
\tag{45}
\]
For feasible positive \(x\), \(Q_\sigma(x)\le M\operatorname{Tr}x\le M\): write \(Y=\sigma^{-1/4}x\sigma^{-1/4}\le M\sqrt\sigma\), and take the trace of \(Y(M\sqrt\sigma-Y)\ge0\) in the trace sense.

The Jain–Nayak form of the quantum substate theorem supplies a normalized \(x_0\le M\sigma\) with squared fidelity at least \(1-\eta\). Its observational divergence in bits is at most relative entropy in bits plus one; this gives exactly (39) when relative entropy is in nats. Thus
\[
 J(G)\le J(x_0)\le-1+2\eta,
 \qquad f(\rho,G)\ge1-2\eta.
\]
The trace \(s=\operatorname{Tr}G\) is at least \((1-2\eta)^2>1/2\). Define \(\widehat\rho=G/s\). Domination and the fidelity–trace-distance inequality prove (40).

For \(\rho=\sigma\), if \(\operatorname{Tr}x=s\le1\), then
\(J_{\sigma,\sigma}(x)\ge-\sqrt s+\lambda s^2\). This scalar expression is decreasing on \([0,1]\) because \(\lambda<1/4\). The state \(\sigma\) attains its minimum; uniqueness gives \(G(\sigma,\sigma)=\sigma\).

We prove the invariance assertion rather than adding a fixed smoothing error to \(b\). Root fidelity increases under CPTP maps, and order-two sandwiched Rényi data processing implies
\[
 Q_{T_0\sigma}(T_0x)\le Q_\sigma(x).
\tag{46}
\]
The latter holds for subnormalized positive \(x\) by homogeneity. Supports are handled by inverses on the appropriate support.

Put \(\nu=T_0\sigma\), \(d_r=\|T_0\rho-\rho\|_1\), \(d_s=\|\nu-\sigma\|_1\). A feasible \(x=\sqrt\sigma A\sqrt\sigma\), \(0\le A\le MI\), transports to \(x'=\sqrt\nu A\sqrt\nu\). Clip it down to trace one if necessary, obtaining \(k\in K_\nu\). The square-root inequality and Hölder give
\[
 \|k-x\|_1\le4M\sqrt{d_s},
 \quad
 Q_\nu(k)\le Q_\sigma(x)+2M^2\sqrt{d_s}.
\tag{47}
\]
For the second inequality, use \(Q_\sigma(x)=\operatorname{Tr}(A\sqrt\sigma A\sqrt\sigma)\), expand its difference from the analogous expression for \(\nu\), and note that clipping can only decrease \(Q\).

Root-fidelity continuity gives a one-way change in the objective at most
\[
 \xi=\sqrt{d_r}+2\sqrt M\,d_s^{1/4}+2\lambda M^2\sqrt{d_s}.
\tag{48}
\]
The same transport in the reverse direction bounds the absolute difference of the two minimum values by \(\xi\). Let \(G_1=G(T_0\rho,\nu)\). Data processing makes \(T_0G\) feasible with objective no larger than the old minimum. Its gap above the new minimum is at most \(\xi\), so (45) gives
\(\|T_0G-G_1\|_1\le\sqrt{\xi/\lambda}\).
The transported \(k\) obtained from \(G\) has gap at most \(2\xi\), giving
\(\|k-G_1\|_1\le\sqrt{2\xi/\lambda}\). Together with (47),
\[
 \|T_0G-G\|_1\le
 (1+\sqrt2)\sqrt{\xi/\lambda}+4M\sqrt{d_s}.
\tag{49}
\]
Division by \(2s>1\) gives the same upper bound for \(T(T_0\widehat\rho,\widehat\rho)\). Substituting \(d_r,d_s\le2b\) proves (41). For (42), use \(2b\le1\), \(\eta\le1/8\), \(M\ge1\), and
\(\xi(b)\le4M(2b)^{1/4}\); the resulting numerical constant is at most \((2+3\sqrt2)2^{1/8}<8\). \(\square\)

## 7. Proof of the main theorem

Take a broadcaster of error \(b\), symmetrize it, and use Lemma 6 to include the common reference \(\sigma\). The same broadcaster, by Lemma 7 applied to both marginals, has error at most \(\min\{1,v(b)\}\) on the entire smoothed family, which contains \(\sigma\) and is dominated by \(2M\sigma\). Lemma 5 and trace contraction therefore give
\[
 e(\mathcal E)\le4\sqrt\eta+
 g_{2M}\bigl(\min\{1,v(b)\}\bigr).
\tag{50}
\]
There is only one EB map for the smoothed family. The two smoothing errors in (50) come from comparing its action on \(\rho\) and \(\widehat\rho\), and comparing the target states. No nonlinear smoother is used as a channel.

Equation (50) already proves (5): fix \(C\) and \(\eta\), let \(b\to0\), and then let \(\eta\downarrow0\). We now obtain the explicit bound (3).

Write \(C_0=C+1\) and \(L=\log(1/b)\). If \(L\le65536C_0\), the right side of (3) is one, so the assertion is trivial. Otherwise take
\[
 \eta=1024C_0/L<1/64.
\]
Then
\[
 M\le2e^{L/1024},
 \qquad
 v(b)\le\frac12\sqrt{L/C_0}\,e^{-127L/1024}
 \le e^{-L/9}.
\tag{51}
\]
For the last inequality, \(127/1024-1/9>1/80\), while
\(\log(\tfrac12\sqrt L)\le L/80\) for \(L\ge256\).
The function \(x\log(e/x)\) is increasing on \([0,1]\). Applying (24) gives
\[
\begin{aligned}
 g_{2M}(v(b))
 &\le32\,4^{33/32}(1+L/9)^{1/32}
       e^{(33/32768-1/288)L}\\
 &\le256(1+L/9)^{1/32}e^{-L/512}
 \le128/\sqrt L.
\end{aligned}
\tag{52}
\]
The middle inequality uses \(1/288-33/32768>1/512\). To verify the last one, for \(L\ge65536=2^{16}\), use \(1+L/9\le L\) and
\[
 \log2+\frac{17}{32}\log L\le L/512.
\]
The difference is positive at \(2^{16}\) and increasing thereafter.

Finally, (50)–(52) imply
\[
 e(\mathcal E)\le128\sqrt{C_0/L}+128/\sqrt L
 \le256\sqrt{C_0/L}.
\]
This proves (3). If the optimal broadcasting error is zero, the fixed-\(\eta\) argument in (50), followed by \(\eta\downarrow0\), gives \(e=0\). The finite-dimensional sets of broadcasting channels and EB channels are compact, so zero infima have the usual exact interpretation, also for an infinite family of input states.

For (4), if \(\Lambda(\rho)=\sum_y\operatorname{Tr}(E_y\rho)\theta_y\), define
\[
 \mathcal B_\Lambda(\rho)=\sum_y\operatorname{Tr}(E_y\rho)
                      \theta_y\otimes\theta_y.
\]
Both marginals equal \(\Lambda\). This proves (4) and completes the theorem. \(\square\)

## 8. What is and is not established

The full bounded-capacity implication in Astra N93 is the mathematical target addressed here. The theorem also permits sublogarithmically growing capacity. The proof does not assume a bounded-dimensional Hilbert space, a bounded number of family members, a common spectral gap, a supplied tracial reference, or reversible broadcast marginals.

The indispensable connection in this argument is the combination of (i) retaining all logarithmic pinching choices as a classical flag, (ii) correcting the reference exactly with the single channel (18), and (iii) applying a common tracial comparator after the legitimate adjoint composition \(L^\dagger L\). These remove the nontracial and nonreversible dependencies without exchanging an average and a worst-case quantifier.

The reversible binary-tree comparator, pairwise likelihood estimates and compatible-smoothing construction are credited to the earlier Astra records below; they are reconstructed here, not presented as new inventions of this run. The proof establishes no sharpness of the constant 256 or the logarithmic modulus.

Classical reconstruction here means a common measurement followed by state preparation, uniformly on the specified experiment. It does not mean that the prepared states are mutually commuting, that a finite-memory alphabet can be bounded independently of dimension, that the measurement is efficiently computable, that an arbitrary purification is preserved, or that the broadcast outputs are independent copies. No claim about diamond-norm approximation of the identity is made.

The analytic argument has been checked within this run. No independent external referee, separate proof-auditor instance, Lean kernel or other proof assistant has validated it. The numerical diagnostics concern only selected finite-dimensional lemmas and are not a proof of the theorem. A 10/10 historical assessment and external priority determination remain unestablished.

## 9. Sources, attribution and accessed revisions

**Pinned research repositories.**

- Astra: `harjassand/astra-research-knowledge` at `f9344902ef1f94fb8d07540363741894bfbdc0ae`.
- OpenAI mathematics: `openai/math` at `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`.

**Astra inputs actually used or reconstructed.**

- `00_START_HERE.txt`: retrieval entry point and source-status contract.
- `frontier/review_cards/N93-bounded-holevo-gates.txt`: the bounded-capacity target and its previously unresolved scope.
- `frontier/review_cards/N330-broadcast-common-C4-comparator.txt` and `web/pages/d-8e0604d9d97a15ac.html`: reversible binary-tree/covariance/regression comparator, reconstructed in Lemma 2.
- `frontier/review_cards/N46-compact-quantum-classicality.txt`: pairwise broadcasting, canonical likelihood and spectral-binning precedents; the needed arguments are supplied in Lemmas 4–5.
- `web/pages/d-b4ddaa96b233287d.html`, whose exact original is `web/assets/362a88df81d6cf761b003d8ad5b196b77bc0a599fc42d4d7a15a7ae508475a6c.txt`: compatible-smoothing audit, reconstructed in Lemma 7. The earlier source also gives a better transport exponent; the weaker proved bound is enough here.

These records were labeled source-derived and unreviewed at the accessed revision. Reading them did not upgrade their status; their decisive mathematical arguments are included above rather than assumed from those labels.

**Established primary mathematics.**

1. Rahul Jain and Ashwin Nayak, *Short proofs of the Quantum Substate Theorem*, arXiv:1103.6067v2, Theorem 1 and the observational-divergence comparison. Used with squared fidelity and with bits converted to nats in (39).
2. Salman Beigi, *Sandwiched Rényi Divergence Satisfies Data Processing Inequality*, arXiv:1306.5920v6, Theorem 6. Used only at order two in (46), extended to subnormalized inputs by homogeneity.
3. Elliott H. Lieb, *Convex trace functions and the Wigner–Yanase–Dyson conjecture*, Advances in Mathematics 11 (1973), 267–288, DOI 10.1016/0001-8708(73)90011-X. Its joint concavity gives affinity data processing. Square-root trace inequalities, fidelity monotonicity, Schatten Hölder, classical Pinsker and finite-dimensional Carathéodory are used in their standard forms.

**Primary contextual literature consulted, not a substitute for priority clearance.**

4. H. Barnum, C. M. Caves, C. A. Fuchs, R. Jozsa and B. Schumacher, *Noncommuting mixed states cannot be broadcast*, arXiv:quant-ph/9511010; Physical Review Letters 76 (1996), 2818–2821.
5. Marius Lemm and Mark M. Wilde, *Information-theoretic limitations on approximate quantum cloning and broadcasting*, arXiv:1608.07569v2; Physical Review A 96 (2017), 012304.
6. Fernando G. S. L. Brandão, Marco Piani and Paweł Horodecki, *Generic emergence of classical features in quantum Darwinism*, arXiv:1310.8640v2; Nature Communications 6 (2015), 7908. Its displayed general diamond-norm approximation bounds retain dimension factors; this note concerns a family-restricted trace-distance contract instead.
7. Dominik Janzing and Bastian Steudel, *Quantum broadcasting problem in classical low-power signal processing*, Physical Review A 75 (2007), 022309. Its Holevo-information broadcasting formulation is related but is not used as the present theorem.

**OpenAI original material inspected.** The family-272 manuscript's `build/source/sections/foundations.tex` and `applications.tex` were read, including the Kraus/Choi transfer and the explicit two-block switch with an absorbing flag that completes non-trace-preserving PPT maps to a trace-preserving channel. The file `lean/docs/272.md` states that the selected formalization covers the PPT pair and dimension-21 square consequences, not the zero-secret-key claim. The formalization was not executed here, and neither consequence is a premise of Theorem 1. All of these paths are under the pinned OpenAI revision.

No repository file was modified and nothing was published.
