# Independent audit: uniform Gaussian equivalence near the tracial state

Audit completed 7 October 2026. The object audited is `work/uniform_gaussian_experiment.md`, especially its normalizer comparison and ordinary eigenvalue jitter. Earlier finite-memory theorems and their audits remain separate.

**Verdict:** the explicit ordinary-jitter construction survives the independent attack. It gives two channels depending only on `n,d`, with uniform error `C_d(delta+n^(-1/8))` on the entire ball `||d rho-I||_op<=delta<=1/2`. In particular every shrinking sequence `delta_n->0` is covered, without a condition on `n delta_n^3`. The normalization argument is not circular: an exact discrete normalizer, an independently computed continuous normalizer, and continuous small-gap control suffice. A weighted-jitter replacement is unnecessary.

The proof uses the established fixed-dimensional uniform HCIZ estimate, the previously audited universal coherent channel, and ordinary gamma/Hermite identities. This is a mathematical audit, not a novelty claim, formal verification, or an efficient circuit construction.

## 1. Interface and the two state-independent channels

Fix `d>=2`, and put

\[
 r=d^2-1,\qquad R=\frac{d(d-1)}2,\qquad
 N=n+R,\qquad c_H=\prod_{j=1}^{d-1}j!.
\]

The real space `H_0` of traceless Hermitian matrices carries the Hilbert–Schmidt inner product. The target law is

\[
 G_{n,\rho}=\mathcal N_{H_0}\!\left(\sqrt n(\rho-I/d),\,I_{H_0}/d\right).
\]

All `r` coordinates in an orthonormal HS basis have variance `1/d`. Both the spectrum and the basis of `rho` are unknown parameters.

The encoder measures the universal Schur/coherent POVM and obtains a partition `lambda` and a complete flag `W`. Set `l_i=lambda_i+d-i`. These are strictly decreasing nonnegative integers of sum `N`. Draw an independent uniform point from

\[
 C=\{\xi\in\mathbb R^d:\ \sum_i\xi_i=0,\quad
                   \max_i\xi_i-\min_i\xi_i\le1\},
\]

and output

\[
 T_n:\quad Y=\frac{W\operatorname{diag}(l+\xi)W^*-(N/d)I}{\sqrt n}.
\]

The decoder sets `M=sqrt(n)Y+(N/d)I`, diagonalizes it with ordered eigenvalues `x`, and rounds `x` to a nearest integer vector `l` of sum `N`. If `l` is strictly decreasing and nonnegative, it prepares the coherent state in sector `lambda_i=l_i-d+i`, tensors the normalized identity in the multiplicity space, and inverts the Schur transform. For invalid `l`, it prepares an arbitrary fixed state. Tie conventions can be fixed measurably.

These channels contain no `rho`, `delta`, estimated spectrum, or state-dependent resampling rule. They are continuous classical channels, not finite retained registers.

The basis `e_i-e_d`, `i<d`, of the root lattice has Gram determinant `d`. Thus its HS covolume is

\[
 v_d=\sqrt d.
\]

The displayed `C` really is its Voronoi cell. Root inequalities imply coordinate range at most one. Conversely, if that range is at most one and `z` is any sum-zero integer vector, then, with `P=sum_(z_i>0)z_i`,

\[
 \langle\xi,z\rangle\le P\le\frac12\|z\|^2,
\]

because `z_i^2>=|z_i|`. These are all Voronoi inequalities. Also `|xi_i|<1`. Integer gaps at least one retain their order under this jitter; ties are a boundary event of measure zero. Nearest-lattice rounding therefore recovers `l` on every encoder output almost surely. In particular

\[
 S_nT_n(\rho^{\otimes n})=C_{n,d}(\rho^{\otimes n})
 \tag{1}
\]

exactly, where `C_(n,d)` is the audited coherent measure-and-prepare channel. There is no positivity requirement on the classical observation `Y`. The comparison continuous matrix domain must be `M>-I`, rather than `M>0`: a sector with `lambda_d=0` can jitter its lowest eigenvalue below zero while the exact decoder still recovers that sector.

The earlier channel minorant gives

\[
 \frac12\|C_{n,d}(\rho^{\otimes n})-\rho^{\otimes n}\|_1
 \le1-\prod_{i<j}\frac{p_j}{p_i}\le C_d\delta
 \tag{2}
\]

for `p_i in [(1-delta)/d,(1+delta)/d]`. This bound and (1) will supply the entire reverse direction.

## 2. Uniform coherent-to-HCIZ replacement

Work in a basis in which `P=diag(p)` has decreasing entries. Write `ell_k=lambda_k-lambda_(k+1)` and `P_(W,k)=W_k W_k^*`. The coherent conditional flag potential is

\[
 \Phi_\lambda(W)=\sum_{k<d}\ell_k b_k(W),\qquad
 b_k=\sum_{i\le k}\log p_i-\log\det(W_k^*PW_k).
\]

Define the nonnegative rearrangement energy

\[
 E_{\lambda,p}(W)=\operatorname{Tr}(\lambda P)
                -\operatorname{Tr}(P W\lambda W^*)
 =\sum_{k<d}\ell_k\left(\sum_{i\le k}p_i-
                              \operatorname{Tr}(P P_{W,k})\right).
\]

With `a=1/p_max` and `b=1/p_min`, compression eigenvalues and the scalar logarithm derivative give `aE<=Phi<=bE`. The trace-log potential

\[
 \Gamma_\lambda(W)=\operatorname{Tr}(\lambda\log P)
             -\operatorname{Tr}(\log P\,W\lambda W^*)
\]

satisfies the same bounds. One precise justification for the latter is to expand both trace deficits in the ordered spectral increments. The coefficients are

\[
 \min(k,j)-\operatorname{Tr}(P_{\mathrm{top},j}P_{W,k})\ge0,
\]

and each logarithmic increment is between `a` and `b` times its ordinary increment. Hence

\[
 |\Phi_\lambda-\Gamma_\lambda|\le(b-a)E_{\lambda,p}
                                      \le C_d\delta E_{\lambda,p}.
 \tag{3}
\]

The required uniform first moment does not require a typical-label restriction. Let

\[
 K(c)=\int e^{-cE_{\lambda,p}(W)}\,d\mu(W).
\]

The [Graczyk–Sawyer uniform HCIZ estimate](https://arxiv.org/html/2012.12022v1), Theorem 3.1, gives

\[
 K(c)\asymp_d\prod_{i<j}
       [1+c(\lambda_i-\lambda_j)(p_i-p_j)]^{-1}.
 \tag{4}
\]

This includes chamber boundaries and repetitions, by continuity. For any interpolated potential `H_t=(1-t)Phi+tGamma`,

\[
 \mathbb E_{H_t}E
 \le\frac{\int E e^{-aE}\,d\mu}{K(b)}
 \le\frac{2}{ae}\frac{K(a/2)}{K(b)}\le C_d.
 \tag{5}
\]

The last inequality follows factor by factor from (4), since `b/a<=3` and `a>=2d/3`. Differentiation of the normalized density yields

\[
 \|\partial_t f_t\|_1
 \le2\mathbb E_{H_t}|\Gamma-\Phi|\le C_d\delta.
\]

Thus the coherent conditional flag law can be replaced by the HCIZ law of natural parameter `log rho`, with error `C_d delta`, uniformly in **every** partition and every spectrum in the ball.

The additional Weyl shift `k_i=d-i` has trace-log rearrangement energy in `[0,C_d delta]`, independent of `lambda`. Tilting by it changes the normalized law by at most `C_d delta`. Therefore the final conditional replacement is

\[
 g_l(W)=\frac{e^{\operatorname{Tr}(\log\rho\,W\operatorname{diag}(l)W^*)}}
              {I_l(\log\rho)}.
 \tag{6}
\]

Holding the exact sector probabilities fixed, the full joint outcome law changes by at most `C_d delta`.

## 3. Exact lattice law and its normalization

The three relevant formulas, with normalized invariant flag measure, are

\[
 m_\lambda=\frac{n!\Delta(l)}{\prod_i l_i!},\qquad
 s_\lambda(p)=\frac{\det[p_i^{l_j}]}{\Delta(p)},\qquad
 I_l(\log P)=\frac{c_H\det[p_i^{l_j}]}{\Delta(\log p)\Delta(l)}.
\]

Consequently `m_lambda s_lambda(p) g_l(W)` equals the normalized law

\[
 Q_\rho(l,dW)=\frac{u_\rho(l,W)}{Z_d(\rho)}\,d\mu(W),
 \qquad
 u_\rho(x,W)=\Delta(x)^2
 \frac{e^{\operatorname{Tr}(\log\rho\,W\operatorname{diag}(x)W^*)}}
      {\prod_i\Gamma(x_i+1)},
\]

with the **exact** normalizer

\[
 Z_d(\rho)=\frac{c_H\Delta(p)}{n!\Delta(\log p)}.
 \tag{7}
\]

The quotient at repeated eigenvalues is its positive continuous extension. At the uniform spectrum it is exactly `c_H d^(-R)/n!`. There is no loss of a factor `Delta(l)` or `c_H` here: multiplying the normalized HCIZ law by the original Schur law cancels precisely the character determinant.

After uniform cell jitter, the joint density on `l+C` in eigenvalue HS measure times flag measure is

\[
 j_\rho(x,W)=\frac{u_\rho(l,W)}{v_d Z_d(\rho)}.
 \tag{8}
\]

It is **not** exactly `u_rho(x,W)` because both the Vandermonde and the gamma factor vary inside a cell. Section 7 below proves the comparison instead of assuming it.

## 4. Continuous factorial model and the true-state center

Let the continuous matrix law on `M>-I`, `Tr M=N`, have raw density

\[
 a_\rho(M)=e^{-V_\rho(M)},\qquad
 V_\rho(M)=\operatorname{Tr}\log\Gamma(M+I)
                              -\operatorname{Tr}(M\log\rho).
\]

Its ordered eigenvalue/flag density is `u_rho/Z_c`, where `Z_c` is the integral of `u_rho` in the same eigenvalue HS measure used in (8). This domain contains all jitter outputs and is convex. Its eigenvalues have maximum below `N+d-1`.

Center at

\[
 M_0=n\rho+(R/d)I,\qquad Z=(M-M_0)/\sqrt n\in H_0.
\]

For `h(x)=log Gamma(x+1)`, digamma asymptotics imply

\[
 \nabla V_\rho(M_0)=\log n\,I+O_d(n^{-1}).
 \tag{9}
\]

The scalar term disappears on the trace constraint. In particular the projected gradient is `O_d(1/n)`, even if `sqrt(n)delta` diverges. There is no mean bias of order `sqrt(n)delta^2`.

For completeness, the Hessian of `Tr h(M)` at a diagonal `M=diag(m)` has diagonal coefficients `h''(m_i)` and off-diagonal divided differences `(h'(m_i)-h'(m_j))/(m_i-m_j)`. These extend continuously at coincident eigenvalues. At `M_0` they equal `d/n+O_d(delta/n+n^(-2))`. In a segment whose eigenvalues are at least `c_d n`, the second divided differences of `h'` are bounded by its scalar third derivative `O_d(n^(-2))`; the trace third derivative has the same bound in fixed dimension. Taylor's formula gives, on `||Z||<=c_d sqrt(n)`,

\[
 \left|V_\rho(M_0+\sqrt n Z)-V_\rho(M_0)-\frac d2\|Z\|_F^2\right|
 \le C_d\left[\delta\|Z\|^2+
                     \frac{\|Z\|+\|Z\|^3}{\sqrt n}\right].
 \tag{10}
\]

All estimates use `p_min>=1/(2d)` and remain uniform at spectral collisions.

There is also global Gaussian domination. The trigamma series implies

\[
 h''(x)=\psi'(x+1)\ge\frac1{x+1}\ge\frac1{N+d}\quad(x>-1)
\]

on this trace domain. The corresponding divided differences have the same lower bound, so the matrix Hessian does too. Strong convexity, (9), and completing a square yield

\[
 V_\rho(M_0+\sqrt n Z)-V_\rho(M_0)
                           \ge c_d\|Z\|^2-C_d/n.
 \tag{11}
\]

The centered domain contains a ball of radius `c_d sqrt(n)`. Integrating

\[
 |e^{-a}-e^{-b}|\le |a-b|e^{-\min(a,b)}
\]

using (10)–(11), and bounding the outer region by Gaussian tails, proves both the relative normalization estimate and

\[
 \operatorname{TV}\left(q_\rho\text{ mapped by }
           M\mapsto\frac{M-(N/d)I}{\sqrt n},\ G_{n,\rho}\right)
                           \le C_d(\delta+n^{-1/2}).
 \tag{12}
\]

The cubic remainder is integrated against a fixed-dimensional Gaussian; no cutoff condition such as `delta L_n^2=o(1)` is needed. The expansion is around the actual `n rho`, not an expansion of the uncentered natural parameter at `I/d`. This is the reason there is no `n delta^3` restriction.

## 5. Independent check of every normalization constant

The ordered trace-zero eigenvalue Gaussian integral is

\[
 J_d=\int_{x_1>\cdots>x_d,\ \sum x_i=0}
       \Delta(x)^2e^{-d\|x\|^2/2}\,dx_{HS}
     =c_H(2\pi)^{(d-1)/2}d^{-r/2}.
 \tag{13}
\]

To verify it, monic scaled Hermite norms give the full integral

\[
 \int_{\mathbb R^d}\Delta(x)^2e^{-d\|x\|^2/2}\,dx
   =d!\,c_H(2\pi)^{d/2}d^{-d^2/2}.
\]

Divide by `d!` for the ordered chamber. Decompose the trace coordinate as `t=Tr(x)/sqrt(d)` orthogonally to the sum-zero hyperplane and divide by `sqrt(2 pi/d)`. This gives (13) with HS hyperplane measure, rather than an unnormalized delta-function constraint measure.

Equivalently the Weyl matrix-volume constant for these choices of measures is `(2 pi)^R/c_H`: the matrix Gaussian integral `(2 pi/d)^(r/2)` divided by (13). The continuous normalization is obtained by translating the **matrix** variable by `M_0`, not by translating its ordered eigenvalues. Thus the integral is independent of the possibly large and repeated mean.

Put `s=R/d`, so the eigenvalues of `M_0` are `m_i=n p_i+s`. Stirling gives

\[
 \begin{aligned}
 \log a_\rho(M_0)
 &=\sum_i\left[m_i\log p_i-(m_i+\tfrac12)\log m_i
                    +m_i-\tfrac12\log(2\pi)\right]+O_d(n^{-1})\\
 &=n-(n+R+d/2)\log n-\tfrac12\log\det\rho
                        -\tfrac d2\log(2\pi)+O_d(n^{-1}).
 \end{aligned}
\]

Here the `d s=R` term in the expansion of `log m_i` cancels the extra `R` in `sum m_i`. Hence

\[
 a_\rho(M_0)=e^n n^{-n-R-d/2}(2\pi)^{-d/2}
                         (\det\rho)^{-1/2}[1+O_d(n^{-1})].
\]

The centered matrix volume contributes `n^(r/2)`, and its Gaussian integral contributes `J_d` in eigenvalue/flag measure. Since `-R-d/2+r/2=-1/2`, a further Stirling comparison gives

\[
 Z_c(\rho)=\frac{c_H}{n!}d^{-r/2}(\det\rho)^{-1/2}
                                  [1+O_d(\delta+n^{-1/2})].
 \tag{14}
\]

Each factor `(p_i-p_j)/(log p_i-log p_j)` lies between `p_min` and `p_max`, including its repeated-eigenvalue extension. Therefore

\[
 \frac{\Delta(p)}{\Delta(\log p)}=d^{-R}[1+O_d(\delta)],\qquad
 (\det\rho)^{-1/2}=d^{d/2}[1+O_d(\delta)].
\]

Combining (7), (14), and `v_d=sqrt(d)` gives

\[
 \boxed{\frac{Z_c(\rho)}{\sqrt d\,Z_d(\rho)}
                     =1+O_d(\delta+n^{-1/2}).}
 \tag{15}
\]

The exponent identity is `-r/2+d/2+R=1/2`. All constants, including the trace-hyperplane measure and lattice covolume, match. This estimate is independent of any discrete good-cell or gap probability.

## 6. Uniform small gaps for every translated matrix Gaussian

Let `theta in H_0` be any deterministic mean, with ordered eigenvalues `t`, and let a matrix Gaussian of covariance `I/d` have ordered eigenvalues `x`. Weyl integration and (4) bound its normalized eigenvalue density by

\[
 C_d e^{-d\|x-t\|^2/2}
       \prod_{i<j}\frac{(x_i-x_j)^2}
                           {1+d(x_i-x_j)(t_i-t_j)}.
 \tag{16}
\]

For `z,u>=0`,

\[
 \frac{z^2}{1+dzu}\le C_d(1+|z-u|)^2.
\]

Indeed, if `u>=z/2` the ratio is at most `2/d`; otherwise `z<=2|z-u|`. All nonselected pair factors in (16) are consequently bounded by a fixed-degree polynomial in `||x-t||`. If the selected adjacent gap is in `[0,h]`, its factor is at most `h^2`. The selected gap constraint is a width-`h/sqrt(2)` slab in the trace hyperplane. Every translated Gaussian-polynomial slice has a dimension-only uniform bound: decompose along its normal, bound the one-dimensional Gaussian-polynomial factor in supremum, and integrate the other coordinates. Integration and the union over adjacent pairs give

\[
 \boxed{\Pr\{\min_i(x_i-x_{i+1})\le h\}\le C_d h^3.}
 \tag{17}
\]

This is uniform even for unbounded `||theta||`, all repeated eigenvalues of `theta`, and the entire growing parameter ball. It imports no extra deformed-GUE theorem beyond the HCIZ estimate already used for (5).

## 7. Good-cell comparison without a lattice-tail assumption

Take `L=K=n^(1/8)`. A legal center `l` is good when every adjacent gap exceeds `K` and every `|l_i-np_i|<=2L sqrt(n)`. These are proof-only state-dependent sets; neither channel uses them.

Under the continuous model, the central matrix event `||M-M_0||_F<=L sqrt(n)` has complement at most `C_d exp(-c_d L^2)` by (11) and a uniform positive centered normalizer. Hoffman–Wielandt places its ordered eigenvalues within `L sqrt(n)` of the ordered eigenvalues of `M_0`. If they also have adjacent gaps exceeding `K+2`, nearest-lattice rounding gives a good center: coordinate rounding errors are less than one, and the lower eigenvalue bound `n/(2d)-L sqrt(n)-O_d(1)` is positive for all sufficiently large `n`. Using (12) and (17) at `h=(K+2)/sqrt(n)`, the union of good cells has continuous probability

\[
 q_\rho(G)\ge1-C_d(\delta+n^{-1/8}).
 \tag{18}
\]

On a good cell, pairwise jitter differences are at most one and all gaps exceed `K`, so

\[
 \frac{\Delta(l+\xi)^2}{\Delta(l)^2}=1+O_d(K^{-1}).
\]

For the gamma/source factor, let `B_i=(W^*log rho W)_(ii)`. Every `B_i` lies between `log p_min` and `log p_max`. Along the cell,

\[
 h'(l_i+t\xi_i)=\log n+\log p_i+O_d(L/\sqrt n+1/n).
\]

Subtract the scalar `log n`; it cancels because `sum xi_i=0`. The remaining difference `B_i-log p_i` is bounded by the logarithmic spectral range `C_d delta`, for every flag `W`. Hence

\[
 \left|\log\frac{a_\rho(l+\xi,W)}{a_\rho(l,W)}\right|
                         \le C_d(\delta+L/\sqrt n+1/n).
\]

There is no `delta L`, `delta log n`, or `n delta^3` term. Combining these estimates yields a uniform raw density ratio `1+O_d(delta+n^(-1/8))` on every good cell, for all flags.

Now compare the **normalized** densities (8) and `u_rho(x,W)/Z_c`. Equation (15) gives

\[
 j_\rho(x,W)/q_\rho(x,W)=1+O_d(\delta+n^{-1/8})\qquad\text{on }G.
\]

Integrating this identity over `G` and using (18) forces `j_rho(G)>=1-C_d(delta+n^(-1/8))`. Thus both omitted masses are small, and

\[
 \operatorname{TV}(j_\rho,q_\rho)\le C_d(\delta+n^{-1/8}).
 \tag{19}
\]

This is the decisive implication: continuous good-cell mass plus the independently established normalization ratio controls discrete good-cell mass. It neither presumes discrete eigenvalue repulsion nor derives a normalizer from a prior assumption that discrete tails are small. The exact ratio repairs the only gap in a naive uniform-jitter argument.

## 8. Completion and scope

The coherent-to-HCIZ replacement costs `C_d delta`; jitter and the matrix map are Markov kernels; (19) and (12) give

\[
 \sup_{\rho:\|d\rho-I\|_{op}\le\delta}
 \operatorname{TV}(T_n(\rho^{\otimes n}),G_{n,\rho})
                                \le C_d(\delta+n^{-1/8}).
\]

Contractivity of the explicit `S_n`, followed by (1)–(2), then gives

\[
 \sup_{\rho:\|d\rho-I\|_{op}\le\delta}
 \frac12\|S_n(G_{n,\rho})-\rho^{\otimes n}\|_1
                                \le C_d(\delta+n^{-1/8}).
\]

All ratio manipulations can first be made with `delta+n^(-1/8)` smaller than a fixed dimension-only constant. The remaining finite-`n` or larger-`delta` range follows by enlarging `C_d`, since both distances are at most one. Thus the displayed finite bound holds throughout `delta<=1/2`, not only along a selected asymptotic subsequence.

For every `delta_n->0`, both experiment deficiencies therefore vanish. The reverse channel does not need an independent rounding approximation for the continuous factorial law: exact encoder-decoder composition already supplies it. The theorem concerns unpurified density-operator statistical experiments; it asserts neither finite memory for the real observation nor preservation of arbitrary purifications. The prior finite-memory results are unaffected.

No actual mathematical gap remains identified in this construction after the normalization, collision, boundary, mean-bias, and state-independence checks above. The established uniform HCIZ estimate and the audited coherent channel remain explicit dependencies of the positive verdict.
