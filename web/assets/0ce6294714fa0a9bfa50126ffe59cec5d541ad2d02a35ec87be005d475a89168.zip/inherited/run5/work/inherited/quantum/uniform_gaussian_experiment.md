# Uniform tracial quantum-to-Gaussian equivalence on arbitrary shrinking balls

Derived 7 October 2026. This builds on the universal coherent classicalization channel and the Graczyk–Sawyer HCIZ estimate in `quantum_multiscale_collisions.md`. The research proof has explicit channels and all analytic dependencies written below. Two independent analytic audits are complete and positive: `gaussian_bridge_audit.md` checks the Weyl/Gamma normalization and uniform translated-GUE repulsion, and `gaussian_jitter_audit.md` checks the root-lattice cell, exact channel composition, and good-cell comparison. The parent also independently checked the proof; no unresolved load-bearing gap was identified in these agent audits. No external certification, formal verification, novelty determination, or efficient implementation is asserted. The earlier finite-memory theorems are preserved separately.

## 1. Statement, covariance, and actual channels

Fix `d>=2`; write `r=d^2-1`, `R=d(d-1)/2`, `c_H=prod_(k=1)^(d-1) k!`, and `N=n+R`. Let `H_0` be the real space of traceless Hermitian matrices, with Frobenius/HS inner product. Define the state ball

\[
 \mathcal B_\delta=\{\rho:\rho\ge0,\operatorname{Tr}\rho=1,\|d\rho-I\|_\mathrm{op}\le\delta\},\quad0\le\delta\le1/2.
\]

The quantum experiment is `{rho^n:rho in B_delta}`. The comparison classical experiment is

\[
 G_{n,\rho}=\mathcal N_{H_0}(\sqrt n(\rho-I/d),\,I_{H_0}/d).
\]

Thus in any orthonormal HS basis of `H_0`, its `r` real coordinates have independent variance `1/d`. This is a full matrix Gaussian location experiment, including the unknown spectrum and eigenbasis.

**Claim proved below:** there are universal channels `T_n` (quantum to classical) and `S_n` (classical to quantum), depending only on `n,d`, with

\[
 \sup_{\rho\in\mathcal B_\delta}\operatorname{TV}(T_n(\rho^n),G_{n,\rho})
 \le C_d(\delta+n^{-1/8}),
\]

\[
 \sup_{\rho\in\mathcal B_\delta}\tfrac12\|S_n(G_{n,\rho})-\rho^n\|_1
 \le C_d(\delta+n^{-1/8}).
\tag{A}
\]

The right sides can be capped by one. Consequently, for **every** `delta_n->0`, the experiments are uniformly equivalent, with no requirement such as `n delta_n^3->0` and no bound on `sqrt n delta_n` beyond its being `o(sqrt n)`. In particular the Gaussian local-parameter ball may grow nearly as fast as `sqrt n`.

The channels are explicit. Under universal Schur/coherent measurement, obtain transient sector `lambda` and complete flag `W`. Set

\[
 l_i=\lambda_i+d-i\quad(i=1,...,d),\qquad\sum_i l_i=N.
\]

The `l_i` are distinct decreasing nonnegative integers. Let

\[
 C=\{\xi\in\mathbb R^d:\sum_i\xi_i=0,\ \max_i\xi_i-\min_i\xi_i\le1\}
\]

be the Voronoi cell of the integer root lattice `A_(d-1)={z in Z^d:sum z=0}`. Draw `xi` uniformly in `C`. Output

\[
 Y=\frac{W\operatorname{diag}(l+\xi)W^*-(N/d)I}{\sqrt n}.
\tag{T}
\]

For the inverse channel, form `M=sqrt n Y+(N/d)I`, diagonalize it as `W diag(x) W*` with ordered eigenvalues, and round `x` to its nearest integer point `l` in the trace-`N` lattice. If `l` is distinct decreasing and nonnegative, set `lambda_i=l_i-d+i`, prepare its coherent Schur state with flag `W`, attach the mixed multiplicity state, and invert Schur. If invalid, return a fixed state. Ties use any fixed measurable rule.

On an output of (T), nearest-lattice rounding recovers `l` exactly outside a measure-zero boundary, and `l+xi` stays ordered. Hence

\[
 S_nT_n(\rho^n)=C_{n,d}(\rho^n)
\tag{B}
\]

**exactly**, where `C_(n,d)` is the previously proved universal coherent channel. This identity is not an asymptotic approximation.

The output `Y` need not be positive; it is a classical traceless matrix. This makes the rare `lambda_d=0` boundary harmless: the inverse rounding still recovers its valid sector. The theorem concerns statistical equivalence, not finite stored memory. No real-valued observation is counted as a finite register.

## 2. Root-lattice cell facts

The lattice basis `e_i-e_d`, `i<d`, has Gram determinant `d`, so its covolume is `v_d=sqrt d`. The stated `C` is its Voronoi cell. The nearest-point inequalities for lattice roots `e_i-e_j` imply `xi_i-xi_j<=1`. Conversely, if the coordinate range is at most one, then for every integer `z` of sum zero, with `P=sum_(z_i>0) z_i`,

\[
 \langle\xi,z\rangle\le P\le\tfrac12\|z\|^2,
\]

because integer `z_i^2>=|z_i|`. These are exactly the Voronoi inequalities. Also `|xi_i|<1`, and each pairwise jitter difference has absolute value at most one. If `l_i-l_j>=1`, its order is preserved after jitter, with ties occurring only on cell boundaries.

The trace-`N` lattice's Voronoi translates partition its affine hyperplane up to measure-zero boundaries. Distinct ordered nonnegative integer vectors of sum `N` correspond bijectively to legal Schur labels via the Weyl shift above.

## 3. Uniform angular replacement by a natural-parameter HCIZ law

Diagonalize `rho`, with decreasing spectrum `p`. Set `P=diag(p)`; rotation covariance handles the true unknown eigenbasis. The coherent conditional flag likelihood is

\[
 f_\lambda(W)\propto e^{-\Phi_\lambda(W)},\quad
 \Phi_\lambda=\sum_{k<d}\ell_k b_k,
 \quad \ell_k=\lambda_k-\lambda_{k+1},
\]

\[
 b_k=\sum_{i\le k}\log p_i-\log\det(W_k^*PW_k).
\]

Compare it with

\[
 g_\lambda(W)\propto e^{-\Gamma_\lambda(W)},\quad
 \Gamma_\lambda=\operatorname{Tr}(\lambda\log P)-\operatorname{Tr}(\log P\,W\lambda W^*).
\]

Let `t_k=sum_(i<=k)p_i-Tr(P W_kW_k*)>=0`, and `E_(lambda,p)=sum_k ell_k t_k>=0`. Compression and scalar-log derivative bounds give

\[
 aE_{\lambda,p}\le\Phi_\lambda\le bE_{\lambda,p},\qquad
 aE_{\lambda,p}\le\Gamma_\lambda\le bE_{\lambda,p},
\]

where `a=1/p_max`, `b=1/p_min`. The second bound follows by decomposing the trace deficit of `log P` into its ordered spectral increments; each log increment lies between `a` and `b` times the corresponding increment of `P`. Since `p_i in [(1-delta)/d,(1+delta)/d]`,

\[
 |\Phi_\lambda-\Gamma_\lambda|\le(b-a)E_{\lambda,p}\le C_d\delta E_{\lambda,p}.
\]

Interpolate these two potentials. Every interpolated law has energy expectation at most `C_d` by the HCIZ normalizer-ratio proof in the previous note, because all potentials lie between `aE` and `bE` and `b/a<=3`. Its density derivative has `L1` norm at most `2 C_d delta E`. Integration gives

\[
 \operatorname{TV}(f_\lambda,g_\lambda)\le C_d\delta,
\]

uniformly in `n`, **every** Schur label, all collisions, and the true unknown eigenbasis.

Replace `lambda` by `l=lambda+k`, `k_i=d-i`. The additional rearrangement energy

\[
 \Gamma_k=\operatorname{Tr}(k\log P)-\operatorname{Tr}(\log P\,WkW^*)
\]

is between zero and `C_d log(p_max/p_min)<=C_d delta`. Thus `TV(g_lambda,g_l)<=C_d delta`. We may replace the coherent conditional flag law by the natural-parameter HCIZ law

\[
 g_l(W)=\frac{e^{\operatorname{Tr}(\log\rho\,W\operatorname{diag}(l)W^*)}}
 {\int e^{\operatorname{Tr}(\log\rho\,V\operatorname{diag}(l)V^*)}d\mu(V)}
\tag{C}
\]

with joint-law error `C_d delta`, retaining the exact original Schur-sector probabilities.

## 4. An exact matrix factorial exponential family

The representation formulas are

\[
 m_\lambda=\frac{n!\,\Delta(l)}{\prod_i l_i!},\quad
 s_\lambda(p)=\frac{\det[p_i^{l_j}]}{\Delta(p)},\quad
 \int e^{\operatorname{Tr}(\log P\,WlW^*)}d\mu(W)
 =\frac{c_H\det[p_i^{l_j}]}{\Delta(\log p)\Delta(l)}.
\]

Here `Delta(x)=prod_(i<j)(x_i-x_j)`. Ratios at spectral repeats are interpreted by continuity. Multiplying the Schur law `m_lambda s_lambda(p)` by (C), all determinant factors cancel. The resulting normalized discrete-eigenvalue joint law is exactly

\[
 Q_\rho(l,dW)=\frac1{Z_\mathrm{disc}(\rho)}
 \frac{\Delta(l)^2}{\prod_i l_i!}
 e^{\operatorname{Tr}(\log\rho\,WlW^*)}d\mu(W),
\]

\[
 \boxed{Z_\mathrm{disc}(\rho)=\frac{c_H\Delta(p)}{n!\Delta(\log p)}.}
\tag{D}
\]

The comparison law after ordinary uniform cell jitter therefore has raw density `u_rho(l,W)/v_d` on the cell centered at `l`, where

\[
 u_\rho(x,W)=\Delta(x)^2 a_\rho(x,W),\quad
 a_\rho(x,W)=\frac{e^{\operatorname{Tr}(\log\rho\,WxW^*)}}{\prod_i\Gamma(x_i+1)}.
\]

Ordinary jitter is **not** exactly a continuous matrix density: `Delta(x)^2` changes inside each cell. Its error is controlled explicitly in Sections 7–8, including close spectral gaps.

## 5. Continuous matrix model and Gaussian approximation at the true state

On Hermitian matrices `M>-I` with trace `N`, define

\[
 q_\rho(M)\propto\exp\{\operatorname{Tr}(M\log\rho)-\operatorname{Tr}h(M)\},
 \qquad h(x)=\log\Gamma(x+1).
\]

The domain includes every jittered matrix because all `l_i>=0` and `xi_i>-1`. In ordered eigenvalues and invariant flag coordinates its density is precisely `u_rho(x,W)` above, up to a constant fixed by the Weyl integration formula. Let `Z_cont` denote its integral in eigenvalue-HS measure `dx_(Tr=N)` times normalized flag measure; this is the normalizer to compare with (D).

Center at

\[
 M_0=n\rho+(R/d)I,\qquad
 Z=\frac{M-M_0}{\sqrt n},\quad \operatorname{Tr}Z=0.
\]

This expansion is centered at the actual state and does not expand an uncentered `n log rho` around `I/d`. Put `V_rho(M)=Tr h(M)-Tr M log rho`.

The digamma asymptotics give, uniformly for `p_i>=(1-delta)/d>=1/(2d)`,

\[
 \nabla V_\rho(M_0)=\log n\,I+O_d(1/n),
\]

so its scalar part disappears on the trace-zero tangent. The Hessian has diagonal coefficients `h''(m_i)` and off-diagonal divided differences `(h'(m_i)-h'(m_j))/(m_i-m_j)`. Therefore

\[
 \nabla^2 V_\rho(M_0)[H,H]
 =\frac dn\|H\|_F^2+O_d\!\left(\frac\delta n+\frac1{n^2}\right)\|H\|_F^2.
\]

For `||Z||<=c_d sqrt n`, every eigenvalue along the centered segment remains at least `c_d n`. Scalar polygamma bounds and divided differences give the third derivative bound `C_d/n^2`. Thus

\[
 V_\rho(M_0+\sqrt nZ)-V_\rho(M_0)
 =\frac d2\|Z\|_F^2+\mathcal R,
\]

\[
 |\mathcal R|\le C_d\{\delta\|Z\|^2+(\|Z\|+\|Z\|^3)/\sqrt n\}.
\tag{E}
\]

There is also a global integrable domination, independent of the moving mean. For `x>-1`, `h''(x)=psi'(x+1)>=1/(x+1)` by the integral comparison of the positive trigamma series. Since eigenvalues in this trace domain have maximum at most `N+d-1`, scalar and matrix Hessians are bounded below by `1/(N+d)`. Strong convexity and the centered gradient estimate give

\[
 V_\rho(M_0+\sqrt nZ)-V_\rho(M_0)\ge c_d\|Z\|^2-C_d/n.
\tag{F}
\]

Use `|e^(-a)-e^(-b)|<=|a-b|e^(-min(a,b))`, (E), and (F) inside the centered region. Outside it, (F) and Gaussian tails give `O_d(e^(-c_dn))`. Integrating polynomial Gaussian moments yields the quantitative continuous-model result

\[
 \operatorname{TV}\left(\frac{M-(N/d)I}{\sqrt n},\,
 \mathcal N_{H_0}(\sqrt n(\rho-I/d),I/d)\right)
 \le C_d(\delta+n^{-1/2}).
\tag{G}
\]

The same argument gives its centered normalization constant with relative error `O_d(delta+n^(-1/2))`. It remains uniform even when `sqrt n delta` diverges arbitrarily quickly. The matrix-function derivative estimates use the scalar divided-difference formulas in fixed dimension, not an assumed nondegenerate LAN theorem.

## 6. Exact-normalizer comparison removes lattice-tail circularity

The ordered trace-zero Gaussian Vandermonde integral is

\[
 J_d=\int_{x_1>...>x_d,\sum x_i=0}\Delta(x)^2e^{-d\|x\|^2/2}\,dx_{HS}
 =c_H(2\pi)^{(d-1)/2}d^{-(d^2-1)/2}.
\]

For completeness, the full Gaussian Vandermonde integral follows by writing the Vandermonde determinant in monic Hermite polynomials and applying determinant integration/orthogonality; it equals `d! c_H (2pi)^(d/2) d^(-d^2/2)`. Divide by `d!` for the ordered chamber and then by the one-dimensional trace Gaussian integral `sqrt(2pi/d)` to obtain `J_d`.

Stirling at the true-state center gives

\[
 a_\rho(M_0)=e^n n^{-(n+R+d/2)}(2\pi)^{-d/2}(\det\rho)^{-1/2}\{1+O_d(1/n)\}.
\]

The trace-zero matrix volume scales as `n^(r/2)`. Its Gaussian integral is translation invariant, so the centered local normalization from (G), expressed in eigenvalue/flag measure, is `J_d` regardless of the true mean. It follows that

\[
 Z_\mathrm{cont}(\rho)
 =\frac{c_H}{n!}d^{-r/2}(\det\rho)^{-1/2}
 \{1+O_d(\delta+n^{-1/2})\}.
\]

Near the tracial spectrum,

\[
 \Delta(p)/\Delta(\log p)=d^{-R}\{1+O_d(\delta)\},\qquad
 (\det\rho)^{-1/2}=d^{d/2}\{1+O_d(\delta)\}.
\]

Since `-r/2+d/2=-R+1/2`, the normalizers satisfy

\[
 \boxed{\frac{Z_\mathrm{cont}(\rho)}{v_d Z_\mathrm{disc}(\rho)}
 =1+O_d(\delta+n^{-1/2}).}
\tag{H}
\]

This is important: good-cell quadrature plus continuous good-cell probability already forces discrete good-cell probability to approach one. No unproved assumption about the close-gap probability of the discrete Schur law is needed, and no tail-estimate normalization loop occurs.

## 7. Uniform deformed-GUE small-gap estimate

Let `theta` be any deterministic traceless Hermitian mean, with decreasing eigenvalues `t`. A Gaussian matrix of covariance `I_H0/d` centered at `theta` has ordered eigenvalue density, up to a dimension-only constant,

\[
 \Delta(x)^2 e^{-d(\|x\|^2+\|t\|^2)/2}
 \int e^{d\operatorname{Tr}(tWxW^*)}d\mu(W).
\]

The established HCIZ estimate gives the uniform upper bound

\[
 C_d e^{-d\|x-t\|^2/2}
 \prod_{i<j}\frac{(x_i-x_j)^2}{1+d(x_i-x_j)(t_i-t_j)}.
\]

For each pair, with `z=x_i-x_j>=0`, `u=t_i-t_j>=0`,

\[
 \frac{z^2}{1+dzu}\le C_d(1+|z-u|)^2
 \le C_d(1+\|x-t\|)^2.
\]

To verify the first inequality, if `u>=z/2`, the ratio is bounded by `2/d`; otherwise `z<=2|z-u|`. If a particular gap is at most `h`, its factor is at most `h^2`. Integrate that gap coordinate over a width-`h` strip on the trace hyperplane, and integrate the remaining coordinates against a shifted Gaussian times a fixed-degree polynomial. The integral is bounded by a dimension-only constant uniformly in the shift `t`. A union over adjacent gaps proves

\[
 \boxed{\Pr(\min_i(x_i-x_{i+1})\le h)\le C_d h^3,}
\tag{I}
\]

uniformly in **every** deterministic mean, including repeated eigenvalues and arbitrarily large mean norms. This uses the HCIZ theorem already needed for the coherent moment; no additional random-matrix anti-concentration theorem is imported.

## 8. Ordinary eigenvalue jitter is asymptotically the continuous model

Take a central matrix neighborhood `||M-M_0||<=L_n sqrt n`, with `L_n=n^(1/8)`, and a lattice gap threshold `K_n=n^(1/8)`. Call a legal integer center `l` good when its adjacent gaps exceed `K_n` and `|l_i-np_i|<=2 L_n sqrt n` for every `i`. Its Voronoi cell is independent of the flag `W`. Every matrix in the central neighborhood with adjacent gaps larger than `K_n+2` lies in such a legal cell for sufficiently large `n`; true eigenvalues are at least `n/(2d)`, so the boundary cannot intervene there.

Under `q_rho`, the central neighborhood has probability `1-o(1)` uniformly by (F)/(G), and (G)+(I) show that the excluded small-gap neighborhood has probability at most

\[
 C_d\{\delta+n^{-1/2}+(K_n/\sqrt n)^3\}.
\]

For a good cell, `|xi_i-xi_j|<=1` gives

\[
 \Delta(l+\xi)^2/\Delta(l)^2=1+O_d(1/K_n).
\]

The smooth factorial/source factor varies little across each good cell, uniformly in *every* flag. The diagonal source values `(W*logrho W)_ii` lie between `log p_min` and `log p_max`, while the digamma derivative at the center satisfies `h'(l_i)=log n+log p_i+O_d(L_n/sqrt n+1/n)`. The scalar `log n` term cancels against the trace-zero jitter. Hence

\[
 \left|\log\frac{a_\rho(l+\xi,W)}{a_\rho(l,W)}\right|
 \le C_d\{\delta+L_n/\sqrt n+1/n\}.
\]

The displayed elementary bound suffices; it has no `delta L_n` or `delta log n` term. If the *full matrix* is also in a central neighborhood, a matrix-logarithm Lipschitz argument improves the term `delta` to zero, but that stronger estimate is not needed for this good-cell proof.

Thus the continuous raw density and its center evaluation agree uniformly on good cells up to

\[
 O_d(\delta+K_n^{-1}+L_n/\sqrt n+1/n)=O_d(\delta+n^{-1/8}).
\]

On these cells the normalized jitter law and `q_rho` consequently have density ratio `1+O_d(delta+n^(-1/8))`, using the exact normalizer comparison (H). As continuous good-cell mass is `1-O_d(delta+n^(-1/8))`, summing this identity also gives the same bound for discrete/jitter good-cell mass. The complements cost at most their two masses. Therefore

\[
 \operatorname{TV}(\text{HCIZ-replaced ordinary-jitter law},q_\rho)
 \le C_d(\delta+n^{-1/8}).
\tag{J}
\]

This is the step that a naive assertion of an exact jitter density would miss: the Weyl/Vandermonde factor is approximated only on well-separated lattice cells, and all omitted cells are controlled using the continuous Gaussian law and the **exact** normalization ratio.

## 9. Finish the two-direction experiment theorem

The actual Schur/coherent law differs from the HCIZ-replaced discrete law by `C_d delta`, uniformly in all sectors, by Section 3. Jitter and the matrix map are Markov kernels and cannot increase TV. Combine this with (J) and (G) to obtain the first inequality in (A).

The exact composition identity (B), contractivity of `S_n`, and the universal coherent-channel trace bound give

\[
 \tfrac12\|S_n(G_{n,\rho})-\rho^n\|_1
 \le\operatorname{TV}(G_{n,\rho},T_n(\rho^n))
 +1-\prod_{i<j}p_j/p_i
 \le C_d(\delta+n^{-1/8}).
\]

This proves uniform strong statistical equivalence throughout every shrinking tracial ball, with universal channels and a fixed Gaussian covariance. All spectra and all eigenbases are unknown parameters of the experiment; no spectrum-dependent decoder resampling is invoked here.

## 10. Scientific limits and validation boundary

The theorem concerns density-operator statistical experiments and trace/TV approximation. It neither preserves arbitrary purifications nor supplies an entropy rate or a computationally efficient Gaussian decoder. The covariance is the tracial HS covariance; it is not asserted to be a uniform classical replacement around a nontracial limiting state. No fixed-spectrum nondegenerate LAN theorem was extrapolated to a collision. The uniform HCIZ estimate is established primary-source input. The gamma/Hermite/lattice identities and explicit channels are the mechanism supporting the stronger shrinking-ball conclusion.

The only load-bearing steps requiring especially careful independent review are (H), with its trace-hyperplane and lattice-covolume constants, and the good-cell normalization argument in (J). They are written explicitly to make a failed implication identifiable. Finite checks can support those identities, but cannot certify the uniform theorem or its novelty.
