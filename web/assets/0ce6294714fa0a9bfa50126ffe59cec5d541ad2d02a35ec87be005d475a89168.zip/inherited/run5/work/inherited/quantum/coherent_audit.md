# Independent coherent-state audit

Date: 7 October 2026. Scope: the proposed higher-dimensional extension of §3 in the supplied handoff. This is an independent analytic derivation plus finite diagnostic checks. It is not an external referee report, a priority claim, or a finite-memory theorem.

## Verdict

The proposed positive-P / coherent-Q argument is correct for every faithful density matrix on C^d and every finite-dimensional irreducible GL(d,C) representation with its U(d)-invariant Hilbert-space structure. The coherent measure-and-prepare channel is the same channel for every spectrum. There is no hidden highest-weight or copy-number dependence in the flag Jacobian.

For a partition λ, put τ_λ(ρ)=π_λ(ρ)/Tr π_λ(ρ), and let C_λ be its highest-weight coherent measure-and-prepare channel. If p_1≥...≥p_d>0 are the eigenvalues of ρ, then the complete-flag proof gives

    C_λ(τ_λ(ρ)) ≥ c_full(ρ) τ_λ(ρ),
    c_full(ρ) = ∏_{i<j} p_j/p_i.

Consequently the proposed coefficient cond(ρ)^(-d(d-1)/2) is valid but unnecessarily weak. Writing η=log(p_1/p_d), one also has

    c_full(ρ) ≥ exp[-floor(d²/4) η].

Using the actual partial flag orbit improves the coefficient to

    c_λ(ρ) = ∏_{i<j: λ_i>λ_j} p_j/p_i,

where λ and p are both put in decreasing order. This is an exact minimum for the pointwise Q/P comparison proved below. It is not claimed to be the largest possible Loewner-order coefficient for the channel output.

The resulting continuous-outcome, globally entanglement-breaking channel Λ_n obeys, for every n,

    sup_U (1/2)||Λ_n((UρU†)^⊗n) - (UρU†)^⊗n||_1
        ≤ 1-c_full(ρ)
        ≤ floor(d²/4) log cond(ρ).

Thus at fixed d, any sequence of spectra approaching the maximally mixed spectrum has a uniformly vanishing reconstruction error using a continuous classical outcome. This statement alone does not count the classical memory or establish optimal finite storage. The Schur label and flag outcome must still be discretized and charged.

## 1. Representation and coherent-state conventions

Let H_λ be the U(d) irrep of dimension D_λ with dominant integral highest weight λ_1≥...≥λ_d, extended to a rational GL(d,C) representation π_λ. For Schur-Weyl sectors λ is a partition of n. Fix a unit highest-weight vector v_λ. The chosen Hilbert structure satisfies

    π_λ(g)† = π_λ(g†),
    π_λ(ρ)>0 and π_λ(ρ)^(-1)=π_λ(ρ^(-1)) for ρ>0.

A full flag F is represented by U∈U(d), with first k columns U_k specifying its k-dimensional subspace. Its coherent projector is

    P_λ(F) = |v_F><v_F|,    v_F=π_λ(U)v_λ.

Changing column phases changes v_F only by phase. When entries of λ repeat, the projector depends only on the corresponding partial flag; using full flags is still legal and only introduces redundant fibers.

Let μ be normalized U(d)-invariant measure on full flags. Irreducibility and the trace give the resolution

    D_λ ∫ P_λ(F) dμ(F) = I_Hλ.

The highest-weight line is preserved by the upper triangular subgroup. Thus for any g∈GL(d,C), π_λ(g)v_F is a nonzero coherent vector for the flag gF. Write

    q_λ(B;F) = <v_F|π_λ(B)|v_F>    (B>0).

For completeness, highest-weight character evaluation after QR gives the explicit formula

    q_λ(B;F) = det(B)^λ_d
                   ∏_{k=1}^{d-1} det(U_k† B U_k)^(λ_k-λ_(k+1)).

This also follows by realizing the highest-weight vector as the Cartan tensor product of exterior-power highest-weight vectors. The normalized representation state and coherent projectors are insensitive to a determinant twist λ→λ+t(1,...,1).

## 2. Exact positive P representation by filtering

Set g=ρ^(1/2), Z_λ=Tr π_λ(ρ). Filtering the identity resolution gives

    τ_λ(ρ) = (D_λ/Z_λ) ∫ π_λ(g)P_λ(F)π_λ(g)† dμ(F)
            = (D_λ/Z_λ) ∫ q_λ(ρ;F) P_λ(gF) dμ(F).

Define the geometric Jacobian by

    dμ(gF) = J_g(F) dμ(F).

For V=gF, normalize π_λ(g)v_F to v_V. Applying π_λ(g)^(-1) back to this vector gives the exact relation

    q_λ(ρ;F) = 1/q_λ(ρ^(-1);V).

The change of variables F=g^(-1)V therefore produces

    τ_λ(ρ) = ∫ p_λ(V) P_λ(V) dμ(V),
    p_λ(V) = (D_λ/Z_λ) J_(g^(-1))(V) / q_λ(ρ^(-1);V).

Every factor is strictly positive. Taking the trace proves ∫p_λ dμ=1. This is an exact probability density, not a formal inverse Berezin transform or a signed quasiprobability.

There is also an exact shifted-highest-weight form. For full flags let

    ν=(d-1,d-3,...,1-d),

the sum of the positive roots. The Jacobian formula below is
J_(ρ^(-1/2))(V)=1/q_ν(ρ^(-1);V). Cartan-product factorization of coherent symbols therefore gives

    p_λ(V) = (D_λ/Z_λ) / q_(λ+ν)(ρ^(-1);V).

For the actual partial orbit replace ν by the sum of the active roots, ν_λ=∑_(i<j:λ_i>λ_j)(e_i-e_j). This weight is dominant and has the same partial-flag stabilizer. This is the general-irrep version of the reciprocal, shifted-spin thermal P formula found in Sidles's SU(2) paper. Negative entries of ν are determinant twists and cause no problem for invertible ρ.

## 3. Q/P comparison and operator direction

The coherent POVM is E_λ(dV)=D_λ P_λ(V)dμ(V). Measuring τ_λ(ρ) gives density

    f_λ(V) = (D_λ/Z_λ) q_λ(ρ;V),

and preparing the measured projector produces

    C_λ(τ_λ(ρ)) = ∫ f_λ(V)P_λ(V)dμ(V).

The ratio is exactly

    f_λ(V)/p_λ(V)
      = q_λ(ρ;V) q_λ(ρ^(-1);V) / J_(ρ^(-1/2))(V).

Apply Cauchy-Schwarz to π_λ(ρ)^(1/2)v_V and π_λ(ρ)^(-1/2)v_V:

    q_λ(ρ;V) q_λ(ρ^(-1);V) ≥ |<v_V|v_V>|² = 1.

Hence f_λ≥p_λ/sup J_(ρ^(-1/2)). The inequality goes in the required direction. Integrating positive projectors yields

    C_λ(τ_λ(ρ)) ≥ [sup J_(ρ^(-1/2))]^(-1) τ_λ(ρ).

No comparison between individual diagonal matrix entries is being substituted for Loewner order. The pointwise density domination directly implies the operator inequality.

If σ=C_λ(τ)≥cτ with both states normalized, then σ=cτ+(1-c)ξ for a density matrix ξ (unless c=1, when σ=τ). Therefore

    (1/2)||σ-τ||_1 ≤ 1-c.

## 4. Full-flag Jacobian, with exponent and orientation derived

Fix F represented by U. Take the positive-diagonal QR decomposition

    gU=VR,

where V is unitary and R upper triangular, r_ii>0. Use the holomorphic lower-triangular coordinate chart L(Z)=I+Z centered at F, and the corresponding chart centered at gF. To first order, g acts by

    Z ↦ projection_to_strict_lower( R Z R^(-1) ).

The tangent quotient is gl(d,C)/b. The determinant of the upper-unipotent part of R on this quotient is one. Its diagonal part multiplies the complex tangent coordinate Z_ji, j>i, by r_jj/r_ii. The U(d)-invariant volume densities at the two chart origins agree. Thus the real Jacobian is

    J_g(F) = ∏_{i<j} (r_jj/r_ii)^2.

This is the real Jacobian: the square of the complex determinant modulus. It is not its square again, and it is not the reciprocal.

Put A=g†g and h_k(F)=det(U_k† A U_k). QR gives h_k=∏_{i≤k}r_ii² and h_d=det A. Consequently

    J_g(F) = det(A)^(d-1) / ∏_{k=1}^{d-1} h_k(F)^2.

Check at d=2 and g=diag(a,b): in the local coordinate [1:z], z↦(b/a)z, so J_g=b²/a² at z=0. The formula has precisely this orientation. In the qubit thermal problem, at the highest-eigenvalue coherent ray the inverse-action Jacobian is p_1/p_2; the Q/P lower coefficient is therefore p_2/p_1, as in §3 of the handoff.

To maximize the inverse-action Jacobian, take A=ρ^(-1). Its increasing eigenvalues are 1/p_1,...,1/p_d. Exterior-power variational bounds give

    h_k(F) ≥ ∏_{i=1}^k (1/p_i),

simultaneously with equality at the flag of the eigenvectors of ρ in decreasing eigenvalue order. Substitution yields

    sup_F J_(ρ^(-1/2))(F) = ∏_{i<j} p_i/p_j.

At this maximizing eigenflag v_F is itself an eigenvector of π_λ(ρ), so the Cauchy-Schwarz product equals one. Therefore the minimum of the pointwise Q/P ratio is exactly c_full. This sharpness is a statement about the chosen P density and pointwise ratio, not necessarily about the operator comparison after integration.

Each individual ratio p_i/p_j is at most cond(ρ), proving the proposed coarse exponent N=d(d-1)/2. A stronger uniform spread estimate follows by putting a_i=log p_i:

    log sup J = ∑_{i<j}(a_i-a_j)
              = ∑_{i=1}^d (d+1-2i)a_i
              ≤ floor(d²/4)(a_1-a_d).

The coefficient floor(d²/4) is optimal as a bound based only on condition number: set the upper half of the eigenvalues to p_1 and the lower half to p_d. Normalization does not change the ratios.

## 5. Partial flags and repeated highest-weight entries

Let consecutive equal entries of λ have block sizes b_1,...,b_k, with prefix sums s_a=b_1+...+b_a. The coherent orbit is

    U(d)/(U(b_1)×...×U(b_k)),

of complex dimension R_λ=∑_{a<b}b_a b_b, and normalized invariant measure gives the same identity resolution. The complex tangent space has only lower off-diagonal blocks Hom(C^(b_a),C^(b_b)), b>a.

For block-upper-triangular R with diagonal blocks R_a, the complex determinant on this tangent space is

    ∏_{a<b} (det R_b)^(b_a) / (det R_a)^(b_b).

Writing A=g†g and h_s=det(U_s†AU_s), its real Jacobian becomes

    J_g(F)=det(A)^(d-b_k)
             ∏_{a=1}^{k-1} h_(s_a)(F)^(-(b_a+b_(a+1))).

Every denominator exponent is positive. The same exterior-power minimum is therefore attained simultaneously at the appropriate eigenflag. For the inverse action,

    sup_F J_(ρ^(-1/2))(F)
       = ∏_{i<j: λ_i>λ_j} p_i/p_j.

This proves the sharper coefficient c_λ. Since the partial and full coherent projectors have the same invariant pushforward measure, their measure-and-prepare channels coincide; only the positive P representation used to prove domination is refined.

Examples:

- If λ=(m,0,...,0), the orbit is CP^(d-1), and
  c_λ=∏_{j>1}p_j/p_1=det(ρ)/p_1^d.
- For two λ blocks of sizes k,d-k, the orbit is the Grassmannian, and
  c_λ=det(ρ)^k/(p_1...p_k)^d.
- If every λ_i is equal, H_λ has dimension one; the partial orbit is a point and c_λ=1. The weaker full-flag bound remains valid.

Thus repeated λ entries, a trivial determinant irrep, or λ_d of order n do not introduce a failure or hidden n factor.

## 6. Scalar shifts, singular density matrices, and scope

For any s>0, π_λ(sρ)=s^(sum λ_i)π_λ(ρ), so τ_λ(sρ)=τ_λ(ρ); the condition number and every coefficient above are also invariant. Under λ→λ+t(1,...,1), π_λ acquires the scalar det(ρ)^t. It cancels from τ, from D_λ, and from q_λ(ρ)q_λ(ρ^(-1)). The coherent rays and partial orbit do not change.

Faithfulness of ρ is used for the inverse action and the positive-density formula. For a singular ρ in a polynomial irrep with Tr π_λ(ρ)>0, a positive P *measure* still exists by taking a weak limit from ρ+εI; the flag space is compact and the coherent projectors are continuous. It need not have a density. The condition-number bound degenerates to c=0 and does not imply a useful uniform approximation. If λ has more rows than rank(ρ), π_λ(ρ)=0 and the corresponding Schur sector has zero probability, so τ_λ is not defined there.

Near a positive scalar matrix, log cond(ρ) tends to zero. If Δ=p_1-p_d, then log cond(ρ)≤Δ/p_d. In a fixed neighborhood of I/d with p_d≥1/(2d), the global error is at most 2d floor(d²/4)Δ. Thus “O_d(spectral spread)” is valid in the maximally mixed collision regime. A collision of some eigenvalues while other positive gaps remain fixed does not by itself make this global full-flag coefficient approach one.

## 7. Global tensor-power reconstruction

Schur-Weyl decomposition has the exact form

    ρ^⊗n ≅ ⊕_λ w_λ(ρ) τ_λ(ρ)⊗I_(m_λ)/m_λ,

where w_λ(ρ) depends only on the known spectrum. A channel measuring λ and the coherent POVM in H_λ, then preparing its coherent projector and maximally mixed multiplicity state, is globally entanglement-breaking. It is defined for every input by discarding inter-sector coherences and multiplicity information, and does not depend on the unknown eigenbasis.

Blockwise operator domination gives

    Λ_n(ρ^⊗n) ≥ c_full(ρ)ρ^⊗n.

Covariance gives the same inequality for every UρU†. This proves the n-uniform trace-distance result in the verdict. One may also average the stronger c_λ sector bounds, but c_full is enough for a common coefficient.

Continuous classical outcomes have not been declared free memory. This result supplies the uniform reconstruction step needed before finite classical label counting; finite quantization, Schur-sector resampling, precision, and gate complexity are separate tasks.

## 8. Finite diagnostics

`work/coherent_audit_checks.py` and its JSON output check the complete and every partial flag shape in d=2,...,7. For each shape, five random faithful spectra/flags are used: 630 cases, including 30 trivial-orbit cases. Checks cover the tangent determinant against the compressed-minor formula, the exact eigenflag extremizer, the P/Q Cauchy-Schwarz direction, and determinant-twist cancellation.

Results: all passed. Maximum absolute log-Jacobian discrepancy was 2.31e-14; eigenflag-extremizer discrepancy 2.85e-14; determinant-twist cancellation discrepancy 1.82e-12. The smallest computed nonnegativity residual was -1.14e-13, consistent with floating-point cancellation in trivial cases. These are finite floating-point algebra checks and do not certify the analytic theorem or the full Schur-channel implementation.

The same script additionally evaluates 126 actual partial-flag chart actions by block LU of R(I+Z), rather than merely comparing two tangent-determinant formulas. The central finite-difference determinant agrees with the analytic Jacobian; its maximum log discrepancy is recorded in the JSON output.

`work/coherent_audit_exact_symmetric.py` and its JSON output use Fraction arithmetic and exact complex-Haar Dirichlet moments to compute the output eigenvalues for Sym^n(C^d). If α and β are d-tuples summing to n, D=binom(n+d-1,d-1), and Z=∑_|α|=n p^α, the exact formula is

    q_α = (D/Z) (n!/α!)
            ∑_|β|=n (n!/β!)p^β
              [(d-1)!∏_i(α_i+β_i)!/(2n+d-1)!].

All 170 representation states and 3,680 output eigenvalues passed exact trace-one, q_α≥c_partial p^α/Z, and TV≤1-c_partial checks. There were five faithful rational spectra per d, including uniform, repeated, nearly uniform, and highly uneven spectra; n ranged from 0 to 14 for d=2, 0 to 10 for d=3, and 0 to 7 for d=4. The deliberate incorrect reciprocal coefficient was rejected in all 124 nonuniform/nontrivial cases. These are exact finite symmetric-power channel checks, not checks of all full-flag irreps or a substitute for the analytic derivation.

## 9. Brief prior-art lookup

The lookup was deliberately bounded and is not a novelty clearance.

- [John A. Sidles, Positive P-Representations of the Thermal Operator from Quantum Control Theory (2004)](https://arxiv.org/html/quant-ph/0401165v1), Theorem 1, gives a closed-form positive spin-j thermal P representation, with a reciprocal Q symbol at shifted spin j+1. Thus exact positive thermal P representation for qubits is established prior art. Its explicit shifted-spin formula agrees with the inverse-Q-plus-Jacobian structure derived here. The paper also remarks that its Lie-group study is confined to SU(2).
- [Benjamin Cahen, Berezin quantization on generalized flag manifolds (2009)](https://www.mscand.dk/article/view/15106) supplies generalized flag coherent-state/Berezin machinery. The present audit does not assert that the underlying coherent-state geometry or filtering idea is new.
- [Hayden, Maloney, Wang, Yang, Quantum minimum description of density matrices, 5 October 2026](https://arxiv.org/html/2610.06742v1), Theorem 1 and the paragraph following it, hold dimension and spectrum fixed and explicitly disclaim uniformity as positive eigenvalues collide or approach zero. The derived bound above is in the moving maximally mixed collision regime and does not contradict that theorem. Its other references include classical-memory impossibility in fixed nontrivial unknown-basis families; no such fixed-spectrum vanishing-error claim is made here.

Possible novelty rests on the exact general-irrep thermal P formula and representation-uniform Q/P domination as a collision tool, and on any fully charged finite-memory consequence. No priority determination is made by this audit.
