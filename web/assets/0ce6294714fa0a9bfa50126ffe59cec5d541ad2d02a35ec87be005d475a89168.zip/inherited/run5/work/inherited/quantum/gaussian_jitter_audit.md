# Independent audit: uniform quantum/Gaussian experiment via root-lattice jitter

Verdict: **the analytic proof passes this independent audit**. In particular, §§6–9 of `work/uniform_gaussian_experiment.md` close the normalization, collision-cell, ordering, and reverse-channel issues. I independently recomputed the constants and supplied the detailed arguments below. The proof uses the previously established universal coherent minorant and the published type-A Graczyk–Sawyer estimate. This is mathematical auditing within the agent team, not external expert review, formal proof certification, or a novelty determination.

An initially plausible gap has been resolved: the orbital-exponential flag law is not literally the coherent POVM law. Its uniform O(δ) conditional replacement is a separate necessary step (§3 below), and the main proof includes it. Ordinary uniform jitter is also not an exact matrix-density identity: its changing Vandermonde factor is handled only on good cells and by the exact normalizer (§§7–8).

## 1. Statement and conventions being audited

Fix d≥2, and set

    r=d²−1,  R=d(d−1)/2,  N=n+R,
    c_H=∏_{k=1}^{d−1}k!.

The state set is B_δ={ρ≥0:Trρ=1, ‖dρ−I‖op≤δ}, with 0≤δ≤1/2. All these states are faithful with eigenvalues p_i≥1/(2d). Let H₀ be the r-dimensional real Hilbert space of traceless Hermitian matrices, with HS norm. The comparison law is

    G_{n,ρ}=Normal_{H₀}(√n(ρ−I/d), I_{H₀}/d).

The proposed channels depend only on n,d and obey

    TV(T_n(ρ^⊗n),G_{n,ρ})≤C_d(δ+n^−1/8),
    (1/2)‖S_n(G_{n,ρ})−ρ^⊗n‖₁≤C_d(δ+n^−1/8).             (1)

Thus every δ_n→0 is allowed, including arbitrary slow shrinkage and unbounded √nδ_n. Covariance is exactly I/d in an orthonormal HS basis of H₀; the trace coordinate is fixed and is not an extra Gaussian variable.

## 2. The correct cell, trace constraint, and exact reverse composition

Let L₀={z∈Z^d:Σ_i z_i=0}. Its basis e_i−e_d, i<d, has Gram matrix I+11ᵀ and determinant d. Hence its covolume in the induced Euclidean/HS hyperplane measure is

    v_d=√d.

Its Euclidean Voronoi cell is exactly

    C={ξ∈R^d:Σξ_i=0, max_i ξ_i−min_i ξ_i≤1}.              (2)

Proof: the nearest-point inequalities against roots e_i−e_j imply every ξ_i−ξ_j≤1. Conversely, for any z∈L₀ let P=Σ_{z_i>0}z_i=Σ_{z_i<0}|z_i|. Then coordinate range at most one gives

    ⟨ξ,z⟩≤P≤(1/2)Σ_i z_i²,

where the last inequality uses integer z_i²≥|z_i|. These are all Voronoi inequalities, so the root inequalities suffice. In particular, |ξ_i|≤(d−1)/d<1 and every pairwise difference has absolute value at most 1.

The Schur label λ gives strict decreasing nonnegative integer eigenvalues

    l_i=λ_i+d−i,  Σ_i l_i=N.

For every such l and ξ in the interior of C,

    l_i+ξ_i>l_j+ξ_j for i<j,
    l_i+ξ_i>−1.

Indeed l_i−l_j≥j−i≥1 and ξ_i−ξ_j>−1 in the interior. Thus uniform ξ preserves order almost surely, even when adjacent integer gaps are only one. It also gives a valid classical matrix M>−I, including the case l_d=0. Jittered eigenvalues can be negative; no positivity constraint belongs to the classical Gaussian observation.

The forward channel measures λ and a complete coherent flag W, samples ξ uniformly in C, and outputs

    Y=[W diag(l+ξ)W*−(N/d)I]/√n.

For the reverse channel, form M=√nY+(N/d)I, take its decreasing eigenvalues x and eigenflag W, and choose a nearest lattice point l in L_N={integer vectors of sum N}. A fixed measurable tie rule suffices. If l is strict decreasing and nonnegative, λ_i=l_i−d+i is a valid partition of n: λ_i−λ_{i+1}=l_i−l_{i+1}−1≥0 and λ_d=l_d≥0. Prepare the coherent λ-sector state, its known mixed multiplicity, and invert Schur. Otherwise return a fixed state.

On every forward output except null cell/eigenvalue boundaries, nearest lattice rounding recovers l, and the preserved ordering recovers the same flag modulo irrelevant phases. Therefore

    S_nT_n=C_{n,d}                                          (3)

exactly, for the universal coherent measure/prepare channel. This is stronger than a good-cell approximate inverse. Gaussian and jittered laws give zero probability to the relevant tie sets, but fixed measurable rules define the channels on them anyway. No unknown spectrum appears in either kernel.

## 3. The necessary coherent-to-orbital replacement

The measured coherent conditional law is proportional to exp(−Φ_λ), with

    Φ_λ=Σ_k ℓ_k b_k,
    ℓ_k=λ_k−λ_{k+1},
    b_k=Σ_{i≤k}logp_i−logdet(W_k*PW_k).

The orbital law uses Γ_λ=Tr(λlogP)−Tr(logP WλW*). Let t_k=Σ_{i≤k}p_i−Tr(PW_kW_k*)≥0 and E=Σℓ_k t_k. Compression/interlacing and scalar log divided differences give, for a=1/p_max and b=1/p_min,

    aE≤Φ_λ,Γ_λ≤bE,
    |Φ_λ−Γ_λ|≤(b−a)E≤C_dδE.

All interpolating potentials stay between aE and bE. The GS orbital normalizer bounds give a uniform expectation of E in each interpolating law: its numerator is at most (2/a)K(a/2), denominator at least K(b), and K(a/2)/K(b)≤C_d because b/a≤3. Differentiating normalized densities therefore gives uniform conditional TV at most C_dδ for **every** λ, with no typical-sector restriction.

Replacing λ by l=λ+(d−1,…,0) changes the orbital potential by at most C_dδ since this shift has fixed dimension-only size. Thus the actual joint measurement law is within C_dδ of the following exact auxiliary law. This step is required; exact sector marginals alone would not establish it.

## 4. Exact auxiliary joint law and its discrete normalizer

The Weyl character and HCIZ formulas give

    m_λ=n!Δ(l)/∏_i l_i!,
    s_λ(p)=det[p_i^{l_j}]/Δ(p),
    I(l,logp)=c_H det[p_i^{l_j}]/[Δ(logp)Δ(l)].

Multiplying the exact Schur-sector law m_λs_λ(p) by its normalized orbital conditional law cancels the determinant. Therefore the auxiliary law ν_ρ on (l,W) has density

    u_ρ(l,W)/Z_disc,
    u_ρ(x,W)=Δ(x)² a_ρ(x,W),
    a_ρ(x,W)=exp[Tr(logρ Wdiag(x)W*)]/∏_iΓ(x_i+1),
    Z_disc=c_H Δ(p)/[n!Δ(logp)].                            (4)

At spectral repetitions the ratio Δ(p)/Δ(logp) is the continuous product of scalar divided differences, strictly positive. Thus no singularity or hidden gap lower bound enters (4). Near the tracial spectrum,

    Δ(p)/Δ(logp)=d^−R[1+O_d(δ)],                            (5)

uniformly over all collisions, because every logarithmic mean lies between p_min and p_max.

## 5. Continuous model: uniform Gaussian domination, including slow δ

On the affine HS matrix space TrM=N, with M>−I, define

    q_ρ(M)∝exp[−V_ρ(M)],
    V_ρ(M)=Tr logΓ(M+I)−Tr Mlogρ.

Its ordered eigenvalue/flag law is u_ρ(x,W)/Z_cont relative to hyperplane HS measure dx and normalized invariant flag measure. The fixed Weyl coarea constant cancels in this normalized law. M>−I contains all forward jittered matrices.

Let M₀=nρ+(R/d)I and Z=(M−M₀)/√n. Direct digamma asymptotics at the eigenvalues m_i=np_i+R/d give

    ∇V_ρ(M₀)=logn I+O_d(1/n).

The scalar term has zero pairing with trace-zero perturbations. Hessian coefficients are ψ′(m_i+1) on diagonal directions and divided differences of ψ(m_i+1) on offdiagonal directions. Hence

    D²V_ρ(M₀)[A,A]=(d/n)‖A‖²
                    +O_d(δ/n+n^−2)‖A‖².

On ‖Z‖≤c_d√n, the entire centered segment has eigenvalues bounded below by c_dn. Polygamma bounds and coalescence-safe divided differences give |D³V[A,B,C]|≤C_dn^−2‖A‖‖B‖‖C‖. Thus

    V(M₀+√nZ)−V(M₀)=d‖Z‖²/2+R_n(Z),
    |R_n(Z)|≤C_d[δ‖Z‖²+(‖Z‖+‖Z‖³)/√n].                 (6)

The global lower bound is equally important. For x>−1,

    ψ′(x+1)=Σ_{k≥0}(x+1+k)^−2≥1/(x+1).

On the trace-N domain, every eigenvalue is less than N+d−1, so all matrix Hessian coefficients are at least 1/(N+d). Strong convexity, with the small trace-tangent gradient at M₀, gives

    V(M₀+√nZ)−V(M₀)≥c_d‖Z‖²−C_d/n.                      (7)

Equations (6)–(7) prove a uniform integrated error directly. Use

    |e^−A−e^−B|≤|A−B|e^−min(A,B).

Both exponents have the quadratic lower bound (7); hence the integrand is bounded by the polynomial in (6) times a fixed Gaussian. Integrating its moments gives O_d(δ+n^−1/2). The part outside the Taylor-valid radius c_d√n is exponentially small by (7) and the Gaussian tail. The normalizer also has relative error O_d(δ+n^−1/2).

Consequently

    TV(q_ρ transformed to Y,G_{n,ρ})≤C_d(δ+n^−1/2).         (8)

This is the reason arbitrarily slow δ_n is valid: no estimate takes the supremum of δ‖Z‖² on an expanding analysis ball. The error is integrated against a uniform Gaussian envelope. Imposing δ_n logn→0 here would be an unnecessary restriction.

## 6. Recomputed continuous normalizer: all constants and n powers

At the scalar center the ordered trace-zero Gaussian Vandermonde integral is

    J_d=∫_{x decreasing,Σx=0}Δ(x)²e^−d‖x‖²/2 dx_HS
       =c_H(2π)^((d−1)/2)d^−(d²−1)/2.                     (9)

Audit of factors: monic-Hermite determinant integration gives the full unordered R^d integral

    d! c_H(2π)^(d/2)d^−d²/2.

Dividing by d! gives the ordered chamber. Decompose the trace direction as t=Σx_i/√d, orthogonal to the trace-zero hyperplane. Its Gaussian integral is √(2π/d), so dividing by that factor gives (9). The trace hyperplane uses induced HS measure, which is essential to the √d covolume comparison.

For a noncentral M₀, the full matrix Gaussian integral is unchanged by translation in the trace-N affine space. The Weyl integration factor is fixed, so its eigenvalue/flag integral is still n^(r/2)J_d. This justifies using (9) even for an arbitrarily large scaled mean √n(ρ−I/d); translating eigenvalues alone would not justify it.

Stirling at m_i=np_i+R/d gives

    a_ρ(M₀)=e^n n^−(n+R+d/2)(2π)^−d/2(detρ)^−1/2
             ×[1+O_d(1/n)].                               (10)

The fixed Weyl shift contributes R to the exponent and cancels in the exponential because Σm_i−R=n. Multiplying (10) by n^(r/2)J_d leaves

    e^n n^−(n+1/2) c_H(2π)^−1/2 d^−r/2(detρ)^−1/2,

because R+d/2−r/2=1/2. Comparing with Stirling for n!, and applying the integrated normalization estimate from §5, yields

    Z_cont=[c_H/n!]d^−r/2(detρ)^−1/2
             ×[1+O_d(δ+n^−1/2)].                           (11)

Since (detρ)^−1/2=d^(d/2)[1+O_d(δ)] and (5) holds,

    Z_cont/(v_d Z_disc)=1+O_d(δ+n^−1/2),  v_d=√d.           (12)

The dimension powers cancel because −r/2+d/2−1/2+R=0. I independently checked these constants against d=2 and d=3: at the tracial spectrum the leading ratios are respectively (1/√2)/(√2·1/2)=1 and [2·3^−5/2]/[√3·2·3^−3]=1.

The exact normalizer identity removes the proposed circular discrete-tail argument. No discrete collision anti-concentration or generic “uniform Riemann sum” assertion is needed.

## 7. Uniform Gaussian small-gap bound: the mean can be arbitrary

For a traceless Gaussian matrix with covariance I/d and any deterministic mean θ, let t be the mean's decreasing eigenvalues and x the random decreasing eigenvalues. The GS type-A estimate, with its uniform constants, gives the upper density bound

    C_d e^−d‖x−t‖²/2
       ∏_{i<j}[(x_i−x_j)²/(1+d(x_i−x_j)(t_i−t_j))].         (13)

This is a normalized Gaussian eigenvalue density: its underlying matrix Gaussian has a dimension-only normalizer, independent of θ. For a=x_i−x_j≥0 and b=t_i−t_j≥0,

    a²/(1+dab)≤C_d(1+|a−b|)²≤C_d(1+‖x−t‖)².

If b≥a/2, the factor is at most 2/d. Otherwise a≤2|a−b|. If a specified adjacent gap is at most h, retain its sharper bound h². Every other factor is bounded by a fixed-degree polynomial in e=x−t. On the trace-zero hyperplane the selected gap condition is a strip

    e_i−e_{i+1}∈[−(t_i−t_{i+1}),h−(t_i−t_{i+1})]

of width h. A Gaussian times a fixed-degree polynomial has uniformly bounded strip density: take the supremum of the one-dimensional Gaussian-polynomial factor in this coordinate and integrate the other coordinates. Thus the strip integral is at most C_dh, uniformly over its center. Multiplying by h² and taking the finite union over adjacent roots yields

    P(min adjacent gap≤h)≤C_dh³.                            (14)

This holds for all θ, including repeated eigenvalues and unbounded mean norm. Source checked live: Graczyk–Sawyer, *Sharp Estimates of Radial Dunkl and Heat Kernels in the Complex Case A_n*, Theorem 3.1, https://arxiv.org/pdf/2012.12022 ; published version https://www.numdam.org/articles/10.5802/crmath.188/ . The uniform HCIZ estimate is established input; (14)'s short deduction is written above.

## 8. Good cells, Vandermonde Jacobian, and total-variation jitter

Take L_n=K_n=n^1/8. Call a legal center l good if its adjacent gaps exceed K_n and |l_i−np_i|≤2L_n√n for every i. This condition depends on the unknown state only for **analysis**, not for either channel.

A continuous matrix satisfying ‖M−M₀‖≤L_n√n and adjacent eigenvalue gaps exceeding K_n+2 belongs to the Voronoi cell of a good legal center. Weyl's eigenvalue bound gives |x_i−(np_i+R/d)|≤L_n√n. The cell radius bounds change each coordinate by less than one and each pairwise difference by at most one. Hence the nearest integer center is strict, nonnegative, trace N, and satisfies the good-center conditions for large n. The lower eigenvalue boundary cannot intervene: np_min≫L_n√n.

By (7), the continuous central neighborhood has complement exponentially small in L_n². By (8) and (14), its small-gap complement has probability at most

    C_d[δ+n^−1/2+(K_n/√n)³]
      ≤C_d(δ+n^−1/8).                                     (15)

Thus the union of all good cells, including every flag above each, has continuous q mass 1−O_d(δ+n^−1/8).

Inside any good cell, uniformly in ξ∈C,

    Δ(l+ξ)²/Δ(l)²=1+O_d(K_n^−1).                           (16)

Indeed each gap changes by at most one and every adjacent center gap exceeds K_n; multiply the finitely many factors. This is the exact Weyl/Jacobian correction that ordinary jitter must account for.

The smooth factor also varies little uniformly over **all** flags W. On the good-center window,

    ψ(l_i+ξ_i+1)=logn+logp_i+O_d(L_n/√n+1/n).

The source terms (W*logρW)_ii are between logp_min and logp_max. Differentiating loga along ξ, the common logn term cancels because Σξ_i=0; every remaining scalar discrepancy is at most

    C_d[δ+L_n/√n+1/n].

Integrating along the bounded cell segment yields

    a_ρ(l+ξ,W)/a_ρ(l,W)
      =1+O_d(δ+L_n/√n+1/n).                                (17)

There is no δL_n or δlogn factor. It is permissible for √nδ to be arbitrarily large. Combining (16)–(17),

    u_ρ(l+ξ,W)/u_ρ(l,W)=1+O_d(δ+n^−1/8).                   (18)

The jittered auxiliary law has spectral-coordinate density u_ρ(l,W)/(v_dZ_disc) on the cell. The continuous law has density u_ρ(l+ξ,W)/Z_cont. Equations (12) and (18) therefore give normalized density ratio 1+O_d(δ+n^−1/8) on the full good-cell union.

Because the continuous good-cell mass is already 1−O_d(δ+n^−1/8), integrating this ratio forces the jittered good-cell mass to have the same bound. The two complements cost at most their masses. Hence

    TV(Jν_ρ,q_ρ)≤C_d(δ+n^−1/8).                            (19)

This is the rigorous normalization argument: the exact ratio (12) precedes the inference about discrete good-cell probability. One cannot infer that probability merely from continuous good-cell mass without (12) or a separately proved normalization estimate.

Coarea is correct on both sides. In matrix coordinates the Jacobian is the same Δ(l+ξ)² at the same output point, so passing the spectral comparison to matrix laws preserves TV. It does not license replacing Δ(l)² by Δ(l+ξ)² exactly; that replacement is precisely (16).

## 9. Bidirectional channels and what the result establishes

The auxiliary law is within C_dδ of the actual coherent measurement law (§3). Jitter is a fixed Markov kernel, so (19) and (8) prove the first inequality in (1). For the reverse direction use the exact identity (3), trace/TV contractivity, and the universal minorant bound:

    error(S_nG_{n,ρ},ρ^⊗n)
      ≤TV(G_{n,ρ},T_nρ^⊗n)+error(C_{n,d}ρ^⊗n,ρ^⊗n)
      ≤C_d(δ+n^−1/8).

This establishes strong, uniform statistical equivalence on **every shrinking ball around I/d**, with unknown spectrum and unknown eigenbasis, and channels independent of both. It is more than a fixed-spectrum memory-rate theorem.

The result preserves density operators and downstream bounded-loss statistical decisions. It does not preserve arbitrary purifications; does not prove analogous classical equivalence around a nontracial limiting state; does not give optimal finite memory constants; and does not establish polynomial gate or machine-precision complexity. Constants depend on fixed d. Scientific priority and external expert validation remain unassessed.

## 10. Audit checklist, resolved failures, and status

| Concern | Resolution |
|---|---|
| Orbital flag law asserted exact for coherent POVM | Separate O(δ) replacement, uniform in every λ |
| Trace coordinate or covolume omitted | Trace fixed at N; induced HS measure; covolume √d |
| Nearest floors violate trace/order | Nearest A_{d−1} lattice point; Voronoi range≤1 preserves order |
| Jittered negative eigenvalues forbidden | Classical M may be negative; q domain M>−I contains jitter |
| Vandermonde changes inside cells | Explicit (16), restricted to high-probability good cells |
| Discrete bad-cell mass assumed small | Derived from exact normalizer ratio plus continuous good mass |
| Uniformity fails for slow δ_n | Integrated Gaussian domination, and cell score O(δ+L/√n) |
| Eigenvalue collisions invalidate gap control | Uniform GS-derived h³ bound, including arbitrary mean collisions |
| Decoder secretly knows ρ | Rounding, flag recovery, and coherent preparation use only n,d |
| Reverse approximation requires a second jitter proof | Exact S_nT_n=C_{n,d} suffices by contractivity |

No analytic counterexample or unresolved load-bearing implication remains in the audited §§6–9. The status is **proved within this written argument using its stated established inputs**, with independent team audit; it is not externally certified and no novelty claim is made.
