# Spectral threshold repetition in the commuting-operator model

Status: COMPLETE_INTERNAL_DERIVATION; independent operator/game gate by
frontier_quantum_bridge and a third full adversarial reconstruction by
frontier_functional both PASS on the stated interface. No external
validation, formal verification, or historical novelty certificate is claimed.
This changes the source's strategy interface; it is not an automatic
corollary obtained by identifying commuting and finite tensor models.

## Question, assumptions and theorem

Let G be a finite two-player one-round game, with classical finite question
sets X,Y, finite nonempty answer sets A,B, known law mu on X times Y and
Boolean acceptance V. A commuting strategy consists of a Hilbert space H,
a unit vector psi, and POVMs M_x^a,N_y^b on H with

    [M_x^a,N_y^b]=0 for EVERY x,y,a,b.

H may be infinite dimensional; it need not carry a tensor factorization
or a trace. Define omega^co(G) as the supremum of
sum mu(x,y)V(x,y,a,b)<psi,M_x^a N_y^b psi> over these strategies.
The corresponding repeated strategy has arbitrary joint local POVMs for
the complete question/answer strings, subject to the same cross
commutation condition.

This value agrees with the conventional projective-measurement commuting
value. An explicit dilation that preserves all cross commutators is given
in Section 7 below. This equivalence changes the measurement description
within the commuting model; it does not identify that model with finite
tensor-product entanglement.

On the positive-mass pair graph H_mu, adjacent pairs share a local input.
For every non-singleton component j put mu_j=mu(.|j),
P_j=(P_X+P_Y)/2 on L2(mu_j), and

    sigma_j=gap(I-P_j on the orthogonal complement of constants).

Take sigma=min_j sigma_j, with sigma=1 if all components are singletons.
Connectedness and finiteness ensure sigma>0. All logarithms are natural.

**Internally derived theorem.** For v=omega^co(G)<1, 0<delta<1-v,
k>=1, and every commuting strategy for the independent k-fold questions,

    Pr[W_k >= ceil((v+delta)k)]
       <= exp[-sigma delta^3 k/(2048(1+log(|A||B|)))].       (T)

The bound passes to the supremum. If the support is connected, 2048 can
be replaced by 1024. Taking delta upward to 1-v at fixed k gives the
all-wins consequence

    omega^co(G^tensor k)
       <= exp[-sigma(1-v)^3 k/(2048(1+log(|A||B|)))].       (A)

In particular, since every finite question law has finitely many connected
components with positive gaps, this yields qualitative exponential
threshold and all-wins repetition for every finite game with commuting
value below one. The rate depends on its given question law; this is not
a universal gap-free cubic rate or an efficient gap-acquisition theorem.

## Origin of the claim and source boundary

OpenAI's 2026-09-25 finite-tensor preprint at release commit
adc7f1241b42e322a6451854ab7e4b4c146bf78a supplies the resolvent/Jensen
construction, weighted mixed exposure and scalar threshold transfer.
All those source files were read fully and their finite derivation was
independently checked in `FINITE_REPETITION_GATE.md`.

Frontier_quantum_bridge replaces a component root by its mean and obtains
the finite-tensor spectral rate in
`notes/frontier_quantum_bridge/cycle19/SPECTRAL_BARYCENTER_REPETITION.md`.
This worker then asked whether two commuting algebras could be retained
by giving each side a separate resolvent ancilla. The following proof is
our additional deduction. It does not use Song's sampler or the source's
finite common-span compression. The latter is not an appropriate repair
for an arbitrary commuting representation.

The independent hostile reconstruction is
`notes/frontier_quantum_bridge/cycle19/COMMUTING_RESOLVENT_INDEPENDENT_GATE.md`.
The third reconstruction, including a genuinely non-type-I stress case, is
`notes/frontier_functional/cycle19/COMMUTING_REPETITION_ADVERSARIAL_AUDIT.md`,
with structured verdict in that worker's COMMUTING_GATE_REPORT.json.
Agreement between these internal reconstructions is not independent
external validation.

## 1. Resolvent maps on an arbitrary Hilbert space

For bounded T>=0 define F_T:H -> L2((0,infinity),ds) tensor H by

    (F_T h)(s)=T(T+sI)^(-1)h.

The spectral theorem and scalar integral int t^2/(t+s)^2 ds=t give
F_T*F_T=T in every Hilbert space. For an effect this is a contraction.
Define a bounded partial isometry WITHOUT an unbounded inverse by

    (V_T h)(s)=sqrt(T)(T+sI)^(-1)h.

Then V_T*V_T=Pi_T by int t/(t+s)^2 ds=1 for t>0, zero for t=0,
and F_T=V_T sqrt(T). Strong measurability follows from norm continuity
in s for each h. The vector integrals are well-defined; no finite rank
or positive lower spectral bound is required.

The Jensen bound also extends in operator norm. First use A_l+epsilon I
and B+epsilon I, with B=sum q_l A_l. These operators are bounded below.
For completeness, for any such bounded positive ensemble, set D_l=A_l-B.
The scalar integral f(t)=int_0^infinity[t/(1+s)-t/(t+s)]ds and functional
calculus give its Jensen gap. The exact inverse identity is

    (A_l+s)^(-1)=(B+s)^(-1)-(B+s)^(-1)D_l(B+s)^(-1)
       +(B+s)^(-1)D_l(A_l+s)^(-1)D_l(B+s)^(-1).

The linear term averages to zero. Thus the gap equals the positive integral

    int_0^infinity s sum_l q_l(B+s)^(-1)D_l
                          (A_l+s)^(-1)D_l(B+s)^(-1) ds.

The difference Gram of F_A_l-F_B has the same expression with middle
factor s(A_l+s)^(-1) replaced by s^2(A_l+s)^(-2). It is dominated since
s(A_l+s)^(-2)<=(A_l+s)^(-1), then by congruence. The integrands are
bounded near zero at a positive lower spectral bound and O(s^(-2)) at
infinity. These are norm-convergent integrals even for noncommuting
ensemble members on arbitrary H. Applying this to the shifted ensemble gives

    sum q_l(F_(A_l+epsilon)-F_(B+epsilon))*
                   (F_(A_l+epsilon)-F_(B+epsilon))
       <=sum q_l f(A_l+epsilon I)-f(B+epsilon I),             (1)

where f(t)=t log t, f(0)=0. The argument applies to bounded positive
operators, so their upper bound 1+epsilon causes no problem.

For a scalar t>=0,

    ||F_(t+epsilon)-F_t||_L2^2
      =epsilon^2 int_0^infinity s^2/
         [(t+epsilon+s)^2(t+s)^2] ds
      <=epsilon^2 int_0^infinity (epsilon+s)^(-2) ds
      =epsilon.

Functional calculus gives ||F_(T+epsilon I)-F_T||<=sqrt(epsilon).
All difference Grams on the left of (1) therefore converge in norm, and
continuity of f on [0,2] gives norm convergence on the right. Letting
epsilon go to zero proves

    sum q_l(F_A_l-F_B)*(F_A_l-F_B)
       <=sum q_l f(A_l)-f(B).                               (2)

Thus a continuous spectrum accumulating at zero is covered. Restricting
to supp B and treating its inverse as bounded would have been invalid
in this infinite-dimensional step.

## 2. Bounded transport in one von Neumann algebra

Let mathcal A be a von Neumann algebra on H, T in mathcal A an effect,
and G_a in mathcal A positive with sum_a G_a=T. Define a positive form
on ran sqrt(T) by

    q_a(sqrt(T)u,sqrt(T)v)=<u,G_a v>.

It is well-defined since ker T is contained in ker G_a. Positivity and
G_a<=T give |q_a(u',v')|<=||u'|| ||v'|| and
0<=q_a(u',u')<=||u'||^2. It extends to the closure supp T and determines
a unique contraction C_a supported there, satisfying

    G_a=sqrt(T) C_a sqrt(T),       sum_a C_a=Pi_T.            (3)

The bounded regularizations belong to mathcal A and converge strongly:

    (T+epsilon I)^(-1/2)G_a(T+epsilon I)^(-1/2)
       =R_epsilon C_a R_epsilon  -> C_a,
    R_epsilon=sqrt(T)(T+epsilon I)^(-1/2) -> Pi_T.

Von Neumann strong closure implies C_a belongs to mathcal A. This proves
both existence and algebra membership instead of assuming an unbounded
T^(-1/2)G_aT^(-1/2) formula is meaningful.

Every D in mathcal A' intertwines V_T and I tensor D, since each
sqrt(T)(T+s)^(-1) commutes with D. Therefore

    Q_a=V_T C_a V_T* + 1_(a=a_*)(I-V_T V_T*)                 (4)

commutes with I tensor mathcal A'. The commutant identity gives
Q_a in B(L2_s) bar-tensor mathcal A. It is positive, sums to I, and

    F_T* Q_a F_T=sqrt(T) C_a sqrt(T)=G_a.                   (5)

This includes T=0, where V_T=C_a=0 and the completion always outputs a_*.
The construction depends only on T,G_a and retains membership in the
amplification of the ORIGINAL local algebra.

## 3. Simultaneous transport preserves commutation and the joint law

Take commuting von Neumann algebras mathcal A,mathcal B on H, T,G_a
in mathcal A, S,K_b in mathcal B, and sum_a G_a=T, sum_b K_b=S.
The common target is

    Htilde=L2_s tensor L2_t tensor H.

Alice's transported Q_a acts on (s,H) and belongs to
B(L2_s) bar-tensor I_t bar-tensor mathcal A. Bob's R_b acts on (t,H)
and belongs to I_s bar-tensor B(L2_t) bar-tensor mathcal B. These two
amplified algebras commute: their auxiliary actions use distinct factors,
and every original Alice coefficient commutes with every Bob coefficient.

Define the unnormalized vector

    Psi_TS(s,t)=T(T+s)^(-1) S(S+t)^(-1)psi.                  (6)

It is the sequential application of F_T in the s register and the lift
of F_S in the t register. Its squared norm is <psi,TS psi> by separate
spectral integration, since T and S commute.

For the exact joint probability, Alice's Q_a commutes with S and K_b,
and intertwines the t-purification of S. Consequently

    <Psi_TS,Q_a R_b Psi_TS>
       =<F_T psi,Q_a (I_s tensor K_b)F_T psi>
       =<psi,G_a K_b psi>.                                (7)

The first equality is Bob's pullback (5); the second is Alice's pullback,
using that F_T intertwines all Bob operators. This is an operator identity
on H, not an approximation of commuting correlations by tensor ones.
All inputs' transported Alice POVMs belong to the same amplified Alice
algebra, and all Bob POVMs belong to the same amplified Bob algebra, so
cross commutation holds for ALL choices of inputs, not merely at a chosen
question pair.

## 4. The exposure lemma survives, with exact costs

Fix any repeated commuting strategy and let mathcal A,mathcal B be the
von Neumann algebras generated by its entire local POVM families. They
commute. Coarse effects and all conditional averages still belong to the
corresponding original algebras.

Fix proper C with p=Pr(E_C)>0, m=k-|C|, d_C=d^|C|, L=log(d_C/p),
tau=L/m, and a fixed ordering 1,...,m of the live coordinates. Define
Omega_j=(X_C,Y_C,X_<=j,Y_>j), j=0,...,m. Given Omega_j under the
ORIGINAL product-of-pairs question law, the two full local question
strings are independent: both questions at tested positions are fixed;
one question at every live position is fixed and its mate is sampled
conditionally, independently over positions. No conditioning on answers
has yet occurred.

Let M_xvec^alpha sum Alice's joint POVM effects with tested answers
a_C=alpha; define N_yvec^gamma analogously. Set

    F_j^alpha=E[M_Xvec^alpha|Omega_j],
    H_j^gamma=E[N_Yvec^gamma|Omega_j],
    theta=product_(c in C) V(X_c,Y_c,alpha_c,gamma_c).

The answer strings are indices, not conditions on the question law.
Conditional independence gives, for every j,
E_Omega_j sum_(alpha,gamma) theta chi(F_j^alpha,H_j^gamma)=p.

At mode i put r0=(X_C,Y_C,X_<i,Y_>i), nu_i=law(r0), independent of
the fresh pair z=(x,y). Define F_x^alpha=E[M_Xvec^alpha|r0,X_i=x]
and H_y^gamma=E[N_Yvec^gamma|r0,Y_i=y], then
F_y^alpha=E_(x|y)F_x^alpha and H_x^gamma=E_(y|x)H_y^gamma.
The effects at Omega_(i-1) are (F_y,H_y), and those at Omega_i are
(F_x,H_x). Zero conditional weights are omitted; zero-mass inputs may
use arbitrary complete POVMs.

For r=(r0,alpha,gamma), put w_i(r)=nu_i(r0)theta(r), using counting
measure on the answer strings. These weights need not sum to one.
Use (6) to define f_ir(z)=Psi_(F_x^alpha,H_y^gamma),
a_ir(x)=Psi_(F_x^alpha,H_x^gamma), and
b_ir(y)=Psi_(F_y^alpha,H_y^gamma). Their norms obey

    ||f_ir(z)||^2=chi(F_x,H_y),
    ||a_ir(x)||^2=E_(y|x)||f_ir(z)||^2,
    ||b_ir(y)||^2=E_(x|y)||f_ir(z)||^2.

All three families use the same Htilde, which may be infinite dimensional.
The conditional transcript/question law is exactly
w_i(r)mu(x,y)||f_ir(z)||^2/p. Normalizing only w_i would change the law.

Finer effects G_x^(alpha,a)=E[M_Xvec^(alpha,a_i=a)|r0,X_i=x] and
K_y^(gamma,b)=E[N_Yvec^(gamma,b_i=b)|r0,Y_i=y] sum to F_x,H_y.
Fixing r0,x,y makes X_>i and Y_<i independent with law
product_(j>i)mu(X_j|Y_j) product_(j<i)mu(Y_j|X_j). Thus the original
joint answer mass is chi(G_x^(alpha,a),K_y^(gamma,b)). Formula (7)
reproduces it exactly with POVMs depending only on (i,r,x) and (i,r,y).
At positive norm, division by ||f_ir(z)||^2 gives the conditional fine
answer law; zero norm or theta=0 has no conditional mass. The transcript
is still an analysis variable, until Section 5 creates a legal resource
independent of the fresh questions.

Write chi(A,B)=<psi,AB psi>. For B in the positive Bob algebra, the
functional A->chi(A,B) on the Alice algebra is positive and normal:

    chi(A,B)=<sqrt(B)psi,A sqrt(B)psi>.

Its mass is g=chi(I,B)<=1. Scalar spectral-measure Jensen gives exactly
-chi(f(F),B)<=h log(g/h)<=-h log h, where h=chi(F,B).
Define

    U_j=E_Omega_j sum_(alpha,gamma) theta chi(f(F_j^alpha),H_j^gamma),
    Z_j=E_Omega_j sum_(alpha,gamma) theta chi(F_j^alpha,f(H_j^gamma)).

Here f(t)=t log t remains distinct from the vector notation f_ir.
For h0(t)=-t log t, the preceding scalar bound and binary theta give
-U_j<=E sum h0(theta h)<=d_C h0(p/d_C)=pL by scalar Jensen over
flags and the d_C answer pairs. Since f(effects)<=0, U_j<=0.
Interchanging the players proves the same range for Z_j. No von Neumann
entropy, density matrix, finite trace or tracial embeddability is assumed.

For the squared distance to the y-description, integration gives

    ||Psi_(F_x,H_y)-Psi_(F_y,H_y)||^2
       =chi((F_(F_x)-F_(F_y))*(F_(F_x)-F_(F_y)),H_y).

The Gram on the right belongs to mathcal A and commutes with H_y.
Linearity and the two conditional averages give the exact increments

    U_i-U_(i-1)=E_(nu_i mu_Y) sum theta
       chi(E_(x|y)f(F_x)-f(F_y),H_y),
    Z_(i-1)-Z_i=E_(nu_i mu_X) sum theta
       chi(F_x,E_(y|x)f(H_y)-f(H_x)).

Apply (2) to F_x at fixed y and evaluate against the positive functional
chi(.,H_y). This bounds the average ||f_ir-b_ir||^2 by the first
increment. The reversed argument bounds ||f_ir-a_ir||^2 by the second.
Both increments are nonnegative. Telescoping over the fixed ordering and
using U_j,Z_j in [-pL,0] gives two budgets pL and total 2pL.

Writing w_ir=w_i(r)/m, c_ir(z)=||f_ir(z)-a_ir(x)||^2+
||f_ir(z)-b_ir(y)||^2, and sbar as the mean conditional win rate of the
live coordinates, the mass, fine-law and error calculations prove

    sum_ir,z w_ir mu(z)||f_ir(z)||^2=p,
    sum_ir,z w_ir mu(z)c_ir(z)<=2p tau,
    sum_ir,z w_ir mu(z)<f_ir(z),W_ir(z)f_ir(z)>=p sbar.       (8)

W_ir(z)=sum V Q_(r,x)^a R_(r,y)^b is an effect because its POVM
products are commuting positive operators and their sum is I.

## 5. Barycenter rounding gives a legal commuting strategy

The scalar graph Poincare bound applies to Hilbert-valued functions in
Htilde. For a fixed finite graph, their vector span is finite dimensional,
so this can be seen by decomposing that finite span into an orthonormal
basis; no operator or tensor compression is performed. The fixed space
of (P_X+P_Y)/2 is the intersection of the local-function spaces; sharing
local questions across a connected support graph forces that intersection
to be the constants. Conditional means are least-squares optimal, so

    sigma_j Var_j(f_ir)
      <=(E_mu_j||f_ir-P_Xf_ir||^2+E_mu_j||f_ir-P_Yf_ir||^2)/2
      <=E_mu_j c_ir/2.

Put lambda_j=mu(component j), beta_ir,j=E_mu_j f_ir(z), and define

    P_j=sum_ir w_ir E_mu_j||f_ir(z)||^2,
    E_j=sum_ir w_ir Var_j(f_ir),
    P_hat_j=sum_ir w_ir||beta_ir,j||^2,
    T_j=sum_ir w_ir E_mu_j<f_ir(z),W_ir(z)f_ir(z)>,
    T_hat_j=sum_ir w_ir E_mu_j<beta_ir,j,W_ir(z)beta_ir,j>.

Thus sum_j lambda_j P_j=p and sum_j lambda_j T_j=p sbar by (8).
Singleton component variance is zero. Orthogonal decomposition and the
preceding Poincare bound give

    P_hat_j=P_j-E_j,        E=sum lambda_j E_j<=p tau/sigma. (9)

For P_hat_j>0, take shared Hilbert space ell2(ir) tensor Htilde and state

    P_hat_j^(-1/2) sum_ir sqrt(w_ir)|ir> tensor beta_ir,j.

Both players' POVMs are block diagonal on the SAME finite classical flag
register. Within every block their transported operators commute by
Section 3, so all Alice and Bob controlled POVMs commute. Their state
is independent of the new questions. Its component success is
T_hat_j/P_hat_j, therefore T_hat_j<=v_j P_hat_j with
v_j=omega^co(G_j). If P_hat_j=0, T_hat_j=0.

The norm/effect Cauchy-Schwarz bound gives

    |T_j-T_hat_j|<=(sqrt(P_j)+sqrt(P_hat_j))sqrt(E_j)
                    <=2sqrt(P_j E_j),
    T_j<=v_j P_j+2sqrt(P_j E_j).

Indeed for an effect W, the difference of the two quadratic forms is at
most (||f||+||beta||)||f-beta||; weighted Cauchy-Schwarz proves the
first inequality. There is no linear E_j term or second mass comparison.

Every local question identifies its support component. Tensoring the
finitely many component COMMUTING representations gives a legal
commuting strategy for the full game, so sum lambda_j v_j<=v.
This tensoring of different shared representations does not assert that
the original Alice and Bob algebras factor within any representation.

The exact conditional component weights are
lambda_tilde_j=lambda_j P_j/p=(1/m)sum_i Pr[J_i=j|E_C]. Their joint
conditioned likelihood ratio is at most 1/p relative to lambda^tensor m.
Product relative entropy, Pinsker and Cauchy-Schwarz give

    TV(lambda_tilde,lambda)<=sqrt(log(1/p)/(2m)).

Combining these facts with (9) proves

    sbar<=v+sqrt(log(1/p)/(2m))+2sqrt(tau/sigma).             (10)

The drift term vanishes for connected support. All normalizations and
zero-vector cases are accounted for; neither local acquisition nor
efficient preparation of beta is needed for a value upper bound.

## 6. Threshold transfer and short repetition lengths

At T=sigma delta^2/128, tau<=T makes the excess in (10) at most
delta/16+delta/sqrt(32)<delta/4. Also T<=delta/4. In connected support
the drift is zero and T=sigma delta^2/64 suffices. The remaining argument
is scalar, with no independence assumption on the win indicators.

First, any single-coordinate marginal has success at most v: fix every
other question pair, insert the fresh x,y at that coordinate, run the
joint POVMs, and sum out all other answers. These are complete commuting
single-game POVMs. Average over the fixed pairs using the original
product law. If v=0, all win indicators vanish almost surely and the
theorem is immediate.

Here is the complete selection and transfer for v>0 (the same scalar
calculation also works for v=0). Write W=sum_i I_i and E_C=all tested
coordinates won. For arbitrary 0<q0<q<1 and epsilon in (0,1), let
p_H=Pr[W>=ceil(qk)]>0 and

    ell=ceil(log(4/(epsilon p_H))/log(q/q0)).

Draw ell independent uniform coordinate indices WITH replacement and
let C be their distinct set. For each draw set a_C=Pr(E_C),
b_C=Pr(E_C,W<q0k), and A0=p_H q^ell. Then

    E_draw a_C=E(W/k)^ell>=A0,
    E_draw b_C<=q0^ell<=epsilon A0/4.

Draws with a_C<A0/2 contribute at most A0/2 to E_draw a_C; draws with
b_C>epsilon a_C contribute at most E_draw b_C/epsilon<=A0/4. Their
union cannot exhaust the at-least-A0 total a_C mass. A remaining draw
therefore supplies a fixed set with

    |C|<=ell,  p_C>=p_H q^ell/2,
    Pr[W<q0k|E_C]<=epsilon.                               (S)

Apply this with q=v+delta, q0=v+delta/2, eta=delta/16, epsilon=eta,
r=log(q/q0), R=log(d/q), and c=delta T/[16(1+log d)]. The inequalities
r>=delta/(2q), q log(1/q)<=1/e, and delta<1 give

    c/r<=T/8<=eta/2,
    c(1+R/r)<=3T/16.

The second follows from delta(1+R/r)<=delta+2q log d+
2q log(1/q)<=3(1+log d). Put t=1+log(4/eta)/r and B0=log2+Rt.
Choose k0 with t/k0<=eta/2 and B0/k0<=T/16. This choice depends only
on the displayed game parameters, not the strategy or its Hilbert space.

If k>=k0 and p_H>=exp(-ck), (S) gives ell<=ck/r+t and |C|<=eta k<k.
Since W-|C| is nonnegative on E_C and the tested wins are certain there,

    E[W-|C| | E_C]/(k-|C|)
      >=(1-eta)(q0-u)/(1-u)>=q0-eta=v+7delta/16,
    u=|C|/k<=eta.

The function (q0-u)/(1-u) is decreasing, justifying the second step.
On the other hand, the first guarantee of (S) gives

    log(1/p_C)+|C|log d<=log(1/p_H)+log2+ell R,
    tau(C)<=[c(1+R/r)+B0/k]/(1-eta)
             <=T/[4(1-eta)]<T.

The conditioning estimate then gives at most v+delta/4, a contradiction.
Thus the rate exp(-ck) holds for all k>=k0.

For a short fixed k-strategy, take N independent copies on H^tensor N.
Alice and Bob string POVMs are tensor products over copies; all cross
operators still commute, and the product vector makes block outcomes
independent. If every block meets its threshold, probability p_H^N, the
global threshold is met because N ceil(qk)>=ceil(qNk). For Nk>=k0 the
bound yields p_H^N<=exp(-cNk), hence p_H<=exp(-ck). This proves every
k and passes to suprema without attainment or finite dimension. Inserting
the two budgets T proves (T) and its connected improvement. All-wins is
a subevent of each threshold event; letting delta increase to 1-v at
fixed k proves (A).

## 7. POVM/projective interface equivalence

For a finite Alice POVM M_x^a in mathcal A let
K_A=ell2(A) tensor H and define the isometry

    W_x h=sum_a |a> tensor sqrt(M_x^a)h.

On H direct-sum K_A define the unitary into K_A direct-sum H

    U_x(h,k)=(W_x h+(I-W_x W_x*)k, W_x* k).                 (11)

The isometry identity W_x*W_x=I and orthogonal range/complement
decomposition prove both U_x*U_x=I and U_x U_x*=I. Let E_a be the
answer-coordinate projection on K_A, assigning the extra H summand
to a fixed default answer. The operators U_x*E_a U_x are complete
orthogonal projections. Their compression to the initial H summand is
W_x*E_a W_x=M_x^a.

Every matrix coefficient of (11) belongs to mathcal A, because it uses
sqrt(M_x^a), products, sums and identity. Regard its two direct sums as
the same (|A|+1)-dimensional scalar ancilla tensor H, with a fixed
permutation of scalar coordinates. Thus all dilated Alice measurements
belong to B(C^(|A|+1)) bar-tensor mathcal A. Dilate Bob on a DISTINCT
scalar ancilla with coefficients in mathcal B. These amplified algebras
commute for all local questions. In the state |0>_A|0>_B tensor psi,
compressing both ancillas preserves each joint probability
<psi,M_x^a N_y^b psi>. This holds with arbitrary H and needs no finite
approximation, finite trace or Murray-von Neumann cancellation premise.

Therefore any commuting POVM strategy has a commuting projective
realization on an allowed larger Hilbert space. The reverse inclusion is
immediate, so the value and the theorem are independent of these two
standard measurement conventions. Apply the same construction to joint
answer-string POVMs at a fixed repetition length if needed.

## Decisive obstructions and downstream use

The new state may be infinite dimensional and may lie outside the original
algebra's representation. It is nevertheless permitted by omega^co.
Discarding this strategy-model allowance would leave a gap: we have no
claim that the rounded strategy remains in a fixed factor, a prescribed
type-II_1 representation, a finite tensor model, or a hardware-limited
class. There is likewise no universal cubic constant with sigma removed.
The almost-disconnected 2x2 question law has sigma approaching zero.

For efficiently specified verifier families with a supplied or certified
sigma>=1/poly(n), completeness c and commuting soundness s with
Delta=c-s>=1/poly(n), midpoint threshold gives

    completeness >=1-exp(-Delta^2 k/8),
    commuting soundness <=exp[-sigma(Delta/2)^3 k/
                                  (2048(1+log d))].

Hence any target error exp(-L) is reached with

    k>=max{8L/Delta^2, 16384(1+log d)L/(sigma Delta^3)}.

This directly amplifies the original question law and keeps two players
and one round. Question and answer strings grow by factor k. The referee's
score predicate spans k tests; no constant-query, sparse-isometry,
constant-locality Hamiltonian or quantum PCP theorem is produced.
The theorem also applies when finite tensor soundness is not known but
a commuting soundness upper bound is supplied; conversely it cannot
replace v^co by a smaller v* when they differ.

## Nearest primary prior art and novelty status

The graph/Poincare mechanism is classical prior art: Dinur, Harsha,
Venkat and Yuen, arXiv1610.08349v2 (2017-06-26), Definitions 2/4 and
Theorem 6. Their value is classical multiplayer; their theorem is
all-wins. It does not supply the commuting measurement construction.

Verified exact commuting comparator: Junqiao Lin, *MIPco=coRE*,
[arXiv2510.07162v1](https://arxiv.org/abs/2510.07162v1), submitted
2025-10-08. Theorem 9.3 and Appendix A, Theorem A.1, prove an
all-wins repetition estimate for G_bottom, an anchored transformation,
with exponent proportional to epsilon^17 and prefactor 16/epsilon.
Appendix A explicitly assumes anchored games or games arising from the
anchoring transformation. The author's main complexity result and the
remainder of its 167-page proof were NOT audited here. Our primary read
scope is the exact repetition theorem and surrounding assumptions.

Our additional claim concerns every given finite question law, every
threshold above omega^co and a linear-sigma cubic rate. This materially
differs from the verified anchored comparator. A bounded primary search
did not find the same statement, but that is insufficient to establish
historical novelty. The third adversarial operator-algebra/game audit has
finished PASS after full reconstruction, including a non-type-I singular
spectrum case. Broader priority review and external/formal validation
remain outstanding.
Primary snapshots and precise read depths are in `PRIOR_METADATA.json`.

## Uniform cubic consequence of the verified anchoring transformation

This is an additional deduction from (T), independently derived by the
third auditor and checked here. Lin Definition 9.1 independently erases
each local question with probability 1/2. The resulting law mu_bottom has
mass mu(x,y)/4 on ordinary pairs, mu_X(x)/4 on (x,bottom), mu_Y(y)/4
on (bottom,y), and 1/4 on (bottom,bottom). Its support is connected.

For centered local functions a(x),b(y) under the erased marginals, let
ma=E_mu_X a and mb=E_mu_Y b on their ordinary inputs. Centering gives
a(bottom)=-ma and b(bottom)=-mb. Expanding the four branches yields

    <a,b>_mu_bottom=Cov_mu(a,b)/4,
    ||a||_mu_bottom,X^2=Var_mu_X(a)/2+|ma|^2,
    ||b||_mu_bottom,Y^2=Var_mu_Y(b)/2+|mb|^2.

Cauchy-Schwarz on the original covariance gives
|<a,b>_mu_bottom|<=(1/2)||a|| ||b||. For centered f on the anchored
pair law put S0=||P_Xf||^2+||P_Yf||^2. The local correlation bound gives
||P_Xf+P_Yf||^2<=3S0/2. Since S0=<f,P_Xf+P_Yf>,
S0<=||f||sqrt(3S0/2) and <f,Pf>=S0/2<=3||f||^2/4.
Therefore sigma_bottom>=1/4, uniformly over the original question law.

The acceptance rule uses the original predicate on ordinary pairs;
erased branches require the erased player to answer bottom and accept
arbitrary answers from any ordinary player. Their total mass is 3/4.
For the upper value bound, an arbitrary transformed strategy on ordinary
inputs still has the extra bottom answer. Merge its bottom POVM effect
into a fixed original answer for each side. Positivity, completeness and
all-input cross commutation are preserved, and original-branch acceptance
can only increase: originally accepting ordinary answer pairs remain
unchanged, and the added terms are positive. Thus that branch has success
at most v=omega^co(G); the anchor branches have success at most one.
Conversely a near-optimal original strategy, answering bottom deterministically
on erased input, succeeds on every anchor branch. Taking suprema gives

    omega^co(G_bottom)=(3+v)/4.

Using sigma_bottom>=1/4, answer product
d_bottom=(|A|+1)(|B|+1), the connected constant 1024, and the all-wins
endpoint of (T), for v<=1-epsilon gives

    omega^co(G_bottom^tensor r)
      <=exp[-epsilon^3 r/(262144(1+log d_bottom))].         (C)

The same argument applies in the finite tensor model. This has cubic gap
power and no prefactor, whereas the exact primary Lin Theorem 9.3/A.1
states power 17 and prefactor 16/epsilon on this anchored interface.
The unknown constant in that primary theorem prevents a numerical
comparison at every gap. Historical priority of (T) or (C) remains UNKNOWN.

Next falsifiable step: a specialist external proof review or formal audit
of the bounded-column/intertwining package, and a broader primary-source
priority search for arbitrary-law commuting threshold repetition. Within
this programme, a concrete verifier application should charge all sampler,
question, answer and predicate costs. An efficiently described two-level
conditionally linear sampler can have exponentially small unanchored gap,
as explicitly proved in `CL_SPECTRAL_OBSTRUCTION.md`; (C) instead acquires
a uniform gap by the specified anchoring transformation. No source contact
or publishing is authorized.
