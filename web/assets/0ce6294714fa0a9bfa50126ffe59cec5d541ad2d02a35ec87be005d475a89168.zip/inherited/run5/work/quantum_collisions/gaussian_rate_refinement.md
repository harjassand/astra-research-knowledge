# A new average-cell proof step: the Gaussian bridge has an n^(-1/2) remainder

Date: 7 October 2026. Status: a new written derivation, using the exact identities and coherent-channel minorant of the inherited candidate as explicitly declared inputs. No external review, formal certification, minimax sharpness claim, or priority clearance. The inherited n^(-1/8) proof is not counted as new work. The new contribution is Sections 2–4 below, which replace its coarse good-cell cutoff.

## 1. Exact interface and inherited inputs

Fix d >= 2, r=d^2-1, R=d(d-1)/2, N=n+R. Let H_0 be the real Hilbert space of traceless Hermitian d-by-d matrices with the Hilbert–Schmidt inner product. The input family is rho^tensor n, with ||d rho-I||_op <= delta <= 1/2. Both spectrum and eigenbasis are unknown. Error is half trace norm for quantum outputs and total variation for classical outputs.

The existing explicit channels depend only on n,d. T_n measures the Schur/coherent POVM, obtains lambda and a complete flag W, sets l_i=lambda_i+d-i, jitters by a uniform xi from

    C={sum xi_i=0, max xi_i-min xi_i <= 1},

and returns Y=[W diag(l+xi) W*-(N/d)I]/sqrt(n). S_n diagonalizes M=sqrt(n)Y+(N/d)I, rounds its eigenvalues to the nearest integer vector of sum N, and prepares the corresponding coherent Schur state and known mixed multiplicity. Illegal rounded labels produce a fixed state. C has HS volume v_d=sqrt(d), and nearest lattice rounding exactly recovers the encoded l almost surely.

The inputs used from the prior written argument are:

1. S_n T_n = C_(n,d) exactly, where the universal coherent measure/prepare channel obeys T(C_(n,d)(rho^n),rho^n) <= C_d delta.
2. Replacing the coherent conditional flag law by the HCIZ orbital law changes the outcome experiment by at most C_d delta uniformly in every Schur label. This uses the established type-A Graczyk–Sawyer uniform HCIZ bound.
3. The resulting auxiliary lattice/flag law has unnormalized density

       u_rho(x,W)=Delta(x)^2 exp(Tr(log rho W diag(x)W*))/prod_i Gamma(x_i+1)

   and exact discrete normalizer Z_disc=c_H Delta(p)/[n! Delta(log p)], with continuous extensions at repeated p. The continuous matrix law Q_rho has density proportional to exp(-V_rho(M)) on M>-I, Tr M=N, where V=Tr log Gamma(M+I)-Tr M log rho. Write Z_cont for its spectral/flag normalizer.
4. With M_0=n rho+(R/d)I and Z=(M-M_0)/sqrt(n), the continuous density has uniform Gaussian domination and moments. In particular

       E_Q ||Z|| <= C_d,
       Q(||Z|| > c_d sqrt(n)) <= C_d exp(-c_d n),
       TV(Q_rho mapped to Y,G_(n,rho)) <= C_d(delta+n^(-1/2)),
       Z_cont/(v_d Z_disc)=1+O_d(delta+n^(-1/2)),

   where G_(n,rho)=N_H0(sqrt(n)(rho-I/d),I_HS/d). The normalizer estimate is computed from the exact Schur/HCIZ cancellation and a centered matrix log-Gamma Laplace integral, not from a discrete Riemann-sum claim.
5. For an isotropic traceless-Hermitian Gaussian X with covariance I_HS/d and ANY deterministic mean, its smallest adjacent eigenvalue gap g satisfies

       Pr(g <= h) <= C_d h^3, 0<h<=1.

   This is the short eigenvalue-density deduction from the uniform HCIZ bound already written in the previous audit. The mean may be arbitrarily large or have repeated eigenvalues.

Items 1–5 must stand independently. The argument below introduces no new premise about moving spectral gaps, and no unknown parameter is used by the channels.

## 2. Cubic small-gap control implies integrable reciprocal gaps

For the Gaussian gap g, the layer-cake identity gives

    E[min(1,1/(sqrt(n) g))]
      = integral_0^1 Pr(g <= 1/(sqrt(n)t)) dt
      <= n^(-1/2)+C_d n^(-3/2) integral_(n^(-1/2))^1 t^(-3) dt
      <= C_d n^(-1/2).                                      (1)

Equivalently E[g^(-1)] <= C_d follows by integrating the cubic bound near zero; the capped form (1) is preferable because it is stable under a total-variation perturbation.

If x are the ordered eigenvalues of M under Q_rho, the eigenvalue gaps of its Y variable are (x_i-x_j)/sqrt(n). Adding (N/d)I has no effect on them. Thus, for any adjacent pair,

    E_Q[min(1,1/(x_i-x_(i+1)))]
      <= C_d(delta+n^(-1/2)).                               (2)

Indeed the integrand lies in [0,1], so transferring (1) from G to Q costs at most their TV distance. Likewise

    Q(min adjacent x-gap <= 4)
      <= C_d(delta+n^(-1/2)+n^(-3/2)).                       (3)

The total-variation transfer is not applied to an unbounded reciprocal gap. That would be an invalid step and could introduce an uncharged collision singularity.

## 3. Integrated cell oscillation replaces a growing cutoff

Let A be the union of root-lattice cells whose centers l are legal and have all adjacent gaps at least 3, intersected with the central matrix window ||M-M_0|| <= c_d n. Choose c_d small enough that all eigenvalues on the segment from l to l+xi are at least n/(4d), for all sufficiently large n. Every Q point outside the exponentially unlikely central complement and with all x-gaps >4 lies in A: rounding changes any coordinate by less than one and any gap by at most one. Nonnegative l is automatic in this central window. Therefore

    Q(A^c) <= C_d(delta+n^(-1/2)).                          (4)

On a cell with adjacent center gaps >=3, all pairwise gaps are >=3. Since |xi_i-xi_j|<=1,

    |log(Delta(l+xi)^2/Delta(l)^2)|
      <= C_d sum_(i<j) 1/(l_i-l_j)
      <= C_d sum_(i=1)^(d-1) 1/(l_i-l_(i+1)).                (5)

The left side is bounded by a dimension-only constant on A. Also l_i-l_(i+1) differs from x_i-x_(i+1) by at most one; hence its reciprocal is at most twice the capped reciprocal of the corresponding continuous gap. Integrating (5) against Q and using (2) costs C_d(delta+n^(-1/2)). No growing n^(1/8) gap cutoff is needed.

For the smooth factor a_rho=u_rho/Delta^2, differentiate along the bounded cell segment. The common log n cancels because sum xi_i=0. On the central window, the digamma estimate and p_min>=1/(2d) give

    |log(a_rho(l+xi,W)/a_rho(l,W))|
      <= C_d[delta+(1+||Z||)/sqrt(n)]                       (6)

uniformly in W. To verify the estimate, use

    psi(l_i+t xi_i+1)=log n+log p_i
         +O_d(|l_i-np_i|/n+1/n),

and (W* log rho W)_ii-log p_i=O_d(delta). Weyl's eigenvalue perturbation inequality bounds |l_i-np_i| by ||M-M_0||+C_d. The segment stays above n/(4d), so the logarithm has a uniformly bounded derivative there. This is a centered estimate; it does not produce sqrt(n) delta^2.

The log ratio in (6) is bounded by a dimension-only constant on A. Gaussian domination supplies E_Q ||Z||<=C_d, so its integrated contribution is C_d(delta+n^(-1/2)). Since |exp(s)-1|<=exp(B)|s| for |s|<=B, (5)–(6) imply

    integral_A |u_rho(l,W)/u_rho(x,W)-1| dQ
      <= C_d(delta+n^(-1/2)).                              (7)

For delta exceeding a fixed small dimension-only constant, the final TV bound is trivial after enlarging C_d. For smaller delta and sufficiently large n, the exact normalizer ratio in input 4 stays in a fixed positive compact interval and differs from one by C_d(delta+n^(-1/2)). The auxiliary jittered density Jnu_rho is u_rho(l,W)/(v_d Z_disc), while Q has density u_rho(x,W)/Z_cont in the SAME spectral/flag measure. Therefore (7) gives

    integral_A |d(Jnu_rho)-dQ| <= C_d(delta+n^(-1/2)).        (8)

Both are probability laws. Their masses outside A are bounded by (4) and (8); this infers the discrete bad-cell mass only AFTER using the independently proved normalizer ratio. Adding the complements proves

    TV(Jnu_rho,Q_rho) <= C_d(delta+n^(-1/2)).                (9)

Pushing the two spectral/flag laws into matrix coordinates preserves TV. The Vandermonde at the output x is the common coarea Jacobian; it has not been silently treated as constant inside a cell.

## 4. Improved explicit Gaussian experiment theorem

Combining the O(delta) coherent-to-HCIZ replacement, (9), and input 4 yields

    TV(T_n(rho^n),G_(n,rho)) <= C_d(delta+n^(-1/2)).         (10)

Exact S_n T_n=C_(n,d) then gives

    T(S_n(G_(n,rho)),rho^n) <= C_d(delta+n^(-1/2)).          (11)

These are the same spectrum-independent channels as before. The new proof strengthens their previously displayed O_d(delta+n^(-1/8)) bound. The channels remain continuous classical channels; the theorem itself does not assert finite retained storage, gate efficiency, reference preservation, or growing d uniformity. It gives arbitrary-shrinkage strong equivalence if delta_n ->0, including n delta_n^3 ->infinity.

The n^(-1/2) term is a proved upper-bound order within the stated argument. It is NOT a minimax lower bound on the best conceivable channels: reference-dependent transports or higher-order corrections can potentially do better at the exactly tracial singleton.

## 5. New finite classical storage consequence: second-order positive quantization

The Gaussian representation also avoids the inherited epsilon^(-2r) full-ball precision overhead. Uniform cell resampling would give epsilon^(-r). A positive tent kernel improves this further to epsilon^(-r/2). This consequence uses the Gaussian bridge, while its discretization argument is supplied here; no sharp-priority claim is made for the elementary kernel.

In one real dimension, let a_k(x)=(1-|x/h-k|)_+, k in Z. These nonnegative hat functions form a partition of unity. Encode x by the integer k with probability a_k(x); this is exactly stochastic rounding to the adjacent grid vertices. Given k, decode y with density b_k(y)=a_k(y)/h. Equivalently y=kh+h(U-V) for two fresh independent Uniform[0,1] draws. The resulting density operator is

    R_h f(y)=sum_k [integral a_k(x)f(x) dx] a_k(y)/h.

Its symmetric Markov kernel K_h(x,y) is nonnegative, at most 1/h, vanishes when |x-y|>2h, and has

    integral K_h(x,y)dx=1,
    integral (x-y)K_h(x,y)dx=0.

The second identity is barycentric interpolation: each b_k has mean kh and sum_k kh a_k(y)=y. Taylor's formula with integral remainder, followed by translation invariance of Lebesgue measure, therefore gives the global estimate

    ||R_h f-f||_1
      <= (1/h) integral_(-2h)^(2h) u^2 du
                    integral_0^1 (1-t)dt ||f''||_1
      = (8/3)h^2 ||f''||_1.                               (12)

This proof requires only f'' in L1 and avoids a supremum derivative or an unbounded-domain cutoff. Tensoring the Markov kernel along r coordinates and using L1 contractivity gives

    TV(R_h^tensor r f,f) <= (4/3)h^2 sum_i ||partial_(ii)f||_1.

For every shifted isotropic Gaussian of coordinate variance 1/d,

    ||partial_(ii)f||_1=d E|Z^2-1|=4d phi(1), Z~N(0,1),

independently of the mean. Choose h=sqrt(epsilon/C_d) with C_d large enough that the infinite-grid Gaussian error is at most epsilon/2.

In an orthonormal HS basis the Gaussian mean theta satisfies ||theta||<=B=sqrt(n/d)delta. Put a=sqrt((2/d)log(4r/epsilon)) and J=ceil((B+a)/h). Retain vertices k in {-J,...,J}^r and one overflow symbol. For x inside [-Jh,Jh]^r, tensor stochastic rounding uses only retained vertices. If x is outside, store the overflow symbol and decode to a fixed state. The finite and infinite encoding kernels agree on the cube. Gaussian overflow probability is at most epsilon/2 by a coordinate union bound, so the finite kernel still changes every Gaussian in the family by at most epsilon.

The actual quantum encoder applies T_n and then this finite stochastic rounding. The decoder draws the r triangular noises and applies S_n. Each real vector is transient decoder randomness, not a retained register. The vertex-conditioned mixtures are equivalently fixed quantum density matrices, so the retained alphabet is finite. Markov and trace-distance contractivity, (10), and (11) give

    e <= C_d(delta+n^(-1/2))+epsilon,
    D <= 1+[C_d epsilon^(-1/2)
                  (1+sqrt(n)delta+sqrt(log(4r/epsilon)))]^r. (13)

All retained classical symbols are counted in D. No quantum memory is retained. The channels know the envelope delta, epsilon, n,d, but do not know rho or its spectrum. This is an existence construction with explicitly positive stochastic kernels, not a practical quantum-hardware compiler.

For fixed epsilon the leading full-ball law remains (r/2) log_2(1+n delta^2)+O_(d,epsilon)(1), matching the inherited constant-error lower bound. For variable precision the NEW upper overhead is (r/2) log_2(1/epsilon)+(r/2) log_2 log(1/epsilon)+O_d(1), replacing the inherited 2r log_2(1/epsilon) bound. A cleaner joint bound keeps the sum inside (13); separate log overheads can overcount when sqrt(n)delta dominates the tail radius. This precision overhead is not proved optimal. In particular (13) cannot show classical error o(delta), which is excluded in resolved qubit regimes by the separate EB lower bound.

## 6. Corpus connection and priority boundary

The October OpenAI corpus catalogue was searched for Gaussian, compression, statistical sufficiency, recovery, quantum-information, entropy, and transport mechanisms. It contains no stated iid density-compression or quantum-to-classical experiment theorem. Family 093's proposed subgaussian log-concave LSI is unnecessary here: the matrix log-Gamma potential already has a direct global Hessian lower bound. Family 273's proposed entropy photon-number inequality concerns independent bosonic inputs and entropy at beam splitters; it does not imply trace-norm reconstruction or a spectrum-uniform iid comparison. Family 140 studies finite-state noiseless regression at growing dimension, with a different acquisition interface. Importing any of those claims as the bridge would leave a gap.

The actual load-bearing established external input remains Graczyk–Sawyer, *Sharp Estimates of Radial Dunkl and Heat Kernels in the Complex Case A_n*, Theorem 3.1:
https://www.numdam.org/articles/10.5802/crmath.188/

The bridge is adjacent to strong quantum LAN, whose classical/thermal product decomposition is established at fixed separated reference spectra (Kahn–Guţă, 2009): https://arxiv.org/abs/0804.3876 . The covariance I/d at the tracial point is established LAN geometry; neither that covariance nor weak convergence is being claimed as new. Bounded search did not settle priority for the full arbitrary-shrinkage theorem or the rate refinement.

The corpus README explicitly describes model-produced manuscripts with differing verification stages and possible unformalized issues. Catalogue presence is not independent validation. The new quantitative step (1)–(9) uses no unverified corpus theorem.

## 7. The n^(-1/2) order is sharp for this specific uniform-jitter channel

At d=2 and rho=I/2, the coherent direction is uniform on the sphere. If L=2j is the Schur spin label, its exact weight is

    p_(n,L)=2^(-n) binomial(n,(n-L)/2)
                         (L+1)^2/[(n+L)/2+1],

for L in {n mod 2,n mod 2+2,...,n}. In root-lattice jitter, the unscaled eigenvalue gap g is uniform on [L,L+2], conditional on L. Thus the radial density is exactly p_(n,L)/2 on that interval.

For the target three-dimensional traceless Gaussian, x=g/sqrt(n) has Maxwell density

    f(x)=sqrt(2/pi) x^2 exp(-x^2/2), x>=0.

Let h=2/sqrt(n) and x_L=(L+1)/sqrt(n). Central Stirling expansion of the binomial coefficient gives

    sum_L |p_(n,L)-h f(x_L)|=O(1/n).                       (14)

For clarity, the relevant cancellation is

    [n/(n+L+2)] exp(((L+1)^2-L^2)/(2n))
      =1+O(1/n+L^2/n^2).

The standard centered binomial Stirling remainder is O(1/n+L^4/n^3). On L<=n^(3/5), these remainders are uniformly small and bounded by C n^(-1)[1+x_L^4]. Summing against h f(x_L) costs O(1/n). Outside that region, Hoeffding and the Gaussian tail give exp(-c n^(1/5)), which is o(1/n). This proves (14). Endpoint support mismatches have Gaussian mass O(h^3) near zero and exponentially small mass near the upper endpoint.

For any smooth density f with f'' in L1, the midpoint histogram H_h has

    TV(H_h f,f)=(h/8) integral |f'|+O(h^2).                (15)

To verify it, write f(x)=f(c)+f'(c)(x-c)+a Taylor remainder on each width-h cell. The integral of |x-c| is h^2/4. The integrated remainder is O(h^2)||f''||_1 over the whole line; also h sum_c |f'(c)| differs from integral |f'| by O(h)||f''||_1. Combining these and the factor 1/2 in TV yields (15). The missing near-zero half-cell for odd n contributes O(h^3), so both parities have the same leading constant.

The Maxwell density is unimodal with maximum f(sqrt(2))=2sqrt(2/pi)/e. Hence integral_0^infinity |f'|=2 f(sqrt(2)). Equations (14)–(15) give the new exact asymptotic

    TV(T_n((I/2)^n),G_(n,I/2))
      = [sqrt(2/pi)/e] n^(-1/2)+O(1/n).                   (16)

The numerical script check_tracial_rate.py uses the exact Schur weights and the exact Maxwell CDF, splits every cell at its density-crossing points, and integrates absolute differences. Its checks from n=64 to n=1,048,576 give sqrt(n)TV from 0.295332 to 0.293525553, approaching sqrt(2/pi)/e=0.2935253263. The JSON records these floating-point diagnostics and their limits; they are corroboration, not a proof certificate.

This lower asymptotic concerns the displayed ordinary-jitter encoder. At the tracial singleton one could instead output the known Gaussian exactly, so (16) is not a lower bound on all possible statistical-comparison channels.
