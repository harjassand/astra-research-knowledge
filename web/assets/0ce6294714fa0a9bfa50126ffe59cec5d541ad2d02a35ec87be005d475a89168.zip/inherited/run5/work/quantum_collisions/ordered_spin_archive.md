# A new consequence of a macroscopic-spin law: ordered-phase archive threshold Vt

Date: 7 October 2026. Status: new conditional compression/rate derivation. The theorem below is proved for a declared macroscopic-spin premise using exact representation theory and the finite spin coherent-channel minorant already present in the inherited research. The application to the three-dimensional nearest-neighbor ferromagnet is conditional on the new OpenAI manuscript's spherical-law claim, which has not been independently verified here. No magnetization theorem, efficient compiler, or novelty clearance is claimed.

## 1. Exact model and the one new corpus premise

Let V ->infinity index known finite spin systems. For concreteness take V sites, each of fixed spin S>0, with global generators J=sum_x S_x, normalized by [J_a,J_b]=i epsilon_(abc)J_c. Thus the largest total spin is j_max=SV. Let H_V be a known SU(2)-invariant Hamiltonian, [H_V,J_a]=0. The known inverse temperature beta>0 is fixed. The known field magnitude t_V>0 tends to zero; its direction v in S^2 is unknown. In physical units t_V=beta |B_V|. One supplied state is the entire correlated Gibbs density matrix

    rho_(V,t,v)=exp[-beta H_V+t v·J]/Z_(V,t).

This is one many-body state, not V iid copies. Error is e=sup_v T(Dec Enc(rho_(V,t,v)),rho_(V,t,v)), with half trace norm. All input-dependent retained classical, quantum, and hybrid registers count toward dimension D. Independent private randomness is absorbed into the encoder/decoder channels. The converses below also permit a codebook selected by input-independent encoder/decoder common randomness, even if that seed is not charged: condition on the seed, each codebook factors through a D-dimensional memory. Fresh fixed ancillas and decoder randomness are allowed; no quantum side channel or pre-shared entanglement is allowed. The known model, beta,t,V are fixed side information.

Schur decomposition for this SU(2) representation gives

    rho_(V,t,v)=direct_sum_j q^t_V(j) tau_(j,t,v) tensor omega_(V,j),
    tau_(j,t,v)=exp(t v·J^(j))/Z_j(t),
    omega_(V,j)=exp(-beta H_(V,j))/Tr exp(-beta H_(V,j)),
    q^t_V(j) proportional q^0_V(j) w_j(t),
    w_j(t)=Z_j(t)/(2j+1)
          =sinh((2j+1)t/2)/[(2j+1)sinh(t/2)].              (1)

The multiplicity state is known and independent of v. There can be exponentially large multiplicity spaces; no computation-cost shortcut for preparing them is assumed.

The premise is simply

    under q^0_V, j/V -> m in probability for a fixed m>0. (MP)

The new OpenAI manuscript *The spherical magnetization law for the three-dimensional quantum Heisenberg ferromagnet*, Theorem 1.1 and Section 8's eq:spin-concentration, explicitly claims MP for fixed S, every fixed finite beta>=beta_0(S), and even periodic cubes of V=L^3 sites. Its Hamiltonian is -sum_<x,y> S_x·S_y with each bond counted once. I read the exact introduction and total-spin proof, and downloaded all eight source sections into this branch's work directory at release commit adc7f1241b42e322a6451854ab7e4b4c146bf78a. That is source identification, not verification of the long spatial/pressure proof on which MP depends.

Exact source URL:
https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/The-spherical-magnetization-law-for-the-three-dimensional-quantum-Heisenberg-ferromagnet-October-5-2026/build/sections/08-global-spin.tex

MP alone, rather than the whole new physical theorem, is the load-bearing premise for the archive rates below. Established complete-graph Heisenberg spherical-law results provide a separate prior-art source of this premise (Björnberg–Fröhlich–Ueltschi 2020, Theorem 2.1, https://arxiv.org/html/1811.12834v2). The three-dimensional nearest-neighbor application remains conditional.

Here is an explicit deduction of MP for that established example, rather than an appeal to a spherical-law name. Use the complete-graph normalization H_V=-J^2/V (an additive scalar is immaterial), and beta>3/[2S(S+1)], so its theorem gives m=m^*(beta)>0 and the zero-field moment generating function of J_z/V converges to sinh(hm)/(hm). Since |J_z/V|<=S, weak convergence gives convergence of the second and fourth moments. SU(2) invariance makes J_z uniform over -j,-j+1,...,j conditional on j. The exact conditional moments are

    E[J_z^2 | j]=j(j+1)/3,
    E[J_z^4 | j]=j(j+1)(3j^2+3j-1)/15.

The spherical limiting moments are m^2/3 and m^4/5. Since j/V<=S, the lower-order corrections are uniformly O(1/V), and hence E[(j/V)^2]->m^2 and E[(j/V)^4]->m^4. Thus E[((j/V)^2-m^2)^2]->0; because j/V>=0 and m>0, j/V->m in probability. The storage theorem therefore has a concrete unconditional complete-graph application, irrespective of the new local-neighbor manuscript.

## 2. New rate theorem

Write kappa_V=Vt_V. Subject to MP and t_V->0:

1. If kappa_V->0, zero retained bits suffice for vanishing error. Conversely a uniformly vanishing zero-memory error forces kappa_V->0 (along any subsequence with a positive signal, it is impossible).
2. If kappa_V->c in (0,infinity), vanishing error requires D_V->infinity for every classical/quantum/hybrid code, including input-independent randomized codebooks. Any diverging classical capacity suffices; no mandatory log V term occurs. More quantitatively, with alpha=mc and L(alpha)=coth(alpha)-1/alpha,

       L(alpha)/(2D)-a_V <= e^*_(V,D)
                              <= C_alpha/D+a_V,          (2a)

   for all D above a fixed chart-size constant, where a_V->0 is independent of D. The upper code is classical. Thus the critical limiting memory/accuracy law is Theta(1/D) in the iterated limit V->infinity then D->infinity. No rate for a_V is claimed from MP alone.
3. If kappa_V->infinity, the optimal leading retained cost is

       log_2 D_V=(1+o(1)) log_2(Vt_V),                    (2)

   achievable with a wholly classical archive. At uniform constant error <=1/8, every quantum/hybrid/classical code has D_V>=c_(S,m)Vt_V eventually. A direct finite classical construction has, for 0<epsilon<=1/4 and t<=1,

       e <= 1-exp(-t)+epsilon <=t+epsilon,
       D <= C_S epsilon^(-3)(1+Vt)[1+log(1+Vt)].          (3)

The upper bound holds for ANY known invariant H_V and beta,t; MP is needed for the matching lower bounds and phase interpretation. Dimension is a fixed worst-case memory capacity, not an expected variable-length cost.

In a product thermal spin-one-half system, j is of order Vt (in a resolved weak-field regime), so the analogous angular resolution scale is Vt^2. MP puts j of order V, yielding Vt. The ordered-phase field threshold therefore occurs at t~1/V rather than t~1/sqrt(V). This change comes from extensive total-spin support; it is not an iid spectral-collision formula applied to correlated inputs.

For t=V^(-alpha): alpha>1 permits zero memory; alpha=1 permits any diverging capacity; 0<alpha<1 gives (1-alpha+o(1))log_2 V retained classical bits and zero retained qubits. These assertions are conditional on MP and known magnitude t.

## 3. Exact coherent channel and finite retained alphabet

In sector j let L=2j, r=exp(-t), a=1-r, and K_(L,v)=j-J_v. The spin density is r^K/Z_L, Z_L=sum_(k=0)^L r^k. The inherited finite spin coherent channel

    B_L(X)=(L+1) integral <L,u|X|L,u>|L,u><L,u| dmu(u)

obeys B_L(tau_(L,t,v))>=r tau_(L,t,v), uniformly in L and v. This minorant is an explicit prior input, not a new result here. Measuring j, applying this coherent POVM, and regenerating omega_(V,j) gives an EB channel with error <=1-r. Internal many-body entanglement in the known multiplicity state is allowed; the channel breaks entanglement with an external reference.

The exact measured angular density, relative to normalized sphere area mu, is

    f_(L,v)(u)=[(L+1)a/(1-r^(L+1))](r+a z)^L,
    z=(1+v·u)/2.                                          (4)

The joint reference law is q^t_V(L)mu(du). Coarsening its density and decoding with the conditional reference mixture produces exactly a finite measure/prepare channel; the additional trace error is bounded by the TV change in (4).

### Radial regularity

Temporarily extend L to all nonnegative real values. Under f_L the variable Y=-log(r+a z) in [0,t] is a truncated exponential of rate L+1. Thus

    partial_L log f_L=E[Y]-Y,
    ||partial_L f_L||_1<=min(t/2,1/(L+1))
                       <=2t/(1+tL),
    TV(f_L,f_J)<=|log((1+tL)/(1+tJ))|.                     (5)

The truncated-exponential variance is 1/(L+1)^2 minus the nonnegative term t^2 exp(-(L+1)t)/(1-exp(-(L+1)t))^2; the other variance bound is Popoviciu's t^2/4. This proves the first inequality without a typical-sector assumption.

Bin all represented L by successive factors 1+epsilon/4 in the coordinate 1+tL, from 1 to 1+2SVt. Then TV between any two densities in a bin is at most epsilon/4. The number of bins is

    B<=2+(5/epsilon)log(1+2SVt).                          (6)

After retaining a bin, the decoder samples the actual L from the known q^t_V conditioned on that bin. No L is secretly retained, and a fixed representative L is not used. Bins with zero reference mass can be omitted.

### Angular regularity

The marginal in z has density proportional to (r+a z)^L. Direct integration gives

    E_f(1-z)<=1/[a(L+2)].                                 (7)

Since |grad log f|=La sqrt(z(1-z))/(r+a z), the directional Fisher bound is

    integral |grad log f|^2 f dmu
       <=L^2 a^2 r^(-2)E(1-z)<=aL/r^2,
    integral |grad f|dmu<=r^(-1)sqrt(aL)
                         <=e sqrt(tL), t<=1.              (8)

Use six normalized cube-face charts and a G-by-G square grid on each face. Chart derivatives and area densities have dimension-only positive upper/lower bounds. Ordinary square L1 Poincare, obtained by integrating coordinate line segments and averaging over pairs of points, therefore gives

    TV(f,angular-cell-average(f))
          <=(C/G) integral |grad f|dmu.                   (9)

Choose G=ceil(C epsilon^(-1)sqrt(1+2SVt)). There are 6G^2 cells and the angular cost is at most epsilon/4 uniformly in every L. The radial and angular conditional averages commute and are L1 contractions with respect to the fixed product reference law, so their costs add to at most epsilon/2. Increasing constants gives (3).

Operationally retain only (radial bin, angular cell). The decoder samples L from the known sector law in the bin, samples u uniformly in the angular cell, prepares |L,u><L,u| tensor omega_(V,L), and inverts the known representation decomposition. Equivalently each finite label names a fixed mixed many-body state. The alphabet size is at most 6BG^2; counting all input-dependent labels gives (3). Temporary output preparation, ancillas, and sampled reals are not retained storage.

This supplies exact positive POVMs and exact finite-dimensional mixed decoding states, not a gate-efficient algorithm. The known interacting partition functions and multiplicity Gibbs states can be hard to compute or prepare. No experimental hardware or computational speedup is claimed.

## 4. Field tilt preserves macroscopic spin

The function sinh(x)/x is increasing for x>0, so w_j(t) in (1) is increasing in j. Exponentially tilting q^0 by an increasing nonnegative weight stochastically increases j. A direct proof uses covariance:

    Cov_(q0)(1_(j<b),w_j)
      =1/2 E[(1_(J<b)-1_(J'<b))(w_J-w_J')]<=0.

Consequently

    q^t_V(j<mV/2)<=q^0_V(j<mV/2)=o(1),                   (10)

uniformly for every t>=0. This needs no rate or exponential tail in MP. In particular it remains true even if Vt diverges so quickly that an exponential field tilt could amplify rare upper-spin tails. Claiming j/V->m under all such tilts would be unjustified; (10), which is sufficient for the lower bound, is the valid conclusion.

If Vt->c<infinity, w_j(t) lies between 1 and exp(SVt), uniformly bounded. Then MP DOES transfer to q^t, and j/V->m also under q^t.

## 5. Packing gives the supercritical lower bound

Measure the exact coherent POVM and report u. Combining (7) with ||u-v||^2=4(1-z) gives

    E[||u-v||^2 | L]<=4/[a(L+2)].                         (11)

On j>=mV/2, L>=mV. Pick a chordal sphere packing at separation

    Delta^2=256/(amV),

which is <=1 in the supercritical regime. A maximal such packing covers the sphere with chordal caps of area pi Delta^2, so its number of points obeys

    N>=4/Delta^2=amV/64.

Nearest-neighbor classification of u fails only if ||u-v||>=Delta/2, or the low-spin event occurs. Its failure probability is at most

    o(1)+16/(amV Delta^2)=o(1)+1/16,

at most 1/8 for large V. If an archive has uniform reconstruction error <=1/8, applying this classification POVM to its output succeeds with probability >=3/4.

Let omega_i be the retained memory state for hypothesis i and F_i the effective classification POVM on memory. For any D-dimensional quantum/hybrid/classical memory, omega_i<=I and sum_i F_i=I, so average success is at most

    (1/N)sum_i Tr(omega_i F_i)<=D/N.

Thus

    D>=3N/4>=3amV/256>=3mVt/512, t<=1.                  (12)

This supercritical dimension bound also permits uncharged input-independent common classical randomness: condition on the seed and average in the same argument. A persistent input-dependent side register would have to be included in D. Section 7 gives a separate common-randomness-compatible critical converse.

Choose epsilon=1/log(e+Vt) in (3). Then e->0, while

    log_2 D<=log_2(Vt)+4log_2 log(e+Vt)+O_(S)(1).

Together with (12), this proves the optimal leading cost (2).

## 6. Subcritical zero memory and its converse

For any invariant H_V, exp(t v·J) has eigenvalues between exp(-SVt) and exp(SVt). Dividing by its expectation in rho_(V,0) gives

    exp(-2SVt) rho_(V,0)<=rho_(V,t,v)<=exp(2SVt)rho_(V,0).

Thus preparing the known zero-field Gibbs state with one fixed label has error <=1-exp(-2SVt)=O(Vt), proving the subcritical assertion.

For the converse compare opposite directions. Their sector laws q^t are the same. The exact root fidelity in spin j is

    F_root(tau_(j,t,+z),tau_(j,t,-z))
      =(2j+1)/Z_j(t)
      =(2j+1)sinh(t/2)/sinh((2j+1)t/2).                  (13)

By (10), asymptotically all weight has j>=mV/2. Along any sequence with Vt bounded below by a positive constant, (13) is bounded strictly below one on that event. The direct-sum root fidelity is the q^t-weighted sum of (13), so the opposite-direction trace distance is bounded below by a positive constant. One parameter-independent output state then has maximum reconstruction error at least half that distance. When Vt->infinity the fidelity tends to zero and the zero-memory error is at least 1/2-o(1).

This establishes the precise subsequence qualification: vanishing zero-memory error forces Vt->0. If Vt oscillates, the converse applies to its positive-signal subsequences.

## 7. Critical regime: a classical spherical experiment and sharp capacity order

Suppose Vt->c in (0,infinity). By the bounded-tilt statement after (10), L/(2V)->m under q^t. In (4), r=exp(-t), a=t+O(t^2), L t^2=O(1/V), and Lt->2mc. Uniformly in u,v on these typical sectors,

    f_(L,v)(u)->f_(alpha,v)(u)
              =[alpha/sinh(alpha)]exp(alpha v·u),
    alpha=mc>0.                                         (14)

The functions are uniformly bounded because Lt<=2SVt=O(1). Taking mixtures gives uniform convergence of the coherent-measurement Q laws to the von Mises–Fisher spherical experiment (14). The known sector distribution carries no direction parameter. This is a derived critical limit, not a classical Gaussian limit.

There is also an EXACT positive coherent-state P representation:

    tau_(L,t,v)=integral P_(L,t,v)(u)|L,u><L,u|dmu(u),
    P_(L,t,v)(u)=(L+1)r^(L+1)/[Z_L(1-a z)^(L+2)].        (15)

To verify it, rotate v to z. Azimuthal integration kills off-diagonal entries, and the k-th diagonal entry follows from

    binomial(L,k) integral_0^1
       z^(L-k)(1-z)^k/(1-a z)^(L+2) dz
          =r^(k-L-1)/(L+1).

The substitution w=z/(1-a z), or a beta-integral evaluation, gives this identity directly. Both sides are positive and normalized. When Vt->c and j/V->m, the P density also converges uniformly to the SAME f_(alpha,v): its normalizer tends to alpha exp(-alpha)/sinh(alpha), and its denominator contributes exp(alpha(1+v·u)).

Define the nonnegative comparison remainder

    a_V=sup_v sum_L q^t_V(L)[TV(P_(L,t,v),f_(alpha,v))
                              +TV(Q_(L,t,v),f_(alpha,v))]. (16)

Then a_V->0. It depends on the known physical experiment and MP convergence, not on any archive capacity D or chosen quantization mesh. This distinction is needed for the precision claims below.

### A quantitative converse, including free input-independent common randomness

The positive P representation means ANY archive induces a Markov kernel K_V(u,du') from a latent coherent direction to a later coherent measurement on the archive's decoded output. For input u, first sample L from known q^t and prepare the coherent/multiplicity state Omega_(L,u), then apply the code, then measure its output coherently and report u'. The exact P input and exact Q target, (16), and trace/TV contractivity give

    sup_v TV(f_(alpha,v)K_V,f_(alpha,v))<=e+a_V.           (17)

Let b_alpha=coth(alpha)-1/alpha>0. The von Mises–Fisher first moment is E_(f_alpha,v)u=b_alpha v. Set m_K(v)=E_(f_alpha,v K)u'. Since a bounded scalar test changes by at most twice TV,

    |v·m_K(v)-b_alpha|<=2(e+a_V).

Integrate v over normalized sphere area. Rotation symmetry gives integral v f_(alpha,v)(u)dmu(v)=b_alpha u. Therefore

    b_alpha[1-E_(u uniform,K)(u·u')]<=2(e+a_V),
    E_(u uniform,K)||u-u'||^2<=4(e+a_V)/b_alpha.           (18)

Now use the memory dimension. If sigma_u is the D-dimensional encoded state and F(du') is the effective output POVM, sigma_u<=I and integral F=I. A chordal cap {u:||u-u'||^2<=x} has normalized area x/4 for 0<=x<=4. Fubini gives

    Pr_(uniform u,K)(||u-u'||^2<=x)
      <=integral Tr F(du') (x/4)=Dx/4.

Consequently

    E||u-u'||^2>=integral_0^(4/D)(1-Dx/4)dx=2/D.          (19)

If codebooks use a common input-independent seed, apply the cap inequality at each seed and average. The same D bound survives. Combining (18)–(19) proves

    e>=b_alpha/(2D)-a_V.                                 (20)

Unlike the elementary D^2 rank argument, this converse handles mixtures of codebooks coordinated by uncharged common randomness. An earlier rank-only draft was replaced because averaging many codebooks can create an infinite-rank expectation matrix even when each individual codebook uses bounded memory.

### A matching classical O(1/D) upper bound

Here is an explicitly positive finite quantizer on the sphere. Use the six signed-axis charts U_i={s_i u_(a_i)>1/4}, with coordinates given by the other two components divided by s_i u_(a_i). Set b(s)=(s-1/3)_+^4 and

    eta_i(u)=b(s_i u_(a_i))/sum_j b(s_j u_(a_j)).

The denominator is uniformly positive because max_a |u_a|>=1/sqrt(3). These C3 functions form a partition of unity and have support strictly inside the U_i. Their coordinate supports lie in a fixed disk of radius sqrt(8). In chart coordinates x in R^2, write w_i(x)=eta_i(phi_i(x)) times the normalized spherical area Jacobian (1+|x|^2)^(-3/2)/(4pi). Extend w_i by zero to a globally C1 compactly supported nonnegative function. Chart domains and derivative bounds are fixed, independent of V,D,v.

For mesh h>0, take the tensor hats

    A_k(x)=prod_(a=1)^2 (1-|x_a/h-k_a|)_+,
    c_k=hk,
    phi_(i,k)(u)=eta_i(u)A_k(coord_i(u)),
    M_(i,k)=integral phi_(i,k)dmu=integral A_k w_i dx.

Choose h below a fixed chart-support margin, so every active neighboring node and hat support used in Taylor's formula lies in a fixed C2 chart neighborhood. Only O(h^(-2)) hats meet the compact chart supports. Omit zero-M labels. The phi_(i,k) are nonnegative and sum to one. Encode u by label (i,k) with that probability, and decode u' with density phi_(i,k)(u')/M_(i,k). This is a finite positive Markov kernel R_h; every label is retained and counted.

For a C2 spherical density f, examine one chart. Tensor-hat nodal interpolation reproduces constants and affine functions, so

    sum_k A_k(y)f(c_k)=f(y)+O(h^2)||D^2 f||_infinity.

The reference-conditioned decoder averages f around c_k. Its centroid bias is

    delta_(i,k)=[integral (x-c_k)A_k(x)w_i(x)dx]/M_(i,k).

The individual delta can be O(h); the VALID bound is its integrated contribution. Since the unweighted tensor hats are symmetric, integral (x-c_k)A_k(x)dx=0. Subtract w_i(c_k), use the fixed Lipschitz bound on w_i, and sum all active hats:

    sum_k M_(i,k)|delta_(i,k)|
      <=sum_k Lip(w_i) integral |x-c_k|^2 A_k(x)dx
      <=C h^2.                                          (21)

Each numerator is O(h^4), and there are O(h^(-2)) active hats. Taylor's remainder in each conditional average is O(h^2)||D^2f||_infinity. After integrating in y against w_i and summing the partition of unity, (21) and nodal interpolation prove

    TV(R_h f,f)<=C h^2 (||grad f||_infinity+||D^2 f||_infinity).

The chart C2 norms of f_(alpha,v) are uniformly bounded in v, for fixed alpha. Hence

    TV(R_h f_(alpha,v),f_(alpha,v))<=C_alpha h^2.          (22)

The actual encoder measures the coherent Q law, discards L, and retains only (i,k). The decoder samples a fresh L from known q^t, samples u' from the label's reference-conditioned angular density, and prepares Omega_(L,u'). The actual averaged Q law differs from f_alpha by the Q part of (16), and the exact target P mixture differs from the q^t-times-f_alpha reference mixture by the P part. Thus

    e<=C_alpha h^2+a_V,
    D<=C h^(-2).

Choosing h of order D^(-1/2), with constants large enough to accommodate the finite chart labels, gives

    e<=C'_alpha/D+a_V.                                  (23)

The comparison remainder a_V is independent of h and D, because only contractivity is used when applying R_h. The actual critical code uses the known q^t and the chart mesh; it does not require knowing m or alpha. Equations (20),(23) prove (2a). They show order-optimal classical memory in the limiting critical experiment, and exclude a better dimension order for quantum/hybrid memory. They do not give a simultaneous sharp rate for arbitrarily fast-growing D_V without a quantitative rate in MP.

In particular any D_V->infinity permits e_V->0 by (23), while bounded D is excluded by (20). For target small limiting error epsilon, the necessary and sufficient dimension order is epsilon^(-1), or log_2(1/epsilon)+O_alpha(1) retained classical bits. Constants depend on alpha=mc and no exact leading constant is claimed.

## 8. What is new, and what remains conditional

The new results are the correlated-system finite count (3), the matching Vt discrimination bound (12), the sharp leading orientation-memory law (2), and the critical von Mises–Fisher experiment with matching inverse-D accuracy order (20),(23), valid for arbitrary quantum/hybrid memories and common randomized codebooks. The inherited exact Gibbs representation and coherent EB minorant are inputs and are not counted as new. The new corpus supplies the proposed physical MP premise for a local three-dimensional system; it supplies no archive/compression theorem.

The established complete-graph spherical law means the generic theorem has an application that does not depend on the new corpus. Priority for these storage consequences has not been exhaustively checked. The low-temperature local-neighbor application cannot be promoted to an unconditional new physical theorem unless MP's long source proof is independently validated.

Unknown temperature, unknown Hamiltonian, unknown field magnitude, purification-preserving storage, arbitrary record-dependent later tests, and efficient Gibbs preparation are outside this theorem. They change the retained interface or the acquisition problem and are not resolved by MP.
