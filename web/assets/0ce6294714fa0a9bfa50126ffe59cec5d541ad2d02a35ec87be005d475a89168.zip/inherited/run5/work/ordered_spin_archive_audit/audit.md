# Independent ordered-spin archive audit

Date: 7 October 2026. Auditor: ordered_spin_archive_audit.

Audit target: work/quantum_collisions/ordered_spin_archive.md. This is an independent reconstruction of its finite-memory theorem. The abstract theorem passes after replacing the original critical rank converse when common encoder-decoder randomness is allowed. A stronger replacement and a checked critical precision upper are proved below. The local three-dimensional physical premise remains an unverified source claim. No priority clearance, efficient Gibbs preparation, or reference-preserving compression follows.

## 1. Interface and conventions

There are V fixed-spin-S sites. J=sum S_x satisfies [J_a,J_b]=i epsilon_abc J_c. The known Hamiltonian commutes with every J_a. The entire supplied input is

    rho_(V,t,v)=exp(-beta H_V+t v·J)/Z_(V,t),
    t=beta|B|, v in S^2 unknown, t=t_V -> 0.

This is a correlated many-body Gibbs density, not V independently supplied qubits. Beta, H_V, V and the magnitude t are known to both channels. Their description and computation are not retained storage. Error is

    e_V = sup_v (1/2)||Dec Enc(rho_(V,t,v))-rho_(V,t,v)||_1.

All input-dependent retained registers are charged. A hybrid memory is a finite direct sum of matrix algebras, with total Hilbert-space dimension D=sum_c d_c. A classical alphabet with C labels has D=C; a classical register of C labels and a fixed q-dimensional quantum register has D=Cq. Thus the actual classical count below requires ceil(log_2 D) retained bits. No input-dependent seed, sector label, or side register may be omitted from D.

Fixed ancillas and private randomness are part of the channels. Input-independent common classical randomness may also be allowed: every converse below that is used for the final theorem survives conditioning on that randomness, with worst-case conditional memory dimension at most D. No shared entanglement or quantum side channel is available.

Write j for the spin label, and L=2j for the nonnegative integer coherent-state degree. Then j<=SV and L<=2SV. The field coefficient is t J, not t L. The critical von Mises-Fisher parameter will therefore be alpha=mc, rather than 2mc.

The sole asymptotic premise is

    q^0_V(j/V -> m)=1 in the sense of convergence in probability,
    for a fixed m>0.                                  (MP)

The known multiplicity state in each sector can be exponentially expensive to prepare. This is a theorem about retained capacity and channels, with no claim of an efficient circuit.

## 2. Exact Gibbs decomposition and field tilt

SU(2) invariance gives a decomposition H_V=direct_sum_j I_(2j+1) tensor H_(V,j), and hence

    rho_(V,t,v)
      = direct_sum_j q^t_V(j) tau_(j,t,v) tensor omega_(V,j),
    tau_(j,t,v)=exp(t J_v^(j))/Z_j(t),
    q^t_V(j)=q^0_V(j)w_j(t)/E_(q0)w_J(t),
    w_j(t)=sinh((2j+1)t/2)/[(2j+1)sinh(t/2)].

Omega_(V,j) is known and independent of v. The ratio sinh(x)/x is increasing for x>0, since x cosh(x)-sinh(x)>0. Consequently w_j is increasing in j. For every cutoff b,

    Cov_(q0)(1_(j<b), w_j) <= 0,
    q^t_V(j<b) <= q^0_V(j<b).

In particular

    q^t_V(j<mV/2) = o(1),                              (1)

for every nonnegative t, without any rate assumption on MP. The useful conclusion in the supercritical regime is this lower-spin bound. MP alone does not imply j/V->m after every unbounded tilt: rare upper-spin tails can be amplified.

If Vt stays bounded, 1<=w_j(t)<=exp(SVt), so MP does transfer to q^t. This is the justified concentration used in the critical limit.

## 3. Positive coherent representation and the exact EB error

Let r=exp(-t), a=1-r, L=2j, and x=(1+v·u)/2. Relative to normalized sphere area mu, the coherent POVM density is

    Q_(L,v)(u) = C_L (r+a x)^L,
    C_L=(L+1)a/(1-r^(L+1)).

There is also an exact positive coherent preparation density

    P_(L,v)(u)
      = C_L r^(L+1)/(1-a x)^(L+2),                    (2)
    tau_(j,t,v)=integral P_(L,v)(u)
                      |L,u><L,u| dmu(u).

For completeness, after the azimuthal integral the k-th diagonal coherent weight is

    binomial(L,k) x^(L-k)(1-x)^k.

The substitution y=rx/(1-a x) gives

    binomial(L,k) integral_0^1
      x^(L-k)(1-x)^k/(1-a x)^(L+2) dx
        = r^(k-L-1)/(L+1).

Multiplying by C_L r^(L+1) yields a r^k/(1-r^(L+1)), the correct normalized spin thermal eigenvalue. The densities in (2) integrate to one.

Pointwise,

    Q/P
      = [(r+a x)(1-a x)/r]^L (1-a x)^2/r
      >= r,

because (r+a x)(1-a x)=r+a^2 x(1-x)>=r and 1-a x>=r. Therefore the spin coherent measure-and-prepare channel obeys

    B_L(tau)>=r tau,
    T(B_L(tau),tau)<=1-r<=t.                           (3)

The same bound holds after measuring j, discarding its known multiplicity state, and regenerating that state. It is independent of L and of v. This reconstruction verifies the inherited minorant directly; it is not promoted to a new historical result.

## 4. Finite supercritical alphabet and complete label count

### Radial bins

Extend L temporarily to nonnegative reals. Under Q_L the variable

    Y=-log(r+a x) in [0,t]

has a truncated-exponential density of rate L+1. Differentiation gives

    partial_L log Q_L = E Y-Y.

Its variance is

    1/(L+1)^2 - t^2 exp(-(L+1)t)/(1-exp(-(L+1)t))^2.

Cauchy-Schwarz and the bounded-support variance inequality give

    ||partial_L Q_L||_1
       <= min(t/2, 1/(L+1))
       <= 2t/(1+tL).

The half in TV then yields the valid integrated bound

    TV(Q_L,Q_J)
      <= |log(1+tL)-log(1+tJ)|.                       (4)

Bin the represented L labels in the coordinate 1+tL, with successive ratios 1+epsilon/4. The number of bins can be taken to satisfy

    B <= 2 + (5/epsilon) log(1+2SVt).                  (5)

Every pair of angular laws within one bin has TV at most epsilon/4. This does not require smoothness or concentration of q^t. On decoding, the actual L is sampled from its known q^t conditional on the bin; an exact sector label is not retained.

### Angular cells

Direct integration gives

    E_(Q_L)(1-x)
      = 1/[a(L+2)]
        - (L+1)r^(L+1)/[(L+2)(1-r^(L+1))]
      <= 1/[a(L+2)].                                 (6)

Since |grad x|=sqrt(x(1-x)),

    integral |grad log Q_L|^2 Q_L dmu
       <= L^2 a^2 r^(-2) E(1-x)
       <= aL/r^2,
    integral |grad Q_L|dmu <= e sqrt(tL), 0<t<=1.     (7)

Partition the sphere into the six normalized cube faces and use G by G coordinate squares on each face. The charts are uniformly smooth with uniformly positive bounded area densities. Weighted square L1 Poincare gives

    TV(f, its cellwise area average)
      <= (C/G) integral |grad f|dmu.

Choose

    G = ceil(C epsilon^(-1) sqrt(1+2SVt)).

There are exactly at most 6G^2 angular cells, and their averaging error is at most epsilon/4 for every represented L.

The fixed reference measure is q^t(L)mu(du). Radial conditional averaging and angular conditional averaging are commuting L1 contractions in this product reference measure. Their two errors add. The retained alphabet is exactly the set of pairs

    (radial bin, angular cell),
    D_code <= 6 B G^2.                                (8)

An empty radial bin can be omitted. The decoder samples L conditional on the retained radial bin and u uniformly in the retained angular cell, prepares |L,u><L,u| tensor omega_(V,L), and inverts the representation decomposition. No j, L, continuous u, or independently sampled spin label is persistent storage.

Equations (3)-(8) prove, with absolute chart constants and S-dependent comparison constants,

    e <= 1-exp(-t)+epsilon,
    D_code <= C_S epsilon^(-3)
                 (1+Vt)[1+log(1+Vt)].                 (9)

The same construction works for every known SU(2)-invariant H_V; MP is not needed for its upper bound.

## 5. Supercritical dimension converse

Under the coherent measurement,

    E||u-v||^2 <= 4/[a(L+2)].

On the event j>=mV/2 this is at most 4/(amV). If Vt->infinity, aV is asymptotic to Vt. Choose a maximal chordal sphere packing at separation Delta, where

    Delta^2=256/(amV).

For large V, Delta<=1. Maximality gives a cover by chordal caps of squared radius Delta^2. Their normalized area is Delta^2/4, so the packing size satisfies

    N>=4/Delta^2=amV/64.

Nearest-direction classification of u has failure at most

    q^t(j<mV/2)+4 E||u-v||^2/Delta^2
      <= o(1)+1/16.

It is at most 1/8 eventually. If an archive has e<=1/8, classification after decoding succeeds with probability at least 3/4.

For N equiprobable hypotheses, D-dimensional memory states sigma_i and a POVM F_i have

    average success
      = (1/N)sum_i Tr(sigma_i F_i)
      <= (1/N)sum_i Tr F_i = D/N,

since sigma_i<=I. Conditioning on input-independent common randomness leaves this inequality valid. Thus

    D >= 3amV/256 >= 3mVt/512, 0<t<=1.                (10)

Choosing epsilon=1/log(e+Vt) in (9) gives vanishing error and

    log_2 D_code
      <= log_2(Vt)+4log_2 log(e+Vt)+O_S(1).

Together with (10), this establishes the optimal leading retained cost

    log_2 D = (1+o(1))log_2(Vt).

This is a first-order assertion. It does not establish an additive O(1) remainder or optimal precision overhead.

## 6. Zero-memory regime and its exact converse

If Vt->0, the spectral bound |t J_v|<=SVt gives

    rho_(V,t,v) >= exp(-2SVt)rho_(V,0),
    T(rho_(V,t,v),rho_(V,0))
       <= 1-exp(-2SVt).

A one-label decoder that prepares the known zero-field Gibbs state therefore has vanishing error.

For opposite directions, the exact sector root fidelity is

    F_root(tau_(j,t,+z),tau_(j,t,-z))
      = (2j+1)sinh(t/2)/sinh((2j+1)t/2).

The full direct-sum root fidelity is the q^t-weighted sum of these numbers, since the sector laws and multiplicity states are the same. By (1), along any subsequence with Vt bounded below by a positive constant this fidelity stays strictly below one. The opposite-direction trace distance is bounded away from zero. Any parameter-independent decoded output has worst-case error at least half that distance.

If Vt->infinity, the root fidelity tends to zero and the one-label worst-case error is at least 1/2-o(1). Thus vanishing zero-memory error holds if and only if Vt->0, including oscillating sequences by the subsequence argument. This conclusion is also valid with input-independent common randomness: with no input-dependent message its averaged output remains independent of v.

## 7. Critical spherical limit

Suppose Vt->c in (0,infinity). The bounded-tilt argument gives j/V->m under q^t. On typical sectors Lt->2mc and Lt^2->0. Expanding the two exact positive densities above, uniformly in u and v, yields

    Q_(L,v)(u), P_(L,v)(u)
       -> f_(alpha,v)(u)
          = [alpha/sinh(alpha)]exp(alpha v·u),
    alpha=mc>0.                                     (11)

All densities are uniformly bounded when Lt is bounded. Consequently

    delta_Q,V
      = (1/2)sum_j q^t(j) integral|Q_(2j,v)-f_(alpha,v)|dmu ->0,
    delta_P,V
      = (1/2)sum_j q^t(j) integral|P_(2j,v)-f_(alpha,v)|dmu ->0,

with values independent of v by rotation. This is convergence of the exact coherent experiment and its positive preparation law, not a Gaussian approximation.

The original Legendre rank proof is correct for one fixed factorization through a D-dimensional memory: each fixed-degree coefficient is positive by Rodrigues,

    integral exp(alpha z)P_ell(z)dz
      = alpha^ell/(2^ell ell!)
        integral exp(alpha z)(1-z^2)^ell dz >0,

and an expectation matrix built from D^2+1 degrees has full limiting rank.

That proof alone does not cover free common randomness. Averaging seed-dependent low-rank matrices can produce a matrix of arbitrary rank. The following stronger argument repairs that scope gap.

## 8. Quantitative critical converse, including common randomness

Use the exact positive representation (2). Replace its angular density in every sector by f_(alpha,v), paying delta_P,V. With that replacement, the uniformly distributed latent direction u is encoded into the memory state

    sigma_(u,R)
       = sum_j q^t(j)
           Enc_R(|2j,u><2j,u| tensor omega_(V,j)),

where R denotes optional input-independent common randomness. This is a normalized D-dimensional density. The decoder followed by the full-sector coherent POVM is a sphere-valued POVM E_R(du') on memory. Hence the entire code induces

    K_V(u,du')=E_R Tr[sigma_(u,R)E_R(du')].

By trace/TV contraction and (11),

    sup_v TV(f_(alpha,v)K_V, f_(alpha,v))
       <= eta_V = e_V+delta_P,V+delta_Q,V.              (12)

Let

    lambda_alpha = coth(alpha)-1/alpha >0.

Rotational invariance and differentiating the spherical exponential normalizer give the reciprocal first-moment identities

    integral u f_(alpha,v)(u)dmu(u)=lambda_alpha v,
    integral v f_(alpha,v)(u)dmu(v)=lambda_alpha u.

Apply the bounded test v·u' to (12), and integrate over v. Fubini and the second identity give

    lambda_alpha [1-E(u·u')] <= 2 eta_V.

Thus

    E||u-u'||^2 <= 4 eta_V/lambda_alpha.                (13)

For clarity, the expectation is under u uniform and u' sampled from K_V; no measurement can be chosen using the retained input record in this argument.

There is a dimension-only opposite bound. For any 0<=x<=4, sigma_(u,R)<=I and Fubini imply

    Pr(||u-u'||^2<=x | R)
      <= integral dmu(u) Tr E_R({u':||u-u'||^2<=x})
      = (x/4) Tr I = Dx/4.                            (14)

The equality uses the exact normalized area x/4 of a chordal sphere cap of squared radius x. It remains true after averaging over R. Therefore

    E||u-u'||^2
      >= integral_0^(4/D)(1-Dx/4)dx = 2/D.              (15)

Combining (12)-(15) proves

    e_V >= lambda_alpha/(2D)
                   -delta_P,V-delta_Q,V.              (16)

This supplies both a quantitative error floor for every fixed D and the necessary conclusion D_V->infinity for vanishing error. It applies to all classical, quantum and hybrid codes, including an uncharged input-independent common seed. It does not require any rank bound on the averaged code.

## 9. Checked critical upper of inverse-capacity order

The general alphabet (9) already proves that every divergent classical capacity suffices in the critical regime. The following positive quantization improves the precision overhead, and audits the sibling's smooth-chart refinement.

Fix a finite smooth sphere atlas and a smooth nonnegative partition of unity eta_i whose supports lie compactly inside its coordinate domains. Let u_i(x) be a chart, and let J_i(x) be its area Jacobian for normalized mu. Define the globally C1, compactly supported weight

    w_i(x)=eta_i(u_i(x))J_i(x),

extended by zero outside the chart domain. All chart derivatives on the relevant compact neighborhoods are uniformly bounded.

Use the tensor-product hats on the square lattice of spacing h,

    A_k(x)=product_(a=1)^2 (1-|x_a/h-k_a|)_+,
    c_k=hk.

They form a partition of unity and satisfy sum_k c_k A_k(x)=x. Define

    phi_(i,k)(u)=eta_i(u)A_k(coord_i(u)),
    M_(i,k)=integral phi_(i,k)(u)dmu(u).

Retain only active labels M_(i,k)>0. They are finite in number and

    N_h <= C_0 h^(-2).

Encode u to label (i,k) with probability phi_(i,k)(u); decode that label with density phi_(i,k)(u')/M_(i,k). These are nonnegative, exactly normalized kernels. The density operator is

    R_h f(u') = sum_(i,k) phi_(i,k)(u')
                   [integral phi_(i,k)(u)f(u)dmu(u)/M_(i,k)].

Here is the weighted-centroid step that needs care. In chart i set

    b_(i,k)=integral (x-c_k)A_k(x)w_i(x)dx,
    d_(i,k)=b_(i,k)/M_(i,k).

Unweighted hats are symmetric around their centers. Subtracting w_i(c_k) inside the integral gives

    |b_(i,k)|
       <= Lip(w_i) integral |x-c_k|^2 A_k(x)dx
       <= C_i h^4.

There are O(h^(-2)) active hats, so

    sum_(i,k) M_(i,k)|d_(i,k)| <= C h^2.                (17)

No lower bound on individual M_(i,k) is used; in particular small chart weights do not create an uncharged singularity.

For a C2 density f in every compact chart neighborhood, Taylor's formula gives its weighted conditional average as

    f_i(c_k)+grad f_i(c_k)·d_(i,k)+O(h^2||Hess f_i||_infinity).

Tensor-hat interpolation is exact on affine functions, so its nodal f_i(c_k) part approximates f_i(x') by O(h^2||Hess f_i||_infinity). Integrating the centroid term with phi_(i,k) and using (17) gives

    ||R_h f-f||_1 <= C_f h^2.

The family f_(alpha,v) has uniformly bounded C2 chart norms for fixed alpha, independently of v. Hence

    sup_v TV(R_h f_(alpha,v), f_(alpha,v))
       <= C_alpha h^2.                               (18)

For the actual quantum code, coherently measure (j,u), discard j, and store only the finite chart/hat label. The decoded state samples j' independently from the known q^t, samples u' from the label's fixed density, and prepares |2j',u'><2j',u'| tensor omega_(V,j'). If barQ_v=sum_j q^t(j)Q_(2j,v), its decoded angular density in every output sector is R_h barQ_v.

Comparing to the exact positive target P_(2j,v) gives

    e_V <= TV(R_h barQ_v,f_(alpha,v))+delta_P,V
         <= C_alpha h^2+delta_Q,V+delta_P,V.             (19)

This residual is independent of h and D. For sufficiently large D choose h of order D^(-1/2) with N_h<=D. Enlarging constants covers smaller D by a one-label channel. Thus

    e_V <= C_alpha/D+delta_Q,V+delta_P,V.               (20)

Every retained label includes its chart index i and grid index k. No sector label is retained in this critical refinement.

Equations (16) and (20) give matching inverse-D orders in the iterated thermodynamic/precision sense. For arbitrary joint D_V growth the additive residuals must remain visible; MP supplies no rate for them. They are not a proved uniform exact finite-V minimax asymptotic.

## 10. Regime verdict

- Vt->0: one classical label, zero bits, and error O(Vt) suffice. Vanishing zero-memory error implies this regime.
- Vt->c>0: D must diverge; every arbitrarily slowly divergent classical D suffices. In the iterated critical limit, fixed-D errors are bounded above and below by positive alpha-dependent constants times 1/D.
- Vt->infinity: every constant-error quantum/hybrid/classical code needs D>=c_m Vt. A classical code attains log_2 D=(1+o(1))log_2(Vt) with error tending to zero.

These verdicts use the exact t J convention. For t=V^(-gamma), the subcritical threshold is gamma>1, the critical threshold gamma=1, and the supercritical retained first-order cost is (1-gamma)log_2 V for 0<gamma<1.

The theorem preserves averaged density matrices. Preserving a purification, conditionally fresh outputs after the record is inspected, unknown t/beta/H, and affordable multiplicity Gibbs preparation are different interfaces.

## 11. Physical source boundary and established example

The local source copied by the sibling is the OpenAI manuscript The spherical magnetization law for the three-dimensional quantum Heisenberg ferromagnet. Its Section 8, equation spin-concentration, asserts exactly j/V->m>0 in the zero-field state. The source proof relies on earlier spatial comparison, equilibrium-radius and pressure arguments. This audit read the stated concentration step and checked its role; it did not validate those earlier lemmas. Consequently the nearest-neighbor three-dimensional application is conditional.

Exact released source:

https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/The-spherical-magnetization-law-for-the-three-dimensional-quantum-Heisenberg-ferromagnet-October-5-2026/build/sections/08-global-spin.tex

The established complete-graph example was checked live in Bjornberg-Frohlich-Ueltschi, Quantum spins and random loops on the complete graph, Theorem 2.1:

https://arxiv.org/html/1811.12834v2

It uses H=-(2/V)sum_(i<j)S_i·S_j and spin-normalized generators. Above beta_c=3/[2S(S+1)] its m is positive. Its component Laplace-transform theorem implies MP: conditional on j, a component is uniform over -j,...,j. Its second and fourth normalized moments imply E(j/V)^2->m^2 and E(j/V)^4->m^4, so Var((j/V)^2)->0. Bounded support justifies taking these moments. This establishes an application of the abstract archive theorem independently of the new local-source claim.

## 12. Evidence status

The accompanying verification.py checks exact finite spin identities with rational arithmetic, coherent EB diagonal minorants, angular means, monotone same-parity tilts, and finite Legendre evaluation matrices. It also records floating-point critical P/Q convergence diagnostics. These fixtures can catch implementation and normalization mistakes; the proofs above, rather than those checks, establish the asymptotic statements.

The original common-randomness rank gap is expressly repaired by Section 8. Priority and external validation remain open.
