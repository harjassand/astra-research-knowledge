# A charged commuting amplification and its finite-encoding boundary

7 October 2026. Status: new scoped composition, internally derived. The inherited commuting threshold theorem remains an internally reconstructed, externally unvalidated theorem. Lin's MIPco=coRE theorem is used as an external mathematical premise, not re-proved here. No quantum PCP, sparse positive encoding, new undecidability theorem, or historical novelty is claimed.

## 1. The application now has an acquired question gap

The named family is Junqiao Lin's two-prover, one-round commuting verifier from *MIPco=coRE*, [arXiv:2510.07162v1](https://arxiv.org/abs/2510.07162v1), Sections 6.1 and 6.2, Definitions 6.1 and 6.2. For input z of length n its sampler Q and predicate D run in polynomial time. The finite question and answer sets are binary strings of polynomial lengths x(n) and a(n). The promised game value is 1 in the yes case and at most 1/2 in the no case. Theorem 1.1 and the completeness reduction identify a coRE-complete family. The article's full compression proof was not audited in this run; the exact verifier interface and theorem statement were checked in its primary text.

This is an implicit sampler interface. An explicit probability table can have exponential size. Polynomial sampler time, synchronous structure, or membership in the conditionally linear class does not by itself certify an inverse-polynomial question gap; Section 4 gives a new symmetric obstruction.

We acquire the gap with an explicit one-sided wrapper. Sample the original pair (x,y), then two independent fair bits. If the bits are 00, send Alice the erased question bottom and Bob y. Otherwise send x and y. Bob's question and answer alphabet remain the original ones. Alice gains the answer bottom. On an erased question accept if Alice answers bottom; on an ordinary pair require ordinary answers and apply D. Thus

    nu(x,y) = 3 mu(x,y)/4,
    nu(bottom,y) = mu_Y(y)/4.

There is no rejection sampling and no need to list the support graph. This differs from the inherited two-sided half-erasure wrapper; the present application also charges the named verifier's complete interface.

### Exact value identity

For any finite game and either the commuting or finite tensor model,

    omega(G_skip) = 1/4 + 3 omega(G)/4.

For the lower bound, use any original strategy and answer bottom deterministically on the erased input. For the upper bound, erased-branch acceptance is at most one. On every ordinary Alice input, merge its bottom POVM effect into a fixed original answer a0. This preserves positivity, completeness and all cross-input commutators. Original accepting ordinary pairs remain, and any added accepting terms are positive, so the ordinary branch's original-game success can only increase. Its success is therefore at most omega(G). No supremum attainment is assumed.

### Exact question-gap identity

Let rho_mu be the maximal correlation of the two original questions, including rho_mu=1 when there is a nonconstant common component label. If a centered function A of Alice's erased question has ordinary mean m, centering gives A(bottom)=-3m. For a centered function B of Bob's original question,

    ||A||_nu^2 = (3/4) Var_mu_X(A_ordinary) + 3 |m|^2,
    ||B||_nu^2 = Var_mu_Y(B),
    <A,B>_nu = (3/4) Cov_mu(A_ordinary,B).

The correlation supremum is consequently

    rho_nu = sqrt(3/4) rho_mu.

The upper bound follows from Cauchy-Schwarz and the original maximal-correlation definition. Equality follows by choosing ordinary mean-zero maximizing functions, with A(bottom)=0; finite alphabets make this a finite singular-value problem. If one centered local-function space is zero, take rho=0 and retain the lower bound below.

The erased input is adjacent to every supported Bob question, and every ordinary Alice question has a supported Bob neighbor. Hence the pair support is connected. For the resampling operator P=(P_X+P_Y)/2 the nonconstant spectral maximum is at most (1+rho_nu)/2. This follows by the two-projection principal-angle decomposition, or by applying

    ||P_X f + P_Y f||^2
        <= (1+rho_nu) (||P_X f||^2+||P_Y f||^2)

to centered f and using <f,P_X f+P_Y f>=||P_X f||^2+||P_Y f||^2. Therefore

    sigma_nu >= (1-rho_nu)/2
              >= (2-sqrt(3))/4 > 1/15.

The rational comparison is exact: sqrt(3/4)<13/15 because 3/4<169/225. Degenerate local spaces can only improve the stated bound. Thus this is a supplied proof certificate for a constant question gap, acquired with two coins.

## 2. Fully charged exponential amplification of the named family

In a no instance, omega^co(G_skip)<=5/8. Let H_k send the complete local strings for k independent copies of G_skip and accept only if every copy accepts. The connected inherited theorem, at its all-wins endpoint, gives

    omega^co(H_k)
      <= exp[-sigma_nu (3/8)^3 k/(1024(1+ln d_skip))]
      <= exp[-27 k/(7864320(1+ln d_skip))],

    d_skip = (|A|+1)|B|.

A yes instance retains value 1: k independent copies of strategies approaching the one-game supremum approach perfect all-wins success. This does not require a finite perfect strategy or a finite dimension bound.

For the named symmetric binary alphabets, 1+ln d_skip <= 2a(n)+2. Hence any integer L>=1 and

    k = ceil[7864320 (2a(n)+2) L / 27]

guarantee no-instance commuting value at most exp(-L), while yes-instance value remains 1. The constant is conservative and large; this is a theorem-level protocol bound, not a practical efficiency claim.

Let the original sampler use s(n) random bits and time T_Q(n), and let predicate time be T_D(n). The complete ledger is:

* Random bits: k(s(n)+2), with a fixed finite seed. Original pairs are independent across copies.
* Questions: Alice k(x(n)+1) wire bits, Bob k x(n) bits, using one erasure tag bit for Alice.
* Answers: Alice at most k(a(n)+1) wire bits, Bob k a(n) bits. A canonical dummy encoding gives logical answer size |A|+1; if all tagged bit strings are accepted as aliases of bottom, the larger wire alphabet only changes ln d to the displayed bound 2a(n)+1.
* Referee time: O(k[T_Q(n)+T_D(n)+x(n)+a(n)]). The all-wins predicate checks k tests; ordinary-test branch tags and canonical encodings are checked explicitly.
* Communicated/storage strings grow by k. No player, round, or quantum message is added. The referee's total test locality grows with k.
* Construction time is polynomial in n and L. No graph enumeration, value computation, strategy construction, or approximation by finite tensor models is used.
* This is a final protocol amplification. The one-sided wrapper changes the two local alphabets and question-law symmetry; it is not proved to retain Lin's synchronous CL normal form or the oracularizable-strategy interface required inside his compression theorem.

These are new charged consequences of the inherited theorem and a named external verifier. The source theorem already supplies generic amplification, and the wrapper is an elementary optimization of anchoring. The result is not advertised as a new foundational repetition theorem.

The continuous optimum explains the choice 3/4. For ordinary-branch probability p, one-sided erasure gives sigma >= (1-sqrt(p))/2 and original loss is multiplied by p. The worst-law cubic coefficient is

    (1-sqrt(p)) p^3 / 2.

It is maximized at sqrt(p)=6/7, i.e. p=36/49. The dyadic p=3/4 is within one percent of this optimum and needs exactly two fair bits. Using 36/49 would require specifying and charging a non-dyadic sampling implementation. This constant optimization does not change the cubic gap power.

## 3. Exact operator loss control, and a noncomputable generic bridge

For fixed k, form the universal unital C*-algebra generated by Alice and Bob's complete projective measurements on whole question strings, with all cross-player generators commuting. This can be described as the maximal tensor product of the two finite measurement universal algebras. Define its acceptance element R_k as the nu^k-weighted sum of accepting products. Each product is positive, and all joint outcomes sum to identity, so 0<=R_k<=1.

Every state of this universal algebra gives, through GNS, a legal commuting strategy. Conversely commuting projective strategies define its representations, and the inherited dilation treats POVMs without changing the value. Thus the scalar amplification is exactly the universal operator inequality

    R_k <= exp(-L) 1,
    Loss_k = 1-R_k >= (1-exp(-L)) 1

on no instances, uniformly over every Hilbert space and measurement representation. On yes instances, ||R_k||=1 and the universal loss has spectral infimum zero. This is a representation-independent operator assertion. It does not specify a finite matrix, its basis, any row support, or any efficiently acquired realization.

There is a decisive generic obstruction. Conditional on Lin's coRE-completeness theorem, no total computable algorithm can take every game in this named promised family and output a finite effectively specified Hermitian matrix K and effectively separated thresholds alpha<beta such that

    yes => lambda_min(K)<=alpha,
    no  => lambda_min(K)>=beta.

The matrix can use arbitrary finitely many auxiliary registers; no polynomial dimension, time bound, sparsity bound or fixed positive gap is needed for the contradiction. The only requirements are that the finite dimension is effectively known and entries are uniformly computable to a requested certified precision. A row oracle with a terminating row enumeration and precision guarantee meets this interface.

Proof: reduce a coRE-complete language instance z to its promised game, run the hypothetical compiler, enumerate its finite matrix, approximate its smallest eigenvalue to less than (beta-alpha)/4, and compare with (alpha+beta)/2. Every operation terminates. This decides the coRE-complete language, contradicting undecidability. For computable-real thresholds, first refine their certified intervals until a positive rational separation is found; the strict promised separation guarantees termination. Certified entrywise approximation gives an operator approximation through ||E||<=N max_ij|E_ij|, and finite rational Hermitian eigenvalues are computable. Positivity, sparsity or normalization cannot repair the contradiction.

This is a standard computability implication of the named theorem, not a new undecidability result. It does not depend on the inherited repetition theorem: the original 1 versus 1/2 promise is already enough. Amplification exposes the same barrier at a nearly unit universal operator loss.

The obstruction does NOT exclude the imported sparse-PCP target. That target starts from a decidable QMA local-Hamiltonian subclass with an actual finite input Hilbert space. It still asks for one common efficiently represented isometry V and positive sparse B,C protecting every auxiliary state. It does not demand a finite spectral realization of all commuting games. A successful restricted QMA compiler, a non-total search procedure, an infinite-dimensional operator, a finite hierarchy that only semidecides one side, or an oracle without certified computability all evade this no-go.

The theorem closes a hidden generic interface, not the QMA positive-encoding bottleneck. Repetition bounds a universal nonlocal-game acceptance element; the imported PCP target requires an acquired finite row-enumerable operator encoding of the actual five-qubit amplified Hamiltonian family. Neither object supplies the other automatically.

## 4. A synchronous conditionally linear sampler with exponentially small gap

The inherited CL counterexample did not by itself establish the obstruction for a symmetric, diagonal-positive sampler. Here is that additional stress case.

Let U,V be independent uniform r-bit strings and T an independent fair bit. Send

    X = (U, 1[U!=0] T),
    Y = (V, 1[V!=0] T).

The law is symmetric. Every supported question has positive diagonal mass. Its pair support is connected: the zero-prefix view (0,0) occurs for either latent T and connects the two otherwise separated latent-bit blocks. It uses 2r+1 seed bits, r+1 wire bits per player, and O(r) sampling time. It is a valid two-level conditionally linear distribution in Lin's Definition 5.1: the first level is a linear prefix selection; the second selects either the linear T-coordinate or zero according to the visible prefix. Padding later registers with zero embeds it into the seven-level class.

Put epsilon=2^-r and Z(X)=(-1)^T when U!=0, with Z(0,0)=0. Then E Z=0 and E Z^2=1-epsilon. The two views are conditionally independent given T; their centered cross-covariance has rank one. Its sole nonzero singular value is

    rho = 1-epsilon.

Indeed E[Z(X)Z(Y)]=(1-epsilon)^2 and division by the equal marginal norms gives rho. Hence

    sigma = (1-rho)/2 = 2^(-r-1).

An exact pair-chain eigenfunction is Z(X)+Z(Y), with eigenvalue 1-epsilon/2. This gives both the gap witness and an independently checkable finite certificate. It disproves extracting an inverse-polynomial original gap from synchrony, diagonal positivity, a fixed CL level and a linear-time sampler alone. It does not establish the actual hard Lin sampler's gap, which remains uncomputed. The charged skip wrapper avoids needing that unknown interface.

## 5. Internal checks and boundaries

The companion check script independently forms finite resampling matrices. It checks the skip Poincare certificate with exact rational LDL/Schur elimination, checks exact affine classical values for small fixtures, compares maximal-correlation and chain spectra numerically, and verifies the symmetric CL eigenfunction exactly. These are implementation/stress checks. The universal proofs above do not follow from finite experiments.

The source folder was read-only. Source proof read depth: all seven family277 section files (introduction, marginals, operators, exposure, threshold, root support and consequences) were read in full, as was the complete inherited COMMUTING_THRESHOLD_EXTENSION.md. No release Lean build or external expert review was performed. Broader prior review is still required before claiming that any of these particular compositions or constants are historically new.
