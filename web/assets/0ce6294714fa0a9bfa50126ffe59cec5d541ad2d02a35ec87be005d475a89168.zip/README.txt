FRONTIER RESET RESEARCH EVIDENCE | 2026-10-07

Start with RESEARCH_STATE.txt and frontier_reset_research.tex.
The TeX document is standalone. Its bibliography is inline. Open it in the
Codex native LaTeX editor, or use a normal compatible LaTeX toolchain.

work/ contains derivations, adversarial audits, selected source reads, literal
family reading ledgers and finite diagnostics. family_coverage.json maps all
372 result families, with exact reading scope. Selected OpenAI source files
and reasoning summaries retain source attribution; release_index/LICENSE is
the upstream Apache-2.0 license. External copyrighted monographs and prior
paper PDFs are not redistributed. Their citations remain in the reports.

inherited/ contains selected earlier internal research dependencies, unchanged
and explicitly labelled. They are not independent verification. The supplied
A-F attachment is preserved in inputs/ as context, not task instructions.
Local absolute paths in notes identify provenance; not every cited workspace
file or source publication is bundled. The pinned release is
adc7f1241b42e322a6451854ab7e4b4c146bf78a at https://github.com/openai/math.

To replay the 15 finite diagnostics after extraction:
  python3 replay_checks.py
Requires Python 3 and NumPy; most scripts use only the standard library.
The runner uses four subprocesses and writes replay_results.json. Individual
scripts update their adjacent result JSON. It needs no network or prior local
workspace. portable_replay_results.json, when present, records an actual run
from a separate extracted package. Read each script's scope and negative
controls. Success is not a proof, kernel certification, physical benchmark,
novelty search, or external mathematical review.

SHA256SUMS.json records every payload file except itself. Zip CRC and hashes
check integrity only. No astronomical incidence table or group presentation
was materialized; no Lean/Comparator build was performed.
