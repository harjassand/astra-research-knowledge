# Reasoning mechanisms: tested transfer and exact reading record

Date: 2026-10-07. Source snapshots remained read-only. Official release pin: `adc7f1241b42e322a6451854ab7e4b4c146bf78a`.

**New result in this run:** the stable-law mechanism in family 271 cannot supply exact-marginal sampling for arbitrary Boolean polytopes with short edges. A constant-cardinality, four-vertex polytope has edge support four and an easily sampled exact-mean law, but every real-stable law on its legal vertices is a point mass. The exact-mean law also violates the source's joint-presence inequality. Cartesian products keep edge support four in arbitrary dimension. This is an obstruction to a proposed transfer, not a refutation of the Heisenberg source or the existing ROUND objective.

All ten released summaries are covered below. Current-run reading was full substantive narrative for six and selected, explicitly listed sections for four; inherited full-narrative reading of all ten is credited separately. This report does **not** represent the inherited reading as fresh reading or any narrative as a checked proof of its headline theorem.

## 1. The mechanism and the target interface

The attached A–F state includes ROUND: for a Boolean polytope \(P=\operatorname{conv}V\subset[0,1]^n\), with actual maximum edge support \(k(P)\), produce a law supported on legal vertices, preserve the supplied mean \(y\in P\) exactly, and control every supported atom's discrepancy for a matrix with unit Euclidean columns. Its support bound is \(\dim F(y)+1\le n+1\). The attachment seeks a constructive, costed implementation; it does not demand negative association or stability. Its exact source is `/Users/harjas/.codex/attachments/2f87408a-6b4c-49c5-b868-d29f20d801d1/Pasted text.txt`, particularly its ROUND section. Later inherited results keep the implementation/acquisition gap open.

The [271 summary](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/reasoning_traces/spontaneous-magnetization-quantum-heisenberg-ferromagnet.pdf), §§1,3–5, describes a stable polynomial for the full, unexposed pin-output law. The manuscript's `02-pin-test.tex`, lines 1–370, gives the concrete algebra: begin with

\[
 F_\pi(x,y)=\prod_i(x_i+y_{\pi(i)}),
\]

apply independent partial symmetrizations for Bernoulli transpositions, then splice an unpinned coordinate by setting \(x_q=y_q=t\) and taking the coefficient of \(t\). Splicing a closed cycle contributes the required factor two. Stability is retained along these **specific** operations. The resulting law has the joint-presence bound

\[
 \Pr(J\subseteq A)\leq\prod_{j\in J}\Pr(j\in A).
\]

The useful transfer hypothesis to test is therefore concrete: *can every short-edge Boolean polytope admit a real-stable legal-vertex law with a prescribed mean?* A positive answer would provide a source of concentration, but it adds a substantive premise beyond ROUND. The following test rejects it.

## 2. Counterexample and universal stable-support lemma

Start with

\[
 V=\{000,110,101,011\},\qquad y=(1/2,1/2,1/2).
\]

The four points are affinely independent, so \(P=\operatorname{conv}V\) is a tetrahedron. Every pair is an edge and differs in two coordinates; hence \(k(P)=2\). Writing the three mean equations and total mass equation forces each atom's probability to be \(1/4\). Its generating polynomial is

\[
 G(z)=\tfrac14(1+z_1z_2+z_1z_3+z_2z_3).
\]

At \(z_1=z_2=z_3=i/\sqrt3\), every variable lies in the open upper half-plane and \(G=0\), so the law is not real stable. All three pairwise coordinate covariances nevertheless vanish. The stronger diagnostic gives

\[
 \operatorname{Cov}(X_1,\mathbf1\{X_2\lor X_3\})=1/8>0,
\]

so pairwise covariance tests alone miss the failure of negative association.

To retain constant cardinality, lift each atom to \((v,1-v)\):

\[
 V'=\{000111,110001,101010,011100\},\qquad y'=(1/2)^6.
\]

Again this is an affine three-dimensional simplex. Every atom has cardinality three, every edge changes four coordinates, and \(k(P')=4\). The first three mean equations still force the unique law \(U\), uniform on the four atoms. With one-based coordinates \(J=\{2,3,4\}\), precisely the atom \(011100\) contains \(J\). Thus

\[
 \Pr_U(J\subseteq X)=1/4>1/8=\prod_{j\in J}\Pr_U(X_j=1).
\]

This directly violates the proposed transferred presence bound. In fact all non-complement coordinate pairs are independent; complement pairs have negative covariance. Even constant cardinality together with nonpositive pairwise covariances is insufficient.

**Lemma. Every real-stable probability law supported on \(V'\) is a point mass.**

Proof. The four supports are

\[
 S_0=\{4,5,6\},\quad S_1=\{1,2,6\},\quad
 S_2=\{1,3,5\},\quad S_3=\{2,3,4\}.
\]

Suppose two distinct atoms \(S_a,S_b\) have positive weights \(p,q\). They share exactly one coordinate \(c\). The other two supports share a coordinate \(d\) absent from \(S_a\cup S_b\). Set \(z_d=0\). This kills precisely the two other monomials and leaves

\[
 z_c(pz_uz_v+qz_rz_s),
\]

where the exclusive pairs \(\{u,v\}\) and \(\{r,s\}\) are disjoint. Give these variables the values

\[
 z_c=i,\quad z_u=1+i,\quad z_v=q(1+i),\quad
 z_r=-1+i,\quad z_s=p(-1+i).
\]

All five remaining variables have positive imaginary part, and the two terms cancel because \((1+i)^2=2i\), \((-1+i)^2=-2i\). This contradicts stability under real specialization.

For an elementary proof avoiding that closure theorem, restore \(z_d=i\varepsilon\). The full generating polynomial is affine in \(z_u\), say \(A(\varepsilon)z_u+B(\varepsilon)\). At zero its coefficient is \(ipq(1+i)\neq0\), and its root is \(1+i\). For sufficiently small positive \(\varepsilon\), the root \(-B(\varepsilon)/A(\varepsilon)\) still has positive imaginary part by continuity. All six variables now lie in the open upper half-plane, producing an actual zero of the full polynomial. Arbitrary weights on the two killed atoms do not affect the argument. Therefore two positive atom weights are impossible. Every point-mass polynomial is a nonzero monomial and is stable. ∎

Consequently, among stable laws on these legal vertices,

\[
 \min\|\mathbb E X-y'\|_\infty=1/2,\qquad
 \min d_{\rm TV}(\mathcal L(X),U)=3/4.
\]

Both are sharp because every stable law is a point mass. Thus allowing a small mean error or a small distributional repair cannot rescue this transfer while retaining the legal support.

For every \(r\ge1\), use \(P_r=(P')^r\subset[0,1]^{6r}\). An edge of a Cartesian product changes one factor, so \(k(P_r)=4\), while every atom has cardinality \(3r\). Any exact-mean law at \((1/2)^{6r}\) has the uniform marginal in each block and inherits the same triple-presence violation. Moreover a stable joint law would have stable block marginals under specialization of other variables to one. The lemma then forces every block, hence the whole joint law, to be deterministic. The elementary continuity proof above extends directly: specialize outer variables to one, create the isolated block root, then replace all outer variables by \(1+i\varepsilon\) and the deleted variable by \(i\varepsilon\).

This family satisfies the rounding interface in a particularly benign way. With \(A=I_{6r}\), every column has Euclidean norm one and every atom has discrepancy \(\|A(X-y)\|_\infty=1/2\). Uniformly sample one of the four lifted vertices and repeat it in every block. This legal law has exact marginals, four atoms (within the required support limit \(\dim F(y)+1=3r+1\)), rational weights \(1/4\), two fair bits total, and \(O(r)\) output time. A supplied linear objective over the full product polytope can be optimized by evaluating four block scores per factor; the rational arithmetic has polynomial bit cost in the original objective input. Short edges, efficient optimization, small discrepancy, and exact mean coexist with the stability obstruction.

## 3. What was tested, and which alternatives failed

The exact test is `work/stability_rounding_counterexample.py`, with output `work/stability_rounding_counterexample.json`. It uses rational arithmetic and \(\mathbb Q(i)\), with no optimization solver, numerical root finder, or simulation. `python3 work/stability_rounding_counterexample.py` exited zero. It checked both affine ranks, the unique \(1/4\) weights, all simplex edge supports, cardinalities, identity-feature discrepancy, the covariance and presence inequalities, the base algebraic root relation, and all six two-atom isolation patterns at three positive rational weight pairs (18 exact cancellations). It also checked the four-atom repeated-block control for 1, 2, and 5 blocks. The universal lemma follows from the displayed algebra and continuity argument, not from those 18 examples.

Three plausible repairs were deliberately tested:

1. **Check only pairwise covariances.** The base law has zero pairwise covariances and still fails negative association. The lift retains nonpositive pairwise covariances and fails the actual source-style triple inequality.
2. **Restrict to a fixed-cardinality support.** The complement lift makes every atom cardinality three while preserving the obstruction and giving the stronger point-mass classification.
3. **Repair or approximate within legal support.** The classification gives exact lower bounds \(1/2\) on marginal error and \(3/4\) on total variation. An unrestricted positive-polynomial repair could add illegal vertices, which changes ROUND's interface. Existing cycle19 work had already identified that support problem for the Fourier moment repair; it is not a new positive result here.

The uniformly sampled four-atom law is the equally informed control: it already performs the target mean-preserving task at constant cost. The stable mechanism cannot outperform it on this family because the stable mechanism cannot meet its feasibility condition.

The support also fails basis exchange: from \(S_0=\{4,5,6\}\) and \(S_1=\{1,2,6\}\), exchanging element 4 for either 1 or 2 gives an absent support. This identifies a concrete additional structural premise to investigate in a genuine application. The next useful observation is whether that application's legal support admits the exchange/partial-symmetrization/splicing operations; edge support alone cannot establish it. This report makes no claim that a stable representation is necessary for ROUND, or that all matroid rounding mechanisms fail.

The closest established framework is the relation between stable generating polynomials and negative dependence, described in [Borcea–Brändén–Liggett, *Negative dependence and the geometry of polynomials*](https://arxiv.org/abs/0707.2340v2), and restrictions on stable-polynomial supports in [Brändén, *Polynomials with the half-plane property and matroid theory*](https://arxiv.org/abs/math/0605678v4). Only their abstracts/metadata were read in this run; no result from their full proofs is required above. The elementary counterexample is a new tested application in this run, not a claim of historical novelty in stable-polynomial theory.

## 4. Mechanisms and failed alternatives across all ten summaries

The table records the mathematical operations worth attempting elsewhere and the failures that constrain them. Every headline result remains a source claim unless a separate proof audit establishes it. “Open gate” means unverified here, not a proved defect of the source.

| Family and official summary | Concrete transferable operation | Failed alternative and remaining gate |
|---|---|---|
| [007: ordinary two-point correlations](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/reasoning_traces/ordinary-two-point-correlations.pdf) | During prime-by-prime signed integration, keep return factors and separate weighted core edges from centered marks. Use a common witness cover for high mixed differences before eliminating variables. | Unconditional singleton cancellation can fail after exposure; logarithmic averaging or almost-all scales do not give the desired uniform scale. Conditional integration, residue classes, and forest bounds remain gates. Its low-order moment repair was already tested in cycle19 and is not a new mechanism here. |
| [017: irrationality exponent of pi](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/reasoning_traces/irrationality-exponent-of-pi.pdf) | Balance analytic decay against arithmetic height using weighted-simplex jet cuts and unitriangular truncations. Count independent error directions in the actual determinant, rather than the ambient matrix. | More matrix dimensions need not create more approximation signals; normalizing denominators can move height elsewhere. Shared-pole constraints and a missing nonzero denominator defeat naive Padé amplification. Geometric interpolation and ample-jet claims remain gates; no exponent-two conclusion is adopted. |
| [087: symmetric and general Mahler conjectures](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/reasoning_traces/symmetric-and-general-mahler-conjectures.pdf) | Preserve primal–dual contact and its residual loss. Separate linear Gaussian terms from even/odd chaos, then select a matrix Riccati covariance evolution to cancel the leading error without assuming commutativity. | Independent covariance choices miss polar vertices; scalar/commuting checks miss anisotropic obstructions; dropping residual budgets too early destroys the estimate. Uniform scalar certificates and the fixed-point/entropy chain remain gates. The Riccati kernel was already extracted in the inherited run. |
| [102: BasicSDP threshold hardness](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/reasoning_traces/basic-semidefinite-threshold-np-hardness.pdf) | Identify affine tables by a reduced common key before conditioning. In a sparse projection, balance many surviving witnesses against quadratic disruption; use a rank-hazard potential to charge exposure. | A favorable fiber's existence does not give abundance. Conditioning on a successful witness may destroy independence, and choosing alphabet size before required uniform constants can be circular. Uniform shortcode/decoder estimates remain gates. Sparse exposure and harmonic charging were already extracted. |
| [159: quasipolynomial arithmetic progressions](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/reasoning_traces/quasipolynomial-arithmetic-progressions.pdf) | Separate active precision from passive output width, retain marked output data, and impose a strict normalized buffer. Make width increments depend only on higher layers to obtain a triangular recurrence. | Dimension does not bound width. Same-layer feedback defeats triangularity; pairwise independence does not give a jointly positive configuration count. Reusing a sampler after cuts changes its law. The actual backward globalization and joint sampling guarantees remain gates. The triangular recurrence was already tested algebraically. |
| [197: Kaplansky direct finiteness in characteristic two](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/reasoning_traces/kaplansky-direct-finiteness-characteristic-two.pdf) | Keep characteristic-p cancellation separate from a global rank pairing; preserve group relations through explicit diagrams. A supplied one-sided inverse defect gives a concrete cellular-automaton injectivity/surjectivity witness. | Positive coefficient lifts, formal series, and finite-support group-ring elements have different interfaces. Local recovery can lose information at infinity, and finite quotients need not be faithful. Embedding/global construction gates remain unaudited. The cellular-automaton implication was already extracted and does not acquire the required inverse witness. |
| [221: Mézard–Parisi formula](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/reasoning_traces/mezard-parisi-formula.pdf) | Shift branching depth to expose a fresh factor that cancels a rare normalization. Control positive anchored squared replacement differences and average martingale contributions while keeping the background fixed. | Pinning can give the wrong weights, purity assumptions may fail, and continuity errors can blow up after division by small exponent gaps. Correlated extensions cannot replace the required conditional projections. The cancellation and continuity identities remain gates. |
| [271: Heisenberg ferromagnet](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/reasoning_traces/spontaneous-magnetization-quantum-heisenberg-ferromagnet.pdf) | Preserve a stable polynomial under partial symmetrization and cycle splicing; derive joint-presence bounds for the full unexposed law. Use conditional first moments and same-time heat leakage rather than an incorrectly refreshed path law. | Free-energy agreement does not establish order; mean defect bounds can permit walls; exposed clocks are not independent fresh clocks. This run disproves the general short-edge legal-support transfer, while leaving the actual pin construction and physical conclusion unrefuted. |
| [287: free group factor isomorphism](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/reasoning_traces/free-group-factor-isomorphism.pdf) | A spectral cutoff of a prefix-sum operator can turn small coefficient norm into a large observable image. Track trace-flow cancellation, summable tuple perturbations, and limiting generation as distinct obligations. | Decoder derivatives may be uncontrolled; small-corner errors can become order-one after amplification; recovering a missing generator can lose freeness. High-probability row bounds do not by themselves control width. The absorption flow and limiting-generation gates remain unverified. |
| [362: relativistic Vlasov–Maxwell](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/reasoning_traces/relativistic-vlasov-maxwell.pdf) | Combine transport and acceleration contributions with their signs before taking absolute values. Integrate by parts at fixed source labels, choose a speed-stable angular window, and charge first-exit occupation with the required field regularity. | Taking absolute values too early loses cancellation; an overly long window restores a linear bootstrap term; field regularity can be insufficient for the patch. Event counting and cutoff absorption remain gates. No transfer to unforced Navier–Stokes is established. |

These are mathematical mechanisms, not an effectiveness claim about prompting. The selected release has no matched experiment showing that a particular workflow reliably discovers or verifies arbitrary new theorems.

## 5. Reading and acquisition ledger

The [pinned official README](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/README.md) and source inventory identify the ten files. All ten official PDF blobs are now in `work/reasoning_traces/`, totaling 1,584,961 bytes and 202 pages. Seven were downloaded from the pinned official repository, while 007/102/159 were copied from already acquired pinned snapshots. Each Git blob SHA-1 was checked against the pinned tree inventory; SHA-256, size, official URL, page count, and extraction size are recorded in `METADATA.json`. There are 764,120 extracted characters. Integrity establishes source identity, not mathematical validity.

`READ_DEPTH.json` records exact compact-text line intervals and the PDF pages containing every freshly read section. `.txt` is the full pypdf layout extraction; `.compact.txt` only normalizes its whitespace. The ranges below are inclusive and refer to those current-run compact files. “Full” refers to every substantive numbered narrative section, not systematic bibliography or manuscript validation.

| Family | PDF pages | Current-run fresh reading | Exact compact-text intervals |
|---|---:|---|---|
| 007 | 7 | Full, §§1–5 | 50–263 |
| 017 | 42 | Selected §§1,7,9,10,15,30–35,39,44,45 | 16–58; 308–362; 407–517; 733–781; 1431–1698; 1808–1847; 2006–2102 |
| 087 | 45 | Selected §§1,2,18,22,27–29,35–38,47–49 | 35–182; 903–951; 1089–1139; 1317–1455; 1687–1835; 2083–2149 |
| 102 | 16 | Full, §§1–12 | 113–649 |
| 159 | 41 | Selected §§1,5,12,28,31,33,35,38,39 | 30–89; 247–298; 600–643; 1289–1352; 1481–1534; 1595–1655; 1721–1778; 1907–1989 |
| 197 | 23 | Selected §§1–4,14,16,18,20–23 | 78–239; 620–659; 700–732; 777–814; 859–1074 |
| 221 | 5 | Full, §§1–3 | 115–220 |
| 271 | 6 | Full, §§1–6 | 46–246 |
| 287 | 11 | Full, §§1–7 | 24–397 |
| 362 | 6 | Full, §§1–5 | 80–254 |

Some initial tool results clipped a section despite its acquisition; those sections were re-read separately. No clipped tail is counted as read. Bibliographies were sometimes visible but were not systematically checked. The four selected long summaries were not freshly read in their entirety.

Inherited full-narrative reading comes from `/Users/harjas/Documents/Codex/2026-10-07/you-have-access-to-over-100-5/work/reasoning_completion.md` and its `work/corpus/reasoning_map.json`, including separate-worker completion attestations for 087 and 159. Its full-narrative text ranges were: 007 1–333; 017 1–2202; 087 1–2248; 102 1–682; 159 1–2081; 197 1–1122; 221 1–248; 271 1–290; 287 1–412; 362 1–283. Those ranges refer to its extraction format, not the current compact files. They establish prior team reading, not an independent proof audit.

For nonduplication, this run read the inherited `mechanism_kernels.md` in full and section 7 of its `outputs/RESEARCH_STATE.txt`; it also read `/Users/harjas/Documents/ChatGPT/Literature Digestion/notes/frontier_methods/cycle19/VALIDATED_RESEARCH_MECHANISMS.md` in full. Earlier Fourier repair, same-information exact-law comparisons, sparse exposure, Riccati cancellation, triangular width accounting, and one-sided-inverse cellular-automaton implications were retained as prior work. None is advertised as newly discovered here.

The manuscript read for the tested mechanism was only family 271's `build/source/sections/02-pin-test.tex`, lines 1–370, under the inherited `work/corpus/repository/preprints/Spontaneous-magnetization-in-the-quantum-Heisenberg-ferromagnet-September-24-2026/`. This includes its stable-polynomial closure, partial-symmetrization, exchange-symbol, splicing, and presence statements. The remainder of the manuscript was not read or validated for this report. The pin construction's hypotheses are retained; the counterexample rejects extending them to every legal short-edge polytope.

## 6. Result status

The new universal stable-support lemma and its application to ROUND are proved above, with an exact finite implementation discriminator. This closes one plausible concentration-based route under the general legal-support interface. It does not solve the ROUND implementation, acquire a missing quantum spectral experiment, establish PCP auxiliary semantics, or validate any of the ten release headline claims. No source snapshot was edited, and no historical-priority claim is made.
