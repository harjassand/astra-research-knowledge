# Sharp Gaussian memory and nontracial spectral blocks

7 October 2026. Source workspaces and Literature Digestion were read only.

**Status.** Section 3A proves a sharp bounded Gaussian-experiment memory law by a direct posterior-risk/cap argument and a positive finite quantizer. The no-logarithm quantizer was proposed by root and reconstructed here. Its quantum iid consequences remain conditional on the inherited tracial Gaussian bridge. Sections 2--4 also give a complete written conditional extension of that bridge to a known block algebra. This is not independent certification of the bridge, an unrestricted partial-collision QLAN theorem, or historical novelty clearance. The unrestricted hybrid statement remains a candidate with a named missing factorization lemma. Finite checks diagnose conventions and moments; they do not prove trace-norm asymptotics.

## 1. Current inherited frontier, including the later run

The full state and report in `../you-have-access-to-over-100-2/outputs/` were read. Their strongest candidate gives spectrum-independent channels on every shrinking full-state tracial ball, with covariance `I_HS/d`, and originally error `O_d(delta+n^(-1/8))`. Its Schur/HCIZ normalizer, matrix log-Gamma model, and lattice inversion must stand separately. These are internally audited arguments, not externally validated theorems.

The later `../you-have-access-to-over-100-5/outputs/RESEARCH_STATE.txt` and `work/quantum_collisions/{branch_report,gaussian_rate_refinement,operational_limits}.md` materially advance that state:

* The same continuous channels have a written `O_d(delta+n^(-1/2))` bound, conditional on the inherited exact identities and coherent minorant. Capped reciprocal gaps can be integrated using the cubic Gaussian small-gap estimate. This is already inherited here.
* A positive tent kernel gives a finite classical alphabet
  `D <= 1+[C_d epsilon^(-1/2)(1+sqrt(n)delta+sqrt(log(4r/epsilon)))]^r`, `r=d^2-1`, with error `O_d(delta+n^(-1/2))+epsilon`. Its precision factor is an upper bound; no matching arbitrary-quantum precision converse is established.
* The exact d=2 tracial ordinary-jitter asymptotic is `sqrt(2/pi)/e * n^(-1/2)+O(n^(-1))`. This is specific to that encoder, not a channel-minimax lower bound.
* A correlated SU(2) Gibbs archive, with known Hamiltonian, temperature and field magnitude, has scale `Vt` when the zero-field total-spin law satisfies `j/V -> m*>0`. Leading growing-signal memory is `log_2(Vt)`, achievable classically. The critical precision law has dimension order `epsilon^(-1)`. The new local Heisenberg premise is still a release assertion; the established complete-graph premise is separate.
* Purification preservation requires quantum branch dimension `Q` with `error >= 1-sum_{i<=Q}lambda_i(rho^n)`, hence `error >= 1-Q||rho||_op^n`. At `I/d`, `Q >= (1-error)d^n`. Classical density-only compression does not preserve a purification.
* If a later experiment is selected using the original retained record, its risk is `E_c T(omega_c,rho^n)`. A two-point bound leaves an explicit positive floor on nontrivial critical local families. Ordinary averaged-density reconstruction covers later fixed protocols, including their own internal adaptivity.

The current Literature Digestion cycle19 root report was read in full. It expressly retains the supplied quantum collision result as `IMPORTED_UNAUDITED`; its new commuting-game repetition and sparse positive-enforcement work does not supply a Gaussian comparison theorem. The later quantum branch is therefore the appropriate starting point, not evidence that cycle19 validated the collision proof.

## 2. New scoped theorem: an entire known nontracial block algebra

Let `P_1,...,P_B` be known mutually orthogonal projectors summing to `I`, with ranks `m_b`. Fix

\[
 \rho_0=\bigoplus_{b=1}^B a_b I_{m_b}>0,
 \qquad w_b=m_ba_b,
 \qquad \sum_bw_b=1.
\]

For the interpretation as spectral blocks, the `a_b` are distinct; the construction itself does not need their separation. Dimension, block ranks and `rho_0` are fixed. Their projectors and weights are supplied to encoder and decoder. Within each block, both eigenvalues and eigenvectors of the unknown state are unknown. The input is `rho^tensor n`; reconstruction error is half trace norm of the *averaged reconstructed density matrix*.

Set

\[
 \mathcal A_0=\{H=H^*:H=\sum_bP_bHP_b,\ \operatorname{Tr}H=0\},
 \qquad s=\dim_{\mathbb R}\mathcal A_0=\sum_bm_b^2-1.
\]

Define a positive covariance operator `V_0` on this Hilbert--Schmidt space by

\[
 \langle H,V_0 L\rangle
   =\operatorname{Tr}(\rho_0 HL)
     -\operatorname{Tr}(\rho_0 H)\operatorname{Tr}(\rho_0 L).
 \tag{2.1}
\]

`rho_0` commutes with the entire block algebra, so the right side is real and symmetric. If `a_min=min_b a_b` and `a_max=max_b a_b`,

\[
 a_{\min}\|H\|_{\rm HS}^2\le\langle H,V_0H\rangle
       \le a_{\max}\|H\|_{\rm HS}^2.
 \tag{2.2}
\]

For the lower bound use
`Var_{rho0}(H)=min_c Tr rho0(H-cI)^2 >= a_min min_c ||H-cI||_HS^2`
and `Tr H=0`. These constants do not involve a within-block spectral gap.

For `delta<=delta_0(rho_0)`, let

\[
 \mathcal F_\delta=\{\rho\ge0:\operatorname{Tr}\rho=1,
    \rho=\sum_bP_b\rho P_b,\quad
    \|\rho-\rho_0\|_{\rm op}\le\delta\}.
\]

**Conditional theorem.** Assume the inherited tracial channels in every block dimension `m_b>=2`, with both comparison errors bounded by `C_{m_b}(alpha+k^(-1/2))` when `||m_b sigma-I||op<=alpha<=1/2`, and the inherited exact composition with the coherent measure/prepare channel. Then there are channels `T_n^A,S_n^A`, depending only on `n,rho_0` and the supplied projectors, for which

\[
 \sup_{\rho\in\mathcal F_\delta}
 \operatorname{TV}\left(T_n^A(\rho^{\otimes n}),
      N_{\mathcal A_0}(\sqrt n(\rho-\rho_0),V_0)\right)
     \le C_{\rho_0}(\delta+n^{-1/2}),
 \tag{2.3}
\]

\[
 \sup_{\rho\in\mathcal F_\delta}
 T\left(S_n^A N_{\mathcal A_0}(\sqrt n(\rho-\rho_0),V_0),
                         \rho^{\otimes n}\right)
     \le C_{\rho_0}(\delta+n^{-1/2}).
 \tag{2.4}
\]

The continuous channels do not depend on `delta` or the unknown `rho`. Consequently **every** `delta_n -> 0` is covered. The block spectra may collide at arbitrary rates, and `n delta_n^3` may diverge. For `B=1` this reduces to the inherited tracial bridge. For `m_b=1` for every block it reduces to the established classical multinomial comparison. The new intermediate case has noncommuting unknown states inside degenerate blocks and a genuinely nontracial center.

If only the original `k^(-1/8)` tracial remainder is accepted, exactly the same proof gives `O_{rho0}(delta+n^(-1/8))`; the new extension is not dependent on accepting the later rate refinement.

### 2.1 Exact finite decomposition, with no unavailable conditional law

Write

\[
 p_b=\operatorname{Tr}P_b\rho,\qquad
 \sigma_b=P_b\rho P_b/p_b,\qquad
 A_b=\sigma_b-I_{m_b}/m_b.
\]

For sufficiently small fixed `delta_0`, `p_b>=w_b/2` and

\[
 |p_b-w_b|\le m_b\delta,\qquad
 \|A_b\|_{\rm HS}\le C_{\rho_0}\delta,\qquad
 \|m_b\sigma_b-I\|_{\rm op}\le C_{\rho_0}\delta\le1/2.
 \tag{2.5}
\]

Measure the block projectors separately on the `n` input systems. Because the input is block diagonal, this is nondisturbing. The block word `j_1...j_n` has probability `prod_b p_b^(K_b)`, and the counts obey `K~Multinomial(n,p)`. Conditional on `K`, every word with those counts is equiprobable independently of `p`. Reorder the systems by block and discard that word. The quantum state conditional on `K` is exactly

\[
 \bigotimes_b\sigma_b^{\otimes K_b}.
 \tag{2.6}
\]

The inverse channel draws a uniform word with the supplied counts and embeds the block outputs into its tensor positions. Thus the experiment is *exactly equivalent* to the classical counts plus the conditional product in (2.6). It does not resample counts from the unknown `p`. The full block word is also not a free retained register: it is discarded and regenerated using its known uniform conditional law.

### 2.2 Forward statistic and exact reverse count recovery

For each `K_b>0`, apply the inherited inner channel `T_{K_b,m_b}` to obtain `Y_b` in the trace-zero Hermitian block. For `m_b=1`, that space is zero dimensional. If `K_b=0`, set `Y_b=0`; the exceptional counts will be exponentially unlikely.

Draw independent `U_1,...,U_{B-1}~Uniform(-1/2,1/2)` and set `U_B=-sum_{b<B}U_b`. When `B=1`, `U=0`. Output the block-diagonal trace-zero matrix

\[
 \Gamma_b=\sqrt{K_b/n}\,Y_b
             +\frac{K_b+U_b-nw_b}{\sqrt n}\frac{I_{m_b}}{m_b},
 \qquad\Gamma=\bigoplus_b\Gamma_b.
 \tag{2.7}
\]

`sum_b Tr Gamma_b=0`, so no trace coordinate is spuriously added.

The reverse channel obtains `z_b=Tr Gamma_b`, rounds the first `B-1` numbers `nw_b+sqrt(n)z_b` to the nearest integer, and sets the last count to `n` minus their sum. Invalid counts produce a fixed state. For positive counts it forms

\[
 Y_b=\sqrt{n/K_b}\left(\Gamma_b-z_bI_{m_b}/m_b\right),
 \tag{2.8}
\]

applies `S_{K_b,m_b}`, and regenerates the uniform word. On all encoder outputs outside null boundaries it recovers every count and every inner observation exactly. It therefore obeys the exact conditional identity

\[
 S_n^AT_n^A(\rho^{\otimes n})
 =\sum_K \Pr_p(K)\,\mathsf{Embed}_K
       \left(\bigotimes_b C_{K_b,m_b}(\sigma_b^{\otimes K_b})\right).
 \tag{2.9}
\]

The inner coherent minorants yield an additional useful finite identity. If `s_{b,1}>=...>=s_{b,m_b}>0` are the unknown eigenvalues of `sigma_b`, then the right side in (2.9) dominates

\[
 c_A(\rho)\rho^{\otimes n},\qquad
 c_A(\rho)=\prod_b\prod_{i<j}\frac{s_{b,j}}{s_{b,i}}.
 \tag{2.10}
\]

The empty inner experiment uses the identity channel and also dominates with any coefficient at most one. Applying product minorants and summing counts proves (2.10), independently of the Gaussian comparison. Since `1-c_A(rho)<=C_{rho0}delta`,

\[
 T(S_n^AT_n^A(\rho^{\otimes n}),\rho^{\otimes n})
       \le C_{\rho_0}\delta.
 \tag{2.11}
\]

This is a direct specialization/composition of inherited coherent domination, not an independently new group-coherent theorem. Crucially the coefficient contains only *within-block* ratios, and no fixed interblock ratio `a_c/a_b`.

### 2.3 Forward error and the fluctuating-count calculation

The event `K_b>=c_{rho0}n` for every block fails with probability at most `C exp(-c n)`, uniformly in the family. Replace the inner observations conditional on `K` by independent Gaussians

\[
 Y_b^{\rm g}\mid K\sim
     N(\sqrt{K_b}A_b,I_{\rm HS,b}/m_b).
\]

The total replacement error, averaged over the counts, is
`C(delta+n^(-1/2))+C exp(-c n)`. This follows by summing the inherited block errors on the central event; low counts cost at most their probability.

Set `Z_b=sqrt(K_b/n)Y_b^g`. Its conditional law is

\[
 Z_b\mid K\sim
    N\left(\frac{K_b}{\sqrt n}A_b,
                       \frac{K_b}{nm_b}I_{\rm HS,b}\right).
 \tag{2.12}
\]

Compare it to an independent, count-free law

\[
 \widetilde Z_b\sim
     N\left(\sqrt n p_b A_b,\frac{w_b}{m_b}I_{\rm HS,b}\right).
 \tag{2.13}
\]

On the central count event all covariance eigenvalues lie in a fixed positive compact interval. Gaussian KL and Pinsker, followed by the elementary finite-dimensional covariance bound, give

\[
 \operatorname{TV}((2.12),(2.13))
 \le C_{\rho_0}\left[
    \frac{|K_b-np_b|}{\sqrt n}\|A_b\|_{\rm HS}
       +\left|\frac{K_b}{n}-w_b\right|\right].
 \tag{2.14}
\]

For example use `KL(N(mu,C)||N(nu,C0))=1/2[Tr C0^{-1}C-r-logdet(C0^{-1}C)+(mu-nu)^*C0^{-1}(mu-nu)]`; on that compact interval its covariance term is at most a constant times `||C-C0||^2`. No estimate of an accumulating displacement `sqrt(n)delta^2` is made here.

Since `E|K_b-np_b|<=sqrt(n p_b(1-p_b))`, (2.5) makes the expected right side in (2.14) `O(delta+n^(-1/2))`. This is the essential new calculation: the covariance and mean dependence on the count can be removed despite `sqrt(n)delta` being arbitrarily large. The random mean difference is a *count fluctuation times an intrablock deviation*, not the full uncentered displacement. The count jitter is independent and untouched by this replacement.

The established multinomial jitter theorem, Ouimet 2021 Lemma 3.1 and Theorem 3.2, gives

\[
 \operatorname{TV}\left(\frac{K+U-nw}{\sqrt n},
     N_{\sum z_b=0}(\sqrt n(p-w),\Sigma_p)\right)
       \le C_{\rho_0}n^{-1/2},\qquad
 \Sigma_p=\operatorname{diag}(p)-pp^*.
 \tag{2.15}
\]

It is applied to the first `B-1` coordinates and then to their sum-zero embedding. Its constants are uniform because all `p_b` remain in a fixed positive compact simplex. Replacing `Sigma_p` by `Sigma_w` adds `O(delta)` by the same Gaussian covariance argument. For `B=1` this part is absent.

The Gaussian count statistic and the independent Gaussians (2.13) now have the target mean in (2.3). To verify its covariance, write an arbitrary `H in A_0` as `H_b=h_b I_{m_b}+H_b^0`, `Tr H_b^0=0`. Counts contribute
`sum_b w_b h_b k_b-(sum_b w_b h_b)(sum_b w_b k_b)`
to the covariance of `Tr H Gamma` and `Tr L Gamma`. The inner Gaussians contribute
`sum_b (w_b/m_b)Tr H_b^0 L_b^0`.
Their sum is precisely (2.1). This proves the forward bound.

Contractivity and (2.11) prove the reverse bound:
`T(S_n^A G_{n,rho},rho^n) <= TV(G_{n,rho},T_n^A rho^n)+C delta`.
No reverse theorem for the joint count/block model is quietly assumed.

## 3. Entire finite memory and exact regime consequences

All continuous observations above are transient. In a fixed orthonormal basis of `A_0`, whiten by `V_0^{-1/2}` and apply the inherited positive tent quantizer to the resulting `s` independent unit-variance Gaussian coordinates. Equations (2.2) and `||rho-rho0||HS<=sqrt(d)delta` bound every mean by `C_{rho0}sqrt(n)delta`.

For `0<epsilon<1/4` there is thus a wholly classical code, with all retained input-dependent registers charged, satisfying

\[
 D\le1+\left[C_{\rho_0}\epsilon^{-1/2}
       \left(1+\sqrt n\delta+\sqrt{\log(4s/\epsilon)}\right)\right]^s,
 \qquad e\le C_{\rho_0}(\delta+n^{-1/2})+\epsilon.
 \tag{3.1}
\]

The decoder's triangular noises, count resampling, flag resampling and word randomness are fresh fixed randomization, not retained registers. Equivalently every finite code symbol maps to one fixed output density matrix. Channels for this finite code know the declared envelope, accuracy and center, and do not know the input spectrum or basis.

There is a matching **constant-error leading-dimension** converse:

\[
 e\le1/8\quad\Longrightarrow\quad
 D\ge c_{\rho_0}(1+n\delta^2)^{s/2}.
 \tag{3.2}
\]

Proof: an `s`-dimensional HS ball of radius `c delta` in `A_0` gives faithful states `rho0+H` inside the model. Pack it at spacing `L/sqrt(n)`. The number of points is at least `c(1+n delta^2)^(s/2)` for fixed sufficiently large `L`. A fixed informationally complete product measurement estimates a `d`-dimensional state with HS squared risk at most `C_d/n`; nearest-point decoding succeeds with probability at least `7/8`. Reconstruction error `<=1/8` retains success at least `3/4`. For the `N` equiprobable memory states and pulled-back effects, `N^{-1}sum_i Tr(F_i omega_i)<=D/N`, proving (3.2) against arbitrary quantum/hybrid memory. An input-independent shared random codebook can be allowed: the same `D/N` bound holds conditioned on that seed and hence after averaging.

For `delta_n->0`, `kappa_n=n delta_n^2->infinity`, choose `epsilon_n=1/log(2+kappa_n)` once it is below `1/4`. Then

\[
 \log_2D_n=\frac{s}{2}\log_2\kappa_n+o(\log\kappa_n)
 \tag{3.3}
\]

is the optimal leading cost, achievable with zero retained qubits. This result assumes supplied projectors. The unrestricted full-state dimension `d^2-1` must not be replaced by `s` when the spectral subspaces are unknown.

Zero memory gives vanishing error iff `kappa_n->0` for this full block-algebra envelope. Sufficiency follows from smooth faithful-state fidelity and preparing `rho0^n`; necessity uses two commuting opposite diagonal local alternatives whenever `sqrt(n)delta` stays positive. For `kappa_n` bounded away from zero and infinity, every diverging classical capacity suffices, while no bounded quantum/hybrid dimension gives vanishing error. Section 3A supplies a stronger quantitative converse that also permits a free input-independent common classical seed; it avoids the inherited finite-rank argument's seed qualification.

The joint growing-signal/precision dependence in (3.1) is not proved optimal. The sharp critical precision exponent is proved next. The separate growing-signal leading law (3.3) must not be promoted to a matching simultaneous precision theorem.

## 3A. New sharp Gaussian memory law, including finite parameter sets

This is the strongest new completed derivation in this branch. The posterior-risk lower argument was constructed here; root proposed the broad-reference compactification in the upper argument, which is fully reconstructed below. Independent adversarial reconstruction has passed the finite-prior lower, seed averaging, derivative constant, periodic first moment, and every-dimension handling. The primary prior-art comparison remains in progress. The theorem uses no unverified release assertion or quantum LAN theorem.

### Statement and full interface

Let `Theta` be a nonempty bounded subset of a finite-dimensional Euclidean space. Let `s>=1` be its **affine-span dimension**, and let
`P_theta=N(theta,I)` be the classical Gaussian location experiment. Orthogonally projecting onto the known affine span discards only independent, known Gaussian noise, which the decoder can regenerate. We consequently write the proof in `R^s`, where `Theta` affinely spans the full space.

The encoder is an arbitrary measurable classical-to-quantum channel, mapping the supplied observation `X` to a density matrix in a memory algebra `direct_sum_j M_{d_j}`. The decoder is an arbitrary quantum-to-classical channel, hence a POVM, producing an observation `Y`. All input-dependent retained information passes through this memory. Its total dimension is

\[
 D=\sum_j d_j.
\]

Classical memory is the case `d_j=1`; an ordinary quantum memory is one branch. An arbitrary **input-independent shared classical random seed** may be supplied for free to both stages. Conditioned on it, the memory dimension is at most `D`. No pre-shared entanglement, feedback, additional quantum channel or input-dependent side register is allowed. Fresh fixed decoder randomness is allowed. Loss is

\[
 e=\sup_{\theta\in\Theta}\operatorname{TV}(\mathcal D\mathcal E(P_\theta),P_\theta).
\]

There are constants `0<c_Theta<=C_Theta<infinity` such that for every `D>=1`,

\[
 c_\Theta D^{-2/s}\ \le\
 \inf_{\mathcal E,\mathcal D}e
 \ \le\ C_\Theta D^{-2/s}.
 \tag{3A.1}
\]

The upper is achieved with a wholly classical finite memory. The lower permits arbitrary quantum/hybrid memory and the shared seed. The constants depend on the bounded parameter set, its actual affine geometry, and the Gaussian covariance after whitening. They are not uniform when the informative mean set collapses in an affine direction.

**Finite-set point.** No continuum, interior or smoothness hypothesis on `Theta` is needed. Any `s+1` affinely independent means suffice for the lower bound. A finite hypothesis set can still require unbounded memory for asymptotically exact experiment preservation because its posterior is continuously varying. Finite hypothesis count alone does not make its supplied Gaussian observation finitely sufficient.

### Lower bound: posterior risk forces preservation of an s-dimensional statistic

Choose affinely independent `theta_0,...,theta_s` in `Theta`, with positive prior probabilities `pi_i`. Set `theta=theta_i` with those probabilities and draw `X|theta~N(theta,I)`. Write `p(x)` for its marginal density. Its posterior mean is

\[
 m(x)=\frac{\sum_i\pi_i\theta_i
                e^{\theta_i\cdot x-\|\theta_i\|^2/2}}
              {\sum_i\pi_i
                e^{\theta_i\cdot x-\|\theta_i\|^2/2}}
       =\nabla\log\sum_i\pi_i
                   e^{\theta_i\cdot x-\|\theta_i\|^2/2}.
 \tag{3A.2}
\]

Differentiation gives `Dm(x)=Cov(theta|X=x)`. Every posterior weight is strictly positive. Affine independence therefore makes this covariance positive definite at every finite `x`: if `v` had zero conditional variance then `v dot theta_i` would be equal for all `i`, contradicting affine spanning. Fix a cube `C=[-L,L]^s`, `L>0`. Compactness yields

\[
 Dm(x)\ge v I\quad(x\in C),\qquad
 v>0,\qquad M=\Pr\{X\in C\}>0,
 \qquad p(x)\le p_{\max}\le(2\pi)^{-s/2}.
 \tag{3A.3}
\]

The map `m` is globally injective: integrate its positive-definite Hessian along the line between two points to get strict monotonicity. On `C`, its Jacobian determinant is at least `v^s`. By ordinary change of variables, for every `z` and radius `h>0`,

\[
 \operatorname{Vol}\{x\in C:\|m(x)-z\|_2\le h\}
      \le v^{-s}\operatorname{Vol}(B_s)h^s.
 \tag{3A.4}
\]

The smooth inverse exists locally and injectivity makes the change of variables legitimate; boundary sets have measure zero. One can alternatively bound the preimage diameter using strong monotonicity on the convex cube, with a weaker dimension constant.

Let `R` be the free seed. Conditional on it, the encoded density at observation `x` is `omega_{R,x}` and the decoder POVM is `F_R(dy)`. Every memory density satisfies `omega_{R,x}<=I`, and `sum_j Tr_j F_R(R^s)=D_R<=D`. Thus, conditional on `R`,

\[
\begin{split}
 &\Pr\{X\in C,\ \|m(Y)-m(X)\|_2\le h\mid R\}\\
 &=\int_Cp(x)\operatorname{Tr}\!\left[
       F_R\{y:\|m(y)-m(x)\|_2\le h\}\,\omega_{R,x}\right]dx\\
 &\le p_{\max}\operatorname{Tr}\int F_R(dy)
      \operatorname{Vol}\{x\in C:\|m(x)-m(y)\|_2\le h\}\\
 &\le C_*D h^s,\qquad
 C_*=p_{\max}\operatorname{Vol}(B_s)/v^s.
 \tag{3A.5}
\end{split}
\]

The seed is independent of `theta,X`, so their marginal `p` and central mass `M` are unchanged. Averaging (3A.5) over **any** seed distribution leaves the same bound. It does not average rank-bounded matrices or assume a finite seed alphabet.

Take `h=(M/(2C_*D))^(1/s)`. At least `M/2` of the probability lies in the central cube with posterior-mean displacement exceeding `h`. Consequently

\[
 E\|m(Y)-m(X)\|_2^2
      \ge\frac M2\left(\frac{M}{2C_*D}\right)^{2/s}.
 \tag{3A.6}
\]

Choose `B>0` with `||theta_i||_2<=B`. Every posterior mean lies in their convex hull and also has norm at most `B`. The loss
`ell(theta,y)=||theta-m(y)||_2^2/(4B^2)` lies in `[0,1]`. The assumed TV reconstruction error at those finite source parameters implies

\[
 E\|\theta-m(Y)\|_2^2
   -E\|\theta-m(X)\|_2^2\le4B^2e.
 \tag{3A.7}
\]

Because `theta -> X -> (R,omega) -> Y` is a Markov chain and the seed is independent, conditioning on `X,R,Y` has posterior mean `m(X)`. Expanding the square therefore makes the difference in (3A.7) **exactly** `E||m(Y)-m(X)||_2^2`. Combining (3A.6)--(3A.7) proves the explicit lower constant

\[
 e\ge\frac{M}{8B^2}
       \left(\frac{M}{2C_*}\right)^{2/s}D^{-2/s}.
 \tag{3A.8}
\]

This is a Bayesian decision identity and a dimension-trace cap bound; it does not use the number of encoded free parameters as a quantum dimension count.

### Upper bound without a tail logarithm: a broad reference and periodic hats

After a fixed coordinate translation, bound `Theta` by `[-A,A]^s`. In one coordinate let `f_theta=N(theta,1)` and take a **known broad reference** density

\[
 g(x)=\frac1{2\sqrt{2\pi}}e^{-x^2/8},\qquad
 u=G(x)=\Phi(x/2)\in(0,1),\qquad
 q_\theta(G(x))=f_\theta(x)/g(x).
 \tag{3A.9}
\]

`q_theta` is a probability density on `(0,1)`. Put `a=g'/g=-x/4`. Differentiating with `d/du=g^{-1}d/dx` gives

\[
 q_\theta'=\frac{f_\theta'-a f_\theta}{g^2},\qquad
 q_\theta''=\frac{f_\theta''-3a f_\theta'
                       +(2a^2-a')f_\theta}{g^3}
     =\left(\frac38x^2-\frac54\theta x+
                         \theta^2-\frac34\right)\frac{f_\theta}{g^3}.
 \tag{3A.10}
\]

Both `q_theta` and `q_theta'` tend to zero at the two endpoints, uniformly for bounded means. Moreover

\[
 \|q_\theta''\|_{L^1(0,1)}
 =\int_{\mathbb R}\left|\frac38x^2-\frac54\theta x+
                \theta^2-\frac34\right|\frac{f_\theta(x)}{g(x)^2}\,dx
 \le M_A<\infty\quad(|\theta|\le A).
 \tag{3A.11}
\]

To verify uniform integrability explicitly,
`f_theta/g^2=4sqrt(2pi) exp[-(x-2theta)^2/4+theta^2/2]`.
Writing `z=x-2theta` reduces the polynomial to
`3z^2/8+theta*z/4-3/4`. Therefore one admissible bound is

\[
 M_A=8\sqrt2\pi e^{A^2/2}
                \left(\frac32+\frac{A}{2\sqrt\pi}\right).
 \tag{3A.12}
\]

Endpoint matching and (3A.11) make the periodic extension an element of `W^{2,1}(R/Z)`. A narrow reference equal to the target variance would not supply this integrability; the variance-four choice is load-bearing.

Let `J>=5`, `h=1/J`, and index circle vertices by `k=0,...,J-1`. Set

\[
 a_k(u)=\left(1-\frac{\operatorname{dist}_{\mathbb R/\mathbb Z}(u,kh)}h\right)_+.
\]

The hats are nonnegative, `sum_k a_k=1`, and `int a_k=h`. Encode the finite vertex `k` with probability `a_k(u)`. Given `k`, decode `v` with density `a_k(v)/h`. The resulting symmetric Markov kernel is

\[
 K_h(u,v)=h^{-1}\sum_ka_k(u)a_k(v),\qquad
 R_hq(v)=\int_0^1K_h(u,v)q(u)du.
 \tag{3A.13}
\]

It is bounded by `1/h` and supported at circle distance at most `2h`. On the unique local unwrapping of that support, it has zero first moment about `v`: each decoded hat has mean its lifted vertex, and the two encoding weights interpolate that vertex mean exactly to `v`. The bound `J>=5` ensures `2h<1/2`, so no ambiguous antipodal unwrapping is used.

Apply Taylor's formula with integral remainder to the periodic extension. Constants and that local first moment cancel. Translation invariance on the circle gives

\[
 \|R_hq-q\|_1
  \le h^{-1}\int_{-2h}^{2h}t^2dt
              \int_0^1(1-r)dr\,\|q''\|_1
  =\frac83h^2\|q''\|_1.
 \tag{3A.14}
\]

The `s` transformed coordinates are independent. Tensoring these positive kernels and telescoping with L1 contractivity yields uniformly over `Theta`

\[
 \operatorname{TV}(R_h^{\otimes s}q_\theta,q_\theta)
       \le\frac43sM_A J^{-2}.
 \tag{3A.15}
\]

The stored alphabet has exactly `J^s` labels. The decoder draws the periodic triangular noises and returns `x_j=G^{-1}(v_j)=2Phi^{-1}(v_j)`; null endpoints may be assigned any fixed value. The unbounded real outputs are fresh decoder samples. They are not stored or supplied as an additional observation of the unknown parameter. The invertible fixed map preserves TV, proving the classical upper in (3A.1). For general `D`, choose `J=floor(D^(1/s))` once `D>=5^s`; larger constants handle the finite smaller cases.

### Sharp conditional critical iid precision law

Suppose `delta_n->0`, with `n delta_n^2` bounded above and bounded away from zero in the full block-algebra family. The whitened Gaussian mean set is bounded and contains an `s`-dimensional cube. The upper can now replace (3.1)'s tail-cutoff quantizer by (3A.9)--(3A.15), giving

\[
 D\le C\epsilon^{-s/2},\qquad
 e\le C(\delta_n+n^{-1/2})+\epsilon.
 \tag{3A.16}
\]

Conversely, compose any quantum iid archive with `S_n^A` before encoding and `T_n^A` after decoding. It is a Gaussian memory code through the same `D`, with error at most `e+C(delta_n+n^(-1/2))`; free common seeds remain independent. Therefore

\[
 e+C(\delta_n+n^{-1/2})\ge c D^{-2/s}.
 \tag{3A.17}
\]

Since the critical envelope has `delta_n=Theta(n^(-1/2))`, for any prescribed `epsilon_n->0` with `epsilon_n sqrt(n)->infinity`, the least total memory dimension satisfies

\[
 D_n^{\rm opt}(\epsilon_n)=\Theta(\epsilon_n^{-s/2}),\qquad
 \log_2D_n^{\rm opt}(\epsilon_n)
    =\frac s2\log_2(1/\epsilon_n)+O(1),
 \tag{3A.18}
\]

and a wholly classical memory attains this order. This closes the **critical** precision exponent, not the simultaneous growing-signal/precision law and not the below-bridge precision problem.

### Critical known-spectrum orbits: affine dimension can exceed orbit dimension

For the inherited tracial family, let known ordered spectra satisfy
`sqrt(n)(diag(p_n)-I/d)->A!=0` in the traceless Hermitian space, with `A` fixed. The limiting Gaussian mean set is the compact orbit `Theta_A={UAU*:U unitary}`; whitening multiplies it by `sqrt(d)` and changes no dimension.

Its affine span is the **entire** `d^2-1` dimensional traceless Hermitian space, even if `A` has repeated eigenvalues. Here is an elementary verification. In an eigenbasis choose two unequal eigenvalues. Subtracting the conjugate which swaps them gives a nonzero multiple of `E_ii-E_jj` in the span of orbit differences. That difference span is invariant under all unitary conjugations. Permutations therefore give every traceless diagonal difference; two-dimensional Hadamard and phase rotations give every real and imaginary offdiagonal matrix unit. These form a basis of all traceless Hermitians. A finite collection of orbit points thus contains `d^2` affinely independent means. Fixed chosen unitaries also give affinely independent means for all sufficiently large `n`, with lower constants uniform by continuity of the finite posterior data.

Applying (3A.1) and the inherited Gaussian comparison yields, when `epsilon_n sqrt(n)->infinity`,

\[
 D_n^{\rm opt}(\epsilon_n)=\Theta(\epsilon_n^{-(d^2-1)/2})
 \tag{3A.19}
\]

for this critical known-spectrum orbit. Its **precision** exponent is ambient affine dimension, rather than the orbit manifold dimension `d^2-sum_b m_b^2` appearing in the growing-signal leading law. These are distinct asymptotic questions. In particular critical qubit orbits have `D=Theta(epsilon^(-3/2))`, whereas the separately inherited critical ordered-spin direction experiment has `D=Theta(epsilon^(-1))`. The Gaussian orbit observes a full-dimensional noisy vector; its radius affects the posterior confidence even though the true mean has a fixed norm. The ordered-spin limiting observation lives on a two-dimensional sphere. No radial statistic is being counted as a free retained register in this comparison.

The proof also applies to any bounded Gaussian mean set with full affine span, including a finite set of `s+1` means. No novelty claim is made pending the separately assigned comparison with statistical-experiment discretization and quantization literature.

## 4. A nontracial tube beyond exactly block-diagonal states

Let `P_A(rho)=sum_b P_b rho P_b` be block pinching. Suppose

\[
 \|\rho-\rho_0\|_{\rm op}\le\delta,\qquad
 \|\rho-P_A(\rho)\|_{\rm HS}\le\eta,
 \qquad\delta\le\delta_0.
\]

Both states have least eigenvalue at least `c=a_min/2`. Put `X=sqrt(rho)-sqrt(P_A rho)`. The Sylvester identity
`sqrt(rho)X+Xsqrt(P_A rho)=rho-P_A rho`
implies `||X||HS<=eta/(2sqrt(c))`. Root fidelity therefore obeys

\[
 F(\rho,P_A\rho)\ge\operatorname{Tr}\sqrt\rho\sqrt{P_A\rho}
        =1-\tfrac12\|X\|_{\rm HS}^2
        \ge1-\frac{\eta^2}{8c}.
\]

Using fidelity multiplicativity and the elementary upper trace/fidelity bound gives

\[
 T(\rho^{\otimes n},(P_A\rho)^{\otimes n})
      \le\frac{\sqrt n\eta}{2\sqrt c}.
 \tag{4.1}
\]

Apply the block channels after the physical block measurement. Their output law is exactly that for the pinched input. Comparison to the Gaussian mean `sqrt(n)(P_A rho-rho0)` has the preceding forward bound, and reverse reconstruction of the *original* state adds (4.1). The finite code has

\[
 e\le C_{\rho_0}(\delta+n^{-1/2}+\sqrt n\eta)+\epsilon,
 \tag{4.2}
\]

and the same finite alphabet (3.1). Thus arbitrary intrablock shrinking envelopes coexist with negligible transverse coherences when `sqrt(n)eta_n->0`.

This is the exact scope of the tube theorem. The `n^(-1/2)` transverse condition cannot be erased from *this pinching construction*. For two unequal eigenvalues `a_i,a_j`, perturb by
`rho_n=rho0+(c/sqrt(n))(E_ij+E_ji)`.
Measuring `X_ij=(E_ij+E_ji)/sqrt(2)` independently gives a sum divided by `sqrt(n)` with limiting mean `sqrt(2)c` and variance `(a_i+a_j)/2`; the pinched state has zero mean and the same limiting variance. A fixed midpoint halfspace test yields a positive limiting discrepancy. This elementary witness does not by itself exclude every other classical reconstruction channel.

## 5. The larger hybrid theorem and the exact missing lemma

The consequential next target is the **full affine experiment at a fixed faithful center with repeated spectral blocks**, with no supplied unknown eigenspaces and with resolved transverse rotations retained. Its local Gaussian geometry is explicit.

For centered Hermitian observables define

\[
 V_0(H,L)=\operatorname{Re}\operatorname{Tr}\rho_0 HL
       -\operatorname{Tr}\rho_0H\operatorname{Tr}\rho_0L,
 \qquad\Omega_0(H,L)=-i\operatorname{Tr}\rho_0[H,L].
 \tag{5.1}
\]

The commutant part is exactly `A_0` and has zero `Omega_0`. For each `i` in block `b` and `j` in block `c`, `a_b>a_c`, put

\[
 X_{ij}=\frac{E_{ij}+E_{ji}}{\sqrt2},\qquad
 Y_{ij}=\frac{-iE_{ij}+iE_{ji}}{\sqrt2}.
\]

Then `Omega_0(Xij,Yij)=a_b-a_c` and each variance is `(a_b+a_c)/2`. On the corresponding canonical pair `Q=Xij/sqrt(a_b-a_c)`, `P=Yij/sqrt(a_b-a_c)`, the covariance is

\[
 \frac{a_b+a_c}{2(a_b-a_c)}
 =\frac12+\frac{a_c}{a_b-a_c}.
 \tag{5.2}
\]

Thus the target has `s=sum_b m_b^2-1` classical coordinates and `M=sum_{b<c}m_bm_c` thermal quantum modes, with thermal parameter `t_bc=a_c/a_b`, occupancy `t_bc/(1-t_bc)`, and displacement means obtained from the offblock perturbation's expectations of `Q,P`. The parameter count checks: `s+2M=d^2-1`. Formula (5.1) is established QLAN geometry; identifying it is not a new theorem.

**First unresolved target:** For every fixed compact set of `h in H_0`, construct a *single* pair of strong channels comparing `(rho0+h/sqrt(n))^n` to the hybrid Gaussian shift determined by (5.1), uniformly in `h`, including arbitrary unknown perturbations inside the equal-eigenvalue blocks. No singular inverse within-block spectral gap is permitted. The proof above supplies the classical commutant restriction, but cannot simply be applied after measuring the block words for this full model: doing so erases the resolved transverse modes.

**Second target:** Globalize to every shrinking full-state neighborhood `||rho-rho0||op<=delta_n->0`, with a fully specified fixed or recentered hybrid target and no hidden radius/gap dependence. These two targets should remain separate until the first is proved.

The strongest prior directly checked is Yamaguchi--Tajima September 2026, Theorem I.5: strong *unitary-orbit* QLAN for arbitrary rank and degeneracy, with `||Z||<=n^beta`, `beta<1/12`, and constants allowed to depend on the fixed reference state. Its reverse map regenerates a fixed ground component; it does not include independent perturbations in that component. Kahn--Guta 2009 Theorem 4.3 instead assumes separated reference eigenvalues. Neither theorem can be multiplied by the block channels without a compatibility argument.

The load-bearing extension lemma can be stated more narrowly than the whole desired theorem:

> **Ground-component/Fock factorization lemma (unproved here).** In each typical global Schur sector, retain the ground representation of `K=prod_b U(m_b)` rather than replacing it by its fixed tracial state. Construct one isometry to that ground component tensor the crossblock Fock modes. Show a uniform trace-norm factorization and inverse approximation for all faithful `R=bigoplus_b R_b` with `||R-rho0||op<=delta`, and for bounded residual transverse displacements, with error tending to zero as `delta->0` and `n->infinity`. Classicalizing the retained ground component must preserve the crossblock factor and all correlations up to the same error. The map may depend on the known block decomposition but not on the unknown splitting eigenvalues within it.

Why this is plausible, and what was actually attacked: normalizing crossblock matrix units by `sqrt(n(a_b-a_c))` makes the leading commutator scalar. On ground sectors with within-block highest-weight spread `O(n delta+sqrt(n))`, the undesired within-block generator in a cross commutator is of normalized size `O(delta+n^(-1/2))`, whereas all interblock denominators stay fixed and positive. This suggests fixed-excitation Fock Gram estimates can be uniform over collapsing *within-block* gaps. It does not establish a trace-norm isometry or a thermal-tail estimate, particularly after retaining an unknown ground density. Those are the exact unfinished steps.

For arbitrary shrinking radii, a preliminary localization budget could be chosen slowly enough that the residual excitation cutoff tends to infinity while its polynomial factors times `delta+n^(-1/2)` vanish, and the consumed fraction of copies tends to zero. That schedule is feasible once the factorization lemma supplies its actual powers. The forward/reverse Gaussian localization, conditional correlations, amplification after sample loss, and recentering must still be proved. A fixed-center Taylor chart can accumulate `sqrt(n)delta^2` terms; this is an obstruction to a naive proof, not a demonstrated impossibility of a properly recentered experiment theorem.

Known displaced-thermal measure/prepare benchmarks give a positive classical reconstruction floor for resolved nontracial quantum modes on expanding local domains. A fully classical unrestricted extension should therefore not be expected. This does not determine the necessary quantum memory dimension. The exact split of finite classical and quantum storage for this hybrid collision experiment remains an open precision problem.

## 6. Release/source checks and the nontransfer boundary

The release is pinned in the existing source inventory to `adc7f1241b42e322a6451854ab7e4b4c146bf78a`. Three relevant family statements were inspected directly; no release theorem is used in (2.3)--(4.2).

| Family and directly read scope | What it supplies at the stated interface | What it does not supply here |
|---|---|---|
| 271, spherical magnetization: full introduction and principal theorem | Claimed fixed-spin, fixed-temperature, even periodic 3D nearest-neighbor limit of total-spin transforms; supports the separately inherited correlated-spin application if its proof is valid | A product iid source, a block-Gaussian equivalence, or certification of its long spatial/pressure proof |
| 273, entropy photon-number inequality: full principal statement, attenuator corollary and context | Claimed entropy inequality for independent bosonic input ports, with internal multimode entanglement allowed; claimed entropy minimum for identical thermal attenuators | Trace-distance reconstruction, environment/reference correlations, or a ground-component/Fock channel theorem |
| 276, generalized amplitude damping: triangular-block entropy theorem and its finite formulation | Entropy lower bounds for arbitrary rectangular noncommuting blocks; relevant to noisy-memory capacity after its separate source proof is validated | A retained quantum-capacity formula or a reference-preserving classical archive |

These statements are source assertions with hypotheses checked, not external proof verification. The cycle19 quantum bridge notes concern sparse enforcement, table-oracle acquisition and commuting repetition. They preserve the distinction between existence of a state/vector and acquiring or retaining its useful quantum information. None repairs the missing factorization lemma.

The inherited collision proof's established analytic input was checked against Graczyk--Sawyer Theorem 3.1: the root-product estimate is uniform on the *closed* Weyl chamber, including repeated entries. Scalar shifts reduce the unitary orbital integral to that theorem. The elementary cancellation in the inherited report was also rechecked: `m_lambda=n!Delta(l)/prod l_i!`, `s_lambda(p)=det[p_i^l_j]/Delta(p)`, and `I_l(log p)=c_H det[p_i^l_j]/(Delta(log p)Delta(l))` give the stated `Z_disc` with one squared Vandermonde. Repeated `p` use continuous logarithmic means. This is a targeted load-bearing check; it does not independently certify all continuous log-Gamma and angular steps.

## 7. Finite evidence and limits

`work/quantum_collision_checks/check_block_moments.py` was run successfully. It uses the exact qubit Schur/coherent/jitter moments conditional on an exact binomial count law for a d=3 `(2,1)` block example. The center is `diag(.35,.35,.30)` and the schedule is `p_1=.7+.08n^(-1/4)`, inner polarization `.4n^(-1/4)`. Checks at `n=16,64,256,1024,4096` show the displayed mean, variance and count/inner-covariance deviations decreasing, with largest displayed deviation from `0.05230` to `0.01872`. Their ratio to `delta+n^(-1/2)` stays below `0.49` on this finite list. Negligible omitted count mass is recorded, rather than silently renormalized away from the quantum moment averages.

The covariance at the center was independently computed in HS coordinates as `diag(.35,.35,.35,.315)`; the interblock symplectic coefficient is `.05` and the intrablock coefficient is zero. One thousand cube-jitter count-rounding fixtures recover the exact counts. These are convention/implementation diagnostics only. The script does not build a complete quantum circuit, verify TV convergence, test adversarial states, or validate the inherited bridge. The saved JSON is `work/quantum_collision_checks/block_moment_diagnostics.json`.

`work/quantum_collision_checks/check_gaussian_periodic.py` was also run successfully. Twenty-four fixtures, including both sides of the periodic boundary and `J=5`, verify row mass one and local first moment zero to numerical tolerance `1e-12`. Midpoint quadrature for means `0,.5,1,2` and `J=8,16,32,64,128` checks the transformed Gaussian normalization and reconstruction error. At mean zero the estimated `J^2 TV` grows from `2.079` to `2.150`; at mean two it grows from `7.842` to `18.895`. These finite estimates remain below the analytic bound and are not an asymptotic-rate proof. Real-line quadrature also checks that the `q''` norm is below (3A.12) at those means. The saved JSON is `work/quantum_collision_checks/gaussian_periodic_diagnostics.json`; only the analytic arguments in Section 3A establish the theorem.

## 8. Primary references and reading scope

* [Ouimet, A precise local limit theorem for the multinomial distribution and some applications](https://arxiv.org/html/2001.08512v4), Lemma 3.1 and Theorem 3.2. Their stated cube-jitter total-variation bound and parameter-free reverse rounding kernel were read. This is the established nonquantum input in the new block comparison.
* [Graczyk--Sawyer, Sharp Estimates of Radial Dunkl and Heat Kernels in the Complex Case A_n](https://arxiv.org/html/2012.12022v1), Theorem 3.1; [published version](https://www.numdam.org/articles/10.5802/crmath.188/). Closed-chamber uniformity was checked; no proof of a new all-root-system estimate is claimed.
* [Kahn--Guta, Local asymptotic normality for finite dimensional quantum systems](https://arxiv.org/html/0804.3876), Sections 4.1--4.4 and Theorem 4.3 statement. This supplies strong separated-spectrum Gaussian comparison and its thermal mode normalization, not the unrestricted unknown splitting within degenerate blocks.
* [Yamaguchi--Tajima, Quantifying Symmetry Breaking with Metric Adjusted Quantum Geometric Tensors](https://arxiv.org/pdf/2609.11926), Theorem I.5 on PDF page 58 and the fixed-model constant qualification on PDF page 64. Scope checked at the main theorem, not the entire 116-page proof.
* [Guta--Bowles--Adesso, Quantum teleportation benchmarks for iid spin states and displaced thermal states](https://arxiv.org/html/1004.1843v2), Gaussian benchmark and local-transfer converse sections. Its positive thermal measure/prepare floor is established prior art.
* [Yang--Bai--Chiribella--Hayashi, Compression for quantum population coding](https://arxiv.org/html/1701.03372v3), hybrid-memory and necessity-of-quantum-memory sections. Leading parametric hybrid compression and a nonzero quantum requirement at fixed noncommuting centers are prior art; they do not directly cover this moving block-collision full-state envelope.

The strongest completed derivation is Section 3A's sharp bounded Gaussian uniform-TV memory law, including finite affine-spanning mean sets, a quantum/shared-seed lower, and a classical upper without a tail logarithm. Its critical iid and known-spectrum orbit consequences remain conditional on the inherited Gaussian bridge. Sections 2--4 separately supply the explicit arbitrary-shrinkage extension on a known nontracial block algebra and its fluctuating-count proof. That extension is a conditional corollary of the existing tracial bridge plus established classical comparison, rather than a universal hybrid theorem. The larger unresolved opportunity is the named ground-component/Fock factorization lemma in Section 5.

Memory use: `MEMORY.md:44--97` and `rollout_summaries/2026-10-06T16-44-34-0JR9-uniform_gaussian_equivalence_spectral_collisions.md:1--89` supplied source navigation and provisional-status context only. Their claims were reopened in the live source files. Rollout id `01a1121a-4750-72f0-8f5c-b501038890d3`.
