# Geometry frontier sweep: exact search interfaces and two failed bridges

7 October 2026. Reader: `frontier_geometry`. Release commit: `adc7f1241b42e322a6451854ab7e4b4c146bf78a`. Sources in the Literature Digestion repository were read only. No worker was spawned.

**Outcome:** no new major theorem or breakthrough is supported by this sweep. The best positive acquisition target is an explicit, finite numerical search for Gepner Harder--Narasimhan factors, conditional on a supplied support constant and an actual subobject decision/witness service. Two superficially stronger bridges fail: quintic Virasoro constraints do not determine the curve-counting data, and planar constant-distortion L1 embedding does not combine with fixed-p dimension reduction to compress the original planar metric into subpolynomial coordinates. The latter failure persists when p is tuned toward one.

The universal negative results below need no newly released theorem. They are reconstructions and routine consequences of primary prior art, not claimed novel. The positive search result is conditional on a precise part of family 055; the snowflake result is conditional on 089 and 094. None of those three complete release theorems was fully proof-audited here.

## What was read

All 98 present families in Algebraic and complex geometry, Differential geometry, Topology, and Convex and metric geometry were read at the **overview-statement level**. Existing cycle19 assessments/reports were read for `charges_design9`, `hessian_bridge12`, `frontier_geometry1`, `frontier_geometry2`, `frontier_topology`, `metric_geometry10`, and the root report. Their deeper readings are prior programme readings; this worker does not claim to have repeated them. In particular, the previous finite-global-rank torus counterexample and transport/LSI acquisition gates are preserved.

Current technical reads:

* **055, quintic Gepner manuscript:** entire introduction and numerical section; the block-support and finite block-refinement proofs in `grid.tex`, lines 201--355. The perturbed-aisle construction, full grid nesting, unsaturated-subobject argument, and large-volume companion were not audited. The numerical lattice and rotation algebra were independently reconstructed; the categorical inclusions are imports.
* **065, complete-intersection Virasoro manuscript:** entire introduction; operator, potential, coefficient-rule, and completion conventions. The Hodge/evaluation, cap preparation, sewing, and detection proofs were not audited. The projectivization companion was not technically read. The manuscript itself explicitly recognizes the earlier Calabi--Yau result.
* **089, planar manuscript:** introduction through the two-portal/interpolation mechanism; entire almost-embeddable consequence. No main packing/interpolation/assembly proof adoption. The bounded-treewidth companion was not technically read.
* **094:** theorem and parameter scope; exact-discretization setup; complete weighted-moment separation/sampling proof; complete weighted-projection fixed-point proof; the entire 1<p<2 clipping/projection argument and final upper-bound assembly. The electrical localization appendix, homogeneous-increment construction, p>2 construction, and exact lower-bound proof were not audited. The weighted-moment lemma was independently reconstructed. The projection step remains conditional on its cited electrical localization bound; the full theorem remains an unchecked import.
* **Primary priors:** Getzler 1999, introduction, original operator formula, and entire Section 7; Lee--Naor 2004, all three pages including the quadrilateral and diamond telescoping proof. Additional Coates--Givental--Tseng and Oblomkov--Okounkov--Pandharipande statements were checked at the indicated Calabi--Yau remarks, not as full-paper audits.

Pinned raw sources were recovered in `work/frontier_geometry_sources/`; 18 text leaves were checked against the release Git blob SHA1 and additionally SHA256-hashed. These are source-integrity checks, not mathematical validation. `frontier_geometry_reading_depths.json` records every family literally and keeps current depth separate from earlier workers' depth.

## 1. The useful physics interface: finite numerical search, conditional witness acquisition

Let X be a smooth quintic threefold. Family 055 writes its numerical classes as

\[
 v=(r,c,d,e)\in\Lambda\subset
 \mathbb Z\times\mathbb Z\times\tfrac1{10}\mathbb Z\times\tfrac1{30}\mathbb Z.
\]

Its numerical rotation is

\[
 M=\begin{pmatrix}
 -4&-20/3&-5&-5\\1&1&0&0\\1/2&1&1&0\\1/6&1/2&1&1
 \end{pmatrix},\qquad M^5=I.
\]

The normalized eigencharge is a linear functional over Q(zeta_5): ZM=zeta_5 Z and Z(O_x)=-1. Thus an irrational charge image does **not** require arbitrary-real phase comparisons. Products and conjugation stay in the fixed degree-four number field. In a sector of width pi/5, ordering phases is equivalent to the sign of Im(conjugate(z_1) z_2); dividing its antisymmetric part by zeta_5-zeta_5^-1 gives a real quadratic-field sign test. Equal-phase magnitude ties use |z|^2. Standard algebraic-number arithmetic decides both exactly.

The important source mechanism precedes semistability. Two independent perturbations of the second tilt imply, for a transformed block class w,

\[
 \epsilon(|r(w)|+|c(w)|)\le
 N_0(w)=\frac{\operatorname{Im} Z(w)}{5t_0}.
\]

The coordinate map w -> (r,c,Re Z,Im Z) is invertible; five powers of M give one support constant C for all blocks. This is the precise source input we use. It depends on the imported perturbed-aisle inclusions and a usable epsilon. Merely knowing the eigencharge does not supply it.

**Conditional finite-search proposition.** Suppose an extension-closed block S in an abelian heart has: numerical lattice Lambda as above; every nonzero block object F has a nonzero charge Z(F) in a closed sector of angle pi/5 and ||[F]||_2 <= C|Z(F)|; subobjects with block quotient also lie in S; and short exact sequences give additive classes. Let E be a supplied block object. Put

\[
 q(z)=\operatorname{Re}(e^{-i\theta}z),\quad
 \theta=\text{sector midpoint},\quad
 B=\frac{Cq(Z(E))}{\cos(\pi/10)}.
\]

Then every saturated subobject F of E and every nonzero factor of any block filtration has numerical norm at most B. Every such filtration has at most floor(30B) nonzero factors. Its possible classes lie in a set of cardinality at most

\[
 (2\lfloor B\rfloor+1)^2
 (2\lfloor10B\rfloor+1)(2\lfloor30B\rfloor+1).
\]

**Proof.** A sector projection is nonnegative, and q(Z(F)) <= q(Z(E)) because E/F lies in the same sector. Also |Z(F)| <= q(Z(F))/cos(pi/10), giving the class bound. A nonzero lattice vector has Euclidean norm at least 1/30, hence each nonzero block factor contributes at least cos(pi/10)/(30C) to q. Additivity gives the length bound. The coordinate box count follows directly from the denominators. The same argument applies to successive quotients since their projection never exceeds the original one.

Now supply a certified rational upper bound for C and an oracle A(E,v) which either constructs a certified saturated subobject of class v and its quotient, or certifies that none exists. Enumerate the box, retain feasible classes, choose maximum phase then maximum |Z|, and repeat on the quotient. One may overenumerate the containing rational grid; A also rejects classes outside the actual lattice. The whole E is an admissible candidate. Any saturated subobject of the selected F is saturated in E by extension closure. A quotient subobject of larger phase, or the same phase, lifts to a saturated subobject of E and contradicts the maximum/tie choice. Therefore F is block-semistable and the subsequent phases strictly decrease. The length bound terminates the process. This reconstructs the source's finite-refinement argument as a **charged conditional search**: at most floor(30B) times the displayed box cardinality oracle calls, plus exact arithmetic and actual quotient construction. Alternatively use a certified rational radius larger than B and replace B throughout the execution ledger by that radius.

This is polynomial in the numerical radius B, generally exponential in the binary input height. It is not an efficient algorithm in bit length. The source does not provide A, a bound for its cost, effective C/epsilon, or bounded atlases for the relevant derived subobject families. Counting lattice candidates also does not compute a virtual/BPS invariant of their moduli. The largest acquisition obstacle is an effective class-feasibility/witness theorem for the **actual irrational double-tilt heart**, with bounded presentations and exact certificates.

**Downstream opportunity:** an exact explorer for actual quintic Gepner stability and wall data, followed by separately certified moduli/counting machinery. The first falsifiable step is a finite presentation and cost bound for A on one explicitly represented nontrivial object. Without that service, finite candidate lists are search capital, not acquired stable factors or BPS counts. The underlying support/HN argument is source work and standard stability theory; the explicit box and call ledger are routine deductions. No historical novelty is asserted. [Pinned 055 manuscript](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/A-Gepner-stability-condition-on-every-smooth-quintic-threefold-September-24-2026/paper.pdf).

## 2. Why 055 + 065 does not determine quintic amplitudes

Fix a positive curve class beta on a quintic and define N_(g,beta)=< >_(g,beta), the unmarked connected invariant. Ordinary unreduced stable-map virtual dimension is the number n of markings. After repeatedly applying the string equation to remove tau_0(1), every remaining insertion has

\[
 a+\tfrac12\deg_{\mathbb R}(\gamma)-1\ge0.
\]

Here H^1=0, a>=0, and a unit can remain only with a>=1. Dimension says the sum is zero. Consequently only tau_1(1) and primary divisors can survive. Primitive degree-three, higher-degree, and higher-descendant insertions vanish after the string reduction. Dilaton and divisor equations then give the exact formula

\[
 \left\langle\tau_1(1)^k\prod_{j=1}^m\tau_0(D_j)\right\rangle_{g,\beta}
 =(2g-2+m)_k\prod_{j=1}^m\left(\int_\beta D_j\right)N_{g,\beta},
\]

where (x)_k is the rising factorial. Apply dilaton first, so divisor-removal corrections involving descendants do not enter. All general positive-degree descendants therefore reduce to this one seed per (g,beta), by finite string recursion. Degree-zero/unstable classical conventions are separate and are not used to infer a positive-degree seed.

For g>0, Getzler's Section 7 starts from the standard Hori equation at k=0. For k>=1, the Virasoro errors, restricted to the primary-unit coordinate being zero, have grading weight -k while every surviving variable has nonnegative weight. They therefore vanish identically; the string commutator extends this vanishing off that slice. The proof uses dimensional and standard GW identities, and leaves the N_(g,beta) values unconstrained. The release 065 introduction explicitly cites this earlier result. Its new theorem is not a new quintic Virasoro ingredient. [Getzler, Theorem 7.1 and proof](https://arxiv.org/html/math/9812026v4#S7).

Thus 055 may supply a new stability condition, but adding 065 alone cannot determine the positive-genus quintic seeds, mirror boundary conditions, or BPS degeneracies. This is a prior-art obstruction, not a flaw in the broader complete-intersection theorem. I do not claim arbitrary seed assignments realize actual Calabi--Yau geometries or satisfy every extra degeneration/correspondence identity. The narrower statement is that the named Virasoro system introduces no independent equation selecting those seeds. Nearest independent confirmation: [Coates--Givental--Tseng, Calabi--Yau discussion](https://www.cambridge.org/core/journals/forum-of-mathematics-pi/article/virasoro-constraints-for-toric-bundles/8BE7221F9F98EBE37DEDAFB62F4ACBC5) and [Oblomkov--Okounkov--Pandharipande, footnote 16](https://www.cambridge.org/core/journals/forum-of-mathematics-pi/article/virasoro-constraints-for-stable-pairs-on-toric-threefolds/AC30911051BE3F9A6EF39C05C8E57E40).

## 3. A quantitative obstruction to 089 + 094, including varying p

Let G_0 be one unit edge; obtain G_k by replacing each previous edge with a four-edge diamond of half the previous edge length. These are planar and series-parallel, with

\[
 N_k=\frac{2(4^k+2)}3.
\]

At level j there are 4^(j-1) anti-edges, each of graph distance 2^(1-j), and at the final level the sum of squared edge lengths is one. Lee--Naor's fully checked three-page proof gives

\[
 \operatorname{distortion}(G_k\to L_p)^2\ge1+(p-1)k,
 \qquad 1<p\le2.
\]

The proof uses the classical uniform-convexity quadrilateral inequality and sums it over the diamond hierarchy; intermediate edge energies cancel. This result is old. [Lee--Naor, Theorem 1.1, Lemmas 2.1--2.2](https://web.math.princeton.edu/~naor/homepage%20files/diamond1.pdf).

**Endpoint-tuning corollary, independently derived here.** Let Delta>=1 be a distortion bound and k>=4Delta^2-1. Every map G_k -> ell_p^d of distortion at most Delta, for any 1<=p<=2, satisfies

\[
 d\ge2^{k/(4\Delta^2-1)}
 =\left(\frac{3N_k-4}{2}\right)^{1/[2(4\Delta^2-1)]}.
\]

**Proof.** For p>1 the previous inequality gives p-1 <= (Delta^2-1)/k; for p=1 this is immediate. Put t=4Delta^2-1 and q=1+t/k, so p<q<=2. On d coordinates the identity ell_p^d -> ell_q^d has distortion d^(1/p-1/q). Compose the assumed embedding with it. The old inequality at q gives

\[
 \Delta^2d^{2(1/p-1/q)}\ge1+(q-1)k=4\Delta^2.
\]

Therefore log d >= log 2/(1/p-1/q). Since 1/p-1/q <= t/k, the displayed bound follows. If the initial p-bound is impossible, no embedding exists and the conclusion is vacuous. This permits p to depend arbitrarily on k. The exact norm-comparison identity is also the classical route from the diamond theorem to L1 dimensional lower bounds; this is not claimed a new obstruction mechanism.

For fixed Delta, the necessary dimension is polynomial in N. Hence neither fixed-p application nor p->1 tuning yields fixed-distortion subpolynomial coordinates for the **original** planar metric. The 094 theorem explicitly assumes a fixed p and supplies no uniform endpoint constants. More fundamentally, most planar metrics are not constant-distortion L_p inputs for any fixed 1<p<=2. No source theorem is contradicted.

**Lawful positive bridge:** conditionally import the planar L1 distortion C from 089 and the fixed-p dimension reduction from 094. A finite cut representation D=sum_S w_S delta_S with d_G<=D<=C d_G gives

\[
 F(v)=(w_S^{1/p}1_S(v))_S,\qquad
 \|F(u)-F(v)\|_p=D(u,v)^{1/p}.
\]

Apply 094 to obtain subpolynomial coordinates for the **1/p snowflake** of the graph metric, at fixed p and fixed distortion, with total distortion C^(1/p)D_0. This is a pairwise representation consequence; it does not preserve original path lengths, flow-cut values, Dirichlet energies, linear combinations, or stochastic/quantum transitions. At p=2 ordinary Johnson--Lindenstrauss already gives O(log N) coordinates for this Hilbert snowflake. Both general cut-to-snowflake conversion and nonlinear compression are old operations; the strengthened planar input and non-Hilbert bound are the imported release improvements. No efficient acquisition algorithm follows from the two existence theorems.

The separately reconstructed 094 weighted-moment lemma is useful research capital: a common moment b and a common bound K, uniform over every pair-weight test lambda, imply one distribution with simultaneous relative moment control by convex separation, then finite coordinates by bounded sampling. Uniformity of b,K is load-bearing. This is a certificate-to-representation mechanism, conditional on obtaining the weighted random-gradient service; it is not itself an acquired service.

## Remaining opportunities and stopping boundary

The positive opportunities retained after this sweep are: (a) actual bounded presentations/subobject certificates for 055; (b) constructive weighted-moment or cut-distribution acquisition for 089/094; (c) a fully checked sharp CAT(0) filling mechanism in 337 for geometric PDE transfer; and (d) 318/319 attachment and finite-assembly obstructions as limits on algebraic topological compilers. The last two remain overview-level candidates in this worker's reading. They are not supported new connections to computation or physics.

Families 041/043/044/069 contain promising fibration, filtration, Higgs/Coulomb, and duality interfaces, but an equivalence/existence statement has not supplied finite presentations or algorithms here. Previous programmes already identified the 050 effective dual-certificate and 357 sharp two-center geometric-estimate gates. The torus/transport approaches were not restarted. No catalogue claim, source hash, numerical check, or Lean label was promoted into theorem validation.

`frontier_geometry_checks.py` verifies the finite diamond distance ledger on k=1,...,5 and the literal rank-four rotation/lattice algebra using exact fractions. Its output is implementation evidence only. The universal conclusions are the written arguments above. There was no source-proof execution, Lean compilation, moduli computation, external validation, or novelty certification. This is incremental research clarification and a concrete next acquisition interface, below the requested significance bar.
