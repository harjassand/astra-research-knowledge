# Fresh analysis, functional-analysis, dynamics and PDE opportunity sweep

**Result.** The strongest newly reconstructed connection in this allocation is a defect-sensitive, mean-preserving binary rounding law, obtained from family 076 and linked to the exact-mean interface in A–F `ROUND`. It controls the Fourier error of every supported output, while retaining every prescribed coefficient mean. The construction uses classical matrix discrepancy locally and does not require the release's global ultraflat theorem. It is a useful synthesis for stochastic binary filters and quantized linear features; a first-in-literature claim is not established.

The other useful deductions are a dimension-independent collar bound for higher matrix-function derivatives (325), and a direct Wasserstein certificate for the quantum coherent mixtures in C/E/F. The latter bypasses the unstable optimal-map representation in 374. Neither produces a quantum memory exponent improvement. Qualitative mixing in 145/154 and permanence in 149 do not close the acquisition or resource gaps in A–F.

## Provenance and actual depth

Pinned release: `adc7f1241b42e322a6451854ab7e4b4c146bf78a`. All 55 assigned overview entries were read. Prior cycle-19 family assessments were inspected for all four categories. Current proof reading was concentrated on:

- **076:** all six technical sections of the October 5 ultraflat manuscript, plus the predecessor's complete signed-interval packing and real-matrix-discrepancy argument. Sources newly retrieved into this task's `work/`; source workspace remained read-only.
- **325:** direct manuscript's main argument, including its two coefficient orders, Faber contraction, positive resolvent block and outer-domain limit. The conformal-collar appendix and Lean dependency graph were not checked.
- **332:** its finite cut lift, cubic flattening, stopped-martingale assembly and median interpretation; the previous report's stronger constants and sample interface were read as prior internal findings, not independently rerun here.
- **374:** introduction, complete three-atom sharpness proof and complete fixed-mass finite-target potential argument. The moment and gradient sections giving the global upper bound were not reread.
- **149:** introduction, entire arbitrary-tolerance affine lemma and common absorbing-set iteration. The intervening general trapping section was not reread.
- **154:** complete dynamical-input section; selected joining-law section at excerpt depth. Its companion mixing and smooth-triple proofs were not read.

The literal 55-family depths are in `frontier_analysis_read_depths.json`. Formalization listings were not treated as kernel verification. No global forced or unforced Navier–Stokes theorem was adopted. The memory-registry search supplied no premise used in the deductions below.

## 1. Family 076 × A–F ROUND: unbiased small-defect rounding

### Exact question and interface

Let `R ≥ n`, `A ∈ [-1,1]^(R×n)`, `p ∈ [0,1/2]^n`, and `μ = Σp_j`. Can one produce a binary random vector `Z`, with **every coordinate mean exactly `p_j`**, such that **every output** has small feature error, improving on the `O(√R)` bound obtained by normalizing columns and using the general Euclidean-column ROUND theorem?

**Derived lemma.** There is a universal constant `C` and a finite law on binary vectors in the minimal cube face of `p` satisfying

`E Z = p`,

`‖A(Z-p)‖∞ ≤ C[1 + √(μ log(8R/μ))]` for every supported vector.

Set the square-root term to zero at `μ=0`, when `Z=0` exactly. The law can additionally be reduced to at most `n+1` atoms without changing its mean or the hard error bound. With a supplied certified matrix-signing routine, one sample uses `O(log n)` signing calls. There is also a favorable response for every rational cost `c`: a good binary `z` with `c·(z-p) ≤ 0`. This is a cube result, not an arbitrary-matroid or general-polytope extension.

### Complete derivation

**Balanced signing.** The standard Spencer/Lovett–Meka consequence is that a real `r×s` matrix with entries at most one, `r≥s`, has a signing with row discrepancy at most `C₀√(s log(2r/s))`. Add an all-ones row. If `s` is odd, also add one zero column to the original matrix, making the total number of columns even. Find a signing for this augmented matrix. Its total sign sum is even and bounded by the same discrepancy bound. Flip half that sum's absolute value of the majority signs. This makes the augmented sum exactly zero and increases any original row discrepancy by at most its previous total-sign discrepancy. Drop the dummy if used. Consequently, we obtain

`|Σ ξ_j| ≤ 1`, `‖A_S ξ‖∞ ≤ C₁√(s log(8R/s))`.

For even `s`, the sign sum is zero. Both orientations `ξ` and `-ξ` have these properties. This balance is the load-bearing modification: fair orientation preserves conditional means while keeping the total defect uniformly controlled. The source's orientation that only decreases mass does not itself preserve means.

**Small mass.** If `0≤μ≤1`, use `Z=e_j` with probability `p_j`, and `Z=0` with probability `1-μ`. This preserves means, freezes all zero coordinates, and has hard feature error at most `1+μ≤2`.

**Dyadic initialization.** For `μ>1`, set `J=ceil(log₂ n)`. Independently round each `p_j` to its adjacent multiples of `2^-J`, choosing the upper value with probability `2^J(p_j-lower_j)`. The initialized vector `q` is unbiased, stays in the cube, has `Σq_j≤μ+1`, and has initial feature error at most `n2^-J≤1`. Exact rational `p` gives exact rational coin probabilities.

**Coarsening.** For `h=J,...,1`, let `S_h` consist of coordinates whose integer numerator `2^h q_j` is odd. Obtain a balanced signing on those columns, then choose its orientation with a fair independent coin and update `q_j ← q_j ± 2^-h ξ_j`. Odd numerators are at least one and at most `2^h-1`, so either orientation stays in `[0,1]` and moves to the next coarser grid. Each step preserves `E[q_new | q_old, ξ] = q_old`. Its total-mass change has absolute value at most `2^-h`; hence every trajectory throughout the process has mass at most `μ+2 < 3μ`.

Each active coordinate has mass at least `2^-h`. Thus `s_h ≤ min(n, 3·2^h μ)`. Monotonicity of `s log(8R/s)` on `0<s≤n≤R` gives

`2^-h √(s_h log(8R/s_h)) ≤ √(3μ log(8R/μ))·2^-h/2`.

If `3·2^h μ>n`, first bound the left numerator by `n log(8R/n)` and use `n≤3·2^h μ` and `μ≤n`; the same displayed estimate follows. Summing the geometric series and adding initialization error proves the hard bound. The final vector is binary and repeated conditional expectation gives its exact mean.

**Favorable response.** For `μ≤1`, choose a cheapest vertex in the explicit law's support; its cost is at most the law's mean cost. For `μ>1`, initialize each coordinate by its cheaper adjacent dyadic value according to the sign of `c_j`, and orient every balanced signing so that `c·ξ≤0`. Initialization and every move have nonpositive cost relative to their predecessor. The same mass and discrepancy estimates still hold, and zero input coordinates remain zero. Thus a favorable good output exists for every cost.

**Small support.** The direct stochastic construction already proves `p∈conv(G)`, where `G` is the finite set of hard-good binary outputs. Carathéodory gives at most `dim F(p)+1` atoms. For rational data, polynomial-call transcript extraction can use the favorable response and the same bounded-separator/ellipsoid interface stated in A–F ROUND. Its bit accounting and signing implementation remain charged. This allocation implements neither a general ellipsoid extractor nor a rational-bit Lovett–Meka engine; its runnable checker uses an exhaustive signing oracle.

### Fourier consequence and scientific use

For coefficients `X_j ∈ [-1,1]`, put `d_j=sign(X_j)` (choose `+1` at zero) and `p_j=(1-|X_j|)/2`. Apply the lemma to the real and imaginary evaluations of `d_j e^(2πijt)` on a grid of `20n` points, so `R=40n`. For `ε_j=d_j(1-2Z_j)`, every coefficient mean is exactly `E ε_j=X_j` and every output satisfies

`sup_t |Σ(ε_j-X_j)e^(2πijt)| ≤ C[1+√(μ log(C'n/μ))]`.

The grid-to-circle passage is the source's independently checkable derivative argument: a degree-`n-1` error polynomial has angular derivative at most `2π e n` times its circle maximum, and every circle point is within `1/(40n)` of the grid. The resulting loss is the fixed factor `(1-πe/20)^-1`. Complex prescribed phases work identically; exact Fourier entries require approximation costs for an actual bit compiler.

If the source's relaxed filter is already flat and `μ=o(n)`, then `√[(μ/n)log(C'n/μ)]→0`, so every output filter retains asymptotic flatness **and** the ensemble preserves the relaxed coefficients. This strengthens the particular deterministic-rounding interface in the source. It preserves first moments, not independence or all higher moments. It does not furnish arbitrary prefix guarantees, matroid feasibility, positive quantum quadrature weights, or better qubit memory exponents.

For an acquired ultraflat sign polynomial `P_N` and any period `M≥N`, its zero-padded circulant convolution has singular values `|P_N(ζ_M^j)|/√N ∈ [1-ε,1+ε]`. It is therefore a well-conditioned binary filter with `O(M log M)` application by FFT. This is a conditional construction, not a compression: it retains dimension `M`. Arbitrary coordinate masks can become dense under convolution or Fourier change of basis, so it does not close A's selective-output tensor-access bottleneck. FFT, orthogonal Fourier bases and Hadamard constructions are competent existing comparators.

### Source attack, evidence and novelty boundary

The October 5 waves proof genuinely uses increased endpoint curvature to keep modulus positive while shrinking endpoint Fourier contributions. It matches function values and leading phase derivatives, causing the first exterior integration-by-parts boundary terms to cancel; the remaining exterior coefficients are summably `O_data((N+|k|)^-2)`. The interval-packing input was inspected through its conditional first/second moments, bad-vertex deletion, codegree bound and Pippenger–Spencer matching step. No contradiction was found in this local read. This is not an independent audit of the entire global theorem or a numerical filter implementation.

The source makes many auxiliary choices before `N→∞`: torus dimension, coefficient-spreading boxes, small projection products, packing prime, matching and phase collars. It supplies no inexpensive quantitative `N₀(ε)` or practical compiler. These dependencies prevent an affordable-filter claim from the asymptotic theorem alone.

The reproducible checker `frontier_analysis_check.py` passes **84 exact rational laws**, including nondyadic probabilities, **504 favorable-cost cases**, four exact transport scaling cases, and four mixing obstruction cases. It checks normalization, positivity, exact means, minimal-face freezing, cube membership and total-mass control. Exhaustive balanced signings certify these finite fixtures only; they are not a universal discrepancy proof or runtime benchmark.

Nearest primary prior: [Lovett–Meka, Theorem 4](https://arxiv.org/html/1203.5747v2) supplies the vector partial-coloring ingredient. [Doerr, *Typical rounding problems*](https://doi.org/10.1016/j.tcs.2003.10.035) already proves total-mass-sensitive linear discrepancy. The complete six-page [Friedrich–Doerr–Klein–Osbild, *Unbiased Matrix Rounding*](https://hpi.de/friedrich/docs/publications/2007/ENDM_b.pdf) announcement was read: its Theorem 3.2 states exact unbiased bitwise rounding with row/column-prefix control, and its truncation paragraph explicitly randomizes discarded bits to retain exact expectations. It does not supply the underlying general algorithm proof in this announcement. Its interface concerns sums of matrix entries, rather than a prescribed vector under an arbitrary real feature matrix. The exact combination above is newly reconstructed here; these older results make a foundational novelty claim premature. The older full proof of mass-sensitive unbiased discrepancy remains the decisive priority check.

## 2. Family 325 × matrix-function precision: higher derivatives with a charged collar

The complete Crouzeix proof keeps `FG` and `GF` in their correct orders. Its positive boundary kernel has both angular marginals; those two facts survive matrix coefficient amplification. This offers scientific-computing error certificates for nonnormal matrix functions and matrix-valued response functions.

A precise derived bound is available without acquiring the source's optimal similarity. Suppose a complete numerical-range bound with constant `K` is available (`K=1+√2` from prior work, or `K=2` conditional on family 325). For an `m`th repeated-direction derivative of a matrix polynomial `F`, let `c_m=cos(π/(m+2))` and `r>0`. Then

`‖D^m F[A](E,...,E)‖ ≤ K m! (c_m‖E‖/r)^m sup_(z∈W(A)+D_r) ‖F(z)‖`.

Proof: form the `(m+1)`-block upper bidiagonal matrix with `A` on its diagonal and `tE` on its superdiagonal. Its numerical range lies in `W(A)+D_(t c_m‖E‖)`, by the scalar path adjacency Rayleigh bound applied to the block-vector norms. The top-right block of its polynomial evaluation equals `t^m D^mF[A](E,...,E)/m!`, as follows by expanding words in `A` and `E`. Compress the complete bound and take `t=r/(c_m‖E‖)`. This proves the formula, including arbitrary finite coefficient dimension.

The collar and scalar maximum are inputs to be certified. For logarithms and inverse powers, that collar must avoid the singular set; a small spectral gap alone does not control a nonnormal matrix's numerical range. The A–F ROUND Hessian matrices and quantum covariance matrices are Hermitian, so spectral-theorem estimates with constant one already apply there.

Priority is substantially known: block matrix derivative evaluation appears in [Al-Mohy–Higham, Theorem 2.1](https://eprints.maths.manchester.ac.uk/1218/1/covered/MIMS_ep2008_26.pdf). [Crouzeix–Kressner, Sections 3–5](https://arxiv.org/html/2007.09784v1) already gives bivariate and derivative numerical-range bounds. Its derivative norm is induced by **Frobenius norm** on matrix inputs; converting that silently into operator-norm or diamond-norm control would change the interface. The displayed collar bound works in operator norm but is a straightforward block consequence, not an established novel theorem. Complete polynomial control also does not make the calculus a completely positive channel or acquire arbitrary entangled measurements for a classical archive.

## 3. Family 374 × C/E/F: law stability bypasses unstable latent maps

The source's exact cube counterexample has `b=a/2`,

`W₂(μ_a,ν_a)²=ab²=a³/4`,

`‖T_(μ_a)-T_(ν_a)‖²_(L²)=b/2+ab²=a/4+a³/4`.

Thus a fixed common-random-number realization by optimal transport can move much more than the target laws do. This obstructs a proposed uniformly Lipschitz compiler for those latent assignments; it is compatible with stable decoded observables.

For the qubit archives, directly use their decoder kernel. For sphere directions `u,v`, the spin-`L` coherent states satisfy the exact pure-state trace distance

`T(ω_(L,u),ω_(L,v)) = √[1-((1+u·v)/2)^L] ≤ (√L/2)|u-v|`.

Inverse Schur decoding with the same mixed multiplicity preserves this distance. By convexity and any coupling `π` of angular laws,

`T(∫Ω_(n,L,u)dμ, ∫Ω_(n,L,v)dν) ≤ ∫ min(1,(√L/2)|u-v|)dπ ≤ (√L/2)W₂(μ,ν)`.

For known common block weights, sum these bounds over `L`; different block weights cost their total variation separately. This works for continuous versus discrete laws even when their total variation is one. It gives a direct positive-quadrature certificate without building a Brenier map.

For a two-dimensional mesh with diameter `h`, the decoder error is at most `√L h/2`; `O(L/ν²)` uniform mesh nodes suffice for block error `ν`. This improves the loose `O(L)` projector-Lipschitz constant recorded in E's precision sketch for the decoder component. It does not establish that node count is optimal or improve the separate POVM normalization/error bound. Analytic or higher-order quadrature remains a stronger possible comparator.

An especially transparent separation uses the source's three atom targets as Bloch vectors for single mixed qubits: the mixture state changes by trace distance exactly `ab/2=a²/4`, while unit-scale branch changes of the common-source optimal assignments occupy mass `b/2=a/4`. This is the same supplied-versus-acquired law distinction underlying C/E/F; map regularity is not the right bottleneck for average output-state error. The coherent-state inequality is elementary prior mechanism, so this is a useful certificate improvement, not a new quantum compression theorem.

## 4. Dynamics × LEARNING and scientific simulation: two exact barriers

**145/154 do not acquire high-girth latent samples.** Consider a stationary chain on `F₂^m` that keeps its state with probability `1-q` and resets to an independent uniform state with probability `q>0`. Its two-sided shift is invertible, mixing of every order; finite separated blocks decouple when a reset occurs between them. Nevertheless, among the first `n` samples, no reset occurs with probability `(1-q)^(n-1)≥1-(n-1)q`. On that event every even-size subset sums to zero. Choosing the computable rational `q_n=n^-10` makes the relation probability tend to one, with polynomial `O(n(m+log n))` sample-generation work using exact rational reset coins. A uniform random permutation of the sampled vectors makes their finite joint law exchangeable and preserves the no-reset event. Hence all-order qualitative mixing cannot supply a uniform superpolynomial suppression of fixed-size relations required by A–F's low-degree LEARNING obstruction. The process here varies with `n`; the conclusion concerns the missing uniform rate across this admissible class, not failure of mixing for any fixed positive `q`. A quantitative reset/mixing modulus must be charged. The counterexample belongs to a class where higher-order mixing is elementary, so it does not rely on adopting family 145.

**149 permanence does not bound acquisition time uniformly over initial conditions.** The weakly reversible reaction `0 ⇌ X`, with both rates one, satisfies `x'=1-x` and has the common absorbing interval `[1/2,2]`. For `x₀>2`, entry occurs at `log(x₀-1)`, unbounded over its fixed positive class. This exactly matches the source's allowed initial-point-dependent transient; it is not a counterexample to permanence. The affine proof also chooses a finite cover by compactness and an asymptotic scale threshold. Its arbitrary positive tolerance function has no computational representation or modulus in the lemma's interface. Effective trapping constants, entry times and ODE discretization costs therefore remain additional tasks. Permanence alone does not certify steady-state convergence, mixing or a useful chemical processor.

The entropy-rate formulas in 148 and arithmetic classification in 153 are relevant representation constraints, but exact composed-map overlap classes and an infinite approximation condition are not acquired efficient oracles. Family 152's smooth-model obstruction cautions against equating low entropy with a cheap smooth finite-dimensional simulator. These claims remained catalogue-level in the current pass.

## Remaining gate and allocation decision

The precise new lemma worth retaining is the mean-preserving small-defect cube rounding construction. Its proof is complete relative to the classical signing theorem, its finite law algebra is runnable, and it offers a strictly narrower but stronger interface than the generic column-normalized bound when `μ log(R/μ)≪R`. It does not solve any of A–F's global open bottlenecks.

The next useful allocation is **priority and implementation**, not another catalogue summary: compare the exact mass-sensitive unbiased interface with older Pusher–Chooser and randomized linear-discrepancy results; then implement and charge a certified finite-bit signing oracle on acquired Fourier coefficients. For foundational use of 076, separately acquire quantitative auxiliary-size and `N₀(ε)` bounds. For quantum use, implement the direct positive quadrature certificate against an existing adaptive/high-order baseline.

No forced-to-unforced Navier–Stokes transfer was made: 376 retains an externally supplied smooth force and its computational evaluation costs. Global PDE existence, a.e. Fourier convergence, fixed-point existence, or an infinite classification likewise does not by itself supply finite simulation or optimization complexity.

## Literal family-depth ledger

```json
[
  {
    "family_id": "071",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "072",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "073",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "074",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "075",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "076",
    "depth": "full_main_technical_text_plus_two_shared_input_proofs"
  },
  {
    "family_id": "077",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "078",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "079",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "080",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "081",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "082",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "083",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "084",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "085",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "086",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "143",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "144",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "145",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "146",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "147",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "148",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "149",
    "depth": "two_complete_proof_sections_and_introduction"
  },
  {
    "family_id": "150",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "151",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "152",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "153",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "154",
    "depth": "complete_inputs_section_and_selected_joining_excerpt"
  },
  {
    "family_id": "322",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "323",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "324",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "325",
    "depth": "main_core_proofs_complete_collar_appendix_unread"
  },
  {
    "family_id": "326",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "327",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "328",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "329",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "330",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "331",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "332",
    "depth": "core_proof_excerpts_plus_previous_internal_assessment"
  },
  {
    "family_id": "362",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "363",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "364",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "365",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "366",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "367",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "368",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "369",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "370",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "371",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "372",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "373",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "374",
    "depth": "two_complete_proof_sections_and_introduction"
  },
  {
    "family_id": "375",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "376",
    "depth": "catalogue_and_previous_assessment_only"
  },
  {
    "family_id": "377",
    "depth": "catalogue_and_previous_assessment_only"
  }
]
```
