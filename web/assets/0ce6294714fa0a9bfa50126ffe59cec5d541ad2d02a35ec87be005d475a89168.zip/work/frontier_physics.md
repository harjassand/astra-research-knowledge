# Fresh physics/operator/probability consequences — 7 October 2026

## Outcome and status

The most useful positive mechanism is an exact reconstruction of Gaussian cycle phases from **charge weighted modular commutators**. On a rectangular square grid it uses pair spectra and one four-site probe per face, instead of requiring a nonzero covariance link from one root to every site. It has a complete elementary derivation below. These are additional observables: they are not obtainable automatically from the spectra and ordinary modular commutators in the attached A–F interface. Historical novelty and an economical physical acquisition protocol remain UNKNOWN.

Two negative results materially delimit this opportunity.

* For half-filled Gaussian covariances supported on any bipartite graph, every ordinary modular commutator vanishes. Opposite nonreal loop phases are indistinguishable even by every ordered many-body word made only from the state's modular Hamiltonians. A one-particle Jordan–Lie expression detects the phase, but its genuine many-body analogue cancels exactly.
* The naive photon-number entropy inequality conditioned on arbitrary quantum memory is false even for a fixed independent thermal bath, positive conditional input entropy, and three finite-energy Gaussian modes. The explicit example below has a certified violation greater than 0.0269 nats. It does not contradict release family 273, whose interface is independent input ports without conditioning on the memory.

Exact local cycle recovery also fails to furnish a size-independent Lipschitz inverse: a constant edge floor and a fixed covariance spectral margin do not prevent weak face errors from accumulating around a large grid boundary.

These are complementary to the root's repetition and spectral-collision teams. They do not resolve the imported collision theorem, yield quantum PCP, or establish a new post-release computational capability. The cycle mechanism uses standard Gaussian calculus and cycle invariants rather than a load-bearing theorem unique to the new release.

## 1. Interface and notation

Let \(\rho_C\) be a faithful, number-conserving fermionic Gaussian state on finitely many labelled modes, with

\[
C_{ij}=\operatorname{Tr}(\rho_C c_j^\dagger c_i),\qquad 0<C<I.
\]

For a CAR region \(R\), its covariance is the principal submatrix \(C_R\). Its modular Hamiltonian has the form

\[
K_R=-\log\rho_R=Q(k_R)+s_R I,\quad
Q(A)=\sum_{ij}A_{ij}c_i^\dagger c_j,\quad
k_R=f(C_R),\quad f(x)=\log((1-x)/x).
\]

Matrices are embedded in the full one-particle space when multiplied. Constants drop from commutators. The exact Gaussian identities used below are

\[
[Q(A),Q(B)]=Q([A,B]),\quad
\langle Q(A)\rangle=\operatorname{Tr}(CA),
\]

\[
\langle Q(A)Q(B)\rangle
=\operatorname{Tr}(CA)\operatorname{Tr}(CB)
+\operatorname{Tr}(CAB)-\operatorname{Tr}(CACB).
\tag{1}
\]

The supplied A–F finite theorem assumes labelled one-particle covariance spectra, occupations, ordered modular commutators, and nonzero root spokes. Its conclusions are finite exact reconstruction up to onsite \(U(1)\) gauge. It does not supply physical modular measurements or a uniform precision theorem.

Here a support graph means the graph of nonzero off-diagonal entries of \(C\). It is a substantial promise about the covariance. A local physical quadratic Hamiltonian generally has a covariance with longer-range entries, so Hamiltonian locality alone is insufficient.

## 2. An exact modular blind spot and the failed Jordan–Lie shortcut

### Bipartite blindness

Suppose

\[
C=\tfrac12 I+X,\qquad \Gamma^2=I,\qquad \Gamma X\Gamma=-X,
\]

where \(\Gamma\) is diagonal with entries \(+1,-1\). Equivalently, the occupations are all one half and the covariance support graph is bipartite.

Every region inherits this relation. Since \(f(1-x)=-f(x)\),

\[
\Gamma k_R\Gamma=-k_R.
\]

Thus \([k_R,k_S]\) is even under \(\Gamma\), whereas \(X\) is odd. Consequently

\[
J(R,S)=i\operatorname{Tr}C[k_R,k_S]
=i\left(\tfrac12\operatorname{Tr}[k_R,k_S]
+\operatorname{Tr}X[k_R,k_S]\right)=0
\tag{2}
\]

for every pair of regions, regardless of their size.

An explicit faithful four-mode example, with \(t=1/10\), is

\[
C=\begin{pmatrix}
1/2&t&0&-it\\
t&1/2&t&0\\
0&t&1/2&t\\
it&0&t&1/2
\end{pmatrix},\qquad
\Gamma=\operatorname{diag}(1,-1,1,-1).
\tag{3}
\]

Its eigenvalues lie between 0.3152 and 0.6848. Every labelled principal covariance spectrum is identical for \(C\) and \(C^*\). All their ordinary modular commutators are zero. But the onsite-gauge invariant

\[
W_{1234}=C_{12}C_{23}C_{34}C_{41}=it^4
\]

changes sign under conjugation, so \(C\) and \(C^*\) are not onsite-\(U(1)\)-gauge equivalent. Here \(C_{13}=C_{24}=0\), so no vertex has all the nonzero root spokes required by the attached theorem. The finite theorem remains intact; this example obstructs a broader pure-modular reconstruction interface.

This is local oriented loop information, not a claimed counterexample to formulas for a bulk chiral central charge.

### Why adding only higher modular words cannot repair it

The CAR automorphism \(c_j\mapsto\Gamma_{jj}c_j^\dagger\) changes the covariance to

\[
I-\Gamma C^T\Gamma=C^T=C^*.
\]

In an occupation tensor representation it can be implemented by a product of onsite particle–hole rotations and onsite phases. For (3), the implementation is simply \(U=X_{\rm Pauli}^{\otimes4}\). The modular Hamiltonians of every corresponding region transform by the same unitary:

\[
U\rho_C U^\dagger=\rho_{C^*},\qquad
UK_R(\rho_C)U^\dagger=K_R(\rho_{C^*}).
\]

Hence every labelled ordered-word expectation

\[
\operatorname{Tr}\rho_C K_{R_1}\cdots K_{R_q}
\]

is identical for the two states, for every degree and order. The symmetry preserves the pure modular interface while reversing the oriented charge. A repair must add an observable that fixes this orientation, or otherwise change the allowed equivalence group.

### Exact sign and Wick cancellation for the parent's four-cycle expression

At half filling, a two-site covariance with nonzero off-diagonal entry \(C_{ij}\) has

\[
(k_{ij})_{ij}=a_{ij}C_{ij},\qquad
a_{ij}=-\frac{2\operatorname{atanh}(2|C_{ij}|)}{|C_{ij}|}.
\]

Set \(A=k_{12}\), \(B=k_{23}\), \(E=k_{34}\), \(D=[B,E]\). Direct multiplication gives

\[
i\operatorname{Tr}C\{A,D\}
=-2a_{12}a_{23}a_{34}\operatorname{Im}W_{1234}.
\tag{4}
\]

For equal magnitudes \(t\), its coefficient is
\(16\operatorname{atanh}(2t)^3/t^3\), positive. For \(W=t^4e^{i\phi}\), the leading value is \(128t^4\sin\phi\).

However, the genuine many-body candidate obeys (1):

\[
i\langle\{Q(A),[Q(B),Q(E)]\}\rangle
=i\left[
2\operatorname{Tr}(CA)\operatorname{Tr}(CD)
+\operatorname{Tr}C\{A,D\}
-2\operatorname{Tr}(CACD)
\right].
\tag{5}
\]

Bipartite parity gives \(\operatorname{Tr}(CD)=0\) and

\[
\operatorname{Tr}(CACD)
=\tfrac12\operatorname{Tr}C\{A,D\}.
\]

Therefore (5) is exactly zero. Subtracting the Wick term is not an acquisition method: the oriented contraction being subtracted already contains the missing imaginary loop phase. In the explicit Fock check, (4) is 0.0133318512, the raw many-body expression is zero to numerical precision, and the separately needed Wick term is 0.0133318512.

## 3. A genuine charge repair and graph reconstruction

### Four-site theorem

Suppose four sites form an induced covariance cycle \(1,2,3,4,1\), with no diagonal chords, all occupations one half, and all four edges nonzero. Define the physical charge \(N_R=\sum_{j\in R}c_j^\dagger c_j\). The new observable is

\[
F_{1234}
=i\operatorname{Tr}\rho_R (N_R-2)[K_{23},K_{34}].
\tag{6}
\]

Charge commutes with the number-conserving modular operators, so this is a real expectation of a Hermitian observable. Applying (1), including the centering, gives

\[
F_{1234}
=i\operatorname{Tr}C_R(I-C_R)[k_{23},k_{34}]
=-i\operatorname{Tr}X_R^2[k_{23},k_{34}]
=2a_{23}a_{34}\operatorname{Im}W_{1234}.
\tag{7}
\]

For clarity, \([k_{23},k_{34}]_{24}
=a_{23}a_{34}C_{23}C_{34}\), with reverse entry the negative conjugate. In the trace against \(X_R^2\), the path through site 1 supplies \(W\); the other two-step path supplies a real quantity that cancels with its reverse. This proves the coefficient and sign without a numerical assumption.

The pair spectra determine the edge magnitudes and the \(a\)'s. The labelled four-site covariance spectrum determines \(\operatorname{Tr}X_R^4\), and

\[
\operatorname{Re}W_{1234}
=\frac{\operatorname{Tr}X_R^4
-2\sum_{\text{edges }e}r_e^4
-4\sum_{\text{adjacent edge pairs }e,f}r_e^2r_f^2}{8},
\quad r_e=|C_e|.
\tag{8}
\]

Thus (6), pair spectra and four-site spectra recover the complex four-cycle holonomy. For (3), (6) is 0.00328803907786; its opposite-flux partner has the negative value.

### Induced even cycles

The repair extends to an induced cycle \(1,\ldots,\ell,1\) of any even length \(\ell\ge4\). Let

\[
\mathcal D_\ell
=[K_{23},[K_{34},\ldots,[K_{\ell-2,\ell-1},K_{\ell-1,\ell}]\ldots]]
\]

be right nested, and \(W_\ell=C_{12}\cdots C_{\ell-1,\ell}C_{\ell1}\). Then

\[
F_\ell=i\langle(N_R-\ell/2)\mathcal D_\ell\rangle
=2\left(\prod_{j=2}^{\ell-1}a_{j,j+1}\right)\operatorname{Im}W_\ell.
\tag{9}
\]

Proof: nested commutators of quadratic number-conserving operators remain quadratic. Their one-particle matrix is the directed path \(2\to\ell\) minus its adjoint, with coefficient \(\prod a_{j,j+1}\). The Wick identity again replaces centered charge by \(C(I-C)=I/4-X^2\). For \(\ell>4\), the only two-step closure from \(\ell\) to 2 in the induced cycle passes through1. For \(\ell=4\), the extra reverse-backtracking term cancels. This proves (9).

Let \(A_{\rm abs}\) be the cycle matrix with positive edge magnitudes \(r_e\). Closed walks of length \(\ell\) either wind once around the cycle or have zero winding. The latter have the same weight for \(X\) and \(A_{\rm abs}\), so

\[
\operatorname{Re}W_\ell
=\prod_e r_e+
\frac{\operatorname{Tr}X^\ell-\operatorname{Tr}A_{\rm abs}^{\,\ell}}{2\ell}.
\tag{10}
\]

The labelled cycle covariance spectrum supplies the first trace, and edge magnitudes supply the second.

For comparison, the stronger one-particle-only interface also admits the path formula

\[
i\operatorname{Tr}C(P-P^\dagger)
=-2\left(\prod_{j=1}^{\ell-1}a_{j,j+1}\right)\operatorname{Im}W_\ell,
\quad P=k_{12}k_{23}\cdots k_{\ell-1,\ell}.
\]

It has the same acquisition problem as (4); it is not a substitute for the genuine charge observable.

### Gauge reconstruction and its cost

Edge magnitudes and all oriented cycle products determine a connected covariance matrix up to diagonal onsite \(U(1)\). Choose a spanning-tree gauge with positive tree edges; each remaining edge phase is fixed by the associated cycle product. This part is established prior mathematics, not a novelty claim.

All induced cycles suffice: any cycle with a chord is the oriented integer sum of smaller cycles, recursively reducing to induced ones. On a general bipartite graph these are even, so (9)–(10) recover all needed phases. The number of induced cycles can be exponential, and their lengths can grow. There is no general efficient acquisition theorem here.

On a finite rectangular square grid, the oriented faces form an integer cycle-lattice basis. Every face is an induced four-cycle. Consequently all edge magnitudes, labelled face covariance spectra, and one observable (6) per face recover \(C\) up to onsite gauge, using \(O(|V|)\) bounded-region invariants. Holes or periodic boundaries require extra oriented loop data.

The exact query count is not an efficiency advantage over an equally informed comparator. If four-site covariance tomography is supplied, ordinary two-point tomography already obtains every sparse covariance edge in \(O(|V|)\) local measurements. If modular observables are available as a separate service, their construction and execution must be charged. The signal in (7) is fourth order in uniformly weak edges; no shot-cost, compiled measurement protocol, interaction-stability theorem, or thermodynamic inference guarantee is established.

## 4. Precision boundaries and inverse dynamics

### The root-spoke promise cannot have a uniform floor

If \(\nu I\le C\le(1-\nu)I\), then \(C-C^2\ge\nu(1-\nu)I\). For occupation \(d_1=C_{11}\),

\[
\sum_{j\ne1}|C_{1j}|^2
=d_1(1-d_1)-(C-C^2)_{11}
\le(1/2-\nu)^2.
\]

Thus \(m-1\) root spokes all of magnitude at least \(s\) require
\(s\le(1/2-\nu)/\sqrt{m-1}\). The attached reconstruction's divisions by pairs of root spokes cannot have a size-independent conditioning constant under a fixed spectral margin.

Bounded-degree covariance graphs permit constant edge magnitudes and avoid this specific star obstruction. They do not remove global phase conditioning.

### A grid obstruction even after the charge repair

Take an \(L\)-by-\(L\) array of square cells. Let \(C_0=I/2+tA_0\), where every nearest-neighbor edge has value \(t\), with fixed \(0<t<1/8\). For \(C_\delta\), give a vertical edge in column \(x\) phase \(x\delta\), and horizontal edges phase zero. Every face has flux \(\delta\). Fix \(0<\alpha<\pi\) and choose \(\delta=\alpha/L^2\).

Both matrices satisfy a size-independent spectral margin because the maximum degree is4 and \(\|C-I/2\|\le4t\). All pair spectra agree. Each four-site face can be independently gauged so only one edge carries phase \(\delta\); hence its covariance eigenvalues differ from those of the zero-flux face by at most \(t|e^{i\delta}-1|\). Each charge probe differs by \(2a^2t^4\sin\delta\). The maximum local data error is therefore \(O(L^{-2})\).

But the product of edge phases around the outer boundary is \(e^{i\alpha}\), and is unchanged by every global onsite gauge. If every boundary covariance edge differs by at most \(\epsilon\) from \(C_0\) after any such gauge, telescoping unit-modulus products yields

\[
|e^{i\alpha}-1|\le4L\epsilon/t,\qquad
\epsilon\ge\frac{t|e^{i\alpha}-1|}{4L}.
\]

Thus no system-size-independent Lipschitz inverse exists from maximum errors in these bounded-region invariants to maximum covariance-edge errors modulo gauge. This result leaves weaker continuity moduli, additional long-loop measurements, and geometry-dependent precision bounds open.

### Static reconstruction is not physical inverse dynamics

A static faithful Gaussian covariance determines the modular one-particle matrix \(f(C)\). It does not identify a physical Hamiltonian. Every number-conserving quadratic Hamiltonian \(Q(h)\) with \([h,C]=0\) leaves the same state stationary; the completely mixed covariance is stationary for all such Hamiltonians. A known Gibbs promise with known inverse temperature would give \(h=\beta^{-1}f(C)\), but that promise and the time scale are additional inputs.

With time-resolved data, \(i\dot C=[h,C]\) identifies off-diagonal entries only across unequal covariance eigenvalues; the commutant and small-gap conditioning remain. No inverse-dynamics result is acquired here.

## 5. A finite counterexample to complete conditional photon-number entropy

Write \(g(n)=(n+1)\log(n+1)-n\log n\), using natural logarithms and vacuum covariance \(I/2\). The tempting complete version of family 273 would assert, for \(I(A:B\mid M)=0\),

\[
S(C\mid M)\ge
g\!\left(\eta g^{-1}(S(A\mid M))
+(1-\eta)g^{-1}(S(B\mid M))\right).
\tag{11}
\]

The following construction satisfies its domain restrictions and falsifies it.

Take a two-mode Gaussian state on input \(A\) and memory \(M\), with

\[
V_{AM}=
\begin{pmatrix}
160I_2&\sqrt{25536}\,Z\\
\sqrt{25536}\,Z&160I_2
\end{pmatrix},\qquad Z=\operatorname{diag}(1,-1).
\]

Its symplectic eigenvalues are 8,8, so it is faithful and physical. Each marginal has mean photon number \(159.5\). Let \(B\) be an independent thermal mode with mean photon number 1, and mix \(A,B\) at a beam splitter of transmissivity \(\eta=1/2\). The total state factors as \(\rho_{AM}\otimes\tau_B\), so \(I(A:B\mid M)=0\). All energies are finite.

The retained output-memory covariance has diagonal blocks \(80.75I_2,160I_2\) and cross block \(\sqrt{12768}\,Z\). Its symplectic eigenvalues are exactly

\[
\nu_\pm=\frac{\sqrt{110217}\pm317}{8}.
\]

Therefore

\[
S(A\mid M)=2g(7.5)-g(159.5)=0.0824072836777\ldots>0,
\]

\[
S(C\mid M)=g(\nu_--1/2)+g(\nu_+-1/2)-g(159.5)
=0.9365709487115\ldots.
\]

Since \(S(B\mid M)=g(1)\), the right side of (11) is approximately 0.963533160617. The actual violation is approximately 0.02696221 nats.

The checker supplies an exact rational certificate, rather than relying on these decimals. It encloses logarithms by a 90-term atanh series with a rational remainder and encloses \(\sqrt{110217}\) between
\(331989457663/10^9\) and \(331989457664/10^9\). It proves

\[
g^{-1}(S(A\mid M))>2/125,
\]

\[
S(C\mid M)<0.936570948716,\qquad
g((2/125+1)/2)>0.963517784888,
\]

and hence a strict violation greater than 0.0269.

The unconditioned inputs are both thermal, with photon numbers 159.5 and1. Their unconditioned output is thermal with photon number 80.25. Thus the unconditioned entropy photon-number inequality is actually an equality in this example. Family273 is not contradicted.

The already existing conditional exponential quantum EPI uses \(e^{S(\cdot\mid M)}\), not \(g^{-1}(S(\cdot\mid M))\). De Palma–Trevisan's primary manuscript states that conditional exponential inequality under conditional independence and gives Gaussian memory saturation constructions. Its entropy scale explains why a stronger photon-number interpolation need not survive quantum memory. This counterexample rules out the straightforward complete photon-number envelope and the same purported conditional entropy-dependent Jensen-gap consequence. It does not rule out the ordinary \(e^{-t}\) complete relative-entropy contraction, other state-restricted refinements, or the unconditioned envelope. [Primary conditional qEPI and Gaussian saturation](https://arxiv.org/html/1706.00440v2).

## 6. What the selected release manuscripts actually support

The initial routing covered the titles/categories of 73 families: 29 Probability and statistical mechanics, 25 Mathematical physics, 19 Operator algebras. The completed breadth follow-up read all 73 catalogue overviews and all current assessment fields; section 8 records the changed priorities. This is not 73 full manuscript reads.

* **273, entropy photon-number inequality:** read the introduction lines1–190 and all 429 lines of the minimization section. The source has independent finite-energy bosonic ports, an entropy-constrained thermal optimum, fourth-moment regularization, stationarity, and a constrained component BKM/Hessian inequality. Its constrained Hessian does not supply a universal inequality for arbitrary states with arbitrary quantum memory. The unbounded closure and all remaining proof sections were not independently checked. The prior cycle19 report itself retains a missing independent unbounded closure gate.
* **276, generalized amplitude damping:** read all of block.tex, output.tex and partners.tex. The block mechanism is a noncommutative entropy triangle. The partner-branch lemma gives an arbitrary finite channel partner bound, and the ensemble argument gives strong Holevo and minimum-output additivity. This is substantial source capital that had only an overview assessment in the checkpoint. Its branch/ensemble inequality is not (11), and cannot repair the counterexample. The thermal-block proof, other source sections and any infinite-dimensional approximation were not read or reconstructed here; the full capacity theorem is not promoted to an independently proved result.
* **289, Kadison–Kastler stability:** read its whole introductory interface. The metric is a two-sided norm gap between represented operator-algebra unit balls; the conclusion is a near-identity implementing unitary. It does not supply a distinguished state or modular data. In the blind-spot example the represented full Fock algebra is literally the same algebra for both states, so its KK distance is zero while the onsite-gauge cycle invariant differs. Algebra stability cannot reconstruct the missing state observable.
* **290, bounded modular spectral recovery:** read its whole introductory interface. The bounded recovery requires a scalar centralizer, \(M_\varphi=\mathbb C\), and concerns pointwise modular averages. A faithful state on a finite matrix algebra of dimension greater than1 has a nonscalar centralizer (at least its spectral diagonal algebra, or the whole algebra in the tracial case). It also supplies no uniform acquisition rate. This mechanism does not close the finite Gaussian tomography or physical inverse-dynamics gate.
* **Probability families:** the completed breadth pass read the critical SK introduction and the Thorp introduction/eight-block Fourier proposition, as recorded in section 8. Their whole manuscript proofs remain unread. The remaining probability overviews and peer assessments do not by themselves acquire a finite target sampler or entropy oracle.

The root cycle19 report was reread in full. Its exact Volterra/scalar-grid and commuting-repetition results retain their existing scope. Its own report describes the collision theorem as imported and unaudited; this pass supplies no revised verdict on that theorem.

## 7. Prior-art boundary and verification record

[Kim–Shi–Kato–Albert](https://arxiv.org/html/2110.10400) establish ordinary modular commutator properties, including local-unitary invariance, conjugation oddness and vanishing for exact Markov chains. The selected sections were read; no global topological theorem was adopted.

[Fan–Zhang–Gu](https://arxiv.org/html/2211.04510) already discuss Gaussian modular calculations and charge-enriched entanglement probes. Adding charge to modular diagnostics is not itself a novelty claim. Their preliminaries and selected free-fermion/probe passages were inspected; the complete manuscript was not read.

[Chien–Waldron](https://arxiv.org/html/1312.5393) identify Bargmann cycle products as the data determining projective/gauge equivalence; their cycle example shows that triangle information need not recover a longer chordless loop. The spanning-tree/cycle recovery is established prior art. The potentially distinctive element here is the precise genuine many-body extraction formula (9), together with its pure-modular obstruction and grid precision counterexample. A bounded primary-source search did not settle priority. Historical novelty remains UNKNOWN.

The new elementary arguments above are written derivations. There has been no external review, formal kernel execution, or full release-proof certification. The accompanying checker has two evidence scopes:

* An exact-rational logarithm/square-root certificate for the finite quantum-memory entropy violation.
* NumPy diagnostics for the four-mode covariance and 16-dimensional Fock state: all 15 nonempty CAR region spectra, all 225 ordinary modular pairs, Jordan–Lie sign, Wick cancellation, the charge observable, and particle–hole unitary symmetry. Maximum ordinary \(J\) magnitude was \(3.6\times10^{-17}\); the density-unitary residual was \(3.6\times10^{-16}\).
* Additional one-particle/Wick-form diagnostics on nonuniform induced even cycles of lengths 4,6,8,10 confirm the nested coefficient and spectral real-part formula. They are not additional physical measurement demonstrations.

An initial checker invocation failed because SciPy was absent; the Hermitian exponential was replaced by NumPy eigendecomposition and rerun successfully. No package installation, source mutation or delegated worker was used.

Artifacts:
[checker](frontier_physics/checks.py),
[check results](frontier_physics/check_results.json),
[literal read depths](frontier_physics_read_depths.json).

The decisive next positive gate is a concrete, charged implementation of the charge observables with a specified noisy-data model and a geometry-dependent inverse guarantee, compared against equally informed local covariance tomography. The decisive entropy gate is an actually valid restricted quantum-memory refinement; the straightforward complete photon-number formula is now excluded.

## 8. Completed breadth pass and a second reusable mechanism

The follow-up fully read the remaining 54 catalogue entries, completing **all 73 overview statements and links** in the assigned categories. It also read all current family assessment fields: 84 rows covering those 73 IDs. Nine of the ten relevant assessment files still matched the frozen coverage aggregate. The current frontier_crossfield record for 265 had changed; its live replacement was read, preserving the distinction between supplied ground vectors and acquired PEPS tensors.

This changes the routing, rather than the proof status of the other 69 families.

### Exactification from a uniquely verified output and its decoded success mass

Family 279 deserves reopening beyond an exact factoring headline. Its entire exactness section was read, including dyadic completion, deferred tests, known-quarter preparation and the final reflection. The useful extracted theorem is the following conditional compiler. The upstream order trial, factoring controller and primality proof were not audited, so the global factoring theorem remains unadopted here.

For every admitted classical input \(x\), assume:

1. There is exactly one accepted string \(w_x\in\{0,1\}^{W}\), recognized by a total polynomial-time deterministic verifier \(V(x,w)\). The width \(W=W(|x|)\) is polynomially bounded and known.
2. A supplied polynomial-time uniform polynomial-size **unitary circuit** \(A_x\) produces \(w_x\) with probability \(p_x\ge1/2\), after applying the verifier to its output. Its circuit and inverse are available. Merely possessing classical samples from it is insufficient.
3. The probability is exactly \(p_x=P_x/2^B\), with a known polynomial bound on the actual denominator exponent \(B\), not merely a short description of an exponentially long denominator.
4. A charged total polynomial-time classical decoder, on the verified string \(w_x\), returns \(P_x\). On invalid strings it can return anything within its fixed resource cap. The correctness promise on accepted strings is exact; estimated success frequencies do not satisfy it.
5. The fixed finite gate set contains exact Hadamard, NOT, CNOT and Toffoli operations, supports the gates used by \(A_x\), and can exactly implement their inverses. The source's stated finite gate set, with \(S=\operatorname{diag}(1,i)\) and controlled versions, satisfies this contract. No arbitrary-angle rotation is assumed.

Then a uniform polynomial-size circuit over that fixed gate set outputs \(w_x\) with probability one. All verifier, decoder, arithmetic, coin registers and work costs are included.

Here is the construction with actual finite denominators. Put

\[
E=W+3,\qquad
K=\left\lfloor\frac{2^{E-1+B}}{P_x}\right\rfloor,\qquad
D=2^{B+E-1}-P_xK.
\tag{12}
\]

The inequality \(1/2\le p_x\le1\) gives \(0\le K\le2^E\). Integer division gives \(0\le D<P_x\le2^B\). Define

\[
C=K/2^E,\qquad q=D/2^{B+3}.
\tag{13}
\]

These are valid dyadic coin probabilities, with \(q<1/8\). Their registers have precisely \(W+3\) and \(B+3\) bits. The arithmetic uses integers of \(O(W+B)\) bits. The endpoint \(p_x=1/2\) permits \(K=2^E\), so the threshold integer needs \(E+1\) bits; it represents an always-accept ordinary coin, not overflow.

Prepare a fair branch bit. In its ordinary branch select the output of \(A_x\); in its guessing branch select an independent uniform \(W\)-bit string. Require verification in both branches. On a verified selected output, evaluate the decoder and (12). Accept the ordinary branch when an independent \(E\)-bit uniform integer is below \(K\), and accept the guessing branch when an independent \((B+3)\)-bit uniform integer is below \(D\).

Both branches use the same true \(P_x\), because every verified selected output is the unique string \(w_x\). No decoder is assumed available before that string has been generated. The total flagged mass is

\[
\frac12p_x\frac K{2^E}
+\frac12\,2^{-W}\frac D{2^{B+3}}
=\frac{P_xK+D}{2^{B+E+1}}
=\frac14.
\tag{14}
\]

The exponentially rare guess is never repeated until success. It supplies only the residual rounding mass, also exponentially small. Thus it adds polynomial coin and arithmetic costs, not exponential runtime.

The circuit implementation avoids a hidden controlled-subroutine requirement. Run \(A_x\) unconditionally, prepare the independent uniform guess and both coin registers, and use reversible Toffoli/CNOT selection to put the branch-selected computational-basis output into a new register. Keep both original output registers, the branch bit, every coin, and all quantum work. Selection is a reversible operation on basis labels; it does not clone an arbitrary unknown quantum state. The verifier and mass decoder are computed coherently by reversible classical circuits with fixed polynomial caps. No intermediate outcome is selected or discarded, and there is no postselection.

Let the resulting unitary preparation be \(U_x\), let \(\psi=U_x|0\rangle\), and let \(\Pi\) be its success-flag projector. Equation (14) gives \(\|\Pi\psi\|^2=1/4\). The exact two-reflection identity is

\[
(2|\psi\rangle\langle\psi|-I)(I-2\Pi)\psi=2\Pi\psi.
\tag{15}
\]

The right side has norm one and only output \(w_x\). The success reflection is a phase on one bit. The other reflection is \(U_x(2|0\rangle\langle0|-I)U_x^{-1}\), where the zero test includes **all retained noninput registers**. Multi-control signs use reversible conjunction and phase kickback on an exactly prepared \(|-\rangle\), or \(S^2\); their scratch registers are restored. A global sign choice is irrelevant. The whole algorithm uses two forward preparations and one inverse. It introduces no recursively nested amplification and leaves arbitrary final junk without affecting the exact output.

If \(p_x\)'s denominator exponent is smaller than \(B\), the decoder pads its numerator by a power of two. It is essential not to infer dyadic probabilities from an arbitrary controlled-Hadamard circuit: interference between paths with differing Hadamard counts can give nondyadic probabilities. The dyadic promise is explicit. For circuits with only uncontrolled Hadamards and reversible/phase gates, a common polynomial denominator follows from their fixed Hadamard count, but computing its numerator remains a separate problem.

There is also a compact padded form, independently checked by root. Pad the unique output and guessing width to \(W\ge B\), then set

\[
k=\lfloor 2^{W-1}/p_x\rfloor,\qquad
l=2^{2W-1}-2^Wp_xk.
\]

Both integers are computable from the verified output; \(l\) is integral because \(2^Wp_x\) is integral. Ordinary and guess retentions \(k/2^W,l/2^W\) again give total mass \(1/4\). The unpadded form (12) records a smaller explicit guess-retention denominator when the original output width and probability precision differ.

This is an extraction of source 279's completion mechanism, not an independent proof of exact factoring and not a claim that the compiler is historically new. [Jordan–Kobayashi–Nagaj–Nishimura (2012)](https://www.rintonpress.com/xxqic12/qic-12-56/0461-0471.pdf) already achieve perfect QCMA completeness through additive finite-gate probability adjustment with a probability description supplied in the classical witness. Their introduction, model and proof setup were inspected. [Brassard–Høyer–Mosca–Tapp](https://arxiv.org/abs/quant-ph/0005055) supply established amplitude amplification. The potentially useful acquisition distinction is that the decoder here receives only a generated, uniquely verified output. Neither older supplied probability descriptions nor this compiler acquire such a decoder for a general inference problem. Precise priority remains UNKNOWN; no unique post-release capability is claimed.

The new [exact arithmetic checker](frontier_physics/exactification_checks.py) passed 8264 cases spanning widths 1–8 and denominator exponents 1–10, including \(p=1/2,1\). A concrete reversible toy has \(p=3/4\), one-bit unique output zero, \(K=10,D=2\), ordinary retention \(5/8\), and guess retention \(1/16\). Thirty ordinary and two guess histories among 128 uniform histories are flagged; the exact reflection eliminates every unflagged coefficient. These checks verify the finite arithmetic and toy construction, not a general acquired decoder or the global factoring theorem. [Results](frontier_physics/exactification_check_results.json).

### Other ranking changes from the actual statements and records

* **227, critical SK dynamics, reopened as a concrete sampling audit.** Its whole introduction was read. The source theorem is worst-start TV mixing \(n^{2/3+o(1)}\) with rate one per site, exactly \(n^{5/3+o(1)}\) attempted random-site updates, in probability over zero-field Gaussian disorder, at \(\beta=1\). The same exponent applies to the relaxation time and inverse classical logarithmic Sobolev constant. It is stronger sampling access than a rate-free pressure identity. It is not an all-instance bound, an external-field theorem, a finite-size certificate, or a zero-temperature optimizer. The \(o(1)\) means every fixed exponent slack, not an acquired uniform error bar. The source's observation-dependent spherical/Gaussian comparison is a promising entropy mechanism; the global proof remains unread and unadopted.
* **238, Thorp shuffle, reopened for its marginal-to-Fourier mechanism.** Read its whole introduction and the whole eight-block Fourier proposition/proof. The stated shuffle mixes a dyadic deck after 1600\(d\) full layers asymptotically, using \(O(n\log n)\) fair bits. Its useful primitive is a common trimming of eight complementary coset marginals, followed by \(\|\widehat\nu(\rho)\|\le A(\dim\rho)^{-5/16}\), preserving arbitrary representation multiplicities via a single vector's orbit span. The complete contraction/mixing proof was not read. Uniform permutation sampling already has elementary comparators; the opportunity concerns constrained shuffle layers and this transfer, not a general new sampling service. Parity must still be handled: uniform even permutations and uniform odd permutations have identical marginals on any at most \(n-2\) labelled cards but disjoint full supports.
* **267 and271, bosonic/ferromagnetic conditional algebra, restored to the capital inventory.** Their current peer assessments record full selected manuscripts and exact conditional normalizer/Schur first-moment constructions. They retain outside-equilibrium-marginal, whole-factor/collision-service or conditional-permutation acquisition obligations, and no physical real-time sampler was acquired. This pass read those assessment fields, not their primary proofs; their work should not disappear merely because the earlier root report emphasized other branches.
* **262, matrix Lieb–Thirring rigidity, retained as a meaningful reserve.** The actual overview has a matrix-size-independent sharp constant and equality cases in one constant unitary basis. A quantitative near-equality theorem could matter for matrix inverse problems, but neither stability nor an effective reconstruction is stated. No such theorem is inferred.
* **235, random-SAT, retained as a computability/cost audit.** The overview separates limiting threshold existence, sharp variance and computability, and explicitly credits concurrent prior threshold work. Computability does not imply a tractable precision runtime. The effective algorithm and primary proofs remain unread.
* **215–216,260–264,268–270 and280–282 remain major foundational claims with distinct interfaces.** Continuum/mass/scaling limits, spectral types, ground-state gaps, geometric rigidity and VOA/QFT equivalences do not alone supply finite-rate inference, state preparation or noisy modular recovery.
* **285–303 remain structural capital, with 300 specifically requiring an application gate.** The current paving assessment has a full selected proof and narrow derived controls, but retains qualitative locality and arbitrary-state cross-block compression debt. Similarity, factor classification, cohomology primitives, generator existence and absorption are not automatically finite algorithms. The original 289/290 nontransfers remain unchanged.

The breadth completion therefore adds a precise conditional exactification mechanism and reopens named finite sampling/Fourier audits. It leaves the charge reconstruction, pure-modular blindness and entropy counterexample unchanged. No new physical preparation, mass decoder, complete primary theorem validation or historical priority result has been manufactured.

