# Algebra / arithmetic / logic / groups: fresh opportunity sweep

Status: internally reconstructed universal permutation obstruction, explicit finite acquisition algorithm, and independent CAT(-1) geometry replacement. This is a research candidate with a complete written argument at the stated interface; no external review, formal kernel replay, or materialized incidence instance is claimed. Literature priority remains UNKNOWN. The strongest fresh combination joins **252's incidence/interpolation construction, support-rank perturbation estimates, and CAT(-1) geometry**: its finite-quotient obstruction extends to sofic approximations, and its underlying group has a finite two-dimensional CAT(-1) classifying complex. Family197 is a prior comparator, not an imported lemma needed for this derivation. The robust transfer is proved below rather than imported from the headline claims.

All 69 catalogue entries in Number theory (001–031), Algebra (193–210), Mathematical logic (240–245), and Group theory (246–259) were read. The explicit JSON ledger distinguishes this breadth reading from manuscript reading. The cycle19 coverage and report were used as current assessments, not proof adoption. The attached A–F research summary was read to exclude repeated tensor/PIT/discrepancy/quantum-compression leads. Previously selected 009, 020/021, 025/028, 200/206, 242, 247/250 and 251 mechanisms were not relabelled as new findings.

## Main new question and exact interface

Can the fixed-characteristic rank/interpolation certificate of family252 reject approximate permutation models, with one error tolerance valid for every permutation degree D? Yes, conditional only on explicit finite incidence/wiring data and the nontriviality of its rectangular words. The data can also be acquired by the explicit algorithm below; the geometric nontriviality is reconstructed with a different metric.

Pinned source: OpenAI, *A torsion-free hyperbolic group that is not residually finite*, September23,2026, commit `adc7f1241b42e322a6451854ab7e4b4c146bf78a`. The introduction explicitly leaves the common finite-residual element existential. The complete construction source was read, including its rank-reduction lemma, local factorizations, interpolation identity and link argument. The long original geometry proof was not adopted; only its closed-path proof excerpt was read. [Construction source](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/a-torsion-free-hyperbolic-group-that-is-not-residually-finite-September-23-2026/build/sections/construction.tex), [manuscript](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/a-torsion-free-hyperbolic-group-that-is-not-residually-finite-September-23-2026/paper.pdf).

Fix h=20, c=100^(-20), r=100/c=10^42 and a prime q>r. Put P=F_q^h and m=q^h. Choose N distinct marked points a_i in S^h, S⊂F_q, |S|=floor(q/100), and affine lines ell_i through their marks. Let I(z)={i:z∈ell_i\{a_i}}. Require:

* the punctured point/line incidence graph has no cycle of length at most12;
* outside a set E, |I(z)|≥4r²;
* Δ=Nr/4−2m−r|E|>0.

At each z outside E partition I(z) into two Cartesian blocks with sizes s_b t_b and s_b,t_b≥r. This is elementary: for d=|I(z)|≥4r² choose t∈[r,2r−1] with t≡d mod r, then d=r s+(r+1)t with s=(d−(r+1)t)/r≥r. Label each block bijectively by (α_b(i),β_b(i))∈Z/s_b×Z/t_b.

Use vertices O,V,W, edges X_iuv:V→W, L_buj:O→V, R_bvk:O→W and, for every block b, i in that block, and u,v∈[r], attach the triangle

    L_b,u,α_b(i)+v · X_iuv · R_b,v,β_b(i)+u^(-1).

Coordinates are cyclic. A maximal-tree collapse supplies a finite ordinary group presentation. Each nondegenerate rectangle is

    w_i,u,u',v,v' = X_iuv X_iu'v^(-1) X_iu'v' X_iuv'^(-1),
    u≠u', v≠v'.

## Quantitative rejection theorem for arbitrary permutations

Assign arbitrary permutations of D points to all edge loops. Let ε≥0 bound the normalized Hamming defect of every triangle, and suppose every nondegenerate rectangle has at most εD fixed points. No correction to a genuine action, no P-stability hypothesis, and no relation between q and D is used.

Let U denote a permutation matrix and set Y_i=(U(X_iuv))_(u,v), an rD×rD integer matrix. Every row has exactly r ones in disjoint column blocks. Writing T_i=Y_iY_i^T,

    tr T_i = r²D,
    tr T_i² ≤ [2r³−r² + r²(r−1)² ε]D.

The degenerate rectangles are exactly identities; the other traces count fixed points. Cauchy–Schwarz on the positive eigenvalues therefore gives

    rank_R Y_i ≥ r²D / [2r−1+(r−1)²ε].                 (1)

For any integer matrix A with row Euclidean norms at most√r, let d=rank_R A and choose a nonzero d×d minor B. Hadamard gives 1≤|det B|≤r^(d/2). If d'=rank_Fq B, subtract integer lifts of a modulo-q spanning row family from the other rows. The resulting d−d' rows are q-divisible, so q^(d−d') divides det B. Since q>r, d'≥d/2. Hence

    rank_Fq Y_i ≥ r²D / [2(2r−1+(r−1)²ε)].           (2)

This fixed-prime argument works even if q divides D. It is the essential integer/permutation restriction, not a generic matrix approximation lemma.

Set Z(z)=Σ_(i∈I(z))Y_i. At a regular point, the exact Cartesian wiring would factor each block sum as one block column times one block row, of inner dimension D. With triangle errors, each component difference U(X)−U(L)^(-1)U(R) has at most εD nonzero columns. Its rank is at most εD over every field. Embedding each difference in its matrix block and adding them gives

    rank_Fq Z(z) ≤ 2D+r²|I(z)|εD       (z outside E),
    rank_Fq Z(z) ≤ rD                 (z in E).     (3)

This bound uses support of the permutation error, not a conversion from a small analytic norm to rank.

Product Lagrange interpolation on S^h gives f_i(a_j)=δ_ij with total degree h(|S|−1). Let f=(f_i)_i and H(z)=f(z)f(z)^T. Then rank H(z)≤1, H(a_i)=E_ii, and every entry of H restricted to a line has degree at most2h(|S|−1)<q−1. Finite-field power sums, including the zero constant sum q=0, yield

    Σ_(z∈ell_i\{a_i}) H(z)=−E_ii.

Thus the following identity holds for arbitrary Y_i, even when every group relator has an error:

    − directsum_i Y_i = Σ_(z∈P) H(z)⊗Z(z).          (4)

Put S_reg=Σ_(z outside E)|I(z)|≤N(q−1). Taking ranks in(4), using(2),(3), and cancelling D gives

    N r²/[2(2r−1+(r−1)²ε)]
        ≤ 2m+r|E|+r²S_reg ε.                       (5)

The scalar function α(ε)=r²/[2(2r−1+(r−1)²ε)] satisfies

    α(ε) ≥ r/4−r²ε/8.

Indeed α(0)≥r/4 and α(0)−α(ε)≤r²(r−1)²ε/[2(2r−1)²]≤r²ε/8. Consequently(5) implies

    Δ ≤ r²(N/8+S_reg) ε.                           (6)

Therefore ε₀=min{1/2, Δ/[2r²(N/8+S_reg)]} rules out every such permutation assignment in every degree D. This is the reusable finite integral-to-modular rank certificate. A verifier needs the finite incidence/wiring/interpolation data and rational budget inequalities; its theorem has no uncharged finite-model-size parameter.

## From the finite rejection to the group conclusion

If all rectangles are nonidentity, soficity supplies edge permutations with triangle defects and rectangle fixed fractions tending to zero. One can use the standard finite-word definition: generator permutations evaluate all words, trivial words have Hamming length tending to zero, nontrivial words have length tending to one. The finite collection of triangle words and rectangles meets(6), contradicting ε<ε₀. Equivalently, a finite-set almost-homomorphism definition works with explicit inverse/prefix bookkeeping; the independent audit bounded the rectangle fixed fraction by8δ and each triangle defect byδ, so δ<ε₀/8 suffices. No general stability theorem enters.

More strongly, no homomorphism from this group to a sofic group can keep every rectangle nonidentity. If each rectangle survived in some sofic target, the finite product of those targets would be sofic and its product map would preserve all rectangles. This contradicts the same finite rejection. Hence one fixed rectangle lies in the intersection of kernels of all homomorphisms to all sofic groups. Its index is not identified. This is stronger than the source's common finite-quotient witness. The connected-core appendix below additionally constructs an explicit combined word in this common sofic residual, without identifying that rectangle's index.

## Independent geometry replacement

The source link wiring admits a simple alternative to its long Euclidean thinness proof. Give every triangle the same hyperbolic shape with angles

    angle(O)=27π/50, angle(V)=angle(W)=9π/50.

Their sum is9π/10<π, so this shape exists, and equal V,W angles give compatible L,R edge lengths. All X edges have the same third side length. Distinct cells embed and have isometric full-edge gluings.

At O each block link is a simple complete bipartite graph: prescribed u,v,j,k uniquely recover i from α(i)=j−v, β(i)=k−u. Every nonempty reduced cycle has≥4 edges and angular length≥108π/50>2π. At V the map taking X_iuv to line label i and L_buj to point z(b) is locally injective: uniqueness at X follows from disjoint blocks at one point, and uniqueness at L follows from s_b≥r. Therefore a reduced link cycle projects to a reduced incidence walk and has≥14 edges. The same holds at W using t_b≥r. These angular lengths are≥126π/50>2π.

A reduced path between distinct same-i X directions projects to a positive closed incidence walk with no internal reversals. Such a walk contains a simple cycle, even if its closing seam reverses, so it also has≥14 edges. Thus the turns of every rectangle have link distance≥126π/50>π.

The finite hyperbolic cell complex satisfies the metric link condition. Its universal cover is a complete CAT(-1) space by the polyhedral link criterion and Cartan–Hadamard; the finite-complex deck action is proper and cocompact. It follows that the fundamental group is word-hyperbolic. A nontrivial finite-order deck transformation would have a fixed point by the complete CAT(0) fixed-point theorem, contradicting freeness of the deck action, so the group is torsion-free. A nullhomotopic rectangle would lift to a closed positive-length local geodesic in the CAT(-1) universal cover; local geodesics there are global geodesics, an impossibility. Hence all rectangles are nonidentity. This reconstruction preserves the topological group while changing its metric. It was independently suggested and checked by corpus_provenance and then checked here.

Primary classical boundary: Bridson–Haefliger, *Metric Spaces of Non-Positive Curvature*, II.5.2/5.4 (finite-shape link criterion and simply connected globalization), II.1.4 (local geodesics), II.2.8 (fixed points), and III.H (CAT(-1) hyperbolicity). [ChapterII.5 primary text](https://webhomes.maths.ed.ac.uk/~v1ranick/papers/bridsonhaefligerx.pdf), [Bridson's author exposition](https://people.maths.ox.ac.uk/bridson/papers/bridsonicm.pdf). Standard CAT results are explicitly used, not recertified by the finite code.

The assembled written argument therefore supports a **torsion-free nonsofic group with a finite two-dimensional CAT(-1) classifying complex**, rather than importing family252's global claim. It remains an internally derived candidate pending external mathematical scrutiny and formal replay.

## Explicit acquisition and full cost boundary

The source says q is sufficiently large. Here is a specific choice and a finite Las Vegas acquisition proof. Set q=2^521−1. The exact code verifies exponent521 is prime by trial division and runs all519 Lucas–Lehmer iterations, obtaining final residue0. Thus q is a specific prime, not a probable-prime sample. It exceeds Q=64r²/c=64·10^124. [Lucas–Lehmer algorithm, GIMPS primary documentation](https://www.mersenne.org/various/math.php).

Let M₀=floor(q/100)^h. Since q≥200h, Bernoulli's inequality gives M₀≥cm/2. For each of these marks independently sample one uniform projective direction, from J=(q^h−1)/(q−1) possibilities. Every point has initial degree mean μ_z=(M₀−1_(z is a mark))/J≥cq/8≥8r². Chebyshev therefore gives

    E B ≤32m/(cq),

where B counts points of initial degree<4r². For a simple incidence cycle with s point vertices, 2≤s≤6, consecutive points fix geometric lines, at mostq choices of a mark lie on each line, and distinct labels have independent directions. Its expected count is≤m^s q^s/J^s≤q^(2s). If C is the total number of short simple cycles, then

    E C ≤5q^12.

Accept sampled outcomes satisfying B≤m/(4r) and C≤m/(24rq). Markov's inequality and a union bound give rejection probability at most

    128r/(cq)+120r/q^7 <1/2.

Delete every label on a short cycle, at most6C labels. Let E consist of the old B low-degree points plus all points on deleted lines. Then the remaining graph has girth>12, no surviving degree changes outside E, and

    |E|≤B+6qC≤m/(2r),
    N≥M₀−6C≥cm/2−m/(4rq)≥cm/4,
    Δ≥(cr/16−5/2)m=15m/4>0.

Thus the expected number of independent trials is≤2. This is an exact halting construction with bounded expected trials, but each trial is astronomical. To sample a uniform projective direction, sample uniformly from F_q^h excluding the zero vector and normalize the first nonzero coordinate to1. Every projective direction has exactly q−1 preimages. Field elements sampled by rejection from unbiased bits give expectedO(h log q) bits per direction; normalization has additional finite field cost. A literal acquisition enumerates the m points, materializes M₀(q−1) incidences, enumerates all cycles of lengths≤12, and deletes their labels. With V=m+M₀ and maximum degree Δ_graph≤max(M₀,q), a conservative deterministic cycle-enumeration cost is O(V Δ_graph^12) graph operations, with O(M₀ q h) field operations to build incidences. Each field operation is charged polynomial bit cost in log q. Storage includes O((m+M₀q)log(m+M₀)) bits for graph/indices. Choosing Cartesian bijections and checking wiring is additional finite work.

There is also a concrete tolerance independent of the sampled outcome. Since N≤cm and S_reg≤N(q−1), N/8+S_reg≤cmq. The acquired gap Δ≥15m/4 therefore gives ε₀≥15/(800rq). In particular **ε=1/(100rq)** is a valid universal rejection tolerance; finite-set sofic accuracy δ<1/(800rq) suffices.

The output complex has at most M₀r²+2M₀(q−1) edges and M₀r²(q−1) triangles. Emitting the ordinary finite presentation therefore already requires that many words/symbols and their encoded indices. For this concrete q, m has3137 decimal digits as a cardinality, M₀ has3097, the incidence-edge upper count has3254, and the triangle-relator upper count has3338. No line table, finite presentation, or actual certificate of this size was produced on the user's machine. The code checks prime/arithmetic/interface conventions only. This acquisition is mathematically effective and physically unusable at the stated parameters; a practical research primitive would require a vastly smaller incidence design.

## Prior-art discriminator and remaining combinations

The August *Ten Advances*, Chapter3, gives nonsoficity of the binary Leavitt unit group through property(T) and an expander-matching mechanism; it does not assert a hyperbolic group specialization. Its proof was read only at the chapter introduction and stated mechanism, not fully recertified. [Primary paper](https://cdn.openai.com/pdf/ten-proofs-oai.pdf). Kun–Thom, August20,2026v3, TheoremA, gives nonsofic wreath products and doubles under Kazhdan/infranormal hypotheses. Its introduction separately mentions a hyperbolic group with a nonsofic probability-measure-preserving action: that statement does not imply that the hyperbolic group itself is nonsofic. [Kun–Thom primary manuscript](https://arxiv.org/html/2608.06222v3). Chapman–Peled, September25,2025, proposes a conditional route to a nonsofic hyperbolic group via linear permutation cocycle stability of random complexes. [Primary abstract](https://arxiv.org/abs/2509.21566). The present finite-rank route requires no such stability premise. The bounded search found no earlier copy of this particular rank perturbation theorem; this is not an exhaustive priority certificate.

Family197's October4 torsion-free direct-finiteness companion claims a finite two-dimensional classifying complex and is nonsofic by the standard sofic-group-ring theorem. Its complete introduction and topology section were read. The cone criterion excludes reduced spherical arrangements, proves π₂=0/root protection, and derives asphericity and torsion-freeness; it supplies no CAT metric, linear filling bound, hyperbolicity assertion or word-problem algorithm in those files. Its probabilistic and algebra sections were not adopted. Its construction uses graph-cone cancellation/asphericity rather than this marked-line CAT(-1) rank certificate. [Primary introduction](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/A-Torsion-Free-Group-Algebra-That-Is-Not-Directly-Finite-October-4-2026/build/sections/introduction.tex), [topology source](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/A-Torsion-Free-Group-Algebra-That-Is-Not-Directly-Finite-October-4-2026/build/sections/topology.tex).

Other retained combinations:

* **252 + 250:** this hyperbolic group's word problem is decidable, so adopting250's separate effective embedding theorem would give a simple F∞ overgroup that is nonsofic. This is conditional on250's still-ungated algebra/action compiler. Nonsoficity with decidable word problem alone is not new: the earlier finitely generated Leavitt elementary-group construction already has exact ring-word evaluation. Our useful addition is the negative-curvature finite classifying complex, not a claim of first decidable-word-problem nonsoficity.
* **252 + 258:** adopting258's virtual compact specialness theorem would exclude every one-relator presentation of the constructed group, since virtually compact special groups are residually finite and therefore sofic. This is a compatibility consequence, not a new proof of258. The two258 introductions were read in excerpt, with the actual filling/Novikov/tower proof still unverified.
* **256 + 250:** nonsingular group equations give an embedding into a quotient, but do not supply a decidable word problem for that quotient. The Boone–Higman compiler's decidability premise therefore remains unacquired. Family256's simultaneous fixed-space theorem is a separate reusable topological primitive: signed block incidence of full rational row rank forces at leastΣk_i fixed directions for some unitary variable assignment. Its complete finite-dimensional proof was read, but an efficient or exact-bit acquisition of that assignment was not obtained.
* **243 + 009/206:** symmetry-invariant algebraic consistency/reconstruction may require an acquired canonical choice. The CPT separation warns against treating unordered input symmetry as cost-free canonicalization; the field/lattice prior gates already distinguish supplied globally compatible data from acquired data. This is a useful interface audit, not a new theorem.
* **242 + 004/245:** unique Diophantine witnesses and system-wide normalization do not give recursive resource bounds or an effective test of their global premises. This boundary was already explicit in cycle19, so it is retained as a negative control rather than promoted as a fresh lead.

## Adversarial boundaries and exact evidence

The argument concerns permutation approximations. Arbitrary unitary models cannot be substituted: e^(it)I−I has arbitrarily small normalized Hilbert–Schmidt norm but full rank, and rounding entries does not preserve the fixed-prime row budget. No nonhyperlinear conclusion follows.

Likewise, arbitrary finite-field or complex invertible matrices with rank-separated rectangles do not suffice. Let X_uv=(a_u+b_v)I_D with distinct a_u,b_v and all sums nonzero. Every nondegenerate rectangle differs from I by a nonzero scalar: its numerator difference is (a_u−a_u')(b_v'−b_v)≠0. Thus rank(I−rectangle)=D, but the full block matrix Y=(a_u+b_v)⊗I_D has rank≤2D for arbitrary r. The permutation trace/row-sparsity hypothesis is indispensable.

Independent agents corpus_provenance and hyperbolic_sofic reconstructed the perturbation estimates and found no dependence on D or missing repair premise; their reports are independent internal checks, not external validation. The former supplied the CAT(-1) angle replacement. Own exact check code is `work/frontier_algebra_checks.py`, with results in `work/frontier_algebra_checks.json`:1313 exhaustive small permutation arrays,120 sampled arrays,80 perturbed Cartesian block factorizations,32 interpolation line certificates,519 exact primality iterations,8 residual free words and36 leaf-kill controls. All passed. Negative controls retain the all-identity rectangle defect and generic-linear/Hilbert–Schmidt failures. These finite checks audit conventions and arithmetic, not the universal existence theorem or any local capability benchmark.

The first three boundary counterexamples are executed as exact controls: r=2,D=2 all-identity blocks have rank2 below the incorrectly defect-free bound8/3; the matrix3I₂ has real rank2 and rank0 over F₃ when the required row-budget/prime inequality is removed; and the scalar construction over F₃₇ with r=10 has8100 rank-separated rectangles but block rank2 below the false permutation lower bound50/19. The Hilbert–Schmidt boundary is a written analytic counterexample, not a numerical experiment.

Next decisive observation: an external hostile review of the standalone marked-line/CAT(-1)/robust-rank proof, plus a formalization of the finite rank certificate. For practical research use, find a compact explicit incidence system with the same positive rank gap; then actually emit and independently verify its presentation, rectangular words, and error threshold. The astronomical Las Vegas acquisition here closes effectivity but does not close practical acquisition.

## Connected core and the property(T) prospect

The original three-vertex complex has large built-in free factors. Let B denote its number of Cartesian blocks. Form K_core using vertices O_b (one per block), V_u (one per u∈[r]), and W_v (one per v∈[r]); let each X_iuv go from V_u to W_v, each L_buj go from O_b to V_u, and each R_bvk go from O_b to W_v. Every original triangle remains a valid triangle. K_core is connected: N>0 gives the complete bipartite X-edge graph on the V_u,W_v, and each O_b attaches to that graph.

Identifying the B vertices O_b, the r vertices V_u, and the r vertices W_v recovers the original complex. Identifying k distinct vertices of a connected CW complex adds a free factor F_(k−1), by adjoining a tree joining those points and contracting that tree. Consequently, with H=π₁(K_core),

    G ≅ H * F_(B+2r−3).

The geometry and rank certificate also apply directly to H. Its O_b link is one original O-link component, while its V_u and W_v links are the corresponding original components. The CAT(-1) link bounds survive. For algebraic bookkeeping choose one base path to every vertex: based edge loops still satisfy L·X=R, and their four-X rectangle products are conjugates of the genuine closed squares V_u,W_v,V_u',W_v'. Thus the same integer matrices, Cartesian factorizations and interpolation identity reject sofic approximations of H. This yields a connected finite two-dimensional CAT(-1) nonsofic core independently of any free-product closure theorem.

In particular the original G cannot have property(T), regardless of coordinate bijections. An explicit free quotient makes this visible: take free symbols e_b,a_u,b_v with e_b₀=a₁=b₁=1, and map

    L_buj↦e_b a_u,   X_iuv↦a_u^(-1)b_v,   R_bvk↦e_b b_v.

Every triangle relation cancels and the images generate F_(B+2r−3). Hence G has infinite abelianization; discrete property(T) groups have finite abelianization. [Bekka–de la Harpe–Valette, primary introduction](https://assets.cambridge.org/97805218/87205/excerpt/9780521887205_excerpt.pdf).

Property(T) for the core remains an unacquired stronger target. Its O_b links are complete bipartite graphs, with normalized Laplacian gap1. At V_u and W_v the coordinate bijections can change wiring, but they cannot repair a label with no regular incidences: its X direction is isolated in the link for every bijection. The accepted incidence criteria bound degrees outside E and |E|, but supply no minimum number of regular points on each surviving line, no connectivity of these individual links, and no spectral estimate. Thus random bijections alone are not currently a property(T) theorem. A productive additional lemma must control every V/W link after line/point trimming while preserving Δ>0; it must then prove normalized gap>1/2 and the applicability of the simplicial local spectral criterion. The primary criterion requires connected links and the strict spectral inequality, not high girth alone. [Ballmann–Świątkowski, Corollary1](https://archive.mpim-bonn.mpg.de/2255/1/preprint_1996_127.pdf). No such expansion or practical finite construction was proved here.

## Explicit word in the common sofic residual

The free factor can turn the finite joint obstruction into an individually selectable word. Fix a block b₀. Use the following spanning tree of K_core: L_b₀,u,0 for every u, R_b₀,v,0 for every v, and L_b,1,0 for every b≠b₀. It has exactly B+2r−1 edges, one less than the number of core vertices. In the original complex use the tree consisting of L_b₀,1,0 and R_b₀,1,0. After that collapse, t=L_b₀,2,0^(-1) is one free generator of the vertex-identification factor. Indeed adjoin a connecting edge a₂:V₁→V₂ before identifying vertices; its based loop is L_b₀,1,0 a₂ L_b₀,2,0^(-1), which becomes exactly t after contraction. The other identification edges give the remaining free generators, so this choice realizes the previous free-product splitting explicitly.

Enumerate all M=N r²(r−1)² nondegenerate rectangles in a fixed index order. If rectangle j starts at V_u, put

    h_j=L_b₀,u,0 w_j L_b₀,u,0^(-1).

This is the image of a genuine based loop in K_core, so h_j belongs to the embedded factor H; it is nonidentity by the link argument and has length at most6 in original edge generators. Every homomorphism G→a sofic group kills some h_j, because restriction to H and the same finite permutation certificate forbid simultaneous survival of all core rectangles.

Now work inside the embedded free product H*⟨t⟩. Its homomorphism to ⟨t⟩ killing H has kernel

    freeproduct_(k∈Z) t^k H t^(-k).

This identity follows directly by forming the semidirect product of the displayed free product with the integer shift of its factors; the maps sending the kth copy of h to t^k h t^(-k) and sending t to the shift are mutually inverse. Therefore the nontrivial elements u_j=t^j h_j t^(-j) lie in distinct free factors. Define

    W₁=u₁,             W_j=[W_(j−1),u_j]  (2≤j≤M).

Inductively W_(j−1) belongs to the free product of factors1 through j−1 and is nonidentity. Its commutator with u_j has four alternating nonidentity syllables between that subgroup and factor j, so W_j is nonidentity. Simultaneously W_j lies in each normal closure ⟨⟨h_k⟩⟩ for k≤j: a quotient killing either commutator entry kills the commutator. Thus **W_M is a specified nonidentity word killed by every homomorphism from G to every sofic group**. This removes the word-selection gap for a combined witness; it does not identify which single rectangle is in the common residual.

This word is acquired by an explicit finite algorithm once the incidence presentation is acquired. Its expanded length obeys L₁≤8 and L_j≤2L_(j−1)+4j+12, hence L_M≤16·2^M. A straight-line expression can store successive powers t^j, the h_j and their inverses, and successive commutators in O(M) nodes, or O(M(log M+log|Σ|)) encoded bits for the finite edge alphabet Σ. Expanding the word requires its exponential output length. Neither this straight-line expression for the astronomical acquired presentation nor its expansion was materialized. The finite code separately checks free-word commutator conventions and cancellation after deleting each leaf; the arbitrary-H normal-form proof remains the written mathematical justification.

## Further standard consequences and their scope

The CAT(-1) universal cover is contractible, so the finite two-dimensional complex is already a classifying space. Both G and H are of typeF, hence typeF∞, with geometric dimension at most2. Hyperbolicity supplies a deterministic linear-time word problem after the fixed group's finite Dehn algorithm has been compiled; this is a query-time statement whose constant includes that compiled data. Holt–Rees give the stronger real-time multi-tape formulation. [Primary theorem/abstract](https://wrap.warwick.ac.uk/id/eprint/812/1/WRAP_Holt_Solving_word_problem.pdf). No word-problem machine or its preprocessing was produced for the astronomically large presentation.

Both groups are exact and have propertyA, and their actions on their Gromov boundaries are topologically amenable. Apply Ozawa's Theorem1 to a finite-generator Cayley graph, which is a countable fine hyperbolic graph with finite quotient and trivial vertex stabilizers; its amenable compactification action restricts to the closed boundary. The introduction records exactness and its equivalence with propertyA. [Ozawa, primary manuscript](https://arxiv.org/pdf/math/0501555). These classical consequences do not require an additional theorem from the OpenAI release.

Consequently local negative curvature, typeF, propertyA, and a topologically amenable boundary action do not force soficity. More concretely, use the finite edge generating alphabet and permutation-labelled graphs with one incoming and outgoing edge of every generator colour. If radius4 rooted neighbourhoods agree with the group's coloured Cayley graph on a fraction at least1−1/(100rq) of their vertices, every triangle word is satisfied and every nonidentity rectangle is separated outside the same exceptional fraction, contradicting the certificate. Thus even this one finite local-law target has a positive universal rejection gap. The conclusion is about finite labelled permutation graphs; no cheap finite graph sampler or practical benchmark follows from the acquisition proof. Exact nonsoficity alone is not asserted as first in the literature; the discriminator here is the hyperbolic finite-classifying-space specialization.
