# Adversarial reconstruction: arbitrary commuting threshold repetition

Date: 2026-10-07. Source workspace was read only. No subagents were spawned.

## Verdict and exact scope

**Scoped internal PASS.** I reconstructed the operator dilation, weighted question exposure, component barycenter, disconnected-component drift, and scalar threshold transfer. I found no concrete counterexample or missing mathematical step on the stated interface. This is an independent mathematical reconstruction, not external validation or a proof-assistant certificate.

The checked statement is the following. For a finite two-player one-round game with a known classical question law, finite nonempty answer sets, Boolean acceptance, arbitrary Hilbert-space vector states and all-input cross-commuting POVMs, let v = omega^co(G) < 1, d = |A||B|, and sigma be the minimum positive resampling-chain gap over nonsingleton support components (convention 1 if all components are singletons). For every k >= 1, every joint commuting repetition strategy, and 0 < delta < 1-v,

    Pr[W_k >= ceil((v+delta)k)]
      <= exp(-sigma delta^3 k / (2048(1+log d))).

For connected support the denominator is 1024. Neither tensor decomposability of the original Alice/Bob representation, finite dimension, a trace, a density matrix, a purification theorem for bipartite states, measurable optimization selections, nor an attained optimum is used.

The allowed comparison class must remain **all commuting strategies on arbitrary enlarged Hilbert spaces**. The construction does not prove that the rounded strategy remains in a prescribed factor or representation, has finite memory, or can be efficiently prepared. It cannot replace omega^co with a potentially smaller finite tensor value. Historical novelty and external/formal validation remain unassessed by this audit.

## Read scope and provenance

All of the principal extension (632 lines) and root gate (28 lines) were read. The released operator, exposure, threshold, support-rounding, and marginal sections below were read in full; clipped tool output was repaired with explicit additional reads. The release metadata and Lean scope prose were also read. Existing peer-gate titles/stress-case locations were searched only after reconstructing the sensitive proof steps; their verdicts were not used as premises.

Source base: `/Users/harjas/Documents/ChatGPT/Literature Digestion/`.

| Source under that base | SHA-256 of bytes read |
| --- | --- |
| `notes/frontier_check_repetition/cycle19/COMMUTING_THRESHOLD_EXTENSION.md` | `b981050c5aebbc53b7004c359d25283cc0447cfa037b1dbae3908adeb9d419bc` |
| `notes/root_cycle19/COMMUTING_REPETITION_GATE.md` | `fee145b30a04187d3a08b9efd65b2ebb9bc54ffe769f501b618392a8df4e137c` |
| `sources/frontier_check_repetition/cycle19/release/build/sections/01-operators.tex` | `3ee22a7feae90ae082fa8ee7c06d948ec38842ec0da6dc240bf64091c91eb354` |
| `sources/frontier_check_repetition/cycle19/release/build/sections/02-exposure.tex` | `01a1f432c206e89458b43d1cbad3b13edbbe399e5d056c45a0d70de9a7c501db` |
| `sources/frontier_check_repetition/cycle19/release/build/sections/04-threshold.tex` | `cad8395c2a47d66e59110a9c3c3d6d0fcd91326c019ae507af93671a69c5f689` |
| `sources/frontier_check_repetition/cycle19/release/build/sections/05-root-support.tex` | `e39c02c77accf376849dbac57d9ed0fb1d78cd6340e4c3d600a55f01196bd1f5` |
| `sources/frontier_check_repetition/cycle19/release/build/sections/00b-marginals.tex` | `919a760af140aab147e888183df1a13d4f3457ec3782740fbcfff1c468ee74c9` |

The five released section hashes agree with the supplied retrieval metadata for commit `adc7f1241b42e322a6451854ab7e4b4c146bf78a`. This verifies local snapshot identity, not historical priority or an independent live provenance audit. The source URL for the decisive operator proof is:

https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Threshold-parallel-repetition-for-finite-dimensional-entangled-games-September-25-2026/build/sections/01-operators.tex

The released proof itself is explicitly finite tensor. Its finite common-span compression and bounded support inverse cannot simply be imported into the arbitrary commuting case. The extension supplies separate proofs of both replacements. The released Lean scope prose describes a universal finite-dimensional threshold exponent delta^13 and explicitly excludes the separate distribution-dependent cubic theorem. It supplies no formal certificate for this commuting extension.

## 1. Resolvents at zero spectrum: certified

Extension lines 85-148 contain the necessary infinite-dimensional repair. Write K = L2((0,infinity), ds). For a bounded positive T,

    (F_T h)(s) = T(T+sI)^(-1)h,
    (V_T h)(s) = sqrt(T)(T+sI)^(-1)h.

The spectral integrals give F_T*F_T = T and V_T*V_T = support(T). The latter integrand has scalar integral 1 for every positive spectral value and 0 at zero; consequently V_T is a bounded partial isometry even when T has no bounded inverse on its support. F_T = V_T sqrt(T). For each h, both functions are continuous on s > 0 and square-integrable, so their Bochner integrals are legitimate. No choice of eigenvectors is involved.

For a positive ensemble A_l with mean B, put D_l = A_l-B. After adding epsilon I, the second resolvent identity and sum q_l D_l = 0 give the Jensen-gap integrand

    s sum_l q_l (B+s)^(-1) D_l (A_l+s)^(-1) D_l (B+s)^(-1).

The Gram integrand of F_A_l-F_B is identical with the middle factor s(A_l+s)^(-1) replaced by s^2(A_l+s)^(-2). The scalar spectral inequality

    s(A_l+s)^(-2) <= (A_l+s)^(-1)

and congruence therefore prove Gram <= Jensen gap. At fixed epsilon the integrals converge in operator norm: near zero all inverses are bounded and at infinity the final integrands are O(s^-2).

The zero-spectrum limit is genuinely in operator norm. For every scalar t >= 0,

    integral |(t+epsilon)/(t+epsilon+s)-t/(t+s)|^2 ds
      = epsilon^2 integral s^2/((t+epsilon+s)^2(t+s)^2) ds
      <= epsilon.

Functional calculus yields ||F_(T+epsilon I)-F_T|| <= sqrt(epsilon). Each difference Gram therefore converges in norm, as does t log t under continuous functional calculus on a common bounded interval. The final operator inequality is valid without finite rank or a positive lower spectral bound.

One optional additional reduction addresses nonseparable ambient Hilbert spaces: at any finite repetition length there are only finitely many POVM effects. The closure of their finite words applied to psi is separable and reducing, since the effects are self-adjoint. Restricting to this space preserves the strategy. The proof does not need this reduction, but it also precludes a nonseparability-based measurability objection.

## 2. Transport stays in the local von Neumann algebra: certified

Extension lines 150-224. Suppose 0 <= G_a <= T and sum_a G_a = T in a von Neumann algebra A. On ran sqrt(T), define

    q_a(sqrt(T)u, sqrt(T)v) = <u,G_a v>.

The form is well-defined because ker T is contained in ker G_a. Its bound follows from the positive-form Cauchy-Schwarz inequality and G_a <= T:

    |<u,G_a v>| <= sqrt(<u,G_a u><v,G_a v>)
                  <= ||sqrt(T)u|| ||sqrt(T)v||.

It yields a unique positive contraction C_a on the support p_T with

    G_a = sqrt(T) C_a sqrt(T),  sum_a C_a = p_T.

This is a bounded form construction, not an application of an everywhere-defined unbounded inverse. The bounded regularizations

    (T+epsilon I)^(-1/2) G_a (T+epsilon I)^(-1/2)
      = R_epsilon C_a R_epsilon,
    R_epsilon = sqrt(T)(T+epsilon I)^(-1/2),

belong to A and converge strongly to C_a because R_epsilon -> p_T strongly. Hence C_a is in A. Strong closure is sufficient; norm convergence is neither asserted nor needed.

The completed transported POVM is

    Q_a = V_T C_a V_T* + 1_(a=a_*)(I-V_T V_T*).

Its positivity, completeness and exact pullback F_T*Q_aF_T = G_a follow directly. Every D in A' intertwines V_T with I_K tensor D; its adjoint does likewise. Thus Q_a commutes with I_K tensor A'. Equivalently its scalar-ancilla matrix coefficients lie in A, so Q_a is in B(K) bar-tensor A. This step uses the type-I scalar **ancilla**, which is explicitly allowed, and imposes no type-I hypothesis on A.

If Alice and Bob originally have commuting A and B, give them different scalar factors K_s and K_t. Alice's transported effects have coefficients in A and act on s; Bob's have coefficients in B and act on t. Their amplified algebras commute for every input pair. No identification A tensor B = B(H), or spatial Alice/Bob factorization of H, occurs.

Let J_T = F_T and let the lift of F_S into the t register be denoted J_S. Set Psi_TS = J_S J_T psi. Since all original coefficients commute,

    ||Psi_TS||^2 = <psi,TS psi>,
    (J_S J_T)* Q_a R_b (J_S J_T)
      = J_T* Q_a (I_s tensor K_b) J_T
      = G_a K_b.

The first pullback uses Bob's identity and J_S Q_a = Q_a J_S; the second uses Alice's identity and J_T K_b = (I_s tensor K_b) J_T. This verifies the **joint** answer law, not only its marginals. T = 0 or S = 0 gives a zero vector and deterministic completion on the relevant null range.

## 3. Weighted exposure and entropy: certified

Extension lines 226-334 and released 02-exposure.tex. The flags Omega_j are formed under the unconditioned product-of-pairs question law. Each live coordinate fixes exactly one local input; across coordinates the remaining mates are independent. At tested coordinates both inputs are fixed. Consequently the full Alice and Bob question strings are conditionally independent before any answer postselection. This is enough to factor the average of a joint operator product, since its two factors depend on disjoint residual random strings.

In a mode i, r0 excludes the fresh pair. The coarse averages F_x,H_y are effects in A,B respectively, and the local averages are F_y = E_(x|y) F_x and H_x = E_(y|x) H_y. With r = (r0,alpha,gamma), define w_i(r) = nu_i(r0) theta(r). These weights intentionally need not sum to 1. Exact pullback gives the tested coarse mass ||f_ir(x,y)||^2 and fine answer mass <psi,G_x^(alpha,a) K_y^(gamma,b) psi>. The conditional law is exactly

    w_i(r) mu(x,y) ||f_ir(x,y)||^2 / p,

where p = Pr(E_C). Treating w_i as a probability would break the proof, but the extension does not do so. Zero conditional weights are omitted; null coarse vectors and theta = 0 have no conditional mass.

For B >= 0 in Bob's algebra, the Alice functional phi_B(A) = <psi,AB psi> is positive, since it is the vector functional of sqrt(B)psi. If its mass is g <= 1 and h = phi_B(F), scalar Jensen applied to the spectral measure of F gives

    -phi_B(F log F) <= h log(g/h) <= -h log h.

At h = 0 this is its continuous value 0; at g = 0 the functional vanishes. Thus neither a trace nor von Neumann entropy is involved. Jensen across the d^|C| answer pairs and all flags bounds each potential in [-p log(d^|C|/p),0]. The mask theta is binary, so replacing h by theta h is exact.

The two potential increments are exactly the operator Jensen gaps for F_x at fixed y and H_y at fixed x. The common resolvent coordinates express the two squared vector errors as these Grams evaluated against the corresponding positive functional. Summing the increments over the fixed ordering costs at most pL per side, L = log(d^|C|/p). For w_ir = w_i(r)/m, this proves

    sum_ir,z w_ir mu(z)||f_ir(z)||^2 = p,
    sum_ir,z w_ir mu(z)c_ir(z) <= 2p tau,
    sum_ir,z w_ir mu(z)<f_ir(z),W_ir(z) f_ir(z)> = p sbar,

where tau = L/m. W_ir(z) is an effect because Q^a_x R^b_y are commuting positive operators forming a complete joint POVM. The same local amplified algebras work for all modes and flags.

## 4. Barycenters require no measurable selection or compact optimizer

Extension lines 335-403. P_X and P_Y are orthogonal projections on the finite weighted question-pair space. Therefore P = (P_X+P_Y)/2 is a positive contraction. Equality in its fixed-space condition forces membership in both local-function spaces; on a connected pair graph this means constants. The finite spectral gap is positive and at most 1.

The scalar Poincare inequality extends to Htilde-valued functions by resolving the finite span of the finitely many vector values into an orthonormal basis. This does not compress operators or approximate the strategy. Conditional means minimize squared error, so for each component j,

    sigma_j Var_j(f_ir)
      <= (||f_ir-P_X f_ir||_2^2+||f_ir-P_Y f_ir||_2^2)/2
      <= E_mu_j c_ir/2.

The barycenter beta_ir,j = sum_z mu_j(z) f_ir(z) is a finite vector sum in one fixed Hilbert space. There is no field of eigenspaces, direct-integral choice, maximizer, or measurable selector. With the extension's masses P_j,E_j,P_hat_j, orthogonal decomposition gives exactly

    P_hat_j = P_j-E_j,  sum_j lambda_j E_j <= p tau/sigma.

When P_hat_j > 0, the vector P_hat_j^(-1/2) sum_ir sqrt(w_ir)|ir> tensor beta_ir,j is normalized and independent of the fresh input pair. Alice and Bob use block-diagonal measurements on the same finite classical register. In each block their operators commute, hence every controlled Alice/Bob pair commutes. This is a legal arbitrary commuting strategy. Its success is T_hat_j/P_hat_j <= v_j. When P_hat_j = 0 all its vector terms vanish and T_hat_j = 0; nothing is divided by zero.

For every effect W,

    |<f,Wf>-<beta,Wbeta>| <= (||f||+||beta||)||f-beta||.

Weighted Cauchy-Schwarz and P_hat_j <= P_j yield

    |T_j-T_hat_j| <= 2 sqrt(P_j E_j),
    T_j <= v_j P_j + 2 sqrt(P_j E_j).

No lower bound on any barycenter norm or any individual conditional probability is needed.

To justify sum_j lambda_j v_j <= v without attainment, for each epsilon > 0 choose one strategy with component success at least v_j-epsilon. There are only finitely many components. Tensor their **whole shared Hilbert spaces** and states; for an input in component j each player uses that component's factor. Local questions identify j, and the new cross-input effects commute even for different components because they act on different tensor factors. Success is at least sum_j lambda_j v_j-epsilon; let epsilon decrease to 0. This tensor product of whole commuting representations is not a bipartite factorization of any original representation. The opposite inequality is also immediate by restriction, although only the displayed direction is needed.

The conditional component law is lambda_tilde_j = lambda_j P_j/p = (1/m) sum_i Pr(J_i=j | E_C). Its joint likelihood ratio relative to lambda^tensor m is at most 1/p. Product relative entropy therefore bounds the sum of marginal divergences by log(1/p). Pinsker and Cauchy-Schwarz give

    TV(lambda_tilde,lambda) <= sqrt(log(1/p)/(2m)).

Since 0 <= v_j <= 1, total variation bounds the possible increase of its weighted value average. Summing sqrt(P_j E_j) once more gives the final conditioning estimate

    sbar <= v + sqrt(log(1/p)/(2m)) + 2sqrt(tau/sigma).

For connected support the component drift is zero. Singleton components have zero variance; the stated sigma convention is safe.

## 5. Every repetition length and the constants: certified

Extension lines 405-479 and released 04-threshold.tex. For the disconnected bound, tau <= T = sigma delta^2/128 gives excess at most delta/16 + delta/sqrt(32) < delta/4, using sigma <= 1. For connected support, T = sigma delta^2/64 gives excess at most delta/4. Both budgets satisfy T <= delta/4.

Sampling ell indices with replacement uses only the realized number of wins W. Its success probability conditional on the indicators is (W/k)^ell, even when the indicators are dependent. With q = v+delta, q0 = v+delta/2, eta = delta/16, the weight argument supplies a fixed tested set with

    |C| <= ell,
    p_C >= p_H q^ell/2,
    Pr(W < q0 k | E_C) <= eta.

Let r = log(q/q0), R = log(d/q), and c = delta T/[16(1+log d)]. The arithmetic checks independently:

    r >= delta/(2q),
    c/r <= T/8 <= eta/2,
    delta(1+R/r) <= delta+2q log d+2q log(1/q)
                    <= 3(1+log d).

For sufficiently large k, a putative p_H >= exp(-ck) therefore gives |C| <= eta k < k and tau(C) < T. The conditional remaining win fraction is at least q0-eta = v+7delta/16, contradicting the conditioning upper bound v+delta/4. The decreasing function (q0-u)/(1-u), u = |C|/k, is used with its correct direction.

The large-k cutoff is independent of the strategy and its Hilbert space. For a fixed short strategy take N independent copies on H^tensor N. Complete string effects are products across copies and retain every cross-input commutator. The product vector makes the blocks independent, so the event that every block meets its threshold has probability p_H^N and implies the threshold on Nk coordinates. The large-k bound yields p_H^N <= exp(-cNk), hence p_H <= exp(-ck). This is valid for arbitrary H and takes no limit of optimizers.

The constants are thus 16*128 = 2048 and 16*64 = 1024. Every coordinate marginal is a legal single-game commuting strategy after fixing the other question pairs, so v = 0 gives zero wins almost surely. The all-wins event is contained in every threshold event; taking delta upwards to 1-v at fixed k gives the stated endpoint.

## 6. Analytical non-type-I stress case with a kernel and singular inverse

This is a stress specimen for the construction, not a theorem counterexample or a numerical surrogate for the proof.

Let R0 = L(F_2), the finite factor of the free group on two generators, and R = M_2 tensor R0 with normalized trace tau. On H = L2(R,tau), let Alice act by left multiplication and Bob by right multiplication. The two von Neumann algebras commute and are type II_1, rather than type I. If desired, finitely many additional binary inputs with effects (I +/- Re U)/2, (I +/- Im U)/2, the analogous effects for the other free generator V, and the two matrix Pauli observables make the original POVM families generate the full non-type-I algebras. All left/right cross commutators still vanish.

The Haar unitary U in R0 has uniform angular spectral variable u in [0,1). Choose t = (2u-1)_+, by bounded Borel functional calculus, and p0 = support(t). Its spectral law is half an atom at 0 and half uniform on (0,1). Let

    D = diag(1,1/2),
    T = D tensor t,
    p = I_2 tensor p0,
    C_+ = |+><+| tensor p0,
    C_- = |-><-| tensor p0,
    G_+/- = (sqrt(D)|+/-><+/-|sqrt(D)) tensor t.

Then 0 <= T <= I, support(T) = p, sum G_+/- = T, and the G effects do not commute with T internally. T has a nontrivial kernel and positive spectrum arbitrarily close to zero. Thus T^(-1/2) is unbounded on pH.

Nevertheless the form-defined C_+/- are exactly the displayed projections. With R_epsilon = sqrt(T)(T+epsilon I)^(-1/2),

    R_epsilon C_+/- R_epsilon -> C_+/- strongly,
    ||R_epsilon C_+/- R_epsilon - C_+/-|| = 1

for every epsilon > 0. The norm equality follows by taking positive spectral values of t arbitrarily near zero: the regularized matrix tends to 0 while C_+/- has norm 1; the difference of two positive contractions has norm at most 1. This demonstrates why **strong**, rather than norm, von Neumann closure is the right step in Section 2.

Use Bob's coarse S = right(T) and fine K_+/- = right(G_+/-), Alice's left copies, and psi = 1 in L2(R,tau). The exact two-ancilla pullback gives norm squared tau(T^2) = (5/8)(1/6) = 5/48. Its unnormalized answer masses are

| | Bob + | Bob - |
| --- | ---: | ---: |
| Alice + | 9/192 | 1/192 |
| Alice - | 1/192 | 9/192 |

These are tau(G_a G_b); after dividing by 5/48 the probabilities are 9/20 on each diagonal and 1/20 on each off-diagonal. This verifies an explicit zero-spectrum, internally noncommuting transport in a genuinely non-type-I original representation. The trace is used solely to evaluate this specimen, not in the general proof.

## 7. Strengthened readings that this audit rejects

* A proof in a fixed original representation: the component flag, resolvent ancillas, and component tensor copies enlarge the permitted representation. The extension explicitly permits this.
* A finite tensor approximation of an arbitrary commuting correlation: none is constructed or invoked.
* An efficiently preparable barycenter or an efficiently acquired inverse-polynomial gap: the argument is a value upper bound with a supplied question-law spectral parameter.
* A formal or historically novel theorem: the relevant released Lean scope excludes the spectral cubic result and the commuting interface; this audit performed no kernel verification or broader primary priority search.
* An impossibility proof for every gap-free cubic repetition theorem: the fact that this resampling gap can tend to zero is an obstruction to this spectral estimate, not a counterexample to all possible alternative uniform arguments.

For the last distinction, the full-support binary law with masses (1-epsilon)/2 on the two diagonal pairs and epsilon/2 on the two off-diagonal pairs has sigma = epsilon for 0 < epsilon < 1/2. Its centered local signs have correlation 1-2epsilon; their sum is an eigenvector of P with eigenvalue 1-epsilon. This exactly identifies deterioration of this rounding mechanism. It does not falsify a hypothetical theorem using a different mechanism.

The optional POVM/projective equivalence at extension lines 481-514 also checks. For the displayed isometry W and P = I-WW*, the proposed unitary has inverse (l,h') -> (W*l,Pl+Wh'). Its matrix coefficients lie in the original local algebra, and separate finite ancillas preserve cross commutation. Joint compression gives the original M_x^a N_y^b probabilities without any dimensional cancellation theorem.

## Remaining validation step

On the exact interface, the load-bearing proof is internally complete after reconstruction. The substantive remaining validation is an external specialist or kernel-level reconstruction of the bounded-column transport and its game composition. Application to a particular verifier additionally requires a certified gap and charged question/answer/predicate growth. No source change, publication, source contact, or claim of historical priority was made.
