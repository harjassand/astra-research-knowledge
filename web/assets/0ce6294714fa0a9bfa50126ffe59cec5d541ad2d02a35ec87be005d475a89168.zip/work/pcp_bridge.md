# Sparse QMA/PCP bridge: one exact auxiliary repair and one bounded-degree barrier

7 October 2026. Worker `pcp_bridge`; no nested agents. Status: **INTERNALLY DERIVED, NOT EXTERNALLY VALIDATED; general sparse QMA hardness remains unresolved**. Existing research files were read without modification. Historical novelty is not claimed.

## 1. Exact target and the present bottleneck

The imported target is the amplified hard Hamiltonian

\[
H=\sum_j w_j h_j,\quad \sum_jw_j=1,\qquad
h_j=I-\bigotimes_{i=1}^{t_j}(I-\Pi_{ji}),
\]

with actual hard constant-size seeds, including five-qubit Clifford **projectors**. Their reflections need not be Clifford. The desired reduction must supply one common efficiently described isometry \(V\), \(P=VV^*\), and positive polynomial-row contractions \(C,B\), such that

\[
\ker C=\operatorname{ran}V,\qquad
C\ge\gamma(I-P),\qquad
\alpha H\le V^*BV\le\beta H,
\]

with positive constants \(\alpha,\beta,\gamma\) independent of size and amplification depth. Row enumeration, entry computation, precision, coefficient size, normalization and invalid encodings must all be charged. Every auxiliary state must be protected. The imported compression inequality removes the requirement \([B,P]=0\): for \(K=(C+B)/2\),

\[
\frac{\gamma\alpha}{2(\gamma+1)}\lambda_{\min}(H)
\le\lambda_{\min}(K)\le\frac\beta2\lambda_{\min}(H).
\]

This inequality is a conditional conversion service; it does not supply either positive sparse operator.

BMVZ explicitly retain sparsification as an application bottleneck, and their amplified terms have the displayed tensor structure. Read scope here: Definitions 1.6 and 1.9 and the introduction/application excerpts; no reconstruction of their full amplification proof. [Primary source](https://arxiv.org/html/2510.01333v1).

## 2. Exact auxiliary repair of the peaked Fourier-field example

The existing release-283 audit constructs a row-1 exact Fourier-field isometry whose image contains a peaked vector. In its original coordinates, every positive normalized constant-gap image enforcer needs an exponential row. The following construction repairs **that example's image enforcement** after changing its auxiliary encoding. It does not repair arbitrary matched Fourier fields or supply the hard-instance test operator \(B\).

### The source image

Take \(m=2^r\), \(r\ge1\), \(k=m+1\), and

\[
c=\frac1{\sqrt2}|0\rangle+
\frac1{\sqrt{2m}}\sum_{j=1}^m|j\rangle.
\]

The unitary block matrix

\[
U_c=\begin{pmatrix}I_k-cc^*&c\\c^*&0\end{pmatrix}
\]

has one internal coordinate and internal block \(D=0\). Substituting in the source's Section 4 field formulas gives the exact forward image

\[
P_E=|f_0\rangle\langle f_0|\otimes I_k
+|f_1\rangle\langle f_1|\otimes cc^*,
\]

where \(f_0=0\), \(f_1=-v_1\ne0\). Ports map to frequency \(f_0\), and the internal input maps to frequency \(f_1\) tensored with \(c\). The source formulas were read directly at `04-fields.tex`, equations `fields:block`, `fields:truncations`, and `fields:maps`; the full synthesis proof was not adopted here. [Pinned source](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Polynomial-Time-Unitary-Synthesis-from-a-Boolean-Oracle-October-5-2026/build/sections/04-fields.tex).

### A row-1 isometry that flattens the heavy coordinate

Use \(2m\) coordinates addressed by a flag and \(r\) bits. Define

\[
W|0\rangle=|0\rangle\otimes |+\rangle^{\otimes r},\qquad
W|j\rangle=|1\rangle\otimes |j-1\rangle\quad(1\le j\le m).
\]

These columns are orthonormal, every row has one nonzero, and

\[
Wc=|+\rangle^{\otimes(r+1)}.
\]

The port dimension grows from \(m+1\) to \(2m\), a factor below two. There is an explicit efficient full-register unitary extension. First use the permutation fixing index zero and adding \(m-1\) cyclically on the other \(2m-1\) indices. It sends valid indices \(1,\ldots,m\) to the entire flag-1 half and sends index zero to flag-0, all-zero. Apply Hadamards to the \(r\) low bits conditioned on flag zero. Reversible arithmetic implements the permutation in polynomial cost in \(r\); the stated images on the valid subspace are exactly \(W\). Nonzero entries of \(W\) are \(1\) or \(2^{-r/2}\), represented exactly using a rational times \(1\) or \(1/\sqrt2\). Its exponentially dense heavy column is permitted; the objective is polynomial row support of \(C,B\), not column support of \(V\).

### Deterministic rational small-bias enforcement

For each integer \(\ell\ge1\), choose the smallest power of two \(q\ge4\ell\) and an explicit field \(\mathbb F_q\). For \((a,b)\in\mathbb F_q^2\), define a bit vector

\[
s(a,b)_i=\operatorname{Tr}_{\mathbb F_q/\mathbb F_2}(ab^i),
\qquad 0\le i<\ell,
\]

and let \(X^{s(a,b)}\) be the corresponding computational-basis permutation. Set

\[
G_\ell=\frac1{q^2}\sum_{a,b}\frac{I-X^{s(a,b)}}2.
\]

This is a positive contraction. On the Fourier character labelled by \(u\in\mathbb F_2^\ell\), its eigenvalue is

\[
\frac{1-\beta_u}{2},\qquad
\beta_u=\mathbb E_{a,b}(-1)^{\operatorname{Tr}(a\sum_i u_i b^i)}.
\]

For \(u=0\), \(\beta_u=1\). For \(u\ne0\), character orthogonality in \(a\) gives

\[
\beta_u=\Pr_b\!\left[\sum_i u_i b^i=0\right]
\in[0,(\ell-1)/q]\subseteq[0,1/4].
\]

Consequently,

\[
\ker G_\ell=\operatorname{span}(|+\rangle^{\otimes\ell}),\quad
\frac38(I-|+^\ell\rangle\langle+^\ell|)\le G_\ell\le\frac12 I.
\]

Each row has at most \(1+q^2=O(\ell^2)\) enumerated nonzeros. Repeated labels can be merged in polynomial time. Entries are exact rationals with denominator dividing \(2q^2\), hence \(O(\log\ell)\) bits apart from addresses. Field construction by exhaustive search for an irreducible polynomial of degree \(\log_2q=O(\log\ell)\) is itself polynomial in \(\ell\); no randomized expander promise or supplied coefficient table is required.

### The complete image enforcer

For \(V=(I\otimes W)E\), the image projection is

\[
P'=|f_0\rangle\langle f_0|\otimes
 (|0\rangle\langle0|\otimes|+^r\rangle\langle+^r|
  +|1\rangle\langle1|\otimes I_m)
+|f_1\rangle\langle f_1|\otimes|+^{r+1}\rangle\langle+^{r+1}|.
\]

Define, including every unused frequency address,

\[
\begin{split}
C={}&|f_0\rangle\langle f_0|\otimes(|0\rangle\langle0|\otimes G_r)\\
&+|f_1\rangle\langle f_1|\otimes G_{r+1}\\
&+(I-|f_0\rangle\langle f_0|-|f_1\rangle\langle f_1|)\otimes I_{2m}.
\end{split}
\]

The three sectors are orthogonal, so

\[
0\le C\le I,\qquad \ker C=\operatorname{ran}V,
\qquad C\ge\frac38(I-P').
\]

This protects all auxiliary and invalid frequency states. Address equality is a diagonal test with one nonzero per row. The complete matrix retains \(O(r^2)\) row support, polynomial row/entry algorithms, and exact rational coefficients. The construction is dimension-uniform for the specified \(m=2^r\) family.

**Boundary.** This explicitly evades the prior peaked-row obstruction using a different isometry. It does not produce one common encoding for all amplified hard clauses, acquire a general Fourier-field table, or control the compression of their positive test operators. The original same-coordinate theorem remains correct. Small-bias enforcement and coherent copying are established mechanisms; no historical novelty of this combination is claimed.

## 3. Bounded syndrome degree cannot give constant normalized rejection

This is a self-contained extension of the imported affine-syndrome barrier. It allows any fixed auxiliary Hilbert space, arbitrary signed operator coefficients, and syndrome-dependent preferred auxiliary states. Its lower bound comes from protecting **every** auxiliary state on a violated syndrome.

### Theorem

Let \(x\in\{0,1\}^t\). On one fixed auxiliary Hilbert space, suppose

\[
K_x=\sum_{S\subseteq[t],\,|S|\le d}\left(\prod_{i\in S}x_i\right)A_S
\]

with bounded self-adjoint \(A_S\). Assume

\[
0\le K_x\le L I\quad\text{for all }x,\qquad
\inf\operatorname{spec}K_0\le\eta,\qquad
K_x\ge c I\quad\text{for all }x\ne0.
\]

If \(d^2<t\), then

\[
\boxed{c-\eta\le\frac{L d^2}{t-d^2}.}\tag{1}
\]

If \(c>\eta\), in all cases

\[
\boxed{d^2\ge\frac{c-\eta}{L+c-\eta}\,t.}\tag{2}
\]

The theorem is independent of the auxiliary dimension and of coefficient bit sizes or row sparsity. Coefficient matrices need not be positive or commute.

### Proof

Choose a unit vector \(z\) with \(\langle z,K_0z\rangle\le\eta+\zeta\). This exists for every \(\zeta>0\), including infinite-dimensional auxiliary spaces. The real multilinear scalar polynomial

\[
f(x)=\langle z,K_xz\rangle
\]

has degree at most \(d\), takes values in \([0,L]\), has \(f(0)\le\eta+\zeta\), and satisfies \(f(x)\ge c\) on all nonzero strings.

Symmetrize over all coordinate permutations. At weight \(j\), the result is a univariate polynomial \(p(j)\) of degree at most \(d\): a degree-\(s\) monomial contributes \((j)_s/(t)_s\). Thus

\[
0\le p(j)\le L\quad(j=0,1,\ldots,t),\quad
p(0)\le\eta+\zeta,\quad p(1)\ge c.
\]

Put \(g(u)=p(u)-L/2\) and \(M=\max_{u\in[0,t]}|g(u)|\). The classical Markov inequality after rescaling \([-1,1]\) to \([0,t]\) is

\[
\|g'\|_{[0,t]}\le\frac{2d^2}{t}M.
\]

Every real \(u\in[0,t]\) lies within \(1/2\) of an integer point, where \(|g|\le L/2\). Therefore

\[
M\le\frac L2+\frac12\|g'\|
\le\frac L2+\frac{d^2}{t}M,
\]

so, when \(d^2<t\),

\[
M\le\frac{Lt}{2(t-d^2)},\qquad
\|p'\|\le\frac{Ld^2}{t-d^2}.
\]

Hence \(c-\eta-\zeta\le p(1)-p(0)\le\|p'\|\). Let \(\zeta\downarrow0\) to obtain (1). Rearrangement gives (2) for \(d^2<t\); if \(d^2\ge t\), (2) is immediate. This completes the proof.

The scalar symmetrization/Markov mechanism is old: see Bun–Thaler, especially Section 5 and the stated higher-derivative Markov inequality with \(T_d'(1)=d^2\). This is a direct application to all-auxiliary positive enforcement, not a new approximate-degree theorem. [Primary reference](https://arxiv.org/html/1302.6191).

For \(d=1\), the exact affine argument is stronger: since \(p(t)=t p(1)-(t-1)p(0)\le L\),

\[
c\le L/t+(1-1/t)\eta.
\]

### Uniform precision extension

Suppose physical \(K_x\) obeys the operator conditions above, while a degree-\(d\) family \(\widetilde K_x\) satisfies

\[
\sup_x\|K_x-\widetilde K_x\|\le\epsilon.
\]

The same scalarization has grid values in \([-\epsilon,L+\epsilon]\), and its first-step increase is at least \(c-\eta-2\epsilon-\zeta\). Centering again at \(L/2\) gives

\[
c-\eta\le2\epsilon+
\frac{(L+2\epsilon)d^2}{t-d^2}.\tag{3}
\]

Thus, for \(c>\eta+2\epsilon\),

\[
d^2\ge\frac{c-\eta-2\epsilon}{L+c-\eta}\,t.
\]

Small uniform operator error cannot turn a bounded-degree scheme into a constant-gap one. This premise requires an actual uniform operator-error certificate; per-entry precision alone does not supply it. For a Hermitian row-\(s\) error matrix with each entry at most \(\delta\), the elementary row-sum bound gives \(\|\Delta\|\le s\delta\), so \(\delta\le\epsilon/s\) suffices when the perturbed sparsity pattern is controlled. Exact-zero completeness must still be established separately if it is claimed.

## 4. Sharpness of the degree scale; remaining sparsity loss

The quadratic degree dependence in (1) is necessary. For \(t>1\), choose \(a\ge1\) and let \(T_a\) be the Chebyshev polynomial. Define

\[
q_{t,a}(j)=1-
\left[
\frac{T_a((t+1-2j)/(t-1))}{T_a((t+1)/(t-1))}
\right]^2.
\]

It has degree \(d=2a\), exact \(q_{t,a}(0)=0\), and for every integer \(1\le j\le t\),

\[
c_{t,a}\le q_{t,a}(j)\le1,\qquad
c_{t,a}=1-\frac1{T_a((t+1)/(t-1))^2}.
\]

The lower bound is attained at \(j=1,t\). Thus \(K_x=q_{t,a}(|x|)I\) is an exact positive all-auxiliary construction of the specified syndrome gap. Using

\[
\operatorname{arcosh}\frac{t+1}{t-1}
=2\operatorname{artanh}(t^{-1/2}),
\]

the gap is

\[
c_{t,a}=\tanh^2(2a\operatorname{artanh}(t^{-1/2})).
\]

For \(a\ll\sqrt t\), this is asymptotic to \(4a^2/t=d^2/t\); \(a=\Theta(\sqrt t)\) gives constant gap. For \(a=1\), the exact gap is \(4t/(t+1)^2\), asymptotically matching (1)'s degree-2 bound.

For commuting projections, put \(S=\sum_i\Pi_i\), \(F=I-\prod_i(I-\Pi_i)\). The same spectral calculation proves

\[
c_{t,a}F\le q_{t,a}(S)\le F,
\]

with the exact kernel of \(F\). Polynomial coefficients are rational with \(O(a\log t)\) bit heights and can be generated by a rational recurrence. No square root or approximate zero is needed.

However, if each \(\Pi_i\) has row support at most \(s_0\), straightforward multiplication gives only the row bound \((1+t s_0)^{2a}\). At the needed degree \(\Theta(\sqrt t)\), this is not polynomial in the amplified input size when \(t\) is polynomial. Cancellations or a special basis could improve that bound; the degree theorem supplies no universal row lower bound. It therefore does not rule out the required common auxiliary encoding. It rules out a constant-degree syndrome gadget as an automatic normalized-gap repair.

## 5. Why repetition, entropy and qLTC do not close this interface

Release family 277's primary Section 6 gives error amplification for two-player games: threshold repeated wins preserve two players and one round. The source's paper states a universal fifth-power rate; its Lean scope document covers a thirteenth-power rate and excludes the separate distribution-dependent cubic bound. No build was run. These are game-value statements, not sparse Hamiltonian image-enforcement algorithms. The recent local commuting-operator extension remains internally derived evidence. [Pinned scope](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/lean/docs/277.md), [pinned primary consequence](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Threshold-parallel-repetition-for-finite-dimensional-entangled-games-September-25-2026/build/sections/06-consequences.tex).

Our inference is that a stronger repetition rate can lower repetition count after a named verifier has been supplied, but it does not acquire the common \(V,C,B\), row oracles, or positive normalization. Replacing repeated OR/threshold predicates with a bounded-degree syndrome Hamiltonian is still constrained by (1)–(3). The game strategy quantifiers cannot be identified with the spectrum of an arbitrary noncommuting Hamiltonian without an additional reduction.

The two September qLTC papers claim good codes with constant rate, relative distance, soundness and bounded checks. Only their abstracts and metadata were verified here. [Gay–Jeronimo](https://arxiv.org/abs/2609.20780), [Chen–Huang–Liu–Tang](https://arxiv.org/abs/2609.28028). Constant Hamming soundness is not a constant normalized excitation gap: for a weighted stabilizer tester of check weight at most \(k\), total weight one, and distance above one, choose a site with weighted incidence at most \(k/n\) and a one-site Pauli error taking a codeword to an orthogonal syndrome. Its energy is at most \(k/n\). This is consistent with Hamming soundness for a one-site error. Nonlocal small-bias enforcement can avoid that loss, as Section 2 demonstrates, but does not by itself encode computation.

The local quantum-entropy note was also read at its interface: family 273 is a finite-mode, finite-energy, independent-input beam-splitter inequality. It supplies no state-preparation, row-enumeration or code-enforcement service. The earlier area-law/PEPS bridge likewise assumes a full excitation gap and provides an existence statement whose tensors may depend on the ground state. Neither supplies the hard sparse-positive reduction. Their full proofs were not newly audited in this task.

## 6. Evidence and falsifiable next step

`pcp_bridge_checks.py` passed 62 exact rational Chebyshev cases at 40,934 grid points, nine finite-field enforcer cases with 1,013 nontrivial character checks, and eight complete image-sector compositions. These finite fixtures check implementation and constants; the proofs above establish the dimension-uniform statements. Results are in `pcp_bridge_checks.json`. No theorem prover or external mathematical review was used. Recoverable read-scope and source metadata are in `pcp_bridge_sources.json`.

The next substantive encoding test should specify a common isometry for at least overlapping actual five-qubit rank-one stabilizer seeds, then give both: (a) a positive polynomial-row \(C\) with a certified size-independent normalized gap on all invalid/auxiliary states, and (b) a positive polynomial-row \(B\) with uniform multiplicative compression bounds for their amplified clauses. The exact repair in Section 2 supplies (a) for its special Fourier image only. The degree theorem tells us that a proposed bounded-syndrome scheme must expose \(\Omega(\sqrt t)\) dependence or leave its model. The remaining global positive-encoding bottleneck is unchanged.
