# Adaptive predictive acquisition: a passive LPN boundary and a repeated-readout escape

7 October 2026. Derived in this run. Source work was read only. The arguments below are written proofs, with finite diagnostic checks; they are not externally or formally validated. No historical novelty is claimed.

The important inherited advance is already past the matrix-oracle assumption: the later run constructs a universal polynomial bank of bounded trajectory moments whose population Hankel rank is complete for every finite-state process. The remaining problem is **acquiring informative adaptive features at affordable precision and computation**, because every fixed polynomial bounded bank has exponentially bad worst-case conditioning.

This note supplies two interface-matched results. First, a general polynomial-time passive learner with efficiently evaluable prefix predictions would solve noisy parity, even if its learned model is improper. The simulation supplies only ordinary reset trajectories and does not simulate a conditional-sampling teacher. Second, a concrete positive finite-state class with **persistent noisy readout** permits dense parity-feature discovery, exact model reconstruction at known rational noise, and a certified constant local predictive moment margin. It needs only longer reset episodes. The equally informed direct majority/GF(2) decoder attains the same construction; there is no claimed acquisition advantage over that comparator.

## 1. Inherited work and the question being advanced

Read sources:

* `/Users/harjas/Documents/ChatGPT/Literature Digestion/results/root_cycle19/REPORT.md`.
* `/Users/harjas/Documents/ChatGPT/Literature Digestion/notes/root_cycle19/CYCLIC_SCALAR_GRID_HITTING.md` and its acquisition addendum/prior comparison.
* `/Users/harjas/Documents/Codex/2026-10-07/you-have-access-to-over-100-5/outputs/RESEARCH_STATE.txt`.
* That workspace's `work/algebra_acquisition/UNIVERSAL_STOCHASTIC_MOMENT_REALIZATION.md`, `work/FIXED_OBSERVABLE_CONDITIONING_BARRIER.md`, and `work/algebra_acquisition/prior/ACQUISITION_BOUNDARY.md`.

Inherited: a nonzero proper m-state series is detected by one of the m full Volterra responses at dimension 2nm; positive rescaling and controller occupation tests compile this into bounded passive moments. The universal moment learner is polynomial in the inverse *actual moment singular margin*, not merely in state count. The fixed-bank parity argument proves that no fixed polynomial bank can make that margin uniformly polynomial. The earlier boundary note already discusses the classical noisy-parity hardness of probabilistic automata through primary prior; this note does not relabel that older hardness as new.

The new explicit gate is: does a proposed adaptive feature learner acquire a forecast that works at arbitrary supplied histories, and what data actually make this possible? The distinction between one noisy label and repeated readout of the same latent bit resolves that gate on a concrete class.

## 2. An exact low-state passive simulator for noisy parity

Let d>=1, let the unknown mask s belong to GF(2)^d, and let 0<eta<1/2. Write theta=1-2eta. A reset episode emits

    A_1,...,A_d independently fair,
    B = s dot A + E mod 2,  E ~ Bernoulli(eta),
    followed by an independent fair iid tail.

All E and A are independent. Denote this infinite process by P_s. Its first-(d+1) law is

    p_s(a,b) = 2^(-(d+1)) [1 + theta (-1)^(s dot a + b)].

This is a time-homogeneous positive symbol-transition process with at most 2d+2 states. Use start state (0,0), two parity/clock states (t,p) for 1<=t<=d, and one fair-tail state. For t<d, emit x fairly and update

    (t,p) -> (t+1, p + s_(t+1) x mod 2).

At t=d, emit p with probability 1-eta or 1-p with probability eta and enter the tail. The tail emits fair bits forever. A standard edge-to-state emission conversion uses at most 4d+4 ordinary state-emitting HMM states. For eta=1/4, every entry is in the fixed set {0,1/4,1/2,3/4,1}; coefficient heights are not the source of hardness. The clock is counted in these bounds.

**Simulation lemma.** Given an ordinary search-LPN sample service producing independent `(a,b)` with `a` uniform and `b=s dot a+E`, one can simulate every adaptively stopped/reset observed trajectory of P_s exactly. Draw and retain one LPN sample at the beginning of each episode. Reveal its a coordinates, then its b coordinate, then independent fair bits. A reset discards any unrevealed coordinates and starts a new sample. The learner may decide when to stop or reset from everything revealed so far; the construction remains identical in law.

If the learner uses R resets and O observed symbols, simulation costs R LPN samples, O(Rd+O) local bit work, and O(d) buffering. It never asks for an LPN sample conditioned on an arbitrary a or history. A conditional teacher implemented by exponential rejection sampling is neither supplied nor needed.

## 3. Improper forecast extraction gives a search-LPN reduction

Assume a learner trained on the passive interface above returns a positive law q on length-(d+1) words. The representation may be arbitrary. The required operational output is an algorithm that, on every supplied a, computes the two next-bit probabilities q(b|a) in polynomial time and bit precision. At q(a)=0, it may return any probability pair. This is a learned-model query, not a conditional sample from the unknown source.

**Theorem A.** Suppose, with success probability at least 2/3, the learner has

    TV(p_s,q) <= theta/16,

and training, model size, and arbitrary-prefix probability evaluation are polynomial in d and theta^-1. Then search-LPN at noise eta is solvable in randomized polynomial time. The theorem allows improper models and adaptive computation over all raw training paths.

In particular, under the usual search-LPN hardness hypothesis at a fixed noise rate such as eta=1/4, no such uniform passive learner exists for all these O(d)-state processes. This is a computational consequence of a hypothesis, not an unconditional impossibility theorem or a passive-sample lower bound.

### 3.1 From joint TV to one heavy Fourier coefficient

Put

    g(a) = q(0|a)-q(1|a),              |g(a)|<=1,
    g_s(a) = E_P[(-1)^B | A=a] = theta chi_s(a),
    chi_s(a)=(-1)^(s dot a).

For each a, the triangle inequality gives

    p_s(a)|g(a)-g_s(a)|
      <= sum_b |q(a,b)-p_s(a,b)| + |q(a)-p_s(a)|.

The same bound holds at q(a)=0 by defining any conditional pair there. Summing and using `p_s(a)=2^-d` gives

    E_(a uniform)|g(a)-theta chi_s(a)| <= 4 TV(p_s,q) <= theta/4.

Consequently the Fourier coefficient satisfies

    ghat(s)=E_a g(a)chi_s(a) >= 3theta/4.

Only O(log(theta^-1)) bits of absolute precision in g are needed for the following constant-fraction Fourier thresholds. For example, evaluating g within theta/32 leaves the target coefficient above theta/2. If the model computes conditionals by dividing tiny prefix masses, its claimed polynomial probability-evaluation contract must include that operation; it is not supplied by this proof.

### 3.2 A self-contained polynomial heavy-coefficient extractor

This is the classical Goldreich-Levin/Kushilevitz-Mansour mechanism, written out to charge the learned-model queries.

For a prefix u of k frequency bits, define the bucket energy

    S_k(u) = sum_(v in GF(2)^(d-k)) ghat(u,v)^2.

Orthogonality of the remaining characters gives the exact identity

    S_k(u)
      = E_(z,a,a') [g(a,z) g(a',z) (-1)^(u dot (a+a'))],

where a,a' are independent fair k-bit strings and z is a fair (d-k)-bit string. The integrand lies in [-1,1] and needs two evaluations of the learned g. Parseval gives `sum_u S_k(u)=E g^2<=1` at every k.

Take tau=theta/2. Begin with the empty prefix. At every layer evaluate the two children of each retained prefix, estimate each S to additive accuracy tau^2/4, and retain it if its estimate is at least tau^2/2. The true target bucket always has S>=ghat(s)^2>=tau^2, so every prefix of s survives. Every retained bucket has true S>=tau^2/4, so there are at most 4/tau^2 retained prefixes per layer. Abort if this count is exceeded; this does not happen on the joint estimation event.

There are at most 8d/tau^2 bucket estimates. For failure allowance zeta, each estimate needs at most

    ceil(32 tau^-4 log(16d/(tau^2 zeta)))

independent integrand samples by Hoeffding. Thus the total learned-predictor evaluations are

    O(d theta^-6 log(d/(theta zeta))),

with polynomial sign/arithmetic overhead, and the final list has at most 16/theta^2 masks including s. If g is computed within theta/32, either reduce the bucket-error allowance by a fixed factor or invoke the extraction thresholds on the rounded bounded g; its target remains theta/2-heavy and the same polynomial bound applies.

On a fresh LPN validation batch, estimate

    C_v=E[(-1)^B chi_v(A)].

These expectations are theta at v=s and zero otherwise. O(theta^-2 log(|list|/zeta)) fresh examples estimate every C_v within theta/4, so choosing the largest finds s. Splitting failure between training, bucket estimation and validation leaves constant success probability, which can be amplified by independent runs and validation. All costs are polynomial. This proves Theorem A.

### 3.3 Precise scope of the obstruction

The inherited finite-horizon positive sampler computes child probabilities from its signed recurrence at supplied prefixes. If an adaptive extension produced such a sampler with the displayed TV accuracy and a polynomial finite-bit evaluation contract for all inputs, Theorem A would apply. A failure at an off-support prefix is harmless only when the program still defines an efficient valid conditional pair there.

An opaque generator that only produces unconditional draws does **not** automatically supply g(a): waiting for a chosen d-bit prefix can cost 2^d. No generator-only LPN hardness is claimed here. Kearns et al. already distinguish evaluator and generator learning; preserving that distinction is essential. Likewise, the theorem does not rule out special structural classes, a supplied appropriate predictive margin, stronger observation services, or superpolynomial computation.

## 4. A positive class: the latent readout persists

Change only the law after the d fair input bits. The process retains Z=s dot A and emits

    B_j = Z + E_j mod 2,   j=1,2,...,

with independent Bernoulli(eta) errors. Denote it by R_s. Each new reset draws a new A; continuing an episode supplies repeated measurements of the **same** latent Z. No hidden-state intervention, arbitrary-prefix source query, state copy, or hidden matrix is available.

The positive symbol-transition realization has start (0,0), two (t,p) states for each 1<=t<=d, and self-loops at both (d,p) states with output probabilities eta and 1-eta. Hence it has at most 2d+1 symbol-transition states, or at most 4d+2 ordinary state-emitting HMM states. With known eta=1/4 all parameters are from the same fixed rational set above.

This is a distinct process class, not a way to obtain repeated noisy labels from the one-shot LPN oracle for free. Repeating the *same noisy observed label* would not work: fresh independent errors conditional on the retained latent bit are the load-bearing assumption.

**Theorem B (dense adaptive feature acquisition).** Supply d, a known noise bias theta>=beta>0, and failure probability delta. Let

    N = d + ceil(log2(3/delta)),
    R = any odd integer >= (2/beta^2) log(3N/delta).

Observe N independent reset episodes, each of length d+R. Majority-decode the R readout bits in each episode, then solve the resulting N equations over GF(2). With probability at least 1-2delta/3, the decoded equations have full rank and recover the exact unknown dense mask s. The resulting model generates and evaluates R_s exactly at **every horizon** when eta is known. No basis words or hidden transitions are supplied.

The complete observation charge is

    N(d+R)=O((d+log(delta^-1)) [d+beta^-2 log((d+log(delta^-1))/delta)]).

Gaussian elimination costs O(Nd^2) elementary bit operations using a conservative uncompressed representation; streaming storage can be O(d^2+d+R). Model storage is d mask bits plus O(log d) clock bits and the representation of eta. Masks of arbitrarily large weight are allowed.

### 4.1 Proof

For one episode, multiply the observed readout signs by the unobserved true sign of Z for the analysis. The R resulting independent signs have mean theta>=beta. A wrong majority requires their mean to be <=0, so Hoeffding gives failure at most

    exp(-R beta^2/2) <= delta/(3N).

A union bound makes all N labels correct with probability at least 1-delta/3.

The input rows are independent uniform elements of GF(2)^d. For every nonzero v, the probability that all N rows annihilate v is 2^-N. Union-bounding the at most 2^d-1 nonzero v gives rank failure at most

    (2^d-1)2^-N < 2^(d-N) <= delta/3.

On the complement of these two failure events, the equations are correct and full rank, so their unique solution is s. No raw noisy linear equations are incorrectly treated as exact. Once s is known, the model is explicit: emit fair input bits while updating their selected parity, then emit independent noisy copies of that parity forever. This proves all-word equality to R_s, not only agreement on the training set.

## 5. Acquired local predictive features have a certified margin

For an input cut t with 1<=t<=d, define

    U_t=(-1)^(sum_(j<=t) s_j A_j),
    V_t=(-1)^(sum_(j>t) s_j A_j + B_1).

These are computable bounded path observables after s has been recovered. They require only a prefix or suffix parity and the first terminal readout. Let `phi=(1[U=+1],1[U=-1])` and `psi=(1[V=+1],1[V=-1])`.

If the selected prefix contains at least one coordinate, U_t is fair and `V_t=U_t(-1)^E_1`, whence

    H_t=E[phi psi^T]
       = (1/4) [[1+theta,1-theta],[1-theta,1+theta]],
    singular values(H_t) = {1/2, theta/2}.

Before the first selected coordinate there is only one reachable parity value, so use the one-dimensional constant feature, whose scalar moment is 1. These are **local input-cut moments** for the known clock structure, not a claim about the smallest singular value of the inherited large universal Hankel bank. The source clock is still charged in the model; retaining the visible episode position costs O(log d) additional execution bits.

This proves existence of a good small adaptive feature bank for the one-shot LPN processes too: both processes have the same law through B_1. Theorem A shows why existence plus a good margin does not automatically give efficient discovery. The repeated-readout process makes discovery possible.

**Held-out certificate.** After training, freeze s and use a new independent batch of M episodes, reading only d+1 bits from each. Estimate every entry of each active H_t by its [0,1] indicator product. Set

    c = sqrt(log(24d/delta)/(2M)).

There are at most 4d entries. Hoeffding and a union bound show, with probability at least 1-delta/3, that every entry has error <=c. Thus each 2x2 operator error is <=2c, and the data-dependent lower certificate

    sigma_min(H_t) >= sigma_min(Hhat_t)-2c

is valid simultaneously. If

    M >= 128 beta^-2 log(24d/delta),

then c<=beta/16 and every certified lower bound is at least beta/4 on the successful mask-recovery event. Combining this with Theorem B gives success at least 1-delta. The held-out data are independent of the adapted features, so no fixed-feature concentration bound is silently reused after selection.

The extra observation charge is M(d+1), and all active moments can be computed in O(Md) bit operations by maintaining prefix parity and total selected parity. Exact moment counts have O(log M) bits. The square root in the certificate can be replaced by any rational upper bound on c; the 2x2 singular value can be enclosed by rational interval arithmetic to beta/64 at polynomial bit cost. This does not require an exact-real SVD.

There is an even cheaper **class-specific exact-mask and margin certificate**. For the frozen candidate v, use independent validation episodes and estimate

    C_v=E[(-1)^(B_1+v dot A)].

Within the promised class, C_v is theta if v=s and exactly zero otherwise, including the zero mask. With J validation episodes put

    a=sqrt(2 log(6/delta)/J).

Hoeffding gives simultaneous correctness of the single adaptive-after-freezing interval with probability at least 1-delta/3. Accept only if `Chat_v-a>=beta/2`. On the confidence event, acceptance certifies **v=s**, since an incorrect mask has C_v=0. Once accepted, `(Chat_v-a)/2` is a valid lower bound on every active cut's nonzero second singular value. Taking `J>=32 beta^-2 log(6/delta)` makes `a<=beta/4`, so a correctly recovered mask is accepted with lower margin at least beta/4. For a finite-bit certificate, use the conservative rational radius beta/4 directly at this J; its coverage follows from the same Hoeffding calculation, with no square-root computation. This costs J(d+1) symbols, O(Jd) bit work, and O(log J) count bits, plus the public rational encoding of beta. The certificate's validity depends on the promised process class; it does not certify that arbitrary unmodeled real-world data belong to that class. Repeated full 2x2 moment estimation is therefore optional in this specialization.

## 6. Unknown noise and a second positive specialization

If eta is unknown but theta>=beta is supplied, mask recovery is unchanged. Freeze the recovered s, read a fresh episode's input A, and collect J further persistent readouts. The values `(-1)^(B_j+s dot A)` are independent signs of mean theta on the successful training event. J=O(gamma^-2 log(delta^-1)) estimates theta to error gamma; reserve rounding error by exporting a dyadic theta estimate to another gamma precision.

For a requested horizon T>=d, coupling readout Bernoulli variables gives

    TV(R_s[1:T], Rhat_s[1:T])
       <= (T-d)|thetahat-theta|/2.

Choosing total theta error <=2epsilon/max(1,T-d) yields a finite-horizon epsilon guarantee with O((T-d)^2 epsilon^-2 log(delta^-1)) calibration readouts and O(log(T/epsilon)) coefficient bits. Use separate failure allowances for training, calibration and any margin certificate. No finite-sample exact acquisition of an arbitrary real unknown eta or uniform all-horizon approximation is inferred. If eta is known, this calibration stage is absent.

A distinct positive class needs no persistence: if the one-shot mask is promised to have weight at most k, enumerate the D=sum_(j<=k) binom(d,j) possible masks. With N>=32 beta^-2 log(2D/delta) episodes, all correlations `N^-1 sum (-1)^B chi_v(A)` are within beta/4 of their expectations. The correct correlation is theta>=beta and the others are zero, so its empirical correlation is uniquely largest. The time is O(NDd) bit work. For fixed k this is polynomial; for unrestricted dense masks D=2^d, so it is not a solution of LPN. The same learned H_t margin and independent certificate apply. Direct sparse-parity correlation search is the competent control, not a new algorithm by renaming it an adaptive moment learner.

## 7. On this positive class, the matrix oracle can actually be acquired

At known rational eta, Theorem B returns an explicit finite positive representation for the true R_s with high probability. Therefore the learner can implement all jointly strictly triangular rational matrix evaluations locally, rather than treating them as an external supplied service.

For a D-dimensional common strictly lower-triangular tuple X, with learned row/transition/column representation `(alpha,B_i,beta)`, the m-vector block recurrence for each input column q is

    z_(r,q) = beta 1[r=q] + sum_i sum_(h<r) X_i[r,h] B_i z_(h,q),
    f(X)[r,q] = alpha z_(r,q).

It computes the entire returned D-by-D matrix in O(nm^2D^3) rational operations by naive dense multiplication, or less with this sparse clock/parity representation. The output contains D^2 field elements and is fully charged. A prefix query of the inherited residual learner can also be evaluated using this now explicit model, with its actual larger D.

Let eta have H encoding bits and every queried rational X entry at most P bits. One common denominator for all learned transition entries and all X entries has polynomial bit length in m,n,D,H,P. Each finite path uses fewer than D X transitions, and every scalar block is a sum of at most (nmD)^D products. The numerator and denominator bit lengths are consequently polynomial; a deliberately loose sufficient bound is

    O(D [nm^2H+nD^2P+log(nmD)] + mH).

Fraction-free/common-denominator arithmetic therefore gives a polynomial bit implementation. Matrix-oracle costs are subsequent local execution costs, added to the reset/symbol/training/certification costs above. A speed or learning advantage over direct decoding is not established: direct decoding creates the identical explicit model and identical matrix-evaluation capability.

## 8. Comparator, limits, and significance

The primary comparator receives the same raw reset paths, d, noise knowledge/bias bound, repetition opportunity, and runtime budget. It majority-decodes labels, solves GF(2), and directly emits the clock/parity model. The adaptive-feature description is a useful proof of a predictive margin, but adds no scientific acquisition advantage over this control. All repeated measurements, held-out certificates and noise calibration are charged. No state observation, matrix table, off-distribution teacher, or label-preserving intervention was granted to only one method.

The consequential conclusion is an observation-interface separation:

* A one-shot noisy parity clock already has a short accurate predictor and a constant-margin adaptive cut bank; discovering either in general polynomial time would solve LPN.
* Persistent independent noisy readout of the same latent bit makes dense feature discovery possible with explicit polynomial reset/symbol/bit costs.
* A supplied sparse support bound supplies another polynomial specialization, with its D-dependent search cost visible.

Persistence is a structural assumption of the class and should be tested or justified on any application. These examples do not settle adaptive acquisition for general mixing HMMs, arbitrary noisy low-rank processes, or the broad local-intelligence objective. They identify exactly what observation changes an intractable feature-discovery problem into an explicit usable one.

## 9. Primary prior-art check and written proof versus execution

[Kearns, Mansour, Ron, Rubinfeld, Schapire and Sellie, *On the Learnability of Discrete Distributions*, STOC 1994](https://people.csail.mit.edu/ronitt/papers/learndist.pdf), Section 6.1/Theorem 16, PDF pages 8-9: the same two-track noisy-parity probabilistic automaton and a representation-independent hardness claim for learned evaluators are established prior. They explicitly distinguish evaluators from generators. This was read in the primary author manuscript, including the theorem and proof sketch. Theorem A is an interface/TV/arbitrary-prefix/search extraction specialization of that older mechanism, not new general hardness.

[Feldman, *On the Power of Membership Queries in Agnostic Learning*, JMLR 2009](https://jmlr.csail.mit.edu/papers/volume10/feldman09a/feldman09a.pdf): the primary paper discusses finding heavy Fourier coefficients of bounded probabilistic label functions by membership access and the Goldreich-Levin algorithm. The bucket proof above is written out rather than treating its learned-model access or query costs as free. No new Fourier-recovery method is claimed.

[Petreczky, *Realization theory for linear and bilinear switched systems: A formal power series approach*, 2011](https://www.numdam.org/item/10.1051/cocv/2010015.pdf), Section 2.1: bilinear trajectories, rational generating series, finite Hankel rank, and minimal realizations are established prior. This source was read at the displayed introductory/realization section, not throughout its switched-system proofs.

[Petreczky, Toth and Mercere, *Realization Theory for LPV State-Space Representations with Affine Dependence*](https://arxiv.org/abs/1601.02777) gives an established finite-Hankel-rank/Ho-Kalman realization comparator. Its primary abstract and metadata were read; its complete proof was not reconstructed here.

[Sattar, Jedra, Fazel and Dean, *Finite Sample Identification of Partially Observed Bilinear Dynamical Systems*, 2025](https://arxiv.org/html/2501.07652v1), Section 6 and Proposition 2: realistic partially observed controlled identification charges quantitative stability and expanded Markov-like features with exponential dependence on history length. Those passages and the displayed bound were read. This corroborates the need to specify an excitation/readout interface; it does not provide our repeated-parity decoder or a universal matrix oracle.

Majority decoding, GF(2) rank bounds, sparse correlation search, two-point conditioning, and singular-value perturbation are elementary established tools. Theorem B and the acquired-matrix-oracle/certified-cut-margin composition are derivations at the precise interface here. Historical priority of that composition was not cleared, and a special-class construction is not a foundational breakthrough.

Executed diagnostics: `work/acquisition_attack_check.py` and `work/acquisition_attack_check.json` in this workspace. PASS: 2,088 exact rational adaptive-cut moment calculations; 246 exact real-valued Fourier bucket identities; 20 decoder fixtures at d=4,8,16,32,64 with eta=1/4 and confidence input delta=.01. All masks were recovered using only the episode callable, d, beta and delta. All 20 true-mask certificates were accepted and all 20 one-bit-wrong masks rejected. Charged symbols: 78,044 for decoding, 422,604 for true-mask validation, and 422,604 for negative-control validation. Target masks were consulted only outside the decoder for auditing. These fixtures are not a LPN solver, a universal proof, an advantage benchmark, or evidence of external mathematical validation.

## 10. Deprioritized controlled-jet interpretation

The Volterra base queries also have a direct controlled-differential-equation interpretation. For an inaccessible plant

    x'(t)=sum_i c_i(t) B_i x(t)+v b(t),    y(t)=u x(t),

choose `c_i(t)=ell/(t+i)`, `b(t)=a'(t)`, and `x(0)=v a(0)`. Its integral equation is `x=v a+sum_i ell B_i J_i x`, so the first d output Taylor coefficients for `a=t^q`, q=0,...,d-1, form the full matrix `f(ell T)`. No hidden matrix is read. However, exact high-order output Taylor jets are a strong additional service; ordinary finite noisy output samples do not automatically supply them. This branch was not promoted into a practical oracle-acquisition theorem, because the inherited passive construction already crosses the observational-interface gap more directly and retains the honest conditioning cost.

## Memory guidance used

The only memory material used was `MEMORY.md:741-746`, to preserve executable obstruction/competent-comparator and accounting requirements. No mathematical theorem or current workspace fact was inferred from memory. Associated prior rollout IDs: `01a0e5e2-d835-73f1-bdd2-c3f71e6b572a` and `01a0e38f-8e24-7582-8676-765fd6f13a5f`.
