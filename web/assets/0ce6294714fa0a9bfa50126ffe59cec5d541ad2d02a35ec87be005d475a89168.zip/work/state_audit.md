# Research-state audit — 7 October 2026

This is a state and dependency audit, not mathematical certification. The full 175-line attachment and full 453-line latest capability state were read, along with current scientific summaries and selected branch reports. No source workspace was changed. Original research suites and release Lean builds were not replayed.

The decisive update is that several apparent opportunities in the attachment have already been pursued. Converting Volterra detection into passive bounded observations, improving collision Gaussian comparison to an n^(-1/2) remainder, adding finite PEPS coefficient bits, supplying a named erased commuting-verifier wrapper, and obtaining bounded-degree algebraic witnesses are now recorded results. Their remaining acquisition, conditioning, encoding and validation boundaries should drive the next work.

## Evidence and status

The complete attachment was read at /Users/harjas/.codex/attachments/2f87408a-6b4c-49c5-b868-d29f20d801d1/Pasted text.txt. Its local-symbol conventions, X/D/!/? labels and reported-unreplayed checks remain attached to its claims.

Current Literature Digestion files read: NOW.md; results/root_cycle19/REPORT.md and CLAIM_LEDGER.json; leads/PROGRAMMES.md; and current tensor, quantum, probability, equilibrium-method and acquisition branch reports. The notes index was used as navigation. Root path: /Users/harjas/Documents/ChatGPT/Literature Digestion.

Current follow-up quantum files read: outputs/RESEARCH_STATE.txt, the later selective-tensor construction, and relevant live audit openings under /Users/harjas/Documents/Codex/2026-10-07/you-have-access-to-over-100-2. The spectral_collision_evidence.zip member inventory has 113 members. This removes the older factual “missing quantum pack” blockage, but not proof validity, priority or circuit-compilation debt.

Latest follow-up capability state read in full: /Users/harjas/Documents/Codex/2026-10-07/you-have-access-to-over-100-5/outputs/RESEARCH_STATE.txt. Its underlying complete proofs were not all reread in this audit.

Literature Digestion still labels its imported collision result UNAUDITED; the later package supplies internal audits. Those labels describe different reviews and are compatible. No external source claim below is adopted beyond its saved report's read scope.

The discovery index reports metadata/integrity issues and explicitly does not independently verify worker dates, authors or read depths. There are 722 catalogued manuscripts in 372 families. Literal family assessment is not full proof reading or validation. The memory registry was used to locate the later quantum work; relevant current facts were then live-read.

## Delta ledger: do not rediscover these results

| Older opening | Later recorded advance | Current obligation |
|---|---|---|
| A useful cyclic matrix detector/learner | Cycle19 has compact scalar-grid detection and exact output-only learning; release116 already implies larger polynomial cyclic capability | Useful inexpensive oracle and precision/height accounting; compactness is the increment over the post-release baseline |
| Matrix detection has no passive observation interface | Follow-up -5 supplies a deterministic bounded occupation-test bank and universal rank(H)=r | Adaptive conditioning or a predictive certificate without a supplied singular margin |
| Gaussian jitter has n^(-1/8) cutoff loss | Follow-up -5 integrates reciprocal-gap costs and reports O_d(delta+n^(-1/2)) | Independent adoption, sharper storage/accuracy laws, nontracial partial collisions, growing d, circuits |
| Correlated archives absent | Follow-up -5 gives an ordered-phase Vt archive and critical Theta(1/D) error law | Physical premise validation, acquired sector/multiplicity operations, unknown magnitude, joint-limit rate |
| PEPS coefficients have uncontrolled bits | Follow-up -5 gives polynomial description and O(L^2 log L) coefficient bits | Discover useful tensors; generic preparation/observable access meets isolated-SAT barriers |
| Repetition needs any named certified-gap application | Follow-up -5 gives 1/4 erasure, gap >1/15 and a charged Lin-verifier all-wins wrapper | Preserve the recursive normal form or construct an honest positive encoding |
| Algebraic witness existence is qualitative | Follow-up -5 gives degree <=3r-2 witnesses by exact linear algebra | Acquire multiplication-table/generator inputs or apply the witness meaningfully |
| Exact-mean rounding lacks stable local use | Follow-up -5 gives finite anchor laws and a retained-label Gaussian interface | Validate imported hard rounding and acquire anchor/covariance data and margins |
| Better full-MM exponent might solve arbitrary masks | All-field 9/4 transfer, transposition, generic-trace bilinearization and block/orbit obstructions are now banked | A deterministically acquired shared mask-local circuit and the sparse rectangular endpoint remain missing |

## 1. Quantum storage

### Exact interfaces

The attachment's qubit experiment is n iid copies of the SAME unknown density matrix rho_b. Error is worst-case half trace distance on the entire n-copy density. Every input-dependent classical, quantum or hybrid register counts in D; log2 D is fixed maximum storage, not expected variable-length storage. Fresh randomness and fixed ancillas are allowed; quantum side channels and shared entanglement are absent. This is density reconstruction, not preservation of purification or arbitrary correlated inputs.

The three qubit interfaces are distinct:

* **Known radius K:** kappa=n delta^2, known delta<=1/2 and unknown direction. Recorded M<=1+2^24(1+kappa) epsilon^(-3) ln(1+72/epsilon), error <=2delta/(1+delta)+epsilon. At error <=1/8, every quantum/hybrid/classical D>=(1+kappa)/1024. Near-tracial supercritical leading storage is log2 kappa.
* **Pair/local archive P:** actual radius and direction unknown. OVERLAPPING singlet/triplet tests remove multiplicity deficiency. Count/angle storage has D=O(n^2 epsilon^(-2)), not the optimal-memory theorem. Analytic error includes eta+epsilon+sum_L p_L min(1,R_L H_L/4). Pair routing, device noise and general entangled-query execution remain separate costs.
* **Unknown envelope U:** known R<=1/2, all |b|<=R. Recorded D<=10^12(1+nR^2)^(3/2) epsilon^(-6), error <=2R/(1+R)+epsilon, matching constant-error dimension lower bound. Unknown radius changes the leading coefficient from 1 to 3/2.

Live -2 work extends fixed-d collision accounting with B_n(p)=product_{i<j}(1+n(p_i-p_j)^2). Unknown-spectrum decoding uses a fixed reference law within radial bins, never the unknown actual Schur law.

**Norm caution:** Gaussian equivalence uses ||d rho-I||op<=delta<=1/2. The live unknown-spectrum audit uses rho=I/d+X, ||X||F<=delta<=1/(2d). They convert up to fixed-d constants, but their deltas and numerical constants cannot be silently identified.

The strongest later Gaussian candidate uses state-independent Schur/coherent channels and the Gaussian N(sqrt(n)(rho-I/d),I_HS/d), with reported O_d(delta+n^(-1/2)) error. Tent interpolation gives an epsilon^(-(d^2-1)/2) alphabet factor with signal/tail terms. The error floor still contains O_d(delta+n^(-1/2)); it does not dominate the older direct code at much smaller epsilon.

### Adoption obligations already present as written arguments

These are validation gates, not lemmas that nobody has attempted:

1. Finite-spin/flag coherent minorant and uniform coherent-to-HCIZ conditional replacement. The two laws are not identical.
2. Exact Schur/HCIZ cancellation and all normalization, trace-hyperplane and lattice-covolume factors, including collision limits.
3. Vandermonde and gamma variation inside jitter cells. Ordinary jitter is not an exact smooth density identity.
4. Uniform translated-Gaussian small gaps and later integrated capped reciprocal-gap errors.
5. Weighted flag averaging with metric/volume/Poincare bounds; bracket bounds alone do not supply it.
6. Fixed reference-sector resampling and complete positive finite-bit circuit composition. Small channel diagnostics are not a built compiler.

### Outstanding scientific bridges

* **Sub-delta precision:** the live EB lower bound is delta/20-(16/3)exp(-kappa/2), kappa>=64. It does not determine optimal retained-qubit dimension or finite classical/quantum tradeoffs. The simple order-delta conclusion needs exp(-kappa/2)=o(delta).
* **Nontracial partial collisions:** require a uniform hybrid strong-channel theorem; persistent nonzero gaps cannot inherit the purely classical near-tracial conclusion.
* **Growing d:** explicit dimension constants and actual compilation are missing.
* **Ordered phase:** the new Vt law imports j/V->m_star>0 under the zero-field total-spin law. Its critical bound lambda_alpha/(2D)-a_V <=e*<=C_alpha/D+a_V has a_V->0 without a premise-supplied rate. Joint D,V limits must pay a_V.
* **Interacting multiplicities:** acquire Gibbs sector operations and partition functions. Storage savings do not pay for them.

### Failed transfers to retain

Tomography followed by a product of the estimate adds the wrong noise. These codes preserve a mixing law, not each estimated pure tensor power. Classical storage does not erase orientation. Fixed-spectrum log(n delta) is not moving-collision log(1+n delta^2). Real-valued records are not free finite memory.

Single-site delayed queries can have a classical engine; arbitrary entangled POVMs may need quantum reconstruction. Density closeness supports later experiments fixed independently of the realized record. The later two-point obstruction blocks uniform vanishing conditional-state error for unrestricted record-dependent tests in nontrivial local experiments. Repeated preparations from one record are correlated. Purification-preserving compression near the maximally mixed state can require exponentially large retained quantum storage.

## 2. Sparse PCP and repetition

The exact open target is one common efficient isometry V for the actual amplified hard H, with P=VV*, positive sparse contractions C,B, and

    ker C=ran V; C>=gamma(I-P);
    alpha H<=V*BV<=beta H,

where alpha,beta,gamma are independent of instance size and amplification depth. Row enumeration, entries, coefficient bits, norms, invalid encodings and ALL auxiliary states must be charged/protected.

The restricted Clifford-involution construction has not established hardness of that restricted class. The actual route has general rank-one five-qubit Clifford projectors; I-2Pi is generally non-Clifford already for >=3-qubit stabilizer projectors. A two-qubit demo does not cross this mismatch.

An existing compression bound removes an unnecessary requirement: B need not preserve ran V. For CP=0, C>=gamma(I-P), 0<=B<=LI and h0=lambda_min(PBP|ran P),

    lambda_min(C+B)
      >=[gamma+L-sqrt((gamma+L)^2-4gamma h0)]/2
      >=gamma h0/(gamma+L).

This bound does not construct B,C.

Recorded obstructions:

* Same-data positive sums in the commuting Clifford-involution cone force additive approximation error >=alpha/7.
* S(S+aI)^(-1) positive block flattening has extensive norm; bounded affine syndrome families with zero-kernel reference have singleton gap <=1/t.
* Same-basis complement enforcement can require exp(Omega(sqrt t)) rows at constant gap. Changed basis/auxiliary image remains allowed.
* Common finite exact monomial lifts cannot realize universal connected logical groups. Individual gates, approximate lifts and selected tests remain outside that no-go.
* qLTC Hamming soundness is not normalized spectral gap: bounded-weight normalized stabilizer testers have gap <=k/n on one-site errors.
* Cycle19 supplies an admissible exact row-one Fourier encoder with dense positive image enforcement. For c=(1/sqrt2,1/sqrt(2m),...), gap gamma forces r>=gamma m/(2-gamma) tail neighbors in the heavy row. Sparse forward encoding does not make its adjoint/image projection sparse.
* Boolean-oracle synthesis and finite-bit PEPS repair precision only at supplied-oracle/description interfaces. They do not acquire the image, ground state or exact-zero Hamiltonian completeness.

Current commuting repetition capital is

    Pr[W_k>=ceil((v+delta)k)]
      <=exp[-sigma delta^3 k/(2048(1+log d_answer))].

It allows arbitrary commuting-operator strategies, not an identification with finite tensor strategies. Independent internal gates are recorded; external/formal validation is absent.

Follow-up -5 already gives a named wrapper: one-sided 1/4 erasure yields v_skip=1/4+3v/4, gap >1/15, and fully charged Lin-verifier all-wins amplification. Therefore seeking merely another certified-gap wrapper is stale. A consequential next application must preserve the recursive verifier's needed normal form, improve a meaningful fixed-law interface, or produce an honest positive encoding. A total effective finite-Hamiltonian conversion for every such promised commuting game meets the recorded undecidability barrier; the decidable QMA subclass is not excluded.

## 3. Discrepancy and hard rounding

The attachment D contains a detailed written PTB candidate, not a blank bridge: Boolean P=conv V, actual edge support k(P)<=k, rational unit-Euclidean columns A, rational y in P, and exact STRONG optimization returning maximizing Boolean vertices.

It claims <=dim F(y)+1 atoms, exact rational mean y, all atoms in the original minimal face F(y), and every positive-weight atom satisfying ||A(b-y)||infinity <B(k), with

    B(k)=16R^2+2K+8k+1<=1161k;
    K=64k, R=floor sqrt K.

Matroid k=2 gives B=2209; independence access is converted via rank, integer SFM and rational LP. A favorable response for every rational objective is converted by an infeasible-separator transcript into an exact mean law. Favorable access is not optimization over the good set.

The exact-mean radius lower bound k(P)/2 and upper O(k(P)) concern ACTUAL edges. Intersections, coupled bases and prefixes may have long joint edges.

Load-bearing adoption/implementation gates:

1. Current ORIGINAL-face tangent reserve, protected barriers and singular diagonal-trace lemma.
2. Perron regularization on the full active ambient coordinates, exact flatness and C^(2,1) third-order control.
3. Shifted Hessian restriction in the physical metric before restriction to an ill-conditioned face basis.
4. Exact current-face/cost-slice repair with input-bounded bits; tiny geometric margin is paid in bits.
5. Cleanup/reset/tracking/deletion and arbitrarily short face-hit composition into a global potential decrease and move bound. Artificial spectral fixtures are not complete trajectories.
6. Strong-oracle face/span/endpoint implementation; true separator-system infeasibility; exact mean extraction and affine reduction.

The state gives arguments for these gates. The honest missing ingredient is full independent proof composition and end-to-end exact rational execution. It does not report an executed full rounder/compiler. The initial Hessian finite-difference failure is preserved, not erased.

Failed transfers: ordinary symmetric exchange does not give an exchange cube (K4 Hall failure); independent mean-preserving pair laws can have large feature error; exact hard balance forces correlations; cost slices can be fractional; coordinate dyadic rounding can miss their affine space. Activity-fixed spectral independence is not uniform hard feasibility. Matrix-cube and variance-normalized diagonal examples obstruct automatic operator Komlos transfer. Terminal rounding does not solve unrestricted fixed-order/prefix Komlos.

Later -5 stable finite anchor laws and retained-label Gaussian bounds are already banked. Anchor/covariance acquisition, latent KL/transport cost, geometric margins, retained-label bits and finite observation precision remain charged. Those results do not independently validate the imported hard-rounder.

## 4. Selective tensors

Given polynomially bounded integer X in Z^(N x D), Y in Z^(D x N), and arbitrary supplied W, the open target is

    D=N^(1/4), |W|<=N^(15/8), O(N^(2-eta)),
    fixed 0<eta<1/8.

Charge reading, mask acquisition, encoding, preprocessing, arithmetic, output incidence, decoding and bits.

Later -2 improves the attachment:

* D<=N^(1/8), |W|<=N^2/sqrt D: deterministic O(N^2/D^0.0018).
* D<=N^(1/7), |W|<=N^2/D: deterministic O(N^2/D^0.0045).

The stated model is O(log N)-word RAM for polynomially bounded input integers. The public source's D^(8.3048...) tile constraint and later internal tail-relaxed parameters should not be conflated. Neither reaches the target. All-field 9/4 is an arithmetic-exponent consequence, not acquired finite rank/bit/selective compilation.

### Fresh obstruction to tuning the current certificate

This is an own deduction using the stated COMPLETE-ARRAY ten-term encoding accounting, not an unrestricted lower bound for all selective algorithms. With |W|<=N^2/D^kappa_mask, its certificate charges

    polylog(D)[N D^E(c)+N^2 D^g(c,theta)
                         +N^2 D^(q(theta)-kappa_mask)],

where

    E(c)=[c ln10-(c-1)ln3
               -(c ln c-(c-1)ln(c-1))/2]/ln4;
    q(theta)=[-theta ln theta-(1-theta)ln(1-theta)
                                      +theta ln9]/ln4.

Geometric tail decrease requires c>10(1-theta). At the target kappa_mask=1/2, strict saving requires q(theta)<1/2. q is increasing to theta=9/10, q(1)>1/2, and q(1/4)>1/2; hence theta<1/4 and c>15/2.

E'(c)=[ln(10/3)-(1/2)ln(c/(c-1))]/ln4 is positive there. Moreover E(15/2)>6 is equivalent to the exact integer inequality

    4*10^30*13^13 >4^24*3^26*15^15.

This inequality was checked exactly in this audit; E(15/2)≈6.2439 is only a diagnostic. The target needs E(c)<4, in fact <=4-4eta. Thus parameter tuning cannot make this charged complete-array/tail certificate reach the target. A lazy/shared mask-specialized encoding is a different mechanism and is not excluded.

### Remaining circuit bridge

Cycle19: a value-independent circuit for (Z_W,Y)->Z Y^T can be contracted with X and reverse differentiated for O(T+ND+|W|) arithmetic plus circuit acquisition/tape. A value-dependent zero-pruned trace is not automatically this circuit.

Follow-up -5 handles division singularities at zero by acquiring a bounded-degree generic trace at a regular field point, capping at a public budget, bilinearizing and transposing, including characteristic two if the algorithm is correct over the extension. The deterministic trace hitset and fast sparse rectangular endpoint circuit remain missing.

Legal masks force Omega(N^2) for independently charged complete-block covers; cross-block shared arithmetic is allowed. FSMM endpoint sketches can retain the original hard product; replacing ambient dimension by sqrt(nnz(input)) was retracted. Small missing fractions of full output orbits can contain EVERY requested output.

The needed new lemma is a shared mask-local circuit/packing with full encoding exponent below four and explicit requested-coordinate access acquired without N^2 work. Rank, dual exponents, field descent and full-MM results alone do not give it.

## 5. PIT and two learning barriers

### Commutative PIT

The attachment maps a commutative ABP p to a homogeneous pencil M with supplied scalar rank N-1, whose commutative rank is N iff p!=0. A supplied 2x2 noncommutative blowup has full rank in BOTH cases, because an added commutator supplies invertibility. Symmetric dilation preserves this blindness.

The surviving question is identity AFTER abelianization of a path series, modulo commutator relations, despite a short free-field description. Noncommutative fingerprints distinguish words that may cancel when commuting. Exact matrix learning, the observable bank and noncommutative rank do not acquire that quotient identity. Approximate commutative rank is not exact nonsingularity; the codimension-one scalar promise is insufficient. No unconditional commutative PIT algorithm/lower bound is established.

### Passive finite-state processes: population acquisition is now bridged

Latest -5 interface: independent resets, alphabet n, real linear representation of minimal dimension r<=m, no hidden transitions/basis/interventions/matrix oracle. With d=2nm and K=1+md(d-1)/2, explicit stochastic occupation controllers give rank H=r and M=K+(n+1)K^2 bounded moments, each of horizon <=4nm-1.

Exact moments give a minimal signed realization. With supplied sigma<=sigma_r(H), horizon T, target epsilon and failure rho,

    eta=epsilon sigma^3/(300 n K^4 T);
    N>=ln(2M/rho)/(2eta^2).

The signed positive-part repair gives an efficient length-T sampler. It does not give a positive minimal HMM or uniform rare-history conditional prediction. A complete rounded SVD/recurrence implementation remains unfinished.

For ANY M fixed bounded single-path tests, the latest parity-clock obstruction supplies an O(L)-state positive process P with TV(P[1:L],fair iid)=1/2 but moment difference <=sqrt(M/[4(2^L-1)]). The particular Volterra bank can be even less visible. Public rational heights permit finite exact recovery but exponential sample cost. Another fixed polynomial bounded bank cannot solve uniform conditioning.

This does not block adaptive batch computation: raw noiseless paths allow elementary parity discovery. The next substantial bridge must acquire features or prediction certificates on a declared useful class from the same legal data, with direct algebraic/parity, ordinary spectral and retained-data comparators.

### Uniform low-degree latent sampler

The separate graph construction needs superpolynomial suppression of each fixed-size evaluation-vector relation. Random RM points contain affine-flat identities; flat avoidance alone fails because symmetric differences yield non-flat relations. The open object is an efficient uniform high-girth/dual-distance evaluation-matroid sampler with the specified low-degree description. Primal distance, ordinary hitting sets and hidden polynomial subspaces do not solve it. Divergent low-degree norm is not by itself strong two-sided detection.

## 6. Other supply boundaries

* **Gaussian chirality:** labelled covariance spectra, occupations and ORDERED modular commutators recover a gauge orbit with nonzero root spokes. Entropies/unlabelled spectra are weaker. Weak links give J=O(t^3); interaction-stable and size-uniform reconstruction error remains missing.
* **PDE:** direction-VMO coherence exceeds finite-energy NS assumptions. Forced singularity does not remove forcing. No unrestricted NS result follows.
* **Sunflower:** rooted clean-code obstruction applies to that strategy; its certificate block is omitted. Bounded VC does not acquire product-quotient control.
* **Mean-response sampling:** cycle19 finite SR reduction uses O(n log^2(n/epsilon)/epsilon^2) complete mean queries with charged precision. Support-search and rare tilted-event examples block generic acquisition. A supplied DPP matrix has faster standard samplers and is a control.
* **Replica mixing:** all-additive pair control can replace full pair gap, but needs acquired bottom refresh/stationarity and all-additive C. Adjacent-law closeness can leave C=1/(4p) exponential in input bits.
* **Conditional route sampling:** the report proves a heat-bath/service-call reduction, not continuous base-factor/collision/target-set or equilibrium outside-marginal acquisition.
* **PEPS:** finite bits close representation only. Matching-promise product ground states encode isolated SAT: efficient classical root access/sampling implies SAT in RP; quantum preparation/root access implies NP in BQP. Arbitrary tensor-description output alone is not assigned that hardness without a decoder.
* **Algebra witnesses:** degree <=3r-2 and exact linear algebra are supplied under central-simple multiplication tables/generators. Acquire inputs or apply them; do not rederive the qualitative existence lemma.
* **Geometry/fields:** finite global-rank stabilization is obstructed, while locally finite or compact-dependent ranks survive. Relative field reconstruction supplies no finite-query protocol.
* **Kinetic paths:** conditional integrated L2 fluctuation is now supplied. Raw uniform/Skorokhod convergence fails the spike test; microscopic centering and prescribed lifespan remain.

## 7. Opportunity candidates and obligations

These are provisional research targets, not promised discoveries.

### A. Adaptive predictive feature acquisition

Question: on a declared useful finite-state class, can data-dependent bounded tests and a predictive certificate replace supplied sigma at affordable reset, arithmetic and bit cost?

Owned: universal population rank, bounded observations, conditional sampler, signed repair and parity obstruction.

Required: legal data-dependent feature selection; certified conditioning OR representation-independent finite-horizon TV; selection-bias accounting; complete rounded recurrence/sampler; equally informed spectral/retained-data/direct-algebraic controls.

Stop: fixed dictionaries meet the parity obstruction; hidden conditional teachers or supplied spanning bases relocate acquisition. Noiseless parity alone has a strong elementary baseline.

### B. Positive common auxiliary encoding for the actual hard family

Question: can a changed auxiliary image give constant normalized C-gap and positive sparse B-compression for genuine non-Clifford five-qubit seeded tests?

Owned: restricted frames, compression inequality, cone/affine/coordinate obstructions.

Required: one acquired V; both positive C and B; uniform constants; polynomial rows/entries/bits; zero completeness/all invalid encodings; actual hard-input coverage.

Stop: same-coordinate penalties, unrestricted lookup tables, two-qubit demos and game repetition do not meet this interface.

### C. Shared selective encoding at D=N^(1/4)

Question: can a shared mask-local circuit defeat independently charged block covers with full encoding exponent below four?

Owned: tail relaxation, all-field transfer, transposition, generic traces and block/orbit obstructions.

Required: new/lazy encoding, exact incidence/decoding, deterministic trace acquisition if used, and end-to-end integer time O(N^(2-eta)).

Stop: tuning the current complete-array certificate is blocked above; full-MM exponent substitution is insufficient.

### D. Sub-delta precision versus retained quantum memory

Question: for iid qubits with delta->0, kappa->infinity and e=o(delta), determine finite classical/quantum storage tradeoffs.

Owned: classical coarse-precision codes and EB lower bound.

Required: converse for LIMITED quantum dimension with all classical bits charged; matching constructive hybrid code; uniform moving-gap constants. Choose exp(-kappa/2)=o(delta), or pay the remainder.

Stop: EB impossibility is not a retained-qubit dimension lower bound; purification preservation changes the problem.

### E. Consequential normal-form-preserving repetition

Question: can the named erased commuting wrapper preserve the recursive structure needed downstream, or encode a decidable restricted Hamiltonian family?

Owned: commuting threshold proof, certified erasure gap, named final wrapper.

Required: exact normal-form preservation OR positive encoding; full verifier costs; external/formal validation and prior anchored comparison.

Stop: another generic erasure wrapper repeats existing work; universal finite-Hamiltonian conversion meets undecidability.

### F. Validate and execute hard rounding

Question: does a charged exact rational implementation satisfy the global proof/oracle contract, including rank-face hits with every coordinate fractional?

Owned: detailed written spectral/geometry/precision construction and stable-anchor consequences.

Required: hostile proof-composition reconstruction; end-to-end strong-oracle/matroid path; exact mean/face/feature checks; input-bounded persistent bits and retained failures.

Stop: local Hessian checks/output LPs are not the rounder. This is valuable validation, not by itself a new foundational theorem.

### G. Acquire one interacting/geometric service

Choose one honest interface: ordered-phase multiplicity Gibbs operations, a useful mean evaluator, a conditional route's continuous/outside service, or a tractable PEPS subclass.

Required: declared representation/data/controls, numerical precision, complete cost and competent comparator. Isolated-SAT, support and tilt barriers restrict the class.

Stop: a supplied continuous oracle, coefficients or macroscopic physical premise cannot be acquisition-free.

## Research selection

After the latest package, the strongest new research-enabling bridge is adaptive predictive acquisition. Positive common encoding and shared selective computation remain the direct complexity targets. Sub-delta quantum memory is a narrower mathematical opportunity with explicit existing converses. The imported hard-rounder and Gaussian theorem need adoption-quality validation before further downstream claims are treated as established primitives.

The gap is obtaining a legal, stable, affordable interface or preserving final-application structure. More catalogue coverage does not close it.
