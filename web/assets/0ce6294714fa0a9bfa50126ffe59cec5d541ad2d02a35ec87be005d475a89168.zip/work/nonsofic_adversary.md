# Family 252: adversarial audit of the approximate-permutation substitution

**Finding:** the proposed substitution survives this independent audit. A direct quantitative rank argument excludes sufficiently accurate approximate permutation assignments, without correcting them to exact finite actions. Consequently, **if the release's finite incidence construction and nontrivial rectangular words are valid, its constructed group is nonsofic**. This is an independently reconstructed conditional deduction, not external validation of the release or a priority certificate.

Family 252 is **“A non-residually-finite torsion-free hyperbolic group.”** Its [manuscript](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/a-torsion-free-hyperbolic-group-that-is-not-residually-finite-September-23-2026/paper.pdf) claims non-residual-finiteness and a common nonidentity kernel element for all finite-dimensional representations over commutative fields. The [selected formalization scope](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/lean/docs/252.md) covers the torsion-free hyperbolic non-residual-finiteness statement; it does not advertise nonsoficity. No Lean or Comparator execution was performed in this audit.

I read the full introduction, history note, and **all 296 lines of construction.tex**, independently refetched the introduction and construction from the pinned release, and checked their Git blob hashes against the canonical inventory. Their SHA256 values are respectively `431371b4f398f5b955c26a6a0855d032339e9d902b53af9c48db14cf43607986` and `9ddffe7f11b0b0133f03cf60dd93947b8d47b911f3f0930c8e55512cba8d930e`. The source paths are under `work/frontier_algebra_sources/preprints/a-torsion-free-hyperbolic-group-that-is-not-residually-finite-September-23-2026/build/`. The original lengthy geometric proof was not fully read; an independent classical CAT(-1) route is given below.

## Exact conditional interface

Fix the source's finite data **before** choosing permutation dimension \(D\): an integer \(r\ge2\), prime \(q>r\), point set \(P\) of size \(m\), label set \(I\) of size \(N\), incidence sets \(I(z)\), exceptional set \(E\subset P\), and two Cartesian-coordinate blocks partitioning every regular \(I(z)\). Block \(b\) has coordinates \((\alpha_b(i),\beta_b(i))\in\mathbb Z/s_b\times\mathbb Z/t_b\), with \(s_b,t_b\ge r\). Let

\[
B=2m+r|E|,\qquad
\Delta=Nr/4-B>0,\qquad
S_0=\sum_{z\notin E}|I(z)|.
\]

The interpolation data are \(N\times N\) matrices \(H(z)\) over \(\mathbb F_q\), with rank at most one, satisfying

\[
\sum_{z:\,i\in I(z)} H(z)=-E_{ii}\quad(i\in I).
\]

In the source, \(H(z)=f(z)f(z)^T\) comes from product Lagrange interpolation, and \(S_0\le N(q-1)\). These identities are scalar linear-algebra facts; they do not depend on an exact group action.

Suppose a group contains the source's labeled elements \(x_{iuv},\ell_{buj},\rho_{bvk}\) satisfying

\[
x_{iuv}=\ell_{b,u,\alpha_b(i)+v}^{-1}
          \rho_{b,v,\beta_b(i)+u},
\]

and every nondegenerate rectangular word

\[
w_{i,u,u',v,v'}=x_{iuv}x_{iu'v}^{-1}x_{iu'v'}x_{iuv'}^{-1}
\quad(u\ne u',\ v\ne v')
\]

is nonidentity. **Under these hypotheses, the group cannot be sofic.** The proof is the following finite obstruction.

## Quantitative finite obstruction

Assign arbitrary permutations \(X_{iuv},L_{buj},R_{bvk}\in\mathrm{Sym}(D)\). Assume every triangle factorization has normalized Hamming error at most \(\varepsilon\), and every nondegenerate rectangle evaluated in these assigned permutations has fixed-point fraction at most \(\varepsilon\). Define \(Y_i=(P(X_{iuv}))_{u,v\in[r]}\), an \(rD\times rD\) integer matrix, where \(P\) denotes the permutation matrix.

**Lower rank.** Expanding the real trace moments gives

\[
\operatorname{tr}(Y_iY_i^T)=r^2D,
\qquad
\operatorname{tr}((Y_iY_i^T)^2)
\le [2r^3-r^2+r^2(r-1)^2\varepsilon]D.
\]

There are exactly \(2r^3-r^2\) degenerate index choices; their products are identity even for arbitrary assignments. Each other trace counts fixed points of a rectangular permutation. Cauchy--Schwarz on the positive eigenvalues therefore yields

\[
\operatorname{rank}_{\mathbb R}Y_i
\ge \frac{r^2D}{2r-1+(r-1)^2\varepsilon}.
\]

Each row has exactly \(r\) unit entries. The source's rank-under-reduction argument remains valid without any representation assumption: for an integer matrix of real rank \(d\) and row norm at most \(\sqrt r\), choose a nonzero \(d\times d\) minor. Hadamard bounds its absolute determinant by \(r^{d/2}\); if its rank modulo \(q\) is \(d'\), integer row operations make \(d-d'\) rows divisible by \(q\), so \(q^{d-d'}\le r^{d/2}\). Since \(q>r\), \(d'\ge d/2\). Thus

\[
\operatorname{rank}_{\mathbb F_q}Y_i
\ge D\alpha(\varepsilon),\qquad
\alpha(\varepsilon)=\frac{r^2}{2[2r-1+(r-1)^2\varepsilon]}.
\]

This argument is uniform in \(D\), including \(q\mid D\).

**Upper rank with errors.** For permutations \(p,p'\), their permutation-matrix difference has nonzero columns only where \(p(j)\ne p'(j)\). Consequently

\[
\operatorname{rank}_{F}(P(p)-P(p'))\le Dd_H\(p,p'\)
\]

over **every** field \(F\). This is the crucial error bound: it concerns support and rank, so no dimension-dependent conversion from an operator norm occurs.

For a Cartesian block \(b\), form the exact matrix factorization from the assigned \(L,R\) permutations. For each fixed \(u,v\), the shifts \((\alpha_b(i)+v,\beta_b(i)+u)\) enumerate all coordinate pairs once. Its inner dimension is \(D\), and its factor order is preserved. The difference from \(\sum_{i\in I_b}Y_i\) is a sum of \(r^2|I_b|\) embedded matrix differences, each of rank at most \(\varepsilon D\). Therefore, with \(Z(z)=\sum_{i\in I(z)}Y_i\),

\[
\operatorname{rank}_{\mathbb F_q}Z(z)
\le\begin{cases}
2D+r^2|I(z)|\varepsilon D,&z\notin E,\\
rD,&z\in E.
\end{cases}
\]

**Certificate.** The interpolation identity still holds exactly for these arbitrary \(Y_i\):

\[
-\bigoplus_iY_i=\sum_{z\in P}H(z)\otimes Z(z).
\]

Rank subadditivity and \(\operatorname{rank}H(z)\le1\) imply, after canceling \(D>0\),

\[
N\alpha(\varepsilon)\le B+r^2S_0\varepsilon.
\]

Since \(\alpha(\varepsilon)\ge r/4-r^2\varepsilon/8\), this forces

\[
\Delta\le r^2(N/8+S_0)\varepsilon.
\]

Set

\[
\varepsilon_*=
\min\left\{\tfrac12,
\frac{\Delta}{2r^2(N/8+S_0)}\right\}>0.
\]

For \(\varepsilon\le\varepsilon_*\), the inequality would give \(\Delta\le\Delta/2\). Hence **no such assignment exists, in any finite dimension**. Although the source constants are enormous, they are fixed; soficity imposes no minimum allowed approximation error.

## Why soficity supplies the forbidden assignments

Use the finite-set definition in [Arzhantseva--Păunescu, Definition 2.2](https://arxiv.org/html/1410.2626v2#S2): for any finite set of group elements and any \(\delta>0\), a sofic group has a permutation model whose multiplication errors are below \(\delta\), while every nonidentity listed element moves a fraction exceeding \(1-\delta\).

Choose one finite set containing the identity, all labeled edge-loop elements, the inverses needed in the rectangles, and every rectangular prefix product. Also include every triangle product; it equals the corresponding right-edge element. Set \(\delta<\varepsilon_*/8\). Assign \(X=\phi(x)\), \(L=\phi(\ell)\), \(R=\phi(\rho)\).

The exact group equality \(\ell x=\rho\) gives the triangle assignment error below \(\delta\). No chosen spanning-tree edge needs an exactly normalized model.

If the definition does not explicitly require \(\phi(1)=\mathrm{id}\), approximate multiplication of \(1\cdot1\) gives \(d_H(\phi(1),\mathrm{id})<\delta\). Each inverse substitution then costs at most \(2\delta\). A rectangle contains two inverses, and comparing its four-factor evaluation with \(\phi(w)\) uses three prefix multiplications. Total comparison error is below \(7\delta\). Because \(w\ne1\), \(\phi(w)\) has fixed-point fraction below \(\delta\); the actual rectangle evaluation has fixed-point fraction below \(8\delta<\varepsilon_*\). This produces exactly the forbidden assignment.

No permutation-stability theorem is used. In general, failure of residual finiteness alone would be insufficient: [Arzhantseva--Păunescu, Example 7.3](https://arxiv.org/html/1410.2626v2#S7.SS1) discusses sofic non-residually-finite Baumslag--Solitar groups, while their Theorems 4.2--4.3 explain the additional stability route. Hyperbolicity does not itself provide that stability; [Alekseev--Thom, Corollary B](https://arxiv.org/html/2512.15494v1) even gives a residually finite hyperbolic group failing flexible permutation stability. Here the stronger, perturbation-resistant rank certificate supplies the obstruction directly.

## Independent geometric shortcut and remaining source gate

The source's link-combinatorics can be checked without its lengthy Euclidean thinness proof. Give every attached triangle a hyperbolic metric with angles

\[
(27\pi/50,\ 9\pi/50,\ 9\pi/50)
\quad\text{at }(O,V,W).
\]

Their sum is \(9\pi/10<\pi\), so the hyperbolic triangle exists. All triangles use one shape, and each edge type receives the corresponding common length. This changes the metric, not the fundamental group.

At \(O\), each block's link is simple complete bipartite; a cycle has at least four edges, hence length at least \(108\pi/50>2\pi\). At \(V,W\), the link projection to the punctured incidence graph is locally injective: at an \(x\)-direction a label belongs to at most one block at each point, and at an \(L\)- or \(R\)-direction the shift equation determines at most one array coordinate because \(s_b,t_b\ge r\). Therefore reduced link cycles project to reduced incidence cycles and have at least 14 edges, giving \(126\pi/50>2\pi\). A reduced link path between two distinct same-label \(x\)-directions projects to an internally reduced closed walk, which contains a simple cycle; its length is also at least 14 edges, or the directions are disconnected. Each rectangular turn thus has link distance greater than \(\pi\).

The classical link criterion and its two-dimensional form are **Bridson--Haefliger (1999), Theorem II.5.2 and Lemma II.5.6, pp. 206--207**; Theorem II.5.4 gives CAT(-1) for the simply connected cover. I checked the original pages both as text and as rendered images in this [primary reference](https://webhomes.maths.ed.ac.uk/~v1ranick/papers/bridsonhaefligerx.pdf). Finite shapes and a finite base complex give a complete locally finite cover. If a strict polyhedral-complex convention requires cells to intersect in a single face, subdivide each hyperbolic triangle; the metric and original links remain unchanged, and the additional vertex links satisfy the usual \(2\pi\) condition. The deck action is proper and cocompact, so the group is word-hyperbolic. A finite-order deck transformation would fix a point in this CAT(0) space and hence be identity, giving torsion-freeness. A nonconstant closed local geodesic cannot be nullhomotopic, giving the nontrivial rectangles; the latter two consequences are also recorded in **II.4.13, p. 201**. This verifies the geometry **assuming the stated incidence data and cell gluings**. The geometric-action implication is independently recorded in [Kim--Walsh (2016), Lemma 3.9](https://academic.oup.com/jtopol/article/9/1/117/2459625).

I also read the source's incidence alteration proof: independent line directions give expected low-degree points \(O(m/q)\) and expected short-cycle counts at most \(\sum_{s=2}^6q^{2s}\); deleting at most \(6q^{13}\) cycle labels adds at most \(6q^{14}=o(m)\) exceptional points when \(h=20\). The source's fixed \(cr\ge100\) then yields its strict budget for sufficiently large prime \(q\). No counterexample to this argument was found in this pass. **An explicit admissible finite instance was not constructed, the release's selected Lean proof was not replayed, and no independent external mathematical review was acquired.** These are validation limitations, not additional hypotheses required by the probabilistic existence argument. The programme should retain the nonsofic implication as an internally audited deduction pending further adversarial review of those source hypotheses.

## Finite checks and decision

`work/nonsofic_adversary_checks.py` ran successfully and saved `work/nonsofic_adversary_checks.json`: 1,728 permutation-support/rank checks over three characteristics; all 1,296 \(r=2,D=3\) permutation-block assignments for the trace/rank bounds; 100 random shifted-block perturbation fixtures; and 30 arbitrary-assignment interpolation fixtures. These are finite transcription checks, not a universal proof or a validation of the source geometry. The proof above supplies the general perturbation argument.

**Decision:** retain the lead. The missing step is **not** permutation stability. The next falsifiable audit is the incidence construction and the exact link/cell hypotheses, together with a selected clean source/formalization check if feasible. Preserve the conditional status and prioritize finding a concrete flaw in those inputs over repeatedly questioning the approximate-permutation substitution. Novelty and external validation remain unestablished.
