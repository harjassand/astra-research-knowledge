# Independent audit: family 252 and nonsoficity

Audit date: 2026-10-07. Sources were read without modification. This is an internal mathematical audit, not external validation or a formal verification.

## Verdict

The proposed extension to **permutation approximations is sound**. I independently reconstructed the interpolation, real-rank estimate, reduction modulo the fixed prime, and error propagation. I found no missing support, normalization, dimension, or divisibility hypothesis. In particular, the model size can be arbitrary and can be divisible by the interpolation prime.

The stronger conclusion follows from the actual construction, rather than from the abstract statement that a hyperbolic group is not residually finite: the group constructed in family 252 is nonsofic. More precisely, its finite family of rectangle words contains a nonidentity word killed by every homomorphism to every sofic group.

This conclusion depends on the construction having the stated incidence data and nontrivial rectangles. I checked the source's incidence and link arguments. An independent standard CAT(-1) argument below also certifies the geometric properties, without relying on its lengthy thinness proof. The present audit does **not** establish nonhyperlinearity or failure of linear soficity.

## Exact source and imported data

The local source is:

`work/frontier_algebra_sources/preprints/a-torsion-free-hyperbolic-group-that-is-not-residually-finite-September-23-2026/build/sections/construction.tex`

The corresponding [primary source](https://github.com/openai/math/blob/main/preprints/a-torsion-free-hyperbolic-group-that-is-not-residually-finite-September-23-2026/build/sections/construction.tex) records:

- Lines 29–80: fixed integers/prime and punctured affine-line incidence data.
- Lines 82–112: the Cartesian blocks and triangle presentation.
- Lines 146–174: link bounds and nontrivial rectangle words.
- Lines 185–202: integer-matrix rank reduction modulo a fixed prime.
- Lines 204–231: exact permutation-array rank lower bound.
- Lines 239–283: local matrix factorizations and exact interpolation identity.

Fix these data once and for all: prime q > r, P = F_q^h of size m, a label set I of size N, lines l_i with distinct marks a_i in S^h, and an exceptional set E. The strict source budget is

\[
\Delta:=\frac{Nr}{4}-2m-r|E|>0.
\]

For z outside E, I(z) is partitioned into two Cartesian blocks. The coordinates in each block b are (alpha_b(i), beta_b(i)) in Z/s_b × Z/t_b, with s_b,t_b >= r. The edge generators satisfy

\[
x_{iuv}=L_{b,u,\alpha_b(i)+v}^{-1}
 R_{b,v,\beta_b(i)+u}\quad(i\in I_b).
\]

All nondegenerate rectangles

\[
w_{i,u,u',v,v'}=
x_{iuv}x_{iu'v}^{-1}x_{iu'v'}x_{iuv'}^{-1},
\qquad u\ne u',\ v\ne v',
\]

are nonidentity in G = pi_1(K). Collapse a spanning tree in K to interpret these edges as a finite generating set, assigning identity to its tree edges. This gives a genuine finite presentation, not a collection of unrelated assumed relations.

Put

\[
d(z)=|I(z)|,\qquad
S_{\rm inc}=\sum_{z\notin E}d(z)
\le N(q-1).
\]

The inequality counts each label's q-1 punctured-line incidences once. The number of triangle relations is r^2 S_inc.

## Robust finite-dimensional witness

Take an arbitrary positive integer D and assign D-by-D permutation matrices X_iuv, L_buj, R_bvk to these edges. For two permutations use normalized Hamming distance, i.e. the fraction of columns in which their images differ. Assume:

1. Every triangle defect satisfies
   \[
   d_H(L_{b,u,\alpha+v}X_{iuv}R_{b,v,\beta+u}^{-1},I_D)\le\delta.
   \]
2. Every nondegenerate rectangle product has at most lambda D fixed points.

Then necessarily

\[
\boxed{\quad
\Delta\le r^2\left(S_{\rm inc}\,\delta+\frac N8\lambda\right).
\quad}
\]

Thus the finite presentation and finite rectangle family form an obstruction with a positive error threshold independent of D. For example, simultaneous bounds delta,lambda <= epsilon_* are impossible, where

\[
\varepsilon_*=
\min\left\{\frac12,
\frac{\Delta}{2r^2(S_{\rm inc}+N/8)}\right\}>0.
\]

No attempt is made to optimize this very small threshold.

### Rectangle rank lower bound

For each label form Y_i = (X_iuv)_(u,v in [r]), an rD-by-rD integer matrix. Direct block expansion gives

\[
\operatorname{tr}(Y_iY_i^{\mathsf T})=r^2D.
\]

The second trace contains 2r^3-r^2 degenerate index choices, each contributing D, and r^2(r-1)^2 nondegenerate choices, each contributing at most lambda D. Therefore

\[
\operatorname{tr}((Y_iY_i^{\mathsf T})^2)
\le[2r^3-r^2+r^2(r-1)^2\lambda]D.
\]

Cauchy–Schwarz on the positive eigenvalues gives

\[
\operatorname{rank}_{\mathbb R}Y_i
\ge\frac{r^2D}{2r-1+(r-1)^2\lambda}.
\]

Every row has exactly r unit entries in distinct block columns. If d is its real rank, a nonzero d-by-d integer minor B satisfies |det B| <= r^(d/2). If d' is the rank of B modulo q, integer row operations make d-d' rows divisible by q, so q^(d-d') divides det B. Since q > r, d' >= d/2. Consequently

\[
\operatorname{rank}_{\mathbb F_q}Y_i
\ge\alpha(\lambda)D,
\qquad
\alpha(\lambda):=
\frac{r^2}{2(2r-1+(r-1)^2\lambda)}.
\]

This determinant argument never divides by D in the field. The ordinary integer D enters only as a dimension in numerical inequalities. In particular q | D is harmless.

Writing a = 2r-1 and b = (r-1)^2,

\[
\alpha(0)\ge r/4,
\qquad
\alpha(0)-\alpha(\lambda)
\le\frac{r^2b\lambda}{2a^2}
\le\frac{r^2\lambda}{8}.
\]

The last inequality uses b/a^2 <= 1/4 and has no small-lambda assumption.

### Triangle rank upper bound

By Hamming bi-invariance, the triangle hypothesis is exactly

\[
d_H(X_{iuv},L_{b,u,\alpha+v}^{-1}R_{b,v,\beta+u})\le\delta.
\]

Its matrix difference has at most delta D nonzero columns. Its rank over F_q is therefore at most delta D. No repair to an exact representation is used.

Within each Cartesian block, summing the ideal products gives the exact factorization

\[
\left(\sum_j L_{b,u,j}^{-1}\right)_{u\in[r]}
\left(\sum_k R_{b,v,k}\right)_{v\in[r]},
\]

with inner dimension D. For each fixed u,v, the shifted coordinate pairs run over all (j,k) exactly once. Matrix order is unchanged; commutativity is unnecessary.

Each triangle error is embedded into a single block of the rD-by-rD matrix. Rank subadditivity therefore gives, for Z(z) = sum_(i in I(z)) Y_i,

\[
\operatorname{rank}_{\mathbb F_q}Z(z)
\le2D+r^2d(z)\delta D\quad(z\notin E).
\]

For z in E the ambient bound rank Z(z) <= rD suffices, including all its actual incidences.

### Exact interpolation and contradiction

Let f_i be the source's product Lagrange polynomial, and let H(z) = f(z)f(z)^T. These are N-by-N scalar matrices over F_q, with rank H(z) <= 1 and H(a_i) = E_ii. Their degrees on an affine line are below q-1, hence their full-line sums vanish in characteristic q. Omitting only the line's own mark yields

\[
\sum_{z:\ i\in I(z)}H(z)=-E_{ii}.
\]

The consequent identity

\[
-\bigoplus_iY_i=\sum_{z\in P}H(z)\otimes Z(z)
\]

holds for **any** matrices Y_i of the common size. It does not require exact triangle relations or a homomorphism.

Dimensions are explicit: both sides are NrD-by-NrD; H(z) is N-by-N, Z(z) is rD-by-rD, and each local ideal factor has inner dimension D. Rank subadditivity and tensor-product rank now give

\[
N\alpha(\lambda)D
\le[2m+r|E|+r^2S_{\rm inc}\delta]D.
\]

Cancel the positive numerical dimension D and insert alpha(lambda) >= r/4-r^2 lambda/8. The boxed robust inequality follows. Setting delta,lambda <= epsilon_* would imply Delta <= Delta/2, a contradiction.

## Passage from soficity to the finite witness

Soficity supplies generator permutations whose relators have arbitrarily small Hamming defect and whose fixed finite family of nonidentity words has arbitrarily small fixed-point fraction. This is the standard finite-presentation form of sofic approximation.

To see the passage explicitly, include the identity, each edge element, its inverse, each prefix of every triangle and rectangle word, and their products in a finite subset of G. A sufficiently accurate almost multiplication map on this finite set makes products of generator permutations close to the images of all these words. Inverse products introduce only finitely many additional errors, independent of D. Tree-edge images can be chosen as identity.

If one starts with the weaker separation form of the definition, take a fixed Cartesian power of each permutation model. For each nonidentity word, its fixed-point fraction is raised to that power. The power can be chosen using the finite family's positive minimum separation; multiplication defects grow by at most this fixed factor and can be made arbitrarily small beforehand. Thus both delta and lambda can be made smaller than epsilon_* simultaneously. This contradicts the witness.

The [Pestov primary exposition](https://arxiv.org/html/0804.3968v8), Theorem 3.5 and its amplification proof, confirms this finite approximation interface. No global almost homomorphism or correction theorem is required.

The same argument applies to any homomorphism G -> H into a sofic group that keeps all rectangle words nonidentity. Consequently no such homomorphism exists. If every rectangle survived in some sofic target, the finite product of these targets, with the product homomorphism, would preserve all rectangles. Finite products and subgroups of sofic groups are sofic. Therefore at least one fixed nonidentity rectangle is killed by **all** homomorphisms into sofic groups. Which rectangle it is remains unidentified.

## Independent geometric check

The incidence proof is a valid probabilistic alteration argument. With h = 20 and the other constants fixed, the expected number of cycles of length at most 12 is O(q^12); with probability tending to one it is at most q^13. Deleting all participating labels removes at most 6q^13 labels and affects at most 6q^14 points, both negligible relative to q^20. The degree estimate and strict rank budget then hold for sufficiently large primes. The proof counts only distinct labels when invoking independence and allows repeated geometric lines without invalidating the upper bound.

At O, each block's link is a simple complete bipartite graph. A direction pair determines exactly one label via the Cartesian coordinates, so reduced cycles have at least four corners and original angular length at least 12pi/5. At V and W, the link map to the punctured incidence graph is locally injective: s_b,t_b >= r prevents collisions among the shifted indices. Reduced cycles consequently have at least 14 corners. A reduced positive path between distinct same-label x-directions maps to a closed walk with no internal reversal, which contains a simple cycle even if its closing seam reverses. Its length is therefore at least 14 corners, or no such path exists.

All triangles have the same Euclidean shape and compatible side lengths. Replace each with the hyperbolic triangle whose side lengths are t times the original lengths, for t > 0 sufficiently small. Hyperbolic corner angles converge to their Euclidean counterparts as t -> 0. Choose t so each new angle is at least 11/12 of its original angle. The shortest reduced link cycles then have lengths at least

\[
\frac{11}{12}\frac{12\pi}{5}=\frac{11\pi}{5}>2\pi,
\qquad
\frac{11}{12}\frac{14\pi}{5}=\frac{77\pi}{30}>2\pi.
\]

The finite complex is locally CAT(-1) by the metric link criterion. Its universal cover is CAT(-1) by Cartan–Hadamard. It is proper, and the deck action is proper and cocompact. This gives word hyperbolicity; a finite-order deck transformation would have a fixed point in the CAT(-1) cover, so the group is torsion-free.

The same-label turn distances stay at least 77pi/30 > pi. Each rectangle is consequently a closed local geodesic in this new metric. A nullhomotopic rectangle would lift to a positive closed local geodesic in a CAT(-1) space, which is impossible. This independently verifies the nonidentity input.

This shortcut uses standard CAT(-1) link and local-to-global theorems (Bridson–Haefliger, *Metric Spaces of Non-Positive Curvature*, the source's BH1999 reference). It does not purport to verify every sentence of the source's separate self-contained Euclidean geometry proof.

The cover is contractible, so this very same finite two-dimensional complex is a K(G,1). The construction therefore also supplies a nonsofic group with a finite two-dimensional classifying space and a geometric action on a proper CAT(-1) space.

## Boundaries and adversarial counterexamples

**Arbitrary invertible matrices / linear soficity.** The rectangle rank lower bound is a permutation statement. Full rank of I minus every rectangle does not imply the required rank of Y. Over C, or F_q with q > 3r, set

\[
X_{uv}=(a_u+b_v)I_D,
\qquad a_u=u,\quad b_v=r+v+1.
\]

Every block is invertible. For u != u' and v != v', the rectangle scalar differs from 1 because

\[
(a_u+b_v)(a_{u'}+b_{v'})
-(a_{u'}+b_v)(a_u+b_{v'})
=(a_u-a_{u'})(b_{v'}-b_v)\ne0.
\]

Thus every such rectangle has rank(I-R) = D, whereas rank Y = 2D for r >= 2. For the source's huge r this violates the attempted rD/2 bound. This is a counterexample to a replacement lemma, not a global approximation of G. A different argument might address linear soficity, but the audited proof does not do so. The [Arzhantseva–Paunescu paper](https://www.mat.univie.ac.at/~arjantseva/Abs/sofic.pdf), Theorem 1.3, places soficity inside the larger class of linear sofic groups; the implication cannot be reversed by contraposition.

**Hyperlinearity.** Small normalized Hilbert–Schmidt defects need not have small rank: exp(it)I_D is arbitrarily close to I_D in that norm, while exp(it)I_D - I_D has rank D for every nonzero small t. This invalidates the triangle rank-error bound for general unitary models. Additionally, the integer-minor reduction argument cannot be applied to arbitrary complex unitary entries, and the interpolation's characteristic-q power-sum identity has no direct characteristic-zero lift. Nonsoficity alone therefore supplies no conclusion about hyperlinearity or Connes embeddability of L(G).

**Other conjectures.** Failure of soficity does not alone produce a direct-finiteness, determinant, or surjunctivity counterexample. The group has no sofic embedding and is not residually amenable, since amenable groups are sofic and products of sofic targets are sofic. The standard exactness of hyperbolic groups also makes it an exact nonsofic example. Its nonamenability follows already from nonsoficity.

## Prior art and novelty scope

The [Pestov exposition](https://arxiv.org/html/0804.3968v8), Open Question 9.2, records the separate question whether every hyperbolic group is hyperlinear or sofic. The audited extension answers the sofic part and leaves the hyperlinear part untouched.

[Chapman–Peled, *Cocycle stability in permutations of random simplicial complexes*](https://arxiv.org/html/2509.21566v1), Theorem 1.1, gives a **conditional** path to nonsofic hyperbolic groups through an unproved stability hypothesis. It does not establish the unconditional result derived here.

[Kun–Thom, *Nonsofic wreath products of residually finite groups*](https://arxiv.org/html/2608.06222v3) (August 2026), Theorem A, establishes additional nonsofic wreath products and doubles using property (T). Its discussion of hyperbolicity at the introduction concerns a hyperbolic group with a **nonsofic p.m.p. action**, not a nonsofic hyperbolic group. These notions must not be conflated.

[OpenAI, *Ten Advances in Mathematics and Theoretical Computer Science*](https://cdn.openai.com/pdf/ten-proofs-oai.pdf), Chapter 3, Theorem 1.1, already establishes a nonsofic binary Leavitt-algebra unit group using an expander mechanism. Thus “nonsofic groups exist” is prior art by the audit date; the stronger geometric class is the relevant incremental conclusion.

The family-252 source and its catalogue entry themselves assert non-residual-finiteness and the common finite-dimensional linear kernel, but do not assert nonsoficity. I located no primary source giving this same robust interpolation extension or an unconditional nonsofic hyperbolic group before it. This is a bounded literature check, not an exhaustive priority certification.

## Final audit status

- Robust permutation witness: independently reconstructed, no gap found.
- Sofic finite-word passage: verified; all error constants are finite after source data are fixed.
- Source incidence and link inputs: checked; independent CAT(-1) certification supplied.
- Common kernel for all maps to sofic groups: verified by the finite-product argument.
- Nonhyperlinearity / non-linear-soficity: not established; explicit failures of naive transfer steps supplied.
- External validation, formal verification, and exhaustive priority: not claimed.
