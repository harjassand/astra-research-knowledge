# Unknown field magnitude in ordered SU(2) Gibbs archives

Date: 7 October 2026. Status: mathematical derivation from the exact invariant Gibbs decomposition and the inherited spin-coherent measure/prepare bound. The universal finite construction and the engineered lower example below do not assume a spatial magnetization theorem. Applications to a particular interacting local Hamiltonian need its own sector-law estimates. This is not an efficient Gibbs-preparation algorithm or a priority claim.

## 1. Interface and conclusions

The known data are a finite SU(2)-invariant Hamiltonian H_V, inverse temperature beta, V sites of fixed spin S, and a public radius 0 <= R_V <= 1 with R_V -> 0. One entire correlated Gibbs state is supplied:

    rho_(V,t,v) = exp[-beta H_V + t v.J] / Z_V(t),
    0 <= t <= R_V, v in S^2.

Both t and v are unknown. A single encoder and a single decoder must work for every member of this family. Every retained input-dependent register contributes to the fixed memory dimension D. Decoder randomness and known-state preparation are permitted. No input-dependent sector, continuous direction, field estimate, or auxiliary side register is free. No preshared entanglement is permitted. The converses permit input-independent common classical randomness by conditioning on its seed.

Let A_V = V R_V. The principal results are:

1. For every known invariant Hamiltonian, there is a wholly classical, parameter-independent archive with

       e <= 1-exp(-R_V) + epsilon,
       D <= C_S epsilon^(-3) (1+A_V)^(3/2),              (U)

   for 0 < epsilon <= 1/4. No macroscopic-spin hypothesis is needed. More informative versions retain the actual sector-envelope complexity rather than substituting its universal bound.

2. The exponent 3/2 is the sharp worst-case leading exponent even among systems satisfying

       under q_V^0, j/V -> m > 0 in probability.         (MP)

   An explicit known, nonlocal invariant Hamiltonian below has D >= c A_V^(3/2) at any reconstruction error <= 1/8 when A_V -> infinity. Thus MP alone does not give the known-magnitude leading cost log_2(A_V). The sharp worst-case unknown-magnitude cost is

       log_2 D = (3/2 + o(1)) log_2 A_V.

   This worst-case statement does not assert that every MP model needs the extra factor: a fixed spin sector needs only the angular alphabet of order 1+A_V.

3. Under MP, if A_V -> c in (0,infinity), the critical experiment is the entire von Mises-Fisher ball on the sphere,

       f_(alpha,v)(u) = [alpha/sinh(alpha)] exp(alpha v.u),
       0 <= alpha <= m c,

   with f_0=1. A single decoder using q_V^0, independent of t, attains

       e^*_(V,D) <= C_(m,c)/D + a_V,
       e^*_(V,D) >= [coth(mc)-1/(mc)]/(2D) - a'_V,       (C)

   for all D above a fixed chart constant, where a_V,a'_V -> 0 independently of D. There is no extra critical radial accuracy exponent. The inverse-D lower bound is for arbitrary quantum/hybrid/classical memories and common randomized codebooks. If A_V -> 0, zero retained bits suffice; under MP vanishing zero-memory error forces A_V -> 0.

4. If a known spin interval I_V of width Delta_V contains the sector law with uniformly high probability for every 0 <= t <= R_V, then a sharper concentration-sensitive finite bound is

       e <= 1-exp(-R_V) + eta_V + epsilon,
       D <= 1 + C_S epsilon^(-3) (1+j_max(I_V)R_V)
                                   sqrt(1+R_V Delta_V). (W)

   Here eta_V = sup_t q_V^t(I_V^c) is charged explicitly. An endpoint certificate suffices: eta_V <= q_V^0(j<inf I_V)+q_V^R(j>sup I_V). In particular, uniform confinement with eta_V -> 0 and R_V Delta_V=A_V^o(1) recovers the known-magnitude leading cost log_2 A_V when A_V -> infinity. MP by itself supplies no such supercritical confinement estimate.

The error is worst-case half trace norm after density reconstruction. No claim is made about preserving a purification, about all later record-conditioned tests, or about computational cost.

## 2. Exact representation and the unknown-magnitude obstruction

Read-only input: `../you-have-access-to-over-100-5/work/quantum_collisions/ordered_spin_archive.md`, Sections 1, 3, and 7, together with that workspace's `outputs/RESEARCH_STATE.txt`. The inherited exact SU(2) decomposition is

    rho_(V,t,v) = direct_sum_j q_t(j) tau_(j,t,v) tensor omega_(V,j),
    tau_(j,t,v) = exp(t v.J^(j))/Z_j(t),
    q_t(j) = q_0(j) w_j(t)/M(t),
    w_j(t) = sinh((j+1/2)t)/[(2j+1)sinh(t/2)],
    M(t) = sum_j q_0(j) w_j(t).                          (1)

The value w_j(0)=1 is understood by continuity. The multiplicity state omega_(V,j) is known and independent of both t and v. Spins satisfy 0 <= j <= SV. Sectors of zero q_0 mass can be omitted; a finite Gibbs Hamiltonian on its full Hilbert space has positive mass on every represented sector.

Measuring j and the spin-coherent POVM yields the exact joint law q_t(j) f_(2j,t,v)(u) mu(du). With L=2j, r=exp(-t), a=1-r and z=(1+v.u)/2, the angular density is

    f_(L,t,v)(u) = [(L+1)a/(1-r^(L+1))](r+a z)^L.       (2)

Preparing the observed coherent state and omega_(V,j) incurs trace error at most 1-exp(-t), uniformly in j. This is the inherited coherent-channel minorant, and its hypotheses are unchanged here.

There is a short independent verification from the exact positive P law (18). Put x=(1-r)z in [0,1-r]. The two densities obey

    Q_(L,t,v)(u)/P_(L,t,v)(u)
        = [(r+x)(1-x)/r]^L (1-x)^2/r >= r,

because (r+x)(1-x)=r+x(1-r-x)>=r and 1-x>=r. Thus the coherent measure/prepare output integral Q(u)|L,u><L,u|dmu dominates r times the exact target integral P(u)|L,u><L,u|dmu. After subtracting r times the target, the positive remainder has trace 1-r, proving the stated trace-error bound. This verification uses no limit in j or in t.

For a fixed j, (2) and a finite angular quantizer already work for every 0 <= t <= R: no radial field register is needed. The issue for general sectors is that the weights q_t(j) depend on the unknown t. Resampling a sector from q_t at the decoder would violate the declared interface. Resampling from q_0 within uniform spin bins of width epsilon/R is valid but gives order VR radial bins and an unnecessarily large order (VR)^2 combined alphabet.

The reference law used below is instead a fixed envelope of the entire known family. It is computed from H_V,beta,R, not from the true t.

## 3. A finite quantization lemma for monotone likelihood ratios

Consider a continuously differentiable family p_t(x)>0 on a finite ordered set, t in [0,R], with the monotone likelihood ratio property: p_t(x)/p_s(x) is nondecreasing in x when t>=s. Define

    h(x) = max_(0<=s<=R) p_s(x),   H = sum_x h(x).

For every delta>0 there is a contiguous partition into at most 2H/delta+2 bins, with every non-singleton bin having h-mass <=delta. Heavy atoms h(x)>delta are isolated. If a bin label is retained and its atom is resampled from h conditional on that bin, then

    sup_t TV(p_t, C_h p_t) <= delta.                     (3)

### Why the envelope quotient is unimodal

For fixed t,

    g_t(x) = p_t(x)/h(x)
           = min{ inf_(s<=t) p_t(x)/p_s(x),
                  inf_(s>=t) p_t(x)/p_s(x) }.

The first infimum is nondecreasing in x and the second is nonincreasing. Their minimum is unimodal, allowing a plateau. Since 0<g_t<=1, its total discrete variation is at most 2. This argument does not assume that the maximizer defining h is unique or differentiable.

For a bin B, let gbar_B=(sum_B h g_t)/(sum_B h). Its contribution to twice TV is

    sum_(x in B) h(x)|g_t(x)-gbar_B|
        <= h(B)[max_B g_t-min_B g_t].

Singletons give zero. For the other bins, h(B)<=delta, and the sum of their oscillations is at most the total variation of g_t, hence at most 2. This proves (3).

A greedy partition proves the count: scan in order, isolate heavy atoms, and fill each light bin until adding the next light atom would exceed delta. In a consecutive block of light atoms, consecutive greedy bin masses satisfy m_b+m_(b+1)>delta. Thus the number of bins in that block is at most 2H_block/delta+1. If there are N heavy atoms, there are at most N+1 light blocks, while N<=H_heavy/delta. Adding light and heavy bins gives at most 2H/delta+1. The looser displayed bound is sufficient. Refining two contiguous partitions on an ordered support adds their cut counts: the common refinement has at most B_1+B_2-1 bins.

This is a finite positive encoder/decoder, not a representation of the unknown parameter by a supplied real number. The use of a normalized likelihood envelope is standard in universal coding; the reconstruction statement here is proved directly.

## 4. Sector MLR and a universal square-root envelope bound

Write k=j+1/2. For t>0 the sector score is

    s_j(t) = partial_t log w_j(t)
           = k coth(kt) - (1/2)coth(t/2).                (4)

It tends to zero at t=0. The derivative of k coth(kt) in k is

    coth(kt) - kt csch^2(kt) > 0.

Therefore s_j(t) increases with j. Integrating the score difference in t proves the required MLR property of q_t. In particular, the envelope quotient q_t(j)/h_j is unimodal for

    h_j = max_(0<=t<=R) q_t(j),   H_V(R)=sum_j h_j.

Define the sector Fisher length

    ell_V(R) = integral_0^R sqrt(Var_(q_t)(s_j(t))) dt.

Upward variation bounds the envelope directly:

    H_V(R)
      <= 1 + sum_j integral_0^R (partial_t q_t(j))_+ dt
      = 1 + (1/2)integral_0^R E_(q_t)|s_j-E_(q_t)s_j| dt
      <= 1 + ell_V(R)/2.                                (5)

There is an exact information bound, not an unproved concentration assumption. Let A(t)=log M(t). For a measurement of J_v in the full Gibbs state,

    A'(t)=E J_v,   A''(t)=Var(J_v),
    E[J_v | j]=s_j(t).

The conditional-variance decomposition gives Var_(q_t)(s_j)<=A''(t). SU(2) invariance gives A'(0)=0, and the spectral bound gives A'(R)<=SV. Cauchy-Schwarz therefore yields

    ell_V(R) <= sqrt(R integral_0^R A''(t)dt)
              <= sqrt(SVR),
    H_V(R) <= 1 + (1/2)sqrt(SVR).                       (6)

The model-specific envelope H or Fisher length ell can be substantially smaller. A fixed sector has H=1 and ell=0. No concentration of j around a zero-field or true-field mean was assumed in (6).

An additional exact bound uses only public endpoint sector means. Since s_j(t) is increasing and 1-Lipschitz in j (proved below), independent J,J' under q_t give

    I_sector(t) = (1/2)E(s_J-s_J')^2
        <= (1/2)E(J-J')(s_J-s_J')
         = Cov_(q_t)(j,s_j)
         = partial_t E_(q_t)j.

Writing mu_j(t)=E_(q_t)j, integration and Cauchy-Schwarz give

    ell_V(R)^2 <= R[mu_j(R)-mu_j(0)],
    H_V(R) <= 1 + (1/2)sqrt(R[mu_j(R)-mu_j(0)]).         (6b)

The endpoint difference is nonnegative by MLR. The full-Gibbs bound (6) and the sector-response bound (6b) are both valid; (6b) automatically removes the contribution from within-sector magnetic fluctuations. No differentiation of a thermodynamic limit is used.

## 5. The parameter-independent finite archive

The inherited radial angular-density estimate is, for any j,k and 0<=t<=1,

    TV(f_(2j,t,v),f_(2k,t,v))
       <= |log[(1+2tj)/(1+2tk)]|.                       (7)

For j>=k and t<=R, the right side is at most log[(1+2Rj)/(1+2Rk)]. Partition the represented sectors into logarithmic bins of diameter eta in log(1+2Rj). The number of nonempty bins is at most

    1 + ceil(log(1+2SVR)/eta).                          (8)

Intersect them with the h-mass partition of Section 3. Since both partitions are contiguous, the number B of common radial bins obeys

    B <= 2H_V(R)/delta + 3 + log(1+2SVR)/eta.            (9)

Choose delta=epsilon/4 and eta=epsilon/8. The radial decoder resamples j from the fixed law h_j conditional on its retained bin B.

### Joint sector-angle error

One cannot apply (3) to q_t and silently leave the observed j in the angular state. For a bin B choose any representative j_B for analysis only, and replace f_(2j,t,v) by f_(2j_B,t,v) inside B. This costs at most eta in joint TV by (7). Conditional h-resampling is a contraction, so making the same replacement after the radial channel costs at most eta. For the analytically replaced distribution, all angular densities in a bin agree and the remaining radial error is exactly the error in (3). Thus

    TV(q_t(j)f_(2j,t,v), C_h[q_t(j)f_(2j,t,v)])
        <= delta + 2eta = epsilon/2.                   (10)

The representative depends on the analysis of a density but is not used by the actual code. The actual channel resamples the joint conditional reference h_j mu(du), so it never uses t or v.

### Angular alphabet

In six normalized cube-face charts, a G-by-G grid and conditional uniform-area resampling give

    TV(f, angular-cell-average(f))
        <= (C/G) integral |grad f| dmu.

For (2), the inherited direct calculation gives

    integral |grad f_(2j,t,v)| dmu
        <= exp(t)sqrt((1-exp(-t))2j)
        <= e sqrt(2Rj),   0<=t<=R<=1.                  (11)

Take G=ceil(C epsilon^(-1)sqrt(1+2SVR)) with the constant making the angular error <=epsilon/2. There are 6G^2 cells. The radial and angular averages are commuting contractions with respect to the same fixed product reference h_j mu. Consequently their errors add, and the decoder is exactly:

1. Retain only the pair (radial bin B, angular cell C).
2. Draw a fresh j with probability h_j/(sum_(k in B) h_k), j in B.
3. Draw a fresh u uniformly in normalized spherical area on C.
4. Prepare the fixed coherent/multiplicity state |2j,u><2j,u| tensor omega_(V,j), and invert the known representation decomposition.

Each pair names a fixed mixed many-body decoding state. Fresh j and u are output preparation randomness; they are not an uncharged input-dependent register. Equivalently one can define every decoding state by its finite sum and sphere integral without claiming a finite gate implementation.

Equations (9)-(11), the coherent disturbance, and the reference product construction prove

    e <= 1-exp(-R)+epsilon,
    D <= C_S epsilon^(-3)(1+VR)
                  [1+H_V(R)+log(1+VR)]
      <= C_S epsilon^(-3)(1+VR)^(3/2).                 (12)

The second line uses (6) and log(1+x)<=2sqrt(x). Constants can absorb the fixed S. If R=0, prepare rho_(V,0) with one label. Computing h_j requires access to the known sector partition functions, and omega_(V,j) can be costly to prepare; this cost is not suppressed by the storage statement.

For fixed j, only one radial label exists. Equation (11) gives D<=C epsilon^(-2)(1+jR), uniformly over all unknown magnitudes. The three parameters (t,v) therefore do not automatically create three independent dimensions of archive data.

## 6. More informative conditions: tilted variance and confinement

The finite theorem actually proves the model-sensitive estimate

    D <= C_S epsilon^(-3)(1+VR)
                  [1+ell_V(R)+log(1+VR)].               (13)

Consequently, under MP and A_V->infinity, the public-model condition

    ell_V(R_V)=A_V^o(1)                                 (F)

is sufficient to restore the sharp leading cost log_2 A_V: take epsilon->0 slowly enough that epsilon^(-1)=A_V^o(1), use (13), and apply the inherited orientation converse at t=R. In particular bounded or polylogarithmic Fisher length suffices. This is a sufficient condition, not a claimed necessary characterization of every model's optimal code.

There are two simpler certifiable conditions. First, the derivative in j of s_j(t) lies in [0,1]. The upper bound follows from

    coth(x)-x csch^2(x) <= 1
      iff (1-exp(-2x))/2 <= x.

For independent J,J' under q_t,

    Var(s_J) = (1/2)E(s_J-s_J')^2 <= Var(J).

Therefore

    ell_V(R) <= integral_0^R sqrt(Var_(q_t)(j))dt.       (14)

A supplied uniform variance estimate Var_(q_t)(j)<=sigma_V^2 yields ell_V(R)<=R sigma_V. The estimate is for the actual tilted sector laws over the whole allowed field interval, not merely for q_0.

The even simpler endpoint condition

    R_V[mu_j(R_V)-mu_j(0)]=A_V^o(1)                     (E)

also implies (F), by (6b). Only two public-model mean values need certification. This is again sufficient, not a claimed necessary characterization.

Second, suppose a public interval I has width Delta and sup_t q_t(I^c)<=eta. Restrict the input outcomes to I; send the exceptional outcomes to one extra fixed decoding state. Conditional laws q_t^I on I still have MLR and the same score differences. Their mean can increase by at most Delta, so (6b) gives

    ell_I <= sqrt(R Delta),
    H_I <= 1 + (1/2)sqrt(R Delta).

For very small R Delta, Popoviciu's bound also gives H_I<=1+R Delta/4; either bound can be used.

The logarithmic partition needed inside I has range at most

    log[(1+2R sup I)/(1+2R inf I)] <= log(1+2R Delta).

Use log(1+x)<=2sqrt(x) and repeat the construction on I with its conditional envelope. Its alphabet count and exceptional mass prove the square-root-width bound (W). This includes a literally fixed spin sector, or a finite Hamiltonian whose mass outside that sector is uniformly negligible. The known model supplies the conditional reference; no true-field spin weights are passed to the decoder.

MLR implies stochastic increase of j in t. Thus for I=[a,b],

    sup_(0<=t<=R) q_t(I^c)
        <= q_0(j<a)+q_R(j>b).                           (15)

The two endpoint laws are known model quantities. This is often a more useful uniform-confinement interface than requiring a separate proof at every intermediate field.

## 7. Critical unknown magnitude: one sphere decoder for a vMF ball

Assume MP and A_V=VR_V->c<infinity. The weights w_j(t) are uniformly bounded above and below for 0<=t<=R_V, and their variation on |j/V-m|<=delta tends uniformly to zero as delta->0. The representation (1), boundedness j/V<=S, and MP then give

    sup_(0<=t<=R_V) TV(q_t,q_0) -> 0,
    sup_(0<=t<=R_V) q_t(|j/V-m|>delta) -> 0.             (16)

This uses the bounded range VR; it is not asserted for arbitrary supercritical fields from MP alone.

Let alpha=m Vt, so alpha ranges in [0,mA_V]. In (2), t<=R_V=O(1/V) and L<=2SV, hence Lt^2=O(1/V). Uniformly on typical sectors and in u,v,t,

    f_(2j,t,v)(u) -> f_(alpha,v)(u)
        = [alpha/sinh(alpha)]exp(alpha v.u).             (17)

Continuity at alpha=0 handles t=0. For preparation, use the inherited exact positive coherent-state P law

    tau_(L,t,v) = integral P_(L,t,v)(u)|L,u><L,u|dmu(u),
    P_(L,t,v)(u)
        = (L+1)r^(L+1)/[Z_L(1-(1-r)z)^(L+2)],
    Z_L=sum_(k=0)^L r^k.                                (18)

Its diagonal beta integral gives r^k/Z_L, so it is positive and exact, including the uniform-density limit at t=0. The same uniform expansion gives P_(2j,t,v)->f_(alpha,v). All these densities are bounded uniformly when VR is bounded.

Explicitly, for k=0,...,L,

    binomial(L,k) integral_0^1
        z^(L-k)(1-z)^k/[1-(1-r)z]^(L+2) dz
            = r^(k-L-1)/(L+1).

The substitution y=r z/[1-(1-r)z] transforms the integral to r^(k-L-1) times the ordinary beta integral. Multiplying by the prefactor in (18) gives r^k/Z_L, and azimuthal averaging removes the off-diagonal entries. This supplies the positive representation used both for critical reconstruction and for the independent finite-spin minorant check above.

Define the D-independent remainder

    a_V = sup_(t<=R,v) { TV(q_t,q_0)
          + sum_j q_t(j)[TV(P_(2j,t,v),f_(mVt,v))
                         +TV(f_(2j,t,v),f_(mVt,v))] }.

Then a_V->0 by (16)-(18). It may decay arbitrarily slowly under MP. No quantitative thermodynamic rate is inserted.

Use the positive sphere tensor-hat kernel from the inherited critical construction. It has N_h<=C h^(-2) labels and

    sup_(0<=alpha<=m(c+1),v)
       TV(R_h f_(alpha,v),f_(alpha,v)) <= C_(m,c)h^2.     (19)

For completeness, its finite labels have nonnegative functions phi_k on the sphere with sum_k phi_k=1; the encoder selects k with probability phi_k(u), and the decoder samples density phi_k(u')/M_k, M_k=integral phi_k dmu. In smooth charts phi_k are partition-of-unity weights times tensor hats. Affine reproduction and the integrated centroid estimate sum_k M_k |delta_k|<=C h^2 prove (19), with uniformly bounded C2 norms over the compact vMF ball. Zero-M labels are omitted. The complete fixed chart construction is in Section 7 of the read-only ordered-spin archive.

The unknown-magnitude code measures the coherent Q outcome, discards its exact j, and retains only the angular hat label k. The decoder samples a fresh j from the single known zero-field law q_0 and u' from phi_k/M_k, then prepares their coherent/multiplicity state. This decoder knows neither alpha nor t nor v. Contractivity and the exact P representation imply

    e <= C_(m,c)h^2 + a_V,
    D <= C h^(-2),

which proves the upper inequality in (C). The critical sector label carries asymptotically no field information. The magnitude is represented through the same angular density on a two-dimensional observation space; it does not require an additional retained radial coordinate.

For c>0, restrict any candidate unknown-magnitude code to t=R_V. The inherited critical converse applies to that subfamily. One can state its argument directly: P and Q closeness reduce the archive to a sphere Markov kernel K with sup_v TV(f_(mc,v)K,f_(mc,v))<=e+a'_V. Writing b=coth(mc)-1/(mc), the vMF first moment gives

    E_(uniform u,K)||u-u'||^2 <= 4(e+a'_V)/b.

For a D-dimensional encoded state sigma_u and effective output POVM F(du'), sigma_u<=I. A chordal cap of squared radius x has normalized area x/4, so

    Pr(||u-u'||^2<=x) <= Dx/4,
    E||u-u'||^2 >= integral_0^(4/D)(1-Dx/4)dx = 2/D.

These inequalities apply conditionally on every input-independent common seed and then average. They give e>=b/(2D)-a'_V and prove the lower inequality in (C). The upper and lower remainders are independent of D, which is essential for the stated iterated limiting accuracy law. For c>0, any D_V->infinity permits vanishing error, and bounded D is excluded.

For A_V->0, prepare rho_(V,0). The eigenvalue comparison gives e<=1-exp(-2SVR_V)->0. Conversely, under MP, q_R(j>=mV/2)->1 by monotone field tilt. Opposite directions at magnitude R have spin-sector root fidelity

    (2j+1)sinh(R/2)/sinh((2j+1)R/2).

It remains strictly below 1 along every subsequence with VR bounded away from zero. Their trace distance is therefore bounded away from zero, and no single fixed output can approximate both with vanishing error. This proves the zero-memory necessity claimed in Section 1.

## 8. An MP counterexample with a matching 3/2 lower exponent

Take S=1/2 and even V. The tensor-power representation has every integer spin j=0,1,...,V/2 with positive multiplicity

    d_(V,j) = binomial(V,V/2-j)-binomial(V,V/2-j-1),

with out-of-range binomial coefficients interpreted as zero. Fix numbers m>0,c_0>0 with m+c_0<1/2, and a public schedule R_V->0 with A_V=VR_V->infinity. For example, m=c_0=1/8 works. Define a block-scalar invariant Hamiltonian by

    H_V = direct_sum_j E_(V,j) I_(2j+1) tensor I_(d_(V,j)),
    beta E_(V,j)
        = log d_(V,j) + R_V(j-mV)^2/(2c_0 V).           (20)

All energies are finite. The Hamiltonian depends on the declared public radius R_V, not on the unknown field t. It is nonlocal and is offered only within the arbitrary-invariant-H model.

The multiplicity factor cancels in the zero-field sector law:

    q_0(j) proportional (2j+1)
              exp[-R_V(j-mV)^2/(2c_0V)].                (21)

Set sigma_V^2=c_0 V/R_V. Then sigma_V/V=sqrt(c_0/A_V)->0 and sigma_V->infinity. The lattice Gaussian in (21) concentrates at j/V=m. Multiplication by (2j+1) does not alter this: on the central Gaussian bulk its relative variation is O(sigma_V/V), and Gaussian tail ratios vanish as |j-mV|/sigma_V->infinity. The boundaries 0 and V/2 are a positive multiple of V from mV, or a diverging multiple of sigma_V. Thus (21) satisfies MP on the actual finite spin support.

For t in [R_V/4,3R_V/4], multiply (21) by w_j(t). The exact cancellation gives

    q_t(j) proportional
      exp[-(j-mV)^2/(2sigma_V^2)] sinh((j+1/2)t)
      proportional exp[-(j-mu_t)^2/(2sigma_V^2)]
                    [1-exp(-(2j+1)t)],
    mu_t = mV + sigma_V^2 t = mV + c_0 V t/R_V.        (22)

All normalizing factors omitted in the second proportionality are independent of j. The centers lie in the fixed interior interval [(m+c_0/4)V,(m+3c_0/4)V]. The actual law is a truncated lattice Gaussian multiplied by a factor between 0 and 1. On j>=mV/2 that factor differs from 1 by at most exp(-m A_V/4). Below mV/2 and beyond the two physical boundaries, the lattice-Gaussian tail ratios are O(exp(-c_1 A_V)) for a constant c_1>0. Hence uniformly on this t interval,

    TV(q_t, G_(mu_t,sigma_V)) = O(exp(-c_2 A_V)),        (23)

where G is the untruncated integer-lattice Gaussian. The constants can change with m,c_0. Since sigma_V->infinity, uniform shifted Riemann sums give

    E_G(j-mu_t)^2 <= 2sigma_V^2

eventually. This second-moment bound and (23) give uniform classification bounds without an assumption on a continuous retained j.

### Radial packing

Choose means mu_i in the above interval spaced by 32sigma_V and let t_i=(mu_i-mV)/sigma_V^2. Their number satisfies

    K_V >= c_3 R_V sigma_V = c_3 sqrt(c_0 A_V)

for all sufficiently large V. Nearest-center classification from the exactly measured j fails only if |j-mu_i|>=16sigma_V. Chebyshev for the lattice Gaussian, followed by (23), bounds this by 1/128+o(1). No exact center is retained by an archive; this is a distinguishing measurement used for a lower bound.

### A common angular packing for every radial hypothesis

Choose a maximal sphere packing with chordal separation Delta_V satisfying

    Delta_V^2 = 2048/(m A_V).

For large V, Delta_V<=1. Its number N_V is at least 4/Delta_V^2=m A_V/512 by the exact spherical cap-area bound. On j>=mV/2 and t_i>=R_V/4, the coherent observation satisfies

    E(||u-v||^2 | j,t_i)
        <= 4/[(1-exp(-t_i))(2j+2)]
        <= 32/(m A_V).

Nearest-direction classification fails only if ||u-v||>=Delta_V/2. Markov bounds its probability by 1/16 on the high-spin event. Equation (23) makes the low-spin event o(1), uniformly in i. The radial and angular classifiers can be combined on the fixed joint measurement (j,u); a union bound gives total failure <1/8 eventually.

There are K_V N_V >= c_4 A_V^(3/2) input states rho_(V,t_i,v_a) distinguished by this measurement with success >=7/8. If a code reconstructs every state with trace error <=1/8, applying the same classifier to its decoded state succeeds with probability >=3/4.

For any D-dimensional quantum memory, let omega_(i,a) be its encoded states and F_(i,a) the effective classification POVM. Since omega_(i,a)<=I and sum F_(i,a)=I,

    average success
        <= [sum_(i,a) Tr F_(i,a)]/(K_VN_V)
        = D/(K_VN_V).

The bound includes hybrid and classical memory as special cases. Condition on a common seed if codebooks use input-independent common randomness; averaging preserves the same bound. Thus

    D >= (3/4)K_VN_V >= c_5 A_V^(3/2).                 (24)

Equations (12) and (24), with epsilon=1/log(e+A_V), prove the sharp worst-case leading unknown-magnitude cost (3/2+o(1))log_2 A_V. The example meets MP but does not preserve its concentration point under all supercritical tilts: the mean moves by a fixed macroscopic fraction as t changes. Its role is to rule out an MP-only log_2 A_V theorem.

An even stronger warning is possible. Replace c_0 by c_V=1/log(e+A_V). The same construction, with sigma_V^2=c_V V/R_V, then has j/V->m uniformly for t in [0,R_V]: the endpoint q_0 concentrates at m and q_R at m+c_V, and MLR controls both intermediate tails. Its radial packing has size order sqrt(c_V A_V). The lower bound becomes c A_V^(3/2)/sqrt(log(e+A_V)), which retains the 3/2 leading exponent. Thus unquantified macroscopic concentration under every tilted field, by itself, also does not recover the known-magnitude leading exponent. The fixed macroscopic upper-tail large-deviation rates of a particular local Hamiltonian are additional information and must be accounted for separately.

## 9. What the local Heisenberg application still needs

The exact response decomposition is

    u_j(t) := Var_(tau_(j,t,v))(J_v)
            = partial_t s_j(t)
            = (1/4)csch^2(t/2)
                         -(j+1/2)^2 csch^2((j+1/2)t),
    I_sector,V(t) := Var_(q_t)(s_j(t))
            = partial_t^2 log M(t) - E_(q_t) u_j(t).    (25)

At t=0 take the finite limit u_j(0)=j(j+1)/3. For jt>>1, u_j(t)=1/t^2+O(1)-O(j^2 exp(-2jt)). This term is present even for a single known spin sector, whose radial Fisher information is exactly zero. A full susceptibility bound cannot simply be interpreted as a radial field-information bound; (25) subtracts the within-sector angular contribution.

The read-only family271 source inspected here is the released spherical-magnetization manuscript, especially Section 8's `eq:spin-concentration` and Section 7's pressure-tangent argument, at release commit adc7f1241b42e322a6451854ab7e4b4c146bf78a:

https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/The-spherical-magnetization-law-for-the-three-dimensional-quantum-Heisenberg-ferromagnet-October-5-2026/build/sections/08-global-spin.tex

Section 8 claims MP and uses a fixed positive field and the pressure right derivative to obtain an exponentially small zero-field upper tail at each fixed macroscopic excess epsilon. Such a bound, if accepted, transfers the upper-tail concentration uniformly under t<=R_V->0 because the tilt costs only exp(O(VR_V))=exp(o(V)). The monotone lower-tail bound transfers automatically. This can establish uniform tilted macroscopic concentration for that physical family, beyond abstract MP.

The inspected argument does not provide a quantitative finite-volume bound on I_sector,V(t), on Var_(q_t)(j), or on a submacroscopic confinement width uniformly for all shrinking fields in [0,R_V]. Its pressure tangent concerns the thermodynamic right derivative and equilibrium radii; it supplies neither a finite-size susceptibility rate nor a valid differentiation of a pointwise pressure limit twice on a shrinking field interval.

The endpoint certificate (6b) offers an alternative that avoids second derivatives. Uniform tilted macroscopic concentration gives only mu_j(R)-mu_j(0)=o(V), hence ell=o(sqrt(VR)); without a rate this does not improve the leading exponent. The c_V counterexample above shows the issue explicitly. A finite-volume endpoint response estimate satisfying (E) would restore the known-magnitude leading rate.

For connecting this endpoint quantity to a physical longitudinal magnetization, the exact conditional geometric law gives

    j-s_j(t) = 1/(exp(t)-1)
                         -(2j+1)/(exp((2j+1)t)-1),
    0 <= mu_j(t)-A'(t) <= 1/(exp(t)-1) <= 1/t.

Therefore

    R[mu_j(R)-mu_j(0)] <= R[A'(R)-mu_j(0)] + 1.         (25b)

A finite-volume first-derivative magnetization estimate can thus be sufficient; the thermodynamic pressure right derivative alone supplies no required convergence rate for its use at R_V->0.

The missing load-bearing estimate is any certified function B_V(t) with

    I_sector,V(t) <= B_V(t),
    integral_0^R sqrt(B_V(t))dt = A_V^o(1),              (26)

or the stronger but easier-to-state tilted variance version of (14), the endpoint mean-response interface (E), or the confinement interface (W). A rate for the angular zero-mode subtraction in (25) is needed if B is obtained from the full susceptibility. The field t~1/V, finite linear-size crossover, and any error in q_t's rare sectors must all be included. A spin-wave prediction for B is not used as a theorem here. No tighter universal leading rate is attributed to the local three-dimensional Heisenberg model on the evidence inspected.

## 10. Prior-art and status boundary

The likelihood envelope h and its normalizer are standard normalized-maximum-likelihood/Shtarkov objects. A primary discussion is Grünwald and Harremoës, *Finiteness of Redundancy, Regret, Shtarkov Sums, and Jeffreys Integrals in Exponential Families* (ISIT 2009):

https://homepages.cwi.nl/~pdg/ftp/isit2009.pdf

The finite MLR conditional-resampling lemma, the SU(2) Fisher bound (6), and their archive composition were derived explicitly here. No claim is made that these ingredients or their combination lack prior art.

The extra one-half logarithmic spectrum cost is already present for iid fully unknown mixed qubit states in Yang, Chiribella, and Hayashi, *Optimal compression for identically prepared qubit states* (2016). Their result concerns fixed iid models and quantum/hybrid archives, rather than an arbitrary correlated invariant Gibbs state with R_V->0 and a wholly classical archive:

https://arxiv.org/abs/1606.02893

The regular iid parameter-count framework is also established in Yang, Bai, Chiribella, and Hayashi, *Compression for quantum population coding*:

https://arxiv.org/abs/1701.03372

Those sources delimit the claim: a 3/2 exponent is not intrinsically new, and counting the three unknown field parameters is not a proof of this theorem. Here the archive is built from a two-dimensional coherent outcome plus a rigorously bounded sector envelope; it remains valid at singular t=0 and for arbitrary known invariant Hamiltonians. The lower example proves the worst-case extra factor under the declared MP interface. No gate complexity, experimental realization, physical susceptibility theorem, or exhaustive novelty assessment has been established.

Independent reconstruction: the sibling audit agent checked MLR, envelope unimodality, Fisher length, greedy-bin count, joint conditional resampling, and the Gaussian lower construction. The separate audit remains evidence of an internal proof review, not external validation.

Finite numerical fixtures: `unknown_field_checks.py` passed for 16 irregular sector laws and three exact Gaussian-sector Hamiltonian laws, writing `unknown_field_checks.json`. The checks cover the discrete-parameter envelope bound and unimodality, raw h-mass thresholds, additive refinement count, radial and joint resampling TV, normalization of the coherent angular law, and the exact Gaussian tilt centers/variance. The engineered examples use A=512,1024,2048 while R decreases; their zero-field standard deviations divided by V decrease and their sector-envelope masses increase from 4.14 to 5.48 to 7.36. These finite checks are sanity evidence for the derivation, not proof certification, capability evidence, or an advantage benchmark.
