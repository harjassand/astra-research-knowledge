# Independent audit of the unknown-magnitude SU(2) archive

Date: 7 October 2026. Read-only source inputs:

- `/Users/harjas/Documents/Codex/2026-10-07/you-have-access-to-over-100-5/work/quantum_collisions/ordered_spin_archive.md`, chiefly Sections 1 and 3.
- `/Users/harjas/Documents/Codex/2026-10-07/you-have-access-to-over-100-7/work/unknown_field.md`, Sections 1–5 as initially written, followed by appended Sections 6–9 and the endpoint-response refinement.
- Direct coordination with the deriving agent concerning the proposed lower example.

**Verdict:** the envelope construction passes independent reconstruction. The decoder uses a fixed envelope of the public family and never uses the true field magnitude. The Fisher envelope estimate, MLR/unimodality implication, TV coarsening estimate, additive interval-refinement count, and combined `3/2` power all hold under the declared fixed-S, `0<=R<=1` interface. No macroscopic-spin premise is needed for this upper bound. The endpoint-response and square-root-width refinements also pass. Under MP and bounded VR, the fixed q_0 decoder attains the critical `O(1/D)` law with a remainder independent of D. The engineered examples support the `3/2` worst-case exponent, even under unquantified uniform tilted macroscopic concentration; they do not establish that power for every specific local ordered model.

This is an internal mathematical audit, not external validation or priority clearance. No integrity fixtures were replayed.

## 1. Declared interface

The known data are V, fixed on-site spin S, a finite SU(2)-invariant Hamiltonian H, beta, and a public R in `[0,1]`. The input is one entire Gibbs density operator

\[
\rho_{t,v}=e^{-\beta H+t v\cdot J}/Z(t),
\qquad0\le t\le R,\quad v\in S^2.
\]

Both t and v are unknown. The exact decomposition is

\[
\rho_{t,v}=\bigoplus_j q_t(j)\tau_{j,t,v}\otimes\omega_j,
\qquad 0\le j\le SV,
\]

where `omega_j` is public and independent of t,v. The spin-sector laws satisfy

\[
q_t(j)=q_0(j)w_j(t)/M(t),\qquad
w_j(t)=\frac{\sinh((j+1/2)t)}{(2j+1)\sinh(t/2)},
\quad M(t)=\sum_jq_0(j)w_j(t).
\]

The value at zero is the continuous extension. Only represented sectors with positive `q_0` need be considered. The represented support is a finite ordered set; missing spin values cause no problem.

The known-field source's decoder samples from `q_t` inside a radial bin. That operation is illegal for this enlarged interface. The new construction replaces it by `h_j/sum_B h`, with `h_j=max_(0<=s<=R) q_s(j)`. Computing h may be expensive, but it depends solely on public data, not on the actual input parameter.

## 2. Sector MLR

Let `k=j+1/2`. The logarithmic derivative of `w_j` is

\[
s_j(t)=k\coth(kt)-\tfrac12\coth(t/2).
\]

For t>0,

\[
\partial_k[k\coth(kt)]
=\coth(kt)-kt\operatorname{csch}^2(kt)>0,
\]

because `sinh(x)cosh(x)>x` for x>0. At t=0 all scores extend to zero. For j'>j, integrating the score difference proves that `w_(j')(t)/w_j(t)` is nondecreasing in t. Normalization factors cancel in likelihood ratios. Therefore, for t>=s, `q_t(j)/q_s(j)` is nondecreasing in j.

Neither a concentration premise nor a special zero-field sector shape was used.

## 3. The envelope mass has the square-root bound

Set `H_env=sum_j h_j`. For each coordinate,

\[
h_j-q_0(j)\le\int_0^R(\partial_t q_t(j))_+\,dt.
\]

Summing and using `sum_j partial_t q_t(j)=0` gives

\[
H_{\rm env}\le1+\tfrac12\int_0^R
\sum_j|\partial_t q_t(j)|dt
=1+\tfrac12\int_0^R
\mathbb E_{q_t}|s_j-\mathbb E_{q_t}s_j|dt.
\]

Thus

\[
H_{\rm env}\le1+\tfrac12\ell(R),\qquad
\ell(R)=\int_0^R\sqrt{\operatorname{Var}_{q_t}(s_j)}dt.
\]

Let `A(t)=log M(t)=log Z(t)-log Z(0)`. Since H commutes with the global generators,

\[
A'(t)=\mathbb E J_v,\qquad A''(t)=\operatorname{Var}(J_v).
\]

Conditional on j, the mean of J_v is precisely `s_j(t)`. The law of total variance gives `Var_(q_t)(s_j)<=A''(t)`. Invariance gives `A'(0)=0`, and the spectral bound gives `A'(R)<=SV`. Hence

\[
\ell(R)^2\le R\int_0^R A''(t)dt
=R[A'(R)-A'(0)]\le SVR,
\]

\[
\boxed{H_{\rm env}\le1+\tfrac12\sqrt{SVR}.}
\]

The factor one half in the envelope estimate is correct. This is a global Fisher-length argument, not a Gaussian sector approximation or a hidden susceptibility bound.

## 4. MLR makes the envelope quotient unimodal

For fixed t put `g_t(j)=q_t(j)/h_j`. Exactly,

\[
g_t(j)=\min\left\{
\inf_{s\le t}\frac{q_t(j)}{q_s(j)},
\inf_{s\ge t}\frac{q_t(j)}{q_s(j)}\right\}.
\]

By MLR the first term is nondecreasing in j; the second is nonincreasing. An infimum preserves these monotonicities. Their difference is nondecreasing, so their minimum increases up to a possible crossing and decreases afterward. A plateau and a mode at either endpoint are allowed. Since `0<g_t<=1`,

\[
\sum_{j\text{ consecutive in support}}
|g_t(j_+)-g_t(j)|\le2.
\]

The proof requires no unique envelope maximizer, no smoothness of that maximizer, and no claim that the envelope h itself is unimodal. General MLR is sufficient.

## 5. Raw h-mass bins give the required TV bound and count

Fix a threshold delta>0. Isolate every heavy atom with `h_j>delta`. On each remaining contiguous block of light atoms, make maximal successive bins of raw h-mass at most delta. For a bin B, resample according to the fixed probability `h_j/h(B)`. The output sector law is

\[
q'_t(j)=\frac{h_j}{h(B)}q_t(B),\qquad j\in B.
\]

Writing `gbar_B=q_t(B)/h(B)`, its contribution to twice TV is

\[
\sum_{j\in B}h_j|g_t(j)-\overline g_B|
\le h(B)\operatorname{osc}_B(g_t).
\]

Singletons contribute zero. All other bins have `h(B)<=delta`. The sum of their oscillations is bounded by the full discrete variation of g_t, because they are disjoint contiguous subsets. Consequently

\[
\boxed{\operatorname{TV}(q_t,q'_t)\le\delta.}
\]

Here is a precise count argument. In a light block with greedy bin masses `m_1,...,m_n`, maximality implies `m_i+m_(i+1)>delta` for every adjacent pair. Hence `(n-1)delta<2 sum_i m_i` and `n<=2 h(block)/delta+1`. If there are `N_heavy` heavy atoms, there are at most `N_heavy+1` nonempty light blocks. Also `N_heavy<=H_heavy/delta`. Therefore the total number of bins is at most

\[
2H_{\rm light}/\delta+2N_{\rm heavy}+1
\le2H_{\rm env}/\delta+1.
\]

The source's looser `2H_env/delta+2` bound is valid.

**Normalization convention matters:** the threshold is raw `h(B)<=delta`. If one implements using the normalized reference `nu_j=h_j/H_env`, the same threshold is `nu(B)<=delta/H_env`. Merely requiring `nu(B)<=delta` would in this argument give TV of order `H_env delta`. The decoder's conditional probabilities are identical under either convention; only the bin threshold must be translated correctly.

## 6. Geometric refinement adds bins

The inherited exact radial angular-law bound is

\[
\operatorname{TV}(f_{2j,t,v},f_{2k,t,v})
\le\left|\log\frac{1+2tj}{1+2tk}\right|.
\]

For j>=k, the logarithm is nondecreasing in t, as its derivative is

\[
\frac{2(j-k)}{(1+2tj)(1+2tk)}\ge0.
\]

Thus public bins of log-diameter eta in `log(1+2Rj)` give pairwise angular TV at most eta simultaneously for all `0<=t<=R` and all v. Their nonempty count is at most `1+ceil(log(1+2SVR)/eta)`.

Two contiguous partitions of the same ordered support have a common refinement with at most `B_1+B_2-1` bins: its cut set is the union of the two cut sets. This remains true with holes in the support. Refinement preserves the raw h-mass threshold and singleton heavy atoms, so the sector TV bound remains delta.

Consequently

\[
B_{\rm radial}\le2H_{\rm env}/\delta+O(1)
+\log(1+2SVR)/\eta.
\]

There is no product of the two radial counts.

## 7. Exact joint coarsening and parameter independence

The measured joint law is `q_t(j) f_(2j,t,v)(u) mu(du)`. After fixed h-resampling inside B, its exact joint law is

\[
q'_t(j)\,g_{B,t,v}(u)\,d\mu(u),\qquad
g_{B,t,v}=\sum_{k\in B}q_t(k\mid B)f_{2k,t,v}.
\]

The function g is an analytical description of the output distribution. The decoder does not evaluate it or use `q_t(k|B)`; it arises from the incoming label/outcome distribution.

There is a direct bound slightly stronger than the source's triangle estimate. First compare the measured law to `q'_t(j) f_(2j,t,v)(u)`, which costs exactly `TV(q_t,q'_t)<=delta`. Then compare to `q'_t(j)g_(B,t,v)(u)`. Every component of g has angular TV at most eta from the density of any j in B, so the second cost is at most eta. Hence

\[
\operatorname{TV}(\text{measured joint law},\text{radially coarsened law})
\le\delta+\eta.
\]

The source's `delta+2eta` proof, using a representative density only in the analysis and contraction on each side, is also valid. The representative is not an oracle-dependent decoding state.

For angular cells C, the entire finite decoder state associated with (B,C) is explicitly

\[
\Omega_{B,C}=\sum_{j\in B}\frac{h_j}{h(B)}
\frac1{\mu(C)}\int_C
P_j(u)\otimes\omega_j\,d\mu(u),
\]

followed by the known inverse representation decomposition. Its encoder effect is the sum of the sector-coherent POVM effects over `j in B` and `u in C`, tensored with the multiplicity identity. Both kernels are positive, normalized, and fixed by public data. The probability of (B,C) depends on the input as every measurement probability does; its decoder state does not.

The sampled output sector and sampled real direction are fresh preparation randomness. No exact input sector, field estimate, or direction is secretly retained. Equivalently the fixed mixed states Omega define the decoder without a sampling implementation.

## 8. Alphabet and reconstruction error

For `0<=t<=R<=1`, the inherited angular variation estimate gives

\[
\int\|\nabla f_{2j,t,v}\|d\mu\le e\sqrt{2Rj}
\le e\sqrt{2SVR}.
\]

A six-face cube chart grid with

\[
G=\left\lceil C\epsilon^{-1}\sqrt{1+2SVR}\right\rceil
\]

has at most `6G^2<=C_S epsilon^-2(1+VR)` angular cells and can make the uniform angular TV error at most a chosen constant multiple of epsilon. The averages over radial bins and angular cells are commuting L1 contractions relative to the public product reference `h_j mu(du)`, so the errors add.

Choose delta and eta as fixed fractions of epsilon. The radial count obeys

\[
B_{\rm radial}\le C_S\epsilon^{-1}
[1+\sqrt{VR}+\log(1+VR)]
\le C_S\epsilon^{-1}\sqrt{1+VR},
\]

using `log(1+x)<=2sqrt(x)`. Counting every retained label gives

\[
\boxed{D\le C_S\epsilon^{-3}(1+VR)^{3/2}.}
\]

The preparation map contracts TV, and the exact spin coherent channel incurs at most `1-e^-t`. With allocations making the extra coarsening error at most epsilon,

\[
\boxed{e\le1-e^{-R}+\epsilon\le R+\epsilon.}
\]

No MP premise was used. If R=0 the input is the known invariant zero-field state and one label gives exact reconstruction. For a fixed single spin sector there is also no radial count: unknown t is encoded through its measured angular distribution using a fixed angular decoder, giving order `epsilon^-2(1+jR)` labels.

The restriction R<=1 is material to an R-independent angular constant. The construction is an information-theoretic archive; the known partition functions, envelope optimization, and multiplicity Gibbs preparation may be difficult. These computational tasks are not treated as cheap experimental algorithms.

## 9. Independent reconstruction of the proposed worst-case lower example

This subsection audits the example communicated by the deriving agent. Let `R=R_V->0`, `kappa=VR->infinity`, and choose fixed constants `0<m<m+c<S`. On all represented spins take

\[
q_0(j)\propto(2j+1)
\exp\left[-\frac{R(j-mV)^2}{2cV}\right].
\]

If the multiplicity of sector j is `d_j`, this is realized by the known block-scalar invariant Hamiltonian

\[
H_j=\beta^{-1}\left[
\frac{R(j-mV)^2}{2cV}+\log d_j\right]I.
\]

It depends on the public radius R, not on the unknown true t. It is generally nonlocal, which is allowed by the arbitrary-invariant-H interface. The zero-field standard deviation scale is

\[
\sigma=\sqrt{cV/R}=\sqrt c\,V/\sqrt\kappa,
\qquad \sigma/V\to0.
\]

The extra factor `2j+1` is bounded above and below by constant multiples of V in the central bulk. Gaussian tail bounds then give `j/V->m` under q_0. Thus the stated MP premise holds.

For `t in [R/4,3R/4]`, multiplying q_0 by the exact w_j cancels its `2j+1` factor. Completing the square gives

\[
q_t(j)\propto
\exp\left[-\frac{(j-\mu_t)^2}{2\sigma^2}\right]
[1-e^{-(2j+1)t}],\qquad
\mu_t=mV+cVt/R.
\]

The center stays a fixed positive distance, proportional to V, from both spin endpoints. The support truncation tails are `O(exp(-c_0 kappa))`, uniformly in this t interval. On `j>=mV/2`, the bracket differs from one by at most `exp(-m kappa/4)`; the omitted lower-spin probability is also exponentially small. Therefore q_t is uniformly TV-close to the indicated truncated lattice Gaussian. Since `sigma->infinity`, uniform Riemann-sum estimates give its normalizer `sigma sqrt(2 pi)+O(1)` and its unnormalized second moment about mu_t `sigma^3 sqrt(2 pi)+O(sigma^2)`. Endpoint tails change the ratio by an exponentially small relative term. The bracket correction changes that moment by at most `O(V^2 exp(-c_0 kappa))=o(sigma^2)`. Thus the q_t second moment about mu_t is bounded by `2 sigma^2` for sufficiently large V.

Choose centers mu_t separated by `32 sigma`. The interval of available centers has length `cV/2`, so there are `Theta(sqrt(kappa))` field hypotheses. Nearest-center classification from the measured j has arbitrarily small fixed error after increasing this fixed separation constant; Chebyshev already suffices.

Use a common direction packing with squared chordal separation `Delta^2=2048/(m kappa)`. For `t>=R/4`, `1-e^-t>=R/8`. On `j>=mV/2`, the exact angular mean bound gives

\[
\mathbb E\|u-v\|^2\le\frac{4}{(1-e^{-t})(2j+2)}
\le\frac{32}{m\kappa}.
\]

Nearest-direction classification fails with probability at most `4 E||u-v||^2/Delta^2<=1/16`, plus the negligible lower-spin event. A maximal packing contains at least `4/Delta^2=Theta(kappa)` directions. The same fixed coherent measurement of (j,u) therefore distinguishes the Cartesian set of `Theta(kappa^(3/2))` hypotheses with error less than 1/8 for sufficiently large V.

An archive with reconstruction error at most 1/8 preserves classification success at least 3/4. For N equiprobable hypotheses, every D-dimensional classical/quantum/hybrid memory has average success at most D/N, by `sigma_i<=I` and POVM normalization. Conditioning on any independent common seed preserves this inequality. Hence

\[
D\ge c_{S,m,c}(VR)^{3/2}.
\]

This establishes a worst-case obstruction to retaining the known-magnitude exponent under MP alone. It is not a counterexample for a specified nearest-neighbor Hamiltonian, and it does not show that every MP family has large radial complexity. Any claim of a universal `3/2` lower rate for every ordered model would exceed this evidence.

## 10. The exact endpoint-response refinement

The score has a further property beyond monotonicity. For x>0,

\[
0<\coth x-x\operatorname{csch}^2x\le1.
\]

The lower bound follows from `sinh(x)cosh(x)>x`. The upper bound is equivalent to `(1-e^-2x)/2<=x`, which follows by integrating `e^-2y<=1` from 0 to x. Thus `s_j(t)` is increasing and 1-Lipschitz in j for every t, including its zero extension at t=0.

For independent J,J' drawn from q_t, the two score differences have the same sign as the spin difference, and their magnitude is no larger. Therefore

\[
\operatorname{Var}_{q_t}(s_J)
=\tfrac12\mathbb E(s_J-s_{J'})^2
\le\tfrac12\mathbb E(J-J')(s_J-s_{J'})
=\operatorname{Cov}_{q_t}(j,s_j).
\]

Differentiating the finite sector mean cancels the normalized score's scalar term and gives exactly

\[
\partial_t\mu(t)=\operatorname{Cov}_{q_t}(j,s_j),
\qquad \mu(t)=\mathbb E_{q_t}j.
\]

Hence

\[
\boxed{\ell(R)^2\le R[\mu(R)-\mu(0)],\qquad
H_{\rm env}\le1+\tfrac12\sqrt{R[\mu(R)-\mu(0)]}.}
\]

The mean difference is nonnegative and is a public endpoint quantity. The bound directly measures sector response and removes all within-sector angular variance. It does not differentiate a thermodynamic limit.

The same 1-Lipschitz calculation gives `Var(s_J)<=Var(J)` and the source's variance sufficient condition `ell<=int_0^R sqrt(Var_(q_t)(j)) dt`. Both bounds are exact; neither permits replacing the tilted variance by a zero-field variance without another argument.

## 11. Conditional confinement gives a square-root width factor

Let a public interval I of width Delta have uniformly excluded mass at most eta. Assume it contains at least one represented positive-mass sector. The conditional family `q_t^I(j)=q_t(j)/q_t(I)` has the same MLR and score differences. Apply Section 10 to its conditional mean. Both endpoint conditional means lie in I, so

\[
\ell_I^2\le R[\mu_I(R)-\mu_I(0)]\le R\Delta,
\qquad H_I\le1+\tfrac12\sqrt{R\Delta}.
\]

Popoviciu's variance inequality also gives `ell_I<=R Delta/2`, hence `H_I<=1+R Delta/4`, when that is more useful. The logarithmic radial range inside I is at most

\[
\log\frac{1+2R\sup I}{1+2R\inf I}
\le\log(1+2R\Delta)\le2\sqrt{2R\Delta}.
\]

Repeat the same envelope/geometric refinement on the conditional family. The radial count is at most `C epsilon^-1 sqrt(1+R Delta)`, while the angular count is at most `C epsilon^-2(1+j_max(I)R)`. One extra label catches outcomes outside I. Convexity of trace distance charges their total probability, rather than requiring any information about their state. This proves

\[
\boxed{D\le1+C_S\epsilon^{-3}
(1+j_{\max}(I)R)\sqrt{1+R\Delta},\qquad
e\le1-e^{-R}+\eta+\epsilon.}
\]

The reference envelope is conditional on a public interval and public model; no true-field conditional law is passed to the decoder. MLR also gives the advertised endpoint certificate

\[
\sup_{0\le t\le R}q_t(I^c)
\le q_0(j<\inf I)+q_R(j>\sup I).
\]

Thus the square-root refinement, not merely the original linear width bound, is justified.

## 12. Uniform critical magnitude ball and fixed q_0 decoder

Assume MP, `j/V->m>0` under q_0, and `A_V=VR_V->c<infinity`. Set `u=Vt`, so u is uniformly bounded. The common scalar in w_j cancels from q_t, leaving

\[
q_t(j)=\frac{q_0(j)F((j+1/2)t)}
{\mathbb E_{q_0}F((J+1/2)t)},\qquad
F(x)=\sinh(x)/x,\quad F(0)=1.
\]

F is bounded, positive, and Lipschitz on the relevant fixed compact interval. Uniformly over u in `[0,A_V]`,

\[
\mathbb E_{q_0}|F((J+1/2)t)-F(m u)|
\le C[\mathbb E_{q_0}|J/V-m|+V^{-1}]\to0.
\]

Bounded support upgrades MP to convergence of this absolute moment. The denominator is at least one. The normalized tilt consequently satisfies

\[
\boxed{\sup_{t\le R_V}\operatorname{TV}(q_t,q_0)\to0.}
\]

This is a TV statement, stronger than uniform macroscopic concentration. It is valid because VR is bounded and is not extended to the supercritical range.

The angular expansions can also be made uniform at t=0. Put `L=2j`, `x=(L+1)t` and `alpha_j=x/2`. The coherent Q density can be written as

\[
Q_{L,t,v}(u)=
\frac{1-e^{-t}}t\frac{x}{1-e^{-x}}
[e^{-t}+(1-e^{-t})z]^L.
\]

Using `log[e^-t+(1-e^-t)z]=-t(1-z)+O(t^2)` and continuous extensions at zero gives

\[
Q_{L,t,v}(u)=f_{\alpha_j,v}(u)+O(t+Lt^2),
\quad
f_{\alpha,v}(u)=\frac{\alpha}{\sinh\alpha}e^{\alpha v\cdot u}.
\]

The constants are uniform in j,u,v and all permitted t. The exact positive P density has prefactor `[(1-e^-t)/t] x/(e^x-1)` and exponent `-(L+2)log[1-(1-e^-t)z]=xz+O(t+Lt^2)`. It therefore has the same uniform approximation to `f_(alpha_j,v)`.

Since `t=O(1/V)` and `L<=2SV`, `t+Lt^2=O(1/V)`. Replacing `alpha_j=(j+1/2)t` by `alpha=mVt` costs at most `C(|j/V-m|+1/V)` on the compact alpha interval. The q_t/q_0 density ratio is uniformly bounded, so the q_t-weighted P and Q errors vanish uniformly over t,v.

The source's remainder

\[
a_V=\sup_{t\le R_V,v}\left\{
\operatorname{TV}(q_t,q_0)+\sum_j q_t(j)
[\operatorname{TV}(P_{j,t,v},f_{mVt,v})
+\operatorname{TV}(Q_{j,t,v},f_{mVt,v})]\right\}
\]

therefore tends to zero. It is independent of D. This reasoning supplies no universal numerical rate for MP.

The positive tensor-hat quantizer has `N_h<=C h^-2` labels and uniformly approximates the compact vMF ball with TV error `C_(m,c) h^2`. I reconstructed the relevant second-order step: unweighted hats are symmetric around their centers, the global chart weights are Lipschitz, and the unnormalized weighted centroid of each hat is `O(h^4)`. Summing `O(h^-2)` hats gives an integrated centroid error `O(h^2)` without any lower bound on a single label mass. Affine reproduction removes the other first-order terms. The vMF family's C2 chart norms are uniform on the compact alpha ball, including zero.

The unknown-magnitude decoder samples j from one fixed q_0 and the direction from the hat's fixed normalized density. If `barQ=sum_j q_t(j)Q_(j,t,v)`, its angular output is `R_h barQ` in every output sector. Comparing its decoded density operator to the exact positive P target costs

\[
\operatorname{TV}(q_t,q_0)+\sum_jq_t(j)
\operatorname{TV}(R_h\bar Q,P_{j,t,v})
\le C_{m,c}h^2+a_V.
\]

For all D above a fixed chart threshold choose `h^2=C_0/D` with `N_h<=D`. This proves the uniform critical upper `e^*_(V,D)<=C_(m,c)/D+a_V`, with a single decoder that knows neither t nor alpha nor v. Unknown magnitude is carried by the angular measurement law; no radial parameter estimate is supplied.

For c>0 the lower bound follows by restricting to t=R_V. P/Q closeness and `mVR_V->mc` yield a sphere kernel K with `sup_v TV(f_(mc,v)K,f_(mc,v))<=e+a'_V`, where the remainder is again independent of D. With `b=coth(mc)-1/(mc)>0`, the vMF first moment gives

\[
\mathbb E_{u\ {m uniform},K}\|u-u'\|^2
\le4(e+a'_V)/b.
\]

Any factorization through D-dimensional memory satisfies the opposite bound `E||u-u'||^2>=2/D`: a squared-radius-x chordal cap has normalized area x/4, and `sigma_u<=I` gives `Pr(||u-u'||^2<=x)<=Dx/4`; integrating this for `0<=x<=4/D` proves the bound. Conditioning on independent common randomness preserves both estimates. Therefore

\[
\boxed{e^*_{V,D}\ge b/(2D)-a'_V.}
\]

The upper and lower orders are justified in the iterated critical limit; in arbitrary joint thermodynamic/precision limits, the D-independent remainders must remain visible. For c>0 every divergent D suffices for vanishing error, and bounded D cannot suffice.

The zero-memory critical/subcritical statements also pass: a fixed zero-field output has error at most `1-exp(-2SVR)`, while MP and monotone sector tilt make opposite directions at t=R separated along any subsequence with VR bounded away from zero. Their exact sector root fidelity is `(2j+1)sinh(R/2)/sinh((2j+1)R/2)`. Thus vanishing zero-memory error forces VR->0.

## 13. Shrinking-curvature example still has the 3/2 leading obstruction

In Section 9 replace the fixed c by `c_V=1/log(e+kappa)`, where `kappa=VR->infinity`. For sufficiently large V, `m+c_V<S`, so the centers remain uniformly away from the support endpoints. A finite initial prefix can be chosen independently.

Now

\[
\sigma^2=c_VV/R,\qquad
\sigma/V=\sqrt{c_V/\kappa}\to0,\qquad
\sigma\to\infty,
\]

and the full center sweep has length `c_V V`. At t=0 the factor `2j+1` does not destroy concentration at m. At t=R, the exact Gaussian/bracket representation concentrates at `m+c_V`, which also tends to m. MLR controls the lower tail by q_0 and the upper tail by q_R. It follows that

\[
\boxed{\sup_{0\le t\le R}q_t(|j/V-m|>\delta)\to0
\quad\text{for every fixed }\delta>0.}
\]

This stronger premise nevertheless does not reduce the leading archive exponent. On `[R/4,3R/4]`, the radial center range is `c_V V/2`; spacing by `32 sigma` gives `Theta(sqrt(c_V kappa))` radial hypotheses because `c_V kappa=kappa/log(e+kappa)->infinity`. The same common angular packing has `Theta(kappa)` points. The earlier probability bounds retain controlled constants: the bracket correction is `exp(-m kappa/4)`, and boundary/lower-spin tails are even smaller, of order `exp(-c_0 kappa/c_V)`. Corrections to the Gaussian second moment relative to sigma^2 vanish because `(kappa/c_V)exp(-c_1 kappa)->0`.

Thus the fixed joint classifier and D/N argument give

\[
\boxed{D\ge c\,\kappa\sqrt{c_V\kappa}
=c\,\frac{\kappa^{3/2}}{\sqrt{\log(e+\kappa)}}.}
\]

Its logarithm retains leading coefficient 3/2. Unquantified concentration under every tilted field is therefore insufficient to infer the known-magnitude leading cost. In this example the endpoint response is of order `R[mu(R)-mu(0)]~c_V kappa`, exactly consistent with the response bound in Section 10.

## 14. Physical and final status boundary

The response algebra in the source is correct:

\[
u_j(t)=\partial_t s_j(t)
=\tfrac14\operatorname{csch}^2(t/2)
-(j+1/2)^2\operatorname{csch}^2((j+1/2)t),
\]

\[
I_{\rm sector}(t)=A''(t)-\mathbb E_{q_t}u_j(t),
\qquad u_j(0)=j(j+1)/3.
\]

Also `j-s_j(t)=1/(e^t-1)-(2j+1)/(e^((2j+1)t)-1)` lies in `[0,1/t]`. Hence the proposed public magnetization connection `R[mu(R)-mu(0)]<=R[A'(R)-mu(0)]+1` is valid. These are finite-model identities, not spatial susceptibility theorems.

I have not independently verified the physical manuscript's pressure, spatial, or large-deviation proof. Its asserted fixed macroscopic upper-tail rate, if accepted, can support uniform tilted macroscopic concentration, but no quantitative endpoint-response or sector-Fisher rate follows just from unquantified concentration. The shrinking-curvature example makes this distinction substantive.

No load-bearing mathematical gap is identified in the audited envelope, endpoint, confinement, critical-ball, or engineered-lower constructions. The raw h-mass convention, public R<=1 condition, D-independent critical remainders, and arbitrary-H scope of the lower examples should remain explicit. Particular local physical applications still require valid quantitative sector information. No assertion about efficient preparation, purification preservation, historical novelty, or external certification follows from this audit.
