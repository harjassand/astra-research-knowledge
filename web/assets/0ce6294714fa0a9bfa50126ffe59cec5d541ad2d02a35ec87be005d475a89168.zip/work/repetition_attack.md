# Cubic commuting repetition inside Lin's synchronous CL compression interface

7 October 2026. Status: **internally derived conditional consequence** of the
cycle19 commuting spectral repetition theorem. The inherited operator proof
has internal PASS gates but no external or formal validation. Lin's compression
and coRE theorem are external premises; their full proofs were not audited here.
Historical novelty remains UNKNOWN. The new work below closes a particular
normal-form preservation debt left by the earlier final-verifier wrapper.

## Result and inherited boundary

The inherited run at
`/Users/harjas/Documents/Codex/2026-10-07/you-have-access-to-over-100-5/work/quantum_repetition/NAMED_AMPLIFICATION_AND_ENCODING_GATE.md`
already acquired a constant question gap by one-sided erasure and amplified a
named Lin commuting verifier. It explicitly did not preserve the synchronous
CL/oracularizable interface used recursively in compression. Repeating that
final-verifier application is not the contribution here.

**Quantitative replacement theorem.** Let G be a finite synchronous two-player
one-round game, with common finite nonempty answer alphabet A and a
(h,m,p)-conditionally linear (CL) question sampler in Lin's convention:
the field is **F_(2^p), with p an odd positive integer**, not F_p. For either
finite tensor or arbitrary commuting strategies, write v=omega^t(G). There is
an explicit synchronous game J(G) with the SAME answer alphabet such that

    omega^t(J(G)) = 1 - (49/64)(1-v),
    sigma_J >= 1/16,
    J(G) has a (h+1,m+6,p)-CL sampler.

It preserves a perfect oracularizable strategy whenever one is supplied
for G, and preserves global synchrony of that strategy when also supplied.
Thus its r-fold all-wins repetition has parameters

    (h+1,r(m+6),p),     answer alphabet A^r,

and, for v <= 1-epsilon,

    omega^t(J(G)^tensor r)
      <= exp[-117649 epsilon^3 r / (2^32(1+2 ln|A|))].       (1)

All constants apply to the actual CL wire sampler, including its independent
selector salts, rather than only to an abstract question law with one bottom
symbol. The original question law's graph gap is never computed. The
construction has a deterministic acceptance predicate and contains no hidden
private acceptance coin.

For a uniform synchronous h-level CL verifier sequence with public finite
effective answer bound |A_n| <= exp((B(n)-1)/2), a public rational lower
soundness gap epsilon(n)>0 and integer L(n)>=1, take

    r(n) = ceil[2^32 B(n) L(n)/(117649 epsilon(n)^3)].        (2)

The sampler depends only on Q and these public bounds. Its decider calls D;
no semantic analysis of D, value computation, support enumeration or
strategy acquisition is performed. A perfect oracularizable yes strategy is
preserved, and no-instance value is at most exp(-L(n)). In particular L=1
gives soundness below 1/2 and is a replacement for the soundness-amplification
part of Lin Proposition 6.18.

## 1. Deterministic game and exact value

Put alpha=1/8 and q=1-alpha=7/8. Each player is independently erased with
probability alpha. Logical question law:

    nu(x,y)          = q^2 mu(x,y),
    nu(bottom,y)    = alpha q mu_Y(y),
    nu(x,bottom)    = q alpha mu_X(x),
    nu(bottom,bottom)=alpha^2.

Choose any existing answer a0 in A. Ordinary questions retain their ordinary
answers. On any erasure pair the erased player is required to answer a0,
with one explicit diagonal repair: on IDENTICAL full questions, accept
exactly when a=b. On other ordinary pairs use D; on other erasure pairs
require a0 from every erased side and accept any ordinary-side answer.

This diagonal repair matters. Lin defines synchronous games by
D(x,x,a,b)=1[a=b], including acceptance of every equal-answer diagonal.
Merely requiring a0 on an erased/erased diagonal would violate that exact
definition. Our predicate imposes the diagonal rule first. It is Boolean,
efficient, and makes J(G) synchronous on its entire formal question set.
Malformed unsupported questions can be assigned the same diagonal rule and
rejection elsewhere; they have zero probability.
When the original question law and predicate are symmetric, the identical
independent erasure rules and common fixed answer also preserve symmetry.

For any strategy, the ordinary/ordinary branch has probability q^2. Its
restriction is a legal strategy for G, hence contributes at most q^2 v;
all other branches contribute at most 1-q^2. Therefore value is at most
1-q^2+q^2v. Conversely use any original strategy on ordinary questions and
the POVM {I at a0, 0 at other answers} on erased inputs. This succeeds on
every erased branch, including the repaired diagonal. Its success is exactly
1-q^2+q^2*u, where u is its original success. Taking suprema proves the identity.

There is no added answer to merge. Supremum attainment is unnecessary. On
the CL wires, ordinary questions carry private selector salts. These are
independent across players and independent of the original seed, conditional
on neither player being erased. Average each player's POVM independently
over its ordinary salts. The averaged POVMs remain complete and retain
all cross-input commutators. The same ordinary-branch upper bound follows.
Ignoring those salts realizes the lower bound.

## 2. Gap certificate, including wire aliases

The pair support is connected: every ordinary local question connects to
every supported erased question on the other side, and erased/erased pairs
also have positive mass. No minimum atom is needed.

Let rho_mu be the maximal correlation of centered local functions under mu,
with rho_mu<=1 and rho_mu=0 if one centered local space is zero. For centered
real functions a,b on the logically erased inputs, let ma,mb be the ordinary
means. Global centering gives

    a(bottom)=-q ma/alpha,       b(bottom)=-q mb/alpha.

Expanding the four branches gives

    E_nu[a b] = q^2 Cov_mu(a_ordinary,b_ordinary),
    ||a||_nu^2 = q Var_mu_X(a_ordinary)+(q/alpha)|ma|^2,
    ||b||_nu^2 = q Var_mu_Y(b_ordinary)+(q/alpha)|mb|^2.

Consequently |E[a b]|<=q rho_mu ||a|| ||b||. The same bound holds for the
actual CL wires: first average a and b over each side's selector salts
conditional on its branch and ordinary question. The displayed covariance
identity is unchanged, while conditional Jensen only lowers the norms.
Thus the salts create no hidden common question label. When the original
maximal correlation is attained by nonzero centered local functions, using
those functions on ordinary inputs and zero on erased inputs gives equality
rho_J=q rho_mu.

For a centered pair function f, write a=P_X f, b=P_Y f and
S=||a||^2+||b||^2. By the local correlation bound,

    ||a+b||^2 <= (1+q rho_mu) S,
    S=<f,a+b> <= ||f|| sqrt((1+q rho_mu)S).

It follows that

    <f,(P_X+P_Y)f/2> <= (1+q rho_mu)||f||^2/2,
    sigma_J >= (1-q rho_mu)/2 >= (1-q)/2 = 1/16.           (3)

This is a universal algebraic certificate. With an original two-component
equality question law, rho_mu=1 and the witness f=a(X)+b(Y) has eigenvalue
15/16 on the actual selector-decorated pair chain. Hence the worst-law
constant 1/16 is attained; no unproved original sampler expansion is used.

## 3. Exact CL implementation and its probability

A CL sampler uses a uniform seed in F_(2^p)^m. The canonical field-coordinate
map kappa is a bijection with p fair bits. Lin's own Lemma 9.4 already uses
the first canonical bit of one uniform field element to choose half-erasure.
Here add six independent field elements

    u_A,1,u_A,2,u_A,3, u_B,1,u_B,2,u_B,3.

The new initial CL register is F_(2^p)^6. Alice's zeroth-level linear map
copies her three elements to the first three output slots and writes zero
in the remaining three slots. Bob copies his own three elements to the
same first three output slots, also writing zero in the remaining slots.
These are fixed F_(2^p)-linear maps; Alice learns none of Bob's selectors.

A side is erased iff the first canonical bit of EACH of its three selector
elements equals 1. Independent uniform field elements give exactly

    Pr[erased] = (1/2)^3 = 1/8,

for every odd p>=1. In particular p=1 is allowed. No non-dyadic coin,
interval approximation, rejection sampling, or change of field is needed.

After this initial register, embed each old register in its original body
coordinates. At an old stage j, the new linear map is zero if the initial
local selector prefix says erased; otherwise it is precisely the old
stage-j linear map selected by the old body prefix. For each fixed prefix,
the selected map is linear on that stage's fresh input register, exactly
as required by Definition 5.1. Thus there are h+1 levels and m+6 field
coordinates. Original questions are reproduced on ordinary inputs; erased
bodies are zero. The initial prefix identifies the branch without exposing
the other player's selectors or the original seed.

The parser uses the initial prefix to interpret the body. All six selector
positions are charged in the formal wire dimension, including the three
constant output slots. Independent parallel composition of r copies keeps
the number of levels h+1 and multiplies the dimension by r. The h+1 entry
in the Parameter mode is explicit; one should not copy an apparent h
instead of h+1 in the source's later pseudocode.

## 4. Perfect oracularizability is preserved

This is stronger than ordinary all-input cross-player commutation. In Lin
Definition 3.15, the Alice and Bob operators inside the same tracial algebra
must commute whenever their QUESTION PAIR has positive probability.
It is not automatic from the commuting-operator strategy definition.

Extend a supplied perfect oracularizable strategy by ignoring ordinary
selector salts and using the identity/default POVM on every erased input.
When both questions are ordinary, positive mass implies the original pair
had positive mu mass, so the required internal commutators vanish by the
original premise. When either question is erased, that side's effects are
I or 0, so every required internal commutator vanishes. The same state,
tracial algebra and embedding therefore work. All erased tests accept this
strategy, including every diagonal, and original tests accept perfectly.

For r copies, tensor the states and the tracial representations. The joint
measurement effects are tensor products of their component effects. Positive
repeated question mass means positive mass in every component, so all
oracularizable commutators still vanish. Equal full question strings with
positive sampled mass give equal answers with certainty. A globally
synchronous original strategy remains globally synchronous. The all-wins
predicate itself is synchronous on every full question string.

This is precisely the property a hidden product-question refresh could lose:
new positive ordinary question pairs might impose internal commutation
conditions absent from G. Replacing all refreshed measurement effects by
identities is the essential repair, and the explicit tags let honest players
do it. We do not infer oracularizability from ordinary commuting soundness.

## 5. Cubic bound and quantitative compression consequence

The inherited connected-support all-wins theorem is

    omega^t(H^tensor r)
       <= exp[-sigma_H(1-omega^t(H))^3 r/(1024(1+ln d_H))].

For J(G), d_H=|A|^2, its gap is at least 1/16, and original soundness
loss epsilon becomes (49/64)epsilon. Consequently its exponent is at least

    (1/16)(49/64)^3 epsilon^3/(1024(1+2 ln|A|))
      =117649 epsilon^3/(2^32(1+2 ln|A|)).

This proves (1) for all r>=1, including its all-wins endpoint. Near-optimal
independent original strategies show output value 1 whenever input value
is 1; preservation of an actual perfect oracularizable strategy uses the
separate explicit construction above.

The named use is Lin Proposition 6.18, the third subroutine in Theorem 6.5.
It needs a synchronous h-level CL input, an h+1-level CL output, sampler
independence from D, perfect oracularizable completeness, and soundness at
most 1/2. Sections 1-4 establish those structural conditions. Choosing a
public answer bound B and L=1 in (2) establishes its soundness condition
with a cubic reciprocal-gap cost instead of the displayed seventeenth power.
If that subroutine receives a 6-level input, its output remains 7-level.
If applied to a final 7-level input, it produces 8 levels; we do not silently
identify an 8-level sampler with a 7-level one. The construction is usable
at the same stage as the source's h-to-h+1 anchoring procedure.

For example, with public bounds

    ln|A_n|=O((ln n)^u),  T_sample+T_D+p(m+6)=O((ln n)^w),
    epsilon(n)>=(ln n)^(-b),  L(n)=O((ln n)^ell),

the repetition count is O((ln n)^(u+3b+ell)) and the compiled referee time
is at most that factor times its original cost, plus public parameter
arithmetic and string parsing. The old displayed epsilon^17 estimate
requires a count with exponent u+17b+ell and a logarithmic prefactor in
1/epsilon. This identifies a reduction of 14b in the repetition count's
polylogarithmic exponent on this stated interface. It does not assert a
corresponding improvement of the entire compression theorem's final gamma:
the earlier question/answer reductions and their constants can dominate.

For the two-sided ordinary probability q, the worst-law cubic coefficient
before the answer factor is (1-q)q^6/2048. Differentiation maximizes it at
q=6/7. Our dyadic q=7/8 is within one percent and has exact finite
canonical-bit sampling. This optimization is elementary, and is not itself
the substantive normal-form result.

### Synchronous two-error amplification

There is also a threshold version on the same CL interface. Suppose the
no-instance soundness is at most s, and a supplied G-strategy is globally
synchronous with honest acceptance at least c>s. Put Delta=c-s. Extend
it by the identity/default measurements above and take independent copies.
Their mean acceptance is at least c_J=15/64+(49/64)c; the no-instance value
is at most s_J=15/64+(49/64)s. Use the midpoint threshold

    t_J=15/64+(49/128)(c+s).

On identical full question strings, explicitly require identical full answer
strings. Elsewhere apply the acceptance-count threshold ceil(r*t_J). This
keeps the whole repeated predicate strictly synchronous: on a diagonal,
equal answer strings already win every constituent diagonal test, while
unequal strings are rejected. The extra rule only reduces arbitrary-strategy
acceptance compared with the ordinary threshold. It costs no additional
question sampling or CL level. The supplied globally synchronous honest
strategy never triggers the extra rejection, so its completeness is intact.

The inherited connected threshold theorem and Hoeffding give respectively

    no acceptance <= exp[-117649 Delta^3 r/(2^35(1+2 ln|A|))],
    honest rejection <= exp[-2401 Delta^2 r/8192].           (4)

Thus both errors are <=exp(-L) if

    r>=max{2^35 B L/(117649 Delta^3),8192 L/(2401 Delta^2)}.

The global-synchrony premise on the honest strategy is necessary for this
particular diagonal repair. Ordinary c-completeness alone does not establish
that it will pass the additional global diagonal condition. Perfect
oracularizable strategies supplied with global synchrony remain perfect
through the same construction.

## 6. Full cost ledger and limits

Assume the original sampled questions have formal length p*m bits per
player, the original finite answers have wire budget a bits, the sampler
uses p*m seed bits, and sample/check costs are T_sample,T_D. Per repetition:

* Seed: p(m+6) independent fair bits. Over r copies: r*p(m+6). The CL
  prefix salts are actual communicated inputs and are accounted for above.
* Question wires: r*p(m+6) bits per player, with formal alphabet
  F_(2^p)^(r(m+6)). Logical support can be enormous; no table is acquired.
* Answer wires: r*a bits per player for a fixed-length original alphabet.
  The logical repeated alphabet is A^r, with NO new answer symbol. Variable
  bounded words can use their original delimiter convention or lengths,
  adding O(r log(a+1)) parsing bits/time if a fixed tuple encoding needs it.
* Referee time: O(r[T_sample+T_D+p(m+6)+a]) plus the time for computing the
  public rational r(n). The Q modes are obtained by direct series/parallel
  composition; all old map/predicate computations and clocks are charged.
* Compiler size/time: polynomial in the original machine descriptions and
  public bound programs; the uniform output machine computes r(n) at run
  time. Sampler independence uses a PUBLIC answer bound, not |A_n| acquired
  by inspecting D. If source time bounds give at most a read bits, a safe
  effective-prefix alphabet has size <=2^(a+1), so B=1+2(a+1) suffices.
* Players, rounds and quantum message type are unchanged. Classical strings,
  the number of predicates, and total predicate locality all grow with r.
  No finite-dimensional honest strategy is acquired from a commuting one.

The result is a protocol-level compression subroutine with an improved
quantitative amplification cost. It supplies no constant-query PCP,
constant-arity Hamiltonian, polynomial positive sparse encoding, or method
to prepare the proof's resolvent/barycenter states. It does not calculate
the game values or resolve the original sparse-PCP acquisition target.

## 7. Prior-art gate for the discarded hidden-product route

Before finding the recursive-interface construction, I checked the mixture

    mu_alpha=(1-alpha)mu+alpha mu_X mu_Y,

with hidden automatic acceptance on the product branch. Its one-game value
is exactly alpha+(1-alpha)v, alphabets are unchanged, its full product
support has gap at least alpha/2, and fractional tested masks retain the
cycle19 exposure proof because theta*(-h ln h)<=-(theta h)ln(theta h).
Private branches remain conditionally independent given complete questions
and answers; joint answer POVMs depend only on the questions, so there is
no private-coin leakage. This would give a cubic commuting threshold bound
and a full-support constant-gap hardness consequence.

However this underlying dummy-question transformation is established prior
art: Kempe--Vidick, arXiv:1012.4728v2, Definition 4, explicitly sends hidden
independent-marginal questions and ignores their answers in Feige--Kilian
repetition. It is NOT a new wrapper. Their checked theorem uses a different
fixed-count schedule and the projection/consistency framework; our source
mechanism would give a distinct constant-density i.i.d. cubic commuting
analysis, not novelty for the transformation itself. Also the mixture is a
private-randomized predicate and does not automatically preserve Lin's
deterministic synchronous CL/oracularizable normal form. Those debts are
why it is not the main theorem here.

There is likewise no claim of a new computability obstruction. Conditional
on Lin's coRE-completeness and NPA convergence, no total recursive bound in
the finite instance description can guarantee a finite NPA level certifying
every no instance even after this constant-gap wrapper: use L=1, so every
no-instance value is below 1/2 and yes value is 1. Convergence eventually gives an NPA
upper bound below 3/4 on every no instance. A recursive level bound plus
exact finite real-algebraic SDP decision at that level would decide the
coRE-complete promised language. This is a
standard consequence of undecidability, not a consequence specific to the
improved cubic rate or a new major-open-problem resolution.

## Sources, read scope, and verification

Inherited inputs read: cycle19 quantum-bridge REPORT, independent finite
gate and VERDICT; the commuting theorem's interface, game-level proof and
anchoring comparison; heterogeneous/fractional mask extension; the later
run's RESEARCH_STATE and named amplification/encoding gate. The original
Literature Digestion tree and inherited workspace were read only.

Primary literature verified live through arXiv metadata and its recoverable
primary HTML snapshot (the web tool rejects Lin's 5.1-MB HTML). Precise Lin
read scope here: Sections 2.1 canonical field coordinates, 3.5 synchronous
games/Definition 3.15, Definitions 5.1/5.5/6.4, Theorem 6.5, Proposition
6.18, and Definition 9.1/Lemma 9.4/proof of Proposition 6.18. The inherited
read scopes also cover Theorem 9.3 and Appendix A's theorem interface.

* OpenAI, *Threshold parallel repetition for finite-dimensional entangled
  games*, 25 September 2026, pinned commit adc7f1241b42e322a6451854ab7e4b4c146bf78a:
  [primary source](https://github.com/openai/math/tree/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Threshold-parallel-repetition-for-finite-dimensional-entangled-games-September-25-2026).
* Junqiao Lin, *MIPco=coRE*, arXiv:2510.07162v1, 8 October 2025:
  [primary article](https://arxiv.org/abs/2510.07162v1). The CL/synchronous/
  oracularizable definitions and named subroutine are taken from this source;
  the modified sampler, predicate, gap and cubic quantitative composition
  are reconstructed above.
* Julia Kempe and Thomas Vidick, *Parallel Repetition of Entangled Games*,
  arXiv:1012.4728v2, 11 May 2011, Definition 4 and Theorems 7/9:
  [primary text](https://arxiv.org/html/1012.4728v2).
* Navascues, Pironio and Acin, *A convergent hierarchy of semidefinite programs
  characterizing the set of quantum correlations*, arXiv:0803.4290v1:
  [primary abstract](https://arxiv.org/abs/0803.4290). Only the stated
  commuting completeness of the hierarchy is used; its proof was not read.

Companion exact checks in `repetition_attack_check.py` enumerate canonical
selector events, verify the 15/16 pair-chain eigenfunction on the actual
decorated worst-case sampler using rational arithmetic, and exhaustively
check the repaired fixed-answer predicate/value for a small synchronous
two-answer game. They are scoped diagnostics, not proofs of the universal
theorem. External/operator specialist review and historical priority remain
outstanding.
