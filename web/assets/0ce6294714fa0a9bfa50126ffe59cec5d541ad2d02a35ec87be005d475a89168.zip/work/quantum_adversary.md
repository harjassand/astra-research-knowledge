# Independent adversarial reconstruction: uniform tracial Gaussian equivalence

Audit date: 7 October 2026. Sources were read only. This report audits the fixed-dimension density-operator statement in `/Users/harjas/Documents/Codex/2026-10-07/you-have-access-to-over-100-2/outputs/spectral_collision_research.tex`, chiefly lines 330–633, including the coherent-channel dependency at lines 76–135. It also checks the corresponding work notes. The two earlier positive agent audits were treated as maps to the arguments, not as evidence of their correctness.

**Verdict:** I found no fatal flaw or counterexample in the audited claim. I independently reconstructed the angular replacement, determinant cancellation, continuous normalizer, uniform translated-Gaussian small-gap bound, jitter comparison, and universal reverse channel. The stated error `C_d(delta+n^(-1/8))` is consistent with this reconstruction for fixed `d`. The claim remains an internally reviewed research derivation, not an externally certified theorem or a novelty determination. Downstream uses should preserve that status.

## 1. Exact interface and quantifiers

Let `H_0` be the real Hilbert space of traceless Hermitian matrices with the Hilbert–Schmidt inner product. Put

\[
r=d^2-1,\qquad R=d(d-1)/2,\qquad N=n+R,
\qquad c_H=\prod_{k=1}^{d-1}k!.
\]

The audited experiment is

\[
\{\rho^{\otimes n}:\rho\in\mathcal B_\delta\},\qquad
\mathcal B_\delta=\{\rho\ge0:\operatorname{Tr}\rho=1,
\ \|d\rho-I\|_{\rm op}\le\delta\},\quad 0\le\delta\le1/2.
\]

The comparison laws are `N_(H_0)(sqrt(n)(rho-I/d), I_(H_0)/d)`. The claim has one pair of channels for each `n,d`, valid simultaneously over every `delta` in this range. It does not permit a new kernel for each true spectrum or each shrinking schedule.

All proof constants below can be chosen using only `d`, because `p_min>=1/(2d)` and `p_max<=3/(2d)`. The eigenbasis, the eigenvalues, and the sequence `delta_n` are all unknown to the channels. Parameter-dependent centers and good sets occur only in the analysis. The estimates that require small relative error can first be proved when `delta+n^(-1/8)` is below a fixed dimension-dependent threshold; both distances are at most one, so enlarging `C_d` covers its complement and the finitely many small n.

## 2. The reverse-channel dependency can be reconstructed

Write `Q_lambda(B;U)=<lambda,U|pi_lambda(B)|lambda,U>`. Filtering the coherent resolution

\[
h_\lambda\int P_\lambda(U)\,d\mu(U)=I
\]

by `pi_lambda(rho^(1/2))` gives a positive coherent representation of `tau_(lambda,rho)`. A QR decomposition maps a filtered coherent vector to another normalized coherent vector. The inverse change of flag has Jacobian

\[
J_{\rho^{-1/2}}(U)=
\frac{\det(\rho^{-1})^{d-1}}
{\prod_{k<d}\det(U_k^*\rho^{-1}U_k)^2}.
\]

Consequently the mixture density and the coherent measurement density are respectively

\[
P(U)=\frac{h_\lambda}{Z_\lambda}
\frac{J_{\rho^{-1/2}}(U)}{Q_\lambda(\rho^{-1};U)},
\qquad
f(U)=\frac{h_\lambda}{Z_\lambda}Q_\lambda(\rho;U).
\]

Since `pi_lambda(rho^-1)=pi_lambda(rho)^-1`, the positive-operator Cauchy–Schwarz inequality gives `Q_lambda(rho;U) Q_lambda(rho^-1;U)>=1`. Compression determinants are bounded below by products of the smallest eigenvalues, and the ordered eigenflag attains all these minima at once. Thus

\[
\sup_U J_{\rho^{-1/2}}(U)=\prod_{i<j}p_i/p_j,
\qquad f(U)\ge c(p)P(U),\quad
c(p)=\prod_{i<j}p_j/p_i.
\]

Integrating projectors proves `C_lambda(tau)>=c(p)tau`. The exact Schur sector probabilities and mixed multiplicity registers are retained, so `C_(n,d)(rho^n)>=c(p)rho^n`. Hence

\[
T(C_{n,d}(\rho^{\otimes n}),\rho^{\otimes n})
\le1-c(p)\le C_d\delta.
\]

This dependency has no fixed-gap assumption. Repeated highest-weight entries merely introduce redundancy in the complete flag; they do not invalidate the positive mixture or its minorant.

## 3. The published HCIZ input has the required uniformity

I checked [Graczyk–Sawyer, Theorem 3.1](https://arxiv.org/html/2012.12022), against the [published article record](https://www.numdam.org/articles/10.5802/crmath.188/). Its estimate is uniform in both arguments over the closed positive Weyl chamber. The paper defines its flat spherical function as a compact-group orbital exponential integral. Specializing to type `A_(d-1)` therefore gives, with dimension-dependent normalization changes absorbed,

\[
K(t)=\int e^{-tE_{\lambda,p}(W)}d\mu(W)
\asymp_d\prod_{i<j}
[1+t(\lambda_i-\lambda_j)(p_i-p_j)]^{-1}.
\]

This is a global bound, including chamber walls, rather than an asymptotic statement for fixed regular arguments. The broader [Theorem 2.6](https://arxiv.org/html/2111.13529) also supplies the multiplicity-one case and explicitly extends the estimate to the boundary by continuity.

For `a=1/p_max`, `b=1/p_min`, `b/a<=3`. The bound implies

\[
K(a/2)/K(b)\le C_d\prod_{i<j}
\frac{1+b(\lambda_i-\lambda_j)(p_i-p_j)}
{1+(a/2)(\lambda_i-\lambda_j)(p_i-p_j)}\le C_d.
\]

No root gap was divided out here.

## 4. Coherent-to-orbital replacement does not grow with the sector

Let `ell_k=lambda_k-lambda_(k+1)`, `Q_k=W_k W_k^*`, and

\[
t_k=\sum_{i\le k}p_i-\operatorname{Tr}(P Q_k)\ge0,
\qquad E=\sum_{k<d}\ell_k t_k.
\]

For the coherent potential, compression eigenvalues `q_i` satisfy `p_i>=q_i>=p_min`, so

\[
a t_k\le\sum_{i\le k}(\log p_i-\log q_i)\le b t_k.
\]

For the orbital potential, decompose `P` into its ordered increments and rank-j prefix projections `P_j`. The coefficient of its j-th increment is `min(k,j)-Tr(Q_k P_j)>=0`. Each logarithmic increment is between `a` and `b` times the corresponding eigenvalue increment. This proves separately that both potentials `Phi_lambda` and `Gamma_lambda` lie in `[aE,bE]`, and therefore

\[
|\Phi_\lambda-\Gamma_\lambda|\le(b-a)E\le C_d\delta E.
\]

Every interpolated density has an E-moment bounded by

\[
\frac{\int E e^{-aE}d\mu}{K(b)}
\le\frac{2}{a}\frac{K(a/2)}{K(b)}\le C_d.
\]

Differentiating normalized densities and integrating the derivative gives conditional TV `<=C_d delta` for **every** sector. Thus sectors with large weights cannot amplify the pointwise `delta` error into `n delta^2` or `sqrt(n) delta`.

The Weyl shift `l=lambda+(d-i)_i` contributes a nonnegative orbital potential bounded by `R log(p_max/p_min)<=C_d delta`. It adds another uniform `O_d(delta)` cost. This is essential: the coherent law is not literally an HCIZ conditional law, but the explicit replacement argument supplies the required comparison.

## 5. Exact cancellation and repeated-spectrum continuation

For a legal strictly decreasing nonnegative integer vector `l` of trace `N`,

\[
m_\lambda=\frac{n!\Delta(l)}{\prod_i l_i!},\qquad
s_\lambda(p)=\frac{\det[p_i^{l_j}]}{\Delta(p)},\qquad
I_l(\log p)=\frac{c_H\det[p_i^{l_j}]}
{\Delta(\log p)\Delta(l)}.
\]

Multiplying the exact sector probability `m_lambda s_lambda(p)` by the normalized HCIZ flag density gives precisely

\[
Q_\rho(l,dW)=\frac{u_\rho(l,W)}{Z_d(\rho)}d\mu(W),
\quad
u_\rho(x,W)=\frac{\Delta(x)^2
e^{\operatorname{Tr}(\log\rho\,W\operatorname{diag}(x)W^*)}}
{\prod_i\Gamma(x_i+1)},
\]

\[
Z_d(\rho)=\frac{c_H}{n!}\frac{\Delta(p)}{\Delta(\log p)}.
\]

This coefficient follows algebraically before any asymptotic approximation or discrete-tail estimate. At repeated eigenvalues, each factor `(p_i-p_j)/(log p_i-log p_j)` is the positive logarithmic mean, continued to `p_i` at equality. It lies in `[p_min,p_max]`. The formula therefore remains finite, positive, and uniform at collisions.

As an independent endpoint check, at `rho=I/d`, `Z_d=c_H d^-R/n!`, and the auxiliary law is exactly the original Schur law `m_lambda h_lambda d^-n` with a uniform complete flag. This checks the powers associated with the shift `sum l_i=n+R`.

## 6. Log-Gamma analysis admits a gap-free resolvent proof

On `M>-I`, `Tr M=N`, set

\[
V_\rho(M)=\operatorname{Tr}\log\Gamma(M+I)
-\operatorname{Tr}(M\log\rho),
\qquad M_0=n\rho+(R/d)I.
\]

A direct series proof strengthens the compressed divided-difference argument. Write `R_k=(M+(k+1)I)^-1`. The digamma series, differentiated termwise, gives for Hermitian H

\[
D^2\operatorname{Tr}h(M)[H,H]=
\sum_{k\ge0}\operatorname{Tr}(R_k H R_k H),
\]

\[
D^3\operatorname{Tr}h(M)[H,H,H]=
-2\sum_{k\ge0}\operatorname{Tr}(R_k H R_k H R_k H).
\]

These formulas are valid at repeated eigenvalues. If `m_min>=c_d n`, the third derivative is bounded in absolute value by `C_d n^-2 ||H||_HS^3`, using `|Tr B^3|<=||B||_HS^3` and summing `(m_min+k+1)^-3`.

For every matrix in the entire trace domain, `m_max<N+d-1`. The Hessian is consequently bounded below by

\[
\sum_{k\ge0}(N+d+k)^{-2}\|H\|_{\rm HS}^2
\ge\frac{1}{N+d}\|H\|_{\rm HS}^2.
\]

At `M_0`, digamma asymptotics give the tangent gradient `O_d(1/n)` after removing `log n I`, and the Hessian is `d/n` plus a quadratic-form error `O_d(delta/n+n^-2)`. Setting `M=M_0+sqrt(n)Z` yields

\[
V(M)-V(M_0)=\tfrac d2\|Z\|^2+\mathcal R(Z),
\quad
|\mathcal R(Z)|\le C_d\left[
\delta\|Z\|^2+\frac{\|Z\|+\|Z\|^3}{\sqrt n}\right]
\]

on `||Z||<=c_d sqrt(n)`, while globally

\[
V(M)-V(M_0)\ge c_d\|Z\|^2-C_d/n.
\]

Thus the exponential difference is integrated against a fixed Gaussian envelope, not bounded by taking the largest Taylor remainder on an expanding ball. Polynomial Gaussian moments give relative normalization error and TV error `O_d(delta+n^-1/2)`. The domain boundary is a distance of order `sqrt(n)` from this center and its omitted Gaussian mass is exponentially small.

The true-state center is used only to analyze the density. Its transformation is exactly the target mean, since `(M_0-(N/d)I)/sqrt(n)=sqrt(n)(rho-I/d)`. There is no oracle-dependent channel and no uncentered `n delta^3` remainder.

## 7. Normalizer constants reconstructed from matrix volume

With induced Euclidean measure on the trace-zero hyperplane and normalized flag measure,

\[
J_d=\int_{x_1>\cdots>x_d,\ \sum x_i=0}
\Delta(x)^2e^{-d\|x\|^2/2}dx_{\rm HS}
=c_H(2\pi)^{(d-1)/2}d^{-r/2}.
\]

The full Hermite integral is `d! c_H (2 pi)^(d/2) d^(-d^2/2)`. Dividing by `d!` imposes ordering. Dividing by `sqrt(2 pi/d)` removes the orthonormal trace coordinate `sum x_i/sqrt(d)`. This also calibrates the Weyl matrix-volume factor as `(2 pi)^R/c_H`.

Let `s=R/d`, `m_i=np_i+s`. Stirling gives

\[
e^{-V(M_0)}=e^n n^{-n-R-d/2}(2\pi)^{-d/2}
(\det\rho)^{-1/2}(1+O_d(n^{-1})).
\]

The extra `R` in `sum m_i` cancels the first correction from `log(np_i+s)`. The local matrix volume contributes `n^(r/2)`. Converting this translation-invariant matrix Gaussian integral into eigenvalue/flag measure contributes `J_d`, even when the mean is large or degenerate. The result is

\[
Z_c=\frac{c_H}{n!}d^{-r/2}(\det\rho)^{-1/2}
\bigl(1+O_d(\delta+n^{-1/2})\bigr).
\]

The lattice `A_(d-1)` has covolume `v_d=sqrt(d)`: the basis `e_i-e_d` has Gram determinant d. Also

\[
\Delta(p)/\Delta(\log p)=d^{-R}(1+O_d(\delta)),
\qquad (\det\rho)^{-1/2}=d^{d/2}(1+O_d(\delta)).
\]

Consequently

\[
\frac{Z_c}{v_d Z_d}=1+O_d(\delta+n^{-1/2}),
\]

because `-r/2+d/2+R-1/2=0`. Omitting the lattice covolume or using delta-function trace measure would leave a fatal constant mismatch. The audited source uses the correct measure and covolume. This comparison did not assume discrete gap repulsion or concentration.

## 8. Uniform small gaps for arbitrary deterministic means

For a traceless Gaussian matrix with HS covariance `I/d`, let t be the ordered eigenvalues of any deterministic mean and x the ordered eigenvalues of the random matrix. Weyl integration and the published HCIZ bound give

\[
f_t(x)\le C_d e^{-d\|x-t\|^2/2}
\prod_{i<j}\frac{(x_i-x_j)^2}
{1+d(x_i-x_j)(t_i-t_j)}.
\]

The matrix normalizer is independent of the mean. For nonnegative a,b,

\[
\frac{a^2}{1+dab}\le C_d(1+|a-b|)^2.
\]

If `b>=a/2`, the left side is at most `2/d`; otherwise `a<=2|a-b|`. Write `e=x-t`. All nonselected root factors are bounded by a fixed polynomial in `||e||`. If a selected adjacent gap is at most h, its factor is at most `h^2`. In the orthonormal coordinate along `(e_i-e_(i+1))/sqrt(2)`, this event restricts e to an interval of length `h/sqrt(2)`, whose location may depend on t.

A Gaussian times a fixed polynomial has a uniformly bounded one-dimensional slice after integrating the other coordinates. Extending the chamber to the whole hyperplane therefore gives `C_d h^3` for the selected gap and the same order after a finite union. No constant depends on t:

\[
\sup_{\theta\in H_0}\Pr_\theta\{\min_i(x_i-x_{i+1})\le h\}
\le C_dh^3,\qquad0<h\le1.
\]

The original proof thus does not illicitly import central-GUE repulsion into a growing noncentral family. Its use of the uniform orbital bound closes that issue.

## 9. Jitter, good cells, and the exact universal inverse

The cell `C={sum xi_i=0, max xi_i-min xi_i<=1}` is exactly the root-lattice Voronoi cell. The root inequalities are necessary. For their sufficiency, any integer z of trace zero satisfies `<xi,z><=sum_(z_i>0) z_i<=||z||^2/2`. Thus all Voronoi inequalities hold. Moreover `|xi_i|<1` almost surely, and every legal ordered l remains ordered after jitter except on null boundaries.

The forward law in eigenvalue/flag coordinates on `l+C` is `u_rho(l,W)/(v_d Z_d)`, rather than a continuous matrix density with a constant Vandermonde. Take `K=L=n^(1/8)` and retain cells with lattice gaps greater than K and `|l_i-np_i|<=2L sqrt(n)`. A central continuous matrix with gaps greater than `K+2` rounds to one of these cells. The true lower eigenvalue `np_min>=n/(2d)` makes the legal-boundary failure impossible on this central event for sufficiently large n.

The continuous Gaussian approximation, its tails, and the uniform small-gap estimate imply continuous good-cell mass `1-O_d(delta+n^-1/2+exp(-c_d L^2)+(K+2)^3/n^(3/2))`.

On a good cell,

\[
\Delta(l+\xi)^2/\Delta(l)^2=1+O_d(K^{-1}).
\]

For the source/factorial factor, put `B_i=(W^*log rho W)_(ii)`. Every B_i lies in the logarithmic spectral range, and

\[
h'(l_i+t\xi_i)=\log n+\log p_i
+O_d(L/\sqrt n+n^{-1}).
\]

The scalar `log n` cancels against `sum xi_i=0`; `|B_i-log p_i|<=C_d delta` for every flag. Therefore the logarithmic raw-density change is `O_d(delta+K^-1+L/sqrt(n)+n^-1)=O_d(delta+n^-1/8)`.

Using the independently reconstructed normalization ratio, normalized jitter and continuous densities have ratio `1+O_d(delta+n^-1/8)` on good cells. Integrating this ratio forces the jitter good-cell mass to be large as well. This is a legitimate deduction from already normalized measures, not circular use of an unproved discrete-tail bound. The complementary masses and good-cell density error establish their TV comparison.

The actual kernels use only Schur/coherent measurement, this fixed cell, spectral decomposition, nearest trace-N lattice rounding, and a fixed fallback state. On every forward output outside null boundaries, rounding recovers l and the flag modulo phases. It therefore prepares exactly the measured coherent sector. The multiplicity state is known from `n,d,lambda`. Hence `S_n T_n=C_(n,d)` on every product-state input.

Contractivity now supplies the reverse bound from the forward comparison plus `1-c(p)<=C_d delta`. The inverse neither resamples from a true-spectrum law nor uses any of the proof's good-cell tests.

## 10. Adversarial attacks and remaining status

The following would have been fatal but do not occur in the audited source:

- Treating the coherent conditional density as exactly orbital. It is instead replaced with a sector-uniform `O_d(delta)` estimate.
- Canceling singular character determinants without a collision-safe continuation. The remaining ratio is a product of positive logarithmic means.
- Assuming jitter is an exact log-Gamma matrix density. The changing Vandermonde is compared only on good cells.
- Using good-cell quadrature to assume both a normalizer and discrete concentration. The normalizer is derived independently in matrix coordinates.
- Letting Gaussian small-gap constants depend on the mean. The published uniform HCIZ estimate yields a dimension-only bound.
- Turning true-state centering or good-set selection into an oracle-dependent kernel. Neither appears in either kernel.
- Imposing `delta_n log n->0` through a pointwise Taylor supremum. The proof instead integrates against uniform convexity domination.

I do not identify a surviving load-bearing gap in this route. The resolvent formulas in Section 6 would be useful additions to a revised exposition: they make the derivative bounds at collisions explicit. A precise distinction between ideal continuous channels and computational compilation should also be retained.

The claim does not furnish finite stored memory for a real Gaussian observation, preserve purifications, address growing dimension, or give equivalence at a fixed nontracial limit. It does establish the stated implication for every shrinking schedule if this internally reconstructed proof is accepted: `delta_n+n^-1/8->0` with no further radius condition. There is no new external referee review, formal certification, or priority search in this audit, and no irrelevant integrity replay was performed.
