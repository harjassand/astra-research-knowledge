# Bounded Gaussian experiment memory: prior-art and scope audit

7 October 2026. Source workspaces were read only. Target: Section 3A of `work/quantum_collision.md`, equations (3A.1)--(3A.19).

**Finding.** No primary source located in this bounded search states the exact theorem below. This is not novelty clearance. The posterior-quantization viewpoint is established statistical decision theory, and the lower-bound exponent can be derived from established Shannon/Holevo inequalities. The defensible candidate contribution is the precise fixed-experiment TV statement, its matching positive reconstruction without a tail logarithm, and the resulting critical-orbit precision law. Calling either posterior quantization or the dimension-versus-squared-distortion exponent new would overstate the evidence.

## 1. Exact claim being compared

Let `Theta` be a fixed bounded subset of an affine Gaussian mean space of dimension `s>=1`. After discarding parameter-independent orthogonal Gaussian coordinates and whitening its fixed positive covariance, the experiment is `P_theta=N(theta,I_s)`. An encoder sees one draw `X`; it does not receive `theta`. All input-dependent retained memory is a quantum/classical direct sum of total dimension `D=sum_j d_j`. The decoder outputs a classical observation `Y`. Arbitrary input-independent shared **classical** randomness is free; no input-dependent side register or shared entanglement is included. Define

\[
 e_D(\Theta)=\inf_{\mathcal E,\mathcal D}
    \sup_{\theta\in\Theta}
    \operatorname{TV}\bigl(\mathcal D\mathcal E(P_\theta),P_\theta\bigr).
\]

The claimed law is

\[
 c_\Theta D^{-2/s}\le e_D(\Theta)\le C_\Theta D^{-2/s},
 \qquad 0<c_\Theta\le C_\Theta<\infty.
\]

The lower permits arbitrary quantum memory; the upper is wholly classical. A finite set of `s+1` affinely independent means suffices. This compares **output distributions for every parameter**, rather than squared error of `X`, estimating `theta`, or simulating a known source law. The exponent is the dimension of the continuously varying posterior statistic. It need not equal the dimension of the parameter manifold.

## 2. Primary literature inspected and what it actually covers

| Source and inspected location | Established overlap | What it does not settle here |
|---|---|---|
| Helmut Strasser, *Towards a statistical theory of optimal quantization* (2000), sections 4--5, Lemma 1 and Theorems 7--8; [author manuscript](https://www.math4tune.com/publications/Strasser%202000,%20quantization%20Bock,%20article.pdf). The 2000 proceedings citation is confirmed in Pötzelberger's reference list. | Finite reductions of finite statistical experiments become finite-support quantizations of their standard likelihood/posterior measures; convex Bayes utility governs admissible reductions. | No Gaussian `D^(-2/s)` uniform reconstruction theorem, quantum dimension constraint, or shared-seed converse appears in the inspected text. |
| Klaus Pötzelberger, *MSP-Partitions and Unbiased Quantizations: A Review of Results*, AJS 31 (2002), 201--209, section 3 and Theorem 2; [journal PDF](https://www.ajs.or.at/index.php/ajs/article/download/vol31,%20no2&3%20-%208/426). | Complexity-`m` quantization of a finite experiment is characterized through majorization of its standard measure. Its discussion explicitly connects finite partitions and all bounded decision losses. | Characterization and admissibility are not an asserted minimax TV approximation rate. The PDF's issue year is 2002; the present website's 2016 upload date is not the historical publication year. |
| Erik Torgersen, *Comparison of Statistical Experiments* (1991), chapter 6; [publisher chapter](https://www.cambridge.org/core/books/abs/comparison-of-statistical-experiments/deficiencies/AABD0ACA1EC297492575D9144B71AE7E). Anna Jenčová, *Comparison of quantum binary experiments* (2012), introduction/Theorem 1; [publisher text](https://www.sciencedirect.com/science/article/pii/S0034487712600433), [author arXiv](https://arxiv.org/abs/1110.4792). | Deficiency expresses worst decision-risk loss, with a randomization criterion in classical experiments. The quantum binary paper precisely distinguishes classical and quantum comparison. | These inspected results do not optimize approximation through a prescribed finite memory dimension. Torgersen's full book was not accessible in this run. |
| Tobias Koch, *The Shannon Lower Bound is Asymptotically Tight*, arXiv 1504.08245, equations (2)--(4), Theorem 2; [primary manuscript](https://arxiv.org/pdf/1504.08245). Victoria Kostina, *Data compression with low distortion and finite blocklength*, equations (5)--(7); [primary manuscript](https://arxiv.org/pdf/1510.02190). | The continuous squared-error information lower bound already has `s/2 log(1/distortion)` scaling for a source with finite differential entropy. Low-distortion and finite-length refinements are established. | Their fidelity criterion concerns coupled source/reconstruction distortion, not uniform preservation of every law in a fixed statistical experiment. That distinction requires the posterior-risk conversion. |
| A. S. Holevo, *Bounds for the Quantity of Information Transmitted by a Quantum Communication Channel* (1973); [primary journal record](https://www.mathnet.ru/eng/ppi/v9/i3/p3). Nilanjana Datta, Min-Hsiu Hsieh and Mark M. Wilde, *Quantum rate distortion, reverse Shannon theorems, and source-channel separation*, IEEE IT 59 (2013), Theorem 8; [primary manuscript](https://arxiv.org/pdf/1108.4940). | Accessible classical information is bounded by the Holevo entropy bound. Theorem 8 relates classical source rate-distortion to quantum-channel Holevo capacity in the memoryless block regime. | The latter is not a one-observation uniform Gaussian experiment-reconstruction theorem. It nevertheless makes the information-versus-distortion quantum bottleneck established prior machinery. |
| Robert M. Gray and David L. Neuhoff, *Quantization*, IEEE IT 44 (1998), sections IV and V; [paper mirror](https://www.math.ucdavis.edu/~saito/data/quantization/44it06-gray.pdf). James A. Bucklew and Gary L. Wise, *Multidimensional asymptotic quantization theory with rth power distortion measures*, IEEE IT 28 (1982), 239--247; [author-university repository record](https://minds.wisconsin.edu/handle/1793/9810). | Fixed-rate vector quantization has the familiar power-distortion dimension exponent, including `D^(-2/s)` for squared error. | Atomic reconstruction of a continuous law has TV distance one. A distortion quantizer theorem alone is therefore not the present positive TV-reconstruction upper. The Bucklew--Wise full file was not retrieved; its identity was checked at its institutional record and in the inspected Gray--Neuhoff paper. |
| Yuxiang Yang, Ge Bai, Giulio Chiribella and Masahito Hayashi, *Compression for quantum population coding*, IEEE IT 64 (2018), 4766--4783, main theorem and the classical Gaussian part of the QLAN compression; [primary arXiv](https://arxiv.org/abs/1701.03372), [accepted-paper university copy](https://hub.hku.hk/bitstream/10722/258244/1/content.pdf). | Parametric iid quantum compression, hybrid memories, Gaussian comparison, and leading memory proportional to `log n` are established. | Leading growing-signal cost with vanishing error does not determine the fixed bounded Gaussian experiment's sharp `epsilon` exponent. Its noncommuting displaced-thermal obstruction also concerns a different source experiment. |

Lucien Le Cam's *Sufficiency and Approximate Sufficiency*, Annals of Mathematical Statistics 35 (1964), 1419--1455, [original DOI](https://doi.org/10.1214/aoms/1177700372), is the historical starting point. The publisher returned an access challenge, so its full text was **not** inspected here; the historical role and randomization framework were checked in the primary works above. This audit does not attribute a quantitative finite-memory theorem to that unread paper.

One tempting recent hit can be rejected precisely: *Information-Preserving and Model-Aware Voronoi Dequantization of Weighted Discrete Laws*, [publisher article](https://www.mdpi.com/2571-905X/9/5/103), claims a sharp `h^2` result in **Wasserstein-1** for reconstruction from exact bin masses. It also starts from a supplied discrete law. Neither is the unknown-parameter uniform-TV bottleneck here. The publisher search text was available; direct full-text fetching was rate limited. It was used only to distinguish the stated criterion and input interface.

## 3. The quantum lower exponent is already a corollary of standard inequalities

This derivation is an analysis of the proposed theorem, not a claim that any of the cited papers contains its entire statement. It identifies how much novelty can reasonably attach to the converse.

Choose `s+1` affinely independent means `theta_0,...,theta_s`, with positive prior weights `pi_i`. Let `X` follow their Gaussian mixture, and put `T=m(X)=E(theta|X)`. Set

\[
 V=[\theta_1-\theta_0,\ldots,\theta_s-\theta_0],\qquad
 w_i(x)=\frac{\pi_i\exp(\theta_i\cdot x-\|\theta_i\|^2/2)}
 {\sum_j\pi_j\exp(\theta_j\cdot x-\|\theta_j\|^2/2)}.
\]

Then

\[
 m(x)=\theta_0+V(w_1(x),\ldots,w_s(x))^\mathsf T,
 \qquad
 \det Dm(x)=(\det V)^2\prod_{i=0}^s w_i(x)>0.
 \tag{P.1}
\]

The determinant follows from `Dm=V(diag(w_1,...,w_s)-ww^T)V^T` and the matrix determinant lemma. Strict monotonicity makes `m` injective. Each `log w_i(x)` is bounded in absolute value by `C(1+||x||)`, while the mixture has finite first moment and finite differential entropy. Change of variables therefore gives

\[
 h(T)=h(X)+2\log|\det V|+\sum_i E\log w_i(X)\in\mathbb R.
 \tag{P.2}
\]

This also explains why a finite parameter set still presents a continuous `s`-dimensional compression problem.

Fix any admissible code of error `e`. Let `R` be any input-independent shared seed and let `Y` be the decoded observation. Conditional Holevo/data processing gives

\[
 I(T;Y,R)=I(T;Y\mid R)\le\log D.
 \tag{P.3}
\]

Classical side branches fit in the direct sum. The seed may have any alphabet; conditioning bounds each branch by the same memory dimension. The standard continuous squared-error Shannon lower bound, applied to `T` and the reconstruction `m(Y)`, gives, with `L=E||T-m(Y)||^2`,

\[
 I(T;Y,R)\ge h(T)-\frac{s}{2}\log\frac{2\pi\mathrm e L}{s},
 \quad\Longrightarrow\quad
 L\ge\frac{s}{2\pi\mathrm e}\exp\!\left(\frac{2h(T)}s\right)D^{-2/s}.
 \tag{P.4}
\]

The source and estimate need not be iid repetitions for this information inequality; iid block coding is needed for general achievability statements, not for the inequality itself. Equivalently, (P.4) follows by comparing the joint law to a centered Gaussian conditional reference density of variance `L/s`.

With `B=max_i||theta_i||>0`, the bounded loss `||theta-m(y)||^2/(4B^2)` and the original parameterwise TV bound imply

\[
 L=E\|\theta-m(Y)\|^2-E\|\theta-m(X)\|^2\le4B^2 e.
 \tag{P.5}
\]

The equality is the posterior orthogonality identity for the Markov chain `theta -> X -> memory -> Y`. Combining (P.4)--(P.5), and then taking the infimum over codes, yields

\[
 e_D\ge\frac{s}{8\pi\mathrm e B^2}
       \exp\!\left(\frac{2h(T)}s\right)D^{-2/s}.
 \tag{P.6}
\]

Thus the exponent against arbitrary quantum memory follows from standard information theory once the posterior geometry and bounded-loss conversion are supplied. Section 3A's direct central small-ball/trace proof remains useful: it is elementary, avoids entropy calculations, and gives a geometric constant. It should be described as a direct proof of this scoped converse, not as the discovery of a new quantum rate-distortion dimension principle.

## 4. What remains specific, and what may still be old

For a fixed encoder, a classical memory experiment is a garbling of the original experiment. Optimizing its decoder is exactly reverse deficiency. Without the free seed, the classical problem is therefore a finite-experiment approximation problem in the existing Le Cam/Strasser framework. With a seed, it is the same constrained bottleneck conditional on that external randomization. The new theorem's subject is a rate inside that framework, not a new notion of approximate sufficiency.

The concrete upper is stronger than simply quoting ordinary quantization: the fixed broad reference `g=N(0,4)` sends each bounded-mean target to a periodic `W^{2,1}` density under `u=Phi(x/2)`. Its positive encode/decode hat kernel is a valid Markov kernel and cancels the first moment. `J^s` labels produce uniform TV `O(J^-2)` without cutting off a Gaussian tail. Probability transforms, companding, and positive linear approximation are established ingredients. I did not locate a primary theorem already combining them into the exact present bottleneck statement. This absence supports continued technical use, not a historical priority assertion.

The finite-hypothesis and orbit consequences are useful ways to expose the scope. In particular, a critical known-spectrum unitary orbit can have affine span `d^2-1` despite lower manifold dimension. The posterior observation varies in the full affine space. That consequence is not supplied by a growing-signal parameter-count memory formula alone. Its iid transfer nevertheless remains conditional on the separately inherited Gaussian bridge.

The information-theoretic conclusion is equality of **exponents and dimension order**, not equality of classical and quantum optimal errors or constants. The proofs permit a quantum constant-factor advantage. They also do not give a sharp asymptotic constant, or solve a parameter set whose radius or spanning geometry varies with `D`.

## 5. Scope and cost statements to retain in a release

1. Fix `s`, covariance, `Theta`, and its affine geometry before taking `D -> infinity`. Nearly colliding means can make the lower constant arbitrarily small. A mean set with affine dimension zero has a one-label exact simulator.
2. Specify memory dimension rather than the number of real parameters used to describe a density matrix. All input-dependent classical registers contribute to `sum_j d_j`. The decoder does not revisit `X`.
3. State free independent classical randomness explicitly. Preserved input-dependent side information and entanglement assistance are different resource models.
4. State that reconstruction is the marginal law of a fresh decoded observation. It does not preserve the original observation jointly with an external record, or arbitrary quantum purification.
5. Treat the hat encoder and inverse-normal decoder as measurable stochastic channels. The law alone is not a finite-bit running-time theorem. A deterministic finite-bit output alphabet is atomic and has TV one against the continuous Gaussian; a digital implementation requires a declared output discretization or continuous-output sampling convention.
6. For the iid corollary, retain the bridge remainder. With critical `delta_n=Theta(n^-1/2)`, the claimed matching precision law is justified only in the stated regime `epsilon_n sqrt(n) -> infinity`; the theorem does not settle precision below the comparison error.

Suggested positioning: **“We give matching finite-memory bounds for bounded Gaussian location experiments under uniform total variation reconstruction, including finite affine-spanning hypothesis sets and unrestricted quantum memories with independent shared randomness. The proof combines classical experiment quantization and a posterior-distortion converse with an explicit positive reconstruction kernel.”** Add “new” or “first” only after a deeper search of quantitative deficiency/quantization results, including the inaccessible portions of Torgersen and older high-resolution decision-quantization papers.

## 6. Search completeness record

Search families included finite statistical experiment approximation, quantization and deficiency, Gaussian/normal experiment quantization, majorization and standard likelihood measures, high-rate vector quantization for detection, Le Cam finite approximation, Shannon lower bounds, Holevo information and classical-source quantum rate distortion, and parametric quantum population compression. Primary full texts were inspected where indicated above; publisher records, snippets, and access failures were kept distinct.

This search found close mechanisms and related regimes, but no exact antecedent. The correct prior-art status is **EXACT PRIOR MATCH NOT LOCATED / HISTORICAL NOVELTY UNRESOLVED**. The theorem can be carried forward as an internally proved scoped result without claiming priority.
