# Selective tensor attack after the all-field release

**Status.** The arbitrary-mask integer target remains unresolved. No mask-specialized circuit attaining it was acquired, and no lower bound against general arithmetic circuits is claimed. This note derives (i) a subquadratic spectral bound with its exact tensor-power limitation, (ii) a new obstruction to precompiled shared kernels using coordinate copies, and (iii) an output-incidence test for recursive bilinear schemes. The last two are unconditional within their stated models. The first assumes the release's audited arithmetic bounds.

The source inputs were read only: the TENSOR portion of the attached `Pasted text.txt`, cycle19 `SELECTIVE_OUTPUT_AUDIT.md`, `FIELD_DESCENT.md`, and `REPORT.md`, the October 2 finite separator, the September 24 terminal leaf dimensions and tensor preliminaries, and selected primary prior. No upstream script was executed and no source was modified.

## 1. Interface and the remaining gap

The input is dense integer `X: N x D`, `Y: D x N`, and a supplied arbitrary list `W` of positions. We must return exactly the entries `(XY)_{ij}` for `(i,j) in W`. The intended parameters are

\[
D=N^{1/4},\qquad |W|\le N^{15/8},\qquad T=O(N^{2-\eta}),\quad 0<\eta<1/8.
\]

All input reading, mask acquisition, encodings, arithmetic, coefficient heights, and answer decoding count. Entries of `O(log N)` bits give input size `O(N^{5/4} log N)` and mask/answer size `O(N^{15/8} log N)`, compatible with the target. The full thin product already costs `N^{2+o(1)}` operations; the output list is the missing saving.

The cycle19 legal reverse-differentiation interface reduces the problem to acquiring a value-independent circuit for `Z_W Y^T`, where the entries of sparse `Z_W` are independent formal variables. Nothing here removes that acquisition requirement. In particular, setting `Z=0` during differentiation does not justify discarding structural gates.

## 2. A genuine spectral gain, and the quantifier that blocks the target

Write

\[
G_W=\sum_{(i,j)\in W}a_i b_j c_{ij},\qquad
T_{W,D}=\sum_{(i,j)\in W}\sum_{k=1}^D x_{ik}y_{kj}z_{ij}.
\]

There is an exact coordinate identification

\[
T_{W,D}=G_W\otimes B_Z(D),\qquad
B_Z(D)=z_0\sum_{k=1}^D u_k v_k.
\]

For every tensor character, put `lambda(B_i(t))=t^{p_i}` as in the release. Then `0 <= p_i <= 1`, and

\[
\lambda(G_W)\le \min\{|W|,N^{p_X+p_Y}\}.
\]

The first bound is its explicit `|W|`-term rank decomposition. The second follows by setting unwanted output variables to zero in the complete outer product `B_X(N) tensor B_Y(N)`. Consequently, with `s=p_X+p_Y`, `t=p_Z`,

\[
\log_N\lambda(T_{W,D})
\le \min\{15/8,s\}+t/4.\tag{1}
\]

The all-field square bound supplies `s+t <= 9/4`. Maximizing the right side of (1) under this condition and `s <= 2`, `t <= 1` gives

\[
\lambda(T_{W,D})\le N^{63/32}=N^{2-1/32}.
\]

To see the maximum, if `s <= 15/8`, the objective increases with `s` after substituting `t <= 9/4-s`; if `s >= 15/8`, it decreases with `s`. The maximum is at `s=15/8`, `t=3/8`.

The audited dual estimate improves this. Use only the safe rational bound `alpha_0=93/200=0.465`, rather than a floating certificate. The thin full-product bound implies

\[
s+\alpha_0 t\le2.
\]

Since `1/4 < alpha_0`, the same two-piece maximization puts the optimum at `s=15/8`, `t=(1/8)/alpha_0=25/93`, giving

\[
\boxed{\lambda(T_{W,D})\le
N^{15/8+25/372}=N^{1445/744}=N^{2-43/744}.}\tag{2}
\]

The other two permuted dual constraints and `s+t <= 9/4` do not worsen this upper bound. Exact rational vertex enumeration in `selective_tensor_checks.py` verifies both optimizations. This is an upper bound from a relaxation of the character set; no assertion that a character attains it is needed.

Strassen spectral duality identifies asymptotic rank with the maximum of character values; a primary statement is in [Christandl--Vrana--Zuiddam, section 4.1](https://toc.cs.uchicago.edu/articles/v017a002/v017a002.pdf). Thus (2) really does imply

\[
\widetilde R(T_{W,D})\le N^{1445/744}
\]

for each fixed finite mask and dimension. **The limit is in tensor-power length, with that mask held fixed.** It proves the existence of low-rank schemes for `T_{W,D}^{tensor k}`, whose output mask is the Cartesian power `W^{tensor k}`. It does not prove `R(T_{W,D}) <= N^{1445/744+o(1)}` as the original `N` and an arbitrary mask vary. It also does not acquire a finite kernel, bound its coefficient heights, or provide a uniform procedure to transform arbitrary masks into these product masks.

One honest structured consequence is possible. Fix a graph `G` on `256 x 256` with exactly `32768` edges, take `D_0=4`, and let

\[
N=256^k,\quad D=4^k,\quad W\subseteq G^{\otimes k}.
\]

A sufficiently large **fixed** tensor-power rank witness for `T_{G,4}` can be recursively applied to this family. Its output coordinate set has only `32768^k=N^{15/8}` entries. For an exponent strictly above `1445/744`, the rank dominates both input and output coordinate dimensions, so the fixed linear maps can be evaluated recursively in `O(k r^k)` operations rather than writing `N^2` answers. With one fixed algebraic-number coefficient field, coefficient heights grow only linearly in the recursion depth; exact integer inputs of `O(log N)` bits then incur a polylogarithmic bit overhead. Checking the envelope promise and reading a supplied mask costs `O(|W| polylog N)`.

This explains how output access could be charged for the structured family **after a finite witness has been acquired**. No such witness was acquired here. One can give a terminating algebraic enumeration for fixed accuracy over characteristic zero, but that is an accuracy- and graph-dependent constant search, not a uniform arbitrary-mask acquisition algorithm or a competitive crossover. Reporting (2) as the imported arbitrary-mask integer algorithm would exchange the two limits and omit the load-bearing step.

The older dual bound already exceeded `1/4`, so the qualitative Cartesian-power gain is not unique to the new release. The release improves its bound. Its value for this investigation is exposing an algebraically favorable regime that still fails the requested uniform interface.

## 3. New obstruction: a small library of globally shared masked kernels cannot handle all masks through coordinate copies

This model is broader than independently charged complete-block covers. Its source kernels can compute arbitrary graph masks and may share all their arithmetic internally.

For each `N`, let a precompiled family contain `K_N` source kernels. A kernel computes every output of the graph-masked multiplication tensor

\[
T_{H,D}=\sum_{(u,v)\in H}\sum_{k=1}^D A_{uk}B_{kv}C_{uv},
\]

where `H` has `h` edges and `U,V` nonisolated row and column vertices. The source kernel is evaluated fully. A specialization may depend arbitrarily on `W`, but its inputs are coordinate copies or aliases:

\[
A_{uk}=a_u X_{f(u),k},\qquad
B_{kv}=b_v Y_{k,g(v)},
\]

with each `f(u),g(v)` a target index or zero; arbitrary scalings are allowed. The output decoder may select outputs or take arbitrary linear combinations of them. Acquiring these assignments is permitted without an independent block charge. The source arithmetic circuit itself is precompiled and is not rewritten using the alias dependencies.

Charge a fully evaluated source kernel by at least

\[
C\gtrsim \max\{h,UD,VD\}.\tag{3}
\]

The three quantities are its output size and input flattening ranks. In an arithmetic-circuit model these are lower bounds up to a constant factor via bilinearization. The argument permits an ideal kernel meeting (3); it does not rely on today's full-product exponent.

**Theorem.** If `D=N^{1/4}`, `m=floor(N^{15/8})`,

\[
\log K_N=o(m\log N),
\]

and every source evaluated by the strategy costs `O(N^{2-eta})` for a fixed `eta>0`, then this strategy fails on at least one legal mask of exactly `m` outputs, for all sufficiently large `N`.

**Proof.** Fix one source graph and one coordinate assignment. Its output polynomials are scaled copies of requested-dot-product polynomials at the pairs

\[
E=\{(f(u),g(v)):(u,v)\in H,\ f(u),g(v)\ne0\}.
\]

There are at most `h` such pairs. The target dot-product polynomials for different pairs are linearly independent, so output linear combinations cannot create a pair outside `E`. At most `binom(h,m)` masks of size `m` are therefore obtainable from this assignment. The number of assignments is at most `(N+1)^{U+V}`; the arbitrary scaling coefficients do not alter the envelope `E`.

Put `C_N=c N^{2-eta}` for an upper bound on all source charges, absorbing constants in (3). The number of masks obtainable from the whole library is at most

\[
K_N (N+1)^{O(C_N/D)}\binom{\lfloor C_N\rfloor}{m}.\tag{4}
\]

If `C_N<m`, failure is immediate. Otherwise

\[
\frac{\binom{N^2}{m}}{\binom{\lfloor C_N\rfloor}{m}}
=\prod_{r=0}^{m-1}\frac{N^2-r}{\lfloor C_N\rfloor-r}
\ge\left(\frac{N^2}{C_N}\right)^m.
\]

The logarithm of this ratio is at least

\[
m(\eta\log N-\log c).
\]

In contrast, the logarithm of the prefactor in (4) is

\[
\log K_N+O(N^{7/4-\eta}\log N)=o(m\log N).
\]

Thus (4) is smaller than the number `binom(N^2,m)` of legal masks, proving the claim. ∎

This rules out transferring the structured bound in section 2 through a polynomial-size library of Cartesian masks, coordinate permutations, or duplicated source rows and columns, even if each library kernel itself has sophisticated global arithmetic sharing. It also permits output linear combinations after coordinate-aliased inputs. It is therefore a different obstruction from the cycle19 independently charged rectangle theorem.

The escape routes are precise: a family with mask-sized description entropy, a mask-dependent rewrite of the arithmetic circuit, or genuinely mixed linear input maps. A huge conceptual family is not itself an acquisition lower bound: a uniform algorithm could conceivably generate its appropriate member in `O(m polylog N)` time. That algorithm is exactly what remains absent. The theorem is not a lower bound against arbitrary circuits or against the output-local Alman--Vassilevska Williams construction, whose encodings mix input variables.

## 4. New diagnostic: the output-leg incidence profile determines whether recursive leaf pruning can save an exponent

Suppose an explicitly acquired bilinear kernel for `q x d` by `d x q` multiplication is

\[
T=\sum_{\ell=1}^r u_\ell(X)v_\ell(Y)w_\ell(Z).
\]

Remove zero terms first and let `s_ell` be the number of nonzero output coordinates in `w_ell`. In its `k`th tensor power a scalar product leaf indexed by `ell_1,...,ell_k` contributes to exactly

\[
S_{\boldsymbol\ell}=\prod_{a=1}^k s_{\ell_a}
\]

output coordinates. Consider the precise specialization strategy that retains a product leaf exactly when its output support meets `W`. All encoding sharing is allowed, but no new algebraic decomposition or dependency rewrite is performed.

Choose `W` uniformly among masks of exactly `m` positions in the `N x N` output grid, `N=q^k`, and put `rho=m/N^2`. A support of size `S` is hit with probability

\[
1-\frac{\binom{N^2-S}{m}}{\binom{N^2}{m}}
\ge1-e^{-\rho S}
\ge(1-e^{-1})\min\{\rho S,1\}.
\]

Therefore some legal mask forces at least

\[
(1-e^{-1})\sum_{\boldsymbol\ell}
\min\{\rho S_{\boldsymbol\ell},1\}\tag{5}
\]

product evaluations. This lower bound does not charge an input encoding independently for every block.

For `rho=N^{-sigma+o(1)}`, fixed `q,r,s_ell`, a type-class count gives the exponent of the sum in (5):

\[
\boxed{\Psi(\sigma)=
\max_\gamma\left[
\frac{H(\gamma)}{\log q}
+\min\left\{0,\frac{\sum_\ell\gamma_\ell\log s_\ell}{\log q}-\sigma\right\}
\right].}\tag{6}
\]

Here `gamma` ranges over probability laws on the `r` leaves. There are only polynomially many types; their multiplicities are `exp(k H(gamma)+O(log k))`, which proves (6). Equivalently, the entropy variational identity and concave minimax give

\[
\Psi(\sigma)=\min_{0\le a\le1}
\left[\log_q\left(\sum_{\ell=1}^r s_\ell^a\right)-a\sigma\right].
\]

For the target, `sigma=1/8`. A necessary condition for this pruning strategy to have any fixed subquadratic saving is `Psi(1/8)<2`. This condition does not address acquisition, integer heights, or encoding work, so it is only an early rejection gate.

Two immediately usable rejection tests follow.

1. Since every `s_ell >= 1`, even the weakest bound in (5) forces exponent `log_q r - 1/8`. Thus a kernel with `r >= q^{17/8}` fails through output pruning alone. This refers to the kernel **after** all promised inner-dimension zeros have been applied.
2. If the geometric mean output support satisfies
   `prod(s_ell)^{1/r} >= q^{1/8}`, insert the uniform law into (6) to get `Psi(1/8)=log_q r`. Since `r >= q^2` by the output flattening, the strategy fails to give a fixed saving. If the inequality is strict, almost all leaves have support at least `N^{1/8+delta}`. A union bound shows that a random legal mask hits all these leaves with probability tending to one, yielding `Omega(r^k)` retained products.

An actual aspect-ratio fixture is the `16 x 2` by `2 x 16` kernel obtained from `64` Strassen `2 x 2` products. It has `r=448`: `320` leaves have output support two and `128` have support one. Its geometric-mean exponent is

\[
\frac{320}{448}\log_{16}2=5/28>1/8.
\]

At depth `k`, `N=16^k`, `D=2^k=N^{1/4}`. Almost all `448^k=N^{log_{16}448}` leaves survive legal worst-case masks. Input-form reuse across the 64 blocks does not remove this product count. Exact finite evaluations of (5)'s incidence proxy are saved in `selective_tensor_checks.json`. The fixture illustrates the test; it is not an optimized contemporary kernel.

The new release supplies exponents and finite degenerations, but the kernel's actual output maps after coefficient extraction, field descent, and recursive composition are needed to compute the `s_ell` profile. Bare rank, terminal matrix volume, or a Fourier map before coefficient extraction does not determine that profile. A literal Fourier step can have dense support while its coefficient maps split that support at the price of extra rank terms. Either accounting must include the final exact maps.

## 5. What the new shared-leg separator actually does to the target tensor

Group `T_{W,D}` by the middle coordinate `k`. The output leg `Z_W` is shared; the `X_k` and `Y_k` legs are disjoint and have the same label. Applying the finite separator with `M=D` yields

\[
T_{W,D}^{\oplus O(D\,\mathrm{polylog}\,D)}
\rightsquigarrow
\bigoplus_{k=1}^D (G_W\otimes B_Z(D))
=T_{W,D}^{\oplus D}.
\]

The source multiplication is still the unknown masked tensor. The separator has not replaced it by an efficiently evaluable primitive. Keeping all separated sectors creates `|W|D=N^{17/8}` independent output coordinates; keeping just one sector discards the multiplicity responsible for the entropy argument. Neither operation supplies the missing one-shot circuit.

Grouping by rows gives a shared `Y` leg with independent row payloads and an auxiliary dot factor of length `N`; grouping by columns is symmetric. The finite separator again extracts larger complete payloads from copies of the unresolved original source. It cannot be inverted into an upper bound. Grouping directly by edges does not satisfy its two-disjoint-matched-leg hypothesis because different edge payloads share row or column inputs.

This is a precise source-interface check, not a claim that every possible composition with the separator fails. A useful composition must first provide a cheap source tensor and explicit mixed encodings, then pass the output-incidence and total-cost tests above.

## 6. Result and next gate

The target is still open in this run. The strongest positive calculation is the conditional fixed-mask asymptotic-rank bound (2); its load-bearing missing lemma is a uniform, cheaply acquired circuit for the varying masks. The new obstruction says a small precompiled library with coordinate copies, even with global sharing inside each kernel, cannot supply that lemma. The recursive profile test says how to reject a supplied exact kernel without conflating rank and selective access.

The next useful object is an explicit value-independent mask-specialized circuit or a mixed encoding for a cheap source tensor. Before exponent optimization, acquire its final exact output-leg maps and evaluate `Psi(1/8)`. If this is below two, charge the input transforms, extension acquisition, coefficient heights, and output decoding. No new end-to-end 3SUM/APSP exponent follows from the present deductions.

Evidence: `selective_tensor_checks.py` independently uses exact rational arithmetic to check the two spectral polytope bounds, an explicit large finite counting inequality, and five actual blocked-Strassen incidence profiles. All passed. These checks do not acquire a rank kernel for (2), execute the arbitrary-mask algorithm, or establish external novelty.
