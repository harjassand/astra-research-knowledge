# Complementary TCS and combinatorics sweep

7 October 2026. Worker `frontier_tcs`. Sources were read only. Release pinned to
`adc7f1241b42e322a6451854ab7e4b4c146bf78a`. This pass inspected the overview and
current assessment entries for all **40 TCS and 37 combinatorics families**.
`frontier_tcs_read_depths.json` records each family, the current workers' reported
depths, and this worker's much narrower actual primary reading. It does not
inherit another worker's full-proof status. No release headline is newly
certified by this sweep.

The strongest completed result is a **sampler/proof-method obstruction** for
the low-degree branch: polynomial-alphabet iid latent sampling cannot satisfy
bounded growing-degree advantage in the random alternating-form graph model,
and simply enlarging the iid alphabet breaks the current full Reed–Muller
clean-column rank certificate. A second exact example shows that selecting
points with no short evaluation dependencies is not ordinary matroid
independence. These are incremental scope results, with written proofs and
exact finite checks, rather than a uniformly samplable counterexample to the
polynomial-time low-degree conjecture. Historical novelty is unknown.

## What changed and what remains missing

| Families | Complementary opportunity | Actual boundary in the current assessment |
|---|---|---|
| 103 | Uniform deterministic logspace compiler | Catalogue claim only; no compiler/proof acquisition in the prior allocation. High consequence if checked, but not a high-girth sampler or an arbitrary algebraic identity detector. |
| 108, 112, 126, 133, 135 | Algebraic/circuit/representation lower bounds | Restricted models: border determinantal complexity, depth three/five, exact SDP lifts, or specified sequential WL models. No arbitrary algorithm or acquired representation lower bound follows. |
| 113–115 | Count and sample constrained nuisance/design laws without assuming them supplied | Exact rank/oracle and original bit costs matter. Family114 technical proof is only partially independently reconstructed; exact-uniform table sampling is a separate claim. Hard feature bounds and high-girth generation are not outputs. |
| 119, 127, 132, 186, 192 | Fourier/information/influence mechanisms | Symmetry, Booleanity, noise model, and target metric are load-bearing. These results do not certify low-degree hardness or furnish a latent sampler. |
| 131 | Degree-conditioned graph null models | A major unexamined complementary primitive: polynomial switch mixing for every degree sequence. Current assessment is catalogue-only; full chain/encoding/coupling must be read before adoption. |
| 136 | Robust local numerical verification | PCP-for-PPAD does not acquire an endpoint or turn robust verification into an affordable proposer. Not read deeply in cycle19. |
| 137, 139, 140, 141 | Resource/precision-sensitive acquisition | Respect one-tape/unrestricted-time, exact-oracle/unrestricted-computation, one-pass-memory, and counting-hierarchy interfaces. No affordable local research engine follows merely from these headlines. |
| 142 | Deterministic prime-field algebraic acquisition | Prior deep read retains family029 analytic dependence and unimplemented full bit algorithm. This is not general rational commutative PIT. |
| 159–160, 164, 175–176 | Additive/cover/threshold selection | Some useful common-witness mechanisms are reconstructed. Cover acquisition, precision-loss control, and the sunflower-specific global certificate remain absent. |
| 174 | Strong thin trees and rank-one signing | The cost-and-cut outer proof is readable and constructive conditional on the core algorithm, but gives cost factor24B rather than a favorable exact-mean response. Prior cycle19 already derives dominated marginals and the cube signing law. |
| 177–178 | Explicit bounded-degree expansion/spectral objects | Potentially valuable constructions; the current assessments have not checked full degree/cohomology/size/cleanup proofs. These do not automatically supply the missing PCP encoding. |
| 184 | Weighted independence/decorrelation | A prior internal stationary-point obstruction is already present. The proof uses global maximality, and no efficient global-comparison service is claimed. |
| Other combinatorics families | Geometric, Ramsey, tiling, positivity, and decomposition capital | Most remain overview/abstract depth. No named A–F missing lemma is removed by their literal statements. |

There is **no sunflower or Komlós resolution family** in the catalogue, and no
family directly supplies the missing uniformly samplable high-girth latent
cloud. This is a catalogue/interface observation, not a proof that no new
mechanism somewhere in a manuscript can help. Parent teams own PIT, repetition,
and selective tensor follow-up; this pass avoids duplicating those attacks.

## 1. General iid collision obstruction

Let `pi_n` be any probability law on a finite subset of `F_2^{K_n}`. Sample
`v_1,...,v_n` iid from it. Independently sample a uniform alternating bilinear
form `B` on `F_2^{K_n}`, and set

`X_ij = B(v_i,v_j)`, for `i<j`.

The resulting graph law is vertex-relabeling invariant without an additional
permutation. Resample each observed edge independently at a fixed rate
`0 <= epsilon < 1`, replacing it by a fresh fair bit. Write the noisy graph law
as `P_n^epsilon`, and let `Q_n=G(n,1/2)`. Define the feature collision mass

`gamma_n = sum_v pi_n(v)^2`.

**Proposition.** For every fixed integer `s>=3` with `s+2<=n`,

`Adv_{<=2s}(P_n^epsilon,Q_n)`

`>= (1-epsilon)^(2s) gamma_n sqrt[binom(n,2) binom(n-2,s)].`      (1)

This requires no degree bound, efficient representation, bias estimate,
linear independence, or Reed–Muller assumption on the feature vectors.

**Proof.** For disjoint vertex sets `U,S` with `|U|=2`, `|S|=s`, let

`chi_US(X) = (-1)^(sum_{i in U,j in S} X_ij)`.

By bilinearity this is

`(-1)^B(sum_U v_i, sum_S v_j)`.

Average over the independent uniform `B`. A linear character on its finite
vector space averages to either zero or one; it is one when the corresponding
alternating tensor vanishes. In particular it is one whenever the two vectors
in `U` coincide. Thus `E_P chi_US >= gamma_n`. Independent fair resampling
multiplies the mean by exactly `(1-epsilon)^(2s)`.

For `s>2`, the bipartition of `K_(2,s)` is determined by the edge set because
its two sides have unequal degrees. Consequently every unordered `U,S` above
gives a different character. There are

`M=binom(n,2) binom(n-2,s)`

of them. Under `Q_n` these nonempty edge characters have mean zero and are
orthonormal. Hence `F_s=sum chi_US` has null variance `M`, real multilinear
degree `2s`, and planted mean at least
`M(1-epsilon)^(2s)gamma_n`. Standardizing by `sqrt(M)` proves (1). ∎

**Corollary.** If the iid latent alphabet has size `q_n<=C n^b`, then
`gamma_n>=1/q_n` by Cauchy–Schwarz. For every fixed

`s > max{2, 2b-2}`,

the right side of (1) grows as at least a positive constant times
`n^((s+2)/2-b)`. Thus even one fixed-degree statistic has divergent advantage.
Arbitrary feature maps or random shared feature maps independent of `B` do not
repair this: condition on the map, and feature collisions can only be more
frequent than latent collisions.

More generally, if `D_n -> infinity` and
`Adv_{<=D_n}(P_n^epsilon,Q_n)=O(1)`, then for **every** fixed `A>0`,

`n^A gamma_n -> 0`.

Choose a fixed `s` with `(s+2)/2>A` and eventually `2s<=D_n` in (1).
Therefore the order-two collision entropy obeys

`H_2(pi_n)/log_2 n -> infinity`.

For iid latents encoded by `m_n` binary bits, `gamma_n>=2^(-m_n)`, so necessarily
`m_n/log_2 n -> infinity`.

**Relation to A–F.** The supplied state already has a general biclique
amplification lemma for fixed-size zero relations and a without-replacement
Reed–Muller-flat obstruction. The proposition applies that mechanism at
relation size **two** and removes every algebraic feature assumption. Its
incremental value is an explicit entropy admission test for *all* iid
polynomial-alphabet repairs, including ones using better coefficient circuits,
different bases, or new exact finite sampling services. It does not address
correlated sampling without replacement or a certified high-girth cloud.

**What it does not prove.** Divergent normalized mean or low-degree norm does
not by itself establish strong two-sided detection. For example,
`R_n=(1-eta_n)Q_n+eta_n delta_empty`, with `eta_n=n^(-b)`, has TV distance at
most `eta_n` from `Q_n`, including after resampling. Nevertheless the same
statistic has normalized mean
`eta_n(1-epsilon)^(2s)sqrt(M)`, which diverges when `s>2b-2`. No strong test
can distinguish this pair because its TV distance vanishes. This elementary
control prevents promoting (1) to a new efficient strong detector.

## 2. Why iid support enlargement breaks the existing rank certificate

The relevant external baseline is [Mao's construction](https://arxiv.org/html/2607.20318),
especially Proposition2.6 and Sections3.1–3.4. Its selected fixed evaluation
points supply short-relation avoidance; its sampler is nonuniform, and the
uniform-sampling question remains explicit in that paper.

For the present proof-method boundary, retain the full Reed–Muller feature
map of fixed degree `r>=1` on `m_n` binary variables, and the current
clean-column monomial rank test. Let `T_n` be the number of anchor vertices,
`s_n` the monomial lift degree, and keep a fixed noise rate
`0<epsilon<1`. A clean nonanchor column retains all its `T_n` anchor edges.
The proof compares its count to

`mu_n=(n-T_n)(1-epsilon)^(T_n)`

and bounds the rank of clean columns by

`R_latent=binom(m_n, <=r s_n)`.

The null full-column-rank argument also needs

`R_anchor=binom(T_n, <=s_n) >= n-T_n`.

Suppose an iid repair is required to have bounded advantage through some
`D_n -> infinity`. Section1 forces `m_n/log n -> infinity`. If the
clean-column certificate has `mu_n -> infinity`, then
`T_n=O(log n)` and `n-T_n ~ n`.
The necessary null row-count condition forces `s_n=Omega(log n)`: otherwise,
for `s_n=o(log n)` and `T_n=O(log n)`,

`log binom(T_n, <=s_n) <= O(s_n log(e T_n/s_n)) = o(log n)`,

so the number of lift rows is `n^o(1)<n-T_n`.

Choose a fixed `c>0` with `t_n=floor(c log_2 n)<=r s_n` eventually. Since
`m_n/log n -> infinity`, eventually `t_n<=m_n` and

`R_latent >= binom(m_n,t_n) >= (m_n/t_n)^(t_n)=n^omega(1)`.

This exceeds the total number of nonanchor columns. Hence the current bound
`rank(clean)<=R_latent` becomes vacuous and cannot certify any rank deficit.

This is a **boundary of that proof certificate**. It does not show actual
clean rank is large, does not exclude a smaller subspace tailored to the latent
support, and does not rule out another detector or a correlated latent sampler.
The two requirements expose the exact repair obligation: acquire a law avoiding
short relations while retaining a genuinely small product-closure space.
Neither polynomial finite-field factorization nor faster matrix multiplication
supplies this geometric/code property by its stated interface.

## 3. Short-circuit avoidance is not ordinary matroid independence

Family114's October introduction literally assumes two normalized monotone
submodular rank functions, supplied by exact rank-value oracles, and counts
their common integer bases. An evaluation matrix's column matroid is available,
but the requirement “every small subcollection is independent” is not the same
as independence of the whole selected set. The following small example makes
the failed shortcut explicit.

Take `x in F_2^6` and the degree-one full evaluation map `phi(x)=(1,x)`.
Call a set of distinct points admissible when its evaluations have no nonzero
linear dependence supported on at most four points. The constant coordinate
rules out odd relations; size-two relations are ruled out by distinctness.
Thus admissibility is exactly absence of four distinct points with XOR zero.

Let `e_1,...,e_6` be the coordinate vectors and `w=e_1+...+e_6`. Put

`A={0,e_1,...,e_6,w}`.

The pair sums of `A` have respectively weights1,2,5,6, and are distinct within
each class, so `A` is admissible and `|A|=8`. It is maximal: every point outside
`A` has weight2,3,4,or5 and is the XOR of three distinct points of `A`:

* weight2: `0+e_i+e_j`;
* weight3: `e_i+e_j+e_k`;
* weight4: `w+e_i+e_j` for its two missing coordinates;
* weight5: `w+0+e_i` for its missing coordinate.

Now put

`B={0,e_1,...,e_6, e_1+e_2+e_3+e_4, e_1+e_2+e_5+e_6}`.

It has nine points. The two extra vectors have weight4, their XOR has weight4,
and they differ in four positions. Their pair sums with the coordinate vectors
have weights3 or5 and cannot coincide across the two extra vectors, because
such a collision would say their XOR has weight2. Their pair sums with zero
and each other are three different weight4 vectors. These also cannot equal a
basis pair sum of weight1 or2. Hence `B` is admissible.

The admissible-subset system is hereditary but fails augmentation: `|A|<|B|`,
while no `x in B\A` can be added to `A`. It is therefore **not a matroid**.
This does not exclude a more elaborate reduction to two matroids, whose complete
feasibility/counting/multiplicity/oracle costs would need a separate proof.
It refutes only the direct substitution of short-circuit avoidance for the
ordinary independence oracle in family114. The example uses degree one, so
the mistake precedes the harder Reed–Muller/high-girth parameters.

## 4. Cover equivalence does not remove the sunflower logarithm by itself

The primary [Park–Pham threshold statement](https://arxiv.org/abs/2203.17207)
already gives `p_c(F)=O(q(F) log ell(F))`. A constant comparison between integral
and fractional expectation thresholds, as claimed by family175, does not
delete this general logarithm. Perfect matching gives an elementary control.

Let `F` be the increasing property of containing a perfect matching in the
complete graph on an even number `n=2r` of vertices. For a uniform perfect
matching `M`, a compatible matching `S` of `k` edges satisfies

`Pr(S subset M) = 1/[(n-1)(n-3)...(n-2k+1)] <= (6/n)^k`.

Indeed the geometric mean of the first `k` decreasing odd factors is at least
that of all `r` factors. The full product is at least `r! >= (r/e)^r`, and
`e<3`. Nonmatching sets have probability zero. Any integral cover of all
perfect matchings must have expected coverage at least one under `M`.
At `p=6/n` its p-cost is at least that expectation, so the expectation threshold
obeys `q(F)<=6/n`.

At `p=alpha log n/n` for any fixed `0<alpha<1`, the number `Z` of isolated
vertices has mean `n(1-p)^(n-1)=n^(1-alpha+o(1))`. For two distinct vertices,
their joint isolation probability is `(1-p)^(2n-3)`, whose ratio to the product
of the two isolation probabilities is `1/(1-p)`. Therefore

`Var Z/(E Z)^2 <= 1/E Z + p/(1-p) -> 0`.

An isolated vertex rules out a perfect matching, so `p_c(F)` is at least
`alpha log n/n` eventually, and `p_c(F)/q(F)=Omega(log n)`.

This control is classical and receives no novelty claim. It establishes that
constant q/q_f equivalence alone cannot yield a general constant-factor
threshold theorem. A sunflower application must use additional special
structure. The [ALWZ primary abstract](https://arxiv.org/abs/1908.08483) records
the robust sunflower improvement and its near-sharpness; [Bell–Chueluecha–Warnke](https://arxiv.org/abs/2009.09327)
records the `(O(p log k))^k` ordinary bound. No log-free sunflower certificate
or product-quotient control was acquired in this pass.

## Verification, prior art, and scientific conclusion

`python3 work/frontier_tcs_checks.py` completed successfully. The resulting
`frontier_tcs_checks.json` records **12,358 exact assertion groups** across ten
rational iid feature laws, direct averaging over all small alternating forms,
the collision lower bound, distinct biclique characters, null mean/variance,
exact resampling attenuation, both point sets, and all 56 excluded-point
short-relation witnesses. These checks validate finite identities and the
explicit exchange example. The asymptotic statements rest on the written
proofs; no release FPRAS, thin-tree implementation, or Lean/kernel was run.

The most relevant direct prior is the supplied A–F biclique amplification
mechanism plus [Mao](https://arxiv.org/html/2607.20318). [Buhai–Hsieh–Jain–Kothari](https://arxiv.org/abs/2505.17360)
provides the earlier noise-tolerant quasipolynomial counterexample context;
[Kunisky–Wein–Bandeira](https://arxiv.org/abs/1907.11636) gives the likelihood-ratio
framework. This bounded primary-source check did not establish novelty for
the all-iid entropy condition, the certificate incompatibility, or the cap
exchange example. They should be treated as independently written elementary
deductions, possibly already known, rather than advertised breakthroughs.

The existing cycle19 two-budget design obstruction was re-read as a negative
control and is not a new result here. Its exact mean, hard feature, positive
rank-one, and minimal budget-repair statements already go beyond any implication
available from perfect counting or sampling. New counting theorems change
acquisition only for their legal feasible family; they do not change that
family's long-edge geometry. Likewise, family186's Boolean influence theorem
cannot be promoted to a real-valued spectral inequality for the polynomial
statistic in (1), nor does it produce a high-girth point law.

The highest useful complementary target remains a **uniformly acquired,
correlated high-girth latent cloud with small product closure**. Its successful
construction would answer the explicit uniform-sampling question while
preserving the noise-tolerant rank detector. The present run narrows the search:
the simple iid polynomial-alphabet repair, the simple support-enlargement
repair using the current full-RM rank bound, and the simple ordinary-matroid
counting shortcut all fail. None of the newly inspected literal source
interfaces removes the remaining joint girth/closure acquisition bottleneck.
