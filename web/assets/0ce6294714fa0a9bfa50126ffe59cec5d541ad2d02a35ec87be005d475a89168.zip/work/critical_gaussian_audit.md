# Independent critical Gaussian memory audit

Date: 2026-10-07. Source workspaces were read only. No subagents were spawned. Coordinated directly with quantum_collision and checked its completed Section 3A in full.

## Verdict

**Scoped internal PASS.** The sharp Gaussian experiment bound, the arbitrary-quantum converse with free shared classical seeds, the periodic-hat upper bound without a tail logarithm, and the finite-parameter/affine-span strengthening survive reconstruction. I found no counterexample or remaining load-bearing gap. This is a written mathematical audit, not formal kernel verification or historical novelty clearance.

The Gaussian theorem is independent of the inherited quantum Gaussian bridge. Its iid quantum and critical known-spectrum consequences remain conditional on that bridge. The additive bridge remainder must remain explicit.

## Exact theorem checked

Let Theta be a fixed bounded subset of a finite-dimensional Euclidean space and let s >= 1 be the dimension of its affine span. Consider the classical experiment P_theta = N(theta,I). An encoder receives its supplied observation X and maps it to a memory algebra direct_sum_j M_(d_j); a decoder maps that memory to an output observation Y. All retained information depending on X passes through the memory. Charge total memory dimension

    D = sum_j d_j.

An arbitrary input-independent shared classical seed R, known to encoder and decoder, is allowed for free. Conditioned on R the memory dimension is at most D. Fresh decoder randomization is allowed. No uncharged input-dependent side register, entangled reference, feedback protocol or second communication channel is included.

Define e_D as the infimum of sup_theta TV(law(Y|theta),P_theta) over these channels. There exist constants 0 < c_Theta <= C_Theta < infinity such that for every integer D >= 1,

    c_Theta D^(-2/s) <= e_D <= C_Theta D^(-2/s).

The upper uses only classical memory. The lower applies to arbitrary quantum or hybrid memory, including every distribution of the allowed free seed. The constants depend on the bounded mean set and its actual affine geometry. They need not be uniform when that geometry collapses in an informative direction.

If the affine span has dimension s smaller than the observation ambient dimension, first project onto its known affine span. The orthogonal complement is independent Gaussian noise with a known mean and can be regenerated at the decoder. Thus s is affine dimension, rather than necessarily observation ambient dimension. A singleton has s = 0 and can be reproduced with D = 1 exactly; it is outside the positive-dimensional statement.

Known positive-definite covariance is covered by whitening. No interior or continuum hypothesis on Theta is needed. A finite set containing s+1 affinely independent means is already sufficient.

## 1. The posterior-risk coupling is exact

Choose s+1 affinely independent means theta_0,...,theta_s from Theta and put positive prior weights pi_i on them. Use this finite prior only for the converse. Let B > 0 bound their Euclidean norms, draw the random parameter T from the prior, then draw X|T ~ N(T,I).

The encoder and decoder define the actual joint experiment

    T -> X -> (R, memory) -> Y.

R is independent of T,X. Therefore

    E[T | X,R,Y] = E[T|X] = m(X).

Here m is the posterior mean for the **original Gaussian experiment**. In particular m(Y) means evaluating that same fixed function at the decoded observation. It is not a claim that m(Y) equals the posterior mean for the generally altered experiment Y.

Expand the square under this actual encoder coupling:

    E||T-m(Y)||^2 - E||T-m(X)||^2
      = E||m(Y)-m(X)||^2.

The cross term vanishes after conditioning on X,R,Y. This identity does not assume any initially chosen coupling of nearby distributions or an optimal Bayes estimator for the decoded experiment. It converts preservation of the source distributions into preservation of a continuously varying statistic under the true channel coupling.

All m(x) lie in the convex hull of the finite prior support, so ||m(x)|| <= B. Consequently

    ell(t,y) = ||t-m(y)||^2/(4B^2)

is a measurable loss in [0,1]. If the reconstruction error is e at the finitely many chosen means, then averaging the rowwise TV inequalities over the prior gives

    0 <= E||m(Y)-m(X)||^2 <= 4B^2 e.                 (L1)

Using TV = half the L1 distance, the bound for a [0,1] loss is e rather than 2e. The lower inequality also follows from the exact square identity. There is no data-processing sign error and no free-randomness conditioning error.

## 2. A finite prior still supplies a full-dimensional statistic

Define

    Z(x) = sum_i pi_i exp(theta_i dot x - ||theta_i||^2/2),
    m(x) = grad log Z(x).

All posterior weights are positive at every finite x, and differentiation gives

    Dm(x) = Cov(T|X=x).

For any nonzero vector z, a zero conditional variance of z dot T would mean z dot theta_i is constant for all i. Affine independence forbids this. Thus Dm(x) is positive definite everywhere.

This also proves global injectivity without a selector: integrate the Hessian along the line segment between x and x' to obtain

    (m(x)-m(x')) dot (x-x') > 0   whenever x != x'.

Fix any cube C = [-L,L]^s with L > 0. Its original prior-predictive mass M = Pr(X in C) is positive. By continuity and compactness there is v > 0 with Dm(x) >= vI on C. Its Jacobian determinant is at least v^s. The inverse function theorem and global injectivity therefore permit an ordinary change of variables on its interior. For every output target z and every h > 0,

    Vol{x in C : ||m(x)-z|| <= h}
      <= v^(-s) Vol(B_s) h^s.                      (L2)

The cube boundary is null. No assumption is made that m(C) is convex or that z belongs to m(C). When the preimage is empty the inequality is immediate.

An explicit compactness-free constant can also be supplied. On C, if ||theta_i|| <= B, all posterior weights obey

    Pr(T=theta_i|x) >= eta pi_i,
    eta = exp(-2B sqrt(s)L - B^2/2).

Indeed the numerator exponential is at least exp(-B sqrt(s)L-B^2/2) and every term in the denominator is at most exp(B sqrt(s)L). Hence

    Cov(T|x) >= eta Cov_prior(T)

by the variational expression Var(Z)=min_a E(Z-a)^2. The positive prior covariance supplies a direct admissible v. This confirms that the finite-prior Hessian lower bound is a quantitative assumption depending only on the selected affine configuration.

## 3. Quantum dimension, hybrid branches, and arbitrary shared seeds

Let p(x) be the prior-predictive mixture density; p(x) <= p_max <= (2pi)^(-s/2). Condition on any seed value r. The encoder state at x is omega_(r,x), a positive trace-one element of the direct-sum memory. As an operator on the charged direct-sum Hilbert space it satisfies

    omega_(r,x) <= I.

The decoder is a POVM F_r(dy) with F_r(R^s)=I and total block trace D_r <= D. Tonelli for the nonnegative trace measure, the operator inequality, and (L2) give

    Pr(X in C, ||m(Y)-m(X)|| <= h | R=r)
      = integral_C p(x) Tr[omega_(r,x)
          F_r{y:||m(y)-m(x)||<=h}] dx
      <= p_max integral Tr[F_r(dy)]
          Vol{x in C:||m(x)-m(y)||<=h}
      <= C_* D h^s,
    C_* = p_max Vol(B_s)/v^s.                       (L3)

This is a dimension **D** bound, not a parameter-count or rank D^2 argument. It needs neither pure encoder states nor a discrete decoder outcome space. The density/POVM kernels can be arbitrary measurable channels.

Because the seed is independent, p(x) and M are unchanged after conditioning. Average (L3) over an arbitrary seed distribution. There is no finite-seed assumption and no assertion that an average of rank-limited matrices remains rank limited.

Set h = [M/(2C_*D)]^(1/s). At least M/2 of the probability lies in C with posterior displacement exceeding h, so

    E||m(Y)-m(X)||^2
      >= (M/2)[M/(2C_*D)]^(2/s).

Combine this with (L1) to obtain the explicit converse

    e >= [M/(8B^2)] [M/(2C_*)]^(2/s) D^(-2/s).       (L4)

The central cube is imposed on X alone; no lower bound on central mass of Y is needed. The argument works even if the decoder deliberately outputs huge values or if m(Y) lies outside m(C).

The side-resource boundary is substantive. A free entangled receiver reference would increase the Hilbert space on which the decoder POVM acts, so its trace would not equal the charged D. For example dense coding can transmit D^2 classical labels using a D-dimensional message together with a free entangled D-dimensional reference; the classical upper construction would then have a different dimension law. The present result explicitly excludes that resource. Free input-independent **classical** randomness creates no such increase after conditioning.

## 4. Finite Gaussian hypotheses do not admit exact finite-memory Petz recovery

The converse already rules out e = 0 for every finite D whenever the means affinely span a positive-dimensional space. A direct test is the binary one-dimensional family with means +/-a, a > 0, under an equal prior:

    m(x) = a tanh(ax),
    m'(x) = a^2 sech^2(ax) > 0.

Exact recovery of both Gaussian laws would, by (L1), require m(Y)=m(X) almost surely in the actual channel experiment. Injectivity then requires Y=X almost surely under a strictly positive continuous mixture density. But (L3) makes the probability of arbitrarily precise recovery in a positive-mass central interval tend to zero as h decreases for any finite D. This is impossible.

A recovery channel for finite-dimensional quantum state families cannot be invoked without first constructing an encoder sufficient for these supplied continuous distributions. Exact sufficiency is the property at issue; Petz recovery does not promise it after an arbitrary finite-dimensional bottleneck. The finite number of source hypotheses is not a finite number of values of the posterior statistic. The same argument applies to s+1 finite Gaussian hypotheses, a sphere, or any other bounded full-affine-span mean set.

## 5. Broad-reference compactification and boundary regularity

Translate the parameter set into a cube [-A,A]^s. For one coordinate, let f_theta be the N(theta,1) density and choose the fixed broader density

    g(x) = (2 sqrt(2pi))^(-1) exp(-x^2/8),
    u = G(x) = Phi(x/2),
    q_theta(G(x)) = f_theta(x)/g(x).

q_theta is the transformed probability density on (0,1), not a stored parameter or a density requiring knowledge of the unknown mean. Its coordinate transformation is fixed.

Put P_theta(x) = (3/8)x^2 - (5/4)theta x + theta^2 - 3/4. Direct differentiation using d/du = g^(-1)d/dx gives

    q_theta''(G(x)) = P_theta(x) f_theta(x)/g(x)^3,
    ||q_theta''||_1 = integral |P_theta(x)| f_theta(x)/g(x)^2 dx.

The exact useful ratio is

    f_theta/g^2 = 4 sqrt(2pi)
      exp[-(x-2theta)^2/4 + theta^2/2].

With z=x-2theta, the polynomial becomes 3z^2/8+theta z/4-3/4. A N(0,2) variable has E z^2=2 and E|z|=2/sqrt(pi). Thus the explicit uniform bound stated in quantum_collision checks:

    ||q_theta''||_1 <= M_A,
    M_A = 8 sqrt(2) pi exp(A^2/2)
          [3/2 + A/(2 sqrt(pi))].                    (U1)

q_theta itself has exponential factor -3x^2/8+theta x. Its u derivative has factor -x^2/4+theta x times a linear polynomial. Both therefore tend to 0 at both endpoints, uniformly over bounded theta. Combined with (U1), this makes the periodic extension belong to W^(2,1) on the circle. No unmatched boundary derivative or atom is created by the wrap. The variance-four reference is what keeps this second derivative integrable; a reference with the target variance would not have this property.

## 6. The positive periodic-hat kernel is genuinely second order

Take J >= 5, h=1/J, and the circle vertices kh, k=0,...,J-1. Let

    a_k(u) = [1 - dist_circle(u,kh)/h]_+.

The hats sum to 1 and each integrates to h. Encoding k with probability a_k(u), followed by decoder density a_k(v)/h, is a legal classical channel through exactly J symbols. Its kernel is

    K_h(u,v) = h^(-1) sum_k a_k(u)a_k(v).

It is nonnegative, symmetric, and Markov in either variable, satisfies K_h <= 1/h, and is supported at circle distance at most 2h. The support admits a unique signed unwrapped displacement t=u-v because 2h < 1/2.

The first displacement moment at fixed v is exactly zero. If v is between two adjacent lifted vertices kh and (k+1)h, its two nonzero outer weights interpolate those vertices to v. The inner tent around each vertex has that lifted vertex as its mean. Thus the mixture has mean v. This remains true across the seam using the same periodic extension; it does not require treating u in [0,1) as a globally ordered coordinate.

For a periodic q in W^(2,1), Taylor's formula with integral remainder gives

    q(v+t)-q(v)-tq'(v)
      = t^2 integral_0^1 (1-r) q''(v+rt) dr.

Kernel mass and first moment cancel its first two terms. Bound the remaining kernel by 1/h, integrate over |t|<=2h, and use translation invariance of Lebesgue measure on the circle:

    ||R_h q-q||_1
      <= h^(-1) integral_(-2h)^(2h) t^2 dt
          integral_0^1 (1-r)dr ||q''||_1
      = (8/3)h^2 ||q''||_1.

Therefore the one-coordinate TV error is at most (4/3)M_A J^(-2). The Gaussian coordinates and the coordinate transformations factor for each fixed theta, so a tensor product of the kernels and a telescoping product comparison give

    sup_theta TV(R_h^tensor s q_theta,q_theta)
      <= (4s/3) M_A J^(-2).                          (U2)

There are exactly J^s retained symbols. For D >= 5^s take J=floor(D^(1/s)); then J >= D^(1/s)/2 and (U2) is at most (16s/3)M_A D^(-2/s). For D < 5^s any fixed one-symbol decoder has error at most 1 <= 25 D^(-2/s). This proves the upper for every D with, for example, C_Theta = max(25,(16s/3)M_A).

The decoder generates its real-valued observation as 2Phi^(-1)(v) from fresh samples. Null endpoints can be assigned a fixed value. Applying the fixed invertible transformation back to the line preserves TV. No clipping or retained unbounded real register is involved, and no logarithm of the target error appears in the symbol count.

## 7. Conditional iid transfer and known-spectrum orbits

Suppose a quantum iid experiment Q_(n,theta) and this Gaussian experiment admit forward/backward channels T_n,S_n, with both errors uniformly at most b_n in their respective TV/half-trace-norm metrics. Compose a Gaussian code with T_n before encoding and S_n after decoding; compose a quantum code in the opposite direction for the converse. Channel contractivity and two triangle inequalities give

    e_D^G - 2b_n <= e_D^(Q_n) <= e_D^G + 2b_n.       (T1)

The intermediate continuous records are transient channel outputs. They do not add retained memory across the bottleneck. The same input-independent free seed remains allowed.

For the inherited fixed-dimension near-tracial bridge with b_n=O(delta_n+n^(-1/2)), a nontrivial critical family has delta_n=Theta(n^(-1/2)), hence b_n=O(n^(-1/2)). The new Gaussian law then yields

    c D^(-2/s)-O(n^(-1/2))
      <= e_D^(Q_n)
      <= C D^(-2/s)+O(n^(-1/2)).                    (T2)

For target errors epsilon_n -> 0 with epsilon_n sqrt(n) -> infinity, the least dimension is Theta(epsilon_n^(-s/2)), or logarithmic cost (s/2)log_2(1/epsilon_n)+O(1). A wholly classical code reaches this order. At or below the bridge remainder, (T2) does not certify a matching sharp iid precision law. Growing-signal/precision joint optimality is also outside this bounded-mean theorem.

For critical known spectra, take a fixed nonzero traceless Hermitian matrix H and its conjugation orbit {UHU*}. This orbit has affine span all s=d^2-1 traceless Hermitian coordinates, including when H has repeated eigenvalues. An elementary verification avoids a representation-theoretic premise:

* There are two unequal eigenvalues. Subtracting the orbit point which swaps them gives a nonzero multiple of E_ii-E_jj.
* The span of orbit differences is invariant under unitary conjugation. Permutations yield all traceless diagonal differences. Hadamard and phase rotations within a two-dimensional coordinate subspace yield the real and imaginary off-diagonal units.
* Those matrices form a basis of the entire traceless Hermitian space. Thus finitely many orbit points include d^2 affinely independent means.

Consequently the Gaussian orbit precision exponent is (d^2-1)/2, despite a smaller intrinsic orbit manifold dimension. The law concerns preserving the noisy Gaussian experiment, whose posterior depends on the full observation; it is not just quantizing an unknown point on the noiseless orbit.

The same conclusion is stable when H_n converges to a fixed nonzero H: choose the same finite unitaries at all n. Their affine independence and bounded central posterior Hessian persist for all sufficiently large n by continuity. No rate of H_n-H convergence is needed because the code and lower prior apply to the actual bounded orbit at each n, rather than replacing it by its limit. If H_n itself collapses to zero or loses an affine direction, uniform lower constants require a fresh analysis.

For qubit orbits this gives dimension order epsilon^(-3/2), conditionally transferred through the iid bridge in the above error regime. It does not conflict with a different ordered-spin experiment whose limiting observation is supported on a two-dimensional sphere: these are different statistical experiments.

The inherited bridge was rechecked for status from the current quantum_collision and quantum_adversary reports. This audit did not reconstruct all Schur/HCIZ/lattice steps or certify that bridge anew. Its role here is a separately supplied, internally audited premise.

## 8. Bounded primary-source comparison; no novelty clearance

The mathematical theorem above is proved directly, but its methods have established neighbors. The following primary sources were opened and read at the stated excerpt scopes. No result located in this bounded search was verified to state the exact arbitrary-quantum/shared-classical-seed D^(-2/s) preservation theorem. This is not evidence that no such prior exists.

* [Jencova and Petz, Sufficiency in quantum statistical inference, arXiv quant-ph/0604091](https://arxiv.org/abs/quant-ph/0604091), 12 April 2006, PDF pages 4-7 and 13-14: classical randomization equivalence and minimal likelihood-ratio sufficiency; the quantum sufficient-coarse-graining definition and Theorem 2/Proposition 4 connect exact recovery to preservation conditions. These are sufficiency criteria, not a guarantee of arbitrary finite memory. The binary Gaussian obstruction above is consistent with them.
* [Xu and Raginsky, Information-Theoretic Lower Bounds on Bayes Risk in Decentralized Estimation, arXiv 1607.00550](https://arxiv.org/abs/1607.00550), 2 July 2016, PDF pages 5-7 and the retrieved theorem/conclusion passages: small-ball and information-based Bayes-risk lower bounds for quantized/communication-constrained data. The small-ball converse mechanism has clear prior ancestry; this audit uses a direct POVM dimension-trace cap on posterior reconstruction to avoid an information-bound loss.
* [Barnes, Han and Ozgur, A Geometric Characterization of Fisher Information from Quantized Samples](https://web.stanford.edu/~aozgur/FisherAllerton.pdf), Allerton 2018, abstract/introduction and Theorem 1 passages: score-function geometry bounds the information retained by k-bit quantization and gives Gaussian-location estimation consequences. This is classical quantized estimation rather than uniform experiment reconstruction through arbitrary quantum memory.
* [Raginsky, Shannon Meets Blackwell and Le Cam](https://maxim.ece.illinois.edu/pubs/raginsky_ISIT11.pdf), ISIT 2011, first-page introduction/definitions: randomized channel comparison in TV, including shared randomization. This supplies the comparison framework but was not checked as a proof of the specific rate here.

Retrieval date for these primary excerpts: 2026-10-07. The browsed Jencova/Petz PDF identifies v1; Xu/Raginsky PDF is the July 2016 draft returned by arXiv. Read depths are excerpt, not full-paper proof audits. No long quotations were copied.

## Remaining step

The new Gaussian result is internally complete on the stated interface, including finite hypotheses and full-affine-span compact mean sets. External specialist review or formalization and a wider primary search remain needed for validation/priority. The iid precision consequences must continue to identify their inherited Gaussian bridge premise and the epsilon_n >> n^(-1/2) regime.
