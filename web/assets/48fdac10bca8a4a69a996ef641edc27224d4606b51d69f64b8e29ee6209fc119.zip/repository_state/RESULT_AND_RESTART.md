# Collective thermalization: strong multipartite bound entanglement

Research checkpoint, 8 October 2026 (Australia/Brisbane).
STATUS: internally derived candidate theorems; numerical and exact-rational code executed; NOT externally reviewed, proof-assistant formalized, or priority-cleared. Do not present this checkpoint as an established historical breakthrough. No independent subagents were available. This is a new state record, not a replacement for canonical Astra cards.

## Provenance and inherited capital

Read 00_START_HERE.txt and 01_CORE.txt, W/R routing and N93, and parts of the current OpenAI mathematics catalogue. Core blob: 23ae7247f5437409bc4f2356050adee79c38bea3. Catalogue blob: fc40ebdcd0fb9db026a2e44bde66f2e469939fd4.

Prior Astra discussion already contained collective-decay entanglement from I/2^N, thermal eventual entanglement for every fixed finite bath occupation, and stationary depth <=2. Those are inherited, not claimed new. Original collective-decay working files were not located in the read indices; the ingredients are independently reconstructed here. No new OpenAI theorem or Chen-Liu counting oracle is a premise. Established singlet-fraction distillation is the external input to the unlocking corollary.

## 1. Model and exact selected stationary state

J_a=(1/2) sum_i sigma_a^(i), J_+=sum_i sigma_+^(i), J_-=J_+^dagger.
D[L](rho)=L rho L^dagger - {L^dagger L,rho}/2.

L(rho)=Gamma[(nu+1)D[J_-](rho)+nu D[J_+](rho)], rho(0)=I/2^N.

Assume ideal uniform collective coupling, no drive/local noise during evolution, 0<nu<infinity. Gamma multiplies the UNNORMALIZED collective jumps. Set q=nu/(1+nu)=exp(-beta), beta=log(1+1/nu).

Schur sectors: H=direct_sum_j V_j tensor C^(m_Nj),
m_Nj=binom(N,N/2-j)-binom(N,N/2-j-1),
w_Nj=(2j+1)m_Nj/2^N,
Z_j=sum_(m=-j)^j exp(-beta*m)=sinh((2j+1)beta/2)/sinh(beta/2).

The limit selected by I/2^N is
rho_N=2^(-N) direct_sum_j [(2j+1)/Z_j] exp(-beta J_z^(j)) tensor I_m.
It is not the unique fixed point for arbitrary initial data: sector weights/multiplicity information are conserved.

Define f_j=(2j+1)/Z_j, F_beta=sum_j f_j P_j. Then
rho_N=2^(-N) exp(-beta J_z/2) F_beta exp(-beta J_z/2).
This is an invertible PRODUCT filter, so separability and partial-transpose inertia can be analyzed on F_beta. Physically implementing its inverse is stochastic and charged below.

## 2. Exact singleton-separability/PPT threshold

For every N>=2 the following are equivalent:
(a) rho_N is PPT across each single-qubit-versus-rest cut;
(b) rho_N is separable across each such cut;
(c) cosh(beta)<=4;
(d) nu>=(sqrt(15)-3)/6 = 0.1454972243679028...

Proof of PPT: decompose the rest into spin k. For k>0, put f_+=f_(k+1/2), f_-=f_(k-1/2). The block is a I + b sigma dot K, where
a=[(k+1)f_+ + k f_-]/(2k+1), b=(f_+-f_-)/(2k+1)<=0.
A sigma_y-conjugated qubit partial transpose has eigenvalues a-bk and a+b(k+1); only the second can be negative. Thus its condition is
f_-/f_+ = [k/(k+1)] sinh((k+1)beta)/sinh(k beta) <= 2(k+1).
At k=1/2 and k=1 this is exactly cosh(beta)<=4. For k>=1 the sinh ratio is <=2cosh(beta)<=8<=2(k+1)^2/k. Even N has a rest k=1/2 sector; odd N>=3 has k=1, proving necessity. k=0 is trivial. Product-filter congruence transfers inertia to rho_N.

Upgrade to separability: the SU(2) twirl of a qubit pointing up tensor a spin-k coherent state pointing down is separable and has <sigma dot K>=-k. In the two-irrep invariant block this is exactly b/a=-1/(k+1). Mixing it with the identity realizes every b/a between that value and zero, precisely the PPT interval. Rest-spin/multiplicity flags are local to the rest. Mixing blocks and undoing the product filter preserves bipartite separability.

Different singleton cuts need different decompositions; this does NOT imply full separability. For N>=4 do not infer PPT across larger cuts. At nu>nu_* each singleton partial transpose is strictly positive for fixed N; at equality there are zero eigenvalues.

## 3. Reconstructed entanglement, depth and local structure

<J^2>=3N/4 is conserved; only <J_z> is nonzero. Put M_N=-<J_z>. In sector j, r=m+j has a truncated geometric distribution and
E_j r=nu-(2j+1)/(exp((2j+1)beta)-1), between 0 and nu.
Consequently M_N=E_N j-E_N E_j r, and
M_N/sqrt(N) -> sqrt(2/pi).

Exact E_N j:
N even: (N+1/2)*binom(N,N/2)/2^N -1/2;
N odd: (N+1)*binom(N,(N-1)/2)/2^N -1/2.
It is sqrt(2N/pi)-1/2+O(N^(-1/2)).

All fully separable states obey sum_a Var(J_a)>=N/2, by the product Bloch-vector bound and concavity of variance. Thus M_N>sqrt(N)/2 certifies entanglement, eventually for every fixed finite nu. This is sufficient, not an exact general-N separability boundary.

Depth <=2: write the spin-j thermal state as a positive mixture of identical pure-product states on 2j qubits, obtained by filtering the Haar coherent-state resolution of P_sym/(2j+1). Tensor with (N-2j)/2 singlet pairs; uniformly permute. Schur's lemma fills the multiplicity register with identity. Mix with weights w_Nj. Depth is exactly two whenever entanglement is detected. This does not identify entangled labeled two-qubit marginals; in the threshold regime all such marginals are separable.

For any r-qubit subset R, the same random-pairing decomposition gives
D(rho_R,I/2^r) <= 2r E_N j/N + r(r-1)/[2(N-1)],
where D is half trace norm. Unless a sampled subset hits an unpaired spin or both members of a singlet, it is exactly maximally mixed. Thus every subset of size o(sqrt(N)) is asymptotically maximally mixed.

Singleton PPT (indeed stationary singleton separability) is preserved by tensor products and separated-party LOCC. No pure entanglement/Bell pair can be distilled by N separate parties. With non-full-separability, this is MULTIPARTITE bound entanglement. It does not solve the NPT-bound-entanglement conjecture or establish genuine N-partite entanglement.

## 4. General angular-window anti-concentration theorem

This reusable result requires no permutation symmetry. Choose theta uniformly after preparation, measure J_theta=J_x cos(theta)+J_y sin(theta), and accept an outcome within w of a prescribed center c_theta. It is LOCC: identical local axes and classical addition of outcomes.

Let a=2 sqrt(pi)(w+1)/sqrt(N). If 0<a<1 define
B(a)=(2/pi)[arcsin(a)+a log((1+sqrt(1-a^2))/a)]; for a>=1 take B(a)=1.
EVERY fully separable N-qubit state has pass probability <=B(a), for arbitrary centers.

Proof: a product-state measurement is a shifted sum of independent Bernoulli variables. Fourier inversion bounds its largest atom by sqrt(pi/(8V)), using |1-p+p exp(it)|<=exp[-2p(1-p)sin^2(t/2)] and sin(|t|/2)>=|t|/pi. An interval contains at most 2w+2 atoms. For Bloch vectors b_i, A=sum_i b_i,xy b_i,xy^T has trace<=N. Its eigenvalues satisfy lambda_1<=N, lambda_2<=N/2. Therefore V_theta >= (N/8)sin^2(theta-theta_0). The pass probability is <=min(1,a/|sin(theta-theta_0)|), whose angular average is B(a). Convexity handles separable mixtures.

Center at the target's <J_theta>, and put v=Var(J_x)+Var(J_y). Averaged Chebyshev gives target pass probability >=1-v/(2w^2). Hence
D(rho,SEP_N) >= 1-v/(2w^2)-B(a).

Uniform L-angle discretization adds at most 4/L to the separable bound (majorant total variation <=4). For L>=3 the average target variance is still v/2. Angular error delta has conservative probability error N delta; epsilon accuracy needs O(log N+log(1/epsilon)) bits. Bounded detector count error r<w replaces target width by w-r and separable width by w+r. Independent setting choice and detector/calibration costs cannot be omitted.

For rho_N, v=<J_x^2+J_y^2> <= (2nu+1) E_N j <= (2nu+1)sqrt(3N/4), since j(j+1)-m^2=(2r+1)j-r^2.
Choosing w=N^(1/3) proves
D(rho_N,SEP_N) >= 1-O_nu(N^(-1/6) log N) -> 1.
Optimizing w improves the error to O_nu(N^(-1/6)(log N)^(2/3)). This is maximal distance from FULL separability, not maximal depth or distillable entanglement. Distance to the two-producible set is zero. The finite bound is conservative; do not extrapolate distance near one to four qubits.

## 5. Regularized relative entropy grows logarithmically

Use nats. E_R(rho)=inf_SEP D_relative(rho||sigma). For m copies SEP is across N laboratories, each with m local qubits; local cross-copy entanglement is allowed. Then for fixed finite nu:
(1/4)log N-O_nu(log log N) <= E_R^infinity(rho_N) <= E_R(rho_N) <= (1/2)log(3N+1).

Lower proof: choose w=N^(1/4)log N. Target pass p>=1-O_nu(1/log^2 N); separable pass <=q=C N^(-1/4)log^2 N. Measurement data processing gives binary relative entropy >=p log(1/q)-h(p), with leading coefficient 1/4.
REGULARIZATION IS NOT ASSUMED: sequentially apply the LOCC test to m copies, retain pass/fail bits. Conditional on any history, an arbitrary N-party separable alternative remains separable across the laboratories, so its next pass probability is <=q. The target is iid Bernoulli(p). The classical KL chain rule gives >=m*d(p||q), even for alternatives with local quantum correlations across copies.

Upper proof: I/2^N is separable. Exactly
N log2-S(rho_N)=E_j[log(2j+1)-S(tau_j)] <= E log(2j+1)
<= (1/2)log E(2j+1)^2 = (1/2)log(3N+1).
Thus entropy per qubit tends to one bit, while distance from SEP tends to one. This is not global trace proximity to the identity. The leading 1/4 versus 1/2 gap remains unresolved. No exact Bell-pair cost/rate is implied.

## 6. Constant local noise after preparation

Apply E_lambda(X)=lambda X+(1-lambda)tr(X)I/2 independently. It preserves singleton separability/PPT and depth<=2. <J^2>=3N/4 remains unchanged, because all pair dot correlations scale by lambda^2 and their total was zero. Magnetization becomes lambda M_N.
Thus whenever lambda M_N>sqrt(N)/2 the noisy state is entangled. For each fixed nu>=nu_* and lambda>sqrt(pi/8)=0.6266570686577501..., this holds for all sufficiently large N. This is a sufficient threshold, not exact. It concerns POST-preparation noise, not symmetry-breaking during evolution. Neither distance ->1 nor the logarithmic lower bound is asserted under fixed local depolarization.

## 7. Exact three-qubit window, with prior-art caveat

For N=3 the normalized central state's spin-3/2 probability is 1/(1+cosh beta). Full separability requires <J^2>>=3/2, equivalently this probability >=1/4. Sufficiency follows by twirling a planar 120-degree product configuration (probability 1/4) and an aligned product (probability 1), then mixing. Product filtering preserves separability both ways.
Thus exact fully-PPT/non-fully-separable interval:
(sqrt(15)-3)/6 <= nu < (sqrt(2)-1)/2 =0.2071067811865475...
All bipartitions here are singleton cuts, and are in fact separable. This familiar invariant-state geometry must be compared with Eggeling-Werner; it is not claimed as an independently new general state classification.

## 8. Group unlocking and resource charges

For N=2n, groups A,B each measure local spin and retain j_A=j_B=j. Casimirs commute with collective jumps, so branch probability is w_nj^2. Discard multiplicity registers. At stationarity the spin state is d^(-2) sum_(J=0)^(2j) f_J exp(-beta J_z)P_J, d=2j+1.
Each group applies norm-one filter K_j=exp(-beta j/2)exp(beta J_z^(j)/2).
Successful output is sigma_j=[sum_J f_J P_J]/S_j,
S_j=sum_(J=0)^(2j)(2J+1)f_J;
p_filter=exp(-2beta j)S_j/d^2.
Its maximally entangled spin-singlet fidelity is 1/S_j.
S_j<=S_infinity(beta)=sinh(beta/2) sum_(J>=0)(2J+1)^2/sinh((2J+1)beta/2)<infinity.
Choose admissible fixed j with d>S_infinity: fidelity >1/d. Standard isotropic twirling and the Horodecki singlet-fraction theorem imply distillability between the TWO GROUPS.

Complete probability: w_nj^2 exp(-2beta j)S_j/d^2. At fixed nu,j this is Theta(N^(-3)), since w_nj=Theta_j(n^(-3/2)). Constants/filtering can be extremely bad as nu increases. This is not a uniform polynomial-in-temperature protocol. A heralded mixed state is not a pure Bell pair; later distillation overhead is unpaid by this probability. No physical experiment or optimal rate is claimed.

This is not Smolin's original pattern of one joined pair enabling two still-separated recipients. Joint operations within BOTH receiving groups are allowed here; singleton separability/PPT forbids the stronger endpoint claim.

Exact four-qubit stationary example: nu=1/5, q=1/6, groups of two selecting j=1.
S_1=37907/13373; singlet fidelity=13373/37907=0.3527844461...>1/3.
p_total=37907/7702848=0.004921166820... . About 203 preparations per heralded qutrit pair BEFORE distillation. Nondestructive triplet projections within each pair and single-qubit diag(1/sqrt(6),1) filters realize the specified operations abstractly.

## 9. Executed exact-rational FINITE-TIME certificate

See certify_finite_time.py in this directory. N=4, nu=1/5, Gamma*t=8.
It certifies singleton PPT minimum eigenvalue >1/20000-epsilon, sum of three variances <2, grouped heralding p>49/10000, singlet fidelity >7/20, and stability of these properties under arbitrary state trace-norm perturbation <=1/100000.

Method: rational birth-death generators Q_j, j=0,1,2. Uniformization P_j=I+Q_j/9 is stochastic. mu=72; truncate at K=400 and normalize. With S_K=sum_(r<=K)mu^r/r!, R=[mu^(K+1)/(K+1)!]/[1-mu/(K+2)], trace error <=epsilon=2R/S_K<3.151e-158. Construct projectors as rational polynomials in J^2. Exact positive LDL pivots certify the 16x16 partial transpose minus I/20000. Partial transpose preserves Hilbert-Schmidt norm, so operator error <=state trace error. Magnetization/filter bounds are rational; group-singlet numerator is exactly q^2/16 at all times.

Display-only values: M=1.02054956454..., variance witness minus threshold=-0.04152141368..., p=0.004921171306..., F=0.3527841246.... Pass/fail does not use these floats. This finite-time code certifies PPT, NOT singleton separability or entanglement depth at finite time. The stationary structural results are separate.

Other actual diagnostics: 36 full N=2..7 fixtures; 240 qubit-spin spectra; 900 moment fixtures; exact polynomial threshold factors; 100 product angular fixtures with 16000 pointwise tests; seven B(a) quadratures. These are not independent expert reviews.

## 10. Further escalation attempted; precise obstruction retained

Extreme-spin projector product overlap is exactly
sup_product <P_(j,-j)>=(2j+1)/(N/2+j+1).
Proof: Schur orthogonality expresses P_(j,-j) as (2j+1) times a Haar integral of the conjugated extreme spin-j matrix coefficient times U^tensorN. Apply Holder to N+2j fundamental diagonal factors. Their squared magnitude is uniform on [0,1], yielding 1/(N/2+j+1). A z-basis product of magnetization -j attains equality by the multiplicity/binomial formula.

This does not close the relative-entropy coefficient gap: summing over order-sqrt(N) relevant j gives only order-one total probability. A tempting conditional bound multiplying the overlap by Pr(J_z=-j) is FALSE: N=2, product |+> tensor |-> has singlet probability 1/2 and Pr(J_z=0)=1/2, but the proposed RHS is 1/4. A global compatibility inequality between sector overlaps, not separate sector bounds, is missing.

No uniform large-N mixing-time bound was obtained. Strict stationary PPT/entanglement margins imply finite-time existence for each fixed N, but no finite-time inference at nu=nu_* from continuity alone. Unequal couplings/local noise during evolution may break conservation and invalidate the stationary mechanism. No high-depth/GME, NPT-bound-entanglement solution, quantum-computational or metrological advantage, or secret-sharing protocol was proved.

Earlier routes: bounded-Holevo broadcasting still lacks a common family-wide measure/prepare channel; pairwise gaps and independent-input disentanglers do not close it. The general unequal-squeezing lossy-bosonic paired construction was not obtained. KLS covariance-information and reaction-network recurrence barriers were screened, not solved. Catalogue reading was not proof certification.

## 11. Sources and priority

Established prior works, consulted at varying abstract/article/search scope; not all complete proofs independently audited:
- Horodecki & Horodecki, PRA 59,4206 (1999), quant-ph/9708015, doi:10.1103/PhysRevA.59.4206: singlet fraction >1/d implies distillation.
- Smolin, PRA 63,032306 (2001), quant-ph/0001001: prior unlockable bound entanglement, different grouping pattern.
- Eggeling & Werner, PRA 63,042111 (2001), quant-ph/0010096: tripartite invariant-state separability.
- Toth et al., PRL 99,250405 (2007), doi:10.1103/PhysRevLett.99.250405; extended arXiv:0806.1048: spin-variance witnesses and thermal bound entanglement.
- Barreiro et al., arXiv:1005.1965 (2010): decoherence-induced bound-entanglement dynamics from an entangled starting state.
- Moharramipour et al., PRX Quantum 5,040336 (2024), arXiv:2406.08542: symmetry-sector maximally mixed entanglement.
- Zhang, Malz & Rabl, arXiv:2505.13401 (2025): collective decay/trajectories, different preparations.
- Bassler, PRA112,053713 (2025), doi:10.1103/qxx1-xr44; Rosario et al., doi:10.1103/xcxr-sm9c: symmetric-sector separability results; do not extend without checking lower-spin sectors.

Thermal/environmental bound entanglement and invariant-state methods are old. The novelty of THIS preparation plus exact threshold and quantitative consequences remains unresolved. Do not claim first discovery from a failed exact-phrase search.

## 12. Artifacts and restart

A complete current-conversation packet contains RESEARCH_NOTE.md, three executable scripts, all JSON outputs, replay logs, requirements and a hash manifest. Full note SHA256: ce7acf0ce4619dbfaaaf2456b8ec413d37f848346c67af495e2e71476becbeb4. Exact certificate script SHA256: 88de7dd7b0838f93bcd95ab2c080aafd538973181eb8cc11548d1d3e5b23d78b. Certificate JSON SHA256: e332a384d61faa5f649d0ec11c85300f4b7ce3507d30ddc193d266f6d00fd111.

The portable exact certificate is stored beside this checkpoint. The core all-size proof arguments are preserved above so later runs do not require the conversation attachment to restart.

First audit the singleton separability construction, angular anti-concentration constant, and regularization argument with local cross-copy correlations. Then perform specialist priority review. Technical escalation targets: close the 1/4-to-1/2 logarithmic coefficient gap without the false conditional inequality; obtain uniform preparation-time bounds; or remove the high-temperature filtering penalty with a genuinely new protocol. Do not rebrand inherited thermal-entanglement/depth observations as new or interpret numerical scaling diagnostics as proved theorems.
