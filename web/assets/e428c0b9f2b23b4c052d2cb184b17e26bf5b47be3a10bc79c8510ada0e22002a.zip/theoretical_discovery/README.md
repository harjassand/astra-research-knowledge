# Undecidable divisibility in fixed finite-state probability models

Research date: 9 October 2026.

Read `Undecidable_Divisibility_2026-10-09.md` for the theorem, full proof, limitations, references, and source revisions. The proposed result has not been independently reviewed or formally verified, and historical priority has not been established.

## Contents

- `Undecidable_Divisibility_2026-10-09.md`: complete mathematical manuscript.
- `divisibility_compiler.py`: exact rational positive-expression and marked-Markov-chain compiler.
- `exact_checks.json`: results of the symbolic and finite-instance checks actually run.
- `example_finite_chain.json`: explicit square-root-decision example for p(x)=x-3.
- `example_infinite_chain.json`: explicit infinite-divisibility-decision example for p(x)=x-3.
- `chain_audit.json`: exact transition and zero-mark-cycle checks for both exported chains.
- `provenance.json`: source revisions, literature consulted, and artifact hashes.

## Reproduce

Use Python 3.10 or later with SymPy installed:

```bash
python divisibility_compiler.py --output-dir validation
```

The compiler does not decide Diophantine solvability or divisibility. For every integer polynomial input it constructs a valid probability law; the proof shows how that law's divisibility is related to the polynomial's zero set.

## Compile another instance

```python
import sympy as sp
from divisibility_compiler import Construction

x = sp.symbols('x')
model = Construction(x*x + 1, (x,), mode='infinite')
model.export('positive_example.json')
print(model.sample())
```

For a fixed finite root order, use `mode='finite', m=3` (or any integer m>=2). `degree_caps` gives fixed coordinate-degree bounds on p squared; keeping the bounds fixed preserves the template when polynomial coefficients vary.

The examples are not an optimized implementation. The theorem's fixed-template conclusion uses the established DPRM theorem. This package does not contain a numerically minimized universal generator or the full coefficient list of a chosen universal Diophantine polynomial.

Sampling uses exact rational transitions with unbiased random bits. An optional `max_steps` causes an exception if reached, not a silently truncated or biased output. Seeded `random.Random` is used only in reproducible demonstrations; the default is `random.SystemRandom`.

The undecidability statements concern exact classification. No fixed total-variation separation or finite-precision testing impossibility is claimed.
