# Undecidable divisibility in fixed finite-state probability models

**Research date:** 9 October 2026  
**Status:** A complete proposed mathematical construction, with exact symbolic checks and an executable finite-state compiler. Not independently peer reviewed or formally verified. Historical priority has not been established. No claim of a verified historic-scale breakthrough is made.

## Abstract

For every fixed integer m >= 2, we construct a fixed finite-state absorbing Markov-generator template with rational transition probabilities and nonnegative integer vector marks for which deciding whether the output law has an m-fold identical convolution root is co-recursively-enumerable complete. A second fixed template has the same completeness property for infinite divisibility. Every output law has a rational probability generating function, an atom at zero greater than 1/3, a probability generating function that is holomorphic and zero-free on a neighborhood of the closed polydisc of radius 2, and the uniform exponential-moment bound E[2^{||X||_1}] < 3. The input changes only rational transition probabilities; it does not supply an unbounded-state simulator. The templates admit expected polynomial-bit-time exact sampling.

The mechanism is a positive rational realization that hides an arbitrary Diophantine sign problem in a convolution root or logarithm without allowing negative probabilities in the presented model. Infinite-divisibility undecidability persists after encoding the count vector into one real variable by fixed algebraic marks and adding an independent standard Gaussian. The resulting densities are strictly positive and real analytic, with uniform exponential tails. The result concerns exact decision and exact certification, not a fixed-error robust testing problem.

## 1. Definitions and principal theorem

Write N = {0,1,2,...}. For a probability law mu on N^k, let

\[
G_\mu(z)=\sum_{n\in\mathbb N^k}\mu(n)z^n,
\qquad z^n=\prod_{i=1}^k z_i^{n_i}.
\]

A law is **m-divisible** if mu = nu^{*m} for a probability law nu. It is **infinitely divisible** if this holds for every integer m >= 2, with the root permitted to depend on m. Roots are not restricted to a finite-state class.

A **finite-state marked absorbing generator** has finitely many transient states, one absorbing state, rational transition probabilities, and a mark in N^k on each transition. It starts at a specified state, terminates almost surely, and outputs the sum of its marks. Marks may be replaced by sequences of unit coordinate marks and zero marks using finitely many additional states. The counters are passive output accumulators: transitions never inspect them.

A set of finite inputs is co-recursively-enumerable (co-r.e.) if its complement can be enumerated by an algorithm. It is co-r.e.-complete if every co-r.e. decision problem reduces effectively to it. In particular, such a set is undecidable and is not recursively enumerable.

**Theorem 1 (fixed-generator divisibility).**

For every fixed m >= 2 there are a fixed dimension and a fixed marked-generator topology such that recognizing m-divisibility from its rational transition probabilities is co-r.e.-complete. There is also a fixed marked-generator topology for which recognizing infinite divisibility is co-r.e.-complete. Hardness holds within effectively generated families for which every input satisfies

\[
\mu(0)>\frac13,
\qquad
\mathbb E_\mu 2^{\|X\|_1}<3,
\]

and the probability generating function is rational and zero-free on a neighborhood of the closed polydisc |z_i| <= 2. All designated transitions can have strictly positive probabilities. Exact sampling takes expected time polynomial in the encoded rational input length, with constants depending on the fixed template.

More precisely, each hardness family can be parameterized by a single nonnegative integer a. The transition probabilities are fixed rational functions of a. For a fixed Diophantine polynomial P(a,n), divisibility holds exactly when P(a,n) has no zero in N^d.

The fixed-template conclusion is existential through the classical DPRM theorem, not an assertion that this note lists a numerically minimized universal template. The attached compiler explicitly constructs the generator for any supplied integer polynomial and supplied degree bounds.

## 2. Encoding arithmetic in a rational series

Let p be an integer polynomial in d >= 1 variables. Choose coordinate degree bounds D_i for p^2 and put

\[
e_i=D_i+1,
\qquad Q(z)=\prod_{i=1}^d(1-z_i)^{e_i},
\qquad E=\sum_i e_i.
\]

The formal series

\[
S(z)=\sum_{n\in\mathbb N^d}\left(p(n)^2-\frac12\right)z^n
\]

has the form N(z)/Q(z), where N is a computable rational-coefficient polynomial with coordinate degree at most D_i.

To verify rationality constructively, expand the polynomial p(n)^2-1/2 in the product binomial basis:

\[
p(n)^2-\frac12
=\sum_{0\le k_i\le D_i}b_k\prod_i\binom{n_i}{k_i}.
\]

The coefficients are finite differences at zero. The identity

\[
\sum_{n\ge0}\binom nk z^n=\frac{z^k}{(1-z)^{k+1}}
\]

then gives an explicit numerator after multiplication by Q. Equivalently, applying the commuting Euler operators z_i partial_{z_i} to a product of geometric series produces the same rational function. No Diophantine solvability test is used in this computation.

Take the fixed finite monomial box I = {alpha: 0 <= alpha_i <= D_i}, including coefficients that happen to vanish, and write

\[
N(z)=\sum_{\alpha\in I}n_\alpha z^\alpha,
\qquad
C=\sum_{\alpha\in I}(1+n_\alpha^2).
\]

Then C > sum_alpha |n_alpha|. Define

\[
A(z)=\frac1{Q(z)},
\qquad
T(z)=\frac{N(z)}{2C Q(z)}.
\tag{1}
\]

The critical sign identity is

\[
[z^n]T=\frac{p(n)^2-1/2}{2C}.
\tag{2}
\]

Because p(n) is an integer,

\[
T\text{ is coefficientwise nonnegative}
\quad\Longleftrightarrow\quad
p(n)\ne0\text{ for every }n\in\mathbb N^d.
\tag{3}
\]

A zero of p produces the exact negative coefficient -1/(4C). The series is not assumed to be a probability distribution.

## 3. Explicit positive envelopes

We need more than a coefficientwise bound: the eventual presented law must have an effectively supplied positive generator. Define

\[
U=A+2T=\frac{C+N}{CQ},
\qquad
V=A-2T=\frac{C-N}{CQ}.
\tag{4}
\]

Both U and V admit expressions using only positive rational constants, monomials, addition, multiplication, and geometric series.

Here is a complete construction. For alpha != 0 put B_alpha = 1+n_alpha^2. For either sign,

\[
C\pm N
=(1+n_0^2\pm n_0)
+\sum_{\alpha\ne0}\left[
 B_\alpha(1-z^\alpha)+(B_\alpha\pm n_\alpha)z^\alpha
\right].
\tag{5}
\]

Every displayed scalar coefficient is strictly positive. Also

\[
1-z^\alpha
=\sum_{i:\alpha_i>0}
 \left(\prod_{j<i}z_j^{\alpha_j}\right)(1-z_i^{\alpha_i}),
\tag{6}
\]

and

\[
\frac{1-z_i^{\alpha_i}}{1-z_i}
=1+z_i+\cdots+z_i^{\alpha_i-1}.
\tag{7}
\]

Each e_i is at least one, so division of (6) by Q cancels one factor (1-z_i), leaving a polynomial with nonnegative coefficients times products of geometric series. Dividing (5) by CQ proves the assertion.

Consequently A, U and V are positive rational series, and -A/2 <= T <= A/2 coefficientwise. On complex polydiscs of coordinate modulus at most r < 1 we also have

\[
|A(z)|\le (1-r)^{-E},
\qquad
|T(z)/A(z)|=|N(z)/(2C)|<\frac12.
\tag{8}
\]

The latter bound follows from the numerator coefficient norm, not from an unproved complex coefficientwise comparison.

## 4. A sign-isolating padding polynomial

Introduce a fresh variable t and set

\[
q(t)=1+2t+2t^3+t^4,
\qquad
R(z,t)=A(z)q(t)+t^2T(z).
\tag{9}
\]

Its t^2 layer is precisely T; every other layer is nonnegative. Therefore

\[
R\ge_{\mathrm{coeff}}0
\quad\Longleftrightarrow\quad T\ge_{\mathrm{coeff}}0.
\tag{10}
\]

The important additional fact is that **every integer power R^m, m >= 2, has an explicit positive rational realization, whether or not T has a negative coefficient**.

To prove this, put q_+ = q+t^2/2 and q_- = q-t^2/2. Equations (4) and (9) give

\[
R=\frac12(Uq_++Vq_-).
\tag{11}
\]

For r = 2 or 3 and 0 <= j <= r, consider q_+^j q_-^{r-j}. The absolute value of its difference from q^r is bounded coefficientwise by (q+t^2/2)^r-q^r. Hence

\[
q_+^j q_-^{r-j}
\ge_{\mathrm{coeff}}2q^r-(q+t^2/2)^r.
\tag{12}
\]

In increasing degree, the coefficient lists on the right are

\[
r=2:\quad
(1,4,3,2,39/4,2,3,4,1),
\]

\[
r=3:\quad
(1,6,21/2,8,81/4,57/2,71/8,
 57/2,81/4,8,21/2,6,1).
\]

All coefficients are positive. Expanding (11)^r gives R^2 and R^3 as positive sums of products of U, V and nonnegative polynomials in t. Every integer m >= 2 is 2a+3b with a,b >= 0: use b=0 for even m and b=1 for odd m. Thus R^m=(R^2)^a(R^3)^b has the asserted positive realization.

For later use define H(t)=1/(1-t). Direct multiplication gives

\[
\begin{aligned}
HR={}&A+3At+\frac{5A+U}{2}t^2
       +\frac{9A+U}{2}t^3\\
     &+\frac{11A+U}{2}\frac{t^4}{1-t}.
\end{aligned}
\tag{13}
\]

This is another explicit positive rational expression. Equations (11)-(13), not the Diophantine theorem itself, are the sign-hiding mechanism specific to this construction.

## 5. Genuine probability laws and uniform regularity

### 5.1 Fixed finite divisibility

For a fixed m >= 2 let rho=1/(16mE), write boldsymbol w=(z,t), and define

\[
G_{p,m}(w)=
\frac{R(\rho w)^m}{R(\rho\mathbf1)^m}.
\tag{14}
\]

The preceding section guarantees nonnegative coefficients. Its constant numerator coefficient is one. At positive arguments t <= 1/8,

\[
R(z,t)\ge A(z)\big(q(t)-t^2/2\big)\ge A(z)\ge1,
\]

so the normalizer is positive and at least one.

To prove convergence and the exponential bound, put r=2rho. Equation (8), together with q(r)+r^2/2 <= 1+3r for r <= 1/8, gives

\[
|R(\rho w)|\le (1-r)^{-E}(1+3r)
\quad\text{when }|w_i|\le2.
\]

Using -log(1-r) <= 2r and log(1+3r) <= 3r,

\[
\log |R(\rho w)|
\le 2Er+3r\le\frac{5}{8m}.
\]

Consequently

\[
G_{p,m}(2\mathbf1)\le e^{5/8}<3.
\tag{15}
\]

This proves normalization to a probability law, the uniform moment bound, and its atom bound G_{p,m}(0)>1/3. All inequalities have a margin, so the series is holomorphic on a neighborhood of the closed radius-2 polydisc. It is also zero-free there: Q is zero-free and

\[
|R/A-1|\le2r+r^2/2+2r^3+r^4\le3r<1.
\]

### 5.2 Infinite divisibility

Introduce one more variable y. Set

\[
F_p(z,t,y)=\frac{H(t)}{1-yR(z,t)}
=\frac{H(t)+yH(t)R(z,t)}{1-y^2R(z,t)^2}.
\tag{16}
\]

The second expression is a positive rational realization: its denominator is expanded as a geometric series in y^2R^2, and (13) handles its numerator. This equality is why a signed R does not create a signed presented law.

Now let rho=1/(16E) and define

\[
G_{p,\infty}(w)=\frac{F_p(\rho w)}{F_p(\rho\mathbf1)},
\qquad w=(z,t,y).
\tag{17}
\]

For coordinate modulus at most r=2rho <= 1/8, Bernoulli's inequality gives

\[
(1-r)^{-E}\le\frac1{1-Er}=\frac87.
\]

Moreover q(r)+r^2/2 < 4/3, whence |R| < 32/21, |yR| < 4/21 and |H| <= 8/7. Thus

\[
|F_p|<\frac{8/7}{1-4/21}=\frac{24}{17}<3.
\tag{18}
\]

The numerator in (16) has nonnegative coefficients and constant coefficient one, so its positive normalizer is at least one. Equations (17)-(18) prove the same probability, atom, exponential-moment, holomorphy and zero-free assertions. In particular,

\[
\Pr(\|X\|_1\ge L)<3\,2^{-L}.
\tag{19}
\]

## 6. Extracting the exact divisibility decisions

### 6.1 Roots cannot escape the count lattice

Suppose a law mu on N^k with mu(0)>0 equals nu^{*m}, where nu is initially allowed to be a law on R^k. If a coordinate of a nu-distributed vector is negative with positive probability, taking all m independent copies in a fixed negative interval makes their sum negative with positive probability. Hence nu is supported on the nonnegative orthant. It follows that nu(0)^m=mu(0)>0. Taking one copy outside N^k and the other m-1 copies at zero would put positive mu-mass outside N^k. Thus nu is supported on N^k.

This proves that count-lattice divisibility and ordinary real-vector divisibility coincide for every law under discussion.

### 6.2 Every fixed m

A formal series with positive constant term has a unique m-th root with positive constant term. This follows recursively by total degree: the unknown coefficient at each degree appears multiplied by m times the (m-1)-st power of the constant term.

For (14), this root is exactly

\[
\frac{R(\rho w)}{R(\rho\mathbf1)}.
\tag{20}
\]

It is a probability generating function exactly when its coefficients are nonnegative. Necessity follows from uniqueness and the preceding lattice argument. Sufficiency follows directly from its convergent normalized series. Equations (3) and (10) therefore prove

\[
G_{p,m}\text{ is m-divisible}
\quad\Longleftrightarrow\quad
p\text{ has no zero on }\mathbb N^d.
\tag{21}
\]

### 6.3 The logarithmic criterion for infinite divisibility

For completeness, let G be any count probability generating function with G(0)>0 and write the formal identity

\[
\log(G/G(0))=\sum_{\alpha\ne0}c_\alpha w^\alpha.
\tag{22}
\]

Then G is infinitely divisible if and only if every c_alpha is nonnegative.

For necessity, its normalized formal m-th root is exp((sum c_alpha w^alpha)/m). At a fixed nonzero multi-index alpha its coefficient equals c_alpha/m + O_alpha(m^{-2}). Only finitely many products contribute to this coefficient. A negative c_alpha therefore contradicts the nonnegativity of all sufficiently high-order convolution roots.

For sufficiency, nonnegative c_alpha imply, by the formal exponential identity and monotone summation,

\[
\frac1{G(0)}=
\sum_\alpha[w^\alpha]\exp\Big(\sum_{\beta\ne0}c_\beta w^\beta\Big)
=\exp\Big(\sum_{\beta\ne0}c_\beta\Big).
\]

Thus Lambda=sum c_alpha=-log G(0)<infinity, and

\[
G(w)=\exp\left(\sum_{\alpha\ne0}c_\alpha(w^\alpha-1)\right)
\]

is a finite-intensity compound-Poisson law. Dividing the intensities by any m provides its roots. This proves the criterion without assuming a finite coefficient cutoff.

For (16),

\[
\log F_p=-\log(1-t)+\sum_{j\ge1}\frac{y^j}{j}R(z,t)^j.
\tag{23}
\]

If p has no zero, T and R are nonnegative, making every nonconstant coefficient in (23) nonnegative. If p(n)=0, then

\[
[z^nt^2y]\log G_{p,\infty}
=-\frac{\rho^{\|n\|_1+3}}{4C}<0.
\tag{24}
\]

Normalization changes only the constant term. Hence

\[
G_{p,\infty}\text{ is infinitely divisible}
\quad\Longleftrightarrow\quad
p\text{ has no zero on }\mathbb N^d.
\tag{25}
\]

## 7. The finite-state realization and sampling costs

A positive rational expression used above is compiled as follows. Evaluate each subexpression at the chosen positive rational scaling point. All resulting values are finite rational numbers.

For a sum, choose a summand with probability proportional to its value, then sample that normalized summand. For a product, sample the normalized factors independently and concatenate their marks. A monomial emits its exponent vector; a constant emits zero. A geometric factor 1/(1-J) repeats an independent normalized J-output a geometrically distributed number of times, with continuation probability J(rho). Its continuation probability is a rational number strictly below one.

These instructions compile to a finite control graph. Each expression has finite syntax depth; a product is sequential composition, a sum is a finite branch, and a star is a loop around a finite subgraph. The compiler in the accompanying Python file explicitly emits this graph with rational transition probabilities.

Every loop iteration emits a positive total mark: the basic geometric factors emit z_i or t, and the outer loop in (16) emits y^2. Therefore the zero-mark transition subgraph is acyclic. If S is the number of transient states, the number of transitions in a completed execution is at most (S+1)(1+||X||_1). Equation (19), or (15) and Markov's inequality, gives a uniform exponential termination tail for a fixed graph.

Rational categorical draws can be sampled exactly using unbiased random bits and integer rejection. Their expected bit cost is polynomial in the transition-probability encoding length. Together with the uniform expected transition bound, this gives expected polynomial-bit-time exact sampling in each fixed-template family. Truncating the transition count and random-bit draws yields a worst-case finite approximation with an explicitly charged total-variation error; no such truncation is used to claim exact decision of divisibility.

This proves a positive probabilistic realization, not just positivity of a rational generating function whose realization is left as another unsolved problem.

## 8. Co-r.e. completeness and fixed topology

The classical Davis-Putnam-Robinson-Matiyasevich theorem states that every recursively enumerable subset of N has a Diophantine representation [1,2]. Apply it to a recursively enumerable complete halting set K. There is one fixed integer polynomial P(a,n_1,...,n_d) such that

\[
a\in K\quad\Longleftrightarrow\quad
\exists n\in\mathbb N^d:\ P(a,n)=0.
\tag{26}
\]

Fix the coordinate degree bounds once, taking their maxima in this polynomial, rather than recomputing smaller degrees at special parameters. Apply the preceding construction to p_a(n)=P(a,n). Equations (21) and (25) reduce the complement of K to the two decision problems.

The variable count, monomial box, denominator exponents, and all positive-expression syntax are fixed. In (5), include every monomial in the fixed box even if its coefficient vanishes. The coefficients n_alpha are polynomial functions of a, and C is a positive polynomial function of a. All scalar expression values and all compiled transition probabilities are rational functions of a. Their bit lengths are polynomial in the binary length of a. The graph topology does not change. The scalar factors n_alpha^2+1 +/- n_alpha are strictly positive, so no disappearing branch is required.

For the converse complexity inclusion, a rational count PGF with a positive atom at zero has effectively computable rational coefficients in its normalized formal m-th root and in log(G/G(0)). A negative coefficient is an enumerable certificate of nondivisibility. If the normalized formal root has only nonnegative coefficients, its formal m-th power equals G/G(0), and monotone summation forces its normalization to be finite and correct. The logarithmic case was proved in Section 6.3. Thus both decision problems are co-r.e., completing the proof of Theorem 1.

## 9. Scalar and Gaussian-smoothed versions

**Theorem 2 (one real observable and analytic densities).** The fixed finite-divisibility and infinite-divisibility undecidability results persist for one real observable whose transition marks lie in one fixed finite set of positive algebraic numbers. For infinite divisibility they also persist after addition of an independent standard Gaussian; all resulting densities are strictly positive and real analytic, with a uniform exponential-moment bound.

**Proof.** Let k be the fixed vector dimension, theta=2^{1/k}, and choose marks

\[
a_j=\theta^{j-1},\quad 1\le j\le k.
\]

The polynomial x^k-2 is irreducible by Eisenstein's criterion, so the a_j are linearly independent over Q and belong to [1,2). Thus

\[
\iota(n)=\sum_{j=1}^k a_j n_j
\]

is an injective additive map from N^k into R_+. Its image is locally finite, since each a_j >= 1. Set X=iota(N).

Any real convolution root of X is nonnegative, has a positive atom at zero, and is supported on iota(N^k): otherwise one root summand outside that set together with all other summands at zero contradicts the support of X. The injective additive map then lifts the root to N^k. Hence finite and infinite divisibility are preserved in both directions. Since X <= 2||N||_1,

\[
\mathbb E\exp(cX)<3,\qquad c=(\log2)/2.
\tag{27}
\]

Now use the infinite-divisibility family and let Z be an independent standard Gaussian. Put W=X+Z. Its density is

\[
f_W(x)=\sum_n\mu(n)\frac1{\sqrt{2\pi}}
                 \exp\left[-\frac{(x-\iota(n))^2}{2}\right].
\tag{28}
\]

It is strictly positive. The same sum for complex x converges uniformly on compact sets, because the modulus of each Gaussian factor is at most exp((Im x)^2/2)/sqrt(2pi), independently of its real shift. Thus f_W is the restriction of an entire function. Also

\[
\mathbb E e^{c|W|}
\le \mathbb E e^{cX}\,\mathbb E e^{c|Z|}
<6e^{c^2/2}<7.
\tag{29}
\]

It remains essential to prove that Gaussian smoothing does not erase the divisibility obstruction. The analytic logarithm of G has absolutely summable coefficients lambda_n, with sum |lambda_n| ||n||_1^2 finite. The scalar characteristic exponent is

\[
\log\phi_X(u)=\sum_{n\ne0}\lambda_n(e^{iu\iota(n)}-1),
\]

and

\[
\log\phi_W(u)=-\frac{u^2}{2}
                 +\sum_{n\ne0}\lambda_n(e^{iu\iota(n)}-1).
\tag{30}
\]

This is a finite signed Levy-measure representation. Its uniqueness is a standard part of quasi-infinite-divisibility theory [5]. A direct finite-variance argument makes the sign obstruction explicit. If W were infinitely divisible, its finite-variance Levy-Khintchine representation would give

\[
-(\log\phi_W)''(u)
=\sigma^2+\int x^2e^{iux}\nu(dx),\qquad \nu\ge0.
\]

Equation (30) instead gives the Fourier transform of the finite signed measure

\[
\delta_0+\sum_{n\ne0}\lambda_n\iota(n)^2\delta_{\iota(n)}.
\]

Uniqueness of Fourier transforms of finite measures forces this measure to equal sigma^2 delta_0 + x^2 nu(dx). All nonzero atoms iota(n) are distinct, so each lambda_n must be nonnegative. Conversely, nonnegative lambda_n give a compound-Poisson law X, and adding the Gaussian preserves infinite divisibility. Therefore W is infinitely divisible exactly when the original vector law is. This proves Theorem 2.

The scalar result uses a fixed algebraic nonlattice alphabet. It does **not** establish the corresponding theorem for a single integer-valued rational PGF.

## 10. Structural consequences and limits

**No computable coefficient cutoff.** There is no total computable function of the input encoding length that bounds the degree of a negative logarithmic coefficient for every non-infinitely-divisible instance in the fixed template. Otherwise enumerate all coefficients through that bound and decide the co-r.e.-complete problem. The same argument applies to coefficients of the normalized formal m-th root.

**No complete effective positive-certificate system.** Any sound system of finite positive certificates with a computable verifier misses some divisible instances in these families. A sound and complete system would make the positive set recursively enumerable; both it and its complement would then be enumerable, contradicting completeness.

**No finite algebraic sign characterization.** Extend the parameter a in the fixed construction to all nonnegative real numbers. Equations (5)-(18) still produce valid laws; arithmetic integrality is needed only for the reduction on integer inputs. The parameter locus of divisibility cannot be semialgebraic. A semialgebraic subset of the real line is a finite union of intervals and points, so its membership on sufficiently large integers is constant and hence decidable. That contradicts (26). In fact this locus is not definable in any o-minimal expansion of the real field, by the defining one-dimensional finiteness property of such structures.

**Exactness matters.** No fixed positive distance from the divisible class is promised. A negative witness in (24) may occur at a very high count and have extremely small magnitude. The results do not rule out useful finite-precision approximations, promise-gap tests, asymptotically correct decisions in the limit, or classification of restricted physical models. They do rule out an always-terminating exact recognizer, even when the finite generator and all its rational parameters are supplied exactly.

## 11. Relationship to previous mathematics

The arithmetic undecidability is imported from DPRM [1,2], not claimed as new. The count-law logarithmic criterion is classical compound-Poisson mathematics; Section 6.3 provides its needed proof. Signed Levy-measure uniqueness and the terminology of quasi-infinite divisibility precede this work [5].

Bausch and Cubitt [3] give polynomial-time finite divisibility results for finitely supported distributions. Our inputs have infinite support but finite positive-state presentations. Their result therefore does not decide this problem. Bernardoff's finite criterion for inverse powers of multiaffine polynomials [4] is another important restricted positive result. The rational functions here are not confined to that class.

Astra's N38 Gaussian-count construction motivated investigating positive logarithmic coefficients and independent Poisson representations. Its own source attributes the loop-soup mechanism to established mathematics, and its repository status remains internally derived and externally unreviewed. No Gaussian-sampling theorem from Astra is assumed in the present proof.

During breadth exploration, selected original sections of OpenAI's subgaussian logarithmic-Sobolev manuscript were inspected, including Gaussian regularization, posterior-covariance identities, and the entropy-defect compactness argument. Those claims are not premises of this construction, and the complete OpenAI theorem was not independently audited here.

The proposed contribution is the sign-isolating positive realization, together with the resulting fixed-generator exact-decision, finite-root, and smoothed-law theorems. The primary-source search conducted here did not locate this exact combined result, but that is not a priority certificate. Its historical significance is not established by its internal proof or by the attached checks.

## 12. Reproduction and validation status

Run:

```bash
python divisibility_compiler.py --output-dir validation
```

The script requires SymPy and uses exact rational arithmetic. It verifies the padding identities, the positive base-power coefficient bounds, the HR identity, several explicit normalized PGFs and tail bounds, and one bivariate rationalization. It emits rational marked-chain JSON files. The examples p(x)=x-3 and p(x)=x^2+1 exercise both a negative sign witness and a positive arithmetic instance.

The checks validate particular algebraic identities and finite examples. They are not a formal proof of the unbounded theorem, and they do not decide the universal Diophantine family. The mathematical proof of the unbounded result is Sections 2-9, relative to the established DPRM and Levy-Khintchine theorems. No universal polynomial's full coefficient list or optimized fixed state count is provided.

### References

[1] Y. Matiyasevich. Enumerable sets are Diophantine. Doklady Akademii Nauk SSSR 191 (1970), 279-282; English translation, Soviet Mathematics Doklady 11 (1970), 354-357. Classical DPRM theorem.

[2] J. P. Jones. Universal Diophantine equation. Journal of Symbolic Logic 47(3) (1982), 549-571. DOI: 10.2307/2273588. See also J. Bayer et al., The DPRM Theorem in Isabelle, ITP 2019, DOI: 10.4230/LIPIcs.ITP.2019.33, and J. Bayer and M. David, A Formal Proof of Complexity Bounds on Diophantine Equations, ITP 2025, DOI: 10.4230/LIPIcs.ITP.2025.3. The latter sources were consulted; no claim is made that the 2019 development was already complete at publication.

[3] J. Bausch and T. Cubitt. The complexity of divisibility. Linear Algebra and its Applications 504 (2016), 64-107. arXiv:1411.7380v2.

[4] P. Bernardoff. Which negative multinomial distributions are infinitely divisible? Bernoulli 9(5) (2003), 877-893. DOI: 10.3150/bj/1066418882. The finite multiaffine criterion was checked in Theorem 2 of the author's later primary manuscript, Domain of existence of the Laplace transform of infinitely divisible negative multinomial distributions, arXiv:2106.00342v1 (2021).

[5] A. Lindner, L. Pan, and K.-i. Sato. On quasi-infinitely divisible distributions. arXiv:1701.02400v1 (2017); Transactions of the American Mathematical Society 370 (2018), 8483-8520. The introduction and uniqueness formulation in the primary preprint were consulted.

### Repository revisions actually accessed

Astra: `7e08c9fc917a684a437155abd2c790d5f5ff2d99`.
Relevant records: `00_START_HERE.txt` (initial navigation at the corresponding branch head), `agent/topics.txt`, selected complexity-index ranges, `frontier/review_cards/N38-nonnegative-gbs.txt`, `frontier/cards/N38-nonnegative-gbs.json`, and the original proof rendering `web/pages/d-33f172c4dc41f1b1.html`. The latter tool response was truncated after the principal derivations; the whole archive was not loaded.

OpenAI/math: `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`.
Relevant records: README, selected contents, and lines 1-210 of `preprints/A-dimension-free-logarithmic-Sobolev-inequality-for-subgaussian-log-concave-measures-September-23-2026/build/sections/03-critical.tex` (blob `016a22e3a93f763107d956f29eaabbc17d25f24b`).
