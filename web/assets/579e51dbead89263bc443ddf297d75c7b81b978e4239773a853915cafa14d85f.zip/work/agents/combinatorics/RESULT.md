# Combinatorics composition result

## Main outcome

No unrestricted sunflower theorem or historical-calibre combinatorial advance was established. The highest-ceiling sunflower transfer was attacked in three materially different representations: balanced-shadow random detection, exact signed clean tensors, and binary linear coset codes. Two bridges were refuted by exact mathematics; the third yields an actual constant-base theorem for its linear subclass, resolving a gap in the earlier local attempt by classical binary affine-cover structure. A positive source-dependent expander extension and its characteristic-p homological consequences are independently audited in `expander_composition/REPORT.md` and `expander_composition/chain_audit/COEFFICIENT_EXTENSION_AUDIT.md`.

## Positive expander consequence and sharp limit

Conditional on the pinned OA177 geometric/KMS inputs, ambient rank N=2d suffices for d≥2, saving one coordinate through Iwasa's pro-epimorphism range. The resulting congruence tower has a sharp coefficient classification, with support-expansion constants independent of the coefficient group A:

- Degree one expands exactly when A has no element of order p.
- Every degree 2≤j<d expands exactly when multiplication by p is bijective on A.
- Hence d=2 permits integer coefficients, while d≥3 fails over Z in degree two because Ext(H_1,Z) is nonzero.

This follows from localized integral pro-stability, normalized p-power transfer, finite p-primary integral homology, universal coefficients, and coefficient-independent link/cocycle expansion. The characteristic restriction is proved necessary, rather than left as a source assumption.

A rectangular square-zero block gives an actual group retraction Γ_N(m)→F_p^(md²). Therefore β_j(X_m;F_p)≥binom(md²+j−1,j) in every 1≤j<d. Independently checked coherent support lifting gives sys_j≥m. In degree one a short graph cycle basis supplies the upper bound sys_1=Θ(m)=Θ(log V). Coefficient-independent cosystoles are Ω(V). These are actual logical classes and sparse p-qudit checks; the code distances are strongly unequal, and no frontier parameter gain follows.

Two exact failures prevent naive escalation: in characteristic two the middle logical spaces vanish and the top systole is d+2 with dual distance 1; the opposition complex cannot be a closed convex or complete CAT(0) invariant complex because a nontrivial finite p-subgroup acts freely. The usual Ramanujan apartment-retraction/minimal-area proof of higher log-power systoles therefore cannot be transplanted. A new quantitative filling theorem staying inside the opposition complex remains missing.

Prior-art correction: Oppenheim–Valentiner-Branth, https://arxiv.org/html/2510.18351v1, Theorem 1.1 already gives degree-one expansion for all groups with no order-p element, including Z. Our result classifies this particular p-power tower and its higher degrees; it is not first existence of integer 2-dimensional expanders. The unbalanced-code parameter pattern is also prior art. Exact size V=N p^((m−1)(N²−1)) makes even the weakest admitted refined d=3 instance exceed 10^43 vertices. No instance was built; the incidence-oracle derivation charges enormous fixed precomputation.

## Changed premises actually acquired

Pinned release commit: adc7f1241b42e322a6451854ab7e4b4c146bf78a.

OA175 supplies a simultaneous selector for the **same member** H at all legal scales: for non-p-small F and preassigned edge-dependent probability weights λ_H, independently color vertices with probabilities 256^i p and obtain λ_H(A_i)≥1−2^(−i), all i, with probability≥9/10. The resulting mean color≤2 lets independent product variables round arbitrary fractional containment covers at the constant loss 25·512^4. Source anchors: `expectation/sections/selector.tex`, theorem `thm:multiscale-selector`; `expectation/sections/rounding.tex`, equations `round:mass`, `round:lower`, `round:upper`.

OA175's discrete convexity proof supplies a different mechanism: an even-row signed kernel gives positive high powers of one biased-Fourier weight system, whose total budget is controlled by Parseval; pair-sampling converts concentration of many small weights into an integral cover. It covers exceptional sets outside K unions at the original density, K=2^75, or outside two unions at a constant density loss. Source anchors: `convexity/sections/01_covering.tex`, lemma `lem:covering`; `02_weights.tex`, `eq:signed-identity` and `eq:global-weight-bound`; `00_intro.tex`, main theorem and two-union corollary.

The difference from the earlier capital is concrete: reconstruction now retains one witness across multiple scales, and LP cover rounding no longer loses a parameter-dependent factor. It does not automatically make a child support sunflower-free or acquire an alphabet-independent rank fraction.

## Direct sunflower outcomes

1. **Balanced-shadow independence density obstruction, proved.** For binary cube parents of rank k, k divisible by 6, let H be their rank-k/2 shadow. At p=a/binom(k,k/2), a random child support hits every fixed parent cluster with probability→1−e^(−a), but its probability of being sunflower-free tends to zero. The exact second-moment bound has leading exponential factor ρ=(4+3√2)/9<1. Proof and precise estimates: `SHADOW_DENSITY_OBSTRUCTION.md`. Finite coefficient/count checks: `SHADOW_DENSITY_OBSTRUCTION_CHECKS.txt`. These checks are only checks of the counting formulas; the asymptotic conclusion comes from the proof.

2. **Vertex capture does not give a safe shadow, proved.** The independent selector worker gives a fully source-compatible [1024]^k product, r=1025, p=1/1024, s=1, where the early balanced shadow contains an r-sunflower with probability→1. It also calculates exponentially small captured-parent weight in relevant product controls and preserves the fact that a different collision-aware safe projection has cover cost one. Source: `selector_sunflower/RESULT.md` and its `obstruction/selector_parent_mass_obstruction.md`.

3. **Direct full capture still has a rank-dependent price.** Uniform λ needs i>log₂ k to eliminate all residual labels. The color budget then forces p<1/(2k^8). This fails to close the constant-base sunflower problem. This is a limit of this particular uniform-weight use, not an impossibility theorem for all selector compositions.

4. **Signed clean tensor, exact representation but failed uniform bound.** T_Q=(δ_xy+δ_xz+δ_yz−1)/2 restricts to a diagonal tensor on any clean-triple-free code. Its actual slice projections retain the word-label structure. On a q-symbol coordinate, TTᵀ has eigenvalues q/2 with multiplicity q−1 and q(q²−5q+8)/4 on constants. The released Boolean Fourier budget therefore does not transfer with an alphabet-independent constant. Source: `SIGNED_CLEAN_TENSOR_ATTACK.md` and `SIGNED_TENSOR_CHECKS.txt`. The representation matches the known character/slice-rank approach, whose prior bound grows as (q−1)^(2/3); no priority claim is made.

5. **Linear coset-code theorem, actual restricted bound.** For V=F_2^n and coordinate kernels K_1,…,K_k with trivial common intersection, encode v by its cosets v+K_i. If every 2-dimensional U⊂V meets some K_i in dimension one (equivalently the code is clean-triple-free), then n≤2k−1 for n>0, and |C|≤4^k/2. The complement of the union of kernels is sum-free, so a vector v in it yields a cover of V by the paired cosets K_i and v+K_i. Recursively extracting irredundant subcovers charges at most 2s−1 dimensions to s discarded kernels. A separate private-point induction produces a legal integral outside-coset certificate of size at most k² at every root: outside one selected coset costs at most 2k−1, and its interior recurses on k−1 kernels. This quadratic certificate is not the sought linear certificate. Proofs: `selector_sunflower/LIN_COSSET_ATTACK.md` and independent `selector_sunflower/obstruction/LIN_TARSI.md`. The needed binary affine-cover inequality is valid classical prior art: Brouwer, *An inequality in binary vector spaces*, Discrete Math. 59 (1986), 315–317, https://ir.cwi.nl/pub/2507/2507D.pdf. An independent Rado/Tarsi proof supplies the same rank inequality. This resolves a genuine subclass gap in the previous local attempt, without claiming a new global sunflower theorem or novelty for the subclass. The superficially matching Nagy–Pach–Tomon result arXiv:2205.03389 is explicitly withdrawn for a Claim 4.5 error; it is excluded as a premise.

## Prior-art refresh

Primary sources freshly checked:

- Frankston–Kahn–Narayanan–Park, https://arxiv.org/abs/1910.13433: generic spread/random containment still has logarithmic rank loss.
- Pham, revised September 6, 2026, https://arxiv.org/abs/2412.03540v2: earlier fractional cover rounding at O(log support rank) and global log-log comparison.
- Shangguan, September 24, 2026, https://arxiv.org/abs/2609.30263: bounded-VC random detection and sunflower bound (Cr log(d+1))^k. It does not resolve arbitrary VC dimension.
- Fang–Wang, September 25, 2026, https://arxiv.org/abs/2609.30680: log-star expectation-threshold comparison, strictly weaker than the pinned release's advertised universal comparison.
- Naslund–Sawin, https://arxiv.org/abs/1606.09575, Theorem 2: fixed-alphabet clean-free bound c_q^k with c_q=(3/2^(2/3))(q−1)^(2/3); establishes that alphabet dependence in the signed tensor is a prior known barrier.

No claimed theorem is inferred from a review website or search summary.

## Strongest next sunflower attack

The exact missing safe-shadow statement is weighted neighborhood capture: for every parent weight, find a sunflower-free balanced child support G capturing an exp(−polylog k) fraction of that weight. The new simultaneous selector is potentially useful only if coupled to a proved price for deleting child conflicts or to an actual occurrence-preserving restriction inequality. Dense independence, automatic safety of all captured children, and uncharged large-parent capture are no longer live assumptions.

The linear coset subclass now has a valid dimension theorem. Its translation invariance removed the root-selection quantifier and converted dirty triples into a 2-dimensional incidence condition. Arbitrary word codes do not supply a group addition, affine kernels, or an irredundant linear-form cover, so none of the proof's decisive steps extend automatically. The strongest next general attack would need an occurrence-preserving analogue of the charged affine-cover recursion, or an independently proved weighted child-conflict repair bound.

## Memory provenance used for navigation, then live reopened

`MEMORY.md:278-319` and `rollout_summaries/2026-10-04T01-50-07-hKil-sunflower_conjecture_laptop_audit_and_global_proof_attempt.md:31-67` routed to the prior handoff and October 4 closure. The decisive statements were reopened from their actual local files in this run. Rollout id: 01a1049a-aae7-7be1-8ede-9c8eee0d2a81. Root final response should carry a memory citation if it uses this navigation/history.
