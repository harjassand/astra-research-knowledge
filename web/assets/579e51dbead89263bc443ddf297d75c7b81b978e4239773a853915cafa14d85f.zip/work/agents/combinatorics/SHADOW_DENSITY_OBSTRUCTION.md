# Balanced-shadow independence is sparse at the parent-capture density

Status: direct elementary proof below. This refutes one proposed composition of the released discrete-convexity theorem with the balanced safe-shadow route. It does not refute the safe-shadow target, the sunflower conjecture, or the released theorem.

## Exact statement

Let k run through positive multiples of 6 and set m=k/2. Use the ground set U=[k]×{0,1}. The parent family is

F_k = { {(i,x_i): i∈[k]} : x∈{0,1}^k }.

Let H_k be its m-uniform shadow: every member chooses m distinct coordinates and one binary label on each. Put B=binom(k,m), N=|H_k|=B·2^m. For a parent A, its cluster is S_A=binom(A,m), of size B. Independently retain each member of H_k with probability p=a/B, for an arbitrary fixed a>0 and sufficiently large k; denote the resulting child support W.

1. F_k is 3-sunflower-free.
2. For every parent A, P(W∩S_A≠∅)=1−(1−a/B)^B→1−exp(−a).
3. P(W is 3-sunflower-free)→0, exponentially in k up to polynomial factors.

More precisely, with ρ₁=(4+3√2)/9<1 and ρ₂=(4+2√2)/9<1,

P(W is 3-sunflower-free)
≤ 6 a⁻³(k+1)^6(2/3)^k
 +36 a⁻¹(k+1)^17 ρ₁^k
 +36 a⁻²(k+1)^16 ρ₂^k.

Thus choosing a=ln 2 already hits every fixed parent cluster with probability greater than 1/2 while the probability that W is an independent set of the shadow sunflower-conflict hypergraph tends to zero.

## Proof

Three distinct binary words cannot be clean: in each coordinate a clean triple must be all equal or all distinct. The binary alphabet disallows the latter, so all coordinates would be equal and the words identical. This proves 1. Independence of child retention gives 2 directly.

For 3, it suffices to count sunflowers with empty core, namely unordered triples of pairwise disjoint members of H_k. Let T denote the number of these triples in H_k, and let Z denote the number whose three members all lie in W.

### Lower bound on T

Partition the k coordinates into six classes, each of size k/6. Three classes have types single-i, i=1,2,3: only child i uses that coordinate. Three classes have types double-missing-i, i=1,2,3: the other two children use the coordinate with different binary labels. Each coordinate has two label choices, in either kind of class. The three children are pairwise disjoint. Each child uses k/6+2k/6=m coordinates.

The number of ordered triples in this construction is

2^k k! / ((k/6)!)^6.

The balanced multinomial coefficient is the largest coefficient in the expansion of (1+⋯+1)^k with six terms. There are at most (k+1)^6 coefficients, so it is at least 6^k/(k+1)^6. Dividing ordered triples by 6 gives

T≥12^k/[6(k+1)^6].

Consequently μ=E Z=T p^3≥a^3(3/2)^k/[6(k+1)^6], because B≤2^k.

### Degree bound

Fix E∈H_k. Count ordered pairs of children (F,G) disjoint from E and from one another. On each of the m coordinates used by E, only one binary symbol remains available, so the local generating polynomial is 1+u+v. On each of the other m coordinates, the polynomial is 1+2u+2v+2uv. The desired count is the coefficient of u^m v^m in

(1+u+v)^m(1+2u+2v+2uv)^m.

All coefficients are nonnegative. Set u=v=t=1/√2. The coefficient is at most

t^(-2m)(1+2t)^m(1+4t+2t²)^m
=[2(1+√2)]^k.

Hence the degree of E in the unordered triple hypergraph is at most D=[2(1+√2)]^k. Also N≤(2√2)^k.

### Pair and codegree bounds

The number P of ordered pairs of disjoint children is the coefficient of u^m v^m in

(1+2u+2v+2uv)^k.

The same substitution bounds it by

P≤(4+2√2)^k.

For a fixed pair E,F of disjoint children, their union uses k of the 2k ground elements. A third child disjoint from them is an m-subset of the remaining k elements, with the transversal restriction possibly removing choices. Thus the codegree is at most binom(k,m)≤2^k.

### Second moment

Indicators for distinct triple hyperedges with no common child are independent. If two triple hyperedges share exactly one child, their joint probability is p^5; if they share exactly two children, it is p^4. Counting ordered pairs of triple edges sharing one child by N D² and sharing two by P(2^k)² only overcounts. Therefore

Var Z≤μ+N D²p^5+P·4^k p^4.

The central binomial coefficient is the largest of k+1 coefficients summing to 2^k, hence B≥2^k/(k+1), and p≤a(k+1)2^(−k). Substitution yields

N D²p^5≤a^5(k+1)^5(1+3√2/4)^k,

P·4^k p^4≤a^4(k+1)^4(1+√2/2)^k.

Divide by the displayed lower bound on μ². Chebyshev gives P(Z=0)≤Var Z/μ², which is the stated estimate. Since W being sunflower-free implies Z=0, assertion 3 follows.

## Consequence for the attempted composition

The release's original-density discrete-convexity theorem applies to a family D with μ_p(D)≥1−1/K, K=2^75. Its two-union consequence applies when μ_p(D)>1/2, at a constant density loss. Taking D to be the collection of sunflower-free child supports fails even for F_k above at the density where individual parent clusters are captured with constant probability.

The unresolved WNC target still asks for a sunflower-free child support G whose *upward neighborhood* captures an exp(−polylog k) fraction of arbitrary parent weight. The obstruction does not constrain an adaptive G, which may differ drastically from a Bernoulli child support. It shows that typicality of independent child supports is too strong an intermediate premise. Random repair or weighted extraction would need a distinct structural theorem.

## Source boundary

Released theorem: OpenAI, Talagrand's discrete convexity conjecture, sections/00_intro.tex, Theorem `thm:main` and Corollary `cor:two-union`, at commit adc7f1241b42e322a6451854ab7e4b4c146bf78a. Raw source: https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Talagrands-discrete-convexity-conjecture-September-23-2026/build/source/sections/00_intro.tex

Prior balanced-shadow WNC and rainbow reduction: `/Users/harjas/Documents/Codex/2026-07-15/current-task-statement-a-set-family/SUNFLOWER_PROGRESS_HANDOFF.md`, sections 1.2 and 2.1–2.2, reopened in this run. The proof here is independent of any validity claim about the release or WNC.

Priority: this elementary obstruction is not claimed to be new in the literature. Its research role is to eliminate the actual proposed transfer, with exact interfaces and quantifiers.
