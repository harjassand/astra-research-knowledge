# Independent audit: prime localization and characteristic-p contrast

This is an independent adversarial check of the parent's proposed extension of the pinned OA177 proof. It is conditional on the geometric identification and finite-quotient recognition of the source, not an independent validation of all of OA177. No fatal algebraic gap was found in the extension below. Required coefficient conventions and the degree-zero expansion check are made explicit.

## 1. Exact proposed coefficient result

Fix d>=3, n=2d, N=2d+1, and a sufficiently large odd prime p satisfying the source's geometric/local expansion requirements. Let S=Z[1/p] and take exactly the source complexes T_m and X_m=skel_d T_m, m>=2. Then the source's proof mechanisms imply

    reduced H_j(X_m;S)=0 for 0<=j<d,
    reduced H^i(X_m;A)=0 for 0<=i<d

for every S-module A, with trivial coefficients. This includes Q, R, C, finite fields of every characteristic different from p, and arbitrary abelian coefficient groups on which multiplication by p is an automorphism. It does not include F_p or a general coefficient group with p-torsion. Ordinary H^0 remains the constant cochains; the degree-zero statement is reduced.

The group-homology vanishing also holds for U and Gamma_N(m), in the source's required respective ranges, with S coefficients. Over F_p the same X_m instead satisfies

    dim H_1(X_m;F_p)>=m(N^2-1),
    m<=sys_1(X_m;F_p)<=C_d,p m,

where the upper bound additionally uses the source's fixed-degree graph expansion and the source/group-count fact log |X_m(0)|=O(m). The source's coefficient-independent cosystolic input gives cosys_1(X_m;F_p)>=c_d,p |X_m(0)| in support count, provided its stated uniform link/cone hypotheses are retained. Thus the canonical F_p CSS qudit degree-one sector is unbalanced: k>=m(N^2-1), Z distance Theta(m), X distance Omega(|X_m(0)|). Its quantum distance is only Theta(log |X_m(0)|). No historical-priority or frontier-parameter claim is made.

## 2. Integral geometry survives

The shared local source `ovb.html`, converted to `ovb_extract.txt` in this directory, states in line 1124 that from that point onward a `k-cone function` means an integral (k,Z)-cone function. Its Corollary 6.10 supplies an (r-2)-cone on the relevant type-A_r opposition complex when p>=2^(r-1). Thus reduced homology of the opposition complex vanishes integrally below r-1. Integral tensoring gives the same chain contraction over any coefficient ring, and joins retain the required lower acyclicity by the augmented join chain formula.

The OA177 geometry filtration uses relative chains of (F*O,partial F*O) equal to a shift of the augmented O chains. With integral coefficients, one must retain the orientation sign in this chain isomorphism; it changes no homology calculation. The block relative homology vanishes in every degree k<n. Therefore each attachment preserves reduced homology through j<n-1. Filtered unions commute with simplicial homology, and the full affine building is contractible. Consequently reduced H_j(L;Z)=0 for j<n-1, hence the same over S by flatness and over F_p by the integral chain contraction/UCT. Source anchors: `geometry.tex`, `eq:spherical-opposition`, `eq:relative-chains`, `prop:L-acyclic`.

## 3. Projectivity and localization

All nonempty U-simplex stabilizers in L are finite p-groups. Over S, averaging by |H|^-1 splits augmentation S[H]->S, so the induced simplex permutation modules are projective over S[U]. Type preservation prevents inversions and fixes simplex orientations. The integral acyclicity therefore makes the augmented chain complex a partial projective resolution in the same range as in OA177. The U orbit complex is a simplex, giving H_j(U;S)=0 for 0<j<n-1.

The Gamma_N(m) action has trivial nonempty simplex stabilizers for m>=2, so its chain modules are free over any coefficient group algebra. It follows that H_j(T_m;B)=H_j(Gamma_N(m);B) for j<n-1 for any constant coefficient ring B; in particular B=S and B=F_p. For F_p this comparison does not require p-stabilizers of U to be invertible, because only the free Gamma action is used.

Iwasa's integral homology pro-stability (source cited version Theorem 5.13; the shared downloaded arXiv version states the corresponding range in Theorem 0.3) gives pro-zero stabilization cokernels once a>=2j+1, using relative stable rank<=2 for t^m F_p[t]. Tensoring with S preserves those cokernels and their zero transition maps, because S is flat over Z. Equivalently H_j(G;S)=H_j(G;Z) tensor S by flat localization of the bar chain complex.

Every transition Gamma_a(m') subset Gamma_a(m), m'>=m, has finite p-power index. Transfer followed by inclusion is multiplication by that index on S-homology, which is invertible. Inclusion is therefore surjective. Induced maps on stabilization cokernels are surjective as well. A pro-zero system with surjective transitions is zero at each fixed level. This is sufficient for ordinary stabilization surjectivity; there is no need to upgrade all pro-isomorphisms to ordinary isomorphisms.

Two-coordinate centralization uses precisely the source stable range N-2=2(d-1)+1. Any homology class in degree 1<=j<=d-1 is represented on the N-2 coordinates complementary to a chosen elementary matrix. Hence all elementary conjugations, and therefore SL_N(F_p[t]) conjugation, act trivially on H_j(Gamma_N(m);S). The quotient G_m is a finite p-group. Its coinvariant functor over S is exact by averaging, so

    H_j(U;S)=H_j(Gamma_N(m);S)_(G_m)=H_j(Gamma_N(m);S)=0.

This proves the proposed vanishing in the source range.

## 4. Arbitrary S-module cohomology and a uniform expansion constant

The finite augmented simplicial chains of X_m are free S-modules and acyclic below d. Since S is a PID, the lower boundary modules are free and the relevant exact sequences split. Equivalently use the S-module universal coefficient sequence: Hom_S(H_i,A)=0 and Ext_S(H_(i-1),A)=0 for i<d, with ordinary H_0=S contributing no Ext. Thus reduced cohomology vanishes for every S-module A without assuming A finite, flat, or finitely generated.

The uniform expansion argument needs more than this qualitative vanishing. OVB integral cone functions give proper-link coboundary expansion with a constant beta>0 depending on n but independent of the coefficient abelian group. A chain homomorphism defined on integral simplex bases tensors directly with an arbitrary abelian group; support can only shrink from cancellation, so its cone radius stays bounded. Alternatively, for the distance-to-cocycles inequality, every finite cochain has values in a finitely generated coefficient subgroup: a uniform inequality there implies it in the full coefficient group because enlarging the cocycle group can only decrease distance.

Dikstein-Dinur, *Coboundary and cosystolic expansion without dependence on dimension or degree*, Theorem 2, gives for positive i with n>=i+2 the cocycle expansion lower bound

    eta_i >= beta^(i+1)/(4(i+2)!)-e lambda,

uniform in the coefficient group (abelian for higher degrees). The source KMS local spectral bound lambda=2/sqrt(p) lets one choose one sufficiently large p so that every i=1,...,d-1 has a positive common lower bound. The exact relevant link degree hypotheses must be retained; the local cone expansion supplies all proper links that occur in this range.

Theorem 2 is stated for i>0, so degree zero must be checked separately. Let P be the stationary weighted graph walk with nonconstant eigenvalues bounded above by lambda. For a coefficient-valued vertex labeling f, let p_a be the stationary mass of each label. Since the label classes partition the vertex set,

    norm(delta_0 f)
      =1-sum_a <1_a,P 1_a>
      >=(1-lambda)(1-sum_a p_a^2)
      >=(1-lambda)(1-max_a p_a)
      =(1-lambda)dist(f,constants).

This gives a coefficient-independent degree-zero inequality. The source's comparison of intrinsic skeleton weights applies to support norms for every coefficient group, with the same factor cancellation. Thus one possible common expansion constant is

    epsilon = min(1-lambda, min_(1<=i<d) eta_i)/M >0,

where M is the fixed chamber incidence bound used by OA177. Once reduced H^i(X_m;A)=0 is established for the full A, the cocycle distance is exactly the coboundary distance. Every A-cochain is covered, although A itself need not be finitely generated.

Source handles for parent verification: shared `dd.txt`, lines 182-188; shared `ovb.html`/own `ovb_extract.txt`, Theorems 1.1 and 1.2, Proposition 2.7, cone convention after that proposition, Corollary 6.10. This audit checked those clauses directly; no new theorem is inferred from an abstract alone.

## 5. Sharp characteristic-p failure

For R=F_p[t], the map

    Gamma_N(m) -> sl_N(F_p) tensor (t^m R/t^(2m)R),
    I+t^m A -> t^m A modulo t^(2m)

is an additive-group homomorphism with kernel Gamma_N(2m). Determinant linearization modulo t^(2m) imposes exactly trace A=0. Surjectivity follows from surjectivity SL_N(R)->SL_N(R/t^(2m)), since the latter local-ring group is generated by elementary matrices and polynomial representatives lift those generators. The congruence-I condition modulo t^m is preserved under the lift. Therefore

    Gamma_N(m)/Gamma_N(2m) = sl_N(F_p)^(direct sum m)

as abelian groups. Its F_p dimension is m(N^2-1), including if p divides N: trace is still a nonzero linear functional on all N by N matrices. It is a quotient of H_1(Gamma_N(m);F_p). The free-action homology comparison and the unchanged 2-skeleton of X_m give the claimed H_1(X_m;F_p) lower bound. Hence the coefficient-p restriction is real, not merely a missing proof technique.

## 6. Short-loop lift: stronger m bound and cover check

Take an l-edge closed graph circuit in X_m. Because m>=2, reduction is injective on every local group H_i and preserves all local subgroup intersections. A path beginning at the identity coset H_(i_0) can be lifted successively to vertices

    g_r H_(i_r), where g_r=g_(r-1) h_(r-1), h_(r-1) in H_(i_(r-1)).

Each h has matrix entries of degree at most one, so entries of g_l have degree at most l. Closure in the finite quotient means g_l mod t^m is an element of the reduced H_(i_0); choose h in H_(i_0) with that reduction, whose entries also have degree at most one. If l<m, both g_l and h have entries of degree strictly less than m, hence their congruence modulo t^m implies g_l=h entrywise. The lifted path therefore closes in L. Since H_1(L;F_p)=0, it bounds a finite 2-chain there; projection fills the original circuit in X_m. Multiplying by h^-1 first gives a weaker degree estimate and is unnecessary.

The quotient/path-lift issue at m=2 causes no extra gap. Gamma acts freely on vertices and preserves types. If two lifts of a quotient simplex containing the same specified lifted vertex were Gamma translates, the translating element would fix that vertex and hence be the identity. Every quotient incident simplex has a lift at that vertex by translating any lift. Thus the quotient identifies stars correctly in the source's m>=2 regime. The source's explicit reduction/intersection lemma is the required hypothesis; a generic arbitrary quotient would not suffice.

Every F_p 1-cycle supported on s edges decomposes as a linear combination of fundamental simple circuits in its support graph, each of length at most s. Choose a spanning forest and eliminate chord coefficients; the remaining tree cycle is zero. Therefore a cycle of support size s<m is a sum of circuits that all fill, proving sys_1>=m. No positivity or ordering of F_p coefficients is assumed.

For the upper bound, a breadth-first spanning tree of a graph of diameter D has fundamental circuits of length <=2D+1, and these generate its full graph cycle space. Since simplicial H_1(X_m;F_p) is nonzero, at least one survives after quotienting by triangle boundaries. The source's uniform graph expansion and bounded degrees imply D=O(log |X_m(0)|). With the fixed-ring congruence count log |X_m(0)|=O(m), this gives sys_1<=C m.

## 7. Stronger localized stable range: rank N=2d and all d>=2

The previous sections retain the original source rank N=2d+1 for transparent comparison. The parent's proposed optimization to N=2d, ambient n=N-1=2d-1, also survives this audit and gives the same p-invertible conclusion for every d>=2.

The essential distinction is that only a pro-epimorphism is needed, not a pro-isomorphism. Iwasa's Theorem 0.3 in the shared arXiv v2 text gives integral homology stabilization as a pro-epimorphism at a>=2j+r-2 and as a pro-isomorphism at a>=2j+r-1. With r=2, the former begins at a>=2j. Flat localization preserves its pro-zero cokernel; normalized transfer upgrades it to an ordinary surjection at each level exactly as above. The parent's check of published Theorem 5.13 reports the same pro-epimorphism range.

For each j<=d-1, the complementary N-2=2d-2 coordinates now meet a>=2j. Two stabilization surjections therefore still put every class on coordinates complementary to an elementary conjugation. The geometric range j<n-1=2d-2 contains j=d-1 exactly when d>=2. OVB needs n>=3, which also holds exactly in this range. For d=2 the desired 2-skeleton is the (n-1)-skeleton itself, so the source weight comparison is particularly direct. The lower-homology and characteristic-p contrast arguments are otherwise unchanged, with N^2-1=(2d)^2-1.

The original source states d>=3, apparently focusing on the previously unresolved higher-dimensional range because dimension two was already known. This is not a mathematical obstruction from its chosen rank: even its original N=2d+1, n=2d and pro-isomorphism range also formally cover d=2. The optimized N=2d statement is a derived construction refinement and must be identified as such; it is not literally the pinned theorem's stated rank/quantifier range. No proof mechanism here covers d=1 through the KMS argument, for which ordinary expander graphs suffice separately.

## 8. Exact coefficient classification, including a stronger dimension-two result

The localization result and finite simplicial chain complex imply that every integral H_j(X_m;Z), 1<=j<d, is a finite p-primary group: a finitely generated abelian group killed by tensoring with Z[1/p] has exactly this form. In particular write

    H_1(X_m;Z) = direct sum_(a=1)^t Z/p^(r_a)Z,
    r_a>=1, t>=m(N^2-1).

The lower bound on t follows from H_1(X_m;F_p)=H_1(X_m;Z) tensor F_p, since H_0 is free, and from the explicit congruence quotient.

For every abelian group A the ordinary universal coefficient sequence is

    0 -> Ext_Z^1(H_(i-1)(X_m;Z),A)
      -> H^i(X_m;A)
      -> Hom_Z(H_i(X_m;Z),A) -> 0.

In degree one this gives H^1(X_m;A)=Hom(H_1(X_m;Z),A). This group vanishes exactly when A[p]={a:pa=0} is zero: sufficiency follows because H_1 is p-primary; necessity follows by mapping any nonzero cyclic summand to a nonzero element of A[p]. Thus in dimension d=2 the same fixed family has vanishing reduced cohomology in every degree below d exactly for coefficient groups on which multiplication by p is injective. Uniform cocycle expansion then makes it a uniform coboundary expander for every such A, with a common constant independent of A. This includes Z and every torsion-free abelian group; p need not act surjectively.

For d>=3, degree two is also below the top. If A/pA is nonzero then each A/p^(r_a)A is nonzero (and surjects onto A/pA). The universal coefficient injection

    Ext_Z^1(H_1(X_m;Z),A)
      = direct sum_(a=1)^t A/p^(r_a)A
      -> H^2(X_m;A)

therefore forces nonzero degree-two cohomology. If A[p] is nonzero, degree one already fails. Conversely, if multiplication by p is both injective and surjective, all Hom and Ext terms from finite p-primary homology vanish. Consequently, for each d>=3, m>=2 and this fixed p,

    reduced H^i(X_m;A)=0 for every 0<=i<d
      if and only if p:A->A is an automorphism.

With the uniform coefficient cocycle bound this is also an exact classification of which coefficient groups have positive coboundary expansion in every degree below d for the family. For all failing groups the corresponding degree-one or degree-two coboundary Cheeger constant is zero. In particular Z coefficients are admissible in dimension two but fail in degree two in every d>=3. This classification is a chain/UCT consequence beyond the initial S-module statement and should receive its own novelty check.

## 9. Finite elementary subgroup retraction and each positive-degree coefficient phase

The parent's proposed root-group retraction is valid: projection of Gamma_N(m)/Gamma_N(2m) to the E_12 coefficients gives a homomorphism to F_p^m, and the section maps a polynomial f supported in degrees m,...,2m-1 to e_12(f). Since E_12^2=0, this is an exact additive subgroup, and projection composed with section is the identity.

There is a stronger rectangular-block version. Split the coordinates into disjoint sets I,J of sizes floor(N/2), ceil(N/2). Let W consist of matrices F with nonzero entries allowed only in the I by J block, and each allowed entry a polynomial supported in degrees m,...,2m-1. For F,F' in W, FF'=0 because J and I are disjoint. After ordering I before J, I+F is block upper unitriangular, so its determinant is 1. Thus

    s: (W,+) -> Gamma_N(m), F -> I+F

is an injective group homomorphism. The map r taking the I by J block of g-I modulo t^(2m), with coefficients of t^m,...,t^(2m-1), is a group homomorphism on Gamma_N(m), since all quadratic terms have degree at least 2m. It satisfies r s=identity. Therefore Gamma_N(m) retracts onto

    Q = (F_p)^h, h=m floor(N^2/4).

For optimized N=2d this is h=md^2; for original N=2d+1 it is h=md(d+1). Homology of Q injects as a direct summand into homology of Gamma_N(m) for every constant coefficient ring, because functoriality preserves r s=identity. The geometric/free-action comparison transfers this direct summand into H_j(X_m) for j<d.

A self-contained dimension calculation uses the periodic free resolution for one cyclic p-group: its differentials alternate between g-1 and 1+g+...+g^(p-1). With trivial F_p coefficients both are zero. Tensor h such resolutions gives a free resolution for Q, whose trivial-coefficient degree-j chain space has one basis vector for each h-tuple of nonnegative integers summing to j, and all differentials zero. Hence

    dim H_j(Q;F_p)=binom(h+j-1,j),
    dim H_j(X_m;F_p)>=binom(h+j-1,j)  (1<=j<d).

For h>=2, H_j(Q;Z) is nonzero in every positive degree. In odd degrees the integral homology of either cyclic factor gives a nonzero summand. In even j>=2, the Kunneth tensor term H_1(C_p;Z) tensor H_(j-1)(C_p;Z) gives Z/p. Induction using the split integral Kunneth sequence shows all positive integral H_j(Q;Z) are elementary p-groups. Thus every H_j(X_m;Z), 1<=j<d, contains a nonzero elementary p-group. This uses h>=2, which holds throughout m>=2 and N>=4.

This upgrades Section 8 to an individual-degree classification. In degree one,

    H^1(X_m;A)=0 iff A[p]=0.

In every 2<=j<d, both the finite p-primary groups H_j and H_(j-1) are nonzero. If A[p] is nonzero the Hom term is nonzero; if A/pA is nonzero the Ext term is nonzero. Conversely p invertible kills both. Therefore

    H^j(X_m;A)=0 iff multiplication by p on A is bijective
      for every 2<=j<d.

Combining with the common cocycle expansion gives the same exact phase classification for the positive coboundary-expansion constant in each degree. For bad coefficients the corresponding coboundary constant is exactly zero. Quantifiers are fixed d,p,m and arbitrary abelian A with trivial coefficients; no local systems are included.

The uniform-support issue for integral cones is explicit: if M is the integer matrix of a cone on oriented simplex bases, tensoring with A replaces each integer entry c in M e_sigma by c a on a coefficient generator a e_sigma. Its support is contained in the integral support of M e_sigma. Signs and coefficient cancellation can only decrease support, so the same cone radii and derived link constants work for Z and all other abelian groups. This verifies that the dimension-two Z case does not rely merely on qualitative vanishing.

## 10. Higher systoles: support incidence removes the dimension loss

The short-loop lift extends to every 1<=j<d, and its lower bound can remain m rather than m/(j+1). Let z be a nonzero F_p simplicial j-cycle supported on s distinct j-faces. Let K be the subcomplex formed from those support faces and their subfaces.

First K has at most s vertices. For every support vertex v, the chain obtained by taking the link of z at v is a nonzero reduced (j-1)-cycle: the signed boundary identities follow from partial z=0, including the augmentation identity when j=1. A nonzero reduced simplicial k-cycle has at least k+2 support faces. For k>=1, choose one k-face; each of its k+1 facets needs another support face to cancel its nonzero coefficient, and no distinct k-face can contain two of those facets. For k=0, the reduced augmentation cannot vanish on a singleton nonzero coefficient. Therefore link_v(z) has at least j+1 support faces, so v occurs in at least j+1 support j-faces. Counting vertex-face incidences gives

    (j+1)s >= (j+1)|K(0)|,
    hence |K(0)|<=s.

Now suppose s<m. Every simple graph circuit in K has length <=|K(0)|<=s<m. The polynomial short-loop argument returns to the starting lifted vertex for every such circuit, at every choice of starting lift. Simple circuits generate the fundamental group of each connected support graph. Thus choose one lifted vertex per component and lift all graph paths: circuit monodromy being trivial makes every endpoint and edge independent of the path choice.

The quotient L->T_m identifies the closed star at every lifted vertex with the corresponding quotient star in the source's m>=2 regime. Indeed, lifts of a simplex are precisely Gamma orbits by the explicit quotient identification; two lifts containing the same prescribed vertex would differ by an element fixing that vertex, and its stabilizer is trivial. Every quotient incident simplex can also be translated to contain the prescribed lifted vertex. Hence the consistent graph lift extends to all support simplices of K, and faces agree across adjacent simplices.

The cycle z therefore lifts to a j-cycle in L with the same coefficients. Integral opposition-cone acyclicity gives H_j(L;F_p)=0 for j<n-1. This range contains every j<d for either source rank N=2d+1 or optimized rank N=2d, d>=2. The lifted cycle bounds a finite (j+1)-chain. Its projection lies in X_m because j+1<=d, and fills z. Consequently

    sys_j(X_m;F_p)>=m for every 1<=j<d.

This proof does not assume L simply connected; it uses closed endpoint lifts for short circuits and the established homological acyclicity. It also does not treat the top j=d sector, which still contains the ambient-simplex boundaries of support d+2. For j=1 the breadth-first graph argument supplies a matching upper O(m); for j>=2 this audit establishes only the lower bound, not a matching upper bound or an optimal distance scaling.

## 11. Caveats that survive this audit

* This is a conditional extension of the source proof mechanisms, not an independent audit of its twin-building identification, Iwasa convention equivalence, or KMS recognition.
* Cochains over coefficients other than F_2 require oriented, signed simplicial boundaries. Copying the F_2 unsigned formula would be wrong.
* Degree-zero reduction and constants must be stated. Ordinary H^0 does not vanish.
* The uniform coefficient extension uses the integral cone and local-to-global theorem explicitly; qualitative S-homology vanishing alone supplies no uniform filling constant.
* No conclusion is made for nontrivial local systems, nonabelian higher coefficients, or characteristic-p coboundary expansion. The exhibited H_1 in characteristic p prevents the latter.
* The characteristic-p CSS parameters are unbalanced and logarithmic in their smaller distance. No new good quantum LDPC parameters follow.

Status: elementary algebra and lifting portions independently checked; source-dependent geometric/global hypotheses preserved. Parent should perform primary-source novelty checks before treating the coefficient result as publishable.
