# OA177: exact homology and CSS obstruction

Source pin: `adc7f1241b42e322a6451854ab7e4b4c146bf78a` in `openai/math`.
Primary source: https://github.com/openai/math/tree/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Bounded-degree-coboundary-expanders-in-every-dimension-September-24-2026/build/source
Local downloaded copies in this directory are the pinned source files, not modified source.

## 1. Scope verified from source

For every fixed integer d>=3 the source constructs connected pure d-dimensional X_m with vertex counts tending to infinity, fixed D and epsilon>0, and all i<d satisfying weighted norm(delta_i f)>=epsilon dist(f,B^i). Here B^0 is the constants. Source locations: `introduction.tex`, theorem `thm:main`, equations `eq:weights`, `eq:goal`; `construction.tex`, equation `eq:construction`; `expansion.tex`, lines 139-156. The source expressly distinguishes distance to B from distance to Z.

For each m>=2, X_m=skel_d(T_m), where T_m is pure n=2d dimensional. The proved homology range for the full T_m is 1<=j<=d-1; see `homology.tex`, proposition `prop:quotient-homology`. This is not a proof that full T_m has no homology in every degree below 2d.

The Lean scope document `lean/docs/177.md` matches the advertised F_2 quantifiers. The downloaded comparator is a statement file whose `main` ends in `sorry`; that comparator itself was not used as proof evidence. No Lean build or formal proof dependency audit was performed here.

## 2. Theorem-level obstruction

Let X be a finite pure d-dimensional simplicial complex over F_2. Suppose for every i<d and every cochain f, norm(delta_i f)>=epsilon dist(f,B^i), with epsilon>0 and positive weights on every face. If f is a cocycle then its distance to B^i is zero, and finiteness plus positive weights implies f is in B^i. Hence reduced H^i(X;F_2)=0 for 0<=i<d, and by finite-dimensional duality reduced H_i=0 in the same range.

For the standard CSS construction with physical qubits C_i(X), X checks given by rows of boundary_i, and Z checks given by columns of boundary_(i+1), the number of logical qubits is k=dim H_i(X;F_2), the Z distance is the minimum weight in ker boundary_i minus im boundary_(i+1), and the X distance is the minimum weight in ker delta_i minus im delta_(i-1). Therefore every 1<=i<d sector has k=0. In ordinary degree zero, connectedness gives k=1, d_Z=1, d_X=|X(0)|; using reduced chains instead removes this sector.

If H_d(X) is nonzero, choose a nonzero top cycle z and a top face sigma in its support. The singleton cochain e_sigma pairs with z to 1, so e_sigma is not a coboundary. Since there are no (d+1)-faces, every top cochain is a cocycle. Thus d_X=1. This holds for every finite d-complex with nonzero H_d, independent of expansion or top systolic distance.

Thus a direct canonical CSS code from a coboundary expander has either zero encoded qubits (interior sectors), or quantum distance one (ordinary bottom sector and nonempty top sector). One-sided filling expansion does not provide two nontrivial protected logical sectors.

## 3. Construction-specific exact top distances

For OA177, every ambient (d+1)-simplex tau of T_m has all of its d-dimensional facets in X_m. The chain boundary(tau) has exactly d+2 top faces and is a nonzero d-cycle. Since X_m has no (d+1)-faces, it is a nonzero homology class.

Conversely, every nonzero d-cycle in a simplicial complex, d>=1, has at least d+2 faces. Pick a face sigma in its support. Every one of its d+1 facets must also occur in a different support face. A distinct d-face cannot contain two distinct facets of sigma, since their union is sigma. At least d+1 other faces are therefore needed.

Consequently, for every source m>=2,

    beta_d(X_m)>0, sys_d(X_m)=d+2, cosys_d(X_m)=1.

With the source's normalized top-face weights these are (d+2)/|X_m(d)| and 1/|X_m(d)|, respectively. Purity gives |X_m(d)|>=|X_m(0)|/(d+1), so both normalized quantities vanish with m.

The top Betti number is in fact linear in the size. Let Delta be a uniform bound on the number of ambient (d+1)-faces through a vertex. It exists because a source vertex lies in exactly M chambers, giving Delta<=M binom(2d,d+1) (`expansion.tex`, lines 74-83). There are at least |X_m(0)|/(d+2) such ambient faces. A greedy vertex-disjoint packing selects at least |X_m(0)|/((d+2)^2 Delta) of them, up to integer rounding. Their boundaries have disjoint top-face supports and are linearly independent. Thus beta_d>=c_d |X_m(0)|, while |X_m(d)|<=D |X_m(0)|/(d+1). This supplies constant-rate top classical cycle spaces with constant distance; it does not supply a useful direct quantum distance.

## 4. Exact ordinary graph tensor-product result

Let d>=3, let X be any connected finite d-complex with reduced H_j(X;F_2)=0 for all j<d and with top systole s and top Betti number b>0. Let G be any connected finite graph with v vertices, e edges, cycle rank r=e-v+1>0 and finite girth g. Use the ordinary cellular product chain complex C_*(X) tensor C_*(G), with its product cell basis. Let f_i=|X(i)| and a=|X(0)|.

The exact nonzero homology sectors, by the field Kunneth theorem, are H_0=F_2, H_1=H_1(G), H_d=H_d(X), and H_(d+1)=H_d(X) tensor H_1(G). All 2<=i<=d-1 sectors vanish. The standard CSS parameters are:

| Qubit degree | Qubit count | Logical dimension | Z distance | X distance |
| --- | ---: | ---: | ---: | ---: |
| 1 | f_1 v + a e | r | g | a |
| d | f_d v + f_(d-1) e | b | s | v |
| d+1 | f_d e | b r | s g | 1 |

For the last two X-distance equalities use cosys_d(X)=1, which holds automatically for every finite d-complex with nonzero top homology. For OA177 substitute s=d+2.

Proof of degree-1 Z distance: the augmentation on C_0(X) induces the projection to G; it induces an isomorphism on H_1, and cannot increase support. Every nonzero representative therefore has at least g cells. A graph girth cycle at any fixed vertex of X attains g. For X distance restrict a nontrivial degree-1 cocycle to each slice {x} times G. The cohomology class on these slices is the same for every x, because X is connected. It is nonzero by the Kunneth identification. Each slice needs at least one edge in its support, so the cocycle uses at least a product edge cells. A singleton graph-edge cochain which is nontrivial on a graph cycle, repeated at every X vertex, attains a.

Proof of degree-d Z distance: augmentation on C_0(G) projects total degree d to C_d(X); it induces an isomorphism on H_d since H_(d-1)(X)=0, and does not increase support. It gives lower bound s; a minimum top X cycle at any G vertex attains s. For X distance restrict to X times {v}. Adjacent slices have cohomologous top cochains because the mixed part of the total cocycle witnesses their difference as a coboundary. All v slices have the same nonzero top class, so each needs at least one top face. Repeating one nontrivial singleton top cochain at all graph vertices attains v.

Proof of top Z distance: a top chain is a matrix whose columns are in ker boundary_d(X) and whose rows are in ker boundary_1(G). A nonzero column has at least s nonzero entries, giving at least s nonzero rows; each nonzero row has at least g entries. Thus weight>=s g. A tensor of minimum cycles attains equality. No top boundaries exist. The top singleton-cochain argument gives X distance one.

Consequences for growing logarithmic-girth bounded-degree graphs:

* The degree-d quantum code has distance min(d+2,v)=d+2 once v>=d+2; its rate is at most 1/v, so graph growth also destroys its rate.
* The top product cycle space has classical distance (d+2)g and can have constant classical rate when G is regular of degree>2 and the source top Betti ratio is positive. Its associated quantum top sector still has distance one.
* The degree-1 sector has distance min(g,a). Its logical dimension comes entirely from the graph. For source m growing, r/(f_1 v+a e)<=1/a, so its rate vanishes. This gives at most the graph's logarithmic cycle distance.
* The product's one-skeleton already contains the triangles of X. The girth of G is not the girth of the product's one-skeleton.

A simplicial join X*G has reduced homology only in top degree d+2, equal to H_d(X) tensor H_1(G), and the same top cycle distance s g with top cosystole one. Moreover its vertex incidence grows with the size of the other factor, so the join does not preserve bounded vertex degree. No statement here rules out a different, explicitly specified balanced product, local-system construction, puncturing, or quotient; each would need an actual chain map and a new homology/distance argument.

## 5. Failure ledger and remaining attack

Rejected: infer positive-rate CSS logical space in degrees below d from coboundary expansion. Exact failure: these groups vanish.

Rejected: infer large top systole from bounded degree and expansion. Exact source counterexample: every ambient (d+1)-simplex has boundary of d+2 top faces.

Rejected: infer useful quantum distance by tensoring top cycles with a high-girth graph. Exact failure: top X logical distance is one; one degree below top the original d+2 Z cycle remains.

Unresolved possible route: use full T_m in the middle degree d instead of X_m=skel_d T_m. Then the local simplex boundaries are stabilizers, rather than logical cycles. The source proves lower homology vanishing only up to d-1. Nonzero H_d(T_m), a lower bound on its homological systole, and a suitable comparison of the available cosystolic bound to this full-chain sector remain necessary. None is established by this audit. The source explicitly notes an additional nontrivial-cosystole bound in the OVB input (`expansion.tex`, lines 30-41), which is potentially useful only after nonzero middle homology and homological distance are acquired.

Prior-art interface verification: Bravyi and Hastings, *Homological Product Codes*, Section II.1, https://arxiv.org/html/1311.0885v1, describes the same standard CSS construction from boundary maps. Its general homological-product distances need not multiply; the exact multiplication proved above applies specifically to the top classical tensor-cycle sector, not to arbitrary CSS homological products.

Status: source-derived conditional on OA177's construction and advertised homology theorem; the CSS and product obstruction proofs are independent elementary chain algebra. No claim of an independent full OA177 proof validation, novelty, or external mathematical certification.
