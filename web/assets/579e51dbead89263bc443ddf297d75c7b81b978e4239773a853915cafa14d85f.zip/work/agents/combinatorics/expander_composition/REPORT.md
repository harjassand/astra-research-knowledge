# OA177: coefficient phase separation, logarithmic systoles, and code obstruction

Status: internally derived mathematics with named source dependencies; no external proof or priority certification. Source commit: `adc7f1241b42e322a6451854ab7e4b4c146bf78a`. No released construction was instantiated: its smallest admitted output is already astronomically large. The exact original source is in `source/`. Independent audit notes are in `chain_audit/`.

## Decisive result

The proposed F2 quantum-code consequence fails sharply. The released X_m is the d-skeleton of a 2d-dimensional complex. In every degree 1,...,d-1 its F2 cohomology is zero. In degree d, its homological systole equals d+2, and the dual logical distance equals 1. Graph girth does not repair either fact under the direct or ordinary product construction.

A positive consequence survives after changing coefficients. The same algebraic construction is a bounded-degree coboundary expander simultaneously over every Abelian coefficient group A on which multiplication by its field characteristic p is invertible. This is stronger than merely choosing one coefficient field. In dimension two, injectivity alone suffices, including integer coefficients. At characteristic p the failure is real: H1 has at least m(N^2-1) independent Fp classes. A split elementary-Abelian subgroup additionally certifies nonzero characteristic-p homology in every relevant higher degree. The degree-one classes yield a sparse homological quantum code with homological distance Theta(log V) and cohomological distance Omega(V), where V is the vertex count. This parameter pattern already occurs in the Ramanujan-complex coding literature; it is not a new good quantum LDPC construction.

The localization argument also saves one ambient coordinate: N=2d suffices rather than N=2d+1, by using Iwasa's pro-epimorphism range. This covers d>=2. Neither the coefficient extension nor the rank saving is claimed historically novel.

## Sources and load-bearing locations

1. [Pinned OA177 source](https://github.com/openai/math/tree/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Bounded-degree-coboundary-expanders-in-every-dimension-September-24-2026/build/source): `sections/geometry.tex`, Lemma `lem:patterns`, Proposition `prop:L-acyclic`; `sections/homology.tex`, Lemmas `lem:projective-chains`, `lem:stabilization`, `lem:trivial-action`, Proposition `prop:quotient-homology`; `sections/expansion.tex`, KMS recognition and weight comparison. The released theorem is weighted F2 coboundary expansion with bounded *vertex* incidence, not only bounded codimension-one incidence.
2. [Oppenheim--Valentiner-Branth, arXiv 2504.05823v2](https://arxiv.org/html/2504.05823v2): Theorem 1.1 gives coefficient-independent link expansion; Corollary 6.10 supplies the integral opposition cone used in the geometric filtration; Theorem 1.2 gives cosystolic expansion, including nontrivial cosystole bounds, for KMS skeleta. Local spectral parameter is 2/sqrt(p), after its hypotheses are met.
3. [Iwasa, published Homology pro stability for Tor-unital pro rings](https://doi.org/10.4310/HHA.2020.v22.n1.a20): Theorem 5.13 gives integral pro-epimorphisms at a>=2j+r-2 and pro-isomorphisms at a>=2j+r-1, r=max(2,sup stable-range). The arXiv version has the same range in Theorem 0.3/4.12. Do not confuse integral pro stability with a finite-level result; the transfer step is necessary.
4. [Morrow, arXiv 1404.4179v2](https://arxiv.org/abs/1404.4179v2): Theorem 0.3, powers of an ideal in a commutative Noetherian ring are pro Tor-unital.
5. [Dikstein--Dinur, APPROX/RANDOM 2024](https://drops.dagstuhl.de/storage/00lipics/lipics-vol317-approx-random2024/LIPIcs.APPROX-RANDOM.2024.62/LIPIcs.APPROX-RANDOM.2024.62.pdf): Theorem 2 (and Theorem 8) gives coefficient-independent cocycle expansion from links; Proposition 9 gives coefficient-independent nontrivial cosystole bounds. This removes a possible ambiguity in the placement of Abelian-group quantifiers in OVB's local-to-global statement.
6. [Evra--Kaufman--Zemor, arXiv 2004.07935](https://arxiv.org/abs/2004.07935): Sections 1--2 and the distance-balancing construction already use unbalanced logarithmic-systole/linear-cosystole codes. Three-dimensional Ramanujan complexes give a stronger log-squared systole ingredient for their application.
7. [Kaufman--Tessler, arXiv 2008.09495](https://arxiv.org/abs/2008.09495): collective cosystolic expansion and tensoring are additional hypotheses/mechanisms, not consequences of ordinary coboundary expansion.
8. Astra `cards/P-graph.txt` was freshly fetched and saved as `astra_P_graph.txt`. It preserves a conditional distance-rejection extension of OA178 with girth c log V, and explicitly retains the underlying source validation debt. It provides no CSS homology or commutation mechanism.
9. [Oppenheim--Valentiner-Branth, arXiv 2510.18351v1](https://arxiv.org/html/2510.18351v1), Theorem 1.1, already provides degree-one coboundary expansion for arbitrary coefficient groups without an order-p element, using irreducible-polynomial KMS quotients. This includes Z, so existence of dimension-two integer coboundary expanders is already a prior-art consequence. Our p-power quotient family and exact higher-degree coefficient phase are the refined conclusions here.

## Exact generalized theorem

Fix d>=2. Put N=2d and n=N-1. Choose a sufficiently large fixed odd prime p satisfying the affine type-A KMS spectral/link-expansion hypotheses and p>=2^(n-1). Let R=Fp[t], and let U be the inverse image of the upper unitriangular subgroup of SL_N(Fp) under evaluation at t=0. For each affine simple generator x_i, omit it to form H_i. Define

    Gamma_a(m) = ker(SL_a(R) -> SL_a(R/(t^m))),
    G_m = U/Gamma_N(m),
    T_m = CC(G_m; images of H_0,...,H_(N-1)),
    X_m = d-skeleton(T_m),       m>=2.

There are constants D, epsilon>0, depending on d and p alone, such that every vertex belongs to at most D d-faces and, for EVERY Abelian group A for which p:A->A is bijective, every m>=2, every 0<=i<d, and every A-valued oriented cochain f,

    ||delta_i f||_(X_m,i+1) >= epsilon dist_(X_m,i)(f,B^i(X_m;A)).

Norms are the normalized chamber-incidence support norms; orientations and signed coboundaries are necessary away from characteristic two. Degree-zero B^0 consists of constants. The family and epsilon are independent of A, m, i, and f. Any finite Abelian group of order coprime to p qualifies, as do arbitrary Q-vector spaces and Z[1/p]-modules. This theorem does not assert integer-coefficient expansion or characteristic-p expansion.

## Proof of coefficient extension and smaller rank

Let S=Z[1/p]. First repeat the source's opposition-complex filtration over S, with oriented chains. The input is an integral cone, so every required spherical opposition attachment is acyclic over S. The relative chain identification is the shifted augmented chain complex of the opposition factor; signs can be absorbed in the shifted differential. Exhaustion by the contractible affine building gives reduced H_j(L;S)=0 for j<n-1, where L=CC(U;(H_i)). In fact the same geometric reasoning works integrally and over Fp.

Every nonempty U-simplex stabilizer is a finite p-group. Its order is a unit in S, so averaging splits the augmentation of its S-group algebra. Thus its induced permutation module is projective over S[U]. The augmented chain complex of L supplies a partial projective resolution. Its U-orbit complex is one n-simplex, whence H_j(U;S)=0 for 0<j<n-1.

The action of Gamma_N(m) on L is free on nonempty simplices because its reduction is injective on each local group. The preserved intersection identities identify its orbit complex with T_m. The same partial resolution therefore identifies H_j(T_m;S) with H_j(Gamma_N(m);S) in the relevant range. This use of free stabilizers does not require p invertible and later also applies over Fp.

For A_m=t^m Fp[t], source's explicit relative row argument gives stable range at most two. Morrow makes the ideal-power system pro Tor-unital. Iwasa's *pro-epimorphism* range gives pro-zero cokernels of

    H_j(Gamma_a(m);Z) -> H_j(Gamma_(a+1)(m);Z),   a>=2j.

Localization is flat, and therefore localization of these cokernels is the cokernel of the localized homology map. It remains pro-zero. Each deeper congruence subgroup has p-power index in a shallower one. The transfer/inclusion composite is multiplication by that index; multiply transfer by its inverse in S to obtain a right inverse to inclusion. Thus all transition maps on homology over S are surjective, and so are transition maps on stabilization cokernels. A pro-zero system with surjective transitions has each term zero. Consequently the stabilization map is surjective *at every level*, already when a>=2j.

For j<=d-1, N-2=2(d-1)>=2j. Two successive stabilization maps represent every homology class in H_j(Gamma_N(m);S) on any specified N-2 coordinates. An elementary matrix supported on the two complementary coordinates centralizes that congruence subgroup, so it acts trivially on the whole homology group. Elementary matrices generate SL_N(Fp[t]), hence ambient conjugation acts trivially.

G_m is a finite p-group. Its averaging functor is exact over S, and the homology coinvariant identity gives

    H_j(U;S) = H_j(Gamma_N(m);S)_(G_m).

The action is trivial, and the left side is zero. Therefore H_j(T_m;S)=0 for 1<=j<=d-1. Here d-1<n-1=2d-2, including d=2. Connectivity provides reduced H_0=0.

Since X_m is finite, its oriented chain modules over the localized PID S are finite free. Universal coefficients, or splitting its exact low-degree chain sequences over S, gives reduced H^i(X_m;A)=0 for every S-module A and i<d. Being an S-module is exactly bijectivity of multiplication by p on A.

For quantitative expansion, the proper links have integral cone-radius bounds and hence coefficient-independent support-expansion constants beta>0. DD's Theorem 2 applies in degrees i>0 since ambient n>=i+2. With local spectral parameter lambda small enough, its bound

    beta^(i+1)/(4(i+2)!) - e lambda

is uniformly positive for i<d. This gives distance-to-cocycles inequalities. All constants are independent of the Abelian group. For an arbitrary group A rather than a finitely generated one, take the finitely generated subgroup generated by the finite collection of values in f. Applying the inequality there yields at least as strong a distance bound, because enlarging coefficients can only reduce distance to cocycles.

Degree zero can be handled separately. If masses of the distinct labels of f are a_r under the uniform stationary vertex measure, the spectral gap gives edge disagreement at least

    (1-lambda) sum_r a_r(1-a_r) >= (1-lambda)(1-max_r a_r),

and the last factor is distance to a constant cochain. This avoids misusing DD's positive-degree theorem at degree zero.

Finally, source's skeleton-weight comparison uses a common normalization factor in successive degrees and bounded chamber multiplicities. Its cancellation gives epsilon at least eta/M, M=p^binom(N,2), for a common eta>0. Cohomology vanishing replaces cocycles by coboundaries. This completes the generalized theorem subject to the stated source inputs.

## The exceptional coefficient cannot be removed

The same geometric filtration over Fp gives H_1(L;Fp)=0. Because the Gamma_N(m) action has free stabilizers, H_1(T_m;Fp)=H_1(Gamma_N(m);Fp). The d-skeleton preserves this group for d>=2.

Reduction from SL_N(Fp[t]) onto SL_N(Fp[t]/(t^(2m))) is surjective: the target is generated by elementary matrices over the local ring, and those matrices lift polynomially. Therefore reduction maps Gamma_N(m) onto the kernel of the level-2m to level-m reduction. Every member of that kernel is I+t^m A modulo t^(2m). Multiplication adds A because t^(2m)=0; the determinant-one condition is trace(A)=0. Consequently

    Gamma_N(m)/Gamma_N(2m) = sl_N(Fp) tensor (t^m R/t^(2m)R)
                           = additive Fp^(m(N^2-1)).

This is an abelian quotient, so

    dim_Fp H^1(X_m;Fp) >= m(N^2-1).

In particular characteristic-p coboundary expansion fails already in degree one. This is an explicit family-wide failure, not an absent proof. The localized homology result also means integral H_j(X_m;Z) is finite p-primary torsion in degrees 1,...,d-1: the groups are finitely generated and vanish after localization. In degree one its cardinality is at least p^(m(N^2-1)). Removing this p-torsion while keeping the expansion/local incidence structure is the remaining obstacle to any integer-coefficient upgrade.

### Split retraction and higher nonzero homology

Fix a rectangular off-diagonal block with r rows and N-r columns, the row and column sets disjoint, r=floor(N/2). Write s=r(N-r)=floor(N^2/4). Projection of the additive level-m/level-2m quotient onto this block is a homomorphism

    pi : Gamma_N(m) -> Fp^(s m).

Its section sends the coefficient vector to I+F, where F is supported in that block and its entries are polynomials using only powers t^m,...,t^(2m-1). All products of two matrices supported in this block are zero; hence (I+F)(I+F')=I+F+F' as actual polynomial matrices. Their determinant is one, and pi of this section is the original vector. This is an honest group retraction, with a finite elementary-Abelian image Q_m, not only a quotient that might destroy higher homology.

It follows that H_j(Q_m;Fp) is a direct summand of H_j(Gamma_N(m);Fp). The geometric partial-resolution comparison works over Fp because the congruence action is free, even though the U-stabilizers are not projective in that characteristic. For every 1<=j<d,

    dim_Fp H_j(X_m;Fp) >= binom(s m+j-1,j) = Omega_(d,p)((log V)^j).

The binomial formula is the Kunneth coefficient of (1-x)^(-s m): a cyclic p-group has one-dimensional mod-p homology in every nonnegative degree. Over Z, the same split retraction certifies nonzero p-primary H_j in every positive degree, since rank(Q_m)>=2 and integral homology of an elementary-Abelian p-group of rank at least two is nonzero in every positive degree. The comparison to X_m is valid for j<d.

### Exact coefficient classification

For any Abelian group A, the integral universal-coefficient sequence is

    0 -> Ext(H_(i-1)(X_m;Z),A) -> H^i(X_m;A)
      -> Hom(H_i(X_m;Z),A) -> 0.

All positive low-degree integral homology groups are nonzero finite p-groups. In degree one, H_0 is free, so H^1 vanishes exactly when A[p]=0. For every 2<=i<d, the Hom term vanishes exactly when A[p]=0 and the Ext term vanishes exactly when pA=A. Therefore H^i vanishes exactly when multiplication by p is bijective in each such degree.

Combining these exact vanishing criteria with the same uniform cocycle-expansion inequality gives:

* d=2: full below-top coboundary expansion holds over A if and only if multiplication by p is injective. In particular the family is simultaneously a Z-coboundary expander and an expander over every p-torsion-free Abelian group, with the same epsilon.
* d>=3: full below-top coboundary expansion holds over A if and only if multiplication by p is bijective.
* For every d>=2, first-degree integer coboundary expansion holds. For d>=3, second-degree integer coboundary expansion fails because Ext(H_1,Z) is a nonzero finite p-group.

The dimension-two integer result and this precise coefficient phase are internally derived consequences, with external-priority uncertainty retained.

The dimension-two existence conclusion is already covered by OVB's non-Abelian KMS theorem just cited; it must not be presented as a new solution of that existence problem.

## Matching logarithmic homological distance at characteristic p

Write V=|X_m(0)|. A path of length l in T_m's graph can be lifted starting at a chosen tagged coset by choosing a common representative for each edge. Each step multiplies a representative by an element of one H_i; all entries in that element have polynomial degree at most one. The final representative g_l therefore has degree at most l.

If the path closes modulo t^m, its final tagged coset agrees with its starting one, so the reduction of g_l equals the reduction of some h in the starting H_i. For l<m and m>=2, both matrices have degree below m. Equality after reduction implies equality before reduction. Thus the lifted path closes in L. Its Fp cycle bounds a finite two-chain there, whose projection supplies a filling in X_m. Any one-cycle with fewer than m supported edges decomposes into simple circuits in its support, each shorter than m. All of them fill. Hence

    sys_1(X_m;Fp) >= m.

The graph has uniform vertex measure and a fixed spectral gap. Its diameter is O(log V)=O(m). A breadth-first spanning tree gives a graph-cycle basis whose circuits have length at most twice the diameter plus one. Since H_1(X_m;Fp) is nonzero, at least one of those basis circuits is not a two-boundary. Thus

    sys_1(X_m;Fp) = Theta(m) = Theta(log V).

The same lifting idea gives a general positive-degree estimate. A j-cycle supported on s simplices has a support complex with at most s vertices. To see this stronger vertex bound, the link of the cycle at each support vertex is a nonzero reduced (j-1)-cycle. Every such link has at least j+1 supported faces, by the elementary minimum-face argument for simplicial cycles (in reduced dimension zero, at least two vertices are needed). Counting vertex/face incidences yields (j+1)s>=(j+1)|V(support)|. Every fundamental circuit of a spanning forest of its support graph is simple and has length at most s. If s<m, each such circuit closes upstairs by the degree argument, so its edge monodromy is trivial. Local subgroup-intersection preservation ensures unique lifting of an incident simplex once a vertex lift is chosen. The entire support complex therefore lifts coherently to L. In degrees 1<=j<d, H_j(L;Fp)=0, so the lifted cycle fills; projecting its filling gives a (j+1)-chain in X_m. Consequently

    sys_j(X_m;Fp) >= m,       1<=j<d.

This establishes logarithmic lower distance in all these degrees, but does not establish (log V)^j distance for j>1 or a matching higher-degree upper bound. The elementary-Abelian retraction supplies nonzero homology in all the same degrees, and OVB supplies linear cohomological distance. Thus degree-j canonical p-qudit CSS codes have O(V) qudits, k>=binom(m floor(N^2/4)+j-1,j), homological distance Omega(log V), and cohomological distance Omega(V). Higher k does not turn the logarithmic-distance bound into a good-code theorem.

OVB's nontrivial cosystole lower bound applies also over Fp. The panel weights on the (n-1)-skeleton agree with T_m weights, and its degree-one cochain spaces and cocycle/coboundary maps agree with X_m. A fixed maximum number of chambers through an edge converts the normalized support bound into

    cosys_1(X_m;Fp) >= c V.

Canonical CSS p-qudit codes on edges therefore have O(V) physical qudits, bounded check weights/degrees, k>=m(N^2-1), homological distance Theta(log V), and cohomological distance Omega(V). This is an internally derived variant of an existing unbalanced-code pattern. Conventional distance balancing would at best recover the older square-root times square-root-log scale from this degree-one ingredient; no new rate/distance frontier follows. This last comparison does not silently invoke a binary theorem as a proved p-ary theorem.

## Top-dimensional and graph-composition failures

In the released F2 construction, all reduced cohomology below d vanishes, so canonical middle-degree CSS codes encode zero logical qubits. In top degree, choose any (d+1)-simplex in the ambient T_m. Its boundary is a nonzero d-cycle in X_m with d+2 faces, and no (d+1)-boundaries exist in X_m. Every nonzero simplicial d-cycle has at least d+2 supported faces: take a supported d-face; each of its d+1 codimension-one faces needs a distinct other supported d-face for boundary cancellation, and any other d-face shares at most one such facet. Therefore sys_d=d+2 exactly. A singleton d-cochain pairing nontrivially with this cycle gives dual logical distance one.

For the ordinary cellular product with a connected graph G of v vertices and finite girth g, the independent chain audit proves:

| Degree | Nonzero homology | Homological distance | Cohomological distance |
|---|---|---|---|
| 1 | H_1(G) | g | |X_m(0)| |
| d | H_d(X_m) | d+2 | v |
| d+1 | H_d(X_m) tensor H_1(G) | (d+2)g | 1 |

All intermediate degrees 2,...,d-1 vanish. These are direct product statements over F2; they do not cover arbitrary twisted or balanced products. A logarithmic-girth OA178 graph therefore yields only logarithmic homological distance at degree one or top degree, and cannot produce good quantum codes by this composition. Joins with growing factors also violate bounded vertex incidence.

## Exact size, addressability, and charged costs

The polynomial reduction onto every finite local quotient is onto; the kernel of SL_N(R/(t^r))->SL_N(R/(t^(r-1))) has order p^(N^2-1). Thus

    |G_m| = p^(binom(N,2)+(m-1)(N^2-1)),
    V = N p^((m-1)(N^2-1)),
    |H_i| = M = p^binom(N,2),
    D <= M binom(N-1,d).

For original OA177's d=3,N=7,m=2, even its weakest explicit geometric requirement forces p>=37, hence V>=7*37^48>10^76. Actual quantitative KMS requirements increase this. The reduced-rank construction N=6 still gives V>=6*17^35>10^43 under its weakest explicit geometric requirement. These output lower bounds prevent an actual full construction on this machine.

Conditional on an admissible fixed p, an asymptotic strongly explicit incidence algorithm is nevertheless derivable. Precompute, for each type i, a right-coset representative table for G_2/H_i. This is a finite constant depending on d,p and is charged. For m>2, K_2=Gamma_N(2)/Gamma_N(m) intersects H_i trivially, so every type-i coset has a unique representative k r where r is one of the fixed lifted level-two representatives and k belongs to K_2.

K_2 has a unique local-ring LDU decomposition: strict lower and upper entries and the first N-1 diagonal entries have arbitrary coefficients of t^2,...,t^(m-1), the last diagonal entry is determined by determinant one. These give (m-2)(N^2-1) field digits, so addressing is dense and has O(m) bits for fixed d,p. To re-canonicalize a computed coset, inspect its reduction modulo t^2, recover the fixed r and h in H_i from the precomputed table, and compute k=g h^(-1) r^(-1). Matrix arithmetic and ring inversion take polynomial time in m. Incident faces are indexed similarly by cosets of fixed intersection subgroups, and finitely many local group elements enumerate the entire incidence neighborhood.

This is poly(log V) per incidence query with a huge fixed table and degree constant, and polynomial output time for the full complex. OA177 itself does not provide a numerically acquired admissible p or the table. An existential uniform construction should not be described as a demonstrated feasible implementation.

## Failure ledger and strongest next obstacle

* F2 canonical code: zero middle logical space, constant top systole, top dual distance one. Fully resolved obstruction.
* OA178 ordinary product: exact distances above block good-code gain. Logarithmic girth is not a higher-dimensional relation cutoff or collective cosystolic expansion certificate.
* All coefficients including Fp: explicitly refuted by m(N^2-1) dimensional first-cohomology quotient.
* Integer coefficients: first-degree expansion holds, and full expansion holds for d=2. For d>=3, degree-two expansion fails from nontrivial Ext(H_1,Z). A surgery killing the p-primary integral homology must also control newly created higher homology, bounded incidence, and filling constants. A Smith-normal-form correction supplies no local or bounded-cost surgery.
* Characteristic-p quantum codes: logarithmic systoles and linear cosystoles are positive consequences, but that unbalanced pattern and its balancing applications have stronger established comparators. No new globally good quantum LDPC code follows.
* Higher systolic gain: a split elementary-Abelian subgroup now certifies nonzero H_j(Fp), with dimension Omega((log V)^j), in every 1<=j<d. Support-complex lifting proves an Omega(log V) systole in every such degree, with matching Theta(log V) in degree one. It does not prove log^j bounds in higher degrees. Such a bound, together with controlled collective cosystolic behavior, is the remaining load-bearing ingredient for an improved coding composition.
* Construction: admissible smallest instances and local tables exceed available resources; no executable full adjacency evidence was obtained.

Best surviving research representation is the localized-coefficient theorem with its sharp exceptional characteristic and matching logarithmic one-systole. The most consequential next attack is a controlled p-torsion removal or a genuinely higher-dimensional characteristic-p systolic lower bound; neither was completed here.

## Why the known higher-systole proof does not automatically transfer

EKZ Theorem 5.11 (PDF p.24, printed p.23) obtains a power of the injectivity radius by passing through apartment retraction and Euclidean minimal-chain volume monotonicity. The local model there is the whole Bruhat--Tits building. Here it is the opposition subcomplex L. An apartment retraction of the ambient building need not preserve L, and a replacement/filling allowed in the ambient building need not be an allowed boundary in L. Consequently a cycle minimal modulo L-boundaries has not been shown to remain area-minimal under the ambient retraction. OVB's local integral cone radii concern finite spherical links and prove acyclicity/link expansion; they do not give this radial volume comparison in the infinite opposition complex.

There is an exact obstruction to replacing this gap by a generic complete-CAT(0) argument. The rectangular subgroup Q_m is finite and nontrivial, lies in Gamma_N(m), and acts freely on all nonempty simplices of L. A finite group acting by isometries on a complete CAT(0) space has a fixed point, the circumcenter of any finite orbit ([Bridson--Haefliger, II.2.8](https://egg.epfl.ch/metriques/Bridson-Haefliger.pdf)). In a type-preserving simplicial action, fixing a point forces stabilization of its unique minimal carrier simplex and then fixes that simplex vertexwise. This contradicts the free Gamma action. Thus L cannot be a closed convex invariant subcomplex of the affine CAT(0) building, nor can it carry a complete CAT(0) metric making this action isometric. This does not refute a (log V)^j systolic estimate by a different argument; it identifies why the standard convex/CAT(0) route cannot simply be imported.

The precise next lemma would be an opposition-complex local minimal-chain growth theorem: every support-minimal nontrivial j-cycle in a congruence quotient, viewed in an injectively lifted opposition ball of radius R=Theta(m), has at least c R^j supported j-faces. A controlled chain retraction or filling staying inside L could imply it. Neither such a retraction nor such a volume inequality has been proved here. Higher-degree k has only the stated lower bound; its asymptotic upper behavior and actual smaller CSS distance in those degrees remain unknown.
