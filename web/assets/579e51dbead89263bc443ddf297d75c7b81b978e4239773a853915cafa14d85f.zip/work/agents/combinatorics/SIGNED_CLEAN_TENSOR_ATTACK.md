# A different sunflower representation: the exact signed clean tensor

Status: exact identities and a failed transfer, not a constant-base theorem. This is the second representation attacked after the balanced-shadow density obstruction.

## The new ingredient and the prior obstruction

The release's discrete-convexity proof uses a signed product measure supported on arrays whose row unions cover an exceptional set. Pointwise vanishing then produces a sum of even powers of *one* set of Fourier coefficients; Parseval gives a dimension-independent total-weight budget. The high powers feed a covering lemma. Source: `convexity/sections/02_weights.tex`, equations `eq:global-weight-bound`, `eq:signed-identity`, and `eq:exceptional-weight-bound`.

The prior sunflower barrier was not the availability of a valid rank identity. It was bounding the actual word-derived rank uniformly over arbitrary coordinate alphabets and shared-label occurrences. The October 4 closure explicitly retained this gap. The signed-kernel mechanism suggested testing whether positive higher powers could replace that missing bound.

## Exact clean tensor

For a finite alphabet Q, define

T_Q(x,y,z)=1 if x=y=z;
T_Q(x,y,z)=−1/2 if x,y,z are pairwise distinct;
T_Q(x,y,z)=0 otherwise.

The following equality holds pointwise:

T_Q(x,y,z)=(1/2)(δ_xy+δ_xz+δ_yz−1).

For a word code C⊂∏_{i=1}^k Q_i, use the product tensor T=⊗_i T_{Q_i}. If C is clean-triple-free, then the restriction of T to C×C×C is the diagonal tensor: T(x,x,x)=1 and every other entry is zero. Three distinct words would contribute only if they formed a clean triple. If exactly two words agree, a coordinate where the third differs has the forbidden equality pattern and gives zero. Therefore

slice-rank(T|_{C³})=|C|.

This is an exact alphabet-free *representation*, but an alphabet-free upper bound on its restricted rank is still needed.

Expanding each coordinate's four terms gives 4^k partition terms. Each term uses disjoint coordinate sets I_xy, I_xz, I_yz and I_0. It has the form

constant · δ_{x|I_xy,y|I_xy} δ_{x|I_xz,z|I_xz} δ_{y|I_yz,z|I_yz}.

Slicing according to x's projection, or y's or z's, bounds that term by the smallest of the three actual projection cardinalities

min{ |π_{I_xy∪I_xz}(C)|,
     |π_{I_xy∪I_yz}(C)|,
     |π_{I_xz∪I_yz}(C)| }.

At least one of these three coordinate sets has size at most 2k/3. Consequently an entirely valid bound is

|C|≤sum over the 4^k partitions of the displayed minimum.

Replacing these actual projection sizes by a universal constant to the number of coordinates is precisely an unsupported alphabet-independent structural step. Arbitrary alphabets prevent that replacement. Replacing them by products of alphabet cardinalities recovers the usual alphabet-dependent slice estimate.

## Where the signed-Fourier composition loses uniformity

Take a q-element alphabet, q≥3, and equip R^Q with the counting inner product. Use e_0=q^(−1/2)·1 and an orthonormal basis e_1,…,e_{q−1} of the zero-sum subspace. The coordinates of T_Q in this basis are exactly:

T_000=√q(3−q)/2;
T_ab0=T_a0b=T_0ab=(√q/2)δ_ab for a,b≥1;
all coefficients with exactly one nonconstant index or three nonconstant indices vanish.

Proof: the pointwise four-term identity above makes the three-centered contraction zero. Summing over z gives

sum_z T_Q(x,y,z)=(q/2)δ_xy−(q−2)/2,

which gives the two-centered coefficient. Summing over all three indices gives the constant coefficient.

The flattening Gram matrix TTᵀ has diagonal

A=1+(q−1)(q−2)/4

and off-diagonal

B=(q−2)(q−3)/4.

Its eigenvalues are q/2 with multiplicity q−1 and q(q²−5q+8)/4 on constants. Thus neither the literal coefficient magnitudes nor the nonconstant multiplicity is bounded independently of q. Tensor powers retain this growing effective dimension.

The discrete-convexity source has a Bernoulli Boolean basis and a pointwise *zero* product on every array in the signed support. Here the product on C³ equals the diagonal rather than zero. Even after isolating that term, the available orthogonal norm budget depends on q and the projections. The source's dimension-independent Parseval bound cannot simply be copied with the same smallness parameter.

This diagnoses the first unsupported transfer. It does not prove that no signed-kernel argument can solve sunflower, nor that a more refined restriction inequality is impossible.

## The exact remaining attack

A successful argument would need an alphabet-independent bound on the restricted clean tensor that uses the actual occurrence structure, or a weighted decomposition in which the large projection dimensions are charged to disjoint portions of |C|. This is closely related to the prior actual generic fibre-packing problem; the release supplies simultaneous reconstruction of one witness, but not a theorem bounding all word-derived projection dimensions.

There is no new generic rank-fraction theorem here. The independent worker is separately attacking a genuinely narrower linear-coset subclass, where clean-freeness is an incidence condition on 2-dimensional F2 subspaces and may impose additional structure absent from arbitrary alphabets.

## Prior-art scope

The clean signed tensor and diagonal restriction are standard sunflower/slice-rank representations; no priority claim is made for them. Naslund–Sawin, *Upper bounds for sunflower-free sets*, [arXiv:1606.09575](https://arxiv.org/abs/1606.09575), Theorem 2 and the proof on pp. 8–9, use the character version of this exact mechanism and obtain c_q=(3/2^(2/3))(q−1)^(2/3). The primary [published paper](https://doi.org/10.1017/fms.2017.12) and [full PDF](https://www.cambridge.org/core/services/aop-cambridge-core/content/view/ED7A0DE48541FA919651E4533393CDD8/S2050509417000123a.pdf/upper_bounds_for_sunflowerfree_sets.pdf) were checked in this run. The result of this attack is an exact interface audit of the released signed-product mechanism against the actual open rank bottleneck, not a new slice-rank sunflower bound.

Release source pinned at adc7f1241b42e322a6451854ab7e4b4c146bf78a: https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Talagrands-discrete-convexity-conjecture-September-23-2026/build/source/sections/02_weights.tex

Reopened prior closure: `/Users/harjas/Documents/ChatGPT/Sunflower solve/GLOBAL_CLOSURE_2026-10-04/RESULT.md`, `sandwich_packing.md`, and `private_exchange.md`.
