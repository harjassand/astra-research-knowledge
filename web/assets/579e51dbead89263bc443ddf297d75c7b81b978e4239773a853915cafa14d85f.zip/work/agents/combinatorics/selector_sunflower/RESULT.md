# OA175 selector versus sunflower-safe balanced shadows

Status: exact negative mechanism results; no constant-base sunflower theorem was proved. The changed premise is useful and genuine: OA175 chooses the **same** edge at every nested scale, under an arbitrary fixed assignment of edge-supported probability weights. None of the failures below disputes that premise.

## Sources and exposure

The source used is `work/agents/combinatorics/expectation/sections/selector.tex`, Theorem `thm:multiscale-selector`, from [Integral and fractional expectation thresholds are equivalent](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Integral-and-fractional-expectation-thresholds-are-equivalent-September-23-2026/paper.pdf). The pinned release commit is `adc7f1241b42e322a6451854ab7e4b4c146bf78a`.

The prior balanced-shadow interface was read in `/Users/harjas/Documents/Codex/2026-07-15/current-task-statement-a-set-family/SUNFLOWER_PROGRESS_HANDOFF.md`, Sections 2.1--2.5. The latest global closure was read in `/Users/harjas/Documents/ChatGPT/Sunflower solve/GLOBAL_CLOSURE_2026-10-04/{RESULT,private_exchange,FAILURE_INPUT}.md`. These remain unproved at WNC, actual free-skew packing, and the some-root partite outside-certificate bound. The all-root certificate variant is false.

The product lower example is standard; it is stated and proved in [Lovett--Ostuni's PCMI notes](https://www.ias.edu/sites/default/files/Sunflowers%20Lecture%20Notes_1.pdf), Claim 1.4. The new calculations here concern its exact relation to the supplied selector and the balanced child interface. They are elementary proofs, not finite numerical extrapolations or priority claims.

## Exact premise

If a family F of nonempty sets is not p-small, every preassigned probability weight lambda_H supported on H obeys the following. For legal s with

    p sum_(i=1)^s 256^i <= 1/2,

independent vertex colors have probabilities pi_i=256^i p, and with probability at least .9 there is one H satisfying

    lambda_H(A_i) >= 1-2^(-i) for every i,
    sum_x a(x) lambda_H(x) <= 2.

The fixed order of quantifiers is essential: the weights are chosen before the coloring. The theorem gives one member, with no lower bound on the original weighted mass of all such members, and no assertion that their shortened children are sunflower-free.

## A source-compatible early-shadow obstruction

Let q=1024, r=q+1=1025, and X=[k] x [q]. Let F be all q^k transversals H_w={(j,w_j):j in [k]}. Every r-sunflower in F would have all equal letters in every coordinate, because r distinct letters are impossible; its members would therefore be identical. Thus F is r-sunflower-free.

Its exact minimum p-cover cost is min{1,(qp)^k}. Indeed the uniform parent law gives probability q^(-|S|) to any useful subset S; a cover therefore has sum_S q^(-|S|)>=1. If qp<=1, its p-cost is at least (qp)^k, attained by the complete-edge cover. If qp>=1, the cost is at least 1, attained by the empty-set cover. In particular F is not p-small for p=1/q.

Choose s=1. This is legal, and A_1 includes every physical vertex with probability 1/4. Let k be divisible by four, let m=k/2, and define the entire early balanced shadow

    B(a) = {B subset A_1(a): |B|=m and B subset H for some H in F}.

**Proposition.** If k>=r/32, then

    Pr{B(a) contains an r-sunflower} >= 1-exp(-k/48)-exp(-8k).

**Proof.** Split the coordinate blocks into an initial 3k/4 blocks and the final k/4 blocks. An initial block has an early vertex with probability

    alpha=1-(3/4)^1024 > 8/9.

The number Z of such initial blocks is binomial with mean at least 2k/3. The standard lower-tail bound gives

    Pr{Z<k/2} <= exp(-(E Z-k/2)^2/(2 E Z)) <= exp(-k/48).

When Z>=k/2, choose a compatible set C of m-1 early vertices, one in each of m-1 distinct initial blocks. The final k/4 blocks contain W~Bin(qk/4,1/4) early vertices, with mean 64k. For k>=r/32, r<=32k=(E W)/2, and therefore

    Pr{W<r} <= exp(-(E W)/8)=exp(-8k).

If W>=r, choose distinct vertices x_1,...,x_r from those final blocks. Every C union {x_i} is an m-subset of a transversal, hence belongs to B(a). Their pairwise intersections are exactly C and their singleton petals are distinct. They form an exact r-sunflower. The two failure estimates and a union bound prove the claim. QED.

Thus the natural strengthening "all available captured balanced children are safe" fails with probability tending to one, while every premise of the selector holds. On the simultaneous event where the selector succeeds and this sunflower exists, the probability is at least

    .9-exp(-k/48)-exp(-8k).

This is a failure of a proposed projection rule, not a sunflower counterexample. Keeping one fixed set of m coordinate blocks gives a safe projection of every parent onto only q^m children, preserving all parent mass; the correct balanced neighborhood cost on this product is 1.

## Parent mass and mean-color obstructions

The independent child report `obstruction/selector_parent_mass_obstruction.md` gives full proofs of two complementary failures, audited here.

1. For the preceding q=1024 family and uniform lambda_H, a captured parent must have at least k/2 first-color vertices. Under the uniform parent law the expected total captured-parent mass M is at most

       E M <= Pr{Bin(k,1/4)>=k/2} <= (sqrt(3)/2)^k.

   At the same time Pr{M>0}>=.9. Hence

       Pr{0<M<=(sqrt(3)/2)^(k/2)} >= .9-(sqrt(3)/2)^(k/2).

   This rules out quasipolynomial weighted capture if one simply retains the good original parents. More generally the same cardinality-tail upper bound applies to any assigned weights whose first-scale capture condition always certifies at least k/2 selected physical vertices.

2. The s=1 average-color statement is tautological, so the child also tested the average-color conclusion itself with s=2, q=4*256^2, r=q+1, and p=1/q. Its color probabilities are (1,256,767)/1024. Uniform parent mass N of words with average color at most two satisfies

       E N <= ((256+2 sqrt(767))/1024)^k.

   This base is approximately .3040913376, while the selector still guarantees Pr{N>0}>=.9. Thus mean color alone does not supply parent-mass retention either.

The examples use large fixed r so that the product meets the selector's small-p budget. They do not refute a separate theorem assuming a sufficiently larger spread parameter C_r, nor do they refute a some-root or hypothetical high-cardinality-base argument for r=3.

## Full containment has the wrong scale

With uniform lambda_H, simultaneous capture only gives |H minus A_i|<=k*2^(-i). For exact containment from this inequality alone one needs 2^(-s)k<1, hence s>log_2 k. The source's color budget then imposes

    p <= 1/(2*256^s) < 1/(2 k^8).

It therefore cannot yield constant-density containment simply by exhausting the residual mass. The exact product calculation is stronger: for any legal fixed q,s, t_s=sum_(i=1)^s pi_i<=1/2, and

    Pr{some complete parent lies in A_s} = [1-(1-t_s)^q]^k -> 0.

Consequently, for any fixed weights, selector success without a contained edge has probability at least .9-[1-(1-t_s)^q]^k.

## An adaptive-weight shortcut is invalid

For a fixed coloring a, the assertion "for every assignment lambda_H some H is simultaneously captured" is equivalent to "some H is contained in A_1(a)." If there is no contained H, assign lambda_H to a point of H outside A_1, and every H fails the first-scale test. Such an assignment depends on the realized coloring and is not a legal preassigned input. Therefore the selector's for-all-fixed-weights statement cannot be used after choosing an obstruction weight from the realized child conflicts.

## Attempted substantive composition and first missing inference

I tested two direct compositions.

* Uniform/diffuse weights produce balanced partial members. Full containment costs p=O(k^-8); keeping the eligible original parents loses exponentially much weight; taking all eligible children produces exact sunflowers. These failures occur before a useful balanced recurrence can be written.
* Weights chosen from the blockers of a putative safe child support would better target the desired exchange. However these blockers depend on the realized projection/coloring, so assigning the weight afterwards swaps the source quantifiers. Preassigning blockers requires an additional theorem controlling the weighted cost of their future repair. The source selector supplies no such price-response statement.

The surviving smaller gate is therefore a **fixed-before-coloring, collision-aware weighted extraction/repair lemma**: a random palette must yield an r-free support of m-children whose upward neighborhood contains at least exp(-polylog(k)) parent weight, with any alteration/deletion price charged. It may merge many parents into one child. The early-shadow and parent-mass obstructions show exactly why both the support repair and mass transport are necessary. Merely giving that gate a new name would restate WNC; no proof of the gate is claimed here.

Failure ledger: full containment from a constant number of scales, refuted; quasipolynomial retention of captured original parents, refuted; automatic safety of the early balanced shadow, refuted; post-coloring assignment of lambda, invalid; adaptive weighted safe extraction, unresolved; constant-base sunflower conjecture, unresolved.
