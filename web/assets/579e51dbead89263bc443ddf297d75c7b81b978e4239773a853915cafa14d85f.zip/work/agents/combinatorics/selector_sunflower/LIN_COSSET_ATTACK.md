# A constant-base bound for the binary linear-coset subclass

Status: proved, with a self-contained rank argument. This closes the dimension bound for the specified subclass and gives a legal quadratic outside certificate. It does not prove the general Sunflower Conjecture or a linear bound for the number of original-kernel nonzero cosets needed in a private certificate. No novelty claim is made; the key cover inequality is classical.

## Exact interface and result

Let V=F_2^n. Let K_1,...,K_k be linear subspaces with intersection {0}. Encode every v in V by

    w(v)=(v+K_1,...,v+K_k).

The cosets in different coordinates are different physical symbols. Intersection zero makes the word map injective. A three-word tuple w(x),w(y),w(z) can be translated to w(0),w(a),w(b), with distinct a,b nonzero. Its nonzero differences are a,b,a+b, spanning a two-dimensional U. In coordinate i, the three symbols are all equal, have a two-plus-one pattern, or are all distinct according as dim(U intersect K_i) equals 2, 1, or 0. Hence the full code is clean-3-free exactly when

    every two-dimensional U <= V has some i with dim(U intersect K_i)=1.  (LC)

**Theorem.** If k>=1, intersection K_i={0}, and (LC) holds, then

    n <= 2k-1,
    |{w(v):v in V}| = 2^n <= 4^k/2.

The same bound holds for the k-uniform partite set family associated with these words. Any affine translate of the code has the same property and size. The case n=0 is immediate. The proof below continues to the zero-dimensional residual and charges all used coordinates, so there is no uncharged final dimension.

## The supplied new selector and the materially different representation

The OA175 selector was read exactly in `work/agents/combinatorics/expectation/sections/selector.tex`, Theorem `thm:multiscale-selector`. Its same-member multiscale premise did not supply safe weighted shadow capture; the exact obstructions are in `RESULT.md` and `obstruction/selector_parent_mass_obstruction.md`.

This attack instead uses the translation-invariant linear-coset model from `/Users/harjas/Documents/ChatGPT/Sunflower solve/GLOBAL_CLOSURE_2026-10-04/private_exchange.md`, Section 3. It converts clean-freeness into a paired affine cover and applies a rank bound to an irredundant subcover. The selector is not invoked in the final proof.

The exact classical source is A.E. Brouwer, **An inequality in binary vector spaces**, Discrete Mathematics 59 (1986), 315--317, [primary PDF](https://ir.cwi.nl/pub/2507/2507D.pdf). The theorem on p.315 applies to irredundant **affine** covers and gives

    m >= dim V - dim(V intersect intersection U_i) + 1.

I read all three pages and checked this quantifier; it is stronger than only a statement about hyperplane covers. The independent worker supplied the direct rank proof below, which I checked in full. It avoids dependence on any withdrawn theorem.

An initially tempting source, Nagy--Pach--Tomon arXiv:2205.03389, is **withdrawn**. Its [primary arXiv page](https://arxiv.org/abs/2205.03389), v2 dated 31 October 2022, identifies a mistake in Claim 4.5 invalidating most of the paper. Its claimed general abelian exponential-index theorem is not used here. The verified Brouwer theorem suffices in the binary setting.

## Independent representatives: a linear Hall lemma

For finite vector sets S_1,...,S_m in a vector space over a field, one can choose independent representatives s_i in S_i if and only if

    dim span(union_(i in J) S_i) >= |J| for every J subset [m].  (R)

Necessity is immediate. Here is the induction proving sufficiency. The m=1 case is immediate. If some nonempty proper J has span dimension |J|, choose independent representatives in J by induction. In the quotient by their common span, every set of remaining indices L has rank at least |L|, because (R) for J union L gives rank at least |J|+|L|. Induction in the quotient supplies the remaining representatives.

Otherwise every nonempty proper J has rank at least |J|+1. Choose any nonzero representative from S_m and quotient by its span. Every nonempty J subset [m-1] loses at most one rank and still satisfies (R). Induction supplies the other representatives modulo the chosen vector; together they are independent. This proves the lemma without importing a matroid theorem.

## Direct affine-cover rank bound

**Lemma.** If a finite-dimensional vector space E over F_2 is irredundantly covered by m affine subspaces a_i+U_i, then

    codim_E(intersection_i U_i) <= m-1.  (B)

First remove empty terms. If a single full-space term occurs, irredundancy forces m=1 and the inequality is immediate. Otherwise each affine subspace is the common zero set of affine equations

    ell(x)=c_ell, ell in S_i,

where the coefficient vectors S_i span U_i's annihilator. Empty or redundant scalar equations can be removed. Its complement is the clause

    C_i(x) = OR_(ell in S_i) [ell(x) != c_ell].

The cover is exactly the assertion that the conjunction of all clauses is unsatisfiable. Irredundancy says this is minimally unsatisfiable: deleting any clause makes it satisfiable. A constant false literal may be removed. A constant true literal cannot occur in a minimally unsatisfiable formula with more than one clause. An empty clause alone is the already handled m=1 full-space cover.

Put L_I=span(union_(i in I) S_i), and r(I)=dim L_I. If independent representatives existed for all m clauses, their forms could simultaneously be prescribed values different from their forbidden constants, giving a satisfying assignment. Thus there is no independent transversal. The linear Hall lemma gives some I with positive deficiency |I|-r(I)>0.

Choose I maximizing this deficiency over all index subsets. For any J disjoint from I,

    r(I union J)-r(I) >= |J|,

since otherwise I union J would have larger deficiency. The images of the remaining literal sets in the quotient E^*/L_I therefore satisfy (R). Select independent literal representatives modulo L_I, one for every outside clause.

If I were proper, minimal unsatisfiability would give an assignment x_0 satisfying all clauses in I. The selected outside representatives are independent modulo L_I, so their restrictions to the annihilator L_I^perp are independent. The map from L_I^perp to their simultaneous scalar evaluations is surjective. Consequently one can choose h in L_I^perp so that each selected outside literal is true at x_0+h. Every literal in an I-clause retains its value, because h annihilates L_I. Thus x_0+h satisfies every clause, a contradiction.

It follows that I contains all m clauses. Its positive deficiency says

    rank span(S_1 union ... union S_m) <= m-1.

This rank is exactly codim_E(intersection_i U_i), proving (B). The argument actually gives this weak dimension bound over any field; only the binary version is needed below. It does not supply the uniform-in-prime exponential index bound asserted in the withdrawn abelian paper.

## Clean-freeness supplies a paired cover

Let W be any nonzero residual subspace of V. Retain only coordinates for which L_i=W intersect K_i is proper in W; coordinates containing W have rank-zero restriction on every two-dimensional U<=W and can be discarded. The remaining restrictions still satisfy (LC), and their total intersection is {0}.

Let

    T = W minus union_i L_i.

**Lemma.** T is sum-free: there are no a,b in T with a+b in T.

If a=b then a+b=0 is not in T. Otherwise a,b,a+b are distinct nonzero points and span a two-dimensional U. All three avoid every L_i, so every intersection U intersect L_i is zero. That contradicts (LC). The one-dimensional W case also satisfies the assertion, since its possible T is a singleton. QED.

If T is empty, the subspaces L_i cover W. Select an irredundant subcover using a nonempty set J of s distinct coordinate indices. By (B), for W'=intersection_(i in J) L_i,

    dim W - dim W' <= s-1 <= 2s-1.  (D0)

If T is nonempty, choose v in T. Then

    W = union_i [L_i union (v+L_i)].  (P)

Indeed any x outside all L_i belongs to T. It cannot also have x+v in T, since x,v,x+v would violate sum-freeness (and if x=v then x+v=0 lies in every L_i). Thus x+v lies in some L_i, proving (P). These cosets are all proper; v is in none of the L_i.

Select an irredundant subcover of (P). Let J be its set of distinct coordinate indices, of size s. It contains at most 2s cosets. Its direction intersection is exactly

    W'=intersection_(i in J) L_i.

Applying (B) gives

    dim W - dim W' <= 2s-1.  (D1)

It is not necessary to assume that the subcover selects both cosets for each used coordinate. The count 2s remains valid for every subcover.

In both cases W' is a strict subspace of W: all L_i used are proper, and at least one is used. On W', every used coordinate kernel contains W', so it can never witness a one-dimensional intersection with a two-dimensional U<=W'. Hence the unused coordinates retain (LC). The total intersection of their restrictions is still {0}, since intersecting them with W' is the same as intersecting all original kernels with W'.

## Charged recursion and consequence

Begin with W_0=V. While W_j is nonzero, discard coordinates containing W_j and apply the preceding construction. Let s_j be the number of coordinate indices used in its chosen irredundant cover. Set W_(j+1) to their common restricted kernel and remove those used coordinates.

Every step strictly reduces dimension and removes s_j>=1 previously unused coordinates. Thus the recursion terminates at W_b={0}, all batches are disjoint in their coordinate indices, and

    sum_(j=0)^(b-1) s_j <= k,
    n = sum_j (dim W_j-dim W_(j+1))
      <= sum_j (2s_j-1)
      <= 2k-b <= 2k-1.

This proves the theorem. There is no factor log k: a batch that costs up to twice its coordinate count in dimension is charged once, and those coordinates are permanently removed. The clean-free condition on every two-dimensional residual is what justifies this removal.

The theorem is an existence bound. Finding v, a complete cover, or an irredundant subcover may use exhaustive enumeration of W; no polynomial running-time or cheap acquisition claim is asserted. Once an explicit sequence of batches is given, kernel intersections and dimension charges can be checked by Gaussian elimination, and coverage/irredundancy can be checked by finite enumeration or an exact solver.

## What remains and which inference is forbidden

The code is a full injective binary linear-coset image. Arbitrary clean-free word families need not have a group law, kernel symbols, or a line spanning each translated triple. None of the proof transfers to them without acquiring such a representation. In particular the resulting 4^k bound does not close WNC, SP_free, or the unrestricted conjecture.

The dimension bound also does not automatically give an O(k) outside certificate using the **original** K_i cosets. The paired cover includes the linear cosets L_i, all containing zero; they cannot be used in an outside certificate for w(0). Replacing them by enlarged hyperplane cosets changes the legal symbol family. A basis of V^* supplies n nonzero hyperplane cosets covering V minus {0}, but those hyperplanes need not be any K_i. Inferring a legal original-kernel certificate from that cover is the first invalid step of that stronger route.

## A legal quadratic outside certificate

The independent worker also supplied the following integral construction, checked here. Let b(k) be the largest minimum number of nonzero original-kernel cosets covering V minus {0}, among this subclass with k coordinates. Translation symmetry makes the private-certificate number identical at every root.

Use either the linear cover when T is empty or the paired cover when T is nonempty. Extract an irredundant subcover of at most 2k pieces and select any piece A=a+K_j with private point a (renaming its translation vector is legitimate because a lies in that coset). Every other selected piece avoids a, and together those other pieces cover V minus A. There are at most 2k-1 such legal original-kernel cosets.

Within A, identify x with a+x for x in K_j. The other k-1 kernels restrict to K_i intersect K_j. Their common intersection is zero and (LC) holds, because K_j itself has rank-zero restriction on every two-dimensional subspace of K_j. By induction they provide at most b(k-1) nonzero restricted cosets covering K_j minus {0}. A restricted coset x+(K_i intersect K_j), x in K_j minus K_i, lifts to the ambient original coset a+x+K_i. It still avoids a and covers its required restricted coset. Enlarging it outside A only helps coverage.

Thus the legal certificate recurrence is

    b(k) <= 2k-1+b(k-1), b(0)=0,
    b(k) <= sum_(j=1)^k (2j-1)=k^2.

This covers all points except a, and translation by a transports it to a nonzero-coset cover for zero. It therefore gives an all-root bound within this translation-invariant model. It does not invoke enlarged hyperplanes, fractional coefficients, or an uncharged cover. It remains quadratic, so it does not establish the linear certificate conjecture.

Actual outcome: n<=2k-1 and constant base 4 for this binary linear-coset subclass, proved; legal original-kernel outside certificate b<=k^2, proved. Legal O(k) original-kernel nonzero-coset cover: not proved here. General sunflower conjecture: not proved here.
