# Selector success can retain exponentially little parent mass

Status: exact elementary obstruction, conditional only in its invocation of the supplied OA175 selector estimate. This does not refute a constant-base sunflower conjecture; it refutes a specific route that keeps only selector-good original parents while hoping for a dimension-independent amount of their original mass.

Source premise: `work/agents/combinatorics/expectation/sections/selector.tex`, Theorem `thm:multiscale-selector`. It gives, for each fixed assignment of probability measures lambda_H supported on H, probability at least 9/10 of the existence of one H with simultaneous capture. The release manuscript is [Integral and fractional expectation thresholds are equivalent](https://github.com/openai/math/blob/main/preprints/Integral-and-fractional-expectation-thresholds-are-equivalent-September-23-2026/paper.pdf). The repository snapshot recorded in `work/repository/01_CORE.txt` is `adc7f1241b42e322a6451854ab7e4b4c146bf78a`. The proofs below concern the explicit family and need no claim about release novelty or global proof certification.

## Exact product family and smallness calculation

Let X=[k] x [q], and let F consist of the q^k transversals

    H_w = {(j,w_j): 1 <= j <= k},  w in [q]^k.

Let r=q+1. The family F has no r distinct members forming a sunflower. At each coordinate, an r-sunflower must use either one common letter or r pairwise distinct letters. The latter is impossible because q=r-1. Consequently all coordinates must be common, making all r words identical.

Put the uniform parent law z(H_w)=q^(-k). For any G that is contained in at least one transversal, G uses distinct coordinates and

    z{H: G subset H} = q^(-|G|).

For any covering family Gcal, summing these probabilities gives

    sum_(G in Gcal) q^(-|G|) >= 1.

All useful cover elements have |G|<=k. If qp<=1, then

    p^|G| = (qp)^|G| q^(-|G|) >= (qp)^k q^(-|G|),

so any p-cover costs at least (qp)^k. The cover by all complete edges attains that cost. If qp>=1, every cover costs at least 1, attained by the single empty set. Therefore the exact minimum p-cover cost is

    min{1, (qp)^k}.

In particular F is not p-small at p=1/q. This is an integral calculation, not a fractional relaxation. The uniform parent law also witnesses q-spreadness.

## First-scale parent-mass obstruction

Fix q>=513, r=q+1, and p=1/q. Take any s>=1 allowed by

    (1/q) sum_(i=1)^s 256^i <= 1/2.

For every H, use its uniform edge measure lambda_H(v)=1/k for v in H. Let B(a) be the subfamily satisfying all simultaneous capture conditions and let

    M(a) = sum_(H in B(a)) z(H).

The first capture condition requires |H intersect A_1(a)|>=k/2. Under the independent random coloring, a fixed parent's first-color count is Bin(k,t), where t=256/q<1/2. Thus

    E M <= Pr{Bin(k,t)>=ceil(k/2)} <= [4t(1-t)]^(k/2).

For completeness, exponential Markov with theta=ln((1-t)/t)>0 gives

    Pr{B>=k/2} <= exp(-theta k/2)(1-t+t exp(theta))^k
                  = [2 sqrt(t(1-t))]^k.

Define beta=2 sqrt(t(1-t))<1. For every eta>0,

    Pr{M>beta^k/eta} <= eta.

The selector says Pr{M>0}>=9/10. Combining these bounds gives

    Pr{0<M<=beta^k/eta} >= 9/10-eta.

In particular, eta=beta^(k/2) gives

    Pr{0<M<=beta^(k/2)} >= 9/10-beta^(k/2).

The concrete choice q=1024, r=1025, p=1/1024, s=1 is legal and has t=1/4, beta=sqrt(3)/2. Hence

    E M <= (sqrt(3)/2)^k,
    Pr{0<M<=(sqrt(3)/2)^(k/2)} >= .9-(sqrt(3)/2)^(k/2).

At k=100, the expectation bound is approximately 5.6632e-7. The OA175 existence guarantee can therefore coexist with exponentially tiny total mass of all eligible original parents. The same bound applies to any selected subcollection supported only on good parents, before arbitrary mass amplification or reassignment. Recovering total mass 1 by renormalizing such parents incurs an exponential factor in k on the displayed event.

This disproves every proposed lower bound M>=c>0 independent of k, and more generally every uniformly guaranteed subexponential lower bound exp(-o(k)), within this interface. No collision condition needs to be dropped to obtain the counterexample: the original family already is r-sunflower-free.

## The average-color conclusion alone has the same barrier

For s=1 the conclusion average-color<=2 is tautological, since the only colors are 1 and 2. To avoid relying on the stronger capture condition, choose instead

    q=4*256^2=262144,  r=q+1,  p=1/q,  s=2.

The three color probabilities are

    (pi_1,pi_2,pi_3) = (1,256,767)/1024.

They are legal, since pi_1+pi_2=257/1024<1/2. Let N(a) be the uniform parent mass of words satisfying the average-color conclusion, with the same uniform edge weights. A fixed word's average color is at most 2 precisely when its counts obey N_1>=N_3. Applying exponential Markov to the sum of a(v)-2, and choosing theta=(1/2)ln(pi_3/pi_1), gives

    E N <= (pi_2+2 sqrt(pi_1 pi_3))^k
         = [(256+2 sqrt(767))/1024]^k.

The base is approximately 0.3040913376. The selector guarantees Pr{N>0}>=.9, while Markov gives, for b=(256+2 sqrt(767))/1024,

    Pr{0<N<=b^(k/2)} >= .9-b^(k/2).

Thus the actual average-color conclusion can leave exponentially tiny original parent mass, even after all simultaneous-capture constraints are removed.

## Full containment and the quantifier order

Let t_s=sum_(i=1)^s pi_i<=1/2. For the same product family, a complete word is contained in A_s if and only if every coordinate contains an available letter. Its probability is exactly

    Pr{some H subset A_s} = [1-(1-t_s)^q]^k.

For fixed q and s this tends to zero with k. For any preassigned lambda_H (not necessarily uniform), the supplied selector therefore implies

    Pr{selector succeeds and no H subset A_s}
      >= .9-[1-(1-t_s)^q]^k.

This shows that changing the fixed edge weights cannot rescue a direct selector-to-full-containment bridge at spread q=r-1.

There is also an exact quantifier obstruction, for every fixed coloring a with s>=1:

    [for every assignment (lambda_H), some H satisfies simultaneous capture]
      iff [some H subset A_1(a)].

The reverse implication is immediate. For the forward implication's contrapositive, if no H lies in A_1, pick for each H a vertex x_H outside A_1 and set lambda_H=delta_(x_H). Every edge then fails the first capture inequality. Such weights depend on the realized coloring and are not legal inputs to the selector theorem. Therefore one cannot swap

    for every fixed lambda, probability_a(exists H good)>=.9

with

    probability_a(for every lambda, exists H good)>=.9.

Deterministically, even a single H's capture does not force containment when k>=2^s: choose a coordinate j to which H assigns mass at most 1/k, color that entire coordinate s+1, and all other vertices 1. No complete word lies in A_s; H nevertheless satisfies every capture condition. Its average color is at most 1+s/k.

## Necessary next premise and limits

The product has spread r-1, so it does not refute a theorem restricted to spread at least C*r with a sufficiently large universal C. Establishing that every such uniformly spread family contains an r-sunflower is a reformulation strong enough to recover the constant-base sunflower bound. Precisely, suppose every nonempty t-uniform kappa-spread family contains an r-sunflower whenever kappa>C*r, for every t>=1. If a k-uniform family F has |F|>kappa^k, choose S of largest cardinality with |F(S)|>=|F|*kappa^(-|S|). S cannot be a complete edge, because then |F(S)|<=1<|F|*kappa^(-k). Its nonempty link is (k-|S|)-uniform, and maximality gives, for every nonempty T disjoint from S,

    |F(S union T)|/|F(S)| < kappa^(-|T|).

Thus the link is kappa-spread. Any sunflower in the link lifts by adjoining S, so an r-sunflower-free original family violates the proposed large-spread premise. Conversely, a bound |F|<kappa^t for every r-sunflower-free t-uniform family rules out a kappa-spread probability law on such a family, since every edge has mass at most kappa^(-t) and the support therefore has at least kappa^t edges. With the harmless strict inequalities or a constant enlargement, this is exactly the constant-base sunflower problem. The selector theorem does not provide this missing structural statement.

The meaningful repair must create collision-safe partial words, transport/reassign mass with an explicitly charged distortion, or use a new structural inequality above the r-1 spread boundary. Merely applying the selector to original parents and retaining the good ones cannot guarantee dimension-independent mass. Projection can preserve total pushforward mass 1 while changing the support objects, so the parent-retention obstruction does not automatically apply to a correctly defined projection interface.

Failure ledger:

1. Uniformly positive mass of selector-good original parents: disproved exponentially.
2. Uniformly positive mass of average-color-good original parents: disproved exponentially with s=2.
3. Good capture implies full containment: disproved deterministically and with probability approaching .9 on a sunflower-free product.
4. Post-coloring adaptive lambda assignment invokes OA175: invalid quantifier swap.
5. Constant-base sunflower bound: unresolved here; none of these counterexamples disproves it.
