# A linear Tarsi lemma and a binary clean-three bound

Status: proved by the direct linear-algebra argument below. The binary affine-cover inequality is old: A. E. Brouwer, *An inequality in binary vector spaces*, Discrete Mathematics 59 (1986), 315–317, [primary-source scan](https://ir.cwi.nl/pub/2507/2507D.pdf), theorem on p. 315, proof on pp. 315–316. Its theorem explicitly permits affine cosets, despite the shorter abstract mentioning linear subspaces. The direct proof here also works over any field. No use is made of the withdrawn arXiv:2205.03389 claim.

The consequence for the binary coset model is

    n <= 2k-1  for n>=1,
    |F|=2^n <= 2^(2k-1).

This is a constant-base bound for that translation-invariant linear model, not an unrestricted sunflower result. Whether its stronger bound n<=k always holds is not established here.

## 1. Linear Hall lemma, with proof

Let E_1,...,E_m be finite sets of vectors in a vector space. There exist vectors e_i in E_i which are linearly independent if and only if

    dim span(union_(i in I) E_i) >= |I|

for every I subset [m]. Necessity is immediate. For sufficiency, induct on m. The case m=1 is immediate.

If a nonempty proper I has equality, first find an independent transversal of the E_i for i in I by induction. It is a basis of L=span(union_(i in I) E_i). The images of the remaining sets in the quotient by L obey the same condition: for J disjoint from I their span has dimension

    dim span(E_I union E_J) - dim L >= |I|+|J|-|I| = |J|.

Induction in the quotient finds the remaining transversal; together they are independent.

If no nonempty proper I has equality, all such I have rank at least |I|+1. Pick a nonzero e_m in E_m and quotient by its span. Every nonempty subset I of [m-1] loses at most one dimension, hence still has rank at least |I|. Induction finds an independent transversal in the quotient, which lifts to one independent together with e_m. This proves the lemma.

## 2. Linear Tarsi theorem

Let Q be a finite-dimensional vector space over a field. Consider clauses C_1,...,C_m, where each clause is the disjunction of finitely many conditions

    alpha(x)+b != 0,

with alpha a linear functional on Q. Suppose the conjunction of the clauses is minimally unsatisfiable: it has no satisfying assignment, but deleting any clause makes it satisfiable. Let L be the span of all coefficient functionals alpha occurring in the clauses. Then

    dim L <= m-1.

Proof. A nonzero constant literal makes a clause tautological, which cannot occur in a minimally unsatisfiable formula. Zero constant literals can be removed. An empty clause forces m=1 by minimality, giving the assertion immediately. Hence assume all remaining literal sets are nonempty and have nonzero coefficient vectors.

For I subset [m], write L_I for the span of coefficients in those clauses and define the deficiency

    d(I)=|I|-dim L_I.

If every d(I)<=0, the linear Hall lemma chooses one coefficient alpha_i from every clause with the alpha_i independent. The affine equations alpha_i(x)+b_i=1 then have a simultaneous solution, satisfying every clause. Unsatisfiability therefore gives a set I with d(I)>0.

Choose I maximizing d(I). For any J subset [m]\I, maximality implies

    |I|+|J|-dim L_(I union J) <= |I|-dim L_I,

and therefore

    dim(L_(I union J)/L_I) >= |J|.

Apply the linear Hall lemma to the outside clauses' coefficient sets in the quotient Q*/L_I. It selects one coefficient alpha_j per outside clause whose residue classes modulo L_I are independent.

If I were proper, minimal unsatisfiability would give an assignment x_0 satisfying every clause in I. (Delete any one outside clause, then restrict its satisfying assignment to I.) Change x_0 by a vector u in the annihilator L_I^perp. This preserves all literals in I. Independence of the selected outside coefficient classes means the restrictions alpha_j|_(L_I^perp) are independent, so their joint evaluation map is onto. Thus choose u so that

    alpha_j(x_0+u)+b_j=1

for every outside clause j. This satisfies all clauses, a contradiction. Consequently I=[m], and d(I)>0 gives dim L<=m-1. End of proof.

This argument does not assume ordinary literals correspond to independent coordinate variables. Linear dependencies and repeated affine forms are handled by the rank and annihilator calculations.

## 3. Irredundant affine subspace covers

Let a_1+H_1,...,a_m+H_m irredundantly cover a finite-dimensional vector space Q. Then

    codim_Q(intersection_(i=1)^m H_i) <= m-1.

Indeed, choose for each H_i a basis of its annihilator. Membership in a_i+H_i is the conjunction alpha(x)-alpha(a_i)=0 over that basis. Its negation is one clause of the kind in Section 2. An irredundant cover becomes a minimally unsatisfiable conjunction of those clauses. The span of all their coefficient vectors is exactly the annihilator of the common direction intersection. Apply the theorem.

The inequality is sharp: in dimension d over F_2, use the d hyperplanes x_i=0 and the singleton {(1,...,1)}. They irredundantly cover, their directions have common intersection zero, and there are d+1 pieces.

The version relative to a linear subspace W also follows by intersecting every coset with W and translating within W whenever the intersection is nonempty. Consequently an irredundant cover of W by affine cosets with direction spaces W intersect H_i gives

    dim W - dim(W intersect intersection_i H_i) <= m-1.

## 4. Binary clean-three model and the paired cover

Let V=F_2^n and let K_1,...,K_k be subspaces with common intersection zero. Encode v by the coset word

    w(v)=(v+K_1,...,v+K_k).

Assume every two-dimensional U<=V has some i with dim(U intersect K_i)=1. This is exactly the absence of three distinct clean words: translating their first vector to zero identifies their remaining pair with the three nonzero points of U.

For every linear subspace W<=V, the same clean-three condition holds for the restricted kernels K_i intersect W. Define

    T_W = W \ union_i(K_i intersect W).

T_W is sum-free in the binary additive sense: it contains no a,b,a+b with a,b distinct. If all three were in T_W, the two-dimensional span of a,b would have zero intersection with every restricted kernel, violating the hypothesis.

If T_W is nonempty, fix v in T_W. The paired cosets

    K_i intersect W,   v+(K_i intersect W)   (1<=i<=k)

cover W. A point already in a restricted kernel is covered by its zero coset. For x in T_W, if x=v then x+v=0 lies in a restricted kernel; otherwise sum-freeness says x+v is outside T_W and hence lies in one. In either case x lies in a shifted coset.

If T_W is empty, the zero cosets already cover W.

## 5. Amortized recursive bound n<=2k-1

Keep a current subspace W and a set R of unused kernel indices. Maintain that every consumed kernel contains W and that

    W intersect intersection_(i in R) K_i = {0}.

Initially W=V and R=[k]. The clean-three condition on W can only be witnessed by unused indices: a consumed kernel contains every U<=W, so its intersection dimension is 2.

If W is nonzero, build the zero-coset cover or the paired cover from Section 4 using only R. Take an irredundant subcover consisting of m pieces and let I subset R be the distinct kernel indices used. Every index contributes at most two pieces, so m<=2|I|. (If T_W is empty, the stronger m<=|I| holds.) Define

    W' = W intersect intersection_(i in I) K_i.

The affine-cover theorem gives

    dim W - dim W' <= m-1 <= 2|I|-1.

Consume I, replace W by W', and continue. The invariant survives. Whenever the dimension does not drop, at least one index is still consumed. Therefore this process terminates, and it can terminate only at W={0}, since the common-intersection invariant prevents a nonzero W with no unused indices.

The consumed sets I at different stages are disjoint and have total size at most k. If there are h>=1 stages, summing the dimension drops gives

    n <= sum_stages(2|I|-1) <= 2k-h <= 2k-1.

The proof also tolerates redundant or whole-space kernels; consuming them may have zero dimension drop but still decreases the unused set. For n=0 there is nothing to prove. Injectivity of the coset encoding now gives the advertised |F|<=2^(2k-1).

## 6. A separate quadratic private-certificate bound

The same paired covers give an explicit existence bound on the number b of nonzero coordinate cosets needed to cover V minus {0}:

    b <= k^2.

This does not require the dimension theorem. Here is an induction on k. If V={0}, no cosets are needed. Otherwise form the cover with at most 2k pieces from Section 4 and take an irredundant subcover C_1,...,C_m. Pick a private point a of C_j, meaning a lies in C_j and in no other piece. Write C_j=a+K_j; its original translate has this form because a is a point of the coset.

The other m-1 pieces avoid a and cover V outside C_j. Each is therefore a legal outside coordinate coset for root a. Inside C_j, translate by a and apply induction to K_j with the k-1 restricted kernels K_i intersect K_j, i!=j. Their common intersection is zero, and they inherit the clean-three condition since index j cannot witness a two-dimensional U<=K_j. Induction supplies at most (k-1)^2 restricted nonzero cosets covering K_j minus {0}.

Every such restricted coset is the intersection with K_j of an ambient K_i-coset. The ambient coset still avoids a after translation: if it contained a, its intersection with C_j would also contain a. Thus the restricted certificate lifts to a legal ambient certificate for the remaining part of C_j. Altogether root a has a certificate of size at most

    m-1+(k-1)^2 <= 2k-1+(k-1)^2 = k^2.

Translation invariance then moves this certificate to root zero, and to every other root. Whole-space kernels cause no problem: if one supplies a one-piece cover, the induction merely discards that redundant kernel.

This is an integral coset-cover construction. It still falls short of the requested linear private-certificate bound; the induction may reuse earlier coordinate types and therefore has quadratic rather than disjoint-index amortization.

## 7. Scope and failure ledger

1. Generalized linear Tarsi rank<=m-1: proved directly, with an old binary affine-cover source independently verifying the needed case.
2. Binary clean-three dimension n<=2k-1: proved using sum-freeness, paired coset covers, and disjoint-index amortization.
3. Stronger n<=k: not proved and not refuted here.
4. General abelian-group log-index bound uniform over groups: not asserted. The withdrawn Nagy–Pach–Tomon source is not a dependency.
5. Private certificate coset count b<=k^2: proved separately by private-point induction. A linear b<=Ck remains open here.
6. Unrestricted constant-base sunflower theorem: not asserted; the construction and theorem concern linear binary coset families.
