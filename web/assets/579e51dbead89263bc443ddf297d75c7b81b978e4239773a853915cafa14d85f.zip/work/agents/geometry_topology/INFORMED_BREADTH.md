# Independent audit: intrinsic approximate classicality

Status: candidate theorem independently checked at its algebraic interfaces; established external ingredients are identified below. No external certification or novelty claim. This second breadth pass was redirected by root to one higher-ceiling target, so no unrelated second target is proposed.

## Changed premise and ceiling

The run's bounded-score classicality proof supplied a dimension-free common pinching and commuting-approximation mechanism. Its adversary showed that commutators of a chosen score representation cannot characterize reconstruction. The new canonical positive likelihoods instead extract the geometry from the states themselves. Combining their polar stability with the common approximation mechanism yields an intrinsic criterion; combining that criterion with Raynaud's compatible noncommutative Lp ultraproduct theorem removes domination.

The resulting candidate concerns arbitrary experiments E_n on finite-dimensional H_n, with dimension and parameter set varying. Assume only that, for every epsilon>0, the trace-distance covering numbers of E_n are bounded uniformly in n. Define

    Delta(rho,sigma) = ||sqrt(rho)sqrt(sigma)||_1 - Tr sqrt(rho)sqrt(sigma),
    delta_n = sup_(rho,sigma in E_n) Delta(rho,sigma),
    e_n = inf_(measure-and-prepare Lambda) sup_(rho in E_n) T(Lambda rho,rho).

The emerging theorem is e_n -> 0 iff delta_n -> 0. At any fixed positive target error the classical output alphabet can be bounded independently of dim(H_n). This broadens a representation-specific sufficient condition to an experiment-level iff. It does not resolve a named longstanding conjecture, supply an efficient compiler, preserve purification, or establish priority.

Exact parent proofs: `../general_classicality/INVARIANT_CRITERION.md` and `../general_classicality/GENERAL_CRITERION.md`. Their source-specific hypotheses and acquisition costs must be retained in any final synthesis.

## 1. Necessity passes without regularity assumptions

For Lambda(rho)=sum_z p_z tau_z and Lambda(sigma)=sum_z q_z tau_z, the fidelity measurement inequality and affinity superadditivity give

    F(rho,sigma) <= sum_z sqrt(p_z q_z) <= A(Lambda rho,Lambda sigma).

Powers--Stormer and Cauchy--Schwarz imply

    Delta(rho,sigma)
      <= sqrt(||Lambda rho-rho||_1) + sqrt(||Lambda sigma-sigma||_1).

Therefore delta <= 2 sqrt(2 epsilon) for uniform trace-distance error epsilon, and e >= delta^2/8. Neither domination, covering numbers, dimension, nor a reference enters. This is an independent direct derivation, not an inference from exact no-broadcasting.

The exponent 1/2 in epsilon cannot improve: for two pure qubit states with overlap s -> 0, Delta=s-s^2. Helstrom discrimination followed by preparation of the guessed original state has symmetric trace-distance recovery error

    epsilon_s = sqrt(1-s^2) [1-sqrt(1-s^2)]/2 ~ s^2/4.

Thus Delta/sqrt(epsilon_s) -> 2. This does not establish the optimal constant in the universal inequality.

Detailed independent necessity proof, continuous-outcome qualification, and exact primary locators: `transport_sharp_bridge/CLASSICALITY_NECESSITY_AUDIT.md`.

## 2. The dominated polar bridge passes, including singular states

Suppose rho<=C omega, S=sqrt(omega), Q=sqrt(rho), M=sqrt(C). Restrict to supp(omega) and set

    X=S^(-1) (S rho S)^(1/2) S^(-1).

Operator monotonicity gives 0<=X<=M I; X omega X=rho and ||XS||_2=1. In SQ=WP, extend the polar partial isometry W to a unitary on supp(omega). Then XS=QW^*, and P=(Q omega Q)^(1/2)>=rho/M. With K=2I-W-W^*>=0,

    ||XS-Q||_2^2 = Tr rho K
                <= M Tr P K = 2M Delta(omega,rho).

Adjoints give ||[X,S]||_2<=2 sqrt(2M Delta). The singular polar extension leaves every displayed product valid; lower domination and ambient full rank are unnecessary.

The common pinching, normalization, weighted tracial approximation, and net transfer also check. Two details to make explicit are a<1 before dividing B_i by its weighted norm, and clipping positive-score rounding to [0,1] after scaling. Both hold in the intended asymptotic construction. Child independent audit: `convex_bridge_audit/CLASSICALITY_ADVERSARY.txt`; its checked findings were also sent directly to root and general_classicality.

## 3. Direct improvement: canonical pair commutators before pinching

This removes the extra fidelity-continuity loss from the dominated finite-family proof. The following elementary inequality is useful beyond this application:

    ||A sqrt(omega)||_2^2 <= ||A||_op ||A omega||_1                 (1)

for every square matrix A and state omega. Indeed, |A|^2<=||A||_op |A|, while the polar partial isometry U gives

    Tr omega |A| = Tr U^* A omega <= ||A omega||_1.

No normality, lower spectral bound, or centrality is required in (1).

Let rho_i<=C omega, let X_i be their canonical likelihoods, and assume every pair in the augmented family {omega,rho_i} has Delta<=delta. Put

    p=sqrt(2M delta),
    xi=max_i ||[X_i,S]||_2 <= 2p,
    b=2sqrt(2delta)+4p+2M xi.

The polar decomposition of Q_i Q_j gives

    ||[Q_i,Q_j]||_1 <= 2sqrt(2delta).                            (2)

To verify (2), write Q_iQ_j=UP. Then

    ||UP-P||_1
      <= ||(U-I)P^(1/2)||_2 ||P^(1/2)||_2
      = sqrt(2 Delta(rho_i,rho_j) F(rho_i,rho_j))
      <= sqrt(2delta),

and compare the adjoint with the same P.

The exact normalized amplitudes obey

    ||Q_iQ_j-X_i X_j omega||_1
      <= ||Q_iQ_j-X_i S X_j S||_1
         + ||X_i[S,X_j]S||_1
      <= 2p+M xi.

Subtract the reversed product and use (2):

    ||[X_i,X_j] omega||_1 <= b.

Since ||[X_i,X_j]||_op<=2M^2, inequality (1) yields

    kappa := max_i,j ||[X_i,X_j]S||_2
           <= sqrt(2M^2 b) = O_C(delta^(1/4)).                  (3)

Now perform the parent's common log-spectrum pinching at width t, producing S' and positive Y_i<=MI that commute with S'. Put D=max_i||(X_i-Y_i)S||_2 and eta=max_i||(X_i-Y_i)S'||_2<=e^t D. Because Y_i commutes with S',

    ||[X_i,S']||_2 <= 2eta.

Expanding the two score commutators gives

    ||[Y_i,Y_j]S'||_2 <= e^t kappa+8M eta.                     (4)

For example, use [Y_i,Y_j]=[X_i,X_j]-[D_i,X_j]-[Y_i,D_j], D_i=X_i-Y_i. The first defect is at most 6M eta after moving X_j past S'; the second is at most 2M eta. Also S'=S R with ||R||<=e^t, proving the first term in (4).

Normalize C_i=Y_i/||Y_iS'||_2. When the amplitude error h<=1/2, the normalizing factors are at least 1/2, so

    ||[C_i,C_j]S'||_2 <= 4(e^t kappa+8M eta).

With L=2M the simultaneous commuting-approximation input is therefore

    theta <= (e^t kappa+8M eta)/M^2.                           (5)

At t=delta^(1/6), the parent's pinching D=O_(C,K)(delta^(1/6)) gives theta=O_(C,K)(delta^(1/6)). The previous surrogate-affinity route gave only theta=O(delta^(1/24)). If the explicit tuple lemma has f_K(theta)<=C_K theta^(1/(2^K-1)), choosing quantization on the same scale yields a fixed-family reconstruction modulus

    O_(C,K)(delta^(1/[6(2^K-1)])),

instead of the previous delta^(1/[24(2^K-1)]) exponent. This is a direct improvement of this proof, not an optimality or priority claim. Both the universal inequality (1) and all weighted manipulations in (2)--(5) were independently checked by convex_bridge_audit.

An optional constant improvement follows directly from normalized canonical amplitudes: averaging the common log-spectrum shift gives E||(X_i-P_uX_i)S||_2^2<=3 xi/t because ||X_iS||_2=1. Thus D<=sqrt(3K xi/t), eliminating an unnecessary factor M from the parent's generic operator-norm pinching bound. It does not change the exponent.

## 4. Reference-free finite-mixture escalation: audited interface

The fixed-m lemma needed to remove domination is:

    max_j Delta(m^(-1)sum_i rho_i,rho_j) <= u_m(max_i,j Delta(rho_i,rho_j)),

where u_m(s)->0 as s->0, uniformly over Hilbert-space dimension. The proof provides no explicit/effective modulus; it does not assert convexity of Delta.

Raynaud's original source was loaded and its exact interfaces checked:

* Introduction p42 explicitly states that all results apply to ultraproducts of varying noncommutative Lp spaces.
* Theorem3.6 pp59--60 gives compatible linear isometries preserving positivity, conjugation, and the Mazur maps.
* Theorem5.1 p66 preserves products Lp x Lq -> Lr; here the essential case is L2 x L2 -> L1.
* Haagerup Lp is realized in the tau-measurable operator algebra of a semifinite crossed product, recalled pp57--58. The Groh--Raynaud algebra itself need not be semifinite.

For a contradictory sequence of fixed-m tuples, roots Q_(i,n) have L2 norm1. Their ultraproduct images a_i are positive L2 elements. Product and Hilbert-inner-product compatibility carry pair Delta->0 to

    ||a_i a_j||_1 = tr(a_i a_j).

Under L1(M)=M_*, equality of norm with the value at I characterizes positive normal functionals. Hence a_i a_j is positive and equals its adjoint a_j a_i.

The unbounded-operator issue is handled correctly only in the full measurable operator algebra. That algebra is associative and contains I. The bounded resolvents r_i=(I+a_i)^(-1) are two-sided inverses there. Algebraic commutation of a_i,a_j then gives r_i r_j=r_j r_i. Commuting bounded positive resolvents have commuting spectral projections, so a_i,a_j strongly commute. This is stronger than merely declaring equality of two formal unbounded products.

Consequently b=(m^(-1)sum_i a_i^2)^(1/2) has a common abelian measurable functional calculus with each a_j, and ba_j is positive. Compatible Mazur maps send the square roots of the finite means to b. Compatible product norms and L2 inner products send the offending mixture gaps to ||ba_j||_1-tr(ba_j)=0, a contradiction.

The outline passes these interfaces. It still depends on the established Raynaud theorem and on the standard measurable-operator realization; no finite numerical experiment certifies those dependencies. A mean of a fixed finite net then dominates each net member with C=m, so the audited dominated construction and a 2epsilon channel-contraction transfer complete the reference-free candidate theorem.

## 5. Primary prior-art audit and boundary

This is a bounded focused audit, not a novelty certificate. No source loaded in this pass states the full arbitrary-dimension, uniformly trace-total-bounded, pairwise-fidelity-affinity iff. The following precise precedents constrain what can be claimed:

| Primary source | Relevant exact content | Relation to the candidate |
| --- | --- | --- |
| Fuchs--Caves, *Mathematical Techniques for Quantum Communication Theory*, OSID3 (1995),345--356; quant-ph/9604001 | Eq7 minimizes measured Bhattacharyya coefficient; Eq19 is exactly the positive likelihood used here | Canonical X and its operational fidelity role are established prior art; credit directly |
| Barnum et al., quant-ph/9511010, PRL76 (1996),2818 | Exact no-broadcasting iff pair commutation; Eq5 fidelity measurement variational formula | Exact endpoint and necessity ingredient; not by itself a dimension-free stability converse |
| Lieb, original1973 author manuscript, Corollary1.1 | Joint concavity of Tr A^p K^* B^r K, p+r<=1 | At p=r=1/2 gives affinity superadditivity used in necessity; cite Cor1.1, not only same-variable Thm1 |
| Guță--Jenčová, quant-ph/0606213v2, CMP276 (2007),341--379 | Thm3.16 weak/LeCam equivalence for finite parameter sets, canonical states dominated by one fixed experiment, typeI discrete-center sufficient algebras | Its uniform domination is ACROSS canonical experiments, not the candidate's earlier within-experiment rho<=C omega. It does not directly prove the new criterion; full canonical-state convergence has more data than pair fidelities |
| Kuramochi,1710.01599, IJTP57 (2018) | Exact nondisturbing information is limited to the center of the minimal sufficient experiment; broadcasting application | Exact arbitrary-von-Neumann-algebra precedent; no matched dimension-free small-Delta theorem found |
| Lemm--Wilde,1608.07569v2, PRA96 (2017),012304 | Quantitative approximate simultaneous cloning/broadcasting restrictions via relative entropy and recovery | Quantitative precedent with different task/hypotheses; does not supply the stated pairwise gap sufficiency |
| Fuchs--Sasaki,quant-ph/0302092, QIC3 (2003),377--404 | Quantumness through worst-case transmission of a state alphabet through a classical channel; accessible fidelity | Operational measure-and-prepare framing is established. Candidate's novelty, if any, is its intrinsic asymptotic characterization under uniform metric entropy, not the notion of classical transmission |
| Muthuganesan--Chandrasekar,2104.09095, IJTP61 (2022) | Eq16 minimizes ensemble coherence over common bases/commuting approximants | Measures distance to a commuting ensemble; not the pairwise Delta or reconstruction iff found here |
| Nuradha--Mishra--Leditzky--Wilde,2404.16101v3, JPA58 (2025),165304 | Thm5.33 orders average pairwise Holevo, secrecy, SDP and Uhlmann fidelities; Prop5.4 gives continuity | Pairwise fidelity/affinity comparison and multivariate compactness ingredients have substantial prior art. No common EB-channel characterization found in loaded theorem |
| Raynaud,JOT48 (2002),41--68 | Thm3.6/5.1 compatible noncommutative Lp ultraproducts | The reference-removal compactness engine is established prior art. Composition does not establish historical novelty |

Primary URLs:

* https://arxiv.org/html/quant-ph/9604001v1 (Eq19)
* https://arxiv.org/html/quant-ph/9511010v1
* https://www.numdam.org/item/RCP25_1973__19__A4_0.pdf (Cor1.1, manuscriptp8/PDFp9)
* https://arxiv.org/html/quant-ph/0606213v2 (Thm3.16)
* https://arxiv.org/html/1710.01599v1
* https://arxiv.org/html/1608.07569v2
* https://arxiv.org/abs/quant-ph/0302092
* https://arxiv.org/html/2104.09095v1 (Eq16)
* https://arxiv.org/html/2404.16101v3 (Thm5.33)
* https://jot.theta.ro/jot/archive/2002-048-001/2002-048-001-003.pdf

Loaded HTML/text copies for the main external comparisons are in `invariant_prior/`. Raynaud's primary PDF/text is in `../general_classicality/sources/`. No exact matched theorem was identified after targeted searches for approximate broadcasting, statistical sufficiency/equivalence, fidelity-affinity or Bures-Hellinger gaps, quantumness of ensembles, and noncommutative ultraproducts. That search result must not be reported as proof of novelty.

## 6. Retained obstructions and limits

The reference-free candidate retains uniform metric entropy. The union of d+1 mutually unbiased bases in prime-power dimension d is a projective2-design with maximum pair gap d^(-1/2)-d^(-1)->0 but worst-case EB recovery error at least1-2/(d+1)->1. It therefore decisively rejects unrestricted pairwise-gap sufficiency. The candidate does not assume that an epsilon-net, the true family, a precise projective measurement, or conditional-state preparation is cheap to acquire.

No source in this audit justifies efficient acquisition, an explicit general finite-mixture rate, preservation of external entanglement, or a claim that this result resolves the KLS, transport endpoint, group, or PSPACE targets. The directly proved improvement is (1)--(5); the larger intrinsic theorem remains a candidate under its exact externally grounded interfaces and independent root review.
