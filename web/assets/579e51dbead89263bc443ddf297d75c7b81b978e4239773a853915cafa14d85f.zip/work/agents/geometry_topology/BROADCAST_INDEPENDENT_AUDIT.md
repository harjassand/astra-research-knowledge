# Independent final audit of the two-receiver criterion

Status: **the supplied candidate proof passes this independent algebraic/interface audit; no fatal gap found**. This is internal mathematical review, not external certification or priority clearance. The proof imports established Raynaud operator-space/noncommutative-Lp ultraproduct theorems. Its exact no-broadcasting mechanism is established prior art.

Audited source: `../general_classicality/BROADCAST_CRITERION.md`. Also read `../broadcast_prior_art/AUDIT.md`. The original Raynaud PDF/text was checked at Theorem1.1/Fact1.2, Proposition1.6, Theorem3.6, Theorem5.1 and Proposition5.2, rather than relying only on the author's proof description.

## Exact conclusion retained

Let one CPTP channel take either of two unknown input density matrices rho,sigma on H to two output systems H,H. Correlations between outputs are allowed. Let b2 be its best worst-case marginal trace-distance error, where the worst case includes both input labels and both receivers. The candidate proves a universal dimension-independent qualitative modulus

    Delta(rho,sigma) <= v(b2(rho,sigma)),
    Delta(rho,sigma)=||sqrt(rho)sqrt(sigma)||_1-Tr sqrt(rho)sqrt(sigma),
    v(epsilon)->0 as epsilon->0.

No trace-covering hypothesis is needed for this pair converse. Under uniform trace-distance covering numbers for experiments E_n, combining it with the earlier intrinsic reconstruction candidate makes the following equivalent: vanishing pairwise gaps; one common entanglement-breaking reconstruction channel; one common two-receiver broadcaster; and common broadcasters for every prescribed finite receiver-count sequence with marginal error uniform in receiver count.

The result concerns unknown-state-independent channels and marginal density matrices. It supplies no independent output copies, joint closeness to rho^tensorK, efficient synthesis, preservation of a purification, or effective approximation modulus.

## 1. The normal channel limit is justified by the precise operator-space theorem

Raynaud's original paper establishes the following needed facts:

* On p44, the represented coordinate C*-ultraproduct is a unital injective *-subalgebra of the operators on the Hilbert-space ultraproduct. Its weak-operator closure is the Groh--Raynaud von Neumann algebra A.
* Theorem1.1/Fact1.2 pp44--45 identify the Banach ultraproduct of all predual functionals with A_* and give the pairing `lim_U phi_n(x_n)` on coordinate operator sequences. The coordinate algebra is ultraweakly dense.
* Proposition1.6 p46 identifies the positive cones. The introduction p42 explicitly extends all paper results to varying-algebra ultraproducts.
* Proposition5.2 p67 states that the compatible Lp identifications are complete isometries for every p>=1, including p=1. Its proof explicitly treats fixed finite matrix amplifications via Id_k tensor Lambda_p. The p=1 map is the predual identification from Section1.

The coordinate CPTP Schrödinger maps are completely contractive for the natural predual operator-space structures. Their Banach ultraproduct therefore remains completely contractive, and the above complete isometries transport it to B_*:M_*->N_*. Its adjoint Phi:N->M is normal and completely contractive. Exact preservation of the value of every normal functional at the unit, checked through the coordinate pairing, gives Phi(I_N)=I_M.

There is no missing matrix-cone assumption here: a unital completely contractive map is completely positive. At each fixed matrix level, compose the unital contraction with any state on the target matrix algebra. The resulting functional has norm at most1 and value1 at the unit, hence norm1 and positivity. States separate the positive cone, so every amplification is positive. This supplies Schwarz and multiplicative-domain statements used later.

The use of **all bounded predual sequences**, not merely the two experimental states, is necessary. It provides a map on the complete limiting predual and thereby a normal adjoint. The supplied proof makes that choice correctly.

## 2. Marginal maps are genuine normal commuting homomorphisms

Each coordinate partial trace gives a completely contractive trace-preserving ultraproduct predual map N_*->M_*. Its adjoint iota_a:M->N is therefore normal UCP. For coordinate x=(x_n)_U, pairing against every normal functional of N shows exactly

    iota_1(x)=(x_n tensor I)_U,
    iota_2(x)=(I tensor x_n)_U.

Thus multiplicativity and commuting ranges first hold on the ultraweakly dense coordinate C*-algebra. To extend multiplication, fix one coordinate factor, approximate the other arbitrary factor ultraweakly, and use normality of iota and separate ultraweak continuity of multiplication. Then approximate the first factor. The same two-stage argument extends commutation of the two ranges. It proves identities on all of M without assuming any spatial tensor-product identification.

This is a valid use of density. A claimed normal extension of an arbitrary coordinate homomorphism would be insufficient, but here normality comes first from the predual adjoint construction. The output algebra N is kept separate from M bar-tensor M throughout. Injectivity of either iota is unnecessary.

For ultralimit input states phi_i, marginal trace-norm defects tending to zero give

    phi_i composed with Phi composed with iota_a = phi_i

as normal functionals on the full input algebra. The predual construction supplies this identity directly; equivalently it holds on the dense coordinate algebra and extends by normality.

## 3. Input-only support compression preserves every required contract

Let phi=(phi_1+phi_2)/2 and p=supp(phi). Then phi is faithful on R=pMp, and phi_i<=2phi. All input densities lie under p, so the Haagerup corner embedding preserves their square roots, L1 products, norms, and gaps.

Keep the full output N. The compressed map Phi_p(y)=pPhi(y)p is normal UCP from N to R with unit p. The restricted iota_a:R->N remains a *-homomorphism but need not be unital into N; the proof does not assume it is.

The composites T_a=Phi_p iota_a are nevertheless unital on R. Indeed,

    0<=T_a(p)<=p,
    phi(T_a(p))=phi(p)=1.

Faithfulness of phi on R forces T_a(p)=p. The phi_i and phi remain invariant. This is the correct support argument; compressing the output by an unsupported shared support could have destroyed range commutation.

## 4. The Cesaro expectation is normal for a proved reason

Let T=(T_1+T_2)/2. For its fixed point x, Schwarz gives T(x*x)>=x*x. The faithful invariant phi makes the nonnegative difference vanish. The analogous equality for xx* puts x in the multiplicative domain of T. Therefore the fixed-point set F is a unital *-algebra; normality of T makes it ultraweakly closed, hence a von Neumann algebra.

The same F is fixed pointwise by each T_a. To check the strict-convexity step without an implicit equality assumption, put u=T_1x and w=T_2x in the GNS Hilbert norm. Schwarz and invariance give ||u||,||w||<=||x||, while (u+w)/2=x. The identity

    ||(u+w)/2||^2=(||u||^2+||w||^2)/2-||u-w||^2/4

forces u=w=x. Faithfulness turns GNS equality into operator equality.

A **single global subnet** of the Cesaro means converges pointwise ultraweakly by compactness of the product of bounded operator balls. Its limit E is linear UCP and phi-preserving. The estimates ||TC_L-C_L||,||C_LT-C_L||<=2/L, together with normality of T, give TE=ET=E. Each C_L fixes F, so E is a projection onto F and phi_i composed with E=phi_i.

Pointwise ultraweak limits of normal maps need not normally be normal. The proof correctly uses the faithful invariant state to establish this additional fact. For a bounded increasing positive net x_alpha upward to x, let y=sup E(x_alpha)<=E(x). Normality of phi gives phi(y)=phi(x)=phi(E(x)); faithfulness yields y=E(x). Thus E is normal. Multiplicative-domain equality on F then proves F-bimodularity.

No uniqueness of the Cesaro cluster point, uniform ergodic convergence, or finite-dimensional limiting algebra is required.

## 5. Broadcasting forces the sufficient algebra to be abelian

For x in F, x*x and xx* are also in F and fixed by both T_a. Because iota_a is multiplicative,

    Phi_p(iota_a(x)*iota_a(x))=x*x
      =Phi_p(iota_a(x))*Phi_p(iota_a(x)),

and the analogous other-sided equality hold. Thus iota_a(x) belongs to the multiplicative domain of the **unital** Phi_p even though the restriction of iota_a is nonunital.

For x,y in F, range commutation consequently gives

    xy=Phi_p(iota_1(x)iota_2(y))
      =Phi_p(iota_2(y)iota_1(x))=yx.

Hence F is abelian. This exact sufficient-algebra mechanism is established no-broadcasting prior art, not a new theorem of this run. The candidate-specific work is the dimension-independent approximate-to-exact limit with its precise normal-map interfaces.

## 6. The abelian RN step does imply the required root gap, including typeIII limits

F lies in the centralizer of phi: for a in F and x in R, phi-preservation, bimodularity, and abelianness give

    phi(ax)=phi(aE(x))=phi(E(x)a)=phi(xa).

Restrict phi_i<=2phi to F. Since F is abelian and phi faithful normal, classical RN supplies bounded f_i in F, 0<=f_i<=2p, satisfying phi_i(a)=phi(f_i a) for a in F. Crucially, the derivatives are acquired **inside F first**. Mere domination on R would not place arbitrary RN operators in the abelian algebra.

Sufficiency then lifts the identity to every x in R:

    phi_i(x)=phi_i(E(x))=phi(f_i E(x))=phi(E(f_i x))=phi(f_i x).

Centralizer membership means f_i commutes strongly with the Haagerup density h_phi (equivalently it commutes with every h_phi^(it), implementing the modular group). Thus

    h_i=f_i h_phi,
    sqrt(h_i)=sqrt(f_i)sqrt(h_phi).

All f_i mutually commute and commute with h_phi. The two roots therefore strongly commute, and their product is the positive L1 element sqrt(f_1)sqrt(f_2)h_phi. Consequently its L1 norm equals its distinguished trace and the gap is zero.

This argument does not require R to be semifinite. Haagerup densities live in the common measurable crossed-product algebra, and the bounded centralizer factors supply the legitimate functional calculus.

Raynaud Theorem3.6 preserves positivity and the Mazur maps, Theorem5.1 preserves L2 times L2 to L1 products, and the L2 isometry preserves inner products. The limiting zero gap is therefore exactly lim_U Delta(rho_(1,n),rho_(2,n)), contradicting a uniform positive lower bound.

## 7. Quantifiers, receiver escalation, and retained limitations

Define v(epsilon) by the supremum over finite-dimensional pairs admitting a two-output channel with error at most epsilon, or a monotone envelope. If it failed to tend to zero, an offending sequence with errors tending to zero would produce the contradiction just audited. Infima can be approximated if necessary. For each finite-dimensional instance the CPTP set is compact, so no practical infimum issue is hidden.

For arbitrary experiments, restricting a common broadcaster to any pair gives the same modulus uniformly over pairs. This proves the broadcasting-to-gap implication without any covering hypothesis. Uniform covering numbers enter only when the previous GENERAL_CRITERION converts small pair gaps into one common EB reconstruction channel.

Given a measure-and-prepare channel sum_z Tr(E_z rho)tau_z, the K-output channel sum_z Tr(E_z rho)tau_z^tensorK has every marginal equal to the original EB output. The error is exactly uniform in finite K, including prescribed unbounded receiver-count sequences K_n. The outputs remain correlated; neither independent cloning nor a joint tensor-power approximation follows.

The pure-qubit overlap example already recorded in `../broadcast_prior_art/AUDIT.md` shows that any universal monotone modulus must be at least (2+o(1))sqrt(epsilon) near zero. The qualitative proof makes no stronger rate claim. Ordinary small density commutators, artificial symmetric extensions of cq states, or diamond-norm closeness on the whole input space cannot replace this promised-pair channel contract.

## Primary prior-art boundary

Original contracts checked:

* Yves Raynaud, *On ultrapowers of non commutative Lp spaces*, JOT48(2002),41--68: https://jot.theta.ro/jot/archive/2002-048-001/2002-048-001-003.pdf . Introductionp42; Thm1.1/Fact1.2 pp44--45; Prop1.6p46; Thm3.6 pp59--60; Thm5.1p66; Prop5.2p67.
* Yui Kuramochi, *Accessible information without disturbing partially known quantum states on a von Neumann algebra*,1710.01599: https://arxiv.org/pdf/1710.01599 . Cor1p14 gives exact algebraic-tensor broadcasting iff normal CP equivalence to a classical experiment. Remark2 separates normal spatial tensor-product broadcasting, where atomicity is required. The candidate avoids imposing that stronger topology.

The broader prior-art report additionally distinguishes the channel-wide cb-norm information-disturbance theorem, relative-entropy approximate broadcasting, receiver-dependent symmetric extension bounds, and the recent explicit fidelity-affinity-gap zero-set theorem2609.14203. I do not claim those distinctions constitute exhaustive priority clearance. The exact broadcasting backbone and the statistic itself must be credited; neither originated in this run.

Final audit result: the new universal qualitative pair converse and the compact-experiment receiver equivalence survive the requested independent review. The effective modulus, optimal rate, efficient acquisition/implementation, and external correctness/priority are not established by this audit.
