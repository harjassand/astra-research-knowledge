# Spectral positivity at coefficient 4 need not admit finite torus stabilization

Status: independently derived constructive obstruction, with exact symbolic identities checked. The universal claim below rests on the written estimates, not on the finite numerical checks. External correctness and priority have not been established. Root has been asked for an independent adversarial check. This does not disprove the October 2026 spectral width manuscript, which expressly uses locally finite stabilization.

## Exact question and interface

Let `Δ=div grad`, and let

\[
Q_a(\varphi)=\int_M(a|d\varphi|^2+R_g\varphi^2)\,dV_g,
\quad \varphi\in C_c^\infty(M),\qquad
\lambda_a=\inf_{\varphi\ne0}\frac{Q_a(\varphi)}{\int_M\varphi^2}.
\]

Does `λ_4>0` on an arbitrary complete smooth manifold guarantee that some *finite* diagonal torus extension of the original metric has scalar curvature bounded below? A finite extension means a single integer `k<∞` and globally defined smooth real functions `p_1,...,p_k`, giving

\[
g^\times=g+\sum_{i=1}^k e^{2p_i}d\theta_i^2.
\]

The construction below answers this question negatively. The base is smooth, complete, connected, orientable, and boundaryless. No curvature or injectivity-radius bound is imposed. The base metric stays fixed throughout the obstruction. The allowed warps are otherwise unrestricted.

## Constructive proposition

There is a complete smooth metric on `M=R×S²` such that

\[
\lambda_4\ge2,\qquad \lambda_a=-\infty\quad(0<a<4).
\tag{1}
\]

For this metric, every finite diagonal torus extension has scalar curvature unbounded below. The product with `R^{n-3}` has the same properties in every dimension `n≥3`.

### 1. A completely specified smooth global profile

Put `b(u)=0` for `u≤0`, and `b(u)=exp(-1/u)` for `u>0`. Define

\[
\theta(u)=\frac{b(1-u)}{b(u)+b(1-u)}.
\]

This is smooth, equals one for `u≤0`, equals zero for `u≥1`, lies in `[0,1]`, and satisfies `θ(1-u)=1-θ(u)`. Define

\[
\Psi(t)=
\begin{cases}
t,&t\le1/2,\\
1/2+\int_{1/2}^t\theta(2v-1)\,dv,&1/2<t<1,\\
3/4,&t\ge1.
\end{cases}
\]

The identity `∫_0^1 θ(u)du=1/2` makes the last value exactly `3/4`. Flatness of `θ` at its endpoints makes `Ψ` smooth across both joins. Moreover `0≤Ψ′≤1`.

For `j≥1`, set `δ_j=2^{-(j+5)}`, `ε_j=δ_j³`, and

\[
q_j(s)=\Psi\bigl(\delta_j+\sqrt{s^2+\varepsilon_j^2}-\varepsilon_j\bigr).
\]

It is smooth and even, `0<δ_j≤q_j≤3/4`, and `|q_j′|≤1`. If `|s|≥1`, the argument of `Ψ` is at least `1+δ_j-ε_j>1`, so `q_j` is identically `3/4` on a neighborhood of either boundary of `[-1,1]`. Define

\[
q(x)=\begin{cases}
q_j(x-3j),&|x-3j|<1\text{ for some }j\ge1,\\
3/4,&\text{otherwise}.
\end{cases}
\]

The intervals are disjoint and locally finite. This gives a smooth global function, with `0<q≤3/4` and `|q′|≤1`. Its derivatives need not be uniformly bounded; that is permitted by the interface.

Set

\[
f(x)=\sin q(x),\qquad g=dx^2+f(x)^2g_{S^2},\qquad w=2\log f.
\tag{2}
\]

Here `g_{S²}` is the round metric of sectional curvature one. All data are globally smooth and `f>0`.

**Completeness and properness.** The coordinate function `x` is 1-Lipschitz for `g`. A metric ball of radius `r` centered at `(x_0,z_0)` lies in `[x_0-r,x_0+r]×S²`, a compact set. On any such compact interval, `f` has a positive minimum, so the smooth metric is locally equivalent to a product metric. The closed metric ball is therefore compact. Equivalently, a `g`-Cauchy sequence has a bounded convergent `x` coordinate and converges after using the compact sphere and local metric equivalence. Thus the metric is proper and complete. Shrinking cross-sections occur only as `x→+∞`; no finite-distance missing point is introduced.

### 2. Exact scalar formula and positivity at 4

For this warped cylinder,

\[
R_g=\frac2{f^2}-4\frac{f''}f-2\left(\frac{f'}f\right)^2,
\qquad
\Delta u=u''+2\frac{f'}f u'\quad(u=u(x)).
\]

Write `D=R_g+2Δw-|dw|²`. Direct substitution gives

\[
D=2\frac{1-(f')^2}{f^2}
 =2+2\cot^2q\,[1-(q')^2]\ge2.
\tag{3}
\]

For the positive smooth function `v=e^{-w/2}=1/f`,

\[
(-4\Delta+R_g)v=Dv.
\]

Integration by parts against compactly supported tests gives the exact ground-state identity

\[
Q_4(\varphi)=\int_M4v^2|d(\varphi/v)|^2\,dV_g
             +\int_M D\varphi^2\,dV_g.
\tag{4}
\]

This proves `λ_4≥2` for **all** compactly supported smooth tests, including tests with angular dependence. No eigenvalue attainment or uniform geometry is needed.

### 3. Test functions for every smaller coefficient

Fix the smooth even cutoff

\[
\zeta(s)=\theta(8|s|-2).
\]

It equals one on `|s|≤1/4` and zero on `|s|≥3/8`. Although `|s|` is nonsmooth at zero, the cutoff is constant in a neighborhood there and is globally smooth. Put

\[
\varphi_j(x,z)=\frac{\zeta(x-3j)}{f(x)}.
\]

These are globally smooth compactly supported tests. Sphere volume cancels in every quotient. With `s=x-3j`, define the constants

\[
A_0=\int_{\mathbb R}\zeta^2 ds\in[1/2,3/4],\qquad
A_1=\int_{\mathbb R}(\zeta')^2ds<\infty.
\]

Then

\[
\frac1{4\pi}\int_M\varphi_j^2dV_g=A_0,
\quad
\frac1{4\pi}Q_4(\varphi_j)=4A_1+\int D_j\zeta^2ds,
\tag{5}
\]

and

\[
E_j:=\frac1{4\pi}\int_M|d\varphi_j|^2dV_g
 =\int\left(\zeta'-\frac{f'}f\zeta\right)^2ds.
\tag{6}
\]

On the whole support of `ζ`, the argument of `Ψ` is at most `δ_j+|s|≤1/32+3/8<1/2`, so `Ψ` is exactly the identity. Therefore, throughout this support,

\[
q_j=\delta_j+\sqrt{s^2+\varepsilon_j^2}-\varepsilon_j,
\quad q_j'=\frac{s}{\sqrt{s^2+\varepsilon_j^2}},
\quad
D_j=2+\frac{2\varepsilon_j^2\cot^2q_j}{s^2+\varepsilon_j^2}.
\tag{7}
\]

**Uniform upper bound for `Q_4`.** On `|s|≤1/4`, use `q_j≥δ_j`, `cot δ_j≤1/δ_j`, and `ε_j=δ_j³`:

\[
\int_{|s|\le1/4}(D_j-2)ds
\le2\cot^2\delta_j\int_{\mathbb R}\frac{\varepsilon_j^2}{s^2+\varepsilon_j^2}ds
\le2\pi\delta_j.
\]

On `1/4≤|s|≤3/8`, `q_j≥|s|-ε_j≥1/8`, while `|q_j′|≤1`. This set has length `1/4`, so its contribution to `∫(D_j-2)ζ²` is at most `(1/2)cot²(1/8)`. Consequently

\[
\frac1{4\pi}Q_4(\varphi_j)
\le C:=4A_1+2A_0+\frac\pi{16}+\frac12\cot^2(1/8)<\infty.
\tag{8}
\]

The same constant works for every dip.

**Divergent derivative energy.** On `s∈[δ_j,2δ_j]`, `ζ=1`, `q_j≤δ_j+s≤3δ_j`, and `q_j′≥1/√2`. Since `q_j≤3/32`, `cos q_j≥1/2` and `sin q_j≤q_j`, giving `cot q_j≥1/(6δ_j)`. Thus

\[
E_j\ge\int_{\delta_j}^{2\delta_j}\cot^2q_j(q_j')^2ds
\ge\frac1{72\delta_j}.
\tag{9}
\]

For each fixed `0<a<4`,

\[
\frac{Q_a(\varphi_j)}{\int\varphi_j^2}
=\frac{Q_4(\varphi_j)/(4\pi)-(4-a)E_j}{A_0}
\le\frac{C-(4-a)/(72\delta_j)}{A_0}\longrightarrow-\infty.
\tag{10}
\]

This proves (1). The limit is taken through the same metric and a sequence of disjoint supported tests, not through a changing family of metrics.

### 4. Why this rules out every finite torus warp

For any `k≥1`, let `P=Σp_i`. The standard diagonal warp formula and pointwise Cauchy-Schwarz give

\[
R_{g^\times}=R_g-2\Delta P-|dP|^2-\sum_i|dp_i|^2
\le R_g-2\Delta P-\frac{k+1}{k}|dP|^2.
\tag{11}
\]

Set

\[
a_k=\frac{4k}{k+1}<4,\qquad
U=\exp\left(\frac{k+1}{2k}P\right)>0.
\]

The right side of (11) is `R_g-a_k ΔU/U`. If the warped scalar curvature were bounded below by any finite `σ∈R`, then

\[
(-a_k\Delta+R_g)U\ge\sigma U.
\]

The coefficient-`a_k` version of the compactly supported ground-state transform would imply `Q_{a_k}(φ)≥σ∫φ²` for every test. This contradicts `λ_{a_k}=-∞`. Hence no such lower bound exists. For `k=0`, the same conclusion follows because a scalar lower bound itself would make all `Q_a` bounded below for `a>0`.

This argument permits arbitrary warps and arbitrary total weight `P`. It strengthens the simpler fixed-weight obstruction in `SPECTRAL_WIDTH_AUDIT.md`.

### 5. Higher dimensions

Take the product with Euclidean `R^{n-3}`. The scalar curvature and `w` remain unchanged, so (3)-(4) still prove `λ_4≥2`. Multiply `φ_j` by one fixed nonzero smooth compactly supported Euclidean cutoff. Its additional derivative contribution is a fixed finite term, while (10) still tends to `-∞`. Thus the conclusion holds in every `n≥3`.

## Correct finite-rank interface and a quantitative repair

For a **fixed** finite number `k≥1`, the best uniform scalar lower bound obtainable from diagonal warps is

\[
\sup_{p_1,\ldots,p_k}\inf_M R_{g^\times}
=\lambda_{4k/(k+1)}.
\tag{12}
\]

Necessity is exactly (11) and its ground-state transform. For sufficiency, if `λ_a>−∞`, standard positive-solution theory gives a smooth positive supersolution `U` of `(-aΔ+R)U≥λ_a U`. This passage can be reconstructed using positive Dirichlet first eigenfunctions on a nested connected relatively compact smooth exhaustion, normalized at one fixed point. Their eigenvalues are bounded below by `λ_a` and above by a fixed compactly supported test quotient. A convergent eigenvalue subsequence, local Harnack bounds, local elliptic estimates, and a diagonal extraction give a positive smooth solution at an eigenvalue at least `λ_a`. In the compact boundaryless case, use the positive first eigenfunction. Choosing all `p_i=(2/(k+1))log U` makes the warp scalar exactly `R-aΔU/U`, with `a=4k/(k+1)`. If `λ_a=−∞`, necessity already proves both sides of (12) equal `−∞`.

Thus the **finite-global-rank** stabilized invariant is `sup_k λ_{4k/(k+1)}`. Replacing this supremum by `λ_4` requires a left-continuity/uniformity argument. The dip example disproves that replacement in the unrestricted complete interface. Equation(12) is already implicit in equal-warp normalization and positive-solution theory; no priority is claimed for the characterization itself.

There is a simple useful repair with an explicit rank cost. If `R_g≥−C` for some finite `C≥0` and `λ_4≥λ>0`, then for each `0<a<4` and every normalized compactly supported test,

\[
Q_a=\frac a4 Q_4+\left(1-\frac a4\right)\int R_g\varphi^2
\ge\frac a4\lambda-\left(1-\frac a4\right)C.
\]

At `a=4k/(k+1)`, this becomes

\[
\lambda_{4k/(k+1)}\ge\frac{k\lambda-C}{k+1}.
\tag{13}
\]

Every integer `k>C/λ` therefore permits a finite torus stabilization with positive scalar curvature. This uses a scalar lower bound and does not require a bounded logarithmic gradient of a preselected supersolution. It explains exactly which assumption the counterexample violates: the curvature at its sharply rounded dips has no finite lower bound.

## Source relation, novelty, and practical consequence

1. **2026 manuscript claim.** OpenAI's *Spectral scalar curvature and uniform Urysohn width*, dated October 5, 2026, was read in full at commit `adc7f1241b42e322a6451854ab7e4b4c146bf78a`. Its Theorem 1.1 claims controlled codimension-two width for `λ_4≥1`. Section 2 explicitly imports a partition theorem allowing a **locally finite** family of compactly supported log warps. Section 6, PDF p.26, constructs such a family by subdividing localized pieces of its drift. The present obstruction is compatible with that interface.

2. **Nearest prior art.** [Gromov's *Product Inequalities for T-rtimes-Stabilized Scalar Curvature*](https://sigma-journal.com/2024/038/), SIGMA 20 (2024), 038, published May 8, 2024, defines the extension using finite `N` on PDF p.1. Section 1.A, PDF p.3, passes from finite `N` to the coefficient-4 expression; §1.B1, PDF p.4, states equality with the exhaustion limit on a noncompact base. The displayed unqualified extension to arbitrary noncompact geometry requires a uniformity condition or a broadened stabilization interface. Under the finite-global-rank definition, the present construction has no finite scalar lower bound, while the coefficient-4 quadratic form has lower bound 2. We have **not** established that this issue is new or that no correction, convention, or antecedent addresses it.

3. **Our deduction.** The endpoint spectral condition is strictly weaker than existence of any globally finite diagonal torus stabilization on an arbitrary complete base. Compactness/gradient control cannot be discarded when taking the stabilization-rank limit. A locally finite family is analytically different from a global product with one finite-dimensional torus.

4. **Downstream use.** This supplies a concrete adversarial fixture for future spectral scalar-curvature, weighted geometry, and torus-stabilization arguments. It prevents an invalid shortcut in noncompact width/band/cube proofs. It also tells an auditor precisely what must be checked when an imported geometric theorem was originally formulated for a finite torus product.

5. **What this does not settle.** The 2026 width theorem's imported partition construction, the global graph existence estimates, and its high-dimensional singular shielding are not verified by this construction. No contradiction to its width conclusion is obtained: this example is visibly a bounded-sphere-fiber bundle over a line (or Euclidean factor).

The mismatch with the exhaustion statement can itself be checked without invoking the compact spectral proposition. Let `X_i=[-i,i]×S²` be a compact exhaustion. On `X_i`, `|dw|²` is bounded. With `N` equal warps `p_l=-w/N`, the scalar formula is exactly `R_warp=D-|dw|²/N`. For each `η>0`, choosing `N` larger than `sup_{X_i}|dw|²/η` gives `R_warp≥2-η`. Thus each compact stabilized supremum is at least 2. Their decreasing exhaustion limit is at least 2, whereas no finite global extension has any finite lower bound. The rank depends on the exhaustion member; it cannot be interchanged with the infimum over the whole noncompact base.

## Evidence, costs, and next falsifiable step

The base has unlimited deterioration of curvature and cross-section size at infinity. Every dip is explicitly smooth, and only finitely many dips occur on each compact interval. The negative-curvature peak at the dip scale is extremely large; finite computation at a fixed grid is inadequate to test it. The proof uses a global positive supersolution, a fixed cutoff, exact integration by parts, and two elementary estimates.

`work/frontier_geometry1/cycle19/check_geometry.py` checks exact scalar/ground-state and release graph-square identities. `check_endpoint_dips.py` supplies finite quadrature witnesses with scale-aware panels. Neither validates all analytic lemmas in the release. Exact source snapshots and metadata are under `sources/frontier_geometry1/cycle19/`.

The next falsifiable step is an independent reconstruction of (2)-(11), especially the cutoff and fixed-metric limit. Then verify the meaning of the finite-rank definition and any hypotheses surrounding Gromov §1.A/§1.B1. If the obstruction survives, inspect the 2026 partition theorem's transfer from locally finite warps to finite analytic pieces; a hidden global finite-rank requirement would invalidate that transfer, while a genuinely local interface can avoid the obstruction.
