# Independent necessity audit of the fidelity-affinity criterion

7 October 2026. Verdict: **PASS**, with a dimension-free quantitative inequality requiring neither reference domination nor uniform trace-total-boundedness. The inequality is a direct consequence of established fidelity, affinity, and square-root inequalities; no novelty claim is made. Only necessity is audited here.

## Exact statement and constant

For density matrices rho,sigma on the same Hilbert space, let

F(rho,sigma)=||sqrt(rho)sqrt(sigma)||_1,
A(rho,sigma)=Tr[sqrt(rho)sqrt(sigma)],
Delta(rho,sigma)=F(rho,sigma)-A(rho,sigma)>=0.

For every entanglement-breaking, trace-preserving channel Lambda with the same input/output space,

Delta(rho,sigma)
 <=sqrt(||Lambda(rho)-rho||_1)+sqrt(||Lambda(sigma)-sigma||_1).       (N1)

In particular, if T(Lambda(rho),rho),T(Lambda(sigma),sigma)<=epsilon, where T=half the trace norm, then

Delta(rho,sigma)<=2sqrt(2epsilon).                                 (N2)

For an arbitrary family E, write delta=sup_{rho,sigma in E}Delta(rho,sigma) and e=inf_{EB Lambda}sup_{rho in E}T(Lambda(rho),rho). Then

e>=delta^2/8.                                                     (N3)

No infimum attainment or supremum attainment is needed. Apply N2 to every admissible channel and then take the infimum. Consequently e_n->0 forces delta_n->0 even when dimension and family cardinality diverge arbitrarily. All domination/covering assumptions in the proposed iff theorem concern sufficiency, not this implication.

## Direct proof

By the finite-dimensional EB structure theorem, write

Lambda(rho)=sum_j p_j tau_j,
Lambda(sigma)=sum_j q_j tau_j,

where p_j=Tr(E_j rho), q_j=Tr(E_j sigma), {E_j} is one POVM, and each tau_j is one fixed decoder density matrix.

For any unitary U, Hilbert-Schmidt Cauchy-Schwarz gives

sqrt(p_j q_j)>=|Tr[U sqrt(rho) E_j sqrt(sigma)]|.

Sum over j, use the triangle inequality and sum E_j=I, and maximize over U to obtain

F(rho,sigma)<=sum_j sqrt(p_j q_j).                                 (N4)

Thus only the easier measurement inequality is needed, not acquisition of a pairwise optimal POVM.

Lieb joint trace concavity at exponents one half gives joint concavity of A(P,Q)=Tr sqrt(P)sqrt(Q) on positive operators. A is also jointly homogeneous of degree one. Therefore it is superadditive on positive pairs, and

A(Lambda(rho),Lambda(sigma))
 >=sum_j A(p_j tau_j,q_j tau_j)
 =sum_j sqrt(p_j q_j) Tr tau_j
 =sum_j sqrt(p_j q_j)
 >=F(rho,sigma).                                                  (N5)

Set rho'=Lambda(rho), sigma'=Lambda(sigma). Expand the affinity difference and apply HS Cauchy-Schwarz:

|A(rho',sigma')-A(rho,sigma)|
 <=||sqrt(rho')-sqrt(rho)||_2 ||sqrt(sigma')||_2
   +||sqrt(rho)||_2 ||sqrt(sigma')-sqrt(sigma)||_2
 <=sqrt(||rho'-rho||_1)+sqrt(||sigma'-sigma||_1).                    (N6)

The last step is Powers-Stormer; all square roots of states have HS norm one. Since N5 says F(rho,sigma)<=A(rho',sigma'), subtracting A(rho,sigma) proves N1. This proof avoids an unjustified quantitative upgrade of exact no-broadcasting.

## An elementary reconstruction of the square-root inequality

To avoid depending on an unchecked original theorem location, here is the full needed argument. Put a=sqrt(P), b=sqrt(Q), D=a-b and choose an eigenbasis e_k of the compact selfadjoint D, with eigenvalues lambda_k. Because a+b>=D and a+b>=-D,

<e_k,(a+b)e_k>>=|lambda_k|.

The diagonal entry of a^2-b^2=[(a+b)D+D(a+b)]/2 is lambda_k<e_k,(a+b)e_k>. Hence

||a-b||_2^2=sum_k lambda_k^2
 <=sum_k |<e_k,(a^2-b^2)e_k>|
 <=Tr|a^2-b^2|.

For density matrices this is exactly ||sqrt(P)-sqrt(Q)||_2^2<=||P-Q||_1. The proof also works for positive HS a,b with trace-class squares on separable Hilbert space. Brown's Proposition 3.1.3 reproduces this classical argument and was checked live.

## Continuous outcomes and infinite dimensions

The proposed theorem itself uses finite-dimensional H_n, varying arbitrarily with n; the above finite EB representation is sufficient for its necessity without any limiting compactness argument.

The same bound extends to normal EB channels on a separable Hilbert space using the established integral measure-and-prepare representation. It is important not to replace this by an unsupported countable rank-one Kraus representation: some infinite-dimensional EB channels are not countably decomposable in that manner.

For measurement laws p,q, let lambda=p+q, and let r=dp/dlambda, s=dq/dlambda. The classical overlap is integral sqrt(rs) d lambda. The quantum measurement inequality follows from finite partitions and approximation of r,s. For the preparation inequality, apply Bochner Jensen to the jointly concave positive-operator function A and the probability measure lambda/2, with fields r(x)tau_x and s(x)tau_x; joint homogeneity gives

A(integral tau_x dp, integral tau_x dq)>=integral sqrt(rs) d lambda.

One may justify Jensen through simple-function approximation in trace norm and N6's square-root continuity for subnormalized positive operators. The integrands have bounded trace because 0<=r,s<=1. Thus countability or finite alphabet bounds are not needed for necessity. The sufficient-construction alphabet bound remains a separate claim.

## Broadcasting relationship and exact zero gap

Every measure-and-prepare channel has the broadcasting extension

B(rho)=sum_j Tr(E_j rho) tau_j tensor tau_j.

Both marginals equal Lambda(rho), so reconstruction error epsilon gives the same marginal broadcasting error epsilon. However, exact no-broadcasting alone provides no dimension-free approximate constant. N4--N6 supply the missing quantitative statement directly.

For a single exact pair, Delta=0 iff rho and sigma commute. Indeed, for C=sqrt(rho)sqrt(sigma), equality ||C||_1=Tr C forces C positive: polar decomposition C=U|C| gives ||(U-I)|C|^(1/2)||_2^2=2Delta=0. Thus C=C^*, so the square roots commute. Conversely commuting roots have positive product. This is an exact pair statement; it is not by itself a dimension-uniform sufficient family theorem.

## Square-root dependence is optimal in exponent

Let rho_+,rho_- be two pure qubit states with overlap s in (0,1), approaching zero. Then F=s, A=s^2 and Delta=s-s^2. Choose the symmetric realization

|psi_+>=cos(theta)|0>+sin(theta)|1>,
|psi_->=cos(theta)|0>-sin(theta)|1>,
cos(2theta)=s.

Measuring in the sigma_x basis and preparing the guessed original state yields equal error probability r=(1-sqrt(1-s^2))/2 on both inputs. The reconstructed state is (1-r)rho_+ + r rho_- (or the reverse). Its trace-distance error is

epsilon_s=r T(rho_+,rho_-)
 =sqrt(1-s^2)[1-sqrt(1-s^2)]/2
 ~s^2/4.

Thus Delta/sqrt(epsilon_s)->2. A universal necessity modulus o(sqrt(epsilon)) is impossible, already in dimension two. The coefficient 2sqrt(2) in N2 is valid but no optimal-constant claim is made.

## Precise primary-source ledger

1. M. Horodecki, P. W. Shor, M. B. Ruskai, *Entanglement Breaking Channels*, arXiv:quant-ph/0302031v2, Theorem 2 and Theorem 4(A)<->(B): https://arxiv.org/html/quant-ph/0302031v2 . This is the finite-dimensional EB/Holevo-form equivalence used at the start.
2. H. Barnum, C. M. Caves, C. A. Fuchs, R. Jozsa, B. Schumacher, *Noncommuting mixed states cannot be broadcast*, Phys. Rev. Lett. 76 (1996), 2818--2821, arXiv:quant-ph/9511010v1, Eq.(5) and the direct CS calculation Eqs.(6)--(8): https://arxiv.org/html/quant-ph/9511010v1 . Their Eq.(5) credits C. A. Fuchs and C. M. Caves, Open Systems & Information Dynamics 3, 1 (1995). The measurement inequality is established prior art. The HTML rendering's displayed 2026 date is not used as a publication date; arXiv metadata records November 1995.
3. E. H. Lieb, *Convex Trace Functions and the Wigner-Yanase-Dyson Conjecture*, original author preprint, Corollary 1.1, printed manuscript p.8 (PDF page 9), at p=r=1/2, K=I: https://www.numdam.org/item/RCP25_1973__19__A4_0.pdf . Theorem 1 first gives same-variable concavity; Corollary 1.1 supplies the required JOINT two-variable concavity via block lifting. Merely citing Theorem 1 without this specialization obscures the exact needed statement.
4. N. P. Brown, *Invariant Means and Finite Representation Theory of C*-algebras*, arXiv:math/0304009v2, Proposition 3.1.3 and its complete eigenbasis proof: https://arxiv.org/html/math/0304009v2 . Original attribution: R. T. Powers and E. Stormer, *Free states of the canonical anticommutation relations*, Commun. Math. Phys. 16 (1970), 1--33, https://doi.org/10.1007/BF01645492 . The original publication's metadata was checked, but its original lemma numbering was not independently accessed here; do not portray an unverified original locator as checked.
5. A. S. Holevo, *Entanglement-breaking channels in infinite dimensions*, arXiv:0802.0235v1, Introduction Eq.(2), and Section 2 Theorem 1: https://arxiv.org/html/0802.0235v1 . Eq.(2) states the normal separable-Hilbert-space EB integral measure-and-prepare equivalence and credits the earlier Holevo--Shirokov--Werner 2005 structure theorem. This resolves the noncountable-outcome scope.

## Boundary of the result

The necessity proof passes and is stronger in scope than the proposed theorem. It does not prove sufficiency of uniformly small pairwise Delta. It does not certify the canonical-likelihood lemma, a common decoder construction, metric-net acquisition, compilation cost, or the novelty of the full dominated uniformly total-bounded iff. Those are assigned separately.
