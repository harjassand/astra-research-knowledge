# Conditional audit: distinct homogeneous degrees and higher-rank summands

7 October 2026. Scope: independent audit of the deduction from the moment-coordinate tensor and density statements in the supplied released091 source. The load-bearing tensor/density statements are taken as premises, as requested; this note is not an independent proof of those premises or a priority certification.

Inspected parent source files: `logbm_variance.tex`, `logbm_tensor.tex`, `logbm_identities.tex`, `logbm_density.tex` under `work/agents/geometry_topology/`.

## Exact conditional theorem

Let psi_1,...,psi_k be nonzero nonconstant even convex homogeneous polynomials on R^n, with possibly different homogeneous degrees q_i. Necessarily every q_i is even and q_i>=2. Fix epsilon>0 and

V(x)=epsilon |x|^2/2+sum_i psi_i(x),
mu(dx)=Z^-1 exp(-V(x)) dx.

Under the supplied smooth moment-map, tensor-energy, and dense-even-double-divergence premises, for all real b_i,

Var_mu(sum_i b_i psi_i)<=sum_i b_i^2 E_mu psi_i.

Consequently, for any fixed such family, the function

L(t)=log integral_R^n exp(-epsilon |x|^2/2-sum_i exp(t_i)psi_i(x)) dx

is jointly concave on R^k.

No rank-one Hessian assumption or common homogeneous degree is required by the inspected deduction.

## Exact algebra audit

Convexity and evenness imply psi_i(x)>=psi_i(0)=0. The Gaussian term makes the density positive smooth even and all polynomial moments finite. Its Hessian satisfies D^2V>=epsilon I, so the moment-map premises provide the same positive matrix field tau with tau<=4 epsilon^-1 I. Different q_i do not affect this strong-convexity input.

Set H_i=D^2 psi_i>=0, a_i=E psi_i>0, and M=tau^-1. Euler's identities hold separately:

x dot grad psi_i=q_i psi_i,
H_i x=(q_i-1)grad psi_i.

Stein adjunction, with polynomial cutoff justification as in the inspected source, gives

m_i=E tr(tau H_i)=E[x dot grad psi_i]=q_i a_i>0.

For an even compact smooth test f use B=tau D^2f tau, W=delta_mu B, u=delta_mu W. The double-adjoint pairing gives

d_i=E[u psi_i]=E[W dot grad psi_i]=E tr(B H_i).

Matrix Hilbert-Schmidt Cauchy-Schwarz for H_i^(1/2)tau^(1/2) and H_i^(1/2)B tau^(-1/2) gives

E tr(M B H_i B)>=d_i^2/m_i.

No positivity of B and no Hessian rank restriction is needed. Positivity of H_i is enough for its square root and the quadratic form.

Separately,

E[x^T H_i x]=(q_i-1)m_i,
E[x^T H_i W]=(q_i-1)d_i.

Cauchy-Schwarz in the possibly degenerate positive form E[X^T H_i Y] therefore gives

E[W^T H_i W]>=(q_i-1)d_i^2/m_i.

The tensor-energy premise yields

E u^2>=E tr(M B (D^2V) B)+E[W^T(D^2V)W]
       >=sum_i q_i d_i^2/m_i
       =sum_i d_i^2/a_i.

The epsilon terms discarded here are nonnegative. The cancellation q_i/m_i=1/a_i occurs componentwise, so there is no common-q step.

The density premise applies because V and tau are even and epsilon strongly convex. It extends this inequality to every centered even u in L2(mu). Taking u=F-EF for F=sum_i b_i psi_i gives

||u||_2^2=sum_i b_i d_i
 <=(sum_i b_i^2 a_i)^(1/2)(sum_i d_i^2/a_i)^(1/2)
 <=(sum_i b_i^2 a_i)^(1/2)||u||_2.

Division when nonzero proves the claimed variance inequality. This last step also uses no shared degree or rank-one structure.

## Joint coefficient concavity and edge cases

For every t, apply the variance inequality to Psi_i=exp(t_i)psi_i, still convex even and homogeneous of degree q_i. Differentiation is justified locally in t by Gaussian domination times polynomial moments. Direct differentiation gives

(D^2L(t))_ij=Cov_mu_t(Psi_i,Psi_j)-1_(i=j) E_mu_t Psi_i.

The variance inequality says precisely that this matrix is negative semidefinite. Thus the proposed joint concavity follows.

Degree-zero constants should be omitted from the double-CS division m_i=q_i a_i. Nonnegative constants contribute the separately concave term -c_i exp(t_i) to L, so they can be added afterward. Identically zero summands are inert. The clean stated theorem uses nonzero nonconstant summands.

Sending epsilon down to zero is legitimate only if the unregularized partition function is finite for every coefficient vector considered. A sufficient condition is that the common zero set of the psi_i is {0}: compactness of the sphere then gives min_|theta|=1 sum_i psi_i(theta)>0, and for r>=1,

sum_i exp(t_i)psi_i(r theta)>=c_t r^(min_i q_i),

which ensures coercivity and integrability. If a nontrivial common kernel remains, the unregularized integral can be infinite; no finite log-partition concavity assertion should be made there.

## Verdict and provenance limitation

PASS at the supplied-premise interface. The mixed-degree, higher-rank extension is a direct algebraic consequence of the inspected variance proof. Its novelty versus existing generalized B-type inequalities, as well as the independent validity of the supplied tensor/density premises, remain separate questions.
