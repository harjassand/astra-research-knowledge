# Direct bounded-source transport bridge audit

Status (7 October 2026): the proposed atom-independent linear-TV premise is **false**, with an exact fixed-source counterexample in dimension two and density bounded by 8. The W-infinity premise and the general W2 one-third endpoint remain unresolved by this audit. No result here is upgraded by numerical checks, model agreement, or publication metadata.

## Exact investigated interface

Let rho=f dx be a probability supported in a fixed compact X, with 0<=f<=A. For every probability mu on a fixed compact Y, let T_mu be its unique quadratic Brenier map. No source convexity, connectedness, log-concavity, lower density, or target atom-count bound is assumed. Write E(mu,nu)=integral |T_mu-T_nu|^2 d rho and TV(mu,nu)=sup_B |mu(B)-nu(B)| (half the signed-measure norm).

The attempted bridge asks for E<=C W_infinity for short target displacements and E<=C TV for reweighting. Truncating an optimal W2 coupling at displacement r would then give E<=C(r+W2^2/r^2), hence map error <=C W2^(1/3). The TV estimate fails even when C is allowed to depend arbitrarily on the single fixed source below.

## Fixed-density counterexample

For n>=2 put s_n=2^-n, h_n=s_n/16, w_n=s_n/(4096 n^2) and

R_n=(-w_n,w_n) x (s_n-h_n,s_n+h_n).

Also put B=(-1/8,1/8) x (1/2,1), and U=B union (union_{n>=2} R_n). All rectangles are disjoint. Let Z=|U| and rho=Z^-1 1_U dx. Then X=closure(U) is a single fixed compact subset of [-1,1]^2, Z>1/8, and f=Z^-1 1_U<8. Thus there is no source/container/density variation with n.

For the nth target pair write h=h_n, w=w_n, s=s_n, v=x_2-s, sigma_i=(-1)^i, z_i=-1/4+i/(2n), 0<=i<=n. The target slopes are

a_i=(sigma_i,z_i), 0<=i<=n; c_-=(0,-1); c_+=(0,1).

All lie in the fixed target square Y=[-1,1]^2. Define the finite affine maximum

u_n(x)=max( sigma_i x_1+z_i v-h z_i^2 [0<=i<=n], -v-5h/8, v-5h/8).

With q=h/(100n), define u_n'(x_1,x_2)=u_n(x_1,x_2-q). Hence each affine intercept is perturbed by -q times its vertical slope, while every target site remains unchanged. Let mu_n=(grad u_n)#rho, nu_n=(grad u_n')#rho. Gradients of convex affine maxima are the unique Brenier maps to their own pushforward laws: the supporting inequalities certify optimality, and affine ties have Lebesgue measure zero.

For |x_1|<=w, the consecutive internal breakpoints in v are

b_i(x_1)=h(z_i+z_{i+1})-(sigma_{i+1}-sigma_i)x_1/(z_{i+1}-z_i), 0<=i<n.

Their deviations from h(z_i+z_{i+1}) have magnitude <=4nw=h/(64n). Consecutive unperturbed centers are h/n apart, so every consecutive interval has length >=31h/(32n). The bottom/top cap interfaces are

b_-(x_1)=-3h/4-(4/3)x_1,
b_+(x_1)=3h/4+(4/3)sigma_n x_1.

These lie outside all internal interfaces, with positive margins, and within (-h,h). Thus every target cell is present on R_n. Every interface translates vertically by exactly q after the intercept perturbation. The changed bands are disjoint and remain inside R_n.

All other R_m and B remain cap-dominated, so their maps do not change. For m<n, v>=7s_m/16 and |x_1|<=s_m/(4096m^2), while h_n<=s_m/32; the upper cap minus any internal affine score is at least (3/4)(v-q)-5h_n/8-|x_1|>0. For m>n, v<=-15s_n/32, |x_1|<=s_n/32768, and the analogous lower-cap gap is >0. On B, v>=1/4 and |x_1|<=1/8, so the upper-cap gap is at least 3/16-5/512-1/8-(3/4)q>0. These inequalities also show no target mass variation occurs off R_n.

Set A=Z^-1 and delta_n=2A w_n q_n=A 4^-n/(3,276,800 n^3). Each changed band has exactly rho mass delta_n. Every internal site loses one band and gains one band, so its target mass is unchanged. The bottom cap gains delta_n and the top cap loses delta_n. Consequently

nu_n-mu_n=delta_n(delta_{c_-}-delta_{c_+}),
TV(mu_n,nu_n)=delta_n.

Across each of the n internal interfaces, the two sites have squared separation 4+1/(4n^2). Across either cap interface it is 1+(3/4)^2=25/16. Therefore the exact map discrepancy is

E(mu_n,nu_n)=delta_n [n(4+1/(4n^2))+25/8]>=4n delta_n.

Thus E/TV>=4n tends to infinity for one fixed rho, X, Y, A. This disproves unrestricted E<=C TV. For dimension d>2, take the product source with the uniform probability on [-1,1]^(d-2) and pad target slopes by zeros; the same identities hold.

## Why finite support gives a valid substitute

Suppose both targets use one fixed set of N distinct sites y_i in diameter D. Choose affine-max potentials with intercepts c_i and d_i and write q_i=c_i-d_i. If positive source mass switches from old cell i to new cell j, strict maximizing inequalities give q_i>q_j, apart from null ties. Thus the directed switching flow is acyclic.

Its divergence at each vertex is the signed target-mass change. Decompose this finite nonnegative acyclic flow into paths from deficit vertices to surplus vertices. The sum of path weights is TV, and every path has at most N-1 edges. Hence the off-diagonal switching mass is <=(N-1)TV, and

E<=D^2 (N-1) TV.

The counterexample above has N=n+3 and carries each unit of changed mass over n+2 edges, with n edges of squared length about 4. Dependence on atom count is therefore necessary at this general source interface. An arbitrary-target truncation cannot silently import this finite-N bound with an atom-independent constant.

## Compatibility with known W2 bounds

The target difference is only an endpoint transfer, so coupling the unchanged masses and moving delta_n from c_+ to c_- gives W2(mu_n,nu_n)^2<=4delta_n and W1<=2delta_n. This is only an upper bound: a target coupling may relay through intermediate sites. In any case the construction's exponentially small delta_n keeps E~n delta_n consistent with Ruan's E<=C sqrt(W1), and this audit does not assert failure of W2^(1/3).

Primary literature checked live:

- Yuanlong Ruan, *Sharp conditioning and quantitative stability of optimal transport*, arXiv:2610.07577v1, 6 October 2026: https://arxiv.org/html/2610.07577v1 . Corollary 1 gives squared-map error <=C cost-gap^(1/2) for bounded compact sources/targets; §11 explains repaired target-coupling plans; §12 Theorem 8 gives map W1^(1/4) for bounded sources. This source attributes the compact bounded-source estimates to Mérigot; the premise is not entirely new on October 6.
- Cyril Letrouit, *Unstable optimal transport maps*, Comptes Rendus Mathématique 364 (2026), 333--344, Theorem 2: https://comptes-rendus.academie-sciences.fr/mathematique/item/10.5802/crmath.834.pdf . One fixed bounded uniform source rules out every Wp exponent alpha>p/[2(p+1)], including alpha>1/3 for p=2.
- William Ford, *Quantitative Stability, Coercivity and Uniqueness of Optimal Transport Plans*, arXiv:2609.35574v1, 28 September 2026: https://arxiv.org/html/2609.35574v1 . §1.2 explicitly says its W2^(1/4) deduction is below the theoretical W2^(1/3) upper exponent. §2 gives quantitative subgradient oscillation; Theorem 3.1 gives a sharp one-third quantitative uniqueness bound for nearby regular source measures, which is not a two-target stability theorem. Proposition 5.2 treats sharper W_r obstruction exponents.

## Failure ledger and strongest remaining attack

1. Unrestricted linear-TV correction: REFUTED exactly above.
2. Atom-count-dependent linear-TV correction: PROVED by acyclic flow decomposition.
3. Unrestricted squared-map W-infinity bound: UNKNOWN here; the constructed endpoint-transfer sequence does not refute it.
4. General fixed bounded-source W2 one-third endpoint: UNKNOWN here; neither Ruan nor Ford inspected statements supplies it.
5. Transfer of Ford's quantitative uniqueness theorem directly to two targets: missing a common-subgradient representation. Two maps for different targets do not in general lie on the same subgradient graph.

The next useful attack needs a target-displacement-sensitive control of long acyclic reweighting paths, or a common-subgradient construction that retains the original fixed source and charges W2^2. A bare TV correction discards the geometric information needed for such a proof.
