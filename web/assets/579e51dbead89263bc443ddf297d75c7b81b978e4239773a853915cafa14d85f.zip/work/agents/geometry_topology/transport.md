# Compact log-concave transport: endpoint stability and its concentration obstruction

7 October 2026. Worker `pde_spectrum9`, verified GPT-6.1 Sol/max, no nested workers. Own cycle19. Release commit `adc7f1241b42e322a6451854ab7e4b4c146bf78a`.

**Status:** internally reconstructed mathematical result. The positive-C1 source theorem in `LOG_CONCAVE_MIDPOINT_STABILITY.md` has two scoped independent analytic gates. This note independently reconstructs the further Moreau-source limit, layer-cake interpolation and exact concentration obstruction proposed in `notes/frontier_check_transport/cycle19/INDEPENDENT_LOGCONCAVE_GATE.md`. Those additions PASS at their literal interfaces. External validation and priority remain UNKNOWN. None of the numerical or formal-source inventories is used as a universal proof.

## 1. Exact theorem and author-versus-deduction boundary

Let `rho=f dx` be a full-dimensional, absolutely continuous, compactly supported log-concave probability on `R^d`. Let `K=closure{f>0}` be its convex compact support, contained in `B_R`, and use the upper-semicontinuous log-concave representative. Fix a compact target container `Y subset B_L`, with `R,L>0`. Targets are arbitrary Borel probabilities on Y, including atoms; no target density, separation, convexity or minimum mass is required.

For a target mu, let `T_mu=grad u_mu` be its unique quadratic optimal map from rho and normalize `integral u_mu d rho=0`. Its convex potential may be chosen L-Lipschitz on K. Set

\[
 C_p=(2+\sqrt5)R,\qquad
 M_\rho=\sum_{j=1}^d\int_{e_j^\perp}\sup_{t\in\mathbb R}
                         f(\xi+t e_j)\,d\xi.
\]

Then `0<M_rho<infinity`, and for every pair mu,nu,

\[
 \|u_\mu-u_\nu\|_{L^2(\rho)}\le C_p W_2(\mu,\nu),                 \tag{1}
\]
\[
 W_2(\mu,\nu)\le\|T_\mu-T_\nu\|_{L^2(\rho)}
 \le C_m W_2(\mu,\nu)^{1/3},                                    \tag{2}
\]
\[
 C_m={\sqrt3\over 2^{1/3}}(12d C_p^2)^{1/6}
                              (28L^2 M_\rho)^{1/3}.              \tag{3}
\]

Translations permit R and L to be enclosing-ball radii about chosen centers. M_rho depends on the chosen orthonormal coordinate system; rotation optimization is not acquired. If `A=ess sup f` and `P_K=sum_j |proj_(e_j^perp)K|`, then `M_rho<=A P_K`.

The pinned family374 author manuscript proves the uniform-source endpoint and a sharp fixed-source three-atom example. The weighted midpoint theorem, improved derivative-limit factor and (1) for smooth positive log-concave sources are deductions in our earlier note. The removal of source smoothness, the M_rho ledger and the source-concentration obstruction are additional deductions reconstructed here from the independently written checker note. They are not represented as claims made by the release authors.

## 2. Input primitive, including its finite-step limitation

Our earlier note gives the full smooth positive-source proof. The inputs needed below are exactly:

1. If U,V are convex positive-mass subcells, triangular scalar quantiles X,Z satisfy
   `sqrt(rho(U)rho(V)) Law((X+Z)/2) <= rho`. Indeed their diagonal Jacobian products are `rho(U)/f(X)` and `rho(V)/f(Z)`, AM-GM bounds the midpoint product from below, and log-concavity gives `f((X+Z)/2)>=sqrt(f(X)f(Z))`. Reverse-order scalar substitutions give the measure inequality without needing off-diagonal differentiability.
2. Symmetric weighted face calculus and that midpoint inequality yield, for fixed positive cells of masses M_i,

\[
 \sum_i {|DB_i[q,0]|^2\over M_i}
 \le(1+\sqrt5)^2R^2\sum_i {|DM_i[q,0]|^2\over M_i}.              \tag{4}
\]

The finite perturbation size can depend on the configuration. The constant emerges AFTER taking the derivative limit; it is not a target-uniform numerical step-size guarantee.

3. Along one optimal finite target coupling with masses m_i and site velocities v_i, weighted graph symmetry gives

\[
 \sum_i r_i DM_i[q,0]=-\sum_i v_i\cdot DB_i[q,0],\quad
 \sum_i m_i r_i=0,\quad \sum_i m_i|v_i|^2=W_2^2.
\]

Choosing `DM_i[q,0]=m_i r_i` is legal on the graph's zero-sum range. Cauchy-Schwarz with (4), and the explicit site term `x.v_i`, give the centered potential derivative bound `C_p W_2`. Neither an inverse-graph norm nor a lower cell mass enters the bound. Finite target approximation by uniformly Lipschitz potentials proves (1) for every compactly supported target under the smooth source premise.

The independent gates are `notes/frontier_check_transport/cycle19/INDEPENDENT_LOGCONCAVE_GATE.md`, Section3, and `notes/pde_transport9/cycle19/LOG_CONCAVE_OT_BOUNDED_PEER_GATE.md`. Both preserve the nonuniform finite-step limitation.

## 3. Fixed-support source approximation: independent reconstruction

Let `V=-log f`, extended by `+infinity` where f=0. With the upper-semicontinuous representative of f, V is proper lower-semicontinuous convex. It is finite near an interior point, so a supporting affine function bounds it below on bounded K. Thus `m=inf V> -infinity` and `A=exp(-m)<infinity`.

For integers n>=1 put

\[
 V_n(x)=\inf_z\{V(z)+(n/2)|x-z|^2\},\qquad
 Z_n=\int_K e^{-V_n}dx,\qquad
 f_n=Z_n^{-1}e^{-V_n}\mathbf1_K.                                \tag{5}
\]

The minimizer `z=P_n(x)` exists because V is lower-semicontinuous and its finite domain lies in compact K; strict convexity makes it unique. Optimality gives `n(x-z) in partial V(z)`. For z=P_n(x), z'=P_n(x'), monotonicity of partial V implies

\[
 (x-x'-(z-z'))\cdot(z-z')\ge0.
\]

This makes both P_n and `Id-P_n` 1-Lipschitz. Comparing the two minimization problems at x and x+h gives

\[
 V_n(x+h)-V_n(x)=n(x-P_n(x))\cdot h+O(n|h|^2).
\]

Consequently V_n is finite convex C1 on all space, with n-Lipschitz gradient `n(x-P_n(x))`. Before restricting to K, `Z_n^-1 exp(-V_n)` is positive C1 on a neighborhood of K and log-concave. Hence the exact smooth-source theorem applies to every rho_n=f_n dx, with the SAME K,R,L,C_p. There is no need for uniform min f_n or uniform log-gradient bounds.

The limiting claims have a direct proof. V_n increases with n and is at least m. If V(x) is finite, comparison with z=x gives `n|x-P_n(x)|^2/2<=V(x)-m`, so P_n(x) tends to x; lower semicontinuity forces V_n(x) to increase to V(x). If V(x)=infinity but some V_n(x) remained bounded, the same displacement bound would give P_n(x) tending to x with V(P_n(x)) bounded, contradicting lower semicontinuity. Thus V_n increases to V everywhere. Dominated convergence on fixed K gives `Z_n down to 1`, `Z_n>=1`, `f_n<=A`, and `f_n to f` in L1.

For each fixed pair mu,nu, choose the rho_n-centered convex potentials. They are uniformly L-Lipschitz and bounded by `L diam(K)`, so a common subsequence converges uniformly on K. At a differentiability point of the limiting convex potential in int K, every cluster limit of its bounded gradients satisfies the limiting supporting inequality; uniqueness of the supporting slope gives a.e. gradient convergence. For a continuous target test phi,

\[
 \left|\int\phi(\nabla u_n)f_n-\int\phi(\nabla u)f\right|
 \le\|\phi\|_\infty\|f_n-f\|_1
      +\int|\phi(\nabla u_n)-\phi(\nabla u)|f\longrightarrow0.
\]

The limiting gradient therefore has law mu. Its supporting inequality and bounded restricted conjugate prove optimality by Fenchel duality; source absolute continuity makes the optimal slope unique a.e. Normalizations and squared potential norms pass by uniform convergence and total-variation convergence. Passing the smooth inequality to the limit proves (1) with the full interface in Section1.

This argument uses a fixed compact source support. It does not make R uniform under unbounded-source truncation or singular limits.

## 4. Layer-cake interpolation: independent reconstruction

For convex L-Lipschitz u,v on K, put F=u-v. The pinned family374 coordinate-slice proof gives, on EVERY convex body E and for EVERY h>0,

\[
 \int_E|\nabla F|^2dx\le {12d\over h^2}\int_EF^2dx
                                      +28L^2 h P_E.            \tag{6}
\]

The constants can be reconstructed on each interval fiber: a forward quotient of F costs `4 h^-2 integral F^2`; the three-term square costs a factor3; each convex quotient-error square costs `4L^2h`, hence24 for two potentials after that factor; the omitted endpoint costs4. Fibers shorter than h are wholly charged to the endpoint term. Thus no small-h condition is hidden in (6).

For `0<t<A`, set `K_t={f>=t}`. These sets are compact convex by upper semicontinuity and log-concavity. All nondegenerate levels admit (6); any lower-dimensional exceptional level has zero volume contribution and cannot invalidate the inequality with its nonnegative projection term. Integrate in t, using

\[
 f(x)=\int_0^A\mathbf1_{K_t}(x)dt,
 \quad \int_0^A P_{K_t}dt
   =\sum_j\int_{e_j^\perp}\sup_s f(\xi+s e_j)d\xi=M_\rho.       \tag{7}
\]

For (7), a transverse point belongs to the projection of K_t exactly when its compact fiber attains f>=t. Tonelli is applicable to these nonnegative measurable quantities. Therefore

\[
 \|\nabla u-\nabla v\|_{L^2(\rho)}^2
 \le12d h^{-2}\|u-v\|_{L^2(\rho)}^2+28L^2 M_\rho h
 \qquad(h>0).                                                 \tag{8}
\]

Only convex superlevel sets are used in this interpolation step, so (8) itself holds for bounded quasi-concave weights. The potential estimate (1) still uses log-concavity. A direct independent fiber-mode proof gives the same inequality with32: choose the forward quotient left of the mode and backward quotient right of it; translated intervals are disjoint and move toward higher density; derivative increments cost24 and the central omitted length2h costs8. This also checks the direction of the weighted comparison.

Insert (1), set `a=12d C_p^2`, `b=28L^2 M_rho`, `w=W_2`, and choose `h=(2a w^2/b)^(1/3)` when w>0. The minimized squared bound is `3*2^-2/3*a^1/3*b^2/3*w^2/3`, giving (3). When w=0, send h to0. The lower bound in (2) is the coupling induced by `(T_mu,T_nu)` on rho.

For example, the normalized density `(9/16)(1-x_1^2)(1-x_2^2)` on the square has M_rho=3/2. It vanishes at the entire boundary and has unbounded log-gradient, yet (1)-(3) apply with finite constants. No approximation of its log-gradient is charged to the final estimate.

## 5. Exact obstruction to density-independent map continuity

Take fixed `K=Y=[-1,1]^2`. For integer n>=1, define

\[
 I_n=\int_{-1}^1e^{-n^2s^2}ds={\sqrt\pi\over n}\operatorname{erf}(n),
 \quad f_n(x)={e^{-n^2x_1^2}\over2I_n}\mathbf1_K.
\]

Each untruncated weight is smooth positive and log-concave. Let

\[
 \mu=\tfrac12(\delta_{-e_1}+\delta_{e_1}),\quad
 \nu_n=\tfrac12(\delta_{-(e_1+n^{-1}e_2)}
                         +\delta_{e_1+n^{-1}e_2}).
\]

The maps are `grad |x_1|` and `grad |x_1+x_2/n|`; central symmetry gives each sign mass1/2, and Fenchel equality verifies optimality. The two possible target matchings have squared costs `n^-2` and `4+n^-2`, so W2=1/n exactly.

Conditioning on uniform x_2, the sign-mismatch probability is

\[
 p_n={J\over\sqrt\pi\operatorname{erf}(n)},\qquad
 J=\int_0^1(1-r)e^{-r^2}dr
   ={\sqrt\pi\over2}\operatorname{erf}(1)-{1-e^{-1}\over2}>0.
\]

Equal signs cost n^-2; unequal signs cost `4+n^-2`. Thus

\[
 \|T_\mu-T_{\nu_n}\|_{L^2(f_n)}^2=4p_n+n^{-2}
                                     \ge4J/\sqrt\pi>0.         \tag{9}
\]

This disproves EVERY source-density-independent uniform map modulus on those fixed containers, even with smooth positive sources and two target atoms. In the same family,

\[
 M_{f_n}=1/I_n+1/2={n\over\sqrt\pi\operatorname{erf}(n)}+1/2.
\]

A one-third map constant must be at least `(4J/sqrt(pi))^1/2*n^1/3`; hence the M_rho^1/3 source-concentration exponent in (3) is necessary along this family. The potentials differ pointwise by at most1/n, consistent with (1). The obstruction is a universal proof from explicit formulas; finite numerical checks are not needed for it.

## 6. Downstream interface, costs and prior art

With fixed rho and a supplied certificate `W2(mu,bar_mu)<=epsilon`, the centered potential recovered from bar_mu has error at most C_p epsilon, and its map has error at most C_m epsilon^1/3. Quantizing bar_mu onto an eta-net replaces epsilon by epsilon+eta. A certified numerical solve error is added separately. Source acquisition, representation of the target, the W2 certificate, construction of a net, the cell solve, arithmetic precision and runtime are NOT acquired by these analytic inequalities.

The deterministic metric-noise exponents are sharp over this source class. Opposite Dirac targets on a uniform square give the potential lower rate epsilon. The pinned release's fixed uniform-source three-atom family gives W2=a^3/2/2 and squared map distance `a/4+a^3/4`, hence every estimate at observation mu_a has worst-case error at least `2^-5/3 epsilon^1/3`. This is an uncertainty-ball consequence, not a statistical sample-size lower bound.

Primary prior: Delalande–Merigot, arXiv2103.05934v2,8 March2023, Proposition4.1 supplies the convex gradient interpolation; inspected Corollary3.2/Theorem4.2 have W1^1/2 potential and W1^1/6 map bounds. Letrouit–Merigot, arXiv2411.04908v3,16 July2026, Theorem2.1 ALREADY gives a compact log-concave variance inequality with no density contrast when rho itself is log-concave. Its compact-source application uses dual-potential Lipschitzness and W1, producing a squared-potential bound proportional to W1. Thus compact log-concavity alone is not a newly acquired setting here. The precise comparison frontier is (1)'s linear W2 endpoint and the resulting one-third map exponent for arbitrary targets, with the explicit M_rho dependence. Exact global priority remains UNKNOWN.

A concrete recent conjecture is independently verified in the primary journal PDF: Cyril Letrouit, *Unstable optimal transport maps*, Comptes Rendus Mathématique364(2026),333–344, online18 May2026, printed page335, **Conjecture3**. It proposes a W2^1/2 map modulus for a fixed uniform source on a compact convex set and arbitrary targets in a compact set. The exact family374 square construction above has W2=a^3/2/2 but map distance at least sqrt(a)/2, so its ratio to W2^alpha diverges for EVERY alpha>1/3. Thus the inspected release example refutes this literal conjecture. This is stronger than describing its effect solely as an improvement of a W1^1/6 upper bound. It does not identify whether another paper between May and October2026 already refuted the conjecture; priority remains UNKNOWN. The primary PDF's introduction and theorem/conjecture statements were read, not its complete proofs.

No unbounded-source theorem, log-bounded perturbation extension, solver improvement, statistical minimax conclusion, or formal-kernel verification is asserted. The next falsifiable mathematical step is an external audit of the fixed-mass midpoint differential and source-limit passage. The next literature step is an exact search for the same centered-potential W2-Lipschitz interface in all relevant contemporary papers; this note does not turn a missing citation into a novelty claim.

## 7. Gate read scope

The independent checker note was read in full; Sections4–5 and7 were reconstructed here from the literal formulas. The pinned unweighted gradient TeX section was read in full and supplies the all-h premise of (6). The original positive-source proof was independently gated elsewhere, as listed in Section2. Our 17 symbolic checks in `TRANSPORT_ENVELOPE_ALGEBRA.json` concern algebraic identities and finite examples; they do not replace any of Sections2–5. The checker's 1,092 diagnostics are also scoped corroboration. Formalization source was inspected only to the depth separately recorded in source metadata; no Lean build was run.
