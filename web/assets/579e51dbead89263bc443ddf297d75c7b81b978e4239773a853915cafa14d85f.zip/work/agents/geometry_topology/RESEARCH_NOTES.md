# Geometry, convexity and transport: changed-premise audit

Research date: 7 October 2026. Shared protocol read in full. Source claims remain conditional until independently validated. No external publication, messages, installs or cloud computation occurred.

## Decisive routes and status

1. **Convex analytic composition.** Released family 091 supplies an even moment-coordinate tensor inequality. Its proof appears to extend from same-degree powers of linear forms to arbitrary even convex homogeneous polynomial summands, including mixtures of degrees. The resulting multivariable partition-function theorem is derived below. This is an extraction of a stronger reusable interface, conditional on the source's tensor, moment-map and density lemmas. No global priority claim is made.
2. **Transport endpoint extension.** Released family 374 and Astra L08 give the sharp W2 one-third modulus for compact uniform convex and compact full-dimensional log-concave sources. A potential direct extension to arbitrary bounded-density compact sources remains unresolved. The simple truncation composition through a dimension-free linear-TV estimate is false: independent agent gives a fixed disconnected source of density below 8 and arbitrarily many sites for which squared map error / TV diverges. The full exact construction is in the agent's report.

The initial KLS composition was rejected as a novelty target and as an unsupported proof: 093's psi2 premise is not acquired by 101's sharp entropy bound. Exact regular-simplex and product-exponential obstructions appear in `convex_bridge_audit/BRIDGE_AUDIT.txt`. New KLS claims were read to their base/cumulant/suspension interfaces; this audit does not certify them.

## A derived mixed-homogeneous partition theorem

Let psi_i be nonzero, nonnegative, even, convex homogeneous polynomials on R^d, of degrees q_i >= 2. The degrees may differ. Let epsilon > 0 and

    V(x) = epsilon |x|^2/2 + sum_i psi_i(x),
    mu(dx) = Z^{-1} exp(-V(x)) dx.

Conditional on family 091's moment-coordinate tensor and density lemmas at this interface,

    Cov_mu(psi_1,...,psi_m) <= diag(E_mu psi_i)

in the PSD order, i.e.

    Var_mu(sum_i b_i psi_i) <= sum_i b_i^2 E_mu psi_i.

Consequently

    t -> log integral exp[-epsilon |x|^2/2 - sum_i exp(t_i) psi_i(x)] dx

is jointly concave on R^m. Positive prefactors can be absorbed into the homogeneous summands. The result is about exact partition functions; it does not supply a numerical normalizer, sampler, conditioning bound, or query algorithm.

### Direct proof of the extraction

Use the source's moment map x=grad phi(z), tau=D_z^2 phi, M=tau^{-1}, with smooth bounded tau supplied by its moment-map lemma. For an even compact test f define

    B=tau D_x^2 f tau,
    W=delta_mu B,
    u=delta_mu W=A(A-1)f.

Write H_i=D^2 psi_i, a_i=E psi_i, m_i=E tr(tau H_i), and d_i=E u psi_i. The Stein identity and homogeneous Euler identities give, separately for every i,

    m_i=q_i a_i,
    H_i x=(q_i-1) grad psi_i,
    d_i=E tr(B H_i)=E W.grad psi_i,
    E x^T H_i x=(q_i-1)m_i,
    E x^T H_i W=(q_i-1)d_i.

Each H_i is PSD. The first Hilbert-Schmidt Cauchy-Schwarz estimate is

    E tr(M B H_i B) >= d_i^2/m_i.

The second Cauchy-Schwarz estimate in the H_i inner product is

    E W^T H_i W >= (q_i-1)d_i^2/m_i.

The source's tensor inequality and vector Bochner identity therefore imply

    E u^2 >= sum_i q_i d_i^2/m_i = sum_i d_i^2/a_i.

No step uses equality of the degrees, rank-one Hessians, a shared normal fan, or a supplied target atom list. Polynomial moments are finite because V has a positive quadratic part. The source's cutoff argument for the Stein identity applies to each polynomial separately. Its density lemma extends this estimate from double divergences to all centered even u in L2(mu). Taking u=F-EF, F=sum_i b_i psi_i, and applying weighted scalar Cauchy-Schwarz proves the variance inequality.

At parameter t, replace psi_i with exp(t_i)psi_i. Differentiation is justified uniformly on compact parameter boxes by the common positive quadratic domination and polynomial factors. For direction b,

    D_b^2 log Z(t) = Var_mu_t(sum_i b_i exp(t_i)psi_i)
                      - sum_i b_i^2 E_mu_t exp(t_i)psi_i <= 0.

This proves joint concavity, conditional only on the source analytical lemmas named above.

### Removing the positive quadratic term

If V_0=sum_i psi_i is coercive, i.e. V_0(x)->infinity as |x|->infinity, then its polynomial homogeneity decomposition gives a positive polynomial radial lower bound outside a ball (for a finite collection of nonnegative homogeneous polynomials, coercivity is equivalent to absence of a shared nonzero zero direction). Thus exp(-V_0) and its polynomial moments are integrable. Alternatively, integrability of the needed moments can be stated as a premise. As epsilon decreases to zero, monotone convergence gives finite partition functions. Their logarithms have a pointwise finite limit, and the concavity inequality passes directly to the limit. No uniform global lower bound on the moment Hessian is required for this limiting passage.

For a common degree q and no quadratic term, simultaneous coefficient scaling gives

    log Z(t+c 1)=log Z(t)-dc/q,

so the coefficient Hessian has the all-ones vector in its kernel. For mixed degrees, the corresponding scaling direction is (q_i):

    log Z(t+c(q_i))=log Z(t)-dc.

These are exact controls that any strict-concavity or equality argument must preserve.

### Prior-art boundary and historical ceiling

The two-summand homogeneous case is closely related to Cordero-Erausquin--Rotem's functional B-conjecture/correlation criterion; the source is `Several results regarding the (B)-conjecture`, Theorem 7 and Proposition 12, https://webusers.imj-prg.fr/~dario.cordero/Docs/articles/B-note-gafa.pdf . Its precise multi-summand coverage remains to be audited. The logBM source already implies scalar B and weighted logBM; extending an existing proof is not automatically a new theorem with historical priority.

The strongest next consequence would be rigidity or quantitative stability of the coefficient concavity for irreducible homogeneous families and, after the soft-to-hard limit, equality classification for full logBM. The load-bearing obstacle is **uniform coercivity as q->infinity and epsilon->0**. Redundant facet constraints can have vanishing expectations and create extra local flat directions in the hard-body limit. Smooth finite-parameter strictness does not establish sharp polytope rigidity.

### A wider geometric proof and arbitrary even log-concave base

There is a second direct conditional derivation, using only weighted logBM and ordinary Prekopa, which removes polynomial smoothness and admits any even log-concave Radon base measure mu. Let K_1,...,K_m be origin-symmetric convex bodies, and define

    G(s)=mu(intersection_i exp(s_i)K_i).

Then G is jointly log-concave. For D=intersection_i exp(s_i)K_i and E=intersection_i exp(t_i)K_i, the support inequalities h_D<=exp(s_i)h_K_i and h_E<=exp(t_i)h_K_i imply

    W[h_D^(1-lambda)h_E^lambda]
       subset intersection_i exp((1-lambda)s_i+lambda t_i)K_i.

Weighted logBM then proves the claim. All sets are compact bodies, so Radon masses are finite. Zero masses use the standard log-concavity convention. Multiple interpolation follows by iteration.

Now let psi_i(x)=||x||_{K_i}^{q_i}, q_i>=1, and suppose

    Z(t)=integral exp[-sum_i exp(t_i)psi_i(x)] dmu(x)

is finite and positive. Layercake and Tonelli give the exact formula

    Z(t)=integral_R^m G(((u_i-t_i)/q_i)_i)
                         product_i exp(u_i-exp(u_i)) du.

Indeed exp(-a psi)=integral_0^infinity exp(-r)1_{psi<=r/a}dr, followed by r=exp(u). The integrand is jointly log-concave in (u,t), since log G is concave and u-exp(u) is concave. Prekopa therefore makes Z jointly log-concave in t. Thus the mixed homogeneous theorem extends to arbitrary convex even homogeneous gauge penalties under an arbitrary even log-concave base. Its finite partition premise remains explicit; cylinders/seminorms can be obtained by bounded-body approximation if the resulting integrals are finite, but no uncharged limit should be assumed.

This is a reusable geometric principle extracted from the changed weighted-logBM premise; it is not asserted to have independent novelty. It generalizes scalar B to simultaneous body constraints, then soft homogeneous penalties. The source's scalar-B catalogue hides this multivariable interface, while the entire argument is short and independently inspectable.

Homogeneity is load-bearing. In one dimension, the even convex nonhomogeneous penalty psi(x)=(|x|-1)_+^2 under Lebesgue measure has

    integral exp[-exp(t)psi(x)]dx = 2+sqrt(pi)exp(-t/2).

Its logarithm is strictly convex, not concave. This exact counterexample forbids replacing homogeneous penalties by all even convex penalties, even when the base measure is Lebesgue and the partition is finite everywhere.

## Catalogue consequence: full (p,q) weighted dimensional inequalities

The release catalogue for 091 lists additive Lp volume inequalities but does not list the full even-log-concave dimensional consequence. This is a known implication, not a novelty claim.

Assume weighted logBM for an even log-concave density mu on R^n. Such a density is radially nonincreasing, so for 0<r<=1,

    mu(rC) >= r^n mu(C).

For K,L symmetric convex bodies with positive finite masses, p>0, lambda in (0,1), put

    a=mu(K)^(p/n), b=mu(L)^(p/n),
    z=(1-lambda)a+lambda b,
    alpha=lambda b/z,
    r=[(1-lambda)/(1-alpha)]^((1-alpha)/p)
      [lambda/alpha]^(alpha/p) <= 1.

Weighted AM-GM yields

    W[((1-lambda)h_K^p+lambda h_L^p)^(1/p)]
       contains r W[h_K^(1-alpha) h_L^alpha].

Weighted logBM, followed by radial contraction, gives

    mu(K+_p L)^(p/n)
       >= r^p a^(1-alpha)b^alpha = z.

Lower q in [0,p] follows by concavity of s^(q/p); q=0 follows from the logarithmic convention. This includes the generalized Gardner--Zvavitch inequality at p=q=1. The exact implication already appears in Hosle--Kolesnikov--Livshyts, arXiv2003.05282, Conjecture 1.2 and its following implications; the p=1 argument is Livshyts--Marsiglietti--Nayar--Zvavitch, arXiv1504.04878, Proposition 1. See downloaded `lmnz.txt` Section 3. Conditional on released091, these known conjectured consequences follow, but their resolution should be credited to the changed logBM premise and the existing transfer.

## Transport mechanism audit

Fresh primary Ruan, arXiv2610.07577v1, Section 5 structural estimate, Section 6 source profile, Section 12 Theorem 8:

    squared map error <= inf_{R,h} [4R gap/h +18R^2 A_rho(h)+8 target-tail(R)].

For bounded source density in a compact container, A_rho(h)<=C h, giving squared map error <=C sqrt(gap). Repairing a target coupling gives a W1 one-quarter map modulus. This works for nonconvex sources and does not need potentials' global normalization. It is a new reusable source mechanism relative to Astra L08, but its sharpness and original correctness remain source claims outside the reconstructed specialization.

Candidate composition:

    map-error^2 <= C W_infinity for target displacement,
    map-error^2 <= C TV for target reweighting,
    cutoff optimal W2 coupling at delta.

If both premises held uniformly, delta+W2^2/delta^2 would yield sharp W2^(2/3) squared map error. The TV premise is false in the unrestricted target-cardinality interface. The W-infinity premise and the actual W2 endpoint remain unresolved. Do not present the failed composition as a proof or as a counterexample to the endpoint itself.

## L05 endpoint guardrail

Read the supplied exact `metric.md` proof. The explicit complete warped cylinder has lambda_4>=2 and lambda_a=-infinity for all a<4. Thus coefficient-4 spectral positivity does not give one finite global torus stabilization. The correct finite-rank invariant uses lambda_{4k/(k+1)}, and a scalar lower bound R>=-C repairs it with rank k>C/lambda. This prevents an invalid compact-rank to global-rank interchange. No new result was obtained by rereading the existing obstruction.

## Failure ledger

* KLS from covariance/entropy plus093: rejected; regular simplex and exponential products do not supply uniform psi2.
* Claiming new KLS merely because current sources announce it: rejected; base/cumulant/tilt lemmas need correctness audits and prior art is immediate.
* Full (p,q) inequalities as new mathematics: rejected; exact composition is known conditional prior art.
* Compactlogconcave map1/3 with source-independent constants: rejected by L08's thin-source explicit two-atom example.
* Finite global torus rank from lambda4 on arbitrary complete manifolds: rejected by L05.
* Direct W2 endpoint using linearTV reweighting: rejected by fixed source zigzag construction; endpoint itself still open in this run.
* Strict soft partition concavity automatically proving hard logBM equality: rejected; scaling kernel and redundant facets survive/develop in the limit.

## Exact source handles

* Release snapshot commit is shared `work/repository/openai_commit.txt` (scientific source, no proof certification).
* 091 TeX files locally `logbm_{introduction,measure,variance,tensor,moment,identities,density}.tex`; raw base https://raw.githubusercontent.com/openai/math/main/preprints/The-logarithmic-Brunn-Minkowski-conjecture-September-23-2026/build/ . Load-bearing labels: lem:tensor, eq:tensor-squares, lem:density, lem:moment, eq:dual-bound.
* 374 TeX `sharpness.tex`; raw https://raw.githubusercontent.com/openai/math/main/preprints/Sharp-One-Third-Stability-of-Brenier-Maps-September-25-2026/build/source/sections/sharpness.tex . Labels sharpness:targets, sharpness:target-distance, sharpness:map-distance.
* Ruan primary https://arxiv.org/html/2610.07577v1 ; local `ruan.html`. Beware source intro equations 1.144/1.146 rendered numerator m-1 while abstract says m-2; source formula inconsistency is not resolved here.
* Astra L08 exact proof `transport.md`, gate `transport_gate.md`, card `L08-logconcave-transport.txt`; source exact asset daccf06ab6eeac204196f805f25418158f0aa6eb883ff00c68ffef28383df850.md .
* Astra L05 exact proof `metric.md`; source exact asset 1ebdc85d5ee901a1627f2fae2a22edfd57b8370655278b18d7b769fa6a09ee30.md .
