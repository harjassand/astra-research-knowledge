# Independent gate and extension: compact log-concave Brenier stability

7 October 2026. Worker `frontier_check_transport`, dispatched GPT-6.1 Sol/max; no nested workers. Cycle19. Exact pinned release: `adc7f1241b42e322a6451854ab7e4b4c146bf78a`.

**Status.** The inspected candidate `notes/pde_spectrum9/cycle19/LOG_CONCAVE_MIDPOINT_STABILITY.md` passes this independent mathematical reconstruction within its stated positive-C1, compact-source scope. This gate additionally derives an extension to every full-dimensional compactly supported log-concave probability density, including boundary-vanishing densities. An independently reconstructed layer-cake interpolation removes the candidate's log-gradient dependence from the map estimate. Novelty and external mathematical validation remain UNKNOWN; a numerical check below is only finite corroboration.

## 1. What was read first, and what is being claimed

Before reading the candidate note, I read the actual pinned release sections `cells.tex`, `moments.tex`, `finite_stability.tex`, and `gradient.tex`. I later read `sharpness.tex`, the source `main.tex`, README and bibliography. Recoverable, blob-verified copies are in `sources/frontier_check_transport/cycle19/release/`; source metadata is in `sources/frontier_check_transport/cycle19/SOURCE_METADATA.json`.

The exact inspected candidate is preserved as `sources/frontier_check_transport/cycle19/INSPECTED_CANDIDATE.md`, SHA256 `9b115f450aa6db1c70f7c05f7754521ace80637e7040b59dd463e063f6076cd6`. The machine-readable final gate is `results/frontier_check_transport/cycle19/GATE_RESULT.json`. The metadata records fourteen pinned-release/primary source files and no access failures; saved HTML does not imply full reading when metadata says excerpt.

The author manuscript is OpenAI, *Sharp One-Third Stability of Brenier Maps*, internally dated 25 September 2026. It claims, and supplies proofs for, uniform-source potential stability and the sharp one-third map exponent. Relevant source locators are `moments:midpoint`, `moments:derivative`, `finite:potentials`, `gradient:interpolation`, `gradient:extension`, and `sharpness:exponent`. Its constant in the stationary-site moment bound is 162; its potential factor is `(1+sqrt(162))R`.

The candidate extends the midpoint domination to weighted log-concave sources, improves the derivative-limit constant, and obtains the potential factor `(2+sqrt(5))R`. Its map proof pays both `max f` and `max |grad log f|`. Those deductions are not claims read from the release. The general-density limit, log-gradient-free interpolation, optimized concentration dependence, and exact concentration obstruction below are additional deductions of this gate.

## 2. Exact theorem and interface

Let `rho=f dx` be an absolutely continuous log-concave probability on `R^d`, with full-dimensional compact support `K`, and choose the upper-semicontinuous representative of `f`. Thus `f>0` on `int K`, `f=0` outside `K`, and `V=-log f` is a proper lower-semicontinuous convex extended-real function with domain contained in `K`. Assume `K subset B_R(0)`. Let all targets be arbitrary Borel probabilities on one compact `Y subset B_L(0)`, with `R,L>0`.

Write `T_mu=grad u_mu` for the unique quadratic optimal map from `rho` to `mu`, and normalize the convex potential by `integral u_mu d rho=0`. Potentials can be taken L-Lipschitz on K. Put

\[
 C_p=(2+\sqrt5)R,\qquad
 M_\rho=\sum_{j=1}^d\int_{e_j^\perp}
                \sup_{t\in\mathbb R}f(\xi+t e_j)\,d\xi.
\]

Then `M_rho` is finite. In particular, if `A=ess sup f` and `P_K=sum_j |proj_(e_j^perp) K|`, then `M_rho<=A P_K`. For every two such targets,

\[
 \|u_\mu-u_\nu\|_{L^2(\rho)}\le C_p W_2(\mu,\nu),                 \tag{T1}
\]

and

\[
 W_2(\mu,\nu)\le\|T_\mu-T_\nu\|_{L^2(\rho)}
 \le C_m W_2(\mu,\nu)^{1/3},                                  \tag{T2}
\]

where

\[
 C_m={\sqrt3\over2^{1/3}}(12d C_p^2)^{1/6}
                         (28L^2 M_\rho)^{1/3}.                 \tag{T3}
\]

There is no source lower-density or log-gradient assumption. The potential constant has no density dependence. The map constant pays source concentration through `M_rho`; removing all source-density dependence from a map modulus is impossible, even for positive smooth densities on one fixed square (Section 7). Atom count, minimum target mass and target-site separation do not enter either bound. Full-dimensional absolute continuity, compact source support, log-concavity, and a common bounded target set are essential scope restrictions here.

Translations allow R to be an enclosing-ball radius about any source center: replace x by x minus that center before applying the proof. A common target translation subtracts the same affine function from both potentials and the same vector from both maps, so L can also be optimized over enclosing balls. M_rho is defined in the chosen orthonormal coordinates; no rotation-independent optimal formula is claimed.

## 3. Independent reconstruction of the candidate's weighted proof

### 3.1 Weighted midpoint domination

First assume the candidate's smooth scope: K compact convex, f positive C1 on a neighborhood of K, log-concave on K, integral_K f=1. For convex U,V subset K with positive masses a,b, successive conditional scalar quantiles on the same parameter cube give X distributed as rho conditioned on U and Z distributed as rho conditioned on V. If p_k denotes the weighted marginal over the last d-k coordinates, then

\[
 \partial_{s_k}X_k=p_{k-1}(X_{<k})/p_k(X_{\le k}),\quad
 \prod_k\partial_{s_k}X_k=a/f(X),
\]

and the analogous product is b/f(Z). Positivity and continuity on interior projection fibers justify each scalar inverse CDF; the maps are Borel and triangular. Set H=(X+Z)/2. Arithmetic-geometric mean and log-concavity give

\[
 J_H:=\prod_k\partial_{s_k}H_k
 \ge {\sqrt{ab}\over\sqrt{f(X)f(Z)}}
 \ge {\sqrt{ab}\over f(H)}.                                  \tag{3.1}
\]

The second inequality has the displayed direction because `f(H)>=sqrt(f(X)f(Z))`. Sequential one-dimensional substitutions, in the last coordinate first, yield for any nonnegative Borel g

\[
 \int g(H)f(H)J_H\,ds\le\int g(x)f(x)\,dx.
\]

Earlier derivative factors depend only on earlier parameters, so Tonelli permits the substitutions without off-diagonal differentiability. Thus

\[
 \sqrt{ab}\,\operatorname{Law}(H)\le\rho.                       \tag{3.2}
\]

For opposite intercept perturbations of the same Laguerre cell, averaging its affine inequalities puts H in the central cell. Hence the right-hand side can be restricted to that cell. This checks the load-bearing new lemma rather than importing an unweighted bound.

### 3.2 Weighted cell calculus and derivative limit

For distinct sites y_i and cells P_i, define M_i=int_(P_i) f and B_i=int_(P_i) x f. The normal-coordinate difference quotient of perturbed half-space indicators gives

\[
 g_{ij}=\int_{F_{ij}}{f(x)\over|y_i-y_j|}\,dS,
 \quad b_{ij}=\int_{F_{ij}}{x f(x)\over|y_i-y_j|}\,dS,
\]

\[
 DM_i[r,v]=\sum_{j\ne i}\{g_{ij}(r_i-r_j)
                          +b_{ij}\cdot(v_i-v_j)\},
 \quad DB_i[q,0]=\sum_{j\ne i}b_{ij}(q_i-q_j).                  \tag{3.3}
\]

Continuity of f and the source's compactness give domination. Boundaries of convex-body sections and triple-tie sets have surface measure zero at positive-cell configurations. The same argument after graph parametrization of nearby equality planes gives continuous coefficients. Strictly active interior cells, positivity of f, and generic segments between cells give a connected positive-face graph. Consequently Gq=DM[q,0] has kernel constants and range the ordinary zero-sum hyperplane. These checks justify the implicit function theorem without a bound on the inverse graph Laplacian.

For opposite perturbations, put alpha_i=M_i(c-sq), beta_i=M_i(c+sq), gamma_i=sqrt(alpha_i beta_i), delta_i=alpha_i-beta_i, and D_i=E|X_i-Z_i|^2 under the coupling above. Testing midpoint domination with the NONNEGATIVE concave function Phi(x)=R^2-|x|^2 gives

\[
 {\mathcal A\over4}\le{R^2\mathcal B\over8}
                         +{R\over2}\sqrt{\mathcal A\mathcal B},
 \quad \mathcal A=\sum_i\gamma_iD_i,
 \quad \mathcal B=\sum_i\delta_i^2/\gamma_i.
\]

The mass deficit is `delta_i^2/[2(sqrt(alpha_i)+sqrt(beta_i))^2]`, at most `delta_i^2/(8gamma_i)`, and the Phi expectation difference is at most `2R sqrt(D_i)`. Young's inequality gives `mathcal A<=5R^2 mathcal B`.

Let E_s=sum_i delta_i^2/M_i for this fixed positive-cell configuration. The pointwise vector estimate

\[
 |\Delta B_i|\le R|\delta_i|+\alpha_i\sqrt{D_i}
\]

and Minkowski give

\[
 \left(\sum_i {|\Delta B_i|^2\over M_i}\right)^{1/2}
 \le R\sqrt{E_s}+
       \left(\sum_i{\alpha_i^2D_i\over M_i}\right)^{1/2}
 \le(1+\sqrt5+o(1))R\sqrt{E_s}.                               \tag{3.4}
\]

Here alpha_i,beta_i,gamma_i tend to M_i and there are finitely many cells, so `mathcal B=(1+o(1))E_s` and `max_i alpha_i^2/(M_i gamma_i)=1+o(1)`. These are multiplicative comparisons even when E_s=0. Divide by 2s and pass to the cell differentials:

\[
 \left(\sum_i {|DB_i[q,0]|^2\over M_i}\right)^{1/2}
 \le (1+\sqrt5)R
       \left(\sum_i {|DM_i[q,0]|^2\over M_i}\right)^{1/2}.       \tag{3.5}
\]

The finite perturbation threshold can depend on the smallest cell mass, direction and sites; the limiting constant does not. No uniform numerical step size has been obtained. An optional constant sharpening solves the preceding quadratic exactly, replacing sqrt(5) by `1+sqrt(3/2)` in the displacement bound; it is not needed or used in this gate.

### 3.3 Potentials along an optimal target coupling

For a finite optimal target coupling sum_i m_i delta_(y_i^0,y_i^1), combine repeated pairs and interpolate y_i(t). Pairwise cyclical monotonicity gives `(y_i^0-y_j^0).(y_i^1-y_j^1)>=0`, making interior-time sites distinct. Prescribed cell masses m_i and normalization sum_i m_i c_i=0 produce a C1 intercept path. Put r_i=c_i'(t), v_i=y_i^1-y_i^0 and w=W2(mu,nu). Then sum_i m_i r_i=0 and sum_i m_i |v_i|^2=w^2.

Differentiating the fixed-mass equations and using symmetric face coefficients gives

\[
 \sum_i r_iDM_i[q,0]=-\sum_i v_i\cdot DB_i[q,0].                \tag{3.6}
\]

Choose q with DM_i[q,0]=m_i r_i. Weighted Cauchy-Schwarz and (3.5) yield `||r||_m<=(1+sqrt(5))Rw`. At a strict active cell,

\[
 \partial_t u_t(x)=x\cdot v_i+r_i,
 \quad\|\partial_t u_t\|_{L^2(\rho)}\le(2+\sqrt5)Rw.            \tag{3.7}
\]

Individual intercept bounds `|r_i|<=(1+sqrt(5))Rw/sqrt(m_i)` give finite endpoint limits; their mass dependence is used only for existence. Endpoint repeated slopes can be merged, and the slope laws converge to the desired endpoint targets. Convex supporting inequalities and Fenchel duality identify these gradients as the unique optimal maps. Centering by the rho mean is an L2 orthogonal projection, proving T1 for finite targets.

Finite target nets give L-Lipschitz, centered potentials uniformly bounded by `L diam(K)`. Uniform subsequential limits are convex; at interior differentiability points their bounded gradients converge, because every gradient cluster point satisfies the limiting supporting inequality. Bounded convergence shows that the limiting gradient has the desired target law. Fenchel duality and uniqueness identify the limit. Passing T1 through this approximation proves the candidate's smooth-source all-target potential bound. No map estimate with a source log-gradient is needed for this passage.

## 4. Remove all source smoothness and boundary positivity from T1

The compactly supported log-concave density is bounded. A self-contained reason is that V is finite and convex near an interior point x_0, so it has a supporting affine lower bound there; that bound is finite below on bounded K. Closing V preserves it. Let m=inf V> -infinity and A=exp(-m)=ess sup f.

For integer n>=1 define the Moreau envelope

\[
 V_n(x)=\inf_{z\in\mathbb R^d}
           \{V(z)+\tfrac n2|x-z|^2\},\quad
 Z_n=\int_K e^{-V_n(x)}dx,\quad
 f_n=Z_n^{-1}e^{-V_n}\mathbf1_K.                              \tag{4.1}
\]

The infimum has a unique minimizer: the extended objective can be minimized on compact K and is lower semicontinuous and strongly convex in z; it is finite at at least one point. The standard elementary Moreau calculation gives a finite convex C1 V_n on R^d with gradient `n(x-prox_(V/n)(x))`; the proximal monotonicity inequality makes that gradient n-Lipschitz. Thus its untruncated weight is positive C1 on a neighborhood of K and log-concave.

Here is the needed regularity calculation explicitly. For proximal minimizers z=P_n(x) and z'=P_n(x'), `n(x-z)` and `n(x'-z')` are subgradients of V at z and z'. Monotonicity gives `(x-x'-(z-z')).(z-z')>=0`, hence both P_n and `Id-P_n` are 1-Lipschitz. Comparing the envelope at x+h using z and at x using P_n(x+h) bounds its difference above and below by `n(x-z).h+O(n|h|^2)`. This proves the stated gradient and C1 regularity. Convexity follows by taking the infimum in z of the jointly convex function `V(z)+(n/2)|x-z|^2`.

For clarity, the limiting facts do not assume them from a smoothing slogan. V_n increases with n and is bounded below by m. For finite V(x), the proximal minimizer z_n satisfies `n|x-z_n|^2/2<=V(x)-m`, hence z_n tends to x; lower semicontinuity then gives V_n(x) increasing to V(x). If V(x)=infinity but V_n(x) had a bounded subsequence, the same displacement estimate with that bound would force z_n to x and V(z_n) bounded, contradicting lower semicontinuity. Therefore V_n increases to V everywhere.

Consequently `Z_n>=1`, `Z_n` decreases to 1, `f_n<=A`, and `f_n` tends to f in L1 on K by dominated convergence. Denote rho_n=f_n dx. The source support, R, target bound L and potential constant C_p are identical for all n. The min f_n and log-gradient bounds can deteriorate; neither is used in T1.

For fixed mu,nu, take their rho_n-centered convex potentials. Both families are uniformly L-Lipschitz and bounded by `L diam(K)`, so choose a common uniformly convergent subsequence. At a common interior differentiability point, every limit of their gradients is the unique slope supporting the limiting convex function; therefore the gradients converge Lebesgue-a.e. Since f_n tends to f in L1 and gradients stay in B_L, testing against continuous functions of the gradients shows that their limits push rho to mu and nu. Their supporting inequalities and bounded restricted conjugates prove optimality and uniqueness as in Section 3.3. The normalizations pass to the limit because convergence of potentials is uniform and sources converge in total variation. The squared potential norms pass for the same reason. Apply T1 for rho_n and take the limit to prove T1 for the full interface in Section 2.

This limit uses a FIXED source support. It is not an assertion that constants remain uniform for arbitrary unbounded log-concave sources, singular limits, or target supports whose radius diverges.

## 5. New interpolation without a log-gradient bound

### 5.1 Layer-cake proof; main ledger, constant 28

For arbitrary convex L-Lipschitz u,v on K put F=u-v. For 0<t<A, let `K_t={x:f(x)>=t}`. These are compact convex sets. Those with positive d-dimensional volume are convex bodies; a degenerate level has zero contributions to the d-dimensional integrals below. The pinned source's unnormalized coordinate-slice argument gives, for every h>0,

\[
 \int_{K_t}|\nabla u-\nabla v|^2dx
 \le {12d\over h^2}\int_{K_t}F^2dx+28L^2h P_{K_t}.             \tag{5.1}
\]

Restricted u and v retain convexity and the same L-Lipschitz bound. A lower-dimensional level can be ignored on the left and right volume integrals; adding its nonnegative projection term cannot hurt. Log-concavity is used here through convex superlevel sets, so this interpolation by itself holds more generally for bounded quasi-concave weights.

Use the layer-cake identity `f(x)=int_0^A 1_{K_t}(x)dt` and Tonelli to integrate (5.1). Compact upper semicontinuity ensures that the fiber supremum is attained, and

\[
 \int_0^A|\operatorname{proj}_{e_j^\perp}K_t|dt
 =\int_{e_j^\perp}\sup_s f(\xi+s e_j)d\xi.
\]

This is just layer cake for the supremum: a transverse point is in the level projection exactly when its fiber maximum is at least t. Therefore

\[
 \|\nabla u-\nabla v\|_{L^2(\rho)}^2
 \le {12d\over h^2}\|u-v\|_{L^2(\rho)}^2
                         +28L^2M_\rho h\quad(h>0).             \tag{5.2}
\]

This proves the all-density interpolation without differentiating f or translating its logarithm. Boundary-vanishing and nonsmooth densities are included directly. The projection identity also proves measurability and finiteness of M_rho, with M_rho<=A P_K.

### 5.2 Independent mode-directed check; constant 32

The same mechanism can be checked without layer cake. On a coordinate fiber [a,b], any log-concave weight g is unimodal. Choose a mode m, use a forward quotient on [a,m-h] and a backward quotient on [m+h,b], interpreting empty intervals as empty. Moving toward m gives `g(t)<=g(t+h)` on the left and `g(t)<=g(t-h)` on the right. The two translated image intervals lie in [a+h,m] and [m,b-h], disjoint up to an endpoint. Hence the sum of squared quotient integrals is at most `4h^-2 int F^2 g`.

For a convex u, p=u' is monotone and lies in [-L,L]. The forward and backward quotient errors are nonnegative and bounded by the corresponding derivative increments. The integrals of those increments over both retained sides are at most `h Var_[a,b](p)<=2Lh`: their derivative-variation measures occupy the two disjoint sides of m. Since each error is at most 2L, its squared weighted integral over both sides is at most `4L^2 h sup g`. The same applies to v. The three-term square estimate contributes `24L^2 h sup g`. The omitted central interval has length at most 2h and derivative difference at most 2L, contributing at most `8L^2 h sup g`. The total is therefore `12h^-2 int F^2g+32L^2h sup g`. Integrating the scalar inequality over transverse coordinates gives (5.2) with 32. A measurable choice of m is unnecessary: the scalar inequality, whose final quantities are measurable, is proved separately on each fiber and then integrated. This independently verifies the translation direction and shows why an unbounded |grad log f| is harmless.

### 5.3 Optimization and T2

Insert T1 into (5.2), put `w=W2(mu,nu)`, `a=12d C_p^2`, `b=28L^2 M_rho`, and choose

\[
 h=(2a w^2/b)^{1/3}\qquad(w>0).
\]

The minimum of `a w^2/h^2+b h` is `3*2^(-2/3)*a^(1/3)*b^(2/3)*w^(2/3)`. Taking square roots gives T3. If w=0, T1 is zero and h tends to zero in (5.2). The lower bound in T2 follows because `(T_mu,T_nu)_#rho` is itself a target coupling. No small-h restriction or large-w patch is needed.

One immediate example beyond the candidate's map scope is

\[
 K=[-1,1]^2,\qquad f(x)={9\over16}(1-x_1^2)(1-x_2^2)\mathbf1_K.
\]

It integrates to 1 and is log-concave, vanishes at the entire boundary, and has unbounded |grad log f|. Yet `M_rho=3/2`, so T1-T3 give finite constants. The polynomial example and compact Dirichlet laws with parameters at least 1 illustrate why this is a genuine scope extension.

## 6. Exact robust inverse-problem consequences

Assume a fixed source in Section 2 and a certified observational W2 error `W2(mu,bar_mu)<=epsilon`. Computing the centered potential of bar_mu gives worst-case potential error at most `C_p epsilon`; computing its optimal map gives at most `C_m epsilon^(1/3)`. If bar_mu is first quantized onto an eta-net, replace epsilon by epsilon+eta. A numerically certified potential or map solver error must be added by the triangle inequality. Exact acquisition of the source, the W2 observational certificate, the target representation, the cell solve, precision and verification are costs outside the analytic theorem; no computational acceleration or uncharged oracle is asserted.

The potential noise exponent 1 is sharp across this source class. With rho uniform on the square, observation delta_0 and hypotheses delta_(plus/minus epsilon e_1), both hypotheses are within W2 radius epsilon. Their centered potentials are plus/minus epsilon x_1 and have L2 separation `2epsilon/sqrt(3)`. Any potential estimate has worst-case error at least `epsilon/sqrt(3)`.

The map noise exponent 1/3 is sharp even with the source fixed. Reconstructing `sharpness:exponent`, let u_a=max(-x_1,x_1,a), v_a=max(-x_1,x_1,a+(a/2)x_2) on the uniform square. Their three-atom target laws have the same masses, and

\[
 W_2(\mu_a,\nu_a)=a^{3/2}/2,\qquad
 \|T_{\mu_a}-T_{\nu_a}\|_\rho^2=a/4+a^3/4.
\]

At observation mu_a, both mu_a and nu_a lie in the uncertainty ball of radius `epsilon=a^(3/2)/2`. Every reported map has worst-case error at least half this separation, which is at least `2^(-5/3)epsilon^(1/3)`. This is a deterministic metric-noise lower bound, not a statistical sample-size bound. It makes the robust-map rate in T2 a matching rate in this observation interface.

## 7. Decisive concentration obstruction and sharp source dependence

No modulus depending only on K and Y can control maps uniformly over all log-concave source densities on those fixed sets. A fully explicit smooth family demonstrates this.

For integer n>=1 on `K=Y=[-1,1]^2`, set

\[
 I_n=\int_{-1}^1 e^{-n^2t^2}dt={\sqrt\pi\over n}\operatorname{erf}(n),
 \quad f_n(x)={e^{-n^2x_1^2}\over2I_n}\mathbf1_K.
\]

These are normalized, positive smooth log-concave weights on a neighborhood of K before restriction. Let

\[
 \mu={1\over2}(\delta_{-e_1}+\delta_{e_1}),\quad
 \nu_n={1\over2}(\delta_{-(e_1+n^{-1}e_2)}
                         +\delta_{e_1+n^{-1}e_2}).
\]

Under this centrally symmetric source their optimal maps are the gradients of `|x_1|` and `|x_1+x_2/n|`; each sign has mass 1/2. The matching target coupling gives `W2(mu,nu_n)=1/n`, and the swapped coupling has squared cost `4+1/n^2`, so the equality is exact.

Let p_n be the source probability that the two signs differ. Substituting r=n x_1 and conditioning on x_2 uniform in [-1,1] yields

\[
 p_n={J\over\sqrt\pi\operatorname{erf}(n)},\qquad
 J=\int_0^1(1-r)e^{-r^2}dr
 ={\sqrt\pi\over2}\operatorname{erf}(1)-{1-e^{-1}\over2}>0.
\]

On equal signs the squared map difference is 1/n^2; on unequal signs it is 4+1/n^2. Therefore

\[
 \|T_\mu-T_{\nu_n}\|_{L^2(f_n)}^2=4p_n+n^{-2}
 \ge4J/\sqrt\pi>0.                                            \tag{7.1}
\]

Although W2 tends to zero, the map error stays bounded away from zero. This refutes every density-independent uniform map modulus, not only a particular exponent or constant. The two targets always have exactly two atoms, the source and target containers remain fixed, and the densities are smooth positive. The worker's original paid density ledger is therefore necessary in principle.

For this same family,

\[
 M_{f_n}=1/I_n+1/2={n\over\sqrt\pi\operatorname{erf}(n)}+1/2.
\]

Any one-third map constant for f_n is at least `(4J/sqrt(pi))^(1/2)n^(1/3)`, so growth of order `M_rho^(1/3)` is necessary along this family. The optimized T3 has exactly that source-concentration exponent when d,R,L are fixed. The construction also shows why compactness of the supports alone cannot make a singular-source limiting statement uniform. Conversely, the two potentials differ pointwise by at most `1/n`, consistent with the density-independent potential bound.

## 8. Prior art and unresolved priority

Primary source checks include Alex Delalande and Quentin Merigot, arXiv `2103.05934v2`, version 8 March 2023, and Cyril Letrouit and Quentin Merigot, arXiv `2411.04908v3`, version 16 July 2026. The latter HTML's internal manuscript date is 24 August 2026; retain the arXiv version date separately rather than silently treating it as the same date. The inspected Theorem 2.1 already gives a density-independent variance inequality for a compact log-concave source, and Proposition 2.2 is the unweighted convex-gradient interpolation. Its introductory comparison reports a W1^(1/2) potential estimate and W1^(1/6) map estimate. This does not by itself identify whether the W2-Lipschitz conclusion here has appeared elsewhere.

The weighted midpoint mechanism is consistent with known displacement interpolation and is not claimed novel. The layer-cake argument is an elementary transfer of an older interpolation lemma, not itself a claim of a foundational discovery. The novelty-sensitive result is the full-source-scope W2-Lipschitz potential bound and the resulting sharp one-third map endpoint with explicit source concentration dependence. Exact overlap with all 2026 papers and unpublished notes remains UNKNOWN. Internal reconstruction and agreement with another worker are not independent external validation.

A further recent primary check is Caja-Lopez, Delgadino and Kitagawa, arXiv `2605.24232v1`, submitted 22 May 2026. Its Theorem 1.1 gives W2-Lipschitz map stability with both source and target densities nondegenerate and Holder regular on uniformly convex smooth domains; it excludes the arbitrary atomic targets here. Its Theorem 1.2 removes continuity but uses L2 distances between source and target densities on the right-hand side and still requires nondegeneracy. The statements therefore do not supply the exact T1/T2 interface, although they are relevant neighboring results. Only its abstract, introduction and these theorem statements were read; proofs were not read.

Unexplored alternatives are retained explicitly. For unbounded log-concave sources, truncating to radius R makes the T1 constant grow with R, and the nonnegative quadratic test in Section 3.2 is unavailable globally. A separate tail or moment argument is needed before claiming an untruncated Gaussian theorem. For a merely log-bounded perturbation of a log-concave source, midpoint domination loses a fixed multiplicative factor; that leaves an order-one partition deficit in the small-perturbation moment proof instead of an order-squared deficit. The current argument does not establish the same endpoint for that larger class.

Next falsifiable step: check the literal T1 finite-cell proof and Moreau source-limit proof against primary contemporary stability results, especially any theorem already providing W2-Lipschitz centered potentials for compact log-concave sources. An external referee should target the midpoint domination and the fixed-mass differential identity first. Separately, attempt to invalidate the all-level layer-cake projection identity or source-limit normalization; the complete derivations above expose those steps. If a failure is found, retain the candidate's inspected smooth-positive theorem and restrict the stronger scope explicitly.

## 9. Finite diagnostic scope and gate verdict

`work/frontier_check_transport/cycle19/check_transport.py` checks the exact concentration formulas and finite one-dimensional modal-weight interpolation cases with piecewise affine convex potentials. Output is `results/frontier_check_transport/cycle19/diagnostics.json`: 1,092 cases passed, maximum left-side/bound ratio 0.057443; the exact concentration-family positive map-error lower bound is 0.9859664884. These computations corroborate constants and sign choices; the universal mathematical derivation is Sections 3-5, not those tests.

Gate verdict for the original candidate: **PASS within stated scope**. No failure of M1, C3, P1 or G1 was found. The general log-concave source potential extension and log-gradient-free map estimate are **additional internally reconstructed results, external validation and priority pending**. The attempted strengthening to density-independent map stability is **FALSE**, with exact obstruction (7.1).

After reading this literal note, `pde_spectrum9` separately reconstructed Sections 4, 5 and 7 and reported PASS: the fixed-K Moreau/TV limit, layer-cake projection identity, optimized constant, and two-atom concentration formulas all agreed. That is a reciprocal internal proof check, not independent external mathematical validation.
