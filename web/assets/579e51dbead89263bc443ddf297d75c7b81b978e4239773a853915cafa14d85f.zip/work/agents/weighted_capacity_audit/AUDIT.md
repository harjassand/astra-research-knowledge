# Independent audit of the weighted four-state reconstruction criterion

Audited draft: `work/agents/statistics_learning/weighted_capacity_proof.md`, as read on 7 October 2026. Scientific status: the extension argument survives this audit **conditional on** the source posterior-class closure and cubic-saving proposition. This audit does not independently establish that source proposition, external correctness, or priority. The source certificate replay is assigned separately to `potts_certificate_audit`.

## Exact contract

An infinite locally finite deterministic rooted tree, uniform root in four states, known independent symmetric ferromagnetic channels with edge parameters `0 < lambda_e <= 1`, and observation of the entire depth-n spin vector. Reconstruction is positive limiting expected TV advantage. A flow is nonnegative, finite in mass, and conserved at **every** nonroot vertex, including leaves; it cannot terminate on an early finite branch. Put `R_root=1`, `R_w=R_v lambda_e^2`.

The criterion is existence of a flow of positive finite root mass whose potential is uniformly finite on infinite rays:

`V(theta,xi)=sum_(v,w) in xi (1-lambda_e^4)(theta_e/R_w)^2`

`=sum_(v,w) in xi theta_e^2 (R_w^(-2)-R_v^(-2)).`

This is standard L^3 capacity with edge resistance `sqrt(1-lambda_e^4)/R_w`, allowing zero resistance on deterministic edges. Capacity may be infinite; the theorem uses positivity only.

## Necessity checks

The pair cubic saving `m_star <= a+b-c ab(a+b)` and `y(m)=m+K m^3`, `K<=c/3`, imply `y(m_star)<=y(a)+y(b)`: use `m_star<=a+b` in the positive cubic term and cancel its mixed coefficient `3K-c`. Thus finite local degree suffices; no uniform degree bound is hidden.

The channel identity `y(rm)=r y(m)-K r(1-r^2)m^3` is exact. The conversion `y<=(1+9K)m` gives one universal coefficient for the weighted recurrence. Every child set is finite, so passing finite-depth quadratic informations to limits requires no interchange of an infinite sum or maximum.

For the resulting labels `z_v`, coefficients `d_vw` satisfying `z_v=sum_w d_vw z_w` can be chosen by scaling the finite upper-bound sum. With `ell_w=ell_v d_vw`, `theta_vw=ell_w z_w`, and `g_v=ell_v/R_v`, conservation is exact and

`(1-lambda_e^4)(theta_e/R_w)^2 <= g_v^2-g_w^2`.

Summing finite initial segments and then monotone convergence proves the bound on every ray. There is no flow-compactness or posterior-limit membership assumption.

## Universal third-moment product estimate

For the posterior product coordinates `Z=1+x.y`, `N_i=Z(LP)_i`, simplex membership gives `0<=Z<=4` and `|N_i|<=Z`. Hence the exact denominator remainder satisfies

`|N_1 N_2 N_3| s^2(3+2s)/Z^2 <=36s^2`, `s=x.y in [-1,3]`.

Since `E s^2=ab/3`, its expectation is at most `12ab`. At `Z=0`, the integrand has continuous extension zero because its absolute value is at most Z. This is a substantive repair of the released lemma's `C(lambda)` bound and remains valid for deterministic channel parameters.

An exact SymPy expansion of `N_1 N_2 N_3(1-2s)` has two pure monomials, exactly the two individual third moments; 24 monomials of degree one in one independent vector, whose expectations vanish; and 163 other mixed monomials with total absolute coefficient 364. Each latter monomial has degree at least two in both vectors and absolute expected value at most `ab`. Therefore the proof permits the explicit universal constant **C=376**. Additional symmetry decreases the coefficient total, but is unnecessary.

The constant-seven quadratic loss bound is inherited from the exact cancellation in the source, and its denominator remainder is nonnegative. It also extends continuously through `Z=0`.

## Sufficiency checks

On positive flow, let `p_e=theta_w/theta_v`, `X_v=eta theta_v/R_v`. Then `sum p_e=1`, `X_w=p_e X_v/lambda_e^2`, and the telescope

`X_w^2-X_v^2 <=(1-lambda_e^4)X_w^2`

gives `X_v^2<=eta^2(b^2+1)` when the original energy is at most one and root mass is b. Thus terminal channels `t_v=sqrt(X_v/3)` are valid for one eta chosen uniformly in depth. This avoids falsely obtaining pointwise smallness from a weight that may tend to zero.

Merging any finite number of child branches gives new third-moment cost `C sum_(e<f) (p_e X)(p_f X)=(C/2)X^2 s_v`, where `s_v=1-sum p_e^2`. Summing the quadratic loss also gives the stated factor `(1-p_e)` multiplying each incoming third moment. The constants do not grow with degree. Zero-flow subtrees remain uninformative after terminal degradation.

The finite-depth deficit telescope is exact. Sampling the flow path is legal because locally finite conservation identifies a probability measure on rays; alternatively only its consistent finite path distributions are needed. Its marginal is `Pr(V_i=v)=theta_v/b`. The unrolled third-moment loss has the stated accumulator

`a_(i+1)=lambda_i [a_i+(1-p_i)X_i]`, `a_0=0`.

The terminal remainder is `E[a_n k_n]`, with `k_n=h_n/X_n<=1`. No convergence or compatibility among the differently degraded experiments is required; the original observation dominates each one separately at the same n.

## Independent proof of the load-bearing occupation inequality

Set `F(X,a)=X^2+aX+a^2/4`, `U=pX`, `B=a+(1-p)X`. The deterministic split identity is

`F(U,B)-F(X,a)=-(1-p)(1-(1-p)/4)X^2-(1-p)aX/2`.

Therefore this decrement is at most `-3(1-p)X^2/4-(1-p)aX/2`.

The subsequent scalar channel update gives

`F(U/lambda^2,lambda B)-F(U,B)`

`=(lambda^(-4)-1)U^2+(lambda^(-1)-1)UB-(1-lambda^2)B^2/4`.

Completing the square in B bounds the last two terms by

`[(lambda^(-1)-1)^2/(1-lambda^2)]U^2`

`=[(1-lambda)/(lambda^2(1+lambda))]U^2 <=(lambda^(-4)-1)U^2`.

The inequality is valid for `0<lambda<1` and its lambda=1 case is the exact zero increment. Since `U/lambda^2=X_next`, this proves the draft's pointwise occupation bound. Conditional expectation of `1-p_e` under p_e is `s_v`; summation gives the claimed finite total branch cost and terminal bound. The argument is elementary and does not depend on numerical evidence.

## Adversarial cases and assumption boundaries

1. **Completely deterministic ray:** potential zero and advantage 3/4. The criterion correctly allows infinite capacity. Unweighted capacity would fail.
2. **Summably noisy ray:** `lambda_n=1-2^(-n-1)` has positive infinite product. The exact depth-n advantage is `3/4 product_(j<=n) lambda_j`; a constant flow's weighted energy is `theta^2[(product lambda_j)^(-4)-1]`, finite in the limit. Both sides agree.
3. **Ray with divergent total noise:** if the product is zero, the same telescope yields infinite weighted energy for every positive flow, and advantage tends to zero.
4. **Near-deterministic subdivision:** replacing an edge of parameter lambda by a finite chain with product lambda preserves the weighted energy exactly, since flow is constant along that chain and squared inverse R increments telescope. This handles the classical stretched-edge objection.
5. **Unbounded finite branching bursts / sparse branching / heterogeneous weak and strong edges:** every local merge is finite; the degree-free pair inequality and occupation estimate account for the actual branch probabilities. No uniform lambda lower bound or upper bound below one entered the proof.
6. **Finite side branches:** flow conservation at leaves forces them to carry zero flow. They can contribute finite-depth evidence but cannot circumvent the limiting necessity proof. If they have unbounded heights attached along a noisy spine, local finiteness still forces sufficiently distant evidence through arbitrarily distant spine cut vertices.
7. **Zero edges:** these must be deleted, with separated components discarded. The formula cannot be evaluated through `R=0`. If the root component is finite after deletion, reconstruction is impossible and no positive conserved flow exists.
8. **Infinite degree root or internal vertices:** outside the theorem. Here a level observation can be infinite and finite local merging/limit passage fails. The theorem must retain local finiteness.
9. **Unknown tree/channels:** outside the supplied interface. A positive infinite flow is a characterization, not a finite certificate or uniform recognition algorithm.
10. **Random tree/environment:** requires conditioning on the realized known environment first. Annealed threshold or SBM transfer needs a separate argument.

## Primary literature comparison and priority limits

* [Pemantle--Peres, 2010](https://arxiv.org/pdf/math/0503137), Theorems 2.1--2.2: arbitrary locally finite leafless trees with bounded edge interaction strengths; L^2 capacity for free-boundary Ising reconstruction and L^3 capacity for plus boundary. Section 3, Lemma 3.1 and Corollary 3.4 supply the general nonlinear recursion machinery. End of Section 4, PDF p.14, explicitly demonstrates failure of the unweighted criterion for near-deterministic subdivisions.
* [Evans--Kenyon--Peres--Schulman, 2000](https://users.cms.caltech.edu/~schulman/Papers/evansKPS00Ising.pdf), Section 5: edge-dependent error probabilities and electrical-conductance lower bounds. This is older arbitrary-edge work and must be acknowledged; it does not by itself give the four-state L^3 necessity.
* [Sly, 2011](https://arxiv.org/abs/0811.1208): regular-tree Potts thresholds, proving large-degree three-state sharpness and q>=5 nonsharpness. It does not establish this weighted arbitrary-tree four-state result.

Searches for four-state Potts nonlinear/inhomogeneous capacity did not locate an older exact match, but that absence is **not priority certification**. The extension uses classical capacity machinery and source-specific posterior closure; its new content, if correct and new, lies in the uniform product estimate, degree-free cubic transform, and weighted branch-occupation composition. Historical significance is not established by this audit.

## Audit outcome and strongest next attack

No load-bearing extension gap or counterexample survived the present audit. The broad quantifiers in the exact contract are supported by the conditional argument. The remaining load-bearing dependency is the posterior-class closure/cubic-saving theorem, including its route from polynomial certificates to all laws in the preserved class. A successful finite certificate replay is still distinct from independently auditing that probabilistic reduction. After that, perform a wider specialist prior-art search before any novelty claim. No downstream random-graph/learning claim follows automatically.
