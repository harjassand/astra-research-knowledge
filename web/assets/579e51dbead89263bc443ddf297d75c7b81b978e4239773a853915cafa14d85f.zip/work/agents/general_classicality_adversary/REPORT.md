# Adversarial audit of unrestricted-reference classicality

Status: exact counterexamples and proved necessary obstruction below. No dimension-uniform sufficient converse for the invariant is claimed. Source N03 is a supplied summary, not a supplied proof.

## Interface

Fix k,R>0, Hermitian contractions A_i, a known density omega, and

    rho_b = sqrt(omega) exp(sum_i b_i A_i) sqrt(omega)
            / Tr[omega exp(sum_i b_i A_i)],  ||b||_1 <= R.

Classical reconstruction means one parameter-independent measure-and-prepare channel Lambda=D M with sup_b T(Lambda(rho_b),rho_b) <= epsilon, where T=||.||_1/2. All observations below allow known omega,A_i as supplied inputs. No preparation complexity bound is asserted.

The proposed raw defects are

    eta = max_ij ||[A_i,A_j] sqrt(omega)||_2,
    zeta = max_i ||[A_i,sqrt(omega)]||_2.

## Exact counterexample 1: full-rank, asymptotically constant qubit

Let omega_e=diag(1-e,e), 0<e<1/2, A_1=X, A_2=Y. Set r=sqrt(b_1^2+b_2^2), u=(b_1-i b_2)/r, with the off-diagonal expression interpreted as zero at r=0. Then

    rho_b = [[1-e, sqrt(e(1-e)) u tanh(r)],
             [sqrt(e(1-e)) conjugate(u) tanh(r), e]].

The denominator is cosh(r). For P_0=|0><0|,

    T(rho_b,P_0)=sqrt(e^2+e(1-e)tanh(r)^2) <= sqrt(e).

A constant preparation channel therefore reconstructs the WHOLE bounded-parameter experiment with epsilon <= sqrt(e). Nonetheless

    eta=||[X,Y]sqrt(omega_e)||_2=2,
    zeta=sqrt(2)(sqrt(1-e)-sqrt(e)) -> sqrt(2).

The limiting pure reference gives an exactly constant experiment and exactly nonzero defects. Thus neither raw condition is necessary. This example is full rank at every positive e and has fixed dimension, k, R, and contraction norms.

## Exact counterexample 2: two identifiable parameters and three classical outcomes

The preceding objection does not depend on unidentifiable or globally trivial experiments. On C^3 tensor C^2, take

    D_1=diag(1,0,-1), D_2=diag(0,1,-1),
    omega_e=(I_3/3) tensor diag(1-e,e),
    A_1=(D_1 tensor I + I tensor X)/2,
    A_2=(D_2 tensor I + I tensor Y)/2.

Both A_i have operator norm at most one. Their exponential splits between the tensor factors, so

    rho_b = q_b tensor tau_e(b),
    q_b(a) = exp[(b_1D_1(a)+b_2D_2(a))/2] / Z_cl(b),
    tau_e(b) = [[1-e, sqrt(e(1-e)) u tanh(r)],
                [sqrt(e(1-e)) conjugate(u) tanh(r),e]],
    r=sqrt(b_1^2+b_2^2)/2, u=(b_1-i b_2)/sqrt(b_1^2+b_2^2).

Measuring the classical label a and preparing |a><a| tensor P_0 gives

    sup_b T(rho_b, q_b tensor P_0) <= sqrt(e).

The retained classical alphabet has exactly three outcomes. Both b_1 and b_2 remain identifiable, because

    log[q_b(1)/q_b(3)] = (2b_1+b_2)/2,
    log[q_b(2)/q_b(3)] = (b_1+2b_2)/2,

and the corresponding coefficient matrix is invertible. Yet

    [A_1,A_2]=(i/2) I_3 tensor Z,
    eta=1/2,
    zeta=(sqrt(1-e)-sqrt(e))/sqrt(2) -> 1/sqrt(2).

At e=0 the experiment is exactly the nontrivial, identifiable, two-parameter classical exponential family q_b tensor P_0. The noncommuting auxiliary exponential contributes only a scalar cosh(r), which cancels in normalization. At e>0 the quantum auxiliary information is uniformly negligible.

This is a nonlinear sandwich-score gauge/near-kernel obstruction. A theorem stated only in terms of raw A_i cannot be necessary for arbitrary references without excluding this mechanism or quotienting equivalent experiments.

## A dimension-free, representation-invariant necessary obstruction

For density operators rho,sigma define root fidelity and affinity

    F(rho,sigma)=||sqrt(rho)sqrt(sigma)||_1,
    a(rho,sigma)=Tr[sqrt(rho)sqrt(sigma)],
    Delta(rho,sigma)=F(rho,sigma)-a(rho,sigma) >= 0.

Proposition. If a single measure-and-prepare channel reconstructs rho and sigma with trace distances at most epsilon, then

    Delta(rho,sigma) <= 2 sqrt(2epsilon),
    epsilon >= Delta(rho,sigma)^2 / 8.

Proof. Write the measurement probabilities as p_z,q_z and the decoder output states as tau_z. Fidelity under measurement obeys

    F(rho,sigma) <= sum_z sqrt(p_zq_z).

This follows directly from the variational trace-norm formula and Hilbert-Schmidt Cauchy-Schwarz after inserting the POVM resolution of identity. The affinity is jointly concave and jointly homogeneous, hence superadditive on positive pairs. Therefore

    sum_z sqrt(p_zq_z)
      = sum_z a(p_z tau_z,q_z tau_z)
      <= a(sum_z p_z tau_z, sum_z q_z tau_z).

The Powers-Stormer square-root inequality and Hilbert-Schmidt Cauchy-Schwarz give

    |a(rho',sigma')-a(rho,sigma)|
      <= ||sqrt(rho')-sqrt(rho)||_2
         + ||sqrt(sigma')-sqrt(sigma)||_2
      <= sqrt(||rho'-rho||_1)+sqrt(||sigma'-sigma||_1)
      <= 2sqrt(2epsilon).

Combining the three displayed inequalities proves the result. Countable outcomes follow by monotone finite truncation; continuous outcomes by the same integral concavity argument or finite coarse graining.

Consequently, uniform classical reconstruction requires

    sup_{b,c in parameter set} Delta(rho_b,rho_c) -> 0.

The requirement depends only on observable density operators and survives all redundant score representations. For an exact pair, Delta=0 if and only if rho and sigma commute: equality ||C||_1=Tr C for C=sqrt(rho)sqrt(sigma) forces C to be positive semidefinite, hence C=C^dagger, hence the square roots commute. Conversely commuting density operators have positive C. For an exact family, vanishing pairwise Delta therefore characterizes simultaneous diagonalizability and exact classical reconstruction.

Only NECESSITY is proved quantitatively. Pairwise small Delta is not upgraded here to a dimension-uniform common measurement/decoder construction. That is the remaining obstruction if this invariant is adopted as an iff candidate.

## Exact faithfulness explains why ill-conditioning matters

In fixed finite dimension with a strictly positive reference omega, an exactly commuting sandwich family on a parameter neighborhood necessarily has [omega,A_i]=0. Differentiate [rho_{te_i},omega]=0 at t=0:

    [sqrt(omega)A_i sqrt(omega),omega]
      = sqrt(omega)[A_i,omega]sqrt(omega)=0.

Invertibility gives [A_i,omega]=0. Then the normalized exponentials commute exactly; differentiating mixed pairs at the origin gives [A_i,A_j]=0. Thus exact full-rank classicality does force the raw defects to vanish. The counterexamples show that this implication has no unrestricted asymptotic modulus as the reference approaches a rank-deficient state. Uniform identifiability of b does not repair it.

## Optional effective tangent coordinates; no theorem claimed

At b=0 the observed derivative is

    B_i=sqrt(omega)A_i sqrt(omega)-Tr(omega A_i)omega.

The symmetric logarithmic derivative S_i solves (omega S_i+S_i omega)/2=B_i. In an eigenbasis omega=diag(p_m), its off-diagonal entries are

    (S_i)_{mn}=[2sqrt(p_mp_n)/(p_m+p_n)](A_i)_{mn}.

The factor filters nearly invisible links between high-weight and low-weight eigenspaces, unlike raw A_i. In the examples it sends the auxiliary X,Y tangents to zero as e->0 while preserving the classical D_i tangents. Any tangent criterion still needs control of the entire finite-radius family; first derivatives alone can miss nonlinear sandwich information.

Here is an exact counterexample to tangent-only sufficiency. Let

    omega_e=diag((1-e)I_2/2,e I_2/2),
    P_1=(I+Z)/2, P_2=(I+X)/2,
    A_i=[[0,P_i],[P_i,0]].

The A_i are Hermitian contractions. The first derivative at zero is sqrt(e(1-e))A_i/2 and the SLD is 2sqrt(e(1-e))A_i; both vanish as e->0. Nevertheless the limiting density at parameter t e_i, t>0 fixed, is supported on the first C^2 block and equals

    r_i(t)=[I+(cosh t-1)P_i]/(1+cosh t)
           =(I+u sigma_i)/2, u=tanh(t/2)^2.

These states do not commute. Their exact root-fidelity/affinity gap is

    Delta(r_1,r_2)=sqrt(1-u^2/2)-(1+sqrt(1-u^2))/2 >0.

Thus the measure-and-prepare reconstruction error stays bounded below by the square of this expression divided by eight. Higher-order transitions through the near-kernel subspace carry fixed-radius quantum information even when all filtered tangents vanish. The canonical geometric likelihood of the whole state avoids this tangent-only failure.

## Source audit and prior art

1. N03 card, supplied summary only: https://raw.githubusercontent.com/harjassand/astra-research-knowledge/main/cards/N03-bounded-score.txt . It explicitly assumes exact [omega,A_i]=0 and Hermitian contraction scores, and claims eta->0 iff uniform classicality. It does not cover the references above. Original proof/package links in its J source were not supplied.
2. Barnum, Caves, Fuchs, Jozsa, Schumacher, Noncommuting Mixed States Cannot Be Broadcast, PRL 76 (1996), 2818-2821. https://arxiv.org/abs/quant-ph/9511010 ; https://doi.org/10.1103/PhysRevLett.76.2818 . This is prior art for exact classicality/no-broadcasting. Their root-fidelity measurement formula supplies the first inequality in the obstruction proof. The new local calculation here does not claim priority for the resulting bound.
3. Lieb, Convex trace functions and the Wigner-Yanase-Dyson conjecture, Advances in Mathematics 11 (1973), 267-288, Theorem 1, p=q=1/2, K=I: joint concavity of affinity. https://doi.org/10.1016/0001-8708(73)90011-X . The preparation inequality uses precisely this special case.
4. Powers and Stormer, Free states of the canonical anticommutation relations, Communications in Mathematical Physics 16 (1970), 1-33: square-root trace-norm inequality ||sqrt(P)-sqrt(Q)||_2^2<=||P-Q||_1. Exact original theorem numbering not yet checked; this is a standard named inequality, not a novel ingredient.
5. Fuchs and Sasaki, Squeezing Quantum Information through a Classical Channel: Measuring the Quantumness of a Set of Quantum States, Quantum Information and Computation 3(5) (2003), 377-404, https://arxiv.org/abs/quant-ph/0302092 . This establishes worst-case classical transmission/accessible fidelity of pure-state sets as operational prior art. Audenaert, Fuchs, King, Winter, Multiplicativity of Accessible Fidelity and Quantumness for Sets of Quantum States, https://arxiv.org/abs/quant-ph/0308120 , connects the measure to entanglement-breaking channels. A matching mixed-state, uniformly total-bounded gap criterion was not identified by the focused searches in this subtask; absence from those searches is not a priority certificate.
6. Quantum metrology uses "asymptotically classical" for weak SLD commutativity and equality of Holevo and SLD Cramer-Rao bounds; see Suzuki, Classification and characterization of quantum parametric models in quantum estimation theory, https://arxiv.org/abs/1807.06990 . That interface differs from reconstructing the whole density experiment through one classical encoder/decoder.

## Failure ledger and next attack

- Rejected: raw eta,zeta as a necessary criterion for arbitrary references, even with fixed dimension, full rank at each n, bounded scores, fixed radius, and an identifiable parameter map.
- Retained candidate: eta,zeta jointly vanishing could be sufficient. The counterexamples say nothing against sufficiency. A proof must track nontracial transport errors and preserve dimension independence.
- Proved: Delta gives a universal quantitative necessary lower bound, with exact commuting-family characterization.
- Open here: a common classical decoder from uniformly small pairwise Delta, with a bound depending only on fixed k,R (or a dimension-free parameter-net entropy). Pairwise recovery procedures need not share a measurement; that must be proved or refuted.
- Strongest direct next attack: use bounded mutual domination e^(-2R)omega<=rho_b<=e^(2R)omega to convert the pairwise fidelity-affinity condition into a common approximate commuting algebra, or find a finite-state counterexample. Do not substitute separate pairwise optimal measurements for one legal global encoder.

## Independently checked nontracial-to-commuting-reference reduction

This section audits a lemma supplied by the parent. Let S=sqrt(omega), ||S||_2=1, xi=max_i||[A_i,S]||_2, and 0<t<=1. For a common uniform random shift theta in [0,t), partition positive eigenvalues of S into logarithmic bins of width t; put zero eigenvalues into one separate bin. Let B_i=P_theta(A_i), the block pinching. Replace each positive s_a by its bin's lower endpoint and normalize the resulting diagonal S_tilde in Hilbert-Schmidt norm to obtain S'. Then

    e^(-t) S <= S' <= e^t S,
    ||S-S'||_2 <= e^t-1,
    [B_i,S']=0,
    ||B_i||<=1.

For positive s_a,s_b, random bin separation probability is

    min(1,|log(s_a/s_b)|/t)
      <= (3/t) |s_a-s_b|/(s_a+s_b).

This is valid for t<=1: write x=|log ratio|, use the identity ratio=tanh(x/2), and split x<=t and x>=t. Zero-versus-positive pairs satisfy the same bound because their separation probability is one and the right side is 3/t. Zero-versus-zero pairs have separation probability zero.

By Hermitian entry symmetry,

    E ||(A_i-B_i)S||_2^2
      <= (3/(2t)) sum_ab |A_i,ab|^2 |s_a-s_b| (s_a+s_b)
      <= (3/(2t)) ||[A_i,S]||_2
           sqrt(sum_ab |A_i,ab|^2(s_a+s_b)^2)
      <= 3 xi/t.

The last square root is at most 2 because

    sum_ab |A_i,ab|^2(s_a+s_b)^2
      <= 2 sum_ab |A_i,ab|^2(s_a^2+s_b^2)
      = 4 Tr(S^2 A_i^2) <=4.

Hence a common shift has sum_i||(A_i-B_i)S||_2^2<=3kxi/t. In particular every term is <=d^2, d=sqrt(3kxi/t). Entrywise pinching also gives ||[B_i,S]||_2<=xi. Since ||A_i-B_i||<=2, expansion

    [B_i,B_j]-[A_i,A_j]
      =[B_i-A_i,B_j]+[A_i,B_j-A_j]

and movement of S across the right-side factor gives

    ||([B_i,B_j]-[A_i,A_j])S||_2 <=4d+4xi.

Consequently the commuting-reference model has

    eta'=max_ij||[B_i,B_j]S'||_2
         <= e^t (eta+4d+4xi).

The entire sandwich family, rather than merely its first derivatives, is close. For X=sum b_i A_i, Y=sum b_i B_i and V=exp(X/2)S, W=exp(Y/2)S', Duhamel in the orientation

    exp(X/2)-exp(Y/2)
      =(1/2) integral_0^1 exp((1-u)X/2)(X-Y)exp(uY/2)du

places the difference next to S', since [Y,S']=0. Therefore

    ||V-W||_2
      <= e^(R/2)(e^t-1)+(R/2)e^(R/2+t)d.

The partition functions are ||V||_2^2,||W||_2^2 in [e^(-R),e^R]. Normalize V,W to unit Hilbert-Schmidt norm; the resulting positive states are V^dagger V/||V||_2^2 and W^dagger W/||W||_2^2. Their trace distance is bounded by the distance between normalized amplitudes, at most 2e^(R/2)||V-W||_2. Thus

    sup_b T(rho_b,rho'_b)
      <= 2e^R [e^t-1+(R/2)e^t d].

This is dimension-free. Choosing t of order xi^(1/3) makes the reduction O_(k,R)(xi^(1/3)) and eta'=O_k(eta+xi^(1/3)). Combining with the N03 commuting-reference theorem would give a dimension-free sufficient condition eta->0, xi->0; that last composition is CONDITIONAL on N03's source-summary theorem until its proof is reconstructed or acquired. Classical reconstruction error on the original family is at most twice the displayed model-replacement error plus the reconstruction error on the surrogate family, by trace-norm contractivity.

Audit outcome: no defect found in the log-bin reduction or its zero-eigenvalue treatment. The exponent inherited from the N03 quarter-power bound is only xi^(1/12), unless its reconstruction estimate is improved. No claim of rate optimality is made.

## Verified canonical-likelihood lemma for the invariant route

Let rho<=C omega, restrict to the support of omega, and set S=sqrt(omega), Q=sqrt(rho),

    X=S^(-1)(S rho S)^(1/2)S^(-1).

Then X is positive, X<=sqrt(C)I, and rho=X omega X. These follow from operator monotonicity of the square root and squaring SXS=(S rho S)^(1/2).

Write SQ=W P, P=|SQ|, extending the polar partial isometry to a unitary. Its left absolute value is W P W^dagger=(S rho S)^(1/2)=SXS. Consequently SQW^dagger=SXS and QW^dagger=XS. The orientation matters: W^dagger is on the RIGHT of Q. Since omega>=rho/C,

    P=(Q omega Q)^(1/2) >= rho/sqrt(C).

Hence

    ||XS-Q||_2^2
      = ||Q(W^dagger-I)||_2^2
      = 2Tr rho(I-Re W)
      <= 2sqrt(C) Tr P(I-Re W)
      = 2sqrt(C) Delta(omega,rho).

Taking adjoints gives the same bound for ||SX-Q||_2, and therefore

    ||[X,S]||_2 <= 2sqrt(2sqrt(C)Delta(omega,rho)).

No positive lower domination is needed for this lemma. Singular rho is allowed; singular omega is handled by restricting to its support, because rho<=C omega guarantees support inclusion. This is an exact proof, independently derived and checked against the parent's version.

## Verified central pair-commutator bound

Suppose X,Y>=0, ||X||,||Y||<=L, and both commute with omega. Define Z_X=Tr omega X^2, Z_Y analogously, and tau_X=omega X^2/Z_X. With B=XY=UP and P=|B|, the polar factors can be chosen to commute with omega. The root-fidelity/affinity deficit is

    delta=Tr omega P-Tr omega B
         =sqrt(Z_X Z_Y)Delta(tau_X,tau_Y) <=L^2Delta.

Since P^2<=L^2P,

    ||(U-I)P sqrt(omega)||_2^2
      =2Tr omega P^2(I-Re U) <=2L^2 delta.

The two summands in B-B^dagger=(U-I)P-P(U^dagger-I) have equal weighted Hilbert-Schmidt norms. Thus

    ||[X,Y]sqrt(omega)||_2
      <=2sqrt(2L^2delta)
      <=2sqrt(2)L^2sqrt(Delta(tau_X,tau_Y)).

This permits the canonical likelihood operators to be pinched into a central reference model, after which small invariant gaps force small weighted score commutators. Small model-replacement trace errors preserve small Delta because both root fidelity and affinity change by at most sqrt(||rho-rho'||_1)+sqrt(||sigma-sigma'||_1).

For finitely many central likelihoods bounded BELOW by a>0, log embedding yields contraction scores and

    ||[log X,log Y]sqrt(omega)||_2
      <=a^(-2)||[X,Y]sqrt(omega)||_2.

The estimate follows from applying the integral resolvent identity for log twice. It allows N03 to archive the finite likelihood family as coordinate points of one exponential experiment. If only upper domination is assumed, first replace X_i by X_i+hI after central pinching: pair commutators are exactly unchanged, normalized states move by O_C(h), and a fixed h>0 supplies the log floor. Fix h for the desired approximation error, then send the experiment index to infinity. Do not rely on unproved convexity of Delta under state mixing.

The parent is composing these checked lemmas into the following broader candidate: for uniformly trace-total-bounded experiments, a known reference omega INCLUDED in the family, and rho_theta<=C omega with common finite C, vanishing sup_pair Delta is equivalent to asymptotic classical reconstruction. The source N03 reconstruction ingredient must still be proved or supplied. The total-boundedness/net argument must produce ONE common encoder. No universal invariant iff without those interface restrictions is claimed.

## Parent-supplied MUB counterexample independently verified

Without uniform parameter complexity (and without fixed domination), pairwise gap is not sufficient. In prime-power dimension d take all d(d+1) pure states in a complete set of mutually unbiased bases. Distinct within-basis vectors are orthogonal; vectors from different bases have overlap magnitude d^(-1/2). Therefore

    sup_pair Delta = d^(-1/2)-d^(-1) ->0.

The union is a complex projective 2-design, so for psi=|psi><psi|,

    (1/[d(d+1)])sum_psi psi tensor psi
      =(I+Swap)/(d(d+1)).

For any measure-and-prepare Lambda(rho)=sum_z Tr(E_z rho)tau_z,

    average_psi Tr[psi Lambda(psi)]
      =[d+sum_z Tr(E_z tau_z)]/[d(d+1)]
      <=2/(d+1),

because tau_z<=I and sum_z E_z=I. At least one input therefore has

    T(psi,Lambda(psi)) >=1-Tr[psi Lambda(psi)]
                       >=1-2/(d+1) ->1.

This derivation is exact and applies to arbitrary outcome alphabet and decoder states. Primary 2-design source: Klappenecker and Roetteler, Mutually Unbiased Bases are Complex Projective 2-Designs (2005), https://arxiv.org/abs/quant-ph/0502031 . Complete MUBs in prime-power dimension and the design identity are established prior art. The counterexample is not within fixed-k bounded sandwich families: their dimension-independent Lipschitz parameter map supplies bounded net entropy, and their likelihood domination constant is fixed.
