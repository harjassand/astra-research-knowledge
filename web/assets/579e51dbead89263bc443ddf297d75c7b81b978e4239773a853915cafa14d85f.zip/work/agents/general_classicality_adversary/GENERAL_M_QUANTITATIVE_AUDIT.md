# Audit and strengthening of finite-label broadcast extraction

Status: the adaptive extraction, tree composition, and general-m minimax improvement pass independent audit. No selection, posterior, or hidden-label fault was found. The result remains an existence bound with potentially enormous acquisition and preparation costs.

## Original uniform-prior extension

Let m known joint states Omega_x have K tensor leaves. For a design prior pi and an adaptive history h, let p_x=P(X=x|h), sigma_x the conditional state of the next leaf, tau=sum_x p_x sigma_x, and d_x=T(sigma_x,tau). Choose x maximizing p_x d_x^2, and perform the binary Helstrom measurement of sigma_x-tau. Its output distributions q_y and their posterior average q satisfy

    TV(q_x,q)=d_x.

The conditional mutual information is

    J_h=sum_y p_y D(q_y||q)
       >=2p_xd_x^2
       >=(2/m)sum_y p_y d_y^2
       >=(2/m)(sum_y p_y d_y)^2.

Each step is valid: q is exactly the measurement distribution of tau, Pinsker uses natural logarithms, the maximum is at least the average of the m nonnegative p_y d_y^2 quantities, and weighted Jensen gives the last step. Zero posterior labels contribute nothing and may be assigned arbitrary conditional states.

The full adaptive information chain has sum_j J_j<=H(pi). Therefore some index j has J_j<=H(pi)/K. The actual reconstruction performs ONLY the measurements on leaves 1,...,j-1; it does not perform the analyzed measurement on j. Nonselective measurements on those other tensor factors leave leaf j's marginal unchanged. After record h, preparing tau_h yields prior-average leaf reconstruction defect at most

    sum_h p_h sum_x p_x(h)d_x(h)
      <=sqrt(m J_j/2)<=sqrt(m H(pi)/(2K)).

For a uniform prior, converting average defect to the largest label defect by multiplying by m is valid and gives the parent's original sqrt(m^3 ln(m)/(2K)) term. That conversion is loose, not a fault.

## Tree composition and minimax improvement

Suppose a one-to-two broadcaster has marginal trace error <=epsilon for every rho_x. A depth-L binary tree has K=2^L leaves, every one with trace error <=L epsilon. The inductive step uses contractivity plus the guarantee on rho_x itself; it never assumes that intermediate perturbed states remain in the supplied promise set.

For EVERY design prior pi, the extraction above gives an EB channel on the ORIGINAL input H with average loss

    sum_x pi_x T(Lambda_(L,pi)(rho_x),rho_x)
      <=L epsilon+sqrt(m H(pi)/(2K))
      <=u:=L epsilon+sqrt(m ln(m)/(2K)).

The design prior is a precomputation choice, not the actual unknown-label prior. For fixed finite input/output dimensions, EB channels form a compact convex set because their normalized Choi matrices form the closed separable-state subset of the compact CPTP Choi set. The loss

    f(Lambda,pi)=sum_x pi_x T(Lambda(rho_x),rho_x)

is continuous and convex in Lambda and linear in pi. Sion minimax gives

    min_(Lambda EB) max_x T(Lambda(rho_x),rho_x)
      =max_pi min_(Lambda EB) f(Lambda,pi)<=u.

Thus one common EB channel has WORST-label error

    e_m<=L epsilon+sqrt(m ln(m)/(2*2^L)),

removing the extra factor m. There is no minimax reversal: minimization is over the convex channel set, and maximization is over the prior simplex.

For m>=2 and 0<epsilon<=1/2, set L=ceil(log_2(m ln(m)/(2epsilon^2))). Then

    e_m <=epsilon[log_2(m ln(m)/(2epsilon^2))+2]
         =O(epsilon log(m/epsilon)).

The m=1 family is exactly reconstructed by constant preparation. For larger epsilon the logarithm may be nonpositive at m=2, so use L=max(0,ceil(log_2(...))) and the elementary cap e_m<=1. At epsilon=0, letting L tend to infinity gives an infimum of zero; compactness of finite-dimensional EB channels yields exact reconstruction.

## A finite outcome bound survives minimax

The minimax theorem need not hide an ambient-dimension-dependent number of retained classical labels. Each prior-designed extraction decoder measures at most K-1 binary prefix outcomes, so it has at most N=2^(K-1) classical outcomes. The set of N-outcome EB channels on the fixed H is compact: represent a channel by an N-outcome POVM and N preparation states, both lying in compact finite-dimensional sets, and take their continuous image. Padding unused outcomes by zero effects is allowed.

Let A be the closure of the channels produced by the extraction as pi varies. Then A is a compact subset of the N-outcome EB channels. Let V be its compact set of m-coordinate trace-loss vectors. For every pi,

    min_(v in V) pi.v<=u.

The finite-dimensional linear minimax theorem implies that conv(V) contains a vector v* with every coordinate <=u. Caratheodory represents v* as a convex combination of at most m+1 vectors of V. Mix the corresponding at most m+1 channels. Convexity of trace distance makes the mixed channel's losses no larger than v*, and the mixture can retain its random branch together with the prefix record. Its outcome alphabet is at most

    (m+1) 2^(K-1),

or at most K-1+log_2(m+1) bits for an ideal label count. This is dimension-independent for fixed m,K. It is extremely large and is not an efficient memory law.

## Growing trace entropy

For a trace-distance a-net of m=N_n(a) supplied family states, contractivity transfers the finite-net common decoder to the whole experiment with additive error 2a. With broadcaster error b_n,

    e_n<=2a+inf_L[L b_n+sqrt(m ln(m)/(2*2^L))].

For b_n->0, a_n->0, and b_n log N_n(a_n)->0, the explicit choice makes e_n->0. A one-point net has direct constant-preparation error at most 2a_n and requires no broadcasting assumption. The condition permits diverging covering entropy, unlike the earlier uniform-total-boundedness theorem.

Every original input-dependent outcome record is counted in the alphabet bound. The measurements and preparations depend on known ensemble/channel matrices and observed histories, never on the hidden label. Computing the whole joint tree, finding a small-gain index, conditioning, spectral measurements, and the minimax mixture may nevertheless be prohibitively expensive.

## Sources and remaining limits

Primary minimax source: Maurice Sion, On general minimax theorems, Pacific Journal of Mathematics 8(1) (1958), 171-176, https://msp.org/pjm/1958/8-1/pjm-v8-n1-p14-s.pdf ; DOI https://doi.org/10.2140/pjm.1958.8.171 . The convex finite-dimensional specialization used here is elementary and established.

Pinsker, Shannon chain rules, Helstrom measurements, EB Choi compactness, and Caratheodory are established ingredients. The finite-label information extraction resembles the information-chain mechanisms used in approximate broadcasting/quantum Darwinism; priority needs the dedicated historical audit. No runtime, optimal memory, diamond-norm approximation, purification preservation, or independent-copy production follows from this proof.
