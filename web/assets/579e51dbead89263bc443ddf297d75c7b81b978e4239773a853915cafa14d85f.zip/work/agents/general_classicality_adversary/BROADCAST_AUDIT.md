# Independent audit of the approximate two-broadcast converse

Status: no fatal mathematical defect found in the supplied proof sketch. The detailed normal map, support, expectation, and Radon-Nikodym steps below make the proof reviewable. The imported Raynaud theorem is established primary literature; this audit does not reprove it. A complete packaged theorem still needs a consolidated proof and prior-art assessment.

## Interface and desired consequence

For two known input density operators rho_(n,1),rho_(n,2) on H_n, suppose a channel B_n:B(H_n)_* ->B(H_n tensor H_n)_* has BOTH marginal trace distances at most epsilon_n for BOTH input states, and epsilon_n->0. The desired necessary conclusion is

    Delta(rho_(n,1),rho_(n,2))->0.

By contradiction this yields a universal nonconstructive modulus Delta<=v(epsilon), v(epsilon)->0, independent of the input dimension. No parameter entropy hypothesis is required for this necessary implication. The earlier gap-to-classical reconstruction theorem still needs uniform trace total boundedness for sufficient reconstruction of an arbitrary family.

## Normal maps and commuting embeddings

Let M be the Groh-Raynaud von Neumann algebra whose predual is the Banach ultraproduct of the input preduals; define N similarly from output preduals. The coordinate broadcasting maps induce a bounded positive trace-preserving predual map B:M_* ->N_*. Its adjoint Phi:N->M is normal and unital. The exact complete-positivity bridge is available from Raynaud Proposition 5.2, p67: the identification Lambda_p is a COMPLETE ISOMETRY, including p=1, and fixed finite matrix preduals identify compatibly with matrix amplifications of the limit von Neumann algebra. Coordinate CPTP predual maps are completely contractive, their operator-space ultraproduct remains completely contractive, and the complete-isometric identifications preserve this. Their adjoint Phi is consequently unital and completely contractive. Each finite amplification of Phi is unital contractive and therefore positive: composing any state with that amplification gives a norm-one functional taking value one at the unit, hence a positive functional. Since states separate the positive cone, every amplification is positive, so Phi is UCP. This avoids an unsupported assertion about positive cones at matrix levels. Positivity at the scalar level alone would not suffice later for Schwarz and multiplicative domains.

Define each marginal embedding iota_a:M->N as the ADJOINT of the Banach-ultraproduct partial-trace map N_* ->M_*. It is thereby normal UCP without requiring an unproved normal extension of a C* homomorphism. On the weakly dense input C* ultraproduct of bounded operator sequences, it agrees with x_n->x_n tensor I or I tensor x_n. This follows directly from the predual pairing lim_U Tr(rho_n x_n), given by Raynaud's Theorem 1.1 and Fact 1.2, pp44-45.

The restrictions are exact homomorphisms with commuting ranges. Normality and separate ultraweak continuity of multiplication extend both facts to all of M: first fix one coordinate element and pass a net in the other factor to its limit; then fix the first arbitrary limit and pass a net in the remaining factor. A joint strong topology limit is unnecessary. Global injectivity of iota_a is also unnecessary for this proof.

Let T_a=Phi iota_a. Approximate marginal reconstruction makes every ultralimit normal state phi_i invariant under BOTH T_a. Equality first holds on the dense C* ultraproduct by the vanishing trace-norm marginal defect, and then extends to M by normality.

## Support reduction

Let phi=(phi_1+phi_2)/2 and p=supp(phi). All phi_i are supported on p, because phi_i<=2phi. Restrict the input algebra to pMp; phi becomes faithful there. KEEP the output algebra N uncompressed.

Set Phi_p(y)=pPhi(y)p, a normal UCP map N->pMp. It is unital with respect to unit p. Restrict iota_a to pMp; this restriction need not be unital into N: iota_a(p) can differ from 1_N. That is harmless.

The reduced T_(a,p)=Phi_p iota_a:pMp->pMp is unital. Indeed, 0<=T_a(p)<=1, and phi(T_a(p))=phi(p)=1. Hence pT_a(p)p=p by faithfulness of phi on pMp, which is exactly T_(a,p)(p)=p. Every reduced phi_i remains invariant, since phi_i(p y p)=phi_i(y).

## A normal fixed-point expectation, proved directly

Write T=(T_(1,p)+T_(2,p))/2. It is normal UCP and phi-preserving. Its fixed-point set F is a von Neumann algebra: for x fixed, Schwarz gives T(x^*x)>=x^*x; phi-preservation and faithfulness force equality. Both x and x^* lie in the multiplicative domain of T, so products of fixed points remain fixed. The set is ultraweakly closed by normality.

Take Cesaro maps C_k=(1/k)sum_(r=0)^(k-1)T^r. A GLOBAL pointwise-ultraweak cluster subnet exists by compactness of the product of the bounded output balls. Its limit E is UCP, satisfies phi E=phi, and T E=E T=E because ||T C_k-C_k||<=2/k and T is normal. It is identity on F. Thus E is a projection onto F.

E is normal, even though a pointwise-ultraweak cluster limit of normal maps need not generally be normal. For 0<=x_lambda increasing to x, let y=sup E(x_lambda)<=E(x). Normality of phi and phi E=phi give phi(E(x)-y)=0; faithfulness forces equality. This is the required monotone continuity. Multiplicative-domain equality on F makes E bimodular over F. Every phi_i is E-invariant, by invariance under T and normality of phi_i.

## Common fixed points and commutativity

If x is fixed by T, then T_(1,p)x=T_(2,p)x=x. The two maps act as contractions for the Hilbert norm ||x||_(2,phi)^2=phi(x^*x). Their average fixes x, and strict convexity forces both images to equal x. Equivalently, expand the two-image variance and use Schwarz plus phi-preservation. Faithfulness turns Hilbert equality into operator equality.

For x in F, both x^*x and xx^* lie in F and are fixed by each reduced T_a. Hence iota_a(x) belongs to the multiplicative domain of the UNITAL map Phi_p, since

    Phi_p(iota_a(x)^*iota_a(x))=x^*x
      =Phi_p(iota_a(x))^*Phi_p(iota_a(x)),

and similarly for the other product. The nonunital restriction of iota_a causes no problem in this argument. For x,y in F, multiplicative-domain bimodularity and commutation of the iota ranges give

    xy=Phi_p(iota_1(x)iota_2(y))
      =Phi_p(iota_2(y)iota_1(x))=yx.

Thus F is abelian.

## Centralizer and the exact density conclusion

Since E is phi-preserving, F-bimodular, and F abelian, for f in F and x in pMp,

    phi(fx)=phi(E(fx))=phi(fE(x))
      =phi(E(x)f)=phi(E(xf))=phi(xf).

Therefore F is contained in the centralizer of phi.

On the abelian algebra F, the normal positive functional phi_i|F is dominated by 2phi|F. Classical Radon-Nikodym gives 0<=f_i<=2p with f_i in F and phi_i(y)=phi(f_i y) for y in F. Since phi_i E=phi_i,

    phi_i(x)=phi_i(E(x))=phi(f_i E(x))=phi(f_i x)

for all x in pMp. The last equality uses E bimodularity and phi-preservation.

The Haagerup density h_i of phi_i is therefore f_i h_phi. The centralizer inclusion means f_i commutes strongly with h_phi. The f_i commute mutually because F is abelian. Hence all h_i commute strongly in the common measurable crossed-product algebra. Their positive square roots multiply to a positive L1 element; Delta(phi_1,phi_2)=0.

Raynaud's positivity, Mazur/root, L2 Hilbert inner-product, and product compatibility identify this limiting gap with lim_U Delta(rho_(n,1),rho_(n,2)). A sequence with gap bounded below and epsilon_n->0 would therefore contradict the limiting zero gap.

## Audit conclusions and exact caveats

- The support compression is legal while leaving output N uncompressed.
- The marginal embeddings must be constructed via predual adjoints; an arbitrary normal extension cannot simply be assumed.
- Their reduced restrictions need NOT be unital; only Phi_p and the reduced composites T_a need be unital.
- A faithful invariant state gives normality of the expectation; pointwise cluster limits alone do not give normality.
- The Radon-Nikodym operators first belong to F by restricting the functionals to F, then lift via E. Domination on pMp alone would not automatically place them in the abelian fixed algebra.
- Complete positivity of the ultraproduct channel and marginal maps is justified by Raynaud Proposition 5.2 complete isometry, preserved complete contractivity, and the elementary unital-complete-contraction argument above. A consolidated proof should spell it out.
- The result is a nonconstructive dimension-free modulus. No explicit v, optimal cloning error, efficient decoder, or unrestricted gap-to-classical sufficiency is obtained.

Primary source for all ultraproduct identifications: Yves Raynaud, On ultrapowers of non commutative Lp spaces, J. Operator Theory 48 (2002), 41-68, https://www.theta.ro/jot/archive/2002-048-001/2002-048-001-003.pdf . Theorem 1.1 / Fact 1.2 pp44-45; L0 core recap pp57-58; Theorem 3.6 pp59-60; Theorem 5.1 p66; Proposition 5.2 p67 complete isometry; varying-algebra applicability p42.
