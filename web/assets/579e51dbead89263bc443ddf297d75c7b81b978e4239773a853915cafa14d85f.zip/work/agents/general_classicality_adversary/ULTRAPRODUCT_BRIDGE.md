# Audit of the finite-mixture bridge without domination

This is an adversarial audit of a route proposed by the parent, rather than a priority claim. It uses an established noncommutative Lp ultraproduct theorem. The direct finite-dimensional decoder after the bridge is in SIMULTANEOUS_PINCHING.md.

## Claim

For every fixed finite m, there is a dimension-independent qualitative modulus f_m(delta)->0 with the following property. For any m density operators rho_1,...,rho_m in any finite dimension, if

    max_ij Delta(rho_i,rho_j)<=delta,
    omega=(1/m)sum_i rho_i,

then max_i Delta(omega,rho_i)<=f_m(delta).

The route below proves existence of a modulus by contradiction, not an explicit rate. The modulus can be defined as the supremum over all dimensions and such tuples; it is bounded by one.

## Precise imported theorem

Yves Raynaud, On ultrapowers of non commutative Lp spaces, Journal of Operator Theory 48 (2002), 41-68.

Primary PDF: https://www.theta.ro/jot/archive/2002-048-001/2002-048-001-003.pdf

The locally read exact source is shared read-only at work/agents/general_classicality/sources/Raynaud2002.txt, with its PDF alongside.

- Introduction, p42: all results hold for ultraproducts of a family of Lp spaces, not only fixed-algebra ultrapowers. This is essential because matrix dimensions vary.
- Haagerup construction recap, pp57-58: all Lp(A) spaces are realized in the ONE associative involutive algebra L0(core,trace) of measurable affiliated operators. L1 is the predual, and its canonical Tr is evaluation at the unit. The L2 inner product is Tr(k^*h).
- Theorem 3.6, pp59-60: simultaneous linear bijective isometries Lambda_p preserve positivity and conjugation and intertwine the Mazur maps. Thus positive squares and their inverse square roots pass to the ultraproduct correctly.
- Theorem 5.1, p66: these identifications preserve the products Lp x Lq ->Lr for 1/p+1/q=1/r. In particular, positive root products L2 x L2 ->L1 are identified in the same Haagerup realization.

## Contradiction proof

Suppose the claim fails for some fixed m. Then there are dimensions d_n and tuples rho_(n,i) with all pair gaps tending to zero, while one mixture gap stays above a fixed epsilon>0 along a subsequence. Pass to that subsequence and one fixed i by the finite pigeonhole principle. Let Q_(n,i)=sqrt(rho_(n,i)), of L2 norm one.

Take a free ultrafilter and use Raynaud's simultaneous identifications to obtain positive a_i in L2(A), each of norm one. Product compatibility and preservation of the Hilbert L2 inner product imply

    ||a_i a_j||_1 = lim_U ||Q_(n,i)Q_(n,j)||_1,
    Tr(a_i a_j) = lim_U Tr(Q_(n,i)Q_(n,j)).

Their difference is zero. In L1(A)=A_*, equality ||c||_1=Tr(c) forces c positive: a bounded normal functional whose norm equals its value at the unit is positive. Therefore a_i a_j is positive, hence

    a_i a_j=(a_i a_j)^*=a_j a_i

in the measurable operator algebra of the crossed product.

The unbounded operator point must be handled carefully. Equality on an arbitrary common dense domain would NOT suffice for strong commutation. Here it is equality in the associative measurable *algebra L0(core,trace), so bounded inverses can be multiplied algebraically. For each positive a_i, r_i=(1+a_i)^(-1) is bounded, affiliated with the core and therefore belongs to the core von Neumann algebra. It is a genuine two-sided inverse in L0. From (1+a_i)a_j=a_j(1+a_i), multiply by r_i on both sides to obtain r_i a_j=a_j r_i. Invert 1+a_j similarly to obtain r_i r_j=r_j r_i.

The r_i are bounded commuting positive selfadjoint operators. Functional calculus recovers the spectral projections of a_i from r_i (the map x->1/(1+x) is injective on [0,infinity)), so a_i and a_j strongly commute. All finite sums, products, and functional calculi of the a_i therefore lie in one common abelian measurable algebra.

Set

    h=(1/m)sum_i a_i^2 in L1(A)+,
    b=sqrt(h) in L2(A)+.

Strong commutation makes every b a_i positive. Therefore ||b a_i||_1=Tr(b a_i). By linearity, product compatibility, positivity, and the Mazur/root compatibility,

    b = ultraproduct limit of sqrt((1/m)sum_i rho_(n,i)).

Again norm and Hilbert inner product compatibility identify its pair gap with the ultralimit of Delta(omega_n,rho_(n,i)), which is consequently zero. This contradicts the chosen epsilon lower bound and proves the qualitative finite-mixture modulus.

## Consequence for finite state families

The mixture omega dominates each rho_i by rho_i<=m omega. Add omega to the finite family. The original gaps tend to zero, and the bridge makes all new reference gaps tend to zero. The direct dominated-reference proof in SIMULTANEOUS_PINCHING.md then gives one finite classical encoder/decoder reconstructing the entire finite family with vanishing error.

For uniformly trace-total-bounded families, take a fixed-tolerance finite net, use its average as the known reference, reconstruct the net, and transfer to the full family by trace-norm contractivity. Let the tolerance tend to zero after the experiment index. This removes the need for an originally included dominating reference.

Thus the wider candidate criterion is:

    Uniform trace total boundedness + sup_pair Delta->0
      iff vanishing uniform measure-and-prepare reconstruction error.

Total boundedness means that at every positive trace-distance tolerance, all experiments admit covers by at most one finite N(tolerance), uniformly over the experiment index and dimension. The MUB counterexample in REPORT.md blocks the unrestricted version without such parameter complexity control.

## Audit limits

- The source theorem and its exact interfaces have been checked. Raynaud's entire proof was not independently reproved.
- The measurable inverse argument is valid because the elements lie in the same measurable *algebra; no claim is made for arbitrary densely defined unbounded operators.
- The modulus f_m is nonconstructive. No explicit uniform threshold, efficient compilation, computational runtime, preparation bound, or optimal number of classical outcomes follows from the ultraproduct step.
- The finite decoder after the bridge is constructive given known matrices, a numerical target, and the relevant defects, though absent an explicit f_m the bridge does not supply a numerical threshold from delta alone.
- Novelty is unestablished. Exact no-broadcasting, Lp ultraproducts, and almost-commuting spectral binning are established ingredients. A focused prior-art search for precisely this state-family invariant criterion remains necessary.
