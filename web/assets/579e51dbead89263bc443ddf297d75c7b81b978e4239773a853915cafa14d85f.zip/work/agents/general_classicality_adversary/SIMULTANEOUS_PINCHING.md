# A self-contained finite-family classical decoder

This is a direct proof mechanism that removes dependence on N03's unprovided sufficiency proof. It is a weighted version of the standard spectral-binning mechanism for almost commuting selfadjoint matrices; no novelty or optimal-rate claim is made. The matrices and reference are known inputs; diagonalization/preparation complexity is uncharged here and must not be inferred to be efficient.

## Simultaneous pinching lemma

Let Omega be a finite-dimensional density operator. Let m be fixed and let 0<=X_j<=L I commute EXACTLY with Omega. Put

    eta=max_ij ||[X_i,X_j]sqrt(Omega)||_2.

For every fixed m,L there is a dimension-independent modulus g_(m,L)(eta)->0 such that one can find positive mutually commuting Y_j, commuting with Omega, with ||Y_j||<=L and

    max_j||(X_j-Y_j)sqrt(Omega)||_2<=g_(m,L)(eta).

Moreover all Y_j can be chosen with finitely many eigenvalues, with a bound on their joint number of eigenspaces depending only on m,L and the approximation target, not ambient dimension.

Proof. Process j=1,...,m sequentially. All current matrices commute with Omega, and all earlier rounded matrices commute with every current matrix. At step r, let the current future commutator defect be at most mu_r. Diagonalize the current X_r jointly with Omega and earlier rounded matrices. Randomly shift LINEAR spectral bins of width h_r. For every future X_j, pinching into those bins gives

    E ||(X_j-P_theta X_j)sqrt(Omega)||_2^2
      <= (1/h_r) sum_ab |X_j,ab|^2 w_b |x_r,a-x_r,b|
      <= (1/h_r)||[X_r,X_j]sqrt(Omega)||_2
                       ||X_j sqrt(Omega)||_2
      <= L mu_r/h_r.

Here w_b is the reference eigenvalue at b. The random separation probability is min(1,|x_r,a-x_r,b|/h_r). All matrices centralize Omega, so the weighted norm is tracial on the generated algebra. A common shift has total future squared error at most (m-r)L mu_r/h_r. Write

    d_r=sqrt((m-r)L mu_r/h_r).

Round the current X_r to bin centers clipped to [0,L]; its operator-norm change is at most h_r. Pinch each future matrix, changing its weighted norm by at most d_r and preserving positivity, the norm bound, and commutation with Omega and earlier rounded matrices. The rounded X_r is constant on every pinching block and therefore commutes exactly with all future matrices.

The pair commutator defect among future pinched matrices grows by at most 4L d_r. Indeed, writing B_i=pinch(X_i), D_i=B_i-X_i,

    [B_i,B_j]-[X_i,X_j]=[D_i,B_j]+[X_i,D_j],

and traciality with respect to Omega implies

    ||[D_i,B_j]sqrt(Omega)||_2<=2L||D_i sqrt(Omega)||_2,

and similarly for the other summand. Thus mu_(r+1)<=mu_r+4L d_r. Previously rounded matrices are left unchanged and stay central.

A completely explicit loose modulus is obtained from an arbitrary positive upper bound nu>=eta. Set v_1=nu; recursively take

    h_r=v_r^(1/3),
    d_r<=sqrt((m-r)L)v_r^(1/3),
    v_(r+1)=v_r+4L sqrt((m-r)L)v_r^(1/3).

At the last step choose h_m=v_m^(1/3) and only round X_m. For fixed m,L all v_r,h_r,d_r go to zero with nu. Every original matrix changes by at most sum_(r<j)d_r+h_j in weighted norm. Each Y_j has at most ceil(L/h_j)+2 possible values. The joint spectral partition therefore has at most the product of those bounds. This proves the lemma. The case eta=0 uses arbitrarily small positive nu; no division by zero is required.

## Exact decoder for the final commuting likelihood family

For each j with Z_j=Tr(Omega Y_j^2)>0 define

    sigma_j=Omega Y_j^2/Z_j.

Let P_z be the joint spectral projections of all Y_j. Measure {P_z}. Decode z by preparing

    tau_z=P_z Omega P_z / Tr(Omega P_z),

omitting zero-reference-weight labels. Since all Y_j commute with Omega and are constant on P_z, this one decoder exactly reconstructs every sigma_j. The alphabet is the finite joint-partition size just bounded. Diagonalizing Omega itself is unnecessary; reference variation within a cell is preserved by the known conditional reference state.

## Transfer from approximate likelihood matrices to states

If rho_j=X_j Omega X_j/Tr(Omega X_j^2), and the initial amplitudes X_j sqrt(Omega) have norms bounded below by a>0, then

    T(rho_j,sigma_j)<=2||(X_j-Y_j)sqrt(Omega)||_2/a.

To see this, normalize the two Hilbert-Schmidt amplitudes; their distance is at most twice the amplitude difference divided by the initial norm. Trace distance between the corresponding products VV^dagger is at most the normalized amplitude distance. The common decoder that fixes sigma_j consequently reconstructs rho_j with error at most twice this trace distance, by contractivity.

## Composition with invariant gaps and a nontracial reference

Assume a finite m-state family includes omega and satisfies rho_j<=C omega. The geometric canonical likelihoods

    X_j=omega^(-1/2)(omega^(1/2)rho_j omega^(1/2))^(1/2)omega^(-1/2)

satisfy X_j>=0, ||X_j||<=sqrt(C), rho_j=X_j omega X_j, and their original amplitude norms equal one. The independently verified polar lemma yields

    ||[X_j,sqrt(omega)]||_2
      <=2sqrt(2sqrt(C)Delta(omega,rho_j)).

If the uniform pair gap tends to zero, logarithmic reference-spectrum pinching (audited in REPORT.md) makes a nearby family omega' X_j'^2/Z_j with central positive likelihoods X_j'. Model replacement errors tend to zero; the fidelity-affinity gap is continuous in trace distance, so the surrogates retain vanishing pair gaps. The central polar estimate then yields

    max_ij||[X_i',X_j']sqrt(omega')||_2 ->0.

Apply the simultaneous pinching lemma DIRECTLY to these positive likelihoods. No log embedding, lower likelihood bound, regularization, or N03 theorem is needed. Their amplitude norms stay close to one because the surrogate states arose from vanishing amplitude perturbations. The final finite-partition decoder therefore reconstructs the original finite family with vanishing uniform trace distance.

For an arbitrary sequence of uniformly trace-total-bounded state families, take a finite trace-distance r-net, add the included reference if needed, and apply the finite-family result. A common reconstruction channel with net error e has full-family error at most e+2r. Fix r, let the experiment index tend to infinity, then let r tend to zero. This proves a qualitative dimension-independent sufficient condition:

    known included omega_n,
    rho_(n,theta)<=C omega_n with ONE fixed C,
    uniform trace total boundedness,
    sup_(theta,theta') Delta(rho_(n,theta),rho_(n,theta'))->0.

The reverse implication is the general Delta<=2sqrt(2epsilon) bound. Hence these assumptions support an iff criterion. The proof is mathematical and nonasymptotic at each fixed net size; it supplies no efficient decoder compiler or uniform optimal memory law. A formal writeup and independent validation of the whole composition are still required before promotion beyond internally derived theorem status.

## Bounded sandwich families meet the domination and entropy hypotheses

For ||sum_i b_i A_i||<=R and Z_b=Tr omega exp(sum_i b_i A_i) in [e^(-R),e^R],

    e^(-2R)omega <=rho_b<=e^(2R)omega.

The reference omega is rho_0. Duhamel applied to exp(X/2) gives a dimension-independent Lipschitz bound

    T(rho_b,rho_c)<=e^R||b-c||_1.

Thus fixed k,R yield trace-net cardinality bounds depending only on k,R and the net tolerance. The counterexamples in REPORT.md show why the criterion must use the actual states (or their canonical geometric likelihoods), rather than arbitrary raw sandwich scores.

## Prior-art pointers

Glebsky, Almost commuting matrices with respect to normalized Hilbert-Schmidt norm (2010), https://arxiv.org/abs/1002.3082 . Its fixed-family almost-commuting framework is directly relevant prior art to the simultaneous pinching mechanism. Bansil and Kachkovskiy, On almost commuting matrices with respect to the normalized Hilbert-Schmidt norm (2026), https://arxiv.org/abs/2608.31000 , gives an improved optimal pair exponent under an additional commuting-with-one-input constraint. These sources were found by primary-source browsing; their exact proofs were not yet fully read in this subtask. The weighted central-reference proof above is supplied in full rather than delegated to those results.
