# Independent broadcast-converse audit

Status: no fatal defect found in the supplied sketch or the subsequently saved BROADCAST_CRITERION.md. The full parent file has now been independently read. Its normal-extension, support-reduction, fixed-point expectation and centralizer arguments match the valid contracts checked below. This remains an internal mathematical audit, not external validation or a priority claim.

## Normal embeddings: construct them as predual adjoints

At coordinate n let A_n=B(H_n), B_n=B(H_n tensor H_n), let beta_n:(A_n)_* -> (B_n)_* be the broadcasting channel, and let r_(a,n):(B_n)_* -> (A_n)_* be partial trace over the other output. Raynaud Theorem 1.1 identifies the Banach predual ultraproducts with M_* and N_*. Fact 1.2 and the proof of Theorem 1.1, pp44-45, preserve the pairing with the weakly dense C*-algebra ultraproduct:

    <[rho_n],[x_n]> = lim_U Tr(rho_n x_n).

The bounded coordinate maps therefore yield beta:M_* -> N_* and r_a:N_* -> M_*. Their adjoints Phi=beta^* and iota_a=r_a^* are NORMAL UCP maps. On the C* ultraproduct cores,

    iota_1([x_n])=[x_n tensor I],
    iota_2([x_n])=[I tensor x_n].

The cores are weakly dense. Their maps are homomorphisms and have commuting ranges. Separate ultraweak continuity of multiplication and normality extend both properties to all of M: first extend in one variable while keeping the other in the core, then extend the other variable. Matrix-level positivity similarly passes from the core to its von Neumann closure. This supplies a legal normal-extension proof; weak density by itself, without the predual adjoints, would not.

Approximate reconstruction in trace norm makes each limiting normal state phi_i invariant under T_a=Phi iota_a. The mean phi=(1/m)sum_i phi_i is invariant too.

## Support reduction: the embeddings become nonunital

Let p=supp(phi), M_p=pMp, and retain N uncompressed. Define

    Phi_p(y)=p Phi(y)p,
    j_a(x)=iota_a(x), x in M_p,
    T_(a,p)=Phi_p j_a.

Phi_p is unital into M_p, whose identity is p. The j_a are normal commuting *-homomorphisms, but are NOT generally unital: j_a(p)=iota_a(p) need not equal 1_N. This does not break the proof.

Indeed T_(a,p)(p)<=p and

    phi(T_(a,p)(p))=phi(T_a(p))=phi(p)=1.

Faithfulness of phi on M_p implies T_(a,p)(p)=p. Thus both compressed marginal maps are unital, normal CP, and phi-preserving. The phi_i remain invariant after compression because each is supported on p. Keeping N uncompressed preserves the commuting output embeddings exactly.

## Fixed-point algebra and a normal expectation without extra assumptions

Let T=(T_(1,p)+T_(2,p))/2. If Tx=x, Schwarz implies T(x^*x)>=x^*x. The positive difference has phi-expectation zero, so faithfulness implies equality, and likewise for xx^*. Every fixed point belongs to the multiplicative domain of T; therefore the fixed points F form an ultraweakly closed *-algebra.

F is contained in each marginal fixed-point algebra. One explicit proof uses the phi-Hilbert norm: both marginal maps are contractions by Schwarz and phi-invariance, while their average is x. Strict convexity gives T_(1,p)x=T_(2,p)x=x. Equivalently apply phi to

    (T_(1,p)x-T_(2,p)x)^*(T_(1,p)x-T_(2,p)x)/4

and use T(x^*x)=x^*x.

To obtain E, take one simultaneous ultraweak cluster subnet of the Cesaro averages S_k=(1/k)sum_(r=0)^(k-1)T^r, as maps on all elements (product compactness). Telescoping gives (I-T)S_k ->0 in operator norm pointwise. Thus E maps into F, fixes F, is UCP, and preserves phi and every phi_i. E is F-bimodular by its own multiplicative-domain identity.

E is NORMAL: if x_alpha decreases to zero in M_p^+, then E(x_alpha) decreases to some y>=0, and phi(y)=lim phi(E(x_alpha))=lim phi(x_alpha)=0. Faithfulness implies y=0. This avoids assuming a stronger pointwise Cesaro convergence theorem or a normal expectation without proof.

## Abelianness and reconstruction of the state densities

For x in F, both x and x^*x are fixed by each T_(a,p). Therefore

    Phi_p(j_a(x))=x,
    Phi_p(j_a(x)^*j_a(x))=x^*x,

and similarly for xx^*. Hence j_a(x) lies in the multiplicative domain of the UNITAL map Phi_p. The nonunitality of j_a is irrelevant to these identities. Since the two ranges commute,

    xy=Phi_p(j_1(x)j_2(y))
      =Phi_p(j_2(y)j_1(x))=yx.

Thus F is abelian. Bimodularity of E and phi-preservation imply for x in F and y in M_p,

    phi(xy)=phi(x E(y))=phi(E(y)x)=phi(yx),

so F lies in the phi-centralizer; this conclusion needs no modular-theory theorem.

The restrictions phi_i|F satisfy phi_i<=m phi. Classical Radon-Nikodym therefore gives 0<=f_i<=m with f_i in F and phi_i(z)=phi(f_i z) for z in F. As phi_i E=phi_i,

    phi_i(y)=phi(f_i E(y))=phi(f_i y), y in M_p.

The Haagerup densities are h_(phi_i)=f_i h_phi. The f_i commute with one another and with h_phi by the centralizer property. Their positive density roots therefore strongly commute and have positive pair products. In the limiting algebra their root-fidelity minus affinity gaps vanish. Raynaud Theorem 3.6 and Theorem 5.1 transfer root products, L1 norms and canonical traces back to the coordinate ultralimit.

## Scope and disposition

The normal embeddings and support reduction pass. The necessary clarifications are: explicitly construct embeddings using partial-trace predual adjoints; do not call j_a unital after support compression; prove E normal as above; and state that Radon-Nikodym densities first belong to the abelian fixed algebra and then lift using phi_i E=phi_i. Subject to these details, the converse compactness argument is valid and supplies a qualitative dimension-independent finite-family modulus. It does not supply an explicit rate, finite precision compiler, or preparation-complexity bound.

The final parent file states these details correctly. Its alternative use of the Hilbert mean ergodic theorem is legal: bounded Cesaro means converging in the phi-Hilbert norm have an ultraweak cluster point whose phi-Hilbert vector is the same limit, since phi(z^* C_k(x)) converges against every z in R. Faithfulness makes that cluster point unique. The corner Haagerup densities extend by zero to the full core, so the final root-gap comparison applies to the original limit states. For fixed finite dimension the broadcasting-channel infimum is attained by compactness of the Choi channel set; alternatively the stated monotone/right envelope convention handles an infimum. No quantitative rate is supplied by this compactness step.
