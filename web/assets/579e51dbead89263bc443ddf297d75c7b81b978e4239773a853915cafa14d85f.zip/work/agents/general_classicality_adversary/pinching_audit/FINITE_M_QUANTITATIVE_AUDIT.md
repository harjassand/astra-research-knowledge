# Finite-label quantitative broadcast audit

Status: no fatal issue found. The arbitrary-prior extraction and Sion minimax improvement are valid. I read EXPLICIT_PAIR_BOUND.md and the initial GENERAL_M_BROADCAST_BOUND.md. The latter's conservative uniform-prior m^3 bound is valid; the minimax argument improves m^3 to m.

## Conditional information inequality

Fix any design prior pi on m known labels and any known joint output family Omega_x on K copies of the same H. At a prefix history h, let p_x be the posterior, sigma_x the conditional state of the next leaf, tau=sum_x p_x sigma_x, and d_x=T(sigma_x,tau). Select x_h maximizing p_x d_x^2 and measure a binary Helstrom projector for sigma_(x_h) versus tau. Its conditional outcome distributions q_x have mixture q=sum_x p_x q_x, and

    TV(q_(x_h),q)=d_(x_h).

Classical Pinsker in natural logarithms therefore gives

    J_h=sum_x p_x D(q_x||q)
       >=2 max_x p_x d_x^2
       >=(2/m) sum_x p_x d_x^2
       >=(2/m) (sum_x p_x d_x)^2.

All inequalities are correct. Labels with zero posterior contribute nothing. Histories impossible under the design prior can be completed with arbitrary legal measurements and preparations, so the construction remains a channel even on zero-prior labels.

Build the whole adaptive leaf sequence to define g_j=I(X:Y_j|H_(j-1)). The information chain gives sum_j g_j<=H(pi)<=ln(m), hence some j has g_j<=H(pi)/K. The index j and measurement decisions depend only on the known joint family, known prior and previous measured record, never on the actual unknown input label.

## Prefix-only recovery is a legal EB map

Perform only stages 1,...,j-1. On outcome h prepare tau_h for the selected leaf. Those prefix measurements act only on other tensor factors, so their nonselective action preserves the selected leaf's original marginal. Therefore

    sum_x pi_x T(E'_pi(Omega_x),Omega_(x,j))
       <=sum_h P(h) sum_x p_x(h) d_x(h)
       <=sqrt((m/2)sum_h P(h)J_h)
       <=sqrt(m H(pi)/(2K)).

For K=2^L broadcast-tree outputs, every leaf is within L epsilon of the corresponding original rho_x. This remains valid although intermediate perturbed states are outside the promised ensemble: contractivity compares them to T_a(rho_x), for which the original one-step guarantee applies.

Composing the prefix POVM with the known CPTP broadcast tree gives a POVM on the original H. The tau_h are fixed known states. Thus for EVERY prior pi there exists an EB channel E_pi:H->H with

    sum_x pi_x T(E_pi(rho_x),rho_x)
       <=L epsilon+sqrt(m H(pi)/(2*2^L))
       <=A_L:=L epsilon+sqrt(m ln(m)/(2*2^L)).

This does not yet assert the SAME E_pi works for all priors. The minimax step below supplies the common channel.

## Exact minimax justification

Let C be the set of all EB channels H->H. In finite dimension, their Choi operators form a closed bounded set of separable positive operators satisfying the channel affine constraints. C is therefore COMPACT and CONVEX. For each label x define

    ell_x(E)=T(E(rho_x),rho_x).

Each ell_x is continuous and convex in E. The payoff f(E,pi)=sum_x pi_x ell_x(E) is continuous, convex in E and linear, hence concave, in pi. Sion's theorem on C and the finite probability simplex gives

    min_(E in C) max_x ell_x(E)
       = max_pi min_(E in C) f(E,pi)
       <= A_L.

The minimum is attained, so ONE legal EB channel has worst-label error at most

    L epsilon+sqrt(m ln(m)/(2*2^L)).

The prior dependence of the intermediate construction creates no information leak. It is only used to bound every inner minimization. The final channel is chosen using the known ensemble, independently of its unknown label. EB convexity also permits randomized mixtures of legal measure-and-prepare maps. No unrestricted recovery-channel enlargement is used.

This is an existence/minimax construction. It does not imply that one chosen prior's prefix map is itself the minimax channel, or that efficient optimization over the EB Choi set is available.

## Improved constants and costs

For m>=2 and 0<epsilon<=1, take

    L=max(0,ceil(log_2(m ln(m)/(2 epsilon^2)))).

This yields

    e(E)<=epsilon [2 log_2(1/epsilon)
                     +log_2(m)+log_2(ln(m)/2)+2],

with the trivial cap at one. For m=2 and epsilon near one the logarithm can be negative, so do not claim it is always positive; the displayed max with zero makes the depth convention explicit. The ceiling is already nonnegative in the stated range, but that fact should not be replaced by the false positivity claim. The specialized binary identity remains sharper than the generic minimax estimate.

The improved tree leaf count is O(m ln(m)/epsilon^2), versus O(m^3 ln(m)/epsilon^2) for the conservative direct uniform-prior conversion. There are K-1 uses of the original broadcasting channel. The actual adaptive prefix can still have exponentially many records in K, and the minimax EB selection can be expensive. No efficient compiler follows.

The net extension likewise improves to

    e_n<=2a+L b_n+sqrt(N_n(a) ln(N_n(a))/(2*2^L)).

The sufficient growing-entropy condition b_n log N_n(a_n)->0, with b_n->0 and a_n->0, survives with the improved constant. This is a bound on marginal reconstruction, not independent cloning or preservation of a purification.

## Disposition

Selection, conditional information, prefix-only preparation, broadcast iteration and minimax all pass. The parent can safely replace m^3 by m in the finite-label bound and its tree cost. Preserve the existence-versus-efficient-compilation qualification and the requirement that all selected broadcast leaves have the same output Hilbert space H for the common-channel minimax set.

## Finite outcome control through loss-vector minimax

The sharper bound can retain a finite alphabet. Every prior-designed binary-prefix decoder uses at most N=2^(K-1) outcomes. For fixed H, the set EB_N of channels with at most N outcomes is compact: it is the continuous image of the compact parameter set of N positive POVM effects summing to I and N density preparation states. Shorter channels are padded by zero effects. Although EB_N need not be convex, the closure A of the candidate prefix-channel family remains compact inside it.

Let V={(ell_1(E),...,ell_m(E)):E in A}; V is compact in R^m. Every prior has min_(v in V) pi dot v<=u. The convex hull of V is compact by finite-dimensional Caratheodory, and linear minimax gives v* in conv(V) with every coordinate at most u. Represent v* by at most m+1 vectors from V. Mix their corresponding decoders with the same coefficients. Convexity of trace distance makes the mixed channel's loss coordinate at most v*'s coordinate. The explicit mixed POVM effects are lambda_l M_(l,z), with preparation states tau_(l,z). Therefore the common decoder has at most (m+1)N=(m+1)2^(K-1) outcomes.

No closure, mixing or outcome-count defect found. This bounds the classical alphabet; it does not bound finite precision for POVM effects, mixing weights, preparations or the computation required to choose them.
