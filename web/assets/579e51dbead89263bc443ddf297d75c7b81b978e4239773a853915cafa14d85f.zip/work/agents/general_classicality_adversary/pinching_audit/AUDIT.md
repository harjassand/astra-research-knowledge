# Independent pinching and decoder audit

Status: no fatal counterexample or hidden nontracial defect found in the stated finite-dimensional theorem. The proof below closes the one transport step that was only referenced in SIMULTANEOUS_PINCHING.md. This is an internal mathematical audit, not external validation or a priority claim.

## Exact likelihood-to-central-state transport

Let the finite family have m members, rho_j <= C omega, let S=sqrt(omega), L=sqrt(C), and let X_j be the positive canonical likelihoods. Restrict to supp(omega). Then

    0 <= X_j <= L I, rho_j = X_j omega X_j,
    ||X_j S||_2 = 1.

The polar calculation in REPORT.md has the correct orientation Q W^* = X S. It proves

    xi := max_j ||[X_j,S]||_2 <= 2 sqrt(2 L delta),
    delta := sup_(i,j) Delta(rho_i,rho_j),

because the included reference is one of the rho_j. No lower domination is used.

Apply one common shifted logarithmic binning of S, width 0<t<=1, set B_j=P_theta(X_j), and round/normalize S to S'. Entry symmetry and the log separation estimate give

    E ||(X_j-B_j)S||_2^2 <= 3 L xi/t.

Indeed the final Cauchy-Schwarz factor is at most 2L; the contraction-case formula therefore acquires exactly one factor L. One common shift has

    max_j ||(X_j-B_j)S||_2 <= d := sqrt(3m L xi/t).

The positive B_j satisfy ||B_j||<=L and commute EXACTLY with S'. Put Omega'=S'^2. Since ||S-S'||_2<=e^t-1,

    ||X_j S-B_j S'||_2 <= q := d+L(e^t-1).

If q<1, a_j=||B_j S'||_2 >=1-q>0. Define

    tau_j=B_j Omega' B_j/a_j^2 = Omega' B_j^2/a_j^2.

Normalization of Hilbert-Schmidt amplitudes proves T(rho_j,tau_j)<=2q. This direct estimate replaces the sandwich-exponential Duhamel argument and requires no logarithm embedding or lower bound on X_j. Choose, for example, t=xi^(1/3) when 0<xi<=1; for fixed m,L, q tends to zero. If xi=0 use arbitrarily small positive t, or simply retain the already centralized reference.

Both root fidelity and affinity change by at most the sum of the square roots of the input trace-norm changes. Consequently

    Delta(tau_i,tau_j) <= delta+8 sqrt(q).

The central polar estimate in REPORT.md is valid and yields

    max_(i,j)||[B_i,B_j]sqrt(Omega')||_2
        <= 2 sqrt(2) L^2 sqrt(delta+8 sqrt(q)).

The weighted trace inequalities used here are legal precisely because B_i, B_j, their polar factors and Omega' centralize one another in the required reference direction. A nontracial application before the logarithmic reference step would not be justified; the supplied construction never makes that application.

## Sequential simultaneous pinching

The invariants in SIMULTANEOUS_PINCHING.md are sufficient. At every stage, every current matrix commutes with Omega' and all previously rounded matrices. Spectral projections of the current X_r therefore commute with Omega' and the previous rounded matrices. Pinching preserves all these commutations, positivity, and the norm bound. The rounding is a scalar function of X_r, constant on each global spectral bin, and hence commutes exactly with every future pinched matrix.

The expectation bound L mu_r/h_r is correct. The future commutator increment 4L d_r is correct: centrality permits right multiplication through sqrt(Omega'), so each of [D_i,B_j] and [X_i,D_j] has weighted norm at most 2L d_r. The displayed recurrence with h_r=v_r^(1/3) tends to zero for every fixed m,L. Thus no dimension enters the final approximation modulus.

All bin shifts are GLOBAL, including across different Omega' eigenvalue blocks. Hence each final Y_j has at most ceil(L/h_j)+2 distinct scalar values. The number of joint likelihood cells is at most the product of these bounds, even when the intermediate reference-spectrum partition has an arbitrarily large number of blocks. This is the key dimension-independent decoder point.

## One decoder and net quantifiers

For joint likelihood projections P_z, the single POVM {P_z} and states

    tau_z=P_z Omega' P_z / Tr(Omega' P_z)

fix every final state sigma_j=Omega' Y_j^2/Tr(Omega'Y_j^2). Reference variation INSIDE a joint cell is preserved by tau_z, so no diagonalization of Omega' into separate output labels is needed. Zero-reference cells can be omitted. If the final likelihood error is g and q<1, then

    T(tau_j,sigma_j)<=2g/(1-q),
    T(rho_j,Lambda(rho_j))<=4q+4g/(1-q).

The latter bound uses contractivity twice through tau_j and sigma_j. It tends to zero for fixed m,C.

Uniform trace total boundedness must mean: for every r>0 there is N(r)<infinity that bounds an r-net cardinality for EVERY experiment index n. An r-net plus the included reference has at most N(r)+1 states. The finite-family modulus is independent of n and dimension; pad a smaller net if desired. The SAME channel fixes all approximate net states and satisfies, for every state in the full family,

    T(rho,Lambda(rho)) <= e_n(r)+2r.

For each fixed r, e_n(r) tends to zero. Thus limsup_n of the optimal uniform reconstruction error is at most 2r for every r>0, and therefore zero. An actual sequence of channels follows by a diagonal choice of r(n) tending to zero sufficiently slowly. This does not exchange sup over parameters with a pointwise limit or use separate pairwise measurements. The net states, reference and conditional preparations must be legally known inputs; no efficient net acquisition or decoder compilation follows from this existence proof.

## Additional ultraproduct bridge audit

I checked the local Raynaud (2002) text: intro p42 explicitly extends the results to varying-algebra ultraproducts; pp57-58 place all Haagerup Lp elements inside the associative involutive algebra L0(core,tau) of tau-measurable affiliated operators; Theorem 3.6 pp59-60 preserves positivity, conjugation and the Mazur maps; Theorem 5.1 p66 preserves L2 times L2 to L1 multiplication.

For fixed m, pairwise gaps tending to zero imply that the limiting root products a_i a_j have norm equal to canonical trace. They are therefore positive L1 elements. The involution in L0 then gives a_i a_j=a_j a_i. This is algebraic equality of closed measurable products, stronger than dense-domain commutation. Each positive a_i has a bounded two-sided inverse resolvent (1+a_i)^(-1) in the core. Algebraic commutation forces these resolvents to commute; their bounded selfadjoint spectral calculus proves strong commutation of the a_i. Therefore b=sqrt(sum_i a_i^2/m) strongly commutes with every a_i and b a_i is positive.

Canonical trace preservation follows from positive norm preservation and linear decomposition of L1 elements. Root and multiplication compatibility therefore send the mixture-reference gaps to zero. I find no measurable-inverse defect in this bridge. Its finite-family modulus is nonconstructive; combining it with the explicit dominated decoder removes the original domination/reference hypotheses for uniformly trace-total-bounded known experiments, if the parent fully states this ultraproduct compactness argument.

## Audit disposition

No exact fatal issue found. Required clarifications are the explicit amplitude transport above, the uniform-in-n net-cardinality definition, global likelihood bin shifts, and existence versus efficient acquisition/preparation. Infinite-dimensional extensions need their operator-domain conventions stated separately; the finite-dimensional varying-dimension argument audited here is sufficient for the stated application. No rate optimality or new-priority claim is supported by this audit.
