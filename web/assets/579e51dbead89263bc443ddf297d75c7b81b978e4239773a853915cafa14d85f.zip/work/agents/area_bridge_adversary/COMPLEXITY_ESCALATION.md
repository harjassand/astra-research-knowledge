# Conditional classical verification consequence

Status: a derived conditional consequence of the released uniform polynomial-PEPS theorem plus the finite-bit extension in `FINITE_BIT_AUDIT.md`. This is an upper bound for an explicitly restricted promise problem, not a polynomial-time energy algorithm, NP inclusion, or QCMA inclusion.

## Fixed promise

Fix constants q, J, Delta>0 and k>=1. Let N=L^2. Input: on-site and nearest-neighbor rational Hermitian terms on the L by L square, one bounded term per designated support, local dimension q, individual operator norms <=J, and rational a<b with `delta=b-a>=N^-k`. Assume input bit length is polynomial in N (or retain an explicit polynomial input-bit-length multiplier).

YES instances have `E0<=a`, a unique ground vector, and full-system gap at least Delta. NO instances have `E0>=b`. One may also impose the same gap/uniqueness promise on NO instances, but soundness does not need it. No assertion is made about intermediate-energy or nongapped low-energy instances outside this promise.

Conditional conclusion:

`problem in NTIME(exp(O(sqrt(N) log N)))`.

There is a polynomial-bit classical PEPS witness. The verifier runs in the displayed time. The implicit constants depend on q,J,Delta,k and fixed proof parameters; the estimate is uniform across the allowed Hamiltonians.

## Arbitrary inverse-power PEPS accuracy

The source main theorem fixes error `L^-1`, but its internal proof is parameterized:

- `02-information.tex`, `prop:angular`: arbitrary fixed information exponent p.
- `03-patches.tex`, `prop:patch`: arbitrary fixed patch vector exponent p.
- `04-compression.tex`, `thm:compression`: arbitrary fixed density exponent p.
- `05-frames.tex`, `lem:small-rewrite`: arbitrary fixed operator exponent a in its last assertion/proof, with polynomial monomial counts depending on a.
- `05-frames.tex`, `lem:splitting`: vector error at most sqrt(b), so information error `L^-P` yields vector error `L^(-P/2)`.
- `06-geometry.tex`, lines 25–32: expansions accurate to any fixed inverse power and constant lifetime incidence. At lines 440–447 and 579–583, the numerical 60,30,20 serve error accounting; they impose no geometric obstruction.
- `06-geometry.tex`, lines 649–678: total changes/holes <=C L^3, with actual count O(L^2). The fixed 60 in the reference norm is precisely the patch accuracy.
- `07-assembly.tex`, lines 29–48: telescoping contraction errors and partial trace; its numerical exponents can be chosen after the desired final power.

For an explicit conservative substitution to target vector power t, choose information and patch power `P=4(t+10)`, every required gate approximant at power `A=2(t+10)`, and density compression error `L^(-2(t+5))`. Every split error is at most `L^(-2(t+10))`. Every small rewrite's reference error is bounded by a fixed constant times patch errors plus its operator approximant error (only boundedly many patch encoders occur), hence also `O(L^(-2(t+10)))`. Telescoping <=C L^3 gates gives vector error `O(L^(-2t-17))`; frozen-sheet norm loss is `O(L^(3-P))`. The protocol density error is therefore smaller than `L^(-2(t+5))` for sufficiently large L. Compression yields `eta=O(L^(-2(t+5)))`. The strengthened column lemma and rounding with `theta=L^(-2(t+5))` yield normalized error smaller than `L^-t` after increasing the uniform size threshold. Polynomial bond/bit exponents may depend on t.

The precise conservative exponents are unimportant; the listed dependencies verify that all accuracy powers are fixed before the polynomial counts. One must actually state this parameterized extension, rather than cite the frozen `L^-1` theorem for an arbitrary energy promise.

## Completeness and soundness

There are O(N) bounded terms, hence `||H||<=C_H N` with fixed C_H. Use the parameterized PEPS construction and rational rounding to obtain a normalized rational-PEPS vector psi with

`min_theta ||psi-exp(i theta)Omega|| <= delta/(8 C_H N)`.

For unit vectors, the elementary bilinear identity gives

`|<psi|H|psi>-<Omega|H|Omega>| <=2||H|| ||psi-exp(i theta)Omega|| <=delta/4`.

Thus on YES instances its energy is at most `a+delta/4 < (a+b)/2`.

The witness encodes the dyadic rational PEPS tensors of polynomial bond dimension and polynomial entry bit length. The verifier first checks the prescribed dimensions and bit bounds, contracts its norm exactly, rejects a zero vector, contracts its energy exactly, and accepts iff

`<v|H|v> < ((a+b)/2) <v|v>`.

NO soundness is immediate from the variational principle: every nonzero v has Rayleigh quotient at least E0>=b. No ground-state approximation promise is needed for the supplied witness, and no gap test is performed by the verifier.

## Exact contraction and bit accounting

The double-layer PEPS network has bond dimensions at most D^2, where `D<=C N^c`. Sweep rows of the square. A boundary has O(L) virtual bonds, so each intermediate array has at most `D^{O(L)}=exp(O(L log N))` entries. A conservative row-contraction algorithm takes `poly(N) D^{O(L)}` arithmetic operations. Inserting any one local term affects only a constant-size physical contraction and leaves this width bound unchanged. Sum O(N) such contractions for the energy.

Use dyadic tensor coordinates, as supplied by the rounding proof. For a full contraction, every summand has the same tensor denominator (the product of all ket/bra node denominators), with a polynomial number of denominator bits. The rational Hamiltonian denominators can be combined with this denominator; there are only O(N) local terms with polynomial-bit input numbers. The sum of numerator products has polynomial bit length: at most `D^{O(N)}` assignments contribute, their log count is `O(N log D)`, and each product contains O(N) polynomial-bit tensor entries. Intermediate row contractions obey the same polynomial-bit bound. Therefore exact arithmetic adds only a polynomial factor to `D^{O(L)}`.

No numerical condition number, exponentially small normalization tolerance, or cancellation assumption is used in verification. The retained-norm estimate is used for existence of a polynomial-bit witness; exact rational verification can handle that small norm directly.

## Supplied-versus-acquired boundary

The machine guesses the witness. The theorem does not compute it from H. Neither the state-dependent purification maps nor the good column are acquired efficiently by this reasoning. A deterministic enumeration of all polynomial-bit tensor witnesses costs exponential time in their polynomial description length and does not give the stated subexponential deterministic algorithm.

Likewise a polynomial-bit PEPS witness by itself does not imply NP: its exact generic contraction uses the displayed row width. It does not imply QCMA without an independently justified efficient verifier or efficient quantum preparation promise.

## Primary-source context and unresolved priority

- The release source itself is pinned at OpenAI/math commit `adc7f1241b42e322a6451854ab7e4b4c146bf78a`.
- Schuch, Wolf, Verstraete, Cirac, *Computational complexity of projected entangled pair states*, [arXiv:quant-ph/0611050](https://arxiv.org/abs/quant-ph/0611050), establishes severe generic PEPS contraction/preparation complexity; this is compatible with the row-sweep upper bound used here and motivates preserving its superpolynomial verification time.
- Deshpande, Gorshkov, Fefferman, *Importance of the spectral gap in estimating ground-state energies*, [arXiv:2007.11582](https://arxiv.org/abs/2007.11582), concerns a different high-precision/gap regime and should not be treated as a proof of this 2D constant-gap inverse-polynomial-energy consequence.

The derivation establishes the conditional upper bound directly. Historical priority of this exact promise-problem formulation remains to be checked; no priority claim is made.
