# Independent audit of the local tensor-entry moment

Scope: Lemmas 1–2 of `work/agents/area_bridge_adversary/FINITE_BIT_AUDIT.md`, against the supplied `04-compression.tex` at the pinned release snapshot. This is an algebraic check of this extension; it does not certify the underlying PEPS theorem or establish efficient acquisition.

Verdict: no indexing or correlation counterexample found. The bound follows under the original-party, fixed-virtual-label interface stated in Lemma 1.

## Deterministic local maps

Source theorem assumptions at lines 137–150 provide normalized private input vectors, contraction gates, constant lifetime participation, and local discard. The source-only representation at lines 233–267 leaves each source half as an initially idle free register, with every local branch map a contraction on its full ambient domain. For fixed ket and bra branches at every incident gate, composing these maps, the normalized private preparation, and final physical basis projection gives contractions A_x and Atilde_y with the same final garbage space. Thus O=Atilde_y^dagger A_x has norm at most one. It is deterministic: the sampled half matrices have been removed and replaced by their open input indices.

## Gaussian indexing

Source sampling at lines 279–340 assigns an independent Gaussian family to each slot location and ordered branch pair. A fixed consistent assignment to the virtual labels selects one such family per incident slot, plus one sample j. Different slots remain independent even when their endpoint parties and sample labels coincide. An original party is only one endpoint of each slot, so that slot contributes only g_ac or its conjugate, never both. For the product gamma_il over incident slots, covariance is exactly delta_ii' delta_ll', including arbitrary mixtures of endpoint orientations. Local Schmidt bases may differ between branches; their orthonormal coordinate indices are the respective domain and codomain indices of O, so no common-basis assumption is needed.

With normalized product probabilities p and ptilde, the variance is consequently

    E|t|^2 = sum_il sqrt(p_i ptilde_l)|O_li|^2
            = ||Ptilde^(1/4) O P^(1/4)||_HS^2 <= 1.

The last step is Schatten Holder with exponents 4,infinity,4 and trace(P)=trace(Ptilde)=1, exactly the form used in the source at its dimension-free inequality. Empty source lists give a scalar trace-one weight and cause no exception.

## Network labels and coefficients

The star wiring at lines 565–588 can impose equality of the branch label at the anchor. Inconsistent fixed star labels give zero entries. Consistent labels determine every local branch before evaluating the entry. No local summation over unspecified global monomial branches is required. Scalar density coefficients have modulus at most B^2 per gate; at most b nonprivate gates meet an original party. All averaging factors have modulus at most one. Therefore E|T|^2 <= B^(4b).

Choose the polynomial sample count k first. The number M of resulting party-tensor entries is then polynomial by bounded incidence and polynomial physical/link dimensions. Set K^2=8 M B^(4b). Markov and the union bound give the 1/8 failure probability. The global trace-norm failure probability of 1/4 gives a simultaneous good event of probability at least 5/8. Correlations across entries or across opposite endpoints do not enter either argument. Increasing k changes M and K but creates no circular condition: neither M nor K controls k.

## Boundary of the claim

Apply the moment estimate before routing or merging party tensors. If both endpoints of a slot were contracted into one node, the stated diagonal covariance argument would no longer apply. For the smallest example, a one-dimensional source with both halves at one merged node yields t=g conjugate(g), hence E|t|^2=2 rather than 1. This is not a counterexample to the claimed original-party bound; it shows why that qualification must remain explicit. Rational rounding should therefore occur before merging, as specified in the parent audit.

No sampled maximum-coordinate bound, private dimension bound, independence between tensor entries, or efficient Schmidt decomposition is needed for the existence conclusion. These omissions do not provide an acquisition algorithm.
