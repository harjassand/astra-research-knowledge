# Finite-bit escalation of the released PEPS construction

Status: independently derived conditional extension of the released proof, not external certification of its load-bearing area-law/information claims and not a ground-state acquisition algorithm.

Snapshot: OpenAI/math commit `adc7f1241b42e322a6451854ab7e4b4c146bf78a`. Source directory: `preprints/Polynomial-PEPS-approximation-of-gapped-square-grid-ground-states-September-24-2026/build/sections/`.

Pinned primary source URLs:

- [Information section](https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Polynomial-PEPS-approximation-of-gapped-square-grid-ground-states-September-24-2026/build/sections/02-information.tex).
- [Patch section](https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Polynomial-PEPS-approximation-of-gapped-square-grid-ground-states-September-24-2026/build/sections/03-patches.tex).
- [Density-compression section](https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Polynomial-PEPS-approximation-of-gapped-square-grid-ground-states-September-24-2026/build/sections/04-compression.tex).
- [Assembly section](https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Polynomial-PEPS-approximation-of-gapped-square-grid-ground-states-September-24-2026/build/sections/07-assembly.tex).

## Decisive conclusion

Assuming the released distributed protocol and density-compression theorem, one can choose its compressed operator network with polynomially bounded entries, not merely polynomial bond dimensions. A strengthened column lemma then supplies a column with inverse-exponential retained norm. Consequently the final approximate ket can be rounded to a rational PEPS with a polynomial number of bits. Arbitrary finite private dimensions do not obstruct this existence claim: a dimension-free second-moment estimate controls each local tensor entry. This is stronger than bounding all purification-space logarithmic dimensions by a polynomial.

No efficient acquisition conclusion follows. The proof still selects state-dependent variational minimizers, purification isometries, locally contracted tensor entries, and a good product-basis column. Supplied full dense reduced density matrices on logarithmic-radius patches have `q^{Theta(log^2 L)}` dimension and description size, and the filter objective is a joint matrix optimization, not an exhibited polynomial-time routine.

## Exact source interfaces

- `02-information.tex`, `lem:reset`, lines 333–631: gap-based information reset. The auxiliary purification factors are removed at lines 400–405 before the locality estimate. No enlarged ancilla remains in the Hamiltonian.
- `03-patches.tex`, `prop:patch`, lines 24–50: polynomial *inside-rank sum*, variable radii, and explicitly no bound on internal tensor complexity of the vectors. Minimization appears at `eq:patch-variational-problem`, lines 70–79.
- `04-compression.tex`, `thm:compression`, lines 132–171: arbitrary finite private spaces; constant lifetime participation; polynomial local outputs and monomial expansions.
- `04-compression.tex`, `eq:compression-source-gate`, lines 233–251, and common half-spaces at lines 253–267: each fixed monomial consists of normalized pair sources followed by local contractions, without commuting a source through an earlier local map.
- `04-compression.tex`, `eq:compression-random-source`, lines 279–308: correlated Gaussian half matrices on each pair source, with independent samples by slot location and ordered branch pair at lines 339–340.
- `04-compression.tex`, `eq:compression-dimension-free`, lines 509–527: the same `4,infinity,4` Schatten estimate used below.
- `04-compression.tex`, `eq:compression-total-error`, lines 540–563: expected global trace-norm error can be reduced to an arbitrarily small fixed fraction of the target by increasing polynomial sample count.
- `04-compression.tex`, lines 565–588: local contraction into one tensor per party; bounded degree; no entry bound was required by the source proof.
- `05-frames.tex`, `lem:splitting`, lines 352–391: finite-dimensional Uhlmann splitting; no size bound stated.
- `07-assembly.tex`, `eq:compressed-density`, lines 53–63: trace-norm approximation to the pure ground state.
- `07-assembly.tex`, `lem:columns`, lines 67–94: existence of a good column, but without a lower bound on its amplitude. The strengthening below supplies that bound at a factor-two increase in error.
- `07-assembly.tex`, `lem:routing`, lines 122–172: constant congestion and polynomial final bond dimensions.

## Lemma 1: dimension-free local tensor-entry moment

Use the source-only circuit after eliminating pair effects. Fix a party P. Fix every incident ket/bra monomial label, every incident Gaussian sample label, and its physical ket/bra basis labels x,y. Leave its normalized source half registers as free inputs from the beginning, kept idle until their first use. Compose all local contractions and the normalized private initial vector, and project the physical outputs onto x,y. This gives contractions

`A_x : I -> F`, `Atilde_y : Itilde -> F`.

Here F is the final private discard space and the initial private preparation is part of these maps. All chronological maps remain contractions on *all* free inputs. Thus

`O = Atilde_y^dagger A_x : I -> Itilde`, `||O|| <= 1`.

For each incident source slot e, its ket Schmidt probabilities are `lambda_{e,a}`, its bra probabilities are `mu_{e,c}`. Its local half matrix is either

`sum_{a,c} (lambda_{e,a} mu_{e,c})^(1/4) g_{e,ac} |u_{e,a}><utilde_{e,c}|`

or the corresponding other-endpoint matrix with `conj(g_{e,ac})` and its Schmidt vectors. A party has only one endpoint of each slot. Distinct slots use independent Gaussian families, even if the slots join the same two parties. At a fixed virtual-label assignment every half matrix occurs only once in the party contraction.

With `i=(a_e)_e`, `l=(c_e)_e`, put the normalized probability lists

`p_i = product_e lambda_{e,a_e}`, `ptilde_l = product_e mu_{e,c_e}`.

The scalar entry before gate coefficient and averaging factors is

`t = sum_{i,l} (p_i ptilde_l)^(1/4) gamma_{il} O_{li}`,

where `gamma_{il}` is the product of independent incident Gaussians, each possibly conjugated. Circular Gaussian covariance gives

`E[gamma_{il} conj(gamma_{i'l'})] = delta_{ii'} delta_{ll'}`.

Therefore

`E |t|^2 = sum_{i,l} sqrt(p_i ptilde_l) |O_{li}|^2`

`= ||Ptilde^(1/4) O P^(1/4)||_2^2 <= ||Ptilde^(1/4)||_4^2 ||O||^2 ||P^(1/4)||_4^2 <= 1`.

The probability matrices P,Ptilde have trace one, regardless of private dimensions. This proof also covers no incident source, when the corresponding probability list is the scalar one.

For scalar coefficients, let B(L) bound each gate's absolute coefficient sum as in `eq:compression-polynomial-bounds`, and let b bound a party's lifetime participation. Put every ket/bra scalar gate coefficient and `1/k` averaging weight on one participating party. At most b such gate factors meet a party, and averaging factors have modulus at most one. Each finished local tensor entry T consequently satisfies

`E |T|^2 <= B(L)^(4b)`.

This statement is about each original party node before possible routing/merging. Correlations between entries and between opposite endpoints do not affect the union bound below.

## Lemma 2: choose bounded entries and a globally good sample simultaneously

Let M(L) be the total number of entries of the party tensors. Bounded node degree, polynomial physical dimensions, polynomial link dimensions, and polynomial node count imply `M(L) <= poly(L)`.

Set `K(L)^2 = 8 M(L) B(L)^(4b)`. Lemma 1 and a union bound give

`Pr[max_entry |T| > K(L)] <= 1/8`.

Choose the source sample count k large enough that the released global estimate gives `E ||sigma-rho'||_1 <= epsilon/8`. Then

`Pr[||sigma-rho'||_1 > epsilon/2] <= 1/4`.

Thus a realization has both properties with probability at least `5/8`. The pair-effect conversion error can be budgeted separately, e.g. at `epsilon/2`, as in the source. After adding the protocol's approximation error, the operator network can be selected with polynomial entry magnitudes and prescribed inverse-polynomial trace-norm error to `|Omega><Omega|`.

No private-dimension bound, Schmidt-rank bound, maximum Gaussian-coordinate event, or fixed finite representation of a purification basis is needed for this existence argument.

Order of choices: choose k from the global error estimate first, then count M(k), then set K. There is no dependence of k on K or M. The independent audit in `moment_check/AUDIT.md` found no indexing/correlation obstruction at original party nodes. This qualification matters: contracting the two Gaussian endpoints into one node first can yield `|g|^2`, with second moment 2 rather than 1 even for a scalar source. The proof rounds at original nodes before routing or merging.

## Lemma 3: a good column with nonnegligible amplitude

Let physical Hilbert-space dimension be d and let `||sigma-|Omega><Omega|||_1 <= eta < 1/2`, with `||Omega||=1`. In a fixed product basis put

`a_z=<Omega|z>`, `e_z=(sigma-|Omega><Omega|)|z>`.

Then `sum_z ||e_z||^2 <= eta^2` and `sum_z |a_z|^2=1`. Call z bad if `||e_z|| > 2 eta |a_z|`; coordinates with `a_z=0` carry zero weight. The total bad weight is at most 1/4. Hence good coordinates carry weight at least 3/4, and one good coordinate satisfies

`|a_z|^2 >= 3/(4d)`.

For `v=sigma|z>` this gives

`||v|| >= (1-2eta) sqrt(3/(4d))`,

`min_theta ||v/||v|| - exp(i theta) Omega|| <= 4 eta`.

The normalized-error inequality follows by applying `||w/||w||-Omega|| <= 2 ||w-Omega||` to `w=v/a_z`. For `eta<=1/4`, the retained norm is at least `sqrt(3)/(4 sqrt(d))`.

In the grid application `d=q^(L^2)` because temporary parties have dimension-one physical outputs. Thus the retained norm is at least `exp(-O(L^2))`.

The stronger lemma changes the constant in the approximation but not any bond dimension. It does not identify z efficiently.

## Lemma 4: quantitative rational rounding

Consider the selected ket network with n nodes, e virtual links, link dimensions at most D, physical dimension d, and all local entries at most K. Suppose its represented vector v has norm at least s. Round each real and imaginary component of each entry to a rational grid of mesh at most delta/2. The complex entry error is then at most delta.

By telescoping every product in the contraction, for `delta<=1` each physical coordinate changes by at most

`D^e n delta (K+1)^(n-1)`.

Thus

`||vtilde-v|| <= sqrt(d) D^e n delta (K+1)^(n-1)`.

Choose

`delta <= theta s / [sqrt(d) D^e n (K+1)^(n-1)]`.

The rounded vector differs by at most `theta ||v||`, so after normalization its error from the original normalized vector is at most `2 theta`. Its norm stays nonzero for `theta<1`.

The released protocol has `n,e<=poly(L)`, `D,K<=poly(L)`, and Lemma 3 gives `s>=c q^(-L^2/2)`. Consequently

`log(1/delta) = O(L^2 log q + e log D + n log(K+1) + log n + log(1/theta)) = poly(L)`

for every fixed inverse-polynomial theta. Entry integer parts require `O(log K)` further bits. There are polynomially many entries, so the entire rational ket network has polynomial description length.

Route this *already rounded rational network* using the source's identity wires and constant-congestion construction. Identity tensors have entries zero or one. Tensor products and local contractions preserve rationality. At each final grid vertex the number of party tensors is bounded: a nonunit anchor's coordinate valuations determine its unique nonunit dyadic scale, there are boundedly many temporary parties per block, and unit anchors add one further group. Folding adds at most four coordinate preimages. Hence the final merged tensors can be formed with polynomially many rational arithmetic operations, and their number, bond dimensions, and entry bit lengths remain polynomial. Even a cruder merge bound would still keep bit lengths polynomial, but constant occupancy provides polynomial formation time from the supplied rounded party tensors.

The normalized rational PEPS error is at most `4 eta + 2 theta`. Take both budgets small inverse powers before applying the main theorem's final `L^-1` target.

## Algorithmic scope and failure ledger

1. Finite-bit *existence* follows conditionally on the released protocol/compression proofs. It does not prove uniform polynomial-time construction from the Hamiltonian.
2. If the finished bounded party tensors and a qualifying column z are supplied, rational rounding and routing take polynomial time, with polynomial bit precision. This is a supplied-representation contract.
3. If the distributed source-only circuit has explicit polynomial-size private matrices and source vectors, Gaussian sampling and local contraction give a randomized polynomial-time construction of the operator network, with constant success probability; efficient verification of its global trace-norm error is not required for the mathematical guarantee. The pure-column acquisition step still needs additional access.
4. Full largest-patch RDMs determine the patch objective because every filter acts inside X_m, but dense patch RDM input length is quasipolynomial in L. The proof supplies no polynomial-time global matrix minimization algorithm. Rank bounds alone are insufficient to acquire their bases.
5. The adversarial reads of the reset, cell conditioning order, descending noncommuting filter stationarity, and Gaussian covariance estimate found no specific false implication in those lines. This is a limited proof audit, not a correctness certificate for the entire companion theorem.
6. Prior-art/historical priority of this finite-bit extension was not resolved by this derivation.
