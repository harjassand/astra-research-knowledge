# Algebraic complexity research handoff

Source pins: OpenAI adc7f1241b42e322a6451854ab7e4b4c146bf78a; Astra 778b78af5d4bbde608ce3fc775049ceaeb55a2d3. The actual full release107 and release116 manuscripts and Astra L01,L03,L04,N12,N25 were read. Exact PDF hashes are in SOURCE_HASHES.json. Primary literature was checked at the theorem locations collected in PRIOR_ART_LEDGER.md.

## Strongest positive derivation

The load-bearing changed premise is an all-characteristic q-Newton reversal expander. It replaces the ordinary-Wronskian gate in the released rational-hitting proof. For w=n+1, Delta=4w^3B, M>B Delta and N=M-Delta, its maps satisfy

    dim sum_i T_i U>(w-1) dim U,  1<=dim U<=B.

The folded Casoratian bound used to prove this is

    sum_(i,j) d_(i,j)<=h(M-1)+w h(h-1).

Its direct proof works over F(q), for EVERY coefficient field F, because q has infinite order and the anchors (1+q)^i have disjoint q-orbits. No derivative factorial or finite-field multiplicity assumption remains.

Composing this with the source's shrunk-subspace rank argument, a prime-to-characteristic symbol division lift, and an explicitly counted separable finite-field grid yields the following internally audited theorem candidate:

Given a prime p in binary and n,B in unary, generate a polynomial-bit, polynomial-size list of ordinary F_p tuples. Over every extension/coefficient field F of characteristic p, EVERY family of <=B feasible affine pencils of order <=B has a common invertible hit. The generator is independent of coefficients and witnesses. All matrix entries, dense output, finite-field construction, and elimination costs are charged.

All internal proof gates have now received independent adversarial passes: folded Newton reduction, every-primitive-root division lifting and total degree, arbitrary-coefficient-field branch specialization, and original rational expression domains. This is a complete local derivation, not an external certification or historical-priority conclusion.

Artifacts:

- ALL_CHARACTERISTIC_STRONG_PENCIL_HITTING.md: complete prime-specific construction and degree/bit interfaces.
- FOLDED_NEWTON_EXPANDER.md: direct folded multiplicity and valuation/reversal proof.
- cyclic_shift_audit/difference_kernel_attack/FOLDED_NEWTON_SECOND_AUDIT.md: independent expander audit.
- cyclic_shift_audit/difference_kernel_attack/q_green_adversary/DIVISION_LIFT_DEGREE_AUDIT.md: division and degree audit.
- cyclic_shift_audit/difference_kernel_attack/q_green_adversary/ORDINARY_STRONG_DESCENT_AUDIT.md: arbitrary-extension specialization and full costs.
- cyclic_shift_audit/OPERATIONAL_RATIONAL_GATE_AUDIT.md: exact HW domain bridge and all inverse occurrences.

## Consequence escalation: one integer list across all fields

UNIVERSAL_INTEGRAL_STRONG_LIST.md removes the characteristic input entirely. Fix power-two M, use integer cyclotomic regular matrices U_i=M R_i^*, and print

    lambda adj(U_0) U_i

on a fixed five-parameter integer grid. Generic lambda=1/det U_0 proves every feasible-pencil determinant polynomial is nonzero. No inversion or discard is needed in the output construction. This grid works in characteristic zero and all p above an explicit polynomial threshold K. Enumerate all primes p<=K and append the already charged prime-specific lists, viewing entries as integer representatives. Thus n,B alone generate ONE polynomial-bit integer list working over EVERY field, in every characteristic, with arbitrary coefficient constants.

Independent final adjugate/degree/bit audit is at cyclic_shift_audit/UNIVERSAL_INTEGRAL_LIST_AUDIT.md. The tuple dimensions may vary across appended lists; the statement is an existential hit in one universal list. This is not a single-point result.

The conservative construction is impractical: already n=B=1 yields large-characteristic block dimension d=2048 and more than 4e62 grid points. Exact cost examples are in tests/integral_list_cost_examples.json. The promised-size generator has not been executed. The finite diagnostics below validate components only.

## Rational formulas and exact noncommutative rank

Hrubes–Wigderson2015 Theorem2.1 and Proposition7.3 apply over arbitrary fields. A nonzero admissible formula represents a nonzero free-field element; its original inverse-node domain pencils and root augmented pencil are feasible. The released Section4 recursions use only field operations and +/-1 and preserve all inverse occurrences, including in characteristic two. For formula size s there are <=s+1 pencils of order <=2s+1. With B=2s+1 the integer list gives a DEFINED, INVERTIBLE value for the original formula over every field. No inverse-nesting or constant-height bound is needed by the generator. Evaluation over an unspecified coefficient field still requires its own exact arithmetic interface and bit charges.

The same list also computes exact noncommutative rank through an exact full matrix-output or rank-output evaluation service. If an order-r affine pencil has free-field rank t, division-ring pivot induction selects ORIGINAL rows and columns giving a t-by-t invertible affine subpencil. The list with B=r hits that subpencil, so some evaluation has rank >=t d. Cohn inner rank equals free-field rank, hence L=P Q with polynomial matrices of width t; this evaluates everywhere and proves rank <=t d at every tuple. Therefore

    nc-rank(L)=max_over_list rank(L(X))/dim(X).

The upper bound is valid over arbitrary fields and requires no acquired factorization. Primary exact source Fortin–Reutenauer Section2 pp3–4, https://www.mat.univie.ac.at/~slc/wpapers/s52reut.pdf; its later infinite-field assumptions are not used. Audit: cyclic_shift_audit/difference_kernel_attack/q_green_adversary/NC_RANK_COROLLARY_AUDIT.md. Exact rank replies allow ordinary integer processing. Full matrix replies require represented-field exact linear algebra with all bit costs charged. This does not acquire an ordinary-language oracle, unknown model weights, or a physical service.

These consequences extend the actual release116 Q-only strong rational list and its division-free positive-characteristic companion. They do not establish scalar commutative PIT, general arithmetic-circuit PIT, or first white-box noncommutative rank: NC2026 already supplies a white-box algorithm with coefficients input.

## Smaller all-characteristic nonvanishing detector

The compact cyclic q-Green transfer proof yields an integral jointly nilpotent tuple with

    N=max(1,2n(m-1)),
    E=1+binom(N,2)+n(N-1),
    d=m N E=O(n^3m^4).

The marker degree is strictly below m. For finite polynomials or acyclic ABPs the marker can be omitted, giving d=N E=O(n^3m^3); formulas give O(n^3s^3), versus release116 positive-characteristic O(n^3s^6). One integer tuple reduces correctly over EVERY field without characteristic input. Full-matrix output is essential. Infinite unmarked faithfulness is false; only the bounded-state graded guarantee survives.

This compact detector depends on the actual release116 finite-word independence lemma, whose mechanism was read and composed. Its downstream proof is independently audited, but neither the full source nor this result has external certification. Astra L01 already recorded that routine unrolling provided polynomial characteristic-zero cyclic capability, so this is a characteristic/uniformity/dimension refinement, not first polynomial cyclic capability.

Main proof: cyclic_shift_audit/COMPACT_Q_KERNEL_PROOF.md and difference_kernel_attack/TRANSFER_KERNEL_REFINEMENT.md. Artifact map: cyclic_shift_audit/RESULTS_INDEX.md.

## Matrix multiplication: an exact barrier and corrected bit consequence

MM_PROFILE_BARRIER.md directly attacks stronger use of release107's profile inequalities. Define H_1=1, H_a=product_(j<a)(3j+1)/(3j), and

    P*(a,b)=H_min(a,b) [max(a,b)+(min(a,b)-1)/2].

At t=3/4 this numerical profile satisfies EVERY used Section4–5 axiom: symmetry, boundary, separate concavity, shifted tripling for every h, and rank envelope P(a,b)<=(a+b-1)^(4/3). Its diagonal growth is Theta(a^(4/3)). The proof is exact and shows that optimizing those same axioms, all shifts, or their constants cannot prove an exponent below 9/4. Larger proportional odd-sector counts also fail to exclude it. It is not an actual tensor character or a lower bound on the true matrix multiplication exponent. Additional structural identities can escape it.

The same-copy auxiliary dot-product format cannot improve sector entropy power: source and target Y-flattenings force Q<=L. A new format is needed to obtain Q=M^(1+epsilon) with L=O(M).

CONSTRUCTIVE_BIT_TRANSFER.md corrects an overly absolute reading of L03. Conditional on omega<=9/4, standard dovetailed algebraic-number rank-decomposition search gives a UNIFORM exact integer algorithm for every fixed epsilon>0:

    C_epsilon+O_epsilon(N^(9/4+epsilon)(b+log(N+2))^2)

elementary bit operations for b-bit inputs. The constant C_epsilon is uncontrolled and potentially enormous. Thus no practical/supplied decomposition is acquired, but it is false to say no uniform bit algorithm follows at all. This standard consequence receives no novelty claim, and does not acquire N-dependent selective circuits.

## Selective arbitrary masks: target remains unresolved

The target X of shape N-by-N^(1/4), Y of shape N^(1/4)-by-N and arbitrary output mask |W|<=N^(15/8) remains open at charged subquadratic integer cost. The actual Oct5 Alman–Vassilevska Williams paper was ALREADY in Astra's audit; its date alone supplied no changed premise.

Two direct attacks produced new restricted obstructions:

1. The unchanged ten-term output-support-pruning recursion needs Omega(N^2) retained syntactic products for some legal mask, even with free encoders and all fitting block/inner assignments. A concentration extension gives ONE mask defeating every scheme in any prescribed family with log|Gamma|=o(N^(15/8)), including adaptive global row/column permutations and assignments. It excludes neither semantic alias simplification, rewritten circuits, unrestricted mask-dependent packing, nor genuinely new shared transforms.
2. Every exact masked rank decomposition has at least |W|D incidences on EACH leg, by the rank-D slices at each output. Independently summing its forms and products costs Omega(N^(17/8)). Shared multilevel linear circuits could still escape this bound. A dense gauge transform of Strassen explicitly shows rank alone does not promise pruning locality.

Independent adversarial corrections and exact proofs are in selective_mask/REPORT.md, LEAF_UNION_THEOREM.md, and sparse_transpose/DIRECT_SPARSE_TRANSPOSITION.md. No finite target circuit or rank kernel was acquired.

## Runnable evidence and its exact scope

- 20,760 exact cyclic-transfer identities, 80 fixtures over GF101/GF(2^8), detection matched all-word row-span certificates: difference_kernel_attack/check_transfer_kernel.py and TRANSFER_KERNEL_EXACT_CHECKS.json.
- 8,360 exact regular-representation/semisimple branch comparisons over F4/F16, including arbitrary extension constants held fixed. A deliberately wrong Frobenius-on-F predicate disagreed in 13 and 1,446 cases: cyclic_shift_audit/check_semisimple_descent.py and SEMISIMPLE_DESCENT_EXACT_CHECKS.json.
- Numerical-profile checks used exact Fractions: 6,400 symmetry/envelope, 6,320 concavity, 2,080 shifted-tripling cases: tests/mm_profile_exact.json. General proof is separate.
- Selective recursion: 73 original parameter cases plus 239 crossing-order cases; 2,220 exact slice-rank checks; 64 tensor coefficients and 84 nonzero gauged-factor coefficients checked. Scripts and JSON in selective_mask/.

These checks establish fixture/component identities only. They do not certify general theorems, source correctness, historical novelty, or full generator performance.

## Failure ledger and next decision-changing work

- Nilpotent coefficient descent preserves nonzero entries but not invertibility or original rational domains; replaced by semisimple all-branch specialization.
- Arbitrary-degree finite-field irreducible construction polynomial only in log p was not assumed; exhaustive search is charged at Q<=H^4.
- Frobenius twisting arbitrary coefficient constants is wrong; only grid elements are permuted. Exact fixtures explicitly catch the mistake.
- Copying the source's existential division lift at a witness index divisible by p is wrong; HW free-field feasibility bypasses that root choice.
- Unmarked infinite q-word faithfulness is false; cyclic marker is retained.
- Optimizing the displayed profile axioms cannot beat 9/4; exact numerical countermodel retained.
- Rank pruning and sparse transposition do not acquire the arbitrary-mask shared circuit.

The strongest next clearance is complete external/formal review of the integer universal strong list, plus a reduced-parameter generator implementation and a broader priority check against universal rank condensers, lossless dimension expanders, and rational black-box hitting. There is no remaining internally identified mathematical lemma for the stated strong-list construction, subject to its inherited source mechanisms and current audit scope. Priority and practical implementation remain unverified. None of the weaker circuit/PIT/selective targets is represented as resolved.
