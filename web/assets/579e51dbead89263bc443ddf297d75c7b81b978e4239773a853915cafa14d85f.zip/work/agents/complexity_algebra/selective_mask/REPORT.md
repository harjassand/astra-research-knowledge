# Selective outputs: exact outcome

The target remains open: arbitrary supplied `W`, `D=N^(1/4)`, `|W|<=N^(15/8)`, polynomial-height integers, fully charged `N^(2-eta)` computation. No circuit or finite rank witness meeting it was obtained. The two strongest direct attacks were shared/lazy encoding for the existing output-local Schönhage recursion, and sparse transposition through low-degree rank-leg evaluation.

The actual Oct 5 Alman--Vassilevska Williams paper does provide genuine shared output-local recursion, but its useful thinness range was already preserved in Astra's exact audit. Release107's new square arithmetic exponent does not change the incidence structure of that primitive. Both primary TeX proofs were acquired and read at the relevant gates.

## Exact derived outcomes

1. **Free encoders cannot repair unchanged fixed leaf pruning.** `LEAF_UNION_THEOREM.md` proves that, for `N=4^(4m)` and `D=4^m`, any fixed assignment of physical outputs to fitting ten-term recursive calls (`3^(L-m)<=N`) admits a legal mask forcing `Omega(N^2)` scalar product leaves. Arbitrary incomplete tiles and active output subsets are allowed. Every encoder and decoder is free. Each syntactic leaf may serve many outputs, but distinct products are individually charged and semantic alias/zero rewrites are excluded. The proof uses exact incidence at `d=floor(m/4)`, not the old tail certificate.

2. **A limited adaptive extension.** One mask defeats every scheme in any prescribed family with `log |Gamma_m|=o(N^(15/8))`. Sample `M=N^(15/8)` positions with replacement (the resulting set is always legal), and choose the least order d with `p alpha_d>=1`; then `alpha_d<900/p`. The independent bounded-difference inequality gives failure probability `exp(-Omega(M))` for each scheme. This covers row/column permutations and one global inner-set assignment chosen after W is seen. It does not cover unrestricted mask-dependent per-call maps or new circuit constructions.

3. **Direct sparse rank-wire evaluation cannot supply the transpose circuit.** The independent companion note `sparse_transpose/DIRECT_SPARSE_TRANSPOSITION.md` proves that every exact decomposition of the masked tensor has at least `|W|D` incidences on each leg. Independently summing the sparse Z linear forms plus scalar products therefore costs at least `|W|D=N^(17/8)`. Alman--Li's source theorem enumerates sparse wires of a separately bounded linear factorization; omega and alpha do not bound that factorization. Shared deeper encoders and new factorizations remain open.

4. **Rank alone does not promise pruning locality.** The independent audit `sparse_transpose/kronecker_audit/AUDIT.txt` shows that invertible matrix-multiplication changes of coordinates can make every factor coefficient nonzero without changing rank. Every rank leaf of its tensor powers is then reached by singleton support. An exact rational transformed Strassen witness checks the construction.

These are restricted-model negative deductions. They are not lower bounds against arbitrary arithmetic circuits, border-rank lower bounds, or an externally certified advance. Prior-art priority for the deductions has not been established.

## Validation and corrections

`verify_leaf_union.py` passes 73 exact parameter checks (`m=8..80`), the minimal-order crossing bound, and a proper active-output subset fixture with 134 outputs / 1797 incident leaves. The companion passes 2220 exact slice-rank fixtures. The transformed Strassen witness checks all 64 tensor coefficients and all 84 nonzero factor coefficients. These are scoped diagnostics alongside the displayed mathematical proofs.

Independent adversarial review forced two material scope corrections: the first expectation argument initially covered a fixed packing, not every W-dependent packing; the limited-family concentration extension handles only its now-stated family. Also, large padded tiles contain separate X-only and Y-only aliases outside the lone nonzero product slot. No lower bound is claimed for unrewritten `N0>N` padding. These limitations are preserved in the main note.

## Arithmetic versus rank and bit costs

The existing fixed-mask asymptotic rank deduction `N^(1445/744)` concerns tensor powers while the mask is held fixed. It supplies no uniformly acquired one-shot circuit for varying arbitrary masks. Release107 states an arithmetic exponent over complex scalars and no practical finite size. None of these ranks is upgraded into a charged bit algorithm here. Polynomial input heights and explicit `0,+1,-1` transforms make word sizes manageable for the original fixed recursion, but its counted products already fail. Big-integer vector packing charges `Theta(D log N)`-bit operands and does not evade the fixed-word budget.

## Strongest next observation

An explicit mask-dependent shared circuit for sparse `Z_W Y^T`, or an actual alias-specialized recursive identity with its final leg maps, could change the outcome. It must avoid direct `|W|D` incidence evaluation by sharing real arithmetic, and must avoid the proved leaf-union cost through a semantic change in products, maps, or packing. Input-only lazy evaluation of the current fixed primitive cannot do this. No such replacement was found in the two attacks.

Primary source pins and hashes:

* OpenAI math HEAD `adc7f1241b42e322a6451854ab7e4b4c146bf78a`; `sources/release107.pdf` SHA256 `9c430672ddf2a1d0d2335c55c03b0b1fdea72f5a000c586bf130c2e984f19ae6`.
* Alman--Vassilevska Williams arXiv:2610.06783v1; `sources/aw2610-source.tar` SHA256 `d94af3a900befd6a706ab55644f80f91fb652afaf1a2a242c65fd6e52b0ceb0e`.
* Alman--Li arXiv:2509.14489v1; `sources/al2509-source.tar` SHA256 `c9ed6f7e26507e3612c80b606b264d5408724acf67669c14c9dba61c27e6cba7`.
* Astra HEAD `778b78af5d4bbde608ce3fc775049ceaeb55a2d3`; exact audit source IDs `d-d2ebdc4e16ec4b31`, `d-1e7a99ec32d38c30`.
