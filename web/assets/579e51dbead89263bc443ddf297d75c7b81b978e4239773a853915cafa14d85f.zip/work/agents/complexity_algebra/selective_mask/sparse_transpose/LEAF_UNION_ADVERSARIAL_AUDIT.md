# Adversarial read of the parent's leaf-union theorem

7 October 2026. Main fitting-block proof checks out after the scope corrections listed below. This is an internal mathematical audit of a restricted algorithm model, not an externally reviewed circuit lower bound.

## Exact checked steps

- N=4^(4m), D=4^m implies N=D^4, M=N^(15/8)=2^(15m), density p=M/N^2=2^(-m).
- alpha_d=binom(m,d)9^d, beta_d=binom(L,m-d)9^(L-m+d), r_d=binom(L-m+d,d) satisfy beta_0 alpha_d=beta_d r_d.
- For an arbitrary fixed subset of active output strings, sum of order-d leaf support sizes equals C alpha_d and each support size is at most r_d. No complete-tile assumption is needed.
- For a uniformly sampled fixed-size mask, miss probability is at most (1-p)^s<=exp(-ps). Thus hit probability is at least (1-exp(-1))min(ps,1).
- For 0<=s<=r, min(ps,1)>=s min(p,1/r). This yields the displayed expectation lower bound for arbitrary active subsets.
- d=floor(m/4) gives p alpha_d >= (sqrt(6)/2)^m/36, so this factor is at least one for all sufficiently large m.
- Fitting N0=3^(L-m)<=N implies L-m<16m/3. For h<=m/4, beta_h/beta_(h-1)>81/67, so beta_d/beta_0>=1.
- Summing expectations over calls gives at least (1-exp(-1))N^2 when each physical output has a distinct assigned call-output string.

The verification program passed 73 exact parameter checks for m=8..80 and its partial-active-set fixture (134 outputs, 1,797 incident order-one leaves). I ran the program with only its output path redirected into this directory, preserving the parent's source and result files. The result is leaf_union_checks.json. These fixtures support arithmetic and incidence formulas, not the theorem's general quantifiers.

## Two load-bearing scope corrections

1. The expectation argument originally established `for every fixed packing, there exists a bad W`. It did not establish `there exists W defeating every W-adaptive packing`. The parent corrected the theorem to require the collection and physical-output assignment to be fixed independently of W. Input-only lazy encoding can still depend on W because all encoders are free in the lower bound.

2. In a literal K0-by-K0 padded grid with N0>N, exactly one slot has both block factors nonzero. However X remains nonzero in every slot in its row and Y remains nonzero in every slot in its column. Therefore it is incorrect to infer that the input arrays have only one nonzero inner set Q. Those separate aliases can leave extra nonzero leaf forms whose contributions cancel. The parent removed the claim for literal unrewritten padding. If both input arrays of every zero-product slot are explicitly set to zero, the resulting one-Q specialization does have D ordinary inner-product leaves per real output. This additional rewrite must be stated.

## One remaining wording caution

The proof counts distinct syntactic call-leaf instances. It allows one leaf to contribute to many outputs, and it grants encoders and decoding free. It does not allow replacing several leaf instances by one product after discovering identical input maps or other dependencies. The phrase `multiplication ... may be shared arbitrarily` should therefore mean the sharing already present in one leaf's output support, not unrestricted semantic sharing or merging of distinct products across calls. State the charge on syntactic call-leaf instances explicitly.

## Optional finite-family strengthening: direct proof

This is an independent extension available if the parent wants a precise stronger quantifier. Let F_N be any prescribed finite family of fitting-block collections/assignments, each independent of the random mask. Keep the same m and d for every member, but allow different L per call. For P in F_N, let f_P(W) be the number of retained order-d call-leaf instances. The main theorem gives E f_P>=c0 N^2, c0=1-exp(-1).

If two size-M masks differ by removing one position and adding one other position, f_P changes by at most 2 alpha_d: each changed physical output reaches exactly alpha_d order-d leaves in its assigned call. This is uniform over P and all active subsets.

Reveal a uniformly sampled size-M mask as M draws without replacement. In the Doob martingale for f_P, consider two possible next draws a,b after a fixed prefix. Couple their random completions by exchanging a and b whenever necessary. The resulting completed masks are either identical or differ by one swap. Therefore the two conditional expectations differ by at most 2 alpha_d. Each martingale increment has absolute value at most 2 alpha_d. Azuma's exponential-moment proof gives

    Pr[f_P <= E f_P - t] <= exp(-t^2 / (8 M alpha_d^2)).

The coupling can be checked explicitly: with next draw a, a completion subset U excludes a. If b is in U, replace b by a to obtain a completion for next draw b; if b is absent, leave U unchanged. This bijection preserves the uniform completion distribution and produces the claimed identical-or-one-swap final subsets.

For a sharper elementary bound on alpha_d, use u=1/27:

    alpha_d u^d <= sum_h binom(m,h)9^h u^h = (4/3)^m,

hence

    alpha_d <= (4/3)^m27^(m/4)
             = 2^((2-(log_2 3)/4)m)
             = N^(1/4-(log_2 3)/32).

Taking t=c0 N^2/2 yields

    Pr[f_P < c0 N^2/2]
        <= exp(-Omega(N^gamma)),
    gamma = 13/8+(log_2 3)/16 = 1.724060156... .

A union bound now proves the existence of one legal size-M mask W with f_P(W)>=c0 N^2/2 for every P in F_N, provided

    log |F_N| = o(N^gamma).

This permits an algorithm to choose a packing after seeing W if all its choices lie in that prescribed family. It covers, for example, a family of exp(O(N log N)) packings. It does not cover all arbitrary output assignments, whose naive count has logarithm Theta(N^2 log N). No counting bound for any named adaptive packing family is supplied by this earlier argument; such a bound remains a separate premise. The parent's subsequent extension below is stronger and makes this optional fixed-size argument unnecessary.

## Subsequent stronger extension: audited

The parent replaced the optional concentration approach with M independent sampled positions allowing repeats, and chose d_* as the least d with p alpha_d>=1. I independently checked the resulting proof in the revised LEAF_UNION_THEOREM.md.

1. d_* is at least one because p alpha_0=p<1. It is at most floor(m/4) for sufficiently large m by the already proved alpha bound.

2. For 1<=d<=m/100, alpha_d<=(9em/d)^d<=(900e)^(m/100)<2^m. The function d log(9em/d) increases over this interval since its derivative is log(9m/d)>0. The last inequality follows, for example, from e<3 and 2700<2^12. Thus d_*>m/100.

3. The crossing ratio is 9(m-d_*+1)/d_*<900, so 1<=p alpha_(d_*)<900. This controls the concentration scale by the mask budget rather than a fixed chosen leaf order.

4. The hit probability 1-(1-s/N^2)^M is at least 1-exp(-ps), so the expected leaf count is at least kappa N^2 by the original incidence proof and the beta monotonicity through d_*.

5. Changing one sampled position changes the union-size statistic by at most alpha_(d_*), rather than twice that amount: with the other samples fixed, each completion adds a number between zero and alpha to the same base union. The independent bounded-difference inequality at deviation kappa N^2/2 gives exactly

       Pr[F_g < kappa N^2/2]
           <= exp(-kappa^2 N^4/(2M alpha_(d_*)^2))
           <= exp(-kappa^2 M/(2*900^2)).

6. A union bound over a specified family Gamma_m with log|Gamma_m|=o(M) succeeds. The sampled set W always has at most M elements, so it is legal even though sample positions repeat.

7. For actual-row/column permutations followed by the paper's fixed zero padding and one global assignment of inner sets Q to all grid slots, the number of schemes at fixed L is at most (N!)^2 K!, because an injection of K0^2 slots into K available Q sets has count at most K!. The fit condition gives L<19m/3 and K<=2^L<N^(19/24), hence log family size is O(N log N+N^(19/24) log N)=o(M). Taking the union over O(m) fitting values of L is harmless.

No invalid line found in this revised stronger extension. Its scope remains the specified family of output-pruning schemes with distinct syntactic call-leaf instances charged. It does not automatically cover arbitrary per-call mask-dependent assignments or symbolic simplification of input maps.

An additional 239 exact crossing-order checks for m=18..256 passed and are saved in crossing_order_checks.json. They check d_*>m/100, d_*<=floor(m/4), minimality, the ratio bound and p alpha_(d_*)<900. These are finite diagnostics of the displayed inequalities, not the concentration theorem.
