# Direct sparse transposition: one exact missing-lemma refutation

Status: **no subquadratic arbitrary-mask circuit is constructed**. The target remains open. The one serious route examined here was support-aware evaluation of exact rank identities using the sparse Kronecker-power evaluation mechanism of Alman–Li (2025). Its direct low-degree specialization is impossible for a simple, field-independent reason. This is a theorem about an explicitly restricted evaluator, not a lower bound against general arithmetic circuits.

## 1. Interface and charges

Let F be any field, W subset of [N] x [N], m=|W|, and D a positive integer. Z has independent variables z_ij for (i,j) in W and zero elsewhere; B is an arbitrary dense N x D matrix. We seek a division-free value-independent circuit for C=ZB, uniformly acquired from W with acquisition cost charged. At m<=N^(15/8), D=N^(1/4), its preprocessing and arithmetic evaluation would have to cost O(N^(2-eta)) for a fixed eta>0. Reverse differentiation of

    f(Z,B,X) = sum_(i,k) x_ik C_ik
              = sum_((i,j) in W) sum_(k=1)^D z_ij x_ik b_jk

then computes the selected products (XY)_ij, where B=Y^T. The contraction adds O(ND), and gradient writes add O(m), which fit for eta<1/8. The correct structural circuit must be retained when evaluated at Z=0; value-pruning cannot be differentiated as though it retained the polynomial.

Entries of the original X,Y must have O(log N) bits for the stated N-only bit budget. The released omega<=9/4 is an asymptotic field-arithmetic premise, not by itself a coefficient-height, acquisition, or bit-cost statement. This report's obstruction already applies over Q with exact finite coefficients.

## 2. Primary source and exact candidate

Josh Alman and Baitian Li, *Kronecker Powers, Orthogonal Vectors, and the Asymptotic Spectrum*, arXiv:2509.14489v1, 17 September 2025:

- Source: https://arxiv.org/html/2509.14489v1#S7 ; saved HTML and extracted text in sources/al25.html and sources/al25.txt.
- Theorem 7.1: for a fixed p x q matrix M, supported input vectors u,v on at most s coordinates each, and tensor power M^(tensor d), an arithmetic circuit of size O(s (delta(M)+epsilon)^d) can compute u^T M^(tensor d) v; circuit acquisition has the corresponding soft-O cost.
- Proof of Theorem 7.1: after choosing a constant-power depth-2 factorization M^(tensor d0)=UV^T with small maximum external degree, enumerate, for every supported input coordinate, every nonzero wire of its row in the Kronecker-power factors. Build the two resulting encoded sparse vectors and take their inner product.
- Exact TeX was also inspected at ../sources/al2509-tex/main.tex, theorem label thm:algebraic-algorithm, lines 1968-2021; the wire-enumeration statements are at lines 2007-2014.
- Sections 3.2 and 6.1-6.2: delta(M) is asymptotic maximum external row/column degree of a depth-2 linear circuit, not bilinear tensor rank. Degree-density control and symmetry can sometimes establish it. An omega or alpha bound does not give those data for arbitrary leg maps of a matrix-product identity.

The attempted missing lemma was: restrict an exact recursive matrix-product rank identity to W on its Z-leg, enumerate the wires incident to supplied support, and use sufficiently low Z-leg degree to reduce arithmetic below N^2. At the maximum allowed m, this would require effective degree O(N^(1/8-eta)). The next theorem rules out that degree even for an optimally chosen exact rank decomposition of the already masked tensor.

## 3. Slice-rank incidence theorem

Define the graph matrix-product tensor

    T_(W,D) = sum_((i,j) in W) sum_(k=1)^D z_ij x_ik b_jk.

For any exact rank decomposition over F,

    T_(W,D) = sum_(ell=1)^R a_ell(Z) c_ell(X) b_ell(B),

all three factors of each summand are nonzero linear forms. Define deg_Z(i,j) as the number of ell with a nonzero coefficient of z_ij in a_ell, and let I_Z=sum_((i,j) in W) deg_Z(i,j). Define I_X,I_B similarly, summing incidences over their variables.

**Theorem.** Every such decomposition satisfies

    deg_Z(i,j) >= D for every (i,j) in W,
    deg_X(i,k) >= deg_W(i) for every k in [D],
    deg_B(j,k) >= deg_W(j) for every k in [D],

and consequently

    I_Z >= mD,  I_X >= mD,  I_B >= mD.

Here deg_W(i) and deg_W(j) are the row and column degrees of the bipartite graph W.

**Proof.** Extract the coefficient of z_ij in the tensor identity. The left side is

    sum_(k=1)^D x_ik b_jk.

As a bilinear form between X and B variables, its coefficient matrix contains a D x D identity matrix and has rank exactly D over every field. Each surviving summand on the right is a scalar multiple of a rank-one bilinear form c_ell(X)b_ell(B). Rank subadditivity implies at least D surviving summands, giving deg_Z(i,j)>=D. Summing over W proves I_Z>=mD.

The coefficient of x_ik is sum_(j:(i,j) in W) z_ij b_jk. These are distinct variables on both sides and its coefficient matrix has rank deg_W(i), so at least that many right-hand summands survive. Summing over i and k gives I_X>=D sum_i deg_W(i)=mD. Extracting b_jk gives the column version and I_B>=mD. QED.

No random mask, expansion assumption, full-product support promise, characteristic restriction, or generic-value assumption is used.

## 4. Direct arithmetic-evaluation corollary

Consider the restricted bilinear evaluator which computes ZB by the displayed exact rank decomposition, constructs each rank-term linear form a_ell independently using binary linear gates, computes the R bilinear products a_ell(Z)b_ell(B), and decodes those products. Shared partial sums between different a_ell are excluded in this model; all decoding and other-leg encoding costs are left free for this lower bound.

If a_ell has s_ell nonzero Z coefficients, independently summing its s_ell inputs needs at least s_ell-1 binary additions or subtractions. Since a_ell is nonzero, s_ell>=1 and the total is I_Z-R. The R leaf products cost R scalar multiplications. Hence this evaluator uses at least

    (I_Z-R)+R = I_Z >= mD

arithmetic operations. Coefficient multiplications could only increase this charge. At m=Theta(N^(15/8)) and D=N^(1/4), the charge is Omega(N^(17/8)), exceeding the requested N^(2-eta) budget for every eta>0.

This addresses the possibility that free copying of variables makes wire incidence free: independent sums together with the leaf multiplication charge still imply the stated operation bound.

The same incidence theorem applies to the tensor power of a fixed exact identity: the slice rank of a Z-coordinate multiplies under tensor product. Thus rank-term fanout cannot meet a per-supported-coordinate degree below the full inner dimension.

## 5. Scope: what this does not prove

- It does not prohibit a shared deeper linear encoder. Dense fast matrix multiplication itself has at least n^3 leg incidences when its rank decomposition is fully expanded, yet its recursive encodings share partial sums and may use n^(omega+o(1)) operations. Incidence is not general linear-circuit size.
- It does not prohibit refactoring a leg map through a different low-degree depth-2 circuit of the kind Alman–Li studies. Such a refactorization is additional mathematical input, which must be explicit and charged. Its degree is not the number of scalar multiplications of the original tensor identity.
- It does not give a border-rank lower bound. The coefficient-slice theorem concerns exact decompositions. Converting a border-rank construction to an exact finite algorithm before direct evaluation recovers the theorem for that exact decomposition; shared interpolation and recursive encodings may evade the restricted model.
- It does not lower-bound nonlinear division-free arithmetic circuits that later cancel to the desired bilinear map.
- It does not revisit the rejected fully-sparse rescaling or complete-block-cover arguments. The theorem applies even when W is itself a complete rectangular block, illustrating its deliberately restricted scope.

Flattening T_(W,D) into a fixed linear matrix against a vector of the monomials x_ik b_jk is also not a free Alman–Li application: the required vector has mD independent support positions indexed by (i,j,k). Materializing those monomials already costs mD. Exploiting their product structure would require a new trilinear rather than ordinary sparse vector-matrix-vector construction.

## 6. Exact remaining object

The unchanged load-bearing lemma is a uniformly acquired, mask-dependent shared arithmetic circuit for ZB of size O(N^(2-eta)), with fixed value-independent gates. It must simultaneously share partial sums across sufficiently many Z-leg terms and avoid a quadratic complete dense block. Alternatively a trilinear support-aware factorization theorem with explicit shared encoders could supply such a circuit. Neither omega<=9/4 nor alpha>.465 alone supplies this additional property in the inspected sources.

The precise next observation which could change this outcome is a concrete leg-map refactorization with acquisition plus encoding plus leaf-product plus decoding costs below N^2 for every legal W. Total rank, average nonzero count, and the sparsity of one input are insufficient cost certificates.

## 7. Validation and failure ledger

- Mathematical proof above is exact and field-independent; independently checked by the kronecker_audit subagent.
- verify_slice_ranks.py passed all 2,220 fixtures: every mask through N=3 and D<=4 over rational arithmetic, and 100 seeded randomized masks through N=12. This verifies the displayed slice matrices and rank counts on those fixtures; it is not the general proof. The exact result is saved in slice_rank_checks.json.
- Rejected candidate: direct low-degree evaluation of exact rank-term leg maps. Decisive gap: every supported Z coordinate has degree at least D, giving mD operations in the independently summed evaluator.
- Still open: shared arbitrary-mask sparse-by-dense circuit and its integer bit implementation.

## 8. Independent complementary counterexample

kronecker_audit/AUDIT.txt proves a distinct representation-level obstruction. Over an infinite field, any exact rectangular matrix-product rank decomposition with nonzero summands admits an invertible matrix-multiplication change of coordinates that makes every coefficient of every leg factor nonzero, without changing its rank. Tensor powers of that identity therefore have every rank leaf structurally reached by even a singleton nonempty input support. A rank exponent alone cannot imply support-density proportional pruning of an arbitrary given identity.

The accompanying exact rational witness in kronecker_audit/check_dense_strassen.py verifies all 64 coefficients of a transformed 2 x 2 Strassen rank-seven identity and all 84 nonzero leg coefficients. Its kth power has 7^k live leaves for one supported coordinate among 4^k input coordinates. The witness demonstrates failure of the generic pruning inference; it does not rule out choosing a better representation or refactoring shared linear maps. The general infinite-field proof in the audit does not rely on this finite test.
