# A leaf-union obstruction beyond independently charged block covers

Status: proved below within the exact output-pruning model stated here. It is not an arithmetic-circuit lower bound. It does not resolve the arbitrary-mask target.

## Target and two direct attacks

Let `D=N^(1/4)`, let integer inputs have `O(log N)` bits, and let the supplied mask have at most `N^(15/8)` entries. Return the corresponding entries of `XY` in charged `O(N^(2-eta))` work for a fixed positive eta.

Only two targets were pursued: (1) make the ten-term Schönhage recursion mask-local by lazy/shared input encoding, and (2) use a support-aware sparse-by-dense circuit and transpose it. The independent second attack is in `sparse_transpose/DIRECT_SPARSE_TRANSPOSITION.md`. Neither supplies the desired circuit.

The source-card warning about complete-block covers was not used as a substitute for an attack. The result here charges only scalar product leaves, grants all input encodings for free, and permits shared decoding. Thus it addresses a genuinely shared recursive scheme, albeit a restricted one.

## Exact primitive and model

Use the ten-term identity in Alman--Vassilevska Williams, arXiv:2610.06783v1, Section 2.2. At `L` levels, an output string has `m` symbols `z_0` and `L-m` symbols `z_ij`; its inner dimension is `D=4^m`. The outer dimension of each product is `N0=3^(L-m)`.

The output-pruning algorithm retains a scalar product leaf exactly when its output support meets the requested mask. Distinct syntactic call--leaf instances are individually charged. A single such leaf may serve many requested outputs, but combining two distinct leaf products using aliases or a dependency rewrite is excluded. No new identity is acquired, and no rewrite of the input maps induced by aliases or zero coordinates is performed. This is the precise rule used in the paper's `Pruned` recursion, after its full input encodings are supplied. All encoders, decoders, and repeated use of encoders are free in the lower bound. The output incidence comes from the identity's third leg, rather than a separately charged complete matrix block.

Different calls may have arbitrary sets `A_t` of active output strings. Each actual `N x N` output position is assigned injectively to one of these calls and strings. The collection and this assignment are fixed independently of W, as in the paper's tiling; input-only lazy encoders may depend on W. The count below allows inactive padded output strings, arbitrary fixed choices of the active inner sets, and incomplete tiles. It requires `N0<=N`, so it covers all calls whose base outer block fits in the original matrix. It does not require the much larger full tile to fit.

## The incidence identity

For `0<=d<=m`, define

    alpha_d = binom(m,d) 9^d,
    beta_d  = binom(L,m-d) 9^(L-m+d),
    beta_0  = binom(L,m) 9^(L-m),
    r_d     = binom(L-m+d,d).

An output has exactly `alpha_d` leaves of order d. A leaf of order d meets at most `r_d` active outputs, since it meets exactly that many outputs in the complete collection of all inner sets. Double counting gives

    beta_0 alpha_d = beta_d r_d.                         (1)

These are the paper's exact counts in Section 2.4.3; no tail bound is being substituted for them.

## Theorem: free lazy encoding does not rescue output pruning at D=N^(1/4)

Take `N=4^(4m)`, `D=4^m`, with m tending to infinity. For every fixed, W-independent collection and assignment above, with `3^(L-m)<=N` in each call, some mask of **exactly** `N^(15/8)` positions forces `Omega(N^2)` retained scalar product leaves under the stated output-pruning rule.

The result permits a different L for each call, and all input encoding reuse and decoding sharing.

**Proof.** Select the mask uniformly among all subsets of exactly `M=N^(15/8)=2^(15m)` entries of the actual `N x N` output grid. Its density is

    p=M/N^2=2^(-m).

If a leaf has s active output positions in its support, its probability of being retained is

    1 - binom(N^2-s,M)/binom(N^2,M)
      >= 1-exp(-ps)
      >= (1-exp(-1)) min(ps,1).                          (2)

Fix one call with `C=|A_t|` active output positions. At order d, write `s_lambda` for the active support size of a leaf. Then `s_lambda<=r_d` and `sum_lambda s_lambda=C alpha_d`. Consequently,

    E[retained order-d leaves]
      >= (1-exp(-1)) sum_lambda min(p s_lambda,1)
      >= (1-exp(-1)) C alpha_d min(p,1/r_d)
      =  (1-exp(-1)) C min(p alpha_d,beta_d/beta_0).      (3)

Set `d=floor(m/4)`. The elementary estimate `binom(m,d)>=(m/d)^d>=4^d` gives

    p alpha_d >= 2^(-m) 36^floor(m/4)
              >= (sqrt(6)/2)^m / 36,

which tends to infinity, and is at least one for all sufficiently large m.

It remains to bound `beta_d/beta_0`. The fit condition implies

    L-m <= 4m log_3(4) < (16/3)m,

where `log_3(4)<4/3` follows from `4^3<3^4`. For `1<=h<=floor(m/4)`,

    beta_h/beta_(h-1)
      = 9(m-h+1)/(L-m+h)
      >= (27m/4)/((16/3+1/4)m)
      = 81/67 > 1.                                      (4)

Thus `beta_d/beta_0>=1`. Equation (3) gives at least `(1-exp(-1)) C` expected retained leaves in this call. Summing over calls uses `sum_t C=N^2`, because physical output positions are assigned once. Hence the expectation is at least `(1-exp(-1)) N^2`; some legal fixed-size mask meets this lower bound. Each retained scalar product costs at least one multiplication in this model. QED.

## Scope, loopholes, and comparison with the old certificate

This proves failure of the complete output-pruning primitive in the fitting-block regime, even with **free** lazy input encoders. It is stronger than showing that the published full-array encoding certificate has the wrong exponent. It also differs from the independently charged complete-block-cover obstruction: each scalar leaf may serve many outputs, and encoders/decoders are free; combining distinct syntactic leaf products via an alias or dependency rewrite remains excluded.

The theorem expressly does not prohibit choosing a new output-to-call packing after W is known: its quantifiers are `for each fixed packing, some W`, not `some W defeats all W-dependent packings`. It also does not prohibit removing rank terms whose input form becomes identically zero after the particular grid aliases and zero padding are substituted. It does not prohibit changing the rank decomposition, sharing scalar products after a symbolic dependency rewrite, regrouping leaves into new bilinear blocks, or devising another multilevel linear transform. A proposed rescue along one of these lines must exhibit its final exact input and output maps; it cannot rely only on a better full-product exponent or a reduced cost for the unchanged input encoder.

For `N0>N`, no additional lower bound for the paper's literal padded tiling is claimed here. Only one grid slot has both block factors nonzero, but X is copied into other slots in its row and Y into other slots in its column; these separate copies can leave nonzero rank terms whose cancellations matter. If one explicitly zeroes **both** input arrays of every zero block product, only one inner set Q remains. Under that additional rewrite, deleting identically zero factors leaves exactly the `4^m=D` ordinary inner-product terms at each real output, with no sharing across different output pairs, giving `|W|D=N^(17/8)`. That calculation does not extend automatically to the literal unrewritten padding or to a new overlapping packing.

The earlier exact certificate required useful tail decay at a large L/m and failed through its full-array exponent. Here a random-mask argument establishes that the upper-bound union estimate is also large for every fitting outer block: both `p alpha_d` and `beta_d/beta_0` exceed one at a specific order. No optimization of the current leaf-count certificate or input-only lazy encoding can change this obstruction while the leaf-support rule stays fixed.

## Extension: one mask defeats a subexponential family of adaptive packings

The quantifier limitation of the first theorem can be removed for a specified sufficiently small family. Let `Gamma_m` be any finite collection of fitting call/assignment schemes in the same model, and suppose

    log |Gamma_m| = o(M),     M=N^(15/8).

Then for all sufficiently large m there is one legal W, `|W|<=M`, such that **every** scheme in `Gamma_m` retains `Omega(N^2)` syntactic scalar product leaves. An algorithm may select its scheme from this family after seeing W.

**Proof.** Generate `M` independent uniformly random positions of the actual `N x N` grid, allowing repeats, and let W be their set. It is always legal. Set `p=M/N^2=2^(-m)`, and let `d_*` be the least d for which `p alpha_d>=1`. For sufficiently large m, the preceding binomial bound gives `d_*<=floor(m/4)`.

Also `d_*>m/100`. Indeed, for `1<=d<=m/100`,

    alpha_d <= (9em/d)^d <= (900e)^(m/100) < 2^m,

where the middle inequality follows because `d log(9em/d)` increases on that interval. Hence

    alpha_(d_*)/alpha_(d_*-1)
      = 9(m-d_*+1)/d_* < 900,
    1 <= p alpha_(d_*) < 900.                            (5)

Fix a scheme g and let `F_g` count only its retained leaves of order `d_*`. Its expected value is at least `kappa N^2`, with `kappa=1-exp(-1)`: a support of s positions is hit with probability `1-(1-s/N^2)^M`, and the proof of (3) applies; (4) gives `beta_(d_*)/beta_0>=1`.

Changing one sampled position changes `F_g` by at most `alpha_(d_*)`. To see this, fix the union B of leaf sets from the other samples. Each possible replacement adds at most `alpha_(d_*)` leaves to B, so the two total union sizes differ by at most that amount. The bounded-difference inequality therefore gives

    Pr[F_g < kappa N^2/2]
      <= exp(-kappa^2 N^4 / (2 M alpha_(d_*)^2))
      <= exp(-kappa^2 M / (2*900^2)).                    (6)

For completeness, the inequality used here follows from the Doob martingale for the M independent samples: each conditional martingale increment has range at most `alpha_(d_*)`, so its conditional exponential moment is bounded by `exp(lambda^2 alpha_(d_*)^2/8)`; multiplication of those bounds and optimization in lambda gives `exp(-2t^2/(M alpha_(d_*)^2))` for a lower deviation t. Thus no independence between different leaves is being assumed.

A union bound over `Gamma_m` makes the failure probability at most

    |Gamma_m| exp(-kappa^2 M/(2*900^2)) = o(1).

Some legal W therefore forces at least `kappa N^2/2` retained leaves for all schemes in the family. QED.

For example, this covers choosing the paper's row and column permutations and its one global assignment of inner sets to grid slots after W is supplied. There are at most `(N!)^2 K!` such schemes for fixed L (using the looser `K^K` instead of `K!` makes no difference). Over all fitting L, `L<(19/3)m`, so `K=binom(L,m)<=2^L<N^(19/24)`. Thus the logarithm of their number is `O(N log N + N^(19/24) log N)=o(N^(15/8))`.

The extension does not cover unrestricted mask-dependent per-call maps or newly simplified input/output circuits. Such a family may have much larger description entropy or may leave this leaf-evaluation model entirely.

## Arithmetic, rank, circuit, and bit ledgers

* Release107 supplies a complex arithmetic exponent bound, not a finite rank decomposition for this mask. Its exact source is pinned below. The Astra all-field and rectangular deductions remain conditional on their audited releases.
* The previously supplied fixed-mask asymptotic rank `N^(1445/744)` holds the mask fixed while taking tensor powers. This note neither exchanges those limits nor acquires a uniform finite circuit.
* The theorem is an arithmetic product-count lower bound for the specified primitive. It grants encodings for free; coefficient heights cannot reverse the count.
* Polynomial-height input integers and the ten-term coefficients `0,+1,-1` permit `O(log N)`-bit words when the recursion dimensions are polynomial in N. This does not supply a subquadratic algorithm; there are already too many counted scalar products in the primitive.
* Packing a D-component vector into one D-times-long integer makes one nominal multiplication per mask entry possible, but its operands require `Theta(D log N)` bits and direct bit cost returns to at least the `|W|D` scale. It is not a fixed-word or field-arithmetic rescue.

## Provenance and next falsifiable object

Read primary sources, not just the cards:

* OpenAI, *An Upper Bound of 9/4 for the Matrix Multiplication Exponent*, October 2, 2026, Theorem 1.1; exact PDF at https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Matrix-Multiplication-Nine-Fourths-October-2-2026/paper.pdf . Repository HEAD verified as `adc7f1241b42e322a6451854ab7e4b4c146bf78a`.
* Alman--Vassilevska Williams, arXiv:2610.06783v1, Sections 2.2--2.4 and 4.3--4.4, actual TeX downloaded at https://arxiv.org/src/2610.06783v1 . Their relevant source labels are `lem:prune`, `lem:count`, and `eq:decay`; their general data structure does not cover `D=N^(1/4)`.
* Alman--Li, arXiv:2509.14489v1, Section 7, `thm:algebraic-algorithm`; its sparse depth-two wire enumeration was checked against the independent slice-rank theorem in the companion note.
* Astra source pin `778b78af5d4bbde608ce3fc775049ceaeb55a2d3`; exact retrieved notes `d-d2ebdc4e16ec4b31` and `d-1e7a99ec32d38c30` retained in `sources/`.

The next object capable of changing the conclusion is a concrete alias-specialized rank decomposition or a shared multilevel circuit for the sparse-by-dense transpose problem, together with its final maps. It must beat the per-output slice incidence cost through actual internal sharing. No such object was acquired in this run, and no historical-calibre positive result is claimed.
