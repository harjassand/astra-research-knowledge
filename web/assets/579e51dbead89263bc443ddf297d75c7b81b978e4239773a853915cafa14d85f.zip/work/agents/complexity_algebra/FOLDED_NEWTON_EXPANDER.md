# All-characteristic small-subspace expansion by q-Newton reversal

Status: direct lemma candidate with two independent adversarial passes. The characteristic-zero rational-hitting manuscript's Section 2 can be repaired in every characteristic over a two-parameter extension. Division-algebra, simultaneous-specialization, and rational-domain steps have now also received separate audits in ALL_CHARACTERISTIC_STRONG_PENCIL_HITTING.md. The integer-list escalation is in UNIVERSAL_INTEGRAL_STRONG_LIST.md. No external certification or priority clearance is claimed.

Source mechanism: OpenAI, *Polynomial Hitting Lists for Noncommutative Rational Formulas*, September 24, 2026, Lemmas 2.2–2.4 and Proposition 2.1. https://raw.githubusercontent.com/openai/math/main/preprints/Polynomial-Hitting-Lists-for-Noncommutative-Rational-Formulas-September-24-2026/Polynomial-Hitting-Lists-for-Noncommutative-Rational-Formulas-September-24-2026.pdf . Local `sources/pitrational.txt`.

## Folded order bound

Let F be any field, q transcendental over F, k=F(q), and w>=1. Choose anchors a_i=(1+q)^i, 0<=i<w. Their multiplicative q-orbits are disjoint: (1+q)^(i-i')=q^r forces r=0 by order at q=0 and then i=i' by order at q=-1.

For every i,d>=0 define monic Newton polynomials

    L_(i,d)(z)=prod_{j=0}^{d-1}(z-a_i q^j).

The L_(i,d), 0<=d<M, form a basis of polynomials of degree<M. A polynomial vanishes at the first d points of orbit i if and only if its first d Newton coefficients vanish. Thus every h-dimensional V in this polynomial space has increasing echelon filtration indices d_(i,1)<...<d_(i,h).

Claim:

    sum_i sum_j d_(i,j) <= h(M-1)+w h(h-1).

Proof. Form the global folded Casoratian

    W(z)=det(f_j(q^r z))_(0<=r<h,1<=j<=h)

for any basis f_j of V. Change to a basis with distinct highest monomial degrees e_1<...<e_h. Its leading coefficient is the product of the leading coefficients times det(q^(r e_j)), a nonzero Vandermonde because q has infinite multiplicative order. Thus W is nonzero; deg W<=h(M-1).

For a given i change instead to the Newton-echelon basis with indices d_(i,j); this changes W by a nonzero constant. At z=a_i q^ell, every column satisfying d_(i,j)>ell+h-1 has all its entries zero, because the relevant points have orbit indices ell+r<d_(i,j). Every determinant term then has at least that many vanishing factors. Therefore

    ord_(a_i q^ell) W >= #{j: d_(i,j)>ell+h-1}.

Summing ell>=0 gives sum_j max(d_(i,j)-h+1,0)>=sum_j d_(i,j)-h(h-1). The orbits are disjoint, so all these multiplicities sum to at most deg W. This proves the claim over every field. The factor w h(h-1) replaces the source's w binom(h,2); it is still quadratic in subspace dimension.

## Explicit reversal maps

Fix state/order bound B and w=n+1. Set Delta=4 w^3 B. Choose M>B Delta and N=M-Delta; M can be chosen a power of 2 unless char(F)=2, and a power of 3 in that case, so M is prime to the characteristic and M<=3B Delta+3. Over k((eta)), define w maps P_N -> P_M by

    T_i(sum_{a=0}^{N-1} c_a L_(i,a))
      =sum_{a=0}^{N-1} c_a eta^a L_(i,M-1-a).

All maps are injective and explicit. Newton changes of basis are triangular with diagonal one, so their entries and inverses are polynomials in q. The eta-weighted matrices therefore have polynomial q,eta degrees and polynomial representation size. These statements concern construction over the rational function field, not numerical conditioning.

Claim: for every U of dimension 1<=h<=B,

    dim(sum_i T_i U)>(w-1)h.

The source's integral-reduction proof transfers exactly with eta as the valuation parameter and Newton coefficient projection as its filtration. Normalizing an input with a unit Newton coefficient at index a<=A forces minimum output eta-valuation<=A. Every term surviving the leading reduction then has index a<=A and is divisible by L_(i,M-1-A). A j-dimensional low-Newton-projection subspace consequently forces j independent output reductions in that vanishing filtration. Thus, if W=sum_i T_iU has dimension ell,

    b_(i,ell-j+1)>=M-1-a_(i,j), 1<=j<=h.

Apply the folded order bound to the reduced input U and output W. One obtains

    ell(M-1)+w ell(ell-1)
       >=(w-1)h(M-1)+h Delta-w h(h-1).

If ell<=(w-1)h, this implies

    h Delta <=w[h(h-1)+ell(ell-1)]
             <=w[1+(w-1)^2]h^2
             <=w^3 B h
             <4w^3 B h=h Delta,

contradiction. This proves strict expansion.

## Near-full-rank affine pencils

For any field F and any feasible affine pencil of order r<=B with coefficients in F, padding T_i with M-N zero columns gives square R_i(q,eta). The source's kernel/shrunk-subspace argument then yields

    rank(sum_i A_i tensor R_i)>=rN>(r-1)M.

A witness over an arbitrary extension of F is compared in its Laurent-series field using fresh q,eta parameters, preserving the coefficient-field embedding. This extension comparison must not identify the formal q or eta with a pre-existing coefficient of the same name.

## Composition and higher ceiling

Because M is prime to the characteristic, the source's Fourier lift inside a generic symbol division algebra extends algebraically over F(omega_M)(q,eta,p,r): the proof of no zero divisors and rank divisibility only needs primitive M-th roots and 1/M. Every feasible pencil therefore becomes full rank over that parameter field. Normalizing by the lifted R_0 gives simultaneous invertible affine evaluations over an extension.

The load-bearing descent task was a polynomial-bit algorithm printing a polynomial-size list of ordinary base-field matrices while ensuring **simultaneous invertibility in every component** of the semisimple coefficient-ring representation. Finite nilpotent coefficient truncation only preserves nonzero entries; it does not preserve invertibility when determinant constant terms vanish. Treating it as a strong hitting point would be false. The completed companion proof uses a separable cyclotomic ring and a grid counted across every embedding, with an exhaustive finite-field irreducible search whose polynomial candidate bound is explicitly charged. It does not assume deterministic factoring polynomial only in log p.

This supplies the companion candidate universal strong hitting list for feasible affine pencils in every characteristic, materially beyond the division-free positive-characteristic primitive and the proper-cyclic nonvanishing detector. The rational-formula bridge is independently checked against Hrubes–Wigderson Theorem2.1 and Proposition7.3: nonzero admissible expressions supply feasible original domain/root pencils. The source's witness-index division lift is bypassed, so an initial witness dimension divisible by the characteristic is harmless.

Priority is unknown. Folded Wronskian/subspace-design methods are established prior art; the Newton reversal composition must be compared against those constructions before any novelty claim.
