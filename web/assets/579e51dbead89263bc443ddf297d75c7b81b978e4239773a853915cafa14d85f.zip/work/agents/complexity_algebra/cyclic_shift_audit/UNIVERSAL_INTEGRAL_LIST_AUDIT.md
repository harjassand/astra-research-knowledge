# Independent audit: one characteristic-independent integer strong list

2026-10-07. Verdict: no gap found in the proposed universal-integer-list escalation. This is a direct internal algebra/quantifier/cost audit, conditional on the separately reconstructed all-field q-Newton strong-pencil proof and prime-specific construction. It does not establish external correctness, practical feasibility, or priority.

Audited parent note: `../UNIVERSAL_INTEGRAL_STRONG_LIST.md`. Inspected supporting division note: `difference_kernel_attack/q_green_adversary/DIVISION_LIFT_DEGREE_AUDIT.md`. The stronger operational rational-domain gate is separately checked in `OPERATIONAL_RATIONAL_GATE_AUDIT.md` against HW2015 Theorem 2.1 and Proposition 7.3.

## Exact target

Given only unary n,B, output a polynomial-size list of integer n-tuples, with polynomial matrix dimensions, entry bit lengths, complete dense output length, and deterministic bit generation time. The SAME list, mapped into any coefficient field F through its prime subfield, must simultaneously hit every family of at most B feasible affine pencils, each of order at most B. Feasible means some invertible matrix evaluation over an extension of F. The generator receives no coefficients, witnesses, oracle, characteristic, or advice.

The proposal achieves this list property within the audited premises. The construction does not establish one strong hitting point. Matrix dimensions can vary between appended prime-specific tuples, which is allowed by the proposed list statement; no common dimension is asserted here.

## 1. Integral large-characteristic branch

Take w=n+1, Delta=4w^3B, and the smallest power of two M>B Delta. Then M is polynomial in n,B, N=M-Delta>=1, rho=phi(M)=M/2, and d=M rho. The integral coefficient algebra has the especially simple presentation

    C=Z[omega]/(omega^rho+1).

All q-Newton coordinate matrices are monic unit triangular. Their inverses are therefore integral polynomial matrices: no q-dependent denominator is introduced. The Fourier symbol lift's sole scalar denominator is M, so clearing it once gives

    A_i=M R_i^* in Mat_M(C[q,eta,u,v]).

Negative omega powers reduce integrally using omega^rho=-1 (or omega^M=1). Replacing C by its ordinary integral multiplication representation gives polynomial matrices U_i of order d over Z. All these constructions specialize correctly in every characteristic not dividing M. Since M is a power of two, this includes every odd characteristic and characteristic zero.

After extending F to its algebraic closure, C splits into rho distinct primitive-M-root branches whenever char(F) does not divide M. The per-root strong-pencil proof applies to EVERY primitive root with arbitrary coefficients in F. Therefore U_0 has nonzero generic determinant, and every feasible pencil's normalized evaluation at

    X_i=U_0^-1 U_i

is generically invertible in the ordinary d-dimensional representation. This is a simultaneous all-root statement, not selection of one root.

## 2. The shared adjugate normalization is valid

Define integer polynomial matrices Z_i=adj(U_0) U_i and introduce one scalar lambda. For a feasible affine pencil L, the ordinary matrix determinant

    Q_L(q,eta,u,v,lambda)=det L(lambda Z)

is a polynomial with coefficients in the ARBITRARY coefficient field F. In the parameter function field, the specialization

    lambda=1/det(U_0)

gives lambda Z_i=U_0^-1 U_i and hence a nonzero determinant. Thus Q_L is nonzero. This uses one common ordinary determinant of U_0, so the same scalar normalizes ALL cyclotomic branches simultaneously. It does not confuse each branch's determinant with the ordinary determinant/norm.

No additional U_0-nonsingularity constraint is needed at the eventual integer grid point. Adjugates and lambda Z_i are always concrete integer matrices. Generic U_0 invertibility is solely a witness that Q_L is nonzero. A grid point where all actual Q_L are nonzero is already a valid simultaneous strong hit, even if U_0 happens to be singular at that point.

The earlier optional-U_0 version would need one more root-count constraint. The final parent note correctly omits it, so the grid degree budget covers exactly at most B required pencils.

## 3. Degree budget

The separately audited raw-lift entry bound is

    2M^2(w+M)+3(M-1).

It includes q-degree of both Newton coordinate changes, eta degree, and u,v lift degrees. Cyclotomic reduction and ordinary regular representation add no degree in q,eta,u,v. Hence the parent’s safe entry bound

    E0=3M^2(w+M+1)

is valid. It dominates the raw bound since

    3M^2(w+M+1)-[2M^2(w+M)+3(M-1)]
      =M^2(w+M)+3M^2-3M+3 > 0.

A cofactor of U_0 has degree at most (d-1)E0, so each Z_i entry has degree at most dE0. Entries of L(lambda Z) have degree at most dE0+1. For order r<=B, its ordinary order is rd, and therefore

    degree Q_L <=rd(dE0+1)<=B d(dE0+1)=T0.

The exact choice

    K=max(M,B T0+2)

is polynomial in n,B. At least K+1 distinct field elements are supplied by the integer grid 0,...,K in characteristic zero or p>K. The bad set for one nonzero Q_L has at most T0(K+1)^4 points in the five-dimensional grid. Union over at most B pencils leaves a good point because B T0<K+1. No coefficient-height or coefficient-field cardinality assumption enters this count.

Fresh formal parameters remain algebraically independent over F even if F already contains elements with the same informal names. This is necessary for the generic proof and is respected by the construction.

## 4. Patch every small characteristic without characteristic input

Enumerate all primes p<=K by an elementary deterministic algorithm. For each such prime, run the audited prime-specific simultaneous strong-list generator with n,B,p. Convert every residue entry to its integer representative in 0,...,p-1 and append its tuples to the one list.

For ANY coefficient field F of characteristic p<=K, reduction of the p-specific appended integer tuple reproduces the original prime-field matrices exactly. Their strong guarantee already quantified over all extension-field coefficients, so no assumption that F is finite, perfect, or equal to the prime field is introduced. For characteristic zero or p>K, the adjugate branch gives the hit. Other branches can be undefined or unsuccessful for a rational expression without harming the hitting-list statement: at least one tuple meets every required domain pencil.

This patch is finite and polynomially charged. There are at most K primes, each has bit length O(log K), and K is an explicit polynomial in n,B. The prime-specific generator's uniform polynomial bounds therefore remain polynomial when repeated for all those primes. Elementary trial primality testing is itself polynomial in K, which is sufficient here; no factoring oracle or nonuniform table is assumed.

## 5. Exact integer generation and bit heights

The constructor need not manipulate a huge symbolic adjugate. For each four-coordinate integer grid point (q,eta,u,v), evaluate all U_i as integer matrices, compute the numeric integer adjugate of U_0 using exact cofactor determinants, form numeric Z_i, then loop over integer lambda. This handles singular U_0 without any special field division or discard.

Newton factors have polynomial-degree integer coefficients with O(w) bits per binomial coefficient. Products of at most M factors, finite unit-triangular inversion, and the fixed-variable polynomial matrix operations give polynomial coefficient bit lengths. Their degree bounds are polynomial, and only four parameter variables occur. Integral cyclotomic reduction for a power-of-two M introduces signs, not coefficient denominators.

Evaluating parameter values at most K adds at most E0 log(K+1), plus polynomial coefficient length and logarithmic summation overhead, to each U_i entry. A d-dimensional cofactor has bit length at most

    O(d times input-entry bit length + d log(d+1)),

by the ordinary determinant bound. Cofactor determinants can be computed by exact integer/rational Gaussian elimination in polynomial bit time; one computes d^2 such determinants. Multiplication by U_i and lambda preserves polynomial bit lengths. The complete large branch has (K+1)^5 tuples and prints n d^2 integer entries per tuple. This is polynomial but has prohibitive exponents. No practical generator run or useful oracle execution is claimed.

## 6. Original rational-expression domains

Take B=2s+1 for a size-s nonzero admissible rational formula over F. The actual-tree inverse-node pencils and root augmentation form at most s+1 feasible affine pencils of orders at most s+2, so both bounds fit B. Their feasibility follows from arbitrary-field HW2015 correctness/free-field/domain equivalence and Proposition 7.3, as recorded in the operational audit.

A simultaneous hit of these pencils makes every inverse occurrence in the original expression defined, including canceled or zero-multiplied branches. The root augmentation makes the defined final value invertible. Thus integer specialization and small-prime patching preserve the actual expression's domain. No primitive root tied to an unknown initial matrix-witness dimension is used.

## Verdict and limits

All-extension coefficients, characteristic two via the small-prime branch, characteristic zero, simultaneous constraints, original expression domains, explicit generation, and integer bit costs survive this audit. No missing lemma was found in this escalation after the optional U_0 constraint was removed.

The result remains an internally reconstructed theorem candidate and a polynomial-size list. The q-Newton expansion, p-coprime symbol-division proof, primary free-field domain theorem, and prime-specific semisimple construction are load-bearing dependencies. It supplies neither a single strong universal matrix point nor practical runtime or a physical exact matrix-output oracle. It makes no novelty or historical-priority claim.
