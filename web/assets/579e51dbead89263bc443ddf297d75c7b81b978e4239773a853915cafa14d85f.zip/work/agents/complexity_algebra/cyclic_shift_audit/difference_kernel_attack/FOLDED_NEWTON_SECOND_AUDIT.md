# Independent second audit: folded q-Newton expansion

Status: no gap found in Section-2 analogue, conditional only on the stated construction. This does not audit the division lift or assert priority.

Let k=F_p(q), with sigma_z fixing k and sending z to qz. At anchors a_i=(1+q)^i the q-orbits are disjoint and each is infinite: an equality a_i q^r=a_j q^s forces r=s by valuation at q=0 and i=j by valuation at q=-1, in every characteristic.

For any h-dimensional V⊂k[z]_{<M}, choose a basis echelon by HIGHEST monomial degree, with distinct degrees e_j. Its Casoratian det(f_j(q^r z)) has top coefficient (product of leading coefficients) det(q^(r e_j)), a nonzero Vandermonde in the distinct elements q^e_j. The coefficients depending on q cause no problem because sigma_z fixes every coefficient. Thus the determinant is nonzero with degree <=h(M-1).

At a fixed anchor, a basis echelon in Newton coordinates has distinct earliest nonzero indices d_ij, equivalently divisibility by product_(s<d_ij)(z-a_iq^s). At z=a_iq^ell, any column with d_ij>ell+h-1 has all entries zero and is divisible by z-a_iq^ell as a polynomial column. Therefore the determinant vanishes to order at least the number of such columns. Summing ell>=0 gives sum_j max(0,d_ij-h+1), and summing all disjoint anchor orbits gives

    sum_i,j d_ij <= h(M-1)+w h(h-1).

This is a lower multiplicity bound, not an equality, and that is sufficient.

For Laurent-series coefficients in eta, conversion between monomial and Newton bases is an invertible matrix over k, independent of eta, hence preserves integral lattices and minimum valuations. An input with a unit Newton coefficient at an index a<=A has image minimum eta valuation <=A under c_a -> eta^a L_(i,M-1-a). Terms at a>A cannot survive the normalized leading reduction. Every surviving output Newton index is >=M-1-A, and distinct basis polynomials prevent cancellation of all leading coefficients. The integral-subspace argument of source Lemmas 2.3-2.4 therefore transfers exactly.

For input dimension k<=B and image sum dimension ell, applying the folded order bound to reduced input/output spaces gives, under ell<=(w-1)k,

    k Delta <= w[k(k-1)+ell(ell-1)] <= w^3 Bk.

This contradicts Delta=4w^3B. Hence dimension sum T_iU>(w-1)dimU. The source's shrunk-subspace implication is characteristic-free, so it yields injectivity of the rectangular feasible-pencil test. Padding gives rank>=rN>(r-1)M when M>B Delta. Formal q,eta must be freshly transcendental over any witness extension used in that implication.

Source: `work/agents/complexity_algebra/sources/pitrational.txt`, Section 2, especially Lemmas 2.2-2.4 and Proposition 2.1. The constant changes because folded orbit vanishing loses h(h-1), rather than ordinary Taylor's binom(h,2).

Pinned source: https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Polynomial-Hitting-Lists-for-Noncommutative-Rational-Formulas-September-24-2026/Polynomial-Hitting-Lists-for-Noncommutative-Rational-Formulas-September-24-2026.pdf (Section 2, Lemmas 2.2-2.4; Proposition 2.1).
