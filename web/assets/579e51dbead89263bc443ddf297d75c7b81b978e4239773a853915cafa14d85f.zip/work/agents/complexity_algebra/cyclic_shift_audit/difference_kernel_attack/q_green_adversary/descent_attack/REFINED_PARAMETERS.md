# Refined parameter descent check

Requested revision: for `m>=2`, take `D=2n(m-1)` and the nilpotent shift `S_m` of size `m`; retain `E=1+binom(D,2)+n(D-1)`. This note assumes the upstream transfer-kernel argument supplies a nonzero homogeneous word-length component with `h<=m-1` inside the new `D` truncation.

The descent is unchanged. Apply Lemma 5.1 to `V_i=S_m tensor U_i` and `g=sum_(|w|<=m-1) f_w w`; `S_m^m=0` makes `f(V)=g(V)`. The common-denominator, regular-at-zero, numerator-degree, arbitrary-field base-change, and multiplication-order arguments in `REPORT.md` depend on `D` and increasing path indices only. They place no lower bound on the marker dimension other than retaining the upstream selected `S_m^h`.

The exact parameters simplify to

```
D = 2n(m-1),
E = 1 + nm[2n(m-1)-1],
d = m D E
  = 2nm(m-1) [1 + nm(2n(m-1)-1)].
```

Thus `d=O(n^3m^4)`. For `m>=2`, the dense output contains exactly

```
n d^2 = 4 n^3 m^2 (m-1)^2 [1 + nm(2n(m-1)-1)]^2
```

prime-field residues. Its bit length is `O(log(d+1)+n d^2(1+log p))`, including fixed dense separators. The construction operations remain bounded by `O(nD^2(nDE+E^2)+nd^2)` residue-array operations plus integer loop/parameter overhead, with bit cost per residue operation polynomial in `log p`. This yields a polynomial-time and polynomial-output bound in `n+m+ceil(log_2 p)`; it does not charge a loop of length `p`.

For `m=1`, `u,v,B_i` are scalars and `f_w=(uv) product_j B_(w_j)`. A nonzero one-state recognizable series therefore has `uv!=0`. Setting each input variable to the scalar `0` detects its constant coefficient, so the output dimension is `d=1`, with `n` zero residues and no denominator descent required. In particular one must branch on `m=1`; the formula `D=2n(m-1)` would otherwise give an invalid zero dimension.

No counterexample or new descent gap was found. The sharpened upstream nonvanishing premise itself was outside this follow-up descent scope.
