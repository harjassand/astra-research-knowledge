# Hostile audit: ordinary prime-field strong descent

Status: no gap found in the assigned semisimple descent, Frobenius branch count, simultaneous grid point, normalization, or polynomial bit-cost argument. The verdict is conditional on the stated premise that each lifted determinant is a nonzero polynomial for every primitive M-th root, with total degree<=D0. This report does not audit or certify the division-algebra lifting proof that supplies that premise. No numerical experiment is used as universal proof evidence.

Candidate inspected: work/agents/complexity_algebra/ALL_CHARACTERISTIC_STRONG_PENCIL_HITTING.md, Sections 3--4 and their algorithmic prerequisites. All writes for this audit stay in the assigned q_green_adversary directory.

## Exact conditional statement

Assume p is a promised prime, M>=1 is coprime to p, and rho=deg Phi_M. The lifted matrices R_i^*(q,eta,u,v) have polynomial parameter entries over F_p[omega]/Phi_M. For every field F of characteristic p, every family of at most B feasible pencils of order<=B, and every primitive root Omega, assume the corresponding determinant polynomials, plus det R_0^*, are nonzero and have total parameter degree<=D0. Take B>=1 and H>=max(16,rho(B+1)D0).

Under these premises, the proposed generator prints a polynomial-size ordinary F_p matrix list, of common order d=M e rho, that contains a tuple simultaneously making the entire family invertible. It does not receive the family or its coefficients. If B=0 is admitted as an input, add the trivial branch printing one empty-family tuple; otherwise explicitly state B>=1.

## 1. Finite field and coefficient algebra

For p>H^2 use E=F_p, e=1, and G={0,...,H^2}. These are H^2+1 distinct residues because H^2<p. For p<=H^2 choose minimal e with Q=p^e>H^2. Minimality gives Q<=pH^2<=H^4 and e<=2log_2 H+1<H for H>=16. Consequently Q>H^2>eH. In both cases |G|>eH and |G|<=H^4.

Enumerating all p^e=Q monic degree-e polynomials is polynomial in H. Exact irreducibility tests are polynomial in e,log p: repeated modular p-powering and gcds suffice. One can avoid factoring e by checking gcd(f,z^(p^j)-z)=1 for every 1<=j<=floor(e/2), together with the usual degree-e Frobenius identity. Every reducible degree-e polynomial has an irreducible factor of degree<=e/2, so this criterion is sufficient. The existence of degree-e irreducibles ensures eventual success. No general deterministic irreducible-construction theorem at unbounded Q is assumed.

The algebra A=E[omega]/Phi_M has F_p dimension e rho. Because p does not divide M, Phi_M is separable modulo p and its roots have exact order M. In the construction's actual prime-power choices M=ell^k, ell in {2,3}, this is especially direct: Phi_M(z)=sum_(j=0)^(ell-1) z^(j M/ell), and a root cannot satisfy z^(M/ell)=1 because that would give Phi_M(z)=ell!=0. Separability follows because Phi_M divides z^M-1, whose derivative is Mz^(M-1), relatively prime to z^M-1. No factorization of Phi_M is needed.

## 2. Branch labels and arbitrary coefficient fields

Let Fbar be an algebraic closure of F. Choose an embedding of E into Fbar. Then

    Fbar tensor_(F_p) A
      = product_(j=0,...,e-1; Omega root Phi_M) Fbar.

There are exactly e rho branches. The map of branch (j,Omega) fixes Fbar, sends a in E to sigma_j(a)=a^(p^j), and sends the class of omega to Omega. The two indices are independent: after fixing an embedding of E, every root of the F_p polynomial Phi_M remains a valid image of omega.

For a grid tuple gamma=(q,eta,u,v) in E^4, a determinant with coefficients in F becomes

    P_(L,Omega)(sigma_j(q),sigma_j(eta),sigma_j(u),sigma_j(v)).

The F-coefficients are unchanged. It would be incorrect to apply Frobenius to arbitrary F-coefficients, but the proposed proof does not do so. The underlying Frobenius map sigma_j permutes E and hence E^4. Thus counting zeros of this composed function is exactly counting zeros of the nonzero polynomial P_(L,Omega) on the same grid. In the large-p case e=1 and only the identity embedding occurs, so the prefix grid need not be Frobenius invariant under anything else.

This also proves the needed consistency of a single grid tuple across all branches: each branch sees a deterministic permutation of that same tuple, rather than an independently chosen parameter point. The union bound is over subsets of the one common grid.

## 3. Simultaneous nonvanishing is strong enough

Schwartz--Zippel's elementary Cartesian-grid count is valid for a polynomial over any field containing the grid, even if its coefficients lie outside E. Each nonzero polynomial of total degree<=D0 has at most D0|G|^3 zeros in G^4. Each branch has at most B+1 determinant constraints. Therefore the total bad set has size at most

    e rho(B+1)D0 |G|^3 <=eH|G|^3<|G|^4.

A single tuple gamma consequently makes every constraint nonzero in every branch.

Over Fbar, the regular representation of A decomposes as the direct sum of the e rho branch evaluations. Replacing an M by M matrix over A by scalar multiplication matrices therefore gives, after a fixed similarity, a block diagonal matrix with the M-dimensional branch evaluations. All-branch determinant nonvanishing is exactly what ensures that this ordinary matrix is invertible after scalar extension to F. No nonzero-element-implies-unit shortcut is used.

In particular the good grid point has invertible ordinary R_0^*. Since that matrix has entries in F_p, it is invertible over F_p itself and survives the generator's singularity filter. Ordinary F_p Gaussian elimination defines X_i=(R_0^*)^(-1)R_i^*. For every affine pencil,

    L(X)=(I_r tensor (R_0^*)^(-1)) (sum_i A_i tensor R_i^*).

Both factors are invertible at the good point after scalar extension to F. The product order is correct, and the constant term becomes A_0 tensor I. This tuple therefore simultaneously hits the whole family.

## 4. Polynomial bit cost, with all output charged

The parameters M,D0,H are explicit polynomials in n,B in the candidate, and e=O(log H). The small-p irreducible search visits at most Q<=H^4 candidates, with polynomial work in e,log p per candidate. The grid visits at most |G|^4<=H^16 points. The algebra dimension is e rho<=M(2log_2 H+1), and the ordinary matrix order obeys

    d=M e rho<=M^2(2log_2 H+1).

Arithmetic in E and A uses polynomial-length coefficient arrays and exact reductions; inverses of M and negative powers of omega are legal because p does not divide M and omega^M=1. All four-parameter lifted entries have polynomial degree and polynomial coefficient counts. Parameter evaluation, regular multiplication matrices, singularity checks, and inversion use polynomially many F_p operations per grid point. Field operations have deterministic bit cost polynomial in log p.

The complete dense output has at most n H^16 d^2 prime-field residues and at most O(n H^16 d^2(1+log p)) bits, plus polynomial headers. The R_0 elimination charge is O(H^16 d^3) F_p operations using ordinary cubic elimination. These bounds are large but are fixed polynomials; no enumeration proportional to the possibly enormous p occurs in the large-p branch.

The candidate's D0 is conservative enough for the displayed lift: per-entry total degree is at most 2M^2(w+M)+3(M-1), and an order-rM determinant has degree at most BM times this quantity, dominated by 10BM^3(w+M+1).

## Verdict and remaining premise

No counterexample or algebraic defect was found in the assigned descent. The branch count e rho, Frobenius permutation, all-branch grid union, ordinary matrix normalization, and bit-cost bounds are mutually consistent for arbitrary characteristic-p coefficient extensions. The only minor specification repair is to state B>=1 or branch separately for B=0.

The theorem remains conditional on the nonzero-polynomial premise for every primitive root. Symbol-division correctness, feasibility-to-nonzero-determinant lifting, rational-expression domain bridges, prior art, and historical novelty are not certified by this audit.
