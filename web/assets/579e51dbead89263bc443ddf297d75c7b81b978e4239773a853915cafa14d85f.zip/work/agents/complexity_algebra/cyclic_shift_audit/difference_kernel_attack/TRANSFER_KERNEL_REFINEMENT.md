# Transfer-kernel refinement: shortest marker and compact q-detector

Status: internally reconstructed candidate theorem, with independent parent and adversarial first checks. No external validation or priority claim. This supersedes the constants in `Q_GREEN_COMPACT_DETECTOR.md`; that file proves a weaker Green-kernel version. The prerequisite is the supplied `pitp.txt`, Proposition 2.2, finite word-series independence. Exact full-matrix output is essential.

## Claim

For n,m>=1, let

    D=max(1,2n(m-1)), E=1+binom(D,2)+n(D-1).

Over F_p(t), take the D-dimensional operator matrices

    (U_i)_(r,q)=(1+t)^[i(r-q-1)]/(t^r-1), 0<=q<r<D,

zero otherwise, and let S_m be a nilpotent shift of dimension m. For EVERY coefficient field F of characteristic p and EVERY nonzero proper recognizable series f_w=uB_wv with <=m states,

    f(S_m tensor U_1,...,S_m tensor U_n) !=0.

All substitutions are jointly strictly lower triangular, so evaluation is always defined. Replacing entries by their expansions modulo t^E and then representing multiplication on F_p[t]/(t^E) yields ordinary prime-field matrices of dimension

    d=m D E=O(n^3m^4).

The same tuple detects all arbitrary extension-field coefficients. The generator knows only n,m,p. For m=1, D=E=1 and zero substitution detects exactly the constant coefficient, which is sufficient: if uv=0 in a one-state realization then f=0.

## Formal setup and Green identity

Let K=F(t), sigma(g)(z)=g(tz), b_i(z)=z/(1-(1+t)^i z), J_i=(sigma-1)^(-1) M_(b_i), with zero-constant inverse. Introduce lambda and write

    C_lambda(z)=lambda sum_i b_i(z) B_i,
    A_lambda(z)=I+C_lambda(z),
    H_lambda(z)=sum_w lambda^|w| B_w h_w(z).

Coefficientwise z-local finiteness makes H well-defined in GL_m(K[lambda][[z]]). It solves sigma H=A H and H(0)=I; every coefficient has bounded lambda degree because each J raises order.

For an arbitrary seed a(z), write X[a]=sum_w lambda^|w| B_w J_w(a)v and Y[a]=X[a]-a v. Prefix splitting gives

    (sigma-1)Y=C_lambda(Y+a v), Y(0)=0.

Writing Y=H V therefore gives

    (sigma-1)V=H_lambda(tz)^(-1) C_lambda(z) v a(z), V(0)=0.

Consequently, with the linear functional

    I_z[F(z,y)]=sum_(r>=1) [y^r]F(z,y) z^r/(t^r-1),

the exact operator identity is

    f(lambda J)a-u v a=I_z[K_lambda(z,y)a(y)],
    K_lambda(z,y)=uH_lambda(z)H_lambda(ty)^(-1)C_lambda(y)v.

Here K lies in y K[lambda][[z,y]]. No convergence beyond formal coefficientwise local finiteness is used. The shifted inverse H(ty)^(-1) is forced by sigma variation of constants.

## The transfer kernel and the low marker degree

If uv!=0, every strict-triangular evaluation has nonzero diagonal and we are done. Assume uv=0 and m>=2. Define

    L_lambda(z,y)=uH_lambda(z)H_lambda(y)^(-1)v.

Then

    L_lambda(z,0)=uH_lambda(z)v=f(lambda J)1,
    L_lambda(y,y)=uv=0,
    K_lambda=(1-sigma_y)L_lambda,

where sigma_y substitutes y->ty and fixes z. The last identity follows from H(y)^(-1)=H(ty)^(-1)A_lambda(y). Matrix order is preserved exactly.

A nonzero homogeneous word-length part of f is a finite linear combination of h_w. Source Proposition 2.2 makes it nonzero, so f(lambda J)1!=0. Thus L_lambda!=0. This uses only finite-word faithfulness and the explicit marker; it never assumes unmarked infinite-series faithfulness.

Over F(t,lambda)(z), define R_0=u and R_(j+1)=sigma(R_j) A_lambda. Then

    L_lambda(t^j y,y)=R_j(y)v.

The rational span of the first independent rows R_0,...,R_(k-1), k<=m, contains every R_j: at the first dependence R_k=sum_(j<k)c_jR_j, applying the semilinear map R->sigma(R)A expresses R_(k+1) in that same span. Iterate. Therefore if all first m shifted diagonals vanish, all infinitely many shifted diagonals vanish.

For each finite total degree d, its homogeneous part has the form L_d(z,y)=sum_(a+b=d)l_(a,b)z^ay^b. Vanishing at z=t^j y for all j makes the finite polynomial sum_a l_(a,d-a) X^a vanish at infinitely many distinct t^j in F(t,lambda). Hence it is zero. This proves all first m diagonals cannot vanish. The zeroth diagonal is identically uv=0, so some

    1<=j<=m-1

has nonzero R_j(y)v.

Let Q(y)=prod_i(1-(1+t)^i y), M(y)=sum_i y prod_(l!=i)(1-(1+t)^l y)B_i, and P_lambda(y)=Q(y)I+lambda M(y). Both y-degrees are <=n. Then

    R_j(y)v = [u P_lambda(t^(j-1)y)...P_lambda(y)v]
               / prod_(e=0)^(j-1) Q(t^e y).

The denominator is lambda-independent and has constant term one. The numerator has lambda-degree <=j<=m-1 and y-degree <=nj<=n(m-1). Its lambda^0 term is zero because uv=0. Choose a nonzero coefficient lambda^h, 1<=h<=m-1. Its diagonal has order delta<=n(m-1), so the corresponding homogeneous total-degree delta part L_(h,delta) is nonzero.

Since L_lambda(y,y)=0, EACH lambda coefficient and EACH homogeneous total-degree part has zero ordinary diagonal. A nonzero L_(h,delta) cannot consist solely of a pure z^delta term; it necessarily has a nonzero term z^a y^b with b>=1. Applying 1-sigma_y multiplies its coefficient by 1-t^b!=0. Therefore K_(h,delta) is also nonzero. Choose any nonzero homogeneous K_h component of total degree d<=delta<=n(m-1).

## Full-matrix recovery by q-Cauchy moments

Write K_(h,d)=sum_(b=1)^d c_b z^(d-b)y^b with not all c_b zero. Applying it to seeds y^q for q=0,...,d-1 yields the output coefficient at z^(d+q)

    sum_(b=1)^d c_b/(t^(b+q)-1).

The square matrix M_(q,b)=1/(t^(q+b)-1) is Cauchy: M_(q,b)=t^(-b)/(t^q-t^(-b)). Its row parameters t^q (q>=0) and column parameters t^(-b) (b>=1) are individually distinct and mutually disjoint. Hence its determinant is nonzero in EVERY characteristic. Some q<d gives a nonzero matrix entry at output index d+q<=2d-1<D.

By the exact Green identity, that entry belongs to f_h(J), and truncation gives f_h(U)!=0. With S_m,

    f(S_m tensor U)=sum_(h=0)^(m-1)S_m^h tensor f_h(U).

The powers S_m^0,...,S_m^(m-1) are linearly independent over F(t), so this matrix is nonzero. The m marker states exactly retain all h<m; the proof does not need a degree-m component.

## Descent and output cost

Let Delta(t)=prod_(r=1)^(D-1)(t^r-1). Its degree is binom(D,2), and it is a unit at t=0. Any word matrix entry is a sum over strict index paths q=q_0<q_1<...<q_h=r. Every path denominator is a product of factors t^(q_j)-1 for distinct q_j, hence formally divides Delta. Its numerator is (1+t)^M with M<=n(D-1). Thus Delta times EACH entry of the graded evaluated matrix has polynomial t-degree <=binom(D,2)+n(D-1)<E. Arbitrary extension-field coefficients do not change this degree bound.

Reducing Ui entries modulo t^E preserves a nonzero evaluated entry: otherwise its nonzero cleared polynomial numerator of degree <E would vanish modulo t^E. Applying the injective multiplication representation of F_p[t]/(t^E) gives prime-field matrices of dimension mDE. After any scalar extension to F, the coordinates 1,t,...,t^(E-1) remain linearly independent, so uniform detection is retained. All inverses needed in the truncated ring are units t^r-1, with explicit inverse -sum_(kr<E)t^(kr).

Construction time and output length are polynomial in n,m,log p. Dense output alone costs n(mDE)^2 prime-field entries; oracle responses and later arithmetic must also be charged. This does not acquire a useful external matrix-output oracle, bound arbitrary input coefficient heights, or certify priority.

## Verification scope and remaining uncertainty

`Q_GREEN_EXACT_CHECKS.json` checks the exact Green operator and shifted diagonals on twenty dense 2-state/2-letter cyclic models, half in GF(101), half in GF(2^8), marker degree through four, with 3920 exact identities and nonzero Cauchy determinants through d=8. This finite diagnostic does not prove the theorem. `TRANSFER_KERNEL_EXACT_CHECKS.json` additionally checks eighty dense cyclic models with m=2,3 over those two fields at the REFINED z-dimension 2n(m-1), retaining marker degrees below m. It records 20760 exact Green/transfer/difference/shifted-diagonal equalities, and compact detection agrees with independent reachable-row-span all-word zero certificates on all eighty models (79 nonzero, one zero). These are finite checks, not a universal proof certificate. Independent adversarial proof review is recorded in `q_green_adversary/TRANSFER_AUDIT.md`; it found no algebraic gap and confirmed descent, conditional on the source prerequisite. The universal proof depends on the supplied source word-independence proposition; independent hostile review and prior-art comparison remain required.

Pinned primary prerequisite: https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Uniform-Matrix-Hitting-Points-in-Every-Positive-Characteristic-October-4-2026/uniform-matrix-hitting-points-positive-characteristic.pdf (Proposition 2.2; equation (23)).
Characteristic-zero inspiration record: https://raw.githubusercontent.com/harjassand/astra-research-knowledge/778b78af5d4bbde608ce3fc775049ceaeb55a2d3/web/pages/d-daae0ce9b7b6e2ee.html (Derivation section; internal source status).
