# Adversarial audit: prime-field descent and construction

Scope: Section 4 of `Q_GREEN_COMPACT_DETECTOR.md`, with the upstream nonvanishing and order bound treated as premises. Source checked: `pitp.txt`, equation (23), Section 5.2 and Lemma 5.1, and the explicit construction (28). The supplied files were read only.

Verdict: no gap or counterexample found in this section. This is a conditional validation of the descent step, not a validation of Sections 1–3 or a universal theorem certificate.

## Exact finite object to descend

Set `V_i = S tensor U_i`, where `S` is the standard nilpotent shift of size `m+1`. Because `S^(m+1)=0`, every recognizable-series evaluation at `V` is the evaluation of the finite noncommutative polynomial `g = sum_(|w|<=m) f_w w`. Consequently Lemma 5.1 applies directly to `g` and `V`; applying that polynomial lemma to an untruncated infinite expression is unnecessary. Each entry of `V_i` is regular at `t=0` and has prime-field rational coefficients.

## Denominator and numerator attacks

For a nonzero contribution to a length-`h` product of the `U_i`, the row indices form `q=q_0<q_1<...<q_h=r`. The denominator is a product of the indexed factors `(t^(q_j)-1)`, with each index appearing at most once. Its quotient into `Delta = product_(a=1)^(D-1) (t^a-1)` is the product of the unselected indexed factors and is therefore a polynomial in every characteristic. This argument makes no squarefreeness or pairwise-coprimality assumption. For example in characteristic 2, `(t^2-1)=(t-1)^2`, but selecting indices 1 and 2 consumes exactly the three corresponding copies of `(t-1)` already present in `Delta`.

The numerator exponent is at most `n[(r-q)-h]`; the letter order along the ascending path is the reverse of the written operator-product order, but this has no effect on the bound. Multiplication by `Delta` produces a polynomial of degree at most `binom(D,2)+n(D-1)=E-1`. The empty word contributes `Delta` times an identity entry. The `S` factors contribute only 0 or 1. Arbitrary coefficients in `F` may cancel these polynomials but cannot increase their degree.

## Taylor reduction and arbitrary coefficient fields

Every denominator `(t^r-1)` has constant term `-1`, including characteristic 2, and `Delta(0)=(-1)^(D-1)` is nonzero. Thus reduction is the unital algebra map from the ring of rational functions regular at zero into `F[t]/(t^E)`; it uses no derivatives, factorials, roots, or separability assumptions. A nonzero cleared numerator of degree below `E` cannot reduce to zero. This proves preservation of upstream nonvanishing.

The base-change identity `F tensor_(F_p) F_p[t]/(t^E) = F[t]/(t^E)` is valid for every field extension `F/F_p`. Multiplication on `F[t]/(t^E)` is injective because its action on the vector 1 returns the multiplying element. Thus the images of `1,t,...,t^(E-1)` stay linearly independent over `F`, and arbitrary extension-field word coefficients introduce no descent defect.

## Marker and order

The safe descended tuple is `W_i = S tensor rho(U_i mod t^E)`, equivalently the entrywise application of the matrix-ring embedding to `V_i`. Its dimension is `(m+1)DE`. This operation preserves multiplication order, scalar coefficients, and the identity. Nilpotence of `S` still kills all word lengths greater than `m`; the `m+1` shift size retains `S^m`. Nothing requires reducing the shift automorphism itself modulo `t^E`.

## Explicit cost witness

Let `B=n+m+ceil(log_2 p)+1`, with `n,m>=1` and prime `p` promised. Then `D=O(B^2)`, `E=O(B^4)`, and `d=O(B^7)`, more precisely `d=O(n^3 m^4)`.

For each entry with `q<r`, compute `(1+t)^(i(r-q-1)) mod t^E` by at most `n(D-1)` repeated multiplications by `1+t`; compute the denominator inverse as `-sum_(j=0)^floor((E-1)/r) t^(rj)`; multiply and truncate with ordinary coefficient-array arithmetic modulo `p`. A loose bound per entry is `O(nDE+E^2)` residue operations, for at most `nD^2` entries. Forming the multiplication blocks is Toeplitz copying, and tensoring with `S` inserts their positions and zeros. Every loop bound is polynomial in `B`; all residue operations have bit cost polynomial in `log p` because coefficients are reduced after each operation. No loop has length `p` and no polynomial factorization or extension-field acquisition is needed.

Dense output contains `n d^2` residues and has bit length `O(log(d+1)+n d^2(1+log p))`, hence a polynomial bound (for example `O(B^16)`, allowing standard separators). This is construction cost only. Evaluation of an arbitrary externally supplied series and representation of its arbitrary-field response are separate interface charges.

Suggested exposition clarification only: explicitly say that Lemma 5.1 is applied to `V_i=S tensor U_i` and the truncation `g`; replace "without repeated factors" by "selecting distinct indexed factors" to avoid an accidental squarefree reading. Neither clarification repairs an identified mathematical failure.

No numerical experiment was used to infer the general claim.
