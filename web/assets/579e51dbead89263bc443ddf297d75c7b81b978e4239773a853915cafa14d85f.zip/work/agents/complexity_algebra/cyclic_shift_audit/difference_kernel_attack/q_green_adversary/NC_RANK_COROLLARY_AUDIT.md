# Brief hostile check: exact nc-rank from the universal strong list

Status: the proposed corollary is valid conditional on the audited strong-pencil list. The original nonsingular-submatrix fact holds over arbitrary division rings. The universal normalized-rank upper bound follows directly from Cohn's polynomial inner-rank characterization, so no additional blow-up-attainment or characteristic restriction is needed.

## Original submatrix at division-ring rank

Let Z be an a by b matrix over a division ring D, with rank s. For s>=1, choose a nonzero original entry and move its row and column to the first position. Write

    Z=[a b; c E],   a!=0.

Invertible block elimination gives rank Z=1+rank(E-ca^(-1)b). By induction the Schur complement has an invertible (s-1) by (s-1) submatrix indexed by row/column sets I,J among the remaining ORIGINAL indices. The bordered ORIGINAL submatrix

    [a b_J; c_I E_(I,J)]

has that Schur complement and is invertible by the same block elimination. Undoing permutations gives an invertible s by s original submatrix of Z. This uses neither commutative determinants nor a transformed linear combination of original rows/columns as the eventual selected submatrix. For s=0 the assertion is vacuous.

## Lower and upper evaluation bounds

Let L(x) be an order-r affine pencil over any characteristic-p field F, and let s be its rank over the free skew field F<(x)>. An invertible original s by s submatrix is itself an affine pencil in the same variables. Hrubes--Wigderson, Theory of Computing 11(14), 2015, Proposition 7.3, provides an invertible matrix evaluation over an extension whenever such an affine pencil is invertible over the free skew field. The proof simultaneously evaluates expressions for all entries of its inverse. It is characteristic independent. The inspected local source is work/agents/complexity_algebra/sources/hw2015.txt, Proposition 7.3 (journal pp377--378); DOI 10.4086/toc.2015.v011a014.

Applying the universal strong list with B=r to this ONE feasible subpencil yields a tuple X of dimension d for which its sd by sd block evaluation is invertible. Therefore rank_F L(X)>=sd. The generator does not need the value s or the submatrix indices; the subpencil is used only in the existence proof.

For the matching upper bound, Cohn's theorem identifies free-field rank with inner rank over the free polynomial algebra. Thus L admits a POLYNOMIAL factorization L=P Q of width s over F<x>. Evaluating this identity at any matrices of dimension d is always legal, and gives rank_F L(X)<=sd. Rational factorization would leave a possible denominator/domain gap; polynomial inner-rank factorization avoids it.

This all-field theorem is stated in the primary Fortin--Reutenauer paper, Section 2, journal pp3--4, which defines the coefficient field without any infinitude or characteristic condition. Their Theorem 2.1 additionally supplies the linear zero-block characterization. The infinitude assumption appearing later in Section 3 concerns scalar commutative ranks and does not apply here. Primary source: https://www.mat.univie.ac.at/~slc/wpapers/s52reut.pdf .

Consequently

    ncrk_F L = max_(X in universal list) rank_F L(X)/d.

The maximum is attained at an integer s, but ranks at other list points need not be multiples of d. If s=0, the polynomial inner-rank identity forces L=0 and every evaluation has rank zero. If n=0, the claim reduces to rank(A_0 tensor I_d)=d rank A_0. The strong generator's constant R_0 constraint keeps its retained list nonempty for B>=1.

## Operational scope

This is a coefficient-independent, deterministic, nonadaptive matrix-query list, polynomial in n+r+log p, valid uniformly over every coefficient extension F. Exact ordinary-rank replies permit direct integer processing of the rank/d quotients. Complete matrix replies suffice if exact arithmetic over their represented field F is available; elimination uses polynomially many such field operations, but their bit costs and the oracle's evaluation cost depend on the coefficient-field representation and must be charged separately. For an unspecified abstract F, do not claim a total bit algorithm processing arbitrary field elements from their mere names.

Known coefficient-aware nc-rank algorithms remain required comparators. The corollary does not establish novelty, a useful acquired oracle, or a coefficient-height-independent cost for executing that oracle.
