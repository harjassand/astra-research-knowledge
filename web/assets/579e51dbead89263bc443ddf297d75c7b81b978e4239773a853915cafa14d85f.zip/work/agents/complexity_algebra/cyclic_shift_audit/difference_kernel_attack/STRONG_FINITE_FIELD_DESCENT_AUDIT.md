# Independent audit: ordinary prime-field descent through all etale branches

Status: the finite-field/branch-counting construction is valid under the stated premise that every root-specific lifted determinant is a NONZERO polynomial of total degree <=D0. This note does not establish that division-lift premise. No irreducibility/factorization assumption on the cyclotomic polynomial is required.

Assume gcd(M,p)=1. The reduction of Phi_M over F_p has phi(M) distinct roots, each of exact order M; this follows because x^M-1 is separable and the cyclotomic factorization distinguishes exact orders when p does not divide M. For Q=p^e, A=F_Q[omega]/Phi_M is finite etale over F_p, of dimension e phi(M). Over an algebraic closure of ANY coefficient field F of characteristic p,

    Fbar tensor_(F_p) A = product_(0<=j<e, Phi_M(omega)=0) Fbar.

There are exactly e phi(M) branches. The embedding on a grid parameter gamma in F_Q is gamma -> gamma^(p^j), while omega independently ranges over primitive M-th roots. The coefficients of the INPUT pencils in F stay fixed. They must not be Frobenius-transformed. This is legitimate because only the coefficient algebra A is represented over F_p and then scalar-extended to F.

Each Frobenius is a bijection of F_Q and hence of F_Q^4. For a root-specific nonzero determinant polynomial P_omega over Fbar of total degree <=D0, the ordinary grid root bound gives at most D0 Q^3 bad grid tuples after composing with a branch Frobenius. This does NOT require polynomial coefficients to lie in F_Q.

If at most B+1 constraints include the base lift R0 and H>=phi(M)(B+1)D0, the union of bad tuples over all branches and constraints has size at most eH Q^3. For H>=16 and the minimal e with Q=p^e>H^2, one has e<=2log_2(H)+1<H, hence eH<H^2<Q. Thus the union is strictly smaller than Q^4. A grid tuple simultaneous for every branch exists. The conclusion is invertibility of the full ordinary regular-representation pencil over F, since it becomes blockwise invertible over the faithfully extending Fbar.

When p>H^2, no extension enumeration is needed. The integer grid {0,...,H^2} has H^2+1 DISTINCT elements of F_p. Its side length is greater than H, so the same union bound with e=1 supplies a simultaneous point using polynomially many tuples, even if p is astronomically large.

When p<=H^2, minimality gives Q<=pH^2<=H^4. Enumerating all monic degree-e polynomials over F_p costs Q candidates. Exact deterministic irreducibility checks use repeated modular powers and polynomial gcds, polynomial in e and log p; the existence of degree-e irreducibles guarantees termination. Factoring e, if used in the standard test, is inexpensive because e=O(log H). Thus the field construction, Q^4 grid enumeration, and arithmetic in A are polynomial in H,M,log p. The exponents of this polynomial can be large and should not be disguised as practical cost.

The generator represents the MxM lifts by M e phi(M) ordinary matrices over F_p. It checks invertibility of the regular R0 by finite-field Gaussian elimination and discards tuples with singular R0. At a good tuple, R0 is invertible on every branch, so it survives. Define X_i=regular(R0)^(-1) regular(R_i). Then

    A0 tensor I + sum_i Ai tensor X_i
      = (I tensor regular(R0)^(-1)) sum_(i>=0) Ai tensor regular(R_i),

which is invertible at the simultaneous good tuple. The matrix dimension is M e phi(M), and list/output/inversion charges are polynomial. The construction remains uniform for arbitrary extension-field input coefficients because the branch argument fixes those coefficients and selects the tuple existentially.

Important boundary: the four-parameter determinant degree D0 must bound the ACTUAL polynomial lifts before normalization. If parameters occur rationally, all required denominators must be included among bad conditions with their degree charged. R0 normalization is safely postponed until after the grid point is selected and tested. No nilpotent parameter specialization is asserted.
