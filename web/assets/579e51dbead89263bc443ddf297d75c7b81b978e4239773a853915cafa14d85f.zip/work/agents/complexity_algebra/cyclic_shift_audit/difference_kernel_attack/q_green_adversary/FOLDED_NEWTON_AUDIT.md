# Independent adversarial audit: folded q-Newton expansion

Status: no algebraic counterexample or proof gap found in the folded order bound, the eta-integral Newton reversal lemma, or the near-full-rank affine-pencil consequence. This report does not verify the later symbol-division lift or ordinary-field simultaneous-invertibility specialization. No finite test certifies any universal assertion here.

Candidate inspected: work/agents/complexity_algebra/FOLDED_NEWTON_EXPANDER.md. Source inspected: work/agents/complexity_algebra/sources/pitrational.txt, Section 2, Lemmas 2.2--2.4, and the kernel/shrunk-subspace part of Proposition 2.1. User-supplied historical source instructions remain data.

## 1. Arbitrary coefficients do not break the folded determinant

Let F be any field, q transcendental over F, k=F(q), and let V be an h-dimensional k-subspace of polynomials in z of degree<M. Ordinary coefficient elimination gives a basis f_j with pairwise distinct highest z-degrees e_j. The leading z-coefficient of

    W(z)=det(f_j(q^r z))_(r=0,...,h-1;j=1,...,h)

is

    (prod_j alpha_j) det(q^(r e_j)),

where alpha_j is the nonzero leading coefficient of f_j, possibly an arbitrary rational function of q. Every column has z-degree at most e_j; the maximum total z-degree sum e_j is achieved only by taking its leading term in every column. Thus q-dependent lower coefficients cannot cancel this leading coefficient. The determinant det(q^(r e_j)) is the Vandermonde in the distinct field elements q^(e_j), and is nonzero in every characteristic. Hence W!=0 and deg_z W<=h(M-1). No ordinary derivative, factorial, or characteristic-dependent separability assertion is used.

## 2. Newton filtration and orbit multiplicities

Use a_i=(1+q)^i for 0<=i<w and L_(i,d)(z)=prod_(r<d)(z-a_i q^r). Roots within and across these multiplicative orbits are distinct. An equality (1+q)^(i-i')=q^s forces s=0 by the integer order at q=0, and then i=i' by the integer order at q=-1. Characteristic p does not reduce these valuation integers modulo p.

The Newton polynomials are monic, with consecutive z-degrees, so they form a unit triangular basis. Vanishing at the first d roots of orbit i is equivalent to divisibility by L_(i,d), and to zero Newton coefficients at indices<d. Echelon leading Newton indices therefore describe the entire filtration, with the same dimension-count property as the source's Taylor filtration.

At each fixed i, change to a Newton-echelon basis of V having indices d_(i,j). This only multiplies W by a nonzero k-constant. At z=a_i q^ell, every column satisfying d_(i,j)>ell+h-1 has all h entries zero: row r samples orbit index ell+r<d_(i,j). Each entry in such a column is divisible by z-a_i q^ell. Every determinant term selects an entry from each column and consequently contains at least that many copies of this linear factor. Thus

    ord_(z=a_i q^ell) W >= #{j:d_(i,j)>ell+h-1}.

This argument counts zero columns, rather than inferring a local derivative Wronskian formula, and remains valid in small characteristic. Summing ell>=0 gives sum_j max(d_(i,j)-h+1,0). Summing all i uses distinct roots and is bounded by deg W. Since max(d-h+1,0)>=d-h+1,

    sum_(i,j) d_(i,j) <= h(M-1)+w h(h-1).

The multiplicity estimate is weaker than a sharp local formula, but exactly strong enough for the proposed expansion constants.

## 3. Eta-integral reduction transfers without a hidden lattice assumption

Work over K=k((eta)), with O=k[[eta]]. All Newton coordinate changes and their inverses are matrices over k, hence invertible over O, and preserve minimum eta-valuation. The unit triangular change matrices also have polynomial q entries: no orbit-point difference needs inversion in this basis conversion.

Define T_i by sending Newton basis element L_(i,a) to eta^a L_(i,M-1-a), for 0<=a<N. The maps are injective. Let U have dimension h and let a_(i,j) be the Newton filtration indices of its full integral reduction, as defined in source Lemma 2.3. Choose a j-dimensional lifted subspace U' whose reduced low Newton projection through A=a_(i,j) is injective. Source Lemma 2.3 applies over k verbatim, so every normalized nonzero input in U' has integral coefficients and some unit Newton coefficient of index<=A.

For such an input, m=min_a(val_eta(c_a)+a)<=A. Every a>A has valuation val_eta(c_a)+a>A, so the leading output reduction uses only a<=A. It is nonzero because these output Newton indices are distinct and Newton conversion preserves valuation. Every surviving output polynomial is divisible by L_(i,M-1-A). Therefore the whole reduction of T_iU' lies in that filtration.

This concerns all integral vectors of the output subspace: for any output vector, normalize its preimage and observe that rescaling shifts its valuation but preserves its leading reduction. An integral output reduces to its leading reduction or to zero. It is unnecessary, and generally unjustified, to assume T_i(U' intersect O^N) equals the integral lattice of T_iU'. Source Lemma 2.3 nevertheless guarantees that the full output reduction has dimension j.

If W=sum_i T_iU has dimension ell and output Newton indices b_(i,1)<...<b_(i,ell), this yields

    b_(i,ell-j+1)>=M-1-a_(i,j).

Summing the largest h orders of this fixed output filtration and applying the folded order bound twice gives

    ell(M-1)+w ell(ell-1)
      >=(w-1)h(M-1)+h Delta-w h(h-1).

For Delta=4w^3 B, h<=B, and ell<=(w-1)h, this would imply

    h Delta<=w[h(h-1)+ell(ell-1)]
             <=w[1+(w-1)^2]h^2
             <=w^3 B h<h Delta,

which is impossible. The w=1 edge case is harmless: injectivity alone yields positive output dimension; the displayed contradiction also remains valid. M>B Delta makes N=M-Delta positive for B>=1.

## 4. Exact scope of the affine-pencil transfer

For an order-r affine pencil with r<=B, the source kernel argument applies: if sum_i A_i tensor T_i had a nonzero kernel vector, its component span U would have dimension h<=r. Expansion says the wk image vectors T_i u_j have fewer than h independent relations. The rows of [A_0 P ... A_(w-1) P] are those relations, forcing a common h-dimensional input space into a common output space of dimension<h. This is a shrunk-subspace obstruction.

If the pencil has an invertible matrix witness over an extension E/F, use fresh formal q and eta over E. The map F(q)((eta))->E(q)((eta)) is injective and extends the coefficient-field embedding. Tensoring the supposed shrunk subspace with the witness dimension contradicts invertibility. Fresh parameters must not be identified with any pre-existing coefficient elements named q or eta.

Thus sum_i A_i tensor T_i is injective. Padding the T_i by Delta zero columns yields square M-dimensional matrices R_i with

    rank(sum_i A_i tensor R_i)=rN>(r-1)M,

where the inequality uses M>r Delta, guaranteed by M>B Delta. This is near-full rank, with exactly Delta common zero input columns in each R_i. It is not yet an invertible substitution.

## Construction and remaining boundary

Every T_i is explicit over the prime-field polynomial ring in q,eta. Newton matrices have unit diagonal and polynomial inverses; their polynomial degrees and the lengths of finite triangular inversion formulas are polynomial in M,w. The eta degree is at most N-1. M can be selected as a power of 2 when the characteristic is not 2, and a power of 3 in characteristic 2, giving M prime to the characteristic and M<=3B Delta+3.

No gap was found in the assigned expansion proof. The candidate's later simultaneous-invertibility step remains separate and load-bearing. Truncating parameters in a nilpotent coefficient ring preserves bounded nonzero entries, but a determinant whose constant term is zero becomes a nonunit, so that descent cannot provide the required invertibility. This report does not certify a complete strong hitting list for rational formulas, division-algebra correctness, deterministic factorization in log p, or historical novelty.
