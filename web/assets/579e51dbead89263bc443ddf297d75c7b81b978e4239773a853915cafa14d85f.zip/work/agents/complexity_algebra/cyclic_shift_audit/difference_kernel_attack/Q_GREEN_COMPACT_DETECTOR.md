# A compact positive-characteristic proper-cyclic detector from a q-Green kernel

Status: candidate proof reconstructed independently from the supplied shift primitive. Not an external or formal correctness certificate; no priority claim. The principal source prerequisites used are Proposition 2.2 (finite word-series independence) of `pitp.txt` and its explicit operator entries (23). The row-closure and q-Green composition below are deductions.

## Exact interface and claim

Let F be ANY field of characteristic p (arbitrary extension-field coefficients are allowed). A proper recognizable series has coefficients f_w=u B_w v for u in F^(1 x m), v in F^(m x 1), B_i in Mat_m(F), with no acyclicity assumption. Set K=F(t), sigma(g)(z)=g(tz), a_i=(1+t)^i, b_i(z)=z/(1-a_i z), and J_i=(sigma-1)^(-1) M_{b_i}, with zero-constant inverse. Every J_i raises z-order. Let U_i be its truncation on K[z]/z^D, D=2nm:

    (U_i)_(r,q) = (1+t)^[i(r-q-1)]/(t^r-1), 0<=q<r<D,

and zero otherwise. Let S be a nilpotent shift of dimension m+1. Then the candidate theorem is

    f != 0 implies f(S tensor U_1,...,S tensor U_n) != 0.

The matrix dimension over F_p(t) is 2nm(m+1). A descent to ordinary prime-field matrices has dimension

    d = (m+1) D E,
    E = 1 + binom(D,2) + n(D-1),

so d=O(n^3 m^4), uniformly in p including p=2. All evaluations exist by joint strict triangularity. Construction needs only n,m,p, not the hidden B_i,u,v. The output is the complete exact matrix. Costs of implementing an external full-matrix service are separate.

## 1. Exact q-Green kernel

Introduce the commuting formal marker lambda and put C_lambda(z)=lambda sum_i b_i(z)B_i, A_lambda=I+C_lambda. There is a unique H_lambda in GL_m(K[lambda][[z]]) satisfying

    sigma H_lambda = A_lambda H_lambda, H_lambda(0)=I.

Coefficient recursion divides only by t^r-1 for r>=1. Moreover H_lambda=sum_w lambda^|w| B_w h_w: all coefficients in z have only finitely many words because J_i raises order. The inverse also has polynomial-in-lambda coefficients at each z-order.

For an arbitrary a in K[lambda][[z]], let

    X[a](z)=sum_w lambda^|w| B_w J_w(a)(z) v,
    Y[a]=X[a]-a v.

All sums are z-locally finite. Splitting nonempty words by their first letter gives

    (sigma-1)Y = C_lambda(Y+a v), Y(0)=0.

Write Y=H_lambda V. Since sigma H=A H,

    (sigma-1)V = H_lambda(tz)^(-1) C_lambda(z) v a(z), V(0)=0.

For a bivariate formal series F(z,y) divisible by y, define the Jackson functional

    I_z[F] = sum_(r>=1) [y^r]F(z,y) z^r/(t^r-1).

It is well-defined z-adically when the coefficients are nonnegative powers of z. The exact identity is

    f(lambda J)a(z)-u v a(z) = I_z[K_lambda(z,y)a(y)],
    K_lambda(z,y)=u H_lambda(z) H_lambda(ty)^(-1) C_lambda(y)v.

Thus K_lambda lies in y K[lambda][[z,y]], with finite lambda degree at each total z,y degree. This identity uses the sigma-shift in the SECOND H factor; replacing H(ty)^(-1) by H(y)^(-1) is incorrect.

If uv != 0, every strict-triangular evaluation detects f on its diagonal immediately. Assume uv=0 henceforth. If f != 0, some homogeneous word-length part is nonzero (indeed a nonzero coefficient occurs below length m by ordinary reachable-span stabilization). Proposition 2.2 implies its finite h_w combination is nonzero. Therefore f(lambda J)1 != 0, so the exact identity forces K_lambda != 0. No faithfulness of an infinite UNMARKED series is assumed.

## 2. Rational row closure forces a low-degree shifted diagonal

Work over L=F(t,lambda). Define

    R_0(z)=u,
    R_(j+1)(z)=sigma(R_j)(z) A_lambda(z).

Then sigma^j(uH)=R_j H. For every j>=0,

    K_lambda(t^(j+1)y,y)=R_j(ty) C_lambda(y)v.

Indeed H(t^(j+1)y)H(ty)^(-1)=A(t^j y)...A(ty), with empty product I for j=0.

The rows R_j are in L(z)^(1 x m). Let k<=m be the first index for which R_0,...,R_k are dependent, so R_0,...,R_(k-1) are independent. (A nonzero f entails u!=0.) Express R_k in their span. Applying the semilinear operation R -> sigma(R) A expresses R_(k+1) in that span too, because the images are R_1,...,R_k. Induction gives EVERY R_j in the same rational span.

Suppose all first m shifted diagonals vanish. In particular all j<k vanish, hence row closure makes EVERY j>=0 diagonal zero. For each total degree d, write the homogeneous kernel component

    K_lambda,d(z,y)=sum_(a+b=d,b>=1) kappa_(a,b) z^a y^b.

The coefficient of y^d on its j-th diagonal is

    P_d(t^(j+1)), P_d(X)=sum_(a+b=d,b>=1) kappa_(a,b) X^a in L[X].

The elements t^(j+1) are infinitely many distinct elements of L. A finite-degree polynomial cannot vanish at all of them unless P_d=0. Thus every homogeneous kernel component vanishes, contrary to K_lambda!=0. This is a bounded-polynomial inference for each homogeneous component, not an ungraded infinite-faithfulness inference.

Consequently some j<m has a nonzero diagonal.

Set Q(y)=prod_i(1-a_i y), L_0(y)=sum_i y prod_(l!=i)(1-a_l y)B_i, and P_lambda(y)=Q(y)I+lambda L_0(y). These have y-degree <=n, and Q(0)=1, L_0(0)=0. The chosen diagonal has the explicit presentation

    numerator N_j(lambda,y)=u P_lambda(t^j y)...P_lambda(ty) lambda L_0(y)v,
    denominator Q(y) prod_(e=1)^j Q(t^e y).

For j=0 the P product is empty. The denominator is independent of lambda and a unit at y=0. Therefore

    deg_lambda N_j <= j+1 <= m,
    deg_y N_j <= n(j+1) <= nm,
    lambda divides N_j.

Some coefficient lambda^h, 1<=h<=m, is nonzero. Its diagonal y-order is <=nm, hence K_h=[lambda^h]K_lambda has a nonzero homogeneous component of total degree d<=nm.

## 3. q-Cauchy moments recover that component

Write a nonzero homogeneous component as

    K_h,d(z,y)=sum_(b=1)^d c_b z^(d-b)y^b.

Apply the kernel operator to a(y)=y^q. The coefficient of z^(d+q) is

    sum_(b=1)^d c_b/(t^(b+q)-1).

Use q=0,...,d-1. This is a square Cauchy matrix M_(q,b)=1/(t^(q+b)-1). Put x_q=t^q and s_b=t^(-b), obtaining

    M_(q,b)=t^(-b)/(x_q-s_b).

The x_q are pairwise distinct, the s_b are pairwise distinct, and the two sets are disjoint, since t has infinite multiplicative order. The ordinary Cauchy determinant formula is nonzero over EVERY characteristic. Thus some q<d has nonzero output coefficient at z^(d+q), where d+q<=2d-1<2nm=D.

The exact q-Green identity says this coefficient belongs to the homogeneous word-length h operator f_h(J). Since J_i raises order, truncation preserves it. Thus f_h(U)!=0. The linearly independent powers S^h, 0<=h<=m, imply

    f(S tensor U)=sum_(h=0)^m S^h tensor f_h(U) !=0.

## 4. Prime-field descent and cost

Let Delta(t)=prod_(r=1)^(D-1)(t^r-1). It is a unit at t=0 and has degree binom(D,2). Every word matrix U_w is strictly lower triangular along increasing row indices. A contributing length-h path q=q_0<q_1<...<q_h=r has denominator product_j(t^(q_j)-1), which divides Delta without repeated factors as a FORMAL product. Its numerator is (1+t)^M with

    M=sum_j i_j(q_j-q_(j-1)-1) <= n[(r-q)-h] <= n(D-1).

Therefore Delta times any entry of every evaluated word, and hence every entry of f(S tensor U), is a polynomial in t of degree <E=1+binom(D,2)+n(D-1). Coefficients are in the arbitrary F. This includes h=0 because the identity clears with Delta itself. No bound on the word coefficients is used.

Reduce every U_i entry modulo t^E using its unique regular Taylor expansion. If a nonzero evaluated entry became zero modulo t^E, its nonzero cleared numerator of degree <E would become zero, impossible. Thus reduction preserves at least one nonzero entry, uniformly for arbitrary F.

Represent multiplication on F_p[t]/(t^E) in the basis 1,t,...,t^(E-1) by E x E matrices over F_p. This is injective, and after scalar extension to ANY F its coefficient coordinates remain F-linearly independent. Applying it to every entry yields ordinary matrices of dimension d=(m+1)DE. Evaluation commutes with this ring representation. The construction is polynomial in n,m,log p; it prints n dense d x d matrices, so output charge n d^2 field entries must be stated. No claim about useful oracle acquisition or response coefficient heights follows.

## Failure ledger / limits

- Omitting lambda is not justified by finite-word independence; infinite unmarked cyclic aliases can exist.
- The q-Green kernel MUST contain H(ty)^(-1), not H(y)^(-1).
- Ordinary derivatives are not used; characteristic-p Frobenius does not break the Cauchy determinant because t has infinite order.
- A scalar grid {1,...,m} is illegal in small characteristic when elements collide. The nilpotent marker avoids field-cardinality assumptions.
- The proof uses full matrix entries, including polynomial seed inputs y^q. First-column-only detection is not established by this compact argument.
- The result is conditional on correctness of the supplied finite word-series independence proof. It is a candidate mathematical composition, not a formal proof or established historical novelty.

## Sources and prior boundary

- Source manuscript: `work/agents/complexity_algebra/sources/pitp.txt`, Proposition 2.2 (word independence), equations (23)-(24) (truncated operator), Theorem 4.1 (older order bound, not needed for the compact kernel route). Source is from current OpenAI math release; parent owns its pinned source metadata.
- Characteristic-zero inspiration: `work/agents/complexity_algebra/sources/d-daae0ce9b7b6e2ee.txt`, root-cycle19 scalar-grid q-free Volterra kernel. The shift identity and q-Cauchy recovery above are independent positive-characteristic deductions.
- Prior polynomial capability is already present from source primitive plus length truncation; the improvement here is compact matrix dimension, with exact full-output and descent cost preserved.

Pinned primary prerequisite: https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Uniform-Matrix-Hitting-Points-in-Every-Positive-Characteristic-October-4-2026/uniform-matrix-hitting-points-positive-characteristic.pdf (Proposition 2.2; equation (23)).
Characteristic-zero inspiration record: https://raw.githubusercontent.com/harjassand/astra-research-knowledge/778b78af5d4bbde608ce3fc775049ceaeb55a2d3/web/pages/d-daae0ce9b7b6e2ee.html (Derivation section; internal source status).
