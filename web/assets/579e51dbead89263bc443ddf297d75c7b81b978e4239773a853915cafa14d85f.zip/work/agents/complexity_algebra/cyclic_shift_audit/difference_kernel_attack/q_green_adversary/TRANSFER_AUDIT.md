# Adversarial audit: q-Green detector and transfer refinement

Status: no counterexample or algebraic gap found in the original q-Green composition or the stronger transfer-kernel refinement below. This is an independent mathematical audit, conditional on the supplied finite-word independence prerequisite; it is not a formal or external correctness certificate and establishes no priority claim. No finite experiment is used to certify the universal conclusion.

## Exact strengthened claim

For every field F of characteristic p, n>=1, and m>=2, take D=2n(m-1), the supplied operators U_i truncated in z to dimension D, and a nilpotent shift S_m. Every nonzero m-state recognizable series f with coefficients uB_wv satisfies

    f(S_m tensor U_1,...,S_m tensor U_n) != 0.

This is a full matrix-output conclusion. The ordinary prime-field descent has dimension mDE, with E=1+binom(D,2)+n(D-1). For m=1, scalar zero inputs already suffice, because a nonzero one-state series necessarily has uv!=0.

## Decisive checks

Write K=F(t), with t transcendental over F; sigma acts only on z and fixes t and lambda. Set C(y)=lambda sum_i b_i(y)B_i and A=I+C. The uniquely defined H, with H(0)=I and sigma H=AH, has polynomial lambda coefficients at each z-degree. Both H and its formal inverse are defined over K[lambda][[z]].

Define

    L(z,y)=uH(z)H(y)^(-1)v.

The finite-word independence statement (supplied pitp.txt, Proposition 2.2) gives L(z,0)=uH(z)v!=0 whenever f!=0. This uses one finite homogeneous word-length coefficient, not an unmarked infinite-series injectivity assertion. If uv!=0, strict triangularity detects the constant coefficient immediately, so assume uv=0. Then L(y,y)=0 identically.

The Green kernel is exactly

    K_G(z,y)=uH(z)H(ty)^(-1)C(y)v=(1-sigma_y)L(z,y).

The matrix order in this equality is correct: H(ty)^(-1)=H(y)^(-1)A(y)^(-1), and A(y)^(-1)C(y)=I-A(y)^(-1). Thus H(ty)^(-1)C(y)=H(y)^(-1)-H(ty)^(-1). Replacing H(ty)^(-1) by H(y)^(-1) in the Green integral would be incorrect.

Put R_0=u and R_(j+1)=sigma(R_j)A. Then sigma^j(uH)=R_jH and

    L(t^j y,y)=R_j(y)v.

Over F(t,lambda)(z), let k<=m be the first dependent row index. The span of R_0,...,R_(k-1) is stable under the semilinear map R -> sigma(R)A: images are R_1,...,R_k, all in that span. Hence every later row belongs to it. If diagonals j=0,...,m-1 vanished, all diagonals would vanish. For each finite homogeneous total-degree component of L, diagonal substitution produces a polynomial in t^j, whose infinitely many distinct roots force that component to vanish. This contradicts L!=0. Since j=0 is uv=0, some 1<=j<=m-1 has a nonzero diagonal.

No relation coefficient is specialized at a numerical value or at lambda=constant. Replacing the formal variable z by the formal variable y is an injective field substitution; possible rational row-relation poles only yield valid Laurent-series identities.

The j-th nonzero diagonal has numerator

    u P(t^(j-1)y)...P(y) v,

where P(y)=Q(y)I+lambda L_0(y), deg_y P<=n, and Q(0)=1. Its denominator is the lambda-independent unit product Q(t^(j-1)y)...Q(y). Its numerator has lambda-degree<=j, y-degree<=nj, and zero constant lambda coefficient because uv=0. Thus some 1<=h<=j and 1<=d<=nj give a nonzero homogeneous total-degree component L_(h,d).

At each h,d, L_(h,d)(y,y)=0. A nonzero such component cannot consist only of its pure z^d term, because substitution z=y would then leave its nonzero coefficient. Therefore it contains a term z^a y^b with b>=1. Applying 1-sigma_y multiplies that coefficient by 1-t^b, which is nonzero in every characteristic. Consequently the same h,d component of K_G is nonzero.

For K_(h,d)=sum_(b=1)^d c_b z^(d-b)y^b, input y^q gives output coefficient at z^(d+q) equal to sum_b c_b/(t^(q+b)-1). The d by d matrix q=0,...,d-1 and b=1,...,d is Cauchy: entries are t^(-b)/(t^q-t^(-b)). The t^q and t^(-b) are pairwise distinct and disjoint in F(t), including characteristic two. Its determinant is nonzero. Hence some q<d detects the component at an index d+q<=2d-1<D.

The Green identity identifies this coefficient with f_h(J)y^q, so truncation yields f_h(U)!=0. Since h<=m-1, S_m^h survives, and the linearly independent powers S_m^0,...,S_m^(m-1) prevent cancellation in the tensor evaluation.

## Descent and cost

The independent micro-audit is in descent_attack/REPORT.md. Descent applies the supplied Lemma 5.1 to S_m tensor U_i and the finite word-length truncation through m-1. For Delta=prod_(r=1)^(D-1)(t^r-1), every path denominator selects distinct indexed factors of Delta. Characteristic-p repetitions as polynomials are harmless: no squarefreeness is claimed or needed. The numerator exponent is at most n(D-1), so every cleared entry has degree<E. Taylor reduction modulo t^E and the regular multiplication representation preserve nonvanishing after arbitrary coefficient-field extension.

The dimension is mDE=O(n^3m^4), and printing n dense matrices charges nd^2 field entries, or O(nd^2(1+log p)) bits in conventional prime-field encoding. This supplies no real-world oracle, response height bound, or numerical stability result.

## Exposition repairs only

1. Use 'distinct indexed factors of Delta' rather than 'without repeated factors'; polynomials t^r-1 can share or repeat irreducible factors in characteristic p.
2. State explicitly that Lemma 5.1 is applied to the nilpotent-marker matrices and the finite truncation, so no infinite formal series is silently fed to a polynomial-only lemma.
3. Keep the full-output requirement: the recovered seed input y^q may require an arbitrary input column. First-column-only detection has not been proved by this route.

Sources inspected: work/agents/complexity_algebra/sources/pitp.txt, Lemma 2.1, Proposition 2.2, equation (23), and Lemma 5.1; work/agents/complexity_algebra/sources/d-daae0ce9b7b6e2ee.txt for the earlier characteristic-zero composition boundary; and the parent candidate Q_GREEN_COMPACT_DETECTOR.md.
