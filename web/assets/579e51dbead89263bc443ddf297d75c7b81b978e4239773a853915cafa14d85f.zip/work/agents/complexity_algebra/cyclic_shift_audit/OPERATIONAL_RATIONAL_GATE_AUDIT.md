# Any-field operational rational-formula gate

2026-10-07. Direct source audit, no gap found at the stated interface. This is an audit of the algebraic reduction; the full strong hitting-list conclusion additionally depends on the parent's q-Newton expander, p-coprime division lift, and ordinary semisimple descent.

Primary source: Pavel Hrubes and Avi Wigderson, *Non-commutative arithmetic circuits with division*, Theory of Computing 11(14), 2015.
https://theoryofcomputing.org/articles/v011a014/v011a014.pdf
Local text: `../sources/hw2015.txt`.

## Exact imported statements

* Section 2, Theorem 2.1, pp. 361-362 (local lines 220 onward): correctness in the free skew field is equivalent to a nonempty matrix evaluation domain; for correct circuits, free-field equality is equivalent to equality on every common matrix domain. The coefficient field is an arbitrary field F in this section, with no characteristic-zero assumption.
* Section 7, Proposition 7.3, p. 378 (local lines 1013 onward): an affine matrix over F<x> is invertible over the free skew field exactly when some matrix substitution is invertible. Its forward proof explicitly works with an algebraic-closure witness, which is sufficient for the extension-field feasibility interface. No useful witness is algorithmically acquired at this step.
* Section 2, Theorem 2.2: fullness equivalence, used by Proposition 7.3 for the converse. This need not be reproved if Proposition 7.3 is cited at its exact scope.

## Reduction from the actual expression

Fix a rational formula Phi of tree size at most s over F. Operational admissibility means some matrix tuple gives a defined evaluation of every inverse occurrence in the actual tree. Operational nonzero means some such defined tuple has nonzero final output.

By Theorem 2.1, admissibility implies the original formula is correct over the free skew field. Comparing Phi with the zero expression under Theorem 2.1 shows that a nonzero defined matrix output implies Phi is a nonzero free-field element. Thus adding an inverse to the root gives a correct expression. This step needs no primitive root associated with the operational witness dimension, and consequently avoids the case where that dimension is divisible by p.

The affine-pencil recursions in release116 rational companion, Section 4, Lemma 4.1, work over every field: they use only constants 0,1,-1, ordered block multiplication, and block inverse identities. Characteristic two is included. For each subtree h,

    h = u_h L_h^-1 v_h,
    order(L_h)=|h|+1.

All correct subtree pencils are invertible over the free skew field by induction. Retain the pencil for EVERY inverse-node occurrence, including branches multiplied by zero or later canceled. Add the root augmentation

    J_Phi = [ L_Phi   v_Phi ; u_Phi  0 ].

Its Schur complement is -Phi, so it is invertible over the free skew field because Phi is nonzero. Each retained inverse-node pencil and J_Phi is therefore feasible over an extension of F by HW Proposition 7.3.

The family has at most s+1 members. Inverse-node pencil orders are at most s+1; the root augmentation order is at most s+2. Taking B=2s+1 bounds both the orders and the number for all s>=1, including s=1.

At a simultaneous strong hit, the inverse-node conditions enforce the actual tree's domain by induction from its leaves. With the root augmentation invertible, the same Schur-complement identity makes the defined root value invertible. This retains expression domains, not merely equivalence classes of rational functions. The resulting output is stronger than nonzero value.

If operational input permits an initial witness over an extension E/F, apply the free-field argument over E. The resulting affine pencil coefficients still lie in F, and a universal prime-field list that works for every coefficient field applies over E. For the resulting prime-field tuple, all determinant conditions are already in F; invertibility after extension is equivalent to invertibility over F. Thus the same domain and invertible-output conclusion descends to F.

## Scope and non-claims

This argument validates the parent’s route from a simultaneous all-field feasible-affine-pencil hitting list to actual rational-expression hitting. It does not validate the list constructor by itself. In particular the division lift must use an M coprime to p, and every per-root determinant polynomial must be shown nonzero with its true degree bound before the semisimple descent union bound is invoked.

Source checks do not execute the unknown formula oracle or certify full generator feasibility at practical sizes. Dense output, list length, coefficient bits, and oracle evaluation costs must still be charged.
