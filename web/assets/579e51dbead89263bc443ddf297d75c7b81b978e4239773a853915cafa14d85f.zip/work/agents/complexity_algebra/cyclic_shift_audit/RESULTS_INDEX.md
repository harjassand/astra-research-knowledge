# Cyclic q-shift audit handoff

2026-10-07. Internal derivations and independently reconstructed hostile checks; external correctness and priority remain unverified.

## Compact proper-series result

Candidate universal integral tuple:

    N=max(1,2n(m-1)), E=1+binom(N,2)+n(N-1), d=mNE=O(n^3m^4).

It detects every nonzero proper recognizable m-state series over every field, using one exact full matrix output and a legal jointly nilpotent tuple. Lambda marker S_m is retained explicitly. Core proof is `COMPACT_Q_KERNEL_PROOF.md`; independently reconstructed transfer proof is `difference_kernel_attack/TRANSFER_KERNEL_REFINEMENT.md`; hostile audit is `difference_kernel_attack/q_green_adversary/TRANSFER_AUDIT.md`.

Finite polynomial/acyclic corollary drops the lambda marker and has dimension NE=O(n^3m^3); size-s division-free formula bound is O(n^3s^3). The integral tuple has entries with O(n^2m+log(nm)) bits and can be reduced modulo any prime. This improves the release116 first-column construction's charged matrix dimension; it is not the first polynomial proper-cyclic capability, which follows from generic unrolling.

Exact transfer diagnostics: `difference_kernel_attack/check_transfer_kernel.py`, `difference_kernel_attack/TRANSFER_KERNEL_EXACT_CHECKS.json`: 80 m=2/3 dense cyclic fixtures over GF(101) and GF(2^8), 20,760 coefficient/Green/transfer/shifted-diagonal identities; refined marker detection matches independently computed all-word zero certificates (79 nonzero, 1 zero). Earlier q-Green diagnostics add 3,920 exact identities. These are finite checks, not proof certification.

## Parent affine-pencil extension audits

Folded q-Newton expander: no defect found in the order bound, eta-integral reduction, reversal, or near-full-rank affine-pencil step. Independent notes:

* `difference_kernel_attack/q_green_adversary/FOLDED_NEWTON_AUDIT.md`
* `difference_kernel_attack/FOLDED_NEWTON_SECOND_AUDIT.md`

Ordinary semisimple descent: no defect found conditional on per-primitive-root lifted determinant polynomial nonvanishing and its degree bound. Independent notes:

* `difference_kernel_attack/q_green_adversary/ORDINARY_STRONG_DESCENT_AUDIT.md`
* `difference_kernel_attack/STRONG_FINITE_FIELD_DESCENT_AUDIT.md`

Small exact component diagnostic: `check_semisimple_descent.py`, `SEMISIMPLE_DESCENT_EXACT_CHECKS.json`. A=F_Q[omega]/Phi_3, Q=4/16, ordinary prime-field regular dimensions 4/8, branches 4/8. 8,360 exact rank-versus-all-branch comparisons with no mismatches. Arbitrary extension coefficient c=2 is held fixed; wrongly Frobenius-twisting it changes the predicted predicate on 13 cases for Q=4 and 1,446 for Q=16, showing this diagnostic catches that error. Simultaneous good full-grid points: c=2 gives 24/256 and 17,280/65,536. This runs only the component algebra, not the huge promised-parameter generator.

Operational arbitrary rational-formula gate: direct primary-source audit passes, conditional on the parent's strong list. `OPERATIONAL_RATIONAL_GATE_AUDIT.md` records HW2015 Theorem 2.1, Proposition 7.3, actual-tree domain conditions, B=2s+1 safe order/count bounds, and why no primitive root tied to an unknown witness size is required.

Characteristic-independent universal integer strong list: `UNIVERSAL_INTEGRAL_LIST_AUDIT.md` independently checks the parent's final adjugate-and-small-prime construction. No gap found. Audited degree parameters E0=3M^2(w+M+1), T0=B d(dE0+1), K=max(M,BT0+2) are safe. The shared scalar lambda=1/det(U0) normalizes all cyclotomic branches, and the eventual grid does not need U0 as an extra constraint. One integer list generated from n,B alone works over every coefficient field, retaining original rational expression domains. This is a polynomial-size list with impractical parameters; no common dimension, single strong hitting point, full generator execution, or novelty claim is asserted.

## Load-bearing premises and costs

* Compact tuple uses release116 finite-word independence over every field, not infinite ungraded series faithfulness.
* Lambda marker, t-adic descent, arbitrary coefficient-field base extension, and full output are all charged.
* The larger all-rational-formula result still needs the parent's per-root p-coprime division-lift nonvanishing and true four-parameter determinant-degree accounting.
* No actual useful oracle was acquired, no practical full-list construction was executed, and response coefficient bit heights are not controlled by size alone.
* Novelty and comparison with existing black-box rational-formula hitting papers require separate review; no historical-calibre label is attached to these internal audit outcomes.
