# Compact all-characteristic cyclic detector via a q-Green kernel

Date: 2026-10-07. Status: mathematical derivation, independently reconstructed by the nested `difference_kernel_attack` agent. Finite diagnostics are separate evidence. External correctness and priority are not certified.

## Exact interface and conclusion

Let p be prime, F any field of characteristic p, and n,m >= 1. A proper recognizable series is given only through an exact full-matrix evaluation oracle; a hidden realization satisfies

    f_w = u B_w v,   u in F^(1xm), B_i in Mat_m(F), v in F^(mx1).

The oracle evaluates the entire matrix value of f at jointly nilpotent matrix tuples; evaluation is defined by the finite series sum. No hidden coefficients or state matrices are read by the generator.

Set

    N = max(1, 2 n (m-1)),
    E = 1 + binom(N,2) + n(N-1),
    d = m N E.

There is one explicit tuple T_i in Mat_d(F_p), depending only on p,n,m, such that every nonzero such series satisfies f(T_1,...,T_n) != 0. The tuple is jointly nilpotent, so every evaluation is defined. It can be generated in deterministic bit time polynomial in n+m+log p, with dense output length O(n d^2 (log p+1)). Its dimension is O(n^3 m^4).

The construction is S_m tensor U_i, followed by coefficient-ring descent in t. Here S_m is the standard nilpotent shift and U_i is the release116 q-Volterra tuple on z-coefficients through degree N-1:

    (U_i)_(r,q) = (1+t)^[i(r-q-1)] / (t^r-1),  0 <= q < r < N,
                  0 otherwise.

The transpose convention for S is immaterial as long as its powers 0 through m-1 are linearly independent. For m=1, N=E=d=1 and the tuple consists of zeros: a nonzero scalar-state series necessarily has uv!=0. The proof below therefore treats m>=2. Full matrix output is essential in the proof: the successful seed need not be the constant series 1.

In fact the construction can be output once over the integers, without p as an input. All truncated Taylor coefficients of U_i are integers because

    (t^r-1)^-1 = -sum_(j>=0) t^(rj),

and the numerator (1+t)^[i(r-q-1)] has integer coefficients. Truncating at E and writing multiplication blocks over Z gives one tuple T_(n,m) in Mat_d(Z). Its image over EVERY field, including every positive characteristic and characteristic zero, has the guarantee above. Each integer entry has absolute value at most E 2^[n(N-1)], hence O(nN+log E)=O(n^2m+log(nm)) bits. Reduction modulo p recovers exactly the prime-field construction. This is a uniform integral-tuple consequence, not a necessity claim about characteristic-zero dimensions.

## Source ingredients and new step

Primary release116 source: `Uniform Matrix Hitting Points in Every Positive Characteristic`, OpenAI, October 4, 2026, at

https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Uniform-Matrix-Hitting-Points-in-Every-Positive-Characteristic-October-4-2026/uniform-matrix-hitting-points-positive-characteristic.pdf

Local exact text: `../sources/pitp.txt`. Used ingredients: Section 2 Proposition 2.2 (finite word-series independence over F(t)(z)); equations (2)-(5) (q-Volterra operators); Section 5.1 equation (23) (truncated matrices); Section 5.2 equation (26) and Lemma 5.1 (prime-field coefficient-ring descent). The source's Theorem 4.1 gives the weaker first-column truncation N=1+n binom(m,2) when cyclic H is graded in lambda. We avoid that weaker order bound here by reconstructing a bivariate q-Green kernel, controlling shifted diagonals, and using Cauchy moments from all seeds.

Characteristic-zero precedent: source d-daae0ce9b7b6e2ee, `CYCLIC_SCALAR_GRID_HITTING.md`, uses a differential Green kernel and diagonal derivatives. Its scalar grid does not directly transfer to small characteristic. The present proof uses shifted diagonals, a multiplicative Cauchy matrix, and an explicit nilpotent marker instead.

## 1. Formal graded system without an ungraded faithfulness claim

Write L=F(t,lambda), sigma(g)(z)=g(tz), a_i=(1+t)^i, b_i(z)=z/(1-a_i z), C(z)=lambda sum_i b_i(z) B_i and A(z)=I+C(z). Define J_i by

    (sigma-1) J_i a = b_i a,   (J_i a)(0)=0.

J_i raises z-order by at least one. Thus the sums below are locally finite and well defined even when the B_i are cyclic:

    H(z)=sum_w lambda^|w| B_w h_w(z),   h_w=J_w 1.

Then H(0)=I and sigma H=A H. Both H and H^-1 have coefficients in F(t)[lambda] at every fixed z-degree, because all nonconstant word terms raise z-order.

If uv=0 and f != 0, then f(lambda J)1 != 0. Indeed choose any nonzero finite homogeneous word-length part f_h; the coefficient of lambda^h is f_h(J)1, nonzero by release116 Proposition 2.2. This invokes only finite word independence. It does not assert that an arbitrary infinite ungraded series f(J) is faithful.

The case uv != 0 is immediate: every joint-nilpotent evaluation has diagonal constant uv, since U and the final tuple are strictly triangular in the z index.

## 2. Exact q-Green kernel

For any input series a(z), let

    X(z)=sum_w lambda^|w| B_w v J_w a(z).

Then X=v a+lambda sum_i B_i J_i X. With Z=X-v a, applying sigma-1 gives

    sigma Z=A Z+C v a,   Z(0)=0.

Substitute Z=H W. Since sigma H=A H and H(tz)=A(z)H(z),

    (sigma-1)W = H(tz)^-1 C(z)v a(z),   W(0)=0.

Consequently

    f(lambda J)a - uv a
      = uH(z) (sigma-1)^-1[H(tz)^-1 C(z)v a(z)].

Introduce the scalar bivariate kernel

    K(z,s)=uH(z) H(ts)^-1 C(s)v.

It has no s^0 coefficient. If K(z,s)=sum_(r,k>=0) K_(r,k) z^r s^k, then the operator is

    f(lambda J)a - uv a
      = sum_(r>=0,k>=1,q>=0) K_(r,k) a_q z^(r+k+q)/(t^(k+q)-1).

Every coefficient sum is finite. The previous nonzero action on 1 proves K != 0 when uv=0 and f != 0.

## 3. Transfer-kernel refinement and bounded shifted diagonal

Introduce the transfer kernel

    L(z,s)=uH(z)H(s)^-1 v.

Its ordinary diagonal is L(s,s)=uv=0. Its specialization at s=0 is uH(z)v=f(lambda J)1, so it is nonzero. Also

    K(z,s)=L(z,s)-L(z,ts)=(1-sigma_s)L(z,s),

because H(s)^-1=H(ts)^-1 A(s). This identity will recover a nonzero Green-kernel term from a bounded transfer-kernel term.

Let sigma act on rational rows in s and define

    R_0(s)=u,
    R_(j+1)(s)=sigma(R_j)(s) A(s).

Equivalently R_j(s)=u A(t^(j-1)s)...A(s). For all j>=0,

    L(t^j s,s)=R_j(s)v.                            (D_j)

The rational row span of R_0,R_1,... stabilizes within m rows. More explicitly, let k<=m be the first index with R_k in span_(L(s)){R_0,...,R_(k-1)}. Applying sigma and right multiplying by A shows that every subsequent R_j lies in this same span. No division specialization is performed: this argument stays over L(s).

If D_j were zero for every j<m, all D_j would therefore be zero. This would force L=0: at any fixed total degree d, the coefficient of s^d in L(t^j s,s) is

    sum_(r=0)^d L_(r,d-r) t^[jr].

The Vandermonde matrix for j=0,...,d has nodes 1,t,...,t^d, distinct in every characteristic. Thus all homogeneous coefficients would vanish. Since L != 0, some D_j, j<m, is nonzero. D_0=uv=0, so 1<=j<=m-1.

Let Q(s)=product_i(1-a_i s), so A=P/Q with degree_s P<=n, degree_lambda P<=1, and Q independent of lambda. Therefore

    D_j(s)=W_j(lambda,s) / product_(e=0)^(j-1) Q(t^e s),

where W_j is polynomial, divisible by lambda, and

    degree_s W_j <= nj <= n(m-1),
    degree_lambda W_j <= j <= m-1.

The numerator is divisible by lambda: at lambda=0, A=I, R_j=u, and D_j=uv=0. Choose a nonzero lambda^h coefficient of W_j, with 1<=h<=m-1. Its s-order is at most n(m-1), and the denominator is a unit at s=0 and independent of lambda. Thus the coefficient L_h(z,s) of lambda^h in L has a nonzero homogeneous part at some total degree d<=n(m-1). Each homogeneous total-degree part of L_h vanishes on z=s because L(s,s)=uv. Consequently a nonzero homogeneous part must contain a term of positive s-degree; a sole pure z^d term would not vanish on that diagonal. Applying 1-sigma_s multiplies each z^r s^k coefficient by 1-t^k. Positive k gives a nonzero factor, so that nonzero homogeneous part survives in K_h. Its least nonzero total degree d is therefore at most n(m-1) and at least one.

## 4. Full-output Cauchy moments

Write the least nonzero homogeneous part of K_h as

    sum_(k=1)^d c_k z^(d-k)s^k,

with at least one c_k != 0. For input a(z)=z^q, the coefficient of lambda^h z^(d+q) in f(lambda J)a is exactly

    sum_(k=1)^d c_k/(t^(k+q)-1).

There is no contamination from a different total kernel degree. The d by d matrix with rows q=0,...,d-1 and columns k=1,...,d,

    M_(q,k)=1/(t^(k+q)-1),

is invertible over F(t) in every characteristic. To see this use x_k=t^k and y_q=t^-q: M_(q,k)=y_q/(x_k-y_q), a Cauchy matrix times nonzero row scalars. Both node sets are internally distinct and their sets are disjoint because k>=1 and q>=0. Hence some seed q<d yields a nonzero coefficient at z-degree d+q<=2d-1<=2n(m-1)-1.

The corresponding entry of the full truncated matrix f_h(U) is nonzero. We have proved existence of some 1<=h<=m-1 such that f_h(U) != 0 for N=2n(m-1).

## 5. Lambda marker and prime-field descent

Since all U_i strictly raise z index, evaluation of the infinite series at S_m tensor U is finite, with

    f(S_m tensor U)=sum_(h=0)^(m-1) S_m^h tensor f_h(U).

Its coefficient at the successful h cannot cancel with another h because the powers S^0,...,S^(m-1) are linearly independent. Thus this matrix is nonzero over F(t).

For the same N, release116 Section 5.2 supplies

    D(t)=product_(r=1)^(N-1)(t^r-1),
    degree_t[D(t) f_h(U)_(a,b)] <= binom(N,2)+n(N-1)=E-1.

The bound is valid for every finite word and every F-linear combination, regardless of its formula representation. It follows by a strict z-index chain: each denominator t^r-1 appears at most once; the numerator exponent is at most n(N-1). The same bound applies to entries of f(S tensor U). D(0)!=0, so reducing entries modulo t^E preserves nonzero evaluation. Replacing a truncated coefficient by its multiplication matrix on F_p[t]/t^E is a unital injective map after every base extension F/F_p, exactly as in Lemma 5.1. This produces T_i of dimension mNE over F_p.

Final nilpotence remains explicit: the lambda marker raises its index, so every word of length m vanishes even after descent. Each variable is therefore a legal proper-series oracle query.

## Cost ledger and honest comparison

* One universal query tuple, all coefficients in F_p, valid over every extension field F of characteristic p.
* d=mNE=O(n^3m^4), exact dense inputs n d^2 residues, and one exact full output d^2 field elements. Any structural output compression requires its own justified interface.
* Constructor bit time and output bit length are polynomial in n+m+log p. Residue operations involve O(log p) bits. Unknown oracle output coefficient heights, representation, and arithmetic cost are not bounded by n,m alone.
* Over F(t), before prime-field descent, dimension mN=O(nm^2).
* For a finite polynomial with an m-state coefficient realization, set lambda=1 and omit S entirely. Release116 finite-word independence makes f(J)1 != 0, so L != 0 directly; all shifted-diagonal and Cauchy steps remain valid. The resulting universal integral detector has dimension NE=O(n^3m^3). In particular an acyclic m-vertex path program has this bound, improving the released O(n^3m^6) dimension, and a size-s division-free formula has m<=2s, N=2n(2s-1), and dimension O(n^3s^3) instead of O(n^3s^6). This corollary uses full matrix output and claims nonzero value, not first-column detection or invertibility.
* The simple graded first-column use of Theorem 4.1 gives N0=1+n binom(m,2), marker N0, and dimension N0^2 E0=O(n^4m^8). This proof saves four powers of m and one power of n in that charged dimension.
* A generic shortest-word truncation plus acyclic release116 detector gives O(n^3m^13) at the crude m^2-state unrolling bound and an m length marker. Therefore polynomial proper-cyclic detection is already a routine consequence of release116. The increment here is compactness and a full-output all-characteristic kernel composition, not the first polynomial capability.
* The theorem does not cover arbitrary rational expressions undefined at zero, and it does not acquire an exact full-output oracle from passive data or noisy measurements.

## Residual-learning consequence under the same oracle

The detector makes the feature map Phi(g)=vec(g(T)) injective on the left-residual space of one hidden realization: every F-linear combination of residuals has the SAME hidden B_i and state bound m. This avoids paying bound 2m for an unrelated hypothesis during the residual-span search.

An ordinary greedy prefix-basis learner needs at most 1+nr residual evaluations, where r<=m is the actual minimal state rank. A selected prefix has length at most r-1 and a candidate extension length at most r. A legal residual query embeds a width-d chain spelling that prefix ahead of the T tail, so its dimension is at most d(r+1); a selected output block is exactly f_p(T). Linear dependence of these blocks equals dependence of residual series by the detector. Constants f_p(epsilon) occur on the diagonals of f_p(T), and therefore provide the final output column after transition coefficients are learned.

Thus one exact full-output oracle supplies an exact minimal realization with polynomial matrix dimensions, query count, response-field-element count, and exact linear-algebra operation count. A crude dense response bound is (1+nr)d^2(r+1)^2 field elements. Output coefficient bit heights and the physical cost of the oracle remain unbounded by m,n alone. A width-b prefix chain plus a b-by-d seed selector can trade smaller query matrices against ceil(d/b) residual queries, as in the characteristic-zero source; no numerical stability or positivity claim follows.

## Failure ledger and next attack

1. Do not remove lambda merely because finite h_w are independent: the argument explicitly uses finite homogeneous parts and keeps a nilpotent marker.
2. Do not reuse the characteristic-zero integer scalar grid when p<=m; its nodes coincide. The current construction avoids this specialization.
3. Do not apply ordinary derivatives/Cauchy moment denominators in characteristic p; the proof uses q-shifts and 1/(t^r-1).
4. A fixed scalar t specialization in a small extension is not automatically universal for arbitrary extension-field coefficients. The coefficient-ring descent gives the required base-extension injection.
5. The largest remaining compactness expense is t descent E=Theta(N^2+nN). The proof presently gives no smaller universal t-adic precision for the recognizable-series subclass.
6. Bounded search primary prior comparators: Arvind-Chatterjee-Mukhopadhyay 2022 and 2023/2026 rational-formula hitting papers; Schutzenberger finite truncation. No priority claim is made for the q-Green-kernel combination pending deeper literature audit.

Primary prior-source handles:
https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.APPROX/RANDOM.2022.23
https://arxiv.org/abs/2309.15647
https://epubs.siam.org/doi/10.1137/24M1689508
