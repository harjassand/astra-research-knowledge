# Exact integer algorithms from the arithmetic nine-fourths premise

Status: conditional consequence of release107's rank-exponent conclusion, with a constructive but unbounded-in-epsilon preprocessing algorithm. This does **not** supply a usable finite rank decomposition or solve selective outputs.

Primary source: OpenAI, *An Upper Bound of 9/4 for the Matrix Multiplication Exponent*, October 2, 2026, Theorem 1.1, the final proof in Section 5, and Remark 5.2. URL https://raw.githubusercontent.com/openai/math/main/preprints/Matrix-Multiplication-Nine-Fourths-October-2-2026/paper.pdf . The source itself notes that the exact rank equations have rational coefficients and a complex solution therefore admits algebraic coefficients in one number field. The proof is not claimed audited in full here.

## Precise consequence

Assuming that inf_{q>=2} log_q R(T_q) <=9/4 over C, for every fixed positive rational epsilon there is a uniform deterministic exact algorithm multiplying arbitrary N-by-N integer matrices with entries of bit length at most b, in

    C_epsilon + O_epsilon(N^(9/4+epsilon) (b+log(N+2))^2)

bit operations. The elementary square factor uses schoolbook arithmetic; it can be replaced by an appropriate exact-integer multiplication cost with routine fixed-degree number-field arithmetic overhead. Constants, number-field degree, and initial discovery time may be enormous. No claimed quantitative bound on C_epsilon is obtained from the exponent alone.

## Effective acquisition of a fixed decomposition

Choose a rational delta in (0,epsilon). Enumerate q>=2, lengths r satisfying r^den(delta+9/4)<q^num(delta+9/4), number fields described by irreducible integer polynomials with specified complex roots, and finite coefficient arrays in these fields. For every candidate, check the exact bilinear identity

    T_q = sum_{h=1}^r alpha_h tensor beta_h tensor gamma_h

coefficientwise using exact algebraic-number arithmetic. Dovetail the finite enumerations. Every algebraic coefficient tuple lies in some finite number field and is eventually enumerated. The arithmetic exponent premise guarantees at least one q,r and a complex decomposition of the desired size. Polynomial equations with rational coefficients that have a complex solution have an algebraic solution (Nullstellensatz), so the search terminates.

This is a concrete algorithm for discovering a decomposition, although its halting time C_epsilon is not controlled by the claimed exponent. The preprocessing depends only on the fixed requested epsilon, not N, b, or matrix entries. If a finite decomposition is actually supplied, acquisition reduces to verification rather than search.

## Exact recursive costs

Fix the resulting q,r and its number field K. Pad N to the next power of q, costing a constant factor. Apply the bilinear identities recursively to matrix blocks. They remain valid because coefficient scalars are central and every bilinear product multiplies its left-input block before its right-input block. Flattening gives r>=q^2; the usual recursion uses O(N^log_q(r)) operations if r>q^2, and O(N^2 log N) if r=q^2.

Represent K in a fixed rational basis. Clear the finitely many fixed coefficient denominators by one integer denominator. At recursion level ell, encoded input entries are fixed linear combinations of original entries with coefficient denominators and numerator magnitudes bounded exponentially in ell. Since ell=O(log N), their rational coordinate numerators and denominators have O_epsilon(b+log N) bits. Leaf products and the output reconstruction satisfy the same bound (with factor two on b), because each multiplication has degree at most two in the original entries. Fixed number-field dimension contributes only an epsilon-dependent constant. Schoolbook multiplication and division therefore charge O_epsilon((b+log N)^2) bits per field operation. This proves the bound.

## Interpretation and limitations

It is too strong to interpret 'the release does not print a finite decomposition or bit algorithm' as 'no uniform bit algorithm follows at all'. A uniform but impractical exact-bit consequence does follow by algebraic search and recursion. The justified distinction is between an existence-based uniform algorithm with uncontrolled constants, a supplied/reviewable finite circuit, and a practical implementation.

The result does not transfer the **dimension-dependent** selective mask to a fixed finite family: its N-dependent output incidence and encoding must still be processed within the claimed target time. It cannot be used to hide the selective-circuit acquisition gap. It also gives no numerical stability guarantee for floating point evaluation.

## Prior-art boundary

This is a standard constructive consequence of algebraic rank identities, not claimed as a new historical advance. It corrects the interpretation of the premise and specifies exactly what remains unavailable.
