# One universal integer strong hitting list, with no characteristic input

Status: direct corollary of the internally audited all-characteristic strong-pencil construction. Its adjugate-and-small-prime composition passed an independent algebra, quantifier, degree, bit-cost, and expression-domain audit at cyclic_shift_audit/UNIVERSAL_INTEGRAL_LIST_AUDIT.md. No external correctness or priority clearance is claimed. This is a list, not a single hitting point.

## Exact statement

Given only n,B in unary, one deterministic machine prints a polynomial-size list of n-tuples of integer square matrices in polynomial bit time. Matrix dimensions and integer entry lengths are polynomially bounded. After applying the prime-subfield map to the integers, this SAME list works over every coefficient field F, in characteristic zero or any positive characteristic:

Every family of at most B feasible affine pencils of orders at most B has a common invertible hit in the list. Feasibility means invertibility at some matrix evaluation over an extension of F. The list generator receives no coefficients, witnesses, expression, or characteristic.

The same standard domain certificate therefore gives a defined, invertible hit for every nonzero admissible size-s noncommutative rational formula over every field, by taking B=2s+1. The original expression's inverse occurrences are preserved.

## Large-characteristic and characteristic-zero branch

For n,B>=1 put w=n+1 and Delta=4w^3B. Fix M to be the smallest power of two strictly greater than B Delta; N=M-Delta. Unlike the prime-specific construction this M is independent of characteristic. The q-Newton reversal matrices R_i(q,eta) have integer polynomial entries. Set rho=phi(M)=M/2 and

    C=Z[omega]/(omega^rho+1),
    d=M rho.

Take the Fourier lift of the strong-pencil proof and clear its ONLY scalar denominator:

    A_i=M R_i^*
       =sum_(a,b<M) sum_(j<M) omega^(-aj) (R_i)_(j,j-b)
                         u^a v^b D^a S^b.

Negative powers of omega are reduced using omega^rho=-1, so every A_i is an M-by-M matrix over C[q,eta,u,v]. Replace scalars of C by their ordinary integer multiplication matrices. Denote the resulting d-by-d integer polynomial matrices by U_i.

Use the degree bound

    E0=3M^2(w+M+1)

for the total parameter degree of every U_i entry. The detailed division audit bounds the original entry degree by 2M^2(w+M)+3(M-1), strictly below E0. Cyclotomic reduction and regular representation do not increase parameter degree.

Define integer polynomial matrices

    Z_i=adj(U_0) U_i.

Each entry has degree at most d E0. No inversion, denominator, or invertibility-dependent discard occurs in this branch. Introduce one further scalar parameter lambda. For an order-r<=B affine pencil L, its ordinary evaluation at lambda Z has order rd, and

    Q_L(q,eta,u,v,lambda)=det L(lambda Z)

is a polynomial of total degree at most

    T0=B d(d E0+1).

We now prove it is nonzero over every field F of characteristic zero or odd positive characteristic. Tensor C with an algebraic closure of F; it splits into rho branches, one for each primitive Mth root. Every branch of each symbol-lifted feasible pencil is invertible by the strong-pencil proof, and U_0 has nonzero determinant. Over the parameter function field, setting

    lambda=1/det U_0

gives lambda Z_i=U_0^(-1)U_i. The normalized evaluation of L is invertible on every branch. Therefore Q_L cannot be the zero polynomial. This argument holds for arbitrary F coefficients; none need be rational or in a finite subfield.

Set

    K=max(M,B T0+2).

Print the tuple (lambda Z_1,...,lambda Z_n) at every point of the integer grid {0,...,K}^5. In characteristic zero and every characteristic p>K, these grid elements are distinct. For each of at most B pencil constraints, at most T0(K+1)^4 points are bad. Since B T0<K+1, their union is smaller than the full grid. Thus one tuple simultaneously hits the entire family.

There is no need to separately force U_0 invertible at the chosen grid point. Its generic inverse proves Q_L is nonzero; the evaluated Q_L itself is the constraint used in the grid argument.

## Patch every remaining characteristic

Enumerate all primes p<=K, by any elementary deterministic polynomial-in-K primality method. For each such p run the prime-specific machine proved in ALL_CHARACTERISTIC_STRONG_PENCIL_HITTING.md. View its prime-field entry representatives in {0,...,p-1} as integers and append those tuples.

For a coefficient field of characteristic p<=K, the appended p-specific list supplies the simultaneous hit, and integer reduction reproduces its entries exactly. For characteristic zero or p>K, the adjugate grid branch supplies the hit. Other appended branches may be useless in a given characteristic; the list property requires only one successful tuple.

Because K is an explicit polynomial in n,B, this enumerates polynomially many primes, each at a polynomial logarithmic input length. Every appended list has polynomial dimension, length, and complete bit generation cost. Their sum remains polynomial in n,B.

## Integer-bit construction costs

The Newton coordinate matrices are monic unit triangular. Their inverses are finite triangular sums with integer polynomial entries; no division by a coefficient or characteristic is hidden. Each Newton factor has at most w+1 coefficients of bit length O(w), and at most M factors occur. Polynomial-degree bounds and these explicit finite triangular products give polynomial coefficient bit lengths.

Integer evaluation of q,eta,u,v on the grid increases entry lengths by at most E0 log(K+1), plus polynomial coefficient length and logarithmic summation overhead. Computing every adjugate by exact integer determinant algorithms charges all minors. A cofactor of a d-by-d integer matrix has bit length at most O(d times input-entry length+d log(d+1)), so integer arithmetic and complete dense output remain polynomial. Singular matrices cause no difficulty: adjugates exist and exact determinant algorithms handle zero minors.

The grid has (K+1)^5 points, and the dense large-characteristic branch prints n d^2 integers per point. Its exponents and conservative constants make it impractical even for tiny parameter values. It is an asymptotic construction, not a usable implementation claim. The full promised-size generator has not been executed.

For B=0, any dimension-one tuple serves the empty family. For n=0, print the empty tuple in dimension one; feasible constant pencils are already invertible.

## Scope and dependencies

- Folded Newton reversal, symbol division, degree bounds, simultaneous semisimple descent, and rational expression domains are separately audited in the companion notes.
- The characteristic-independent escalation needs only the large-characteristic symbol proof and the already charged prime-specific lists; it does not assume deterministic finite-field factoring.
- This establishes no scalar commutative PIT, general arithmetic-circuit PIT, or small practical runtime.
- Formula evaluation or an exact matrix-output service remains a separate interface. The generator never acquires coefficients or a physical oracle.
- Historical priority remains unknown; characteristic patching and adjugate normalization are elementary reductions, not independently novel mechanisms.
