# An exact extremal profile for the released nine-fourths argument

Status: direct analytic deduction; conditional relevance to release107, not a tensor-character construction or a lower bound for matrix multiplication. This shows that the **numerical profile axioms used in that proof cannot alone yield a better exponent**. It identifies a concrete missing new inequality.

Primary source: OpenAI, *An Upper Bound of 9/4 for the Matrix Multiplication Exponent*, October 2, 2026, Sections 4–5 (Lemmas 4.1, 4.2, 5.1), https://raw.githubusercontent.com/openai/math/main/preprints/Matrix-Multiplication-Nine-Fourths-October-2-2026/paper.pdf . Local full text: `sources/mm9_4.txt`. Release commit supplied by protocol: adc7f1241b42e322a6451854ab7e4b4c146bf78a.

The proof constrains a positive symmetric P(a,b) by P(1,b)=b, separate discrete concavity, shifted tripling P(a,3h+a-1) >= 3P(a,h), and the rank upper bound P(a,b) <= (a+b-1)^(1/t). It obtains t <= 3/4. A natural higher-ceiling attack is to optimize all these inequalities jointly, instead of only using tripling at h=a. The following explicit profile defeats that attack.

Let

    H_1=1,
    H_a=product_{j=1}^{a-1} (3j+1)/(3j),
    P_*(a,b)=H_min(a,b) [max(a,b)+(min(a,b)-1)/2].

This profile satisfies every displayed axiom with t=3/4 and has P_*(a,a)=Theta(a^(4/3)).

## Proof of all axioms

Positivity, symmetry, and P_*(1,b)=b are immediate.

Fix a. When b<a,

    Delta_b=P_*(a,b+1)-P_*(a,b)=H_b (a+2b)/(3b).

For 2<=b<a, the recurrence for H gives

    Delta_(b-1)-Delta_b
      = H_b [ (a+2b-2)/(3b-2) - (a+2b)/(3b) ]
      = H_b 2(a-b)/[3b(3b-2)] >=0.

At b=a-1, Delta_(a-1)=H_a. For b>=a, every Delta_b equals H_a. Thus the increments are nonincreasing everywhere, including the seam. Symmetry gives the other variable's concavity.

For h>=a, shifted tripling is equality, since

    P_*(a,3h+a-1)=H_a [3h+3(a-1)/2]=3P_*(a,h).

For h<a, 3h+a-1 >=a. The inequality reduces to

    H_a/H_h >= (2a+h-1)/(a+2h-1).

Define F_h(a)=H_a(a+2h-1)/(2a+h-1). Then F_h(h)=H_h and, for a>=h,

    F_h(a+1)/F_h(a)
       = (3a+1)(a+2h)(2a+h-1)
           /[3a(a+2h-1)(2a+h+1)] >=1,

because numerator minus denominator is exactly 2(a-h)(a-h+1). This proves the inequality for every a,h.

To check the rank envelope at t=3/4, first observe

    (1+1/(3j))^3 <= (3j+2)/(3j-1),  j>=1.

The difference after clearing the positive denominators is 9j+1>0. Telescoping gives H_a^3 <=(3a-1)/2. For b>=a, put c=a+b-1 and A=a-1. The function (c-A/2)^3/c^4 is decreasing on c>=2A+1, because its logarithmic derivative has numerator 2A-c<0. Consequently the worst value of P_*^3/(a+b-1)^4 is at b=a, where the preceding bound gives

    P_*(a,a)^3 <= [(3a-1)/2]^4 <=(2a-1)^4.

Therefore P_*(a,b)<=(a+b-1)^(4/3) for every a,b.

Finally log H_a=(1/3)log a+O(1) by summing log(1+1/(3j))=1/(3j)+O(j^-2), so the diagonal exponent is exactly 4/3. No t<3/4 upper envelope can hold on this profile for all a.

## What it rules out, and what remains allowed

This is a countermodel to an inference from the **listed profile axioms**. It is not asserted to come from an actual tensor character. Additional relations obeyed by genuine tensor characters may rule it out. Merely using every h, optimizing the recurrence, taking larger tensor powers of the same inequalities, or sharpening the product estimate cannot prove omega<9/4 through this profile system.

The next attack must supply a genuinely stronger tensor relation. For example, a uniform growth inequality with smaller additive shift than P(a,3h+a-1)>=3P(a,h), or a new relation linking different a,b beyond separate concavity, must violate P_* for an explicit pair. That gives an exact cheap falsification test for any proposed strengthening.

Two further escalations are also blocked inside the present mechanism:

1. Concatenating an odd number 2k+1 of alternating outer/middle sectors gives the candidate inequality P(a,(2k+1)h+k(a-1)) >= (2k+1)P(a,h). It follows already by iterating the normalized linear-growth slope. The same P_* satisfies it: for h>=a it is equality; for h<a the needed H_a/H_h ratio is the one proved above, independently of k. Thus a larger odd sector count with proportionate shift supplies no better exponent.

2. One cannot obtain a larger entropy exponent simply by upgrading Proposition 3.1 to A^(direct sum L) degenerating to direct sum_h [A_h tensor B_X(Q)] with Q=M^(1+epsilon) while L=O(M). The Y-flattening ranks of A and of the separated target are respectively sum_h rank_Y(A_h) and Q sum_h rank_Y(A_h), since the corresponding Z sectors are disjoint. The source flattening rank is L sum_h rank_Y(A_h). Degeneration cannot increase flattening rank, so Q<=L whenever at least one A_h is nonzero. Therefore auxiliary dot-product dimension M^(1+epsilon) costs at least that many source copies. The existing Q=M,L=5M achieves the largest possible power of M in this format. This does not prohibit a genuinely different construction.

## Cost and provenance boundary

This argument neither constructs a finite rank decomposition nor certifies the entire released manuscript. It is independent of field descent and bit arithmetic. It audits a mathematical escalation route in the actual mechanism and leaves the original exponent bound conditional on the release's other lemmas. Prior-art priority for this numerical extremal profile is unknown.
