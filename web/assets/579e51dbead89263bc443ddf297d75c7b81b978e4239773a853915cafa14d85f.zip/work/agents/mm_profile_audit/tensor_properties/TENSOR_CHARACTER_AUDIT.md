# Tensor-character audit of the 9/4 profile barrier

Status: exact deductions and exact all-parameter compatibility proofs. No tensor character extending the proposed profile has been constructed. No new inequality excluding the profile was found among the source relations or the standard polynomial-product restrictions audited here. This is a scoped obstruction to these routes, not a proof that all stronger tensor relations fail.

## Sources and scope

- OpenAI, *An Upper Bound of 9/4 for the Matrix Multiplication Exponent*, October 2, 2026, supplied release107 text `work/agents/complexity_algebra/sources/mm9_4.txt`; source https://raw.githubusercontent.com/openai/math/main/preprints/Matrix-Multiplication-Nine-Fourths-October-2-2026/paper.pdf . Definition 2.1, equations (2.3)–(2.4), Lemma 2.3, Corollary 3.2, equations (4.1)–(4.5), Lemmas 4.1–4.2, Lemma 5.1. Protocol-pinned source commit adc7f1241b42e322a6451854ab7e4b4c146bf78a.
- Josh Alman, Baitian Li, Kevin Pratt, *The edge of the asymptotic spectrum of tensors*, current arXiv v2, September 27, 2026: https://arxiv.org/html/2604.01386v2 . Proposition 8.1, Lemma 8.2, Corollaries 8.7/8.9/8.10, Proposition 8.13. Live version checked October 7, 2026.

The profile under audit is

\[
H_a=\prod_{j=1}^{a-1}\left(1+\frac1{3j}\right),\qquad
P_*(a,b)=H_{\min(a,b)}\left(\max(a,b)+\frac{\min(a,b)-1}{2}\right),\qquad t=\frac34.
\]

The parent note proves that this is the pointwise smallest profile satisfying the numerical source axioms. The present audit investigates information lost when the character is replaced by those numerical axioms.

## 1. Full multiplicativity and the correct direct-sum law

For every tensor A define

\[
Q(A)=\left(\prod_{\pi\in S_3}\lambda_\pi(A)\right)^{1/(6t)}.
\]

This agrees with P on C(a,b). It is symmetric under leg permutations, multiplicative under tensor products, and monotone under restriction and degeneration. It is **not** asserted to be additive or a normalized character: Q(1)=1, but Q(m)=m^{1/t} on the scalar diagonal tensor m.

The exact sum constraint is

\[
Q(A\oplus B)^t\ge Q(A)^t+Q(B)^t.\tag{1}
\]

Proof: set u_pi=lambda_pi(A), v_pi=lambda_pi(B). The geometric mean G on six coordinates is superadditive: G(u+v)>=G(u)+G(v). If U=G(u), V=G(v)>0, write u+v=(U+V)[r(u/U)+(1-r)(v/V)] with r=U/(U+V). Coordinatewise weighted AM-GM gives product of the bracket at least 1. The cases U=0 or V=0 follow by continuity. Character additivity now gives (1). More than two summands follows by induction.

This law is a constraint on arbitrary tensors. It cannot be applied to an arbitrary expression involving P(a,b) without a proved restriction or degeneration connecting those C-tensors. In particular, a full direct sum cannot be inferred merely from shared-leg blocks; this is exactly why Proposition 3.1/Corollary 3.2 is needed in the source.

Let S(a,b)=tensor_product_{pi in S3} C(a,b)^pi, if that notation is used for the balanced tensor. Then lambda(S(a,b))=P(a,b)^(6t), its three leg dimensions all equal [ab(a+b-1)]^2, and S(1,b) is isomorphic to T_(b^2). Products and restrictions of S follow by tensoring the six corresponding relations for C; none adds a new exponent to an already valid Q-comparison.

The rank avenue for S is limited but not closed: on the diagonal its flattening rank [a^2(2a-1)]^2 already grows as a^6. Thus no rank upper bound with a power below 6 is possible. P_min(a,a) grows as a^(4/3), so comparing only these powers yields 8t<=6, again t<=3/4. A genuinely improved finite rank decomposition could still change the conclusion at fixed a; no such decomposition was acquired or certified in this audit.

## 2. Zero axes and the outer-product envelope

The natural extension is C(a,0)=C(0,b)=0 and P(a,0)=P(0,b)=0. At b=1 the determinant sequence has zero kernel, giving only

\[
P(a,2)\le2P(a,1)=2a.
\]

For P_* and a>=2 this is (4a+2)/3<=2a; for a=1 it is equality. Consequently the extension by zero is separately concave. No zero-axis failure excludes the candidate.

There is a stronger source-derived numerical upper bound than its rank envelope:

\[
C(a,b)\le B_Y(a)\otimes B_X(b),\qquad P(a,b)\le ab.\tag{2}
\]

The source on the right is the outer-product tensor sum_{i,j} x_i y_j z_ij. Substitute z_ij=z_(i+j). For each permuted character its value is a^(p_Y^(pi)) b^(p_X^(pi)), and sum_pi p_X^(pi)=sum_pi p_Y^(pi)=6t. Multiplying and taking the 1/(6t) power proves (2).

P_* passes (2) exactly. Since 1+1/(3j)<=1+1/j, H_a<=a. Therefore H_(a+1)-H_a=H_a/(3a)<=1/3 and H_a<=1+(a-1)/3=(a+2)/3. Thus

\[
P_*(a,a)=\frac{3a-1}{2}H_a\le\frac{(3a-1)(a+2)}6\le a^2,
\]

the last inequality being (3a-2)(a-1)>=0. For b>=a the ratio P_*(a,b)/(ab) decreases with b, so the diagonal bound suffices.

## 3. Two elementary H-product inequalities

For every positive m,n,

\[
H_{mn}\le H_mH_n.\tag{3}
\]

Proof: group the factors j=m,...,mn-1 into blocks j=mk,...,m(k+1)-1 for k=1,...,n-1. For fixed k the polynomial

\[
F_k(\alpha)=\prod_{j=mk}^{m(k+1)-1}(1+\alpha/j)
\]

is convex on [0,1], because all its coefficients are nonnegative. F_k(0)=1 and F_k(1)=(k+1)/k by telescoping. Hence F_k(1/3)<=1+1/(3k). Multiplication proves (3).

In the opposite direction, for positive a,c set a star c=2ac-a-c+1. Then

\[
H_{a\mathbin\star c}\ge H_aH_c.\tag{4}
\]

Proof: put q0=2a-1. The factors j=a,...,(a star c)-1 divide into c-1 blocks j=q0 k+r, -(a-1)<=r<=a-1. In each block,

\[
\prod_r(1+1/(3j))\ge1+\tfrac13\sum_r1/j\ge1+1/(3k).
\]

The second inequality is arithmetic-harmonic mean: the block has q0 entries with arithmetic mean q0 k. Multiplication proves (4). All denominators are positive, including k=1.

## 4. P_* is componentwise submultiplicative for every orientation

The exact numerical property is

\[
P_*(ac,bd)\le P_*(a,b)P_*(c,d)\quad(a,b,c,d\ge1).\tag{5}
\]

This is not an assertion of the generally unproved tensor restriction C(ac,bd)<=C(a,b) tensor C(c,d). It is a compatibility property stronger than needed for the valid dense-packing restrictions below.

First suppose a<=b and c<=d. By (3), H_ac<=H_aH_c. The remaining linear factors satisfy

\[
bd+(ac-1)/2\le[b+(a-1)/2][d+(c-1)/2].
\]

After multiplying the difference by 4, its minimum over b>=a,d>=c occurs at b=a,d=c and equals 3(a-1)(c-1)>=0.

To handle crossed orientations, fix a product K. At integer m<=sqrt(K), allow the second argument K/m to be real in the same affine formula. The exact consecutive difference is

\[
H_m[K/m+(m-1)/2]-H_{m+1}[K/(m+1)+m/2]
=\frac{2H_m}{3}\left(\frac K{m(m+1)}-1\right).
\]

It is nonnegative whenever m+1<=sqrt(K). Thus P_* decreases as its smaller argument increases while the product is fixed, when comparing integer smaller arguments. If a<=b and c>=d, the pairs (ac,bd) and (ad,bc) have the same product, and the former's smaller argument is at least ad. Consequently P_*(ac,bd)<=P_*(ad,bc), and the already proved aligned case applied to (a,b),(d,c) finishes (5). Input symmetry covers all remaining orientations.

## 5. Dense packing and tensor powers: exact survival

For positive a,b,c,d and 1<=q<=min(a,b), put

\[
A=q(c-1)+a,\qquad B=q(d-1)+b.
\]

There is a restriction

\[
C(a,b)\otimes C(c,d)\ge C(A,B).\tag{6}
\]

Construction: index the first product input by (i,k). Retain i<q for k<c-1 and i<a for k=c-1; relabel it by i+qk. This gives every integer in [0,A-1] exactly once. Retain and relabel the second input analogously by j+q l. On the output apply z_(r,s) -> z_(r+qs). Every retained input pair now has output index (i+qk)+(j+ql), with coefficient 1. Output coordinates may merge; that is an allowed linear substitution on the third leg. The result is exactly C(A,B).

Every actual profile must satisfy P(A,B)<=P(a,b)P(c,d). Since A<=ac and B<=bd, monotonicity of P_* and (5) show that P_* satisfies this for all parameters. In particular:

\[
C(m,m)\otimes C(c,d)\ge C(mc,md),\qquad
P_*(mc,md)\le P_*(m,m)P_*(c,d).
\]

Iteration covers every finite composition or tensor power using these dense-packing maps. No finite search is used in this conclusion.

## 6. Sparse no-carry embeddings: exact survival

For q=a+b-1 put A=q(c-1)+a, B=q(d-1)+b. Then

\[
C(A,B)\ge C(a,b)\otimes C(c,d).\tag{7}
\]

Retain input indices i+qk and j+q l, and retain output indices r+qs, where i<a, j<b, r<a+b-1=q. Since i+j<q, there are no carries or output collisions, so the retained tensor is exactly the product. Larger q also works.

Assume first a<=b and c<=d. Then A<=B, A>=a star c, and (4) gives H_A>=H_aH_c. Writing L_cd=d+(c-1)/2, the other factor is

\[
B+(A-1)/2=qL_{cd}-(a-1)/2
\ge [b+(a-1)/2]L_{cd},
\]

because the difference is (a-1)(L_cd-1)/2>=0. Therefore P_*(A,B)>=P_*(a,b)P_*(c,d).

For crossed orientation a<=b,c>d, compare to the aligned pair A'=q(d-1)+a, B'=q(c-1)+b. The two target pairs have the same sum, while min(A,B)>=A'. At fixed integer sum S,

\[
P_*(m+1,S-m-1)-P_*(m,S-m)
=\frac{H_m}{3m}(S-2m-1)\ge0
\]

for m+1<=S/2. Hence the crossed target has at least the aligned target's profile value. The aligned proof applies. Symmetry completes all orientations. Monotonicity handles q>a+b-1.

Thus every finite iteration of the standard no-carry embedding (7) also preserves P_*.

## 7. Rectangular matrix links and current edge rigidity

The source's oriented dot products factor every rectangular matrix tensor. Their character values are monomials in the three dot-product exponents. Balancing under all leg permutations therefore gives Q(M_<E,H,L>)=EHL, independently of t. Dimension-only outer-product comparisons reduce to inequalities such as (2); they do not bound t below 3/4.

There is stronger current rigidity on the boundary: Alman–Li–Pratt v2 Proposition 8.1 proves that a dot-product exponent p_i=1 forces sum p=2, using Schönhage's direct-sum degeneration (Lemma 8.2). Corollaries 8.7/8.10 identify the entire character there with an edge support functional. Proposition 8.13 gives lower domination by powers of those edge functionals. These hypotheses allow a hypothetical p=(3/4,3/4,3/4) to remain in the interior. Applying boundary classification to it would be invalid. In this symmetric case the edge domination lower bound on C(a,b) is at most (a+b-1)^(3/4), whereas P_*(a,b)^(3/4) is at least that value: P_*(a,b)>=a+b-1 by its slope in b and its diagonal value. Thus this domination also gives no violation on the C-family.

Explicitly, for a=min(a,b)>=2, H_a>=H_2=4/3 gives D_a=(3a-1)H_a/2>=2a-2/3>2a-1. For b>=a the slope is H_a>=1, so P_*(a,b)>=D_a+(b-a)>=a+b-1. At a=1 this lower envelope is equality. This proves the edge-domination compatibility without an asymptotic estimate.

## 8. Residual gap and failure ledger

- The zero-axis extension, P<=ab, dense carry-merging compositions, sparse no-carry compositions, and all their finite iterations are compatible with P_* by exact proofs.
- The profile is not a character: Q(diagonal m)=m^(1/t), and Q has a power-sum lower bound under direct sum rather than additivity. Confusing P with lambda would manufacture an invalid constraint.
- Specifying lambda_pi(C(a,b))=P_*(a,b)^(3/4), with all p_i=3/4, is only a consistent six-value numerical lift for the displayed source inequalities. It does not specify values on sums/products/restrictions of arbitrary tensors or prove a semiring extension.
- Current edge rigidity classifies p_i=1, not every interior point. It cannot be extrapolated to p_i=3/4.
- A small exact rational diagnostic found no dense-packing violation in a bounded parameter range; it is superseded here by the all-parameter proof and is not evidence for semiring extendibility.

The next attack must exhibit an additional proved restriction/degeneration between nontrivial sums or products of C/S tensors that yields an explicitly violated inequality, or a theorem excluding a full character with this interior dot-product behavior. Full character additivity and multiplicativity by themselves do not furnish that missing tensor comparison. The present audit neither constructs the extension nor proves it impossible.
