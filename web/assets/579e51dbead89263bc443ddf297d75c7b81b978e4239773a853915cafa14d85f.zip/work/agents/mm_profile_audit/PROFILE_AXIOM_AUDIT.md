# Independent adversarial audit of the nine-fourths profile obstruction

Status: proved statements about an abstract numerical profile system. No tensor character with the extremal profile is constructed, and no lower bound on matrix multiplication is claimed. The released manuscript's other lemmas are not certified by this audit.

Source: OpenAI, *An Upper Bound of 9/4 for the Matrix Multiplication Exponent*, 2 October 2026, Sections 2–5, specifically Definition 2.1, equations (2.3), (2.4), (4.4), (4.5), Lemmas 4.1, 4.2 and 5.1. Protocol pin: `adc7f1241b42e322a6451854ab7e4b4c146bf78a`. Primary URL: https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Matrix-Multiplication-Nine-Fourths-October-2-2026/paper.pdf . Full local text inspected: `work/agents/complexity_algebra/sources/mm9_4.txt`.

## Verdict and necessary corrections

The extremal profile in `work/agents/complexity_algebra/MM_PROFILE_BARRIER.md` satisfies every explicitly required numerical profile axiom, at `t=3/4`, over all positive integer arguments. It also satisfies the natural zero-axis extension and the additional boundary concavity inequality this extension permits.

Two corrections are needed in that note:

1. “No t<3/4 upper envelope can hold” has the inequality reversed. No `t>3/4` envelope holds globally on this profile. Every positive `t<=3/4` envelope does hold, because `1/t>=4/3`.
2. The cleared-denominator difference in `(1+1/(3j))^3 <= (3j+2)/(3j-1)` is `6j+1`, not `9j+1`. It remains strictly positive.

The obstruction has an exact strengthening: this profile is the **pointwise minimum** of the complete normalized, positive, symmetric, separately discrete-concave, shifted-tripling profile class. Thus the numerical system admits maximal feasible `t=3/4` exactly, not only a matching asymptotic exponent.

## Exact system extracted from the source

For a fixed character, the source has oriented dot-product exponents `p_X,p_Y,p_Z in [0,1]` and `t=(p_X+p_Y+p_Z)/3>0`. Its Section 2 argument establishes `p_X+p_Y+p_Z>=1`, hence `t in [1/3,1]`; stronger tensor facts can further constrain this interval, but are not needed for this proof.

Its symmetrized profile is

`P(a,b) = (product_{pi in S_3} lambda_pi(C(a,b)))^(1/(6t))`.

The extracted numerical constraints are exactly:

* Domain `a,b>=1`; positive real values.
* `P(a,b)=P(b,a)` and `P(1,b)=b`.
* `2P(a,b)>=P(a,b-1)+P(a,b+1)` for `a>=1,b>=2`, and the corresponding first-variable inequality by symmetry.
* `P(a,3h+a-1)>=3P(a,h)` for **all** `a,h>=1`.
* `P(a,b)<=(a+b-1)^(1/t)`.

Definition 2.1 also requires full character additivity, multiplicativity, normalization and restriction monotonicity on **all tensors**. Those are not equivalent to the five numerical items above. No extension to that full semiring is provided by the profile countermodel.

## Direct verification, including boundaries

Define

`H_1=1, H_a=product_{j=1}^{a-1}(3j+1)/(3j)`

and

`P_*(a,b)=H_{min(a,b)}[max(a,b)+(min(a,b)-1)/2]`.

Positivity, symmetry, `P_*(1,b)=b`, `P_*(1,1)=1`, and `P_*>=max(a,b)>=1` are immediate. Thus the elementary positivity and scalar normalization consequences are respected.

Fix `a` and write `Delta_b=P_*(a,b+1)-P_*(a,b)`. For `1<=b<a`, direct substitution gives

`Delta_b=H_b(a+2b)/(3b)`.

For `2<=b<a`,

`Delta_{b-1}-Delta_b=H_b 2(a-b)/[3b(3b-2)]>=0`.

The seam has `Delta_{a-1}=H_a` when `a>=2`; all `b>=a` increments equal `H_a`. For `a=1`, every increment is 1. These statements cover every `b>=2` in Lemma 4.1, including `b=a-1`, `b=a`, and the whole tail. Symmetry covers the other variable.

Naturally extend `P_*(0,b)=P_*(a,0)=0`. Concavity at `b=1` requires `P_*(a,2)<=2a`. For `a>=2`, `P_*(a,2)=(4a+2)/3<=2a`; for `a=1`, it equals 2. Thus even this stronger boundary version passes. Zero-axis values are not required by Lemma 5.1, whose domain is strictly positive integers.

For shifted tripling, if `h>=a`, both profile evaluations are on the affine tail and equality holds:

`P_*(a,3h+a-1)=3H_a[h+(a-1)/2]=3P_*(a,h)`.

If `h<a`, the left argument `3h+a-1` is at least `a`; the desired inequality is exactly

`H_a/H_h >= (2a+h-1)/(a+2h-1)`.

For fixed `h`, put `F_h(a)=H_a(a+2h-1)/(2a+h-1)`. Then `F_h(h)=H_h` and

`F_h(a+1)/F_h(a)=(3a+1)(a+2h)(2a+h-1)/[3a(a+2h-1)(2a+h+1)]`.

The numerator minus denominator is `2(a-h)(a-h+1)>=0`. Therefore `F_h(a)>=F_h(h)` for all `a>=h`, completing the full `h<a` range. No limiting or numerical extrapolation is used.

For the rank envelope at `t=3/4`, put `x=3j`. The elementary inequality has the exact positive gap

`x^3(x+2)-(x+1)^3(x-1)=2x+1=6j+1>0`.

It telescopes to `H_a^3 <= (3a-1)/2`. For `b>=a`, put `A=a-1`, `c=a+b-1`; then

`P_*(a,b)^3/c^4=H_a^3(c-A/2)^3/c^4`.

The logarithmic derivative of `(c-A/2)^3/c^4` is

`(2A-c)/[c(c-A/2)]<0`

on `c>=2A+1`. Hence the maximum in `b>=a` is on the diagonal. There

`P_*(a,a)^3=H_a^3[(3a-1)/2]^3 <=[(3a-1)/2]^4 <=(2a-1)^4`.

Symmetry completes the rank-envelope proof. At `a=1`, the product and inequalities remain valid; in particular `P_*(1,b)=b<=b^(4/3)`.

## Pointwise-minimality theorem

**Theorem.** Every profile obeying positivity, symmetry, axis normalization, separate discrete concavity and shifted tripling satisfies `P(a,b)>=P_*(a,b)` at every positive integer pair.

**Proof.** Fix `a`. The row increments `Delta_{a,h}=P(a,h+1)-P(a,h)` decrease by concavity. If any increment were negative, all later increments would be no larger, forcing eventual negative row values; positivity excludes this. Thus the increments decrease to a finite limit `L_a>=0`. Cesaro averaging gives `P(a,n)/n -> L_a` as `n->infinity`.

Let `D_a=P(a,a)` and `c_a=(a-1)/2`. Iterating tripling from `h_0=a` gives

`h_k=3^k(a+c_a)-c_a`, `P(a,h_k)>=3^kD_a`.

Divide by `h_k` and use the row limit. It follows that

`L_a>=D_a/(a+c_a)=2D_a/(3a-1)=:K_a`.

Symmetry expresses consecutive diagonal differences as

`D_a-D_{a-1}=Delta_{a-1,a-1}+Delta_{a,a-1}>=L_{a-1}+L_a>=K_{a-1}+K_a`.

Using `D_a=(3a-1)K_a/2` and rearranging gives

`K_a >= (3a-2)/(3a-3) K_{a-1}` for `a>=2`.

Since `K_1=D_1=1`, iteration gives `K_a>=H_a`. Hence `D_a>=(3a-1)H_a/2`. For `b>=a`, every increment is at least `L_a`, so

`P(a,b)>=D_a+(b-a)L_a>=D_a+(b-a)K_a=K_a[b+(a-1)/2]>=P_*(a,b)`.

For `b<a`, apply symmetry. This is an all-integer proof, independent of the rank-envelope estimate. QED.

The same argument supplies the stronger arbitrary row-growth comparison

`P(a,n)>=(n+c_a)/(h+c_a) P(a,h)` for every integer `n>=h>=1`:

iterate tripling starting from `h` to obtain `L_a>=P(a,h)/(h+c_a)`, then sum increments bounded below by `L_a`. The extremal profile satisfies this stronger comparison as well, because it already satisfies the original axioms. Larger odd-sector inequalities with proportional shifts are instances of it, so they supply no new constraint.

## Exact limits and blocked inference

The product has the exact gamma form

`H_a=Gamma(a+1/3)/[Gamma(4/3)Gamma(a)]`

and asymptotic

`H_a ~ a^(1/3)/Gamma(4/3)`.

Consequently

`P_*(a,a) ~ [3/(2Gamma(4/3))] a^(4/3)`.

For any `t>3/4`,

`P_*(a,a)/(2a-1)^(1/t) -> infinity`,

because its power of `a` is `4/3-1/t>0`. For every `0<t<=3/4`, the envelope follows from the proven `t=3/4` case. Combined with Lemma 5.1, the maximal feasible `t` in the numerical system is therefore exactly `3/4`.

It follows that this system cannot prove `t<=c` for any `c<3/4`, nor any universal diagonal lower growth of exponent greater than `4/3`. The release turns `t<=3/4` into `omega<=9/4` using detecting characters. A better uniform character bound, including `t<=2/3` needed for `omega=2`, cannot be deduced solely from these numerical constraints.

This does **not** establish `omega>=9/4`, establish a genuine character with `t=3/4`, obstruct every tensor-power construction, or obstruct stronger properties of the actual polynomial tensors. Any such claim would reverse the logical direction of the countermodel.

## Unsymmetrized construction inequalities

There is a consistent six-value lift on the named polynomial family: choose `p_X=p_Y=p_Z=t=3/4` and assign every oriented character evaluation of `C(a,b)` the value `P_*(a,b)^t`. Axis values then equal the required `b^p_X`, each value is between 1 and rank, and the symmetrized definition recovers `P_*`.

For the determinant filtration's **arbitrary** probability pair, the unsymmetrized inequality reduces after a positive `1/t` power to

`2P_*(a,b)>=exp(H(q)) P_*(a,b+1)^q_+ P_*(a,b-1)^q_-`.

The right side is at most `P_*(a,b+1)+P_*(a,b-1)`, so discrete concavity implies every one of these inequalities. For the three-sector construction, arbitrary probabilities reduce similarly to a three-term entropy maximum of `3P_*(a,h)`, which shifted tripling bounds. Thus optimizing probabilities before the geometric averaging, when treated only as the displayed polynomial-family inequalities, does not exclude the lift.

The lift is an assignment on selected tensors only. It does not assert additivity or multiplicativity on the full tensor semiring.

## Stronger source structure and recent literature boundary

Definition 2.1 does impose more than the extracted profile. With

`Q(A)=(product_pi lambda_pi(A))^(1/(6t))`,

one has `Q(AB)=Q(A)Q(B)` and monotonicity under restriction/degeneration. Also Holder's inequality yields

`Q(A+B)^t >= Q(A)^t+Q(B)^t`,

while scalar normalization is `Q(m)=m^(1/t)` for full diagonal tensors. None of these global requirements has been satisfied by a full extension of `P_*`; source-level restrictions between products of polynomial tensors must be analyzed separately.

Recent primary literature checked live: Alman–Li–Pratt, *The edge of the asymptotic spectrum of tensors*, arXiv:2604.01386v2, 27 September 2026, Proposition 8.1 and Corollary 8.10: https://arxiv.org/html/2604.01386v2 . Its edge rigidity applies when one oriented dot-product exponent equals 1; the other two then sum to 1 and the spectral point is an edge support functional. That gives `t=2/3` on those boundary faces, but the proposed interior choice `(3/4,3/4,3/4)` does not satisfy the boundary hypothesis. Extending edge rigidity to the interior would be a new load-bearing result, not a direct consequence of that paper.

A further exact upper bound follows directly from the full source character axioms. The outer-product tensor `B_Y(a) tensor B_X(b)` restricts to `C(a,b)` by merging each output coordinate `z_ij` into `z_(i+j)`. Averaging its oriented values gives `P(a,b)<=ab`. The candidate passes this bound over all integers: product comparison gives `H_a<=a`, then `H_(a+1)-H_a=H_a/(3a)<=1/3` yields `H_a<=(a+2)/3`. Thus

`D_a<=((3a-1)(a+2))/6<=a^2`,

with final positive difference `(3a-2)(a-1)/6`. For `b>=a`, `P_*(a,b)/(ab)=H_a/a [1+(a-1)/(2b)]` decreases in `b`, so the diagonal bound suffices. Symmetry finishes.

The independent tensor-properties audit also proves, over all parameters, that the candidate passes both standard cross-size product comparisons:

* `C(m,m) tensor C(c,d) >= C(mc,md)`, forcing `P(mc,md)<=P(m,m)P(c,d)`.
* For `q=a+b-1`, `C(q(c-1)+a,q(d-1)+b) >= C(a,b) tensor C(c,d)`, forcing the opposite sparse no-carry product comparison.

Complete proofs and their exact orientation accounting are in `tensor_properties/`. Therefore these genuine full-character consequences are stronger than the displayed profile axioms but still do not exclude the candidate. No source relation reopening the exponent-two attack has been found.

## Failure ledger and next falsifiable attack

* Failed: optimize all discrete profile inequalities; exact pointwise-minimum theorem closes it.
* Failed: boundary normalization/zero axes; profile passes analytically.
* Failed: arbitrary entropy probabilities in the two released polynomial constructions; the explicit six-value lift passes.
* Failed: apply 2026 edge rigidity to all characters; hypothesis only covers a boundary face.
* Failed: add the outer-product upper bound `P<=ab`; the profile passes analytically.
* Failed: standard tensor-product compression and sparse no-carry embeddings; the independent audit proves the profile passes all parameters.
* Unresolved: extend the candidate to a globally additive/multiplicative tensor character, or find a genuine source-level restriction/degeneration violating the candidate.

A stronger tensor relation must be written as an inequality with explicit integer parameters and checked against `P_*`; exhibiting a strict violation is the cheapest first admission test. The best remaining direction is an interior character rigidity statement or a new polynomial-tensor comparison linking different input lengths beyond the extracted row constraints.
