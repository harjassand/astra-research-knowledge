# Primary audit: BLR, positive characteristic, and direct finiteness

Audit date: 2026-10-07. Scope: primary literature only; source197 was not inspected. Local corpus claims were not used as evidence. Protocol and repository start/core were read.

## Conclusion and permitted use

The requested chain is **formally valid if the positive-characteristic idempotent premise is accepted**, and that premise is literally asserted in BLR math/0701434v2. Its hypotheses fit a torsion-free word-hyperbolic group and F2 exactly. However, this audit found a substantive gap in the cited proof chain: the companion theorem requires stable finiteness or characteristic zero or soficity; its separate attribution to Formanek in positive characteristic strengthens the cited trace statement beyond what Formanek and Burger-Valette actually prove. Therefore this audit does **not independently certify** the unconditional statement that every torsion-free word-hyperbolic G has directly finite F2[G]. It also does **not prove that statement false**, and found no correction or counterexample to that exact statement. An alleged contradiction with a new candidate must remain unestablished pending an independent valid positive-characteristic bridge.

An earlier progress message accepted the BLR introduction at face value; that provisional acceptance is withdrawn after tracing the proofs.

## Exact BLR statement and dates

Primary paper: Arthur Bartels, Wolfgang Lueck, Holger Reich, *The K-theoretic Farrell-Jones Conjecture for hyperbolic groups*, arXiv math/0701434v2.

- Versioned abstract: https://arxiv.org/abs/math/0701434v2 . First submitted 2007-01-16; v2 submitted 2007-10-29 14:21:09 UTC. The v2 PDF has 33 pages and is marked final version. The internal front-page date remains January 16, 2007; that is not the v2 submission date.
- Exact primary PDF: https://arxiv.org/pdf/math/0701434v2 . Saved as `blr_math0701434v2.pdf` and extracted to `.txt`.
- Main Theorem, printed p.1: for hyperbolic G, every additive category A with right G-action, and every n in Z, the assembly from G-equivariant homology over E_VCyc G to K_n(A *_G pt) is an isomorphism. Consequently ordinary K-theoretic FJ holds for arbitrary coefficient ring R. Rings are associative with unit and need not be commutative (local text lines 10-29; web PDF lines 8-26).
- Printed p.2 explains ordinary RG coefficients by the category of finitely generated free R-modules with trivial G-action. Thus F2 is an admissible coefficient ring; no characteristic-zero condition belongs to the Main Theorem.
- Printed p.3 Applications assumes FJ for every n and every coefficient ring. Printed p.4 has the prime-characteristic Kaplansky bullet (local text lines 163-171; web PDF lines 153-159). The logical hypothesis is: R is a field of characteristic p **or** (R is a skew-field of characteristic p **and** G is sofic), and every finite subgroup of G is a p-group. The claimed conclusion is that RG has only idempotents 0,1. This disjunction is visually confirmed in `blr_v2_p4.png`; there is no hidden soficity requirement attached syntactically to the commutative-field clause.
- For torsion-free G, every finite subgroup is trivial, hence a p-group (order p^0). F2 satisfies the commutative-field clause with p=2. Neither regularity of F2[G] nor invertibility of p is a hypothesis of this bullet. F2 itself is regular, but that does not fill the proof gap below.
- Publisher metadata: https://link.springer.com/article/10.1007/s00222-007-0093-7 . Inventiones mathematicae 172 (2008), pp.29-70; received 2007-03-05, accepted 2007-10-14, published online 2007-12-20, issue April 2008. Publisher full PDF retrieval returned access-page HTML, retained as `blr_hyperbolic_published.html`; it was not counted as a read published PDF.
- Lueck's current publications page links an older v1 manuscript despite listing the published article: https://him-lueck.uni-bonn.de/data/bartels+lueck+reich_K-theoretic_FJC_hyperbolic_groups_xxx0701434.pdf . The downloaded file labeled `blr_hyperbolic_author_final.pdf` is actually v1, verified by first-page stamp. It must not be called the final journal PDF. Both v1 and v2 contain the same relevant introductory bullet.

## The companion theorem does not fill the positive-characteristic field gap

BLR, *On the Farrell-Jones Conjecture and its applications*:

- Primary arXiv: https://arxiv.org/abs/math/0703548 , only v1, submitted 2007-03-19 11:25:33 UTC. PDF https://arxiv.org/pdf/math/0703548 is saved as `blr_applications_latest.pdf` (37 pages).
- Published journal reprint: https://webhomes.maths.ed.ac.uk/~v1ranick/papers/blr2.pdf . Journal of Topology 1 (2008), 57-86, DOI https://doi.org/10.1112/jtopol/jtm008 . Saved as `blr_applications_published.pdf` (30 pages). This is the published text, with journal pagination and theorem numbering, not a later arXiv revision.
- Published Theorem 1.12, p.62 (arXiv Theorem 0.12, p.8): assume R has only trivial idempotents and K0(R) tensor Q -> K0(RG) tensor Q is an isomorphism. The conclusion requires one of: (i) RG is stably finite, (ii) R is a field of characteristic zero, or (iii) R is a skew-field and G is sofic. Published local text lines 259-267; arXiv web lines 248-255.
- Published p.63 prime-characteristic discussion explicitly adds soficity, including for a skew-field that happens to be commutative (published local lines 275-281; arXiv web lines 261-268).
- The proof is Lemma 6.4 and Theorem 6.3 in the journal (arXiv Lemma 5.4 and Theorem 5.3, printed pp.28-29). Stable finiteness is used to infer P=0 from [P]=0 in K0. The available stable-finiteness theorem covers characteristic-zero commutative fields or sofic groups over skew-fields. Merely substituting F2 into K0(F2) -> K0(F2[G]) is therefore not enough for this proof.
- Published p.63 later attributes unrestricted field idempotent triviality for torsion-free hyperbolic groups to Formanek, including prime characteristic. This attribution survives publication (local lines 304-315). It is the second route investigated below.

## Tracing Formanek shows trace triviality, not idempotent triviality, in characteristic p

Formanek, *Idempotents in Noetherian group rings*, Canad. J. Math.25 (1973), 366-369. Primary publisher PDF:

https://www.cambridge.org/core/services/aop-cambridge-core/content/view/25AF425E2069C808258EA860D2329372/S0008414X00050392a.pdf/idempotents-in-noetherian-group-rings.pdf

- Theorem 1, p.366, and generalized Theorem 9, p.368, assume the coefficient field has **characteristic zero**. Theorem 9 assumes infinitely many primes exclude conjugacy to proper prime-power powers. Local `formanek1973.txt` lines 106-111; web PDF lines 123-132.
- Lemmas 5-7, p.367-368, work in characteristic p and prove vanishing of a nonidentity conjugacy-class trace of an idempotent. Local lines 71-80; web PDF lines 71-97.
- The last step proving an idempotent itself equals 0 or 1 invokes Kaplansky's characteristic-zero trace theorem (p.368, local lines 95-99; web lines 112-116). This is unavailable over F2.

Burger-Valette, *Idempotents in complex group rings: theorems of Zalesskii and Bass revisited*, J. Lie Theory8 (1998), 219-228, is the companion's second cited location. Primary author PDF https://people.math.ethz.ch/~burger/pub/1998_Idempotents.pdf . Publisher original PostScript https://ftp.gwdg.de/pub/misc/EMIS/journals/JLT/vol.8_no.2/vallat.ps.gz . Saved as `burger_valette1998.pdf` and `vallat.ps`; visually inspected printed p.226 (`burger_page226.png`).

- Lemma 4.1, p.226, assumes positive characteristic p, no p-torsion, and no conjugacy to p^k powers. Its conclusion is **tau(e)=0 or 1**.
- Proposition 4.2, same page, concludes only that **C[G]** has no nontrivial idempotents, using infinitely many primes and Kaplansky's complex trace theorem. It does not assert that Fp[G] has no nontrivial idempotents.
- Thus the companion's positive-characteristic attribution is not supported by the cited statements as written. The trace conclusion over F2 is particularly weak: every scalar trace already lies in {0,1} because F2 has just those two elements. The vanishing of nonidentity conjugacy-class sums gives additional information, but the cited proof contains no bridge from that information to e=0 or1.
- A simple counterexample to the **generic missing trace implication**, not to the hyperbolic-group claim: in F2[C3], with g of order3, e=g+g^2 is a nontrivial idempotent with coefficient-at-identity trace0. Indeed e^2=g^2+g^4=g^2+g=e. C3 violates the no p-prime torsion restrictions, so this is solely evidence that characteristic-zero positivity cannot be imported formally.

Later independent primary exposition corroborates the distinction: Giles Gardam's winter 2023/24 group-ring course notes, https://www.math.uni-bonn.de/people/gardam/notes/groig.pdf . Printed p.28 Theorem1.122(i) gives char p -> tr(e)=0 or1; (ii) gives char0 -> e=0 or1. Hyperbolic groups appear in Example1.124, and Corollary1.125 explicitly concludes idempotent conjecture in **characteristic zero**. Local `gardam_group_rings2024.txt` lines1425-1443; visually confirmed `gardam_p28.png`. This is not an explicit statement that the positive-characteristic hyperbolic case is open, but it prevents misreading Formanek as an unconditional positive-characteristic theorem.

Lueck's July2025 survey https://arxiv.org/pdf/2507.11337 (v1) p.4 says the field idempotent conjecture follows from the universal regular-ring K0 conjecture. It provides no proof there. This audit has not resolved whether a stronger universal-coefficient argument proves that implication; the statement is retained as contrary evidence, not silently rejected. No broad claim that FJ fails to imply positive-characteristic idempotent triviality is justified by this audit.

## Completely verified elementary implication

Let A be a unital ring with only idempotents 0,1. Suppose xy=1. Set e=yx. Then e^2=y(xy)x=yx=e. If e=1 we are done. If e=0, then 1=(xy)^2=x(yx)y=0, so A is the zero ring and e=0=1 there too. Therefore A is directly finite.

Equivalently, in a nonzero unital ring, a witness xy=1, yx!=1 produces a nontrivial idempotent yx (or 1-yx). This proof is valid in characteristic2 and uses no group hypothesis.

The scalar argument alone does not prove stable finiteness of all matrix rings. The independent algebra subagent's fuller audit is in `idempotent_implication/algebra_audit.md`.

## Strongest focused next attack

Acquire an independent explicit proof that torsion-free hyperbolic F2[G] has no nontrivial idempotents, or a theorem deriving positive-characteristic stable finiteness from the universal coefficient FJ input. The documented K0 and Formanek trace routes each leave a load-bearing missing implication. Until it is supplied, keep the alleged source197 incompatibility conditional; do not claim a refutation of source197 or BLR from this audit.
