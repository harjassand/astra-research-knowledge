# Scalar idempotents and direct finiteness

## Valid implication, with all cases

Let R be an associative unital ring, allowing the zero ring. Assume every
idempotent of R belongs to {0,1}. If x,y in R satisfy xy=1, then

    e=yx,
    e^2=y(xy)x=yx=e.

If e=1, the conclusion is immediate. If e=0, then

    1=(xy)^2=x(yx)y=xey=0.

Thus R is the zero ring in this case, and e=0=1. In either case yx=1.
Therefore R is directly finite. For a nonzero ring, the e=0 branch is
impossible. No commutativity, domain property, characteristic restriction,
or group-theoretic hypothesis is used.

An equivalent proof uses f=1-yx: f is idempotent and xf=0. The branch f=1
forces x=0 and hence 1=xy=0; otherwise f=0.

For R=F_2[G], the ring is nonzero because group elements form an F_2-vector
space basis and the group identity is a nonzero basis vector. Thus any
independently established absence of nontrivial idempotents implies scalar
direct finiteness, without a soficity premise.

## Stable finiteness is a genuinely stronger conclusion

Stable direct finiteness means M_n(R) is directly finite for every n>=1.
The scalar hypothesis cannot be applied to M_n(R): for nonzero R and n>=2,
diag(1,0,...,0) is already a nontrivial matrix idempotent.

In fact the implication "only scalar idempotents 0,1 => stably directly
finite" is false for arbitrary rings. A concrete counterexample is the
Leavitt algebra R=L_k(2,3), over any field k. It is a noncommutative domain,
hence has only idempotents 0 and 1. Let X (2 by 3) and Y (3 by 2) denote its
defining generator matrices; they satisfy XY=I_2 and YX=I_3. Set

    P=[I_2  0]       (2 by 3),
    E=[I_2; 0]       (3 by 2),
    A=YP, B=EX       (both 3 by 3).

Then

    AB=Y(PE)X=YX=I_3,
    BA=E(XY)P=EP=diag(1,1,0) != I_3.

Thus M_3(R) is not directly finite, while R satisfies the scalar hypothesis.
The matrix calculation is independently checked algebraically here. The
imported fact needed for this counterexample is that L_k(2,3) is a domain.

## Sources and scope

The main scalar implication is the elementary proof above and needs no
external theorem. For the domain property of the stable counterexample:

- Pere Ara, "The exchange property for purely infinite simple rings",
  Proceedings of the AMS 132 (2004), 2543-2547, proof of Theorem 2.1,
  p.2546: for m>1, V_{m,n} is an (m-1)-fir (citing Bergman, Theorem 6.1),
  in particular a domain. V_{2,3} is the universal algebra with rectangular
  two-sided inverse matrices, i.e. L_k(2,3) in the convention above.
  DOI: https://doi.org/10.1090/S0002-9939-04-07369-1
  Author-uploaded full text read at:
  https://www.researchgate.net/publication/261931709_The_Exchange_Property_for_Purely_Infinite_Simple_Rings
- The convention and domain statement are also explicitly recorded in
  Bilich-Hazrat-Nam, "Embedding into Leavitt algebra L_k(1,2)",
  arXiv:2512.09241v1, Introduction, equation (1) and following paragraph:
  https://arxiv.org/html/2512.09241v1

No BLR/Farrell-Jones theorem, group presentation, hyperbolicity, torsion
claim, or group-ring idempotent claim was audited in this subtask. Those
remain external premises for any application to the proposed group.

Failure ledger: official AMS PDF retrieval returned HTTP 403; author
uploaded full text and arXiv primary preprint were accessible. No tests or
model agreement were used as mathematical evidence.
