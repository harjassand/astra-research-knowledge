# Primary-source audit: finite Landweber approximate inverses

Outcome: the finite polynomial approximate-inverse mechanism is old. It is defined for every right-hand side in a Hilbert space and requires no actual square-integrable inverse. The free-group endpoint-density/support specialization remains a separate calculation, not a new inversion mechanism.

## Verified primary sources and exact locations

1. Louis Landweber, *An Iteration Formula for Fredholm Integral Equations of the First Kind with Application to the Axially Symmetric Potential Flow About Elongated Bodies of Revolution*, University of Maryland PhD thesis, May 1951, Part I.
   - Institutional landing page: https://drum.lib.umd.edu/items/dd279688-bc7d-4cec-a1ee-a8f3fcfaf928
   - Institutional full PDF: https://api.drum.lib.umd.edu/server/api/core/bitstreams/b22a2a4a-29ee-48ad-832f-4b3fb1fdfeb5/content
   - DOI: https://doi.org/10.13016/M25B3S
   - Printed p. 2 (PDF p. 9), equations (3)–(4): the transformed kernel is A* A and transformed data is A* b, in modern notation.
   - Printed p. 7 (PDF p. 14), equation (17): g_n=g_{n-1}+F-Kg_{n-1}.
   - Printed p. 8 (PDF p. 15), equation (22): g_n=g_0+[1-(1-K)^n]/K · (F-Kg_0). The immediately following paragraph explicitly requires expansion of the numerator and cancellation of K; this fraction denotes a polynomial, not application of an inverse operator.
   - Printed p. 9 (PDF p. 16), equation (23): scaled Hilbert–Schmidt kernel size at most 2. Theorem 3: transformed images Kg_n approach F without assuming existence/convergence of a solution. Theorem 4, printed pp. 9–10 (PDF pp. 16–17): original images Ag_n approach b in mean exactly when the left singular system is complete relative to b; this is the range-closure condition, not existence of a solution.
   - Equations (17), (22), (23) and Theorems 3–4 were visually checked in the scan. The thesis is accessible primary material, but its numbering must not be represented as verified numbering of the journal article.
   - Corresponding published article: L. Landweber, “An iteration formula for Fredholm integral equations of the first kind,” *American Journal of Mathematics* 73(3) (1951), 615–624, https://doi.org/10.2307/2372313 ; journal full text was not available in this run.

2. Plamen Stefanov and Yang Yang, “Multiwave tomography with reflectors: Landweber's iteration,” *Inverse Problems and Imaging* 11(2) (2017), 373–401, https://doi.org/10.3934/ipi.2017018 . Published bibliographic record verified at https://www.aimsciences.org/article/doi/10.3934/ipi.2017018 .
   - Author manuscript: https://www.math.purdue.edu/~stefanop/publications/TAT_with_reflection_numerics.pdf ; same accessible text at https://arxiv.org/pdf/1603.07045 . Locations below refer to this author manuscript.
   - Section 3.1, printed p. 5, equation (3.9): f_0=0, f_k=f_{k-1}-γL*(Lf_{k-1}-m). The following discussion explicitly permits m outside Ran L.
   - Section 3.3, printed p. 9, Theorem 3.2: arbitrary data, no assumption m=Lf; all-data convergence holds precisely in the stable/closed-range case, and unbounded iterates occur generically otherwise.
   - Same p. 9, unnumbered display immediately after (3.22): finite sum Σ_{j=0}^{N-1}(I-γL*L)^j γL*m, with polar spectral filter g_N(λ)=[1-(1-γλ²)^N]/λ. It is smooth at zero for every finite N.
   - Printed p. 10, equation (3.24), and printed p. 11, Remark 3.2: amplification sup|g_N| grows on the order of √N near singular values of order N^(-1/2).
   - These are author-manuscript locators for a published article; publisher full text was subscription restricted, so final typeset page/equation matching is unverified.

## Exact translation, valid without an L² inverse

For bounded A:H→K, Q=AA*, b∈K, h_0=0, α>0, define the polynomial

p_k(x)=αΣ_{j=0}^{k-1}(1-αx)^j=[1-(1-αx)^k]/x, with p_k(0)=αk.

The finite Landweber iterate is

h_k=Σ_{j=0}^{k-1}α(I-αA*A)^j A*b=A* p_k(Q)b.

The intertwining identity (A*A)^j A*=A*Q^j proves this without dividing by Q. Direct polynomial algebra gives

b-Ah_k=(I-αQ)^k b.

With ν_b(E)=〈1_E(Q)b,b〉,

||b-Ah_k||²=∫(1-αx)^(2k) dν_b(x),
||h_k||²=∫[1-(1-αx)^k]²/x dν_b(x).

The integrand in the second formula is extended as zero at x=0. Choosing 0<α<2/||Q|| makes the residual converge to the projection of b onto ker Q; no atom at zero makes the residual vanish. Existence of a genuine solution instead requires ∫x^(-1)dν_b(x)<∞ (after removal of the zero atom). These conditions are different.

## Endpoint-density and support specialization (own derivation)

Suppose ν_b has no zero atom and density ρ(x)~c x^(β-1) at zero, 0<β<1. For 0<α≤1/||Q||, rescaling x=t/(αk) and dominated convergence gives

||b-Ah_k||²~cΓ(β)(2αk)^(-β),
||h_k||²~[2cΓ(β)(1-2^(-β))/(1-β)](αk)^(1-β).

For the supplied Kesten squared-singular density ρ(x)~c x^(-1/2), this becomes residual Θ(k^(-1/4)), iterate norm Θ(k^(1/4)); ∫ρ(x)/x dx diverges. Thus small residual and growing finite norms are fully consistent with absence of an L² inverse.

For A=T_m=1+Σ_{i=1}^m u_i acting by convolution and b=δ_e, elementary word-length propagation yields supp h_k⊆B_{2k-1} and supp(b-Ah_k)⊆B_{2k}. Radius is not support cardinality: the ambient ball can have exponentially many words. The source papers do not claim the free-group specialization; this report does not clear its specific priority. It is a routine application of the established spectral filter to an established density.

## Failure and scope ledger

- Original journal equation numbers: not verified; cite original thesis locators instead.
- Publisher typeset Stefanov–Yang locators: not verified; cite author manuscript §3 and its equation numbers explicitly.
- General finite inverse approximants: strong prior art.
- L² residual convergence outside the actual range: already present in Landweber Theorem 4 and modern Hilbert-space calculus.
- Sharp polynomial support/error optimum: not established by this task; accelerated/Chebyshev or orthogonal-polynomial filters may improve degree dependence, so the Landweber radius rate must not be called optimal.
- No group-factor isomorphism consequence assessed.
