# Exact law and provenance audit

Date: 2026-10-07. Scope: exact scalar spectral law and classical mechanisms, not the correctness of the overall free-factor-isomorphism manuscript.

## Verdict

The proposed density is correct for every integer m >= 1, with k=m+1. It is a direct specialization of a published classical sum-of-free-Haar law. The exact scalar law, its no-atom-at-zero fact, norm, and Marchenko–Pastur limit must not be presented as new results. Effective polynomial approximate inversion can be composed with classical orthogonal-polynomial/Christoffel machinery; the companion note audits that provenance separately.

## Primary sources and exact locations

1. U. Haagerup and F. Larsen, *Brown's Spectral Distribution Measure for R-diagonal Elements in Finite von Neumann Algebras*, MPS-RR 1999-27, August 1999; published J. Funct. Anal. 176 (2000), 331–367, DOI 10.1006/jfan.2000.3610. Author/institution preprint: https://www.maphysto.dk/publications/MPS-RR/1999/27.pdf . Example 5.5, pp. 28–29, equation (5.7), computes the density of |u_1+...+u_k| explicitly. The text following (5.7) attributes its symmetrization to Kesten. This preprint's example numbering differs from the final publication's Example 5.3 (the latter numbering is reported by source 2). The relevant page was rendered and visually checked locally.

2. K. Życzkowski, K. A. Penson, I. Nechita, and B. Collins, *Generating random density matrices*, J. Math. Phys. 52 (2011), 062201; arXiv:1010.3570, https://arxiv.org/pdf/1010.3570 . Appendix A, PDF/printed p. 13, equations (A4)–(A7), gives the return generating function, squared law, singular law, and normalized law, and explicitly cites Haagerup–Larsen Example 5.3. The paragraph before (A3) identifies alternating free-Haar return words with return walks on the k-regular tree. The relevant page was rendered and visually checked locally. **Caveat:** (A3) really prints binomial(2p,p)^2; this is a typo. For p=1 its own operator definition has trace 2, not 4. Its (A4) at k=2 gives (1-4z)^(-1/2), hence the unsquared binomial. Do not use (A3) as evidence.

3. H. Kesten, *Symmetric random walks on groups*, Trans. Amer. Math. Soc. 92 (1959), 336–354, DOI 10.1090/S0002-9947-1959-0109367-6. Primary paper copy: https://sites.math.northwestern.edu/~auffing/papers/KRW.pdf . Theorem 3 at p. 347 gives the spectral radius for the symmetric normalized walk on F_h; the return generating function is (4.9) at p. 349, immediately followed by the root spectral-density integral. Its degree is 2h. For all integer k, including odd k, cite source 1's free-Haar formula or derive the k-regular tree formula directly; do not silently identify the hermitized graph with a 2k-regular Cayley tree.

## Exact reduction

Write V_j=lambda(p_j). The source's free-prefix lemma proves that these are free Haar unitaries. Adjoin a free Haar unitary U_0. Set W_0=U_0 and W_j=U_0 V_j for 1<=j<=m. On the free group, this is the Nielsen automorphism fixing U_0 and mapping V_j to U_0 V_j; its inverse maps V_j to U_0^* V_j. Therefore W_0,...,W_m are again a free Haar family. With S=U_0 T_m, S*S=T_m*T_m and SS*=U_0 Q_m U_0*. Thus Q_m has exactly the squared singular law of the k=m+1 free-Haar sum.

## Graph check without a free extension

On ell^2(F_m) direct-sum ell^2(F_m), A=[[0,T_m],[T_m*,0]] is the adjacency of a bipartite graph. Label its m+1 edges at each vertex by i=0,...,m, where V_0=1. At a plus vertex g, edge i leads to the minus vertex V_i^(-1)g; the reverse edge leads back by V_i. Every vertex has exactly m+1 different neighbours. The graph is connected because a length-two path using edge 0 and edge j realizes a generator step.

A nonbacktracking closed walk would have even length and a word of alternating signs in the V_i labels with successive labels different. Remove identity labels. Between successive surviving letters there are either no zeros (opposite signs, different labels) or one zero (same signs). Two successive zeros are forbidden by nonbacktracking. The surviving nonempty word is therefore freely reduced and cannot be the identity. Hence this graph is the (m+1)-regular tree. On the full ambient group, subgroup right cosets give reducing copies, so the total hermitization graph is a disjoint union of such trees. For m=1 each component is a bi-infinite line.

## Formulas and checks

For k>=2, put b=2*sqrt(k-1). The symmetrized singular law is

    rho_k(t)=k*sqrt(4(k-1)-t^2)/(2*pi*(k^2-t^2)), |t|<b.

Its square pushforward has density

    q_k(x)=k*sqrt(4(k-1)-x)/(2*pi*sqrt(x)*(k^2-x)), 0<x<4(k-1).

There is no atom at zero. The k=2 apparent endpoint cancellation gives the usual arcsine density on (0,4). The k=1 case would instead be a point mass at x=1 and is outside the m>=1 density assertion.

For source-normalized Q_m/m the exact density is

    [m(m+1)/((m+1)^2-m*y)] * (1/(2*pi))*sqrt((4-y)/y), 0<y<4.

Consequences: support is exactly [0,4] for every m>=1; ||T_m||=2*sqrt(m); tau(Q_m)=m+1; and the multiplier tends to 1 on the interior as m grows. This recovers the source's Marchenko–Pastur limit. For m=1 it specializes to 1/(pi*sqrt(y*(4-y))). The distinction between Q=TT* and T*T is harmless for their tracial spectral law, but the cutoff inverse acting on a target vector must keep the indicated TT* order.

An independent derivation uses the regular-tree cavity equation h=1/(z-(k-1)h) and root Green function g=1/(z-kh), with h~1/z at infinity. Stieltjes inversion gives rho_k above. Thus neither the free-extension reduction nor the formula depends on trusting the asymptotic word count in the released manuscript.

## Limits and next action

No additional theorem on free group factor isomorphism follows from this scalar calculation. What it does do is remove an unnecessary asymptotic/moment-convergence step and expose an exact classical input for finite-coefficient constructions. Prior-art clearance for the broader cocycle/flow composition remains separate.

## Completed effective-construction companion

See inverse_prior_art/REPORT.txt and inverse_prior_art/check_christoffel.py. The report checks Nozaki (2015), §2 equations (11)–(13), Theorem 1, and Simon (2008), Theorem 9.2, equations (9.6)–(9.7), plus Landweber's original 1951 thesis. Combining the established Kesten sphere polynomials with the Christoffel kernel gives a real polynomial q_r of degree r with q_r(0)=1, and

    h=T_m* [(1-q_r(Q_m))/Q_m] delta_e,
    residual^2=m/[m+r(m+1)],
    ||h||_2^2=(m+1)r(r+1)(2r+1)/[6(m+r(m+1))^2].

The bracketed quotient is a polynomial of degree r-1. The strict choices r=ceil(eta^(-2)) and an integer m>r/(3eta^2) give both norms <eta. The expanded support has exactly (m+1)*sum_{j=0}^{r-1}m^(2j) entries. This is an effective but generally exponentially large finite-coefficient construction; it is not a polynomial-time algorithm in 1/eta. Sixteen exact rational convolution fixtures m,r=1,...,4 independently checked the formulas and support count. The all-parameter proof is the sphere calculation, not those finite checks. No separately published exact T_m/eta theorem was located; this is not evidence of novelty.
