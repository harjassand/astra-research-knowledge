# Kesten-law and explicit polynomial inverse audit

Status: the proposed exact law, eta^-4 scaling, and positive square-code construction pass this independent mathematical audit. They are classical-law consequences; no independent novelty or correctness certification of the free-factor-isomorphism manuscript is claimed. The estimates below concern only the prefix-sum family, not arbitrary cocycle witnesses or arbitrary words.

## 1. Exact law and its legal interface

Let V_1,...,V_m be the left regular unitaries of a free basis, T=1+sum V_j, Q=TT*, and e the identity vector. The ambient group may be larger: right-coset blocks reduce T, and the e block is the regular representation of the free subgroup.

The self-adjoint operator H=[[0,T],[T*,0]] is the adjacency operator of the (m+1)-regular tree on the relevant connected bipartite block. Alternatively adjoin a free Haar U_0; U_0,U_0V_1,...,U_0V_m form a free Haar family by a Nielsen basis automorphism, and U_0T has the same singular law as T. This is degree m+1, not degree 2(m+1).

Writing d=m+1, the symmetrized singular-value density is

    rho_m(t) = (m+1) sqrt(4m-t^2) / [2 pi ((m+1)^2-t^2)], |t|<2sqrt(m).

Squaring it gives the spectral law at e:

    f_m(x) = (m+1) sqrt(4m-x) / [2 pi sqrt(x) ((m+1)^2-x)], 0<x<4m.

For m=1, this is the arcsine-square density 1/[pi sqrt(x(4-x))]. For every m>=1 it has no atom at zero; ||T||=2sqrt(m). For m>=2 and 0<x<=1,

    1/[pi sqrt(3mx)] <= f_m(x) <= 1/[pi sqrt(mx)].

The lower bound uses sqrt(4m-x)>=sqrt(3m), m+1<=3m/2, and denominator<=(m+1)^2. The upper uses sqrt(4m-x)<=2sqrt(m) and denominator>=(m+1)^2-1=m(m+2).

The exact law is already explicit in Haagerup--Larsen's 1999 preprint, Example 5.5, pp.28--29, equation (5.7); the published 2000 paper calls this Example 5.3. The 2011 reproducing source gives it in Appendix A (A5)--(A6). See the companion source audit below.

## 2. A completely finite, real polynomial construction

For an integer r>=1 define Kesten polynomials in one variable t:

    F_0=1, F_1=t, F_2=t^2-d,
    F_j=t F_{j-1}-m F_{j-2}  (j>=3).

Each F_{2j}(t)=G_j(t^2) for a real integer polynomial G_j. Define

    K = 1 + rd/m,
    q_r(x) = K^-1 [1 + sum_{j=1}^r (-1)^j m^-j G_j(x)],
    p_{r-1}(x) = (1-q_r(x))/x,
    h = T* p_{r-1}(Q)e.

Here G_j(0)=(-1)^j d m^(j-1), hence q_r(0)=1 and p_{r-1} is an actual polynomial of degree r-1. All coefficients are real rational numbers and h has finite support. Exact identities:

    ||Th-e||_2^2 = m/(m+rd),
    ||h||_2^2 = d r(r+1)(2r+1)/[6(m+rd)^2].

Proof without an integration or asymptotic gate: on the d-regular tree rooted at o, F_l(H)delta_o is the indicator s_l of the sphere of radius l. The recurrence follows from Hs_1=s_2+d s_0 and Hs_l=s_{l+1}+m s_{l-1} for l>=2. The spheres are disjoint, with size d m^(l-1) for l>=1.

The residual q_r(H^2)delta_o has coefficient 1/K at o and (-1)^j/(m^j K) on sphere 2j, 1<=j<=r. Its squared norm is

    K^-2 [1 + sum_{j=1}^r d/m] = 1/K.

The odd radial vector h' with coefficient

    a_j = (-1)^(j+1)(r-j+1)/(m^j K)

on sphere 2j-1 satisfies Hh'=delta_o-q_r(H^2)delta_o: the root coefficient is d a_1; sphere 2j has coefficient a_j+m a_{j+1}; the terminal sphere 2r has coefficient a_r. This is also H p_{r-1}(H^2)delta_o, whose lower bipartite component is exactly the h above. Therefore

    ||h||^2 = sum_{j=1}^r d m^(2j-2) a_j^2
            = d/[m^2K^2] sum_{l=1}^r l^2,

giving the claimed identity.

Useful explicit tolerance rule: set

    r=ceil(eta^-2),
    m=max(2, floor[r/(3eta^2)]+1).

Then both required norms are strictly less than eta. Indeed residual^2<1/r<=eta^2, and norm^2<r/(3m)<eta^2. The strict norm inequality follows by expanding

    2(m+rd)^2 - md(r+1)(2r+1)
      = 2r^2 d + rmd + m(m-1) > 0.

Thus m=(1/3+o(1))eta^-4 and polynomial degree r-1=O(eta^-2). The construction has exact support size

    d sum_{j=0}^{r-1} m^(2j) = (m^(2r)-1)/(m-1), m>=2,

and subgroup-word radius <=2r-1. This is exponentially large in r log m; no polynomial total output cost is claimed. It removes the unspecified finite-support approximation from the source lemma.

The residual polynomial is precisely the Christoffel kernel minimizer with q(0)=1 for the squared Kesten measure: F_{2j}(0)^2/||F_{2j}||^2=d/m, so the kernel at zero is K. Primary sources: Nozaki arXiv:1407.4562v2, Section 2 equations (11)--(13), Theorem 1, for Kesten polynomials; Simon arXiv:0806.1528, Theorem 9.2 equations (9.6)--(9.7), for Christoffel minimization. The explicit norm formula above is a direct radial calculation, not a claim that these papers separately state this exact cocycle corollary.

## 3. Necessary scale and sharp family asymptotic

For lambda>0 let

    R_m(lambda)=< (Q+lambda)^-1 e,e>
      = 2m/[sqrt(lambda)((m-1)sqrt(lambda)+(m+1)sqrt(lambda+4m))].

Completing the square in Hilbert space gives

    min_h [||Th-e||^2+||h||^2] = R_m(1),

with minimizer h=T*(Q+1)^-1e. Thus existence of any h with both norms <=eta requires R_m(1)<=2eta^2. The exact formula shows R_m(1)>=1/sqrt(5m): use sqrt(4m+1)<=sqrt(5m) and m-1<=(m-1)sqrt(m), then the denominator is <=2sqrt(5)m sqrt(m). Consequently

    m >= 1/(20 eta^4).

More precisely R_m(1)=(1+o(1))/sqrt(m). For the regularized minimizer,

    error^2=-R_m'(1), norm^2=R_m(1)+R_m'(1),

and both are (1+o(1))/(2sqrt(m)). Therefore if M(eta) is the least integer m for which a real finite-support h with both norms <eta exists, then

    M(eta)=(1/4+o(1))eta^-4 as eta -> 0.

The upper asymptotic first constructs the real resolvent vector with strict slack for m>(1/4+epsilon)eta^-4, and then uses finite-support truncation and boundedness of T. The explicit polynomial rule in Section 2 attains the same exponent with constant 1/3 rather than 1/4. The lower bound applies to arbitrary Hilbert-space h, not merely spectral filters. These statements require no information about support beyond permitted finite approximation.

## 4. Hostile check of the compact square-code prefix family

For m>=2 let ell=ceil(log_2 m), choose m distinct positive words t_j of length ell in x_2,x_3, and set b_j=t_j^2. The b_j freely generate a free subgroup.

Proof: in a reduced word in b_j^{+/-1}, equal-sign adjacent factors do not cancel. Opposite-sign adjacent factors have distinct indices; their cancellation length is a common prefix or common suffix length of t_i^2,t_j^2, hence <=ell-1 because the first or last ell letters are t_i,t_j. Each factor has length 2ell, so its left and right maximal cancellation intervals are disjoint and leave at least two letters. Delete these intervals at all boundaries simultaneously. The next letters at each surviving boundary are not inverse, by maximality of the deleted interval. No factor vanishes and no new boundary forms. The remaining word is reduced and nonempty.

Now a=x_1 is free from the b_j subgroup, u_j=ab_j is a free family by the Nielsen substitution b_j -> ab_j, and p_j=u_1...u_j is a free family by the triangular basis substitution. The source cocycle calculation is unchanged because D vanishes on every b_j. The positive word w_m=p_m a has exact original-generator length

    |w_m|=m(2ell+1)+1.

Combined with Section 2 this supplies |w|=O(eta^-4 log(1/eta)), compared with O(eta^-8) for the source's original b_j=x_2^j x_3 x_2^-j. For m=1 use ell=max(1,ceil(log_2m)) or handle separately. There is no claim that this word length is globally optimal.

## 5. Failure / scope ledger

* No atom at zero is not a bounded inverse: f_m(x)~const*x^-1/2, so integral x^-1 f_m(x)dx diverges for every fixed m. No h in l2 solves Th=e exactly.
* Small-singular-value lower bounds and eta^-4 optimality are only for this freely independent prefix-sum family.
* Degree is m+1. Using the usual free-group Cayley degree 2(m+1) gives the wrong law.
* m=1 requires the endpoint cancellation in the density; m=0 is T=1 and is outside the stated family formula.
* Finite support, its radius, its cardinality, and original-generator witness length are different resource quantities. The exact polynomial vector has huge support.
* The direct square-code proof relies on positivity and equal length. Arbitrary distinct words, or arbitrary variable-length codes, do not automatically satisfy its cancellation bound.
* The retrieved 2011 paper's displayed Appendix A (A3) appears to contain a squared-binomial typo: its k=2 second moment would be 4 instead of 2. Use Haagerup--Larsen (5.7), or the reproducing density (A5)--(A6), not that display.

Source details and retrieval evidence: `primary_law_sources/LAW_AUDIT.md` and its inverse-prior-art child note. No source manuscript was modified.
