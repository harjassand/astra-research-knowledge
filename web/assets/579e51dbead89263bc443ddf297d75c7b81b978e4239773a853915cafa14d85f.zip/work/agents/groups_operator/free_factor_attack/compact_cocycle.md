# Quantitative compact small cocycles for family 287

Status: locally derived quantitative refinement, conditional on the released
flow/perturbation mechanism for applications to von Neumann algebras. The
coefficient and free-group construction below is independent of that mechanism.
Not a global proof audit, priority claim, or practical algorithm for the full
isomorphism. Independent mathematical audit by `kesten_audit` accompanies this.

## Sources and precise load-bearing locations

Release: https://github.com/openai/math/tree/main/preprints/An-isomorphism-of-the-free-group-factors-September-23-2026
at the release snapshot adc7f1241b42e322a6451854ab7e4b4c146bf78a.

- `cocycle.tex`, lemmas `lem:cocycle-prefixes`, `lem:cocycle-spectrum`,
  `lem:small-cocycle`: original free prefixes and qualitative cutoff inversion.
- `flow.tex`, proposition `prop:flow`: operator displacement is at most
  K times coefficient norm/error, K=3 pi.
- `generation.tex`, proposition `prop:perturbation`: old extra Haar generator is
  approximated in operator norm by a word in a small moved n-tuple.
- `entropy-dimensions.tex`, corollary `cor:entropy-dimensions`: unbounded
  generator-dependent entropy dimensions are ALREADY asserted by the release.

Classical spectral ingredient:
Haagerup and Larsen, Brown's spectral distribution measure for R-diagonal
elements in finite von Neumann algebras (2000), published Example 5.3;
1999 preprint Example 5.5, pp.28-29, equation (5.7);
Zyczkowski, Penson, Nechita, Collins (2011), Generating random density matrices,
Appendix A, (A5)-(A6), https://arxiv.org/abs/1010.3570.
The Kesten law is classical; any contribution here is its precise use and the
compact prefix construction, not the spectral distribution.

## Compact free prefix codes

For m>=2 set r=ceil(log_2 m). Choose m distinct positive words t_j of length r
in x_2,x_3; binary enumeration is explicit. Set b_j=t_j^2 and a=x_1.
The words b_j freely generate a subgroup of F(x_2,x_3).

Proof: each b_j has length 2r. Between two adjacent factors b_i^sigma and
b_j^tau in a freely reduced abstract word, equal signs cause no cancellation.
Opposite signs require i!=j. The canceled portion is a common prefix or
suffix of b_i,b_j, and has length at most r-1, because their first r and last
r letters are the distinct words t_i,t_j. Perform these maximal seam
cancellations. The portions deleted from each internal factor are disjoint
and total at most 2r-2, so every factor retains at least two letters. After
these deletions every seam is reduced, and no seam becomes adjacent to a
non-neighboring seam. The resulting word is nonempty. This proves freeness.

Since x_1 is a separate free factor, a,b_1,...,b_m freely generate. Exactly
the two elementary Nielsen changes in the release show that
u_j=a b_j and p_j=u_1...u_j form a free m-tuple. Let p_0=e and
w_m=p_m a. All letters are positive, so

    |w_m| = m(2r+1)+1.

Set T_m=1+sum_{j=1}^m lambda(p_j), Q_m=T_m T_m^*. With only h_1=h
and all other generator cocycle values zero, the prefix rule gives
D_{w_m}=T_m h. This identity is exact because every b_j uses only x_2,x_3.

## Exact spectrum and sharp prefix-count law

The trace law of Q_m is supported on [0,4m] and has density

    f_m(x)=(m+1) sqrt(4m-x) /
             [2 pi sqrt(x) ((m+1)^2-x)],   0<x<4m.

There is no atom. For m=1 the cancellation in this expression gives the
arcsine square law 1/[pi sqrt(x(4-x))]. One direct identification is to add
a free Haar unitary U_0 and multiply T_m on the left by it: U_0 and
U_0 V_j form a free (m+1)-tuple by a free-group basis change. Thus singular
values are those of a sum of m+1 free Haar unitaries. Their symmetrization
is the Kesten law of the (m+1)-regular tree. This can also be checked by
counting alternating words, which are closed walks on that tree.

The Stieltjes quantity at a positive real lambda is

    R_m(lambda)=tau((Q_m+lambda)^(-1))
      =2m / [sqrt(lambda) ((m-1)sqrt(lambda)
                           +(m+1)sqrt(lambda+4m))].

For h_0=T_m^*(Q_m+1)^(-1)e, exact identities give

    ||h_0||_2^2=tau(Q_m(Q_m+1)^(-2)),
    ||T_m h_0-e||_2^2=tau((Q_m+1)^(-2)),
    their sum = R_m(1) <= 1/sqrt(m).

Consequently m=ceil(16 eta^(-4)), 0<eta<=1/2, gives each norm at most
eta/2. Moreover as m tends to infinity the two squared quantities are
both (1+o(1))/(2sqrt(m)). Thus the minimum prefix count allowing BOTH
norms at most eta is (1/4+o(1)) eta^(-4). The matching necessity follows
from the exact variational identity

    inf_h [||h||_2^2+||T_m h-e||_2^2] = R_m(1),

which is obtained by completing the Hilbert-space square. If both norms
are <=eta then R_m(1)<=2eta^2; since R_m(1)~1/sqrt(m), this implies
the stated asymptotic. This holds for arbitrary L2 vectors h, not merely
the chosen resolvent vector. It does NOT lower-bound arbitrary cocycle
witness words outside this free-prefix construction.

## Stronger exact finite rational coefficients: radial tree polynomials

The independent Kesten audit supplied this sharper finite construction,
which supersedes the geometric resolvent approximation below. Let d=m+1,
and define polynomials in a formal self-adjoint variable t by

    F_0(t)=1, F_1(t)=t, F_2(t)=t^2-d,
    F_j(t)=t F_{j-1}(t)-m F_{j-2}(t)  (j>=3).

F_{2j}(t) is an even polynomial, so F_{2j}(sqrt(Q)) below means an
ordinary polynomial in Q, not a square-root oracle. For an integer r>=1,
put K_r=1+rd/m and

    q_r(Q)=K_r^-1 [1+sum_{j=1}^r (-1)^j m^-j F_{2j}(sqrt(Q))],
    h_r=T_m^* [(1-q_r(Q_m))/Q_m]e.

The quotient is polynomial: F_{2j}(0)=(-1)^j d m^{j-1}, hence q_r(0)=1.
It has degree r-1 and real rational coefficients. The exact identities are

    ||T_m h_r-e||_2^2 = m/(m+rd),
    ||h_r||_2^2 = d r(r+1)(2r+1)/[6(m+rd)^2].

Proof mechanism: hermitize T_m as H=[[0,T_m],[T_m^*,0]]. The connected
root component of its labelled graph is the d-regular tree, since the
p_j are free. F_l(H)e is the indicator vector of the level-l sphere;
the sphere has d m^(l-1) vertices for l>=1. The residual vector has at
each even level 2j the coefficient (-1)^j/(m^j K_r), with level-zero
coefficient 1/K_r. The h-vector has at each odd level 2j-1, 1<=j<=r,
the coefficient (-1)^(j+1)(r-j+1)/(m^j K_r). Apply H at each even level:
the parent contributes the adjacent odd-level coefficient and the m
children contribute m times the next one. This equals e-q_r(H)e.
The displayed squared norms follow by multiplying coefficient squares
by sphere sizes and using sum_{j=1}^r j^2=r(r+1)(2r+1)/6. This gives an
exact finite coefficient verification without asymptotic approximation.

For rational 0<eta<=1/2 choose

    r=ceil(eta^-2),
    m=max(2, ceil[(r+1)(2r+1)/(6r eta^2)]).

Then residual squared <1/(r+1)<=eta^2, and norm squared is at most
(r+1)(2r+1)/(6rd)<eta^2. Thus both norms are strictly less than eta.
As eta tends to zero, r~eta^-2 and m~(1/3)eta^-4. This is within a
factor 4/3 of the asymptotically optimal prefix count with unrestricted
L2 coefficients, and is completely finite with rational coefficients.

With compact binary prefixes the absorption word has length
O(eta^-4 log(1/eta)); coefficient support-word radius is at most
(2r-1)m(2ceil(log_2 m)+1)=O(eta^-6 log(1/eta)). The expanded support is
exactly d sum_{j=1}^r m^(2j-2) on the odd spheres, and is at most
(4/3)d m^(2r-2) for m>=2. It remains
astronomical. Compact polynomial degree r-1 is O(eta^-2). No claim of
efficient expanded output or numerically stable physical execution follows.

The radial/Christoffel construction is classical orthogonal-polynomial
technology composed with the released Fox-cocycle mechanism. No priority
claim is made for this composition without a fuller literature audit.

## Independent fallback: geometric resolvent coefficients

Assume eta is positive rational. m=ceil(16 eta^(-4)) is an integer. Let
c=4m+1, q=1-1/c, and choose any integer N with
q^(N+1)<=eta/(16m), e.g.

    N=ceil(c ln(16m/eta)).

One can choose a larger N using rational repeated squaring, avoiding a
real logarithm oracle. Define the rational group-ring polynomial

    P_N(Q)=(1/c) sum_{j=0}^N (1-(Q+1)/c)^j,
    h_N=T_m^* P_N(Q_m)e.

This has finite real rational coefficients. For 0<=x<=4m, the geometric
sum error from (x+1)^(-1) is at most q^(N+1). Since ||T_m||=2sqrt(m),

    ||h_N-h_0||_2 <= 2sqrt(m) q^(N+1) <= eta/(8sqrt(m)),
    ||T_m(h_N-h_0)||_2 <= 4m q^(N+1) <= eta/4.

Hence ||h_N||_2<eta and ||T_m h_N-e||_2<eta. This is an explicit
finite-coefficient replacement for the release's cutoff and arbitrary
finite-support approximation.

Costs: m=O(eta^-4), |w_m|=O(eta^-4 log(1/eta)),
N=O(eta^-4 log(1/eta)). The support-word radius is at most
(2N+1)m(2r+1)=O(eta^-8 log^2(1/eta)). The raw expanded support bound is
(m+1)^(2N+1), which is enormous. The coefficient vector admits a compact
rational group-ring circuit. No polynomial bound in expanded output size,
numerical stability, ODE precision, or complete-isomorphism acquisition is
claimed. Coefficient bit length can grow with N and log c.

## Consequence under the released flow theorem

For a completed free Haar tuple (A_1,...,A_n,C), n>=3, insert the h_r and
w_m above into the source flow, taking eta<epsilon/K. The source proof
then provides a normal trace-preserving automorphism alpha with

    max_j ||alpha(A_j)-A_j||<epsilon,
    ||alpha(A_{w_m})-C||<epsilon,

with an explicit witness word of length O(epsilon^-4 log(1/epsilon))
and explicit finite rational coefficient data for the flow. This sharply
reduces the original prefixes' word length m^2+3m+1 and removes their
non-effective spectral choice. The normal/Borel functional calculus and
ODE execution remain part of the legal interface; the result is not an
efficient rational-matrix realization of the factor isomorphism.

## Failure ledger and consequence boundaries

1. Unbounded free entropy dimensions are already in the release; do not
   present them as a new result of this work.
2. Taking b_j=x_2^j would be invalid: the resulting u_j=a x_2^j generate
   a subgroup of rank at most two, so the prefixes are not a free m-tuple
   for large m. The squared fixed-length binary code avoids this defect.
3. Uniform coefficient/support/numerical-computation costs do not follow
   merely from a normal isomorphism or a finite group-ring formula.
4. The sharp eta^-4 prefix-count lower bound does not rule out a better
   witness using a different word/Fox derivative family.
5. Only the source sections listed above were read; this does not certify
   every line of the complete release, its Lean scope, or its priority.
6. A generic orbit-closure consequence below is topological, not a group
   ring direct-finiteness or hyperbolic-group transfer.
7. The companion source audit found an apparent squared-binomial typo in
   the 2011 Appendix A (A3) moment display. The density (A5)-(A6), the
   original Haagerup-Larsen formula, the independent tree proof, and exact
   word-moment diagnostics agree. No step here relies on the suspect
   displayed moment formula.

Independent final audit: `kesten_audit/AUDIT.md`; primary-source locations
and prior-art notes: `kesten_audit/primary_law_sources/LAW_AUDIT.md`.
Diagnostics: `check_compact_cocycle.py` and `diagnostics.json` (62,152
finite reduced code words, 16 exact word moments, 16 expanded rational
radial-polynomial cases, 7 geometric-polynomial cases, 6 quadrature cases).
These diagnostics are scoped cross-checks, not certification of general
mathematics or of the released von Neumann algebra construction.

## Additional topological consequence (conditional)

Let M=L(F_{n+1}), n>=3, let A be its canonical first n Haar unitaries,
and X be the operator-norm closure in U(M)^n of {alpha(A):alpha in Aut(M)}.
X is complete, and all its tuples have the free Haar joint law. Then
the set G={U in X: W*(U)=M} is a dense G_delta in X.

Proof of G_delta: fix a countable L2-dense family y_j in M, and write
G as the intersection, over j and positive integers k, of the unions over
rational complex word polynomials P of
{U: ||P(U)-y_j||_2<1/k}. Every displayed set is norm-open. The equality
follows from L2-density and the trace-preserving conditional expectation.
For density, source generation.tex's iteration can start at any orbit
tuple and choose its initial future budget arbitrarily small; the limiting
generating tuple remains within that budget. Since the orbit is dense in
X, generating tuples are dense in X. Baire then gives the statement.

Every actual orbit tuple generates the proper infinite-index free-factor
subalgebra alpha(L(F_n)); hence the orbit is disjoint from G and meagre.
In particular operator-norm convergence of a finite Haar tuple does not
make W*-generation stable, even with exactly fixed joint distribution.
No claim is made about all free Haar tuples in M, only this specified
orbit closure. Prior art for this exact topological formulation remains
unsettled. Shlyakhtenko's September 2026 paper below already proves the
analogous residual-generation statement in a constrained L2 orbit closure
(Proposition 1), so this is a routine adaptation to the stronger released
norm perturbation, not a credible independent major advance.
Voiculescu's Cyclomorphy (2002) also discusses orbit closure and its
connection to the free group factor problem.

## Separately verified changed-premise lead for the parent

Primary source: D. Shlyakhtenko, On the II1 Factors of Fuchsian Groups,
arXiv:2609.11074v1, submitted September 10 2026,
https://arxiv.org/html/2609.11074v1.
Theorem 1 and Corollary 1 assert that every finitely generated torsion-free
non-elementary discrete PSL2(R) subgroup has a free group factor, including
L(pi1 Sigma_g)=L(F_{2g-1}) for closed orientable genus g>=2. Its key
Theorem 3 freely complements the commutator MASA of L(F2). Theorem 1
also includes certain groups with torsion (g>=2 or g>=1,k>=2).
This was verified at the actual arXiv HTML, not solely an aggregator.
It has NOT received a full proof audit here. Composing it with family287
would give the same common free factor for the named Fuchsian groups;
that is a conditional standard composition, not a new theorem claimed
by this worker. It gives no group-ring direct-finiteness result.
