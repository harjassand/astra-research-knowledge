# The N06/N27 rank obstruction does not lift by changing the matrix metric

Date: 2026-10-07. Scope: unitary and general-linear transfers of the moved-grid permutation rank certificate. These are local barrier results, conditional only where explicitly marked. They neither construct hyperlinear microstates of the whole group nor prove that the N06/N27 candidate is hyperlinear or linear-sofic. They also do not certify the candidate's incidence/geometry theorem.

## Outcome

The permutation theorem has three essential inputs: a trace moment bound supplied by almost fixed-point-free rectangles; an integral bounded-row minor estimate transferring real rank to one fixed finite characteristic; and a finite-characteristic rank-one interpolation identity. A Hilbert–Schmidt replacement loses the second input. Rank-distance separation loses the first input even when every assigned block is unitary. The third input has no exact complex replacement of the same rank budget: evaluating the exact relations in the group's regular representation rules it out. The last assertion has a quantitative extension ruling out arbitrarily accurate complex rank-one lifts with bounded total interpolation residual.

The two new direct derivations in this note are the SU(2) local counterexample and the conditional complex-certificate no-go theorem. Priority for these exact formulations has not been established. They are elementary barrier lemmas rather than a historical-scale positive group theorem.

## Sources and exact interface

Astra snapshot: `778b78af5d4bbde608ce3fc775049ceaeb55a2d3`. The source manifest pins the downloaded pages by SHA256. The Astra pages cite OpenAI mathematics snapshot `adc7f1241b42e322a6451854ab7e4b4c146bf78a`.

* [N06 card](https://raw.githubusercontent.com/harjassand/astra-research-knowledge/778b78af5d4bbde608ce3fc775049ceaeb55a2d3/cards/N06-nonsofic-hyperbolic.txt): permutation-only statement and original scalar/HS blockers.
* [N27 card](https://raw.githubusercontent.com/harjassand/astra-research-knowledge/778b78af5d4bbde608ce3fc775049ceaeb55a2d3/cards/N27-h5-nonsofic-refinement.txt): moved-grid D(5,q) refinement, `r=1,200,000`, `q=2^61−1`, no unitary/linear transfer.
* [Exact rank audit](https://raw.githubusercontent.com/harjassand/astra-research-knowledge/778b78af5d4bbde608ce3fc775049ceaeb55a2d3/web/pages/d-0415d12ee81adc66.html), §§1–6: finite interface, trace moments, fixed-prime minor bound, Cartesian factorization, interpolation identity, defect accounting.
* [Groups approximation scout](https://raw.githubusercontent.com/harjassand/astra-research-knowledge/778b78af5d4bbde608ce3fc775049ceaeb55a2d3/web/pages/d-9aff31ed5c66dd0b.html), “Failed transfers retained”: original GL scalar counterexample and phase/rank counterexample.
* [Mallahi-Karai–Mohammadi Yekta](https://arxiv.org/html/2112.10111v2), Definition 1.1 and Theorem A: linear-sofic approximations use normalized rank; characteristic-zero torsion-free groups can amplify separation toward 1. This says nothing about the required rank of a block array. The local counterexample below already has separation exactly 1.
* [Pestov notes](https://www.math.cmu.edu/~eschimme/Appalachian/PestovNotes.pdf), §3 equation (3.2), §4 Definition 4.1: normalized Hilbert–Schmidt unitary metric and hyperlinear matrix models. Only these definitions are used; historical open-problem statements in the notes are not used as current status.
* [Nayak, A framework for rank identities](https://arxiv.org/abs/1801.08072): finite von Neumann algebras support rank systems. The necessary properties and the trace estimate are proved directly below.

Finite data comprise `r≥2`, `N` labels, `m` points, exceptional set `E`, incidence sets `I(z)`, and two Cartesian blocks at every regular point. For each block `b`, label `i` is bijective with `(α_b(i),β_b(i))∈Z/s_b×Z/t_b`. The triangles prescribe

`X_iuv = L_b,u,α(i)+v^−1 R_b,v,β(i)+u`.

The nondegenerate rectangles are

`w_i,u,u′,v,v′ = X_iuv X_iu′v^−1 X_iu′v′ X_iuv′^−1`.

For permutations, small triangle Hamming error `δ` and rectangle fixed-point fraction `λ` imply

`Δ = Nr/4−2m−r|E| ≤ r²(S_inc δ+Nλ/8)`.

The supplied positive-gap input has `Δ>0`. No change of `r`, `q`, or moved-grid acquisition removes the metric/field issues below.

## 1. Full rectangle rank separation fails even inside SU(2)

Choose pairwise distinct `a_1,…,a_r` and pairwise distinct `b_1,…,b_r` on the unit circle. Define

```
             1 [ a_u       b_v    ]
X_uv =  --------[                  ] .
           √2 [ −conj(b_v) conj(a_u)]
```

Each `X_uv` belongs to `SU(2)`. Indeed its two columns are orthonormal and its determinant is `( |a_u|²+|b_v|² )/2=1`.

Write `X_uv=(A_u+B_v)/√2`, where

```
A_u = diag(a_u,conj(a_u)),
B_v = [[0,b_v],[-conj(b_v),0]].
```

The full `2r×2r` block array `Y=(X_uv)` is the sum of a block column times the common block row `(I_2,…,I_2)`, and the common block column `(I_2,…,I_2)^T` times a block row. Therefore

`rank_C Y ≤ 2+2=4=2D`, with `D=2`.

In fact equality holds for `r≥2`. Differences of two block columns span the two-dimensional constant-block subspace, since `B_v−B_v′` is invertible. The stacked `A_u` column has a two-dimensional range disjoint from that subspace, since `A_u−A_u′` is invertible. Together these subspaces span the range of `Y`.

For `u≠u′`, put `P_v=X_uv X_u′v*`. A direct multiplication gives

```
       1 [a_u conj(a_u′)+1       b_v(a_u′−a_u)       ]
P_v =  - [                                            ] .
       2 [conj(b_v)(conj(a_u)−conj(a_u′)) conj(a_u)a_u′+1]
```

The rectangle is `W=P_v P_v′*`. Since `a_u′−a_u≠0`, `P_v=P_v′` is equivalent to `b_v=b_v′`. Thus every nondegenerate rectangle is nonidentity. A nonidentity element of `SU(2)` has no eigenvalue 1: its eigenvalues have product 1, and if one were 1 then both would be 1 and unitary diagonalizability would force the matrix to be identity. Consequently

`rank_C(I_2−W)=2`,

so **all** rectangles have normalized rank separation 1, while the block array has rank at most `2D` for arbitrarily large `r`. Tensor each block with `I_k` to obtain the same conclusion for every even `D=2k`.

Already `r=5,D=2` gives block rank `4`, below the false permutation trace lower bound `r²D/(2r−1)=50/9`. This refutes the replacement “full rank rectangle separation ⇒ the permutation lower bound” even for unitaries.

For clarity, the correct normalized trace of a rectangle is

`tr_2(W)=1−|a_u−a_u′|²|b_v−b_v′|²/8`,

and

`||I_2−W||_(2,tr)=|a_u−a_u′||b_v−b_v′|/2`.

All phases can be placed in arbitrarily short arcs. Then every rectangle stays rank-distance 1 from identity while its Hilbert–Schmidt distance tends uniformly to zero. The valid unitary trace-moment estimate is therefore consistent with this example; rank separation alone does not supply its hypothesis.

This is a counterexample to a local replacement lemma. The blocks do not claim to satisfy every triangle of the entire N06/N27 incidence presentation.

The supplied scalar counterexample also covers the source's fixed finite characteristic. Over `F_q`, take `a_u=u` and `b_v=r+v`, for `1≤u,v≤r`, provided `q>3r`. Then `X_uv=(a_u+b_v)I_D` is invertible, the full array has rank at most `2D`, and the rectangle ratio differs from 1 because its cross-product numerator is `(a_u−a_u′)(b_v′−b_v)≠0`. Thus `rank(I_D−W)=D` for every nondegenerate rectangle. N27's fixed `q=2^61−1` and `r=1,200,000` meet `q>3r`. In rank-metric linear approximations, the triangle error rank charge itself is valid; this lower-rank failure is the decisive remaining blocker even when the field/interpolation certificate is retained.

## 2. Hilbert–Schmidt triangle errors cannot be charged as algebraic rank

For any `D≥1` and `t∈(0,2π)`,

`U=e^(it) I_D`, `V=I_D`

obey

`||U−V||_(2,tr)=|e^(it)−1| →0`,

but

`rank(U−V)/D=1`.

Thus there is no dimension-independent function `f(δ)→0` such that normalized algebraic rank of a unitary difference is at most `f` of its normalized Hilbert–Schmidt norm. This invalidates exactly §4's moved-column rank charge after a metric substitution. A spectral truncation creates a small-norm residual; it does not convert that residual into finite-field rank.

## 3. Conditional no-go for characteristic-zero interpolation at the same rank budget

**Hypotheses.** Let a group `G` admit the finite exact edge/triangle data above, with every displayed nondegenerate rectangle nonidentity. Let `R=2m+r|E|`. Then complex matrices `H(z)∈M_N(C)` of rank at most one cannot satisfy

`Σ_(z:i∈I(z)) H(z)=−E_ii` for all labels `i`

whenever

`R < N r²/(2r−1)`.

In particular they cannot exist for the N06/N27 positive-gap budget `Δ>0`, since that gives `R<Nr/4 <Nr²/(2r−1)`.

**Proof.** Work in the group von Neumann algebra `L(G)` with canonical trace `τ(λ(g))=1_(g=e)`. On `M_k(L(G))` use the unnormalized matrix trace `Tr_k⊗τ`, and define support rank `rk_τ A` to be the trace of its range support projection. A block of inner dimension one over `L(G)` has support rank at most one. Support rank is subadditive because the range of a sum lies in the closed span of the individual ranges; polar decomposition identifies right and left support dimensions. Direct sums add support rank. Tensoring with a scalar complex matrix multiplies support rank by its ordinary rank, as scalar singular-value decomposition shows.

Evaluate every edge in the left regular representation. For `Y_i=(λ(X_iuv))_(u,v)` and `T_i=Y_iY_i*`, exact unitarity and nontriviality of rectangles give

`(Tr_r⊗τ)(T_i)=r²`,

`(Tr_r⊗τ)(T_i²)=2r³−r²=r²(2r−1)`.

The second identity is the same block expansion as the permutation audit, but each nondegenerate rectangle has canonical trace zero. If `p_i` is the support of `T_i`, then Cauchy–Schwarz gives

`r^4=τ(p_iT_i)^2 ≤τ(p_i)τ(T_i²)`.

Therefore `rk_τ Y_i≥r²/(2r−1)`.

Put `Z(z)=Σ_(i∈I(z))Y_i`. At a regular point, each of the two Cartesian block sums factors through one copy of `L(G)`, exactly as in the source's §4; hence `rk_τ Z(z)≤2`. At an exceptional point, the ambient `r×r` block size gives `rk_τ Z(z)≤r`. Thus the tensor sum `B=Σ_z H(z)⊗Z(z)` has support rank at most `2m+r|E|=R`.

The proposed interpolation identity gives

`B=−⊕_i Y_i`.

Taking support ranks yields

`N r²/(2r−1) ≤R`,

contradicting the hypothesis. ∎

This proof uses the exact regular representation, which every discrete group possesses, and does not assume hyperlinearity. It proves that the needed complex coefficient certificate is impossible; it does **not** prove that the regular representation has finite-dimensional unitary approximants. The finite-characteristic identity escapes this contradiction precisely because `F_q` does not act as complex scalar coefficients in a finite tracial von Neumann algebra.

If the source is formulated with edges between different vertices, choose base paths from one base vertex and evaluate the resulting based loops. A triangle relation stays an exact relation, and a rectangle becomes conjugate to its original closed square, preserving nontriviality and canonical trace. This is the same conversion recorded in the supplied frontier algebra source's core discussion.

## 4. A quantitative floor for approximate complex lifts

Under the same exact group hypotheses, allow arbitrary rank-at-most-one complex `H(z)` and define

`K_i=E_ii+Σ_(z:i∈I(z)) H(z)`.

Set `A=⊕_i Y_i`, `B=Σ_z H(z)⊗Z(z)`, and `S=Σ_i K_i⊗Y_i`. The distributive identity is

`B=−A+S`.

The preceding factorization still gives `rk_τ B≤R`. Let `p` be the range support of `B`; use `T=AA*`. Since `(1−p)B=0`,

```
||S||_2² = ||A+B||_2²
         ≥ ||(1−p)A||_2²
         = τ(T)−τ(pT)
         ≥ Nr²−√[R·Nr²(2r−1)].
```

Here `τ(T)=Nr²`, `τ(T²)=Nr²(2r−1)`, and the last inequality is Hilbert–Schmidt Cauchy–Schwarz. On the other hand scalar tensoring and the triangle inequality give

`||S||_2 ≤r Σ_i ||K_i||_F`.

Consequently

`Σ_i ||K_i||_F ≥ √[N−√(RN(2r−1))/r]`,

whenever the expression is positive. For the source's positive-gap regime `R<Nr/4`, this gives the simpler strict bound

`Σ_i ||K_i||_F > √[N(1−1/√2)]`.

Thus a fixed positive-gap finite incidence system admits no sequence of complex rank-one interpolation coefficients with total Frobenius interpolation residual tending to zero. This blocks an approximate characteristic-zero coefficient lift at the same global rank budget as well as an exact one. It does not rule out a genuinely different certificate with different local factorizations, coefficient rank budget, or finite-dimensional invariants.

## Checks, failures, and next attack

`local_unitary_checks.py` passed exact rational-complex checks for `r=5,D=2`: 25 SU(2) blocks, block-array rank exactly 4, all 400 nondegenerate rectangle differences of rank 2, and all 400 trace formulas. Phases use the rational unit-circle parametrization `(1+it)/(1−it)`; no floating-point eigenvalue threshold is used. These checks catch transcription errors and do not replace the universal algebraic derivation.

An independent subagent completed a direct proof audit in `verify_local_no_go/report.txt`, finding both derivations valid under the stated exact hypotheses and unnormalized trace convention. Its separate exact `Q(i)` fixtures at `r=4,6` checked block-array rank 4, all 1,044 rectangle differences of rank 2, and the trace formula. It also checked the basepoint/groupoid gauge issue. This review remains an internal mathematical check rather than external certification.

Failure ledger:

1. HS defect to algebraic rank: scalar phases have vanishing norm defect and full rank defect.
2. Rectangle rank separation to large array rank: the additive SU(2) array has all rectangle rank separations exactly 1 and array rank at most `2D`.
3. Characteristic-zero rank-one lift at the same rank gap: impossible under exact triangle/nontrivial-rectangle hypotheses by the regular-representation argument.
4. Approximate such lift: a fixed explicit residual floor survives, so making coefficient residuals arbitrarily small cannot repair the mechanism.
5. Whole-group hyperlinear or linear-sofic model: not acquired; none of these local counterexamples is such a model.

The strongest next attack is to identify a property of finite matrix tracial algebras that fails for the particular regular `L(G)` representation and is robust in normalized Hilbert–Schmidt norm. A mere trace moment, support-rank inequality, or rank-one scalar interpolation identity valid in every finite von Neumann algebra cannot do this job. For linear soficity, a replacement array lower bound must use genuinely more than full rectangle rank separation; Theorem A's separation amplification alone is insufficient. No such replacement has been found here.
