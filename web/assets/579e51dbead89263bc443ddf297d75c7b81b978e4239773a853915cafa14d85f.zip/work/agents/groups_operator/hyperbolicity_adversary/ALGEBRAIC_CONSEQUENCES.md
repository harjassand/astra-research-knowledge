# Exact algebraic consequences of the proposed witness

These are elementary deductions for any nonzero unital F2-algebra `R` with elements `a,b,c` satisfying `ab=1`, `ac=0`, and `c!=0`. For the group candidate they remain conditional on acquiring the released construction. They do not validate that construction.

Set `e=1-ba`. Then:

```
e^2=e,
a e=0,
e b=0,
e c=c.
```

In particular `e!=0`; also `e!=1`, because `ba=0` would imply `1=(ab)^2=a(ba)b=0`.

## A nonzero projective module invisible to K0

The right module `P=eR` is nonzero, cyclic, and projective, since it is the image of the idempotent endomorphism `r -> er` of `R_R`. The maps

```
Phi: R -> R ⊕ P,       Phi(r)=(ar,er),
Psi: R ⊕ P -> R,       Psi(s,p)=bs+p
```

are inverse right-module isomorphisms. Indeed `a p=0`, `e b=0`, and `e p=p`, while `ba+e=1`. Consequently

```
R ≅ R ⊕ P,
[P]=0 in K0(R),
P != 0.
```

Thus a calculation `K0(R)=Z` does not conflict with the witness. The projective-module monoid need not cancel even when its group completion has the expected value. For `R=F2[G]`, augmentation sends `e` to zero, so `P` also vanishes after tensoring with the augmentation module F2.

## Universal finite-dimensional invisibility in characteristic two

Let `K` be any field of characteristic two and let `rho:R -> M_d(K)` be any unital F2-algebra homomorphism. Since `rho(a)rho(b)=I_d`, finite-dimensional matrix algebra gives `rho(b)rho(a)=I_d`. Therefore `rho(e)=0`.

For a group algebra this applies to every finite-dimensional group representation over every field of characteristic two. The nonzero algebra element `e` belongs to the intersection of the kernels of all such representations extended linearly to `F2[G]`. This is an algebra element, not a claimed single group word in every kernel.

## Matrix units of every finite size

For integers `i,j>=0`, define `E_ij=b^i e a^j`. Then

```
E_ij E_kl = delta_jk E_il.
```

If `j<k`, use `a^j b^k=b^(k-j)` and `e b=0`; if `j>k`, use `a^j b^k=a^(j-k)` and `a e=0`; if `j=k`, use `a^j b^j=1` and `e^2=e`. Every `E_ij` is nonzero because `a^i E_ij b^j=e`.

They are linearly independent: multiplying a finite linear relation on the left by `e a^r` and on the right by `b^s e` isolates its `(r,s)` coefficient times `e`. Over F2 a nonzero scalar cannot annihilate nonzero `e`.

Hence the finite-support infinite matrix algebra over F2 embeds in `R` as a nonunital subalgebra. Each finite upper-left block gives an embedded `M_k(F2)` with its own unit `sum_{i<k} E_ii`; that unit is not asserted to equal `1_R`. In particular `R` contains arbitrarily many nonzero pairwise orthogonal idempotents. No claim of proper infiniteness of `1_R` follows from this calculation alone.

For the candidate group all of these deductions coexist with characteristic-zero idempotent theorems because the construction and its parity witness have characteristic two.

## The entire universal Jacobson algebra embeds

Let `J=F2<x,y | xy=1>`, and consider the homomorphism `J -> R` given by `x -> a`, `y -> b`. It is injective whenever `e=1-ba!=0`.

First, the rewriting rule `xy -> empty` is terminating and confluent. It shortens words, has no overlapping ambiguity with itself (its last letter is `y`, its first letter is `x`), and disjoint reductions commute. Its irreducible words are exactly `y^i x^j`, `i,j>=0`. They consequently form a vector-space basis of `J`.

Let `z=sum c_ij y^i x^j` be any nonzero element in this normal form, and let `n` be the least column index `j` for which some `c_ij!=0`. Put `epsilon_J=1-yx`. Then

```
z y^n epsilon_J = sum_i c_i,n y^i epsilon_J.
```

Terms with `j>n` vanish because `x^j y^n epsilon_J=x^(j-n)epsilon_J=0`; there are no nonzero terms with `j<n`. Under the homomorphism this right side becomes `sum_i c_i,n b^i e`, a nonzero linear combination of the already established independent matrix units `E_i0`. Hence the image of `z` is nonzero. The kernel is zero.

This also gives the essential-ideal argument requested by the parent: the ideal of `J` spanned by `y^i epsilon_J x^j` is the finite-support matrix ideal. For any nonzero `z`, the product above is a nonzero element of that ideal, so every nonzero ideal meets it. The matrix ideal is simple: left and right multiplication by matrix units isolates a nonzero coefficient and produces every matrix unit. An ideal containing a nonzero matrix-ideal element therefore contains `epsilon_J`. Since its image `e` is nonzero, the representation kernel cannot be such an ideal.

Thus the candidate group algebra contains the full universal one-sided-inverse algebra as a UNITAL F2-subalgebra, whereas its matrix ideal embeds nonunitally. This distinguishes the two units correctly: `1_J` maps to `1_R`; each finite matrix corner has unit `sum_{i<k} E_ii`.
