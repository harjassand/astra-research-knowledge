# Audit of the disk extension

Status: the proposed disk extension survives this audit as a deterministic conditional theorem. Combined with release197's bounded-pattern estimate, algebra and torsion construction, it yields a conditional torsion-free hyperbolic direct-finiteness counterexample over F2. It does not independently establish a new group example or validate the release. The earlier claimed Farrell–Jones incompatibility is expressly WITHDRAWN after exact primary-source tracing. No exact erroneous line inside the released bounded-pattern proof has been identified here.

## Exact conclusion

Assume the finite immersed graph has the source's short-closure property, girth and diameter hypotheses, and excludes the single fixed bounded-pattern triple `(K0,C,I)` chosen in `planar.tex:299–305`. Then its cone group has a linear Dehn function. It suffices to use the source's original triple; a larger triple or changed order of quantifiers is unnecessary.

This is stronger than merely assuming absence of fully paired reduced spherical arrangements. That latter property alone is not what this proof uses.

## Fixed-boundary surgeries

For an arbitrary nonempty cyclically freely reduced rose nullword `w`, the proof of picture representation (`topology.tex:55–105`) supplies a cone picture even though the lemma's disk statement mentions an outer graph lift. Its proof only needs a prescribed rose boundary word; the graph lift is used later for exterior surgery.

Minimize total INNER graph-boundary length `H`, with the exact rose boundary `w` fixed. Cyclically tighten inner loops and remove constant disks. A nonempty freely reduced `w` ensures an inner disk remains. General position pairs all letter occurrences by arcs.

The two internal same-edge surgeries of `topology.tex:200–208,231–243` still apply:

- Different inner disks merge in their common abstract cone. Their boundary length drops by two.
- A band from an inner disk to itself produces an annulus. Keep the complementary component containing the exterior boundary, cap the new inner boundary in the same abstract cone, and discard the other component. The retained picture fills exactly `w`; its total inner length drops by at least two.

Both surgeries use only the inner graph lifts. They do not use an outer graph lift, an exterior surgery, or an assumption that a cone embeds in `X`. Consequently every pairing with both ends on inner boundaries traverses distinct underlying graph edges.

## Paired intervals with an arbitrary exterior

The paired-interval proof (`planar.tex:143–230`) uses graph immersion on a disk boundary only through cyclic free reduction of its label word. That condition excludes disk monogons and self-paired consecutive runs. It does not use the graph identities of paired edges. All inner words and the exterior word are cyclically freely reduced. Thus include the exterior as one additional disk in that proof, with one prescribed indexing gap and one intact designated piece.

If there are `N` internal pieces, all pairings are organized into at most `6(N+1)` interval pairs. Deleting the exterior deletes whole interval pairs and creates at most `|w|` unpaired INNER occurrences. Outer–outer arcs create no extra internal loss. No hypothesis `|w| <= H/L` is needed.

## Exact source constants suffice

Write `ell=|w|` and use the source epsilon, with `0<epsilon<=1/4`. Every resulting inner path is closed and cyclically immersed. Each has at least `L` original occurrences: intact loops by girth, split pieces by their `UL/3` lower bound and `U>=3`. Hence `NL<=H`, and `N>=1`.

The source choices imply:

```
closure overhead A <= 3 D0 H/U <= epsilon H/32,
deleted original length M <= eta N U L <= eta U H <= epsilon H/64,
retained comparisons <= 6(N+1) <= 12N <= 12H/L.
```

If `ell <= epsilon H/64`, the surviving clusters therefore satisfy:

```
sum H_Z >= H-M >= 63H/64,
H_Z <= K0(U+D0)L = C L,
sum b_Z <= ell+M+A <= epsilon H/16,
sum I_Z <= 12H/L.
```

Discarding clusters with `b_Z>epsilon H_Z` costs at most `H/16`. Discarding those with `I_Z>192H_Z/L` costs at most another `H/16`. At least `55H/64` of cluster length remains. Every such cluster already has length at least `L`, because it contains a positive closed cyclically immersed graph path. There is no exceptional sub-`L` cluster. A surviving cluster satisfies precisely the source fixed triple and gives the forbidden system. Therefore `H < 64 ell/epsilon`.

Closures remain wholly unpaired, so their repeated graph edges do not affect the distinct-edge comparison condition. Piece splitting preserves the planar embedding by the source sector argument (`planar.tex:364–371`). Comparison intervals are retained or deleted whole.

## Conversion to ordinary finite Dehn area

Independently checked by subagent `dehn_conversion` (its proof is in `dehn_conversion/AUDIT.md`). Choose a tree and basepoint in every graph component and add to the rose one fundamental-loop relator for every non-tree edge. This is a finite presentation of the cone group. A closed graph loop of length `h` decomposes, by inserting the tree paths at its successive vertices, into at most `h` conjugates of those relators. Thus its finite-presentation area is at most `h`. The punctured-disk exterior maps to the rose and contributes zero relation cells. Consequently `Area(w)<=H <64 ell/epsilon`.

One can equivalently fan each inner loop to its cone apex with exactly `h` cone triangles; radial spokes are actual cone one-cells. Arbitrary connector lengths add no relation cells. Freely/cyclically reducing an arbitrary rose nullword, then adding conjugating whiskers, adds no relation cells. The inequality therefore holds for all nullwords.

## Withdrawn compatibility argument

The earlier version quoted the prime-characteristic introductory bullet of the [Bartels–Lück–Reich paper](https://www.maths.ed.ac.uk/~v1ranick/papers/blr.pdf), Applications on PDF page 5, as an established no-idempotents obstruction. That claimed contradiction is WITHDRAWN. Exact tracing through the authors' applications paper and its cited proofs does not acquire the needed positive-characteristic implication. This is a proof-source limitation in this audit; it is not presented as a correction to BLR itself.

The cited [Formanek1973 paper](https://doi.org/10.4153/CJM-1973-037-6), printed pages366–369, has Theorems1 and9 in characteristic ZERO. Its modular Lemma7 only makes nonidentity conjugacy-class trace sums vanish. Burger–Valette's Lemma4.1 obtains modular coefficient trace in `{0,1}`; Proposition4.2 then proves a complex idempotent conclusion using Kaplansky's characteristic-zero positivity theorem. These proofs do not turn modular trace zero into a zero idempotent. Independently checked local primary copies are `work/agents/group_source_audit/primary_fj/formanek1973.txt` and `vallat.ps:2248–2375`.

BLR applications Theorem0.12 (`blr_applications_latest.txt:288–300`) requires stable finiteness, characteristic-zero coefficients, or soficity to infer no idempotents from its rational K0 isomorphism. Its Lemma5.4 retains the stable-finiteness hypothesis. Thus `K0(F2[G])=Z` by itself does not veto the candidate.

The release's parity witnesses still have `ab=1`, `ac=0`, and `c!=0` (`algebra.tex:56–118`), so `ba!=1`. The idempotent `ba` cannot be zero: `ba=0` would give `1=(ab)^2=a(ba)b=0`. Therefore `e=1-ba` is a nontrivial scalar idempotent. Without an independently acquired positive-characteristic no-idempotents theorem, that is an additional conditional counterexample consequence, not a compatibility contradiction.

For an explicit explanation of the K0 gap, `P=eR`, with `R=F2[G]`, is a nonzero finitely generated projective right module. The maps `r -> (ar,er)` and `(s,p) -> bs+p` give `R ≅ R ⊕ P`. Hence `[P]=0` in K0 although `P!=0`. This identity is fully consistent with `K0(R)=Z` and shows exactly why that K-theory calculation cannot alone force `e=0`.

## Failure ledger and next target

- The exterior-without-graph-lift objection fails: internal surgeries and interval counting need no such lift.
- The interval-count objection fails: including the exterior contributes only one additional piece; `6(N+1)<=12H/L`.
- The small-cluster objection fails: all retained paths are closed, so there is no exceptional cluster.
- The cone-area objection fails: a finite cycle-relator presentation gives at most one relator cell per inner edge traversal.
- The probability-quantifier objection fails for existential selection: exactly the original fixed triple suffices, and the source asserts its exclusion with probability tending to one.
- The universal claim for every graph merely lacking full arrangements is unsupported; the deterministic hypothesis must explicitly include bounded-pattern exclusion.

The source bounded-pattern estimate has not been independently established in this audit. Its strong epsilon-before-all-bounds assertion is the load-bearing premise for the candidate transfer. Audit its stage/embedding accounting (`patterns.tex:424–593`) and the conditional prescription estimates. The present audit does not identify an erroneous proof line and must not infer a source error from the withdrawn compatibility argument. The independently audited disk extension composes with the release to a conditional torsion-free hyperbolic F2 direct-finiteness counterexample candidate, with a finite two-dimensional classifying complex.
