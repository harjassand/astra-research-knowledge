# Finite acquisition audit

Status: the finite recognition/search corollary at the end of `work/agents/groups_operator/hyperbolic_direct_finiteness_candidate.txt` is valid CONDITIONAL on the source probability estimates and deterministic source lemmas. No matching table has been acquired, and no feasible runtime is asserted.

## Coarse constants

The parent's rational

```
lambda = 71589573988/72026254783
```

is the source ordinary-row upper bound `q/(q+1)+7p^2+21/(q+1)^2`, with `q=128`, `p=129/16513`. The extra-row contraction bound, after dividing by its vector value four, is smaller. Thus `Mf<=lambda f` and `lambda<1`.

With `delta=(1-lambda)/8`, one has `exp(-4delta)>lambda`: `exp(-t)>=1-t`, and `1-4delta=(1+lambda)/2>lambda`. Consequently the source long-word decay holds eventually with this computable positive delta. The minimum positive turn weight is `1/129`; `a0=10` safely bounds the logarithmic word bins. Therefore `epsilon=delta/176` is exactly `delta/(16(1+a0))`, below the source's `1/4` cap.

The choice `c0=1/1000` satisfies both girth-scale inequalities. This can be verified with elementary coarse bounds on `log(2|T|/p)` and `log136`.

For the expansion constants `C2=4|T|`, `A=2C2/p`, `C3=3A^65`, the source union bound works. The binomial factor allows this C2 because `e/64.5<1`. Writing `x=k/n<=1`, and `64.5<=r/k<=65`, the probability is bounded by

```
[(e/2)^2 A^(r/k) x^(r/k-2)]^k
<= [3 A^65 x^62.5]^k.
```

The dyadic conditions `rho<1/4`, `260rho<p`, and `4 C3^2 rho^125<1` are decidable by rational arithmetic. The last is exactly the squared version of `C3 rho^62.5<1/2`, and the middle gives `65rho<p/4`.

For large n, the source radius `R=ceil(log_2 n)+1` obeys `2R+1 <= 5 log n`, while `L=floor(c0 log n) >=(c0/2)log n`. Thus `d>=20/(rho c0)` is conservative. Since `log2>1/2`, `D0>=d+16/c0+8` exceeds the source closure constant `d+8/(c0 log2)+8`. The parent's remaining rational/integer choices exceed the source separator requirements because `Csep<20`.

## Finite recognition contract

For a finite candidate graph and fixed integer L, there are finitely many graph paths of length at most CL. Enumerate positive cyclically immersed closed paths, and positive immersed interval paths beginning at `x_A` or `x_B`; form tuples with at most K0 paths, at most one interval path, and total length in `[L,CL]`. Enumerate at most I comparisons using disjoint positions, and verify equal-length intervals, allowed word equality, distinct underlying graph edges at every paired position, and `b<=epsilon H` using exact rational arithmetic.

The source allows both direct agreement and reversed/inverse agreement. For literal recognition of its excluded predicate, include BOTH modes. Checking only inverse comparisons suffices for the deterministic arrangement and disk consequences, because their pairings have inverse labels, but the weaker predicate should then be named explicitly.

Cyclic intervals, including those crossing the chosen indexing gap, must be included; finite enumeration can alternatively split every crossing comparison at the indexing gap and account for the resulting fixed comparison bound. Direct enumeration of all cyclic intervals avoids that bound adjustment.

Compute EXACT `L=floor(c0 log n)` by refining certified rational intervals for `log n` until the floor is determined. For rational positive c0 and integer n>1, equality `c0 log n=k` cannot occur for nonzero integer k, since it would say `n=exp(k/c0)` with nonzero algebraic exponent. Thus the refinement terminates. An unqualified floating-point approximation is not sufficient for a literal certificate. The source estimates would also need a separately checked stability argument if another O(1)-nearby girth scale were used.

The arithmetic condition

```
dL+4(ceil(log_2 n)+1) <= D0 L
```

directly guarantees the short-closure construction at the selected finite size. Together with `L>=3`, minimum degree129, and component diameter at most dL, it avoids accepting a small-n graph based only on eventual asymptotics. `ceil(log_2 n)` is computed by integer bit lengths, not floating-point logs. With `U>=3` and `L>=3`, the source `UL>=6` splitting condition is automatic.

## Termination and cost

Search over admissible `m=1 mod4`, legal prescribed types, and every finite tuple of inverse-label matchings. Each size has finitely many candidates and a decidable predicate. Source eventual positive probability supplies at least one accepting size, so a fair dovetail search halts conditional on the source estimates. An unknown asymptotic threshold does not require an oracle for this unbounded search.

For canonical types and fixed m, matching enumeration has

```
[(129m)! (129(m-1))!]^(|T|/2)
```

outcomes, where `|T|/2=8260`. Path checking alone can enumerate on the order of `n*136^(CL)` walks before path-tuple and comparison enumeration. These are coarse upper-bound descriptions, not an optimized complexity claim. They make the construction effective in the computability sense while leaving astronomical acquisition costs fully charged.

Once a graph table is selected, breadth-first spanning trees yield a finite rose presentation with at most `|E(Gamma)|` relators, each of length at most `2dL+1`, and the scalar expressions a,b,c follow by enumerating root-component vertex paths. No finite table or scalar coefficient list is emitted by this audit.
