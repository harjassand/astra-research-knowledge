# Cone-boundary cost gives ordinary linear Dehn area

Status: rigorous conditional cone-to-Dehn conversion; conditional torsion-free hyperbolic F_2 direct-finiteness counterexample candidate. The hypothesis that EVERY nullword in the rose has a cone picture with total inner graph-boundary length H <= C times its outer word length is sufficient. There is no additional radial-edge or rose-boundary obstruction. The claimed positive-characteristic Farrell-Jones contradiction in the first version of this audit is WITHDRAWN after exact tracing of the cited primary proofs. The released bounded-pattern estimate and construction lemmas remain unvalidated here.

Source interface: release197 algebra.tex lines 29-41 define finite X as the rose F with the abstract cones K_Lambda attached via graph label maps. topology.tex lines 35-47 define pictures whose punctured-surface exterior maps into F and whose inner disks factor through abstract cones with specified closed edge-path boundary lifts. The statement of topology.tex Lemma cone-pictures mentions a specified graph path on the outer boundary; the construction in its proof works with any specified rose edge word, because it is relative to F. However, a length estimate applying only to outer words that lift to Gamma is NOT sufficient for the hypothesis above.

## Explicit finite triangle presentation

For each graph vertex v in component Lambda, add the radial 1-cell r_v from the cone apex to the rose vertex. For an oriented graph edge e from v to u labeled t, its cone is a triangular 2-cell with attaching word r_v t r_u^{-1}. One triangle per geometric graph edge suffices; the reversed orientation reads its inverse. This is a finite CW structure, whether or not the cone image embeds in X.

An h-edge closed path c in Lambda fills by a fan with one domain triangle per edge occurrence. Map the fan apex to Lambda's cone apex and each spoke at vertex occurrence v to r_v. Adjacent sectors use the same spoke. The final spoke agrees with the first because c is a CLOSED path in the abstract graph. Repeated vertices or edges cause no problem: combinatorial disk maps need not be injective. Thus c uses exactly h nondegenerate target triangles. Its boundary stays entirely in F; no cone apex is needed on the outer rose boundary.

For a cone picture of an outer nullword w, replace every inner filling by this fan, keeping the outside map into F. The replacement is legitimate relative to the inner boundary because the ABSTRACT cone is contractible. The outside contributes zero 2-cell area. Its triangulation can include degenerate triangles, but Dehn area counts only relator cells, not the triangulation size of a map into a graph. Equivalently, cut the punctured exterior along disjoint connecting arcs. Its map into F gives the usual free-group identity expressing w as a product of conjugates of inner boundary labels. Connectors may be long; their lengths cost no relator cells. Attach the fans to obtain a standard possibly singular van Kampen diagram, with area at most H. Therefore Area_X(w) <= H <= C |w| for every rose nullword.

Collapse a maximal tree of X's 1-skeleton: choose exactly one radial edge in each cone component, together with the rose vertex. This produces a finite one-vertex triangle presentation P. Its generators consist of the rose generators and the remaining radial loops. Choose, for every v, a fixed graph path p_v from the selected vertex to v. The triangle relators along p_v give r_v = label(p_v) with at most |p_v| relator uses. Since Gamma is fixed finite, there are constants M >= 1 and A such that substituting all extra radial generators in a word W of length n gives a rose word w of length at most Mn, with at most An relator uses. If W is null then w is null. Consequently

    Area_P(W) <= An + C Mn.

This is a linear Dehn function for a genuine finite presentation, not merely for the restricted rose words.

## Even shorter direct rose presentation

Choose a maximal tree T_Lambda in every graph component and based fundamental loops for edges outside that tree. Present G on the rose alphabet, with the labels of these finitely many fundamental loops as relators. A closed h-edge graph path, based at any vertex, is conjugate to a product of at most h fundamental-loop generators and inverses: collapse the tree and read one basis letter per non-tree-edge occurrence. Tree-only closed walks freely cancel in Gamma, hence their labels freely cancel in F. Its label therefore fills with at most h relator cells in this finite rose presentation. The punctured-exterior free-group identity then immediately gives Area(w) <= H. This avoids introducing radial generators entirely and is the quantitative version of source topology.tex lines 56-79.

## Withdrawn external-obstruction argument

Primary source independently checked: Arthur Bartels, Wolfgang Lueck, Holger Reich, The K-theoretic Farrell-Jones Conjecture for hyperbolic groups, arXiv:math/0701434v2 (29 October 2007), Main Theorem on p.1; Applications on pp.3-4, bullet 'Kaplansky Conjecture for prime characteristic'. URL: https://arxiv.org/abs/math/0701434 ; PDF: https://arxiv.org/pdf/math/0701434 . Download and text extraction are retained here as blr_hyperbolic.pdf and blr_hyperbolic.txt.

The Main Theorem gives Farrell-Jones for every hyperbolic group and every coefficient ring. The p.4 introductory bullet DOES print that, for a commutative field R of characteristic p and a group satisfying that theorem, if every finite subgroup is a p-group, then 0 and 1 are the only idempotents of R[G]. I initially used this bullet as a verified obstruction. That was insufficient proof tracing, and the obstruction is now explicitly withdrawn. This audit does not claim to establish a correction to the BLR paper itself; it records that the needed positive-characteristic implication is not acquired from the cited proofs.

Read-only primary files examined during the correction:

- work/agents/group_source_audit/primary_fj/formanek1973.txt, printed pp.366-369; Edward Formanek, Idempotents in Noetherian Group Rings, https://doi.org/10.4153/CJM-1973-037-6 . Theorems 1 and 9 assume CHARACTERISTIC ZERO. Positive-characteristic Lemma 7 only proves vanishing of trace sums over NONIDENTITY conjugacy classes. The final e=0 or 1 inference in the characteristic-zero proof invokes Kaplansky's trace theorem, whose nontrivial-idempotent trace is strictly between 0 and 1.
- work/agents/group_source_audit/primary_fj/vallat.ps, lines 2248-2375; Burger-Valette, Idempotents in complex group rings: theorems of Zalesskii and Bass revisited. Lemma 4.1 obtains tau(e) in {0,1} in positive characteristic under the stated torsion and conjugacy-power assumptions. Proposition 4.2 concerns the COMPLEX group ring and concludes using Kaplansky's characteristic-zero theorem. It does not provide a modular tau(e)=0 implies e=0 inference.
- work/agents/group_source_audit/primary_fj/blr_applications_author.txt, Section 5, Lemma 5.4 and proof. Its K_0 induction argument EXPLICITLY assumes RG is stably finite. Theorem 5.3 supplies this for characteristic-zero fields or for sofic groups over skew-fields. Dropping stable finiteness from that proof is invalid.

In particular K_0(F_2[G]) = Z, although a consequence of Farrell-Jones for torsion-free hyperbolic G, does NOT on its own force a zero-class projective module to vanish. Such a conclusion is exactly the extra positivity/cancellation supplied by stable finiteness. No established positive-characteristic direct-finiteness theorem for the proposed torsion-free hyperbolic group has been verified in this audit.

The elementary implication 'only idempotents 0,1 implies direct finiteness' itself remains valid: if ab=1 then ba is idempotent and cannot be 0 in a nonzero ring, so ba=1. The unacquired premise is the modular absence of nontrivial idempotents, not this ring calculation.

## Corrected conditional consequence

If the release197 hypotheses prove the universal H <= C|w| bound AND its parity/protected-root construction is valid, then the resulting group is a torsion-free WORD-HYPERBOLIC direct-finiteness counterexample over F_2. This is a conditional candidate, not a validated theorem. The audited cone-to-Dehn conversion strengthens the geometric consequence; it does not validate the source's bounded-pattern probability theorem or the assembled construction.

For the proposed witnesses ab=1, ac=0, c!=0, e=1-ba is a nonzero nonidentity idempotent. The right module P=eR, R=F_2[G], is nonzero finitely generated projective and R is isomorphic to R direct-sum P: (x,z) maps to bx+z, with inverse y maps to (ay,ey). Hence [P]=0 in K_0(R). This explicitly demonstrates why the K_0 calculation alone cannot exclude the candidate. It is compatible with K_0(R)=Z at the level of Grothendieck groups.

## Failure ledger / next attack

Rejected proposed gap: radial edges missing from the finite complex. They are present and fixed; their elimination costs only a fixed constant.

Rejected proposed gap: arbitrarily complex or long exterior rose map could cost superlinear Dehn area. Graph-valued exterior costs zero 2-cell area; connector lengths are irrelevant to area.

Rejected proposed gap: repeated graph vertices in a fan prevent a disk diagram. Maps need not embed, and the fan spokes are indexed by domain occurrences.

Load-bearing dependency: obtaining the stated H <= C|w| estimate for EVERY nullword in F from the source's bounded-pattern exclusion, with the exact same constants and a rose-word outer boundary that may have no graph lift. The parent geometry audit now supplies a deterministic disk-extraction proof conditional on that exclusion; see read-only work/agents/groups_operator/hyperbolic_direct_finiteness_candidate.txt. The outstanding global validity gate is the released strong bounded-pattern probability estimate and the remaining construction lemmas. Do not cite the withdrawn FJ compatibility argument as evidence that the released construction is false. Do not present the conditional stronger counterexample as proved.
