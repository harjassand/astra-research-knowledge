# Adversarial prior-art and interface audit of two-output broadcasting

Audit date: 2026-10-07. Read `../general_classicality/GENERAL_CRITERION.md` and `../general_classicality/BROADCAST_CRITERION.md`. Primary-source search and concrete counterexample probes were performed; this is a bounded audit, not external correctness certification or priority clearance.

## Updated finding

**2026-10-07 finite-proof update:** `../broadcast_quantitative/EXPLICIT_PAIR_BOUND.md` replaces the load-bearing qualitative ultraproduct argument with a direct matrix proof. The focused source audit then found that its finite extraction lemma, including the exact binary constant, is a direct classical-label corollary of Brandão–Piani–Horodecki's 2013/2015 measured-conditioning proof, Li–Smith's 2015 Lemma 3, and Qi–Ranard's 2021 Proposition 1. See `FINITE_ENTROPY_ADDENDUM.md` for exact contracts, pages, source links, and the stronger general bound `e_m <= L eps + (m/2)sqrt(ln(m)/(2*2^L))`. The pair converse is therefore supported by known finite-dimensional tools; the ultraproduct interface below is now optional, and no novelty claim is justified for the finite extraction or information method.

## Earlier qualitative-route finding (retained as history)

No counterexample to the claimed **qualitative** dimension-independent pair modulus was found. The closest reviewed quantitative no-broadcasting statements do not immediately supply it under the stated pairwise promise interface. The exact infinite-algebra backbone is established prior art and should be foregrounded. The proposed passage from finite-dimensional approximate channels to a joint exact ultraproduct broadcast is the candidate-specific step needing independent verification.

The current draft addresses the important spatial-tensor pitfall: its output algebra `N` is not identified with the normal spatial tensor product `M bar-tensor M`. Keeping commuting marginal homomorphisms in a separate output algebra is consistent with the exact theorem below. I found no direct contradiction in that interface on reading, but have not independently certified the Raynaud matrix-amplification/channel-extension construction.

## Exact interface being tested

For two arbitrary density matrices on any finite-dimensional `H`, one unknown-label-independent CPTP channel `B:H -> H tensor H` must make **both** marginals close to **both** states. Set

`b2(rho,sigma) = inf_B max_{tau in {rho,sigma}, a=1,2} (1/2)||Tr_other B(tau)-tau||1`.

The claimed converse is a function `v(eps)->0` independent of `dim H`, with

`||sqrt(rho)sqrt(sigma)||1 - Tr sqrt(rho)sqrt(sigma) <= v(b2(rho,sigma))`.

There is no promise of independent output copies, purification preservation, efficient computation, a finite-dimensional limiting algebra, or an explicit rate. The experiment-level equivalence additionally uses uniform trace-distance covering numbers. Pair gap alone, for families with diverging covering entropy, is not being asserted sufficient.

## Primary sources and exact distinctions

1. **Barnum, Caves, Fuchs, Jozsa, Schumacher, 1996**, *Noncommuting mixed states cannot be broadcast*, PRL 76,2818; [primary arXiv](https://arxiv.org/abs/quant-ph/9511010), [publisher](https://doi.org/10.1103/PhysRevLett.76.2818). Exact same-channel broadcasting of a pair, with correlations allowed, is equivalent to commutation. The original presentation treats invertible mixed states; later exact extensions remove this minor limitation. This is a zero-error statement, not itself uniform stability over growing dimensions.

2. **Kretschmann, Schlingemann, Werner, 2008**, *The information-disturbance tradeoff and the continuity of Stinespring's representation*, [primary manuscript](https://arxiv.org/pdf/quant-ph/0605009), Corollary 4, p12 in arXiv v1, Eq.(43): for the two marginal Heisenberg channels, some completely depolarizing `S` satisfies `||T2-S||cb <= 2||T1-id||cb^(1/2)`. This is genuinely dimension-independent but assumes channel closeness to identity in stabilized cb/diamond norm on the full input space. Small error on two promised states does not imply that hypothesis, even for exactly broadcastable nonidentical commuting states. Thus this theorem cannot simply be substituted for the pair lemma.

3. **Lemm and Wilde, 2017**, *Information-theoretic limitations on approximate quantum cloning and broadcasting*, [primary manuscript](https://arxiv.org/pdf/1608.07569). Theorem 14/App.G, pp11-13, treats a simultaneous approximate two-fold broadcast with identical output marginals and proves `D(sigma1||sigma2)-D(tilde sigma1||tilde sigma2) >= Delta_R`. Its RHS is a channel-dependent rotated-Petz recovery difference. The discussion explicitly notes that its vanishing need not force commutation. A Carlen-Lieb alternative `Delta_CL` does have that zero-set property. Neither gives in the reviewed statement a dimension-independent conversion from marginal trace error to the proposed root-fidelity/affinity gap. Relative entropy also lacks uniform trace-distance continuity across arbitrary spectra. Theorems4-5 impose a product-output requirement for one of the two states and are stronger cloning interfaces.

4. **Kuramochi, 2017/2018**, *Accessible information without disturbing partially known quantum states on a von Neumann algebra*, [primary manuscript](https://arxiv.org/pdf/1710.01599). Corollary1,p14: a normal-state experiment on an arbitrary von Neumann algebra is broadcastable by a Schwarz channel on the **algebraic tensor product** iff it is normally CP equivalent to a classical experiment. This is directly relevant to the ultraproduct's commuting tensor embeddings. Remark2 distinguishes the normal spatial tensor product: in that stricter topology, broadcastability is equivalent to an **atomic** classical experiment. Hence no normal spatial tensor-product identification should be silently inferred. Theorem1 and the preceding minimal-sufficiency machinery already supply the exact ergodic/abelian-sufficient-algebra mechanism.

5. **Piani, 2016**, *Hierarchy of efficiently computable and faithful lower bounds to quantum discord*, [primary manuscript](https://arxiv.org/pdf/1501.06855), Eq.(4),p3 and Theorem1,p7. For a `k`-Bose-symmetric extendible channel on `B`, the channel's distance from an EB channel is bounded by `dim(B)/k`; consequently optimal EB recovery fidelity is at least optimal `k`-Bose broadcast fidelity minus `sqrt(2 dim(B)/k)`. The lowest nontrivial broadcasting level is faithful at fixed finite dimension, but these quantitative comparisons contain dimension. Bose support is stronger than merely permutation-invariant output. The paper therefore does not immediately make a dimension-free two-output promised-pair modulus trivial.

6. **Xie, Fang, Wang, Duan, 2017**, *Approximate broadcasting of quantum correlations*, [primary author-hosted PDF](https://www.kunfang.info/pdfs/XFWD17-PRA.pdf), Sec.V and Theorem5,p7. Defines weighted average root-fidelity broadcasting of a supplied finite ensemble using the same symmetric channel and gives its SDP. For fixed positive label weights, fidelity tending to1 is equivalent to each marginal trace error tending to0 by Fuchs-van de Graaf. The SDP establishes computability in a supplied finite-dimensional instance, not a uniform rate comparing the two-output optimum with EB reconstruction in arbitrarily growing dimension. Its asymptotic discord results concern receiver count tending to infinity and dimension-dependent bounds.

7. **Horodecki, Horodecki, Horodecki, Piani, 2005/2006**, *Quantumness of ensemble from no-broadcasting principle*, [primary manuscript](https://arxiv.org/pdf/quant-ph/0506174). Introduces a Holevo-information increase when replacing an ensemble by possible two-copy marginal realizations; its zero set is broadcastable ensembles. This supplies a prior operational quantumness characterization, but the reviewed result does not state the proposed uniform trace-error versus root-gap stability. A fixed finite-label cq encoding gives dimension-free continuity of Holevo information in the label dimension, but an additional argument would still be needed to turn small redundant-information loss into the requested gap bound.

8. **Khouzani and Manjegani, 2026**, *Trace-Norm Overlaps of Quantum States: Interpolation, Equality, and Data-Processing Rigidity*, submitted13Sep2026; [primary manuscript](https://arxiv.org/pdf/2609.14203). Sec.6, Theorem6.1,p17 defines precisely `Delta_alpha=||rho^alpha sigma^(1-alpha)||1-Tr rho^alpha sigma^(1-alpha)` and proves its zero set consists exactly of commuting pairs on separable Hilbert spaces, without faithfulness or common-support conditions. Thus the proposed `Delta` is already explicitly studied prior art at `alpha=1/2`. This paper's reviewed result is exact, and its subsequent channel discussion concerns overlap data processing/preservers. Full-text searches found no broadcasting, approximation, or stability statement. It should be cited for the statistic/exact criterion; it does not, on this bounded reading, state the compact-experiment EB equivalence or the dimension-free approximate broadcasting modulus. Its existence strengthens the need to avoid novelty claims about introducing the gap itself.

These source statements do not establish originality. The claim can be a nontrivial corollary of established exact theorems without being historically new. A complete bibliography/priority judgment would require a broader expert review.

## Concrete counterexample probes

The detailed independent probe is in `counterexamples.md`. These are mathematical tests of candidate mechanisms, not numerical theorem verification.

A later branch supplied a uniform dyadic copy ladder over all unknown pure directions, with two-output broadcasting error `1/L` but near-maximal EB reconstruction error when the direction dimension greatly exceeds the largest copy count. This concerns the absence of uniform metric-entropy control; it does not contradict the promised-pair modulus or the uniformly totally bounded experiment theorem. Its imported estimation bound and narrow historical comparison are audited in `COPY_LADDER_PRIOR.md`: the shift and estimation ingredients are established, while no exact construction match was identified within the bounded sources checked. That search result does not support a novelty claim. Construction correctness is audited by the separate `broadcast_entropy_counterexample` branch.

### A square-root rate is unavoidable, already in dimension two

Take pure states with overlap `c=|<psi|phi>|` tending to0. Then `Delta=c-c^2`. A symmetric Helstrom discrimination followed by preparation of the guessed state's two copies has per-label error probability

`p=(1-sqrt(1-c^2))/2`.

Both marginals therefore have trace error

`eps=p sqrt(1-c^2)=c^2/4+O(c^4)`.

Consequently any monotone envelope modulus for pairs admitting error at most `eps` must satisfy `v(eps) >= (2+o(1))sqrt(eps)`. In particular a universal linear rate is false. This does not refute a qualitative vanishing modulus. Equal-rank isoclinic projector lifts reproduce the same experiment at arbitrary dimensions.

### Standard high-dimensional universal cloning does not work

For the standard one-to-two universal cloner the marginal is `eta_d rho+(1-eta_d)I/d`, with `eta_d=(d+2)/(2(d+1)) ->1/2`. Vanishing marginal error on two test states forces both states close to `I/d` in trace distance. Dimension-free square-root continuity then forces their gap to0. Increasing dimension supplies no counterexample here.

### Small density commutators are a misleading substitute

For normalized projectors `rho=P/r`, `sigma=Q/r`, one can have a constant root-gap even while `||[rho,sigma]||1 ->0` from normalization. For isoclinic subspaces, the canonical two-projection decomposition gives a direct sum of identical rank-two pure-state experiments. The apparent large-dimensional gain disappears; it does not produce a low-error broadcaster. Thus a proof using ordinary density commutators without spectral normalization would be invalid, but the actual root-gap claim avoids that substitution.

### The natural embezzling-style copy ladder has vanishing gap

Consider the flagged harmonic ladder `rho_N = direct_sum_{k=1}^N [1/(k H_N)] rho0^(tensor k)` and similarly `sigma_N`. Splitting the `k` copies approximately in half can yield marginal distribution mismatch of order `1/H_N`. However, writing `F0=||sqrt(rho0)sqrt(sigma0)||1`, `A0=Tr sqrt(rho0)sqrt(sigma0)`, its root-gap is

`Delta_N = (1/H_N) sum_{k=1}^N (F0^k-A0^k)/k <= (log 2)/H_N ->0`.

The bound follows from `F0^2<=A0` and the infinite-series estimate `sum_k(F^k-F^(2k))/k=log(1+F)<=log2`, so it is uniform even for a changing base pair. This removes a concrete plausible counterexample mechanism.

### Data hiding and symmetric extension alone do not meet the contract

Data hiding controls distinguishability under restricted measurements, whereas `b2` uses unrestricted marginal trace norm. A cq state representing a pair is automatically separable and has artificial symmetric extensions; this is not a common channel on the quantum input. State extensions cannot replace channel extendibility. No counterexample meeting the full channel contract emerged from these labels alone.

## Earlier ultraproduct verification issue (now optional)

The right issue is whether the coordinate CP predual maps, under the precise Groh-Raynaud identifications, induce normal UCP adjoints whose partial-trace adjoints are genuine commuting homomorphisms on the full limiting algebra. The draft now explains this using the represented coordinate C*-ultraproduct and ultraweak density, and keeps `N` separate from a spatial tensor product. The exact normality, unit, matrix-cone and density claims should remain explicit and independently sourced. Once that interface is valid, Kuramochi's exact theorem strongly supports the proposed contradiction route; the known high-dimensional cloning/data-hiding examples reviewed here do not refute it.

Final updated status: **no counterexample found; explicit pair converse follows from existing conditioning tools; finite extraction has direct prior-art collision; full experiment-equivalence correctness and historical priority are separate questions, with no external novelty claim**.
