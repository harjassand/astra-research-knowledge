# Primary audit: finite supplied-state reconstruction from redundant outputs

Audited 2026-10-07. Trace distance convention: `T(a,b) = ||a-b||_1/2`; logarithms in candidate bounds are natural. The source papers use entropy in bits.

## Finding

The candidate's existence statement and its binary constant are immediate finite-label corollaries of earlier primary conditioning results. They should not be presented as a new redundancy-to-measurement reconstruction theorem. The specific adaptive Helstrom construction can be described as a particular proof implementation, without inferring novelty of the resulting existence bound.

## Original quantum Darwinism proof: present already in the 2013 version

Brandão, Piani, Horodecki, [*Quantum Darwinism is Generic*, arXiv:1310.8640v1](https://arxiv.org/pdf/1310.8640v1), submitted **31 October 2013**, Section III.A, printed/PDF ordinal **pp.9–10**. (The PDF's generated `Dated:` field is not the arXiv submission date.)

Their Eq.(28), printed p.10, supplies a subset `J`, measurements on `J`, and a classical record `H`, with `|J| < k`, such that

\[
\mathbb E_{j\notin J}\max_{M_j\in\mathrm{QC}} I(A:Y_j\mid H)
\le \frac{\log_2 d_A}{k}.
\]

Their Eq.(30), same page, then bounds the averaged measured norm of the residual from the **actual conditional-marginal product**:

\[
\mathbb E_{j\notin J}\max_{M_j\in\mathrm{QC}}
\left\|(\mathrm{id}_A\otimes M_j)
\left(\rho_{AB_j}-\sum_h p_h\rho_A^h\otimes\rho_{B_j}^h\right)\right\|_1
\le\sqrt{\frac{2\ln 2\log_2 d_A}{k}}.
\]

The chain/entropy argument uses no output permutation symmetry. Set `k=n=K` and take `A` to be a uniform classical label of the supplied states. At least one remaining output has the displayed norm bound. The proof's Choi-state machinery is used subsequently to obtain the main diamond-norm theorem; it is unnecessary for this finite-label application.

The published article is [*Generic emergence of classical features in quantum Darwinism*, Nature Communications 6, 7908 (2015)](https://doi.org/10.1038/ncomms8908). In [arXiv v2](https://arxiv.org/pdf/1310.8640v2), the corresponding proof inequalities are **Eqs.(32),(34), printed/PDF ordinal p.18**, with the entropy-budget setup on p.17. Its main Theorem 1 is the different, stronger-in-norm but weaker-in-rate contract

\[
\|\Lambda_j-\mathcal E_j\|_\diamond
\le\left(\frac{27\ln 2\,d_A^6\log_2 d_A}{n\delta^3}\right)^{1/3}
\]

for at least `(1−δ)n` outputs using a common input POVM. Do not substitute `d_A=m` into this main channel theorem: the finite classical label is a reference, not the original input system.

## Closest named unsymmetric proposition

Qi and Ranard, [*Emergent classicality in general multipartite states and channels*, Quantum 5, 555 (2021), arXiv:2001.01507v3](https://arxiv.org/pdf/2001.01507v3), **Proposition 1**, Eq.(18), printed/PDF ordinal **p.9**: for an arbitrary state on `AB_1…B_n`, there is a measured subset `Q` of size at most `q` such that every disjoint size-`r` region satisfies

\[
\max_{M_R\in\mathrm{QC}}I(A:Y_R\mid H)
\le \frac{S(A)}{1+\lfloor q/r\rfloor}.
\]

Thus `n=K`, `q=K−1`, `r=1`, and classical `A=X` give exactly `H(X)/K` bits, for every remaining output. **Lemma 2**, Appendix A, printed **pp.19–20**, converts conditional information into a residual from the actual conditional product using Pinsker. Theorem 2's proof, **Eq.(20), p.11**, explicitly states that the resulting label ensemble and record measurement are independent of the remaining output. Theorem 2 itself is on p.7; it controls a one-way-LOCC norm and excludes an entropy-controlled region.

## Finite-label contract comparison (corollary inference)

For a common channel `Λ`, feed the uniform ensemble `ρ_x`, retain the classical label `X`, and apply either result above. The measured prefix induces the legal input POVM `Λ_Q^*(M_Q^h)`. Preparing the posterior marginal `ξ_{j,h}` gives an EB channel `E_j`.

The corresponding label residual blocks are `D_x = Λ_j(ρ_x)−E_j(ρ_x)`, with `Σ_x D_x=0`. A Helstrom measurement for one block contributes its norm, while the other measured blocks together contribute at least the same norm. Consequently the primary measured-residual bound yields

\[
\max_x T\bigl(\Lambda_j(\rho_x),E_j(\rho_x)\bigr)
\le\frac m2\sqrt{\frac{\ln m}{2K}}.
\]

For `m=2`, this is exactly `sqrt(ln 2/(2K))`; for general `m≥2`, it is stronger than the candidate `m² sqrt(ln m/(2K))`. No identical-marginal or permutation-invariance assumption is needed for the one-output existence statement. If every marginal already approximates a common target, the selected marginal's target approximation transfers by the triangle inequality.

This is a prior-art contract comparison, not a reconstruction or correctness audit of the candidate's adaptive proof. Local copies of the primary PDFs and text extraction are retained beside this note; p.10 of v1 and p.9 of Qi–Ranard were rendered for equation/page checks.
