# Finite-label broadcasting: primary-source collision addendum

Audit date: 2026-10-07. This updates `AUDIT.md` after reading `../broadcast_quantitative/EXPLICIT_PAIR_BOUND.md`. The earlier qualitative ultraproduct route is no longer needed to justify the pair converse. The finite extraction lemma, including its binary constant, is a direct corollary of existing measured-conditioning results. No originality claim is supported for that lemma or information-chain method.

## Closest original contracts

**Brandão–Piani–Horodecki**, *Generic emergence of classical features in quantum Darwinism*, Nature Communications 6, 7908 (2015), [primary arXiv v2](https://arxiv.org/pdf/1310.8640v2), [original v1](https://arxiv.org/pdf/1310.8640v1), [version history](https://arxiv.org/abs/1310.8640). The v1 title is *Quantum Darwinism is Generic*, submitted 31 October 2013. Its proof p10, Eqs. (28)–(30), already produces a measured subset `J`, with `|J|<=k-1`, and bounds the average one-leaf measured norm of the posterior-product residual by `sqrt(2 ln(2) log_2(d_A)/k)`. The posterior states are explicitly obtained by measurements of `J`. The later Choi-state norm conversion and averaging over excluded leaves introduce the headline dimension factors and cube-root rate. These later losses are unnecessary for a classical finite label and one selected good leaf. In v2 the corresponding argument is Appendix A, pp17–18, Eqs. (32)–(34).

**Li–Smith**, *Quantum de Finetti theorem under fully-one-way adaptive measurements*, PRL 114, 160503 (2015), [primary arXiv v4](https://arxiv.org/pdf/1408.6829v4), [publication/version metadata](https://arxiv.org/abs/1408.6829). Lemma 3, printed p3, states that a permutation-invariant state `rho_AB1...BK` admits a measurement `Q:B2...BK->H` such that every measurement `P:B1->Y` satisfies `I(A:Y|H)<=log_2(dim A)/K`. Proof: printed p6, Eqs. (14)–(15). Symmetrizing a broadcast-tree channel preserves the promised marginal error, so this named lemma applies directly. Its measurement outcomes determine the posterior label distribution and conditional output preparation. This is a clean prior named contract for the binary extraction after symmetrization.

**Qi–Ranard**, *Emergent classicality in general multipartite states and channels*, Quantum 5, 555 (2021), [primary arXiv v3](https://arxiv.org/pdf/2001.01507v3). Proposition 1, printed p9, Eq. (18), requires no permutation symmetry. Given `rho_AB1...BK`, region size `r`, and `q`, it provides `|Q|<=q`, a measurement `M_Q`, and for every disjoint `r`-site region `R`, `max_MR I(A:R|Q)<=S(A)/(1+floor(q/r))`, with entropy in bits. Take `r=1,q=K-1`. Its proof is pp10–11. Theorem 2/Eq. (20), p11, and Lemma 2, pp19–20, turn this into a measured posterior-product norm bound. Lemma 2 explicitly defines the conditional states using the measured POVM, so the reconstruction retains the required input-POVM contract. The authors attribute the posterior-product/Pinsker step to Brandão–Piani–Horodecki.

## Exact specialization to the promised ensemble

The following is our explicit specialization of those source contracts, rather than a statement that the papers advertise a finite-label EB theorem in this notation.

Let `C:H_in->H^tensor K` be one channel and let the promise consist of `m>=2` states `rho_x`, with uniform design prior. Apply the source conditioning result to

`omega_XB1...BK=(1/m) sum_x |x><x| tensor C(rho_x)`.

Here `S(X)=log_2 m`. For `K>=2`, the stated Qi–Ranard specialization is legal; `K=1` follows directly from the entropy budget and Pinsker with an empty conditioning record. For some remaining leaf `j`, measure the excluded systems with the source POVM, obtaining outcome `h`. Define `xi_h` to be the conditional average state of leaf `j`. Composing that measurement with `C` gives an actual POVM on the original quantum input; preparing `xi_h` therefore defines a legitimate EB channel `E`. No label-dependent input operation is used.

Write `D_x=C_j(rho_x)-E(rho_x)` and

`R=(1/m) sum_x |x><x| tensor D_x`.

The conditional-product construction preserves the average leaf state, so `sum_x D_x=0`. The source bound becomes

`max_M ||(id_X tensor M)R||1 <= sqrt(2 ln(m)/K)`.

For the Helstrom measurement of a selected `D_x`, its measured norm equals `||D_x||1`. The other blocks together contribute at least the same norm because their sum is `-D_x`. Hence

`max_x T(C_j(rho_x),E(rho_x)) <= (m/4)sqrt(2 ln(m)/K) = (m/2)sqrt(ln(m)/(2K))`,

where `T=(1/2)||.||1`. For `m=2`, the residual blocks are exactly opposite, and this is precisely `sqrt(ln(2)/(2K))`, the constant in the binary draft. This also improves both preliminary `m^2` and `m^(3/2)` bounds. The classical-label norm conversion is elementary; the information conditioning is prior art.

## Broadcasting and covering consequences

Standard depth-`L` iteration of a two-output broadcaster with maximum promised marginal trace error `eps` produces `K=2^L` outputs, each with error at most `L eps`. Therefore the prior conditioning lemma yields

`e_EB({rho_1,...,rho_m}) <= L eps + (m/2)sqrt(ln(m)/(2*2^L))`.

Binary `m=2` reproduces the submitted explicit pair inequality exactly. Choosing `2^L` of order `m^2 ln(m)/eps^2` gives the existing claimed order `O(eps log(m/eps))`; the known extraction lemma supplies a sharper finite constant. Composing with the draft's separate EB-to-root-gap inequality gives its pair rate `O(sqrt(eps log(1/eps)))`.

For a trace-distance `eta`-net of size `m=N_E(eta)`, the usual contractivity extension contributes `2 eta`, giving

`e_EB(E) <= 2 eta + L eps + (m/2)sqrt(ln(m)/(2*2^L))`.

Thus the operational finite-label/covering rate is a short composition of known conditioning machinery, channel iteration, and net extension. I did not find the full root-gap/EB/broadcast experiment equivalence under the draft's precise uniform total-boundedness hypothesis stated in these sources. That bounded search is not priority clearance: a differently phrased theorem or an immediate combination of other established results may already cover it.

## Interpretation and recommended attribution

Use wording such as: “A finite classical-label specialization of the conditioning argument of Brandão–Piani–Horodecki, or of Li–Smith Lemma 3 after output symmetrization, gives the following reconstruction bound. Qi–Ranard Proposition 1 provides a direct form without symmetrization.” Then state the tree-iteration and covering corollaries separately.

Do not say that the information-chain argument is new, that the pair extraction constant is new, or that the explicit dimension-free operational rate establishes external novelty. The exact equivalence/statistical-experiment formulation must be evaluated separately. The adversarial pure-state example in `counterexamples.md` still shows that a universal pair-gap modulus cannot improve to a linear function of broadcasting error.

Status: **direct prior-art collision for the finite extraction lemma and its exact binary constant; finite operational converse follows from known tools; no counterexample found; no external novelty or full-equivalence priority claim.**
