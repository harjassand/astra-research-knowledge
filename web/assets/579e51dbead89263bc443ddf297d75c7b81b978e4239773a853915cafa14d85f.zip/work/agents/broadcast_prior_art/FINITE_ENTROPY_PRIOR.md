# Focused prior-art audit: finite-label entanglement-breaking extraction

Status: the proposed finite-ensemble extraction bound has a direct prior-art collision. Its binary constant follows immediately from an original 2013 quantum-Darwinism conditioning argument. The proposed general `m^2` bound is weaker than a direct finite-label corollary of that argument. This classification concerns the extraction lemma; it does not establish historical priority of every subsequent fidelity-affinity consequence.

Conventions: `T(a,b) = ||a-b||_1/2`; `ln` denotes natural logarithm. The ensemble has `m` supplied states with a uniform design prior. The common channel has `K` output systems. Output correlations are unrestricted. Reconstruction is required only on the supplied states.

## Earliest directly verified source: Brandao–Piani–Horodecki, 2013

Primary source: [Quantum Darwinism is Generic, arXiv:1310.8640v1](https://arxiv.org/pdf/1310.8640v1), submitted 31 October 2013; later published as [Generic emergence of classical features in quantum Darwinism](https://doi.org/10.1038/ncomms8908), Nature Communications 6, 7908 (2015).

The proof of Theorem 1 contains the decisive state-level contract before its Choi-state/diamond-norm conversion. On PDF/printed page 10, Eq. (28) gives a measured subset `J`, `|J| = q-1 < k`, such that

    E_{j notin J} max_{M_j} I(A : Y_j | Z) <= log_2(d_A)/k.

Here `Z` records measurements on `J`; `M_j` is any measurement on the unmeasured output `B_j`. Eq. (30), on the same page, gives

    E_{j notin J} max_{M_j}
      ||(id_A tensor M_j)[rho_ABj - sum_z p(z) rho_A^z tensor rho_Bj^z]||_1
        <= sqrt(2 ln(2) log_2(d_A)/k).

The entropy budget and chain telescope are on pages 9–10, Eqs. (24)–(27). Setting `k = K` is legal. Their main published theorem has a dimension-dependent diamond-norm contract; the displayed conditioning contract is the appropriate source for the finite-label corollary. In [v2](https://arxiv.org/pdf/1310.8640v2), the corresponding equations are (32)–(34), pages 17–18.

## Explicit later statement: Li–Smith, 2015

Primary source: [Quantum de Finetti theorem under fully-one-way adaptive measurements, arXiv:1408.6829v4](https://arxiv.org/pdf/1408.6829v4), [Physical Review Letters 114, 160503](https://doi.org/10.1103/PhysRevLett.114.160503).

Lemma 3 on page 3 states: if `rho_AB1...BK` is invariant under permutations of the `B` systems, and `P : B1 -> Y`, `Q : B2...BK -> Z` are measurements, then

    min_Q max_P I(A : Y | Z) <= log_2(|A|)/K.

Its proof is on page 6. A broadcast output may first be symmetrized: each resulting supplied-state marginal retains the assumed target error. For `A` a classical `m`-label register, the lemma supplies exactly the required finite information budget. This is a separately stated theorem-level route to the same extraction result.

## Modern unsymmetric statement: Qi–Ranard, 2021

Primary source: [Emergent classicality in general multipartite states and channels, Quantum 5, 555](https://quantum-journal.org/papers/q-2021-09-28-555/), [publisher PDF](https://quantum-journal.org/papers/q-2021-09-28-555/pdf/).

Proposition 1, page 9, Eq. (18): for any `rho_AB1...Bn` and region size `r`, there are a region `Q`, `|Q| <= q`, and a measurement `M_Q` such that every disjoint region `R`, `|R| = r`, satisfies

    max_{M_R} I(A : R | Q)_{M_Q M_R(rho)}
      <= S(A)_rho / (1 + floor(q/r)).

Take `n = K`, `r = 1`, `q = K-1`, `A` the classical ensemble label. The bound is `ln(m)/K` in nats. Their Lemma 2, pages 19–20, and the Pinsker step Eq. (20) give the same measured posterior-product residual as the earlier source. No permutation symmetry is required. `K=1` is handled directly by the entropy bound or trivial constant preparation.

## Finite-label application and constant audit

The following is an inference from the cited posterior-product contracts, not an assertion that they print a theorem named “finite-label EB reconstruction.” Put

    rho_XB1...BK = (1/m) sum_x |x><x| tensor C(rho_x).

Measure the supplied region to obtain `z`; prepare the fixed posterior-mixture state `rho_Bj^z`. Pulling the output measurement back through `C` gives a POVM on its original input, so the resulting reconstruction channel `E` is entanglement breaking. Define `D_x = C_j(rho_x) - E(rho_x)`. The residual is

    R = (1/m) sum_x |x><x| tensor D_x,
    sum_x D_x = 0,
    max_M ||(id_X tensor M) R||_1 <= sqrt(2 ln(m)/K).

Choose the Helstrom measurement for one `D_x`. The other measured blocks sum to its negative, so their total norm is at least its norm. Therefore

    max_x T(C_j(rho_x), E(rho_x))
      <= (m/2) sqrt(ln(m)/(2K)).

For `m=2`, this is exactly `sqrt(ln(2)/(2K))`. The zero-sum identity makes the two binary residual blocks negatives of each other; a single Helstrom measurement attains their full trace norm. For `m=1`, constant preparation gives exact reconstruction.

Consequently, the original binary-tree marginal estimate immediately gives

    max_x T(rho_x, E_L(rho_x))
      <= L epsilon + sqrt(ln(2)/(2 * 2^L))

for two supplied states, and the general finite-label extraction is already stronger than the proposed `m^2 sqrt(ln(m)/(2K))` bound. The adaptive-Helstrom proof may remain a useful elementary presentation, but the quantitative extraction conclusion should be attributed as a corollary of the established conditioning machinery.

## Why the bare Brandao–Harrow theorem is not the cleanest citation

Primary source: [Quantum de Finetti Theorems under Local Measurements with Applications, arXiv:1210.6367v5](https://arxiv.org/pdf/1210.6367v5). Theorem 1(1), page 6, bounds

    min_{sigma separable} max_{Lambda_B} E_t
      ||(E_t tensor Lambda_B)(rho_AB - sigma_AB)||_1
        <= sqrt(2 ln(|Atilde|)/k).

Its proof, pages 22–24, Eqs. (49)–(57), already uses the information chain and conditional product mixture. But a classical-label/quantum-output state is itself separable, so the theorem's bare separability conclusion does not enforce the output-induced input POVM required here. The 2013 Darwinism proof, Li–Smith Lemma 3, or Qi–Ranard Proposition 1 preserve precisely the useful conditioning contract.
