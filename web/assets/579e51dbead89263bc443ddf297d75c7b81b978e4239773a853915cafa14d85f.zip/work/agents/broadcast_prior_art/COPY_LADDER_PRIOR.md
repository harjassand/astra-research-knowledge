# Copy-ladder historical audit

Audit date: 2026-10-07. Scope: a bounded primary-source comparison for the supplied dyadic, flagged family

\[
\rho_\psi=\frac1L\bigoplus_{j=0}^{L-1}(|\psi\rangle\langle\psi|)^{\otimes 2^j},\qquad
\mathcal H=\bigoplus_{j=0}^{L-1}\operatorname{Sym}^{2^j}(\mathbb C^d),
\]

with one channel broadcasting both marginals to half-trace-distance error at most \(1/L\), while every entanglement-breaking reconstruction has worst error at least
\(1-(2^{L-1}+1)/(2^{L-1}+d)\). The construction and its support-witness reduction were supplied by the counterexample branch; this note audits historical interfaces and the imported estimation theorem, and does not independently reprove the construction.

## Bounded conclusion

**No exact priority match was identified in the primary sources checked. This is not evidence of historical novelty.** An explicit tensor-power reservoir shifted almost invariantly is established prior art (Leung–Toner–Watrous). The universal estimation ingredient is also established. Known asymptotic broadcasting-to-classicality theorems explicitly depend on the receiver Hilbert-space dimension. The specific conjunction “uniform dyadic flagged unknown-direction family; two approximate marginals; near-maximal uniform EB reconstruction error” was not located here.

## Verified imported theorem

For a Haar-distributed unknown pure state \(\psi\in\mathbb C^d\), supplied as \(n\) identical copies, **every deterministic measure-and-prepare channel**, allowing collective measurements and arbitrary mixed prepared states, satisfies

\[
\int d\psi\,\operatorname{Tr}\!\left[\psi\,\mathcal E(\psi^{\otimes n})\right]
\le \frac{n+1}{n+d}.
\]

- [Giulio Chiribella, *On quantum estimation, quantum cloning and finite quantum de Finetti theorems* (2010/2011), primary PDF](https://arxiv.org/pdf/1010.1875): Section 1, PDF pages 3–4, immediately following Eq. (5), explicitly optimizes \(\mathcal M(\rho)=\sum_i\operatorname{Tr}(P_i\rho)\rho_i\), with density operators \(\rho_i\), and gives maximum average target overlap \(D_n/D_{n+k}\), \(D_m=\binom{d+m-1}{m}\). Set \(k=1\). Symmetric-output restrictions are then vacuous. The score is overlap, not root fidelity.
- [Dagmar Bruß and Chiara Macchiavello, *Optimal state estimation for d-dimensional quantum systems* (1998/1999), primary PDF](https://arxiv.org/pdf/quant-ph/9812016): Eq. (16) is the original general-dimensional \((n+1)/(n+d)\) formula. Their discussion uses universal pure-state estimation; Chiribella is the more direct citation for unrestricted average measure-and-prepare performance.
- [Huangjun Zhu, *Quantum measurements in the light of quantum state estimation* (2022), primary PDF](https://arxiv.org/pdf/2111.02841): Theorem 2, Eq. (60), covers any POVM on the full tensor-product input. Eqs. (32)–(35) permit mixed estimators and explain that these cannot improve the optimal score.
- [Horodecki, Shor, and Ruskai, *Entanglement Breaking Channels* (2003), primary PDF](https://arxiv.org/pdf/quant-ph/0302031): Theorems 2 and 4 identify EB CPTP channels with precisely measure-and-prepare form with a POVM and prepared density matrices.

Consequently the one-copy worst half-trace-distance reconstruction error is at least \((d-1)/(n+d)\). This consequence uses the pure-state projector test and average-to-worst-case passage; it is an elementary inference, not an additional source theorem. The ladder branch supplies the reduction from its flagged support witness to this one-body estimation score.

For a finite replacement of Haar, [Hayashi, Hashimoto, and Horibe, *Reexamination of optimal quantum state estimation of pure states* (2005), primary PDF](https://arxiv.org/pdf/quant-ph/0410207), Section III, establishes finite positive quadratures with exact symmetric moments; Eq. (21) gives the \((n+1)\)-moment condition. Thus an exact **weighted** projective \((n_{\max}+1)\)-design suffices for the estimation calculation across the finite ladder. Finite existence does not assert efficient construction, uniform weights, or small cardinality.

## Closest construction-level precedent: LTW

[Debbie Leung, Ben Toner, and John Watrous, *Coherent state exchange in multi-prover quantum interactive proof systems* (arXiv 2008; final 2013), primary PDF](https://arxiv.org/pdf/0804.4118), Section 2, PDF pages 4–5, Eqs. (1)–(2) in arXiv v2 (Eqs. (2.1)–(2.2) in the author final), uses, for orthogonal fixed states \(\phi,\psi\),

\[
|E_N\rangle=N^{-1/2}\sum_{k=1}^N
|\phi\rangle^{\otimes k}|\psi\rangle^{\otimes(N-k+1)}.
\]

Local cyclic register shifts exchange \(\phi\otimes E_N\) for \(\psi\otimes E'_N\), with \(\langle E_N|E'_N\rangle=1-1/N\). The reservoir is state dependent. The paper separately constructs universal multipartite embezzling families using a tensor product over a finite net and calls this highly inefficient.

**Interface differences:** LTW has fixed known state exchange, a coherent pure catalyst, additive copy counts, and an extracted fixed target. It does not state the dyadic flagged mixed unknown-direction family, two marginal broadcasting on the same flagged Hilbert space, or the uniform EB reconstruction gap. Its near-invariant tensor-power shift is clear mechanism-level prior art.

## Related results and their limits

- [van Dam and Hayden, *Embezzling Entangled Quantum States* / *Universal entanglement transformations without communication* (2002/2003), primary paper](https://arxiv.org/abs/quant-ph/0201041): a fixed universal bipartite entanglement reservoir permits extraction of a chosen target by suitable local unitaries while hardly changing the reservoir. “Universal” concerns reservoir independence of the chosen known target; it does not supply a channel that clones an unknown direction from this ladder.
- [Marvian and Lloyd, *From clocks to cloners: Catalytic transformations under covariant operations and recoverability* (2016), primary PDF](https://arxiv.org/pdf/1608.07325): treats \(\psi^{\otimes n}\to\psi^{\otimes(n+k)}\) as approximate catalysis, with optimal global root fidelity \(\sqrt{D_n/D_{n+k}}\). Global cloning from a fixed copy count is a different target; \(d\gg n\) does not yield high global fidelity for doubling.
- [Chiribella and D’Ariano, *Quantum information becomes classical when distributed to many users* (2006), primary PDF](https://arxiv.org/pdf/quant-ph/0608007): Theorem 2 and Eq. (20) approximate permutation-symmetric broadcasting by a measure-and-prepare channel, with full trace-norm marginal error asymptotically \(2(d^2-1)k/M\), for \(M\gg kd^2\). The immediately following paragraph explicitly notes weaker control as receiver dimension grows. This is fixed-dimension many-receiver convergence, and does not rule out the supplied growing-dimension two-receiver family.
- [Bae and Acín, *Asymptotic quantum cloning is state estimation* (2006), primary PDF](https://arxiv.org/pdf/quant-ph/0603078): proves equivalence in the infinite-output-copy limit for a fixed pure-state ensemble. It is not a dimension-uniform stability theorem for approximate broadcasting of arbitrary mixed-state families.
- [Lemm and Wilde, *Information-theoretic limitations on approximate quantum cloning and broadcasting* (2017), primary PDF](https://arxiv.org/pdf/1608.07569): Definition 3 allows general mixed inputs with identical approximate marginals. Theorems 4–5 additionally require one input’s joint output to be a tensor product; correlated ladder flags violate that premise. Their relative-entropy bounds require support inclusion for informativeness, also absent for generic different rank-one directions in the ladder blocks.

## Search boundary

Primary-source searches combined dyadic/flagged/direct-sum broadcasting, approximate broadcasting plus EB/classicality, catalytic cloning, self-embezzlement, and embezzling tensor-power reservoirs. The inspected contracts above are positive evidence for known ingredients and distinct interfaces. The absence of an exact match in this bounded audit cannot settle priority, and neither the entire family obstruction nor any global novelty claim should be attributed to the estimation papers or LTW without qualification.
