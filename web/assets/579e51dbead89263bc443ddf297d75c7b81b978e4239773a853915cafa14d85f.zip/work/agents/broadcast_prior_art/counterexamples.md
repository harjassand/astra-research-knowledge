# Counterexample audit for the dimension-free broadcast criterion

Scope: a common CPTP channel sends each of two finite-dimensional density states to a bipartite output, and each output marginal has trace distance at most epsilon from its corresponding input. Trace distance here is D(x,y)=||x-y||_1/2. The tested conclusion is that Delta(rho,sigma)=f(rho,sigma)-a(rho,sigma) tends to zero uniformly in dimension, where f=||sqrt(rho)sqrt(sigma)||_1 and a=Tr sqrt(rho)sqrt(sigma).

**Result of this bounded audit:** no counterexample found. The constructions below are rigorous candidate eliminations or restrictions on a possible quantitative modulus. They do not prove the general criterion or certify its ultraproduct proof.

## 1. Any modulus must allow square-root error

Let rho=|psi><psi| and sigma=|phi><phi| be qubit pure states with real overlap c in (0,1). Then f=c, a=c^2, and Delta=c-c^2.

Perform the equal-prior optimal binary Helstrom measurement and prepare two copies of the selected target state. By the symmetry of the two pure states, the conditional error probability on either input is

    p=(1-sqrt(1-c^2))/2.

Each marginal is (1-p)rho+p sigma on rho input, and vice versa. Therefore both marginal trace-distance errors are exactly

    epsilon=p D(rho,sigma)
           =[(1-sqrt(1-c^2))/2]sqrt(1-c^2)
           =c^2/4+O(c^4).

Consequently Delta=(2+o(1))sqrt(epsilon). A universal upper modulus cannot be o(sqrt(epsilon)). In particular, a linear bound with a universal constant fails already in dimension two. This construction does not contradict the qualitative conclusion.

## 2. Small density commutators can be misleading

Let rho_r=rho tensor I_r/r and sigma_r=sigma tensor I_r/r, with the same fixed pure qubit pair above. Equivalently, these are normalized equal-rank isoclinic projectors P/r and Q/r in dimension 2r. Then

    Delta(rho_r,sigma_r)=c-c^2,
    ||[rho_r,sigma_r]||_1=2c sqrt(1-c^2)/r -> 0.

This shows why a small unscaled commutator of density matrices is not an adequate classicality witness. It is not a broadcasting counterexample: any broadcaster for the lifted states induces a broadcaster for the fixed qubit pair by preparing I_r/r on input and tracing out the ancillary r-dimensional systems on both outputs. Trace-distance errors cannot increase under these traces. Compactness in the fixed qubit dimension plus exact no-broadcasting rules out errors tending to zero for fixed 0<c<1.

More generally, a pair of projections admits the usual principal-angle/Jordan decomposition into blocks of dimension at most two. No universal quantitative lower bound for arbitrary cross-block channels is asserted here.

## 3. Universal cloning does not supply a counterexample

The standard optimal symmetric universal 1-to-2 cloner has each marginal

    T_d(tau)=eta_d tau+(1-eta_d)I_d/d,
    eta_d=(d+2)/(2(d+1)).

Hence D(T_d(tau),tau)=(1-eta_d)D(tau,I_d/d). Since 1-eta_d>=1/3 for d>=2, errors at most epsilon on both inputs force D(rho,I_d/d),D(sigma,I_d/d)<=3epsilon. Thus D(rho,sigma)<=6epsilon. The Powers-Stormer inequality gives 1-a(rho,sigma)<=D(rho,sigma), and f<=1, so

    Delta(rho,sigma)<=6epsilon.

The large-dimensional shrinkage eta_d -> 1/2 therefore cannot hide a fixed positive gap.

Primary source for the universal cloner: R. F. Werner, *Optimal Cloning of Pure States*, https://arxiv.org/abs/quant-ph/9804001; M. Keyl and R. F. Werner, *Optimal Cloning of Pure States, Judging Single Clones*, https://arxiv.org/abs/quant-ph/9807010. The gap estimate above is an elementary derivation, not a claimed theorem of these papers.

## 4. Harmonic tensor-copy embezzling ladder: vanishing error and vanishing gap

For a base pair rho_0,sigma_0, let H_N=sum_{k=1}^N 1/k, p_k=1/(k H_N), and define flagged states

    rho_N=directsum_{k=1}^N p_k rho_0^{tensor k},
    sigma_N=directsum_{k=1}^N p_k sigma_0^{tensor k}.

A CPTP channel measures the block label k. For k>=2 it splits 2 floor(k/2) factors into two groups of floor(k/2), discarding the extra factor when k is odd. For k=1 it prepares an arbitrary fixed product state in output block 1. Each output system uses the same direct-sum Hilbert space as the input.

Apart from the k=1 replacement, both marginal weights are

    q_j=p_{2j} 1_{2j<=N}+p_{2j+1} 1_{2j+1<=N}.

They satisfy q_j<=p_j and sum_j(p_j-q_j)=p_1. Each marginal's trace distance from the appropriate input is therefore at most p_1=1/H_N, for either base state.

Write f=f(rho_0,sigma_0), a=a(rho_0,sigma_0). Direct sums and tensor products give

    Delta_N=(1/H_N) sum_{k=1}^N (f^k-a^k)/k.

The standard inequality f^2<=a yields

    Delta_N <= (1/H_N) sum_{k=1}^infinity (f^k-f^{2k})/k
            = log(1+f)/H_N <= log(2)/H_N,

for f<1; when f=1, a=1 and Delta_N=0. This estimate remains valid if the base pair depends on N. Thus the most direct embezzling attempt fails uniformly.

For an elementary proof of f^2<=a, put r=sqrt(rho_0), s=sqrt(sigma_0), and take a unitary U attaining f=|Tr rsU|. Set X=r^{1/2}s^{1/2} and Y=s^{1/2}Ur^{1/2}. Then Tr XY=Tr rsU, ||X||_2^2=a, and ||Y||_2^2=Tr rU^dagger sU<=sqrt(Tr r^2 Tr s^2)=1. Hilbert-Schmidt Cauchy-Schwarz proves the claim. A primary paper also states f>=a>=f^2 explicitly: T. A. Hahn and E. Y.-Z. Tan, *Fidelity bounds for device-independent advantage distillation*, https://www.nature.com/articles/s41534-022-00635-y.

## 5. Remaining limits of the search

Ordinary data hiding does not directly address this interface: the broadcast errors are global trace distances and the channel is unrestricted. A symmetric extension of one state also does not provide a common channel preserving a pair. No explicit slow-dynamics, highly mixed, or correlated ladder family with epsilon->0 and liminf Delta>0 was identified. Those observations are search triage, not exclusion theorems.
