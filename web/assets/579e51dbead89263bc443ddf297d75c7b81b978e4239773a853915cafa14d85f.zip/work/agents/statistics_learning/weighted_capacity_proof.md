# Arbitrary-edge four-state Potts reconstruction and weighted cubic capacity

Status: independently derived source-dependent theorem candidate. Its sole release-specific probabilistic dependency is the four-state posterior cone closure and cubic saving in release 229, companion Proposition 3.2. The independent exact source-certificate replay completed successfully: scalar certificate and all24 coordinate actions passed; product row(a) `done4479 19 lp=2074 lt=166`; product row(b) `done1935 20 lp=871 lt=97`; both executables exited0 and all counts match the source. Only a nonportable C++ include was changed, with all arithmetic/tests/assertions retained. These exact finite source checks support the specified dependency; external proof validation and priority remain open. The argument below removes both the constant-channel and bounded-degree restrictions from the companion capacity paper.

Source pin: OpenAI/math adc7f1241b42e322a6451854ab7e4b4c146bf78a.

Source capacity theorem: `preprints/A-Capacity-Criterion-for-Four-State-Potts-Reconstruction-on-Trees-October-5-2026/build/main.tex`, Theorem 1.1, Proposition 2.1, Lemma 4.1, and Sections 3--5. Local copy: `sources/potts_capacity.tex`.

Source cone input: `preprints/The-Reconstruction-Threshold-for-the-Ferromagnetic-Four-State-Potts-Model-October-5-2026/build/sections/03-cone.tex`, Proposition 3.2, equations (3.8)--(3.9). Local copies are under the independently assigned `work/agents/potts_certificate_audit/sources/`.

Pinned source URLs:

- https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/A-Capacity-Criterion-for-Four-State-Potts-Reconstruction-on-Trees-October-5-2026/build/main.tex
- https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/The-Reconstruction-Threshold-for-the-Ferromagnetic-Four-State-Potts-Model-October-5-2026/build/sections/03-cone.tex

## Contract and theorem

Let T be any infinite locally finite rooted tree. No uniform upper degree bound is imposed. Every known edge e=(v,w) has a known parameter lambda_e in (0,1]. Give the root a uniform spin in {1,2,3,4}; transmit independently conditional on parents through

P_lambda(j|i)=lambda 1{i=j}+(1-lambda)/4.

Write r_e=lambda_e^2, R_root=1, and R_w=R_v r_e. Observe the spins at depth n and the entire known tree/channel description. Let a_n be the expected total variation of the root posterior from uniform. Data processing implies a_n decreases; reconstruction means lim a_n>0.

A flow theta is nonnegative, conserved at nonroot vertices, and has finite positive root mass m_theta. Define its weighted cubic path potential by

V(theta,xi) = sum_{e=(v,w) in xi} (1-r_e^2)(theta_e/R_w)^2
            = sum_{e=(v,w) in xi} theta_e^2 (R_w^{-2}-R_v^{-2}).

Conditional on the source cone theorem, reconstruction holds **if and only if** there exists such a positive-mass flow with sup_xi V(theta,xi)<infinity. By scaling, this is equivalent to a positive flow with every path potential at most one. Edges with lambda=1 contribute zero. Edges with lambda=0 can be deleted together with components separated from the root, since those components have no information about the root; the positive-flow criterion is then applied to the root component, if it is infinite.

For constant lambda in (0,1), the factor 1-lambda^4 is constant, recovering exactly the released unweighted L^3 criterion. On a single ray the criterion reduces to product_e lambda_e>0: the weighted potential of the constant flow theta telescopes to theta^2(R_infinity^{-2}-1). This repairs the decisive failure of the naive unweighted extension.

## Dependency: posterior calculus

For posterior p, use x=Lp with the source tetrahedral sign matrix; A=|x|^2=4|p-u|^2, m=E A, tau=E x_1x_2x_3, h=|tau|. Every finite subtree experiment belongs to the preserved source class C, including independently channel-degraded terminal observations. Products and every lambda in [0,1] preserve C. The source gives, for independent branches with quadratic informations a,b,

m_star <= a+b-c(a^2 b+a b^2), c=1/1000,

by Jensen applied to its stronger fourth-moment saving. Every partial product remains in C. Channel steps give m'=lambda^2 m and h'=lambda^3 h. Also 0<=m<=3 and h<=m.

For all symmetric posterior laws, even without channel smoothing, take the explicit finite absolute constant C=460 such that

m_star >= a+b-7(h_a b+a h_b),
h_star <= h_a+h_b+C ab.

The first inequality is source Lemma 4.1's exact quadratic cancellation. To extend its second inequality uniformly to lambda=1, use the source product coordinates Z=1+x.y and N_i=Z(LP)_i. Since the combined posterior P lies in the simplex, |N_i|<=Z. Therefore the remainder in replacing Z^{-2} by 1-2s, s=x.y, is bounded by

|N_1N_2N_3| s^2(3+2s)/Z^2 <= Z(3+2s)s^2 <= 36 s^2,

for s in [-1,3] and Z>=0. Its expectation is at most 12 ab. Each N_i has four monomials with coefficient absolute sum four; the coefficient absolute sum of N_1N_2N_3(1-2s) is at most 4^3(1+2*3)=448. Its pure terms are exactly tau_a+tau_b; every other surviving mixed monomial has degree at least two in each independent vector and contributes at most its absolute coefficient times ab. Terms with marginal degree one have zero expectation. Hence C=448+12=460 is a direct universal choice, with no large symbolic computation required. At Z=0 the weighted posterior integrand is its continuous extension zero. This removes the source's C(lambda) denominator dependence without a new probabilistic assumption.

## Necessity, with no uniform degree bound

Take the limiting quadratic information m_v from descendants of each vertex. Choose K=c/3=1/3000 and define y(m)=m+Km^3. Pairwise subadditivity follows immediately:

y(m_star) <= a+b-c ab(a+b)+K(a+b)^3
          <= y(a)+y(b),

because the mixed cubic coefficient is 3K-c<=0. Induct over the finite child set; there is no B^3 penalty. Channel scaling gives

y(r m)=r y(m)-K r(1-r^2)m^3.

Passing finite-depth informations to limits gives

y_v <= sum_w r_e y_w -K sum_w r_e(1-r_e^2)m_w^3.

Since y_w<=(1+9K)m_w, set delta=K/(1+9K)^3. Then

y_v <= sum_w r_e y_w[1-delta(1-r_e^2)y_w^2]
    <= sum_w r_e y_w /sqrt(1+2delta(1-r_e^2)y_w^2),

using (1+2t)^(-1/2)>=1-t for t>=0. Thus z_v=sqrt(2delta)y_v obeys

z_v <= sum_w r_e z_w/sqrt(1+(1-r_e^2)z_w^2).

Choose coefficients 0<=d_vw<=r_e/sqrt(1+(1-r_e^2)z_w^2) so z_v=sum_w d_vw z_w. Define ell_root=1, ell_w=ell_v d_vw, theta_e=ell_w z_w, and g_v=ell_v/R_v. Conservation and root mass z_root follow. Moreover

g_w^2[1+(1-r_e^2)z_w^2]<=g_v^2,
(1-r_e^2)(theta_e/R_w)^2 <=g_v^2-g_w^2.

The path potential telescopes to at most g_root^2=1. Reconstruction implies m_root>0, hence z_root>0. All sums are finite locally, so neither uniform degree nor compactness of a space of flows is needed.

## Sufficiency: use branch dissipation instead of a geometric depth kernel

Fix a flow theta with potential at most one and root mass b=m_theta>0. Scale it to Theta=eta theta. Define X_v=Theta_v/R_v, including X_root=eta b. On a positive-flow vertex set p_e=Theta_w/Theta_v; these sum to one, and

X_w=p_e X_v/lambda_e^2,
X_v=sum_w lambda_e^2 X_w.

Each positive-flow path extends to infinity. Since theta_w<=theta_v,

X_w^2 <=X_v^2+(1-lambda_e^4)X_w^2.

Telescoping on a path gives X_v^2<=eta^2(b^2+1). Thus every profile is uniformly small after choosing eta, even when an edge is nearly deterministic and its individual energy weight is tiny. Put U=eta sqrt(b^2+1), and choose eta so U<=1.

At level n, independently degrade spin v by channel t_v=sqrt(X_v/3). Then its information is exactly m_v=X_v and h_v<=X_v. For the resulting finite subtree experiments, source subadditivity implies m_v<=X_v. Let k_v=h_v/X_v on positive-flow vertices and s_v=1-sum_e p_e^2. The universal local estimates, merging branches successively, imply

k_v <= sum_e p_e lambda_e k_w +(C/2)X_v s_v,
D_v/X_v <=7X_v sum_e p_e lambda_e(1-p_e)k_w +(7C/2)X_v^2 s_v,

where D_v=sum_e lambda_e^2 m_w-m_v>=0. To see that the constants are independent of degree, branch profiles are b_e=lambda_e^2 X_w=p_e X_v. Newly generated third moments cost at most C sum_{e<f} b_e b_f=(C/2)X_v^2 s_v. The cross h terms are at most sum_e h_e sum_{f!=e} b_f=X_v sum_e(1-p_e)h_e. Generated third moments in the m-loss cost one further factor X_v. Zero-flow subtrees are uninformative after degradation and can be omitted.

Choose a random flow ray: at vertex v follow edge e with probability p_e. Its depth-i vertex is V_i. Conservation gives Pr(V_i=v)=Theta_v/(eta b). Telescoping the m-deficits over the finite tree yields

m_root/(eta b) =1-E_flow sum_{i<n} D_{V_i}/X_{V_i}.

Unroll the k-recursion along this random path. Define a_0=0 and

a_{i+1}=lambda_i[a_i+(1-p_i)X_i],
X_{i+1}=p_i X_i/lambda_i^2.

Then the total relative loss is bounded by

7 E[a_n k_n] +(7C/2) E sum_{i<n}(a_i X_i+X_i^2)s_{V_i}.

The last display is a finite-depth exact upper bound: a_i collects the earlier branch-loss factors and their channel propagation. The next identity bounds it uniformly in n without any uniform contraction in lambda.

## Quadratic occupation lemma

Let F(X,a)=X^2+aX+a^2/4. For X,a>=0, p in [0,1], and 0<lambda<=1, set X'=pX/lambda^2 and a'=lambda[a+(1-p)X]. Then

F(X',a')-F(X,a)
 <= -(3/4)(1-p)X^2 -(1/2)(1-p)aX
    +2(1-lambda^4)X'^2.                       (*)

At lambda=1, direct expansion gives

F(pX,a+(1-p)X)-F(X,a)
 =-(1-p)[(1-(1-p)/4)X^2+(1/2)aX],

which supplies the two negative terms. Comparing the general update with the lambda=1 update, put B=a+(1-p)X. The difference is

p^2(lambda^{-4}-1)X^2+p(lambda^{-1}-1)XB
 -(1/4)(1-lambda^2)B^2.

Completing the square bounds the last two terms by

p^2 (lambda^{-1}-1)^2 X^2/(1-lambda^2)
 <=p^2(lambda^{-4}-1)X^2.

The scalar inequality follows from

(lambda^{-1}-1)^2/(1-lambda^2)
 = (1-lambda)/(lambda^2(1+lambda))
 <= (1-lambda^4)/lambda^4.

At lambda=1 use the exact zero difference. This proves (*).

Conditional expectation over p_i replaces 1-p_i by s_{V_i}. Every flow ray has

sum_{i<n}(1-lambda_i^4)X_{i+1}^2<=eta^2.

Summing (*) and using F>=0 gives

E sum_{i<n}(a_i X_i+X_i^2)s_{V_i}
 <=2eta^2(b^2+2),
E F(X_n,a_n)<=eta^2(b^2+2),
E a_n<=2eta sqrt(b^2+2).

Since k_n<=1 at the terminal level, the relative information loss is at most

14eta sqrt(b^2+2)+7C eta^2(b^2+2).

For example choose eta=1/[128 sqrt(C+1) sqrt(b^2+2)]. Then U<=1 and the displayed relative-loss bound is strictly below 1/2. This choice depends only on the selected flow's finite mass b and the absolute local constant C, never on n or the tree's degree/channel supremum. Therefore

m_root >=eta b/2>0 at every depth n,
a_n>=m_root/8>=eta b/16.

The undegraded observations have at least this information by data processing. Reconstruction follows. The degraded experiments can vary with n; no limit law or common compatible family is assumed.

## Acquisition, execution, and unresolved status

The theorem assumes the known tree and edge channels, exactly as the release. Existence of an infinite finite-energy flow is a characterization, not a uniform terminating recognition or acquisition algorithm. The positivity criterion may be undecidable for an arbitrary computable infinite tree. On a finite supplied tree, local posterior evaluation costs O(|T|) arithmetic operations and finite-channel bit precision must still be charged; the theorem does not turn an implicit infinite input into a finite learner.

The release-specific polynomial sign certificates are exact finite claims whose independent replays completed successfully, as recorded above and in `work/agents/potts_certificate_audit/AUDIT.md`/`provenance.json`. The occupation lemma and the pairwise y-subadditivity improvement are new direct derivations here; they do not depend on interpreting a thermodynamic limit as finite computation. Prior-art comparison with arbitrary-channel Ising/nonlinear-capacity literature remains required before a novelty claim. Exact local rational diagnostics of the occupation identity, the weighted telescoping identity, deterministic edges, near-deterministic rays, and the degree-free subadditivity are in `check_weighted_occupation.py` and `check_weighted_occupation_results.json`. These finite diagnostics are scoped evidence, not the general proof.

Primary prior-art handles checked live: Pemantle--Peres, *The critical Ising model on trees, concave recursions and nonlinear capacity*, https://arxiv.org/abs/math/0503137 and author PDF https://www2.math.upenn.edu/~pemantle/papers/crit-ising.pdf . Their Theorems 2.1--2.2 distinguish free-boundary L^2 from plus-boundary L^3, with edge biases bounded away from one via bounded interactions. Their edge-subdivision discussion removes the lower interaction bound but explicitly retains the upper one. This is relevant precedent for nonlinear capacity and near-deterministic obstructions, not a four-state arbitrary-edge theorem. Mossel--Sly--Sohn, *Exact Phase Transitions for Stochastic Block Models and Reconstruction on Trees*, https://arxiv.org/abs/2212.03362 , establishes 3/4-state KS sharpness at sufficiently large average degree, not the all-tree weighted statement here. The brief targeted search found no prior exact four-state arbitrary-edge criterion, but that is not a completed priority search.

## Failure ledger and next escalation

1. Naive arbitrary-edge unweighted capacity is false: ray lambda_n=1-2^{-n-1} has positive product and reconstructs, but every nonzero constant flow has divergent unweighted sum. The weighted increment criterion fixes it exactly.
2. Source's C(lambda) h-bound appeared to force lambda_max<1. Bounding the Bayes numerator by the normalizer removes that dependence.
3. Source's geometric depth convolution fails near deterministic edges. Actual branch factors 1-p and the quadratic occupation identity replace it.
4. Source's B^3 max-pair necessity loses arbitrary locally finite degrees. Pairwise subadditivity of m+Km^3 removes that loss.
5. No unrestricted HMM acquisition consequence follows: a known channel/tree representation is supplied here.
6. Candidate further consequence: marked-Poisson four-state reconstruction exact threshold kappa=sum_l c_l lambda_l^2>1, and through an audited labeled-tree/SBM coupling an exact finite-label assortative 4-community weak-recovery threshold. That graph composition is not proved in this note.
7. Negative/signed channels are not covered: applying lambda=-1/3 to the revealing q4 posterior gives H=-1409/24300<0 exactly, outside the preserved cone. Replacing lambda by its absolute value is not a legal inference.
