# Statistical learning / optimization intake and cost ledger

## Selected changed premise

The Oct5 release229 companion provides an explicit preserved posterior class for ferromagnetic four-state Potts experiments, including all positive channel parameters, with uniform cubic information saving under every conditionally independent product. The accompanying capacity paper only translates it to constant lambda<1 and bounded-degree known trees. The source's translation incurs B^3 in necessity and 1/(1-lambda) in sufficiency.

The new direct argument replaces those costs by pairwise subadditivity of m+Km^3, a universal third-moment product estimate, and a flow-ray quadratic occupation identity. This removes uniform degree and channel-contraction bounds, and gives the exact weighted increment potential that survives deterministic edges and arbitrary edge subdivision. Full note: weighted_capacity_proof.md.

## Considered and rejected shortcuts

- SK full support/QAOA (release281): local sk_algorithm.tex expressly invokes the existing El Alaoui--Montanari--Sellke algorithm with supplied scalar functions and normalization constants. It gives C(epsilon)n^2 real-arithmetic instance complexity, with no numerical preprocessing or bit-complexity estimate. The source main.tex also explicitly cites Chen2026 as proving the same full-support conclusion. Importing this corollary does not remove representation acquisition or establish a new efficient angle/compiler procedure. No mixed-spin or nonzero-field consequence was claimed here.
- Gaussian streaming lower bounds (release140): the catalogue shows exact Gaussian measurements, finite classical persistent bits, terminal-state output, and unrestricted computation. It is a lower bound in a different interface, not an HMM synthesis/acquisition tool. Decisive proof mechanisms were not fully audited in this branch; no quantum or general-learning transfer is claimed.
- Log-concave sampling (release139): catalogue and main source preserve a supplied minimizer, exact first-order queries, unrestricted between-query computation, and fixed TV1/10 accuracy. No full sampling proof was acquired here, so no runtime or posterior-acquisition result follows.
- Marked-SBM escalation: a marked-Poisson posterior subadditivity proof suggests the threshold sum_l c_l lambda_l^2, but the exact tree/graph coupling and algorithmic achievability for labeled four-community models were not independently established. The deterministic weighted-capacity theorem does not prove this graph claim.

## Costs and legal input

The positive theorem is mathematical, not a complete learn-and-deploy algorithm. The complete deterministic tree and channel parameters are supplied; boundary spins are the actual statistical observations. Existence of an infinite finite-energy flow is not its efficient discovery. Arbitrary computable infinite-tree positivity need not admit finite recognition. No terminal label, target-specific advice, or optimum is acquired for free by naming this characterization.

For a finite explicitly supplied tree, standard four-state belief propagation evaluates a realized posterior in O(number of edges) arithmetic operations. Large products require stable log representation and a charged precision budget in a bit model. The current proof imposes no robustness promise for unknown channel parameters at criticality.

Research work used local source retrieval and exact CPU-only arithmetic. Source acquisition used gh api at the pinned OpenAI commit. No installs, costly jobs, publication, messages to people, or push occurred. Two delegated audit tasks, including the child's numerical adversarial task, independently checked the release polynomial inequalities and the extension; their outcomes remain scoped evidence.

## Provenance and unresolved scientific gates

- OpenAI source pin: adc7f1241b42e322a6451854ab7e4b4c146bf78a.
- Original posterior polynomial certificates: exact scalar replay and all24 coordinate actions passed; global row(a) passed `done4479 19 lp=2074 lt=166`; global row(b) passed `done1935 20 lp=871 lt=97`; both processes exited0 and matched source counts. Current exact status is maintained in work/agents/potts_certificate_audit/AUDIT.md and provenance.json. The only portability edit replaced GCC's bits/stdc++.h with explicit standard-library includes; no arithmetic or tests changed.
- Independent extension audit: work/agents/weighted_capacity_audit/AUDIT.md found no gap across local finiteness, finite branches, near-zero/deterministic channels, zero-edge pruning, all-depth comparisons, and occupation algebra.
- Own exact diagnostics: check_weighted_occupation_results.json, 2880 occupation instances and961 degree-free subadditivity instances; these are diagnostic checks, not a proof substitute.
- Primary prior art: Pemantle--Peres2010, Theorems2.1--2.2 and Corollary3.5; Evans--Kenyon--Peres--Schulman2000; Mossel--Sly--Sohn2025. Nonlinear p-loss capacity classification is already known. A targeted search did not locate the specific four-state unrestricted-edge weighted criterion, but a completed priority search or external proof review has not occurred.

## Strongest continuation

Audit the source posterior polynomial certificate to completion and perform broader prior-art comparison of the exact unrestricted-edge q4 criterion. The abstract note isolates why a common eigenvalue, symmetry, reversibility, or a first local Taylor term does not certify a general capacity exponent. A concrete next extension needs a preserved posterior algebra and a finite auxiliary hierarchy with an occupation potential; identifying only a dominant linear spectral radius is insufficient.
