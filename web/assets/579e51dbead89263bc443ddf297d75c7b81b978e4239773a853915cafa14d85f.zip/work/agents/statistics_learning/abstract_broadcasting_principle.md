# What an exact nonlinear-loss capacity principle needs

Status: direct abstract theorem under explicit uniform hypotheses; not a generic Potts/asymmetric-channel theorem. This separates the transferable mechanism from unsupported inference based on a Taylor expansion at the uninformative posterior. Generic scalar power-loss capacity classification is prior art: Pemantle--Peres (2010), Corollary 3.5, gives L^p capacity from a bounded increasing scalar recursion f(x)=ax-Theta(x^p) near zero together with the global strict contraction 0<f(x)<ax. Our statement formulates sufficient uniform Bayesian-composition hypotheses and the arbitrary-edge clock; it is not presented as discovery of the general p-loss principle.

## Uniform scalar-loss theorem

Fix p>1 and put q=p-1. An experiment class E has an information statistic m in [0,M], with m=0 precisely at the uninformative law, satisfying:

1. An associative Bayes product of conditionally independent experiments preserves E. Empty observation has m=0.
2. Every channel step S_r, 0<r<=1, preserves E and scales m exactly by r. Such channels may vary by edge of any known locally finite tree.
3. There are absolute constants 0<c<=C<infinity such that for every pair of experiments in E with informations a,b,

   c B_p(a,b) <= a+b-m(product) <= C B_p(a,b),
   B_p(a,b)=(a+b)^p-a^p-b^p.

4. For every sufficiently small x>0 there is a legal independently degraded terminal experiment in E with information exactly x. The natural fully observed terminal experiment dominates these experiments. The root reconstruction criterion is equivalent to positive limiting m.

Then for every supplied tree/channel environment, reconstruction is equivalent to existence of a finite positive-mass flow theta such that

sup_rays sum_{e=(v,w)} (1-r_e^q)(theta_e/R_w)^q <infinity,
R_root=1, R_w=R_v r_e.

This is weighted L^p nonlinear capacity: the path-potential exponent is p-1. If r_e=lambda_e^2, the clock is exactly 1-lambda_e^{2(p-1)}. The principle concerns a uniform compositional loss bound. A first nonzero local Taylor coefficient is not one of its hypotheses.

## Necessity

Let y(m)=m+K m^p with 0<K<=c. Since m(product)<=a+b,

y(m(product)) <=a+b-cB_p(a,b)+K(a+b)^p
              <=y(a)+y(b).

Iterate over each finite child set. A channel gives

y(rm)=r y(m)-K r(1-r^q)m^p.

Since y(m)<=(1+KM^q)m, setting delta=K/(1+KM^q)^p gives

y_v<=sum_w r_e y_w[1-delta(1-r_e^q)y_w^q].

The tangent inequality (1+t)^(-1/q)>=1-t/q yields the recurrence for z=(q delta)^(1/q)y:

z_v<=sum_w r_e z_w/[1+(1-r_e^q)z_w^q]^(1/q).

Choose coefficients d_vw within the displayed upper bounds so z_v=sum_w d_vw z_w, define ell and theta as in the q4 proof, and put g=ell/R. Then

(1-r_e^q)(theta_e/R_w)^q <=g_v^q-g_w^q.

The potential telescopes. There is no uniform degree dependence.

## Sufficiency

Scale a unit-energy flow theta by eta>0. Put X_v=eta theta_v/R_v, and p_e=theta_w/theta_v at positive-flow vertices. Every flow ray satisfies

X_w=p_e X_v/r_e,
X_w^q<=X_v^q+(1-r_e^q)X_w^q,
X_v^q<=eta^q(b^q+1),

where b is the root mass of theta. Choose eta so all profiles fit the legal terminal range. At any finite depth use terminal experiments of information X_v. Upper product subadditivity ensures deployed information <=X_v throughout.

At a parent, sequential lower product bounds and monotonicity of B_p give a deficit

D_v<=C[(sum_e r_e X_w)^p-sum_e(r_e X_w)^p]
    =C X_v^p(1-sum_e p_e^p).

To justify monotonicity, partial deployed information is at most the sum of prior branch profiles; B_p(a,b) is increasing in a,b for p>1. The successive B_p terms of the profiles telescope exactly to total power minus the sum of branch powers.

Follow a random flow ray, choosing edge e with probability p_e. The exact scalar occupation identity is

X_v^q-E[X_w^q|v]+E[(1-r_e^q)X_w^q|v]
 =X_v^q(1-sum_e p_e^p).

Summation and nonnegativity imply

E sum_{i<n} X_i^q(1-sum p_e^p) <=eta^q(b^q+1).

The root relative information deficit is at most C times this quantity. Choose eta small enough to make it <=1/2; positive root information survives uniformly in depth. This completes the abstract theorem.

## Exact positive control: binary symmetric broadcasting

For a uniform binary input, write a posterior's magnetization x in [-1,1]. A symmetric posterior law is invariant under x->-x; m=E x^2. Channels scale x by lambda, hence m by r=lambda^2. Independent Bayes products have posterior (x+y)/(1+xy) and marginal weight 1+xy.

Conditioning on magnitudes u=|x|,v=|y| and averaging the independent signs gives

m_product integrand=(u^2+v^2-2u^2v^2)/(1-u^2v^2).

The information loss relative to u^2+v^2 is

u^2v^2(2-u^2-v^2)/(1-u^2v^2).

Its ratio to u^2v^2 lies between 1 and 2. The lower bound is (1-u^2)(1-v^2)>=0; the upper bound is u^2+v^2>=2u^2v^2. The corner u=v=1 is interpreted by its legitimate Bayes product, with loss one. Therefore ab<=a+b-m_product<=2ab after averaging magnitudes.

For p=2, B_2=2ab, so the uniform scalar-loss theorem applies with c=1/2 and C=1. Legal terminals use an extra binary channel lambda=sqrt(x). The capacity clock is 1-lambda_e^2, and the path energy is

sum_e(1-lambda_e^2)theta_e/R_w
 =sum_e theta_e(R_w^-1-R_v^-1).

This is the known electrical/free-boundary mechanism, not a new binary reconstruction claim. Primary prior-art handle: Evans--Kenyon--Peres--Schulman, *Broadcasting on trees and the Ising model* (2000), and Pemantle--Peres (2010), https://arxiv.org/abs/math/0503137 . The weighted arbitrary-edge formulation should be checked against the precise earlier electrical resistance convention before any priority statement.

## Why q4 cubic saving needs its auxiliary statistic

The q4 source class contains revealing and uninformative experiments, and observed input-independent mixtures. Reveal the true symbol with probability t and otherwise reveal only an erasure marker. Its m is 3t. Combining two such experiments reveals the root whenever either succeeds, so

m_product=3(2t-t^2),
a+b-m_product=3t^2=ab/3,
B_3(a,b)=3ab(a+b)=162t^3.

Thus no finite C bounds the loss by C B_3 uniformly as t->0, even inside the source class. The source cubic **upper information** bound alone is a one-sided inequality. It does not establish a two-sided cubic scalar-loss principle.

The weighted q4 proof succeeds through h=|E x_1x_2x_3|, its exact lambda^3 scaling, uniform product generation h_star<=h_a+h_b+C ab, and the quadratic occupation variable a. That additional state remembers the shape information which m alone loses. It is essential to the proof, not a decorative rephrasing of the local cubic term.

## Symmetry and a common eigenvalue alone do not suffice

For a uniform three-symbol input, take an observation that excludes one randomly selected incorrect symbol. The posterior is uniform on two of three symbols; its permutation-symmetric law has m=3|p-u|^2=1/2. Independently compose two such experiments. Under independent marginal posterior laws, the excluded symbols match with probability1/3: normalization Z=3/2 and posterior m=1/2. They differ with probability2/3: normalization Z=3/4 and the posterior is a point mass with m=2. Consequently

m_product=(1/3)(3/2)(1/2)+(2/3)(3/4)(2)=5/4>1=a+b.

Raw quadratic information is synergistic. This example is a legal Bayesian experiment and a symmetric posterior law; it need not lie in a special class generated only from ferromagnetic reveal/channel/product operations. Hence a preserved class or a different calibrated statistic must be supplied and proved. Local symmetry, reversibility, and a dominant nontrivial eigenvalue do not by themselves imply the abstract hypotheses.

## Multi-type and asymmetric limits

An exact four-state separation already rules out a universal answer based only on the leading eigenvalue and Kesten--Stigum clock. On a spherically symmetric tree choose level sizes N_n comparable to 2^n(n+1)^beta, with beta in (1/2,1]. Such a bounded-degree tree is obtained by branching by two except at sparse levels where one branches by four: set k_n=floor(beta log_2(n+1)) and branch factor d_n=2^{1+k_n-k_{n-1}}. These factors are two or four, and N_n=2^n2^{k_n}. Put lambda=1/sqrt(2).

For the isotropic four-state Potts channel, the weighted cubic criterion yields reconstruction because its equally splitting flow has energy comparable to sum_n n^{-2beta}<infinity. The equal-split flow minimizes the supremum path energy on a spherically symmetric tree: any alternative flow has a ray whose depth-n flow is at least its mass/N_n, obtained by selecting at each vertex a child of largest flow. Necessity therefore identifies the same series.

Compare a different reversible uniform four-state channel: identify a state with two independent bits, and flip each bit independently through the binary symmetric channel with eigenvalue lambda. This four-state channel has eigenvalues 1,lambda,lambda,lambda^2 and the same leading nontrivial eigenvalue lambda. The two bit-broadcast processes, including root bits, are independent. Each bit's weighted electrical criterion requires sum_n n^{-beta}<infinity, which fails for beta<=1. Their joint posterior is the product of the two bit posteriors, and its TV error from the uniform product is at most the sum of the two marginal TV errors. Thus the joint four-state process does not reconstruct.

The models share the state count, stationary law, reversibility, leading eigenvalue, underlying tree, and exponential KS critical boundary, yet have opposite reconstruction outcomes. The decisive distinction is the Bayes-product algebra and nonlinear loss, not the exponential growth rate. In the independent-bit model the product character's eigenvalue is lambda^2; in isotropic Potts all three nontrivial tetrahedral characters have eigenvalue lambda. This prevents a generic transfer from isotropic four-state cancellation to arbitrary reversible channels.

A proposed extension to arbitrary reversible channels must first identify: (i) a common compositional information statistic, (ii) exact channel contraction on that statistic, (iii) a preserved class of realizable posterior laws, and (iv) a uniform two-sided loss or an explicit finite auxiliary hierarchy with an occupation potential. A matrix of linear contractions or a first Taylor tensor supplies none of these by itself. Different eigenspaces can generate each other through Bayes products; projecting onto the leading eigenspace may discard a nonlinear sufficient statistic. No general asymmetric/reversible theorem follows from the proof above.

Strongest next mathematically concrete attack: replace the scalar contraction r with a finite family of commuting contraction operators whose product-algebra closes, and attempt a matrix-valued occupation potential. Four-state tetrahedral characters already have x_i*x_j=x_k at the latent spin; generic multi-type eigenvectors need not have this closure. An exact algebraic closure and positivity criterion is the missing hypothesis, not a computationally free change of basis.
