# Quantum statistical experiments: exact mechanisms and scope

Date: 7 October 2026. Status: direct mathematical derivations with independent internal audit; no external correctness or priority certification. Completed results include interacting collective-experiment transfer, informative-scale classicalization under asymptotically conserved spin, a charged polynomial-time 1D quantum archive, sharp logarithmic Gibbs continuity order, an exact unequal-mode Gaussian reconstruction threshold, and finite near-tracial/pairwise-compatible families with maximal classical-reconstruction failure. These are derived results and compositions of imported primary theorems; no historical-calibre advance or solution of local critical universality is asserted.

## 1. The changed premise and the two serious targets

The current primary preprint [Pilatowsky-Cameo, Styliaris, Bakshi, Malz, arXiv:2609.35973v1](https://arxiv.org/html/2609.35973v1), Theorems 1–2 and Corollary 1, gives an exact block-product mixture for every bounded-range 1D Gibbs state at any fixed positive temperature and a polynomial-time approximate sampler of the pure-state mixture. The stated block/depth bound is double exponential in inverse temperature, with a range constant itself exponential in range. This is a real changed preparation premise. Its mixture and sampling circuit depend on the supplied Hamiltonian. It does not provide a parameter-independent measurement that preserves an unknown-Hamiltonian experiment.

Target A: a strong, full-density statistical reduction for interacting local Gibbs families, rather than another archive exponent. Exact SU(2) conservation permits a complete proof for collective fields and anisotropies. Approximate conservation and local-intensive perturbation replacement are the substantive escalation mechanisms below.

Target B: the exact boundary between thermal/preparation simplicity and inferential classicalization. A connected cluster-chain example obstructs inference from locally maximally mixed marginals. Growing-dimension accumulation was completed using an exact collective multimode Gaussian EB benchmark, followed by published fixed-d LAN and an existential diagonal sequence; see Section 6B.

## 2. Whole-experiment transfer from any SU(2)-invariant reference

Let the known faithful reference on a finite spin system be

    omega_N = direct_sum_j q_N(j) [I_(2j+1)/(2j+1) tensor xi_(N,j)].

The multiplicity state xi_(N,j) can be arbitrarily entangled. Permutation symmetry, locality, dimension of the multiplicity spaces and an identity multiplicity state are NOT assumptions. The representation and conditional reference states are supplied public data; acquiring or preparing them is charged separately.

Let a_N tend to infinity, R_N=j/a_N converge weakly under q_N to a known law q on [0,infinity), and for some delta>0 assume

    sup_N E_qN exp[(M+delta) R_N^2 + (B+delta) R_N] < infinity.

Unknown parameters range over real symmetric A with ||A||op<=M and vectors b with |b|<=B. Put

    H_N(A,b)=Q_A(J)/a_N^2 + b.J/a_N,
    Q_A(J)=sum_(i,k) A_ik (J_i J_k+J_k J_i)/2,
    rho_N(A,b)=omega_N exp(H_N(A,b))/Tr[omega_N exp(H_N(A,b))].

The product is valid because exact reference invariance implies [omega_N,H_N]=0. The entire experiment is uniformly equivalent, via fixed parameter-independent channels in both directions, to one sample (R,U) with reference q(dR) times uniform sphere measure and likelihood

    exp[R^2 U^T A U + R b.U] / Z(A,b).

Atoms, singular q, q=delta_m, and mass at R=0 are allowed. The reverse channel reconstructs the entire quantum density including xi_(N,j), not only magnetization moments. Error is O(a_N^(-1/2)) + o(1), where the unspecified o(1) is radial-coupling error; no rate follows from weak radial convergence alone.

### Proof: quantum reconstruction

In each spin-j factor apply the coherent measure-and-prepare channel B_j, and act as identity on multiplicity. The block-pinched map Bcal is unital and trace-preserving, preserves log omega_N, and acts on collective tensor ranks 1,2 with exact multipliers

    lambda_1=j/(j+1),
    lambda_2=j(2j-1)/[(j+1)(2j+3)].

The actual classical encoder discards multiplicity and its decoder resets it to known xi_j. That physical composition need not be unital on arbitrary input matrices. It agrees with Bcal ON THE GIVEN FAMILY; this distinction is essential.

For every unital trace-preserving CP map Bcal and tau=e^K/Tr e^K, operator Jensen for log gives

    D(tau||Bcal(tau)) <= Tr tau(K-Bcal(K)).

There is no exponentiation of a noncommuting operator inequality. With A0=A-(tr A)I/3, the exact tensor multipliers and ||Q_A0||<=||A0||j(j+1) imply

    D(rho_N||Bcal(rho_N))
      <= 3||A0|| E_rhoN[j]/a_N^2 + |b|/a_N
      = O(1/a_N).

The exponential slack gives the required uniformly bounded tilted E[j/a_N]. Pinsker yields trace distance O(a_N^(-1/2)).

### Proof: encoded law and radial coupling

The coherent measurement density in sector j is q_N(j) <j,U|e^Hj|j,U>/Z. Exact lower/upper symbols are

    h_j^- = c j(j+1)/a_N^2
             + j(j-1/2) U^T A0 U/a_N^2 + j b.U/a_N,
    h_j^+ = c j(j+1)/a_N^2
             + (j+1)(j+3/2) U^T A0 U/a_N^2
             + (j+1)b.U/a_N,
    c=tr A/3.

Scalar Jensen gives <U|e^Hj|U> >= e^(h_j^-); scalar Jensen applied to each eigenvector with the coherent resolution gives Tr e^Hj/(2j+1) <= integral e^(h_j^+). Both symbols differ from h(R_N,U)=R_N^2 U^TAU+R_N b.U by O((1+R_N)/a_N). Summation with exponential slack gives uniform O(1/a_N) TV approximation of the encoded law by its ideal classical tilt.

Choose a parameter-independent monotone/quantile coupling Gamma_N between q_N and q. Weak convergence implies R_N-R tends to zero in probability under this coupling. Exponential slack implies uniform integrability of the weights and, by compactness/equicontinuity of the parameter class,

    sup_(A,b) E_GammaN,mu |e^h(R_N,U)-e^h(R,U)| -> 0.

Use the two disintegrations of Gamma_N as the forward/backward radial Markov kernels. Atoms require this two-kernel construction; exact recovery of j after transport is not claimed. Preparing P_(j,U) tensor xi_j after the backward kernel completes the reverse channel. Normalizers stay bounded away from zero, so the weight L1 discrepancy bounds both TV deficiencies.

Independent proof: collective_universality_audit/AUDIT.md and its radial_transport/RADIAL_TRANSPORT_AUDIT.txt. No finite calculation is being substituted for this proof.

## 3. Approximate conservation: no total-Hamiltonian norm restriction

For omega=e^(-beta H)/Z and Hermitian A,

    ||[sqrt(omega),A]||HS^2
       <= (beta^2/4) Tr omega [H,A]^dagger[H,A].

Proof in the H eigenbasis: with p_i=e^(-beta E_i)/Z,

    (sqrt(p_i)-sqrt(p_j))^2/(p_i+p_j)
       = 1-sech(beta(E_i-E_j)/2)
       <= beta^2(E_i-E_j)^2/8.

The symmetric sum over p_i+p_j equals twice the omega-weighted squared commutator norm. This is an elementary Wigner–Yanase/energy estimate; historical priority is not asserted.

For a lattice spin system H_N=H_N^inv + lambda_N sum_x v_x, where H_N^inv is SU(2)-invariant, each v_x has uniformly bounded norm and support, and bounded overlap holds, set A_i=J_i/(NS) (spin S fixed). Then

    ||[H_N,A_i]||op = O(lambda_N),
    ||[A_i,A_j]||_(2,omegaN) = O(1/N).

Thus N39's near-modular commuting-grid archive sufficiency (or the independently reconstructed general_classicality theorem) applies to the bounded unknown macro-field Gibbs family exp(log omega_N+sum b_i A_i), fixed |b|_1<=R, whenever lambda_N->0. This allows N lambda_N->infinity; no trace-distance closeness between the known anisotropic and invariant references is required. The criterion is sufficient and not necessary. At the informative J/sqrt(N) fluctuation scale, one additionally needs uniform thermal tail/concentration and connected-correlation control; Section 6A proves these at sufficiently high temperature rather than inferring them from this macro-scale estimate.

## 4. Local intensive perturbations can be replaced in reference L2

Here is a useful exact Gibbs transfer lemma. Let omega be faithful, [B,omega]=0, and A,B be Hermitian with ||A||,||B||<=C. Define rho_A=e^(log omega+A)/Z_A and rho_B analog, D=A-B, epsilon=Tr omega D^2. Then

    D(rho_B||rho_A) <= e^(2C) k(C) epsilon,
    T(rho_A,rho_B) <= sqrt[e^(2C) k(C) epsilon/2],
    k(C)=(e^(2C)-1-2C)/(4C^2), with k(0)=1/2.

Proof: relative entropy equals log Tr exp(log rho_B+D) - Tr rho_B D. Golden–Thompson bounds the trace by Tr rho_B e^D. Scalar spectral calculus gives e^D<=I+D+k(C)D^2 for ||D||<=2C, and log y<=y-1 gives D(rho_B||rho_A)<=k(C)Tr rho_B D^2. Commutation and bounded B imply rho_B<=e^(2C)omega. Pinsker finishes. Neither A nor D need commute with omega or B. The constant can be optimized by centering D; it is already independent of Hilbert dimension and the least reference eigenvalue.

Therefore unknown physical weak local perturbations A_N(theta)=sum_x local_v_(theta,x)/N admit full-experiment replacement by a collective central polynomial B_N(theta)=f_theta(J/N), provided the following explicit load-bearing condition is proved:

    sup_theta Tr omega_N [A_N(theta)-B_N(theta)]^2 -> 0.

Combined with Section 2 this transfers a local Hamiltonian perturbation experiment to the classical order-parameter experiment. If this conditional self-averaging variance is O(1/N), the additional trace error is O(N^(-1/2)), even though the generator difference need not tend to zero in operator norm. Spherical magnetization moments alone do not prove this L2 condition for local anisotropy; phase uniqueness/completeness and local observable self-averaging remain separate hypotheses.

Independent direct proof and general noncentral logarithmic alternative: gibbs_l2_audit/CONTINUITY_PROOF.md. The central comparison is the relevant strongest version for a reference-commuting approximant.

For arbitrary noncentral A,B, the same audit derived and independently checked the sharp dimension-independent DECAY ORDER. Put L=log(4C^2/epsilon). Then

    T(rho_A,rho_B)
      <=min{1, e^(3C/2)(1+C/4)sqrt(epsilon)
                +2C^2(C+2)e^(2C)/(L+C)^2}.

Weighted Schatten interpolation and a telescoped Dyson expansion provide the upper bound. A faithful qubit reference diag(1-p,p), common off-diagonal perturbation C/sqrt(3), and rare diagonals +/-2C/3 give T~[4C^2/(3sqrt(3))]/log^2(1/epsilon), so no positive-power uniform Holder modulus in reference L2 exists generally. A qutrit improves the lower coefficient to C^2; the sharp coefficient across all dimensions remains open. The exact general modulus priority is unresolved, and standard machinery is explicitly cited in that audit.

## 5. Release271: exact dependency and unproved physical escalation

Reopened source [spherical magnetization preprint](https://github.com/openai/math/tree/main/preprints/The-spherical-magnetization-law-for-the-three-dimensional-quantum-Heisenberg-ferromagnet-October-5-2026/build/sections). Section 08-global-spin.tex proves j_L/V->m in probability from the local second-moment lower bound, pressure upper tails and support [0,S]. This directly supplies Section 2's radial premise with a_N=V and q=delta_m, conditional on the source theorem's correctness. The new classical family becomes the Fisher–Bingham sphere experiment

    p_(A,b)(U) proportional exp[m^2 U^T A U + m b.U].

Its quadratic anisotropy and field do not commute before taking the limit. The scalar trace component of A is unidentifiable at the fixed-radius limit because it adds the same constant m^2 tr(A)/3 to every log likelihood. Whole-state density information about that bounded collective isotropic quadratic perturbation therefore vanishes in this scale.

No attempt here validates source271's hard spatial comparison and equilibrium-radius arguments. The source does not establish that all local bond-anisotropy intensive observables are L2 functions of the total magnetization direction. Consequently the physical weak-local-anisotropy corollary remains conditional at precisely that named condition. General local-lattice critical radial fluctuations, efficient 3D conditional reference preparation, and strong quantum LAN for arbitrary noncommuting unknown local couplings remain open here.

## 6. Failure ledger and consequence limits

* Exact block separability, constant-depth known-Hamiltonian preparation and thermal area laws do not imply strong classical sufficiency for an unknown Hamiltonian. Nontracial product qubits already obstruct that inference; the boundary audit has a geometrically connected three-site cluster-interaction variant with every one-site marginal I/2.
* Vanishing pairwise tangent symplectic form alone does not imply whole-experiment classicalization: modularly generated conjugate observables can retain quantum information. N39 explicitly includes this obstruction.
* Direct raw TV convergence of discrete sector radius to a continuous radius is impossible. The two classical transport kernels solve the correct experiment deficiency problem.
* The multiplicity-reset decoder is not generally unital; use the spin-only unital map for Jensen and establish equality on the family.
* Scalar anisotropy at a deterministic radius is an ancillary normalization and cannot create another inference coordinate.
* Full-density approximation transfers every bounded decision problem and later POVM with additive trace-error bounds. It does not clone independent samples of the limiting classical experiment. Marginal broadcasting is possible; iid cloning is a different task.
* No circuit/runtime benefit follows from abstract CPTP channels when the known multiplicity reference states and radial couplings are supplied without efficient acquisition/preparation.
* Fixed-d near-tracial results are not dimension-uniform. The growing-d Gaussian-EB accumulation lower was subsequently completed and independently audited; see the addendum below. It remains an internally derived theorem, not external certification.

Strongest next attack: prove the local intensive anisotropy reference-L2 reduction in the released low-temperature Heisenberg model, or exhibit two ergodic equilibrium phases with the same magnetization direction but different local anisotropy means. That exact observation decides whether Section 4 yields a new full local-field experiment or only a conditional transfer theorem.

## 6A. Completed informative-scale high-temperature local extension

boundary_audit/noncentral_fluctuation_theorem.md proves a substantive escalation beyond exact SU(2) backgrounds. For arbitrary known omega_N, let A_i=(J_i-E_omega J_i)/sqrt(N). If all centered exponential moments are uniform, ||[sqrt(omega_N),A_i]||HS->0, and Tr omega_N J^2/N^2->0, then the entire family exp(log omega_N+b.J/sqrt(N)), fixed |b|_1<=R, admits vanishing-error EB reconstruction and an N-independent finite classical alphabet at each fixed requested error. Noncentral Gibbs entropy controls tail clipping; ordinary HS functional calculus contracts the Wigner–Yanase defect; a smooth-clipping approximation plus total-spin cutoff closes weighted pair commutators. No Gaussian limit theorem is needed.

For H_N(lambda)=H_N^inv+lambda V_N with fixed few-body order q and common bounded local strength g_*, choose beta<1/(8e^3 g_* q). Then any lambda_N->0 speed satisfies those hypotheses: Theorem 1 of Kuwahara–Saito supplies centered concentration of J_i,V_N,i[V_N,J_i]; exact thermal commutator expectation zero and the energy-WY estimate give defect O(lambda_N); Kubo–Mori susceptibility bounds give E J_i/N=O(lambda_N); hence E J^2/N^2=O(1/N+lambda_N^2). N lambda_N and sqrt(N)lambda_N may diverge. These unknown magnetic fields have the informative 1/sqrt(N) scale, not merely the 1/N macrofield scale.

Source correction: Kuwahara–Saito's Corollary 1 proof equation (17) has an apparent missing factor two in completing the square. The local extension uses only their Theorem 1 MGF bound and independently derives the conservative valid tail 2exp[-(beta_c-beta)x^2/(8 Fbar)] and variance <=16Fbar/(beta_c-beta). This repairs constants without changing the qualitative theorem or beta threshold.

No necessity in lambda is claimed for every perturbation. A fixed Zeeman one-body perturbation and transverse local fields yields the faithful nontracial qubit LAN experiment with positive EB floor, showing the hypothesis cannot be discarded in an unrestricted theorem.

## 6B. Completed dimension-growing boundary and local obstruction

The independently audited assembly boundary_audit/growing_dimension/COUNTEREXAMPLE.md constructs faithful distinct spectra p_n on d_n->infinity with ||d_n diag(p_n)-I||op->0 while optimal EB reconstruction of the unknown FULL eigenbasis iid orbit has error->1. The construction permits d_n slower than any prescribed diverging function of n by enlarging existential sample thresholds; no useful dimension-uniform n(d) rate is supplied.

The key exact lemma in growing_dimension/gaussian_eb_lower/EXACT_MULTIMODE_EB_BENCHMARK.md permits arbitrary collective EB strategies and proves minimax error on m independent thermal displacement modes equals TV(NB_m(Nthermal),NB_m(Nthermal+1)). Finite-volume displacement averaging yields a possibly subnormalized normal covariant map, and escaped mass only strengthens the finite photon-cutoff witness. Complete copositivity yields a gain-two amplifier seed representation. A thermal amplifier decomposes into pure loss plus quantum-limited amplification; arbitrary correlated Fock seeds stochastically dominate vacuum total photon number. Thus no naive one-mode tensorization is used. The exact threshold is m/Nthermal^2: it gives nonzero floor for a positive limit and error->1 when it diverges.

Two near-degenerate spectral clusters furnish m approximately d^2/4 and Nthermal approximately1/(2delta). Published FIXED-d strong LAN, tiny distinct-spectrum perturbations and a diagonal sequence convert the exact benchmark into the iid orbit obstruction. This is a direct composition of old primary theorems and newly assembled proof steps; priority has not been cleared. Matching upper conditions and retained quantum-dimension lower bounds remain open.

The connected cluster-chain construction boundary_audit/dimer_counterexample.md has every physical one-site marginal exactly I/2 for all unknown parameters, yet a one-parameter interaction perturbation is fixed-Clifford-equivalent to nontracial iid logical qubits and has a positive full-experiment EB floor. The local Hamiltonian is geometrically connected and commuting at each fixed parameter. This exact counterexample rejects local-marginal traciality, spatial thermal separability or a one-dimensional tangent symplectic form as sufficient criteria.

## 6C. Completed efficient preparation transfer

EFFICIENT_1D_ARCHIVE.md gives a concrete composition of the new 1D Gibbs sampler with efficient Schur circuits, a positive finite coherent POVM and coarse-grid archive. For known exactly SU(2)-invariant high-temperature 1D reference and fields b.J/sqrt(N), retained classical label count depends only on requested error; full-state error is O_R(N^(-1/4))+grid error+tilted tail+implementation error. Decoder rejection-samples the known reference, measures j while RETAINING the already prepared conditional multiplicity state, replaces the spin coherent state and reverses Schur. This avoids separately acquiring xi_j. Capping rejection trials and a hybrid error argument handle arbitrarily rare cells. Gates/preprocessing/reference calls are charged polynomially in N and 1/epsilon at fixed beta/range/R, under standard polynomial-bit public Hamiltonian descriptions; beta constants can be double exponential. This is a quantum-device implementation theorem, not a local classical simulator. Independent audit collective_universality_audit/EFFICIENT_ARCHIVE_AUDIT.md returned PASS after the explicit cap and rounded-coordinate repairs. It verifies the exact radial tail 4exp[-(beta_c-beta)t^2/16] and raw-label cost <=1+Mexp[R(L+zeta)].

## 6D. Current primary-literature boundary

[Rounding Almost Commuting Hamiltonians, arXiv:2605.26096](https://arxiv.org/html/2605.26096), especially Section 6.2, studies local operator-norm rounding and Gibbs sampling. That interface differs from the weighted-L2/modular full-experiment conditions here; the bounded current search is not priority clearance.

[Classical Sufficiency in Quantum Statistical Experiments, Lahiry, arXiv:2609.29348v1](https://arxiv.org/html/2609.29348v1), introduction Section 1.2, explicitly distinguishes Blackwell sufficiency of prescribed invariant measurements for selected statistical functionals from full quantum-state recovery/Petz sufficiency. Its Schur block-label spectral sufficiency and thermal negative-binomial residual-photon laws are relevant comparison points, but do not by themselves subsume the unknown full-orbit reconstruction contract or the collective EB benchmark used in Section 6B. This source's proof was not audited. Exact novelty of every derived result remains open.

## 6E. Exact unequal thermal threshold and intrinsic pairwise boundary

UNEQUAL_THERMAL_THRESHOLD.md and independent gibbs_l2_audit/UNEQUAL_THERMAL_BENCHMARK_AUDIT.md extend the collective Gaussian benchmark to arbitrary known unequal thermal means n_i>=0. The exact minimax EB/PPT reconstruction error is TV(tensor_i Geom(n_i),tensor_i Geom(n_i+1)). The optimal witness is the finite-rank weighted photon likelihood region, which is coordinatewise decreasing. For arbitrary correlated/entangled seeds, phase twirling followed by a simultaneous coordinatewise Fock-amplifier coupling shows that this region's probability is maximized by vacuum. This closes the collective lower bound without a one-mode tensorization assumption.

For s=sum_i(n_i+1)^(-2), the exact bounds are

    1-exp(-s/8)<=error<=sqrt(1-2^(-s)).

Hence error->0 iff s->0, and error->1 iff s->infinity. If min_i n_i->infinity and s->c in (0,infinity), a direct triangular-array likelihood CLT gives error->2Phi(sqrt(c)/2)-1. A fixed cold mode invalidates that critical Gaussian profile even though the exact TV formula/bounds remain true. In fixed-d qudit LAN, s=sum_(i<j)[(p_i-p_j)/p_i]^2; near-tracial p_i=(1+u_i)/d give s~d sum_i u_i^2. This applies to the LAN oscillator experiment; any finite-n or growing-d qudit consequence separately charges LAN/localization errors and cannot assume uniform LAN rates.

boundary_audit/PAIRWISE_ENTROPY_BOUNDARY.md completes finite-dimensional FINITE experiments of faithful states with sup_pair[F_root-Tr(sqrt(rho)sqrt(sigma))]->0 but arbitrary collective EB reconstruction error->1. For equal thermal means n and m=n^3, the exact supremum pair gap is (kappa-1)kappa^[-kappa/(kappa-1)]<=1/(eD^2)~1/(16en^2), D=(sqrt(n+1)+sqrt(n))^2, kappa=1+D^(-2), independent of m. Finite-box localization, Fock leakage n^-12 and finite 1/n nets preserve both limits. An explicit binary displacement code remains exponentially trace-distance separated after projection. Thus compactness alone does not suffice; uniform covering entropy matters. This provides a physical smooth thermal counterpart to general_classicality's mutually-unbiased-basis obstruction, and is compatible with its intrinsic criterion under uniform metric entropy.

For unequal thermal means the exact pairwise defect likewise depends only on kappa_*=max_i[1+(sqrt(n_i+1)+sqrt(n_i))^(-4)]: its supremum is (kappa_*-1)kappa_*^[-kappa_*/(kappa_*-1)]. If the coldest mode heats, this is asymptotic to max_i(n_i+1)^(-2)/(16e). Independent audit confirmed this last optimization. The full experiment therefore tests the SUM of inverse squared thermal means, while any single pair tests only their MAXIMUM.

Finite diagnostics: check_bridges.py passed 400 random matrix fixtures for energy-WY and central-comparator KL constants. bridge_diagnostics.json records the scope; these calculations do not prove the general results. Other branch diagnostics accompany their proof files.

## 7. Provenance handles

* Astra cards N20, N39 and N02 downloaded to this directory, current on 7 October 2026. N20 complete source: [gibbs_criticality.md, d-75e02546d30c2d83](https://harjassand.github.io/astra-research-knowledge/web/pages/d-75e02546d30c2d83.html); independent original audit: [d-e52dcc61c4754c0b](https://harjassand.github.io/astra-research-knowledge/web/pages/d-e52dcc61c4754c0b.html).
* Exact coherent multipliers and semiclassical channel machinery are established prior art: [Aschieri–Ruba–Solovej 2024](https://link.springer.com/article/10.1007/s00220-024-05178-1), Theorem 1 and Lemma 12.
* Trace-norm coherent Gibbs approximation is old: [Davies 1979](https://doi.org/10.1017/S0305004100056383). No priority claim for Section 2's isolated classicalization mechanism.
* Golden–Thompson/Gibbs variational foundations and bounded perturbation entropy inequalities are standard; [Two-sided Bogoliubov inequality, 2022](https://link.springer.com/article/10.1007/s11005-022-01586-3), Section 4, is a relevant primary reference. Section 4 is an explicit derived corollary, not a claimed new inequality.
* Memory quick pass used MEMORY.md lines 44–99 only for prior audit map/status. All substantive mathematics above was rederived/reopened this run; prior memory status remained provisional.
