# Dimension-independent Gibbs continuity from reference weighted L2

Status: self-contained finite-dimensional internal proof, checked by two independent adversarial audits. No priority claim or claim about efficient Gibbs preparation. Natural logarithms throughout; T(rho,sigma)=||rho-sigma||_1/2.

## Interface

Let omega be a faithful density matrix on an arbitrary finite-dimensional Hilbert space. Let A,B be Hermitian and ||A||,||B|| <= C, with C>0. Put D=A-B, epsilon=Tr(omega D^2), and rho_V=exp(log omega+V)/Z_V. All bounds below are uniform in Hilbert-space dimension and in the eigenvalues of omega.

If epsilon=0 then faithfulness implies D=0. The nontrivial case is 0<epsilon<4C^2. Set L=log(4C^2/epsilon) and lambda=L/2.

**General continuity theorem (strongest elementary constant obtained).**

T(rho_A,rho_B)
 <= min{1, e^(3C/2)(1+C/4) sqrt(epsilon)
   +2C^2(C+2)e^(2C)/(L+C)^2}.

Section 9 gives the stronger Hilbert-Schmidt interpolation that proves this bound. Sections 1-3 first give the simpler, still sufficient proof and explicit integral:

T(rho_A,rho_B)
 <= min{1, e^C sqrt(epsilon)
   +2 C^2 e^C integral_0^1 r[2+C(1-r)] exp[C(1-r)-lambda r] dr}
 <= min{1, e^C sqrt(epsilon)+8C^2(C+2)e^(2C)/L^2}.

Consequently the worst-case modulus is O_C(log(1/epsilon)^(-2)). The exact two-dimensional family below supplies an Omega_C(log(1/epsilon)^(-2)) obstruction, so this order is sharp over all finite dimensions. There cannot be a uniform positive-power Holder bound in epsilon without further assumptions.

## 1. Weighted Schatten estimate

For a,b>=0, r=a+b<=1, and q=||D||, the estimate needed is

||omega^a D omega^b||_(1/r) <= q^(1-r) epsilon^(r/2). (1)

The r=0 case means the operator norm. Zero D is trivial. First,

||D omega||_1 <= ||D sqrt(omega)||_2 ||sqrt(omega)||_2 = sqrt(epsilon),

and the same bound holds for ||omega D||_1 by taking adjoints, using D=D*. Apply the three-lines theorem, at fixed Schatten norm 1, to F(z)=omega^z D omega^(1-z) on 0<=Re z<=1. On either boundary, the imaginary powers of omega are unitaries and do not change the trace norm. Therefore

||omega^u D omega^(1-u)||_1 <= sqrt(epsilon), 0<=u<=1. (2)

For r>0, put u=a/r and apply the Schatten interpolation theorem to

G(z)=omega^(uz) D omega^((1-u)z).

On Re z=0, its operator norm is q. On Re z=1, (2) bounds its trace norm by sqrt(epsilon). Evaluation at z=r gives (1), since 1/p_r=r. Finite-dimensional analyticity and boundedness on the closed strip are immediate. The imaginary factors are exterior unitary factors even on Re z=1; they are not incorrectly commuted through D.

## 2. Dyson expansion and why two powers give log squared

Write H=log omega. For V bounded,

exp(H+V) = sum_(n>=0) integral_(Delta_n)
 omega^(s_0) V omega^(s_1) ... V omega^(s_n) ds,

where Delta_n={s_i>=0, sum_(i=0)^n s_i=1}, equipped with the usual n-dimensional simplex measure of mass 1/n!. This formula is the time-ordered Duhamel expansion. Its convergence in trace norm is uniform here: Schatten Holder gives each n-th integrand norm <=C^n, because ||omega^s||_(1/s)=(Tr omega)^s=1. Thus the n-th term has norm <=C^n/n!.

Subtract the A and B expansions and telescope the n inserted perturbations. There are n summands, each containing one D, with A before it and B after it. If D occupies position k, its two adjacent reference powers are omega^(s_(k-1)) and omega^(s_k). Put r=s_(k-1)+s_k. Isolate these three factors and apply (1), then Schatten Holder to all remaining factors. Their omega exponents sum to 1-r; bounded A/B insertions use Schatten infinity. Hence

||integrand||_1 <= C^(n-1) q^(1-r) epsilon^(r/2)
 <= C^(n-1) (2C) exp(-lambda r). (3)

There is no need to control omega transported by exp(H+A), and no incorrect operator-monotonicity assumption for exp.

For n=1, r=1 identically, so the entire difference term has norm <=sqrt(epsilon). For every n>=2 and every position k,

integral_(Delta_n) exp(-lambda r) ds
 = 1/(n-2)! integral_0^1 r(1-r)^(n-2) exp(-lambda r) dr. (4)

The factor r is the length of the split of r into its two adjacent nonnegative coordinates. The remaining n-1 coordinates have fixed sum 1-r and simplex volume (1-r)^(n-2)/(n-2)!. For lambda=0, (4) equals 1/n!, checking normalization.

Sum (3)-(4), using q<=2C and n placements:

||exp(H+A)-exp(H+B)||_1
 <= sqrt(epsilon)+2C^2 integral_0^1
 r[2+C(1-r)] exp[C(1-r)-lambda r] dr. (5)

Indeed sum_(n>=2) n C^(n-2)(1-r)^(n-2)/(n-2)!
 =[2+C(1-r)] exp[C(1-r)]. The integral in (5) is at most

(C+2)e^C integral_0^infinity r exp(-lambda r)dr
 =(C+2)e^C/lambda^2.

## 3. Normalization

Since -CI<=V<=CI, the monotonicity of Tr exp, or the min-max theorem for eigenvalues, gives e^(-C)<=Z_V<=e^C. For positive E,F with traces Z_E,Z_F,

||E/Z_E-F/Z_F||_1
 <= ||E-F||_1/Z_E+|Z_E-Z_F|/Z_E
 <=2||E-F||_1/Z_E.

Therefore T(rho_A,rho_B)<=e^C||exp(H+A)-exp(H+B)||_1. Combine with (5) and lambda=L/2 to obtain the theorem. The displayed constants are deliberately conservative; the logarithmic exponent is sharp.

## 4. A stronger central-comparator corollary

If [B,omega]=0, then rho_B=omega exp(B)/Z_B<=e^(2C)omega in Loewner order. This condition places no restriction on [A,omega] or [A,B]. More generally, it is enough that rho_B<=K omega for a supplied K.

Set kappa_C=(exp(2C)-1-2C)/(4C^2), continuously kappa_0=1/2. Scalar Taylor's integral remainder shows e^x<=1+x+kappa_C x^2 for |x|<=2C, hence this holds for D by functional calculus. Golden-Thompson gives

Z_A/Z_B =Tr exp(log rho_B+D) <=Tr rho_B exp(D).

Thus

D(rho_B||rho_A)
 =log(Z_A/Z_B)-Tr rho_B D
 <=log[1+Tr rho_B D+kappa_C Tr rho_B D^2]-Tr rho_B D
 <=kappa_C Tr rho_B D^2
 <=K kappa_C epsilon. (6)

The bracket is positive because it bounds the positive Tr rho_B exp(D) from above, and log(1+x)<=x for x>-1. Pinsker gives

T(rho_A,rho_B)<=sqrt(K kappa_C epsilon/2).

For [B,omega]=0 one can take K=e^(2C). Therefore central or reference-commuting polynomial approximants yield an O_C(sqrt(epsilon)) whole-state estimate directly. This is much stronger than the generic optimal logarithmic modulus. The assumption must be checked for the actual approximant.

## 5. Audit of the originally supplied entropy lemma

Every V_t=B+tD has norm <=C by convexity. log Z_t lies in [-C,C], so D(rho_t||omega)=Tr rho_t V_t-log Z_t<=2C. The measurement with binary effect Q=D^2/(4C^2) sends omega to Bernoulli(p), p=epsilon/(4C^2), and rho_t to Bernoulli(x_t). Data processing and d(x||p)>=x log(1/p)-log2 give

Tr rho_t D^2<=4C^2(2C+log2)/L.

The symmetrized endpoint relative entropy is integral_0^1 Var_BKM,rho_t(D) dt and the BKM variance is at most Tr rho_t D^2. These steps are correct. Because each relative-entropy direction is >=2T^2, their sum is >=4T^2. Thus the original bound improves to

T<=C sqrt((2C+log2)/L).

The originally supplied coefficient sqrt(2) times this is still a valid conservative bound. The argument requires 0<p<1 to have a positive finite denominator; p=0 is handled separately and p=1 by the trivial T<=1 bound. It is dimension independent but weaker than Sections 1-3.

## 6. Exact two-dimensional obstruction

For 0<p<1/2, let omega_p=diag(1-p,p), b=C/sqrt(3), a=2C/3,

A=[[0,b],[b,a]], B=[[0,b],[b,-a]].

Both norms are exactly C (spectra {C,-C/3} and {C/3,-C}). D=diag(0,4C/3), hence epsilon_p=(16C^2/9)p. Put ell=log((1-p)/p), and h_+=(ell-a)/2, h_-=(ell+a)/2, r_+/-=sqrt(b^2+h_+/-^2). Their Bloch vectors are

v_+=(b,0,h_+) tanh(r_+)/r_+,
v_-=(b,0,h_-) tanh(r_-)/r_-.

The exact trace distance is T=|v_+-v_-|/2. Since tanh r=1+O(exp(-ell)) and the transverse difference is 2b(2a)/ell^2+O(ell^-4), while the longitudinal difference is O(ell^-3),

ell^2 T ->2ab=4C^2/(3sqrt(3)).

Because ell=log(1/epsilon_p)+O_C(1), this is the matching order obstruction. The child qubit audit also proposes that this constant is the sharp supremum asymptotic in dimension two; see its own proof rather than inferring a universal all-dimension constant here.

## 7. Statistical-experiment consequence and remaining premise

For arbitrary finite-dimensional omega_N, unknown parameter theta, uniformly bounded A_(N,theta), B_(N,theta) by fixed C, if sup_theta Tr omega_N(A_(N,theta)-B_(N,theta))^2 ->0, then sup_theta T(rho_A,rho_B)->0. Identity channels in both directions make the two experiments asymptotically equivalent in trace-distance deficiency. With [B_(N,theta),omega_N]=0 the error is <=sqrt(e^(2C)kappa_C epsilon_N/2).

No acquisition, preparation, or global weak-to-local convergence statement follows from this continuity theorem alone. In the intended intensive local-perturbation application, the load-bearing remaining premise is the actual uniform weighted-L2 approximation by the bounded central polynomial, plus its exact commutation with omega_N if the fast rate is claimed. Proving an operator norm error that scales like N eta is unnecessary once this premise holds.

## 8. Sources and novelty boundary

The proof uses standard matrix mechanisms. Sutter, Berta and Tomamichel, *Multivariate Trace Inequalities*, arXiv:1604.03023v3, Introduction Eq. (1), states Golden-Thompson; Section 3.1, Theorem 3.1, supplies Schatten complex interpolation in a stronger Stein-Hirschman form. Primary full text: https://arxiv.org/html/1604.03023 . The Dyson expansion is standard bounded perturbation theory for Gibbs semigroups; related primary source: Boulton and Dimoudis, *Norm-ideal perturbations of one-parameter semigroups and applications*, JFA 2023, DOI https://doi.org/10.1016/j.jfa.2022.109784 , arXiv:2202.02768v2, Section 3 Eq. (6)-(7) and Theorem 3.1. Primary full text: https://arxiv.org/html/2202.02768 . This establishes nearby norm-ideal/Dyson theory, not this exact weighted-L2 optimal modulus. A targeted web search did not locate this exact theorem or sharp log-squared modulus; that is not a priority clearance.

Failure ledger: no flaw found in original entropy method; it loses rate by replacing bounded Hamiltonian perturbations with a generic entropy-ball transport bound and then using Pinsker. A proposed uniform positive-power modulus without a commutation or density-domination premise is refuted by Section 6. No runtime/preparation novelty claimed.

Strongest next attack: prove the uniform L2 local-to-central replacement for the actual spin/lattice background and bounded parameter set, retaining any finite-volume/boundary assumptions. The central-comparator corollary turns that premise directly into whole-experiment equivalence at its square-root rate.

## 9. Sharper general constant from the Hilbert-Schmidt endpoint

The key stronger estimate, with q=2C and L=log(q^2/epsilon), is

||omega^a D omega^b||_(1/r)
 <=q exp[-L min(r,1/2)], r=a+b in [0,1]. (7)

For r=1/2, first use the three-lines theorem in Schatten norm 2 on F(z)=omega^(z/2)D omega^((1-z)/2). Both boundary norms are sqrt(epsilon), because D is Hermitian. Therefore every split of total reference exponent 1/2 has Hilbert-Schmidt norm <=sqrt(epsilon).

For 0<r<1/2, let u=a/r and use Schatten interpolation on G(z)=omega^(u z/2)D omega^((1-u)z/2), between Schatten infinity at Re z=0 and Schatten 2 at Re z=1. Evaluate at z=2r. This gives

||omega^a D omega^b||_(1/r)<=||D||^(1-2r)epsilon^r<=q exp(-Lr).

For r>1/2, factor

omega^a D omega^b
 =omega^(a-a/(2r)) [omega^(a/(2r))D omega^(b/(2r))] omega^(b-b/(2r)).

The bracket has Schatten 2 norm <=sqrt(epsilon). The exterior reference exponents sum to r-1/2. Schatten Holder gives norm 1/r <=sqrt(epsilon)=q exp(-L/2). This proves (7).

Repeating the exact Dyson summation of Section 2 gives the improved integral

||exp(H+A)-exp(H+B)||_1
 <=sqrt(epsilon)+2C^2 integral_0^1
 r[2+C(1-r)]exp[C(1-r)-L min(r,1/2)]dr. (8)

For an elementary closed bound, first note the full-integral identity

C integral_0^1 r[2+C(1-r)] exp[C(1-r)]dr=e^C-1.

Using the global bound exp[-L min(r,1/2)]<=exp(-Lr)+exp(-L/2) would give a constant tail plus first-order term <=e^C sqrt(epsilon). A better split uses the exact high-r identity

C integral_(1/2)^1 r[2+C(1-r)]exp[C(1-r)]dr=e^(C/2)(1+C/4)-1.

Hence the constant tail plus first-order term is <=e^(C/2)(1+C/4)sqrt(epsilon). The low-r decaying contribution satisfies

2C^2 integral_0^1 r[2+C(1-r)]exp[C(1-r)-Lr]dr
 <=2C^2(C+2)e^C integral_0^infinity r exp[-(L+C)r]dr
 =2C^2(C+2)e^C/(L+C)^2.

Normalize as in Section 3 to obtain the headline theorem. The exact integral (8) can be used for tighter finite-epsilon numerical evaluation. The headline bound is also valid at epsilon=4C^2 (L=0), even though the weaker proof in Sections 1-3 and the entropy proof require L>0.

Additional obstruction: the qubit child supplies a qutrit family with leading constant C^2, larger than the sharp qubit constant. Thus the precise all-dimension optimal leading constant remains open even though the logarithmic order is settled by matching upper/lower bounds. See qubit_obstruction/qutrit_stronger_constant.md.

## 10. Finite diagnostic scope and independent audit records

The executable check_matrix_bounds.py uses only NumPy and saves matrix_diagnostics.json. With seed 714231 it checked 300 random Gibbs pairs in dimensions 2,3,5,9,16 and 2400 weighted Schatten inequalities, with reference log-eigenvalue spans up to 80. Maximum left/right ratios were 0.9948895902094933 for the weighted Schatten bound, 0.192083873857037 for the headline generic Gibbs bound, and 0.5469382899582194 for the commuting-comparator corollary. Quibit exact-family scaled values approach 4/(3sqrt(3)); at gap 500 the value is 0.769797621850403 versus predicted 0.769800358919501. These checks are finite diagnostics only. A first implementation directly raised singular values to large Schatten exponents and overflowed; rescaling by the largest singular value fixed the numerical issue before the successful check.

Independent direct proof records are under dyson_adversary/ and qubit_obstruction/qubit_upper/DIMENSION_FREE_DYSON_AUDIT.md. The sharp qubit supremum proof is qubit_obstruction/qubit_upper/SHARP_QUBIT_MODULUS.md. All child models were GPT-6.1-sol with ultra reasoning, as required. No external mathematical certification is claimed from those reviews.
