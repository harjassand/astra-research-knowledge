# Exact qubit obstruction for weighted-L2 Gibbs continuity

Status: direct elementary derivation, with an independent analytic upper-bound audit in `qubit_upper/`. No novelty or external validation claim is made.

## Contract

Fix C > 0. Let omega be a faithful density matrix on C^2 and A,B be Hermitian with ||A||,||B|| <= C. Define

    epsilon = Tr omega (A-B)^2,
    rho_A = exp(log omega + A) / Tr exp(log omega + A),
    T = (1/2) ||rho_A-rho_B||_1.

Logarithms are natural. Let F_C(epsilon) be the supremum of T over this contract with weighted-L2 cost at most epsilon. The exact asymptotic qubit modulus is

    F_C(epsilon) = [4 C^2/(3 sqrt(3)) + o(1)] / log(1/epsilon)^2.

This note derives the lower bound and the optimization of its leading constant. The independently written matching uniform upper proof is in `qubit_upper/SHARP_QUBIT_MODULUS.md`.

## Exact family

Put v=C/sqrt(3), d=2C/3, and let 0<q<1/2. Take

    omega_q = diag(1-q,q),
    A = [[0,v],[v,d]],
    B = [[0,v],[v,-d]].

A has eigenvalues C,-C/3 and B has eigenvalues C/3,-C. Thus their operator norms are exactly C. The weighted discrepancy is exactly

    epsilon_q = Tr omega_q diag(0,(2d)^2) = (16 C^2/9) q.

In particular, choose q=9 epsilon/(16 C^2). This remains faithful for every positive sufficiently small epsilon.

Let L=log((1-q)/q) and set

    R_plus  = sqrt((L-d)^2+4v^2),
    R_minus = sqrt((L+d)^2+4v^2),
    t_plus=tanh(R_plus/2), t_minus=tanh(R_minus/2).

Scalar shifts of a Hamiltonian disappear after normalization. The Pauli exponential identity therefore gives the exact Bloch vectors

    r_A = t_plus  * (2v,0,L-d)/R_plus,
    r_B = t_minus * (2v,0,L+d)/R_minus.

For qubits, T=|r_A-r_B|/2. Equivalently, set

    theta_plus=atan2(2v,L-d),
    theta_minus=atan2(2v,L+d),
    Delta=theta_plus-theta_minus.

Then the exact trace distance is

    T_q = (1/2) sqrt((t_plus-t_minus)^2
                     +4 t_plus t_minus sin(Delta/2)^2).

This is numerically stable even when q is so tiny that q itself underflows.

## Direct asymptotic proof

For fixed v,d and L tending to infinity,

    t_plus,t_minus = 1+O_C(exp(-L)),
    Delta = 4vd/L^2 + O_C(L^-4).

For the latter identity, integrate the exact derivative

    d/dx atan2(2v,x) = -2v/(x^2+4v^2)

from x=L-d to x=L+d, and expand the denominator symmetrically. Consequently

    T_q = sin(Delta/2)+O_C(exp(-L))
        = 2vd/L^2 + O_C(L^-4)+O_C(exp(-L))
        = [4 C^2/(3 sqrt(3))]/L^2 + O_C(L^-4).

The middle approximation can also be justified without cancellation: each mixed Gibbs state is at trace distance (1-t)/2 <= exp(-R) from the corresponding pure state with the same Bloch direction, so the trace-distance error is <=exp(-R_plus)+exp(-R_minus).

Since epsilon_q=(16 C^2/9)/(1+exp(L)),

    log(1/epsilon_q) = L-log(16 C^2/9)+log(1+exp(-L))

and log(1/epsilon_q)/L tends to one. Hence

    lim epsilon_q -> 0 log(1/epsilon_q)^2 T_q
        = 4 C^2/(3 sqrt(3)).

This exact two-dimensional family rules out every dimension-independent bound o(log(1/epsilon)^-2), in particular every positive power O(epsilon^alpha), alpha>0. It does not by itself give a dimension-independent upper bound; the separate parent audit supplies that part if its proof survives.

## Why the leading constant is optimized among invisible-diagonal families

In the omega eigenbasis, write the common visible entries as a in R and c in C, and the rare diagonal entries as y and z:

    A=[[a,c],[conj(c),y]], B=[[a,c],[conj(c),z]].

For |a|<C, the two semidefinite constraints C I +/- A >= 0 put y in precisely the interval

    -C+|c|^2/(C+a) <= y <= C-|c|^2/(C-a).

The same interval contains z. Its length is

    2C * [1-|c|^2/(C^2-a^2)].

Thus

    |c| |y-z| <= 2C |c| [1-|c|^2/(C^2-a^2)]
               <= [4C/(3sqrt(3))] sqrt(C^2-a^2)
               <= 4C^2/(3sqrt(3)).

The first maximization has |c|=sqrt(C^2-a^2)/sqrt(3); the second has a=0. Both interval endpoints are attained by the exact family above. Boundary cases |a|=C force c=0 and contribute zero.

For shared a,c, exact Bloch differentiation shows the leading trace change is |c||y-z|/L^2. The optimized constant therefore equals the family's 2vd coefficient.

## Source and failure ledger

Read and obeyed the local research protocol and scientific intake files before calculation. The protocol's state and quantifier distinctions are preserved here.

Web searches for quantum Gibbs continuity and Kubo-Mori perturbation bounds returned local many-body stability and entropic-continuity work, but did not identify this exact weighted-L2 unrestricted-reference contract or its sharp qubit modulus. This search is insufficient for novelty clearance. Primary adjacent source inspected at search-result level: Capel, Moscolari, Teufel, Wessel, *From Decay of Correlations to Locality and Stability of the Gibbs State*, https://www.repository.cam.ac.uk/handle/1810/378991 . Its stated contract concerns local perturbations and correlation decay, so it is not used in this proof.

Rejected interpretation: epsilon -> 0 does not force ||A-B|| -> 0 uniformly over faithful omega; the rare diagonal difference here remains 4C/3.

Rejected estimate: a common offdiagonal coupling produces a Gibbs eigenvector angle O(C/L), but the difference between the two Gibbs states is a derivative with respect to the rare diagonal gap and is O(C^2/L^2). Counting only the angle of either state gives the wrong obstruction exponent.

Numerical verification is restricted to checking the exact formula and asymptotic constant; it is not a proof or priority certificate.

Strongest next attack: audit the dimension-independent Dyson/Schatten interpolation upper bound, then identify whether its leading constant can be sharpened to this qubit value or whether higher dimensions yield a larger leading constant.
