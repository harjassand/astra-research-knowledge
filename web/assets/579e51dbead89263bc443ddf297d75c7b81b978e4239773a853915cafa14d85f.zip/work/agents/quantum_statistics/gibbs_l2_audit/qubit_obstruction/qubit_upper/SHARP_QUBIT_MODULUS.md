# Sharp qubit Gibbs modulus under reference-weighted L2 error

This is a self-contained analytic derivation, not a claim about prior art or external validation. All logarithms are natural. The upper-bound argument does not need an assumed limit or a numerical fit.

## Statement

Fix C > 0. For a faithful qubit density matrix omega and Hermitian 2 by 2 matrices A and B with operator norms at most C, put

    rho_A = exp(log(omega) + A) / Tr exp(log(omega) + A),
    E = Tr omega (A-B)^2,
    T = (1/2) ||rho_A-rho_B||_1.

Define the worst modulus

    F_C(eps) = sup { T : E <= eps, ||A||,||B|| <= C,
                         omega faithful qubit density }.

Then the argument below proves

    lim_{eps -> 0} [log(1/eps)]^2 F_C(eps)
        = 4 C^2 / (3 sqrt(3)).

The same constant holds if E=eps is required. C=0 is trivial, with F_0=0.

## 1. Exact reduction and a uniform Lipschitz estimate

By simultaneous unitary conjugation, take

    omega = diag(1-q,q),  0 < q <= 1/2,
    A = [[a,c],[conj(c),d]],
    B = [[b,e],[conj(e),f]].

For x=a-b, z=c-e, y=d-f, direct multiplication gives

    E = (1-q)x^2 + |z|^2 + q y^2.                 (1)

Thus, if E<=eps,

    |x| <= sqrt(2 eps),  |z| <= sqrt(eps),
    |y| <= sqrt(eps/q).

The normalized Gibbs map G(H)=exp(H)/Tr exp(H) satisfies, for arbitrary finite-dimensional Hermitian H and D,

    (1/2)||G(H+D)-G(H)||_1 <= ||D||_op.          (2)

Indeed, along H+sD its derivative is

    d rho/ds = integral_0^1 rho^(1-u) D rho^u du
                 - rho Tr(rho D).

Schatten Holder gives ||rho^(1-u) D rho^u||_1 <= ||D||_op, because Tr(rho)=1. The second summand has trace norm at most ||D||_op. Integrating therefore proves (2). Endpoints u=0 and u=1 follow from the usual limiting exponents. This proof is independent of the smallest eigenvalue of omega.

## 2. The sharp geometric coefficient

Suppose matrices

    X_d=[[a,c],[conj(c),d]], X_f=[[a,c],[conj(c),f]]

both have norm at most K. Write t=|c|. If |a|=K then positivity of K I +/- X forces t=0, so t|d-f|=0.

For |a|<K, positivity of K I +/- X gives

    -K + t^2/(K+a) <= d,f <= K - t^2/(K-a).

Consequently

    |d-f| <= 2K [1 - t^2/(K^2-a^2)].           (3)

The interval is nonempty, so 0<=t<=sqrt(K^2-a^2). Write u=t/sqrt(K^2-a^2) in [0,1]. Then

    t|d-f| <= 2K sqrt(K^2-a^2) u(1-u^2)
               <= 4 K^2/(3 sqrt(3)).             (4)

Here the scalar maximum is u=1/sqrt(3), and sqrt(K^2-a^2)<=K. Equality is possible at a=0, t=K/sqrt(3), and d=-f=2K/3. No additional Bloch or density constraint is being imposed on A or B: they are bounded Hermitian perturbations.

## 3. Uniform large-gap estimate

Fix shared a,c and vary the rare diagonal v between d and f. Set

    L = log((1-q)/q),
    Delta(v) = L+a-v,
    s(v) = sqrt(Delta(v)^2+4t^2),
    tau(v) = tanh(s(v)/2),
    n(v) = (2 Re(c), -2 Im(c), Delta(v))/s(v).

The Gibbs density has Bloch vector r(v)=tau(v)n(v). If ||X_v||<=K along the segment, then |a|,|v|<=K. For L>2K, Delta(v)>=L-2K>0.

Since n has unit norm, n and n' are orthogonal. Exact differentiation gives

    ||n'(v)|| = 2t/s(v)^2,
    |tau'(v)| = |Delta(v)|/(2s(v)) sech^2(s(v)/2).

For qubits the trace distance is half the Euclidean Bloch-vector distance. Hence its infinitesimal speed is

    (1/2)||r'(v)||
      = sqrt[ t^2 tau(v)^2 / s(v)^4
                + Delta(v)^2 sech^4(s(v)/2)/(16s(v)^2) ]
      <= t/(L-2K)^2 + exp(-(L-2K)).             (5)

The last step uses tau<=1, |Delta|/s<=1, and

    (1/4) sech^2(s/2) = exp(-s)/(1+exp(-s))^2 <= exp(-s).

Integrating along the v segment and using (4) and |d-f|<=2K yields

    T(G(log omega+X_d),G(log omega+X_f))
       <= [4 K^2/(3 sqrt(3))]/(L-2K)^2
            + 2K exp(-L+2K).                    (6)

The matrix norm bound holds throughout the segment by convexity of the operator-norm ball.

## 4. Removing unequal common entries

For the original A,B, let

    B' = [[a,c],[conj(c),f]],
    eta = (sqrt(2)+1) sqrt(eps),
    K = C+eta.

The difference B'-B has norm at most |x|+|z|<=eta. Therefore ||B'||<=K, and A also has norm at most K. Formula (2) gives

    T(rho_B,rho_B') <= eta.

Combining with (6), whenever L>2K,

    T(rho_A,rho_B)
       <= eta + [4 K^2/(3 sqrt(3))]/(L-2K)^2
                 + 2K exp(-L+2K).               (7)

This step avoids assuming A and B share entries and incurs only a term exponentially small on the logarithmic scale of interest.

## 5. Uniform small-eps bound and limsup

Put ell=log(1/eps), fix any delta in (0,1), and split all admissible q into two cases.

If q>=eps^(1-delta), (1) and (2) imply

    T <= ||A-B|| <= eta + eps^(delta/2).         (8)

If q<eps^(1-delta), then

    L >= (1-delta) ell - log(2) =: L_0.

For all sufficiently small eps, L_0>2K, so (7) yields

    T <= eta + [4 K^2/(3 sqrt(3))]/(L_0-2K)^2
                 + 4K exp(2K) eps^(1-delta).     (9)

Equations (8) and (9) are a genuinely uniform bound over faithful references and perturbations. Since ell^2 times every displayed power of eps tends to zero, and K tends to C,

    limsup ell^2 F_C(eps)
       <= 4 C^2/[3 sqrt(3)(1-delta)^2].

Let delta decrease to zero. This proves the claimed sharp upper constant.

## 6. Matching lower construction

Take

    t = C/sqrt(3),  h = 2C/3,
    A = [[0,t],[t,h]],  B = [[0,t],[t,-h]],
    omega = diag(1-q,q).

The eigenvalues of A are C and -C/3; those of B are C/3 and -C. Thus both norms are exactly C. Their difference is diag(0,2h), so

    E = 4h^2 q = (16 C^2/9) q.                (10)

Set q=9 eps/(16 C^2), which is faithful with q<1/2 for sufficiently small eps. Let Delta_A=L-h and Delta_B=L+h, and s_j=sqrt(Delta_j^2+4t^2). The Gibbs off-diagonal is

    (rho_j)_{01} = t tanh(s_j/2)/s_j.

As L tends to infinity,

    1/s_j = 1/Delta_j + O_C(L^-3),
    tanh(s_j/2) = 1 + O_C(exp(-L)),

so

    (rho_A-rho_B)_{01}
      = t [1/(L-h)-1/(L+h)] + O_C(L^-3)
      = 2th/L^2 + o_C(L^-2)
      = [4 C^2/(3 sqrt(3))]/L^2 + o_C(L^-2).   (11)

For a traceless Hermitian qubit difference [[u,z],[conj(z),-u]], trace distance equals sqrt(u^2+|z|^2), and is therefore at least |z|. Also (10) gives L=ell+O_C(1). Equation (11) proves

    liminf ell^2 F_C(eps) >= 4 C^2/(3 sqrt(3)).

Together with the uniform upper it proves the theorem. The lower construction has E=eps, so the exact-error version follows too.

## Audit ledger

- This proof addresses only dimension two, fixed perturbation bound C, natural-log asymptotics, and trace distance with the factor 1/2.
- It explicitly covers references whose rare eigenvalue goes to zero arbitrarily quickly, and references staying away from zero.
- It explicitly covers unequal diagonals and unequal complex off-diagonal entries in A and B.
- The rare-diagonal effect changes the Gibbs eigenvector at order L^-2; its Gibbs-population effect is included in the exponentially small term in the derivative estimate, while the change of geometric rare population is included in the eigenvector derivative.
- No external source, software theorem prover, finite test, or numerical optimizer is used as proof.
- No unresolved analytic gap was identified in this derivation. Independent review should focus on the three load-bearing identities: weighted error (1), geometric optimization (4), and Bloch speed (5).
- Prior-art status, higher-dimensional sharpness, and implications for any larger Gibbs-classicalization theorem are not resolved here.
