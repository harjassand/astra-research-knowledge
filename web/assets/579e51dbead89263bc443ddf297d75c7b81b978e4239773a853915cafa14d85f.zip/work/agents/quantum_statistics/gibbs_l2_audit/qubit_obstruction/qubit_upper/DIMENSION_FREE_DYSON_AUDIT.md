# Independent audit of the dimension-free Dyson/Schatten estimate

Status: self-contained analytic audit of the supplied mechanism. No external priority claim, numerical evidence, or theorem-prover verification is asserted. All logarithms are natural. No gap was found in the mechanism after the assumptions and normalization below are made explicit.

## Interface and notation

Let omega be any faithful density matrix of any finite dimension. Let A and B be Hermitian, with ||A||_op,||B||_op<=C, where C>0 is fixed. Put

    D=A-B, eps=Tr(omega D^2), M=||D||_op,
    X_A=exp(log(omega)+A), Z_A=Tr X_A,
    rho_A=X_A/Z_A,
    L=log(4C^2/eps).

The bounds below assume 0<eps<4C^2, so L>0. If eps=0, faithfulness implies D=0 and the trace distance is zero. One can substitute any upper bound on the weighted error in place of its exact value throughout the proof.

## 1. Weighted Schatten claim: valid as stated

For 0<=a,b and s=a+b<=1, the claimed estimate is

    ||omega^a D omega^b||_{1/s}
       <= M^(1-s) eps^(s/2).                    (1)

The convention at s=0 is Schatten infinity; then (1) is simply ||D||=M. Here and below Hermiticity of D is essential for identifying both left- and right-weighted Hilbert-Schmidt norms with eps.

First, Schatten Holder gives

    ||omega D||_1
      <= ||omega^(1/2)||_2 ||omega^(1/2)D||_2
      = sqrt(eps),

    ||D omega||_1 <= sqrt(eps).                 (2)

Indeed Tr omega=1, and

    ||omega^(1/2)D||_2^2=Tr(D omega D)=eps,
    ||D omega^(1/2)||_2^2=Tr(omega D^2)=eps.

For a+b=1, apply the scalar three-lines theorem after dualizing trace norm to the analytic matrix function

    F(z)=omega^z D omega^(1-z),  0<=Re z<=1.

At Re z=0 its trace norm equals ||D omega||_1, and at Re z=1 it equals ||omega D||_1, because all imaginary powers are unitary and appear only at the two ends. Thus

    ||omega^a D omega^(1-a)||_1 <= sqrt(eps)     (3)

for every a in [0,1]. This endpoint estimate is independent of dimension and the smallest eigenvalue of omega.

Now suppose 0<s<1, set lambda=a/s, and use

    F(z)=omega^(lambda z) D omega^((1-lambda)z).

At Re z=0, ||F(z)||_infinity=M; at Re z=1, ||F(z)||_1<=sqrt(eps) by (3). Finite-dimensional Schatten interpolation gives

    ||F(s)||_{1/s} <= M^(1-s)(sqrt(eps))^s,

which is (1).

For completeness, this Schatten interpolation step can be proved directly by scalar three-lines. For p=1/s, let Y be a maximizing dual matrix with ||Y||_{1/(1-s)}=1 and Tr(Y F(s))=||F(s)||_p. Write Y=W|Y| and set

    Y(z)=W |Y|^((1-z)/(1-s))

on the support of |Y|, setting it to zero off that support. At z=s it equals Y; at Re z=0 it has trace norm one; at Re z=1 it has operator norm at most one. Apply scalar three-lines to Tr(Y(z)F(z)), using the paired Schatten Holder estimates at the two boundaries. This yields exactly the displayed interpolation inequality, with no dimension factor. Zero singular values cause no problem because their support is fixed.

## 2. A stronger weighted Schatten estimate

The claimed estimate is sufficient, but its exponent can be improved using the intermediate Hilbert-Schmidt endpoint. If a+b=1/2, diagonalize omega with eigenvalues p_i. Then

    ||omega^a D omega^b||_2^2
       = sum_{i,j} p_i^(2a) p_j^(2b) |D_ij|^2
       <= sum_{i,j} (2a p_i+2b p_j) |D_ij|^2
       = eps.                                  (4)

The inequality is weighted arithmetic-geometric mean, because 2a+2b=1. Hermiticity makes |D_ij|^2 symmetric, so the two weighted sums both equal eps.

Interpolating at fixed a/(a+b) between the endpoints s=0 and s=1/2, and then between s=1/2 and s=1, gives

    ||omega^a D omega^b||_{1/s}
       <= M^(1-2s) eps^s,     0<=s<=1/2,
       <= sqrt(eps),          1/2<=s<=1.         (5)

In the second interval both interpolation endpoint bounds are sqrt(eps), so no extra factor appears. The proof uses the same matrix three-lines argument as above with Schatten exponents infinity/2 and 2/1 respectively.

Writing L_M=log(M^2/eps), (5) has the equivalent convenient form

    ||omega^a D omega^b||_{1/s}
       <= M exp[-L_M min{s,1/2}].               (6)

For the universal perturbation bound M<=2C, this implies

    ||omega^a D omega^b||_{1/s}
       <= 2C exp(-Ls),       0<=s<=1/2,
       <= sqrt(eps),         1/2<=s<=1.         (7)

One must retain the piecewise form: extrapolating M^(1-2s)eps^s beyond s=1/2 is not justified by this argument.

## 3. Dyson expansion and telescope

The exact Dyson expansion is

    X_A = sum_{m>=0} integral_{Delta_m}
              omega^(t_0) A omega^(t_1) ... A omega^(t_m) dt,

where Delta_m consists of m+1 nonnegative weights with sum one, with the standard m-dimensional simplex measure of total volume 1/m!. The m=0 term is omega. Schatten Holder bounds the trace norm of the mth integrand by C^m, so the series converges absolutely in trace norm, uniformly in dimension:

    sum_{m>=0} C^m/m! = exp(C).

For each m>=1, subtract the corresponding B product and telescope over its m perturbation factors. In the jth telescope summand, D replaces one factor, the left perturbations are A, and the right perturbations are B. D has adjacent reference weights a=t_(j-1) and b=t_j. Put s=a+b.

Group omega^a D omega^b as one factor with Schatten exponent 1/s. Assign every remaining omega^t the Schatten exponent 1/t and every A or B factor exponent infinity. Since all reciprocal exponents sum to one, generalized Schatten Holder gives

    ||telescope integrand||_1
       <= C^(m-1) ||omega^a D omega^b||_{1/s}.

All remaining reference factors have norm one in their assigned exponents, because Tr omega=1. No commuting assumption is used.

At m=1, s=1 throughout the simplex, so (3) gives a total contribution at most sqrt(eps). At m>=2, the marginal simplex measure of the sum of any two reference weights is

    integral_{Delta_m} f(t_(j-1)+t_j) dt
       = 1/(m-2)! integral_0^1
              s(1-s)^(m-2) f(s) ds.             (8)

The factor s is the length of the internal split a+b=s; the remaining m-1 reference weights contribute the simplex volume (1-s)^(m-2)/(m-2)!. Taking f=1 recovers 1/m!, which independently checks the normalization. Relative to the uniform probability measure on Delta_m, this is the Beta(2,m-1) law.

This factor s is the entire source of log^-2 rather than log^-1 in the proposed mechanism. It is a two-reference-weight integration, not a sum over eigenvalues or a dimension count.

## 4. Reproduction of the supplied general bound

Use (1), M<=2C, and L=log(4C^2/eps). The weighted factor is at most

    2C exp(-Ls/2).

For m>=2, (8) and (1-s)^(m-2)<=1 give

    integral_{Delta_m} exp(-Ls/2) dt
       <= 1/(m-2)! integral_0^infinity s exp(-Ls/2) ds
       = 4/[(m-2)! L^2].

There are m telescope summands at order m. Therefore

    ||X_A-X_B||_1
       <= sqrt(eps) + (8/L^2) sum_{m>=2} m C^m/(m-2)!
       = sqrt(eps) + 8 C^2(C+2) exp(C)/L^2.       (9)

The exact exponential sum is obtained by writing n=m-2:

    sum_{m>=2} m C^m/(m-2)!
       = C^2 sum_{n>=0} (n+2) C^n/n!
       = C^2(C+2) exp(C).

To normalize, eigenvalue monotonicity for Hermitian matrices and

    log(omega)-C I <= log(omega)+A <= log(omega)+C I

give exp(-C)<=Z_A<=exp(C). This uses monotonicity of trace exponential, not false operator monotonicity of the matrix exponential. Also |Z_A-Z_B|<=||X_A-X_B||_1. Thus

    (1/2)||rho_A-rho_B||_1
       <= ||X_A-X_B||_1/Z_A
       <= exp(C)||X_A-X_B||_1.

Combining with (9) reproduces the supplied bound exactly:

    T <= exp(C) sqrt(eps)
            + 8 C^2(C+2) exp(2C)/[log(4C^2/eps)]^2.  (10)

No missing dimension factor, simplex factorial, factor of two from trace-distance normalization, or uncharged normalization constant was identified.

## 5. Stronger interpolation improves the factor 8 to 2

Use the piecewise estimate (7). For each m>=2, its simplex integral is bounded by

    2C/[(m-2)! L^2] + sqrt(eps)/m!.

The first term comes from extending the s<=1/2 integral to [0,infinity], using int_0^infinity s exp(-Ls) ds=1/L^2. The second bounds the s>=1/2 part by the volume of the whole simplex. The two parts are separate upper bounds; this deliberate overcount is harmless.

After multiplication by m C^(m-1), summation, and inclusion of m=1,

    ||X_A-X_B||_1
       <= exp(C) sqrt(eps)
              + 2 C^2(C+2) exp(C)/L^2.

Therefore the independently strengthened explicit bound is

    T <= exp(2C) sqrt(eps)
            + 2 C^2(C+2) exp(2C)/[log(4C^2/eps)]^2.  (11)

This improves the asymptotic logarithmic constant of (10) by a factor of four while worsening its negligible square-root term. One may take the minimum of (10) and (11). Neither is asserted to have the sharp universal constant.

## Audit conclusions and limits

- The supplied weighted Schatten estimate (1) is valid, with Hermiticity and Tr omega=1 made explicit.
- The stronger intermediate endpoint (4) is elementary and yields (5), hence the refined bound (11).
- The Beta(2,m-1) simplex marginal supplies the extra power of the logarithm; it has no dependence on Hilbert-space dimension.
- All bounds are uniform over finite dimension, faithful omega, and bounded Hermitian A,B. No bound on the condition number of omega is used.
- Strict faithfulness is needed to define log omega directly. Rank-deficient extensions require specifying restriction to support and legal perturbations before applying this argument.
- The constants in (10) and (11) are upper bounds, not sharp optimal constants. A qubit sharp constant and a larger qutrit lower coefficient do not determine the all-dimension optimal coefficient.
- This audit does not settle prior art or the correctness of any larger theorem using this modulus. The mathematical derivation itself has no identified gap.
