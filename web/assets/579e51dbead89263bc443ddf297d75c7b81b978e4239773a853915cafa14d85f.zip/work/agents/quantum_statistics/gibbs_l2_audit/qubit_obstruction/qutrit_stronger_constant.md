# A qutrit obstruction with a larger leading constant

Status: direct finite-dimensional proof. This improves the lower constant for a dimension-independent theorem, while preserving the qubit result separately. It is not a novelty or universal-optimal-constant claim.

Fix C>0 and set t=w=C/sqrt(2). For 0<q<1/3 define

    omega=diag(1-2q,q,q),
    A=[[0,t,0],[t,0,w],[0,w,0]],
    B=[[0,t,0],[t,0,-w],[0,-w,0]].

The eigenvalues of either perturbation are 0,+C,-C, so ||A||=||B||=C. The weighted error is exactly

    epsilon = Tr omega(A-B)^2 = 8q w^2 = 4C^2 q.

Let U=diag(1,1,-1). Then B=UAU and U commutes with omega. Therefore rho_B=U rho_A U. If x=(rho_A)_{02} and y=(rho_A)_{12}, the difference rho_A-rho_B is exactly

    [[0,0,2x],[0,0,2y],[2conj(x),2conj(y),0]],

whose eigenvalues are 0 and +/-2sqrt(|x|^2+|y|^2). Consequently the exact trace distance is

    T = 2sqrt(|(rho_A)_{02}|^2+|(rho_A)_{12}|^2).

## Dominant eigenvector calculation

Subtract the scalar log(1-2q) from log omega+A. With

    L=log((1-2q)/q),

the resulting matrix is

    H=[[0,t,0],[t,-L,w],[0,w,-L]].

For L>C its two smaller eigenvalues are <=-L+C by the minimax eigenvalue inequality applied to diag(0,-L,-L)+A. Its largest eigenvalue lambda is positive and simple: the largest eigenvalue of the upper 2x2 principal block is positive, while the second eigenvalue is negative. The top eigenvector can be written

    u=(1,a,b)/sqrt(1+a^2+b^2),
    a=lambda/t,
    b=w lambda/[t(L+lambda)].

The middle-coordinate eigenvalue equation gives the exact root relation

    lambda = t^2/[L+lambda-w^2/(L+lambda)].

For L large the denominator is at least L-w^2/L>=L/2, so lambda=O_C(L^-1). Substituting this back into the denominator gives

    lambda=t^2/L+O_C(L^-3),
    a=t/L+O_C(L^-3),
    b=wt/L^2+O_C(L^-4).

Let P=|u><u|. The Gibbs weight outside the top eigenspace is at most 2exp(-L+C), since the top eigenvalue is >=0. Thus

    T(rho_A,P)<=2exp(-L+C),
    T(rho_B,UPU)<=2exp(-L+C).

For the two pure states, the exact distance is

    T(P,UPU)=sqrt(1-|<u,Uu>|^2)
             = 2|b|sqrt(1+a^2)/(1+a^2+b^2)
             = 2wt/L^2+O_C(L^-4).

The triangle inequality in both directions now gives

    T(rho_A,rho_B)=C^2/L^2+O_C(L^-4)+O_C(exp(-L)).

Choose q=epsilon/(4C^2). Then

    L=log((4C^2-2epsilon)/epsilon)
      =log(1/epsilon)+O_C(1).

Hence this exact admissible qutrit family proves

    lim epsilon->0 log(1/epsilon)^2 T = C^2.

In particular, the dimension-independent worst-modulus leading constant is at least C^2. This is strictly larger than the sharp qubit coefficient 4C^2/(3sqrt(3)). The higher-dimensional optimum remains unresolved by this note.

## Mechanism and next attack

The common visible-to-rare coupling t produces a rare amplitude t/L. A discrepancy wholly inside the rare two-dimensional sector then changes a second rare amplitude by wt/L^2. The squared-reference cost remains O(q). Unlike the optimized qubit, the rare discrepancy rotates the shared coupling vector into an independent rare direction; this raises the leading trace-distance coefficient.

For the entire fixed-dimensional family with one heavy eigenvalue and a flat rare sector, the coefficient C^2 is optimal. Here is an exact perturbation-constraint calculation supporting that restricted statement. Write

    A=[[a,v*],[v,D_A]], B=[[a,v*],[v,D_B]],
    omega=diag(1-rq,q I_r), E=D_A-D_B,
    t=||v||, |a|<C.

Schur complements of C I +/- A and C I +/- B require both rare blocks to lie in the same operator interval

    -C I + vv*/(C+a) <= D_j <= C I - vv*/(C-a).

The midpoint is -a vv*/(C^2-a^2), and the halfwidth is

    M=C I - C vv*/(C^2-a^2).

Thus -2M<=E<=2M, and E=2M^(1/2) K M^(1/2) for a Hermitian contraction K (with the same support statement if M is singular). If r>=2, ||M||=C and

    ||Ev|| <= 2||M^(1/2)|| ||M^(1/2)v||
             =2C t sqrt(1-t^2/(C^2-a^2))
             <= C sqrt(C^2-a^2) <= C^2.

The maximum occurs at a=0 and t=C/sqrt(2); K can exchange the direction of v with an orthogonal rare direction. The qutrit family realizes precisely this choice. If r=1, the largest eigenvalue of M is instead C(1-t^2/(C^2-a^2)), so this calculation reduces to the sharp qubit coefficient.

To connect the operator coefficient with the Gibbs asymptotic in this restricted family, remove the scalar log(1-rq)+a from the Hamiltonian. The top eigenvector's rare part is

    x_j=(L+a+lambda_j-D_j)^(-1)v
        =v/L+(D_j-aI)v/L^2+O_C,r(L^-3),

where L=log((1-rq)/q) and lambda_j=O_C,r(L^-1). Therefore its difference is Ev/L^2+O_C,r(L^-3). Normalization does not change the leading coefficient; the other Gibbs eigenvalues have total weight O_C,r(exp(-L)). For E nonzero, the exact error is epsilon=q Tr(E^2), and the limiting trace-distance coefficient is ||Ev||. This proves the claimed C^2 maximum for this restricted family. It makes no statement about arbitrary reference spectra or a high-rank visible sector.

The strongest next attack is to optimize the second-order map for a high-rank visible block and a nonflat rare spectrum under the joint operator-norm constraints. Scalar qubit interval bounds do not suffice, because the rare perturbation can be noncommuting with the coupling vector's rank-one projection.
