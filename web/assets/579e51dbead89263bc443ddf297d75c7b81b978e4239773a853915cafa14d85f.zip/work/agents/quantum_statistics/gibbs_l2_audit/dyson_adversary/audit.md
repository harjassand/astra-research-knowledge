# Adversarial audit: dimension-free Gibbs continuity in reference-weighted L2

Date: 2026-10-07. Status: the proposed proof is valid under its stated finite-dimensional, faithful-reference, Hermitian assumptions. This is an independent analytic check, not a priority or external-certification claim. The logarithmic exponent 2 is optimal already in dimension 2. A stronger S2 interpolation step, suggested by the parent auditor and independently verified here, improves the leading logarithmic constant by a factor of 4.

## Contract

Let omega be a faithful finite-dimensional density matrix, A and B Hermitian, and ||A||,||B|| <= C. Set

- P_X = exp(log omega + X), Z_X = Tr P_X, rho_X = P_X / Z_X;
- D = A-B, epsilon = Tr omega D^2;
- q = 2C and L = log(q^2/epsilon), for C>0 and 0<epsilon<q^2.

Then the submitted inequality

T(rho_A,rho_B) <= exp(C) sqrt(epsilon) + 8 C^2(C+2) exp(2C)/L^2

holds. A stronger bound proved below is

T(rho_A,rho_B) <= exp(3C/2)(1+C/4) sqrt(epsilon)
                 + 2 C^2(C+2) exp(2C)/(L+C)^2.

The right side can always be capped at 1. If C=0 or epsilon=0, then D=0 and T=0. The exact-integral version below remains finite at epsilon=q^2 (L=0).

## 1. Original interpolation step

Hermiticity is essential to using the same epsilon on both boundaries:

||D omega||_1 <= ||D sqrt(omega)||_2 ||sqrt(omega)||_2 = sqrt(epsilon),
||omega D||_1 = ||D omega||_1 <= sqrt(epsilon).

For F(z)=omega^z D omega^(1-z), on Re z=0 and Re z=1 the imaginary powers are exterior unitaries. Thus ||F(it)||_1=||D omega||_1 and ||F(1+it)||_1=||omega D||_1. Scalarizing against every operator-norm contraction and applying Hadamard's three-lines theorem gives

||omega^u D omega^(1-u)||_1 <= sqrt(epsilon), 0<=u<=1.

For a,b>=0, r=a+b in (0,1), use G(z)=omega^(az/r) D omega^(bz/r). Its boundary operator norm is <=q, and its boundary trace norm is <=sqrt(epsilon). Schatten interpolation with p_0=infinity, p_1=1, theta=r gives

||omega^a D omega^b||_(1/r) <= q^(1-r) epsilon^(r/2) = q exp(-Lr/2).

Endpoints r=0 and r=1 follow directly. No dimension-dependent interpolation constant is needed.

Primary-source anchor for the standard interpolation ingredient: Sutter, Berta, Tomamichel, "Multivariate Trace Inequalities," arXiv:1604.03023v3, Theorem 3.1 and Appendix D. The boundary-uniform version used here follows immediately from their inequality (31). URL: https://arxiv.org/html/1604.03023v3#S3.SS1 . This citation only verifies the standard ingredient; it does not establish priority of the Gibbs modulus.

For a fully finite-dimensional scalar proof of the mixed interpolation: choose a norming dual matrix Y with ||Y||_(1/(1-r))=1 and polar decomposition Y=U|Y|. The analytic dual family Y(z)=U|Y|^((1-z)/(1-r)), with powers restricted to the support, has trace norm 1 on Re z=0 and operator norm <=1 on Re z=1. Apply three-lines to Tr Y(z) G(z). At z=r this yields the desired norm estimate. The usual polar orientation can be chosen so that Tr Y G(r) is the norm.

## 2. Dyson expansion and the adjacent-power Holder step

For X=A,B, finite-dimensional Duhamel iteration gives

P_X = sum_(n>=0) integral_(Delta_n) omega^(s_0) X omega^(s_1) X ... X omega^(s_n) ds,

where Delta_n={s_i>=0, sum s_i=1} and its standard n-dimensional simplex measure has volume 1/n!. Generalized Schatten Holder bounds each integrand's trace norm by C^n because ||omega^s||_(1/s)=1 and the reciprocal exponents sum to 1. Consequently the series converges absolutely in trace norm, with bound sum C^n/n!=exp(C), so termwise telescoping and integration are justified.

The n-th difference telescopes into n terms, one for each insertion k of D, with A before D and B after D. Let r=s_(k-1)+s_k be the sum of the two adjacent omega exponents. Treat omega^(s_(k-1)) D omega^(s_k) as one Schatten-1/r factor. The remaining omega factors have reciprocal exponents summing to 1-r, and all remaining A/B factors are bounded in operator norm by C. Hence each telescoped integrand is bounded by

C^(n-1) q exp(-Lr/2).

For n=1, r=1 identically and the complete term is <=sqrt(epsilon). For n>=2, the exact pushforward of simplex measure under r=s_(k-1)+s_k is

[r(1-r)^(n-2)/(n-2)!] dr, 0<=r<=1.

This is the unnormalized Beta(2,n-1) density; its integral is 1/n!, as required. Summing the n placements and then n>=2 gives exactly

R_original <= q C integral_0^1 r[2+C(1-r)] exp(C(1-r)-Lr/2) dr.

With q=2C, extending the integration range to infinity after bounding the bracket by C+2 gives the submitted R <=8 C^2(C+2) exp(C)/L^2. Retaining exp(-Cr) instead gives the stronger denominator (L+2C)^2.

The exact original integral is also useful. Put k=C+L/2 and

I1(k)=[1-(1+k)exp(-k)]/k^2,
I2(k)=[2-(k^2+2k+2)exp(-k)]/k^3.

Then R_original <=q C exp(C)[(C+2)I1(k)-C I2(k)]. At L=0 this is q(exp(C)-1); including n=1 gives delta=||P_A-P_B||_1 <=q exp(C).

## 3. Better S2 interpolation

The S1 interpolation above is valid but loses a factor 2 in the decay exponent. Apply three-lines in S2 to

H(z)=omega^(z/2) D omega^((1-z)/2).

Both boundary S2 norms are sqrt(epsilon), because D is Hermitian. Thus

||omega^(u/2) D omega^((1-u)/2)||_2 <=sqrt(epsilon).

If 0<r<=1/2, interpolate G(z)=omega^(az/(2r)) D omega^(bz/(2r)) between S_infinity at Re z=0 and S2 at Re z=1. Evaluate at theta=2r to obtain

||omega^a D omega^b||_(1/r) <=q^(1-2r)epsilon^r =q exp(-Lr).

If 1/2<=r<=1, factor the same matrix as

omega^[a(1-1/(2r))] [omega^(a/(2r)) D omega^(b/(2r))] omega^[b(1-1/(2r))].

The central factor has S2 norm <=sqrt(epsilon); the exterior omega powers have Schatten reciprocal exponents totaling r-1/2 and each norm 1. Generalized Holder then gives S1/r norm <=sqrt(epsilon). The combined bound is therefore

||omega^a D omega^b||_(1/r) <=q exp(-L min(r,1/2)).

Use this in the same Dyson sum. The r>=1/2 part contributes sqrt(epsilon) times

B(C)=C integral_(1/2)^1 r[2+C(1-r)] exp(C(1-r)) dr
    =exp(C/2)(1+C/4)-1.

The identity follows from the antiderivative -exp(C(1-r))[1+Cr(1-r)]. Including n=1 yields the sqrt(epsilon) coefficient exp(C/2)(1+C/4).

The r<=1/2 part is

R_low <=q C exp(C) integral_0^(1/2) r(C+2-Cr) exp(-(L+C)r) dr
      <=q C(C+2) exp(C)/(L+C)^2.

Thus

delta <=exp(C/2)(1+C/4) sqrt(epsilon)
        +2 C^2(C+2) exp(C)/(L+C)^2.

The exact low integral can be retained. For k=L+C, write

J1(k)=[1-(1+k/2)exp(-k/2)]/k^2,
J2(k)=[2-(k^2/4+k+2)exp(-k/2)]/k^3.

Then R_low <=q C exp(C)[(C+2)J1(k)-C J2(k)]. At L=0 this exact bound, together with the high tail and n=1, equals q exp(C), consistent with the endpoint.

## 4. Normalization

For positive P,Q with a=Tr P, b=Tr Q, delta=||P-Q||_1,

T(P/a,Q/b) <=[delta+|a-b|]/[2 max(a,b)] <=delta/max(a,b).

This follows by decomposing with the larger trace as common denominator; |a-b|<=delta. For H=log omega and ||X||<=C, H-CI<=H+X. Eigenvalue monotonicity therefore gives

Z_X=Tr exp(H+X)>=exp(-C)Tr exp(H)=exp(-C).

Only trace-exponential monotonicity is used. It would be incorrect to claim that matrix exponential is operator monotone in the Loewner order. Multiplying the delta estimates by exp(C) proves both bounds in the contract.

The child normalization auditor independently verified these constants and showed that exp(C) is sharp as a universal multiplier using only a lower bound on the Gibbs normalizers: omega=diag(1-r,r), B=-CI, A=-CI+h|2><2|, 0<h<=2C, gives T/delta ->exp(C) as r->0.

## 5. A two-dimensional sharpness family

Fix C>0 and take a=d=C/2. For M>0 set

omega_M = diag(1,exp(-M))/(1+exp(-M)),
A = [[0,a],[a,d/2]],
B = [[0,a],[a,-d/2]].

Both norms equal sqrt(a^2+d^2/16)+d/4 = C(sqrt(17)+1)/8 < C. Here D=diag(0,d) and

epsilon_M=d^2/(1+exp(M)).

Subtracting the scalar normalization from log omega_M has no effect on the normalized Gibbs state. The relevant two generators are [[0,a],[a,-t]] with t=M-d/2 for A and t=M+d/2 for B. Their normalized Gibbs states have Bloch vector

v(t)=tanh(R_t) (a,0,t/2)/R_t,
R_t=sqrt(a^2+t^2/4).

As t->infinity,

v_x(t)=2a/t+O(t^-3),
v_z(t)=1-2a^2/t^2+O(t^-4),

with the tanh error exponentially small. Consequently

T(rho_A,rho_B)=ad/M^2+O(M^-3).

Since L_M=log(4C^2/epsilon_M)=M+log(16)+O(exp(-M)),

lim_(M->infinity) L_M^2 T(rho_A,rho_B)=ad=C^2/4>0.

Thus no uniformly valid dimension-free o(1/log^2(1/epsilon)) modulus is possible at any fixed C>0. In particular, every epsilon^alpha bound with alpha>0 fails under this interface, even with dimension fixed at 2. The obstruction is a common bounded coupling a combined with a diagonal change on a reference-rare level; D itself has reference-weighted L2 mass exponentially small while the coupling responds algebraically to the large reference energy gap.

One can improve the lower-family coefficient by taking d=4C/3 and a=C/sqrt(3), for which the norms equal C and ad=4C^2/(3sqrt(3)). This coefficient optimization is incidental; the simple family already proves the optimal exponent.

## Audit ledger

- No flaw found in the submitted theorem or proof skeleton.
- Required hypotheses retained: finite dimension, omega faithful, D Hermitian, bounded A and B, standard simplex measure. No spectral lower bound on omega and no dimension factor are introduced.
- Original mixed interpolation is correct; S2 interpolation improves it.
- Dyson convergence, n insertion count, Beta marginal, and exponential generating sum were checked explicitly.
- Normalization uses trace exponential monotonicity, never operator monotonicity of exponential.
- C=0, epsilon=0 need a separate zero-distance branch. L=0 is excluded in the submitted rational expression, but the exact integral remains valid there.
- Neither this proof nor the lower family settles novelty or priority; a targeted literature comparison is still needed before any new-theorem claim.
