# Unequal known thermal means: independent benchmark audit

Status: the new unequal-temperature steps are valid under the imported covariance/PPT reduction. The audit below independently proves the weighted likelihood witness, correlated-Fock domination, exact formula, affinity threshold, and triangular-array critical profile. The noncompact covariance reduction and multimode Bochner characterization are imported from the assigned, already audited benchmark; they are not re-certified here. No novelty or priority claim.

All logarithms are natural. Trace distance is half the trace norm. For each finite array, the number of modes m is finite and each known mean n_i is a finite nonnegative real number.

## Contract and exact result

Let theta_n have photon-count distribution

p_n(k)=n^k/(n+1)^(k+1), k>=0,

with p_0 concentrated at k=0. The unknown parameter is the entire displacement vector alpha in C^m, with no displacement or input-energy restriction. Arbitrary normal collective EB channels, joint measurements, correlated classical outcomes, and entangled prepared outputs are permitted.

Under the imported covariance/PPT result, the exact minimax error is

e(n_1,...,n_m)
 = TV(product_i geom(n_i), product_i geom(n_i+1))
 = half ||product_i theta_(n_i)-product_i theta_(n_i+1)||_1. (1)

The same optimum holds over the larger normal PPT channel class. Product heterodyne measurement and coherent preparation attain (1).

## 1. The optimal likelihood region for unequal means

Put u_i=1/(n_i+1), b_i=log(1+u_i), and, when n_i>0,

a_i=-log(1-u_i^2)
   =log((n_i+1)^2/[n_i(n_i+2)])>0.

For positive n_i, the target-to-heterodyne-output likelihood ratio is

p_(n_i)(k_i)/p_(n_i+1)(k_i)=exp(b_i-a_i k_i).

Let Z={i:n_i=0} and J its complement. The exact positive-likelihood region is

R={k in N^m: k_i=0 for every i in Z,
                  sum_(i in J) a_i k_i <= sum_(i=1)^m b_i}. (2)

Here a zero-mean coordinate contributes the likelihood factor 2 at k_i=0; if k_i>0, the target probability vanishes and that vector is outside R. Thus (2) directly handles zero means; it does not rely on an informal infinite-weight limit. If all means are zero, R is the vacuum vector, and the exact risk is 1-2^(-m).

R is coordinatewise decreasing: k in R and 0<=l_i<=k_i for all i implies l in R. It is also finite for every fixed array: every positive-temperature coordinate satisfies k_i<=floor[(sum b_j)/a_i], and every zero-temperature coordinate is fixed to zero. Therefore Pi_R=sum_(k in R)|k><k| is a finite-rank projector, as needed by the imported weak-star covariance-limit witness. The weights may be tiny and the rank enormous, but neither issue affects this existence theorem.

On a likelihood-equality boundary P(k)=Q(k), including or excluding the boundary does not change the difference of probabilities. The exact classical trace error is

e=P(R)-Q(R), P=product geom(n_i), Q=product geom(n_i+1). (3)

Unequal temperatures require the weighted cutoff (2), rather than a total-photon cutoff. A Ky Fan witness from a generic output-majorization statement does not alone prove that this particular projector is optimal. The coordinatewise argument below supplies the missing witness.

## 2. Thermal amplifiers factor independently despite a collective seed

The imported covariant PPT representation gives a normal m-mode seed tau, possibly entangled and with infinite mean energy, such that its output on the undisplaced target is

product_i A_(2,n_i)(tau).

The tensor-product notation means a product of channels acting on the joint seed, not a product-state assumption. For each i,

A_(2,n_i)=A_(n_i+2,0) composed_with L_(2/(n_i+2),0). (4)

The gains multiply to 2, and the characteristic-function noise exponent of the composition is

[(n_i+2)(1-2/(n_i+2))+(n_i+2)-1]/2=n_i+1/2,

which is the noise exponent of the gain-2 amplifier with thermal environment mean n_i. At n_i=0 the loss in (4) is the identity, so the endpoint is included exactly.

Apply the product of losses to tau and call the joint state sigma. Pi_R is diagonal in every local photon number, and the product amplifiers are locally phase covariant. Consequently phase-twirling sigma independently in each mode does not change the output probability of R. The twirled state has the form

sum_(k in N^m) mu(k)|k_1,...,k_m><k_1,...,k_m|,

where mu is an arbitrary joint probability distribution. No independence, product-state, finite-energy, or finite-support assumption is imposed on mu. For infinite sums, normality and positivity justify passage by monotone convergence.

## 3. Simultaneous coordinatewise Fock-output domination

For a fixed Fock input |k_i> under a quantum-limited amplifier of gain G_i=n_i+2, the output count has the exact law

S_i=k_i+sum_(j=1)^(k_i+1) Y_(i,j),

where Y_(i,j) are independent geom(n_i+1) variables. Equivalently, for l>=0,

Pr[S_i=k_i+l]=binomial(k_i+l,k_i)G_i^(-k_i-1)(1-1/G_i)^l.

For a multimode Fock basis vector, the output counts are independent conditional on that vector because the channel is a product. Couple all coordinates to the vacuum-seed counts

V_i=Y_(i,1).

Then S_i>=V_i simultaneously for every i. The V_i are independent with joint law Q=product geom(n_i+1). Since R is coordinatewise decreasing,

1_R(S)<=1_R(V) almost surely,

so Pr[S in R]<=Q(R) for every deterministic Fock vector. Mixing with any correlated mu preserves this inequality. This is a multivariate stochastic-order argument; no invalid tensorization of one-mode trace errors is being used.

It follows that every normalized covariant PPT channel satisfies

Tr[Pi_R T(rho_0)]<=Q(R). (5)

The imported noncompact reduction may instead yield a covariant subnormalized limit T_0=cT, 0<=c<=1. Because Pi_R has finite rank, its original risk witness survives the limit. Then

r >=P(R)-Tr[Pi_R T_0(rho_0)]
  >=P(R)-cQ(R)>=P(R)-Q(R)=e.

This proves the exact lower bound even against arbitrary collective EB channels. Product heterodyne/coherent preparation maps each displaced theta_(n_i) to the same displacement of theta_(n_i+1), proving the upper bound and equality in (1).

## 4. Exact affinity and dimension-free threshold

The one-mode classical Bhattacharyya affinity is

c_i=sum_k sqrt(p_(n_i)(k)p_(n_i+1)(k))
   =[sqrt(n_i+2)+sqrt(n_i)]/[2sqrt(n_i+1)],

so, including n_i=0,

c_i^2=[1+sqrt(1-u_i^2)]/2. (6)

The product affinity is c=product_i c_i. Classical TV obeys

1-c<=e<=sqrt(1-c^2). (7)

For v=u_i^2 in [0,1], write f(v)=-log(c_i). The exact expression is

f(v)=-half log[(1+sqrt(1-v))/2].

The scalar bounds

v/8<=f(v)<=v/2 (8)

follow as follows. Since sqrt(1-v)<=1-v/2, one has c_i^2<=1-v/4, and -log c_i>=-half log(1-v/4)>=v/8. Conversely sqrt(1-v)>=1-v gives c_i^2>=1-v/2. Then -half log(1-v/2)<=v/2 because the derivative of -log(1-v/2) is 1/(2-v)<=1 on [0,1].

Set s=sum_i u_i^2. Equations (7)-(8) prove the proposed universal bounds exactly:

1-exp(-s/8)<=e<=sqrt(1-exp(-s)). (9)

The upper bound can be sharpened. f is convex, f(0)=0 and f(1)=log(2)/2, so f(v)<=v log(2)/2 by the chord bound. This gives

e<=sqrt(1-2^(-s)). (10)

No asymptotic approximation or common-temperature assumption is used in (9)-(10). For arbitrary sequences of finite arrays, they imply

e->0 if and only if s->0,
e->1 if and only if s->infinity.

In particular, the requested sufficient s->infinity criterion for error tending to 1 has a valid converse as well. A zero-temperature mode contributes 1 to s and prevents vanishing error.

Notation warning only: the reciprocal temperatures u_i are distinct from the likelihood weights a_i. Bounds (8) involve u_i^2, not a_i^2. The parent claim's final reference to a squared parameter should be read with that distinction.

## 5. Critical triangular-array likelihood CLT

Now consider arrays indexed by r, with min_i n_(r,i)->infinity and

s_r=sum_i u_(r,i)^2 ->c in (0,infinity).

Thus max_i u_(r,i)->0. Every mean is positive for all sufficiently large r. Under P_r or Q_r, the log likelihood ratio is

Lambda_r=sum_i [b_i-a_i K_i],

and R={Lambda_r>=0}. The following expansions hold uniformly as max u_i->0:

b_i=log(1+u_i)=u_i-u_i^2/2+O(u_i^3),
a_i=-log(1-u_i^2)=u_i^2+O(u_i^4).

Under P_i, E K_i=n_i=1/u_i-1 and Var K_i=(1-u_i)/u_i^2. Therefore

E_(P_i)[b_i-a_i K_i]=u_i^2/2+O(u_i^3),
Var_(P_i)[b_i-a_i K_i]=u_i^2+O(u_i^3).

Under Q_i, E K_i=n_i+1=1/u_i and Var K_i=(1+u_i)/u_i^2. Therefore

E_(Q_i)[b_i-a_i K_i]=-u_i^2/2+O(u_i^3),
Var_(Q_i)[b_i-a_i K_i]=u_i^2+O(u_i^3).

Since sum_i u_i^3<=max_i u_i times s_r->0, the aggregate means tend to +/-c/2 and both aggregate variances tend to c.

For a geometric variable of mean mu>=1,

E|K-mu|^3<=E(K+mu)^3=16mu^3+9mu^2+mu<=26mu^3.

Both relevant means are <=1/u_i. Also a_i<=u_i^2/(1-u_i^2). Thus, eventually, the third absolute centered moment of each log-likelihood term is <=constant times u_i^3. The sum of these moments tends to zero, whereas aggregate variance tends to c>0. Lyapunov's triangular-array CLT applies under both product distributions:

Lambda_r under P_r converges in distribution to Normal(c/2,c),
Lambda_r under Q_r converges in distribution to Normal(-c/2,c).

The limiting laws have no atom at zero, so equality boundaries and lattice spacings cause no extra term. Hence

P_r(R)->Phi(sqrt(c)/2),
Q_r(R)->1-Phi(sqrt(c)/2),

and the exact risk converges to

e_r->2Phi(sqrt(c)/2)-1. (11)

The condition min n_i->infinity is load-bearing for this universal Gaussian profile. Without infinitesimal reciprocal temperatures, fixed cold modes can survive and the limiting likelihood need not be Gaussian, even at finite positive s. For example, a single zero-temperature mode has s=1 and risk exactly 1/2, while 2Phi(1/2)-1 is about 0.3829.

## Sources, dependency, and failure ledger

Imported proof/interface: work/agents/quantum_statistics/boundary_audit/growing_dimension/gaussian_eb_lower/EXACT_MULTIMODE_EB_BENCHMARK.md, sections on noncompact covariance, covariant PPT amplifier representation, and the single-mode quantum-limited Fock amplifier law. Its primary-source anchors are Guta--Bowles--Adesso arXiv:1004.1843, https://arxiv.org/abs/1004.1843 , Theorem IV.1 and Lemmas IV.2/IV.4/IV.5; Owari et al. arXiv:0808.2260, https://arxiv.org/abs/0808.2260 , main-text Eqs. (14)-(15) and Appendix A Lemmas 2-4. This audit accepts those imported facts as instructed and checks only their unequal-temperature composition.

No mathematical flaw found in the new claim. The important corrections in presentation are to specify the finite-rank weighted region, handle zero means directly, and avoid confusing reciprocal-temperature squares with squared likelihood weights. The correlated Fock mixture is handled by simultaneous coordinatewise coupling, not by assuming independence of its seed coordinates. Generic majorization is unnecessary for this extension. The asymptotic threshold is unconditional under the exact Gaussian full-orbit benchmark; the critical normal profile needs the stated uniform high-temperature premise. No dimension-uniform qudit LAN bridge or bounded-displacement localization is proved by this audit.

Strongest next use: insert the exact unequal-mode value into the qudit Gaussian collision experiment with s=sum_i (n_i+1)^(-2), retaining the separate finite-n/dimension-dependent Gaussian and localization errors. Any such transfer must charge those errors independently; the present note settles only the unequal Gaussian EB step.
