# Radial transport: independent tail and atom audit

Status: direct mathematical audit of the stated candidate; no counterexample to
the candidate with positive slack was found. No literature-priority claim.

Inputs are probability Borel measures q_N,q on [0,infinity), q_N weakly
converging to q; fixed uniform probability measure sigma on S^2; real symmetric
matrices A with operator norm at most M and real vectors b with norm at most B.
Write f_(A,b)(r,u)=exp(r^2 u^T A u+r b.u), and normalize f against q_N x sigma
or q x sigma. The kernels below depend on the known radial measures, never on
(A,b). Their computational acquisition/cost is not addressed by this theorem.

## 1. Positive slack suffices, including both directions and atoms

Let h(r)=exp(Mr^2+Br) and H(r)=exp((M+delta)r^2+(B+delta)r), delta>0.
Suppose sup_N int H dq_N <= C. Portmanteau gives int H dq <= C.

Choose the common-uniform quantile coupling gamma_N of q_N,q. Then coupled
radii r_N,r converge almost surely. Define t=max(r_N,r). Since H is increasing,
H(t)<=H(r_N)+H(r). Consequently E H(t)<=2C for every N. For every parameter,
|f(r_N,u)-f(r,u)|<=2h(t); hence, after averaging u and the coupling,

  E[|f(r_N,u)-f(r,u)| 1_(t>R)]
    <= 4C exp(-delta(R^2+R)).

This controls all cross-endpoint tail events; no independence or a separate
coupling-tail estimate is required.

On t<=R the derivative in the radial variable is uniformly bounded by

  L_R=exp(MR^2+BR)(2MR+B).

Therefore D_N := sup_(A,b) E|f(r_N,u)-f(r,u)| satisfies

  D_N <= L_R E[|r_N-r| 1_(t<=R)]
         +4C exp(-delta(R^2+R)).

For fixed R the first term tends to zero by dominated convergence. Then let
R tend to infinity. Thus D_N tends to zero.

Normalizers are uniformly bounded away from zero. For example choose R_0 with
H(R_0)>=2C; Markov's inequality gives at least 1/2 radial mass in [0,R_0]
under every q_N and q. Hence Z_N(A,b),Z(A,b) >=

  z_* = (1/2) exp(-MR_0^2-BR_0)>0.

Disintegrate gamma_N both ways to obtain k_N(r_N,dr) and l_N(r,dr_N).
On product spaces let the kernels retain u and apply the respective radial
conditional law. Standard Borel disintegrations exist even for mixed/atomic
measures. On the common joint space the normalized tilted densities are
f(r_N,u)/Z_N and f(r,u)/Z. Their TV distance is at most D_N/z_*; projecting
onto either endpoint proves

  sup_(A,b) TV(K_N P_N(A,b),P(A,b)) <= D_N/z_*,
  sup_(A,b) TV(L_N P(A,b),P_N(A,b)) <= D_N/z_*.

At an atom, the conditional quantile variable must be randomized uniformly
over the atom's CDF interval. A deterministic radial map generally cannot
split an atom. The disintegration formulation already includes this
randomization. At r=0, retaining the sphere variable is harmless auxiliary
randomness; if the observation is instead x=ru in R^3, add/remove a fresh
uniform direction at x=0 to obtain the same experiment.

## 2. A strictly weaker sufficient condition

For uniform sigma on S^2 define

  G(r)=exp(Mr^2) sinh(Br)/(Br),

using sinh(0)/0=1. This is increasing. For every allowed parameter,

  int_(S^2) f_(A,b)(r,u) d sigma(u) <= G(r).

Equality in the supremum is achieved by A=MI and any b of length B.
Consequently the transport theorem remains valid if the original moment
assumption is replaced by uniform integrability of G under q_N:

  lim_(R to infinity) sup_N int_(r>R) G(r) dq_N(r)=0.

Indeed after integrating u, the difference on t>R is at most 2G(t), and

  G(t) 1_(t>R) <= G(r_N)1_(r_N>R)+G(r)1_(r>R).

Weak convergence and this uniform integrability also give finite G moment
and vanishing G tails for q. Compact radial convergence then finishes the
same proof. Positive quadratic slack OR positive linear slack suffices; the
candidate's use of both is stronger than needed.

In particular if B>0, the exact boundary bound

  sup_N int exp(Mr^2+Br) dq_N <= C

already implies the weaker sufficient condition because

  G(r)/exp(Mr^2+Br)=(1-exp(-2Br))/(2Br)<=1/(2Br).

The coupling-tail estimate is then at most 2C/(BR). This conclusion holds for
every M>=0, not only M=0. The positive linear-envelope term and sphere
averaging jointly force tail dilution. Do not claim positive slack is
necessary for all parameter bounds.

## 3. Exact boundary counterexample when M>0 and B=0

Let R_N tend to infinity, epsilon_N=exp(-MR_N^2), and

  q_N=(1-epsilon_N)delta_0+epsilon_N delta_(R_N),  q=delta_0.

Then q_N converges weakly to q and int exp(Mr^2)dq_N=2-epsilon_N<=2.
For theta_0=(0,0), the rare-radius probability is epsilon_N. For
theta_1=(MI,0), its tilted probability is 1/(2-epsilon_N), tending to 1/2.
The limiting experiment is parameter-independent because f(0,u)=1.

Any reverse kernel applied to the limiting experiment must therefore produce
the same law R for both parameters. The triangle inequality gives

  max_i TV(R,P_N(theta_i)) >= (1/2)TV(P_N(theta_0),P_N(theta_1))
    = (1/2)[1/(2-epsilon_N)-epsilon_N] -> 1/4.

So bidirectional uniform TV equivalence fails under merely bounded exact
quadratic moment. Forward deficiency happens to vanish here by collapsing
all radii to zero; the reverse direction is the failure.

This counterexample requires MI to be allowed. If the intended A interface is
traceless, or excludes positive scalar matrices, it does not apply. Under a
traceless restriction, angular quadratic dilution can remove the boundary
obstruction; that is a distinct theorem to formulate rather than infer.

## 4. Positive slack is not necessary even when B=0

For M>0 take q with density proportional to exp(-Mr^2)/(1+r)^2, and q_N its
restriction to [0,N], renormalized. These measures converge to q; G=e^(Mr^2)
has uniformly integrable tails under q_N. Hence the transport result applies.
But for every delta>0,

  sup_N int exp((M+delta)r^2+delta r) dq_N = infinity.

Thus the candidate is sufficient and convenient, not a necessary condition.

## Failure ledger and next attack

- Proposed positive-slack theorem: no failure; uniform tails, normalizers,
  bidirectional transport, and atoms all close by direct proof.
- Mere weak convergence: insufficient. Rare masses can become order-one
  after parameter tilting.
- Bounded exact envelope with M>0,B=0 and MI permitted: reverse deficiency
  bounded below by 1/4 in the explicit example above.
- Blanket necessity of positive slack: false; B>0 exact envelope suffices,
  and uniformly integrable quadratic-envelope families can lack all slack.
- Deterministic atom transport: false in general; randomized disintegration
  is the correct kernel interface.

Strongest next attack: establish the actual matrix parameter restrictions in
the upstream quantum model, then audit its radial-moment input uniformly in
those parameters. The abstract coupling theorem is not the load-bearing
obstacle if the displayed slack bound has already been proved.
