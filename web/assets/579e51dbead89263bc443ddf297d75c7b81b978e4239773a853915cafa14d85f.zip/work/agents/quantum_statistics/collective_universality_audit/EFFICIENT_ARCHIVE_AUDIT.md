# Independent audit: efficient 1D collective-field archive

Date: 2026-10-07. Auditor: `collective_universality_audit`. No further agents were used for this audit.

## Verdict

**PASS for the repaired construction in `work/agents/quantum_statistics/EFFICIENT_1D_ARCHIVE.md`.** At fixed public field bound R, inverse temperature, range and strength, it has a classical retained alphabet independent of N and a quantum encoder/decoder of polynomial runtime in N and inverse requested accuracy. It reconstructs the entire system density, including the reference multiplicity state. The decoder prepares a fresh known reference and retains its multiplicity register; it never computes or separately prepares the enormous conditional multiplicity density matrix.

The following repairs are necessary for a fully precise statement and are incorporated below:

1. Cap rejection sampling and charge all sampler calls, rather than assume small conditional probabilities can be acquired exactly. No offline cell-probability calibration is needed.
2. Define cells using shared rounded public coordinates, so finite-bit implementation never has to decide whether an algebraic quadrature coordinate is extremely close to a grid boundary.
3. Apply exact coherent identities to an ideal quadrature channel, and compare its compiled approximation in diamond norm. The compiled finite-gate channel is not claimed to preserve the coherent identities exactly.
4. Use the separate explicit high-temperature MGF theorem, or supply the radial Gaussian tail as a hypothesis. The new Gibbs preparation theorem does not itself prove these tails.
5. The preparation theorem is an imported premise. Its complete proof has not been independently audited here. No constant-depth bound for the entire archive or practical classical-machine simulation follows.

The source preparation capability is correctly identified in [Pilatowsky-Cameo et al., arXiv:2609.35973v1](https://arxiv.org/html/2609.35973v1), Theorem 2, equation (3), and Corollary 1, equation (4). The theorem gives a randomized classical description of bounded-block states whose mean approximates the known Gibbs density in trace norm; the corollary supplies quantum preparation. Appendix B explains the sampler. The block/depth constants depend very badly on the fixed temperature and range. I use its stated algorithm as a black box.

## 1. Legal input and computation interface

The known reference is `omega_N=exp(-beta H_N)/Tr exp(-beta H_N)`, with a fixed-range, fixed-strength SU(2)-invariant qubit Hamiltonian on a 1D ring. The unknown input is one density matrix

```text
rho_(N,b) = omega_N exp(b.J/a)/Z_(N,b),
a=sqrt(N),  |b|<=R.
```

H_N, beta, R and the preparation algorithm are public; b is unknown. The local Hamiltonian matrices have a finite description of polynomial bit length, or are computable to any needed absolute precision in polynomial bit time. This standard input condition must be part of any bit-complexity claim; an arbitrary noncomputable real Hamiltonian is not an algorithmic input.

The supplied preparation primitive, using fresh independent randomness on each call, produces a mean density `hat omega_N` with `T(hat omega_N,omega_N)<=tau` in time `poly(N,1/tau)` at these fixed physical constants. The pure-state sampler descriptor is used to prepare the sample and then ignored or discarded before the Schur measurement and acceptance decision. Decisions depend on the measured j and freshly sampled quadrature outcome only. This ensures the operational channel acts on the mean reference density promised by the sampler theorem.

The archive is quantum hardware work. Encoder measurements, fresh N-spin decoder registers, reference preparation calls, Schur transforms, gates and decoder scratch are charged as runtime/workspace. At the storage checkpoint only the cube/overflow label remains; every other input-dependent register is discarded. Decoder workspace is freshly generated from that label and public independent randomness. No external purification is preserved.

At beta>0 the field can be interpreted as a physical uniform local Hamiltonian perturbation of strength `-b/(beta sqrt(N))`. At beta=0 the density family remains well defined, but that physical reparameterization divides by zero and should be omitted.

## 2. The finite spherical quadrature is sufficient

For a given j take `D=2j+2`, an integer. Let

```text
n_z = ceil((D+1)/2),    n_phi = D+1.
```

Use the n_z-point positive Gauss-Legendre rule on z in [-1,1], normalized to integrate dz/2, and equally spaced azimuths `phi=2pi k/n_phi`, with weight `1/n_phi`. Thus the number of outcomes is `n_z n_phi=O((j+1)^2)` and all weights w are positive and sum to one.

This product rule integrates every Cartesian polynomial on the sphere of total degree at most D exactly. To see this, its azimuthal Fourier modes have absolute order at most D, so the finite Fourier average kills every nonzero mode with no alias. The azimuthal zero mode is a polynomial in z of degree at most D: surviving powers of the transverse coordinates combine into integer powers of `1-z^2`. The Gauss-Legendre rule integrates that polynomial exactly because `2n_z-1>=D`.

The coherent projector P_(j,u) is a matrix polynomial in the Cartesian coordinates u of degree at most 2j. For example it is the restriction of `[(I+u.sigma)/2]^(tensor 2j)` to the symmetric subspace. Consequently the above rule gives exactly

```text
(2j+1) sum_l w_(j,l) P_(j,u_l) = I_(V_j),
(2j+1) sum_l w_(j,l) u_(l,i)P_(j,u_l) = J_i/(j+1).
```

The degree-2j+2 choice also integrates the rank-two formulas if needed. Degree 4j+4 is harmless but unnecessary. j=0 has a one-dimensional spin space and remains valid; apparent redundant angular functions are not operator obstructions.

The effects `E_(j,l)=(2j+1)w_(j,l)P_(j,u_l)` define a valid finite POVM. Its measure-and-prepare channel is completely positive, unital, and trace preserving, and has exactly

```text
B_j(J_i) = [j/(j+1)] J_i.
```

## 3. Exact linear-field error bounds

Use the spin-only unital block channel `Bhat=direct_sum_j B_j tensor id_mult`, including block pinching. As in the preceding universality audit it fixes `log omega_N`. The actual fine encoder/preparation composition resets multiplicity to xi_j and agrees with Bhat on this family, although the reset channel need not be globally unital.

For `H_j=b.J/a`,

```text
||H_j-B_j(H_j)||op
 = |b|j/[(j+1)a] <= R/a.
```

The log-Jensen Gibbs defect lemma and quantum Pinsker therefore give the exact uniform bound

```text
T(rho_(N,b),Bhat rho_(N,b)) <= sqrt[R/(2a)]
                              = sqrt(R/2) N^(-1/4).
```

No spin-tail assumption is needed for this bound.

Let `Q(j,l)=q_N(j)w_(j,l)` and `x_(j,l)=(j/a)u_l`. The actual fine outcome law is

```text
P_b(j,l) = Q(j,l) R_(j,l)(b)/Z_(N,b),
R_(j,l)(b) = <j,u_l|exp(b.J/a)|j,u_l>.
```

The exact finite lower/upper symbols are

```text
h^-_(j,l)=b.x_(j,l),
h^+_(j,l)=[(j+1)/a]b.u_l.
```

Scalar Jensen gives `R_(j,l)>=exp(h^-_(j,l))` pointwise. The eigenbasis/Jensen argument using the finite positive upper-symbol representation gives

```text
sum_l w_(j,l) R_(j,l)
 <= sum_l w_(j,l) exp(h^+_(j,l))
 <= exp(R/a) sum_l w_(j,l)exp(h^-_(j,l)).
```

After summing j and normalizing,

```text
TV(P_b,C_b) <= 1-exp(-R/a) <= R/a,
C_b(j,l)=Q(j,l)exp(b.x_(j,l))/z_N(b).
```

The finite reference law has mean x zero because the quadrature integrates degree one. Hence scalar Jensen gives `z_N(b)>=1`. The quantum normalizer also has `Z_(N,b)>=1`, since `Tr omega_N J_i=0` by invariance and `Tr omega_N exp(b.J/a)>=exp(Tr omega_N b.J/a)=1`.

## 4. Rounded cells and archive accuracy

Compute a public rational approximation `tilde x_(j,l)` with `|tilde x-x|<=zeta`, and use this same public table or evaluation routine for both encoder and decoder. Retain nodes with `|tilde x|<=L`; partition their rounded coordinates into cubes of side h and put the rest into one overflow label. The alphabet bound is

```text
M <= 1+(ceil(2L/h)+1)^3.
```

Two true x values sharing a retained label differ by at most

```text
d_cell = sqrt(3)h+2zeta.
```

Every retained true point has `|x|<=L+zeta`; every overflow point has `|x|>L-zeta`. Thus rounding removes the need for exact algebraic boundary comparisons while perturbing only explicit geometric bounds.

For a retained label c, the ideal decoder uses the **un-tilted** reference conditional law Q(.|c) and prepares `P_(j,u_l) tensor xi_j`, then undoes Schur. It is not exactly the conditional unknown-b coherent mixture. Within a cell the two conditional laws differ by at most `exp(R d_cell)-1`, because the tilt varies by at most that ratio. Summing labels and assigning a fixed fallback to overflow gives the ideal grid error `exp(R d_cell)-1+P_(C_b)(overflow)`.

Comparing both the encoder law and the fine reconstruction to C_b contributes two copies of the fine-law TV error. Hence the exact-reference complete archive obeys

```text
sup_(|b|<=R) T(decoded encoded rho_(N,b),rho_(N,b))
 <= sqrt[R/(2sqrt(N))] + 2R/sqrt(N)
    +exp[R(sqrt(3)h+2zeta)]-1
    +E_(q_N)[exp(R r_j) 1_{r_j>L-zeta}].
```

No limiting Gaussian identification, radial density, radial TV convergence, or thermodynamic convergence rate is required. Only the uniform reference tail is used to choose L.

## 5. Conditional multiplicity preparation and cost

For a retained label c, prepare a fresh exact omega_N. Perform Schur, measure j, and retain its multiplicity register. Independently sample l with probabilities w_(j,l), accept precisely when its public rounded label is c, replace spin by `P_(j,u_l)`, and undo Schur. With acceptance probability `Q(c)`, this produces

```text
tau_c = [1/Q(c)] sum_(j,l:label=c)
        q_N(j)w_(j,l) [P_(j,u_l) tensor xi_j]
```

exactly. The conditional multiplicity state appears by conditioning a whole reference sample; no exponential classical matrix is acquired. The multiplicity register has a large Hilbert dimension but is already represented by O(N) physical qubits in the Schur encoding. Replacing the spin register conditioned on j preserves the valid multiplicity encoding for that j.

Crucially, the following runtime inequality holds for the **actual raw** encoded law, not only its exponential-tilt approximation. Every retained j has `j/a<=L+zeta`, so the operator bound gives

```text
R_(j,l)(b) <= exp[R(L+zeta)],
P_b(c) <= exp[R(L+zeta)] Q(c)/Z_(N,b)
         <= exp[R(L+zeta)]Q(c).
```

Let W be the number of exact reference calls before successful rejection sampling, with a fixed one-call convention for overflow. Empty cells have Q(c)=P_b(c)=0 and may have any fallback. Geometric expectation gives

```text
E_(actual input label) W
 <= 1+sum_(retained c:Q(c)>0) P_b(c)/Q(c)
 <= 1+M exp[R(L+zeta)] =: A_eps.
```

This cancels every small acceptance probability against its small occurrence probability in the input label. The number of calls is bounded in average uniformly in N,b even when some individual nonempty cell probabilities are exponentially small.

To obtain a bounded-time algorithm, cap at `K=ceil(A_eps/eta_cap)` attempts, with a fixed fallback if none succeed. Coupling capped and uncapped algorithms and using Markov bounds their average output trace-distance difference by `A_eps/K<=eta_cap`, uniformly in b. This proof uses no least cell mass or acquired cell-probability estimate.

## 6. Approximate preparation and postselection

For the capped algorithm, a hybrid over its at most K fresh reference preparations bounds total output error by `K tau` when each approximate mean reference is within trace distance tau. All measurements and adaptive acceptance decisions are included in this CPTP hybrid. A rare postselection event can magnify its **conditional** error, but cannot invalidate the capped unconditional hybrid bound.

The same reasoning handles approximate Schur transformations, classical quadrature sampling, coherent-state preparation and inverse Schur. Assign error budgets to complete primitives, with the sum of all primitive errors in any attempted trial at most eta_impl/K. Count the single encoder implementation error separately. If G gates implement a primitive, compiling each gate to error at most the primitive budget divided by G makes the telescoping gate bound explicit. It is not enough to give every gate the full primitive budget.

Fresh samples must be independent of the previous trials and of the unknown input except through the stored label. The random reference sampler's classical descriptor must not be used as an extra acceptance condition. Under these conventions the prepared mean density is exactly the interface promised by the imported theorem.

Take tau and all per-trial implementation budgets to be `O(epsilon/K)`. Then the sampler has precision `1/tau=poly(1/epsilon)` for fixed R and physical constants. No error term depends on inverse cell mass.

## 7. Polynomial bit and circuit cost

The efficient qubit Schur transform is supplied by [Bacon, Chuang and Harrow, quant-ph/0407082](https://arxiv.org/abs/quant-ph/0407082), with circuit size polynomial in N and log inverse precision for fixed qubit dimension.

For each spin j, form the Naimark isometry

```text
W_(l,m) = sqrt[(2j+1)w_(j,l)] <j,u_l|j,m>.
```

The exact POVM resolution implies `W^dagger W=I`. It has O((j+1)^2) rows and O(j+1) columns, both polynomial in N. Its coherent amplitudes are computed from binomial coefficients, half-angle powers and azimuthal phases. Legendre nodes are roots of an explicitly known degree-O(N) rational polynomial; root isolation and arbitrary-precision arithmetic have polynomial bit cost at the required absolute precision. Fourier phases are likewise efficiently computable. Binomial coefficients use only polynomially many bits. Tiny amplitudes need absolute accuracy, not a relative-accuracy oracle.

After approximating the matrix, enforce its isometry property by the stable polar correction

```text
W_tilde -> W_tilde (W_tilde^dagger W_tilde)^(-1/2).
```

The Gram matrix is close to I, so its smallest eigenvalue stays bounded away from zero. This normalization introduces no inverse exponentially small probability. Complete the resulting isometry to a unitary on a polynomial-dimensional padded register and synthesize it by a generic polynomial-length two-level/Givens construction, followed by finite universal-gate approximation. Matrix and synthesis precision sufficient for a prescribed operator/diamond error uses polynomial bits and gates. Implement the spin-controlled family for all O(N) sectors if desired; even this brute-force uniform compilation remains polynomial.

The ideal exact quadrature channel has the identities in Section 2. The implemented channel is close to it in diamond norm; approximate numerical quadrature is not falsely claimed to satisfy those identities exactly. The rounded coordinate label is a separate common public map, so changes in numeric coordinates do not cause an unaccounted encoder/decoder disagreement.

For an explicit Gaussian radial tail, take `h,zeta=O_R(epsilon)`, `L=O_R(sqrt(log(1/epsilon)))`. Then M is polynomial in inverse epsilon, and `exp[R(L+zeta)]` is subpolynomial in inverse epsilon up to fixed R-dependent constants. Hence K, inverse primitive error and inverse sampler accuracy are polynomial in inverse epsilon. Each of the K reference trials and all public preprocessing are polynomial in N and inverse epsilon. The large temperature/range constants stay fixed; no uniform growing-beta efficiency claim is made.

This establishes the conservative polynomial computational claim. It does not supply an optimized circuit, a polynomial depth independent of beta, or a practical runtime estimate.

## 8. Explicit high-temperature radial tails

The required q_N tails can be supplied as a separate assumption at any fixed beta. A verified sufficient high-temperature condition follows from [Kuwahara and Saito, arXiv:1906.10872v2](https://arxiv.org/html/1906.10872v2), Theorem 1, equations (8)-(10). Let interaction order be at most k and common per-site strength g bound both H_N and J_z, with `g>=1/2`. Set

```text
beta_c = 1/(8e^3 g k),
0<=beta<beta_c,  Delta=beta_c-beta>0.
```

For J_z the theorem's sum of local term norms is `Fbar=N/2`, and invariance gives mean zero. Its MGF bound, restricted to `|t|<=Delta/2`, implies

```text
log Tr omega_N exp(t J_z) <= 2t^2 Fbar/Delta.
```

For a nonempty deviation event choose `t=x Delta/(4Fbar)`. The spectral range makes this choice legal; Chernoff gives the conservative bound

```text
Pr_(omega_N)(|J_z|>=x) <= 2exp[-Delta x^2/(8Fbar)]
                        = 2exp[-Delta x^2/(4N)].
```

For larger x the event is empty. I checked directly that the source's equation (17) completes the square incorrectly: the square should be centered at `x/(2c_beta Fbar)` and the remaining constant should be `-x^2/(4c_beta Fbar)`. Thus I do not use the stronger printed Corollary 1 constant.

Conditional on j, SU(2) invariance makes J_z uniform on `m=-j,-j+1,...,j`. For every j>0,

```text
Pr(|m|>=j/2 | j) >= 1/2.
```

This elementary count includes integer and half-integer j. Therefore, with `r=j/sqrt(N)`,

```text
Pr_(q_N)(r>t)
 <= 2 Pr_(omega_N)(|J_z|>t sqrt(N)/2)
 <= 4exp[-Delta t^2/16].
```

This is uniform for all N and t>0, including small-spin sectors. It requires no joint measurement of noncommuting components. Integrating this tail after the fixed linear tilt gives

```text
E_(q_N) exp(Rr) 1_{r>L} <= C_R exp(-c_R L^2)
```

for sufficiently large L, with constants independent of N. It closes the cutoff premise at the explicit high-temperature threshold. At larger beta this audit retains the supplied radial-tail assumption; the new preparation theorem alone does not remove it.

## 9. Final scope and remaining gaps

For the repaired exact statement, no internal mathematical or cost-accounting gap remains. The reconstruction bound is

```text
sqrt(R/2)N^(-1/4)+2R N^(-1/2)
+exp[R(sqrt(3)h+2zeta)]-1
+C_R exp[-c_R(L-zeta)^2]
+eta_cap+eta_impl+eta_encoder.
```

The unknown family and the known reference must remain distinct. All supplied preparation calls concern omega_N, never the unknown b-tilted density. This proves efficient whole-state reconstruction with a fixed requested-accuracy classical alphabet for a physical quantum device. It closes the separately supplied xi_j preparation bottleneck in this class.

External dependencies retained: the source's claimed polynomial Gibbs sampler, standard Schur/synthesis algorithms in a bit-accessible Hamiltonian model, and the explicit high-temperature MGF theorem when no separate radial-tail premise is supplied. Historical priority of this composition is unresolved. General unknown noncentral Hamiltonians, arbitrary non-SU(2) references, external purification, and uniform efficiency as beta grows are outside this audit.

Memory was used only to preserve the scope distinction between internal mathematics, finite checks, external proof, and priority (`MEMORY.md:82,96-97`, rollout `01a1121a-4750-72f0-8f5c-b501038890d3`). No remembered formula is a premise of this audit.
