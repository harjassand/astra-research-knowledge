# Independent audit: collective quadratic Gibbs universality

Date: 2026-10-07. Auditor: `collective_universality_audit`.

## Exact verdict

**PASS, with one channel distinction that must be stated explicitly.** The claimed qualitative, uniform, bidirectional equivalence follows from the hypotheses in the parent assignment. The reference may have arbitrary known faithful multiplicity states, including states entangled across the underlying physical spin particles. The limiting radial law may have atoms or be singular. No radial total-variation convergence is needed.

The entropy proof must use the **spin-only unital channel**, which preserves the multiplicity operator. The physical encoder/preparation composition instead resets multiplicity to its known state and is usually not unital. These two channels agree on every state in the stated family, so the distinction repairs the presentation without changing the result.

The quantum recovery error is uniformly `O(a_N^(-1/2))`; the raw coherent law has a uniform `O(a_N^(-1))` symbol error. Weak radial convergence supplies an additional unspecified `o(1)`. It does not give an `O(a_N^(-1/2))` rate for the complete equivalence.

This is an independent mathematical proof audit, not a priority check, an external correctness certification, or an efficient state-preparation theorem.

## Precise setting

For each N let

```text
H_N = direct_sum_j (V_j tensor M_(N,j)),  d_j=2j+1,
omega_N = direct_sum_j q_N(j) [I_(V_j)/d_j tensor xi_(N,j)].
```

The reference is known and faithful: every included `q_N(j)>0`, and every `xi_(N,j)` is a full-rank density matrix. The collective angular momenta act as `J_i^(j) tensor I_mult` in each block. Let `a=a_N>0`, with `a_N -> infinity`, and `r_j=j/a`. Put

```text
H_(N,j)(A,b) = Q_A(J)/a^2 + b.J/a,
rho_N(A,b) = omega_N exp(H_N(A,b))/Z_N(A,b),
Q_A(J) = sum_(i,l) A_il (J_i J_l+J_l J_i)/2.
```

Take real symmetric A and real b with `||A||op<=M`, `|b|<=B`, for fixed finite nonnegative M and B. The symmetry assumption on A can equivalently be imposed by replacing A with its symmetric part. Assume the laws of `r_j` under `q_N` converge weakly to a probability q on `[0,infinity)`, and for fixed `delta>0`,

```text
C_exp := sup_N sum_j q_N(j)
         exp[(M+delta)r_j^2+(B+delta)r_j] < infinity.
```

With `mu` normalized area measure on the sphere, the limiting experiment is the joint law

```text
nu_(A,b)(dr,du) = exp[h_(A,b)(r,u)] q(dr)mu(du)/z_(A,b),
h_(A,b)(r,u) = r^2 u^T A u + r b.u.
```

The radial marginal of this law is generally tilted; the formula specifies exactly what “R~q and uniform U, tilted” means.

## 1. The log-reference step is valid

Let `B_j` be the coherent measure-and-prepare channel on the spin representation. On the full matrix algebra define

```text
Bhat_N(X) = direct_sum_j (B_j tensor id_mult)(Pi_j X Pi_j).
```

Block pinching and each `B_j tensor id` are completely positive, trace preserving, and unital. Faithfulness gives the finite logarithm

```text
log omega_N|_j = (log q_N(j)-log d_j) I
                + I_spin tensor log xi_(N,j).
```

Thus `Bhat_N(log omega_N)=log omega_N` exactly, regardless of the eigenvalues or entanglement of `xi_(N,j)`.

Since the reference commutes with the collective perturbation,

```text
rho_N = exp(K_N)/Tr exp(K_N),
K_N = log omega_N + H_N(A,b).
```

Operator concavity of log under a unital completely positive map gives

```text
log Bhat_N(exp K_N) >= Bhat_N(K_N),
D(rho_N || Bhat_N rho_N)
 <= Tr rho_N [K_N-Bhat_N(K_N)]
 = Tr rho_N [H_N-Bhat_N(H_N)].
```

There is no exponentiation of an operator inequality. Trace preservation handles the common normalizer correctly.

Write `A_0=A-(tr A)I/3`. The exact coherent-channel identities in the supplied audit imply

```text
B_j(J_i) = [j/(j+1)] J_i,
B_j(R_il) = [j(2j-1)/((j+1)(2j+3))] R_il,
R_il = (J_iJ_l+J_lJ_i)/2 - delta_il j(j+1)I/3.
```

The scalar quadratic part is fixed. Diagonalizing A_0 and using `sum_i J_i^2=j(j+1)I` gives

```text
||Q_(A_0)(J)||op <= ||A_0||op j(j+1),
1-lambda_2 <= 3/(j+1),
||(1-lambda_1)b.J||op <= |b|.
```

Consequently

```text
D(rho_N || Bhat_N rho_N)
 <= [3||A_0||op/a] E_(rho_N) r_j + B/a.
```

For all sufficiently large a,

```text
H_(N,j) <= [M r_j^2+(B+M/a)r_j] I,
H_(N,j) >= -[M r_j^2+(B+M/a)r_j] I.
```

The exponential hypothesis bounds all fixed polynomial radial moments uniformly. Choose a fixed R_* with `q_N{r_j<=R_*}>=1/2` for every N, using the uniform exponential tail. For a>=1 the lower operator bound yields

```text
Z_N(A,b) >= (1/2) exp[-M R_*^2-(B+M)R_*] =: c_*>0.
```

The upper bound and exponential slack yield

```text
E_(rho_N) r_j
 <= c_*^(-1) E_(q_N) r_j
        exp[M r_j^2+(B+M/a)r_j] = O(1)
```

uniformly in A,b. Hence `D=O(1/a)`. With natural logarithms and `T=||.||_1/2`, quantum Pinsker gives

```text
sup_(A,b) T(rho_N, Bhat_N rho_N) = O(a^(-1/2)).
```

This uses average spin, not maximum spin. It remains valid even if the largest available radius grows very rapidly.

## 2. The actual encoder/preparation composition

The raw encoder `M_N` measures j and the POVM `d_j P_(j,u)mu(du)` on spin, and discards multiplicity. The raw decoder `E_N` prepares `P_(j,u) tensor xi_(N,j)`.

For the stated Gibbs family every block factors as a spin state tensor the same known xi. Therefore

```text
E_N M_N rho_N(A,b) = Bhat_N rho_N(A,b)
```

exactly. The reset composition need not agree with Bhat on other inputs.

Indeed, in a multiplicity space of dimension m,

```text
(E_N M_N)(I_spin tensor I_mult)
    = I_spin tensor m xi_(N,j),
```

which equals the identity only when `xi_(N,j)=I_mult/m`. For example, `xi=diag(2/3,1/3)` gives `2xi!=I`. Applying the unital Jensen argument directly to the reset channel would therefore be incorrect. The equality on the family is sufficient for the proof above and for recovery below.

## 3. Averaged noncommuting symbol comparison is O(1/a)

Let `alpha=tr A/3`, and within a block write `H_j=H_(N,j)(A,b)`. Exact lower and upper symbols are

```text
h_j^-(u) = alpha j(j+1)/a^2
          + j(j-1/2)u^T A_0 u/a^2 + j b.u/a,
h_j^+(u) = alpha j(j+1)/a^2
          + (j+1)(j+3/2)u^T A_0 u/a^2 + (j+1)b.u/a.
```

They satisfy `h_j^-=<j,u|H_j|j,u>` and `H_j=Q_j(h_j^+)`. These formulas are valid also at j=0 and j=1/2: a redundant rank-two upper-symbol function may quantize to zero.

If `R_j(u)=<j,u|exp H_j|j,u>`, scalar Jensen in the spectral measure gives `R_j(u)>=exp(h_j^-(u))`. Applying scalar Jensen to each eigenvector using the positive upper-symbol representation gives the integrated upper bound

```text
integral R_j(u)dmu = Tr exp(H_j)/d_j
 <= integral exp(h_j^+(u))dmu.
```

Define

```text
epsilon_j = 3(j+1/2)||A_0||op/a^2+B/a.
```

Then `|h_j^+-h_j^-|<=epsilon_j`, and

```text
integral [R_j-exp(h_j^-)]dmu
 <= integral exp(h_j^-)(exp(epsilon_j)-1)dmu.
```

The lower symbol differs from the desired scalar exponent by

```text
h_j^-(u)-h(r_j,u)
 = [j/(2a^2)] [tr A-u^T A u],
|h_j^--h(r_j,u)| <= M r_j/a.
```

The last bound follows from `|tr A-u^T A u|<=2M`; no extra factor of three is needed. Since `||A_0||<=2M`, `epsilon_j<=C(1+r_j)/a` for a>=1, with C depending only on M,B. Using `exp(t)-1<=t exp(t)` for t>=0, the preceding inequalities imply

```text
sum_j q_N(j) integral |R_j(u)-exp(h(r_j,u))|dmu
 <= (C'/a) E_(q_N) (1+r_j)
      exp[M r_j^2+(B+C''/a)r_j+C''/a^2].
```

For sufficiently large a, `C''/a<=delta/2`. The remaining polynomial is absorbed by the unused quadratic/linear exponential slack, so the expectation is uniformly bounded. The displayed unnormalized L1 error is `O(1/a)`.

The raw measurement law is exactly `q_N(j)R_j(u)/Z_N`. Both its normalizer and the normalizer of `q_N(j)exp(h(r_j,u))` are bounded below uniformly. Normalizing two nonnegative densities preserves the `O(1/a)` conclusion:

```text
sup_(A,b) TV(M_N rho_N(A,b), C_(N,A,b)) = O(1/a),
C_(N,A,b)(j,du) = q_N(j)exp(h(r_j,u))mu(du)/z_(N,A,b).
```

There is no valid pointwise upper bound `R_j(u)<=exp(h_j^+(u))` asserted or required here. Only its integrated version is used.

## 4. Atomic and singular radial limits cause no obstruction

Let `F_N,F` be the CDFs of the un-tilted radial laws, and couple them by

```text
t ~ uniform(0,1), r_N=F_N^(-1)(t), r=F^(-1)(t).
```

Weak convergence implies `r_N -> r` for Lebesgue-a.e. t. Disintegrate this fixed coupling in both directions, and retain the same u. The resulting parameter-independent Markov kernels are `K_N^+:(j,u)->(r,u)` and `K_N^-:(r,u)->(j,u)`.

Explicitly, from a prelimit atom r_j, sample t uniformly from `(F_N(r_j^-),F_N(r_j)]`, then output `F^(-1)(t)`. In the reverse direction, sample t uniformly from `(F(r^-),F(r)]` when q has an atom at r; at a zero-mass point use `t=F(r)` for q-a.e. r. Output `F_N^(-1)(t)` and its unique corresponding j. General disintegration is an equivalent definition that avoids endpoint conventions. In particular, an atom at zero is harmless: its direction is parameter independent, and can be retained or redrawn uniformly.

Portmanteau gives

```text
E_q exp[(M+delta)r^2+(B+delta)r] <= C_exp.
```

On the coupling times sphere measure, put

```text
Delta_N = E sup_(A,b) |exp(h(r_N,u))-exp(h(r,u))|.
```

For R>=1, the compact region where both radii are at most R contributes at most

```text
exp(MR^2+BR)(2MR+B) R E min(1,|r_N-r|).
```

The expectation tends to zero by dominated convergence. On the remaining region, use `G(s)=exp(Ms^2+Bs)`, which is increasing. Pointwise the difference is at most `2G(max(r_N,r))`, and

```text
G(max(r_N,r)) 1_{max(r_N,r)>R}
 <= G(r_N)1_{r_N>R}+G(r)1_{r>R}.
```

The exponential slack therefore bounds the tail contribution by

```text
4 C_exp exp[-delta(R^2+R)].
```

First N->infinity, then R->infinity, proves `Delta_N->0` uniformly in the whole bounded parameter set. This argument deals directly with the supremum; it needs no appeal to an unjustified exchange of pointwise and uniform convergence.

The normalizers differ by at most Delta_N. The limiting normalizers are bounded below by

```text
c = E_q exp(-M r^2-B r)>0.
```

For all sufficiently large N, the prelimit normalizers are at least c/2. Comparing the two normalized densities on the common coupling gives both

```text
sup_(A,b) TV(K_N^+ C_(N,A,b), nu_(A,b)) <= 2 Delta_N/c,
sup_(A,b) TV(K_N^- nu_(A,b), C_(N,A,b)) <= 2 Delta_N/c.
```

Atoms require randomization inside their quantile interval; they do not require a density or radial TV convergence. The two kernels use only fixed base laws q_N and q, never tilted distributions or unknown A,b.

## 5. Assemble the two whole-experiment channels

Define

```text
T_N = K_N^+ M_N,
S_N = E_N K_N^-.
```

Contractivity, Section 3, and Section 4 yield

```text
sup_(A,b) TV(T_N rho_N,nu_(A,b))
 <= O(1/a_N)+2Delta_N/c -> 0.
```

For reverse recovery,

```text
T(S_N nu_(A,b),rho_N)
 <= TV(K_N^-nu_(A,b),C_(N,A,b))
    +TV(C_(N,A,b),M_Nrho_N)
    +T(E_NM_Nrho_N,rho_N)
 <= 2Delta_N/c+O(1/a_N)+O(a_N^(-1/2)) -> 0
```

uniformly in A,b. The equality in Section 2 supplies the last term. No exact identity `K_N^-K_N^+=id` is needed or generally true. Avoid claiming an exact transported encoder/decoder composition.

## Failure ledger and interface limits

1. **Unital reset shortcut:** false for nonmaximally mixed xi. The spin-only unital channel and equality on the family repair it exactly.
2. **Pointwise exponential upper symbol:** neither proved nor used. The eigenbasis/Jensen integrated bound is sufficient.
3. **Uniform maximum-spin defect:** can fail to vanish under the general scaling. The moment-weighted defect and exponential slack provide the correct bound.
4. **Direct radial TV replacement:** generally false when q has atoms or is singular. Fixed coupling/disintegration provides the correct statistical kernels.
5. **Exact composition after radial transport:** generally false. The triangle estimate above is the correct assembly.
6. **Entire equivalence at a stated polynomial rate:** not implied by weak radial convergence alone. Keep Delta_N as an unspecified vanishing radial remainder.
7. **External purification:** arbitrary internal multiplicity entanglement is covered; reconstruction of a system density does not preserve correlations with an external purification.
8. **Efficient implementation:** not claimed. The fixed decoder uses the known xi and the known base laws q_N,q; their descriptions, inverse-CDF sampling, Schur transform, and preparation of xi can be expensive. Statistical existence does not bound those costs.
9. **Boundary exponential moment without slack:** insufficient in general. For M>0,B=0, a rare mass `p_N=exp(-M R_N^2)` at `R_N->infinity` has vanishing un-tilted probability but order-one mass after the isotropic tilt A=MI. Thus weak convergence and bounded `E exp(MR_N^2)` do not give the claimed limit. The assigned positive slack excludes this construction.

## Sources and strongest next attack

The exact spin-coherent identities and scalar Jensen derivation are supplied in `work/agents/quantum_statistics/critical_gibbs_audit.md`, Sections 1, 2, and 4; I checked their algebra and small-spin cases directly. The reference/channel, tail, and radial-coupling arguments above are the independent extension needed for the present generalization. The separate radial audit is saved in this directory's `radial_transport/` subdirectory.

For this exact theorem there is no remaining load-bearing proof gap. The strongest separate next attack would be to obtain a quantitative, computable radial-coupling modulus and a charged preparation interface for general xi. Such results are not consequences of the present hypotheses and must not be advertised as already established.

Memory was used only to preserve the scope distinction between an internal audit, finite diagnostics, external correctness, and priority (`MEMORY.md:82,96-97`; rollout `01a1121a-4750-72f0-8f5c-b501038890d3`). No remembered mathematics was used as a proof premise.
