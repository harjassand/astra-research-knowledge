# Exact classical reconstruction threshold for unequal thermal displacement modes

Status: direct derivation, independently audited PASS in gibbs_l2_audit/UNEQUAL_THERMAL_BENCHMARK_AUDIT.md. The normal covariant-PPT reduction is the already audited imported mechanism in boundary_audit/growing_dimension/gaussian_eb_lower/EXACT_MULTIMODE_EB_BENCHMARK.md. The extension and consequences here have no external correctness or priority certification.

## Interface and theorem

For a fixed finite m, supply known means n_i>=0 and one unknown state

    rho_alpha = D(alpha) [tensor_i tau_(n_i)] D(alpha)^*, alpha in C^m,
    tau_n = sum_(k>=0) n^k/(n+1)^(k+1) |k><k|.

The reconstruction is an arbitrary normal entanglement-breaking channel, with no restriction to product measurements, Gaussian measurements, independent preparation or finite classical alphabet. The error is worst-case system-density trace distance; no purification must be preserved. Define

    e(n_1,...,n_m)=inf_EB sup_alpha T(Phi(rho_alpha),rho_alpha).

Then the exact candidate equality is

    e(n_1,...,n_m)
      =T(tensor_i tau_(n_i),tensor_i tau_(n_i+1))
      =TV(tensor_i Geom(mean n_i),tensor_i Geom(mean n_i+1)).

The same lower bound holds for arbitrary completely copositive channels. Product heterodyne followed by coherent-state preparation attains the EB upper bound. Every channel and datum is supplied mathematically; efficient acquisition/implementation is not implied.

## Lower bound: a weighted photon test

The established finite-volume displacement averaging argument produces a possibly subnormalized normal covariant completely copositive map. Complete copositivity gives a quantum-Bochner seed state sigma (or positive substate with trace c<=1). Its centered output on the supplied thermal input is

    tensor_i A_(2,n_i)(sigma),

where A_(2,n) is the gain-two phase-insensitive amplifier with thermal environment of mean n. Its exact factorization is

    A_(2,n)=A_(n+2,0) o L_(2/(n+2),0).

Thus the state after the loss maps can be arbitrary, including entangled or correlated. The test against the vacuum-seed output is diagonal in all individual photon numbers, so independently phase-twirling this seed preserves every test probability. The twirled seed is an arbitrary correlated mixture of Fock vectors k=(k_1,...,k_m).

For a product Fock input k, independent quantum-limited amplifiers output coordinate photon counts distributed as

    k_i + sum_(r=1)^(k_i+1) G_(i,r),
    G_(i,r) independent Geom(mean n_i+1).

Couple each coordinate using the same first G_(i,1); its output is pointwise at least the vacuum-input count G_(i,1). Consequently the vacuum output maximizes the probability of EVERY coordinatewise downward-closed photon region, including correlated mixtures of the input Fock seed. This is the missing argument that permits unequal n_i; no tensorization of a one-mode minimax inequality is assumed.

For n_i>0, let P be the target product photon law and Q the vacuum amplifier-output product law. Their likelihood ratio is

    log[Q(k)/P(k)]
       =sum_i [-log(1+a_i) - k_i log(1-a_i^2)],
    a_i=1/(n_i+1).

It increases in every k_i. Therefore its optimal total-variation test region {P>=Q} is coordinatewise downward closed. On that region the output of any allowed seed has probability at most Q, so the test gives the exact lower bound TV(P,Q). If n_i=0, the target photon count is exactly zero; require k_i=0 in that coordinate, and apply the same downward-closed test on the remaining coordinates. The equality also follows by an n_i downarrow0 limit.

Escaped covariant mass c<1 only strengthens this finite-test bound. The established bounded-box localization and normal-covariance proofs apply unchanged for each fixed finite m and supplied means.

## A complete sequence criterion

For arbitrary finite arrays (n_(r,1),...,n_(r,m_r)), set

    s_r=sum_i 1/(n_(r,i)+1)^2.

The single-coordinate classical root fidelity is exactly

    c_i = sum_k sqrt[P_i(k)Q_i(k)],
    c_i^2=[1+sqrt(1-a_i^2)]/2,
    a_i=1/(n_i+1).

The elementary inequalities

    a_i^2/8 <= -log c_i <= a_i^2/2

hold for 0<=a_i<=1. For the lower bound use c_i^2<=1-a_i^2/4. For the upper bound use c_i^2>=1-a_i^2/2 and -log(1-u)<=2u for 0<=u<=1/2. In fact -log c_i is convex as a function of a_i^2, so the chord from zero to one gives the sharper upper coefficient log(2)/2. Classical fidelity/TV inequalities give the dimension-independent bounds

    1-exp(-s_r/8) <= e_r <= sqrt[1-2^(-s_r)].

It follows exactly that

    e_r ->0 iff s_r ->0;
    s_r ->infinity implies e_r ->1.

The converse to the last implication also follows from the upper bound: e_r->1 forces s_r->infinity. Thus maximal failure occurs iff s_r diverges. A subsequence with s_r bounded away from zero has a positive error floor, regardless of individual mode thermalization.

## Critical window

Suppose max_i a_(r,i)->0 and s_r->c in (0,infinity). Write L=log(Q/P), ell_i=-log(1-a_i^2). Under P,

    E L_i=-log(1+a_i)+(1/a_i-1)ell_i
          =-a_i^2/2+O(a_i^3),
    Var L_i=(1-a_i)ell_i^2/a_i^2
            =a_i^2+O(a_i^3).

Under Q,

    E L_i=-log(1+a_i)+(1/a_i)ell_i
          =a_i^2/2+O(a_i^3),
    Var L_i=(1+a_i)ell_i^2/a_i^2
            =a_i^2+O(a_i^3).

Geometric centered third absolute moments are O(a_i^-3), so centered L_i third moments are O(a_i^3). Since sum_i a_i^3<=max_i a_i sum_i a_i^2->0, the triangular-array Lyapunov theorem applies under both P and Q. Their likelihood ratios converge to N(-c/2,c) and N(c/2,c). The LR-zero test therefore gives

    e_r -> 2 Phi(sqrt(c)/2)-1.

If some means remain finite, the exact product-TV formula and the universal bounds still apply; this Gaussian critical-window formula requires max_i a_i->0.

## Spectral interpretation and limitation

Pairwise intrinsic compatibility has a different aggregation rule. By [Banchi–Braunstein–Pirandola, arXiv:1507.01941](https://arxiv.org/html/1507.01941), equations (8)–(9), and the direct thermal-square-root calculation in boundary_audit/PAIRWISE_ENTROPY_BOUNDARY.md,

    F_root(rho_alpha,rho_beta)=exp[-sum_i s_i/(4n_i+2)],
    Tr[sqrt(rho_alpha)sqrt(rho_beta)]=exp[-sum_i s_i/D_i],
    s_i=|alpha_i-beta_i|^2,
    D_i=(sqrt(n_i+1)+sqrt(n_i))^2.

Set kappa_i=(4n_i+2)/D_i=1+D_i^(-2), and kappa_*=max_i kappa_i. For fixed x=sum_i s_i/(4n_i+2), the maximal gap assigns all displacement to a mode with kappa_i=kappa_*. Consequently

    sup_(alpha,beta)[F_root-affinity]
      =(kappa_*-1)kappa_*^[-kappa_*/(kappa_*-1)].

As min_i n_i->infinity, this is asymptotic to max_i(n_i+1)^(-2)/(16e), while full EB reconstruction is controlled by their SUM. Thus all pairwise defects vanish as the coldest mode heats, but the full statistical experiment remains nonclassical if sufficiently many modes are present. The finite-dimensional finite-state strengthening is proved in boundary_audit/PAIRWISE_ENTROPY_BOUNDARY.md. The reciprocal-temperature and weighted-likelihood parameters above are distinct; their roles must not be conflated.

In fixed-d full-rank distinct-spectrum quantum LAN, a unitary-orbit mode associated with p_i>p_j has thermal mean n_ij=p_j/(p_i-p_j). Hence

    1/(n_ij+1)=(p_i-p_j)/p_i,
    s(p)=sum_(i<j) [(p_i-p_j)/p_i]^2.

This is the exact thermal-displacement classical reconstruction threshold after LAN, for the full orbit's oscillator component. When p_i=(1+u_i)/d with max|u_i|->0 and sum_i u_i=0,

    s(p)=(1+o(1))sum_(i<j)(u_i-u_j)^2
         =(1+o(1))d sum_i u_i^2.

Thus the relevant sum can stay large while every relative gap vanishes. This gives a physical interpretation of dimension accumulation. Published fixed-d LAN permits an existential diagonal sequence, as in our earlier counterexample; it does not supply a uniform growing-d sample rate. No direct growing-d iid theorem, efficient compiler or retained quantum-memory lower bound follows merely by writing s(p).

## Sources

The exact covariance, multimode amplifier factorization and correlated-Fock stochastic domination mechanisms were audited in our equal-thermal benchmark. Its primary sources include [Guţă et al., arXiv:1004.1843](https://arxiv.org/abs/1004.1843), [Giovannetti et al., arXiv:1405.4066](https://arxiv.org/abs/1405.4066), and [Kahn–Guţă, arXiv:0804.3876](https://arxiv.org/abs/0804.3876). The latter is used only at each fixed d. Elementary geometric-law calculations and the triangular-array central limit theorem supply the threshold steps. Exact novelty remains open.
