# Efficient whole-state archive when a known 1D Gibbs sampler is supplied

Status: derived construction, independently audited PASS in collective_universality_audit/EFFICIENT_ARCHIVE_AUDIT.md. This is a quantum circuit and classical storage theorem, not a classical simulation algorithm on the user's Mac. It uses a currently claimed primary Gibbs-sampling theorem, whose full proof was not independently audited here.

## Contract

Known H_N is a bounded-range, bounded-strength SU(2)-invariant qubit Hamiltonian on a 1D ring. The fixed inverse temperature beta is sufficiently small for a uniform Gaussian concentration bound of total-spin components; alternatively supply the explicit radial tail premise below. One copy of the full state

    rho_(N,b)=omega_N exp(b.J/sqrt(N))/Z_(N,b), |b|<=R,
    omega_N=exp(-beta H_N)/Tr exp(-beta H_N)

is the unknown input. At beta>0 the field is physically local and uniform, of strength -b/(beta sqrt(N)) in Hamiltonian units. H_N and R are public; b is not supplied. No purification must be preserved. The local Hamiltonian has a polynomial-bit description or a polynomial-time absolute-precision evaluation algorithm; arbitrary noncomputable real couplings are not algorithmic inputs.

Assume an algorithm prepares known omega_N to any requested trace distance tau in quantum/classical time poly(N,1/tau) for this fixed beta/range/strength. arXiv:2609.35973v1, Theorem 2 and Corollary 1, is a new claimed supplier of this capability, with constants double exponential in beta. Known efficient Gibbs samplers can also be substituted; the new theorem is not required for pure mathematical existence.

Then for every fixed epsilon>0 and all sufficiently large N, a polynomial-time quantum encoder and randomized polynomial-time quantum decoder can reconstruct rho_(N,b) uniformly with error <=epsilon while retaining only M_epsilon classical labels, independent of N, and zero qubits. All labels count. The decoder can call the supplied known-reference preparation algorithm; those calls, fresh N-spin registers, Schur transformations and output gates are charged. No conditional multiplicity Gibbs state xi_j is separately supplied or acquired.

## 1. Positive finite coherent measurement

Perform the efficient qubit Schur transform. In spin j, the space V_j has dimension 2j+1<=N+1, while the multiplicity may be enormous. A coherent rank-one POVM can be replaced by a positive finite spherical quadrature exact through degree 2j+2: use equally spaced azimuths and Gauss-Legendre nodes for cos(theta), with O(j^2) points and positive product weights. The resulting identity resolution and rank-one coherent-channel multiplier on J_i are exact. Taking a more conservative degree 4j+4 also remains polynomial and covers every relevant integrand unambiguously.

Effects are E_(j,l)=(2j+1) w_(j,l)P_(j,u_l). Their matrix elements are explicitly computable from binomial coefficients, trigonometric functions and quadrature nodes. A generic Naimark isometry for the O(j)-dimensional spin register with O(j^2) outcomes has polynomial dimension, and standard finite-dimensional circuit synthesis gives polynomial(N,log(1/precision)) gate and classical-description costs. The multiplicity is discarded by the encoder. This is an inefficient polynomial exponent, sufficient for the computational distinction; no optimal circuit depth is claimed.

Let Q_N(j,l)=q_N(j)w_(j,l) be the reference distribution. Output x=(j/sqrt(N))u_l. The spin-only coherent channel fixes log omega_N and has rank-one multiplier j/(j+1), so Jensen/Pinsker give

    T(rho_(N,b), coherent_reconstruct(rho_(N,b)))
       <=sqrt[R/(2 sqrt(N))].

Exact lower/upper linear symbols are (j/sqrt(N))b.u and ((j+1)/sqrt(N))b.u. Scalar Jensen shows the raw outcome law differs from the ideal tilt Q_N(j,l)exp(b.x)/z_N(b) by at most 1-exp[-R/sqrt(N)]<=R/sqrt(N). This does not require a Gaussian limit or a radial convergence rate.

## 2. Finite archive and explicit error

Keep outcomes with |x|<=L and partition their x values into cubes of side h; put every outside outcome into one overflow label. Thus

    M<=1+(ceil(2L/h)+1)^3.

Only this cell label persists. All j, direction, Schur, measurement and input-dependent scratch registers are discarded.

For a retained cell C, the ideal decoder draws a reference outcome (j,l) from Q_N conditioned on x in C and prepares P_(j,u_l) tensor xi_j, undoing Schur. For overflow it prepares any fixed known state. Within a cell, exp(b.x) varies by at most a factor exp(R sqrt(3)h); the coarse-grid reversible reference kernel therefore changes the ideal tilted law by at most exp(R sqrt(3)h)-1, plus at most the ideal overflow probability.

The overall exact-reference reconstruction bound is consequently

    error <=sqrt[R/(2 sqrt(N))]+2R/sqrt(N)
          +exp(R sqrt(3)h)-1+ideal_tilt_tail(L).

If q_N has a uniform bound P(j/sqrt(N)>t)<=C0 exp(-c0 t^2), the ideal tilt tail is uniformly at most C_R exp(-c_R L^2) after enlarging the fixed constants. Choose h=O_R(epsilon), L=O_R(sqrt(log(1/epsilon))) and then N large. No claimed sharp memory exponent is needed.

SU(2) invariance and component concentration supply the radial tail without joint measurements. Conditional on j, the spectral distribution of J_z is uniform on -j,...,j. For every j>0, the fraction with |J_z|>=j/2 is at least 1/2. With Delta=beta_c-beta>0, the conservative Theorem-1-derived component tail is 2exp[-Delta x^2/(4N)] and hence q_N(j/sqrt(N)>t)<=4exp[-Delta t^2/16].

## 3. The key conditional-reference preparation trick

For label C, prepare a FRESH known omega_N, perform Schur and measure j, retaining its actual multiplicity subsystem xi_j. Independently sample l from the public per-j quadrature weights. Accept if x lies in C. On acceptance replace the spin subsystem by P_(j,u_l), keep the reference multiplicity subsystem already present, and undo Schur. This exactly prepares the conditional reference decoder state. It does not compute, classically represent or separately prepare xi_j.

Let Q(C) be the reference acceptance probability and P_b(C) the ACTUAL raw unknown-input cell probability. With the shared rounded-coordinate convention of Section 4, ||b.J/sqrt(N)|| on each retained sector is at most R(L+zeta) and Z_(N,b)>=1 (scalar Jensen and Tr omega_N J=0),

    P_b(C)<=exp[R(L+zeta)]Q(C).

Therefore with exact reference preparations,

    E_(input label) number_of_reference_calls
        <=1+sum_retained_C P_b(C)/Q(C)
        <=1+M exp[R(L+zeta)],

independent of N. The one is for overflow. Exponentially small individual cell probabilities do not create an average input-cost blowup. The memory record remains just C; quantum registers generated during decoding are output/workspace, not retained input-dependent information.

## 4. Precision, rare cells and capped runtime

Abstract conditional sampling has an unbounded worst-case geometric runtime. A polynomial expected-time algorithm follows from the bound above. To make a uniform bounded-time approximation, cap the TOTAL reference attempts at K_attempt and prepare a fixed fallback if all trials fail. Markov's inequality bounds the averaged failure probability by [1+M exp(R(L+zeta))]/K_attempt, uniformly in b. Choosing K_attempt=O(M exp(R(L+zeta))/epsilon) depends only on requested error/R, not N.

Approximate reference preparation with trace distance tau accumulates at most K_attempt tau by a hybrid argument over those bounded trials, including all measurements, accept/reject decisions and fallback. The sampler's random classical state descriptor is discarded before the acceptance decision, which depends only on j and the independent quadrature draw. The same hybrid argument covers approximate Schur transforms, quadrature sampling and generic POVM gates. Choose the sum of all primitive errors per trial O(epsilon/K_attempt), and distribute each primitive's budget across its compiled gates. Thus no exact Q(C) acquisition, rare-cell probability calibration, least-eigenvalue computation or postselection stability estimate is needed for a bounded-error capped algorithm.

Numerical grid boundaries are handled by defining the PUBLIC label map on uniformly rounded quadrature coordinates tilde x, computed to absolute error zeta. Both encoder and decoder use the same stored map, so no near-boundary algebraic comparison must be acquired exactly. Two true coordinates in the same cube are separated by at most sqrt(3)h+2zeta; retained norms are at most L+zeta, and overflow has true norm above L-zeta. Taking zeta=O(epsilon/R) absorbs this in the error bounds. Approximate Naimark columns can be Gram-normalized by a polar correction because the exact columns are orthonormal and their approximate Gram matrix has least eigenvalue bounded away from zero; circuit synthesis then uses uniform absolute precision. Exponentially small individual coherent amplitudes need not be resolved to relative precision.

This simplification is stronger than the initial offline cell-calibration proposal: direct capping plus hybrid error accounting handles every rare cell and keeps all preprocessing/runtime costs polynomial in N and 1/epsilon at fixed R,beta,local range. Since L=O(sqrt(log(1/epsilon))) and M polynomial in 1/epsilon, exp(RL) is subpolynomial in 1/epsilon (up to constants depending R), so the cap and tau precision retain polynomial epsilon dependence.

## Sources and limits

* [Pilatowsky-Cameo et al., 2609.35973v1](https://arxiv.org/html/2609.35973v1), Theorem 2, Corollary 1: known 1D Gibbs state preparation/sampling. This premise is new; the theorem's proof is imported, not certified here.
* [Bacon, Chuang, Harrow, quant-ph/0407082](https://arxiv.org/abs/quant-ph/0407082): efficient Schur circuits, polynomial(n,d,log(1/epsilon)).
* [Kuwahara–Saito, 1906.10872v2](https://arxiv.org/html/1906.10872v2), Theorem 1: high-temperature moment generating bound. Its Corollary 1 proof has an apparent factor-two completing-square typo; use the conservative independently derived tail 2exp[-(beta_c-beta)x^2/(8 Fbar)] from Theorem 1, not the printed Corollary 1 constant.
* Coherent-state Gibbs approximation is established prior art; the contribution here is the charged conditional-multiplicity preparation construction and composition, with priority unresolved.

No practical advantage on classical hardware is implied. A physical quantum device is needed for the encoder/reference preparations. Decoder output depth includes Schur transforms and need not remain constant, despite constant-depth reference preparation. This construction does not extend to generic non-SU(2) unknown local Hamiltonians, an inaccessible unknown reference, external purification preservation, or the growing-dimensional near-tracial families with quantum EB floor.
