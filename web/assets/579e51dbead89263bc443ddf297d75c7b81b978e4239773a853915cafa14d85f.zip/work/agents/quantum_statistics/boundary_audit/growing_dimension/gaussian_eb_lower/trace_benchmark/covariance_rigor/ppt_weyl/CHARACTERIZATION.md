# Finite-mode normal covariant CP/coCP Weyl characterization

Audit date: 2026-10-07. Scope is the characterization after a normal covariant map has already been obtained. This note does not justify noncompact averaging, preservation of normality under an invariant mean, or existence of a normal covariant minimax optimizer.

## Exact result

Let H be the finite-m-mode Schrödinger Hilbert space, let D(z), z in R^(2m), be its irreducible strongly continuous Weyl system with

    D(z)D(w) = exp[-i σ(z,w)/2] D(z+w).

Let L:B(H)->B(H) be a bounded normal map covariant for conjugation by every D(a). Let Θ be a normal matrix-transposition map, and let Z be the anti-symplectic real involution implementing Θ(D(z))=D(Zz). Assume Θ∘L is completely positive and L(I)=tI, t>0. Then there is a unique positive trace-class m-mode density operator τ such that

    L(D(z)) = t χ_τ(√2 z) D(z),
    χ_τ(u) = Tr[τ D(u)].

Conversely, every such τ defines a unique bounded normal covariant coCP map of this form with L(I)=tI. If L is additionally CP, precisely those τ whose Wigner distribution is a nonnegative probability measure are allowed. Equivalently χ_τ (and hence χ_τ(√2·)) must also be an ordinary continuous positive-definite characteristic function. For finite-mode trace-class τ this is the usual Wigner nonnegativity condition.

For a normal trace-decreasing CP/coCP Schrödinger map Ψ, its dual L=Ψ* satisfies L(I)=tI automatically by covariance and irreducibility, with 0<=t<=1. If t>0, Ψ/t is trace-preserving CP/coCP and the displayed characterization applies. If t=0 then the positive map Ψ is zero.

## Direct necessity proof

1. Covariance makes L(D(z)) an eigenoperator for the same displacement-conjugation character as D(z). Thus L(D(z))D(z)* commutes with every Weyl operator. Irreducibility implies

       L(D(z)) = f(z)D(z).

   In particular f(0)=t. The same commutant argument applied to L(I) gives the scalar t.

2. Normality gives an actual trace-class predual L_*. Let ρ0 be the m-mode vacuum, with χ_ρ0(z)=exp(-|z|²/4), which never vanishes. Then

       f(z) = Tr[L_*(ρ0)D(z)] / exp(-|z|²/4).

   Characteristic functions of trace-class operators are continuous by strong continuity of D and finite-rank approximation. Therefore f is continuous everywhere. This is the exact point at which a nonnormal invariant-mean output cannot automatically be substituted.

3. Put M=Θ∘L. Its action is M(D(z))=f(z)D(Zz), and M is CP. For any finite z1,...,zN, the matrix [D(zj)D(zk)*] is positive in M_N(B(H)), so CP gives the positive block matrix [M(D(zj)D(zk)*)]. Weyl multiplication and congruence by diag(D(Zzj)*) reduce it to the scalar matrix

       [ f(zj-zk) exp{ i[σ(zj,zk)-σ(Zzj,Zzk)]/2 } ] I
       = [ f(zj-zk) exp{ i σ(zj,zk) } ] I.

   Hence f/t is 2σ-positive in the quantum-Bochner sense. Set

       g(u)=f(u/√2)/t.

   Its twisted positive matrix has phase exp[i σ(uj,uk)/2]. It is continuous, normalized at zero, and σ-positive. Finite-mode quantum Bochner therefore gives g=χ_τ for a unique positive trace-class density τ. Rearranging yields f(z)=tχ_τ(√2z), not χ_τ(z/√2).

4. If L itself is CP, repeat step 3 with Z=I. The symplectic defect is zero, so f/t is ordinary positive definite. By ordinary Bochner it is the Fourier transform of a probability measure. Invertible dilation preserves ordinary positive definiteness, so χ_τ also has this property. Its inverse symplectic Fourier transform, the Wigner distribution of τ, is the same nonnegative probability measure. Conversely, Wigner nonnegativity gives ordinary positive definiteness and hence the normal random-displacement CP map with this multiplier.

The quantum-Bochner source below is explicitly a density-operator theorem; no separate L² hypothesis is needed. It supplies trace-class τ directly, rather than only a possibly nonregular state on an abstract discrete Weyl algebra.

## Sufficiency and normal extension

For any density τ, f=tχ_τ(√2·) is continuous, has f(0)=t, and is 2σ-positive. With K=Z the symplectic defect σ-K^TσK is 2σ, so the finite-mode linear-bosonic-channel theorem defines a normal CP map M with M(D(z))=f(z)D(Zz). Then L=Θ∘M is bounded normal coCP and has the required diagonal Weyl action. It is covariant because that action has the required conjugation characters, and the span of the Weyls is ultraweakly dense in B(H). The same density and normality show uniqueness.

If τ also has nonnegative Wigner distribution, ordinary Bochner gives a displacement probability measure. Integrating unitary conjugations against that measure defines a normal CP map L. Its diagonal Weyl multiplier equals f/t. Normality and Weyl uniqueness identify this CP map with the coCP construction. Scaling by t gives the subchannel when 0<t<=1.

## Primary sources and exact locations

- Owari, Plenio, Polzik, Serafini, Wolf, *Squeezing the limit: Quantum benchmarks for the teleportation and storage of squeezed states*, arXiv:0808.2260v1, Appendix A, Lemma 2 and Eq. (A.1), printed p.17; Lemma 3, Eqs. (A.2)-(A.4), printed p.17; Lemma 4, Eqs. (A.5)-(A.6), printed p.18. Main Eqs. (14)-(15), printed p.6 use the correct √2 scaling. https://arxiv.org/pdf/0808.2260v1
- Demoen, Vanheuverzwijn, Verbeure, *Completely positive maps on the CCR-algebra*, Letters in Mathematical Physics 2, 161-166 (1977), DOI 10.1007/BF00398582. Owari's reference [40] is this 1977 paper; the later *Completely positive quasi-free maps of the CCR-algebra*, Reports on Mathematical Physics 15, 27-39 (1979), is a different paper. Original publisher abstract says it characterizes the general induced CP map for any operator on the testfunction space. Full 1977 proof was not obtained in this audit; the exact usable theorem and full independent proof are available in Lami et al. below. https://link.springer.com/article/10.1007/BF00398582
- Lami, Sabapathy, Winter, *All phase-space linear bosonic channels are approximately Gaussian dilatable*, arXiv:1806.11042v2, Lemma 2 (Quantum Bochner Theorem), printed pp.5-6, gives normalized + continuous at 0 + Ω-positive iff characteristic function of a density operator. Appendix A, printed pp.22-27, gives a direct full proof. Lemma 3, printed pp.6-7, gives linear-map CP iff normalized + continuous + J(X)-positive for J(X)=Ω-X^TΩX; Appendix B, printed pp.27-29, gives a full proof. https://arxiv.org/pdf/1806.11042v2
- Holevo's cited book theorem is *Probabilistic and Statistical Aspects of Quantum Theory* (2011), §5.4, Theorem 5.4.1, identified in the primary Lami et al. text immediately before Lemma 2. The full book theorem text was not directly accessed, so the directly read Lami theorem is the operative proof source. Publisher chapter: https://doi.org/10.1007/978-88-7642-378-9_5
- Independent delegated check: Dammeier-Werner, arXiv:2208.05020v3, Theorem 4, printed p.15, with Definition 1 p.12 and Theorem 3 p.13, yields the same standard/normal density-operator conclusion for finite nondegenerate modes. Detailed verification is in `normal_bocher_sources/primary_verified.md`. https://arxiv.org/pdf/2208.05020v3
- Independent delegated Wigner check: Dangniam-Ferrie, arXiv:1410.5755v2, Theorem 2(2), printed p.3, Eq. (7), gives ordinary untwisted positive definiteness of χ as equivalent to nonnegative Wigner for a valid state. Detailed verification is in `normal_bocher_sources/wigner_primary/RESULT.md`. https://arxiv.org/pdf/1410.5755v2

## Failure ledger: source inaccuracies that must not be inherited

1. Owari Appendix A Lemma 4 Eq. (A.5) prints f(ξ/√2)Wξ with f a standard quantum characteristic function. The accompanying proof has symplectic defect 2σ, which forces f(√2ξ) instead. Main Eq. (15) agrees with √2. Direct check: vacuum f(u)=exp(-|u|²/4); printed inverse scaling gives multiplier exp(-|ξ|²/8), whose rescaled Bochner candidate has covariance I/4, below the quantum uncertainty bound. It is not coCP.

2. Owari main text after Eq. (15) says every density τ gives an admissible phase-space covariant channel. That is true for a positive coCP map, but does not guarantee CP. If 'time-reversible channel' requires both CP and coCP, the converse needs Wigner nonnegativity. One-mode τ=|1><1| has

       χ_τ(u)=(1-|u|²/2)exp(-|u|²/4),
       f(z)=χ_τ(√2z)=(1-|z|²)exp(-|z|²/2).

   Its ordinary inverse Fourier transform is (|x|²-1)(2π)^(-1)exp(-|x|²/2), negative near the origin. Hence f is not ordinary positive definite and cannot be the multiplier of a CP displacement-covariant map. The necessary representation, and upper bounds obtained by optimizing over all τ as a relaxation, are unaffected.

## Strongest next check

The characterization is proved for a normal covariance output, including trace-decreasing mass t. The remaining potential gap belongs to the parent audit: prove the noncompact symmetrization produces or dominates a normal covariant CP/coCP subchannel with enough success mass and the relevant loss/overlap bound. This note does not treat normality of such an averaged object as established.
