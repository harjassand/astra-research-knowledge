# Noncompact covariance audit for the thermal trace benchmark

Status: the normality / escaped-mass obstruction is closed by a subnormalized normal-channel limit. A full normal trace-preserving covariant minimizer need not be obtained or asserted. The finite-rank lower-bound witness survives the trace loss. The Gaussian majorization theorem is an explicit separate dependency, handled by the parent.

## Exact interface

Let H be the m-mode Fock space for finite m. Let U_x be its irreducible Weyl representation of R^(2m), and let rho_x=U_x rho_0 U_x^*. An allowed strategy T:T1(H)->T1(H) is an arbitrary normal channel which is entanglement breaking (EB). The argument below actually requires only that T is CP, trace preserving, and completely copositive (coCP). Write

    epsilon = sup_x (1/2)||T(rho_x)-rho_x||_1.

No displacement prior, finite energy restriction on the strategy, Gaussianity, tensor-product structure of the strategy, or compactness of the parameter orbit is imposed.

## Lemma: covariant subnormalized limit

There is a bounded linear CP/coCP map S:T1(H)->T1(H), a scalar c in [0,1], and a sequence of finite Følner twirls T_Rj, such that:

1. T_Rj(a) converges to S(a) in sigma(T1(H),K(H)) for every a in T1(H).
2. S(U_x a U_x^*) = U_x S(a) U_x^* for every x and a.
3. S^*(I)=cI, equivalently Tr S(a)=c Tr a for every a.
4. Every finite-rank projection P satisfies

       Tr P S(rho_0) >= Tr P rho_0 - epsilon.

If c>0, S/c is a normal displacement-covariant PPT channel. If c=0, S is the zero map.

### Proof

For C_R=[-R,R]^(2m), define the Bochner integral

    T_R(a) = (1/|C_R|) int_C_R U_x^* T(U_x a U_x^*) U_x dx.

The integrand is trace-norm continuous in x for each traceclass a. Each integrand channel is CP, coCP, trace preserving, and EB. The integral is a normal CP/coCP channel; EB is also preserved, though the later limit only needs CP/coCP. Convexity and displacement covariance of the target family give

    (1/2)||T_R(rho_0)-rho_0||_1 <= epsilon.

Also ||T_R||_(1->1)=1, and for every y and a,

    ||T_R(U_y a U_y^*) - U_y T_R(a) U_y^*||_1
       <= (|(C_R+y) symmetric_difference C_R|/|C_R|) ||a||_1.

The right side tends to zero for fixed y.

The traceclass is the Banach dual of the compact operators, T1(H)=K(H)^*. Since K(H) is separable, each norm-bounded set in T1(H) is sequentially compact for sigma(T1,K). Choose a countable trace-norm-dense set of inputs (for example finite linear combinations of matrix units with rational complex coefficients). A diagonal subsequence of integer R makes T_R(a) converge weak* for every input in that set. The uniform 1->1 contraction bound extends convergence to every a: for a compact observable K, approximate a by a dense input b and bound the resulting errors by 2||K|| ||a-b||_1. The limit functional on K has norm at most ||a||_1, so it is represented by a unique traceclass S(a). This construction also gives linearity and ||S||_(1->1)<=1.

Positivity survives this convergence: finite-rank positive observables test positivity of traceclass operators. The same argument at every finite matrix level proves complete positivity. More explicitly, each positive input block A=[a_ij] in T1(H tensor C^k) has positive output [T_R(a_ij)]; its pairings with every positive finite-rank block observable converge entry by entry, hence [S(a_ij)] is positive. For coCP use output transposition theta in a fixed Fock basis. Transposition maps K(H) to K(H), so it is sigma(T1,K)-continuous. Therefore theta composed with S is CP, since theta composed with T_R is CP at every finite matrix level. This is sufficient for the PPT relaxation. The pre-transpose and post-transpose formulations are equivalent: conjugating a CP map on both sides by theta preserves CP.

S maps traceclass to traceclass and is bounded, so its adjoint S^*:B(H)->B(H) is automatically normal. For positive a, finite-rank projections P_n increasing strongly to I give

    Tr S(a)=sup_n Tr P_n S(a) <= Tr a.

Thus S is trace nonincreasing. Passing the Følner error to the weak* limit, using that conjugation maps compact observables to compact observables, proves covariance on all traceclass inputs. Dual covariance then implies that S^*(I) commutes with every U_x. Weyl irreducibility gives S^*(I)=cI; positivity and trace nonincrease give 0<=c<=1. If c=0, every positive output has trace zero and hence is zero, so linearity makes S=0. If c>0, S/c is a normal CPTP/coCP channel.

Finally, since T_R(rho_0) and rho_0 both have trace one,

    Tr P T_R(rho_0) >= Tr P rho_0 - epsilon

for every projection P. Finite-rank P lies in K(H), so this inequality passes to S. Notice that this last step never takes the trace of the weak* limit as if total mass had been preserved. QED.

## Consequence for the parent's majorization witness

Take rho_0 = thermal_N tensor ... tensor thermal_N, with N>=0. Let P_K project onto all m-mode number vectors of total photon number at most K; it has finite rank choose(K+m,m). Suppose the normal PPT Weyl characterization and the multimode Gaussian amplifier majorization theorem imply, for every normal covariant PPT channel Q,

    Tr P_K Q(rho_0) <= F_(m,N+1)(K),

where F_(m,M) is the total-photon CDF of thermal_M^tensor m. Then the subnormalized S above satisfies

    Tr P_K S(rho_0) <= c F_(m,N+1)(K) <= F_(m,N+1)(K)

(with the same statement trivial if c=0). Combining with item 4 yields

    epsilon >= F_(m,N)(K) - F_(m,N+1)(K)

for every K. Thus arbitrary normal EB channels cannot beat the parent's cutoff lower bound. Heterodyne followed by coherent preparation has output thermal_(N+1)^tensor m, so the best crossing cutoff gives equality. This consequence is conditional only on the cited normal-PPT characterization and the parent's Gaussian-majorization/crossing checks, not on any unproved noncompact normality assertion.

## Source and failure ledger

1. Guţă, Bowles and Adesso, arXiv:1004.1843v2, Section IV, Theorem IV.1 and Eq. (7), use the single-mode covariance/PPT/amplifier route. The covariance step is described by a reference rather than a complete normality proof. Their reference [9] is Owari et al., New J. Phys. 10, 113014 (2008), not PRA 78, 032316. URL: https://arxiv.org/html/1004.1843v2#S4
2. Owari et al., arXiv:0808.2260v1, Section 3, Eqs. (9)-(10), explicitly replace compact averaging by an invariant mean. Appendix A, Lemmas 2-4, treats finite multimode Weyl maps. URL: https://arxiv.org/html/0808.2260v1#A1 . Main Eq. (15) has chi_tau(sqrt(2)xi), while Appendix Lemma 4 Eq. (38) prints xi/sqrt(2); the latter scaling is inconsistent with its own modified symplectic form 2 sigma and is a source typo. Derive the scaling directly.
3. Owari's assertion that every arbitrary tau yields a channel is overbroad unless CP is separately imposed. CP of the unit-gain map requires its multiplier to be a classical characteristic function; coCP supplies the quantum-characteristic condition at doubled symplectic form. The lower bound only needs the necessary representation and can enlarge to arbitrary normal tau afterward. The independent ppt_weyl agent owns that detailed check.
4. Werner, arXiv:quant-ph/0405184v1, Section 2.4 (weight at infinity) and Section 4 (reduction to the covariant case), explicitly identifies the escaped-mass issue in noncompact invariant-mean arguments. URL: https://arxiv.org/html/quant-ph/0405184 . This supports the need for the repair; the proof above is independent and does not import Werner's measurement metric or tightness assumptions.
5. Lami, Sabapathy and Winter, arXiv:1806.11042v2, Lemma 2 and Appendix A, give quantum Bochner with exactly normalization at zero, continuity at zero, and symplectic-positive-definiteness; the conclusion is a positive trace-class density operator. Lemma 3 and Appendix B give CP for linear Weyl maps through the defect symplectic form J(X)=Omega-X^T Omega X. URL: https://arxiv.org/html/1806.11042v2 . These theorem statements were read directly in the current audit.

## Normal PPT multiplier lemma

For a normal displacement-covariant PPT channel Q, irreducibility gives

    Q^*(D(z)) = f(z) D(z).

Normality makes f continuous: the output state Q(vacuum) is traceclass and

    f(z) = chi_(Q(vacuum))(z) / chi_vacuum(z),

where chi_vacuum(z)=exp(-|z|^2/4) never vanishes in real Weyl coordinates. The normal unital map theta composed with Q^* is CP (use the input-transpose formulation of coCP); its Weyl matrix is the time-reversal Z, where Z^T Omega Z=-Omega. The defect is therefore 2 Omega. Lemma 3 of arXiv:1806.11042v2 implies that f is 2 Omega-positive. Define g(u)=f(u/sqrt(2)); substitution in the finite positivity matrices makes g Omega-positive, continuous, and normalized. Lemma 2 implies g=chi_tau for a normal density operator tau. Hence

    Q^*(D(z)) = chi_tau(sqrt(2) z) D(z).

There is no extra L2 integrability assumption, energy assumption, or Gaussianity assumption on tau. For the subnormalized S above the multiplier is c chi_tau(sqrt(2) z) if c>0. The original CP condition additionally makes the multiplier a classical characteristic function; this extra property can be discarded when enlarging the optimization over tau for a lower bound.

## What is not claimed

The construction does not establish that arbitrary EB channels admit a trace-preserving normal covariant twirl with no larger trace risk. That stronger statement is unnecessary and should not appear in the benchmark proof. It does establish the exact lower bound through normal trace-decreasing limits and finite-rank witnesses. The argument is for every finite m; it does not construct a countably infinite-mode Fock/CCR minimax theorem.
