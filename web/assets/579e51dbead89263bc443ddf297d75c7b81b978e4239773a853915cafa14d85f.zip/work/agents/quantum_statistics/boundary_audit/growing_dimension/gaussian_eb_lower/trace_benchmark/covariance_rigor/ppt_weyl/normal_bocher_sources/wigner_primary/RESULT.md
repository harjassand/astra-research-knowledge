# Exact Wigner positivity / ordinary Bochner criterion

Verified 7 October 2026 from primary paper text. This is a sourced standard theorem, not a new result.

## Direct statement

Dangniam and Ferrie, *Quantum Bochner's theorem for phase spaces built on projective representations*, arXiv:1410.5755v2 (12 February 2015), **Section II.A, Theorem 2, PDF page 3**, especially item 2; the definition is **equation (7)** on the same page.

https://arxiv.org/pdf/1410.5755v2

https://arxiv.org/html/1410.5755

Theorem 2 distinguishes operator positivity, characterized by 1-positive definiteness, from simultaneous operator positivity and nonnegative Wigner representation, characterized by both 1-positive and 0-positive definiteness. Equation (7) defines gamma-positive definiteness with multiplier exp[i gamma (zeta_j eta_k - zeta_k eta_j)/2]. For gamma=0 the phase disappears, giving ordinary positive definiteness. Since the input is already a density operator, the 1-positive condition is automatic. This section explicitly displays one mode; the finite-mode statement follows with the sum of the mode symplectic forms, or from Werner's arbitrary finite-dimensional phase-space formulation below.

**Caution:** their Theorem 1 loosely formulates classical Bochner as producing a probability density. The general classical theorem produces a probability measure; density requires an extra argument.

## Rigorous finite-mode formulation

Let rho be a positive trace-class operator of trace one on L2(R^m), m finite. Put D(z)=exp(-i z^T R), [R_a,R_b]=i Omega_ab, and chi(z)=Tr[rho D(z)]. Then

W_rho >= 0 almost everywhere **if and only if**

[chi(z_k-z_j)]_(j,k) >= 0 for every finite collection z_1,...,z_N in R^(2m).

Quantum positivity instead asserts

[chi(z_k-z_j) exp(+i z_j^T Omega z_k/2)]_(j,k) >= 0.

The sign here follows the declared convention D(z)D(w)=exp(-i z^T Omega w/2)D(z+w); changing Weyl/Fourier conventions changes this sign but never removes the phase from the quantum condition. Positivity of rho implies the latter matrix by applying Tr[rho A* A]>=0 to A=sum_j c_j D(z_j).

## Integrability caveat and its resolution

Werner, *Quantum harmonic analysis on phase space*, Journal of Mathematical Physics **25 (1984), 1404–1411**, **Proposition 3.4(4), (6), (7), page 1407**, treats arbitrary finite-dimensional symplectic phase space. Parts (4),(6) give the Hilbert-Schmidt/Plancherel identity and chi in C0 intersect L2 for trace-class rho. The paragraph immediately after the proof of Proposition 3.4 explicitly warns that a general Wigner function need not be integrable.

Primary paper PDF:
https://wiki.math.ntnu.no/_media/ma8107/2024h/werner_-_quantuysis_on_phase_spacem_harmonic_anal.pdf

Independent short argument: ordinary positive definiteness, continuity and chi(0)=1 yield a probability measure mu by classical Bochner. Because chi is L2, its inverse Fourier transform is an L2 function. Fourier uniqueness in tempered distributions forces mu=W_rho dx. Thus W_rho is nonnegative and becomes L1, with integral one. No chi in L1 assumption is needed.

Conversely, if W_rho>=0 as an L2 function, pair it with exp(-epsilon |x|^2). Fourier duality and continuity of chi at zero show these Gaussian-cutoff integrals tend to chi(0)=1 as epsilon decreases to zero. Monotone convergence gives integral W_rho=1; its Fourier transform is therefore ordinary positive definite.

For an arbitrary normalized continuous ordinary-positive-definite function unconnected to a density operator, the inverse may be a singular probability measure. The quantum-state / L2 hypothesis is what excludes that issue here. Without integrability of chi, a pointwise absolutely convergent inverse-Fourier integral is not justified; use the L2 inverse or distributions.

Hudson's 2009 preprint is published as Kybernetika 46(6) (2010), 1061–1068. Its Theorem 3.1 and Section 4 (p.1064) independently distinguish multiplier-positive definiteness from ordinary positive definiteness and explicitly use Fourier-Plancherel. Exact follow-up audit is in hudson_check/result.txt.

Publisher primary PDF: https://www.kybernetika.cz/content/2010/6/1061/paper.pdf
