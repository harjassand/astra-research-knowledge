# Finite-mode Bochner normality: primary-source verification

Scope: source check only. No covariance, PPT, channel, or energy theorem is established here.

## Verified primary theorem

Dammeier and Werner, *Quantum-Classical Hybrid Systems and their Quasifree Transformations*, Quantum 7, 1068 (2023), https://quantum-journal.org/papers/q-2023-07-26-1068/ ; author version https://arxiv.org/pdf/2208.05020v3 .

- Definition 1, printed p.12: a standard state is represented by a density operator in the standard representation; its quantum factor is the Schrödinger representation.
- Theorem 3, printed pp.13-14: strongly continuous Weyl representations are direct sums of standard representations. The paragraph after the statement explicitly equates separate one-axis regularity with joint continuity in finite dimension.
- Theorem 4, printed p.15: continuity, chi(0)=1, and sigma-twisted positive definiteness characterize standard states. With their convention, its matrix is chi(-xi_k+xi_l) exp[-i sigma(xi_k,xi_l)/2].
- The proof passes through the continuous GNS representation and Theorem 3. Thus setting the classical part to zero gives a genuine positive trace-class density operator on the fixed Schrödinger Hilbert space, not just an abstract CCR state.

This is an independently read normality justification for the finite nondegenerate quantum case. The theorem is finite-mode and must not be transferred to infinitely many modes. For a degenerate form with a classical part, standard states allow arbitrary classical probability measures, not only Lebesgue densities.

## Independent representation statement

Jan Dereziński, *Introduction to Representations of the Canonical Commutation and Anticommutation Relations*, https://arxiv.org/pdf/math-ph/0511030v2 ; published chapter DOI https://doi.org/10.1007/3-540-32579-4_3 .

Section 3.2, Theorem 4, printed p.12, states that any regular CCR representation over a finite-dimensional nondegenerate symplectic space is unitarily equivalent to the Schrödinger representation on L²(X) tensor a multiplicity space K. Irreducibility is equivalent to K being one-dimensional. This confirms the direct-sum/multiplicity claim independently.

## Explicit normality and uniqueness consequence

This paragraph is a direct mathematical reconstruction, not an additional quoted source theorem. Quantum Bochner constructs a GNS unit vector Omega. In the finite nondegenerate case, Stone-von Neumann gives H = H_S tensor K and pi(W(z)) = W_S(z) tensor I. Therefore rho = Tr_K |Omega><Omega| is positive trace-class with trace one and chi(z) = Tr rho W_S(z). The Weyl family acts irreducibly, so its linear span is weakly dense in B(H_S); normal linear functionals agreeing on every Weyl operator agree on B(H_S). Consequently rho is unique. No separate assumption chi in L² is needed; this follows from rho being trace-class and hence Hilbert-Schmidt.

## Holevo exact book location: identified, not directly read

Holevo, *Probabilistic and Statistical Aspects of Quantum Theory* (2011), Chapter 5, Section 5.4, Theorem 5.4.1. Publisher chapter https://doi.org/10.1007/978-88-7642-378-9_5 . The chapter spans pp.187-218; Section 5.4 begins at p.201 according to the indexed contents. The exact theorem number is cited by Lami-Sabapathy-Winter directly preceding their Lemma 2 at pp.5-6: https://arxiv.org/pdf/1806.11042v2 . Publisher full chapter text was subscription-limited; do not claim its theorem page or wording was directly inspected here. Lami et al. Lemma 2 is the directly accessible equivalent statement and their Appendix A gives an independent proof. Parent already independently located and read this source.

## Failure/caveat ledger

- General abstract CCR positivity without continuity does not establish normality.
- Infinite numbers of modes do not admit the finite-mode uniqueness argument.
- Nondegeneracy matters for the conclusion being solely a density operator on one Schrödinger quantum factor.
- Primary theorem requires positivity for every finite collection, not a finite numerical test.
- Holevo theorem number verified through a primary paper's explicit citation; book theorem text remains unread here.

## Memory provenance

MEMORY.md lines 44-60 used only to preserve candidate/audit status and avoid treating this source check as broader proof validation. Current theorem assertions above come from live primary-source reads.
