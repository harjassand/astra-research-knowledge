# Exact multimode thermal entanglement-breaking benchmark

Status: complete internal derivation, with independent checks. This is a multimode extension of a known one-mode theorem; novelty of the extension is not claimed. The application to growing-dimensional iid experiments is handled by the parent and depends on the exact LAN interface there.

## Statement and conventions

Let H be the m-mode bosonic Fock space, m a positive integer, N >= 0, and

    theta_N = sum_{k>=0} N^k/(N+1)^(k+1) |k><k|,
    rho_alpha = D(alpha) theta_N^{tensor m} D(alpha)^dagger,
    alpha in C^m.

All channels below are normal CPTP maps on trace-class operators. They may use arbitrary joint measurements, entangled auxiliary states, unrestricted classical outcome spaces, and arbitrary prepared m-mode outputs. Define trace distance with the factor one half:

    e(m,N) = inf_{T entanglement-breaking} sup_alpha (1/2)||T(rho_alpha)-rho_alpha||_1.

Then

    e(m,N) = (1/2)||theta_N^{tensor m}-theta_{N+1}^{tensor m}||_1
           = TV(NB_m(N), NB_m(N+1)).

Here NB_m(N) is the law of the sum of m independent geometrically distributed photon counts of mean N. Its probabilities are

    P_{m,N}(k) = binom(m+k-1,k) (N+1)^(-m) (N/(N+1))^k.

For N>0, put

    x(m,N) = m log((N+2)/(N+1)) / log((N+1)^2/(N(N+2))),
    K = floor(x(m,N)).

The exact risk is

    e(m,N) = P_{NB_m(N)}[S<=K] - P_{NB_m(N+1)}[S<=K].

If x is an integer, the probabilities at x coincide, so either adjacent convention gives the same value. At N=0 the risk is 1-2^(-m).

The result in fact holds with the infimum over all completely copositive channels (PPT channels), because the lower bound uses only this weaker property and the optimal heterodyne channel is EB.

## Proof: attainability

Heterodyne each mode and prepare the corresponding coherent state. Heterodyne output on rho_alpha is a complex Gaussian outcome with mean alpha and per-mode variance N+1. Preparing coherent states and averaging yields D(alpha) theta_{N+1}^{tensor m} D(alpha)^dagger. Thus the claimed value is achievable uniformly in alpha by an EB channel.

## Proof: rigorous noncompact covariance reduction

It is not enough to assert that an invariant mean preserves normality. The following finite-volume construction avoids that issue.

Fix any completely copositive CPTP T whose supremum reconstruction risk is r. Let F_R=[-R,R]^(2m) in real displacement coordinates, and set

    T_R(X) = |F_R|^{-1} integral_{F_R} D(-a) T(D(a) X D(a)^dagger) D(-a)^dagger da.

Each T_R is CPTP and completely copositive; if T is EB then so is T_R. Convexity and the risk assumption imply

    (1/2)||T_R(rho_0)-rho_0||_1 <= r.

For every fixed displacement b, the covariance defect on X has trace norm at most

    ||X||_1 |(F_R+b) symmetric_difference F_R|/|F_R|,

which tends to zero as R tends to infinity.

Trace class T_1(H) is the dual of the separable space K(H) of compact operators. Its norm-bounded balls are weak-star compact and metrizable. Choose a countable trace-norm dense set of inputs and diagonalize a subsequence R_j so that T_{R_j}(X) converges in sigma(T_1,K) for every input in that set. The limit extends by the uniform contraction bound to a bounded linear map T_0:T_1(H)->T_1(H), and convergence holds for every X.

Positivity, complete positivity, and complete copositivity survive the limit: test every finite amplification on finite-rank positive operators. Output transpose maps K(H) to itself, so it is continuous for this weak-star convergence. For positive X, lower semicontinuity of trace gives

    Tr T_0(X) <= Tr X.

The covariance defect estimate gives exact displacement covariance of T_0. Consequently its normal adjoint satisfies

    D(b)^dagger T_0^*(I) D(b) = T_0^*(I).

Weyl irreducibility forces T_0^*(I)=cI for a scalar c in [0,1]. If c>0, T_0/c is a normal CPTP completely copositive displacement-covariant channel. If c=0, T_0=0. This explicitly permits mass escaping to infinite energy under the averaging sequence.

For every finite-rank projector Pi, the original risk bound survives as

    Tr Pi rho_0 - Tr Pi T_0(rho_0) <= r.

Thus a bound on the finite-rank cutoff probability for the normalized covariant channel also bounds the original r. The escaped mass multiplies this probability by c<=1 and can only strengthen the lower bound.

## Proof: covariant PPT channel equals amplifier output

Use Weyl convention D(z)=exp(sum_j z_j a_j^dagger - conjugate(z_j) a_j), with vacuum characteristic function exp(-||z||^2/2). Displacement covariance and Weyl irreducibility give

    T^*(D(z)) = f(z) D(z).

Complete copositivity (transpose composed with T is CP) gives the quantum Bochner positivity condition with symplectic form 2 Omega. Continuity follows from normality, since the thermal characteristic function never vanishes and

    f(z) = Tr[T(rho_0)D(z)] / Tr[rho_0 D(z)].

Hence for an arbitrary m-mode density operator tau,

    f(z) = Tr[tau D(sqrt(2) z)].

This is the multimode time-reversible channel characterization in Owari et al., Appendix A, Lemmas 2-4; their main-text equations (14)-(15) give the consistent sqrt(2) normalization. Guţă-Bowles-Adesso equation (7) uses precisely the same normalization. The printed/extracted Appendix A equation (A.5) in arXiv:0808.2260v1 has xi/sqrt(2), inconsistent with its own main-text equation (15) and its 2-Omega Bochner condition. We use the Bochner calculation and the main-text formula, not that reciprocal factor.

On the undisplaced thermal input,

    Tr[T(rho_0)D(z)] = Tr[tau D(sqrt(2)z)] exp(-(N+1/2)||z||^2).

This is exactly A_{2,N}^{tensor m}(tau), where A_{2,N} is the gain-2 phase-insensitive amplifier with an independent thermal environment of mean N. The seed tau may be entangled across all m modes.

## Proof: elementary collective photon-number domination

An explicit Gaussian-channel factorization is

    A_{2,N} = A_{N+2,0} composed_with L_{2/(N+2),0},

where A_{G,0} is the quantum-limited amplifier of gain G and L_{eta,0} is pure attenuation of transmissivity eta. Indeed the total signal gain is G eta=2 and the noise exponent is [G(1-eta)+G-1]/2=N+1/2.

Let sigma=L_{2/(N+2),0}^{tensor m}(tau). To compute a total-photon cutoff probability after A_{N+2,0}^{tensor m}, locally phase-twirl sigma. The cutoff is invariant and the amplifier is phase covariant, so this changes no relevant probability. The twirled sigma is an arbitrary correlated mixture of multimode Fock states |k_1,...,k_m><k_1,...,k_m|; neither independence nor separability is assumed.

For one such Fock input |k>, the quantum-limited gain-G amplifier has output photon count

    S_k = k + sum_{j=1}^{k+1} Z_j,

where the Z_j are independent geometric variables with mean G-1=N+1. Equivalently

    P[S_k=k+l] = binom(k+l,k) G^{-(k+1)} ((G-1)/G)^l.

For a multimode Fock vector whose total occupation is J=sum_j k_j, the total output count has law

    S = J + sum_{j=1}^{m+J} Z_j.

Couple this to the vacuum-seed total output

    S_vac = sum_{j=1}^{m} Z_j.

Then S>=S_vac almost surely. Convex mixing preserves this stochastic domination. Therefore every covariant PPT channel satisfies, for each integer L>=0,

    Tr[Pi_{<=L} T(rho_0)] <= P[NB_m(N+1)<=L],

where Pi_{<=L} is the finite-rank total-photon cutoff projector. The rank is binom(m+L,L), finite for fixed m,L, which is exactly what the noncompact reduction requires.

Independent alternative: Giovannetti-Holevo-Mari Theorem 1(i) proves that the vacuum output of every multimode gauge-covariant Gaussian channel majorizes every other output. Applying its Ky Fan consequences to A_{2,N}^{tensor m} yields the same cutoff inequality because theta_{N+1}^{tensor m} has eigenvalues decreasing with total photon number. The elementary argument above avoids relying on that stronger theorem.

## Proof: cutoff achieves full trace distance

For a multimode Fock vector of total photon number k, the input/output-vacuum likelihood ratio is

    theta_N^{tensor m}(k) / theta_{N+1}^{tensor m}(k)
      = ((N+2)/(N+1))^m [N(N+2)/(N+1)^2]^k.

It decreases strictly with k. Thus the positive part of theta_N^{tensor m}-theta_{N+1}^{tensor m} is exactly the total-photon cutoff Pi_{<=K} at the crossing given in the statement. Applying the covariance-limit witness inequality, followed by the domination inequality, gives

    r >= Tr Pi_{<=K}[rho_0 - T_0(rho_0)]
      >= Tr Pi_{<=K}[theta_N^{tensor m}-theta_{N+1}^{tensor m}]
       = (1/2)||theta_N^{tensor m}-theta_{N+1}^{tensor m}||_1.

Together with the heterodyne construction this proves the exact formula.

## High-temperature threshold

Define the one-mode Hellinger affinity

    a_N = (sqrt(N+2)+sqrt(N))/(2 sqrt(N+1)).

The standard TV-affinity inequalities give, without any asymptotic approximation,

    1-a_N^m <= e(m,N) <= sqrt(1-a_N^(2m)).

Since log(a_N)=-1/[8(N+1)^2]+O(N^-4), these prove:

* If N tends to infinity and m/N^2 tends to 0, then e(m,N) tends to 0.
* If N tends to infinity and m/N^2 tends to infinity, then e(m,N) tends to 1.
* If m/N^2 tends to c>0, then liminf e(m,N)>=1-exp(-c/8)>0.

The exact intermediate limit is stronger. The likelihood crossing satisfies

    K = m[N+1/2 - 1/(6(N+1)) + O(N^-3)] + O(1).

The centered geometric sum has variance mN(N+1), and a triangular-array CLT applies because the standardized third absolute moment of one geometric variable stays bounded as N tends to infinity and m tends to infinity. Under m/N^2->c in (0,infinity), the standardized cutoff tends to sqrt(c)/2 under NB_m(N) and to -sqrt(c)/2 under NB_m(N+1). Therefore

    e(m,N) -> 2 Phi(sqrt(c)/2)-1.

In the parameter q=N/(N+1), the threshold is m(1-q)^2. This includes arbitrary collective EB strategies and all independent displacement coordinates.

## Source ledger and prior-art scope

1. M. Guţă, P. Bowles, G. Adesso, Quantum teleportation benchmarks for independent and identically-distributed spin states and displaced thermal states, PRA 82, 042310 (2010), https://arxiv.org/abs/1004.1843 . Theorem IV.1; Lemmas IV.2, IV.4, IV.5; equations (7)-(8). Exact one-mode trace-norm minimax result, stochastic domination proof, and thermal purification/amplification mechanism.
2. M. Owari, M. B. Plenio, E. S. Polzik, A. Serafini, M. M. Wolf, Squeezing the limit: Quantum benchmarks for teleportation and storage of squeezed states, NJP 10, 113014 (2008), https://arxiv.org/abs/0808.2260 . Section 3 noncompact covariance discussion; equations (14)-(15); Appendix A Lemmas 2-4 explicitly stated for arbitrary finite mode number. Quantum Bochner and covariant PPT characterization.
3. V. Giovannetti, A. S. Holevo, A. Mari, Majorization and additivity for multimode Gaussian channels, https://arxiv.org/abs/1405.4066 . Theorem 1(i), equations (11), proof and arbitrary-state approximation. Independent general output-majorization route.

The exact multimode extension is a direct composition of these mechanisms plus the elementary correlated-Fock total-number argument above. No historical-calibre novelty is inferred from proving this reusable lemma.

## Failure and issue ledger

* Product heterodyne output distance alone would be only an upper bound; the lower proof above explicitly includes all collective EB channels.
* Naive tensorization of a one-mode trace risk is invalid because joint outputs may correlate. The total-number domination handles arbitrary correlated Fock seeds.
* An invariant-mean channel may be nonnormal. The subnormalized weak-star Følner limit above handles escaping trace mass and uses only finite-rank witnesses.
* Hilbert-Schmidt overlap/fidelity with the mixed target is too small to give the m/N^2 trace threshold by itself. The likelihood crossing cutoff yields the sharp threshold.
* Owari arXiv v1 Appendix A has an apparent reciprocal-sqrt(2) formula inconsistency; the main text, Bochner derivation and Guta equation (7) agree on sqrt(2).
* Scientific numerical checks below are diagnostics of formulas and constants, not substitutes for the proof.

## Strongest next use

For fixed m,N, the parent has a localization/splitting lemma showing that increasing bounded displacement balls recover this full-orbit minimax value. Combine with fixed-d quantum LAN on bounded parameter balls and a diagonal sequence of sample sizes. Near-tracial d-level spectra with two nearly degenerate clusters supply m approximately d^2/4 cross-cluster modes and N approximately 1/(2 delta), yielding the dimension-dependent obstruction m/N^2 approximately d^2 delta^2. The LAN and distinct-spectrum perturbation details belong to the parent; this note certifies only the Gaussian EB step.
