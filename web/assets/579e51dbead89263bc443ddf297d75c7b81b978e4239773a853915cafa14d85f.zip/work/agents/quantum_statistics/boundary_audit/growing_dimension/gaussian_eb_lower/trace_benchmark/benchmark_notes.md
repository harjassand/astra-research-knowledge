# Exact multimode thermal trace benchmark

Status: independently derived extension of an established one-mode result. The finite-mode theorem below is proved using the cited multimode majorization theorem and a separately audited covariance reduction. This is not a claim of priority or a growing-dimension qudit LAN theorem.

## Interface

For an integer m >= 1 and N >= 0, let

    rho_N = (N+1)^(-1) sum_{k>=0} (N/(N+1))^k |k><k|,
    rho_{N,alpha} = D(alpha) rho_N^{tensor m} D(alpha)^*.

Input: one m-mode state, arbitrary unknown alpha in C^m, known N and m. Output: all m modes. Risk is global trace distance, with the factor 1/2:

    e(m,N) = inf_{normal EB Phi} sup_{alpha in C^m}
              (1/2)||Phi(rho_{N,alpha}) - rho_{N,alpha}||_1.

Arbitrary joint measurement and entangled preparation across modes are allowed. There is no input-energy constraint or displacement restriction. In particular, a product-channel lower bound alone would not solve this interface.

## Result

    e(m,N) = (1/2)||rho_N^{tensor m} - rho_{N+1}^{tensor m}||_1
           = TV(NB(m, mean per summand N), NB(m, mean per summand N+1)).

The same optimum holds for the larger normal completely copositive (PPT/time-reversible) channel class. Product heterodyne measurement followed by coherent preparation attains it.

For N > 0, define

    K = floor( m log((N+2)/(N+1))
                   / log((N+1)^2/(N(N+2))) ).

If F_{m,N} is the CDF of the sum of m geometric variables with mean N, then

    e(m,N) = F_{m,N}(K) - F_{m,N+1}(K).

For N=0, e(m,0)=1-2^{-m}.

## Primary sources and exact locations

1. Guţă, Bowles, Adesso, *Quantum teleportation benchmarks for independent and identically-distributed spin states and displaced thermal states*, Phys. Rev. A 82, 042310 (2010), https://arxiv.org/abs/1004.1843 . Section IV, Theorem IV.1: exact one-mode minimax heterodyne/coherent scheme. Lemma IV.2: one-mode trace benchmark. Equations (7)-(8): displacement-covariant time-reversible multiplier and gain-2 thermal amplifier representation. Full text: https://arxiv.org/html/1004.1843v2 .
2. Giovannetti, Holevo, Mari, *Majorization and additivity for multimode bosonic Gaussian channels*, Theoret. Math. Phys. 182, 284-293 (2015), https://arxiv.org/abs/1405.4066 . Section 2, Theorem 1(i), equation (11): for every multimode Gaussian gauge-covariant channel, vacuum/coherent output majorizes output of every state. Their theorem has no finite-energy restriction. Gaussian-channel form in equation (5), physicality in equation (6).
3. Covariance/PPT characterization source identified by the independent checker: Owari et al., New J. Phys. 10, 113014 (2008), https://arxiv.org/abs/0808.2260 . The precise full audit is in covariance_rigor/; the argument below does not assume a normal invariant-mean limit.

## Proof: normal covariant completely copositive channels

Use D(z)=exp(sum_j(z_j a_j^* - conjugate(z_j)a_j)). A normal displacement-covariant channel has

    Phi^*(D(z)) = f(z)D(z).

Complete copositivity and the quantum Bochner condition give

    f(z) = Tr[tau D(sqrt(2)z)]

for an arbitrary normal m-mode state tau, up to a fixed coordinate conjugation which can be absorbed by transposing tau. Complete positivity imposes a further classical positivity condition on f, but it is unnecessary for the lower bound. In particular tau is allowed to be entangled or have infinite mean energy.

Let A_{2,N} be the m-fold gain-2 amplifier with thermal environment mean N. Its characteristic function is

    chi_{A_{2,N}(tau)}(z) = chi_tau(sqrt(2)z)
                           exp(-(N+1/2)||z||^2).

The thermal input has chi_{rho_N^{tensor m}}(z)=exp(-(N+1/2)||z||^2). Consequently

    Phi(rho_N^{tensor m}) = A_{2,N}(tau).

This amplifier is a Gaussian gauge-covariant channel with K=sqrt(2)I and noise matrix mu=(N+1/2)I. Its vacuum output is rho_{N+1}^{tensor m}.

Theorem 1(i) of Giovannetti--Holevo--Mari gives

    rho_{N+1}^{tensor m} majorizes A_{2,N}(tau).

No twirl of tau is needed. Let Pi_K be the projection onto total photon number <= K. Its rank is R_K=binomial(K+m,m). The R_K largest eigenvalues of rho_{N+1}^{tensor m} are exactly its eigenvalues on Pi_K, because they decrease with total photon number. Ky Fan's variational principle and majorization therefore imply

    Tr[Pi_K Phi(rho_N^{tensor m})]
       <= sum_{i<=R_K} lambda_i(Phi(rho_N^{tensor m}))
       <= Tr[Pi_K rho_{N+1}^{tensor m}].

Trace distance dominates this effect witness:

    (1/2)||Phi(rho_N^{tensor m})-rho_N^{tensor m}||_1
       >= F_{m,N}(K)-F_{m,N+1}(K).

## Proof: arbitrary normal EB/PPT channels, noncompact displacement group

Let r be the supremum trace-distance risk of an arbitrary normal EB (or PPT) channel Phi. Average its displacement conjugates over cubes C_R in R^{2m}, obtaining normal EB/PPT channels Phi_R. Convexity makes their supremum risk <= r. Cubes form a Følner sequence.

Extract a subsequence pointwise in sigma(T_1,K(H)), first on a countable traceclass-dense set of inputs and then extend by the uniform bound ||Phi_R||_{1->1}<=1. Since T_1(H)=K(H)^* and K(H) is separable, the bounded balls are weak-star sequentially compact. The result is a bounded map T_0:T_1->T_1, hence its adjoint is normal. Positivity, complete positivity and complete copositivity are preserved through finite matrix compact-operator tests. T_0 is trace-nonincreasing. The Følner norm error proves displacement covariance. Thus T_0^*(I) commutes with all Weyl operators and equals cI, 0<=c<=1, by irreducibility.

If c>0, T_0/c is a normal covariant CPTP PPT channel, so the preceding bound applies. If c=0, positivity gives T_0=0. Since Pi_K is finite rank, the original risk witness survives the limit:

    F_{m,N}(K)-r <= Tr[Pi_K T_0(rho_N^{tensor m})]
                    <= c F_{m,N+1}(K) <= F_{m,N+1}(K).

Therefore r>=F_{m,N}(K)-F_{m,N+1}(K). Escaped output trace cannot weaken the conclusion. This avoids assuming that an invariant-mean average is normal or trace preserving.

## Exact likelihood crossing and attainment

The eigenvalue per Fock basis vector of total occupation k is

    q_N(k) = (N+1)^(-m) [N/(N+1)]^k.

The multiplicity is binomial(k+m-1,m-1). The eigenvalue likelihood ratio is

    q_N(k)/q_{N+1}(k)
      = [(N+2)/(N+1)]^m [N(N+2)/(N+1)^2]^k.

It decreases strictly in k. It is >=1 exactly for k<=K as defined above (an equality at a boundary makes no difference to the risk). Thus Pi_K is the positive spectral projection of rho_N^{tensor m}-rho_{N+1}^{tensor m}; its witness equals the full trace distance.

Product heterodyne/coherent preparation has Weyl multiplier exp(-||z||^2), so it maps every displaced rho_N^{tensor m} to the equally displaced rho_{N+1}^{tensor m}. Its supremum risk equals the lower bound. This proves exact optimality even against entangled EB channels.

## High-temperature dimension threshold

Let N->infinity and m=m(N) be an integer sequence. Write

    h_N = log(1+1/(N+1)) / [-log(1-1/(N+1)^2)]
        = N+1/2 - 1/[6(N+1)] + O(N^(-2)),
    K = floor(m h_N).

The two total photon distributions have means mN and m(N+1), and variances mN(N+1) and m(N+1)(N+2). If m/N^2 -> c in (0,infinity), then m->infinity and

    (K-mN)/sqrt(mN(N+1)) -> sqrt(c)/2,
    (K-m(N+1))/sqrt(m(N+1)(N+2)) -> -sqrt(c)/2.

A triangular-array CLT applies. For example, the geometric third absolute central moment divided by variance^(3/2) is uniformly bounded for N>=1: E|X-N|^3<=16N^3+9N^2+N<=26N^3, while variance>=N^2. Berry--Esseen therefore has error O(m^(-1/2)). Hence

    e(m,N) -> 2 NormalCDF(sqrt(c)/2)-1.

This is positive for every c>0. In the high-temperature regimes m/N^2->0 and m/N^2->infinity, e tends respectively to 0 and 1.

An exact, simple bound covering those endpoint regimes follows from the per-mode classical affinity

    a_N = sum_{k>=0} sqrt(q_N(k)q_{N+1}(k))
        = (sqrt(N+2)+sqrt(N))/(2sqrt(N+1)),
    a_N^2 = [1+sqrt(1-(N+1)^(-2))]/2.

The elementary classical inequalities give

    1-a_N^m <= e(m,N) <= sqrt(1-a_N^(2m)).

Since log a_N=-1/[8(N+1)^2]+O(N^(-4)), the lower bound tends to 1-exp(-c/8), directly proving nonvanishing at positive m/N^2 without using CLT. The exact CLT profile is stronger.

## Failure ledger and scope

* A tensor product of one-mode minimax lower bounds would not exclude entangled EB schemes; the arbitrary multimode majorization input and covariant PPT representation are the load-bearing replacements.
* A unital invariant-mean average may fail to be normal; the compact-test subnormalized limit resolves this issue for the finite photon witness.
* The theorem assumes every alpha in C^m. It does not directly imply the same value on a shrinking or bounded displacement set; a localization/splitting argument must quantify its extra error.
* The equal-temperature theorem does not by itself identify the exact benchmark for unequal mode temperatures. Majorization still supplies eigenvalue-sum witnesses, but the target positive spectral projection need not be a top-eigenvalue projection of the heterodyne output.
* The Gaussian result does not provide a dimension-uniform finite-n qudit Gaussian approximation. That transfer must retain its dimension-dependent error separately.
* The sources already prove the one-mode benchmark and multimode majorization. No novelty claim is made for their combination; a further literature check is needed before any priority claim.

## Strongest next attack

Insert the exact risk into the growing-qudit collision analysis only after supplying a dimension-uniform Gaussian bridge and a finite-radius localization theorem. In an equal-temperature block with m/N^2 bounded below, any EB classicalization incurs a nonvanishing error even when each individual mode has vanishing commutator/thermal classicalization error.
