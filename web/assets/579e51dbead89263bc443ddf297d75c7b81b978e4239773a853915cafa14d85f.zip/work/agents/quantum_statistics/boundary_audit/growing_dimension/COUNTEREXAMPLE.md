# Growing dimension: near-tracial iid orbits can resist every classical reconstruction

Status: complete internal derivation of an obstruction, assembled from published fixed-d strong LAN, Weyl/PPT characterization, and an explicit multimode photon-number argument. Published multimode Gaussian majorization supplies an independent lower-bound route. External adversarial review and historical priority remain open. This is not a dimension-uniform LAN theorem, a quantum-memory dimension theorem, a practical algorithm, or a historical priority claim.

## Contract and strongest statement

Use normalized trace distance T(a,b)=||a-b||_1/2. For a known spectrum p on C^d define

  E_n(p)=inf_{Phi EB} sup_{U in SU(d)} T(Phi((U diag(p) U*)^tensor n),(U diag(p) U*)^tensor n).

The infimum permits arbitrary measure-and-prepare channels, unlimited classical outcome sets, arbitrary collective POVMs, and arbitrary prepared n-qudit states. No external reference is required. The spectrum and sample size may be supplied to the channel.

**Written theorem, with proof below.** There are faithful strictly distinct spectra p_n on dimensions d_n tending to infinity such that

  ||d_n diag(p_n)-I||_op -> 0,
  E_n(p_n) -> 1.

Thus the fixed-d iff criterion 'asymptotically classical iff the spectrum tends to the tracial spectrum' has no dimension-free extension based solely on relative operator-norm traciality. The counterexample can have d_n grow slower than any prescribed diverging function of n, at the price of implicit and potentially enormous sample-size thresholds.

## Published inputs and exact locations

1. Kahn and Guta, *Local asymptotic normality for finite dimensional quantum systems*, https://arxiv.org/html/0804.3876 . Equations (4.1), (4.3), (4.4) define the faithful strictly distinct reference spectrum and exact unitary family. Equations (4.18)-(4.20) give independent thermal modes with q_ij=p_j/p_i and displacement coordinates. Theorem 4.3, equations (4.23)-(4.24), gives bidirectional strong channels on fixed-d growing local parameter boxes. We restrict all eigenvalue coordinates to zero and all within-cluster rotation coordinates to zero. Other Gaussian modes and the classical Gaussian component then are known parameter-independent ancillas.

2. Guta, Bowles, Adesso, *Quantum teleportation benchmarks for independent and identically-distributed spin states and displaced thermal states*, https://arxiv.org/html/1004.1843 . Theorem IV.1 proves the one-mode trace-norm minimax heterodyne/coherent benchmark. Its proof, equation (7), reduces covariant EB channels to a larger time-reversible class; equation (8) is the gain-2 amplifier representation. Theorem V.2's converse uses thermal splitting, heterodyne localization, and final amplification to pass from bounded local balls to all displacements. We give an explicit multimode version of that localization below.

3. Giovannetti, Holevo, Mari, *Majorization and additivity for multimode bosonic Gaussian channels*, https://arxiv.org/html/1405.4066 . Theorem 1(i) says the output on vacuum/coherent input majorizes output on every state for any Gaussian gauge-covariant channel, including an entangled input across arbitrarily many modes. It does not require finite second moments. Applying this to the thermal-environment gain-2 amplifier closes the collective-EB loophole in a direct product of one-mode benchmarks. See gaussian_eb_lower/EXACT_MULTIMODE_EB_BENCHMARK.md for the completed noncompact covariance step and arbitrary-EB proof. That note also gives an elementary amplifier-factorization/Fock-mixture proof, so this majorization theorem is an independent check rather than a necessary dependency.

4. Owari, Plenio, Polzik, Serafini, Wolf, *Squeezing the limit: Quantum benchmarks for the teleportation and storage of squeezed states*, https://arxiv.org/html/0808.2260 . Appendix A Lemmas 2-3 establish the arbitrary finite-mode Weyl multiplier and modified-symplectic-form CP criterion. Lemma 4 uses doubled symplectic form under transposition. Its printed equation (38) contains a reciprocal-sqrt(2) inconsistency; direct rescaling of the doubled form and main-text equation (15) give the required multiplier chi_tau(sqrt(2)z), also agreeing with Guta-Bowles-Adesso equation (7). Only the necessary representation is used; CP imposes a further ordinary-characteristic condition, so we do not claim every seed tau defines a legal EB channel.

Exact downloaded HTML copies live in this directory. These source inputs are established prior art; the high-dimensional iid consequence is an inference from them.

## Gaussian benchmark needed by the construction

Let tau_N=(N+1)^-1 sum_{k>=0}(N/(N+1))^k |k><k|, N>0, and

  G_alpha = D(alpha) tau_N^tensor m D(alpha)*, alpha in C^m.

The multimode benchmark is

  B(m,N)=inf_{Phi EB} sup_alpha T(Phi(G_alpha),G_alpha)
         =T(tau_N^tensor m,tau_{N+1}^tensor m).

Product heterodyne followed by preparation of the coherent state at the outcome attains the right side. The lower bound permits arbitrary collective EB channels, not merely product measurements or product preparations.

Proof mechanism: displacement covariance plus complete copositivity puts the centered output into the class A_{2,N}^tensor m(tau), with tau an arbitrary m-mode state, and A_{2,N} the amplifier b -> sqrt(2)b+a*, environment a in tau_N. Its vacuum output is tau_{N+1}^tensor m. Theorem 1(i) gives vacuum-output majorization. If P_K projects onto total photon number <=K, it has finite rank and is a projector onto the largest eigenvalues of tau_{N+1}^tensor m. Ky Fan then gives

  Tr[P_K A_{2,N}^tensor m(tau)] <= Tr[P_K tau_{N+1}^tensor m].

Choose K where the geometric product likelihood ratio crosses one. The target and heterodyne output both depend only on total photon count, so this single threshold realizes their total variation distance. The noncompact displacement averaging is handled in the companion proof by a weak-star limit of finite-volume twirls. The limit is a normal covariant trace-decreasing CP/coCP map, with adjoint on I equal to cI; its finite-rank cutoff probabilities retain the bound, and escaped mass c<=1 only helps the lower bound. No probability Haar measure or normal invariant mean is assumed.

An elementary alternative removes the majorization dependency entirely. Factor A_{2,N}=A_{N+2,0} composed with pure loss L_{2/(N+2),0}. Locally phase-twirl the arbitrary correlated seed after loss; this preserves the total-photon cutoff. The quantum-limited amplifier maps a Fock vector of total occupation J to the photon-count law J+sum of (m+J) independent geometric variables of mean N+1. Coupling its first m terms to the vacuum output shows stochastic domination of NB(m,N+1), even for arbitrary correlated mixtures of Fock vectors. Thus collective entangled strategies obey the exact same cutoff bound.

The total photon count under tau_N^tensor m is a negative binomial variable with mean mN and variance mN(N+1). Under tau_{N+1}^tensor m its mean is m(N+1) and variance m(N+1)(N+2). Testing at floor(m(N+1/2)) and using Chebyshev gives the exact sufficient lower bound

  B(m,N) >= max{0, 1 - 8(N+1)^2/m}.                     (G1)

No central limit theorem is needed to obtain B->1 when m/N^2->infinity. The sharper finite-critical normal limit is B->2 Phi(sqrt(c)/2)-1 if N->infinity and m/N^2->c>0; it is not needed below.

## Bounded local domains suffice

Define B_R(m,N) as the EB minimax risk on ||alpha||_infinity<=R. Then

  sup_{R<infinity} B_R(m,N)=B(m,N).                    (G2)

Here m,N are fixed while R grows. To prove this, take any channel good on the radius-R box and construct an all-displacement EB channel. Mix each input mode tau_{N,alpha} with a supplied centered tau_N through a passive splitter of intensity reflectivity eta. The outputs are independent displaced thermal states with centers sqrt(eta)alpha and sqrt(1-eta)alpha. Heterodyne the first part and put alpha_hat=alpha+Z/sqrt(eta), where the m complex components of Z are independent centered Gaussians of variance N+1. Displacing the remaining input by -sqrt(1-eta)alpha_hat leaves residual center

  gamma=-sqrt((1-eta)/eta) Z,

whose law is independent of alpha. The probability that gamma falls outside the radius-R box tends to zero as R grows. Apply the bounded-domain EB map, undo the displacement, then quantum-limit amplify with intensity gain 1/(1-eta). The ideal thermal mean becomes

  N_eta=N+(N+1)eta/(1-eta)

and its center is alpha. Contractivity and the bad-event bound imply

  B(m,N) <= B_R(m,N)+Pr(||gamma||_infinity>R)
                          +T(tau_N^tensor m,tau_{N_eta}^tensor m).

First choose eta small and then finite R large. This proves (G2). It also supplies a concrete finite local radius for each prescribed slack. The auxiliary thermal state and final amplifier may be costly; they are legal channels in this mathematical lower-bound reduction, not free physical acquisition.

## Explicit spectrum with d^2/4 weak quantum modes

For even d>=16 put

  t=d^(-1/2),  epsilon=t/d^3,  m=d^2/4,
  s_i=(d+1-2i)/d,  i=1,...,d,
  p_i=(1+t+epsilon s_i)/d                  if i<=d/2,
  p_i=(1-t+epsilon s_i)/d                  if i>d/2.

The s_i sum to zero and strictly decrease. Hence p is a faithful, strictly decreasing probability vector. Its relative tracial deviation is exactly

  ||d diag(p)-I||_op=t+epsilon(1-1/d),

which tends to zero. The small perturbation is not needed physically; it lets us invoke the published distinct-spectrum strong LAN theorem without assuming its extension to degenerate spectra.

For each cross-cluster pair i<=d/2<j, the corresponding thermal mode has mean

  N_ij=p_j/(p_i-p_j),

and there are exactly m such modes. Compare them to

  N_0=(1-t)/(2t).

Since s_i>0>s_j,

  0<=N_0-N_ij
    =epsilon[(1-t)s_i-(1+t)s_j]
      /[2t(2t+epsilon(s_i-s_j))]
    <=epsilon/(2t^2).                                    (S1)

For geometric thermal states,

  T(tau_N,tau_M)<=|N-M|/(min(N,M)+1).                     (S2)

One proof differentiates p_q(k)=(1-q)q^k, bounds sum_k|partial_q p_q(k)|<=2/(1-q), integrates, and substitutes q=N/(N+1). Our epsilon gives N_ij>=N_0/2. Thus each mode differs by at most 2epsilon/t, and tensor telescoping gives

  zeta_d := T(tensor_cross tau_{N_ij},tau_{N_0}^tensor m)
          <=2m epsilon/t=1/(2d).                         (S3)

This bound holds uniformly under any common displacement vector, since displacement is unitary. All other LAN modes are fixed at zero displacement. They and the centered classical Gaussian may be discarded and regenerated with zero deficiency.

## Strong-channel transfer and the diagonal choice of n

Fix d and its spectrum above. By (G2) choose a finite R_d such that the identical-temperature model on that box has EB risk at least B(m,N_0)-1/d. Replacing the identical thermal states by the actual cross modes changes reconstruction minimax risk by at most 2zeta_d. This follows from the triangle inequality and trace-distance contractivity for any EB channel.

The published unitary coordinates in equations (4.3)-(4.4) give exact states on the full unitary orbit of diag(p). Set eigenvalue coordinates to zero, set within-cluster rotation coordinates to zero, and vary cross coordinates to realize the displacement box. The correspondence between coordinates and displacements is an invertible fixed linear scaling for this fixed spectrum. A finite box therefore lies inside the LAN parameter domain for every sufficiently large n.

Let F_{d,n} denote the forward LAN channel followed by discarding the known components. Let S_{d,n} append those known components and apply inverse LAN. Choose n_d so that for every n>=n_d both approximation errors are at most 1/(2d), uniformly on the chosen box. This is a fixed-d consequence of Theorem 4.3; no uniformity in d or spectral gaps is asserted.

If Phi is any EB reconstruction on the iid orbit, then

  F_{d,n} o Phi o S_{d,n}

is an EB reconstruction on the cross-mode Gaussian experiment. Two applications of contractivity show its reconstruction error is at most the original orbit error plus 1/d. Consequently, for every n>=n_d,

  E_n(p^(d)) >= B(m,N_0) -1/d -2zeta_d -1/d
             >= B(m,N_0)-3/d
             >= 1 -8(d+2sqrt(d)+1)/d^2 -3/d.             (C1)

The last expression tends to one. Make n_d strictly increasing, choose a sequence of even d tending to infinity, and define d_n to be the greatest stage reached by sample size n. Use p_n=p^(d_n). Then n>=n_{d_n}, and (C1) proves E_n(p_n)->1 while relative traciality tends to zero.

For any externally prescribed g(n)->infinity, enlarge each n_d further so that g(n)>=d for all n>=n_d. This ensures d_n<=g(n) eventually. The statement is existential and gives no feasible numerical sample count. The source LAN error constants can explode with the extremely small within-cluster gaps.

## Operational inference consequence

Let a classical experiment C_n be bidirectionally approximable from the quantum iid orbit, with forward and reverse normalized trace/total-variation errors a_n,b_n. Composing the quantum-to-classical channel with the classical-to-quantum decoder is EB and gives E_n(p_n)<=a_n+b_n. For this construction a_n+b_n cannot tend to zero; in fact its liminf is at least one. If the Le Cam distance uses the maximum of the two errors, its liminf from every classical experiment is at least 1/2.

This rules out a fully classical archive of any alphabet size that reconstructs the whole unknown-basis density family with vanishing error. It does not determine a lower bound growing with d on retained quantum dimension, and does not imply a separated lower bound for every particular fixed measurement or scalar parameter estimation loss. The witness is a collective, parameter-indexed photon-number test transferred through LAN, fitting the entire experiment/density reconstruction contract.

## Failure ledger and remaining bottleneck

- A single SU(2) pair floor of order t cannot prove this, because t->0.
- Taking tensor products of many weakly polarized qubits while preserving the global relative operator-norm tracial bound forces total polarization budget to be small; this does not accumulate the needed thermal defect.
- Direct sums of independently rotated qubit blocks give only d/2 modes. They can still furnish a counterexample with sqrt(d)t bounded below, but the full cross-cluster unitary family improves the accumulating count to d^2/4.
- Degenerate two-level clusters cannot be inserted into the published distinct-spectrum LAN theorem without further proof. We avoid that unproved step with explicit tiny distinct perturbations and thermal-state continuity.
- Tensoring one-mode optimal channels does not establish an arbitrary collective-EB lower bound. The elementary correlated-Fock domination (or independently the published multimode majorization theorem) is the needed additional ingredient; the companion proof repairs noncompact displacement averaging rather than relying on a false Haar probability.
- We do not know the sharp finite-(n,d) threshold, a useful dimension-uniform Gaussian bridge, a matching sufficient criterion involving d and t, or the required quantum memory size. The normal/subnormal covariance reduction and the PPT/Weyl factor-of-sqrt(2) check have now been written explicitly in the companion note; no internal missing lemma remains in this obstruction. External proof review, useful finite-(n,d) rates, and a matching dimension-dependent upper theorem remain outstanding.

## Local diagnostic, not theorem evidence

A basic double-precision script checked spectrum normalization, relative tracial deviation, cross means, and the conservative continuity/Chebyshev bounds for d=16,64,256,1024. For d=256 the Gaussian Chebyshev bound is 0.96472; for d=1024 it is 0.99169. These arithmetic checks neither verify LAN convergence at a numerical sample size nor certify the arbitrary-EB proof.

Memory navigation: MEMORY.md lines 44-97 only supplied candidate status and earlier fixed-d obstruction pointers. All theorem inputs above were re-opened as primary sources. Related memory rollout id 01a1121a-4750-72f0-8f5c-b501038890d3.
