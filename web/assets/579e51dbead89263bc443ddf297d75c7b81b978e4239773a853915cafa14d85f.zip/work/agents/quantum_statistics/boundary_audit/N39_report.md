# Noncommuting references and unresolved spectral blocks

7 October 2026. Independently written deductions, with explicit proofs below. They have not received external mathematical review or novelty clearance. The finite diagnostics are convention checks, not proof certificates. No source repository was changed.

## Results and opportunities

Three useful boundaries emerged.

1. **A constructive nontracial extension of bounded-score classicalization.** Exact reference commutation can be replaced by small Wigner–Yanase commutators, together with small reference-weighted score commutators. The decoder is a conditional known reference on a finite joint spectral grid. The alphabet bound is independent of Hilbert-space dimension. This result is only sufficient; an explicit modular-gap freezing example disproves its necessity.
2. **A direct partial-collision obstruction in the original iid model.** For any pair of eigenvalues, allowing its unknown SU(2) eigenspace produces a finite entanglement-breaking reconstruction floor. The proof handles random active counts and arbitrary decoder changes of spin sector. It requires neither the tracial Gaussian bridge nor the missing ground-component/Fock factorization. Together with the inherited, re-opened coherent channel, it gives an iff criterion for the full unknown-eigenbasis orbit of an arbitrary fixed-dimensional moving spectrum: vanishing entirely classical density reconstruction is possible exactly when the spectrum tends to the maximally mixed spectrum.
3. **A tangent commutator is not a universal criterion.** A one-parameter Gaussian displacement can have zero restricted symplectic form while remaining noncommuting and nonclassical as a whole statistical experiment. Modular evolution generates the missing conjugate observable. This is the decisive conceptual obstacle to interpreting weak QLAN covariance calculations as strong classical equivalence.

The missing unrestricted partial-collision factorization remains open. The new results clarify what a successful hybrid theorem must retain, and give a separate constructive extension that does not rely on that factorization.

## 1. Exact interface

Throughout, distance is $T(\rho,\sigma)=\frac12\|\rho-\sigma\|_1$. A classical archive is a POVM followed by a quantum preparation, hence an entanglement-breaking (EB) channel. Arbitrary outcome alphabets, parameter-independent common randomness, and decoder ancillas are allowed in the lower bounds. Such randomness does not evade an EB bound.

Density reconstruction is averaged over the encoder record and decoder randomness. It does not preserve a purification or a later task selected using the original retained record. Every retained input-dependent label counts. Supplied reference states, score operators, spectra, and block projectors are model descriptions, not an extra observation of the unknown parameter. Their acquisition and circuit synthesis can be costly and are discussed separately.

## 2. Constructive bounded-score theorem without exact reference commutation

Let $k\ge1$, (R>0) be fixed. Let $\omega>0$ be any known finite-dimensional density matrix, with no condition-number bound. Let $A_1,\ldots,A_k$ be known Hermitian contractions. Define

\[
 \rho_b=\frac{\exp(\log\omega+\sum_i b_i A_i)}
 {\operatorname{Tr}\exp(\log\omega+\sum_i b_i A_i)},
 \qquad\|b\|_1\le R.
\]

Set

\[
 \nu=\max_i\|[\sqrt\omega,A_i]\|_{\rm HS},\qquad
 \eta=\max_{i,j}\|[A_i,A_j]\|_{2,\omega},\qquad
 \|X\|_{2,\omega}^2=\operatorname{Tr}\omega X^*X.
\]

For (k=1), set $\eta=0$. Write (a_k=1/(2^k-1)) and $z=\eta+\nu^{1/3}$.

**Written theorem.** There are constants (c_k,C_{k,R},C_k>0), independent of the Hilbert-space dimension and of the least eigenvalue of $\omega$, such that for $0<z\le c_k$ a finite classical archive satisfies

\[
 \sup_{\|b\|_1\le R}T(\mathcal R\mathcal E(\rho_b),\rho_b)
 \le C_{k,R}z^{a_k},
 \qquad M\le C_k z^{-k a_k}.
 \tag{2.1}
\]

The physical encoder measures a finite joint spectral partition; it stores one of (M) labels and zero qubits. The decoder prepares a supplied, parameter-independent conditional reference state for that label. For (z=0), any requested positive error $\epsilon$ is attainable with $M\le C_{k,R}\epsilon^{-k}$. The result does not assert a necessary criterion, efficient circuit preparation, or optimal error/memory exponents.

The proof consists of three elementary lemmas. It does not use the absent linked N03 proof or its pointer-recovery estimate.

### 2.1 Log-spectrum bins flatten the reference and centralize the scores

For $0<h\le1$, choose an offset $u\in[0,h$) and divide the real line into the intervals (u+mh+[0,h)). Let (P_m) be the spectral projection of $\log\omega$ onto interval (m). Replace its eigenvalues by the corresponding interval midpoint to obtain (K'). Put

\[
 \omega'=e^{K'}/\operatorname{Tr}e^{K'},\qquad
 A_i^0=\sum_m P_m A_iP_m.
\]

Then $\omega'$ is scalar on each (P_m), all (A_i^0) commute with $\omega'$, and

\[
 \|\log\omega'-\log\omega\|_{\rm op}\le h,
 \quad e^{-h}\omega\preceq\omega'\preceq e^h\omega,
 \quad\|A_i^0\|_{\rm op}\le1.
 \tag{2.2}
\]

For two reference eigenvalues (p_i,p_j), the probability over the offset that they are separated is exactly

\[
 \min\{1,|\log p_i-\log p_j|/h\}.
\]

Write $t=|\log p_i-\log p_j|$ and

\[
 c(t)=\frac{(\sqrt{p_i}-\sqrt{p_j})^2}{p_i+p_j}
       =1-\operatorname{sech}(t/2).
\]

The scalar bound

\[
 \min(1,t/h)\le\frac4h\sqrt{c(t)}\qquad(0<h\le1)
 \tag{2.3}
\]

follows from $c(t)\ge t^2/16$ for $0\le t\le1$ and $c(t)\ge c(1)>1/16$ for $t\ge1$. For the first inequality, with $v=t/2\le1/2$, use
\$1-\operatorname{sech}v=(\cosh v-1)/\cosh v\ge v^2/(2\cosh(1/2))\ge v^2/4\$.

Hermiticity symmetrizes the weighted matrix-element sum. Cauchy–Schwarz gives

\[
\begin{split}
 \mathbb E_u\|A_i-A_i^0\|_{2,\omega}^2
 &\le\frac2h\sum_{r,s}(p_r+p_s)|(A_i)_{rs}|^2\sqrt{c(t_{rs})}\\
 &\le\frac2h\sqrt{2\operatorname{Tr}\omega A_i^2}
                   \|[\sqrt\omega,A_i]\|_{\rm HS}
 \le\frac{4\nu}{h}.
\end{split}
\tag{2.4}
\]

Choose one offset whose sum over all (k) squared errors does not exceed its expectation. Thus, simultaneously,

\[
 d_0:=\max_i\|A_i-A_i^0\|_{2,\omega'}
 \le2e^{h/2}\sqrt{k\nu/h}.
 \tag{2.5}
\]

Only the supplied model is used in choosing the offset. In finite dimension the partition changes at finitely many eigenvalue residues; one can enumerate intervals to select an offset satisfying (2.4). No unknown (b) is used.

The score commutators after pinching remain controlled despite the nontracial reference. Put (E_i=A_i-A_i^0). Since (A_i^0) commute with $\omega'$, right multiplication by them is a contraction in the weighted norm. Since $\|E_i\|_{\rm op}\le2$, left multiplication by (E_i) has norm at most two. Expanding the commutator yields

\[
 \eta_0:=\max_{i,j}\|[A_i^0,A_j^0]\|_{2,\omega'}
 \le e^{h/2}\eta+8d_0.
 \tag{2.6}
\]

For example, the three error terms are

\[
 [A_i,A_j]-[A_i^0,A_j^0]
 =[E_i,A_j^0]+[A_i^0,E_j]+[E_i,E_j],
\]

whose norms sum to at most $4\|E_i\|_{2,\omega'}+4\|E_j\|_{2,\omega'}$. This avoids the invalid assumption that arbitrary right multiplication preserves a nontracial weighted norm.

Taking $h=\nu^{1/3}$, for $0<\nu\le1$, gives reference and score errors $O_k(\nu^{1/3})$. If $\nu=0$, skip this step: take $\omega'=\omega$, (A_i^0=A_i).

### 2.2 Finite commuting score grids with a common bin width

**Lemma.** Suppose a density $\Omega$ commutes with all (k) Hermitian contractions (X_i). If

\[
 \max_{i,j}\|[X_i,X_j]\|_{2,\Omega}\le\delta,
\]

then for $0<\delta\le1$ there are commuting Hermitian contractions (B_i), commuting with $\Omega$, each taking at most $\lceil2/q\rceil+2$ distinct values, such that

\[
 \max_i\|X_i-B_i\|_{2,\Omega}\le C_k\delta^{1/(2^k-1)},
 \qquad q=\delta^{1/(2^k-1)}.
 \tag{2.7}
\]

The lemma also allows an upper bound $\delta\le C q^{2^k-1}$, with constants adjusted by (C,k).

Proof of the spectral step: diagonalize a current (X), jointly with $\Omega$ and the preceding block partition. Randomly offset bins of width (q). Round (X) to their centers, clipping the two endpoint centers into ([-1,1]). Pinch every remaining (Y) to the same nested partition. The rounded (X) changes by at most (q) in operator norm. In a joint eigenbasis,

\[
\begin{split}
 \mathbb E\|Y-\mathcal P(Y)\|_{2,\Omega}^2
 &\le q^{-1}\sum_{r,s}p_s|x_r-x_s||Y_{rs}|^2\\
 &\le q^{-1}\|[X,Y]\|_{2,\Omega}\|Y\|_{2,\Omega}
 \le q^{-1}\|[X,Y]\|_{2,\Omega}.
\end{split}
\tag{2.8}
\]

This estimate is tracial on the score algebra because all current scores commute with $\Omega$; it is not assumed for general noncommuting references. Choose a shared offset for which the sum over remaining (Y)'s is at most its expectation. All pinches and spectral rounding preserve Hermiticity, contraction bounds, and commutation with $\Omega$ and the preceding rounded scores.

Let (d_j) bound the errors of all remaining current scores after (j) pinches. Comparing their commutators with the original scores gives a bound $\delta+4d_j$. Therefore

\[
 d_0=0,\qquad
 d_{j+1}\le d_j+\sqrt{k(\delta+4d_j)/q},\quad 0\le j<k-1.
 \tag{2.9}
\]

With $\delta=q^{2^k-1}$, induction gives

\[
 d_j\le C_{k,j}q^{,2^{k-j}-1}.
 \tag{2.10}
\]

Indeed (a_{j+1}=(a_j-1)/2) for (a_j=2^{k-j}-1), and (d_j) and $\delta$ are no larger than constant multiples of (q^{a_j}). At the last pinch, (d_{k-1}=O_k(q)). Round the last remaining score as well; previous rounding errors add at most (q). This proves (2.7).

All scores use global grids of width (q), even when the intermediate partition has many known reference blocks. Their joint value alphabet is at most $(\lceil2/q\rceil+2)^k$. Neither the reference-bin index nor its possibly large alphabet needs to be retained.

**Prior-art boundary.** The two-matrix (1/3) exponent is expressly established by Bansil–Kachkovskiy, 31 August 2026, Theorem 1.1, and cannot be counted as new. Their Corollary 1.4 states a multi-matrix exponent (1/3^{k-1}). The common-width recursion above gives the candidate exponent (1/(2^k-1)), for example (1/7) at (k=3). This comparison is an actual potential improvement, but the elementary derivation and historical priority require independent scrutiny. No claim of an optimal exponent is made.

### 2.3 Gibbs comparison from one-sided relative entropy

This step permits a known commuting approximation without incorrectly asserting operator monotonicity of the exponential.

Let

\[
 H=\log\omega+\sum_i b_iA_i,
 \quad H'=\log\omega'+\sum_i b_iB_i,
 \quad \sigma_b=e^{H'}/\operatorname{Tr}e^{H'},
 \quad E=H-H'.
\]

The (B_i) commute with $\omega'$, so $\sigma_b\preceq e^{2R}\omega'$. Also $\|E\|_{\rm op}\le h+2R=:L$. Golden–Thompson gives

\[
 D(\sigma_b\|\rho_b)
 =\log\operatorname{Tr}e^{\log\sigma_b+E}-\operatorname{Tr}\sigma_bE
 \le\log\operatorname{Tr}\sigma_be^E-\operatorname{Tr}\sigma_bE.
\]

Center $E_c=E-(\operatorname{Tr}\sigma_bE)I$, whose norm is at most (2L). The scalar remainder bound

\[
 e^{E_c}\preceq I+E_c+\tfrac12e^{2L}E_c^2
\]

implies

\[
 D(\sigma_b\|\rho_b)
 \le\tfrac12e^{2L}\operatorname{Tr}\sigma_bE^2.
\]

Pinsker's inequality, with natural logarithms, consequently yields

\[
 T(\sigma_b,\rho_b)
 \le\tfrac12e^{h+3R}
 \left[h+R\max_i\|A_i-B_i\|_{2,\omega'}\right].
 \tag{2.11}
\]

Equations (2.5)--(2.7), with $q\asymp_k z^{a_k}$, make the right side (O_{k,R}(z^{a_k})).

Let (P_z) now denote the joint spectral projections of the finite-grid (B_i); its reuse of the letter (z) as an outcome is local to this paragraph. Measure these projections and prepare

\[
 \mathcal R(z)=\frac{P_z\omega'P_z}{\operatorname{Tr}\omega'P_z}.
 \tag{2.12}
\]

Zero-weight labels are omitted. This channel fixes every $\sigma_b$ exactly, since the unknown exponential factor is constant on each joint projection. Contractivity and the triangle inequality give

\[
 T(\mathcal R\mathcal E(\rho_b),\rho_b)
 \le2T(\rho_b,\sigma_b).
\]

Thus (2.1) follows, with the stated finite alphabet and no input-dependent reference-bin register.

### 2.4 Why the new sufficient condition is not necessary

Let $\omega_\epsilon=\operatorname{diag}(1-\epsilon,\epsilon)$, $A=\sigma_x$, and $|b|\le R$. With

\[
 a=\tfrac12\log((1-\epsilon)/\epsilon),\qquad
 s=\sqrt{a^2+b^2},
\]

the Gibbs state has Bloch vector

\[
 (b\tanh s/s,\ 0,\ a\tanh s/s).
\]

Uniformly in bounded (b), the first component is (O_R(1/a)), and the third differs from (	anh a) by (O_R(1/a^2)). Hence a zero-bit decoder preparing $\omega_\epsilon$ has vanishing error as $\epsilon\to0$. Yet

\[
 \|[\sqrt{\omega_\epsilon},\sigma_x]\|_{\rm HS}^2
 =2(\sqrt{1-\epsilon}-\sqrt\epsilon)^2\longrightarrow2.
\]

A diverging modular energy gap suppresses bounded perturbations. It is a second route to classicality, distinct from almost commuting bounded scores or semiclassical unbounded collective generators. An unrestricted iff criterion must account for the modular response, not merely raw Wigner–Yanase commutators.

## 3. Explicit finite failure when N03 reference commutation is dropped

Take a fixed qubit reference $\omega=(I+r\sigma_z)/2$, (0<r<1), and one bounded score $A=\sigma_x$. Then (k=1), so every score-score commutator is zero. Consider $\omega,\rho_t,\rho_{-t}$, with (t>0), where $\rho_b\propto e^{\log\omega+bA}$. Let

\[
 a=\operatorname{arctanh}r,\quad s=\sqrt{a^2+t^2},\quad
 x=t\tanh s/s,\quad z=a\tanh s/s<r.
\]

Their Bloch vectors are ((0,0,r)), ((x,0,z)), ((-x,0,z)).

Write any qubit EB channel in Bloch form $v\mapsto Tv+c$. A measure/prepare representation gives

\[
 T=\sum_y q_y r_y m_y^{\mathsf T},\qquad
 q_y\ge0,\quad\sum_yq_y=1,\quad|r_y|,|m_y|\le1,
\]

so its nuclear norm obeys $\|T\|_*\le1$, including continuous outcomes. If its half-trace error is at most (e) on the three states, subtracting the two displaced states gives

\[
 |Te_x-e_x|\le2e/x.
\]

Subtracting the reference from their midpoint gives

\[
 |Te_z-e_z|\le4e/(r-z).
\]

Therefore

\[
 1\ge\|T\|_*\ge T_{xx}+T_{zz}
 \ge2-e\{2/x+4/(r-z)\},
\]

and every entirely classical reconstruction satisfies the explicit floor

\[
 \boxed{e\ge\frac1{2/x+4/(r-z)}>0.}
 \tag{3.1}
\]

For (r=1/2,t=1), the floor is $0.0250471231\ldots$. This refutes the naive N03 generalization using only score-score commutators with a noncommuting reference. It uses bounded scores, finite dimension, finite parameters, and no Gaussian limit.

## 4. Direct two-level lower bound for unknown eigenspaces

Let a known (d)-dimensional spectrum contain two entries $p_i>p_j\ge0$. Put

\[
 w=p_i+p_j,\quad g=p_i-p_j,\quad\delta=g/w\in(0,1],\quad
 \kappa=nw\delta^2=\frac{n(p_i-p_j)^2}{p_i+p_j}.
\]

Consider only SU(2) rotations in their supplied two-level span, leaving the rest fixed. For direction $v\in S^2$, each input is

\[
 \rho_v=w\frac{I+\delta v\cdot\sigma}{2}\ \oplus\ (1-w)\tau_{\rm rest}.
 \tag{4.1}
\]

**Written finite converse.** For every EB channel on (n) copies,

\[
 \sup_v T(\Phi(\rho_v^{\otimes n}),\rho_v^{\otimes n})
 \ge\frac\delta{20}-\frac2\kappa,
 \qquad\kappa\ge64.
 \tag{4.2}
\]

The bound includes (p_j=0). It is not claimed sharp, and can be negative in weakly resolved regimes. It is sufficient for a uniform obstruction whenever a pair gap remains bounded below. The same proof covers Haar-average error.

### 4.1 Exact reduction with random active count

Measure which sites lie in the two-level span. The active count is $K\sim\operatorname{Bin}(n,w)$, independently of (v); the active sites contain (K) identical qubits with gap $\delta$. Schur-reduce those qubits. Conditional on spin label $L=2j\in\{K\bmod2,\ldots,K\}$, the direction-dependent state is

\[
 \tau_{L,v}=r^{L/2-J_v}/Z_L(r),\quad
 r=(1-\delta)/(1+\delta),\quad Z_L(r)=\sum_{s=0}^Lr^s.
\]

All active patterns, rest states, multiplicity states, and the conditional count law given (L) are known and parameter-independent. They can be discarded and regenerated exactly. Thus the subexperiment is strongly equivalent, with zero error, to

\[
 R_v=\bigoplus_{L=0}^n P_L\tau_{L,v},
\]

where (P_L) is the binomial mixture of the exact qubit Schur weights. This equivalence is a physical block measurement, Schur transform, known conditional sampling, and inverse Schur transform. Composing an arbitrary original EB channel with these exact maps remains EB.

### 4.2 A spin-sector master inequality valid for any target weights

Define

\[
 f(s)=Z_s(r)/(s+1)=\frac1{1-r}\int_r^1x^s\,dx,
 \quad t_L=(L+1)/Z_L,
 \quad b_L=t_L^2f(2L),
\]

and

\[
 T_L=Z_L(r^2)/Z_L(r)=\frac{1+r^{L+1}}{1+r},
 \quad g_L=T_L-t_Lf(2L).
\]

For cutoff (J), set $S=\{L:L\le J}$, $C=\max_{L\in S}t_L$, and $\eta_J=\sum_{L\notin S}P_L$. If an EB reconstruction has error (e), then

\[
 \boxed{\frac32e\ge C^{-1}\sum_{L\in S}P_Lt_Lg_L-\eta_J.}
 \tag{4.3}
\]

Here is the label-transition argument, so sector preservation is not hidden. Write its POVM as (M_y) and its prepared output blocks as $\omega_{y,K}$, with $s_{y,K}=\operatorname{Tr}\omega_{y,K}$. The weights

\[
 W_{LK}=P_L\int\frac{\operatorname{Tr}M_{y,L}}{L+1}s_{y,K}\,d\mu(y)
\]

form a probability coupling. Its input marginal is (P_L); its output marginal is the Haar-average decoded sector law (Q_K), with $\operatorname{TV}(Q,P)\le e$. The Haar spin twirl gives

\[
 \left\|\int\tau_{L,v}\otimes r^{K/2-J_v}\,dv\right\|_\infty
 =\frac{Z_{L+K}}{(L+K+1)Z_L}.
\]

It follows by the same-sign Clebsch–Gordan decomposition, with the largest scalar at total spin ((L+K)/2). No Choi transpose is inserted.

Use the output effect $\bigoplus_{K\in S}(t_K/C)r^{K/2-J_v}$. On pair $L,K\in S$, its normalized EB score is at most

\[
 C^{-1}t_Lt_K f(L+K)
 \le(2C)^{-1}(b_L+b_K),
\]

by Cauchy–Schwarz in the integral defining (f). Moreover $0\le b_K/C\le1$ on (S). Summing against (W) bounds the decoded score by

\[
 C^{-1}\sum_SP_Lb_L+e/2+\eta_J.
\]

The target score is $C^{-1}\sum_SP_Lt_LT_L$; an effect changes expectation by at most (e). Subtraction proves (4.3).

For all (L), $g_L\ge0$. One direct proof writes the numerator as

\[
 L\sum_{s=0}^Lr^{2s}-(L+1)\sum_{s=0}^{L-1}r^{2s+1}
\]

after multiplying by ((2L+1)Z_L). Midpoint convexity bounds the odd sum by the even sum minus the endpoint average; convexity bounds the even sum by ((L+1)) times that endpoint average. Also

\[
 g_L\ge\frac\delta2-\frac1{2(2L+1)}
\]

when the right side is nonnegative. These arguments include (r=0) by continuity.

### 4.3 Concentration from an exact collective-spin second moment

On each original site, the embedded spin is spin (1/2) with probability (w), and zero otherwise. With $g=w\delta$, collective-spin algebra gives exactly

\[
 \mathbb E[L(L+2)]=3nw+n(n-1)g^2.
 \tag{4.4}
\]

The true-axis magnetization (M) has mean (ng) and is bounded above by (L) in their joint measurement. Hence $\mathbb EL\ge ng$, and (4.4) implies

\[
 \mathbb E(L-ng)^2\le3nw.
 \tag{4.5}
\]

Thus

\[
 P(L<ng/2)\le12/\kappa,\qquad
 P(L>2ng)\le3/\kappa.
\]

Choose (J=2ng). On the retained band $ng/2\le L\le2ng$,

\[
 t_L\ge\kappa/(1+\delta),\qquad
 g_L\ge(\delta/2)(1-1/\kappa).
\]

The inequality $t_L\le1+(1-r)(L+1)$ gives, for $\kappa\ge64$,

\[
 C\le\frac{4\kappa+1+3\delta}{1+\delta}
 \le\frac{5\kappa}{1+\delta}.
\]

Retaining only the band in (4.3) therefore yields

\[
 e\ge\frac\delta{15}(1-1/\kappa)(1-15/\kappa)-\frac2\kappa
 \ge\frac\delta{20}-\frac2\kappa,
\]

because at $\kappa=64$ the product is (3087/4096>3/4), and it increases. This completes (4.2).

### 4.4 Full unknown-eigenbasis orbit criterion

Fix (d), let (p_n) be any sequence of spectra, allowing zero entries and arbitrary collisions, and let the family be

\[
 \mathcal F_n=\{(U\operatorname{diag}(p_n)U^*)^{\otimes n}:U\in U(d)\}.
\]

Then

\[
 \boxed{\inf_{\Phi\ {
m EB}}\sup_{\mathcal F_n}T(\Phi(\rho^n),\rho^n)\to0
 \quad\Longleftrightarrow\quad p_n\to(1/d,\ldots,1/d).}
 \tag{4.6}
\]

Necessity: if the largest-smallest gap does not tend to zero, choose a subsequence where it exceeds (g_*>0), and use its two-level SU(2) orbit. Its $w\le1$, $\delta\ge g_*$, and $\kappa\ge ng_*^2\to\infty$. Equation (4.2) leaves a positive floor.

Sufficiency uses the re-opened universal Schur/coherent channel, whose proof is summarized here rather than treating the card as validation. In each Schur representation, filter the highest-weight coherent resolution by $\pi_\lambda(\sqrt\rho)$. The resulting exact positive density is

\[
 P(F)=\frac{h_\lambda}{Z_\lambda}
       \frac{J_{\rho^{-1/2}}(F)}{Q_\lambda(\rho^{-1};F)},
\]

while the coherent POVM density is $f(F)=h_\lambda Q_\lambda(\rho;F)/Z_\lambda$. Positive-operator Cauchy–Schwarz gives $Q(\rho)Q(\rho^{-1})\ge1$. The complete-flag QR Jacobian is

\[
 J_g(F)=\frac{\det(g^*g)^{d-1}}
 {\prod_{r<d}\det(F_r^*g^*gF_r)^2},
\]

and compression-determinant bounds give

\[
 \sup_FJ_{\rho^{-1/2}}(F)=\prod_{i<j}p_i/p_j.
\]

Consequently $f\ge c(p)P$, $c(p)=\prod_{i<j}p_j/p_i$, and the measure/prepare channel obeys

\[
 \mathcal C_{n,d}(\rho^{\otimes n})\succeq c(p)\rho^{\otimes n},
 \qquad T\le1-c(p).
\]

Its error tends to zero when $p_n\to I/d$. Faithfulness holds eventually in this case. Carathéodory applied to the coherent channel Choi matrix gives at most $h_\lambda^4+1$ outcomes in each sector, so the entirely classical alphabet is polynomial in (n) for fixed (d). Its exponent is at most ((d-1)(2d+1)); finding the finite design is a separate computational problem.

This criterion excludes a fully classical unrestricted partial-collision theorem whenever two limiting eigenvalue blocks stay separated. The supplied-projector block theorem can still be classical: its unknown family does not include these transverse rotations. For example, the full orbit of ((.4,.4,.2)) has the lower bound $e\ge1/60-30/n$, despite its exact twofold collision. The theorem does not determine the required quantum memory dimension or the sharp floor.

## 5. The actual Gaussian/factorization boundary

N08 correctly separates an entire *supplied block algebra* from an unknown eigenspace experiment. Its exact covariance and symplectic form at $\rho_0=\bigoplus_b a_bI_{m_b}$ are

\[
 V(H,L)=\operatorname{Re}\operatorname{Tr}\rho_0HL
       -\operatorname{Tr}\rho_0H\operatorname{Tr}\rho_0L,
 \qquad\Omega(H,L)=-i\operatorname{Tr}\rho_0[H,L].
\]

For an interblock pair, $\Omega(X_{ij},Y_{ij})=a_b-a_c$; its canonical Gaussian oscillator variance is

\[
 \frac{a_b+a_c}{2(a_b-a_c)}=\frac12+\frac{a_c}{a_b-a_c}.
\]

Within-block directions are classical only after a compatible strong comparison has been constructed. The exact missing lemma is a single Schur-sector isometry retaining the unknown $\prod_bU(m_b)$ ground representation tensor crossblock Fock modes, with a uniform trace-norm product approximation and a reverse approximation. It must cover unknown within-block eigenvalue splitting and must preserve correlations with the crossblock modes. Measuring the original block word first destroys those modes; multiplying the block channel by the fixed-orbit QLAN channel therefore does not supply the lemma.

At fixed excitation cutoff, cross commutators have unwanted ground terms of normalized size $O(\delta+n^{-1/2})$. That supports a Gram-matrix approximation, but it does not by itself bound an unknown ground density's trace norm, thermal tails, leakage outside the isometry, or conditional correlations. No such factorization was proved here. The original tracial bridge's Schur/HCIZ cancellation, continuous matrix log-Gamma normalizer, and lattice inversion remain inherited candidate arguments; the improved average-cell (n^{-1/2}) remainder changes none of this nontracial obstruction.

### A one-parameter counterexample to a symplectic-subspace criterion

Take a fixed faithful thermal oscillator

\[
 \tau_0=(1-r)\sum_{n\ge0}r^n|n\rangle\langle n|,\qquad0<r<1,
\]

and the one-real-parameter family $\tau_u=D(u)\tau_0D(u)^*$, $u\in[-R,R]$. Its parameter tangent has dimension one, hence the restriction of any antisymmetric symplectic form to it is zero. Nevertheless $\tau_0\$ and $\tau_u$ do not commute for $u\ne0$.

Indeed, commutation with faithful $\tau_0$ implies invariance under its modular unitaries $e^{it\beta N}$, $\beta=-\log r>0$. These rotate the displacement mean (u) by $e^{-it\beta}$. A nonzero mean cannot be invariant for every (t). Thus no EB channel fixes both states, by no broadcasting.

Nor can their EB reconstruction error have infimum zero. If EB channels $\Phi_j$ fixed both asymptotically, their images of the faithful $\tau_0$ would form a tight compact set in trace norm. For every finite spectral projection (P_m) of $\tau_0$, $P_m\preceq C_m\tau_0$; the output of every positive input supported there is correspondingly tight. A diagonal subsequence over finite matrix units gives a strong-limit CPTP channel; density and trace-norm contractivity extend it to all trace-class inputs. The EB property is closed in strong convergence because all ancilla-output separable states form a closed set. The limit would fix both noncommuting states, a contradiction. This is a qualitative positive-floor argument, not a sharp benchmark.

Established strong qubit LAN transfers this obstruction to one-parameter local transverse qubit experiments at a fixed nontracial reference. It is not necessary to vary two conjugate local parameters to obstruct entirely classical *experiment* preservation. Single-parameter SLD Fisher-information attainability is therefore weaker than density/experiment recoverability.

For an independent classical/thermal Gaussian product experiment, exact EB reconstructibility requires every quantum displacement to be constant across parameters. When the quantum covariance is correlated with a classical Gaussian center, the appropriate constant quantity is the conditional quantum mean (m_q-V_{qc}V_{cc}^{-1}m_c). A zero symplectic form merely on the supplied mean subspace does not impose that condition. This statement concerns exact Gaussian structure; it does not prove the missing partial-collision strong channels.

## 6. Supplied inputs, operations, and resources

For (2.1), $\omega,A_i,k,R$ are supplied. The code does not estimate them from the input. The offline work diagonalizes the reference, selects finitely many reference-bin residues, and successively diagonalizes score restrictions in a nested partition. Generic matrix descriptions require (O(kD^2)) complex data at Hilbert dimension (D), and generic exact quantum projective measurements/preparations can be expensive. No polynomial-size circuit compiler or finite-bit arithmetic uniform in $\lambda_{\min}(\omega)$ is established.

The retained classical dimension is $M\le C_kz^{-ka_k}$, costing $ka_k\log_2(1/z)+O_k(1)$ bits, and the retained quantum dimension is one. The known reference-bin index is not retained: the decoder's conditional state sums all supplied reference blocks within the same joint score label. The reconstruction may regenerate a large known density with fresh ancillas, whose preparation and thermodynamic costs are not implied to be free physically. They are explicitly separate from retained input-dependent storage.

The two-level lower bound supplies the known spectrum and permits arbitrary hardware, arbitrarily large classical memory, and arbitrary output preparations. Its floor is therefore an information obstruction, not a circuit-cost claim. Conditional subspace measurement is used only to expose an exactly equivalent subexperiment for the converse.

For (4.6), the finite coherent design is existential; spectrum and eigenspaces are unknown to the universal channel. A positive floor rules out a wholly classical archive but does not quantify how many qubits a hybrid archive must retain. None of these results preserves an external reference or solves an unknown many-body Gibbs-state preparation problem.

## 7. Decisive falsification and numerical evidence

The proof can fail at specific, testable points:

* A reference-bin counterexample to (2.4), or a failure of (2.6) in a highly nontracial state, invalidates the approximate-reference extension.
* A common-width recursion example violating (2.9) invalidates its multi-score exponent. The required norm is reference-weighted and the scores commute with the flattened reference; applying (2.9) outside that algebra is invalid.
* Incorrect charging of the known conditional reference-bin index would invalidate the finite alphabet claim. Equation (2.12), summed over all reference bins, makes this explicit.
* A transpose in the spin twirl, a false same-sector restriction, or a parameter-dependent count/label decoder would invalidate (4.2). The coupling proof admits all transitions and the conditional count law is independent of the direction.
* Zero tangent symplectic form cannot certify a classical Gaussian experiment; the one-real-displacement example is a decisive counterexample.

`check_boundary.py` was run successfully. Its six spin fixtures check total mass, the exact Casimir moment, the centered second-moment bound, nonnegative thermal gap, and the master versus simplified bound where its threshold applies. They include a pure active block. It separately computes the explicit three-state qubit floor, checks 6,000 scalar log-bin inequalities over tiny and huge modular gaps, and checks the common-width exponents for $k=1,\ldots,8$. `diagnostics.json` preserves the results. These checks do not prove asymptotic channel correctness.

The dense-matrix construction in `check_matrix_construction.py` also passed. Six nontracial fixtures in dimensions 4--12 check reference-bin distortion, score centralization, the weighted commutator bound, positive Gibbs comparison, exact fixation of the approximating family, and original-family reconstruction. Log-condition spans include 100. Three further tracial fixtures in dimensions 12 and 24 execute nonzero pinches for three and four scores, with final commutators below 2e-12. Every step checks the selected pinching cost against (2.8) and the operator rounding bound. Universal comparison constants are conservative and often exceed one on these small fixtures; no tight finite resource advantage is inferred. Results are in `matrix_diagnostics.json`. `rounding_lemma.md` isolates the common-width proof for a second reader.

## 8. Primary sources, exact artifacts, and novelty status

* [Bansil–Kachkovskiy, On almost commuting matrices with respect to the normalized Hilbert–Schmidt norm, 31 August 2026](https://arxiv.org/html/2608.31000): Theorems 1.1, 1.3 and Corollary 1.4 read. The pair (1/3) exponent is prior art. Their stated multi-matrix exponent is (1/3^{k-1}). Exact HTML is saved in `sources/bansil_kachkovskiy_2608_31000.html`.
* [Glebsky, Almost commuting matrices with respect to normalized Hilbert–Schmidt norm](https://arxiv.org/abs/1002.3082): longstanding qualitative dimension-independent commuting approximations; abstract and the newer paper's contextual theorem descriptions checked. Not a new conceptual almost-commuting principle.
* [Barnum–Caves–Fuchs–Jozsa–Schumacher, Noncommuting mixed states cannot be broadcast](https://arxiv.org/abs/quant-ph/9511010): exact no-broadcasting boundary. The approximate reference theorem and explicit Bloch/spin inequalities are separate derivations, not claims that no broadcasting is new.
* [Guţă–Kahn, Local asymptotic normality for qubit states](https://arxiv.org/html/quant-ph/0512075), and [Kahn–Guţă, finite-dimensional LAN](https://arxiv.org/html/0804.3876): the fixed faithful nontracial qubit strong channels and displaced thermal conventions were checked; the latter's introductory Theorem 1.1 gives the exact bidirectional interface. These do not automatically supply uniform unknown splitting in partial collisions.
* [Yamaguchi–Tajima, Quantifying Symmetry Breaking with Metric Adjusted Quantum Geometric Tensors](https://arxiv.org/abs/2609.11926): live metadata checked; the exact fixed-orbit/degeneracy restrictions used here were re-opened in the supplied N08 proof record. No claim of a complete 116-page proof audit.
* [Guţă–Bowles–Adesso, Quantum teleportation benchmarks for iid spin states and displaced thermal states](https://arxiv.org/abs/1004.1843): established full-displacement thermal EB benchmark; reopened inherited precision note records its exact normalization. This run's lower bound is direct and weaker, with arbitrary active count.
* [Shirokov, The Schmidt number and partially entanglement breaking channels in infinite dimensions](https://arxiv.org/html/1110.4363): Section 5's explicit strong-closure statement was read in the saved exact HTML. The closure can also be read directly from the definition and closed separable-state cone.

The Astra sources were copied/extracted, preserving their scope:

* `sources/d-ece46f964518dbb3.md`: N03's complete supplied summary; its full linked proof was absent. The new sufficiency theorem deliberately avoids relying on that absent proof.
* `sources/d-900a3c8187ffc0aa.md`: N08's actual written block theorem and named missing ground-component/Fock lemma; sections 4–5 were reconstructed.
* `sources/d-c4a9e95fccd25a09.md`: inherited average-cell Gaussian-rate refinement; its external analytic inputs and the fact it is not a nontracial factorization were retained.
* `sources/d-7bf3825bbd159ebb.md`: inherited critical Gaussian audit, copied for scope preservation.
* The live prior `work/quantum_higher_d.md`, `quantum_precision.md`, and `precision_audit.md` in the earlier `you-have-access-to-over-100-2` workspace were reopened. The coherent positive-symbol mechanism and the generic spin-sector witness were independently reconstructed above.

The approximate-reference finite-code theorem, common-width multi-matrix recursion, and arbitrary-active-count pair converse are useful written deductions. The first may be a new combination or extension; the pair (1/3) lemma is established prior art. The full unknown-eigenbasis iff statement combines a new direct finite lower bound with the inherited coherent upper, and extends a known fixed-model noncommutativity obstruction to moving spectra and rank changes. No historical novelty clearance, practical advantage, or completed universal hybrid theorem is claimed.

Memory navigation used only the provisional status and exact prior-file pointers. All load-bearing inherited claims used here were reopened. Memory references: `MEMORY.md:44–97`; `rollout_summaries/2026-10-06T16-44-34-0JR9-uniform_gaussian_equivalence_spectral_collisions.md:1–89`; rollout `01a1121a-4750-72f0-8f5c-b501038890d3`.
