# Independent boundary audit: consolidated findings

7 October 2026. Parent quantum_statistics; all writes restricted to this directory. These are internal written mathematics, not external validation or novelty clearance.

## Strongest negative result: growing dimension breaks near-tracial classicalization

Independently inspected the complete construction at growing_dimension/COUNTEREXAMPLE.md and its collective Gaussian proof at growing_dimension/gaussian_eb_lower/EXACT_MULTIMODE_EB_BENCHMARK.md. I found no missing internal lemma or false quantifier. In particular the result is existential in the sample-size thresholds and uses only fixed-d LAN separately at each stage; it does not silently invoke growing-d uniform LAN.

There are faithful distinct spectra p_n, dimension d_n->infinity arbitrarily slowly, for which

||d_n diag(p_n)-I||op->0,
inf_(Phi EB) sup_U T(Phi[(U diag(p_n)U*)^tensor n],(U diag(p_n)U*)^tensor n)->1.

Unlimited classical alphabets and arbitrary collective encoder/preparation are included. d^2/4 cross-cluster modes, each individually weakly quantum, accumulate a near-maximal trace-distance defect. At each fixed stage d, the proof gives eventual lower bound

1-8(d+2sqrt(d)+1)/d^2-3/d.

This is consequential whole-experiment/density preservation, not merely a storage exponent refinement. Bidirectional deficiency to any classical experiment has errors whose sum asymptotically reaches at least one. Retained quantum-memory dimension is not bounded below here, and a practical n(d) threshold is unknown.

Audited details: finite-volume displacement twirling; normal weak-star subchannel and escaped mass; coCP/PPT doubled-symplectic Weyl characterization; gain-2 amplifier thermal noise normalization; loss/amplifier factorization; arbitrary correlated-Fock photon-number stochastic domination; negative-binomial likelihood crossing and Chebyshev bound; finite-radius beamsplitter localization; distinct spectrum perturbation and product thermal continuity; exact fixed-d unitary orbit coordinates; physical strong-channel composition and diagonalization. Primary Kahn--Guţă Theorem4.3 and Owari Lemma4 were reopened. The reciprocal-sqrt2 in Owari's Appendix formula is inconsistent with its doubled-form statement; direct rescaling and the main text agree with sqrt2. This is recorded explicitly, not ignored.

## Strongest positive result: local near-SU2 Gibbs fluctuation experiment

noncentral_fluctuation_theorem.md proves the following sufficient theorem directly: centered spin fluctuations A_i=(J_i-Eomega J_i)/sqrtN, all fixed exponential moments bounded, Wigner--Yanase defects ||[sqrtomega,A_i]||HS->0, and Eomega J^2/N^2->0 imply uniform EB density reconstruction for exp(logomega+b.J/sqrtN), bounded b. For each fixed requested error, an eventually bounded classical alphabet exists; no efficient circuit or sharp alphabet law is claimed.

The key repair to the original central clipping proof is noncentral Gibbs tail replacement by a uniform entropy bound and symmetric KL identity. This avoids invalid operator order e^(logomega+bounded score)<=constant omega. WY defects contract under ordinary HS functional calculus. Weighted score commutators do not automatically contract under clipping without centrality; a separate SU2 total-spin cutoff and smooth functional calculus proof closes that gate.

An explicit corollary covers known finite-range bounded-strength H_N=H_inv+lambda_N V_N, exact [H_inv,J_i]=0, lambda_N->0 at any rate, and a fixed beta below the common Kuwahara--Saito threshold beta_c=1/(8e^3 g_* q). Their Theorem 1 equation (10) applies to J_i, V and i[V,J_i]. We derive the conservative Gaussian tail 2 exp[-(beta_c-beta)x^2/(8Fbar)] directly from that MGF theorem, giving all centered tails and commutator-sum O(N) variance. Thermal commutator mean is zero. Kubo--Mori CS and variance domination give d E J_i/N /dλ=O(1), hence E J^2/N^2=O(1/N+lambda_N^2). Thus full unknown-field b/(beta sqrtN) experiments strongly classicalize even if N lambda_N diverges. Time reversal is optional, not required. All needed local-strength and moment assumptions are explicit.

This is a useful extension of bounded-score classicalization to noncentral unbounded conserved fluctuations. It is internally derived; priority remains unresolved. It does not solve generic local Gibbs strong LAN or give a necessary condition for every perturbation V.

## Exact interacting counterexample

dimer_counterexample.md gives a connected ring cluster-chain Hamiltonian

H_N(theta)=-sum_i [cos(theta) Z_(i-1)X_i Z_(i+1)+sin(theta) Z_(i-1)Y_i Z_(i+1)].

At fixed inverse temperature a>0, every one-site marginal is exactly I/2 for all theta. A supplied depth-two CZ circuit reduces the entire state to nontracial iid logical qubits. Under theta=u/sqrtN, strong qubit LAN and thermal no-broadcasting compactness imply a positive EB floor. This refutes inference from local marginal traciality or zero one-dimensional tangent symplectic form to strong classical experiment preservation. Those conceptual obstructions were already explained in 2006 primary LAN work; the cluster chain is an explicit local Gibbs corollary, not a claimed new no-broadcasting principle.

check_cluster.py independently verified the exact Gibbs/CZ factorization, commuting interaction terms, and vanishing one-site Pauli expectations at N=4,6 and three angles; errors were below 9e-16. The checks verify conventions only.

## Remaining genuine bottlenecks

* Kuwahara--Saito equation (17) has an apparent factor error in completing the square. Its displayed Corollary 1 coefficient is not inherited. The corrected conservative Gaussian bound is derived explicitly from Theorem 1 equation (10), preserving all qualitative conclusions.
* External proof review and priority assessment of these new combinations remain undone.
* Growing-d sample-size thresholds are existential; useful finite-n,d error bounds and a matching upper classicalization criterion are open.
* No growing lower bound on quantum memory dimension is established.
* Generic unknown/nonconserved interacting local Gibbs perturbations remain outside the positive theorem.
* All Hamiltonian/reference/operator descriptions are supplied. Measurement design, exact means, conditional known-state preparation and numerical/circuit complexity are separate acquisition/execution costs.
* The central bounded-score converse imported through N03 has an absent proof, so the central exponential-tail iff extension in clipping_theorem.md is explicitly conditional; the positive near-SU2 theorem does not depend on it.

Source URLs and exact handles are contained in the proof notes. No external messages, cloud jobs, installations or shared-repository writes occurred.

Memory navigation used MEMORY.md lines44--97 for provisional status and source pointers only. All load-bearing current results were re-opened or rederived. Associated prior rollout 01a1121a-4750-72f0-8f5c-b501038890d3.

## Later escalation: pairwise intrinsic defect without uniform entropy

PAIRWISE_ENTROPY_BOUNDARY.md independently audits and strengthens the thermal example. For m modes of common thermal mean n, root fidelity is exp[-s/(4n+2)] and affinity is exp[-s/D], D=(sqrt(n+1)+sqrt(n))^2. The exact supremum pair gap is (kappa-1)kappa^[-kappa/(kappa-1)]<=1/(eD^2)=O(n^-2), kappa=1+D^-2, independent of m. Setting m=n^3 makes the arbitrary-collective EB minimax risk tend to one while the pair gap tends to zero.

Thermal localization gives bounded compact displacement boxes. A Fock cutoff with leakage n^-12 makes the experiments finite-dimensional: reconstruction lower bounds lose at most n^-12+n^-6 and pair-gap bounds change by at most 4sqrt(2)n^-3. Finite 1/n trace-distance nets then give FINITE faithful-state experiments with the same limits. A projected binary displacement packing contains exponentially many states separated by trace distance tending to one, making the failure of uniform covering entropy explicit.

This is a counterexample to a pairwise-fidelity/affinity criterion WITHOUT a uniform metric-entropy premise; it does not refute a criterion retaining that premise. All primary fidelity conventions were checked in Banchi et al equations (8)--(9); the affinity, maximization, cutoff transfer and finite-net steps were independently derived. Local scalar diagnostics checked n=0,1,2,10,100,1000 and do not substitute for the proof. External correctness/priority remains open.
