# Exponential-tail extension of central bounded-score classicalization

Status: independently derived sufficient theorem, 7 October 2026. No external correctness or novelty clearance. The commuting-grid lemma is rederived below rather than treating an Astra summary as proof. This result concerns whole density reconstruction, not purifications, efficient preparation or unknown Hamiltonian acquisition.

## The exact theorem

For each N, let omega_N>0 be a supplied finite-dimensional density matrix and A_N,1,...,A_N,k supplied Hermitian matrices; k and R>0 are fixed. No N-uniform operator-norm bound is assumed. Suppose

1. [omega_N,A_N,i]=0 for every i.
2. For some s>2R, C_s:=sup_(N,i) Tr omega_N exp(s|A_N,i|)<infinity.
3. eta_N:=max_(i,j) ||[A_N,i,A_N,j]||_(2,omega_N) ->0.

Define rho_N,b=omega_N exp(S_N,b)/Tr(omega_N exp(S_N,b)), S_N,b=sum_i b_i A_N,i, ||b||_1<=R.

Then there exist entanglement-breaking, parameter-independent channels Phi_N with

sup_b T(Phi_N(rho_N,b),rho_N,b)->0.

Moreover for every fixed epsilon>0 there is a finite classical alphabet M_epsilon, independent of N, and N_0(epsilon), such that for all N>=N_0 the channel can use at most M_epsilon labels and zero retained qubits with error <=epsilon. All labels count. The known reference and scores determine the encoder/decoder offline. This is an existential finite-dimensional measurement/preparation theorem.

## Proof: tail clipping is uniformly harmless

Write tau_N(X)=Tr omega_N X. Omega commutes with the entire score algebra, so tau_N is a trace on it. Set B_i=f_K(A_i), f_K(x)=max(-K,min(x,K)), K>=1, and rho'_b=omega exp(sum_i b_i B_i)/Z'_b. We have rho'_b<=exp(2RK)omega because omega is central and ||sum_i b_iB_i||op<=RK.

Put E=sum_i b_i(A_i-B_i). Golden--Thompson and log x<=x-1 give

D(rho'_b||rho_b)<=Tr rho'_b (exp(E)-I-E)
 <=exp(2RK) tau(exp(E)-I-E).

The matrix exp(E)-I-E is positive by scalar functional calculus. For lambda_i=|b_i|/R and lambda_0=1-sum_i lambda_i, trace convexity of exp gives

tau(exp(E)-I-E)
 <=sum_i lambda_i tau[exp(R sign(b_i)(A_i-B_i))-I-R sign(b_i)(A_i-B_i)].

For scalar y=(|a|-K)_+ and either sign, 0<=exp(+-Ry)-1-+-(Ry)<=exp(Ry) 1_{|a|>K}. Hence, for s>=R,

tau(exp(E)-I-E)
 <=max_i exp(-RK) tau(exp(R|A_i|)1_{|A_i|>K})
 <=C_s exp(-sK).

Quantum Pinsker consequently gives the explicit, dimension-free comparison

sup_b T(rho'_b,rho_b) <=sqrt(C_s/2) exp[-(s-2R)K/2].    (A)

No noncentral Loewner domination or exponential operator-monotonicity is used. This estimate is generally invalid if [omega,A_i]=0 is omitted; that boundary is load-bearing.

## Proof: clipping does not enlarge the commutators

For a 1-Lipschitz scalar function f, in a basis diagonalizing A and omega,

||[f(A),X]||_(2,omega)<=||[A,X]||_(2,omega).

The entrywise factor f(a_r)-f(a_s) has magnitude <=|a_r-a_s|. Applying this first to B then to A gives

||[f_K(A_i),f_K(A_j)]||_(2,omega)<=eta_N.

For normalized contractions X_i=B_i/K, commutator defects are at most delta_N=eta_N/K^2. Each X_i commutes with omega.

## Proof: a finite commuting grid

For k Hermitian contractions X_i central with respect to omega, commutator defect delta, fix one common bin width q in (0,1). Randomly offset bins of width q for a current score X. Round X to centers and pinch all remaining scores to this partition. In a common eigenbasis of X and omega,

E ||Y-P(Y)||_2^2
 <=q^(-1) sum_(r,s) p_s |x_r-x_s| |Y_rs|^2
 <=q^(-1) ||[X,Y]||_2 ||Y||_2.

This is Cauchy--Schwarz and ||Y||_2<=1. Choose one common offset for which the sum of remaining squared errors is no larger than its expectation. Earlier rounded scores commute with the partition, so their values remain unchanged. All current scores and pinches commute with omega.

If d_j bounds cumulative errors after j pinches, comparison with the original commutators yields

d_0=0, d_(j+1)<=d_j+sqrt(k(delta+4d_j)/q).

Taking delta<=q^(2^k-1), induction gives d_j<=C_(k,j)q^(2^(k-j)-1), and the last pinch has O_k(q) error. Round the last score as well. Thus there are commuting contractions C_i, commuting with omega, on grids with at most ceil(2/q)+2 values, satisfying max_i||X_i-C_i||_2<=C_k q. The joint alphabet is at most (ceil(2/q)+2)^k. No reference-block index is retained.

The proof uses traciality on the score algebra, which follows from exact centrality of omega. For k=1 simply round the sole score and the defect constraint is vacuous.

## Proof: reconstruction and finite alphabet

Approximate the clipped scores B_i by K C_i. Let sigma_b=omega exp(sum_i b_i K C_i)/Z. It is fixed exactly by measuring the joint grid projections P_z and preparing P_z omega P_z/Tr(P_z omega). The alphabet above is independent of the Hilbert-space dimension.

The bounded Golden--Thompson comparison from N39 section 2.3 is independently obtained by centering the score error and using exp(X)<=I+X+(exp(2L)/2)X^2 for ||X||<=2L. It gives

T(rho'_b,sigma_b)<= (R K/2) exp(3RK) C_k q.

Triangle inequality and contractivity then give, on the original experiment,

sup_b T(Phi(rho_b),rho_b)
 <=sqrt(2 C_s) exp[-(s-2R)K/2] +R K exp(3RK) C_k q.    (B)

Given epsilon, first choose fixed K making the first term <=epsilon/2, then fixed q making the second <=epsilon/2. Since eta_N/K^2->0, the condition delta_N<=q^(2^k-1) holds eventually. This proves the stated theorem.

## Subgaussian refinement (scope: upper bound only)

If for every real t, max_i tau exp(t A_i)<=exp(v t^2/2), then tau exp(s|A_i|)<=2 exp(vs^2/2). Optimizing (A) at s=K/v gives a clipping term <=exp[-K^2/(4v)+RK]. Consequently K=O_(v,R)(1+sqrt(log(1/epsilon))) suffices, and

log M_epsilon <=k log(1/epsilon)+O_(k,R,v)(sqrt(log(1/epsilon))+log log(1/epsilon)).

This is not a matching lower bound or an optimal archive law.

## Conserved-charge consequence

Let H_N be any supplied SU(2)-invariant spin-1/2 Hamiltonian, omega_N proportional exp(-beta H_N), and J_(N,i)=sum_x sigma_i^(x)/2. The Hamiltonian may contain noncommuting local interaction terms. Set A_(N,i)=J_(N,i)/sqrt(N). Then [omega_N,A_i]=0 and

[A_x,A_y]=i J_z/N,
eta_N^2=max_i Tr omega_N J_i^2/N^2.

If spin-rotation invariance and a uniform Gaussian concentration bound for J_i/sqrt(N) hold, then the moments above are uniformly bounded, Tr omega_N J_i^2=O(N), and eta_N=O(N^(-1/2)). The theorem therefore preserves the entire bounded-local-field family

rho_(N,b) proportional exp(-beta H_N+b.J_N/sqrt(N)), ||b||_1<=R,

with an asymptotically lossless entirely classical archive of bounded size for fixed requested error. This is density reconstruction of the whole N-spin experiment, not merely local observable tomography. A central-limit theorem, Gaussian density identification, and lattice Gibbs-state preparation are not assumed or provided.

Kuwahara--Saito (1906.10872v2), Theorem 1 equation (10), supplies the MGF bound from which the conservative Gaussian concentration estimate in noncentral_fluctuation_theorem.md is directly derived for generic few-body high-temperature Gibbs systems under their bounded-local-strength hypotheses. Their equation (17) has an apparent completing-square factor error, so its displayed Corollary 1 coefficient is not inherited. Their exact hypotheses and beta threshold must be applied; finite-range bounded-degree Heisenberg interactions fall within that class. This is a new composition to audit, not a claim that concentration or almost-commuting approximation is new.

## Necessity route, explicitly conditional

N03 states a dimension-uniform quantitative converse for central bounded contractions, but its full proof was not supplied. If that converse is correct, exponential tails extend its iff criterion as well. If eta_N stays >=eta_0 on a subsequence, noncommutative L4 Hölder and exponential-tail estimates imply eta_(N,K) of clipped scores stays >=eta_0/2 for one sufficiently large fixed K. Test coordinate tilts at a small t<min(R,s/20). The N03 floor for contractions B_i/K is proportional to t^4 eta_0^4 exp(-4tK)/K^4. The clipping discrepancy is O(exp[-(s-2t)K/2]), which decays faster because s>10t. Thus one can choose fixed K so clipping error is below the floor and transfer a positive floor back to the original family. This is a conditional converse, not independently established here.

## Failure ledger and priority

* Raw small score commutators without reference centrality do not suffice. N39's finite qubit counterexample already settles this.
* Local marginal traciality does not imply global classicality; see dimer_counterexample.md.
* Uniform variance alone is insufficient for the clipping estimate. Rare tails can dominate fixed exponential tilts; a moment or another uniform tilted-tail premise is essential.
* The theorem does not settle generic nonconserved local-Gibbs scores. Strong local Gibbs comparison, not a fluctuation CLT or vanishing tangent symplectic form, is still the bottleneck.
* Existing qualitative normalized-HS almost-commuting results (Glebsky 2010) and recent quantitative bounds (Bansil--Kachkovskiy 2026) are prior art. The elementary clipping/Gibbs composition and its exact conserved-charge application need priority checking.

Primary sources checked: https://arxiv.org/html/1906.10872v2 (Theorem 1 equation (10), conservative tail derived independently); https://arxiv.org/html/quant-ph/0606213 (Lemma 5.5 and modular minimal sufficient algebra); https://arxiv.org/html/quant-ph/0512075 (Theorem 1.1 and Section 7.2); https://arxiv.org/abs/1002.3082; https://arxiv.org/html/2608.31000.
