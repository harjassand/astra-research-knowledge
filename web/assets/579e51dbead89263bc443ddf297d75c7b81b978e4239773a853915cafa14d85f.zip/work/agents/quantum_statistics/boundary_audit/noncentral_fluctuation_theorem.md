# Strong classicalization of near-conserved SU(2) fluctuation experiments

Status: independently written sufficient theorem and explicit high-temperature local-Gibbs corollary. No external proof/priority certification. Density reconstruction is the contract; preparation complexity and purification preservation are not claimed. The bounded-score approximate-reference construction is N39 sections 2.1--2.3, re-opened and checked in this run. No dependence on N03's absent converse.

## General SU(2) theorem

For each N, let J_N=(J_x,J_y,J_z) be the total spin of N spin-1/2 sites. Let omega_N>0 be any supplied density, m_(N,i)=Tr omega_N J_i and

A_(N,i)=(J_i-m_(N,i)I)/sqrt(N).

Fix R>0. Suppose:

(A) For every s>0, sup_(N,i) Tr omega_N exp(s|A_(N,i)|)<infinity.
(B) nu_N=max_i ||[sqrt(omega_N),A_(N,i)]||HS ->0.
(C) Tr omega_N (J_x^2+J_y^2+J_z^2)/N^2 ->0.

Then the whole family

rho_(N,b) proportional exp(log omega_N+b.J_N/sqrt(N)), ||b||_1<=R,

admits parameter-independent entanglement-breaking reconstruction with uniform trace-distance error tending to zero. For every fixed epsilon>0 an eventually N-independent finite classical alphabet M_epsilon suffices, with zero retained qubits. Conditions describe the known reference/model; they are not acquired by the archive.

The scalar centering does not alter the density family because it cancels in normalization. Scores may have diverging operator norms. Condition (C) follows, for example, from uniform centered Gaussian concentration together with m_N/N->0; no commutation of omega with J^2 is required.

## 1. Gibbs tails can be clipped without reference centrality

Here is the missing noncentral replacement for the earlier central clipping proof. It uses uniform ALL exponential moments; the earlier one-fixed-moment theorem did use exact centrality.

For any fixed number k of Hermitian scores with assumption (A), set B_i=f_K(A_i), f_K scalar clipping into [-K,K]. Write S=sum b_i A_i, S'=sum b_iB_i, rho=exp(log omega+S)/Z and rho'=exp(log omega+S')/Z'. Let C_s bound all reference moments and M_1 bound max Tr omega |A_i|.

Choose one t_0>R. The Gibbs variational identity and quantum entropy inequality give

D(rho||omega)=Tr rho S-log Z,
log Z>=Tr omega S>=-R M_1,
Tr rho |A_i| <=[D(rho||omega)+log Tr exp(log omega+t_0|A_i|)]/t_0
 <=[D(rho||omega)+log C_(t_0)]/t_0.

Consequently both rho and rho' have uniform entropy bound

D(rho||omega), D(rho'||omega)
 <=C_ent=[(R/t_0)log C_(t_0)+R M_1]/(1-R/t_0).      (1)

For rho' the same argument holds because |B_i|<=|A_i| by scalar functional calculus. No Loewner comparison between a noncentral Gibbs state and omega is assumed.

Set T_i=|A_i-B_i|=(|A_i|-K)_+. For every t>0 and any s>=t,

Tr rho T_i <=[C_ent+log Tr omega exp(tT_i)]/t
 <=[C_ent+log(1+C_s exp(-sK))]/t,                       (2)

and the same holds for rho'. The first inequality is again entropy duality + Golden--Thompson. The second follows from

exp(tT_i)-I <=exp[t(|A_i|-K)] 1_(|A_i|>K)

and the reference s-moment. For each fixed t the logarithmic term vanishes as K grows; then t can be made arbitrarily large. Thus all expected score tails vanish uniformly under both Gibbs families.

The exact symmetric-relative-entropy identity is

D(rho||rho')+D(rho'||rho)=Tr[(rho-rho')(S-S')]
 <=sum_i |b_i| [Tr rho T_i+Tr rho' T_i].                (3)

Both summands on the left are nonnegative. Pinsker and (2) imply

sup_b T(rho_b,rho'_b)
 <=sqrt{ R[C_ent+log(1+C_s exp(-sK))]/t }.              (4)

Choose t first, then K. This tends to zero independently of Hilbert dimension and without [omega,A_i]=0.

This proof only establishes vanishing/bounded-epsilon reconstruction. It supplies no sharp memory exponent. Under Gaussian tails its entropy estimate gives clipping error O(K^(-1/2)), which is weaker than the exponentially small error available in the exactly central case.

## 2. Wigner--Yanase defect contracts under clipping

For a 1-Lipschitz scalar f and any matrix X,

||[f(A),X]||HS<=||[A,X]||HS.

This follows directly by diagonalizing A and comparing its entrywise differences. Therefore ||[sqrt omega,B_i]||HS<=nu_N. This ordinary-HS inequality needs no centrality of omega.

Weighted score-score commutators do not enjoy the same immediate contraction when omega is noncentral. The SU(2) structure closes that separate gate, as follows.

## 3. Fixed clipped scores almost commute in the weighted norm

Let P_(N,a) be the spectral projection of total spin j onto j<=aN. All A_i and B_i commute with this projection. On its range

||[A_i,A_j]||op=||J_k/N||op<=a.

For fixed K and delta>0, approximate f_K uniformly on the real line by a smooth bounded scalar f, constant outside a compact interval, with error <=delta and ||f||infinity<=K+delta. Its derivative has integrable Fourier transform. The Fourier representation

f(A)-f(0)I=(2pi)^(-1) integral hat(f')(t)(exp(itA)-I)/(it) dt

and Duhamel's identity give an operator commutator bound

||[f(A),X]||op<=L_f ||[A,X]||op,
L_f=(2pi)^(-1) integral |hat(f')(t)|dt <infinity.

Apply this twice to obtain

||[f(A_i),f(A_j)]||op<=L_f^2 ||[A_i,A_j]||op.

Hence, on P_(N,a),

||[B_i,B_j]P_(N,a)||op<=L_f^2 a+4(K+delta)delta.        (5)

The full commutator norm is <=2K^2. Since it commutes with P_(N,a),

||[B_i,B_j]||_(2,omega)^2
 <=[L_f^2 a+4(K+delta)delta]^2
       +4K^4 Tr omega (I-P_(N,a)).                    (6)

Total-spin Casimir gives j(j+1)=J^2. Condition (C) lets us choose a_N->0 such that Tr omega(I-P_(N,a_N))->0; for example choose a_N=[Tr omega J^2/N^2]^(1/4), with a harmless positive sequence if the numerator is zero. Markov's inequality controls the tail by Tr omega J^2/(a_N^2 N^2).

For fixed delta, first let N->infinity in (6), then delta->0. Thus, for every fixed K,

eta_(N,K):=max_(i,j)||[B_i,B_j]||_(2,omega)->0.         (7)

No [omega,J^2]=0 or centrality is used. Smooth global approximation avoids invoking a dimension-dependent operator-Lipschitz bound for the nonsmooth clipping function itself.

## 4. Apply the bounded approximate-reference archive

For each fixed K, B_i/K are Hermitian contractions. Their Wigner--Yanase defect is at most nu_N/K and their weighted commutator defect is eta_(N,K)/K^2. The bounded N39 construction has fixed three scores and fixed parameter radius RK, so its uniform EB reconstruction error on the clipped family tends to zero. Given epsilon, choose K using (4), then choose a fixed upper defect/grid resolution in that construction. Its global joint-score grid has finite alphabet independent of N; reference spectral bins are summed into conditional decoder states and are not retained labels. Finally triangle inequality and contractivity transfer reconstruction to the original family at twice the clipping error.

This proves the general theorem. It is a sufficient criterion, not an iff characterization for arbitrary Gibbs models.

## 5. Explicit high-temperature local Hamiltonian corollary

Consider N spin-1/2 sites, fixed finite-range (or bounded few-body) interactions with uniformly bounded per-site operator strength,

H_N(lambda)=H_(N,inv)+lambda V_N,
V_N=sum_X v_X,
[H_(N,inv),J_i]=0 for i=x,y,z.

Assume all |lambda|<=lambda_0 and all N have interaction order <=q and per-site strengths bounded independently of N. Let B_(N,i)=i[V_N,J_i]; these are also sums of q-body Hermitian terms with bounded per-site strength. Choose one common strength g_* bounding H_N(lambda), V_N, each B_(N,i), and each J_i in the precise Kuwahara--Saito local-strength condition sum_(X contains v)||f_X||<=g_*. One may take g_* at least max(g_H,g_V,q g_V,1/2), enlarging it if the H decomposition uses a different q.

Fix

0<beta<beta_c=1/(8e^3 g_* q).

Kuwahara--Saito, 1906.10872v2, Theorem 1 equation (10), applies uniformly along the whole interval |lambda|<=lambda_0. We derive our own conservative concentration bound from that main theorem rather than relying on the displayed constant in their Corollary 1. For any of F=J_i,V_N,B_(N,i), let Fbar=sum_X ||f_X|| and Delta=beta_c-beta>0. Equation (10), after centering F and taking |tau|<=Delta/2, gives

log Tr omega exp[tau(F-Eomega F)] <=2 tau^2 Fbar/Delta.    (13)

The spectral range of F is at most 2Fbar, so every nonempty centered deviation event has x<=2Fbar. Choosing tau=x Delta/(4Fbar) is therefore legal and Chernoff gives

Pr_omega(|F-Eomega F|>=x) <=2 exp[-Delta x^2/(8Fbar)].    (14)

For x>2Fbar the probability is zero, so the same bound holds globally. For Fbar=0 the observable is constant and the conclusion is immediate. Since Fbar=O(N), integrating (14) gives

Var_omega(F)<=16 Fbar/Delta=O(N),

and the centered J_i/sqrt(N) have uniformly bounded exponential moments of every fixed order s>0. This establishes precisely the variance/tail premises used below, with conservative constants.

Let lambda_N->0 at any speed and omega_N proportional exp[-beta H_N(lambda_N)]. We check all three general assumptions explicitly.

**Approximate reference commutation.** In the energy eigenbasis, the scalar bound 1-sech(x)<=x^2/2 proves

||[sqrt omega,A]||HS<=(beta/2)||[H,A]||_(2,omega)          (8)

for Hermitian A. Here [H_N(lambda),J_i]=lambda[V_N,J_i]. Moreover

Tr omega_N B_(N,i)=i Tr omega_N[V_N,J_i]=0              (9)

because Tr omega_N[H_N(lambda_N),J_i]=0; for lambda_N=0 the desired defect is already zero. Gaussian concentration of B_(N,i) and (9) give Tr omega_N B_(N,i)^2=O(N). Therefore

nu_N<=C beta |lambda_N|->0.                            (10)

**Centered tails.** Gaussian concentration of J_i gives assumption (A) directly, whether or not its mean vanishes exactly.

**Vanishing macroscopic spin.** For finite N the Gibbs derivative identity is

d/dlambda [Tr omega_(N,lambda) J_i/N]
 =-(beta/N) Cov_(KM,omega_(N,lambda))(J_i,V_N).         (11)

The Kubo--Mori covariance is a positive inner product and its variance is bounded by ordinary centered variance (scalar logarithmic mean <= arithmetic mean). Thus Gaussian concentration along the whole lambda interval yields a uniform bound on the absolute derivative in (11). At lambda=0 exact SU(2) invariance forces Tr omega_(N,0)J_i=0. Integrating (11) shows

|Tr omega_N J_i|/N=O(|lambda_N|).

Combined with Var_omega(J_i)=O(N),

Tr omega_N J^2/N^2=O(1/N+lambda_N^2)->0.               (12)

If the Hamiltonians are time-reversal invariant, the mean is exactly zero and this last derivative argument is unnecessary, but time reversal is not required.

All hypotheses are now proved from explicit local-strength/high-temperature conditions. Consequently, for every fixed R,

rho_(N,b) proportional exp[-beta H_N(lambda_N)+b.J_N/sqrt(N)], ||b||_1<=R,

has asymptotically vanishing full-density EB reconstruction error and an eventually bounded finite classical alphabet for each fixed error request. In Hamiltonian units these are unknown uniform magnetic fields -b/(beta sqrt(N)). The fields have the fluctuation scale N^(-1/2), and N lambda_N need not vanish. Any lambda_N->0 speed is allowed. The infinite-temperature product reference gives a nontrivial local experiment at this scale; no universal lower susceptibility bound is proved here. The theorem does not require N lambda_N, sqrt(N)lambda_N or ||omega_N-I/2^N|| to vanish.

No necessary condition on lambda is claimed: some perturbations preserve the spin charges or yield classical families even for fixed lambda. Conversely a fixed nonzero one-body Zeeman perturbation gives a faithful nontracial iid qubit reference; a transverse one-parameter local rotation experiment has a positive EB floor by established strong qubit LAN, so the small-symmetry-breaking premise cannot simply be discarded in a uniform theorem.

## Scientific interface and remaining bottleneck

The exact known Hamiltonian, its invariant decomposition, all local terms, beta, and lambda_N are supplied. The channel does not learn them, simulate the Gibbs state efficiently, or preserve a purification. Joint score measurements/conditional reference preparation can be exponentially costly in N. The theorem certifies information preservation by a classical record, with all input-dependent labels counted; computational preparation is separate.

The broad generic local-Gibbs boundary remains open. Uniform central-limit moments or a vanishing tangent symplectic form alone do not establish strong classicalization. Approximate conserved charge + centered exponential tails + a vanishing macroscopic SU(2) spin is the fully stated sufficient mechanism here. The theorem's elementary combination may be new; priority has not been cleared, and it is not a historical-calibre advance by itself.

Primary source exact handles: https://arxiv.org/html/1906.10872v2 Theorem 1, eqs (8)--(10); our conservative Gaussian bound (13)--(14) above is derived from equation (10), not imported from the source Corollary 1; https://raw.githubusercontent.com/harjassand/astra-research-knowledge/main/web/pages/d-121a7c06024874b4.html sections 2.1--2.3 (bounded candidate construction); https://arxiv.org/html/quant-ph/0512075 Theorem 1.1 (fixed nontracial obstruction); https://arxiv.org/html/quant-ph/0606213 Lemma 5.5 (modular sufficient algebra).

### Explicit fixed-anisotropy counterexample for the same Gibbs local-field family

Take H_(N,inv)=0 and H_N=-c sum_i Z_i, c>0 fixed, so a=beta c and r=tanh(a)>0. For the one-parameter field family,

rho_(N,b)=[exp(aZ+bX/sqrt(N))/(2 cosh sqrt(a^2+b^2/N))]^(tensor N), |b|<=R.

The single-site state has polarization r_(N,b)=tanh sqrt(a^2+b^2/N)=r+O_R(N^-1) and direction angle theta_(N,b)=arctan[b/(a sqrt(N))]. Replace its polarization by the fixed r while retaining that direction. The one-copy relative entropy of these matching-direction states is O_R(N^-2), because both eigenvalues remain uniformly away from zero. Product Pinsker gives uniform N-copy trace distance O_R(N^-1/2). The angle equals b/(a sqrt(N))+O_R(N^-3/2), whose negligible correction is likewise harmless. Thus strong qubit LAN identifies the limit with a real nonzero-displacement family of a faithful thermal oscillator. The compactness/no-broadcasting proof in dimer_counterexample.md gives a positive uniform EB floor. This is a fixed-lambda counterexample to dropping the vanishing-symmetry-breaking premise uniformly, not necessity for every perturbation V.


### Exact source-error ledger: concentration coefficient

The displayed completion of the square in Kuwahara--Saito, 1906.10872v2, equation (17), is algebraically inconsistent: the expression -tau x+c_beta Fbar tau^2 is not equal to c_beta Fbar[tau-x/(c_beta Fbar)]^2-x^2/(c_beta Fbar). The square center needs a factor 1/2, and the resulting Gaussian exponent has a factor 1/4 relative to their displayed Corollary 1 coefficient if one uses only that MGF bound. We do not infer that their qualitative concentration theorem fails; we use the conservative bound derived directly from Theorem 1 equation (10). The beta threshold and all O(N) variance/uniform-exponential-tail conclusions used here are unchanged. This is an apparent source algebra typo, explicitly retained as an audit issue.
