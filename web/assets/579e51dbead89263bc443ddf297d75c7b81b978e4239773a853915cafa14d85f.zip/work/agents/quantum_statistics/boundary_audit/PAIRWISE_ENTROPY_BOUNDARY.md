# Pairwise intrinsic classicality does not replace uniform metric entropy

7 October 2026. Independent algebra/proof audit. Status: internally derived theorem with established Gaussian-fidelity and EB-benchmark inputs; external correctness/priority review remains open. No new agents used. Infinite-dimensional issues are removed below by explicit finite Fock cutoffs and finite subsets.

## Strongest statement

There are finite-dimensional finite experiments F_n such that

sup_(rho,sigma in F_n) [F_root(rho,sigma)-Tr(sqrt(rho)sqrt(sigma))] ->0,

but

inf_(Phi EB) sup_(rho in F_n) T(Phi(rho),rho) ->1.

Here T=||.||_1/2, F_root(rho,sigma)=||sqrt(rho)sqrt(sigma)||_1, and the affinity is the unsquared trace overlap Tr(sqrt(rho)sqrt(sigma)). Phi ranges over every measure-and-prepare channel with any classical alphabet, arbitrary collective operations and preparations. Thus vanishing of this supremum pairwise fidelity/affinity defect alone is insufficient for dimension-free classical reconstructibility. Each experiment is finite and hence compact; its cardinality and covering entropy grow. This does not refute a criterion which also imposes uniform metric-entropy control.

## 1. Exact thermal formulas and ordering

For mean photon number n>0 define

theta_n=(n+1)^(-1) sum_(k>=0)[n/(n+1)]^k |k><k|,
rho_alpha=D(alpha) theta_n^(tensor m) D(alpha)^*, alpha in C^m,
s=||alpha-beta||_2^2.

Primary input: Banchi--Braunstein--Pirandola, arXiv:1507.01941, equation (8) explicitly defines ROOT fidelity; equation (9) gives

F_root=F_0(V,V) exp[-delta_u^T(2V)^(-1)delta_u/4].

Our covariance is V=(n+1/2)I_(2m), equal-covariance factor F_0=1, and the displacement convention D(alpha)=exp(alpha a^dagger-conjugate(alpha)a) has ||delta_u||^2=2s. Therefore

F_root(rho_alpha,rho_beta)=exp[-s/(4n+2)].                (1)

No square of fidelity is used.

For affinity put q=n/(n+1), q_half=sqrt(q), and

M=q_half/(1-q_half)=n+sqrt(n(n+1)),
D=2M+1=(sqrt(n+1)+sqrt(n))^2.

The square root of the thermal density is exactly

sqrt(theta_n)=sqrt(D) theta_M.

For example, compare their geometric Fock coefficients: sqrt(1-q)/(1-sqrt(q))=sqrt((1+sqrt(q))/(1-sqrt(q)))=sqrt(D).

The direct thermal overlap is

Tr[theta_M D(delta) theta_M D(delta)^*]
 =(2M+1)^(-1) exp[-|delta|^2/(2M+1)].

This follows by integrating the coherent-state thermal representation; for two independent complex Gaussian coherent amplitudes of variance M, their difference has variance 2M, and the coherent overlap is exp(-|z-w-delta|^2). The elementary Gaussian integral gives the displayed expression. Product multiplication then cancels all D^m normalization factors, yielding

A(rho_alpha,rho_beta):=Tr[sqrt(rho_alpha)sqrt(rho_beta)]
 =exp[-s/D].                                          (2)

Since D<4n+2, affinity <= root fidelity as required. For n=0 the limiting formulas give root fidelity exp(-s/2), affinity exp(-s); the construction below uses n>=2.

## 2. Uniform pairwise gap, independent of mode count

The exact identity

(4n+2)-D=1/D

follows by multiplying (2n+1-2sqrt(n(n+1)))(2n+1+2sqrt(n(n+1)))=1. Hence

kappa=(4n+2)/D=1+D^(-2)>1.

Writing x=s/(4n+2), the gap is

Delta(s)=exp(-x)-exp(-kappa x).

Its unique positive maximizer has x_*=log(kappa)/(kappa-1), and

sup_(s>=0) Delta(s)
 =(kappa-1) kappa^[-kappa/(kappa-1)]
 <=(kappa-1)/e=1/(eD^2)
 ~1/(16 e n^2).                                      (3)

The bound uses kappa log(kappa)/(kappa-1)>=1, equivalently log(kappa)>=1-1/kappa. Crucially, (3) has no m factor: all mode contributions have already combined into s. It holds uniformly on all displacement vectors and on every restricted subset.

Thus the complete displaced thermal experiment is pairwise intrinsically classical in this exact defect as n->infinity, even if m grows much faster than n^2.

## 3. Whole-experiment reconstruction remains maximally nonclassical

The independently audited arbitrary-collective EB benchmark is

B(m,n)=inf_(Phi EB) sup_alpha T(Phi(rho_alpha),rho_alpha)
 =T(theta_n^(tensor m),theta_(n+1)^(tensor m))
 =TV(NB_m(n),NB_m(n+1))
 >=1-8(n+1)^2/m.                                     (4)

The lower bound handles entangled seeds, correlated prepared outputs and arbitrary joint measurements through the covariant PPT amplifier representation and total-photon stochastic domination; it is not a tensor-product optimality assumption. See growing_dimension/gaussian_eb_lower/EXACT_MULTIMODE_EB_BENCHMARK.md.

Take n to be integer and m=n^3. Then the supremum pair defect is O(n^-2), while B(m,n)->1 by (4).

For each fixed m,n, the previous thermal-splitting localization proof gives

sup_(R<infinity) B_R(m,n)=B(m,n),

where B_R is the minimax EB risk on the compact displacement set max_j|alpha_j|<=R. Choose finite R_n so

B_(R_n)(n^3,n)>=B(n^3,n)-1/n,

and enlarge it if necessary so R_n>=sqrt(n). The gap bound (3) continues to hold. This gives compact experiments at every stage; their compactness constants are not uniform.

The full all-displacement set has no finite epsilon net for any sufficiently small fixed epsilon: spacing alpha along one mode at increasingly separated points makes root fidelity tend to zero and trace distance tend to one. Thus passing to bounded boxes matters before a finite-dimensional truncation.

## 4. Finite-dimensional Fock cutoff

On the radius-R_n box, the total photon expectation is bounded uniformly by

E_n=m n+m R_n^2.

Choose the integer cutoff K_n so E_n/(K_n+1)<=p_n:=n^-12. Let P_n project onto total Fock occupation <=K_n. Its finite rank is binom(m+K_n,K_n). Markov gives leakage

ell_alpha=1-Tr(P_n rho_alpha)<=p_n.

The normalized finite-dimensional states

hat(rho)_alpha=P_n rho_alpha P_n/(1-ell_alpha)

satisfy

T(hat(rho)_alpha,rho_alpha)<=sqrt(ell_alpha)<=sqrt(p_n). (5)

To prove (5), take a purification of rho and postselect the projection P on its system component. Its overlap with the original purification is sqrt(1-ell), so root fidelity is at least sqrt(1-ell); Fuchs--van de Graaf gives the result.

Define the CPTP compression into P_n H,

C_n(X)=P_n X P_n+Tr[(I-P_n)X] tau_0,

where tau_0 is any known state supported in P_n. For each family state,

C_n(rho_alpha)=(1-ell_alpha)hat(rho)_alpha+ell_alpha tau_0,

so T(C_n(rho_alpha),hat(rho)_alpha)<=ell_alpha. If a finite-dimensional EB channel Phi recovers all hat(rho)_alpha with error e, compose C_n with Phi and the output embedding. This is an EB channel on the original Fock space, and its error on each rho_alpha is at most

e+p_n+sqrt(p_n).

Therefore the finite-dimensional compact family has minimax risk

E_hat >=B_(R_n)(m,n)-p_n-sqrt(p_n)
 >=1-8(n+1)^2/n^3-1/n-n^-12-n^-6 ->1.                 (6)

This does not rely on an infinite-dimensional normality assumption for the finite-dimensional assertion; the known normal EB benchmark only serves as the lower-bound comparison.

## 5. Pairwise defect survives the cutoff uniformly

Powers--Størmer gives ||sqrt(rho)-sqrt(sigma)||_2<=sqrt(||rho-sigma||_1). Schatten Holder and the triangle inequality imply, when T(rho,hat rho),T(sigma,hat sigma)<=t,

|F_root(rho,sigma)-F_root(hat rho,hat sigma)|<=2sqrt(2t),
|A(rho,sigma)-A(hat rho,hat sigma)|<=2sqrt(2t).

For root fidelity, apply the trace-norm triangle inequality to sqrt(rho)sqrt(sigma); for affinity apply the HS inner product triangle inequality. Both square roots have HS norm one. Consequently

|Delta(rho,sigma)-Delta(hat rho,hat sigma)|<=4sqrt(2t).

Here t=sqrt(p_n)=n^-6, so

sup_(alpha,beta in box) Delta(hat rho_alpha,hat rho_beta)
 <=1/(eD^2)+4sqrt(2)n^-3 ->0.                         (7)

The scalar gap is always nonnegative by polar decomposition; no absolute-value convention is needed in its definition.

## 6. Finite experiments and explicit entropy failure

The finite-dimensional projected family is compact: displacement-to-density is trace-norm continuous, the box is compact and all retained masses are uniformly at least 1-p_n. Choose a finite delta_n=1/n trace-distance net. For every channel, its reconstruction error is 2-Lipschitz in the input state, by contractivity plus the triangle inequality. Thus the EB minimax risk on the finite net is at least E_hat-2/n. Combining (6)--(7), this already proves the strongest finite-experiment statement.

We can make divergence of covering entropy explicit rather than infer it indirectly. Because R_n>=sqrt(n), the original box includes alpha in {0,sqrt(n)}^m. Greedy binary coding gives a set C_m of exponentially many binary strings with Hamming distance at least m/4, for example

|C_m|>=2^m / sum_(j<=floor(m/4)) binom(m,j)
 >=exp[m(log 2-h(1/4))-o(m)],

h(x)=-x log x-(1-x)log(1-x).

For distinct codewords, s>=n m/4, and n>=2 gives

F_root<=exp[-n m/(4(4n+2))]<=exp(-m/20).

Fuchs--van de Graaf yields original pairwise T>=1-exp(-m/20). Projected states remain separated by

T(hat rho_alpha,hat rho_beta)>=1-exp(-m/20)-2n^-6.

Add these projected packing states to the finite net; adding states cannot reduce its minimax risk, and bound (7) still applies to every pair. For every fixed epsilon<1/2, eventually one epsilon ball contains at most one packing state. Hence the epsilon covering number is at least exp(c m) for a positive constant c, and m=n^3. Uniform covering entropy fails decisively.

All sets in the strongest statement are finite, and all their states live in a finite Hilbert space. Their finite dimensions, R_n and net cardinalities can be enormous; localization radii are existential. No feasible computation, archive-size optimum or accessible preparation claim is made.

## Exact inference and novelty boundaries

This disproves a dimension-free implication from pairwise root-fidelity/affinity-gap convergence alone to strong EB reconstruction. It is fully compatible with a theorem that also requires uniform metric entropy or a fixed-dimensional compact model. The many independently displaced thermal modes amplify reconstruction noise while the maximum pairwise intrinsic defect remains small; pairwise closeness in that defect is not a uniform statistical experiment comparison.

The Gaussian fidelity formula, thermal EB benchmark, gentle projection, and finite-net arguments are established inputs/elementary consequences. Priority for this particular combined counterexample is unresolved, and no historical novelty is claimed.

Primary citations: https://arxiv.org/html/1507.01941 equations (8)--(9) for exact ROOT fidelity convention; https://arxiv.org/html/1004.1843 Theorem IV.1 and covariance/amplifier proof for the one-mode benchmark mechanism; https://arxiv.org/html/0808.2260 Appendix A Lemmas 2--4 for finite-mode Weyl/PPT characterization. The independently written exact arbitrary-m benchmark is growing_dimension/gaussian_eb_lower/EXACT_MULTIMODE_EB_BENCHMARK.md. No current assertion is taken from unverified memory.
