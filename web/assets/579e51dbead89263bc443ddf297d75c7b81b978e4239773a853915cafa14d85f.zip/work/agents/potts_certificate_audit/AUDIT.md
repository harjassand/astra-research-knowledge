# Four-state Potts certificate audit and heterogeneous-edge repair

Pinned primary source: OpenAI `math`, commit `adc7f1241b42e322a6451854ab7e4b4c146bf78a`, folder `preprints/The-Reconstruction-Threshold-for-the-Ferromagnetic-Four-State-Potts-Model-October-5-2026/`. Retrieved selected `build/sections/*.tex` and `verification/checks/{small_polynomials.py,certificate.cpp}` with `gh api` raw accept headers. Local copies are in `sources/`.

## Exact certificate and class scope

Companion Proposition 3.2 is `build/sections/03-cone.tex`, label `prop:cone-closure`. Its class is **symmetric** posterior laws with `E H >= 0`, for the explicit degree-six polynomial in equation `polynomial-table`. Closure holds under all channel parameters `t in [0,1]`, conditionally independent Bayes products with the correct change-of-law weight `z`, and observed mixtures whose label is independent of the input. Arbitrary symmetric experiments are not automatically in the class.

The proof reduces to pointwise permutation-averaged rational inequalities over the entire two-simplex product; interpolation in Type P merely proposes a rational polynomial, and the independently checked remainder coefficients certify its actual error everywhere. Type T uses a global Taylor lower bound for `z^-k` on `z>0`; no power-series radius assumption is used. The continuous extension at `z=0` is justified by `N/z^k = z A(P)` or `z H(P)` and bounded posterior polynomials.

The standard-library Python scalar verifier passed exactly and reproduces minima `19/50, 0, 87/1000, 0` for `H+1/2,F,G,(3-Euler)H`, as well as all 24 coordinate actions. Full JSON is `scalar_check.json`.

The original C++ source requires GCC's nonportable `bits/stdc++.h`. A local copy `certificate_portable.cpp` replaces that include with explicit standard headers only; arithmetic and tests are unchanged. An existing local Boost 1.87 source tree was used, with assertions enabled. Exact row (a) replay passed with `done 4479 19 lp=2074 lt=166`, matching the manuscript. Exact row (b) replay also passed with `done 1935 20 lp=871 lt=97`, matching the manuscript. Both processes exited with code 0. Thus both global two-posterior sign certificates have been replayed successfully, in addition to the scalar certificates.

## Exact counterexample to naive arbitrary-edge composition

Let the tree be a single infinite ray, and take edge parameters `lambda_n = 1 - 2^(-n-1)` for `n>=1`. Every edge is strictly ferromagnetic and noisy. The product `beta_n = product_{j<=n} lambda_j` is at least `1 - sum_{j<=n} 2^(-j-1) >= 1/2`. The level-n experiment is one Potts channel with parameter `beta_n`, so expected TV is `3 beta_n/4 >= 3/8` and reconstruction holds.

If one merely substitutes `R_n = (product_{j<=n} lambda_j^2)^(-1)` into the original L3 potential `sum (R_n theta_n)^2`, every nonzero flow has constant `theta_n=theta` and the potential is infinite because `R_n>=1`. Thus that naive capacity is zero. The companion cone permits all these edges; the failure is in translating information recursion to the unchanged capacity.

The natural repaired edge energy is

`sum_e (1-lambda_e^4) (theta_e / r_e)^2`, where `r_e=product_{f on root-to-e} lambda_f^2`.

On a ray it telescopes: `(1-lambda_n^4)/r_n^2 = 1/r_n^2 - 1/r_{n-1}^2`. For constant lambda in `(0,1)` it is a constant multiple of the original energy.

## Universal local moment estimates: no channel smoothing required

Write `x=Lp,y=Lq,s=x.y,z=1+s`, and `N=x+y+R`, with `R_i=x_j y_k+x_k y_j`. The Bayes product gives `N=LU` and each `|N_i|<=z`, because `U` has nonnegative entries summing to `z`. Thus, for `z>0`,

`|N_1 N_2 N_3| * s^2(3+2s)/z^2 <= z s^2(1+2z) <= 36 s^2`.

Here `0<=z<=4`, and the singular boundary extends continuously. Since `E s^2=ab/3`, the third-moment denominator remainder is at most `12ab`, uniformly over all symmetric posterior laws. The remaining mixed polynomial `N_1N_2N_3(1-2s)` has finite coefficient norm; a direct polynomial expansion gives 364 after discarding pure and marginal-degree-one terms. Therefore

`h(mu star nu) <= h(mu)+h(nu)+376 m(mu)m(nu)`

for **all** symmetric posterior laws, even without an edge channel or a posterior coordinate lower bound. The companion capacity manuscript's quadratic lower bound with constant 7 already needs no smoothing: its exact nonnegative remainder is valid by the same continuous extension. Hence `C=376` is a valid common absolute constant for both local estimates.

A simpler entirely symbolic constant is `C=460`: each `N_i` has coefficient norm 4, and `1-2s` has coefficient norm 7, so the mixed polynomial coefficient norm is at most `4^3*7=448`; add the same remainder bound 12. The parent can use 460 without depending on the explicit expansion count.

## Degree-free renormalization for necessity

The capacity manuscript's `B^3` estimate is unnecessary. If `a=m(mu)`, `b=m(nu)`, and `u=m(mu star nu)`, Proposition 3.2 and Jensen give `u<=a+b-c ab(a+b)`, `c=1/1000`. Set `f(m)=m+K m^3` with `0<K<=c/3`. Since also `u<=a+b`,

`f(u)<=a+b-c ab(a+b)+K(a+b)^3=f(a)+f(b)+(3K-c)ab(a+b)<=f(a)+f(b)`.

Iterate this inequality over all child branches, using class closure for every partial product. With `r_e=lambda_e^2`, the resulting labels `y_v=f(m_v)` satisfy

`y_v<=sum_e r_e y_child-K sum_e r_e(1-r_e^2)m_child^3`.

All sums and limit passages are finite at a fixed vertex on any locally finite tree. Thus K can be universal; there is no need for a uniform bound on offspring. Since `m<=3`, take `delta0=K/(1+9K)^3` and obtain

`y_v<=sum_e r_e y_child / sqrt(1+2delta0(1-r_e^2)y_child^2)`.

The standard multiplicative flow construction then gives the repaired energy with weight `(1-r_e^2)`. The parent has been sent this reduction; its final theorem must still be checked as a whole.

## Quadratic Lyapunov controlling heterogeneous branching losses

This calculation is supplied to the parent for incorporation into a complete sufficiency proof. On a flow path let `X=theta/r` at the current vertex, `p` be the selected child flow fraction, and `lambda` its edge parameter. The next profile and accumulated ancestor influence satisfy

`X' = p X/lambda^2`, `a' = lambda [a+(1-p)X]`.

Choose `F(X,a)=X^2+aX+c a^2`, `0<c<1/2`, and let `S2=sum_child p^2`, `S3=sum_child p^3`. Conditional expectation for noiseless edges is exactly

`E[F'-F] = -(1-2c)(1-S2)aX - [(1-S2)-c(1-2S2+S3)]X^2`.

Since `S3<=S2`, this is at most

`-(1-2c)(1-S2)aX -(1-c)(1-S2)X^2`.

For a general edge, compare with that same transition at lambda=1. Including its selection probability p, the extra term is exactly

`p^2 (lambda^-1-1) X [a+(1-p)X] - c p (1-lambda^2)[a+(1-p)X]^2 + p^3(lambda^-4-1)X^2`.

Complete the square in the bracketed variable. The first two terms are at most

`p^3 (lambda^-1-1)^2 X^2/[4c(1-lambda^2)] <= p^3(lambda^-4-1)X^2/(4c)`.

The last inequality follows directly from

`(lambda^-1-1)^2 / [(1-lambda^2)(lambda^-4-1)] = lambda^2/[(1+lambda)^2(1+lambda^2)] <= 1`.

At `c=1/4` this yields

`E[F'-F] <= -(1/2)(1-S2)aX -(3/4)(1-S2)X^2 + 2 E[(1-lambda^4)X'^2]`.

With `a_0=0`, nonnegativity of F telescopes to

`E sum_j (1-S2_j)(a_j X_j+X_j^2) <= 2 X_0^2 + 4 E sum_j (1-lambda_j^4)X_j^2`.

It also gives `E a_n <= 2 sqrt(X_0^2+2 E energy)`, uniformly in n, because `F>=a^2/4`. Thus terminal third moments with `h_terminal/X_terminal<=1` contribute only order epsilon under a scaled flow. The calculation handles lambda=1 by continuity; lambda=0 edges must carry zero flow and can be pruned.

The coefficient 2 can be sharpened to `9/8` using

`(1+lambda)^2(1+lambda^2)-8lambda^2=(1-lambda)^2(lambda^2+4lambda+1)>=0`.

The standalone `lyapunov_exact.py` verifies the transition identity and the stronger bound on 3,660 rational fixtures. These are implementation diagnostics supporting the written algebra; the algebra is the general proof.

## Sparse reveals and forbidden transfers

An observed, input-independent reveal/erasure label with probability gamma produces posterior law `gamma mu_reveal+(1-gamma)mu_uninformative`, so it is in the preserved class. Fixed terminal channel degradation also remains in the class. This licenses moment inequalities, but does not establish reconstruction for arbitrary sparse reveal schedules: if `gamma_n |L_n| ->0`, then probability of any reveal tends to zero and expected root TV does too. Full-boundary positive capacity is therefore insufficient for unrestricted schedules.

Input-dependent reveal masks or color-specific observations need a fresh symmetry/class check. Negative channel parameters are outside the closure proof; an exact counterexample from the independent child is informative law passed through lambda=-1/3, which has `E H=-1409/24300<0`.

Symmetry alone is insufficient even for subadditivity. Let mu be the uniform orbit law of `p=(1/2,1/2,0,0)`, corresponding to observing a uniformly chosen two-subset containing the input. Then `m(mu)=1`, `E H=-3/25`, and two independent copies have combined posterior of the same two-subset with probability 1/3 and a singleton with probability 2/3. Consequently `m(mu star mu)=7/3>2`. This exact example rules out replacing the cone condition by symmetry for arbitrary terminal experiments.

Even the cone does not supply a uniform scalar *upper* bound of cubic order on information loss. Let `mu_t=t mu_reveal+(1-t)mu_uninformative`, with each reveal flag observed. Then `m(mu_t)=3t`, while `m(mu_t star mu_t)=3(2t-t^2)` because the combined experiment reveals iff at least one flag reveals. The information loss is `3t^2`, whereas `m(mu_t)^2[2m(mu_t)]=54t^3`. No finite universal constant C bounds the former by the latter as t tends to zero. The companion gives a cubic lower bound on the saving, not a cubic upper loss bound for every cone law. The separate third-moment statistic in the sufficiency proof is essential.

## Remaining proof obligations

The parent must finish the weighted-capacity sufficiency derivation, verifying the branch-moment recursions and converting them to the flow-path sums before citing the Lyapunov bound. The precise sequential-product bookkeeping is as follows. Write `b_j=lambda_j^2 m_child<=p_j X`, `h'_j=lambda_j^3 h_child=lambda_j p_j X k_child`, `S=sum b_j`. Then

`h_v<=sum_j h'_j+C sum_{i<j} b_i b_j`,

`D_v<=C sum_j h'_j(S-b_j)+C^2 S sum_{i<j}b_i b_j`.

Consequently

`k_v<=E_flow[lambda k_child]+(C/2)X(1-S2)`,

`D_v/X<=C X E_flow[lambda(1-p)k_child]+(C^2/2)X^2(1-S2)`.

Unfolding these bounds yields relative total information loss at most

`C E[a_n k_n]+(C^2/2)E sum_j(a_j X_j+X_j^2)(1-S2_j)`.

For `k_n<=1`, the Lyapunov bounds give the uniform upper bound

`2C sqrt(X_0^2+2 energy)+C^2(X_0^2+2 energy)`.

A fixed scaled flow makes this arbitrarily small. These local estimates do not depend on offspring degree; only each individual product needs finitely many inputs. This document supplies exact algebraic ingredients and a certificate audit; it does not independently assert prior-art novelty or claim the parent's final theorem has been audited as a whole.

For completeness, the fixed terminal degradation is valid under the new energy. Let `R_i=1/r_i` on a positive-flow path and `Theta_i` be its nonincreasing entering flow, with root mass M. Then

`sum_{j<=i}(R_j^2-R_{j-1}^2)Theta_j^2 >= Theta_i^2(R_i^2-1) >= X_i^2-M^2`.

Thus if `Theta=epsilon theta` and the unscaled ray energy is at most 1, every profile satisfies `X_i^2<=epsilon^2(|theta|^2+1)`. Choose a fixed epsilon so every `t_i=sqrt(X_i/3)<=1`. Then `m_terminal=X_i` and `h_terminal/X_i=t_i/3<=1`, and the relative loss bound is at most

`2C epsilon sqrt(|theta|^2+2)+C^2 epsilon^2(|theta|^2+2)`.

It can be made less than 1/2 independently of observation depth, edge contraction bounds, or offspring bounds.
