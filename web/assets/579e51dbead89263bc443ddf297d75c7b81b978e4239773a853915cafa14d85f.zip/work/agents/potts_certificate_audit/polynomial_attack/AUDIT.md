# Independent pointwise audit of release229

Source pin: OpenAI/math `adc7f1241b42e322a6451854ab7e4b4c146bf78a`.
Primary paper: [The Reconstruction Threshold for the Ferromagnetic Four-State Potts Model](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/The-Reconstruction-Threshold-for-the-Ferromagnetic-Four-State-Potts-Model-October-5-2026/four-state-potts.pdf).
Decisive locations in supplied source: `03-cone.tex`, Proposition `prop:polynomial-inequalities`, equations `A-product`, `H-product`, `H-scaling`; `02-experiments.tex`, Lemma `lem:bayes-product`; `05-polynomial-certificates.tex`, Lemma `lem:scalar-checks` and `eq:scalar-homogenization`.

## Result and scope

No stable counterexample was found to any asserted pointwise inequality.
An independent symbolic homogeneous-coefficient reconstruction reproduced all four scalar minima reported in the source, and gave three stronger scalar inequalities plus a quantitative channel inequality. The rational two-posterior inequalities were checked only on finite numerical/exact fixtures by this worker. Their global proof still requires the source two-variable certificate audit/replay conducted separately by the parent team.

## Exact scalar strengthening

For every p in the four-state simplex, set x=Lp and Q=(3-E)H, with E the coordinate Euler operator. The independent coefficient certificate proves

    H(p) >= -3/25,
    F(p) >= (3/10) A(p),
    G(p) >= 613/71500,
    Q(p) >= A(p)^2/20.

The first inequality is sharp at p=(1/2,1/2,0,0); the second coefficient is sharp because F(e)=9/10 and A(e)=3. The G and Q constants are certificate bounds, not asserted optimal pointwise constants.

Explicitly,

    Q = A^2/10 + 3C/20 - 3AB/5 + 3A^3/50 - 21AC/100 + 153B^2/100.

Proof certificate: restrict to ordered p, use barycentric X at vertices e1,(e1+e2)/2,(e1+e2+e3)/3,u, and replace coordinates by

    x=(X0+X1+X2/3, X0+X2/3, X0-X2/3).

Homogenize H+3/25 and Q-A^2/20 to degree 6, and F-3A/10 to degree 5. All ordinary monomial coefficients are nonnegative. For G at degree 14 the minimum normalized Bernstein coefficient is 613/71500 at index (9,0,0,5); subtracting (613/71500)(sum X)^14 leaves every coefficient nonnegative. Permutation invariance supplies the whole simplex. Full rational coefficients are saved in `scalar_exact_certificates.json`; `scalar_exact.py` recreates them from the polynomial formulas and the elementary homogenization identity, without importing the release verifier.

Since d[t^-3 H(tx)]/dt=-t^-4 Q(tx), the Q bound gives

    H(tx) >= t^3 H(x) + (1/20)t^3(1-t)A(x)^2,   0<=t<=1.

Thus, for an input cone law with h=E H>=0,

    h_after_channel >= lambda^3 h + (1/20)lambda^3(1-lambda)E A^2.

This is strict if 0<lambda<1 and E A^2>0.

Combined with the source product inequalities, two cone laws having moments a=E_mu A,b=E_nu A,h_mu=E_mu H,h_nu=E_nu H satisfy the conditional recurrences

    E A_product <= a+b -(3/10)(h_mu b+a h_nu)
                    -(E_mu A^2 b+a E_nu A^2)/1000,
    E H_product >= (613/71500)(h_mu+h_nu).

These are direct consequences of the source product assertions plus the independently checked scalar certificates, not a newly certified tree theorem.

For an independently observed reveal/erasure mixture of probability theta,

    E A=3theta, E A^2=9theta, E H=13theta/100,
    E H_after_lambda = theta[lambda^3 -(27/20)lambda^4
                              +(9/10)lambda^5 -(21/50)lambda^6].

## Adversarial tests

`attack.py` uses independent formulas and all 24 permutations at every pair. Seed 229003; 166156 pair tests and 140000 scalar samples. The samples include Dirichlet alpha in {0.025,0.05,0.1,0.3,1,5,100}; support boundaries; the 34 ordered representatives of the resolution-12 probability lattice; and near-uniform perturbations down to 1e-5. Product minima at a uniform input were around 1e-16 below zero in floating point and are exact equalities. The numerical output is in `numerical_results.json`.

`rational_exact.py` uses Python Fraction arithmetic. All 595 unordered pairs of the resolution-12 ordered grid pass exactly, including denominator-zero support cases. Exact perturbations of uniform posteriors down to 1e-12 also pass. This rules out the particular floating cancellation artifacts, not every nearby direction. Results are in `rational_exact_results.json`.

Define the candidate cubic-saving coefficient

    c(p,q)=[A(p)+A(q)-H(p)F(q)-F(p)H(q)-[zA(P)]]
           /[A(p)A(q)(A(p)+A(q))].

The source uses c=1/1000. The coarse exact grid minimum is 126352/13942125≈0.009062607 at p=q=(2/3,1/6,1/6,0). An independent diagonal family sweep and projected local attack find smaller c≈0.0080579026433 at

    p≈(0.6074153929,0.1308615357,0.1308615357,0.1308615357),
    q≈(0.6538910567,0.1730544717,0.1730544717,0).

The rational nearby fixture

    p=(3037/5000,1963/15000,1963/15000,1963/15000),
    q=(6539/10000,3461/20000,3461/20000,0)

has exactly

    c=3361433991220835213107303050126698401022703675481
      /417159907248448407381499264213476562500000000000000
     ≈0.0080579028157.

It is a rigorous upper bound on any universal replacement for the displayed pointwise c, and in particular refutes replacing 1/1000 by 1/100 in that exact A-product template. It does not refute a differently formulated integrated moment inequality.

The local normalized H-product margin search gave 548203/109350000≈0.0050132876086 at p=q=(1/3,1/3,1/3,0). This is only a tested upper bound on a putative universal normalized margin. Optimization results and exact fixture values are in `optimized_results.json` and `exact_fixtures.json`.

## Failure ledger and interface limitations

1. Near-uniform floating evaluation of the A residual suffers cancellation because its leading saving is far smaller than the individual second moments. Negative values of order 1e-18 or less, and absurd normalized ratios, were not treated as counterexamples. Fraction tests confirm positivity on independently chosen exact fixtures at still smaller scales.
2. The direct degree-14 coefficient test for G>=87/1000 fails: G-(87/1000) has a negative coefficient. This disproves that certificate attempt, not the stronger pointwise inequality. No claim about the true minimum of G is made.
3. Ferromagnetism is essential to this cone mechanism. An exact counterexample to extending cone closure to signed lambda is the informative law passed through lambda=-1/3: its posterior orbit is (0,1/3,1/3,1/3), and H=-1409/24300<0. This does not contradict the source, which assumes lambda in [0,1].
4. Numerical minima are exploratory, not global optimality certificates. The strengthened scalar bounds have full finite coefficient certificates, whereas no strengthened universal A-product constant has been proved.

## Strongest next attack

For the parent heterogeneous/sparse-reveal target, retain the extra h statistic and the strict channel increment rather than using only a=E A. These give explicit positive cone entry after a nontrivial ferromagnetic edge and exact sparse-reveal seed values. The remaining global task is to compose these recurrences with the tree-capacity criterion and independently audited two-posterior certificates. Do not infer a capacity or signed-channel result from the finite numerical tests.

Reproduction: run `python3 attack.py`, `python3 rational_exact.py`, `python3 scalar_exact.py`, and `python3 optimize.py` from this directory. Existing numpy and sympy were used; no installs, publication, push, or cloud jobs occurred.
