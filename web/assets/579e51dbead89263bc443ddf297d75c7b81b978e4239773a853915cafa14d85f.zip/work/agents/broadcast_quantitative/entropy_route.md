# Explicit dimension-free pair broadcasting bound by accessible information

Status: self-contained candidate proof, checked at the level of each channel and constant. It uses no ultraproduct, no spectrum-dependent entropy continuity, and no independent-copy claim. The key construction is an entanglement-breaking (measure-and-prepare) channel from one receiver of a sufficiently large broadcast tree.

## Claim

Write (T(a,b)=\tfrac12\|a-b\|_1), (F(a,b)=\|\sqrt a\sqrt b\|_1), and (A(a,b)=\operatorname{Tr}\sqrt a\sqrt b). Suppose a single CPTP map (B:\mathcal B(H)_*\to\mathcal B(H\otimes H)_*) obeys

\[
\max_{x\in\{0,1\},\,r\in\{1,2\}}T(B_r(\rho_x),\rho_x)\le\varepsilon,
\qquad \rho_0=\rho,\quad \rho_1=\sigma.
\]

For every integer (L\ge0), put (K=2^L) and

\[
\eta_L=L\varepsilon+\sqrt{\frac{\ln 2}{2K}}.
\]

Then there is an entanglement-breaking channel (E_L:H\to H), depending on the supplied pair, such that

\[
\max_x T(E_L(\rho_x),\rho_x)\le\eta_L.
\]

Consequently

\[
\boxed{\quad
\Delta(\rho,\sigma)=F(\rho,\sigma)-A(\rho,\sigma)
\le\min\left\{1,\ 2\sqrt{2\eta_L}\right\}
\quad}\tag{1}
\]

for every (L). For (0<\varepsilon\le1/2), choose (L=\lceil2\log_2(1/\varepsilon)\rceil) to get the explicit dimension-free modulus

\[
v(\varepsilon)=\min\left\{1,\ 2\sqrt{2\varepsilon\left(\lceil2\log_2(1/\varepsilon)\rceil+\sqrt{(\ln2)/2}\right)}\right\}.
\tag{2}
\]

Set (v(0)=0), and (v(\varepsilon)=1) for (\varepsilon>1/2). Thus (v(\varepsilon)=O(\sqrt{\varepsilon\log(1/\varepsilon)})\). The case (\varepsilon=0) follows by letting (L\to\infty) in (1).

## 1. Iterated broadcasting preserves each marginal up to (L\varepsilon)

Apply (B) to the input, then apply a fresh copy of (B) to every output, and repeat for (L) levels. This defines a channel (C_L:H\to H^{\otimes K}). No independence of the leaves is asserted. If (S_x=C_L(\rho_x)), contractivity of trace distance under each marginal map (B_r) proves inductively that every leaf (j) satisfies

\[
T((S_x)_j,\rho_x)\le L\varepsilon.\tag{3}
\]

Indeed a child marginal of a parent state (a) is (B_r(a)), and

\[
T(B_r(a),\rho_x)\le T(B_r(a),B_r(\rho_x))+T(B_r(\rho_x),\rho_x)
\le T(a,\rho_x)+\varepsilon.
\]

Local application of (B) to correlated parents does not change this marginal calculation.

## 2. Find a leaf with little *new* binary-label information

Draw (X\in\{0,1\}) uniformly and prepare (S_X). Measure leaves sequentially in some fixed order, choosing the two-outcome POVM on leaf (j) adaptively as follows. Given a previous outcome history (h=(y_1,\dots,y_{j-1})) of positive mixture probability (p_h), let (q_x=P(X=x\mid h)), and let (\tau_x^h) be the conditional state of leaf (j). (For zero conditional probability, choose the unused state arbitrarily.) Use the Helstrom projector onto the positive part of (\tau_0^h-\tau_1^h). Its two outcome laws (P_0^h,P_1^h) have

\[
T(P_0^h,P_1^h)=T(\tau_0^h,\tau_1^h)=:t_h.
\]

Define (d_h=2q_0q_1t_h=q_0q_1\|\tau_0^h-\tau_1^h\|_1). Directly expanding the two-by-two classical table gives

\[
T(P_{XY_j\mid h},P_{X\mid h}P_{Y_j\mid h})=d_h.
\]

Pinsker's inequality in nats gives

\[
I(X:Y_j\mid h)
=D(P_{XY_j\mid h}\|P_{X\mid h}P_{Y_j\mid h})\ge2d_h^2.
\]

Therefore, with (g_j=I(X:Y_j\mid Y_{<j})),

\[
g_j\ge2\sum_h p_h d_h^2.\tag{4}
\]

All the adaptive POVMs together form one legitimate sequential measurement on (S_X). The classical chain rule and the binary prior give

\[
\sum_{j=1}^K g_j=I(X:Y_1\cdots Y_K)\le H(X)=\ln2.
\]

Choose a leaf (j) with (g_j\le(\ln2)/K). No assumption about conditional independence of its state from preceding leaves was used.

## 3. Turn the preceding outcomes into a measure-and-prepare channel

Perform the same preceding-leaf measurements on (C_L(a)) for an arbitrary input (a), stopping just before leaf (j). Let (M_h) be the induced input POVM effect for outcome (h). For each history of positive mixture probability define the fixed preparation state

\[
\xi_h=q_0\tau_0^h+q_1\tau_1^h.
\]

Choose any state for a zero-probability history. The channel

\[
E_L(a)=\sum_h\operatorname{Tr}(M_h a)\xi_h
\]

is entanglement breaking. The (j)-th leaf marginal of (S_x) decomposes as (\sum_h p(h\mid x)\tau_x^h). Because the prior is uniform, (p(h\mid x)=2p_h q_x). Also (T(\tau_x^h,\xi_h)=q_{1-x}t_h). Convexity and the triangle inequality, separately for **each** label, therefore give

\[
\begin{aligned}
T(E_L(\rho_x),(S_x)_j)
&\le\sum_h p(h\mid x)T(\xi_h,\tau_x^h)\\
&=\sum_h p_h(2q_0q_1t_h)
=\sum_h p_h d_h\\
&\le\sqrt{\sum_h p_h d_h^2}
\le\sqrt{g_j/2}
\le\sqrt{\frac{\ln2}{2K}}.
\end{aligned}\tag{5}
\]

This exact posterior identity avoids an unnecessary factor of two from converting a mean-label error into a worst-label error. Combining (3) and (5) gives the stated (\eta_L\).

## 4. An approximate entanglement-breaking fixed pair has a small gap

For any measure-and-prepare channel (E(a)=\sum_h\operatorname{Tr}(M_h a)\xi_h), set (p_h=\operatorname{Tr}(M_h\rho)) and (s_h=\operatorname{Tr}(M_h\sigma)). Fidelity monotonicity under the measurement gives

\[
F(\rho,\sigma)\le\sum_h\sqrt{p_hs_h}.\tag{6}
\]

The quantum affinity (A(a,b)=\operatorname{Tr}\sqrt a\sqrt b) is jointly concave and positively homogeneous (the (\alpha=1/2) case of Lieb concavity). Applied to the prepared states, this says

\[
A(E\rho,E\sigma)
\ge\sum_h A(p_h\xi_h,s_h\xi_h)
=\sum_h\sqrt{p_hs_h}.\tag{7}
\]

Powers–Størmer and Hilbert–Schmidt Cauchy–Schwarz imply, for any density matrices (a,a',b,b'),

\[
|A(a,b)-A(a',b')|
\le\|\sqrt a-\sqrt{a'}\|_2+\|\sqrt b-\sqrt{b'}\|_2
\le\sqrt{\|a-a'\|_1}+\sqrt{\|b-b'\|_1}.\tag{8}
\]

If (T(E\rho,\rho),T(E\sigma,\sigma)\le\eta), (6)–(8) yield

\[
F(\rho,\sigma)-A(\rho,\sigma)
\le A(E\rho,E\sigma)-A(\rho,\sigma)
\le2\sqrt{2\eta}.
\]

This proves (1) with (\eta=\eta_L\).

## Interface checks and limits

* The same original channel (B) is used at every node. The constructed (E_L) may depend on the supplied pair, which is allowed in a pairwise optimization.
* Sequential outcome histories arise from a physical POVM on the leaves. Conditioning on a history is only a proof device; the resulting (E_L) has fixed input POVM effects and fixed preparation states.
* The proof charges (L\varepsilon) for marginal error propagation. This logarithmic loss may be improvable, but (2) is explicit and dimension independent.
* Classical correlations among leaves are unrestricted; the information budget (I(X:Y_1\cdots Y_K)\le\ln2) holds regardless.
* The argument proves a stronger intermediate assertion: two-state approximate broadcasting yields an approximate entanglement-breaking reconstruction with the above dimension-free rate.

## 5. Finite-family extension and covering consequence

Let (\mathcal E=\{\rho_1,\ldots,\rho_m\}\) with (m\ge2\). Suppose the same (B\) broadcasts every state in (\mathcal E\) with worst marginal trace error at most (\varepsilon\). The broadcast tree still makes each of its (K=2^L\) leaf marginals (L\varepsilon\)-close to its input state.

Choose a uniform design label (X\in\{1,\ldots,m\}\). At history (h\) of the first (j-1\) sequential leaf measurements, write (q_x=P(X=x\mid h)\), let (\tau_x^h\) be the conditional state of leaf (j\), and put (\xi_h=\sum_xq_x\tau_x^h\). Define

\[
D_h=\sum_xq_x T(\tau_x^h,\xi_h).
\]

Choose an \(x_h\) that maximizes \(q_xT(\tau_x^h,\xi_h)^2\). The maximum is at least \(m^{-1}\sum_xq_xT(\tau_x^h,\xi_h)^2\ge D_h^2/m\). On leaf \(j\), use the two-outcome Helstrom measurement distinguishing \(\tau_{x_h}^h\) from \(\xi_h\). This is also the Helstrom measurement distinguishing \(\tau_{x_h}^h\) from the posterior mixture of all other labels, because their signed differences are positive scalar multiples. Write \(q=q_{x_h}\), \(u=\tau_{x_h}^h\), \(v=(\xi_h-qu)/(1-q)\), and \(t=T(u,v)\). When \(q=1\), \(D_h=0\) and the choice is immaterial. Let \(Z=\mathbf1_{\{X=x_h\}}\). Data processing and Pinsker applied separately to the two conditional outcome laws give

\[
\begin{aligned}
I(X:Y_j\mid h)&\ge I(Z:Y_j\mid h)\\
&=qD(P_u\|P_{\xi_h})+(1-q)D(P_v\|P_{\xi_h})\\
&\ge2\big[q(1-q)^2+(1-q)q^2\big]t^2\\
&=2q(1-q)t^2
=\frac{2q}{1-q}T(u,\xi_h)^2
\ge2qT(u,\xi_h)^2
\ge\frac{2D_h^2}{m}.
\end{aligned}
\]

Here \(P_{\xi_h}=qP_u+(1-q)P_v\), so its total variations from \(P_u,P_v\) are \((1-q)t,qt\), respectively. By the information chain rule there is a \(j\) with \(g_j=I(X:Y_j\mid Y_{<j})\le(\ln m)/K\), hence

\[
\sum_h p_hD_h
\le\sqrt{\sum_h p_hD_h^2}
\le\sqrt{\frac{m\ln m}{2K}}.
\tag{9}
\]

Measure the preceding leaves and prepare the fixed (\xi_h\), as in Section 3. With a uniform prior, (p(h\mid x)=mp_hq_x\). The mean of the (m\) label-wise reconstruction errors against leaf (j\) is at most (\sum_hp_hD_h\). Thus each individual label error is bounded by (m\sum_hp_hD_h\), and the resulting entanglement-breaking channel (E_{L,m}\) obeys

\[
\boxed{\quad
\max_{1\le x\le m}T(E_{L,m}(\rho_x),\rho_x)
\le L\varepsilon+m\sqrt{\frac{m\ln m}{2\cdot2^L}}.
\quad}\tag{10}
\]

This bound is deliberately conservative in (m\); the two-label posterior identity used in (5) gives a better constant and label dependence for (m=2\).

For (0<\varepsilon<1\), choosing

\[
L=\max\left\{0,\left\lceil\log_2\frac{m^3\ln m}{2\varepsilon^2}\right\rceil\right\}
\]

makes the second term in (10) at most (\varepsilon\), so the error is at most (\varepsilon(L+1)=O\!\left(\varepsilon\log(m/\varepsilon)\right)\) for fixed (m\) (more precisely (L=O(\log m+\log(1/\varepsilon))\)).

If an experiment (\mathcal F\) has a finite trace-distance (\delta\)-net (\mathcal E\subseteq\mathcal F\) of cardinality (m\), apply (10) to that net. For any (\omega\in\mathcal F\), choose (\rho_x\in\mathcal E\) with (T(\omega,\rho_x)\le\delta\). Contractivity of (E_{L,m}\) gives

\[
T(E_{L,m}(\omega),\omega)
\le2\delta+L\varepsilon+m\sqrt{\frac{m\ln m}{2\cdot2^L}}.
\tag{11}
\]

Thus uniform total boundedness of a sequence of experiments, together with vanishing one-to-two marginal broadcasting error, yields one entanglement-breaking reconstruction channel per experiment with vanishing worst-case error. To see the quantifiers, fix (\delta>0\), take its uniform finite net cardinality (m(\delta)\), let broadcasting error tend to zero in (11) while choosing (L\to\infty\) slowly enough that (L\varepsilon\to0\), and then let (\delta\to0\).
