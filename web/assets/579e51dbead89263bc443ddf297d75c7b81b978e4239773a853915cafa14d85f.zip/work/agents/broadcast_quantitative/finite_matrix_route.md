# Finite-matrix quantitative no-broadcasting route

Status: complete candidate proof, with explicit but weak dimension-free rate. This argument is independent of the ultraproduct proof. The information-gain construction developed separately gives a much stronger rate; this note records an elementary likelihood/Kadison route and its constants for audit.

## Statement

Let \(\rho,\sigma\) be arbitrary density matrices and let \(B\) be one CPTP map to two copies of the input space. Assume, for \(i\in\{\rho,\sigma\}\) and \(a=1,2\),
\[
 T(B_a(i),i)\leq\varepsilon,\qquad T(u,v)=\tfrac12\|u-v\|_1.
\]
Then \(\Delta(\rho,\sigma)=\|\sqrt\rho\sqrt\sigma\|_1-\operatorname{Tr}\sqrt\rho\sqrt\sigma\) obeys an explicit dimension-free modulus. One convenient choice is
\[
 v(0)=0,\qquad
 v(\varepsilon)=\min\left\{1,
 4\sqrt{2\left[4\varepsilon+
  (8\sqrt2+\tfrac12)\varepsilon^{1/6}\right]}\right\}
 \quad(\varepsilon>0).
\]
Thus \(\Delta\leq v(\varepsilon)=O(\varepsilon^{1/12})\). The modulus is very loose; its value here is that every step uses finite matrices and elementary trace-ideal estimates.

## 1. Bounded symmetric likelihood and Kadison

Put \(\omega=(\rho+\sigma)/2\), restrict the input to \(\operatorname{supp}\omega\), and write \(\rho\leq2\omega\). The symmetric logarithmic derivative score \(R\) is the unique self-adjoint solution
\[
 \rho=\tfrac12(\omega R+R\omega),\qquad
 R=2\int_0^\infty e^{-t\omega}\rho e^{-t\omega}\,dt.
\]
Order preservation in this integral gives \(0\leq R\leq2I\). Extend \(R\) by zero off \(\operatorname{supp}\omega\). Its quadratic score is
\[
 \chi=\operatorname{Tr}\omega R^2=\operatorname{Tr}\rho R
 =\sup_{X=X^*}\left(2\operatorname{Tr}\rho X-\operatorname{Tr}\omega X^2\right).
\]

Let \(\gamma=B(\omega)\), \(\beta=B(\rho)\). Since \(\beta\leq2\gamma\), the corresponding output score \(L\), defined on \(\operatorname{supp}\gamma\), is positive and bounded by 2. Its optimum \(\chi_{\rm out}=\operatorname{Tr}\gamma L^2\) satisfies \(\chi_{\rm out}\leq\chi\): for the unital CP adjoint \(E=B^*\), Kadison gives \(E(Y^2)\geq E(Y)^2\), so each output variational value is at most the input variational optimum.

Define the commuting output observables \(R_1=R\otimes I\) and \(R_2=I\otimes R\). The marginal error assumptions imply \(T(\gamma_a,\omega)\leq\varepsilon\) and \(T(\beta_a,\rho)\leq\varepsilon\). Hence, using \(\|R\|\leq2\) and \(\|R^2\|\leq4\),
\[
 V_a:=2\operatorname{Tr}\beta R_a-\operatorname{Tr}\gamma R_a^2
 \geq 2\operatorname{Tr}\rho R-\operatorname{Tr}\omega R^2-16\varepsilon
 =\chi-16\varepsilon.
\]
The exact completion of the square on the output is
\[
 \chi_{\rm out}-V_a=\operatorname{Tr}\gamma(R_a-L)^2.
\]
It follows that \(\operatorname{Tr}\gamma(R_a-L)^2\leq16\varepsilon\), and the triangle inequality in the real Hilbert norm \(\|X\|_{2,\gamma}=(\operatorname{Tr}\gamma X^2)^{1/2}\) yields
\[
 \boxed{\operatorname{Tr}\gamma(R_1-R_2)^2\leq64\varepsilon.}\tag{1}
\]
The formula remains valid when \(\gamma\) is singular, since all square completions are on its support and the expectation of an off-support component is zero.

## 2. Spectral agreement produces a commuting reference

Choose a bin width \(h>0\). Randomly shift a grid of width \(h\) across \([0,2]\), and let \(P_k\) be the spectral projections of \(R\) in its bins. Since \(R_1,R_2\) commute, their joint spectral measure under \(\gamma\) is an ordinary probability distribution. For eigenvalues \(\lambda,\mu\), the chance over the shift that they occupy different bins is at most \(|\lambda-\mu|/h\). Cauchy-Schwarz and (1) therefore give a shift such that, with \(Q=\sum_kP_k\otimes P_k\),
\[
 \eta:=1-\operatorname{Tr}\gamma Q\leq\frac{8\sqrt\varepsilon}{h}.
\]
Whenever the right side is below 1, set \(\gamma'=Q\gamma Q/\operatorname{Tr}\gamma Q\) and \(\omega'=\operatorname{Tr}_2\gamma'\). By purifying \(\gamma\), projecting the purification with \(Q\), and using the fidelity/trace-distance inequality,
\[
 T(\gamma,\gamma')\leq\sqrt\eta,
 \qquad T(\omega,\omega')\leq d:=\varepsilon+\sqrt\eta.
\]
The state \(\omega'\) commutes with every \(P_k\): cross terms between distinct \(P_k\otimes P_k\) vanish under the second partial trace.

Let \(R_h=\sum_k r_kP_k\), where \(r_k\) is the midpoint of the occupied part of bin \(k\) in \([0,2]\). Then \(0\leq R_h\leq2I\), \(\|R-R_h\|\leq q:=h/2\), and \([\omega',R_h]=0\). Put \(a=\operatorname{Tr}\omega'R_h\). Since \(\operatorname{Tr}\omega R=1\),
\[
 |a-1|\leq 4d+q.
\]
When \(4d+q<1\), the states
\[
 \rho_c=\omega'R_h/a,
 \qquad \sigma_c=\omega'(2I-R_h)/(2-a)
\]
are well-defined and commute. The Jordan representation of \(\rho\), together with \(\|R\|\leq2\), gives
\[
 \|\rho-\omega'R_h\|_1\leq4d+q.
\]
Normalization costs another \(|a-1|\leq4d+q\), so
\[
 T(\rho,\rho_c)\leq4d+q.
\]
The identical estimate holds for \(\sigma\) using its score \(2I-R\). Define \(\delta:=4d+q\). For any pairs of states differing by trace distance at most \(\delta\) in each argument, Powers-Størmer and Schatten Hölder give both
\[
 |F(\rho,\sigma)-F(\rho_c,\sigma_c)|\leq2\sqrt{2\delta},
 \quad |A(\rho,\sigma)-A(\rho_c,\sigma_c)|\leq2\sqrt{2\delta}.
\]
Since \(\rho_c,\sigma_c\) commute, their gap vanishes and \(\Delta(\rho,\sigma)\leq4\sqrt{2\delta}\). Take \(h=\varepsilon^{1/6}\) to obtain the stated formula. If the expression is at least 1, use the trivial \(\Delta\leq1\); if it is below 1, then \(\delta<1/32\), ensuring the postselection and normalization assumptions. The \(\varepsilon=0\) case follows directly from (1), or by continuity.

## Audit points

* The bound uses one common channel and all four marginal promises. The extra reference \(\omega\) is only the known average of the two states.
* The likelihood is the symmetric Jordan score. Its operator bound \(R\leq2I\) relies on \(\rho\leq2\omega\); the raw density commutator is not used.
* The postselected state \(\gamma'\) is an analysis witness, not an operation required of a broadcaster. Its first marginal is block diagonal because the selected event requires matching spectral bins on both outputs.
* The rate is likely far from optimal and no novelty claim is attached. The separate iterative many-leaf information argument reaches a stronger explicit modulus.
