# Two-marginal broadcasting does not uniformly imply classical reconstructibility

Status: complete finite-dimensional counterexample candidate. The independent audit is saved in `audit/independent_audit.md`. Its role is a boundary result: some uniform control of experiment complexity is indispensable in a dimension-independent theorem that turns small two-marginal broadcasting error into small error of a single entanglement-breaking reconstruction channel. It does not establish that uniform covering entropy is necessary for each individual classically reconstructible experiment. External correctness and historical priority review remain open.

All distances below are `T(rho,sigma)=||rho-sigma||_1/2`. An experiment is a supplied set of density matrices; one channel must work uniformly for its unknown member. Channels act on the entire matrix algebra, including inputs outside the supplied experiment.

## 1. Definitions and quantitative statement

For an experiment E on H, write

    b_2(E) = inf_B sup_{rho in E; a=1,2} T(B_a(rho),rho),
    e_EB(E) = inf_{E entanglement-breaking} sup_{rho in E} T(E(rho),rho),

where B:H -> H tensor H is CPTP, B_a is its a-th marginal, and the reconstruction channel has input and output H. An entanglement-breaking (EB) channel is a measure-and-prepare channel.

Let L>=2 and d>=2 be integers; put k_j=2^j, j=0,...,L-1, m=2^(L-1), and

    H_(L,d) = direct_sum_(j=0)^(L-1) Sym^(k_j)(C^d),
    rho_psi = (1/L) direct_sum_(j=0)^(L-1) (|psi><psi|)^(tensor k_j),

for every unit vector psi in C^d. The vector phase does not matter. Let E_(L,d) be this experiment. Its states have rank L and entropy ln L; d and the dimension of H may grow.

Then

    b_2(E_(L,d)) <= 1/L,
    e_EB(E_(L,d)) >= 1 - f_(L,d),
    f_(L,d) := (1/L) sum_(j=0)^(L-1) (2^j+1)/(2^j+d)
              <= (m+1)/(m+d).

For the fidelity-affinity invariant,

    Delta(rho,sigma) = ||sqrt(rho)sqrt(sigma)||_1
                      - Tr(sqrt(rho)sqrt(sigma)),

one has the stronger exact identity

    Delta(rho_psi,rho_phi) = (t-t^(2^L))/L <= 1/L,
    t = |<psi,phi>|.

For example take d_L=L 2^(L-1). Then b_2<=1/L tends to zero, every pair's Delta is at most 1/L, and

    e_EB >= 1 - (1+2^(1-L))/(L+1) -> 1.

Thus no dimension-independent function g with g(epsilon)->0 can satisfy e_EB(E)<=g(b_2(E)) for all finite-dimensional experiments. The same conclusion holds for finite experiments consisting entirely of faithful states, by Section 5.

## 2. A broadcasting channel defined on every input

Let P_j be the orthogonal projection onto the j-th direct-sum sector. Fix any density matrix omega on the bottom sector H_0=C^d, embedded in H. First measure/dephase the sector flag.

For j>=1, the canonical tensor grouping is an isometry

    V_j: Sym^(2^j)(C^d) -> Sym^(2^(j-1))(C^d)
                               tensor Sym^(2^(j-1))(C^d).

A totally symmetric tensor is separately symmetric in its first and second halves, so its image belongs to the asserted codomain. The map is the restriction of the ordinary tensor-factor identification and preserves inner products. In particular,

    V_j psi^(tensor 2^j) = psi^(tensor 2^(j-1))
                              tensor psi^(tensor 2^(j-1)).

Embed that codomain in the pair of lower sectors of H tensor H. Define

    B(X) = Tr(P_0 X) omega tensor omega
           + sum_(j=1)^(L-1) V_j (P_j X P_j) V_j^*.

Each summand is CP. The first is a replacement channel on the bottom input block; the remaining summands use isometries. Because sum_j P_j=I and V_j^*V_j=P_j on H, B preserves trace. In particular there is no requirement that images from different measured flags be mutually orthogonal. This proves CPTP on the full input matrix algebra.

On rho_psi, both output marginals are

    B_a(rho_psi) = rho_psi + omega/L
                  - (1/L) (|psi><psi|)^(tensor m)_top.

The positive and negative differences occupy different direct-sum sectors because L>=2. Each has trace 1/L; hence

    T(B_a(rho_psi),rho_psi)=1/L

for both receivers and every psi. This is the error of the displayed channel; it is not an assertion that the optimal b_2 equals 1/L.

## 3. Every EB reconstruction fails

Define a CPTP decoder R:H->C^d: dephase the sector flag, then in sector j trace out all but one of the k_j tensor factors. It is well defined on every block using the canonical embedding of the symmetric subspace in the ordinary tensor product. It satisfies

    R(rho_psi)=|psi><psi|.

If E:H->H is EB, then A=R composed with E is EB. It can be written as

    A(X) = sum_x Tr(M_x X) sigma_x,

where {M_x} is a POVM on H and sigma_x are density matrices on C^d. Finite sums suffice for finite-dimensional EB channels; allowing an outcome integral gives the same calculation. The diagonal restrictions M_(x,j)=P_j M_x P_j form a POVM on Sym^(k_j)(C^d). Coherences between sectors of M_x cannot contribute on rho_psi.

Let mu be normalized Haar measure on pure states of C^d and let

    D_k = dim Sym^k(C^d) = binomial(k+d-1,k).

The standard symmetric moment identity is

    integral (|psi><psi|)^(tensor(k+1)) dmu(psi)
      = P_sym^(k+1)/D_(k+1).

For an arbitrary k-copy POVM {M_x} and arbitrary prepared density matrices sigma_x, its Haar-average single-copy fidelity obeys

    integral sum_x Tr(M_x psi^tensor k) Tr(sigma_x psi) dmu
      = (1/D_(k+1)) sum_x Tr[(M_x tensor sigma_x) P_sym^(k+1)]
      <= (1/D_(k+1)) sum_x Tr(M_x tensor sigma_x)
      = D_k/D_(k+1)
      = (k+1)/(k+d).

Here `psi` in a density-matrix expression abbreviates |psi><psi|. The inequality uses only positivity of M_x tensor sigma_x and 0<=P_sym<=I, so mixed prepared states are covered as well. This is the established optimal pure-state estimation upper bound; no achievability claim is needed.

Applying the bound separately to every measured input sector gives

    integral <psi|A(rho_psi)|psi> dmu <= f_(L,d).

Contractivity under R and the two-outcome test {|psi><psi|,I-|psi><psi|} give pointwise

    T(E(rho_psi),rho_psi)
      >= T(A(rho_psi),|psi><psi|)
      >= 1 - <psi|A(rho_psi)|psi>.

Therefore every EB E has worst-case reconstruction error at least 1-f_(L,d). Taking the infimum over E proves the claim. The Haar prior is only a lower-bound witness; the operational requirement remains worst-case error for one unknown state, and no prior is supplied to the channel.

## 4. Small pair invariant and unbounded covering complexity

Both states are block diagonal with identical weights. In a pure sector of k copies the root fidelity is t^k and the affinity is t^(2k). Thus

    Delta = (1/L) sum_j (t^(2^j)-t^(2^(j+1)))
          = (t-t^(2^L))/L.

The construction is compatible with a dimension-independent approximate no-broadcasting theorem for a fixed pair. Pairwise closeness to a commuting/classical model does not provide one simultaneous EB channel for this growing experiment.

The states corresponding to d orthogonal basis vectors have pairwise trace distance 1: their supports are orthogonal in every sector. Hence every trace-distance cover of radius a<1/2 contains at least d centers. If N_E(a) denotes a covering number,

    N_E(a)>=d,        ln N_E(a)>=ln d -> infinity.

For d_L=L2^(L-1), the displayed channel's broadcasting error 1/L times the elementary cover lower bound ln d_L tends to ln2. This is consistent with a quantitative sufficiency condition in which broadcasting error times an appropriate covering log-cardinality tends to zero. This observation concerns the displayed channel's error and does not assert that the infimum b_2 equals 1/L. Divergent covering complexity alone does not rule out EB reconstruction; commuting experiments may have arbitrarily large covers.

## 5. Faithful and finite experiments

Let D=dim H and nu=I_H/D. For 0<eta<1 define

    rho_tilde_psi = (1-eta)rho_psi + eta nu.

Every rho_tilde_psi is strictly positive on H. The same B gives

    T(B_a(rho_tilde_psi),rho_tilde_psi)
      <= (1-eta)/L + eta.

For every EB E, contractivity and T(rho_tilde_psi,rho_psi)<=eta imply

    T(E(rho_psi),rho_psi)
      <= T(E(rho_tilde_psi),rho_tilde_psi)+2eta.

Consequently the perturbed experiment obeys

    e_EB(E_tilde)>=1-f_(L,d)-2eta.

Taking eta_L=L^(-3), for example, preserves b_2->0 and e_EB->1.

The pair invariant also remains bounded by (1-eta)/L, without an entropy-dependent continuity estimate. To check this directly, put s=eta/D and w=(1-eta)/L. Each block pair has the form sI+wP, sI+wQ with pure projectors of overlap u=t^(k_j). Put

    c=2sqrt(s(s+w)),       h=(sqrt(s+w)-sqrt(s))^2=w+2s-c<=w.

The orthogonal complement of span(P,Q) contributes the same term to root fidelity and affinity. The remaining two-dimensional calculation gives the block gap

    sqrt(w^2 u^2+c^2)-c-h u^2.

The convex function g(u)=sqrt(w^2u^2+c^2)-c has g(0)=0 and g(1)=h, so g(u)<=hu for 0<=u<=1. Summing the block bounds h(u-u^2) and telescoping the dyadic powers gives

    Delta(rho_tilde_psi,rho_tilde_phi)
      <=h(t-t^(2^L))<=(1-eta)/L.

Two finite restrictions work.

**Finite net.** Compactness of the projective parameter space and continuity of psi->rho_psi give a finite zeta-net in the original state trace metric. For any fixed channel E, its reconstruction-error function is 2-Lipschitz in that metric, by channel contractivity and triangle inequality. Thus

    e_EB(full)<=e_EB(net)+2zeta,
    e_EB(perturbed net)>=1-f_(L,d)-2eta-2(1-eta)zeta.

Take zeta_L=L^(-3). No efficient net acquisition or moderate cardinality is claimed.

**Finite exact moment design, with no net loss.** Put t_order=m+1 and D_t=dim Sym^t(C^d). The Haar moment P_sym^t/D_t belongs to the convex hull of the compact set of pure product projectors psi^tensor t. This is a trace-one affine space of real dimension at most D_t^2-1. Caratheodory's theorem therefore gives at most D_t^2 unit vectors psi_i and positive weights w_i summing to 1 such that

    sum_i w_i psi_i^tensor t = P_sym^t/D_t.

Taking partial traces gives the identical Haar moment for every order k_j+1<=t. The estimation bound of Section 3 holds for the finite weighted witness {psi_i,w_i}; hence the finite experiment {rho_psi_i} already has

    e_EB>=1-f_(L,d).

After adding the common faithful perturbation, its lower bound is 1-f_(L,d)-2eta. One may adjoin the d orthogonal-basis states before perturbation to preserve the elementary cover lower bound; the design-weight witness remains supported on the original subset. The full finite family has no more than D_t^2+d states. After perturbation the basis-state distances equal 1-eta, giving N_E_tilde(a)>=d whenever a<(1-eta)/2.

## 6. More receivers and operational limits

Iterating the same B down a depth-r binary tree produces 2^r receivers. Each leaf marginal is a composition of r copies of the same marginal map. Contractivity and the per-input one-step bound give error at most r/L, or r[(1-eta)/L+eta] after perturbation. For K receivers, choose r=ceil(log_2 K) and discard surplus leaves. Thus every fixed K admits vanishing marginal error, and the same sequence works for any K_L with log K_L=o(L).

The statement is about each receiver's marginal density matrix. The outputs may be correlated. It makes no claim of a joint product state, independent clones, preservation of purifications, low channel-computation cost, or efficient acquisition of the design/net. The construction supplies an existence obstruction to a universal experiment-level approximation modulus.

## 7. Companion harmonic construction

The originally proposed harmonic copy ladder also works particularly simply if a zero-copy vacuum sector is included. For N>=1 let

    H = direct_sum_(k=0)^N Sym^k(C^d),
    H_N = sum_(k=1)^N 1/k,
    rho_psi = (1/H_N) direct_sum_(k=1)^N (1/k)psi^tensor k,

with zero weight in the one-dimensional vacuum block. Measure k, choose a uniformly from {0,...,k}, and split the k tensor factors into a and k-a. The corresponding symmetric-subspace embeddings are isometries, including a=0 and a=k. Define an arbitrary fixed output for a vacuum input to make the channel CPTP everywhere.

Both marginal sector laws satisfy exactly

    q_0 = N/[(N+1)H_N],
    q_j = (1/j-1/(N+1))/H_N = p_j - 1/[(N+1)H_N],  1<=j<=N.

Within each nonzero output sector the correct pure tensor state is retained. Therefore the quantum trace error is exactly q_0=O(1/ln N). The same decoder/estimation argument gives e_EB>=1-(N+1)/(N+d), while

    Delta <= (1/H_N) sum_(k=1)^infinity (t^k-t^(2k))/k
          = ln(1+t)/H_N <= ln2/H_N.

The dyadic construction remains the principal version because its error and pair invariant are exact telescoping formulas. The separate floor/ceil harmonic diagnostics in `subcheck/check.py` also distinguish classical flag distance from the k=1 unknown-state preparation error; a flag-TV calculation alone is insufficient for that version.

## Sources

The symmetric moment identity and the optimal k-copy pure-state-estimation fidelity bound are established results. A primary derivation is A. Hayashi, T. Hashimoto and M. Horibe, *Reexamination of optimal quantum state estimation of pure states*, Phys. Rev. A 72, 032325 (2005), arXiv:quant-ph/0410207; equations (4), (9), and (12): https://arxiv.org/pdf/quant-ph/0410207 . D. Bruss and C. Macchiavello, *Optimal state estimation for d-dimensional quantum systems*, Phys. Lett. A 253, 249-251 (1999), arXiv:quant-ph/9812016, is earlier related primary work: https://arxiv.org/pdf/quant-ph/9812016 . These references support the estimation ingredient and do not by themselves establish priority for the assembled counterexample.

G. Chiribella, *On quantum estimation, quantum cloning and finite quantum de Finetti theorems*, arXiv:1010.1875v4, Section 1, pp. 3-4, explicitly proves the same projector-trace bound for arbitrary measure-and-prepare output density matrices, including mixed outputs: https://arxiv.org/pdf/1010.1875 . The one-output-copy special case is exactly (k+1)/(k+d).

## Bounded historical comparison

A narrow primary-source check did not identify the exact flagged dyadic family with the simultaneous worst-case EB separation above. This is a bounded search result and does not establish novelty or priority.

The closest explicit tensor-power shift precedent located is D. Leung, B. Toner and J. Watrous, *Coherent state exchange in multi-prover quantum interactive proof systems*, arXiv:0804.4118v2, Section 2, Eq. (1), p. 4: https://arxiv.org/pdf/0804.4118 . Their uniform coherent ladder over tensor powers of two chosen states allows a local cyclic shift to exchange those states while its auxiliary-state overlap is 1-1/N. It gives a clear precedent for the shift-and-small-boundary mechanism. Its stated interface is coherent exchange of a chosen pair using an auxiliary state, and does not state the arbitrary-unknown-state flagged broadcasting experiment or its EB reconstruction lower bound.

Dimension dependence in broadcasting-to-classical approximation is already explicitly recognized in G. Chiribella and G. M. D'Ariano, *Quantum information becomes classical when distributed to many users*, arXiv:quant-ph/0608007v3, Theorem 2, Eq. (20) and the following paragraph, p. 4: https://arxiv.org/pdf/quant-ph/0608007 . Their general symmetric-distribution approximation has a receiver-dimension-dependent bound of order d_receiver^2 k/M in trace norm; they point out that growing receiver dimension weakens the classical approximation. This anticipates the qualitative loophole. It does not by itself supply the displayed finite faithful family, the exact 1/L marginal error, or the simultaneous e_EB->1 bound.

The safe claim for this result is therefore an internally audited explicit boundary construction with established ingredients and related shift prior art. An exhaustive novelty or historical equivalence judgment remains open.
