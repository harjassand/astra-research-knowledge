# Independent adversarial audit of the dyadic construction

Verdict: the construction and the proposed lower bounds are mathematically sound, with the conventions and asymptotic quantifiers below. No substantive error was found. The faithful version has a stronger pair-gap bound than a generic continuity argument gives, and a finite weighted design avoids the net loss.

## Conventions and parameters

Let V=C^d, d>=2, L>=2, k_j=2^j for 0<=j<L, and m=2^(L-1). Let H=direct_sum_j Sym^{k_j}(V), D_k=binomial(d+k-1,k), and D=sum_j D_{k_j}. Set P_psi=|psi><psi| for a unit vector psi and

    rho_psi = (1/L) direct_sum_j P_psi^{tensor k_j}.

Trace distance means T(rho,sigma)=||rho-sigma||_1/2. The estimation fidelity below is the squared fidelity <psi|tau|psi>, whereas the pair-gap uses root fidelity ||sqrt(rho)sqrt(sigma)||_1.

Define e_EB(F)=inf_{E EB CPTP H->H} sup_{rho in F} T(rho,E(rho)). All channels are trace preserving; postselection is excluded.

## Broadcasting channel and decoder

For j>=1, there is a canonical isometric inclusion

    W_j: Sym^{2^j}(V) -> Sym^{2^(j-1)}(V) tensor Sym^{2^(j-1)}(V)

obtained by splitting the physical tensor factors. This is an isometry because a fully symmetric vector is symmetric within both blocks, and the ambient tensor norm is preserved. It takes psi^{tensor 2^j} to two copies of psi^{tensor 2^(j-1)}.

Choose a fixed density operator omega supported on sector 0. Measure/dephase the input sector; use W_j for j>=1; for j=0 discard the input and prepare omega tensor omega. These branches define a CPTP B:H->H tensor H. Both marginal channels equal a channel Phi, and

    Phi(rho_psi) = rho_psi + omega/L - P_psi^{tensor m}/L,

where the last term is in the top sector. Positive and negative terms occupy orthogonal sectors, so T(Phi(rho_psi),rho_psi)=1/L exactly. This exact value depends on the half-trace-norm convention.

The decoder R first dephases the sector and then traces out k_j-1 physical tensor factors in sector j. It is CPTP and R(rho_psi)=P_psi.

## Entanglement-breaking obstruction

For any EB E:H->H, Lambda=R composed with E is EB H->V. Write

    Lambda(X)=sum_x Tr(M_x X) sigma_x,

with M_x>=0, sum_x M_x=I_H and sigma_x density operators on V. Finite-dimensional EB channels admit such a finite representation; allowing integrals causes no change.

The compressed effects M_{x,j} on Sym^{k_j}(V) form a POVM on that sector. Off-diagonal sector blocks have zero expectation against rho_psi, so coherent effects across sectors do not improve the bound.

For each k, the normalized Haar moment is

    integral P_psi^{tensor(k+1)} dpsi = P_sym,k+1 / D_{k+1}.

Therefore, for every positive effect M on Sym^k(V) and density sigma on V,

    integral Tr(M P_psi^{tensor k}) Tr(sigma P_psi) dpsi
      = Tr[(M tensor sigma) P_sym,k+1]/D_{k+1}
      <= Tr(M)/D_{k+1}.

The inequality uses P_sym<=I and positivity; it does not require commuting operators. M is extended by zero if viewed in V^{tensor k}. Its POVM traces sum to D_k, not d^k.

Summing gives

    integral <psi|Lambda(rho_psi)|psi> dpsi
      <= f_L,d := (1/L) sum_j (k_j+1)/(k_j+d)
      <= (m+1)/(m+d).

The averaged-sector bound f_L,d is sharp for this estimation problem, using the covariant coherent POVM in each sector followed by preparation in the bottom sector. Sharp estimation does not assert sharpness of the trace-distance lower bound.

Contractivity and the two-outcome measurement {P_psi,I-P_psi} give

    T(rho_psi,E(rho_psi))
      >= T(P_psi,Lambda(rho_psi))
      >= 1 - <psi|Lambda(rho_psi)|psi>.

Thus for every E there exists a psi, possibly depending on E, with error at least 1-f_L,d, and

    e_EB({rho_psi: all pure psi}) >= 1-f_L,d
      >= 1-(m+1)/(m+d).

There is no interchange of infimum and Haar integral. The Haar bound holds separately for every E, then its average supplies a worst-case witness.

## Pairwise root-fidelity minus affinity

Let t=|<psi,phi>| be the unsquared overlap, in [0,1]. On each pure sector, root fidelity is t^{k_j} and affinity is t^{2k_j}. Direct-sum weights are both 1/L, so

    Delta(rho_psi,rho_phi)
      = (1/L) sum_j (t^{2^j}-t^{2^(j+1)})
      = (t-t^{2^L})/L <= 1/L.

This telescope would be written differently if t meant the squared overlap. No ambiguity should remain in the final statement.

## Faithful perturbation

For 0<eta<1, let tau=I_H/D and rho_tilde_psi=(1-eta)rho_psi+eta tau. Every rho_tilde_psi is full rank, with minimum eigenvalue at least eta/D.

Convexity gives the stronger displayed broadcasting bound

    T(Phi(rho_tilde_psi),rho_tilde_psi)
      <= (1-eta)/L + eta T(Phi(tau),tau)
      <= (1-eta)/L + eta.

For any CPTP E, two triangle inequalities and contractivity imply

    T(rho_tilde_psi,E(rho_tilde_psi))
      >= T(rho_psi,E(rho_psi))-2eta.

Taking supremum and then infimum gives e_EB(tilde_family)>=1-f_L,d-2eta.

The pair-gap stays O(1/L) without a square-root eta loss. Every sector has the same scalar parameters

    s=eta/D, w=(1-eta)/L,
    c=2 sqrt(s(s+w)), h=w+2s-c=(sqrt(s+w)-sqrt(s))^2 <= w.

For an n-dimensional sector, n>=2, and u=t^{k_j}, its two unnormalized blocks are A=sI+wP and B=sI+wQ. On the two-dimensional span of the two vectors, the root-fidelity formula for positive 2x2 matrices yields

    F_root(A,B)=(n-2)s+sqrt(w^2 u^2+c^2),
    Tr(sqrt(A)sqrt(B))=(n-2)s+c+h u^2.

The same formula remains valid at u=1 by padding the common vector with one orthogonal direction, and at s=0 by continuity. Their difference is g(u)-h u^2, where g(u)=sqrt(w^2 u^2+c^2)-c. Convexity on [0,1] gives g(u)<=u g(1)=u h. Thus

    Delta(rho_tilde_psi,rho_tilde_phi)
      <= h sum_j(t^{k_j}-t^{2k_j})
      = h(t-t^{2^L}) <= (1-eta)/L.

## Finite-net transfer

The pure-state parameter space is compact and psi->rho_psi is continuous, so for every zeta>0 there is a finite zeta-net in original-state trace distance. For any CPTP E,

    sup_full T(rho,E(rho)) <= max_net T(rho,E(rho))+2zeta.

Taking the infimum over EB E gives e_EB(net)>=e_EB(full)-2zeta. After faithful perturbation, pairwise distances are multiplied by (1-eta), giving the slightly stronger noisy-net bound

    e_EB(noisy_net) >= 1-f_L,d-2eta-2(1-eta)zeta.

The proposed looser bound with -2eta-2zeta is valid. Net centers can be chosen in the original family. No uniform bound on the number of net points is needed for an existence result.

## Finite weighted-design alternative

Let q=m+1 and D_q=dim Sym^q(V). The Haar moment P_sym,q/D_q lies in the convex hull of the rank-one coherent projectors P_psi^{tensor q}. This convex hull is compact in finite dimension. These projectors lie in the trace-one affine hyperplane of real dimension D_q^2-1, so Caratheodory gives at most D_q^2 nodes with nonnegative weights summing to one. Remove zero weights to obtain strictly positive weights.

Partial trace gives exact moments of all orders <=q. In particular, every order k_j+1 needed in the preceding estimation argument is available. The same weighted-average bound f_L,d holds for every EB channel; consequently the finite node family already satisfies e_EB>=1-f_L,d, with no net loss. The faithful node family satisfies e_EB>=1-f_L,d-2eta.

Adjoining rho_{e_i} for an orthonormal basis {e_i}_{i=1}^d preserves every uniform broadcasting and pair-gap bound and can only increase worst-case EB error. The original design weights remain a lower-bound witness supported on the original subset. The added original basis states are mutually orthogonal in H; their faithful versions have trace distance exactly 1-eta. Analytic existence is sufficient for a counterexample, but this argument does not supply an efficient numerical design construction.

## Many recipients and asymptotic quantifiers

Apply B in a complete binary tree of depth r. Its output has K=2^r leaves, and every leaf marginal is Phi^r(rho_tilde_psi), even though leaves can be correlated. Contractivity and telescoping give

    T(Phi^r(rho_tilde_psi),rho_tilde_psi)
      <= r((1-eta)/L+eta).

This is a marginal broadcasting guarantee, not approximation of a product state or independent cloning. For arbitrary K, use depth ceil(log_2 K) and discard extra leaves.

To conclude vanishing error for log K_L=o(L), choose eta_L with ceil(log_2 K_L) eta_L->0. A fixed positive eta does not suffice. For example, eta_L=L^-2 works for all such K_L. To make the EB lower bound tend to one, require d_L/m_L->infinity and eta_L->0; for nets also require zeta_L->0. One simple choice is d_L=m_L^2, for which (m_L+1)/(m_L+d_L)=1/m_L. Dimension and the finite family's cardinality are allowed to grow with L.

## Corrections and qualifications to preserve

1. State the half-trace-norm convention and squared estimation fidelity explicitly.
2. The witness psi for the EB lower bound may depend on E.
3. The asymptotic faithful many-recipient claim needs a vanishing eta_L with r_L eta_L->0.
4. Tree output is only controlled in its individual marginals.
5. Caratheodory provides a finite positive weighted design by existence, not a computationally efficient construction.
6. The first estimation bound is sharp; the derived EB trace-distance lower bound need not be sharp.

No other error or missing assumption was identified.
