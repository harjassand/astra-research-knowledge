# Fresh PSPACE-effective synthesis audit: space, precision, and phase

Status 2026-10-07: no fatal obstruction found in the obligations below. This is a direct independent audit of the repaired construction, conditional on the imported OpenAI283 feedback/encoder identities and the cited KT characterization; it does not certify the full manuscripts or historical priority. Review inputs: `work/agents/quantum_complexity/oracle_synthesis/PSPACE_EFFECTIVE_CANDIDATE.md`, polished `PSPACE_EFFECTIVE_SYNTHESIS.md`, `pspace_acquisition_audit/AUDIT.md`, and source sections02–07 at commit adc7f1241b42e322a6451854ab7e4b4c146bf78a.

## 1. Legal input and phase-sensitive target

Fix one exact unitary family U_n and one deterministic entry approximation program E(1^n,i,j,1^p), with an associated fixed polynomial-space bound, satisfying absolute complex error<=2^-p. The conclusion selects a single PSPACE language f_U; it is not a universal poly-space evaluator for arbitrary programs whose space exponents are included as data. The polynomial bounds may depend on the fixed E code/space exponent. No exact-zero or exact-sign information about computable reals is assumed.

OpenAI283 `02-slots.tex`, `slot:clean-error`, supplies restricted operator norm ||C iota-iota U||, preserving actual scalar phases and labels, including workspace. This is stronger than the displayed channel diamond headline. Global phases cannot be recovered from that headline alone. KT Definition5.2 asks closeness to a full unitary extension; Lemma5.3 converts restricted error epsilon/2 to full-extension error epsilon. The constant factor must be budgeted. Physical scratch is approximately zero, not exactly zero; only the ideal comparison extension resets it exactly.

## 2. Short-seed moment calculations checked independently

For a=n+1, q<=2^n and s<=q/M, a 2a-wise independent sign family requires 2a log2(q)=O(n^2) seed bits. A random degree-(2a-1) polynomial over GF(q), followed by any fixed nonzero F2-linear functional, supplies these signs. The field may be represented by the first irreducible degree-log2(q) polynomial in a finite enumeration; all polynomial data have O(n) bits. No q-entry sign table is stored.

For a complex Rademacher sum S with sum|alpha_i|^2<=1/q, expand real and imaginary moments: E|S|^(2a)<=(4a/q)^a. This is a degree-2a sign polynomial, so bounded independence suffices. A qs-entry union bound at 16sqrt(a/q) is <=qs*64^-a<=4^n64^-(n+1)<1. Finite squared-error thresholds strictly between 256a/q and289a/q choose E2 robustly, and imply the accepted exact bound17sqrt(a/q).

For fixed E2, the source Hermitian dilations have sumL_i^2<=vI, v=289sa/q. Convexity of Tr|X|^(2a) and conditional Jensen over Gaussian magnitudes imply

E Tr(Y^(2a)) <= mu^(-2a)*(2s)*(2a-1)!! v^a.

Since TrY^(2a)=2Tr(D*D)^a, mu>1/2, and (2a-1)!!<=(2a)^a, the result is

E Tr(D*D)^a <=s(2312a^2s/q)^a.

With M=2^20a^2 and s<=2^(a-1), this is <16^-a. A finite trace estimate of error4^-a/8 accepted at3*4^-a/4 certifies exact trace<=7*4^-a/8, hence ||D||<1/2. Existence has ample slack. The sign-polynomial degree is2a, so replacing full signs by 2a-wise independent signs remains legitimate. Using the *norm expectation* instead would not have justified limited independence; the trace moment repair is necessary.

The s=1 case has a separate fixed gap1/sqrt2<3/4 and needs only an O(n)-bit transposition index. All seed choices must be canonical finite-gap choices fixed independently of requested output accuracy. They are discontinuous functions of U, but repeated evaluation selects exactly the same choice. The feedback Lipschitz estimate is used only after fixing them.

## 3. Precision invariant that makes the space bound work

At recursion level j, exact target U_j is obtained from U_{j-1} by fixed canonical conditioning and the exact feedback F=A+BZ(I-DZ)^-1C. Each exact conditioned block is a unitary subblock, ||D||<=3/4. The family U_j, including labels, is mathematically fixed; entry evaluators approximate it and do not define a different target at every precision.

To evaluate feedback at error2^-p, define each entry of an implicit matrix Vbar by the same deterministic finite approximation followed by one common dyadic rounding. Request enough precision that max-entry error<=2^-(p+n+c), so ||Vbar-V||<=2^-p-c by dimension<=2^n. Construct diagonal Zbar similarly. With c a fixed large integer, ||Dbar Zbar||<=4/5. The resolvent identity yields inverse norms4,5 and a fixed dimension-independent Lipschitz constant for the full feedback expression. Thus the original rounding error is charged once in operator norm.

Compute a length t=O(p+1) Neumann polynomial in Vbar,Zbar using exact finite dyadic path arithmetic. All factors share denominators of bit lengthO(p+n); each path has denominator lengthO(t(p+n)). The number of paths is at most2^O(nt); exact sums require onlyO(t(p+n)+nt+logt) numerator bits. Path counters also have O(nt) bits. This is polynomial space. It is false that one must request p+nt bits in child evaluations after this repair: those factors are the globally fixed rounded matrix, and the exponentially many path terms only enlarge the exact accumulator.

Walsh conditioning adds O(n) child precision because each transformed entry has coefficient absolute sum at most2^n. Fixed-gap seed tests use a precision P_seed(n)=poly(n). Hence the correct recurrence is

p_{j-1} <= max(p_j,P_seed(n))+C(n+1),

with j<=J=8M(n+1)=poly(n). It follows that all precisions are bounded by p_out+P_seed(n)+C(n+1)J. This is additive, not multiplicative. Every call that recomputes a seed for U_j invokes entries of U_j, whose evaluator recursively uses only the earlier U_{j-1}; there is no cycle at a fixed level.

Including global desired circuit precision b, L=O(b+log J), K=O(nL^2+LlogL), and cumulative phase-label lengthO(JK) are polynomial(n+b). Fourier coefficient computations call the feedback entry evaluator at precision p+O(nL), once outside the feedback recursion. They do not cause this nL loss at every recursion level. An evaluation frame stores polynomial-bit exact rationals and O(JK)-bit labels; polynomial-depth stacks therefore fit polynomial(n+b+p) space. Arbitrarily many recomputations increase time, not workspace.

## 4. Rational encoder repair checked

Every Fourier row has a structural support of size<=L, decoded from its signed power-sum frequency. Enumerating candidate roots and validating Newton identities uses polynomial-size integer data. Frequencies that fail these finite integer tests are assigned an invalid-row extension. Real coefficient vanishing is never queried.

For R<=2^(K+n), d<=2^n, choose common-grid coefficients A with per-entry error<=delta/sqrt(Rd). Restrict them to structural support first. Then ||A-T||<=delta and rational Ttilde=A/(1+delta) is a contraction. With the source Gram bound,

Ttilde*Ttilde >=(1-r^(2L)-4delta)I.

The lower bound follows from ||Ttilde-T||<=2delta and both matrices being contractions. The source row-sparse encoder error is at most5(r^(2L)+4delta), so its difference from ideal T is at most5r^(2L)+22delta. Two encoders per level and delta<=e/(176J), together with18Jr^L<=e/4, fit the e/2 skeleton budget.

Entries of Ttilde have a common rational denominator H with poly(n+b) bits. Every squared-prefix probability is an exact integer numerator overH^2. Its numerator may be obtained by enumerating exponentially many rows, but its bit length increases by only logR. Nonzero probabilities are>=H^-2, so conditional rotations and phase-normalized nonzero coefficients have a polynomial precision bound. The failure amplitude sqrt(H^2-sum(u^2+v^2))/H has a finite integer radicand. This is the crucial replacement for impossible exact-zero/near-zero queries on arbitrary computable reals.

## 5. Full precision can be proved directly from the source refinement

The source `07-compilation.tex`, `compile:words`, already proves a determinant-one refinement with epsilon_{j+1}<=Cepsilon_j^(3/2), ell_{j+1}=5ell_j. It subsequently weakens this to epsilon_{j+1}<=epsilon_j/2 only because polynomial1/epsilon suffices for its headline.

Let beta_j=C^2epsilon_j and choose a fixed starting net with beta_0<1. Then beta_{j+1}<=beta_j^(3/2), so beta_j<=beta_0^((3/2)^j). To achieve eta one needs j=O(loglog(1/eta)); word length is therefore

O((log(1/eta))^(log_{3/2}5)).

The initial net and its maximal length are fixed constants, and the inverse alphabet exists. This directly proves the needed uniform polylog length *existence* bound using the source's detailed estimates. The generator hardcodes a conservative integer polynomial length bound; it need not acquire the net or target words. This is a simplification of the candidate's separate full-Solovay-Kitaev invocation, not an additional assumption.

U(2) phases are retained by enumerating a pair of SU(2) words and testing its 4x2 clean action against W tensor|0>. Exact determinant-one is the residue4#H+#T-#Tdag mod8. An abstract SU(2) decomposition proves a passing pair exists, but no determinant square-root branch is evaluated. Constant-dimensional finite matrix arithmetic and strict-gap tests select the first accepted pair in polynomial space. Actual approximate scratch leakage composes safely by restricted telescoping after ideal prefixes.

For a total uniform oracle, addresses explicitly charge n and desired b in unary. Invalid sizes, slot indices, controls, word positions, and other malformed addresses return0. The circuit generator's L choice can avoid rounding a transcendental logarithm: use the least integerL satisfying4^L>=72J2^b3^L. Integer comparisons/powers have polynomial bitlength because L=poly(n+b). Rational eta can be replaced by a smaller dyadic within a constant factor. These routine choices remove threshold ambiguity from the generator itself.

## 6. Converse containment

A polynomial-size circuit with one PSPACE Boolean oracle has entries approximable in polynomial space: enumerate basis paths, evaluate every Boolean query via its fixed polynomial-space machine, approximate the finite elementary gates to sufficient precision, and sum rational paths. There are poly(n+b) qubits/gates, so all path indices and requested precisions are polynomial. With b=p+O(1), the clean upper-left block approximates U_n entries to2^-p. KT Theorem6.17 then gives unitaryP^PSPACE subset unitaryPSPACE. The same argument applies to a fixed classical oracle L using PSPACE^PSPACE^L=PSPACE^L. No coherent evaluation of a PSPACE oracle in polynomial time is being asserted.

## 7. A smaller sufficient theorem for the cryptographic consequence

The separately audited constant-error route in `commitment_audit/CONSTANT_COMMITMENT_REDUCTION.md` removes the arbitrary-precision time bound from the cryptographic dependency chain. Given a standard uniformly generated EFI pair with trace distance at least1/p(s), take m(s) to be a power of two in[8p(s)^2,16p(s)^2). Root-fidelity multiplication gives tensor-power trace distance>31/32. Choosing a uniformly random challenge position among these m copies proves computational indistinguishability of the amplified pair by an exact signed hybrid identity; no unknown favorable index or advice is needed.

For its q(s)-qubit difference A_s, phase estimation of exp(iA_s) with tau=2^(-q(s)-6) and failure1/64 has ideal sign-measurement advantage at least59/64. The exact full phase-estimation target has PSPACE entry approximations; pad its arity by an explicit polynomial injection before applying synthesis. The released full diamond error1/2 loses at most1/2 in distinguishing advantage. Under BQP=PSPACE, coherent replacement of the acquired total Boolean oracle to restricted error1/64 adds diamond error at most1/32. The resulting uniform BQP attack retains advantage25/64, and the uniform hybrid gives single-copy advantage at least25/(64m(s)).

Therefore the commitment implication needs only PSPACE-effective **constant-error** synthesis. Full precision, full Solovay–Kitaev, retained scalar phases, and clean synthesis of the target are not needed for that implication. They remain relevant to the stronger equality of KT's exact unitary complexity classes. The oracle-acquisition proof is still load-bearing even in this shortened route.

For this weaker theorem fix the synthesis precision prefix b=b0 once, for example b0=2 for restricted error1/4 and diamond error1/2, and make the total Boolean oracle return0 on other precision prefixes. The released weak polynomial(1/eta) word bound is then polynomial(n), because eta is inverse polynomial(n). It cannot simply be used at arbitrary variable b while claiming that enumeration of the resulting exponentially long words fits polynomial(n+b) space. The fixed-precision language interface removes that dependency honestly.

## Scope

The claim appears sound in the audited space/precision/phase obligations, conditional on the released Fourier-field and row-sparse encoding mechanism and KT's characterization. The clean-BQP-oracle and EFI reduction were separately audited under commitment_audit/, with no fatal obstruction found for standard uniform honest generation. Constant channel error alone does not imply the full-precision class equality, although constant-error PSPACE-effective synthesis suffices for the amplified cryptographic reduction above. Neither the construction nor the class equality proves BQP!=PSPACE unconditionally; a commitment/EFI existence hypothesis is required.
