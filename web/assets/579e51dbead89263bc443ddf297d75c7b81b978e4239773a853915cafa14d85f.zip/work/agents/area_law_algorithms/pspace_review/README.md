# Fresh independent review of PSPACE-effective unitary synthesis

7 October 2026. Assigned independently after the area-law work. Scope: attack the repaired release283 acquisition proof's space, precision, phase, uniformity, and cryptographic interface. This is an internal mathematical audit, not external certification of the source manuscripts or a priority claim.

## Outcome

No fatal obstruction was found in the repaired proof obligations. The uniform input is one fixed exact unitary family with one fixed deterministic polynomial-space entry approximation program. The conclusion uses one fixed total PSPACE Boolean language, with unary size/precision charged in its addresses. Polynomial-space enumeration can take exponential time. Arbitrary program exponents and arbitrary quantum input amplitudes are not supplied free.

The main independent acquisition audit is `SPACE_PRECISION_AUDIT.md`. It checks the trace-moment bounded-independence repair, canonical finite-gap sign selection, the additive recursive precision invariant, consistent implicit dyadic rounding before Neumann path expansion, rational sparse-encoder probabilities, phase-sensitive gate-word selection, total-address uniformity, and the converse containment. It also derives the needed polylogarithmic word bound directly from the released epsilon_next<=C epsilon^(3/2), length_next=5length refinement, so a separate black-box Solovay–Kitaev dependency is unnecessary.

The main independently derived consequence is weaker in its hypotheses than the full class equality: **constant-error channel synthesis with a PSPACE-acquired oracle already implies standard quantum commitments=>BQP!=PSPACE**. Uniform polynomial-copy amplification yields EFI trace distance>31/32. A polynomial-space-entry phase-estimation target gives ideal distinguishing advantage59/64. The release's full diamond error1/2 plus coherent replacement diamond error1/32 leaves25/64 advantage. Thus full precision, clean target synthesis, and global-phase retention are not needed for the cryptographic consequence. The oracle-acquisition proof remains essential.

## Files

- `SPACE_PRECISION_AUDIT.md`: fresh acquisition and class-interface audit, including the shortened consequence.
- `commitment_audit/CONSTANT_COMMITMENT_REDUCTION.md`: exact standalone conditional constant-error cryptographic deduction.
- `commitment_audit/AUDIT.md`: official KT class-collapse route, clocks, indexing, standard commitment-to-EFI interface, and advice boundaries.
- `commitment_audit/coherent_check.md`: independent coherent Boolean-oracle derivation, exact restricted norm2sqrt(max failure), and valid scratch-reuse telescoping.
- `commitment_audit/arxiv-v2.tex`, `kt2610v2.pdf.txt`, `bcq2023.pdf.txt`: acquired primary source and extracted evidence.

## Remaining conditions and rejected shortcuts

The acquisition proof imports the pinned release283 feedback, Gram, Fourier-support, and row-sparse encoder identities, and uses KT's entry characterization. This review checks composition and acquisition but does not constitute a new verification of every imported lemma. Standard uniformly generated honest states are required. Arbitrary quantum advice supplied to honest parties need not have PSPACE-computable entries and is outside the theorem. Classical-oracle relativization does not authorize arbitrary unitary-oracle relativization.

Literal exact physical scratch cleanup is false for the finite-error BQP replacement. The needed statement is restricted isometry closeness to an exact clean comparator. Direct EFI separation is KT Theorem7.14, not Corollary7.16. Printed KT pages are Lemma5.3p16, Theorem6.17p30, Theorem7.14pp38–39; zero-based PDF indices are15,29,37–38.

No unconditional separation or existence of commitments follows. No historical priority claim was established.
