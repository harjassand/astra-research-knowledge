# Constant-error PSPACE-effective synthesis already excludes commitments under BQP=PSPACE

7 October 2026. Independent deduction, conditional only on the stated effective constant-error synthesis premise. This does not prove the oracle-acquisition premise.

## Exact sufficient premise

For every unitary language W whose entries are uniformly approximable in polynomial space, suppose there is one fixed total Boolean language f_W in PSPACE and a deterministic polynomial-time generator G such that G(1^N) outputs a circuit C_N with polynomial(N) gates, qubits, Boolean oracle calls and address width, and its retained-output channel satisfies

    ||Phi_N^{f_W} - (rho -> W_N rho W_N^dagger)||diamond <= 1/2.

The norm is the **full diamond norm**, without a factor 1/2. This is the convention explicitly fixed in OpenAI 283, `sections/01-introduction.tex`, equation `intro:diamond` and Theorem `thm:main`, at release commit adc7f1241b42e322a6451854ab7e4b4c146bf78a. The extra premise is PSPACE-effectivity of the oracle for this family, with n charged in the address and one uniform oracle language across all lengths.

The effective premise gives an oracle circuit that depends only on the target family and input size. It does not require exact phase preservation, an exact-clean implementation, or synthesis error smaller than 1/2.

## Theorem

Under this premise, existence of standard uniformly generated EFI pairs implies BQP!=PSPACE, and therefore P!=PSPACE. Standard quantum commitments imply the same by BCQ's commitment-to-EFI equivalence.

## Proof

Assume BQP=PSPACE and let rho_0,s, rho_1,s be a standard EFI pair at security parameter s. Uniform polynomial-time generation produces d(s)<=poly(s) qubits. Fix an integer polynomial p(s)>=1 such that

    TD(rho_0,s,rho_1,s) >= delta(s)=1/p(s)

for all sufficiently large s. Here TD(rho,sigma)=||rho-sigma||1/2. The attack uses this lower bound, not the exact trace distance.

### Uniform polynomial-copy amplification

Define root fidelity F(rho,sigma)=||sqrt(rho)sqrt(sigma)||1. Fuchs–van de Graaf gives

    F(rho_0,s,rho_1,s) <= sqrt(1-delta(s)^2).

Let

    m(s)=2^ceil(log2(8p(s)^2)),
    sigma_b,s=rho_b,s^tensor m(s).

Then 8p(s)^2<=m(s)<16p(s)^2, so m(s) is a polynomial-time computable polynomially bounded integer. Fidelity multiplies under tensor products, and the opposite Fuchs–van de Graaf inequality yields

    TD(sigma_0,s,sigma_1,s)
       >= 1-F(rho_0,s,rho_1,s)^m(s)
       >= 1-exp(-m(s)delta(s)^2/2)
       >= 1-exp(-4)
       > 31/32.

The sigma pair is uniformly generated using m(s) independent executions of the original generator. It remains computationally indistinguishable. Indeed, for any putative distinguisher D on m copies, define hybrid H_j with j copies of rho_0 followed by m-j copies of rho_1. A single-copy distinguisher D' chooses j uniformly in {1,...,m} using exactly log2(m) random coins, places its challenge in slot j, and generates the other hybrid slots itself. Then

    Pr[D'(rho_0)=1]-Pr[D'(rho_1)=1]
      = [Pr[D(sigma_0)=1]-Pr[D(sigma_1)=1]]/m.

This identity telescopes the signed advantage, so no search for an unknown favorable hybrid index is required. D' is polynomial time and uniform whenever D is. It uses the same advice as D if D is nonuniform/advised. Thus noticeable distinguishing of the sigma pair would violate security of the original EFI pair.

### A PSPACE-entry unitary with large distinguishing advantage

Let q(s)=m(s)d(s) and A_s=sigma_0,s-sigma_1,s. Uniform polynomial-size generation gives a deterministic PSPACE approximation to every entry of A_s, by streaming the circuit path sum and the partial trace. Also `||A_s||op<=1`.

Define U_s=exp(i A_s). Its entries have a PSPACE approximation algorithm: truncate the Taylor series at O(log(1/epsilon)) terms and stream the expanded finite matrix-product sums with polynomial precision. This is the same entry characterization step used by KT Theorem 7.14, resting on their Theorem 6.17.

Let V_s be a unitary phase-estimation circuit for U_s. On each eigenstate of A_s it estimates lambda in [-1,1] within

    tau(s)=2^(-q(s)-6),

with failure probability at most eta=1/64. The phase register uses polynomial(s) qubits, and the circuit makes at most exponential-in-polynomial(s) controlled U_s calls. All gates and their order are generated in polynomial space. Approximate implementations of U_s can use inverse-exponential accuracy; that accuracy is used only to establish polynomial-space entry evaluation of the exact target V_s, not to require full-precision **polynomial-time** synthesis. KT self-lowness or direct streamed circuit evaluation places this exact full target in unitaryPSPACE.

Initialize V_s's phase registers to zero and accept if the estimated eigenvalue is nonnegative. Let D_ideal denote that measurement. The spectral calculation from KT Theorem 7.14 gives

    Adv(D_ideal)
      >= TD(sigma_0,s,sigma_1,s)-2^q(s)tau(s)-2eta
      >= 31/32-1/64-2/64
      = 59/64.

The small-eigenvalue band costs at most the number of eigenvalues times tau. No exact eigenvalue-sign comparison or spectral gap is assumed.

### Arity is charged and the target is a genuine unitary language

V_s acts on ell(s)<=poly(s) qubits, including its phase-output registers. Choose a strictly increasing integer polynomial N(s)=C(s+1)^k that majorizes ell(s), and define

    W_{N(s)}=V_s tensor I_(N(s)-ell(s)),
    W_N=I_N for N outside the image of N(s).

Given unary N, enumerate s<=N to recognize the image and recover s. This is polynomial time in N. All needed precision and space remain polynomial(N+p). This repairs the harmless KT shorthand `{V_n}` where footnote 9 notes that V_n acts on more than n qubits. The adversary computes N(s) in polynomial(s) time, pads the challenge and phase registers, and reads the designated phase output after synthesis.

Apply the constant-error effective premise to W. The circuit C_{N(s)} uses one fixed PSPACE language f_W. Under BQP=PSPACE, f_W has a fixed time-uniform BQP decider. An address-preserving amplified compute-copy-uncompute implementation approximates each oracle gate with restricted norm at most kappa/max(1,Q), where Q is a polynomial bound on the number of queries and kappa=1/64. Worst-case decision failure O((kappa/Q)^2) needs O(log Q) repetition; all address widths and clocks are polynomial(N(s))=polynomial(s).

Restricted telescoping, or KT Lemma 5.3 plus full-extension telescoping, gives isometry error at most kappa between the simulated circuit and the original exact-oracle circuit, with the additional scratch compared to zero. Tracing all discarded work then gives full diamond error at most 2kappa=1/32. Physical scratch need only be approximately reset; the construction never assumes exact cleanup.

Therefore the simulated BQP output channel is within

    1/2+1/32=17/32

in full diamond norm of the ideal W channel. For any effect 0<=E<=I and two normalized states, its probability change is at most half their trace-norm difference, because their difference has trace zero. Thus each of the two acceptance probabilities changes by at most 17/64. Distinguishing advantage decreases by at most 17/32. The resulting uniform BQP distinguisher has

    Adv(D_BQP) >= 59/64-34/64=25/64.

This contradicts computational indistinguishability of the sigma pair. Equivalently the exact uniform hybrid constructs a distinguisher of the original pair with advantage at least 25/(64m(s)), which is inverse polynomial. Hence BQP!=PSPACE. Since P subset BQP subset PSPACE, P!=PSPACE as well.

## Scope and reduced dependency chain

The cryptographic conclusion uses only:

1. Standard uniform EFI generation, with computational security at least against uniform polynomial-time quantum adversaries.
2. Polynomial-copy gap amplification and the uniform hybrid.
3. PSPACE entry approximation of the density-matrix exponential and phase-estimation target.
4. PSPACE-effectivity of the **constant-error** released synthesis oracle.
5. Ordinary BQP amplification and coherent Boolean-oracle replacement under the hypothetical collapse.

It does not use full Solovay–Kitaev, the complete arbitrary-precision polynomial-time synthesis extension, global-phase retention, or clean unitary synthesis of the target. The acquired-oracle construction is still load-bearing; the constant-error release alone does not establish its PSPACE-effectivity.

Arbitrary quantum auxiliary input for honest parties is outside this deduction. Standard adversarial quantum advice is harmless to the argument because the attack uses none, and the hybrid preserves any advice if one chooses to state stronger security.

## Primary references

- OpenAI 283 source at fixed commit: https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Polynomial-Time-Unitary-Synthesis-from-a-Boolean-Oracle-October-5-2026/build/sections/01-introduction.tex . Equations `intro:diamond`, Theorem `thm:main` fix full diamond error 1/2.
- Kretschmer–Tang: https://arxiv.org/pdf/2610.03705v2 . Theorem 6.17, Theorem 7.14, printed p30 and pp38–39. Exact source acquired as https://arxiv.org/src/2610.03705v2 .
- Brakerski–Canetti–Qian: https://doi.org/10.4230/LIPIcs.ITCS.2023.24 . Definition 7, Theorem 13, printed pp24:13–14; Section 1.2, p24:9, poses the BQP-versus-PSPACE question.
- Fuchs–van de Graaf: https://arxiv.org/abs/quant-ph/9712042 . Root-fidelity convention is fixed explicitly above to avoid squared-fidelity ambiguity.

Status: exact conditional reduction checked independently. It is neither proof that the effective synthesis premise holds nor proof that commitments exist, and it makes no priority claim.
