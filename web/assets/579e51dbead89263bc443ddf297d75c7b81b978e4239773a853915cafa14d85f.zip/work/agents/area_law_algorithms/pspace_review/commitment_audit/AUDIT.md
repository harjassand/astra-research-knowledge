# Independent audit: coherent PSPACE oracle replacement and commitments

7 October 2026. This audit concerns the deductions after a PSPACE-effective synthesis theorem. It does not certify the acquired-oracle construction or its imported OpenAI 283 proof gates.

## Verdict

No fatal gap was found in the implication

    PSPACE-effective synthesis + BQP=PSPACE
        => unitaryP=unitaryPSPACE
        => no standard quantum commitments.

The first implication holds under Kretschmer–Tang's exact definitions, with uniform polynomial clocks and charged precision. The second is their Theorem 7.14 together with the standard commitment-to-EFI equivalence. Consequently the candidate, if proved, gives standard quantum commitments => BQP!=PSPACE => P!=PSPACE.

There are three distinctions to preserve:

1. Compute-copy-uncompute returns its physical work register only **approximately** to zero. Exact cleanup is false in general. This is sufficient: restricted operator-norm approximation implies closeness to an exact clean extension by KT Lemma 5.3.
2. The direct KT separation is **Theorem 7.14**, not Corollary 7.16. The latter adds a separate synthesis-versus-BPP/NEXP dichotomy.
3. Standard uniform honest generation is essential to the imported EFI theorem. Nonuniform adversaries, including adversaries with quantum advice, pose no problem because the attack obtained here is uniform and uses no advice. Arbitrary quantum auxiliary input supplied to honest parties is a different model, to which this proof does not extend automatically.

An additional dependency reduction is available: the commitment consequence needs only PSPACE-effective **constant-error channel synthesis**. Polynomial-copy amplification of the EFI trace gap lets the released full-diamond error 1/2 suffice. Neither a full-precision theorem nor phase-sensitive clean unitary synthesis is needed for this particular consequence. The stronger poly(n,log(1/epsilon)) bound is still needed for equality of the full KT unitary classes. The exact constant-error reduction is proved in `CONSTANT_COMMITMENT_REDUCTION.md`; Section 4 below states it as the primary cryptographic route.

## Primary sources and exact locations

Kretschmer and Tang, *Unitary complexity in polynomial space*, arXiv:2610.03705v2, 5 October 2026:

https://arxiv.org/pdf/2610.03705v2

https://arxiv.org/src/2610.03705v2

The exact source archive was acquired in this audit; its `arxiv-v2.tex` is saved beside this note. Relevant locations in that source:

- Definition 4.5: lines 750–758; unary size parameter, fixed-point precision of length O(log(1/epsilon)); polynomial-time generator has a write-only output tape.
- Definition 5.2: lines 855–861; time-uniform unitary implementations on poly(n,log(1/epsilon)) qubits, epsilon-close in full operator norm to some exact zero-workspace extension.
- Lemma 5.3: lines 877–882, printed p16; restricted epsilon/2 error implies full-space epsilon closeness to an extension.
- Proposition 5.8: lines 1003–1012 and proof beginning 1017; BQP language embeddings are in unitaryP at arbitrary precision.
- Proposition 5.10: proof around lines 1066–1111; unitaryP and unitaryPSPACE are self-low.
- Theorem 6.17: lines 1847–1865, printed p30; PSPACE matrix-entry characterization for classical oracles.
- Definition 7.13: lines 2394–2418, printed p38; time-uniform EFI generators and nonuniform adversaries allowed by footnote 8.
- Theorem 7.14: lines 2423–2482, printed pp38–39; EFI => unitary class separation.

Brakerski, Canetti, and Qian, *On the Computational Hardness Needed for Quantum Cryptography*, ITCS 2023:

https://doi.org/10.4230/LIPIcs.ITCS.2023.24

https://arxiv.org/abs/2209.04101

- Section 1.2, printed p24:9, explicitly asks EFI => BQP!=PSPACE and points to PSPACE-oracle Helstrom synthesis as a route.
- Section 2, Definition 6, printed p24:12: the standard security definition allows nonuniform quantum advice for adversaries; reductions are uniform/advice-preserving.
- Definition 7, printed p24:13: EFI generation is by a uniform QPT algorithm on (1^s,b) and all-zero ancillary registers.
- Theorem 13, printed p24:14: EFI states, statistically binding canonical commitments, general commitments, and semi-honest oblivious transfer are equivalent in the stated standard model.

Local source copies and extracted PDF text are preserved in this directory. The alternate local HTML file is `work/agents/quantum_complexity/sources/unitary_pspace.html`; the requested `oracle_synthesis/sources/unitary_pspace.html` does not exist.

## 1. Formal deduction using the paper's own closure lemmas

Write S for the candidate synthesis premise

    unitaryPSPACE subset unitaryP^PSPACE.

The superscript is an existential union over one fixed total PSPACE language per target family, not a changing per-input oracle/advice string. The candidate's f_U meets this interface if its acquisition proof closes.

Assume BQP=PSPACE. For every L in PSPACE, L is in BQP. KT Proposition 5.8 then puts the unitary language embedding

    O^L_m |x,b> = |x,b XOR L(x)>

in unitaryP, with phase retained and arbitrary precision supported uniformly. Therefore any U in unitaryP^L is in unitaryP^unitaryP, which equals unitaryP by Proposition 5.10. Hence

    unitaryPSPACE subset unitaryP^PSPACE
                  subset unitaryP^unitaryP
                  = unitaryP.

The reverse containment is immediate. This avoids needing a novel coherent-computation theorem for the final class-collapse deduction. Proposition 5.8 uses an exponentially small decision error to overcome a generic column-to-operator-norm loss; amplification still costs only polynomial(address length + log(1/error)). The address-preserving construction below gives a sharper bound, but either proof suffices.

The candidate begins with a restricted error `||C iota - iota U||<=e`. Invoke its generator with e<=epsilon/2, then apply KT Lemma 5.3. Spending this constant factor puts the construction in the official full-extension definition. No channel-to-unitary or global-phase identification is needed.

## 2. Explicit address-preserving coherent replacement

Let f be any fixed total language in BQP. A standard deferred-measurement unitary implementation on m-bit input can be made to retain the address exactly by copying each computational-basis input into a fresh work register and operating only on the copy. Thus an amplified decision unitary has the form

    A_m = sum_x |x><x| tensor A_x,

where measuring its answer bit after A_x|0> returns f(x) with failure p_x<=p. All intermediate measurement outcomes can be coherently retained; because the original BQP computation has polynomial time, this purification costs polynomial space and time. This construction does not require a quantum-cloning operation: CNOT copying basis labels produces the intended coherent control register.

Let T be an arbitrary oracle target qubit and S the decision scratch. Define

    Q = (I_T tensor A_m^dagger) CNOT(answer,T) (I_T tensor A_m).

For each x, decompose A_x|0> into its correct- and incorrect-answer projections. CNOT differs from the ideal X_T^{f(x)} only on the incorrect-answer component. Therefore for any state |psi> of T and an arbitrary reference,

    ||(Q_x-X_T^{f(x)} tensor I_S)(|psi> tensor |0>)||
       <= 2 sqrt(p_x) ||psi||.

Equality is attained on the target |-> if p_x is nonzero. Since x is unchanged, different x branches are orthogonal. The full restricted norm is therefore exactly

    ||(Q-O_f tensor I_S) P_zero|| = 2 sqrt(max_x p_x),

with no factor exponential in m. This is phase-sensitive vector error, not merely correctness after measuring the answer. It tensors with arbitrary references because the same operator bound applies to each controlled block.

For the candidate's p<=zeta^2/16, restricted error is at most zeta/2. Lemma 5.3 then supplies an exact clean extension Qbar of O_f with full norm `||Q-Qbar||<=zeta`. The physical Q itself need not clean scratch exactly.

Controlled f queries use Toffoli(control,answer,T) in place of CNOT. The control and address are retained. Classical Boolean oracle unitaries are real involutions, so conjugate, transpose and inverse queries coincide with the original; their controlled variants have the same error and resource bounds. More generally Q is itself exactly unitary and self-inverse.

### Reusing approximately dirty scratch is valid

Let the original circuit have q oracle gates, and replace each by Q_j. Use Qbar_j from Lemma 5.3, which exactly preserves scratch zero. Full-space telescoping gives

    ||product Q_j - product Qbar_j|| <= sum_j zeta_j.

The product with Qbar_j is an exact clean extension of the original oracle circuit. This argument remains valid when physical scratch has a small dirty component after earlier replacements, because the error norm is full-space after passing to the extensions. Alternatively, restricted telescoping can be expanded with ideal prefixes, on which scratch remains zero. Neither argument assumes exact physical reset between approximate modules.

### Uniform clock and precision accounting

Fix the BQP decider code and its polynomial time bound once for f. Under BQP=PSPACE existence of this code follows for each fixed f_U; the equality need not provide an effective algorithm for discovering the code from the PSPACE description. Unitary class membership is existential in that same per-family sense.

Suppose the synthesis generator has q(n,b) queries and query width at most ell(n,b), both polynomial in n+b. Choose

    zeta = 2^(-b-c)/(max(1,q(n,b)))

for an absolute error-budget constant c. Majority amplification takes O(log(1/zeta)) repetitions, with worst-case failure at most zeta^2/16, and all repetitions have the fixed polynomial clock of the decider at the relevant address width. Thus the substituted generator runs in polynomial(n+b) time, prints only polynomial(n+b) gates, uses polynomial(n+b) scratch, and works for every unary b. Inverses are obtained by reversing an explicitly generated finite gate list. If the original q bound is not exact, any fixed polynomial upper bound suffices.

No advice string depending on n or b has been smuggled in. Invalid addresses are part of the total language and the BQP guarantee must hold on them too. The original n and b must remain unary/length-charged in those addresses, as the polished synthesis note states.

## 3. Exact commitment distinguisher and arity repair

Let s be security parameter. Let uniform generators output d(s)-qubit mixed states rho_0,s and rho_1,s, with d(s)<=poly(s), and assume their trace distance is at least delta(s)=1/p(s) for all sufficiently large s, for one fixed polynomial p. Choose this known lower bound; the attack does not need to compute the exact trace distance.

Set A_s=rho_0,s-rho_1,s. Uniform efficient generation implies the entries of A_s admit deterministic polynomial-space approximation by a Feynman path calculation, including the partial trace of any private generator workspace. Moreover `||A_s||op<=1`. The unitary U_s=exp(i A_s) has a PSPACE entry approximator: truncate its Taylor series at degree O(log(1/epsilon)), expand each matrix product, and stream its terms at polynomial precision. The path indices use O(d(s)log(1/epsilon)) bits. KT Theorem 6.17 therefore applies after the arity padding below.

Use a unitary phase-estimation circuit V_s that estimates each eigenvalue lambda of A_s in [-1,1] with additive error

    tau(s)=delta(s)/2^(d(s)+2)

and failure at most eta(s)=delta(s)/8. Since no eigenphase wraps inside [-1,1], the sign can be decoded unambiguously except in the allowed small-eigenvalue band. The number of phase-estimation registers is polynomial(s), and the number of controlled U_s calls is exponential in polynomial(s). This is a valid space-uniform unitary computation. Its exact full unitary V_s acts on all its phase-estimation registers as part of the target input/output, even though the distinguisher initializes those registers to zero. It is not an implementation that must erase its own phase output.

For eigenvalues lambda_j and acceptance probabilities q_j after measuring whether the estimate is nonnegative,

    Adv(D_s) = sum_j lambda_j q_j
       >= delta(s) - 2^d(s) tau(s) - 2 eta(s)
       = delta(s)/2.

This uses trace(A_s)=0, sum_{lambda_j>0} lambda_j=TD(rho_0,s,rho_1,s)>=delta(s), and `||A_s||1<=2`. Thus eigenvalues arbitrarily close to zero do not require deciding exact signs.

If unitaryP=unitaryPSPACE, synthesize V_s to vector/operator error at most delta(s)/16, including zero work outside its designated target arity. For every mixed input state, a measurement probability changes by at most twice this error. Each of the two acceptance probabilities changes by at most delta(s)/8; the advantage changes by at most delta(s)/4 and remains at least delta(s)/4. This is noticeable and contradicts EFI security even against a uniform adversary.

### Formal indexing of V_s

KT's Theorem 7.14 writes `{V_n}` although footnote 9 acknowledges that V_n acts on more than n qubits. This is a harmless shorthand, but a strict proof should repair it.

Choose a strictly increasing integer polynomial N(s)=C(s+1)^k with fixed constants that majorizes d(s) and the total number of qubits of V_s. Define a genuine unitary language W by

    W_{N(s)}=V_s tensor I_(N(s)-arity(V_s)),
    W_N=I_N whenever N is outside the image of N(s).

Given 1^N, polynomial-time search recovers s if N=N(s), and otherwise chooses the identity. The entry evaluator and space-uniform circuit generator use polynomial(N+log(1/epsilon)) space. The strict indexing and every unused-arity case are now total and uniform. Under the unitary-class collapse, a time-uniform circuit for W_{N(s)} at error delta(s)/16 has size polynomial(N(s),log p(s))=polynomial(s). The adversary computes N(s), pads its state, invokes that circuit, and reads the designated phase-estimation output. No arity coincidence or nonuniform reindexing is assumed.

## 4. Primary cryptographic consequence: constant-error effective synthesis suffices

Assume only PSPACE-effectivity of the released **constant-error channel** synthesis theorem: every PSPACE-entry unitary family W has one total PSPACE Boolean oracle f_W and a polynomial-time, polynomial-resource circuit generator whose retained-output channel has full diamond error at most 1/2 from W. The released source explicitly fixes full diamond norm without a factor 1/2 (`01-introduction.tex`, `intro:diamond`). This premise is strictly weaker than equality of KT's full unitary classes and does not require phase-sensitive clean synthesis.

For the standard EFI pair at security parameter s, fix delta(s)=1/p(s) as above, with p an integer polynomial. Define **root fidelity**

    F(rho,sigma)=||sqrt(rho)sqrt(sigma)||1.

Fuchs–van de Graaf gives F<=sqrt(1-delta^2). Choose the power of two

    m(s)=2^ceil(log2(8p(s)^2)),
    sigma_b,s=rho_b,s^tensor m(s).

Then 8p(s)^2<=m(s)<16p(s)^2. Fidelity multiplies under tensors, so

    TD(sigma_0,s,sigma_1,s)
      >=1-F(rho_0,s,rho_1,s)^m(s)
      >=1-exp(-m(s)delta(s)^2/2)
      >=1-exp(-4)>31/32.

The amplified pair is still uniformly efficiently generated and computationally indistinguishable. For hybrids H_j containing j rho_0 copies and m-j rho_1 copies, choose j uniformly from {1,...,m} using exactly log2(m) fair coins, put the single challenge in slot j, and generate the other slots. The signed single-copy distinguishing advantage is exactly `[Pr(D(H_m)=1)-Pr(D(H_0)=1)]/m`. Thus any noticeable attack on the tensor pair yields a noticeable uniform attack on the original pair; no nonuniform search for a favorable hybrid index is needed. The same construction preserves any adversarial advice.

The amplified output arity is q(s)=m(s)d(s)=poly(s). Let A_s=sigma_0,s-sigma_1,s and U_s=exp(i A_s). Exactly as in Section 3, U_s has a PSPACE entry approximator. Its phase-estimation unitary V_s uses

    tau(s)=2^(-q(s)-6), eta=1/64.

The phase registers occupy poly(s) qubits; exponentially many controlled U_s calls are allowed in a space-uniform target. KT Theorem 6.17 and self-lowness, or direct polynomial-space circuit-entry evaluation, make this an exact PSPACE-entry full unitary. The inverse-exponential precision here is used to characterize the **polynomial-space target**, not to demand arbitrarily accurate polynomial-time synthesis. Polynomial injection N(s) and identity padding from Section 3 give a genuine unitary language W with N(s)=poly(s).

The ideal sign measurement on sigma_b,s has distinguishing advantage at least

    31/32-2^q(s)tau(s)-2eta
      =31/32-1/64-2/64=59/64.

Apply only the constant-error synthesis premise to W. Under BQP=PSPACE, simulate its fixed PSPACE oracle coherently with total restricted isometry error kappa=1/64. The circuit has polynomial(s) query count and address width, so amplification needs only polynomial(s) work. The output full diamond error caused by replacement is at most 2kappa=1/32. Hence the simulated channel is within `1/2+1/32=17/32` in full diamond norm of W.

For a normalized input and any measurement effect, a probability difference is at most half the trace-norm difference. Therefore each acceptance probability changes by at most 17/64, and distinguishing advantage decreases by at most 17/32. The final uniform BQP distinguisher has advantage at least

    59/64-17/32=25/64.

The uniform hybrid then gives advantage at least 25/(64m(s)) on the original EFI pair, contradicting security. Thus standard EFI/commitments imply BQP!=PSPACE if the **constant-error** synthesis oracle is PSPACE-effective. Since P subset BQP subset PSPACE, P!=PSPACE follows.

This is the primary cryptographic dependency chain. It dispenses with full Solovay–Kitaev, the arbitrary-precision polynomial-time extension, retained global phase and clean target synthesis. The acquired constant-error oracle remains load-bearing. A weaker simplification also holds: poly(n,1/epsilon) effective synthesis at inverse-polynomial epsilon already suffices without tensor amplification. Equality `unitaryPSPACE=unitaryP^PSPACE` under the official KT definition remains a separate stronger result requiring poly(n,log(1/epsilon)) resources.

The detailed independent proof, with scope and source conventions, is preserved in `CONSTANT_COMMITMENT_REDUCTION.md`.

## 5. Advice and uniformity boundary

- Uniform honest algorithms with no arbitrary shared quantum auxiliary input: covered directly by BCQ's standard equivalence and KT Theorem 7.14.
- Security against uniform adversaries: the uniform attack suffices to contradict it. Strengthening security to nonuniform polynomial circuits or BQP/qpoly does not rescue the scheme, since these classes also contain that attack.
- Classical advice only in the adversary: irrelevant to the constructed uniform attack.
- Nonuniform classical advice in honest generation: not literally KT Definition 7.13. An extension is possible by treating a polynomial-length description/advice string as an additional preserved control register in a universal circuit simulator, defining a controlled family of density-matrix exponentials, and hardcoding the actual advice into the nonuniform distinguisher. That is a separate extension, not needed for the standard claim here. If only uniform adversaries are allowed and the honest advice is uncomputable, the resulting attack need not be uniform.
- Arbitrary quantum advice or auxiliary states supplied to honest parties: their entries need not have a uniform PSPACE approximation algorithm. Neither BQP=PSPACE nor the candidate synthesis theorem supplies those amplitudes. No general implication for that model is proved by this deduction. If the supplied state's entries are independently PSPACE-effective, further consequences may follow, but that is an added premise.
- Quantum oracle models: the candidate's stated classical-oracle relativization does not authorize replacing arbitrary unitary oracle access. Preserve the restriction to classical languages.

## Failure ledger and outcome

Rejected claim: literal exact physical cleanup after BQP compute-copy-uncompute. A decider for f=0 that prepares an erroneous answer with probability p leaves a nonzero dirty-scratch component after copying into a |-> target and uncomputing. The error vector has norm 2sqrt(p), and scratch leakage is 4p(1-p). The exact-clean comparator is supplied only by an extension lemma.

Rejected attribution: calling Corollary 7.16 the direct EFI-to-unitary-separation theorem. The required statement is Theorem 7.14; Corollary 7.16 is a subsequent consequence using a separate full-synthesis premise.

Repaired shorthand: security parameter is not automatically target arity; explicit polynomial injection N(s) makes the quantum distinguisher a genuine KT unitary language.

No uniformity, error, clock, or advice flaw was found for the standard consequence. The next load-bearing audit remains the acquired PSPACE oracle construction itself, particularly canonical finite-precision selection and recursive precision storage; this deduction cannot validate those mechanisms.

Independent coherent-oracle derivation: `coherent_check.md`, prepared by an explicitly requested gpt-6.1-sol ultra subagent. That derivation is evidence of an independent mathematical audit, not external certification.
