# Coherent replacement of a fixed PSPACE Boolean oracle

**Audit outcome.** Assuming the uniform-language equality `BQP = PSPACE`, every fixed total Boolean language `f` in PSPACE has a time-uniform polynomial-size unitary replacement for its XOR oracle, with arbitrarily small **restricted operator-norm error relative to a zero-scratch ideal output**. The bound holds for superposition addresses, arbitrary target states, and arbitrary reference systems. Scratch may be reused despite the small dirt left by earlier approximate calls. The correct telescoping expansion evaluates each local error on an ideal clean-scratch prefix.

The stronger assertion that the implemented replacement returns scratch **exactly** to zero is not supplied by bounded-error amplification or compute-copy-uncompute. A finite-gate counterexample below demonstrates the failure of that inference. Thus this audit proves the approximate-clean statement needed for an approximate unitary-synthesis contract; it does not prove an additional exact-clean existential theorem from `BQP = PSPACE`.

## 1. Exact interface and quantified theorem

Fix a total language `f : {0,1}* -> {0,1}` in PSPACE. For each address width `m`, its ideal Boolean oracle is

\[
 O_{f,m}|x,b\rangle=|x,b\oplus f(x)\rangle,
 \qquad x\in\{0,1\}^{m},\ b\in\{0,1\}.
\]

The target is a qubit `T`; it need not start in a basis state. All other target/data registers, including an arbitrary reference `R`, are spectators for this query and may be entangled with `X,T`. Let `W` denote all added decision-module scratch. Define the zero-scratch embedding

\[
 J_W|\psi\rangle_{XTR}=|\psi\rangle_{XTR}|0_W\rangle,
 \qquad P_0=I_{XTR}\otimes|0_W\rangle\langle0_W|.
\]

Under `BQP = PSPACE`, there is one classical polynomial-time generator, depending on the **fixed** language and a chosen BQP decider for it, which on `(1^m,1^k)` outputs a measurement-free unitary circuit `Q_{m,k}` such that

\[
 \boxed{\left\|\bigl(Q_{m,k}-(O_{f,m}\otimes I_W)\bigr)P_0\right\|_{\rm op}
 \le 2^{-k}.}\tag{1}
\]

The same estimate holds after tensoring with any reference identity. Address `X` is preserved **exactly**, `Q_{m,k}` is exactly an involution, and a coherently controlled version has the same bound. Its gate count and scratch width are polynomial in `m+k`. Precision `k` is unary; the theorem makes no polynomial-in-`log k` claim.

The equality of complexity classes is existential: without an actual BQP machine for `f`, it does not furnish its code, numerical polynomial exponent, or a practical runtime. Once a fixed decider and its fixed polynomial clock are supplied/chosen, the construction below is a single uniform compiler, rather than one unrelated circuit chosen at each length or precision.

## 2. Coherent decider with an immutable address

By the hypothesis, fix a polynomial-time generated BQP circuit family deciding `f` with error at most `1/3` on **every** string of the relevant length. Use a fixed finite exact gate basis with efficiently available inverses. For example, an inverse-closed extension of Clifford+T, together with Toffoli and X, suffices; Toffoli is exactly implementable in Clifford+T, and `T† = T^7` if inverses are not included as primitive gates.

Purify the computation: retain erased qubits; retain measurement records coherently; replace classical feed-forward by reversible control on those records; and pad all branches to a common polynomial clock. No measurement of the oracle address is permitted. To preserve it, coherently copy its computational-basis bits by CNOT into a fresh input register and run the original computation on that copy. This is a controlled basis copy, not copying an unknown quantum state into two independent copies.

Consequently we may fix a polynomial `p(m)=c(m+1)^d`, with integer constants `c,d` dependent only on this chosen decider/compiler, that bounds circuit generation time, gate count, and workspace width of an address-preserving decision unitary `B_m`. Write

\[
 B_m=\sum_x |x\rangle\langle x|\otimes B_x.
\]

Each `B_x` has a designated output qubit with wrong-answer probability at most `1/3` on zero workspace. Any input-dependent phase or garbage is retained by the unitary; the inverse later removes it up to the controlled answer error. Merely running a measured BQP algorithm on a superposition would not establish (1).

If the intended predicate takes an external precision parameter, that parameter must already be included in the encoding of the fixed language, or be appended reversibly as known constant bits. A different uncharged predicate at every precision is not a fixed-language hypothesis. Here `m` counts the **entire** query encoding, including such fields.

## 3. Amplification with numerical constants and a polynomial clock

For desired query error `2^{-k}`, take the odd repetition count

\[
 \boxed{r=36(k+1)+1.}\tag{2}
\]

Run `r` copies of `B_m` with disjoint fresh workspace and with the same immutable address as controls. For each fixed classical address `x`, their output distributions are independent. This conditional product statement is sufficient; the shared address can remain in arbitrary superposition. Compute their majority reversibly into a designated answer qubit `a`, retaining all scratch. Call the resulting unitary `A=A_{m,k}`. It remains block diagonal in `x` and does not touch `T`.

Hoeffding's inequality gives, uniformly in `x`,

\[
 p_x:=\Pr[a\ne f(x)]\le \exp(-r/18).
\]

One explicit reversible majority circuit uses the threshold recurrence

\[
 d_{i,j}=d_{i-1,j}\lor(d_{i-1,j-1}\land b_i),
 \qquad d_{i,0}=1,\quad d_{i,j}=0\ (j>i),
\]

for `1 <= j <= i <= r`, and outputs `d_{r,(r+1)/2}`. Store each recurrence cell on a fresh wire. A fresh-wire AND takes one Toffoli; a fresh-wire OR takes two CNOTs and one Toffoli because `u OR v = u XOR v XOR uv`. Thus each cell costs four gates and two stored bits. One X gate initializes the shared constant one. This proves the following explicit enriched-basis bounds:

\[
 \begin{aligned}
 G_A(m,k)&\le r p(m)+2r(r+1)+1,\\
 w_W(m,k)&\le r p(m)+r(r+1)+1.
 \end{aligned}\tag{3}
\]

There is no need to erase the majority computation within `A`: the whole `A` is subsequently inverted. The compiler generates `B_m` once, emits `r` relabelled copies, generates the recurrence in nested loops, emits the central gate, and emits the reverse gate list with inverted gates. Gate addresses have logarithmic-length encodings. This is a deterministic polynomial-time generation algorithm; enlarging the fixed base-clock constant `c` to cover fixed compiler/encoding overhead, one may use the explicit uniform generator clock

\[
 \boxed{T_{\rm gen}(m,k)\le [r+p(m)+m+10]^6.}\tag{4}
\]

Equation (4) is a deliberately loose clock after fixing a conventional gate-list encoding and compiler. The more relevant physical circuit clock is the gate-count bound (7) below. The unknown `c,d` are the existential BQP witness costs; amplification introduces no length-dependent or precision-dependent nonuniform advice.

## 4. Compute-copy-uncompute: exact restricted norm

Let `C` be the CNOT from answer qubit `a` to target `T`, and define

\[
 \boxed{Q=A^\dagger C A.}\tag{5}
\]

This circuit is exactly unitary and satisfies `Q† = Q` and `Q^2 = I` on its **whole** Hilbert space. Since `A` preserves `X` and does not act on `T`, it commutes with the ideal oracle `O_f` extended by the identity on scratch.

For a fixed `x`, let `Pi_bad,x` be the projector onto `a = 1-f(x)`, and write

\[
 v_x=A_x^\dagger\Pi_{\rm bad,x}A_x|0_W\rangle,
 \qquad \|v_x\|=\sqrt{p_x}.
\]

For an arbitrary state `|psi>_{TR}`, the good-answer part cancels exactly, leaving

\[
 \begin{aligned}
 &(Q-O_f\otimes I_W)|x\rangle|\psi\rangle|0_W\rangle\\
 &\quad=|x\rangle
 \bigl[(X_T^{1-f(x)}-X_T^{f(x)})\otimes I_R\bigr]|\psi\rangle
 \otimes v_x.
 \end{aligned}
\]

The target operator has norm two. Different addresses give orthogonal summands because the address is exactly retained. Hence

\[
 \boxed{\|(Q-O_f\otimes I_W)P_0\|_{\rm op}
 =2\sqrt{\max_xp_x}\le2e^{-r/36}\le2^{-k}.}\tag{6}
\]

Equality in the first bound is attained by an address maximizing `p_x` and target `|->`. In particular, arbitrary targets require the factor two; a proof restricted to target `|0>` would instead give `sqrt(2 max_x p_x)` and would not prove the stated oracle interface. Tensoring with a reference changes neither the maximum nor the norm. There is **no** `2^m`, `sqrt(2^m)`, or union-bound factor for coherent addresses.

The last inequality follows from `r >= 36(k+1)` and `e > 2`:
`2 exp(-(k+1)) <= 2^{-k}`. The replacement clock from (3) is

\[
 \boxed{G_Q(m,k)\le2r p(m)+4r(r+1)+3.}\tag{7}
\]

The output has scratch leakage amplitude at most `2^{-k}` and leakage probability at most `2^{-2k}`. Thus the ideal output scratch is exactly zero and the **implemented output is close to that ideal**. This is the proved meaning of approximate cleanup.

## 5. Literal exact zero scratch fails for this construction

Take the easy total language `f(x)=0`. Prepare `t >= 2` Hadamard coin qubits and coherently compute their AND as the answer qubit, using exact reversible Boolean gates. This is a valid decision unitary with wrong-answer probability `p=2^{-t}`; `t` may be any finite polynomial precision schedule.

With target `|->`, the central CNOT is a phase flip of the answer, so compute-copy-uncompute produces

\[
 |x\rangle| -\rangle A_x^\dagger Z_a A_x|0_W\rangle.
\]

Its zero-scratch amplitude is `1-2p`. Consequently its nonzero-scratch probability is

\[
 \boxed{1-(1-2p)^2=4p(1-p)>0.}\tag{8}
\]

More generally, ` <0|v_x> = p_x` and
`||v_x-p_x|0>||^2 = p_x(1-p_x)`, so the leakage for an arbitrary target is

\[
 p_x(1-p_x)\,
 \|[X^{1-f(x)}-X^{f(x)}]|\psi\rangle\|^2.
\]

Therefore finite amplification does not turn bounded error into exact cleanup. Indeed, for the particular construction (5), requiring exact cleanup for **every** target forces `p_x(1-p_x)=0`; if the restricted error is less than two, this forces `p_x=0`, i.e. a perfect decision on every address. This is stronger than the BQP premise.

The example does not separate BQP from EQP: its language also has the exact clean replacement `I`. It refutes the inference that a bounded-error decider plus uncomputation necessarily gives exactly returned-zero workspace. This audit does not establish that no other exact-clean approximation could exist for some harder language.

There is also no full-space operator-norm approximation claim. Already with `f=0` and `A=I`, clean scratch makes (5) exact, but dirty answer scratch `|1>` makes the CNOT flip the target. Thus `||Q-I|| = 2` on the full space although its clean-input restricted error is zero.

## 6. Reused dirty scratch: the correct telescoping proof

Consider any fixed time-uniform synthesis circuit with `q` ideal Boolean queries, interleaved with ordinary unitary gates. Reserve `W` exclusively for the replacement modules, and extend **every ideal operation** by the identity on `W`. An ordinary synthesis register may contain arbitrary intermediate scratch; it is included in the unrestricted data/reference side of (6). Only the newly reserved oracle pool must be zero on ideal trajectories.

Let `U_j` denote each ideal operation and `V_j` its implemented operation, in execution order. For ordinary gates `V_j=U_j`; at query positions `U_j=O_{f,m_j} tensor I_W` and `V_j=Q_{m_j,k_j}`, acting on a suitable subset of the pool. All `V_j` are unitary even on dirty scratch. The algebraic identity is

\[
 V_L\cdots V_1-U_L\cdots U_1
 =\sum_{j=1}^L
 V_L\cdots V_{j+1}(V_j-U_j)U_{j-1}\cdots U_1.
\]

For any initial data/reference state tensored with `|0_W>`, every **right-hand ideal prefix** has scratch exactly zero. Equation (6) applies there. Each **left-hand actual suffix** has norm one, regardless of its accumulated scratch contamination. Therefore

\[
 \boxed{\|(V_L\cdots V_1-U_L\cdots U_1)P_0\|
 \le\sum_{\text{query }j}2^{-k_j}.}\tag{9}
\]

This proves that one pool can be reused. It does not apply the restricted bound to the actual dirty state and does not silently reset or discard scratch. If non-query operations deliberately use the reserved pool so that the ideal prefix makes it nonzero at a query, this particular proof loses its hypothesis; the compiler must reserve the pool or use fresh pools.

With fresh pools, each new query pool is exactly zero even on the actual incoming trajectory; old pools count as references. Fresh pools use at most `sum_j w_W(m_j,k_j)` qubits, still polynomial for polynomial `q`. Reusing a pool uses `max_j w_W(m_j,k_j)` qubits. Both are valid, but neither makes old or final scratch exactly zero.

For a unary final-precision request `1^s`, use

\[
 \boxed{k=s+\lceil\log_2\max\{1,q\}\rceil+2.}\tag{10}
\]

Then the total replacement error is at most `2^{-s-2}`. If only a fixed polynomial upper bound `Q(N,s)` for `q` is available, replace `q` in (10) by `Q(N,s)`. If the largest query encoding width is `M(N,s)` and the original circuit gate count is `H(N,s)`, explicit total gate clock is bounded by

\[
 \boxed{H(N,s)+q\,[2r p(M(N,s))+4r(r+1)+3],}\tag{11}
\]

with (2) and (10). Thus polynomial query count and polynomial address width give one polynomial clock in `N+s`, uniformly over address width and unary requested precision. Choosing, for example, `s=N` makes the added error exponentially small and therefore negligible in `N`.

If the ideal synthesis already has restricted error `eta_syn(N,s)` relative to a desired unitary output with zero logical scratch, the implemented full output, including `W`, has error at most
`eta_syn(N,s) + 2^{-s-2}` relative to that same target tensored with `|0_W>`. No other acquisition, synthesis, or original-gate precision error is erased by this oracle replacement.

## 7. Controls, inverses, and operational error

For a coherent query-enable flag `F`, implement

\[
 Q_{\rm ctrl}=A^\dagger\operatorname{Toffoli}(F,a;T)A.
\]

The `F=0` block is **exactly** `A†A=I`, including on dirty scratch; the `F=1` block is `Q`. This preserves the enable flag and address, works for superposition query/non-query control, and has the same restricted error. Address-dependent enable bits may likewise be computed reversibly while retaining the address; measurements or irreversible classical branching on superposition addresses are not allowed.

Both the ideal Boolean oracle and its replacement are exactly self-inverse. Inverse calls therefore use the same replacement module and error bound. Reversing a compiled surrounding circuit means reversing its gate list and taking the exact adjoint of each compiled gate. There is no need to invert a probability distribution or to rerun a measured procedure. The reversed ideal circuit still acts trivially on the reserved oracle pool, so (9) applies separately to its execution.

The restricted estimate is stable under entanglement and therefore bounds the norm difference of full pure output states by the same delta. Their trace distance is at most delta; after ignoring scratch, any final measurement probability differs by at most delta. This observation also covers mixed input states by purification. It does not license treating discarded scratch as exactly pure, or declaring exact unitary equality on the full enlarged register.

## 8. Primary-source cross-check and failure ledger

The construction is the standard Boolean BQP subroutine mechanism. The new content of this audit is the fully explicit interface, restricted-norm calculation, constants, and clean-trajectory telescoping proof, rather than a new complexity theorem.

- Bennett, Bernstein, Brassard, Vazirani, *Strengths and Weaknesses of Quantum Computing*, [primary paper](https://arxiv.org/html/quant-ph/9701001), Section 4.2, Theorems 4.13 and 4.14, Corollary 4.15. Their statement supplies amplification and approximate uncomputation, not literal zero scratch; the paragraph immediately before Theorem 4.14 explicitly distinguishes exact reversal for deterministic output from imperfect reversal for varied output.
- Watrous, *Quantum Computational Complexity*, [author-hosted PDF](https://cs.uwaterloo.ca/~watrous/Papers/QuantumComputationalComplexity.pdf), Section III.3 (unitary purification), Section IV.1 (polynomial-time generation), Proposition 3, and Section IV.4 / Theorem 4 / Figure 8 (BQP subroutine), printed pages 10, 12-15. These confirm the uniform circuit and approximate oracle conventions used here.

Rejected proof shortcuts: pointwise basis-input success alone without preserving address; a union bound over exponentially many coherent addresses; applying a clean-input estimate to actual dirty scratch; treating finite amplification as exact cleanup; replacing a unitary module by measured/reset computation; claiming a full-space norm bound; and treating `BQP = PSPACE` as an effectively supplied practical decider or as a free bound on its polynomial exponent.

**Decisive conclusion:** There is no coherent-substitution obstruction to a polynomial-query, time-uniform *approximate* unitary synthesis once its fixed total PSPACE language and polynomial query/width bounds are established. The module and composition bounds above prove that step. If its contract literally demands that the implemented scratch be exactly zero at each query or at completion, that extra requirement is not established by this argument and must be relaxed to the stated restricted-isometry approximation or proved by another mechanism.
