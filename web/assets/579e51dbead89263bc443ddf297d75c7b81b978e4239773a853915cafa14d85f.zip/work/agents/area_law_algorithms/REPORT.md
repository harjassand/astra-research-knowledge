# Release265: actual algorithmic consequences and failed bridges

Status: conditional consequence analysis of OpenAI/math snapshot adc7f1241b42e322a6451854ab7e4b4c146bf78a. The area-law and distributed-protocol proofs have not been externally certified here. We independently inspected the interfaces listed below and derived exact counterexamples and a finite-bit/subexponential consequence. No uniform polynomial-time ground-state algorithm or quantum PCP resolution was established.

## Inputs inspected and decisive changed premise

Source base: https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/ .

- Area-law manuscript: `A-two-dimensional-area-law-from-a-global-spectral-gap-September-24-2026/build/sections/` (downloaded under `area/`). Main area theorem is `00-introduction.tex`, `thm:area`; full-system gap only, arbitrary finite induced square-lattice domains/cuts. `03-quasilocal.tex`, `prop:positive` supplies quasi-local positive contractions annihilating the ground vector, but centers their construction using unknown expectations <Omega,h_i Omega>. They are not finitely local frustration-free terms.
- PEPS manuscript: `Polynomial-PEPS-approximation-of-gapped-square-grid-ground-states-September-24-2026/build/sections/` (downloaded under `peps/`). `00-introduction.tex`, `thm:main` gives polynomial bond dimension and vector error L^-1, uniformly in H for fixed q,J,Delta. It explicitly makes no efficient acquisition/contraction assertion.
- The actual stronger mechanism is `04-compression.tex`, `thm:compression`: distributed density compression with arbitrary finite private dimensions, bounded lifetime communication incidence, and dimension-free weighted Gaussian second moments. Together with `06-geometry.tex`, `prop:protocol`, and `07-assembly.tex`, `lem:routing`, it produces a tensor network on the square grid. This is more informative than entropy alone.
- `02-information.tex`, `prop:angular`, supplies inverse-power mutual-information bounds for angularly separated sets with logarithmic minimum separation; `03-patches.tex`, `prop:patch`, supplies polynomial inside-rank *sum* with adaptive radii, explicitly not a bound on the tensor complexity of vectors on O(log^2 L) sites.

The two serious targets attacked were (1) efficient ground-state acquisition/verification from these stronger interfaces; (2) finite classical description and a subexponential classical verification consequence. Target (1) failed in the exact senses below. Target (2) has a conditional derivation and an independent moment audit.

## Exact falsification: local Hamiltonian collar data do not determine the ground marginal

On the connected L x L grid, use qubits and define

H_s = sum_{(u,v) edges} (I - Z_u Z_v)/2 + (I - (-1)^s Z_corner)/2,  s in {0,1}.

All terms are diagonal positive projections of norm1. A computational-basis assignment has energy equal to its number of disagreeing edges plus its corner-pin disagreement.

**Proof.** Zero energy forces all bits equal, by connectedness, and the pin forces their common value s. Thus the unique ground vector is |s>^{tensor L^2}. Every other basis vector has integer energy at least1. The opposite uniform configuration has energy exactly1, so the full-system spectral gap is exactly1. For every set of sites the ground vector has entropy0, mutual information0, and PEPS bond dimension1.

The Hamiltonians H_0 and H_1 agree on every interaction supported in a collar that excludes the corner. Yet on every nonempty target set their reduced ground densities are orthogonal, with trace-norm difference2. Consequently no algorithm that depends only on such collar Hamiltonian data can approximate both target marginals within trace norm strictly below1. This defeats local reconstruction inferred solely from the full-system gap, even if all released decoupling/patch statements are granted. It does not rule out algorithms that read the full Hamiltonian: this particular pin family is globally easy.

The restriction to a pin-free collar has a degenerate ground space. Supplying a gap for the full Hamiltonian does not supply compatible boundary conditions or a ground-state selection rule for its restrictions. The gap also closes along the path that interpolates the two pins, so a gapped-path hypothesis would be an extra input.

`bridge_counterexample.py` exhaustively diagnosed the L=2,3 instances; `bridge_counterexample_results.json` records uniqueness and gap1 for both pin values. The general proof above, not the finite enumeration, proves the family.

## Computational obstruction, with tensor construction/contraction carefully separated

A Boolean circuit with fanout represented by copy gates can be embedded in a polynomial-size orthogonal square-grid drawing. Each wire gets a distinct horizontal lane and distinct vertical endpoint stubs; crossing sites retain two independent signals. Gate degree is at most3; turns, wire continuations, pins, and crossings have constant-size local truth tables. At every grid site use q=16 states indexed by four port bits (north,east,south,west). Unused ports are fixed0. A site penalty is0 on its designated truth table and1 otherwise; edge penalties require the incident port bits to agree. Padding sites force all four ports0. The output is pinned1. The grid embedding and local penalty lists are polynomial-time computable.

For each input assignment all wire/gate/unused bits are uniquely determined. Hence zero-energy grid assignments correspond bijectively to satisfying inputs of the circuit. If there is exactly one satisfying input, the Hamiltonian is diagonal, frustration-free, has a unique *product* ground state, norm-bounded nearest-neighbor terms, and full spectral gap at least1, since every nonzero energy is an integer.

Therefore any uniform polynomial-time classical routine that obtains all relevant single-site ground marginals to error <1/4, or samples the ground basis assignment with success bounded below by a constant, solves unique-SAT search. Valiant-Vazirani isolation then gives RP=NP: on a satisfiable input, a random polynomial-size isolated circuit is uniquely satisfiable with inverse-polynomial probability; the routine returns its assignment on those trials; original satisfiability is verified directly. On a nonpromised trial the routine is time-limited to its stated polynomial runtime and every returned assignment is verified; unsatisfiable instances cannot produce a false positive. If the ground-state acquisition/preparation routine is quantum, the corresponding consequence is NP subset BQP, not RP=NP.

**Do not infer hardness of tensor construction alone.** For this diagonal subclass a 0/1 PEPS of bond dimension2 is generated directly from the local truth tables:

A_v(physical four-port state t; virtual port bits b) = 1[t=b] 1[t satisfies the site truth table].

Contract edge variables by equality. The resulting vector is exactly the sum of all zero-energy grid basis assignments. Under the unique-satisfying promise it is already the normalized product ground vector. Thus even explicit constant-bond, 1-bit-entry tensors with known retained norm1 and a unique gapped product ground state do not make local-marginal contraction polynomial time unless RP=NP. Finding the D=1 representation, or extracting the represented solution, is where the information is acquired.

This is the standard classical constraint-network/PEPS mechanism; no novelty or unconditioned separation is claimed.

## Positive consequence: polynomial-bit PEPS existence

Detailed independent derivation is `../area_bridge_adversary/FINITE_BIT_AUDIT.md`. Main steps:

1. Fix a compressed party-tensor entry, including incident monomial labels, Gaussian sample indices, and physical ket/bra indices x,y. Its party-local private calculation gives contractions A_x and Atilde_y and hence O=Atilde_y^dagger A_x with ||O||<=1, even when private dimensions are arbitrary.
2. Every source slot has only one endpoint at that party. Distinct slots use independent Gaussians. With normalized product Schmidt weights P,Ptilde, Gaussian covariance gives E|T_entry|^2 <= B(L)^(4b) ||Ptilde^(1/4) O P^(1/4)||_2^2 <= B(L)^(4b). Here b is bounded lifetime gate participation and B is a polynomial coefficient-sum bound. The last inequality is Schatten Holder with exponents4,infinity,4; the probability matrices have trace1.
3. The total number of local entries is polynomial. A union bound gives a realization with every entry polynomially bounded. Increasing the polynomial sample count makes the global compression failure probability <1/4; the entry event can fail with probability <1/8. Thus accuracy and entry bounds hold simultaneously.
4. If ||sigma-|Omega><Omega|||_1<=eta, then ||sigma-|Omega><Omega|||_2<=eta. At least3/4 of product-basis Omega-amplitude mass lies on columns with relative error <=2eta. One such column has amplitude squared >=3/(4q^(L^2)), so its represented vector v has norm >=(1-2eta)sqrt(3/(4q^(L^2))) and normalized error <=4eta.
5. In a bounded-degree tensor network with n nodes, e links, link dimension D and maximum entry magnitude K, changing every entry by delta changes the output vector by at most sqrt(d) D^e n delta (K+1)^(n-1), where d is physical dimension. Here n,e=poly(L), D,K=poly(L), d=q^(L^2), and ||v||>=exp(-O(L^2)). Choosing delta=exp(-poly(L)) preserves any fixed inverse-power normalized accuracy. There are polynomial entries, so the rational description requires polynomial bits. Routing the already-rounded rational network with constant congestion preserves polynomial size and bit length.

This proves a finite classical *description* theorem conditional on the released protocol/compression premises. It avoids an unproved private-dimension or condition-number bound. It does not supply the state-dependent private contractions, good random realization, or good column.

## Consequence escalation: a classical subexponential nondeterministic verifier

Fix q,J,Delta and a precision exponent k. Consider rational-input nearest-neighbor square-grid local Hamiltonians with N=L^2 sites and a fixed inverse-polynomial energy promise b-a>=N^-k. YES instances have E_0<=a and a unique ground state with gap at leastDelta. NO instances have E_0>=b; no uniqueness/gap hypothesis is needed on NO instances for soundness.

The printed main PEPS statement freezes the target L^-1, so it alone does not give arbitrary fine energy precision. Inspection of the proof gives a straightforward *derived precision family*: prop:angular, prop:patch, thm:compression, and small-rewrite all permit any fixed inverse-power precision. Replace the fixed60 in the frame/geometry bookkeeping by a sufficiently large fixed P, replace splitting error L^-30 by L^-P/2, choose each rewrite's operator error and global compression error below the desired inverse power, and sum over <=CL^3 operations/holes. No geometry depends on P except fixed logarithmic-width constants and polynomial exponents. Thus for every fixed t>0 the same construction gives normalized vector error L^-t with bond and bit bounds polynomial in L, depending on t. This is a proof extension, not a quotation of the printed main theorem.

Choose a polynomial-bit dyadic PEPS with normalized vector error epsilon <=(b-a)/(8||H||) (or use the sharper eigenvector excess-energy bound O(||H||epsilon^2)). Guess its polynomial description nondeterministically. Compute exactly its norm squared Z and numerator Y=<Phi,H Phi> by row-wise double-layer contraction. The double-layer bond dimension is D^2 and the row frontier has O(L) indices. With D=poly(L), the arithmetic cost is exp(O(L log L)); intermediate integer/rational bit lengths are polynomial because there are polynomial tensors with polynomial-bit dyadic entries and polynomial-bit H coefficients. Repeat for the O(N) local terms, or carry an energy insertion register; either preserves this bound.

Reject Z=0. Accept if Y/Z <=(a+b)/2. On YES, the chosen witness has energy <=a+(b-a)/4; on NO every nonzero vector has energy >=b. Therefore, conditional on the released proof and the precision/finite-bit extensions,

ONE-SIDED UNIQUE-CONSTANT-GAPPED 2D LH with fixed inverse-polynomial precision is in NTIME[exp(O(sqrt(N) log N))],

with polynomial witness length. This is classical nondeterministic time measured by physical N; it is not a polynomial-time algorithm and not an NP/QCMA containment. The local-term input bit length may add a polynomial factor, and the witness/time constants depend on fixed q,J,Delta,k. No claim of prior-art priority is made.

Generic finite-bit PEPS witnesses can also be checked by a counting oracle, yielding an NP^PP-style bound, but this is no improvement over the already known QMA subset PP upper bound for local Hamiltonian decision. The nontrivial scoped resource consequence of the stronger PEPS premise is the row-width subexponential nondeterministic verification bound; historical priority remains unresolved.

## Quantum PCP geometry boundary, independent of the area law

For fixed-q, bounded-J nearest-neighbor square-grid Hamiltonians, an additive energy-density approximation already exists without any gap assumption. Divide the grid into b-by-b squares (with smaller boundary squares) and delete interactions crossing the block boundaries. There are at most2N/b such edge terms, so ||H-H_block||<=2JN/b. The blocks are independent and have at most b^2 sites. For fixed b their ground energies can be computed to the required precision by diagonalizing constant-size matrices q^(b^2), in total polynomial time in the input length. The min--max principle gives |E0(H)-E0(H_block)|<=2JN/b.

For an extensive promise gap at least epsilon N, take fixed b>=16J/epsilon and enough fixed-size eigenvalue precision that the sum of block errors is <=epsilon N/8. The total energy estimation error is <=epsilon N/4, so comparison to the promise midpoint decides the problem in deterministic polynomial time. A product of the block ground states has energy at most E0(H)+4JN/b, also giving a fixed-depth preparation description for every fixed energy-density tolerance. These are elementary separator/hyperfiniteness observations, not new consequences of release265.

Thus the strictly geometric fixed-q fixed-J setting of release265 already excludes a generic quantum-PCP-style extensive approximation hardness claim unless the relevant classical/quantum complexity classes collapse. A transfer to generic quantum PCP must leave this geometric class, allow growing dimensions/interaction strength/range, or address fine absolute energy precision. The finite-bit/subexponential witness consequence above concerns that last regime.

## Why other released arithmetic mechanisms do not remove the remaining exponential factor

Release116 noncommutative PIT applies to a *supplied bounded-size formula/algebraic path program* and an acquired full matrix evaluation. A PEPS contraction is not supplied as a polynomial-size ordinary/noncommutative formula. Row elimination naturally makes boundary matrices of dimension D^{Theta(L)}. Their construction/evaluation remains exponential. Turning each virtual path into a distinct noncommutative word prevents the cancellations that define the actual contracted tensor; it changes the problem. The hitting-point theorem also detects nonzero polynomials, whereas witness energy verification requires the sign of Y-tZ and a nonzero norm at fixed rational entries. Matrix-multiplication exponent improvements change powers of the boundary dimension and do not turn D^{Theta(L)} into poly(N).

An additional *structural compression property* sufficient for NP verification would be a supplied, efficiently checkable contraction schedule whose boundary messages have polynomial-size representations, with exact updates or certified norm errors small relative to Z. Physical area-law entropy permits exponential Schmidt rank along a length-L frontier, and even the product-ground constraint PEPS above can hide a hard contraction, so entropy/decoupling alone does not supply this property. For QCMA one instead needs a polynomial-time quantum preparation certificate with inverse-polynomial success probability or deterministic isometric preparation; bounded PEPS entries only guarantee exponentially small generic postselection success. The released Gaussian density compression produces a generally nonpositive operator network, so it provides neither form of verifier.

Strongest next attack: find a recognizable subclass of the newly constructed networks with efficiently represented *boundary contraction algebra* (e.g. an exact small algebra, stabilizer/Gaussian structure, or a certified transfer-message compiler), then prove that this property survives the state-dependent ownership operations and Gaussian density compression. The unrestricted class is blocked by the unique classical constraint-network example. One should not pursue a generic local-collar algorithm after the pin counterexample.

## Primary prior-art sources verified live

- Valiant and Vazirani, NP is as easy as detecting unique solutions (1986), abstract and original PDF: https://www.cs.princeton.edu/courses/archive/fall05/cos528/handouts/NP_is_as.pdf ; DOI https://doi.org/10.1016/0304-3975(86)90135-0 . Supports randomized unique-SAT search hardness. The square-grid port reduction above is directly reconstructed here.
- Schuch, Wolf, Verstraete, Cirac, The computational complexity of PEPS: https://arxiv.org/abs/quant-ph/0611050 . General PEPS contraction is #P-complete; this does not automatically establish hardness for every promised restricted class, which is why the direct unique-CSP argument is kept separate.
- Brandao and Harrow, Product-state Approximations to Quantum Ground States: https://arxiv.org/abs/1310.0017 . Primary prior-art context for geometric/planar approximation and quantum PCP expansion barriers; the square-block additive-energy estimate above is derived directly.
- Marriott and Watrous, Quantum Arthur-Merlin Games, Theorem3.4: https://arxiv.org/abs/cs/0506068 ; author PDF https://cs.uwaterloo.ca/~watrous/Papers/QuantumArthurMerlinGames.pdf . Existing QMA subset PP upper bound.

## Failure ledger and scope

- Entropy bound -> polynomial-time acquisition: no; direct uniqueness/constant-gap product-state examples already obstruct it.
- Separated-region MI -> collar-local H dependence: refuted exactly by H_0,H_1.
- Polynomial adaptive patch rank -> polynomial acquired basis: no; inside vectors on Theta(log^2 L) sites can have quasipolynomial dense size, and minimizers are state-dependent.
- Polynomial PEPS construction -> polynomial contraction: no; direct constraint PEPS already gives tensors efficiently while extracting unique solution stays hard under RP!=NP.
- Polynomial entries -> inverse-poly quantum preparation probability: no; generic tensor-map postselection accumulates exponential norm factors.
- NC PIT -> contraction/sign verification: supplied-formula and exponential-frontier bottleneck remains.
- Polynomial finite-bit PEPS: derived conditionally, independent moment audit completed separately.
- Subexponential nondeterministic verification: derived conditionally; arbitrary fixed inverse-power accuracy is an inspected proof extension, not the printed main statement.
- No quantum PCP boundary resolved. Full-system ground-state gap is distinct from the constant extensive approximation promise and generic near-ground states quantified by quantum PCP.
