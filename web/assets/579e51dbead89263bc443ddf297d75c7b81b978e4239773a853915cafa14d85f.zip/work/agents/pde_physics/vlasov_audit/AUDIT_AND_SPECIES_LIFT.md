# Pinned relativistic Vlasov–Maxwell audit and finite-species transfer

Status: internal source audit and conditional transfer. No independently certified global-regularity proof and no priority claim. The release is an unvalidated mathematical premise in this investigation; exact symbolic algebra below does not certify its analytic estimates.

## Source and scope

Commit: `adc7f1241b42e322a6451854ab7e4b4c146bf78a`.
Directory: `preprints/Global-classical-solutions-of-the-three-dimensional-relativistic-Vlasov-Maxwell-system-September-23-2026/build/`.
Source base: https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Global-classical-solutions-of-the-three-dimensional-relativistic-Vlasov-Maxwell-system-September-23-2026/build/

Fetched and read `main.tex`, all ten `sections/*.tex`. Source copies are in `sources/`. The only serious transfer target pursued here is a finite collection of charged massive species. Collisional and particle mean-field targets are not being claimed.

The stated initial class is nonnegative `f0 in C_c^infty(R^6)`, finite-energy fields `E0,B0 in C_b^infty cap L²`, all bounded spatial derivatives, and Maxwell divergence constraints. No background charge. A Coulomb tail with nonzero total charge is allowed. Momentum support need only be bounded on compact classical intervals. The claimed conclusion is unique global smooth existence with compact phase support on every finite slab.

## What actually changes the mathematical premise

The old bounded-momentum continuation criterion is not the new result. The release's decisive assertion is `setup.tex`, Proposition `prop:increment` (lines 37 onward): for a supported receiver, dyadic momentum majorant P, receiver scale w, and an interval of duration I wholly in w/8 <= q_X <= 8w,

    |V_X(t2)-V_X(t1)| <= M P sqrt(I) + A I P² log(2+P)/w,

with M,A independent of the actual compact classical endpoint and P. `setup.tex` then obtains a lower momentum-doubling time c/log(P); the divergent harmonic-scale sum excludes finite-time momentum blowup.

The proof's load-bearing mechanism is:

1. `cancellation.tex`, Lemma `can:identity`, lines 49–112: combine transport and source-acceleration kernels before absolute values. The kernel becomes a total source-time derivative plus a geometric residual and a receiver-acceleration term. The latter must have a small coefficient.
2. `direct.tex`, Proposition `dir:direct`: a baseline absolute-force bound loses sqrt(w).
3. `direction.tex`, Lemma `ang:direction`, lines 22–205: projected signed cancellation bounds the number of direction changes of size delta by C(M,A)L^6/delta. This uses the preliminary occupation/direct bounds and the original signed bootstrap, not improved occupation.
4. `direction.tex`, Lemma `ang:improved-hit`, lines 222–375: in the high-momentum intermediate-angle window, source-time occupation improves to (h/p) phi^(-29/25) max(1,I/I_m^0,h/I_m^0).
5. `selection.tex`, Lemma `sel:exponents`, lines 122–275: every selected bin's receiver coefficient

       U = w^(-1) min{ h²(p theta)^3, [p theta h phi²]^(-1) }

   is <= w^(-1/2) W, where W=(P theta)^(-1e-5) phi^(1e-5) h^(1e-5) is summable. This exactly removes the sqrt(w) absolute-force loss.
6. `selection.tex`, Lemmas `sel:spatial-sum`, `sel:time-weight`, and Proposition `sel:bulk-impulse`; `closure.tex`: control cutoff/weight errors and restore endpoint intervals with the original signed bootstrap, producing strict improvement and a uniform continuity closure.

The potentially dangerous chain is therefore the direction lemma -> improved occupation -> selected coefficient lemma, including constants uniform in P and the fixed bootstrap parameters. This audit read those proofs directly. No explicit counterexample or unresolved algebraic step was found there, but this is not a full independent theorem certification.

## Exact independent check of the cancellation identity

`check_signed_identity.py` uses SymPy exact rational expressions, not numerical sampling. It sets n=e3 by rotation covariance and allows arbitrary symbolic timelike receiver/source velocities a,u, arbitrary source acceleration b=u', and arbitrary receiver-time acceleration a_t. It constructs the full derivative of k0/(r d) with

    d=1-n.u, D=1-n.a, e=1-a.u,
    r'=d/D-1,
    r n'=(d/D)(a-n)+n-u,
    a'=a_t d/D,
    q^(-2)=1-|u|², q_X^(-2)=1-|a|².

All three components of the released identity's residual cancel exactly to zero. Rotation covariance extends this coordinate check to any unit n. This validates the geometric identity only. It does not validate occupation bounds, exponent selection, continuum summation, or continuation.

## Conditional finite-species theorem and exact normalization

Let the finite species index set be 1,...,N. For species alpha take mass m_alpha>0 and signed charge e_alpha in R, fixed once and for all. Use normalized momentum v=p_physical/m_alpha, so

    q(v)=sqrt(1+|v|²), u(v)=v/q(v), c_alpha=e_alpha/m_alpha.
    d_t f_alpha + u.d_x f_alpha
       + c_alpha(E+u cross B).d_v f_alpha=0.
    rho=sum_alpha e_alpha int f_alpha dv,
    j=sum_alpha e_alpha int u f_alpha dv.

Here f_alpha is number density in the normalized momentum coordinate. Physical density is obtained by the constant Jacobian m_alpha^(-3). Data: every f_alpha0 is smooth, compactly supported and nonnegative; E0,B0 have the release's field class and signed-source divergence constraints.

Conditional on the validity of the released analytic proof mechanism, the same argument gives global classical existence and uniqueness for this system, including opposite charges and unequal masses. The transfer requires redoing the simultaneous estimates below; it is not obtained by treating sum f_alpha as a scalar Vlasov solution.

### Energy and positive majorants

The local conserved energy and flux are

    U=(|E|²+|B|²)/2 + sum_alpha m_alpha int q f_alpha dv,
    S=E cross B + sum_alpha m_alpha int q u f_alpha dv.

Particle energy exchange is sum e_alpha E.int(u f_alpha), exactly canceled by Maxwell. Cone energy controls

    G² + sum_alpha m_alpha int q d f_alpha dv.

There is no requirement that the charge density be nonnegative. Put

    F_abs=sum_beta |e_beta| f_beta,
    C_charge=max_beta |e_beta|/m_beta,
    C_accel=max_beta |c_beta|.

Then global and cone integrals of q F_abs and q d F_abs are bounded by C_charge times the positive total particle-energy budgets. The velocity-shell density bound is

    int_bin F_abs dv <= C p³ nu² sum_beta |e_beta| ||f_beta0||_infty.

All former positive source-measure estimates have valid replacements using the positive disjoint-union species measure |e_beta| f_beta0(z) dz. Neutral sources contribute no Maxwell force and neutral receivers are free particles.

### Retarded formulas and signed identity

Linearity of Maxwell gives a sum of the exact retarded kernels, each weighted by e_beta. For a receiver of species alpha, multiply the field expression by c_alpha. Its source-beta contribution is

    c_alpha e_beta f_beta (T_geometry + S_geometry).

The source acceleration is now

    b_beta=(c_beta/q)(Id-u tensor u)(E+u cross B).

Its direct bounds acquire only the fixed factor |c_beta| <= C_accel. The exact `can:identity` is geometric for arbitrary u', so it remains unchanged for every ordered source-receiver pair. Its signed multiplier c_alpha e_beta stays outside integration by parts. Receiver acceleration always satisfies

    a_t=(Id-a tensor a) K_alpha/q_X,

where K_alpha=V_alpha', so no extra charge factor appears in that identity. Absolute residual/cutoff estimates use |c_alpha e_beta|. These fixed coefficients can be absorbed into constants depending on C_charge,C_accel and the aggregate initial density bound.

### Occupation, direction, selection, closure

Bootstrap the released signed increment inequality simultaneously for every supported characteristic of every species with one common M,A,P. Every source trajectory then has exactly the needed source-time momentum and velocity stability. Phase volume preservation and f_alpha transport hold species by species. Source labels form a disjoint union with a positive weighted measure; total energy bounds the union's hit mass. The common-time mass argument, joint budget sum, direction partitions, and monotone-crossing proof all carry over using that union. None requires sources and receivers to share charge-to-mass ratio.

The direct field budgets belong to the single physical field E,B and remain shared across species. The sums over species are taken into F_abs before density/energy Cauchy–Schwarz estimates, avoiding an artificial N-dependent logarithm. Numerical exponent inequalities in `sel:exponents` are unchanged. Fixed charge/mass constants alter only the choice order of M,A,P0 and C(M,A), not powers of P or the coefficient U. The bootstrap continuity argument uses the finite union of compact supported-label sets. Local uniqueness and Sobolev constructions use the finite vector (f_1,...,f_N), signed rho/j, and sums of the same energy estimates. The field modification remains valid because the Coulomb construction applies to a smooth compactly supported signed rho0. Prior multi-species continuation literature must be checked separately (child handles that).

Constants should be uniform over families of finite species systems with bounded C_charge, C_accel, positive aggregate energy, aggregate |charge|-weighted L-infinity density, common initial phase support, and the required aggregate derivative/local norms. No uniform claim for arbitrarily small masses or arbitrarily large charge-to-mass ratios is made.

## Counterexamples to shortcuts / extension failure ledger

1. Summing densities as one scalar f is wrong for different charge-to-mass ratios. If F=E+u cross B and f_total=sum f_alpha, then

       d_t f_total+u.d_x f_total
          = -F.d_v(sum c_alpha f_alpha).

   This equals -F.d_v f_total only under a special common-c_alpha condition. Opposite charge distributions already violate the proposed scalar reduction. The correct construction keeps species label measures separate and uses positive sums only for estimates.
2. Signed charge density cannot replace positive particle energy. Opposite-charge states can have rho=0,j=0 while their particle energy is arbitrarily large. Cone budgets must use mass-weighted energy, not Maxwell source magnitude alone.
3. The collisional relativistic Vlasov–Maxwell–Boltzmann model adds a gain/loss term to transport. It destroys exact f_alpha=f_alpha0 on characteristics, the preserved L-infinity bound, and a deterministic source-label measure with fixed weights. The present proof does not supply the missing collision-compatible occupation/label identity. This is an obstruction to direct transfer, not a disproof of global classical regularity.
4. A particle mean-field limit with shrinking charge regularization requires error/stability estimates with controlled dependence on particle-scale fields and derivatives. A qualitative global classical solution gives none of those constants. No unregularized point-charge derivation follows from this source audit.
5. The exact symbolic pass is only an identity check. No solver/finite fixture is used as proof of the analytic bootstrap or of the entire large-data theorem.

## Current decision

The finite-species lift is mathematically consequential but appears to be bookkeeping once the released proof is valid. It should not be advertised as a separate historical-calibre advance. The most valuable next work on this region is an independent analytic audit of `ang:direction`, `ang:improved-hit`, and the uniform selected-bin coefficient bound, or an external validation of the release. There is no stronger target justified by the evidence gathered here.

## Additional exact exponent check and computation ledger

`check_selected_exponents.py` checks the final coefficient contradiction with rational arithmetic. From the raw near/far energy inequalities one obtains Delta/z < 4/99995. The H<=2c branch contradicts H+z+6alpha<8Delta because 8Delta/z<32/99995<1. In H>2c the lower bound is H/z>99963/199990. Once the improved-occupation entry is applicable, near selection and the improved far bound give H/z<7403526/18699065. The exact positive gap is 555147/5342590. This checks the algebraic closure only; the improved-window eligibility and analytic occupation still need their stated proofs.

An earlier exact SymPy simplex diagnostic, retained as `attempt_selected_exponents_lp.py`, found maximal common strictness margin zero in the H<=2c branch and positive margin 50011/799990 without improved occupation in the H>2c branch. Its third optimization (adding improved occupation) did not finish promptly and was manually interrupted. No infeasibility conclusion was taken from that unfinished solver call. The direct rational closure certificate replaced the unfinished diagnostic; no solver output certifies the PDE proof.

A more exact collision obstruction: if along a source characteristic `d_s f=Q(f,f)` instead of zero, integrating the kernel total derivative `-f (k0/(r d))'` by parts produces the new bulk term `Q(f,f) k0/(r d)` in source-time measure. Unlike the released residuals, this term retains the source deficit factor d^(-1). Local collision conservation may preserve the energy budget, but it does not supply a bound on this new signed retarded collision contribution or on the density/occupation controls. A collision extension therefore needs an additional estimate, beyond the released geometric identity.

## Independent child audit and primary prior art

The independent child saved `extension_prior_art/PRIOR_ART_AND_EXTENSION.txt` and `extension_prior_art/DIRECTION_ADVERSARIAL_CHECK.txt`. It found no extra species-sign obstruction and no gap in the narrow weighted-first-exit/common-refinement check. It explicitly checked that bulk bounds sum over measurable unions once, that only weight derivatives cost the cell count, that receiver energy extends through each relevant source-time cell by a first-exit argument, and that exceptional retarded crossings are measured directly in source time (no incorrect dt/ds conversion). These remain scoped source audits.

Primary prior-art handles:

- Luk–Strain, arXiv:1406.0165v1, Remark 1.2, printed p.3, explicitly extends analogous continuation to multi-species; https://arxiv.org/pdf/1406.0165v1 . Theorem 1.1 is the solution-support H^5 bounded-momentum restatement imported by the release.
- Glassey, *The Cauchy Problem in Kinetic Theory*, Chapter 5, printed p.159, identifies species-specific transport and signed source sums as the proof modifications; https://epubs.siam.org/doi/10.1137/1.9781611971477.ch5 . The book proof has an approximation-support caveat and is used here as species-adaptation prior art only.
- Glassey–Schaeffer, 1988, large nearly cancelling species data, restricted assumptions; https://doi.org/10.1007/BF01218078 . Full hypotheses were not read and are not equated with arbitrary neutral data.
- Wang, arXiv:2203.01199v2, July 2026, Theorem 1.1, cylindrical covariance and weighted H^s data; https://arxiv.org/html/2203.01199v2 . It remains a symmetry-restricted large-data result.

The bounded primary-source search found no independent arbitrary-data finite-species 3D large-data classical theorem. This is not proof of absence or priority. The extension's scientific dependency remains the released signed-increment mechanism, and its novelty increment appears routine.
