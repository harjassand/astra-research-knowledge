# Luk–Strain finite-species continuation audit

Audit date: 2026-10-07. Scope: only arXiv:1406.0165v1 and arXiv:1406.0169v1. Read protocol and repository start/core files; no OpenAI release inspection. Downloaded original PDFs, extracted their complete text, and visually checked the decisive theorem/remark pages. All page numbers below are printed PDF page numbers, equal to one-based PDF pages.

## Finding

Finite many nonnegative distribution functions, fixed strictly positive rest masses, and fixed real charges (including opposite signs) do not introduce a new obstruction in these continuation arguments. The plane-support paper already explicitly announces the multi-species extension. The moment paper supplies only a normalized single-species statement; extending it is a direct proof adaptation, not a verbatim printed theorem. A claimed new result consisting only of adding finitely many species, masses, and signed charges should therefore be treated as standard-extension prior art, with the exact distinction between explicit source claim and reconstruction preserved.

## Exact primary-source record

### arXiv:1406.0165v1

Primary URLs: https://arxiv.org/abs/1406.0165v1 ; https://arxiv.org/pdf/1406.0165v1 .

The setup is one nonnegative density, with normalized mass/charge, \(p_0=\sqrt{1+|p|^2}\), equations (1)–(4), p.1. Theorem 1.2, pp.2–3, assumes compactly supported \(H^5\) particle data, \(H^5\) fields and the constraints; bounded support projected to one fixed two-plane suffices for unique \(C^1\) extension. Theorem 1.3, p.3, replaces this by an angular support envelope \(\kappa(t,\gamma)>1\), \(A=\|\kappa\|_{L^4_\gamma}\), and

\[
\int_0^T\left[A(t)^2+\left(\int_0^t A(s)^8\,ds\right)^{1/2}\right]dt<\infty.
\]

Remark 1.2, p.3, explicitly says the methods yield an “analogous continuation criterion for multi-species relativistic Vlasov-Maxwell system”; details are omitted. It does not give species cardinality, rest-mass values, or charge signs. Energy is equation (16)/Proposition 2.1, p.7; nonnegative null flux is Proposition 2.2, p.8; kernel estimates are Propositions 3.1–3.4, pp.9–11; support closure is Proposition 6.1, pp.19–20.

Exact location links: https://arxiv.org/pdf/1406.0165v1#page=3 ; https://arxiv.org/pdf/1406.0165v1#page=7 ; https://arxiv.org/pdf/1406.0165v1#page=8 .

### arXiv:1406.0169v1

Primary URLs: https://arxiv.org/abs/1406.0169v1 ; https://arxiv.org/pdf/1406.0169v1 .

The setup, p.1, again uses one nonnegative density with \(p_0=\sqrt{1+|p|^2}\). Complete-text search found no occurrence of “species” or “mass”; there is no explicit multi-species remark. Theorem 1.4, p.4, assumes weighted \(H^4\) particle data, \(H^4\) fields and local shifted particle/derivative bounds (11)–(16). Its continuation assumption (10) is a uniform bound on the time integral of \(|E|+|B|\) along every characteristic. Theorem 1.9, p.5, adds all finite initial moments (18) and

\[
\|p_0^\theta f\|_{L^\infty_t L^q_x L^1_p}<\infty,
\qquad \theta>2/q,\quad 2<q\le\infty.
\]

Remark 1.10, p.5, requires only one sufficiently high initial moment \(N_*(\theta,q)\). Energy: Proposition 2.1, p.11. Kernels: Propositions 4.1–4.4, pp.16–19; derivatives: Propositions 4.5–4.6, pp.19–23. Characteristic continuation: §5, pp.23–29. Moment estimate: Proposition 7.3, p.30; moment closure: Propositions 8.2–8.4, pp.31–35; characteristic integral closure: Propositions 8.5–8.7, pp.35–36.

Exact location links: https://arxiv.org/pdf/1406.0169v1#page=4 ; https://arxiv.org/pdf/1406.0169v1#page=5 ; https://arxiv.org/pdf/1406.0169v1#page=11 ; https://arxiv.org/pdf/1406.0169v1#page=30 .

The lower-spatial-integrability consequence is **Corollary 1.11**, printed p.5: under the data assumptions of Theorem 1.4 and initial moment assumption (18), the continuation norm (17) may instead have \(1\le q\le2\) and \(\theta>8/q-3\). At \(q=1\), this is \(\theta>5\), with a strict inequality. Its conclusion is unique continuation in the same weighted \(H^4\) and field \(H^4\) spaces. This is distinct from Theorem 1.9's \(q>2\) statement and retains the initial high-moment hypotheses.

### Approximation hypothesis: exact historical qualification

In 1406.0165, **footnote 1 on printed p.2**, attached to Theorem 1.1, says the original Glassey–Strauss theorem required the support condition (6) for all approximations. It says this extra requirement can be removed through standard energy estimates, citing [13], but with stronger initial regularity, as in the stated \(H^5\) theorem. **Remark 1.1 is not this caveat**: it records initial energy, \(L^\infty\), and momentum-support bounds.

In 1406.0169, **Theorems 1.1–1.2 on printed p.3** explicitly retain support bounds for all \(f^{(n)}\). By contrast, **§1.3.2 on printed p.7** explains that Theorem 1.4 requires its field-integral condition (10) only for the actual solution, removing the approximation assumption. This distinction should be preserved if a historical multi-species Glassey–Strauss theorem is invoked.

Exact links: https://arxiv.org/pdf/1406.0165v1#page=2 ; https://arxiv.org/pdf/1406.0169v1#page=3 ; https://arxiv.org/pdf/1406.0169v1#page=7 .

## Independent reconstruction of the species extension

This section is an inference/proof adaptation, not an additional quotation from either source.

Let \(a=1,\ldots,n\), with \(n<\infty\), \(m_a>0\), \(q_a\in\mathbb R\), and \(f_a\ge0\). In physical momentum \(p\), write

\[
\epsilon_a\(p\)=\sqrt{m_a^2+|p|^2},\qquad v_a=p/\epsilon_a,
\]
\[
\partial_t f_a+v_a\cdot\nabla_x f_a+
q_a(E+v_a\times B)\cdot\nabla_p f_a=0,
\]
\[
\rho=4\pi\sum_a q_a\int f_a\,dp,\qquad
j=4\pi\sum_a q_a\int v_a f_a\,dp.
\]

The species count and parameters are fixed. Set \(p=m_a u\) and \(g_a(t,x,u)=m_a^3 f_a(t,x,m_a u)\). Then

\[
u_0=\sqrt{1+|u|^2},\quad \widehat u=u/u_0,\quad
\partial_t g_a+\widehat u\cdot\nabla_xg_a+
\lambda_a(E+\widehat u\times B)\cdot\nabla_ug_a=0,
\quad\lambda_a=q_a/m_a.
\]

All species now have the same normalized velocity kernels as the source. They retain different force coefficients and characteristics. Put \(G=\sum_a g_a\). It is nonnegative but generally does **not** solve the one-species Vlasov equation. The proof must apply transport identities species by species and then sum, rather than falsely treating \\(G\) as a transported solution.

### Energy and null flux

Multiplying each species equation by \(\epsilon_a\) and integrating in \(p\) gives the work term \(q_a E\cdot\int v_af_a\,dp\). It cancels the field work term after summing. Thus

\[
e=\tfrac12(|E|^2+|B|^2)+4\pi\sum_a\int\epsilon_af_a\,dp,
\qquad
S=E\times B+4\pi\sum_a\int p f_a\,dp
\]

satisfy \(\partial_t e+\nabla_x\cdot S=0\). Charge signs do not enter the kinetic-energy weights. The null-cone particle flux is

\[
4\pi\sum_a\int \epsilon_a(1+v_a\cdot\omega)f_a\,dp
=4\pi\sum_a m_a\int u_0(1+\widehat u\cdot\omega)g_a\,du\ge0.
\]

Consequently the electromagnetic good-component null flux remains bounded by the positive initial energy. For fixed finitely many masses, \(m_{\min}>0\); the positive kinetic energy and flux also dominate the corresponding unweighted \\(G\) quantities up to \(m_{\min}^{-1}\). Using signed charge density as a substitute would destroy this argument.

### Maxwell kernels and derivative terms

Linearity of Maxwell's equations gives a sum of each species' retarded contribution. In normalized momentum, the \(T\) contribution carries coefficient \(q_a\), and the force-generated \(S\) contribution carries \(q_a\lambda_a=q_a^2/m_a\). The absolute bounds in the source are therefore dominated by its same nonnegative kernels applied to \\(G\), with constants depending on

\[
\max_a |q_a|,\qquad \max_a(q_a^2/m_a),\qquad
\max_a|\lambda_a|,\qquad n.
\]

Derivative formulas have the same finite coefficients. Where the source writes a positive \(\rho f\) in a derivative estimate (1406.0169, Proposition 4.5, pp.20–21), use \(|\rho|G\), with

\[
|\rho|\le4\pi\sum_a |q_a|\int g_a\,du.
\]

Cross-species products are bounded by the same moment envelope. There is no reliance on cancellation between charge signs. Initial-data terms are finite species sums of the stated initial norms.

### Characteristics, moments, and closure

Each species preserves positivity, its individual \(L^\infty\) bound, and phase-space volume. Hence \(\|G\|_\infty\le\sum_a\|g_{a,0}\|_\infty\); the sum of individual \(L^r\) norms is also bounded although \(\|G\|_{L^r}\) need not be conserved.

For a high moment define \(Y_N=\sum_a\iint u_0^Ng_a\,du\,dx\). Direct differentiation yields

\[
\frac{dY_N}{dt}
\le N\max_a|\lambda_a|\int |E(x)|
\left(\int u_0^{N-1}G(x,u)\,du\right)dx.
\]

The magnetic contribution vanishes because \(u\cdot(\widehat u\times B)=0\). The standard momentum interpolation, using the bounded \(G\) envelope, and spatial Hölder give

\[
\frac{dY_N}{dt}\le C_N\|E\|_{L^{N+3}_x}
Y_N^{(N+2)/(N+3)},
\]

and therefore

\[
Y_N(t)\le C_N\left[Y_N(0)+
\|E\|_{L^1_tL^{N+3}_x}^{N+3}\right].
\]

This supplies the species analogue of Proposition 7.3 without assuming a common transport equation. The interpolation and Strichartz inequalities used later are applied to the nonnegative envelope \\(G\). Finite coefficient changes do not alter their exponents or the sublinear closure \(Y_N\le C(1+Y_N^\alpha)\), \(\alpha<1\).

For Theorem 1.4's analogue, impose (10) uniformly over **all** species characteristics and impose the initial bounds (11)–(15) for every \(g_{a,0}\). Take finite maxima of the forward/backward characteristic derivative bounds in §5. The different forces add fixed factors \(\lambda_a\); the divergence-free transport and determinant-one argument remain valid separately. The same Gronwall/Osgood closures and weighted Sobolev continuation then apply.

For Theorem 1.9's analogue, require

\[
\|u_0^\theta G\|_{L^\infty_tL^q_xL^1_u}<\infty,
\qquad\theta>2/q,\quad2<q\le\infty,
\]

and the stated sufficiently high initial moment for each species. A finite sum of individual moment norms is equivalent for this purpose. Fixed positive masses make physical \(\epsilon_a\)-weights and normalized \(u_0\)-weights equivalent up to fixed constants.

For 1406.0165, impose the support envelope in one common physical two-plane for every species. After mass scaling, take a common normalized envelope by maximizing over finitely many species. Define support \(P\) as the maximum over all species. The source's nonnegative particle-kernel bounds apply to \\(G\), the good-field flux remains controlled, and each characteristic satisfies \(|\dot U_a|\le C|\lambda_a|\(|E|+|B|\)\). The support Osgood closure is unchanged up to constants. Separate species planes may also be analysable, but are not claimed or needed in this audit.

## Caveats and failure ledger

- **Explicit/source distinction:** only 1406.0165 Remark 1.2 announces multi-species applicability. Neither paper states a formal theorem enumerating arbitrary positive masses or signed charges. The stronger parameter statement above is reconstructed.
- **Signed-density substitution fails:** \(\sum_aq_af_a\) can cancel pointwise. It need not control source magnitudes, high moments, or positive energy. Bounds must use nonnegative species sums with absolute coefficients; energy is not charge weighted.
- **Total-density transport substitution fails:** \\(G\) has different species force coefficients. Its characteristic and exact norm conservation identities cannot simply be inherited from one species.
- **Massless/uniform limits excluded:** positive fixed masses give strict subluminal velocities, mass normalization, bounded momentum-kernel derivatives, and finite parameter constants. This audit gives no uniform \(m_a\downarrow0\) theorem.
- **Infinitely many species excluded:** finiteness permits maxima, finite source/norm sums, and \(m_{\min}>0\). A countable extension needs separate summability/coercivity hypotheses and is not established here.
- **Continuation is conditional:** none of these criteria proves an a priori bound for arbitrary large initial data. This does not establish unconditional global regularity.
- **Theorem 1.4 energy nuance:** its listed data do not expressly assume all spatially integrated particle moments. The finite-energy step in the moment theorem is justified by its added high initial moments; do not silently claim weighted \(H^4\) alone supplies global particle \(L^1\) energy on unbounded space.

## Verification record and strongest next audit

Downloaded PDFs have 21 and 37 pages. SHA256:

- `luk_1406_0165.pdf`: `a3bbd52e5e9a15ca7219fe52b15cfc8a088644d0c8abe182f52870d49ea1e223`.
- `luk_1406_0169.pdf`: `7179950cdb2f5b0ebc6e6d8217be9ad2d7f6160c1b5d374f42b441992c714110`.

Theorem/remark PDF images for 0165 p.3 and 0169 pp.4–5 were inspected. Complete text searches verified the reported presence/absence of species discussion. The decisive energy/work cancellation and summed-moment inequality were derived directly above; no numerical experiment is being substituted for proof.

The strongest further check within this scope would compare any proposed “new” multi-species criterion with the exact source hypotheses and threshold, particularly whether it drops high initial moments, reaches an endpoint, supplies mass-uniform constants, or proves the criterion a priori. Merely introducing fixed finite species and charge signs is already absorbed by the existing mechanisms.
