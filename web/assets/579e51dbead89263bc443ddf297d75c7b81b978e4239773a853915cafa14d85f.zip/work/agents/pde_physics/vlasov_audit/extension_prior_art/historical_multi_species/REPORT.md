# Historical finite-species continuation audit

Checked 2026-10-07. Scope: the named historical sources only. No new-release proof was inspected.

## Outcome

For a **fixed finite number of species with nonnegative densities, fixed positive masses, and fixed real charges**, continuation methods based on the Glassey–Strauss representations, positive energy/null flux, and positive momentum moments extend by specieswise estimates and finite positive sums. Charge signs do not destroy energy positivity. This is an adaptation checked below, not a literal application of a scalar theorem to the signed charge density.

Multi-species continuation was explicitly part of Glassey's authored 1996 presentation, and Luk–Strain explicitly recognized a multi-species extension in 2014. Arbitrary masses/signed charges are not a separately stated theorem in the three checked arXiv papers. Original 1986 full wording remains **UNVERIFIED**: its publisher page is subscription-only and the attempted PDF URL redirects to that preview. The 1996 authored reproduction is directly verified and materially stronger evidence than a secondary citation.

## Exact primary sources and locations

1. **Luk–Strain, arXiv:1406.0165v1**: [PDF](https://arxiv.org/pdf/1406.0165v1), [HTML](https://arxiv.org/html/1406.0165v1). Theorem 1.2, printed pp.2–3: nonnegative compactly supported H5 density, H5 fields satisfying constraints; common fixed-plane projected support bound yields C1 extension. Theorem 1.3, p.3, gives the angular support/integrability variant. **Remark 1.2, p.3, explicitly says the methods extend to an analogous multi-species criterion, omitting details.** Energy: Prop.2.1/equation(16), p.7; null flux: Prop.2.2, p.8; absolute field bounds: Props.3.1–3.4, pp.9–11; support closure: Prop.6.1, pp.19–20. Different masses/charge coefficients are not explicitly specified in the printed theorem.

2. **Luk–Strain, arXiv:1406.0169v1**: [PDF](https://arxiv.org/pdf/1406.0169v1), [HTML](https://arxiv.org/html/1406.0169v1). Theorem 1.4, p.4, is the uniformly bounded electromagnetic-field integral along every characteristic, with initial conditions (11)–(16). Theorem 1.9, p.5: bounded positive weighted moment M(theta,q), theta>2/q and 2<q<=infinity, under its initial moment hypotheses; Remark 1.10 permits sufficiently high finite initial moment. Setup is normalized single species; no species remark was found. Energy: Prop.2.1 p.11; field kernels: Props.4.1–4.4 pp.16–19; derivative estimates: Props.4.5–4.6 pp.19–23; continuation: section5 pp.23–29; moments/closure: Prop.7.3 p.30 and Props.8.2–8.7 pp.31–36.

   Corollary1.11, p.5: 1<=q<=2 and theta>8/q-3, with Theorem1.4 data and all initial moments(18). In particular q=1 requires theta>5. This is the low-spatial-integrability comparison used by Patel.

3. **Patel, arXiv:1607.07416v1**: [PDF](https://arxiv.org/pdf/1607.07416v1), [HTML](https://arxiv.org/html/1607.07416v1). Page1 equations(1)–(3) have one nonnegative density, unit mass and unit charge. No species/mass remark was found. Prop.1 p.2 gives positive energy; equations(11)–(14) pp.2–3 give retarded field bounds. Theorem6 p.5 assumes (16)–(21), initial moment of some order N>5, and a uniformly bounded theta-moment in L1(x,p), theta>3. Theorem7 p.6 assumes Theorem2 data and bounded L-infinity-time/Lr-space positive moment with exponent 18/(5r)-1+beta, 1<=r<=2, beta>0. These yield continuation in the stated classes. Moment estimate: Prop.20 p.13; characteristic integral: Prop.21 pp.13–15; closure: Prop.22 p.15 and ensuing pp.15–16. Theorems9–10 pp.7–8 concern varying planes.

4. **Glassey–Strauss (1986), original**: [publisher/DOI](https://link.springer.com/article/10.1007/BF00250732), *Archive for Rational Mechanics and Analysis* 92, 59–90. Title, bibliographic details, and the abstract's high-velocity criterion verified. **Exact original theorem numbering, hypotheses and multi-species remark were not verified.** Do not silently substitute the following book wording for the 1986 text.

5. **Glassey (1996), authored primary reproduction**, *The Cauchy Problem in Kinetic Theory*: [full scan](https://www.math.ens.psl.eu/~ffougeres/Ferns_files/Glassey.%20The%20Cauchy%20Problem%20in%20Kinetic%20Theory.pdf). Printed p.140 (PDF page153), section5.2/equations(5.3), explicitly formulates 1<=a<=N species with masses m_a and charges e_a. **Theorem5.2.1 p.140** uses 0<=f_a0 in C0^1, E0,B0 in C^2, div constraints and integral rho0=0; a continuous beta(t) bounds momentum support for all species, yielding a unique C1 solution for all t. Printed p.159 (PDF page172) gives species transport/source and iteration-difference modifications. Physical nonzero rest masses underlie its strict subluminal velocities; literal m_a>0 is not displayed. Preserve its neutrality hypothesis. The subsequent energy-density criterion is attributed to a different paper.

**Approximation-support distinction:** p.140 prints the support hypothesis on f_a, with no iteration index. But section5.8 pp.152–158 constructs f^(n), and p.154 repeats prior support-dependent estimates (5.32)/(5.36) uniformly in n. Page159 explicitly refers to differences f_a^(n)-f_a^(n-1). Consequently the book is secure finite-species prior-art evidence, but it does **not**, by its compressed printed statement alone, independently establish removal of the original approximation-support caveat. For modern solution-only continuation use the verified Luk/Patel statements; do not upgrade the inaccessible 1986 theorem.

The caveat is explicitly documented in **1406.0165 p.2 footnote1 to Theorem1.1**: GS1986 imposed support condition(6) on all approximations; standard energy estimates remove this condition for the actual solution under slightly stronger initial regularity, with a citation to [13]. In **1406.0169 p.3 Theorems1.1–1.2**, approximations f^(n) are retained; **section1.3.2 p.7** says Theorem1.4 removes that assumption and requires field-integral condition(10) only for the actual solution.

## Checked mathematical adaptation (independent reconstruction)

Set c=1 and let a=1,...,S, S<infinity. Use physical momentum p, epsilon_a(p)=sqrt(m_a^2+|p|^2), v_a=p/epsilon_a, m_a>0, and q_a in R. The equations are

    (partial_t+v_a.partial_x+q_a(E+v_a cross B).partial_p) f_a=0,
    rho=4pi sum_a q_a integral f_a dp,
    j=4pi sum_a q_a integral v_a f_a dp.

The Gauss constraints use these signed sources; the f_a themselves remain nonnegative. Introduce u=p/m_a, g_a(t,x,u)=m_a^3 f_a(t,x,m_a u), u0=sqrt(1+|u|^2), lambda_a=q_a/m_a. All velocities become u/u0 and each transport force gets the fixed coefficient lambda_a. Its flow preserves phase volume and the individual Lp norms.

**Positive energy:** direct integration by parts gives

    H = (1/2) integral_x (|E|^2+|B|^2)
        +4pi sum_a m_a integral_(x,u) u0 g_a,
    dH/dt=0.

The particle work is E.j, because the magnetic force is orthogonal to velocity. It cancels the Maxwell work -E.j regardless of signs of q_a. The local matter energy/flux is (4pi sum_a integral epsilon_a f_a, 4pi sum_a integral p f_a). The null-cone matter term is

    4pi sum_a m_a integral_u u0(1+u_hat.omega) g_a >=0.

Thus all energy and flux estimates survive, with constants depending on the fixed species parameters.

**Absolute field sources:** after the above normalization, retarded T contributions have coefficient q_a; retarded S contributions have coefficient q_a*lambda_a=q_a^2/m_a. Choose

    c_a=1+|q_a|+q_a^2/m_a,   G=sum_a c_a g_a >=0.

Triangle inequalities bound both kinds of field contribution by the same positive kernel functionals of G used in the scalar estimates. Also ||G||infinity <= sum_a c_a||g_a0||infinity, and its first moment is controlled by H times max_a(c_a/m_a). Spatial interpolation, Holder/Minkowski, wave Strichartz estimates, angular denominators and compact-support geometry therefore keep their exponents. With fixed finite masses, physical epsilon_a moments and normalized u0 moments are equivalent up to fixed constants.

**Moment and continuation steps:** differentiate M_N=sum_a c_a integral u0^N g_a specieswise. Magnetic work vanishes and

    |dM_N/dt| <= N max_a|lambda_a| integral_x |E|
                     sum_a c_a integral_u u0^(N-1) g_a.

The usual scalar interpolation uses the boundedness of positive G and yields the same moment exponent/closure inequality. For characteristic criteria, the supremum must range over all species' characteristic flows; each satisfies |dU_a/dt| <= |lambda_a|(|E|+|B|). The finite-species local weighted-Sobolev argument and differentiated field/iteration estimates use sums over all a. A bound on every species' continuation quantity is consequently sufficient.

**Important non-identity:** G usually does not solve one scalar Vlasov equation because the lambda_a differ. Neither does sum_a q_a g_a. The proof must apply transport/derivative bounds specieswise and sum afterward. Signed charge-density cancellation cannot replace positive species-moment control in these estimates.

## Limits and failure ledger

- No uniform theorem over growing species number, masses tending to zero, unbounded charge-to-mass ratios, or infinitely many species has been established by this check. The displayed constants make the missing uniformity explicit.
- Massless species are outside this normalization and the strict subluminal kernel argument.
- For common-plane criteria, the same plane/envelope must control the union of species supports. Different uncontrolled planes cannot be substituted without a fresh geometric argument.
- All initial regularity, finite energy and tail assumptions in the cited theorem must be imposed specieswise (or in a finite equivalent positive sum). Their omission is not justified by species counting.
- Original 1986 access failed legitimately; no institutional login, paid acquisition or people messages were attempted. The accessible authored reproduction was used with its distinct provenance preserved.

Verification: arXiv PDF/HTML checked; Patel p.5 and Glassey pp.140–142,152,154,159 visually rendered from downloaded primary documents. Exact Luk locations were independently checked by the delegated source audit at `luk_strain/REPORT.md`. Sources and relevant page renderings are in `sources/`.
