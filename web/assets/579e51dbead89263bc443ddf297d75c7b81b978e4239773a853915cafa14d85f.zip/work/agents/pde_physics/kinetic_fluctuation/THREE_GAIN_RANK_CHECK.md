# Independent check: three gains suffice for the OA363 rank lemma

Status: verified local differential-geometric lemma. This shortens the source's five-gain submersion construction. It is not a new nonuniqueness theorem, a grazing-uniform estimate, or an external priority claim.

Source: OA363 at commit adc7f1241b42e322a6451854ab7e4b4c146bf78a, `build/paper/10-nonconcentration.tex`, `lem:five-gain-rank`, `nc:rank-map`, and `nc:uniform-pullback`; parent copy `work/agents/pde_physics/boltzmann_10-nonconcentration.tex`, lines 842-983. The axial cold profiles u_{rho_i,sigma_i}(t,z)e3 are real analytic on positive times.

## Map and statement

For i=1,2,3 define

  x_i=x_{i-1}-(t_{i-1}-t_i)v_{i-1},
  p_i=u_i(t_i,z_i)e3,
  n_i=v_{i-1}-p_i,
  k_i=n_i cross L_i,
  v_i=v_{i-1}+k_i.

For any fixed nonaxial endpoint v0, positive t0, positive scales, and choices of signs, the map

  Phi_3:(t1,t2,t3,L1,L2,L3) -> (t3,x3,v3)

has rank seven almost everywhere on (0,infinity)^3 x R^9, hence on the strictly ordered region 0<t3<t2<t1<t0. The source's C1 convergence of finite-temperature maps and its bounded-density robust-pullback lemma carry over to this three-gain map.

## Clean explicit witness: every axial profile allowed

Rotate around e3 so v0=(R,0,z), R>0. Choose 0<h<tau<t0, and put

  t1=t2=tau, t3=tau-h,
  k1=0, L1=0,
  k2=e2=(0,1,0),
  k3=0, L3=0.

The first two positions coincide at x1=x2=x0-(t0-tau)v0. Write p1=a1e3,p2=a2e3; they have zero angular derivatives. Then

  n1=(R,0,b1), n2=(R,0,b2),
  v2=(R,1,z), n3=(R,1,b3),
  x3=x1-h v2.

Here b1,b2,b3 are whatever axial values the actual profiles supply. All normals are nonzero because R>0. The middle increment is perpendicular to n2 and is represented by L2=-n2 cross e2/|n2|^2. Zero first/final increments are permitted in the full analytic parameter domain.

### The first two angular blocks control all velocity directions

Use [a]_cross b=a cross b. Because delta_angular p2=0,

  delta v2=D1 delta L1+D2 delta L2,
  D1=(I-[L2]_cross)[n1]_cross,
  D2=[n2]_cross.

A vector q annihilating D2 must be parallel to n2. To also annihilate D1, (I-[L2]_cross)^T q must be parallel to n1. But

  (I-[L2]_cross)^T n2=n2+L2 cross n2=n2-k2
                                =(R,-1,b2),

which is not parallel to n1=(R,0,b1). Thus q=0 and the combined map (D1,D2) is onto R3. This conclusion is independent of all profile values and derivatives.

For any d in R3, these angular controls produce

  (delta x3,delta v3)=(-h d,d).

The last profile p3 can have angular variation through x3; it is harmless because L3=0, so its contribution through delta n3 cross L3 vanishes.

### Obtain position-only columns

For any d in n3_perp, choose delta L3=n3 cross d/|n3|^2. This changes final velocity by -d and does not change x3. Combined with the first-two angular controls it gives (-h d,0).

An explicit plane basis is

  d_A=(1,-R,0), d_B=(0,-b3,1).

Both are perpendicular to n3=(R,1,b3). Keeping t3 fixed, the second time column has

  (partial_t2 x3,partial_t2 v3)
  =(-k2-h partial_t2 v2,partial_t2 v2).

Subtract the angular control corresponding to d=partial_t2 v2 to obtain (-k2,0). Since n3 dot k2=1, k2 is not in n3_perp. More explicitly,

  det(d_A,d_B,k2)=-1,
  det(-h d_A,-h d_B,-k2)=h^2 !=0.

These are three independent position-only columns. The first-two angular blocks already span every final-velocity direction; subtracting position-only columns gives three independent velocity-only columns. Consequently the (x3,v3) block has rank six. The output time coordinate t3 has derivative zero on all these columns and derivative one on its own time column. Appending that column gives rank seven.

## Analytic continuation and pullback

The witness lies on t1=t2, which is inside the full connected analytic domain, although outside the strict collision-order region. Its nonzero minor persists near the witness, including strictly ordered times and nonzero first/final increments. Alternatively, the source's analytic-zero-set argument makes rank failure null on the full domain and therefore on the ordered region. The witness need not belong to a particular measurable mask; the source's robust-pullback lemma applies to arbitrary bounded masks after a.e. rank is established.

The finite-temperature maps replace p_i by the source's implicit thermal profiles and add spectator parameters. On compact sets the positive scale bounds and the implicit-derivative denominator >=1 give the same C1 convergence argument used by the source. The limiting map is independent of those spectators, and remains rank seven a.e. on the enlarged domain by Fubini.

## Minimality in this limiting parameterization

Two gains have two time coordinates and two effective plane coordinates per gain, at most six effective parameters. More formally, each independent gauge variation delta L_i=n_i leaves k_i and all subsequent states unchanged. These are two independent kernel directions in the two-gain ambient domain of dimension 2+6=8. Thus its rank is at most six, below the required seven. Finite-temperature spectator parameters disappear from the limiting map and do not repair that deficit. Three is therefore the smallest number that can yield the source's seven-dimensional submersion in this parameterization.

## Consequence boundary

The source's five-gain RANK lemma can be shortened to three gains by the proof above. Replacing the whole five-nonaxial-gain nonconcentration lemma additionally requires rerunning its truncations, axial-endpoint exclusions, time-gap masks, and bounded normalized-kernel estimates with a shorter chain; this differential calculation alone does not certify every downstream replacement.

There is no uniform grazing estimate here. The middle increment e2 is an O(1) deflection, unavailable on a bounded-velocity theta<=delta event law as delta->0. The hard-sphere collision plane supports a neighborhood of this witness, whereas such grazing parameter patches degenerate.
