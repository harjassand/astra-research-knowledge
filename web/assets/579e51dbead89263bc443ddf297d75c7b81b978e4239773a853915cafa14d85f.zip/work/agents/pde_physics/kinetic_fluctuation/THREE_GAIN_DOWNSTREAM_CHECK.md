# Downstream audit: three gains preserve OA363 cap nonconcentration

Status: the three-gain replacement preserves the complete source nonconcentration argument, conditional on the source's unchanged kernel, compactness, weak-limit, and C1-convergence lemmas. This checks a local proof improvement; it neither independently validates OA363 as a whole nor claims a new global nonuniqueness theorem.

Pinned source: https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Nonuniqueness-with-local-conservation-for-the-hard-sphere-Boltzmann-equation-October-5-2026/build/paper/10-nonconcentration.tex . Source copy inspected: `work/agents/pde_physics/boltzmann_10-nonconcentration.tex`.

The locator in `THREE_GAIN_RANK_CHECK.md` has been corrected from `build/sections/10-nonconcentration.tex` to `build/paper/10-nonconcentration.tex`.

## Dependency ledger

Unchanged imports:

* `nc:core-kernels`, lines 59-158: nonnegative normalized kernels, mass <=C/t at t>0, uniform tails and large-output decay; measured masks <=1; cold cores defined on all of [0,1].
* `nc:iteration-norm`, lines 196-204: ||V_n^j F(t)||_infinity <=||F||_infinity [C log(t/a)]^j/j!, for every fixed j.
* `nc:zero-in-measure`, lines 255-263: if the limiting hot density g is zero, f_n=h_n/H tends to zero in measure on compact subsets of the open spacetime region away from the velocity axis.
* `lem:axis-kernel-estimates`, lines 393-497: uniform axial input/mismatch vanishing, axial interval modulus, and nonaxial small-input estimate. None requires five iterations.
* `nc:two-axial-gains`, lines 615-719: V_n^2 1(t_n,x_n,v_n)->0 at bounded endpoints approaching the velocity axis; any later bounded finite chain is allowed.
* `nc:plane-parameters`, lines 729-766, and `nc:uniform-pullback`, lines 768-840: these do not depend on the number of gains.
* Source C1 convergence proof, lines 969-982: the recursive implicit-profile argument has exactly the same form for three profiles and nine thermal spectator coordinates.

Only the rank assertion is replaced by `THREE_GAIN_RANK_CHECK.md`. Everything below explicitly checks the remaining substitutions.

## Endpoint and path truncation: five -> any fixed j, including three

`nc:endpoint-tightness`, lines 299-376, uses no lower bound of five on chain length. At a removed tail, uniform kernel-tail mass is small; the other j-1 kernels and input are bounded by `nc:iteration-norm`. Summing j possible removed locations gives a uniform error. Large outgoing velocities make the first kernel uniformly small; j-1 later kernels are bounded. Spatial escape again makes the FIRST core kernel small, uniformly on bounded paths, and requires only bounded masses of later factors.

Thus for j=3:

1. Every increment, cold velocity, and sheet/thermal parameter can be restricted to fixed bounded sets at arbitrarily small total error, uniformly in n,t_n,x_n,v_n, with t_n in [a,1].
2. If |v_n|->infinity, V_n^3 F_n(t_n,x_n,v_n)->0.
3. If retained endpoint positions escape all neighborhoods of dilated periodic origins, the same vanishing follows.
4. Every subsequence with a positive lower bound for its three-fold integral has convergent endpoint positions and velocities after periodic translation and subselection.
5. On the translated bounded paths, physical main cores can encounter only one lattice copy, all encountered s/r_n are bounded, and physical transverse widths tend uniformly to zero. This last fact is precisely the input needed for the nonaxial small-input estimates; shortening the chain changes no spatial estimate.

For a schematic explicit error count, set M_a=max(1,C log(1/a)). If one deleted-tail operator has norm <=eta on [a,1], the sum of j deleted locations is <=2j M_a^{j-1} eta for input bounded by two. All choices may depend on fixed a and error tolerance; none depends on n. Their deterioration as a->0 is harmless because the proof always takes n->infinity first.

## Replacement of `nc:five-nonaxial-gains`

Claim: under the source lemma's hypotheses, V_n^3 f_n(tau_n,x_n,v_n)->0 whenever the translated hit endpoints converge to a nonaxial velocity.

Proof with all source truncations retained:

1. Remove uniform path/kernel tails using the three-step version above. All retained velocities, positions, increments, and cold parameters are in fixed bounded sets. Physical main-core transverse widths vanish uniformly.
2. Starting with the positive lower bound on the endpoint transverse speed, use `ker:off-axis-small-input` successively at gains i=1,2,3. Choose b_1, then b_2, then b_3 so deletion of |bar v_i|<b_i costs an assigned error. Earlier thresholds are fixed before each choice; later-chain masses are bounded by `nc:iteration-norm`. The limit ordering is unchanged: first choose the finitely many thresholds/tolerances, then n->infinity. There is a common b>0 for all retained bar v_i, including v0. Since retained cold transverse velocities tend uniformly to zero, |n_i|>=b/2 for large n.
3. Delete collision points |y_i|<rho. Conditional on earlier parameters, y_i is affine in t_i with derivative bar v_{i-1}. The time length is <=2rho/b. Current kernel mass is <=C/a and later-chain masses are bounded. Summing THREE locations gives C_a rho/b, with n-independent constant. Choose rho only after the speed thresholds.
4. The retained annular scales therefore lie in one compact interval [rho_-,rho_+] inside (0,infinity). Mesh convergence leaves finitely many scale/sign TRIPLES, with positive limiting scales. This is the same finite-list mechanism as for five tuples.
5. If U>1, target time t3 lies in [a,1], compactly inside (0,U). If U=1, delete t3>1-delta. Ordering forces all THREE times into (1-delta,tau_n), of length <=delta since tau_n<=1. The exact replacement of `nc:upper-endpoint-cost` is

       2(C/a)^3 delta^3 / 3!.

   This can be made arbitrarily small at fixed a; no weak convergence at the cap event time is used.
6. Delete t3-a<kappa and t_{i-1}-t_i<kappa for i=1,2,3, with t0=tau_n. There are FOUR boundary strips, each with three-dimensional time volume O(kappa). Total contribution is C_a kappa. On the retained set every consecutive time gap is >=kappa and t3>=a+kappa. As tau_n->1, the retained time domain lies in one fixed compact subset of 0<t3<t2<t1<1. Choose kappa after the preceding tolerances.
7. Fix one retained scale/sign triple. Apply `nc:plane-parameters` three times. The ambient parameters are THREE times, NINE L-coordinates, and NINE cold/thermal coordinates, i.e. 21 coordinates total, in a fixed compact subset of (0,infinity)^3 x R^18. The density is uniformly bounded: core amplitudes <=C/a, normals bounded above/below, retained H(v_i)/H(v_{i-1}) bounded, and all source masks/time ordering/other restrictions are arbitrary measurable factors <=1. No conditional probability normalization is introduced.
8. The target (t3,x3,v3) on the actual masked support lies in a compact B inside the open weak-limit region, bounded away from the velocity axis. Set F_n=f_n 1_B 1_{a<=t<=tau_n}, extended by zero. It is bounded by two and tends to zero in measure. The prelimit maps converge in C1 on the fixed parameter compact to the rank-seven three-gain map of `THREE_GAIN_RANK_CHECK.md`. The robust-pullback lemma therefore makes this triple's integral tend to zero.
9. Sum finitely many triples and let all deleted error tolerances tend to zero.

This establishes the three-gain nonaxial lemma with the same quantifiers/uniformities as the original five-gain lemma. The entire parameter compact need not map into B; only the measurable density's support must do so, exactly as in the source.

## Replacement of `nc:five-residual`

Keep the source positive inequality

  f_n<=d_n+V_n f_n+e_n,
  ||d_n||_infinity<=a+ell_n,
  0<=e_n<=epsilon_n.

Three substitutions, using positivity and the unchanged iteration norm, give

  f_n(t,x,v)
  <=(a+ell_n+epsilon_n)
    [1+C log(1/a)+(C log(1/a))^2/2]
    +(V_n^3 f_n)(t,x,v),
  a<=t<=tau_n.

This is the exact replacement of the five-residual equation. All statements hold on the same finite-approximation common full-measure characteristic sets. Fewer repetitions introduce no new exceptional-set requirement; the source already intersects finitely many iterations and a countable sequence a->0.

## Nonvanishing completion: all cases preserved

The l>0 branch is unchanged: either the limiting initial hot trace is nonzero, or the scalar bound with exp(2C/l) contradicts the cap. This includes l=1 and cap times tending to zero.

For l=0, tau_n->1. Assume g=0 and choose cap endpoints with f_n(tau_n,x_n,v_n)>=1/2. Fix a>0. The three-step endpoint lemma rules out large velocities or spatial escape whenever a residual has a positive lower bound. For any remaining subsequence, take translated convergent endpoints.

* Axial limiting velocity: positivity and the iteration norm give the explicit bound

      (V_n^3 f_n)(tau_n,x_n,v_n)
      <=2 C log(1/a) (V_n^2 1)(tau_n,x_n,v_n)->0.

  This uses the unchanged two-axial-gain lemma and only ONE later gain. The larger source chain used three later gains; shortening it makes this requirement weaker.
* Nonaxial limiting velocity: the three-gain nonaxial lemma applies to `nc:zero-in-measure` and gives residual vanishing.

Every subsequence is covered, so the full residual tends to zero. The modified residual inequality yields

  1/2<=a [1+C log(1/a)+(C log(1/a))^2/2].

Let a->0 after n->infinity. The right side tends to zero, contradicting the cap. The cases U=1 and U=infinity remain covered: U=1 is handled by the explicit delta^3 endpoint deletion; U=infinity only needs the same finite target-time compact.

## Adversarial checks / nonclaims

* No step needs three bounded later gains after the axial pair: it explicitly accepts ANY fixed bounded finite chain, including the single one left here.
* The source axial-interval modulus and the five collapsed axial speeds belong to the TWO-AXIAL-GAIN proof and must NOT be replaced by three collapsed speeds. That whole lemma stays unchanged. Only chain-count occurrences of five are shortened.
* None of the rank proof's zero-increment/equal-time witness constraints is imposed on retained integrations. The analytic rank assertion is a.e. on all strictly ordered parameters, so positive gap truncations and arbitrary bounded masks remain valid.
* No estimates uniform in grazing angle are asserted. All kernel constants and the new rank map concern the source hard-sphere kernel and fixed jet parameters.
* This does not strengthen the global theorem's data class, uniqueness/nonuniqueness conclusion, or physical scaling. It reduces the necessary nonaxial regularization depth from five gains to the minimum three and simplifies the cap nonconcentration proof.

Final assessment: FULL three-gain replacement is reviewable and supported by the unchanged source inputs; no downstream truncation, axis-estimate, endpoint-time, periodicity, representative, or n-uniformity obstruction was found.
