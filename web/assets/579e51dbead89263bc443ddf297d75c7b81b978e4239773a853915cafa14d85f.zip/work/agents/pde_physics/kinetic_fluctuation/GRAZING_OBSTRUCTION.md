# Adversarial audit of the OA363 branching-to-grazing transfer

Status: exact algebraic obstruction, conditional only on the stated finite-cutoff kernel symmetries/integrability. This does NOT prove uniqueness for a Landau equation or disprove every possible nonuniqueness construction.

OA363 source at pinned release commit: https://github.com/openai/math/tree/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Nonuniqueness-with-local-conservation-for-the-hard-sphere-Boltzmann-equation-October-5-2026/build . Parent downloaded source excerpts are `work/agents/pde_physics/boltzmann_02-framework.tex`, `boltzmann_03-kernel.tex`, and `boltzmann_11-branching.tex`.

## Exact source interface

`02-framework.tex`, lines 17-35: hard-sphere P(f,g)=integral |(v-v_*) dot omega| f(v')g(v_*') dv_* d omega; P is symmetric for this hard-sphere kernel. nu_f(v)=2 pi integral |v-p| f(p) dp. The relative-speed cutoff is used equally in gain/loss and preserves collision symmetries.

`03-kernel.tex`, `lem:carleman`, lines 63-84: one-output gain measure is uniform on the sphere with diameter [p,xi], with total mass 2 pi |p-xi|. That uniform sphere law is specific to the hard-sphere angular kernel.

`11-branching.tex`, lines 49-64, `br:gain-mass`: integral P(B,h)=integral nu_B h. The coefficient 2 counts BOTH outgoing children, while the loss removes the parent once. The positive hot equation is therefore a branching equation, not the full conservative linearization around B.

## General finite grazing kernel: conventions repaired

Take B_delta(g,sigma)=|g| b_delta(n dot sigma), n=g/|g|, b_delta>=0 with finite beta_0,delta=integral_S2 b_delta(n dot sigma) d sigma. Assume incoming/outgoing reversibility and particle interchange, as in the usual sigma representation. Let G_delta be its bilinear gain. For an angular law supported only near sigma=n, G_delta(B,h) need not equal G_delta(h,B) POINTWISE. Consequently one cannot copy the original unsymmetrized notation 2P without checking this.

Define instead

  P_delta(B,h)=[G_delta(B,h)+G_delta(h,B)]/2,
  nu_delta,B(v)=beta_0,delta integral |v-w| B(w) dw.

Equivalently symmetrize the angular representation near both sigma=+n and sigma=-n and keep the matching normalization. Either repair preserves the physical statement that both outgoing children are counted.

The pre/post-collisional volume change then gives exactly

  integral G_delta(B,h)=integral G_delta(h,B)
  =beta_0,delta integral integral |v-w| h(v)B(w) dv dw
  =integral nu_delta,B h.

Thus, for every nonnegative B,h with finite displayed integrals,

  integral [2P_delta(B,h)-nu_delta,B h]
  =integral nu_delta,B h >0 whenever the relative-speed pairing is nonzero.

Rotations, Galilean transformations, input/output interchange, and relabeling offspring do not change this total number count.

## Fixed second moment: exact lower bound; comparability needs more

Use the deviation angle theta in [0,pi] between n and sigma. Let the one-sided grazing event law be supported in 0<=theta<=delta<=1 and normalize the momentum-transfer moment

  Lambda=integral b_delta(cos theta)(1-cos theta) d sigma >0

independently of delta. Since 1-cos theta<=delta^2/2,

  beta_0,delta >=2 Lambda delta^{-2}.

Fixed second moment plus support <=delta does NOT by itself imply beta_0,delta=O(delta^{-2}); the law could concentrate at angles much smaller than delta. For an annular profile theta in [delta/2,delta], beta_0,delta<=12 Lambda delta^{-2}, giving comparability. For the explicit constant-cap law

  b_delta(cos theta)=Lambda/[pi(1-cos delta)^2] * 1_{theta<=delta},

one has exactly beta_0,delta=2 Lambda/(1-cos delta) ~4 Lambda delta^{-2}. Replacing 1-cos theta by theta^2 merely changes the normalization constant. With a reflection-normal omega convention, grazing corresponds to omega almost perpendicular to g, not omega almost parallel to g; the same statements hold after the angular Jacobian is included.

## Concrete diverging positive semigroup mass

For the constant reference cold bath B=b_0(delta_{+u}+delta_{-u}), b_0>0, u!=0, triangle inequality gives

  nu_delta,B(v)=b_0 beta_0,delta (|v-u|+|v+u|)
              >=2 b_0 |u| beta_0,delta.

For a positive integrable solution of the hot branching equation

  partial_t h=2P_delta(B,h)-nu_delta,B h

whose mass identity is valid, its mass M_delta obeys

  M_delta'(t)>=2 b_0 |u| beta_0,delta M_delta(t),
  M_delta(t)>=exp(2 b_0 |u| beta_0,delta t) M_delta(0)
             >=exp(4 b_0 |u| Lambda t/delta^2) M_delta(0).

Accordingly this positive operator cannot have a uniform fixed-time L1 semigroup bound as delta->0 for a prescribed nonzero initial hot mass. The statement is an obstruction for this generator, not a statement that every nonlinear normalized construction must diverge.

## Full linearization cancellation

The full linearization of Q_delta(F,F) at B is

  L_delta,B h=G_delta(B,h)+G_delta(h,B)
             -h nu_delta,B-B nu_delta,h
            =2P_delta(B,h)-h nu_delta,B-B nu_delta,h.

Fubini and |v-w| symmetry give

  integral B nu_delta,h=integral h nu_delta,B.

Hence integral L_delta,B h=0 exactly, canceling the divergent branching mass. The omitted term -B nu_delta,h is order beta_0,delta in mass pairing. It is not uniformly lower order under Landau normalization. Its measure support on cold jets does not justify discarding it in a conservative weak limit. At singular B the existence/meaning of a Landau limit needs separate analysis; the zero-mass identity alone does not supply it.

## Why offspring relabeling does not rescue the OA363 proof

At one grazing event, incoming hot velocity v and cold velocity w give

  |v'-v|=|w'-w|=|v-w| sin(theta/2).

For |v|,|w|<=R this is <=R delta. Therefore one child stays near the hot parent and the other stays within R delta of the cold bath. If a hot test region D is at distance eta from supp(B), then, when R delta<eta, the cold-like child supplies no birth into D. Reclassifying it as cold makes the number of hot children ONE, so the source's two-child reproduction mechanism disappears in that region.

A tagged-one-child generator K_delta h-nu_delta,B h is mass conservative, but it is a different equation. It omits a gain child; the full conservative linearization instead retains both gains and subtracts the corresponding background loss. Neither operation preserves the original positive branching equation.

On a fixed bounded velocity set, j grazing deflections can move a tagged velocity by at most j R delta. Thus a fixed finite gain sequence cannot carry the original hard-sphere O(1)-angle reachability/separation patches uniformly into the grazing limit. Uniform-in-delta diffusive estimates would require O(delta^{-2}) collisions and the signed gain/loss cancellation. OA363's hard-sphere uniform-sphere patches, finite-gain rank/minor argument, and positive branching weights do not by themselves provide those estimates. This does not rule out a different argument.

Rescaling time by delta^2 keeps the positive mass rate finite but makes its cumulative angular diffusion moment scale to zero. It does not retain the prescribed Landau physical time. Exponentially shrinking a seed can offset the mass growth, but adds a new delta-dependent normalization and does not prove uniform nonlinear bounds, a common nonzero initial datum, or separation in the limit.

## Primary grazing literature checked

* Desvillettes, *On asymptotics of the Boltzmann equation when the collisions become grazing* (1992), https://doi.org/10.1080/00411459208203923 : linearized grazing limits are established prior art.
* Alexandre--Villani, *On the Landau approximation in plasma physics* (2004), https://ems.press/journals/aihpc/articles/4077202 : spatially inhomogeneous limits use the conservative operator and mass/energy/entropy/entropy-production estimates.
* Le Bihan--Winter, *The grazing collisions limit from the linearized Boltzmann equation to the Landau equation for short-range potentials*, https://arxiv.org/abs/2208.14918 and https://doi.org/10.3934/krm.2023003 : weak potential and collision-rate rescaling; this does not apply to the positive two-child generator after deleting the background loss.

Conclusion for parent: the proposed obstruction is valid after symmetrizing P for a general angular law. Strengthen the universally justified rate from '~delta^{-2}' to '>=c delta^{-2}' unless an angular profile assumption supplies the upper bound. No collision convention invalidates the mass discrepancy; relabeling only changes the operator whose positivity generated the OA363 branching argument.
