# Kinetic/fluctuation audit, 7 October 2026

Status: source-level audit and derived bookkeeping only. Neither manuscript has been independently certified by this audit. No new global Boltzmann regularity theorem or hydrodynamic fluctuation theorem was obtained.

Pinned release commit: `adc7f1241b42e322a6451854ab7e4b4c146bf78a`.

## Exact changed premise

Hard-sphere source: https://github.com/openai/math/tree/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Hard-sphere-fluctuations-on-the-regular-Boltzmann-lifespan-September-23-2026/build

`sections/01-introduction.tex`, `ass:kinetic`, `thm:main`: initial smooth probability density on whole space R^3_x x R^3_v, summable spatial Gaussian bounds on density and spatial gradient; fixed finite regular Boltzmann interval [0,T] with sup exp(2 beta |v|^2) f finite; N is grand canonical with activity mu=epsilon^{-2}, pair exclusion epsilon. The conclusion is finite-dimensional convergence of the EXACT-microscopic-expectation-centered fluctuations. The covariance is the linear fluctuating Boltzmann equation. This genuinely extends the nonequilibrium FDD interval, assuming the proof is correct. It does not establish path tightness or regular existence beyond the supplied kinetic lifespan.

The source fixes its DHM input at arXiv:2408.07818v3, 18 July 2025, with operational estimates spelled out in `sections/03-dhm-inputs.tex`, `thm:dhm-package`. Source citations are not substitutes for independently auditing the imported estimates.

## Load-bearing new connected estimates checked

`sections/06-sharp-asymptotics.tex`:

* `lem:sharp-merger-coordinates`, lines 150-230: chronological relative translations turn each component-merging contact into epsilon^2 [(v-v_*) dot omega]_+ dt d omega. A redundant contact supplies an occurrence indicator, not a freely integrated normal/time or an extra independent Jacobian. One birth phase variable per distinct line; continued lines acquire no new birth variable.
* `eq:sharp-scaling`, lines 235-239: mu^{m-h} epsilon^{2(m-c-p)} epsilon^{3p} = mu^{c-h} epsilon^p. Thus connected trees have mu^{1-h}; initial excluded-volume links gain epsilon.
* `lem:sharp-factorials`, lines 259-307: fresh-label denominators product n_i! survive; bounded complexity costs C_K (1+n)^{d_K}, while ordinary C/O flags cost C^n with base independent of K.
* `lem:sharp-summability`, lines 309-435: after removing mu^{1-h}, absolute diagram masses at slab sizes n_i are bounded by C_K (1+n)^{d_K} (C tau sqrt L)^n = C_K (1+n)^{d_K} (C T/sqrt L)^n. Energy-pair sums use n_i^{3/2} sqrt P; chronological time volumes use tau^{a_i}/a_i!; Gaussian energy integration cancels the remaining factorial powers. Choose L>(C T)^2, or L>=4(C T)^2 for base <=1/2. Here C depends on the fixed kinetic envelopes; C_K,d_K also depend on fixed L, observations, and complexity K.
* `lem:sharp-no-extra`, lines 451-625: on a finite forest, polynomial nonidentity of d cross u excludes an extra zero-diameter coincidence outside a null set. The positive-diameter tree coordinates obey x_p^epsilon(t)=x_p^0(t)+epsilon d_p. This supports finite-graph dominated convergence for the first redundant contact.
* lines 627-651 explicitly remove graph size only AFTER dominated convergence on each fixed graph, and say this needs no rate uniform in number of vertices. This is the quantitative barrier for growing horizons, not an established rate.
* `thm:sharp-cumulants`, lines 45-72: ||c_h^epsilon||_TV <= C_h mu^{1-h} for each fixed h; scaled c_1,c_2 converge against bounded continuous record tests to signed trees. Higher ordinary CLT cumulants therefore have order C_h epsilon^{h-2}, for fixed data/T/L/h. The constants are not stated uniform when T or the kinetic data depend on a second limit parameter.

`sections/05-cutoff.tex`, `prop:cutoff`: P(any pasted/true trajectory discrepancy before T) <= C_cut(T,L,data) epsilon^{21/20}, after a fixed dimensional cycle-excess threshold Gamma and a sufficiently large FIXED number of layers. The source's terminal calculation reaches epsilon^{6/5}|log epsilon|^{C_*}, then absorbs fixed logarithmic powers to state exponent 21/20.

`sections/08-transfer.tex`, `lem:center-transfer`: the source chooses p>21 to compare exact means. A concrete allowed choice p=42 gives

  |E S_true - E S_pasted| / sqrt(mu)
  <= 2 M_obs [E(N/mu)^42]^{1/42} C_cut^{41/42} epsilon^{1/40}.

The initial factorial moment bound makes the displayed N/mu moment uniformly finite; it is independent of T because both flows conserve N. For p=22 the exponent is only 1/440. Thus a growing-horizon center transfer would need C_cut(T_epsilon)^{41/42} epsilon^{1/40}->0, plus a uniformly valid epsilon threshold. No such assertion is released.

## Exact two-parameter obstacle

For a family of kinetic data indexed by a Knudsen parameter kappa, let T_kappa be the horizon in release coordinates, B_kappa its summable Gaussian input bounds, and L_kappa the layer count. A simultaneous microscopic/hydrodynamic limit must control all of the following; existence for each fixed kappa does not supply them:

1. Base r_kappa=C(B_kappa,beta,T_kappa) T_kappa/sqrt(L_kappa)<1 uniformly.
2. Layer occupancy counting. The source calls the number of vectors (n_i) polynomial only because L is fixed. Exactly,

   sum_{n>=0} binom(n+L-1,L-1) r^n=(1-r)^{-L}.

   Hence even at r=1/2 the numerical majorant sums to 2^L before the complexity polynomial. For a fixed nonnegative integer d and eta=log(3/2),

   sum_n binom(n+L-1,L-1) (1+n)^d (1/2)^n
   <= (3/2) d! eta^{-d} 4^L,

   using (1+n)^d <= d! eta^{-d} exp(eta(1+n)). This is a derived bound, not a lower bound on the actual correlations. C_K,d_K can themselves grow with L.
3. The explicit cutoff hierarchy is A_L=ell=|log epsilon|, Lambda_i=A_i^{30}, A_{i-1}=A_i^{900}. Therefore A_i=ell^{900^{L-i}}, Lambda_i=ell^{30*900^{L-i}}. For any positive fixed gamma,p,

   epsilon^gamma Lambda_i^p
   = exp[-gamma ell + 30p*900^{L-i} log ell].

   To absorb these cutoff-polynomial losses by epsilon powers one needs 900^{L-i} log ell=o(ell) (sufficient with fixed coefficients), hence L-i substantially below [log ell - log log ell]/log 900. This is a limitation of directly uniformizing this proof, not a physical upper bound on the true microscopic dynamics. If one unrealistically held all kinetic-envelope constants uniform and L=O(T^2), it already suggests T=o(sqrt(log log(1/epsilon))) for this particular hierarchy; actual second-parameter dependence is untracked.
4. Coarse complexity removal needs |log epsilon|^{C_*(L) rho} epsilon^{c_*(L) rho} small; c_*(L)>0,C_*(L) are only given at fixed L.
5. Higher cumulants need C_h(T_kappa,L_kappa,data_kappa) epsilon^{h-2}->0 for every fixed h>=3.
6. Covariance/tree convergence has only the qualitative finite-graph extra-contact result. To establish a prescribed coupling epsilon=epsilon(kappa), a recollision modulus uniform in retained graph sizes/horizons/data and a cutoff/mean error modulus are still needed.
7. Diffusive hydrodynamics also requires process tightness and tests involving unbounded polynomial velocities. The release proves only FDD for fixed compact smooth phase-space tests. Its weighted bounds are for retained diagrams and limiting trees, and it explicitly does not claim velocity-weighted microscopic expansion-remainder estimates.
8. Periodic equilibrium is outside the summable whole-space probability-density interface. Simply substituting a uniform torus Maxwellian is not a valid application.

For orientation on normalization: a physical whole-space equation (partial_t+v.grad_x) f_kappa = kappa^{-1} Q(f_kappa,f_kappa), with physical particle activity a^{-2} kappa^{-1}, can be put into the release's unit-collision convention by y=sqrt(kappa) x, s=sqrt(kappa) t, epsilon=a sqrt(kappa), and g_kappa(s,y,v)=kappa^{-3/2} f_kappa(s/sqrt(kappa),y/sqrt(kappa),v). Then activity=epsilon^{-2} exactly and g solves unit-coefficient Boltzmann. A physical diffusive horizon t=T/kappa becomes a release horizon s=T/sqrt(kappa), while the density/gradient norms grow at least as the concentration scaling dictates. Counting collisions in standard kinetic units still gives O(kappa^{-2}) collisions. This exhibits both time and data deterioration rather than silently treating only the time parameter.

A trivial nonconstructive diagonal schedule can be selected after convergence for each fixed second parameter, but it gives neither a prescribed quantitative coupling nor a new uniform estimate. It is not a historical-calibre advance.

## Stable radial manuscript audit

Source: https://github.com/openai/math/tree/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/The-Boltzmann-Grad-limit-for-stable-radial-potentials-on-regular-kinetic-intervals-September-23-2026/build

`sections/00-introduction.tex`, `thm:main`: stable fixed finite-range radial C^2 potential, possibly a repulsive singular core; C^1 probability density with summable Gaussian density/gradient bounds; fixed regular Gaussian-bounded Boltzmann interval. It concludes uniform-in-deterministic-time fixed-order factorial L1 chaos. It permits attractive wells and keeps many-body clusters in the exact microscopic flow. It has NO fluctuation theorem.

`sections/01-preliminaries.tex`, `pre:duration`: isolated two-body residence-time flux has finite integral, so its tail is at most C_M/D. This is not a many-particle cluster lifetime estimate.

`pre:scattering`: non-force-free scattering has nonzero increments outside a flux-null set. The scattering cutoffs are acquired by qualitative compact exhaustion; uniform rotational marginals are NOT conditional independence.

`sections/04-history-estimates.tex`, `hist:basic`: the mesh factor is chi_epsilon=C P^{dA}(J^{-1/2}+epsilon J/b) with J a sufficiently large fixed power of P; the once-counted Gaussian and augmented Hamiltonian avoid resetting a carried root to a fresh Maxwellian. Constants per ordinary birth are independent of L, while the epsilon threshold depends on fixed layer length b=T/L.

`sections/05-exposure.tex`, `exp:exposure`: product domination in unconditioned charts, plus exposure of k disjoint fresh regular trees, gives source_norm*(pJ)^{Cp}*(p^C epsilon^c)^{k/2}. It explicitly forbids concluding independence after normalizing a rare conditional sector. `exp:defects` gives P^{C_L p} epsilon^{c_L p}, after compact cutoff losses <=exp(-A p). `exp:finite` separately treats finitely many top roots, and explicitly asserts no algebraic rate in the small-speed/output-increment exclusion parameter eta.

`sections/06-closure.tex`, `close:summability`: for any desired a>0, choose L with C T/sqrt L < exp(-4a-20), then rarity cutoffs. Completed absolute p-label terms are <=exp(-ap) when p>=p_L and h_0<=eta_L p. It again uses binom(n+L-1,L-1)=exp(o(p)) at FIXED L.

`close:isolated-limit` then recovers actual factorial mass by positivity and conservation of (N)_s, removing cluster configurations without excluding their microscopic formation. This is a plausible important LLN mechanism to audit further, but cannot produce connected-cumulant scale mu^{1-h}. Merely combining the two released conclusions does not yield radial fluctuations, and the potential is fixed independently of epsilon, so it also does not prove a simultaneous weak-potential/grazing Newton-to-Landau limit.

## At most one serious target

Target: a quantified NONEQUILIBRIUM joint hydrodynamic fluctuation limit around a prescribed smooth regular kinetic/hydrodynamic family, initially at FDD level. The new ingredient is the regular-lifespan nonequilibrium connected-cumulant expansion. The smaller load-bearing missing theorem is a horizon/data/graph-size-uniform recollision and centering modulus that pays the explicit layer hierarchy above. This audit has not supplied that theorem. Even a polynomial finite-graph sublevel estimate alone would not control the recursively growing layers, complexity constants, or the hydrodynamic covariance limit.

Strongest next attack: replace the qualitative polynomial-nonidentity argument in `lem:sharp-no-extra` with explicit small-sublevel bounds on bounded velocity/time/direction charts; track their dependence on graph size, and couple that to the exact negative-binomial occupancy count. A claimed quantitative horizon must state epsilon(kappa), B_kappa, L_kappa, every complexity cutoff, and the epsilon threshold. Do not claim global regularity or skip the nonequilibrium kinetic-to-fluid covariance analysis.

## Primary literature / priority gates

1. Deng--Hani--Ma, https://arxiv.org/abs/2408.07818, actual imported version https://arxiv.org/abs/2408.07818v3 . Long regular-lifespan hard-sphere LLN is already prior art to this release.
2. Bodineau--Gallagher--Saint-Raymond--Simonella, *Dynamics of dilute gases at equilibrium: from the atomistic description to fluctuating hydrodynamics*, AHP 25 (2024), https://arxiv.org/abs/2210.11812 ; theorem source https://arxiv.org/html/2210.11812 . Theorem 1.1 already gives equilibrium fluctuating Stokes--Fourier as a JOINT limit on a periodic d>=3 box, with inverse mean-free time alpha^{-1}=mu_epsilon epsilon^{d-1}<=log log log mu_epsilon and alpha->0. Consequently an equilibrium fluid-fluctuation derivation is not a new target.
3. DHM, *Hilbert's sixth problem: derivation of fluid equations via Boltzmann's kinetic theory*, https://arxiv.org/abs/2503.01800 . Classical deterministic fluid derivations using regular kinetic intervals are prior art; neither a new title nor an iterated composition creates a new global regularity theorem.

Failure ledger: no unrestricted/global Boltzmann regularity; no nonequilibrium hydrodynamic result proved; no radial-potential CLT; no rate from qualitative finite-graph convergence; no uniform angular/weak-potential family; no path tightness. These are exact gates, not negative verdicts about the source theorem's fixed-parameter correctness.
