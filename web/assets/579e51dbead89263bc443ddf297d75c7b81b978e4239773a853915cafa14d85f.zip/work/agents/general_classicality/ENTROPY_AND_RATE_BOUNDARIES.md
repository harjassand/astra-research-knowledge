# Covering entropy, finite composition and rate boundaries

Status: derived consequences of GENERAL_CRITERION.md and the internally audited broadcasting proofs. Intrinsic-gap sufficiency retains a qualitative finite-mixture modulus. The broadcasting direction now has an explicit information-chain rate, recorded below and in GENERAL_M_BROADCAST_BOUND.md.

## Finite-family reconstruction modulus and a weaker entropy condition

For an integer m >= 1 and s >= 0, define

G_m(s)=sup { e(E): E is a family of at most m finite-dimensional density matrices, max_pair Delta <= s },

where the supremum is over all dimensions and e is worst-case optimal measure-and-prepare reconstruction error. These are universal, monotone in m and s, and lie in [0,1]. The fixed finite-mixture lemma plus the dominated construction prove G_m(s)->0 for each fixed m. The proof gives no computable explicit modulus for G_m because the mixture modulus is nonconstructive.

For every arbitrary experiment E with trace covering number N_E(epsilon), choosing an epsilon-net and contracting trace distance yields the exact upper bound

e(E) <= inf_(epsilon>0) [ 2 epsilon + G_(N_E(epsilon))(delta(E)) ].

Consequently uniform covering entropy can be weakened: it is enough to find epsilon_n->0 such that

G_(N_(E_n)(epsilon_n))(delta_n)->0.

This allows growing covering numbers, provided they grow sufficiently slowly relative to the intrinsic gap. It is a resource/error tradeoff, not an explicit power-law theorem.

There also exists a universal integer threshold q(s)->infinity as s decreases to zero, such that G_(q(s))(s) <= 1/q(s). To construct one, choose a decreasing sequence s_j->0 with G_j(s_j)<=1/j; take q(s) as the largest eligible j, with a finite monotone staircase definition. Thus

N_E(1/q(delta)) <= q(delta)

implies e(E)<=3/q(delta). This threshold is nonconstructive and may grow extremely slowly. No polynomial or logarithmic relation between covering size and delta follows from the present proof.

There is now a separate effective entropy condition for broadcasting. GENERAL_M_BROADCAST_BOUND.md proves that a family of m states with two-broadcast marginal error b has e<=inf_(L>=0 integer) [L b+sqrt(m ln(m)/(2*2^L))]. Hence b_n->0 and b_n log N_n(a_n)->0 for some a_n->0 suffice for EB reconstruction even when covering numbers diverge. This bound follows from finite-label adaptive information extraction, a binary broadcasting tree and minimax. It does not supply an effective root-gap finite-mixture modulus.

## Arbitrary receiver count and composition

Under the main theorem's entropy hypothesis, accurate two-receiver marginal broadcasting gives delta_n->0 by BROADCAST_CRITERION.md and hence a measure-and-prepare channel

Lambda_n(rho)=sum_z Tr(E_(n,z)rho) tau_(n,z)

with worst error tending to zero. For any prescribed integers K_n>=2, including arbitrarily fast growth, the channel

B_(n,K)(rho)=sum_z Tr(E_(n,z)rho) tau_(n,z)^(tensor K_n)

has every marginal exactly Lambda_n(rho). Its marginal error bound is independent of K_n. It uses one common classical record; receiver correlations are allowed. There is no claim that its joint output approximates rho^(tensor K_n).

For a fixed number r of independently unknown tensor factors,

F_total=product_i F_i, A_total=product_i A_i,

Delta_total <= sum_i Delta_i,

N_product(epsilon) <= product_i N_i(epsilon/r),

max_i e_i <= e_product <= sum_i e_i.

The lower error bound follows by supplying fixed known states in all other input factors and tracing all other outputs; a joint EB channel then induces a legal EB channel for the selected factor. Growing r requires separate error/entropy accounting. Accurate marginal broadcasting does not eliminate error accumulation in joint tensor-product reconstruction.

## MUB obstruction also prevents accurate two broadcasting

Let d be a prime power and use a complete set of d+1 mutually unbiased orthonormal bases, containing m=d(d+1) pure states P_x. For distinct labels the root-fidelity/affinity gap is zero within a basis, and d^(-1/2)-d^(-1) across bases. Thus delta_d tends to zero. The set is a uniform complex projective 2-design:

(1/m) sum_x P_x^(tensor 2) = (I+S)/(d(d+1)).

Take any CPTP broadcaster B:C^d -> C^d tensor C^d, and its unnormalized Choi matrix J on X tensor A tensor B, with Tr_(AB) J=I_X and Tr J=d. Put Omega_XA=|Omega><Omega|_XA, where |Omega>=sum_(j=1)^d |j>_X|j>_A is unnormalized; define Omega_XB similarly. Partial transposition of the design identity gives the average of the two marginal survival probabilities as

f_avg = Tr[J (2 I_XAB + Omega_XA tensor I_B + Omega_XB tensor I_A)] / [2 d(d+1)].

The sum of the last two terms has operator norm d+1. To see this, write them as d P_1 and d P_2, where P_1,P_2 project onto the ranges of the isometries

V_1|b>=(|Omega>/sqrt(d))_XA tensor |b>_B,

V_2|a>=(1/sqrt(d)) sum_j |j>_X tensor |a>_A tensor |j>_B.

Their overlap is V_1* V_2=I/d. Hence ||P_1+P_2||=1+1/d, and

f_avg <= (d+3)/(2(d+1)).

For a pure target P, T(tau,P)>=1-Tr(P tau), by measuring {P,I-P}. The worst label/marginal error is at least its average, so every broadcaster obeys

b_2(E_d) >= (d-1)/(2(d+1)) -> 1/2.

The standard optimal universal symmetric cloner achieves the corresponding survival bound; optimality is not required for this obstruction. Therefore the main entropy assumption cannot be removed from the sufficient direction delta->two-broadcast, as well as from delta->EB reconstruction. The MUB family already has EB error >=1-2/(d+1)->1.

Primary sources: Klappenecker and Roetteler, Mutually unbiased bases are complex projective 2-designs, https://arxiv.org/abs/quant-ph/0502031 ; Keyl and Werner, Optimal cloning of pure states, judging single clones, https://arxiv.org/abs/quant-ph/9807010 . The Choi bound above is an explicit derivation from the design identity, not a claimed new universal-cloning optimum.

## Even two bases constrain possible entropy/gap power laws

The union of two mutually unbiased bases has m=2d, delta=d^(-1/2)-d^(-1), and EB reconstruction error bounded away from zero. A short independent upper bound on average EB survival is (1+d^(-1/2))/2.

For a measure-and-prepare channel with effects E_z and prepared states tau_z, let D_1,D_2 be dephasing in the two bases. Its average pure-state survival is

(1/(2d)) sum_z Tr[E_z (D_1(tau_z)+D_2(tau_z))].

For any state tau, let p_max,q_max be the largest probabilities in those bases. The largest eigenvalue of P_a+Q_b for any pair of rank-one basis projections is 1+d^(-1/2); hence p_max+q_max<=1+d^(-1/2). Also ||D_1(tau)+D_2(tau)||<=p_max+q_max. Since sum_z E_z=I, the survival bound follows, giving

e(E_d) >= (1-d^(-1/2))/2.

At any fixed sufficiently small trace resolution, its covering number equals 2d because distinct pure states are separated by at least sqrt(1-1/d). Thus a proposed universal sufficient condition N_E(epsilon) delta^p ->0 fails for every p>2: this family has N delta^p asymptotic to 2 d^(1-p/2)->0 but constant EB error. This does not settle the p<=2 regime, or identify an optimal entropy threshold. It only rules out overly permissive power laws.

## Simultaneous copy-ladder failure without entropy control

The stronger experiment-level boundary is the dyadic copy ladder of ../broadcast_entropy_counterexample/PROOF.md. On H_(L,d)=direct_sum_(j=0)^(L-1) Sym^(2^j)(C^d), the supplied states rho_psi=(1/L) direct_sum_j psi^(tensor 2^j), with unknown pure psi, admit a legal flag-measurement/splitting broadcaster with marginal error exactly 1/L. Their pair gap telescopes to (t-t^(2^L))/L<=1/L, t=|<psi,phi>|. Discarding all but one actual copy decodes the target pure state, while every EB reconstruction would become a pure-state estimator from at most 2^(L-1) copies. For d=L2^(L-1), established Haar estimation bounds give e_EB->1. The construction remains valid for finite faithful experiments using a finite exact moment design and noise L^(-3). Thus neither delta->EB nor two-broadcast->EB is valid for arbitrary growing experiment complexity. This counterexample is independently audited in its owning directory and does not contradict the finite-label or controlled-entropy theorems.

## Pair broadcast rates cannot be linear

For two pure qubit states with real overlap c->0,

Delta=c-c^2.

The equal-prior Helstrom measurement has the same conditional error probability p=(1-sqrt(1-c^2))/2 on both labels. Prepare two copies of the selected state. Each marginal is (1-p)rho+p sigma on input rho, and conversely; its trace error is exactly

epsilon=p sqrt(1-c^2)=c^2/4+O(c^4).

Therefore the universal pair modulus must satisfy

v(epsilon) >= (2+o(1)) sqrt(epsilon)

along this sequence. A universal linear bound fails already in dimension two. This restricts a sharp future quantitative theorem; it does not refute the explicit sqrt(epsilon log(1/epsilon)) upper modulus. Independent derivation and additional fixed-pair embezzling/data-hiding probes are recorded in ../broadcast_prior_art/counterexamples.md.

## Strongest remaining target

The new research target is effective intrinsic-gap finite-mixture/finite-ensemble abelianization, including its dependence on label count. Broadcasting now has an explicit modulus by the established adaptive low-information extraction mechanism, but the logarithmic loss between its sqrt(b log(1/b)) pair bound and the sqrt(b) qubit obstruction is unresolved. Effective intrinsic-gap mixture bounds would convert the remaining qualitative characterization into a usable growing-entropy threshold. The exact no-broadcasting theorem, adaptive extraction mechanism, root-gap statistic, and normalized-Hilbert-Schmidt almost-commuting approximation are established prior art. No explicit sharp modulus or computationally efficient reconstruction is proved here.
