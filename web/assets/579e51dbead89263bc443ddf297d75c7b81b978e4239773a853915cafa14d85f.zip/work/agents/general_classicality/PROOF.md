# Approximate conservation gives classical reconstruction of bounded Gibbs experiments

Status: direct mathematical derivation, internally checked; external proof/priority review remains open. The proposed unrestricted iff statement is false. This note proves a sufficient theorem and an exact sandwich/Gibbs bridge without using the unprovided N03 proof package.

## Interface

Finite-dimensional Hilbert spaces may vary arbitrarily with n. A known density matrix ω and a fixed number k of known Hermitian contractions A_i are supplied. No preparation/compiler cost is asserted. The unknown parameter satisfies ||b||_1≤R, where R is fixed. Set S=√ω, h_b=Σ_i b_i A_i, and define

ρ_b^S = S exp(h_b) S / Tr[ω exp(h_b)],

ρ_b^G = exp(log ω+h_b) / Tr exp(log ω+h_b).

For Gibbs states the logarithm and scores are restricted to supp ω, or ω is faithful. The sandwich statement permits singular ω on the whole Hilbert space. Trace distance is T(ρ,σ)=½||ρ−σ||_1. Define

ξ=max_i ||[A_i,S]||_HS,

η=max_i,j ||[A_i,A_j]S||_HS.

Theorem (sufficiency). For fixed k,R, ξ_n→0 and η_n→0 imply the existence of one parameter-independent measure-and-prepare channel C_n such that

sup_||b||1≤R T(C_nρ_b^S,ρ_b^S)→0,

sup_||b||1≤R T(C_nρ_b^G,ρ_b^G)→0.

The retained classical alphabet can be bounded independently of the Hilbert-space dimension, at every prescribed positive error tolerance. The channel is specified from ω,A_i; it has no access to b.

The theorem is sufficient, not necessary, even if references are faithful, k=2, dimension=6, and both parameter coordinates are identifiable (see adversary report).

## 1. Random log-spectrum reduction

Fix 0<t≤1. Diagonalize S with eigenvalues s_a≥0. Choose a common random shift u uniformly in [0,t). Partition positive eigenvalues by the intervals [u+mt,u+(m+1)t) of log s_a. Zero eigenvalues form their own block. Let P_u be pinching into this decomposition and A_i'=P_u(A_i).

Replace each positive s_a by the lower endpoint of its bin, then normalize the resulting positive diagonal matrix in HS norm to obtain S'. Write ω'=(S')². Then

e^(−t)S≤S'≤e^t S,

e^(−2t)ω≤ω'≤e^(2t)ω,

||S−S'||_HS≤e^t−1,

||log ω−log ω'||_op≤2t on the common support,

[A_i',ω']=0 and ||A_i'||_op≤1.

The bin-separation probability for positive s_a,s_c is

p_ac=min(1,|log(s_a/s_c)|/t).

For 0<t≤1,

p_ac≤(3/t)|s_a−s_c|/(s_a+s_c).

Indeed, with x=|log(s_a/s_c)|, the ratio on the right is tanh(x/2). On 0≤x≤t, x/tanh(x/2)≤t/tanh(t/2)<3; on x≥t, t≤3tanh(x/2). The same bound holds when exactly one eigenvalue is zero. Terms with both zero do not contribute to the weighted norm.

For any Hermitian contraction A, put ξ_A=||[A,S]||_HS. Symmetry of |A_ac|² gives

E_u ||(A−P_uA)S||_HS²
 = ½Σ_ac |A_ac|²(s_a²+s_c²)p_ac
 ≤ (3/(2t))Σ_ac |A_ac|²|s_a−s_c|(s_a+s_c)
 ≤ (3/(2t)) ξ_A [Σ_ac |A_ac|²(s_a+s_c)²]^(1/2)
 ≤ 3ξ_A/t.

The last bound uses (s_a+s_c)²≤2(s_a²+s_c²), Trω A²≤1, and Hermiticity. Thus one shift satisfies

Σ_i ||(A_i−A_i')S||_HS²≤3kξ/t.

Fix such a shift and put d=√(3kξ/t), so every score defect is ≤d. These quantities depend on finite supplied matrices; one can choose the shift by checking the finitely many breakpoints of the pinching objective.

For later use, [A_i',S]=P_u([A_i,S]), so ||[A_i',S]||_HS≤ξ. Expanding a score commutator and writing D_i=A_i−A_i' gives

||[A_i',A_j']S||_HS≤η+2||D_iS||_HS+2||D_jS||_HS+4ξ≤η+4d+4ξ.

For example, ||D_i A_j S||≤||D_iS A_j||+||D_i[A_j,S]||≤d+2ξ. Since S'≤e^tS and both are diagonal,

η':=max_i,j ||[A_i',A_j']S'||_HS≤e^t(η+4d+4ξ).

## 2. Simultaneous commuting approximation in a central weighted trace

This is close to established almost-commuting-matrix prior art. The direct proof is included to avoid dependence on unprovided N03 material.

Let τ(X)=Trω'X on the algebra commuting with ω'. It is a normalized trace. For m Hermitian contractions X_1,...,X_m in any finite-dimensional tracial algebra, let θ=max_i,j ||[X_i,X_j]||_(2,τ).

There is a function f_m(θ)→0 as θ→0, independent of dimension and τ, such that commuting Hermitian contractions B_i satisfy max_i||X_i−B_i||_(2,τ)≤f_m(θ). Set f_1=0. The following recurrence is valid:

f_m(θ) ≤ inf_0<δ≤1 max{δ, d_m+f_(m−1)(θ+4d_m)},

d_m=√((m−1)θ/δ).

To prove it, diagonalize X_1 and randomly shift an additive spectral grid of interval width δ. Let P be its pinching. Round X_1 to a scalar in each bin (clipped to [−1,1]), with operator error≤δ, and pinch the other scores. For each j≥2,

E||X_j−PX_j||_(2,τ)²
 ≤ δ^(−1)Σ_ac τ-weight_ac |(X_j)_ac|² |λ_a−λ_c|
 ≤ δ^(−1)||[X_1,X_j]||_(2,τ)||X_j||_(2,τ)
 ≤ θ/δ.

Choose one common shift with sum defect²≤(m−1)θ/δ. Pinching preserves contractions and τ. The remaining commutators are bounded by θ+4d_m because left and right multiplication by contractions is norm-contracting in a trace. Recurse in the block algebra; every later approximant still commutes with the first rounded score.

For fixed m≥2, the recurrence gives

f_m(θ)≤C_m θ^(1/(2^m−1)) for sufficiently small θ.

For m=2 choose δ=θ^(1/3). Inductively choose δ=θ^α_m, α_m=1/(2^m−1); the propagated exponent is α_(m−1)(1−α_m)/2=α_m. No optimality is claimed. The new August 2026 Bansil–Kachkovskiy theorem already gives the two-score 1/3 exponent and a tuple construction (their Corollary 1.4 states exponent 1/3^(m−1)); this exponent accounting is not a high-consequence novelty claim.

Apply this lemma to the A_i' with central ω'. Finally round all the commuting B_i on a common mesh of width ζ>0, retaining contraction and commutation, and adding error≤ζ. Their joint spectral projectors Π_z have at most (ceil(2/ζ)+2)^k labels, independently of input dimension. Hence

a:=max_i||(A_i−B_i)S'||_HS≤e^t d+f_k(η')+ζ.

For k=1, f_1=0 and this formula still applies.

## 3. Explicit channel and sandwich error

Measure the common spectral projections Π_z of the B_i. For p_z=Trω'Π_z>0 prepare

τ_z=Π_zω'Π_z/p_z.

Zero-probability labels may be assigned any state because all comparator states have zero probability there. This defines C=R∘M, a parameter-independent entanglement-breaking channel. It exactly fixes every commuting comparator

σ_b=ω' exp(Σ_i b_i B_i)/Trω'exp(Σ_i b_iB_i).

Write h=Σ b_iA_i and g=Σb_iB_i. Both have operator norm≤R, g commutes with S', and ||(h−g)S'||_HS≤Ra. Use purifications W=S exp(h/2), W'=S'exp(g/2). Duhamel's formula, with the g exponential on the left, gives

||W−W'||_HS≤e^(R/2)[||S−S'||_HS+½||(h−g)S'||_HS]
≤e^(R/2)[e^t−1+Ra/2].

Both purification norms are ≥e^(−R/2). Normalizing costs a factor≤2e^(R/2). The trace distance between reduced pure states is bounded by the distance of normalized purification vectors, so

T(ρ_b^S,σ_b)≤2e^R[e^t−1+Ra/2].

By channel contraction and Cσ_b=σ_b,

sup_b T(Cρ_b^S,ρ_b^S)≤4e^R[e^t−1+Ra/2].

For example t=ξ^(1/3), ζ→0 yields a dimension-uniform vanishing bound of order O_(k,R)((η+ξ^(1/3))^(1/(2^k−1))) when k≥2. This rate is deliberately conservative.

## 4. Gibbs error and exact Gibbs/sandwich bridge

Changing log ω to log ω' changes it by operator norm≤2t. If K'=K+L with ||L||≤2t, the corresponding normalized Gibbs states have relative entropy at most 4t (the free energy is 1-Lipschitz in operator norm). Pinsker gives

T(ρ_b^G, exp(logω'+h)/Tr exp(logω'+h))≤√(2t).

Now compare τ_h=exp(logω'+h)/Z_h to σ_b=exp(logω'+g)/Z_g. Put D=h−g, ||D||≤2R. Since g is central relative to ω', Golden–Thompson and log x≤x−1 imply

D(σ_b||τ_h)
 = log(Z_h/Z_g)−Trσ_bD
 ≤ logTrσ_be^D−Trσ_bD
 ≤ Trσ_b(e^D−I−D)
 ≤ c_R Trσ_bD²
 ≤ c_R e^(2R) R² a²,

c_R=(e^(2R)−1−2R)/(4R²), with continuous value c_0=1/2.

The scalar spectral inequality e^x−1−x≤c_R x² holds on [−2R,2R]. The order σ_b≤e^(2R)ω' follows from ||g||≤R and centrality. Pinsker therefore gives

T(ρ_b^G,σ_b)≤√(2t)+e^R R√(c_R/2)a,

sup_b T(Cρ_b^G,ρ_b^G)≤2√(2t)+2e^R R√(c_R/2)a.

Taking t=√ξ, ζ→0 proves vanishing uniformly in dimension whenever ξ,η→0.

The sandwich/Gibbs bridge needs NO mutual-score commutator assumption. Repeat Sections 1,3,4 with g=Σb_iA_i' instead of mutually commuting B_i. Although the A_i' may fail to commute with one another, every A_i' commutes with ω', and hence g does as well. Set a=e^t√(3kξ/t). Both families approach the same central comparator. With t=√ξ,

sup_||b||1≤R T(ρ_b^G,ρ_b^S)=O_(k,R)(ξ^(1/4)).

This bridge closes the exact physical Gibbs-vs-sandwich issue for bounded fields and approximate modular conservation.

## 5. Physical corollary and costs

For ω=e^(−βH)/Z, an energy-eigenbasis calculation gives

||[√ω,A]||_HS≤(β/2)||[H,A]||_(2,ω)≤(β/2)||[H,A]||_op.

Indeed, for an energy gap Δ, (√p_a−√p_c)²/(p_a+p_c)=1−sech(βΔ/2)≤β²Δ²/8. Summing ordered pairs gives the stated factor β/2.

For bounded macroscopic charges A_i=J_i/N, ||[A_i,A_j]||_op=O(1/N). If H=H_SU2+λ_NΣ_x v_x, bounded-range uniformly bounded terms v_x give ||[H,A_i]||_op=O(λ_N). At fixed β, λ_N→0 therefore implies ξ→0, η→0 and full reconstruction of the unknown bounded Gibbs-field family. There is no need for Nλ_N→0 or for the perturbed reference to approach a rotation-invariant reference in trace distance. Fixed number of charges and bounded parameter radius are essential to the proved bound.

Operational costs: spectral decompositions, selecting shifts, exact POVM implementation, and preparing τ_z can be arbitrarily expensive. The theorem provides existence and a finite alphabet depending on tolerance, k,R,defects; it provides no efficient local physical apparatus or finite-precision compiler. It reconstructs the density experiment and does not preserve a purification or an external entangled reference.

## 6. What remains open

The raw score/modular commutator conditions are not necessary. A representation-invariant necessary condition is the pairwise root-fidelity/affinity gap described in the adversary report. Proving a dimension-uniform sufficient converse for that invariant under suitable bounded-likelihood and metric-entropy assumptions is a higher-ceiling target. It is not established here.

## Sources and exact scope

* Astra pinned commit 778b78af5d4bbde608ce3fc775049ceaeb55a2d3, web/pages/d-ece46f964518dbb3.html, Section 4: bounded-score criterion summary. Its linked full proof/scripts were not supplied; source statements are candidates, not validation.
* https://arxiv.org/abs/1002.3082 — Glebsky, 2010, normalized Hilbert–Schmidt almost commuting matrices, including finite tuples.
* https://arxiv.org/html/2608.31000v1 — Bansil–Kachkovskiy, 31 August 2026; Theorems 1.1–1.3 and Corollary 1.4. Two-score 1/3 rate, constrained sharpness, tuple extension.
* https://arxiv.org/abs/quant-ph/9511010 — Barnum et al., no broadcasting of noncommuting mixed states. Exact classical reconstruction implies broadcasting and hence commutation; this alone does not give a dimension-uniform approximate converse.
* https://arxiv.org/abs/quant-ph/0606213 — Guță–Jenčová, strong/weak convergence of quantum experiments, canonical experiments, QLAN framework.
* https://arxiv.org/html/1210.3749v2 — Yamagata–Fujiwara–Gill, quantum log likelihood and local asymptotic normality. Weak score-covariance commutation is a local Gaussian statement; it does not immediately characterize full density reconstruction of arbitrary bounded experiments.
* https://arxiv.org/html/2609.29348v1 — Lahiry, quantum-to-classical sufficiency relative to prescribed measurement classes. Its block-factorization/invariance scope does not by itself imply reconstruction of the full unknown-orientation density family.

Memory used only to preserve earlier scoped-evidence and novelty distinctions: MEMORY.md lines 74–88, rollout id 01a1121a-4750-72f0-8f5c-b501038890d3. No earlier Gaussian theorem is used in this proof.
