# An intrinsic criterion for uniformly compact quantum experiments

Status: complete candidate proof using established noncommutative Lp ultraproduct and exact no-broadcasting mechanisms; independent audits passed the finite-mixture algebraic step and the two-broadcast normal-channel/corner/ergodic-expectation interfaces. External correctness and priority review remain open. This supersedes the domination requirement of INVARIANT_CRITERION.md, whose constructive finite-family proof is still used as a lemma. The broadcasting proof is in BROADCAST_CRITERION.md.

## Theorem

For every n, let E_n be an arbitrary family of density matrices on a finite-dimensional Hilbert space H_n. There are no assumptions on dimension, scores, reference commutation, Gibbs structure, identifiability or a shared parameterization.

Assume uniform total boundedness in trace distance: for each ε>0 there is N(ε)<∞, independent of n, such that E_n has an ε-net of at most N(ε) states selected from E_n.

Write

Δ(ρ,σ)=||√ρ√σ||_1−Tr√ρ√σ,

δ_n=sup_(ρ,σ∈E_n)Δ(ρ,σ),

e_n=inf_(measure-and-prepare Λ) sup_(ρ∈E_n) ½||Λρ−ρ||_1.

Also let b_(n,2) be the infimum over CPTP channels B:H_n -> H_n tensor H_n of the worst, over both output marginals and all states of E_n, marginal trace-distance error. Correlations between output receivers are allowed. Then

e_n→0 iff δ_n→0 iff b_(n,2)→0.

These conditions are also equivalent to vanishing-error marginal broadcasting to every prescribed receiver-count sequence K_n>=2, with a bound independent of K_n. The latter channel uses one classical record and may have correlated outputs; it does not approximate independent copies jointly.

EB necessity has the explicit universal lower bound e_n≥δ_n²/8. Two-broadcast necessity has an explicit dimension-independent modulus δ_n<=v(b_(n,2)), with v(epsilon)=O(sqrt(epsilon log(1/epsilon))); it needs no entropy hypothesis. The finite-label proof is in ../broadcast_quantitative/EXPLICIT_PAIR_BOUND.md. An independently audited alternative normal-channel ultraproduct/fixed-point proof is preserved in BROADCAST_CRITERION.md. Sufficiency produces one unknown-state-independent measure-and-prepare channel, with an alphabet size bounded independently of dimH_n at every fixed positive target error. It supplies no efficient algorithm, polynomial-time apparatus or purification-preserving channel.

The only experiment regularity hypothesis is the uniform trace-distance covering-number bound. It cannot be omitted wholesale: the complete MUB family has δ_n→0 but worst-case EB reconstruction error→1 and two-broadcast marginal error at least (d-1)/(2(d+1))->1/2. Exact Choi normalization and derivation are in ENTROPY_AND_RATE_BOUNDARIES.md.

A stronger simultaneous boundary is now available: the finite faithful dyadic copy-ladder experiment in ../broadcast_entropy_counterexample/PROOF.md has delta_L->0 and b_(L,2)->0 while e_L->1. Thus even accurate two broadcasting does not globally imply one simultaneous EB reconstruction without complexity control. This is a boundary to the entropy hypothesis, not a failure of the fixed-pair modulus.

## 1. Fixed finite mixtures inherit asymptotic gap zero

Lemma. For each fixed integer m there exists a dimension-independent function u_m(s)→0 as s↓0 such that for any m density matrices ρ_1,...,ρ_m on any finite-dimensional space, with ω=(1/m)Σ_iρ_i,

max_j Δ(ω,ρ_j)≤u_m(max_i,jΔ(ρ_i,ρ_j)).

This lemma is qualitative; the proof does not provide a computable explicit modulus u_m. It is the new step removing the common-reference assumption. No convexity of Δ is assumed.

Proof by contradiction. If the lemma fails, there is a sequence of m-tuples, with dimensions allowed to vary, for which all pair gaps tend to zero but some mixture gap stays at least ε_0>0. Pass to a subsequence with the same offending label j.

Put Q_(i,n)=√ρ_(i,n). These are positive elements of the Schatten class S_2(H_n), with ||Q_(i,n)||_2=1. Choose a free ultrafilter U. Raynaud's noncommutative Lp ultraproduct theorem identifies the Banach ultraproducts

∏_U L_p(B(H_n)) with L_p(M),

for all finite p, for one Groh–Raynaud von Neumann algebra M. The compatible identifications preserve positivity, conjugation, norms, the Mazur maps, and products L_p×L_q→L_r whenever 1/r=1/p+1/q. These exact properties are Theorem 3.6 and Theorem 5.1 of Raynaud (2002); his introduction p42 explicitly states validity for varying-algebra ultraproducts.

Let a_i∈L_2(M)_+ be the image of (Q_(i,n))_U. They have L2 norm1. The compatible L1 product and norm maps, together with the preserved L2 Hilbert inner products, give

||a_i a_l||_1−tr(a_i a_l)=lim_U Δ(ρ_(i,n),ρ_(l,n))=0.

An L1 element c with ||c||_1=tr c is positive: under L1(M)=M_* this is the standard characterization of a positive normal functional by ||φ||=φ(1). Consequently a_i a_l is positive, so

a_i a_l=(a_i a_l)*=a_l a_i.

## 2. Algebraic commutation is sufficient here

Haagerup Lp(M) is represented in the τ-measurable operator *algebra of the semifinite crossed product used in its construction. The products above are products in that associative algebra. This point is essential: ordinary operator-norm ultraproducts would erase diffuse normalized-density mass.

For positive a_i, the bounded operator r_i=(I+a_i)^(-1) is a genuine two-sided inverse of I+a_i in the measurable algebra. From a_i a_l=a_l a_i, multiplication by these inverses gives

r_i a_l=a_l r_i,

r_i r_l=r_l r_i.

The bounded resolvents r_i,r_l therefore commute as operators. Spectral functional calculus then shows that the positive affiliated operators a_i,a_l strongly commute. All the a_i admit a common abelian measurable functional calculus.

Define

b=(m^(-1)Σ_i a_i²)^(1/2)∈L_2(M)_+.

It strongly commutes with each a_j, so ba_j is positive in L1 and

||ba_j||_1−tr(ba_j)=0.

The Mazur-map compatibility sends the ultraproduct of the square roots of the finite mixture states ω_n to b. Product/norm and L2 inner-product compatibility therefore give

lim_U Δ(ω_n,ρ_(j,n))=||ba_j||_1−tr(ba_j)=0,

contradicting the offending lower bound ε_0. This proves the fixed-m finite-mixture lemma.

## 3. Complete sufficiency proof

Fix ε>0. Choose an ε-net ρ_(n,1),...,ρ_(n,m_n) for E_n, where m_n≤N(ε). By repeating labels, pad it to exactly m=N(ε) states. Define its known mean reference

ω_n=m^(-1)Σ_iρ_(n,i).

Every net state satisfies ρ_(n,i)≤mω_n. The original pair gap is at most δ_n; by the mixture lemma, every reference/net gap is at most u_m(δ_n). Hence the augmented finite family

F_n={ω_n,ρ_(n,1),...,ρ_(n,m)}

has maximum pair gap tending to zero and a common included reference with the fixed upper-domination constant C=m. Its cardinality is at most m+1.

Apply the direct finite-family dominated reconstruction proof in INVARIANT_CRITERION.md. It constructs channels Λ_n with

max_i T(Λ_nρ_(n,i),ρ_(n,i))→0.

The alphabet sizes at every fixed precision are bounded using only m and the target error, independent of dimH_n. Channel contraction extends from the net to every original state:

sup_(ρ∈E_n)T(Λ_nρ,ρ)≤2ε+max_i T(Λ_nρ_(n,i),ρ_(n,i)).

Thus limsup_n e_n≤2ε. Let ε↓0 to conclude e_n→0. A standard diagonal choice of nets/resolutions gives one channel sequence with vanishing error. Necessity was already proved without any hypotheses in INVARIANT_CRITERION.md.

## 4. Broadcasting equivalence

The pair theorem of BROADCAST_CRITERION.md proves that any two density matrices admitting a common two-output channel with both marginal errors at most epsilon have Delta<=v(epsilon), uniformly over Hilbert dimension. Restricting an experiment broadcaster to any input pair therefore gives delta_n<=v(b_(n,2)); an arbitrarily small slack handles an infimum. Thus b_(n,2)->0 implies delta_n->0, even before imposing covering entropy.

Conversely, a measure-and-prepare reconstruction channel Lambda(rho)=sum_z Tr(E_z rho) tau_z gives, for every integer K>=2,

B_K(rho)=sum_z Tr(E_z rho) tau_z^(tensor K).

Every marginal equals Lambda(rho). Hence b_(n,K)<=e_n for every K, without an error factor depending on K. Preparing and distributing K output systems is a charged physical resource; the theorem bounds the error rather than this cost. Restricting a K-output channel to any two outputs proves the remaining equivalence.

## Scientific implications and limits

This characterizes asymptotic full-density classicality across arbitrary uniformly trace-total-bounded models, rather than only a central exponential-score representation. The intrinsic gap vanishes exactly for commuting pairs. Its asymptotic version becomes sufficient only because uniform metric entropy reduces the problem to fixed finite families; the MUB counterexample demonstrates the role of this restriction.

Fixed-k bounded sandwich experiments satisfy uniform total boundedness automatically, so this gives their representation-invariant iff even if the original score/reference commutators do not vanish. The approximate-conservation sufficient theorem and Gibbs/sandwich bridge in PROOF.md are separate quantitative physical applications. General noncommuting Gibbs perturbations must not be assigned an unjustified uniform Loewner bound.

The intrinsic-gap sufficiency characterization remains qualitative: its finite-mixture modulus arises by contradiction/ultraproduct. Broadcasting now has an explicit finite-label reconstruction modulus: for m states with two-broadcast error b, e<=inf_L[L b+sqrt(m ln(m)/(2*2^L))], and a dimension-independent finite alphabet can be retained. Consequently the entropy hypothesis for two-broadcast->EB can be weakened to b_n log N_n(a_n)->0 for some a_n->0. Exact proof and costs are in GENERAL_M_BROADCAST_BOUND.md.

Channel construction may require acquiring an ε-net, full spectral or conditional joint-output data, exact adaptive projective measurements and conditional-state preparation. These are charged resources and can be intractable. The channel reconstructs marginal density matrices only; it does not preserve input purification or arbitrary external entanglement. Finite tensor composition, a separate nonconstructive growing-entropy condition for intrinsic-gap sufficiency, and a qubit square-root obstruction to linear broadcast rates are recorded in ENTROPY_AND_RATE_BOUNDARIES.md.

## Source theorem verified

Yves Raynaud, *On ultrapowers of non commutative Lp spaces*, Journal of Operator Theory 48 (2002), 41–68.

Primary PDF: https://jot.theta.ro/jot/archive/2002-048-001/2002-048-001-003.pdf

* Introduction p42: varying-algebra ultraproduct applicability; multiplication compatibility announced.
* Theorem3.6 pp59–60: compatible linear isometries, positivity, conjugation, Mazur maps.
* Theorem5.1 p66: product compatibility for all finite p,q,r with 1/r=1/p+1/q.
* Haagerup measurable-operator realization and L1 distinguished trace are recalled pp57–58.

Downloaded exact PDF/text are in sources/Raynaud2002.pdf and sources/Raynaud2002.txt. Raynaud's theorem is established prior art. Proposition5.2 p67 supplies the complete-isometry/finite-amplification interface for channels in the broadcasting proof.

The statistic and its exact zero set are explicitly prior art: Khouzani and Manjegani, Trace-Norm Overlaps of Quantum States: Interpolation, Equality, and Data-Processing Rigidity, arXiv2609.14203 (13Sep2026), Section6 Theorem6.1 p17, https://arxiv.org/pdf/2609.14203 . Their Delta_alpha at alpha=1/2 is precisely the present gap, and they prove zero iff commuting without faithfulness. Kuramochi, arXiv1710.01599, Corollary1 p14, https://arxiv.org/pdf/1710.01599 , supplies the established exact von-Neumann-algebraic broadcasting/classical-sufficiency mechanism. It is essential to use commuting embeddings or the algebraic tensor product rather than assume a normal spatial tensor-product limit.

A bounded primary-source audit found no matched full compact-experiment intrinsic-gap operational equivalence, but this is not a novelty certificate. The dimension-free pair-broadcast modulus is now explicitly a corollary of established finite-label conditioning machinery: Brandao–Piani–Horodecki1310.8640, Li–Smith1408.6829 Lemma3 and Qi–Ranard2001.01507 Proposition1. The exact binary extraction constant collides directly with that prior art; see ../broadcast_prior_art/FINITE_ENTROPY_ADDENDUM.md. The characterization itself requires external correctness and priority review; its being derivable by composition does not establish historical novelty. Independent prior-art/interface and counterexample probes are in ../broadcast_prior_art/AUDIT.md and ../broadcast_prior_art/counterexamples.md.
