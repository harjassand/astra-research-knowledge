# Consequences and limits of the intrinsic criterion

Current strongest result is GENERAL_CRITERION.md. This note records proved consequences and unresolved escalation separately.

## Two receivers and arbitrarily many receivers

Let Λ_n(ρ)=Σ_z Tr(E_(n,z)ρ)τ_(n,z) be the reconstruction channel from the criterion, with uniform error e_n→0. For every integer K_n≥2, however rapidly it grows, define

B_(n,K)(ρ)=Σ_z Tr(E_(n,z)ρ) τ_(n,z)^(⊗K).

This is a legal parameter-independent quantum channel. Every one of its K marginals equals Λ_n(ρ), so the worst marginal trace-distance error is at most e_n, independently of K. Therefore the intrinsic gap condition under uniform metric entropy implies asymptotic broadcasting to arbitrarily many receivers.

This output is a mixture of tensor powers with one common label z. It generally has classical correlations between receivers and is not ρ^(⊗K). There is no independent-copy cloning claim or joint trace-distance bound to ρ^(⊗K).

The converse is now supplied by BROADCAST_CRITERION.md: approximate two-output broadcasting with vanishing marginal error forces pairwise intrinsic gap to zero uniformly in dimension, even without a covering-entropy hypothesis. The proof constructs normal UCP limit channels from compatible predual ultraproducts, and normal commuting marginal homomorphisms from the two partial traces. Input-only support reduction gives a faithful mean state. A normal fixed-point conditional expectation has abelian range by the two marginal multiplicative domains, and bounded Radon-Nikodym densities in that abelian centralizer force the root gap to vanish. These interfaces passed independent adversarial audits. Under the main entropy hypothesis this upgrades accurate two broadcasting to arbitrarily many receivers with the same vanishing marginal bound. No receiver-by-receiver iteration or dimension-dependent de Finetti bound is needed.

An explicit finite-label information-chain proof now supersedes the need for that qualitative converse: ../broadcast_quantitative/EXPLICIT_PAIR_BOUND.md gives e_pair<=inf_L[L b+sqrt(ln(2)/(2*2^L))] and Delta<=O(sqrt(b log(1/b))). GENERAL_M_BROADCAST_BOUND.md extends this, by adaptive conditional Helstrom extraction and minimax, to e_m<=inf_L[L b+sqrt(m ln(m)/(2*2^L))]. It supplies the effective growing-entropy condition b_n log N_n(a_n)->0 for some a_n->0. Its extraction mechanism is established prior art in Li–Smith1408.6829 Lemma3 and Qi–Ranard2001.01507 Proposition1. The alternative algebraic proof remains preserved and independently audited.

Relevant primary prior art: Barnum et al. https://arxiv.org/abs/quant-ph/9511010 (exact no broadcasting); Kuramochi https://arxiv.org/pdf/1710.01599 Corollary1 p14 (exact general operator-algebraic broadcasting/classical sufficiency); Lemm–Wilde https://arxiv.org/abs/1608.07569 (approximate simultaneous cloning/broadcasting entropy limitations); Xie–Fang–Wang–Duan, PhysRevA96,022302(2017), https://www.kunfang.info/pdfs/XFWD17-PRA.pdf (set-broadcasting SDPs and correlations). The latter's Eq3 explicitly depends on growing input Hilbert-space dimension. The root-gap statistic/exact zero set are explicitly Khouzani–Manjegani https://arxiv.org/pdf/2609.14203 Section6 Theorem6.1 prior art.

## Fixed finite tensor composition

For r fixed experiments E_(n,1),...,E_(n,r), each uniformly trace-total-bounded, consider their product experiment with independently unknown parameters. An ε/r-net in each factor gives a product ε-net because trace distance between tensor products is at most the sum of the factor trace distances. Thus covering numbers satisfy

N_product(ε)≤Π_(i=1)^r N_i(ε/r),

independently of n.

For pairs of product states,

F_total=Π_iF_i,

A_total=Π_iA_i,

Δ_total=Π_iF_i−Π_iA_i≤Σ_iΔ_i,

by a telescoping product and 0≤A_i≤F_i≤1. Hence asymptotic classical reconstruction of all factors implies that of the product. Conversely, fixing known states in the other factors, applying a joint EB reconstruction channel and tracing them out gives an EB reconstruction channel for each factor. Therefore e_product≥max_i e_i and, by tensoring near-optimal factor channels, e_product≤Σ_i e_i. This is a fixed-r stability statement, not a dimension-uniform growing-mode claim.

For r_n→∞, errors can accumulate and covering entropy can diverge. The exact product identities remain valid, but the compact-family criterion cannot be invoked without separately verifying its uniform covering-number hypothesis. Thermal/Gaussian and MUB tests supplied by quantum_statistics are useful boundary examples.

## Bounded physical Gibbs families meet uniform metric entropy

For known ω_n on its support and h_b=Σ_i b_iA_i with ||A_i||≤1, fixed k,R and ||b||_1≤R, the physical Gibbs family ρ_b∝exp(logω_n+h_b) has a dimension-uniform modulus in its parameter. A perturbation ||h_b−h_c||≤||b−c||_1 gives

D(ρ_b||ρ_c)≤2||h_b−h_c||,

T(ρ_b,ρ_c)≤√||b−c||_1,

by Gibbs free-energy operator-norm Lipschitzness and Pinsker. Its parameter ball therefore yields dimension-independent trace-distance nets. The general intrinsic iff applies directly to this family, even though a uniform Loewner bound ρ_b≤Cω_n is not generally available.

The quantitative score-Wigner–Yanase criterion of PROOF.md supplies an efficiently testable-in-principle sufficient invariant (given the full matrices), but its spectral/measurement/preparation apparatus need not be computationally or physically efficient.

## Failure ledger

1. Raw score modular/pair commutators need not vanish in a classically reconstructible experiment. The faithful six-dimensional identifiable example in general_classicality_adversary/REPORT.md has η=1/2 and modular defect→1/√2 while reconstruction error≤√ε.
2. First-order effective scores or SLDs do not characterize fixed-radius experiments. A near-kernel excursion can have vanishing first derivatives but noncommuting second-order observable states. Exact four-dimensional example is in the adversary report.
3. Pair intrinsic gaps alone do not imply classical reconstruction when experiment entropy grows. The complete MUB family has pair gaps→0 and optimal worst-case EB error→1.
4. Ordinary operator-norm ultraproducts erase diffuse density mass; the finite-mixture proof uses compatible L1/L2 Haagerup ultraproducts. Replacing them by C*-norm ultraproducts would be a fatal proof error.
5. Finite numerical fixtures verify calculations only; 480 lemma fixtures, three MUB2design checks and diffuse-background tests are recorded in lemma_diagnostics.json. They do not certify the general theorem or novelty.
6. The finite-mixture modulus is nonconstructive, so a claimed explicit optimal rate for GENERAL_CRITERION would be unsupported. The dominated case does have an explicit, conservative spectral-pinning modulus; geometry_topology/INFORMED_BREADTH.md improves its bookkeeping without altering the theorem's scope.
7. The pair-broadcast modulus now has an explicit O(sqrt(epsilon log(1/epsilon))) upper bound. Helstrom measurement and preparation for almost orthogonal qubit pure states yield epsilon~c^2/4 and Delta~c, so no universal linear rate is possible and the possible logarithmic loss is unresolved. The complete MUB family has two-broadcast error bounded below by a limit of one half despite delta->0, proving that the entropy hypothesis also matters for sufficient broadcasting. Exact derivations are in ENTROPY_AND_RATE_BOUNDARIES.md.
8. The finite faithful dyadic copy-ladder construction in ../broadcast_entropy_counterexample/PROOF.md has both delta_L->0 and b_(L,2)->0 but e_EB->1. Thus complexity control is needed even for two-broadcast->simultaneous-EB, rather than just intrinsic-gap sufficiency. Its broadcaster reads a known copy-number flag and splits actual copies; its EB lower bound follows from established Haar pure-state estimation. The prepared/estimated state is not supplied as an oracle. Finite exact designs and tiny uniform noise preserve the obstruction; no efficient design acquisition is claimed.

## Prior-art conclusion so far

The operational task is old: Fuchs–Sasaki https://arxiv.org/abs/quant-ph/0302092 studies classical transmission/accessible fidelity of pure-state sets. The ingredients of the present criterion are also old: Fuchs–Caves canonical fidelity likelihood, Lieb affinity concavity, Powers–Størmer, almost-commuting matrices, Raynaud compatible Lp ultraproducts, and quantum-experiment convergence.

A focused primary-source search has not identified the exact theorem that uniform trace-total-bounded experiments have vanishing EB reconstruction error iff their uniform root-fidelity/affinity gap vanishes. This is a bounded search result, not a novelty certificate. The gap and its exact zero set are explicitly studied by Khouzani–Manjegani2609.14203, and the exact operator-algebraic no-broadcasting/classical-sufficiency mechanism is Kuramochi1710.01599. The explicit finite-label pair converse/extraction constant is a direct corollary of established Brandao–Piani–Horodecki1310.8640, Li–Smith1408.6829 and Qi–Ranard2001.01507 measured-conditioning machinery; the source collision is recorded in ../broadcast_prior_art/FINITE_ENTROPY_ADDENDUM.md. Guță–Jenčová quant-ph/0606213 Theorem3.16 uses canonical-state domination by a single fixed experiment, a different interface from the original per-n domination lemma. Lahiry2609.29348 concerns sufficiency relative to prescribed invariant measurement classes and explicitly distinguishes it from full state recovery. Bansil–Kachkovskiy2608.31000 supplies the recent quantitative almost-commuting premise; its elementary role should be credited rather than claimed as new. The full broadcasting audit is in ../broadcast_prior_art/AUDIT.md.
