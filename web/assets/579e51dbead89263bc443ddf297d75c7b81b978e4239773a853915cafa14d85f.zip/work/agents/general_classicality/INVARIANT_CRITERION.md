# Fidelity–affinity characterization under domination and uniform metric entropy

Status: candidate theorem with a complete direct proof below; canonical polar lemma independently checked by the adversary. No novelty certificate or external validation. The next attack is removal of domination by finite-mixture stability.

## Precise theorem

For each n let E_n={ρ_(n,θ):θ∈Θ_n} be density matrices on a finite-dimensional space H_n. Dimension and parameter set may vary without bound. Suppose:

1. A known included reference ω_n∈E_n satisfies ρ_(n,θ)≤Cω_n for every n,θ, with one constant C<∞.
2. Uniform total boundedness in trace distance: for every ε>0 there is an integer N(ε)<∞, independent of n, such that E_n has a trace-distance ε-net of at most N(ε) members of E_n. There is no requirement that the same parameter labels work for each n.

Let root fidelity and affinity be

F(ρ,σ)=||√ρ√σ||_1,

A(ρ,σ)=Tr√ρ√σ,

Δ(ρ,σ)=F(ρ,σ)−A(ρ,σ)≥0.

Define

δ_n=sup_(ρ,σ∈E_n)Δ(ρ,σ),

e_n=inf_(measure-and-prepare Λ_n) sup_(ρ∈E_n) T(Λ_nρ,ρ),

T=½||·||_1.

Then δ_n→0 iff e_n→0.

The sufficiency construction uses finite classical alphabets whose cardinality, at any fixed target error, is bounded by a function of C and N(ε), independent of dimH_n. It does not assert efficient acquisition of nets, matrix spectral decompositions, implementation or preparation. If the net and states are not supplied, those are acquisition costs.

Only upper domination is assumed. Restrict to suppω_n; all states lie there. Full rank on the original Hilbert space and lower domination are unnecessary.

## Necessity: no regularity hypotheses needed

Suppose Λ=R∘M reconstructs ρ,σ within ε. Let p_z,q_z be the measurement distributions and τ_z the prepared states. Measurement data processing gives

F(ρ,σ)≤Σ_z√(p_zq_z).

Joint concavity of the affinity (Lieb's trace concavity at exponent 1/2) gives

A(Λρ,Λσ)≥Σ_z√(p_zq_z)A(τ_z,τ_z)=Σ_z√(p_zq_z).

Powers–Størmer gives ||√ρ−√ρ'||_HS≤√||ρ−ρ'||_1. Consequently

|A(Λρ,Λσ)−A(ρ,σ)|≤2√(2ε).

Thus Δ(ρ,σ)≤2√(2ε), and e_n≥δ_n²/8. This is dimension-free, intrinsic, and valid for arbitrary experiments.

## Canonical likelihood lemma

Let ρ≤Cω, S=√ω, Q=√ρ, and define on suppω

X=S^(−1)(SρS)^(1/2)S^(−1).

Then X≥0, XωX=ρ and ||X||_op≤√C=:M. The bound follows from SρS≤Cω² and operator monotonicity of the square root.

The crucial quantitative statement is

||XS−Q||_HS²≤2√C Δ(ω,ρ),

||[X,S]||_HS≤2√(2√C Δ(ω,ρ)).

Proof: use the polar decomposition SQ=W P, P=|SQ|. Since (SρS)^(1/2)=W P W†, one has SQW†=SXS and hence XS=QW†. The polar partial isometry may be extended to a unitary on suppω, including singular ρ. The positive operator K=2I−W−W† satisfies

TrPK=2(F(ω,ρ)−A(ω,ρ))=2Δ.

Because ρ≤Cω,

P=(QωQ)^(1/2)≥(QρQ/C)^(1/2)=ρ/√C.

Therefore

||XS−Q||_HS²=TrρK≤√C TrPK=2√CΔ.

Taking adjoints gives the same bound for SX−Q, and their difference gives the commutator bound. This is the load-bearing domination bridge. It is NOT a statement about the supplied exponential score A_i; those scores may have invisible directions even when X≈I in the weighted geometry.

## Sufficiency on a fixed finite net

Fix ε>0. Choose an ε-net ρ_1,...,ρ_m, with m≤N(ε), and append ω if absent. Put K=m+1, M=√C. Let X_i be the canonical likelihoods of the net states relative to ω. Each satisfies

0≤X_i≤MI,

||X_iS||_HS=1,

Ξ:=max_i||[X_i,S]||_HS≤2√(2Mδ).

The random log-spectrum lemma in PROOF.md applies after scaling X_i/M. For 0<t≤1 it produces S'=√ω', pinched positive Y_i, with

e^(−t)S≤S'≤e^tS,

[Y_i,ω']=0,

0≤Y_i≤MI,

max_i||(X_i−Y_i)S||_HS≤D:=√(3KMΞ/t).

Define h=D+M(e^t−1). Then

||X_iS−Y_iS'||_HS≤h.

If h≤1/2, let z_i=||Y_iS'||_HS² and C_i=Y_i/√z_i. These are positive central likelihoods with

||C_i||_op≤L:=2M,

Trω'C_i²=1.

The normalized central surrogate σ_i=ω'C_i² satisfies T(ρ_i,σ_i)≤2h=:e_0 by normalization of the HS amplitudes. The reference surrogate is ω'.

Fidelity is dimension-free 1/2-Hölder in trace distance, as is affinity. In particular, if T(ρ_i,σ_i),T(ρ_j,σ_j)≤e_0 then

Δ(σ_i,σ_j)≤δ+4√(2e_0)=δ+8√h=:δ_1.

## Central gap controls score commutation

In the algebra commuting with ω', τ(B)=Trω'B is a trace. For positive C_i,C_j with τ(C_i²)=τ(C_j²)=1, let B=C_iC_j=UP. Choose its polar unitary U to commute with ω'. Then

Δ(σ_i,σ_j)=τP−τB=:d_ij,

||B−P||_(2,τ)²=2τ[P²(I−ReU)]≤2L²d_ij,

because P≤L²I. The adjoint defect has the same tracial HS norm. Hence

||[C_i,C_j]||_(2,τ)≤2√2 L√d_ij≤2√2 L√δ_1.

Apply the simultaneous commuting approximation lemma of PROOF.md to C_i/L, giving commuting positive B_i≤LI with

max_i||C_i−B_i||_(2,τ)≤L f_K(θ),

θ=2√2√δ_1/L,

f_K(θ)→0 as θ→0.

Positivity is retained by every pinching and rounding step because the scores lie in [0,L]. Finally quantize every B_i with mesh Lζ, adding at most Lζ weighted-HS error. At most (ceil(1/ζ)+2)^K common eigenvalue labels occur.

Put a=L(f_K(θ)+ζ), and require a≤1/2 before normalization (automatic as δ,ζ→0). Then ||B_iS'||_HS≥1−a≥1/2. The normalized commuting states β_i=ω'B_i²/Trω'B_i² satisfy T(σ_i,β_i)≤2a. Measure the common spectral projections Π_z of the B_i and prepare Π_zω'Π_z/Trω'Π_z. This channel Λ exactly fixes every β_i, so

max_i T(Λρ_i,ρ_i)≤2e_0+4a=4h+4a.

The ε-net and channel contraction extend this to the entire family:

sup_(ρ∈E_n) T(Λρ,ρ)≤2ε+4h+4L(f_K(θ)+ζ).

All bounds depend on δ,C,K,t,ζ only, not Hilbert-space dimension.

For fixed ε, choose t=δ^(1/6) when 0<δ≤1. Then Ξ=O_C(δ^(1/2)), D=O_(C,K)(δ^(1/6)), h→0, δ_1→0 and θ→0. Choose ζ→0. This gives limsup_n e_n≤2ε. Since ε>0 was arbitrary, e_n→0. If δ=0 along a subsequence, exact commutation of the states already yields an exact classical channel, or one can choose t,ζ independently tending to zero.

## Bounded sandwich experiments satisfy the two structural hypotheses

For S exp(Σb_iA_i)S normalized, ||A_i||≤1 and ||b||_1≤R imply

e^(−2R)ω≤ρ_b≤e^(2R)ω.

The map b↦ρ_b is uniformly Lipschitz in trace distance with a constant depending only on R (bounded exponential Duhamel plus normalization). The fixed-k compact parameter ball therefore has covering numbers independent of dimension. Thus the theorem gives an actual representation-invariant iff for all fixed-k bounded sandwich experiments, without requiring approximate commutation of the original scores with the reference.

General noncommuting Gibbs perturbations exp(logω+h) are NOT assumed to have such Loewner domination. The approximate-conservation Gibbs/sandwich bridge in PROOF.md applies under its own additional hypothesis; it must not be replaced by an unjustified order claim.

## Why uniform metric entropy matters

For prime-power d, take the union of d+1 complete mutually unbiased bases (d(d+1) pure states), a projective 2-design. Every pair gap is zero within a basis, and is d^(−1/2)−d^(−1) between bases, so δ_d→0.

For every EB channel Λ(ρ)=Σ_zTr(E_zρ)τ_z, the 2-design identity gives average survival

(1/[d(d+1)])Σ_ψ TrψΛψ = [d+Σ_zTr(E_zτ_z)]/[d(d+1)]≤2/(d+1).

Hence some state has T(Λψ,ψ)≥1−2/(d+1)→1. Pair gaps alone cannot control an increasing-cardinality experiment. This sequence also violates fixed common-reference domination, so it does not prove which of the two structural hypotheses is individually necessary.

## Failure ledger and next attack

* Raw exponential-score commutators are not necessary, even for faithful references and identifiable two-parameter experiments; see general_classicality_adversary/REPORT.md.
* Pairwise fidelity–affinity gaps alone are not sufficient for arbitrary large families; the MUB counterexample is exact.
* No small-gap convexity claim for mixtures is used. Removing common domination using a finite-net average reference requires proving Δ(average_iρ_i,ρ_j)→0 from fixed finite pairwise Δ→0, or finding a counterexample. This is the current top unresolved escalation.
* Statistical nets and channels can be prohibitively expensive to acquire/implement. The result is an experiment-level characterization, not an efficient compiler.

## Prior-art boundary

The ingredients are established: exact no-broadcasting; the Fuchs–Caves optimal fidelity measurement/canonical positive likelihood; Lieb joint concavity; Powers–Størmer; normalized-HS almost-commuting matrices. N03 already claimed a bounded central-score iff. The precise dominated, uniformly total-bounded intrinsic iff and its canonical-polar stability bridge need focused external priority review. Searches are evidence of a bounded audit only and do not establish novelty.

Primary handles: Barnum et al. https://arxiv.org/abs/quant-ph/9511010; Guță–Jenčová https://arxiv.org/abs/quant-ph/0606213; Glebsky https://arxiv.org/abs/1002.3082; Bansil–Kachkovskiy Theorems 1.1–1.3/Corollary1.4 https://arxiv.org/html/2608.31000v1; Klappenecker–Rötteler MUB2design https://arxiv.org/abs/quant-ph/0502031. Fuchs–Caves canonical likelihood is older and must receive direct bibliographic attribution before release.
