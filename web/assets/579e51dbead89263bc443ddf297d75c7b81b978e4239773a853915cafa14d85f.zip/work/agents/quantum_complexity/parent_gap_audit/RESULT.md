# Exact split-parent counterexample and grouping audit

Status: proved finite-dimensional separation for the split parent; it is **not** a counterexample to arXiv:2610.04952's grouped reduction or combinatorial theorem. The paper's grouping removes the separation in this three-qubit toy. No faithful chain counterexample was established.

## 1. Legal split-parent construction

Work on three qubits, with computational basis ordered 000,001,...,111. Let 0 < δ ≤ 1, Φ=(00+11)/√2, and

Qδ = |Φ><Φ| + δ(I−|Φ><Φ|), acting on qubits 12.

Set Kinit=Qδ(span{|0>1}⊗C2⊗C3), Kgate=Qδ(C1⊗span{|Φ>23}), and define hinit and hgate to be the **orthogonal** projectors onto their orthogonal complements. Set hout=|0><0|3, and Hδ=(hinit+hgate+hout)/3. All identities below concern support projectors, not the inverse-sandwiched operators' unnormalized eigenvalues.

Write

a=(1+δ)/2, b=(1−δ)/2, nδ=a²+b²=(1+δ²)/2, sδ=nδ+δ²=(1+3δ²)/2.

The exact projectors are

hinit = [|10><10| + |z><z|/nδ]12 ⊗ I3,
z=b|00>−a|11>,

hgate = I123 − (|v0><v0|+|v1><v1|)/sδ,
v0=a|000>+δ|011>+b|110>,
v1=b|001>+δ|100>+a|111>.

In the 00,01,10,11 basis, the 12 matrix of hinit is

```
[ (1−δ)²/[2(1+δ²)]  0  0  −(1−δ²)/[2(1+δ²)] ]
[ 0                     0  0   0                    ]
[ 0                     0  1   0                    ]
[ −(1−δ²)/[2(1+δ²)] 0  0   (1+δ)²/[2(1+δ²)]   ]
```

Thus the projectors have exact rational entries whenever δ is rational. The formula for hgate is also an explicit rational formula, since v0,v1 have rational entries and common rational squared norm sδ. Their supports are disjoint, so they are orthogonal.

To check that these are the intended conjugated parents, if A is any positive operator and Q is invertible and Hermitian, then

ker(Q⁻¹ A Q⁻¹) = Q ker(A).

Apply this to Ainit=(I−|0><0|1)⊗I23 and Agate=I1⊗(I−|Φ><Φ|23), then replace each positive operator by its support projector. The displayed hinit,hgate follow. In particular, taking the support projector is essential to the expectation formulas here.

## 2. Exact combinatorial energy

Invertibility implies

Kinit ∩ Kgate = Qδ[(span0⊗C2⊗C3) ∩ (C1⊗spanΦ23)]
                   = span{v0}.

This uses the elementary identity Q(A∩B)=QA∩QB for an invertible linear map. The preimage intersection is exactly span{|0>1|Φ>23}.

The normalized unique common parent ground state is ψ0=v0/√sδ, and

<ψ0|hout|ψ0> = (a²+b²)/sδ = (1+δ²)/(1+3δ²) > 0.

Consequently the three projectors have no common kernel: every normalized state violates at least one of them, in the paper's exact nonzero-expectation sense. Therefore its combinatorial energy is at least 1/3. The state ψ0 satisfies hinit,hgate exactly and violates only hout, proving that the combinatorial energy is **exactly 1/3**. This proves the combinatorial assertion independently of the variational bound.

The same argument covers mixed states. Zero expectation against a positive projector implies that the support of the mixed state lies inside that projector's kernel, so zero expectations against all three would force an empty support.

## 3. Exact variational energies

For the normalized trial state w=|Φ>12|1>3=(|001>+|111>)/√2,

<w|hinit|w> = δ²/(1+δ²),
<w|hgate|w> = 3δ²/(1+3δ²),
<w|hout|w> = 0.

Hence

0 < λmin(Hδ) ≤ 2δ²(2+3δ²)/[3(1+δ²)(1+3δ²)]
                   ≤ (4/3)δ².

The strict positivity follows from finite dimension, positivity, and the absence of a common kernel. The final inequality holds for all 0<δ≤1 (indeed for every δ>0). This is a rigorous upper bound; it is not asserted to be the exact ground energy.

The other proposed trial state, ψ1=v1/√sδ = normalized Qδ(|1>1|Φ>23), gives

<ψ1|hinit|ψ1> = 2δ²(3+δ²)/[(1+δ²)(1+3δ²)],
<ψ1|hgate|ψ1> = 0,
<ψ1|hout|ψ1> = 2δ²/(1+3δ²),
<ψ1|Hδ|ψ1> = 4δ²(2+δ²)/[3(1+δ²)(1+3δ²)].

Both witnesses work. The first has the smaller leading coefficient (4/3 versus 8/3). The limit δ=0 is not included in the injective construction: Q0 is singular and Q0K differs from the limiting kernel of these projectors.

## 4. Tensor copies, including entangled states

Let Hδ,N = (1/(3N)) Σ[j=1..N](hinit,j+hgate,j+hout,j), acting on N disjoint three-qubit blocks.

For any global state ρ, let ρj be its reduced state on block j. At least one of Tr(ρj hinit), Tr(ρj hgate), Tr(ρj hout) is nonzero, by the mixed-state kernel argument above. This statement needs no product assumption. Thus at least N of the 3N terms are violated by every state, and the combinatorial energy is at least 1/3. The product ψ0^⊗N violates exactly the N output terms, proving equality.

By independence of blocks, the normalized quantum ground energy is exactly λmin(Hδ), and the product witness w^⊗N has exactly the preceding expectation. Set δ=2⁻ᴺ. Then

combinatorial energy = 1/3,
0 < λmin(H2⁻ᴺ,N) ≤ (4/3)4⁻ᴺ.

All local terms are orthogonal projectors of locality at most three and interaction degree at most three. There are 3N terms; each can be specified by a constant-size matrix with rational entries of O(N) bits, and weights 1/(3N). The local Hamiltonian description is polynomial length. The entire 2^(3N)-dimensional matrix does not have polynomially many rows, so 'polynomial rows' is safe only when referring to the explicit local terms or an implicit sparse interface. This precision issue should not be obscured.

## 5. What grouping changes

Primary source: [Bafna–Nguyen–Zhang, arXiv:2610.04952v1](https://arxiv.org/html/2610.04952v1), §8.1 and §8.2 Eqs. (113)–(117); version displayed 4 October 2026. Local source: ../sources/gap-amplification.txt, lines 9194–9439.

Section 8.1 describes conjugating individual input/resource terms. Section 8.2 instead groups all local initialization and local gate-resource checks inside one vertex projector (Eq. 116). Its edge projector jointly includes both endpoints' local resources and the edge communication resources (Eq. 115). These support projectors cannot be replaced by the split pair in a spectral argument.

For a single vertex holding all three toy qubits, the grouped term is

hgroup = I−|ψ0><ψ0|.

Let q=<ψ0|(I−hout)|ψ0>=2δ²/(1+3δ²). A two-dimensional diagonalization gives

λmin(hgroup+hout) = 1−√q = 1−√[2δ²/(1+3δ²)].

The other eigenvalues are 1 (multiplicity three) and 2 (multiplicity three), alongside 1±√q. Therefore the equally weighted grouped Hamiltonian has ground energy (1−√q)/2, approaching 1/2 as δ→0; it has no O(δ²) low-energy witness. This **refutes a direct identification of the split toy with the paper's grouped vertex construction**. The Eq. (114) perturbation parameter on one EPR location equals δvertex/√3, so that conversion must also be charged.

More generally, for a support projector I−|ψ><ψ|, an output projector P, and weights α,β>0, write q=<ψ|(I−P)|ψ>. The minimum eigenvalue of α(I−|ψ><ψ|)+βP is

(α+β−√[(α−β)²+4αβq])/2.

It approaches min(α,β) when q→0. Thus grouping all fixed-input resources into a single support projector eliminates the toy's bad condition number even if the unnormalized inverse sandwich was ill-conditioned.

For a multi-location edge or vertex group, Eqs. (113)–(114) perturb a **single Bell-product projector** Pgroup with one uniform coefficient on its entire orthogonal complement. This differs from a tensor product of independent single-pair Qδ maps, whose eigenvalue depends on the number of nontrivial Bell outcomes. A chain lift must preserve this further grouping convention.

## 6. Bounded attempt at two vertices / chains

For a faithful two-vertex graph with exactly one edge, fixed initialized input, and no free witness, Eq. (115) checks **all** seed resources: all local resources at both vertices plus all communication resources. Its inverse product includes every contraction group Qu,Qv,Qe. Thus its kernel is the single global perturbed TN state. The preceding weighted rank-one calculation gives a constant lower bound against a rejecting-output check whenever this TN state has only q=o(1) weight in the accepting-output subspace. Extra positive vertex terms preserve that lower bound. Consequently a two-vertex, one-edge grouping does not provide the requested near-parallel counterexample.

I also tested a literal naive ownership assignment: initial qubit 1 at u, identity transmission resource Φ23, Qe12, Qvertex=I, and no local comp gates. Eq. (115) gives h_e=I−|ψ0><ψ0|, but Eq. (116) would give h_u=|1><1|1, whose expectation in ψ0 is

(1−δ)²/[2(1+3δ²)],

which is nonzero for δ≠1. Therefore this assignment does not safely instantiate Claim 8.1's frustration-free construction. It must not be used as a counterexample: either the displayed support/ownership conventions impose an excluded structure, or more precise inverse-map conventions are needed. Adding a second edge without resolving this issue compounds it.

No faithful three-vertex chain example was established in this bounded audit. In particular, the proved split separation neither establishes nor refutes quantitative soundness for the actual grouped HDX/MPC output. The architecture-specific next attack is to specify a concrete legal multi-edge tensor network, verify every parent kernel against Claim 8.1 **before** searching for a small-angle state, and then calculate the projector angles after the paper's actual grouping. A direct transfer of the split toy would omit a load-bearing modification.

## 7. Verification and failure ledger

`python3 check_exact.py` verifies symbolically: Q's Bell action, idempotence of the three projectors, their prescribed transformed kernels, both expectation tables, the entire characteristic polynomial of hgroup+hout, and the naive-placement inconsistency. It saves `check_exact.json`. PASS on 7 October 2026. Numerical split-ground diagnostics (δ=1/2,1/8,1/32) are supplementary and are not used in the proofs.

The first optional numerical spectral diagnostic used SymPy's general floating eigensolver and failed to converge; it was replaced by mpmath's symmetric eigensolver. All exact identities had already passed before that diagnostic failure. This numerical replacement does not change the mathematics.

Failure/rejection ledger:

1. Rejected: identifying separate hinit+hgate with Eq. (116)'s jointly checked vertex projector.
2. Rejected: claiming a polynomial number of rows for the full global Hamiltonian matrix.
3. Rejected: treating an unverified resource-ownership assignment as a legal paper protocol.
4. Open: whether a genuine multi-edge grouped family retains an exponentially small quantum gap relative to its combinatorial energy.
5. Not claimed: any contradiction of the paper's stated combinatorial gap-amplification theorem, quantitative soundness theorem, or historical novelty.
