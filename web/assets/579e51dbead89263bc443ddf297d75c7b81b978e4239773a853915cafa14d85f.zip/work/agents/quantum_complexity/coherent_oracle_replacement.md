# Coherent oracle replacement and the conditional classical consequence

This is an independent elementary lemma. It composes with, but does not prove, the PSPACE-effective synthesis construction or the cryptographic hardness statement in Kretschmer-Tang.

Suppose a Boolean function f has a uniform BQP decider. Preserve its query register x and let A be an amplified decider on zero workspace, with each classical x's answer wrong with probability<=delta. Define O_f|x,z>=|x,z xor f(x)>.

Use A, copy its output bit into z by CNOT, and use A^*. The ideal output has all added workspace zero. For each x, write A|x,0>=|x>(g_x+b_x), where g_x has the correct answer and ||b_x||²<=delta. Before uncomputation, the actual output differs from copying f(x) only on b_x, by norm at most2||b_x||. After A^*, the same bound holds. Since distinct x remain in orthogonal blocks, the restricted operator norm bound on arbitrary superpositions and references is at most2sqrt(delta).

If a larger circuit has T Boolean oracle calls and total target error e, choose delta<=(e/(4T))². Standard BQP repetition and reversible majority uses O(log1/delta)=O(log1/e+logT) repetitions, then the restricted ideal-prefix telescoping argument bounds total oracle replacement error by e/2. It applies even though the actual work registers after a replacement need only approximately return to zero. The ideal prefix has zero scratch, which is the only domain on which the replacement estimate is needed.

Therefore, if BQP=PSPACE and a clean unitary synthesis algorithm uses one PSPACE Boolean language with polynomial(n,log1/e) circuit/query resources, that oracle can be replaced by an ordinary polynomial-time quantum computation while preserving polylog error costs and controlled phases. In the Kretschmer-Tang definitions this gives unitaryP=unitaryPSPACE, assuming the proposed PSPACE-effective synthesis theorem.

Kretschmer-Tang arXiv:2610.03705 (v2 5 October2026) claims quantum commitments imply unitaryP != unitaryPSPACE (formal location being checked in child notes). On that dependency, the proposed synthesis theorem would imply

    quantum commitments => BQP != PSPACE,

and hence P != PSPACE as well. This is conditional on the existence of commitments and the new synthesis/acquisition derivation. It is NOT an unconditional classical complexity separation, a construction of quantum commitments, or a polynomial-time classical acquisition algorithm.

A converse acquisition barrier is exact and needs no crypto: given any L in PSPACE, take the unitary U_L|x,z>=|x,z xor L(x)>. Its entries are PSPACE computable. A universal polynomial-time classical procedure producing a polynomial-size evaluator for an appropriate synthesis oracle from a legal U_L descriptor would, with the constant-error synthesis circuit, decide L in BQP. Thus such a universally efficient acquisition service would force BQP=PSPACE. The candidate PSPACE evaluator preserves, rather than abolishes, this cost boundary.
