# Independent gates checked for PSPACE-effective release-283 synthesis

This audits, but does not by itself certify, the oracle_synthesis branch's stronger acquisition construction. Read directly: release283 02-slots.tex, 03-contraction.tex, 04-fields.tex, 07-compilation.tex. Commit adc7f1241b42e322a6451854ab7e4b4c146bf78a. Full root route still needs a complete reviewed construction.

## Clean phase interface

The source itself works in actual operator norm, not norm modulo phase: Eq(slot:clean-error) asks ||C iota - iota U||<=delta on zero-workspace inputs. Labels are coherent. In 07-compilation each W_y=e^(i gamma_y)S_y is approximated by SU(2) words on its target plus SU(2) diag(e^(i gamma_y),e^(-i gamma_y)) on a zero scratch qubit. This retains all relative phases and approximately returns scratch to zero. The final source proof has clean norm error<1/10 before its weaker channel conclusion. Therefore a phase- or garbage-mismatch is not an obstruction to composing a suitably retuned proof with Kretschmer-Tang's clean unitary classes.

## Searchable signs: independently derived constants

Let a=n+1 and use 2a-wise independent Rademacher signs. The trace-power and scalar moments depend on at most 2a signs, so their full-independent expectations are preserved. Scalar moment comparison for a complex sum with sum|alpha_j|^2<=1/q gives

    E|sum eps_j alpha_j|^(2a) <= (8a/q)^a.

For squared threshold128a/q, Markov gives16^(-a) per matrix entry. Union over qs<=2^(2n) entries remains<1/16. Hence a seed exists with all |C'_ij|²<=128a/q. A computable certificate using threshold160a/q has margin40a/q; this needs O(n) extra accuracy bits, not exact zero or an eigenvalue-equality decision.

For the Hermitian dilations L_i in source 03-contraction, conditional Jensen for the convex function Tr(X^(2a)) and the Gaussian trace recursion give

    E Tr(sum eps_i L_i)^(2a) <= h(4a v)^a,
    v<=160a s/q, h=2s.

Choosing M=2^20 a² and s<=q/M makes the 2a-th root of the expectation at most sqrt(2)*sqrt(640/2^20)<1/16. A seed with certificate Tr(...)^(2a)<(1/2)^(2a) thus exists with ample margin. All index loops in the trace expansion have polynomial-bit counters and depth O(a); finite-field polynomial generators use O(an)=O(n²) seed bits. Enumerating seeds, indices, and terms uses polynomial space. This is a real acquisition argument, unlike treating a sampled sign table as supplied free input.

## Recursion stability

For exact transformed blocks D with ||D||<=3/4, the inverse R=(I-DZ)^(-1) has ||R||<=4. If perturbed blocks are contractions within small operator error e and ||D'Z'||<=7/8, the feedback maps A+BZR C are Lipschitz with an absolute constant (81 suffices when Z is exact and both inverse norms<=8). There is no dimension-dependent condition number in this inverse. Along polynomially many recursive stages, the required precision therefore increases additively by O(J) bits, plus the O(n) bits per stage needed to promote entrywise accuracy to operator accuracy. It must NOT be implemented by a recursive request for O(n b) precision at every Neumann level: that can become exponential in recursion depth.

A safe implementation rounds a whole implicit matrix to a fixed dyadic grid (entry grid fine enough that dimension times error<=2^-b), then evaluates each length-O(b) Neumann path using exact rational/dyadic arithmetic. Denominator and accumulator bit lengths are polynomial in b and n, so evaluating the exponentially many paths sequentially is compatible with PSPACE. Recursion requests b+O(n) bits of the previous exact matrix, and stack depth J is polynomial. The oracle_synthesis child reports this repair; it remains important to inspect every derived slot table similarly.

## Fourier row support and zero decisions

The source Fourier row's only candidate internal columns are the roots of an integer power-sum polynomial of degree<=L. Root candidates can be enumerated with O(n)-bit counters and checked exactly; multiplicities and coefficients have polynomial bit size. Whether a coefficient from summing paths equals zero need not be decided: keep every candidate, round coefficients to a common dyadic grid, and let zero values have zero amplitude. Rows outside this structural support are exactly zero by the source power-sum argument. Global operator approximation can be paid using entry accuracy finer than 2^(-poly(row-register-width,n,error-bits)); the exponentially many rows cost polynomially many extra precision bits. An additional rational scaling preserves contraction.

For a nonzero dyadic amplitude vector, its squared norm is at least 2^(-2b) if the grid denominator is2^b. Prefix-ratio state preparation therefore has an explicitly bounded precision condition number; true-zero prefixes of a dyadic vector are rationally decidable. This avoids silently making zero tests on arbitrary polynomial-space computable real numbers.

## Current outcome

No fatal flaw found in the clean phase, sign acquisition, bounded-inverse, or structural row-support gates. The log-error Solovay-Kitaev refinement and complete rounded-encoder perturbation chain still need to be included in one full derivation and independently checked. The source's published statement is constant error; any polylog(1/error) theorem and PSPACE-effective oracle are research extensions, not verbatim source conclusions. Historical priority remains open.
