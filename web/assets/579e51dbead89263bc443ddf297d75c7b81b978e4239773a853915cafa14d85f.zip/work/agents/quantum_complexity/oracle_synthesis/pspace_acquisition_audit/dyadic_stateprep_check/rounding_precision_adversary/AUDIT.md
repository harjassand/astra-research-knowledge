# Dyadic column preparation: precision and continuity audit

Status: independent mathematical derivation; no fatal denominator, tiny-prefix, or phase-precision obstruction after the explicitly computable dyadic repair below. This audits one acquisition sublemma, not the entire PSPACE synthesis candidate or its priority.

## Source and interface

Release commit: `adc7f1241b42e322a6451854ab7e4b4c146bf78a`.

Source base:
https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Polynomial-Time-Unitary-Synthesis-from-a-Boolean-Oracle-October-5-2026/build/

- `sections/02-slots.tex`, `slot:preparation`, local lines 57-79: conditional prefix-norm rotations and a final diagonal phase slot.
- `sections/04-fields.tex`, `fields:gram` / `fields:gram-bound`, local lines 122-130; `fields:sparsity`, local line 190 onward: contraction, near-isometry, and maximum Fourier-row support.
- `sections/05-encoders.tex`, `encode:assumptions`, local line 21; column preparation and flag normalization, local lines 57-64; `encode:row-sparse`: error at most five times the Gram defect.

Assume `R <= 2^w`, `d <= 2^n`, structural row support at most `L`, and `||T|| <= 1`, with `(1-e)I <= T* T`. The entry algorithm deterministically returns dyadic complex approximations with error at most `2^-p` using polynomial space in the instance/address widths and unary `p`. The quantities `w,n,log L,log(1/delta)` must be polynomially charged parameters. Exponential enumeration time is allowed; exponential address widths or requested precision are not silently allowed.

## 1. Computable rounding that preserves sparse support

Set `delta=2^-c`, with integer `c>=0`, and let `ell=ceil(log2(max(1,L)))`. It suffices to take

```
b = c + ceil((w+ell)/2) + 1,
q = 2^-b.
```

For each entry, first request real and imaginary approximations of coordinate error at most `q/4`, then round these finite dyadic outputs to the nearest multiples of `q`, with a fixed exact tie convention. Let the resulting matrix be `A`.

Each coordinate changes by at most `3q/4`, hence each complex entry changes by at most `3 sqrt(2) q/4`. A true zero entry is rounded to zero because both approximated coordinates have magnitude at most `q/4`. Thus `supp A` is contained in `supp T`, including without any numerical zero test on the original real coefficient. There are at most `RL` affected entries, so

```
||A-T|| <= ||A-T||_F
          <= (3 sqrt(2)/4) q sqrt(RL)
          <= (3 sqrt(2)/8) delta < delta.
```

Using a supplied structural mask instead is also valid. The candidate's more conservative `Rd` bound is sufficient, since `log(Rd)=w+n` is polynomial. The rounding algorithm must refer to the finite approximation, rather than demand the exact nearest grid point of the underlying arbitrary real.

## 2. Rational scaling, contraction, and error

Define `S=A/(1+delta)`. Then `||S||<=1` exactly and

```
||S-T|| <= 2 delta/(1+delta) <= 2 delta,
||S* S - T* T|| <= 4 delta/(1+delta) <= 4 delta.
```

Consequently `(1-e-4 delta)I <= S* S <= I`. The row-sparse encoding lemma applies with defect `e'=e+4 delta` provided `e'<1`; its ideal-slot encoder differs from embedded `T` by at most `5e+22 delta`.

Write an entry of `A` as `(a+ib)/2^b`, where the symbols `a,b` in this sentence are integers. Since the grid precision is at least `c`, a common integer denominator for all entries of `S` is

```
Q = 2^(b_grid-c) (2^c+1),
S_ui = (alpha_ui+i beta_ui)/Q.
```

Here `b_grid` denotes the grid precision in the preceding subsection. This `Q` has at most `b_grid+2` bits. More generally a polynomial-bit rational scale gives a polynomial-bit common denominator; reduction to lowest terms is unnecessary.

## 3. Failure square roots do not change squared-mass denominators

For column `i`, put the success amplitudes `S_ui` at leaves `|u,1>` and use one disjoint failure leaf `|0^w,0>` of amplitude

```
sqrt(F_i)/Q,
F_i = Q^2 - sum_u (alpha_ui^2+beta_ui^2).
```

The integer `F_i` is nonnegative because `S` is a contraction. Its positive square root supplies the phase convention. Every leaf's squared mass is an integer divided by `Q^2`, even though failure amplitudes need not be rational. The resulting column state is exactly normalized.

Every binary prefix has

```
P_i(p) = N_i(p)/Q^2,    0 <= N_i(p) <= Q^2,
```

with an exact integer numerator. Thus a positive prefix is at least `Q^-2`. For `N_i(p)>0`, its next conditional probability is exactly

```
P_i(p0)/P_i(p) = N_i(p0)/N_i(p).
```

Both integers have `O(log Q)` bits. At `N_i(p)=0`, zero is decided exactly and an arbitrary fixed rotation is permitted. This avoids dividing approximations to uncontrolled tiny real masses.

Prefix numerators can be acquired in polynomial space by enumerating the relevant success rows and accumulating their exact integer squared numerators, adding `F_i` if the prefix contains the failure leaf. All partial positive sums are at most `Q^2`; no exponential-bit accumulator arises from the exponentially many rows. A looser count-dependent bound would add only `w` bits and also suffices. Only the requested numerator is produced; an exponential column is not stored.

## 4. Uniform rotation and phase precision

Put `u=w+1` for the prepared row-plus-flag width and fix desired preparation error `0<eta<=1`. Let `beta=eta/(u+1)`.

For a positive prefix, compute its exact rational ratio `r=N0/N` to absolute error `h<=beta^2/16`, clipped to `[0,1]`. Exact integer long division needs `O(log Q + log(1/h))` bits. The real rotation angle is `theta=arccos sqrt(r)`, lying in `[0,pi/2]`. Uniformly, including endpoints,

```
|arcsin sqrt(r)-arcsin sqrt(r')|
    <= (pi/2) sqrt(|r-r'|).
```

Therefore this ratio error changes the angle by less than `beta/2`. Approximating the remaining elementary arithmetic to angle error at most `beta/2` gives total angle error at most `beta`. A sufficient ratio precision is

```
m_ratio = ceil(2 log2((u+1)/eta)) + 4.
```

Square-root endpoint derivatives are not a bit-cost obstruction. One may compute roots by rational comparisons/bisection, then compute `atan2(sqrt(1-r),sqrt(r))`. For the arctangent, divide the smaller coordinate by the larger; the latter is at least `1/sqrt(2)`. Range reduction `atan x = 2 atan(x/(1+sqrt(1+x^2)))` makes the Taylor argument at most `sqrt(2)-1`, giving geometric convergence with polynomial-bit arithmetic. Exact integer comparison decides which coordinate is larger. This is an explicit polynomial-precision route that avoids conditioning a derivative near zero.

At a success leaf with nonzero integer pair `(alpha,beta)`, the phase is the unit phasor

```
(alpha+i beta)/sqrt(alpha^2+beta^2).
```

Its integer squared norm is at least one. Signs/quadrants are exact integer tests; divide the smaller absolute integer coordinate by the larger to obtain a bounded ratio and apply the same arctangent range reduction. Computing the circular phase to `beta` accuracy uses `O(log Q + log(1/beta))` bits. Principal-argument branch cuts do not enlarge circular phase error. At a zero pair choose phase one. The failure leaf has phase one by construction.

A rotation angle error at most `beta` gives one-qubit operator error at most `beta`; a phase error at most `beta` gives diagonal operator error at most `beta`. Each controlled slot is block diagonal, so its operator error is the maximum branch error, without a factor for the number of labels/prefixes. Telescoping the `u` rotation depths and final phase slot gives total preparation-operator error at most `(u+1)beta=eta`. This includes coherent label controls and arbitrary references.

If masses were instead acquired numerically, the lower bound `P>=Q^-2` would permit sufficient mass precision `O(log Q + log(u/eta))`; exact integer numerators are cleaner and provide exact zero detection.

## 5. Failure ledger and scope

1. **Exact real rounding is not acquired.** A tolerance oracle can return the same midpoint for reals just above and just below a dyadic rounding boundary for every precision queried in a bounded computation. Exact nearest-grid rounding consequently cannot be inferred from a fixed polynomial approximation precision without a separation promise. Finite-approximation rounding in subsection 1 repairs this while preserving the approximation guarantee and true zeros.
2. **The scale must be rational.** Choosing `delta` to be an arbitrary real error bound, especially the exact norm `||A-T||`, does not imply rational prefix masses. Choose a certified dyadic upper bound. The candidate already chooses a dyadic `delta`.
3. **Rational masses alone do not acquire phases.** The vector `(1,exp(i alpha))/sqrt(2)` has rational squared masses even with noncomputable `alpha`. Here this issue is avoided by the exact integer complex success coefficients and the fixed positive failure square root.
4. **Precision is not time.** The prefix arithmetic and gate-table acquisition are PSPACE, generally exponential-time; this audit supplies no polynomial-time classical oracle acquisition or exponential table materialization.
5. **Dimension widths are charged.** The proof is polynomial in `w,n,log L,c,log(1/eta)` and the entry algorithm's space bound. For Fourier fields, `w=K+n` is the released polynomial-width register; if an application supplied superpolynomial row-address width, the conclusion would change.

No finite experiment is needed for these integer-denominator identities and norm inequalities. The independent tiny-branch audit agreed on the common-denominator lower bound, the square-root Holder bound, circular phase treatment, and telescoping with no label-count factor. Strongest remaining task outside this sublemma: audit that recursive entry evaluation provides the stated additive precision/space guarantee and that every final Boolean table query recomputes the same rounded matrix/phase convention.
