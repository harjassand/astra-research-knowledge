# Dyadic Fourier encoders: PSPACE acquisition audit

Status: the rounding/state-preparation repair is mathematically sound under the explicit interface below. It does not by itself acquire the recursively defined entries of V or the contraction choices. No source files were edited.

## Source and exact scope

Read `work/RESEARCH_PROTOCOL.txt`, repository `00_START_HERE.txt` and `01_CORE.txt`, and the requested source sections. The relevant locations are:

- `02-slots.tex:57-82`: conditional prefix-mass state preparation.
- `04-fields.tex:71-118`: Fourier field dimensions and truncations.
- `04-fields.tex:122-175`: contraction and lower Gram bound.
- `04-fields.tex:190-243`: a multiset frequency determines a structural row support of size at most L.
- `05-encoders.tex:17-141`: column normalization, row lists, and amplification; notably the proof only needs each row list to contain all actual nonzeros.

Assume n, L, label length, and requested output precision are polynomial in the base input length; the field-entry machine returns finite dyadic (or polynomial-bit rational) approximations of real and imaginary parts in space polynomial in those parameters and the number of precision bits. Let R be the number of rows, log R polynomial, and d <= 2^n. Let

    (1-e) I <= T* T <= I,       0 <= e < 1,

and suppose a polynomial-space computable set J_u, |J_u| <= L, contains the support of each row. The latter is available for these Fourier fields, independently of coefficient cancellations.

## 1. Construct an approximation, rather than deciding a rounding boundary

Choose a positive, explicitly specified polynomial-bit rational safety budget delta with e + 4 delta < 1. For definiteness take delta = 2^(-j). Force A_ui = 0 when i is outside J_u. Inside J_u, call a fixed deterministic coefficient approximator to precision q+2, then truncate its returned finite rational approximation onto the common grid 2^(-q). Each real/imaginary error is at most (5/4) 2^(-q), so each complex error is less than 2 * 2^(-q).

With w = ceil(log_2 R), one sufficient choice is

    q = ceil((w+n)/2) + ceil(log_2(1/delta)) + 2.

Then |A_ui-T_ui| <= delta/sqrt(Rd), and

    ||A-T|| <= ||A-T||_F <= delta.

There is no exact true-coefficient zero test or exact nearest-grid tie test. A true zero inside J_u may acquire a nonzero approximant; it still occupies only a structural candidate position.

This distinction is necessary. Exact nearest rounding of a general polynomial-space approximable real at a grid midpoint is not computable. For a fixed midpoint theta, encode whether machine e halts at time t by theta +/- 2^(-t-c), using theta itself if it never halts. Approximating this family to m bits only requires simulating m+O(1) steps, hence polynomial space; exact rounding with a fixed tie convention in the opposite direction would decide halting. Finite-approximation quantization avoids this discontinuous operation.

## 2. Rational safety scaling preserves the hypotheses

Define S = A/(1+delta), using the rational safety budget, never an exact acquired value of ||A-T||. Then

    ||S|| <= 1,
    ||S-T|| <= (||A-T|| + delta ||T||)/(1+delta) <= 2 delta,
    ||S*S - T*T|| <= (||S||+||T||) ||S-T|| <= 4 delta.

Therefore

    (1-e-4 delta) I <= S*S <= I.

Applying the source row-sparse encoder to S gives

    ||U_S iota - jmath T|| <= 5(e+4 delta) + 2 delta
                               = 5e + 22 delta.

The original slot count and row list size are unchanged. The extra 22 delta per encoder must be charged in the overall recursion error budget; the unmodified claim 5e is for exact T only.

For A_ui = (alpha_ui+i beta_ui)/2^q and delta=2^(-j), write

    S_ui = (u_ui+i v_ui)/H,
    H = 2^q (2^j+1),
    u_ui = 2^j alpha_ui,  v_ui = 2^j beta_ui.

The common denominator has O(q+j) bits. Division by 1+delta generally gives rational, not dyadic, entries. Rationality is sufficient. If literal dyadic entries are wanted, the alternative S=(1-delta)A for 0<delta<1 also has norm <= (1-delta)(1+delta)<=1 and ||S-T||<=2delta; it gives the same displayed error bounds and a dyadic common denominator.

An irrational or implicitly specified scaling factor does not establish the rational-prefix argument.

## 3. Exact normalized column and exact tiny-prefix arithmetic

For each column i, put

    M_i = sum_u (u_ui^2+v_ui^2),       0 <= M_i <= H^2.

Prepare success amplitudes S_ui at |u,1>, and put the sole failure amplitude sqrt(H^2-M_i)/H at |0^w,0>. This vector is exactly normalized. The failure amplitude itself need not be rational; its squared modulus is rational with the same denominator H^2.

For every binary prefix p of the w+1 output bits,

    P_i(p) = N_i(p)/H^2,       0 <= N_i(p) <= H^2,

where N_i(p) is an integer sum of the appropriate success squared numerators and, if included, H^2-M_i. Compute M_i and N_i(p) by enumerating rows and recomputing their coefficients. The row counter has log R bits; each accumulator has at most 2 log H + O(log R) bits (in fact positive partial sums are bounded by H^2). Exponential time is allowed in PSPACE.

Exact zero is the integer comparison N_i(p)=0. Every positive P_i(p) is at least H^(-2). More strongly, the allegedly unstable division cancels the common denominator:

    P_i(p0)/P_i(p) = N_i(p0)/N_i(p),

an exact fraction of polynomial-bit nonnegative integers. No inverse of a super-polynomial precision number is required.

If one instead approximates the masses with absolute error zeta, then for zeta<=P/2,

    |Ptilde_0/Ptilde - P_0/P| <= 4 zeta/P <= 4 H^2 zeta.

Thus even that route only requires O(log H + log(1/target-error)) extra precision. Exact integer mass arithmetic is simpler and removes this numerical-conditioning question entirely.

## 4. Rotation and phase precision, including endpoints

For N>0 and 0<=N0<=N, set r=N0/N. The desired real rotation has first column (sqrt(r),sqrt(1-r)). To approximate sqrt(r) to error <2^(-m), compute

    c_m = floor(sqrt(floor(2^(2m) N0/N)))/2^m.

This equals floor(2^m sqrt(r))/2^m. The analogous integer formula gives sqrt(1-r). Integer division and integer square root use O(log H+m) bits. The resulting entry approximation determines the ideal unitary rotation to operator error at most 2^(1-m), uniformly including r=0 and r=1. Choose m >= ceil(log_2(2/eta)) for a slot target eta. The truncated entry matrix is not necessarily itself unitary; use it to describe the ideal unitary for the gapped gate-word search, rather than directly inserting a nonunitary numerical matrix into a circuit. It is unnecessary to evaluate a poorly conditioned arcsin or arccos angle.

At a success amplitude (u+i v)/H, its phase is (u+i v)/sqrt(u^2+v^2). Exact zero is u=v=0. Otherwise K=u^2+v^2>=1; the common denominator H cancels. A scaled integer square root approximates sqrt(K) with polynomial space, followed by rational divisions. If ztilde=floor(2^m sqrt(K))/2^m, then ztilde>=1 and |u/ztilde-u/sqrt(K)|<=2^(-m), since |u|<=sqrt(K); the same holds for v. Round the divisions to another m bits. Each component then has error less than 2^(1-m), so m >= ceil(log_2(4/eta)) suffices for complex phase error below eta. All phase entries are PSPACE approximable at O(log H+m) bit cost. Assign phase 1 to zero and to the nonnegative real failure amplitude.

For coherent labels, all computations use the same machine and safety parameters; the controlled slot norm is the maximum branch norm, so no factor equal to the number of labels appears.

## 5. Structural row lists and Fourier coefficient cost

At frequency zero, J_(0,a)={a} for a valid output port. At a nonzero frequency, first negate w on the E side. Enumerate nondecreasing tuples of length 1<=m<=L from {1,...,s}, testing their integer power-sum vectors against w. This uses O(nL+K) space, K=b(L+1), and at most exponential time. The source's no-wrap and Newton-identity argument makes the matching multiset unique. J_u consists of its distinct internal indices; no match gives the empty set. Invalid output ports also give the empty set. This is an effective route; it does not require polynomial factorization or numerical root finding.

Fill J_u to exactly L distinct extended indices with the first L-|J_u| indices 2^n,2^n+1,... . These are outside valid input indices and fit within n+h bits, h=ceil(log_2(L+1)). The row preparation then has squared amplitudes 1/L on this exact list. Its prefix ratios are ratios of integer membership counts, again polynomial-bit exact fractions.

For the truncated Fourier coefficients, normalization by |G| does not create an exponential amplitude factor: Fourier orthogonality extracts the polynomial monomial coefficient exactly. A coefficient is a sum of at most M<=L s^(L-1) products, each of at most L bounded matrix entries, with signs/conjugations handled exactly. Enumerate contributing paths and their frequencies rather than all phase points. If each input complex entry is approximated to nu<=min(1/L,2^(-p)/(4LM)), product error is at most 2Lnu and total error at most 2LMnu. Thus p+O(nL+log L) input precision bits suffice. Exact dyadic products and the running sum also use polynomial-bit storage. This statement assumes the needed V-block entries are already uniformly PSPACE approximable.

## Failure ledger and exact remaining gap

- Fatal if read literally: acquire exact nearest rounding of arbitrary computable coefficients. Repaired by quantizing a fixed finite approximation.
- Unsupported if delta is irrational or is the exact unknown perturbation norm. Repaired by choosing a rational safety budget from the Frobenius estimate.
- Incorrect wording: entries after dividing by 1+delta need not remain dyadic. They have a polynomial-bit rational common denominator, which proves everything needed.
- Incorrect error budget: rounding/scaling changes the per-encoder field error to at most 5e+22delta.
- No fatal support issue: use computable multiset candidate support, including positions that cancel exactly; force every other entry to zero.
- No fatal tiny-prefix or phase issue after the repair. Denominator cancellation and exact integer zero tests give polynomial precision bounds.
- Rational squared masses alone would not acquire arbitrary phases: for example (1,exp(i alpha))/sqrt(2) has rational squared masses even for a noncomputable alpha. Here the finite complex dyadic approximants themselves supply the integer phase numerators, so that counterexample is outside the repaired interface.
- Remaining acquisition obligation: prove the recursively defined V blocks, contraction choices, permutations and all chosen finite approximants are uniformly PSPACE approximable under the legal base input interface. This audit does not assume an arbitrary noncomputable unitary has computable entries, and does not prove that larger obligation.

Primary context for the standard state-preparation construction: Grover--Rudolph, https://arxiv.org/abs/quant-ph/0208112 ; Mottönen--Vartiainen--Bergholm--Salomaa, https://arxiv.org/abs/quant-ph/0407010 . The rational-conditioning and support arguments above were derived directly from the specified source and interface.

Finite diagnostic: `python3 check_integer_rotations.py` passed 236 exact rational checks, including endpoint ratios and denominators with up to 4,001 bits. It verifies the displayed floor-square-root inequalities on those cases only; it is not a general-proof certificate.

Independent adversarial check: `rounding_precision_adversary/AUDIT.md` independently verified the rational denominator, prefix ratio cancellation, floor-square-root construction, Gram perturbation, support padding and phase calculation. It identified the nonunitary-truncation and final phase-division precision wording cautions incorporated above. Agreement is a check, not external proof validation.
