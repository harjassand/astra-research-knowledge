# Independent PSPACE acquisition audit

2026-10-07. Conditional mathematical audit of the released OpenAI283 mechanism, not external correctness or priority certification.

## Verdict

I found no fatal PSPACE cost after the repairs below. The unqualified phrase “stream Neumann paths at precision p+O(n t)” is insufficient for the recursive proof: directly applying that bound to the true entries at every level can cause precision multiplication. A globally rounded implicit matrix, followed by exact finite rational path arithmetic, gives an additive precision recurrence and closes that particular obstruction. The candidate should state this algorithm explicitly.

The initial M=65536(n+1)^2 claim needs minor numerical adjustment if robust E2 selection allows entries up to 17 sqrt(a/q): the norm-expectation bound becomes 68a sqrt(s/q), hence 17/64 rather than 1/4. This is not fatal; it remains far below 3/4. The current parent candidate uses M=2^20 a^2 and a trace threshold that has ample slack.

My audit reads source sections 02-slots, 03-contraction, 04-fields, 05-encoders, 06-recursion and 07-compilation. It does not certify the entire source beyond the calculations discussed here.

## 1. Short seeds and existence

Put a=n+1 and m=log2 q. Let a uniformly random polynomial of degree at most 2a-1 over GF(2^m) be evaluated at all q distinct field points. Applying a fixed nonzero F2-linear functional to each value gives signs. Vandermonde interpolation gives independent uniform field values at every at most 2a distinct points, hence independent unbiased signs at those points. This remains true when q<2a (then all q coordinates are independent). The seed uses 2am=O(n^2) bits. A field representation is obtainable by finite enumeration of irreducible degree-m polynomials in polynomial space; no table of q values is stored.

For a real sign sum X with coefficient squared norm v0,
E X^(2a) <= (2a-1)!! v0^a <= (2a)^a v0^a.
For complex S=X+iY, (X^2+Y^2)^a <= 2^(a-1)(X^(2a)+Y^(2a)), giving
E |S|^(2a) <= (4a/q)^a when the complex squared coefficient norm is at most 1/q. The expression is a polynomial in signs of total degree 2a; limited independence preserves the expectation exactly.

The E2 union bound at threshold 16 sqrt(a/q) is therefore
q s (4a/q)^a/(256a/q)^a <= 4^n 64^(-a) < 1.

Existence alone does not allow a fixed-precision exact-boundary search. Instead approximate each C' entry to a fixed precision 2^-O(n), accept with an intermediate rational squared threshold between (16 sqrt(a/q))^2 and (17 sqrt(a/q))^2, and reserve enough error on both sides. Some seed must pass and every accepted seed meets the exact upper bound 17 sqrt(a/q). All seed selection rules must be pinned independently of the later requested entry precision.

For E1 the source norm-Jensen comparison is not directly an expectation determined by 2a-wise independence. Use the convex function X -> Tr |X|^(2a) on Hermitian matrices instead. Conditional Jensen with Gaussian magnitudes gives
E Tr Y^(2a) <= mu^(-2a) h (2a-1)!! v^a,
where mu=sqrt(2/pi)>1/2 and h=2s. This is now a degree-2a polynomial expectation and is preserved. For the Hermitian dilation of D, Tr Y^(2a)=2 Tr(D*D)^a. With v=289sa/q,
E Tr(D*D)^a <= s(2312 a^2 s/q)^a.

With M=2^20 a^2 this is at most
2^(a-1)(2312/2^20)^a < 16^(-a).
Thus a seed has trace at most 16^-a. Approximating the trace to error at most 4^-a/8 and accepting estimates at most 3*4^-a/4 certifies exact trace at most 7*4^-a/8, hence ||D||<1/2. The existence and certification inequalities do not test a real equality.

For s=1 the minimum column entry modulus is at most 1/sqrt(d)<=1/sqrt(2), leaving a fixed gap below 3/4. A finite-precision first-acceptable row search works, and its permutation can be a transposition, whose forward and inverse maps have a polynomial-space evaluator.

Trace evaluation can use direct paths: there are at most s^(2a) products of 2a entries of D or D*, and ||D||<=1 before the seed is accepted because it is a subblock of a unitary. Entry precision 2an+O(n+log a) makes the total trace error 2^-O(n). Loop indices use O(an) bits. E2 and E1 seed counters use O(n^2) bits. Exponential time is allowed; neither the signs nor their truth table are stored.

## 2. Explicit recursive precision repair

Here is a stable evaluator for F=A+BZ(I-DZ)^-1 C to additive entry error 2^-p.

1. Fix the exact canonical signs/permutation using the robust tests above. These choices depend on the label and level, not p.
2. Compute an implicit dyadic matrix Vbar, using one deterministic finite approximation and one common grid for all entries, with entry error at most 2^(-(p+n+c)). Then ||Vbar-V||<=2^n max entry error <=2^(-(p+c)). It is enough to request previous-level U entries to precision p+O(n): each Walsh-transformed entry has coefficient absolute sum at most 2^n, by Cauchy-Schwarz on the two unitary rows/columns. A conservative p+3n+c bound absorbs both this sum and the grid rounding.
3. Approximate the diagonal phases to a common dyadic grid with error at most 2^(-(p+c)). They form Zbar. With c fixed sufficiently large, ||Dbar Zbar||<=4/5, while the approximate other blocks have norms at most 1+tiny.
4. Set t=O(p+1) so that the norm tail in the geometric series of Dbar Zbar is at most 2^(-(p+c')). Evaluate
   Fbar_t=Abar+Bbar Zbar sum_{l=0}^{t-1}(Dbar Zbar)^l Cbar
   exactly by streaming its finite rational paths. Every factor has a common dyadic denominator with O(p+n) bits. A product has O(t(p+n)) denominator bits; align the finitely many lengths to a common denominator and add all paths exactly. Numerator length is O(t(p+n)+nt+log t). The path counter has O(nt) bits. These are polynomial, even though the number of paths is exponential.
5. Round the resulting entry for output.

The resolvent identity supplies the error estimate. If delta=||Vbar-V|| and phase error is at most delta, inverse norms are <=4 for the exact matrix and <=5 for the approximate matrix. Since the exact and approximate B,C blocks have norm <=2,
||Rbar-R|| <= 20 ||Dbar Zbar-DZ|| <= O(delta),
and every term in Fbar-F is bounded by an absolute constant times delta. Choosing c sufficiently large and the geometric tail as above gives final error 2^-p. No stability bound depends on t. Exact dyadic summation is what avoids charging the exponentially many paths against the input approximation error separately.

Write P_seed=O(n^2) for the fixed precision used by the seed tests (increase its constant for the Walsh sums). In the recursive evaluator, the precision requested at the preceding unitary level is bounded by
p_prev <= max(p,P_seed)+C n+C.
Thus at depth at most J, all requested precisions are bounded by p+P_seed+C(n+1)J. Numerical frames use polynomial space in this quantity, n, K and the label length; summing at most J frames is polynomial. Seed reconstruction calls only the same current unitary's entry evaluator, which in turn calls earlier unitary levels; there is no cycle. Recomputing prior seeds may cost substantial time, but not exponential workspace.

All grid outputs must be deterministic finite approximations. Defining grid values by the nearest grid point to an exact computable real introduces an unnecessary equality/tie problem.

## 3. Fourier coefficients and rational state preparation

An exact coefficient is a finite sum of at most L*2^(nL) length-at-most-L path products. Here L is the circuit truncation parameter, already polynomial in n and desired output precision; it is not a recursively increasing evaluation length. Direct finite approximation using p+O(nL+log L) factor precision is polynomial. Alternatively one may exactly sum fixed rounded factors. Structural support is enforced first: a signed frequency corresponds to at most one multiset of at most L internal indices, and only indices in it can contribute. At frequency zero only the output's port column is legal. Finding/validating the multiset by enumeration uses O(nL+K) bits. No real coefficient is tested for being exactly zero.

Let A be a finite dyadic approximation constrained to this support and satisfying ||A-T||F<=delta. Take delta rational, preferably a power of two below the error allocation, and put S=A/(1+delta). Then
||S||<=1, ||S-T||<=2delta,
S*S >= (1-epsilon-4delta)I, S*S<=I.
The source row-sparse encoder gives ||U_S iota-jmath S||<=5(epsilon+4delta), and therefore
||U_S iota-jmath T||<=5epsilon+22delta.
Two encoders contribute at most 44delta per recursion level. The candidate's allocation delta<=e/(176J), with its truncation allocation, fits the claimed budget.

The entries of S are rational, generally not dyadic after division. They have a common denominator H of polynomial bitlength. Write each entry as (u+iv)/H. For a normalized column preparation, put the unused norm into a single failure basis state with positive amplitude
sqrt(H^2-sum_rows(u^2+v^2))/H.
Its squared norm is rational. Every prefix probability is N/H^2 with a polynomial-bit nonnegative integer N<=H^2. A nonzero prefix has probability at least H^-2. Prefix ratios are exactly N_child/N_parent, and every zero decision is an integer test. Square-root and phase-normalized slot entries are therefore computable to the required precision using polynomial-bit arithmetic. Exponential enumeration of rows adds only log R=K+n bits to the numerator size.

Padding row support lists with invalid extended indices works: there are at most L structural indices, and the extended space has more than d+L positions. Padding never requires testing exact zeros.

Independent state-preparation audit: dyadic_stateprep_check/AUDIT.md (or its final report), under this directory. It confirms the same bounds and the finite-approximation-before-quantization requirement.

## 4. Scalar phase, words, and definitions

For d=1 the exact remaining entry is a unit-modulus scalar computable by the same entry evaluator. Apply diag(u,1) to a fresh qubit known to be zero. There is no need to compute an argument, a square root branch of a determinant, or an exact sign of an arbitrary real.

For any U(2) table W, enumerate pairs of determinant-one words. Test the resulting 4-by-2 isometry (first word on target, second on scratch |0>) against W tensor |0> with a robust Frobenius-error threshold. The abstract SU(2) phase decomposition proves existence; the algorithm never needs to extract its branch. Solovay-Kitaev supplies pairs of polynomial-in-log(1/eta) length. A word counter and the constant-dimensional matrix products use polynomial space. Determinant-one is an exact residue test: 4#H+#T-#Tdag is 0 modulo 8. Word matrices lie in Q(i,sqrt(2)) and also admit direct polynomial-bit exact arithmetic.

Kretschmer-Tang use closeness to a full-space extension, while the released construction supplies a restricted clean-workspace norm bound. Their Lemma5.3 explicitly converts restricted error epsilon/2 to a full extension within epsilon. Spend this constant factor in the final error target. Definition5.2 uses poly(n,log1/epsilon) with n unary and precision bitlength charged, so the proposed one-language oracle must also parse n and precision with unary/length charging on every address.

Primary reference: https://arxiv.org/html/2610.03705v2 (Definition4.5, Definition5.2, Lemma5.3, introductory PSPACE-effective question). The characterization Theorem6.17 is not contained in this partially rendered HTML; the parent should continue using the PDF/source for that exact theorem. Released source is pinned to adc7f1241b42e322a6451854ab7e4b4c146bf78a at https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Polynomial-Time-Unitary-Synthesis-from-a-Boolean-Oracle-October-5-2026/build/ .

## Remaining boundary

This is a constructive repair audit. The conclusion is conditional on the correctness of the released feedback, Fourier-field and row-sparse encoder mechanism. I found no counterexample within these audited obligations, but this is not proof by model agreement and it is not an external historical-priority determination. The most load-bearing addition is the explicit globally rounded feedback evaluator and its additive precision recurrence; preserve it in any final theorem manuscript.
