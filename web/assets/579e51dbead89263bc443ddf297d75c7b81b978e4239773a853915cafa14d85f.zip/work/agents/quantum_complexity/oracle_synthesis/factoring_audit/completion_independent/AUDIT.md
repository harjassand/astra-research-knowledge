# Independent audit: deferred dyadic completion in result 279

Source pin: `adc7f1241b42e322a6451854ab7e4b4c146bf78a`.

Source base: https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Exact-quantum-factoring-over-a-fixed-finite-gate-set-September-25-2026/build/

Scope: independent adversarial audit of `05-factor-process.tex` and
`06-exactness.tex`, with only necessary inspection of the interface of the
order-trial proposition. This is not a full proof certification of result 279.
In particular, exactness of the order-transform arithmetic and the primality
appendix are dependencies, not established by this audit.

## Finding

No fatal counterexample found. The load-bearing deferred-completion argument
is valid under the stated transition/process premises. Its use of completed
data is retrospective and does not condition on eventual completion.

The argument needs all three source premises:

1. The completed accepted data are unique and correct.
2. The true data determine, from a recorded transition input, its good
   predicate, a canonical good output, and its exact dyadic good mass.
3. Every all-good output evolution completes within the stated caps.

Removing any of these would invalidate a general transfer. The source
explicitly establishes or imports each premise; the exact locations are below.

## Dyadic completion: direct proof

`06-exactness.tex:9–27`, Lemma `lem:completion`, equation `eq:completion`.

Write `A=(1-delta)s`, `delta=2^-t`, `E=W+t+2`,
`C=2^-E floor(2^E z/A)`, and `R=z-CA`. Then, for **every** allowed parameter
tuple, including `W=0` and `z=A`,

    0 <= C <= 1,
    0 <= R < A*2^-E <= 2^-E,
    0 <= q_guess := R*2^(W+t) < 1/4,
    Pr(pass) = (1-delta)*s*C + delta*2^-W*q_guess
             = AC+R = z.

The scaled floor uses exact integer division; the ratio `z/A` itself is never
sampled. `C`, `R`, and `q_guess` are dyadic. If `A` has denominator exponent
`alpha`, then a common representation of `R` has exponent at most
`max(denom_exp(z), E+alpha)`. Multiplication by `2^(W+t)` therefore leaves a
polynomial denominator exponent; when `denom_exp(z)<=E+alpha`, the exponent
of `q_guess` is at most `alpha+2`. There is no hidden non-dyadic coin.

## Deferred filters: independent kernel proof

`06-exactness.tex:50–73`, Proposition `prop:known-probability`; in particular
lines 58–66.

Fix the unique true data `D` only in the mathematical analysis. For each
recorded prefix `h`, let `T_h` be its next ordinary transition distribution
and let its hypothetical immediate retention predicate use `D`. Attach
fresh independent filter coins to this distribution. By the completion lemma,
the probability of a passing next slot is exactly `z`, for every passing
prefix `h`.

Why the next slot exists: every passing output is good. A passing prefix can
be continued with canonical good outputs; the all-good completion premise
therefore rules out an abort or exhausted cap before its next slot. This
reasoning does not inspect future sampled outputs or condition on eventual
completion. Early completion simply changes all later kernels to the dummy
kernel, which has the same retained mass `z`.

Thus, if `F_i` denotes passage of the first `i` hypothetical tests,

    Pr(F_i | each particular passing prefix at i-1) = z,
    Pr(F_i) = z Pr(F_(i-1)) = z^i.

At `i=L`, all outputs were good, hence the actual run generated true complete
data and its deferred tests are exactly those hypothetical tests. Conversely,
an implemented success has verified data; uniqueness makes those data equal
to `D`, so its deferred tests equal the hypothetical tests on the same history
and same coins. This proves pathwise event equality, not merely equality of
averaged distributions. It also handles bad runs that happen to complete
correctly: their bad slots are rejected by the actual deferred tests.

The quantum issue is separately resolved by immutable orthogonal history
copies (`02-model.tex:28–37`, `lem:records`; `05-factor-process.tex:73–78`).
Conditioning on prior outputs and prior filter coins leaves fresh trial
registers in zero state. Unobserved old work can be arbitrary and entangled;
the next trial acts identically on it. Copying only final control outcomes
does not destroy the intended within-trial interference.

## Process premises checked

* `05-factor-process.tex:80–102`: true complete data supply factorizations
  of subfactors and each required `p-1`; stripping prime factors from
  `phi(m)` computes orders exactly. This is retrospective, not advice.
* `05-factor-process.tex:147–180`: CRT component level counts give the
  exact favorable count `F=phi(m)-sum_t product_i c_i(t)`. The canonical
  CRT residue has level 0 on one component and level 1 on others.
* `05-factor-process.tex:182–195`: **conditional on the order-trial
  proposition**, the minimum candidate equals `r` iff at least one of the
  independent trials returns `r`; every nonempty candidate is a positive
  multiple of `r`. Hence `s=1-(1-phi(r)lambda(r))^K` exactly.
* `05-factor-process.tex:211–229`: unequal local 2-adic levels make
  `gcd(a^(r/2)-1,m)` proper and nontrivial. All-good outputs guarantee a split.
* `05-factor-process.tex:235–270`: logarithmic mass does not increase on
  descent; every two descents halve the label. The auxiliary occurrence
  tree and arbitrary accepted gcd split histories stay polynomial even
  when outputs are bad. No exponentially many recurrence occurrences appear.
* `05-factor-process.tex:272–286`: a verified occurrence tree is unique
  by unique prime factorization; incomplete/wrong trees are rejected. This
  imports an exact polynomial primality verifier.

The low cutoff cases are handled explicitly: `n>=128` from
`02-model.tex:4–8`; for `N=2` the process can consist entirely of dummy
slots, and those still receive the same completion filter. Numerical
resource sizes are enormous but remain polynomial; this audit makes no
practical-resource claim.

## Quarter correction and final reflection

`06-exactness.tex:94–117`, Lemma `lem:quarter`, is another application of
the same rounding-and-unique-guess principle. For any dyadic `1/2<p<=1`
and nonnegative guess width `J`,

    c = 2^-(J+2) floor(2^(J+2)/(2p)),
    e = 1/4 - pc/2,
    0 <= e < p*2^-(J+3),
    0 <= 2^(J+1)e < 1/4,
    pc/2 + (1/2)*2^-J*2^(J+1)e = 1/4.

The valid root factor list is unique because of ordering, primality,
multiplication, and zero padding. Exact reflection at mass 1/4 is elementary:
for `g=Pi psi`, `||g||^2=1/4`,

    (2|psi><psi|-I)(psi-2g) = 2g.

Keeping all workspace is sufficient: `V(2|0><0|-I)V^-1` reflects about
the full prepared state including histories. There is no requirement that
successful garbage be equal across branches.

## Finite diagnostics

`exact_checks.py` uses standard-library `Fraction` throughout. It passed:

* 32,544 allowed dyadic completion parameter tuples, including `W=0`
  and `z=A` endpoints.
* Exact enumeration of 140 recorded runs of a three-slot adaptive
  controller, with state-dependent good masses, aborts, invalid data,
  completed bad histories, early completion, and dummy padding.
  Deferred mass = hypothetical immediate mass = `z^L = 1/64`.
* 288 quarter-correction parameter tuples.

These are scoped diagnostics; the general algebra and pathwise proof above
carry the claim, not enumeration.

## Failure ledger and next decisive attack

No counterexample in this scope. Rejected objections: non-dyadic `z/A`
(only its floor is used); advice/circular completion (pathwise event equality);
conditional old-work entanglement (fresh-register kernel); early completion
(dummy slots); unequal successful garbage (full-state reflection); and
exponential auxiliary-tree branching (log-mass/depth bounds).

The load-bearing remaining audit target is the independent exact order-trial
success law `Pr(candidate=r)=phi(r)lambda(r)` and its actual circuit
realization. This audit validates the completion step **conditional on** that
law and the primality verifier; it does not replace their proofs.
