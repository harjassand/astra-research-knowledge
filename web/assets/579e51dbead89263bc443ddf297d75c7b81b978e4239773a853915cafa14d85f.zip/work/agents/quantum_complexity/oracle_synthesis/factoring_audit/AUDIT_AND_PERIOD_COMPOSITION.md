# Release 279: bounded arithmetic audit and conditional period composition

Status, 7 October 2026: no fatal counterexample found in the inspected
finite-gate/order-mass construction. A rigorous arithmetic obstruction
excludes a tempting exact-QFT interpretation but does not contradict the
factoring claim. The period-finding consequence below is a conditional
derivation from release 279, not independent certification of that release
or a priority claim.

## Source pin and inspected scope

OpenAI/math commit `adc7f1241b42e322a6451854ab7e4b4c146bf78a`.

The requested `.../main.tex` is absent. Actual source:
<https://github.com/openai/math/tree/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Exact-quantum-factoring-over-a-fixed-finite-gate-set-September-25-2026/build>.
Local copies of `build/main.tex` and eight section files are in this
directory. The main PDF is also preserved. No compiler, Lean build, or
complete gate simulator was run.

Precise locations (line numbers refer to the downloaded section files):

* `01-introduction.tex`, `thm:main`, lines 10–12: probability-one full
  factorization, length uniformity, polynomial worst-case gates and qubits,
  fixed NOT/CNOT/Toffoli/H/S with inverses and single controls.
* `02-model.tex`, `lem:dyadic`: polynomial-bit dyadic thresholds realized
  by fresh Hadamards and integer comparisons, with all random registers
  retained. `lem:records`: immutable histories, reversible controller,
  fresh work per transition; no copying before intended interference.
* `03-order-transform.tex:56–130`, `lem:transform`: selected ancillary
  branch has actual unnormalized kernel `Q^-1/2 g(kx/Q)`, not an ideal
  Fourier transform. `Q=B^16`, `g` is quarter-circle linear interpolation.
* `03-order-transform.tex:143–189`, `lem:bins`: unique reduced denominator
  recovery by continued fractions and exact nearest-bin validation.
* `03-order-transform.tex:191–227`, `eq:order-P` and
  `eq:residue-probability`: residue-class collision law is used only at
  the true order. At candidate `d != r`, P has arithmetic meaning only.
* `04-dyadic-order.tex:16–164`, `lem:majorant`: exact progression sums;
  bounded piecewise quartic J; coefficient rounding upward at denominator
  `QB^8`; power sums give exact S without enumerating exponentially many
  residues. U-P lies in [0,128/Q]; `1/(128d) <= S <= 2`.
* `04-dyadic-order.tex:172–249`, completion of `prop:order-trial`: three
  modes make each reduced numerator contribute exactly lambda(d), with
  `lambda(d)=2^(-ceil(log2 d)-10)`. True-order mass is phi(r)lambda(r);
  every returned candidate is a verified positive multiple of r.
* `05-factor-process.tex:211–286`: all-good splitting and polynomial
  occurrence-tree/cap bounds; complete data are unique and verified.
* `06-exactness.tex:9–27`, `lem:completion`: ordinary retained mass plus
  a tiny canonical-output guess fills the exact dyadic residual.
* `06-exactness.tex:58–66`, `prop:known-probability`: prefix conditioning
  and pathwise equality of deferred versus true-data filters.
* `06-exactness.tex:94–117`, `lem:quarter`: unique factor-list guessing
  repairs the final rounding residual to success mass exactly 1/4.
* `06-exactness.tex:119–136`, `eq:one-reflection`: two exact sign
  reflections map the state to its normalized good part in one step.

The Lean comparator endpoint `ExactQuantumFactoring.lean` contains a
`sorry`, as a challenge statement. That is not the submitted proof. Its
JSON points to `OAI.Computability.QuantumFactoring.Main`; the actual
`Main.lean` theorem composes `PhysicalTree.finalCircuit_uniform`,
`finalCircuit_resources`, and `finalCircuit_spec`. Those imported
dependencies were not replayed or recursively audited here. It would be
incorrect to infer either proof certification or a proof failure merely
from the comparator stub.

## What the arithmetic audit established

The alleged obstruction "a fixed finite gate set cannot succeed with
probability one because Fourier phases require arbitrarily large roots
of unity" does not apply to this construction. It never implements those
phases. The selected-branch kernel uses Gaussian dyadics, its success
mass is supplemented by classical dyadic sampling, and the final
amplification uses only -1 phases. Probability one itself is compatible
with the gate ring; ordinary deterministic computations already have it.

The order-mass equations were checked independently with exact Python
Fraction arithmetic in `check_order_arithmetic.py`:

* 5,456 triangular transform entry identities for Q=4,8,...,64, plus
  every corresponding four-phase autocorrelation shift.
* 735 comparisons of bounded-piece progression evaluation against
  explicitly summed P at Q=256.
* 308 complete reduced (d,j) labels with d<32: symbolic quartic/power-sum
  S equals direct U enumeration; every t satisfies majorant bounds;
  the three mode masses sum to lambda(d) exactly.
* 20 labels at n=128, including 127/128-bit d: dyadic P/U/S,
  nonnegative valid retention thresholds, sampled majorant errors, and
  at most eight polynomial pieces. No residue enumeration at large d.

All passed. The JSON records the scoped counts. They support the finite
fixtures and implemented arithmetic formulas, not the universal theorem.

An independent child audited the completion/deferred-filter portion.
It found no counterexample under the source order law and verifier,
and checked 32,544 exact completion cases, 140 adaptive recorded runs,
and 288 quarter corrections. Its report and code are under
`completion_independent/`. In particular, the proof does not condition
on eventual completion: passing prefixes force good outputs, which force
continuation; unique verified completed data identify the same pathwise
event after the fact.

## Proven finite-gate obstruction: uniform odd support and arbitrary QFT

Let R=Z[i,1/sqrt(2)] and K=Q(i,sqrt(2)). All entries of the released
gate set, inverses, controlled gates, and reversible classical oracles
belong to R. Any finite unitary circuit from classical basis input has
all amplitudes in R. Retained-record simulation extends this to bounded
adaptive computational-basis measurements.

Every amplitude can be written

    ((a+b sqrt(2)) + i(c+d sqrt(2)))/2^m,

for integer a,b,c,d and a sufficiently large common m. A marginal Born
probability, after summing any finite set of basis outcomes and arbitrary
ancillary registers, is therefore `(A+B sqrt(2))/2^(2m)` for integers A,B.
If that probability is rational, irrationality of sqrt(2) forces B=0.
Consequently every rational marginal probability is dyadic.

Corollary: a finite circuit over these gates cannot produce an exactly
uniform computational-basis distribution on q outputs unless q is a
power of two. In particular, an exact three-element uniform state,
even with arbitrary retained garbage, is impossible: its marginal 1/3
is not dyadic. This also rules out an exact QFT_q for any q with an odd
factor, because its zero-input column has uniform probabilities 1/q.

Even for q=2^b, an exact coherent QFT_q up to global phase is impossible
when b>3: ratios of nonzero entries require the primitive root
zeta_(2^b), whose field degree 2^(b-1)>4 excludes it from K. The same
ratio argument covers a coherent implementation with fixed output
ancillary garbage, by choosing any nonzero ancillary amplitude. A merely
uniform measurement distribution at a power of two does not imply that
the coherent Fourier transform was implemented.

This is a genuine composition barrier. Exact classical output for
factoring/period finding does not provide arbitrary exact Fourier
transforms, exact uniform sampling from every finite group, or an exact
physical state factory for all odd-dimensional states. It causes no
contradiction with the selected-branch approach.

## Conditional theorem: injective period finding from only an upper bound

Assume release 279's exact factoring theorem and prescribed-order trial.
Let n>=128, B=2^n, Q=B^16. Input is a reversible function oracle

    O_f: |x,z> -> |x,z XOR f(x)>,

for 0<=x<Q and ell-bit values, with the promise that there exists a
positive r<B such that

    f(x)=f(y) iff x congruent to y modulo r

throughout the queried range. Non-oracle gates come from the released
fixed finite set. Count ell in space/time; the query bound below assumes
one oracle call is a unit operation. No period multiple, factorization,
exact Fourier gate, or classical sampling service is supplied.

Then there is a uniform polynomial-size quantum oracle circuit that
outputs r with probability one. It uses O(n^5) oracle queries, plus
polynomially many ordinary gates and qubits and one invocation of the
imported exact-factor279 circuit (up to constant amplification overhead).

### Proof

1. Replace `a^x mod m` by f(x) in the order-sampling state. The promise
   gives precisely the source residue-class orthogonality at true r.
   All interpolation, bin arithmetic, P/U/S calculations, and correction
   branches are unchanged. Candidate validation becomes f(d)=f(0).
   Thus every returned positive d satisfies r|d, d<B, and

       Pr(d=r) = p_r = phi(r) 2^(-ceil(log2 r)-10).

   Oracle evaluation must be clean before the transform: only the
   intended label f(x) may remain as x-dependent ancillary information.
   An XOR-output oracle supplies this directly.

2. Run K=n^5 independent trials and retain the raw list d_1,...,d_K,
   writing 0 for no candidate. If nonempty, choose any nonzero d.
   Factor d with release 279 (handle d=1 directly), then start v=d
   and repeatedly divide by a prime q|v while f(v/q)=f(0). Each step
   preserves r|v. If terminal v>r, a prime q|v/r allows another division,
   contradiction. The result is r, and the remaining exponents provide
   its canonical prime-factor list.

3. A canonical witness w=(v, sorted prime factors with multiplicity,
   zero padding) is uniquely verifiable by checking the product/primes,
   f(v)=f(0), and f(v/q)!=f(0) for each distinct prime q|v. If r|v and
   v/r>1, a prime factor of v/r contradicts its exclusion check. Thus
   exactly the true r witness verifies, including v=1. Use J=n+n^2 bits.
   Prime tests can use the independently established AKS algorithm.

4. The ordinary branch must require the event H that the raw list
   contains an entry exactly equal to decoded r. Its probability is

       s(r)=1-(1-p_r)^K.

   Requiring only successful decoding would be wrong: lists containing
   strict multiples of r also decode, and their total mass is not s(r).
   From the source elementary totient bound,

       p_r >= 1/(2048(n+1)),
       1-s(r) <= exp(-n^5/(2048(n+1))) <= exp(-2n)<2^(-2n).

   Hence s>1/2. Its exact dyadic representation is computable from the
   acquired factorization of r with at most (n+10)K denominator bits.

5. Put E=J+2 and, computed from a verified witness, define

       c(r)=2^-E floor(2^E/(2s(r))),
       e(r)=1/4-s(r)c(r)/2.

   In a half ordinary branch, run step 2, require the unique witness and
   H, and retain with c(r). In a half guessing branch, guess a uniform
   J-bit witness, verify it, compute the same s,c,e from that witness,
   and retain with 2^(J+1)e. All sampled probabilities are dyadic;
   0<=c<=1 and 0<=2^(J+1)e<1/4. The ordinary accepted mass is sc/2,
   and the one verifying guessed string contributes

       (1/2) 2^-J 2^(J+1)e=e.

   Their total is exactly 1/4. Witness-dependent thresholds are legitimate
   here: on every H-passing ordinary history and every accepted guess,
   the witness is the same uniquely verified mathematical object. No
   conditioning on its acquisition changes the probability calculation.

6. Retain all histories and unused oracle/decoder work. Apply exactly
   the source two-reflection identity at success mass 1/4. Two
   preparations and one inverse produce only true-r flagged outcomes.
   Queries to the inverse XOR oracle have the same cost. This gives the
   stated certainty and worst-case polynomial bounds.

Each trial uses constantly many f queries. Stripping and verification
use O(n) more, and the unique-witness guessing verifier also uses O(n).
Thus O(K+n)=O(n^5) queries suffice before and after constant-factor
amplification. Oracle wires require O(ell+16n) bits per active trial;
retaining K histories is still polynomial in n+ell. The non-oracle
polynomial inherits the very large release279 construction and is not
a practical resource estimate.

### Black-box group corollary

For a uniquely encoded group element g, f(x)=enc(g^x) has the required
promise. Coherent reversible multiplication gives clean binary powering
in O(n) multiplication queries per evaluation, with all intermediate
x-dependent labels uncomputed. Hence O(n^6) group queries suffice.
For ell-bit unique group encodings choose n=max(128,ell+1), since
ord(g)<=|G|<=2^ell<B. No group-order multiple is supplied.

This is an oracle theorem if multiplication is an oracle. For concrete
groups with exact polynomial-time classical arithmetic, Boolean
reversible compilation gives the corresponding fixed-gate-only theorem.
Randomized/nonunique encodings, approximate equality, and arbitrary
unknown unitaries do not satisfy this interface. Function-oracle
controls can be built by compute, controlled-copy, uncompute, so no
free controlled version of an arbitrary unitary is assumed.

## Prior art and limits

* Mosca–Zalka, Sections 2.1, 4.2, 5.2:
  <https://arxiv.org/html/quant-ph/0301093v1>. Their quarter-success
  amplification is established prior art; arbitrary-order exact QFT
  uses computed rotations, and factoring is discussed in a generalized
  model. The new conditional composition does not claim that method.
* Imran, Section 3:
  <https://arxiv.org/html/2205.04240v4>. Its exact order problem explicitly
  receives a multiple m of the unknown r and uses exact QFT_m. Our
  conditional oracle consequence removes that input and gate premise.
* Imran–Ivanyos, Theorem 2:
  <https://www.rintonpress.com/xxqic22/qic-22-910/0770-0789.pdf>.
  Exact solvable-group algorithms are stated with QFT_m/inverse oracle
  access and a group-order prime-divisor promise. They do not by
  themselves supply a fixed-finite-gate replacement here.
* Nishimura–Ozawa:
  <https://arxiv.org/abs/quant-ph/0511117v3>. Finitely generated uniform
  circuit families and QTMs can exactly simulate one another; one must
  preserve the gate model in interpreting the consequence.

The literature pass located these distinctions; it is not exhaustive
priority clearance. There is no proven general exactification of BQP,
generic exact discrete logarithm, arbitrary abelian HSP, general
nonunique-encoding groups, or uniform finite-group state preparation.
Those would require additional acquisition/probability computations;
some state/QFT variants are ruled out by the ring argument above.

## Failure ledger and strongest next attack

Rejected: a blanket number-field impossibility for exact factoring.
The target is a deterministic classical output; the algorithm never
needs arbitrary roots of unity or 1/r uniform measured probabilities.

Rejected: using the known s(r) for every decodable ordinary branch.
Strict multiples also decode; the retained raw-list-contains-r event
is essential. The independent child explicitly checked this distinction.

Rejected: treating the selected branch as deterministic postselection,
or discarding its ancillary success probability. The paper retains that
mass throughout.

Unresolved: complete submitted proof/compiler/Lean dependency verification
and external priority review. All universal factoring conclusions remain
imported premises for the composition; finite arithmetic fixtures do not
remove this dependency.

Strongest next bounded attack: mechanically instantiate the period-oracle
construction with small faithful periodic functions and include all
garbage/history registers through exact quarter preparation and reflection.
That would check the composition circuit interface. General discrete-log
exactification requires a new load-bearing efficiently summable
two-dimensional success law; the one-dimensional P/U argument is not
enough and should not be claimed to transfer automatically.
