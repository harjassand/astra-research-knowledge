# Adversarial check of the proposed exact element-order composition

Status: mathematically valid conditional composition, with an important
predicate/interface qualification. It depends on the order-trial success
law and exact factoring result 279, both at source commit
`adc7f1241b42e322a6451854ab7e4b4c146bf78a`. This is not independent validation
of those imported results.

## Required legal interface

Let a group element `g` have unknown finite order `r`, with a supplied known
integer `n>=128` satisfying `r<2^n`. Exact unique computational-basis
encodings of `g^x` must coincide if and only if the group elements coincide.
Coherent reversible evaluation of powers and exact comparison with the
identity must have polynomial cost, counting oracle calls explicitly.

For a finite group with unique `ell`-bit element labels, one can choose
`n=max(128,ell+1)` because `r<=|G|<=2^ell<2^n`; no supplied group order is
needed. For non-unique encodings, the direct substitution into the order
trial is not justified. Randomized representations, approximate equality,
or mere classical sampling access are likewise insufficient.

If group operations are black-box coherent oracles, the conclusion is an
exact quantum **oracle** algorithm with the source finite gates between
queries. A gate-only theorem requires those oracles to have exact uniformly
generated polynomial-size implementations over the finite gate set. Exact
classical reversible function/XOR-output oracles can be controlled by
compute, conditionally copy, uncompute; arbitrary unknown unitaries cannot
silently be assigned a controlled version.

## Generalizing only the order-trial interface

The necessary source points are:

* `03-order-transform.tex:193–220`: the powered labels coincide precisely
  on residue classes modulo the true order, producing the residue-class
  probability law. For any group, `g^x=g^y` iff `r|(x-y)`.
* `04-dyadic-order.tex:190–196,224–248`: candidate validation uses only
  `1<=d<2^n` and the relation `g^d=e`; all returned candidates are therefore
  positive multiples of `r`. The arithmetic majorant/correction laws
  depend on candidate integers, not the arithmetic structure of residues.

Thus the generalized trial returns no candidate or `d` with
`1<=d<2^n`, `r|d`, and has the imported exact mass

    Pr(d=r) = p_r := phi(r)*2^(-ceil(log2(r))-10).

This substitution needs the exact-period/unique-label interface above; it
does not require an arbitrary exact Fourier transform.

## Decoder from any nonempty returned multiple

Run `K=n^5` independent trials and retain the full raw list. If it has a
nonempty entry, choose one returned `d`. Apply exact factoring 279 to `d`
(handle `d=1` directly). Starting with `v=d`, for each prime `q|d`, replace
`v` by `v/q` while `q|v` and `g^(v/q)=e`.

Invariant: `r|v`. If the terminal `v` were larger than `r`, some prime
`q|(v/r)` would allow another division, contradiction. Therefore `v=r`.
The prime exponents left over from the factorization of `d` give the
canonical prime factorization of `r` without another factoring call.
The stripping loop uses at most `n` successful divisions and at most `n`
terminal failed checks, each involving an exponent of at most `n` bits.

The generated witness is uniquely verifiable:

    1<=v<2^n;
    the canonical prime list factors v;
    g^v=e;
    g^(v/q) != e for every distinct prime q|v.

If `t=ord(g)`, then `t|v` from `g^v=e`. If `v/t>1`, any prime dividing
`v/t` contradicts its associated exclusion check. Hence `v=t`. At `v=1`
the prime list is empty and the test is simply `g=e`, also unique.

## Essential predicate qualification

The ordinary branch must accept only the event

    H = [the raw K-trial list contains an entry equal to decoded r].

Its exact mass is

    s(r)=1-(1-p_r)^K.

It would be wrong to attach this mass to **all** ordinary branches that
decode a valid witness: some lists contain only strict multiples of `r`,
and the decoder still correctly outputs `r`. Such branches must have final
success flag zero unless the raw-list predicate `H` passes.

This qualification is constructive and polynomial: retain the raw list,
decode `r`, then compare every list entry with `r`. The event `H` guarantees
a nonempty entry and therefore successful decoding; any ordinary branch
with no entry can simply fail.

From the source's elementary totient bound and `r<2^n`,

    p_r >= 1/(2048(n+1)),
    1-s(r) <= exp(-n^5/(2048(n+1))) <= exp(-2n) < 2^(-2n).

Thus `s(r)>1/2` and is computable exactly from the acquired factorization
of `r`; its denominator exponent is at most `(n+10)K`.

## Direct quarter correction with acquired unique witness

Use a fixed `J`-bit canonical witness encoding, for example the `n`-bit
integer `r` plus `n` padded `n`-bit prime entries (`J=n+n^2`). In a half
ordinary branch, run the trials and decoder, require the verified witness
and `H`, and retain with

    c(r) = 2^(-J-2) floor(2^(J+2)/(2s(r))).

In a half guessing branch, guess a uniform `J`-bit witness; verify it;
compute `s(r)` from that guessed verified witness; and retain with

    q(r) = 2^(J+1) [1/4 - s(r)c(r)/2].

For the unique true witness, `0<=c<=1` and `0<=q<1/4`; both coins are
dyadic of polynomial bit length. The ordinary passing mass is `s c/2`
and the unique guessed witness contributes
`(1/2)*2^-J*q = 1/4-sc/2`. Their sum is exactly `1/4`.

Computing coefficients from an acquired/guessed witness is not circular:
there is only one verified witness, and every `H`-passing ordinary history
acquires that witness. Wrong guesses are rejected before any coefficient
can contribute. There is no conditioning on witness acquisition in the
probability calculation. Full classical histories, decoder garbage, and
oracle work must be kept for the inverse; the two-reflection exact
amplification then yields certain correct order as in result 279.

## Cost and scope

Only one returned multiple needs factoring. There are `K` trial calls,
one exact-factor279 call, polynomial integer arithmetic, and polynomially
many exact group power/equality checks. With binary powering costing
`O(n)` multiplication queries, the pre-amplification group query count is
`O(Kn+n^2)`, apart from any separately charged equality/encoding costs.
The amplification uses two preparations and one inverse, a constant
factor. All source polynomial exponents may be very large; this is not
a practical implementation claim.

The conclusion is exact element-order computation under the stated
interface and imported results. It establishes neither arbitrary exact
QFT nor general hidden-subgroup reconstruction, and it does not remove
the central dependency on the prescribed-probability order trial.
