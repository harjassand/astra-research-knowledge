# PSPACE-effective unitary synthesis: constructive candidate, not external certification

Date: 2026-10-07. Source release commit adc7f1241b42e322a6451854ab7e4b4c146bf78a.
Status: constructive mathematical candidate; independent adversarial audits found no fatal gap after precision and finite-rounding repairs; not externalcertification. No historical priority assertion.

## Target and legal interface

Let U={U_n}, each U_n an exact unitary on n qubits. Assume there is a deterministic algorithm which, given (1^n,i,j,1^p), computes a dyadic complex approximation to (U_n)_{ij} with error <=2^-p in space polynomial(n+p). The code and a polynomial space bound are fixed; no truth table, state-preparation oracle, prefix probabilities or good random signs are supplied.

Claim under attack: there is one language f_U in PSPACE and a deterministic generator G which, given (1^n,1^b), outputs a Boolean-oracle quantum circuit over H,T,Tdag,CNOT of size/qubits/querylength poly(n+b), with
  ||C_{n,b}^{f_U} iota - iota U_n|| <=2^-b.
Here iota appends zero workspace; relative/global phase is retained, and the bound is the restricted operator norm, hence holds with arbitrary references. f_U accepts addresses (n,b,slot,control value,word,position,symbolbit); all precision parameters are unary/bitlength-charged. The generation algorithm does not use U_n entries; f_U does use the fixed entry algorithm and its bound. A query in PSPACE is not a polynomial-time acquired oracle.

The converse containment follows by simulating a polynomial-size circuit with a PSPACE classical oracle using polynomial-space unitary computation, or by PSPACE entrywise evaluation. Thus, if the candidate proof closes, unitaryPSPACE = unitaryP^PSPACE under Kretschmer-Tang definitions (poly(n,log1/epsilon), phase-sensitive clean implementations).

## Sources and exact released locations

OpenAI283 source base:
https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Polynomial-Time-Unitary-Synthesis-from-a-Boolean-Oracle-October-5-2026/build/
- sections/01-introduction.tex, thm:main: only constant diamond error asserted; arbitrary target-dependent truth table; no acquisition claim.
- 03-contraction.tex, contract:moment, contract:block, contract:depth: random-sign contracting block.
- 04-fields.tex, fields:feedback, fields:gram, fields:sparsity: Neumann feedback, isometric Gram telescope, sparse Fourier rows.
- 05-encoders.tex, encode:row-sparse, encode:implementation: row-sparse near-isometry implementation by slots, cost O(L(n+w+h)).
- 06-recursion.tex, rec:step, rec:skeleton: exactly one recursive call per level; error delta'+2r^L/(1-r)+10r^(2L).
- 07-compilation.tex, compile:slots: pair of SU2 word tables preserve U2 phase by one phase-scratch qubit. Released proof intentionally uses weak polynomial-in-1/eta word bound; our precision extension replaces that bound by full Solovay-Kitaev.

Kretschmer and Tang, Unitary complexity in polynomial space, arXiv:2610.03705v2 (5 October 2026):
https://arxiv.org/pdf/2610.03705v2
- Theorem6.17 / informal Theorem3.5: PSPACE matrix-entry approximation characterization.
- Lemma7.4, Corollary7.5: positive full-precision synthesis implies unitaryPSPACE subset unitaryP^FNEXP.
- Corollary7.16 / informal Theorem1.1: commitments imply either no full-precision synthesis or BPP != NEXP.
- Intro after Cor1.3 explicitly asks PSPACE-effective synthesis; this candidate is stronger than immediate NEXP composition.
The exact formal theorem numbers will be rechecked before final reporting. The OpenAI proof itself gives phase-sensitive clean restricted operatornorm, even though its main statement retains only the weaker diamondchannel consequence; no channel-to-unitary identification is used here.

## 1. Full-precision extension of the released skeleton

Use r=3/4; choose M=2^20(n+1)^2 instead of released4096(n+1)^2 (for short-seed signs below), q=max power2 <=d, s=max(1,floor(q/M)), k=d-s and J=8M(n+1). Dimension decrease proof is unchanged: s>=d/(4M), so fewer than J levels.

For an operator-error target e in (0,1), use
 L=ceil(log(72J/e)/log(4/3)),
 b_phase=nL+ceil(log2(L+1)), K=b_phase(L+1), h=ceil(log2(L+1)).
Since 18Jr^L <=e/4, exact field encoders add at most e/4 through all levels. L=O(log J+log1/e), K=O(n L^2+L log L). Q=O(J(K+n+h)); S=O(J[L(K+n+h)+K+n]); these are poly(n,log1/e). No repeated call to the recursively synthesized unitary occurs.

Compile S slots at eta=e/[2(S+1)] (leave a further error budget for dyadic maps). Full SK gives determinant-one words of length poly(log1/eta), rather than the released eta^-3 estimate. A finite constant set of determinant-one H,T,Tdag words and inversewords densely generatesSU2: with W=(HTH)T, takeW^4 andT W^4 Tdag andtheir inverses. Bothhave determinantone; the irrationalrotation andnonparallelaxes argument in compile:words provestheir closureis SU2. SK therefore applies to this fixed inverse-closed finite alphabet. The universal polynomial length bound is hardcoded in G; G never selects words. Each U2 table gate uses two such words, with the phase encoded into the zero scratch qubit as in compile:slots. Query address length O(Q+log S+log wordlength), elementary gates O(S*wordlength*poly(Q)), and total scratch are poly(n,log1/e). Restricted telescoping applies even if phase scratch is reused. This proves full precision given arbitrary Boolean truth table; it is not error reduction by repetition.

## 2. Short-seed signs replace unrestricted existential sign strings

Set a=n+1. A 2a-wise independent family of q Rademacher signs has a seed of O(a log q)=O(n^2) bits: evaluate a degree(2a-1) random polynomial over GF(2^logq) at each coordinate and apply a nonzero linear trace bit. A representation of the field can be found by polynomial-space enumeration of irreducible polynomials; alternatively its polynomial-time construction is standard. Each sign is evaluable in polynomial space from seed/index.

For any complex sign sum S=sum eps_j alpha_j with sum|alpha_j|^2<=1/q,
 E|S|^(2a) <= (4a/q)^a.
Proof: |x+iy|^(2a)<=(2^(a-1))(|x|^(2a)+|y|^(2a)); each real moment <=(2a-1)!!(sum coefficients^2)^a <=(2a)^a/q^a. 2a-wise independence preserves this moment exactly.
Hence for E2,
 Pr[max_{q*s entries}|(M0 E2 W)_{ij}|>16 sqrt(a/q)]
 <= q*s*64^-a <=4^n64^-(n+1)<1.
Search seeds by finite dyadic approximations with a gap to 17sqrt(a/q). This selects a canonical seed whose exact C'=M0E2W entries have modulus <=17sqrt(a/q). Approximation tolerance is 2^-O(n), so the seed test is PSPACE and robust; no exact-zero test is used.

Consequently ||c_i||^2<=v=289 s a/q and ||h_i||^2=s/q. Let L_i be released Hermitian dilation; sum L_i^2<=vI. For full signs Y=sum eps_i L_i, Schatten-Jensen conditional on Gaussian magnitudes yields
 E Tr Y^(2a) <= mu^(-2a)*(2s)*(2a-1)!! v^a
 <=4^a*(2s)*(2a)^a v^a,
where mu=E|g|>1/2. This moment is unchanged by 2a-wise independent signs. Since Tr Y^(2a)=2Tr(Ddag D)^a,
 E Tr(Ddag D)^a <=s*(2312 a^2 s/q)^a
 <=s*(2312/2^20)^a <=2^(a-1)*(2312/2^20)^a
 <16^-a.
There is therefore a seed with Tr(Ddag D)^a <=16^-a, much below the acceptance threshold (3/4)*4^-a. Evaluate the trace to additive error <=(1/8)*4^-a and accept iff its estimate <=(3/4)*4^-a. Accepted seeds have trace <=(7/8)*4^-a and thus ||D||<1/2<r. A good seed must be accepted. Trace evaluation streams paths through products of2a implicit matrix entries, with O(an) index bits and precision O(n^2). Search over O(n^2)-bit seeds is PSPACE, not polynomial time.

For s=1, a canonical row having a sufficiently small last-column entry can be selected with a robust gap: some modulus<=1/sqrt(d)<=1/sqrt2<3/4. Approximate to a fixed accuracy below the gap, select first modulus<=say0.73; record the transposition. It uses O(n) space and can be applied from its row-index table without storing an exponential permutation.

## 3. Effective feedback and additive precision propagation

Naive floating-point path expansion is unsafe: the absolute sum may require n*t extra bits in child evaluations, yielding p->O(np) at each of J levels. We instead round the implicit matrices ONCE to a common dyadic grid, then perform each local path computation exactly.

At requested feedback accuracy2^-p, form a conceptual (not stored) Vbar by running a fixed dyadic entryapproximation at precision p+n+c+3, then rounding THAT finite dyadic to a common p+n+c bit grid. Never round an exact arbitrary computable real at a grid threshold. Fixedcode makes repeated accesses return the same finite value. The total entryerror is <=2^(-(p+n+c)+1); absorbthisguard factor into c. Since d<=2^n, ||Vbar-V||<=2^n max_entry_error<=2^(-p-c). Likewise approximate each diagonal Z entry deterministically at extra guardprecision, then roundthe finite dyadic to p+c bits, giving ||Zbar-Z||<=2^(-p-c). With c a sufficiently large absolute constant, the product Wbar=Dbar Zbar has norm<=4/5, uniformly. The original exact W=DZ has norm<=3/4.

The resolvent map is uniformly Lipschitz. ||(I-W)^-1||<=4, ||(I-Wbar)^-1||<=5, and the resolvent identity gives
 ||(I-Wbar)^-1-(I-W)^-1||<=20||Wbar-W||.
Using ||A||,||B||,||C||,||D||<=1 and their rounded norms<=1+small, expansion of Abar+Bbar Zbar (I-Wbar)^-1 Cbar shows a fixed absolute constantC (e.g.C=200 suffices) times the operator rounding error. Increase c accordingly. Truncating the rounded Neumann series after t=O(p+c) terms gives error<=5*(4/5)^t timesbounded||Bbar||||Zbar||||Cbar||, <=2^(-p-2) by an explicit integer choice t.

Compute its entries EXACTLY as dyadic rationals by streaming all length<=t paths. Every factor has a common denominator2^O(p+n); a path product has denominator2^O(t(p+n)), and putting all terms over that common denominator adds at mostO(nt+logt) bits to the numerator. Thus each accumulator/counter has O(p^2+np+n^2) bits. The exponentiallymany summands cost time2^poly(n+p), not space. Crucially, calls to the previous-level exact-entry routine request only p+n+c bits, NOT p+nt. There is no floating-point accumulation loss in the local Neumann polynomial.

Pre/postconditioning V=P_L U P_R uses at most two exact-unitary matrix products. Evaluate them similarly on globally rounded dyadic factors, or stream exact rational products; requesting child entries at p+O(n) bits suffices in norm, with a fixedconstant perturbation bound. Signs/permutations/Hadamard entries have explicit polynomialspace evaluation. Seed selection uses bounded precisions polynomial(n) for its fixedgap tests, independentof requested finalp. It is always performed with the same deterministic rounding conventions, so the mathematically exact target transformations selected by the tests are well-defined.

Let E_j denote an entry evaluator for the jth recursively prescribed exactunitary family. Evaluating E_j to p bits requires E_(j-1) at precision at most p+c1*n+c2 (for feedback and matrixproducts), pluscalls at a fixed seedtest precision p_seed(n)=poly(n). After at most J levels, all requested precisions are at most p+O(Jn)+p_seed(n). An evaluationframe has polynomial(n+p+J+K) storage; frames nest at mostO(J), plus polynomial-depth arithmetic recursion. All loop indices, exact rational accumulators, priorphase labels, andthe stack occupy polynomial(n+p) space because J,K themselves are polynomial(n+p). No exponential matrix is materialized.

This closes the naive multiplicativeprecision problem identified by the adversarial auditor. Exact dyadic rounding is used only internally to evaluate theexact feedback family; the candidate full circuit approximates that family with independentlycharged errors.

## 4. Dyadic Fourier coefficient matrices avoid illconditioned slot data

At one level the field matrix T has R<=2^(K+n) rows and d<=2^n columns, row support at most L, and (1-r^(2L))I<=TdagT<=I. A Fourier coefficient is computed by streaming all paths of length m<=L whose internal multiset gives the signed frequency; m and each path index require O(nL) bits. Its coefficient is a finite sum of products of B,C,D entries. The number of summands is at mostL*2^(nL), so additive2^-p coefficient accuracy requires only p+O(nL) bits in the underlying entries. The power sums have O(nL+logL) bits, exactly as in fields:sparsity.

Do not query whether a coefficient is exactly zero. For any row frequency, decode the length m from the first power sum; reconstruct/verify its unique internal multiset by PSPACE enumeration/Newton identities. Potential support comprises only the distinct indices in that multiset, plus the one port at zero frequency. If no legal multiset exists, support is empty. This row support is at most L and can be padded using invalid extended indices; see the released extended dimension2^(n+h)>=2^n(L+1). Restrict approximated coefficients to this potential support.

Choose dyadic delta=2^-ceil(log2(176J/e)), so delta<=e/[176J]. Approximate all legal coefficients by a common dyadic grid so each entry error<=delta/sqrt(R*d). Then ||That-T||<=||That-T||F<=delta. Define Ttilde=That/(1+delta), making an exactly rational matrix. Since ||That||<=1+delta, Ttilde is a contraction. Also ||Ttilde-T||<=2delta, and
 (1-r^(2L)-4delta)I<=Ttilde_dag Ttilde<=I.
By encode:row-sparse, its encoder differs from the embedded Ttilde by <=5(r^(2L)+4delta), hence from ideal T by <=5r^(2L)+22delta. Two encoders add44delta per level. Total encoder/feedback error<=J[18r^L+44delta]<=e/2 with the above choices.

Ttilde coefficients are rational with poly(n+log1/e) bit numerators/denominators. A column prefix probability is a sum of squared rational coefficients across at most2^(K+n) rows. Common-denominator arithmetic yields exact rational prefix sums of polynomial bitlength (the sum adds only K+n bits). Column norm<=1, so remaining flag-zero probability is nonnegative. Every nonzero rational is bounded below by2^-poly(n+log1/e), preventing an unbounded bit demand for ratios/phase normalization. Square roots/rotations can therefore be approximated in PSPACE with polynomial precision. Zero rational tests are exact finite tests. The row-support inverse stateprep uses only a polynomial list of integers. This repairs the failure of using exact arbitrary-real prefix ratios.

## 5. A PSPACE Boolean word oracle

For a dyadic/rational table gate W_y computed in PSPACE, enumerate pairs of determinant-one gate words of length at mostpoly(log1/eta) over fixed H,T,Tdag inverse alphabet. Determinantone is decidable exactly from the symbol counts (roots of unity). Test their action on target tensor zero phase-scratch against W_y tensor zero, using a constant-dimensional matrix approximation with a gap. Existence of SK words with error eta/8 ensures a pair passes a robust eta/2 test. Enumeration counter has polynomial length; word matrix products use polynomial bits. Return requested bit of first accepted pair, padding with identities. This avoids choosing a square-root branch of det(W_y) by exact real sign tests. Work is PSPACE uniformly over all n,b,slot,y; query width remains polynomial. No truth table is materialized.

## 6. Consequences and limits (conditional on closing this candidate)

- unitaryPSPACE = unitaryP^PSPACE for phase-sensitive clean polylogprecision definitions.
- The same construction relativizes to any classical language L, yielding unitaryPSPACE^L = unitaryP^(PSPACE^L), because all scalar entry procedures merely use polynomial-length L queries.
- If P=PSPACE (or P^L=PSPACE^L), replace the PSPACE Boolean word oracle by its polynomial-time reversible evaluator; then unitaryP=unitaryPSPACE (respectively relative to L). This resolves the conditional unitary/classical collapse question positively.
- More strongly, if BQP=PSPACE, replace each PSPACE oracle with a coherent amplified BQP decision circuit. Keep the address unchanged, compute the answer with worst-case failure<=zeta^2/16, XOR its output into the oracle target, then uncompute. On the zeroancilla subspace, this differs from theideal Boolean oracle by atmostzeta in operatornorm: every addressbranch is orthogonalbecause addressis unchanged; forward error and inverseerror each<=2sqrt(failure). Use zeta=e/[poly(numberofqueries)] andamplify bypoly(addresslength+log1/e) repetitions. ThenunitaryP=unitaryPSPACE. Kretschmer-Tang's quantumcommitment separation yields quantum commitments=>BQP!=PSPACE andhenceP!=PSPACE. This isconditional onexistenceofstandard uniform computationallysecure commitments, notunconditional classicalseparation orconstructionof commitments. Brakerski-Canetti-Qian ITCS2023 explicitlyask this BQP-vs-PSPACE implication andpoint toPSPACEoracle Helstrom synthesis asan answer route (p24:9).
- Evaluating f_U is still generally exponential time. The legal acquired oracle is in PSPACE, not uniformlyefficient classical computation.

## 7. Concrete barrier to efficiently acquiring an oracle for arbitrary succinct targets

For any PSPACE language L define U_{2n+1}|x>|z>=|x>|z xor L(x)> (with unused n workspace qubits if needed). U entries are PSPACE computable. A uniform polynomial-time classical constructor that outputs a polynomial-size reversible evaluator for a suitable released-synthesis oracle on all such descriptors would, combined with the released constant-error circuit, decide L in BQP: apply to |x,0>, measure answer. Full diamonderror1/2 yields bit-error<=1/4. Thus universalefficient acquisition for these targets implies PSPACE=BQP. This is an exact reduction, not an unconditional lower bound. It also matches the candidate theorem: PSPACE oracle acquisition is legal but costs exponential time in general. For arbitrary truth-table targets, information/counting already forces exponentialdescription for some oracles; a finite one-line label is not a legal targetencoding.

## Failure/uncertainty ledger

1. Immediate Cor7.5/7.16 composition from constant-error statement alone is invalid; full precision extension is necessary.
2. Exact arbitrary-real row support or phase/ratio tests are not PSPACE-effective in general; dyadic coefficient repair is necessary.
3. Unrestricted sign-string lexsearch would require exponentialspace; short-seed k-wise independence is necessary.
4. Root and independent auditors internally checked the named proof gates; this is not externalvalidation ofrelease283 or theextension.
5. Date alignment: KT v1 Oct2, v2 Oct5; release283 Oct5. Need inspect whether another source already proves this PSPACE-effective corollary. Do not claim priority based on a search alone.


## Appendix: base scalar and deterministic support conventions

At d=1 the recursively prescribed exact unitary is a scalar phase alpha=U_(J)(0,0), PSPACE approximable by section3. The slot table on an index bit canbe diag(alpha,1); no argument/phasebranch extraction is required. The wordpair oracle evaluates this2x2 matrix directly and uses a rectangular4x2 cleanaction test.

For padding a rowsupport list, append extendedindices 2^n,2^n+1,... until exactlyL distinct indices appear. Theseindices areinvalid inputcolumns and never collidewith valid support. Theyfitbecause2^(n+h)>=2^n(L+1). For support reconstruction, afterrecoveringm fromthe firstfrequencycoordinate, Newtonidentities givea degree-m monicinteger polynomial ifthe frequencyis valid. Check exactinteger divisibility inthese identities; otherwise labelrow invalid. Enumeratei in[1,s], divideout (T-i) withmultiplicity whenever it divides; storeat mostL distinct roots. Accept iffdegreefalls to0 andthe reconstructedpowersums matchthe original frequency. Thisuses polynomialspace; no unprovenefficient integerpolynomialfactorizer isneeded. Zero-frequency rows haveonly their matchingport; otherm=0 rows areinvalid.

All source-dependent choices arefixed by firstaccepted finite-gap dyadic tests. Thusno exactcomparison of arbitrary computablereal numbers isrequired. Circuittables forinvalid labels/indices areassigned identityorcanonical zero-preparation extensions. Theseextensions do notaffect thevalid subspaceclaims butmakeevery Booleanoracletotal.
