# PSPACE-effective Boolean-oracle unitary synthesis

7 October 2026. Constructive conditional derivation from the released OpenAI 283 mechanism. Internal independent audits found no fatal obstruction after the repairs described here. This is not external certification, an unconditional classical separation, or historical-priority clearance.

## Theorem and input contract

Let U={U_n} be a family of exact n-qubit unitaries. Suppose a fixed deterministic algorithm, on input (1^n,i,j,1^p), returns a complex dyadic approximation to (U_n)_{ij} with additive error at most 2^-p in space polynomial in n+p. The code and its space bound are fixed. No state-preparation oracle, conditional probabilities, sign table, or truth table is supplied.

Using the feedback and row-sparse encoder construction of OpenAI 283, there is one total Boolean language f_U in PSPACE and a deterministic polynomial-time circuit generator G such that G(1^n,1^b) outputs an oracle circuit C_{n,b}, over H,T,Tdag,CNOT and f_U, with polynomial(n+b) qubits, gates, queries, and address length, and

    ||C_{n,b}^{f_U} iota - iota U_n|| <= 2^-b.

Here iota appends zero workspace. The estimate retains the actual scalar phase of U_n, restores the workspace in the ideal comparison, and holds on arbitrary superpositions and with arbitrary reference systems. The oracle address contains (1^n,1^b,slot,control value,word,word position,symbol bit). Malformed addresses return zero.

This oracle is acquired in polynomial space; its evaluation can take exponential time. The theorem does not supply a polynomial-time classical evaluator. Through Kretschmer–Tang's entry characterization and restricted-norm extension lemma, the conclusion is

    unitaryPSPACE = unitaryP^PSPACE,

for their clean phase-sensitive classes with polynomial(n,log(1/epsilon)) resource bounds. The same proof relativizes to classical languages L:

    unitaryPSPACE^L = unitaryP^(PSPACE^L).

The proof below gives the additional algorithmic work beyond the released constant-error statement.

## 1. Polynomial resources at arbitrary precision

Set a=n+1, M=2^20 a^2, r=3/4, and J=8Ma. At order d, let q be the largest power of two at most d, remove s=max(1,floor(q/M)) coordinates, and retain k=d-s. The released dimension-decrease argument still gives s>=d/(4M), hence fewer than J reductions.

For desired restricted operator error e in (0,1), set

    L = ceil(log(72J/e)/log(4/3)),
    b_phase = nL+ceil(log2(L+1)),
    K = b_phase(L+1),
    h = ceil(log2(L+1)).

The released feedback identity and field Gram telescope give per-level tail error at most 18r^L. Thus 18Jr^L<=e/4. Its encoder implementation has O(L(K+n+h)+K) slots; the entire skeleton has

    Q = O(J(K+n+h)) qubits,
    S = O(J[L(K+n+h)+K+n]) slots.

All are polynomial in n+log(1/e). The recursive smaller unitary is called exactly once per level. Amplitude amplification repeats only the local state preparations.

The source's deliberately weak word bound polynomial(1/eta) must be replaced by full Solovay–Kitaev. A fixed inverse-closed finite determinant-one alphabet is available: put W=(HTH)T and use W^4, T W^4 Tdag, and their inverses. The source's irrational-rotation/nonparallel-axis argument proves density in SU(2). Solovay–Kitaev then gives words of length polynomial(log(1/eta)), expanding to constant-factor longer H,T,Tdag words. A universal length polynomial can be hardcoded in G.

Compile each slot at eta=e/[2(S+1)]. Each U(2) slot uses a target SU(2) word and a phase-scratch SU(2) word, as in the source; this retains relative scalar phases. The resulting gate count and query length O(Q+log S+log word length) are polynomial in n+log(1/e). The oracle stores the word choices; the generator does not find them.

## 2. Deterministic short-seed contracting blocks

The source proves existence using q independent signs, whose full assignment would occupy exponential space. Replace them by 2a-wise independent signs. A degree-(2a-1) polynomial over GF(2^log q), evaluated at q distinct points and followed by a fixed nonzero F2-linear functional, gives such signs from 2a log q=O(n^2) seed bits. A field representation is found by polynomial-space enumeration of irreducible polynomials. Each sign is evaluated on demand; the full string is never stored.

For a complex sign sum S=sum_j eps_j alpha_j with sum|alpha_j|^2<=1/q,

    E|S|^(2a) <= (4a/q)^a.

Indeed, apply (x^2+y^2)^a<=2^(a-1)(x^(2a)+y^(2a)), and the real Rademacher moment bound (2a-1)!!<= (2a)^a. This expectation is a degree-2a polynomial in the signs, so limited independence preserves it.

For the first sign table E2, the union bound therefore gives

    Pr[max |(M0 E2 W)_{ij}| > 16 sqrt(a/q)]
      <= qs*64^-a <= 4^n*64^-(n+1) < 1.

Search polynomial-length seeds using fixed dyadic entry estimates and an acceptance threshold strictly between the squared bounds 256a/q and 289a/q. Reserve error on both sides. Every accepted seed satisfies the exact bound 17sqrt(a/q), while a seed meeting the 16sqrt(a/q) bound must pass. These tests use polynomial(n) digits and are independent of later requested precision.

For the second sign table E1, let L_i be the released Hermitian dilation and Y=sum eps_i L_i. With v=289sa/q,

    sum_i L_i^2 <= vI,
    E Tr Y^(2a) <= mu^(-2a)*(2s)*(2a-1)!!*v^a,
    mu=sqrt(2/pi)>1/2.

The trace-moment inequality follows by conditional Jensen for the convex Schatten-2a power and the source Gaussian moment bound. Unlike norm expectation, this is a polynomial moment preserved by 2a-wise independence. Since Tr Y^(2a)=2Tr(Ddag D)^a,

    E Tr(Ddag D)^a <= s*(2312a^2s/q)^a < 16^-a

for M=2^20a^2. Approximate this trace to error at most 4^-a/8 and accept if its estimate is at most 3*4^-a/4. Some seed passes. Every passing seed has exact trace at most 7*4^-a/8, so ||D||<1/2<r. Stream paths of length 2a through implicit matrix entries to evaluate the trace. Seed counters, path indices and the needed O(n^2)-bit accumulators fit in polynomial space.

For s=1, some last-column entry has modulus at most 1/sqrt(d)<=1/sqrt(2)<3/4. A fixed-gap dyadic search finds a qualifying row. Its conditioning permutation can be a transposition, computed from that O(n)-bit row index. No exponential permutation table is stored.

## 3. Stable recursive feedback evaluation

The exact recursively prescribed unitary is

    F(z)=A+BZ(I-DZ)^-1 C.

A naive floating-point expansion can demand p+O(nt) child precision for t=O(p), multiplying precision at each recursion level. That approach is rejected. The Lipschitz argument below is applied only after fixing the canonical seed and permutation choices. Seed selection itself is discontinuous: each numerical evaluation reuses the same deterministic fixed-precision selection rule, and never reselects signs using Vbar or output-dependent precision.

Instead, define a conceptual globally rounded matrix Vbar. Run the fixed exact-entry approximation algorithm at extra guard precision, then round the returned finite dyadic to a common grid with entry error at most 2^(-(p+n+c)). Do not round an arbitrary exact real at a threshold. Deterministic finite approximation gives consistent values on repeated access. Then ||Vbar-V||<=2^n*max entry error<=2^(-(p+c)). Define Zbar by the same finite-approximation procedure, with diagonal error at most 2^(-(p+c)). For a sufficiently large absolute c, ||Dbar Zbar||<=4/5.

Exact and rounded inverse norms are bounded by 4 and 5. The resolvent identity gives

    ||(I-Dbar Zbar)^-1-(I-DZ)^-1||
      <=20||Dbar Zbar-DZ||.

Thus the feedback expression changes by at most an absolute constant times the rounding error. A length t=O(p+1) Neumann polynomial for Dbar Zbar has a tail at most 5(4/5)^t, also below the requested budget.

Evaluate this finite rounded polynomial EXACTLY as rational path arithmetic. Factors have common dyadic denominators with O(p+n) bits. A path product has O(t(p+n)) denominator bits, and aligning all lengths and adding all paths adds O(nt+log t) numerator bits. These numbers, and the O(nt)-bit path counter, use polynomial space. The many paths cost exponential time. Their count does not increase the input approximation error, because that error was bounded once in matrix norm before exact evaluation.

Walsh conditioning introduces only another O(n) child precision loss: the absolute coefficient sum in a transformed entry is at most 2^n by Cauchy–Schwarz on the two unitary rows/columns. Taking a conservative p+3n+c guard suffices. Fixed-gap seed tests use some precision P_seed(n)=polynomial(n), independent of p. The preceding-level request obeys

    p_prev <= max(p,P_seed(n))+C n+C.

At fewer than J levels all requests are bounded by p+P_seed(n)+C(n+1)J. Frames store polynomial-size rationals, indices and phase labels; labels occupy O(JK) bits. The polynomial-depth stack remains polynomial space. Seed tests invoke only earlier unitary levels, so no circular numerical definition occurs.

## 4. Effective Fourier encoders without exact-real tests

In Fourier coordinates the released field matrix T has at most R=2^(K+n) rows, d<=2^n columns, and at most L nonzero entries per row. It satisfies

    (1-r^(2L))I <= Tdag T <= I.

A coefficient is a finite sum of products along at most L internal visits. At most L*2^(nL) paths contribute. L is already a fixed polynomial in n+log(1/e), so computing a coefficient to p bits from factor approximations at p+O(nL+log L) bits uses polynomial space. This loss is charged once at the outer coefficient calculation, not recursively at every feedback level.

Use structural support rather than testing whether a real coefficient is exactly zero. The signed frequency records a unique multiset of at most L internal indices; only indices in that multiset can occur in its row. Newton identities reconstruct its monic integer polynomial. Enumerate possible integer roots in [1,s], divide out roots with multiplicities, and verify the original power sums. Reject invalid rows. This uses polynomial space and requires no efficient polynomial factorizer. At zero frequency only the matching port column is legal. Pad with distinct invalid extended indices 2^n,2^n+1,... until the list has exactly L entries.

Choose a power of two delta<=e/(176J). Compute a common-grid coefficient matrix A, restricted to this structural support, with entry error at most delta/sqrt(Rd). Consequently

    ||A-T|| <= ||A-T||F <= delta.

Put Ttilde=A/(1+delta). This is an exactly rational contraction and

    ||Ttilde-T||<=2delta,
    (1-r^(2L)-4delta)I <= Ttilde_dag Ttilde <= I.

The released row-sparse encoder applied to Ttilde differs from embedded T by at most 5r^(2L)+22delta. Two encoders add 44delta per level. Together with the feedback tail, total error is at most

    J[18r^L+44delta] <= e/2.

All entries of Ttilde have a common rational denominator H with polynomial bitlength. Write coefficients as (u+iv)/H. Prefix squared norms are exact rational numbers N/H^2, with polynomial-bit integers; enumerating the rows adds only log R bits. Place unused column norm in a failure basis state with amplitude sqrt(H^2-sum(u^2+v^2))/H. Nonzero prefix probabilities are at least H^-2. Ratios, square roots and phase normalization therefore need only polynomial precision. Zero tests are finite integer tests. Arbitrarily small exact-real probabilities never enter the oracle computation.

## 5. One PSPACE Boolean word oracle

Given a slot address, compute its U(2) table entry by the procedures above. Enumerate pairs of determinant-one gate words up to the polynomial Solovay–Kitaev length bound. Test the 4-by-2 isometry consisting of a target word and a phase-scratch word on scratch |0> against W_y tensor |0>, with a finite dyadic approximation and a strict gap. Words approximating to eta/8 guarantee that a pair passes; choose the first passing pair. Return the requested symbol bit.

The determinant is checked exactly by the residue 4#H+#T-#Tdag modulo 8. Word counters and constant-dimensional products use polynomial space. This search avoids extracting a branch of sqrt(det W_y) or deciding an arbitrary real sign. At d=1, the remaining scalar u is computed entrywise and implemented with diag(u,1); the same pair-word search handles it without an argument function.

The oracle is one fixed total PSPACE language across all n and precision parameters. Word lookup is coherent in polynomial-length addresses. Compilation adds at most Seta<=e/2 error, so the complete restricted error is at most e. Spend a further constant factor when invoking Kretschmer–Tang Lemma5.3, which converts restricted error epsilon/2 to epsilon-closeness to a full-space extension. Polynomial resource bounds are unaffected.

## Consequences, comparator and limits

If BQP=PSPACE, replace f_U by an amplified coherent BQP decision circuit. Retain the address, compute its answer with failure probability at most zeta^2/16, XOR the answer into the target, then uncompute. Distinct address branches stay orthogonal, so the restricted operator error is at most zeta uniformly on superpositions. Amplification needs polynomial(address length+log(1/zeta)) work. Allocate zeta inversely to the polynomial number of oracle calls. It follows that unitaryP=unitaryPSPACE.

Kretschmer–Tang Theorem7.14 states that standard EFI pairs imply unitaryP!=unitaryPSPACE; quantum commitments are equivalent to EFI pairs. Thus the repaired synthesis argument yields, conditionally on the released mechanism,

    quantum commitments => BQP != PSPACE => P != PSPACE.

More concretely, f_U reduces by a polynomial-time many-one reduction to a fixed PSPACE-complete Boolean language such as TQBF. Compute that reduction reversibly around each coherent oracle call. Thus a polynomial-time quantum adversary with a TQBF oracle can break any standard efficiently generated EFI pair or commitment. No EFI pair exists relative to a PSPACE-complete oracle, and the analogous assertion holds relative to PSPACE^L. This excludes auxiliary-input schemes whose supplied quantum advice does not have the required effective matrix description.

This addresses the question explicitly posed by Brakerski–Canetti–Qian, ITCS2023, p24:9. It does not prove that commitments exist. The corresponding classical-oracle relativization rules out a language L with P^L=PSPACE^L but unitaryP^L!=unitaryPSPACE^L under these definitions.

For a concrete efficient-acquisition barrier, encode any PSPACE language L in the reversible unitary |x,b> -> |x,b XOR L(x)>. Its entries are PSPACE-computable. A uniform polynomial-time classical constructor producing a polynomial-size evaluator for a suitable 283 oracle for every such succinct target would let a BQP machine decide L. The released full diamond error 1/2 gives at most 1/4 bit error. Therefore universal polynomial-time acquisition in this interface implies BQP=PSPACE. This is a reduction, not an unconditional lower bound.

The bounded current-primary search found the PSPACE-effective question still open in Kretschmer–Tang v2, dated 5 October2026; its existing general consequence uses FNEXP witness oracles. Release283 is also dated 5 October2026. No novelty is inferred solely from that timing or from the absence of a search hit. Verification of the entire released proof and external priority review remain outstanding.

## Primary sources and internal audit trail

- OpenAI283 at commit adc7f1241b42e322a6451854ab7e4b4c146bf78a: https://github.com/openai/math/tree/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Polynomial-Time-Unitary-Synthesis-from-a-Boolean-Oracle-October-5-2026/build . Exact proof gates: contract:moment, contract:block, fields:gram, fields:sparsity, encode:row-sparse, rec:step, rec:skeleton, compile:slots. Local immutable source copies are in source/.
- Kretschmer–Tang, arXiv2610.03705v2: https://arxiv.org/pdf/2610.03705v2 . Definition5.2, Lemma5.3, Theorem6.17, Lemma7.4, Corollary7.5, Theorem7.14, Corollary7.16. Their first-page dichotomy requires full precision; constant diamond error alone is insufficient.
- Dawson–Nielsen, Solovay–Kitaev: https://arxiv.org/abs/quant-ph/0505030 . Fixed inverse-closed dense SU(2) alphabet, polylog precision dependence.
- Brakerski–Canetti–Qian, ITCS2023: https://drops.dagstuhl.de/storage/00lipics/lipics-vol251-itcs2023/LIPIcs.ITCS.2023.24/LIPIcs.ITCS.2023.24.pdf . Section1.2, p24:9, asks EFI=>BQP!=PSPACE.
- Independent repair audit: pspace_acquisition_audit/AUDIT.md. Separate state-preparation audit: pspace_acquisition_audit/dyadic_stateprep_check/AUDIT.md.
- Exploratory calculations and rejected naive precision route: PSPACE_EFFECTIVE_CANDIDATE.md.

No simulation or model consensus is used as a proof of the universal theorem. The conclusion rests on the explicit construction and imported proof gates, with internal adversarial checks scoped as stated.
