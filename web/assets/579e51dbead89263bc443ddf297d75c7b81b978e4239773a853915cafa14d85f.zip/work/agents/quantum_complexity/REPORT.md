# Quantum-complexity branch: source mechanisms and direct attacks

Date2026-10-07. Scientific status: candidate derivations and scoped counterexamples; no external proof/priority certification. Root intellectual objective is NOT claimed achieved.

## Outcome with greatest consequence

The best changed-premise composition is release283 plus a computable-oracle repair, rather than using commuting repetition to infer a quantum-PCP Hamiltonian. The oracle_synthesis child completed a detailed conditional construction of

    unitaryPSPACE = unitaryP^PSPACE,

for phase-sensitive clean unitary implementations with polynomial(n,log1/error) resources. This is stronger than Kretschmer-Tang's recently published alternative with FNEXP witness access. If the complete construction survives independent audit, quantum commitments imply BQP != PSPACE (thus P != PSPACE); this is conditional on quantum commitments, not an unconditional separation. The primitive introduced is PSPACE acquisition of the Boolean word oracle, not polynomial-time acquisition.

Load-bearing finished proof and costs: oracle_synthesis/PSPACE_EFFECTIVE_SYNTHESIS.md; exploratory candidate: oracle_synthesis/PSPACE_EFFECTIVE_CANDIDATE.md. Independent gates read: oracle_acquisition_independent_audit.md. Elementary coherent replacement proof: coherent_oracle_replacement.md. A fresh independent root reviewer is auditing the full construction. The additional acquisition proof is explicit, but the entire released mechanism and historical priority are not externally certified. Historical novelty remains unresolved.

The source proof actually preserves clean workspace and actual scalar phases. Constant-error release283 by itself does not meet the current complexity-class polylog(error) definition; a deliberate parameter retuning and full SK refinement are necessary. The child gives short-seed signs, streamed trace-moment certification, norm-convergent feedback, exact dyadic local arithmetic, rational approximate Fourier encoders, and PSPACE word selection. Those details preserve the supplied-versus-acquired boundary.

## Sources acquired selectively

Astra cards L02, N11, N26 and P-pcp/P-pcp-obstructions/P-pcp-refinements, plus exact evidence d-2815b2aba17e044e, d-c1f0aa3b0a5c8570 and d-4fbea2698881e27b. Source base https://raw.githubusercontent.com/harjassand/astra-research-knowledge/main/ . Cards/evidence preserve internal candidate status; none is upgraded by retrieval.

OpenAI source283 commit adc7f1241b42e322a6451854ab7e4b4c146bf78a, sections02-07. Direct reading checked clean labels, matrix sign estimate, Neumann feedback, Fourier-multiset row support, row-sparse near-isometric encoder, one recursive call, phase-sensitive Boolean word compilation. Full candidate derivation extends the source and is therefore not merely a quoted theorem.

Current primary literature:
- Kretschmer-Tang, Unitary complexity in polynomial space, arXiv2610.03705v2 (5Oct2026), https://arxiv.org/pdf/2610.03705v2 . General dichotomy: PSPACE-unitary either unsynthesizable with any classical oracle or synthesizable using FNEXP witness search. Its front matter explicitly identifies PSPACE-effective synthesis as open.
- Bafna-Nguyen-Zhang, Gap Amplification for Local Hamiltonians with Combinatorial Soundness, arXiv2610.04952v1 (4Oct2026), https://arxiv.org/html/2610.04952v1 . Exact Def1.1, Thm1.2/9.3, sections2.6 and8.1-8.4 read. The theorem amplifies nonzero-constraint support, not quantitative energy. Its route uses shared quantum inputs, zero-error MPC, and copies of classical violation outcomes. Good qLTCs would make its support cap constant, but energy soundness/alphabet reduction remain separate.
- Bergamaschi-Metger-Vidick-Zhang, Derandomised tensor product gap amplification, arXiv2510.01333v1, https://arxiv.org/html/2510.01333v1 . Source mechanism and applications checked selectively; complete proof not newly certified.
- Anshu-Breuckmann-Nguyen, Circuit-to-Hamiltonian from tensor networks and fault tolerance, arXiv2309.16475, https://arxiv.org/abs/2309.16475 . Primary abstract and successor's exact formula interface; known analysis distinguishes tiny quantitative energy from polynomial combinatorial support.
- ECCC TR26-150, https://eccc.weizmann.ac.il/report/2026/150/ . Near-linear RS codes with transversal multiplication and X soundness; higher-dimensional product expansion dependency remains conditional. Only primary summary read, no full code theorem adopted.
- Brakerski-Canetti-Qian, On the computational hardness needed for quantum cryptography, ITCS2023, https://drops.dagstuhl.de/storage/00lipics/lipics-vol251-itcs2023/LIPIcs.ITCS.2023.24/LIPIcs.ITCS.2023.24.pdf . Child source search identifies BQP-vs-PSPACE implication as a previously explicit cryptographic question. Check exact cited location before novelty claims.

## Locality attack and exact negative capital

Astra N26 remains sharp under its own premise: independent syndrome bits x, one fixed auxiliary space, nonnegative total term normbudget1, each effect depends on<=r bits, exact zero completeness -> uniform invalid-sector gap<=r/t. Noncommuting auxiliaries do not help in that architecture. Sector coupling and dense-column coherent isometries are legal escapes, so no global quantum-PCP no-go follows.

New Bafna-Nguyen-Zhang premise does escape witness copying. Direct attack at its energy conversion yields an exact three-qubit SPLIT teleportation example with combinatorial energy1/3 but ground energy<=4delta²/3. N disjoint copies with delta=2^-N retain support gap1/3 even for entangled states, and energy<=4*4^-N/3; all local projectors have rational O(N)-bit entries. Full proof and exact checks: parent_gap_audit/RESULT.md, check_exact.py, check_exact.json.

Crucial adverse check: the paper's grouping of initialized and Choi constraints eliminates this toy. Its joint projector plus wrong output has ground energy1-sqrt(2delta²/(1+3delta²))->1. A faithful twovertex/oneedge fixed-input specialization likewise contains a joint global edge check. No longer-chain counterexample was established. Therefore the example blocks a GENERIC support-to-energy inference and a split-term architecture, not the new paper's amplification theorem or its eventual energy conversion. This distinction was independently found and retained.

A second filter is sparse_isometry_tradeoff.md. If V has max rowr and columnc, and B rows, then V*BV has row<=crs. In the source tensor-complement family, inherited constant-gap row lower bounds forcecrs>=exp(Omega(sqrt t)). It excludes uniformly row-and-column-sparse common encodings, but intentionally permits exponentially dense columns. This statement depends on the source row lower bound; only the elementary support counting was newly independently proved.

## Factoring consequences

Child also inspected release279 exact factoring with an independent completion audit. No fatal flaw found in inspected exact order arithmetic; finite dyadic checks are scoped. Conditional on source279, an injective period oracle satisfying f(x)=f(y) iff x=y(mod r) with only r<2^n supplied yields exact period finding with O(n^5) calls; unique-encoding blackbox group order uses O(n^6) multiplications and does not require a known order multiple. Source/derived proof: oracle_synthesis/factoring_audit/AUDIT_AND_PERIOD_COMPOSITION.md. A finite-gate dyadic-probability obstruction prevents transferring certainty to arbitrary-denominator uniform samples/QFTs. This is a secondary consequence; no general exact-query-complexity claim.

## Failure ledger

1. Stronger commuting repetition does not acquire positive sparse V,C,B or Hamiltonian locality.
2. Good qLTC Hamming soundness does not give a constant normalized one-site excitation gap.
3. Constant-error unitary synthesis cannot be generically amplified by repetition; use the proof's tunable tail and SK instead.
4. Unrestricted signs lexsearch costs exponential space; use short-seed limited independence.
5. Exact zeros/rounding branches of arbitrary computable reals are not automatic PSPACE decisions; use finite dyadic approximations and rational prefix data.
6. Naive Neumann rounding can multiply required precision by n per recursion level; exact local dyadic arithmetic gives additive precision growth.
7. Generic support-to-energy counterexamples cannot be claimed against grouped parent checks.
8. PSPACE oracle evaluation may cost exponential time. No efficient acquired oracle, unconditional cryptography or unconditional classical separation follows.

## Strongest next attack

Complete a fresh adversarial review of the finished PSPACE_EFFECTIVE_SYNTHESIS derivation, including every table bit, deterministic rounding convention, norm-to-entry precision propagation, clean relative phases, malformed-address bounds, and exact current KT consequence. If it survives, formalize the acquisition theorem and distinguish new theorem from source283 correctness/priority dependencies. The next PCP task requires a faithful >=3vertex grouped parent instance or an independent energy-robust decoder; generic N26 searches and split toy repetition will not resolve it.
