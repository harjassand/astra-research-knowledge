# A compression support obstruction for sparse isometries

Status: direct elementary composition with inherited source row lower bound; no independent proof of that source bound is asserted here. This is a construction filter, not a quantum-PCP no-go theorem.

Let V: C^D -> C^M be an isometry, every V row containing at most r nonzero entries and every V column at most c. Let 0 <= B <= I_M have at most s nonzero entries per row. Then b=V*BV is a positive contraction and has at most csr nonzero entries in every row. Proof: the ith logical column has at most c physical rows; from each, B reaches at most s rows; each reached V row contains at most r logical columns. Hermiticity removes any asymmetry from taking V*.

For P_t=(I_4-J_4/4)^{tensor t}, let F_t=I-P_t. Suppose, as the desired positive compression interface requires for this individual test,

    alpha F_t <= V*BV <= beta F_t, alpha>0,

with alpha constant and B a contraction. Then ker(b)=ker(F_t), b>=alpha F_t, and source P-pcp-refinements's same-coordinate support theorem gives

    alpha <= O(log^2(csr+1)/t).

Consequently csr >= exp(Omega(sqrt(alpha t))). In particular, polynomial row support of B and row/column support of V cannot jointly handle polynomial-depth amplified tests in this coordinate family. Enlarging the number of auxiliary qubits alone does not change the counting bound.

The source lower bound is itself a candidate/internal derivation. Exact source handle: cards/P-pcp-refinements.txt, evidence d-8f0b200475145312, subsection Exact support; primary source base https://raw.githubusercontent.com/harjassand/astra-research-knowledge/main/ . Its full argument is Fourier symmetrization, Chebyshev approximation, and Markov derivative control. This report does not upgrade its validation status.

This filter does NOT exclude a row-sparse isometry with exponentially dense columns, a changed low-energy code, nonmultiplicative global hardness reductions, or tests outside this F_t basis. In fact the Astra heavy-port repair expressly uses an exponentially dense column: W|0> = |0>|+^r>. That is the correct way to evade the support count and shows that the dense-column debt is substantive, not a bookkeeping mistake.

Potential stronger independent statement: if ||V*BV-F_t|| <= epsilon <=1/4, any established operator approximation row lower bound for F_t immediately yields csr >= exp(Omega(sqrt t)). No exact zero-completeness is then required. No new approximate-degree claim is made.
