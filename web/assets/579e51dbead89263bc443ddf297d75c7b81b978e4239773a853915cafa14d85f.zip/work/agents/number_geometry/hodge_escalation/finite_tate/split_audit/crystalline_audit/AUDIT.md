# Crystalline consequence audit — conditional affirmative

The proposed passage to rational crystalline Tate has no additional obstruction once the parent supplies the algebraic retraction in one rational ell-adic realization. Do **not** assert that an equality modulo ell-homological equivalence automatically remains an equality in crystalline cohomology. Instead, transfer ell-adic Tate in every codimension and Frobenius semisimplicity, obtain the strong Tate pole formula, and then transfer to crystalline by numerical rank and characteristic-polynomial independence.

## Exact conditional statement

Fix a finite field k of characteristic p and one prime ell != p. Assume:

1. Rational ell-adic Tate holds in every codimension for every abelian variety over every finite extension of k. Stating this for all finite products of abelian varieties is equivalent for the present purpose, since such products are abelian varieties.
2. For each finite-height K3 surface S/k, after a finite extension k'/k there are algebraic correspondences a_S: h(S) -> M_S and b_S: M_S -> h(S), where M_S is a finite sum of twists of abelian motives and Tate motives, with b_S a_S = id in ell-adic cohomology. The parent owns construction, specialization, and descent of this retraction.

Then rational ell-adic Tate, rational crystalline Tate, and the strong Tate pole formula hold in every codimension for every finite product of arbitrary K3 surfaces over k, and every finite product of their Hilbert schemes of points. Supersingular factors require the known divisor-spanning argument below, rather than the finite-height CM-lift theorem. All conclusions are rational; there is no integral conclusion.

## Reconstruction of the transfer

Choose one common finite extension over which all required correspondences are defined. Tensoring the finite-height retractions exhibits any product of finite-height K3 factors as an ell-adic algebraic retract of finite sums of twists of abelian products. If v is a Frobenius-invariant class on this product, a(v) is an invariant ambient class. Ambient Tate supplies a cycle z representing a(v); b(z) represents v. This works in every codimension, including the complementary codimension needed for intersection duality.

Frobenius is semisimple on abelian cohomology. Finite direct sums, Tate twists, tensor products, invariant subspaces, and direct summands retain semisimplicity in characteristic zero. Thus the retract has semisimple Frobenius. This is stronger than the partial semisimplicity at eigenvalue 1 required in the Tate equivalences.

For a supersingular K3 surface, after a finite extension choose divisors D_1,...,D_22 spanning H^2 and a rational degree-one zero-cycle. The inverse of the divisor intersection matrix gives an algebraic correspondence inducing the identity on H^2. Together with the degree 0 and 4 projectors this gives, modulo ell-homological equivalence,

    h(S) = 1 + L^22 + L^2.

This is a statement about the rational homological motive; this audit does not infer a Chow-motive equality from cohomological spanning alone. Tensoring shows that adjoining any supersingular factors to the preceding products preserves Tate surjectivity and semisimplicity.

Let X/k have dimension d, and suppose Tate surjectivity holds for r and d-r, with Frobenius semisimple at eigenvalue 1 on H^{2r}(X)(r). Poincare duality restricts to a nondegenerate pairing of the two invariant spaces. Since cycles span both, numerical equivalence equals ell-homological equivalence in codimension r, and

    N_r := dim_Q N^r(X)_Q
         = dim_Qell H^{2r}_et(Xbar,Qell(r))^F
         = multiplicity of q^r in H^{2r}_et(Xbar,Qell).

The last quantity is the order of the pole of Z(X,t) at t=q^{-r}; weights rule out cancellation from other degrees. This establishes strong Tate rather than identifying weak surjectivity with the pole formula without a semisimplicity step.

Here is the crystalline argument in fixed-field form. Write q=p^a, K_0=W(k)[1/p], H=H^{2r}_cris(X/W(k))[1/p], and pi=phi^a. Katz–Messing gives the same characteristic polynomial for pi on H as for Frobenius on ell-adic cohomology. Choose N_r cycles and complementary cycles whose rational intersection matrix is invertible. Their crystalline classes are Q_p-linearly independent, so the crystalline cycle image C_p has dimension at least N_r. On the other hand,

    N_r <= dim_Qp C_p <= dim_Qp H^{phi=p^r}
        = dim_K0 H^{pi=q^r} <= multiplicity(q^r) = N_r.

The middle equality is semilinear descent (Hilbert 90). Hence all inequalities are equalities, giving crystalline Tate and partial crystalline semisimplicity at q^r. This proof does not need the original projector identity to be separately known crystalline.

For full crystalline Frobenius semisimplicity, one may use the already known K3 semisimplicity and Kunneth, or use partial semisimplicity for X x X in the middle degree: a Jordan block for any eigenvalue pairs with its inverse to produce a Jordan block at 1. This is the argument of Milne's Theorem 1.5, and has the same crystalline form. Hilbert-scheme motives transfer it to Hilbert schemes.

The Hilbert-scheme Chow-motive decomposition of de Cataldo–Migliorini expresses h(S^[n]) as a direct sum of Tate twists of symmetric-power motives, each a rational projector summand of powers of S. Their Theorem 6.2.1 and Remark 6.2.2 permit arbitrary ground fields. Rational symmetrization is legal even when p divides n!; no p>n restriction enters this transfer. Products of Hilbert schemes use products of these decompositions. The parent handles the common finite extension and rational trace descent to k.

## Statements which must remain distinct

| Statement | Content | Role here |
|---|---|---|
| Rational ell-adic Tate | Cycles span actual invariant vectors | Transferred by algebraic correspondences |
| Partial semisimplicity | Generalized eigenvalue-1 space has no Jordan blocks | Needed for strong Tate |
| Full semisimplicity | Every Frobenius eigenvalue has no Jordan blocks | Transfers from abelian cohomology; also known for K3 |
| Strong/full Tate | Pole order equals numerical cycle rank | Follows from surjectivity, complementary surjectivity, semisimplicity |
| Rational crystalline Tate | Cycles span H^{2r}_cris[1/p]^{phi=p^r} over Q_p | Follows from strong Tate and compatible characteristic polynomials |
| Newton slope r | The entire slope-r subisocrystal | Generally larger than the finite-field Tate invariant space; not the claimed target |

## Primary sources and exact references

- Ito–Ito–Koshikawa, *CM liftings of K3 surfaces over finite fields and their applications to the Tate conjecture*, Forum Math. Sigma 9:e29 (2021), DOI 10.1017/fms.2021.24: Theorem 1.1 / Corollary 9.10 covers every finite height and every p, after finite extension; Theorem 1.5 / 10.1 concerns the square of one K3, not arbitrary products. Lemma 10.4 (printed p.54) supplies ell-to-crystalline transfer; **Remark** 10.5 (p.54), not Lemma 10.5, records crystalline semisimplicity; Lemma 10.6 (pp.54–55), Lemma 10.7 and Remark 10.8 (p.55) cover supersingular rank 22 and powers. The published proof references the characteristic-2 erratum [51]. [Publisher PDF](https://www.cambridge.org/core/services/aop-cambridge-core/content/view/9E14D5849CED8ABFC81CC49818267366/S2050509421000244a.pdf/cm-liftings-of-dollark3dollar-surfaces-over-finite-fields-and-their-applications-to-the-tate-conjecture.pdf)
- Milne, *The Tate conjecture over finite fields (AIM talk)*, version 2.2 (2008): Theorem 1.4 identifies Tate plus complementary Tate plus partial semisimplicity with full Tate; Theorem 1.11 permits p; Theorem 1.5 upgrades middle-degree partial semisimplicity of X x X to full Frobenius semisimplicity. Section 1 also defines the p-adic target using finite-field models and semilinear Frobenius. [Author PDF](https://www.jmilne.org/math/articles/2007e.pdf)
- Milne, *Rational Tate classes*, submitted version (2008), published Moscow Math. J. 9 (2009): §§1.3–1.5 treat finite-field isocrystal semisimplicity and descent; Theorem 1.7 and Remark 1.8(b) provide the simultaneous-prime transfer, explicitly including p. [Author PDF](https://www.jmilne.org/math/articles/2009b.pdf)
- Katz–Messing, *Some consequences of the Riemann hypothesis for varieties over finite fields*, Invent. Math. 23 (1974), 73–77: Theorem 1 (printed p.74), including crystalline characteristic-polynomial compatibility. The scanned theorem was visually verified from the author-hosted copy. [Author-hosted journal scan](https://web.math.princeton.edu/~nmk/old/katzmessing.pdf)
- de Cataldo–Migliorini, *The Chow groups and the motive of the Hilbert scheme of points on a surface*, J. Algebra 251 (2002), 824–848: Theorem 6.2.1 plus Remark 6.2.2, printed p.846. [Author-hosted published PDF](https://www.math.stonybrook.edu/~mde/MyPublishedPapers/MotiveHilbSchJournOfAlg.pdf)

## Failure ledger and remaining boundary

Rejected: weak Tate alone implies strong Tate; equality modulo ell-homology automatically proves a crystalline correspondence identity; a Newton slope-r condition alone means a class is Tate over a finite field; a CM lift theorem for finite height covers supersingular K3 surfaces; rational projectors give integral Tate; a homological Tate decomposition automatically gives a Chow decomposition.

The load-bearing remaining issue is the parent's algebraic retraction/specialization/descent premise. Once that premise is established and ambient abelian Tate is granted in all codimensions, this audit finds no new obstruction in crystalline realization, supersingular factors, or Hilbert schemes. Ordinary self-powers and supersingular self-powers, and arbitrary K3 self-squares, were already known; these are controls, not new conclusions to claim as advances.
