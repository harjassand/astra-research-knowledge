# Supersingular K3: primary-source and homological-motive audit

Status: the supersingular branch is unconditional for rational homological motives in every characteristic p>0, including p=2. Pure Tate form requires a finite field extension defining a divisor basis; over the original finite field the natural form is Artin–Tate. No claim about rational-equivalence motives follows merely from the cohomology calculation.

## Verified primary sources

1. K. Ito, T. Ito, T. Koshikawa, **CM liftings of K3 surfaces over finite fields and their applications to the Tate conjecture**, Forum of Mathematics, Sigma 9 (2021), e29, DOI [10.1017/fms.2021.24](https://doi.org/10.1017/fms.2021.24). [Current published PDF](https://www.cambridge.org/core/services/aop-cambridge-core/content/view/9E14D5849CED8ABFC81CC49818267366/S2050509421000244a.pdf/cm-liftings-of-dollark3dollar-surfaces-over-finite-fields-and-their-applications-to-the-tate-conjecture.pdf).
   - **Lemma 10.6, printed p.54:** over an algebraically closed field of any characteristic p>0, infinite formal-Brauer height is equivalent to Picard rank 22. Its proof explicitly accommodates characteristic 2 and refers to the correction [51].
   - **Lemma 10.7 and Remark 10.8, printed p.55:** Tate for supersingular squares in both ell-adic and crystalline realizations, and for all powers.
   - **Remark 10.5, printed p.54:** crystalline q-Frobenius semisimplicity for supersingular K3 follows from Lemma 10.6.
   - **Remarks 6.9–6.10, printed pp.35–36:** the published version repairs the comparison/étaleness issues, citing the erratum as a different repair.

   PDF downloaded in this directory; SHA256: `6d236cfd8336ac6fae946c47b27c1b9e9bc82407d7f737408d736c45b47dc66a`. The web parser omitted the final line of Lemma 10.6's proof; local pypdf extraction confirmed its reference to [51].

2. W. Kim, K. Madapusi Pera, **2-adic integral canonical models**, Forum of Mathematics, Sigma 4 (2016), e28: **Theorem A.1, printed p.23**, Tate for K3 surfaces over finitely generated fields. [DOI](https://doi.org/10.1017/fms.2016.23), [publisher PDF](https://www.cambridge.org/core/services/aop-cambridge-core/content/view/A775E4486CF0175DC1A8DBC872094E8C/S2050509416000232a.pdf/2adic_integral_canonical_models.pdf).

3. K. Madapusi Pera, **Erratum to appendix to ‘2-adic integral canonical models’**, Forum of Mathematics, Sigma 8 (2020), e14. [DOI](https://doi.org/10.1017/fms.2020.2), [publisher PDF](https://www.cambridge.org/core/services/aop-cambridge-core/content/view/108599E986768412152F17EBACC6FD66/S205050942000002Xa.pdf/erratum-to-appendix-to-2-adic-integral-canonical-models.pdf). **Opening paragraph, printed p.1:** identifies a serious gap in the original Proposition A.12 and credits Ito–Ito–Koshikawa with the first complete characteristic-2 proof. Cite source 2 together with source 3, or use source 1 directly.

## Explicit homological splitting (independent elementary deduction)

Let S/F_q be supersingular. Choose a finite extension k'/F_q on which divisors D_1,...,D_22 forming a Q-basis of NS(S_bar)_Q are defined. Such a common extension exists because there are only finitely many chosen divisors. Choose a rational degree-one zero-cycle z on S_k'; a closed point divided by its degree suffices. Let G_ij = deg(D_i.D_j), and A=G^{-1}, using the nondegeneracy of the surface intersection form.

In rational correspondences of codimension two set

    pi_0 = z × S,       pi_4 = S × z,
    pi_alg = sum_{i,j} A_ij (D_i × D_j).

The action of pi_alg on H^2 sends x to sum A_ij <x,D_i>D_j. The divisor classes form a basis for ell-adic H^2 and, after inverting p, crystalline H^2. Therefore pi_alg acts as identity there and as zero on other degrees. pi_0 and pi_4 supply H^0 and H^4. Odd cohomology vanishes for K3.

The transpose/inverse intersection construction gives explicit maps between the divisor summand and L^{⊕22}. Their two composites are identities in the rational homological category. Thus, for either chosen rational realization,

    h_hom(S_k') ≅ 1 ⊕ L^{⊕22} ⊕ L^2.

Here L realizes as H^2(P^1), i.e. Q_ell(-1) or the slope-one Tate isocrystal. The residual correspondence Delta-pi_0-pi_alg-pi_4 has zero cohomology class by Künneth and Poincaré duality, so is zero modulo homological equivalence. This last step is precisely where one must not silently substitute rational equivalence. Rank 22 alone does not remove a homologically trivial Chow summand.

The splitting is rational. A p-primary discriminant in the Néron–Severi lattice does not obstruct it, including in characteristic 2, since the inverse matrix is allowed rational coefficients. It does obstruct treating this argument as an integral crystalline splitting.

## Products and strong Tate (elementary deduction)

For any finite collection of supersingular K3 surfaces, take one common finite field extension defining all divisor bases. Tensoring the displayed isomorphisms makes every finite product a direct sum of Tate homological motives. Its cohomology is spanned by external products of divisor classes and zero-cycles, in both rational realizations.

Over F_q itself, normalized Frobenius has finite order on each even cohomology degree: on H^2(1) it is the action on NS_Q, and on products this follows by tensoring. It is semisimple in characteristic zero. The base-field invariant classes are algebraic: average a cycle representing an invariant class over the finite Galois extension and divide by the extension degree. This is also the trace construction for crystalline classes.

Consequently, for every codimension r and every finite extension of F_q:

- the rational cycle map surjects onto Frobenius-fixed twisted cohomology;
- numerical and the selected rational homological equivalences coincide, because the Poincaré pairing on the finite-group invariant subspaces is nondegenerate and the complementary invariant classes are algebraic;
- the multiplicity of eigenvalue q^r equals the numerical cycle rank, yielding the usual pole-order or strong Tate statement;
- the q-Frobenius operator is semisimple in both ell-adic and rational crystalline cohomology.

Do not call the motive over F_q a sum of ordinary Tate motives unless NS is already pointwise defined over F_q. In general it is an Artin–Tate motive: 1, L^2, and L tensored with the finite-image rational Artin representation NS_Q. Pure Tate form is true after the finite extension above.

## Failure ledger

- The arXiv v1 of Kim–Madapusi Pera has numbering Theorem 2 rather than published Theorem A.1 and predates the correction. It is not a sufficient standalone characteristic-2 citation.
- Browser PDF text extraction lost the last line of IIK Lemma 10.6; direct downloaded published-PDF extraction recovered it. No theorem gap remains from this extraction issue.
- `pdftotext` is absent locally; no package was installed. Existing Python pypdf succeeded.
- A homological Tate splitting is not, by itself, a Chow Tate splitting or a proof of CH_0 triviality over arbitrary extensions.
- The elementary proof establishes the rational result; it does not establish an integral crystalline statement.

## Hilbert schemes: no small-characteristic restriction in the decomposition

M. A. A. de Cataldo and L. Migliorini, **The Chow groups and the motive of the Hilbert scheme of points on a surface**, Journal of Algebra 251 (2002), 824–848. [Author-hosted published PDF](https://www.math.stonybrook.edu/~mde/MyPublishedPapers/MotiveHilbSchJournOfAlg.pdf).

**Theorem 6.2.1, printed p.846:** rational effective Chow motive decomposition for an irreducible nonsingular projective surface over an algebraically closed field. **Remark 6.2.2, same page:** this theorem holds over any field. The introduction, printed p.824, also explicitly states arbitrary-field scope. No p>n hypothesis is present.

In a convention using L for the Lefschetz motive, the decomposition is

    h(S^[n]) ≅ ⊕_{ν partition of n} h(S^{l(ν)})^{Σ_ν} ⊗ L^{n-l(ν)}.

The quotient notation is the invariant motive under permutations of equal parts, hence a direct summand of h(S^{l(ν)}) using the rational averaging projector. Since the coefficient ring is Q, p dividing |Σ_ν| is permitted. Therefore the displayed supersingular homological Tate splitting transfers to every actual Hilbert scheme S^[n], including p<=n and p=2, separately in ell-adic and crystalline homological categories. It transfers likewise for products of these Hilbert schemes.

This is a theorem about S^[n]. It does not automatically extend to every positive-characteristic deformation or birational model of a K3^[n]-type variety. Nor does a homological Tate input become a Chow Tate conclusion just because the Hilbert-scheme decomposition itself is Chow-level.

Independent source details and quotient-projector verification are in `hilbert_caveat/`.
